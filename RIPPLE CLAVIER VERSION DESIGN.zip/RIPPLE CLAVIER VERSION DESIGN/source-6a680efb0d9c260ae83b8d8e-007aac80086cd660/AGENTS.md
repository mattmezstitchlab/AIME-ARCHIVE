# AGENTS.md

Repère pour les personnes et les agents qui travaillent sur ce dépôt.

## Vue d'ensemble

**AIME® · Ripple — Le Clavier Causal.** Démonstration interactive d'un clavier découpé par
métier : une touche est un geste, le geste ouvre un dossier, propage une onde chez les rôles
concernés et laisse une trace horodatée. Terrain de démonstration : un mariage de 148 personnes,
le 12 septembre 2026.

Le design suit le langage Apple — hiérarchie typographique franche, chrome translucide, surfaces
arrondies en couches, boutons pilule, un seul accent, mouvement bref.

### Pile

| Couche | Technologie |
| --- | --- |
| Framework | TanStack Start 1.167 |
| Routage | TanStack Router v1 (routes par fichier, `routeTree.gen.ts` généré au build) |
| UI | React 19 |
| Build | Vite 7 |
| Styles | Tailwind CSS 4 (`@import 'tailwindcss'`) + tokens CSS dans `src/styles.css` |
| Langage | TypeScript 5.9, `strict`, `noUnusedLocals`, `noUnusedParameters` |
| Paquets | pnpm |
| Déploiement | Netlify — `vite build`, publication de `dist/client` |

## Arborescence

```
├── netlify.toml            build = vite build, publish = dist/client
├── public/                 favicon
└── src
    ├── styles.css          tout le système visuel : tokens, thèmes, classes utilitaires
    ├── router.tsx          createRouter sur le routeTree généré
    ├── data
    │   ├── types.ts        le vocabulaire : Role, Geste, Onde, Stat, Piece, Acte, Profil, Trace…
    │   ├── roles.ts        les 15 rôles, les gestes du moteur, les 6 profils
    │   ├── gestes.ts       roleId → lettre → geste (généré depuis la source, ne pas réécrire à la main)
    │   └── dossiers.ts     les dossiers écrits à la main, clés « role.LETTRE »
    ├── lib
    │   ├── causal.ts       le graphe : arêtes, statistiques, arcs, dossiers dérivés, teintes
    │   ├── moteur.ts       useMoteur — tout l'état du clavier et ses actions
    │   ├── reglages.tsx    FournisseurReglages, localStorage, script anti-clignotement
    │   ├── toast.tsx       FournisseurToast + useToast
    │   └── touches-systeme.ts  la rangée F1–F12 et la touche esc
    ├── components
    │   ├── Chrome.tsx      nav translucide, pied de page, feuille F3, contexte de chrome
    │   ├── Clavier.tsx     le clavier AZERTY dessiné
    │   ├── Dossier.tsx     le panneau qui s'ouvre au-dessus du clavier
    │   ├── Memoire.tsx     le journal des traces
    │   ├── Cascade.tsx     l'onde d'un geste, en SVG
    │   ├── GrapheCausal.tsx  le graphe radial complet (touche G)
    │   ├── CarteDesGestes.tsx  la carte F3
    │   ├── Stats.tsx       jauge / barres / empile / tuiles / chrono
    │   ├── Feuille.tsx     feuille modale (voile flou, focus piégé, esc)
    │   └── Reveal.tsx      révélation au défilement
    └── routes
        ├── __root.tsx      document HTML, métadonnées, fournisseurs
        ├── index.tsx       « Le clavier » — la page principale
        ├── manifeste.tsx   le manifeste
        └── reglages.tsx    « qui suis-je » — profil, rôle d'ouverture, confort, cartes
```

## Le modèle causal

- Un **rôle** possède des **gestes**, un par lettre.
- Un geste porte des **ondes** : `{ r, t }` — quel rôle est déplacé, et ce que ça lui fait.
- Une onde peut porter des ondes de second ordre (`puis`), être **masquée** (`lock`, avec son
  texte réel dans `vrai`), ou déclarer qu'il ne se passe rien (`none`).
- Un **profil** découpe ce catalogue en **couches** de neuf rôles maximum : le chiffre `1`–`9`
  choisit un rôle dans la couche, `0` est le moteur si le profil y a droit.
- Le **pare-feu** (`feu: 'ouvrable' | 'scelle'`) décide si les ondes masquées se lisent.

Tout le graphe est dérivé des données au chargement du module (`ARETES`, `STATS` dans
`lib/causal.ts`) — rien n'est écrit deux fois.

## Conventions

- **Le français partout** : noms de fichiers, de variables, de composants, de props. C'est un
  produit français ; le code parle la même langue que l'interface.
- **Pas de bibliothèque d'UI.** Les surfaces, les boutons et les touches sont des classes de
  `styles.css` (`.card`, `.card-2`, `.btn`, `.cap`, `.display`, `.lede`, `.eyebrow`, `.mono`…).
  Tailwind sert au rythme et à la mise en page, pas à la peau.
- **Les couleurs passent par les tokens CSS** (`var(--ink)`, `var(--surface)`, `var(--accent)`…),
  jamais par les palettes Tailwind — sinon le thème jour/nuit et le réglage de contraste sautent.
  La seule exception est la teinte d'un rôle, obtenue par `teinte(role, jour)`.
- **Les couleurs de rôle sont doublées** : `c` pour la nuit, `cJour` pour le jour (plus dense, pour
  tenir le contraste AA sur fond clair).
- **Rien ne se règle par page.** Le confort de lecture est piloté par la rangée F, montée une
  seule fois dans `Chrome`, et persistée dans `localStorage`.

## Décisions non évidentes

- **Aucune base de données, volontairement.** Le produit promet « aucun compte, aucun envoi » ;
  les réglages tiennent dans une clé `localStorage` (`aime.clavier.v2`). N'introduisez pas de
  stockage serveur sans revoir cette promesse dans l'interface.
- **Script anti-clignotement.** `SCRIPT_SANS_CLIGNOTEMENT` est injecté en clair dans `<head>` :
  il pose `data-theme`, `--ctr`, `--fs` et `--lh` avant la première peinture. L'état React se
  réhydrate ensuite dans un `useEffect` — d'où `pret` dans `useReglages`, qui vaut `false` au
  premier rendu.
- **Rien qui dépende de l'heure au rendu serveur.** Le compte à rebours J−N de la page d'accueil
  est calculé dans un `useEffect` : le HTML rendu par le serveur ne doit pas contenir une valeur
  qui changerait à l'hydratation.
- **La police.** « Apple Design » suppose SF Pro, qui n'existe que sur matériel Apple : la pile
  commence par `-apple-system` / `SF Pro`, puis retombe sur Figtree (Google Fonts) ailleurs.
  Idem pour `SF Mono` → IBM Plex Mono sur les touches.
- **Les gestes du moteur ne portent pas de fonctions.** `Geste.effet` est une chaîne
  (`'graphe' | 'pare-feu' | 'rejouer' | 'exporter'`) que `useMoteur` traduit en action : les
  données restent sérialisables.
- **La rangée F du clavier dessiné rejoue de vraies touches.** `onFn` republie un
  `KeyboardEvent` sur `window` plutôt que de dupliquer la logique de `useTouchesSysteme`.
- **`esc` est délégué.** Chaque page pose sa fonction via `poserEchappe` du contexte `Chrome` ;
  celui-ci ferme d'abord le menu et la carte F3, puis appelle la page.
- **La carte F3 peut presser une touche à distance.** Comme le changement de rôle passe par un
  `setState`, `routes/index.tsx` met la touche en attente et ne la presse qu'une fois le bon
  rôle actif.
- **Les données générées.** `data/gestes.ts` et `data/dossiers.ts` ont été produits par extraction
  puis sérialisation. Modifiez-les comme des données, pas comme du code.

## Accessibilité — à ne pas casser

- Chaque touche est un `<button>` avec son `aria-label` ; les touches inertes sont des
  `<span aria-hidden>`.
- Le lien d'évitement, le `<main data-lecture>` (cible de la lecture vocale F7) et le piège de
  focus des feuilles modales sont dans `Chrome` et `Feuille`.
- `body.no-anim` est posé par le réglage F10 **et** par `prefers-reduced-motion`.
- Les fenêtres modales rendent le focus à l'élément qui les a ouvertes.

## Écueils

- `noUnusedLocals` est actif : un import oublié fait échouer le build.
- `localStorage`, `window` et `speechSynthesis` ne sont touchés que dans un `useEffect` ou un
  gestionnaire d'événement — le rendu se fait aussi sur le serveur.
- `routeTree.gen.ts` est généré : ne pas l'éditer à la main.
- Les écouteurs `keydown` globaux ignorent les champs de saisie et l'intérieur des
  `[role="dialog"]` : gardez ce filtre si vous en ajoutez un.
