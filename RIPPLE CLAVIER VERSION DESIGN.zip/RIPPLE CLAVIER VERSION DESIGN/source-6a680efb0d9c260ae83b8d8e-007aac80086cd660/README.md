# AIME® · Ripple — Le Clavier Causal

Une démonstration interactive : **un clavier par métier**. Une touche est un geste ; le geste
ouvre un dossier, propage une onde chez tous les rôles qu'il concerne, et laisse une trace dans
une mémoire causale.

Le terrain de démonstration est un mariage de 148 personnes, le 12 septembre 2026 — quinze rôles
qui se parlent mal, aucune hiérarchie, une date immuable et des secrets à tenir.

Le site est habillé en **langage de design Apple** : typographie SF Pro, chrome translucide,
surfaces arrondies en couches, boutons pilule, un seul accent bleu, mouvement bref et ferme.

## Ce que fait le produit

- **Une touche fait trois choses** — elle ouvre un dossier (faits, chiffres, onde, pièces),
  propage une onde du premier et du second ordre, et écrit une trace horodatée.
- **Six profils, six claviers** — mariés, invité, prestataire, lieu, témoin, organisation. Ce
  qu'un rôle ne doit pas voir n'est pas grisé : la touche n'existe pas sur son clavier.
- **Un pare-feu causal** — certaines ondes sont sous scellé (les surprises). Seuls les profils
  qui les tiennent peuvent les lire.
- **Les actions ne s'actionnent qu'aux touches** — `⏎` agir, `⌫` reporter, `,` emporter.
- **Accessible par construction** — la rangée `F1`–`F12` règle vraiment la page (contraste, zoom,
  jour/nuit, lecture vocale, interligne, animations, soulignés, focus), et le réglage suit d'une
  page à l'autre. Il n'y a donc pas de page « accessibilité » séparée.
- **Rien ne part** — aucun compte, aucun envoi. Les réglages tiennent dans une clé de
  `localStorage`, sur cet appareil.

## Le clavier

| Touche | Effet |
| --- | --- |
| `A` – `Z` | un geste du rôle actif (`A` aller à, `E` essentiel, `L` lire, `T` traduire sont universelles) |
| `1` – `9` | changer de rôle dans la couche courante |
| `0` | le moteur causal (`G` graphe, `P` pare-feu, `R` rejouer, `X` exporter) |
| `⏎` `⌫` `,` | agir · reporter · copier le dossier ouvert |
| `◀` `▶` | changer de couche |
| `⇧` + lettre | répétition : le geste se calcule, rien ne se propage |
| `esc` | refermer le graphe, puis le dossier |
| `F1` – `F12` | confort de lecture |

Chaque touche dessinée est aussi un bouton : la contrainte est une pédagogie, pas un piège pour
qui ne peut pas taper.

## Pile technique

| Couche | Technologie |
| --- | --- |
| Framework | TanStack Start |
| Routage | TanStack Router v1, routes par fichier |
| UI | React 19 |
| Build | Vite 7 |
| Styles | Tailwind CSS 4 + un système de tokens CSS maison (`src/styles.css`) |
| Langage | TypeScript 5.9, mode strict |
| Déploiement | Netlify (`@netlify/vite-plugin-tanstack-start`) |

Aucune base de données : c'est une propriété du produit, pas une limite technique.

## En local

```bash
pnpm install
pnpm dev     # http://localhost:3000
pnpm build   # sortie statique + serveur dans dist/
```

Sur Netlify, `netlify.toml` lance `vite build` et publie `dist/client`.

## Où regarder

```
src/
├── data/       le monde : rôles, gestes, dossiers, profils, vocabulaire
├── lib/        le moteur : graphe causal, état du clavier, réglages, rangée F
├── components/ les pièces : clavier, dossier, mémoire, graphe, carte F3, chrome
└── routes/     trois pages : le clavier, le manifeste, les réglages
```

Le détail des conventions et des décisions non évidentes est dans [AGENTS.md](./AGENTS.md).
