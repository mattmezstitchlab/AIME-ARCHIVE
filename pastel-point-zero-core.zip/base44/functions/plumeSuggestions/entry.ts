import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

// PLUME pioche dans le registre des prestataires selon la date du mariage (dispos),
// et raconte côté humain pourquoi elle les propose aux mariés : métier, style, tarif, négo, humeur.
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const dateJourJ = body.date_jour_j || null; // 'YYYY-MM-DD' optionnel
    const metier = body.metier || null;

    let all = await base44.entities.Prestataire.list('-note_interne', 200);

    // Filtre par disponibilité si une date est fournie.
    if (dateJourJ) {
      all = all.filter((p) => p.statut_dispo !== 'complet' &&
        (!p.disponibilites?.length || p.disponibilites.includes(dateJourJ)));
    }
    if (metier) all = all.filter((p) => p.metier === metier);

    // On garde les meilleurs, PLUME n'en propose pas 40.
    const shortlist = all.slice(0, 8);

    if (!shortlist.length) {
      return Response.json({ intro: "Je n'ai personne de dispo dans mon registre pour cette date. Ajoute des prestataires et je m'en occupe.", suggestions: [] });
    }

    const contexte = shortlist.map((p) => {
      const tarif = p.tarif_min && p.tarif_max ? `${p.tarif_min}–${p.tarif_max} €` : (p.tarif_min ? `dès ${p.tarif_min} €` : 'tarif sur demande');
      return `- ${p.nom} (${p.metier}) : ${p.specialite || ''}. Tarif ${tarif}${p.negociation_possible ? ', négociable' : ''}. Humeur : ${p.humeur}. ${p.bio || ''}`;
    }).join('\n');

    const prompt = `Tu es PLUME, cheffe d'orchestre de mariage — voix féminine chaleureuse, un peu taquine, populaire (esprit Ch'ti). Tu présentes aux mariés une sélection de prestataires que tu connais personnellement. Tu parles d'eux avec le côté humain : leur personnalité, leur style, le feeling, sans oublier le concret (tarif, négo possible). 3 à 5 phrases, parlé naturel, pas de liste. Uniquement le texte que PLUME dit à voix haute.

Mes prestataires dispos${dateJourJ ? ` le ${dateJourJ}` : ''} :
${contexte}`;

    const result = await base44.integrations.Core.InvokeLLM({ prompt });
    const intro = typeof result === 'string' ? result.trim() : String(result).trim();

    return Response.json({ intro, suggestions: shortlist });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});