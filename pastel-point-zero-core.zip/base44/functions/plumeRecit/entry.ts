import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

// PLUME raconte le déroulé du jour J façon cheffe d'orchestre : à partir des vraies infos
// détectées, elle explique ce qu'elle va faire, prestataire par prestataire, moment par moment.
// « Là j'ai l'info du traiteur, donc le jour J je le préviens de… puis à 21h le DJ, t'inquiète pas. »
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const sourceId = body.source_id;

    // Contexte : soit un dépôt précis, soit tout ce qui a été analysé (vue d'ensemble).
    let nodes = [];
    if (sourceId) {
      nodes = await base44.entities.NoeudMemoire.filter({ source_brute_id: sourceId }, '-created_date', 300);
    } else {
      nodes = await base44.entities.NoeudMemoire.list('-created_date', 300);
    }
    nodes = nodes.filter((n) => n.etat_maturation !== 'vide');

    const isMissing = (n) => n.presence_state === 'absent' || n.manque_probable || n.silence_significatif;
    const present = nodes.filter((n) => !isMissing(n));
    const manques = nodes.filter(isMissing);

    const ligne = (n) => `- ${n.titre}${n.contenu_enrichi ? ` (${n.contenu_enrichi})` : ''} [${n.dimension}]`;

    const contexte = [
      present.length ? `INFOS CONFIRMÉES :\n${present.map(ligne).join('\n')}` : 'Presque rien de confirmé pour l\'instant.',
      manques.length ? `\nCE QUI MANQUE ENCORE :\n${manques.map((n) => `- ${n.titre}`).join('\n')}` : '',
    ].filter(Boolean).join('\n');

    const prompt = `Tu es PLUME, la cheffe d'orchestre d'un mariage — voix féminine, chaleureuse, un peu taquine, populaire (esprit Ch'ti). Tu racontes à voix haute, comme si tu rassurais les mariés, tout ce que TU vas gérer le jour J grâce aux infos que tu as. Tu parles au FUTUR et à la première personne : « le jour J, je préviens le traiteur de…, puis à 18h je fais signe au photographe…, le DJ je le briefe pour 21h, vous inquiétez pas ». Tu enchaînes prestataire par prestataire, moment par moment, de façon fluide et vivante.

Pour les trucs qui manquent, tu glisses gentiment que tu les gardes à l'œil (« manque encore le contact du fleuriste, je te le rappellerai »), sans plomber l'ambiance.

Règles : parlé naturel, pas de liste ni de puces, tutoie/vouvoie les mariés naturellement, ton rassurant et complice. 5 à 8 phrases maximum. Uniquement le texte que PLUME dit à voix haute.

Voici ce que le moteur sait aujourd'hui :
${contexte}`;

    const result = await base44.integrations.Core.InvokeLLM({ prompt });
    const recit = typeof result === 'string' ? result.trim() : String(result).trim();

    return Response.json({ recit, source_id: sourceId || null });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});