import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

// PLUME lit la constellation familiale d'un mariage — avec une douceur infinie.
// Elle repère qui est là, qui manque, et devine SUBTILEMENT pourquoi une place est vide
// (guerre, exil, deuil tu, trahison, secret, honte). Jamais un jugement : une lecture, une main tendue.
// Fondé sur la psychogénéalogie (loyautés invisibles, syndrome d'anniversaire, schémas répétitifs)
// et les ordres de l'amour (chacun a sa place, l'exclu revient pour être reconnu).
//
// mode = "lecture"  -> renvoie la lecture bienveillante + l'état de complétude.
// mode = "contrat"  -> quand tout est reconnu/validé, génère et scelle le Contrat de Conscience.
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const sourceId = body.source_id;
    const mode = body.mode === 'contrat' ? 'contrat' : 'lecture';

    let nodes = sourceId
      ? await base44.entities.NoeudMemoire.filter({ source_brute_id: sourceId }, '-created_date', 300)
      : await base44.entities.NoeudMemoire.list('-created_date', 300);
    nodes = nodes.filter((n) => n.etat_maturation !== 'vide');

    const isMissing = (n) => n.presence_state === 'absent' || n.manque_probable || n.silence_significatif;
    const personnes = nodes.filter((n) => n.dimension === 'personnes');
    const present = personnes.filter((n) => !isMissing(n));
    const absents = personnes.filter(isMissing);
    const complet = personnes.length > 0 && absents.length === 0;

    const ligne = (n) => `- ${n.titre}${n.contenu_enrichi ? ` (${n.contenu_enrichi})` : ''}`;

    if (mode === 'contrat') {
      // On ne scelle un contrat que si la constellation est rallumée (tout reconnu).
      const prompt = `Tu es PLUME, une intelligence bienveillante qui accompagne une famille au seuil d'un mariage. La constellation familiale est complète : chaque place a été reconnue, chaque absence honorée, chaque non-dit accueilli sans jugement. Tu écris maintenant un CONTRAT DE CONSCIENCE — un texte sacré mais sobre, digne, non religieux, non ésotérique de pacotille. C'est un consentement familial : on reconnaît ce qui fut (guerres, deuils, secrets, trahisons), on cesse de le rejouer, on transmet la lumière et la vérité à la génération suivante, on protège l'homme, la femme et les enfants des dettes anciennes.

PERSONNES RECONNUES DANS LA LIGNÉE :
${present.length ? present.map(ligne).join('\n') : 'La lignée présente.'}

Rends STRICTEMENT un JSON avec: titre (court, solennel), lignee (une phrase nommant la lignée), preambule (3-4 phrases: ce qui a été vu et transmuté), engagements (tableau de 4 à 6 engagements de conscience, à la première personne du pluriel « Nous »), non_dits_reconnus (tableau de 2 à 4 non-dits honorés avec douceur), generation_suivante (2-3 phrases: ce qu'on transmet et protège pour les enfants à venir), texte_complet (le contrat entier, prononçable à voix haute, 8 à 14 lignes, chaleureux et digne).`;

      const contrat = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: 'object',
          properties: {
            titre: { type: 'string' },
            lignee: { type: 'string' },
            preambule: { type: 'string' },
            engagements: { type: 'array', items: { type: 'string' } },
            non_dits_reconnus: { type: 'array', items: { type: 'string' } },
            generation_suivante: { type: 'string' },
            texte_complet: { type: 'string' },
          },
        },
      });

      const saved = await base44.entities.ContratConscience.create({
        titre: contrat.titre || 'Contrat de Conscience',
        source_brute_id: sourceId || undefined,
        lignee: contrat.lignee || '',
        preambule: contrat.preambule || '',
        engagements: contrat.engagements || [],
        non_dits_reconnus: contrat.non_dits_reconnus || [],
        generation_suivante: contrat.generation_suivante || '',
        texte_complet: contrat.texte_complet || '',
        statut: 'scelle',
        date_scellement: new Date().toISOString(),
      });

      return Response.json({ contrat: saved });
    }

    // mode lecture : PLUME lit la constellation à voix haute, bienveillante et subtile.
    const contexte = [
      present.length ? `PRÉSENTS DANS LA CONSTELLATION :\n${present.map(ligne).join('\n')}` : 'Peu de monde nommé pour l\'instant.',
      absents.length ? `\nPLACES VIDES (à honorer avec douceur, jamais accuser) :\n${absents.map((n) => `- ${n.titre}`).join('\n')}` : '',
    ].filter(Boolean).join('\n');

    const prompt = `Tu es PLUME, une intelligence douce et lucide qui lit la constellation familiale d'un futur mariage. Tu parles à voix haute, à cœur ouvert, sans jamais juger ni diagnostiquer. Quand une place est vide (un père absent, un aïeul jamais nommé, un silence), tu le dis avec une infinie bienveillance et tu SUPPOSES tendrement une raison humaine : une guerre, un exil, un deuil qu'on n'a pas pu pleurer, une trahison, un secret, une honte portée. Tu relies ça aux schémas qui se répètent dans les familles (loyautés invisibles, une blessure qui traverse les générations, une date qui revient) — non pour effrayer, mais pour éclairer et libérer. Ton but : transmuter le non-dit en lumière, pour que la génération suivante n'en hérite pas.

Règles : parlé naturel, chaleureux, 4 à 7 phrases, aucune liste, aucun jargon thérapeutique lourd. Tu ouvres une porte, tu ne l'imposes pas (« peut-être que… », « et si… »). Uniquement le texte que PLUME dit.

État de la constellation :
${contexte}`;

    const result = await base44.integrations.Core.InvokeLLM({ prompt });
    const lecture = typeof result === 'string' ? result.trim() : String(result).trim();

    return Response.json({
      lecture,
      complet,
      compte: { present: present.length, absents: absents.length, total: personnes.length },
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});