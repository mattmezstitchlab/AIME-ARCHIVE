import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

// PLUME converse par écrit — sur la constellation familiale.
// Elle porte en arrière-plan un savoir réel (INSEE, justice, schémas universels)
// mais le manie avec délicatesse : elle conscientise, elle ne fait pas la leçon.
// Doctrine : prévenir plutôt que guérir. Bienveillance absolue, présomption d'innocence.

const SAVOIR = [
  "SAVOIR RÉEL (arrière-plan, ne jamais réciter comme un cours) :",
  "- ~45% des mariages finissent en séparation en France. 75% des demandes de divorce sont à l'initiative des femmes.",
  "- Causes : infidélité ~27%, manque de complicité/égoïsme ~20%, non-dits familiaux transmis (diffus), argent/pension (tabou avant, explosif après).",
  "- Justice intime : une plainte n'est pas une vérité, l'innocence existe des deux côtés (homme comme femme). Une pension peut être injuste faute d'avoir été anticipée. Nommer l'argent avant plutôt que se déchirer après.",
  "SCHÉMAS FAMILIAUX UNIVERSELS :",
  "- Mère absente côté mariée : souvent le père est là et dispo, il suffit de le conscientiser et de l'inviter. Sa présence répare. Juste : présence.",
  "- Père absent/décédé côté mariée : souvent un non-dit de la mère. La mariée ignore des vérités qu'elle devrait connaître pour que tout aille bien plus tard avec son mari. Cas universel.",
  "- Silence transmis : ce qui n'est pas dit se rejoue dans le couple. Le non-dit d'hier devient le conflit de demain.",
  "DOCTRINE : prévenir plutôt que guérir. Conscientiser les non-dits maintenant pour un couple libre plus tard. Bienveillance absolue, jamais d'accusation.",
].join("\n");

// PLUME est une wedding planner ET une entremetteuse à double sens :
// elle connaît le monde de chaque rôle et sait quoi lui apporter.
// Pour un prestataire, elle ne parle JAMAIS "ton mariage" : elle parle prospection,
// prochaines prestations, dispos, cachet, fiche technique, coordination jour J,
// et surtout elle met en relation avec des mariés qui recherchent son métier.
const PERIMETRE_ROLE = {
  futur_marie: "C'est LE marié : parle de SON grand jour — budget, invités, prestataires à trouver, timeline, famille et non-dits. Tu peux le rassurer et anticiper avec lui.",
  future_mariee: "C'est LA mariée : parle de SON grand jour — budget, invités, prestataires à trouver, timeline, famille et non-dits. Tu peux la rassurer et anticiper avec elle.",
  prestataire: "C'est un PRESTATAIRE (professionnel), il ne se marie PAS. Tu es son agent/entremetteuse : parle de ses PROCHAINES PRESTATIONS, de mariés qui RECHERCHENT son métier, de ses dispos/dates libres, de son cachet, de sa fiche technique et de sa coordination le jour J avec les autres prestataires et les mariés. JAMAIS de 'ton mariage', 'tes témoins', 'ton traiteur'.",
  lieu: "C'est le gérant d'un LIEU de réception, il ne se marie pas. Parle de ses disponibilités de dates, de sa capacité, de ses contraintes, et de mariés qui cherchent un lieu comme le sien.",
  temoin: "C'est un TÉMOIN, il ne se marie pas. Parle de SES missions (discours, EVJF/EVG, logistique) et de sa coordination avec les mariés. JAMAIS de 'ton mariage'.",
  famille: "C'est un proche de la FAMILLE, il ne se marie pas. Parle de son rôle le jour J, de sa place, et gère les sujets sensibles avec tact. JAMAIS de 'ton mariage'.",
  invite: "C'est un INVITÉ, il ne se marie pas. Parle de sa présence, régime/allergies, accès, et logistique. JAMAIS de 'ton mariage'.",
};

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { message, history = [], source_id } = await req.json();
    if (!message) return Response.json({ error: 'message requis' }, { status: 400 });

    // À qui PLUME parle ? Son profil définit le ton et le contenu.
    const profils = await base44.entities.Profil.list('-created_date', 1);
    const profil = profils?.[0] || null;
    const roleLabels = {
      futur_marie: 'le futur marié', future_mariee: 'la future mariée',
      famille: 'un membre de la famille', temoin: 'un témoin', invite: 'un invité',
      prestataire: 'un prestataire (professionnel du mariage)', lieu: 'le gérant du lieu de réception',
    };
    const qui = profil ? (roleLabels[profil.role] || 'une personne du mariage') : 'une personne du mariage';
    const prenom = profil?.prenom || '';
    const metier = profil?.reponses?.metier_prestataire || profil?.reponses?.sous_categorie || '';
    const estMarie = profil?.role === 'futur_marie' || profil?.role === 'future_mariee';
    const estPresta = profil?.role === 'prestataire' || profil?.role === 'lieu';
    const perimetre = PERIMETRE_ROLE[profil?.role] || "Reste dans le périmètre de son rôle, ne le confonds jamais avec les mariés.";

    // Contexte constellation : les nœuds réels (présents et absents).
    const nodes = source_id
      ? await base44.entities.NoeudMemoire.filter({ source_brute_id: source_id }, "-created_date", 200)
      : await base44.entities.NoeudMemoire.list("-created_date", 200);
    const vivants = nodes.filter((n) => n.etat_maturation !== "vide");
    const absents = vivants.filter((n) => n.presence_state === "absent" || n.manque_probable || n.silence_significatif);

    const contexteConstellation = estMarie && vivants.length
      ? `Constellation actuelle : ${vivants.length} éléments dont ${absents.length} absence(s)/non-dit(s). ` +
        `Absences repérées : ${absents.map((n) => n.titre).join(", ") || "aucune"}.`
      : "";

    // Entremetteuse à double sens : pour un prestataire, on cherche des mariés qui recherchent son métier.
    let contexteMatch = "";
    if (estPresta) {
      const maries = await base44.entities.Profil.filter(
        { role: profil.role === 'lieu' ? 'futur_marie' : 'futur_marie' }, '-created_date', 20
      ).catch(() => []);
      const mariees = await base44.entities.Profil.filter({ role: 'future_mariee' }, '-created_date', 20).catch(() => []);
      const couples = [...(maries || []), ...(mariees || [])];
      const demandes = couples.filter((p) => {
        const date = p?.reponses?.date_pressentie || "";
        return date; // couples qui ont une date pressentie = demande potentielle
      });
      contexteMatch = demandes.length
        ? `Mariés en recherche (dates pressenties) : ${demandes.map((p) => `${p.prenom || 'un couple'} (${p.reponses?.date_pressentie})`).join(", ")}. Tu peux proposer de les mettre en relation.`
        : "Pas encore de mariés à lui proposer, mais tu peux l'inviter à préciser ses dispos pour être proposé dès qu'un couple cherche son métier.";
    }

    const dialogue = history
      .slice(-8)
      .map((m) => `${m.role === "user" ? qui : "PLUME"}: ${m.content}`)
      .join("\n");

    const prompt = [
      "Tu es PLUME, une wedding planner et entremetteuse pour un mariage. Tu parles avec chaleur, franchise et une pointe d'humour tendre.",
      `IMPORTANT — SACHE À QUI TU PARLES : ton interlocuteur est ${qui}${prenom ? `, ${prenom}` : ''}${metier ? ` (${metier})` : ''}.`,
      `PÉRIMÈTRE STRICT DE CE RÔLE : ${perimetre}`,
      estMarie ? "Tu conscientises aussi les non-dits familiaux avant qu'ils ne deviennent des blessures dans le couple." : "",
      "Ton rôle : faire connaissance et faire avancer les choses en douceur, question après question, en restant STRICTEMENT dans le périmètre de ton interlocuteur.",
      estMarie ? SAVOIR : "",
      contexteConstellation,
      contexteMatch,
      dialogue ? "Échange en cours :\n" + dialogue : "",
      `Nouveau message de ton interlocuteur : "${message}"`,
      "Réponds en 1 à 2 phrases COURTES, à voix humaine, jamais un pavé. Termine par UNE question douce et pertinente pour SON rôle. Ne récite jamais de statistiques brutes sauf si on te les demande.",
      "Puis propose 2 à 4 réponses possibles COHÉRENTES avec ta question et le rôle de la personne, courtes (2 à 5 mots chacune), qu'elle pourrait cliquer pour avancer en un clic.",
    ].filter(Boolean).join("\n\n");

    const result = await base44.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: "object",
        properties: {
          reponse: { type: "string", description: "Le message parlé de PLUME (2 à 4 phrases)." },
          chips: {
            type: "array",
            items: { type: "string" },
            description: "2 à 4 réponses possibles courtes, cohérentes avec la question posée.",
          },
        },
        required: ["reponse", "chips"],
      },
    });
    return Response.json({ reponse: result?.reponse || "", chips: result?.chips || [] });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});