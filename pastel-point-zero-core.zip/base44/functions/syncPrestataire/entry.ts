import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

// Quand un prestataire (ou un lieu) complète son profil, on le rend MATCHABLE :
// on crée/met à jour sa fiche Prestataire à partir de ses réponses d'onboarding.
// C'est ce qui unifie les deux mondes (Profil ↔ Prestataire) pour que l'entremetteuse fonctionne.

// Le questionnaire renvoie un métier "affiché" — on le normalise vers l'enum de l'entité Prestataire.
const METIER_MAP: Record<string, string> = {
  dj: 'dj', traiteur: 'traiteur', photographe: 'photographe', videaste: 'video', 'vidéaste': 'video',
  fleuriste: 'fleuriste', musicien: 'musicien', 'wedding planner': 'wedding_planner', patissier: 'patissier',
  'pâtissier': 'patissier', coiffeur: 'coiffeur', maquilleur: 'maquilleur', decoration: 'decoration',
  'décoration': 'decoration', transport: 'transport', officiant: 'officiant',
};

function normMetier(v?: string) {
  if (!v) return 'autre';
  const key = v.trim().toLowerCase();
  return METIER_MAP[key] || 'autre';
}

// Extrait deux nombres d'une fourchette de tarif texte ("1 200 – 2 500 €").
function parseTarif(txt?: string): { min?: number; max?: number } {
  if (!txt) return {};
  const nums = (txt.match(/\d[\d\s]*/g) || []).map((n) => parseInt(n.replace(/\s/g, ''), 10)).filter((n) => !isNaN(n));
  if (!nums.length) return {};
  return { min: nums[0], max: nums[1] || nums[0] };
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { profil_id } = await req.json();
    const profils = profil_id
      ? [await base44.entities.Profil.get(profil_id)]
      : await base44.entities.Profil.list('-created_date', 1);
    const profil = profils?.[0];
    if (!profil) return Response.json({ error: 'Profil introuvable' }, { status: 404 });
    if (profil.role !== 'prestataire' && profil.role !== 'lieu') {
      return Response.json({ skipped: true, reason: 'not_a_pro' });
    }

    const r = profil.reponses || {};
    const estLieu = profil.role === 'lieu';
    const tarif = parseTarif(r.tarif);

    const fiche: Record<string, unknown> = {
      nom: estLieu ? (r.nom_lieu || profil.prenom || 'Lieu') : (profil.prenom || 'Prestataire'),
      metier: estLieu ? 'lieu' : normMetier(r.metier_prestataire),
      specialite: estLieu ? (r.type_lieu || '') : (r.sous_categorie || ''),
      bio: estLieu ? (r.contraintes || '') : (r.materiel || r.missions || ''),
      ville: r.zone || '',
      code_aime: profil.code_aime,
      profil_id: profil.id,
      verifie: true,
    };
    if (tarif.min != null) fiche.tarif_min = tarif.min;
    if (tarif.max != null) fiche.tarif_max = tarif.max;
    if (r.date_pressentie) fiche.disponibilites = [];

    // Existe déjà pour ce profil ? On met à jour, sinon on crée.
    const existing = await base44.asServiceRole.entities.Prestataire.filter({ profil_id: profil.id }, '-created_date', 1);
    const saved = existing?.[0]
      ? await base44.asServiceRole.entities.Prestataire.update(existing[0].id, fiche)
      : await base44.asServiceRole.entities.Prestataire.create(fiche);

    return Response.json({ prestataire: saved });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});