import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

const dimensions = {
  temps: { color: '#00D4FF', sub: 'Date/Heure' }, espace: { color: '#4ADE80', sub: 'Lieu' }, personnes: { color: '#3B82F6', sub: 'Identité' }, ressources: { color: '#F59E0B', sub: 'Ressource' }, actions: { color: '#10B981', sub: 'Action' }, documents: { color: '#6366F1', sub: 'Document' }, memoire: { color: '#8B5CF6', sub: 'Souvenir' }, communication: { color: '#38BDF8', sub: 'Message' }, economie: { color: '#EAB308', sub: 'Montant' }, emotions: { color: '#EC4899', sub: 'Émotion' }, validation: { color: '#84CC16', sub: 'Décision' }, relations: { color: '#E2E8F0', sub: 'Relation' }
};

// Dépendances classiques entre dimensions — utilisées pour relier les noeuds par logique, pas par proximité.
const dependanceClassique = {
  actions: ['temps', 'personnes', 'ressources', 'validation'],
  economie: ['ressources', 'documents', 'validation'],
  documents: ['validation', 'personnes'],
  communication: ['personnes', 'actions'],
  temps: ['espace', 'personnes'],
  emotions: ['personnes', 'memoire'],
  validation: ['actions', 'documents']
};

function fallbackAnalyze(text) {
  const items = [];
  const add = (fragment, dimension, confidence, reason, meaning) => items.push({ fragment, dimension, confidence, reason, meaning });
  const source = text || '';
  for (const m of source.matchAll(/\b\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4}\b|\b\d{1,2}h\d{0,2}\b/gi)) add(m[0], 'temps', 82, 'Motif temporel explicite détecté.', 'Le fragment semble désigner une date ou une heure.');
  for (const m of source.matchAll(/\b\d+[\s.,]*\d*\s?(€|euro|euros)\b/gi)) add(m[0], 'economie', 86, 'Montant financier explicite détecté.', 'Le fragment semble désigner une valeur monétaire.');
  for (const m of source.matchAll(/\b[A-ZÉÈÀÂÎÔÛ][a-zéèàêçîïôûù]+\s[A-ZÉÈÀÂÎÔÛ][a-zéèàêçîïôûù]+\b/g)) add(m[0], 'personnes', 66, 'Forme probable de nom propre détectée.', 'Le fragment pourrait désigner une personne.');
  if (/\b(contrat|devis|facture|attestation|justificatif|formulaire)\b/i.test(source)) add(source.slice(0, 90), 'documents', 70, 'Terme documentaire explicite détecté.', 'Le passage semble parler d’un document ou d’une preuve.');
  if (/\b(appeler|confirmer|envoyer|relancer|réserver|payer|régler)\b/i.test(source)) add(source.slice(0, 90), 'actions', 70, 'Verbe actionnable détecté, sans créer de tâche mature.', 'Le passage semble contenir une action possible.');
  if (/\b(peur|joie|stress|tension|merci|magique|me manque|émue?|bonheur)\b/i.test(source)) add(source.slice(0, 90), 'emotions', 68, 'Indice émotionnel détecté.', 'Le passage semble exprimer une charge émotionnelle.');
  if (!items.length) add(source.slice(0, 120) || 'Fichier déposé', '', 32, 'Information visible mais signification incertaine.', 'Le système voit une information, mais ne peut pas encore la comprendre clairement — laissée en zone grise.');
  return {
    comprehension_brute: source ? `Le dépôt semble contenir ${items.length} information(s) repérable(s), mais seules les informations suffisamment comprises seront classées.` : 'Un fichier ou contenu a été déposé, mais son sens reste à confirmer.',
    intention_globale: '', oublis_probables: [], incoherences: [], anticipations: [], domaine_detecte: 'autre',
    fragments: items.slice(0, 8)
  };
}

function confidenceValue(value) {
  const raw = Number(value || 0);
  if (!Number.isFinite(raw)) return 0;
  return raw <= 1 ? Math.round(raw * 100) : Math.round(raw);
}

function projectionHints(dimension, domaine) {
  const prefix = domaine && domaine !== 'autre' ? domaine : 'mariage';
  if (dimension === 'actions') return [`${prefix}_checklist`];
  if (dimension === 'temps') return [`${prefix}_timeline`];
  if (dimension === 'economie') return [`${prefix}_budget`];
  if (dimension === 'personnes') return [`${prefix}_prestataires`];
  return [];
}

function asArray(value) {
  if (Array.isArray(value)) return value.filter(Boolean);
  if (typeof value === 'string' && value.trim()) return [value.trim()];
  return [];
}

const importanceValues = ['critique', 'elevee', 'normale', 'faible'];
const presenceValues = ['present', 'absent', 'inconnu', 'suppose', 'a_verifier'];
const natureValues = ['presente', 'absente', 'ambigue', 'attendue', 'critique', 'secondaire', 'actionnable', 'memorielle', 'relationnelle', 'logistique'];
const orchestrationValues = ['individuel', 'groupe', 'evenement', 'territoire', 'collectif'];

// Le vide est une information: transforme les absences détectées en noeuds d'absence (presence_state absent).
function buildAbsenceNodes(source, domaine) {
  const out = [];
  const push = (texte, hypothese, silence) => {
    const t = (texte || '').trim();
    if (!t) return;
    out.push({
      titre: t.slice(0, 70), contenu_enrichi: t, dimension: 'validation', sous_dimension: 'À vérifier', etat_maturation: 'ambigu', couleur_dimension: '#84CC16',
      confiance_ia: 40, raison_classification: 'Absence ou silence repéré dans le dépôt — à confirmer avant toute action.',
      role: 'risque', importance: 'elevee', contexte: 'Information attendue mais non fournie.',
      dependances: [], consequences_possibles: [], risques: [t], besoins: [`Clarifier: ${t}`], anticipations: [], echeance_probable: '',
      nature_information: 'absente', presence_state: 'absent', mission: 'Signaler ce qui devrait exister mais reste absent.',
      manque_probable: true, silence_significatif: Boolean(silence), hypothese_structurelle: hypothese || 'Le moteur suppose un manque, sans certitude.', niveau_orchestration: 'evenement',
      projections_candidates: projectionHints('validation', domaine), projections_possibles: []
    });
  };
  for (const oubli of asArray(source.oublis_probables)) push(oubli, 'Élément fréquemment présent dans ce type de situation, ici manquant.', false);
  for (const silence of asArray(source.silences_significatifs)) push(silence, 'Silence autour d\'un sujet attendu — peut révéler un oubli ou un non-dit.', true);
  return out;
}

// Relie chaque noeud à ses dépendances logiques plutôt qu'au premier noeud venu.
function buildIntelligentLinks(nodes) {
  const links = [];
  const seen = new Set();
  for (const node of nodes) {
    const cibles = dependanceClassique[node.dimension] || [];
    for (const dimCible of cibles) {
      const cible = nodes.find((n) => n.dimension === dimCible && n.id !== node.id);
      if (!cible) continue;
      const key = [node.id, cible.id].sort().join('|');
      if (seen.has(key)) continue;
      seen.add(key);
      links.push({
        noeud_source_id: node.id, noeud_cible_id: cible.id, type_lien: 'depend_de',
        force: Math.min(85, Math.round(((node.confiance_ia || 50) + (cible.confiance_ia || 50)) / 2)),
        direction: 'unidirectionnel', valide_par_humain: false, date_creation: new Date().toISOString()
      });
    }
  }
  // Si aucune dépendance logique, on garde un maillage minimal autour du noeud le plus important.
  if (!links.length && nodes.length > 1) {
    const pivot = nodes.reduce((a, b) => (importanceValues.indexOf(a.importance) <= importanceValues.indexOf(b.importance) ? a : b));
    for (const node of nodes) {
      if (node.id === pivot.id) continue;
      links.push({ noeud_source_id: pivot.id, noeud_cible_id: node.id, type_lien: 'lie', force: 60, direction: 'bidirectionnel', valide_par_humain: false, date_creation: new Date().toISOString() });
    }
  }
  return links;
}

// Observation collective: apprend des structures anonymes, jamais des données privées.
async function observeCollectif(base44, domaine, source, nodes) {
  if (!domaine) return;
  const motifs = [];
  for (const oubli of asArray(source.oublis_probables)) motifs.push({ type_motif: 'oubli_frequent', libelle: oubli, dimension_concernee: '' });
  for (const node of nodes) {
    for (const risque of asArray(node.risques)) motifs.push({ type_motif: 'risque_recurrent', libelle: risque, dimension_concernee: node.dimension });
    for (const besoin of asArray(node.besoins)) motifs.push({ type_motif: 'besoin_frequent', libelle: besoin, dimension_concernee: node.dimension });
  }
  for (const motif of motifs.slice(0, 12)) {
    const libelle = (motif.libelle || '').slice(0, 160);
    if (!libelle) continue;
    const existing = await base44.asServiceRole.entities.MotifCollectif.filter({ domaine, type_motif: motif.type_motif, libelle });
    if (existing.length) {
      const m = existing[0];
      await base44.asServiceRole.entities.MotifCollectif.update(m.id, { occurrences: (m.occurrences || 1) + 1, force: Math.min(100, (m.force || 30) + 8) });
    } else {
      await base44.asServiceRole.entities.MotifCollectif.create({ domaine, type_motif: motif.type_motif, libelle, dimension_concernee: motif.dimension_concernee || '', occurrences: 1, force: 30 });
    }
  }
}

const actionCategories = ['facture', 'devis', 'email', 'rendez_vous', 'document', 'paiement', 'relance', 'reservation', 'contact', 'autre'];
const actionPictos = ['documents', 'economie', 'communication', 'actions', 'temps', 'personnes'];

// Construit un plan d'action heuristique quand le LLM n'a rien préparé (ou en fallback).
function fallbackPlanAction(text) {
  const source = text || '';
  const montant = (source.match(/\b\d+[\s.,]*\d*\s?(€|euro|euros)\b/i) || [])[0] || '';
  if (/\bfacture\b/i.test(source)) {
    return { intitule: montant ? `Créer une facture de ${montant}` : 'Créer une facture', categorie: 'facture', pictogramme: 'documents', demande_detectee: 'Une facture semble demandée.', etapes: ['Créer la facture', 'Compléter les infos manquantes', 'Vérifier les coordonnées client', 'Générer le document', 'Le préparer pour envoi'], infos_extraites: montant ? [`Montant: ${montant}`] : [], infos_manquantes: ['Coordonnées client', 'Numéro de facture'], confiance: 55 };
  }
  if (/\bdevis\b/i.test(source)) {
    return { intitule: 'Préparer un devis', categorie: 'devis', pictogramme: 'documents', demande_detectee: 'Un devis semble demandé.', etapes: ['Créer le devis', 'Compléter les prestations', 'Vérifier les coordonnées client', 'Générer le document', 'Le préparer pour envoi'], infos_extraites: montant ? [`Montant: ${montant}`] : [], infos_manquantes: ['Détail des prestations', 'Coordonnées client'], confiance: 50 };
  }
  return null;
}

function normalizePlanAction(plan, text) {
  let p = plan && typeof plan === 'object' && (plan.intitule || (plan.etapes && plan.etapes.length)) ? plan : null;
  if (!p) p = fallbackPlanAction(text);
  if (!p) return null;
  return {
    intitule: (p.intitule || '').slice(0, 120),
    categorie: actionCategories.includes(p.categorie) ? p.categorie : 'autre',
    pictogramme: actionPictos.includes(p.pictogramme) ? p.pictogramme : 'actions',
    demande_detectee: (p.demande_detectee || '').slice(0, 240),
    etapes: asArray(p.etapes).slice(0, 8),
    infos_extraites: asArray(p.infos_extraites).slice(0, 8),
    infos_manquantes: asArray(p.infos_manquantes).slice(0, 8),
    confiance: confidenceValue(p.confiance || 0)
  };
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const text = body.contenu_texte || '';
    const source = await base44.entities.SourceBrute.create({ contenu_texte: text, fichier_url: body.fichier_url || '', type_source: body.type_source || 'texte', date_depot: new Date().toISOString(), statut_traitement: 'en_attente' });
    let analysis = null;
    let fallbackUsed = false;
    try {
      const prompt = `Tu es le moteur Point Zéro, un chef d'orchestre, pas un classeur.
Règle absolue: comprendre l'ensemble avant de découper. Ne crée jamais de tâche. Ne force pas une dimension si le sens est incertain (laisse en zone grise).

Doctrine: le vide est une information. Une absence peut être une réponse. Un silence peut révéler ce qui manque. Tu ne classes pas seulement ce qui est présent — tu comprends aussi ce qui devrait être là, ce qui manque, ce qui est flou, ce qui est attendu, ce qui est incohérent. Tu ne inventes jamais une vérité: tu proposes des hypothèses prudentes, des pistes, des alertes.

D'abord, lis le dépôt comme un tout et renseigne:
- comprehension_brute: résumé neutre de ce que tu comprends.
- intention_globale: ce que ce dépôt cherche à accomplir.
- domaine_detecte: parmi mariage, entreprise, projet, famille, administration, succession, creation, voyage, formation, autre.
- provenance_detectee: si le dépôt est une capture ou un fichier, devine son origine en observant l'interface ou la mise en forme: sms, email, facture, devis, document_administratif, google_maps, agenda, capture_site, pdf, formulaire, tableau, note, photo, autre. Reconnais une bulle de SMS, un entête d'email, un plan Google Maps, une facture, un agenda. Ne devine jamais sans indice visuel ou textuel clair (sinon: autre).
- oublis_probables: ce qui manque probablement, déduit du contexte (ex: allergies non renseignées, plan B météo absent, prestataire non confirmé, témoin non identifié, personne clé sans mission claire). Jamais inventé arbitrairement.
- silences_significatifs: sujets attendus dans ce type de situation mais totalement absents du dépôt — le silence lui-même est l'information.
- incoherences: contradictions ou tensions internes (ex: traiteur surdimensionné, timing trop serré).
- anticipations: ce qui devra probablement arriver ensuite, proposé sans imposer ("il faudra probablement...").

Ensuite seulement, extrais des fragments. Chaque fragment doit être un élément VIVANT, avec:
- fragment, comprehension_fragment, raison_comprehension
- dimension_suggeree parmi temps, espace, personnes, ressources, actions, documents, memoire, communication, economie, emotions, validation, relations, ou vide si non classé
- sous_dimension, confiance 0-100, zone_grise true/false, raison_classification
- role: rôle dans l'orchestration (information, decision, dependance, declencheur, ressource, contrainte, jalon, risque, validation, intention)
- importance: critique, elevee, normale ou faible
- contexte: ce qui donne du sens à ce noeud dans l'ensemble
- dependances: ce dont il dépend (langage naturel)
- consequences_possibles, risques, besoins, anticipations (listes courtes)
- echeance_probable: indice temporel anticipé si pertinent (texte libre, jamais une promesse)
- nature_information: la nature profonde, parmi presente, absente, ambigue, attendue, critique, secondaire, actionnable, memorielle, relationnelle, logistique
- presence_state: present, absent, inconnu, suppose ou a_verifier
- mission: la raison d'être structurelle de ce noeud dans l'ensemble (sa mission profonde)
- manque_probable: true si ce noeud désigne quelque chose qui devrait être là mais manque
- silence_significatif: true si l'absence/le silence autour de ce sujet est lui-même une information
- hypothese_structurelle: une hypothèse prudente sur sa place dans l'orchestration (jamais une vérité)
- niveau_orchestration: individuel, groupe, evenement, territoire ou collectif
- projections_suggerees: hypothèses inactives uniquement

Enfin, si le dépôt contient une DEMANDE explicite ou implicite (ex: une capture SMS/email "peux-tu m'envoyer une facture pour 500 €?", un devis à valider, un rendez-vous à fixer, un document à produire), prépare un plan_action — une action naturelle prête à être lancée, jamais exécutée d'office:
- intitule: titre court et concret (ex: "Créer une facture de 500 €").
- categorie: facture, devis, email, rendez_vous, document, paiement, relance, reservation, contact, ou autre.
- pictogramme: la dimension la plus représentative (documents pour une facture/un devis/un document, economie pour un paiement/un montant, communication pour un email/relance, temps pour un rendez-vous, personnes pour un contact, actions sinon).
- demande_detectee: la demande reformulée en une phrase claire.
- etapes: les étapes concrètes ordonnées pour préparer l'action (ex pour une facture: créer la facture, compléter les infos manquantes, vérifier les coordonnées client, générer le document, le préparer pour envoi).
- infos_extraites: ce que tu as déjà trouvé dans le dépôt (montant, nom, date, objet...).
- infos_manquantes: ce qu'il faudra compléter avant d'exécuter (coordonnées client, numéro de facture, échéance...).
- confiance: 0-100.
Si le dépôt ne contient aucune demande actionnable, laisse plan_action vide (ne force jamais une action).

Tu cherches la logique de l'ensemble, pas des catégories. Contenu intact: ${text}`;
      analysis = await Promise.race([
        base44.asServiceRole.integrations.Core.InvokeLLM({ prompt, file_urls: body.fichier_url ? [body.fichier_url] : null, response_json_schema: { type: 'object', properties: {
          comprehension_brute: { type: 'string' }, intention_globale: { type: 'string' }, domaine_detecte: { type: 'string' }, provenance_detectee: { type: 'string' },
          oublis_probables: { type: 'array', items: { type: 'string' } }, silences_significatifs: { type: 'array', items: { type: 'string' } }, incoherences: { type: 'array', items: { type: 'string' } }, anticipations: { type: 'array', items: { type: 'string' } },
          plan_action: { type: 'object', properties: {
            intitule: { type: 'string' }, categorie: { type: 'string' }, pictogramme: { type: 'string' }, demande_detectee: { type: 'string' },
            etapes: { type: 'array', items: { type: 'string' } }, infos_extraites: { type: 'array', items: { type: 'string' } }, infos_manquantes: { type: 'array', items: { type: 'string' } }, confiance: { type: 'number' }
          } },
          fragments: { type: 'array', items: { type: 'object', properties: {
            fragment: { type: 'string' }, comprehension_fragment: { type: 'string' }, raison_comprehension: { type: 'string' }, dimension_suggeree: { type: 'string' }, sous_dimension: { type: 'string' }, confiance: { type: 'number' }, zone_grise: { type: 'boolean' }, raison_classification: { type: 'string' },
            role: { type: 'string' }, importance: { type: 'string' }, contexte: { type: 'string' },
            dependances: { type: 'array', items: { type: 'string' } }, consequences_possibles: { type: 'array', items: { type: 'string' } }, risques: { type: 'array', items: { type: 'string' } }, besoins: { type: 'array', items: { type: 'string' } }, anticipations: { type: 'array', items: { type: 'string' } }, echeance_probable: { type: 'string' },
            nature_information: { type: 'string' }, presence_state: { type: 'string' }, mission: { type: 'string' }, manque_probable: { type: 'boolean' }, silence_significatif: { type: 'boolean' }, hypothese_structurelle: { type: 'string' }, niveau_orchestration: { type: 'string' },
            projections_suggerees: { type: 'array', items: { type: 'string' } }
          } } }
        } } }),
        new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), 26000))
      ]);
    } catch (_error) {
      fallbackUsed = true;
      const fallback = fallbackAnalyze(text);
      analysis = { ...fallback, silences_significatifs: [], provenance_detectee: 'autre', fragments: fallback.fragments.map((i) => ({ fragment: i.fragment, comprehension_fragment: i.meaning, raison_comprehension: i.reason, dimension_suggeree: i.dimension, sous_dimension: dimensions[i.dimension]?.sub || '', confiance: i.confidence, zone_grise: !i.dimension || i.confidence < 50, raison_classification: i.dimension ? i.reason : '', role: 'information', importance: 'normale', contexte: '', dependances: [], consequences_possibles: [], risques: [], besoins: [], anticipations: [], echeance_probable: '', nature_information: i.dimension ? 'presente' : 'ambigue', presence_state: 'present', mission: '', manque_probable: false, silence_significatif: false, hypothese_structurelle: '', niveau_orchestration: 'evenement', projections_suggerees: projectionHints(i.dimension) })) };
    }

    const domaine = (analysis.domaine_detecte || 'autre').toLowerCase();
    const comprehensionBrute = analysis.comprehension_brute || 'Compréhension brute non stabilisée.';
    const planAction = normalizePlanAction(analysis.plan_action, text);
    const normalizedFragments = (analysis.fragments || []).map((f) => {
      const dimension = f.dimension_suggeree || f.dimension || '';
      const confiance = confidenceValue(f.confiance || 0);
      const hasDimension = Object.keys(dimensions).includes(dimension);
      const zoneGrise = Boolean(f.zone_grise) || confiance < 50 || !hasDimension;
      const importance = importanceValues.includes(f.importance) ? f.importance : 'normale';
      return {
        fragment: f.fragment || '', comprehension_fragment: f.comprehension_fragment || '', raison_comprehension: f.raison_comprehension || f.raison_classification || '',
        dimension_suggeree: hasDimension ? dimension : '', sous_dimension: f.sous_dimension || '', confiance, zone_grise: zoneGrise,
        raison_classification: hasDimension ? (f.raison_classification || f.raison_comprehension || '') : '',
        role: f.role || 'information', importance, contexte: f.contexte || '',
        dependances: asArray(f.dependances), consequences_possibles: asArray(f.consequences_possibles), risques: asArray(f.risques), besoins: asArray(f.besoins), anticipations: asArray(f.anticipations), echeance_probable: f.echeance_probable || '',
        nature_information: natureValues.includes(f.nature_information) ? f.nature_information : (hasDimension ? 'presente' : 'ambigue'),
        presence_state: presenceValues.includes(f.presence_state) ? f.presence_state : 'present',
        mission: f.mission || '', manque_probable: Boolean(f.manque_probable), silence_significatif: Boolean(f.silence_significatif),
        hypothese_structurelle: f.hypothese_structurelle || '', niveau_orchestration: orchestrationValues.includes(f.niveau_orchestration) ? f.niveau_orchestration : 'evenement',
        projections_suggerees: Array.isArray(f.projections_suggerees) ? f.projections_suggerees : projectionHints(dimension, domaine)
      };
    }).filter((f) => f.fragment);

    const raisonsComprehension = normalizedFragments.map((f) => f.raison_comprehension).filter(Boolean);
    const zonesGrises = normalizedFragments.filter((f) => f.zone_grise).map((f) => f.fragment);
    const sourceComprise = await base44.entities.SourceBrute.update(source.id, {
      comprehension_brute: comprehensionBrute, raisons_comprehension: raisonsComprehension, zones_grises: zonesGrises, statut_traitement: 'compris',
      intention_globale: analysis.intention_globale || '', oublis_probables: asArray(analysis.oublis_probables), silences_significatifs: asArray(analysis.silences_significatifs), incoherences: asArray(analysis.incoherences), anticipations: asArray(analysis.anticipations), domaine_detecte: domaine, provenance_detectee: analysis.provenance_detectee || 'autre',
      ...(planAction ? { plan_action: planAction } : {})
    });

    const fragmentsData = normalizedFragments.map((f) => ({ source_brute_id: source.id, contenu_fragment: f.fragment, comprehension_fragment: f.comprehension_fragment, dimension_suggeree: f.dimension_suggeree, sous_dimension_suggeree: f.sous_dimension, raison_comprehension: f.raison_comprehension, raison_classification: f.raison_classification, confiance: f.confiance, statut: f.zone_grise ? 'ambigu' : f.dimension_suggeree ? 'suggestion' : 'non_classe', zone_grise: f.zone_grise, nouvelle_categorie_proposee: !f.dimension_suggeree ? 'À comprendre avant classement' : '', projections_suggerees: f.projections_suggerees }));
    const fragments = fragmentsData.length ? await base44.entities.FragmentDetecte.bulkCreate(fragmentsData) : [];

    const nodes = [];
    for (let index = 0; index < fragments.length; index += 1) {
      const fragment = fragments[index];
      const original = normalizedFragments[index];
      const canBecomeNode = Boolean(sourceComprise.comprehension_brute && fragment.contenu_fragment && fragment.raison_comprehension && fragment.confiance >= 50 && fragment.dimension_suggeree && !fragment.zone_grise);
      if (!canBecomeNode) continue;
      const node = await base44.entities.NoeudMemoire.create({
        titre: fragment.contenu_fragment.slice(0, 70), contenu_enrichi: fragment.comprehension_fragment || fragment.contenu_fragment, dimension: fragment.dimension_suggeree, sous_dimension: fragment.sous_dimension_suggeree, etat_maturation: 'detecte', couleur_dimension: dimensions[fragment.dimension_suggeree]?.color || '#F97316', source_brute_id: source.id, fragment_detecte_id: fragment.id, confiance_ia: fragment.confiance, comprehension_brute: sourceComprise.comprehension_brute, raison_classification: fragment.raison_classification || fragment.raison_comprehension, tags: [fragment.dimension_suggeree], date_creation: new Date().toISOString(), projections_candidates: original.projections_suggerees || [], projections_possibles: [],
        role: original.role, importance: original.importance, contexte: original.contexte, dependances: original.dependances, consequences_possibles: original.consequences_possibles, risques: original.risques, besoins: original.besoins, anticipations: original.anticipations, echeance_probable: original.echeance_probable,
        nature_information: original.nature_information, presence_state: original.presence_state, mission: original.mission, manque_probable: original.manque_probable, silence_significatif: original.silence_significatif, hypothese_structurelle: original.hypothese_structurelle, niveau_orchestration: original.niveau_orchestration
      });
      await base44.entities.FragmentDetecte.update(fragment.id, { noeud_cree_id: node.id, statut: 'compris' });
      nodes.push(node);
    }

    // Le vide est une information: les absences et silences deviennent des noeuds d'absence, sans bloquer le dépôt.
    const absenceData = buildAbsenceNodes(sourceComprise, domaine).map((a) => ({ ...a, source_brute_id: source.id, date_creation: new Date().toISOString(), tags: ['absence', a.dimension], comprehension_brute: sourceComprise.comprehension_brute }));
    const absenceNodes = absenceData.length ? await base44.entities.NoeudMemoire.bulkCreate(absenceData) : [];
    nodes.push(...absenceNodes);

    const linksData = buildIntelligentLinks(nodes);
    const links = linksData.length ? await base44.entities.LienMemoire.bulkCreate(linksData) : [];

    // Couche Observation collective — apprend des structures anonymes en arrière-plan.
    try { await observeCollectif(base44, domaine, sourceComprise, nodes); } catch (_e) { /* l'observation ne doit jamais bloquer le dépôt */ }

    await base44.entities.SourceBrute.update(source.id, { statut_traitement: 'traite' });
    return Response.json({ source: sourceComprise, comprehension_brute: comprehensionBrute, fragments, nodes, links, zones_grises: zonesGrises, fallback_used: fallbackUsed });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});