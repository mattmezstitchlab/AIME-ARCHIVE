import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

// Génère la voix de PLUME via ElevenLabs et renvoie le MP3 directement.
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { text } = await req.json();
    if (!text) return Response.json({ error: 'Texte manquant' }, { status: 400 });

    const apiKey = Deno.env.get("ELEVENLABS_API_KEY");
    const voiceId = Deno.env.get("ELEVENLABS_VOICE_ID");
    if (!apiKey || !voiceId) return Response.json({ error: 'Configuration ElevenLabs manquante' }, { status: 500 });

    const res = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`, {
      method: "POST",
      headers: { "xi-api-key": apiKey, "Content-Type": "application/json", "Accept": "audio/mpeg" },
      body: JSON.stringify({
        text,
        model_id: "eleven_multilingual_v2",
        voice_settings: { stability: 0.4, similarity_boost: 0.8, style: 0.5, use_speaker_boost: true },
      }),
    });

    if (!res.ok) {
      const detail = await res.text();
      return Response.json({ error: 'ElevenLabs error', detail }, { status: res.status });
    }

    const audio = await res.arrayBuffer();
    return new Response(audio, { status: 200, headers: { "Content-Type": "audio/mpeg" } });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});