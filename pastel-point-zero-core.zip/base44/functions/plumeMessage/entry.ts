import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

// PLUME commente un dépôt réel : à partir de la compréhension + des manques détectés,
// elle écrit un petit message taquin, populaire et cash (esprit Ch'ti), à dire à voix haute.
// Le périmètre de chaque rôle : PLUME est wedding planner ET entremetteuse.
// Un prestataire ne se marie pas → on lui parle de ses prestations et de mariés qui le cherchent.
const PERIMETRE_ROLE = {
  futur_marie: "C'est LE marié : commente SON grand jour (prestataires à trouver, timeline, budget).",
  future_mariee: "C'est LA mariée : commente SON grand jour (prestataires à trouver, timeline, budget).",
  prestataire: "C'est un PRESTATAIRE (pro), il ne se marie PAS. Parle de ses prochaines prestations, de mariés qui recherchent son métier, de ses dispos, sa fiche technique, sa coordination jour J. JAMAIS 'ton mariage'/'tes témoins'.",
  lieu: "C'est le gérant d'un LIEU, il ne se marie pas. Parle de ses dispos de dates, sa capacité, ses contraintes, et de mariés qui cherchent un lieu.",
  temoin: "C'est un TÉMOIN, il ne se marie pas. Parle de SES missions (discours, EVJF/EVG) et de sa coordination avec les mariés.",
  famille: "C'est un proche de la FAMILLE. Parle de son rôle le jour J, avec tact.",
  invite: "C'est un INVITÉ. Parle de sa présence, régime, accès, logistique.",
};

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const sourceId = body.source_id;

    // Qui parle ? On récupère son profil (rôle + réponses) pour adapter le ton.
    const profils = await base44.entities.Profil.list('-created_date', 1);
    const profil = profils?.[0] || null;
    const roleLabels = {
      futur_marie: 'le futur marié', future_mariee: 'la future mariée',
      famille: 'un membre de la famille', temoin: 'un témoin', invite: 'un invité',
      prestataire: 'un prestataire (professionnel du mariage)', lieu: 'le gérant du lieu de réception',
    };
    const qui = profil ? (roleLabels[profil.role] || 'une personne du mariage') : 'une personne du mariage';
    const metier = profil?.reponses?.metier_prestataire || profil?.reponses?.sous_categorie || '';
    const prenom = profil?.prenom || '';
    const perimetre = PERIMETRE_ROLE[profil?.role] || "Ne le confonds jamais avec les mariés, reste dans son rôle.";
    const estPresta = profil?.role === 'prestataire' || profil?.role === 'lieu';

    // Un prestataire ne se marie pas : on ne commente PAS un dépôt de couple.
    // PLUME l'accueille sur SON activité (prestations, dispos, mariés qui le cherchent).
    if (estPresta) {
      const prompt = `Tu es PLUME, une wedding planner et entremetteuse, voix féminine taquine et chaleureuse (esprit Ch'ti). Tu accueilles un PROFESSIONNEL du mariage, il ne se marie PAS.
PÉRIMÈTRE STRICT : ${perimetre}
Il s'appelle ${prenom || 'ce pro'}${metier ? ` (${metier})` : ''}. Écris UN court message d'accueil (max 2 phrases, parlé, tutoiement) qui lui parle de SON activité : ses prochaines prestations, ses dispos, ou des mariés qui pourraient le chercher. JAMAIS 'ton mariage'.
Écris uniquement le message que PLUME dit à voix haute.`;
      const r = await base44.integrations.Core.InvokeLLM({ prompt });
      const msg = (typeof r === 'string' ? r : String(r)).trim();
      return Response.json({ message: msg, source_id: null });
    }

    // On récupère le contexte réel : soit une source précise, soit la dernière analysée.
    let source = null;
    if (sourceId) {
      source = await base44.entities.SourceBrute.get(sourceId);
    } else {
      const recent = await base44.entities.SourceBrute.list('-created_date', 1);
      source = recent?.[0] || null;
    }
    if (!source) return Response.json({ error: 'Aucun dépôt à commenter' }, { status: 404 });

    // Les nœuds d'absence = ce qui manque vraiment (le coeur du ton de PLUME).
    const nodes = await base44.entities.NoeudMemoire.filter({ source_brute_id: source.id }, '-created_date', 200);
    const manques = nodes
      .filter((n) => n.presence_state === 'absent' || n.manque_probable || n.silence_significatif)
      .map((n) => n.titre)
      .filter(Boolean);

    const contexte = [
      `Compréhension du dépôt : ${source.comprehension_brute || 'rien de clair'}`,
      source.oublis_probables?.length ? `Oublis probables : ${source.oublis_probables.join(', ')}` : '',
      source.silences_significatifs?.length ? `Silences révélateurs : ${source.silences_significatifs.join(', ')}` : '',
      manques.length ? `Ce qui manque : ${manques.join(', ')}` : '',
      source.anticipations?.length ? `À anticiper : ${source.anticipations.join(', ')}` : '',
    ].filter(Boolean).join('\n');

    const prompt = `Tu es PLUME, une voix féminine taquine, populaire et un peu cash, dans l'esprit Ch'ti chaleureux. Tu commentes ce que quelqu'un vient de déposer dans son organisateur. Tu pointes gentiment les oublis et les trucs pas confirmés, avec humour et tendresse, jamais méchant. Maximum 3 phrases courtes, parlé, naturel, pas de liste. Tutoie la personne.

IMPORTANT — SACHE À QUI TU PARLES : tu t'adresses à ${qui}${prenom ? `, ${prenom}` : ''}${metier ? ` (${metier})` : ''}.
PÉRIMÈTRE STRICT : ${perimetre}

Voici ce que le moteur a compris :
${contexte}

Écris uniquement le message que PLUME dit à voix haute.`;

    const result = await base44.integrations.Core.InvokeLLM({ prompt });
    const message = typeof result === 'string' ? result.trim() : String(result).trim();

    return Response.json({ message, source_id: source.id });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});