import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

// L'entremetteuse à double sens, côté DONNÉES (l'écran de matching s'appuie dessus).
// - Marié : on lui remonte les prestataires du registre, avec le côté humain.
// - Prestataire/lieu : on lui remonte les couples qui ont une date pressentie (= demande).

const METIER_LABEL: Record<string, string> = {
  traiteur: 'Traiteur', photographe: 'Photographe', dj: 'DJ', musicien: 'Musicien', fleuriste: 'Fleuriste',
  lieu: 'Lieu', wedding_planner: 'Wedding planner', patissier: 'Pâtissier', coiffeur: 'Coiffeur',
  maquilleur: 'Maquilleur', video: 'Vidéaste', decoration: 'Décoration', transport: 'Transport',
  officiant: 'Officiant', autre: 'Prestataire',
};

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const profils = await base44.entities.Profil.list('-created_date', 1);
    const profil = profils?.[0] || null;
    const role = profil?.role || 'futur_marie';
    const estPresta = role === 'prestataire' || role === 'lieu';

    if (estPresta) {
      // Côté PRO : les couples qui cherchent (date pressentie renseignée).
      const maries = await base44.asServiceRole.entities.Profil.filter({ role: 'futur_marie' }, '-created_date', 50).catch(() => []);
      const mariees = await base44.asServiceRole.entities.Profil.filter({ role: 'future_mariee' }, '-created_date', 50).catch(() => []);
      const couples = [...(maries || []), ...(mariees || [])]
        .filter((p) => p?.reponses?.date_pressentie)
        .map((p) => ({
          id: p.id,
          prenom: p.prenom || 'Un couple',
          date: p.reponses?.date_pressentie || '',
          lieu: p.reponses?.lieu_reve || '',
          budget: p.reponses?.budget || '',
          ambiance: p.reponses?.ambiance || '',
        }));
      return Response.json({ role, view: 'demandes', items: couples });
    }

    // Côté MARIÉ : le registre des prestataires vérifiés.
    const prestas = await base44.asServiceRole.entities.Prestataire.list('-created_date', 100);
    const items = (prestas || []).map((p) => ({
      id: p.id,
      nom: p.nom,
      metier: p.metier,
      metier_label: METIER_LABEL[p.metier] || 'Prestataire',
      specialite: p.specialite || '',
      bio: p.bio || '',
      ville: p.ville || '',
      photo_url: p.photo_url || '',
      extrait_audio_url: p.extrait_audio_url || '',
      statut_dispo: p.statut_dispo || 'disponible',
      humeur: p.humeur || 'posee',
      tarif_min: p.tarif_min,
      tarif_max: p.tarif_max,
      code_aime: p.code_aime || '',
    }));
    return Response.json({ role, view: 'prestataires', items });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});