import React from "react";
import { base44 } from "@/api/base44Client";
import { generateUniqueCode } from "@/lib/profil/code";
import OnboardingChat from "./OnboardingChat";

// Onboarding Point Zéro — désormais entièrement conversationnel, dans la fenêtre de discussion.
// PLUME demande le rôle (chips), fait signer la charte + génère le code AIME, puis pose le questionnaire.
export default function Onboarding({ profil, onDone }) {
  const startStep = profil && profil.charte_signee ? "questions" : "role";

  // Signature charte → crée/complète le profil avec le code AIME.
  const handleSign = async (role, prenom) => {
    const code = profil?.code_aime || (await generateUniqueCode());
    const data = {
      code_aime: code,
      prenom,
      role,
      charte_signee: true,
      date_charte: new Date().toISOString(),
    };
    return profil?.id
      ? await base44.entities.Profil.update(profil.id, data)
      : await base44.entities.Profil.create(data);
  };

  // Fin du questionnaire → profil complet.
  const handleComplete = async (answers) => {
    const extra = {};
    if (answers.metier_prestataire) extra.metier_prestataire = answers.metier_prestataire;
    if (answers.sous_categorie) extra.sous_categorie = answers.sous_categorie;
    // On récupère l'id du profil déjà créé lors de la signature (dernière fiche de la personne).
    const mine = await base44.entities.Profil.list("-created_date", 1);
    const target = mine?.[0];
    if (!target) return;
    const saved = await base44.entities.Profil.update(target.id, {
      reponses: answers,
      profil_complet: true,
      ...extra,
    });
    // Prestataire ou lieu → on le rend matchable dans le registre (entremetteuse).
    if (saved.role === "prestataire" || saved.role === "lieu") {
      await base44.functions.invoke("syncPrestataire", { profil_id: saved.id }).catch(() => {});
    }
    onDone(saved);
  };

  return (
    <OnboardingChatWrapper
      startStep={startStep}
      role={profil?.role || null}
      code={profil?.code_aime || null}
      onSign={handleSign}
      onComplete={handleComplete}
    />
  );
}

// Petit wrapper qui porte l'état "submitting" et relaie au chat.
function OnboardingChatWrapper(props) {
  const [submitting, setSubmitting] = React.useState(false);

  const onSign = async (role, prenom) => {
    setSubmitting(true);
    try {
      return await props.onSign(role, prenom);
    } finally {
      setSubmitting(false);
    }
  };

  const onComplete = async (answers) => {
    setSubmitting(true);
    try {
      await props.onComplete(answers);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <OnboardingChat
      startStep={props.startStep}
      role={props.role}
      code={props.code}
      onSign={onSign}
      onComplete={onComplete}
      submitting={submitting}
    />
  );
}