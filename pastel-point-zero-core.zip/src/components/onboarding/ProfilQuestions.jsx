import React, { useState } from "react";
import { Loader2 } from "lucide-react";
import { questionsFor, roleOf } from "@/lib/profil/roles";

// Étape 3 : le questionnaire ciblé du rôle. Les réponses nourrissent la mémoire persistante
// du profil, pour que PLUME sache tout ce qu'il faut sur chacun et optimise l'organisation.
export default function ProfilQuestions({ role, code, onComplete, submitting }) {
  const [answers, setAnswers] = useState({});
  const questions = questionsFor(role);
  const r = roleOf(role);
  const set = (id, v) => setAnswers((a) => ({ ...a, [id]: v }));

  return (
    <div className="w-full max-w-lg">
      <div className="text-center">
        <span className="rounded-full bg-white/10 px-3 py-1 font-mono text-[12px] text-white/70 ring-1 ring-white/15">{code}</span>
        <h1 className="mt-3 text-xl font-semibold tracking-tight text-white">Faisons connaissance, {r?.label}</h1>
        <p className="mt-1 text-[13px] text-white/50">Chaque détail aide PLUME à mieux orchestrer.</p>
      </div>

      <div className="mt-6 space-y-4">
        {questions.map((q) => (
          <div key={q.id}>
            <label className="mb-1.5 block text-[13px] font-medium text-white/85">{q.label}</label>
            {q.type === "textarea" ? (
              <textarea
                rows={2}
                value={answers[q.id] || ""}
                onChange={(e) => set(q.id, e.target.value)}
                placeholder={q.placeholder}
                className="w-full rounded-2xl bg-white/10 px-4 py-2.5 text-sm text-white placeholder:text-white/40 ring-1 ring-white/15 outline-none focus:ring-white/40"
              />
            ) : q.type === "select" ? (
              <div className="flex flex-wrap gap-2">
                {q.options.map((opt) => (
                  <button
                    key={opt}
                    onClick={() => set(q.id, opt)}
                    className={`rounded-full px-3.5 py-1.5 text-[12.5px] font-medium ring-1 transition-all ${
                      answers[q.id] === opt ? "bg-white text-black ring-white" : "bg-white/10 text-white/80 ring-white/15 hover:ring-white/40"
                    }`}
                  >
                    {opt}
                  </button>
                ))}
              </div>
            ) : (
              <input
                value={answers[q.id] || ""}
                onChange={(e) => set(q.id, e.target.value)}
                placeholder={q.placeholder}
                className="w-full rounded-full bg-white/10 px-4 py-2.5 text-sm text-white placeholder:text-white/40 ring-1 ring-white/15 outline-none focus:ring-white/40"
              />
            )}
          </div>
        ))}
      </div>

      <button
        onClick={() => onComplete(answers)}
        disabled={submitting}
        className="mt-6 flex w-full items-center justify-center gap-2 rounded-full bg-white py-3 text-sm font-semibold text-black transition-all hover:bg-white/90 disabled:bg-white/15 disabled:text-white/40"
      >
        {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : "C'est parti — je discute avec PLUME"}
      </button>
      <button
        onClick={() => onComplete({})}
        disabled={submitting}
        className="mt-2 w-full text-center text-[12px] text-white/40 hover:text-white/70"
      >
        Passer pour l'instant
      </button>
    </div>
  );
}