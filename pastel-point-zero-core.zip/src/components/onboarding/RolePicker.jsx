import React from "react";
import { ROLES } from "@/lib/profil/roles";

// Étape 1 : chacun choisit son rôle. C'est ce qui détermine ce que PLUME va lui demander.
export default function RolePicker({ onSelect }) {
  return (
    <div className="w-full max-w-lg">
      <h1 className="text-center text-2xl font-semibold tracking-tight text-white">Qui es-tu dans ce mariage ?</h1>
      <p className="mt-2 text-center text-[13px] text-white/50">
        Ton rôle guide les questions de PLUME. Choisis, et on fait connaissance.
      </p>
      <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3">
        {ROLES.map((r) => (
          <button
            key={r.key}
            onClick={() => onSelect(r.key)}
            className="group flex flex-col items-center gap-1.5 rounded-3xl bg-white/5 p-4 text-center ring-1 ring-white/10 backdrop-blur-md transition-all hover:bg-white/10 hover:ring-white/30"
          >
            <span className="text-3xl">{r.icon}</span>
            <span className="text-[13.5px] font-medium text-white">{r.label}</span>
            <span className="text-[11px] leading-snug text-white/45">{r.desc}</span>
          </button>
        ))}
      </div>
    </div>
  );
}