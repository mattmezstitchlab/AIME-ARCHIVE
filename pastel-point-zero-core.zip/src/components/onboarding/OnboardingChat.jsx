import React, { useEffect, useRef, useState } from "react";
import { Send, Loader2, Plus } from "lucide-react";
import { ROLES, questionsFor, roleOf } from "@/lib/profil/roles";

// Onboarding conversationnel : tout se passe DANS la fenêtre de discussion, comme PlumeChat.
// PLUME accueille → demande le rôle (chips) → fait signer la charte (chip d'accord + prénom)
// → pose le questionnaire ciblé question après question. Aucun gros écran plein.
//
// Props :
//   onSign(role, prenom)          → crée le profil + code AIME, renvoie le profil sauvegardé
//   onComplete(answers)           → complète le profil avec les réponses
//   submitting                    → verrou pendant les écritures
//   startStep ("role"|"questions"), role, code → reprise si profil partiel
export default function OnboardingChat({ onSign, onComplete, submitting, startStep = "role", role: initialRole = null, code = null }) {
  const [messages, setMessages] = useState([]);
  const [chips, setChips] = useState([]);
  const [input, setInput] = useState("");
  const [phase, setPhase] = useState(startStep); // role | prenom | charte | questions
  const [role, setRole] = useState(initialRole);
  const [qIndex, setQIndex] = useState(0);
  const [answers, setAnswers] = useState({});
  const endRef = useRef(null);

  const questions = role ? questionsFor(role) : [];
  const currentQ = questions[qIndex];

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, chips]);

  // Amorce selon l'étape d'entrée.
  useEffect(() => {
    if (startStep === "questions" && initialRole) {
      setMessages([{ role: "plume", content: `Ton code : ${code}. On continue à faire connaissance — quelques questions et c'est bon.` }]);
      askQuestion(0, initialRole);
    } else {
      setMessages([{ role: "plume", content: "Commençons par vous : qui êtes-vous, quel rôle jouez-vous, quelle histoire voulez-vous faire sentir ?" }]);
      setChips(ROLES.map((r) => r.label));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const pushPlume = (content, newChips = []) => {
    setMessages((m) => [...m, { role: "plume", content }]);
    setChips(newChips);
  };
  const pushUser = (content) => setMessages((m) => [...m, { role: "user", content }]);

  const askQuestion = (idx, r = role) => {
    const qs = questionsFor(r);
    const q = qs[idx];
    if (!q) return;
    const chipOpts = q.type === "select" ? q.options : [];
    setTimeout(() => pushPlume(q.label, chipOpts), 150);
  };

  // Sélection d'un rôle (via chip ou texte libre — on cherche le rôle correspondant).
  const handleRole = (label) => {
    const low = label.toLowerCase();
    const r =
      ROLES.find((x) => label.includes(x.label)) ||
      ROLES.find((x) => low.includes(x.label.toLowerCase())) ||
      ROLES.find((x) => low.includes(x.key));
    if (!r) {
      pushUser(label);
      setTimeout(() => pushPlume("Je n'ai pas reconnu ce rôle — choisis ci-dessous.", ROLES.map((x) => x.label)), 150);
      return;
    }
    pushUser(label);
    setRole(r.key);
    setChips([]);
    setPhase("prenom");
    setTimeout(() => pushPlume("Enchantée. Ton prénom ?"), 150);
  };

  // Réception du prénom → charte.
  const handlePrenom = (prenom) => {
    pushUser(prenom);
    setPhase("charte");
    setTimeout(
      () =>
        pushPlume(
          "Avant tout : je garde tes infos en mémoire, rien que pour t'aider à orchestrer ce mariage. On y va ?",
          ["J'accepte, on y va"]
        ),
      150
    );
    // Mémorise le prénom pour la signature.
    setAnswers((a) => ({ ...a, _prenom: prenom }));
  };

  // Signature de la charte.
  const handleCharte = async () => {
    pushUser("J'accepte");
    setChips([]);
    const saved = await onSign(role, answers._prenom || "");
    if (saved) {
      setPhase("questions");
      setQIndex(0);
      pushPlume(`C'est scellé. Ton code d'identité : ${saved.code_aime}.`);
      askQuestion(0);
    }
  };

  // Réponse à une question du questionnaire.
  const handleAnswer = async (value) => {
    pushUser(value);
    setChips([]);
    const next = { ...answers, [currentQ.id]: value };
    setAnswers(next);
    const nextIdx = qIndex + 1;
    if (nextIdx < questions.length) {
      setQIndex(nextIdx);
      askQuestion(nextIdx);
    } else {
      pushPlume("Parfait, je te connais mieux maintenant. On peut commencer.");
      const clean = { ...next };
      delete clean._prenom;
      await onComplete(clean);
    }
  };

  // Routage d'une saisie/chip vers la bonne étape.
  const handleValue = (value) => {
    const v = (value || "").trim();
    if (!v || submitting) return;
    setInput("");
    if (phase === "role") return handleRole(v);
    if (phase === "prenom") return handlePrenom(v);
    if (phase === "charte") return handleCharte();
    if (phase === "questions") return handleAnswer(v);
  };

  const submit = (e) => {
    e.preventDefault();
    handleValue(input);
  };

  // Skip d'une question facultative (texte laissé vide).
  const canSkip = phase === "questions";

  const lastPlume = [...messages].reverse().find((m) => m.role === "plume");

  return (
    <div className="w-full rounded-3xl bg-black/45 p-4 ring-1 ring-white/10 backdrop-blur-xl">
      {/* En-tête PLUME */}
      <div className="mb-2 flex items-center gap-1.5 text-white/70">
        <span className="text-[13px]">✦</span>
        <span className="text-[11px] font-semibold tracking-[0.18em]">PLUME</span>
      </div>

      {/* Dernier message de PLUME (ou état d'inscription) */}
      <p className="mb-3 text-[13.5px] leading-snug text-white/90">
        {submitting ? "PLUME t'inscrit…" : lastPlume?.content}
      </p>

      {/* Champ de discussion avec + à gauche */}
      <form onSubmit={submit} className="flex items-center gap-1 rounded-full bg-white/5 px-2 py-1 ring-1 ring-white/10">
        <span className="flex h-8 w-8 items-center justify-center text-white/40">
          <Plus className="h-4 w-4" />
        </span>
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder={
            phase === "role"
              ? "Qui êtes-vous ? Rôle, style, histoire…"
              : phase === "charte"
              ? "Tape « ok » pour accepter…"
              : phase === "prenom"
              ? "Ton prénom…"
              : "Ta réponse…"
          }
          className="flex-1 bg-transparent py-1.5 text-[13px] text-white placeholder:text-white/40 outline-none"
        />
        {canSkip && (
          <button
            type="button"
            onClick={() => handleAnswer("—")}
            className="shrink-0 px-2 text-[11px] font-medium text-white/50 transition-colors hover:text-white"
          >
            Passer
          </button>
        )}
        <button
          type="submit"
          disabled={submitting || !input.trim()}
          aria-label="Envoyer"
          className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-white/50 transition-colors hover:text-white disabled:text-white/25"
        >
          {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
        </button>
      </form>

      {/* Rôles / options — texte simple, centré, sans picto */}
      {chips.length > 0 && !submitting && (
        <div className="mt-3 flex flex-wrap items-center justify-center gap-x-5 gap-y-2">
          {chips.map((c, i) => (
            <button
              key={i}
              onClick={() => handleValue(c)}
              className="text-[13px] font-medium text-white/70 transition-colors hover:text-white"
            >
              {c}
            </button>
          ))}
        </div>
      )}

      <div ref={endRef} />
    </div>
  );
}