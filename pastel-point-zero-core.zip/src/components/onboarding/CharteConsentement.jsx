import React, { useState } from "react";
import { Loader2, ShieldCheck } from "lucide-react";
import { roleOf } from "@/lib/profil/roles";

// Étape 2 : la charte de consentement. On coche, on signe (prénom), et on reçoit
// son code d'identité unique AIME-XXX-XXX. Le code n'est délivré qu'après signature.
export default function CharteConsentement({ role, onSign, submitting }) {
  const [prenom, setPrenom] = useState("");
  const [accepte, setAccepte] = useState(false);
  const r = roleOf(role);

  return (
    <div className="w-full max-w-md">
      <div className="mb-4 flex items-center justify-center gap-2 text-white">
        <ShieldCheck className="h-5 w-5 text-primary" />
        <h1 className="text-xl font-semibold tracking-tight">Charte de consentement</h1>
      </div>

      <div className="max-h-[38vh] overflow-y-auto rounded-3xl bg-white/5 p-5 text-[13px] leading-relaxed text-white/70 ring-1 ring-white/10 backdrop-blur-md">
        <p>En rejoignant Point Zéro en tant que <b className="text-white">{r?.label}</b>, tu acceptes que :</p>
        <ul className="mt-3 space-y-2 list-disc pl-4">
          <li>tes réponses sont conservées en mémoire pour préparer le mariage et rien d'autre ;</li>
          <li>PLUME s'engage à la bienveillance, à la présomption d'innocence et à la confidentialité des sujets sensibles ;</li>
          <li>tu peux modifier ou retirer tes informations à tout moment ;</li>
          <li>un code d'identité unique <span className="font-mono text-white">AIME-XXX-XXX</span> te sera remis : il est personnel, garde-le.</li>
        </ul>
      </div>

      <input
        value={prenom}
        onChange={(e) => setPrenom(e.target.value)}
        placeholder="Ton prénom (signature)"
        className="mt-4 w-full rounded-full bg-white/10 px-5 py-3 text-sm text-white placeholder:text-white/40 ring-1 ring-white/15 outline-none transition-all focus:ring-white/40"
      />

      <label className="mt-3 flex cursor-pointer items-start gap-2.5 text-[13px] text-white/80">
        <input
          type="checkbox"
          checked={accepte}
          onChange={(e) => setAccepte(e.target.checked)}
          className="mt-0.5 h-4 w-4 accent-primary"
        />
        <span>Je lis, je comprends et je signe cette charte de consentement.</span>
      </label>

      <button
        onClick={() => onSign(prenom.trim())}
        disabled={!accepte || !prenom.trim() || submitting}
        className="mt-5 flex w-full items-center justify-center gap-2 rounded-full bg-white py-3 text-sm font-semibold text-black transition-all hover:bg-white/90 disabled:bg-white/15 disabled:text-white/40"
      >
        {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : "Signer et recevoir mon code AIME"}
      </button>
    </div>
  );
}