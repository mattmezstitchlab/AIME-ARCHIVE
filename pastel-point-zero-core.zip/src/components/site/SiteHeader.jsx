import React from "react";
import { Link, useLocation } from "react-router-dom";
import { LayoutGrid } from "lucide-react";

// Header du site Point Zéro — épuré, translucide, façon barre iOS.
// Nom à gauche, navigation au centre, code AIME de la personne à droite.
const NAV = [
  { to: "/", label: "Accueil" },
  { to: "/rencontres", label: "Rencontres" },
  { to: "/constellation", label: "Constellation" },
  { to: "/projection/mariage", label: "Jour J" },
];

export default function SiteHeader({ profil, onCockpit }) {
  const { pathname, search } = useLocation();
  return (
    <header className="fixed inset-x-0 top-0 z-30 bg-gradient-to-b from-black/40 to-transparent">
      <div className="flex h-14 w-full items-center justify-between px-5 md:px-8">
        <Link to="/" className="flex items-center gap-2">
          <span className="text-base font-semibold tracking-tight text-white">✦ Point Zéro</span>
        </Link>

        <nav className="hidden items-center gap-1 md:flex">
          {NAV.map((item) => {
            const active = pathname === item.to;
            return (
              <Link
                key={item.to}
                to={`${item.to}${search}`}
                className={`rounded-full px-3.5 py-1.5 text-[13px] font-medium transition-colors ${
                  active ? "bg-white/15 text-white" : "text-white/60 hover:text-white"
                }`}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>

        <div className="flex items-center gap-2">
          {onCockpit && (
            <button
              onClick={onCockpit}
              aria-label="Ouvrir le cockpit"
              className="flex h-9 w-9 items-center justify-center rounded-full text-white/60 ring-1 ring-white/15 transition-colors hover:bg-white/10 hover:text-white"
            >
              <LayoutGrid className="h-4 w-4" />
            </button>
          )}
          {profil?.code_aime ? (
            <span className="rounded-full bg-white/10 px-3 py-1.5 font-mono text-[12px] text-white/80 ring-1 ring-white/15">
              {profil.code_aime}
            </span>
          ) : (
            <span className="rounded-full bg-white/5 px-3 py-1.5 text-[12px] text-white/40 ring-1 ring-white/10">
              Invité
            </span>
          )}
        </div>
      </div>
    </header>
  );
}