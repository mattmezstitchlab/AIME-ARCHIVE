import React, { useState } from "react";
import { Upload, Sparkles } from "lucide-react";

export default function PointZeroInput({ onSubmit, loading }) {
  const [text, setText] = useState("");
  const [file, setFile] = useState(null);
  return (
    <form onSubmit={(e) => { e.preventDefault(); onSubmit({ text, file }); }} className="relative overflow-hidden rounded-xl border border-white/[0.06] bg-neutral-900/80 p-2.5">
      <div className="flex flex-col gap-2.5 lg:flex-row lg:items-center">
        <div className="flex shrink-0 items-center gap-2.5">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-red-400/30 bg-red-500/10">
            <div className="h-4 w-4 animate-pulse rounded-full bg-gradient-to-br from-red-300 to-red-600 shadow-[0_0_14px_rgba(239,68,68,0.6)]" />
          </div>
          <div>
            <p className="text-[10px] uppercase tracking-[0.28em] text-red-300">Point Zéro</p>
            <h2 className="text-sm font-bold tracking-[0.14em] text-neutral-100">Absorber</h2>
          </div>
        </div>
        <label htmlFor="point-zero-chaos" className="sr-only">Contenu à compiler au Point Zéro</label>
        <textarea id="point-zero-chaos" value={text} onChange={(e) => setText(e.target.value)} rows={1} placeholder="Déposez votre chaos : texte, SMS, souvenir, date, lieu, note, devis…" className="min-h-10 flex-1 resize-none rounded-lg border border-white/[0.08] bg-black/30 px-3 py-2 text-sm text-neutral-100 placeholder:text-neutral-600 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-red-400/50" />
        <div className="flex shrink-0 gap-2">
          <label className="flex h-10 cursor-pointer items-center justify-center gap-2 rounded-lg border border-dashed border-white/15 bg-black/30 px-3 text-xs text-neutral-300 hover:bg-white/[0.06] focus-within:ring-2 focus-within:ring-red-400/50">
            <Upload className="h-4 w-4" /> {file ? "Fichier prêt" : "Fichier"}
            <input type="file" className="sr-only" onChange={(e) => setFile(e.target.files?.[0] || null)} accept=".pdf,image/*,.txt,.doc,.docx" />
          </label>
          <button disabled={loading || (!text.trim() && !file)} className="flex h-10 items-center justify-center gap-2 rounded-lg bg-gradient-to-r from-red-500 to-rose-500 px-4 text-sm font-bold text-white hover:from-red-400 hover:to-rose-400 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-red-200 disabled:cursor-not-allowed disabled:opacity-50">
            <Sparkles className="h-4 w-4" /> {loading ? "Compilation…" : "Compiler"}
          </button>
        </div>
      </div>
    </form>
  );
}