import React from "react";
import { MATURATION } from "./config";

export default function MaturationBadge({ state = "detecte" }) {
  const item = MATURATION[state] || MATURATION.detecte;
  return (
    <span className="inline-flex items-center gap-1 rounded-full border border-white/10 bg-white/5 px-2.5 py-1 text-xs font-medium" style={{ color: item.color }}>
      <span>{item.symbol}</span>
      {item.label}
    </span>
  );
}