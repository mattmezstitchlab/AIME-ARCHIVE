import React from "react";
import { X } from "lucide-react";
import ComprehensionBlock from "./result/ComprehensionBlock";
import GreyZoneList from "./result/GreyZoneList";
import NodeCardCompact from "./result/NodeCardCompact";
import Collapsible from "./result/Collapsible";
import LinksSummary from "./result/LinksSummary";
import StatStrip from "./result/StatStrip";
import { dimensionOf, DIMENSIONS } from "./config";

export default function AnalysisPanel({ result, onAccept, onReject, onValidate }) {
  const source = result?.source;
  const nodes = result?.nodes || [];
  const fragments = result?.fragments || [];
  const links = result?.links || [];

  if (!source && !nodes.length && !fragments.length) {
    return <p className="rounded-2xl border border-white/10 bg-black/20 p-6 text-center text-sm text-slate-400">Déposez un contenu au Point Zéro pour voir ici ce que le moteur a compris.</p>;
  }

  // Zones grises du dernier dépôt (sources + fragments ambigus).
  const greyZones = [
    ...(source?.zones_grises || []).map((t) => ({ texte: t, raison: "Signification incertaine — laissée en zone grise" })),
    ...fragments.filter((f) => f.zone_grise || f.statut === "ambigu" || f.statut === "non_classe").map((f) => ({ texte: f.contenu_fragment, raison: f.raison_comprehension, confiance: f.confiance }))
  ];

  // Nœuds groupés par dimension, dans l'ordre de la grille.
  const byDim = {};
  nodes.forEach((n) => { (byDim[n.dimension] = byDim[n.dimension] || []).push(n); });
  const orderedDims = DIMENSIONS.map((d) => d.key).filter((k) => byDim[k]?.length);

  // Niveau 3 — ce qui demande confirmation : nœuds pas encore validés.
  const aConfirmer = nodes.filter((n) => n.etat_maturation !== "valide");

  return (
    <div className="space-y-3">
      {/* Mini-calculatrice universelle */}
      <StatStrip source={source} nodes={nodes} fragments={fragments} greyCount={greyZones.length} />

      {/* 1 — Ce que j'ai compris */}
      <Section title="Ce que j'ai compris">
        <ComprehensionBlock text={source?.comprehension_brute} />
      </Section>

      {/* 2 — Ce qui est rangé, par dimension */}
      {orderedDims.length > 0 && (
        <Section title="Ce qui est rangé">
          <div className="space-y-3">
            {orderedDims.map((key) => {
              const dim = dimensionOf(key);
              return (
                <div key={key}>
                  <p className="mb-1.5 text-xs font-semibold" style={{ color: dim.color }}>{dim.icon} {dim.name} · {byDim[key].length}</p>
                  <div className="grid gap-2 sm:grid-cols-2">
                    {byDim[key].map((node) => <NodeCardCompact key={node.id} node={node} onAccept={onAccept} onValidate={onValidate} />)}
                  </div>
                </div>
              );
            })}
          </div>
        </Section>
      )}

      {/* 3 — Ce qui demande confirmation */}
      {(greyZones.length > 0 || aConfirmer.length > 0) && (
        <Section title="Ce qui demande confirmation">
          <GreyZoneList items={greyZones} />
        </Section>
      )}

      {/* 4 — Caché pour les agents : liens résumés + fragments techniques */}
      <Section title="Détails pour les agents">
        <LinksSummary links={links} nodes={nodes} />
        {!!fragments.length && (
          <Collapsible title="Fragments techniques" count={fragments.length}>
            <div className="space-y-1.5">
              {fragments.map((f) => (
                <div key={f.id} className="flex items-center justify-between gap-2 text-xs text-slate-300">
                  <span>{f.contenu_fragment} — {f.dimension_suggeree || "non classé"} ({f.confiance}%)</span>
                  <button onClick={() => onReject(f)} className="text-slate-500 hover:text-red-300"><X className="h-3.5 w-3.5" /></button>
                </div>
              ))}
            </div>
          </Collapsible>
        )}
      </Section>
    </div>
  );
}

function Section({ title, children }) {
  return (
    <div>
      <p className="mb-1.5 text-[11px] font-semibold uppercase tracking-[0.22em] text-slate-500">{title}</p>
      <div className="space-y-3">{children}</div>
    </div>
  );
}