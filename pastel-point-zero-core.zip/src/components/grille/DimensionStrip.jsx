import React from "react";
import { MATURATION } from "./config";

export default function DimensionStrip({ dimension, nodes = [], selected = false, onSelect }) {
  const ready = nodes.filter((n) => n.etat_maturation === "pret").length;
  const valid = nodes.filter((n) => n.etat_maturation === "valide").length;
  const gray = nodes.filter((n) => n.etat_maturation === "ambigu").length;
  const dominant = nodes.find((n) => ["valide", "pret", "ambigu", "illumine", "detecte"].includes(n.etat_maturation))?.etat_maturation || "vide";
  return (
    <button
      onClick={() => onSelect?.(dimension)}
      title={`${dimension.name} · ${nodes.length} nœuds`}
      className={`group flex w-[152px] shrink-0 flex-col gap-2 rounded-xl border bg-neutral-900/80 p-2.5 text-left transition-colors hover:bg-neutral-800/80 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/30 ${selected ? "border-white/40" : "border-white/[0.06]"}`}
      style={{ boxShadow: selected ? `inset 0 0 0 1px ${dimension.color}55` : "none" }}
    >
      <div className="flex items-center gap-2">
        <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg text-sm" style={{ color: dimension.color, backgroundColor: `${dimension.color}1A` }}>{dimension.icon}</span>
        <span className="min-w-0 flex-1">
          <span className="block truncate text-[11px] font-semibold uppercase tracking-[0.12em]" style={{ color: dimension.color }}>{dimension.name}</span>
          <span className="block text-[10px] text-neutral-500">{nodes.length} nœuds</span>
        </span>
        <span className="text-sm" style={{ color: MATURATION[dominant].color }}>{MATURATION[dominant].symbol}</span>
      </div>
      <div className="grid grid-cols-3 gap-1 text-center text-[9px] text-neutral-500">
        <span className="rounded bg-white/[0.04] py-0.5"><b className="text-emerald-300">{ready}</b> prêts</span>
        <span className="rounded bg-white/[0.04] py-0.5"><b className="text-amber-300">{valid}</b> val</span>
        <span className="rounded bg-white/[0.04] py-0.5"><b className="text-orange-300">{gray}</b> amb</span>
      </div>
    </button>
  );
}