import React from "react";
import { Link } from "react-router-dom";
import MaturationBadge from "./MaturationBadge";
import { dimensionOf } from "./config";

export default function NodeCard({ node }) {
  const dim = dimensionOf(node.dimension);
  return (
    <Link to={`/noeud/${node.id}`} className="block rounded-2xl border border-white/10 bg-white/[0.04] p-4 transition hover:border-white/25 hover:bg-white/[0.07]">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-xs uppercase tracking-[0.18em]" style={{ color: dim.color }}>{dim.icon} {dim.name}</p>
          <h3 className="mt-2 font-semibold text-white">{node.titre}</h3>
        </div>
        <MaturationBadge state={node.etat_maturation} />
      </div>
      <p className="mt-3 line-clamp-2 text-sm text-slate-300">{node.contenu_enrichi}</p>
      <div className="mt-4 h-1.5 rounded-full bg-slate-800"><div className="h-full rounded-full" style={{ width: `${node.confiance_ia || 0}%`, backgroundColor: dim.color }} /></div>
      <p className="mt-2 text-xs text-slate-400">{node.confiance_ia || 0}% — {node.raison_classification || "Raison à enrichir"}</p>
    </Link>
  );
}