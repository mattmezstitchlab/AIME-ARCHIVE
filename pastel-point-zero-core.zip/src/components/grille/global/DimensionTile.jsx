import React from "react";
import { dimensionOf } from "../config";

// Carte d'une dimension dans la grille globale : glyphe coloré, nom, compte de nœuds.
// Sobre (iOS sombre), s'illumine au survol et à la sélection.
export default function DimensionTile({ dimKey, count = 0, active, onClick }) {
  const dim = dimensionOf(dimKey);
  return (
    <button
      type="button"
      onClick={onClick}
      className={`group flex aspect-square flex-col items-center justify-center gap-2 rounded-2xl p-3 text-center transition-all duration-300 focus-visible:outline-none ${active ? "bg-white/[0.08] ring-1 ring-white/30" : "bg-white/[0.03] ring-1 ring-white/[0.06] hover:bg-white/[0.06] hover:ring-white/15"}`}
    >
      <span
        className="flex h-11 w-11 items-center justify-center rounded-full text-lg font-semibold transition-transform group-hover:scale-110"
        style={{ color: dim.color, background: `${dim.color}1a` }}
      >
        {dim.icon}
      </span>
      <span className="text-[13px] font-medium leading-tight text-foreground/90">{dim.name}</span>
      <span className="text-[11px] font-medium tabular-nums text-muted-foreground">
        {count > 0 ? `${count} élément${count > 1 ? "s" : ""}` : "vide"}
      </span>
    </button>
  );
}