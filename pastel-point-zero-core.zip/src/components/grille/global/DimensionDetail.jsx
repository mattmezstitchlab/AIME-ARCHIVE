import React from "react";
import { Link } from "react-router-dom";
import { dimensionOf } from "../config";
import { MATURATION } from "../config";

// Panneau épuré : nœuds + fragments d'une dimension sélectionnée.
export default function DimensionDetail({ dimKey, nodes = [], fragments = [] }) {
  const dim = dimensionOf(dimKey);

  return (
    <div className="space-y-6">
      <header className="flex items-center gap-3">
        <span className="flex h-12 w-12 items-center justify-center rounded-full text-xl font-semibold" style={{ color: dim.color, background: `${dim.color}1a` }}>{dim.icon}</span>
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-foreground">{dim.name}</h2>
          <p className="text-[13px] text-muted-foreground">{dim.description}</p>
        </div>
      </header>

      {/* Nœuds */}
      <section className="space-y-2">
        <p className="text-[12px] font-semibold text-muted-foreground">Nœuds {nodes.length > 0 && `· ${nodes.length}`}</p>
        {nodes.length === 0 ? (
          <p className="rounded-2xl bg-white/[0.03] p-4 text-[13px] text-muted-foreground ring-1 ring-white/[0.06]">Aucun nœud rangé dans cette dimension.</p>
        ) : (
          <div className="space-y-2">
            {nodes.map((n) => {
              const mat = MATURATION[n.etat_maturation] || MATURATION.detecte;
              return (
                <Link key={n.id} to={`/noeud/${n.id}`} className="block rounded-2xl bg-white/[0.04] p-4 ring-1 ring-white/[0.06] transition-colors hover:bg-white/[0.07]">
                  <div className="flex items-start justify-between gap-3">
                    <h3 className="min-w-0 font-medium text-foreground">{n.titre}</h3>
                    <span className="shrink-0 text-[11px] font-medium" style={{ color: mat.color }}>{mat.symbol} {mat.label}</span>
                  </div>
                  {n.contenu_enrichi && <p className="mt-1.5 line-clamp-2 text-[13px] leading-relaxed text-muted-foreground">{n.contenu_enrichi}</p>}
                </Link>
              );
            })}
          </div>
        )}
      </section>

      {/* Fragments */}
      {fragments.length > 0 && (
        <section className="space-y-2">
          <p className="text-[12px] font-semibold text-muted-foreground">Fragments · {fragments.length}</p>
          <div className="space-y-1.5">
            {fragments.map((f) => (
              <div key={f.id} className="rounded-xl bg-white/[0.025] px-4 py-2.5 ring-1 ring-white/[0.05]">
                <p className="text-[13px] text-foreground/85">{f.contenu_fragment}</p>
                <p className="mt-0.5 text-[11px] text-muted-foreground">{f.sous_dimension_suggeree || "non précisé"} · {f.confiance ?? 0}%</p>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}