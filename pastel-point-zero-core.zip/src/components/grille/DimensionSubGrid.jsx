import React from "react";
import { MATURATION } from "./config";

export default function DimensionSubGrid({ dimension, nodes = [], onNodeSelect, onClose }) {
  if (!dimension) return null;
  const cells = Array.from({ length: 36 }).map((_, index) => nodes[index] || null);
  return (
    <section className="rounded-3xl border border-white/10 bg-slate-950/85 p-4">
      <div className="mb-3 flex items-start justify-between gap-3">
        <div>
          <p className="text-xs uppercase tracking-[0.25em]" style={{ color: dimension.color }}>{dimension.name}</p>
          <h3 className="mt-1 text-lg font-semibold text-white">Sous-grille claire</h3>
          <p className="text-sm text-slate-400">Cliquez un nœud pour ouvrir son détail temporaire.</p>
        </div>
        <button onClick={onClose} className="min-h-10 rounded-full border border-white/10 px-3 text-sm text-slate-300 hover:bg-white/10">Replier</button>
      </div>
      <div className="grid grid-cols-6 gap-2">
        {cells.map((node, index) => (
          <button key={node?.id || index} onClick={() => node && onNodeSelect(node)} disabled={!node} className="aspect-square rounded-xl border border-white/10 bg-white/[0.03] p-1 text-left hover:border-white/30 disabled:cursor-default disabled:opacity-40" style={{ boxShadow: node ? `0 0 14px ${dimension.color}` : "none" }}>
            {node && <><span className="block text-lg" style={{ color: MATURATION[node.etat_maturation || "detecte"].color }}>{MATURATION[node.etat_maturation || "detecte"].symbol}</span><span className="line-clamp-2 text-[10px] text-slate-200">{node.titre}</span></>}
          </button>
        ))}
      </div>
    </section>
  );
}