import React from "react";
import { dimensionOf } from "./config";

// Plan d'action préparé à partir d'un dépôt : pictogramme + étapes concrètes.
// Jamais exécuté automatiquement — c'est une action préparée, prête à être lancée par l'humain.
// Réutilisé dans le rapport global et au clic sur une case/document.
export default function ActionPlan({ plan, compact = false }) {
  if (!plan || (!plan.intitule && !(plan.etapes || []).length)) return null;
  const dim = dimensionOf(plan.pictogramme || "actions");

  return (
    <div className="rounded-2xl border border-indigo-200 bg-indigo-50/70 p-4">
      <div className="flex items-start gap-3">
        <span
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl text-base font-bold text-white"
          style={{ backgroundColor: dim.color }}
          title={dim.name}
        >
          {dim.icon}
        </span>
        <div className="min-w-0">
          <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-indigo-500">
            → Action préparée · {CATEGORIES[plan.categorie] || "À lancer"}
          </p>
          <p className="text-sm font-semibold text-indigo-950">{plan.intitule}</p>
          {plan.demande_detectee && <p className="mt-0.5 text-xs leading-5 text-indigo-700">{plan.demande_detectee}</p>}
        </div>
      </div>

      {/* Étapes ordonnées */}
      {(plan.etapes || []).length > 0 && (
        <ol className="mt-3 space-y-1.5">
          {plan.etapes.map((etape, i) => (
            <li key={i} className="flex items-start gap-2.5 text-sm leading-5 text-indigo-950">
              <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-white text-[11px] font-bold text-indigo-600 shadow-sm">{i + 1}</span>
              {etape}
            </li>
          ))}
        </ol>
      )}

      {!compact && (plan.infos_extraites?.length > 0 || plan.infos_manquantes?.length > 0) && (
        <div className="mt-3 grid gap-2 sm:grid-cols-2">
          {plan.infos_extraites?.length > 0 && (
            <InfoList sym="=" tone="emerald" title="Déjà extrait" items={plan.infos_extraites} />
          )}
          {plan.infos_manquantes?.length > 0 && (
            <InfoList sym="?" tone="amber" title="À compléter" items={plan.infos_manquantes} />
          )}
        </div>
      )}
    </div>
  );
}

const CATEGORIES = {
  facture: "Facture", devis: "Devis", email: "Email", rendez_vous: "Rendez-vous",
  document: "Document", paiement: "Paiement", relance: "Relance", reservation: "Réservation", contact: "Contact",
};

const LIST_TONES = {
  emerald: "border-emerald-200 bg-white text-emerald-600",
  amber: "border-amber-200 bg-white text-amber-600",
};

function InfoList({ sym, tone, title, items }) {
  return (
    <div className={`rounded-xl border p-2.5 ${LIST_TONES[tone]}`}>
      <p className="mb-1 flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-[0.14em]">
        <span className="text-xs font-bold">{sym}</span>{title}
      </p>
      <ul className="space-y-0.5">
        {items.map((t, i) => <li key={i} className="text-xs leading-4 text-neutral-700">{t}</li>)}
      </ul>
    </div>
  );
}