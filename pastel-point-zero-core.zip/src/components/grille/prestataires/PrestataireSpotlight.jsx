import React, { useEffect, useRef, useState } from "react";
import DialFace from "@/components/grille/DialFace";
import { metierOf, HUMEURS, fourchette } from "./metiers";
import { Play, Square, Music, X } from "lucide-react";

// PLUME met un prestataire en avant : sa photo au centre du cadran, et au clic sur Play
// elle joue son extrait musical. Le côté humain (bio, tarif, négo, comment lui parler).
export default function PrestataireSpotlight({ p, onClose }) {
  const [playing, setPlaying] = useState(false);
  const [level, setLevel] = useState(0);
  const audioRef = useRef(null);
  const rafRef = useRef(null);
  const m = metierOf(p.metier);

  useEffect(() => () => stop(), []); // cleanup au démontage
  useEffect(() => { stop(); }, [p?.id]); // change de prestataire = coupe l'audio

  const stop = () => {
    if (audioRef.current) { audioRef.current.pause(); audioRef.current = null; }
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    setLevel(0); setPlaying(false);
  };

  const play = async () => {
    if (playing) return stop();
    if (!p.extrait_audio_url) return;
    const audio = new Audio(p.extrait_audio_url);
    audio.crossOrigin = "anonymous";
    audioRef.current = audio;
    try {
      const Ctx = window.AudioContext || window.webkitAudioContext;
      const ctx = new Ctx();
      const src = ctx.createMediaElementSource(audio);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 256;
      src.connect(analyser); analyser.connect(ctx.destination);
      const data = new Uint8Array(analyser.frequencyBinCount);
      const tick = () => {
        analyser.getByteFrequencyData(data);
        let sum = 0; for (let i = 0; i < data.length; i++) sum += data[i];
        setLevel(Math.min(1, (sum / data.length / 255) * 2.2));
        rafRef.current = requestAnimationFrame(tick);
      };
      tick();
    } catch (_e) { /* la lecture marche même sans visualiseur */ }
    audio.onended = () => stop();
    audio.onerror = () => stop();
    await audio.play();
    setPlaying(true);
  };

  return (
    <div className="flex flex-col items-center px-6 py-8 text-center">
      {/* Cadran avec la photo au centre */}
      <DialFace audioLevel={playing ? level : 0} size={280}>
        <div className="h-40 w-40 overflow-hidden rounded-full ring-2 ring-white/20">
          {p.photo_url
            ? <img src={p.photo_url} alt={p.nom} className="h-full w-full object-cover" />
            : <div className="flex h-full w-full items-center justify-center text-5xl" style={{ background: `${m.color}22` }}>{m.icon}</div>}
        </div>
      </DialFace>

      {/* Play musique — sous le cadran */}
      {p.extrait_audio_url && (
        <button onClick={play} className="mt-5 inline-flex items-center gap-2 rounded-full bg-white/10 px-5 py-2.5 text-[13px] font-medium text-white ring-1 ring-white/20 backdrop-blur-md transition-all hover:bg-white/20">
          {playing ? <Square className="h-4 w-4 fill-current" /> : <Play className="h-4 w-4 translate-x-0.5 fill-current" />}
          {playing ? "Arrêter" : "Écouter"} <Music className="h-3.5 w-3.5 opacity-60" />
        </button>
      )}

      <h3 className="mt-5 text-xl font-bold text-white">{p.nom}</h3>
      <p className="text-[13px]" style={{ color: m.color }}>{m.icon} {m.label}{p.specialite ? ` · ${p.specialite}` : ""}</p>
      {p.bio && <p className="mt-3 max-w-md text-[13px] leading-relaxed text-white/70">{p.bio}</p>}

      <div className="mt-4 flex flex-wrap justify-center gap-2 text-[12px]">
        <Chip>{fourchette(p)}</Chip>
        {p.negociation_possible && <Chip>Négociable{p.note_negociation ? ` · ${p.note_negociation}` : ""}</Chip>}
        <Chip>{HUMEURS[p.humeur]}</Chip>
        <Chip>{p.ton_avec_maries === "court" ? "Aime le direct" : "Aime le détail"}</Chip>
      </div>
      {p.note_relation && <p className="mt-3 max-w-md text-[12px] italic text-white/45">💬 {p.note_relation}</p>}

      <button onClick={onClose} className="mt-6 inline-flex items-center gap-1.5 text-[13px] text-white/50 hover:text-white">
        <X className="h-4 w-4" /> Fermer
      </button>
    </div>
  );
}

function Chip({ children }) {
  return <span className="rounded-full bg-white/[0.06] px-3 py-1 text-white/75 ring-1 ring-white/10">{children}</span>;
}