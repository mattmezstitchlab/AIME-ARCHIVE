import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { METIERS, HUMEURS } from "./metiers";
import { Loader2, Check } from "lucide-react";

// Fiche qu'un prestataire (ou un mari\u00e9) remplit dans le cockpit :
// m\u00e9tier, dispos, tarif & n\u00e9go, humeur, comment lui parler, photo, extrait audio.
export default function PrestataireForm({ initial = null, onSaved, onCancel }) {
  const [f, setF] = useState(() => ({
    nom: "", metier: "traiteur", specialite: "", bio: "", ville: "",
    photo_url: "", extrait_audio_url: "", statut_dispo: "disponible", humeur: "posee",
    tarif_min: "", tarif_max: "", negociation_possible: false, note_negociation: "",
    ton_avec_maries: "detaille", note_relation: "", disponibilites_txt: "",
    ...(initial ? { ...initial, disponibilites_txt: (initial.disponibilites || []).join(", ") } : {}),
  }));
  const [saving, setSaving] = useState(false);
  const set = (k) => (e) => setF((s) => ({ ...s, [k]: e.target.value }));

  const save = async () => {
    setSaving(true);
    const payload = {
      nom: f.nom, metier: f.metier, specialite: f.specialite, bio: f.bio, ville: f.ville,
      photo_url: f.photo_url, extrait_audio_url: f.extrait_audio_url,
      statut_dispo: f.statut_dispo, humeur: f.humeur,
      tarif_min: f.tarif_min ? Number(f.tarif_min) : undefined,
      tarif_max: f.tarif_max ? Number(f.tarif_max) : undefined,
      negociation_possible: !!f.negociation_possible, note_negociation: f.note_negociation,
      ton_avec_maries: f.ton_avec_maries, note_relation: f.note_relation,
      disponibilites: f.disponibilites_txt.split(",").map((s) => s.trim()).filter(Boolean),
    };
    try {
      if (initial?.id) await base44.entities.Prestataire.update(initial.id, payload);
      else await base44.entities.Prestataire.create(payload);
      onSaved?.();
    } finally { setSaving(false); }
  };

  const input = "w-full rounded-lg bg-white/[0.06] px-3 py-2 text-[13px] text-white placeholder-white/30 ring-1 ring-white/10 focus:outline-none focus:ring-white/25";
  const lab = "text-[11px] font-semibold uppercase tracking-wide text-white/40";

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-1"><span className={lab}>Nom</span><input className={input} value={f.nom} onChange={set("nom")} placeholder="Nom / artiste" /></div>
        <div className="space-y-1"><span className={lab}>Métier</span>
          <select className={input} value={f.metier} onChange={set("metier")}>
            {Object.entries(METIERS).map(([k, m]) => <option key={k} value={k} className="bg-neutral-900">{m.icon} {m.label}</option>)}
          </select>
        </div>
      </div>

      <div className="space-y-1"><span className={lab}>Spécialité</span><input className={input} value={f.specialite} onChange={set("specialite")} placeholder="Style, ce qui le distingue" /></div>
      <div className="space-y-1"><span className={lab}>Le côté humain (bio)</span><textarea rows={2} className={input} value={f.bio} onChange={set("bio")} placeholder="Sa personnalité, son histoire — ce que PLUME raconte de lui" /></div>

      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-1"><span className={lab}>Photo (URL)</span><input className={input} value={f.photo_url} onChange={set("photo_url")} placeholder="https://…" /></div>
        <div className="space-y-1"><span className={lab}>Extrait audio (URL)</span><input className={input} value={f.extrait_audio_url} onChange={set("extrait_audio_url")} placeholder="Musique jouée au Play" /></div>
      </div>

      <div className="grid grid-cols-3 gap-3">
        <div className="space-y-1"><span className={lab}>Ville</span><input className={input} value={f.ville} onChange={set("ville")} /></div>
        <div className="space-y-1"><span className={lab}>Dispo</span>
          <select className={input} value={f.statut_dispo} onChange={set("statut_dispo")}>
            <option value="disponible" className="bg-neutral-900">Disponible</option>
            <option value="sur_demande" className="bg-neutral-900">Sur demande</option>
            <option value="complet" className="bg-neutral-900">Complet</option>
          </select>
        </div>
        <div className="space-y-1"><span className={lab}>Humeur</span>
          <select className={input} value={f.humeur} onChange={set("humeur")}>
            {Object.entries(HUMEURS).map(([k, v]) => <option key={k} value={k} className="bg-neutral-900">{v}</option>)}
          </select>
        </div>
      </div>

      <div className="space-y-1"><span className={lab}>Dates dispo (séparées par virgules)</span><input className={input} value={f.disponibilites_txt} onChange={set("disponibilites_txt")} placeholder="2026-09-12, 2026-09-19" /></div>

      <div className="grid grid-cols-3 gap-3">
        <div className="space-y-1"><span className={lab}>Tarif min (€)</span><input type="number" className={input} value={f.tarif_min} onChange={set("tarif_min")} /></div>
        <div className="space-y-1"><span className={lab}>Tarif max (€)</span><input type="number" className={input} value={f.tarif_max} onChange={set("tarif_max")} /></div>
        <div className="space-y-1"><span className={lab}>Ton mariés</span>
          <select className={input} value={f.ton_avec_maries} onChange={set("ton_avec_maries")}>
            <option value="court" className="bg-neutral-900">Court & direct</option>
            <option value="detaille" className="bg-neutral-900">Détaillé</option>
          </select>
        </div>
      </div>

      <label className="flex items-center gap-2 text-[13px] text-white/80">
        <input type="checkbox" checked={f.negociation_possible} onChange={(e) => setF((s) => ({ ...s, negociation_possible: e.target.checked }))} />
        Négociation possible
      </label>
      {f.negociation_possible && <div className="space-y-1"><span className={lab}>Marge de négociation</span><input className={input} value={f.note_negociation} onChange={set("note_negociation")} placeholder="Conditions, packages, réductions" /></div>}

      <div className="space-y-1"><span className={lab}>Comment lui parler / habitudes</span><textarea rows={2} className={input} value={f.note_relation} onChange={set("note_relation")} placeholder="Ses préférences de communication" /></div>

      <div className="flex gap-2 pt-1">
        <button onClick={save} disabled={saving || !f.nom} className="inline-flex items-center gap-1.5 rounded-lg bg-white px-4 py-2 text-[13px] font-semibold text-black disabled:opacity-40">
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />} Enregistrer
        </button>
        <button onClick={onCancel} className="rounded-lg px-4 py-2 text-[13px] text-white/60 hover:text-white">Annuler</button>
      </div>
    </div>
  );
}