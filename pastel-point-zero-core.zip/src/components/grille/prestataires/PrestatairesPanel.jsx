import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import PrestataireCard from "./PrestataireCard";
import PrestataireForm from "./PrestataireForm";
import PrestataireSpotlight from "./PrestataireSpotlight";
import usePlumeVoice from "@/hooks/usePlumeVoice";
import { Plus, Sparkles, Loader2, ArrowLeft } from "lucide-react";

// Le registre vivant des prestataires + les suggestions de PLUME.
// Chacun renseigne sa fiche ; PLUME pioche selon les dispos et les présente aux mariés.
export default function PrestatairesPanel() {
  const [list, setList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [mode, setMode] = useState("list"); // list | form
  const [editing, setEditing] = useState(null);
  const [spotlight, setSpotlight] = useState(null);
  const [intro, setIntro] = useState("");
  const [suggesting, setSuggesting] = useState(false);
  const { speak, stop, speaking } = usePlumeVoice();

  const load = () => {
    setLoading(true);
    base44.entities.Prestataire.list("-note_interne", 200)
      .then(setList).catch(() => {}).finally(() => setLoading(false));
  };
  useEffect(load, []);

  const suggest = async () => {
    setSuggesting(true);
    try {
      const res = await base44.functions.invoke("plumeSuggestions", {});
      const txt = res.data?.intro || "";
      setIntro(txt);
      if (txt) speak(txt);
    } finally { setSuggesting(false); }
  };

  if (mode === "form") {
    return (
      <div className="p-5">
        <button onClick={() => setMode("list")} className="mb-4 inline-flex items-center gap-1.5 text-[13px] text-white/60 hover:text-white"><ArrowLeft className="h-4 w-4" /> Registre</button>
        <PrestataireForm initial={editing} onSaved={() => { setMode("list"); setEditing(null); load(); }} onCancel={() => { setMode("list"); setEditing(null); }} />
      </div>
    );
  }

  if (spotlight) {
    return <PrestataireSpotlight p={spotlight} onClose={() => setSpotlight(null)} />;
  }

  return (
    <div className="p-5">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h3 className="text-[15px] font-semibold text-white">Registre des prestataires</h3>
          <p className="text-[12px] text-white/40">{list.length} fiche{list.length > 1 ? "s" : ""} · chacun renseigne dispo, tarif, humeur</p>
        </div>
        <div className="flex gap-2">
          <button onClick={speaking ? stop : suggest} disabled={suggesting} className="inline-flex items-center gap-1.5 rounded-lg bg-white/10 px-3 py-2 text-[13px] font-medium text-white ring-1 ring-white/15 hover:bg-white/20 disabled:opacity-40">
            {suggesting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />} {speaking ? "Arrêter" : "PLUME suggère"}
          </button>
          <button onClick={() => { setEditing(null); setMode("form"); }} className="inline-flex items-center gap-1.5 rounded-lg bg-white px-3 py-2 text-[13px] font-semibold text-black hover:bg-white/90">
            <Plus className="h-4 w-4" /> Ajouter
          </button>
        </div>
      </div>

      {intro && (
        <div className="mb-4 rounded-2xl bg-white/[0.05] p-4 ring-1 ring-white/10">
          <p className="text-[11px] font-semibold uppercase tracking-wide text-white/40">PLUME</p>
          <p className="mt-1 text-[13px] leading-relaxed text-white/85">{intro}</p>
        </div>
      )}

      {loading ? (
        <p className="py-10 text-center text-[13px] text-white/40"><Loader2 className="mx-auto h-5 w-5 animate-spin" /></p>
      ) : list.length === 0 ? (
        <p className="py-10 text-center text-[13px] text-white/40">Aucun prestataire. Ajoute la première fiche.</p>
      ) : (
        <div className="grid gap-2.5 sm:grid-cols-2">
          {list.map((p) => (
            <PrestataireCard key={p.id} p={p} active={spotlight?.id === p.id}
              onEdit={(x) => { setEditing(x); setMode("form"); }}
              onSelect={(x) => setSpotlight(x)} />
          ))}
        </div>
      )}
    </div>
  );
}