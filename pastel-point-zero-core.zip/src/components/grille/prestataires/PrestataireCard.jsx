import React from "react";
import { metierOf, HUMEURS, STATUTS_DISPO, fourchette } from "./metiers";
import { Pencil, Music, MapPin, Check } from "lucide-react";

// Carte prestataire dans le registre — le côté humain + le concret.
// Clic sur la carte = PLUME le met en avant (photo au centre du cadran + play musique).
export default function PrestataireCard({ p, onEdit, onSelect, active }) {
  const m = metierOf(p.metier);
  const dispo = STATUTS_DISPO[p.statut_dispo] || STATUTS_DISPO.disponible;
  return (
    <div
      onClick={() => onSelect?.(p)}
      className={`group cursor-pointer overflow-hidden rounded-2xl bg-white/[0.04] ring-1 transition-all ${active ? "ring-white/40" : "ring-white/[0.07] hover:ring-white/20"}`}
    >
      <div className="flex gap-3 p-3">
        {p.photo_url ? (
          <img src={p.photo_url} alt="" className="h-16 w-16 shrink-0 rounded-xl object-cover" />
        ) : (
          <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-xl text-2xl" style={{ background: `${m.color}22` }}>{m.icon}</div>
        )}
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-1.5">
            <span className="truncate text-[14px] font-semibold text-white">{p.nom}</span>
            {p.verifie && <Check className="h-3.5 w-3.5 shrink-0 text-emerald-400" />}
            {p.extrait_audio_url && <Music className="h-3.5 w-3.5 shrink-0 text-white/40" />}
          </div>
          <p className="text-[11px]" style={{ color: m.color }}>{m.icon} {m.label}{p.specialite ? ` · ${p.specialite}` : ""}</p>
          <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[11px] text-white/50">
            <span className="inline-flex items-center gap-0.5"><span className="h-1.5 w-1.5 rounded-full" style={{ background: dispo.color }} />{dispo.label}</span>
            <span>· {fourchette(p)}{p.negociation_possible ? " · négo" : ""}</span>
            {p.ville && <span className="inline-flex items-center gap-0.5">· <MapPin className="h-3 w-3" />{p.ville}</span>}
          </div>
          <p className="mt-0.5 text-[11px] text-white/35">{HUMEURS[p.humeur] || ""}</p>
        </div>
        <button
          onClick={(e) => { e.stopPropagation(); onEdit?.(p); }}
          className="h-7 w-7 shrink-0 rounded-lg text-white/30 opacity-0 transition-all hover:bg-white/10 hover:text-white group-hover:opacity-100"
          aria-label="Modifier"
        >
          <Pencil className="mx-auto h-3.5 w-3.5" />
        </button>
      </div>
    </div>
  );
}