// Métiers de prestataires — libellé, icône, couleur (aligné à l'esthétique du cadran).
export const METIERS = {
  traiteur: { label: "Traiteur", icon: "🍽", color: "#F59E0B" },
  photographe: { label: "Photographe", icon: "📷", color: "#22D3EE" },
  dj: { label: "DJ", icon: "🎧", color: "#A78BFA" },
  musicien: { label: "Musicien", icon: "🎻", color: "#A78BFA" },
  fleuriste: { label: "Fleuriste", icon: "🌸", color: "#F472B6" },
  lieu: { label: "Lieu", icon: "🏛", color: "#34D399" },
  wedding_planner: { label: "Wedding planner", icon: "📋", color: "#60A5FA" },
  patissier: { label: "Pâtissier", icon: "🎂", color: "#FBBF24" },
  coiffeur: { label: "Coiffeur", icon: "✂️", color: "#F87171" },
  maquilleur: { label: "Maquilleur", icon: "💄", color: "#FB7185" },
  video: { label: "Vidéaste", icon: "🎬", color: "#38BDF8" },
  decoration: { label: "Décoration", icon: "🕯", color: "#FCD34D" },
  transport: { label: "Transport", icon: "🚗", color: "#94A3B8" },
  officiant: { label: "Officiant", icon: "📖", color: "#C084FC" },
  autre: { label: "Autre", icon: "✦", color: "#9CA3AF" },
};

export const metierOf = (key) => METIERS[key] || METIERS.autre;

export const HUMEURS = {
  enthousiaste: "😄 Enthousiaste",
  posee: "🙂 Posée",
  debordee: "😅 Débordée",
  flexible: "😌 Flexible",
  selective: "🧐 Sélective",
};

export const STATUTS_DISPO = {
  disponible: { label: "Disponible", color: "#34D399" },
  sur_demande: { label: "Sur demande", color: "#FBBF24" },
  complet: { label: "Complet", color: "#F87171" },
};

export function fourchette(p) {
  if (p.tarif_min && p.tarif_max) return `${p.tarif_min}–${p.tarif_max} €`;
  if (p.tarif_min) return `dès ${p.tarif_min} €`;
  if (p.tarif_max) return `jusqu'à ${p.tarif_max} €`;
  return "Tarif sur demande";
}