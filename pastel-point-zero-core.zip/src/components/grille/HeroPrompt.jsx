import React from "react";

// Promesse claire au-dessus du cercle + un exemple cliquable.
// Objectif : faire vivre le moment "il a vu ce qui me manquait" dès le premier clic.
const EXEMPLE = "On se marie le 12 septembre, 80 invités en extérieur, traiteur réservé. Réception à la salle des Tilleuls à 19h, DJ confirmé.";

export default function HeroPrompt({ onTryExample, loading }) {
  return (
    <div className="mb-8 max-w-xl text-center">
      <p className="text-[11px] font-semibold uppercase tracking-[0.3em] text-neutral-400">Point Zéro</p>
      <h1 className="mt-3 text-2xl font-bold leading-tight text-neutral-900 sm:text-3xl">
        Déposez votre chaos.<br />Il comprend — et voit ce qui vous manque.
      </h1>
      <p className="mt-3 text-sm leading-6 text-neutral-500">
        Un SMS, une facture, une note jetée vite. Le moteur lit l'ensemble, range ce qui compte,
        et révèle les oublis que personne ne remarque.
      </p>
      <button
        type="button"
        onClick={() => onTryExample(EXEMPLE)}
        disabled={loading}
        className="mt-5 inline-flex items-center gap-2 rounded-full border border-neutral-300 bg-white px-5 py-2.5 text-sm font-medium text-neutral-700 shadow-sm transition-all hover:border-neutral-900 hover:text-neutral-900 disabled:opacity-40"
      >
        <span className="text-amber-500">▲</span>
        Essayez avec un message de mariage
      </button>
    </div>
  );
}