import React from "react";
import { Link } from "react-router-dom";

export default function ProjectionExtract({ nodes = [] }) {
  const mature = nodes.filter((n) => ["pret", "valide"].includes(n.etat_maturation)).length;
  return (
    <section className="rounded-[2rem] border border-amber-300/15 bg-amber-950/10 p-5">
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-xs uppercase tracking-[0.25em] text-amber-200">Projection disponible · extrait</p>
          <h2 className="mt-2 text-xl font-semibold text-white">Mariage / Jour J</h2>
          <p className="mt-2 text-sm leading-6 text-slate-400">Une projection métier issue de la grille, pas le cœur du système. Elle ne peut exécuter que les nœuds prêts ou validés.</p>
        </div>
        <div className="rounded-2xl bg-white/[0.04] px-4 py-3 text-center">
          <b className="block text-2xl text-amber-200">{mature}</b>
          <span className="text-xs text-slate-400">nœuds mûrs</span>
        </div>
      </div>
      <Link to="/projection/mariage" className="mt-4 inline-flex min-h-11 items-center rounded-full border border-amber-200/20 px-4 text-sm font-medium text-amber-100 hover:bg-amber-200/10 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-200/70">Ouvrir l’extrait Mariage/Jour J</Link>
    </section>
  );
}