import React from "react";
import { dimensionOf } from "@/components/grille/config";

// Flux mémoire central — la façon dont les messages/compréhensions apparaissent.
// Pour chaque dépôt : sa compréhension brute, son intention, puis les nœuds saisis (bulles).
export default function CockpitMemoryFeed({ sources = [], nodes = [] }) {
  if (!sources.length) {
    return <p className="p-6 text-center text-[13px] text-white/40">Sélectionne un dépôt, ou dépose du contenu au Point Zéro.</p>;
  }

  return (
    <div className="mx-auto max-w-2xl space-y-8 px-6 py-8">
      {sources.map((s) => {
        const own = nodes.filter((n) => n.source_brute_id === s.id);
        const present = own.filter((n) => !isMissing(n));
        const missing = own.filter(isMissing);
        return (
          <div key={s.id} className="space-y-3">
            {/* Le dépôt tel que saisi */}
            {s.contenu_texte && (
              <div className="ml-auto max-w-[85%] rounded-2xl rounded-tr-sm bg-white/10 px-4 py-2.5 text-[13px] leading-relaxed text-white">
                {s.contenu_texte}
              </div>
            )}
            {/* La compréhension du moteur (message qui apparaît) */}
            {s.comprehension_brute && (
              <div className="max-w-[90%] rounded-2xl rounded-tl-sm bg-white/[0.05] px-4 py-3 ring-1 ring-white/[0.06]">
                <p className="text-[11px] font-semibold uppercase tracking-wide text-white/40">Compréhension</p>
                <p className="mt-1 text-[13px] leading-relaxed text-white/85">{s.comprehension_brute}</p>
                {s.intention_globale && <p className="mt-2 text-[12px] italic leading-relaxed text-white/55">Intention : {s.intention_globale}</p>}
              </div>
            )}
            {/* Nœuds présents — bulles colorées par dimension */}
            {present.length > 0 && (
              <div className="flex flex-wrap gap-1.5 pl-1">
                {present.map((n) => {
                  const d = dimensionOf(n.dimension);
                  return (
                    <span key={n.id} className="inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px]" style={{ background: `${d.color}1a`, color: d.light || d.color }}>
                      <span className="text-[10px]">{d.icon}</span>{n.titre}
                    </span>
                  );
                })}
              </div>
            )}
            {/* Manques — traits blancs, ce qui devrait être là */}
            {missing.length > 0 && (
              <div className="flex flex-wrap gap-1.5 pl-1">
                {missing.map((n) => (
                  <span key={n.id} className="inline-flex items-center gap-1.5 rounded-full border border-dashed border-white/40 px-2.5 py-1 text-[11px] text-white/70">
                    ⚠ {n.titre}
                  </span>
                ))}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

function isMissing(n = {}) {
  return n.presence_state === "absent" || n.manque_probable || n.silence_significatif;
}