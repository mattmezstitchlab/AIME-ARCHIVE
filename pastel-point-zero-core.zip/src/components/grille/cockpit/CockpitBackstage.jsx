import React, { useEffect, useState } from "react";
import { X, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { DIMENSIONS, dimensionOf } from "@/components/grille/config";
import CockpitTimeline from "./CockpitTimeline";
import CockpitEngine from "./CockpitEngine";
import CockpitMemoryFeed from "./CockpitMemoryFeed";
import PrestatairesPanel from "@/components/grille/prestataires/PrestatairesPanel";

// « La machine de derrière » — cockpit plein écran, backstage du moteur.
// Trois zones lisibles malgré la densité :
//   • Gauche  : timeline verticale des dépôts dans le temps (graduations, façon capture Codex).
//   • Centre  : flux mémoire — compréhensions, messages, ce que le moteur a saisi.
//   • Droite  : moteur — dimensions remplies, nœuds, manques, liens.
export default function CockpitBackstage({ open, onClose }) {
  const [sources, setSources] = useState([]);
  const [nodes, setNodes] = useState([]);
  const [links, setLinks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeSource, setActiveSource] = useState(null); // dépôt sélectionné dans la timeline
  const [tab, setTab] = useState("memoire"); // memoire | prestataires

  useEffect(() => {
    if (!open) return;
    setLoading(true);
    Promise.all([
      base44.entities.SourceBrute.list("-created_date", 200),
      base44.entities.NoeudMemoire.list("-created_date", 400),
      base44.entities.LienMemoire.list("-created_date", 200),
    ])
      .then(([s, n, l]) => { setSources(s); setNodes(n); setLinks(l); })
      .finally(() => setLoading(false));
  }, [open]);

  if (!open) return null;

  // Filtrage par dépôt sélectionné (sinon tout).
  const shownNodes = activeSource ? nodes.filter((n) => n.source_brute_id === activeSource) : nodes;
  const shownSources = activeSource ? sources.filter((s) => s.id === activeSource) : sources;

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#0a0a0b] text-white">
      {/* Barre de titre */}
      <header className="flex items-center justify-between border-b border-white/10 px-5 py-3">
        <div className="flex items-center gap-4">
          <span className="text-[13px] font-semibold tracking-wide text-white">COCKPIT</span>
          {/* Onglets : la mémoire du moteur, ou le registre des prestataires */}
          <div className="flex rounded-full bg-white/5 p-0.5 ring-1 ring-white/10">
            {[["memoire", "Mémoire"], ["prestataires", "Prestataires"]].map(([k, label]) => (
              <button key={k} onClick={() => setTab(k)} className={`rounded-full px-3 py-1 text-[12px] font-medium transition-all ${tab === k ? "bg-white text-black" : "text-white/60 hover:text-white"}`}>
                {label}
              </button>
            ))}
          </div>
          {tab === "memoire" && (
            <span className="hidden text-[11px] font-mono text-white/40 md:inline">
              {sources.length} dépôts · {nodes.length} nœuds · {links.length} liens
            </span>
          )}
          {tab === "memoire" && activeSource && (
            <button onClick={() => setActiveSource(null)} className="text-[11px] font-medium text-primary hover:underline">
              ← tout voir
            </button>
          )}
        </div>
        <button onClick={onClose} aria-label="Fermer" className="flex h-8 w-8 items-center justify-center rounded-full text-white/60 hover:bg-white/10 hover:text-white">
          <X className="h-4.5 w-4.5" />
        </button>
      </header>

      {tab === "prestataires" ? (
        <div className="flex-1 overflow-y-auto">
          <div className="mx-auto max-w-4xl">
            <PrestatairesPanel />
          </div>
        </div>
      ) : loading ? (
        <div className="flex flex-1 items-center justify-center">
          <Loader2 className="h-6 w-6 animate-spin text-white/40" />
        </div>
      ) : (
        <div className="grid flex-1 grid-cols-1 overflow-hidden lg:grid-cols-[260px_1fr_340px]">
          {/* Timeline verticale des dépôts */}
          <div className="hidden overflow-y-auto border-r border-white/10 lg:block">
            <CockpitTimeline sources={sources} activeSource={activeSource} onSelect={setActiveSource} />
          </div>
          {/* Flux mémoire central */}
          <div className="overflow-y-auto">
            <CockpitMemoryFeed sources={shownSources} nodes={shownNodes} />
          </div>
          {/* Moteur */}
          <div className="hidden overflow-y-auto border-l border-white/10 lg:block">
            <CockpitEngine nodes={shownNodes} links={activeSource ? links.filter((l) => shownNodes.some((n) => n.id === l.noeud_source_id || n.id === l.noeud_cible_id)) : links} />
          </div>
        </div>
      )}
    </div>
  );
}

export { DIMENSIONS, dimensionOf };