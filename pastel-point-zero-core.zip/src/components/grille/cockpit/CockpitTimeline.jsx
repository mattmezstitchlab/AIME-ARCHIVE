import React from "react";
import { formatDistanceToNow } from "date-fns";
import { fr } from "date-fns/locale";

// Timeline verticale des dépôts — graduations façon règle temporelle (capture Codex).
// Chaque dépôt = une grosse graduation cliquable ; entre eux, des graduations fines.
export default function CockpitTimeline({ sources = [], activeSource, onSelect }) {
  if (!sources.length) {
    return <p className="p-5 text-[12px] text-white/40">Aucun dépôt pour l'instant.</p>;
  }

  return (
    <div className="relative py-6 pl-6 pr-3">
      {/* Rail vertical */}
      <div className="absolute left-6 top-0 h-full w-px bg-white/10" />
      <div className="space-y-1">
        {sources.map((s, i) => {
          const active = s.id === activeSource;
          const label = s.contenu_texte?.trim() || domaineLabel(s) || "Dépôt";
          const when = s.created_date ? formatDistanceToNow(new Date(s.created_date), { addSuffix: true, locale: fr }) : "";
          return (
            <button
              key={s.id}
              onClick={() => onSelect(active ? null : s.id)}
              className="group relative flex w-full items-start gap-3 rounded-lg py-2 pl-0 pr-2 text-left transition-colors hover:bg-white/[0.04]"
            >
              {/* Grosse graduation du dépôt */}
              <span className={`relative z-10 mt-1 block h-0.5 w-5 rounded-full transition-all ${active ? "bg-white" : "bg-white/50 group-hover:bg-white/80"}`} style={active ? { boxShadow: "0 0 8px rgba(255,255,255,0.8)" } : undefined} />
              <span className="min-w-0 flex-1">
                <span className={`block truncate text-[12px] ${active ? "font-medium text-white" : "text-white/70"}`}>{label}</span>
                <span className="mt-0.5 block text-[10px] font-mono text-white/35">{when}</span>
              </span>
              {/* Graduations fines de séparation */}
              {i < sources.length - 1 && (
                <span className="pointer-events-none absolute left-6 top-9 flex flex-col gap-1.5">
                  {[0, 1, 2].map((k) => <span key={k} className="block h-px w-2.5 bg-white/12" />)}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}

function domaineLabel(s) {
  if (s.domaine_detecte && s.domaine_detecte !== "autre") return s.domaine_detecte;
  return s.type_source || "";
}