import React from "react";
import { DIMENSIONS } from "@/components/grille/config";

// Moteur du cadran, à nu — la progression réelle, dimension par dimension.
// Barres de remplissage par dimension + compteurs de manques et de liens.
export default function CockpitEngine({ nodes = [], links = [] }) {
  const present = nodes.filter((n) => !isMissing(n));
  const missing = nodes.filter(isMissing);

  // Compte de nœuds présents par dimension → remplissage.
  const byDim = {};
  present.forEach((n) => { byDim[n.dimension] = (byDim[n.dimension] || 0) + 1; });
  const max = Math.max(1, ...Object.values(byDim));

  return (
    <div className="space-y-6 p-5">
      {/* Progression globale */}
      <div className="grid grid-cols-3 gap-2">
        <Stat label="Saisis" value={present.length} />
        <Stat label="Manques" value={missing.length} accent="#FFFFFF" />
        <Stat label="Liens" value={links.length} />
      </div>

      {/* Remplissage par dimension */}
      <div>
        <p className="mb-3 text-[11px] font-semibold uppercase tracking-wide text-white/40">Remplissage du cadran</p>
        <div className="space-y-2.5">
          {DIMENSIONS.map((d) => {
            const count = byDim[d.key] || 0;
            const pct = count ? Math.max(8, (count / max) * 100) : 0;
            return (
              <div key={d.key} className="flex items-center gap-2.5">
                <span className="w-4 text-center text-[11px]" style={{ color: d.color }}>{d.icon}</span>
                <span className="w-24 shrink-0 truncate text-[11px] text-white/60">{d.name}</span>
                <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-white/[0.06]">
                  <div className="h-full rounded-full transition-all" style={{ width: `${pct}%`, background: d.color, opacity: count ? 0.9 : 0 }} />
                </div>
                <span className="w-4 text-right text-[11px] font-mono text-white/40">{count || "·"}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Manques en clair */}
      {missing.length > 0 && (
        <div>
          <p className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-white/40">Ce qui manque</p>
          <div className="space-y-1">
            {missing.slice(0, 12).map((n) => (
              <p key={n.id} className="truncate text-[12px] text-white/70">— {n.titre}</p>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function Stat({ label, value, accent }) {
  return (
    <div className="rounded-xl bg-white/[0.04] p-3 text-center ring-1 ring-white/[0.06]">
      <p className="text-2xl font-bold tracking-tight" style={accent ? { color: accent } : undefined}>{value}</p>
      <p className="mt-0.5 text-[10px] uppercase tracking-wide text-white/40">{label}</p>
    </div>
  );
}

function isMissing(n = {}) {
  return n.presence_state === "absent" || n.manque_probable || n.silence_significatif;
}