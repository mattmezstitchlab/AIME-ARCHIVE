import React, { useState } from "react";
import MaturationBadge from "./MaturationBadge";
import { dimensionOf } from "./config";
import ActionPlan from "./ActionPlan";
import ActionPicker from "./action/ActionPicker";
import PreparedDocument from "./action/PreparedDocument";

const PREP_MESSAGES = {
  email: "Brouillon d'email à préparer — l'envoi réel n'est pas encore disponible, rien ne part.",
  envoyer: "Préparation seulement — l'envoi automatique n'est pas encore actif. Vous garderez la main.",
  classer: "Conservé dans la mémoire pour les prochains échanges.",
};

export default function NodeDetailPanel({ node, source, onClose }) {
  const [action, setAction] = useState(null);
  if (!node) return null;
  const dim = dimensionOf(node.dimension);
  // Action contextuelle : si ce nœud vient du dépôt affiché et qu'une action a été préparée.
  const plan = source?.plan_action && source.id === node.source_brute_id ? source.plan_action : null;
  const isDoc = plan && (plan.categorie === "facture" || plan.categorie === "devis");
  return (
    <div className="paper-grain letterpress-frame fixed inset-y-4 right-4 z-40 w-[min(420px,calc(100vw-2rem))] overflow-auto bg-paper p-5">
      <div className="relative z-10 mb-5 flex items-center justify-between gap-3">
        <p className="font-display text-xs uppercase tracking-[0.25em]" style={{ color: dim.color }}>{dim.name}</p>
        <button onClick={onClose} className="min-h-10 border-2 border-ink/30 px-3 font-display text-xs uppercase tracking-wide text-ink/60 transition-colors hover:bg-ink hover:text-paper">Fermer</button>
      </div>
      <h2 className="relative z-10 font-heading text-2xl font-semibold text-ink">{node.titre}</h2>
      <div className="relative z-10 mt-3"><MaturationBadge state={node.etat_maturation} /></div>
      <p className="relative z-10 mt-5 whitespace-pre-wrap font-body text-sm leading-6 text-ink/70">{node.contenu_enrichi || "Aucun contenu enrichi."}</p>
      {plan && <div className="mt-5"><ActionPlan plan={plan} compact /></div>}
      {isDoc && (
        <div className="mt-4">
          <p className="mb-2 text-[11px] uppercase tracking-[0.18em] text-neutral-400 dark:text-slate-500">Actions proposées</p>
          <ActionPicker categorie={plan.categorie} active={action} onPick={setAction} />
          {(action === "generer" || action === "completer") && <PreparedDocument plan={plan} />}
          {action && PREP_MESSAGES[action] && (
            <p className="mt-3 rounded-xl border border-neutral-200 bg-neutral-50 p-3 text-xs leading-5 text-neutral-600 dark:border-white/10 dark:bg-white/[0.04] dark:text-slate-300">{PREP_MESSAGES[action]}</p>
          )}
        </div>
      )}
      <div className="relative z-10 mt-5 border border-ink/15 bg-ink/[0.03] p-4">
        <p className="font-display text-xs uppercase tracking-[0.2em] text-ink/45">Raison de classification</p>
        <p className="mt-2 font-body text-sm leading-6 text-ink/70">{node.raison_classification || "Raison à enrichir."}</p>
      </div>
      <div className="relative z-10 mt-4 grid grid-cols-2 gap-3 text-sm text-ink/70">
        <Info label="Confiance" value={`${node.confiance_ia || 0}%`} />
        <Info label="Sous-dimension" value={node.sous_dimension || "—"} />
      </div>
    </div>
  );
}

function Info({ label, value }) {
  return <div className="border border-ink/15 bg-ink/[0.03] p-3"><span className="block font-display text-xs uppercase tracking-wide text-ink/45">{label}</span><b className="text-ink">{value}</b></div>;
}