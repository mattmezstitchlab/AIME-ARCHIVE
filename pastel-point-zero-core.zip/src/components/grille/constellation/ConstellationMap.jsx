import React from "react";
import { lireConstellation } from "@/lib/plume/constellation";

// Le ciel familial — chaque personne présente est une étoile qui brille,
// chaque place vide est un halo pâle en attente d'être rallumé (le non-dit à transmuter).
// Disposé en cercle, sobre et subtil : ni arbre généalogique froid, ni schéma clinique.
export default function ConstellationMap({ nodes = [], size = 320, onSelect }) {
  const { personnes, rallumee } = lireConstellation(nodes);
  const radius = size / 2;
  const orbit = radius - 46;
  const count = Math.max(personnes.length, 1);

  return (
    <div className="relative" style={{ width: size, height: size }}>
      {/* Halo central : la lumière de la lignée, d'autant plus vive que tout est rallumé */}
      <div
        className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full bg-white/80 blur-2xl transition-all duration-1000"
        style={{ width: 40 + rallumee * 120, height: 40 + rallumee * 120, opacity: 0.15 + rallumee * 0.55 }}
      />
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="absolute inset-0">
        <circle cx={radius} cy={radius} r={orbit} fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="1" />
      </svg>

      {personnes.map((n, i) => {
        const angle = (i / count) * 2 * Math.PI - Math.PI / 2;
        const x = radius + orbit * Math.cos(angle);
        const y = radius + orbit * Math.sin(angle);
        const absent = n.presence_state === "absent" || n.manque_probable || n.silence_significatif;
        return (
          <button
            key={n.id || i}
            onClick={() => onSelect?.(n)}
            className="absolute -translate-x-1/2 -translate-y-1/2 flex flex-col items-center gap-1.5 group"
            style={{ left: x, top: y }}
          >
            <span
              className={`block rounded-full transition-all duration-700 ${
                absent
                  ? "h-5 w-5 bg-transparent ring-1 ring-white/40 ring-dashed"
                  : "h-3.5 w-3.5 bg-white shadow-[0_0_16px_4px_rgba(255,255,255,0.7)]"
              } group-hover:scale-125`}
            />
            <span className={`max-w-[90px] text-center text-[10px] leading-tight ${absent ? "text-white/45" : "text-white/85"}`}>
              {n.titre}
            </span>
          </button>
        );
      })}

      {personnes.length === 0 && (
        <p className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 px-8 text-center text-[11px] text-white/40">
          Dépose ta famille, et je verrai qui brille et qui manque.
        </p>
      )}
    </div>
  );
}