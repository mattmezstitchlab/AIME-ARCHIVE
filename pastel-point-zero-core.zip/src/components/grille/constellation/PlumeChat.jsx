import React, { useEffect, useRef, useState } from "react";
import { Send, Loader2, Volume2 } from "lucide-react";
import { base44 } from "@/api/base44Client";

// LE module central du concept : le bloc conversationnel avec PLUME.
// Toujours visible. Le message de PLUME s'affiche dedans dès l'arrivée.
// On discute pour faire connaissance, parler mariage, remplir les manques.
// Selon les infos manquantes, PLUME propose des chips de réponses cohérentes :
// un clic → l'organisation avance avec fluidité.
// Chips d'accueil selon le rôle — PLUME n'ouvre pas la même conversation avec tout le monde.
const CHIPS_ACCUEIL = {
  futur_marie: ["On fixe la date", "Parlons famille", "J'ai un souci", "Qui inviter ?"],
  future_mariee: ["On fixe la date", "Parlons famille", "J'ai un souci", "Qui inviter ?"],
  prestataire: ["Mes prochaines dates", "Des mariés me cherchent ?", "Ma fiche technique", "Mes dispos"],
  lieu: ["Mes disponibilités", "Des mariés me cherchent ?", "Ma capacité", "Mes contraintes"],
  temoin: ["Mes missions", "Le discours", "EVJF / EVG", "La logistique"],
  famille: ["Mon rôle le jour J", "Ma place", "Un sujet délicat", "Ma présence"],
  invite: ["Je confirme ma présence", "Mon régime", "L'accès au lieu", "Mes musiques"],
};

const ACCUEIL_DEFAUT = {
  futur_marie: "Alors, on se marie ? Raconte-moi tout — qui, quand, et ce qui te trotte dans la tête.",
  future_mariee: "Alors, on se marie ? Raconte-moi tout — qui, quand, et ce qui te trotte dans la tête.",
  prestataire: "Ravie de t'avoir dans mon carnet ! On parle de tes prochaines prestations — dispos, cachet, ou des mariés qui te cherchent ?",
  lieu: "Content de t'avoir ! Voyons tes dispos et les mariés qui cherchent un lieu comme le tien.",
  temoin: "Le témoin, personne clé ! On cale tes missions et ta coordination avec les mariés ?",
  famille: "Ravie de te connaître. Parlons de ta place le jour J, en douceur.",
  invite: "Bienvenue ! Confirme-moi ta présence et tes petites infos pratiques.",
};

export default function PlumeChat({ sourceId, onSpeak, role }) {
  const [messages, setMessages] = useState([]);
  const [chips, setChips] = useState([]);
  const [input, setInput] = useState("");
  const [thinking, setThinking] = useState(false);
  const [booting, setBooting] = useState(true);
  const endRef = useRef(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, thinking, chips]);

  // Message d'accueil de PLUME — elle ouvre la conversation.
  useEffect(() => {
    base44.functions
      .invoke("plumeMessage", sourceId ? { source_id: sourceId } : {})
      .then((res) => {
        const fallback = ACCUEIL_DEFAUT[role] || ACCUEIL_DEFAUT.futur_marie;
        setMessages([{ role: "plume", content: res.data?.message || fallback }]);
        setChips(CHIPS_ACCUEIL[role] || CHIPS_ACCUEIL.futur_marie);
      })
      .catch(() =>
        setMessages([{ role: "plume", content: ACCUEIL_DEFAUT[role] || ACCUEIL_DEFAUT.futur_marie }])
      )
      .finally(() => setBooting(false));
  }, [sourceId, role]);

  const sendText = async (text) => {
    if (!text || thinking) return;
    const next = [...messages, { role: "user", content: text }];
    setMessages(next);
    setChips([]);
    setInput("");
    setThinking(true);
    try {
      const res = await base44.functions.invoke("plumeConverse", {
        message: text,
        history: next,
        source_id: sourceId,
      });
      const reponse = res.data?.reponse || "…";
      setMessages([...next, { role: "plume", content: reponse }]);
      setChips(res.data?.chips || []);
    } catch (_e) {
      setMessages([...next, { role: "plume", content: "Je me suis perdue un instant. Redis-moi ?" }]);
    } finally {
      setThinking(false);
    }
  };

  const submit = (e) => {
    e.preventDefault();
    sendText(input.trim());
  };

  return (
    <div className="w-full overflow-hidden rounded-3xl bg-black/30 ring-1 ring-white/10 backdrop-blur-xl">
      <div className="max-h-[38vh] min-h-[88px] space-y-2 overflow-y-auto p-3">
        {booting ? (
          <div className="flex items-center gap-2 text-[12px] text-white/50">
            <Loader2 className="h-3 w-3 animate-spin" /> PLUME arrive…
          </div>
        ) : (
          messages.map((m, i) => (
            <div key={i} className={m.role === "user" ? "flex justify-end" : "flex justify-start"}>
              <div
                className={`max-w-[82%] rounded-2xl px-3 py-1.5 text-[12.5px] leading-snug ${
                  m.role === "user"
                    ? "bg-white text-black"
                    : "bg-white/10 text-white/90 ring-1 ring-white/10"
                }`}
              >
                {m.role === "plume" && onSpeak && (
                  <button
                    onClick={() => onSpeak(m.content)}
                    aria-label="Écouter"
                    className="float-right ml-2 mt-0.5 text-white/40 transition-colors hover:text-white"
                  >
                    <Volume2 className="h-3.5 w-3.5" />
                  </button>
                )}
                {m.content}
              </div>
            </div>
          ))
        )}
        {thinking && (
          <div className="flex justify-start">
            <span className="flex items-center gap-2 rounded-2xl bg-white/10 px-3.5 py-2 text-[13px] text-white/50 ring-1 ring-white/10">
              <Loader2 className="h-3.5 w-3.5 animate-spin" /> PLUME réfléchit…
            </span>
          </div>
        )}
        <div ref={endRef} />
      </div>

      {/* Chips de réponses — plus petits, un clic fait avancer l'organisation */}
      {chips.length > 0 && !thinking && (
        <div className="flex flex-wrap gap-1.5 px-3 pb-2.5">
          {chips.map((c, i) => (
            <button
              key={i}
              onClick={() => sendText(c)}
              className="rounded-full bg-white/10 px-2.5 py-1 text-[11px] font-medium text-white/85 ring-1 ring-white/15 transition-all hover:bg-white/20 hover:ring-white/35"
            >
              {c}
            </button>
          ))}
        </div>
      )}

      {/* Barre de saisie intégrée dans le même bloc — plus d'espace à droite */}
      <form onSubmit={submit} className="flex items-center gap-2 border-t border-white/10 p-2 pl-4">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Réponds à PLUME…"
          className="min-w-0 flex-1 bg-transparent text-sm text-white placeholder:text-white/40 outline-none"
        />
        <button
          type="submit"
          disabled={thinking || !input.trim()}
          aria-label="Envoyer"
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-white text-black transition-all hover:bg-white/90 disabled:bg-white/15 disabled:text-white/40"
        >
          {thinking ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
        </button>
      </form>
    </div>
  );
}