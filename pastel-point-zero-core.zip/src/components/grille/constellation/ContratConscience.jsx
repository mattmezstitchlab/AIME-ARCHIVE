import React from "react";
import { ScrollText, Shield, Sparkles } from "lucide-react";

// Le Contrat de Conscience — scellé quand toute la constellation est rallumée.
// Un consentement familial : reconnaître, cesser de rejouer, transmettre la lumière,
// protéger l'homme, la femme et les enfants des dettes anciennes.
export default function ContratConscience({ contrat }) {
  if (!contrat) return null;
  return (
    <div className="mx-auto max-w-xl rounded-2xl border border-white/15 bg-white/[0.03] p-7 backdrop-blur-md">
      <div className="mb-5 flex items-center gap-2 text-white/90">
        <ScrollText className="h-5 w-5" />
        <h2 className="text-lg font-semibold tracking-tight">{contrat.titre}</h2>
      </div>
      {contrat.lignee && <p className="mb-4 text-sm italic text-white/60">{contrat.lignee}</p>}
      {contrat.preambule && <p className="mb-5 text-sm leading-relaxed text-white/80">{contrat.preambule}</p>}

      {contrat.non_dits_reconnus?.length > 0 && (
        <div className="mb-5">
          <p className="mb-2 flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wide text-white/50">
            <Sparkles className="h-3.5 w-3.5" /> Ce qui est reconnu et transmuté
          </p>
          <ul className="space-y-1.5">
            {contrat.non_dits_reconnus.map((t, i) => (
              <li key={i} className="text-sm leading-relaxed text-white/70">— {t}</li>
            ))}
          </ul>
        </div>
      )}

      {contrat.engagements?.length > 0 && (
        <div className="mb-5">
          <p className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-white/50">Nos engagements</p>
          <ul className="space-y-2">
            {contrat.engagements.map((t, i) => (
              <li key={i} className="flex gap-2 text-sm leading-relaxed text-white/85">
                <span className="text-white/40">{String(i + 1).padStart(2, "0")}</span>
                <span>{t}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {contrat.generation_suivante && (
        <div className="rounded-xl border border-white/10 bg-white/[0.04] p-4">
          <p className="mb-1.5 flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wide text-white/50">
            <Shield className="h-3.5 w-3.5" /> Pour la génération suivante
          </p>
          <p className="text-sm leading-relaxed text-white/80">{contrat.generation_suivante}</p>
        </div>
      )}
    </div>
  );
}