import React from "react";

// Tiroir dédié : tout ce que le système a vu mais pas encore réussi à classer.
export default function GreyZonePanel({ fragments = [], sources = [] }) {
  const greyFragments = fragments.filter((f) => f.zone_grise || f.statut === "ambigu" || f.statut === "non_classe");
  const greyZones = sources.flatMap((s) => (s.zones_grises || []).map((z) => ({ texte: z, comprehension: s.comprehension_brute })));

  if (!greyFragments.length && !greyZones.length) {
    return <p className="text-sm leading-6 text-neutral-400">Aucune zone grise pour l’instant. Tout ce qui a été déposé a pu être compris ou rangé.</p>;
  }

  return (
    <div className="space-y-4">
      <p className="text-sm text-neutral-400">Vu par le système, mais pas encore classé dans les 12 dimensions.</p>

      {greyFragments.length > 0 && (
        <div className="space-y-2">
          <p className="text-[10px] uppercase tracking-[0.22em] text-orange-300">Fragments non classés · {greyFragments.length}</p>
          {greyFragments.map((f) => (
            <div key={f.id} className="rounded-lg border border-orange-300/20 bg-orange-400/[0.06] p-3">
              <p className="text-sm text-neutral-100">{f.contenu_fragment}</p>
              {f.comprehension_fragment && <p className="mt-1 text-xs text-neutral-400">{f.comprehension_fragment}</p>}
              <div className="mt-2 flex items-center gap-2 text-[10px] text-neutral-500">
                <span className="rounded bg-white/[0.06] px-2 py-0.5 uppercase tracking-wide text-orange-300">{f.statut}</span>
                {typeof f.confiance === "number" && <span>confiance {f.confiance}%</span>}
              </div>
            </div>
          ))}
        </div>
      )}

      {greyZones.length > 0 && (
        <div className="space-y-2">
          <p className="text-[10px] uppercase tracking-[0.22em] text-orange-300">Zones grises des sources · {greyZones.length}</p>
          {greyZones.map((z, i) => (
            <div key={i} className="rounded-lg border border-white/[0.06] bg-neutral-800/40 p-3">
              <p className="text-sm text-neutral-200">{z.texte}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}