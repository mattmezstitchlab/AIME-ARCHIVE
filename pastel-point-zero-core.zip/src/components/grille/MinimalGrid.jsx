import React from "react";
import { DIMENSIONS } from "./config";
import { glyphForNode, readableOn } from "./glyph";

// Grille centrale discrète. Les cases s'allument seulement là où des éléments
// ont été rangés. Le SIGNE vient d'abord : chaque case porte son symbole vivant
// (− absence · ▲ alerte · × risque · ÷ budget · = validé · → étape · ◐ détecté…).
export default function MinimalGrid({ nodes = [], onNodeSelect }) {
  const cells = Array.from({ length: 144 }).map((_, index) => {
    const dim = DIMENSIONS[index % DIMENSIONS.length];
    const node = nodes.filter((n) => n.dimension === dim.key)[Math.floor(index / DIMENSIONS.length)];
    return { id: `${dim.key}-${index}`, dim, node };
  });
  return (
    <div className="grid h-full w-full grid-cols-12 gap-1.5">
      {cells.map((cell) => {
        if (!cell.node) {
          return <div key={cell.id} className="aspect-square rounded-md bg-white/[0.04]" />;
        }
        const node = cell.node;
        const glyph = glyphForNode(node);
        // Le signe reste prioritaire : contraste automatique (noir ou blanc) selon la couleur de fond.
        const glyphColor = readableOn(cell.dim.color);
        // Pastille de contraste : claire sur fond foncé, foncée sur fond clair.
        const chipBg = glyphColor === "#FFFFFF" ? "rgba(0,0,0,0.28)" : "rgba(255,255,255,0.55)";
        // Case d'absence : grisée, pointillée — "il manque probablement ici quelque chose".
        const isAbsence = node.presence_state === "absent" || node.manque_probable || node.silence_significatif;
        if (isAbsence) {
          return (
            <button
              key={cell.id}
              onClick={() => onNodeSelect?.(node)}
              title={`${cell.dim.name} · manque probable — ${node.titre}`}
              className="flex aspect-square items-center justify-center rounded-md border border-dashed border-amber-400/50 bg-amber-400/10 text-[12px] font-bold text-amber-400 transition-transform hover:scale-[1.08] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400"
            >
              −
            </button>
          );
        }
        return (
          <button
            key={cell.id}
            onClick={() => onNodeSelect?.(node)}
            title={`${cell.dim.name} · ${node.titre}`}
            className="group relative flex aspect-square items-center justify-center rounded-[5px] border border-white/40 transition-transform hover:scale-[1.08] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-neutral-400"
            style={{ backgroundColor: cell.dim.color, boxShadow: `0 0 16px ${cell.dim.color}66` }}
          >
            <span
              className="flex h-[64%] w-[64%] items-center justify-center rounded-full text-[11px] font-extrabold leading-none"
              style={{ color: glyphColor, backgroundColor: chipBg }}
            >
              {glyph}
            </span>
          </button>
        );
      })}
    </div>
  );
}