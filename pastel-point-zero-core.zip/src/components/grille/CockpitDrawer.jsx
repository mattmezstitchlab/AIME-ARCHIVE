import React from "react";

const positions = {
  top: "left-4 right-4 top-4 max-h-[45vh]",
  bottom: "bottom-4 left-4 right-4 max-h-[45vh]",
  left: "bottom-4 left-4 top-4 w-[min(420px,calc(100vw-2rem))]",
  right: "bottom-4 right-4 top-4 w-[min(420px,calc(100vw-2rem))]"
};

export default function CockpitDrawer({ open, side = "right", title, onClose, children }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-30 bg-ink/40 backdrop-blur-sm" onClick={onClose}>
      <aside onClick={(e) => e.stopPropagation()} className={`paper-grain letterpress-frame absolute overflow-auto bg-paper p-5 ${positions[side]}`}>
        <div className="relative z-10 mb-4 flex items-center justify-between gap-3 border-b-2 border-ink/20 pb-3">
          <h2 className="font-display text-sm uppercase tracking-[0.22em] text-ink">{title}</h2>
          <button onClick={onClose} className="min-h-10 border-2 border-ink/30 px-3 font-display text-xs uppercase tracking-wide text-ink/60 transition-colors hover:bg-ink hover:text-paper">Fermer</button>
        </div>
        <div className="relative z-10">{children}</div>
      </aside>
    </div>
  );
}