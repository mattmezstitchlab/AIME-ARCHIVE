import React from "react";
import { Check } from "lucide-react";
import MaturationBadge from "../MaturationBadge";
import { dimensionOf } from "../config";

export default function NodeCardCompact({ node, onAccept, onValidate }) {
  const dim = dimensionOf(node.dimension);
  return (
    <div className="rounded-xl border border-white/10 bg-white/[0.04] p-3">
      <div className="flex items-start justify-between gap-2">
        <b className="text-sm text-white">{node.titre}</b>
        <MaturationBadge state={node.etat_maturation} />
      </div>
      <p className="mt-1.5 text-xs" style={{ color: dim.color }}>{dim.icon} {dim.name}{node.sous_dimension ? ` · ${node.sous_dimension}` : ""}</p>
      <p className="mt-1 text-[11px] text-slate-400">Confiance {node.confiance_ia || 0}%</p>
      <div className="mt-2.5 flex gap-2">
        <button onClick={() => onAccept(node)} className="rounded-lg bg-cyan-400/15 px-2.5 py-1.5 text-xs text-cyan-200 hover:bg-cyan-400/25"><Check className="mr-1 inline h-3 w-3" />Accepter</button>
        <button onClick={() => onValidate(node)} className="rounded-lg bg-amber-400/15 px-2.5 py-1.5 text-xs text-amber-200 hover:bg-amber-400/25">★ Valider</button>
      </div>
    </div>
  );
}