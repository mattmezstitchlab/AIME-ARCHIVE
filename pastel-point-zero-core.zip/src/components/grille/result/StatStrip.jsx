import React from "react";

// Mini-calculatrice universelle. Discrète, en haut du Résultat. N'affiche que ce qui est détecté.
export default function StatStrip({ source, nodes = [], fragments = [], greyCount = 0 }) {
  const stats = [];

  // Budget détecté (€) — pris du premier nœud économie qui contient un nombre.
  const eco = nodes.find((n) => n.dimension === "economie" && /\d/.test(n.titre || ""));
  if (eco) stats.push({ sym: "÷", label: "Budget", value: (eco.titre.match(/[\d\s.,]+\s?€?/) || [eco.titre])[0].trim() });

  const persons = nodes.filter((n) => n.dimension === "personnes" && n.presence_state !== "absent").length;
  if (persons) stats.push({ sym: "+", label: "Personnes", value: persons });

  const actions = nodes.filter((n) => n.dimension === "actions" && n.presence_state !== "absent").length;
  if (actions) stats.push({ sym: "→", label: "Actions", value: actions });

  const risks = nodes.filter((n) => n.role === "risque" || (n.risques || []).length).length;
  if (risks) stats.push({ sym: "×", label: "Risques", value: risks });

  if (greyCount) stats.push({ sym: "?", label: "À clarifier", value: greyCount });

  const valides = nodes.filter((n) => n.etat_maturation === "valide").length;
  if (valides) stats.push({ sym: "=", label: "Validés", value: valides });

  if (!stats.length) return null;

  return (
    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 rounded-xl border border-white/5 bg-black/30 px-3 py-2 font-mono text-[11px] text-slate-400">
      {stats.map((s, i) => (
        <span key={i} className="flex items-center gap-1.5">
          <span className="text-slate-500">{s.sym}</span>
          {s.label} <b className="text-slate-200">{s.value}</b>
        </span>
      ))}
    </div>
  );
}