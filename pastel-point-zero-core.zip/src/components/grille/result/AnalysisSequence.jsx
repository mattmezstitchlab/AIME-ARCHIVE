import React, { useEffect, useState } from "react";

// Séquence d'analyse "wow" : les blocs d'étapes apparaissent un à un, en défilant,
// pendant que le moteur travaille. Palette unifiée (gris/blanc, un seul accent blanc).
// Une fois toutes les étapes révélées, onDone() est appelé pour dévoiler le rapport.
export default function AnalysisSequence({ steps = [], onDone, interval = 700 }) {
  const [visible, setVisible] = useState(0);

  useEffect(() => {
    if (!steps.length) { onDone?.(); return; }
    setVisible(0);
    let i = 0;
    const id = setInterval(() => {
      i += 1;
      setVisible(i);
      if (i >= steps.length) {
        clearInterval(id);
        setTimeout(() => onDone?.(), 600);
      }
    }, interval);
    return () => clearInterval(id);
  }, [steps]);

  return (
    <div className="space-y-2.5">
      {steps.slice(0, visible).map((s, i) => {
        const isLast = i === visible - 1;
        return (
          <div
            key={i}
            className="flex items-center gap-3 rounded-2xl bg-white/[0.04] px-4 py-3 ring-1 ring-white/[0.06]"
            style={{ animation: "azFade 0.45s ease-out both" }}
          >
            <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-white/10 text-[11px] font-semibold text-foreground/70 tabular-nums">
              {i + 1}
            </span>
            <span className="min-w-0 flex-1 truncate text-[14px] font-light text-foreground/90">{s}</span>
            {isLast && i < steps.length - 1 ? (
              <span className="h-3.5 w-3.5 shrink-0 animate-spin rounded-full border-2 border-white/20 border-t-foreground/70" />
            ) : (
              <span className="shrink-0 text-[13px] text-foreground/40">✓</span>
            )}
          </div>
        );
      })}
      <style>{`@keyframes azFade { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }`}</style>
    </div>
  );
}