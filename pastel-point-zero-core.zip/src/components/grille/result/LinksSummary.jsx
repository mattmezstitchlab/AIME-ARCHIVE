import React, { useState } from "react";

// Niveau 4 — caché pour les agents. Résumé chiffré d'abord, détails techniques sur demande.
export default function LinksSummary({ links = [], nodes = [] }) {
  const [open, setOpen] = useState(false);
  if (!links.length && !nodes.length) return null;

  const dependances = links.filter((l) => l.type_lien === "depend_de").length;
  const risques = nodes.filter((n) => n.role === "risque" || (n.risques || []).length).length;
  const validations = nodes.filter((n) => (n.projections_candidates || n.projections_possibles || []).length).length;

  const counts = [
    { sym: "◎", label: `${links.length} lien${links.length > 1 ? "s" : ""} détecté${links.length > 1 ? "s" : ""}`, show: links.length > 0 },
    { sym: "→", label: `${dependances} dépendance${dependances > 1 ? "s" : ""}`, show: dependances > 0 },
    { sym: "=", label: `${validations} validation${validations > 1 ? "s" : ""} possible${validations > 1 ? "s" : ""}`, show: validations > 0 },
    { sym: "×", label: `${risques} risque${risques > 1 ? "s" : ""}`, show: risques > 0 },
  ].filter((c) => c.show);

  return (
    <div className="rounded-2xl border border-white/10 bg-black/20 p-4">
      <p className="text-xs uppercase tracking-[0.2em] text-slate-400">Caché pour les agents</p>
      <div className="mt-2.5 flex flex-wrap gap-x-4 gap-y-1.5 font-mono text-xs text-slate-300">
        {counts.map((c, i) => (
          <span key={i} className="flex items-center gap-1.5"><span className="text-slate-500">{c.sym}</span>{c.label}</span>
        ))}
      </div>
      {links.length > 0 && (
        <>
          <button onClick={() => setOpen(!open)} className="mt-3 text-xs font-medium text-cyan-300 hover:text-cyan-200">
            {open ? "Masquer les détails techniques" : "Voir détails techniques"}
          </button>
          {open && (
            <div className="mt-2.5 space-y-1.5 border-t border-white/5 pt-2.5">
              {links.map((l) => (
                <p key={l.id} className="font-mono text-[11px] text-slate-500">◎ {l.type_lien} · force {l.force}% · {l.direction}</p>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}