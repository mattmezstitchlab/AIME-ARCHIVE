import React, { useState } from "react";
import { ChevronDown } from "lucide-react";

export default function Collapsible({ title, count, defaultOpen = false, accent, children }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="rounded-2xl border border-neutral-200 bg-neutral-50 dark:border-white/10 dark:bg-black/20">
      <button onClick={() => setOpen(!open)} className="flex w-full items-center justify-between gap-3 px-4 py-3 text-left">
        <span className="flex items-center gap-2 text-sm font-semibold text-neutral-800 dark:text-white">
          {title}
          {count != null && <span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${accent || "bg-neutral-200 text-neutral-600 dark:bg-white/10 dark:text-slate-300"}`}>{count}</span>}
        </span>
        <ChevronDown className={`h-4 w-4 shrink-0 text-neutral-400 transition-transform ${open ? "rotate-180" : ""}`} />
      </button>
      {open && <div className="border-t border-neutral-200 px-4 py-3 dark:border-white/5">{children}</div>}
    </div>
  );
}