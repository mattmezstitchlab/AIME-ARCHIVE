import React from "react";
import { AlertTriangle } from "lucide-react";

export default function GreyZoneList({ items = [], onClarify }) {
  if (!items.length) return null;
  return (
    <div className="rounded-2xl border border-orange-300/20 bg-orange-400/5 p-4">
      <p className="flex items-center gap-2 text-xs uppercase tracking-[0.2em] text-orange-300">
        <AlertTriangle className="h-3.5 w-3.5" /> Zones grises — à clarifier
      </p>
      <div className="mt-3 space-y-2">
        {items.map((z, i) => (
          <div key={i} className="rounded-xl border border-orange-300/15 bg-black/20 p-3">
            <p className="text-sm text-slate-200">{z.texte}</p>
            <p className="mt-1 text-xs text-orange-200/80">{z.raison || "Signification incertaine"}{z.confiance != null && ` · confiance ${z.confiance}%`}</p>
            {onClarify && (
              <button onClick={() => onClarify(z)} className="mt-2 rounded-lg bg-orange-400/15 px-2.5 py-1.5 text-xs font-medium text-orange-200 hover:bg-orange-400/25">
                Clarifier
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}