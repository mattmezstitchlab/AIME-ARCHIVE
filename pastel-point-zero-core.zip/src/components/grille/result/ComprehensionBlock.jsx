import React, { useState } from "react";

export default function ComprehensionBlock({ text }) {
  const [expanded, setExpanded] = useState(false);
  if (!text) return null;
  const isLong = text.length > 320;
  const shown = expanded || !isLong ? text : text.slice(0, 320).trim() + "…";
  return (
    <div className="rounded-2xl border border-cyan-200/10 bg-cyan-400/5 p-4">
      <p className="text-xs uppercase tracking-[0.2em] text-cyan-200">Compréhension brute</p>
      <p className="mt-2 text-sm leading-6 text-slate-200">{shown}</p>
      {isLong && (
        <button onClick={() => setExpanded(!expanded)} className="mt-2 text-xs font-medium text-cyan-300 hover:text-cyan-200">
          {expanded ? "Voir moins" : "Voir plus"}
        </button>
      )}
    </div>
  );
}