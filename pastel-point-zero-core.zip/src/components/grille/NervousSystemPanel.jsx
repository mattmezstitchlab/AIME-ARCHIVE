import React, { useState } from "react";
import { Trash2 } from "lucide-react";

export default function NervousSystemPanel({ sourcesCount = 0, fragments = [], nodes = [], links = [], onCleanTests }) {
  const reasoned = nodes.filter((n) => n.raison_classification).length;
  const projected = nodes.filter((n) => (n.projections_possibles || []).length).length;
  const gray = nodes.filter((n) => n.etat_maturation === "ambigu").length;
  const [cleaning, setCleaning] = useState(false);
  const [confirm, setConfirm] = useState(false);

  const handleClean = async () => {
    setCleaning(true);
    await onCleanTests?.();
    setCleaning(false);
    setConfirm(false);
  };

  return (
    <section className="rounded-[2rem] border border-cyan-300/15 bg-slate-950/75 p-5 shadow-xl shadow-cyan-950/10">
      <p className="text-xs uppercase tracking-[0.25em] text-cyan-200">Système nerveux · historique</p>
      <h2 className="mt-2 text-xl font-semibold text-white">Mémoire lisible par les agents</h2>
      <p className="mt-2 text-sm leading-6 text-slate-400">Sources, fragments, nœuds et liens restent lisibles pour les agents IA, pendant que l’humain navigue par la grille.</p>
      <div className="mt-5 grid grid-cols-2 gap-3 md:grid-cols-3">
        <Metric label="Sources" value={sourcesCount} />
        <Metric label="Fragments" value={fragments.length} />
        <Metric label="Nœuds" value={nodes.length} />
        <Metric label="Liens" value={links.length} />
        <Metric label="Raisons" value={reasoned} />
        <Metric label="Zones grises" value={gray} accent="text-orange-300" />
      </div>
      <p className="mt-4 rounded-2xl border border-white/10 bg-white/[0.03] p-3 text-xs leading-5 text-slate-400">{projected} nœud(s) portent déjà une projection possible. L’exécution reste réservée aux nœuds prêts ou validés.</p>

      <div className="mt-5 border-t border-white/10 pt-4">
        {!confirm ? (
          <button onClick={() => setConfirm(true)} className="flex items-center gap-2 text-xs font-medium text-slate-500 hover:text-red-300">
            <Trash2 className="h-3.5 w-3.5" /> Nettoyer les tests
          </button>
        ) : (
          <div className="rounded-xl border border-red-400/20 bg-red-500/5 p-3">
            <p className="text-xs text-slate-300">Supprimer toutes les sources, fragments, nœuds et liens pour repartir sur une base propre ?</p>
            <div className="mt-2.5 flex gap-2">
              <button onClick={handleClean} disabled={cleaning} className="rounded-lg bg-red-500/20 px-3 py-1.5 text-xs font-semibold text-red-200 hover:bg-red-500/30 disabled:opacity-50">
                {cleaning ? "Nettoyage…" : "Confirmer"}
              </button>
              <button onClick={() => setConfirm(false)} className="rounded-lg bg-white/5 px-3 py-1.5 text-xs text-slate-300 hover:bg-white/10">Annuler</button>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}

function Metric({ label, value, accent = "text-white" }) {
  return <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-3"><b className={`block font-mono text-2xl ${accent}`}>{value}</b><span className="text-xs text-slate-400">{label}</span></div>;
}