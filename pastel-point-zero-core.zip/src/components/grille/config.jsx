export const DIMENSIONS = [
  { key: "temps", name: "Temps", color: "#00D4FF", light: "#93C5FD", icon: "◷", description: "Dates, heures, durées, séquences, délais, cycles et mémoire temporelle.", sub: ["Date", "Heure", "Durée", "Séquence"], examples: ["14h00 cérémonie", "J-120", "première danse"] },
  { key: "espace", name: "Espace", color: "#4ADE80", light: "#86EFAC", icon: "⌖", description: "Lieux, zones, accès, capacités, distances, plans et contraintes physiques.", sub: ["Lieu", "Zone", "Accès", "Ambiance"], examples: ["château", "parking", "salle"] },
  { key: "personnes", name: "Personnes", color: "#3B82F6", light: "#93C5FD", icon: "◉", description: "Identités, rôles, responsabilités, relations humaines, contacts et groupes.", sub: ["Identité", "Rôle", "Relation", "Responsabilité"], examples: ["mariée", "témoin", "traiteur"] },
  { key: "ressources", name: "Ressources", color: "#F59E0B", light: "#FCD34D", icon: "▣", description: "Moyens mobilisables : matériel, prestations, stocks, allocations et manques.", sub: ["Budget", "Matériel", "Prestation", "Manque"], examples: ["tables", "DJ", "stock"] },
  { key: "actions", name: "Actions", color: "#10B981", light: "#6EE7B7", icon: "▶", description: "Ce qui doit être fait, décidé, validé, rappelé ou débloqué après maturation.", sub: ["Tâche", "Décision", "Validation", "Blocage"], examples: ["confirmer", "réserver", "envoyer"] },
  { key: "documents", name: "Documents", color: "#6366F1", light: "#A5B4FC", icon: "▤", description: "Contrats, devis, factures, notes, photos, plans, formulaires et preuves.", sub: ["Contrat", "Devis", "Photo", "Facture"], examples: ["facture", "devis", "plan"] },
  { key: "memoire", name: "Mémoire", color: "#8B5CF6", light: "#C4B5FD", icon: "◌", description: "Souvenirs, histoires, traditions, archives, héritages et annotations du passé.", sub: ["Souvenir", "Histoire", "Tradition", "Archive"], examples: ["rencontre", "tradition", "archive"] },
  { key: "communication", name: "Communication", color: "#38BDF8", light: "#BAE6FD", icon: "✉", description: "Messages, canaux, destinataires, intentions, urgences et historiques d'échange.", sub: ["Message", "Canal", "Intention", "Urgence"], examples: ["SMS", "email", "appel"] },
  { key: "economie", name: "Économie", color: "#EAB308", light: "#FDE68A", icon: "€", description: "Budgets, postes, dépenses, paiements, soldes, prévisions et écarts.", sub: ["Budget total", "Poste", "Dépense", "Solde"], examples: ["3500€", "acompte", "reste"] },
  { key: "emotions", name: "Émotions", color: "#EC4899", light: "#F9A8D4", icon: "♡", description: "Attentes, peurs, joies, tensions, gratitude, regrets et intentions humaines.", sub: ["Attente", "Peur", "Joie", "Tension"], examples: ["stress", "joie", "merci"] },
  { key: "validation", name: "Validation", color: "#84CC16", light: "#BEF264", icon: "✓", description: "Décisions, approbations, refus, modifications, signatures et blocages humains.", sub: ["Décision", "Approbation", "Refus", "Signature"], examples: ["accord", "signé", "validé"] },
  { key: "relations", name: "Relations", color: "#E2E8F0", light: "#F8FAFC", icon: "↔", description: "Liens entre nœuds : dépendance, influence, conflit, héritage, rappel ou référence.", sub: ["Dépendance", "Séquence", "Conflit", "Influence"], examples: ["dépend de", "influence", "référence"] }
];

export const MATURATION = {
  vide: { label: "Vide", symbol: "○", color: "#94A3B8" },
  detecte: { label: "Détecté", symbol: "◐", color: "#CBD5E1" },
  illumine: { label: "Illuminé", symbol: "◕", color: "#00D4FF" },
  pret: { label: "Prêt", symbol: "●", color: "#10B981" },
  valide: { label: "Validé", symbol: "★", color: "#F59E0B" },
  ambigu: { label: "Ambigu", symbol: "▲", color: "#F97316" }
};

export const LINK_TYPES = ["complete", "contredit", "rappelle", "herite", "influence", "prepare", "declenche", "depend_de", "reference", "lie", "custom"];
export const dimensionOf = (key) => DIMENSIONS.find((d) => d.key === key) || { key: "custom", name: "Nouvelle catégorie", color: "#F97316", light: "#FDBA74", icon: "?", description: "Catégorie vivante proposée par la grille.", sub: [] };
export const matureStates = ["pret", "valide"];