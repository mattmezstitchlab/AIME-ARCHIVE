import React from "react";
import { Calendar, MapPin, Heart } from "lucide-react";

// Carte d'un couple en recherche, vue par un prestataire — sa demande potentielle.
export default function MatchCoupleCard({ item }) {
  return (
    <div className="rounded-2xl bg-white/5 p-4 ring-1 ring-white/10 transition-colors hover:bg-white/[0.07]">
      <div className="flex items-start gap-3">
        <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-white/10 ring-1 ring-white/15">
          <Heart className="h-5 w-5 text-rose-300" />
        </div>
        <div className="min-w-0 flex-1">
          <p className="truncate text-[15px] font-semibold text-white">{item.prenom}</p>
          <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11.5px] text-white/50">
            {item.date && (
              <span className="inline-flex items-center gap-1">
                <Calendar className="h-3 w-3" /> {item.date}
              </span>
            )}
            {item.lieu && (
              <span className="inline-flex items-center gap-1">
                <MapPin className="h-3 w-3" /> {item.lieu}
              </span>
            )}
            {item.budget && <span>Budget {item.budget}</span>}
          </div>
          {item.ambiance && <p className="mt-1.5 text-[12.5px] text-white/70">Ambiance : {item.ambiance}</p>}
        </div>
      </div>
    </div>
  );
}