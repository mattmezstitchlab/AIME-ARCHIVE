import React from "react";
import { MapPin, Sparkles } from "lucide-react";

// Carte d'un prestataire vue par un marié — le côté humain d'abord.
const HUMEUR_LABEL = {
  enthousiaste: "enthousiaste",
  posee: "posée",
  debordee: "très demandée",
  flexible: "flexible",
  selective: "sélective",
};

const STATUT = {
  disponible: { txt: "Disponible", cls: "text-emerald-300" },
  sur_demande: { txt: "Sur demande", cls: "text-amber-300" },
  complet: { txt: "Complet", cls: "text-white/40" },
};

export default function MatchPrestataireCard({ item }) {
  const statut = STATUT[item.statut_dispo] || STATUT.disponible;
  const tarif =
    item.tarif_min != null
      ? `${item.tarif_min}${item.tarif_max && item.tarif_max !== item.tarif_min ? ` – ${item.tarif_max}` : ""} €`
      : null;

  return (
    <div className="rounded-2xl bg-white/5 p-4 ring-1 ring-white/10 transition-colors hover:bg-white/[0.07]">
      <div className="flex items-start gap-3">
        <div className="flex h-11 w-11 shrink-0 items-center justify-center overflow-hidden rounded-full bg-white/10 ring-1 ring-white/15">
          {item.photo_url ? (
            <img src={item.photo_url} alt={item.nom} className="h-full w-full object-cover" />
          ) : (
            <Sparkles className="h-5 w-5 text-white/50" />
          )}
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex items-center justify-between gap-2">
            <p className="truncate text-[15px] font-semibold text-white">{item.nom}</p>
            <span className={`shrink-0 text-[11px] font-medium ${statut.cls}`}>{statut.txt}</span>
          </div>
          <p className="text-[12px] text-white/50">
            {item.metier_label}
            {item.specialite ? ` · ${item.specialite}` : ""}
          </p>
          {item.bio && <p className="mt-1.5 line-clamp-2 text-[12.5px] leading-snug text-white/70">{item.bio}</p>}
          <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-white/45">
            {item.ville && (
              <span className="inline-flex items-center gap-1">
                <MapPin className="h-3 w-3" /> {item.ville}
              </span>
            )}
            {tarif && <span>{tarif}</span>}
            <span>Humeur {HUMEUR_LABEL[item.humeur] || item.humeur}</span>
          </div>
        </div>
      </div>
    </div>
  );
}