import React, { useEffect, useState } from "react";
import { DIMENSIONS } from "./config";

// Cadran type montre : graduations radiales tout autour, croix au centre, aucune aiguille.
// — Au repos : graduations sobres, croix au centre.
// — Pendant l'analyse : les graduations s'illuminent une à une en cercle (balayage radial),
//   chaque tick prend la couleur d'une catégorie (nuancier) ; un tick BLANC = un manque détecté.
// — À la fin : le verdict s'affiche au centre ("Tu m'as donné 8 choses…").
//
// Props :
//   analyzing  : booléen, déclenche le balayage animé
//   ticks      : tableau de couleurs (hex) OU "#FFFFFF" pour un manque. Pilote la coloration finale.
//   verdict    : { given, understood, missing } — affiché au centre une fois l'analyse finie
//   audioLevel : 0→1, amplitude de la voix en cours — fait vibrer les graduations
//   children   : contenu central (ex: bouton Play) ; remplace la croix/verdict
//   size       : diamètre px (def. 220)
const TICK_COUNT = 60;

export default function DialFace({ analyzing = false, ticks = [], verdict = null, audioLevel = 0, children = null, size = 220 }) {
  const [sweep, setSweep] = useState(0); // index du balayage radial pendant l'analyse

  useEffect(() => {
    if (!analyzing) { setSweep(0); return; }
    let raf;
    const start = performance.now();
    const loop = (t) => {
      const elapsed = (t - start) / 1000;
      setSweep(Math.floor((elapsed * TICK_COUNT) % TICK_COUNT)); // ~1 tour/seconde
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [analyzing]);

  const radius = size / 2;
  const inner = radius - 18; // longueur depuis le centre jusqu'au pied du tick
  const outer = radius - 6;
  const speaking = audioLevel > 0.01;

  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="absolute inset-0">
        {Array.from({ length: TICK_COUNT }).map((_, i) => {
          const angle = (i / TICK_COUNT) * 2 * Math.PI - Math.PI / 2; // départ en haut

          // Quand PLUME parle : chaque graduation s'allonge au rythme de la voix.
          // On varie la pousse par tick (motif radial) pour un effet "égaliseur" organique.
          const wobble = speaking ? (0.6 + 0.4 * Math.sin(i * 0.8 + sweep)) : 0;
          const grow = speaking ? audioLevel * 12 * wobble : 0;
          const tInner = inner - grow * 0.4;
          const tOuter = outer + grow * 0.6;

          const x1 = radius + tInner * Math.cos(angle);
          const y1 = radius + tInner * Math.sin(angle);
          const x2 = radius + tOuter * Math.cos(angle);
          const y2 = radius + tOuter * Math.sin(angle);

          const color = ticks[i]; // couleur catégorie, blanc = manque, ou undefined
          const isMissing = color === "#FFFFFF";
          // Balayage : on illumine le tick courant et ceux juste derrière (traînée).
          const dist = (sweep - i + TICK_COUNT) % TICK_COUNT;
          const lit = analyzing && dist < 8;
          const litOpacity = analyzing ? Math.max(0.15, 1 - dist / 8) : 1;

          let stroke = "rgba(255,255,255,0.12)"; // repos
          let width = 1.5;
          let opacity = 1;

          if (color) {
            stroke = color;
            width = isMissing ? 2.5 : 2;
            opacity = isMissing ? 1 : 0.9;
          } else if (lit) {
            stroke = "rgba(255,255,255,0.85)";
            width = 2;
            opacity = litOpacity;
          }

          // Pendant la voix, on relève la luminosité des ticks au plus fort.
          if (speaking) {
            opacity = Math.min(1, opacity + audioLevel * 0.5 * wobble);
            if (!color) stroke = `rgba(255,255,255,${0.12 + audioLevel * 0.55 * wobble})`;
          }

          return (
            <line
              key={i}
              x1={x1} y1={y1} x2={x2} y2={y2}
              stroke={stroke}
              strokeWidth={width}
              strokeLinecap="round"
              opacity={opacity}
              className={speaking ? undefined : "transition-all duration-300"}
              style={isMissing ? { filter: "drop-shadow(0 0 3px rgba(255,255,255,0.9))" } : undefined}
            />
          );
        })}
      </svg>

      {/* Cœur du cadran — children prioritaire (ex: bouton Play), sinon verdict, sinon croix. */}
      <div className="absolute inset-0 flex items-center justify-center">
        {children ? children : verdict ? <Verdict {...verdict} /> : (
          // Croix centrale, aucune aiguille tant que rien n'est comblé.
          <span className="text-3xl font-extralight text-foreground/70">＋</span>
        )}
      </div>
    </div>
  );
}

// Le verdict au centre — sobre, percutant.
function Verdict({ given = 0, understood = 0, missing = 0 }) {
  return (
    <div className="px-8 text-center">
      <p className="text-[13px] leading-relaxed text-muted-foreground">
        Tu m'as donné <b className="text-foreground">{given}</b> chose{given > 1 ? "s" : ""}.
      </p>
      <p className="mt-0.5 text-[13px] leading-relaxed text-muted-foreground">
        J'en ai compris <b className="text-foreground">{understood}</b>.
      </p>
      {missing > 0 && (
        <p className="mt-1.5 text-[15px] font-semibold text-foreground">
          Mais <span className="text-white">{missing}</span> manque{missing > 1 ? "nt" : ""}.
        </p>
      )}
    </div>
  );
}

// Construit le tableau de ticks colorés à partir des nœuds analysés.
// Chaque nœud "présent" pose un tick de la couleur de sa dimension ; chaque manque pose un tick blanc.
// Les ticks sont répartis régulièrement autour du cadran.
export function ticksFromNodes(nodes = []) {
  const present = nodes.filter((n) => !isMissing(n));
  const missing = nodes.filter(isMissing);
  const colorOf = (key) => (DIMENSIONS.find((d) => d.key === key)?.color) || "#22D3EE";

  const entries = [
    ...present.map((n) => colorOf(n.dimension)),
    ...missing.map(() => "#FFFFFF"),
  ];
  if (!entries.length) return [];

  // Réparti les entrées sur les 60 graduations, espacées régulièrement.
  const out = new Array(TICK_COUNT).fill(undefined);
  const step = TICK_COUNT / entries.length;
  entries.forEach((color, i) => { out[Math.round(i * step) % TICK_COUNT] = color; });
  return out;
}

function isMissing(n = {}) {
  return n.presence_state === "absent" || n.manque_probable || n.silence_significatif;
}