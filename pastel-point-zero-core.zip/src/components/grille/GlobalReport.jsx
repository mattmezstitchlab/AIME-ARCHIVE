import React from "react";
import { Link } from "react-router-dom";
import { dimensionOf, DIMENSIONS } from "./config";
import Collapsible from "./result/Collapsible";

// Rapport global pédagogique après un dépôt.
// Palette UNIFIÉE : noir/gris, un seul accent blanc — plus de blocs colorés.
// Structure épurée, non redondante : L'essentiel → Rapport d'analyse → Prochaines étapes cliquables.
export default function GlobalReport({ result, onContinue }) {
  const source = result?.source;
  const nodes = result?.nodes || [];
  const fragments = result?.fragments || [];

  if (!source && !nodes.length) {
    return (
      <p className="rounded-2xl bg-white/[0.04] p-6 text-center text-sm leading-6 text-muted-foreground ring-1 ring-white/[0.06]">
        Déposez un contenu au Point Zéro. Le système le comprendra, le rangera dans votre grille mémoire et vous expliquera ici ce qu'il en a fait.
      </p>
    );
  }

  // Ce qui a été rangé, par dimension.
  const byDim = {};
  nodes.filter((n) => !isAbsence(n)).forEach((n) => { (byDim[n.dimension] = byDim[n.dimension] || []).push(n); });

  const rangesCount = nodes.filter((n) => !isAbsence(n)).length;
  const provenance = source?.provenance_detectee && source.provenance_detectee !== "autre" ? PROVENANCE[source.provenance_detectee] || source.provenance_detectee : null;
  const recap = DIMENSIONS.map((d) => ({ dim: d, count: (byDim[d.key] || []).length })).filter((r) => r.count > 0).sort((a, b) => b.count - a.count);
  const domaine = source?.domaine_detecte && source.domaine_detecte !== "autre" ? source.domaine_detecte : null;
  const estMariage = domaine === "mariage" || provenance === "un planning" || recap.some((r) => r.dim.key === "temps" && r.count >= 2);

  // Prochaines étapes (style Manus) : destinations ouvrables + suggestions à compléter.
  // Dédoublonné : une seule liste, plus de "à clarifier" qui répétait "prochaine étape".
  const absences = nodes.filter(isAbsence);
  const suggestions = [...new Set([
    ...absences.map((a) => a.titre),
    ...(source?.oublis_probables || []),
    ...(source?.silences_significatifs || []),
    ...(source?.anticipations || []),
    ...(source?.zones_grises || []),
  ].filter(Boolean))];

  return (
    <div className="space-y-4">
      {/* L'ESSENTIEL — une seule phrase courte, le sens du dépôt. */}
      <p className="px-1 text-[15px] font-medium leading-snug text-foreground">{source?.comprehension_brute || "Dépôt compris."}</p>

      {/* PROCHAINES ÉTAPES PROPOSÉES — compact, condensé (style Manus).
          Chaque étape est cliquable : elle relance le moteur pour la creuser. */}
      <div className="space-y-1.5">
        <p className="px-1 text-[12px] font-semibold text-muted-foreground">Étapes proposées</p>
        {estMariage && <StepLink to={source?.id ? `/projection/mariage?source=${source.id}` : "/projection/mariage"} label="Ouvrir le Planning Jour J" primary />}
        {suggestions.slice(0, 5).map((t, i) => (
          <StepLink key={i} label={t} onContinue={onContinue} />
        ))}
      </div>

      {/* Détails techniques — repliés. */}
      {fragments.length > 0 && (
        <Collapsible title="Détails techniques" count={fragments.length}>
          <div className="space-y-1.5">
            {fragments.map((f) => (
              <div key={f.id} className="text-xs text-muted-foreground">
                {f.contenu_fragment} — {f.dimension_suggeree || "non classé"} ({f.confiance}%)
              </div>
            ))}
          </div>
        </Collapsible>
      )}
    </div>
  );
}

function isAbsence(n = {}) {
  return n.presence_state === "absent" || n.manque_probable || n.silence_significatif;
}

// Étape cliquable façon Manus, compacte : une ligne, sans sous-texte.
// `to` → navigue vers une destination. `onContinue` → relance le moteur sur cette étape.
function StepLink({ label, to, primary, onContinue }) {
  const base = "flex w-full items-center justify-between gap-2 rounded-lg px-3 py-2 text-left text-[13px] transition-colors";
  if (to) {
    return <Link to={to} className={`${base} font-medium ${primary ? "bg-foreground text-background hover:bg-foreground/90" : "bg-white/[0.04] text-foreground ring-1 ring-white/[0.06] hover:bg-white/[0.07]"}`}>
      <span className="min-w-0 truncate">{label}</span>
      <span className={`shrink-0 ${primary ? "text-background/60" : "text-foreground/40"}`}>›</span>
    </Link>;
  }
  return <button type="button" onClick={() => onContinue?.(label)} className={`${base} bg-white/[0.04] text-foreground/85 ring-1 ring-white/[0.06] hover:bg-white/[0.07] hover:text-foreground`}>
    <span className="min-w-0 truncate">{label}</span>
    <span className="shrink-0 text-foreground/30">›</span>
  </button>;
}

function Block({ title, children }) {
  return (
    <div className="rounded-2xl bg-white/[0.04] p-4 ring-1 ring-white/[0.06]">
      <p className="mb-2.5 text-[13px] font-semibold text-foreground/70">{title}</p>
      <div className="text-foreground">{children}</div>
    </div>
  );
}

const PROVENANCE = {
  sms: "un SMS", email: "un email", facture: "une facture", devis: "un devis",
  document_administratif: "un document administratif", google_maps: "un plan Google Maps",
  agenda: "un agenda", capture_site: "une capture de site", pdf: "un PDF",
  formulaire: "un formulaire", tableau: "un tableau", note: "une note", photo: "une photo", planning: "un planning",
};