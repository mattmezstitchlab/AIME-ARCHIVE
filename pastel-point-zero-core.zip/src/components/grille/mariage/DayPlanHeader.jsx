import React from "react";

// En-tête du Jour J : nom de l'événement + date, lus depuis la projection si présente,
// sinon des valeurs douces par défaut. Lecture seule, style iOS sombre.
const JOURS = ["dimanche", "lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi"];
const MOIS = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre", "novembre", "décembre"];

function formatDate(iso) {
  if (!iso) return null;
  const d = new Date(iso);
  if (isNaN(d)) return null;
  return `${JOURS[d.getDay()]} ${d.getDate()} ${MOIS[d.getMonth()]} ${d.getFullYear()}`;
}

export default function DayPlanHeader({ projection, momentsCount = 0 }) {
  const titre = projection?.nom_evenement || "Le Jour J";
  const dateLisible = formatDate(projection?.date_jour_j);

  return (
    <header className="mb-7 text-center">
      <p className="text-[12px] font-medium uppercase tracking-[0.2em] text-muted-foreground">Déroulé orchestré</p>
      <h1 className="mt-2 text-4xl font-bold tracking-tight text-foreground sm:text-5xl">{titre}</h1>
      <div className="mt-3 flex flex-wrap items-center justify-center gap-2 text-[14px] text-muted-foreground">
        {dateLisible && (
          <span className="inline-flex items-center gap-1.5 rounded-full bg-white/[0.06] px-3 py-1">
            <span className="text-primary">◷</span>{dateLisible}
          </span>
        )}
        {momentsCount > 0 && (
          <span className="inline-flex items-center gap-1.5 rounded-full bg-white/[0.06] px-3 py-1">
            {momentsCount} moment{momentsCount > 1 ? "s" : ""}
          </span>
        )}
      </div>
    </header>
  );
}