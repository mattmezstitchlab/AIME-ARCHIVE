import React from "react";

// Sélecteur de niveau de zoom de la timeline : macro → heures → minutes.
// Style "tampon typographique" pour coller à l'identité letterpress du site.
const LEVELS = [
  { key: "macro", label: "Macro", hint: "Grands blocs de moments" },
  { key: "heures", label: "Heures", hint: "Déroulé heure par heure" },
  { key: "minutes", label: "Minutes", hint: "Détail à la minute" },
];

export default function ZoomControl({ level = "heures", onChange }) {
  return (
    <div className="inline-flex items-center overflow-hidden rounded-full border-2 border-ink dark:border-paper">
      {LEVELS.map((l, i) => {
        const active = l.key === level;
        return (
          <button
            key={l.key}
            onClick={() => onChange?.(l.key)}
            title={l.hint}
            className={`px-4 py-1.5 font-display text-[11px] font-bold uppercase tracking-[0.18em] transition-colors ${i > 0 ? "border-l-2 border-ink dark:border-paper" : ""} ${
              active
                ? "bg-ink text-paper dark:bg-paper dark:text-ink"
                : "bg-transparent text-ink hover:bg-ink/10 dark:text-paper dark:hover:bg-paper/10"
            }`}
          >
            {l.label}
          </button>
        );
      })}
    </div>
  );
}