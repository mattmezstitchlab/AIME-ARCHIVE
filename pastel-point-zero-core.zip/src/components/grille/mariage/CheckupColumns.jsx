import React from "react";
import { dimensionOf } from "../config";

// Trois colonnes de vérification : la veille, le matin, et les points à vérifier (risques/oublis).
export default function CheckupColumns({ veille = [], matin = [], aVerifier = [] }) {
  const cols = [
    { sym: "◐", title: "Check-up veille", items: veille, empty: "Rien à préparer la veille pour l'instant." },
    { sym: "◑", title: "Check-up matin", items: matin, empty: "Rien de spécifique le matin." },
    { sym: "▲", title: "À vérifier", items: aVerifier, empty: "Aucun risque ou oubli détecté." },
  ];
  return (
    <div className="grid gap-3 md:grid-cols-3">
      {cols.map((c) => (
        <div key={c.title} className="letterpress-frame bg-paper p-4">
          <p className="flex items-center gap-2 font-display text-sm uppercase tracking-wide text-ink"><span className="text-base">{c.sym}</span>{c.title}</p>
          {c.items.length ? (
            <ul className="mt-3 space-y-2">
              {c.items.map((it, i) => {
                const dim = dimensionOf(it.dim);
                return (
                  <li key={i} className="flex items-start gap-2 font-body text-sm text-ink/80">
                    <span className="mt-0.5 text-xs" style={{ color: dim.color }}>{dim.icon}</span>
                    <span className="leading-5">{it.texte}</span>
                  </li>
                );
              })}
            </ul>
          ) : (
            <p className="mt-3 text-xs text-ink/40">{c.empty}</p>
          )}
        </div>
      ))}
    </div>
  );
}