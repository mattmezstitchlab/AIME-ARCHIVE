import React from "react";
import { formatHour } from "./dayPlan";

// Vue "macro" : les grandes phases de la journée en blocs typographiques.
// Lecture d'un coup d'œil — combien de moments par phase, début → fin.
export default function MacroView({ phases = [] }) {
  return (
    <div className="mx-auto grid max-w-2xl gap-4 sm:grid-cols-2">
      {phases.map((p) => {
        const first = p.moments[0];
        const last = p.moments[p.moments.length - 1];
        const end = last.endMinutes || last.minutes;
        return (
          <div key={p.key} className="letterpress-frame bg-paper px-5 py-4">
            <div className="flex items-baseline justify-between border-b-2 border-ink/15 pb-2">
              <h4 className="display-title text-2xl text-ink">{p.label}</h4>
              <span className="font-mono text-xs text-ink/50">{formatHour(first.minutes)} → {formatHour(end)}</span>
            </div>
            <ul className="mt-3 space-y-1.5">
              {p.moments.map((m) => (
                <li key={m.id} className="flex items-baseline gap-2 text-sm text-ink/80">
                  <span className="font-mono text-[11px] text-ink/40">{formatHour(m.minutes)}</span>
                  <span className="font-medium">{m.titre}</span>
                </li>
              ))}
            </ul>
          </div>
        );
      })}
    </div>
  );
}