import React, { useState, useEffect, useRef } from "react";
import { dimensionOf } from "../config";
import { formatHour, formatDuration, findCurrentNext, momentRisques, detectLiens } from "./dayPlan";
import TimelineInsights from "./TimelineInsights";
import TimelineShare from "./TimelineShare";

// Déroulé du Jour J — grande timeline letterpress noir & blanc, vue minutes (détail complet) en pleine largeur.
// Indicateurs visuels : ⚠ risque sur un moment, trait liant deux moments enchaînés.
export default function DayPlanTimeline({ moments = [], libres = [], insights = [] }) {
  const [, setTick] = useState(0);
  const [immersive, setImmersive] = useState(false);
  const captureRef = useRef(null);
  useEffect(() => {
    const id = setInterval(() => setTick((t) => t + 1), 60000);
    return () => clearInterval(id);
  }, []);
  useEffect(() => {
    if (!immersive) return;
    const onKey = (e) => e.key === "Escape" && setImmersive(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [immersive]);
  const { current, next, countdown, nowMin } = findCurrentNext(moments);

  if (!moments.length) {
    return (
      <div className="rounded-3xl bg-card p-6 text-center text-sm text-muted-foreground ring-1 ring-white/10">
        Aucun horaire détecté pour l'instant. Déposez une capture du déroulé au Point Zéro — les moments datés apparaîtront ici.
      </div>
    );
  }

  const first = moments[0].minutes;
  const lastEnd = moments[moments.length - 1].endMinutes || moments[moments.length - 1].minutes;
  const showNow = nowMin >= first && nowMin <= lastEnd;
  const nowIndex = showNow ? moments.findIndex((m) => m.minutes > nowMin) : -1;
  const liens = detectLiens(moments);

  const card = (
    <div ref={captureRef} className={`bg-card px-6 py-6 sm:px-10 sm:py-8 ${immersive ? "min-h-screen" : "rounded-3xl ring-1 ring-white/10"}`}>
      {/* Barre de tête compacte : heures du moment courant/suivant intégrées */}
      {(current || next) && (
        <div className="relative z-10 mb-6 flex flex-wrap items-center gap-x-3 gap-y-1.5 text-[13px]">
          {current
            ? <span className="font-medium text-foreground"><span className="font-mono">{formatHour(current.minutes)}</span> · {current.titre}</span>
            : <span className="text-muted-foreground">La journée n'a pas commencé</span>}
          {next && <span className="text-muted-foreground/60">→</span>}
          {next && (
            <span className="text-muted-foreground">
              {countdown != null && countdown >= 0 && countdown <= 600 && (
                <b className="mr-1.5 rounded-full bg-primary px-2 py-0.5 font-mono text-[10px] text-primary-foreground">dans {formatDuration(countdown) || "1 min"}</b>
              )}
              <span className="font-mono">{formatHour(next.minutes)}</span> · {next.titre}
            </span>
          )}
        </div>
      )}

      {/* Observations du moteur — chips de réponse, masquées en immersif. */}
      {!immersive && <div className="relative z-10"><TimelineInsights insights={insights} /></div>}

      {/* Le fil — vue minutes en pleine largeur.
          Colonne heure (gauche) · rail vertical + pastille · carte (droite). */}
      <ol className="relative z-10 mx-auto max-w-4xl">
        <span className="absolute left-[92px] top-2 bottom-2 w-px bg-white/10 sm:left-[116px]" />

        {moments.map((m, i) => {
          const isNow = current && m.id === current.id;
          const insertNow = showNow && i === nowIndex;
          const risques = momentRisques(m);
          const linkedToNext = liens.find((l) => l.from === m.id);
          return (
            <React.Fragment key={m.id}>
              {insertNow && <NowMarker nowMin={nowMin} />}
              <li className={`relative flex ${i === 0 ? "" : "pt-9"}`}>
                {/* Heure-repère — largeur fixe, jamais sous la pastille */}
                <div className="w-[76px] shrink-0 pr-5 pt-1 text-right sm:w-[100px]">
                  <span className={`font-mono text-base font-semibold tracking-tight ${isNow ? "text-primary" : "text-foreground/55"} ${m.estimated ? "border-b border-dashed border-foreground/30" : ""}`}>
                    {formatHour(m.minutes)}
                  </span>
                  {m.endMinutes && (
                    <span className="mt-0.5 block font-mono text-[10px] text-muted-foreground">→ {formatHour(m.endMinutes)}</span>
                  )}
                  {m.estimated && <span className="mt-0.5 block text-[9px] uppercase tracking-wider text-muted-foreground">~ estimée</span>}
                </div>

                {/* Point sur le rail — centré sur la ligne, à l'écart des chiffres */}
                <span className={`absolute top-2 z-10 flex h-3.5 w-3.5 -translate-x-1/2 items-center justify-center rounded-full ring-4 ring-card ${isNow ? "bg-primary" : m.estimated ? "border-2 border-foreground/30 bg-card" : "bg-foreground/35"} ${risques.length ? "outline outline-2 outline-offset-1 outline-red-500" : ""}`} style={{ left: "92px" }}>
                  {isNow && <span className="h-1.5 w-1.5 rounded-full bg-primary-foreground" />}
                </span>

                {/* Trait de lien vers le moment suivant (enchaînement / dépendance) */}
                {linkedToNext && (
                  <span className="absolute z-0 flex items-center gap-1" style={{ left: "98px", top: "20px" }}>
                    <span className={`block w-5 border-t ${linkedToNext.type === "depend" ? "border-dashed" : "border-solid"} border-foreground/25`} />
                    <span className="text-[8px] uppercase tracking-wider text-muted-foreground">{linkedToNext.type === "depend" ? "dépend" : "puis"}</span>
                  </span>
                )}

                {/* Contenu du moment — carte douce, décalée à droite du rail */}
                <div className={`ml-7 min-w-0 flex-1 rounded-2xl px-4 py-3 sm:ml-9 sm:px-5 ${isNow ? "bg-primary/10 ring-1 ring-primary/30" : "bg-white/[0.04] ring-1 ring-white/[0.06]"}`}>
                  <div className="flex flex-wrap items-baseline gap-2">
                    <p className={`text-xl font-semibold leading-snug tracking-tight sm:text-2xl ${isNow ? "text-foreground" : "text-foreground/90"}`}>{m.titre}</p>
                    {m.duration && <span className="shrink-0 rounded-full bg-white/[0.06] px-2 py-0.5 font-mono text-[10px] text-muted-foreground">{formatDuration(m.duration)}</span>}
                    {risques.length > 0 && (
                      <span className="inline-flex items-center gap-1 rounded-full bg-red-500/10 px-2 py-0.5 text-[10px] font-bold text-red-600 dark:text-red-400" title={risques.join(" · ")}>
                        ⚠ {risques.length} risque{risques.length > 1 ? "s" : ""}
                      </span>
                    )}
                  </div>
                  {m.contenu_enrichi && (
                    <p className="mt-1.5 max-w-prose text-sm leading-relaxed text-muted-foreground">{m.contenu_enrichi}</p>
                  )}
                  {risques.length > 0 && (
                    <ul className="mt-2 space-y-1">
                      {risques.map((r, ri) => (
                        <li key={ri} className="flex items-start gap-1.5 text-xs text-red-400"><span>⚠</span>{r}</li>
                      ))}
                    </ul>
                  )}
                  {m.duration && (
                    <div className="mt-2.5 h-1 w-full max-w-[220px] overflow-hidden rounded-full bg-white/10">
                      <div className="h-full rounded-full bg-primary/70" style={{ width: `${Math.min(100, (m.duration / 240) * 100)}%` }} />
                    </div>
                  )}
                  {m.attaches.length > 0 && (
                    <div className="mt-2.5 flex flex-wrap gap-1.5">
                      {m.attaches.map((a) => <Satellite key={a.id} node={a} />)}
                    </div>
                  )}
                </div>
              </li>
            </React.Fragment>
          );
        })}
      </ol>

      {libres.length > 0 && !immersive && <FloatingElements libres={libres} />}
    </div>
  );

  return (
    <div className="space-y-5">
      {!immersive && (
        <TimelineShare targetRef={captureRef} immersive={immersive} onToggleImmersive={() => setImmersive(true)} />
      )}
      {immersive ? (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-background">
          <button
            onClick={() => setImmersive(false)}
            className="fixed right-5 top-5 z-50 rounded-full ios-material px-4 py-2 text-[13px] font-medium text-muted-foreground transition-colors hover:text-foreground"
          >
            Quitter (Échap)
          </button>
          {card}
        </div>
      ) : (
        card
      )}
    </div>
  );
}

// Ligne "maintenant" insérée dans le fil, avec l'heure réelle.
function NowMarker({ nowMin }) {
  return (
    <li className="relative flex items-center pt-7">
      <div className="w-[76px] shrink-0 pr-5 text-right sm:w-[100px]">
        <span className="font-mono text-xs font-semibold uppercase tracking-wider text-primary">{formatHour(nowMin)}</span>
      </div>
      <span className="absolute top-1/2 z-10 h-2.5 w-2.5 -translate-x-1/2 -translate-y-1/2 animate-pulse rounded-full bg-primary ring-4 ring-card" style={{ left: "92px" }} />
      <div className="ml-7 flex-1 sm:ml-9">
        <div className="flex items-center gap-2">
          <span className="h-px flex-1 bg-primary/40" />
          <span className="text-[10px] font-semibold uppercase tracking-[0.25em] text-primary">maintenant</span>
        </div>
      </div>
    </li>
  );
}

// Éléments compris mais sans heure rattachée (DJ, fleurs, voiture…). Repliés par défaut.
function FloatingElements({ libres }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="mx-auto mt-12 max-w-4xl border-t border-white/10 pt-6">
      <button
        onClick={() => setOpen((v) => !v)}
        className="mx-auto flex items-center gap-2 text-[13px] font-medium text-muted-foreground transition-colors hover:text-foreground"
      >
        <span>{open ? "−" : "+"}</span>
        {libres.length} élément{libres.length > 1 ? "s" : ""} sans heure fixée
      </button>
      {open && (
        <div className="mt-4 flex flex-wrap justify-center gap-1.5">
          {libres.map((a) => <Satellite key={a.id} node={a} />)}
        </div>
      )}
    </div>
  );
}

// Pastille satellite : glyphe coloré discret + libellé.
function Satellite({ node }) {
  const dim = dimensionOf(node.dimension);
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full bg-white/[0.06] px-3 py-1 text-[13px] text-foreground/85">
      <span style={{ color: dim.color }}>{dim.icon}</span>{node.titre}
    </span>
  );
}