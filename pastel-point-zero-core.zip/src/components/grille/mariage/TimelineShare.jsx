import React, { useState } from "react";
import html2canvas from "html2canvas";
import { Share2, Maximize2, Minimize2, Loader2 } from "lucide-react";

// Barre d'actions de la timeline : partage image réseaux sociaux + bascule mode immersif.
// `targetRef` pointe sur le bloc timeline à capturer.
export default function TimelineShare({ targetRef, immersive, onToggleImmersive }) {
  const [busy, setBusy] = useState(false);

  const handleShare = async () => {
    const node = targetRef.current;
    if (!node || busy) return;
    setBusy(true);
    try {
      const canvas = await html2canvas(node, {
        backgroundColor: getComputedStyle(document.documentElement).classList?.contains?.("dark") ? "#0a0a0a" : "#ffffff",
        scale: 2,
        useCORS: true,
      });
      const blob = await new Promise((res) => canvas.toBlob(res, "image/png"));
      if (!blob) return;
      const file = new File([blob], "deroule-jour-j.png", { type: "image/png" });
      // Partage natif si disponible (mobile), sinon téléchargement.
      if (navigator.canShare && navigator.canShare({ files: [file] })) {
        await navigator.share({ files: [file], title: "Mon déroulé Jour J" });
      } else {
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = "deroule-jour-j.png";
        a.click();
        URL.revokeObjectURL(url);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex items-center justify-center gap-2">
      <button
        onClick={handleShare}
        disabled={busy}
        className="inline-flex items-center gap-2 rounded-full border border-neutral-900/15 bg-white px-4 py-2 text-xs font-medium text-neutral-700 transition-colors hover:bg-neutral-900 hover:text-white disabled:opacity-50 dark:border-white/15 dark:bg-transparent dark:text-neutral-200 dark:hover:bg-white dark:hover:text-neutral-950"
      >
        {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Share2 className="h-3.5 w-3.5" />}
        Partager en image
      </button>
      <button
        onClick={onToggleImmersive}
        className="inline-flex items-center gap-2 rounded-full border border-neutral-900/15 bg-white px-4 py-2 text-xs font-medium text-neutral-700 transition-colors hover:bg-neutral-900 hover:text-white dark:border-white/15 dark:bg-transparent dark:text-neutral-200 dark:hover:bg-white dark:hover:text-neutral-950"
      >
        {immersive ? <Minimize2 className="h-3.5 w-3.5" /> : <Maximize2 className="h-3.5 w-3.5" />}
        {immersive ? "Quitter l'immersion" : "Mode immersif"}
      </button>
    </div>
  );
}