import React, { useState } from "react";

// Ce que le moteur a vu sans qu'on le lui demande : trous, chevauchements, marges serrées, flou.
// Rendu en chips cliquables : un libellé court, le détail se déplie au clic.
const ICON = { chevauchement: "⚠", trou: "◴", serre: "⚡", tardif: "☾", flou: "≈", oubli: "+" };
const LABEL = { chevauchement: "Chevauchement", trou: "Trou", serre: "Marge serrée", tardif: "Fin tardive", flou: "Heures floues", oubli: "Oubli probable" };
const GRAVITY = { haute: 3, moyenne: 2, basse: 1 };

export default function TimelineInsights({ insights = [] }) {
  const [open, setOpen] = useState(null);
  if (!insights.length) return null;
  const ordered = [...insights].sort((a, b) => GRAVITY[b.gravite] - GRAVITY[a.gravite]);
  const active = open != null ? ordered[open] : null;

  return (
    <div className="mx-auto mb-8 max-w-2xl">
      <p className="mb-3 flex items-center justify-center gap-2 text-[12px] font-medium text-muted-foreground">
        <span>◎</span> Ce que le moteur a remarqué
      </p>
      {/* Chips de réponse */}
      <div className="flex flex-wrap justify-center gap-2">
        {ordered.map((o, i) => {
          const isOn = open === i;
          return (
            <button
              key={i}
              onClick={() => setOpen(isOn ? null : i)}
              className={`inline-flex items-center gap-1.5 rounded-full px-3.5 py-2 text-[13px] font-medium transition-colors ${
                isOn
                  ? "bg-primary text-primary-foreground"
                  : o.gravite === "haute"
                  ? "bg-white/10 text-foreground hover:bg-white/[0.14]"
                  : o.gravite === "moyenne"
                  ? "bg-white/[0.07] text-foreground/85 hover:bg-white/[0.12]"
                  : "bg-white/[0.05] text-muted-foreground hover:bg-white/[0.1]"
              }`}
            >
              <span>{ICON[o.type] || "·"}</span>
              {LABEL[o.type] || "Remarque"}
            </button>
          );
        })}
      </div>
      {/* Détail de la chip sélectionnée */}
      {active && (
        <div className="mt-3 rounded-2xl bg-white/[0.05] px-4 py-3 ring-1 ring-white/[0.06]">
          <span className="text-[15px] leading-relaxed text-foreground/85">
            {active.texte}
            {active.suggestion && <span className="mt-1 block text-[14px] text-muted-foreground">→ {active.suggestion}</span>}
          </span>
        </div>
      )}
    </div>
  );
}