// Orchestration "Jour J" : transforme des nœuds bruts en un déroulé par heure.
// Lecture seule — n'exécute rien, ne modifie aucun nœud.

// Extrait une heure (ex "14h00", "14:30", "9h") d'un texte. Retourne des minutes ou null.
export function parseHour(text) {
  const t = String(text || "");
  const m = t.match(/\b(\d{1,2})\s*[h:]\s*(\d{0,2})\b/i);
  if (!m) return null;
  const h = parseInt(m[1], 10);
  const min = m[2] ? parseInt(m[2], 10) : 0;
  if (h > 23 || min > 59) return null;
  return h * 60 + min;
}

// Heures floues exprimées en langage naturel → estimation en minutes (marquée "estimée").
const FUZZY = [
  { re: /\b(aube|lever du soleil|petit matin|très tôt)\b/i, min: 6 * 60 },
  { re: /\b(début de matinée|tôt le matin|matin tôt)\b/i, min: 8 * 60 },
  { re: /\b(en matinée|dans la matinée|le matin)\b/i, min: 10 * 60 },
  { re: /\b(fin de matinée|avant midi|fin matinée)\b/i, min: 11 * 60 + 30 },
  { re: /\b(midi|déjeuner|repas de midi)\b/i, min: 12 * 60 },
  { re: /\b(début d'après-midi|début après-midi|après le déjeuner)\b/i, min: 14 * 60 },
  { re: /\b(en après-midi|dans l'après-midi|l'après-midi)\b/i, min: 15 * 60 },
  { re: /\b(milieu d'après-midi|goûter)\b/i, min: 16 * 60 },
  { re: /\b(fin d'après-midi|fin après-midi|avant le soir)\b/i, min: 17 * 60 + 30 },
  { re: /\b(en début de soirée|début de soirée|apéritif|apéro|vin d'honneur|cocktail)\b/i, min: 18 * 60 + 30 },
  { re: /\b(le soir|en soirée|dîner|repas du soir|au dîner)\b/i, min: 20 * 60 },
  { re: /\b(fin de soirée|tard le soir|fin de nuit)\b/i, min: 23 * 60 },
  { re: /\b(minuit|pièce montée de minuit)\b/i, min: 24 * 60 },
  { re: /\b(nuit|au bout de la nuit|jusqu'au bout)\b/i, min: 25 * 60 },
];

// Estime une heure floue depuis un texte. Retourne minutes ou null.
export function estimateFuzzyHour(text) {
  const t = String(text || "");
  for (const f of FUZZY) if (f.re.test(t)) return f.min;
  return null;
}

// Extrait une durée explicite : "de 17h à 19h", "pendant 2h", "(45 min)", "2h30".
// Retourne une durée en minutes ou null.
export function parseDuration(text, startMinutes) {
  const t = String(text || "");
  // Plage "de 17h à 19h" / "17h-19h" / "17h – 19h30"
  const range = t.match(/\b(\d{1,2})\s*[h:]\s*(\d{0,2})?\s*(?:à|a|-|–|—|jusqu'?à)\s*(\d{1,2})\s*[h:]\s*(\d{0,2})?/i);
  if (range) {
    const start = parseInt(range[1], 10) * 60 + (range[2] ? parseInt(range[2], 10) : 0);
    let end = parseInt(range[3], 10) * 60 + (range[4] ? parseInt(range[4], 10) : 0);
    if (end < start) end += 24 * 60; // passe minuit
    const d = end - start;
    if (d > 0 && d <= 18 * 60) return d;
  }
  // "pendant 2h", "2h30", "durée 90 min", "45 minutes"
  const hm = t.match(/\b(\d{1,2})\s*h\s*(\d{0,2})\b/gi);
  const dur = t.match(/\b(?:pendant|durée|dure|environ)\s*(\d{1,3})\s*(h|heures?|min|minutes?)/i);
  if (dur) {
    const v = parseInt(dur[1], 10);
    return /h|heure/i.test(dur[2]) ? v * 60 : v;
  }
  const mins = t.match(/\b(\d{1,3})\s*(?:min|minutes?)\b/i);
  if (mins) return parseInt(mins[1], 10);
  // "2h30" isolé qui n'est pas une heure d'horloge (heuristique faible) — ignoré pour éviter les faux positifs
  void hm; void startMinutes;
  return null;
}

export function formatHour(minutes) {
  if (minutes == null) return "—";
  const norm = ((minutes % (24 * 60)) + 24 * 60) % (24 * 60);
  const h = Math.floor(norm / 60);
  const m = norm % 60;
  return `${String(h).padStart(2, "0")}h${String(m).padStart(2, "0")}`;
}

// Formate une durée lisible : "2h", "1h30", "45 min".
export function formatDuration(minutes) {
  if (!minutes || minutes <= 0) return "";
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  if (h && m) return `${h}h${String(m).padStart(2, "0")}`;
  if (h) return `${h}h`;
  return `${m} min`;
}

// Dimensions rattachées à un moment du déroulé.
const SATELLITE_DIMS = ["personnes", "espace", "communication", "ressources", "economie", "actions", "memoire", "emotions"];

// Construit le déroulé : chaque nœud porteur d'une heure (précise ou estimée) devient un moment.
// On calcule aussi durée, fin, satellites, et — au niveau global — trous et chevauchements.
export function buildDayPlan(nodes = []) {
  const moments = [];
  const satellites = [];

  nodes.forEach((n) => {
    const blob = `${n.titre || ""} ${n.contenu_enrichi || ""} ${n.sous_dimension || ""}`;
    const precise = parseHour(n.titre) ?? parseHour(n.contenu_enrichi) ?? parseHour(n.sous_dimension);
    const estimated = precise == null ? estimateFuzzyHour(blob) : null;
    const minutes = precise ?? estimated;

    if (minutes != null) {
      const duration = parseDuration(blob, minutes);
      moments.push({
        ...n,
        minutes,
        estimated: precise == null, // heure devinée, à afficher en pointillé
        duration: duration || null,
        endMinutes: duration ? minutes + duration : null,
        attaches: [],
      });
    } else if (SATELLITE_DIMS.includes(n.dimension)) {
      satellites.push({ ...n, minutes });
    }
  });

  moments.sort((a, b) => a.minutes - b.minutes);

  // Rattache chaque satellite au moment horaire le plus proche (≤30 min), sinon liste libre.
  const libres = [];
  satellites.forEach((s) => {
    if (s.minutes != null) {
      const closest = moments.reduce(
        (best, m) => (Math.abs(m.minutes - s.minutes) < Math.abs(best.minutes - s.minutes) ? m : best),
        moments[0]
      );
      if (closest && Math.abs(closest.minutes - s.minutes) <= 30) closest.attaches.push(s);
      else libres.push(s);
    } else {
      libres.push(s);
    }
  });

  return { moments, libres, insights: analyzeTimeline(moments) };
}

// Moments classiques d'un mariage, par fenêtre horaire — souvent oubliés dans un déroulé.
// Sert à suggérer ce qui pourrait combler un trou détecté.
const MOMENTS_CLASSIQUES = [
  { re: /préparatifs|préparation|coiffure|maquillage|habillage/i, label: "les préparatifs", min: 9 * 60, max: 12 * 60 },
  { re: /first look|découverte des mariés/i, label: "le first look", min: 12 * 60, max: 14 * 60 },
  { re: /arrivée des invités|accueil des invités|accueil invités/i, label: "l'accueil des invités", min: 13 * 60, max: 15 * 60 },
  { re: /cérémonie|mairie|église|laïque|engagement|échange des vœux|alliances/i, label: "la cérémonie", min: 14 * 60, max: 17 * 60 },
  { re: /sortie de cérémonie|haie d'honneur|riz|pétales|bulles/i, label: "la sortie de cérémonie", min: 16 * 60, max: 17 * 60 + 30 },
  { re: /vin d'honneur|cocktail|apéritif|apéro/i, label: "le cocktail / vin d'honneur", min: 17 * 60, max: 19 * 60 },
  { re: /photo de groupe|photos de groupe|photo de famille|photos famille/i, label: "les photos de groupe", min: 17 * 60, max: 19 * 60 },
  { re: /photo|shooting|couple/i, label: "la séance photo de couple", min: 17 * 60, max: 19 * 60 },
  { re: /entrée des mariés|repas|dîner|banquet|à table/i, label: "le dîner", min: 19 * 60 + 30, max: 22 * 60 },
  { re: /discours|prise de parole|témoins/i, label: "les discours", min: 20 * 60, max: 22 * 60 },
  { re: /animation|jeu|quiz|surprise|spectacle/i, label: "les animations", min: 20 * 60, max: 23 * 60 },
  { re: /première danse|ouverture de bal|ouverture du bal/i, label: "l'ouverture de bal", min: 22 * 60, max: 23 * 60 + 30 },
  { re: /pièce montée|gâteau|dessert/i, label: "la pièce montée", min: 22 * 60, max: 24 * 60 },
  { re: /lancer de bouquet|lancé de bouquet|jet du bouquet|bouquet/i, label: "le lancer de bouquet", min: 22 * 60 + 30, max: 24 * 60 },
  { re: /jarretière|jarretelle/i, label: "le lancer de la jarretière", min: 22 * 60 + 30, max: 24 * 60 },
  { re: /soirée dansante|dj|bal|fête/i, label: "la soirée dansante", min: 22 * 60, max: 26 * 60 },
  { re: /feu d'artifice|étincelles|cierges magiques|wonderland/i, label: "le feu d'artifice / cierges magiques", min: 23 * 60, max: 25 * 60 },
  { re: /brunch|lendemain|petit-déjeuner|after/i, label: "le brunch du lendemain", min: 26 * 60, max: 30 * 60 },
];

// Cherche un moment classique attendu dans une fenêtre [debut, fin] mais absent du déroulé.
function suggestionPourTrou(debut, fin, moments) {
  const present = (m) => moments.some((mo) => m.re.test(`${mo.titre} ${mo.contenu_enrichi || ""}`));
  return MOMENTS_CLASSIQUES.find((m) => m.min >= debut - 30 && m.max <= fin + 30 && !present(m));
}

// Détecte ce que l'œil humain rate : trous, télescopages, fins tardives, manque de marge.
// Sur les trous, propose le moment classique souvent oublié qui pourrait s'y loger.
// Retourne une liste d'observations { type, gravite, texte, atMinutes, suggestion }.
export function analyzeTimeline(moments = []) {
  const out = [];
  if (moments.length < 2) return out;

  for (let i = 0; i < moments.length - 1; i += 1) {
    const a = moments[i];
    const b = moments[i + 1];
    const aEnd = a.endMinutes || a.minutes;

    // Chevauchement : un moment avec durée déborde sur le suivant.
    if (a.endMinutes && a.endMinutes > b.minutes + 1) {
      out.push({
        type: "chevauchement", gravite: "haute", atMinutes: b.minutes,
        texte: `« ${a.titre} » se termine vers ${formatHour(a.endMinutes)}, mais « ${b.titre} » commence à ${formatHour(b.minutes)} — les deux se chevauchent.`,
      });
      continue;
    }

    // Trou : grand battement entre deux moments. On propose un moment classique si pertinent.
    const gap = b.minutes - aEnd;
    if (gap >= 120) {
      const sugg = suggestionPourTrou(aEnd, b.minutes, moments);
      out.push({
        type: "trou", gravite: gap >= 180 ? "haute" : "moyenne", atMinutes: aEnd,
        texte: `${formatDuration(gap)} de battement entre « ${a.titre} » (${formatHour(aEnd)}) et « ${b.titre} » (${formatHour(b.minutes)}) — voulu, ou un moment manque ?`,
        suggestion: sugg ? `Souvent on place ${sugg.label} ici.` : null,
      });
    } else if (gap >= 0 && gap < 10 && !a.endMinutes) {
      // Enchaînement serré sans marge.
      out.push({
        type: "serre", gravite: "moyenne", atMinutes: b.minutes,
        texte: `« ${a.titre} » et « ${b.titre} » s'enchaînent en ${gap === 0 ? "même temps" : `${gap} min`} — peu de marge pour la transition.`,
      });
    }
  }

  // Fin très tardive sans clôture explicite.
  const last = moments[moments.length - 1];
  const lastEnd = last.endMinutes || last.minutes;
  if (lastEnd >= 24 * 60) {
    out.push({ type: "tardif", gravite: "basse", atMinutes: lastEnd, texte: `Le déroulé court jusqu'après minuit — pensez à confirmer l'horaire de fin avec le lieu et les prestataires.` });
  }

  // Beaucoup d'heures estimées = précision faible.
  const est = moments.filter((m) => m.estimated).length;
  if (est >= 2) {
    out.push({ type: "flou", gravite: "basse", atMinutes: null, texte: `${est} moments ont une heure estimée (déduite du langage). Précisez-les pour un déroulé exact.` });
  }

  // Démarrage tardif : le déroulé commence après 15h sans trace de préparatifs en amont.
  const premier = moments[0];
  const aPreparatifs = moments.some((mo) => /préparatifs|préparation|coiffure|maquillage|habillage/i.test(`${mo.titre} ${mo.contenu_enrichi || ""}`));
  if (premier.minutes >= 15 * 60 && !aPreparatifs) {
    out.push({
      type: "trou", gravite: "moyenne", atMinutes: premier.minutes,
      texte: `Le déroulé démarre à ${formatHour(premier.minutes)} sans rien avant — la matinée (préparatifs, coiffure, habillage) n'apparaît pas.`,
      suggestion: "Ajoutez les préparatifs en début de journée pour cadrer le timing du matin.",
    });
  }

  // Pas de moment de clôture clair en soirée (fin avant 22h sans soirée dansante / fin annoncée).
  const aCloture = moments.some((mo) => /soirée dansante|dj|bal|fin de soirée|clôture|départ des mariés|au revoir/i.test(`${mo.titre} ${mo.contenu_enrichi || ""}`));
  if (lastEnd < 22 * 60 && lastEnd >= 19 * 60 && !aCloture) {
    out.push({
      type: "tardif", gravite: "basse", atMinutes: lastEnd,
      texte: `Le déroulé s'arrête vers ${formatHour(lastEnd)} sans moment de clôture (soirée dansante, départ des mariés) — la fin de soirée reste à définir.`,
      suggestion: "Précisez comment se termine la soirée pour éviter le flottement de fin.",
    });
  }

  // Moments classiques jamais mentionnés, à l'intérieur de la plage du déroulé : oublis probables.
  const debut = moments[0].minutes;
  const fin = lastEnd;
  const present = (m) => moments.some((mo) => m.re.test(`${mo.titre} ${mo.contenu_enrichi || ""}`));
  const oublis = MOMENTS_CLASSIQUES.filter((m) => !present(m) && m.min >= debut && m.max <= fin + 60).map((m) => m.label);
  // On ne garde que les plus marquants pour ne pas noyer.
  const oublisCles = oublis.slice(0, 3);
  if (oublisCles.length) {
    out.push({
      type: "oubli", gravite: "moyenne", atMinutes: null,
      texte: `Aucune trace de ${oublisCles.join(", ")} dans votre déroulé — des moments souvent attendus à ce moment de la journée.`,
    });
  }

  return out;
}

// Grandes phases d'une journée — sert à la vue "macro" (grands blocs).
const PHASES = [
  { key: "matin", label: "Matinée", min: 0, max: 12 * 60 },
  { key: "apresmidi", label: "Après-midi", min: 12 * 60, max: 18 * 60 },
  { key: "soiree", label: "Soirée", min: 18 * 60, max: 23 * 60 },
  { key: "nuit", label: "Nuit", min: 23 * 60, max: 36 * 60 },
];

// Regroupe les moments en grands blocs pour la vue macro.
export function buildPhases(moments = []) {
  return PHASES.map((p) => ({
    ...p,
    moments: moments.filter((m) => m.minutes >= p.min && m.minutes < p.max),
  })).filter((p) => p.moments.length > 0);
}

// Détecte les risques portés par un moment (issus des nœuds) — pour un indicateur visuel.
export function momentRisques(m) {
  const r = [];
  if (Array.isArray(m.risques)) r.push(...m.risques);
  if (m.manque_probable || m.silence_significatif) r.push(m.titre);
  return r.filter(Boolean);
}

// Détecte les liens entre moments : un moment "prépare" / "déclenche" le suivant.
// Heuristique légère sur les dépendances déclarées et l'enchaînement temporel serré.
export function detectLiens(moments = []) {
  const liens = [];
  for (let i = 0; i < moments.length - 1; i += 1) {
    const a = moments[i];
    const b = moments[i + 1];
    const aEnd = a.endMinutes || a.minutes;
    const gap = b.minutes - aEnd;
    // Enchaînement serré = dépendance forte (l'un déclenche l'autre).
    if (gap >= 0 && gap <= 15) liens.push({ from: a.id, to: b.id, type: "declenche" });
    // Dépendances déclarées dans les nœuds.
    if (Array.isArray(a.dependances) && a.dependances.length) {
      liens.push({ from: a.id, to: b.id, type: "depend" });
    }
  }
  return liens;
}

// Repère le moment actuel, le prochain, et le compte à rebours en minutes.
export function findCurrentNext(moments = []) {
  const now = new Date();
  const nowMin = now.getHours() * 60 + now.getMinutes();
  let current = null;
  let next = null;
  for (let i = 0; i < moments.length; i += 1) {
    if (moments[i].minutes <= nowMin) current = moments[i];
    else { next = moments[i]; break; }
  }
  const countdown = next ? next.minutes - nowMin : null;
  return { current, next, countdown, nowMin };
}

// Points de vérification (veille / matin) tirés des risques, besoins et oublis des nœuds.
export function buildCheckups(nodes = []) {
  const veille = [];
  const matin = [];
  const aVerifier = [];
  nodes.forEach((n) => {
    (n.besoins || []).forEach((b) => veille.push({ texte: b, dim: n.dimension }));
    (n.risques || []).forEach((r) => aVerifier.push({ texte: r, dim: n.dimension }));
    if (n.manque_probable || n.silence_significatif) aVerifier.push({ texte: n.titre, dim: n.dimension });
    if (n.dimension === "ressources") matin.push({ texte: n.titre, dim: n.dimension });
    if (n.echeance_probable) veille.push({ texte: `${n.titre} — ${n.echeance_probable}`, dim: n.dimension });
  });
  const dedup = (arr) => { const seen = new Set(); return arr.filter((x) => { const k = x.texte.toLowerCase(); if (!x.texte || seen.has(k)) return false; seen.add(k); return true; }); };
  return { veille: dedup(veille).slice(0, 8), matin: dedup(matin).slice(0, 8), aVerifier: dedup(aVerifier).slice(0, 8) };
}