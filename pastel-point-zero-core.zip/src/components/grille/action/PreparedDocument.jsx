import React, { useState, useMemo } from "react";

// Document préparé (facture / devis) éditable, en préparation seulement.
// Les infos extraites sont pré-remplies et modifiables ; les infos manquantes
// apparaissent comme champs vides à compléter. Aucun envoi, aucune génération réelle.
const FIELD_HINTS = {
  facture: ["Client", "Montant", "Prestation", "Date", "Numéro de facture", "Coordonnées", "Échéance"],
  devis: ["Client", "Montant", "Prestation", "Date", "Coordonnées", "Validité"],
};

// Transforme "Montant: 500 €" ou "Coordonnées client" en { key, value }.
function toField(raw) {
  const text = String(raw || "").trim();
  const sep = text.indexOf(":");
  if (sep > -1) return { key: text.slice(0, sep).trim(), value: text.slice(sep + 1).trim() };
  return { key: text, value: "" };
}

export default function PreparedDocument({ plan }) {
  const categorie = plan.categorie === "devis" ? "devis" : "facture";
  const initial = useMemo(() => {
    const fields = [];
    const seen = new Set();
    const add = (key, value) => {
      const k = (key || "").trim();
      if (!k || seen.has(k.toLowerCase())) return;
      seen.add(k.toLowerCase());
      fields.push({ key: k, value: value || "" });
    };
    (plan.infos_extraites || []).map(toField).forEach((f) => add(f.key, f.value));
    (plan.infos_manquantes || []).map(toField).forEach((f) => add(f.key, ""));
    FIELD_HINTS[categorie].forEach((k) => add(k, ""));
    return fields;
  }, [plan, categorie]);

  const [fields, setFields] = useState(initial);
  const update = (i, value) => setFields((prev) => prev.map((f, idx) => (idx === i ? { ...f, value } : f)));
  const filled = fields.filter((f) => f.value.trim()).length;

  return (
    <div className="mt-3 rounded-2xl border border-indigo-300/30 bg-white p-4 text-neutral-900">
      <div className="mb-3 flex items-center justify-between">
        <p className="text-xs font-semibold uppercase tracking-[0.18em] text-indigo-500">
          ▤ {categorie === "devis" ? "Devis préparé" : "Facture préparée"}
        </p>
        <span className="rounded-full bg-indigo-50 px-2 py-0.5 text-[10px] font-semibold text-indigo-600">
          {filled}/{fields.length} renseignés
        </span>
      </div>

      <div className="space-y-2">
        {fields.map((f, i) => (
          <label key={`${f.key}-${i}`} className="block">
            <span className="mb-0.5 flex items-center gap-1.5 text-[11px] font-medium text-neutral-500">
              {f.value.trim() ? <span className="text-emerald-500">=</span> : <span className="text-amber-500">?</span>}
              {f.key}
            </span>
            <input
              value={f.value}
              onChange={(e) => update(i, e.target.value)}
              placeholder="À compléter…"
              className="w-full rounded-lg border border-neutral-200 bg-neutral-50 px-2.5 py-1.5 text-sm outline-none focus:border-indigo-400 focus:bg-white"
            />
          </label>
        ))}
      </div>

      <p className="mt-3 rounded-lg bg-neutral-50 px-3 py-2 text-[11px] leading-4 text-neutral-500">
        Brouillon de préparation — rien n'est généré ni envoyé. La génération du document arrivera plus tard.
      </p>
    </div>
  );
}