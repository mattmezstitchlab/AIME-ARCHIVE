import React from "react";

// Rangée de pictos-actions contextuels proposés au clic sur une case.
// Pour une facture/un devis : générer, compléter, relancer, créer email, préparer l'envoi, classer en mémoire.
// Rien n'est exécuté automatiquement — chaque picto prépare une étape.
const ACTIONS = {
  facture: [
    { id: "generer", sym: "▤", label: "Générer", hint: "Préparer la facture" },
    { id: "completer", sym: "✎", label: "Compléter", hint: "Renseigner les infos manquantes" },
    { id: "email", sym: "✉", label: "Email", hint: "Préparer un email d'accompagnement" },
    { id: "envoyer", sym: "→", label: "Envoyer", hint: "Préparer l'envoi (brouillon)" },
    { id: "classer", sym: "◌", label: "Classer", hint: "Conserver en mémoire client" },
  ],
  devis: [
    { id: "generer", sym: "▤", label: "Préparer", hint: "Préparer le devis" },
    { id: "completer", sym: "✎", label: "Compléter", hint: "Renseigner les infos manquantes" },
    { id: "email", sym: "✉", label: "Email", hint: "Préparer un email d'accompagnement" },
    { id: "envoyer", sym: "→", label: "Envoyer", hint: "Préparer l'envoi (brouillon)" },
    { id: "classer", sym: "◌", label: "Classer", hint: "Conserver en mémoire client" },
  ],
};

export default function ActionPicker({ categorie, active, onPick }) {
  const actions = ACTIONS[categorie] || ACTIONS.facture;
  return (
    <div className="flex flex-wrap gap-1.5">
      {actions.map((a) => {
        const on = active === a.id;
        return (
          <button
            key={a.id}
            onClick={() => onPick(on ? null : a.id)}
            title={a.hint}
            className={`flex items-center gap-1.5 rounded-xl border px-2.5 py-1.5 text-xs font-medium transition-colors ${
              on
                ? "border-indigo-400 bg-indigo-500/20 text-indigo-100"
                : "border-white/10 bg-white/[0.04] text-slate-300 hover:bg-white/10"
            }`}
          >
            <span className="text-sm font-bold">{a.sym}</span>
            {a.label}
          </button>
        );
      })}
    </div>
  );
}