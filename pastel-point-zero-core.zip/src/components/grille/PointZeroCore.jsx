import React, { useEffect, useRef, useState } from "react";
import DialFace, { ticksFromNodes } from "./DialFace";

// Cadran central type montre : graduations radiales, croix au centre, aucune aiguille.
// Pendant l'analyse → balayage radial animé. À la fin → graduations colorées (nuancier
// de catégories, blanc = manque) + verdict au centre : "Tu m'as donné 8 choses…".
export default function PointZeroCore({ onSubmit, loading, steps = [], lastNodes = [] }) {
  const [text, setText] = useState("");
  const [dragging, setDragging] = useState(false);
  const inputRef = useRef(null);

  // Graduations colorées du dernier dépôt + verdict (donné / compris / manquant).
  const ticks = !loading ? ticksFromNodes(lastNodes) : [];
  const present = lastNodes.filter((n) => !(n.presence_state === "absent" || n.manque_probable || n.silence_significatif));
  const missing = lastNodes.filter((n) => n.presence_state === "absent" || n.manque_probable || n.silence_significatif);
  const verdict = !loading && lastNodes.length > 0
    ? { given: lastNodes.length, understood: present.length, missing: missing.length }
    : null;

  const handleDrop = (e) => {
    e.preventDefault();
    setDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) onSubmit({ text: "", file });
  };

  const submitText = (e) => {
    e.preventDefault();
    if (!text.trim()) return;
    onSubmit({ text, file: null });
    setText("");
  };

  return (
    <div
      onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
      onDragLeave={() => setDragging(false)}
      onDrop={handleDrop}
      className="flex flex-col items-center gap-5"
    >
      <button
        type="button"
        onClick={() => inputRef.current?.focus()}
        className={`relative flex items-center justify-center rounded-full transition-transform duration-500 ease-out focus-visible:outline-none ${dragging ? "scale-[1.06]" : ""}`}
      >
        <DialFace analyzing={loading} ticks={ticks} verdict={verdict} size={220} />
      </button>

      <form onSubmit={submitText} className="flex w-full max-w-xl flex-col gap-3">
        {/* Champ de prompt unique, soft & translucide — bouton intégré à droite (esprit Vercel). */}
        <div className="group relative flex items-center gap-2 rounded-full bg-white/[0.04] py-1.5 pl-5 pr-1.5 ring-1 ring-white/[0.08] backdrop-blur transition-colors focus-within:bg-white/[0.06] focus-within:ring-white/20">
          <input
            ref={inputRef}
            type="text"
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter") submitText(e); }}
            placeholder="Décrivez votre idée, une note…"
            className="min-w-0 flex-1 border-0 bg-transparent text-[15px] font-light text-foreground placeholder:text-muted-foreground/60 focus-visible:outline-none"
          />
          <button
            type="submit"
            disabled={loading || !text.trim()}
            className="h-9 shrink-0 rounded-full bg-foreground px-4 text-[13px] font-medium text-background transition-all hover:bg-foreground/90 disabled:opacity-30"
          >
            {loading ? "…" : "Générer"}
          </button>
        </div>
        <p className="text-center text-[12px] font-light text-muted-foreground/60">Ou glissez un fichier sur le cadran · ↵ pour générer</p>
      </form>
    </div>
  );
}