import React from "react";
import { Link } from "react-router-dom";
import { MATURATION } from "./config";

export default function DimensionCell({ dimension, nodes = [], onSelect, selected = false }) {
  const gray = nodes.filter((n) => n.etat_maturation === "ambigu").length;
  const ready = nodes.filter((n) => n.etat_maturation === "pret").length;
  const valid = nodes.filter((n) => n.etat_maturation === "valide").length;
  const dominant = nodes.find((n) => ["valide", "pret", "ambigu", "illumine", "detecte"].includes(n.etat_maturation))?.etat_maturation || "vide";
  const content = <>
    <div className="flex items-center justify-between gap-3">
      <div className="flex min-w-0 items-center gap-3">
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl border border-white/10 bg-white/[0.04] text-xl" style={{ color: dimension.color }}>{dimension.icon}</div>
        <div className="min-w-0 text-left"><h3 className="truncate text-xs font-semibold uppercase tracking-[0.16em]" style={{ color: dimension.color }}>{dimension.name}</h3><p className="text-xs text-slate-500">{nodes.length} nœuds</p></div>
      </div>
      <span className="text-xl" style={{ color: MATURATION[dominant].color }}>{MATURATION[dominant].symbol}</span>
    </div>
    <div className="mt-3 grid grid-cols-3 gap-1 text-center text-[10px] text-slate-400">
      <span className="rounded-lg bg-white/[0.04] py-1"><b className="text-emerald-300">{ready}</b> prêts</span>
      <span className="rounded-lg bg-white/[0.04] py-1"><b className="text-amber-300">{valid}</b> val.</span>
      <span className="rounded-lg bg-white/[0.04] py-1"><b className="text-orange-300">{gray}</b> amb.</span>
    </div>
  </>;
  const classes = `block w-full rounded-2xl border bg-slate-950/70 p-3 transition-colors hover:border-white/30 hover:bg-slate-900/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-200/70 ${selected ? "border-white/50" : "border-white/10"}`;
  return onSelect ? <button onClick={() => onSelect(dimension)} className={classes}>{content}</button> : <Link to={`/dimension/${dimension.key}`} className={classes}>{content}</Link>;
}