// Langage visuel universel : traduit l'état profond d'un nœud en UN signe.
// Le signe vient d'abord, le texte ensuite. Priorité du plus urgent au plus calme.
//   ▲ alerte/zone grise · × conflit/risque · − absence/manque · ÷ répartir/budget
//   = cohérent/validé · ◎ lien mémoire · → prochaine étape · + à compléter
//   ◐ détecté · ● prêt · ✓ confirmé · ? à vérifier
export const GLYPH_COLORS = {
  "▲": "#FB923C", "×": "#F87171", "−": "#FCD34D", "÷": "#FBBF24",
  "=": "#34D399", "◎": "#A78BFA", "→": "#34D399", "+": "#60A5FA",
  "◐": "#22D3EE", "●": "#34D399", "✓": "#84CC16", "?": "#94A3B8",
};

// Renvoie le signe dominant d'un nœud selon sa nature profonde.
export function glyphForNode(node = {}) {
  if (node.silence_significatif || node.manque_probable || node.presence_state === "absent") return "−";
  if (node.etat_maturation === "ambigu" || node.nature_information === "ambigue") return "▲";
  if ((node.risques?.length || 0) > 0 || node.role === "risque") return "×";
  if (node.dimension === "economie" || node.dimension === "ressources") return "÷";
  if (node.etat_maturation === "valide") return "=";
  if (node.etat_maturation === "pret") return "●";
  if (node.role === "action" || node.dimension === "actions" || (node.anticipations?.length || 0) > 0) return "→";
  if (node.etat_maturation === "illumine") return "✓";
  return "◐";
}

// Choisit noir ou blanc selon la luminance d'une couleur de fond (#rrggbb).
// Garantit que le signe reste lisible sur n'importe quelle dimension.
export function readableOn(hex = "#000000") {
  const c = hex.replace("#", "");
  const r = parseInt(c.slice(0, 2), 16) || 0;
  const g = parseInt(c.slice(2, 4), 16) || 0;
  const b = parseInt(c.slice(4, 6), 16) || 0;
  // Luminance perçue (ITU-R BT.601).
  const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  return luminance > 0.6 ? "#0A0A0A" : "#FFFFFF";
}

// Compte les signes présents dans un ensemble de nœuds — pour le résumé du cercle.
export function glyphTally(nodes = []) {
  const tally = {};
  nodes.forEach((n) => { const g = glyphForNode(n); tally[g] = (tally[g] || 0) + 1; });
  // Ordre d'affichage stable : du plus signifiant au plus calme.
  const order = ["−", "▲", "×", "÷", "→", "◎", "=", "●", "✓", "◐"];
  return order.filter((g) => tally[g]).map((g) => ({ glyph: g, count: tally[g], color: GLYPH_COLORS[g] }));
}