import React from "react";

const steps = [
  { n: "01", title: "Point Zéro absorbe", text: "Déposez le chaos, sans choisir où le ranger.", tone: "text-red-200 border-red-300/20 bg-red-500/10" },
  { n: "02", title: "La grille classe", text: "Les 12 dimensions deviennent le vrai menu.", tone: "text-cyan-200 border-cyan-300/20 bg-cyan-500/10" },
  { n: "03", title: "Les nœuds mûrissent", text: "Détecté, illuminé, prêt, validé ou ambigu.", tone: "text-emerald-200 border-emerald-300/20 bg-emerald-500/10" },
  { n: "04", title: "Les projections exécutent", text: "Mariage/Jour J n’est qu’un extrait actionnable.", tone: "text-amber-200 border-amber-300/20 bg-amber-500/10" }
];

export default function ManifestFlow() {
  return (
    <section className="grid gap-3 md:grid-cols-4">
      {steps.map((step) => (
        <div key={step.n} className={`rounded-2xl border p-4 ${step.tone}`}>
          <span className="font-mono text-xs tracking-[0.25em] opacity-70">{step.n}</span>
          <h3 className="mt-3 text-base font-semibold text-white">{step.title}</h3>
          <p className="mt-1 text-sm leading-6 text-slate-300">{step.text}</p>
        </div>
      ))}
    </section>
  );
}