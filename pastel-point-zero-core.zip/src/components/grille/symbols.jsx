// Langage symbolique universel du moteur. Réutilisable par les demandes automatiques futures.
// + ajouter · − retirer/absence · × conflit/risque · ÷ répartir · = validé · ? à vérifier · → étape · ◎ mémoire · ▲ alerte
export const SYM = {
  ajouter: "+",
  retirer: "−",
  conflit: "×",
  repartir: "÷",
  valide: "=",
  verifier: "?",
  etape: "→",
  memoire: "◎",
  alerte: "▲",
};

// Pastilles symboliques des 4 panneaux secondaires.
export const PANELS = {
  comprendre: { sym: "◐", label: "Comprendre", hint: "ce que le moteur a compris", color: "#22D3EE", soft: "rgba(34,211,238,0.12)" },
  clarifier: { sym: "▲", label: "À clarifier", hint: "ambiguïtés et manques", color: "#FB923C", soft: "rgba(251,146,60,0.14)" },
  agir: { sym: "→", label: "Agir", hint: "vues exploitables", color: "#34D399", soft: "rgba(52,211,153,0.12)" },
  memoire: { sym: "◎", label: "Mémoire", hint: "système nerveux", color: "#A78BFA", soft: "rgba(167,139,250,0.14)" },
};