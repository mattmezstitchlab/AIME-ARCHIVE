import React from "react";
import { DIMENSIONS, MATURATION } from "./config";

const stateRank = ["vide", "detecte", "illumine", "pret", "valide", "ambigu"];
const connectionPaths = ["M80 100 C170 50 250 210 340 125 S510 80 610 185", "M120 260 C250 180 320 330 450 245 S610 210 770 295", "M210 90 C310 175 390 120 505 205 S660 150 850 235", "M160 410 C310 330 420 470 555 360 S720 320 880 430"];

export default function DimensionLiveMap({ nodes = [], selectedDimension, onDimensionSelect, onNodeSelect }) {
  const cells = Array.from({ length: 144 }).map((_, index) => {
    const dim = DIMENSIONS[index % DIMENSIONS.length];
    const node = nodes.filter((n) => n.dimension === dim.key)[Math.floor(index / DIMENSIONS.length)];
    const state = node?.etat_maturation || "vide";
    const opacity = state === "vide" ? 0.18 : state === "detecte" ? 0.48 : state === "illumine" ? 0.76 : 1;
    return { id: `${dim.key}-${index}`, dim, state, opacity, node };
  });
  return (
    <section className="relative flex min-h-0 flex-1 flex-col overflow-hidden rounded-xl border border-white/[0.06] bg-neutral-900/80 p-3">
      <div className="mb-2 flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
        <div>
          <p className="text-[10px] uppercase tracking-[0.28em] text-neutral-500">Grille Universelle · 12×12</p>
          <h2 className="text-base font-semibold text-neutral-100">Menu principal vivant</h2>
        </div>
        <div className="flex flex-wrap gap-2 text-[11px] text-neutral-500">
          {stateRank.map((key) => <span key={key} className="inline-flex items-center gap-1"><span style={{ color: MATURATION[key].color }}>{MATURATION[key].symbol}</span>{MATURATION[key].label}</span>)}
        </div>
      </div>
      <div className="relative min-h-0 flex-1 rounded-lg border border-white/[0.05] bg-black/40 p-2.5">
        <svg viewBox="0 0 960 520" className="pointer-events-none absolute inset-0 h-full w-full opacity-60" aria-hidden="true">
          {connectionPaths.map((d, index) => <path key={d} d={d} fill="none" stroke={DIMENSIONS[index * 3]?.color || "#22D3EE"} strokeWidth="2" strokeDasharray="7 10" opacity="0.5" />)}
        </svg>
        <div className="relative grid h-full grid-cols-12 gap-1.5">
          {cells.map((cell) => {
            const highlighted = selectedDimension === cell.dim.key;
            return <button key={cell.id} onClick={() => cell.node ? onNodeSelect?.(cell.node) : onDimensionSelect?.(cell.dim)} title={`${cell.dim.name} · ${MATURATION[cell.state].label}`} className={`aspect-square rounded-md border transition-colors hover:border-white/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-200/70 ${highlighted ? "border-white/70" : "border-white/5"}`} style={{ backgroundColor: cell.node ? cell.dim.color : "#1c1c1c", opacity: cell.opacity, boxShadow: cell.node ? `0 0 12px ${cell.dim.color}` : "none" }} />;
          })}
        </div>
      </div>
    </section>
  );
}