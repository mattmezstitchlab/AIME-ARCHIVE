import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import DayPlanTimeline from "@/components/grille/mariage/DayPlanTimeline";
import DayPlanHeader from "@/components/grille/mariage/DayPlanHeader";
import { buildDayPlan } from "@/components/grille/mariage/dayPlan";

export default function ProjectionMariage() {
  // Tous les nœuds non vides : le déroulé est une lecture, afficher un horaire détecté n'exécute rien.
  const [nodes, setNodes] = useState([]);
  const [projection, setProjection] = useState(null);
  // Le planning correspond au dépôt cliqué : on filtre sur sa source (?source=...).
  const sourceId = new URLSearchParams(window.location.search).get("source");
  useEffect(() => {
    const promise = sourceId
      ? base44.entities.NoeudMemoire.filter({ source_brute_id: sourceId }, "-created_date", 300)
      : base44.entities.NoeudMemoire.list("-created_date", 300);
    promise.then((all) => {
      setNodes(all.filter((n) => n.etat_maturation !== "vide"));
    });
    base44.entities.ProjectionMariage.filter({ type_vue: "timeline" }, "-created_date", 1).then((p) => {
      if (p?.length) setProjection(p[0]);
    });
  }, [sourceId]);

  const { moments, libres, insights } = buildDayPlan(nodes);

  return <main className="min-h-screen bg-background px-4 py-8 text-foreground md:px-8"><div className="relative z-10 mx-auto max-w-5xl">
    <Link to="/" className="inline-flex items-center gap-1 text-[15px] font-medium text-primary">‹ Retour</Link>
    <section className="mt-6">
      <DayPlanHeader projection={projection} momentsCount={moments.length} />
      <DayPlanTimeline moments={moments} libres={libres} insights={insights} />
    </section>
  </div></main>;
}