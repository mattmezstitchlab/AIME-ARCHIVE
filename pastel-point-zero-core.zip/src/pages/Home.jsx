import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import PointZeroCore from "@/components/grille/PointZeroCore";
import MinimalGrid from "@/components/grille/MinimalGrid";
import GlobalReport from "@/components/grille/GlobalReport";
import GreyZonePanel from "@/components/grille/GreyZonePanel";
import NervousSystemPanel from "@/components/grille/NervousSystemPanel";
import ProjectionExtract from "@/components/grille/ProjectionExtract";
import CockpitDrawer from "@/components/grille/CockpitDrawer";
import NodeDetailPanel from "@/components/grille/NodeDetailPanel";
import AnalysisSequence from "@/components/grille/result/AnalysisSequence";
import { dimensionOf } from "@/components/grille/config";
import { PANELS } from "@/components/grille/symbols";

export default function Home() {
  const [nodes, setNodes] = useState([]); const [fragments, setFragments] = useState([]); const [links, setLinks] = useState([]); const [sources, setSources] = useState([]); const [sourcesCount, setSourcesCount] = useState(0); const [loading, setLoading] = useState(false);
  const [drawer, setDrawer] = useState(null); const [selectedNode, setSelectedNode] = useState(null); const [steps, setSteps] = useState([]); const [lastResult, setLastResult] = useState(null);
  const [reportOpen, setReportOpen] = useState(false); const [expertOpen, setExpertOpen] = useState(false); const [analysisDone, setAnalysisDone] = useState(false);
  const load = async () => { setNodes(await base44.entities.NoeudMemoire.list("-created_date", 200)); setFragments(await base44.entities.FragmentDetecte.list("-created_date", 80)); setLinks(await base44.entities.LienMemoire.list("-created_date", 80)); const loadedSources = await base44.entities.SourceBrute.list("-created_date", 200); setSources(loadedSources); setSourcesCount(loadedSources.length); };
  useEffect(() => { load(); }, []);
  const compile = async ({ text, file }) => {
    setLoading(true);
    setSteps(["Lecture de la source", "Compréhension brute en cours…"]);
    let fichier_url = ""; let type_source = "texte";
    if (file) { const up = await base44.integrations.Core.UploadFile({ file }); fichier_url = up.file_url; type_source = file.type?.includes("image") ? "image" : file.name.endsWith(".pdf") ? "pdf" : "note"; }
    const res = await base44.functions.invoke("analyzeSourceBrute", { contenu_texte: text, fichier_url, type_source });
    const newFragments = res.data.fragments || []; const newNodes = res.data.nodes || []; const newLinks = res.data.links || []; const newSource = res.data.source;
    setSteps(buildSteps({ fragments: newFragments, nodes: newNodes, links: newLinks, source: newSource }));
    setLastResult({ source: newSource, fragments: newFragments, nodes: newNodes, links: newLinks });
    setFragments(newFragments); setNodes(newNodes.concat(nodes)); setLinks(newLinks);
    await load();
    // Ouvre la modale tout de suite : la séquence d'analyse défile bloc par bloc,
    // puis le rapport pédagogique se révèle quand elle est terminée.
    setLoading(false);
    setAnalysisDone(false);
    setReportOpen(true);
  };
  // « Continuer » façon Manus : une étape proposée est cliquée → on la renvoie au moteur
  // comme nouveau dépôt pour qu'il la creuse et propose la suite.
  const continueOnStep = (label) => {
    if (!label) return;
    setReportOpen(false);
    compile({ text: label, file: null });
  };
  const cleanTests = async () => { await base44.entities.LienMemoire.deleteMany({}); await base44.entities.NoeudMemoire.deleteMany({}); await base44.entities.FragmentDetecte.deleteMany({}); await base44.entities.SourceBrute.deleteMany({}); setLastResult(null); await load(); };

  const greyCount = fragments.filter((f) => f.zone_grise || f.statut === "ambigu" || f.statut === "non_classe").length + sources.reduce((acc, s) => acc + (s.zones_grises?.length || 0), 0);

  return <main className="relative flex h-screen flex-col overflow-hidden bg-background text-foreground">
    {/* Cercle Point Zéro — seul et central. Aucun texte superflu. */}
    <div className="relative z-20 flex flex-1 flex-col items-center justify-center px-6">
      <PointZeroCore onSubmit={compile} loading={loading} steps={steps} lastNodes={lastResult?.nodes || []} />
    </div>

    {/* Vue globale des 12 dimensions — accès discret, toujours visible */}
    <Link to="/grille" className="absolute bottom-5 left-5 z-20 flex h-10 items-center gap-1.5 rounded-full ios-material px-4 text-[13px] font-medium text-muted-foreground transition-colors hover:text-foreground">⊞ Grille</Link>

    {/* Accès expert unique et discret — les quatre panneaux ne sont plus l'expérience principale */}
    {lastResult && <button onClick={() => setExpertOpen((v) => !v)} className="absolute bottom-5 right-5 z-20 flex h-10 items-center gap-1.5 rounded-full ios-material px-4 text-[13px] font-medium text-muted-foreground transition-colors hover:text-foreground">⚙ Expert</button>}
    {expertOpen && (
      <div className="absolute bottom-16 right-5 z-20 flex flex-col gap-0.5 rounded-2xl bg-card p-1.5 shadow-2xl ring-1 ring-white/10">
        <ExpertItem cfg={PANELS.comprendre} onClick={() => { setDrawer("bottom"); setExpertOpen(false); }} />
        <ExpertItem cfg={PANELS.clarifier} count={greyCount} onClick={() => { setDrawer("grey"); setExpertOpen(false); }} />
        <ExpertItem cfg={PANELS.agir} onClick={() => { setDrawer("right"); setExpertOpen(false); }} />
        <ExpertItem cfg={PANELS.memoire} onClick={() => { setDrawer("left"); setExpertOpen(false); }} />
      </div>
    )}

    {/* LE récit pédagogique unique — s'ouvre automatiquement après chaque dépôt.
        D'abord la séquence d'analyse animée (effet wow), puis le rapport. */}
    {reportOpen && lastResult && (
      <div className="fixed inset-0 z-40 flex items-end justify-center overflow-y-auto bg-black/60 p-0 backdrop-blur-sm sm:items-center sm:p-8" onClick={() => setReportOpen(false)}>
        <div className="my-0 w-full max-w-xl rounded-t-3xl bg-card p-5 shadow-2xl ring-1 ring-white/10 sm:my-auto sm:rounded-3xl sm:p-7" onClick={(e) => e.stopPropagation()}>
          {/* Poignée de drag iOS */}
          <div className="mx-auto mb-4 h-1.5 w-10 rounded-full bg-white/20 sm:hidden" />
          <div className="mb-5 flex items-start justify-between">
            <div>
              <p className="text-[12px] font-medium text-muted-foreground">{analysisDone ? "Ce qui vient de se passer" : "Analyse en cours"}</p>
              <h2 className="mt-0.5 text-2xl font-bold tracking-tight text-foreground">{analysisDone ? "Le récit du dépôt" : "Lecture du dépôt…"}</h2>
            </div>
            {analysisDone && <button onClick={() => setReportOpen(false)} className="text-[15px] font-medium text-primary">OK</button>}
          </div>
          {analysisDone
            ? <GlobalReport result={lastResult} onContinue={continueOnStep} />
            : <AnalysisSequence steps={buildSteps(lastResult)} onDone={() => setAnalysisDone(true)} />}
        </div>
      </div>
    )}

    <CockpitDrawer open={drawer === "left"} side="left" title="◎ Mémoire" onClose={() => setDrawer(null)}><NervousSystemPanel sourcesCount={sourcesCount} fragments={fragments} nodes={nodes} links={links} onCleanTests={cleanTests} /></CockpitDrawer>
    <CockpitDrawer open={drawer === "right"} side="right" title="→ Agir" onClose={() => setDrawer(null)}><ProjectionExtract nodes={nodes} /></CockpitDrawer>
    <CockpitDrawer open={drawer === "grey"} side="right" title="▲ À clarifier" onClose={() => setDrawer(null)}><GreyZonePanel fragments={fragments} sources={sources} /></CockpitDrawer>
    <CockpitDrawer open={drawer === "bottom"} side="bottom" title="◐ Comprendre — rapport du dernier dépôt" onClose={() => setDrawer(null)}><GlobalReport result={lastResult} /></CockpitDrawer>
    <NodeDetailPanel node={selectedNode} source={lastResult?.source} onClose={() => setSelectedNode(null)} />
  </main>;
}

// Construit les micro-étapes de compréhension affichées dans le cercle central.
function buildSteps({ fragments = [], nodes = [], links = [], source }) {
  const out = ["Lecture de la source"];
  if (source?.comprehension_brute) out.push("Compréhension brute saisie");
  if (fragments.length) out.push(`${fragments.length} fragment${fragments.length > 1 ? "s" : ""} détecté${fragments.length > 1 ? "s" : ""}`);

  // Dimensions suggérées, regroupées avec leur compte d'éléments.
  const byDim = {};
  nodes.forEach((n) => { byDim[n.dimension] = (byDim[n.dimension] || 0) + 1; });
  Object.entries(byDim).forEach(([key, count]) => { const dim = dimensionOf(key); out.push(`${dim.name} → ${count} élément${count > 1 ? "s" : ""}`); });

  const grey = fragments.filter((f) => f.zone_grise || f.statut === "ambigu" || f.statut === "non_classe").length + (source?.zones_grises?.length || 0);
  if (grey) out.push(`${grey} zone${grey > 1 ? "s" : ""} grise${grey > 1 ? "s" : ""} repérée${grey > 1 ? "s" : ""}`);

  if (nodes.length) out.push(`${nodes.length} nœud${nodes.length > 1 ? "s" : ""} créé${nodes.length > 1 ? "s" : ""}`);
  if (links.length) out.push(`${links.length} lien${links.length > 1 ? "s" : ""} possible${links.length > 1 ? "s" : ""}`);

  const projections = [...new Set(nodes.flatMap((n) => n.projections_candidates || n.projections_possibles || []))];
  if (projections.length) out.push(`Projection ${projections[0]} possible`);

  return out;
}

// Entrée du menu expert : symbole coloré + libellé + compteur éventuel.
function ExpertItem({ cfg, count, onClick }) {
  return <button onClick={onClick} title={cfg.hint} className="flex items-center gap-2.5 rounded-xl py-2 pl-2 pr-4 text-foreground/80 transition-colors hover:bg-white/5 hover:text-foreground focus-visible:outline-none">
    <span className="flex h-8 w-8 items-center justify-center rounded-full text-sm font-bold" style={{ color: cfg.color, background: cfg.soft }}>{cfg.sym}</span>
    <span className="text-[15px] font-medium">{cfg.label}</span>
    {count > 0 && <span className="ml-auto rounded-full px-1.5 text-[10px] font-semibold" style={{ color: cfg.color, background: cfg.soft }}>{count}</span>}
  </button>;
}