import React, { useEffect, useMemo, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import { DIMENSIONS } from "@/components/grille/config";
import DimensionTile from "@/components/grille/global/DimensionTile";
import DimensionDetail from "@/components/grille/global/DimensionDetail";

// Vue globale : les 12 dimensions en grille interactive.
// Un clic sur une dimension révèle ses nœuds et fragments dans un panneau épuré.
export default function GrilleGlobale() {
  const [nodes, setNodes] = useState([]);
  const [fragments, setFragments] = useState([]);
  const [selected, setSelected] = useState(null);

  useEffect(() => {
    base44.entities.NoeudMemoire.list("-created_date", 300).then((all) => setNodes(all.filter((n) => n.etat_maturation !== "vide")));
    base44.entities.FragmentDetecte.list("-created_date", 200).then(setFragments);
  }, []);

  // Compte de nœuds par dimension.
  const counts = useMemo(() => {
    const c = {};
    nodes.forEach((n) => { c[n.dimension] = (c[n.dimension] || 0) + 1; });
    return c;
  }, [nodes]);

  const selectedNodes = useMemo(() => (selected ? nodes.filter((n) => n.dimension === selected) : []), [selected, nodes]);
  const selectedFragments = useMemo(() => (selected ? fragments.filter((f) => f.dimension_suggeree === selected) : []), [selected, fragments]);

  return (
    <main className="min-h-screen bg-background px-4 py-8 text-foreground md:px-8">
      <div className="mx-auto max-w-5xl">
        <Link to="/" className="inline-flex items-center gap-1 text-[15px] font-medium text-primary">‹ Retour</Link>

        <header className="mb-8 mt-6 text-center">
          <p className="text-[12px] font-medium uppercase tracking-[0.2em] text-muted-foreground">Vue globale</p>
          <h1 className="mt-2 text-4xl font-bold tracking-tight text-foreground sm:text-5xl">Vos 12 dimensions</h1>
          <p className="mt-3 text-[14px] text-muted-foreground">Touchez une dimension pour voir les nœuds et fragments rangés à l'intérieur.</p>
        </header>

        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {DIMENSIONS.map((d) => (
            <DimensionTile key={d.key} dimKey={d.key} count={counts[d.key] || 0} active={selected === d.key} onClick={() => setSelected(d.key === selected ? null : d.key)} />
          ))}
        </div>

        {selected && (
          <div className="mt-8 rounded-3xl bg-card p-5 ring-1 ring-white/10 sm:p-7">
            <DimensionDetail dimKey={selected} nodes={selectedNodes} fragments={selectedFragments} />
          </div>
        )}
      </div>
    </main>
  );
}