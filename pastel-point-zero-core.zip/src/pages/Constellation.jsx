import React, { useEffect, useState } from "react";
import { Play, Square, Loader2, Volume2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import usePlumeVoice from "@/hooks/usePlumeVoice";
import ConstellationMap from "@/components/grille/constellation/ConstellationMap";
import ContratConscience from "@/components/grille/constellation/ContratConscience";
import PlumeChat from "@/components/grille/constellation/PlumeChat";
import { lireConstellation } from "@/lib/plume/constellation";
import { AMBIANCES } from "@/lib/plume/ambiances";

// La constellation familiale, comme un jeu de conscience.
// Chaque personne est une étoile ; les places vides sont les non-dits à transmuter.
// PLUME lit la lignée avec bienveillance (guerres, deuils, secrets), sans jamais accuser.
// Quand tout est rallumé et validé → un Contrat de Conscience se génère et se scelle.
export default function Constellation() {
  const { speak, stop, speaking, loading, level } = usePlumeVoice();
  const [nodes, setNodes] = useState([]);
  const [lecture, setLecture] = useState("");
  const [loadingLecture, setLoadingLecture] = useState(false);
  const [contrat, setContrat] = useState(null);
  const [loadingContrat, setLoadingContrat] = useState(false);

  const sourceId = new URLSearchParams(window.location.search).get("source");

  useEffect(() => {
    const p = sourceId
      ? base44.entities.NoeudMemoire.filter({ source_brute_id: sourceId }, "-created_date", 300)
      : base44.entities.NoeudMemoire.list("-created_date", 300);
    p.then((all) => setNodes(all.filter((n) => n.etat_maturation !== "vide"))).catch(() => {});
  }, [sourceId]);

  const { complet, rallumee } = lireConstellation(nodes);
  const ambiance = AMBIANCES.accueil;
  const busy = loading || loadingLecture;

  // PLUME lit la constellation à voix haute.
  const handleLire = async () => {
    if (speaking) return stop();
    let texte = lecture;
    if (!texte) {
      setLoadingLecture(true);
      try {
        const res = await base44.functions.invoke("plumeConstellation", { source_id: sourceId, mode: "lecture" });
        texte = res.data?.lecture || "";
        setLecture(texte);
      } finally {
        setLoadingLecture(false);
      }
    }
    if (texte) speak(texte);
  };

  // Scellement du Contrat de Conscience — uniquement quand tout est rallumé.
  const handleSceller = async () => {
    setLoadingContrat(true);
    try {
      const res = await base44.functions.invoke("plumeConstellation", { source_id: sourceId, mode: "contrat" });
      setContrat(res.data?.contrat || null);
    } finally {
      setLoadingContrat(false);
    }
  };

  return (
    <main className="relative min-h-screen w-full overflow-hidden bg-black text-white">
      <img src={ambiance.image} alt="" className="fixed inset-0 h-full w-full object-cover opacity-30" />
      <div className="fixed inset-0 bg-gradient-to-b from-black/70 via-black/60 to-black" />

      <div className="relative z-10 mx-auto flex min-h-screen max-w-2xl flex-col items-center px-6 py-16">
        <p className="mb-1 text-[11px] uppercase tracking-[0.3em] text-white/40">Constellation familiale</p>
        <h1 className="mb-10 text-center text-xl font-light text-white/90">
          Ce qui brille, ce qui manque, ce qui demande à être transmis.
        </h1>

        {/* Le ciel familial */}
        <ConstellationMap nodes={nodes} size={340} />

        {/* Lecture vocale de PLUME */}
        <button
          onClick={handleLire}
          disabled={busy}
          className="mt-8 flex items-center gap-2.5 rounded-full bg-white/10 px-6 py-3 text-sm font-medium text-white ring-1 ring-white/20 backdrop-blur-md transition-all hover:bg-white/20 disabled:opacity-40"
        >
          {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : speaking ? <Square className="h-4 w-4 fill-current" /> : <Play className="h-4 w-4 fill-current" />}
          {speaking ? "PLUME parle…" : "Écouter la lecture de PLUME"}
        </button>

        {lecture && (
          <p className="mt-6 max-w-md text-center text-sm leading-relaxed text-white/75">
            <Volume2 className="mr-1.5 inline h-3.5 w-3.5 text-white/40" />
            {lecture}
          </p>
        )}

        {/* Progression : la lumière rallumée */}
        <div className="mt-10 w-full max-w-xs">
          <div className="mb-1.5 flex justify-between text-[11px] text-white/50">
            <span>Lignée rallumée</span>
            <span>{Math.round(rallumee * 100)}%</span>
          </div>
          <div className="h-1 overflow-hidden rounded-full bg-white/10">
            <div className="h-full bg-white/80 transition-all duration-1000" style={{ width: `${rallumee * 100}%` }} />
          </div>
        </div>

        {/* Scellement du contrat — débloqué quand tout est reconnu */}
        {!contrat && (
          <button
            onClick={handleSceller}
            disabled={!complet || loadingContrat}
            className="mt-8 rounded-full bg-white px-7 py-3 text-sm font-semibold text-black transition-all hover:bg-white/90 disabled:cursor-not-allowed disabled:bg-white/15 disabled:text-white/40"
          >
            {loadingContrat ? "Scellement…" : complet ? "Sceller le Contrat de Conscience" : "Rallume chaque place pour sceller le contrat"}
          </button>
        )}

        {contrat && (
          <div className="mt-10 w-full animate-[fadeIn_0.8s_ease]">
            <ContratConscience contrat={contrat} />
          </div>
        )}

        {/* Ce qu'on avait oublié : converser avec PLUME par écrit. */}
        <div className="mt-12 w-full">
          <p className="mb-3 text-center text-[11px] uppercase tracking-[0.25em] text-white/40">
            Parle à PLUME
          </p>
          <PlumeChat sourceId={sourceId} />
        </div>
      </div>
    </main>
  );
}