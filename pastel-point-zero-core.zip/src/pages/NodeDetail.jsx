import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Link, useParams } from "react-router-dom";
import MaturationBadge from "@/components/grille/MaturationBadge";
import NodeCard from "@/components/grille/NodeCard";
import { dimensionOf } from "@/components/grille/config";

export default function NodeDetail() {
  const { id } = useParams(); const [node, setNode] = useState(null); const [children, setChildren] = useState([]); const [links, setLinks] = useState([]);
  const load = async () => { const n = await base44.entities.NoeudMemoire.get(id); setNode(n); setChildren(await base44.entities.NoeudMemoire.filter({ parent_noeud_id: id })); setLinks(await base44.entities.LienMemoire.filter({ noeud_source_id: id })); };
  useEffect(() => { load(); }, [id]);
  const addChild = async () => { await base44.entities.NoeudMemoire.create({ titre: `Sous-nœud de ${node.titre}`, contenu_enrichi: "Sous-grille héritée du nœud parent.", dimension: node.dimension, sous_dimension: node.sous_dimension, etat_maturation: "vide", couleur_dimension: node.couleur_dimension, parent_noeud_id: node.id, confiance_ia: 0, raison_classification: "Créé par subdivision fractale humaine.", tags: node.tags || [] }); await load(); };
  const validate = async () => { await base44.entities.NoeudMemoire.update(id, { etat_maturation: "valide", date_validation: new Date().toISOString() }); await load(); };
  if (!node) return <main className="min-h-screen bg-[#0A0F1E] p-8 text-white">Chargement…</main>;
  const dim = dimensionOf(node.dimension);
  return <main className="min-h-screen bg-[#0A0F1E] px-4 py-8 text-white md:px-8"><div className="mx-auto max-w-5xl">
    <Link to={`/dimension/${node.dimension}`} className="text-sm text-slate-400 hover:text-white">← Dézoomer vers {dim.name}</Link>
    <section className="mt-6 rounded-[2rem] border border-white/10 bg-slate-900/75 p-8"><div className="flex flex-wrap items-start justify-between gap-4"><div><p className="uppercase tracking-[0.2em]" style={{ color: dim.color }}>{dim.icon} {dim.name} · {node.sous_dimension}</p><h1 className="mt-3 text-4xl font-bold">{node.titre}</h1></div><MaturationBadge state={node.etat_maturation} /></div><p className="mt-6 text-lg text-slate-200">{node.contenu_enrichi}</p><div className="mt-6 rounded-2xl bg-black/20 p-4 text-sm text-slate-300"><b className="text-white">Raison de classification :</b> {node.raison_classification}<br /><b className="text-white">Confiance :</b> {node.confiance_ia || 0}%<br /><b className="text-white">Projections possibles :</b> {(node.projections_possibles || []).join(", ") || "aucune"}</div><div className="mt-5 flex gap-3"><button onClick={addChild} className="rounded-xl bg-white/10 px-4 py-2 text-sm">Créer une sous-grille</button><button onClick={validate} className="rounded-xl bg-amber-400/15 px-4 py-2 text-sm text-amber-200">★ Valider humainement</button></div></section>
    <section className="mt-6 grid gap-4 md:grid-cols-2"><div className="rounded-2xl border border-white/10 p-5"><h2 className="font-semibold">Liens mémoire</h2>{links.map((l) => <p key={l.id} className="mt-2 text-sm text-slate-300">{l.type_lien} · force {l.force}% · {l.direction}</p>)}{!links.length && <p className="mt-2 text-sm text-slate-500">Aucun lien sortant.</p>}</div><div className="rounded-2xl border border-white/10 p-5"><h2 className="font-semibold">Règle absolue</h2><p className="mt-2 text-sm text-slate-300">Une information n’est pas une tâche. Elle ne devient actionnable qu’une fois prête ou validée.</p></div></section>
    <section className="mt-6"><h2 className="mb-3 text-xl font-semibold">Sous-nœuds</h2><div className="grid gap-4 md:grid-cols-2">{children.map((c) => <NodeCard key={c.id} node={c} />)}</div></section>
  </div></main>;
}