import React, { useEffect, useState } from "react";
import { Loader2, HeartHandshake } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { AMBIANCES } from "@/lib/plume/ambiances";
import SiteHeader from "@/components/site/SiteHeader";
import CockpitBackstage from "@/components/grille/cockpit/CockpitBackstage";
import useProfil from "@/hooks/useProfil";
import MatchPrestataireCard from "@/components/grille/match/MatchPrestataireCard";
import MatchCoupleCard from "@/components/grille/match/MatchCoupleCard";

// L'entremetteuse, côté écran. Double sens :
// - Marié → les prestataires du registre, avec leur côté humain.
// - Prestataire/lieu → les couples qui cherchent (date pressentie renseignée).
export default function Rencontres() {
  const { profil, loading: loadingProfil } = useProfil();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [cockpit, setCockpit] = useState(false);

  useEffect(() => {
    base44.functions
      .invoke("plumeMatch", {})
      .then((res) => setData(res.data))
      .catch(() => setData({ view: "prestataires", items: [] }))
      .finally(() => setLoading(false));
  }, []);

  const ambiance = AMBIANCES.accueil;
  const estDemandes = data?.view === "demandes";
  const items = data?.items || [];

  const titre = estDemandes ? "Des mariés qui te cherchent" : "Ton carnet de prestataires";
  const sous = estDemandes
    ? "Les couples avec une date en tête — de belles rencontres à saisir."
    : "PLUME connaît chacun d'eux. Écoute, ressens, choisis.";

  return (
    <main className="relative min-h-screen w-full overflow-hidden bg-black text-white">
      <img src={ambiance.image} alt="" className="fixed inset-0 h-full w-full object-cover opacity-25" />
      <div className="fixed inset-0 bg-gradient-to-b from-black/80 via-black/70 to-black" />

      <SiteHeader profil={profil} onCockpit={() => setCockpit(true)} />

      <div className="relative z-10 mx-auto flex min-h-screen max-w-xl flex-col px-5 pb-16 pt-20">
        <div className="mb-6 flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-full bg-white/10 ring-1 ring-white/15">
            <HeartHandshake className="h-5 w-5 text-white/80" />
          </span>
          <div>
            <h1 className="text-xl font-semibold tracking-tight">{titre}</h1>
            <p className="text-[12.5px] text-white/50">{sous}</p>
          </div>
        </div>

        {loading || loadingProfil ? (
          <div className="flex flex-1 items-center justify-center">
            <Loader2 className="h-6 w-6 animate-spin text-white/40" />
          </div>
        ) : items.length === 0 ? (
          <div className="mt-16 text-center text-sm text-white/50">
            {estDemandes
              ? "Aucun couple en recherche pour l'instant. Précise tes dispos, PLUME te proposera dès qu'un mariage cherche ton métier."
              : "Ton carnet est encore vide. Les prestataires apparaîtront ici dès qu'ils rejoignent Point Zéro."}
          </div>
        ) : (
          <div className="space-y-2.5">
            {estDemandes
              ? items.map((it) => <MatchCoupleCard key={it.id} item={it} />)
              : items.map((it) => <MatchPrestataireCard key={it.id} item={it} />)}
          </div>
        )}
      </div>

      <CockpitBackstage open={cockpit} onClose={() => setCockpit(false)} />
    </main>
  );
}