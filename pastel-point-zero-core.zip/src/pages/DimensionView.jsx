import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Link, useParams } from "react-router-dom";
import NodeCard from "@/components/grille/NodeCard";
import { dimensionOf } from "@/components/grille/config";

export default function DimensionView() {
  const { key } = useParams(); const dim = dimensionOf(key); const [nodes, setNodes] = useState([]);
  useEffect(() => { base44.entities.NoeudMemoire.filter({ dimension: key }, "-created_date", 200).then(setNodes); }, [key]);
  return <main className="min-h-screen bg-[#0A0F1E] px-4 py-8 text-white md:px-8"><div className="mx-auto max-w-6xl">
    <Link to="/" className="text-sm text-slate-400 hover:text-white">← Dézoomer vers la grille</Link>
    <header className="mt-6 rounded-[2rem] border border-white/10 bg-slate-900/70 p-8"><div className="text-5xl" style={{ color: dim.color }}>{dim.icon}</div><h1 className="mt-4 text-4xl font-bold uppercase tracking-[0.18em]" style={{ color: dim.color }}>{dim.name}</h1><p className="mt-3 text-slate-300">Sous-grille fractale : chaque nœud peut devenir une grille complète.</p></header>
    <div className="mt-6 grid gap-4 md:grid-cols-2">{nodes.map((n) => <NodeCard key={n.id} node={n} />)}{!nodes.length && <p className="rounded-2xl border border-white/10 p-6 text-slate-400">Aucun nœud dans cette dimension pour le moment.</p>}</div>
  </div></main>;
}