import React, { useEffect, useState } from "react";
import { Loader2, Play, Pause } from "lucide-react";
import { base44 } from "@/api/base44Client";
import usePlumeVoice from "@/hooks/usePlumeVoice";
import { AMBIANCES, detectAmbiance } from "@/lib/plume/ambiances";
import DialFace, { ticksFromNodes } from "@/components/grille/DialFace";
import PlumeChat from "@/components/grille/constellation/PlumeChat";
import SiteHeader from "@/components/site/SiteHeader";
import Onboarding from "@/components/onboarding/Onboarding";
import CockpitBackstage from "@/components/grille/cockpit/CockpitBackstage";
import useProfil from "@/hooks/useProfil";

// Le cœur du concept : cadran vivant au centre + bloc conversationnel en bas.
// Le cadran affiche la progression du mariage ; le Play déclenche le récit du jour J,
// que PLUME raconte à voix haute — les graduations vibrent avec sa voix.
// Le visuel de fond suit l'ambiance de ce que PLUME dit.

export default function SouvenirDemo() {
  const { speak, stop, speaking, loading, level } = usePlumeVoice();
  const { profil, setProfil, loading: loadingProfil } = useProfil();
  const [nodes, setNodes] = useState([]);
  const [message, setMessage] = useState("");
  const [loadingMsg, setLoadingMsg] = useState(false);
  const [cockpit, setCockpit] = useState(false);

  const sourceId = new URLSearchParams(window.location.search).get("source");
  const ticks = ticksFromNodes(nodes);
  const estMarie = profil?.role === "futur_marie" || profil?.role === "future_mariee";

  useEffect(() => {
    const nodesPromise = sourceId
      ? base44.entities.NoeudMemoire.filter({ source_brute_id: sourceId }, "-created_date", 300)
      : base44.entities.NoeudMemoire.list("-created_date", 300);
    nodesPromise.then((all) => setNodes(all.filter((n) => n.etat_maturation !== "vide"))).catch(() => {});
  }, [sourceId]);

  // L'ambiance suit ce que PLUME raconte à voix haute.
  const ambianceKey = message && speaking ? detectAmbiance({ text: message, nodes }) : "accueil";
  const ambiance = AMBIANCES[ambianceKey] || AMBIANCES.accueil;

  // Play : PLUME dit à voix haute son message — le récit jour J pour les mariés,
  // son message d'accueil personnalisé pour les autres rôles (prestataires inclus).
  const handlePlay = async () => {
    if (speaking) return stop();
    let texte = message;
    if (!texte) {
      setLoadingMsg(true);
      try {
        const fn = estMarie ? "plumeRecit" : "plumeMessage";
        const res = await base44.functions.invoke(fn, sourceId ? { source_id: sourceId } : {});
        texte = res.data?.recit || res.data?.message || "";
        setMessage(texte);
      } finally {
        setLoadingMsg(false);
      }
    }
    if (texte) speak(texte);
  };

  const busy = loading || loadingMsg;

  // Écran de chargement du profil.
  if (loadingProfil) {
    return (
      <main className="flex h-screen w-full items-center justify-center bg-black">
        <Loader2 className="h-6 w-6 animate-spin text-white/40" />
      </main>
    );
  }

  // Tant que la personne n'a pas de profil complet : onboarding conversationnel en bas.
  if (!profil || !profil.profil_complet) {
    return (
      <main className="relative flex h-screen w-full flex-col overflow-hidden bg-black text-white">
        <img src={AMBIANCES.accueil.image} alt="" className="absolute inset-0 h-full w-full object-cover object-[center_25%]" />
        <div className={`absolute inset-0 bg-gradient-to-t ${AMBIANCES.accueil.tint}`} />
        <SiteHeader profil={profil} onCockpit={() => setCockpit(true)} />
        <div className="relative z-10 mt-auto w-full px-4 pb-6">
          <div className="mx-auto w-full max-w-lg">
            <Onboarding profil={profil} onDone={setProfil} />
          </div>
        </div>
        <CockpitBackstage open={cockpit} onClose={() => setCockpit(false)} />
      </main>
    );
  }

  return (
    <main className="relative flex h-screen w-full flex-col overflow-hidden bg-black text-white">
      {/* Visuel plein écran contextuel */}
      <img
        key={ambiance.image}
        src={ambiance.image}
        alt=""
        className="absolute inset-0 h-full w-full object-cover object-[center_25%] animate-[fadeIn_0.8s_ease]"
      />
      <div className={`absolute inset-0 bg-gradient-to-t ${ambiance.tint} transition-colors duration-700`} />

      <SiteHeader profil={profil} onCockpit={() => setCockpit(true)} />

      {/* Cadran vivant — TOUJOURS fixe au centre de l'écran, indépendant du contenu */}
      <div className="pointer-events-none absolute inset-x-0 top-1/2 z-10 flex -translate-y-[58%] justify-center px-4">
        <div className="pointer-events-auto">
          <DialFace analyzing={false} ticks={ticks} audioLevel={level} size={240}>
            <button
              onClick={handlePlay}
              disabled={busy}
              aria-label={speaking ? "Arrêter" : "Écouter PLUME"}
              className="flex h-20 w-20 items-center justify-center rounded-full bg-white/10 text-white ring-1 ring-white/20 backdrop-blur-md transition-all hover:bg-white/20 disabled:opacity-60"
            >
              {busy ? (
                <Loader2 className="h-7 w-7 animate-spin" />
              ) : speaking ? (
                <Pause className="h-7 w-7" />
              ) : (
                <Play className="ml-1 h-7 w-7" />
              )}
            </button>
          </DialFace>
        </div>
      </div>

      {/* LE bloc conversationnel — fixé en bas, toujours visible */}
      <div className="relative z-20 mt-auto w-full px-4 pb-6">
        <div className="mx-auto w-full max-w-lg">
          <PlumeChat sourceId={sourceId} role={profil?.role} onSpeak={(t) => (speaking ? stop() : speak(t))} />
        </div>
      </div>

      <CockpitBackstage open={cockpit} onClose={() => setCockpit(false)} />
    </main>
  );
}