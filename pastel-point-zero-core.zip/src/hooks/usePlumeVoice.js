import { useCallback, useEffect, useRef, useState } from "react";
import { base44 } from "@/api/base44Client";

// Voix de PLUME — vraie voix ElevenLabs via le backend (MP3), lecture dans un <audio>.
// Expose en plus un `level` (0→1) en temps réel : l'amplitude de la voix, pour animer le cadran.
export default function usePlumeVoice() {
  const [speaking, setSpeaking] = useState(false);
  const [loading, setLoading] = useState(false);
  const [level, setLevel] = useState(0);
  const audioRef = useRef(null);
  const ctxRef = useRef(null);
  const rafRef = useRef(null);

  const cleanupAnalyser = useCallback(() => {
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    rafRef.current = null;
    setLevel(0);
  }, []);

  const stop = useCallback(() => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current = null;
    }
    cleanupAnalyser();
    setSpeaking(false);
  }, [cleanupAnalyser]);

  useEffect(() => () => stop(), [stop]);

  const speak = useCallback(async (text) => {
    if (!text) return;
    stop();
    setLoading(true);
    try {
      const res = await base44.functions.invoke("plumeVoice", { text }, { responseType: "blob" });
      const blob = res.data instanceof Blob ? res.data : new Blob([res.data], { type: "audio/mpeg" });
      const url = URL.createObjectURL(blob);
      const audio = new Audio(url);
      audio.crossOrigin = "anonymous";
      audioRef.current = audio;

      // Web Audio : on mesure l'amplitude de la voix en temps réel pour piloter l'animation.
      try {
        const Ctx = window.AudioContext || window.webkitAudioContext;
        const ctx = ctxRef.current || new Ctx();
        ctxRef.current = ctx;
        if (ctx.state === "suspended") await ctx.resume();
        const sourceNode = ctx.createMediaElementSource(audio);
        const analyser = ctx.createAnalyser();
        analyser.fftSize = 256;
        sourceNode.connect(analyser);
        analyser.connect(ctx.destination);
        const data = new Uint8Array(analyser.frequencyBinCount);
        const tick = () => {
          analyser.getByteFrequencyData(data);
          let sum = 0;
          for (let i = 0; i < data.length; i++) sum += data[i];
          const avg = sum / data.length / 255; // 0→1
          setLevel(Math.min(1, avg * 2.2)); // léger boost pour un rendu vivant
          rafRef.current = requestAnimationFrame(tick);
        };
        tick();
      } catch (_e) {
        // Si l'analyse audio échoue, la voix joue quand même (sans visualiseur).
      }

      audio.onended = () => { setSpeaking(false); cleanupAnalyser(); URL.revokeObjectURL(url); };
      audio.onerror = () => { setSpeaking(false); cleanupAnalyser(); URL.revokeObjectURL(url); };
      await audio.play();
      setSpeaking(true);
    } finally {
      setLoading(false);
    }
  }, [stop, cleanupAnalyser]);

  return { speak, stop, speaking, loading, level, supported: true };
}