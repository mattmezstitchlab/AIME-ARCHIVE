import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";

// Charge le profil Point Zéro de la personne connectée (mémoire persistante).
// La RLS limite déjà chaque personne à ses propres fiches → on prend la plus récente.
export default function useProfil() {
  const [profil, setProfil] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    base44.entities.Profil.list("-created_date", 1)
      .then((mine) => setProfil(mine?.[0] || null))
      .catch(() => setProfil(null))
      .finally(() => setLoading(false));
  }, []);

  return { profil, setProfil, loading };
}