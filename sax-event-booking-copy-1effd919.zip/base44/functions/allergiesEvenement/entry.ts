import { createClientFromRequest } from 'npm:@base44/sdk@0.8.38';

// Accès public au registre alimentaire d'un événement : les invités déclarent
// leurs allergies et régimes sans compte ; tout remonte au Studio et au traiteur.
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { evenementId, action, nom, allergenes, regime, commentaire } = await req.json();

    if (!evenementId) {
      return Response.json({ error: "evenementId manquant" }, { status: 400 });
    }

    const evenement = await base44.asServiceRole.entities.Evenement.get(evenementId).catch(() => null);
    if (!evenement) {
      return Response.json({ error: "Événement introuvable" }, { status: 404 });
    }

    if (action === "info") {
      return Response.json({
        titre: evenement.titre,
        date: evenement.date,
        typeEvenement: evenement.typeEvenement || "",
      });
    }

    if (action === "ajouter") {
      const nomPropre = String(nom || "").trim().slice(0, 80);
      if (!nomPropre) {
        return Response.json({ error: "Le nom est requis" }, { status: 400 });
      }
      const listeAllergenes = (Array.isArray(allergenes) ? allergenes : [])
        .map((a) => String(a).trim().slice(0, 40))
        .filter(Boolean)
        .slice(0, 20);
      const cree = await base44.asServiceRole.entities.RegimeInvite.create({
        proprietaire: evenement.proprietaire,
        evenementId,
        nom: nomPropre,
        allergenes: listeAllergenes,
        regime: String(regime || "").trim().slice(0, 60),
        commentaire: String(commentaire || "").trim().slice(0, 500),
      });
      return Response.json({ ok: true, id: cree.id });
    }

    return Response.json({ error: "Action inconnue" }, { status: 400 });
  } catch (error) {
    console.error("allergiesEvenement:", error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});