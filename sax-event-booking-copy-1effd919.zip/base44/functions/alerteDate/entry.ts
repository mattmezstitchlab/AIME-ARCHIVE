import { createClientFromRequest } from 'npm:@base44/sdk@0.8.38';

// Un visiteur demande à être prévenu par e-mail si une date réservée se libère.
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const sr = base44.asServiceRole;
    let data = {};
    try { data = await req.json(); } catch (_e) { data = {}; }

    let proprietaire = String(data.proprietaire || '').trim().toLowerCase();
    if (proprietaire && !proprietaire.includes('@')) {
      const parSlug = await sr.entities.ProfilPrestataire.filter({ slug: proprietaire }, '-updated_date', 1);
      proprietaire = String(parSlug[0]?.proprietaire || '').toLowerCase();
    }
    const date = String(data.date || '').trim();
    const email = String(data.email || '').trim().toLowerCase();

    if (!proprietaire || !/^\d{4}-\d{2}-\d{2}$/.test(date) || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return Response.json({ error: 'Informations invalides.' }, { status: 400 });
    }

    const existantes = await sr.entities.AlerteDate.filter({ proprietaire, date, email }, '-created_date', 1);
    if (!existantes[0]) {
      await sr.entities.AlerteDate.create({ proprietaire, date, email });
    }

    return Response.json({ ok: true });
  } catch (error) {
    console.error('alerteDate:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});