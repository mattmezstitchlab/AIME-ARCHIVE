import { createClientFromRequest } from 'npm:@base44/sdk@0.8.38';

// Estime le temps de trajet en voiture entre deux villes, pour le calendrier public.
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    let data = {};
    try { data = await req.json(); } catch (_e) { data = {}; }
    const depart = String(data.depart || '').trim().slice(0, 120);
    const arrivee = String(data.arrivee || '').trim().slice(0, 120);
    if (!depart || !arrivee) {
      return Response.json({ error: 'Villes de départ et d\'arrivée requises.' }, { status: 400 });
    }

    const res = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt: `Estime le trajet en voiture entre "${depart}" et "${arrivee}" (France, conditions normales de circulation). Donne le temps de route en minutes et la distance en kilomètres. Sois réaliste.`,
      add_context_from_internet: true,
      response_json_schema: {
        type: 'object',
        properties: {
          minutes: { type: 'integer', description: 'Temps de route estimé en minutes' },
          distanceKm: { type: 'number', description: 'Distance routière en kilomètres' },
        },
        required: ['minutes'],
      },
    });

    return Response.json({ minutes: res.minutes, distanceKm: res.distanceKm ?? null, depart, arrivee });
  } catch (error) {
    console.error('tempsRoute:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});