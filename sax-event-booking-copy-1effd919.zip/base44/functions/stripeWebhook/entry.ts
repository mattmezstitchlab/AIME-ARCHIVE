import { createClientFromRequest } from 'npm:@base44/sdk@0.8.38';
import Stripe from 'npm:stripe@17';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY'));
    const signature = req.headers.get('stripe-signature');
    const body = await req.text();

    let event;
    try {
      event = await stripe.webhooks.constructEventAsync(
        body,
        signature,
        Deno.env.get('STRIPE_WEBHOOK_SECRET')
      );
    } catch (err) {
      console.error('Signature webhook invalide:', err.message);
      return Response.json({ error: 'Signature invalide' }, { status: 400 });
    }

    if (event.type === 'checkout.session.completed') {
      const session = event.data.object;
      const documentId = session.metadata?.document_id;
      if (documentId) {
        await base44.asServiceRole.entities.DocumentEmis.update(documentId, { statut: 'paye' });
        console.log(`Document ${documentId} marqué payé.`);
      }
    }

    return Response.json({ received: true });
  } catch (error) {
    console.error('stripeWebhook:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});