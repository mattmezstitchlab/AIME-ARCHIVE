import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

// Le fil « Autour de moi » : on croise le besoin exprimé, le registre,
// la ressourcerie (objets prêtés ou loués entre voisins),
// les disponibilités de l'instant et la proximité géographique.
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const sr = base44.asServiceRole;
    let data = {};
    try { data = await req.json(); } catch (_e) { data = {}; }

    const besoin = String(data.besoin || '').trim();
    const ville = String(data.ville || '').trim();
    if (!besoin || !ville) {
      return Response.json({ error: 'Décrivez votre besoin et indiquez votre ville.' }, { status: 400 });
    }

    const [profils, dispos, ressourcesBrutes] = await Promise.all([
      sr.entities.ProfilPrestataire.list('created_date', 200),
      sr.entities.DisponibiliteInstant.list('-created_date', 200),
      sr.entities.RessourceLocale.filter({ disponible: true }, '-created_date', 500),
    ]);

    const maintenant = new Date();
    const disponiblesMaintenant = new Set(
      dispos.filter((d) => d.jusqua && new Date(d.jusqua) > maintenant).map((d) => d.proprietaire)
    );
    const profilParEmail = Object.fromEntries(profils.map((p) => [p.proprietaire, p]));

    const candidats = profils
      .filter((p) => p.slug && p.nomAffiche)
      .map((p) => ({
        slug: p.slug,
        nom: p.nomAffiche,
        metier: p.sousTitre || p.typeProfil || '',
        accroche: p.accroche || '',
        ville: p.ville || '',
        rayonKm: p.rayonAction || 25,
        disponibleMaintenant: disponiblesMaintenant.has(p.proprietaire),
      }));

    const ressources = ressourcesBrutes.map((r) => {
      const p = profilParEmail[r.proprietaire];
      return {
        id: r.id,
        titre: r.titre,
        description: r.description || '',
        categorie: r.categorie || 'autre',
        modalite: r.modalite || 'gratuit',
        prix: r.prix || '',
        ville: p?.ville || '',
      };
    });

    if (candidats.length === 0 && ressources.length === 0) {
      return Response.json({ message: "Le registre est encore vide par ici — revenez bientôt, les voisins arrivent.", resultats: [] });
    }

    const reponse = await base44.integrations.Core.InvokeLLM({
      prompt: `Tu es Aime, l'assistante d'une plateforme de mise en relation locale fondée sur la proximité et l'entraide : on fait avec ce qu'on a sur son chemin — les voisins ET leurs objets — plutôt que d'acheter loin ou de rouler des heures.

Besoin exprimé par un visiteur : "${besoin}"
Ville du visiteur : "${ville}"

Registre des profils (JSON) : ${JSON.stringify(candidats)}

Ressourcerie des voisins — objets, matériel, déco, espaces à prêter (gratuit) ou louer (payant) (JSON) : ${JSON.stringify(ressources)}

Sélectionne au maximum 4 résultats pertinents pour ce besoin, mélange possible de profils (personnes) et de ressources (objets), classés du plus pertinent/proche au moins :
1. Si le besoin porte sur un objet, du matériel, de la déco ou un espace (ex. "il me faut une arche", "mon enceinte a lâché"), privilégie les ressources correspondantes ; ajoute un profil pertinent en complément si utile.
2. Si le besoin porte sur une prestation humaine, privilégie les profils (sois souple : une "coiffeuse" répond à "me faire couper les cheveux").
3. Tiens compte de la proximité entre villes (estime la distance routière en km entre villes françaises) et du rayonKm des profils : écarte ceux clairement hors rayon.
4. disponibleMaintenant est un atout majeur, mets-le en avant.
5. Pour les ressources gratuites, souligne l'économie réalisée (pas d'achat, pas de location lointaine).

Rédige aussi un "message" global chaleureux d'une ou deux phrases, dans l'esprit "Bonne nouvelle : votre voisine…". Si rien ne correspond, renvoie resultats vide et un message bienveillant.

Pour chaque résultat : type ("profil" ou "ressource"), slug (exactement celui du registre, si type profil), ressourceId (exactement l'id de la ressourcerie, si type ressource), raison (une phrase expliquant pourquoi c'est la bonne rencontre, mentionnant proximité et économie le cas échéant), distanceKm (estimation entière).`,
      response_json_schema: {
        type: 'object',
        properties: {
          message: { type: 'string' },
          resultats: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                type: { type: 'string', enum: ['profil', 'ressource'] },
                slug: { type: 'string' },
                ressourceId: { type: 'string' },
                raison: { type: 'string' },
                distanceKm: { type: 'integer' },
              },
            },
          },
        },
      },
    });

    const parSlug = Object.fromEntries(profils.map((p) => [p.slug, p]));
    const parId = Object.fromEntries(ressourcesBrutes.map((r) => [r.id, r]));

    const resultats = (reponse.resultats || [])
      .map((r) => {
        if (r.type === 'ressource' && parId[r.ressourceId]) {
          const res = parId[r.ressourceId];
          const p = profilParEmail[res.proprietaire];
          return {
            type: 'ressource',
            titre: res.titre,
            photoUrl: res.photoUrl || '',
            modalite: res.modalite || 'gratuit',
            prix: res.prix || '',
            proprietaireNom: p?.nomAffiche || '',
            slug: p?.slug || '',
            ville: p?.ville || '',
            raison: r.raison || '',
            distanceKm: r.distanceKm ?? null,
          };
        }
        if (r.type === 'profil' && parSlug[r.slug]) {
          const p = parSlug[r.slug];
          return {
            type: 'profil',
            slug: p.slug,
            nomAffiche: p.nomAffiche,
            sousTitre: p.sousTitre || '',
            ville: p.ville || '',
            photoProfilUrl: p.photoProfilUrl || '',
            disponibleMaintenant: disponiblesMaintenant.has(p.proprietaire),
            raison: r.raison || '',
            distanceKm: r.distanceKm ?? null,
          };
        }
        return null;
      })
      .filter(Boolean)
      .slice(0, 4);

    return Response.json({ message: reponse.message || '', resultats });
  } catch (error) {
    console.error('autourDeMoi:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});