import { createClientFromRequest } from 'npm:@base44/sdk@0.8.38';

// Accès public à la playlist d'un événement : infos + propositions des invités (sans compte).
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { evenementId, action, nomInvite, morceaux } = await req.json();

    if (!evenementId) {
      return Response.json({ error: "evenementId manquant" }, { status: 400 });
    }

    const evenement = await base44.asServiceRole.entities.Evenement.get(evenementId).catch(() => null);
    if (!evenement) {
      return Response.json({ error: "Événement introuvable" }, { status: 404 });
    }

    if (action === "info") {
      return Response.json({
        titre: evenement.titre,
        date: evenement.date,
        typeEvenement: evenement.typeEvenement || "",
      });
    }

    if (action === "ajouter") {
      const liste = Array.isArray(morceaux) ? morceaux.filter((m) => m && String(m.titre || "").trim()) : [];
      if (liste.length === 0) {
        return Response.json({ error: "Aucun morceau valide" }, { status: 400 });
      }
      if (liste.length > 20) {
        return Response.json({ error: "20 morceaux maximum par envoi" }, { status: 400 });
      }
      const crees = await base44.asServiceRole.entities.PlaylistMorceau.bulkCreate(
        liste.map((m) => ({
          proprietaire: evenement.proprietaire,
          evenementId,
          titre: String(m.titre).trim().slice(0, 120),
          artiste: String(m.artiste || "").trim().slice(0, 120),
          style: String(m.style || "").trim().slice(0, 60),
          source: "invite",
          ajoutePar: String(nomInvite || "").trim().slice(0, 60),
        }))
      );
      return Response.json({ ok: true, nombre: crees.length });
    }

    return Response.json({ error: "Action inconnue" }, { status: 400 });
  } catch (error) {
    console.error("playlistPublique:", error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});