import { createClientFromRequest } from 'npm:@base44/sdk@0.8.38';

// Enregistrement des documents en deux temps :
// 1. action "creer"     : le serveur attribue un numéro unique (basé sur le max existant,
//                          avec réconciliation anti-collision) et crée l'enregistrement.
// 2. action "joindrePdf" : le client génère le PDF avec le numéro attribué puis le dépose
//                          en stockage privé, rattaché à l'enregistrement.
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Vous devez être connecté pour émettre un document.' }, { status: 401 });
    }
    const sr = base44.asServiceRole;
    const proprietaire = String(user.email || '').toLowerCase();
    const payload = await req.json();

    if (payload.action === 'creer') {
      const document = payload.document || {};
      if (!document.type || !document.clientNom || typeof document.montant !== 'number') {
        return Response.json({ error: 'Données du document incomplètes.' }, { status: 400 });
      }
      // Le numéro ne peut jamais être imposé par le client
      delete document.numero;
      delete document.proprietaire;
      delete document.fichierUrl;

      const prefixe = /^[A-Z]{2,8}$/.test(String(payload.prefixe || '')) ? payload.prefixe : 'DOC';
      const annee = new Date().getFullYear();
      const dateEmission = document.dateEmission || new Date().toISOString().slice(0, 10);

      // Séquence basée sur le numéro maximal existant (robuste aux suppressions)
      const existants = await sr.entities.DocumentEmis.filter({ type: document.type, proprietaire }, '-created_date', 500);
      const re = new RegExp(`-${annee}-(\\d+)$`);
      let seq = existants.reduce((max, d) => {
        const m = String(d.numero || '').match(re);
        return m ? Math.max(max, parseInt(m[1], 10)) : max;
      }, 0) + 1;
      let numero = `${prefixe}-${annee}-${String(seq).padStart(3, '0')}`;

      const cree = await sr.entities.DocumentEmis.create({ ...document, numero, dateEmission, proprietaire });

      // Réconciliation anti-collision : en cas de création simultanée, le plus ancien
      // conserve le numéro, le plus récent est renuméroté.
      for (let i = 0; i < 5; i++) {
        const memes = await sr.entities.DocumentEmis.filter({ numero, proprietaire, type: document.type }, 'created_date', 10);
        if (memes.length <= 1 || memes[0].id === cree.id) break;
        seq += 1;
        numero = `${prefixe}-${annee}-${String(seq).padStart(3, '0')}`;
        await sr.entities.DocumentEmis.update(cree.id, { numero });
      }

      return Response.json({ success: true, id: cree.id, numero, dateEmission });
    }

    if (payload.action === 'joindrePdf') {
      const { id, pdfBase64, nomFichier } = payload;
      if (!id || !pdfBase64 || !nomFichier) {
        return Response.json({ error: 'Données manquantes.' }, { status: 400 });
      }
      const doc = await sr.entities.DocumentEmis.get(id);
      if (!doc || (doc.proprietaire !== proprietaire && user.role !== 'admin')) {
        return Response.json({ error: 'Document introuvable ou accès refusé.' }, { status: 403 });
      }
      const octets = Uint8Array.from(atob(pdfBase64), (c) => c.charCodeAt(0));
      const fichier = new File([octets], nomFichier, { type: 'application/pdf' });
      // Stockage privé : fichierUrl contient un file_uri, converti en lien signé au téléchargement.
      const { file_uri } = await sr.integrations.Core.UploadPrivateFile({ file: fichier });
      await sr.entities.DocumentEmis.update(id, { fichierUrl: file_uri });
      return Response.json({ success: true, id, fichierUrl: file_uri });
    }

    return Response.json({ error: 'Action inconnue.' }, { status: 400 });
  } catch (error) {
    console.error('Erreur enregistrerDocument:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});