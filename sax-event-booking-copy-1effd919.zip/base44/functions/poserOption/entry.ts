import { createClientFromRequest } from 'npm:@base44/sdk@0.8.38';

// Un visiteur pose une option gratuite de 48 h sur une date libre du calendrier public.
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const sr = base44.asServiceRole;
    let data = {};
    try { data = await req.json(); } catch (_e) { data = {}; }

    let proprietaire = String(data.proprietaire || '').trim().toLowerCase();
    if (proprietaire && !proprietaire.includes('@')) {
      const parSlug = await sr.entities.ProfilPrestataire.filter({ slug: proprietaire }, '-updated_date', 1);
      proprietaire = String(parSlug[0]?.proprietaire || '').toLowerCase();
    }
    const date = String(data.date || '').trim();
    const nom = String(data.nom || '').trim().slice(0, 120);
    const email = String(data.email || '').trim().toLowerCase();
    const telephone = String(data.telephone || '').trim().slice(0, 30);

    if (!proprietaire || !/^\d{4}-\d{2}-\d{2}$/.test(date) || !nom || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return Response.json({ error: 'Informations invalides.' }, { status: 400 });
    }

    const maintenant = new Date();
    const existantes = await sr.entities.OptionDate.filter({ proprietaire, date, email }, '-created_date', 1);
    if (existantes[0] && new Date(existantes[0].expireLe) > maintenant) {
      return Response.json({ error: 'Vous avez déjà une option active sur cette date.' }, { status: 409 });
    }

    const expireLe = new Date(maintenant.getTime() + 48 * 3600 * 1000).toISOString();
    await sr.entities.OptionDate.create({ proprietaire, date, nom, email, telephone, expireLe });

    const profils = await sr.entities.ProfilPrestataire.filter({ proprietaire }, '-updated_date', 1);
    const dest = profils[0]?.emailNotification || proprietaire;
    const dateFr = new Date(`${date}T12:00:00`).toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
    try {
      await sr.integrations.Core.SendEmail({
        to: dest,
        subject: `Option 48 h posée sur le ${dateFr}`,
      body: `${nom} (${email}${telephone ? ', ' + telephone : ''}) vient de poser une option de 48 heures sur le ${dateFr}.\n\nCette option expire le ${new Date(expireLe).toLocaleString('fr-FR', { timeZone: 'Europe/Paris' })}. Retrouvez-la dans le calendrier de votre compte Aime Event.`,
      });
    } catch (e) {
      // L'option est enregistrée : l'échec d'e-mail ne doit pas bloquer le visiteur.
      console.error('poserOption e-mail:', e.message);
    }

    return Response.json({ ok: true, expireLe });
  } catch (error) {
    console.error('poserOption:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});