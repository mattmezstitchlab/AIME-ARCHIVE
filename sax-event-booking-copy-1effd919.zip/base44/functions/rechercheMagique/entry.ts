import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

// L'agent de recherche du hero : il raisonne, pose une question si la recherche
// manque de précision (ville…), puis livre les sources de vérité en cartes.
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    let data = {};
    try { data = await req.json(); } catch (_e) { data = {}; }

    const messages = Array.isArray(data.messages) ? data.messages : [];
    if (messages.length === 0) {
      return Response.json({ error: 'Écrivez votre recherche.' }, { status: 400 });
    }

    const dialogue = messages
      .map((m) => `${m.role === 'user' ? 'Visiteur' : 'Agent'} : ${String(m.content || '')}`)
      .join('\n');

    const nbQuestionsAgent = messages.filter((m) => m.role !== 'user').length;

    const reponse = await base44.integrations.Core.InvokeLLM({
      prompt: `Tu es l'agent de recherche intelligent d'Aime Event, une plateforme événementielle française. Tu raisonnes sur ce que cherche vraiment le visiteur avant de répondre.

Dialogue en cours :
${dialogue}

Ta mission :
1. Si une information ESSENTIELLE manque pour bien chercher (surtout la ville ou la zone géographique quand la recherche vise des prestataires, lieux ou services), pose UNE seule question courte et chaleureuse dans le champ "question" et laisse "resultats" vide. ${nbQuestionsAgent >= 2 ? 'Tu as déjà posé assez de questions : ne pose plus de question, réponds avec tes meilleures hypothèses.' : 'Ne pose jamais plus de 2 questions au total dans un dialogue.'}
2. Sinon, cherche sur le web les sources de vérité UNIQUES et fiables (sites officiels, établissements réels, références reconnues — jamais d'agrégateurs) et renvoie entre 3 et 6 résultats dans "resultats", chacun avec :
- titre : court et net
- sousTitre : une ligne qui situe (métier, lieu, spécialité)
- description : 2 à 3 phrases propres et denses
- categorie : catégorie du registre au singulier, avec majuscule, courte et réutilisable (ex. "Coiffeur", "Traiteur", "Lieu de réception", "Fleuriste", "Photographe")
- sourceUrl : l'URL de la source de vérité (site officiel de préférence)
- imageUrl : une URL DIRECTE d'image réelle trouvée sur le web illustrant précisément ce résultat (fichier .jpg, .png ou .webp accessible publiquement), sinon chaîne vide — n'invente jamais d'URL
- ville : la ville concernée si identifiable, sinon chaîne vide
- estPrestataire : true s'il s'agit d'un prestataire, artisan, artiste, lieu ou établissement qui pourrait revendiquer sa fiche sur la plateforme, false s'il s'agit d'une information générale

Tous les textes en français.`,
      add_context_from_internet: true,
      response_json_schema: {
        type: 'object',
        properties: {
          question: { type: 'string' },
          resultats: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                titre: { type: 'string' },
                sousTitre: { type: 'string' },
                description: { type: 'string' },
                categorie: { type: 'string' },
                sourceUrl: { type: 'string' },
                imageUrl: { type: 'string' },
                ville: { type: 'string' },
                estPrestataire: { type: 'boolean' },
              },
            },
          },
        },
      },
    });

    const resultats = (reponse.resultats || []).slice(0, 6);
    const question = resultats.length === 0 ? String(reponse.question || '').trim() : '';
    return Response.json({ question, resultats });
  } catch (error) {
    console.error('rechercheMagique:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});