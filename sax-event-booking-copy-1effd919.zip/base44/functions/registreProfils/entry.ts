import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const profils = await base44.asServiceRole.entities.ProfilPrestataire.list('created_date', 200);
    return Response.json({
      profils: profils
        .filter((p) => p.slug)
        .map((p) => ({
          slug: p.slug,
          typeProfil: p.typeProfil || "Prestataire",
          nomAffiche: p.nomAffiche,
          sousTitre: p.sousTitre,
          accroche: p.accroche,
          photoProfilUrl: p.photoProfilUrl,
          couvertureUrl: p.couvertureUrl,
        })),
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});