import { createClientFromRequest } from 'npm:@base44/sdk@0.8.38';

// Quand le prestataire libère une date, on prévient les visiteurs qui avaient posé une alerte.
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    let data = {};
    try { data = await req.json(); } catch (_e) { data = {}; }
    const date = String(data.date || '').trim();
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
      return Response.json({ error: 'Date invalide.' }, { status: 400 });
    }

    const sr = base44.asServiceRole;
    const proprietaire = (user.email || '').toLowerCase();
    const alertes = await sr.entities.AlerteDate.filter({ proprietaire, date }, '-created_date', 100);
    if (alertes.length === 0) return Response.json({ notifies: 0 });

    const profils = await sr.entities.ProfilPrestataire.filter({ proprietaire }, '-updated_date', 1);
    const nomAffiche = profils[0]?.nomAffiche || 'votre prestataire';
    const slug = profils[0]?.slug || '';
    const origine = req.headers.get('origin') || '';
    const lien = slug && origine ? `\n\nRéservez vite : ${origine}/p/${slug}` : '';
    const dateFr = new Date(`${date}T12:00:00`).toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });

    let notifies = 0;
    for (const alerte of alertes) {
      try {
        await sr.integrations.Core.SendEmail({
          to: alerte.email,
          subject: `Bonne nouvelle : le ${dateFr} vient de se libérer`,
          body: `Vous aviez demandé à être prévenu(e) : la date du ${dateFr} vient de se libérer chez ${nomAffiche}.${lien}`,
          from_name: nomAffiche,
        });
        await sr.entities.AlerteDate.delete(alerte.id);
        notifies++;
      } catch (e) {
        console.error('notifierDateLiberee e-mail:', e.message);
      }
    }

    return Response.json({ notifies });
  } catch (error) {
    console.error('notifierDateLiberee:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});