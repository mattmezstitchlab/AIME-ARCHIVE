import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const sr = base44.asServiceRole;
    const data = await req.json();

    // Profil concerné par les avis
    let profil = null;
    if (data.proprietaire) {
      // Slug de profil (front public) ou e-mail (compatibilité).
      const cle = String(data.proprietaire).trim().toLowerCase();
      const trouves = cle.includes('@')
        ? await sr.entities.ProfilPrestataire.filter({ proprietaire: cle }, '-updated_date', 1)
        : await sr.entities.ProfilPrestataire.filter({ slug: cle }, '-updated_date', 1);
      profil = trouves[0] || null;
    }
    if (!profil) {
      const premiers = await sr.entities.ProfilPrestataire.list('created_date', 1);
      profil = premiers[0] || null;
    }
    const proprietaire = profil?.proprietaire || null;

    if (data.action === 'lister') {
      const filtre = { approuve: true, ...(proprietaire ? { proprietaire } : {}) };
      const liste = await sr.entities.Temoignage.filter(filtre, '-created_date', 50);
      return Response.json({
        temoignages: liste.map((t) => ({
          id: t.id,
          nom: t.nom,
          typeEvenement: t.typeEvenement,
          note: t.note,
          message: t.message,
          created_date: t.created_date,
        })),
      });
    }

    if (data.action === 'envoyer') {
      // Honeypot anti-bot
      if (data.siteWeb) return Response.json({ success: true });

      const nom = String(data.nom || '').trim().slice(0, 80);
      const message = String(data.message || '').trim().slice(0, 800);
      const note = Number(data.note);
      const typeEvenement = String(data.typeEvenement || '').trim().slice(0, 60);

      if (!nom || !message) {
        return Response.json({ error: 'Le nom et le message sont obligatoires.' }, { status: 400 });
      }
      if (!Number.isInteger(note) || note < 1 || note > 5) {
        return Response.json({ error: 'La note doit être comprise entre 1 et 5.' }, { status: 400 });
      }
      if (!proprietaire) {
        return Response.json({ error: 'Profil concerné introuvable.' }, { status: 400 });
      }

      await sr.entities.Temoignage.create({ nom, message, note, typeEvenement, proprietaire });

      // Notification au propriétaire du profil pour modération
      try {
        await sr.integrations.Core.SendEmail({
          to: profil.emailNotification || proprietaire,
          subject: `Nouvel avis à modérer – ${nom} (${note}/5)`,
          body: `Un nouvel avis attend votre validation dans votre espace compte (onglet Avis).

Nom : ${nom}
Note : ${note}/5
Événement : ${typeEvenement || 'Non précisé'}

Message :
${message}`,
          from_name: 'Aime Event'
        });
      } catch (e) {
        console.error('Erreur notification avis:', e.message);
      }

      return Response.json({ success: true });
    }

    return Response.json({ error: 'Action inconnue.' }, { status: 400 });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});