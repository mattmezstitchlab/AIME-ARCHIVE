import { createClientFromRequest } from 'npm:@base44/sdk@0.8.38';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const sr = base44.asServiceRole;
    const data = await req.json();

    // Honeypot anti-bot : si le champ caché est rempli, on répond OK sans rien faire
    if (data.siteWeb) {
      return Response.json({ success: true });
    }

    const requis = ['nom', 'prenom', 'telephone', 'email', 'adresseEvenement', 'typeEvenement', 'dateEvenement', 'heureDebut', 'heureFin'];
    for (const champ of requis) {
      if (!data[champ] || String(data[champ]).trim() === '') {
        return Response.json({ error: `Champ obligatoire manquant : ${champ}` }, { status: 400 });
      }
    }
    if (data.consentement !== true) {
      return Response.json({ error: 'Le consentement est obligatoire.' }, { status: 400 });
    }

    // Normalisation et validation de l'e-mail côté serveur
    const emailClient = String(data.email).trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailClient)) {
      return Response.json({ error: 'Adresse e-mail invalide.' }, { status: 400 });
    }

    // Validation des heures (format HH:MM et cohérence)
    if (!/^\d{2}:\d{2}$/.test(String(data.heureDebut)) || !/^\d{2}:\d{2}$/.test(String(data.heureFin))) {
      return Response.json({ error: 'Horaires invalides.' }, { status: 400 });
    }
    if (data.heureFin <= data.heureDebut) {
      return Response.json({ error: "L'heure de fin doit être postérieure à l'heure de début." }, { status: 400 });
    }

    // Date passée refusée (fuseau Europe/Paris)
    const aujourdHuiParis = new Date().toLocaleDateString('fr-CA', { timeZone: 'Europe/Paris' });
    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(data.dateEvenement)) || String(data.dateEvenement) < aujourdHuiParis) {
      return Response.json({ error: "La date de l'événement ne peut pas être dans le passé." }, { status: 400 });
    }

    const infos = (data.informationsComplementaires || '').slice(0, 1000);

    // Limite anti-abus : 3 demandes maximum par e-mail (normalisé) et par jour
    const aujourdHui = new Date().toISOString().slice(0, 10);
    const recentes = await sr.entities.DemandesDisponibilite.filter({ email: emailClient }, '-created_date', 10);
    const duJour = recentes.filter((d) => String(d.dateCreation || d.created_date || '').slice(0, 10) === aujourdHui);
    if (duJour.length >= 3) {
      return Response.json({ error: "Vous avez atteint la limite de demandes pour aujourd'hui. Merci de réessayer demain." }, { status: 429 });
    }

    // Profil destinataire de la demande
    let profil = null;
    if (data.proprietaire) {
      // Le front public transmet le slug du profil (jamais l'e-mail) ; l'e-mail reste accepté pour compatibilité.
      const cle = String(data.proprietaire).trim().toLowerCase();
      const trouves = cle.includes('@')
        ? await sr.entities.ProfilPrestataire.filter({ proprietaire: cle }, '-updated_date', 1)
        : await sr.entities.ProfilPrestataire.filter({ slug: cle }, '-updated_date', 1);
      profil = trouves[0] || null;
    }
    if (!profil || !profil.proprietaire) {
      return Response.json({ error: 'Destinataire de la demande introuvable.' }, { status: 400 });
    }
    const proprietaire = profil.proprietaire;
    const emailNotification = profil.emailNotification || proprietaire;
    const nomPrestataire = profil.nomAffiche || 'Aime Event';

    // Doublon : une demande encore ouverte du même e-mail, pour la même date et le même prestataire.
    const semblables = await sr.entities.DemandesDisponibilite.filter({ proprietaire, email: emailClient, dateEvenement: data.dateEvenement }, '-created_date', 5);
    const dejaOuverte = semblables.find((d) => d.statut !== 'Archivée');
    if (dejaOuverte) {
      return Response.json({ error: `Vous avez déjà une demande en cours pour cette date${dejaOuverte.reference ? ` (référence ${dejaOuverte.reference})` : ''}.` }, { status: 409 });
    }

    const maintenant = new Date();
    const dateEnvoiFr = maintenant.toLocaleString('fr-FR', { timeZone: 'Europe/Paris', dateStyle: 'long', timeStyle: 'short' });
    const [annee, mois, jour] = String(data.dateEvenement).split('-');
    const dateEvenementFr = `${jour}/${mois}/${annee}`;

    // Référence unique, lisible et non prédictible, attribuée côté serveur
    const reference = 'DEM-' + crypto.randomUUID().replace(/-/g, '').slice(0, 8).toUpperCase();

    // Enregistrement en base (même si l'e-mail échoue ensuite)
    let demandeCreee = null;
    try {
      demandeCreee = await sr.entities.DemandesDisponibilite.create({
        proprietaire,
        reference,
        nom: data.nom,
        prenom: data.prenom,
        telephone: data.telephone,
        email: emailClient,
        adresseEvenement: data.adresseEvenement,
        typeEvenement: data.typeEvenement,
        dateEvenement: data.dateEvenement,
        heureDebut: data.heureDebut,
        heureFin: data.heureFin,
        informationsComplementaires: infos,
        consentement: true,
        statut: 'Nouvelle demande',
        dateCreation: maintenant.toISOString()
      });
    } catch (e) {
      console.error('Erreur enregistrement demande:', e.message);
      demandeCreee = null;
    }

    const corps = `Nouvelle demande de disponibilité

Référence : ${reference}

Nom : ${data.nom}
Prénom : ${data.prenom}
Téléphone : ${data.telephone}
E-mail : ${emailClient}
Type d'événement : ${data.typeEvenement}
Date de l'événement : ${dateEvenementFr}
Horaires : de ${data.heureDebut} à ${data.heureFin}
Adresse : ${data.adresseEvenement}

Informations complémentaires :
${infos || 'Aucune'}

Date d'envoi de la demande :
${dateEnvoiFr}`;

    let emailEnvoye = true;
    try {
      await sr.integrations.Core.SendEmail({
        to: emailNotification,
        subject: `Nouvelle demande [${reference}] – ${data.prenom} ${data.nom} – ${dateEvenementFr}`,
        body: corps,
        from_name: 'Demande de disponibilité'
      });
    } catch (e) {
      // La demande est enregistrée en base : on n'affiche pas d'erreur au client.
      console.error('Erreur envoi e-mail notification:', e.message);
      emailEnvoye = false;
    }

    // Accusé de réception envoyé au client
    try {
      await sr.integrations.Core.SendEmail({
        to: emailClient,
        subject: `Votre demande de disponibilité du ${dateEvenementFr} a bien été reçue`,
        body: `Bonjour ${data.prenom},

Votre demande de disponibilité a bien été reçue. En voici le récapitulatif :

Référence de votre demande : ${reference}

Type d'événement : ${data.typeEvenement}
Date : ${dateEvenementFr}
Horaires : de ${data.heureDebut} à ${data.heureFin}
Adresse : ${data.adresseEvenement}

Conservez cette référence pour tout échange à venir. Je reviens vers vous très rapidement pour vous confirmer ma disponibilité.

Musicalement,
${nomPrestataire}`,
        from_name: nomPrestataire
      });
    } catch (e) {
      console.error('Erreur accusé de réception client:', e.message);
    }

    // Journal technique d'envoi consultable par l'administrateur
    if (demandeCreee) {
      try {
        await sr.entities.DemandesDisponibilite.update(demandeCreee.id, { emailNotifie: emailEnvoye });
      } catch (e) {
        console.error('Erreur mise à jour statut envoi:', e.message);
      }
    }

    if (!demandeCreee && !emailEnvoye) {
      return Response.json({ error: "La demande n'a pas pu être traitée." }, { status: 500 });
    }

    return Response.json({ success: true, reference, enregistree: !!demandeCreee, emailEnvoye });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});