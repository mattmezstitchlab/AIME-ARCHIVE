import { createClientFromRequest } from 'npm:@base44/sdk@0.8.38';
import Stripe from 'npm:stripe@17';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { documentId, urlRetour } = await req.json();
    if (!documentId) return Response.json({ error: 'documentId requis' }, { status: 400 });

    const doc = await base44.asServiceRole.entities.DocumentEmis.get(documentId);
    if (!doc) return Response.json({ error: 'Document introuvable' }, { status: 404 });

    const emailUser = (user.email || '').toLowerCase();
    const autorise =
      (doc.clientEmail || '').toLowerCase() === emailUser ||
      (doc.proprietaire || '').toLowerCase() === emailUser ||
      user.role === 'admin';
    if (!autorise) return Response.json({ error: 'Accès refusé' }, { status: 403 });

    if (doc.statut === 'paye') return Response.json({ error: 'Ce document est déjà payé.' }, { status: 400 });
    const montant = Math.round(Number(doc.montant || 0) * 100);
    if (!montant || montant <= 0) return Response.json({ error: 'Montant invalide' }, { status: 400 });

    const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY'));
    const libelles = { devis: 'Devis', facture: 'Facture', contrat: 'Contrat' };
    const base = urlRetour || 'https://example.com';

    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      customer_email: doc.clientEmail || undefined,
      line_items: [
        {
          price_data: {
            currency: 'eur',
            unit_amount: montant,
            product_data: {
              name: `${libelles[doc.type] || doc.type} ${doc.numero}`,
              description: doc.description || undefined,
            },
          },
          quantity: 1,
        },
      ],
      success_url: `${base}?paiement=succes&document=${doc.id}`,
      cancel_url: `${base}?paiement=annule`,
      metadata: {
        base44_app_id: Deno.env.get('BASE44_APP_ID') || '',
        document_id: doc.id,
      },
    });

    return Response.json({ url: session.url });
  } catch (error) {
    console.error('paiementDocument:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});