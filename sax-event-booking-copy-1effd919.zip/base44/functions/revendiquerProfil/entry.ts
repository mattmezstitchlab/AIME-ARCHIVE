import { createClientFromRequest } from 'npm:@base44/sdk@0.8.38';

// Revendication d'un profil de démonstration : l'utilisateur connecté devient
// propriétaire du profil et de tout son contenu (à-propos, tarifs, FAQ…).
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Connexion requise.' }, { status: 401 });

    const { slug } = await req.json();
    const sr = base44.asServiceRole.entities;
    const profils = await sr.ProfilPrestataire.filter({ slug: String(slug || '') }, '-updated_date', 1);
    const profil = profils[0];
    if (!profil) return Response.json({ error: 'Profil introuvable.' }, { status: 404 });

    const ancien = String(profil.proprietaire || '');
    const estDemo = ancien.startsWith('demo.') && ancien.endsWith('@aime-event.fr');
    if (!estDemo) return Response.json({ error: 'Ce profil a déjà un propriétaire.' }, { status: 403 });

    const email = String(user.email || '').toLowerCase();
    await sr.ProfilPrestataire.update(profil.id, { proprietaire: email, emailNotification: email });
    for (const entite of ['ContenuAPropos', 'FormuleTarif', 'QuestionFaq', 'MediaGalerie', 'StyleRepertoire']) {
      await sr[entite].updateMany({ proprietaire: ancien }, { $set: { proprietaire: email } });
    }

    return Response.json({ success: true, slug: profil.slug });
  } catch (error) {
    console.error('revendiquerProfil :', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});