import { createClientFromRequest } from 'npm:@base44/sdk@0.8.38';

// Réservation directe type Doctolib : un visiteur réserve un créneau hebdomadaire
// configuré par le prestataire, sur une date encore libre. La réservation est confirmée d'office.
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const sr = base44.asServiceRole;
    let data = {};
    try { data = await req.json(); } catch (_e) { data = {}; }

    // Honeypot anti-bot
    if (data.siteWeb) return Response.json({ success: true });

    let proprietaire = String(data.proprietaire || '').trim().toLowerCase();
    if (proprietaire && !proprietaire.includes('@')) {
      const parSlug = await sr.entities.ProfilPrestataire.filter({ slug: proprietaire }, '-updated_date', 1);
      proprietaire = String(parSlug[0]?.proprietaire || '').toLowerCase();
    }
    const date = String(data.date || '').trim();
    const heureDebut = String(data.heureDebut || '').trim();
    const heureFin = String(data.heureFin || '').trim();
    const nom = String(data.nom || '').trim().slice(0, 120);
    const prenom = String(data.prenom || '').trim().slice(0, 120);
    const telephone = String(data.telephone || '').trim().slice(0, 30);
    const email = String(data.email || '').trim().toLowerCase();
    const adresseEvenement = String(data.adresseEvenement || '').trim().slice(0, 300);
    const typeEvenement = String(data.typeEvenement || 'Autre').trim();

    if (!proprietaire || !/^\d{4}-\d{2}-\d{2}$/.test(date) || !nom || !prenom || !telephone || !adresseEvenement) {
      return Response.json({ error: 'Informations incomplètes.' }, { status: 400 });
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return Response.json({ error: 'Adresse e-mail invalide.' }, { status: 400 });
    }
    const aujourdHuiParis = new Date().toLocaleDateString('fr-CA', { timeZone: 'Europe/Paris' });
    if (date < aujourdHuiParis) {
      return Response.json({ error: 'Cette date est passée.' }, { status: 400 });
    }

    // La réservation directe doit être activée par le prestataire.
    const profils = await sr.entities.ProfilPrestataire.filter({ proprietaire }, '-updated_date', 1);
    const profil = profils[0];
    if (!profil || !profil.reservationDirecte) {
      return Response.json({ error: "La réservation directe n'est pas activée pour ce prestataire." }, { status: 403 });
    }

    // Le créneau demandé doit correspondre à un créneau hebdomadaire configuré pour ce jour.
    const jourSemaine = new Date(`${date}T12:00:00`).getDay();
    const creneaux = await sr.entities.CreneauHebdo.filter({ proprietaire, jour: jourSemaine }, 'heureDebut', 50);
    const creneauValide = creneaux.find((c) => c.heureDebut === heureDebut && c.heureFin === heureFin);
    if (!creneauValide) {
      return Response.json({ error: "Ce créneau n'est pas proposé ce jour-là." }, { status: 400 });
    }

    // La date doit être encore libre (ni bloquée, ni déjà confirmée, ni événement).
    const [bloquees, confirmees, evenements] = await Promise.all([
      sr.entities.DateBloquee.filter({ proprietaire, date }, '-date', 1),
      sr.entities.DemandesDisponibilite.filter({ proprietaire, dateEvenement: date, statut: 'Confirmée' }, '-created_date', 1),
      sr.entities.Evenement.filter({ proprietaire, date, statut: 'confirme' }, '-date', 1),
    ]);
    if (bloquees[0] || confirmees[0] || evenements[0]) {
      return Response.json({ error: "Cette date vient d'être prise. Choisissez-en une autre." }, { status: 409 });
    }

    const reference = 'RSV-' + crypto.randomUUID().replace(/-/g, '').slice(0, 8).toUpperCase();
    const maintenant = new Date();
    await sr.entities.DemandesDisponibilite.create({
      proprietaire,
      reference,
      nom,
      prenom,
      telephone,
      email,
      adresseEvenement,
      typeEvenement,
      dateEvenement: date,
      heureDebut,
      heureFin,
      informationsComplementaires: 'Réservation directe en ligne (créneau hebdomadaire).',
      consentement: true,
      statut: 'Confirmée',
      dateCreation: maintenant.toISOString(),
    });

    const [a, m, j] = date.split('-');
    const dateFr = `${j}/${m}/${a}`;
    const nomPrestataire = profil.nomAffiche || 'Aime Event';

    // E-mails non bloquants : la réservation est déjà enregistrée.
    try {
      await sr.integrations.Core.SendEmail({
        to: profil.emailNotification || proprietaire,
        subject: `Réservation directe [${reference}] – ${prenom} ${nom} – ${dateFr}`,
        body: `Nouvelle réservation directe confirmée\n\nRéférence : ${reference}\n\nNom : ${nom}\nPrénom : ${prenom}\nTéléphone : ${telephone}\nE-mail : ${email}\nType d'événement : ${typeEvenement}\nDate : ${dateFr}\nCréneau : de ${heureDebut} à ${heureFin}\nAdresse : ${adresseEvenement}\n\nCette date est maintenant marquée comme réservée sur votre calendrier.`,
        from_name: 'Réservation directe',
      });
    } catch (e) { console.error('reserverCreneau e-mail prestataire:', e.message); }
    try {
      await sr.integrations.Core.SendEmail({
        to: email,
        subject: `Votre réservation du ${dateFr} est confirmée`,
        body: `Bonjour ${prenom},\n\nVotre réservation est confirmée !\n\nRéférence : ${reference}\nDate : ${dateFr}\nCréneau : de ${heureDebut} à ${heureFin}\nAdresse : ${adresseEvenement}\n\n${nomPrestataire} vous contactera rapidement pour affiner les détails.\n\nÀ très vite,\n${nomPrestataire}`,
        from_name: nomPrestataire,
      });
    } catch (e) { console.error('reserverCreneau e-mail client:', e.message); }

    return Response.json({ success: true, reference });
  } catch (error) {
    console.error('reserverCreneau:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});