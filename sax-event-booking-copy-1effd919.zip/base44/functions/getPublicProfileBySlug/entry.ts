import { createClientFromRequest } from 'npm:@base44/sdk@0.8.38';

// Profil public assaini : ne retourne JAMAIS l'e-mail du propriétaire,
// l'e-mail de notification, les coordonnées bancaires, les informations
// d'intermittence ni aucun identifiant ou fichier privé.
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const sr = base44.asServiceRole.entities;
    let data = {};
    try { data = await req.json(); } catch (_e) { data = {}; }

    let profilRecord = null;
    if (data.slug) {
      const trouves = await sr.ProfilPrestataire.filter({ slug: String(data.slug) }, '-updated_date', 1);
      profilRecord = trouves[0] || null;
      if (!profilRecord) {
        return Response.json({ error: 'Profil introuvable.' }, { status: 404 });
      }
    } else {
      // Route racine : le profil du lancement, sinon le premier profil créé.
      const fondateur = await sr.ProfilPrestataire.filter({ slug: 'matt' }, '-updated_date', 1);
      profilRecord = fondateur[0] || (await sr.ProfilPrestataire.list('created_date', 1))[0] || null;
      if (!profilRecord) {
        return Response.json({ error: 'Profil introuvable.' }, { status: 404 });
      }
    }

    const proprietaire = profilRecord.proprietaire || null;
    const filtre = proprietaire ? { proprietaire } : {};
    const estDemo = !!(proprietaire && proprietaire.startsWith('demo.') && proprietaire.endsWith('@aime-event.fr'));

    const [medias, questions, formules, styles, aPropos, bloquees, confirmees, evenementsConfirmes, avis] = await Promise.all([
      sr.MediaGalerie.filter(filtre, 'ordre', 100),
      sr.QuestionFaq.filter(filtre, 'ordre', 100),
      sr.FormuleTarif.filter(filtre, 'ordre', 50),
      sr.StyleRepertoire.filter(filtre, 'ordre', 50),
      sr.ContenuAPropos.filter(filtre, '-updated_date', 1),
      sr.DateBloquee.filter(filtre, '-date', 500),
      sr.DemandesDisponibilite.filter({ ...filtre, statut: 'Confirmée' }, '-dateEvenement', 500),
      sr.Evenement.filter({ ...filtre, statut: 'confirme' }, '-date', 500),
      sr.Temoignage.filter({ ...filtre, approuve: true }, '-created_date', 50),
    ]);

    const reservationDirecte = !!profilRecord.reservationDirecte;
    const creneauxHebdo = reservationDirecte
      ? (await sr.CreneauHebdo.filter(filtre, 'heureDebut', 100)).map((c) => ({ jour: c.jour, heureDebut: c.heureDebut, heureFin: c.heureFin }))
      : [];

    // Options 48 h encore actives, affichées comme « sous option » sur le calendrier public.
    const options = await sr.OptionDate.filter(filtre, '-created_date', 200);
    const maintenantOpt = new Date();
    const datesSousOption = [...new Set(
      options.filter((o) => o.expireLe && new Date(o.expireLe) > maintenantOpt).map((o) => o.date)
    )];

    // Créneaux réservés rendus publics (heures + ville seulement, jamais l'identité du client).
    const villeDe = (adresse) => {
      if (!adresse) return '';
      const part = String(adresse).split(',').pop().trim();
      return part.replace(/^\d{4,5}\s*/, '').trim();
    };
    const creneauxReserves = {};
    confirmees.forEach((d) => {
      if (!d.dateEvenement) return;
      if (!creneauxReserves[d.dateEvenement]) creneauxReserves[d.dateEvenement] = [];
      creneauxReserves[d.dateEvenement].push({
        heureDebut: d.heureDebut || '',
        heureFin: d.heureFin || '',
        ville: villeDe(d.adresseEvenement),
      });
    });

    const datesIndisponibles = [...new Set([
      ...bloquees.map((b) => b.date),
      ...confirmees.map((d) => d.dateEvenement),
      ...evenementsConfirmes.map((e) => e.date),
    ])].filter(Boolean);

    return Response.json({
      profil: {
        nomAffiche: profilRecord.nomAffiche,
        sousTitre: profilRecord.sousTitre,
        ville: profilRecord.ville || '',
        accroche: profilRecord.accroche,
        photoProfilUrl: profilRecord.photoProfilUrl,
        couvertureUrl: profilRecord.couvertureUrl,
        sectionsMasquees: profilRecord.sectionsMasquees || [],
        ordreSections: profilRecord.ordreSections || [],
        styleMiniSite: profilRecord.styleMiniSite || 'editorial',
        modeGalerie: profilRecord.modeGalerie || 'grille',
        slug: profilRecord.slug || '',
      },
      estDemo,
      aRevendiquer: estDemo,
      nbAvis: avis.length,
      medias: medias.map((m) => ({ id: m.id, url: m.url, legende: m.legende })),
      questions: questions.map((q) => ({ id: q.id, question: q.question, reponse: q.reponse })),
      formules: formules.map((f) => ({ id: f.id, nom: f.nom, prix: f.prix, duree: f.duree, ambiance: f.ambiance || '', imageUrl: f.imageUrl || '', details: f.details || [], populaire: !!f.populaire })),
      styles: styles.map((s) => ({ id: s.id, titre: s.titre, ambiance: s.ambiance, morceaux: s.morceaux || [], morceauxDetails: s.morceauxDetails || [] })),
      aPropos: aPropos[0]
        ? { photoUrl: aPropos[0].photoUrl, paragraphes: aPropos[0].paragraphes || [], valeurs: aPropos[0].valeurs || [], jalons: aPropos[0].jalons || [] }
        : null,
      datesIndisponibles,
      creneauxReserves,
      datesSousOption,
      reservationDirecte,
      calendrierConfigure: bloquees.length > 0 || confirmees.length > 0 || evenementsConfirmes.length > 0 || creneauxHebdo.length > 0,
      creneauxHebdo,
    });
  } catch (error) {
    console.error('getPublicProfileBySlug :', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});