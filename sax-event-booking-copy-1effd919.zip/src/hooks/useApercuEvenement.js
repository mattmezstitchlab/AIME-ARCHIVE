import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { construireEvenement, persistanceComplete } from "@/lib/persistanceEvenement";
import { blocagesCreation, normaliserAnalyse } from "@/lib/validationApercu";
import { effacerBrouillon, lireAnalyse, lireBrief, obtenirSessionAnalyse, sauverAnalyse, sauverBrief } from "@/lib/brouillonEvenement";

export default function useApercuEvenement() {
  const navigate = useNavigate();
  const [brief, setBrief] = useState(lireBrief());
  const [analyse, setAnalyse] = useState(() => normaliserAnalyse(lireAnalyse()));
  const [chargement, setChargement] = useState(!lireAnalyse());
  const [editionBrief, setEditionBrief] = useState(false);
  const [confirme, setConfirmeEtat] = useState(sessionStorage.getItem("aime_event_confirme") === "1");
  const [creation, setCreation] = useState(false);
  const [erreur, setErreur] = useState("");
  const lance = useRef(false);
  const corrige = useRef(false);
  const creationEnCours = useRef(false);

  const setConfirme = (valeur) => { setConfirmeEtat(valeur); sessionStorage.setItem("aime_event_confirme", valeur ? "1" : "0"); };
  const analyser = async (texte) => {
    setChargement(true); setErreur(""); setAnalyse(null); setConfirme(false); sauverBrief(texte);
    try {
      const res = await base44.functions.invoke("extraireBriefEvenement", { brief: texte, sessionId: obtenirSessionAnalyse() });
      const resultat = normaliserAnalyse(res.data); setAnalyse(resultat); sauverAnalyse(resultat);
      base44.analytics.track({ eventName: "brief_analyzed" });
    } catch (e) { setErreur(e?.response?.data?.error || "L’analyse est momentanément indisponible."); }
    finally { setChargement(false); }
  };

  useEffect(() => {
    const maintenant = Date.now(); const derniereVue = Number(sessionStorage.getItem("aime_preview_viewed_at") || 0);
    if (maintenant - derniereVue > 1500) { base44.analytics.track({ eventName: "preview_viewed" }); sessionStorage.setItem("aime_preview_viewed_at", String(maintenant)); }
    if (!brief) { navigate("/", { replace: true }); return; }
    if (!analyse && !lance.current) { lance.current = true; analyser(brief); }
  }, []);

  const modifier = (cle, valeur) => {
    const suivant = { ...analyse, [cle]: valeur }; setAnalyse(suivant); sauverAnalyse(suivant); setConfirme(false);
    if (!corrige.current) { corrige.current = true; base44.analytics.track({ eventName: "preview_corrected", properties: { field: cle } }); }
  };
  const blocages = blocagesCreation(analyse, confirme);

  const creer = async () => {
    if (creationEnCours.current) return;
    setErreur("");
    if (blocages.length) { setErreur("Corrigez les points bloquants avant de créer l’événement."); return; }
    creationEnCours.current = true;
    const connecte = await base44.auth.isAuthenticated();
    if (!connecte) {
      creationEnCours.current = false;
      sauverAnalyse(analyse); const id = obtenirSessionAnalyse();
      if (sessionStorage.getItem("aime_signup_started") !== id) { base44.analytics.track({ eventName: "signup_started" }); sessionStorage.setItem("aime_signup_started", id); }
      window.location.href = `/register?next=${encodeURIComponent("/apercu-evenement")}`; return;
    }
    setCreation(true);
    try {
      const user = await base44.auth.me();
      const demandeId = obtenirSessionAnalyse();
      const attendu = construireEvenement(analyse, user, demandeId);
      const existants = await base44.entities.Evenement.filter({ proprietaire: attendu.proprietaire, demandeId }, "-created_date", 1);
      let evenement = existants[0];
      if (evenement && !persistanceComplete(attendu, evenement)) {
        await base44.entities.Evenement.update(evenement.id, attendu);
        evenement = await base44.entities.Evenement.get(evenement.id);
      }
      if (!evenement) {
        const cree = await base44.entities.Evenement.create(attendu);
        evenement = await base44.entities.Evenement.get(cree.id);
      }
      if (!persistanceComplete(attendu, evenement)) throw new Error("persistance_incomplete");
      base44.analytics.track({ eventName: "event_confirmed" }); effacerBrouillon(); navigate(`/compte?evenement=${evenement.id}`);
    } catch (_e) {
      creationEnCours.current = false;
      setErreur("La création complète n’a pas pu être vérifiée. Vos corrections sont conservées."); setCreation(false);
    }
  };
  return { brief, setBrief, analyse, chargement, editionBrief, setEditionBrief, confirme, setConfirme, creation, erreur, analyser, modifier, blocages, creer };
}