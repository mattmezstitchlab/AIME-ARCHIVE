import { useEffect } from "react";

function majMeta(attr, cle, contenu) {
  let el = document.head.querySelector(`meta[${attr}="${cle}"]`);
  if (!el) {
    el = document.createElement("meta");
    el.setAttribute(attr, cle);
    document.head.appendChild(el);
  }
  el.setAttribute("content", contenu);
}

/** Met à jour titre, description, canonical, Open Graph et données structurées. */
export default function useSeo({ titre, description, ogImage, chemin, noindex, structuredData }) {
  useEffect(() => {
    majMeta("name", "robots", noindex ? "noindex, nofollow" : "index, follow");
    if (titre) {
      document.title = titre;
      majMeta("property", "og:title", titre);
    }
    if (description) {
      majMeta("name", "description", description);
      majMeta("property", "og:description", description);
    }
    if (ogImage) majMeta("property", "og:image", ogImage);

    let canon = document.head.querySelector('link[rel="canonical"]');
    if (!canon) {
      canon = document.createElement("link");
      canon.setAttribute("rel", "canonical");
      document.head.appendChild(canon);
    }
    canon.setAttribute("href", window.location.origin + (chemin ?? window.location.pathname));

    const id = "aime-event-structured-data";
    let script = document.getElementById(id);
    if (structuredData) {
      if (!script) {
        script = document.createElement("script");
        script.id = id;
        script.type = "application/ld+json";
        document.head.appendChild(script);
      }
      script.textContent = JSON.stringify(structuredData);
    } else if (script) {
      script.remove();
    }
  }, [titre, description, ogImage, chemin, noindex, structuredData]);
}