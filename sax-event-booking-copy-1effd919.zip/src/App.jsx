import { useEffect } from 'react';
import { Toaster } from "@/components/ui/toaster"
import { initAccessibilite } from '@/lib/accessibilite';
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import ProtectedRoute from '@/components/ProtectedRoute';
import Compte from './pages/Compte';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ScrollToTop from './components/ScrollToTop';
import Profil from './pages/Profil';
import Accueil from './pages/Accueil';
import MentionsLegales from './pages/MentionsLegales';
import Confidentialite from './pages/Confidentialite';
import ConditionsUtilisation from './pages/ConditionsUtilisation';
import Login from './pages/Login';
import Register from './pages/Register';
import ForgotPassword from './pages/ForgotPassword';
import ResetPassword from './pages/ResetPassword';
import PlaylistInvite from './pages/PlaylistInvite';
import AllergiesInvite from './pages/AllergiesInvite';
import CreerEvenement from './pages/CreerEvenement';
import ApercuEvenement from './pages/ApercuEvenement';
import BarreCapsule from '@/components/plateforme/BarreCapsule';
import RedirectionLogin from '@/components/RedirectionLogin';
import { EventProvider } from '@/contexts/EventContext';
import Guide from './pages/Guide';
// Add page imports here

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  return (
    <Routes>
      {/* Add your page Route elements here */}
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />
      <Route path="/" element={<Accueil />} />
      <Route path="/guide" element={<Guide />} />
      <Route path="/apercu-evenement" element={<ApercuEvenement />} />
      <Route path="/registre" element={<Navigate to="/" replace />} />
      <Route path="/profil" element={<Profil />} />
      <Route path="/p/:slug" element={<Profil />} />
      <Route path="/mentions-legales" element={<MentionsLegales />} />
      <Route path="/confidentialite" element={<Confidentialite />} />
      <Route path="/conditions-utilisation" element={<ConditionsUtilisation />} />
      <Route path="/playlist/:evenementId" element={<PlaylistInvite />} />
      <Route path="/allergies/:evenementId" element={<AllergiesInvite />} />
      <Route path="/admin" element={<Navigate to="/compte" replace />} />
      <Route path="/espace-client" element={<Navigate to="/compte" replace />} />
      <Route element={<ProtectedRoute unauthenticatedElement={<RedirectionLogin />} />}>
        <Route path="/compte" element={<Compte />} />
        <Route path="/documents" element={<Navigate to="/compte?onglet=documents" replace />} />
        <Route path="/creer" element={<CreerEvenement />} />
      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};


function App() {
  useEffect(() => { initAccessibilite(); }, []);

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <EventProvider>
            <ScrollToTop />
            <AuthenticatedApp />
            <BarreCapsule />
          </EventProvider>
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App