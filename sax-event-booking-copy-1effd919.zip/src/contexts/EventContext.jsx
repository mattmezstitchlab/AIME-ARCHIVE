import React, { createContext, useContext, useEffect, useMemo, useState } from "react";
import { useLocation } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { MODULES_EVENEMENT, ACTIONS_PAR_CONTEXTE, contexteActions } from "@/lib/eventModeConfig";
import { deriveImpactsCausals } from "@/lib/eventCausalSelectors";
const EventContext = createContext(null);
export function EventProvider({ children }) {
  const { search } = useLocation(), { user } = useAuth(), params = new URLSearchParams(search);
  const evenementId = params.get("evenement"), moduleActif = MODULES_EVENEMENT[params.get("studio")] ? params.get("studio") : "cadran", panneauOuvert = params.get("panneau");
  const [evenement, setEvenement] = useState(null), [documents, setDocuments] = useState([]), [simulation, setSimulation] = useState(null);
  const chargerDocuments = () => evenementId ? base44.entities.DocumentEmis.filter({ evenementId }, "-created_date", 100).then(setDocuments).catch(() => setDocuments([])) : Promise.resolve();
  useEffect(() => {
    setEvenement(null); setDocuments([]); setSimulation(null); if (!evenementId) return;
    base44.entities.Evenement.get(evenementId).then(setEvenement); chargerDocuments();
    const unsubscribe = base44.entities.Evenement.subscribe((ev) => { if (ev.data?.id === evenementId && ev.type === "update") setEvenement(ev.data); });
    const actualiser = () => chargerDocuments(); window.addEventListener("aime-event-documents", actualiser);
    return () => { unsubscribe(); window.removeEventListener("aime-event-documents", actualiser); };
  }, [evenementId]);
  const peutModifier = !!evenement && (user?.role === "admin" || evenement.proprietaire === user?.email), contexte = contexteActions(moduleActif, panneauOuvert);
  const value = useMemo(() => ({ evenementId, evenement, setEvenement, documents, moduleActif, panneauOuvert, actionsDisponibles: peutModifier ? ACTIONS_PAR_CONTEXTE[contexte] || [] : [], impactsCausals: deriveImpactsCausals(evenement, documents, simulation), simulation, setSimulation, autorisations: { peutModifier } }), [evenementId, evenement, documents, moduleActif, panneauOuvert, contexte, simulation, peutModifier]);
  return <EventContext.Provider value={value}>{children}</EventContext.Provider>;
}
export const useEventContext = () => useContext(EventContext);