import React from "react";

export default function BlocLegal({ titre, children }) {
  return (
    <section className="rounded-xl border border-[var(--p-border)] bg-[var(--p-surface)] p-6 shadow-sm">
      <h2 className="mb-3 font-heading text-xl text-[var(--p-text)]">{titre}</h2>
      <div className="space-y-2 text-sm leading-relaxed text-[var(--p-text-soft)]">{children}</div>
    </section>
  );
}