import React from "react";
import EnTetePlateforme from "@/components/plateforme/EnTetePlateforme";

export default function CadreLegal({ titre, children }) {
  return (
    <div className="theme-apple min-h-screen bg-[var(--p-bg)] text-[var(--p-text)] font-body">
      <EnTetePlateforme />
      <header className="border-b border-[var(--p-border)] bg-[var(--p-surface)]">
        <div className="max-w-3xl mx-auto px-4 md:px-6 py-5">
          <h1 className="font-heading text-2xl">{titre}</h1>
          <p className="text-xs uppercase tracking-[0.25em] text-[var(--p-accent)] font-bold mt-1">Aime Event</p>
        </div>
      </header>
      <main className="max-w-3xl mx-auto px-4 md:px-6 py-10 space-y-8">{children}</main>
    </div>
  );
}