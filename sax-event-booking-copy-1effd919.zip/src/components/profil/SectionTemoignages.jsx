import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import FormulaireTemoignage from "@/components/temoignages/FormulaireTemoignage";
import ListeTemoignages from "@/components/temoignages/ListeTemoignages";

export default function SectionTemoignages({ proprietaire }) {
  const [temoignages, setTemoignages] = useState([]);
  const [chargement, setChargement] = useState(true);

  const charger = async () => {
    try {
      const res = await base44.functions.invoke("temoignages", { action: "lister", proprietaire });
      setTemoignages(res.data.temoignages || []);
    } finally {
      setChargement(false);
    }
  };

  useEffect(() => {
    charger();
  }, [proprietaire]);

  return (
    <div className="space-y-10">
      <ListeTemoignages temoignages={temoignages} chargement={chargement} />
      <FormulaireTemoignage onEnvoye={charger} proprietaire={proprietaire} />
    </div>
  );
}