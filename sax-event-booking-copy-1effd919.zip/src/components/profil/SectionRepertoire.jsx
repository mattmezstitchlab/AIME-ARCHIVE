import React from "react";
import MorceauApercu from "@/components/profil/MorceauApercu";

export default function SectionRepertoire({ styles }) {
  if (!styles?.length) {
    return <p className="text-center text-[var(--p-muted)] py-12">Le répertoire arrive bientôt.</p>;
  }
  return (
    <div className="space-y-14">
      {styles.map((s, i) => (
        <article key={s.id} className="grid grid-cols-1 md:grid-cols-5 gap-4 md:gap-10">
          <div className="md:col-span-2">
            <p className="text-xs font-bold tracking-[0.3em] text-[var(--p-faint)]">
              {String(i + 1).padStart(2, "0")}
            </p>
            <h3 className="font-heading text-2xl md:text-3xl mt-2 text-[var(--p-text)]">{s.titre}</h3>
            {s.ambiance && (
              <p className="mt-3 text-sm md:text-base italic text-[var(--p-text-soft)] leading-relaxed">
                {s.ambiance}
              </p>
            )}
          </div>
          {s.morceauxDetails?.length > 0 ? (
            <div className="md:col-span-3 grid grid-cols-1 sm:grid-cols-2 gap-2 content-start">
              {s.morceauxDetails.map((m, j) => (
                <MorceauApercu key={j} morceau={m} />
              ))}
            </div>
          ) : s.morceaux?.length > 0 ? (
            <div className="md:col-span-3 flex flex-wrap content-start gap-2">
              {s.morceaux.map((m, j) => (
                <span
                  key={j}
                  className="px-4 py-2 rounded-full bg-[var(--p-surface)] text-sm text-[var(--p-text-soft)] shadow-sm"
                >
                  {m}
                </span>
              ))}
            </div>
          ) : null}
        </article>
      ))}
    </div>
  );
}