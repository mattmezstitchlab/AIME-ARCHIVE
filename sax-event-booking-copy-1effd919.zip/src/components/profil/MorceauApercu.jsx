import React, { useEffect, useState } from "react";
import { Play, Pause } from "lucide-react";
import { basculerLecture, surChangementLecture } from "@/lib/lecteurApercu";

// Fiche morceau façon DJ : pochette, extrait 30 s, BPM et genre.
export default function MorceauApercu({ morceau }) {
  const [enLecture, setEnLecture] = useState(false);

  useEffect(() => {
    if (!morceau.previewUrl) return;
    return surChangementLecture((url) => setEnLecture(url === morceau.previewUrl));
  }, [morceau.previewUrl]);

  return (
    <div className="flex items-center gap-3 rounded-2xl bg-[var(--p-surface)] shadow-sm pl-2 pr-4 py-2">
      {morceau.previewUrl ? (
        <button
          type="button"
          onClick={() => basculerLecture(morceau.previewUrl)}
          title={enLecture ? "Arrêter l'extrait" : "Écouter un extrait de 30 secondes"}
          aria-label={`${enLecture ? "Arrêter" : "Écouter"} un extrait de ${morceau.titre}`}
          className="relative h-11 w-11 shrink-0 rounded-xl overflow-hidden group"
        >
          {morceau.pochetteUrl ? (
            <img src={morceau.pochetteUrl} alt="" className="h-full w-full object-cover" />
          ) : (
            <span className="absolute inset-0 bg-[var(--p-bg)]" aria-hidden="true" />
          )}
          <span className={`absolute inset-0 flex items-center justify-center bg-black/45 text-white transition-opacity ${enLecture ? "opacity-100" : "opacity-70 group-hover:opacity-100"}`}>
            {enLecture ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4 ml-0.5" />}
          </span>
        </button>
      ) : morceau.pochetteUrl ? (
        <img src={morceau.pochetteUrl} alt="" className="h-11 w-11 shrink-0 rounded-xl object-cover" />
      ) : null}
      <div className="min-w-0">
        <p className="text-sm font-semibold text-[var(--p-text)] truncate">{morceau.titre}</p>
        <p className="text-xs text-[var(--p-muted)] truncate">
          {[morceau.artiste, morceau.genre, morceau.bpm ? `${morceau.bpm} BPM` : ""].filter(Boolean).join(" · ")}
        </p>
      </div>
    </div>
  );
}