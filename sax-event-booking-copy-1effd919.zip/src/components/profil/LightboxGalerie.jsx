import React, { useEffect, useCallback } from "react";
import { X, ChevronLeft, ChevronRight } from "lucide-react";

export default function LightboxGalerie({ medias, index, onFermer, onChanger }) {
  const media = medias[index];

  const precedent = useCallback(() => onChanger((index - 1 + medias.length) % medias.length), [index, medias.length, onChanger]);
  const suivant = useCallback(() => onChanger((index + 1) % medias.length), [index, medias.length, onChanger]);

  useEffect(() => {
    const auClavier = (e) => {
      if (e.key === "Escape") onFermer();
      if (e.key === "ArrowLeft") precedent();
      if (e.key === "ArrowRight") suivant();
    };
    document.addEventListener("keydown", auClavier);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", auClavier);
      document.body.style.overflow = "";
    };
  }, [onFermer, precedent, suivant]);

  if (!media) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={media.legende || "Photo en grand format"}
      className="fixed inset-0 z-[100] bg-black/95 flex items-center justify-center"
      onClick={onFermer}
    >
      <button
        onClick={onFermer}
        aria-label="Fermer"
        className="absolute top-4 right-4 h-11 w-11 inline-flex items-center justify-center rounded-full bg-white/10 text-white hover:bg-white/25 transition-colors z-10"
      >
        <X className="h-5 w-5" />
      </button>

      {medias.length > 1 && (
        <>
          <button
            onClick={(e) => { e.stopPropagation(); precedent(); }}
            aria-label="Photo précédente"
            className="absolute left-3 md:left-6 h-11 w-11 inline-flex items-center justify-center rounded-full bg-white/10 text-white hover:bg-white/25 transition-colors z-10"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>
          <button
            onClick={(e) => { e.stopPropagation(); suivant(); }}
            aria-label="Photo suivante"
            className="absolute right-3 md:right-6 h-11 w-11 inline-flex items-center justify-center rounded-full bg-white/10 text-white hover:bg-white/25 transition-colors z-10"
          >
            <ChevronRight className="h-5 w-5" />
          </button>
        </>
      )}

      <figure className="max-w-[92vw] max-h-[88vh] flex flex-col items-center gap-3" onClick={(e) => e.stopPropagation()}>
        <img src={media.url} alt={media.legende || "Photo de prestation"} className="max-w-full max-h-[80vh] object-contain rounded-xl" />
        <figcaption className="text-sm text-white/70 text-center">
          {media.legende || ""} <span className="text-white/40 tabular-nums">{index + 1} / {medias.length}</span>
        </figcaption>
      </figure>
    </div>
  );
}