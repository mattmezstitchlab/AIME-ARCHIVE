import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Loader2, Zap, Check } from "lucide-react";

const classeInput =
  "min-h-[44px] w-full rounded-lg border border-[var(--p-border-strong)] bg-[var(--p-surface)] px-3 text-sm text-[var(--p-text)] placeholder:text-[var(--p-faint)] focus:outline-none focus:border-[var(--p-accent)]";

const TYPES = ["Mariage", "Anniversaire", "Cocktail", "Soirée privée", "Événement d'entreprise", "Restaurant ou hôtel", "Cérémonie", "Demande en mariage", "Autre"];

// Réservation immédiate type Doctolib d'un créneau hebdomadaire sur une date libre.
export default function ReservationDirecte({ proprietaire, date, creneaux, onDemarrer }) {
  const [creneau, setCreneau] = useState(null);
  const [form, setForm] = useState({ prenom: "", nom: "", telephone: "", email: "", adresseEvenement: "", typeEvenement: "Mariage", siteWeb: "" });
  const [envoi, setEnvoi] = useState(false);
  const [reference, setReference] = useState(null);
  const [erreur, setErreur] = useState("");

  const maj = (champ) => (e) => setForm({ ...form, [champ]: e.target.value });
  const complet = form.prenom.trim() && form.nom.trim() && form.telephone.trim() && form.email.trim() && form.adresseEvenement.trim();

  const reserver = async (ev) => {
    ev.preventDefault();
    if (!creneau || !complet) return;
    setEnvoi(true);
    setErreur("");
    try {
      const res = await base44.functions.invoke("reserverCreneau", {
        proprietaire, date, heureDebut: creneau.heureDebut, heureFin: creneau.heureFin, ...form,
      });
      setReference(res.data?.reference || "OK");
      base44.analytics.track({ eventName: "availability_request_sent" });
    } catch (err) {
      setErreur(err?.response?.data?.error || "La réservation n'a pas pu aboutir. Réessayez ou envoyez une demande classique.");
    } finally {
      setEnvoi(false);
    }
  };

  if (reference) {
    return (
      <div className="w-full max-w-md rounded-2xl border border-[var(--p-border)] bg-[var(--p-surface)] p-5 text-center space-y-2">
        <Check className="h-8 w-8 mx-auto text-[var(--p-accent)]" aria-hidden="true" />
        <p className="font-heading text-lg text-[var(--p-text)]">Réservation confirmée !</p>
        <p className="text-sm text-[var(--p-text-soft)]">
          Votre créneau de {creneau.heureDebut} à {creneau.heureFin} est réservé. Référence : <strong>{reference}</strong>. Un e-mail de confirmation vous a été envoyé.
        </p>
      </div>
    );
  }

  return (
    <div className="w-full max-w-md rounded-2xl border border-[var(--p-border)] bg-[var(--p-surface)] p-5 space-y-4">
      <p className="flex items-center gap-2 text-sm font-bold text-[var(--p-text)]">
        <Zap className="h-4 w-4 text-[#FF9F0A]" aria-hidden="true" /> Réservation immédiate possible ce jour-là
      </p>
      <div className="flex flex-wrap gap-2" role="group" aria-label="Créneaux réservables">
        {creneaux.map((c) => {
          const actif = creneau && creneau.heureDebut === c.heureDebut && creneau.heureFin === c.heureFin;
          return (
            <button
              key={`${c.heureDebut}-${c.heureFin}`}
              type="button"
              onClick={() => { if (!actif) onDemarrer?.(); setCreneau(actif ? null : c); }}
              aria-pressed={actif}
              className={`min-h-[44px] px-4 rounded-full text-sm font-medium transition-colors ${
                actif
                  ? "bg-[var(--p-cta)] text-[var(--p-cta-text)]"
                  : "border border-[var(--p-border-strong)] text-[var(--p-text)] hover:bg-[var(--p-bg)]"
              }`}
            >
              {c.heureDebut} – {c.heureFin}
            </button>
          );
        })}
      </div>

      {creneau && (
        <form onSubmit={reserver} className="space-y-3">
          <div className="grid grid-cols-2 gap-2">
            <input aria-label="Prénom" autoComplete="given-name" value={form.prenom} onChange={maj("prenom")} placeholder="Prénom" required className={classeInput} />
            <input aria-label="Nom" autoComplete="family-name" value={form.nom} onChange={maj("nom")} placeholder="Nom" required className={classeInput} />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <input aria-label="Téléphone" type="tel" autoComplete="tel" value={form.telephone} onChange={maj("telephone")} placeholder="Téléphone" required className={classeInput} />
            <input aria-label="Adresse e-mail" type="email" autoComplete="email" value={form.email} onChange={maj("email")} placeholder="E-mail" required className={classeInput} />
          </div>
          <input aria-label="Adresse de l’événement" autoComplete="street-address" value={form.adresseEvenement} onChange={maj("adresseEvenement")} placeholder="Adresse de l'événement" required className={classeInput} />
          <select value={form.typeEvenement} onChange={maj("typeEvenement")} className={classeInput} aria-label="Type d'événement">
            {TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
          </select>
          {/* Honeypot anti-bot, invisible pour les humains */}
          <input name="siteWeb" value={form.siteWeb} onChange={maj("siteWeb")} tabIndex={-1} autoComplete="off" aria-hidden="true" className="hidden" />
          {erreur && <p className="text-sm text-[var(--p-error)]">{erreur}</p>}
          <button
            type="submit"
            disabled={envoi || !complet}
            className="w-full min-h-[48px] rounded-full bg-[var(--p-cta)] text-[var(--p-cta-text)] text-sm font-bold hover:bg-[var(--p-cta-hover)] disabled:opacity-40 inline-flex items-center justify-center gap-2"
          >
            {envoi ? <Loader2 className="h-4 w-4 animate-spin" /> : <Zap className="h-4 w-4" />}
            Réserver ce créneau — confirmation immédiate
          </button>
        </form>
      )}
    </div>
  );
}