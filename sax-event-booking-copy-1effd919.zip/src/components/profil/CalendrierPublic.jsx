import React, { useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { JOURS_SEMAINE, cleDate, grilleMois, libelleMois } from "@/lib/calendrier";

export default function CalendrierPublic({ datesIndisponibles = [], onSelect, dateSelectionnee, onSelectOccupee, dateOccupee, datesSousOption = [], calendrierConfigure = false }) {
  const auj = new Date();
  const [annee, setAnnee] = useState(auj.getFullYear());
  const [mois, setMois] = useState(auj.getMonth());
  const indispo = new Set(datesIndisponibles);
  const sousOption = new Set(datesSousOption);
  const cleAujourdhui = cleDate(auj);

  // Jauge de demande du mois affiché : part des jours restants déjà pris.
  const joursFuturs = grilleMois(annee, mois).filter(Boolean).map(cleDate).filter((c) => c >= cleAujourdhui);
  const tauxOccupation = joursFuturs.length ? joursFuturs.filter((c) => indispo.has(c)).length / joursFuturs.length : 0;
  const jauge = joursFuturs.length === 0
    ? null
    : tauxOccupation >= 0.5
    ? ["Mois très demandé", "bg-[var(--p-cta)] text-[var(--p-cta-text)]"]
    : tauxOccupation >= 0.2
    ? ["Mois demandé", "bg-[var(--p-busy)] text-[var(--p-text-soft)]"]
    : [calendrierConfigure ? "Peu de dates bloquées" : "Disponibilité à confirmer", "border border-[var(--p-border-strong)] text-[var(--p-muted)]"];

  const naviguer = (delta) => {
    const d = new Date(annee, mois + delta, 1);
    setAnnee(d.getFullYear());
    setMois(d.getMonth());
  };

  return (
    <div className="rounded-2xl border border-[var(--p-border)] bg-[var(--p-surface)] shadow-sm p-6 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5 flex-wrap">
          <h3 className="font-heading text-lg text-[var(--p-text)]">{libelleMois(annee, mois)}</h3>
          {jauge && (
            <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wide ${jauge[1]}`}>
              {jauge[0]}
            </span>
          )}
        </div>
        <div className="flex gap-2">
          <button onClick={() => naviguer(-1)} aria-label="Mois précédent" className="h-9 w-9 rounded-full border border-[var(--p-border-strong)] flex items-center justify-center hover:bg-[var(--p-bg)]">
            <ChevronLeft className="h-4 w-4" />
          </button>
          <button onClick={() => naviguer(1)} aria-label="Mois suivant" className="h-9 w-9 rounded-full border border-[var(--p-border-strong)] flex items-center justify-center hover:bg-[var(--p-bg)]">
            <ChevronRight className="h-4 w-4" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-7 gap-1 text-center">
        {JOURS_SEMAINE.map((j) => (
          <p key={j} className="text-[10px] font-bold uppercase tracking-wide text-[var(--p-accent)] py-1">{j}</p>
        ))}
        {grilleMois(annee, mois).map((jour, i) => {
          if (!jour) return <div key={`v-${i}`} />;
          const cle = cleDate(jour);
          const passe = cle < cleAujourdhui;
          const occupe = indispo.has(cle);
          const selectionnable = !!onSelect && !passe && !occupe;
          const selectionnee = dateSelectionnee === cle;
          const occupeCliquable = occupe && !passe && !!onSelectOccupee;
          const contenuJour = sousOption.has(cle) && !occupe && !passe ? (
            <span className="relative">
              {jour.getDate()}
              <span className="absolute -top-1 -right-2 h-1.5 w-1.5 rounded-full bg-[#FF9F0A]" aria-hidden="true" />
            </span>
          ) : (
            jour.getDate()
          );
          const classes = `min-h-[38px] w-full rounded-lg text-sm flex items-center justify-center transition-colors ${
            passe
              ? "text-[var(--p-faint)]"
              : occupe
              ? `bg-[var(--p-busy)] text-[var(--p-faint)] line-through ${occupeCliquable ? "cursor-pointer hover:text-[var(--p-text-soft)]" : ""} ${dateOccupee === cle ? "ring-2 ring-[var(--p-accent)]" : ""}`
              : selectionnee
              ? "bg-[var(--p-cta)] text-[var(--p-cta-text)] font-bold"
              : selectionnable
              ? "text-[var(--p-text-soft)] hover:bg-[var(--p-bg)] cursor-pointer"
              : "text-[var(--p-text-soft)]"
          } ${cle === cleAujourdhui && !selectionnee ? "ring-2 ring-[var(--p-accent)]" : ""}`;

          return selectionnable ? (
            <button
              key={cle}
              type="button"
              onClick={() => onSelect(selectionnee ? "" : cle)}
              aria-pressed={selectionnee}
              aria-label={`Choisir le ${jour.getDate()} ${libelleMois(annee, mois)}`}
              className={classes}
            >
              {contenuJour}
            </button>
          ) : occupeCliquable ? (
            <button
              key={cle}
              type="button"
              onClick={() => onSelectOccupee(dateOccupee === cle ? null : cle)}
              aria-pressed={dateOccupee === cle}
              aria-label={`Voir le détail du ${jour.getDate()} ${libelleMois(annee, mois)} (déjà réservé)`}
              className={classes}
            >
              {contenuJour}
            </button>
          ) : (
            <div key={cle} className={classes}>{contenuJour}</div>
          );
        })}
      </div>

      <div className="space-y-1.5">
        <p className="flex items-center gap-2 text-xs text-[var(--p-muted)]">
          <span className="h-3.5 w-3.5 rounded bg-[var(--p-busy)] inline-block" /> Date déjà réservée ou indisponible{onSelectOccupee ? " — cliquez pour voir les créneaux restants" : ""}
        </p>
        {sousOption.size > 0 && (
          <p className="flex items-center gap-2 text-xs text-[var(--p-muted)]">
            <span className="h-1.5 w-1.5 rounded-full bg-[#FF9F0A] inline-block" /> Date sous option 48 h — encore réservable
          </p>
        )}
      </div>
    </div>
  );
}