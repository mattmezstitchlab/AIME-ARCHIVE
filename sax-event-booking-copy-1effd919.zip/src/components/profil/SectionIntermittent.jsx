import React from "react";
import { BadgeCheck, FileText, Euro, ClipboardCheck } from "lucide-react";

const ETAPES = [
  {
    icone: FileText,
    titre: "1. Avant la prestation — la déclaration",
    texte: "Toute embauche doit être déclarée avant la prestation (DPAE). Si vous êtes un particulier, une association ou une entreprise hors spectacle, le GUSO (guso.fr) fait tout en une seule démarche gratuite : contrat, paie et cotisations.",
  },
  {
    icone: Euro,
    titre: "2. Le cachet — toujours en brut",
    texte: "Le montant convenu est un cachet brut : les cotisations sociales du spectacle sont prélevées dessus. Ce n'est ni une facture ni de l'auto-entreprise — c'est un salaire.",
  },
  {
    icone: ClipboardCheck,
    titre: "3. Après la prestation — les attestations",
    texte: "L'employeur remet les justificatifs (feuillet GUSO ou AEM et bulletin de paie) qui permettent à l'artiste de faire valoir ses heures auprès de France Travail.",
  },
];

export default function SectionIntermittent({ infos }) {
  if (!infos) return null;

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-[var(--p-border)] bg-[var(--p-surface)] p-6">
        <div className="flex items-center gap-2 text-[var(--p-accent)]">
          <BadgeCheck className="h-5 w-5" />
          <span className="text-sm font-semibold">Artiste intermittent du spectacle</span>
        </div>
        <div className="mt-4 grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm">
          {infos.profession && (
            <div>
              <p className="text-xs uppercase tracking-wide text-[var(--p-muted)]">Profession</p>
              <p className="mt-1 text-[var(--p-text)] font-medium">{infos.profession}</p>
            </div>
          )}
          {infos.cachetIndicatif && (
            <div>
              <p className="text-xs uppercase tracking-wide text-[var(--p-muted)]">Cachet indicatif</p>
              <p className="mt-1 text-[var(--p-text)] font-medium">{infos.cachetIndicatif}</p>
            </div>
          )}
          {infos.numeroCongesSpectacles && (
            <div>
              <p className="text-xs uppercase tracking-wide text-[var(--p-muted)]">N° Congés Spectacles</p>
              <p className="mt-1 text-[var(--p-text)] font-medium">{infos.numeroCongesSpectacles}</p>
            </div>
          )}
        </div>
        {infos.employeurGuso && (
          <p className="mt-4 text-sm text-[var(--p-text-soft)] leading-relaxed">
            Employeurs occasionnels bienvenus : la déclaration se fait simplement et gratuitement via le GUSO.
          </p>
        )}
      </div>

      <div>
        <h3 className="text-sm font-semibold text-[var(--p-text)] mb-3">Vous êtes organisateur ? Ce qu'il faut savoir</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {ETAPES.map(({ icone: Icone, titre, texte }) => (
            <div key={titre} className="rounded-2xl border border-[var(--p-border)] bg-[var(--p-surface)] p-5">
              <Icone className="h-5 w-5 text-[var(--p-accent)]" />
              <p className="mt-3 text-sm font-semibold text-[var(--p-text)]">{titre}</p>
              <p className="mt-2 text-sm leading-relaxed text-[var(--p-text-soft)]">{texte}</p>
            </div>
          ))}
        </div>
      </div>

      {infos.precisions && (
        <div className="rounded-2xl border border-[var(--p-border)] bg-[var(--p-surface)] p-5">
          <p className="text-xs uppercase tracking-wide text-[var(--p-muted)]">Précisions</p>
          <p className="mt-2 text-sm leading-relaxed text-[var(--p-text-soft)] whitespace-pre-line">{infos.precisions}</p>
        </div>
      )}
    </div>
  );
}