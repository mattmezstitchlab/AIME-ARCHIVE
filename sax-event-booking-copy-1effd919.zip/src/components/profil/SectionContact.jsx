import React, { useRef, useState } from "react";
import { ArrowLeft, ArrowRight, CalendarDays } from "lucide-react";
import FormulaireDemande from "@/components/demande/FormulaireDemande";
import ConfirmationEnvoi from "@/components/demande/ConfirmationEnvoi";
import CalendrierPublic from "@/components/profil/CalendrierPublic";
import DetailDateOccupee from "@/components/profil/DetailDateOccupee";
import OptionDate48 from "@/components/profil/OptionDate48";
import ReservationDirecte from "@/components/profil/ReservationDirecte";
import { base44 } from "@/api/base44Client";

// Créneaux hebdomadaires proposés pour le jour de semaine de la date choisie.
function creneauxJour(creneauxHebdo, iso) {
  if (!iso) return [];
  const jour = new Date(`${iso}T12:00:00`).getDay();
  return creneauxHebdo.filter((c) => c.jour === jour);
}

function formatDateLongueFr(iso) {
  if (!iso) return "";
  const [a, m, j] = iso.split("-").map(Number);
  return new Date(a, m - 1, j).toLocaleDateString("fr-FR", {
    weekday: "long", day: "numeric", month: "long", year: "numeric",
  });
}

export default function SectionContact({ datesIndisponibles, proprietaire, creneauxReserves = {}, villePrestataire, datesSousOption = [], creneauxHebdo = [], calendrierConfigure = false }) {
  const [etape, setEtape] = useState(1);
  const [dateChoisie, setDateChoisie] = useState("");
  const [dateOccupee, setDateOccupee] = useState(null);
  const [envoye, setEnvoye] = useState(false);
  const [reference, setReference] = useState(null);
  const tunnelMesure = useRef(false);
  const entrerTunnel = () => {
    if (!tunnelMesure.current) { tunnelMesure.current = true; base44.analytics.track({ eventName: "profile_booking_started" }); }
    setEtape(2);
  };

  const recommencer = () => {
    setEnvoye(false);
    setEtape(1);
    setDateChoisie("");
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="text-center mb-10">
        <p className="text-sm text-[var(--p-text-soft)] leading-relaxed">
          {etape === 1 && !envoye
            ? "Commencez par choisir la date de votre événement."
            : "Quelques informations suffisent pour recevoir une réponse rapide."}
        </p>
      </div>

      {envoye ? (
        <div className="rounded-2xl border border-[var(--p-border)] bg-[var(--p-surface)] shadow-sm p-6 md:p-10">
          <ConfirmationEnvoi reference={reference} onNouvelleDemande={recommencer} />
        </div>
      ) : etape === 1 ? (
        <div className="space-y-6">
          <CalendrierPublic
            datesIndisponibles={datesIndisponibles}
            onSelect={(cle) => { setDateChoisie(cle); setDateOccupee(null); }}
            dateSelectionnee={dateChoisie}
            onSelectOccupee={setDateOccupee}
            dateOccupee={dateOccupee}
            datesSousOption={datesSousOption}
            calendrierConfigure={calendrierConfigure}
          />
          {dateOccupee && (
            <DetailDateOccupee
              date={dateOccupee}
              creneaux={creneauxReserves[dateOccupee] || []}
              villeReference={villePrestataire}
              datesIndisponibles={datesIndisponibles}
              proprietaire={proprietaire}
              onChoisirDate={(cle) => { setDateChoisie(cle); setDateOccupee(null); }}
            />
          )}
          <div className="flex flex-col items-center gap-3">
            {dateChoisie && (
              <p className="flex items-center gap-2 text-sm font-medium text-[var(--p-text)]">
                <CalendarDays className="h-4 w-4 text-[var(--p-accent)]" />
                {formatDateLongueFr(dateChoisie)}
              </p>
            )}
            {dateChoisie && creneauxJour(creneauxHebdo, dateChoisie).length > 0 && (
              <ReservationDirecte
                key={dateChoisie}
                proprietaire={proprietaire}
                date={dateChoisie}
                creneaux={creneauxJour(creneauxHebdo, dateChoisie)}
                onDemarrer={() => { if (!tunnelMesure.current) { tunnelMesure.current = true; base44.analytics.track({ eventName: "profile_booking_started" }); } }}
              />
            )}
            {dateChoisie && <OptionDate48 proprietaire={proprietaire} date={dateChoisie} />}
            <button
              onClick={entrerTunnel}
              disabled={!dateChoisie}
              className="min-h-[52px] px-9 rounded-full bg-[var(--p-cta)] text-[var(--p-cta-text)] font-bold text-sm md:text-base hover:bg-[var(--p-cta-hover)] transition-colors disabled:opacity-40 disabled:cursor-not-allowed inline-flex items-center gap-2"
            >
              Demander cette date <ArrowRight className="h-4 w-4" />
            </button>
            <button
              onClick={() => { setDateChoisie(""); entrerTunnel(); }}
              className="text-sm text-[var(--p-muted)] underline hover:text-[var(--p-text)] min-h-[40px]"
            >
              Je ne connais pas encore la date
            </button>
          </div>
        </div>
      ) : (
        <div className="space-y-5">
          <button
            onClick={() => setEtape(1)}
            className="inline-flex items-center gap-2 text-sm text-[var(--p-muted)] hover:text-[var(--p-text)] min-h-[40px]"
          >
            <ArrowLeft className="h-4 w-4" />
            {dateChoisie ? formatDateLongueFr(dateChoisie) : "Choisir une date"} — modifier
          </button>
          <div className="rounded-2xl border border-[var(--p-border)] bg-[var(--p-surface)] shadow-sm p-6 md:p-10">
            <FormulaireDemande
              key={dateChoisie}
              dateInitiale={dateChoisie}
              onSucces={(ref) => { setReference(ref || null); setEnvoye(true); }}
              proprietaire={proprietaire}
            />
          </div>
        </div>
      )}
    </div>
  );
}