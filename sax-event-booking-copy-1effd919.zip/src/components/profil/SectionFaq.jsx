import React from "react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

export default function SectionFaq({ questions }) {
  if (!questions?.length) {
    return <p className="text-center text-[var(--p-muted)] py-12">La FAQ arrive bientôt.</p>;
  }
  return (
    <Accordion type="single" collapsible className="space-y-3">
      {questions.map((q) => (
        <AccordionItem
          key={q.id}
          value={q.id}
          className="rounded-xl border border-[var(--p-border)] bg-[var(--p-surface)] px-5 last:border-b"
        >
          <AccordionTrigger className="text-left text-sm md:text-base font-medium text-[var(--p-text)] hover:no-underline">
            {q.question}
          </AccordionTrigger>
          <AccordionContent className="text-sm text-[var(--p-text-soft)] leading-relaxed">
            {q.reponse}
          </AccordionContent>
        </AccordionItem>
      ))}
    </Accordion>
  );
}