import React from "react";
import { ArrowUpRight } from "lucide-react";

// Liste éditoriale façon « Work » : lignes compactes séparées par de fins filets.
export default function SectionTarifs({ formules, onContact }) {
  if (!formules?.length) {
    return <p className="text-center text-[var(--p-muted)] py-12">Les expériences arrivent bientôt.</p>;
  }
  return (
    <div>
      <ul>
        {formules.map((f) => (
          <li key={f.id} className="border-b border-[var(--p-border)]">
            <button
              onClick={onContact}
              className="group w-full text-left py-5 md:py-6 grid grid-cols-[1fr_auto] gap-x-4 gap-y-1 items-start"
            >
              <div className="min-w-0">
                <p className="font-heading text-lg md:text-xl text-[var(--p-text)] flex items-center gap-2">
                  {f.nom}
                  {f.populaire && (
                    <span className="text-[9px] font-bold uppercase tracking-[0.25em] border border-[var(--p-border-strong)] rounded-full px-2 py-0.5 text-[var(--p-muted)]">
                      Signature
                    </span>
                  )}
                </p>
                {f.ambiance && (
                  <p className="mt-1 text-xs md:text-sm text-[var(--p-muted)] leading-relaxed max-w-xl">{f.ambiance}</p>
                )}
                {(f.details || []).length > 0 && (
                  <p className="mt-1.5 text-[11px] text-[var(--p-faint)]">{f.details.join(" · ")}</p>
                )}
              </div>
              <div className="flex items-start gap-4 text-right">
                <div>
                  <p className="font-heading text-lg md:text-xl text-[var(--p-text)] whitespace-nowrap">{f.prix}</p>
                  {f.duree && <p className="text-[11px] text-[var(--p-muted)] whitespace-nowrap">{f.duree}</p>}
                </div>
                <ArrowUpRight className="h-4 w-4 mt-1 text-[var(--p-muted)] transition-transform duration-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 group-hover:text-[var(--p-text)]" />
              </div>
            </button>
          </li>
        ))}
      </ul>
      <p className="mt-6 text-xs text-[var(--p-muted)]">
        Tarifs indicatifs — chaque prestation fait l'objet d'un devis personnalisé (frais de déplacement en sus selon le lieu).
      </p>
    </div>
  );
}