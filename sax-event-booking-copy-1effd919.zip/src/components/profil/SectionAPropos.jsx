import React from "react";
import TimelineVie from "@/components/profil/TimelineVie";

export default function SectionAPropos({ aPropos }) {
  if (!aPropos || (!aPropos.paragraphes?.length && !aPropos.valeurs?.length && !aPropos.jalons?.length)) {
    return <p className="text-center text-[var(--p-muted)] py-12">Le contenu « À propos » arrive bientôt.</p>;
  }

  const [premier, ...suite] = aPropos.paragraphes || [];

  return (
    <div className="space-y-12">
      <div className="grid grid-cols-1 md:grid-cols-5 gap-8 md:gap-12 items-start">
        {aPropos.photoUrl && (
          <img
            src={aPropos.photoUrl}
            alt="Portrait de l'artiste"
            className="md:col-span-2 rounded-2xl object-cover w-full aspect-[3/4] shadow-2xl"
          />
        )}
        <div className={aPropos.photoUrl ? "md:col-span-3" : "md:col-span-5"}>
          {premier && (
            <p className="font-heading text-xl md:text-2xl leading-relaxed text-[var(--p-text)]">
              {premier}
            </p>
          )}
          <div className="mt-6 space-y-5">
            {suite.map((p, i) => (
              <p key={i} className="text-sm md:text-base text-[var(--p-text-soft)] leading-relaxed">{p}</p>
            ))}
          </div>
        </div>
      </div>

      {aPropos.valeurs?.length > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-10 gap-y-8 border-t border-[var(--p-border)] pt-10">
          {aPropos.valeurs.map((v, i) => (
            <div key={i}>
              <p className="text-xs font-bold uppercase tracking-[0.25em] text-[var(--p-accent)]">{v.titre}</p>
              <p className="mt-2.5 text-sm text-[var(--p-text-soft)] leading-relaxed">{v.texte}</p>
            </div>
          ))}
        </div>
      )}

      <TimelineVie jalons={aPropos.jalons} />
    </div>
  );
}