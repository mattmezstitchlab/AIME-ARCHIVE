import React, { useState } from "react";
import LightboxGalerie from "@/components/profil/LightboxGalerie";

// Survol coloré : chaque case révèle une couleur vive de la palette de la plateforme.
const COULEURS_SURVOL = ["#FF2D78", "#5E5CE6", "#12A150", "#7B2FF2", "#0A84FF", "#E4572E"];

export default function SectionGalerie({ medias, mode = "grille" }) {
  const [ouvert, setOuvert] = useState(null);

  if (!medias?.length) {
    return <p className="text-center text-[var(--p-muted)] py-12">La galerie arrive bientôt.</p>;
  }

  const Vignette = ({ m, index, className, imgClassName }) => (
    <button
      type="button"
      onClick={() => setOuvert(index)}
      aria-label={`Agrandir : ${m.legende || "photo de prestation"}`}
      className={`relative group overflow-hidden rounded-xl cursor-zoom-in ${className}`}
    >
      <img
        src={m.url}
        alt={m.legende || "Photo de prestation"}
        loading="lazy"
        className={`transition-transform duration-500 group-hover:scale-105 ${imgClassName}`}
      />
      <span
        className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 mix-blend-multiply"
        style={{ backgroundColor: `${COULEURS_SURVOL[index % COULEURS_SURVOL.length]}66` }}
        aria-hidden="true"
      />
      {m.legende && (
        <span className="absolute inset-x-0 bottom-0 px-3 pb-2.5 text-[11px] font-medium text-white opacity-0 group-hover:opacity-100 transition-opacity text-left">
          {m.legende}
        </span>
      )}
    </button>
  );

  return (
    <>
      {mode === "mosaique" ? (
        <div className="columns-2 md:columns-3 gap-2 [&>*]:mb-2">
          {medias.map((m, index) => (
            <Vignette key={m.id} m={m} index={index} className="block w-full break-inside-avoid" imgClassName="w-full h-auto" />
          ))}
        </div>
      ) : mode === "pellicule" ? (
        <div className="flex gap-3 overflow-x-auto pb-3 snap-x snap-mandatory -mx-1 px-1">
          {medias.map((m, index) => (
            <Vignette key={m.id} m={m} index={index} className="shrink-0 snap-center h-64 md:h-80" imgClassName="h-full w-auto object-cover" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-3 md:grid-cols-4 gap-1.5 md:gap-2">
          {medias.map((m, index) => (
            <Vignette key={m.id} m={m} index={index} className="aspect-square" imgClassName="h-full w-full object-cover" />
          ))}
        </div>
      )}
      {ouvert !== null && (
        <LightboxGalerie medias={medias} index={ouvert} onFermer={() => setOuvert(null)} onChanger={setOuvert} />
      )}
    </>
  );
}