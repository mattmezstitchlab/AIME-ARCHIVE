import React from "react";
import { MapPin, Music } from "lucide-react";

const COUVERTURE_DEFAUT =
  "https://media.base44.com/images/public/6a565bd0fa77bad71effd919/14695ecff_generated_image.png";

export default function EnTeteProfil({ profil, photoSecours, onContact }) {
  const nom = profil?.nomAffiche || "Profil";
  const sousTitre = profil?.sousTitre || "";
  const accroche = profil?.accroche || "";
  const photo = profil?.photoProfilUrl || photoSecours;
  const couverture = profil?.couvertureUrl || COUVERTURE_DEFAUT;

  return (
    <header className="relative bg-[var(--p-surface)] border-b border-[var(--p-border)] transition-colors duration-500">
      <div
        className="h-40 md:h-56 bg-cover bg-center"
        style={{ backgroundImage: `url(${couverture})` }}
        aria-hidden="true"
      />
      <div className="max-w-4xl mx-auto px-4 md:px-6 pb-6">
        <div className="flex flex-col md:flex-row md:items-end gap-4 -mt-12 md:-mt-16">
          <div className="h-24 w-24 md:h-32 md:w-32 rounded-full border-4 border-[var(--p-surface)] shadow-lg bg-[var(--p-bg)] overflow-hidden shrink-0">
            {photo ? (
              <img src={photo} alt={nom} className="h-full w-full object-cover" />
            ) : (
              <div className="h-full w-full flex items-center justify-center">
                <Music className="h-10 w-10 text-[var(--p-accent)]" />
              </div>
            )}
          </div>
          <div className="flex-1 md:pb-1">
            <h1 className="font-heading text-3xl md:text-4xl text-[var(--p-text)]">{nom}</h1>
            <p className="text-[11px] md:text-xs font-bold uppercase tracking-[0.3em] text-[var(--p-accent)] mt-1.5">
              {sousTitre}
            </p>
            <p className="flex items-center gap-1.5 text-sm text-[var(--p-muted)] mt-2">
              <MapPin className="h-3.5 w-3.5" /> {accroche}
            </p>
          </div>
          <div className="flex flex-wrap gap-2 md:pb-1">
            <button
              onClick={onContact}
              className="h-9 px-4 rounded-full bg-[var(--p-cta)] text-[var(--p-cta-text)] text-xs font-bold hover:bg-[var(--p-cta-hover)] transition-colors"
            >
              Vérifier les disponibilités
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}