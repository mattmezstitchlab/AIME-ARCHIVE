import React, { useState, useEffect } from "react";
import { ChevronDown } from "lucide-react";
import SectionAPropos from "@/components/profil/SectionAPropos";
import SectionGalerie from "@/components/profil/SectionGalerie";
import SectionRepertoire from "@/components/profil/SectionRepertoire";
import SectionTarifs from "@/components/profil/SectionTarifs";
import SectionTemoignages from "@/components/profil/SectionTemoignages";
import SectionFaq from "@/components/profil/SectionFaq";
import SectionContact from "@/components/profil/SectionContact";
import SectionIntermittent from "@/components/profil/SectionIntermittent";
import ApparitionScroll from "@/components/profil/ApparitionScroll";
import sectionsVides from "@/lib/sectionsProfil";

// Sections repliées par défaut, dépliables au clic — à partir de « La scène en images ».
const DEPLIABLES = ["galerie", "repertoire", "tarifs", "avis", "faq"];

export default function ProfilPageUnique({ contenu, onContact }) {
  // Les sections sans contenu sont masquées automatiquement.
  const masquees = [...(contenu.profil?.sectionsMasquees || []), ...sectionsVides(contenu)];
  const immersif = contenu.profil?.styleMiniSite === "immersif";
  const classeBloc = immersif ? "rounded-3xl border border-white/10 bg-[#111114]/90 p-5 shadow-xl backdrop-blur-xl md:p-8" : "";
  const [ouvertes, setOuvertes] = useState([]);

  // La barre d'ancres demande l'ouverture d'une section avant d'y défiler.
  useEffect(() => {
    const ouvrir = (e) => {
      const cle = e.detail;
      if (DEPLIABLES.includes(cle)) setOuvertes((o) => (o.includes(cle) ? o : [...o, cle]));
    };
    window.addEventListener("ouvrir-section-profil", ouvrir);
    return () => window.removeEventListener("ouvrir-section-profil", ouvrir);
  }, []);

  const basculer = (cle) =>
    setOuvertes((o) => (o.includes(cle) ? o.filter((c) => c !== cle) : [...o, cle]));

  const sections = [
    ["apropos", "L'artiste", "À propos", <SectionAPropos aPropos={contenu.aPropos} />],
    ...(contenu.intermittent ? [["intermittent", "Statut professionnel", "Intermittent du spectacle", <SectionIntermittent infos={contenu.intermittent} />]] : []),
    ["galerie", "En images", "La scène en images", <SectionGalerie medias={contenu.medias} mode={contenu.profil?.modeGalerie || "grille"} />],
    ["repertoire", "Répertoire", "Une ambiance pour chaque moment", <SectionRepertoire styles={contenu.styles} />],
    ["tarifs", "Expériences", "Vivez votre moment", <SectionTarifs formules={contenu.formules} onContact={onContact} />],
    ["avis", "Avis", "Ils m'ont fait confiance", <SectionTemoignages proprietaire={contenu.profil?.slug} />],
    ["faq", "Questions", "Questions fréquentes", <SectionFaq questions={contenu.questions} />],
  ].filter(([cle]) => !masquees.includes(cle));

  // Ordre des modules choisi dans l'éditeur de mini-site.
  const ordre = contenu.profil?.ordreSections || [];
  if (ordre.length > 0) {
    sections.sort((a, b) => (ordre.indexOf(a[0]) + 1 || 99) - (ordre.indexOf(b[0]) + 1 || 99));
  }

  return (
    <div className={immersif ? "space-y-8 md:space-y-12" : "space-y-20 md:space-y-28"}>
      {sections.map(([cle, overline, titre, composant]) => {
        const depliable = DEPLIABLES.includes(cle);
        const ouverte = !depliable || ouvertes.includes(cle);
        return (
          <section key={cle} id={`section-${cle}`} className={`scroll-mt-32 ${classeBloc}`}>
            <ApparitionScroll>
              {/* En-tête éditorial : filet fin + titre sobre, libellé discret à droite */}
              {depliable ? (
                <button
                  type="button"
                  onClick={() => basculer(cle)}
                  aria-expanded={ouverte}
                  className={`w-full border-t border-[var(--p-border-strong)] pt-5 flex items-baseline justify-between gap-4 text-left group ${ouverte ? "mb-10" : "mb-0"}`}
                >
                  <h2 className="font-heading text-2xl md:text-3xl text-[var(--p-text)] inline-flex items-center gap-3">
                    {titre}
                    <ChevronDown
                      aria-hidden="true"
                      className={`h-5 w-5 text-[var(--p-muted)] transition-transform group-hover:text-[var(--p-text)] ${ouverte ? "rotate-180" : ""}`}
                    />
                  </h2>
                  <p className="text-[10px] font-bold uppercase tracking-[0.3em] text-[var(--p-muted)] shrink-0">{overline}</p>
                </button>
              ) : (
                <div className="border-t border-[var(--p-border-strong)] pt-5 mb-10 flex items-baseline justify-between gap-4">
                  <h2 className="font-heading text-2xl md:text-3xl text-[var(--p-text)]">{titre}</h2>
                  <p className="text-[10px] font-bold uppercase tracking-[0.3em] text-[var(--p-muted)] shrink-0">{overline}</p>
                </div>
              )}
              {ouverte && composant}
            </ApparitionScroll>
          </section>
        );
      })}
      <section id="section-contact" className={`scroll-mt-32 ${classeBloc}`}>
        <ApparitionScroll>
          <div className="border-t border-[var(--p-border-strong)] pt-5 mb-10 flex items-baseline justify-between gap-4">
            <h2 className="font-heading text-2xl md:text-3xl text-[var(--p-text)]">Contact</h2>
            <p className="text-[10px] font-bold uppercase tracking-[0.3em] text-[var(--p-muted)] shrink-0">Vérifier une date</p>
          </div>
          <SectionContact
            datesIndisponibles={contenu.datesIndisponibles}
            proprietaire={contenu.profil?.slug}
            creneauxReserves={contenu.creneauxReserves || {}}
            villePrestataire={contenu.profil?.ville}
            datesSousOption={contenu.datesSousOption || []}
            creneauxHebdo={contenu.reservationDirecte ? contenu.creneauxHebdo || [] : []}
            calendrierConfigure={contenu.calendrierConfigure}
          />
        </ApparitionScroll>
      </section>

    </div>
  );
}