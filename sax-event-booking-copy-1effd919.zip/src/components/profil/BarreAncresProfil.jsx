import React, { useEffect, useState } from "react";

// Barre d'ancres collante : navigation douce vers les sections de la page profil.
export default function BarreAncresProfil({ ancres }) {
  const [active, setActive] = useState(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) setActive(entry.target.id.replace("section-", ""));
        });
      },
      { rootMargin: "-20% 0px -70% 0px" }
    );
    ancres.forEach(([cle]) => {
      const el = document.getElementById(`section-${cle}`);
      if (el) observer.observe(el);
    });
    return () => observer.disconnect();
  }, [ancres]);

  const aller = (cle) => {
    // Demande à la page de déplier la section avant d'y défiler.
    window.dispatchEvent(new CustomEvent("ouvrir-section-profil", { detail: cle }));
    requestAnimationFrame(() => {
      document.getElementById(`section-${cle}`)?.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  };

  return (
    <nav
      aria-label="Sections du profil"
      className="sticky top-14 z-30 bg-[var(--p-nav-bg)] backdrop-blur-xl border-b border-[var(--p-border)]"
    >
      <div className="max-w-4xl mx-auto px-4 md:px-6 overflow-x-auto scrollbar-none">
        <div className="flex items-center gap-1 py-2 w-max mx-auto">
          {ancres.map(([cle, libelle]) => (
            <button
              key={cle}
              onClick={() => aller(cle)}
              aria-current={active === cle ? "true" : undefined}
              className={`min-h-[38px] px-3.5 rounded-full text-[13px] font-semibold whitespace-nowrap transition-colors ${
                active === cle
                  ? "bg-[var(--p-cta)] text-[var(--p-cta-text)]"
                  : "text-[var(--p-muted)] hover:text-[var(--p-text)]"
              }`}
            >
              {libelle}
            </button>
          ))}
        </div>
      </div>
    </nav>
  );
}