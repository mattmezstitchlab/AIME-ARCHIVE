import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { BadgeCheck, Loader2, Check } from "lucide-react";

// Bandeau affiché sur les profils de démonstration : le prestataire concerné
// peut revendiquer sa page et en devenir propriétaire.
export default function BandeauRevendication({ slug }) {
  const [connecte, setConnecte] = useState(null);
  const [etat, setEtat] = useState("idle"); // idle | encours | fait | erreur

  useEffect(() => {
    base44.auth.isAuthenticated().then(setConnecte).catch(() => setConnecte(false));
  }, []);

  const revendiquer = async () => {
    if (etat !== "idle") return;
    setEtat("encours");
    try {
      await base44.functions.invoke("revendiquerProfil", { slug });
      setEtat("fait");
      setTimeout(() => { window.location.href = "/compte"; }, 1500);
    } catch (_e) {
      setEtat("erreur");
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 md:px-6 mt-6">
      <div className="rounded-2xl border border-[var(--p-border-strong)] bg-[var(--p-surface)] px-5 py-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <BadgeCheck className="h-5 w-5 text-[var(--p-gold)] shrink-0" aria-hidden="true" />
          <p className="text-sm text-[var(--p-text-soft)]">
            <span className="font-semibold text-[var(--p-text)]">Cette page est à revendiquer.</span>{" "}
            C'est votre activité ? Prenez-en les commandes.
          </p>
        </div>
        {etat === "fait" ? (
          <p className="inline-flex items-center gap-2 text-sm font-semibold text-emerald-600">
            <Check className="h-4 w-4" /> Profil revendiqué — ouverture de votre espace…
          </p>
        ) : connecte ? (
          <button
            type="button"
            onClick={revendiquer}
            disabled={etat === "encours"}
            className="inline-flex items-center gap-2 min-h-[40px] px-5 rounded-full bg-[var(--p-cta)] text-[var(--p-cta-text)] text-xs font-bold hover:bg-[var(--p-cta-hover)] disabled:opacity-60 transition-colors"
          >
            {etat === "encours" && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
            Revendiquer ce profil
          </button>
        ) : connecte === false ? (
          <p className="text-xs text-[var(--p-muted)]">
            <Link to="/register" className="font-bold underline text-[var(--p-text)]">Créez votre compte</Link>
            {" "}puis revenez sur cette page pour la revendiquer.
          </p>
        ) : null}
        {etat === "erreur" && (
          <p className="w-full text-xs text-[var(--p-error)]" role="alert">
            La revendication a échoué — ce profil a peut-être déjà été repris. Réessayez ou contactez-nous.
          </p>
        )}
      </div>
    </div>
  );
}