import React, { useState } from "react";

// Timeline horizontale et interactive des repères de vie : cliquez un repère pour le mettre en lumière.
export default function TimelineVie({ jalons }) {
  const [actif, setActif] = useState(0);

  if (!jalons?.length) return null;
  const jalonActif = jalons[Math.min(actif, jalons.length - 1)];

  return (
    <div className="border-t border-[var(--p-border)] pt-10">
      <p className="text-xs font-bold uppercase tracking-[0.25em] text-[var(--p-accent)] mb-8">Parcours</p>

      <div className="overflow-x-auto pb-2 -mx-1 px-1">
        <div className="relative flex gap-12 min-w-max pt-3 pb-1" role="tablist" aria-label="Repères de vie">
          <div className="absolute left-0 right-0 top-[6px] h-px bg-[var(--p-border-strong)]" aria-hidden="true" />
          {jalons.map((j, i) => {
            const estActif = i === actif;
            return (
              <button
                key={i}
                type="button"
                role="tab"
                aria-selected={estActif}
                onClick={() => setActif(i)}
                className="relative shrink-0 text-left group"
              >
                <span
                  aria-hidden="true"
                  className={`absolute -top-3 left-0 rounded-full transition-all duration-300 ${
                    estActif ? "h-[13px] w-[13px] bg-[var(--p-text)]" : "h-[7px] w-[7px] mt-[3px] bg-[var(--p-border-strong)] group-hover:bg-[var(--p-muted)]"
                  }`}
                />
                <span className={`block mt-4 font-heading transition-all duration-300 ${
                  estActif ? "text-3xl md:text-4xl text-[var(--p-text)]" : "text-xl text-[var(--p-muted)] group-hover:text-[var(--p-text)]"
                }`}>
                  {j.annee}
                </span>
                <span className={`block mt-1 text-xs font-semibold uppercase tracking-wide transition-colors ${
                  estActif ? "text-[var(--p-text)]" : "text-[var(--p-faint)]"
                }`}>
                  {j.titre}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Détail du repère sélectionné */}
      <div className="mt-6 max-w-xl" role="tabpanel">
        <p className="font-heading text-lg md:text-xl text-[var(--p-text)]">
          {jalonActif.annee}{jalonActif.titre ? ` — ${jalonActif.titre}` : ""}
        </p>
        {jalonActif.texte && (
          <p className="mt-2 text-sm md:text-base text-[var(--p-text-soft)] leading-relaxed">{jalonActif.texte}</p>
        )}
      </div>
    </div>
  );
}