import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Loader2, Timer, Check } from "lucide-react";

const classeInput =
  "min-h-[44px] w-full rounded-lg border border-[var(--p-border-strong)] bg-[var(--p-surface)] px-3 text-sm text-[var(--p-text)] placeholder:text-[var(--p-faint)] focus:outline-none focus:border-[var(--p-accent)]";

// Pose d'une option gratuite de 48 h sur une date libre, sans engagement.
export default function OptionDate48({ proprietaire, date }) {
  const [ouvert, setOuvert] = useState(false);
  const [nom, setNom] = useState("");
  const [email, setEmail] = useState("");
  const [telephone, setTelephone] = useState("");
  const [envoi, setEnvoi] = useState(false);
  const [fait, setFait] = useState(null);
  const [erreur, setErreur] = useState("");

  const poser = async (ev) => {
    ev.preventDefault();
    if (!nom.trim() || !email.trim()) return;
    setEnvoi(true);
    setErreur("");
    try {
      const res = await base44.functions.invoke("poserOption", {
        proprietaire, date, nom: nom.trim(), email: email.trim(), telephone: telephone.trim(),
      });
      setFait(res.data?.expireLe || true);
    } catch (err) {
      setErreur(err?.response?.data?.error || "Impossible de poser l'option pour le moment.");
    } finally {
      setEnvoi(false);
    }
  };

  if (fait) {
    return (
      <p className="w-full max-w-md flex items-start gap-2.5 rounded-2xl border border-[var(--p-border)] bg-[var(--p-surface)] px-4 py-3 text-sm text-[var(--p-text-soft)]">
        <Check className="h-4 w-4 shrink-0 mt-0.5 text-[var(--p-accent)]" aria-hidden="true" />
        Option posée pour 48 h ! Le prestataire est prévenu et vous garde la priorité sur cette date
        {typeof fait === "string" ? ` jusqu'au ${new Date(fait).toLocaleString("fr-FR")}` : ""}.
      </p>
    );
  }

  if (!ouvert) {
    return (
      <button
        type="button"
        onClick={() => setOuvert(true)}
        className="inline-flex items-center gap-2 text-sm text-[var(--p-muted)] underline hover:text-[var(--p-text)] min-h-[40px]"
      >
        <Timer className="h-4 w-4" /> Poser une option gratuite de 48 h sur cette date
      </button>
    );
  }

  return (
    <form onSubmit={poser} className="w-full max-w-md rounded-2xl border border-[var(--p-border)] bg-[var(--p-surface)] p-4 space-y-3">
      <p className="text-sm text-[var(--p-text-soft)]">
        <strong className="text-[var(--p-text)]">Option 48 h</strong> — sans engagement : le prestataire vous garde la priorité sur cette date pendant deux jours.
      </p>
      <input aria-label="Votre nom" autoComplete="name" value={nom} onChange={(e) => setNom(e.target.value)} placeholder="Votre nom" required className={classeInput} />
      <input aria-label="Votre adresse e-mail" type="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Votre e-mail" required className={classeInput} />
      <input aria-label="Téléphone facultatif" type="tel" autoComplete="tel" value={telephone} onChange={(e) => setTelephone(e.target.value)} placeholder="Téléphone (facultatif)" className={classeInput} />
      {erreur && <p className="text-sm text-[var(--p-error)]">{erreur}</p>}
      <div className="flex gap-2">
        <button
          type="submit"
          disabled={envoi || !nom.trim() || !email.trim()}
          className="min-h-[44px] px-5 rounded-full bg-[var(--p-cta)] text-[var(--p-cta-text)] text-sm font-bold hover:bg-[var(--p-cta-hover)] disabled:opacity-40 inline-flex items-center gap-2"
        >
          {envoi ? <Loader2 className="h-4 w-4 animate-spin" /> : <Timer className="h-4 w-4" />} Poser l'option
        </button>
        <button type="button" onClick={() => setOuvert(false)} className="min-h-[44px] px-3 text-sm text-[var(--p-muted)] hover:text-[var(--p-text)]">
          Annuler
        </button>
      </div>
    </form>
  );
}