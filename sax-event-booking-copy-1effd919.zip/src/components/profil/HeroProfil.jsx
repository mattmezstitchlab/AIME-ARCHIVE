import React from "react";
import { ChevronDown, BadgeCheck, MapPin } from "lucide-react";

const COUVERTURE_DEFAUT =
  "https://media.base44.com/images/public/6a565bd0fa77bad71effd919/14695ecff_generated_image.png";

export default function HeroProfil({ profil, onContact, badge }) {
  const couverture = profil?.couvertureUrl || COUVERTURE_DEFAUT;

  return (
    <header className="relative min-h-[92vh] flex flex-col bg-black">
      <img
        src={couverture}
        alt=""
        className="absolute inset-0 h-full w-full object-cover"
        aria-hidden="true"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/25 to-black/45" aria-hidden="true" />

      {/* L'artiste d'abord — le header du site est affiché par la page */}
      <div className="relative z-10 flex-1 flex flex-col items-center justify-end text-center px-6 pb-28">
        {profil?.photoProfilUrl && (
          <img
            src={profil.photoProfilUrl}
            alt={`Photo de profil de ${profil?.nomAffiche || "l'artiste"}`}
            className="h-24 w-24 md:h-28 md:w-28 rounded-full object-cover ring-2 ring-white/70 shadow-2xl mb-6"
          />
        )}
        {badge && (
          <span className="mb-4 inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-black/30 backdrop-blur-md text-white/85 text-[11px] font-semibold tracking-wide">
            <BadgeCheck className="h-3.5 w-3.5" aria-hidden="true" /> {badge}
          </span>
        )}
        {profil?.sousTitre && (
          <p className="text-[11px] md:text-xs font-bold uppercase tracking-[0.4em] text-white/80">
            {profil.sousTitre}
          </p>
        )}
        <h1 className="font-heading text-5xl md:text-7xl lg:text-8xl text-white mt-4 drop-shadow-[0_2px_24px_rgba(0,0,0,0.45)]">
          {profil?.nomAffiche || ""}
        </h1>
        {profil?.ville && (
          <p className="mt-3 inline-flex items-center gap-1.5 text-sm text-white/80">
            <MapPin className="h-4 w-4" aria-hidden="true" /> {profil.ville}
          </p>
        )}
        {profil?.accroche && (
          <p className="mt-5 text-sm md:text-base text-white/85 max-w-xl leading-relaxed">
            {profil.accroche}
          </p>
        )}
        <button
          onClick={onContact}
          className="mt-9 min-h-[52px] px-9 rounded-full bg-white text-[#1D1D1F] text-sm md:text-base font-bold tracking-wide hover:bg-white/90 transition-colors shadow-xl"
        >
          Vérifier ma date
        </button>
      </div>

      <ChevronDown
        className="absolute bottom-6 left-1/2 -translate-x-1/2 h-6 w-6 text-white/60 animate-bounce z-10"
        aria-hidden="true"
      />
    </header>
  );
}