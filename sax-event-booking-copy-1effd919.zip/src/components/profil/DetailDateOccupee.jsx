import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Clock, Car, Loader2, CalendarDays, BellRing, Check } from "lucide-react";

const formaterMinutes = (min) => (min >= 60 ? `${Math.floor(min / 60)} h ${String(min % 60).padStart(2, "0")}` : `${min} min`);
const formaterDate = (cle) =>
  new Date(`${cle}T12:00:00`).toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long" });

// Détail d'une date déjà prise : créneaux réservés, temps de route estimé, dates libres proches.
export default function DetailDateOccupee({ date, creneaux = [], villeReference, datesIndisponibles = [], onChoisirDate, proprietaire }) {
  const [ville, setVille] = useState("");
  const [calcul, setCalcul] = useState(false);
  const [route, setRoute] = useState(null);
  const [erreur, setErreur] = useState("");
  const [emailAlerte, setEmailAlerte] = useState("");
  const [alerteEnvoi, setAlerteEnvoi] = useState(false);
  const [alerteFaite, setAlerteFaite] = useState(false);

  const poserAlerte = async (ev) => {
    ev.preventDefault();
    if (!emailAlerte.trim()) return;
    setAlerteEnvoi(true);
    try {
      await base44.functions.invoke("alerteDate", { proprietaire, date, email: emailAlerte.trim() });
      setAlerteFaite(true);
    } finally {
      setAlerteEnvoi(false);
    }
  };

  const villeDepart = creneaux.find((c) => c.ville)?.ville || villeReference || "";
  const minDebut = creneaux.map((c) => c.heureDebut).filter(Boolean).sort()[0];
  const maxFin = creneaux.map((c) => c.heureFin).filter(Boolean).sort().pop();

  // Dates libres les plus proches, avant et après.
  const indispo = new Set(datesIndisponibles);
  const aujourdHui = new Date().toISOString().slice(0, 10);
  const proches = [];
  for (let delta = 1; delta <= 21 && proches.length < 4; delta++) {
    for (const signe of [-1, 1]) {
      const d = new Date(`${date}T12:00:00`);
      d.setDate(d.getDate() + delta * signe);
      const cle = d.toISOString().slice(0, 10);
      if (cle >= aujourdHui && !indispo.has(cle) && !proches.includes(cle) && proches.length < 4) proches.push(cle);
    }
  }
  proches.sort();

  const estimer = async (ev) => {
    ev.preventDefault();
    if (!ville.trim() || !villeDepart) return;
    setCalcul(true); setErreur(""); setRoute(null);
    try {
      const res = await base44.functions.invoke("tempsRoute", { depart: villeDepart, arrivee: ville.trim() });
      setRoute(res.data);
    } catch (_e) {
      setErreur("Impossible d'estimer le trajet pour le moment.");
    } finally {
      setCalcul(false);
    }
  };

  return (
    <div className="rounded-2xl border border-[var(--p-border)] bg-[var(--p-surface)] shadow-sm p-6 space-y-5">
      <p className="font-heading text-lg text-[var(--p-text)] capitalize">{formaterDate(date)}</p>

      {creneaux.length > 0 ? (
        <div className="space-y-2">
          {creneaux.map((c, i) => (
            <p key={i} className="flex items-center gap-2 text-sm text-[var(--p-text-soft)]">
              <Clock className="h-4 w-4 text-[var(--p-accent)] shrink-0" />
              Prestation réservée{c.heureDebut ? ` de ${c.heureDebut} à ${c.heureFin || "?"}` : ""}{c.ville ? ` — ${c.ville}` : ""}
            </p>
          ))}
          {minDebut && (
            <p className="text-sm text-[var(--p-muted)]">
              Selon votre horaire, un créneau reste envisageable <strong className="text-[var(--p-text)]">avant {minDebut}</strong>
              {maxFin ? <> ou <strong className="text-[var(--p-text)]">après {maxFin}</strong></> : null} — indiquez votre ville pour vérifier la faisabilité.
            </p>
          )}
        </div>
      ) : (
        <p className="text-sm text-[var(--p-muted)]">Cette journée est indisponible (agenda bloqué).</p>
      )}

      {creneaux.length > 0 && villeDepart && (
        <form onSubmit={estimer} className="space-y-2">
          <label htmlFor="ville-trajet" className="text-xs font-bold uppercase tracking-wide text-[var(--p-accent)]">
            Où se déroulerait votre événement ?
          </label>
          <div className="flex gap-2">
            <input
              id="ville-trajet"
              value={ville}
              onChange={(e) => setVille(e.target.value)}
              placeholder="Votre ville"
              className="flex-1 min-h-[44px] rounded-lg border border-[var(--p-border-strong)] bg-[var(--p-surface)] px-3 text-sm text-[var(--p-text)] placeholder:text-[var(--p-faint)] focus:outline-none focus:border-[var(--p-accent)]"
            />
            <button
              type="submit"
              disabled={calcul || !ville.trim()}
              className="min-h-[44px] px-4 rounded-full bg-[var(--p-cta)] text-[var(--p-cta-text)] text-xs font-bold hover:bg-[var(--p-cta-hover)] disabled:opacity-40 inline-flex items-center gap-1.5"
            >
              {calcul ? <Loader2 className="h-4 w-4 animate-spin" /> : <><Car className="h-4 w-4" /> Estimer</>}
            </button>
          </div>
          {route && (
            <p className="flex items-center gap-2 text-sm text-[var(--p-text)]">
              <Car className="h-4 w-4 text-[var(--p-accent)] shrink-0" />
              ≈ <strong>{formaterMinutes(route.minutes)}</strong> de route depuis {villeDepart}
              {route.distanceKm ? ` (${Math.round(route.distanceKm)} km)` : ""} — à prendre en compte entre les deux prestations.
            </p>
          )}
          {erreur && <p className="text-sm text-[var(--p-error)]">{erreur}</p>}
        </form>
      )}

      {proprietaire && (
        <div className="space-y-2">
          <p className="text-xs font-bold uppercase tracking-wide text-[var(--p-accent)]">Cette date vous tient à cœur ?</p>
          {alerteFaite ? (
            <p className="flex items-center gap-2 text-sm text-[var(--p-text)]">
              <Check className="h-4 w-4 text-[var(--p-accent)] shrink-0" /> C'est noté : vous serez prévenu(e) par e-mail si elle se libère.
            </p>
          ) : (
            <form onSubmit={poserAlerte} className="flex gap-2">
              <input
                type="email"
                value={emailAlerte}
                onChange={(e) => setEmailAlerte(e.target.value)}
                placeholder="Votre e-mail"
                aria-label="E-mail pour être alerté si la date se libère"
                className="flex-1 min-h-[44px] rounded-lg border border-[var(--p-border-strong)] bg-[var(--p-surface)] px-3 text-sm text-[var(--p-text)] placeholder:text-[var(--p-faint)] focus:outline-none focus:border-[var(--p-accent)]"
              />
              <button
                type="submit"
                disabled={alerteEnvoi || !emailAlerte.trim()}
                className="min-h-[44px] px-4 rounded-full border border-[var(--p-border-strong)] text-xs font-bold text-[var(--p-text)] hover:bg-[var(--p-bg)] disabled:opacity-40 inline-flex items-center gap-1.5"
              >
                {alerteEnvoi ? <Loader2 className="h-4 w-4 animate-spin" /> : <BellRing className="h-4 w-4" />} M'alerter si elle se libère
              </button>
            </form>
          )}
        </div>
      )}

      {proches.length > 0 && (
        <div className="space-y-2">
          <p className="text-xs font-bold uppercase tracking-wide text-[var(--p-accent)]">Dates libres les plus proches</p>
          <div className="flex flex-wrap gap-2">
            {proches.map((cle) => (
              <button
                key={cle}
                type="button"
                onClick={() => onChoisirDate(cle)}
                className="inline-flex items-center gap-1.5 min-h-[40px] px-3.5 rounded-full border border-[var(--p-border-strong)] text-xs font-semibold text-[var(--p-text)] hover:bg-[var(--p-bg)] transition-colors capitalize"
              >
                <CalendarDays className="h-3.5 w-3.5 text-[var(--p-accent)]" /> {formaterDate(cle)}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}