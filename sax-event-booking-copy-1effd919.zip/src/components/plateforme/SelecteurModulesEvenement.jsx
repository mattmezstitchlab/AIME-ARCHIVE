import React from "react";
import { Link } from "react-router-dom";
import { Check, CircleDot, House, Music, Radio, UtensilsCrossed } from "lucide-react";
import { MODULES_EVENEMENT } from "@/lib/eventModeConfig";

const ICONES = { cadran: CircleDot, jourj: Radio, playlist: Music, table: UtensilsCrossed };
const classeLien = "flex min-h-[44px] items-center gap-3 rounded-xl px-3 text-sm font-semibold text-white/70 transition-colors hover:bg-white/10 hover:text-white focus-visible:ring-2 focus-visible:ring-[#BF5AF2]";

export default function SelecteurModulesEvenement({ evenementId, moduleActif, panneauOuvert, onChoisir }) {
  const base = `/compte?evenement=${encodeURIComponent(evenementId)}&studio=${moduleActif}`;
  return <div className="absolute bottom-[calc(100%+0.75rem)] left-1/2 max-h-[min(70vh,520px)] w-[min(320px,calc(100vw-1rem))] -translate-x-1/2 overflow-y-auto rounded-2xl border border-white/10 bg-black/95 p-2 shadow-2xl backdrop-blur-xl" role="menu" aria-label="Explorer l’événement">
    <p className="px-3 pb-2 pt-1 text-[11px] font-bold uppercase tracking-[0.18em] text-white/35">Explorer l’événement</p>
    <Link role="menuitem" onClick={onChoisir} to={`${base}&panneau=apercu`} className={classeLien}><House className="h-4 w-4 text-white" /><span className="flex-1">Accueil de l’événement</span>{panneauOuvert === "apercu" && <Check className="h-4 w-4 text-[#30D158]" />}</Link>
    <div className="my-1 h-px bg-white/10" aria-hidden="true" />
    {Object.entries(MODULES_EVENEMENT).map(([cle, module]) => { const Icone = ICONES[cle]; const actif = cle === moduleActif && !panneauOuvert; return <Link key={cle} role="menuitem" onClick={onChoisir} to={`/compte?evenement=${encodeURIComponent(evenementId)}&studio=${cle}`} className={classeLien}><Icone className="h-4 w-4" style={{ color: module.color }} /><span className="flex-1">{module.label}</span>{actif && <Check className="h-4 w-4 text-[#30D158]" />}</Link>; })}
  </div>;
}