import React, { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { CircleDot, FileText, House, Music, Plus, Radio, Settings, UtensilsCrossed } from "lucide-react";
import MenuAjoutEvenement from "@/components/plateforme/MenuAjoutEvenement";
import MenuFocusEvenement from "@/components/plateforme/MenuFocusEvenement";
import SelecteurModulesEvenement from "@/components/plateforme/SelecteurModulesEvenement";
import { useEventContext } from "@/contexts/EventContext";
import { MODULES_EVENEMENT } from "@/lib/eventModeConfig";

const ICONES = { cadran: CircleDot, jourj: Radio, playlist: Music, table: UtensilsCrossed };
export default function BarreCapsuleEvenement() {
  const { evenementId, evenement, moduleActif, panneauOuvert, actionsDisponibles, impactsCausals } = useEventContext();
  const [menu, setMenu] = useState(null);
  const conteneur = useRef(null), module = MODULES_EVENEMENT[moduleActif], IconeModule = ICONES[moduleActif];
  const base = `/compte?evenement=${encodeURIComponent(evenementId)}&studio=${moduleActif}`;
  const alertesOuvertes = impactsCausals.filter((impact) => ["rouge", "orange"].includes(impact.niveau));
  const alertes = alertesOuvertes.length, premiereAlerte = alertesOuvertes[0];
  const documentsAConfirmer = impactsCausals.some((impact) => impact.id === "documents");
  const focusActif = !panneauOuvert || ["acteurs", "retard", "absence", "meteo"].includes(panneauOuvert);
  const classe = (actif) => `relative flex h-11 w-11 items-center justify-center rounded-full transition-colors focus-visible:ring-2 focus-visible:ring-[#BF5AF2] ${actif ? "bg-white/10 text-white" : "text-white/55 hover:bg-white/5 hover:text-white"}`;
  const ajouter = (action) => { window.dispatchEvent(new CustomEvent("aime-event-ajout", { detail: action })); setMenu(null); };

  useEffect(() => {
    const fermer = (event) => { if (event.key === "Escape" || (event.type === "pointerdown" && !conteneur.current?.contains(event.target))) setMenu(null); };
    document.addEventListener("pointerdown", fermer); document.addEventListener("keydown", fermer);
    return () => { document.removeEventListener("pointerdown", fermer); document.removeEventListener("keydown", fermer); };
  }, []);

  return <div className="fixed bottom-[calc(0.75rem+env(safe-area-inset-bottom))] left-1/2 z-50 -translate-x-1/2 md:bottom-5"><div ref={conteneur} className="relative flex items-center gap-1 rounded-full border border-white/10 bg-black/90 px-2 py-1.5 shadow-[0_8px_40px_rgba(0,0,0,0.55)] backdrop-blur-xl">
    {menu === "explorer" && <SelecteurModulesEvenement evenementId={evenementId} moduleActif={moduleActif} panneauOuvert={panneauOuvert} onChoisir={() => setMenu(null)} />}
    {menu === "focus" && <MenuFocusEvenement evenementId={evenementId} evenement={evenement} moduleActif={moduleActif} panneauOuvert={panneauOuvert} onChoisir={() => setMenu(null)} />}
    {menu === "actions" && <MenuAjoutEvenement actions={actionsDisponibles} onChoisir={ajouter} />}
    <div className="relative h-11 w-11 shrink-0"><button type="button" onClick={() => setMenu(menu === "explorer" ? null : "explorer")} aria-label="Explorer les sections de l’événement" aria-haspopup="menu" aria-expanded={menu === "explorer"} title="Explorer" className={classe(panneauOuvert === "apercu")}><House className="h-[18px] w-[18px]" /></button>{premiereAlerte && <Link to={`${base}&panneau=impact&impact=${encodeURIComponent(premiereAlerte.id)}`} onClick={() => setMenu(null)} aria-label={`Ouvrir le premier point à traiter : ${premiereAlerte.label}`} title={premiereAlerte.label} className="absolute -right-1.5 -top-1.5 z-10 flex h-7 min-w-7 items-center justify-center rounded-full bg-[#FF9F0A] px-1 text-[10px] font-bold leading-none text-black ring-2 ring-black focus-visible:ring-2 focus-visible:ring-white">{Math.min(alertes, 9)}</Link>}</div>
    <button type="button" onClick={() => setMenu(menu === "focus" ? null : "focus")} aria-label={`Choisir un focus dans ${module.label}`} aria-haspopup="menu" aria-expanded={menu === "focus"} title={`Focus : ${module.label}`} className={classe(focusActif)}><IconeModule className="h-[18px] w-[18px]" style={{ color: module.color }} /></button>
    <button type="button" disabled={!actionsDisponibles.length} onClick={() => setMenu(menu === "actions" ? null : "actions")} aria-label="Ajouter dans la section active" aria-haspopup="menu" aria-expanded={menu === "actions"} title="Agir ici" className="relative -my-2 flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-[#FF2D78] via-[#BF5AF2] to-[#0A84FF] shadow-[0_4px_20px_rgba(191,90,242,0.45)] transition-transform hover:scale-105 focus-visible:ring-2 focus-visible:ring-white disabled:cursor-not-allowed disabled:opacity-40"><Plus className="h-5 w-5 text-white" /></button>
    <Link to={`${base}&panneau=documents`} onClick={() => setMenu(null)} aria-label={`Documents de l’événement${documentsAConfirmer ? ", contrat à confirmer" : ""}`} aria-current={panneauOuvert === "documents" ? "page" : undefined} title="Documents" className={classe(panneauOuvert === "documents")}><FileText className="h-[18px] w-[18px]" />{documentsAConfirmer && <span aria-hidden="true" className="absolute right-0.5 top-0.5 h-2 w-2 rounded-full bg-[#FF9F0A] ring-2 ring-black" />}</Link>
    <Link to={`${base}&panneau=reglages`} onClick={() => setMenu(null)} aria-label="Gouverner l’événement" aria-current={panneauOuvert === "reglages" ? "page" : undefined} title="Gouverner" className={classe(panneauOuvert === "reglages")}><Settings className="h-[18px] w-[18px]" /></Link>
  </div></div>;
}