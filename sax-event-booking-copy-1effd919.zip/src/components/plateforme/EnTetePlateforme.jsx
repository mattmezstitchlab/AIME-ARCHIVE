import React from "react";
import { Link } from "react-router-dom";

export default function EnTetePlateforme({ sombre = false }) {
  return (
    <header className={`sticky top-0 z-40 border-b border-white/10 backdrop-blur-xl ${sombre ? "bg-black/60" : "bg-black/80"}`}>
      <div className="max-w-5xl mx-auto px-4 md:px-6 h-14 flex items-center">
        <Link to="/" className="flex items-center gap-2 text-lg text-white">
          <span
            aria-hidden="true"
            className="h-6 w-6 rounded-full shrink-0"
            style={{ backgroundImage: "linear-gradient(135deg, #FF9F0A 0%, #FF2D78 30%, #BF5AF2 55%, #0A84FF 78%, #64D2FF 100%)" }}
          />
          <span className="font-semibold tracking-tight">
            Aime{" "}
            <span
              className="font-light"
              style={{
                backgroundImage: "linear-gradient(100deg, #0A84FF 0%, #BF5AF2 55%, #FF2D78 100%)",
                WebkitBackgroundClip: "text",
                backgroundClip: "text",
                color: "transparent",
              }}
            >
              Event
            </span>
          </span>
        </Link>
      </div>
    </header>
  );
}