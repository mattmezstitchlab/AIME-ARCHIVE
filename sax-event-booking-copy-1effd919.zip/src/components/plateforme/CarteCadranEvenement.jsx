import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { CalendarDays, Grid3X3, MapPin } from "lucide-react";
import ListeCadransMoments from "@/components/evenements/ListeCadransMoments";
import MecanismeCadran from "@/components/evenements/MecanismeCadran";
import { deriveImpactsCausals } from "@/lib/eventCausalSelectors";
import { ACTIONS_PAR_CONTEXTE } from "@/lib/eventModeConfig";

export default function CarteCadranEvenement({ evenement, documents = [], peutModifier = false, onOuvrir }) {
  const navigate = useNavigate(), [mecanisme, setMecanisme] = useState(false), [courant, setCourant] = useState(evenement);
  useEffect(() => setCourant(evenement), [evenement]);
  const impacts = deriveImpactsCausals(courant, documents, null);
  const impact = impacts.find((item) => ["rouge", "orange"].includes(item.niveau));
  const actions = peutModifier ? ACTIONS_PAR_CONTEXTE.cadran : [];
  const ouvrir = (suffixe = "") => { onOuvrir(); navigate(`/compte?evenement=${encodeURIComponent(courant.id)}&studio=cadran${suffixe}`); };
  const enregistrerMecanisme = async (patch) => { const maj = await base44.entities.Evenement.update(courant.id, patch); setCourant(maj); };
  const couleurImpact = impact?.niveau === "rouge" ? "text-[#FF6961]" : "text-[#FFB340]";
  return <article className="h-full w-[calc(100vw-2rem)] max-w-[360px] shrink-0 snap-center overflow-hidden rounded-[2.5rem] border border-white/10 bg-white/[0.04] p-5 shadow-2xl sm:p-6">
    {mecanisme ? <MecanismeCadran evenement={courant} documents={documents} impacts={impacts} lectureSeule={!peutModifier} onEnregistrer={enregistrerMecanisme} onRetour={() => setMecanisme(false)} /> : <>
      <div className="mb-2 min-h-[68px] text-center"><p className="truncate text-lg font-semibold text-white">{courant.titre}</p><p className="mt-1 flex flex-wrap justify-center gap-3 text-xs text-white/45"><span className="inline-flex items-center gap-1"><CalendarDays className="h-3.5 w-3.5" />{courant.date || "Date à confirmer"}</span>{courant.lieu && <span className="inline-flex max-w-[180px] items-center gap-1 truncate"><MapPin className="h-3.5 w-3.5 shrink-0" />{courant.lieu}</span>}</p></div>
      <ListeCadransMoments evenement={courant} documents={documents} impacts={impacts} actions={actions} onChoisirAction={(action) => ouvrir(`&action=${encodeURIComponent(action)}`)} onOuvrirDocuments={() => ouvrir("&panneau=documents")} onImpact={(item) => item?.id === "documents" ? ouvrir("&panneau=documents") : item && ouvrir(`&panneau=impact&impact=${encodeURIComponent(item.id)}`)} />
      {impact && <p className={`mt-3 text-center text-xs font-semibold ${couleurImpact}`}>{impact.label}</p>}
      <button type="button" onClick={() => setMecanisme(true)} className="mt-4 flex min-h-[44px] w-full items-center justify-center gap-2 rounded-full bg-white text-sm font-bold text-black hover:bg-white/90 focus-visible:ring-2 focus-visible:ring-[#BF5AF2]"><Grid3X3 className="h-4 w-4" />Voir le mécanisme</button>
    </>}
  </article>;
}