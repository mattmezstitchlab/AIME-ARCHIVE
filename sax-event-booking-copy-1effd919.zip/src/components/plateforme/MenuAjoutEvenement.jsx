import React from "react";
import { AlertTriangle, Clock3, FileText, Music, Plus, Settings, UserRoundPlus, UtensilsCrossed } from "lucide-react";

const ICONES = {
  moment: Clock3, acteur: UserRoundPlus, participant: UserRoundPlus, morceau: Music,
  sequence: Music, "associer-morceau": Music, invite: UtensilsCrossed, "groupe-table": UtensilsCrossed,
  allergie: AlertTriangle, regime: UtensilsCrossed, retard: Clock3, absence: UserRoundPlus,
  incident: AlertTriangle, "decision-urgente": AlertTriangle, decision: AlertTriangle, contrainte: AlertTriangle,
  devis: FileText, contrat: FileText, facture: FileText, "joindre-document": FileText,
  autorisations: Settings, statut: Settings,
};

export default function MenuAjoutEvenement({ actions, onChoisir, placement = "dock" }) {
  const position = placement === "cadran" ? "left-1/2 top-[calc(100%+0.6rem)]" : "bottom-[calc(100%+0.75rem)] left-1/2";
  return <div className={`absolute ${position} z-30 max-h-[min(45vh,300px)] w-[min(280px,calc(100vw-2rem))] -translate-x-1/2 overflow-y-auto rounded-2xl border border-white/10 bg-black/95 p-2 shadow-2xl backdrop-blur-xl`} role="menu" aria-label="Ajouter dans la section active">
    <p className="px-3 pb-2 pt-1 text-[11px] font-bold uppercase tracking-[0.18em] text-white/35">Ajouter ici</p>
    {actions.map(([cle, libelle]) => { const Icone = ICONES[cle] || Plus; return <button key={cle} type="button" role="menuitem" onClick={() => onChoisir(cle)} className="flex min-h-[44px] w-full items-center gap-3 rounded-xl px-3 text-left text-sm font-semibold text-white/75 transition-colors hover:bg-white/10 hover:text-white focus-visible:ring-2 focus-visible:ring-[#BF5AF2]"><Icone className="h-4 w-4 text-[#BF5AF2]" aria-hidden="true" /><span>{libelle}</span></button>; })}
  </div>;
}