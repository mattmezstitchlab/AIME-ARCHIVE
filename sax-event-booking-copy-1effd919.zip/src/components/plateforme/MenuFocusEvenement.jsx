import React from "react";
import { Link } from "react-router-dom";
import { Check, CircleDot, Clock3, CloudRain, Music, Radio, Users, UtensilsCrossed } from "lucide-react";

const optionsPour = (module, evenement) => {
  const moments = evenement?.moments || [], acteurs = evenement?.acteurs || [];
  if (module === "cadran") return [[null, "Cadran et déroulé", CircleDot], ["acteurs", "Acteurs et responsabilités", Users], ...(moments.length ? [["retard", "Simuler un retard", Clock3], ...(acteurs.length ? [["absence", "Simuler une absence", Users]] : []), ...(moments.some((m) => m.exposition === "exterieur") ? [["meteo", "Préparer un plan B météo", CloudRain]] : [])] : [])];
  if (module === "jourj") return [[null, "Direct du Jour J", Radio], ...(moments.length ? [["retard", "Signaler un retard", Clock3], ...(acteurs.length ? [["absence", "Signaler une absence", Users]] : []), ...(moments.some((m) => m.exposition === "exterieur") ? [["meteo", "Vérifier le plan B météo", CloudRain]] : [])] : [])];
  if (module === "playlist") return [[null, "Playlist collaborative", Music]];
  if (module === "table") return [[null, "Invités et régimes", UtensilsCrossed]];
  return [];
};

export default function MenuFocusEvenement({ evenementId, evenement, moduleActif, panneauOuvert, onChoisir }) {
  const options = optionsPour(moduleActif, evenement);
  return <div className="absolute bottom-[calc(100%+0.75rem)] left-1/2 max-h-[min(60vh,420px)] w-[min(300px,calc(100vw-1rem))] -translate-x-1/2 overflow-y-auto rounded-2xl border border-white/10 bg-black/95 p-2 shadow-2xl backdrop-blur-xl" role="menu" aria-label="Choisir un focus">
    <p className="px-3 pb-2 pt-1 text-[11px] font-bold uppercase tracking-[0.18em] text-white/35">Focus local</p>
    {options.map(([panneau, libelle, Icone]) => { const actif = panneau ? panneauOuvert === panneau : !panneauOuvert; const suffixe = panneau ? `&panneau=${panneau}` : ""; return <Link key={panneau || "principal"} role="menuitem" onClick={onChoisir} to={`/compte?evenement=${encodeURIComponent(evenementId)}&studio=${moduleActif}${suffixe}`} className="flex min-h-[44px] items-center gap-3 rounded-xl px-3 text-sm font-semibold text-white/70 transition-colors hover:bg-white/10 hover:text-white focus-visible:ring-2 focus-visible:ring-[#BF5AF2]"><Icone className="h-4 w-4" /><span className="flex-1">{libelle}</span>{actif && <Check className="h-4 w-4 text-[#30D158]" />}</Link>; })}
  </div>;
}