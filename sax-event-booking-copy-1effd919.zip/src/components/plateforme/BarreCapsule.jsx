import React, { useEffect, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { House, BookOpen, CircleDot, Plus, FileText, Settings, LogIn } from "lucide-react";
import { base44 } from "@/api/base44Client";
import BarreCapsuleEvenement from "@/components/plateforme/BarreCapsuleEvenement";
import PanneauCadransEvenements from "@/components/plateforme/PanneauCadransEvenements";

const PAGES_CACHEES = ["/login", "/register", "/forgot-password", "/reset-password"];

// BarreCapsule — navigation globale flottante, pictos uniquement.
// Connecté : Accueil · Mode d’emploi | Cadrans | Documents · Réglages.
// Visiteur : Accueil · Mode d’emploi | + (créer) | Connexion.
export default function BarreCapsule() {
  const { pathname, search } = useLocation();
  const [utilisateur, setUtilisateur] = useState(undefined);
  const [cadransOuverts, setCadransOuverts] = useState(false);

  useEffect(() => {
    if (PAGES_CACHEES.includes(pathname)) return;
    let active = true;
    base44.auth.me()
      .then((u) => { if (active) setUtilisateur(u); })
      .catch(() => { if (active) setUtilisateur(null); });
    return () => { active = false; };
  }, [pathname]);

  if (PAGES_CACHEES.includes(pathname)) return null;
  if (utilisateur === undefined) return null;

  const estAuth = !!utilisateur;
  const params = new URLSearchParams(search);
  const ongletCourant = params.get("onglet");
  const evenementId = params.get("evenement");
  const studio = params.get("studio") || "cadran";
  const panneau = params.get("panneau");

  if (estAuth && pathname === "/compte" && evenementId) {
    return <BarreCapsuleEvenement evenementId={evenementId} studio={studio} panneau={panneau} />;
  }

  const clsBouton = (actif) =>
    `relative flex items-center justify-center h-10 w-10 rounded-full transition-all ${
      actif ? "text-white bg-white/10" : "text-white/55 hover:text-white hover:bg-white/5"
    }`;

  const actifAccueil = pathname === "/";
  const actifGuide = pathname === "/guide";
  const actifDoc = pathname === "/compte" && ongletCourant === "documents";
  const actifReglage = pathname === "/compte" && ongletCourant === "parametres";
  const actifCreation = pathname === "/creer";

  return (
    <>
    {estAuth && <PanneauCadransEvenements ouvert={cadransOuverts} onOuvertChange={setCadransOuverts} utilisateur={utilisateur} />}
    <div className="fixed bottom-[calc(0.75rem+env(safe-area-inset-bottom))] md:bottom-5 left-1/2 -translate-x-1/2 z-50 pointer-events-none">
      <div className="pointer-events-auto relative">
        <div className="flex w-fit max-w-[calc(100vw-1rem)] items-center gap-1 rounded-full bg-black/80 backdrop-blur-xl border border-white/10 shadow-[0_8px_40px_rgba(0,0,0,0.45)] px-2.5 py-1.5">

          {/* Gauche : Accueil + Mode d’emploi */}
          <Link to="/" title="Accueil" aria-label="Accueil" aria-current={actifAccueil ? "page" : undefined} className={clsBouton(actifAccueil)}>
            <House className="h-[18px] w-[18px] shrink-0" />
          </Link>
          <Link to="/guide" title="Mode d’emploi" aria-label="Mode d’emploi et futur causal" aria-current={actifGuide ? "page" : undefined} className={clsBouton(actifGuide)}>
            <BookOpen className="h-[18px] w-[18px] shrink-0" />
          </Link>

          <span className="h-6 w-px bg-white/10 mx-0.5" aria-hidden="true" />

          {/* Centre : cadrans existants, ou création pour un visiteur */}
          {estAuth ? (
            <button type="button" onClick={() => setCadransOuverts(true)} title="Ouvrir mes cadrans" aria-label="Ouvrir mes cadrans causaux" aria-haspopup="dialog" aria-expanded={cadransOuverts} className="relative -my-2 flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-[#FF2D78] via-[#BF5AF2] to-[#0A84FF] shadow-[0_4px_20px_rgba(191,90,242,0.45)] transition-transform hover:scale-105 focus-visible:ring-2 focus-visible:ring-white"><CircleDot className="h-8 w-8 text-white" /><Plus className="absolute h-3.5 w-3.5 text-white" strokeWidth={3} /></button>
          ) : (
            <Link to="/creer" title="Créer mon événement" aria-label="Créer mon événement" aria-current={actifCreation ? "page" : undefined} className="relative -my-2 flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-[#FF2D78] via-[#BF5AF2] to-[#0A84FF] shadow-[0_4px_20px_rgba(191,90,242,0.45)] transition-transform hover:scale-105"><Plus className="h-5 w-5 text-white" strokeWidth={2.5} /></Link>
          )}

          <span className="h-6 w-px bg-white/10 mx-0.5" aria-hidden="true" />

          {/* Droite : Documents + Réglages (ou Connexion) */}
          {estAuth ? (
            <>
              <Link to="/compte?onglet=documents" title="Documents" aria-label="Documents" aria-current={actifDoc ? "page" : undefined} className={clsBouton(actifDoc)}>
                <FileText className="h-[18px] w-[18px] shrink-0" />
              </Link>
              <Link to="/compte?onglet=parametres" title="Réglages" aria-label="Réglages" aria-current={actifReglage ? "page" : undefined} className={clsBouton(actifReglage)}>
                <Settings className="h-[18px] w-[18px] shrink-0" />
              </Link>
            </>
          ) : (
            <Link to="/login" title="Connexion" aria-label="Connexion" className={clsBouton(false)}>
              <LogIn className="h-[18px] w-[18px] shrink-0" />
            </Link>
          )}
        </div>
      </div>
    </div>
    </>
  );
}