import React from "react";
import { Link } from "react-router-dom";
import { Plus } from "lucide-react";

export default function CarteNouveauCadran({ onOuvrir }) {
  return <article className="flex w-[calc(100vw-2rem)] max-w-[360px] shrink-0 snap-center flex-col items-center justify-center rounded-[2.5rem] border border-dashed border-white/15 bg-white/[0.025] p-8 text-center">
    <div className="flex h-52 w-52 items-center justify-center rounded-full border border-white/15 shadow-[inset_0_0_50px_rgba(191,90,242,0.10)]"><div className="flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-[#FF2D78] via-[#BF5AF2] to-[#0A84FF] shadow-[0_0_35px_rgba(191,90,242,0.4)]"><Plus className="h-8 w-8 text-white" /></div></div>
    <h3 className="mt-6 text-xl font-semibold text-white">Nouveau cadran</h3><p className="mt-2 max-w-xs text-sm text-white/45">Créez un événement, même simple. Son cadran évoluera avec vos confirmations.</p>
    <Link to="/creer" onClick={onOuvrir} className="mt-5 inline-flex min-h-[44px] items-center rounded-full bg-white px-6 text-sm font-bold text-black hover:bg-white/90 focus-visible:ring-2 focus-visible:ring-[#BF5AF2]">Créer un événement</Link>
  </article>;
}