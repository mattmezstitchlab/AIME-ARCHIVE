import React from "react";

export default function ListeEditable({ id, label, items = [], onChange }) {
  const valeur = items.map((item) => item.valeur || item.libelle).filter(Boolean).join("\n");
  const changer = (texte) => onChange(texte.split("\n").filter(Boolean).map((ligne) => ({ libelle: ligne, valeur: ligne, confiance: 100, provenance: "Corrigé par vous", statut: "clair" })));
  return (
    <div>
      <label htmlFor={id} className="mb-2 block text-xs font-bold uppercase tracking-wider text-white/60">{label}</label>
      <textarea id={id} rows={4} value={valeur} onChange={(e) => changer(e.target.value)} placeholder="Une information par ligne" className="w-full rounded-2xl border border-white/10 bg-white/[0.04] px-4 py-3 text-base leading-relaxed text-white placeholder:text-white/30 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#BF5AF2]" />
      {items.length > 0 && <ul className="mt-2 space-y-1">{items.map((item, index) => <li key={`${item.libelle}-${index}`} className="text-xs text-white/45"><span className={item.statut === "clair" && item.confiance >= 75 ? "text-[#75E08A]" : "text-[#FFC46B]"}>{item.statut === "clair" && item.confiance >= 75 ? `${Math.round(item.confiance)} % fiable` : "À confirmer"}</span>{item.provenance ? ` · source : « ${item.provenance} »` : ""}</li>)}</ul>}
    </div>
  );
}