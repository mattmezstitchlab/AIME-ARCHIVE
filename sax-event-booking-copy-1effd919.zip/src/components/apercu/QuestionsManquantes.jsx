import React from "react";
import { HelpCircle } from "lucide-react";

export default function QuestionsManquantes({ questions = [], onChange }) {
  if (!questions.length) return null;
  const modifier = (index, valeurs) => onChange(questions.map((q, i) => i === index ? { ...q, ...valeurs } : q));
  return (
    <section className="rounded-2xl border border-[#FF9F0A]/30 bg-[#FF9F0A]/10 p-5">
      <h2 className="flex items-center gap-2 font-semibold text-white"><HelpCircle className="h-5 w-5 text-[#FFC46B]" /> Questions à résoudre</h2>
      <div className="mt-4 space-y-5">{questions.map((question, index) => (
        <fieldset key={`${question.question}-${index}`} className="space-y-2">
          <legend className="text-sm leading-relaxed text-white/80">{question.question}</legend>
          <textarea aria-label={`Réponse à : ${question.question}`} rows={2} value={question.reponse || ""} disabled={question.statut === "inconnue"} onChange={(e) => modifier(index, { reponse: e.target.value, statut: e.target.value.trim() ? "resolue" : "ouverte" })} className="w-full rounded-xl border border-white/15 bg-black/25 px-3 py-2 text-sm text-white disabled:opacity-40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#BF5AF2]" />
          <label className="flex min-h-[40px] cursor-pointer items-center gap-2 text-sm text-white/65"><input type="checkbox" checked={question.statut === "inconnue"} onChange={(e) => modifier(index, { statut: e.target.checked ? "inconnue" : "ouverte", reponse: "" })} className="h-4 w-4 accent-[#BF5AF2]" /> Je ne sais pas encore</label>
        </fieldset>
      ))}</div>
    </section>
  );
}