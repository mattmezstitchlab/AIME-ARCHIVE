import React from "react";
import { Check, Loader2, Pencil } from "lucide-react";
import ChampConfiance from "@/components/apercu/ChampConfiance";
import ListeEditable from "@/components/apercu/ListeEditable";
import ActeursEditables from "@/components/apercu/ActeursEditables";
import QuestionsManquantes from "@/components/apercu/QuestionsManquantes";
import BlocagesCreation from "@/components/apercu/BlocagesCreation";
import { aujourdhuiIso, dateValideFuture } from "@/lib/validationApercu";

const CHAMPS = [["titre", "Titre"], ["typeEvenement", "Type d’événement"], ["date", "Date", "date"], ["lieu", "Lieu"], ["nombreInvites", "Nombre d’invités", "number"], ["budget", "Budget prévisionnel"]];
const LISTES = [["horaires", "Horaires compris"], ["contraintes", "Contraintes"], ["souhaits", "Souhaits"], ["risques", "Risques explicitement identifiés"]];

export default function FormulaireApercu({ etat }) {
  const { brief, setBrief, analyse, editionBrief, setEditionBrief, confirme, setConfirme, creation, erreur, analyser, modifier, blocages, creer } = etat;
  const champ = (cle, valeur) => {
    const date = cle === "date";
    const statut = date ? (dateValideFuture(valeur) ? "clair" : valeur ? "incoherent" : "manquant") : "clair";
    modifier(cle, { ...analyse[cle], valeur, confiance: statut === "clair" ? 100 : 0, provenance: "Correction utilisateur", statut });
  };
  return <div className="space-y-6">
    {editionBrief && <section className="rounded-2xl border border-white/10 bg-white/[0.04] p-5"><label htmlFor="brief-source" className="mb-2 block text-xs font-bold uppercase tracking-wider text-white/60">Votre brief</label><textarea id="brief-source" rows={6} value={brief} onChange={(e) => setBrief(e.target.value)} className="w-full rounded-xl border border-white/15 bg-black/30 p-4 text-base text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#BF5AF2]" /><button onClick={() => { setEditionBrief(false); analyser(brief); }} className="mt-3 min-h-[44px] rounded-full bg-white px-5 text-sm font-bold text-black">Analyser à nouveau</button></section>}
    <div className="grid gap-4 md:grid-cols-2">{CHAMPS.map(([cle, label, type]) => <ChampConfiance key={cle} id={`apercu-${cle}`} label={label} type={type} min={type === "date" ? aujourdhuiIso() : undefined} required={["titre", "typeEvenement", "date", "lieu"].includes(cle)} champ={analyse[cle]} onChange={(valeur) => champ(cle, valeur)} />)}</div>
    <div className="grid gap-5 md:grid-cols-2">{LISTES.map(([cle, label]) => <ListeEditable key={cle} id={`apercu-${cle}`} label={label} items={analyse[cle]} onChange={(items) => modifier(cle, items)} />)}</div>
    <ActeursEditables acteurs={analyse.acteurs} onChange={(acteurs) => modifier("acteurs", acteurs)} />
    <QuestionsManquantes questions={analyse.questionsManquantes} onChange={(questions) => modifier("questionsManquantes", questions)} />
    <label className="flex min-h-[48px] cursor-pointer items-start gap-3 rounded-2xl border border-white/10 bg-white/[0.04] p-4"><input type="checkbox" checked={confirme} onChange={(e) => setConfirme(e.target.checked)} className="mt-0.5 h-5 w-5 accent-[#BF5AF2]" /><span className="text-sm leading-relaxed text-white/75">Je confirme les informations après leur dernière modification.</span></label>
    <BlocagesCreation blocages={blocages} />
    {erreur && <p role="alert" className="rounded-xl border border-[#FF453A]/40 bg-[#FF453A]/10 p-3 text-sm text-[#FF8A82]">{erreur}</p>}
    <div className="flex flex-col gap-3 sm:flex-row"><button onClick={() => setEditionBrief(!editionBrief)} className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-full bg-white/10 px-6 text-sm font-semibold hover:bg-white/20"><Pencil className="h-4 w-4" /> Modifier mon brief</button><button onClick={creer} disabled={creation || blocages.length > 0} className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-full bg-gradient-to-r from-[#BF5AF2] to-[#0A84FF] px-7 text-sm font-bold disabled:cursor-not-allowed disabled:opacity-40">{creation ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />} Confirmer et créer mon événement</button></div>
  </div>;
}