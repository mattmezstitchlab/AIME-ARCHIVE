import React from "react";

const CATEGORIES = [["celebres", "Personne principale"], ["famille", "Proche"], ["organisateur", "Organisation"], ["prestataire", "Prestataire"]];
const classe = "min-h-[44px] w-full rounded-xl border border-white/15 bg-black/30 px-3 text-sm text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#BF5AF2]";

export default function ActeursEditables({ acteurs = [], onChange }) {
  const modifier = (index, champ, valeur) => onChange(acteurs.map((acteur, i) => i === index ? { ...acteur, [champ]: valeur, confiance: 100, provenance: "Corrigé par vous", statut: "clair" } : acteur));
  if (!acteurs.length) return null;
  return (
    <section>
      <h2 className="mb-3 text-xs font-bold uppercase tracking-wider text-white/60">Acteurs compris</h2>
      <div className="grid gap-3 md:grid-cols-2">{acteurs.map((acteur, index) => (
        <div key={`${acteur.nom}-${index}`} className="rounded-2xl border border-white/10 bg-white/[0.04] p-4 space-y-3">
          <label className="block text-xs text-white/55">Nom<input aria-label={`Nom de l’acteur ${index + 1}`} value={acteur.nom} onChange={(e) => modifier(index, "nom", e.target.value)} className={`${classe} mt-1`} /></label>
          <label className="block text-xs text-white/55">Rôle<input aria-label={`Rôle de ${acteur.nom || `l’acteur ${index + 1}`}`} value={acteur.role} onChange={(e) => modifier(index, "role", e.target.value)} className={`${classe} mt-1`} /></label>
          <label className="block text-xs text-white/55">Catégorie<select aria-label={`Catégorie de ${acteur.nom || `l’acteur ${index + 1}`}`} value={acteur.categorie} onChange={(e) => modifier(index, "categorie", e.target.value)} className={`${classe} mt-1`}>{CATEGORIES.map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select></label>
          <p className="text-xs text-white/45"><span className={acteur.statut === "clair" ? "text-[#75E08A]" : "text-[#FFC46B]"}>{acteur.statut === "clair" ? `${Math.round(acteur.confiance)} % fiable` : "À confirmer"}</span>{acteur.provenance ? ` · source : « ${acteur.provenance} »` : ""}</p>
        </div>
      ))}</div>
    </section>
  );
}