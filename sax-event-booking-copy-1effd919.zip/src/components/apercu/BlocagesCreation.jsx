import React from "react";
import { AlertTriangle } from "lucide-react";

export default function BlocagesCreation({ blocages = [] }) {
  if (!blocages.length) return <p className="rounded-2xl border border-[#34C759]/30 bg-[#34C759]/10 p-4 text-sm text-[#9BE8A9]">Toutes les informations requises sont prêtes à être créées.</p>;
  return (
    <section role="alert" className="rounded-2xl border border-[#FF453A]/35 bg-[#FF453A]/10 p-5">
      <h2 className="flex items-center gap-2 font-semibold text-white"><AlertTriangle className="h-5 w-5 text-[#FF8A82]" /> Création encore bloquée</h2>
      <ul className="mt-3 list-disc space-y-1.5 pl-5 text-sm text-white/75">{blocages.map((blocage) => <li key={blocage}>{blocage}</li>)}</ul>
    </section>
  );
}