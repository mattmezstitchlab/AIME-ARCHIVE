import React from "react";

const APPROXIMATION = /\b(environ|vers|probablement|peut-être|peut etre|approximativement)\b/i;

const libelleStatut = (champ) => {
  if (champ?.statut === "manquant") return "Information manquante";
  if (champ?.statut === "incoherent") return "Incohérence détectée";
  if (APPROXIMATION.test(`${champ?.valeur || ""} ${champ?.provenance || ""}`)) return "Approximation détectée";
  if (champ?.statut !== "clair") return "À confirmer";
  return "Détecté clairement";
};

export default function ChampConfiance({ id, label, champ, type = "text", min, onChange, required = false }) {
  const aConfirmer = champ?.statut !== "clair";
  const statut = libelleStatut(champ);
  return (
    <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-4">
      <div className="mb-2 flex items-center justify-between gap-3">
        <label htmlFor={id} className="text-xs font-bold uppercase tracking-wider text-white/60">{label}</label>
        <span className={`rounded-full px-2 py-1 text-[10px] font-bold ${aConfirmer ? "bg-[#FF9F0A]/20 text-[#FFC46B]" : "bg-[#34C759]/15 text-[#75E08A]"}`}>
          {statut}
        </span>
      </div>
      <input id={id} type={type} min={min} required={required} value={champ?.valeur || ""} onChange={(e) => onChange(e.target.value)} className="min-h-[48px] w-full rounded-xl border border-white/15 bg-black/30 px-4 text-base text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#BF5AF2]" />
      {champ?.provenance && <p className="mt-2 break-words text-xs italic text-white/45">Source : « {champ.provenance} »</p>}
    </div>
  );
}