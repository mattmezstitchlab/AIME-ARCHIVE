import React from "react";
import { AlertCircle } from "lucide-react";

export default function ChampFormulaire({ id, label, error, children, className = "" }) {
  return (
    <div className={`flex flex-col gap-2 ${className}`}>
      <label
        htmlFor={id}
        className="text-xs font-bold uppercase tracking-[0.15em] text-[var(--p-accent)]"
      >
        {label}
      </label>
      {children}
      {error && (
        <p
          id={`${id}-error`}
          role="alert"
          className="flex items-center gap-1.5 text-sm text-[var(--p-error)] animate-in slide-in-from-top-1 duration-300"
        >
          <AlertCircle className="h-4 w-4 shrink-0" aria-hidden="true" />
          {error}
        </p>
      )}
    </div>
  );
}