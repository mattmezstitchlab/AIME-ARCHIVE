import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Loader2, AlertCircle, Orbit } from "lucide-react";
import ChampFormulaire from "./ChampFormulaire";

const TYPES_EVENEMENT = [
  "Mariage", "Anniversaire", "Cocktail", "Soirée privée",
  "Événement d'entreprise", "Restaurant ou hôtel", "Cérémonie",
  "Demande en mariage", "Autre",
];

const ETAT_INITIAL = {
  nom: "", prenom: "", telephone: "", email: "", adresseEvenement: "",
  typeEvenement: "", dateEvenement: "", heureDebut: "", heureFin: "",
  informationsComplementaires: "", consentement: false, siteWeb: "",
};

const classeInput =
  "min-h-[48px] w-full rounded-lg border border-[var(--p-border-strong)] bg-[var(--p-surface)] px-4 py-3 text-[var(--p-text)] placeholder:text-[var(--p-faint)] transition-all duration-300 focus:border-[var(--p-accent)] focus:outline-none focus:ring-1 focus:ring-[var(--p-accent)] [color-scheme:dark]";

function formatDateLongueFr(iso) {
  if (!iso) return "";
  const [a, m, j] = iso.split("-").map(Number);
  return new Date(a, m - 1, j).toLocaleDateString("fr-FR", {
    weekday: "long", day: "numeric", month: "long", year: "numeric",
  });
}

export default function FormulaireDemande({ onSucces, proprietaire, dateInitiale }) {
  const [valeurs, setValeurs] = useState(() => ({ ...ETAT_INITIAL, dateEvenement: dateInitiale || "" }));
  const [erreurs, setErreurs] = useState({});
  const [envoi, setEnvoi] = useState(false);
  const [erreurGlobale, setErreurGlobale] = useState("");
  const [prerempli, setPrerempli] = useState(null);

  const aujourdHui = new Date().toISOString().split("T")[0];

  // Visiteur connecté ayant déjà créé son événement sur la plateforme : on préremplit sa demande.
  useEffect(() => {
    base44.auth.me()
      .then(async (u) => {
        const evts = await base44.entities.Evenement.filter(
          { proprietaire: (u.email || "").toLowerCase() }, "-date", 1
        );
        const evt = evts[0];
        if (!evt) return;
        const [prenomU, ...resteNom] = (u.full_name || "").split(" ");
        const typeConnu = TYPES_EVENEMENT.find(
          (t) => t.toLowerCase() === (evt.typeEvenement || "").toLowerCase()
        );
        setValeurs((v) => ({
          ...v,
          prenom: v.prenom || prenomU || "",
          nom: v.nom || resteNom.join(" ") || "",
          email: v.email || u.email || "",
          telephone: v.telephone || evt.organisateurTelephone || "",
          adresseEvenement: v.adresseEvenement || evt.lieu || "",
          typeEvenement: v.typeEvenement || typeConnu || (evt.typeEvenement ? "Autre" : ""),
          dateEvenement: v.dateEvenement || evt.date || "",
        }));
        setPrerempli(evt.titre);
      })
      .catch(() => {});
  }, []);

  const changer = (champ, valeur) => {
    setValeurs((v) => ({ ...v, [champ]: valeur }));
    setErreurs((e) => ({ ...e, [champ]: undefined }));
  };

  const valider = () => {
    const e = {};
    if (!valeurs.nom.trim()) e.nom = "Le nom est obligatoire.";
    if (!valeurs.prenom.trim()) e.prenom = "Le prénom est obligatoire.";
    if (!valeurs.telephone.trim()) e.telephone = "Le numéro de téléphone est obligatoire.";
    else if (!/^\+?[\d\s().-]{8,20}$/.test(valeurs.telephone.trim()))
      e.telephone = "Veuillez saisir un numéro de téléphone valide.";
    if (!valeurs.email.trim()) e.email = "L'adresse e-mail est obligatoire.";
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(valeurs.email.trim()))
      e.email = "Veuillez saisir une adresse e-mail valide.";
    if (!valeurs.adresseEvenement.trim()) e.adresseEvenement = "L'adresse complète est obligatoire.";
    if (!valeurs.typeEvenement) e.typeEvenement = "Veuillez choisir un type d'événement.";
    if (!valeurs.dateEvenement) e.dateEvenement = "La date de l'événement est obligatoire.";
    else if (valeurs.dateEvenement < aujourdHui) e.dateEvenement = "La date ne peut pas être dans le passé.";
    if (!valeurs.heureDebut) e.heureDebut = "L'heure de début est obligatoire.";
    if (!valeurs.heureFin) e.heureFin = "L'heure de fin est obligatoire.";
    else if (valeurs.heureDebut && valeurs.heureFin <= valeurs.heureDebut)
      e.heureFin = "L'heure de fin doit être postérieure à l'heure de début.";
    if (!valeurs.consentement) e.consentement = "Votre consentement est nécessaire pour envoyer la demande.";
    return e;
  };

  const soumettre = async (ev) => {
    ev.preventDefault();
    setErreurGlobale("");
    const e = valider();
    if (Object.keys(e).length > 0) {
      setErreurs(e);
      return;
    }
    setEnvoi(true);
    try {
      const res = await base44.functions.invoke("envoyerDemande", { ...valeurs, proprietaire });
      base44.analytics.track({ eventName: "availability_request_sent" });
      onSucces(res.data?.reference);
    } catch (_err) {
      setErreurGlobale(
        "Une erreur est survenue lors de l'envoi. Merci de vérifier vos informations et de réessayer."
      );
    } finally {
      setEnvoi(false);
    }
  };

  return (
    <form onSubmit={soumettre} noValidate className="space-y-8">
      {prerempli && (
        <p className="flex items-start gap-2.5 rounded-lg bg-[var(--p-bg)] border border-[var(--p-border)] px-4 py-3 text-sm text-[var(--p-text-soft)]">
          <Orbit className="h-4 w-4 shrink-0 mt-0.5 text-[var(--p-accent)]" aria-hidden="true" />
          Nous avons prérempli ce formulaire avec votre événement « {prerempli} ». Vérifiez et ajustez si besoin.
        </p>
      )}
      {/* Champ honeypot invisible anti-bot — masqué des lecteurs d'écran et du clavier */}
      <div className="absolute -left-[9999px] top-0" aria-hidden="true">
        <input
          type="text" name="siteWeb" tabIndex={-1} autoComplete="off" aria-hidden="true"
          value={valeurs.siteWeb} onChange={(ev) => changer("siteWeb", ev.target.value)}
        />
      </div>

      <fieldset className="space-y-6 border-0 p-0 m-0">
        <legend className="font-heading text-xl text-[var(--p-text)] mb-2">Vos coordonnées</legend>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <ChampFormulaire id="nom" label="Nom" error={erreurs.nom}>
            <input id="nom" type="text" placeholder="Dupont" value={valeurs.nom}
              onChange={(ev) => changer("nom", ev.target.value)}
              autoComplete="family-name" required
              aria-invalid={!!erreurs.nom} aria-describedby={erreurs.nom ? "nom-error" : undefined}
              className={classeInput} />
          </ChampFormulaire>
          <ChampFormulaire id="prenom" label="Prénom" error={erreurs.prenom}>
            <input id="prenom" type="text" placeholder="Marie" value={valeurs.prenom}
              onChange={(ev) => changer("prenom", ev.target.value)}
              autoComplete="given-name" required
              aria-invalid={!!erreurs.prenom} aria-describedby={erreurs.prenom ? "prenom-error" : undefined}
              className={classeInput} />
          </ChampFormulaire>
        </div>
        <ChampFormulaire id="telephone" label="Numéro de téléphone" error={erreurs.telephone}>
          <input id="telephone" type="tel" placeholder="06 12 34 56 78" value={valeurs.telephone}
            onChange={(ev) => changer("telephone", ev.target.value)}
            autoComplete="tel" required
            aria-invalid={!!erreurs.telephone} aria-describedby={erreurs.telephone ? "telephone-error" : undefined}
            className={classeInput} />
        </ChampFormulaire>
        <ChampFormulaire id="email" label="Adresse e-mail" error={erreurs.email}>
          <input id="email" type="email" placeholder="marie.dupont@email.com" value={valeurs.email}
            onChange={(ev) => changer("email", ev.target.value)}
            autoComplete="email" required
            aria-invalid={!!erreurs.email} aria-describedby={erreurs.email ? "email-error" : undefined}
            className={classeInput} />
        </ChampFormulaire>
      </fieldset>

      <fieldset className="space-y-6 border-0 p-0 m-0">
        <legend className="font-heading text-xl text-[var(--p-text)] mb-2">Votre événement</legend>
        <ChampFormulaire id="adresseEvenement" label="Adresse de l'événement" error={erreurs.adresseEvenement}>
          <input id="adresseEvenement" type="text" placeholder="10 rue de la Paix, 75002 Paris"
            value={valeurs.adresseEvenement}
            onChange={(ev) => changer("adresseEvenement", ev.target.value)}
            autoComplete="street-address" required
            aria-invalid={!!erreurs.adresseEvenement}
            aria-describedby={erreurs.adresseEvenement ? "adresseEvenement-error" : undefined}
            className={classeInput} />
          <p className="text-xs text-[var(--p-muted)]">Rue, code postal et ville</p>
        </ChampFormulaire>
        <ChampFormulaire id="typeEvenement" label="Type d'événement" error={erreurs.typeEvenement}>
          <select id="typeEvenement" value={valeurs.typeEvenement} required
            onChange={(ev) => changer("typeEvenement", ev.target.value)}
            aria-invalid={!!erreurs.typeEvenement}
            aria-describedby={erreurs.typeEvenement ? "typeEvenement-error" : undefined}
            className={`${classeInput} appearance-none ${valeurs.typeEvenement ? "" : "text-[var(--p-faint)]"}`}>
            <option value="" disabled>Sélectionnez un type d'événement</option>
            {TYPES_EVENEMENT.map((t) => (
              <option key={t} value={t} className="bg-[var(--p-surface)] text-[var(--p-text)]">{t}</option>
            ))}
          </select>
        </ChampFormulaire>
        <ChampFormulaire id="dateEvenement" label="Date de l'événement" error={erreurs.dateEvenement}>
          {dateInitiale ? (
            <p className="min-h-[48px] w-full rounded-lg border border-[var(--p-border)] bg-[var(--p-bg)] px-4 py-3 text-[var(--p-text)] font-medium flex items-center capitalize">
              {formatDateLongueFr(valeurs.dateEvenement)}
            </p>
          ) : (
            <input id="dateEvenement" type="date" min={aujourdHui} value={valeurs.dateEvenement}
              onChange={(ev) => changer("dateEvenement", ev.target.value)} required
              aria-invalid={!!erreurs.dateEvenement}
              aria-describedby={erreurs.dateEvenement ? "dateEvenement-error" : undefined}
              className={classeInput} />
          )}
        </ChampFormulaire>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <ChampFormulaire id="heureDebut" label="Heure de début" error={erreurs.heureDebut}>
            <input id="heureDebut" type="time" value={valeurs.heureDebut}
              onChange={(ev) => changer("heureDebut", ev.target.value)} required
              aria-invalid={!!erreurs.heureDebut}
              aria-describedby={erreurs.heureDebut ? "heureDebut-error" : undefined}
              className={classeInput} />
          </ChampFormulaire>
          <ChampFormulaire id="heureFin" label="Heure de fin" error={erreurs.heureFin}>
            <input id="heureFin" type="time" value={valeurs.heureFin}
              onChange={(ev) => changer("heureFin", ev.target.value)} required
              aria-invalid={!!erreurs.heureFin}
              aria-describedby={erreurs.heureFin ? "heureFin-error" : undefined}
              className={classeInput} />
          </ChampFormulaire>
        </div>
        <ChampFormulaire id="informationsComplementaires" label="Informations complémentaires (facultatif)">
          <textarea id="informationsComplementaires" rows={5} maxLength={1000}
            placeholder="Nombre d'invités, ambiance souhaitée, lieu exact, programme…"
            value={valeurs.informationsComplementaires}
            onChange={(ev) => changer("informationsComplementaires", ev.target.value)}
            className={`${classeInput} resize-y min-h-[120px]`} />
          <p className="text-xs text-[var(--p-muted)] text-right">
            {valeurs.informationsComplementaires.length} / 1000 caractères
          </p>
        </ChampFormulaire>
      </fieldset>

      <div className="space-y-2">
        <label htmlFor="consentement" className="flex items-start gap-3 cursor-pointer min-h-[48px] py-2">
          <input id="consentement" type="checkbox" checked={valeurs.consentement}
            onChange={(ev) => changer("consentement", ev.target.checked)} required
            aria-invalid={!!erreurs.consentement}
            aria-describedby={erreurs.consentement ? "consentement-error" : undefined}
            className="mt-0.5 h-5 w-5 shrink-0 rounded border-[var(--p-border-strong)] bg-[var(--p-surface)] accent-[var(--p-accent)] cursor-pointer" />
          <span className="text-sm text-[var(--p-text-soft)] leading-relaxed">
            J'accepte que les informations renseignées soient utilisées afin de
            répondre à ma demande de disponibilité.
          </span>
        </label>
        {erreurs.consentement && (
          <p id="consentement-error" role="alert"
            className="flex items-center gap-1.5 text-sm text-[var(--p-error)]">
            <AlertCircle className="h-4 w-4 shrink-0" aria-hidden="true" />
            {erreurs.consentement}
          </p>
        )}
      </div>

      {erreurGlobale && (
        <div role="alert"
          className="flex items-start gap-2.5 rounded-lg border border-[var(--p-error)] px-4 py-3 text-sm text-[var(--p-error)]">
          <AlertCircle className="h-5 w-5 shrink-0 mt-0.5" aria-hidden="true" />
          {erreurGlobale}
        </div>
      )}

      <button type="submit" disabled={envoi}
        className="w-full min-h-[52px] rounded-full bg-[var(--p-cta)] text-[var(--p-cta-text)] font-bold text-base tracking-wide transition-all duration-300 hover:bg-[var(--p-cta-hover)] hover:shadow-lg disabled:opacity-70 disabled:cursor-not-allowed focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--p-accent)] focus-visible:ring-offset-4 focus-visible:ring-offset-[var(--p-surface)] flex items-center justify-center gap-2.5">
        {envoi ? (
          <>
            <Loader2 className="h-5 w-5 animate-spin" aria-hidden="true" />
            Envoi en cours…
          </>
        ) : (
          "Envoyer ma demande"
        )}
      </button>
    </form>
  );
}