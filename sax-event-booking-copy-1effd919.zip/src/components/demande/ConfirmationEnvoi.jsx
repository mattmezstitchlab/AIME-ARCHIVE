import React from "react";
import { motion } from "framer-motion";
import { CheckCircle2 } from "lucide-react";

export default function ConfirmationEnvoi({ onNouvelleDemande, reference }) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.96 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5, ease: "easeOut" }}
      role="status"
      className="flex flex-col items-center text-center py-10 px-2"
    >
      <CheckCircle2 className="h-14 w-14 text-[var(--p-accent)] mb-6" aria-hidden="true" />
      <h2 className="font-heading text-2xl md:text-3xl text-[var(--p-text)] mb-4">
        Merci, votre demande a bien été envoyée
      </h2>
      {reference && (
        <p className="mb-4 text-sm text-[var(--p-text)]">
          Référence de votre demande :{" "}
          <span className="font-mono font-bold tracking-wide">{reference}</span>
        </p>
      )}
      <p className="text-sm md:text-base text-[var(--p-muted)] leading-relaxed max-w-md mb-8">
        Votre demande de disponibilité a été transmise{reference ? " (la référence vous a aussi été envoyée par e-mail)" : ""}. Vous serez recontacté(e)
        par téléphone dans les plus brefs délais.
      </p>
      <button
        onClick={onNouvelleDemande}
        className="min-h-[48px] px-8 rounded-full border border-[var(--p-border-strong)] text-[var(--p-text)] font-medium text-sm tracking-wide transition-colors duration-300 hover:bg-[var(--p-cta)] hover:text-[var(--p-cta-text)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--p-accent)] focus-visible:ring-offset-2 focus-visible:ring-offset-[var(--p-surface)]"
      >
        Envoyer une nouvelle demande
      </button>
    </motion.div>
  );
}