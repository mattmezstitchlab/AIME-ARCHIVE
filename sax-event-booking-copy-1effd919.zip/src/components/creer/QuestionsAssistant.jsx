import React, { useState } from "react";
import { MODELES_EVENEMENTS } from "@/lib/modelesEvenements";
import { Loader2 } from "lucide-react";
import TypeEvenementSelector from "@/components/creer/TypeEvenementSelector";

const CHAMP = "w-full min-h-[48px] rounded-xl bg-white/[0.05] border border-white/15 px-4 text-sm text-white placeholder:text-white/35 focus:outline-none focus:border-[#BF5AF2]/60";

// Le questionnaire de l'assistant : type, titre, date, lieu, invités, souhaits.
// `initial` : réponses pré-remplies par l'analyse d'un brief libre.
export default function QuestionsAssistant({ onGenerer, enCours, initial }) {
  const [type, setType] = useState(initial?.cleType && MODELES_EVENEMENTS[initial.cleType] ? initial.cleType : "mariage");
  const [titre, setTitre] = useState(initial?.titre || "");
  const [date, setDate] = useState(initial?.date || "");
  const [lieu, setLieu] = useState(initial?.lieu || "");
  const [invites, setInvites] = useState(initial?.invites || "");
  const [souhaits, setSouhaits] = useState(initial?.souhaits || "");

  const modele = MODELES_EVENEMENTS[type];
  const pret = !!date && !enCours;

  return (
    <form
      onSubmit={(e) => { e.preventDefault(); if (pret) onGenerer({ type: modele.libelle, cleType: type, titre, date, lieu, invites, souhaits }); }}
      className="space-y-5"
    >
      <TypeEvenementSelector value={type} onChange={setType} />

      <label htmlFor="assistant-titre" className="sr-only">Titre de l’événement</label>
      <input id="assistant-titre" type="text" value={titre} onChange={(e) => setTitre(e.target.value)} placeholder={modele.placeholderTitre} className={CHAMP} />

      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div>
          <label htmlFor="assistant-date" className="mb-1.5 block text-[11px] text-white/40">Date *</label>
          <input id="assistant-date" type="date" required value={date} onChange={(e) => setDate(e.target.value)} className={CHAMP} />
        </div>
        <div>
          <label htmlFor="assistant-lieu" className="mb-1.5 block text-[11px] text-white/40">Lieu</label>
          <input id="assistant-lieu" type="text" value={lieu} onChange={(e) => setLieu(e.target.value)} placeholder="Château, salle, jardin…" className={CHAMP} />
        </div>
        <div>
          <label htmlFor="assistant-invites" className="mb-1.5 block text-[11px] text-white/40">Invités</label>
          <input id="assistant-invites" type="number" min="1" value={invites} onChange={(e) => setInvites(e.target.value)} placeholder="80" className={CHAMP} />
        </div>
      </div>

      <label htmlFor="assistant-souhaits" className="sr-only">Cahier des charges de l’événement</label>
      <textarea
        id="assistant-souhaits"
        value={souhaits}
        onChange={(e) => setSouhaits(e.target.value)}
        rows={3}
        placeholder="Cahier des charges : moments clés, horaires, budget, personnes, prestataires, contraintes, risques et plans B…"
        className="w-full rounded-xl bg-white/[0.05] border border-white/15 px-4 py-3 text-sm text-white placeholder:text-white/35 focus:outline-none focus:border-[#BF5AF2]/60"
      />

      <button
        type="submit"
        disabled={!pret}
        className="inline-flex items-center gap-2 min-h-[52px] px-7 rounded-full bg-gradient-to-r from-[#BF5AF2] to-[#0A84FF] text-sm font-bold text-white hover:opacity-90 disabled:opacity-40 transition-opacity"
      >
        {enCours && <Loader2 className="h-4 w-4 animate-spin" />}
        {enCours ? "L'assistant compose votre dossier…" : "Composer mon dossier d'événement"}
      </button>
    </form>
  );
}