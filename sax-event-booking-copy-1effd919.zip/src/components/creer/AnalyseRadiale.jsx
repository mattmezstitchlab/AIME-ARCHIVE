import React, { useEffect, useState } from "react";
import { Check, Circle } from "lucide-react";

const ETAPES = {
  brief: ["Lecture de votre récit", "Repérage des lieux et dates", "Extraction du budget et des horaires", "Identification des acteurs", "Détection des contraintes", "Préparation du cahier des charges"],
  composition: ["Orchestration des moments", "Calcul des dépendances", "Affectation des responsables", "Simulation des imprévus", "Équilibrage du budget", "Tracé du cadran causal"],
};

export default function AnalyseRadiale({ mode = "brief", texte = "" }) {
  const [etape, setEtape] = useState(0);
  const phases = ETAPES[mode];
  const progression = Math.round(((etape + 1) / (phases.length + 1)) * 100);

  useEffect(() => {
    setEtape(0);
    const timer = setInterval(() => setEtape((valeur) => Math.min(valeur + 1, phases.length - 1)), 850);
    return () => clearInterval(timer);
  }, [mode, phases.length]);

  return (
    <div className="grid gap-8 md:grid-cols-[280px_1fr] md:items-center" role="status" aria-live="polite">
      <div className="relative mx-auto h-[260px] w-[260px]">
        <svg viewBox="0 0 260 260" className="h-full w-full -rotate-90" aria-hidden="true">
          <defs><linearGradient id="analyse-prisme"><stop stopColor="#FF2D78" /><stop offset="0.5" stopColor="#BF5AF2" /><stop offset="1" stopColor="#0A84FF" /></linearGradient></defs>
          <circle cx="130" cy="130" r="105" fill="none" stroke="rgba(255,255,255,.10)" strokeWidth="12" />
          <circle cx="130" cy="130" r="105" fill="none" stroke="url(#analyse-prisme)" strokeWidth="12" strokeLinecap="round" pathLength="100" strokeDasharray="100" strokeDashoffset={100 - progression} className="transition-[stroke-dashoffset] duration-700 ease-out" />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-12">
          <span className="text-4xl font-semibold tabular-nums">{progression}%</span>
          <span className="mt-2 text-[10px] font-bold uppercase tracking-[0.2em] text-white/55">Analyse en cours</span>
        </div>
      </div>
      <div className="min-w-0">
        {texte && <p className="mb-5 line-clamp-3 text-sm italic leading-relaxed text-white/55">« {texte} »</p>}
        <ol className="space-y-3">
          {phases.map((phase, index) => (
            <li key={phase} className={`flex items-center gap-3 text-sm transition-colors duration-300 ${index <= etape ? "text-white" : "text-white/30"}`}>
              {index < etape ? <Check className="h-4 w-4 text-[#64D2FF]" /> : <Circle className={`h-4 w-4 ${index === etape ? "fill-[#BF5AF2] text-[#BF5AF2] animate-pulse" : "text-white/20"}`} />}
              <span className={index === etape ? "font-semibold" : ""}>{phase}{index === etape ? "…" : ""}</span>
            </li>
          ))}
        </ol>
      </div>
    </div>
  );
}