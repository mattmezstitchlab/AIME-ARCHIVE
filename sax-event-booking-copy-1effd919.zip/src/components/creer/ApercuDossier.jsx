import React from "react";
import CadranCausal from "@/components/evenements/CadranCausal";
import { Loader2, Check, RefreshCw, Lock, CloudSun } from "lucide-react";

const TAG_STYLE = {
  sacre: "bg-[#FF2D78]/20 text-[#FF6BA3]",
  immuable: "bg-[#FF9F0A]/20 text-[#FFC46B]",
};

// Aperçu du dossier généré : déroulé, acteurs, budget — avant validation.
export default function ApercuDossier({ dossier, onValider, onRecommencer, enCours }) {
  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5 md:p-6">
        <p className="mb-2 text-center text-[11px] font-semibold uppercase tracking-wider text-white/40">Votre cadran causal</p>
        <CadranCausal moments={dossier.moments} />
      </div>

      <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5 md:p-6">
        <p className="text-[11px] font-semibold uppercase tracking-wider text-white/40 mb-4">Votre déroulé</p>
        <ol className="space-y-2">
          {dossier.moments.map((m, i) => (
            <li key={i} className="flex items-start gap-3 text-sm">
              <span className="shrink-0 w-24 tabular-nums text-white/50">{m.heureDebut}{m.heureFin ? `–${m.heureFin}` : ""}</span>
              <span className="flex-1 text-white/85">
                {m.titre}
                {m.tag && (
                  <span className={`ml-2 inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-semibold ${TAG_STYLE[m.tag]}`}>
                    <Lock className="h-2.5 w-2.5" /> {m.tag === "sacre" ? "sacré" : "immuable"}
                  </span>
                )}
                {m.exposition === "exterieur" && (
                  <span className="ml-2 inline-flex items-center gap-1 rounded-full bg-[#0A84FF]/20 px-2 py-0.5 text-[10px] font-semibold text-[#64D2FF]">
                    <CloudSun className="h-2.5 w-2.5" /> extérieur{m.planB ? " · plan B prévu" : ""}
                  </span>
                )}
              </span>
              {m.cout > 0 && <span className="shrink-0 text-white/40 tabular-nums">{Math.round(m.cout)} €</span>}
            </li>
          ))}
        </ol>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
          <p className="text-[11px] font-semibold uppercase tracking-wider text-white/40 mb-3">Les acteurs</p>
          <ul className="space-y-1.5 text-sm text-white/80">
            {dossier.acteurs.map((a, i) => (
              <li key={i}>{a.nom}{a.role ? <span className="text-white/40"> — {a.role}</span> : null}</li>
            ))}
          </ul>
        </div>
        <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5 flex flex-col justify-center">
          <p className="text-[11px] font-semibold uppercase tracking-wider text-white/40">Budget prévisionnel</p>
          <p className="mt-2 text-3xl font-semibold texte-prisme">{Math.round(dossier.budgetPrevisionnel || 0).toLocaleString("fr-FR")} €</p>
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        <button
          onClick={onValider}
          disabled={enCours}
          className="inline-flex items-center gap-2 min-h-[52px] px-7 rounded-full bg-gradient-to-r from-[#BF5AF2] to-[#0A84FF] text-sm font-bold text-white hover:opacity-90 disabled:opacity-40 transition-opacity"
        >
          {enCours ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />}
          {enCours ? "Création du dossier…" : "Créer mon événement"}
        </button>
        <button
          onClick={onRecommencer}
          disabled={enCours}
          className="inline-flex items-center gap-2 min-h-[52px] px-6 rounded-full bg-white/10 text-sm font-semibold text-white hover:bg-white/20 disabled:opacity-40 transition-colors"
        >
          <RefreshCw className="h-4 w-4" /> Recommencer
        </button>
      </div>
    </div>
  );
}