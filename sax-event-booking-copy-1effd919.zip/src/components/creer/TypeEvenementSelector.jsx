import React from "react";
import { MODELES_EVENEMENTS } from "@/lib/modelesEvenements";

export default function TypeEvenementSelector({ value, onChange }) {
  const modele = MODELES_EVENEMENTS[value];

  return (
    <div className="relative overflow-hidden rounded-2xl border border-white/15 bg-white/[0.04] p-4 sm:p-5">
      <span className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-[#FF9F0A] via-[#BF5AF2] to-[#0A84FF]" aria-hidden="true" />
      <label htmlFor="type-evenement" className="text-[11px] font-bold uppercase tracking-[0.24em] text-white/45">Nature de l’événement</label>
      <div className="mt-3 flex min-w-0 items-center gap-3">
        <span className="h-3 w-3 shrink-0 rounded-full bg-gradient-to-br from-[#FF2D78] via-[#BF5AF2] to-[#0A84FF] shadow-[0_0_18px_rgba(191,90,242,0.8)]" aria-hidden="true" />
        <select id="type-evenement" value={value} onChange={(e) => onChange(e.target.value)} className="min-h-[48px] min-w-0 flex-1 rounded-xl border border-white/10 bg-[#141416] px-4 text-sm font-semibold text-white focus:outline-none focus:ring-2 focus:ring-[#BF5AF2]">
          {Object.entries(MODELES_EVENEMENTS).map(([cle, item]) => <option key={cle} value={cle}>{item.libelle}</option>)}
        </select>
      </div>
      <p className="mt-3 text-sm leading-relaxed text-white/55">{modele.description}</p>
    </div>
  );
}