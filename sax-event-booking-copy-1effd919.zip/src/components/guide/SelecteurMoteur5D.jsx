import React from "react";
import { DIMENSIONS_5D } from "@/lib/moteur5dEvenement";

export default function SelecteurMoteur5D({ choix, onChange }) {
  return <div className="space-y-5">
    {DIMENSIONS_5D.map((dimension, axe) => <fieldset key={dimension.id} className="rounded-2xl border border-border bg-card p-4">
      <legend className="px-1 text-sm font-bold text-foreground"><span className="mr-2 text-muted-foreground">{axe + 1}/5</span>{dimension.question}</legend>
      <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
        {dimension.reponses.map((reponse, valeur) => <button key={reponse.label} type="button" aria-pressed={choix[axe] === valeur} onClick={() => onChange(axe, valeur)} className={`min-h-11 rounded-xl border px-3 py-2 text-xs font-semibold transition-colors focus-visible:ring-2 focus-visible:ring-ring ${choix[axe] === valeur ? "border-accent bg-accent text-accent-foreground" : "border-border bg-background text-muted-foreground hover:text-foreground"}`}>{reponse.label}</button>)}
      </div>
    </fieldset>)}
  </div>;
}