import React from "react";
import { ExternalLink } from "lucide-react";

const SOURCES = [
  ["ISO 31000:2018", "Incertitude, objectifs et décision contextualisée.", "https://www.iso.org/obp/ui/#iso:std:iso:31000:ed-2:v1:en"],
  ["ISO 22301:2019", "Continuité, dépendances et ressources nécessaires.", "https://www.iso.org/obp/ui/en/#!iso:std:75106:en"],
  ["GIEC · AR6 WGII", "Aléa physique, exposition, vulnérabilité et adaptation.", "https://www.ipcc.ch/report/ar6/wg2/"],
  ["NASA · Human Factors", "Capacités humaines, coordination et performance opérationnelle.", "https://www.nasa.gov/reference/jsc-human-factors-performance/"],
  ["Reason · 1990", "Défaillances actives et conditions latentes des systèmes complexes.", "https://ui.adsabs.harvard.edu/abs/1990RSPTB.327..475R/abstract"],
  ["Nations unies · Intégrité", "Exactitude, cohérence et fiabilité de l’information.", "https://digitallibrary.un.org/record/4090928/files/1441689-en.pdf"],
];

export default function SourcesMoteur5D() {
  return <section className="mt-12 rounded-3xl border border-border bg-card p-6" aria-labelledby="sources-5d"><h2 id="sources-5d" className="font-heading text-2xl">Fondements et limites</h2><p className="mt-3 max-w-3xl text-sm leading-6 text-muted-foreground">Les cinq axes synthétisent ces référentiels reconnus. La matrice de 1 024 positions est une convention Aime Event : elle organise les observations, mais ne constitue ni une preuve scientifique, ni une probabilité, ni un diagnostic de risque.</p><div className="mt-5 grid gap-3 md:grid-cols-2">{SOURCES.map(([nom, apport, url]) => <a key={nom} href={url} target="_blank" rel="noreferrer" className="group flex min-h-20 items-start justify-between gap-3 rounded-2xl border border-border bg-background p-4 focus-visible:ring-2 focus-visible:ring-ring"><span><strong className="text-sm text-foreground">{nom}</strong><span className="mt-1 block text-xs leading-5 text-muted-foreground">{apport}</span></span><ExternalLink className="h-4 w-4 shrink-0 text-muted-foreground group-hover:text-foreground" aria-hidden="true" /></a>)}</div></section>;
}