import React from "react";

const Bloc = ({ mot, texte }) => <div className="border-t border-border py-4"><p className="mb-1 text-xs font-black uppercase tracking-[0.2em] text-muted-foreground">{mot}</p><p className="text-sm leading-6 text-foreground">{texte}.</p></div>;

export default function ResultatMoteur5D({ signature }) {
  return <aside aria-live="polite" className="rounded-3xl border border-border bg-card p-5 sm:p-6 lg:sticky lg:top-6">
    <div className="flex items-start justify-between gap-4"><div><p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Signature causale</p><h2 className="mt-1 font-heading text-3xl">N° {String(signature.numero).padStart(4, "0")}</h2></div><span className="rounded-full bg-secondary px-3 py-1 text-xs font-bold text-secondary-foreground">{signature.niveau}</span></div>
    <div className="mt-5"><Bloc mot="Si" texte={signature.si} /><Bloc mot="Alors" texte={signature.alors} /><Bloc mot="Parce que" texte={signature.parceQue} /></div>
    <p className="mt-2 text-xs leading-5 text-muted-foreground">Cette lecture explique une combinaison de facteurs. Elle ne modifie jamais un événement et doit être confirmée avec ses données réelles.</p>
  </aside>;
}