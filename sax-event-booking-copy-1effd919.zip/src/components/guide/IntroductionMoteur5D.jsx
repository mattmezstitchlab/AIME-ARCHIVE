import React from "react";
import { CircleDot, Layers3, ShieldCheck } from "lucide-react";

const points = [
  [CircleDot, "5 observations", "Temps, milieu, moyens, acteurs et information."],
  [Layers3, "4 états par axe", "Une combinaison produit 4⁵, soit 1 024 positions traçables."],
  [ShieldCheck, "Validation humaine", "Le moteur explique et simule, mais ne décide jamais seul."],
];

export default function IntroductionMoteur5D() {
  return <div className="grid gap-3 sm:grid-cols-3">{points.map(([Icone, titre, texte]) => <div key={titre} className="rounded-2xl border border-border bg-card p-4"><Icone className="h-5 w-5 text-accent" aria-hidden="true" /><h2 className="mt-3 text-sm font-bold">{titre}</h2><p className="mt-1 text-xs leading-5 text-muted-foreground">{texte}</p></div>)}</div>;
}