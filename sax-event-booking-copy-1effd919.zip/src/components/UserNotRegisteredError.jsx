import React from 'react';

const UserNotRegisteredError = () => {
  return (
    <div className="theme-apple flex min-h-screen flex-col items-center justify-center bg-[#050506] px-4">
      <div className="max-w-md w-full p-8 bg-white rounded-2xl shadow-lg border border-white/10">
        <div className="text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 mb-6 rounded-full bg-orange-100">
            <svg className="w-8 h-8 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
          </div>
          <h1 className="text-3xl font-bold text-slate-900 mb-4">Accès à confirmer</h1>
          <p className="text-slate-600 mb-8">
            Ce compte ne peut pas encore accéder à Aime Event. Vérifiez le compte utilisé ou demandez une invitation à l’organisateur.
          </p>
          <div className="p-4 bg-slate-50 rounded-md text-sm text-slate-600">
            <p>Vous pouvez :</p>
            <ul className="list-disc list-inside mt-2 space-y-1">
              <li>vérifier l’adresse e-mail utilisée ;</li>
              <li>demander une invitation à l’organisateur ;</li>
              <li>vous déconnecter puis vous reconnecter.</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserNotRegisteredError;