import React from "react";
import { Star, Loader2 } from "lucide-react";

export default function ListeTemoignages({ temoignages, chargement }) {
  if (chargement) {
    return (
      <div className="flex justify-center py-16">
        <Loader2 className="h-7 w-7 animate-spin text-[var(--p-accent)]" />
      </div>
    );
  }

  if (!temoignages.length) {
    return (
      <p className="text-center text-[var(--p-muted)] py-12">
        Aucun témoignage pour le moment. Soyez le premier à partager votre expérience !
      </p>
    );
  }

  return (
    <div className="space-y-14">
      {temoignages.map((t) => (
        <article key={t.id} className="max-w-2xl mx-auto text-center">
          <div className="flex items-center justify-center gap-1 mb-5" aria-label={`Note : ${t.note} sur 5`}>
            {[1, 2, 3, 4, 5].map((n) => (
              <Star key={n}
                className={`h-4 w-4 ${n <= t.note ? "fill-[var(--p-gold)] text-[var(--p-gold)]" : "text-[var(--p-border-strong)]"}`} />
            ))}
          </div>
          <blockquote className="font-heading text-xl md:text-2xl leading-relaxed text-[var(--p-text)]">
            « {t.message} »
          </blockquote>
          <footer className="mt-5">
            <p className="font-bold text-sm text-[var(--p-text)]">{t.nom}</p>
            {t.typeEvenement && (
              <p className="text-xs uppercase tracking-[0.25em] text-[var(--p-accent)] mt-1.5">{t.typeEvenement}</p>
            )}
          </footer>
        </article>
      ))}
    </div>
  );
}