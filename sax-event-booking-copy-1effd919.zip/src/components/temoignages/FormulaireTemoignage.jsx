import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Star, Loader2, AlertCircle, CheckCircle2 } from "lucide-react";

const classeInput =
  "min-h-[48px] w-full rounded-lg border border-[var(--p-border-strong)] bg-[var(--p-surface)] px-4 py-3 text-[var(--p-text)] placeholder:text-[var(--p-faint)] focus:border-[var(--p-accent)] focus:outline-none focus:ring-1 focus:ring-[var(--p-accent)]";

export default function FormulaireTemoignage({ onEnvoye, proprietaire }) {
  const [valeurs, setValeurs] = useState({ nom: "", typeEvenement: "", note: 0, message: "", siteWeb: "" });
  const [envoi, setEnvoi] = useState(false);
  const [erreur, setErreur] = useState("");
  const [succes, setSucces] = useState(false);

  const soumettre = async (ev) => {
    ev.preventDefault();
    setErreur("");
    if (!valeurs.nom.trim() || !valeurs.message.trim() || valeurs.note < 1) {
      setErreur("Merci d'indiquer votre nom, une note et votre message.");
      return;
    }
    setEnvoi(true);
    try {
      await base44.functions.invoke("temoignages", { action: "envoyer", proprietaire, ...valeurs });
      setSucces(true);
      setValeurs({ nom: "", typeEvenement: "", note: 0, message: "", siteWeb: "" });
      onEnvoye?.();
    } catch (_e) {
      setErreur("Une erreur est survenue. Merci de réessayer.");
    } finally {
      setEnvoi(false);
    }
  };

  if (succes) {
    return (
      <div role="status" className="rounded-xl border border-[var(--p-border)] bg-[var(--p-surface)] p-8 text-center">
        <CheckCircle2 className="h-10 w-10 text-[var(--p-accent)] mx-auto mb-3" />
        <p className="font-heading text-xl text-[var(--p-text)]">Merci pour votre témoignage !</p>
        <p className="mt-2 text-sm text-[var(--p-muted)]">Votre avis a bien été reçu — il sera publié après validation.</p>
      </div>
    );
  }

  return (
    <form onSubmit={soumettre} noValidate className="rounded-xl border border-[var(--p-border)] bg-[var(--p-surface)] p-6 md:p-8 space-y-5">
      <h2 className="font-heading text-2xl text-[var(--p-text)]">Partagez votre expérience</h2>
      <div className="absolute -left-[9999px]" aria-hidden="true">
        <input type="text" tabIndex={-1} autoComplete="off" value={valeurs.siteWeb}
          onChange={(ev) => setValeurs((v) => ({ ...v, siteWeb: ev.target.value }))} />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <input type="text" placeholder="Votre nom" value={valeurs.nom} aria-label="Votre nom"
          onChange={(ev) => setValeurs((v) => ({ ...v, nom: ev.target.value }))} className={classeInput} />
        <input type="text" placeholder="Occasion (mariage, cocktail…)" value={valeurs.typeEvenement}
          aria-label="Occasion du témoignage"
          onChange={(ev) => setValeurs((v) => ({ ...v, typeEvenement: ev.target.value }))} className={classeInput} />
      </div>
      <div className="flex items-center gap-1" role="radiogroup" aria-label="Votre note">
        {[1, 2, 3, 4, 5].map((n) => (
          <button key={n} type="button" onClick={() => setValeurs((v) => ({ ...v, note: n }))}
            aria-label={`${n} étoile${n > 1 ? "s" : ""}`} className="p-1">
            <Star className={`h-7 w-7 ${n <= valeurs.note ? "fill-[var(--p-gold)] text-[var(--p-gold)]" : "text-[var(--p-border-strong)]"}`} />
          </button>
        ))}
      </div>
      <textarea rows={4} maxLength={800} placeholder="Votre témoignage…" value={valeurs.message}
        aria-label="Votre témoignage"
        onChange={(ev) => setValeurs((v) => ({ ...v, message: ev.target.value }))}
        className={`${classeInput} resize-y min-h-[110px]`} />
      {erreur && (
        <p role="alert" className="flex items-center gap-2 text-sm text-[var(--p-error)]">
          <AlertCircle className="h-4 w-4 shrink-0" /> {erreur}
        </p>
      )}
      <button type="submit" disabled={envoi}
        className="w-full min-h-[50px] rounded-full bg-[var(--p-cta)] text-[var(--p-cta-text)] font-bold hover:bg-[var(--p-cta-hover)] transition-colors disabled:opacity-70 flex items-center justify-center gap-2">
        {envoi ? (<><Loader2 className="h-5 w-5 animate-spin" /> Envoi…</>) : "Publier mon témoignage"}
      </button>
    </form>
  );
}