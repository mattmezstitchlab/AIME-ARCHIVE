import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import Compteur507 from "@/components/intermittent/Compteur507";
import EcheancesIntermittent from "@/components/intermittent/EcheancesIntermittent";
import CoffreJustificatifs from "@/components/intermittent/CoffreJustificatifs";
import { Loader2, Info } from "lucide-react";

// Types de documents émis qui correspondent à un cachet.
const TYPES_CACHET = ["recuCachet", "ficheCachet", "aem"];

export default function TableauIntermittence({ email }) {
  const [cachets, setCachets] = useState(null);
  const [documents, setDocuments] = useState(null);
  const [importEnCours, setImportEnCours] = useState(false);

  useEffect(() => {
    base44.entities.CachetIntermittent.filter({ proprietaire: email }, "-date", 200).then(setCachets);
    base44.entities.DocumentEmis.filter({ proprietaire: email }, "-created_date", 200).then(setDocuments);
  }, [email]);

  if (cachets === null || documents === null) {
    return (
      <div className="flex justify-center py-14">
        <Loader2 className="h-6 w-6 animate-spin text-[#8A7356]" />
      </div>
    );
  }

  const dejaImportes = new Set(cachets.map((c) => c.sourceDocumentId).filter(Boolean));
  const importables = documents.filter((d) => TYPES_CACHET.includes(d.type) && d.dateEvenement && !dejaImportes.has(d.id));

  const importerDepuisDocuments = async () => {
    setImportEnCours(true);
    try {
      const crees = await base44.entities.CachetIntermittent.bulkCreate(
        importables.map((d) => ({
          proprietaire: email,
          date: d.dateEvenement,
          libelle: d.description || `Prestation — ${d.clientNom}`,
          employeur: d.clientNom,
          cachets: 1,
          heures: 12,
          sourceDocumentId: d.id,
        }))
      );
      setCachets((l) => [...crees, ...l].sort((a, b) => String(b.date).localeCompare(String(a.date))));
    } finally {
      setImportEnCours(false);
    }
  };

  const ajouterCachet = async (data) => {
    const cree = await base44.entities.CachetIntermittent.create({ ...data, proprietaire: email });
    setCachets((l) => [cree, ...l].sort((a, b) => String(b.date).localeCompare(String(a.date))));
  };

  const supprimerCachet = async (id) => {
    setCachets((l) => l.filter((c) => c.id !== id));
    await base44.entities.CachetIntermittent.delete(id);
  };

  return (
    <div className="space-y-6">
      {/* Cadre légal — la plateforme prépare, les déclarations officielles restent sur les sites officiels */}
      <div className="flex items-start gap-3 rounded-xl border border-[#B49B72]/25 bg-[#FAF7F2] p-4 text-sm text-[#57534E]">
        <Info className="h-4 w-4 mt-0.5 shrink-0 text-[#8A7356]" />
        <p>
          Cet espace rassemble votre suivi d'intermittence : il prépare vos démarches mais ne remplace pas les
          déclarations officielles, qui s'effectuent toujours sur urssaf.fr, guso.fr et francetravail.fr.
          Les informations affichées publiquement aux employeurs se règlent dans « Mon profil » → onglet « Intermittent ».
        </p>
      </div>

      <Compteur507
        cachets={cachets}
        onAjouter={ajouterCachet}
        onSupprimer={supprimerCachet}
        nbImportables={importables.length}
        onImporter={importerDepuisDocuments}
        importEnCours={importEnCours}
      />

      <div className="grid gap-6 lg:grid-cols-2">
        <EcheancesIntermittent documents={documents} />
        <CoffreJustificatifs email={email} />
      </div>
    </div>
  );
}