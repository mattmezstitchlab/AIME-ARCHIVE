import React from "react";
import { CalendarClock, ExternalLink } from "lucide-react";

const aujourdhui = () => new Date().toISOString().slice(0, 10);
const formatFr = (iso) => iso.split("-").reverse().join("/");

export default function EcheancesIntermittent({ documents }) {
  const auj = aujourdhui();
  const maintenant = new Date();
  const moisCourant = auj.slice(0, 7);

  // DPAE : prestations à venir tirées des documents émis.
  const prestationsAVenir = [...new Map(
    documents
      .filter((d) => d.dateEvenement && d.dateEvenement >= auj)
      .map((d) => [d.dateEvenement, d])
  ).values()].sort((a, b) => a.dateEvenement.localeCompare(b.dateEvenement)).slice(0, 3);

  const prestationsDuMois = documents.filter((d) => d.dateEvenement && d.dateEvenement.startsWith(moisCourant));

  const echeances = [
    ...prestationsAVenir.map((d) => ({
      titre: `DPAE avant le ${formatFr(d.dateEvenement)}`,
      detail: `Prestation « ${d.description || d.clientNom} » — la déclaration préalable à l'embauche se fait avant la date, sur urssaf.fr ou via le GUSO.`,
      lien: "https://www.urssaf.fr",
      libelleLien: "urssaf.fr",
    })),
    ...(prestationsDuMois.length > 0
      ? [{
          titre: "AEM à établir en fin de mois",
          detail: `${prestationsDuMois.length} prestation${prestationsDuMois.length > 1 ? "s" : ""} ce mois-ci — l'attestation employeur mensuelle se déclare sur l'espace employeur France Travail Spectacle.`,
          lien: "https://www.francetravail.fr",
          libelleLien: "francetravail.fr",
        }]
      : []),
    {
      titre: "Actualisation France Travail",
      detail: `Chaque mois, à partir du 28 et jusqu'au 15 du mois suivant${maintenant.getDate() >= 28 ? " — la fenêtre est ouverte" : ""}.`,
      lien: "https://www.francetravail.fr",
      libelleLien: "francetravail.fr",
    },
  ];

  return (
    <div className="rounded-xl border border-[#B49B72]/25 bg-white p-5 md:p-6">
      <h2 className="font-heading text-xl font-semibold tracking-tight">Échéances à venir</h2>
      <p className="mt-1 text-sm text-[#57534E]">Calculées à partir de vos documents émis.</p>
      <ul className="mt-4 space-y-3">
        {echeances.map((e, i) => (
          <li key={i} className="flex items-start gap-3">
            <span className="mt-0.5 h-8 w-8 shrink-0 inline-flex items-center justify-center rounded-full bg-[#FAF7F2] text-[#8A7356]">
              <CalendarClock className="h-4 w-4" />
            </span>
            <div className="min-w-0">
              <p className="text-sm font-semibold">{e.titre}</p>
              <p className="text-xs text-[#57534E]">{e.detail}</p>
              <a href={e.lien} target="_blank" rel="noopener noreferrer" className="mt-0.5 inline-flex items-center gap-1 text-xs font-medium text-[#8A7356] hover:text-[#1C1917] transition-colors">
                {e.libelleLien} <ExternalLink className="h-3 w-3" />
              </a>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}