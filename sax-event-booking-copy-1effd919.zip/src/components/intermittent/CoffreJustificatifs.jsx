import React, { useEffect, useState, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { Upload, Trash2, FileText, Loader2, ExternalLink } from "lucide-react";

const CATEGORIES = {
  contrat: "Contrat signé",
  feuilletGuso: "Feuillet GUSO",
  bulletinPaie: "Bulletin de paie",
  aem: "AEM",
  dpae: "DPAE",
  autre: "Autre",
};

export default function CoffreJustificatifs({ email }) {
  const [justificatifs, setJustificatifs] = useState(null);
  const [categorie, setCategorie] = useState("contrat");
  const [envoi, setEnvoi] = useState(false);
  const fichierRef = useRef(null);

  useEffect(() => {
    base44.entities.JustificatifIntermittent.filter({ proprietaire: email }, "-created_date", 100).then(setJustificatifs);
  }, [email]);

  const televerser = async (e) => {
    const fichier = e.target.files?.[0];
    if (!fichier) return;
    setEnvoi(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file: fichier });
      const cree = await base44.entities.JustificatifIntermittent.create({
        proprietaire: email,
        titre: fichier.name,
        categorie,
        date: new Date().toISOString().slice(0, 10),
        fichierUrl: file_url,
      });
      setJustificatifs((l) => [cree, ...(l || [])]);
    } finally {
      setEnvoi(false);
      e.target.value = "";
    }
  };

  const supprimer = async (id) => {
    setJustificatifs((l) => l.filter((j) => j.id !== id));
    await base44.entities.JustificatifIntermittent.delete(id);
  };

  return (
    <div className="rounded-xl border border-[#B49B72]/25 bg-white p-5 md:p-6">
      <h2 className="font-heading text-xl font-semibold tracking-tight">Coffre à justificatifs</h2>
      <p className="mt-1 text-sm text-[#57534E]">Contrats signés, feuillets GUSO, bulletins de paie — tout au même endroit.</p>

      <div className="mt-4 flex flex-wrap items-center gap-2">
        <select
          value={categorie}
          onChange={(e) => setCategorie(e.target.value)}
          aria-label="Catégorie du justificatif"
          className="min-h-[40px] rounded-lg border border-[#B49B72]/40 bg-white px-3 text-sm focus:outline-none focus:border-[#8A7356]"
        >
          {Object.entries(CATEGORIES).map(([v, l]) => <option key={v} value={v}>{l}</option>)}
        </select>
        <button
          onClick={() => fichierRef.current?.click()}
          disabled={envoi}
          className="inline-flex items-center gap-2 min-h-[40px] px-4 rounded-full bg-[#1C1917] text-[#FAF7F2] text-sm font-semibold hover:bg-[#33302B] transition-colors disabled:opacity-60"
        >
          {envoi ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />} Téléverser un document
        </button>
        <input ref={fichierRef} type="file" className="hidden" onChange={televerser} accept=".pdf,.jpg,.jpeg,.png" />
      </div>

      {justificatifs === null ? (
        <div className="flex justify-center py-8"><Loader2 className="h-5 w-5 animate-spin text-[#8A7356]" /></div>
      ) : justificatifs.length === 0 ? (
        <p className="mt-5 text-sm text-[#57534E] text-center py-4">Aucun justificatif pour le moment.</p>
      ) : (
        <ul className="mt-5 divide-y divide-[#B49B72]/15 border-t border-[#B49B72]/15">
          {justificatifs.map((j) => (
            <li key={j.id} className="flex items-center gap-3 py-2.5 text-sm">
              <FileText className="h-4 w-4 shrink-0 text-[#8A7356]" />
              <span className="flex-1 min-w-0 truncate">{j.titre}</span>
              <span className="hidden sm:inline text-xs text-[#57534E] px-2 py-0.5 rounded-full bg-[#FAF7F2]">{CATEGORIES[j.categorie] || "Autre"}</span>
              {j.date && <span className="hidden md:inline text-xs tabular-nums text-[#57534E]">{j.date.split("-").reverse().join("/")}</span>}
              <a href={j.fichierUrl} target="_blank" rel="noopener noreferrer" aria-label={`Ouvrir ${j.titre}`} className="p-1.5 rounded-full text-[#57534E] hover:text-[#1C1917] hover:bg-[#FAF7F2] transition-colors">
                <ExternalLink className="h-4 w-4" />
              </a>
              <button onClick={() => supprimer(j.id)} aria-label={`Supprimer ${j.titre}`} className="p-1.5 rounded-full text-[#57534E] hover:text-red-600 hover:bg-red-50 transition-colors">
                <Trash2 className="h-4 w-4" />
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}