import React, { useState } from "react";
import { Plus, Trash2, Download, Loader2 } from "lucide-react";

const VIDE = { date: "", libelle: "", employeur: "", cachets: 1, heures: "" };

export default function Compteur507({ cachets, onAjouter, onSupprimer, nbImportables, onImporter, importEnCours }) {
  const [ouvert, setOuvert] = useState(false);
  const [f, setF] = useState(VIDE);

  // Fenêtre glissante de 12 mois — la règle des annexes 8 et 10.
  const limite = new Date();
  limite.setFullYear(limite.getFullYear() - 1);
  const surPeriode = cachets.filter((c) => c.date && new Date(c.date) >= limite);
  const heures = surPeriode.reduce((t, c) => t + (Number(c.heures) || (Number(c.cachets) || 1) * 12), 0);
  const nbCachets = surPeriode.reduce((t, c) => t + (Number(c.cachets) || 1), 0);
  const pct = Math.min(100, Math.round((heures / 507) * 100));

  const ajouter = (e) => {
    e.preventDefault();
    if (!f.date) return;
    onAjouter({
      date: f.date,
      libelle: f.libelle,
      employeur: f.employeur,
      cachets: Number(f.cachets) || 1,
      heures: Number(f.heures) || (Number(f.cachets) || 1) * 12,
    });
    setF(VIDE);
    setOuvert(false);
  };

  const champ = "min-h-[40px] rounded-lg border border-[#B49B72]/40 bg-white px-3 text-sm focus:outline-none focus:border-[#8A7356]";

  return (
    <div className="rounded-xl border border-[#B49B72]/25 bg-white p-5 md:p-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h2 className="font-heading text-xl font-semibold tracking-tight">Compteur 507 heures</h2>
          <p className="mt-1 text-sm text-[#57534E]">Sur les 12 derniers mois — 1 cachet compte pour 12 heures.</p>
        </div>
        <p className="text-3xl md:text-4xl font-semibold tabular-nums">
          {heures.toLocaleString("fr-FR")} <span className="text-base text-[#57534E]">/ 507 h · {nbCachets} cachet{nbCachets > 1 ? "s" : ""}</span>
        </p>
      </div>

      <div className="mt-4 h-3 rounded-full bg-[#FAF7F2] overflow-hidden" role="progressbar" aria-valuenow={heures} aria-valuemin={0} aria-valuemax={507} aria-label="Progression vers les 507 heures">
        <div className={`h-full rounded-full transition-all ${heures >= 507 ? "bg-green-600" : "bg-[#1C1917]"}`} style={{ width: `${pct}%` }} />
      </div>
      <p className="mt-1.5 text-xs text-[#57534E]">
        {heures >= 507 ? "Seuil des 507 heures atteint sur la période." : `${(507 - heures).toLocaleString("fr-FR")} heures restantes pour atteindre le seuil.`}
      </p>

      <div className="mt-5 flex flex-wrap gap-2">
        <button onClick={() => setOuvert((v) => !v)} className="inline-flex items-center gap-2 min-h-[40px] px-4 rounded-full bg-[#1C1917] text-[#FAF7F2] text-sm font-semibold hover:bg-[#33302B] transition-colors">
          <Plus className="h-4 w-4" /> Ajouter un cachet
        </button>
        {nbImportables > 0 && (
          <button onClick={onImporter} disabled={importEnCours} className="inline-flex items-center gap-2 min-h-[40px] px-4 rounded-full border border-[#B49B72]/40 text-sm font-medium hover:bg-[#FAF7F2] transition-colors disabled:opacity-60">
            {importEnCours ? <Loader2 className="h-4 w-4 animate-spin" /> : <Download className="h-4 w-4" />}
            Importer {nbImportables} cachet{nbImportables > 1 ? "s" : ""} depuis mes documents
          </button>
        )}
      </div>

      {ouvert && (
        <form onSubmit={ajouter} className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-5 items-end">
          <label className="grid gap-1 text-xs font-medium text-[#57534E]">Date *
            <input type="date" required className={champ} value={f.date} onChange={(e) => setF({ ...f, date: e.target.value })} />
          </label>
          <label className="grid gap-1 text-xs font-medium text-[#57534E]">Prestation
            <input className={champ} placeholder="Concert, mariage…" value={f.libelle} onChange={(e) => setF({ ...f, libelle: e.target.value })} />
          </label>
          <label className="grid gap-1 text-xs font-medium text-[#57534E]">Employeur
            <input className={champ} value={f.employeur} onChange={(e) => setF({ ...f, employeur: e.target.value })} />
          </label>
          <label className="grid gap-1 text-xs font-medium text-[#57534E]">Cachets
            <input type="number" min="1" className={champ} value={f.cachets} onChange={(e) => setF({ ...f, cachets: e.target.value })} />
          </label>
          <button type="submit" className="min-h-[40px] px-4 rounded-full bg-[#1C1917] text-[#FAF7F2] text-sm font-semibold hover:bg-[#33302B] transition-colors">
            Enregistrer
          </button>
        </form>
      )}

      {cachets.length > 0 && (
        <ul className="mt-5 divide-y divide-[#B49B72]/15 border-t border-[#B49B72]/15">
          {cachets.map((c) => (
            <li key={c.id} className="flex items-center gap-3 py-2.5 text-sm">
              <span className="w-24 shrink-0 tabular-nums text-[#57534E]">{c.date ? c.date.split("-").reverse().join("/") : "—"}</span>
              <span className="flex-1 min-w-0 truncate">{c.libelle || "Cachet"}{c.employeur ? ` — ${c.employeur}` : ""}</span>
              <span className="tabular-nums text-[#57534E]">{Number(c.heures) || (Number(c.cachets) || 1) * 12} h</span>
              <button onClick={() => onSupprimer(c.id)} aria-label="Supprimer ce cachet" className="p-1.5 rounded-full text-[#57534E] hover:text-red-600 hover:bg-red-50 transition-colors">
                <Trash2 className="h-4 w-4" />
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}