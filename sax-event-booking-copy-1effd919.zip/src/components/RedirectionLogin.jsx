import React from "react";
import { Navigate, useLocation } from "react-router-dom";

// Redirige vers la connexion en mémorisant uniquement le chemin interne demandé.
// Les briefs et données personnelles restent dans sessionStorage.
export default function RedirectionLogin() {
  const { pathname, search } = useLocation();
  const next = encodeURIComponent(pathname + search);
  return <Navigate to={`/login?next=${next}`} replace />;
}