import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Loader2, ImagePlus, Music } from "lucide-react";

const classeInput =
  "mt-1 min-h-[46px] w-full rounded-xl border border-black/10 bg-white px-3 text-sm text-[#1C1917] focus:outline-none focus:border-[#1C1917]";

export default function EtapeProfil({ profil, onChange }) {
  const [envoi, setEnvoi] = useState(false);

  const importerPhoto = async (e) => {
    const fichier = e.target.files?.[0];
    if (!fichier) return;
    setEnvoi(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file: fichier });
    onChange({ ...profil, photoProfilUrl: file_url });
    setEnvoi(false);
  };

  return (
    <div className="space-y-4">
      <div>
        <label className="text-xs font-bold uppercase tracking-wide text-[#57534E]">Votre nom affiché *</label>
        <input
          className={classeInput}
          value={profil.nomAffiche}
          onChange={(e) => onChange({ ...profil, nomAffiche: e.target.value })}
          placeholder="Nom de scène, société ou prénom"
        />
      </div>
      <div>
        <label className="text-xs font-bold uppercase tracking-wide text-[#57534E]">Sous-titre (facultatif)</label>
        <input
          className={classeInput}
          value={profil.sousTitre}
          onChange={(e) => onChange({ ...profil, sousTitre: e.target.value })}
          placeholder="Ex : Saxophoniste événementiel"
        />
      </div>

      <div className="rounded-2xl border border-dashed border-black/15 p-4">
        <p className="text-xs font-bold uppercase tracking-wide text-[#57534E]">Aller plus loin (facultatif)</p>
        <div className="mt-3 flex items-center gap-4">
          <div className="h-16 w-16 rounded-full bg-[#F5F5F7] overflow-hidden flex items-center justify-center shrink-0">
            {profil.photoProfilUrl ? (
              <img src={profil.photoProfilUrl} alt="Photo de profil" className="h-full w-full object-cover" />
            ) : (
              <Music className="h-6 w-6 text-black/25" />
            )}
          </div>
          <label className="inline-flex items-center gap-2 min-h-[42px] px-4 rounded-full border border-black/15 text-sm font-medium text-[#1C1917] cursor-pointer hover:border-black/40 transition-colors">
            {envoi ? <Loader2 className="h-4 w-4 animate-spin" /> : <ImagePlus className="h-4 w-4" />}
            Importer une photo de profil
            <input type="file" accept="image/*" className="hidden" onChange={importerPhoto} />
          </label>
        </div>
      </div>
    </div>
  );
}