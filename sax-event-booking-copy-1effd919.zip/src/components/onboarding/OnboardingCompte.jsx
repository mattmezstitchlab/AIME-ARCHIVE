import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import EtapeRole from "@/components/onboarding/EtapeRole";
import EtapeProfil from "@/components/onboarding/EtapeProfil";
import EtapeDocuments from "@/components/onboarding/EtapeDocuments";
import { Loader2, ArrowRight } from "lucide-react";

const FOND_FLORAL =
  "https://media.base44.com/images/public/6a525a256ebe909516a94e8c/c9026231a_generated_image.png";

const TITRES = {
  1: "Bienvenue ! Quel est votre rôle ?",
  2: "Votre présence sur Aime Event",
  3: "Vos informations professionnelles",
};
const ROLES_AVEC_PROFIL = new Set(["Je suis prestataire", "Je gère un lieu", "Je représente une agence"]);

function slugifier(texte) {
  return String(texte).toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
}

export default function OnboardingCompte({ email, onFermer }) {
  const [etape, setEtape] = useState(1);
  const [role, setRole] = useState({ rolePlateforme: "", domaine: "", categorie: "", sousCategorie: "" });
  const [profil, setProfil] = useState({ nomAffiche: "", sousTitre: "", photoProfilUrl: "" });
  const [infos, setInfos] = useState({});
  const [enCours, setEnCours] = useState(false);
  const totalEtapes = ROLES_AVEC_PROFIL.has(role.rolePlateforme) ? 3 : 1;

  const passer = async () => {
    await base44.auth.updateMe({ onboardingTermine: true });
    onFermer(false);
  };

  const terminer = async () => {
    setEnCours(true);
    await base44.auth.updateMe({ ...role, onboardingTermine: true });

    if (profil.nomAffiche.trim()) {
      let slug = slugifier(profil.nomAffiche) || `compte-${Math.random().toString(36).slice(2, 6)}`;
      const memes = await base44.entities.ProfilPrestataire.filter({ slug });
      if (memes.length) slug = `${slug}-${Math.random().toString(36).slice(2, 6)}`;
      await base44.entities.ProfilPrestataire.create({
        proprietaire: email,
        slug,
        typeProfil: role.rolePlateforme || "Je suis prestataire",
        nomAffiche: profil.nomAffiche.trim(),
        sousTitre: profil.sousTitre || [role.sousCategorie, role.domaine].filter(Boolean).join(" · "),
        photoProfilUrl: profil.photoProfilUrl || undefined,
        emailNotification: email,
      });
    }

    if (Object.values(infos).some(Boolean)) {
      await base44.entities.InformationsEntreprise.create({ proprietaire: email, ...infos });
    }

    onFermer(true);
  };

  const peutContinuer = etape === 1 ? !!role.rolePlateforme : etape === 2 ? !!profil.nomAffiche.trim() : true;

  return (
    <div className="theme-apple fixed inset-0 z-50 overflow-y-auto">
      <div className="fixed inset-0 bg-cover bg-center" style={{ backgroundImage: `url(${FOND_FLORAL})` }} aria-hidden="true" />
      <div className="fixed inset-0 bg-black/70" aria-hidden="true" />

      <div className="relative min-h-full flex items-center justify-center p-4">
        <div className="w-full max-w-lg rounded-3xl border border-white/10 bg-[var(--p-surface)]/95 p-6 text-[var(--p-text)] shadow-2xl backdrop-blur md:p-8">
          <div className="flex items-center justify-between">
            <p className="text-xs font-bold uppercase tracking-[0.25em] text-[#57534E]">Étape {etape} / {totalEtapes}</p>
            <div className="flex gap-1.5">
              {Array.from({ length: totalEtapes }, (_, i) => i + 1).map((n) => (
                <span key={n} className={`h-1.5 w-6 rounded-full ${n <= etape ? "bg-[#BF5AF2]" : "bg-white/10"}`} />
              ))}
            </div>
          </div>

          <h2 className="mt-4 font-heading text-2xl font-semibold tracking-tight text-[#1C1917]">{TITRES[etape]}</h2>

          <div className="mt-5">
            {etape === 1 ? (
              <EtapeRole role={role} onChange={setRole} />
            ) : etape === 2 ? (
              <EtapeProfil profil={profil} onChange={setProfil} />
            ) : (
              <EtapeDocuments infos={infos} onChange={setInfos} />
            )}
          </div>

          <div className="mt-7 flex items-center justify-between gap-3">
            <button onClick={passer} className="text-sm text-[#57534E] hover:text-[#1C1917] underline underline-offset-2 transition-colors">
              Passer pour l'instant
            </button>
            <button
              onClick={() => (etape < totalEtapes ? setEtape(etape + 1) : terminer())}
              disabled={!peutContinuer || enCours}
              className="inline-flex min-h-[48px] items-center gap-2 rounded-full bg-gradient-to-r from-[#BF5AF2] to-[#0A84FF] px-6 text-sm font-bold text-white transition-opacity hover:opacity-90 disabled:opacity-50"
            >
              {enCours ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
              {etape < totalEtapes ? "Continuer" : "Terminer"}
              {etape < totalEtapes && !enCours && <ArrowRight className="h-4 w-4" />}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}