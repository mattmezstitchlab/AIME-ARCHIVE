import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Loader2, FileUp, Check } from "lucide-react";

const SCHEMA_EXTRACTION = {
  type: "object",
  properties: {
    nomScene: { type: "string", description: "Nom commercial ou nom de scène de l'émetteur du document" },
    nomLegal: { type: "string", description: "Nom légal ou raison sociale de l'émetteur" },
    siret: { type: "string", description: "Numéro SIRET de l'émetteur" },
    tva: { type: "string", description: "Mention TVA (ex : TVA non applicable, article 293 B du CGI)" },
    adresse: { type: "string", description: "Adresse (rue) de l'émetteur" },
    ville: { type: "string", description: "Code postal et ville de l'émetteur" },
    telephone: { type: "string", description: "Téléphone de l'émetteur" },
    email: { type: "string", description: "E-mail de l'émetteur" },
    banque: { type: "string", description: "Nom de la banque" },
    iban: { type: "string" },
    bic: { type: "string" },
  },
};

const LIBELLES = {
  nomScene: "Nom commercial", nomLegal: "Nom légal", siret: "SIRET", tva: "TVA",
  adresse: "Adresse", ville: "Ville", telephone: "Téléphone", email: "E-mail",
  banque: "Banque", iban: "IBAN", bic: "BIC",
};

export default function EtapeDocuments({ infos, onChange }) {
  const [analyse, setAnalyse] = useState(false);
  const [erreur, setErreur] = useState("");

  const importer = async (e) => {
    const fichiers = Array.from(e.target.files || []);
    if (!fichiers.length) return;
    setAnalyse(true);
    setErreur("");
    try {
      let fusion = { ...infos };
      for (const fichier of fichiers) {
        const { file_url } = await base44.integrations.Core.UploadFile({ file: fichier });
        const resultat = await base44.integrations.Core.ExtractDataFromUploadedFile({
          file_url,
          json_schema: SCHEMA_EXTRACTION,
        });
        if (resultat.status === "success" && resultat.output) {
          const extrait = Array.isArray(resultat.output) ? resultat.output[0] : resultat.output;
          for (const [cle, valeur] of Object.entries(extrait || {})) {
            if (valeur && !fusion[cle]) fusion[cle] = String(valeur);
          }
        }
      }
      onChange(fusion);
    } catch {
      setErreur("L'analyse a échoué pour au moins un fichier. Vous pourrez compléter ces informations plus tard.");
    }
    setAnalyse(false);
  };

  const extraits = Object.entries(infos).filter(([, v]) => v);

  return (
    <div className="space-y-4">
      <p className="text-sm text-[#44403C] leading-relaxed">
        Importez un devis, une facture, un contrat ou un RIB actuels : nous en extrayons automatiquement
        vos informations (SIRET, coordonnées, IBAN…) pour préremplir votre compte. Vous pourrez ainsi
        générer vos propres documents en 30 secondes.
      </p>

      <label className="flex flex-col items-center justify-center gap-2 rounded-2xl border border-dashed border-black/20 py-8 cursor-pointer hover:border-black/40 transition-colors">
        {analyse ? <Loader2 className="h-6 w-6 animate-spin text-[#1C1917]" /> : <FileUp className="h-6 w-6 text-[#1C1917]" />}
        <span className="text-sm font-medium text-[#1C1917]">
          {analyse ? "Analyse en cours…" : "Importer vos documents (PDF ou image)"}
        </span>
        <span className="text-xs text-[#57534E]">Devis · Facture · Contrat · RIB — plusieurs fichiers possibles</span>
        <input type="file" multiple accept=".pdf,image/*" className="hidden" onChange={importer} disabled={analyse} />
      </label>

      {erreur && <p className="text-sm text-[#B3261E]" role="alert">{erreur}</p>}

      {extraits.length > 0 && (
        <div className="rounded-2xl bg-[#F5F5F7] p-4">
          <p className="text-xs font-bold uppercase tracking-wide text-[#57534E] flex items-center gap-1.5">
            <Check className="h-3.5 w-3.5 text-emerald-600" /> Informations détectées
          </p>
          <div className="mt-2 flex flex-wrap gap-1.5">
            {extraits.map(([cle, valeur]) => (
              <span key={cle} className="text-xs bg-white rounded-full px-3 py-1.5 text-[#44403C]">
                <strong>{LIBELLES[cle] || cle} :</strong> {valeur}
              </span>
            ))}
          </div>
          <p className="mt-2 text-[11px] text-[#57534E]">Modifiables à tout moment dans « Informations & Design ».</p>
        </div>
      )}

      <p className="text-xs text-[#57534E]">Cette étape est facultative — vous pouvez la passer.</p>
    </div>
  );
}