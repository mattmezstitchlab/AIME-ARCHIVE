import React from "react";

export const ROLES = [
  "J’organise un événement",
  "Je suis prestataire",
  "Je gère un lieu",
  "Je représente une agence",
  "Je découvre Aime Event",
];

export const DOMAINES = {
  "Musique & spectacle": {
    "Musicien / groupe": ["Saxophoniste", "DJ", "Chanteur·se", "Pianiste", "Violoniste", "Groupe live", "Autre"],
    "Artiste de scène": ["Danseur·se", "Magicien·ne", "Humoriste", "Performeur·se", "Autre"],
  },
  "Restauration & bar": {
    "Traiteur": ["Cuisine française", "Cuisine du monde", "Pâtisserie", "Food truck", "Autre"],
    "Bar & cocktails": ["Barman / mixologie", "Cave & vins", "Autre"],
  },
  "Photo & vidéo": {
    "Photographe": ["Mariage", "Entreprise", "Portrait", "Autre"],
    "Vidéaste": ["Mariage", "Entreprise", "Drone", "Autre"],
  },
  "Lieu & décoration": {
    "Lieu de réception": ["Domaine", "Salle", "Hôtel / restaurant", "Autre"],
    "Décoration": ["Fleuriste", "Scénographie", "Mobilier", "Autre"],
  },
  "Organisation": {
    "Wedding planner": ["Organisation complète", "Coordination jour J", "Autre"],
    "Event planner": ["Entreprise", "Privé", "Autre"],
  },
  "Beauté & bien-être": {
    "Coiffure & maquillage": ["Coiffeur·se", "Maquilleur·se", "Autre"],
  },
  "Autre domaine": {
    "Autre": ["Autre"],
  },
};

const classeSelect =
  "mt-1 min-h-[46px] w-full rounded-xl border border-black/10 bg-white px-3 text-sm text-[#1C1917] focus:outline-none focus:border-[#1C1917]";

function Choix({ libelle, valeur, options, onChange }) {
  return (
    <div>
      <label className="text-xs font-bold uppercase tracking-wide text-[#57534E]">{libelle}</label>
      <select className={classeSelect} value={valeur} onChange={(e) => onChange(e.target.value)}>
        <option value="">Choisir…</option>
        {options.map((o) => <option key={o} value={o}>{o}</option>)}
      </select>
    </div>
  );
}

export default function EtapeRole({ role, onChange }) {
  const categories = role.domaine ? Object.keys(DOMAINES[role.domaine] || {}) : [];
  const sousCategories = role.domaine && role.categorie ? DOMAINES[role.domaine]?.[role.categorie] || [] : [];

  return (
    <div className="space-y-4">
      <Choix
        libelle="Pourquoi êtes-vous ici ?"
        valeur={role.rolePlateforme}
        options={ROLES}
        onChange={(v) => onChange({ rolePlateforme: v, domaine: "", categorie: "", sousCategorie: "" })}
      />
      {role.rolePlateforme === "Je suis prestataire" && (
        <>
          <Choix
            libelle="Votre domaine"
            valeur={role.domaine}
            options={Object.keys(DOMAINES)}
            onChange={(v) => onChange({ ...role, domaine: v, categorie: "", sousCategorie: "" })}
          />
          {role.domaine && (
            <Choix
              libelle="Catégorie"
              valeur={role.categorie}
              options={categories}
              onChange={(v) => onChange({ ...role, categorie: v, sousCategorie: "" })}
            />
          )}
          {role.categorie && (
            <Choix
              libelle="Sous-catégorie"
              valeur={role.sousCategorie}
              options={sousCategories}
              onChange={(v) => onChange({ ...role, sousCategorie: v })}
            />
          )}
        </>
      )}
    </div>
  );
}