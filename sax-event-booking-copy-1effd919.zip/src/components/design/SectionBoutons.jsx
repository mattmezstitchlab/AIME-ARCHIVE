import React from "react";
import { Plus, Pencil, Trash2, Sun } from "lucide-react";

export default function SectionBoutons() {
  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center gap-3">
        <button className="inline-flex items-center gap-2 min-h-[44px] px-5 rounded-full bg-[#1C1917] text-[#FAF7F2] text-sm font-bold hover:bg-[#33302B] transition-colors">
          <Plus className="h-4 w-4" /> Action principale
        </button>
        <button className="min-h-[44px] px-6 rounded-full border border-[#B49B72]/40 text-sm text-[#44403C] hover:bg-[#FAF7F2] transition-colors">
          Action secondaire
        </button>
        <button className="inline-flex items-center gap-2 min-h-[44px] px-5 rounded-full bg-[#0071E3] text-white text-sm font-bold hover:bg-[#0077ED] transition-colors">
          CTA Apple (bleu)
        </button>
      </div>
      <div className="flex flex-wrap items-center gap-3">
        <button className="h-10 w-10 rounded-full bg-[#141416] text-white flex items-center justify-center" aria-label="Exemple icône"><Pencil className="h-4 w-4" /></button>
        <button className="h-10 w-10 rounded-xl border border-[#B49B72]/25 bg-white flex items-center justify-center text-[#57534E] hover:text-[#B3261E] hover:border-[#B3261E]/40 transition-colors" aria-label="Exemple suppression"><Trash2 className="h-4 w-4" /></button>
        <button className="h-10 w-10 rounded-full border border-[#B49B72]/40 flex items-center justify-center text-[#44403C]" aria-label="Exemple bascule"><Sun className="h-4 w-4" /></button>
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <span className="inline-flex items-center min-h-[40px] px-4 rounded-full text-sm font-medium bg-[#1C1917] text-[#FAF7F2]">Onglet actif</span>
        <span className="inline-flex items-center min-h-[40px] px-4 rounded-full text-sm font-medium bg-white border border-[#B49B72]/25 text-[#57534E]">Onglet inactif</span>
      </div>
    </div>
  );
}