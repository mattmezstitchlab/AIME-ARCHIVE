import React from "react";
import { CalendarDays, MapPin } from "lucide-react";

const classeInput =
  "mt-1 min-h-[44px] w-full rounded-lg border border-[#B49B72]/40 bg-white px-3 py-2 text-sm text-[#1C1917] focus:border-[#8A7356] focus:outline-none focus:ring-1 focus:ring-[#8A7356]/40";

export default function SectionComposants() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-xl">
        <div>
          <label className="text-xs font-bold uppercase tracking-wide text-[#8A7356]">Champ texte</label>
          <input className={classeInput} placeholder="Saisir une valeur…" />
        </div>
        <div>
          <label className="text-xs font-bold uppercase tracking-wide text-[#8A7356]">Liste déroulante</label>
          <select className={classeInput}><option>Option A</option><option>Option B</option></select>
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        <span className="px-2.5 py-1 rounded-full text-[11px] font-medium bg-black/5 text-[#57534E]">Brouillon</span>
        <span className="px-2.5 py-1 rounded-full text-[11px] font-medium bg-[#30D158]/15 text-[#1D7A38]">Confirmé</span>
        <span className="px-2.5 py-1 rounded-full text-[11px] font-medium bg-[#0071E3]/10 text-[#0071E3]">Réalisé</span>
        <span className="px-2.5 py-1 rounded-full text-[11px] font-medium bg-[#B3261E]/10 text-[#B3261E]">Annulé</span>
        <span className="px-3 py-1 rounded-full bg-[#0071E3]/20 text-[#0071E3] text-[11px] font-semibold">Bientôt disponible</span>
      </div>

      <div className="max-w-md rounded-xl border border-[#B49B72]/25 bg-white p-5 hover:border-[#8A7356] transition-colors">
        <p className="font-heading text-lg text-[#1C1917]">Carte type</p>
        <div className="mt-1.5 flex flex-wrap gap-4 text-sm text-[#57534E]">
          <span className="inline-flex items-center gap-1.5"><CalendarDays className="h-4 w-4" /> 22/08/2026</span>
          <span className="inline-flex items-center gap-1.5"><MapPin className="h-4 w-4" /> Lieu</span>
        </div>
      </div>

      <div className="max-w-md rounded-3xl bg-[#0A0A0C] text-white p-6">
        <p className="text-xs font-bold uppercase tracking-[0.25em] text-white/50">Carte sombre (cadran, sidebar)</p>
        <p className="mt-2 text-sm text-white/70">Utilisée pour le cadran causal, la barre latérale du compte et les accents « Event OS ».</p>
      </div>
    </div>
  );
}