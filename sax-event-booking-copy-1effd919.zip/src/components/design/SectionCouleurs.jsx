import React from "react";
import { CATEGORIES_ACTEURS } from "@/lib/acteursEvenement";

const GROUPES = [
  {
    titre: "Palette principale (site)",
    couleurs: [
      ["Crème (fond)", "#FAF7F2"],
      ["Noir encre (texte)", "#1C1917"],
      ["Gris chaud (texte doux)", "#44403C"],
      ["Gris pierre (secondaire)", "#57534E"],
      ["Champagne foncé (accent)", "#8A7356"],
      ["Champagne (bordures)", "#B49B72"],
      ["Erreur", "#B3261E"],
    ],
  },
  {
    titre: "Thème Apple (compte & profils)",
    couleurs: [
      ["Fond jour", "#F5F5F7"],
      ["Fond nuit", "#000000"],
      ["Surface sombre", "#141416"],
      ["Bleu action (CTA)", "#0071E3"],
      ["Or (accent)", "#FF9F0A"],
    ],
  },
  {
    titre: "Catégories d'acteurs (événements)",
    couleurs: Object.values(CATEGORIES_ACTEURS).map((c) => [c.libelle, c.couleur]),
  },
];

export default function SectionCouleurs() {
  return (
    <div className="space-y-6">
      {GROUPES.map((g) => (
        <div key={g.titre}>
          <h3 className="text-xs font-bold uppercase tracking-wide text-[#8A7356] mb-3">{g.titre}</h3>
          <div className="flex flex-wrap gap-4">
            {g.couleurs.map(([nom, hex]) => (
              <div key={nom} className="w-32">
                <div className="h-16 rounded-lg border border-black/10" style={{ backgroundColor: hex }} />
                <p className="mt-1.5 text-[11px] font-medium text-[#1C1917]">{nom}</p>
                <p className="text-[11px] text-[#57534E] uppercase">{hex}</p>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}