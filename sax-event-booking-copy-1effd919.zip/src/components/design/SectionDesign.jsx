import React from "react";

export default function SectionDesign({ titre, description, children }) {
  return (
    <section className="space-y-4">
      <div>
        <h2 className="font-heading text-2xl text-[#1C1917]">{titre}</h2>
        {description && <p className="mt-1 text-sm text-[#57534E]">{description}</p>}
      </div>
      <div className="rounded-xl border border-[#B49B72]/25 bg-white p-6">{children}</div>
    </section>
  );
}