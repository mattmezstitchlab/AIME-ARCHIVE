import React from "react";

export default function SectionTypographies() {
  return (
    <div className="space-y-6">
      <div>
        <p className="text-xs font-bold uppercase tracking-wide text-[#8A7356] mb-2">Playfair Display — titres (font-heading)</p>
        <p className="font-heading text-4xl text-[#1C1917]">Un Jour J simple, humain et clair.</p>
        <p className="font-heading text-2xl text-[#1C1917] mt-2">Titre de section</p>
        <p className="font-heading text-lg text-[#1C1917] mt-1">Titre de carte</p>
      </div>
      <div>
        <p className="text-xs font-bold uppercase tracking-wide text-[#8A7356] mb-2">Inter — corps de texte (font-body)</p>
        <p className="text-sm text-[#44403C]">Texte courant — Construire, comprendre et piloter chaque instant d'un événement, ensemble.</p>
        <p className="text-sm text-[#57534E] mt-1">Texte secondaire — informations complémentaires et descriptions.</p>
        <p className="text-[11px] text-[#57534E] mt-1">Petit texte — mentions, légendes et aides contextuelles.</p>
      </div>
      <div>
        <p className="text-xs font-bold uppercase tracking-wide text-[#8A7356] mb-2">Étiquettes de champs</p>
        <p className="text-xs font-bold uppercase tracking-wide text-[#8A7356]">Libellé de champ *</p>
        <p className="text-[10px] font-bold uppercase tracking-[0.25em] text-[#57534E] mt-2">Sur-titre espacé</p>
      </div>
    </div>
  );
}