import React from "react";

export default function BoutonOrbeComposer({ disabled }) {
  return (
    <button type="submit" disabled={disabled} aria-label="Composer l’événement" title="Composer" className="bouton-orbe-composer relative h-12 w-12 shrink-0 rounded-full disabled:cursor-not-allowed disabled:opacity-40">
      <span className="absolute inset-[5px] rounded-full border border-white/35" aria-hidden="true" />
      <span className="sr-only">Composer</span>
    </button>
  );
}