import React, { useState } from "react";
import { Plus, Minus } from "lucide-react";

const QUESTIONS = [
  ["Faut-il un compte pour contacter un prestataire ?", "Non. Les profils publics restent accessibles sans compte et permettent d’envoyer une demande de disponibilité."],
  ["Que contient l’espace prestataire ?", "Vos demandes, votre calendrier, votre mini-site, vos documents, votre suivi d’activité et vos événements."],
  ["Et pour les intermittents du spectacle ?", "Un espace dédié suit les cachets, l’objectif des 507 heures, les échéances et les justificatifs."],
  ["Je prépare un événement, par où commencer ?", "Décrivez votre projet à l’assistant. Il structure le déroulé, les acteurs, le budget, les contraintes et les points à confirmer avant création."],
  ["Mes prestataires doivent-ils avoir un compte ?", "Non pour être ajoutés comme acteurs. Un compte est nécessaire uniquement pour accéder à l’espace partagé de l’événement."],
  ["Puis-je déléguer la gestion de mon compte ?", "Oui. Vous pouvez inviter des collaborateurs et conserver la maîtrise des accès depuis vos réglages."],
];

export default function FaqAccueil() {
  const [ouverte, setOuverte] = useState(null);

  return (
    <section className="pb-12 md:pb-16 grid grid-cols-1 md:grid-cols-[0.9fr_1.5fr] gap-5 md:gap-8">
      <div>
        <p className="text-[11px] font-bold uppercase tracking-[0.35em] text-white/40">03 — Questions</p>
        <h2 className="mt-3 font-heading text-3xl md:text-4xl tracking-tight">
          <span className="texte-prisme">Des vraies réponses,</span>
          <br />
          <span className="text-white/40">pas du jargon.</span>
        </h2>
      </div>
      <ul>
        {QUESTIONS.map(([q, r], i) => (
          <li key={q} className="border-t border-white/10 last:border-b">
            <button
              onClick={() => setOuverte(ouverte === i ? null : i)}
              aria-expanded={ouverte === i}
              className="w-full flex items-center justify-between gap-4 py-4 text-left"
            >
              <span className="text-sm md:text-base font-medium text-white">{q}</span>
              {ouverte === i ? (
                <Minus className="h-4 w-4 shrink-0 text-white/40" />
              ) : (
                <Plus className="h-4 w-4 shrink-0 text-white/40" />
              )}
            </button>
            {ouverte === i && (
              <p className="pb-4 text-sm text-white/50 leading-relaxed max-w-lg">{r}</p>
            )}
          </li>
        ))}
      </ul>
    </section>
  );
}