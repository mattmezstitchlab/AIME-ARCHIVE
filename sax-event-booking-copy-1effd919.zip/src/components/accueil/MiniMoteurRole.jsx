import React from "react";

export default function MiniMoteurRole({ moments }) {
  return (
    <span className="block w-full space-y-1.5">
      {moments.map(([titre, avant, apres]) => (
        <span
          key={titre}
          className={`flex items-center gap-3 rounded-xl px-4 py-2 text-white ${
            apres ? "bg-white/25" : "bg-white/15"
          }`}
        >
          <span className="font-mono text-xs tabular-nums whitespace-nowrap">
            {apres ? (
              <>
                <span className="line-through opacity-60">{avant}</span>
                <span className="font-bold"> → {apres}</span>
              </>
            ) : (
              avant
            )}
          </span>
          <span className="text-sm font-medium truncate">{titre}</span>
        </span>
      ))}
    </span>
  );
}