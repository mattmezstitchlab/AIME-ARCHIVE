import React from "react";
import { Link } from "react-router-dom";

export default function PiedAccueil() {
  return (
    <footer
      className="mt-4 pt-16 pb-[calc(6rem+env(safe-area-inset-bottom))] text-center"
      style={{
        backgroundImage: "radial-gradient(rgba(255,255,255,0.08) 1.5px, transparent 1.5px)",
        backgroundSize: "22px 22px",
      }}
    >
      <p className="font-heading text-[13vw] md:text-8xl leading-none tracking-tight text-white select-none">
        Aime Event
      </p>
      <p className="mt-4 text-xs uppercase tracking-[0.3em] text-white/40">
        Prestataires · Clients · Jour J
      </p>
      <div className="mt-8 flex flex-wrap justify-center gap-x-5 gap-y-1 text-xs text-white/50 tracking-wide">
        <Link to="/p/matt" className="inline-flex items-center min-h-[32px] px-1 underline hover:text-white">Voir le profil exemple</Link>
        <Link to="/mentions-legales" className="inline-flex items-center min-h-[32px] px-1 underline hover:text-white">Mentions légales</Link>
        <Link to="/confidentialite" className="inline-flex items-center min-h-[32px] px-1 underline hover:text-white">Politique de confidentialité</Link>
      </div>
    </footer>
  );
}