import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import BoutonOrbeComposer from "@/components/accueil/BoutonOrbeComposer";
import { demarrerBrief } from "@/lib/brouillonEvenement";

const COULEURS_POINTS = ["#FF9F0A", "#0A84FF", "#FF2D78"];

// Un point de tête suivi d'une traînée de lumière qui s'estompe.
function PointComete({ couleur, base }) {
  return (
    <>
      <span
        className="point-magique"
        style={{ backgroundColor: couleur, color: couleur, animationDelay: `${base}s` }}
        aria-hidden="true"
      />
      {[1, 2, 3, 4].map((k) => (
        <span
          key={k}
          className="point-magique point-trainee"
          style={{
            backgroundColor: couleur,
            color: couleur,
            height: `${6 - k}px`,
            width: `${6 - k}px`,
            opacity: 0.55 - k * 0.12,
            animationDelay: `${base + k * 0.07}s`,
          }}
          aria-hidden="true"
        />
      ))}
    </>
  );
}

// Le brief peut être court ou très détaillé : l'assistant en extrait dates, acteurs,
// contraintes, budget, moments clés, risques et plans B avant de composer le dossier.
export default function BriefMagique() {
  const navigate = useNavigate();
  const [texte, setTexte] = useState("");

  const envoyer = (e) => {
    e.preventDefault();
    if (!texte.trim()) return;
    const id = demarrerBrief(texte.trim());
    if (sessionStorage.getItem("aime_brief_started") !== id) {
      base44.analytics.track({ eventName: "brief_started" });
      sessionStorage.setItem("aime_brief_started", id);
    }
    navigate("/apercu-evenement");
  };

  return (
    <form onSubmit={envoyer} className="champ-magique w-full max-w-xl mx-auto">
      {COULEURS_POINTS.map((c, i) => (
        <PointComete key={c} couleur={c} base={i * -1.7} />
      ))}
      <div className="flex min-w-0 items-center gap-2 rounded-full bg-black/60 py-1.5 pl-5 pr-1.5">
        <input
          value={texte}
          onChange={(e) => setTexte(e.target.value)}
          placeholder="Date, lieu, invités, budget, horaires, prestataires, contraintes, envies…"
          aria-label="Décrivez librement tout votre événement"
          className="flex-1 min-w-0 min-h-[44px] bg-transparent text-sm text-white placeholder:text-white/40 focus:outline-none"
        />
        <BoutonOrbeComposer disabled={!texte.trim()} />
      </div>
    </form>
  );
}