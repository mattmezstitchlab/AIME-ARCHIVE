import React, { useEffect, useRef, useState } from "react";
import CadranCausal from "@/components/evenements/CadranCausal";
import { CalendarCheck, Clock, CloudRain } from "lucide-react";

// Décale une heure "HH:MM" de n minutes.
const decaler = (h, min) => {
  const [H, M] = h.split(":").map(Number);
  const t = (H * 60 + M + min + 1440) % 1440;
  return `${String(Math.floor(t / 60)).padStart(2, "0")}:${String(t % 60).padStart(2, "0")}`;
};

const BASE = [
  { titre: "Préparatifs", heureDebut: "10:00", heureFin: "11:00", categorie: "famille" },
  { titre: "Cérémonie", heureDebut: "11:30", heureFin: "12:15", categorie: "celebres", tag: "sacre", exposition: "exterieur", planB: "Repli en salle" },
  { titre: "Cocktail", heureDebut: "12:30", heureFin: "14:00", categorie: "prestataire", exposition: "exterieur", planB: "Sous la verrière" },
  { titre: "Photos", heureDebut: "15:00", heureFin: "16:30", categorie: "prestataire" },
  { titre: "Dîner & fête", heureDebut: "19:00", heureFin: "23:30", categorie: "famille" },
];

const SCENARIOS = [
  {
    libelle: "Déroulé prévu",
    Icone: CalendarCheck,
    effet: "Tout est en place — chaque acteur voit le même cadran.",
    transformer: (m) => m,
  },
  {
    libelle: "Traiteur en retard",
    Icone: Clock,
    effet: "40 min de retard : cocktail, photos et dîner glissent automatiquement.",
    transformer: (m) =>
      m.heureDebut >= "12:30" ? { ...m, heureDebut: decaler(m.heureDebut, 40), heureFin: decaler(m.heureFin, 40) } : m,
  },
  {
    libelle: "Une averse arrive",
    Icone: CloudRain,
    effet: "Cérémonie et cocktail basculent sur leur plan B, sans toucher au reste.",
    transformer: (m) => (m.exposition === "exterieur" ? { ...m, planBActif: true, titre: m.planB } : m),
  },
];

export default function CadranDemo() {
  const [phase, setPhase] = useState(0);
  const pauseJusquA = useRef(0);

  // Défilement automatique des scénarios, suspendu quelques secondes après un clic.
  useEffect(() => {
    const timer = setInterval(() => {
      if (Date.now() < pauseJusquA.current) return;
      setPhase((p) => (p + 1) % SCENARIOS.length);
    }, 3600);
    return () => clearInterval(timer);
  }, []);

  const choisir = (i) => {
    pauseJusquA.current = Date.now() + 12000;
    setPhase(i);
  };

  const actif = SCENARIOS[phase];
  const moments = BASE.map(actif.transformer);

  return (
    <div className="flex flex-col items-center">
      {/* Scénarios d'imprévus : un libellé actif, puis les pictogrammes sur une ligne */}
      <p className="mb-3 min-h-6 text-center text-sm font-semibold text-white" aria-live="polite">
        {actif.libelle}
      </p>
      <div className="mb-5 flex flex-nowrap justify-center gap-3" role="tablist" aria-label="Scénarios d'imprévus">
        {SCENARIOS.map(({ libelle, Icone }, i) => (
          <button
            key={libelle}
            type="button"
            role="tab"
            aria-label={libelle}
            title={libelle}
            aria-selected={i === phase}
            onClick={() => choisir(i)}
            className={`inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-full transition-colors ${
              i === phase ? "bg-gradient-to-r from-[#BF5AF2] to-[#0A84FF] text-white" : "bg-white/10 text-white/70 hover:bg-white/20 hover:text-white"
            }`}
          >
            <Icone className="h-5 w-5" />
          </button>
        ))}
      </div>

      <CadranCausal moments={moments} />

      <p className="mt-3 text-sm text-white/60 text-center max-w-xs leading-relaxed" aria-live="polite">
        {actif.effet}
      </p>
    </div>
  );
}