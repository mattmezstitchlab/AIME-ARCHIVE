import React from "react";
import { ArrowDown } from "lucide-react";
import BriefMagique from "@/components/accueil/BriefMagique";

export default function HeroAccueil() {
  return (
    <section className="max-w-4xl mx-auto px-4 md:px-6 pt-16 md:pt-24 pb-20 md:pb-28 text-center">
      <p className="text-[11px] font-bold uppercase tracking-[0.35em] text-white/40">01 — La plateforme</p>
      <h1 className="mt-8 font-heading font-semibold uppercase leading-[0.85] tracking-[-0.04em] text-[17vw] md:text-[9rem] select-none">
        <span className="block text-white">Aime</span>
        <span className="block texte-prisme">Event</span>
      </h1>
      <p className="mt-8 mx-auto max-w-2xl text-lg md:text-2xl text-white/85 leading-snug">
        Racontez tout, même en vrac — dates, budget, horaires, personnes, contraintes —
        l'assistant comprend, anticipe et compose le dossier complet.
      </p>
      <div className="mt-9">
        <BriefMagique />
      </div>
      <a
        href="#moteur-causal"
        className="mt-9 inline-flex items-center gap-2 min-h-[44px] px-5 rounded-full bg-white/10 text-sm font-semibold text-white hover:bg-white/20 transition-colors"
      >
        <ArrowDown className="h-4 w-4" /> Voir le moteur du Jour J
      </a>
    </section>
  );
}