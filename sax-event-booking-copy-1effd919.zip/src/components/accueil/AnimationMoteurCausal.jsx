import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { appliquerRetard } from "@/lib/moteurCausal";

// Animation calculée en direct par le vrai moteur causal, dans le même
// langage visuel que les étapes : bloc coloré par phase + grand chiffre.

const MOMENTS = [
  { titre: "Cérémonie", heureDebut: "15:00", heureFin: "16:00", tag: "sacre", categorie: "celebres" },
  { titre: "Cocktail — saxophone live", heureDebut: "16:30", heureFin: "18:30", tag: "", categorie: "prestataire" },
  { titre: "Dîner — service traiteur", heureDebut: "19:00", heureFin: "22:00", tag: "", categorie: "prestataire" },
  { titre: "Ouverture de bal", heureDebut: "22:30", heureFin: "23:00", tag: "immuable", categorie: "famille" },
  { titre: "Soirée dansante", heureDebut: "23:00", heureFin: "01:00", tag: "", categorie: "prestataire" },
];

const PHASES = [
  {
    cle: "repos",
    duree: 3000,
    couleur: "#1D1D1F",
    pilule: "Déroulé stable",
    titre: "Tout est en place.",
    texte: "Cinq moments, quatre acteurs, un seul déroulé partagé dans le Studio.",
    chiffre: "OK",
  },
  {
    cle: "alerte",
    duree: 3000,
    couleur: "#E0342B",
    pilule: "Imprévu détecté",
    titre: "Le traiteur annonce un retard.",
    texte: "18h04 — le service du dîner ne pourra pas commencer à l'heure prévue.",
    chiffre: "+30",
  },
  {
    cle: "recalcul",
    duree: 5600,
    couleur: "#0A6CFF",
    pilule: "Moteur causal",
    titre: "Tout se recalcule.",
    texte: "Les moments glissent, les instants sacrés sont protégés, chaque acteur est prévenu.",
    chiffre: "04",
  },
];

export default function AnimationMoteurCausal() {
  const [phase, setPhase] = useState(0);
  const p = PHASES[phase];

  useEffect(() => {
    const t = setTimeout(() => setPhase((n) => (n + 1) % PHASES.length), p.duree);
    return () => clearTimeout(t);
  }, [phase]);

  const resultat = p.cle === "recalcul" ? appliquerRetard(MOMENTS, 2, 30) : null;
  const moments = resultat?.moments || MOMENTS;

  return (
    <div className="max-w-5xl mx-auto px-4 md:px-6 pb-4 md:pb-8" aria-hidden="true">
      <div
        className="rounded-3xl text-white p-6 md:p-12 overflow-hidden transition-colors duration-700"
        style={{ backgroundColor: p.couleur }}
      >
        {/* Pilules de phase */}
        <div className="flex flex-wrap gap-2">
          {PHASES.map((ph, i) => (
            <span
              key={ph.cle}
              className={`min-h-[40px] px-4 inline-flex items-center rounded-full text-xs font-bold tracking-wide transition-colors duration-500 ${
                phase === i ? "bg-gradient-to-r from-[#BF5AF2] to-[#0A84FF] text-white" : "bg-white/15 text-white"
              }`}
            >
              {ph.pilule}
            </span>
          ))}
        </div>

        <div className="mt-8 md:mt-10 grid md:grid-cols-[1fr_auto] gap-6 md:gap-10 items-end">
          <div className="min-h-[150px]">
            <AnimatePresence mode="wait">
              <motion.div
                key={p.cle}
                initial={{ opacity: 0, y: 14 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.4 }}
              >
                <h3 className="font-heading text-3xl md:text-5xl font-semibold tracking-tight">
                  {p.titre}
                </h3>
                <p className="mt-4 text-sm md:text-base text-white/80 max-w-md leading-relaxed">
                  {p.texte}
                </p>
              </motion.div>
            </AnimatePresence>
          </div>
          <AnimatePresence mode="wait">
            <motion.p
              key={p.chiffre}
              initial={{ opacity: 0, scale: 0.85 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.45 }}
              className="font-heading font-bold text-white/90 leading-none text-[110px] md:text-[180px] tracking-tighter text-right"
            >
              {p.chiffre}
            </motion.p>
          </AnimatePresence>
        </div>

        {/* Déroulé — le vrai moteur déplace les heures */}
        <ol className="mt-8 space-y-1.5">
          {moments.map((m, i) => {
            const original = MOMENTS[i];
            const change =
              p.cle === "recalcul" &&
              (m.heureDebut !== original.heureDebut || m.heureFin !== original.heureFin);
            const alerte = p.cle === "alerte" && i === 2;
            return (
              <li
                key={m.titre}
                className={`flex items-center gap-3 rounded-xl px-4 py-2.5 text-sm transition-colors duration-500 ${
                  change || alerte ? "bg-white/25" : "bg-white/10"
                }`}
              >
                <AnimatePresence mode="popLayout" initial={false}>
                  <motion.span
                    key={`${m.heureDebut}-${m.heureFin}`}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.45, delay: change ? i * 0.12 : 0 }}
                    className={`font-mono text-xs tabular-nums w-[88px] shrink-0 ${
                      change ? "text-white font-bold" : "text-white/70"
                    }`}
                  >
                    {m.heureDebut}–{m.heureFin}
                  </motion.span>
                </AnimatePresence>
                <span className="flex-1 text-white/95 truncate">{m.titre}</span>
                {m.tag === "sacre" && (
                  <span className="text-[10px] font-bold uppercase tracking-wider text-white/70">Sacré</span>
                )}
                {m.tag === "immuable" && (
                  <span className="text-[10px] font-bold uppercase tracking-wider text-white/70">Immuable</span>
                )}
              </li>
            );
          })}
        </ol>
      </div>
      <p className="mt-3 text-center text-[11px] text-white/35">
        Animation calculée en direct par le vrai moteur causal — rien n'est simulé en vidéo.
      </p>
    </div>
  );
}