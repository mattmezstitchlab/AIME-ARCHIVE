import React from "react";
import CadranDemo from "@/components/accueil/CadranDemo";

export default function SectionMoteurCausal() {
  return (
    <section id="moteur-causal" className="bg-[#050506]">
      <div className="max-w-5xl mx-auto px-4 md:px-6 pt-16 md:pt-24 pb-16 md:pb-24">
        <div
          className="rounded-[2.5rem] md:rounded-[3rem] bg-black border border-white/10 text-white p-6 md:p-12 shadow-[0_24px_60px_-24px_rgba(0,0,0,0.45)]"
          style={{ fontFamily: "-apple-system, BlinkMacSystemFont, 'SF Pro Display', 'Helvetica Neue', Inter, sans-serif" }}
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10 items-center">
            <div>
              <p className="text-[11px] font-bold uppercase tracking-[0.35em] text-white/40">02 — Le moteur causal</p>
              <h2 className="mt-5 font-heading text-3xl md:text-5xl tracking-tight leading-tight">
                <span className="texte-prisme">« Un imprévu ne casse pas un moment.</span>
                <br />
                <span className="text-white/65">Il déplace tous les autres. »</span>
              </h2>
              <p className="mt-5 text-xs text-white/60">
                Simulations indicatives — la décision finale reste toujours entre vos mains.
              </p>
            </div>
            <CadranDemo />
          </div>
        </div>
      </div>
    </section>
  );
}