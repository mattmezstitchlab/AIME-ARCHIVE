import React from "react";
import { AlertTriangle, ChevronUp } from "lucide-react";
import SchemaRadialCadrans from "@/components/evenements/SchemaRadialCadrans";

export default function VueRadialeJourJ({ evenement, documents, impacts, onImpact, onFermer }) {
  const moments = evenement.moments || [];
  const alertes = impacts.filter((impact) => ["rouge", "orange", "violet"].includes(impact.niveau)).slice(0, 3);
  return <section className="flex min-h-[500px] flex-col items-center animate-in slide-in-from-top-3 duration-200" aria-label="Miroir radial du cadran causal et des cadrans-moments">
    <button type="button" onClick={onFermer} className="flex min-h-[44px] items-center gap-1.5 rounded-full px-4 text-xs font-semibold text-white/55 hover:bg-white/10 focus-visible:ring-2 focus-visible:ring-[#BF5AF2]"><ChevronUp className="h-4 w-4" />Revenir aux cadrans</button>
    {moments.length ? <SchemaRadialCadrans evenement={evenement} documents={documents} /> : <div className="flex min-h-[330px] items-center justify-center px-6 text-center text-sm text-white/40">Ajoutez des moments pour construire le miroir radial du cadran.</div>}
    {alertes.length > 0 && <div className="mt-2 w-full space-y-2" aria-label="Impacts causaux"><p className="text-[10px] font-bold uppercase tracking-[0.18em] text-white/35">Causalité</p>{alertes.map((impact) => <button key={impact.id} type="button" onClick={() => onImpact(impact)} className={`flex min-h-[44px] w-full items-center gap-2 rounded-2xl px-3 text-left text-xs font-semibold focus-visible:ring-2 focus-visible:ring-white ${impact.niveau === "rouge" ? "bg-[#FF453A]/15 text-[#FF6961]" : "bg-[#FF9F0A]/15 text-[#FFB340]"}`}><AlertTriangle className="h-4 w-4 shrink-0" /><span className="truncate">{impact.label}</span></button>)}</div>}
  </section>;
}