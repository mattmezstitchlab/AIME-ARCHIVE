import React, { useState } from "react";
import { impactsAbsence, appliquerAbsence } from "@/lib/moteurCausal";
import { classeInputOs, classeBoutonBleuVert } from "@/components/evenements/stylesOs";
import ListeImpacts from "@/components/evenements/ListeImpacts";
import { UserX, Check, X } from "lucide-react";

export default function SimulateurAbsence({ acteurs, moments, liensCausaux = [], onAppliquer, onSimulation, couleur = "#FF2D78" }) {
  const [nom, setNom] = useState("");
  const [remplacant, setRemplacant] = useState("");
  const [impacts, setImpacts] = useState(null);
  const [proposition, setProposition] = useState(null);

  const momentsOrphelins = nom ? moments.filter((m) => m.responsable === nom) : [];
  const remplacants = acteurs.filter((a) => a.nom !== nom);

  const reinitialiser = () => {
    setImpacts(null);
    setProposition(null);
    setRemplacant("");
  };
  const analyser = () => {
    if (!nom) return;
    const resultat = impactsAbsence(moments, nom, liensCausaux); setImpacts(resultat);
    onSimulation?.({ id: "simulation-absence", niveau: "rouge", label: `Absence · ${momentsOrphelins.length} moments sans responsable`, cause: `Absence signalée de ${nom}.`, elements: resultat, consequences: resultat, recommandation: "Choisir un remplaçant puis confirmer la réaffectation." });
  };

  return (
    <div className="space-y-4">
      <h3 className="text-[10px] font-bold uppercase tracking-[0.3em] text-white/70 inline-flex items-center gap-2">
        <UserX className="h-3.5 w-3.5 text-white" /> Moteur causal — absence ou annulation d'un acteur
      </h3>

      {acteurs.length === 0 ? (
        <p className="text-sm text-white/70">Ajoutez d'abord des acteurs dans l'onglet Acteurs.</p>
      ) : (
        <div className="grid grid-cols-1 gap-2 sm:grid-cols-[1fr_auto]">
          <select
            className={classeInputOs}
            value={nom}
            onChange={(e) => { setNom(e.target.value); reinitialiser(); }}
            aria-label="Acteur absent"
          >
            <option value="">Choisir l'acteur concerné…</option>
            {acteurs.map((a, i) => <option key={i} value={a.nom}>{a.nom}{a.role ? ` — ${a.role}` : ""}</option>)}
          </select>
          <button onClick={analyser} className={classeBoutonBleuVert}>
            Analyser
          </button>
        </div>
      )}

      {impacts && <ListeImpacts impacts={impacts} />}

      {/* Réaffectation réelle : si des moments dépendent de l'absent, on les confie à un remplaçant. */}
      {impacts && momentsOrphelins.length > 0 && remplacants.length > 0 && !proposition && (
        <div className="grid grid-cols-1 gap-2 sm:grid-cols-[1fr_auto]">
          <select
            className={classeInputOs}
            value={remplacant}
            onChange={(e) => setRemplacant(e.target.value)}
            aria-label="Acteur remplaçant"
          >
            <option value="">Choisir un remplaçant…</option>
            {remplacants.map((a, i) => <option key={i} value={a.nom}>{a.nom}{a.role ? ` — ${a.role}` : ""}</option>)}
          </select>
          <button
            onClick={() => remplacant && setProposition(appliquerAbsence(moments, nom, remplacant, liensCausaux))}
            className={classeBoutonBleuVert}
          >
            Proposer la réaffectation
          </button>
        </div>
      )}

      {proposition && (
        <div className="space-y-3">
          <ListeImpacts impacts={proposition.impacts} />
          <div className="flex gap-2">
            <button
              onClick={() => { onAppliquer(proposition.moments); reinitialiser(); setNom(""); }}
              className={classeBoutonBleuVert}
            >
              <Check className="h-4 w-4" /> Appliquer au déroulé
            </button>
            <button
              onClick={() => setProposition(null)}
              className="min-h-[42px] px-4 rounded-full bg-white/15 text-white/80 text-sm hover:text-white transition-colors inline-flex items-center gap-1.5"
            >
              <X className="h-4 w-4" /> Ignorer
            </button>
          </div>
        </div>
      )}

      <p className="text-[11px] text-white/70">
        Liez un responsable à chaque moment du déroulé pour que le moteur détecte les moments orphelins et propose une réaffectation.
      </p>
    </div>
  );
}