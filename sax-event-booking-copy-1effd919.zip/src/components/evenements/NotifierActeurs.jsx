import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { classeBoutonOs } from "@/components/evenements/stylesOs";
import { Send, Loader2, Check } from "lucide-react";

export default function NotifierActeurs({ evenement }) {
  const [etat, setEtat] = useState("repos");
  const participants = evenement.participants || [];

  if (participants.length === 0) return null;

  const notifier = async () => {
    setEtat("envoi");
    const moments = [...(evenement.moments || [])].sort((a, b) =>
      (a.heureDebut || "").localeCompare(b.heureDebut || "")
    );
    const deroule = moments
      .map((m) => `• ${m.heureDebut}–${m.heureFin} — ${m.titre}${m.responsable ? ` (${m.responsable})` : ""}`)
      .join("\n");
    for (const email of participants) {
      await base44.integrations.Core.SendEmail({
        to: email,
        subject: `Déroulé mis à jour — « ${evenement.titre} »`,
        body: `Bonjour,\n\nLe déroulé de « ${evenement.titre} » vient d'être recalculé. Voici la version à jour :\n\n${deroule || "(aucun moment planifié)"}\n\nRetrouvez le direct et les effets causals dans le Studio de l'événement :\n${window.location.origin}/compte?evenement=${evenement.id}\n\n— Aime Event`,
      });
    }
    setEtat("fait");
  };

  return (
    <div className="border-t border-white/10 pt-5 flex flex-wrap items-center justify-between gap-4 text-white">
      <div>
        <p className="text-[10px] font-bold uppercase tracking-[0.3em] text-white/40">Notifier les acteurs</p>
        <p className="mt-1 text-sm text-white/60">
          Envoie le déroulé à jour aux {participants.length} acteur{participants.length > 1 ? "s" : ""} invité{participants.length > 1 ? "s" : ""}.
        </p>
      </div>
      <button onClick={notifier} disabled={etat === "envoi"} className={`${classeBoutonOs} disabled:opacity-60`}>
        {etat === "envoi" ? <Loader2 className="h-4 w-4 animate-spin" /> : etat === "fait" ? <Check className="h-4 w-4 text-[#30D158]" /> : <Send className="h-4 w-4" />}
        {etat === "fait" ? "Envoyé" : "Prévenir les acteurs"}
      </button>
    </div>
  );
}