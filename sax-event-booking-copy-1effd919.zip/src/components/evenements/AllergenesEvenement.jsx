import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import FormulaireRegimeStudio from "@/components/evenements/FormulaireRegimeStudio";
import { Link2, Check, Send, UtensilsCrossed, Loader2, Trash2 } from "lucide-react";

export default function AllergenesEvenement({ evenement, ouvrirFormulaire }) {
  const [regimes, setRegimes] = useState(null);
  const [copie, setCopie] = useState(false);
  const [envoiTraiteur, setEnvoiTraiteur] = useState("");

  const charger = () =>
    base44.entities.RegimeInvite.filter({ evenementId: evenement.id }, "-created_date", 500)
      .then(setRegimes)
      .catch(() => setRegimes([]));

  useEffect(() => {
    charger();
  }, [evenement.id]);

  const supprimerRegime = async (r) => {
    await base44.entities.RegimeInvite.delete(r.id);
    setRegimes((l) => l.filter((x) => x.id !== r.id));
  };

  const lien = `${window.location.origin}/allergies/${evenement.id}`;
  const traiteur = (evenement.acteurs || []).find((a) => /trait/i.test(a.role || ""));

  const copierLien = async () => {
    await navigator.clipboard.writeText(lien);
    setCopie(true);
    setTimeout(() => setCopie(false), 2000);
  };

  // Synthèse : combien d'invités par allergène et par régime.
  const compteAllergenes = {};
  const compteRegimes = {};
  (regimes || []).forEach((r) => {
    (r.allergenes || []).forEach((a) => { compteAllergenes[a] = (compteAllergenes[a] || 0) + 1; });
    if (r.regime && !/aucun/i.test(r.regime)) compteRegimes[r.regime] = (compteRegimes[r.regime] || 0) + 1;
  });

  const texteSynthese = () => {
    const lignes = [
      `Synthèse alimentaire — « ${evenement.titre} »${evenement.date ? ` (${evenement.date.split("-").reverse().join("/")})` : ""}`,
      `${(regimes || []).length} invité(s) ont répondu.`,
      "",
      "Allergènes déclarés :",
      ...Object.entries(compteAllergenes).map(([a, n]) => `- ${a} : ${n} invité(s)`),
      "",
      "Régimes particuliers :",
      ...Object.entries(compteRegimes).map(([r, n]) => `- ${r} : ${n} invité(s)`),
      "",
      "Détail par invité :",
      ...(regimes || []).map((r) =>
        `- ${r.nom} : ${(r.allergenes || []).join(", ") || "aucun allergène"}${r.regime && !/aucun/i.test(r.regime) ? ` · ${r.regime}` : ""}${r.commentaire ? ` · ${r.commentaire}` : ""}`
      ),
      "",
      "— Aime Event",
    ];
    return lignes.join("\n");
  };

  const envoyerAuTraiteur = async () => {
    if (!traiteur?.email || envoiTraiteur === "envoi") return;
    setEnvoiTraiteur("envoi");
    await base44.integrations.Core.SendEmail({
      to: traiteur.email,
      subject: `Allergies & régimes — « ${evenement.titre} »`,
      body: `Bonjour ${traiteur.nom},\n\n${texteSynthese()}`,
    });
    setEnvoiTraiteur("fait");
    setTimeout(() => setEnvoiTraiteur(""), 2500);
  };

  if (regimes === null) return <Loader2 className="h-6 w-6 animate-spin text-white/50" />;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm text-white/60 max-w-md">
          Renseignez directement les invités ici — et partagez le lien à ceux dont vous ignorez les besoins. Tout remonte, prêt à transmettre au traiteur.
        </p>
        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            onClick={copierLien}
            className="inline-flex items-center gap-2 min-h-[40px] px-4 rounded-full bg-white/10 text-sm font-semibold text-white hover:bg-white/20 transition-colors"
          >
            {copie ? <Check className="h-4 w-4 text-[#30D158]" /> : <Link2 className="h-4 w-4" />}
            {copie ? "Lien copié !" : "Lien pour les invités"}
          </button>
          {traiteur?.email && (
            <button
              type="button"
              onClick={envoyerAuTraiteur}
              disabled={envoiTraiteur === "envoi" || regimes.length === 0}
              className="inline-flex items-center gap-2 min-h-[40px] px-4 rounded-full bg-[#FF9F0A] text-sm font-semibold text-black hover:opacity-90 disabled:opacity-40 transition-opacity"
            >
              {envoiTraiteur === "fait" ? <Check className="h-4 w-4" /> : <Send className="h-4 w-4" />}
              {envoiTraiteur === "envoi" ? "Envoi…" : envoiTraiteur === "fait" ? "Envoyé au traiteur !" : `Envoyer à ${traiteur.nom}`}
            </button>
          )}
        </div>
      </div>

      {!traiteur && (
        <p className="text-xs text-white/40">
          Astuce : ajoutez un acteur avec le rôle « Traiteur » (et son e-mail) pour lui transmettre la synthèse en un clic.
        </p>
      )}

      <FormulaireRegimeStudio evenementId={evenement.id} onAjout={charger} focusDemande={ouvrirFormulaire} />

      {regimes.length === 0 ? (
        <div className="text-center py-10">
          <UtensilsCrossed className="h-8 w-8 mx-auto text-white/25" aria-hidden="true" />
          <p className="mt-3 text-sm text-white/50">Aucun invité renseigné — ajoutez-les ci-dessus ou partagez le lien.</p>
        </div>
      ) : (
        <>
          {/* Synthèse pour le traiteur */}
          <div className="flex flex-wrap gap-2">
            {Object.entries(compteAllergenes).map(([a, n]) => (
              <span key={a} className="inline-flex items-center gap-1.5 min-h-[32px] px-3 rounded-full bg-[#FF453A]/15 text-xs font-semibold text-[#FF6961]">
                {a} <span className="text-white/70">×{n}</span>
              </span>
            ))}
            {Object.entries(compteRegimes).map(([r, n]) => (
              <span key={r} className="inline-flex items-center gap-1.5 min-h-[32px] px-3 rounded-full bg-white/10 text-xs font-semibold text-white/80">
                {r} <span className="text-white/50">×{n}</span>
              </span>
            ))}
          </div>

          {/* Détail par invité */}
          <ul className="space-y-1.5">
            {regimes.map((r) => (
              <li key={r.id} className="flex flex-wrap items-center gap-x-3 gap-y-1 rounded-xl bg-white/[0.07] px-4 py-3 text-sm text-white">
                <span className="font-semibold">{r.nom}</span>
                <span className="text-white/55">
                  {(r.allergenes || []).join(", ") || "Aucun allergène"}
                  {r.regime && !/aucun/i.test(r.regime) ? ` · ${r.regime}` : ""}
                </span>
                <button
                  type="button"
                  onClick={() => supprimerRegime(r)}
                  title={`Retirer ${r.nom}`}
                  aria-label={`Retirer ${r.nom}`}
                  className="ml-auto h-7 w-7 inline-flex items-center justify-center rounded-full text-white/30 hover:text-[#FF453A] hover:bg-white/10 transition-colors"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
                {r.commentaire && <span className="w-full text-xs text-white/40">{r.commentaire}</span>}
              </li>
            ))}
          </ul>
        </>
      )}
    </div>
  );
}