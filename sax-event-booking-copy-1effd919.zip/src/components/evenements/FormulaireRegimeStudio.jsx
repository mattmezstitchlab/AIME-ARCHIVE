import React, { useEffect, useRef, useState } from "react";
import { base44 } from "@/api/base44Client";
import { ALLERGENES_OFFICIELS, REGIMES } from "@/lib/allergenes";
import { Plus, Loader2 } from "lucide-react";

const VIDE = { nom: "", allergenes: [], regime: "", commentaire: "" };

// Saisie directe dans le Studio : l'organisateur renseigne lui-même les invités.
export default function FormulaireRegimeStudio({ evenementId, onAjout, focusDemande }) {
  const nomRef = useRef(null);
  const [form, setForm] = useState(VIDE);
  const [envoi, setEnvoi] = useState(false);

  useEffect(() => {
    if (!focusDemande) return;
    nomRef.current?.scrollIntoView({ block: "center" });
    nomRef.current?.focus();
  }, [focusDemande]);

  const basculerAllergene = (a) =>
    setForm((f) => ({
      ...f,
      allergenes: f.allergenes.includes(a) ? f.allergenes.filter((x) => x !== a) : [...f.allergenes, a],
    }));

  const soumettre = async (e) => {
    e.preventDefault();
    if (!form.nom.trim() || envoi) return;
    setEnvoi(true);
    try {
      await base44.functions.invoke("allergiesEvenement", {
        evenementId,
        action: "ajouter",
        ...form,
      });
      setForm(VIDE);
      onAjout?.();
    } finally {
      setEnvoi(false);
    }
  };

  return (
    <form onSubmit={soumettre} className="rounded-2xl bg-white/[0.06] p-4 space-y-3">
      <p className="text-xs font-bold uppercase tracking-wider text-white/40">Ajouter un invité</p>
      <div className="grid gap-2 sm:grid-cols-2">
        <input
          ref={nomRef}
          aria-label="Nom de l’invité"
          value={form.nom}
          onChange={(e) => setForm((f) => ({ ...f, nom: e.target.value }))}
          placeholder="Nom de l'invité *"
          required
          className="min-h-[42px] rounded-lg bg-white/[0.07] px-3 text-sm text-white placeholder:text-white/30 focus:outline-none focus:ring-1 focus:ring-white/25"
        />
        <select
          value={form.regime}
          onChange={(e) => setForm((f) => ({ ...f, regime: e.target.value }))}
          className="min-h-[42px] rounded-lg bg-white/[0.07] px-3 text-sm text-white focus:outline-none focus:ring-1 focus:ring-white/25 [color-scheme:dark]"
        >
          <option value="">Régime…</option>
          {REGIMES.map((r) => (
            <option key={r} value={r}>{r}</option>
          ))}
        </select>
      </div>
      <div className="flex flex-wrap gap-1.5">
        {ALLERGENES_OFFICIELS.map((a) => (
          <button
            key={a}
            type="button"
            onClick={() => basculerAllergene(a)}
            aria-pressed={form.allergenes.includes(a)}
            className={`min-h-[32px] px-3 rounded-full text-xs font-semibold transition-colors ${
              form.allergenes.includes(a)
                ? "bg-[#FF453A] text-white"
                : "bg-white/[0.08] text-white/60 hover:bg-white/15"
            }`}
          >
            {a}
          </button>
        ))}
      </div>
      <div className="flex gap-2">
        <input
          value={form.commentaire}
          onChange={(e) => setForm((f) => ({ ...f, commentaire: e.target.value }))}
          placeholder="Précision (ex. allergie sévère, table 4…)"
          className="flex-1 min-h-[42px] rounded-lg bg-white/[0.07] px-3 text-sm text-white placeholder:text-white/30 focus:outline-none focus:ring-1 focus:ring-white/25"
        />
        <button
          type="submit"
          disabled={!form.nom.trim() || envoi}
          className="inline-flex items-center gap-1.5 min-h-[42px] px-4 rounded-full bg-white text-black text-sm font-bold hover:bg-white/90 disabled:opacity-40 transition-colors"
        >
          {envoi ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
          Ajouter
        </button>
      </div>
    </form>
  );
}