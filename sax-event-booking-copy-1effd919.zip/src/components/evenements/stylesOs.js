// Styles partagés du « Event OS » (onglet Événements) — sombre, grille pointillée, sans crème/champagne.

export const FOND_POINTILLE = {
  backgroundColor: "#050506",
  backgroundImage: "radial-gradient(rgba(255,255,255,0.07) 1px, transparent 1px)",
  backgroundSize: "26px 26px",
};

export const classeInputOs =
  "min-h-[42px] w-full rounded-lg bg-white/[0.07] px-3 text-sm text-white placeholder:text-white/30 focus:outline-none focus:ring-1 focus:ring-white/25 [color-scheme:dark]";

export const classeBoutonOs =
  "min-h-[42px] px-4 rounded-full bg-[#F5F5F7] text-[#0A0A0C] text-sm font-bold hover:opacity-85 transition-opacity inline-flex items-center justify-center gap-1.5";

// Bouton bleu-vert — actions du moteur causal.
export const classeBoutonBleuVert =
  "min-h-[42px] px-4 rounded-full bg-[#0D9488] text-white text-sm font-bold hover:opacity-85 transition-opacity inline-flex items-center justify-center gap-1.5";

// Variantes claires — blocs sans fond posés sur la page blanche.
export const classeInputClair =
  "min-h-[42px] w-full rounded-lg border border-black/15 bg-white px-3 text-sm text-[#1D1D1F] placeholder:text-black/35 focus:outline-none focus:border-black";

export const classeBoutonClair =
  "min-h-[42px] px-4 rounded-full bg-[#141416] text-white text-sm font-bold hover:opacity-85 transition-opacity inline-flex items-center justify-center gap-1.5";

// Boîtier noir façon Apple Watch — partagé par les blocs du Studio.
export const classeBoitierWatch =
  "rounded-[2.5rem] md:rounded-[3rem] bg-black text-white p-5 md:p-8 shadow-[0_24px_60px_-24px_rgba(0,0,0,0.45)]";

export const STYLE_SF = {
  fontFamily: "-apple-system, BlinkMacSystemFont, 'SF Pro Display', 'Helvetica Neue', Inter, sans-serif",
};

export const BADGES_STATUT_OS = {
  brouillon: "bg-white/10 text-white/60",
  confirme: "bg-[#30D158]/15 text-[#30D158]",
  realise: "bg-[#0071E3]/15 text-[#6CB4FF]",
  annule: "bg-[#FF453A]/15 text-[#FF453A]",
};