import React from "react";
import { ArrowRight, ShieldCheck, AlertTriangle, Minimize2 } from "lucide-react";

const STYLES = {
  decale: { Icone: ArrowRight, classes: "text-[#6CB4FF]" },
  absorbe: { Icone: ShieldCheck, classes: "text-[#30D158]" },
  conflit: { Icone: AlertTriangle, classes: "text-[#FF453A]" },
  comprime: { Icone: Minimize2, classes: "text-[#FFD60A]" },
  barriere: { Icone: ShieldCheck, classes: "text-[#30D158]" },
  dependance: { Icone: AlertTriangle, classes: "text-[#BF5AF2]" },
};

export default function ListeImpacts({ impacts }) {
  return (
    <ul className="space-y-1.5">
      {impacts.map((imp, i) => {
        const { Icone, classes } = STYLES[imp.type] || STYLES.decale;
        return (
          <li key={i} className="flex items-start gap-2.5 rounded-xl bg-white/[0.06] px-4 py-2.5 text-sm text-white/80">
            <Icone className={`h-4 w-4 mt-0.5 shrink-0 ${classes}`} />
            {imp.detail}
          </li>
        );
      })}
    </ul>
  );
}