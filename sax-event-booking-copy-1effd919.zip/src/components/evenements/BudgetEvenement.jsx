import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { calculerBudget } from "@/lib/moteurCausal";
import { classeInputOs } from "@/components/evenements/stylesOs";

const euros = (n) => `${Number(n || 0).toLocaleString("fr-FR")} €`;

export default function BudgetEvenement({ evenement, onMaj }) {
  const [budget, setBudget] = useState(evenement.budgetPrevisionnel ?? "");
  const [docs, setDocs] = useState([]);
  const engage = calculerBudget(evenement.moments);
  const previsionnel = Number(evenement.budgetPrevisionnel) || 0;

  useEffect(() => {
    // On rattache aussi les documents émis pour la même date que l'événement
    // (devis créés depuis le studio de documents, sans lien explicite).
    Promise.all([
      base44.entities.DocumentEmis.filter({ evenementId: evenement.id }, "-created_date", 100),
      evenement.date
        ? base44.entities.DocumentEmis.filter({ dateEvenement: evenement.date }, "-created_date", 100)
        : Promise.resolve([]),
    ])
      .then(([lies, memeDate]) => {
        const parId = new Map();
        [...lies, ...memeDate].forEach((d) => parId.set(d.id, d));
        setDocs([...parId.values()]);
      })
      .catch(() => setDocs([]));
  }, [evenement.id, evenement.date]);

  const somme = (type) =>
    docs
      .filter((d) => d.type === type && d.statut !== "refuse")
      .reduce((t, d) => t + (Number(d.montant) || 0), 0);
  const devise = somme("devis");
  const facture = somme("facture");
  const ecart = previsionnel - (engage + devise);

  const stats = [
    ["Déroulé", euros(engage), "text-white"],
    ["Devis", euros(devise), "text-white"],
    ["Facturé", euros(facture), "text-white"],
    ["Écart", previsionnel === 0 ? "—" : euros(ecart), previsionnel === 0 ? "text-white/40" : ecart >= 0 ? "text-[#30D158]" : "text-[#FF453A]"],
  ];

  return (
    <div className="grid min-w-0 grid-cols-2 gap-4 text-white sm:flex sm:flex-wrap sm:items-center sm:gap-x-8 sm:gap-y-3">
      <h3 className="text-[10px] font-bold uppercase tracking-[0.3em] text-white/40">Budget vivant</h3>
      <label className="col-span-2 flex min-w-0 flex-col gap-1 sm:col-auto sm:inline-flex sm:flex-row sm:items-center sm:gap-2">
        <span className="text-[11px] text-white/40">Prévisionnel</span>
        <input
          type="number"
          className={`${classeInputOs} !min-h-[44px] w-full sm:w-28`}
          value={budget}
          onChange={(e) => setBudget(e.target.value)}
          onBlur={() => onMaj("budgetPrevisionnel", Number(budget) || 0)}
          placeholder="5000"
          aria-label="Budget prévisionnel en euros"
        />
      </label>
      {stats.map(([libelle, valeur, classe]) => (
        <div key={libelle} className="flex flex-col">
          <span className="text-[10px] text-white/40">{libelle}</span>
          <span className={`text-lg font-semibold leading-tight tabular-nums ${classe}`}>{valeur}</span>
        </div>
      ))}
    </div>
  );
}