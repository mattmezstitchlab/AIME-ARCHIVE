import React from "react";
import { Sparkles } from "lucide-react";
import { MODELES_EVENEMENTS } from "@/lib/modelesEvenements";
import { classeBoutonOs } from "@/components/evenements/stylesOs";

const cleModele = (type = "") => {
  const valeur = type.toLowerCase();
  if (/sport|football|match|tournoi/.test(valeur)) return "sportif";
  return Object.entries(MODELES_EVENEMENTS).find(([, modele]) => valeur.includes(modele.libelle.toLowerCase()))?.[0];
};

export default function ModeleDemarrage({ typeEvenement, onAppliquer }) {
  const modele = MODELES_EVENEMENTS[cleModele(typeEvenement)];
  if (!modele?.moments?.length) return null;
  return <div className="flex flex-wrap items-center justify-between gap-4 border-t border-white/10 pt-5 text-white">
    <div className="flex max-w-2xl items-start gap-3">
      <Sparkles className="mt-0.5 h-5 w-5 shrink-0 text-[#0A84FF]" />
      <div><p className="text-sm font-semibold">Démarrer avec une trame {modele.libelle.toLowerCase()}</p><p className="mt-1 text-xs leading-relaxed text-white/50">{modele.moments.length} moments et {modele.acteurs.length} rôles opérationnels seront proposés. Les horaires sont indicatifs : vérifiez-les avant de poursuivre.</p></div>
    </div>
    <button type="button" onClick={() => onAppliquer(modele.moments, modele.acteurs)} className={classeBoutonOs}>Utiliser cette trame</button>
  </div>;
}