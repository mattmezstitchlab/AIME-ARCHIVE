import React from "react";
import { ChevronRight, Folder } from "lucide-react";

export default function CarteTiroirDocument({ groupe, onOuvrir }) {
  const prets = groupe.pieces.filter((piece) => piece.statut === "pret").length;
  const progression = groupe.pieces.length ? Math.round((prets / groupe.pieces.length) * 100) : 0;
  return <button type="button" onClick={() => onOuvrir(groupe.cle)} aria-label={`Ouvrir le dossier ${groupe.label}`} className="group flex min-h-[148px] min-w-0 flex-col rounded-2xl border border-white/10 bg-white/[0.055] p-3 text-left transition-colors hover:border-white/20 hover:bg-white/[0.08] focus-visible:ring-2 focus-visible:ring-[#BF5AF2]">
    <span className="mb-4 flex w-full items-start justify-between gap-2"><span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-[#FF2D78]/20 via-[#BF5AF2]/20 to-[#0A84FF]/20"><Folder className="h-5 w-5 text-[#BF5AF2]" /></span><ChevronRight className="h-4 w-4 text-white/30 transition-transform group-hover:translate-x-0.5" /></span>
    <span className="block w-full truncate text-sm font-semibold text-white">{groupe.label}</span>
    <span className="mt-1 text-[11px] leading-4 text-white/45">{prets}/{groupe.pieces.length} prêts · {groupe.documents.length} doc.</span>
    <span className="mt-auto h-1 w-full overflow-hidden rounded-full bg-white/10"><span className="block h-full rounded-full bg-gradient-to-r from-[#FF2D78] via-[#BF5AF2] to-[#0A84FF]" style={{ width: `${progression}%` }} /></span>
  </button>;
}