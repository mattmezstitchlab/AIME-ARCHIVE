import React, { useEffect } from "react";
import { X } from "lucide-react";

export default function CadrePanneauDocuments({ onFermer, children }) {
  useEffect(() => { const avant = document.body.style.overflow; document.body.style.overflow = "hidden"; return () => { document.body.style.overflow = avant; }; }, []);
  return <>
    <button type="button" aria-label="Fermer les documents" onClick={onFermer} className="fixed inset-0 z-40 cursor-default bg-black/60 backdrop-blur-[2px]" />
    <aside aria-label="Bureau des documents" className="fixed inset-x-2 bottom-[calc(5.5rem+env(safe-area-inset-bottom))] top-2 z-[45] overflow-hidden rounded-[1.75rem] border border-white/10 bg-black/95 shadow-[0_28px_90px_rgba(0,0,0,0.75)] backdrop-blur-2xl sm:left-auto sm:right-4 sm:top-4 sm:w-[min(560px,calc(100vw-2rem))]">
      <button type="button" onClick={onFermer} aria-label="Fermer le bureau des documents" className="absolute right-3 top-3 z-10 flex h-11 w-11 items-center justify-center rounded-full bg-white/10 text-white/70 hover:bg-white/15 hover:text-white"><X className="h-5 w-5" /></button>
      <div className="h-full overflow-y-auto overscroll-contain px-4 pb-8 pt-5 sm:px-5">{children}</div>
    </aside>
  </>;
}