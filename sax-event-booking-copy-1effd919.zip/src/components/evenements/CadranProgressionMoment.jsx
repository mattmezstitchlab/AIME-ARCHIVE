import React from "react";
import { AlertTriangle, CheckCircle2, Clock3 } from "lucide-react";
import AnneauxEtatMoment from "@/components/evenements/AnneauxEtatMoment";
import { calculerProgressionMoment, impactsPourMoment } from "@/lib/progressionMoment";

export default function CadranProgressionMoment({ moment, evenement, documents, impacts, index }) {
  const progression = calculerProgressionMoment(moment, evenement, documents), alertes = impactsPourMoment(moment, impacts);
  return <section className="flex min-h-full snap-start flex-col items-center justify-center px-1 py-5" aria-label={`${moment.titre}, ${progression.confirmees} confirmations sur ${progression.total}`}>
    <div className="text-center"><p className="text-xs font-bold text-[#FF6BA8]">{moment.heureDebut || "Horaire à confirmer"}</p><h3 className="mt-1 max-w-[270px] truncate text-lg font-semibold text-white">{moment.titre || `Moment ${index + 1}`}</h3></div>
    <div className="mt-3"><AnneauxEtatMoment moment={moment} moments={evenement.moments || []} progression={progression} index={index} /></div>
    <div className="mb-3 flex flex-wrap justify-center gap-x-3 gap-y-1" aria-label="État des cinq dimensions">{progression.axes.map((axe) => <span key={axe.id} className="inline-flex items-center gap-1 text-[9px] font-semibold text-white/40"><span className={`h-1.5 w-1.5 rounded-full ${axe.statut === "confirme" ? "bg-[#30D158]" : axe.statut === "a_verifier" ? "bg-[#FF9F0A]" : "bg-white/20"}`} />{axe.label}</span>)}</div>
    <div className="w-full max-w-[285px]">{progression.restantes.length ? <><p className="mb-2 flex items-center gap-1.5 text-xs font-semibold text-white/55"><Clock3 className="h-3.5 w-3.5" />{progression.restantes.length} tâche{progression.restantes.length > 1 ? "s" : ""} restante{progression.restantes.length > 1 ? "s" : ""}</p><ul className="space-y-1">{progression.restantes.slice(0, 3).map((tache) => <li key={tache.label} className="truncate text-xs text-white/40">• {tache.label}</li>)}</ul></> : <p className="flex items-center justify-center gap-2 text-xs font-semibold text-[#30D158]"><CheckCircle2 className="h-4 w-4" />Toutes les confirmations sont obtenues</p>}{alertes.length > 0 && <p className="mt-3 flex items-center gap-1.5 text-xs font-semibold text-[#FFB340]"><AlertTriangle className="h-3.5 w-3.5" />{alertes.length} impact{alertes.length > 1 ? "s" : ""} causal{alertes.length > 1 ? "aux" : ""}</p>}</div>
  </section>;
}