import React, { useEffect, useState } from "react";
import { STATUTS_EVENEMENT } from "@/lib/acteursEvenement";
import { classeInputOs } from "@/components/evenements/stylesOs";

export default function ReglagesEvenement({ evenement, onMaj, lectureSeule = false }) {
  const [titre, setTitre] = useState(evenement.titre || "");

  useEffect(() => { setTitre(evenement.titre || ""); }, [evenement.titre]);

  return (
    <section className="space-y-4" aria-labelledby="titre-reglages-evenement">
      <div>
        <h3 id="titre-reglages-evenement" className="text-[10px] font-bold uppercase tracking-[0.3em] text-white/60">Réglages de l’événement</h3>
        <p className="mt-1 text-xs text-white/45">{lectureSeule ? "Vous pouvez consulter ces réglages, mais seul le propriétaire peut les modifier." : "Ces réglages concernent uniquement cet événement."}</p>
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        <label className="space-y-1.5 text-xs text-white/60">
          <span>Titre</span>
          <input disabled={lectureSeule} className={classeInputOs} value={titre} onChange={(event) => setTitre(event.target.value)} onBlur={() => !lectureSeule && titre.trim() && onMaj("titre", titre.trim())} />
        </label>
        <label className="space-y-1.5 text-xs text-white/60">
          <span>Statut</span>
          <select disabled={lectureSeule} className={classeInputOs} value={evenement.statut || "brouillon"} onChange={(event) => onMaj("statut", event.target.value)}>
            {Object.entries(STATUTS_EVENEMENT).map(([valeur, libelle]) => <option key={valeur} value={valeur}>{libelle}</option>)}
          </select>
        </label>
      </div>
    </section>
  );
}