import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import StudioDocument from "@/components/documents/StudioDocument";
import GuideDocumentsEvenement from "@/components/evenements/GuideDocumentsEvenement";
import CadrePanneauDocuments from "@/components/evenements/CadrePanneauDocuments";
import { Loader2, Plus, X } from "lucide-react";

export default function DocumentsEvenement({ evenement, actionInitiale, lectureSeule = false, onFermer }) {
  const [documents, setDocuments] = useState(null);
  const [formVisible, setFormVisible] = useState(false);
  const [typeInitial, setTypeInitial] = useState(null);
  const [destinataire, setDestinataire] = useState(null);
  const [telechargement, setTelechargement] = useState("");

  const charger = () =>
    base44.entities.DocumentEmis.filter({ evenementId: evenement.id }, "-created_date", 100).then(setDocuments);

  useEffect(() => {
    setDocuments(null); setFormVisible(false); setTypeInitial(null); setDestinataire(null); charger();
  }, [evenement.id]);

  useEffect(() => {
    if (!actionInitiale?.documentType) return;
    setDestinataire(null); setTypeInitial(actionInitiale.documentType); setFormVisible(true);
  }, [actionInitiale?.id]);

  const telecharger = async (doc) => {
    setTelechargement(doc.id);
    try {
      let lien = doc.fichierUrl;
      if (!String(lien).startsWith("http")) {
        const { signed_url } = await base44.integrations.Core.CreateFileSignedUrl({ file_uri: lien });
        lien = signed_url;
      }
      window.open(lien, "_blank");
    } finally {
      setTelechargement("");
    }
  };

  return (
    <CadrePanneauDocuments onFermer={onFermer}>
    <div className="space-y-5 text-white">
      <div>
        <div className="mb-4 flex items-center pr-12">
          {!lectureSeule && <button
            onClick={() => { setDestinataire(null); setFormVisible((v) => !v); }}
            className="inline-flex min-h-[44px] items-center gap-1.5 px-4 rounded-full bg-white/10 text-sm text-white hover:bg-white/15 transition-colors"
          >
            {formVisible ? <X className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
            {formVisible ? "Fermer" : "Nouveau document"}
          </button>}
        </div>

        {documents === null ? <div className="flex justify-center py-12"><Loader2 className="h-5 w-5 animate-spin text-white/40" /></div> : <GuideDocumentsEvenement evenement={evenement} documents={documents} lectureSeule={lectureSeule} onCreer={(acteur) => { setDestinataire(acteur); setTypeInitial("contrat"); setFormVisible(true); }} onTelecharger={telecharger} telechargement={telechargement} />}
      </div>

      {formVisible && (
        <StudioDocument
          email={evenement.proprietaire}
          evenementId={evenement.id}
          valeursInitiales={{
            type: typeInitial || "devis",
            clientNom: destinataire?.nom || evenement.organisateurNom || "",
            clientEmail: destinataire?.email || evenement.organisateurEmail || "",
            clientTelephone: destinataire ? "" : evenement.organisateurTelephone || "",
            description: evenement.titre || "",
            dateEvenement: evenement.date || "",
            lieu: evenement.lieu || "",
          }}
          onFermer={() => { setFormVisible(false); setDestinataire(null); }}
          onGenere={() => {
            setFormVisible(false);
            setTypeInitial(null);
            setDestinataire(null);
            charger();
            window.dispatchEvent(new Event("aime-event-documents"));
          }}
        />
      )}
    </div>
    </CadrePanneauDocuments>
  );
}