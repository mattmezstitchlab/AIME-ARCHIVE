import React, { useEffect, useMemo, useState } from "react";
import { Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { construireGuideDocuments } from "@/lib/guideDocumentsEvenement";
import TiroirDocuments from "@/components/evenements/TiroirDocuments";
import CarteTiroirDocument from "@/components/evenements/CarteTiroirDocument";

const normaliser = (v) => String(v || "").trim().toLowerCase();
export default function GuideDocumentsEvenement({ evenement, documents, lectureSeule, onCreer, onTelecharger, telechargement }) {
  const [pieces, setPieces] = useState(null), [utilisateur, setUtilisateur] = useState(null), [erreur, setErreur] = useState("");
  const [groupeActif, setGroupeActif] = useState(null);
  useEffect(() => { let actif = true; setPieces(null); setErreur(""); setGroupeActif(null); Promise.all([base44.auth.me(), base44.entities.PieceDossierEvenement.filter({ evenementId: evenement.id }, "created_date", 200)]).then(async ([moi, existantes]) => {
    if (!actif) return; setUtilisateur(moi); let liste = existantes;
    if (moi.role === "admin" || normaliser(moi.email) === normaliser(evenement.proprietaire)) {
      const cles = new Set(existantes.map((p) => p.cle)), manquantes = construireGuideDocuments(evenement).filter((p) => !cles.has(p.cle));
      if (manquantes.length) liste = [...existantes, ...await base44.entities.PieceDossierEvenement.bulkCreate(manquantes)];
    }
    if (actif) setPieces(liste);
  }).catch(() => { if (actif) { setPieces([]); setErreur("Le guide documentaire n’a pas pu être chargé."); } }); return () => { actif = false; }; }, [evenement.id, evenement.acteurs, evenement.lieu]);
  const groupes = useMemo(() => { const map = new Map(); (pieces || []).forEach((p) => { const cle = p.categorie === "acteur" ? `acteur:${normaliser(p.acteurEmail || p.acteurNom)}` : p.categorie; if (!map.has(cle)) map.set(cle, { cle, label: p.categorie === "evenement" ? "Événement" : p.categorie === "lieu" ? evenement.lieu : p.acteurNom, acteur: p.categorie === "acteur" ? { nom: p.acteurNom, email: p.acteurEmail, role: p.acteurRole } : null, pieces: [], documents: [] }); map.get(cle).pieces.push(p); }); (documents || []).forEach((d) => { const cle = [...map.keys()].find((k) => k.startsWith("acteur:") && k === `acteur:${normaliser(d.clientEmail)}`) || "evenement"; map.get(cle)?.documents.push(d); }); return [...map.values()]; }, [pieces, documents, evenement.lieu]);
  const changerStatut = async (piece, statut) => { const historique = [...(piece.historique || []), { avant: piece.statut, apres: statut, par: utilisateur.email, date: new Date().toISOString() }]; setPieces((liste) => liste.map((p) => p.id === piece.id ? { ...p, statut, historique } : p)); await base44.entities.PieceDossierEvenement.update(piece.id, { statut, historique }); };
  const peutModifier = (piece) => !lectureSeule || normaliser(piece.acteurEmail) === normaliser(utilisateur?.email);
  if (pieces === null) return <div className="flex justify-center py-8"><Loader2 className="h-5 w-5 animate-spin text-white/40" /></div>;
  if (erreur) return <p role="alert" className="py-6 text-center text-sm text-[#FF6961]">{erreur}</p>;
  if (!groupes.length) return <p className="py-6 text-center text-sm text-white/50">Aucun tiroir documentaire ne vous est attribué.</p>;
  const actif = groupes.find((groupe) => groupe.cle === groupeActif);
  if (actif) return <TiroirDocuments groupe={actif} peutModifier={peutModifier} onStatut={changerStatut} onCreer={!lectureSeule ? onCreer : null} onTelecharger={onTelecharger} telechargement={telechargement} onRetour={() => setGroupeActif(null)} />;
  return <div><div className="mb-5 pr-12"><p className="text-xs font-bold uppercase tracking-[0.18em] text-white/40">Bureau documentaire</p><h4 className="mt-1 text-xl font-semibold tracking-tight text-white">Choisir un tiroir</h4><p className="mt-1 text-sm text-white/45">Chaque personne retrouve uniquement les pièces qui la concernent.</p></div><div className="grid grid-cols-2 gap-3">{groupes.map((groupe) => <CarteTiroirDocument key={groupe.cle} groupe={groupe} onOuvrir={setGroupeActif} />)}</div></div>;
}