import React from "react";
import { ShieldCheck } from "lucide-react";
import { construireTrajectoireCausale } from "@/lib/trajectoiresCausales";

const Ligne = ({ label, valeur, accent }) => <div className="grid grid-cols-[72px_1fr] gap-2 border-t border-white/10 py-2 first:border-0"><dt className={`text-[9px] font-bold uppercase tracking-[0.14em] ${accent || "text-white/35"}`}>{label}</dt><dd className="text-[11px] leading-4 text-white/65">{valeur}</dd></div>;

export default function TrajectoireCausale({ evenement, impacts }) {
  const trajectoire = construireTrajectoireCausale(evenement, impacts);
  return <section className="mx-auto mt-4 w-full max-w-[300px] rounded-2xl border border-white/10 bg-white/[0.045] px-4 py-2" aria-labelledby="trajectoire-causale"><div className="flex min-h-[36px] items-center gap-2"><ShieldCheck className="h-4 w-4 text-[#BF5AF2]" aria-hidden="true" /><h3 id="trajectoire-causale" className="text-[10px] font-bold uppercase tracking-[0.18em] text-white/55">Trajectoire actuelle</h3></div><dl><Ligne label="Observé" valeur={trajectoire.observation} /><Ligne label="Alors" valeur={trajectoire.alors} /><Ligne label="Parce que" valeur={trajectoire.parceQue} /><Ligne label="Sauf si" valeur={trajectoire.saufSi} accent="text-[#30D158]" /><Ligne label="Confiance" valeur={trajectoire.confiance} /><Ligne label="À valider" valeur={trajectoire.validation} accent="text-[#FFB340]" /></dl></section>;
}