import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { ChevronLeft, ChevronRight } from "lucide-react";

const JOURS = ["L", "M", "M", "J", "V", "S", "D"];
const MOIS = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre", "novembre", "décembre"];

const iso = (a, m, j) => `${a}-${String(m).padStart(2, "0")}-${String(j).padStart(2, "0")}`;

// Calendrier d'orchestration : cliquer une date déplace l'événement (le déroulé,
// le cadran et le compte à rebours suivent), les points signalent vos autres événements.
export default function MiniCalendrier({ date, evenementId, onDeplacer }) {
  const [aDate, mDate, jDate] = String(date || "").split("-").map(Number);
  const [vue, setVue] = useState(date ? { a: aDate, m: mDate } : null);
  const [autres, setAutres] = useState({});
  const [choix, setChoix] = useState(null);

  useEffect(() => {
    base44.entities.Evenement.list("-date", 300).then((liste) => {
      const parDate = {};
      liste.forEach((ev) => {
        if (ev.id !== evenementId && ev.date && ev.statut !== "annule") parDate[ev.date] = ev.titre;
      });
      setAutres(parDate);
    }).catch(() => {});
  }, [evenementId]);

  if (!date || !vue) return <p className="text-sm text-white/50">Aucune date définie pour cet événement.</p>;

  const { a, m } = vue;
  const decalage = (new Date(a, m - 1, 1).getDay() + 6) % 7;
  const nbJours = new Date(a, m, 0).getDate();
  const cases = [...Array(decalage).fill(null), ...Array.from({ length: nbJours }, (_, i) => i + 1)];
  const naviguer = (dir) => setVue(({ a, m }) => (m + dir < 1 ? { a: a - 1, m: 12 } : m + dir > 12 ? { a: a + 1, m: 1 } : { a, m: m + dir }));

  const jourEvenement = a === aDate && m === mDate ? jDate : null;
  const joursRestants = Math.ceil((new Date(aDate, mDate - 1, jDate) - new Date().setHours(0, 0, 0, 0)) / 86400000);

  return (
    <div className="max-w-xs mx-auto">
      <div className="flex items-center justify-between">
        <button onClick={() => naviguer(-1)} title="Mois précédent" aria-label="Mois précédent" className="h-8 w-8 inline-flex items-center justify-center rounded-full bg-white/10 text-white/70 hover:bg-white/20 hover:text-white transition-colors">
          <ChevronLeft className="h-4 w-4" />
        </button>
        <p className="text-sm font-semibold text-white/70 capitalize">{MOIS[m - 1]} {a}</p>
        <button onClick={() => naviguer(1)} title="Mois suivant" aria-label="Mois suivant" className="h-8 w-8 inline-flex items-center justify-center rounded-full bg-white/10 text-white/70 hover:bg-white/20 hover:text-white transition-colors">
          <ChevronRight className="h-4 w-4" />
        </button>
      </div>

      <div className="mt-3 grid grid-cols-7 gap-1 text-center">
        {JOURS.map((jj, i) => (
          <span key={`j${i}`} className="text-[10px] font-bold text-white/40">{jj}</span>
        ))}
        {cases.map((n, i) => {
          if (n === null) return <span key={`c${i}`} />;
          const dISO = iso(a, m, n);
          const estEvenement = n === jourEvenement;
          const autre = autres[dISO];
          return (
            <button
              key={`c${i}`}
              type="button"
              onClick={() => !estEvenement && setChoix(dISO)}
              title={autre ? `Déjà occupé : ${autre}` : estEvenement ? "Date de l'événement" : "Déplacer l'événement à cette date"}
              className={`relative h-8 flex items-center justify-center rounded-full text-sm tabular-nums transition-colors ${
                estEvenement ? "text-white font-bold" : choix === dISO ? "bg-white text-black font-bold" : "text-white/60 hover:bg-white/15 hover:text-white"
              }`}
              style={estEvenement ? { backgroundImage: "linear-gradient(135deg, #0A84FF, #BF5AF2, #FF2D78)" } : undefined}
            >
              {n}
              {autre && !estEvenement && (
                <span className="absolute bottom-0.5 h-1 w-1 rounded-full bg-[#FF9F0A]" aria-hidden="true" />
              )}
            </button>
          );
        })}
      </div>

      {choix ? (
        <div className="mt-4 rounded-2xl bg-white/10 p-3 text-center space-y-2">
          <p className="text-sm text-white">
            Déplacer l'événement au <span className="font-bold">{Number(choix.split("-")[2])} {MOIS[Number(choix.split("-")[1]) - 1]}</span> ?
            {autres[choix] && <span className="block text-xs text-[#FF9F0A] mt-1">Attention : « {autres[choix]} » a déjà lieu ce jour-là.</span>}
          </p>
          <p className="text-[11px] text-white/50">Le déroulé, le cadran et le compte à rebours suivent automatiquement.</p>
          <div className="flex justify-center gap-2">
            <button
              onClick={() => { onDeplacer?.(choix); setChoix(null); setVue({ a: Number(choix.split("-")[0]), m: Number(choix.split("-")[1]) }); }}
              className="min-h-[38px] px-4 rounded-full bg-white text-black text-sm font-bold hover:bg-white/90 transition-colors"
            >
              Confirmer
            </button>
            <button onClick={() => setChoix(null)} className="min-h-[38px] px-4 rounded-full bg-white/10 text-white text-sm font-semibold hover:bg-white/20 transition-colors">
              Annuler
            </button>
          </div>
        </div>
      ) : (
        <p className="mt-4 text-center text-xs text-white/50">
          {joursRestants > 0 ? <>J&nbsp;−&nbsp;<span className="font-bold text-white tabular-nums">{joursRestants}</span> — cliquez une date pour déplacer l'événement.</> : joursRestants === 0 ? "C'est aujourd'hui !" : "Événement passé."}
          {Object.keys(autres).length > 0 && <span className="block mt-1"><span className="inline-block h-1.5 w-1.5 rounded-full bg-[#FF9F0A] mr-1.5 align-middle" />vos autres événements</span>}
        </p>
      )}
    </div>
  );
}