import React, { useEffect, useState } from "react";
import { CATEGORIES_ACTEURS } from "@/lib/acteursEvenement";
import { Radio } from "lucide-react";

function enSecondes(hhmm) {
  if (!hhmm) return null;
  const [h, m] = String(hhmm).split(":").map(Number);
  return h * 3600 + m * 60;
}

function formatCompte(sec) {
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  return [h, m, s].map((n) => String(n).padStart(2, "0")).join(":");
}

export default function JourJLive({ evenement, email }) {
  const [maintenant, setMaintenant] = useState(new Date());
  const [vue, setVue] = useState("tous");

  useEffect(() => {
    const timer = setInterval(() => setMaintenant(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const secNow = maintenant.getHours() * 3600 + maintenant.getMinutes() * 60 + maintenant.getSeconds();
  const moments = [...(evenement.moments || [])].sort((a, b) => (enSecondes(a.heureDebut) ?? 0) - (enSecondes(b.heureDebut) ?? 0));

  const enCours = moments.find((m) => {
    const d = enSecondes(m.heureDebut);
    let f = enSecondes(m.heureFin);
    if (d === null || f === null) return false;
    if (f < d) f += 86400; // passage minuit
    return secNow >= d && secNow < f;
  });
  const suivant = moments.find((m) => (enSecondes(m.heureDebut) ?? 0) > secNow);

  // Vue par acteur : l'invité connecté peut filtrer sur ses propres moments.
  const monActeur = (evenement.acteurs || []).find(
    (a) => (a.email || "").toLowerCase() === (email || "").toLowerCase() && a.email
  );
  const momentsAffiches =
    vue === "miens" && monActeur ? moments.filter((m) => m.responsable === monActeur.nom) : moments;

  return (
    <div className="space-y-5">
      <div className="py-2">
        <div className="flex flex-wrap items-center gap-2">
          <span className="inline-flex items-center gap-2 min-h-[36px] px-4 rounded-full bg-white/10 text-white text-[10px] font-bold uppercase tracking-[0.25em]">
            <Radio className="h-3.5 w-3.5 animate-pulse text-[#30D158]" aria-hidden="true" /> Jour J — en direct
          </span>
          <span className="inline-flex items-center min-h-[36px] px-4 rounded-full bg-white/10 text-white/70 text-xs font-semibold">
            {enCours ? "Moment en cours" : "En attente"}
          </span>
        </div>

        <div className="mt-7 grid md:grid-cols-[1fr_auto] gap-6 md:gap-10 items-end">
          <div>
            <p className="font-heading text-3xl md:text-5xl font-semibold tracking-tight text-white">
              {enCours ? enCours.titre : "Aucun moment en cours."}
            </p>
            {enCours && (
              <p className="mt-2 text-sm text-white/80">
                {enCours.heureDebut}–{enCours.heureFin}
                {enCours.responsable && ` · ${enCours.responsable}`}
              </p>
            )}
            {suivant ? (
              <p className="mt-4 text-sm text-white/90">
                À suivre : <span className="font-semibold text-white">{suivant.titre}</span>{" "}
                <span className="tabular-nums font-bold texte-prisme">
                  dans {formatCompte((enSecondes(suivant.heureDebut) ?? 0) - secNow)}
                </span>
              </p>
            ) : (
              <p className="mt-4 text-sm text-white/70">Plus aucun moment à venir aujourd'hui.</p>
            )}
          </div>
          <p className="font-heading font-bold leading-none text-5xl md:text-7xl tracking-tight tabular-nums text-right texte-prisme">
            {maintenant.toLocaleTimeString("fr-FR")}
          </p>
        </div>

        <p className="mt-5 text-[11px] text-white/70">
          Chaque modification du déroulé est diffusée instantanément à tous les acteurs de l'événement.
        </p>
      </div>

      {monActeur && (
        <div className="flex gap-1.5 rounded-full bg-white/10 p-1.5 w-fit" role="group" aria-label="Filtrer le déroulé">
          {[["tous", "Tout le déroulé"], ["miens", "Mes moments"]].map(([cle, libelle]) => (
            <button
              key={cle}
              onClick={() => setVue(cle)}
              className={`min-h-[38px] px-4 rounded-full text-sm transition-colors ${
                vue === cle ? "bg-white text-black font-semibold" : "text-white/60 hover:text-white"
              }`}
            >
              {libelle}
            </button>
          ))}
        </div>
      )}

      <ol className="space-y-1.5 text-white" aria-label="Déroulé en direct">
        {momentsAffiches.map((m, i) => {
          const d = enSecondes(m.heureDebut) ?? 0;
          let f = enSecondes(m.heureFin) ?? d;
          if (f < d) f += 86400;
          const statut = secNow >= f ? "passé" : secNow >= d ? "en cours" : "à venir";
          return (
            <li
              key={`${m.titre}-${i}`}
              className={`flex items-center gap-3 rounded-xl px-4 py-3 text-sm ${
                statut === "en cours" ? "bg-white/10" : "bg-white/[0.07]"
              } ${statut === "passé" ? "opacity-45" : ""}`}
            >
              <span
                className={`h-2.5 w-2.5 rounded-full shrink-0 ${statut === "en cours" ? "animate-pulse" : ""}`}
                style={{ backgroundColor: CATEGORIES_ACTEURS[m.categorie]?.couleur || "#999" }}
                aria-hidden="true"
              />
              <span className="text-xs text-white/50 tabular-nums">{m.heureDebut}–{m.heureFin}</span>
              <span className="flex-1">{m.titre}</span>
              <span className="text-[10px] font-bold uppercase tracking-wider text-white/40">
                {statut}
              </span>
            </li>
          );
        })}
        {momentsAffiches.length === 0 && (
          <p className="text-sm text-white/50 px-1">
            {vue === "miens" ? "Aucun moment ne vous est attribué comme responsable." : "Ajoutez des moments dans l'onglet Déroulé pour activer le direct."}
          </p>
        )}
      </ol>
    </div>
  );
}