import React, { useRef, useState } from "react";
import { ChevronDown } from "lucide-react";
import CadranProgressionMoment from "@/components/evenements/CadranProgressionMoment";
import CadranCausal from "@/components/evenements/CadranCausal";
import TrajectoireCausale from "@/components/evenements/TrajectoireCausale";
import VueRadialeJourJ from "@/components/evenements/VueRadialeJourJ";

export default function ListeCadransMoments({ evenement, documents, impacts, actions, onChoisirAction, onImpact, onOuvrirDocuments }) {
  const liste = useRef(null), depart = useRef(null), [traction, setTraction] = useState(0), [radial, setRadial] = useState(false);
  const commencer = (event) => { if ((liste.current?.scrollTop || 0) <= 0) depart.current = event.touches[0].clientY; };
  const tirer = (event) => { if (depart.current === null) return; setTraction(Math.max(0, Math.min(90, event.touches[0].clientY - depart.current))); };
  const terminer = () => { if (traction >= 64) setRadial(true); depart.current = null; setTraction(0); };
  if (radial) return <VueRadialeJourJ evenement={evenement} documents={documents} impacts={impacts} onImpact={onImpact} onFermer={() => setRadial(false)} />;
  const moments = evenement.moments || [];
  return <div className="relative"><button type="button" onClick={() => setRadial(true)} aria-label="Afficher la vue radiale du Jour J" className="mx-auto flex min-h-[44px] items-center gap-1.5 rounded-full px-4 text-[11px] font-semibold text-white/35 hover:bg-white/10 hover:text-white/65 focus-visible:ring-2 focus-visible:ring-[#BF5AF2]"><ChevronDown className="h-4 w-4" />Tirer vers le bas · Jour J</button>
    <div ref={liste} onTouchStart={commencer} onTouchMove={tirer} onTouchEnd={terminer} className="scrollbar-none h-[min(58vh,520px)] snap-y snap-mandatory overflow-y-auto overscroll-contain" aria-label="Cadran causal puis cadrans des moments" style={{ transform: traction ? `translateY(${traction * 0.35}px)` : undefined }}>
      <section className="flex min-h-full snap-start flex-col items-center justify-center px-1 py-5" aria-label="Cadran causal principal"><p className="mb-2 text-[10px] font-bold uppercase tracking-[0.2em] text-white/35">Cadran causal</p><CadranCausal moments={moments} date={evenement.date} impacts={impacts} actions={actions} onChoisirAction={onChoisirAction} onOuvrirImpact={(id) => onImpact(impacts.find((item) => item.id === id))} onOuvrirDocuments={onOuvrirDocuments} /><TrajectoireCausale evenement={evenement} impacts={impacts} /><p className="mt-4 text-[10px] font-semibold text-white/30">Faites défiler pour voir les cadrans-moments</p></section>
      {moments.length ? moments.map((moment, index) => <CadranProgressionMoment key={`${moment.titre}-${index}`} moment={moment} evenement={evenement} documents={documents} impacts={impacts} index={index} />) : <div className="flex h-full min-h-[360px] snap-start items-center justify-center px-6 text-center text-sm text-white/40">Ajoutez un premier moment pour créer son cadran de progression.</div>}
    </div>
  </div>;
}