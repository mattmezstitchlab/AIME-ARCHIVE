import React, { useEffect, useState } from "react";
import { CATEGORIES_ACTEURS } from "@/lib/acteursEvenement";
import { classeInputOs, classeBoutonOs } from "@/components/evenements/stylesOs";
import { Plus, X, Trash2, TreePine, LifeBuoy } from "lucide-react";

const TAGS = {
  sacre: { libelle: "sacré", classes: "bg-[#636366]/50 text-white" },
  immuable: { libelle: "immuable", classes: "bg-[#FF9F0A]/20 text-[#FFB340]" },
};

const MOMENT_VIDE = { titre: "", heureDebut: "", heureFin: "", categorie: "prestataire", tag: "", exposition: "interieur", cout: "", planB: "", responsable: "" };

export default function TimelineJourJ({ moments, acteurs = [], onChange, ouvrirFormulaire }) {
  const [nouveau, setNouveau] = useState(MOMENT_VIDE);
  const [formOuvert, setFormOuvert] = useState(false);

  useEffect(() => { if (ouvrirFormulaire) setFormOuvert(true); }, [ouvrirFormulaire]);

  const tries = [...moments].sort((a, b) => (a.heureDebut || "").localeCompare(b.heureDebut || ""));

  const ajouter = () => {
    if (!nouveau.titre.trim() || !nouveau.heureDebut) return;
    onChange([...moments, { ...nouveau, cle: globalThis.crypto?.randomUUID?.() || `moment-${Date.now()}`, cout: Number(nouveau.cout) || 0 }]);
    setNouveau(MOMENT_VIDE);
    setFormOuvert(false);
  };

  const supprimer = (moment) => onChange(moments.filter((m) => m !== moment));

  return (
    <div className="space-y-4">
      <h3 className="text-[10px] font-bold uppercase tracking-[0.3em] text-white/40">Déroulé du Jour J</h3>

      {tries.length === 0 ? (
        <p className="text-sm text-white/50">Aucun moment pour l'instant. Ajoutez les temps forts de la journée ci-dessous.</p>
      ) : (
        <ul className="space-y-1.5">
          {tries.map((m, i) => (
            <li key={i} className="flex flex-wrap items-center gap-2.5 rounded-xl bg-white/[0.08] px-3 py-1.5">
              <span className="h-2.5 w-2.5 rounded-full shrink-0" style={{ backgroundColor: CATEGORIES_ACTEURS[m.categorie]?.couleur || "#8E8E93" }} />
              <span className="text-xs text-white/50 tabular-nums whitespace-nowrap">
                {m.heureDebut}{m.heureFin ? `–${m.heureFin}` : ""}
              </span>
              <span className="flex-1 min-w-[120px] text-[13px] font-medium text-white">
                {m.planBActif && m.planB ? m.planB : m.titre}
                {m.responsable && <span className="text-white/40"> · {m.responsable}</span>}
              </span>
              {m.planBActif && (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium bg-[#0A84FF]/20 text-[#6CB4FF]">
                  <LifeBuoy className="h-3 w-3" /> plan B actif
                </span>
              )}
              {m.exposition === "exterieur" && !m.planBActif && (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium bg-[#30D158]/20 text-[#30D158]">
                  <TreePine className="h-3 w-3" /> extérieur
                </span>
              )}
              {Number(m.cout) > 0 && (
                <span className="text-[11px] text-white/45 whitespace-nowrap tabular-nums">{Number(m.cout).toLocaleString("fr-FR")} €</span>
              )}
              {m.tag && TAGS[m.tag] && (
                <span className={`px-2 py-0.5 rounded-full text-[11px] font-medium ${TAGS[m.tag].classes}`}>{TAGS[m.tag].libelle}</span>
              )}
              <button onClick={() => supprimer(m)} aria-label={`Supprimer ${m.titre}`} className="text-white/30 hover:text-[#FF453A] transition-colors">
                <Trash2 className="h-4 w-4" />
              </button>
            </li>
          ))}
        </ul>
      )}

      {!formOuvert ? (
        <button
          onClick={() => setFormOuvert(true)}
          aria-label="Ajouter un moment"
          title="Ajouter un moment"
          className="h-11 w-11 inline-flex items-center justify-center rounded-full bg-white/15 text-white hover:bg-white/25 transition-colors"
        >
          <Plus className="h-4 w-4" />
        </button>
      ) : (
      <div className="space-y-2">
        <div className="flex justify-end">
          <button
            onClick={() => { setFormOuvert(false); setNouveau(MOMENT_VIDE); }}
            aria-label="Fermer le formulaire"
            className="h-11 w-11 inline-flex items-center justify-center rounded-full bg-white/10 text-white/60 hover:text-white transition-colors"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 md:grid-cols-[1fr_110px_110px_1fr_130px]">
          <input className={classeInputOs} placeholder="Moment (Cérémonie…)" value={nouveau.titre} onChange={(e) => setNouveau({ ...nouveau, titre: e.target.value })} />
          <input type="time" className={classeInputOs} value={nouveau.heureDebut} onChange={(e) => setNouveau({ ...nouveau, heureDebut: e.target.value })} aria-label="Heure de début" />
          <input type="time" className={classeInputOs} value={nouveau.heureFin} onChange={(e) => setNouveau({ ...nouveau, heureFin: e.target.value })} aria-label="Heure de fin" />
          <select className={classeInputOs} value={nouveau.categorie} onChange={(e) => setNouveau({ ...nouveau, categorie: e.target.value })} aria-label="Acteur concerné">
            {Object.entries(CATEGORIES_ACTEURS).map(([cle, cat]) => <option key={cle} value={cle}>{cat.libelle}</option>)}
          </select>
          <select className={classeInputOs} value={nouveau.tag} onChange={(e) => setNouveau({ ...nouveau, tag: e.target.value })} aria-label="Contrainte">
            <option value="">Flexible</option>
            <option value="sacre">Sacré</option>
            <option value="immuable">Immuable</option>
          </select>
        </div>
        <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 md:grid-cols-[130px_1fr_110px_1fr_auto]">
          <select className={classeInputOs} value={nouveau.exposition} onChange={(e) => setNouveau({ ...nouveau, exposition: e.target.value })} aria-label="Exposition">
            <option value="interieur">Intérieur</option>
            <option value="exterieur">Extérieur</option>
          </select>
          <select className={classeInputOs} value={nouveau.responsable} onChange={(e) => setNouveau({ ...nouveau, responsable: e.target.value })} aria-label="Responsable du moment">
            <option value="">Responsable (optionnel)</option>
            {acteurs.map((a, i) => <option key={i} value={a.nom}>{a.nom}</option>)}
          </select>
          <input type="number" className={classeInputOs} placeholder="Coût €" value={nouveau.cout} onChange={(e) => setNouveau({ ...nouveau, cout: e.target.value })} aria-label="Coût estimé" />
          <input className={classeInputOs} placeholder="Plan B (ex. repli en salle…)" value={nouveau.planB} onChange={(e) => setNouveau({ ...nouveau, planB: e.target.value })} aria-label="Plan B" />
          <button onClick={ajouter} className={classeBoutonOs}>
            <Plus className="h-4 w-4" /> Ajouter
          </button>
        </div>
        <p className="text-[11px] text-white/40">
          « Sacré » : moment intouchable. « Immuable » : contrainte fixe. Exposition, coût, responsable et plan B alimentent le moteur causal et le budget vivant.
        </p>
      </div>
      )}
    </div>
  );
}