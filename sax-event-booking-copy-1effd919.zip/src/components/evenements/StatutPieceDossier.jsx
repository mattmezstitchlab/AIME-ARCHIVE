import React from "react";

const OPTIONS = [
  ["a_faire", "À faire"],
  ["a_confirmer", "À confirmer"],
  ["pret", "Prêt"],
];

export default function StatutPieceDossier({ piece, modifiable, onChange }) {
  return (
    <select
      value={piece.statut}
      onChange={(e) => onChange(piece, e.target.value)}
      disabled={!modifiable}
      aria-label={`État de ${piece.titre}`}
      className="min-h-[36px] shrink-0 rounded-full border border-white/10 bg-white/[0.07] px-3 text-xs font-semibold text-white disabled:cursor-default disabled:opacity-60 [color-scheme:dark]"
    >
      {OPTIONS.map(([valeur, libelle]) => <option key={valeur} value={valeur} className="bg-[#141416] text-white">{libelle}</option>)}
    </select>
  );
}