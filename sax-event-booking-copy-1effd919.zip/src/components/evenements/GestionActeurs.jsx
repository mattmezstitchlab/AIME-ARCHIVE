import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { CATEGORIES_ACTEURS } from "@/lib/acteursEvenement";
import { classeInputOs, classeBoutonOs } from "@/components/evenements/stylesOs";
import { Plus, X, Trash2, BadgeCheck, Mail } from "lucide-react";

const ACTEUR_VIDE = { nom: "", categorie: "prestataire", role: "", email: "", slugProfil: "" };

export default function GestionActeurs({ acteurs, onChange, ouvrirFormulaire }) {
  const [nouveau, setNouveau] = useState(ACTEUR_VIDE);
  const [formOuvert, setFormOuvert] = useState(false);
  const [registre, setRegistre] = useState([]);

  useEffect(() => {
    base44.functions.invoke("registreProfils", {}).then((res) => setRegistre(res.data.profils || [])).catch(() => {});
  }, []);

  useEffect(() => { if (ouvrirFormulaire) setFormOuvert(true); }, [ouvrirFormulaire]);

  const choisirDuRegistre = (slug) => {
    const p = registre.find((r) => r.slug === slug);
    if (!p) return setNouveau({ ...nouveau, slugProfil: "" });
    setNouveau({ ...nouveau, nom: p.nomAffiche || "", role: p.sousTitre || "", categorie: "prestataire", slugProfil: p.slug });
  };

  const ajouter = () => {
    if (!nouveau.nom.trim()) return;
    onChange([...acteurs, nouveau], nouveau);
    setNouveau(ACTEUR_VIDE);
    setFormOuvert(false);
  };

  const supprimer = (index) => onChange(acteurs.filter((_, i) => i !== index));

  return (
    <div className="space-y-4">
      <h3 className="text-[10px] font-bold uppercase tracking-[0.3em] text-white/40">Acteurs de l'événement</h3>

      {acteurs.length > 0 && (
        <ul className="space-y-1.5">
          {acteurs.map((a, i) => (
            <li key={i} className="flex min-w-0 flex-wrap items-center gap-2.5 rounded-xl bg-white/[0.08] px-3 py-1.5">
              <span className="h-2.5 w-2.5 rounded-full shrink-0" style={{ backgroundColor: CATEGORIES_ACTEURS[a.categorie]?.couleur || "#8E8E93" }} />
              <span className="min-w-0 flex-1 overflow-wrap-anywhere text-[13px] font-medium text-white">
                {a.nom}
                {a.role && <span className="ml-2 font-normal text-white/45">— {a.role}</span>}
              </span>
              {a.slugProfil && (
                <span className="inline-flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-[#64D2FF]" title="Profil du registre Aime Event">
                  <BadgeCheck className="h-3.5 w-3.5" /> Registre
                </span>
              )}
              {a.email && (
                <span className="inline-flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-[#30D158]" title={`Invité : ${a.email}`}>
                  <Mail className="h-3.5 w-3.5" /> Invité
                </span>
              )}
              <button onClick={() => supprimer(i)} aria-label={`Retirer ${a.nom}`} className="text-white/30 hover:text-[#FF453A] transition-colors">
                <Trash2 className="h-4 w-4" />
              </button>
            </li>
          ))}
        </ul>
      )}

      {!formOuvert ? (
        <button
          onClick={() => setFormOuvert(true)}
          aria-label="Ajouter un acteur"
          title="Ajouter un acteur"
          className="h-11 w-11 inline-flex items-center justify-center rounded-full bg-white/15 text-white hover:bg-white/25 transition-colors"
        >
          <Plus className="h-4 w-4" />
        </button>
      ) : (
      <div className="space-y-2">
        <div className="flex justify-end">
          <button
            onClick={() => { setFormOuvert(false); setNouveau(ACTEUR_VIDE); }}
            aria-label="Fermer le formulaire"
            className="h-11 w-11 inline-flex items-center justify-center rounded-full bg-white/10 text-white/60 hover:text-white transition-colors"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
        {registre.length > 0 && (
          <select
            className={classeInputOs}
            value={nouveau.slugProfil}
            onChange={(e) => choisirDuRegistre(e.target.value)}
            aria-label="Choisir un prestataire du registre"
          >
            <option value="">Choisir dans le registre Aime Event…</option>
            {registre.map((p) => (
              <option key={p.slug} value={p.slug}>
                {p.nomAffiche}{p.sousTitre ? ` — ${p.sousTitre}` : ""}
              </option>
            ))}
          </select>
        )}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
          <input aria-label="Nom de l’acteur" className={classeInputOs} placeholder="Nom" value={nouveau.nom} onChange={(e) => setNouveau({ ...nouveau, nom: e.target.value })} />
          <select aria-label="Catégorie de l’acteur" className={classeInputOs} value={nouveau.categorie} onChange={(e) => setNouveau({ ...nouveau, categorie: e.target.value })}>
            {Object.entries(CATEGORIES_ACTEURS).map(([cle, cat]) => <option key={cle} value={cle}>{cat.libelle}</option>)}
          </select>
          <input aria-label="Rôle de l’acteur" className={classeInputOs} placeholder="Rôle (saxophoniste…)" value={nouveau.role} onChange={(e) => setNouveau({ ...nouveau, role: e.target.value })} />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-[1fr_auto] gap-2">
          <input
            aria-label="Adresse e-mail de l’acteur"
            className={classeInputOs}
            type="email"
            placeholder="E-mail (optionnel — invite au Studio de l'événement)"
            value={nouveau.email}
            onChange={(e) => setNouveau({ ...nouveau, email: e.target.value })}
          />
          <button onClick={ajouter} className={classeBoutonOs}>
            <Plus className="h-4 w-4" /> Ajouter
          </button>
        </div>
        <p className="text-xs text-white/40">
          Avec un e-mail, l'acteur reçoit une invitation et accède au Studio : déroulé, effets causals et Jour J en direct.
        </p>
      </div>
      )}
    </div>
  );
}