import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import SimulateurRetard from "@/components/evenements/SimulateurRetard";
import SimulateurAbsence from "@/components/evenements/SimulateurAbsence";
import { Clock3, UserX } from "lucide-react";

const BLEU_VERT = "#0D9488";

const PICTOS = [
  ["retard", "Retard", Clock3],
  ["absence", "Absence / annulation", UserX],
];

export default function CentreImprevus({ evenement, onMajMoments, couleur = "#FF2D78" }) {
  const [declencheur, setDeclencheur] = useState(null);
  const moments = evenement.moments || [];

  const basculer = (cle) => setDeclencheur(declencheur === cle ? null : cle);

  const classePicto = (cle) =>
    `h-11 min-w-[44px] px-2.5 inline-flex items-center justify-center rounded-full transition-all duration-300 ${
      declencheur === cle ? "" : "bg-white/10 hover:bg-white/20"
    }`;
  const stylePicto = (cle) => (declencheur === cle ? { backgroundColor: BLEU_VERT } : undefined);

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-2">
        {PICTOS.map(([cle, libelle, Icone]) => (
          <button
            key={cle}
            onClick={() => basculer(cle)}
            aria-pressed={declencheur === cle}
            aria-label={libelle}
            title={libelle}
            className={classePicto(cle)}
            style={stylePicto(cle)}
          >
            <Icone className="h-5 w-5 text-white/90" strokeWidth={2} />
          </button>
        ))}
      </div>

      <AnimatePresence initial={false}>
        {declencheur && (
          <motion.div
            key={declencheur}
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.22, ease: "easeOut" }}
            className="rounded-2xl bg-white/[0.06] p-4"
          >
            {declencheur === "retard" && <SimulateurRetard moments={moments} onAppliquer={onMajMoments} couleur={couleur} />}
            {declencheur === "absence" && <SimulateurAbsence acteurs={evenement.acteurs || []} moments={moments} onAppliquer={onMajMoments} couleur={couleur} />}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}