import React, { useEffect, useState } from "react";
import { Sun, Cloud, CloudRain, CloudSnow, CloudLightning, CloudFog } from "lucide-react";

const iconePourCode = (code) => {
  if (code <= 1) return [Sun, "Ensoleillé"];
  if (code <= 3) return [Cloud, "Nuageux"];
  if (code <= 48) return [CloudFog, "Brouillard"];
  if (code <= 67) return [CloudRain, "Pluie"];
  if (code <= 77) return [CloudSnow, "Neige"];
  if (code <= 82) return [CloudRain, "Averses"];
  if (code >= 95) return [CloudLightning, "Orage"];
  return [Cloud, "Variable"];
};

export default function MeteoEvenement({ lieu, date, grand = false }) {
  const [meteo, setMeteo] = useState(null);

  useEffect(() => {
    if (!lieu || !date) return;
    const jours = Math.ceil((new Date(date) - new Date()) / 86400000);
    if (jours < 0 || jours > 15) return; // hors fenêtre de prévision fiable
    let actif = true;
    (async () => {
      try {
        const geo = await fetch(
          `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(lieu)}&count=1&language=fr`
        ).then((r) => r.json());
        const p = geo?.results?.[0];
        if (!p) return;
        const prev = await fetch(
          `https://api.open-meteo.com/v1/forecast?latitude=${p.latitude}&longitude=${p.longitude}&daily=weather_code,temperature_2m_max&timezone=auto&start_date=${date}&end_date=${date}`
        ).then((r) => r.json());
        const code = prev?.daily?.weather_code?.[0];
        const temp = prev?.daily?.temperature_2m_max?.[0];
        if (actif && code !== undefined && temp != null) setMeteo({ code, temp });
      } catch {
        // Météo indisponible : on n'affiche simplement rien.
      }
    })();
    return () => { actif = false; };
  }, [lieu, date]);

  if (!meteo) {
    return grand ? <CloudRain className="h-5 w-5 text-white/90" strokeWidth={2} aria-hidden="true" /> : null;
  }
  const [Icone, libelle] = iconePourCode(meteo.code);
  if (grand) {
    return (
      <span className="inline-flex items-center gap-1.5" title={`${libelle} prévu à ${lieu}`}>
        <Icone className="h-5 w-5 text-white/90" strokeWidth={2} />
        <span className="text-base font-semibold tracking-tight tabular-nums text-white/95">{Math.round(meteo.temp)}°</span>
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1.5" title={`Météo prévue à ${lieu}`}>
      <Icone className="h-4 w-4 text-white/70" />
      {libelle} · {Math.round(meteo.temp)}°
    </span>
  );
}