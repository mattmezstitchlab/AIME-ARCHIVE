import React, { useEffect, useRef, useState } from "react";
import { base44 } from "@/api/base44Client";
import { STATUTS_EVENEMENT, CATEGORIES_ACTEURS } from "@/lib/acteursEvenement";
import { FOND_POINTILLE, BADGES_STATUT_OS } from "@/components/evenements/stylesOs";
import FormulaireEvenement from "@/components/evenements/FormulaireEvenement";
import FicheEvenement from "@/components/evenements/FicheEvenement";
import { Link, useNavigate } from "react-router-dom";
import { Loader2, CalendarDays, MapPin, Trash2, Ban, Sparkles } from "lucide-react";

function formatDateFr(dateISO) {
  if (!dateISO) return "—";
  const [a, m, j] = String(dateISO).split("-");
  return `${j}/${m}/${a}`;
}

export default function ListeEvenements({ email, evenementInitialId, typeInitial }) {
  const navigate = useNavigate();
  const [evenements, setEvenements] = useState(null);
  const [creation, setCreation] = useState(false);
  const [selection, setSelection] = useState(null);
  const dejaOuvert = useRef(false);

  const charger = async () => {
    const [miens, partages] = await Promise.all([
      base44.entities.Evenement.filter({ proprietaire: email }, "-date", 200),
      base44.entities.Evenement.filter({ participants: email }, "-date", 200).catch(() => []),
    ]);
    const ids = new Set(miens.map((ev) => ev.id));
    const liste = [...miens, ...partages.filter((ev) => !ids.has(ev.id))];
    setEvenements(liste);
    // Parcours invité : ouvre directement l'événement du lien d'invitation.
    if (evenementInitialId && !dejaOuvert.current) {
      const cible = liste.find((ev) => ev.id === evenementInitialId);
      if (cible) {
        dejaOuvert.current = true;
        setSelection(cible);
      }
    }
  };

  useEffect(() => { charger(); }, [email]);

  const nouveauTraite = useRef("");

  // Ouvrir automatiquement le formulaire de création quand un type arrive depuis la capsule
  useEffect(() => {
    if (typeInitial && typeInitial !== nouveauTraite.current) {
      nouveauTraite.current = typeInitial;
      setCreation(true);
    }
  }, [typeInitial]);

  const supprimer = async (e) => {
    if (!window.confirm(`Supprimer définitivement « ${e.titre} » ?`)) return;
    await base44.entities.Evenement.delete(e.id);
    charger();
  };

  const annuler = async (e) => {
    await base44.entities.Evenement.update(e.id, { statut: "annule" });
    charger();
  };

  const changerStatut = async (e, statut) => {
    await base44.entities.Evenement.update(e.id, { statut });
    // Synchronisation : annuler l'événement archive la demande liée (le calendrier public recalcule les disponibilités).
    if (statut === "annule" && e.demandeId) {
      await base44.entities.DemandesDisponibilite.update(e.demandeId, { statut: "Archivée" }).catch(() => {});
    }
    charger();
  };

  const ouvrirEvenement = (e) => {
    setSelection(e);
    navigate(`/compte?evenement=${encodeURIComponent(e.id)}&studio=cadran&panneau=apercu`);
  };

  const creer = async (v) => {
    const cree = await base44.entities.Evenement.create({ proprietaire: email, statut: "brouillon", acteurs: [], moments: [], ...v });
    setCreation(false);
    charger();
    ouvrirEvenement(cree);
  };

  if (selection) {
    return (
      <FicheEvenement
        evenement={selection}
        email={email}
        onRetour={() => { setSelection(null); charger(); }}
        onMaj={(maj) => setSelection(maj)}
      />
    );
  }

  return (
    <div className="space-y-6">
      {creation && (
        <div className="rounded-3xl p-4 md:p-6" style={FOND_POINTILLE}>
          <FormulaireEvenement key={typeInitial || 'nouveau'} onCreer={creer} onAnnuler={() => setCreation(false)} typeInitial={typeInitial} />
        </div>
      )}

      {!evenements ? (
        <div className="flex justify-center py-16">
          <Loader2 className="h-6 w-6 animate-spin text-[var(--p-accent)]" />
        </div>
      ) : evenements.length === 0 ? (
        !creation && (
          <div className="rounded-2xl border border-black/10 bg-white p-10 text-center space-y-4">
            <CalendarDays className="h-8 w-8 mx-auto text-black/25" />
            <p className="text-sm text-[var(--p-muted)]">
              Aucun événement pour l'instant. Décrivez le vôtre à l'assistant, il compose le dossier complet.
            </p>
            <Link
              to="/creer"
              className="inline-flex items-center gap-2 min-h-[44px] px-6 rounded-full bg-[#141416] text-sm font-semibold text-white hover:bg-black transition-colors"
            >
              <Sparkles className="h-4 w-4" /> Créer mon événement
            </Link>
          </div>
        )
      ) : (
        <ul className="space-y-3 rounded-3xl p-4 md:p-6" style={FOND_POINTILLE}>
          {evenements.map((e) => (
            <li key={e.id} className="flex min-w-0 flex-col gap-2 sm:flex-row sm:items-stretch">
              <div
                role="button"
                tabIndex={0}
                onClick={() => ouvrirEvenement(e)}
                onKeyDown={(ev) => { if (ev.key === "Enter" || ev.key === " ") ouvrirEvenement(e); }}
                aria-label={`Ouvrir le Studio de ${e.titre}`}
                className="flex-1 min-w-0 text-left rounded-2xl bg-[#141416] p-5 hover:bg-[#1C1C1F] transition-colors cursor-pointer"
              >
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <p className="font-heading text-lg text-white">{e.titre}</p>
                    <div className="mt-1.5 flex flex-wrap gap-4 text-sm text-white/50">
                      <span className="inline-flex items-center gap-1.5"><CalendarDays className="h-4 w-4" /> {formatDateFr(e.date)}</span>
                      {e.lieu && <span className="inline-flex items-center gap-1.5"><MapPin className="h-4 w-4" /> {e.lieu}</span>}
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="flex -space-x-1">
                      {(e.acteurs || []).slice(0, 6).map((a, i) => (
                        <span
                          key={i}
                          title={a.nom}
                          className="h-3.5 w-3.5 rounded-full ring-2 ring-[#141416]"
                          style={{ backgroundColor: CATEGORIES_ACTEURS[a.categorie]?.couleur || "#999" }}
                        />
                      ))}
                    </span>
                    {e.proprietaire !== email && (
                      <span className="px-2.5 py-1 rounded-full text-[11px] font-medium bg-[#6CB4FF]/15 text-[#6CB4FF]">
                        Partagé avec vous
                      </span>
                    )}
                    {e.proprietaire === email ? (
                      <select
                        value={e.statut || "brouillon"}
                        onClick={(ev) => ev.stopPropagation()}
                        onKeyDown={(ev) => ev.stopPropagation()}
                        onChange={(ev) => changerStatut(e, ev.target.value)}
                        aria-label={`Statut de ${e.titre}`}
                        className="min-h-[28px] px-2.5 rounded-full text-[11px] font-medium cursor-pointer border-0 focus:outline-none focus:ring-1 focus:ring-white/30 [color-scheme:dark] bg-white/10 text-white/70 hover:bg-white/15"
                      >
                        {Object.entries(STATUTS_EVENEMENT).map(([cle, libelle]) => (
                          <option key={cle} value={cle} className="text-black bg-white">{libelle}</option>
                        ))}
                      </select>
                    ) : (
                      <span className={`px-2.5 py-1 rounded-full text-[11px] font-medium ${BADGES_STATUT_OS[e.statut] || BADGES_STATUT_OS.brouillon}`}>
                        {STATUTS_EVENEMENT[e.statut] || "Brouillon"}
                      </span>
                    )}
                  </div>
                </div>
              </div>
              <div className="flex flex-row justify-end gap-2 sm:flex-col sm:justify-center">
                {e.proprietaire === email && e.statut !== "annule" && e.statut !== "realise" && (
                  <button
                    onClick={() => annuler(e)}
                    title="Annuler l'événement"
                    aria-label={`Annuler ${e.titre}`}
                    className="h-11 w-11 rounded-xl bg-[#141416] flex items-center justify-center text-white/40 hover:text-[#FF453A] transition-colors"
                  >
                    <Ban className="h-4 w-4" />
                  </button>
                )}
                {e.proprietaire === email && (
                <button
                  onClick={() => supprimer(e)}
                  title="Supprimer l'événement"
                  aria-label={`Supprimer ${e.titre}`}
                  className="h-11 w-11 rounded-xl bg-[#141416] flex items-center justify-center text-white/40 hover:text-[#FF453A] transition-colors"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
                )}
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}