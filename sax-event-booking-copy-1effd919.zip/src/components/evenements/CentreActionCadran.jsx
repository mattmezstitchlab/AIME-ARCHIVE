import React, { useState } from "react";
import { AlertTriangle, FileText, Plus } from "lucide-react";
import MenuAjoutEvenement from "@/components/plateforme/MenuAjoutEvenement";

export default function CentreActionCadran({ priorite, actions = [], onPriorite, onChoisirAction }) {
  const [menuOuvert, setMenuOuvert] = useState(false);
  const estDocument = priorite?.id === "documents", Icone = estDocument ? FileText : priorite ? AlertTriangle : Plus;
  const peutAgir = !!priorite || actions.length > 0;
  const activer = () => { if (priorite) onPriorite?.(priorite); else if (actions.length) setMenuOuvert((ouvert) => !ouvert); };
  const libelle = priorite ? priorite.label : actions.length ? "Agir sur cet événement" : "Lecture seule";
  return <div className="pointer-events-none absolute inset-0 z-10 flex items-center justify-center">
    <div className="pointer-events-auto relative">
      {menuOuvert && <MenuAjoutEvenement actions={actions} onChoisir={(action) => { setMenuOuvert(false); onChoisirAction?.(action); }} placement="cadran" />}
      <button type="button" onClick={activer} disabled={!peutAgir} aria-label={libelle} title={libelle} aria-haspopup={!priorite && actions.length ? "menu" : undefined} aria-expanded={!priorite && actions.length ? menuOuvert : undefined} className={`flex h-12 w-12 items-center justify-center rounded-full bg-white text-black shadow-[0_4px_24px_rgba(255,255,255,0.22)] transition-transform hover:scale-105 focus-visible:ring-2 focus-visible:ring-[#BF5AF2] disabled:cursor-not-allowed disabled:opacity-45 ${priorite?.niveau === "rouge" ? "ring-4 ring-[#FF453A]/30" : ""}`}><Icone className="h-5 w-5" strokeWidth={2.5} /></button>
    </div>
  </div>;
}