import React, { useEffect, useState } from "react";
import { CATEGORIES_ACTEURS } from "@/lib/acteursEvenement";
import CentreActionCadran from "@/components/evenements/CentreActionCadran";
import CommandesNavigationCadran from "@/components/evenements/CommandesNavigationCadran";

const CENTRE = 160, RAYON = 118;
const FONTE_SF = "-apple-system, BlinkMacSystemFont, 'SF Pro Display', 'Helvetica Neue', Inter, sans-serif";
const versMinutes = (h) => { if (!h) return null; const [hh, mm] = String(h).split(":").map(Number); return hh * 60 + (mm || 0); };
const versAngle = (minutes) => (minutes / 1440) * 2 * Math.PI - Math.PI / 2;
const point = (angle, r = RAYON) => [CENTRE + r * Math.cos(angle), CENTRE + r * Math.sin(angle)];
const arcMoment = (moment, i) => {
  const debut = versMinutes(moment.heureDebut); if (debut === null) return null;
  let fin = versMinutes(moment.heureFin); if (fin === null) fin = debut + 30; if (fin <= debut) fin += 1440;
  const a1 = versAngle(debut), a2 = versAngle(Math.min(fin, debut + 1439)), [x1, y1] = point(a1), [x2, y2] = point(a2);
  return { i, a1, d: `M ${x1} ${y1} A ${RAYON} ${RAYON} 0 ${fin - debut > 720 ? 1 : 0} 1 ${x2} ${y2}`, couleur: CATEGORIES_ACTEURS[moment.categorie]?.couleur || "#8E8E93", moment };
};

export default function CadranCausal({ moments, date, impacts = [], actions = [], onChoisirAction, onOuvrirImpact, onOuvrirDocuments }) {
  const [actif, setActif] = useState(null), [maintenant, setMaintenant] = useState(new Date()), [sim, setSim] = useState(null), [lecture, setLecture] = useState(false), [rapide, setRapide] = useState(false);
  const estAujourdhui = date === `${maintenant.getFullYear()}-${String(maintenant.getMonth() + 1).padStart(2, "0")}-${String(maintenant.getDate()).padStart(2, "0")}`;
  useEffect(() => { if (!estAujourdhui) return; const timer = setInterval(() => setMaintenant(new Date()), 30000); return () => clearInterval(timer); }, [estAujourdhui]);
  const arcs = (moments || []).map(arcMoment).filter(Boolean), selection = actif !== null ? arcs.find((arc) => arc.i === actif) : null;
  const debuts = arcs.map((arc) => versMinutes(arc.moment.heureDebut)).filter((n) => n !== null).sort((a, b) => a - b);
  const fins = arcs.map((arc) => versMinutes(arc.moment.heureFin) ?? versMinutes(arc.moment.heureDebut) + 30);
  const bornes = debuts.length ? { debut: Math.max(0, Math.min(...debuts) - 45), fin: Math.min(1439, Math.max(...fins) + 45) } : null;
  useEffect(() => { if (!lecture || !bornes) return; const timer = setInterval(() => setSim((valeur) => { const suivant = (valeur ?? bornes.debut) + (rapide ? 8 : 3); if (suivant >= bornes.fin) { setLecture(false); return bornes.fin; } return suivant; }), 50); return () => clearInterval(timer); }, [lecture, rapide, bornes?.debut, bornes?.fin]);
  const momentSim = sim === null ? null : arcs.find((arc) => { const debut = versMinutes(arc.moment.heureDebut); let fin = versMinutes(arc.moment.heureFin); if (fin === null) fin = debut + 30; if (fin <= debut) fin += 1440; return sim >= debut && sim < fin; });
  const deplacer = (delta) => { if (!bornes) return; setLecture(false); setSim((valeur) => Math.max(bornes.debut, Math.min(bornes.fin, (valeur ?? bornes.debut) + delta))); };
  const allerMomentPrecedent = () => { if (!bornes) return; const position = sim ?? bornes.fin + 1; setLecture(false); setSim([...debuts].reverse().find((debut) => debut < position) ?? debuts[debuts.length - 1]); };
  const allerMomentSuivant = () => { if (!bornes) return; const position = sim ?? bornes.debut - 1; setLecture(false); setSim(debuts.find((debut) => debut > position) ?? debuts[0]); };
  const priorite = impacts.find((impact) => ["rouge", "orange"].includes(impact.niveau));
  const ouvrirPriorite = (impact) => impact.id === "documents" ? onOuvrirDocuments?.() : onOuvrirImpact?.(impact.id);
  const angleNow = versAngle(sim !== null ? sim : maintenant.getHours() * 60 + maintenant.getMinutes()), [nx1, ny1] = point(angleNow, RAYON - 16), [nx2, ny2] = point(angleNow, RAYON + 8);
  const heure = sim !== null ? `${String(Math.floor(sim / 60)).padStart(2, "0")}:${String(Math.floor(sim % 60)).padStart(2, "0")}` : selection?.moment.heureDebut || (estAujourdhui ? `${String(maintenant.getHours()).padStart(2, "0")}:${String(maintenant.getMinutes()).padStart(2, "0")}` : arcs[0]?.moment.heureDebut || "—");
  const momentAffiche = selection || momentSim, titreMoment = momentAffiche?.moment.titre || (sim !== null ? "SIMULATION" : estAujourdhui ? "EN DIRECT" : "PREMIER MOMENT");
  return <div className="flex flex-col items-center" style={{ fontFamily: FONTE_SF }}><div className="w-full max-w-[300px]"><div className="relative">
    <svg viewBox="0 0 320 320" className="w-full" role="img" aria-label="Cadran circulaire du déroulé de l’événement">
      <circle cx={CENTRE} cy={CENTRE} r={RAYON} fill="none" stroke="rgba(255,255,255,0.10)" strokeWidth="12" />
      {Array.from({ length: 24 }, (_, h) => { const [cx, cy] = point(versAngle(h * 60), RAYON + 20); return <circle key={h} cx={cx} cy={cy} r={h % 6 === 0 ? 2 : 1} fill={h % 6 === 0 ? "rgba(255,255,255,0.5)" : "rgba(255,255,255,0.18)"} />; })}
      {[[0, "00"], [360, "06"], [720, "12"], [1080, "18"]].map(([min, libelle]) => { const [tx, ty] = point(versAngle(min), RAYON + 33); return <text key={libelle} x={tx} y={ty + 3} textAnchor="middle" fill="rgba(255,255,255,0.45)" fontSize="10" fontWeight="600" style={{ fontFamily: FONTE_SF }}>{libelle}</text>; })}
      {arcs.map((arc) => <path key={arc.i} d={arc.d} fill="none" stroke={arc.couleur} strokeWidth={actif === arc.i ? 14 : 12} strokeLinecap="round" strokeDasharray={arc.moment.planBActif ? "1 16" : undefined} opacity={actif === null || actif === arc.i ? 1 : 0.28} className="cursor-pointer transition-all duration-300" onMouseEnter={() => setActif(arc.i)} onMouseLeave={() => setActif(null)} onClick={() => setActif(actif === arc.i ? null : arc.i)}><title>{`${arc.moment.heureDebut}${arc.moment.heureFin ? `–${arc.moment.heureFin}` : ""} ${arc.moment.titre}`}</title></path>)}
      {arcs.filter((arc) => ["sacre", "immuable"].includes(arc.moment.tag)).map((arc) => { const [mx, my] = point(arc.a1); return <circle key={`tag-${arc.i}`} cx={mx} cy={my} r="4" fill="#000" stroke={arc.couleur} strokeWidth="2.5" pointerEvents="none" />; })}
      {(estAujourdhui || sim !== null) && <g pointerEvents="none"><line x1={nx1} y1={ny1} x2={nx2} y2={ny2} stroke="#FF453A" strokeWidth="2.5" strokeLinecap="round" /><circle cx={nx2} cy={ny2} r="3.5" fill="#FF453A" /></g>}
      <text x={CENTRE} y={CENTRE - 45} textAnchor="middle" fill="#FFFFFF" fontSize={selection ? "27" : "31"} fontWeight="600" letterSpacing="-1" style={{ fontFamily: FONTE_SF, fontVariantNumeric: "tabular-nums" }}>{heure}</text>
      <text x={CENTRE} y={CENTRE + 47} textAnchor="middle" fill={momentAffiche?.couleur || "rgba(255,255,255,0.4)"} fontSize="10" fontWeight="600" letterSpacing="1.2" style={{ fontFamily: FONTE_SF }}>{String(titreMoment).slice(0, 27).toUpperCase()}</text>
      {selection && <text x={CENTRE} y={CENTRE + 64} textAnchor="middle" fill="rgba(255,255,255,0.4)" fontSize="9" style={{ fontFamily: FONTE_SF }}>{[selection.moment.heureFin ? `→ ${selection.moment.heureFin}` : null, selection.moment.responsable, selection.moment.planBActif ? "Plan B" : null].filter(Boolean).slice(0, 2).join(" · ")}</text>}
    </svg>
    <CentreActionCadran priorite={priorite} actions={actions} onPriorite={ouvrirPriorite} onChoisirAction={onChoisirAction} />
  </div>{bornes && <CommandesNavigationCadran lecture={lecture} rapide={rapide} onLecture={() => setLecture((valeur) => !valeur)} onRapide={() => setRapide((valeur) => !valeur)} onPrecedent={allerMomentPrecedent} onReculer={() => deplacer(-60)} onAvancer={() => deplacer(60)} onSuivant={allerMomentSuivant} />}</div></div>;
}