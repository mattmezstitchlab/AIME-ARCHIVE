import React from "react";
import { MOMENTS_MARIAGE, ACTEURS_MARIAGE } from "@/lib/modeleMariage";
import { classeBoutonOs } from "@/components/evenements/stylesOs";
import { Sparkles } from "lucide-react";

export default function ModeleMariage({ onAppliquer }) {
  return (
    <div className="border-t border-white/10 pt-5 flex flex-wrap items-center justify-between gap-4 text-white">
      <div className="flex items-start gap-3">
        <Sparkles className="h-5 w-5 text-[#0A84FF] mt-0.5 shrink-0" />
        <div>
          <p className="text-sm font-semibold">Démarrer avec le modèle mariage</p>
          <p className="mt-0.5 text-[12px] leading-relaxed text-white/50">
            Pré-remplit le déroulé universel ({MOMENTS_MARIAGE.length} moments avec horaires : préparatifs, cérémonie,
            cocktail, photos, dîner, bal…) et les acteurs habituels ({ACTEURS_MARIAGE.length} : mariés, témoins,
            photographe, DJ, traiteur…). Vous pourrez tout ajuster ensuite.
          </p>
        </div>
      </div>
      <button onClick={() => onAppliquer(MOMENTS_MARIAGE, ACTEURS_MARIAGE)} className={classeBoutonOs}>
        Appliquer le modèle
      </button>
    </div>
  );
}