import React, { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { ArrowLeft, X } from "lucide-react";
import { useEventContext } from "@/contexts/EventContext";
import { DESTINATIONS_ACTIONS, MODULES_EVENEMENT } from "@/lib/eventModeConfig";
import BandeauCausal from "@/components/evenements/BandeauCausal";
import PanneauImpactCausal from "@/components/evenements/PanneauImpactCausal";
import VueEnsembleEvenement from "@/components/evenements/VueEnsembleEvenement";
import SaisieDecisionEvenement from "@/components/evenements/SaisieDecisionEvenement";
import GestionActeurs from "@/components/evenements/GestionActeurs";
import TimelineJourJ from "@/components/evenements/TimelineJourJ";
import ModeleDemarrage from "@/components/evenements/ModeleDemarrage";
import CadranCausal from "@/components/evenements/CadranCausal";
import SimulateurRetard from "@/components/evenements/SimulateurRetard";
import SimulateurAbsence from "@/components/evenements/SimulateurAbsence";
import SimulateurMeteo from "@/components/evenements/SimulateurMeteo";
import DocumentsEvenement from "@/components/evenements/DocumentsEvenement";
import ReglagesEvenement from "@/components/evenements/ReglagesEvenement";
import JourJLive from "@/components/evenements/JourJLive";
import NotifierActeurs from "@/components/evenements/NotifierActeurs";
import PlaylistEvenement from "@/components/playlist/PlaylistEvenement";
import AllergenesEvenement from "@/components/evenements/AllergenesEvenement";

export default function FicheEvenement({ evenement, onRetour, onMaj, email }) {
  const [params, setParams] = useSearchParams();
  const [demande, setDemande] = useState(null);
  const contexte = useEventContext();
  const e = contexte.evenement?.id === evenement.id ? contexte.evenement : evenement;
  const moduleActif = contexte.moduleActif;
  const panneau = contexte.panneauOuvert;
  const impactId = params.get("impact");
  const impact = contexte.impactsCausals.find((item) => item.id === impactId);

  useEffect(() => { contexte.setEvenement(evenement); }, [evenement.id]);
  const naviguer = (module, panneauSuivant, extras = {}) => {
    const suivants = new URLSearchParams(params);
    suivants.set("evenement", e.id); suivants.set("studio", module || moduleActif);
    panneauSuivant ? suivants.set("panneau", panneauSuivant) : suivants.delete("panneau");
    suivants.delete("impact"); suivants.delete("action"); Object.entries(extras).forEach(([cle, valeur]) => suivants.set(cle, valeur));
    setParams(suivants, { replace: true });
  };
  const fermerPanneau = () => naviguer(moduleActif, null);
  const retourListe = () => { const suivants = new URLSearchParams(); suivants.set("onglet", "evenements"); setParams(suivants, { replace: true }); onRetour(); };

  useEffect(() => {
    const gerer = ({ detail }) => {
      const destination = DESTINATIONS_ACTIONS[detail] || {};
      setDemande({ type: destination.demande || detail, documentType: destination.documentType, id: Date.now() });
      naviguer(destination.module || moduleActif, destination.panneau || null);
    };
    window.addEventListener("aime-event-ajout", gerer);
    const actionInitiale = params.get("action"); if (actionInitiale && contexte.actionsDisponibles.some(([cle]) => cle === actionInitiale)) gerer({ detail: actionInitiale });
    return () => window.removeEventListener("aime-event-ajout", gerer);
  }, [params, moduleActif, e.id]);

  const majChamp = async (champ, valeur) => {
    const suivant = { ...e, [champ]: valeur };
    contexte.setEvenement(suivant);
    await base44.entities.Evenement.update(e.id, { [champ]: valeur });
    if (champ === "statut" && valeur === "annule" && e.demandeId) await base44.entities.DemandesDisponibilite.update(e.demandeId, { statut: "Archivée" }).catch(() => {});
    onMaj?.(suivant);
  };
  const changerActeurs = async (acteurs, nouveau) => {
    const participant = (nouveau?.email || "").trim().toLowerCase();
    const patch = { acteurs, ...(participant && !(e.participants || []).includes(participant) ? { participants: [...(e.participants || []), participant] } : {}) };
    const suivant = { ...e, ...patch }; contexte.setEvenement(suivant);
    await base44.entities.Evenement.update(e.id, patch); onMaj?.(suivant);
    if (participant) await base44.integrations.Core.SendEmail({ to: participant, subject: `Invitation au Studio de « ${e.titre} »`, body: `Vous avez été invité à participer à l’événement « ${e.titre} ». Connectez-vous à Aime Event avec cette adresse pour accéder au Studio.` });
  };
  const enregistrerSimulation = (simulation) => contexte.setSimulation(simulation);
  const appliquerSimulation = async (type, moments) => {
    const resume = (liste) => liste.map(({ cle, titre, heureDebut, heureFin, responsable, planBActif }) => ({ cle, titre, heureDebut, heureFin, responsable, planBActif }));
    const historiqueCausal = [...(e.historiqueCausal || []).slice(-99), { date: new Date().toISOString(), type, avant: JSON.stringify(resume(e.moments || [])), apres: JSON.stringify(resume(moments)) }];
    const suivant = { ...e, moments, historiqueCausal }; contexte.setEvenement(suivant);
    await base44.entities.Evenement.update(e.id, { moments, historiqueCausal }); onMaj?.(suivant);
  };
  const ouvrirImpact = (id) => naviguer(moduleActif, "impact", { impact: id });
  const demanderDecision = () => { setDemande({ type: "decision", id: Date.now() }); naviguer(moduleActif, "saisie"); };
  const appliquerImpact = async () => {
    if (!impact?.appliquer || !window.confirm("Confirmer l’application de ces changements à l’événement ?")) return;
    await impact.appliquer(); contexte.setSimulation(null); fermerPanneau();
  };

  return <div className="space-y-5 pb-24"><div className="min-w-0 rounded-[1.75rem] bg-black p-4 text-white shadow-[0_24px_60px_-24px_rgba(0,0,0,0.45)] sm:rounded-[2.5rem] md:p-8">
    <div className="flex flex-col items-start gap-3 sm:flex-row sm:items-center"><button onClick={retourListe} aria-label="Retour à la liste des événements" title="Retour à la liste" className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-white/10 hover:bg-white/20"><ArrowLeft className="h-5 w-5" /></button><BandeauCausal impacts={contexte.impactsCausals} actif={impactId} onChoisir={ouvrirImpact} /></div>
    <div className="mt-6 border-t border-white/10 pt-5">
      {panneau && <div className="mb-4 flex justify-end"><button onClick={fermerPanneau} aria-label="Fermer le panneau et revenir au module" className="flex h-11 w-11 items-center justify-center rounded-full bg-white/10 text-white/60 hover:text-white"><X className="h-4 w-4" /></button></div>}
      {panneau === "apercu" && <VueEnsembleEvenement evenement={e} impacts={contexte.impactsCausals} />}
      {panneau === "impact" && <PanneauImpactCausal impact={impact} onAppliquer={appliquerImpact} onIgnorer={() => { if (impact?.id === contexte.simulation?.id) contexte.setSimulation(null); fermerPanneau(); }} onDecision={demanderDecision} />}
      {panneau === "documents" && <DocumentsEvenement evenement={e} actionInitiale={demande} lectureSeule={!contexte.autorisations.peutModifier} onFermer={fermerPanneau} />}
      {panneau === "reglages" && <ReglagesEvenement evenement={e} onMaj={majChamp} lectureSeule={!contexte.autorisations.peutModifier} />}
      {panneau === "acteurs" && <GestionActeurs acteurs={e.acteurs || []} onChange={changerActeurs} ouvrirFormulaire={demande?.id} />}
      {panneau === "retard" && <SimulateurRetard moments={e.moments || []} liensCausaux={e.liensCausaux || []} onAppliquer={(moments) => appliquerSimulation("retard", moments)} onSimulation={enregistrerSimulation} />}
      {panneau === "absence" && <SimulateurAbsence acteurs={e.acteurs || []} moments={e.moments || []} liensCausaux={e.liensCausaux || []} onAppliquer={(moments) => appliquerSimulation("absence", moments)} onSimulation={enregistrerSimulation} />}
      {panneau === "meteo" && <SimulateurMeteo evenement={e} onAppliquer={(moments) => appliquerSimulation("meteo", moments)} onSimulation={enregistrerSimulation} />}
      {panneau === "saisie" && <SaisieDecisionEvenement type={demande?.type} evenement={e} onMaj={majChamp} onFermer={fermerPanneau} />}
      {!panneau && moduleActif === "cadran" && <div className="space-y-5"><div className="grid items-start gap-8 lg:grid-cols-[1fr_auto_1.2fr]"><GestionActeurs acteurs={e.acteurs || []} onChange={changerActeurs} /><div className="justify-self-center"><CadranCausal moments={e.moments || []} date={e.date} impacts={contexte.impactsCausals} actions={contexte.actionsDisponibles} onChoisirAction={(action) => window.dispatchEvent(new CustomEvent("aime-event-ajout", { detail: action }))} onOuvrirImpact={ouvrirImpact} onOuvrirDocuments={() => naviguer(moduleActif, "documents")} /></div><div className="space-y-5"><TimelineJourJ moments={e.moments || []} acteurs={e.acteurs || []} onChange={(moments) => majChamp("moments", moments)} ouvrirFormulaire={demande?.type === "moment" ? demande.id : null} /><NotifierActeurs evenement={e} /></div></div>{!(e.moments || []).length && <ModeleDemarrage typeEvenement={e.typeEvenement} onAppliquer={async (moments, acteurs) => { const momentsComplets = moments.map((moment) => ({ ...moment, cle: globalThis.crypto?.randomUUID?.() || `moment-${Date.now()}-${moment.titre}`, cout: Number(moment.cout) || 0, planB: moment.planB || "", planBActif: false })); const noms = new Set((e.acteurs || []).map((acteur) => acteur.nom.trim().toLowerCase())); const acteursUniques = acteurs.filter((acteur) => !noms.has(acteur.nom.trim().toLowerCase())); const suivant = { ...e, moments: momentsComplets, acteurs: [...(e.acteurs || []), ...acteursUniques] }; contexte.setEvenement(suivant); await base44.entities.Evenement.update(e.id, { moments: suivant.moments, acteurs: suivant.acteurs }); onMaj?.(suivant); }} />}</div>}
      {!panneau && moduleActif === "jourj" && <JourJLive evenement={e} email={email} />}
      {!panneau && moduleActif === "playlist" && <PlaylistEvenement evenement={e} ouvrirFormulaire={demande?.type === "morceau" ? demande.id : null} />}
      {!panneau && moduleActif === "table" && <AllergenesEvenement evenement={e} ouvrirFormulaire={demande?.type === "invite" ? demande.id : null} />}
    </div>
  </div></div>;
}