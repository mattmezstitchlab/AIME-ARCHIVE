import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Folder, Users, Clock3, Briefcase, FileText, UserRound } from "lucide-react";

export default function DossierEvenement({ evenement, onOuvrir }) {
  const acteurs = evenement.acteurs || [];
  const moments = evenement.moments || [];
  const [nbDocuments, setNbDocuments] = useState(0);

  useEffect(() => {
    base44.entities.DocumentEmis.filter({ evenementId: evenement.id }, "-created_date", 100)
      .then((docs) => setNbDocuments(docs.length))
      .catch(() => {});
  }, [evenement.id]);

  const dossiers = [
    { cle: "acteurs", libelle: "Acteurs", icone: Users, compte: acteurs.length, onglet: "acteurs" },
    { cle: "moments", libelle: "Déroulé du Jour J", icone: Clock3, compte: moments.length, onglet: "deroule" },
    { cle: "prestataires", libelle: "Prestataires", icone: Briefcase, compte: acteurs.filter((a) => a.categorie === "prestataire").length, onglet: "acteurs" },
    { cle: "identite", libelle: "Identité & organisateur", icone: UserRound, compte: evenement.organisateurNom ? 1 : 0 },
    { cle: "documents", libelle: "Documents", icone: FileText, compte: nbDocuments, onglet: "documents" },
  ];

  return (
    <div className="rounded-2xl bg-[#141416] p-5">
      <p className="text-[10px] font-bold uppercase tracking-[0.3em] text-white/40 mb-4">Dossier de l'événement</p>
      <ul className="space-y-1">
        {dossiers.map((d) => (
          <li key={d.cle}>
            <button
              onClick={() => d.onglet && onOuvrir?.(d.onglet)}
              disabled={!d.onglet}
              className={`w-full flex items-center gap-3 min-h-[48px] px-3 rounded-xl text-sm transition-colors ${
                d.onglet ? "text-white/80 hover:bg-white/5 hover:text-white" : "text-white/45 cursor-default"
              }`}
            >
              {d.cle === "acteurs" ? <Folder className="h-4 w-4 shrink-0" /> : <d.icone className="h-4 w-4 shrink-0" />}
              <span className="flex-1 text-left">{d.libelle}</span>
              <span className={`font-mono text-sm ${d.compte === 0 ? "text-white/30" : "text-white/70"}`}>{d.compte}</span>
            </button>
          </li>
        ))}
      </ul>
      <p className="mt-4 text-[11px] text-white/35 leading-relaxed">
        Le compteur montre d'un coup d'œil ce qui est prêt — et ce qui manque encore.
      </p>
    </div>
  );
}