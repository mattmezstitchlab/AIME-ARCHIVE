import React, { useState } from "react";
import { appliquerRetard, trierMoments } from "@/lib/moteurCausal";
import { classeInputOs, classeBoutonBleuVert } from "@/components/evenements/stylesOs";
import ListeImpacts from "@/components/evenements/ListeImpacts";
import { Zap, Check, X } from "lucide-react";

export default function SimulateurRetard({ moments, liensCausaux = [], onAppliquer, onSimulation, couleur = "#FF2D78" }) {
  const [index, setIndex] = useState(0);
  const [retard, setRetard] = useState(15);
  const [proposition, setProposition] = useState(null);

  const tries = trierMoments(moments);

  const simuler = () => {
    const resultat = appliquerRetard(moments, index, retard, liensCausaux);
    setProposition(resultat);
    onSimulation?.({ id: "simulation-retard", niveau: "rouge", label: `Retard · ${retard} min · ${resultat.impacts.length} conséquences`, cause: `Retard de ${retard} minutes sur « ${tries[index]?.titre || "un moment"} ».`, elements: resultat.impacts, consequences: resultat.impacts, recommandation: "Prévisualiser le nouveau déroulé puis confirmer avant application.", avant: "Déroulé actuel conservé", apres: `${resultat.impacts.length} conséquence(s) calculée(s)`, appliquer: () => onAppliquer(resultat.moments) });
  };
  const reinitialiser = () => setProposition(null);

  return (
    <div className="space-y-4">
      <h3 className="text-[10px] font-bold uppercase tracking-[0.3em] inline-flex items-center gap-2 text-white/70">
        <Zap className="h-3.5 w-3.5 text-white" /> Moteur causal — simuler un retard
      </h3>

      <div className="grid grid-cols-2 md:grid-cols-[1fr_140px_auto] gap-2">
        <select className={classeInputOs} value={index} onChange={(e) => { setIndex(Number(e.target.value)); reinitialiser(); }} aria-label="Moment en retard">
          {tries.map((m, i) => <option key={i} value={i}>{m.heureDebut} — {m.titre}</option>)}
        </select>
        <select className={classeInputOs} value={retard} onChange={(e) => { setRetard(Number(e.target.value)); reinitialiser(); }} aria-label="Durée du retard">
          {[5, 10, 15, 30, 45, 60].map((n) => <option key={n} value={n}>+{n} min</option>)}
        </select>
        <button onClick={simuler} className={classeBoutonBleuVert}>Simuler</button>
      </div>

      {proposition && (
        <div className="space-y-3">
          <p className="text-sm font-semibold text-white tabular-nums">+{retard} min — prévisualisation calculée.</p>
          {proposition.impacts.length === 0 ? (
            <p className="text-sm text-white/70">Aucun impact : rien à recaler après ce moment.</p>
          ) : (
            <ListeImpacts impacts={proposition.impacts} />
          )}
          <div className="flex gap-2">
            <button
              onClick={() => { onAppliquer(proposition.moments); reinitialiser(); }}
              className={classeBoutonBleuVert}
            >
              <Check className="h-4 w-4" /> Appliquer au déroulé
            </button>
            <button
              onClick={reinitialiser}
              className="min-h-[42px] px-4 rounded-full bg-white/15 text-white/80 text-sm hover:text-white transition-colors inline-flex items-center gap-1.5"
            >
              <X className="h-4 w-4" /> Ignorer
            </button>
          </div>
          <p className="text-[11px] text-white/70">
            Le moteur utilise les horaires, les dépendances confirmées et les capacités de barrière saisies. Aucun autre lien ne modifie automatiquement le déroulé.
          </p>
        </div>
      )}
    </div>
  );
}