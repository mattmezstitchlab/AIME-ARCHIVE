import React from "react";
import { FastForward, Pause, Play, SkipBack, SkipForward } from "lucide-react";

const classe = "inline-flex h-9 shrink-0 items-center justify-center rounded-full bg-white/10 text-[11px] font-semibold text-white/75 transition-colors hover:bg-white/20 focus-visible:ring-2 focus-visible:ring-[#BF5AF2]";
export default function CommandesNavigationCadran({ lecture, rapide, onLecture, onRapide, onPrecedent, onReculer, onAvancer, onSuivant }) {
  return <nav className="mt-2 flex flex-nowrap items-center justify-center gap-1.5" aria-label="Navigation logistique dans le cadran">
    <button onClick={onPrecedent} aria-label="Moment précédent" title="Moment précédent" className={`${classe} w-9`}><SkipBack className="h-4 w-4" /></button>
    <button onClick={onReculer} aria-label="Reculer d’une heure" className={`${classe} px-2.5`}>−1 h</button>
    <button onClick={onLecture} aria-label={lecture ? "Mettre en pause" : "Lire le déroulé"} title={lecture ? "Pause" : "Lecture"} className={`${classe} w-9`}>{lecture ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}</button>
    <button onClick={onRapide} aria-pressed={rapide} aria-label="Activer l’avance rapide" title="Avance rapide" className={`${classe} w-9 ${rapide ? "bg-gradient-to-r from-[#BF5AF2] to-[#0A84FF] text-white" : ""}`}><FastForward className="h-4 w-4" /></button>
    <button onClick={onAvancer} aria-label="Avancer d’une heure" className={`${classe} px-2.5`}>+1 h</button>
    <button onClick={onSuivant} aria-label="Moment suivant" title="Moment suivant" className={`${classe} w-9`}><SkipForward className="h-4 w-4" /></button>
  </nav>;
}