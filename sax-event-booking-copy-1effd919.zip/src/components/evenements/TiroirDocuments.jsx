import React from "react";
import { ArrowLeft, Download, FileText, Folder, Loader2, Plus } from "lucide-react";
import StatutPieceDossier from "@/components/evenements/StatutPieceDossier";
import { TYPES_DOCUMENTS } from "@/lib/typesDocuments";

export default function TiroirDocuments({ groupe, peutModifier, onStatut, onCreer, onTelecharger, telechargement, onRetour }) {
  return <section>
    <div className="mb-5 flex items-center gap-3 pr-12">
      <button type="button" onClick={onRetour} aria-label="Retour au bureau des documents" className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-white/10 text-white/70 hover:text-white"><ArrowLeft className="h-5 w-5" /></button>
      <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-[#FF2D78]/20 via-[#BF5AF2]/20 to-[#0A84FF]/20"><Folder className="h-5 w-5 text-[#BF5AF2]" /></span>
      <div className="min-w-0"><h4 className="truncate text-base font-semibold text-white">{groupe.label}</h4><p className="text-xs text-white/45">{groupe.pieces.length} pièce(s) · {groupe.documents.length} document(s)</p></div>
    </div>
    <div className="space-y-2">
      {groupe.pieces.map((piece) => <div key={piece.id} className="flex min-w-0 flex-col gap-3 rounded-2xl border border-white/10 bg-white/[0.045] p-4 sm:flex-row sm:items-center"><div className="min-w-0 flex-1"><p className="text-sm font-medium text-white/90">{piece.titre}</p><p className="mt-1 text-xs leading-relaxed text-white/45">{piece.description}</p></div><StatutPieceDossier piece={piece} modifiable={peutModifier(piece)} onChange={onStatut} /></div>)}
      {groupe.documents.map((doc) => <div key={doc.id} className="flex min-h-[52px] items-center gap-3 rounded-2xl border border-[#30D158]/15 bg-[#30D158]/[0.07] px-3"><FileText className="h-4 w-4 text-[#5EEA79]" /><span className="min-w-0 flex-1 truncate text-sm text-white/80">{TYPES_DOCUMENTS[doc.type]?.libelle || doc.type} · {doc.numero}</span>{doc.fichierUrl && <button onClick={() => onTelecharger(doc)} aria-label={`Consulter ${doc.numero}`} className="flex h-10 w-10 items-center justify-center rounded-full bg-white/10">{telechargement === doc.id ? <Loader2 className="h-4 w-4 animate-spin" /> : <Download className="h-4 w-4" />}</button>}</div>)}
    </div>
    {onCreer && <button onClick={() => onCreer(groupe.acteur)} className="mt-4 inline-flex min-h-[44px] items-center gap-2 rounded-full bg-white/10 px-4 text-sm font-semibold text-white hover:bg-white/15"><Plus className="h-4 w-4" />Créer ou rectifier un document</button>}
  </section>;
}