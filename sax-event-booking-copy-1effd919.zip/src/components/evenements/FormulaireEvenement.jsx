import React, { useState } from "react";
import { MODELES_EVENEMENTS } from "@/lib/modelesEvenements";
import { classeInputOs, classeBoutonOs } from "@/components/evenements/stylesOs";
import { Loader2, ArrowLeft } from "lucide-react";

const classeLabel = "text-[10px] font-bold uppercase tracking-[0.2em] text-white/40";

export default function FormulaireEvenement({ onCreer, onAnnuler, typeInitial }) {
  const [typeChoisi, setTypeChoisi] = useState(typeInitial && MODELES_EVENEMENTS[typeInitial] ? typeInitial : null);
  const [v, setV] = useState({ titre: "", date: "", lieu: "", organisateurNom: "" });
  const [enCours, setEnCours] = useState(false);
  const [erreur, setErreur] = useState("");

  const maj = (cle) => (e) => setV((prev) => ({ ...prev, [cle]: e.target.value }));

  const modele = typeChoisi ? MODELES_EVENEMENTS[typeChoisi] : null;

  const soumettre = async () => {
    if (!v.titre.trim() || !v.date) { setErreur("Le titre et la date sont obligatoires."); return; }
    setEnCours(true);
    await onCreer({
      ...v,
      typeEvenement: modele.libelle,
      moments: modele.moments,
      acteurs: modele.acteurs,
    });
    setEnCours(false);
  };

  // Étape 1 : choix du type d'événement
  if (!typeChoisi) {
    return (
      <div className="rounded-2xl bg-[#141416] p-4 space-y-4 sm:p-6">
        <div>
          <h3 className="font-heading text-lg text-white">Nouvel événement</h3>
          <p className="mt-1 text-sm text-white/50">
            Étape 1 sur 2 — Choisissez un type : le déroulé du Jour J et les acteurs habituels seront pré-remplis.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          {Object.entries(MODELES_EVENEMENTS).map(([cle, m]) => (
            <button
              key={cle}
              onClick={() => setTypeChoisi(cle)}
              title={m.description}
              className="flex flex-col items-center gap-2 rounded-2xl px-4 py-3 hover:bg-white/10 transition-colors"
            >
              <m.icone className="h-7 w-7 text-white/90" strokeWidth={2} />
              <span className="text-sm font-semibold text-white">{m.libelle}</span>
            </button>
          ))}
        </div>
        <button onClick={onAnnuler} className="min-h-[44px] px-6 rounded-full bg-white/[0.07] text-sm text-white/60 hover:text-white hover:bg-white/10 transition-colors">
          Annuler
        </button>
      </div>
    );
  }

  // Étape 2 : informations de l'événement
  return (
    <div className="rounded-2xl bg-[#141416] p-4 space-y-4 sm:p-6">
      <div className="flex items-center gap-3">
        <button
          onClick={() => setTypeChoisi(null)}
          aria-label="Revenir au choix du type"
          className="h-10 w-10 rounded-full bg-white/[0.07] flex items-center justify-center text-white/60 hover:text-white hover:bg-white/10 transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
        </button>
        <div>
          <h3 className="font-heading text-lg text-white inline-flex items-center gap-2">
            <modele.icone className="h-5 w-5 text-white/60" /> {modele.libelle}
          </h3>
          <p className="text-sm text-white/50">Étape 2 sur 2 — Les informations essentielles.</p>
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="md:col-span-2">
          <label htmlFor="evenement-titre" className={classeLabel}>Titre *</label>
          <input id="evenement-titre" className={`mt-1 ${classeInputOs}`} value={v.titre} onChange={maj("titre")} placeholder={modele.placeholderTitre} />
        </div>
        <div>
          <label htmlFor="evenement-date" className={classeLabel}>Date *</label>
          <input id="evenement-date" type="date" className={`mt-1 ${classeInputOs}`} value={v.date} onChange={maj("date")} />
        </div>
        <div>
          <label htmlFor="evenement-lieu" className={classeLabel}>Lieu</label>
          <input id="evenement-lieu" className={`mt-1 ${classeInputOs}`} value={v.lieu} onChange={maj("lieu")} />
        </div>
        <div className="md:col-span-2">
          <label htmlFor="evenement-organisateur" className={classeLabel}>Organisateur</label>
          <input id="evenement-organisateur" className={`mt-1 ${classeInputOs}`} value={v.organisateurNom} onChange={maj("organisateurNom")} />
        </div>
      </div>
      {modele.moments.length > 0 && (
        <p className="text-[12px] text-white/50">
          {modele.moments.length} moments et {modele.acteurs.length} acteurs seront pré-remplis — tout reste modifiable ensuite.
        </p>
      )}
      {erreur && <p className="text-sm text-[#FF453A]" role="alert">{erreur}</p>}
      <div className="flex flex-col gap-2 sm:flex-row">
        <button onClick={soumettre} disabled={enCours} className={`min-h-[48px] w-full sm:flex-1 ${classeBoutonOs} disabled:opacity-70`}>
          {enCours && <Loader2 className="h-4 w-4 animate-spin" />}
          Créer l'événement
        </button>
        <button onClick={onAnnuler} className="min-h-[48px] w-full px-6 sm:w-auto rounded-full bg-white/[0.07] text-sm text-white/60 hover:text-white hover:bg-white/10 transition-colors">
          Annuler
        </button>
      </div>
    </div>
  );
}