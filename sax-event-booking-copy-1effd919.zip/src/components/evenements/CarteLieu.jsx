import React, { useEffect, useState } from "react";
import { Loader2, MapPin } from "lucide-react";

export default function CarteLieu({ lieu }) {
  const [coords, setCoords] = useState(undefined);

  useEffect(() => {
    if (!lieu) { setCoords(null); return; }
    let actif = true;
    setCoords(undefined);
    fetch(`https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(lieu)}&format=json&limit=1`)
      .then((r) => r.json())
      .then((res) => { if (actif) setCoords(res[0] ? { lat: +res[0].lat, lon: +res[0].lon } : null); })
      .catch(() => { if (actif) setCoords(null); });
    return () => { actif = false; };
  }, [lieu]);

  if (!lieu) return <p className="text-sm text-white/50">Aucun lieu défini pour cet événement.</p>;
  if (coords === undefined) {
    return (
      <div className="flex items-center justify-center gap-2 py-10 text-white/50 text-sm">
        <Loader2 className="h-4 w-4 animate-spin" /> Localisation du lieu…
      </div>
    );
  }
  if (coords === null) return <p className="text-sm text-white/50">Impossible de localiser « {lieu} ».</p>;

  const bbox = `${coords.lon - 0.008},${coords.lat - 0.005},${coords.lon + 0.008},${coords.lat + 0.005}`;
  return (
    <div className="space-y-2">
      <p className="inline-flex items-center gap-1.5 text-sm text-white/60">
        <MapPin className="h-4 w-4" /> {lieu}
      </p>
      <iframe
        title={`Carte de ${lieu}`}
        src={`https://www.openstreetmap.org/export/embed.html?bbox=${bbox}&layer=mapnik&marker=${coords.lat},${coords.lon}`}
        className="w-full h-72 rounded-2xl border-0"
        loading="lazy"
      />
    </div>
  );
}