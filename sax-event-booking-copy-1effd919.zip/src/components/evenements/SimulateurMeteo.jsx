import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { appliquerMeteo } from "@/lib/moteurCausal";
import { classeBoutonBleuVert } from "@/components/evenements/stylesOs";
import ListeImpacts from "@/components/evenements/ListeImpacts";
import { CloudRain, Globe, Loader2, Check, X } from "lucide-react";

export default function SimulateurMeteo({ evenement, onAppliquer, onSimulation, couleur = "#FF2D78" }) {
  const [proposition, setProposition] = useState(null);
  const [meteo, setMeteo] = useState(null);
  const [chargement, setChargement] = useState(false);
  const [erreur, setErreur] = useState("");

  const moments = evenement.moments || [];
  const exterieurs = moments.filter((m) => m.exposition === "exterieur");

  const consulterMeteo = async () => {
    setChargement(true); setErreur("");
    try {
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `Quelle est la prévision météo pour ${evenement.lieu || "France"} le ${evenement.date} ? Réponds en français : un résumé en une phrase, et indique s'il y a un risque de pluie ou de vent fort ce jour-là.`,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: { resume: { type: "string" }, risque: { type: "boolean" } },
        },
      });
      setMeteo(res);
    } catch {
      setErreur("La météo n’a pas pu être consultée. Réessayez plus tard ou confirmez-la auprès d’une source officielle.");
    } finally {
      setChargement(false);
    }
  };

  return (
    <div className="space-y-4">
      <h3 className="text-[10px] font-bold uppercase tracking-[0.3em] text-white/70 inline-flex items-center gap-2">
        <CloudRain className="h-3.5 w-3.5 text-white" /> Moteur causal — météo & plans B
      </h3>

      <div className="flex flex-wrap gap-2">
        <button onClick={consulterMeteo} disabled={chargement} className={classeBoutonBleuVert}>
          {chargement ? <Loader2 className="h-4 w-4 animate-spin" /> : <Globe className="h-4 w-4" />}
          Consulter la météo réelle
        </button>
        <button
          onClick={() => {
            const resultat = appliquerMeteo(moments, evenement.liensCausaux || []); setProposition(resultat);
            onSimulation?.({ id: "simulation-pluie", niveau: "rouge", label: `Pluie · ${exterieurs.length} moments impactés`, cause: "Averse simulée pendant les moments extérieurs.", elements: resultat.impacts, consequences: resultat.impacts, recommandation: "Prévisualiser les plans B et prévenir les responsables avant application.", avant: `${exterieurs.length} moment(s) prévu(s) en extérieur`, apres: `${resultat.impacts.length} conséquence(s) calculée(s)`, appliquer: () => onAppliquer(resultat.moments) });
          }}
          disabled={exterieurs.length === 0}
          className="min-h-[42px] px-4 rounded-full bg-white/15 text-white/80 text-sm hover:text-white transition-colors inline-flex items-center gap-1.5 disabled:opacity-40"
        >
          <CloudRain className="h-4 w-4" /> Simuler la pluie
        </button>
      </div>

      {meteo && (
        <p className="text-sm rounded-xl px-4 py-2.5 bg-white/15 text-white">
          {meteo.resume} <span className="text-white/60">Indication à confirmer avant toute décision.</span>
        </p>
      )}
      {erreur && <p role="alert" className="rounded-xl bg-[#FF453A]/15 px-4 py-2.5 text-sm text-[#FF6961]">{erreur}</p>}

      {exterieurs.length === 0 ? (
        <p className="text-[11px] text-white/70">
          Aucun moment marqué « extérieur » dans le déroulé — la météo n'a pas d'impact. Marquez l'exposition des moments pour activer cette simulation.
        </p>
      ) : (
        <p className="text-[11px] text-white/70">
          {exterieurs.length} moment{exterieurs.length > 1 ? "s" : ""} en extérieur. En cas de pluie, chacun bascule sur son plan B s'il en a un.
        </p>
      )}

      {proposition && (
        <div className="space-y-3">
          <ListeImpacts impacts={proposition.impacts} />
          <div className="flex gap-2">
            <button onClick={() => { onAppliquer(proposition.moments); setProposition(null); }} className={classeBoutonBleuVert}>
              <Check className="h-4 w-4" /> Activer les plans B
            </button>
            <button
              onClick={() => setProposition(null)}
              className="min-h-[42px] px-4 rounded-full bg-white/15 text-white/80 text-sm hover:text-white transition-colors inline-flex items-center gap-1.5"
            >
              <X className="h-4 w-4" /> Ignorer
            </button>
          </div>
        </div>
      )}
    </div>
  );
}