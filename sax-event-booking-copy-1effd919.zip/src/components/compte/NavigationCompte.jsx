import React from "react";

export default function NavigationCompte({ onglets, actif, onChange }) {
  return (
    <>
      <div className="mb-6 md:hidden">
        <label htmlFor="navigation-compte" className="mb-2 block text-xs font-bold uppercase tracking-wider text-[var(--p-muted)]">Section</label>
        <select id="navigation-compte" value={actif} onChange={(e) => onChange(e.target.value)} className="min-h-[48px] w-full rounded-xl border border-[var(--p-border)] bg-[var(--p-surface)] px-4 text-sm font-semibold text-[var(--p-text)]">
          {onglets.map(([cle, libelle]) => <option key={cle} value={cle}>{libelle}</option>)}
        </select>
      </div>
      <nav aria-label="Sections du compte" className="mb-7 hidden min-w-0 flex-wrap gap-2 md:flex">
        {onglets.map(([cle, libelle, Icone]) => (
          <button key={cle} onClick={() => onChange(cle)} aria-current={actif === cle ? "page" : undefined} className={`inline-flex min-h-[44px] items-center gap-2 rounded-full px-4 text-sm font-medium transition-colors ${actif === cle ? "bg-[#141416] text-white" : "bg-white/[0.06] text-[var(--p-muted)] hover:bg-white/[0.10] hover:text-[var(--p-text)]"}`}>
            <Icone className="h-4 w-4" aria-hidden="true" /> {libelle}
          </button>
        ))}
      </nav>
    </>
  );
}