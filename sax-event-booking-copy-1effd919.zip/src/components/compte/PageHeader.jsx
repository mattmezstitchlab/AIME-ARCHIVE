import React from "react";

export default function PageHeader({ titre, contexte, actions }) {
  return (
    <header className="mb-6 min-w-0 lg:mb-8 lg:flex lg:items-end lg:justify-between lg:gap-6">
      <div className="min-w-0">
        <h1 className="font-heading text-3xl font-semibold tracking-tight sm:text-4xl">{titre}</h1>
        {contexte && <p className="mt-1.5 max-w-full overflow-wrap-anywhere text-sm text-[var(--p-muted)]">{contexte}</p>}
      </div>
      {actions && <div className="mt-4 flex min-w-0 flex-wrap items-center gap-2 lg:mt-0 lg:shrink-0">{actions}</div>}
    </header>
  );
}