import React from "react";

export default function EmptyState({ icon: Icon, titre, texte, action, onAction }) {
  return (
    <div className="rounded-2xl border border-[var(--p-border)] bg-[var(--p-surface)] px-5 py-10 text-center sm:px-8 sm:py-14">
      <Icon className="mx-auto h-10 w-10 text-[var(--p-faint)]" aria-hidden="true" />
      <h2 className="mt-4 font-heading text-xl font-semibold text-[var(--p-text)]">{titre}</h2>
      <p className="mx-auto mt-2 max-w-md text-sm leading-relaxed text-[var(--p-muted)]">{texte}</p>
      {action && <button onClick={onAction} className="mt-6 min-h-[48px] w-full rounded-full bg-[var(--p-cta)] px-6 text-sm font-bold text-[var(--p-cta-text)] sm:w-auto">{action}</button>}
    </div>
  );
}