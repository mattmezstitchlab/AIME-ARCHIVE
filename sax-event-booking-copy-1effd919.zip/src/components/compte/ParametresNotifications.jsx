import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Loader2, Check } from "lucide-react";

export default function ParametresNotifications({ email }) {
  const [profil, setProfil] = useState(null);
  const [valeur, setValeur] = useState("");
  const [enCours, setEnCours] = useState(false);
  const [sauve, setSauve] = useState(false);

  useEffect(() => {
    base44.entities.ProfilPrestataire.filter({ proprietaire: email }, "-updated_date", 1).then((l) => {
      setProfil(l[0] || null);
      setValeur(l[0]?.emailNotification || "");
    });
  }, [email]);

  const enregistrer = async () => {
    if (!profil) return;
    setEnCours(true);
    await base44.entities.ProfilPrestataire.update(profil.id, { emailNotification: valeur.trim().toLowerCase() });
    setEnCours(false);
    setSauve(true);
  };

  if (!profil) return null;

  return (
    <div className="rounded-2xl border border-[#B49B72]/25 bg-white p-5 md:p-6">
      <h2 className="font-heading text-xl font-semibold tracking-tight text-[#1C1917]">Notifications</h2>
      <p className="mt-1 text-sm text-[#57534E]">
        Adresse qui reçoit les nouvelles demandes de disponibilité envoyées depuis votre page publique.
      </p>
      <div className="mt-4 flex min-w-0 flex-col gap-2 sm:flex-row">
        <label htmlFor="email-notification" className="sr-only">Adresse e-mail de notification</label>
        <input
          id="email-notification"
          type="email"
          className="min-h-[48px] min-w-0 flex-1 overflow-wrap-anywhere rounded-lg border border-[#B49B72]/40 bg-white px-3 text-sm text-[#1C1917] focus:border-[#8A7356] focus:outline-none"
          placeholder={email}
          value={valeur}
          onChange={(e) => { setValeur(e.target.value); setSauve(false); }}
        />
        <button
          onClick={enregistrer}
          disabled={enCours}
          className="min-h-[48px] w-full px-5 rounded-full sm:w-auto bg-[#1C1917] text-[#FAF7F2] text-sm font-bold inline-flex items-center justify-center gap-2 hover:bg-[#33302B] disabled:opacity-70"
        >
          {enCours ? <Loader2 className="h-4 w-4 animate-spin" /> : sauve ? <Check className="h-4 w-4" /> : null}
          {sauve ? "Enregistré" : "Enregistrer"}
        </button>
      </div>
    </div>
  );
}