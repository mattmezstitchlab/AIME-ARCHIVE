import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { lirePreferences, sauvegarderPreferences } from "@/lib/accessibilite";
import { Switch } from "@/components/ui/switch";
import ParametresNotifications from "@/components/compte/ParametresNotifications";
import { LogOut } from "lucide-react";

const TAILLES = [
  ["100", "Standard"],
  ["110", "Grand"],
  ["125", "Très grand"],
];

const OPTIONS = [
  ["contraste", "Contraste renforcé", "Textes et bordures plus marqués pour une meilleure lisibilité."],
  ["motionReduit", "Réduire les animations", "Désactive les transitions et effets de mouvement (confort vestibulaire)."],
  ["liensSoulignes", "Liens toujours soulignés", "Les liens restent identifiables sans dépendre de la couleur."],
  ["espacement", "Espacement du texte", "Interlignage et espacement des lettres augmentés (norme EN 301 549 / WCAG)."],
];

export default function ParametresCompte({ email }) {
  const [prefs, setPrefs] = useState(lirePreferences);
  const [utilisateur, setUtilisateur] = useState(null);

  useEffect(() => {
    base44.auth.me().then(setUtilisateur).catch(() => {});
  }, []);

  const changer = (maj) => {
    const nouvelles = { ...prefs, ...maj };
    setPrefs(nouvelles);
    sauvegarderPreferences(nouvelles);
  };

  return (
    <div className="min-w-0 max-w-2xl space-y-6">
      {/* Mon compte */}
      <div className="rounded-2xl border border-[#B49B72]/25 bg-white p-5 md:p-6">
        <h2 className="font-heading text-xl font-semibold tracking-tight text-[#1C1917]">Mon compte</h2>
        <div className="mt-4 space-y-3 text-sm">
          <div className="grid min-w-0 gap-1 border-b border-[#B49B72]/15 pb-3 sm:grid-cols-[minmax(140px,auto)_minmax(0,1fr)] sm:items-start sm:gap-4">
            <span className="text-[#57534E]">Nom</span>
            <span className="font-semibold text-[#1C1917]">{utilisateur?.full_name || "—"}</span>
          </div>
          <div className="grid min-w-0 gap-1 border-b border-[#B49B72]/15 pb-3 sm:grid-cols-[minmax(140px,auto)_minmax(0,1fr)] sm:items-start sm:gap-4">
            <span className="text-[#57534E]">E-mail de connexion</span>
            <span className="min-w-0 overflow-wrap-anywhere font-semibold text-[#1C1917] sm:text-right">{utilisateur?.email || email}</span>
          </div>
          <div className="grid min-w-0 gap-1 sm:grid-cols-[minmax(140px,auto)_minmax(0,1fr)] sm:items-start sm:gap-4">
            <span className="text-[#57534E]">Rôle</span>
            <span className="font-semibold text-[#1C1917]">{utilisateur?.role === "admin" ? "Administrateur" : "Utilisateur"}</span>
          </div>
        </div>
        <button
          onClick={() => base44.auth.logout("/")}
          className="mt-5 inline-flex min-h-[48px] w-full items-center justify-center gap-2 rounded-full px-5 sm:w-auto border border-[#B49B72]/40 text-sm font-semibold text-[#1C1917] hover:bg-[#FAF7F2] transition-colors"
        >
          <LogOut className="h-4 w-4" /> Se déconnecter
        </button>
      </div>

      {/* Notifications */}
      {email && <ParametresNotifications email={email} />}

      <div className="rounded-2xl border border-[#B49B72]/25 bg-white p-5 md:p-6">
        <h2 className="font-heading text-xl font-semibold tracking-tight text-[#1C1917]">Accessibilité</h2>
        <p className="mt-1 text-sm text-[#57534E]">
          Réglages conformes à l'Acte européen d'accessibilité (EAA / EN 301 549) et aux bonnes pratiques universelles (WCAG 2.2). Ils s'appliquent immédiatement à toute l'application, sur cet appareil.
        </p>

        <div className="mt-6">
          <p className="text-sm font-semibold text-[#1C1917]">Taille du texte</p>
          <div className="mt-2 flex flex-wrap gap-2">
            {TAILLES.map(([valeur, libelle]) => (
              <button
                key={valeur}
                onClick={() => changer({ taille: valeur })}
                className={`min-h-[40px] px-4 rounded-full text-sm font-medium transition-colors ${
                  prefs.taille === valeur
                    ? "bg-[var(--p-text)] text-[var(--p-bg)]"
                    : "bg-white border border-[#B49B72]/25 text-[#57534E] hover:text-[#1C1917]"
                }`}
              >
                {libelle}
              </button>
            ))}
          </div>
        </div>

        <div className="mt-6 divide-y divide-[#B49B72]/15">
          {OPTIONS.map(([cle, titre, description]) => (
            <div key={cle} className="flex items-center justify-between gap-4 py-4">
              <div>
                <p className="text-sm font-semibold text-[#1C1917]">{titre}</p>
                <p className="text-xs text-[#57534E] mt-0.5">{description}</p>
              </div>
              <Switch
                checked={!!prefs[cle]}
                onCheckedChange={(v) => changer({ [cle]: v })}
                aria-label={titre}
              />
            </div>
          ))}
        </div>
      </div>

      <p className="text-xs text-[#57534E]/70 px-1">
        Ces préférences sont enregistrées sur votre navigateur et respectées sur toutes les pages, y compris votre page publique.
      </p>
    </div>
  );
}