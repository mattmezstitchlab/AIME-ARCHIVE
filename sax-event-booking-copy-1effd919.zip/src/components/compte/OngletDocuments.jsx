import React, { useEffect, useState } from "react";
import HistoriqueDocuments from "@/components/admin/HistoriqueDocuments";
import DocumentsRecus from "@/components/compte/DocumentsRecus";
import StudioDocument from "@/components/documents/StudioDocument";
import { Plus } from "lucide-react";

export default function OngletDocuments({ email, expediteur, prefill }) {
  const [vue, setVue] = useState("emis");
  const [studioOuvert, setStudioOuvert] = useState(false);
  const [actualisation, setActualisation] = useState(0);

  // Un document préparé depuis une demande ouvre directement le studio.
  useEffect(() => {
    if (prefill) { setVue("emis"); setStudioOuvert(true); }
  }, [prefill]);

  return (
    <div className="space-y-6">
      <div className="grid min-w-0 gap-3 sm:grid-cols-[minmax(240px,360px)_auto] sm:items-center sm:justify-between">
        <div className="grid grid-cols-2 gap-2" role="tablist" aria-label="Documents">
          {[["emis", "Émis"], ["recus", "Reçus"]].map(([cle, libelle]) => (
            <button
              key={cle}
              role="tab"
              aria-selected={vue === cle}
              onClick={() => setVue(cle)}
              className={`min-h-[48px] w-full px-5 rounded-full text-sm font-semibold transition-colors ${
                vue === cle
                  ? "bg-[var(--p-text)] text-[var(--p-bg)]"
                  : "bg-[var(--p-surface)] text-[var(--p-muted)] hover:text-[var(--p-text)] border border-[var(--p-border)]"
              }`}
            >
              {libelle}
            </button>
          ))}
        </div>
        {vue === "emis" && (
          <button
            onClick={() => setStudioOuvert(true)}
            className="inline-flex min-h-[48px] w-full items-center justify-center gap-2 rounded-full bg-[var(--p-text)] px-5 text-sm font-semibold text-[var(--p-bg)] transition-opacity hover:opacity-90 sm:w-auto"
          >
            <Plus className="h-4 w-4" /> Nouveau document
          </button>
        )}
      </div>

      {vue === "emis" ? (
        <HistoriqueDocuments actualisation={actualisation} email={email} expediteur={expediteur} onCreer={() => setStudioOuvert(true)} />
      ) : (
        <DocumentsRecus email={email} />
      )}

      {studioOuvert && (
        <StudioDocument
          email={email}
          valeursInitiales={prefill}
          onFermer={() => setStudioOuvert(false)}
          onGenere={() => setActualisation((n) => n + 1)}
        />
      )}
    </div>
  );
}