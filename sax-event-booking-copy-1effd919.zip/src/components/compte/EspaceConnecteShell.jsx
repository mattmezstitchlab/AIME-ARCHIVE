import React from "react";
import EnTetePlateforme from "@/components/plateforme/EnTetePlateforme";

export default function EspaceConnecteShell({ children, sombre = false, largeur = "max-w-7xl" }) {
  return (
    <div className={`theme-apple min-h-screen overflow-x-clip font-body ${sombre ? "bg-[#050506] text-white" : "bg-[var(--p-bg)] text-[var(--p-text)]"}`}>
      <EnTetePlateforme sombre={sombre} />
      <div className={`${largeur} mx-auto min-w-0 max-w-full px-4 pb-[calc(8rem+env(safe-area-inset-bottom))] pt-5 sm:px-6 sm:pt-7 lg:px-8`}>
        {children}
      </div>
    </div>
  );
}