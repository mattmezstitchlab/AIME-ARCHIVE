import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Loader2, FileDown, FileText, CreditCard, CheckCircle2 } from "lucide-react";
import EmptyState from "@/components/compte/EmptyState";

const LIBELLES = { devis: "Devis", facture: "Facture", contrat: "Contrat" };

export default function DocumentsRecus({ email }) {
  const [documents, setDocuments] = useState(null);
  const [ouverture, setOuverture] = useState("");
  const [paiement, setPaiement] = useState("");
  const [erreurPaiement, setErreurPaiement] = useState("");

  useEffect(() => {
    base44.entities.DocumentEmis.filter({ clientEmail: email }, "-created_date").then(setDocuments);
  }, [email]);

  const payer = async (doc) => {
    // Le paiement Stripe ne fonctionne pas dans l'aperçu intégré (iframe).
    if (window.self !== window.top) {
      setErreurPaiement("Le paiement en ligne fonctionne uniquement depuis l'application publiée. Ouvrez l'app dans un nouvel onglet.");
      return;
    }
    setPaiement(doc.id);
    setErreurPaiement("");
    try {
      const { data } = await base44.functions.invoke("paiementDocument", {
        documentId: doc.id,
        urlRetour: `${window.location.origin}/compte`,
      });
      if (data?.url) {
        window.location.href = data.url;
      } else {
        setErreurPaiement(data?.error || "Impossible de créer le paiement.");
      }
    } catch (e) {
      setErreurPaiement(e?.response?.data?.error || "Impossible de créer le paiement.");
    } finally {
      setPaiement("");
    }
  };

  const telecharger = async (doc) => {
    setOuverture(doc.id);
    try {
      let url = doc.fichierUrl;
      if (!String(url).startsWith("http")) {
        const { signed_url } = await base44.integrations.Core.CreateFileSignedUrl({ file_uri: url });
        url = signed_url;
      }
      window.open(url, "_blank", "noopener");
    } finally {
      setOuverture("");
    }
  };

  if (documents === null) {
    return (
      <div className="flex justify-center py-16">
        <Loader2 className="h-6 w-6 animate-spin text-[#8A7356]" />
      </div>
    );
  }

  if (documents.length === 0) {
    return <EmptyState icon={FileText} titre="Aucun document reçu" texte="Les devis, contrats et factures émis pour vous apparaîtront ici." />;
  }

  return (
    <div className="space-y-4">
      {erreurPaiement && (
        <p className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">{erreurPaiement}</p>
      )}
      {documents.map((doc) => {
        const [a, m, j] = String(doc.dateEmission || "").split("-");
        return (
          <div key={doc.id} className="flex min-w-0 flex-col gap-4 rounded-xl border border-[#B49B72]/25 bg-white p-5 shadow-sm sm:flex-row sm:flex-wrap sm:items-center sm:justify-between">
            <div className="min-w-0">
              <p className="overflow-wrap-anywhere font-heading text-lg">{LIBELLES[doc.type] || doc.type} {doc.numero}</p>
              <p className="text-sm text-[#57534E] mt-0.5">
                {doc.description || "Prestation"}
                {doc.dateEmission && ` — émis le ${j}/${m}/${a}`}
              </p>
              <p className="text-sm font-bold text-[#8A7356] mt-1">
                {Number(doc.montant || 0).toLocaleString("fr-FR", { minimumFractionDigits: 2 })} €
              </p>
            </div>
            <div className="flex w-full flex-col gap-2 sm:w-auto sm:flex-row sm:flex-wrap sm:items-center">
              {doc.statut === "paye" ? (
                <span className="inline-flex items-center gap-1.5 min-h-[44px] px-5 rounded-full bg-green-50 text-green-700 text-sm font-medium">
                  <CheckCircle2 className="h-4 w-4" /> Payé
                </span>
              ) : (
                (doc.type === "facture" || doc.type === "devis") && Number(doc.montant) > 0 && (
                  <button
                    onClick={() => payer(doc)}
                    disabled={paiement === doc.id}
                    className="min-h-[48px] w-full justify-center px-5 rounded-full border sm:w-auto border-[#1C1917] text-[#1C1917] text-sm font-medium flex items-center gap-2 hover:bg-[#FAF7F2] transition-colors disabled:opacity-60"
                  >
                    {paiement === doc.id ? <Loader2 className="h-4 w-4 animate-spin" /> : <CreditCard className="h-4 w-4" />} Payer en ligne
                  </button>
                )
              )}
              {doc.fichierUrl ? (
                <button
                  onClick={() => telecharger(doc)}
                  disabled={ouverture === doc.id}
                  className="min-h-[48px] w-full justify-center px-5 rounded-full bg-[#1C1917] sm:w-auto text-[#FAF7F2] text-sm font-medium flex items-center gap-2 hover:bg-[#33302B] transition-colors disabled:opacity-60"
                >
                  {ouverture === doc.id ? <Loader2 className="h-4 w-4 animate-spin" /> : <FileDown className="h-4 w-4" />} Télécharger
                </button>
              ) : (
                <span className="text-xs text-[#57534E]">PDF bientôt disponible</span>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}