import React, { useEffect, useState } from "react";
import { Trash2, Music, Play, Pause } from "lucide-react";
import { SOURCES_PLAYLIST } from "@/lib/playlist";
import { basculerLecture, surChangementLecture } from "@/lib/lecteurApercu";

const formatDuree = (sec) => (sec ? `${Math.floor(sec / 60)}:${String(sec % 60).padStart(2, "0")}` : null);

export default function MorceauLigne({ morceau: m, onSupprimer }) {
  const src = SOURCES_PLAYLIST[m.source] || SOURCES_PLAYLIST.marie;
  const [enLecture, setEnLecture] = useState(false);

  useEffect(() => surChangementLecture((url) => setEnLecture(!!m.previewUrl && url === m.previewUrl)), [m.previewUrl]);

  return (
    <li className="flex items-center gap-3 px-4 py-2.5 border-b border-white/5 last:border-b-0">
      {/* Pochette + lecture */}
      {m.previewUrl ? (
        <button
          type="button"
          onClick={() => basculerLecture(m.previewUrl)}
          title={enLecture ? "Mettre en pause" : "Écouter un extrait (30 s)"}
          aria-label={`${enLecture ? "Pause" : "Écouter"} ${m.titre}`}
          className="relative h-10 w-10 shrink-0 rounded-lg overflow-hidden group"
        >
          {m.pochetteUrl ? (
            <img src={m.pochetteUrl} alt="" className="h-full w-full object-cover" />
          ) : (
            <span className="h-full w-full flex items-center justify-center bg-white/10">
              <Music className="h-4 w-4 text-white/40" />
            </span>
          )}
          <span className={`absolute inset-0 flex items-center justify-center bg-black/50 transition-opacity ${enLecture ? "opacity-100" : "opacity-0 group-hover:opacity-100"}`}>
            {enLecture ? <Pause className="h-4 w-4 text-white" /> : <Play className="h-4 w-4 text-white" />}
          </span>
        </button>
      ) : m.pochetteUrl ? (
        <img src={m.pochetteUrl} alt="" className="h-10 w-10 shrink-0 rounded-lg object-cover" />
      ) : (
        <span className="h-10 w-10 shrink-0 rounded-lg bg-white/[0.06] flex items-center justify-center">
          <Music className="h-4 w-4 text-white/25" />
        </span>
      )}

      {/* Titre + artiste */}
      <span className="flex-1 min-w-0">
        <span className={`block text-sm truncate ${enLecture ? "font-semibold texte-prisme" : "text-white"}`}>{m.titre}</span>
        {m.artiste && <span className="block text-xs text-white/40 truncate">{m.artiste}</span>}
      </span>

      {/* Infos DJ : BPM, tonalité, durée */}
      <span className="hidden sm:flex items-center gap-1.5 shrink-0 tabular-nums">
        {m.bpm > 0 && (
          <span className="px-2 py-0.5 rounded-md bg-white/[0.08] text-[11px] font-bold text-white/80" title="Tempo">
            {Math.round(m.bpm)} <span className="font-normal text-white/40">BPM</span>
          </span>
        )}
        {m.tonalite && (
          <span className="px-2 py-0.5 rounded-md bg-white/[0.08] text-[11px] font-bold text-[#64D2FF]" title="Tonalité (Camelot)">
            {m.tonalite}
          </span>
        )}
        {m.dureeSec > 0 && <span className="text-[11px] text-white/40 w-9 text-right">{formatDuree(m.dureeSec)}</span>}
      </span>

      <span
        className="shrink-0 px-2 py-0.5 rounded-full text-[10px] font-bold"
        style={{ backgroundColor: `${src.couleur}26`, color: src.couleur }}
        title={m.ajoutePar ? `Proposé par ${m.ajoutePar}` : undefined}
      >
        {m.ajoutePar || src.libelle}
      </span>

      {onSupprimer && (
        <button
          type="button"
          onClick={() => onSupprimer(m)}
          title="Retirer ce morceau"
          aria-label={`Retirer ${m.titre}`}
          className="shrink-0 h-7 w-7 inline-flex items-center justify-center rounded-full text-white/30 hover:text-[#FF453A] hover:bg-white/10 transition-colors"
        >
          <Trash2 className="h-3.5 w-3.5" />
        </button>
      )}
    </li>
  );
}