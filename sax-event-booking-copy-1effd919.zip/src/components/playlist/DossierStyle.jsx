import React, { useState } from "react";
import { Folder, ChevronDown } from "lucide-react";
import MorceauLigne from "@/components/playlist/MorceauLigne";

export default function DossierStyle({ style, morceaux, onSupprimer }) {
  const [ouvert, setOuvert] = useState(true);

  return (
    <div className="rounded-2xl bg-white/[0.06] overflow-hidden">
      <button
        type="button"
        onClick={() => setOuvert(!ouvert)}
        aria-expanded={ouvert}
        className="w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-white/[0.04] transition-colors"
      >
        <Folder className="h-4 w-4 text-white/50 shrink-0" />
        <span className="flex-1 text-sm font-semibold text-white">{style}</span>
        <span className="text-xs text-white/40">{morceaux.length}</span>
        <ChevronDown className={`h-4 w-4 text-white/40 transition-transform ${ouvert ? "rotate-180" : ""}`} />
      </button>
      {ouvert && (
        <ul className="border-t border-white/10">
          {morceaux.map((m) => (
            <MorceauLigne key={m.id} morceau={m} onSupprimer={onSupprimer} />
          ))}
        </ul>
      )}
    </div>
  );
}