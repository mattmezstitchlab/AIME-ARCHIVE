import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { SOURCES_PLAYLIST, grouperParStyle } from "@/lib/playlist";
import DossierStyle from "@/components/playlist/DossierStyle";
import FormulaireMorceau from "@/components/playlist/FormulaireMorceau";
import ImportAudio from "@/components/playlist/ImportAudio";
import { rechercherITunes, estimerBpmEtTonalite } from "@/lib/analyseMorceaux";
import { stopperLecture } from "@/lib/lecteurApercu";
import { Link2, Check, FolderInput, Gauge } from "lucide-react";

export default function PlaylistEvenement({ evenement, ouvrirFormulaire }) {
  const [morceaux, setMorceaux] = useState(null);
  const [filtre, setFiltre] = useState("tous");
  const [copie, setCopie] = useState(false);
  const [importation, setImportation] = useState(false);
  const [analyse, setAnalyse] = useState(null);

  const charger = () =>
    base44.entities.PlaylistMorceau.filter({ evenementId: evenement.id }, "-created_date", 500).then(setMorceaux);

  useEffect(() => {
    charger();
    // Playlist vivante : les propositions des invités et du DJ apparaissent en direct chez tout le monde.
    const unsubscribe = base44.entities.PlaylistMorceau.subscribe((ev) => {
      if (ev.data?.evenementId === evenement.id || ev.type === "delete") charger();
    });
    return () => {
      unsubscribe();
      stopperLecture();
    };
  }, [evenement.id]);

  // Analyse façon DJ : extrait, pochette, durée, genre (iTunes) + BPM et tonalité (IA).
  const analyserPlaylist = async () => {
    if (analyse) return;
    const aAnalyser = (morceaux || []).filter((m) => !m.previewUrl || !m.bpm);
    if (aAnalyser.length === 0) return;
    setAnalyse(`0/${aAnalyser.length}`);
    try {
      const patches = {};
      let fait = 0;
      for (const m of aAnalyser) {
        if (!m.previewUrl) {
          const infos = await rechercherITunes(m.titre, m.artiste).catch(() => null);
          if (infos) patches[m.id] = { ...infos };
        }
        fait += 1;
        setAnalyse(`${fait}/${aAnalyser.length}`);
      }
      const sansBpm = aAnalyser.filter((m) => !m.bpm);
      if (sansBpm.length > 0) {
        setAnalyse("BPM…");
        const parIndex = await estimerBpmEtTonalite(sansBpm);
        sansBpm.forEach((m, i) => {
          if (parIndex[i]) patches[m.id] = { ...(patches[m.id] || {}), ...parIndex[i] };
        });
      }
      const maj = Object.entries(patches).map(([id, data]) => ({ id, ...data }));
      if (maj.length > 0) await base44.entities.PlaylistMorceau.bulkUpdate(maj);
      await charger();
    } finally {
      setAnalyse(null);
    }
  };

  const ajouter = async (m) => {
    await base44.entities.PlaylistMorceau.create({
      ...m,
      evenementId: evenement.id,
      proprietaire: evenement.proprietaire,
    });
    charger();
  };

  const supprimer = async (m) => {
    await base44.entities.PlaylistMorceau.delete(m.id);
    setMorceaux((l) => l.filter((x) => x.id !== m.id));
  };

  // Verse le répertoire du profil (styles + morceaux) dans la playlist, sans doublons.
  const importerRepertoire = async () => {
    if (importation) return;
    setImportation(true);
    try {
      const styles = await base44.entities.StyleRepertoire.list();
      const existants = new Set((morceaux || []).map((m) => m.titre.toLowerCase()));
      const nouveaux = [];
      for (const s of styles) {
        for (const brut of s.morceaux || []) {
          const [titre, artiste = ""] = String(brut).split(/\s+[–—-]\s+/);
          if (!titre?.trim() || existants.has(titre.trim().toLowerCase())) continue;
          existants.add(titre.trim().toLowerCase());
          nouveaux.push({
            evenementId: evenement.id,
            proprietaire: evenement.proprietaire,
            titre: titre.trim(),
            artiste: artiste.trim(),
            style: s.titre,
            source: "prestataire",
          });
        }
      }
      if (nouveaux.length > 0) await base44.entities.PlaylistMorceau.bulkCreate(nouveaux);
      await charger();
    } finally {
      setImportation(false);
    }
  };

  const copierLien = async () => {
    await navigator.clipboard.writeText(`${window.location.origin}/playlist/${evenement.id}`);
    setCopie(true);
    setTimeout(() => setCopie(false), 2000);
  };

  const liste = morceaux || [];
  const filtres = filtre === "tous" ? liste : liste.filter((m) => m.source === filtre);
  const dossiers = grouperParStyle(filtres);
  const compteParSource = (cle) => liste.filter((m) => m.source === cle).length;

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h3 className="text-lg font-semibold text-white">Playlist collaborative</h3>
          <p className="text-xs text-white/45 mt-0.5">
            Mariés, invités et DJ alimentent la même playlist, classée en dossiers par style — sans rendez-vous.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <ImportAudio evenement={evenement} onFait={charger} />
          <button
            type="button"
            onClick={analyserPlaylist}
            disabled={!!analyse || !morceaux}
            title="Récupérer BPM, tonalité, durée, pochette et extrait pour chaque morceau"
            className="inline-flex items-center gap-2 min-h-[40px] px-4 rounded-full bg-white/10 text-sm font-semibold text-white hover:bg-white/20 disabled:opacity-50 transition-colors"
          >
            <Gauge className="h-4 w-4" />
            {analyse ? `Analyse ${analyse}` : "Analyser (BPM, extraits…)"}
          </button>
          <button
            type="button"
            onClick={importerRepertoire}
            disabled={importation}
            className="inline-flex items-center gap-2 min-h-[40px] px-4 rounded-full bg-white/10 text-sm font-semibold text-white hover:bg-white/20 disabled:opacity-50 transition-colors"
          >
            <FolderInput className="h-4 w-4" />
            {importation ? "Import en cours…" : "Importer mon répertoire"}
          </button>
          <button
            type="button"
            onClick={copierLien}
            className="inline-flex items-center gap-2 min-h-[40px] px-4 rounded-full bg-white/10 text-sm font-semibold text-white hover:bg-white/20 transition-colors"
          >
            {copie ? <Check className="h-4 w-4 text-[#30D158]" /> : <Link2 className="h-4 w-4" />}
            {copie ? "Lien copié !" : "Lien pour les invités"}
          </button>
        </div>
      </div>

      <FormulaireMorceau onAjouter={ajouter} focusDemande={ouvrirFormulaire} />

      {/* Filtre par source */}
      <div className="flex flex-wrap gap-2" role="tablist" aria-label="Filtrer la playlist">
        <button
          type="button"
          onClick={() => setFiltre("tous")}
          className={`min-h-[34px] px-3.5 rounded-full text-xs font-bold transition-colors ${
            filtre === "tous" ? "bg-gradient-to-r from-[#BF5AF2] to-[#0A84FF] text-white" : "bg-white/[0.08] text-white/70 hover:bg-white/15"
          }`}
        >
          Tous ({liste.length})
        </button>
        {Object.entries(SOURCES_PLAYLIST).map(([cle, s]) => (
          <button
            key={cle}
            type="button"
            onClick={() => setFiltre(cle)}
            className={`min-h-[34px] px-3.5 rounded-full text-xs font-bold transition-colors ${
              filtre === cle ? "text-black" : "bg-white/[0.08] text-white/60 hover:bg-white/15"
            }`}
            style={filtre === cle ? { backgroundColor: s.couleur, color: "#fff" } : undefined}
          >
            {s.libelle} ({compteParSource(cle)})
          </button>
        ))}
      </div>

      {morceaux === null ? (
        <p className="text-sm text-white/40">Chargement de la playlist…</p>
      ) : dossiers.length === 0 ? (
        <p className="text-sm text-white/40">
          Aucun morceau pour l'instant — ajoutez les premiers ou partagez le lien aux invités.
        </p>
      ) : (
        <div className="grid gap-3 md:grid-cols-2">
          {dossiers.map(([style, items]) => (
            <DossierStyle key={style} style={style} morceaux={items} onSupprimer={supprimer} />
          ))}
        </div>
      )}

    </div>
  );
}