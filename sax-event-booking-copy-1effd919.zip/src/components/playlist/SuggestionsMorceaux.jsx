import React, { useState, useEffect, useRef } from "react";
import { Play, Pause } from "lucide-react";

// Recherche de morceaux sur le web (catalogue iTunes) avec extrait de 30 s écoutable.
export default function SuggestionsMorceaux({ recherche, onChoisir }) {
  const [resultats, setResultats] = useState([]);
  const [enLecture, setEnLecture] = useState(null);
  const audioRef = useRef(null);

  useEffect(() => {
    if (!recherche || recherche.trim().length < 3) {
      setResultats([]);
      return;
    }
    const t = setTimeout(() => {
      fetch(`https://itunes.apple.com/search?term=${encodeURIComponent(recherche)}&media=music&limit=5&country=FR`)
        .then((r) => r.json())
        .then((json) => setResultats(json.results || []))
        .catch(() => setResultats([]));
    }, 400);
    return () => clearTimeout(t);
  }, [recherche]);

  // Coupe l'extrait quand le composant disparaît.
  useEffect(() => () => audioRef.current?.pause(), []);

  const basculerEcoute = (r) => {
    if (enLecture === r.trackId) {
      audioRef.current?.pause();
      setEnLecture(null);
      return;
    }
    if (!audioRef.current) audioRef.current = new Audio();
    audioRef.current.src = r.previewUrl;
    audioRef.current.onended = () => setEnLecture(null);
    audioRef.current.play();
    setEnLecture(r.trackId);
  };

  if (resultats.length === 0) return null;

  return (
    <div className="absolute left-0 right-0 top-full mt-1 z-30 rounded-xl bg-[#1C1C1E] border border-white/10 shadow-2xl overflow-hidden">
      {resultats.map((r) => (
        <div key={r.trackId} className="flex items-center gap-3 px-3 py-2 hover:bg-white/[0.06] transition-colors">
          {r.artworkUrl60 && <img src={r.artworkUrl60} alt="" className="h-9 w-9 rounded-md shrink-0" />}
          <button
            type="button"
            onClick={() => onChoisir({ titre: r.trackName, artiste: r.artistName, style: r.primaryGenreName || "" })}
            className="flex-1 min-w-0 text-left"
          >
            <span className="block text-sm text-white truncate">{r.trackName}</span>
            <span className="block text-xs text-white/45 truncate">{r.artistName}{r.primaryGenreName ? ` · ${r.primaryGenreName}` : ""}</span>
          </button>
          {r.previewUrl && (
            <button
              type="button"
              onClick={() => basculerEcoute(r)}
              title={enLecture === r.trackId ? "Arrêter l'extrait" : "Écouter un extrait"}
              aria-label={enLecture === r.trackId ? "Arrêter l'extrait" : `Écouter un extrait de ${r.trackName}`}
              className="h-8 w-8 shrink-0 inline-flex items-center justify-center rounded-full bg-white/10 text-white hover:bg-white/20 transition-colors"
            >
              {enLecture === r.trackId ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
            </button>
          )}
        </div>
      ))}
    </div>
  );
}