import React, { useRef, useState } from "react";
import { base44 } from "@/api/base44Client";
import { FileAudio, Loader2 } from "lucide-react";

// Bouton d'import de fichiers audio (mp3, wav…) versés directement dans la playlist.
export default function ImportAudio({ evenement, onFait }) {
  const refInput = useRef(null);
  const [envoi, setEnvoi] = useState(null);

  const importer = async (e) => {
    const fichiers = Array.from(e.target.files || []);
    if (fichiers.length === 0) return;
    setEnvoi(`0/${fichiers.length}`);
    try {
      let fait = 0;
      for (const fichier of fichiers) {
        const { file_url } = await base44.integrations.Core.UploadFile({ file: fichier });
        await base44.entities.PlaylistMorceau.create({
          evenementId: evenement.id,
          proprietaire: evenement.proprietaire,
          titre: fichier.name.replace(/\.[^.]+$/, ""),
          style: "Fichiers importés",
          source: "dj",
          fichierAudioUrl: file_url,
        });
        fait += 1;
        setEnvoi(`${fait}/${fichiers.length}`);
      }
      onFait?.();
    } finally {
      setEnvoi(null);
      if (refInput.current) refInput.current.value = "";
    }
  };

  return (
    <>
      <input ref={refInput} type="file" accept="audio/*" multiple onChange={importer} className="hidden" aria-hidden="true" />
      <button
        type="button"
        onClick={() => refInput.current?.click()}
        disabled={!!envoi}
        className="inline-flex items-center gap-2 min-h-[40px] px-4 rounded-full bg-white/10 text-sm font-semibold text-white hover:bg-white/20 disabled:opacity-50 transition-colors"
      >
        {envoi ? <Loader2 className="h-4 w-4 animate-spin" /> : <FileAudio className="h-4 w-4" />}
        {envoi ? `Import ${envoi}` : "Importer un fichier audio"}
      </button>
    </>
  );
}