import React, { useEffect, useRef, useState } from "react";
import { Plus } from "lucide-react";
import { SOURCES_PLAYLIST, STYLES_SUGGERES } from "@/lib/playlist";
import { classeInputOs, classeBoutonOs } from "@/components/evenements/stylesOs";
import SuggestionsMorceaux from "@/components/playlist/SuggestionsMorceaux";

export default function FormulaireMorceau({ onAjouter, focusDemande }) {
  const titreRef = useRef(null);
  const [titre, setTitre] = useState("");
  const [artiste, setArtiste] = useState("");
  const [style, setStyle] = useState("");
  const [source, setSource] = useState("marie");
  const [recherche, setRecherche] = useState("");
  const [envoi, setEnvoi] = useState(false);

  useEffect(() => {
    if (!focusDemande) return;
    titreRef.current?.scrollIntoView({ block: "center" });
    titreRef.current?.focus();
  }, [focusDemande]);

  const choisirSuggestion = (m) => {
    setTitre(m.titre);
    setArtiste(m.artiste);
    if (m.style) setStyle(m.style);
    setRecherche("");
  };

  const soumettre = async (e) => {
    e.preventDefault();
    if (!titre.trim() || envoi) return;
    setEnvoi(true);
    await onAjouter({ titre: titre.trim(), artiste: artiste.trim(), style: style.trim(), source });
    setTitre("");
    setArtiste("");
    setRecherche("");
    setEnvoi(false);
  };

  return (
    <form onSubmit={soumettre} className="grid gap-2 sm:grid-cols-[1.2fr_1fr_1fr_auto_auto]">
      <div className="relative">
        <input
          ref={titreRef}
          aria-label="Titre du morceau"
          value={titre}
          onChange={(e) => { setTitre(e.target.value); setRecherche(e.target.value); }}
          onBlur={() => setTimeout(() => setRecherche(""), 200)}
          placeholder="Titre du morceau *"
          required
          className={classeInputOs}
        />
        <SuggestionsMorceaux recherche={recherche} onChoisir={choisirSuggestion} />
      </div>
      <input value={artiste} onChange={(e) => setArtiste(e.target.value)} placeholder="Artiste" className={classeInputOs} />
      <input value={style} onChange={(e) => setStyle(e.target.value)} placeholder="Style / dossier" list="styles-playlist" className={classeInputOs} />
      <datalist id="styles-playlist">
        {STYLES_SUGGERES.map((s) => <option key={s} value={s} />)}
      </datalist>
      <select value={source} onChange={(e) => setSource(e.target.value)} aria-label="Qui propose ce morceau" className={classeInputOs}>
        {Object.entries(SOURCES_PLAYLIST).map(([cle, s]) => (
          <option key={cle} value={cle}>{s.libelle}</option>
        ))}
      </select>
      <button type="submit" disabled={envoi} className={classeBoutonOs}>
        <Plus className="h-4 w-4" /> Ajouter
      </button>
    </form>
  );
}