import React, { useState, useRef, useEffect } from "react";
import { CATEGORIES_DOCUMENTS, TYPES_DOCUMENTS } from "@/lib/typesDocuments";
import { ChevronDown, Check } from "lucide-react";

export default function BibliothequeDocuments({ type, onChange }) {
  const [ouvert, setOuvert] = useState(false);
  const conteneur = useRef(null);
  const actuel = TYPES_DOCUMENTS[type];

  // Fermeture au clic extérieur — sans voile plein écran qui peut intercepter les clics.
  useEffect(() => {
    if (!ouvert) return;
    const fermerSiDehors = (e) => {
      if (conteneur.current && !conteneur.current.contains(e.target)) setOuvert(false);
    };
    document.addEventListener("pointerdown", fermerSiDehors);
    return () => document.removeEventListener("pointerdown", fermerSiDehors);
  }, [ouvert]);

  const choisir = (cle) => {
    onChange(cle);
    setOuvert(false);
  };

  return (
    <div className="relative" ref={conteneur}>
      <button
        type="button"
        onClick={() => setOuvert(!ouvert)}
        aria-expanded={ouvert}
        aria-haspopup="listbox"
        className="inline-flex min-h-[44px] items-center gap-2 rounded-full bg-gradient-to-r from-[#BF5AF2] to-[#0A84FF] px-5 text-sm font-bold text-white transition-opacity hover:opacity-90"
      >
        {actuel?.libelle || "Choisir un document"}
        <ChevronDown className={`h-4 w-4 transition-transform ${ouvert ? "rotate-180" : ""}`} />
      </button>

      {ouvert && (
        <div
          role="listbox"
          aria-label="Types de documents"
          className="absolute left-0 top-full z-50 mt-2 max-h-[420px] w-[min(320px,calc(100vw-2rem))] max-w-full overflow-y-auto rounded-2xl border border-white/15 bg-[#111114] p-2 text-white shadow-2xl"
        >
          <p className="px-3 pt-2 pb-1 text-[11px] font-bold uppercase tracking-wide text-[#8A7356]">
            Bibliothèque — documents du spectacle français
          </p>
          {CATEGORIES_DOCUMENTS.map((cat) => (
            <div key={cat.id} className="pb-1">
              <p className="px-3 pb-1 pt-2 text-xs font-semibold text-white/65">{cat.libelle}</p>
              {cat.types.map((cle) => {
                const t = TYPES_DOCUMENTS[cle];
                const actif = cle === type;
                return (
                  <button
                    key={cle}
                    type="button"
                    role="option"
                    aria-selected={actif}
                    onPointerDown={(e) => { e.preventDefault(); choisir(cle); }}
                    onClick={() => choisir(cle)}
                    className={`w-full flex items-start gap-2 text-left px-3 py-2 rounded-xl transition-colors ${
                      actif ? "bg-gradient-to-r from-[#BF5AF2] to-[#0A84FF] text-white" : "text-white/85 hover:bg-white/10"
                    }`}
                  >
                    <span className="flex-1">
                      <span className="block text-sm font-medium">{t.libelle}</span>
                      <span className={`block text-[11px] ${actif ? "text-white/80" : "text-white/55"}`}>{t.description}</span>
                    </span>
                    {actif && <Check className="h-4 w-4 mt-1 shrink-0" />}
                  </button>
                );
              })}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}