import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { FONDS } from "@/lib/designsDocuments";
import { TYPES_DOCUMENTS } from "@/lib/typesDocuments";
import { genererDevis, genererFacture, genererContrat, genererDocumentAdministratif } from "@/lib/documentsPdf";
import ApercuDevis from "@/components/documents/ApercuDevis";
import BibliothequeDocuments from "@/components/documents/BibliothequeDocuments";
import PanneauStudioDocument from "@/components/documents/PanneauStudioDocument";
import { X, Loader2, Pencil } from "lucide-react";

const CHAMPS_ENTREPRISE = [
  "nomScene", "nomLegal", "siret", "tva", "adresse", "ville",
  "telephone", "email", "banque", "iban", "bic", "chequeOrdre",
];

export default function StudioDocument({ email, onFermer, valeursInitiales, onGenere, evenementId }) {
  const [type, setType] = useState(valeursInitiales?.type && TYPES_DOCUMENTS[valeursInitiales.type] ? valeursInitiales.type : "devis");
  const [v, setV] = useState({
    ...Object.fromEntries(CHAMPS_ENTREPRISE.map((c) => [c, ""])),
    fondDocument: "floral",
  });
  const [idExistant, setIdExistant] = useState(null);
  const [charge, setCharge] = useState(false);
  const [panneauOuvert, setPanneauOuvert] = useState(!!valeursInitiales);
  const [enCours, setEnCours] = useState(false);
  const [erreur, setErreur] = useState("");
  const [d, setD] = useState({
    clientNom: valeursInitiales?.clientNom || "",
    clientAdresse: valeursInitiales?.clientAdresse || "",
    clientTelephone: valeursInitiales?.clientTelephone || "",
    clientEmail: valeursInitiales?.clientEmail || "",
    description: valeursInitiales?.description || "Représentation saxophone",
    dateEvenement: valeursInitiales?.dateEvenement || "",
    heureDebut: valeursInitiales?.heureDebut || "",
    heureFin: valeursInitiales?.heureFin || "",
    lieu: valeursInitiales?.lieu || "",
    montant: valeursInitiales?.montant || "",
  });

  useEffect(() => {
    base44.entities.InformationsEntreprise.filter({ proprietaire: email }, "-updated_date", 1).then((liste) => {
      if (liste[0]) {
        setIdExistant(liste[0].id);
        setV((prev) => ({
          ...prev,
          ...Object.fromEntries(Object.entries(liste[0]).filter(([cle, val]) => cle in prev && val)),
        }));
      }
      setCharge(true);
    });
  }, [email]);

  const majV = (cle, valeur) => setV((prev) => ({ ...prev, [cle]: valeur }));
  const majD = (cle, valeur) => { setErreur(""); setD((prev) => ({ ...prev, [cle]: valeur })); };

  const enregistrerInfos = async () => {
    if (idExistant) {
      await base44.entities.InformationsEntreprise.update(idExistant, v);
    } else {
      const cree = await base44.entities.InformationsEntreprise.create({ proprietaire: email, ...v });
      setIdExistant(cree.id);
    }
  };

  const generer = async () => {
    setErreur("");
    const typeDef = TYPES_DOCUMENTS[type];
    if (!d.clientNom.trim()) { setErreur("Le nom du client est obligatoire."); return; }
    if (typeDef.avecMontant && (!d.montant || Number(d.montant) <= 0)) { setErreur("Le montant doit être supérieur à 0."); return; }
    setEnCours(true);
    try {
      // Le numéro est attribué par le serveur (unicité garantie), puis le PDF est généré avec ce numéro.
      const creation = await base44.functions.invoke("enregistrerDocument", {
        action: "creer",
        prefixe: typeDef.prefixe,
        document: {
          type,
          clientNom: d.clientNom, clientAdresse: d.clientAdresse,
          clientTelephone: d.clientTelephone,
          clientEmail: d.clientEmail.trim().toLowerCase(),
          description: d.description, dateEvenement: d.dateEvenement || undefined,
          heureDebut: d.heureDebut, heureFin: d.heureFin, lieu: d.lieu,
          montant: Number(d.montant) || 0,
          ...(evenementId ? { evenementId } : {}),
        },
      });
      const { id, numero } = creation.data;
      const dateEmission = creation.data.dateEmission || new Date().toISOString().slice(0, 10);

      const donnees = {
        numero,
        dateEmission,
        client: { nom: d.clientNom, adresse: d.clientAdresse, telephone: d.clientTelephone, email: d.clientEmail },
        description: d.description,
        dateEvenement: d.dateEvenement,
        heureDebut: d.heureDebut,
        heureFin: d.heureFin,
        lieu: d.lieu,
        montant: Number(d.montant),
      };

      let resultat;
      if (type === "devis") resultat = await genererDevis(donnees, v);
      else if (type === "facture") resultat = await genererFacture(donnees, v);
      else if (type === "contrat") resultat = await genererContrat(donnees, v);
      else resultat = await genererDocumentAdministratif(donnees, v, type);

      const pdfBase64 = resultat.doc.output("datauristring").split(",")[1];
      await base44.functions.invoke("enregistrerDocument", {
        action: "joindrePdf",
        id,
        pdfBase64,
        nomFichier: resultat.nomFichier,
      });
      resultat.doc.save(resultat.nomFichier);
      onGenere?.();
      onFermer?.();
    } catch (e) {
      const detail = e?.response?.data?.message || e?.response?.data?.error || e?.message || "";
      setErreur(`Une erreur est survenue lors de la génération. ${detail ? `Détail : ${detail}` : ""}`);
      console.error(e);
    } finally {
      setEnCours(false);
    }
  };

  const fondChoisi = FONDS[v.fondDocument || "floral"] || FONDS.floral;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-[#050506]">
      <div className="fixed inset-0 bg-cover bg-center transition-all duration-500" style={{ backgroundImage: `url(${fondChoisi.url})` }} aria-hidden="true" />
      <div className="fixed inset-0 bg-black/75" aria-hidden="true" />

      <div className="relative max-w-3xl mx-auto px-3 md:px-6 py-6 md:py-10">
        <div className="mb-6 flex min-w-0 items-start justify-between gap-3">
          <div className="flex min-w-0 flex-1 flex-wrap items-center gap-2">
            <BibliothequeDocuments type={type} onChange={setType} />
            <button
              onClick={() => setPanneauOuvert(true)}
              className="inline-flex items-center gap-2 min-h-[44px] px-5 rounded-full text-sm font-bold shadow-lg hover:opacity-90 transition-opacity"
              style={{ backgroundColor: "#141416", color: "#FFFFFF" }}
            >
              <Pencil className="h-4 w-4" /> Modifier
            </button>
          </div>
          <button
            onClick={onFermer}
            aria-label="Fermer le studio de documents"
            className="h-11 w-11 shrink-0 rounded-full shadow flex items-center justify-center hover:opacity-90 transition-opacity"
            style={{ backgroundColor: "#141416", color: "#FFFFFF" }}
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <p className="mb-4 text-xs font-medium text-white/90 drop-shadow max-w-[560px] mx-auto">
          {TYPES_DOCUMENTS[type].description}
          {TYPES_DOCUMENTS[type].preparatoire && " — document préparatoire, ne remplace pas la déclaration officielle"}
          {!TYPES_DOCUMENTS[type].avecMontant && " — ce document ne comporte pas de montant"}
        </p>

        {/* Document mis en page en direct */}
        <div className="relative w-full max-w-[560px] mx-auto">
          {!charge ? (
            <div className="rounded-lg shadow-2xl w-full aspect-[210/297] flex items-center justify-center" style={{ backgroundColor: "#FFFFFF" }}>
              <Loader2 className="h-8 w-8 animate-spin" style={{ color: "#1D1D1F" }} />
            </div>
          ) : (
            <ApercuDevis v={v} d={d} type={TYPES_DOCUMENTS[type]} />
          )}
        </div>
      </div>

      {panneauOuvert && (
        <PanneauStudioDocument
          type={type}
          d={d}
          majD={majD}
          v={v}
          majV={majV}
          enregistrerInfos={enregistrerInfos}
          generer={generer}
          enCours={enCours}
          erreur={erreur}
          onFermer={() => setPanneauOuvert(false)}
        />
      )}
    </div>
  );
}