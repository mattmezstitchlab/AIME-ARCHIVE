import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { FONDS } from "@/lib/designsDocuments";
import { TYPES_DOCUMENTS } from "@/lib/typesDocuments";
import ApercuDevis from "@/components/documents/ApercuDevis";
import { X, Loader2, Check, Pencil } from "lucide-react";

// Un exemple représentatif de chaque famille, pour prévisualiser son habillage.
const FAMILLES_APERCU = [
  ["Devis & factures", "devis"],
  ["Contrats", "contrat"],
  ["Cachets & spectacle", "recuCachet"],
  ["Déclarations", "aem"],
];

const CHAMPS = [
  ["nomScene", "Nom commercial / de scène"],
  ["nomLegal", "Nom légal / raison sociale"],
  ["siret", "SIRET"],
  ["tva", "Mention TVA"],
  ["adresse", "Adresse"],
  ["ville", "Code postal et ville"],
  ["telephone", "Téléphone"],
  ["email", "E-mail"],
  ["banque", "Banque"],
  ["iban", "IBAN"],
  ["bic", "BIC"],
  ["chequeOrdre", "Chèque à l'ordre de"],
];

const VIDE = Object.fromEntries(CHAMPS.map(([cle]) => [cle, ""]));

const classeSelect =
  "mt-1 min-h-[44px] w-full rounded-xl border border-black/15 px-3 text-sm focus:outline-none focus:border-black";
const classeInput =
  "mt-1 min-h-[42px] w-full rounded-lg border border-black/15 px-3 text-sm focus:outline-none focus:border-black";
const styleChamp = { backgroundColor: "#FFFFFF", color: "#1B1B1F" };

function Deroulant({ libelle, valeur, options, onChange }) {
  return (
    <div>
      <label className="text-xs font-bold uppercase tracking-wide" style={{ color: "#5B5B60" }}>{libelle}</label>
      <select className={classeSelect} style={styleChamp} value={valeur} onChange={(e) => onChange(e.target.value)}>
        {options.map(([cle, texte]) => <option key={cle} value={cle}>{texte}</option>)}
      </select>
    </div>
  );
}

export default function EditeurDocument({ email, onFermer }) {
  // Style unique : typographie du site, texte noir — plus de choix de couleur ni de police.
  const [v, setV] = useState({ ...VIDE, styleDocument: "moderne", fondDocument: "floral", typographie: "moderne" });
  const [idExistant, setIdExistant] = useState(null);
  const [charge, setCharge] = useState(false);
  const [enregistrement, setEnregistrement] = useState(false);
  const [sauve, setSauve] = useState(false);
  const [panneauOuvert, setPanneauOuvert] = useState(false);
  const [famille, setFamille] = useState("devis");

  useEffect(() => {
    base44.entities.InformationsEntreprise.filter({ proprietaire: email }, "-updated_date", 1).then((liste) => {
      if (liste[0]) {
        setIdExistant(liste[0].id);
        setV((prev) => ({
          ...prev,
          ...Object.fromEntries(
            Object.entries(liste[0]).filter(
              ([cle, valeur]) => cle in prev && valeur && cle !== "styleDocument" && cle !== "typographie"
            )
          ),
        }));
      }
      setCharge(true);
    });
  }, [email]);

  const maj = (cle) => (valeurOuEvenement) => {
    const valeur = valeurOuEvenement?.target ? valeurOuEvenement.target.value : valeurOuEvenement;
    setSauve(false);
    setV((prev) => ({ ...prev, [cle]: valeur }));
  };

  const enregistrer = async () => {
    setEnregistrement(true);
    if (idExistant) {
      await base44.entities.InformationsEntreprise.update(idExistant, v);
    } else {
      const cree = await base44.entities.InformationsEntreprise.create({ proprietaire: email, ...v });
      setIdExistant(cree.id);
    }
    setEnregistrement(false);
    setSauve(true);
  };

  const fondChoisi = FONDS[v.fondDocument || "floral"] || FONDS.floral;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="fixed inset-0 bg-cover bg-center transition-all duration-500" style={{ backgroundImage: `url(${fondChoisi.url})` }} aria-hidden="true" />
      <div className="fixed inset-0 bg-black/25" aria-hidden="true" />

      <div className="relative max-w-3xl mx-auto px-3 md:px-6 py-6 md:py-10">
        <div className="flex items-center justify-between mb-6">
          <button
            onClick={() => setPanneauOuvert(true)}
            className="inline-flex items-center gap-2 min-h-[44px] px-5 rounded-full text-sm font-bold shadow-lg hover:opacity-90 transition-opacity"
            style={{ backgroundColor: "#141416", color: "#FFFFFF" }}
          >
            <Pencil className="h-4 w-4" /> Modifier
          </button>
          <button
            onClick={onFermer}
            aria-label="Fermer l'éditeur"
            className="h-11 w-11 rounded-full shadow flex items-center justify-center hover:opacity-90 transition-opacity"
            style={{ backgroundColor: "#141416", color: "#FFFFFF" }}
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="flex flex-wrap gap-2 mb-4" role="tablist" aria-label="Prévisualiser une famille de documents">
          {FAMILLES_APERCU.map(([libelle, cle]) => (
            <button
              key={cle}
              type="button"
              role="tab"
              aria-selected={famille === cle}
              onClick={() => setFamille(cle)}
              className="min-h-[38px] px-4 rounded-full text-sm font-medium flex items-center shadow-sm hover:opacity-90 transition-opacity"
              style={famille === cle ? { backgroundColor: "#141416", color: "#FFFFFF" } : { backgroundColor: "rgba(255,255,255,0.85)", color: "#5B5B60" }}
            >
              {libelle}
            </button>
          ))}
        </div>

        {/* Document */}
        <div className="relative w-full max-w-[560px] mx-auto">
          {!charge ? (
            <div
              className="rounded-lg shadow-2xl w-full aspect-[210/297] flex items-center justify-center"
              style={{ backgroundColor: "#FFFFFF" }}
            >
              <Loader2 className="h-8 w-8 animate-spin" style={{ color: "#1D1D1F" }} />
            </div>
          ) : (
            <ApercuDevis v={v} type={TYPES_DOCUMENTS[famille]} />
          )}
        </div>
      </div>

      {/* Panneau latéral de modification */}
      {panneauOuvert && (
        <aside
          className="fixed inset-y-0 right-0 z-[60] w-full max-w-[400px] shadow-2xl overflow-y-auto p-5 md:p-6"
          style={{ backgroundColor: "#FFFFFF" }}
          aria-label="Modifier le document"
        >
          <div className="flex items-center justify-between mb-5">
            <h3 className="font-heading text-lg font-semibold" style={{ color: "#1B1B1F" }}>Modifier le document</h3>
            <button
              onClick={() => setPanneauOuvert(false)}
              aria-label="Fermer le panneau"
              className="h-10 w-10 rounded-full flex items-center justify-center hover:opacity-80 transition-opacity"
              style={{ backgroundColor: "#F0F0F2", color: "#1B1B1F" }}
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          <div className="space-y-4">
            <Deroulant
              libelle="Visuel derrière le document"
              valeur={v.fondDocument || "floral"}
              options={Object.entries(FONDS).map(([cle, f]) => [cle, f.libelle])}
              onChange={maj("fondDocument")}
            />

            <div className="h-px bg-black/10 my-2" />

            {CHAMPS.map(([cle, libelle]) => (
              <div key={cle}>
                <label className="text-xs font-bold uppercase tracking-wide" style={{ color: "#5B5B60" }}>{libelle}</label>
                <input className={classeInput} style={styleChamp} value={v[cle]} onChange={maj(cle)} />
              </div>
            ))}

            <button
              onClick={enregistrer}
              disabled={enregistrement}
              className="w-full min-h-[48px] rounded-full font-bold text-sm flex items-center justify-center gap-2 hover:opacity-90 disabled:opacity-70 transition-opacity"
              style={{ backgroundColor: "#141416", color: "#FFFFFF" }}
            >
              {enregistrement ? <Loader2 className="h-4 w-4 animate-spin" /> : sauve ? <Check className="h-4 w-4" /> : null}
              {sauve ? "Enregistré" : "Enregistrer"}
            </button>
            <p className="text-[11px] leading-relaxed" style={{ color: "#5B5B60" }}>
              Ces informations alimentent automatiquement tous vos documents PDF (devis, factures, contrats).
            </p>
          </div>
        </aside>
      )}
    </div>
  );
}