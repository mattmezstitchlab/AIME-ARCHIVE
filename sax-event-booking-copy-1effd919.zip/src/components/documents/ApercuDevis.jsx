import React from "react";

const LIBELLE = "text-[9px] font-bold uppercase tracking-[0.15em] text-[#6E6E73]";

const DEFAUT = { titrePdf: "DEVIS", libelle: "Devis", prefixe: "DEV", avecMontant: true };

function fmtDateFr(iso) {
  if (!iso) return "";
  const [a, m, j] = String(iso).split("-");
  return `${j}/${m}/${a}`;
}

export default function ApercuDevis({ v, d, type }) {
  const t = { ...DEFAUT, ...(type || {}) };
  const numero = `${t.prefixe}-2026-001`;
  const ou = (valeur, texte) => valeur || <span className="opacity-40 italic">{texte}</span>;
  const montant = d?.montant ? `${Number(d.montant).toLocaleString("fr-FR", { minimumFractionDigits: 2 })} €` : "500,00 €";
  const ligne = [
    d?.description || "Prestation pour votre événement",
    d?.dateEvenement ? fmtDateFr(d.dateEvenement) : "12/09/2026",
    d?.heureDebut ? `${d.heureDebut} – ${d.heureFin || ""}` : d?.dateEvenement || d?.description ? "" : "18:00 – 22:00",
  ].filter(Boolean).join(" · ");

  return (
    <div className="relative rounded-lg shadow-2xl w-full max-w-[560px] mx-auto aspect-[210/297] overflow-hidden select-none bg-white text-[#1D1D1F] font-body">
      <div className="relative h-full p-8 md:p-12 text-[10.5px] md:text-xs leading-relaxed flex flex-col">
        {/* En-tête : marque à gauche, numéro à droite */}
        <div className="flex items-start justify-between gap-4">
          <p className="font-heading text-sm md:text-base font-bold">{ou(v.nomScene, "Votre nom commercial")}</p>
          <p className="text-[#6E6E73]">{numero}</p>
        </div>
        <h1 className="mt-2 font-heading text-3xl md:text-5xl font-bold tracking-tight">{t.titrePdf || t.libelle.toUpperCase()}</h1>

        {/* Colonnes De / Client / Date */}
        <div className="mt-7 md:mt-10 grid grid-cols-3 gap-4">
          <div>
            <p className={LIBELLE}>De</p>
            <p className="mt-1.5 font-semibold">{ou(v.nomLegal, "Nom légal / raison sociale")}</p>
            <div className="mt-0.5 space-y-0.5 text-[#48484A]">
              <p>{ou(v.adresse, "Adresse")}</p>
              {v.ville && <p>{v.ville}</p>}
              <p>{ou(v.telephone, "Téléphone")}</p>
              <p>{ou(v.email, "E-mail")}</p>
              <p>SIRET {ou(v.siret, "n° SIRET")}</p>
            </div>
          </div>
          <div>
            <p className={LIBELLE}>Client</p>
            <p className="mt-1.5 font-semibold">{d?.clientNom || "Exemple Client"}</p>
            <p className="mt-0.5 text-[#48484A]">{d?.clientAdresse || (d?.clientNom ? "" : "1 rue des Fleurs, Lille")}</p>
          </div>
          <div className="text-right">
            <p className={LIBELLE}>Date</p>
            <p className="mt-1.5 font-semibold">{new Date().toLocaleDateString("fr-FR")}</p>
            <p className={`${LIBELLE} mt-3`}>{t.libelle}</p>
            <p className="mt-1.5 font-semibold">{numero}</p>
          </div>
        </div>

        {/* Prestation, alignée gauche / droite */}
        <div className="mt-8 md:mt-10 border-t border-black/10">
          <div className="flex justify-between gap-4 pt-2.5">
            <span className={LIBELLE}>Description</span>
            <span className={LIBELLE}>Montant</span>
          </div>
          <div className="flex justify-between gap-4 py-3.5 border-b border-black/10">
            <span className="text-[#48484A]">{ligne}</span>
            {t.avecMontant !== false && <span className="font-semibold shrink-0">{montant}</span>}
          </div>
        </div>

        {/* Totaux, à droite */}
        {t.avecMontant !== false && (
          <div className="mt-4 flex justify-end">
            <div className="w-[55%] md:w-1/2 space-y-1.5">
              <div className="flex justify-between text-[#48484A]"><span>Sous-total</span><span>{montant}</span></div>
              <div className="flex justify-between font-bold border-t border-black/20 pt-1.5">
                <span>{t.libelleMontant ? t.libelleMontant.charAt(0) + t.libelleMontant.slice(1).toLowerCase() : `Total ${t.libelle.toLowerCase()}`}</span>
                <span>{montant}</span>
              </div>
              {v.tva && <p className="text-right text-[#6E6E73]">{v.tva}</p>}
            </div>
          </div>
        )}

        {/* Pied de page */}
        <div className="mt-auto pt-6 space-y-3">
          <div>
            <p className={LIBELLE}>Modalités de règlement</p>
            <p className="mt-1 text-[#48484A]">
              Virement, espèces, chèques{v.chequeOrdre ? ` — chèque à l'ordre de ${v.chequeOrdre}` : ""}.
            </p>
            <p className="text-[#48484A]">
              Banque : {ou(v.banque, "banque")} — IBAN : {ou(v.iban, "IBAN")} — BIC : {ou(v.bic, "BIC")}
            </p>
          </div>
          {t.signatures ? (
            <div className="flex gap-8">
              {t.signatures.map((s) => (
                <p key={s} className="font-semibold">{s}</p>
              ))}
            </div>
          ) : (
            <p className="font-semibold">Bon pour accord (date et signature du client) :</p>
          )}
        </div>
      </div>
    </div>
  );
}