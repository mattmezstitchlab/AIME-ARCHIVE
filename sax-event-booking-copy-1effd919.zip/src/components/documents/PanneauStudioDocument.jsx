import React, { useState } from "react";
import { FONDS } from "@/lib/designsDocuments";
import { TYPES_DOCUMENTS } from "@/lib/typesDocuments";
import { X, Loader2, Check, FileDown, ChevronDown } from "lucide-react";

const classeInput =
  "mt-1 min-h-[42px] w-full rounded-lg border border-black/15 px-3 text-sm focus:outline-none focus:border-black";
const styleChamp = { backgroundColor: "#17171A", color: "#F5F5F7" };
const LIBELLE = "text-xs font-bold uppercase tracking-wide";

const CHAMPS_DOC = [
  ["clientNom", "Nom / société du client *"],
  ["clientAdresse", "Adresse du client"],
  ["clientTelephone", "Téléphone"],
  ["clientEmail", "E-mail"],
  ["description", "Description de la prestation"],
  ["dateEvenement", "Date de l'événement", "date"],
  ["heureDebut", "Début", "time"],
  ["heureFin", "Fin", "time"],
  ["lieu", "Lieu de la prestation"],
];

const CHAMPS_ENTREPRISE = [
  ["nomScene", "Nom commercial / de scène"],
  ["nomLegal", "Nom légal / raison sociale"],
  ["siret", "SIRET"],
  ["tva", "Mention TVA"],
  ["adresse", "Adresse"],
  ["ville", "Code postal et ville"],
  ["telephone", "Téléphone"],
  ["email", "E-mail"],
  ["banque", "Banque"],
  ["iban", "IBAN"],
  ["bic", "BIC"],
  ["chequeOrdre", "Chèque à l'ordre de"],
];

export default function PanneauStudioDocument({ type, d, majD, v, majV, enregistrerInfos, generer, enCours, erreur, onFermer }) {
  const [infosOuvertes, setInfosOuvertes] = useState(false);
  const [enregistrement, setEnregistrement] = useState(false);
  const [sauve, setSauve] = useState(false);
  const typeDef = TYPES_DOCUMENTS[type];

  const enregistrer = async () => {
    setEnregistrement(true);
    await enregistrerInfos();
    setEnregistrement(false);
    setSauve(true);
  };

  return (
    <aside
      className="fixed inset-y-0 right-0 z-[60] w-full max-w-[400px] overflow-y-auto p-5 pb-[calc(2rem+env(safe-area-inset-bottom))] shadow-2xl md:p-6"
      style={{ backgroundColor: "#0B0B0D" }}
      aria-label="Modifier le document"
    >
      <div className="flex items-center justify-between mb-5">
        <h3 className="font-heading text-lg font-semibold" style={{ color: "#F5F5F7" }}>Modifier le document</h3>
        <button
          onClick={onFermer}
          aria-label="Fermer le panneau"
          className="h-10 w-10 rounded-full flex items-center justify-center hover:opacity-80 transition-opacity"
          style={{ backgroundColor: "#1C1C1E", color: "#F5F5F7" }}
        >
          <X className="h-5 w-5" />
        </button>
      </div>

      {/* Contenu du document */}
      <div className="space-y-4">
        {CHAMPS_DOC.map(([cle, libelle, typeChamp]) => (
          <div key={cle}>
            <label htmlFor={`document-${cle}`} className={LIBELLE} style={{ color: "#A1A1A6" }}>{libelle}</label>
            <input
              id={`document-${cle}`}
              type={typeChamp || "text"}
              className={classeInput}
              style={styleChamp}
              value={d[cle]}
              onChange={(e) => majD(cle, e.target.value)}
            />
          </div>
        ))}
        {typeDef.avecMontant && (
          <div>
            <label htmlFor="document-montant" className={LIBELLE} style={{ color: "#A1A1A6" }}>
              {typeDef.libelleMontant ? `${typeDef.libelleMontant} (€) *` : "Montant (€) *"}
            </label>
            <input
              id="document-montant"
              type="number" min="0" step="0.01"
              className={classeInput}
              style={styleChamp}
              value={d.montant}
              onChange={(e) => majD("montant", e.target.value)}
            />
          </div>
        )}

        {erreur && <p className="text-sm" style={{ color: "#B3261E" }} role="alert">{erreur}</p>}

        <button
          onClick={generer}
          disabled={enCours}
          className="w-full min-h-[48px] rounded-full font-bold text-sm flex items-center justify-center gap-2 hover:opacity-90 disabled:opacity-70 transition-opacity"
          style={{ backgroundColor: "#141416", color: "#FFFFFF" }}
        >
          {enCours ? <Loader2 className="h-4 w-4 animate-spin" /> : <FileDown className="h-4 w-4" />}
          Générer — {typeDef.libelle} (PDF)
        </button>
      </div>

      {/* Mes informations & design */}
      <button
        onClick={() => setInfosOuvertes((o) => !o)}
        aria-expanded={infosOuvertes}
        className="mt-6 w-full flex items-center justify-between border-t border-black/10 pt-5 text-left"
      >
        <span className="font-heading text-base font-semibold" style={{ color: "#1B1B1F" }}>Mes informations & design</span>
        <ChevronDown className={`h-4 w-4 transition-transform ${infosOuvertes ? "rotate-180" : ""}`} style={{ color: "#A1A1A6" }} />
      </button>

      {infosOuvertes && (
        <div className="mt-4 space-y-4">
          <div>
            <label htmlFor="document-fond" className={LIBELLE} style={{ color: "#A1A1A6" }}>Visuel derrière le document</label>
            <select
              id="document-fond"
              className={`${classeInput} min-h-[44px] rounded-xl`}
              style={styleChamp}
              value={v.fondDocument || "floral"}
              onChange={(e) => { setSauve(false); majV("fondDocument", e.target.value); }}
            >
              {Object.entries(FONDS).map(([cle, f]) => <option key={cle} value={cle}>{f.libelle}</option>)}
            </select>
          </div>

          {CHAMPS_ENTREPRISE.map(([cle, libelle]) => (
            <div key={cle}>
              <label htmlFor={`entreprise-${cle}`} className={LIBELLE} style={{ color: "#A1A1A6" }}>{libelle}</label>
              <input
                id={`entreprise-${cle}`}
                className={classeInput}
                style={styleChamp}
                value={v[cle]}
                onChange={(e) => { setSauve(false); majV(cle, e.target.value); }}
              />
            </div>
          ))}

          <button
            onClick={enregistrer}
            disabled={enregistrement}
            className="w-full min-h-[48px] rounded-full font-bold text-sm flex items-center justify-center gap-2 hover:opacity-90 disabled:opacity-70 transition-opacity"
            style={{ backgroundColor: "#1C1C1E", color: "#F5F5F7" }}
          >
            {enregistrement ? <Loader2 className="h-4 w-4 animate-spin" /> : sauve ? <Check className="h-4 w-4" /> : null}
            {sauve ? "Enregistré" : "Enregistrer mes informations"}
          </button>
          <p className="text-[11px] leading-relaxed" style={{ color: "#A1A1A6" }}>
            Ces informations alimentent automatiquement tous vos documents PDF (devis, factures, contrats).
          </p>
        </div>
      )}
    </aside>
  );
}