import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Loader2, Trash2, HandHeart } from "lucide-react";
import FormulaireRessource, { CATEGORIES_RESSOURCE } from "@/components/ressources/FormulaireRessource";

const LIBELLES = Object.fromEntries(CATEGORIES_RESSOURCE);

// La ressourcerie du compte : ce que je prête, loue ou donne aux voisins.
export default function GestionRessources({ email }) {
  const [ressources, setRessources] = useState(null);

  const charger = async () => {
    setRessources(await base44.entities.RessourceLocale.filter({ proprietaire: email }, "-created_date", 200));
  };
  useEffect(() => { charger(); }, [email]);

  const basculer = async (r) => {
    await base44.entities.RessourceLocale.update(r.id, { disponible: !r.disponible });
    await charger();
  };
  const supprimer = async (r) => {
    await base44.entities.RessourceLocale.delete(r.id);
    await charger();
  };

  if (ressources === null) {
    return <div className="flex justify-center py-16"><Loader2 className="h-6 w-6 animate-spin text-[#8A7356]" /></div>;
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[1fr_1.2fr] gap-5 items-start">
      <FormulaireRessource email={email} onAjoute={charger} />

      <div className="space-y-3">
        <p className="text-sm text-[#57534E] flex items-center gap-2">
          <HandHeart className="h-4 w-4 text-[#8A7356]" aria-hidden="true" />
          Vos ressources disponibles apparaissent dans le fil « Autour de moi » des voisins. Moins d'achats, moins de route, plus d'entraide.
        </p>
        {ressources.length === 0 ? (
          <p className="text-sm text-[#57534E] rounded-2xl border border-dashed border-[#B49B72]/40 p-5">
            Rien pour l'instant. Une arche qui dort au garage, des chaises, un projecteur ? Proposez-les aux voisins.
          </p>
        ) : (
          ressources.map((r) => (
            <div key={r.id} className="flex items-center gap-4 rounded-2xl border border-[#B49B72]/25 bg-white p-4 shadow-sm">
              {r.photoUrl ? (
                <img src={r.photoUrl} alt={r.titre} className="h-14 w-14 rounded-lg object-cover shrink-0" />
              ) : (
                <div className="h-14 w-14 rounded-lg bg-[#FAF7F2] border border-[#B49B72]/30 shrink-0" aria-hidden="true" />
              )}
              <div className="min-w-0 flex-1">
                <p className="font-medium text-[#1C1917] truncate">{r.titre}</p>
                <p className="text-xs text-[#57534E]">
                  {LIBELLES[r.categorie] || "Autre"} — {r.modalite === "payant" ? (r.prix || "Payant") : "Prêt gratuit"}
                </p>
              </div>
              <button
                onClick={() => basculer(r)}
                aria-pressed={r.disponible}
                className={`min-h-[40px] px-4 rounded-full text-xs font-bold shrink-0 transition-colors ${
                  r.disponible
                    ? "bg-[#0A84FF]/10 text-[#0A84FF] border border-[#0A84FF]/30"
                    : "border border-[#B49B72]/40 text-[#57534E] hover:bg-[#FAF7F2]"
                }`}
              >
                {r.disponible ? "Disponible" : "Indisponible"}
              </button>
              <button
                onClick={() => supprimer(r)}
                aria-label={`Supprimer ${r.titre}`}
                className="h-10 w-10 rounded-full flex items-center justify-center text-[#57534E] hover:text-red-600 hover:bg-red-50 shrink-0"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  );
}