import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Loader2, ImagePlus } from "lucide-react";

export const CATEGORIES_RESSOURCE = [
  ["decoration", "Décoration"],
  ["materiel", "Matériel technique"],
  ["mobilier", "Mobilier"],
  ["espace", "Espace / stockage"],
  ["consommable", "Consommable"],
  ["autre", "Autre"],
];

// Formulaire d'ajout d'une ressource à prêter (gratuit) ou louer (payant).
export default function FormulaireRessource({ email, onAjoute }) {
  const [titre, setTitre] = useState("");
  const [description, setDescription] = useState("");
  const [categorie, setCategorie] = useState("decoration");
  const [modalite, setModalite] = useState("gratuit");
  const [prix, setPrix] = useState("");
  const [photoUrl, setPhotoUrl] = useState("");
  const [enCours, setEnCours] = useState(false);
  const [upload, setUpload] = useState(false);

  const televerser = async (e) => {
    const fichier = e.target.files?.[0];
    if (!fichier) return;
    setUpload(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file: fichier });
      setPhotoUrl(file_url);
    } finally { setUpload(false); }
  };

  const enregistrer = async (e) => {
    e.preventDefault();
    if (!titre.trim()) return;
    setEnCours(true);
    try {
      await base44.entities.RessourceLocale.create({
        proprietaire: email,
        titre: titre.trim(),
        description: description.trim(),
        categorie,
        modalite,
        prix: modalite === "payant" ? prix.trim() : "",
        photoUrl,
        disponible: true,
      });
      setTitre(""); setDescription(""); setPrix(""); setPhotoUrl("");
      onAjoute();
    } finally { setEnCours(false); }
  };

  const classChamp = "min-h-[44px] w-full rounded-lg border border-[#B49B72]/40 px-3 text-sm focus:outline-none focus:border-[#8A7356]";

  return (
    <form onSubmit={enregistrer} className="rounded-2xl border border-[#B49B72]/25 bg-white p-5 shadow-sm space-y-3">
      <h3 className="font-heading text-lg">Proposer une ressource</h3>
      <input value={titre} onChange={(e) => setTitre(e.target.value)} placeholder="Titre — ex. : Arche de cérémonie en bois" className={classChamp} />
      <textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Description, état, dimensions…" rows={2} className="w-full rounded-lg border border-[#B49B72]/40 px-3 py-2.5 text-sm resize-none focus:outline-none focus:border-[#8A7356]" />
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <select value={categorie} onChange={(e) => setCategorie(e.target.value)} aria-label="Catégorie" className={classChamp}>
          {CATEGORIES_RESSOURCE.map(([cle, lib]) => <option key={cle} value={cle}>{lib}</option>)}
        </select>
        <select value={modalite} onChange={(e) => setModalite(e.target.value)} aria-label="Modalité" className={classChamp}>
          <option value="gratuit">Prêt gratuit — entraide</option>
          <option value="payant">Payant — petite location</option>
        </select>
      </div>
      {modalite === "payant" && (
        <input value={prix} onChange={(e) => setPrix(e.target.value)} placeholder="Prix indicatif — ex. : 30 € le week-end" className={classChamp} />
      )}
      <div className="flex items-center gap-3">
        <label className="inline-flex items-center gap-2 min-h-[44px] px-4 rounded-full border border-[#B49B72]/40 text-sm cursor-pointer hover:bg-[#FAF7F2]">
          {upload ? <Loader2 className="h-4 w-4 animate-spin" /> : <ImagePlus className="h-4 w-4" aria-hidden="true" />}
          {photoUrl ? "Changer la photo" : "Ajouter une photo"}
          <input type="file" accept="image/*" onChange={televerser} className="sr-only" />
        </label>
        {photoUrl && <img src={photoUrl} alt="Aperçu de la ressource" className="h-11 w-11 rounded-lg object-cover" />}
      </div>
      <button
        type="submit"
        disabled={enCours || !titre.trim()}
        className="min-h-[48px] px-6 rounded-full bg-[#1C1917] text-[#FAF7F2] text-sm font-bold hover:bg-[#33302B] disabled:opacity-40 inline-flex items-center gap-2"
      >
        {enCours && <Loader2 className="h-4 w-4 animate-spin" />} Ajouter à ma ressourcerie
      </button>
    </form>
  );
}