import React, { useEffect, useRef, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Loader2, Plus, Trash2 } from "lucide-react";

const classeInput =
  "min-h-[40px] w-full rounded-lg border border-[#B49B72]/40 bg-white px-3 py-2 text-sm text-[#1C1917] focus:border-[#8A7356] focus:outline-none";

export default function GestionGalerie({ email }) {
  const [medias, setMedias] = useState([]);
  const [chargement, setChargement] = useState(true);
  const [envoi, setEnvoi] = useState(false);
  const fichierRef = useRef(null);

  const charger = async () => {
    const liste = await base44.entities.MediaGalerie.filter({ proprietaire: email }, "ordre", 100);
    setMedias(liste);
    setChargement(false);
  };

  useEffect(() => { charger(); }, [email]);

  const ajouter = async (ev) => {
    const fichier = ev.target.files?.[0];
    if (!fichier) return;
    setEnvoi(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file: fichier });
      await base44.entities.MediaGalerie.create({ proprietaire: email, url: file_url, legende: "", ordre: medias.length });
      await charger();
    } finally {
      setEnvoi(false);
      if (fichierRef.current) fichierRef.current.value = "";
    }
  };

  const modifierLegende = async (m, legende) => {
    await base44.entities.MediaGalerie.update(m.id, { legende });
  };

  const supprimer = async (m) => {
    await base44.entities.MediaGalerie.delete(m.id);
    setMedias((l) => l.filter((x) => x.id !== m.id));
  };

  if (chargement) return <Loader2 className="h-6 w-6 animate-spin text-[#8A7356] mx-auto my-10" />;

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <h3 className="font-heading text-lg">Photos de la galerie</h3>
        <label className="min-h-[42px] px-4 rounded-full bg-[#1C1917] text-[#FAF7F2] text-sm font-medium inline-flex items-center gap-2 cursor-pointer hover:bg-[#33302B]">
          {envoi ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
          Ajouter une photo
          <input ref={fichierRef} type="file" accept="image/*" className="hidden" onChange={ajouter} disabled={envoi} />
        </label>
      </div>
      {medias.length === 0 && <p className="text-sm text-[#57534E]">Aucune photo pour le moment.</p>}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {medias.map((m) => (
          <div key={m.id} className="rounded-xl border border-[#B49B72]/30 bg-white overflow-hidden">
            <img src={m.url} alt={m.legende || "Photo de la galerie"} className="h-36 w-full object-cover" />
            <div className="p-3 space-y-2">
              <input
                type="text" defaultValue={m.legende} placeholder="Légende…"
                aria-label="Légende de la photo"
                onBlur={(ev) => modifierLegende(m, ev.target.value)}
                className={classeInput}
              />
              <button onClick={() => supprimer(m)}
                className="text-xs text-[#B3261E] flex items-center gap-1 hover:underline">
                <Trash2 className="h-3.5 w-3.5" /> Supprimer
              </button>
            </div>
          </div>
        ))}
      </div>
      <p className="text-xs text-[#57534E]">La légende est enregistrée automatiquement quand vous quittez le champ.</p>
    </div>
  );
}