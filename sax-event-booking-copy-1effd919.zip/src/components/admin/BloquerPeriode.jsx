import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Loader2, CalendarRange } from "lucide-react";

// Bloquer une période entière (vacances, tournée…) en un seul geste.
export default function BloquerPeriode({ email, datesOccupees, onFait }) {
  const [ouvert, setOuvert] = useState(false);
  const [debut, setDebut] = useState("");
  const [fin, setFin] = useState("");
  const [motif, setMotif] = useState("");
  const [enCours, setEnCours] = useState(false);

  const bloquer = async () => {
    if (!debut || !fin || debut > fin) return;
    setEnCours(true);
    try {
      const dates = [];
      const d = new Date(`${debut}T12:00:00`);
      const limite = new Date(`${fin}T12:00:00`);
      while (d <= limite) {
        const cle = d.toISOString().slice(0, 10);
        if (!datesOccupees.has(cle)) dates.push(cle);
        d.setDate(d.getDate() + 1);
      }
      if (dates.length) {
        await base44.entities.DateBloquee.bulkCreate(
          dates.map((date) => ({ proprietaire: email, date, motif: motif || "Période bloquée" }))
        );
      }
      setOuvert(false);
      setDebut(""); setFin(""); setMotif("");
      onFait();
    } finally {
      setEnCours(false);
    }
  };

  if (!ouvert) {
    return (
      <button
        onClick={() => setOuvert(true)}
        className="inline-flex items-center gap-2 min-h-[40px] px-4 rounded-full border border-[#B49B72]/40 text-xs font-bold hover:bg-[#FAF7F2] transition-colors"
      >
        <CalendarRange className="h-3.5 w-3.5" /> Bloquer une période
      </button>
    );
  }

  const classeInput = "rounded-lg border border-[#B49B72]/40 bg-white px-3 py-2 text-sm focus:outline-none focus:border-[#8A7356]";

  return (
    <div className="rounded-2xl border border-[#B49B72]/25 bg-[#FAF7F2] p-4 flex flex-wrap items-end gap-3">
      <div className="flex flex-col gap-1">
        <label className="text-[10px] font-bold uppercase tracking-wide text-[#8A7356]" htmlFor="periode-debut">Du</label>
        <input id="periode-debut" type="date" value={debut} onChange={(e) => setDebut(e.target.value)} className={classeInput} />
      </div>
      <div className="flex flex-col gap-1">
        <label className="text-[10px] font-bold uppercase tracking-wide text-[#8A7356]" htmlFor="periode-fin">Au</label>
        <input id="periode-fin" type="date" value={fin} onChange={(e) => setFin(e.target.value)} min={debut} className={classeInput} />
      </div>
      <div className="flex flex-col gap-1 flex-1 min-w-[160px]">
        <label className="text-[10px] font-bold uppercase tracking-wide text-[#8A7356]" htmlFor="periode-motif">Motif</label>
        <input id="periode-motif" value={motif} onChange={(e) => setMotif(e.target.value)} placeholder="Vacances, tournée…" className={classeInput} />
      </div>
      <button
        onClick={bloquer}
        disabled={enCours || !debut || !fin || debut > fin}
        className="min-h-[40px] px-4 rounded-full bg-[#1C1917] text-[#FAF7F2] text-xs font-bold hover:bg-[#33302B] disabled:opacity-50"
      >
        {enCours ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : "Bloquer"}
      </button>
      <button onClick={() => setOuvert(false)} className="min-h-[40px] px-3 text-xs text-[#57534E] hover:text-[#1C1917]">
        Annuler
      </button>
    </div>
  );
}