import React from "react";
import { Eye, EyeOff } from "lucide-react";

const SECTIONS = [
  ["apropos", "À propos"],
  ["galerie", "Galerie"],
  ["repertoire", "Répertoire"],
  ["tarifs", "Tarifs"],
  ["avis", "Avis"],
  ["faq", "FAQ"],
  ["intermittent", "Intermittent"],
];

export default function VisibiliteSections({ masquees, onChange }) {
  const basculer = (cle) => {
    const liste = masquees.includes(cle) ? masquees.filter((m) => m !== cle) : [...masquees, cle];
    onChange(liste);
  };

  return (
    <div className="rounded-xl border border-[#B49B72]/25 bg-white p-5 space-y-3">
      <div>
        <h3 className="text-xs font-bold uppercase tracking-wide text-[#8A7356]">Sections visibles sur la page</h3>
        <p className="text-xs text-[#57534E] mt-1">
          Le formulaire de disponibilités reste toujours visible.
        </p>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
        {SECTIONS.map(([cle, libelle]) => {
          const visible = !masquees.includes(cle);
          return (
            <button
              key={cle}
              type="button"
              onClick={() => basculer(cle)}
              className={`min-h-[40px] px-3 rounded-lg text-sm inline-flex items-center justify-between gap-2 transition-colors ${
                visible
                  ? "bg-[#FAF7F2] text-[#1C1917] font-medium"
                  : "text-[#57534E] line-through hover:bg-[#FAF7F2]"
              }`}
            >
              {libelle}
              {visible ? <Eye className="h-4 w-4 text-[#8A7356]" /> : <EyeOff className="h-4 w-4" />}
            </button>
          );
        })}
      </div>
    </div>
  );
}