import React from "react";
import { Newspaper, Image as ImageIcon, LayoutGrid, Columns3, GalleryHorizontal } from "lucide-react";

const STYLES = [
  ["editorial", "Éditorial", "Fond noir, typographie magazine, grands titres", Newspaper],
  ["immersif", "Immersif", "Votre couverture en fond, infos dans des blocs par-dessus", ImageIcon],
];

const MODES_GALERIE = [
  ["grille", "Grille", "Cases carrées régulières", LayoutGrid],
  ["mosaique", "Mosaïque", "Colonnes aux hauteurs libres", Columns3],
  ["pellicule", "Pellicule", "Grands visuels à faire défiler", GalleryHorizontal],
];

function GroupeChoix({ titre, options, valeur, onChoisir }) {
  return (
    <div>
      <p className="text-sm font-semibold text-[var(--p-text)] mb-2">{titre}</p>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
        {options.map(([cle, libelle, description, Icone]) => (
          <button
            key={cle}
            type="button"
            onClick={() => onChoisir(cle)}
            aria-pressed={valeur === cle}
            className={`rounded-2xl border p-3.5 text-left transition-colors ${
              valeur === cle
                ? "border-[var(--p-text)] bg-[var(--p-cta)] text-[var(--p-cta-text)]"
                : "border-[var(--p-border)] bg-white text-[var(--p-text)] hover:border-[var(--p-border-strong)]"
            }`}
          >
            <Icone className="h-4 w-4 mb-2" />
            <p className="text-sm font-semibold">{libelle}</p>
            <p className={`mt-0.5 text-xs leading-snug ${valeur === cle ? "opacity-70" : "text-[var(--p-muted)]"}`}>{description}</p>
          </button>
        ))}
      </div>
    </div>
  );
}

// Réglages d'apparence du mini-site : style graphique de la page et mode d'affichage des visuels.
export default function ApparenceMiniSite({ profil, onSauver }) {
  return (
    <div className="rounded-2xl bg-white border border-[var(--p-border)] p-4 md:p-5 space-y-5">
      <GroupeChoix
        titre="Style de la page"
        options={STYLES}
        valeur={profil.styleMiniSite || "editorial"}
        onChoisir={(v) => onSauver({ styleMiniSite: v })}
      />
      <GroupeChoix
        titre="Affichage de la galerie"
        options={MODES_GALERIE}
        valeur={profil.modeGalerie || "grille"}
        onChoisir={(v) => onSauver({ modeGalerie: v })}
      />
    </div>
  );
}