import React from "react";
import { Plus, Trash2 } from "lucide-react";

const classeInput =
  "w-full rounded-lg border border-[#B49B72]/40 bg-white px-3 py-2 text-sm text-[#1C1917] focus:border-[#8A7356] focus:outline-none";

export default function GestionJalons({ jalons, onChange }) {
  const changer = (i, champ, v) => onChange(jalons.map((x, j) => (j === i ? { ...x, [champ]: v } : x)));

  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <label className="text-xs font-bold uppercase tracking-wide text-[#8A7356]">
          Timeline de vie (naissance, moments clés…)
        </label>
        <button
          onClick={() => onChange([...jalons, { annee: "", titre: "", texte: "" }])}
          className="text-xs text-[#8A7356] font-bold flex items-center gap-1 hover:underline"
        >
          <Plus className="h-3.5 w-3.5" /> Ajouter un repère
        </button>
      </div>
      <div className="space-y-3">
        {jalons.map((j, i) => (
          <div key={i} className="rounded-lg border border-[#B49B72]/25 p-3 space-y-2">
            <div className="grid grid-cols-[110px_1fr] gap-2">
              <input className={classeInput} placeholder="Année" value={j.annee || ""}
                onChange={(e) => changer(i, "annee", e.target.value)} />
              <input className={classeInput} placeholder="Titre (ex. Premiers concerts)" value={j.titre || ""}
                onChange={(e) => changer(i, "titre", e.target.value)} />
            </div>
            <textarea rows={2} className={`${classeInput} resize-y`} placeholder="Une phrase sur ce moment" value={j.texte || ""}
              onChange={(e) => changer(i, "texte", e.target.value)} />
            <button onClick={() => onChange(jalons.filter((_, k) => k !== i))}
              className="text-xs text-[#B3261E] flex items-center gap-1 hover:underline">
              <Trash2 className="h-3.5 w-3.5" /> Retirer
            </button>
          </div>
        ))}
        {jalons.length === 0 && (
          <p className="text-xs text-[#57534E]">Aucun repère — ajoutez-en ou générez-les avec vos informations ci-dessus.</p>
        )}
      </div>
    </div>
  );
}