import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { ChevronLeft, ChevronRight, Loader2 } from "lucide-react";
import { JOURS_SEMAINE, cleDate, grilleMois, libelleMois } from "@/lib/calendrier";
import PanneauJourCalendrier from "@/components/admin/PanneauJourCalendrier";
import BloquerPeriode from "@/components/admin/BloquerPeriode";
import ReservationDirecteAdmin from "@/components/admin/ReservationDirecteAdmin";
import PresenceLocale from "@/components/admin/PresenceLocale";

export default function CalendrierAdmin({ email }) {
  const auj = new Date();
  const [annee, setAnnee] = useState(auj.getFullYear());
  const [mois, setMois] = useState(auj.getMonth());
  const [bloquees, setBloquees] = useState(null);
  const [confirmees, setConfirmees] = useState([]);
  const [evenements, setEvenements] = useState([]);
  const [options, setOptions] = useState([]);
  const [selection, setSelection] = useState(null);
  const [enCours, setEnCours] = useState(false);

  const charger = async () => {
    const [b, d, e, o] = await Promise.all([
      base44.entities.DateBloquee.filter({ proprietaire: email }, "-date", 500),
      base44.entities.DemandesDisponibilite.filter({ proprietaire: email, statut: "Confirmée" }, "-dateEvenement", 500),
      base44.entities.Evenement.filter({ proprietaire: email }, "-date", 500),
      base44.entities.OptionDate.filter({ proprietaire: email }, "-created_date", 200),
    ]);
    setBloquees(b);
    setConfirmees(d);
    setEvenements(e.filter((ev) => ev.statut !== "annule"));
    setOptions(o.filter((opt) => opt.expireLe && new Date(opt.expireLe) > new Date()));
  };

  useEffect(() => { charger(); }, [email]);

  const naviguer = (delta) => {
    const d = new Date(annee, mois + delta, 1);
    setAnnee(d.getFullYear());
    setMois(d.getMonth());
  };

  const parDate = Object.fromEntries((bloquees || []).map((r) => [r.date, r]));
  const demandesParDate = {};
  confirmees.forEach((d) => { (demandesParDate[d.dateEvenement] ||= []).push(d); });
  const evtsParDate = {};
  evenements.forEach((e) => { (evtsParDate[e.date] ||= []).push(e); });
  const optionsParDate = {};
  options.forEach((o) => { (optionsParDate[o.date] ||= []).push(o); });
  const cleAujourdhui = cleDate(auj);

  // Actions du panneau de détail
  const bloquer = async (motif) => {
    setEnCours(true);
    try {
      await base44.entities.DateBloquee.create({ proprietaire: email, date: selection, motif });
      await charger();
    } finally { setEnCours(false); }
  };
  const debloquer = async () => {
    setEnCours(true);
    try {
      await base44.entities.DateBloquee.delete(parDate[selection].id);
      // Prévenir les visiteurs qui guettaient cette date.
      try { await base44.functions.invoke("notifierDateLiberee", { date: selection }); } catch (_e) { /* non bloquant */ }
      await charger();
    } finally { setEnCours(false); }
  };
  const changerMotif = async (motif) => {
    setEnCours(true);
    try {
      await base44.entities.DateBloquee.update(parDate[selection].id, { motif });
      await charger();
    } finally { setEnCours(false); }
  };

  if (bloquees === null) {
    return <div className="flex justify-center py-16"><Loader2 className="h-6 w-6 animate-spin text-[#8A7356]" /></div>;
  }

  // Pouls du mois affiché : réservations, blocages, week-ends encore libres.
  const jours = grilleMois(annee, mois).filter(Boolean);
  const nbReservees = jours.filter((j) => demandesParDate[cleDate(j)]).length;
  const nbBloquees = jours.filter((j) => parDate[cleDate(j)]).length;
  const weekendsLibres = jours.filter((j) => {
    const cle = cleDate(j);
    return [0, 6].includes(j.getDay()) && !demandesParDate[cle] && !parDate[cle];
  }).length;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[1.4fr_1fr] gap-5 items-start">
      <div className="rounded-xl border border-[#B49B72]/25 bg-white p-6 shadow-sm space-y-5">
        <div className="flex items-center justify-between">
          <h2 className="font-heading text-xl">{libelleMois(annee, mois)}</h2>
          <div className="flex gap-2">
            <button onClick={() => naviguer(-1)} aria-label="Mois précédent" className="h-10 w-10 rounded-full border border-[#B49B72]/40 flex items-center justify-center hover:bg-[#FAF7F2]">
              <ChevronLeft className="h-4 w-4" />
            </button>
            <button onClick={() => naviguer(1)} aria-label="Mois suivant" className="h-10 w-10 rounded-full border border-[#B49B72]/40 flex items-center justify-center hover:bg-[#FAF7F2]">
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Pouls du mois */}
        <div className="flex flex-wrap gap-x-5 gap-y-1 text-xs text-[#57534E]">
          <p><span className="font-bold text-[#0A84FF]">{nbReservees}</span> jour(s) réservé(s)</p>
          <p><span className="font-bold text-[#1C1917]">{nbBloquees}</span> jour(s) bloqué(s)</p>
          <p><span className="font-bold">{weekendsLibres}</span> jour(s) de week-end encore libre(s)</p>
        </div>

        <div className="grid grid-cols-7 gap-1.5 text-center">
          {JOURS_SEMAINE.map((j) => (
            <p key={j} className="text-[10px] font-bold uppercase tracking-wide text-[#8A7356] py-1">{j}</p>
          ))}
          {grilleMois(annee, mois).map((jour, i) => {
            if (!jour) return <div key={`v-${i}`} />;
            const cle = cleDate(jour);
            const reservee = !!demandesParDate[cle];
            const bloquee = !!parDate[cle];
            const aEvenement = !!evtsParDate[cle];
            const selectionnee = selection === cle;
            return (
              <button
                key={cle}
                onClick={() => setSelection(selectionnee ? null : cle)}
                aria-pressed={selectionnee}
                title={reservee ? "Réservé — cliquez pour voir les détails" : bloquee ? `Bloqué : ${parDate[cle].motif || "sans motif"}` : "Cliquez pour voir ou bloquer cette date"}
                className={`relative min-h-[44px] rounded-lg text-sm transition-colors ${
                  reservee
                    ? "bg-[#0A84FF] text-white font-bold hover:bg-[#0870d8]"
                    : bloquee
                    ? "bg-[#1C1917] text-[#FAF7F2] font-bold hover:bg-[#33302B]"
                    : "border border-[#B49B72]/25 text-[#44403C] hover:bg-[#FAF7F2]"
                } ${cle === cleAujourdhui ? "ring-2 ring-[#98989D]/70" : ""} ${selectionnee ? "ring-2 ring-[#8A7356]" : ""}`}
              >
                {jour.getDate()}
                {optionsParDate[cle] && (
                  <span
                    className="absolute top-1 right-1 h-1.5 w-1.5 rounded-full bg-[#FF9F0A]"
                    aria-hidden="true"
                    title="Option 48 h posée"
                  />
                )}
                {aEvenement && (
                  <span
                    className={`absolute bottom-1 left-1/2 -translate-x-1/2 h-1.5 w-1.5 rounded-full ${reservee || bloquee ? "bg-white" : "bg-[#8A7356]"}`}
                    aria-hidden="true"
                    title="Événement du Studio ce jour-là"
                  />
                )}
              </button>
            );
          })}
        </div>

        <div className="flex flex-wrap gap-x-5 gap-y-2 text-xs text-[#57534E] pt-1">
          <p className="flex items-center gap-2"><span className="h-3.5 w-3.5 rounded bg-[#0A84FF] inline-block" /> Réservé</p>
          <p className="flex items-center gap-2"><span className="h-3.5 w-3.5 rounded bg-[#1C1917] inline-block" /> Bloqué</p>
          <p className="flex items-center gap-2"><span className="h-3.5 w-3.5 rounded border border-[#B49B72]/40 inline-block" /> Libre</p>
          <p className="flex items-center gap-2"><span className="h-1.5 w-1.5 rounded-full bg-[#8A7356] inline-block" /> Événement du Studio</p>
          <p className="flex items-center gap-2"><span className="h-1.5 w-1.5 rounded-full bg-[#FF9F0A] inline-block" /> Option 48 h</p>
        </div>
      </div>

      <div className="space-y-4">
        <PresenceLocale email={email} />
        <ReservationDirecteAdmin email={email} />
        <BloquerPeriode
          email={email}
          datesOccupees={new Set([...Object.keys(parDate), ...Object.keys(demandesParDate)])}
          onFait={charger}
        />
        {selection ? (
          <PanneauJourCalendrier
            cle={selection}
            demandes={demandesParDate[selection] || []}
            evenements={evtsParDate[selection] || []}
            options={optionsParDate[selection] || []}
            bloquee={parDate[selection] || null}
            onBloquer={bloquer}
            onDebloquer={debloquer}
            onChangerMotif={changerMotif}
            enCours={enCours}
          />
        ) : (
          <p className="text-sm text-[#57534E] rounded-2xl border border-dashed border-[#B49B72]/40 p-5">
            Cliquez sur une date pour voir ses détails : qui a réservé, pourquoi elle est bloquée, ou pour la bloquer avec un motif.
          </p>
        )}
      </div>
    </div>
  );
}