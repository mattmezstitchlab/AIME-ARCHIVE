import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Switch } from "@/components/ui/switch";
import { Loader2, Plus, Trash2, Zap } from "lucide-react";

const JOURS = ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];
const ORDRE_AFFICHAGE = [1, 2, 3, 4, 5, 6, 0];
const classeInput = "min-h-[40px] rounded-lg border border-[#B49B72]/40 bg-white px-2 text-sm focus:outline-none focus:border-[#8A7356]";

// Configuration de la réservation directe type Doctolib : activation + créneaux hebdomadaires.
export default function ReservationDirecteAdmin({ email }) {
  const [profil, setProfil] = useState(null);
  const [creneaux, setCreneaux] = useState([]);
  const [charge, setCharge] = useState(false);
  const [nouveau, setNouveau] = useState({ jour: 6, heureDebut: "19:00", heureFin: "23:00" });
  const [enCours, setEnCours] = useState(false);

  useEffect(() => {
    (async () => {
      const [p, c] = await Promise.all([
        base44.entities.ProfilPrestataire.filter({ proprietaire: email }, "-updated_date", 1),
        base44.entities.CreneauHebdo.filter({ proprietaire: email }, "heureDebut", 100),
      ]);
      setProfil(p[0] || null);
      setCreneaux(c);
      setCharge(true);
    })();
  }, [email]);

  const basculer = async (actif) => {
    if (!profil) return;
    setProfil({ ...profil, reservationDirecte: actif });
    await base44.entities.ProfilPrestataire.update(profil.id, { reservationDirecte: actif });
  };

  const ajouter = async () => {
    if (!nouveau.heureDebut || !nouveau.heureFin || nouveau.heureFin <= nouveau.heureDebut) return;
    setEnCours(true);
    try {
      const cree = await base44.entities.CreneauHebdo.create({
        proprietaire: email,
        jour: Number(nouveau.jour),
        heureDebut: nouveau.heureDebut,
        heureFin: nouveau.heureFin,
      });
      setCreneaux((c) => [...c, cree]);
    } finally {
      setEnCours(false);
    }
  };

  const supprimer = async (id) => {
    setCreneaux((c) => c.filter((cr) => cr.id !== id));
    await base44.entities.CreneauHebdo.delete(id);
  };

  if (!charge) {
    return <div className="rounded-2xl border border-[#B49B72]/25 bg-white p-5 flex justify-center"><Loader2 className="h-5 w-5 animate-spin text-[#8A7356]" /></div>;
  }

  return (
    <div className="rounded-2xl border border-[#B49B72]/25 bg-white p-5 space-y-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="font-heading text-base flex items-center gap-2"><Zap className="h-4 w-4 text-[#FF9F0A]" /> Réservation directe</p>
          <p className="text-xs text-[#57534E] mt-1">
            Les visiteurs réservent en un clic vos créneaux récurrents sur une date libre — la date est confirmée d'office, comme sur Doctolib.
          </p>
        </div>
        <Switch checked={!!profil?.reservationDirecte} onCheckedChange={basculer} aria-label="Activer la réservation directe" />
      </div>

      {profil?.reservationDirecte && (
        <>
          <div className="space-y-2">
            {ORDRE_AFFICHAGE.filter((j) => creneaux.some((c) => c.jour === j)).map((j) => (
              <div key={j} className="text-sm">
                <p className="text-xs font-bold uppercase tracking-wide text-[#8A7356] mb-1">{JOURS[j]}</p>
                <div className="flex flex-wrap gap-2">
                  {creneaux.filter((c) => c.jour === j).map((c) => (
                    <span key={c.id} className="inline-flex items-center gap-1.5 rounded-full border border-[#B49B72]/40 pl-3 pr-1 py-1 text-xs">
                      {c.heureDebut} – {c.heureFin}
                      <button onClick={() => supprimer(c.id)} aria-label="Supprimer ce créneau" className="h-6 w-6 rounded-full flex items-center justify-center hover:bg-[#FAF7F2]">
                        <Trash2 className="h-3 w-3 text-[#57534E]" />
                      </button>
                    </span>
                  ))}
                </div>
              </div>
            ))}
            {creneaux.length === 0 && (
              <p className="text-xs text-[#57534E] rounded-lg border border-dashed border-[#B49B72]/40 p-3">
                Ajoutez vos disponibilités récurrentes ci-dessous (ex. samedi 19 h – 23 h) : elles seront proposées à la réservation sur toutes les dates libres.
              </p>
            )}
          </div>

          <div className="flex flex-wrap items-end gap-2 pt-1 border-t border-[#B49B72]/15">
            <label className="text-xs text-[#57534E] flex flex-col gap-1 pt-3">
              Jour
              <select value={nouveau.jour} onChange={(e) => setNouveau({ ...nouveau, jour: Number(e.target.value) })} className={classeInput}>
                {ORDRE_AFFICHAGE.map((j) => <option key={j} value={j}>{JOURS[j]}</option>)}
              </select>
            </label>
            <label className="text-xs text-[#57534E] flex flex-col gap-1">
              Début
              <input type="time" value={nouveau.heureDebut} onChange={(e) => setNouveau({ ...nouveau, heureDebut: e.target.value })} className={classeInput} />
            </label>
            <label className="text-xs text-[#57534E] flex flex-col gap-1">
              Fin
              <input type="time" value={nouveau.heureFin} onChange={(e) => setNouveau({ ...nouveau, heureFin: e.target.value })} className={classeInput} />
            </label>
            <button
              onClick={ajouter}
              disabled={enCours || !nouveau.heureDebut || !nouveau.heureFin || nouveau.heureFin <= nouveau.heureDebut}
              className="min-h-[40px] px-4 rounded-full bg-[#1C1917] text-[#FAF7F2] text-xs font-bold hover:bg-[#33302B] disabled:opacity-40 inline-flex items-center gap-1.5"
            >
              {enCours ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Plus className="h-3.5 w-3.5" />} Ajouter
            </button>
          </div>
        </>
      )}
    </div>
  );
}