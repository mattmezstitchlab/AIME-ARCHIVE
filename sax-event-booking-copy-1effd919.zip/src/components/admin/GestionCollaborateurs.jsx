import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Loader2, UserPlus, ShieldCheck, User as UserIcon } from "lucide-react";

const classeInput =
  "min-h-[44px] w-full rounded-lg border border-[#B49B72]/40 bg-white px-3 py-2 text-sm text-[#1C1917] placeholder:text-[#1C1917]/35 focus:border-[#8A7356] focus:outline-none focus:ring-1 focus:ring-[#8A7356]/40";

export default function GestionCollaborateurs() {
  const [utilisateurs, setUtilisateurs] = useState(null);
  const [email, setEmail] = useState("");
  const [role, setRole] = useState("admin");
  const [envoi, setEnvoi] = useState(false);
  const [message, setMessage] = useState(null);

  const charger = async () => {
    setUtilisateurs(await base44.entities.User.list("-created_date", 200));
  };

  useEffect(() => { charger(); }, []);

  const inviter = async (ev) => {
    ev.preventDefault();
    setMessage(null);
    if (!email.trim()) {
      setMessage({ type: "erreur", texte: "Merci d'indiquer une adresse e-mail." });
      return;
    }
    setEnvoi(true);
    try {
      await base44.users.inviteUser(email.trim().toLowerCase(), role);
      setMessage({ type: "succes", texte: `Invitation envoyée à ${email.trim()}.` });
      setEmail("");
      await charger();
    } catch (e) {
      setMessage({ type: "erreur", texte: e?.response?.data?.message || e?.message || "L'invitation a échoué." });
    } finally {
      setEnvoi(false);
    }
  };

  return (
    <div className="space-y-8">
      <form onSubmit={inviter} className="rounded-xl border border-[#B49B72]/25 bg-white p-6 shadow-sm space-y-4">
        <h2 className="font-heading text-xl">Inviter un collaborateur</h2>
        <p className="text-sm text-[#57534E]">
          <strong>Collaborateur (admin)</strong> : accès complet à cet espace — demandes, calendrier, avis, documents, contenu.
          <br />
          <strong>Client (utilisateur)</strong> : accès uniquement à son espace client et ses documents.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-[1fr_auto_auto] gap-3">
          <input
            type="email"
            className={classeInput}
            placeholder="adresse@email.com"
            value={email}
            onChange={(ev) => setEmail(ev.target.value)}
            aria-label="Adresse e-mail à inviter"
          />
          <select
            className={classeInput}
            value={role}
            onChange={(ev) => setRole(ev.target.value)}
            aria-label="Rôle"
          >
            <option value="admin">Collaborateur (admin)</option>
            <option value="user">Client (utilisateur)</option>
          </select>
          <button
            type="submit"
            disabled={envoi}
            className="min-h-[44px] px-6 rounded-full bg-[#1C1917] text-[#FAF7F2] text-sm font-bold flex items-center justify-center gap-2 hover:bg-[#33302B] disabled:opacity-70"
          >
            {envoi ? <Loader2 className="h-4 w-4 animate-spin" /> : <UserPlus className="h-4 w-4" />}
            Inviter
          </button>
        </div>
        {message && (
          <p role="alert" className={`text-sm ${message.type === "succes" ? "text-[#3F6C3A]" : "text-[#B3261E]"}`}>
            {message.texte}
          </p>
        )}
      </form>

      <div>
        <h2 className="font-heading text-xl mb-4">Membres du compte</h2>
        {utilisateurs === null ? (
          <div className="flex justify-center py-12"><Loader2 className="h-6 w-6 animate-spin text-[#8A7356]" /></div>
        ) : (
          <div className="space-y-3">
            {utilisateurs.map((u) => (
              <div key={u.id} className="rounded-xl border border-[#B49B72]/25 bg-white p-4 flex items-center justify-between gap-4">
                <div>
                  <p className="font-bold text-sm">{u.full_name || u.email}</p>
                  <p className="text-xs text-[#57534E] mt-0.5">{u.email}</p>
                </div>
                <span className={`text-[10px] font-bold uppercase tracking-wide rounded-full px-3 py-1 flex items-center gap-1.5 ${
                  u.role === "admin" ? "bg-[#E8E8ED] text-[#57534E]" : "bg-[#1C1917]/10 text-[#57534E]"
                }`}>
                  {u.role === "admin" ? <ShieldCheck className="h-3 w-3" /> : <UserIcon className="h-3 w-3" />}
                  {u.role === "admin" ? "Collaborateur" : "Client"}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}