import React, { useState } from "react";
import { Eye, EyeOff, ChevronUp, ChevronDown, ChevronRight } from "lucide-react";

// Carte de module du mini-site : ordre, visibilité, et contenu éditable dépliable.
export default function ModuleMiniSite({ libelle, description, visible, onToggle, onMonter, onDescendre, premier, dernier, children }) {
  const [ouvert, setOuvert] = useState(false);

  return (
    <li className={`rounded-2xl bg-white border border-[var(--p-border)] overflow-hidden ${visible ? "" : "opacity-60"}`}>
      <div className="flex items-center gap-3 px-4 py-3">
        <div className="flex flex-col">
          <button type="button" onClick={onMonter} disabled={premier} title="Monter" aria-label={`Monter ${libelle}`}
            className="h-7 w-7 inline-flex items-center justify-center rounded-full text-[var(--p-muted)] hover:bg-white/10 hover:text-[var(--p-text)] disabled:opacity-25 transition-colors">
            <ChevronUp className="h-4 w-4" />
          </button>
          <button type="button" onClick={onDescendre} disabled={dernier} title="Descendre" aria-label={`Descendre ${libelle}`}
            className="h-7 w-7 inline-flex items-center justify-center rounded-full text-[var(--p-muted)] hover:bg-white/10 hover:text-[var(--p-text)] disabled:opacity-25 transition-colors">
            <ChevronDown className="h-4 w-4" />
          </button>
        </div>
        <button
          type="button"
          onClick={() => setOuvert((o) => !o)}
          aria-expanded={ouvert}
          className="flex-1 min-w-0 flex items-center gap-2 text-left group"
        >
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-[var(--p-text)]">{libelle}</p>
            <p className="text-xs text-[var(--p-muted)] truncate">{description}</p>
          </div>
          <ChevronRight className={`h-4 w-4 shrink-0 text-[var(--p-muted)] group-hover:text-[var(--p-text)] transition-transform ${ouvert ? "rotate-90" : ""}`} />
        </button>
        <button
          type="button"
          onClick={onToggle}
          title={visible ? "Masquer ce module" : "Afficher ce module"}
          aria-label={visible ? `Masquer ${libelle}` : `Afficher ${libelle}`}
          aria-pressed={visible}
          className={`h-9 w-9 shrink-0 inline-flex items-center justify-center rounded-full transition-colors ${
            visible ? "bg-[var(--p-cta)] text-[var(--p-cta-text)]" : "bg-white/[0.08] text-[var(--p-muted)] hover:bg-white/15"
          }`}
        >
          {visible ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
        </button>
      </div>
      {ouvert && (
        <div className="border-t border-[var(--p-border)] bg-[var(--p-bg)]/60 p-4 md:p-5">
          {children}
        </div>
      )}
    </li>
  );
}