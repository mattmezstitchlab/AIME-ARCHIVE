import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Loader2, MapPin, Zap } from "lucide-react";

// Ma présence locale : rayon d'action heureux + « J'ai une heure devant moi ».
export default function PresenceLocale({ email }) {
  const [profil, setProfil] = useState(null);
  const [dispo, setDispo] = useState(null);
  const [rayon, setRayon] = useState(25);
  const [enCours, setEnCours] = useState(false);

  const charger = async () => {
    const [profils, dispos] = await Promise.all([
      base44.entities.ProfilPrestataire.filter({ proprietaire: email }, "-updated_date", 1),
      base44.entities.DisponibiliteInstant.filter({ proprietaire: email }, "-created_date", 5),
    ]);
    const p = profils[0] || null;
    setProfil(p);
    setRayon(p?.rayonAction || 25);
    setDispo(dispos.find((d) => d.jusqua && new Date(d.jusqua) > new Date()) || null);
  };

  useEffect(() => { charger(); }, [email]);

  const enregistrerRayon = async () => {
    if (!profil) return;
    setEnCours(true);
    try {
      await base44.entities.ProfilPrestataire.update(profil.id, { rayonAction: Number(rayon) || 25 });
      await charger();
    } finally { setEnCours(false); }
  };

  const basculerDispo = async () => {
    setEnCours(true);
    try {
      if (dispo) {
        await base44.entities.DisponibiliteInstant.delete(dispo.id);
      } else {
        const jusqua = new Date(Date.now() + 60 * 60 * 1000).toISOString();
        await base44.entities.DisponibiliteInstant.create({ proprietaire: email, jusqua });
      }
      await charger();
    } finally { setEnCours(false); }
  };

  if (!profil) return null;

  return (
    <div className="rounded-2xl border border-[#B49B72]/25 bg-white p-5 shadow-sm space-y-4">
      <h3 className="font-heading text-lg flex items-center gap-2">
        <MapPin className="h-4 w-4 text-[#8A7356]" aria-hidden="true" /> Ma présence locale
      </h3>

      <div className="space-y-1.5">
        <label htmlFor="rayon-action" className="text-xs font-bold uppercase tracking-wide text-[#8A7356]">
          Rayon d'action heureux (km)
        </label>
        <div className="flex gap-2">
          <input
            id="rayon-action"
            type="number"
            min="1"
            max="500"
            value={rayon}
            onChange={(e) => setRayon(e.target.value)}
            className="min-h-[44px] w-24 rounded-lg border border-[#B49B72]/40 px-3 text-sm"
          />
          <button
            onClick={enregistrerRayon}
            disabled={enCours}
            className="min-h-[44px] px-4 rounded-full bg-[#1C1917] text-[#FAF7F2] text-sm font-bold hover:bg-[#33302B] disabled:opacity-40"
          >
            Enregistrer
          </button>
        </div>
        <p className="text-xs text-[#57534E]">Aime privilégie les mises en relation dans ce rayon : moins de route, plus de voisins.</p>
      </div>

      <div className="border-t border-[#B49B72]/15 pt-4">
        <button
          onClick={basculerDispo}
          disabled={enCours}
          aria-pressed={!!dispo}
          className={`w-full min-h-[48px] rounded-full text-sm font-bold inline-flex items-center justify-center gap-2 transition-colors disabled:opacity-40 ${
            dispo
              ? "bg-[#FF9F0A]/15 text-[#B45309] border border-[#FF9F0A]/50"
              : "border border-[#B49B72]/40 text-[#1C1917] hover:bg-[#FAF7F2]"
          }`}
        >
          {enCours ? <Loader2 className="h-4 w-4 animate-spin" /> : <Zap className="h-4 w-4" aria-hidden="true" />}
          {dispo ? "Disponible maintenant — cliquer pour arrêter" : "J'ai une heure devant moi"}
        </button>
        {dispo && (
          <p className="text-xs text-[#57534E] mt-2 text-center">
            Visible des voisins jusqu'à {new Date(dispo.jusqua).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}.
          </p>
        )}
      </div>
    </div>
  );
}