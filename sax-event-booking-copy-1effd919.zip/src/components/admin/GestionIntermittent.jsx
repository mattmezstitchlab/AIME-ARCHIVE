import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Switch } from "@/components/ui/switch";
import { Loader2, Check } from "lucide-react";

const classeInput =
  "mt-1 min-h-[44px] w-full rounded-lg border border-[#B49B72]/40 bg-white px-3 py-2 text-sm text-[#1C1917] focus:border-[#8A7356] focus:outline-none focus:ring-1 focus:ring-[#8A7356]/40";

function Champ({ libelle, aide, children }) {
  return (
    <div>
      <label className="text-xs font-bold uppercase tracking-wide text-[#8A7356]">{libelle}</label>
      {children}
      {aide && <p className="mt-1 text-[11px] leading-relaxed text-[#57534E]">{aide}</p>}
    </div>
  );
}

function Interrupteur({ libelle, aide, valeur, onChange }) {
  return (
    <div className="flex items-start justify-between gap-4 rounded-xl border border-[#B49B72]/25 bg-white p-4">
      <div>
        <p className="text-sm font-semibold text-[#1C1917]">{libelle}</p>
        <p className="mt-0.5 text-[11px] leading-relaxed text-[#57534E]">{aide}</p>
      </div>
      <Switch checked={valeur} onCheckedChange={onChange} />
    </div>
  );
}

const VIDE = {
  estIntermittent: false,
  profession: "",
  numeroCongesSpectacles: "",
  cachetIndicatif: "",
  employeurGuso: true,
  precisions: "",
  afficherSurProfil: true,
};

export default function GestionIntermittent({ email }) {
  const [v, setV] = useState(VIDE);
  const [idExistant, setIdExistant] = useState(null);
  const [charge, setCharge] = useState(false);
  const [enregistrement, setEnregistrement] = useState(false);
  const [sauve, setSauve] = useState(false);

  useEffect(() => {
    base44.entities.InfosIntermittent.filter({ proprietaire: email }, "-updated_date", 1).then((liste) => {
      if (liste[0]) {
        setIdExistant(liste[0].id);
        setV((prev) => ({
          ...prev,
          ...Object.fromEntries(Object.entries(liste[0]).filter(([cle]) => cle in prev)),
        }));
      }
      setCharge(true);
    });
  }, [email]);

  const maj = (cle) => (valeurOuEvenement) => {
    const valeur = valeurOuEvenement?.target ? valeurOuEvenement.target.value : valeurOuEvenement;
    setSauve(false);
    setV((prev) => ({ ...prev, [cle]: valeur }));
  };

  const enregistrer = async () => {
    setEnregistrement(true);
    if (idExistant) {
      await base44.entities.InfosIntermittent.update(idExistant, v);
    } else {
      const cree = await base44.entities.InfosIntermittent.create({ proprietaire: email, ...v });
      setIdExistant(cree.id);
    }
    setEnregistrement(false);
    setSauve(true);
  };

  if (!charge) {
    return (
      <div className="flex justify-center py-16">
        <Loader2 className="h-6 w-6 animate-spin text-[#8A7356]" />
      </div>
    );
  }

  return (
    <div className="max-w-2xl space-y-4">
      <div className="rounded-xl border border-[#B49B72]/25 bg-white p-5">
        <h3 className="font-heading text-lg text-[#1C1917]">Intermittent du spectacle</h3>
        <p className="mt-1 text-sm leading-relaxed text-[#57534E]">
          Renseignez ici votre situation d'intermittent. Ces informations s'affichent sur votre profil public
          pour expliquer clairement aux organisateurs (vos employeurs) ce que votre embauche implique :
          déclaration avant la prestation, cachet brut, attestations après la prestation.
        </p>
        <p className="mt-2 text-[11px] leading-relaxed text-[#8A7356]">
          Pour votre suivi personnel (compteur 507 heures, échéances, justificatifs), rendez-vous dans l'onglet
          « Intermittence » du menu de gauche.
        </p>
      </div>

      <Interrupteur
        libelle="Je suis intermittent du spectacle"
        aide="Salarié du spectacle embauché au cachet en CDD d'usage (annexes 8 et 10 de l'assurance chômage)."
        valeur={v.estIntermittent}
        onChange={maj("estIntermittent")}
      />

      {v.estIntermittent && (
        <>
          <Champ libelle="Profession" aide="Telle qu'elle apparaît sur vos contrats et AEM (ex. : musicien — saxophoniste).">
            <input className={classeInput} value={v.profession} onChange={maj("profession")} placeholder="Musicien — saxophoniste" />
          </Champ>

          <Champ
            libelle="N° Congés Spectacles"
            aide="Numéro d'affiliation à la caisse des Congés Spectacles (Audiens). L'employeur en a besoin pour ses déclarations."
          >
            <input className={classeInput} value={v.numeroCongesSpectacles} onChange={maj("numeroCongesSpectacles")} />
          </Champ>

          <Champ
            libelle="Cachet indicatif (brut)"
            aide="Montant brut indicatif d'un cachet. Rappel : le montant convenu avec un employeur est toujours un brut, soumis aux cotisations du spectacle."
          >
            <input className={classeInput} value={v.cachetIndicatif} onChange={maj("cachetIndicatif")} placeholder="Ex. : à partir de 200 € brut" />
          </Champ>

          <Interrupteur
            libelle="J'accepte les employeurs occasionnels via le GUSO"
            aide="Le GUSO (guso.fr) est le guichet unique gratuit qui permet aux particuliers, associations et entreprises hors spectacle de déclarer un artiste en une seule démarche : contrat, paie et cotisations."
            valeur={v.employeurGuso}
            onChange={maj("employeurGuso")}
          />

          <Champ
            libelle="Précisions pour les employeurs"
            aide="Texte libre affiché sur votre profil (ex. : je fournis la fiche cachet préparatoire, numéro d'objet à demander, etc.)."
          >
            <textarea rows={3} className={classeInput} value={v.precisions} onChange={maj("precisions")} />
          </Champ>

          <Interrupteur
            libelle="Afficher la section sur mon profil public"
            aide="Une section « Intermittent du spectacle » claire et pédagogique apparaîtra sur votre page publique."
            valeur={v.afficherSurProfil}
            onChange={maj("afficherSurProfil")}
          />
        </>
      )}

      <button
        onClick={enregistrer}
        disabled={enregistrement}
        className="w-full min-h-[48px] rounded-full bg-[#1C1917] text-[#FAF7F2] font-bold text-sm hover:bg-[#33302B] disabled:opacity-70 transition-colors flex items-center justify-center gap-2"
      >
        {enregistrement ? <Loader2 className="h-4 w-4 animate-spin" /> : sauve ? <Check className="h-4 w-4" /> : null}
        {sauve ? "Enregistré" : "Enregistrer"}
      </button>
    </div>
  );
}