import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Loader2, Plus, Trash2, Save } from "lucide-react";

const classeInput =
  "w-full rounded-lg border border-[#B49B72]/40 bg-white px-3 py-2 text-sm text-[#1C1917] focus:border-[#8A7356] focus:outline-none";

export default function GestionFaq({ email }) {
  const [questions, setQuestions] = useState([]);
  const [chargement, setChargement] = useState(true);
  const [sauvegarde, setSauvegarde] = useState(null);

  useEffect(() => {
    base44.entities.QuestionFaq.filter({ proprietaire: email }, "ordre", 100).then((l) => {
      setQuestions(l);
      setChargement(false);
    });
  }, [email]);

  const changer = (id, champ, valeur) => {
    setQuestions((l) => l.map((q) => (q.id === id ? { ...q, [champ]: valeur } : q)));
  };

  const sauvegarder = async (q) => {
    setSauvegarde(q.id);
    await base44.entities.QuestionFaq.update(q.id, { question: q.question, reponse: q.reponse });
    setSauvegarde(null);
  };

  const ajouter = async () => {
    const cree = await base44.entities.QuestionFaq.create({
      proprietaire: email,
      question: "Nouvelle question",
      reponse: "Votre réponse…",
      ordre: questions.length,
    });
    setQuestions((l) => [...l, cree]);
  };

  const supprimer = async (q) => {
    await base44.entities.QuestionFaq.delete(q.id);
    setQuestions((l) => l.filter((x) => x.id !== q.id));
  };

  if (chargement) return <Loader2 className="h-6 w-6 animate-spin text-[#8A7356] mx-auto my-10" />;

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <h3 className="font-heading text-lg">Questions de la FAQ</h3>
        <button onClick={ajouter}
          className="min-h-[42px] px-4 rounded-full bg-[#1C1917] text-[#FAF7F2] text-sm font-medium inline-flex items-center gap-2 hover:bg-[#33302B]">
          <Plus className="h-4 w-4" /> Ajouter une question
        </button>
      </div>
      {questions.length === 0 && <p className="text-sm text-[#57534E]">Aucune question pour le moment.</p>}
      <div className="space-y-4">
        {questions.map((q) => (
          <div key={q.id} className="rounded-xl border border-[#B49B72]/30 bg-white p-4 space-y-2">
            <input type="text" value={q.question} aria-label="Question"
              onChange={(ev) => changer(q.id, "question", ev.target.value)}
              className={`${classeInput} font-medium`} />
            <textarea rows={3} value={q.reponse} aria-label="Réponse"
              onChange={(ev) => changer(q.id, "reponse", ev.target.value)}
              className={`${classeInput} resize-y`} />
            <div className="flex items-center gap-4">
              <button onClick={() => sauvegarder(q)} disabled={sauvegarde === q.id}
                className="text-xs text-[#8A7356] flex items-center gap-1 font-bold hover:underline disabled:opacity-60">
                {sauvegarde === q.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}
                Enregistrer
              </button>
              <button onClick={() => supprimer(q)}
                className="text-xs text-[#B3261E] flex items-center gap-1 hover:underline">
                <Trash2 className="h-3.5 w-3.5" /> Supprimer
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}