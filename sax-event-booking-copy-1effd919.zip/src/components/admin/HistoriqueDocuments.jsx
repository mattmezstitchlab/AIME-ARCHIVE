import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Loader2, Mail, Check, FileText } from "lucide-react";
import EmptyState from "@/components/compte/EmptyState";

const LIBELLES = { devis: "Devis", facture: "Facture", contrat: "Contrat" };

const STATUTS_DOCUMENT = {
  emis: { libelle: "Émis", classe: "bg-[#FAF7F2] text-[#57534E]" },
  envoye: { libelle: "Envoyé", classe: "bg-blue-50 text-blue-700" },
  accepte: { libelle: "Accepté", classe: "bg-green-50 text-green-700" },
  refuse: { libelle: "Refusé", classe: "bg-red-50 text-red-600" },
  paye: { libelle: "Payé", classe: "bg-emerald-100 text-emerald-800" },
};

export default function HistoriqueDocuments({ actualisation, email, expediteur, onCreer }) {
  const [documents, setDocuments] = useState(null);
  const [envoiEnCours, setEnvoiEnCours] = useState("");
  const [envoyes, setEnvoyes] = useState([]);
  const nomExpediteur = expediteur || "Aime Event";

  useEffect(() => {
    base44.entities.DocumentEmis.filter({ proprietaire: email }, "-created_date", 50).then(setDocuments);
  }, [actualisation, email]);

  const envoyerParEmail = async (doc) => {
    setEnvoiEnCours(doc.id);
    try {
      let lien = doc.fichierUrl;
      if (!String(lien).startsWith("http")) {
        const { signed_url } = await base44.integrations.Core.CreateFileSignedUrl({ file_uri: lien, expires_in: 604800 });
        lien = signed_url;
      }
      await base44.integrations.Core.SendEmail({
        to: doc.clientEmail,
        subject: `Votre ${(LIBELLES[doc.type] || doc.type).toLowerCase()} ${doc.numero} — ${nomExpediteur}`,
        body: `Bonjour ${doc.clientNom},

Veuillez trouver votre ${(LIBELLES[doc.type] || doc.type).toLowerCase()} ${doc.numero} au lien suivant (valable 7 jours) :
${lien}

Montant : ${Number(doc.montant || 0).toLocaleString("fr-FR", { minimumFractionDigits: 2 })} €

N'hésitez pas à me contacter pour toute question.

Cordialement,
${nomExpediteur}`,
        from_name: nomExpediteur,
      });
      setEnvoyes((l) => [...l, doc.id]);
      // L'envoi fait passer le document au statut « Envoyé » s'il était simplement émis.
      if (!doc.statut || doc.statut === "emis") {
        await base44.entities.DocumentEmis.update(doc.id, { statut: "envoye" });
        setDocuments((docs) => docs.map((x) => (x.id === doc.id ? { ...x, statut: "envoye" } : x)));
      }
    } finally {
      setEnvoiEnCours("");
    }
  };

  const changerStatut = async (doc, statut) => {
    setDocuments((docs) => docs.map((x) => (x.id === doc.id ? { ...x, statut } : x)));
    await base44.entities.DocumentEmis.update(doc.id, { statut });
  };

  if (documents === null) {
    return (
      <div className="flex justify-center py-10">
        <Loader2 className="h-5 w-5 animate-spin text-[#8A7356]" />
      </div>
    );
  }

  if (documents.length === 0) {
    return <EmptyState icon={FileText} titre="Aucun document émis" texte="Créez un devis, un contrat ou une facture pour commencer." action="Créer un document" onAction={onCreer} />;
  }

  return (
    <>
      <ul className="space-y-3 md:hidden">
        {documents.map((doc) => (
          <li key={doc.id} className="min-w-0 rounded-2xl border border-[#B49B72]/25 bg-white p-4">
            <div className="flex min-w-0 items-start justify-between gap-3">
              <div className="min-w-0"><p className="font-semibold text-[#1C1917]">{LIBELLES[doc.type] || doc.type} {doc.numero}</p><p className="mt-1 overflow-wrap-anywhere text-sm text-[#57534E]">{doc.clientNom}</p></div>
              <p className="shrink-0 font-semibold text-[#1C1917]">{Number(doc.montant || 0).toLocaleString("fr-FR", { minimumFractionDigits: 2 })} €</p>
            </div>
            <div className="mt-4 grid grid-cols-1 gap-2 min-[480px]:grid-cols-2">
              <select value={doc.statut || "emis"} onChange={(e) => changerStatut(doc, e.target.value)} aria-label={`Statut du document ${doc.numero}`} className={`min-h-[44px] w-full rounded-full px-3 text-xs font-medium border-0 focus:ring-2 focus:ring-[#8A7356] ${(STATUTS_DOCUMENT[doc.statut || "emis"] || STATUTS_DOCUMENT.emis).classe}`}>{Object.entries(STATUTS_DOCUMENT).map(([v, s]) => <option key={v} value={v}>{s.libelle}</option>)}</select>
              {doc.clientEmail && doc.fichierUrl && <button onClick={() => envoyerParEmail(doc)} disabled={!!envoiEnCours} className="inline-flex min-h-[44px] w-full items-center justify-center gap-2 rounded-full border border-[#B49B72]/40 text-sm font-medium">{envoiEnCours === doc.id ? <Loader2 className="h-4 w-4 animate-spin" /> : envoyes.includes(doc.id) ? <Check className="h-4 w-4 text-green-600" /> : <Mail className="h-4 w-4" />}{envoyes.includes(doc.id) ? "Envoyé" : "Envoyer par e-mail"}</button>}
            </div>
          </li>
        ))}
      </ul>
      <div className="hidden rounded-xl border border-[#B49B72]/25 bg-white md:block md:overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="bg-[#FAF7F2] text-left text-xs uppercase tracking-wide text-[#8A7356]">
            <th className="px-4 py-3">Numéro</th>
            <th className="px-4 py-3">Type</th>
            <th className="px-4 py-3">Client</th>
            <th className="px-4 py-3 text-right">Montant</th>
            <th className="px-4 py-3">Statut</th>
            <th className="px-4 py-3 text-right">Envoi</th>
          </tr>
        </thead>
        <tbody>
          {documents.map((doc) => (
            <tr key={doc.id} className="border-t border-[#B49B72]/15 text-[#1C1917]">
              <td className="px-4 py-3 font-medium">{doc.numero}</td>
              <td className="px-4 py-3">{LIBELLES[doc.type] || doc.type}</td>
              <td className="px-4 py-3">{doc.clientNom}</td>
              <td className="px-4 py-3 text-right">{Number(doc.montant || 0).toLocaleString("fr-FR", { minimumFractionDigits: 2 })} €</td>
              <td className="px-4 py-3">
                <select
                  value={doc.statut || "emis"}
                  onChange={(e) => changerStatut(doc, e.target.value)}
                  aria-label={`Statut du document ${doc.numero}`}
                  className={`min-h-[32px] rounded-full px-2 text-xs font-medium border-0 focus:outline-none focus:ring-1 focus:ring-[#8A7356] ${(STATUTS_DOCUMENT[doc.statut || "emis"] || STATUTS_DOCUMENT.emis).classe}`}
                >
                  {Object.entries(STATUTS_DOCUMENT).map(([v, s]) => (
                    <option key={v} value={v}>{s.libelle}</option>
                  ))}
                </select>
              </td>
              <td className="px-4 py-3 text-right">
                {doc.clientEmail && doc.fichierUrl ? (
                  <button
                    onClick={() => envoyerParEmail(doc)}
                    disabled={!!envoiEnCours}
                    className="inline-flex items-center gap-1.5 min-h-[32px] px-3 rounded-full border border-[#B49B72]/40 text-xs font-medium hover:bg-[#FAF7F2] disabled:opacity-60"
                  >
                    {envoiEnCours === doc.id ? (
                      <Loader2 className="h-3.5 w-3.5 animate-spin" />
                    ) : envoyes.includes(doc.id) ? (
                      <Check className="h-3.5 w-3.5 text-green-600" />
                    ) : (
                      <Mail className="h-3.5 w-3.5" />
                    )}
                    {envoyes.includes(doc.id) ? "Envoyé" : "E-mail"}
                  </button>
                ) : (
                  <span className="text-xs text-[#57534E]/60">—</span>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      </div>
    </>
  );
}