import React from "react";
import { Trash2, FileText, Phone, MapPin, CalendarDays } from "lucide-react";

const STATUTS = ["Nouvelle demande", "À contacter", "Disponible", "Indisponible", "Confirmée", "Archivée"];

export default function DemandeCarte({ demande: d, onChangerStatut, onCreerDocument, onSupprimer, lieEvenement }) {
  const [a, m, j] = String(d.dateEvenement || "").split("-");
  const dateFr = d.dateEvenement ? `${j}/${m}/${a}` : "—";
  return (
    <div className="rounded-xl border border-[#B49B72]/25 bg-white p-5 shadow-sm">
      <div>
        <p className="font-heading text-lg text-[#1C1917]">{d.prenom} {d.nom}</p>
        <div className="flex items-center gap-2 flex-wrap">
          <p className="text-sm text-[#8A7356] font-medium">{d.typeEvenement}</p>
          {d.reference && (
            <span className="text-[11px] font-mono text-[#57534E] bg-[#FAF7F2] rounded px-1.5 py-0.5">{d.reference}</span>
          )}
          {lieEvenement && (
            <span className="text-[11px] font-medium text-green-700 bg-green-50 rounded-full px-2 py-0.5">Événement lié</span>
          )}
        </div>
      </div>
      <div className="mt-3 grid grid-cols-1 md:grid-cols-3 gap-2 text-sm text-[#44403C]">
        <p className="flex items-center gap-2"><CalendarDays className="h-4 w-4 text-[#8A7356]" /> {dateFr} · {d.heureDebut} – {d.heureFin}</p>
        <p className="flex items-center gap-2"><Phone className="h-4 w-4 text-[#8A7356]" /> {d.telephone}</p>
        <p className="flex items-center gap-2"><MapPin className="h-4 w-4 text-[#8A7356]" /> {d.adresseEvenement}</p>
      </div>
      {d.informationsComplementaires && (
        <p className="mt-3 text-sm text-[#57534E] bg-[#FAF7F2] rounded-lg p-3">{d.informationsComplementaires}</p>
      )}
      <div className="mt-4 flex flex-wrap items-center gap-3">
        <select
          value={d.statut}
          onChange={(e) => onChangerStatut(d, e.target.value)}
          className="min-h-[38px] rounded-lg border border-[#B49B72]/40 bg-white px-3 text-sm text-[#1C1917] focus:outline-none focus:border-[#8A7356]"
        >
          {STATUTS.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
        <button
          onClick={() => onCreerDocument(d)}
          className="min-h-[38px] px-4 rounded-lg bg-[#1C1917] text-[#FAF7F2] text-sm font-medium flex items-center gap-2 hover:bg-[#33302B] transition-colors"
        >
          <FileText className="h-4 w-4" /> Créer un document
        </button>
        <button
          onClick={() => onSupprimer(d)}
          className="min-h-[38px] px-2 text-[#57534E] hover:text-red-500 transition-colors"
          aria-label="Supprimer la demande"
        >
          <Trash2 className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}