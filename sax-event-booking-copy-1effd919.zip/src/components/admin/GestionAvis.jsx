import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Star, Loader2, Trash2, Eye, EyeOff } from "lucide-react";

export default function GestionAvis({ email }) {
  const [avis, setAvis] = useState(null);
  const [enCours, setEnCours] = useState("");

  const charger = async () => {
    setAvis(await base44.entities.Temoignage.filter({ proprietaire: email }, "-created_date", 200));
  };

  useEffect(() => { charger(); }, [email]);

  const basculer = async (t) => {
    setEnCours(t.id);
    try {
      await base44.entities.Temoignage.update(t.id, { approuve: !t.approuve });
      await charger();
    } finally { setEnCours(""); }
  };

  const supprimer = async (t) => {
    if (!window.confirm(`Supprimer définitivement l'avis de ${t.nom} ?`)) return;
    setEnCours(t.id);
    try {
      await base44.entities.Temoignage.delete(t.id);
      await charger();
    } finally { setEnCours(""); }
  };

  if (avis === null) {
    return <div className="flex justify-center py-16"><Loader2 className="h-6 w-6 animate-spin text-[#8A7356]" /></div>;
  }

  if (!avis.length) {
    return <p className="text-center text-[#57534E] py-12">Aucun avis reçu pour le moment.</p>;
  }

  return (
    <div className="space-y-4">
      <p className="text-sm text-[#57534E]">
        Seuls les avis <strong>publiés</strong> apparaissent sur le profil public.
      </p>
      {avis.map((t) => (
        <div key={t.id} className="rounded-xl border border-[#B49B72]/25 bg-white p-5 shadow-sm">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <div className="flex items-center gap-2">
                <p className="font-bold text-sm">{t.nom}</p>
                <span className={`text-[10px] font-bold uppercase tracking-wide rounded-full px-2.5 py-0.5 ${
                  t.approuve ? "bg-[#C8A85C]/20 text-[#8A7356]" : "bg-[#1C1917]/10 text-[#57534E]"
                }`}>
                  {t.approuve ? "Publié" : "En attente"}
                </span>
              </div>
              <div className="flex items-center gap-0.5 mt-1.5">
                {[1, 2, 3, 4, 5].map((n) => (
                  <Star key={n} className={`h-3.5 w-3.5 ${n <= t.note ? "fill-[#C8A85C] text-[#C8A85C]" : "text-[#B49B72]/30"}`} />
                ))}
                {t.typeEvenement && <span className="text-xs text-[#8A7356] ml-2">{t.typeEvenement}</span>}
              </div>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => basculer(t)}
                disabled={enCours === t.id}
                className="min-h-[38px] px-4 rounded-full bg-[#1C1917] text-[#FAF7F2] text-xs font-bold flex items-center gap-1.5 hover:bg-[#33302B] disabled:opacity-60"
              >
                {t.approuve ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                {t.approuve ? "Masquer" : "Publier"}
              </button>
              <button
                onClick={() => supprimer(t)}
                disabled={enCours === t.id}
                aria-label="Supprimer l'avis"
                className="min-h-[38px] px-3 rounded-full border border-[#B49B72]/40 text-[#B3261E] hover:bg-[#FAF7F2] disabled:opacity-60"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
          </div>
          <p className="text-sm text-[#44403C] leading-relaxed mt-3">« {t.message} »</p>
        </div>
      ))}
    </div>
  );
}