import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Loader2, Inbox, CalendarCheck, Euro, Star, FileCheck2 } from "lucide-react";
import GraphiqueActivite from "@/components/admin/GraphiqueActivite";

export default function StatistiquesAdmin({ email }) {
  const [stats, setStats] = useState(null);

  useEffect(() => {
    Promise.all([
      base44.entities.DemandesDisponibilite.filter({ proprietaire: email }, "-created_date", 500),
      base44.entities.DocumentEmis.filter({ proprietaire: email }, "-created_date", 500),
      base44.entities.Temoignage.filter({ proprietaire: email }, "-created_date", 500),
    ]).then(([demandes, documents, avis]) => {
      const moisCourant = new Date().toISOString().slice(0, 7);
      const confirmees = demandes.filter((d) => d.statut === "Confirmée").length;
      const caFacture = documents
        .filter((d) => d.type === "facture")
        .reduce((s, d) => s + Number(d.montant || 0), 0);
      const devisAcceptes = documents.filter(
        (d) => d.type === "devis" && ["accepte", "paye"].includes(d.statut)
      );
      const caDevisAcceptes = devisAcceptes.reduce((s, d) => s + Number(d.montant || 0), 0);
      setStats({
        demandes,
        documents,
        caDevisAcceptes,
        nbDevisAcceptes: devisAcceptes.length,
        total: demandes.length,
        ceMois: demandes.filter((d) => (d.created_date || "").startsWith(moisCourant)).length,
        confirmees,
        tauxConfirmation: demandes.length ? Math.round((confirmees / demandes.length) * 100) : 0,
        caFacture,
        nbDevis: documents.filter((d) => d.type === "devis").length,
        nbFactures: documents.filter((d) => d.type === "facture").length,
        avisEnAttente: avis.filter((a) => !a.approuve).length,
        noteMoyenne: avis.length
          ? (avis.reduce((s, a) => s + Number(a.note || 0), 0) / avis.length).toFixed(1)
          : "—",
      });
    });
  }, [email]);

  if (!stats) return <Loader2 className="h-6 w-6 animate-spin text-[#8A7356] mx-auto my-10" />;

  const cartes = [
    { icone: Inbox, libelle: "Demandes reçues", valeur: stats.total, detail: `${stats.ceMois} ce mois-ci` },
    { icone: CalendarCheck, libelle: "Prestations confirmées", valeur: stats.confirmees, detail: `Taux de confirmation : ${stats.tauxConfirmation} %` },
    { icone: Euro, libelle: "CA facturé", valeur: `${stats.caFacture.toLocaleString("fr-FR", { minimumFractionDigits: 2 })} €`, detail: `${stats.nbFactures} facture(s) · ${stats.nbDevis} devis` },
    { icone: FileCheck2, libelle: "Devis acceptés", valeur: `${stats.caDevisAcceptes.toLocaleString("fr-FR", { minimumFractionDigits: 2 })} €`, detail: `${stats.nbDevisAcceptes} devis accepté(s) ou payé(s)` },
    { icone: Star, libelle: "Note moyenne", valeur: `${stats.noteMoyenne}/5`, detail: stats.avisEnAttente ? `${stats.avisEnAttente} avis en attente` : "Aucun avis en attente" },
  ];

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {cartes.map(({ icone: Icone, libelle, valeur, detail }) => (
          <div key={libelle} className="rounded-xl border border-[#B49B72]/25 bg-white p-5">
            <p className="flex items-center gap-2 text-xs font-bold uppercase tracking-wide text-[#8A7356]">
              <Icone className="h-4 w-4" /> {libelle}
            </p>
            <p className="font-heading text-3xl mt-2">{valeur}</p>
            <p className="text-xs text-[#57534E] mt-1">{detail}</p>
          </div>
        ))}
      </div>
      <GraphiqueActivite demandes={stats.demandes} documents={stats.documents} />
    </div>
  );
}