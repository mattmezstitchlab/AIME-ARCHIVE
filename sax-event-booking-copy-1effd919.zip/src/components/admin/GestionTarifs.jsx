import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Loader2, Plus, Trash2, Save } from "lucide-react";

const classeInput =
  "w-full rounded-lg border border-[#B49B72]/40 bg-white px-3 py-2 text-sm text-[#1C1917] focus:border-[#8A7356] focus:outline-none";
const classeLabel = "text-xs font-bold uppercase tracking-wide text-[#8A7356]";

export default function GestionTarifs({ email }) {
  const [formules, setFormules] = useState([]);
  const [chargement, setChargement] = useState(true);
  const [sauvegarde, setSauvegarde] = useState(null);

  useEffect(() => {
    base44.entities.FormuleTarif.filter({ proprietaire: email }, "ordre", 50).then((l) => {
      setFormules(l.map((f) => ({ ...f, detailsTexte: (f.details || []).join("\n") })));
      setChargement(false);
    });
  }, [email]);

  const changer = (id, champ, valeur) => {
    setFormules((l) => l.map((f) => (f.id === id ? { ...f, [champ]: valeur } : f)));
  };

  const sauvegarder = async (f) => {
    setSauvegarde(f.id);
    await base44.entities.FormuleTarif.update(f.id, {
      nom: f.nom, prix: f.prix, duree: f.duree, populaire: !!f.populaire,
      details: f.detailsTexte.split("\n").map((d) => d.trim()).filter(Boolean),
    });
    setSauvegarde(null);
  };

  const ajouter = async () => {
    const cree = await base44.entities.FormuleTarif.create({
      proprietaire: email, nom: "Nouvelle formule", prix: "à partir de 0 €", duree: "", details: [], ordre: formules.length,
    });
    setFormules((l) => [...l, { ...cree, detailsTexte: "" }]);
  };

  const supprimer = async (f) => {
    await base44.entities.FormuleTarif.delete(f.id);
    setFormules((l) => l.filter((x) => x.id !== f.id));
  };

  if (chargement) return <Loader2 className="h-6 w-6 animate-spin text-[#8A7356] mx-auto my-10" />;

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <h3 className="font-heading text-lg">Formules tarifaires</h3>
        <button onClick={ajouter}
          className="min-h-[42px] px-4 rounded-full bg-[#1C1917] text-[#FAF7F2] text-sm font-medium inline-flex items-center gap-2 hover:bg-[#33302B]">
          <Plus className="h-4 w-4" /> Ajouter une formule
        </button>
      </div>
      <div className="space-y-4">
        {formules.map((f) => (
          <div key={f.id} className="rounded-xl border border-[#B49B72]/30 bg-white p-4 space-y-3">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div>
                <label className={classeLabel}>Nom</label>
                <input className={classeInput} value={f.nom} onChange={(e) => changer(f.id, "nom", e.target.value)} />
              </div>
              <div>
                <label className={classeLabel}>Prix</label>
                <input className={classeInput} value={f.prix} onChange={(e) => changer(f.id, "prix", e.target.value)} />
              </div>
              <div>
                <label className={classeLabel}>Durée</label>
                <input className={classeInput} value={f.duree || ""} onChange={(e) => changer(f.id, "duree", e.target.value)} />
              </div>
            </div>
            <div>
              <label className={classeLabel}>Détails (un par ligne)</label>
              <textarea rows={4} className={`${classeInput} resize-y`} value={f.detailsTexte}
                onChange={(e) => changer(f.id, "detailsTexte", e.target.value)} />
            </div>
            <div className="flex items-center gap-4 flex-wrap">
              <label className="text-sm text-[#44403C] flex items-center gap-2">
                <input type="checkbox" checked={!!f.populaire}
                  onChange={(e) => changer(f.id, "populaire", e.target.checked)} />
                Badge « Populaire »
              </label>
              <button onClick={() => sauvegarder(f)} disabled={sauvegarde === f.id}
                className="text-xs text-[#8A7356] flex items-center gap-1 font-bold hover:underline disabled:opacity-60">
                {sauvegarde === f.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}
                Enregistrer
              </button>
              <button onClick={() => supprimer(f)}
                className="text-xs text-[#B3261E] flex items-center gap-1 hover:underline">
                <Trash2 className="h-3.5 w-3.5" /> Supprimer
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}