import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Loader2, Orbit } from "lucide-react";

const classeInput =
  "w-full rounded-lg border border-[#B49B72]/40 bg-white px-3 py-2 text-sm text-[#1C1917] focus:border-[#8A7356] focus:outline-none";

export default function GenerateurAPropos({ onGenere }) {
  const [notes, setNotes] = useState("");
  const [enCours, setEnCours] = useState(false);
  const [erreur, setErreur] = useState("");

  const generer = async () => {
    if (!notes.trim()) { setErreur("Donnez quelques informations pour générer votre présentation."); return; }
    setErreur("");
    setEnCours(true);
    try {
      const resultat = await base44.integrations.Core.InvokeLLM({
        prompt: `Tu es un rédacteur spécialisé dans les biographies d'artistes et prestataires événementiels français.
À partir des informations brutes suivantes, rédige en français :
1. Une présentation "À propos" à la première personne, chaleureuse et professionnelle, en 2 à 4 paragraphes (le premier paragraphe est une accroche forte d'une ou deux phrases).
2. 3 points forts (titre court + une phrase).
3. Une timeline de repères de vie (jalons) : pour chaque moment clé mentionné ou déductible (naissance, débuts, formation, rencontres, tournants…), donne l'année (ou la période), un titre très court et une phrase. Classe-les du plus ancien au plus récent. N'invente aucun fait ni aucune date : utilise uniquement les informations fournies.

Informations brutes :
${notes}`,
        response_json_schema: {
          type: "object",
          properties: {
            paragraphes: { type: "array", items: { type: "string" } },
            valeurs: {
              type: "array",
              items: { type: "object", properties: { titre: { type: "string" }, texte: { type: "string" } } },
            },
            jalons: {
              type: "array",
              items: { type: "object", properties: { annee: { type: "string" }, titre: { type: "string" }, texte: { type: "string" } } },
            },
          },
        },
      });
      onGenere(resultat);
    } catch (_e) {
      setErreur("La génération a échoué, réessayez.");
    } finally {
      setEnCours(false);
    }
  };

  return (
    <div className="rounded-lg border border-[#B49B72]/25 bg-[#FAF7F2] p-3 space-y-2">
      <p className="text-xs font-bold uppercase tracking-wide text-[#8A7356]">Générer ma présentation</p>
      <textarea
        rows={4}
        className={`${classeInput} resize-y`}
        placeholder="Racontez en vrac : votre parcours, année de naissance, débuts, formation, moments clés, style, ce qui vous anime…"
        value={notes}
        onChange={(e) => setNotes(e.target.value)}
      />
      {erreur && <p className="text-xs text-[#B3261E]" role="alert">{erreur}</p>}
      <button
        onClick={generer}
        disabled={enCours}
        className="min-h-[42px] px-5 rounded-full bg-[#1C1917] text-[#FAF7F2] text-sm font-bold inline-flex items-center gap-2 hover:bg-[#33302B] disabled:opacity-70"
      >
        {enCours ? <Loader2 className="h-4 w-4 animate-spin" /> : <Orbit className="h-4 w-4" />}
        {enCours ? "Rédaction en cours…" : "Générer texte, points forts & timeline"}
      </button>
      <p className="text-[11px] text-[#57534E]">Le résultat remplit les champs ci-dessous — relisez, ajustez, puis enregistrez.</p>
    </div>
  );
}