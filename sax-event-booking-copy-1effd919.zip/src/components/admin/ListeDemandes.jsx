import React, { useCallback, useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Loader2, CalendarCheck } from "lucide-react";
import DemandeCarte from "@/components/admin/DemandeCarte";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const STATUTS = ["Nouvelle demande", "À contacter", "Disponible", "Indisponible", "Confirmée", "Archivée"];
const TAILLE_PAGE = 20;

// Réponse automatique envoyée au demandeur selon le nouveau statut.
function construireEmailReponse(d, statut) {
  const [a, m, j] = String(d.dateEvenement || "").split("-");
  const dateFr = d.dateEvenement ? `${j}/${m}/${a}` : "";
  const type = (d.typeEvenement || "événement").toLowerCase();
  const ref = d.reference ? `\n\nRéférence de votre demande : ${d.reference}` : "";
  if (statut === "Disponible") {
    return {
      sujet: `Bonne nouvelle — disponible pour votre ${type} du ${dateFr}`,
      corps: `Bonjour ${d.prenom},\n\nBonne nouvelle : je suis disponible pour votre ${type} du ${dateFr}.\n\nJe reviens vers vous très rapidement pour préciser les détails et vous transmettre un devis.${ref}\n\nÀ très bientôt`,
    };
  }
  if (statut === "Indisponible") {
    return {
      sujet: `Votre demande pour le ${dateFr}`,
      corps: `Bonjour ${d.prenom},\n\nMerci pour votre demande concernant votre ${type} du ${dateFr}.\n\nMalheureusement, je ne suis pas disponible à cette date. N'hésitez pas à me recontacter si vos dates évoluent.${ref}\n\nBien cordialement`,
    };
  }
  if (statut === "Confirmée") {
    return {
      sujet: `C'est confirmé — votre ${type} du ${dateFr}`,
      corps: `Bonjour ${d.prenom},\n\nVotre ${type} du ${dateFr} est confirmé. La date est réservée pour vous.\n\nJe reviens vers vous prochainement avec les prochaines étapes.${ref}\n\nÀ très bientôt`,
    };
  }
  return null;
}

export default function ListeDemandes({ onCreerDocument, email }) {
  const [demandes, setDemandes] = useState(null);
  const [filtreStatut, setFiltreStatut] = useState("Tous");
  const [limite, setLimite] = useState(TAILLE_PAGE);
  const [aPlus, setAPlus] = useState(false);
  const [aSupprimer, setASupprimer] = useState(null);
  const [info, setInfo] = useState("");
  const [recherche, setRecherche] = useState("");
  const [statutEnCours, setStatutEnCours] = useState(false);
  const [demandesLiees, setDemandesLiees] = useState(new Set());

  const charger = useCallback(async () => {
    const requete = { proprietaire: email };
    if (filtreStatut !== "Tous") requete.statut = filtreStatut;
    if (recherche.trim()) requete.reference = recherche.trim().toUpperCase();
    const [liste, evenements] = await Promise.all([
      base44.entities.DemandesDisponibilite.filter(requete, "-created_date", limite + 1),
      base44.entities.Evenement.filter({ proprietaire: email }, "-created_date", 200),
    ]);
    setDemandesLiees(new Set(evenements.filter((e) => e.demandeId).map((e) => e.demandeId)));
    setAPlus(liste.length > limite);
    setDemandes(liste.slice(0, limite));
  }, [email, filtreStatut, limite, recherche]);

  useEffect(() => { charger(); }, [charger]);

  const changerStatut = async (demande, statut) => {
    if (statutEnCours) return; // évite le double clic (double événement)
    setStatutEnCours(true);
    try {
      const ancienStatut = demande.statut;
      await base44.entities.DemandesDisponibilite.update(demande.id, { statut });
      // Réponse automatique au demandeur pour Disponible / Indisponible / Confirmée.
      const reponse = construireEmailReponse(demande, statut);
      if (reponse && demande.email && statut !== ancienStatut) {
        await base44.integrations.Core.SendEmail({ to: demande.email, subject: reponse.sujet, body: reponse.corps });
        if (statut !== "Confirmée") {
          setInfo(`Réponse « ${statut} » envoyée par e-mail à ${demande.prenom} ${demande.nom} (${demande.email}).`);
        }
      }
      if (statut === "Confirmée") {
        const lies = await base44.entities.Evenement.filter({ demandeId: demande.id }, "-created_date", 1);
        if (lies.length === 0) {
          await base44.entities.Evenement.create({
            proprietaire: email,
            demandeId: demande.id,
            titre: `${demande.typeEvenement} — ${demande.prenom} ${demande.nom}`,
            typeEvenement: demande.typeEvenement,
            date: demande.dateEvenement,
            lieu: demande.adresseEvenement,
            organisateurNom: `${demande.prenom} ${demande.nom}`,
            organisateurEmail: demande.email,
            organisateurTelephone: demande.telephone,
            statut: "confirme",
          });
          setInfo(`Événement créé dans l'onglet Événements pour ${demande.prenom} ${demande.nom}. Un e-mail de confirmation lui a été envoyé et la date est bloquée sur votre calendrier public.`);
        }
      } else if (ancienStatut === "Confirmée") {
        // La demande n'est plus confirmée : on annule l'événement lié encore confirmé.
        const lies = await base44.entities.Evenement.filter({ demandeId: demande.id }, "-created_date", 5);
        const aAnnuler = lies.filter((e) => e.statut === "confirme");
        for (const evt of aAnnuler) {
          await base44.entities.Evenement.update(evt.id, { statut: "annule" });
        }
        if (aAnnuler.length > 0) {
          setInfo("L'événement lié a été annulé. La date reste bloquée si une autre entrée l'occupe encore.");
        }
      }
      charger();
    } finally {
      setStatutEnCours(false);
    }
  };

  const supprimer = async () => {
    await base44.entities.DemandesDisponibilite.delete(aSupprimer.id);
    setASupprimer(null);
    charger();
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <select
          value={filtreStatut}
          onChange={(e) => { setFiltreStatut(e.target.value); setLimite(TAILLE_PAGE); }}
          aria-label="Filtrer par statut"
          className="min-h-[38px] rounded-full border border-[#B49B72]/40 bg-white px-4 text-xs font-medium text-[#1C1917] focus:outline-none focus:border-[#8A7356]"
        >
          <option value="Tous">Tous les statuts</option>
          {STATUTS.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
        <input
          type="search"
          value={recherche}
          onChange={(e) => { setRecherche(e.target.value); setLimite(TAILLE_PAGE); }}
          placeholder="Référence (ex. DEM-A1B2C3D4)"
          aria-label="Rechercher par référence"
          className="min-h-[34px] w-56 rounded-full border border-[#B49B72]/40 bg-white px-4 text-xs text-[#1C1917] placeholder:text-[#57534E]/60 focus:outline-none focus:border-[#8A7356]"
        />
      </div>

      {info && (
        <div className="flex items-start gap-2 rounded-xl border border-[#B49B72]/25 bg-white p-4 text-sm text-[#1C1917]">
          <CalendarCheck className="h-4 w-4 mt-0.5 text-[#8A7356] shrink-0" />
          <p className="flex-1">{info}</p>
          <button onClick={() => setInfo("")} className="text-[#57534E] hover:text-[#1C1917] text-xs">Fermer</button>
        </div>
      )}

      {demandes === null ? (
        <div className="flex justify-center py-16">
          <Loader2 className="h-6 w-6 animate-spin text-[#8A7356]" />
        </div>
      ) : demandes.length === 0 ? (
        <p className="text-center py-16 text-[#57534E]">
          {filtreStatut === "Tous" ? "Aucune demande pour le moment." : `Aucune demande « ${filtreStatut} ».`}
        </p>
      ) : (
        <>
          {demandes.map((d) => (
            <DemandeCarte
              key={d.id}
              demande={d}
              onChangerStatut={changerStatut}
              onCreerDocument={onCreerDocument}
              onSupprimer={setASupprimer}
              lieEvenement={demandesLiees.has(d.id)}
            />
          ))}
          {aPlus && (
            <div className="flex justify-center pt-2">
              <button
                onClick={() => setLimite((l) => l + TAILLE_PAGE)}
                className="min-h-[42px] px-6 rounded-full border border-[#B49B72]/40 text-sm font-medium text-[#1C1917] hover:bg-[#FAF7F2] transition-colors"
              >
                Afficher plus de demandes
              </button>
            </div>
          )}
        </>
      )}

      <AlertDialog open={!!aSupprimer} onOpenChange={(o) => !o && setASupprimer(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Supprimer cette demande ?</AlertDialogTitle>
            <AlertDialogDescription>
              {aSupprimer && `La demande de ${aSupprimer.prenom} ${aSupprimer.nom} sera définitivement supprimée.`}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annuler</AlertDialogCancel>
            <AlertDialogAction onClick={supprimer}>Supprimer</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}