import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { ExternalLink, Check, Lock, Loader2 } from "lucide-react";
import ModuleMiniSite from "@/components/admin/ModuleMiniSite";
import GestionProfil from "@/components/admin/GestionProfil";
import GestionAPropos from "@/components/admin/GestionAPropos";
import GestionIntermittent from "@/components/admin/GestionIntermittent";
import GestionGalerie from "@/components/admin/GestionGalerie";
import GestionRepertoire from "@/components/admin/GestionRepertoire";
import GestionTarifs from "@/components/admin/GestionTarifs";
import GestionAvis from "@/components/admin/GestionAvis";
import GestionFaq from "@/components/admin/GestionFaq";
import ApparenceMiniSite from "@/components/admin/ApparenceMiniSite";

const MODULES = [
  ["apropos", "À propos", "Présentation, photo, valeurs et timeline de vie", GestionAPropos],
  ["intermittent", "Intermittent", "Statut professionnel du spectacle", GestionIntermittent],
  ["galerie", "Galerie", "Votre activité en images", GestionGalerie],
  ["repertoire", "Répertoire", "Styles, ambiances et morceaux", GestionRepertoire],
  ["tarifs", "Tarifs", "Formules et expériences", GestionTarifs],
  ["avis", "Avis", "Témoignages de vos clients", GestionAvis],
  ["faq", "FAQ", "Questions fréquentes", GestionFaq],
];

export default function EditeurMiniSite({ email }) {
  const [profil, setProfil] = useState(undefined);
  const [enregistre, setEnregistre] = useState(false);

  useEffect(() => {
    base44.entities.ProfilPrestataire.filter({ proprietaire: email }, "-updated_date", 1)
      .then((l) => setProfil(l[0] || null));
  }, [email]);

  if (profil === undefined) {
    return <Loader2 className="h-6 w-6 animate-spin text-[var(--p-muted)]" />;
  }

  const masquees = profil?.sectionsMasquees || [];
  const cles = MODULES.map(([c]) => c);
  const ordreBrut = (profil?.ordreSections || []).filter((c) => cles.includes(c));
  const ordre = [...ordreBrut, ...cles.filter((c) => !ordreBrut.includes(c))];

  const sauver = async (patch) => {
    if (!profil) return;
    setProfil((p) => ({ ...p, ...patch }));
    await base44.entities.ProfilPrestataire.update(profil.id, patch);
    setEnregistre(true);
    setTimeout(() => setEnregistre(false), 1800);
  };

  const deplacer = (index, dir) => {
    const j = index + dir;
    if (j < 0 || j >= ordre.length) return;
    const l = [...ordre];
    [l[index], l[j]] = [l[j], l[index]];
    sauver({ ordreSections: l });
  };

  const basculer = (cle) => {
    sauver({
      sectionsMasquees: masquees.includes(cle) ? masquees.filter((m) => m !== cle) : [...masquees, cle],
    });
  };

  return (
    <div className="max-w-3xl space-y-8">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm text-[var(--p-muted)]">
          Votre mini-site, tout en un : identité en haut, puis chaque section — dépliez-la pour modifier son contenu, masquez-la ou changez son ordre.
        </p>
        {enregistre && (
          <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-[var(--p-text)]">
            <Check className="h-3.5 w-3.5" /> Enregistré
          </span>
        )}
      </div>

      {profil?.slug && (
        <Link
          to={`/p/${profil.slug}`}
          className="inline-flex items-center gap-2 min-h-[44px] px-5 rounded-full bg-[var(--p-cta)] text-[var(--p-cta-text)] text-sm font-semibold hover:bg-[var(--p-cta-hover)] transition-colors"
        >
          <ExternalLink className="h-4 w-4" /> Voir mon mini-site
        </Link>
      )}

      {/* Identité : couverture, photo, nom, accroche */}
      <div>
        <h2 className="text-xs font-bold uppercase tracking-[0.2em] text-[var(--p-muted)] mb-3">Identité</h2>
        <GestionProfil email={email} onProfilChange={setProfil} />
      </div>

      {/* Apparence : style graphique et affichage des visuels */}
      {profil && (
        <div>
          <h2 className="text-xs font-bold uppercase tracking-[0.2em] text-[var(--p-muted)] mb-3">Apparence</h2>
          <ApparenceMiniSite profil={profil} onSauver={sauver} />
        </div>
      )}

      {/* Sections du mini-site */}
      <div>
        <h2 className="text-xs font-bold uppercase tracking-[0.2em] text-[var(--p-muted)] mb-3">Sections du mini-site</h2>
        {!profil && (
          <p className="mb-3 text-sm text-[var(--p-muted)]">
            Enregistrez d'abord votre identité ci-dessus pour activer l'ordre et la visibilité des sections.
          </p>
        )}
        <ol className="space-y-2">
          {ordre.map((cle, i) => {
            const [, libelle, description, Editeur] = MODULES.find(([c]) => c === cle);
            return (
              <ModuleMiniSite
                key={cle}
                libelle={libelle}
                description={description}
                visible={!masquees.includes(cle)}
                onToggle={() => basculer(cle)}
                onMonter={() => deplacer(i, -1)}
                onDescendre={() => deplacer(i, 1)}
                premier={i === 0}
                dernier={i === ordre.length - 1}
              >
                <Editeur email={email} />
              </ModuleMiniSite>
            );
          })}
          {/* Le contact reste toujours en dernier — c'est la raison d'être du mini-site. */}
          <li className="flex items-center gap-3 rounded-2xl bg-[var(--p-bg)] border border-dashed border-[var(--p-border-strong)] px-4 py-3">
            <Lock className="h-4 w-4 text-[var(--p-muted)] ml-2 mr-1" aria-hidden="true" />
            <div className="flex-1">
              <p className="text-sm font-semibold text-[var(--p-text)]">Contact & disponibilités</p>
              <p className="text-xs text-[var(--p-muted)]">Toujours affiché, toujours en dernier.</p>
            </div>
          </li>
        </ol>
      </div>
    </div>
  );
}