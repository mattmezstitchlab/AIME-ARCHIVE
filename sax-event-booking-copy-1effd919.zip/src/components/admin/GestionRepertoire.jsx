import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Loader2, Plus, Trash2, Save, Sparkles } from "lucide-react";
import { rechercherITunes, estimerBpmEtTonalite } from "@/lib/analyseMorceaux";

const classeInput =
  "w-full rounded-lg border border-[#B49B72]/40 bg-white px-3 py-2 text-sm text-[#1C1917] focus:border-[#8A7356] focus:outline-none";
const classeLabel = "text-xs font-bold uppercase tracking-wide text-[#8A7356]";

export default function GestionRepertoire({ email }) {
  const [styles, setStyles] = useState([]);
  const [chargement, setChargement] = useState(true);
  const [sauvegarde, setSauvegarde] = useState(null);
  const [analyse, setAnalyse] = useState(null);

  useEffect(() => {
    base44.entities.StyleRepertoire.filter({ proprietaire: email }, "ordre", 50).then((l) => {
      setStyles(l.map((s) => ({ ...s, morceauxTexte: (s.morceaux || []).join("\n") })));
      setChargement(false);
    });
  }, [email]);

  const changer = (id, champ, valeur) => {
    setStyles((l) => l.map((s) => (s.id === id ? { ...s, [champ]: valeur } : s)));
  };

  const sauvegarder = async (s) => {
    setSauvegarde(s.id);
    await base44.entities.StyleRepertoire.update(s.id, {
      titre: s.titre, ambiance: s.ambiance,
      morceaux: s.morceauxTexte.split("\n").map((m) => m.trim()).filter(Boolean),
    });
    setSauvegarde(null);
  };

  // Analyse DJ : extrait 30 s + pochette + genre (iTunes) et BPM (IA) pour chaque ligne « Titre — Artiste ».
  const enrichir = async (s) => {
    const lignes = s.morceauxTexte.split("\n").map((m) => m.trim()).filter(Boolean);
    if (!lignes.length) return;
    setAnalyse(s.id);
    try {
      const morceaux = lignes.map((l) => {
        const [titre, artiste] = l.split(/\s*[—–]\s*|\s+-\s+/);
        return { titre: (titre || l).trim(), artiste: (artiste || "").trim() };
      });
      const [itunes, bpms] = await Promise.all([
        Promise.all(morceaux.map((m) => rechercherITunes(m.titre, m.artiste).catch(() => null))),
        estimerBpmEtTonalite(morceaux).catch(() => ({})),
      ]);
      const details = morceaux.map((m, i) => ({
        titre: m.titre,
        artiste: m.artiste,
        bpm: bpms[i]?.bpm || 0,
        genre: itunes[i]?.genre || "",
        previewUrl: itunes[i]?.previewUrl || "",
        pochetteUrl: itunes[i]?.pochetteUrl || "",
      }));
      await base44.entities.StyleRepertoire.update(s.id, { morceaux: lignes, morceauxDetails: details });
      changer(s.id, "morceauxDetails", details);
    } finally {
      setAnalyse(null);
    }
  };

  const ajouter = async () => {
    const cree = await base44.entities.StyleRepertoire.create({
      proprietaire: email, titre: "Nouveau style", ambiance: "", morceaux: [], ordre: styles.length,
    });
    setStyles((l) => [...l, { ...cree, morceauxTexte: "" }]);
  };

  const supprimer = async (s) => {
    await base44.entities.StyleRepertoire.delete(s.id);
    setStyles((l) => l.filter((x) => x.id !== s.id));
  };

  if (chargement) return <Loader2 className="h-6 w-6 animate-spin text-[#8A7356] mx-auto my-10" />;

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <h3 className="font-heading text-lg">Styles du répertoire</h3>
        <button onClick={ajouter}
          className="min-h-[42px] px-4 rounded-full bg-[#1C1917] text-[#FAF7F2] text-sm font-medium inline-flex items-center gap-2 hover:bg-[#33302B]">
          <Plus className="h-4 w-4" /> Ajouter un style
        </button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {styles.map((s) => (
          <div key={s.id} className="rounded-xl border border-[#B49B72]/30 bg-white p-4 space-y-3">
            <div>
              <label className={classeLabel}>Titre</label>
              <input className={classeInput} value={s.titre} onChange={(e) => changer(s.id, "titre", e.target.value)} />
            </div>
            <div>
              <label className={classeLabel}>Ambiance</label>
              <input className={classeInput} value={s.ambiance || ""} onChange={(e) => changer(s.id, "ambiance", e.target.value)} />
            </div>
            <div>
              <label className={classeLabel}>Morceaux (un par ligne, format « Titre — Artiste »)</label>
              <textarea rows={5} className={`${classeInput} resize-y`} value={s.morceauxTexte}
                onChange={(e) => changer(s.id, "morceauxTexte", e.target.value)} />
            </div>
            {s.morceauxDetails?.length > 0 && (
              <p className="text-xs text-[#57534E]">
                {s.morceauxDetails.length} morceau(x) analysé(s) — BPM, genre et extraits visibles sur votre mini-site.
              </p>
            )}
            <div className="flex items-center gap-4 flex-wrap">
              <button onClick={() => sauvegarder(s)} disabled={sauvegarde === s.id}
                className="text-xs text-[#8A7356] flex items-center gap-1 font-bold hover:underline disabled:opacity-60">
                {sauvegarde === s.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}
                Enregistrer
              </button>
              <button onClick={() => enrichir(s)} disabled={analyse === s.id}
                className="text-xs text-[#8A7356] flex items-center gap-1 font-bold hover:underline disabled:opacity-60">
                {analyse === s.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Sparkles className="h-3.5 w-3.5" />}
                {analyse === s.id ? "Analyse…" : "Analyser (BPM & extraits)"}
              </button>
              <button onClick={() => supprimer(s)}
                className="text-xs text-[#B3261E] flex items-center gap-1 hover:underline">
                <Trash2 className="h-3.5 w-3.5" /> Supprimer
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}