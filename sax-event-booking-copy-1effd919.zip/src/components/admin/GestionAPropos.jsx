import React, { useEffect, useRef, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Loader2, Save, Plus, Trash2, ImagePlus } from "lucide-react";
import GenerateurAPropos from "@/components/admin/GenerateurAPropos";
import GestionJalons from "@/components/admin/GestionJalons";

const classeInput =
  "w-full rounded-lg border border-[#B49B72]/40 bg-white px-3 py-2 text-sm text-[#1C1917] focus:border-[#8A7356] focus:outline-none";
const classeLabel = "text-xs font-bold uppercase tracking-wide text-[#8A7356]";

export default function GestionAPropos({ email }) {
  const [idRecord, setIdRecord] = useState(null);
  const [photoUrl, setPhotoUrl] = useState("");
  const [texte, setTexte] = useState("");
  const [valeurs, setValeurs] = useState([]);
  const [jalons, setJalons] = useState([]);
  const [chargement, setChargement] = useState(true);
  const [enCours, setEnCours] = useState(false);
  const [envoiPhoto, setEnvoiPhoto] = useState(false);
  const fichierRef = useRef(null);

  useEffect(() => {
    base44.entities.ContenuAPropos.filter({ proprietaire: email }, "-updated_date", 1).then((l) => {
      const c = l[0];
      if (c) {
        setIdRecord(c.id);
        setPhotoUrl(c.photoUrl || "");
        setTexte((c.paragraphes || []).join("\n\n"));
        setValeurs(c.valeurs || []);
        setJalons(c.jalons || []);
      }
      setChargement(false);
    });
  }, [email]);

  const changerPhoto = async (ev) => {
    const fichier = ev.target.files?.[0];
    if (!fichier) return;
    setEnvoiPhoto(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file: fichier });
      setPhotoUrl(file_url);
    } finally {
      setEnvoiPhoto(false);
      if (fichierRef.current) fichierRef.current.value = "";
    }
  };

  const changerValeur = (i, champ, v) => {
    setValeurs((l) => l.map((x, j) => (j === i ? { ...x, [champ]: v } : x)));
  };

  const sauvegarder = async () => {
    setEnCours(true);
    const donnees = {
      proprietaire: email,
      photoUrl,
      paragraphes: texte.split(/\n\s*\n/).map((p) => p.trim()).filter(Boolean),
      valeurs: valeurs.filter((v) => v.titre || v.texte),
      jalons: jalons.filter((j) => j.annee || j.titre || j.texte),
    };
    if (idRecord) {
      await base44.entities.ContenuAPropos.update(idRecord, donnees);
    } else {
      const cree = await base44.entities.ContenuAPropos.create(donnees);
      setIdRecord(cree.id);
    }
    setEnCours(false);
  };

  if (chargement) return <Loader2 className="h-6 w-6 animate-spin text-[#8A7356] mx-auto my-10" />;

  return (
    <div className="space-y-5">
      <h3 className="font-heading text-lg">Page « À propos »</h3>
      <div className="rounded-xl border border-[#B49B72]/30 bg-white p-4 space-y-4">
        <GenerateurAPropos
          onGenere={(r) => {
            if (r.paragraphes?.length) setTexte(r.paragraphes.join("\n\n"));
            if (r.valeurs?.length) setValeurs(r.valeurs);
            if (r.jalons?.length) setJalons(r.jalons);
          }}
        />
        <div>
          <label className={classeLabel}>Photo de présentation</label>
          <div className="mt-2 flex items-center gap-4">
            {photoUrl && <img src={photoUrl} alt="Présentation" className="h-24 w-32 object-cover rounded-lg border border-[#B49B72]/30" />}
            <label className="min-h-[40px] px-4 rounded-full border border-[#B49B72]/40 text-sm text-[#44403C] inline-flex items-center gap-2 cursor-pointer hover:bg-[#FAF7F2]">
              {envoiPhoto ? <Loader2 className="h-4 w-4 animate-spin" /> : <ImagePlus className="h-4 w-4" />}
              Changer la photo
              <input ref={fichierRef} type="file" accept="image/*" className="hidden" onChange={changerPhoto} disabled={envoiPhoto} />
            </label>
          </div>
        </div>
        <div>
          <label className={classeLabel}>Texte de présentation (séparez les paragraphes par une ligne vide)</label>
          <textarea rows={9} className={`${classeInput} resize-y`} value={texte} onChange={(e) => setTexte(e.target.value)} />
        </div>
        <div>
          <div className="flex items-center justify-between mb-2">
            <label className={classeLabel}>Points forts</label>
            <button onClick={() => setValeurs((l) => [...l, { titre: "", texte: "" }])}
              className="text-xs text-[#8A7356] font-bold flex items-center gap-1 hover:underline">
              <Plus className="h-3.5 w-3.5" /> Ajouter
            </button>
          </div>
          <div className="space-y-3">
            {valeurs.map((v, i) => (
              <div key={i} className="rounded-lg border border-[#B49B72]/25 p-3 space-y-2">
                <input className={classeInput} placeholder="Titre" value={v.titre || ""}
                  onChange={(e) => changerValeur(i, "titre", e.target.value)} />
                <textarea rows={2} className={`${classeInput} resize-y`} placeholder="Texte" value={v.texte || ""}
                  onChange={(e) => changerValeur(i, "texte", e.target.value)} />
                <button onClick={() => setValeurs((l) => l.filter((_, j) => j !== i))}
                  className="text-xs text-[#B3261E] flex items-center gap-1 hover:underline">
                  <Trash2 className="h-3.5 w-3.5" /> Retirer
                </button>
              </div>
            ))}
          </div>
        </div>
        <GestionJalons jalons={jalons} onChange={setJalons} />
        <button onClick={sauvegarder} disabled={enCours}
          className="min-h-[46px] px-6 rounded-full bg-[#1C1917] text-[#FAF7F2] text-sm font-bold inline-flex items-center gap-2 hover:bg-[#33302B] disabled:opacity-70">
          {enCours ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
          Enregistrer la page
        </button>
      </div>
    </div>
  );
}