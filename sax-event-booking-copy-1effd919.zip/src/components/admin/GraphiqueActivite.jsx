import React from "react";
import { ComposedChart, Bar, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";

// Évolution des 12 derniers mois : demandes reçues (barres) et CA facturé (courbe).
export default function GraphiqueActivite({ demandes, documents }) {
  const mois = [];
  const d = new Date();
  d.setDate(1);
  d.setMonth(d.getMonth() - 11);
  for (let i = 0; i < 12; i++) {
    const cle = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    mois.push({
      cle,
      label: d.toLocaleDateString("fr-FR", { month: "short" }),
      Demandes: 0,
      "CA facturé": 0,
    });
    d.setMonth(d.getMonth() + 1);
  }
  const parCle = Object.fromEntries(mois.map((m) => [m.cle, m]));

  demandes.forEach((dem) => {
    const m = parCle[(dem.created_date || "").slice(0, 7)];
    if (m) m.Demandes += 1;
  });
  documents
    .filter((doc) => doc.type === "facture")
    .forEach((doc) => {
      const m = parCle[(doc.dateEmission || doc.created_date || "").slice(0, 7)];
      if (m) m["CA facturé"] += Number(doc.montant || 0);
    });

  return (
    <div className="rounded-xl border border-[#B49B72]/25 bg-white p-5">
      <p className="text-xs font-bold uppercase tracking-wide text-[#8A7356] mb-4">Activité des 12 derniers mois</p>
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={mois} margin={{ top: 5, right: 5, left: -15, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#B49B72" strokeOpacity={0.2} vertical={false} />
            <XAxis dataKey="label" tick={{ fontSize: 11, fill: "#57534E" }} axisLine={false} tickLine={false} />
            <YAxis yAxisId="demandes" allowDecimals={false} tick={{ fontSize: 11, fill: "#57534E" }} axisLine={false} tickLine={false} />
            <YAxis yAxisId="ca" orientation="right" hide />
            <Tooltip
              formatter={(valeur, nom) => (nom === "CA facturé" ? [`${Number(valeur).toLocaleString("fr-FR")} €`, nom] : [valeur, nom])}
              contentStyle={{ borderRadius: 12, border: "1px solid rgba(180,155,114,0.4)", fontSize: 12 }}
            />
            <Bar yAxisId="demandes" dataKey="Demandes" fill="#B49B72" radius={[4, 4, 0, 0]} maxBarSize={22} />
            <Line yAxisId="ca" type="monotone" dataKey="CA facturé" stroke="#0A84FF" strokeWidth={2} dot={{ r: 2.5 }} />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
      <div className="flex gap-5 mt-3 text-xs text-[#57534E]">
        <p className="flex items-center gap-2"><span className="h-2.5 w-2.5 rounded-sm bg-[#B49B72] inline-block" /> Demandes reçues</p>
        <p className="flex items-center gap-2"><span className="h-0.5 w-4 bg-[#0A84FF] inline-block" /> CA facturé (€)</p>
      </div>
    </div>
  );
}