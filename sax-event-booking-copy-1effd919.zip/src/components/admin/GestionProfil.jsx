import React, { useEffect, useRef, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Loader2, Camera, Check } from "lucide-react";

const classeInput =
  "min-h-[40px] w-full rounded-lg border border-[#B49B72]/40 bg-white px-3 py-2 text-sm text-[#1C1917] focus:border-[#8A7356] focus:outline-none";

const slugifier = (s) =>
  s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");

export default function GestionProfil({ email, onProfilChange }) {
  const [profil, setProfil] = useState(null);
  const [chargement, setChargement] = useState(true);
  const [sauvegarde, setSauvegarde] = useState(false);
  const [confirme, setConfirme] = useState(false);
  const [envoiPhoto, setEnvoiPhoto] = useState("");
  const photoRef = useRef(null);
  const couvertureRef = useRef(null);

  useEffect(() => {
    base44.entities.ProfilPrestataire.filter({ proprietaire: email }, "-updated_date", 1).then((liste) => {
      setProfil(liste[0] || { proprietaire: email, nomAffiche: "", sousTitre: "", ville: "", accroche: "", photoProfilUrl: "", couvertureUrl: "", sectionsMasquees: [] });
      setChargement(false);
    });
  }, [email]);

  const maj = (champ) => (ev) => setProfil((p) => ({ ...p, [champ]: ev.target.value }));

  const enregistrer = async (donnees) => {
    const aSauver = { ...(donnees || profil), proprietaire: email };
    setSauvegarde(true);
    setConfirme(false);
    try {
      if (!aSauver.slug && (aSauver.nomAffiche || "").trim()) {
        let slug = slugifier(aSauver.nomAffiche);
        const existants = await base44.entities.ProfilPrestataire.filter({ slug });
        if (existants.some((p) => p.id !== aSauver.id)) slug = `${slug}-${Date.now().toString().slice(-4)}`;
        aSauver.slug = slug;
        setProfil((p) => ({ ...p, slug }));
      }
      if (aSauver.id) {
        const { id, created_date, updated_date, created_by_id, ...champs } = aSauver;
        await base44.entities.ProfilPrestataire.update(id, champs);
        onProfilChange?.(aSauver);
      } else {
        const cree = await base44.entities.ProfilPrestataire.create(aSauver);
        setProfil((p) => ({ ...p, id: cree.id }));
        onProfilChange?.({ ...aSauver, id: cree.id });
      }
      setConfirme(true);
    } finally {
      setSauvegarde(false);
    }
  };

  const televerser = (champ) => async (ev) => {
    const fichier = ev.target.files?.[0];
    if (!fichier) return;
    setEnvoiPhoto(champ);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file: fichier });
      const nouveau = { ...profil, [champ]: file_url };
      setProfil(nouveau);
      await enregistrer(nouveau);
    } finally {
      setEnvoiPhoto("");
      if (photoRef.current) photoRef.current.value = "";
      if (couvertureRef.current) couvertureRef.current.value = "";
    }
  };

  if (chargement) return <Loader2 className="h-6 w-6 animate-spin text-[#8A7356] mx-auto my-10" />;

  return (
    <div className="space-y-6">
      {/* Aperçu couverture + photo, comme sur la page profil */}
      <div className="rounded-xl border border-[#B49B72]/25 bg-white overflow-hidden">
        <div className="relative h-32 md:h-40 bg-[#FAF7F2]">
          {profil.couvertureUrl && (
            <img src={profil.couvertureUrl} alt="Visuel de couverture" className="h-full w-full object-cover" />
          )}
          <label className="absolute bottom-3 right-3 min-h-[36px] px-3 rounded-full bg-black/60 backdrop-blur-md text-white text-xs font-medium inline-flex items-center gap-1.5 cursor-pointer hover:bg-black/80">
            {envoiPhoto === "couvertureUrl" ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Camera className="h-3.5 w-3.5" />}
            Changer la couverture
            <input ref={couvertureRef} type="file" accept="image/*" className="hidden"
              onChange={televerser("couvertureUrl")} disabled={!!envoiPhoto} />
          </label>
        </div>
        <div className="px-5 pb-5">
          <div className="relative inline-block -mt-10">
            <div className="h-20 w-20 rounded-full border-4 border-white shadow bg-[#FAF7F2] overflow-hidden">
              {profil.photoProfilUrl && (
                <img src={profil.photoProfilUrl} alt="Photo de profil" className="h-full w-full object-cover" />
              )}
            </div>
            <label className="absolute -bottom-1 -right-1 h-8 w-8 rounded-full bg-black/70 backdrop-blur-md text-white flex items-center justify-center cursor-pointer hover:bg-black/90 ring-1 ring-white/40">
              {envoiPhoto === "photoProfilUrl" ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Camera className="h-3.5 w-3.5" />}
              <input ref={photoRef} type="file" accept="image/*" className="hidden"
                onChange={televerser("photoProfilUrl")} disabled={!!envoiPhoto} />
            </label>
          </div>
        </div>
      </div>

      <div className="rounded-xl border border-[#B49B72]/25 bg-white p-5 space-y-4">
        <div>
          <label className="text-xs font-bold uppercase tracking-wide text-[#8A7356]">Nom affiché</label>
          <input className={classeInput} value={profil.nomAffiche || ""} onChange={maj("nomAffiche")} placeholder="Matt Mez Sax" />
        </div>
        <div>
          <label className="text-xs font-bold uppercase tracking-wide text-[#8A7356]">Sous-titre</label>
          <input className={classeInput} value={profil.sousTitre || ""} onChange={maj("sousTitre")} placeholder="Saxophoniste événementiel" />
        </div>
        <div>
          <label className="text-xs font-bold uppercase tracking-wide text-[#8A7356]">Ville</label>
          <input className={classeInput} value={profil.ville || ""} onChange={maj("ville")} placeholder="Paris, Lyon…" />
        </div>
        <div>
          <label className="text-xs font-bold uppercase tracking-wide text-[#8A7356]">Ligne d'accroche</label>
          <input className={classeInput} value={profil.accroche || ""} onChange={maj("accroche")}
            placeholder="Mariages · Cocktails · Soirées privées · Entreprises" />
        </div>
        {profil.slug && (
          <p className="text-xs text-[#57534E]">
            Adresse de votre page publique : <span className="font-bold text-[#8A7356]">/p/{profil.slug}</span>
          </p>
        )}
        <button
          onClick={() => enregistrer()}
          disabled={sauvegarde}
          className="min-h-[42px] px-6 rounded-full bg-[#1C1917] text-[#FAF7F2] text-sm font-bold hover:bg-[#33302B] disabled:opacity-70 inline-flex items-center gap-2"
        >
          {sauvegarde ? <Loader2 className="h-4 w-4 animate-spin" /> : confirme ? <Check className="h-4 w-4" /> : null}
          Enregistrer le profil
        </button>
      </div>
    </div>
  );
}