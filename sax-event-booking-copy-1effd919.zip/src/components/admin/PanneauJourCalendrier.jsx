import React, { useEffect, useState } from "react";
import { Loader2, Lock, Unlock, Phone, Mail, MapPin, Clock, PartyPopper, Timer } from "lucide-react";
import { Link } from "react-router-dom";

const formaterJour = (cle) =>
  new Date(`${cle}T12:00:00`).toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long", year: "numeric" });

// Panneau de détail d'un jour : réservations, événements, blocage avec motif.
export default function PanneauJourCalendrier({ cle, demandes, evenements, options = [], bloquee, onBloquer, onDebloquer, onChangerMotif, enCours }) {
  const [motif, setMotif] = useState("");

  useEffect(() => { setMotif(bloquee?.motif || ""); }, [cle, bloquee?.id]);

  const reservee = demandes.length > 0;

  return (
    <div className="rounded-2xl bg-[#FAF7F2] border border-[#B49B72]/25 p-5 space-y-4">
      <p className="font-heading text-lg capitalize">{formaterJour(cle)}</p>

      {/* Réservations confirmées ce jour-là */}
      {demandes.map((d) => (
        <div key={d.id} className="rounded-xl bg-white border border-[#0A84FF]/30 p-4 space-y-2">
          <p className="text-xs font-bold uppercase tracking-wide text-[#0A84FF]">Réservé — {d.typeEvenement}</p>
          <p className="font-semibold text-sm">{d.prenom} {d.nom}</p>
          <div className="text-xs text-[#57534E] space-y-1.5">
            <p className="flex items-center gap-2"><Clock className="h-3.5 w-3.5 shrink-0" /> {d.heureDebut} – {d.heureFin}</p>
            <p className="flex items-center gap-2"><MapPin className="h-3.5 w-3.5 shrink-0" /> {d.adresseEvenement}</p>
            <p className="flex items-center gap-2"><Phone className="h-3.5 w-3.5 shrink-0" /> <a href={`tel:${d.telephone}`} className="underline">{d.telephone}</a></p>
            <p className="flex items-center gap-2"><Mail className="h-3.5 w-3.5 shrink-0" /> <a href={`mailto:${d.email}`} className="underline">{d.email}</a></p>
          </div>
        </div>
      ))}

      {/* Événements du Studio ce jour-là */}
      {evenements.map((e) => (
        <Link
          key={e.id}
          to={`/compte?evenement=${e.id}`}
          className="flex items-center gap-3 rounded-xl bg-white border border-[#B49B72]/25 p-4 hover:border-[#B49B72]/50 transition-colors"
        >
          <PartyPopper className="h-4 w-4 text-[#8A7356] shrink-0" />
          <div className="min-w-0">
            <p className="text-sm font-semibold truncate">{e.titre}</p>
            <p className="text-xs text-[#57534E]">{e.lieu || e.typeEvenement || "Événement"} · {e.statut}</p>
          </div>
        </Link>
      ))}

      {/* Options 48 h posées par des visiteurs */}
      {options.map((o) => (
        <div key={o.id} className="rounded-xl bg-white border border-[#FF9F0A]/50 p-4 space-y-1">
          <p className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide text-[#B45309]">
            <Timer className="h-3.5 w-3.5" /> Option 48 h
          </p>
          <p className="text-sm font-semibold">{o.nom}</p>
          <p className="text-xs text-[#57534E]">
            <a href={`mailto:${o.email}`} className="underline">{o.email}</a>
            {o.telephone ? <> · <a href={`tel:${o.telephone}`} className="underline">{o.telephone}</a></> : null}
          </p>
          <p className="text-xs text-[#57534E]">Expire le {new Date(o.expireLe).toLocaleString("fr-FR")}</p>
        </div>
      ))}

      {/* Blocage manuel */}
      {!reservee && (
        <div className="space-y-2">
          <label className="text-xs font-bold uppercase tracking-wide text-[#8A7356]" htmlFor="motif-blocage">
            {bloquee ? "Motif du blocage" : "Bloquer cette date"}
          </label>
          <input
            id="motif-blocage"
            value={motif}
            onChange={(e) => setMotif(e.target.value)}
            placeholder="Motif (congés, perso, autre date en option…)"
            className="w-full rounded-lg border border-[#B49B72]/40 bg-white px-3 py-2.5 text-sm focus:outline-none focus:border-[#8A7356]"
          />
          <div className="flex flex-wrap gap-2">
            {bloquee ? (
              <>
                <button
                  onClick={() => onChangerMotif(motif)}
                  disabled={enCours}
                  className="min-h-[40px] px-4 rounded-full bg-[#1C1917] text-[#FAF7F2] text-xs font-bold hover:bg-[#33302B] disabled:opacity-60"
                >
                  {enCours ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : "Enregistrer le motif"}
                </button>
                <button
                  onClick={onDebloquer}
                  disabled={enCours}
                  className="min-h-[40px] px-4 rounded-full border border-[#B49B72]/40 text-xs font-bold hover:bg-white disabled:opacity-60 inline-flex items-center gap-1.5"
                >
                  <Unlock className="h-3.5 w-3.5" /> Débloquer
                </button>
              </>
            ) : (
              <button
                onClick={() => onBloquer(motif || "Bloquée manuellement")}
                disabled={enCours}
                className="min-h-[40px] px-4 rounded-full bg-[#1C1917] text-[#FAF7F2] text-xs font-bold hover:bg-[#33302B] disabled:opacity-60 inline-flex items-center gap-1.5"
              >
                {enCours ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <><Lock className="h-3.5 w-3.5" /> Bloquer</>}
              </button>
            )}
          </div>
        </div>
      )}

      {reservee && !bloquee && (
        <p className="text-xs text-[#57534E]">Cette date est réservée : elle apparaît indisponible sur votre page publique.</p>
      )}
    </div>
  );
}