import React, { useMemo, useState } from "react";
import IntroductionMoteur5D from "@/components/guide/IntroductionMoteur5D";
import SelecteurMoteur5D from "@/components/guide/SelecteurMoteur5D";
import ResultatMoteur5D from "@/components/guide/ResultatMoteur5D";
import SourcesMoteur5D from "@/components/guide/SourcesMoteur5D";
import { calculerSignature5D } from "@/lib/moteur5dEvenement";

export default function Guide() {
  const [choix, setChoix] = useState([1, 0, 0, 0, 0]);
  const signature = useMemo(() => calculerSignature5D(choix), [choix]);
  const choisir = (axe, valeur) => setChoix((actuels) => actuels.map((item, index) => index === axe ? valeur : item));

  return <main className="theme-apple min-h-screen bg-background px-4 pb-32 pt-10 font-body text-foreground sm:px-6 lg:px-8">
    <div className="mx-auto max-w-6xl">
      <header className="max-w-3xl"><p className="text-xs font-bold uppercase tracking-[0.25em] text-muted-foreground">Mode d’emploi · Futur causal</p><h1 className="mt-4 font-heading text-4xl leading-tight sm:text-6xl">Comprendre ce qui peut arriver, et pourquoi.</h1><p className="mt-5 text-base leading-7 text-muted-foreground">Le moteur hybride événementiel transforme cinq observations en une signature explicable. Il couvre les retards, le climat, les contraintes physiques, l’argent, les conflits d’intérêts, les défaillances, les détournements et les informations inattendues.</p></header>
      <section aria-label="Principes du moteur" className="mt-8"><IntroductionMoteur5D /></section>
      <section className="mt-12"><div className="mb-6"><p className="text-xs font-bold uppercase tracking-[0.2em] text-muted-foreground">Explorateur déterministe</p><h2 className="mt-2 font-heading text-3xl">Composez une signature parmi 1 024</h2></div><div className="grid items-start gap-6 lg:grid-cols-[1.35fr_0.8fr]"><SelecteurMoteur5D choix={choix} onChange={choisir} /><ResultatMoteur5D signature={signature} /></div></section>
      <section className="mt-12 rounded-3xl border border-border bg-card p-6"><h2 className="font-heading text-2xl">Comment lire le résultat ?</h2><p className="mt-3 max-w-3xl text-sm leading-6 text-muted-foreground"><strong className="text-foreground">SI</strong> décrit l’état observé. <strong className="text-foreground">ALORS</strong> expose les conséquences prioritaires. <strong className="text-foreground">PARCE QUE</strong> rend visibles les dépendances qui produisent cette cascade. Une signature est un cadre de lecture : les horaires, montants, lieux et décisions restent toujours à confirmer dans l’événement.</p></section>
      <SourcesMoteur5D />
    </div>
  </main>;
}