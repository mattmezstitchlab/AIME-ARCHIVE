import React from "react";
import CadreLegal from "@/components/legal/CadreLegal";
import BlocLegal from "@/components/legal/BlocLegal";

export default function ConditionsUtilisation() {
  return (
    <CadreLegal titre="Conditions d’utilisation">
      <BlocLegal titre="Objet du service">
        <p>Aime Event aide à structurer un brief, préparer un événement et coordonner ses acteurs. Les propositions de l’assistant restent indicatives jusqu’à leur confirmation par l’utilisateur.</p>
      </BlocLegal>
      <BlocLegal titre="Responsabilité de l’utilisateur">
        <p>Vous devez vérifier les dates, horaires, lieux, budgets, coordonnées et décisions importantes avant toute confirmation ou transmission à un tiers. Vous vous engagez à fournir des informations licites et à ne pas transmettre de données sensibles inutiles.</p>
      </BlocLegal>
      <BlocLegal titre="Disponibilité et contenus">
        <p>Le service peut évoluer ou être temporairement indisponible. Les profils de démonstration et contenus fictifs sont signalés comme tels et ne constituent pas des références commerciales réelles.</p>
      </BlocLegal>
      <BlocLegal titre="Données personnelles">
        <p>Le traitement des données est décrit dans la politique de confidentialité. Vous pouvez demander l’accès, la correction ou la suppression de vos données selon les modalités qui y sont indiquées.</p>
      </BlocLegal>
    </CadreLegal>
  );
}