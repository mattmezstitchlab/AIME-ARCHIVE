import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { ALLERGENES_OFFICIELS, REGIMES } from "@/lib/allergenes";
import EnTetePlateforme from "@/components/plateforme/EnTetePlateforme";
import { Check, UtensilsCrossed } from "lucide-react";

const classeInput =
  "min-h-[48px] w-full rounded-xl border border-white/15 bg-white/[0.06] px-3 text-sm text-white placeholder:text-white/35 focus:outline-none focus:border-[#BF5AF2] [color-scheme:dark]";

export default function AllergiesInvite() {
  const { evenementId } = useParams();
  const [infos, setInfos] = useState(undefined);
  const [nom, setNom] = useState("");
  const [allergenes, setAllergenes] = useState([]);
  const [regime, setRegime] = useState(REGIMES[0]);
  const [commentaire, setCommentaire] = useState("");
  const [envoi, setEnvoi] = useState(false);
  const [envoye, setEnvoye] = useState(false);
  const [erreur, setErreur] = useState("");

  useEffect(() => {
    base44.functions.invoke("allergiesEvenement", { evenementId, action: "info" })
      .then((r) => setInfos(r.data))
      .catch(() => setInfos(null));
  }, [evenementId]);

  const basculer = (a) =>
    setAllergenes((l) => (l.includes(a) ? l.filter((x) => x !== a) : [...l, a]));

  const envoyer = async (e) => {
    e.preventDefault();
    if (!nom.trim() || envoi) return;
    setEnvoi(true);
    setErreur("");
    try {
      await base44.functions.invoke("allergiesEvenement", {
        evenementId,
        action: "ajouter",
        nom: nom.trim(),
        allergenes,
        regime,
        commentaire: commentaire.trim(),
      });
      setEnvoye(true);
    } catch {
      setErreur("L'envoi a échoué, merci de réessayer.");
    }
    setEnvoi(false);
  };

  return (
    <div className="theme-apple min-h-screen bg-[var(--p-bg)] text-[var(--p-text)]">
      <EnTetePlateforme />
      <main className="max-w-2xl mx-auto px-4 md:px-6 py-12 md:py-16">
        {infos === undefined ? (
          <p className="text-sm text-[var(--p-muted)]">Chargement…</p>
        ) : infos === null ? (
          <p className="text-sm text-[var(--p-muted)]">Cet événement est introuvable — vérifiez votre lien.</p>
        ) : envoye ? (
          <div className="text-center py-16">
            <span className="inline-flex h-14 w-14 items-center justify-center rounded-full bg-[#30D158]/15 text-[#30D158] mb-5">
              <Check className="h-7 w-7" />
            </span>
            <h1 className="font-heading text-2xl text-[var(--p-text)]">Merci {nom} !</h1>
            <p className="mt-2 text-sm text-[var(--p-muted)]">
              Vos informations ont été transmises aux organisateurs de « {infos.titre} » — le traiteur en tiendra compte.
            </p>
            <button
              type="button"
              onClick={() => { setNom(""); setAllergenes([]); setRegime(REGIMES[0]); setCommentaire(""); setEnvoye(false); }}
              className="mt-6 min-h-[44px] px-5 rounded-full bg-gradient-to-r from-[#BF5AF2] to-[#0A84FF] text-white text-sm font-bold hover:opacity-90 transition-opacity"
            >
              Répondre pour un autre invité
            </button>
          </div>
        ) : (
          <>
            <p className="text-[10px] font-bold uppercase tracking-[0.3em] text-[var(--p-muted)]">Allergies & régimes</p>
            <h1 className="mt-2 font-heading text-3xl md:text-4xl text-[var(--p-text)]">{infos.titre}</h1>
            <p className="mt-3 text-sm text-[var(--p-muted)]">
              Indiquez vos allergies et votre régime alimentaire — ces informations sont transmises directement aux organisateurs et au traiteur.
            </p>
            <form onSubmit={envoyer} className="mt-8 space-y-6">
              <input value={nom} onChange={(e) => setNom(e.target.value)} placeholder="Votre nom *" required className={classeInput} />

              <div>
                <p className="text-xs font-bold uppercase tracking-wide text-[var(--p-muted)] mb-2">Mes allergènes</p>
                <div className="flex flex-wrap gap-2">
                  {ALLERGENES_OFFICIELS.map((a) => {
                    const actif = allergenes.includes(a);
                    return (
                      <button
                        key={a}
                        type="button"
                        onClick={() => basculer(a)}
                        aria-pressed={actif}
                        className={`min-h-[40px] px-4 rounded-full text-sm font-medium transition-colors ${
                          actif ? "bg-gradient-to-r from-[#BF5AF2] to-[#0A84FF] text-white" : "bg-white/[0.06] border border-white/15 text-[var(--p-text)] hover:bg-white/10"
                        }`}
                      >
                        {a}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <p className="text-xs font-bold uppercase tracking-wide text-[var(--p-muted)] mb-2">Mon régime</p>
                <select value={regime} onChange={(e) => setRegime(e.target.value)} aria-label="Régime alimentaire" className={classeInput}>
                  {REGIMES.map((r) => <option key={r} value={r}>{r}</option>)}
                </select>
              </div>

              <textarea
                value={commentaire}
                onChange={(e) => setCommentaire(e.target.value)}
                placeholder="Précision utile (intolérance, intensité de l'allergie…)"
                rows={3}
                className="w-full rounded-xl border border-white/15 bg-white/[0.06] px-3 py-2.5 text-sm text-white placeholder:text-white/35 focus:outline-none focus:border-[#BF5AF2]"
              />

              <button
                type="submit"
                disabled={envoi || !nom.trim()}
                className="inline-flex items-center gap-2 min-h-[44px] px-6 rounded-full bg-gradient-to-r from-[#BF5AF2] to-[#0A84FF] text-white text-sm font-bold hover:bg-black disabled:opacity-40 transition-colors"
              >
                <UtensilsCrossed className="h-4 w-4" /> {envoi ? "Envoi…" : "Envoyer mes informations"}
              </button>
              {erreur && <p className="text-sm text-[#FF3B30]">{erreur}</p>}
            </form>
          </>
        )}
      </main>
    </div>
  );
}