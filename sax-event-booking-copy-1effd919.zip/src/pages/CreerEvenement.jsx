import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import EspaceConnecteShell from "@/components/compte/EspaceConnecteShell";
import QuestionsAssistant from "@/components/creer/QuestionsAssistant";
import AnalyseRadiale from "@/components/creer/AnalyseRadiale";
import ApercuDossier from "@/components/creer/ApercuDossier";
import { genererDossierEvenement } from "@/lib/assistantEvenement";
import { MODELES_EVENEMENTS } from "@/lib/modelesEvenements";
import useSeo from "@/hooks/useSeo";

// Assistant de création d'événement — le cœur du parcours : quelques
// questions, l'IA compose un dossier complet (déroulé, acteurs, budget),
// l'organisateur valide et atterrit directement dans son Studio.
export default function CreerEvenement() {
  const navigate = useNavigate();
  const [reponses, setReponses] = useState(null);
  const [dossier, setDossier] = useState(null);
  const [enCours, setEnCours] = useState(false);
  const [erreur, setErreur] = useState("");
  const [texteAnalyse, setTexteAnalyse] = useState("");

  useSeo({
    titre: "Créer mon événement — Aime Event",
    description: "Racontez votre événement, l'assistant compose votre dossier complet : déroulé intelligent, acteurs, budget prévisionnel.",
    noindex: true,
  });

  const generer = async (r) => {
    setErreur("");
    setTexteAnalyse([r.type, r.titre, r.date, r.lieu, r.invites && `${r.invites} invités`, r.souhaits].filter(Boolean).join(" · "));
    setEnCours(true);
    try {
      const d = await genererDossierEvenement(r);
      setReponses(r);
      setDossier(d);
    } catch (_e) {
      setErreur("La composition a échoué — réessayez.");
    } finally {
      setEnCours(false);
    }
  };

  const valider = async () => {
    setErreur("");
    setEnCours(true);
    try {
      const u = await base44.auth.me();
      const cree = await base44.entities.Evenement.create({
        proprietaire: (u.email || "").toLowerCase(),
        titre: reponses.titre || MODELES_EVENEMENTS[reponses.cleType]?.placeholderTitre || reponses.type,
        typeEvenement: reponses.type,
        date: reponses.date,
        lieu: reponses.lieu || "",
        budgetPrevisionnel: Math.round(dossier.budgetPrevisionnel || 0),
        statut: "brouillon",
        moments: (dossier.moments || []).map((m) => ({
          titre: m.titre,
          heureDebut: m.heureDebut || "",
          heureFin: m.heureFin || "",
          categorie: m.categorie || "famille",
          tag: m.tag || "",
          exposition: m.exposition || "interieur",
          cout: Number(m.cout) || 0,
          planB: m.planB || "",
          planBActif: false,
          responsable: m.responsable || "",
        })),
        acteurs: (dossier.acteurs || []).map((a) => ({
          nom: a.nom,
          categorie: a.categorie || "famille",
          role: a.role || "",
          email: "",
          slugProfil: "",
        })),
      });
      navigate(`/compte?evenement=${cree.id}`);
    } catch (_e) {
      setErreur("La création a échoué — réessayez.");
      setEnCours(false);
    }
  };

  return (
    <EspaceConnecteShell sombre largeur="max-w-3xl">
      <main className="min-w-0 pt-7 md:pt-12">
        <p className="text-[11px] font-bold uppercase tracking-[0.35em] text-white/40">L'assistant</p>
        <h1 className="mt-4 font-heading text-4xl md:text-5xl font-semibold tracking-tight">
          {dossier ? "Voici votre dossier." : <>Racontez votre événement.<br /><span className="texte-prisme">Il se compose tout seul.</span></>}
        </h1>
        <p className="mt-4 text-sm text-white/55 max-w-xl leading-relaxed">
          {dossier
            ? "Déroulé, acteurs et budget composés selon vos souhaits — tout reste ajustable dans votre Studio."
            : "Quelques questions, et l'assistant compose votre déroulé complet : horaires, moments sacrés, plans B, acteurs et budget prévisionnel."}
        </p>

        <div className="mt-10">
          {dossier ? (
            <ApercuDossier
              dossier={dossier}
              enCours={enCours}
              onValider={valider}
              onRecommencer={() => { setDossier(null); setErreur(""); }}
            />
          ) : enCours ? (
            <AnalyseRadiale mode="composition" texte={texteAnalyse} />
          ) : (
            <QuestionsAssistant onGenerer={generer} enCours={enCours} />
          )}
          {erreur && <p className="mt-4 text-sm text-[#FF6961]">{erreur}</p>}
        </div>
      </main>
    </EspaceConnecteShell>
  );
}