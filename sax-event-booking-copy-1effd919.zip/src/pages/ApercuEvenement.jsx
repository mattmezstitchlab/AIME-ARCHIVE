import React from "react";
import { Orbit } from "lucide-react";
import EnTetePlateforme from "@/components/plateforme/EnTetePlateforme";
import AnalyseRadiale from "@/components/creer/AnalyseRadiale";
import FormulaireApercu from "@/components/apercu/FormulaireApercu";
import useApercuEvenement from "@/hooks/useApercuEvenement";
import useSeo from "@/hooks/useSeo";

export default function ApercuEvenement() {
  const etat = useApercuEvenement();
  useSeo({ titre: "Aperçu de votre événement — Aime Event", description: "Vérifiez et corrigez les informations comprises avant de créer votre événement.", noindex: true });
  return (
    <div className="theme-apple min-h-screen bg-[#050506] text-white">
      <EnTetePlateforme sombre />
      <main className="mx-auto max-w-4xl px-4 pb-32 pt-10 md:px-6 md:pt-16">
        <p className="text-[11px] font-bold uppercase tracking-[0.35em] text-white/40">Aperçu avant inscription</p>
        <h1 className="mt-4 text-balance font-heading text-4xl font-semibold md:text-5xl">Vérifiez ce que <span className="texte-prisme">l’assistant a compris.</span></h1>
        <p className="mt-4 max-w-2xl text-base leading-relaxed text-white/60">Rien n’est enregistré tant que vous n’avez pas corrigé puis confirmé les informations importantes.</p>
        <div className="mt-10">
          {etat.chargement ? <AnalyseRadiale mode="brief" texte={etat.brief} /> : etat.analyse ? <FormulaireApercu etat={etat} /> : (
            <div className="text-center">
              <p role="alert" className="text-[#FF8A82]">{etat.erreur}</p>
              <button onClick={() => etat.analyser(etat.brief)} className="mt-4 inline-flex min-h-[44px] items-center gap-2 rounded-full bg-white px-5 text-sm font-bold text-black"><Orbit className="h-4 w-4" /> Réessayer</button>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}