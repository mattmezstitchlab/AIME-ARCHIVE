import React, { useEffect, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import EspaceConnecteShell from "@/components/compte/EspaceConnecteShell";
import PageHeader from "@/components/compte/PageHeader";
import NavigationCompte from "@/components/compte/NavigationCompte";
import ListeDemandes from "@/components/admin/ListeDemandes";
import OngletDocuments from "@/components/compte/OngletDocuments";
import CalendrierAdmin from "@/components/admin/CalendrierAdmin";
import GestionCollaborateurs from "@/components/admin/GestionCollaborateurs";
import StatistiquesAdmin from "@/components/admin/StatistiquesAdmin";
import ParametresCompte from "@/components/compte/ParametresCompte";
import OnboardingCompte from "@/components/onboarding/OnboardingCompte";
import ListeEvenements from "@/components/evenements/ListeEvenements";
import TableauIntermittence from "@/components/intermittent/TableauIntermittence";
import EditeurMiniSite from "@/components/admin/EditeurMiniSite";
import useSeo from "@/hooks/useSeo";
import {
  Inbox, BarChart3, CalendarDays, FileText, Clapperboard,
  Users, LogOut, ExternalLink, Loader2, Settings, PartyPopper,
  LayoutTemplate,
} from "lucide-react";

const ONGLETS = [
  ["evenements", "Événements", PartyPopper],
  ["demandes", "Demandes", Inbox],
  ["documents", "Documents", FileText],
  ["calendrier", "Calendrier", CalendarDays],
  ["stats", "Statistiques", BarChart3],
  ["minisite", "Mon mini-site", LayoutTemplate],
  ["intermittence", "Intermittence", Clapperboard],
  ["equipe", "Collaborateurs", Users],
  ["parametres", "Paramètres", Settings],
];

const ROLES_CLIENT = ["Organisateur d'événements", "Futur(e) marié(e) / particulier", "Je découvre", "J’organise un événement", "Je découvre Aime Event"];
const ONGLETS_CLIENT = new Set(["evenements", "documents", "parametres"]);

export default function Compte() {
  useSeo({ titre: "Mon compte — Aime Event", noindex: true });
  const location = useLocation();
  const urlParams = new URLSearchParams(location.search);
  const EVENEMENT_INITIAL = urlParams.get("evenement");
  const ONGLET_INITIAL = urlParams.get("onglet");
  const NOUVEAU_EVENT = urlParams.get("nouveau");

  const navigate = useNavigate();
  // L'onglet actif est piloté par l'URL : capsule, navigateur et page restent synchronisés.
  const onglet = EVENEMENT_INITIAL
    ? "evenements"
    : ONGLETS.some(([cle]) => cle === ONGLET_INITIAL) ? ONGLET_INITIAL : "evenements";
  const [utilisateur, setUtilisateur] = useState(null);
  const [profil, setProfil] = useState(null);
  const [prefill, setPrefill] = useState(null);
  const [onboarding, setOnboarding] = useState(false);

  const chargerCompte = async () => {
    const u = await base44.auth.me();
    setUtilisateur(u);
    const liste = await base44.entities.ProfilPrestataire.filter(
      { proprietaire: (u.email || "").toLowerCase() },
      "-updated_date",
      1
    );
    setProfil(liste[0] || null);
    if (!liste[0] && !u.onboardingTermine) setOnboarding(true);
  };

  useEffect(() => { chargerCompte(); }, []);

  const creerDocumentDepuisDemande = (d) => {
    setPrefill({
      clientNom: `${d.prenom} ${d.nom}`,
      clientTelephone: d.telephone,
      clientEmail: d.email,
      dateEvenement: d.dateEvenement,
      heureDebut: d.heureDebut,
      heureFin: d.heureFin,
      lieu: d.adresseEvenement,
      description: `Prestation — ${d.typeEvenement}`,
    });
    navigate("/compte?onglet=documents");
  };

  if (!utilisateur) {
    return (
      <div className="theme-apple min-h-screen bg-[var(--p-bg)] flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-[var(--p-accent)]" />
      </div>
    );
  }

  const email = (utilisateur.email || "").toLowerCase();
  const nomCompte = profil?.nomAffiche || utilisateur.full_name || email;
  const estClient = ROLES_CLIENT.includes(utilisateur.rolePlateforme);
  const ongletsVisibles = estClient ? ONGLETS.filter(([cle]) => ONGLETS_CLIENT.has(cle)) : ONGLETS;
  const ongletActif = ongletsVisibles.some(([cle]) => cle === onglet) ? onglet : "evenements";
  const libelleActif = ongletsVisibles.find(([cle]) => cle === ongletActif)?.[1];

  return (
    <EspaceConnecteShell>
      <PageHeader
        titre={libelleActif}
        contexte={nomCompte}
        actions={<>
          {profil?.slug && (
            <Link to={`/p/${profil.slug}`} title="Ma page publique" className="inline-flex min-h-[44px] items-center gap-2 rounded-full bg-white/[0.07] px-4 text-sm font-semibold text-[var(--p-text)] hover:bg-white/[0.12]">
              <ExternalLink className="h-4 w-4" aria-hidden="true" /> Ma page
            </Link>
          )}
          <button onClick={() => base44.auth.logout("/")} title="Déconnexion" className="inline-flex min-h-[44px] items-center gap-2 rounded-full bg-white/[0.07] px-4 text-sm font-semibold text-[var(--p-muted)] hover:bg-white/[0.12] hover:text-[var(--p-text)]">
            <LogOut className="h-4 w-4" aria-hidden="true" /> Quitter
          </button>
        </>}
      />
      <NavigationCompte onglets={ongletsVisibles} actif={ongletActif} onChange={(cle) => navigate(`/compte?onglet=${cle}`)} />
      <main className="min-w-0 max-w-full">
          {ongletActif === "demandes" ? (
            <ListeDemandes email={email} onCreerDocument={creerDocumentDepuisDemande} />
          ) : ongletActif === "evenements" ? (
            <ListeEvenements email={email} evenementInitialId={EVENEMENT_INITIAL} typeInitial={NOUVEAU_EVENT} />
          ) : ongletActif === "stats" ? (
            <StatistiquesAdmin email={email} />
          ) : ongletActif === "calendrier" ? (
            <CalendrierAdmin email={email} />
          ) : ongletActif === "intermittence" ? (
            <TableauIntermittence email={email} />
          ) : ongletActif === "parametres" ? (
            <ParametresCompte email={email} />
          ) : ongletActif === "equipe" ? (
            <GestionCollaborateurs />
          ) : ongletActif === "minisite" ? (
            <EditeurMiniSite email={email} />
          ) : (
            <OngletDocuments
              key={prefill ? JSON.stringify(prefill) : "vide"}
              email={email}
              expediteur={nomCompte}
              prefill={prefill}
            />
          )}
      </main>

      {onboarding && (
        <OnboardingCompte
          email={email}
          onFermer={(fait) => {
            setOnboarding(false);
            if (fait) chargerCompte();
          }}
        />
      )}
    </EspaceConnecteShell>
  );
}