import React from "react";
import CadreLegal from "@/components/legal/CadreLegal";
import BlocLegal from "@/components/legal/BlocLegal";
import { PRESTATAIRE } from "@/lib/infosPrestataire";

export default function Confidentialite() {
  return (
    <CadreLegal titre="Politique de confidentialité">
      <BlocLegal titre="Responsable du traitement">
        <p>{PRESTATAIRE.nomLegal} — {PRESTATAIRE.adresse}, {PRESTATAIRE.ville}.</p>
        <p>Contact : {PRESTATAIRE.email} · {PRESTATAIRE.telephone}</p>
      </BlocLegal>

      <BlocLegal titre="Données collectées">
        <p>Lorsque vous envoyez une demande de disponibilité, nous collectons : votre nom, prénom, numéro de téléphone, adresse e-mail, l'adresse et les informations relatives à votre événement, ainsi que les précisions que vous choisissez de nous transmettre.</p>
        <p>Lorsque vous laissez un avis, nous collectons votre nom, le type d'événement, votre note et votre message.</p>
        <p>Si vous créez un compte pour accéder à l'espace client, votre adresse e-mail et votre nom sont conservés pour vous authentifier.</p>
        <p>Le brief libre est conservé temporairement dans la session de votre navigateur pour permettre l’aperçu et le retour après authentification. Il est transmis à l’assistant uniquement pour en extraire les informations à vérifier, puis supprimé de la session après création de l’événement.</p>
        <p>Selon ce que vous écrivez, le brief peut contenir le type d’événement, une date ou période, un lieu, un budget, un nombre d’invités, des horaires, des souhaits, des contraintes, des risques et l’identité ou le rôle des acteurs concernés. L’assistant ne doit pas être utilisé pour transmettre des données sensibles inutiles.</p>
        <p>Des événements de mesure d’usage limités sont enregistrés pour suivre les étapes du parcours, par exemple l’analyse, l’affichage de l’aperçu, une correction ou la confirmation. Ils ne contiennent pas le texte du brief ni vos coordonnées.</p>
      </BlocLegal>

      <BlocLegal titre="Finalités et base légale">
        <p>Vos données sont utilisées uniquement pour :</p>
        <ul className="list-disc list-inside space-y-1">
          <li>répondre à votre demande de disponibilité et organiser la prestation (mesures précontractuelles) ;</li>
          <li>établir les devis, contrats et factures liés à la prestation (obligation légale et exécution du contrat) ;</li>
          <li>publier les avis que vous soumettez volontairement (consentement) ;</li>
          <li>analyser le brief afin de proposer une structure à vérifier, sans décision automatique sur les informations importantes (mesures précontractuelles) ;</li>
          <li>mesurer le bon fonctionnement du parcours et prévenir les abus (intérêt légitime).</li>
        </ul>
        <p>Aucune donnée n'est vendue, louée ou transmise à des tiers à des fins commerciales.</p>
      </BlocLegal>

      <BlocLegal titre="Durée de conservation">
        <p>Le brief brut reste dans la session du navigateur jusqu’à la création de l’événement, son remplacement ou la fin de la session. Les informations structurées confirmées sont conservées pendant la durée d’utilisation du compte et supprimées sur demande, sous réserve des obligations légales. Les demandes de disponibilité sont conservées le temps nécessaire à leur traitement et au suivi de la prestation. Les documents comptables sont conservés 10 ans.</p>
      </BlocLegal>

      <BlocLegal titre="Sous-traitants et destinataires">
        <p>Les données nécessaires sont traitées par Base44, service de Wix.com Ltd., pour l’hébergement, l’authentification, la base de données et les fonctions applicatives. Le service d’assistance IA intégré à la plateforme reçoit uniquement le brief nécessaire à l’extraction. Les données ne sont communiquées qu’aux personnes autorisées à organiser l’événement.</p>
      </BlocLegal>

      <BlocLegal titre="Hébergement et sécurité">
        <p>Les données sont stockées de manière sécurisée sur la plateforme Base44 (Wix.com Ltd.). L'accès aux demandes et aux documents est restreint et protégé par authentification.</p>
      </BlocLegal>

      <BlocLegal titre="Vos droits">
        <p>Conformément au Règlement général sur la protection des données (RGPD) et à la loi Informatique et Libertés, vous disposez d'un droit d'accès, de rectification, d'effacement, de limitation et d'opposition sur vos données personnelles.</p>
        <p>Pour exercer ces droits ou demander la suppression de votre compte, d’un brief ou d’un événement, contactez-nous à l'adresse : {PRESTATAIRE.email}. Après vérification de votre identité, les données concernées seront supprimées ou anonymisées, sauf obligation légale de conservation. Vous pouvez également introduire une réclamation auprès de la CNIL (<a href="https://www.cnil.fr" target="_blank" rel="noopener noreferrer" className="underline hover:text-[#1C1917]">www.cnil.fr</a>).</p>
      </BlocLegal>

      <BlocLegal titre="Cookies">
        <p>Ce site n'utilise pas de cookies publicitaires ou de suivi. Seuls des cookies techniques strictement nécessaires au fonctionnement du site (authentification à l'espace client et à l'espace admin) peuvent être déposés.</p>
      </BlocLegal>
    </CadreLegal>
  );
}