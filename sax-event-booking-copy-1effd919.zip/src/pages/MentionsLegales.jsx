import React from "react";
import CadreLegal from "@/components/legal/CadreLegal";
import BlocLegal from "@/components/legal/BlocLegal";
import { PRESTATAIRE } from "@/lib/infosPrestataire";

export default function MentionsLegales() {
  return (
    <CadreLegal titre="Mentions légales">
      <BlocLegal titre="La plateforme Aime Event">
        <p>Aime Event est une plateforme de profils publics pour prestataires événementiels : registre, disponibilités, demandes, devis, contrats et déroulé du Jour J. À ce stade, la plateforme est éditée et administrée par {PRESTATAIRE.nomLegal}, dont le profil Matt Mez Sax est le premier profil fondateur du registre.</p>
      </BlocLegal>

      <BlocLegal titre="Éditeur du site">
        <p><strong>{PRESTATAIRE.nomLegal}</strong></p>
        <p>Nom de scène : {PRESTATAIRE.nomScene}</p>
        <p>SIRET : {PRESTATAIRE.siret}</p>
        <p>{PRESTATAIRE.tva}</p>
      </BlocLegal>

      <BlocLegal titre="Coordonnées">
        <p>{PRESTATAIRE.adresse}</p>
        <p>{PRESTATAIRE.ville}</p>
        <p>Téléphone : {PRESTATAIRE.telephone}</p>
        <p>E-mail : {PRESTATAIRE.email}</p>
      </BlocLegal>

      <BlocLegal titre="Directeur de la publication">
        <p>{PRESTATAIRE.nomLegal}</p>
      </BlocLegal>

      <BlocLegal titre="Hébergement">
        <p>Ce site est hébergé par Base44 (Wix.com Ltd.), 40 Namal Tel Aviv St., Tel Aviv 6350671, Israël — <a href="https://base44.com" target="_blank" rel="noopener noreferrer" className="underline hover:text-[#1C1917]">base44.com</a>.</p>
      </BlocLegal>

      <BlocLegal titre="Propriété intellectuelle">
        <p>L'ensemble des contenus de ce site (textes, photographies, vidéos, logo) est la propriété exclusive de {PRESTATAIRE.nomLegal}, sauf mention contraire. Toute reproduction, représentation ou diffusion, totale ou partielle, sans autorisation écrite préalable est interdite.</p>
      </BlocLegal>

      <BlocLegal titre="Données personnelles">
        <p>Les informations collectées via le formulaire de demande de disponibilité sont utilisées uniquement pour répondre à votre demande. Pour en savoir plus, consultez notre <a href="/confidentialite" className="underline hover:text-[#1C1917]">politique de confidentialité</a>.</p>
      </BlocLegal>
    </CadreLegal>
  );
}