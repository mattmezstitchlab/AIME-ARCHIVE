import React, { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Loader2 } from "lucide-react";
import HeroProfil from "@/components/profil/HeroProfil";
import ProfilPageUnique from "@/components/profil/ProfilPageUnique";
import BarreAncresProfil from "@/components/profil/BarreAncresProfil";
import EnTetePlateforme from "@/components/plateforme/EnTetePlateforme";
import BandeauRevendication from "@/components/profil/BandeauRevendication";
import useSeo from "@/hooks/useSeo";
import sectionsVides from "@/lib/sectionsProfil";

export default function Profil() {
  const { slug } = useParams();
  const [contenu, setContenu] = useState(null);
  const [introuvable, setIntrouvable] = useState(false);

  const p = contenu?.profil;
  const imageMarque = "https://media.base44.com/images/public/6a565bd0fa77bad71effd919/14695ecff_generated_image.png";
  const descriptionProfil = p?.accroche
    ? `${p.nomAffiche} : ${p.accroche}. Vérifiez ses disponibilités sur Aime Event.`
    : p ? `Découvrez le profil public de ${p.nomAffiche} sur Aime Event.` : undefined;
  const donneesStructurees = p ? {
    "@context": "https://schema.org",
    "@type": "ProfessionalService",
    name: p.nomAffiche,
    description: descriptionProfil,
    url: `${window.location.origin}/p/${p.slug}`,
    image: p.couvertureUrl || p.photoProfilUrl || imageMarque,
    ...(p.ville ? { areaServed: p.ville } : {}),
  } : undefined;
  useSeo({
    titre: p ? `${p.nomAffiche}${p.sousTitre ? ` — ${p.sousTitre}` : ""} | Aime Event` : undefined,
    description: descriptionProfil,
    ogImage: p?.couvertureUrl || p?.photoProfilUrl || imageMarque,
    chemin: slug ? `/p/${slug}` : "/profil",
    noindex: !slug,
    structuredData: donneesStructurees,
  });

  useEffect(() => {
    setContenu(null);
    setIntrouvable(false);
    base44.functions
      .invoke("getPublicProfileBySlug", slug ? { slug } : {})
      .then((res) => setContenu(res.data))
      .catch(() => setIntrouvable(true));
  }, [slug]);

  const allerAuContact = () => {
    document.getElementById("section-contact")?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const immersif = p?.styleMiniSite === "immersif" && p?.couvertureUrl;

  return (
    <div className={`theme-apple min-h-screen text-[var(--p-text)] font-body ${immersif ? "" : "bg-[var(--p-bg)]"}`}>
      {immersif && (
        <div aria-hidden="true" className="fixed inset-0 -z-10">
          <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: `url(${p.couvertureUrl})` }} />
          <div className="absolute inset-0 bg-black/75 backdrop-blur-2xl" />
        </div>
      )}
      <EnTetePlateforme />
      {introuvable ? (
        <main className="max-w-4xl mx-auto px-4 md:px-6 py-24 text-center">
          <h1 className="font-heading text-3xl">Profil introuvable</h1>
          <p className="mt-3 text-[var(--p-muted)]">Ce profil n'existe pas ou n'est plus disponible.</p>
          <Link to="/" className="inline-block mt-8 underline text-sm text-[var(--p-muted)] hover:text-[var(--p-text)]">
            Retour à l'accueil
          </Link>
        </main>
      ) : !contenu ? (
        <div className="min-h-screen flex items-center justify-center bg-black">
          <Loader2 className="h-8 w-8 animate-spin text-white/60" />
        </div>
      ) : (
        <>
          {contenu.aRevendiquer && <BandeauRevendication slug={contenu.profil?.slug} />}
          <HeroProfil
            profil={contenu.profil}
            onContact={allerAuContact}
            badge={
              contenu.estDemo
                ? "Profil de démonstration — entreprise fictive"
                : contenu.profil?.slug === "matt"
                ? "Profil fondateur Aime Event"
                : undefined
            }
          />
          <BarreAncresProfil
            ancres={(() => {
              const ordre = contenu.profil?.ordreSections || [];
              const vides = sectionsVides(contenu);
              const base = [
                ["apropos", "À propos"],
                ...(contenu.intermittent ? [["intermittent", "Intermittent"]] : []),
                ["galerie", "Médias"],
                ["repertoire", "Répertoire"],
                ["tarifs", "Tarifs"],
                ["avis", "Avis"],
                ["faq", "FAQ"],
              ].filter(([cle]) => !(contenu.profil?.sectionsMasquees || []).includes(cle) && !vides.includes(cle));
              if (ordre.length > 0) {
                base.sort((a, b) => (ordre.indexOf(a[0]) + 1 || 99) - (ordre.indexOf(b[0]) + 1 || 99));
              }
              return [...base, ["contact", "Contact"]];
            })()}
          />
          <main className="max-w-4xl mx-auto px-4 md:px-6 py-16 pb-24">
            <ProfilPageUnique contenu={contenu} onContact={allerAuContact} />
          </main>
        </>
      )}

      <footer className="pb-[calc(6rem+env(safe-area-inset-bottom))] text-center text-xs text-[var(--p-faint)] tracking-wide space-y-2">
        <p className="font-bold tracking-[0.3em] uppercase">Propulsé par AIME</p>
        <p>Vos informations sont utilisées uniquement pour répondre à votre demande.</p>
        <p className="flex flex-wrap justify-center gap-x-4">
          <Link to="/mentions-legales" className="inline-flex items-center min-h-[32px] px-1 underline hover:text-[var(--p-muted)]">Mentions légales</Link>
          <Link to="/confidentialite" className="inline-flex items-center min-h-[32px] px-1 underline hover:text-[var(--p-muted)]">Politique de confidentialité</Link>
        </p>
      </footer>
    </div>
  );
}