import React from "react";
import EnTetePlateforme from "@/components/plateforme/EnTetePlateforme";
import HeroAccueil from "@/components/accueil/HeroAccueil";
import SectionMoteurCausal from "@/components/accueil/SectionMoteurCausal";
import FaqAccueil from "@/components/accueil/FaqAccueil";
import PiedAccueil from "@/components/accueil/PiedAccueil";
import useSeo from "@/hooks/useSeo";

export default function Accueil() {
  useSeo({
    titre: "Aime Event — Créez et orchestrez votre événement",
    description:
      "Aime Event crée et orchestre vos événements : un assistant transforme votre brief en dossier complet — déroulé intelligent, acteurs, budget, contraintes et plans B — puis le moteur causal recalcule tout en direct le Jour J.",
  });

  return (
    <div className="theme-apple min-h-screen bg-[#050506] text-white font-body">
      <EnTetePlateforme sombre />

      <main>
        <HeroAccueil />
        <SectionMoteurCausal />
        <div className="max-w-5xl mx-auto px-4 md:px-6 pt-10 md:pt-14">
          <FaqAccueil />
        </div>
      </main>

      <PiedAccueil />
    </div>
  );
}