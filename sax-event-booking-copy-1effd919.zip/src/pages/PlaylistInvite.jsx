import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { STYLES_SUGGERES } from "@/lib/playlist";
import EnTetePlateforme from "@/components/plateforme/EnTetePlateforme";
import { Music, Plus, Trash2, Check } from "lucide-react";

const classeInput =
  "min-h-[48px] w-full rounded-xl border border-white/15 bg-white/[0.06] px-3 text-sm text-white placeholder:text-white/35 focus:outline-none focus:border-[#BF5AF2] [color-scheme:dark]";

export default function PlaylistInvite() {
  const { evenementId } = useParams();
  const [infos, setInfos] = useState(undefined);
  const [nom, setNom] = useState("");
  const [morceaux, setMorceaux] = useState([{ titre: "", artiste: "", style: "" }]);
  const [envoi, setEnvoi] = useState(false);
  const [envoye, setEnvoye] = useState(false);
  const [erreur, setErreur] = useState("");

  useEffect(() => {
    base44.functions.invoke("playlistPublique", { evenementId, action: "info" })
      .then((r) => setInfos(r.data))
      .catch(() => setInfos(null));
  }, [evenementId]);

  const majMorceau = (i, champ, valeur) =>
    setMorceaux((l) => l.map((m, idx) => (idx === i ? { ...m, [champ]: valeur } : m)));

  const envoyer = async (e) => {
    e.preventDefault();
    const valides = morceaux.filter((m) => m.titre.trim());
    if (valides.length === 0 || envoi) return;
    setEnvoi(true);
    setErreur("");
    try {
      await base44.functions.invoke("playlistPublique", {
        evenementId,
        action: "ajouter",
        nomInvite: nom.trim(),
        morceaux: valides,
      });
      setEnvoye(true);
    } catch {
      setErreur("L'envoi a échoué, merci de réessayer.");
    }
    setEnvoi(false);
  };

  return (
    <div className="theme-apple min-h-screen bg-[var(--p-bg)] text-[var(--p-text)]">
      <EnTetePlateforme />
      <main className="max-w-2xl mx-auto px-4 md:px-6 py-12 md:py-16">
        {infos === undefined ? (
          <p className="text-sm text-[var(--p-muted)]">Chargement…</p>
        ) : infos === null ? (
          <p className="text-sm text-[var(--p-muted)]">Cet événement est introuvable — vérifiez votre lien.</p>
        ) : envoye ? (
          <div className="text-center py-16">
            <span className="inline-flex h-14 w-14 items-center justify-center rounded-full bg-[#30D158]/15 text-[#30D158] mb-5">
              <Check className="h-7 w-7" />
            </span>
            <h1 className="font-heading text-2xl text-[var(--p-text)]">Merci {nom || ""} !</h1>
            <p className="mt-2 text-sm text-[var(--p-muted)]">
              Vos morceaux ont rejoint la playlist de « {infos.titre} » — les mariés et le DJ les voient déjà.
            </p>
            <button
              type="button"
              onClick={() => { setMorceaux([{ titre: "", artiste: "", style: "" }]); setEnvoye(false); }}
              className="mt-6 min-h-[44px] px-5 rounded-full bg-gradient-to-r from-[#BF5AF2] to-[#0A84FF] text-white text-sm font-bold hover:opacity-90 transition-opacity"
            >
              Proposer d'autres morceaux
            </button>
          </div>
        ) : (
          <>
            <p className="text-[10px] font-bold uppercase tracking-[0.3em] text-[var(--p-muted)]">Playlist collaborative</p>
            <h1 className="mt-2 font-heading text-3xl md:text-4xl text-[var(--p-text)]">{infos.titre}</h1>
            <p className="mt-3 text-sm text-[var(--p-muted)]">
              Proposez les chansons que vous rêvez d'entendre — elles rejoignent directement la playlist des mariés et du DJ, classées par style.
            </p>
            <form onSubmit={envoyer} className="mt-8 space-y-4">
              <input value={nom} onChange={(e) => setNom(e.target.value)} placeholder="Votre prénom" className={classeInput} />
              {morceaux.map((m, i) => (
                <div key={i} className="grid gap-2 sm:grid-cols-[1.2fr_1fr_1fr_auto] items-center">
                  <input value={m.titre} onChange={(e) => majMorceau(i, "titre", e.target.value)} placeholder="Titre du morceau *" className={classeInput} />
                  <input value={m.artiste} onChange={(e) => majMorceau(i, "artiste", e.target.value)} placeholder="Artiste" className={classeInput} />
                  <input value={m.style} onChange={(e) => majMorceau(i, "style", e.target.value)} placeholder="Style" list="styles-invite" className={classeInput} />
                  <button
                    type="button"
                    onClick={() => setMorceaux((l) => l.filter((_, idx) => idx !== i))}
                    disabled={morceaux.length === 1}
                    title="Retirer cette ligne"
                    aria-label="Retirer cette ligne"
                    className="h-10 w-10 inline-flex items-center justify-center rounded-full text-[var(--p-muted)] hover:bg-white/10 disabled:opacity-30 transition-colors"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              ))}
              <datalist id="styles-invite">
                {STYLES_SUGGERES.map((s) => <option key={s} value={s} />)}
              </datalist>
              <div className="flex flex-wrap gap-3">
                <button
                  type="button"
                  onClick={() => setMorceaux((l) => [...l, { titre: "", artiste: "", style: "" }])}
                  className="inline-flex items-center gap-2 min-h-[44px] px-5 rounded-full border border-white/15 text-sm font-semibold text-[var(--p-text)] hover:bg-white/10 transition-colors"
                >
                  <Plus className="h-4 w-4" /> Un autre morceau
                </button>
                <button
                  type="submit"
                  disabled={envoi || !morceaux.some((m) => m.titre.trim())}
                  className="inline-flex items-center gap-2 min-h-[44px] px-6 rounded-full bg-gradient-to-r from-[#BF5AF2] to-[#0A84FF] text-white text-sm font-bold hover:bg-black disabled:opacity-40 transition-colors"
                >
                  <Music className="h-4 w-4" /> {envoi ? "Envoi…" : "Envoyer à la playlist"}
                </button>
              </div>
              {erreur && <p className="text-sm text-[#FF3B30]">{erreur}</p>}
            </form>
          </>
        )}
      </main>
    </div>
  );
}