/* ==================================================================
   AIME® · Ripple — socle commun
   Le catalogue des rôles, les profils de clavier, les réglages.
   Chargé par les trois pages : présentation, réglages, clavier.
================================================================== */
(function (racine) {
  "use strict";

  /* ---- le moteur causal — présent sur toutes les couches, toujours en 0 ---- */
  const SYSTEME = {
    id: "systeme", nom: "AIME · Le Moteur causal", court: "Système",
    c: "#C9B27E", cJour: "#9C8449", meta: true,
    ess: "Quinze rôles, deux couches, une seule mémoire — et rien à refaire.",
  };

  /* ---- les quinze rôles du mariage — un catalogue, pas un clavier ----
     Le clavier, lui, est découpé par profil : chaque métier reçoit
     ses propres touches, dans son propre ordre.                       */
  const ROLES = [
    { id: "couple",    nom: "Couple",                 court: "Couple",    c: "#E2607C", cJour: "#B8355A", famille: "personnes",   ess: "Trois décisions vous attendent — tout le reste peut attendre." },
    { id: "temoin",    nom: "Témoin",                 court: "Témoin",    c: "#D4B36A", cJour: "#96742A", famille: "personnes",   ess: "Le discours : 3 min 40. La surprise : intacte." },
    { id: "famille",   nom: "Famille",                court: "Famille",   c: "#B78A66", cJour: "#8C5F3E", famille: "personnes",   ess: "Mamie a sa chambre, l'oncle a son menu — respirez." },
    { id: "invite",    nom: "Invité",                 court: "Invité",    c: "#93BE8E", cJour: "#4E7F49", famille: "personnes",   ess: "Répondu ✓ · Covoiturage trouvé · Il ne reste qu'à danser." },
    { id: "coordo",    nom: "Coordination",           court: "Coordo",    c: "#EFC94C", cJour: "#9A7B0E", famille: "seuil",       ess: "Toutes les ondes passent par vous — et rien ne déborde." },
    { id: "dj",        nom: "DJ",                     court: "DJ",        c: "#A78BFA", cJour: "#6A4BD6", famille: "prestation",  ess: "BPM branché sur l'orchestration du Jour J." },
    { id: "photo",     nom: "Photographe",            court: "Photo",     c: "#8FB2D9", cJour: "#3F6B9A", famille: "prestation",  ess: "Golden hour : 19 h 42. Sept minutes de miel." },
    { id: "traiteur",  nom: "Traiteur",               court: "Traiteur",  c: "#E0785A", cJour: "#B54A2C", famille: "prestation",  ess: "134 couverts, 6 régimes, 0 improvisation." },
    { id: "lieu",      nom: "Lieu",                   court: "Lieu",      c: "#6FA8A0", cJour: "#39716A", famille: "prestation",  ess: "Le plan B est répété — même la pluie est prévue." },
    { id: "officiant", nom: "Officiant · Le Verbe",   court: "Le Verbe",  c: "#EDE7DA", cJour: "#7E7255", famille: "seuil",       ess: "Les mots sont prêts. Le silence aussi." },
    { id: "fleuriste", nom: "Fleuriste · Le Vivant",  court: "Fleuriste", c: "#D28CB4", cJour: "#8E4A78", famille: "prestation",  ess: "Rien de coupé pour rien : chaque tige a sa table." },
    { id: "mairie",    nom: "Mairie · L'État civil",  court: "Mairie",    c: "#93A0BC", cJour: "#4B5670", famille: "seuil",       ess: "Le dossier est complet. Le reste n'est qu'une fête." },
    { id: "navette",   nom: "Navettes · Le Trajet",   court: "Navettes",  c: "#9CA97C", cJour: "#5C6733", famille: "prestation",  ess: "Personne ne rentrera au volant fatigué." },
    { id: "enfants",   nom: "Enfants d'honneur",      court: "Enfants",   c: "#EFC9A0", cJour: "#9A6B33", famille: "seuil",       ess: "Six enfants, deux paniers, un seul couloir." },
  ];

  const R = Object.fromEntries([...ROLES, SYSTEME].map(r => [r.id, r]));

  /* ==================================================================
     LES PROFILS DE CLAVIER — « qui on est » décide des touches
     couches : jusqu'à 9 rôles chacune, dans l'ordre des chiffres 1–9
     moteur  : la touche 0 (le moteur causal) est-elle donnée ?
     feu     : "ouvrable" — ce profil peut lever le pare-feu causal
               "scelle"   — les ondes masquées lui resteront masquées
     cartes  : les cartes que le panneau a le droit d'ouvrir
  ================================================================== */
  const PROFILS = [
    {
      id: "maries", n: "1", nom: "Futurs mariés", court: "Mariés",
      tagline: "Trois décisions par semaine. Jamais quatre.",
      pour: "Celles et ceux qui se marient — et qui n'ont pas à savoir ce qu'on leur prépare.",
      couches: [
        { nom: "Nos proches",       roles: ["couple", "temoin", "famille", "invite", "coordo"] },
        { nom: "Nos prestataires",  roles: ["lieu", "traiteur", "photo", "dj", "fleuriste", "officiant", "mairie", "navette", "enfants"] },
      ],
      moteur: true, feu: "scelle",
      cartes: ["infos", "stats", "graphe", "pieces"],
      note: "Le pare-feu reste scellé : les surprises préparées pour vous ne s'ouvrent pas depuis ce clavier.",
    },
    {
      id: "invite", n: "2", nom: "Invité", court: "Invité",
      tagline: "Cinq touches, une soirée, zéro question.",
      pour: "Les 148 personnes qui reçoivent un faire-part et veulent juste savoir quoi faire.",
      couches: [
        { nom: "Votre soirée", roles: ["invite", "navette", "lieu", "enfants", "famille"] },
      ],
      moteur: false, feu: "scelle",
      cartes: ["infos", "pieces"],
      note: "Ni moteur, ni statistiques, ni graphe : un invité n'a pas à lire l'organisation.",
    },
    {
      id: "prestataire", n: "3", nom: "Prestataire", court: "Prestataire",
      tagline: "Votre métier en couche 1, vos interlocuteurs en couche 2.",
      pour: "Traiteur, photographe, DJ, fleuriste, officiant, mairie, navettes.",
      couches: [
        { nom: "Vos métiers",         roles: ["traiteur", "photo", "dj", "fleuriste", "officiant", "mairie", "navette"] },
        { nom: "Vos interlocuteurs",  roles: ["coordo", "lieu", "couple", "famille", "invite"] },
      ],
      moteur: true, feu: "ouvrable",
      cartes: ["infos", "stats", "graphe", "pieces"],
      note: "Pare-feu ouvrable : un prestataire doit pouvoir lire ce qu'on lui demande de taire.",
    },
    {
      id: "lieu", n: "4", nom: "Lieu", court: "Lieu",
      tagline: "Un domaine, quarante mariages par an, un seul clavier.",
      pour: "Le domaine, la salle, la ferme — celui qui reçoit et qui rend les clés.",
      couches: [
        { nom: "Le domaine", roles: ["lieu", "traiteur", "navette", "coordo", "dj", "fleuriste", "enfants"] },
      ],
      moteur: true, feu: "ouvrable",
      cartes: ["infos", "stats", "graphe", "pieces"],
      note: "Le clavier du lieu ne parle que de ce qui touche les murs, les horaires et le parking.",
    },
    {
      id: "temoin", n: "5", nom: "Témoin & complices", court: "Témoin",
      tagline: "Le seul clavier qui garde des secrets pour de bon.",
      pour: "Témoins, demoiselles et garçons d'honneur, comploteurs de flashmob.",
      couches: [
        { nom: "La complicité", roles: ["temoin", "invite", "dj", "photo", "coordo", "enfants"] },
      ],
      moteur: true, feu: "ouvrable",
      cartes: ["infos", "stats", "graphe", "pieces"],
      note: "Ici le pare-feu s'ouvre : c'est vous qui tenez les surprises, donc vous qui les voyez.",
    },
    {
      id: "orga", n: "6", nom: "Organisation", court: "Orga",
      tagline: "Les quinze rôles, les deux couches, tout le graphe.",
      pour: "Wedding planner, coordination, et quiconque doit voir l'ensemble.",
      couches: [
        { nom: "Les personnes",         roles: ["couple", "temoin", "famille", "invite", "coordo", "dj", "photo", "traiteur", "lieu"] },
        { nom: "Les métiers du seuil",  roles: ["officiant", "fleuriste", "mairie", "navette", "enfants"] },
      ],
      moteur: true, feu: "ouvrable",
      cartes: ["infos", "stats", "graphe", "pieces"],
      note: "Le clavier complet — celui sur lequel le moteur a été dessiné.",
    },
  ];

  const PROFIL_DEFAUT = "orga";
  const profil = id => PROFILS.find(p => p.id === id) || PROFILS.find(p => p.id === PROFIL_DEFAUT);

  /* ==================================================================
     RÉGLAGES — conservés sur l'appareil (localStorage), jamais sur un serveur.
     Un clavier est un objet personnel : ses réglages n'ont pas à voyager.
  ================================================================== */
  const CLE = "aime.clavier.v1";
  const DEFAUTS = {
    profil: PROFIL_DEFAUT,
    role: "",            /* rôle d'ouverture — vide = le premier de la couche 1 */
    theme: "nuit",
    ctr: 1,              /* contraste */
    fs: 100,             /* zoom typographique, en % */
    lh: 1.55,            /* interligne */
    anim: true,
    souligne: false,
    focus: false,
    panneau: true,       /* le panneau s'ouvre-t-il tout seul à chaque touche ? */
    cartes: ["infos", "stats", "graphe", "pieces"],
  };

  function lire() {
    let brut = null;
    try { brut = JSON.parse(localStorage.getItem(CLE) || "null"); }
    catch (e) { brut = null; }
    const r = Object.assign({}, DEFAUTS, brut || {});
    if (!Array.isArray(r.cartes) || !r.cartes.length) r.cartes = DEFAUTS.cartes.slice();
    r.profil = profil(r.profil).id;
    return r;
  }

  function ecrire(patch) {
    const r = Object.assign(lire(), patch || {});
    try { localStorage.setItem(CLE, JSON.stringify(r)); } catch (e) { /* navigation privée : on continue sans mémoire */ }
    return r;
  }

  function oublier() {
    try { localStorage.removeItem(CLE); } catch (e) { /* rien à oublier */ }
    return Object.assign({}, DEFAUTS);
  }

  /* applique les réglages d'accessibilité au document courant */
  function appliquer(r) {
    r = r || lire();
    const html = document.documentElement;
    html.dataset.theme = r.theme === "jour" ? "jour" : "nuit";
    html.style.setProperty("--ctr", r.ctr);
    html.style.setProperty("--fs", r.fs + "%");
    html.style.setProperty("--lh", r.lh);
    const b = document.body;
    if (b) {
      b.classList.toggle("no-anim", !r.anim || reduitLeMouvement());
      b.classList.toggle("souligne", !!r.souligne);
      b.classList.toggle("focus-fort", !!r.focus);
    }
    return r;
  }

  const reduitLeMouvement = () =>
    !!(window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches);

  /* ---- couleurs ---- */
  const jour = () => document.documentElement.dataset.theme === "jour";
  const couleur = ro => (jour() && ro && ro.cJour) ? ro.cJour : (ro ? ro.c : "#C9B27E");

  /* rampe ordinale champagne — trois pas, du clair au sombre.
     Sert aux barres empilées : une seule teinte, jamais un arc-en-ciel. */
  const rampe = () => jour()
    ? ["#C6B180", "#9C8449", "#6E5B2E"]
    : ["#EBD8AE", "#C9B27E", "#8F7E55"];

  /* ---- format ---- */
  const nb = n => n.toLocaleString("fr-FR");
  const euros = n => n.toLocaleString("fr-FR") + " €";

  racine.AIME = {
    SYSTEME, ROLES, R, PROFILS, PROFIL_DEFAUT,
    profil, lire, ecrire, oublier, appliquer, reduitLeMouvement,
    couleur, rampe, nb, euros,
  };
})(window);
