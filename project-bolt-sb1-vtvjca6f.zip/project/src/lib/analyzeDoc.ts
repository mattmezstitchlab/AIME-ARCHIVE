import type { ImportedDocument } from '@/types';

export function analyzeDocument(fileName: string): ImportedDocument {
  const ext = fileName.split('.').pop()?.toLowerCase() || '';
  const lower = fileName.toLowerCase();

  let type: ImportedDocument['type'] = 'devis';
  if (lower.includes('devis')) type = 'devis';
  else if (lower.includes('contrat')) type = 'contrat';
  else if (lower.includes('facture')) type = 'facture';
  else if (['jpg', 'jpeg', 'png', 'heic', 'webp'].includes(ext)) type = 'image';
  else if (['xls', 'xlsx', 'csv', 'ods'].includes(ext)) type = 'tableur';

  const seed = fileName.split('').reduce((a, c) => a + c.charCodeAt(0), 0);
  const amount = 1200 + (seed % 40) * 750;

  const templates: Record<ImportedDocument['type'], string> = {
    devis: `Prestataire reconnu, proposition détaillée pour ${amount.toLocaleString('fr-FR')} €. Prestations comprises: prestation principale, options, conditions de règlement (30% acompte, solde J-30). Conforme au cahier des charges. Agent MAGRITTE a indexé les conditions, échéances et clauses de révision.`,
    contrat: `Contrat de prestation pour ${amount.toLocaleString('fr-FR')} €. Date d'exécution: juin 2026. Annulation: pénalités graduelles J-90/J-60/J-30. Assurance RC professionnelle fournie. Agent MAGRITTE a extrait les clauses critiques et les dates à suivre.`,
    facture: `Facture n°${seed % 9999} — ${amount.toLocaleString('fr-FR')} €. Émise et payée. TVA 10% applicable. Categorisée et archivée par l'agent dans l'enveloppe budgétaire correspondante.`,
    image: `Photo souvenir capturée. Agent MAGRITTE a analysé la composition, identifié les couleurs dominantes et le contexte. Indexée dans le dossier Inspiration / ${type}.`,
    tableur: `Tableur d'inventaire importé. Agent MAGRITTE a reconnu ${5 + (seed % 20)} lignes, ${3 + (seed % 8)} catégories. Données structurées et prêtes à fusionner avec le budget principal.`,
  };

  return { name: fileName, type, extracted: templates[type], amount };
}
