import type { WeddingPlan } from '@/types';

export function parseIntent(query: string): WeddingPlan {
  const q = query.toLowerCase();

  const guestMatch = q.match(/(\d+)\s*invit/);
  const guests = guestMatch ? parseInt(guestMatch[1]) : 100;

  const budgetMatch = q.match(/(\d+)\s*k|(\d[\d\s]*)\s*€|budget\s*(\d+)/);
  let budget = 30000;
  if (budgetMatch) {
    const raw = (budgetMatch[1] || budgetMatch[2] || budgetMatch[3]).replace(/\s/g, '');
    budget = parseFloat(raw) * (budgetMatch[1] ? 1000 : 1);
  }

  const venueMap: Record<string, string> = {
    château: 'château', manoir: 'manoir', domaine: 'domaine', grange: 'grange', jardin: 'jardin',
  };
  let venue = 'château';
  for (const [kw, val] of Object.entries(venueMap)) if (q.includes(kw)) { venue = val; break; }

  const monthMap: Record<string, string> = {
    janvier: 'janvier', février: 'février', mars: 'mars', avril: 'avril', mai: 'mai',
    juin: 'juin', juillet: 'juillet', août: 'août', septembre: 'septembre',
    octobre: 'octobre', novembre: 'novembre', décembre: 'décembre',
  };
  let month = 'juin';
  for (const [kw, val] of Object.entries(monthMap)) if (q.includes(kw)) { month = val; break; }

  const styleMap: Record<string, string> = {
    champêtre: 'champêtre', bohème: 'bohème', minimaliste: 'minimaliste',
    épuré: 'épuré', luxe: 'luxe', romantique: 'romantique',
  };
  let style = 'épuré';
  for (const [kw, val] of Object.entries(styleMap)) if (q.includes(kw)) { style = val; break; }

  const perGuest = Math.round(budget / guests);
  const dayDuration = guests > 150 ? 20 : 18;
  const sequences = guests > 120 ? 12 : 10;

  const b = budget;
  const budgetLines = [
    { label: 'Lieu & réception', amount: Math.round(b * 0.30), percent: 30 },
    { label: 'Traiteur & boissons', amount: Math.round(b * 0.25), percent: 25 },
    { label: 'Photo & vidéo', amount: Math.round(b * 0.07), percent: 7 },
    { label: 'Décoration & fleurs', amount: Math.round(b * 0.09), percent: 9 },
    { label: 'Musique & animation', amount: Math.round(b * 0.07), percent: 7 },
    { label: 'Tenues & beauté', amount: Math.round(b * 0.08), percent: 8 },
    { label: 'Papeterie & digital', amount: Math.round(b * 0.03), percent: 3 },
    { label: 'Transport & logistique', amount: Math.round(b * 0.05), percent: 5 },
    { label: 'Réserve', amount: Math.round(b * 0.03), percent: 3 },
    { label: 'Honeymoon', amount: Math.round(b * 0.03), percent: 3 },
  ];

  const timeline: { time: string; title: string; detail: string }[] = [
    { time: 'J-12 mois', title: 'Cadrage & budget', detail: `Style ${style}, ${guests} invités, enveloppe ${(b / 1000).toFixed(0)} 000 €` },
    { time: 'J-10 mois', title: 'Lieu réservé', detail: `Visites, options posées, acompte versé sur un ${venue}` },
    { time: 'J-8 mois', title: 'Traiteur & photographe', detail: 'Dégustation, sélection, contrats signés' },
    { time: 'J-6 mois', title: 'Save the date', detail: 'Papeterie, site invités, ouverture des RSVP' },
    { time: 'J-4 mois', title: 'Décoration & fleurs', detail: 'Moodboard validé, scénographie arrêtée' },
    { time: 'J-2 mois', title: 'Plan de table', detail: 'RSVP clos, régimes alimentaires, plan de salle' },
    { time: 'J-3 semaines', title: 'Répétition générale', detail: 'Timing minute par minute, brief des équipes' },
    { time: 'Jour J', title: 'Orchestration', detail: `AIME pilote les ${sequences} séquences, de 08:00 à 02:00` },
  ];

  const vendors = [
    { category: 'Lieu', name: `Un ${venue}`, amount: Math.round(b * 0.30), status: 'confirmer' as const },
    { category: 'Traiteur', name: "Table d'auteur", amount: Math.round(b * 0.25), status: 'degustation' as const },
    { category: 'Photographe', name: 'Reportage argentique', amount: Math.round(b * 0.07), status: 'disponible' as const },
    { category: 'Vidéaste', name: 'Film 6 min', amount: Math.round(b * 0.03), status: 'option' as const },
    { category: 'Fleuriste', name: 'Scénographie végétale', amount: Math.round(b * 0.06), status: 'moodboard' as const },
    { category: 'Musique', name: 'Trio live + DJ', amount: Math.round(b * 0.07), status: 'confirmer' as const },
    { category: 'Beauté', name: 'Coiffure & maquillage', amount: Math.round(b * 0.03), status: 'essai' as const },
    { category: 'Logistique', name: 'Navettes & voiturier', amount: Math.round(b * 0.05), status: 'devis' as const },
  ];

  const guestGroups = [
    { label: 'Famille', count: Math.round(guests * 0.34) },
    { label: 'Amis proches', count: Math.round(guests * 0.30) },
    { label: 'Amis', count: Math.round(guests * 0.18) },
    { label: 'Collègues', count: Math.round(guests * 0.10) },
    { label: 'Enfants', count: Math.round(guests * 0.08) },
  ];

  const daySequences = [
    { time: '08:00', label: 'Préparatifs', width: 8 },
    { time: '13:00', label: 'Cérémonie', width: 10 },
    { time: '15:30', label: 'Cocktail', width: 14 },
    { time: '18:00', label: 'Photos du couple', width: 10 },
    { time: '19:30', label: 'Dîner', width: 17 },
    { time: '22:30', label: 'Ouverture de bal', width: 14 },
    { time: '00:00', label: 'Soirée', width: 15 },
    { time: '02:00', label: 'Fin de service', width: 12 },
  ];

  const synthesis = `Votre célébration prend forme dans un <strong>${venue}</strong> en <strong>${month}</strong>, pour <strong>${guests} invités</strong>, dans une écriture <strong>${style}</strong>. AIME a structuré l'enveloppe, le rétroplanning, les prestataires et la chorégraphie complète du jour J.`;

  return { style, guests, venue, month, budget, perGuest, dayDuration, sequences, synthesis, budgetLines, timeline, vendors, guestGroups, daySequences };
}
