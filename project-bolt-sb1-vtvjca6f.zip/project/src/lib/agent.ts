import type { WeddingPlan } from '@/types';
import { parseIntent } from '@/lib/parseIntent';

export interface ToolCall {
  id: string;
  name: string;
  status: 'pending' | 'running' | 'completed';
  display_projection: {
    label: string;
    active_label: string;
    hide_details: boolean;
    details_redacted: boolean;
  };
}

export interface AgentMessage {
  role: 'user' | 'assistant';
  content: string;
  tool_calls?: ToolCall[];
}

export interface AgentRun {
  userMessage: AgentMessage;
  assistantMessage: AgentMessage;
  plan: WeddingPlan;
  markdownContent: string;
}

export function createAgentRun(query: string): AgentRun {
  const plan = parseIntent(query);

  const toolDefs = [
    { name: 'search_venues', label: `${plan.venue} sélectionné · 3 options comparées`, active: 'Recherche de lieux disponibles' },
    { name: 'calculate_budget', label: `Enveloppe ${(plan.budget / 1000).toFixed(0)} 000 € ventilée`, active: "Calcul de l'enveloppe budgétaire" },
    { name: 'build_timeline', label: 'Rétroplanning J-12 mois généré', active: 'Construction du rétroplanning' },
    { name: 'find_vendors', label: `${plan.vendors.length} prestataires shortlistés`, active: 'Sélection de prestataires' },
    { name: 'plan_day', label: `Chorégraphie ${plan.dayDuration}h établie`, active: 'Chorégraphie du jour J' },
  ];

  const tool_calls: ToolCall[] = toolDefs.map((t, i) => ({
    id: `tool-${i}`,
    name: t.name,
    status: 'pending' as const,
    display_projection: {
      label: t.label,
      active_label: t.active,
      hide_details: false,
      details_redacted: false,
    },
  }));

  const first = plan.daySequences[0];
  const last = plan.daySequences[plan.daySequences.length - 1];

  const markdownContent = `## Synthèse

Votre mariage prend forme : **${plan.guests} invités** dans un **${plan.venue}** en **${plan.month}**, dans une écriture **${plan.style}**.

### Ce que j'ai préparé

- **Budget** : ${(plan.budget / 1000).toFixed(0)} 000 € ventilés sur ${plan.budgetLines.length} postes
- **Rétroplanning** : ${plan.timeline.length} milestones de J-12 mois au jour J
- **Prestataires** : ${plan.vendors.length} pistes priorisées
- **Jour J** : ${plan.daySequences.length} séquences orchestrées de ${first.time} à ${last.time}

Le tableau de bord ci-dessous détaille chaque volet. Importez vos devis et contrats via le bouton **+** — l'agent les analysera et les classera automatiquement.`;

  return {
    userMessage: { role: 'user', content: query },
    assistantMessage: { role: 'assistant', content: '', tool_calls },
    plan,
    markdownContent,
  };
}
