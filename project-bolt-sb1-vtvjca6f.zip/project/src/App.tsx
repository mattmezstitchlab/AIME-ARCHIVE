import { useState, useEffect } from 'react';
import Hero from '@/components/Hero';
import Dashboard from '@/components/Dashboard';
import ImportModal from '@/components/ImportModal';
import AgentPanel from '@/components/AgentPanel';
import { createAgentRun, type AgentRun } from '@/lib/agent';
import type { ImportedDocument } from '@/types';

export default function App() {
  const [state, setState] = useState<'idle' | 'agent' | 'dashboard'>('idle');
  const [run, setRun] = useState<AgentRun | null>(null);
  const [importedDocs, setImportedDocs] = useState<ImportedDocument[]>([]);
  const [importOpen, setImportOpen] = useState(false);
  const [dashboardVisible, setDashboardVisible] = useState(false);

  const handleSubmit = (q: string) => {
    const agentRun = createAgentRun(q);
    setRun(agentRun);
    setDashboardVisible(false);
    setState('agent');
  };

  useEffect(() => {
    if (state === 'dashboard') {
      const t = setTimeout(() => setDashboardVisible(true), 50);
      return () => clearTimeout(t);
    }
  }, [state]);

  return (
    <div
      className="flex flex-col min-h-screen bg-[#FF00A8]"
      style={{ overflowY: state !== 'idle' ? 'auto' : 'hidden' }}
    >
      <Hero
        onSubmit={handleSubmit}
        compact={state !== 'idle'}
        loading={state === 'agent'}
        onImportClick={() => setImportOpen(true)}
      />
      {run && (
        <AgentPanel
          key={run.userMessage.content}
          userMessage={run.userMessage}
          assistantMessage={run.assistantMessage}
          markdownContent={run.markdownContent}
          visible={state === 'agent' || state === 'dashboard'}
          onDone={() => setState('dashboard')}
        />
      )}
      {state === 'dashboard' && run && (
        <Dashboard
          query={run.userMessage.content}
          plan={run.plan}
          visible={dashboardVisible}
          importedDocs={importedDocs}
        />
      )}
      <ImportModal
        open={importOpen}
        onClose={() => setImportOpen(false)}
        onImported={(docs) => setImportedDocs(prev => [...prev, ...docs])}
      />
    </div>
  );
}
