import { useState, useRef, useCallback } from 'react';
import { X, UploadCloud, FileText, Sparkles, CheckCircle2, Loader2 } from 'lucide-react';
import type { ImportedDocument } from '@/types';
import { analyzeDocument } from '@/lib/analyzeDoc';

interface ImportModalProps {
  open: boolean;
  onClose: () => void;
  onImported: (docs: ImportedDocument[]) => void;
}

const STAGES = [
  'Lecture du document',
  'Extraction du contenu',
  'Remise au propre',
  'Classification & indexation',
  'Intégration au dossier',
];

export default function ImportModal({ open, onClose, onImported }: ImportModalProps) {
  const [dragging, setDragging] = useState(false);
  const [docs, setDocs] = useState<ImportedDocument[]>([]);
  const [processing, setProcessing] = useState(false);
  const [stage, setStage] = useState(0);
  const [done, setDone] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const reset = useCallback(() => {
    setDocs([]);
    setProcessing(false);
    setStage(0);
    setDone(false);
  }, []);

  const handleClose = () => {
    if (processing) return;
    reset();
    onClose();
  };

  const handleFiles = (files: FileList | null) => {
    if (!files || files.length === 0) return;
    const analyzed = Array.from(files).map(f => analyzeDocument(f.name));
    setDocs(analyzed);
    runPipeline();
  };

  const runPipeline = async () => {
    setProcessing(true);
    setStage(0);
    for (let i = 0; i < STAGES.length; i++) {
      setStage(i);
      await new Promise(r => setTimeout(r, 750));
    }
    setProcessing(false);
    setDone(true);
  };

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: 'rgba(255, 0, 168, 0.5)', backdropFilter: 'blur(8px)', WebkitBackdropFilter: 'blur(8px)' }}
      onClick={handleClose}
    >
      <div
        className="bg-[#FF00A8] rounded-3xl w-full max-w-lg overflow-hidden border border-white/20"
        style={{ boxShadow: '0 40px 80px -20px rgba(0,0,0,0.4)' }}
        onClick={e => e.stopPropagation()}
      >
        {/* header */}
        <div className="flex items-center justify-between p-5 border-b border-white/15">
          <div className="flex items-center gap-2.5">
            <Sparkles size={18} className="text-white" />
            <span className="text-white font-light tracking-wide">Import & extraction</span>
          </div>
          <button
            onClick={handleClose}
            disabled={processing}
            className="w-8 h-8 rounded-full flex items-center justify-center bg-white/10 hover:bg-white/20 text-white transition disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <X size={16} />
          </button>
        </div>

        {/* body */}
        <div className="p-6">
          {docs.length === 0 && (
            <div
              className="border-2 border-dashed border-white/30 rounded-2xl p-10 text-center transition-colors cursor-pointer"
              style={{ background: dragging ? 'rgba(255,255,255,0.12)' : 'rgba(255,255,255,0.05)' }}
              onDragOver={e => { e.preventDefault(); setDragging(true); }}
              onDragLeave={() => setDragging(false)}
              onDrop={e => { e.preventDefault(); setDragging(false); handleFiles(e.dataTransfer.files); }}
              onClick={() => inputRef.current?.click()}
            >
              <UploadCloud size={36} className="text-white/70 mx-auto mb-3" />
              <p className="text-white/90 text-sm">Glissez vos documents ici</p>
              <p className="text-white/50 text-xs mt-1">devis, contrats, factures, photos, tableurs</p>
              <input
                ref={inputRef}
                type="file"
                multiple
                className="hidden"
                onChange={e => handleFiles(e.target.files)}
              />
            </div>
          )}

          {docs.length > 0 && (
            <div className="space-y-4">
              {/* file chips */}
              <div className="flex flex-wrap gap-2">
                {docs.map((d, i) => (
                  <div
                    key={i}
                    className="flex items-center gap-2 bg-white/10 rounded-full pl-2.5 pr-3 py-1.5"
                  >
                    <FileText size={13} className="text-white/70" />
                    <span className="text-white/90 text-xs">{d.name}</span>
                  </div>
                ))}
              </div>

              {/* pipeline */}
              <div className="bg-white/5 rounded-2xl p-4 space-y-2.5">
                {STAGES.map((label, i) => {
                  const active = processing && i === stage;
                  const complete = (processing && i < stage) || (done && true);
                  return (
                    <div key={i} className="flex items-center gap-3">
                      <div className="w-5 h-5 flex-shrink-0">
                        {active && <Loader2 size={20} className="text-white animate-spin" />}
                        {!active && complete && <CheckCircle2 size={20} className="text-white" />}
                        {!active && !complete && (
                          <div className="w-5 h-5 rounded-full border border-white/20" />
                        )}
                      </div>
                      <span
                        className={`text-sm transition-opacity ${
                          active || complete ? 'text-white' : 'text-white/40'
                        }`}
                      >
                        {label}
                      </span>
                    </div>
                  );
                })}
              </div>

              {/* extracted preview */}
              {(done || (processing && stage >= 1)) && docs.map((d, i) => (
                <div
                  key={i}
                  className="bg-white/10 rounded-2xl p-4 border border-white/10"
                  style={{ opacity: done ? 1 : 0.6 }}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-white/90 text-xs font-medium">{d.name}</span>
                    {d.amount && (
                      <span className="text-white/70 text-xs tabular-nums">{d.amount.toLocaleString('fr-FR')} €</span>
                    )}
                  </div>
                  <p className="text-white/70 text-xs leading-relaxed">{d.extracted}</p>
                </div>
              ))}

              {done && (
                <button
                  onClick={() => { onImported(docs); handleClose(); }}
                  className="w-full py-3 rounded-full bg-white text-[#FF00A8] font-medium text-sm hover:bg-white/90 transition active:scale-[0.98]"
                >
                  Intégrer au dossier
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
