import { useState, useRef } from 'react';
import { Send, Plus } from 'lucide-react';

const PLACEHOLDERS = [
  'Un mariage de 120 invités dans un château en juin, budget 60k…',
  'Trouver un photographe disponible en juillet…',
  'Mariage champêtre 80 invités, budget 25 000€…',
  'Orchestrer mon jour J de A à Z…',
];

interface HeroProps {
  onSubmit: (query: string) => void;
  compact: boolean;
  loading: boolean;
  onImportClick: () => void;
}

export default function Hero({ onSubmit, compact, loading, onImportClick }: HeroProps) {
  const [value, setValue] = useState('');
  const [phIndex, setPhIndex] = useState(0);
  const [phFading, setPhFading] = useState(false);
  const [focused, setFocused] = useState(false);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const startRotation = () => {
    intervalRef.current = setInterval(() => {
      setPhFading(true);
      setTimeout(() => {
        setPhIndex(i => (i + 1) % PLACEHOLDERS.length);
        setPhFading(false);
      }, 300);
    }, 3500);
  };

  const stopRotation = () => {
    if (intervalRef.current) clearInterval(intervalRef.current);
    intervalRef.current = null;
  };

  const handleFocus = () => {
    setFocused(true);
    stopRotation();
  };

  const handleBlur = () => {
    setFocused(false);
    if (!value.trim()) startRotation();
  };

  const handleSubmit = () => {
    const q = value.trim();
    if (!q || loading) return;
    stopRotation();
    onSubmit(q);
  };

  return (
    <header
      className={`w-full flex flex-col items-center justify-center bg-[#FF00A8] transition-all duration-700 ease-in-out overflow-hidden relative z-10 ${
        compact ? 'py-6' : 'min-h-screen'
      }`}
      style={{ flexShrink: 0 }}
    >
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: 'radial-gradient(ellipse 80% 60% at 50% 40%, rgba(255,100,180,0.35) 0%, transparent 70%)',
        }}
      />

      <div className={`flex flex-col items-center transition-all duration-700 ${compact ? 'gap-3' : 'gap-10'} relative`}>
        <div className="text-center select-none">
          <h1
            className={`text-white font-light tracking-[0.25em] uppercase transition-all duration-700 ${
              compact ? 'text-2xl' : 'text-5xl'
            }`}
            style={{ fontFamily: 'Georgia, serif' }}
          >
            MAGRITTE
          </h1>
          <p
            className={`text-white/60 tracking-[0.3em] uppercase font-light transition-all duration-700 ${
              compact ? 'text-[9px] mt-0.5' : 'text-xs mt-2'
            }`}
          >
            L'amour d'une vie
          </p>
        </div>

        <div
          className={`flex items-center rounded-full border transition-all duration-300 ${
            compact ? 'w-[min(600px,90vw)]' : 'w-[min(700px,90vw)]'
          } ${
            focused
              ? 'bg-white/25 border-white/60 shadow-[0_0_0_4px_rgba(255,255,255,0.15)]'
              : 'bg-white/15 border-white/30'
          }`}
          style={{ backdropFilter: 'blur(16px)', WebkitBackdropFilter: 'blur(16px)', padding: '8px 10px' }}
        >
          <button
            onClick={onImportClick}
            className="w-11 h-11 rounded-full flex items-center justify-center bg-white/90 text-[#FF00A8] hover:bg-white hover:scale-105 active:scale-95 transition-all flex-shrink-0"
            title="Importer un document"
          >
            <Plus size={18} />
          </button>

          <input
            className="flex-1 bg-transparent border-none outline-none text-white placeholder-white/60 px-5 text-base"
            placeholder={PLACEHOLDERS[phIndex]}
            value={value}
            onChange={e => setValue(e.target.value)}
            onFocus={handleFocus}
            onBlur={handleBlur}
            onKeyDown={e => e.key === 'Enter' && handleSubmit()}
            disabled={loading}
            autoComplete="off"
            style={{ opacity: phFading && !focused ? 0 : 1, transition: 'opacity 0.3s' }}
          />

          <button
            onClick={handleSubmit}
            disabled={loading || !value.trim()}
            className="w-11 h-11 rounded-full flex items-center justify-center bg-white/90 text-[#FF00A8] hover:bg-white hover:scale-105 active:scale-95 transition-all flex-shrink-0 disabled:opacity-50 disabled:cursor-not-allowed"
            title="Générer"
          >
            {loading ? (
              <svg className="animate-spin" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M21 12a9 9 0 1 1-6.219-8.56" />
              </svg>
            ) : (
              <Send size={16} />
            )}
          </button>
        </div>
      </div>
    </header>
  );
}
