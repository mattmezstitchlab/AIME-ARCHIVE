import type { BudgetLine } from '@/types';

interface BudgetDonutProps {
  lines: BudgetLine[];
  total: number;
  visible: boolean;
}

const COLORS = [
  '#ffffff', '#ffe0f5', '#ffb3e6', '#ff80d4', '#ff4dc3', '#ff1ab2',
  '#e600a0', '#cc008e', '#b3007c', '#99006a',
];

export default function BudgetDonut({ lines, total, visible }: BudgetDonutProps) {
  const size = 220;
  const cx = size / 2;
  const cy = size / 2;
  const r = 80;
  const strokeW = 28;

  let cumAngle = -90;
  const slices = lines.map((line, i) => {
    const angle = (line.percent / 100) * 360;
    const start = cumAngle;
    cumAngle += angle;
    return { ...line, start, angle, color: COLORS[i % COLORS.length] };
  });

  function arc(startDeg: number, angleDeg: number) {
    const start = (startDeg * Math.PI) / 180;
    const end = ((startDeg + angleDeg - 0.5) * Math.PI) / 180;
    const x1 = cx + r * Math.cos(start);
    const y1 = cy + r * Math.sin(start);
    const x2 = cx + r * Math.cos(end);
    const y2 = cy + r * Math.sin(end);
    const large = angleDeg > 180 ? 1 : 0;
    return `M ${x1} ${y1} A ${r} ${r} 0 ${large} 1 ${x2} ${y2}`;
  }

  const fmt = (n: number) => n >= 1000 ? (n / 1000).toFixed(0) + ' 000' : n.toString();

  return (
    <div className="flex flex-col sm:flex-row items-center gap-8">
      <div className="relative flex-shrink-0" style={{ width: size, height: size }}>
        <svg width={size} height={size}>
          {/* background ring */}
          <circle cx={cx} cy={cy} r={r} fill="none" stroke="rgba(255,255,255,0.12)" strokeWidth={strokeW} />
          {slices.map((s, i) => (
            <path
              key={i}
              d={arc(s.start, s.angle)}
              fill="none"
              stroke={s.color}
              strokeWidth={strokeW}
              strokeLinecap="butt"
              style={{
                opacity: visible ? 1 : 0,
                transition: `opacity 0.4s ease ${0.4 + i * 0.07}s`,
              }}
            />
          ))}
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
          <p className="text-white text-2xl font-light tracking-tight">{fmt(total)} €</p>
          <p className="text-white/50 text-[9px] uppercase tracking-[0.2em] mt-1">enveloppe</p>
        </div>
      </div>

      <div className="flex-1 space-y-2.5 w-full">
        {lines.map((line, i) => (
          <div key={i}>
            <div className="flex justify-between text-xs mb-1">
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: COLORS[i % COLORS.length] }} />
                <span className="text-white/80">{line.label}</span>
              </div>
              <span className="text-white/50 tabular-nums">{line.amount.toLocaleString('fr-FR')} €&nbsp;·&nbsp;{line.percent}%</span>
            </div>
            <div className="h-1 rounded-full bg-white/10 overflow-hidden">
              <div
                className="h-full rounded-full transition-all duration-1000"
                style={{
                  width: visible ? `${line.percent}%` : '0%',
                  background: COLORS[i % COLORS.length],
                  transitionDelay: `${0.5 + i * 0.07}s`,
                }}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
