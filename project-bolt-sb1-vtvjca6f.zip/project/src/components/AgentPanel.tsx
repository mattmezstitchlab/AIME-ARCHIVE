import { useState, useEffect, useRef } from 'react';
import AccountAgentMessage from '@/components/AccountAgentMessage';
import type { AgentMessage, ToolCall } from '@/lib/agent';

interface AgentPanelProps {
  userMessage: AgentMessage;
  assistantMessage: AgentMessage;
  markdownContent: string;
  visible: boolean;
  onDone: () => void;
}

const TOOL_DURATION = 850;
const TOOL_GAP = 200;

export default function AgentPanel({ userMessage, assistantMessage, markdownContent, visible, onDone }: AgentPanelProps) {
  const [tools, setTools] = useState<ToolCall[]>([]);
  const [content, setContent] = useState('');
  const doneRef = useRef(false);

  useEffect(() => {
    if (!visible || doneRef.current) return;
    let cancelled = false;

    const run = async () => {
      const allTools = assistantMessage.tool_calls || [];
      const visibleTools: ToolCall[] = [];

      for (let i = 0; i < allTools.length; i++) {
        if (cancelled) return;
        visibleTools.push({ ...allTools[i], status: 'running' });
        setTools([...visibleTools]);
        await sleep(TOOL_DURATION);
        if (cancelled) return;
        visibleTools[i] = { ...visibleTools[i], status: 'completed' };
        setTools([...visibleTools]);
        await sleep(TOOL_GAP);
      }
      if (cancelled) return;
      setContent(markdownContent);
      doneRef.current = true;
      onDone();
    };

    run();
    return () => { cancelled = true; };
  }, [visible]);

  const msg: AgentMessage = {
    ...assistantMessage,
    content,
    tool_calls: tools,
  };

  return (
    <div
      className="w-full max-w-3xl mx-auto px-6 py-6 space-y-4"
      style={{
        opacity: visible ? 1 : 0,
        transition: 'opacity 0.5s ease 0.2s',
      }}
    >
      <AccountAgentMessage message={userMessage} />
      <AccountAgentMessage message={msg} />
    </div>
  );
}

function sleep(ms: number) {
  return new Promise(r => setTimeout(r, ms));
}
