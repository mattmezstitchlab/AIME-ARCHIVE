import type { WeddingPlan, ImportedDocument } from '@/types';
import BudgetDonut from '@/components/BudgetDonut';

interface DashboardProps {
  query: string;
  plan: WeddingPlan;
  visible: boolean;
  importedDocs: ImportedDocument[];
}

function fmt(n: number) {
  return n.toLocaleString('fr-FR') + ' €';
}

function GlassCard({
  label, tag, children, delay, visible, accent = 'white'
}: {
  label: string;
  tag: { text: string };
  children: React.ReactNode;
  delay: number;
  visible: boolean;
  accent?: 'white' | 'pink';
}) {
  return (
    <div
      className="rounded-3xl p-6"
      style={{
        background: 'rgba(255,255,255,0.06)',
        border: '1px solid rgba(255,255,255,0.12)',
        opacity: visible ? 1 : 0,
        transform: visible ? 'translateY(0)' : 'translateY(24px)',
        transition: `opacity 0.5s ease ${0.4 + delay * 0.1}s, transform 0.5s cubic-bezier(0.2,0.8,0.2,1) ${0.4 + delay * 0.1}s`,
      }}
    >
      <div className="flex items-center justify-between mb-4">
        <span
          className="text-[10px] uppercase tracking-[0.22em] font-medium"
          style={{ color: accent === 'pink' ? '#ffe0f5' : 'rgba(255,255,255,0.5)' }}
        >
          {label}
        </span>
        <span
          className="text-[10px] uppercase tracking-widest font-semibold"
          style={{ color: accent === 'pink' ? '#fff' : 'rgba(255,255,255,0.4)' }}
        >
          {tag.text}
        </span>
      </div>
      {children}
    </div>
  );
}

export default function Dashboard({ query, plan, visible, importedDocs }: DashboardProps) {
  const totalSpent = plan.budgetLines.reduce((a, b) => a + b.amount, 0);
  const docsCount = importedDocs.length;

  return (
    <main
      className="flex-1 overflow-auto"
      style={{
        background: 'linear-gradient(180deg, #FF00A8 0%, #e60098 100%)',
        opacity: visible ? 1 : 0,
        transform: visible ? 'translateY(0)' : 'translateY(60px)',
        transition: 'opacity 0.7s ease 0.3s, transform 0.7s cubic-bezier(0.2,0.8,0.2,1) 0.3s',
        visibility: visible ? 'visible' : 'hidden',
      }}
    >
      <div className="max-w-5xl mx-auto px-6 py-10 space-y-6">
        {/* Query echo */}
        <div
          className="flex items-center gap-3 text-sm"
          style={{ opacity: visible ? 1 : 0, transition: 'opacity 0.4s ease 0.5s' }}
        >
          <span className="w-2 h-2 rounded-full bg-white animate-pulse" />
          <span className="text-white/60 italic">{query}</span>
        </div>

        {/* Synthèse */}
        <GlassCard label="Synthèse" tag={{ text: plan.style }} delay={0} visible={visible} accent="pink">
          <p
            className="text-white/90 leading-relaxed text-[0.95rem]"
            dangerouslySetInnerHTML={{ __html: plan.synthesis }}
          />
          <div className="mt-6 grid grid-cols-2 sm:grid-cols-5 gap-4 border-t border-white/10 pt-5">
            {[
              { value: plan.guests.toString(), label: 'Invités' },
              { value: fmt(plan.budget), label: 'Enveloppe' },
              { value: fmt(plan.perGuest), label: 'Par convive' },
              { value: plan.dayDuration + 'h', label: 'Jour J' },
              { value: plan.sequences.toString(), label: 'Séquences' },
            ].map(s => (
              <div key={s.label}>
                <p className="text-2xl font-light text-white tracking-tight">{s.value}</p>
                <p className="text-[10px] text-white/40 uppercase tracking-widest mt-0.5">{s.label}</p>
              </div>
            ))}
          </div>
        </GlassCard>

        {/* Budget donut + lines */}
        <GlassCard label="Budget" tag={{ text: 'Répartition' }} delay={1} visible={visible}>
          <BudgetDonut lines={plan.budgetLines} total={totalSpent} visible={visible} />
        </GlassCard>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {/* Rétroplanning */}
          <GlassCard label="Rétroplanning" tag={{ text: 'Milestones' }} delay={2} visible={visible}>
            <div className="space-y-4 relative">
              <div
                className="absolute left-[10px] top-2 bottom-2 w-px"
                style={{ background: 'rgba(255,255,255,0.12)' }}
              />
              {plan.timeline.map((step, i) => (
                <div
                  key={i}
                  className="flex gap-3 relative"
                  style={{
                    opacity: visible ? 1 : 0,
                    transform: visible ? 'translateX(0)' : 'translateX(10px)',
                    transition: `opacity 0.4s ease ${0.6 + i * 0.08}s, transform 0.4s ease ${0.6 + i * 0.08}s`,
                  }}
                >
                  <div className="relative flex-shrink-0">
                    <div className="w-5 h-5 rounded-full border-2 border-white/30 bg-[#FF00A8] z-10 relative" />
                  </div>
                  <div>
                    <p className="text-white text-xs font-medium">{step.time}</p>
                    <p className="text-white/80 text-sm font-medium mt-0.5">{step.title}</p>
                    <p className="text-white/50 text-xs leading-snug mt-0.5">{step.detail}</p>
                  </div>
                </div>
                ))}
              </div>
          </GlassCard>

          {/* Prestataires */}
          <GlassCard label="Prestataires" tag={{ text: plan.vendors.length + ' pistes' }} delay={3} visible={visible}>
            <div className="space-y-3">
              {plan.vendors.map((v, i) => (
                <div
                  key={i}
                  className="flex items-center justify-between gap-3"
                  style={{
                    opacity: visible ? 1 : 0,
                    transform: visible ? 'translateY(0)' : 'translateY(8px)',
                    transition: `opacity 0.4s ease ${0.7 + i * 0.06}s, transform 0.4s ease ${0.7 + i * 0.06}s`,
                  }}
                >
                  <div className="flex-1 min-w-0">
                    <p className="text-white/90 text-sm font-medium">{v.category}</p>
                    <p className="text-white/50 text-xs truncate">{v.name}</p>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <p className="text-white/70 text-xs tabular-nums">{fmt(v.amount)}</p>
                    <span
                      className="text-[9px] uppercase tracking-wider px-2 py-0.5 rounded-full inline-block mt-1"
                      style={{
                        background: 'rgba(255,255,255,0.12)',
                        color: 'rgba(255,255,255,0.8)',
                      }}
                    >
                      {v.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </GlassCard>
        </div>

        {/* Invités breakdown */}
        <GlassCard label="Invités" tag={{ text: plan.guests + ' convives' }} delay={4} visible={visible}>
          <div className="space-y-3">
            {plan.guestGroups.map((g, i) => {
              const pct = Math.round((g.count / plan.guests) * 100);
              return (
                <div key={i}>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-white/80">{g.label}</span>
                    <span className="text-white/50 tabular-nums">{g.count}&nbsp;·&nbsp;{pct}%</span>
                  </div>
                  <div className="h-2 rounded-full bg-white/10 overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-1000"
                      style={{
                        width: visible ? `${pct}%` : '0%',
                        background: 'linear-gradient(90deg, #ffffff 0%, #ffb3e6 100%)',
                        transitionDelay: `${0.8 + i * 0.1}s`,
                      }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </GlassCard>

        {/* Chorégraphie du jour J */}
        <GlassCard label="Chorégraphie du jour J" tag={{ text: plan.dayDuration + 'h' }} delay={5} visible={visible} accent="pink">
          <div className="flex gap-0 overflow-x-auto pb-3">
            {plan.daySequences.map((seq, i) => {
              const colors = ['#ffffff', '#ffe0f5', '#ffb3e6', '#ff80d4', '#ff4dc3', '#ff1ab2', '#e600a0', '#cc008e'];
              return (
                <div
                  key={i}
                  className="flex-shrink-0 flex flex-col items-center"
                  style={{
                    width: `${seq.width}%`,
                    minWidth: 64,
                    opacity: visible ? 1 : 0,
                    transform: visible ? 'translateY(0)' : 'translateY(10px)',
                    transition: `opacity 0.4s ease ${0.9 + i * 0.08}s, transform 0.4s ease ${0.9 + i * 0.08}s`,
                  }}
                >
                  <div
                    className="w-full flex items-center justify-center text-[10px] font-medium text-[#FF00A8] tracking-wide relative overflow-hidden"
                    style={{
                      background: colors[i % colors.length],
                      height: 32,
                      borderRadius: i === 0 ? '10px 0 0 10px' : i === plan.daySequences.length - 1 ? '0 10px 10px 0' : '0',
                    }}
                  >
                    {seq.label}
                  </div>
                  <p className="text-[10px] text-white/60 mt-1.5 font-medium">{seq.time}</p>
                </div>
              );
            })}
          </div>
        </GlassCard>

        {/* Documents importés */}
        {docsCount > 0 && (
          <GlassCard label="Documents" tag={{ text: docsCount + ' fichiers' }} delay={6} visible={visible}>
            <div className="space-y-3">
              {importedDocs.map((d, i) => (
                <div
                  key={i}
                  className="flex items-start gap-3 p-3 rounded-2xl"
                  style={{ background: 'rgba(255,255,255,0.05)' }}
                >
                  <div className="w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center flex-shrink-0">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2">
                      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                      <path d="M14 2v6h6" />
                    </svg>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <span className="text-white/90 text-sm font-medium truncate">{d.name}</span>
                      {d.amount && (
                        <span className="text-white/60 text-xs tabular-nums flex-shrink-0 ml-2">{fmt(d.amount)}</span>
                      )}
                    </div>
                    <p className="text-white/50 text-xs leading-snug mt-1">{d.extracted}</p>
                  </div>
                </div>
              ))}
            </div>
          </GlassCard>
        )}
      </div>
    </main>
  );
}
