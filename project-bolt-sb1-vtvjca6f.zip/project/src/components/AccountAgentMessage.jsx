import React from "react";
import ReactMarkdown from "react-markdown";
import { Check, Loader2, XCircle } from "lucide-react";

const markdownComponents = {
  h1: ({ children }) => <h2 className="border-b border-white/20 pb-2 text-xl font-medium text-white">{children}</h2>,
  h2: ({ children }) => <h3 className="border-b border-white/20 pb-2 text-lg font-medium text-white">{children}</h3>,
  h3: ({ children }) => <h4 className="text-base font-medium text-white">{children}</h4>,
  p: ({ children }) => <p className="leading-relaxed text-white/70">{children}</p>,
  ul: ({ children }) => <ul className="space-y-2 pl-5 text-white/70 marker:text-white">{children}</ul>,
  ol: ({ children }) => <ol className="space-y-3 pl-5 text-white/70 marker:font-mono marker:text-white">{children}</ol>,
  li: ({ children }) => <li className="pl-1 leading-relaxed">{children}</li>,
  strong: ({ children }) => <strong className="font-medium text-white">{children}</strong>,
};

export default function AccountAgentMessage({ message }) {
  const user = message.role === "user";
  return <div className={user ? "flex justify-end" : "flex justify-start"}><div className={user ? "max-w-[85%] bg-white p-3 text-sm text-[#FF00A8] rounded-2xl rounded-br-md" : "w-full max-w-[95%] border border-white/15 bg-white/5 p-4 text-sm rounded-2xl rounded-bl-md"} style={{backdropFilter: 'blur(12px)', WebkitBackdropFilter: 'blur(12px)'}}>
    {message.content && (user ? <p>{message.content}</p> : <div className="space-y-4"><ReactMarkdown components={markdownComponents}>{message.content}</ReactMarkdown></div>)}
    {message.tool_calls?.map((tool, index) => <ToolState key={index} tool={tool}/>)}
  </div></div>;
}

function ToolState({ tool }) {
  const failed = ["failed", "error"].includes(tool.status), active = ["pending", "running", "in_progress"].includes(tool.status);
  const hidden = tool.display_projection?.hide_details && tool.display_projection?.details_redacted;
  const label = failed ? tool.display_projection?.error_label || "Action impossible" : active ? tool.display_projection?.active_label || "Action en cours" : tool.display_projection?.label || "Action terminée";
  const Icon = failed ? XCircle : active ? Loader2 : Check;
  return <div className="mt-2 flex items-center gap-2 border-t border-white/15 pt-2 font-mono text-[10px] uppercase tracking-widest text-white/80"><Icon className={active ? "h-3 w-3 animate-spin" : "h-3 w-3"}/>{hidden ? label : `${label} · ${tool.name}`}</div>;
}
