export interface BudgetLine {
  label: string;
  amount: number;
  percent: number;
}

export interface TimelineStep {
  time: string;
  title: string;
  detail: string;
}

export interface Vendor {
  category: string;
  name: string;
  amount: number;
  status: 'confirmer' | 'disponible' | 'option' | 'degustation' | 'moodboard' | 'essai' | 'devis';
}

export interface GuestGroup {
  label: string;
  count: number;
}

export interface DaySequence {
  time: string;
  label: string;
  width: number;
}

export interface WeddingPlan {
  style: string;
  guests: number;
  venue: string;
  month: string;
  budget: number;
  perGuest: number;
  dayDuration: number;
  sequences: number;
  synthesis: string;
  budgetLines: BudgetLine[];
  timeline: TimelineStep[];
  vendors: Vendor[];
  guestGroups: GuestGroup[];
  daySequences: DaySequence[];
}

export interface ImportedDocument {
  name: string;
  type: 'devis' | 'contrat' | 'facture' | 'image' | 'tableur';
  extracted: string;
  amount?: number;
}
