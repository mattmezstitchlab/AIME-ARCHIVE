/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        border: 'rgba(255,255,255,0.15)',
        cobalt: '#ffffff',
        foreground: '#ffffff',
        background: '#FF00A8',
        'muted-foreground': 'rgba(255,255,255,0.6)',
      },
    },
  },
  plugins: [],
};
