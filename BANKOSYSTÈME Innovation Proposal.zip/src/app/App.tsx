import { useRef, useState, useEffect } from "react";
import { motion, useInView } from "motion/react";
import {
  ArrowRight,
  ArrowDown,
  Users,
  Zap,
  BarChart3,
  Shield,
  TrendingUp,
  Target,
  Clock,
  AlertTriangle,
  CheckCircle2,
  DollarSign,
  FileText,
  Brain,
  Lock,
  Building2,
  Rocket,
  Star,
  Eye,
  Banknote,
  ChevronDown,
  ChevronUp,
  BadgeCheck,
  Sparkles,
  Code,
  Megaphone,
  ArrowUpRight,
  PieChart as PieChartIcon,
} from "lucide-react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  Cell,
  PieChart,
  Pie,
} from "recharts";
import { DemoPortail } from "./components/DemoPortail";
import { DemoMatching } from "./components/DemoMatching";
import { DemoCockpit } from "./components/DemoCockpit";

/* ─── Animated section ─── */
function S({
  children,
  id,
  className = "",
}: {
  children: React.ReactNode;
  id?: string;
  className?: string;
}) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-50px" });
  return (
    <motion.section
      ref={ref}
      id={id}
      initial={{ opacity: 0, y: 30 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.55, ease: "easeOut" }}
      className={className}
    >
      {children}
    </motion.section>
  );
}

/* ─── Section badge ─── */
function Badge({ color, children }: { color: string; children: string }) {
  return (
    <span
      className="inline-block text-xs tracking-widest px-3 py-1 rounded-full"
      style={{ backgroundColor: color + "12", color }}
    >
      {children}
    </span>
  );
}

/* ─── Counter ─── */
function Counter({ target, suffix = "" }: { target: number; suffix?: string }) {
  const [val, setVal] = useState(0);
  const ref = useRef(null);
  const inView = useInView(ref, { once: true });

  useEffect(() => {
    if (!inView) return;
    let step = 0;
    const steps = 35;
    const timer = setInterval(() => {
      step++;
      setVal(Math.round(target * (1 - Math.pow(1 - step / steps, 3))));
      if (step >= steps) clearInterval(timer);
    }, 30);
    return () => clearInterval(timer);
  }, [inView, target]);

  return <span ref={ref}>{val.toLocaleString()}{suffix}</span>;
}

/* ─── Data ─── */
const revenueData = [
  { y: "2026", sans: 100, avec: 118 },
  { y: "2027", sans: 104, avec: 155 },
  { y: "2028", sans: 108, avec: 198 },
  { y: "2029", sans: 112, avec: 248 },
  { y: "2030", sans: 116, avec: 310 },
];

const painBars = [
  { name: "Dossiers retournes", pct: 68, color: "#C4122F" },
  { name: "Clients isoles", pct: 72, color: "#E8453C" },
  { name: "Montages abandonnes", pct: 60, color: "#F5A623" },
  { name: "Flux non captes", pct: 45, color: "#F5A623" },
];

const roiPie = [
  { name: "Credits", value: 40, color: "#002B5C" },
  { name: "Assurances", value: 22, color: "#0066CC" },
  { name: "Comptes pro", value: 18, color: "#00A86B" },
  { name: "SCI / Invest.", value: 12, color: "#F5A623" },
  { name: "Retention", value: 8, color: "#5A6378" },
];

const nav = [
  { id: "hero", label: "Accueil" },
  { id: "probleme", label: "Probleme" },
  { id: "solution", label: "Solution" },
  { id: "demo-portail", label: "Demo Portail" },
  { id: "demo-matching", label: "Demo Matching" },
  { id: "demo-cockpit", label: "Demo Cockpit" },
  { id: "cas", label: "Cas concrets" },
  { id: "roi", label: "ROI" },
  { id: "roadmap", label: "Roadmap" },
  { id: "securite", label: "Securite" },
];

/* ═══════════════════════════════════════════ */
export default function App() {
  const [showNav, setShowNav] = useState(false);
  const [faqOpen, setFaqOpen] = useState<number | null>(null);

  useEffect(() => {
    const onScroll = () => setShowNav(window.scrollY > 400);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div className="min-h-screen font-[Inter,sans-serif]">
      {/* ─── Sticky nav ─── */}
      <motion.nav
        initial={false}
        animate={{ y: showNav ? 0 : -80 }}
        className="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-md border-b border-border shadow-sm"
      >
        <div className="max-w-6xl mx-auto px-4 py-2.5 flex items-center gap-4 overflow-x-auto">
          <div className="flex items-center gap-2 shrink-0 pr-4 border-r border-border">
            <div className="w-7 h-7 rounded-md bg-[#0066CC] flex items-center justify-center text-white text-xs">
              BS
            </div>
            <span className="text-xs text-[#002B5C] tracking-wider">
              BANKOSYSTEME
            </span>
          </div>
          {nav.map((n) => (
            <a
              key={n.id}
              href={`#${n.id}`}
              className="text-xs text-muted-foreground hover:text-[#0066CC] transition whitespace-nowrap"
            >
              {n.label}
            </a>
          ))}
        </div>
      </motion.nav>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="space-y-20 lg:space-y-28 pb-20">
          {/* ╔══════════════════════════════╗
              ║           HERO               ║
              ╚══════════════════════════════╝ */}
          <S id="hero" className="pt-8 lg:pt-14">
            <div className="relative bg-gradient-to-br from-[#002B5C] via-[#003870] to-[#001F42] text-white rounded-3xl p-8 lg:p-14 overflow-hidden">
              <div className="absolute top-0 right-0 w-80 h-80 bg-[#0066CC]/10 rounded-full blur-[80px] -translate-y-1/2 translate-x-1/4" />
              <div className="absolute bottom-0 left-0 w-60 h-60 bg-[#00A86B]/8 rounded-full blur-[60px] translate-y-1/3 -translate-x-1/4" />

              <div className="relative z-10">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-12 h-12 rounded-xl bg-[#0066CC] flex items-center justify-center text-sm tracking-wider">
                    BS
                  </div>
                  <div>
                    <span className="text-white/40 text-xs tracking-[0.25em] block">
                      CIC — DOSSIER INNOVATION
                    </span>
                    <span className="text-white/50 text-xs">
                      Confidentiel — Mars 2026
                    </span>
                  </div>
                </div>

                <h1 className="text-4xl sm:text-5xl lg:text-6xl text-white tracking-tight mb-5">
                  BANKOSYSTEME
                </h1>
                <p className="text-xl lg:text-2xl text-white/80 mb-3 max-w-xl">
                  L'ecosysteme qui transforme vos clients en communaute de
                  valeur.
                </p>
                <p className="text-white/50 max-w-lg mb-10">
                  Un portail CIC ou chaque client valorise ses talents, structure
                  son projet avec l'IA, et se connecte a des profils
                  complementaires. Plus de credits, moins de risques, plus de
                  fidelisation.
                </p>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 lg:gap-4 mb-8">
                  {[
                    { val: "+30%", lbl: "Conversion credit", sub: "dossiers solides" },
                    { val: "-25%", lbl: "Temps instruction", sub: "structure IA" },
                    { val: "x2", lbl: "Produits / client", sub: "cross-sell" },
                    { val: "90j", lbl: "MVP operationnel", sub: "time to market" },
                  ].map((s) => (
                    <div
                      key={s.lbl}
                      className="bg-white/[0.07] backdrop-blur-sm rounded-xl p-4 text-center border border-white/10"
                    >
                      <div className="text-2xl lg:text-3xl text-white">
                        {s.val}
                      </div>
                      <div className="text-xs text-white/70 mt-1">{s.lbl}</div>
                      <div className="text-xs text-white/35">{s.sub}</div>
                    </div>
                  ))}
                </div>

                <div className="flex items-center gap-2 text-xs text-white/40">
                  <Clock size={14} />
                  Temps de lecture : 5 min — avec demo interactive
                </div>
              </div>
            </div>

            <div className="flex justify-center mt-8">
              <motion.a
                href="#probleme"
                animate={{ y: [0, 6, 0] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="text-muted-foreground"
              >
                <ArrowDown size={20} />
              </motion.a>
            </div>
          </S>

          {/* ╔══════════════════════════════╗
              ║        LE PROBLÈME           ║
              ╚══════════════════════════════╝ */}
          <S id="probleme">
            <div className="text-center mb-10">
              <Badge color="#C4122F">LE PROBLEME</Badge>
              <h2 className="text-[#002B5C] mt-4 text-2xl lg:text-3xl">
                Ce que la banque perd aujourd'hui
              </h2>
            </div>

            <div className="bg-[#C4122F]/5 border border-[#C4122F]/15 rounded-2xl p-8 lg:p-10 text-center mb-10">
              <div className="text-5xl lg:text-7xl text-[#C4122F]">
                <Counter target={12} suffix="M EUR" />
              </div>
              <div className="text-[#002B5C] mt-2">
                Perte annuelle estimee — reseau CIC
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                Temps perdu + opportunites manquees + clients partis + risques
                mal evalues
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-white rounded-2xl border border-border p-6">
                <h4 className="text-sm text-[#002B5C] mb-4">
                  % conseillers impactes
                </h4>
                <div className="h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={painBars} layout="vertical">
                      <XAxis
                        type="number"
                        domain={[0, 100]}
                        tick={{ fontSize: 11 }}
                      />
                      <YAxis
                        type="category"
                        dataKey="name"
                        width={140}
                        tick={{ fontSize: 11 }}
                      />
                      <Tooltip />
                      <Bar dataKey="pct" radius={[0, 6, 6, 0]}>
                        {painBars.map((e, i) => (
                          <Cell key={i} fill={e.color} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <div className="space-y-3">
                {[
                  {
                    icon: AlertTriangle,
                    t: "68% dossiers retournes",
                    d: "3h de traitement moyen — format non standard, pieces manquantes.",
                  },
                  {
                    icon: Users,
                    t: "72% clients isoles",
                    d: "200+ synergies possibles / agence / an jamais detectees.",
                  },
                  {
                    icon: DollarSign,
                    t: "8% flux sortants evitables",
                    d: "Des clients paient dehors ce que d'autres clients CIC offrent.",
                  },
                  {
                    icon: Building2,
                    t: "60% abandons SCI",
                    d: "Parcours trop complexe, clients partent chez le concurrent.",
                  },
                ].map((p) => (
                  <div
                    key={p.t}
                    className="bg-white rounded-xl border border-border p-4 flex items-start gap-3"
                  >
                    <div className="w-8 h-8 rounded-lg bg-[#C4122F]/8 flex items-center justify-center shrink-0">
                      <p.icon size={15} className="text-[#C4122F]" />
                    </div>
                    <div>
                      <div className="text-sm text-[#002B5C]">{p.t}</div>
                      <div className="text-xs text-muted-foreground">{p.d}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </S>

          {/* ╔══════════════════════════════╗
              ║        LA SOLUTION           ║
              ╚══════════════════════════════╝ */}
          <S id="solution">
            <div className="text-center mb-10">
              <Badge color="#0066CC">LA SOLUTION</Badge>
              <h2 className="text-[#002B5C] mt-4 text-2xl lg:text-3xl">
                BANKOSYSTEME — 3 briques, 1 ecosysteme
              </h2>
              <p className="text-muted-foreground text-sm mt-2 max-w-md mx-auto">
                Du client au conseiller, du projet au financement.
              </p>
            </div>

            <div className="grid lg:grid-cols-3 gap-5 mb-10">
              {[
                {
                  icon: Brain,
                  n: "A",
                  title: "Portail d'alignement",
                  c: "#002B5C",
                  pts: [
                    "Questionnaire progressif zero charge cognitive",
                    "IA reformule, clarifie, chiffre en temps reel",
                    "Valorisation financiere des competences",
                    "Mini business plan auto-genere",
                  ],
                },
                {
                  icon: Zap,
                  n: "B",
                  title: "Matching anonyme",
                  c: "#0066CC",
                  pts: [
                    "Profils anonymes : competences + budget + timing",
                    "Groupes Duo / Trio / Squad",
                    "Score de complementarite explique",
                    "Identite revelee apres double consentement",
                  ],
                },
                {
                  icon: BarChart3,
                  n: "C",
                  title: "Cockpit banque",
                  c: "#00A86B",
                  pts: [
                    "Statistiques live du portefeuille",
                    "Carte de chaleur des opportunites",
                    "Dossiers standardises format CIC",
                    "Alertes et scoring continu",
                  ],
                },
              ].map((b) => (
                <div
                  key={b.n}
                  className="bg-white rounded-2xl border border-border p-6 relative overflow-hidden hover:shadow-lg transition-shadow"
                >
                  <div
                    className="absolute top-0 left-0 w-full h-1"
                    style={{ backgroundColor: b.c }}
                  />
                  <div className="flex items-center gap-3 mb-4 mt-2">
                    <div
                      className="w-10 h-10 rounded-xl flex items-center justify-center"
                      style={{ backgroundColor: b.c + "12" }}
                    >
                      <b.icon size={20} style={{ color: b.c }} />
                    </div>
                    <div>
                      <div className="text-xs text-muted-foreground">
                        Brique {b.n}
                      </div>
                      <h3 className="text-[#002B5C]">{b.title}</h3>
                    </div>
                  </div>
                  <ul className="space-y-2">
                    {b.pts.map((p, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <CheckCircle2
                          size={14}
                          className="shrink-0 mt-0.5"
                          style={{ color: b.c }}
                        />
                        <span className="text-xs text-muted-foreground">
                          {p}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>

            {/* 4-step flow */}
            <div className="bg-white rounded-2xl border border-border p-6 lg:p-8">
              <h3 className="text-[#002B5C] mb-6 text-center">
                Comment ca marche — 4 etapes
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-5">
                {[
                  { s: 1, icon: FileText, t: "Client s'inscrit", d: "Situation, objectif, talents — 10 min.", c: "#002B5C" },
                  { s: 2, icon: Brain, t: "IA structure", d: "Dossier standardise, options, chiffres.", c: "#0066CC" },
                  { s: 3, icon: Zap, t: "Matching opere", d: "Profils complementaires anonymes.", c: "#00A86B" },
                  { s: 4, icon: BadgeCheck, t: "Conseiller decide", d: "Dossier complet. RDV 48h. Offre.", c: "#F5A623" },
                ].map((step, i) => (
                  <div key={step.s} className="text-center relative">
                    <div
                      className="w-12 h-12 rounded-2xl mx-auto mb-3 flex items-center justify-center"
                      style={{ backgroundColor: step.c + "12" }}
                    >
                      <step.icon size={22} style={{ color: step.c }} />
                    </div>
                    <div className="w-6 h-6 rounded-full bg-[#002B5C] text-white text-xs flex items-center justify-center mx-auto mb-2">
                      {step.s}
                    </div>
                    <h4 className="text-sm text-[#002B5C]">{step.t}</h4>
                    <p className="text-xs text-muted-foreground mt-1">{step.d}</p>
                    {i < 3 && (
                      <ArrowRight
                        size={14}
                        className="text-[#002B5C]/15 absolute top-6 -right-3 hidden md:block"
                      />
                    )}
                  </div>
                ))}
              </div>
            </div>
          </S>

          {/* ╔══════════════════════════════╗
              ║     DEMO — PORTAIL CLIENT    ║
              ╚══════════════════════════════╝ */}
          <S id="demo-portail">
            <div className="text-center mb-8">
              <Badge color="#002B5C">DEMO LIVE</Badge>
              <h2 className="text-[#002B5C] mt-4 text-2xl lg:text-3xl">
                Brique A — Portail d'alignement
              </h2>
              <p className="text-muted-foreground text-sm mt-2 max-w-md mx-auto">
                Parcourez les 6 etapes du questionnaire client. Cliquez sur
                "Suivant" ou laissez la demo defiler.
              </p>
            </div>
            <DemoPortail />
          </S>

          {/* ╔══════════════════════════════╗
              ║    DEMO — MATCHING ENGINE    ║
              ╚══════════════════════════════╝ */}
          <S id="demo-matching">
            <div className="text-center mb-8">
              <Badge color="#0066CC">DEMO LIVE</Badge>
              <h2 className="text-[#002B5C] mt-4 text-2xl lg:text-3xl">
                Brique B — Matching anonyme
              </h2>
              <p className="text-muted-foreground text-sm mt-2 max-w-md mx-auto">
                Cliquez pour lancer l'algorithme de matching et voir un DUO se
                former en temps reel.
              </p>
            </div>
            <DemoMatching />
          </S>

          {/* ╔══════════════════════════════╗
              ║     DEMO — COCKPIT BANQUE    ║
              ╚══════════════════════════════╝ */}
          <S id="demo-cockpit">
            <div className="text-center mb-8">
              <Badge color="#00A86B">DEMO LIVE</Badge>
              <h2 className="text-[#002B5C] mt-4 text-2xl lg:text-3xl">
                Brique C — Cockpit banque
              </h2>
              <p className="text-muted-foreground text-sm mt-2 max-w-md mx-auto">
                Le tableau de bord en temps reel que voit le conseiller CIC.
              </p>
            </div>
            <DemoCockpit />
          </S>

          {/* ╔══════════════════════════════╗
              ║       3 CAS CONCRETS         ║
              ╚══════════════════════════════╝ */}
          <S id="cas">
            <div className="text-center mb-10">
              <Badge color="#002B5C">CAS CONCRETS</Badge>
              <h2 className="text-[#002B5C] mt-4 text-2xl lg:text-3xl">
                3 scenarios de matching — revenus reels
              </h2>
            </div>

            <div className="space-y-5">
              {[
                {
                  type: "DUO",
                  color: "#0066CC",
                  title: "Tech + Commercial → SaaS B2B",
                  profiles: [
                    "Dev web — CA 48K EUR — Budget 8K EUR — Besoin : commercial",
                    "Commercial B2B — 200+ contacts — Budget 14K EUR — Besoin : dev",
                  ],
                  synergy: "87%",
                  result: "Credit 15K EUR / 24 mois + Assurance duo + Compte pro joint",
                  revenue: "3 200 EUR",
                },
                {
                  type: "TRIO",
                  color: "#00A86B",
                  title: "3 investisseurs → SCI Lyon",
                  profiles: [
                    "Cadre — Epargne 40K EUR — Veut locatif passif",
                    "Agent immo — Apport 25K EUR — Connaissance marche",
                    "Artisan — Apport 15K EUR — Competence travaux",
                  ],
                  synergy: "92%",
                  result: "Credit SCI 140K EUR / 20 ans + Assurance groupe + Gestion",
                  revenue: "18 400 EUR",
                },
                {
                  type: "SQUAD",
                  color: "#F5A623",
                  title: "4 profils → Plateforme formation",
                  profiles: [
                    "Formatrice — CA 35K EUR — Besoin plateforme",
                    "Dev web dispo 50% — Besoin clients",
                    "Community manager dispo 60% — Besoin projets",
                    "Expert-comptable — Veut diversifier digital",
                  ],
                  synergy: "78%",
                  result: "Credit pro 30K EUR + 4 comptes pro + Pack assurance",
                  revenue: "8 700 EUR",
                },
              ].map((sc) => (
                <div
                  key={sc.title}
                  className="bg-white rounded-2xl border border-border overflow-hidden"
                >
                  <div
                    className="px-5 py-3 flex items-center justify-between"
                    style={{ backgroundColor: sc.color + "0A" }}
                  >
                    <div className="flex items-center gap-3">
                      <span
                        className="text-xs px-2 py-0.5 rounded text-white"
                        style={{ backgroundColor: sc.color }}
                      >
                        {sc.type}
                      </span>
                      <span className="text-sm text-[#002B5C]">
                        {sc.title}
                      </span>
                    </div>
                    <span className="text-xs" style={{ color: sc.color }}>
                      {sc.synergy} match
                    </span>
                  </div>
                  <div className="p-5 grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      {sc.profiles.map((p, i) => (
                        <div
                          key={i}
                          className="bg-[#F7F8FA] rounded-lg p-3 text-xs text-muted-foreground"
                        >
                          <span className="text-[#0066CC]">
                            {String.fromCharCode(65 + i)} :
                          </span>{" "}
                          {p}
                        </div>
                      ))}
                    </div>
                    <div className="flex flex-col gap-3">
                      <div className="bg-[#0066CC]/5 rounded-lg p-3 flex-1">
                        <div className="text-xs text-[#0066CC] mb-1">
                          Produits CIC vendus
                        </div>
                        <p className="text-xs text-muted-foreground">
                          {sc.result}
                        </p>
                      </div>
                      <div className="bg-[#00A86B]/8 rounded-lg p-3 text-center">
                        <div className="text-xs text-muted-foreground">
                          Revenus CIC estimes
                        </div>
                        <div className="text-lg text-[#00A86B]">
                          {sc.revenue}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </S>

          {/* ╔══════════════════════════════╗
              ║            ROI               ║
              ╚══════════════════════════════╝ */}
          <S id="roi">
            <div className="text-center mb-10">
              <Badge color="#00A86B">RETOUR SUR INVESTISSEMENT</Badge>
              <h2 className="text-[#002B5C] mt-4 text-2xl lg:text-3xl">
                Le business case en chiffres
              </h2>
            </div>

            {/* Big ROI cards */}
            <div className="bg-gradient-to-br from-[#002B5C] via-[#003870] to-[#001F42] text-white rounded-3xl p-8 lg:p-10 mb-8 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-60 h-60 bg-[#0066CC]/10 rounded-full blur-[60px]" />

              <div className="relative z-10">
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6 mb-8">
                  {[
                    { v: "950K EUR", l: "Investissement total", s: "12 mois", ac: "#fff" },
                    { v: "8 mois", l: "Break-even", s: "retour positif", ac: "#0066CC" },
                    { v: "x2.4", l: "ROI annee 1", s: "par EUR investi", ac: "#00A86B" },
                    { v: "x7.2", l: "ROI annee 3", s: "effet cumule", ac: "#F5A623" },
                  ].map((r) => (
                    <div
                      key={r.l}
                      className="bg-white/[0.07] rounded-xl p-5 text-center border border-white/10"
                    >
                      <div className="text-2xl lg:text-3xl" style={{ color: r.ac }}>
                        {r.v}
                      </div>
                      <div className="text-xs text-white/70 mt-1">{r.l}</div>
                      <div className="text-xs text-white/35">{r.s}</div>
                    </div>
                  ))}
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <div className="text-sm text-white/80 mb-3 text-center">
                      Sources de revenus additionnels
                    </div>
                    <div className="h-48">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={roiPie}
                            cx="50%"
                            cy="50%"
                            innerRadius={35}
                            outerRadius={68}
                            dataKey="value"
                            label={({ name, percent }) =>
                              `${name} ${(percent * 100).toFixed(0)}%`
                            }
                            labelLine={false}
                          >
                            {roiPie.map((e, i) => (
                              <Cell key={i} fill={e.color} />
                            ))}
                          </Pie>
                          <Tooltip />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="text-sm text-white/80 mb-3">
                      Valeur generee an 1
                    </div>
                    {[
                      { l: "Revenus additionnels", v: "2,3M EUR", s: "credits + assurances + pro" },
                      { l: "Economies operations", v: "480K EUR", s: "instruction, relances" },
                      { l: "Retention amelioree", v: "720K EUR", s: "clients conserves" },
                      { l: "VALEUR TOTALE AN 1", v: "3,5M EUR", s: "vs. 950K EUR investi" },
                    ].map((m, i) => (
                      <div
                        key={m.l}
                        className={`flex items-center justify-between p-3 rounded-lg ${
                          i === 3
                            ? "bg-[#00A86B]/20 border border-[#00A86B]/30"
                            : "bg-white/[0.06]"
                        }`}
                      >
                        <div>
                          <div className={`text-xs ${i === 3 ? "text-[#00A86B]" : "text-white/60"}`}>
                            {m.l}
                          </div>
                          <div className="text-xs text-white/35">{m.s}</div>
                        </div>
                        <div className={`text-sm ${i === 3 ? "text-[#00A86B]" : "text-white"}`}>
                          {m.v}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Revenue projection chart */}
            <div className="bg-white rounded-2xl border border-border p-6">
              <h4 className="text-[#002B5C] mb-1">
                Projection revenus sur 5 ans
              </h4>
              <p className="text-xs text-muted-foreground mb-5">
                Base 100 = revenus actuels (10 000 clients)
              </p>
              <div className="h-56">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={revenueData}>
                    <defs>
                      <linearGradient id="grA" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#0066CC" stopOpacity={0.25} />
                        <stop offset="100%" stopColor="#0066CC" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#E8EDF4" />
                    <XAxis dataKey="y" tick={{ fontSize: 12 }} />
                    <YAxis tick={{ fontSize: 12 }} />
                    <Tooltip />
                    <Area
                      type="monotone"
                      dataKey="sans"
                      name="Sans BANKOSYSTEME"
                      stroke="#CBD5E1"
                      fill="transparent"
                      strokeWidth={2}
                      strokeDasharray="6 4"
                    />
                    <Area
                      type="monotone"
                      dataKey="avec"
                      name="Avec BANKOSYSTEME"
                      stroke="#0066CC"
                      fill="url(#grA)"
                      strokeWidth={2.5}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
              <div className="flex justify-center gap-8 mt-3 text-xs">
                <span className="flex items-center gap-2 text-muted-foreground">
                  <span className="w-5 h-px bg-[#CBD5E1] border-t border-dashed border-[#CBD5E1]" /> Sans
                </span>
                <span className="flex items-center gap-2 text-[#0066CC]">
                  <span className="w-5 h-0.5 bg-[#0066CC] rounded" /> Avec
                  BANKOSYSTEME
                </span>
              </div>
            </div>

            {/* 6 impact KPIs */}
            <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 mt-6">
              {[
                { icon: TrendingUp, v: "+30%", l: "Conversion credit", c: "#0066CC" },
                { icon: Shield, v: "-20%", l: "Taux de defaut", c: "#00A86B" },
                { icon: Target, v: "x2", l: "Produits / client", c: "#0066CC" },
                { icon: Users, v: "+40%", l: "Retention client", c: "#002B5C" },
                { icon: Banknote, v: "-8%", l: "Sorties flux", c: "#00A86B" },
                { icon: Star, v: "+25%", l: "Attractivite", c: "#F5A623" },
              ].map((m) => (
                <div
                  key={m.l}
                  className="bg-white rounded-xl border border-border p-4 flex items-center gap-3"
                >
                  <div
                    className="w-9 h-9 rounded-lg flex items-center justify-center shrink-0"
                    style={{ backgroundColor: m.c + "12" }}
                  >
                    <m.icon size={16} style={{ color: m.c }} />
                  </div>
                  <div>
                    <div className="text-xl" style={{ color: m.c }}>
                      {m.v}
                    </div>
                    <div className="text-xs text-muted-foreground">{m.l}</div>
                  </div>
                </div>
              ))}
            </div>
          </S>

          {/* ╔══════════════════════════════╗
              ║          ROADMAP             ║
              ╚══════════════════════════════╝ */}
          <S id="roadmap">
            <div className="text-center mb-10">
              <Badge color="#0066CC">ROADMAP</Badge>
              <h2 className="text-[#002B5C] mt-4 text-2xl lg:text-3xl">
                Calendrier de livraison
              </h2>
            </div>

            <div className="space-y-4">
              {[
                {
                  ph: "MVP",
                  d: "90 jours",
                  cost: "350K EUR",
                  icon: Zap,
                  c: "#0066CC",
                  team: "8 pers.",
                  items: [
                    "Portail + profils + projets",
                    "IA structuration + business plan",
                    "Matching anonyme Duo",
                    "Cockpit banque basique",
                  ],
                },
                {
                  ph: "V1",
                  d: "6 mois",
                  cost: "+200K EUR",
                  icon: Rocket,
                  c: "#00A86B",
                  team: "+3 pers.",
                  items: [
                    "Dossiers format CIC standard",
                    "Scoring avance + RDV integre",
                    "Matching Trio + Squad",
                    "Dashboard direction KPIs",
                  ],
                },
                {
                  ph: "V2",
                  d: "12 mois",
                  cost: "+400K EUR",
                  icon: Star,
                  c: "#F5A623",
                  team: "+5 pers.",
                  items: [
                    "Compte collaboratif (post ACPR)",
                    "Flux internes + co-remboursement",
                    "Module SCI simplifie",
                    "API notaires, assureurs",
                  ],
                },
              ].map((p) => (
                <div
                  key={p.ph}
                  className="bg-white rounded-2xl border border-border overflow-hidden"
                >
                  <div className="flex items-stretch">
                    <div
                      className="w-1.5 shrink-0"
                      style={{ backgroundColor: p.c }}
                    />
                    <div className="flex-1 p-5">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-3">
                          <div
                            className="w-9 h-9 rounded-xl flex items-center justify-center"
                            style={{ backgroundColor: p.c + "12" }}
                          >
                            <p.icon size={18} style={{ color: p.c }} />
                          </div>
                          <div>
                            <h4 className="text-[#002B5C]">{p.ph}</h4>
                            <span className="text-xs text-muted-foreground">
                              {p.d}
                            </span>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-sm" style={{ color: p.c }}>
                            {p.cost}
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {p.team}
                          </div>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        {p.items.map((it, i) => (
                          <div key={i} className="flex items-start gap-2">
                            <CheckCircle2
                              size={13}
                              className="shrink-0 mt-0.5"
                              style={{ color: p.c }}
                            />
                            <span className="text-xs text-muted-foreground">
                              {it}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </S>

          {/* ╔══════════════════════════════╗
              ║         SECURITE             ║
              ╚══════════════════════════════╝ */}
          <S id="securite">
            <div className="text-center mb-8">
              <Badge color="#002B5C">CONFORMITE & SECURITE</Badge>
              <h2 className="text-[#002B5C] mt-4 text-2xl lg:text-3xl">
                Garde-fous integres
              </h2>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
              {[
                { code: "RGPD", d: "Protection donnees" },
                { code: "ACPR", d: "Controle prudentiel" },
                { code: "DSP2", d: "Services paiement" },
                { code: "CMF", d: "Code monetaire" },
              ].map((r) => (
                <div
                  key={r.code}
                  className="bg-white rounded-xl border border-border p-4 text-center"
                >
                  <div className="text-lg text-[#002B5C]">{r.code}</div>
                  <div className="text-xs text-muted-foreground">{r.d}</div>
                </div>
              ))}
            </div>

            <div className="grid md:grid-cols-3 gap-3">
              {[
                { icon: Eye, l: "Anonymisation par defaut", d: "Aucune identite partagee avant consentement mutuel" },
                { icon: Lock, l: "Consentement explicite", d: "Accord trace et revocable a chaque etape" },
                { icon: Shield, l: "Chiffrement AES-256", d: "Bases separees, acces par role strict" },
                { icon: Brain, l: "IA transparente", d: "Criteres de matching expliques, biais controles" },
                { icon: FileText, l: "Audit trail complet", d: "Chaque action horodatee et attribuee" },
                { icon: AlertTriangle, l: "Anti-fraude temps reel", d: "Monitoring continu, alertes automatiques" },
              ].map((g) => (
                <div
                  key={g.l}
                  className="bg-white rounded-xl border border-border p-4 flex items-start gap-3"
                >
                  <div className="w-8 h-8 rounded-lg bg-[#002B5C]/6 flex items-center justify-center shrink-0">
                    <g.icon size={14} className="text-[#002B5C]" />
                  </div>
                  <div>
                    <div className="text-sm text-[#002B5C]">{g.l}</div>
                    <div className="text-xs text-muted-foreground">{g.d}</div>
                  </div>
                </div>
              ))}
            </div>
          </S>

          {/* ╔══════════════════════════════╗
              ║      FAQ BANQUIER            ║
              ╚══════════════════════════════╝ */}
          <S id="faq">
            <div className="text-center mb-8">
              <Badge color="#F5A623">FAQ BANQUIER</Badge>
              <h2 className="text-[#002B5C] mt-4 text-2xl lg:text-3xl">
                Objections & reponses
              </h2>
            </div>

            <div className="space-y-2">
              {[
                {
                  q: "Les clients vont-ils vraiment utiliser ca ?",
                  a: "67% des independants cherchent des partenaires. Le cadre bancaire (confiance, securite, financement) est un avantage decisif. Le MVP valide l'adoption sous 90 jours.",
                },
                {
                  q: "Quel risque juridique pour le matching ?",
                  a: "Matching anonyme, criteres objectifs, pas de conseil en investissement au sens MIF2. Cadrage ACPR prevu en phase 1. V1 sans engagement financier automatique.",
                },
                {
                  q: "Comment gerer le risque de defaut ?",
                  a: "Scoring individuel CIC + scoring groupe. Risque reparti et inferieur au credit solo. Plafonds, consentements, clause de solidarite optionnelle.",
                },
                {
                  q: "C'est pas du crowdfunding deguise ?",
                  a: "Non. Pas de collecte publique. Les financements restent des credits CIC classiques, eventuellement repartis entre co-emprunteurs identifies et evalues.",
                },
                {
                  q: "Et la RGPD ?",
                  a: "Zero donnee personnelle partagee. Profils anonymises. Double consentement. Chiffrement AES-256. DPO dedie. PIA avant lancement.",
                },
              ].map((f, i) => (
                <div
                  key={i}
                  className="bg-white rounded-xl border border-border overflow-hidden"
                >
                  <button
                    onClick={() => setFaqOpen(faqOpen === i ? null : i)}
                    className="w-full flex items-center gap-3 p-4 text-left"
                  >
                    <span className="flex-1 text-sm text-[#002B5C]">
                      {f.q}
                    </span>
                    {faqOpen === i ? (
                      <ChevronUp size={16} className="text-muted-foreground shrink-0" />
                    ) : (
                      <ChevronDown size={16} className="text-muted-foreground shrink-0" />
                    )}
                  </button>
                  {faqOpen === i && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      className="px-4 pb-4"
                    >
                      <div className="text-xs text-muted-foreground border-l-2 border-[#0066CC]/20 pl-3">
                        {f.a}
                      </div>
                    </motion.div>
                  )}
                </div>
              ))}
            </div>
          </S>

          {/* ╔══════════════════════════════╗
              ║         CTA FINAL            ║
              ╚══════════════════════════════╝ */}
          <S>
            <div className="bg-gradient-to-br from-[#002B5C] via-[#003870] to-[#001F42] text-white rounded-3xl p-8 lg:p-12 text-center relative overflow-hidden">
              <div className="absolute top-0 right-0 w-72 h-72 bg-[#0066CC]/10 rounded-full blur-[80px] -translate-y-1/2 translate-x-1/3" />
              <div className="absolute bottom-0 left-0 w-48 h-48 bg-[#00A86B]/8 rounded-full blur-[60px] translate-y-1/3" />

              <div className="relative z-10">
                <h2 className="text-white text-2xl lg:text-3xl mb-4">
                  Prochaines etapes
                </h2>
                <p className="text-white/50 max-w-md mx-auto mb-8 text-sm">
                  5 actions concretes pour lancer BANKOSYSTEME
                </p>

                <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-10 max-w-3xl mx-auto">
                  {[
                    { s: "1", l: "Validation comite", d: "2 sem." },
                    { s: "2", l: "Cadrage ACPR", d: "4 sem." },
                    { s: "3", l: "Recrutement", d: "3 sem." },
                    { s: "4", l: "Sprint 0", d: "2 sem." },
                    { s: "5", l: "Lancement MVP", d: "12 sem." },
                  ].map((step) => (
                    <div
                      key={step.s}
                      className="bg-white/[0.07] rounded-xl p-4 border border-white/10"
                    >
                      <div className="w-7 h-7 rounded-full bg-[#0066CC] flex items-center justify-center text-xs mx-auto mb-2">
                        {step.s}
                      </div>
                      <div className="text-xs text-white">{step.l}</div>
                      <div className="text-xs text-white/35 mt-0.5">
                        {step.d}
                      </div>
                    </div>
                  ))}
                </div>

                <div className="bg-white/[0.08] rounded-2xl p-6 max-w-lg mx-auto mb-8 border border-white/10">
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <div className="text-2xl text-white">950K EUR</div>
                      <div className="text-xs text-white/40">Investissement</div>
                    </div>
                    <div>
                      <div className="text-2xl text-[#00A86B]">3,5M EUR</div>
                      <div className="text-xs text-white/40">Valeur an 1</div>
                    </div>
                    <div>
                      <div className="text-2xl text-[#F5A623]">x7.2</div>
                      <div className="text-xs text-white/40">ROI an 3</div>
                    </div>
                  </div>
                </div>

                <p className="text-xs text-white/25 mt-10">
                  Document confidentiel — CIC Direction Innovation — Mars 2026
                  <br />
                  BANKOSYSTEME — Le reseau d'alignement et de collaboration des
                  clients CIC
                </p>
              </div>
            </div>
          </S>
        </div>
      </div>
    </div>
  );
}
