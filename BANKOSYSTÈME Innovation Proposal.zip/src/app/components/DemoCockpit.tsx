import { useState, useEffect } from "react";
import { motion } from "motion/react";
import {
  BarChart3,
  TrendingUp,
  Users,
  FileText,
  AlertCircle,
  Bell,
  ArrowUpRight,
  Activity,
} from "lucide-react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";

const activityData = [
  { m: "Jan", projets: 42, dossiers: 18 },
  { m: "Fev", projets: 58, dossiers: 28 },
  { m: "Mar", projets: 75, dossiers: 42 },
  { m: "Avr", projets: 98, dossiers: 61 },
  { m: "Mai", projets: 124, dossiers: 85 },
  { m: "Juin", projets: 156, dossiers: 112 },
];

const sectorPie = [
  { name: "Services", value: 35, color: "#002B5C" },
  { name: "Immobilier", value: 25, color: "#0066CC" },
  { name: "Tech", value: 22, color: "#00A86B" },
  { name: "Commerce", value: 18, color: "#F5A623" },
];

const alerts = [
  {
    type: "opportunity",
    msg: "3 nouveaux groupes DUO prets — secteur Tech",
    time: "Il y a 12 min",
  },
  {
    type: "dossier",
    msg: "Dossier SCI Lyon 7e complet — en attente validation",
    time: "Il y a 34 min",
  },
  {
    type: "alert",
    msg: "Scoring a revalider — Groupe #47 (budget ajuste)",
    time: "Il y a 1h",
  },
];

export function DemoCockpit() {
  const [animatedStats, setAnimatedStats] = useState({
    projets: 0,
    groupes: 0,
    dossiers: 0,
    completude: 0,
  });

  useEffect(() => {
    const targets = { projets: 1247, groupes: 89, dossiers: 342, completude: 78 };
    const duration = 1500;
    const steps = 40;
    const interval = duration / steps;
    let step = 0;

    const timer = setInterval(() => {
      step++;
      const progress = Math.min(step / steps, 1);
      const ease = 1 - Math.pow(1 - progress, 3);
      setAnimatedStats({
        projets: Math.round(targets.projets * ease),
        groupes: Math.round(targets.groupes * ease),
        dossiers: Math.round(targets.dossiers * ease),
        completude: Math.round(targets.completude * ease),
      });
      if (step >= steps) clearInterval(timer);
    }, interval);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="bg-white rounded-2xl border border-border shadow-lg overflow-hidden">
      {/* Header bar */}
      <div className="bg-[#002B5C] px-5 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-[#C4122F]" />
          <div className="w-3 h-3 rounded-full bg-[#F5A623]" />
          <div className="w-3 h-3 rounded-full bg-[#00A86B]" />
        </div>
        <span className="text-xs text-white/60">
          bankosysteme.cic.fr/cockpit-banque
        </span>
        <div className="flex items-center gap-2">
          <div className="relative">
            <Bell size={14} className="text-white/60" />
            <div className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-[#C4122F]" />
          </div>
        </div>
      </div>

      <div className="p-5 lg:p-6">
        {/* Stats row */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
          {[
            {
              label: "Projets actifs",
              value: animatedStats.projets.toLocaleString(),
              trend: "+12%",
              icon: Activity,
              color: "#002B5C",
            },
            {
              label: "Groupes formes",
              value: animatedStats.groupes.toString(),
              trend: "+23%",
              icon: Users,
              color: "#0066CC",
            },
            {
              label: "Dossiers generes",
              value: animatedStats.dossiers.toString(),
              trend: "+18%",
              icon: FileText,
              color: "#00A86B",
            },
            {
              label: "Completude moy.",
              value: animatedStats.completude + "%",
              trend: "+5pt",
              icon: BarChart3,
              color: "#F5A623",
            },
          ].map((s) => (
            <div
              key={s.label}
              className="bg-[#F7F8FA] rounded-xl p-3.5 border border-border/50"
            >
              <div className="flex items-center justify-between mb-2">
                <s.icon size={14} style={{ color: s.color }} />
                <span className="text-xs text-[#00A86B] flex items-center gap-0.5">
                  <ArrowUpRight size={10} />
                  {s.trend}
                </span>
              </div>
              <div className="text-xl text-[#002B5C]">{s.value}</div>
              <div className="text-xs text-muted-foreground">{s.label}</div>
            </div>
          ))}
        </div>

        <div className="grid md:grid-cols-5 gap-4 mb-5">
          {/* Chart */}
          <div className="md:col-span-3 bg-[#F7F8FA] rounded-xl p-4 border border-border/50">
            <div className="text-xs text-[#002B5C] mb-3">
              Activite mensuelle
            </div>
            <div className="h-40">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={activityData}>
                  <defs>
                    <linearGradient id="gP" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#0066CC" stopOpacity={0.2} />
                      <stop offset="100%" stopColor="#0066CC" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="gD" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#00A86B" stopOpacity={0.2} />
                      <stop offset="100%" stopColor="#00A86B" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="m" tick={{ fontSize: 10 }} />
                  <YAxis tick={{ fontSize: 10 }} />
                  <Tooltip />
                  <Area
                    type="monotone"
                    dataKey="projets"
                    name="Projets"
                    stroke="#0066CC"
                    fill="url(#gP)"
                    strokeWidth={2}
                  />
                  <Area
                    type="monotone"
                    dataKey="dossiers"
                    name="Dossiers"
                    stroke="#00A86B"
                    fill="url(#gD)"
                    strokeWidth={2}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Sector pie */}
          <div className="md:col-span-2 bg-[#F7F8FA] rounded-xl p-4 border border-border/50">
            <div className="text-xs text-[#002B5C] mb-2">Secteurs</div>
            <div className="h-32">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={sectorPie}
                    cx="50%"
                    cy="50%"
                    innerRadius={25}
                    outerRadius={48}
                    dataKey="value"
                  >
                    {sectorPie.map((e, i) => (
                      <Cell key={i} fill={e.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="grid grid-cols-2 gap-1 mt-1">
              {sectorPie.map((s) => (
                <div key={s.name} className="flex items-center gap-1 text-xs text-muted-foreground">
                  <span
                    className="w-2 h-2 rounded-full shrink-0"
                    style={{ backgroundColor: s.color }}
                  />
                  {s.name} {s.value}%
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Alerts */}
        <div className="space-y-2">
          <div className="text-xs text-[#002B5C] mb-1">
            Alertes & opportunites
          </div>
          {alerts.map((a, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.5 + i * 0.2 }}
              className={`flex items-start gap-3 p-3 rounded-lg border ${
                a.type === "opportunity"
                  ? "bg-[#00A86B]/5 border-[#00A86B]/15"
                  : a.type === "dossier"
                  ? "bg-[#0066CC]/5 border-[#0066CC]/15"
                  : "bg-[#F5A623]/5 border-[#F5A623]/15"
              }`}
            >
              {a.type === "opportunity" ? (
                <TrendingUp size={14} className="text-[#00A86B] mt-0.5 shrink-0" />
              ) : a.type === "dossier" ? (
                <FileText size={14} className="text-[#0066CC] mt-0.5 shrink-0" />
              ) : (
                <AlertCircle size={14} className="text-[#F5A623] mt-0.5 shrink-0" />
              )}
              <div className="flex-1">
                <div className="text-xs text-[#002B5C]">{a.msg}</div>
                <div className="text-xs text-muted-foreground mt-0.5">
                  {a.time}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
