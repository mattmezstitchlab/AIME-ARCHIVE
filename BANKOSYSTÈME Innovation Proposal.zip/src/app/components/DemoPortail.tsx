import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  User,
  Target,
  AlertCircle,
  Sparkles,
  DollarSign,
  Brain,
  CheckCircle2,
  ChevronRight,
  Loader2,
} from "lucide-react";

const steps = [
  {
    id: 0,
    icon: User,
    label: "Situation actuelle",
    color: "#002B5C",
    fields: [
      { label: "Statut", value: "Freelance — Developpeur web" },
      { label: "Revenus mensuels", value: "3 800 EUR nets" },
      { label: "Charges fixes", value: "1 420 EUR / mois" },
      { label: "Epargne disponible", value: "12 000 EUR" },
    ],
  },
  {
    id: 1,
    icon: Target,
    label: "Objectif",
    color: "#0066CC",
    fields: [
      { label: "Projet", value: "Lancer un SaaS de gestion pour PME" },
      { label: "Horizon", value: "6 mois" },
      { label: "Budget necessaire", value: "25 000 EUR" },
      { label: "CA vise an 1", value: "72 000 EUR" },
    ],
  },
  {
    id: 2,
    icon: AlertCircle,
    label: "Besoins & freins",
    color: "#C4122F",
    fields: [
      { label: "Besoin 1", value: "Un associe commercial (prospection B2B)" },
      { label: "Besoin 2", value: "Financement initial de 15 000 EUR" },
      { label: "Frein", value: "Pas de reseau commercial structure" },
      { label: "Manque", value: "Expertise marketing digital" },
    ],
  },
  {
    id: 3,
    icon: Sparkles,
    label: "Talents & services",
    color: "#00A86B",
    fields: [
      { label: "Competence cle", value: "React / Node.js / Design UI" },
      { label: "Experience", value: "5 ans, 12 projets livres" },
      { label: "Disponibilite", value: "80% — 4 jours / semaine" },
      { label: "Ce que je peux offrir", value: "Dev web, prototype rapide, UX" },
    ],
  },
  {
    id: 4,
    icon: DollarSign,
    label: "Valorisation",
    color: "#F5A623",
    fields: [
      { label: "Tarif jour", value: "450 EUR HT" },
      { label: "Capacite mensuelle", value: "16 jours facturables" },
      { label: "Valeur mensuelle", value: "7 200 EUR potentiel" },
      { label: "Valeur apportee au projet", value: "36 000 EUR (dev inclus)" },
    ],
  },
  {
    id: 5,
    icon: Brain,
    label: "IA — Dossier genere",
    color: "#0066CC",
    fields: [],
  },
];

export function DemoPortail() {
  const [activeStep, setActiveStep] = useState(0);
  const [isTyping, setIsTyping] = useState(false);
  const [autoPlay, setAutoPlay] = useState(false);

  useEffect(() => {
    if (!autoPlay) return;
    const timer = setInterval(() => {
      setActiveStep((prev) => {
        if (prev >= 5) {
          setAutoPlay(false);
          return 5;
        }
        return prev + 1;
      });
    }, 2200);
    return () => clearInterval(timer);
  }, [autoPlay]);

  const handleStart = () => {
    setActiveStep(0);
    setAutoPlay(true);
  };

  const current = steps[activeStep];

  return (
    <div className="bg-white rounded-2xl border border-border shadow-lg overflow-hidden">
      {/* Header bar */}
      <div className="bg-[#002B5C] px-5 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-[#C4122F]" />
          <div className="w-3 h-3 rounded-full bg-[#F5A623]" />
          <div className="w-3 h-3 rounded-full bg-[#00A86B]" />
        </div>
        <span className="text-xs text-white/60">
          bankosysteme.cic.fr/portail
        </span>
        <div className="w-16" />
      </div>

      <div className="p-5 lg:p-6">
        {/* Step indicators */}
        <div className="flex items-center gap-1 mb-6 overflow-x-auto pb-2">
          {steps.map((s, i) => (
            <button
              key={s.id}
              onClick={() => { setAutoPlay(false); setActiveStep(i); }}
              className="flex items-center gap-1.5 shrink-0"
            >
              <div
                className={`w-7 h-7 rounded-full flex items-center justify-center text-xs transition-all ${
                  i < activeStep
                    ? "bg-[#00A86B] text-white"
                    : i === activeStep
                    ? "text-white"
                    : "bg-gray-100 text-gray-400"
                }`}
                style={
                  i === activeStep
                    ? { backgroundColor: s.color }
                    : undefined
                }
              >
                {i < activeStep ? (
                  <CheckCircle2 size={14} />
                ) : (
                  i + 1
                )}
              </div>
              <span
                className={`text-xs hidden md:block ${
                  i === activeStep ? "text-[#002B5C]" : "text-gray-400"
                }`}
              >
                {s.label}
              </span>
              {i < steps.length - 1 && (
                <ChevronRight size={12} className="text-gray-300 mx-1" />
              )}
            </button>
          ))}
        </div>

        {/* Content */}
        <AnimatePresence mode="wait">
          <motion.div
            key={activeStep}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
          >
            {activeStep < 5 ? (
              <div>
                <div className="flex items-center gap-3 mb-4">
                  <div
                    className="w-9 h-9 rounded-xl flex items-center justify-center"
                    style={{ backgroundColor: current.color + "15" }}
                  >
                    <current.icon
                      size={18}
                      style={{ color: current.color }}
                    />
                  </div>
                  <div>
                    <h4 className="text-[#002B5C]">
                      Etape {activeStep + 1} — {current.label}
                    </h4>
                    <p className="text-xs text-muted-foreground">
                      Remplissage assiste par IA
                    </p>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {current.fields.map((f, i) => (
                    <motion.div
                      key={f.label}
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.12 }}
                      className="bg-[#F7F8FA] rounded-lg p-3 border border-border/50"
                    >
                      <div className="text-xs text-muted-foreground mb-1">
                        {f.label}
                      </div>
                      <div className="text-sm text-[#002B5C]">{f.value}</div>
                    </motion.div>
                  ))}
                </div>
              </div>
            ) : (
              /* AI Generated summary */
              <div>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-9 h-9 rounded-xl bg-[#0066CC]/15 flex items-center justify-center">
                    <Brain size={18} className="text-[#0066CC]" />
                  </div>
                  <div>
                    <h4 className="text-[#002B5C]">
                      Dossier genere par l'IA
                    </h4>
                    <p className="text-xs text-muted-foreground">
                      Format standard CIC — pret pour le conseiller
                    </p>
                  </div>
                </div>
                <div className="bg-gradient-to-br from-[#002B5C] to-[#003D7A] text-white rounded-xl p-5 space-y-3">
                  {[
                    {
                      title: "Pitch",
                      text: "Creation d'un SaaS B2B de gestion formation par un duo tech/commercial. Marche : PME 10-50 salaries.",
                    },
                    {
                      title: "Budget",
                      text: "Total 25K EUR — Apport 10K EUR — Financement demande : 15K EUR sur 24 mois.",
                    },
                    {
                      title: "Planning",
                      text: "M1-M3 dev + M4-M6 lancement + M7-M12 croissance. Break-even : M8.",
                    },
                    {
                      title: "Risques",
                      text: "Adoption lente (mitigation : 5 prospects pre-signes). Score risque : 3.1/5.",
                    },
                    {
                      title: "KPIs",
                      text: "15 clients M6, MRR 3 000 EUR, churn <5%, NPS >40.",
                    },
                  ].map((item, i) => (
                    <motion.div
                      key={item.title}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.15 + i * 0.1 }}
                      className="flex gap-3"
                    >
                      <span className="text-xs text-[#0066CC] w-16 shrink-0">
                        {item.title}
                      </span>
                      <span className="text-xs text-white/80">
                        {item.text}
                      </span>
                    </motion.div>
                  ))}
                  <div className="flex items-center gap-2 pt-2 border-t border-white/15">
                    <CheckCircle2 size={14} className="text-[#00A86B]" />
                    <span className="text-xs text-[#00A86B]">
                      Dossier complet — pret a envoyer au conseiller
                    </span>
                  </div>
                </div>
              </div>
            )}
          </motion.div>
        </AnimatePresence>

        {/* Controls */}
        <div className="flex items-center justify-between mt-5 pt-4 border-t border-border">
          <button
            onClick={() => { setAutoPlay(false); setActiveStep(Math.max(0, activeStep - 1)); }}
            className="text-xs text-muted-foreground hover:text-[#002B5C] transition"
            disabled={activeStep === 0}
          >
            ← Retour
          </button>
          {activeStep < 5 ? (
            <button
              onClick={() => { setAutoPlay(false); setActiveStep(activeStep + 1); }}
              className="text-xs bg-[#0066CC] text-white px-4 py-2 rounded-lg hover:bg-[#0055AA] transition flex items-center gap-2"
            >
              Suivant <ChevronRight size={14} />
            </button>
          ) : (
            <button
              onClick={handleStart}
              className="text-xs bg-[#00A86B] text-white px-4 py-2 rounded-lg hover:bg-[#009060] transition"
            >
              Relancer la demo
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
