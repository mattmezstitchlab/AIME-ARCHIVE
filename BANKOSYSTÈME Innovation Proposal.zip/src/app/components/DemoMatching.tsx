import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Zap,
  EyeOff,
  CheckCircle2,
  Users,
  Code,
  Megaphone,
  Briefcase,
  Palette,
} from "lucide-react";
import {
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  Radar,
  ResponsiveContainer,
  Tooltip,
} from "recharts";

const radarData = [
  { axis: "Tech", A: 92, B: 25 },
  { axis: "Commercial", A: 20, B: 88 },
  { axis: "Budget", A: 35, B: 65 },
  { axis: "Reseau", A: 30, B: 85 },
  { axis: "Timing", A: 80, B: 75 },
  { axis: "Valeurs", A: 82, B: 78 },
];

const matchPhases = [
  "Analyse des profils...",
  "Calcul de complementarite...",
  "Verification timing & budget...",
  "Score de synergie : 87%",
];

export function DemoMatching() {
  const [phase, setPhase] = useState(-1);
  const [revealed, setRevealed] = useState(false);

  const startDemo = () => {
    setPhase(0);
    setRevealed(false);
  };

  useEffect(() => {
    if (phase < 0 || phase >= matchPhases.length) return;
    const timer = setTimeout(() => {
      if (phase < matchPhases.length - 1) {
        setPhase(phase + 1);
      } else {
        setTimeout(() => setRevealed(true), 600);
      }
    }, 900);
    return () => clearTimeout(timer);
  }, [phase]);

  return (
    <div className="bg-white rounded-2xl border border-border shadow-lg overflow-hidden">
      {/* Header bar */}
      <div className="bg-[#002B5C] px-5 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-[#C4122F]" />
          <div className="w-3 h-3 rounded-full bg-[#F5A623]" />
          <div className="w-3 h-3 rounded-full bg-[#00A86B]" />
        </div>
        <span className="text-xs text-white/60">
          bankosysteme.cic.fr/matching
        </span>
        <div className="w-16" />
      </div>

      <div className="p-5 lg:p-6">
        {phase < 0 ? (
          /* Initial state */
          <div className="text-center py-8">
            <div className="w-16 h-16 rounded-2xl bg-[#0066CC]/10 flex items-center justify-center mx-auto mb-4">
              <Zap size={28} className="text-[#0066CC]" />
            </div>
            <h4 className="text-[#002B5C] mb-2">Moteur de matching</h4>
            <p className="text-xs text-muted-foreground max-w-sm mx-auto mb-6">
              L'algorithme analyse les profils anonymes et detecte les
              complementarites. Aucune identite revelee.
            </p>
            <button
              onClick={startDemo}
              className="text-sm bg-[#0066CC] text-white px-6 py-2.5 rounded-xl hover:bg-[#0055AA] transition"
            >
              Lancer le matching
            </button>
          </div>
        ) : !revealed ? (
          /* Processing */
          <div className="py-8">
            <div className="flex items-center justify-center gap-8 mb-8">
              {/* Profile A */}
              <motion.div
                initial={{ x: -40, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                className="bg-[#002B5C]/5 rounded-xl p-4 w-36 text-center"
              >
                <div className="w-12 h-12 rounded-full bg-[#002B5C] mx-auto mb-2 flex items-center justify-center">
                  <EyeOff size={18} className="text-white" />
                </div>
                <div className="text-xs text-[#002B5C]">Profil A</div>
                <div className="text-xs text-muted-foreground">Anonyme</div>
              </motion.div>

              {/* Pulse */}
              <motion.div
                animate={{ scale: [1, 1.3, 1], opacity: [0.5, 1, 0.5] }}
                transition={{ duration: 1, repeat: Infinity }}
                className="w-10 h-10 rounded-full bg-[#0066CC] flex items-center justify-center"
              >
                <Zap size={18} className="text-white" />
              </motion.div>

              {/* Profile B */}
              <motion.div
                initial={{ x: 40, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                className="bg-[#0066CC]/5 rounded-xl p-4 w-36 text-center"
              >
                <div className="w-12 h-12 rounded-full bg-[#0066CC] mx-auto mb-2 flex items-center justify-center">
                  <EyeOff size={18} className="text-white" />
                </div>
                <div className="text-xs text-[#0066CC]">Profil B</div>
                <div className="text-xs text-muted-foreground">Anonyme</div>
              </motion.div>
            </div>

            {/* Progress */}
            <div className="max-w-xs mx-auto space-y-2">
              {matchPhases.map((msg, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -10 }}
                  animate={i <= phase ? { opacity: 1, x: 0 } : {}}
                  transition={{ duration: 0.3 }}
                  className={`flex items-center gap-2 text-xs ${
                    i <= phase ? "text-[#002B5C]" : "text-gray-300"
                  }`}
                >
                  {i < phase ? (
                    <CheckCircle2 size={14} className="text-[#00A86B]" />
                  ) : i === phase ? (
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                    >
                      <Zap size={14} className="text-[#0066CC]" />
                    </motion.div>
                  ) : (
                    <div className="w-3.5 h-3.5 rounded-full border border-gray-200" />
                  )}
                  {msg}
                </motion.div>
              ))}
            </div>
          </div>
        ) : (
          /* Result */
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
          >
            {/* Match badge */}
            <div className="text-center mb-5">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", stiffness: 200, delay: 0.1 }}
                className="inline-flex items-center gap-2 bg-[#00A86B]/10 text-[#00A86B] px-4 py-2 rounded-full text-sm"
              >
                <CheckCircle2 size={16} />
                DUO detecte — Complementarite 87%
              </motion.div>
            </div>

            <div className="grid md:grid-cols-2 gap-4 mb-4">
              {/* Profiles */}
              <div className="space-y-3">
                <div className="bg-[#002B5C]/5 rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Code size={14} className="text-[#002B5C]" />
                    <span className="text-xs text-[#002B5C]">
                      Profil A — Technique
                    </span>
                  </div>
                  <ul className="space-y-1 text-xs text-muted-foreground">
                    <li>• Dev web fullstack (React/Node)</li>
                    <li>• Budget dispo : 8 000 EUR</li>
                    <li>• Dispo : 80% — 4j/sem</li>
                    <li>• Besoin : Commercial / Reseau</li>
                  </ul>
                </div>
                <div className="bg-[#0066CC]/5 rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Megaphone size={14} className="text-[#0066CC]" />
                    <span className="text-xs text-[#0066CC]">
                      Profil B — Commercial
                    </span>
                  </div>
                  <ul className="space-y-1 text-xs text-muted-foreground">
                    <li>• Commercial B2B — 200+ contacts PME</li>
                    <li>• Budget dispo : 14 000 EUR</li>
                    <li>• Taux closing : 32%</li>
                    <li>• Besoin : Dev pour plateforme</li>
                  </ul>
                </div>
                <div className="bg-[#00A86B]/8 rounded-lg p-3">
                  <div className="text-xs text-[#00A86B] mb-1">
                    Pourquoi ca match
                  </div>
                  <ul className="space-y-0.5 text-xs text-muted-foreground">
                    <li>• Competences 100% complementaires</li>
                    <li>• Budget combine : 22K EUR (suffisant)</li>
                    <li>• Timing aligne (dispo sous 30j)</li>
                    <li>• Valeurs communes : innovation, autonomie</li>
                  </ul>
                </div>
              </div>

              {/* Radar */}
              <div>
                <div className="text-xs text-[#002B5C] mb-2 text-center">
                  Carte de complementarite
                </div>
                <div className="h-52">
                  <ResponsiveContainer width="100%" height="100%">
                    <RadarChart data={radarData}>
                      <PolarGrid stroke="#E8EDF4" />
                      <PolarAngleAxis
                        dataKey="axis"
                        tick={{ fontSize: 10 }}
                      />
                      <Radar
                        name="Profil A"
                        dataKey="A"
                        stroke="#002B5C"
                        fill="#002B5C"
                        fillOpacity={0.15}
                      />
                      <Radar
                        name="Profil B"
                        dataKey="B"
                        stroke="#0066CC"
                        fill="#0066CC"
                        fillOpacity={0.15}
                      />
                      <Tooltip />
                    </RadarChart>
                  </ResponsiveContainer>
                </div>
                <div className="flex justify-center gap-4 text-xs">
                  <span className="flex items-center gap-1">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#002B5C]" />
                    Profil A
                  </span>
                  <span className="flex items-center gap-1">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#0066CC]" />
                    Profil B
                  </span>
                </div>
              </div>
            </div>

            <div className="flex justify-center pt-2">
              <button
                onClick={startDemo}
                className="text-xs text-[#0066CC] hover:underline"
              >
                Relancer la demo
              </button>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}
