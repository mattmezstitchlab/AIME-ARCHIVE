
  # BANKOSYSTÈME Innovation Proposal

  This is a code bundle for BANKOSYSTÈME Innovation Proposal. The original project is available at https://www.figma.com/design/l7poASzMYEZfDBKQNYXabd/BANKOSYST%C3%88ME-Innovation-Proposal.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  