import { useCallback, useEffect, useRef, useState } from 'react'
import type { GesteT, RoleT, Terrain } from '@/data/terrains'

const teinteT = (r: RoleT | undefined, jour: boolean) =>
  r ? (jour ? r.cJour : r.c) : 'var(--ink-3)'

function OndeTerrain({
  terrain,
  geste,
  jour,
  pareFeu,
}: {
  terrain: Terrain
  geste: GesteT
  jour: boolean
  pareFeu: boolean
}) {
  const par = (id: string) => terrain.roles.find((r) => r.id === id)
  const arcs = geste.ondes
  const PAS = 46
  const H = arcs.length * PAS + 16
  const W = 640
  const xs = 30
  const xm = 232
  const xd = 452
  const ys = H / 2
  const src = par(geste.roleId)
  const cSrc = teinteT(src, jour)

  return (
    <svg
      viewBox={`0 0 ${W} ${H}`}
      width="100%"
      height={H}
      role="img"
      aria-label={`${src?.court ?? geste.roleId} déplace ${arcs.length} rôles`}
      style={{ overflow: 'visible' }}
    >
      <defs>
        <linearGradient id={`fil-t-${terrain.id}`} x1="0" x2="1">
          <stop offset="0%" stopColor={cSrc} stopOpacity="0.85" />
          <stop offset="100%" stopColor={cSrc} stopOpacity="0.16" />
        </linearGradient>
      </defs>

      <circle cx={xs} cy={ys} r="7" fill={cSrc} />
      <circle cx={xs} cy={ys} r="13" fill="none" stroke={cSrc} strokeOpacity=".28" />
      <text x={xs} y={ys + 30} textAnchor="middle" fontSize="10.5" fill="var(--ink-3)">
        {src?.court ?? geste.roleId}
      </text>

      {arcs.map((o, i) => {
        const y = 20 + i * PAS
        const cible = par(o.r)
        const c = teinteT(cible, jour)
        const masquee = o.lock && !pareFeu
        return (
          <g key={o.r + i}>
            <path
              d={`M${xs + 12} ${ys} C ${xs + 100} ${ys}, ${xm - 110} ${y}, ${xm - 12} ${y}`}
              fill="none"
              stroke={`url(#fil-t-${terrain.id})`}
              strokeWidth="1.4"
              strokeDasharray={masquee ? '3 4' : undefined}
              opacity={masquee ? 0.5 : 1}
            />
            <circle cx={xm} cy={y} r="5" fill={c} opacity={masquee ? 0.42 : 1} />
            <text x={xm + 13} y={y + 3.5} fontSize="11.5" fill="var(--ink-2)" opacity={masquee ? 0.55 : 1}>
              {cible?.court ?? o.r}
              {o.lock ? (pareFeu ? ' · levé' : ' · scellé') : ''}
            </text>
            {(o.puis ?? []).map((p, j) => {
              const yy = y + (j - ((o.puis?.length ?? 1) - 1) / 2) * 20
              const sc = teinteT(par(p.r), jour)
              return (
                <g key={p.r + j}>
                  <path
                    d={`M${xm + 8} ${y} C ${xm + 90} ${y}, ${xd - 90} ${yy}, ${xd - 8} ${yy}`}
                    fill="none"
                    stroke={sc}
                    strokeOpacity=".34"
                    strokeWidth="1.1"
                  />
                  <circle cx={xd} cy={yy} r="3.6" fill={sc} opacity=".85" />
                  <text x={xd + 10} y={yy + 3.4} fontSize="10.5" fill="var(--ink-3)">
                    {par(p.r)?.court ?? p.r}
                  </text>
                </g>
              )
            })}
          </g>
        )
      })}
    </svg>
  )
}

export function ClavierTerrain({
  terrain,
  jour,
  pareFeu,
}: {
  terrain: Terrain
  jour: boolean
  pareFeu: boolean
}) {
  const [actif, setActif] = useState<string>(terrain.gestes[0]?.k ?? '')
  const [echos, setEchos] = useState<Record<string, number>>({})
  const [journal, setJournal] = useState<Array<{ id: number; h: string; t: string }>>([])
  const minuteurs = useRef<Array<ReturnType<typeof setTimeout>>>([])
  const compteur = useRef(0)

  useEffect(() => {
    setActif(terrain.gestes[0]?.k ?? '')
    setEchos({})
    setJournal([])
  }, [terrain.id])

  useEffect(
    () => () => {
      minuteurs.current.forEach(clearTimeout)
    },
    [],
  )

  const propager = useCallback((g: GesteT) => {
    minuteurs.current.forEach(clearTimeout)
    minuteurs.current = []
    setEchos({ [g.roleId]: 1 })
    g.ondes.forEach((o, i) => {
      minuteurs.current.push(
        setTimeout(() => setEchos((e) => ({ ...e, [o.r]: 1 })), 90 + i * 110),
      )
      ;(o.puis ?? []).forEach((p, j) => {
        minuteurs.current.push(
          setTimeout(() => setEchos((e) => ({ ...e, [p.r]: e[p.r] === 1 ? 1 : 2 })), 300 + i * 110 + j * 90),
        )
      })
    })
    minuteurs.current.push(
      setTimeout(() => setEchos({}), 400 + g.ondes.length * 110 + 700),
    )
  }, [])

  const presser = useCallback(
    (g: GesteT) => {
      setActif(g.k)
      propager(g)
    },
    [propager],
  )

  const geste = terrain.gestes.find((g) => g.k === actif) ?? terrain.gestes[0]

  const poser = (type: 0 | 1 | 2) => {
    if (!geste) return
    compteur.current += 1
    const h = new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
    setJournal((j) =>
      [{ id: compteur.current, h, t: `${geste.k} · ${geste.actes[type]}` }, ...j].slice(0, 6),
    )
    if (type === 0) propager(geste)
  }

  const touchees = new Set(geste ? [geste.roleId, ...geste.ondes.map((o) => o.r)] : [])

  return (
    <div className="grid gap-5 lg:grid-cols-[1.05fr_1fr]">
      {/* le clavier */}
      <div>
        <article className="card overflow-hidden" style={{ boxShadow: 'var(--shadow)' }}>
          <div
            className="border-b px-4 py-3 sm:px-5"
            style={{ borderColor: 'var(--line)', background: 'var(--surface-2)' }}
          >
            <p className="eyebrow">Les rôles — une touche chacun</p>
          </div>
          {/* Taille adaptative : plus compacte sur mobile pour éviter les gros boutons géants */}
          <div className="px-3 py-3 sm:px-5 sm:py-4" style={{ ['--u' as string]: 'clamp(2.4rem, 7vw, 3.8rem)' }}>
            <div className="flex flex-wrap gap-[0.25rem]">
              {terrain.roles.map((r, i) => {
                const c = teinteT(r, jour)
                const rang = echos[r.id]
                const dans = touchees.has(r.id)
                return (
                  <span
                    key={r.id}
                    style={{
                      ['--tint' as string]: c,
                      width: 'var(--u)',
                      height: 'var(--u)',
                    }}
                    className={`cap relative flex flex-col items-center justify-center gap-px overflow-hidden px-0.5 leading-none ${
                      geste?.roleId === r.id ? 'active' : ''
                    } ${rang === 1 ? 'echo' : rang === 2 ? 'echo echo-2' : ''} ${dans ? '' : 'cap-morte'}`}
                    title={r.nom}
                  >
                    <span
                      className="absolute inset-x-0 top-0 h-[2px]"
                      style={{ background: c, opacity: rang || dans ? 1 : 0.28 }}
                      aria-hidden
                    />
                    <span className="mono text-[calc(var(--u)*.22)] font-medium" style={{ color: c }}>
                      {i + 1}
                    </span>
                    <span
                      className="max-w-full truncate text-[calc(var(--u)*.155)]"
                      style={{ color: 'var(--ink-2)' }}
                    >
                      {r.court}
                    </span>
                  </span>
                )
              })}
            </div>

            <p className="eyebrow mt-4">Les gestes — une touche, un dossier, une onde</p>
            <div className="mt-2 flex flex-wrap gap-[0.25rem]">
              {terrain.gestes.map((g) => {
                const c = teinteT(
                  terrain.roles.find((r) => r.id === g.roleId),
                  jour,
                )
                return (
                  <button
                    key={g.k}
                    type="button"
                    onClick={() => presser(g)}
                    aria-pressed={g.k === actif}
                    style={{
                      ['--tint' as string]: c,
                      width: 'calc(var(--u) * 1.7 + .2rem)',
                      height: 'var(--u)',
                    }}
                    className={`cap flex flex-col items-center justify-center gap-px overflow-hidden px-1 leading-none ${
                      g.k === actif ? 'active' : ''
                    }`}
                  >
                    <span className="mono text-[calc(var(--u)*.22)] font-medium" style={{ color: c }}>
                      {g.k}
                    </span>
                    <span
                      className="max-w-full truncate text-[calc(var(--u)*.155)]"
                      style={{ color: 'var(--ink-2)' }}
                    >
                      {g.label}
                    </span>
                  </button>
                )
              })}
            </div>

            <p className="eyebrow mt-4">Actions</p>
            <div className="mt-2 grid gap-[0.25rem] sm:grid-cols-3">
              {(['⏎', '⌫', ','] as const).map((k, i) => (
                <button
                  key={k}
                  type="button"
                  onClick={() => poser(i as 0 | 1 | 2)}
                  className="cap flex items-center gap-2 px-3 py-2 text-left text-[0.8rem]"
                >
                  <span className="mono text-[0.75rem]" style={{ color: 'var(--ink-3)' }}>
                    {k}
                  </span>
                  <span className="min-w-0 flex-1 truncate text-[0.75rem]">
                    {geste?.actes[i] ?? '—'}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </article>

        {/* mémoire */}
        <article className="card mt-4 overflow-hidden">
          <div
            className="flex items-baseline justify-between border-b px-4 py-3 sm:px-5"
            style={{ borderColor: 'var(--line)' }}
          >
            <p className="eyebrow">Mémoire causale</p>
            <span className="mono text-[0.72rem]" style={{ color: 'var(--ink-3)' }}>
              {journal.length} trace{journal.length > 1 ? 's' : ''}
            </span>
          </div>
          {journal.length === 0 ? (
            <p className="px-4 py-4 text-[0.82rem] sm:px-5" style={{ color: 'var(--ink-3)' }}>
              Rien encore. Posez un acte : il s’écrira ici, horodaté.
            </p>
          ) : (
            <ul className="divide-y" style={{ borderColor: 'var(--line)' }}>
              {journal.map((t) => (
                <li
                  key={t.id}
                  className="flex items-baseline gap-3 px-4 py-2.5 text-[0.82rem] sm:px-5"
                  style={{ borderColor: 'var(--line)' }}
                >
                  <span className="mono text-[0.72rem]" style={{ color: 'var(--ink-3)' }}>
                    {t.h}
                  </span>
                  <span className="min-w-0 flex-1">{t.t}</span>
                </li>
              ))}
            </ul>
          )}
        </article>
      </div>

      {/* le dossier */}
      {geste && (
        <article className="card overflow-hidden" style={{ boxShadow: 'var(--shadow)' }}>
          <span
            className="block h-[3px] w-full"
            style={{ background: teinteT(terrain.roles.find((r) => r.id === geste.roleId), jour) }}
            aria-hidden
          />
          <header className="border-b px-4 py-4 sm:px-5 sm:py-5" style={{ borderColor: 'var(--line)' }}>
            <p className="flex flex-wrap items-center gap-2 text-[0.74rem]">
              <span
                className="h-2 w-2 rounded-full"
                style={{ background: teinteT(terrain.roles.find((r) => r.id === geste.roleId), jour) }}
                aria-hidden
              />
              <span
                className="font-medium"
                style={{ color: teinteT(terrain.roles.find((r) => r.id === geste.roleId), jour) }}
              >
                {terrain.roles.find((r) => r.id === geste.roleId)?.nom}
              </span>
              <span className="mono" style={{ color: 'var(--ink-3)' }}>
                · touche {geste.k}
              </span>
            </p>
            <h3 className="display t-2 mt-2">{geste.label}</h3>
            <p className="lede mt-2 !text-[0.95rem]">{geste.scn}</p>
          </header>

          <div className="px-4 py-4 sm:px-5 sm:py-5">
            <p className="eyebrow">Ce qu’il faut savoir</p>
            <dl className="card-2 mt-3 divide-y" style={{ borderColor: 'var(--line)' }}>
              {geste.faits.map(([l, v]) => (
                <div
                  key={l}
                  className="flex flex-wrap items-baseline justify-between gap-3 px-4 py-2.5"
                  style={{ borderColor: 'var(--line)' }}
                >
                  <dt className="text-[0.82rem]" style={{ color: 'var(--ink-2)' }}>
                    {l}
                  </dt>
                  <dd className="text-[0.88rem] font-medium">{v}</dd>
                </div>
              ))}
            </dl>

            <p className="eyebrow mt-5">L’onde — {geste.ondes.length} rôles pivotent</p>
            <div className="card-2 mt-3 overflow-x-auto p-4">
              <OndeTerrain terrain={terrain} geste={geste} jour={jour} pareFeu={pareFeu} />
            </div>

            <ul className="mt-4 grid gap-2">
              {geste.ondes.map((o) => {
                const masquee = o.lock && !pareFeu
                const c = teinteT(terrain.roles.find((r) => r.id === o.r), jour)
                return (
                  <li
                    key={o.r + o.t}
                    className="flex items-start gap-3 rounded-xl border px-3.5 py-2.5"
                    style={{ borderColor: 'var(--line)', background: 'var(--surface-2)' }}
                  >
                    <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full" style={{ background: c }} aria-hidden />
                    <span className="min-w-0 flex-1 text-[0.84rem]">
                      <span className="font-medium" style={{ color: c }}>
                        {terrain.roles.find((r) => r.id === o.r)?.court ?? o.r}
                      </span>{' '}
                      <span style={{ color: 'var(--ink-2)' }}>
                        — {masquee ? 'sous pare-feu' : (o.lock && o.vrai) || o.t}
                      </span>
                    </span>
                  </li>
                )
              })}
            </ul>
          </div>
        </article>
      )}
    </div>
  )
}
