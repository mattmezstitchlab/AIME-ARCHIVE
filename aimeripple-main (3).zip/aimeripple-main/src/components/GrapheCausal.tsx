import { useMemo, useState } from 'react'
import type { RoleT, GesteT } from '@/data/terrains'
import { R as R_DEFAUT, ROLES as ROLES_DEFAUT } from '@/data/roles'
import { ARETES as ARETES_DEFAUT, STATS as STATS_DEFAUT } from '@/lib/causal'

export function GrapheCausal({
  roles,
  gestes,
  jour = false,
}: {
  roles?: RoleT[]
  gestes?: GesteT[]
  jour?: boolean
}) {
  const [survole, setSurvole] = useState<string | null>(null)

  const { R, ARETES, STATS, pos, degres, maxN, maxDeg, displayRoles } = useMemo(() => {
    // 1. Fallbacks ultra-sécurisés : si les imports ou les props sont undefined, on force des tableaux vides
    const defRoles = ROLES_DEFAUT || []
    const defAretes = ARETES_DEFAUT || []
    const defStats = STATS_DEFAUT || { roles: 0, gestes: 0, aretes: 0, liens: 0, ordre2: 0, masquees: 0 }
    const defR = R_DEFAUT || {}

    // On détermine si on est sur la page Accueil (données par défaut) ou Terrains (données dynamiques)
    const useDynamic = roles && roles.length > 0 && gestes && gestes.length > 0
    const activeRoles = useDynamic ? roles : defRoles
    const activeR = useDynamic ? Object.fromEntries(activeRoles.map((r) => [r.id, r])) : defR
    
    let activeAretes = defAretes
    let activeStats = defStats

    // 2. Si on est sur un Terrain, on recalcule le graphe à la volée
    if (useDynamic) {
      const aretesMap: Record<string, { src: string; dst: string; n: number; lock: number }> = {}
      let ordre2 = 0
      let masquees = 0
      let liens = 0

      gestes.forEach((g) => {
        if (!g.ondes) return
        g.ondes.forEach((o) => {
          liens++
          if (o.lock) masquees++

          const key = `${g.roleId}>${o.r}`
          if (!aretesMap[key]) {
            aretesMap[key] = { src: g.roleId, dst: o.r, n: 0, lock: o.lock ? 1 : 0 }
          }
          aretesMap[key].n += 1
          if (o.lock) aretesMap[key].lock = 1

          // Gestion des répercussions (puis)
          if (o.puis) {
            o.puis.forEach((p) => {
              liens++
              ordre2++
              const subKey = `${o.r}>${p.r}`
              if (!aretesMap[subKey]) {
                aretesMap[subKey] = { src: o.r, dst: p.r, n: 0, lock: 0 }
              }
              aretesMap[subKey].n += 1
            })
          }
        })
      })

      activeAretes = Object.values(aretesMap)
      activeStats = {
        roles: activeRoles.length,
        gestes: gestes.length,
        aretes: activeAretes.length,
        liens,
        ordre2,
        masquees,
      }
    }

    // 3. Calcul de la géométrie SVG en couronne
    const W = 520
    const cx = W / 2
    const cy = W / 2
    const rayon = W / 2 - 74
    const p: Record<string, { x: number; y: number; a: number }> = {}

    activeRoles.forEach((ro, i) => {
      const a = (i / activeRoles.length) * Math.PI * 2 - Math.PI / 2
      p[ro.id] = { x: cx + Math.cos(a) * rayon, y: cy + Math.sin(a) * rayon, a }
    })

    const d: Record<string, number> = {}
    activeAretes.forEach((e) => {
      d[e.src] = (d[e.src] ?? 0) + e.n
      d[e.dst] = (d[e.dst] ?? 0) + e.n
    })

    // On évite que Math.max plante sur un tableau vide
    const maxNCalc = activeAretes.length > 0 ? Math.max(...activeAretes.map((e) => e.n)) : 1
    const maxDegCalc = Object.values(d).length > 0 ? Math.max(...Object.values(d)) : 1

    return {
      R: activeR,
      ARETES: activeAretes,
      STATS: activeStats,
      pos: p,
      degres: d,
      maxN: maxNCalc,
      maxDeg: maxDegCalc,
      displayRoles: activeRoles
    }
  }, [roles, gestes])

  const W = 520

  return (
    <div className="grid gap-8 lg:grid-cols-[minmax(0,1fr)_17rem]">
      <div className="card-2 p-3 sm:p-5">
        <svg
          viewBox={`0 0 ${W} ${W}`}
          width="100%"
          role="img"
          aria-label={`Graphe causal : ${STATS.roles} rôles, ${STATS.aretes} arêtes, ${STATS.liens} liens.`}
          onMouseLeave={() => setSurvole(null)}
        >
          <circle cx={W / 2} cy={W / 2} r={W / 2 - 74} fill="none" stroke="var(--line)" strokeDasharray="2 6" />

          {ARETES.map((e) => {
            const a = pos[e.src]
            const b = pos[e.dst]
            if (!a || !b) return null
            const actif = !survole || survole === e.src || survole === e.dst
            
            const roleSrc = R[e.src]
            const c = roleSrc ? (jour && roleSrc.cJour ? roleSrc.cJour : roleSrc.c) : '#888'

            const qx = (a.x + b.x) / 2 + (W / 2 - (a.x + b.x) / 2) * 0.62
            const qy = (a.y + b.y) / 2 + (W / 2 - (a.y + b.y) / 2) * 0.62

            return (
              <path
                key={`${e.src}>${e.dst}`}
                d={`M${a.x} ${a.y} Q ${qx} ${qy} ${b.x} ${b.y}`}
                fill="none"
                stroke={c}
                strokeWidth={0.7 + (e.n / maxN) * 2.2}
                strokeOpacity={actif ? (survole ? 0.72 : 0.3) : 0.05}
                strokeDasharray={e.lock ? '3 4' : undefined}
                style={{ transition: 'stroke-opacity .3s var(--ease)' }}
              />
            )
          })}

          {displayRoles.map((ro) => {
            const p = pos[ro.id]
            if (!p) return null // Sécurité si un rôle n'a pas de position calculée
            
            const c = jour && ro.cJour ? ro.cJour : ro.c
            const r = 4.5 + ((degres[ro.id] ?? 0) / maxDeg) * 7
            const droite = Math.cos(p.a) > -0.15
            const lx = p.x + Math.cos(p.a) * (r + 9)
            const ly = p.y + Math.sin(p.a) * (r + 9)
            const actif = !survole || survole === ro.id

            return (
              <g key={ro.id} onMouseEnter={() => setSurvole(ro.id)} style={{ cursor: 'pointer', opacity: actif ? 1 : 0.28, transition: 'opacity .3s' }}>
                <circle cx={p.x} cy={p.y} r={r + 8} fill="transparent" />
                <circle cx={p.x} cy={p.y} r={r} fill={c} />
                {survole === ro.id ? <circle cx={p.x} cy={p.y} r={r + 6} fill="none" stroke={c} strokeOpacity="0.45" /> : null}
                <text x={lx} y={ly + 3.4} fontSize="10.5" textAnchor={droite ? 'start' : 'end'} fill={survole === ro.id ? 'var(--ink)' : 'var(--ink-3)'}>
                  {ro.court}
                </text>
              </g>
            )
          })}
        </svg>
      </div>

      <aside className="space-y-4">
        <div className="card-2 p-5">
          <p className="eyebrow mb-3">Le moteur en chiffres</p>
          <dl className="space-y-2 text-[0.86rem]">
            {(
              [
                ['Rôles', STATS.roles || 0],
                ['Gestes écrits', STATS.gestes || 0],
                ['Arêtes causales', STATS.aretes || 0],
                ['Liens pondérés', STATS.liens || 0],
                ['Ondes d’ordre 2', STATS.ordre2 || 0],
                ['Ondes sous scellé', STATS.masquees || 0],
              ] as Array<[string, number]>
            ).map(([l, v]) => (
              <div key={l} className="flex items-baseline justify-between gap-4">
                <dt style={{ color: 'var(--ink-2)' }}>{l}</dt>
                <dd className="tnum font-medium">{v}</dd>
              </div>
            ))}
          </dl>
        </div>

        <div className="card-2 p-5">
          <p className="eyebrow mb-2">Lecture</p>
          <p className="text-[0.84rem] leading-relaxed" style={{ color: 'var(--ink-2)' }}>
            Un disque large reçoit et émet beaucoup. Une arête épaisse est un lien
            fréquent. Les pointillés sont des ondes que le pare-feu retient.
            {survole ? (
              <>
                {' '}
                <span style={{ color: 'var(--ink)' }}>
                  {R[survole]?.nom} — {degres[survole] ?? 0} lien(s).
                </span>
              </>
            ) : (
              ' Survolez un rôle pour isoler ses arêtes.'
            )}
          </p>
        </div>
      </aside>
    </div>
  )
}
