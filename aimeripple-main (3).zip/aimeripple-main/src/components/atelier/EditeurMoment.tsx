import { useState } from 'react'
import { Check, X } from 'lucide-react'
import type { EventCategory, WeddingEvent } from '@/lib/moteur-timeline'

const CATEGORIES: Record<EventCategory, string> = {
  ceremony: 'Cérémonie',
  reception: 'Réception',
  catering: 'Table',
  music: 'Musique',
  photo: 'Image',
  preparation: 'Préparatifs',
  transport: 'Transport',
  accommodation: 'Hébergement',
  other: 'Divers',
}

export function EditeurMoment({
  e,
  onValider,
  onAnnuler,
}: {
  e: WeddingEvent
  onValider: (modif: Partial<WeddingEvent>) => void
  onAnnuler: () => void
}) {
  const [titre, setTitre] = useState(e.title)
  const [heure, setHeure] = useState(e.time)
  const [categorie, setCategorie] = useState<EventCategory>(e.category)
  const [budget, setBudget] = useState(e.budget ? String(e.budget) : '')
  const [description, setDescription] = useState(e.description ?? '')

  const champ =
    'w-full rounded-[10px] border bg-transparent px-2.5 py-1.5 text-[0.82rem] outline-none'

  return (
    <form
      className="mt-3 grid gap-2 border-t pt-3"
      style={{ borderColor: 'var(--line)' }}
      onSubmit={(ev) => {
        ev.preventDefault()
        const b = Number(budget.replace(/[^\d.]/g, ''))
        onValider({
          title: titre.trim() || e.title,
          time: /^\d{1,2}:\d{2}$/.test(heure) ? heure.padStart(5, '0') : e.time,
          category: categorie,
          budget: budget.trim() === '' ? undefined : Number.isFinite(b) ? b : e.budget,
          description,
        })
      }}
    >
      <div className="grid gap-2 sm:grid-cols-[1fr_5.5rem]">
        <input
          value={titre}
          onChange={(ev) => setTitre(ev.target.value)}
          aria-label="Titre du moment"
          className={champ}
          style={{ borderColor: 'var(--line)', color: 'var(--ink)' }}
        />
        <input
          value={heure}
          onChange={(ev) => setHeure(ev.target.value)}
          aria-label="Heure"
          placeholder="HH:MM"
          className={`${champ} tnum mono`}
          style={{ borderColor: 'var(--line)', color: 'var(--ink)' }}
        />
      </div>
      <div className="grid gap-2 sm:grid-cols-2">
        <select
          value={categorie}
          onChange={(ev) => setCategorie(ev.target.value as EventCategory)}
          aria-label="Catégorie"
          className={champ}
          style={{ borderColor: 'var(--line)', color: 'var(--ink)', background: 'var(--bg)' }}
        >
          {Object.entries(CATEGORIES).map(([k, v]) => (
            <option key={k} value={k}>
              {v}
            </option>
          ))}
        </select>
        <input
          value={budget}
          onChange={(ev) => setBudget(ev.target.value)}
          aria-label="Budget en euros"
          placeholder="budget €"
          inputMode="numeric"
          className={`${champ} tnum`}
          style={{ borderColor: 'var(--line)', color: 'var(--ink)' }}
        />
      </div>
      <textarea
        value={description}
        onChange={(ev) => setDescription(ev.target.value)}
        aria-label="Description"
        rows={2}
        className={`${champ} resize-none`}
        style={{ borderColor: 'var(--line)', color: 'var(--ink)' }}
      />
      <div className="flex gap-2">
        <button type="submit" className="btn btn-primaire gap-1.5 text-[0.76rem]">
          <Check className="size-3.5" /> Enregistrer
        </button>
        <button
          type="button"
          onClick={onAnnuler}
          className="btn btn-fantome gap-1.5 text-[0.76rem]"
        >
          <X className="size-3.5" /> Annuler
        </button>
      </div>
    </form>
  )
}
