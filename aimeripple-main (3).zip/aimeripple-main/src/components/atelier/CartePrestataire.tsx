import { useMemo } from 'react'
import {
  Building2,
  Camera,
  Car,
  Cake,
  Flower2,
  Heart,
  Mic2,
  Music,
  Palette,
  Scissors,
  Shirt,
  Utensils,
  Star,
  MapPin,
  Plus,
  Bookmark,
  Check,
} from 'lucide-react'
import type { CategoriePrestataire, Prestataire } from '@/data/prestataires'
import { LIBELLES_CATEGORIE } from '@/data/prestataires'

const ICONES: Record<CategoriePrestataire, typeof Camera> = {
  venue: Building2,
  planner: Heart,
  photo: Camera,
  catering: Utensils,
  music: Music,
  dj: Mic2,
  flowers: Flower2,
  dress: Shirt,
  beauty: Scissors,
  decor: Palette,
  cake: Cake,
  transport: Car,
}

export function CartePrestataire({
  p,
  posee,
  retenue,
  onPoser,
  onRetenir,
}: {
  p: Prestataire
  posee: boolean
  retenue: boolean
  onPoser: () => void
  onRetenir: () => void
}) {
  const Icone = useMemo(() => ICONES[p.categorie], [p.categorie])

  return (
    <article
      className="card-2 lift trace-entre overflow-hidden p-3"
      style={{ borderRadius: 'var(--r-md)' }}
    >
      <header className="flex items-start justify-between gap-3">
        <span className="flex items-center gap-2">
          <span
            className="grid size-8 place-items-center rounded-full"
            style={{ background: 'var(--surface-hi)' }}
          >
            <Icone className="size-4" style={{ color: 'var(--accent)' }} />
          </span>
          <span className="leading-tight">
            <span className="block text-[0.9rem] font-semibold">{p.nom}</span>
            <span className="mono block text-[0.66rem]" style={{ color: 'var(--ink-3)' }}>
              {LIBELLES_CATEGORIE[p.categorie]}
            </span>
          </span>
        </span>
        <span
          className="tnum flex shrink-0 items-center gap-1 text-[0.72rem]"
          style={{ color: 'var(--gold)' }}
        >
          <Star className="size-3 fill-current" />
          {p.note.toFixed(1)}
        </span>
      </header>

      <p className="mt-2 text-[0.8rem] leading-snug" style={{ color: 'var(--ink-2)' }}>
        {p.description}
      </p>

      <div
        className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-[0.72rem]"
        style={{ color: 'var(--ink-3)' }}
      >
        <span className="flex items-center gap-1">
          <MapPin className="size-3" />
          {p.lieu}
        </span>
        <span className="tnum" style={{ color: 'var(--ink-2)' }}>
          dès {p.aPartirDe}
        </span>
        <span style={{ color: p.disponible ? 'var(--accent)' : 'var(--ink-3)' }}>
          {p.disponible ? 'disponible' : 'sur liste d’attente'}
        </span>
      </div>

      <div className="mt-3 flex gap-2">
        <button
          type="button"
          onClick={onPoser}
          disabled={posee}
          className="btn btn-primaire flex-1 justify-center gap-1.5 text-[0.76rem] disabled:opacity-50"
        >
          {posee ? <Check className="size-3.5" /> : <Plus className="size-3.5" />}
          {posee ? 'sur le rail' : 'poser sur le rail'}
        </button>
        <button
          type="button"
          onClick={onRetenir}
          className="btn btn-fantome gap-1.5 text-[0.76rem]"
          aria-pressed={retenue}
        >
          <Bookmark
            className="size-3.5"
            style={{ fill: retenue ? 'currentColor' : 'none' }}
          />
          {retenue ? 'retenu' : 'retenir'}
        </button>
      </div>
    </article>
  )
}
