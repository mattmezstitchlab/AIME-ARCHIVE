import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import {
  Send,
  Loader2,
  CheckCircle2,
  Circle,
  Clock,
  Trash2,
  AlertTriangle,
  Info,
  Wallet,
  Gauge,
  Sparkle,
  Pencil,
  FileDown,
  ClipboardCopy,
  RotateCcw,
} from 'lucide-react'
import {
  analyzeWedding,
  cuid,
  formatEuro,
  makeTasks,
  parseChatCommand,
  parseWeddingInput,
  sortByTime,
  type EventCategory,
  type WeddingAnalysis,
  type WeddingConfig,
  type WeddingEvent,
} from '@/lib/moteur-timeline'
import {
  categorieTimeline,
  chercherPrestataires,
  heureSuggeree,
  prestataireParId,
  type Prestataire,
} from '@/data/prestataires'
import { converserAvecAgent } from '@/lib/agent.functions'
import { CartePrestataire } from './CartePrestataire'
import { EditeurMoment } from './EditeurMoment'
import { useToast } from '@/lib/toast'
import { dateLisible, ecrireEtat, effacerEtat, lireEtat } from '@/lib/atelier-persistance'
import { exporterPdf, resumeTexte } from '@/lib/atelier-export'
import { LIBELLES_CATEGORIE } from '@/data/prestataires'

const CATEGORIES: Record<EventCategory, string> = {
  ceremony: 'Cérémonie',
  reception: 'Réception',
  catering: 'Table',
  music: 'Musique',
  photo: 'Image',
  preparation: 'Préparatifs',
  transport: 'Transport',
  accommodation: 'Hébergement',
  other: 'Divers',
}

const EXEMPLES = [
  'Mariage le 12 septembre 2026, 120 invités, domaine avec jardin, cérémonie laïque, photographe, saxophoniste au cocktail et DJ le soir.',
  'Mariage intime de 30 personnes en hiver, mairie puis restaurant, un trio jazz, pas de DJ.',
  'Mariage de prestige au château, 180 invités, dîner de gala, orchestre, vidéaste, navettes et nuit sur place.',
]

const RELANCES = [
  'Qu’est-ce qui manque encore ?',
  'Quel est mon budget estimé ?',
  'Décale le dîner à 20h30',
  'Trouve-moi un photographe',
  'Ajoute un DJ à 22h',
]

interface Bulle {
  id: string
  role: 'user' | 'agent'
  texte: string
  cartes?: string[]
  suggestion?: string
  impact?: string
  ecrit?: boolean
}

/** Commentaire automatique de l'agent sur les cartes qui viennent d'apparaître. */
function commentaireCartes(ids: string[]): string {
  const cartes = ids.map(prestataireParId).filter(Boolean) as Prestataire[]
  if (!cartes.length) return ''
  const tete =
    cartes.length === 1
      ? `Une carte pour ce poste : ${cartes[0].nom}.`
      : `${cartes.length} cartes comparables sur ce poste.`
  const detail = cartes
    .map(
      (p) =>
        `${p.nom} — ${LIBELLES_CATEGORIE[p.categorie]}, ${p.lieu}, dès ${p.aPartirDe}, note ${p.note.toFixed(1)}${p.disponible ? '' : ', sur liste d’attente'}. La poser ajoute un moment vers ${heureSuggeree(p.categorie)}.`,
    )
    .join('\n')
  return `${tete}\n${detail}\nDites-moi laquelle vous tente, ou posez-la : je recale l’heure et le budget derrière.`
}

export function Atelier() {
  const toast = useToast()
  const [phase, setPhase] = useState<'depart' | 'atelier'>('depart')
  const [brouillon, setBrouillon] = useState('')
  const [evenements, setEvenements] = useState<WeddingEvent[]>([])
  const [config, setConfig] = useState<WeddingConfig | null>(null)
  const [bulles, setBulles] = useState<Bulle[]>([])
  const [saisie, setSaisie] = useState('')
  const [occupe, setOccupe] = useState(false)
  const [retenus, setRetenus] = useState<string[]>([])
  const [ouvert, setOuvert] = useState<string | null>(null)
  const [enEdition, setEnEdition] = useState<string | null>(null)
  const [relances, setRelances] = useState<string[]>(RELANCES)
  const [reprise, setReprise] = useState<string | null>(null)
  const [pret, setPret] = useState(false)
  const [alertesAgent, setAlertesAgent] = useState<
    { id: string; severity: 'critical' | 'warning' | 'info'; message: string }[]
  >([])

  const filRef = useRef<HTMLDivElement>(null)
  const champRef = useRef<HTMLTextAreaElement>(null)

  const analyse: WeddingAnalysis | null = useMemo(
    () => (config ? analyzeWedding(evenements, config) : null),
    [evenements, config],
  )

  useEffect(() => {
    filRef.current?.scrollTo({ top: filRef.current.scrollHeight, behavior: 'smooth' })
  }, [bulles])

  useEffect(() => {
    if (phase === 'atelier') champRef.current?.focus()
  }, [phase])

  /* ── reprise de session ─────────────────────────────────────────────── */
  useEffect(() => {
    const etat = lireEtat()
    if (etat?.config) {
      setEvenements(etat.evenements)
      setConfig(etat.config)
      setBulles(etat.bulles ?? [])
      setRetenus(etat.retenus ?? [])
      setOuvert(etat.ouvert ?? null)
      setPhase('atelier')
      setReprise(dateLisible(etat.enregistreLe))
    }
    setPret(true)
  }, [])

  useEffect(() => {
    if (!pret || phase !== 'atelier' || !config) return
    ecrireEtat({
      evenements,
      config,
      bulles: bulles
        .filter((b) => !b.ecrit)
        .map(({ id, role, texte, cartes, suggestion }) => ({
          id,
          role,
          texte,
          cartes,
          suggestion,
        })),
      retenus,
      ouvert,
    })
  }, [pret, phase, evenements, config, bulles, retenus, ouvert])

  /* ── départ : la phrase devient une timeline ────────────────────────── */
  const lancer = useCallback(
    (texte: string) => {
      const brut = texte.trim()
      if (!brut) return
      const { events, config: cfg } = parseWeddingInput(brut)
      setEvenements(events)
      setConfig(cfg)
      setPhase('atelier')
      setBulles([
        {
          id: cuid(),
          role: 'agent',
          texte: `J’ai déplié ${events.length} moments à partir de votre phrase. Dites-moi ce qui change, je recale le rail — et je sors des cartes quand un poste est encore vide.`,
          suggestion: 'Qu’est-ce qui manque encore ?',
        },
      ])
    },
    [],
  )

  /* ── poser un prestataire sur le rail ───────────────────────────────── */
  const poser = useCallback(
    (p: Prestataire) => {
      setEvenements((prev) =>
        sortByTime([
          ...prev,
          {
            id: cuid(),
            title: p.nom,
            time: heureSuggeree(p.categorie),
            description: p.description,
            status: 'pending',
            category: categorieTimeline(p.categorie),
            vendor: p.nom,
            budget: p.budget,
            tasks: makeTasks(categorieTimeline(p.categorie)),
            isNew: true,
          },
        ]),
      )
      setBulles((b) => [
        ...b,
        {
          id: cuid(),
          role: 'agent',
          texte: `${p.nom} est sur le rail vers ${heureSuggeree(p.categorie)} (${LIBELLES_CATEGORIE[p.categorie]}).`,
          impact: `+ ${formatEuro(p.budget)} au budget estimé, et ce poste ne compte plus comme manquant dans la tenue de la journée.`,
          suggestion: `Quel impact sur le reste de la journée ?`,
        },
      ])
      toast(`${p.nom} posé sur le rail`)
    },
    [toast],
  )

  const posees = useMemo(
    () => new Set(evenements.map((e) => e.vendor).filter(Boolean) as string[]),
    [evenements],
  )

  /* ── conversation ───────────────────────────────────────────────────── */
  const envoyer = useCallback(
    async (texte: string) => {
      const t = texte.trim()
      if (!t || occupe || !config) return
      setSaisie('')
      setOccupe(true)

      const idAttente = cuid()
      setBulles((p) => [
        ...p,
        { id: cuid(), role: 'user', texte: t },
        { id: idAttente, role: 'agent', texte: '', ecrit: true },
      ])

      const historique = bulles
        .filter((b) => !b.ecrit && b.texte)
        .slice(-10)
        .map((b) => ({ role: b.role, text: b.texte }))

      let reponse = ''
      let suggestion: string | undefined
      let impact: string | undefined
      let cartes: string[] = []

      try {
        const r = await converserAvecAgent({
          data: {
            message: t,
            historique,
            evenements: evenements.map((e) => ({
              id: e.id,
              title: e.title,
              time: e.time,
              category: e.category,
              status: e.status,
            })),
            contexte: {
              guestCount: config.guestCount,
              venue: config.venue,
              style: config.style,
              season: config.season,
              weddingDate: config.weddingDate,
            },
          },
        })

        if (r.horsLigne || !r.reponse) {
          const local = parseChatCommand(t, evenements, config)
          setEvenements(local.updatedEvents)
          reponse = local.response
          cartes = chercherPrestataires(t).map((p) => p.id)
        } else {
          reponse = r.reponse
          suggestion = r.suggestion
          impact = r.impact
          cartes = r.prestataires
          if (r.relances?.length) setRelances(r.relances)
          if (r.actions.length) {
            setEvenements((prev) => {
              let courant = [...prev]
              for (const a of r.actions) {
                if (a.type === 'ajouter') {
                  const cat = (a.categorie as EventCategory) ?? 'other'
                  courant.push({
                    id: cuid(),
                    title: a.titre,
                    time: a.heure || '18:00',
                    description: a.description ?? '',
                    status: 'pending',
                    category: CATEGORIES[cat] ? cat : 'other',
                    tasks: makeTasks(CATEGORIES[cat] ? cat : 'other'),
                    isNew: true,
                  })
                } else if (a.type === 'deplacer') {
                  courant = courant.map((e) => (e.id === a.id ? { ...e, time: a.heure } : e))
                } else if (a.type === 'confirmer') {
                  courant = courant.map((e) => (e.id === a.id ? { ...e, status: 'done' } : e))
                } else if (a.type === 'supprimer') {
                  courant = courant.filter((e) => e.id !== a.id)
                }
              }
              return sortByTime(courant)
            })
            const nouvellesAlertes = r.actions
              .filter((a) => a.type === 'alerte')
              .map((a) => ({
                id: cuid(),
                severity: (a as { gravite: 'critical' | 'warning' | 'info' }).gravite,
                message: (a as { message: string }).message,
              }))
            if (nouvellesAlertes.length) setAlertesAgent(nouvellesAlertes)
          }
        }
      } catch {
        const local = parseChatCommand(t, evenements, config)
        setEvenements(local.updatedEvents)
        reponse = local.response
        cartes = chercherPrestataires(t).map((p) => p.id)
      }

      const commentaire = commentaireCartes(cartes)
      setBulles((p) => [
        ...p.map((b) =>
          b.id === idAttente
            ? { ...b, texte: reponse, cartes, suggestion, impact, ecrit: false }
            : b,
        ),
        ...(commentaire
          ? [{ id: cuid(), role: 'agent' as const, texte: commentaire }]
          : []),
      ])
      setOccupe(false)
      champRef.current?.focus()
    },
    [bulles, config, evenements, occupe],
  )

  /* ── édition directe sur le rail ────────────────────────────────────── */
  const basculer = (id: string) =>
    setEvenements((p) =>
      p.map((e) => (e.id === id ? { ...e, status: e.status === 'done' ? 'pending' : 'done' } : e)),
    )
  const retirer = (id: string) => {
    const cible = evenements.find((e) => e.id === id)
    setEvenements((p) => p.filter((e) => e.id !== id))
    if (enEdition === id) setEnEdition(null)
    if (cible) toast(`${cible.title} retiré du rail`)
  }
  const modifier = (id: string, modif: Partial<WeddingEvent>) => {
    setEvenements((p) => sortByTime(p.map((e) => (e.id === id ? { ...e, ...modif } : e))))
    setEnEdition(null)
    toast('Moment mis à jour — budget et tenue recalculés')
  }
  const decaler = (id: string, minutes: number) =>
    setEvenements((p) =>
      sortByTime(
        p.map((e) => {
          if (e.id !== id) return e
          const [h, m] = e.time.split(':').map(Number)
          const t = (h * 60 + m + minutes + 1440) % 1440
          return {
            ...e,
            time: `${String(Math.floor(t / 60)).padStart(2, '0')}:${String(t % 60).padStart(2, '0')}`,
          }
        }),
      ),
    )
  const recommencer = () => {
    effacerEtat()
    setEvenements([])
    setConfig(null)
    setBulles([])
    setRetenus([])
    setAlertesAgent([])
    setReprise(null)
    setBrouillon('')
    setPhase('depart')
  }
  const copierResume = async () => {
    try {
      await navigator.clipboard.writeText(resumeTexte(evenements, config, analyse, retenus))
      toast('Résumé copié — prêt à partager')
    } catch {
      toast('Copie impossible depuis ce navigateur')
    }
  }
  const cocher = (idE: string, idT: string) =>
    setEvenements((p) =>
      p.map((e) =>
        e.id === idE
          ? {
              ...e,
              tasks: e.tasks?.map((t) =>
                t.id === idT ? { ...t, status: t.status === 'done' ? 'todo' : 'done' } : t,
              ),
            }
          : e,
      ),
    )

  /* ══════════════════════════════════════════════════════════════════ */
  if (phase === 'depart') {
    return (
      <section className="mx-auto max-w-2xl py-6">
        <label htmlFor="depart" className="eyebrow block">
          Une phrase suffit
        </label>
        <textarea
          id="depart"
          value={brouillon}
          onChange={(e) => setBrouillon(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) lancer(brouillon)
          }}
          rows={5}
          placeholder="Décrivez la journée : date, nombre d’invités, lieu, style, ce qui est déjà décidé…"
          className="card-2 mt-3 w-full resize-none bg-transparent p-4 text-[0.95rem] outline-none"
          style={{ borderRadius: 'var(--r-md)', color: 'var(--ink)' }}
        />
        <div className="mt-3 flex items-center justify-between gap-3">
          <span className="mono text-[0.7rem]" style={{ color: 'var(--ink-3)' }}>
            ⌘ + entrée
          </span>
          <button
            type="button"
            className="btn btn-primaire gap-2"
            onClick={() => lancer(brouillon)}
            disabled={!brouillon.trim()}
          >
            Déplier la journée
            <Send className="size-4" />
          </button>
        </div>

        <p className="eyebrow mt-10">Ou partez d’un exemple</p>
        <div className="mt-3 grid gap-2">
          {EXEMPLES.map((ex) => (
            <button
              key={ex}
              type="button"
              onClick={() => lancer(ex)}
              className="card lift p-3 text-left text-[0.83rem]"
              style={{ borderRadius: 'var(--r-sm)', color: 'var(--ink-2)' }}
            >
              {ex}
            </button>
          ))}
        </div>
      </section>
    )
  }

  const alertes = [...(analyse?.alerts ?? []), ...alertesAgent]

  return (
    <div className="grid gap-6 py-6 lg:grid-cols-[1.05fr_0.95fr]">
      {/* ─── rail ─────────────────────────────────────────────────────── */}
      <section className="min-w-0">
        <header className="flex flex-wrap items-baseline justify-between gap-3">
          <h2 className="t-3">Le rail</h2>
          <span className="mono text-[0.7rem]" style={{ color: 'var(--ink-3)' }}>
            {evenements.length} moments · {analyse?.confirmedCount ?? 0} confirmés
          </span>
        </header>

        <div className="mt-3 flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => exporterPdf(evenements, config, analyse, retenus)}
            className="btn btn-fantome gap-1.5 text-[0.76rem]"
          >
            <FileDown className="size-3.5" /> Exporter en PDF
          </button>
          <button
            type="button"
            onClick={copierResume}
            className="btn btn-fantome gap-1.5 text-[0.76rem]"
          >
            <ClipboardCopy className="size-3.5" /> Copier le résumé
          </button>
          <button
            type="button"
            onClick={recommencer}
            className="btn btn-fantome gap-1.5 text-[0.76rem]"
          >
            <RotateCcw className="size-3.5" /> Repartir de zéro
          </button>
          <span className="mono text-[0.68rem]" style={{ color: 'var(--ink-3)' }}>
            {reprise ? `session reprise · ${reprise}` : 'sauvegarde automatique'}
          </span>
        </div>

        <ol className="relative mt-4 pl-5">
          <span
            className="absolute top-2 bottom-2 left-[5px] w-px"
            style={{ background: 'var(--line)' }}
            aria-hidden
          />
          {evenements.map((e) => {
            const faites = e.tasks?.filter((t) => t.status === 'done').length ?? 0
            const total = e.tasks?.length ?? 0
            const ouverte = ouvert === e.id
            return (
              <li key={e.id} className="relative mb-2.5">
                <span
                  className="absolute top-[18px] -left-5 size-[11px] rounded-full border-2"
                  style={{
                    borderColor: e.status === 'done' ? 'var(--accent)' : 'var(--line-hi)',
                    background: e.status === 'done' ? 'var(--accent)' : 'var(--bg)',
                  }}
                  aria-hidden
                />
                <div className="card-2 p-3" style={{ borderRadius: 'var(--r-md)' }}>
                  <div className="flex items-start gap-3">
                    <span className="tnum mono pt-0.5 text-[0.78rem]" style={{ color: 'var(--accent)' }}>
                      {e.time}
                    </span>
                    <button
                      type="button"
                      className="flex-1 text-left"
                      onClick={() => setOuvert(ouverte ? null : e.id)}
                    >
                      <span className="block text-[0.9rem] font-semibold">{e.title}</span>
                      <span
                        className="mono block text-[0.66rem]"
                        style={{ color: 'var(--ink-3)' }}
                      >
                        {CATEGORIES[e.category]}
                        {total > 0 ? ` · ${faites}/${total} étapes` : ''}
                        {e.budget ? ` · ${formatEuro(e.budget)}` : ''}
                      </span>
                    </button>
                    <button
                      type="button"
                      onClick={() => basculer(e.id)}
                      aria-label={e.status === 'done' ? 'Repasser en attente' : 'Confirmer'}
                      className="shrink-0 p-1"
                      style={{ color: e.status === 'done' ? 'var(--accent)' : 'var(--ink-3)' }}
                    >
                      {e.status === 'done' ? (
                        <CheckCircle2 className="size-4" />
                      ) : (
                        <Circle className="size-4" />
                      )}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setOuvert(e.id)
                        setEnEdition(enEdition === e.id ? null : e.id)
                      }}
                      aria-label="Modifier ce moment"
                      className="shrink-0 p-1"
                      style={{ color: enEdition === e.id ? 'var(--accent)' : 'var(--ink-3)' }}
                    >
                      <Pencil className="size-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => retirer(e.id)}
                      aria-label="Retirer du rail"
                      className="shrink-0 p-1"
                      style={{ color: 'var(--ink-3)' }}
                    >
                      <Trash2 className="size-4" />
                    </button>
                  </div>

                  {ouverte && enEdition === e.id && (
                    <EditeurMoment
                      e={e}
                      onValider={(modif) => modifier(e.id, modif)}
                      onAnnuler={() => setEnEdition(null)}
                    />
                  )}

                  {ouverte && enEdition !== e.id && (
                    <div className="dossier-entre mt-3 border-t pt-3" style={{ borderColor: 'var(--line)' }}>
                      <div className="mb-2 flex flex-wrap items-center gap-1.5">
                        <span className="mono text-[0.68rem]" style={{ color: 'var(--ink-3)' }}>
                          déplacer
                        </span>
                        {[-30, -15, 15, 30].map((d) => (
                          <button
                            key={d}
                            type="button"
                            onClick={() => decaler(e.id, d)}
                            className="btn btn-fantome tnum px-2 py-1 text-[0.72rem]"
                          >
                            {d > 0 ? `+${d}` : d} min
                          </button>
                        ))}
                      </div>
                      <p className="text-[0.82rem]" style={{ color: 'var(--ink-2)' }}>
                        {e.description}
                      </p>
                      {e.tasks && e.tasks.length > 0 && (
                        <ul className="mt-2 grid gap-1">
                          {e.tasks.map((t) => (
                            <li key={t.id}>
                              <button
                                type="button"
                                onClick={() => cocher(e.id, t.id)}
                                className="flex w-full items-center gap-2 text-left text-[0.8rem]"
                                style={{
                                  color:
                                    t.status === 'done' ? 'var(--ink-3)' : 'var(--ink-2)',
                                  textDecoration:
                                    t.status === 'done' ? 'line-through' : 'none',
                                }}
                              >
                                {t.status === 'done' ? (
                                  <CheckCircle2 className="size-3.5 shrink-0" />
                                ) : (
                                  <Circle className="size-3.5 shrink-0" />
                                )}
                                {t.label}
                              </button>
                            </li>
                          ))}
                        </ul>
                      )}
                    </div>
                  )}
                </div>
              </li>
            )
          })}
        </ol>

        {/* orbite : score, alertes, budget */}
        {analyse && (
          <div className="mt-6 grid gap-3 sm:grid-cols-2">
            <div className="card-2 p-4" style={{ borderRadius: 'var(--r-md)' }}>
              <span className="eyebrow flex items-center gap-1.5">
                <Gauge className="size-3.5" /> Tenue de la journée
              </span>
              <p className="tnum mt-1 text-[2rem] leading-none font-semibold">{analyse.score}%</p>
              <div
                className="mt-3 h-1 w-full overflow-hidden rounded-full"
                style={{ background: 'var(--surface-hi)' }}
              >
                <span
                  className="block h-full rounded-full transition-[width] duration-700"
                  style={{ width: `${analyse.score}%`, background: 'var(--accent)' }}
                />
              </div>
            </div>
            <div className="card-2 p-4" style={{ borderRadius: 'var(--r-md)' }}>
              <span className="eyebrow flex items-center gap-1.5">
                <Wallet className="size-3.5" /> Budget estimé
              </span>
              <p className="tnum mt-1 text-[2rem] leading-none font-semibold">
                {formatEuro(analyse.totalBudget)}
              </p>
              <p className="mt-2 text-[0.72rem]" style={{ color: 'var(--ink-3)' }}>
                {analyse.budgetLines.filter((l) => l.isEstimate).length} lignes estimées sur{' '}
                {analyse.budgetLines.length}
              </p>
            </div>

            {alertes.length > 0 && (
              <ul className="grid gap-2 sm:col-span-2">
                {alertes.map((a) => (
                  <li
                    key={a.id}
                    className="card flex items-start gap-2 p-3 text-[0.82rem]"
                    style={{ borderRadius: 'var(--r-sm)' }}
                  >
                    {a.severity === 'info' ? (
                      <Info className="mt-0.5 size-4 shrink-0" style={{ color: 'var(--ink-3)' }} />
                    ) : (
                      <AlertTriangle
                        className="mt-0.5 size-4 shrink-0"
                        style={{
                          color: a.severity === 'critical' ? '#ff6b6b' : 'var(--gold)',
                        }}
                      />
                    )}
                    <span style={{ color: 'var(--ink-2)' }}>{a.message}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        )}
      </section>

      {/* ─── agent ────────────────────────────────────────────────────── */}
      <section className="min-w-0 lg:sticky lg:top-16 lg:self-start">
        <header className="flex items-baseline justify-between gap-3">
          <h2 className="t-3">L’agent</h2>
          <span className="mono text-[0.7rem]" style={{ color: 'var(--ink-3)' }}>
            il modifie le rail en parlant
          </span>
        </header>

        <div
          className="card-2 mt-4 flex flex-col"
          style={{ borderRadius: 'var(--r-lg)', height: 'min(72vh, 720px)' }}
        >
          <div ref={filRef} className="scroll-fin flex flex-1 flex-col justify-end gap-4 overflow-y-auto p-4">
            {bulles.map((b) => (
              <div key={b.id}>
                {b.role === 'user' ? (
                  <p
                    className="ml-auto w-fit max-w-[85%] px-3.5 py-2 text-[0.86rem]"
                    style={{
                      background: 'var(--accent)',
                      color: 'var(--accent-ink)',
                      borderRadius: '16px 16px 4px 16px',
                    }}
                  >
                    {b.texte}
                  </p>
                ) : (
                  <div className="max-w-[95%]">
                    {b.ecrit ? (
                      <span
                        className="flex items-center gap-2 text-[0.84rem]"
                        style={{ color: 'var(--ink-3)' }}
                      >
                        <Loader2 className="size-3.5 animate-spin" />
                        l’onde se propage…
                      </span>
                    ) : (
                      <p
                        className="text-[0.88rem] leading-relaxed whitespace-pre-line"
                        style={{ color: 'var(--ink)' }}
                      >
                        {b.texte}
                      </p>
                    )}

                    {b.impact && !b.ecrit && (
                      <p
                        className="mt-2 border-l-2 pl-2.5 text-[0.8rem]"
                        style={{ borderColor: 'var(--accent)', color: 'var(--ink-2)' }}
                      >
                        {b.impact}
                      </p>
                    )}

                    {b.cartes && b.cartes.length > 0 && (
                      <div className="mt-3 grid gap-2">
                        {b.cartes.map((id) => {
                          const p = prestataireParId(id)
                          if (!p) return null
                          return (
                            <CartePrestataire
                              key={id}
                              p={p}
                              posee={posees.has(p.nom)}
                              retenue={retenus.includes(p.id)}
                              onPoser={() => poser(p)}
                              onRetenir={() =>
                                setRetenus((r) =>
                                  r.includes(p.id) ? r.filter((x) => x !== p.id) : [...r, p.id],
                                )
                              }
                            />
                          )
                        })}
                      </div>
                    )}

                    {b.suggestion && !b.ecrit && (
                      <button
                        type="button"
                        onClick={() => envoyer(b.suggestion!)}
                        className="btn btn-fantome mt-3 gap-1.5 text-[0.78rem]"
                      >
                        <Sparkle className="size-3.5" />
                        {b.suggestion}
                      </button>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>

          <div className="border-t p-3" style={{ borderColor: 'var(--line)' }}>
            <div className="scroll-fin -mx-1 mb-2 flex gap-1.5 overflow-x-auto px-1 pb-1">
              {relances.map((r) => (
                <button
                  key={r}
                  type="button"
                  onClick={() => envoyer(r)}
                  disabled={occupe}
                  className="btn btn-fantome shrink-0 text-[0.74rem] whitespace-nowrap"
                >
                  {r}
                </button>
              ))}
            </div>
            <form
              className="flex items-end gap-2"
              onSubmit={(e) => {
                e.preventDefault()
                envoyer(saisie)
              }}
            >
              <textarea
                ref={champRef}
                value={saisie}
                onChange={(e) => setSaisie(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault()
                    envoyer(saisie)
                  }
                }}
                rows={1}
                placeholder="Décale le dîner, ajoute un DJ, cherche un traiteur…"
                className="max-h-28 min-h-[42px] flex-1 resize-none rounded-[14px] border bg-transparent px-3 py-2.5 text-[0.86rem] outline-none"
                style={{ borderColor: 'var(--line)', color: 'var(--ink)' }}
              />
              <button
                type="submit"
                disabled={occupe || !saisie.trim()}
                aria-label="Envoyer"
                className="btn btn-primaire grid size-[42px] shrink-0 place-items-center !px-0"
              >
                {occupe ? (
                  <Loader2 className="size-4 animate-spin" />
                ) : (
                  <Send className="size-4" />
                )}
              </button>
            </form>
          </div>
        </div>

        <p className="mono mt-3 flex items-center gap-1.5 text-[0.7rem]" style={{ color: 'var(--ink-3)' }}>
          <Clock className="size-3" />
          {config?.weddingDate ?? 'date à préciser'} · {config?.guestCount} invités
          {config?.venue ? ` · ${config.venue}` : ''}
          {config?.style ? ` · ${config.style}` : ''}
        </p>
      </section>
    </div>
  )
}
