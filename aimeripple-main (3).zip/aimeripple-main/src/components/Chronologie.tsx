import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { R } from '@/data/roles'
import { CATEGORIES, CHRONOLOGIE, ETATS } from '@/data/chronologie'
import type { Etat, Moment } from '@/data/chronologie'
import { teinte } from '@/lib/causal'
import type { Arc } from '@/lib/causal'
import { Cascade } from '@/components/Cascade'

/* ------------------------------------------------------------------
   La chronologie causale — la même journée que le clavier, vue en
   longueur. Choisir un moment allume ses ondes : les rôles touchés,
   puis les moments qu'ils tiennent plus tard. Le temps est une onde.
------------------------------------------------------------------ */

const arcsDuMoment = (mo: Moment): Arc[] =>
  mo.ondes.map((r) => ({ r, lock: !!mo.scelle && r !== 'coordo', sous: [] }))

const euros = (n: number) =>
  n.toLocaleString('fr-FR', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 })

function Pastille({ etat }: { etat: Etat }) {
  const c =
    etat === 'confirme' ? 'var(--gold)' : etat === 'en-cours' ? 'var(--accent)' : 'var(--ink-3)'
  return (
    <span
      className="inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-[0.68rem]"
      style={{ borderColor: 'var(--line)', color: 'var(--ink-2)' }}
    >
      <span className="h-1.5 w-1.5 rounded-full" style={{ background: c }} aria-hidden />
      {ETATS[etat].l}
    </span>
  )
}

export function Chronologie({
  jour,
  pareFeu,
  onOuvrirClavier,
}: {
  jour: boolean
  pareFeu: boolean
  onOuvrirClavier?: (roleId: string) => void
}) {
  const [etats, setEtats] = useState<Record<string, Etat>>({})
  const [faites, setFaites] = useState<Record<string, boolean>>({})
  const [ouvert, setOuvert] = useState<string | null>(CHRONOLOGIE[5]?.id ?? null)
  const [onde, setOnde] = useState<Record<string, number>>({})
  const minuteurs = useRef<Array<ReturnType<typeof setTimeout>>>([])

  useEffect(
    () => () => {
      minuteurs.current.forEach(clearTimeout)
    },
    [],
  )

  const etatDe = (mo: Moment): Etat => etats[mo.id] ?? mo.etat

  /** L'onde du temps : le moment touche ses rôles, puis les moments suivants
      que ces rôles tiennent. Une vague, pas un clignotement. */
  const propager = useCallback((mo: Moment) => {
    const i = CHRONOLOGIE.findIndex((x) => x.id === mo.id)
    const touches = new Set([mo.pilote, ...mo.ondes])
    const suite = CHRONOLOGIE.filter(
      (x, j) => j > i && (touches.has(x.pilote) || x.ondes.some((r) => touches.has(r))),
    )
    minuteurs.current.forEach(clearTimeout)
    minuteurs.current = []
    setOnde({ [mo.id]: 1 })
    suite.forEach((x, k) => {
      minuteurs.current.push(
        setTimeout(() => setOnde((o) => ({ ...o, [x.id]: 2 })), 180 + k * 150),
      )
    })
    minuteurs.current.push(setTimeout(() => setOnde({}), 500 + suite.length * 150))
  }, [])

  const choisir = (mo: Moment) => {
    setOuvert((v) => (v === mo.id ? null : mo.id))
    propager(mo)
  }

  const bilan = useMemo(() => {
    const total = CHRONOLOGIE.reduce((n, m) => n + (m.budget ?? 0), 0)
    const confirmes = CHRONOLOGIE.filter((m) => (etats[m.id] ?? m.etat) === 'confirme').length
    const etapes = CHRONOLOGIE.flatMap((m) => m.etapes.map((s) => `${m.id}.${s.id}`))
    const cochees = etapes.filter((k) => faites[k]).length
    return { total, confirmes, etapes: etapes.length, cochees }
  }, [etats, faites])

  return (
    <div className="space-y-8">
      <div className="grid gap-3 sm:grid-cols-4">
        {(
          [
            ['Budget engagé', euros(bilan.total)],
            ['Moments confirmés', `${bilan.confirmes} / ${CHRONOLOGIE.length}`],
            ['Étapes cochées', `${bilan.cochees} / ${bilan.etapes}`],
            ['Sous scellé', `${CHRONOLOGIE.filter((m) => m.scelle).length} moment(s)`],
          ] as Array<[string, string]>
        ).map(([l, v]) => (
          <div key={l} className="card-2 p-4">
            <p className="eyebrow mb-1.5">{l}</p>
            <p className="tnum text-[1.05rem] font-medium">{v}</p>
          </div>
        ))}
      </div>

      <ol className="relative space-y-3 pl-[4.6rem] sm:pl-[6.2rem]">
        <span
          className="absolute top-2 bottom-2 left-[3.4rem] w-px sm:left-[5rem]"
          style={{ background: 'var(--line)' }}
          aria-hidden
        />

        {CHRONOLOGIE.map((mo) => {
          const ro = R[mo.pilote]
          const c = teinte(ro, jour)
          const cat = CATEGORIES[mo.categorie]
          const etat = etatDe(mo)
          const rang = onde[mo.id]
          const est = ouvert === mo.id
          const masque = !!mo.scelle && !pareFeu
          const total = mo.etapes.length
          const faits = mo.etapes.filter((s) => faites[`${mo.id}.${s.id}`]).length

          return (
            <li key={mo.id} className="relative">
              <span
                className="absolute top-[1.35rem] -left-[1.25rem] text-[0.78rem] sm:-left-[1.3rem]"
                style={{ color: 'var(--ink-3)', transform: 'translateX(-100%)' }}
              >
                <span className="mono tnum">{mo.h}</span>
              </span>
              <span
                className={`cap absolute top-[1.45rem] -left-[1.22rem] h-[9px] w-[9px] rounded-full p-0 ${
                  rang === 1 ? 'echo' : rang === 2 ? 'echo echo-2' : ''
                }`}
                style={{ background: c, border: 'none', ['--tint' as string]: c }}
                aria-hidden
              />

              <div
                className={`card-2 p-4 transition-colors sm:p-5 ${rang ? 'echo' : ''}`}
                style={{
                  ['--tint' as string]: c,
                  borderColor: est ? `color-mix(in srgb, ${c} 46%, transparent)` : undefined,
                }}
              >
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <button
                    type="button"
                    onClick={() => choisir(mo)}
                    aria-expanded={est}
                    className="min-w-0 flex-1 text-left"
                  >
                    <p className="eyebrow mb-1" style={{ color: c }}>
                      {cat.l} · {ro?.court ?? mo.pilote}
                    </p>
                    <p className="text-[1.02rem] font-medium">{mo.titre}</p>
                    <p className="mt-1 text-[0.85rem]" style={{ color: 'var(--ink-2)' }}>
                      {masque ? 'Onde sous scellé — le pare-feu retient ce détail.' : mo.sous}
                    </p>
                    {mo.scelle && pareFeu && mo.vrai ? (
                      <p className="mt-1 text-[0.82rem]" style={{ color: 'var(--gold)' }}>
                        {mo.vrai}
                      </p>
                    ) : null}
                  </button>

                  <div className="flex shrink-0 flex-col items-end gap-1.5">
                    <button
                      type="button"
                      onClick={() =>
                        setEtats((v) => ({ ...v, [mo.id]: ETATS[etat].suivant }))
                      }
                      aria-label={`État : ${ETATS[etat].l} — changer`}
                    >
                      <Pastille etat={etat} />
                    </button>
                    {mo.budget ? (
                      <span className="tnum text-[0.78rem]" style={{ color: 'var(--ink-3)' }}>
                        {euros(mo.budget)}
                      </span>
                    ) : null}
                  </div>
                </div>

                <div className="mt-3 flex flex-wrap items-center gap-1.5">
                  {mo.ondes.map((rid) => (
                    <span
                      key={rid}
                      className="rounded-full border px-2 py-0.5 text-[0.7rem]"
                      style={{
                        borderColor: `color-mix(in srgb, ${teinte(R[rid], jour)} 38%, transparent)`,
                        color: 'var(--ink-2)',
                      }}
                    >
                      {R[rid]?.court ?? rid}
                    </span>
                  ))}
                  <span className="tnum ml-auto text-[0.72rem]" style={{ color: 'var(--ink-3)' }}>
                    {faits} / {total} étapes
                  </span>
                </div>

                {est ? (
                  <div className="mt-4 space-y-4 border-t pt-4" style={{ borderColor: 'var(--line)' }}>
                    <div className="grid gap-1.5 sm:grid-cols-2">
                      {mo.etapes.map((s) => {
                        const cle = `${mo.id}.${s.id}`
                        const ok = !!faites[cle]
                        return (
                          <button
                            key={cle}
                            type="button"
                            onClick={() => setFaites((v) => ({ ...v, [cle]: !ok }))}
                            className="flex items-center gap-2 rounded-xl px-2 py-1.5 text-left text-[0.83rem] transition-colors hover:bg-[var(--surface-hi)]"
                            aria-pressed={ok}
                          >
                            <span
                              className="grid h-4 w-4 shrink-0 place-items-center rounded-[5px] border text-[0.6rem]"
                              style={{
                                borderColor: ok ? c : 'var(--line-hi)',
                                background: ok ? c : 'transparent',
                                color: 'var(--bg)',
                              }}
                              aria-hidden
                            >
                              {ok ? '✓' : ''}
                            </span>
                            <span
                              style={{
                                color: ok ? 'var(--ink-3)' : 'var(--ink-2)',
                                textDecoration: ok ? 'line-through' : undefined,
                              }}
                            >
                              {s.l}
                            </span>
                          </button>
                        )
                      })}
                    </div>

                    <div>
                      <p className="eyebrow mb-2">L’onde de ce moment</p>
                      <Cascade
                        source={mo.pilote}
                        arcs={arcsDuMoment(mo)}
                        jour={jour}
                        pareFeu={pareFeu}
                      />
                    </div>

                    {onOuvrirClavier ? (
                      <button
                        type="button"
                        onClick={() => onOuvrirClavier(mo.pilote)}
                        className="lien text-[0.8rem]"
                        style={{ color: 'var(--ink-2)' }}
                      >
                        Ouvrir le clavier de {ro?.court ?? mo.pilote} →
                      </button>
                    ) : null}
                  </div>
                ) : null}
              </div>
            </li>
          )
        })}
      </ol>
    </div>
  )
}
