import type { WeddingConfig, WeddingEvent } from '@/lib/moteur-timeline'

export interface EtatAtelier {
  version: 1
  evenements: WeddingEvent[]
  config: WeddingConfig | null
  bulles: {
    id: string
    role: 'user' | 'agent'
    texte: string
    cartes?: string[]
    suggestion?: string
  }[]
  retenus: string[]
  ouvert: string | null
  enregistreLe: string
}

const CLE = 'aime-atelier-v1'

export function lireEtat(): EtatAtelier | null {
  if (typeof window === 'undefined') return null
  try {
    const brut = window.localStorage.getItem(CLE)
    if (!brut) return null
    const e = JSON.parse(brut) as EtatAtelier
    if (e?.version !== 1 || !Array.isArray(e.evenements) || !e.config) return null
    return e
  } catch {
    return null
  }
}

export function ecrireEtat(etat: Omit<EtatAtelier, 'version' | 'enregistreLe'>): void {
  if (typeof window === 'undefined') return
  try {
    const charge: EtatAtelier = {
      ...etat,
      version: 1,
      enregistreLe: new Date().toISOString(),
    }
    window.localStorage.setItem(CLE, JSON.stringify(charge))
  } catch {
    /* quota plein : on continue sans sauvegarde */
  }
}

export function effacerEtat(): void {
  if (typeof window === 'undefined') return
  try {
    window.localStorage.removeItem(CLE)
  } catch {
    /* ignore */
  }
}

export function dateLisible(iso: string): string {
  try {
    return new Date(iso).toLocaleString('fr-FR', {
      day: '2-digit',
      month: 'short',
      hour: '2-digit',
      minute: '2-digit',
    })
  } catch {
    return ''
  }
}
