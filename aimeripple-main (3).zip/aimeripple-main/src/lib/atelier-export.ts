import { jsPDF } from 'jspdf'
import {
  formatEuro,
  type WeddingAnalysis,
  type WeddingConfig,
  type WeddingEvent,
} from '@/lib/moteur-timeline'
import { LIBELLES_CATEGORIE, prestataireParId } from '@/data/prestataires'

const CATEGORIES: Record<string, string> = {
  ceremony: 'Cérémonie',
  reception: 'Réception',
  catering: 'Table',
  music: 'Musique',
  photo: 'Image',
  preparation: 'Préparatifs',
  transport: 'Transport',
  accommodation: 'Hébergement',
  other: 'Divers',
}

/** Nettoie les caractères que les polices standard du PDF ne portent pas. */
function ascii(t: string): string {
  return t
    .replace(/\u202f|\u00a0/g, ' ')
    .replace(/€/g, 'EUR')
    .replace(/[’‘]/g, "'")
    .replace(/[“”]/g, '"')
    .replace(/[–—]/g, '-')
}

export function resumeTexte(
  evenements: WeddingEvent[],
  config: WeddingConfig | null,
  analyse: WeddingAnalysis | null,
  retenus: string[],
): string {
  const l: string[] = []
  l.push('TIMELINE — atelier AIME® Ripple')
  if (config) {
    l.push(
      [
        config.weddingDate ?? 'date à préciser',
        `${config.guestCount} invités`,
        config.venue,
        config.style,
      ]
        .filter(Boolean)
        .join(' · '),
    )
  }
  l.push('')
  l.push('LE RAIL')
  for (const e of evenements) {
    l.push(
      `${e.time}  ${e.title} — ${CATEGORIES[e.category] ?? e.category}` +
        (e.budget ? ` · ${formatEuro(e.budget)}` : '') +
        (e.status === 'done' ? ' · confirmé' : ''),
    )
  }
  if (analyse) {
    l.push('')
    l.push('BUDGET')
    for (const b of analyse.budgetLines) {
      l.push(`${b.label} : ${formatEuro(b.amount)}${b.isEstimate ? ' (estimé)' : ''}`)
    }
    l.push(`Total : ${formatEuro(analyse.totalBudget)}`)
    l.push(`Tenue de la journée : ${analyse.score}%`)
    if (analyse.alerts.length) {
      l.push('')
      l.push('POINTS OUVERTS')
      for (const a of analyse.alerts) l.push(`- ${a.message}`)
    }
  }
  const cartes = retenus.map(prestataireParId).filter(Boolean)
  if (cartes.length) {
    l.push('')
    l.push('CARTES RETENUES')
    for (const p of cartes) {
      l.push(`- ${p!.nom} (${LIBELLES_CATEGORIE[p!.categorie]}, ${p!.lieu}) dès ${p!.aPartirDe}`)
    }
  }
  return l.join('\n')
}

export function exporterPdf(
  evenements: WeddingEvent[],
  config: WeddingConfig | null,
  analyse: WeddingAnalysis | null,
  retenus: string[],
): void {
  const doc = new jsPDF({ unit: 'pt', format: 'a4' })
  const M = 48
  const L = 595 - M * 2
  let y = M

  const saut = (h: number) => {
    if (y + h > 842 - M) {
      doc.addPage()
      y = M
    }
  }

  const titre = (t: string, taille = 18) => {
    saut(taille + 14)
    doc.setFont('helvetica', 'bold').setFontSize(taille).setTextColor(20)
    doc.text(ascii(t), M, y)
    y += taille + 8
  }

  const ligne = (t: string, options?: { gris?: boolean; gras?: boolean }) => {
    doc.setFont('helvetica', options?.gras ? 'bold' : 'normal').setFontSize(10)
    doc.setTextColor(options?.gris ? 130 : 40)
    const morceaux = doc.splitTextToSize(ascii(t), L) as string[]
    for (const m of morceaux) {
      saut(15)
      doc.text(m, M, y)
      y += 14
    }
  }

  const filet = () => {
    saut(16)
    doc.setDrawColor(215).line(M, y, M + L, y)
    y += 14
  }

  titre('Timeline du mariage', 22)
  if (config) {
    ligne(
      [
        config.weddingDate ?? 'date à préciser',
        `${config.guestCount} invités`,
        config.venue,
        config.style,
      ]
        .filter(Boolean)
        .join('  ·  '),
      { gris: true },
    )
  }
  filet()

  titre('Le rail', 14)
  for (const e of evenements) {
    saut(30)
    doc.setFont('helvetica', 'bold').setFontSize(10).setTextColor(30)
    doc.text(ascii(e.time), M, y)
    doc.text(ascii(e.title), M + 46, y)
    doc.setFont('helvetica', 'normal').setTextColor(130)
    const meta =
      (CATEGORIES[e.category] ?? e.category) +
      (e.budget ? ` · ${formatEuro(e.budget)}` : '') +
      (e.status === 'done' ? ' · confirmé' : ' · en attente')
    doc.text(ascii(meta), M + 46, y + 12)
    y += 28
  }
  filet()

  if (analyse) {
    titre('Budget', 14)
    for (const b of analyse.budgetLines) {
      saut(15)
      doc.setFont('helvetica', 'normal').setFontSize(10).setTextColor(40)
      doc.text(ascii(b.label + (b.isEstimate ? ' (estimé)' : '')), M, y)
      doc.text(ascii(formatEuro(b.amount)), M + L, y, { align: 'right' })
      y += 14
    }
    saut(20)
    doc.setFont('helvetica', 'bold').setTextColor(20)
    doc.text('Total', M, y)
    doc.text(ascii(formatEuro(analyse.totalBudget)), M + L, y, { align: 'right' })
    y += 20
    ligne(`Tenue de la journée : ${analyse.score}%`, { gris: true })

    if (analyse.alerts.length) {
      filet()
      titre('Points ouverts', 14)
      for (const a of analyse.alerts) ligne('• ' + a.message)
    }
  }

  const cartes = retenus.map(prestataireParId).filter(Boolean)
  if (cartes.length) {
    filet()
    titre('Cartes retenues', 14)
    for (const p of cartes) {
      ligne(`${p!.nom} — ${LIBELLES_CATEGORIE[p!.categorie]}`, { gras: true })
      ligne(`${p!.lieu} · dès ${p!.aPartirDe} · note ${p!.note.toFixed(1)}`, { gris: true })
    }
  }

  doc.save('timeline-mariage.pdf')
}
