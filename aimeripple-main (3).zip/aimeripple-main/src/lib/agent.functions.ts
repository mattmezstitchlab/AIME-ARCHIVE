import { createServerFn } from '@tanstack/react-start'
import { z } from 'zod'
import { PRESTATAIRES } from '@/data/prestataires'

const Entree = z.object({
  message: z.string().min(1),
  historique: z
    .array(z.object({ role: z.enum(['user', 'agent']), text: z.string() }))
    .default([]),
  evenements: z
    .array(
      z.object({
        id: z.string(),
        title: z.string(),
        time: z.string(),
        category: z.string(),
        status: z.string(),
      }),
    )
    .default([]),
  contexte: z
    .object({
      guestCount: z.number().optional(),
      venue: z.string().optional(),
      style: z.string().optional(),
      season: z.string().optional(),
      weddingDate: z.string().optional(),
    })
    .default({}),
})

export type ActionAgent =
  | { type: 'ajouter'; titre: string; heure: string; categorie: string; description?: string }
  | { type: 'deplacer'; id: string; heure: string }
  | { type: 'confirmer'; id: string }
  | { type: 'supprimer'; id: string }
  | { type: 'alerte'; gravite: 'critical' | 'warning' | 'info'; message: string }

export interface ReponseAgent {
  reponse: string
  impact?: string
  suggestion?: string
  relances?: string[]
  actions: ActionAgent[]
  prestataires: string[]
  horsLigne?: boolean
}

const CATALOGUE = PRESTATAIRES.map(
  (p) => `${p.id} — ${p.nom} (${p.categorie}, ${p.lieu}, dès ${p.aPartirDe})`,
).join('\n')

function systeme(evenements: unknown, contexte: unknown) {
  return `Tu es l'agent d'AIME® Ripple : un copilote d'organisation de mariage, sobre, concret, en français.
Tu parles court (deux à quatre phrases maximum), sans emphase commerciale, sans emoji.
Tu raisonnes sur une timeline d'événements et tu la modifies par des actions.

Timeline actuelle (JSON) :
${JSON.stringify(evenements)}

Contexte : ${JSON.stringify(contexte)}

Catalogue de prestataires disponibles (utilise EXACTEMENT ces identifiants) :
${CATALOGUE}

Réponds UNIQUEMENT par un objet JSON valide, sans texte autour, de la forme :
{
  "reponse": "ta réponse en français",
  "impact": "une phrase sur l'effet concret sur la journée (heures, budget, tenue), optionnelle",
  "suggestion": "une question de relance courte, optionnelle",
  "relances": ["deux ou trois questions ciblées que la personne peut te poser ensuite"],
  "actions": [
    {"type":"ajouter","titre":"...","heure":"HH:MM","categorie":"ceremony|reception|catering|music|photo|preparation|transport|accommodation|other","description":"..."},
    {"type":"deplacer","id":"<id existant>","heure":"HH:MM"},
    {"type":"confirmer","id":"<id existant>"},
    {"type":"supprimer","id":"<id existant>"},
    {"type":"alerte","gravite":"critical|warning|info","message":"..."}
  ],
  "prestataires": ["identifiants du catalogue à proposer en cartes"]
}
Règles : n'invente jamais d'identifiant d'événement ou de prestataire. Propose des cartes prestataires dès que la personne cherche, hésite ou compare un poste (lieu, photo, traiteur, musique, fleurs, tenue, beauté, transport, gâteau).
Quand tu proposes des cartes, commente-les toujours dans "reponse" : pourquoi celles-là, ce qui les distingue, et ce qu'elles changent sur l'heure et le budget si on les pose sur le rail.
Les "relances" doivent porter sur la journée telle qu'elle est (trous d'horaire, postes vides, budget, logistique), pas sur des généralités. Laisse "actions" vide si rien ne change.`
}

export const converserAvecAgent = createServerFn({ method: 'POST' })
  .inputValidator((d: unknown) => Entree.parse(d))
  .handler(async ({ data }): Promise<ReponseAgent> => {
    const cle = process.env.LOVABLE_API_KEY
    if (!cle) return { reponse: '', actions: [], prestataires: [], horsLigne: true }

    try {
      const res = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Lovable-API-Key': cle,
          'X-Lovable-AIG-SDK': 'fetch',
        },
        body: JSON.stringify({
          model: 'google/gemini-3.6-flash',
          response_format: { type: 'json_object' },
          messages: [
            { role: 'system', content: systeme(data.evenements, data.contexte) },
            ...data.historique.slice(-10).map((m) => ({
              role: m.role === 'user' ? 'user' : 'assistant',
              content: m.text,
            })),
            { role: 'user', content: data.message },
          ],
        }),
      })

      if (res.status === 429)
        return {
          reponse:
            'Trop de demandes coup sur coup — laissez passer une minute, la timeline reste intacte.',
          actions: [],
          prestataires: [],
        }
      if (res.status === 402)
        return {
          reponse:
            'Le crédit IA de l’atelier est épuisé. La timeline continue de fonctionner en mode hors-ligne.',
          actions: [],
          prestataires: [],
          horsLigne: true,
        }
      if (!res.ok) return { reponse: '', actions: [], prestataires: [], horsLigne: true }

      const json = (await res.json()) as {
        choices?: { message?: { content?: string } }[]
      }
      const brut = json.choices?.[0]?.message?.content ?? ''
      const nettoye = brut.replace(/^```(?:json)?/i, '').replace(/```$/, '').trim()
      const parsed = JSON.parse(nettoye) as Partial<ReponseAgent>

      const idsConnus = new Set(PRESTATAIRES.map((p) => p.id))
      const idsEvts = new Set(data.evenements.map((e) => e.id))

      const actions = (Array.isArray(parsed.actions) ? parsed.actions : []).filter((a) => {
        if (!a || typeof a !== 'object') return false
        if (a.type === 'ajouter') return Boolean(a.titre)
        if (a.type === 'alerte') return Boolean(a.message)
        return 'id' in a && idsEvts.has(a.id)
      })

      return {
        reponse: typeof parsed.reponse === 'string' ? parsed.reponse : '',
        impact: typeof parsed.impact === 'string' ? parsed.impact : undefined,
        suggestion: typeof parsed.suggestion === 'string' ? parsed.suggestion : undefined,
        relances: (Array.isArray(parsed.relances) ? parsed.relances : [])
          .filter((r): r is string => typeof r === 'string' && r.length > 0)
          .slice(0, 3),
        actions,
        prestataires: (Array.isArray(parsed.prestataires) ? parsed.prestataires : []).filter(
          (id): id is string => typeof id === 'string' && idsConnus.has(id),
        ),
      }
    } catch {
      return { reponse: '', actions: [], prestataires: [], horsLigne: true }
    }
  })
