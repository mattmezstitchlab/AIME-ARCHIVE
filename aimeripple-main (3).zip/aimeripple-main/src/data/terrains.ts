/**
 * Les terrains — la preuve que le principe causal ne tient pas au mariage.
 *
 * Chaque terrain rejoue le même objet : des rôles (un par touche), des gestes
 * (une touche = un dossier + une onde), un pare-feu, une mémoire. Seul le
 * vocabulaire change. C'est exactement la démonstration du manifeste.
 */

export interface RoleT {
  id: string
  nom: string
  court: string
  /** teinte nuit */
  c: string
  /** teinte jour */
  cJour: string
}

export interface OndeT {
  r: string
  t: string
  /** onde masquée par le pare-feu */
  lock?: boolean
  vrai?: string
  puis?: Array<{ r: string; t: string }>
}

export interface GesteT {
  /** la touche */
  k: string
  /** le rôle qui la presse */
  roleId: string
  label: string
  scn: string
  faits: Array<[string, string]>
  ondes: OndeT[]
  actes: [string, string, string]
}

export interface Terrain {
  id: string
  nom: string
  /** la phrase du manifeste */
  d: string
  /** la mécanique transposée */
  m: string
  /** ce que remplace le clavier */
  avant: string
  contexte: string
  feu: string
  roles: RoleT[]
  gestes: GesteT[]
  preuve: Array<{ l: string; avant: string; apres: string }>
}

export const TERRAINS: Terrain[] = [
  /* ----------------------------------------------------------------- */
  {
    id: 'chantier',
    nom: 'Chantier',
    d: 'Le maçon décale de deux jours : l’électricien, le plaquiste et le maître d’ouvrage se recalent seuls.',
    m: 'rôles → corps d’état',
    avant: 'Onze appels, un groupe WhatsApp, un planning papier périmé le lendemain.',
    contexte:
      'Réhabilitation, 340 m², six corps d’état, un seul escalier. Le gros œuvre glisse — tout le reste tient à lui.',
    feu: 'Le prix d’achat des lots reste scellé : les compagnons voient les dates, jamais les marges.',
    roles: [
      { id: 'macon', nom: 'Maçonnerie · gros œuvre', court: 'Maçon', c: '#C9A87C', cJour: '#7A5A2E' },
      { id: 'elec', nom: 'Électricité · courants forts', court: 'Élec', c: '#FFD44D', cJour: '#8A6C00' },
      { id: 'plaque', nom: 'Plâtrerie · plaquiste', court: 'Plaquiste', c: '#9BC7E0', cJour: '#2F6386' },
      { id: 'plomb', nom: 'Plomberie · CVC', court: 'Plombier', c: '#5FC7B8', cJour: '#2F6E66' },
      { id: 'mo', nom: 'Maître d’ouvrage', court: 'MOA', c: '#FF8A63', cJour: '#B0442A' },
      { id: 'conduite', nom: 'Conduite de travaux', court: 'Conduite', c: '#B39CFF', cJour: '#5F3FD1' },
    ],
    gestes: [
      {
        k: 'D',
        roleId: 'macon',
        label: 'Décaler de deux jours',
        scn: 'Le coulage de la dalle glisse de deux jours : béton reporté, séchage repoussé, tous les lots aval se recalent d’eux-mêmes.',
        faits: [
          ['Lot', 'Dalle R+1 — 96 m²'],
          ['Cause', 'Camion toupie indisponible'],
          ['Glissement', '+2 jours ouvrés'],
          ['Séchage', '21 jours incompressibles'],
        ],
        ondes: [
          {
            r: 'elec',
            t: 'Saignées repoussées au 14 — équipe replacée sur le lot B',
            puis: [{ r: 'conduite', t: 'Une semaine d’intérim annulée à temps' }],
          },
          { r: 'plaque', t: 'Livraison de plaques décalée, pas de stockage sous la pluie' },
          { r: 'plomb', t: 'Percements attendent le séchage — aucun perçage à sec' },
          { r: 'mo', t: 'Réception repoussée au 3 — courrier automatique, pas d’appel' },
          { r: 'conduite', t: 'Chemin critique recalculé : +2 jours, pas +9', lock: true, vrai: 'Pénalité de retard évitée : 4 200 €' },
        ],
        actes: ['Décaler le lot', 'Attendre le confirmé toupie', 'Emporter l’avis de glissement'],
      },
      {
        k: 'R',
        roleId: 'conduite',
        label: 'Réserve levée',
        scn: 'Une réserve de la visite hebdo est levée : la photo, la date et l’auteur restent dans la mémoire.',
        faits: [
          ['Réserve', 'Attente maçonnerie — trémie gaine'],
          ['Ouverte le', '11 mai · levée ce jour'],
          ['Pièces', '2 photos horodatées'],
        ],
        ondes: [
          { r: 'macon', t: 'Sortie de la liste des blocages' },
          { r: 'elec', t: 'Gaine passable dès demain' },
          { r: 'mo', t: 'Compteur de réserves : 7 → 6' },
        ],
        actes: ['Lever la réserve', 'Reporter à la visite du 18', 'Emporter le PV'],
      },
      {
        k: 'L',
        roleId: 'mo',
        label: 'Livraison arbitrée',
        scn: 'Le maître d’ouvrage tranche : carrelage grand format plutôt que parquet. Le geste descend jusqu’au calepinage.',
        faits: [
          ['Arbitrage', 'Carrelage 120×60'],
          ['Délai fournisseur', '4 semaines'],
          ['Impact planning', '+3 jours sur le lot finitions'],
        ],
        ondes: [
          { r: 'plaque', t: 'Cloisons montées avant pose, pas après' },
          { r: 'conduite', t: 'Commande passée le jour même' },
          { r: 'plomb', t: 'Siphons de sol replacés au calepinage' },
        ],
        actes: ['Valider l’arbitrage', 'Reporter à la réunion de chantier', 'Emporter la fiche'],
      },
      {
        k: 'I',
        roleId: 'elec',
        label: 'Intempérie',
        scn: 'Arrêt intempérie déclaré à 11 h : la journée est neutralisée pour les lots extérieurs, pas pour les autres.',
        faits: [
          ['Déclaré', '11 h 05'],
          ['Lots concernés', 'Extérieur uniquement'],
          ['Heures', '5 h × 4 compagnons'],
        ],
        ondes: [
          { r: 'macon', t: 'Repli — reprise demain 7 h' },
          { r: 'plaque', t: 'Bascule sur l’intérieur, journée sauvée' },
          { r: 'conduite', t: 'Déclaration caisse intempéries pré-remplie', lock: true },
        ],
        actes: ['Déclarer l’arrêt', 'Attendre 13 h', 'Emporter le relevé'],
      },
    ],
    preuve: [
      { l: 'Appels passés pour un décalage', avant: '11', apres: '0' },
      { l: 'Délai de recalage des lots aval', avant: '2 jours', apres: '4 minutes' },
      { l: 'Version du planning qui fait foi', avant: '3 en circulation', apres: '1' },
    ],
  },

  /* ----------------------------------------------------------------- */
  {
    id: 'hopital',
    nom: 'Hôpital de jour',
    d: 'Un bloc glisse de quarante minutes : brancardage, anesthésie, famille prévenue — sans standard saturé.',
    m: 'pare-feu → secret médical',
    avant: 'Un standard saturé, trois bips, une famille qui attend sans nouvelle.',
    contexte:
      'Ambulatoire, quatre salles, dix-neuf patients programmés. Une intervention déborde : tout l’après-midi respire différemment.',
    feu: 'Le pare-feu est ici le secret médical : l’onde circule, le motif jamais. Le brancardage lit une heure, pas un diagnostic.',
    roles: [
      { id: 'bloc', nom: 'Bloc opératoire', court: 'Bloc', c: '#7FB6EA', cJour: '#2F63A0' },
      { id: 'anesth', nom: 'Anesthésie', court: 'Anesth', c: '#B39CFF', cJour: '#5F3FD1' },
      { id: 'brancard', nom: 'Brancardage', court: 'Brancard', c: '#AEBD87', cJour: '#535E2C' },
      { id: 'ide', nom: 'Soins · IDE', court: 'IDE', c: '#5FC7B8', cJour: '#2F6E66' },
      { id: 'famille', nom: 'Famille · accompagnant', court: 'Famille', c: '#C99A72', cJour: '#8C5F3E' },
      { id: 'cadre', nom: 'Cadre de santé', court: 'Cadre', c: '#FFD44D', cJour: '#8A6C00' },
    ],
    gestes: [
      {
        k: 'G',
        roleId: 'bloc',
        label: 'Glissement de programme',
        scn: 'La salle 2 déborde de quarante minutes. L’onde part une fois, atteint cinq postes, et n’en réveille aucun de plus.',
        faits: [
          ['Salle', '2 — ambulatoire'],
          ['Glissement', '+40 min'],
          ['Patients aval', '3'],
          ['Standard', 'aucun appel émis'],
        ],
        ondes: [
          {
            r: 'brancard',
            t: 'Descente repoussée à 14 h 40 — pas de patient sur un couloir',
            puis: [{ r: 'ide', t: 'Prémédication décalée d’autant' }],
          },
          { r: 'anesth', t: 'Consultation pré-op replacée, jeûne recalculé' },
          { r: 'famille', t: 'SMS : « intervention vers 15 h, tout va bien »' },
          { r: 'cadre', t: 'Fin de vacation estimée 18 h 10 — relève prévenue' },
          { r: 'ide', t: 'Motif du dépassement', lock: true, vrai: 'Conversion cœlio → laparo, patient stable' },
        ],
        actes: ['Propager le glissement', 'Attendre la fin d’intervention', 'Emporter l’avis de salle'],
      },
      {
        k: 'S',
        roleId: 'ide',
        label: 'Sortie autorisée',
        scn: 'Score de sortie atteint : le patient part, la place se libère, l’aval le sait avant de le demander.',
        faits: [
          ['Score', 'Chung 10/10'],
          ['Accompagnant', 'présent'],
          ['Place libérée', 'box 4'],
        ],
        ondes: [
          { r: 'brancard', t: 'Un transfert de moins à programmer' },
          { r: 'cadre', t: 'Taux d’occupation ambulatoire : 82 %' },
          { r: 'famille', t: 'Consignes de sortie envoyées, appel J+1 planifié' },
        ],
        actes: ['Autoriser la sortie', 'Réévaluer dans 30 min', 'Emporter la fiche de sortie'],
      },
      {
        k: 'J',
        roleId: 'anesth',
        label: 'Jeûne recalculé',
        scn: 'Le jeûne est recalculé sur l’heure réelle, pas sur l’heure théorique : le patient boit, l’attente cesse d’être une punition.',
        faits: [
          ['Liquides clairs', 'jusqu’à 13 h'],
          ['Solides', 'depuis minuit'],
          ['Patients concernés', '3'],
        ],
        ondes: [
          { r: 'ide', t: 'Verre d’eau autorisé, tracé au dossier' },
          { r: 'famille', t: 'Information donnée une fois, sans appel' },
          { r: 'bloc', t: 'Aucun report pour non-respect du jeûne' },
        ],
        actes: ['Appliquer le nouveau jeûne', 'Reporter la décision', 'Emporter la consigne'],
      },
      {
        k: 'A',
        roleId: 'cadre',
        label: 'Appel d’effectif',
        scn: 'Une IDE manque à 16 h. Le geste cherche l’effectif disponible avant de sonner qui que ce soit.',
        faits: [
          ['Besoin', '1 IDE · 16 h – 19 h'],
          ['Disponibles', '2 sur pool'],
          ['Délai', '12 min'],
        ],
        ondes: [
          { r: 'ide', t: 'Renfort identifié, une seule sollicitation' },
          { r: 'bloc', t: 'Dernière intervention maintenue' },
          { r: 'brancard', t: 'Aucun changement — l’onde ne les touche pas' },
        ],
        actes: ['Lancer l’appel', 'Attendre 15 min', 'Emporter la demande'],
      },
    ],
    preuve: [
      { l: 'Appels au standard pour un glissement', avant: '14', apres: '0' },
      { l: 'Familles prévenues', avant: '1 sur 3', apres: '3 sur 3' },
      { l: 'Données médicales diffusées', avant: 'par oral, partout', apres: 'sous pare-feu' },
    ],
  },

  /* ----------------------------------------------------------------- */
  {
    id: 'tournage',
    nom: 'Tournage',
    d: 'La lumière tombe : la feuille de service se replie, la régie et la cantine suivent l’onde.',
    m: 'golden hour → même touche',
    avant: 'Une feuille de service refaite à la main, imprimée trois fois, fausse à 18 h.',
    contexte:
      'Extérieur jour, 34 techniciens, deux séquences restantes. Le soleil ne négocie pas : la feuille de service, si.',
    feu: 'Le budget dépassement et les cachets restent scellés : l’équipe voit l’heure, pas la ligne comptable.',
    roles: [
      { id: 'real', nom: 'Réalisation', court: 'Réal', c: '#EFE9DC', cJour: '#6E6347' },
      { id: 'image', nom: 'Chef opérateur · image', court: 'Image', c: '#7FB6EA', cJour: '#2F63A0' },
      { id: 'regie', nom: 'Régie générale', court: 'Régie', c: '#FFD44D', cJour: '#8A6C00' },
      { id: 'cantine', nom: 'Cantine · HMC', court: 'Cantine', c: '#FF8A63', cJour: '#B0442A' },
      { id: 'prod', nom: 'Production', court: 'Prod', c: '#B39CFF', cJour: '#5F3FD1' },
      { id: 'comedien', nom: 'Comédiens', court: 'Casting', c: '#EE97C6', cJour: '#8E4A78' },
    ],
    gestes: [
      {
        k: 'H',
        roleId: 'image',
        label: 'Golden hour',
        scn: 'Coucher à 19 h 42 : sept minutes de miel. La séquence 24 passe devant, tout le reste se replie derrière la même touche.',
        faits: [
          ['Coucher', '19 h 42'],
          ['Fenêtre utile', '19 h 35 – 19 h 49'],
          ['Séquences restantes', '2'],
          ['Plan de repli', 'séq. 26 en intérieur'],
        ],
        ondes: [
          {
            r: 'real',
            t: 'Ordre des séquences inversé — 24 avant 26',
            puis: [{ r: 'comedien', t: 'Deux comédiens appelés 40 min plus tôt' }],
          },
          { r: 'regie', t: 'Groupe électrogène et HMI repositionnés côté ouest' },
          { r: 'cantine', t: 'Pause repas glissée à 20 h 15 — 34 couverts maintenus' },
          { r: 'prod', t: 'Dépassement estimé', lock: true, vrai: '1 h 10 × 34 — arbitrage prod requis' },
        ],
        actes: ['Replier la feuille', 'Attendre la météo de 17 h', 'Emporter la feuille du jour'],
      },
      {
        k: 'M',
        roleId: 'regie',
        label: 'Météo tournante',
        scn: 'Averse annoncée à 15 h : la régie déclenche le plan B avant que la première goutte ne tombe.',
        faits: [
          ['Averse', '15 h – 15 h 40'],
          ['Décor de repli', 'hangar B'],
          ['Temps de bascule', '25 min'],
        ],
        ondes: [
          { r: 'image', t: 'Lumière intérieure prête avant l’averse' },
          { r: 'real', t: 'Séquence dialoguée avancée' },
          { r: 'cantine', t: 'Café chaud au lieu du service froid' },
        ],
        actes: ['Déclencher le plan B', 'Attendre le radar', 'Emporter la consigne'],
      },
      {
        k: 'C',
        roleId: 'cantine',
        label: 'Couverts recomptés',
        scn: 'Douze figurants confirment : les couverts, les régimes et les heures de service bougent d’un seul geste.',
        faits: [
          ['Couverts', '34 → 46'],
          ['Régimes', '3 végétariens · 1 sans gluten'],
          ['Service', '20 h 15'],
        ],
        ondes: [
          { r: 'prod', t: 'Bon de commande traiteur mis à jour' },
          { r: 'regie', t: 'Tables et barnum : +1 module' },
          { r: 'comedien', t: 'Aucun changement d’appel' },
        ],
        actes: ['Confirmer 46 couverts', 'Reporter à 16 h', 'Emporter le bon'],
      },
      {
        k: 'F',
        roleId: 'real',
        label: 'Feuille de service',
        scn: 'La feuille de service du lendemain se ferme : une seule version, envoyée une seule fois.',
        faits: [
          ['Jour', 'J+1 — extérieur nuit'],
          ['Appel équipe', '16 h 00'],
          ['Séquences', '4'],
        ],
        ondes: [
          { r: 'regie', t: 'Transports et loges calés sur l’appel' },
          { r: 'comedien', t: 'Convocations individuelles, pas de liste diffusée' },
          { r: 'cantine', t: 'Repas nuit programmé' },
          { r: 'prod', t: 'Feuille archivée, horodatée' },
        ],
        actes: ['Diffuser la feuille', 'Attendre l’aval prod', 'Emporter le PDF'],
      },
    ],
    preuve: [
      { l: 'Versions de la feuille de service', avant: '3 par jour', apres: '1' },
      { l: 'Délai entre décision et équipe informée', avant: '35 min', apres: 'immédiat' },
      { l: 'Repas commandés en trop', avant: '12', apres: '0' },
    ],
  },

  /* ----------------------------------------------------------------- */
  {
    id: 'festival',
    nom: 'Festival',
    d: 'Quatre scènes, cent bénévoles, un seul clavier par poste. Chacun voit ses touches, pas celles des autres.',
    m: 'profils → postes',
    avant: 'Un talkie saturé, un tableau blanc en loge, cent bénévoles qui demandent « et moi ? ».',
    contexte:
      'Trois jours, quatre scènes, 12 000 personnes. Le clavier d’un bénévole barrière n’est pas celui d’un régisseur plateau — c’est le même objet, taillé au poste.',
    feu: 'Le pare-feu est un profil : la loge artiste et la billetterie ne partagent rien, sauf l’heure.',
    roles: [
      { id: 'plateau', nom: 'Régie plateau', court: 'Plateau', c: '#FFD44D', cJour: '#8A6C00' },
      { id: 'benevoles', nom: 'Coordination bénévoles', court: 'Bénévoles', c: '#8FD48C', cJour: '#3F7A3A' },
      { id: 'securite', nom: 'Sécurité · flux', court: 'Sécurité', c: '#FF8A63', cJour: '#B0442A' },
      { id: 'artiste', nom: 'Accueil artistes', court: 'Artistes', c: '#EE97C6', cJour: '#8E4A78' },
      { id: 'billetterie', nom: 'Billetterie', court: 'Billet', c: '#9BAAC9', cJour: '#454F68' },
      { id: 'technique', nom: 'Technique · son', court: 'Technique', c: '#B39CFF', cJour: '#5F3FD1' },
    ],
    gestes: [
      {
        k: 'B',
        roleId: 'plateau',
        label: 'Balances décalées',
        scn: 'Le groupe de 18 h arrive en retard : les balances glissent de 25 minutes sur la scène 2, et sur elle seule.',
        faits: [
          ['Scène', '2 — La Grange'],
          ['Glissement', '+25 min'],
          ['Scènes touchées', '1 sur 4'],
        ],
        ondes: [
          {
            r: 'technique',
            t: 'Patch et line-check repoussés — équipe non mobilisée pour rien',
            puis: [{ r: 'benevoles', t: 'Deux bénévoles réaffectés à la scène 3' }],
          },
          { r: 'artiste', t: 'Catering et loge décalés du même quart d’heure' },
          { r: 'securite', t: 'Ouverture du pit maintenue — aucune consigne inutile' },
        ],
        actes: ['Décaler les balances', 'Attendre l’arrivée du tour bus', 'Emporter le run-sheet'],
      },
      {
        k: 'A',
        roleId: 'benevoles',
        label: 'Affectation d’un poste',
        scn: 'Un poste barrière se libère : le geste cherche un bénévole disponible, formé, et pas déjà en service depuis six heures.',
        faits: [
          ['Poste', 'Barrière scène 1 · 21 h – 23 h'],
          ['Éligibles', '7'],
          ['Repos minimum', '4 h respecté'],
        ],
        ondes: [
          { r: 'securite', t: 'Effectif barrière complet avant l’ouverture du pit' },
          { r: 'plateau', t: 'Aucun retard de lever de rideau' },
          { r: 'billetterie', t: 'Non concernée — l’onde s’arrête là' },
        ],
        actes: ['Affecter le poste', 'Reporter à 20 h', 'Emporter la feuille de poste'],
      },
      {
        k: 'J',
        roleId: 'securite',
        label: 'Jauge atteinte',
        scn: 'La scène 3 atteint 92 % de jauge : le flux se régule avant la saturation, pas après.',
        faits: [
          ['Jauge', '2 300'],
          ['Occupation', '92 %'],
          ['Entrées/min', '48'],
        ],
        ondes: [
          { r: 'benevoles', t: 'Filtrage doux en amont, deux postes renforcés' },
          { r: 'billetterie', t: 'Rebasculage vers la scène 4 annoncé' },
          { r: 'plateau', t: 'Lever maintenu' },
        ],
        actes: ['Réguler le flux', 'Réévaluer dans 10 min', 'Emporter le relevé'],
      },
      {
        k: 'L',
        roleId: 'artiste',
        label: 'Loge et rider',
        scn: 'Le rider est confirmé : loge, catering, transferts. Les bénévoles voient une tâche, pas le rider.',
        faits: [
          ['Groupe', 'Scène 2 · 20 h 30'],
          ['Personnes', '9'],
          ['Transferts', '2 véhicules'],
        ],
        ondes: [
          { r: 'benevoles', t: 'Deux missions catering créées' },
          { r: 'securite', t: 'Deux badges accès backstage' },
          { r: 'plateau', t: 'Détail du rider', lock: true, vrai: 'Clauses contractuelles — accueil artistes uniquement' },
        ],
        actes: ['Confirmer le rider', 'Attendre le tourneur', 'Emporter la fiche loge'],
      },
    ],
    preuve: [
      { l: 'Messages talkie par changement', avant: '~30', apres: '1 touche' },
      { l: 'Bénévoles sollicités inutilement', avant: '40', apres: '2' },
      { l: 'Information vue par poste', avant: 'tout', apres: 'ce qui le concerne' },
    ],
  },

  /* ----------------------------------------------------------------- */
  {
    id: 'demenagement',
    nom: 'Déménagement d’entreprise',
    d: 'Un étage bascule : informatique, standard, courrier et sécurité se déplacent en une passe.',
    m: 'couches → sites',
    avant: 'Un tableur à onglets, quatre prestataires, un lundi matin sans téléphone.',
    contexte:
      '420 postes, trois sites, une bascule par étage sur six week-ends. Chaque étage est une couche du clavier.',
    feu: 'Les données RH — qui déménage, avec qui, à quel bureau — restent scellées hors de la DRH.',
    roles: [
      { id: 'it', nom: 'Informatique · postes', court: 'IT', c: '#7FB6EA', cJour: '#2F63A0' },
      { id: 'telecom', nom: 'Standard · téléphonie', court: 'Standard', c: '#FFD44D', cJour: '#8A6C00' },
      { id: 'courrier', nom: 'Courrier · logistique', court: 'Courrier', c: '#C99A72', cJour: '#8C5F3E' },
      { id: 'secu', nom: 'Sécurité · badges', court: 'Sécurité', c: '#FF8A63', cJour: '#B0442A' },
      { id: 'rh', nom: 'RH · affectations', court: 'RH', c: '#EE97C6', cJour: '#8E4A78' },
      { id: 'moyens', nom: 'Services généraux', court: 'Moyens', c: '#5FC7B8', cJour: '#2F6E66' },
    ],
    gestes: [
      {
        k: 'E',
        roleId: 'moyens',
        label: 'Étage basculé',
        scn: 'Le 4e étage bascule vers le site Nord : 68 postes, un week-end, une seule passe.',
        faits: [
          ['Étage', '4e — 68 postes'],
          ['Fenêtre', 'vendredi 18 h – lundi 7 h'],
          ['Site cible', 'Nord · niveau 2'],
        ],
        ondes: [
          {
            r: 'it',
            t: '68 postes ré-adressés, VLAN basculé, imprimantes suivies',
            puis: [{ r: 'telecom', t: 'Numéros portés sur les nouveaux ports' }],
          },
          { r: 'courrier', t: 'Tournée réécrite : le 4e sort, le Nord entre' },
          { r: 'secu', t: 'Badges reprogrammés — accès ancien étage coupé lundi 7 h' },
          { r: 'rh', t: 'Plan d’occupation nominatif', lock: true, vrai: 'Affectations individuelles — DRH uniquement' },
        ],
        actes: ['Basculer l’étage', 'Reporter au week-end suivant', 'Emporter l’ordre de bascule'],
      },
      {
        k: 'P',
        roleId: 'it',
        label: 'Poste hors service',
        scn: 'Un poste ne redémarre pas au nouveau site : le geste ouvre le dossier, pas un ticket de plus.',
        faits: [
          ['Poste', 'N2-114'],
          ['Symptôme', 'pas de lien réseau'],
          ['Impact', '1 utilisateur'],
        ],
        ondes: [
          { r: 'moyens', t: 'Prise murale à recâbler — intervention à 9 h' },
          { r: 'telecom', t: 'Softphone rebasculé sur mobile en attendant' },
          { r: 'secu', t: 'Non concernée' },
        ],
        actes: ['Ouvrir l’intervention', 'Reporter à demain', 'Emporter le constat'],
      },
      {
        k: 'C',
        roleId: 'courrier',
        label: 'Courrier réacheminé',
        scn: 'Le courrier du 4e part maintenant au Nord : une règle, pas cent post-it.',
        faits: [
          ['Volume', '~180 plis/jour'],
          ['Bascule', 'lundi 7 h'],
          ['Recommandés', 'main propre, site Nord'],
        ],
        ondes: [
          { r: 'moyens', t: 'Casiers réétiquetés avant l’arrivée' },
          { r: 'secu', t: 'Accès coursier au niveau 2 ouvert' },
          { r: 'rh', t: 'Aucune donnée nominative transmise' },
        ],
        actes: ['Appliquer la règle', 'Reporter d’un jour', 'Emporter la consigne'],
      },
      {
        k: 'B',
        roleId: 'secu',
        label: 'Badges du lundi',
        scn: 'Les droits d’accès basculent à l’heure exacte du premier café, pas la veille au soir.',
        faits: [
          ['Badges', '68'],
          ['Bascule', 'lundi 07 h 00'],
          ['Anciens accès', 'coupés à 07 h 01'],
        ],
        ondes: [
          { r: 'it', t: 'SSO aligné sur les nouveaux groupes' },
          { r: 'moyens', t: 'Accueil prévenu, aucun attroupement au tourniquet' },
          { r: 'courrier', t: 'Coursier badgé sur le bon niveau' },
        ],
        actes: ['Programmer la bascule', 'Attendre validation RH', 'Emporter la liste'],
      },
    ],
    preuve: [
      { l: 'Onglets de tableur à tenir', avant: '9', apres: '0' },
      { l: 'Postes sans téléphone le lundi', avant: '23', apres: '1' },
      { l: 'Prestataires à rappeler', avant: '4', apres: '0' },
    ],
  },

  /* ----------------------------------------------------------------- */
  {
    id: 'obseques',
    nom: 'Obsèques',
    d: 'Le cas le plus dur : peu de temps, beaucoup de pudeur. Une touche vaut mieux que dix appels.',
    m: 'le silence, aussi, est causal',
    avant: 'Dix appels en deux jours, à des gens qui n’ont pas la force de répondre au téléphone.',
    contexte:
      'Six jours entre l’annonce et la cérémonie. Chaque geste doit être court, et chaque onde doit épargner la famille.',
    feu: 'Ici le pare-feu protège la famille : les questions matérielles se règlent entre professionnels, elle ne voit que ce qui lui revient.',
    roles: [
      { id: 'famille', nom: 'Famille proche', court: 'Famille', c: '#C99A72', cJour: '#8C5F3E' },
      { id: 'pompes', nom: 'Opérateur funéraire', court: 'Opérateur', c: '#9BAAC9', cJour: '#454F68' },
      { id: 'lieu', nom: 'Lieu de recueillement', court: 'Lieu', c: '#5FC7B8', cJour: '#2F6E66' },
      { id: 'officiant', nom: 'Célébrant', court: 'Célébrant', c: '#EFE9DC', cJour: '#6E6347' },
      { id: 'mairie', nom: 'État civil · démarches', court: 'État civil', c: '#AEBD87', cJour: '#535E2C' },
      { id: 'proches', nom: 'Proches à prévenir', court: 'Proches', c: '#EE97C6', cJour: '#8E4A78' },
    ],
    gestes: [
      {
        k: 'H',
        roleId: 'pompes',
        label: 'Heure fixée',
        scn: 'La cérémonie est fixée : jeudi 14 h 30. Une touche, et personne n’a à rappeler la famille pour vérifier.',
        faits: [
          ['Cérémonie', 'jeudi 14 h 30'],
          ['Lieu', 'salle de recueillement'],
          ['Durée', '45 min'],
          ['Appels évités', '10'],
        ],
        ondes: [
          {
            r: 'proches',
            t: 'Faire-part envoyé une fois, sans réponse attendue',
            puis: [{ r: 'lieu', t: 'Nombre de places ajusté au fil des réponses' }],
          },
          { r: 'officiant', t: 'Trame de cérémonie ouverte, textes à relire' },
          { r: 'lieu', t: 'Salle réservée, accès PMR confirmé' },
          { r: 'famille', t: 'Une seule chose à faire aujourd’hui : rien' },
          { r: 'mairie', t: 'Démarches administratives', lock: true, vrai: 'Autorisation d’inhumation — opérateur et mairie' },
        ],
        actes: ['Fixer l’heure', 'Attendre l’accord de la famille', 'Emporter l’annonce'],
      },
      {
        k: 'T',
        roleId: 'officiant',
        label: 'Textes et musique',
        scn: 'Trois textes, deux musiques. Le geste les rassemble sans demander dix fois la même chose.',
        faits: [
          ['Textes', '3 · dont 1 lu par un petit-fils'],
          ['Musiques', '2'],
          ['Relecture', 'mercredi 18 h'],
        ],
        ondes: [
          { r: 'lieu', t: 'Sonorisation prévue, essai à 14 h' },
          { r: 'famille', t: 'Une question posée, une seule fois' },
          { r: 'proches', t: 'Le lecteur est prévenu, personne d’autre' },
        ],
        actes: ['Arrêter la trame', 'Reporter à mercredi', 'Emporter la trame'],
      },
      {
        k: 'D',
        roleId: 'mairie',
        label: 'Démarches',
        scn: 'Les pièces administratives avancent entre professionnels. La famille voit un état, pas un formulaire.',
        faits: [
          ['Pièces', '4 sur 5 réunies'],
          ['Délai légal', 'respecté'],
          ['À signer', '1'],
        ],
        ondes: [
          { r: 'pompes', t: 'Dernière pièce demandée directement au médecin' },
          { r: 'famille', t: 'État : « en cours, rien à faire »' },
          { r: 'lieu', t: 'Créneau sécurisé' },
        ],
        actes: ['Transmettre les pièces', 'Attendre la signature', 'Emporter le récapitulatif'],
      },
      {
        k: 'S',
        roleId: 'famille',
        label: 'Silence demandé',
        scn: 'La famille demande le silence jusqu’à demain. L’onde la plus importante est celle qui n’arrive pas.',
        faits: [
          ['Silence', 'jusqu’à demain 10 h'],
          ['Notifications', 'suspendues'],
          ['Urgences', 'opérateur uniquement'],
        ],
        ondes: [
          { r: 'pompes', t: 'Devient le seul interlocuteur' },
          { r: 'proches', t: 'Aucun message ne partira — c’est voulu' },
          { r: 'officiant', t: 'Relecture décalée sans avoir à le demander' },
        ],
        actes: ['Demander le silence', 'Réévaluer demain', 'Emporter la consigne'],
      },
    ],
    preuve: [
      { l: 'Appels reçus par la famille', avant: '10+', apres: '1' },
      { l: 'Fois où il faut redire la même chose', avant: '6', apres: '1' },
      { l: 'Décisions à prendre le premier jour', avant: '12', apres: '2' },
    ],
  },
]

export const TERRAIN: Record<string, Terrain> = Object.fromEntries(
  TERRAINS.map((t) => [t.id, t]),
)
