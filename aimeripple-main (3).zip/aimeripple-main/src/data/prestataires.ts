import type { EventCategory } from '@/lib/moteur-timeline'

export type CategoriePrestataire =
  | 'venue'
  | 'planner'
  | 'photo'
  | 'catering'
  | 'music'
  | 'dj'
  | 'flowers'
  | 'dress'
  | 'beauty'
  | 'decor'
  | 'cake'
  | 'transport'

export interface Prestataire {
  id: string
  nom: string
  categorie: CategoriePrestataire
  lieu: string
  description: string
  aPartirDe: string
  budget: number
  note: number
  etiquettes: string[]
  disponible: boolean
  motsCles: string[]
}

export const LIBELLES_CATEGORIE: Record<CategoriePrestataire, string> = {
  venue: 'Lieu',
  planner: 'Coordination',
  photo: 'Photographe',
  catering: 'Traiteur',
  music: 'Musicien',
  dj: 'DJ',
  flowers: 'Fleuriste',
  dress: 'Tenue',
  beauty: 'Beauté',
  decor: 'Décoration',
  cake: 'Pâtisserie',
  transport: 'Transport',
}

/** Catégorie de la timeline dans laquelle tombe un prestataire. */
export function categorieTimeline(c: CategoriePrestataire): EventCategory {
  switch (c) {
    case 'photo':
      return 'photo'
    case 'catering':
    case 'cake':
      return 'catering'
    case 'music':
    case 'dj':
      return 'music'
    case 'transport':
      return 'transport'
    case 'venue':
    case 'flowers':
    case 'decor':
      return 'reception'
    case 'dress':
    case 'beauty':
      return 'preparation'
    default:
      return 'other'
  }
}

/** Heure par défaut proposée quand on pose un prestataire sur le rail. */
export function heureSuggeree(c: CategoriePrestataire): string {
  switch (c) {
    case 'beauty':
    case 'dress':
      return '10:00'
    case 'flowers':
    case 'decor':
      return '11:00'
    case 'photo':
      return '14:00'
    case 'venue':
      return '15:00'
    case 'music':
      return '16:30'
    case 'dj':
      return '22:00'
    case 'catering':
      return '19:30'
    case 'cake':
      return '21:00'
    case 'transport':
      return '23:30'
    default:
      return '18:00'
  }
}

export const PRESTATAIRES: Prestataire[] = [
  {
    id: 'domaine-des-lys',
    nom: 'Domaine des Lys',
    categorie: 'venue',
    lieu: 'Hauts-de-France',
    description:
      'Salle principale, jardin clos et espace cérémonie extérieure. Cent quarante couverts, nuit sur place possible.',
    aPartirDe: '3 500 €',
    budget: 3500,
    note: 4.9,
    etiquettes: ['Domaine', 'Jardin', 'Nuit sur place'],
    disponible: true,
    motsCles: ['lieu', 'domaine', 'château', 'salle', 'réception', 'venue', 'jardin'],
  },
  {
    id: 'maison-alba',
    nom: 'Maison Alba',
    categorie: 'planner',
    lieu: 'Paris',
    description:
      'Coordination complète, scénographie et tenue du Jour J. Une seule interlocutrice pour tous les prestataires.',
    aPartirDe: '1 800 €',
    budget: 1800,
    note: 4.8,
    etiquettes: ['Coordination', 'Jour J'],
    disponible: true,
    motsCles: ['planner', 'coordination', 'organisation', 'wedding planner', 'jour j'],
  },
  {
    id: 'claire-martin',
    nom: 'Claire Martin Photo',
    categorie: 'photo',
    lieu: 'Lille',
    description:
      'Reportage naturel, portraits de couple, aucun temps posé imposé. Livraison sous quatre semaines.',
    aPartirDe: '1 200 €',
    budget: 1200,
    note: 4.9,
    etiquettes: ['Naturel', 'Reportage'],
    disponible: false,
    motsCles: ['photo', 'photographe', 'reportage', 'portrait'],
  },
  {
    id: 'studio-nord-film',
    nom: 'Studio Nord Film',
    categorie: 'photo',
    lieu: 'Roubaix',
    description:
      'Film de mariage en deux caméras, teaser à J+7, captation son des vœux.',
    aPartirDe: '2 400 €',
    budget: 2400,
    note: 4.7,
    etiquettes: ['Vidéo', 'Teaser'],
    disponible: true,
    motsCles: ['vidéo', 'video', 'film', 'vidéaste', 'caméra'],
  },
  {
    id: 'atelier-du-gout',
    nom: "L'Atelier du Goût",
    categorie: 'catering',
    lieu: 'Nord',
    description:
      'Cocktail, repas assis et brunch du lendemain. Menus végétariens et allergènes gérés en amont.',
    aPartirDe: '85 € / invité',
    budget: 85,
    note: 4.8,
    etiquettes: ['Cocktail', 'Repas', 'Brunch'],
    disponible: true,
    motsCles: ['traiteur', 'repas', 'dîner', 'diner', 'cocktail', 'menu', 'cater'],
  },
  {
    id: 'matt-mez-sax',
    nom: 'Matt Mez · Saxophone',
    categorie: 'music',
    lieu: 'France / Belgique',
    description:
      'Saxophone live pour la cérémonie, le vin d’honneur et l’entrée des mariés. Set acoustique ou avec DJ.',
    aPartirDe: '450 €',
    budget: 450,
    note: 5,
    etiquettes: ['Saxophone', 'Live'],
    disponible: true,
    motsCles: ['saxo', 'saxophone', 'musicien', 'live', 'cocktail', 'musique'],
  },
  {
    id: 'blue-night-dj',
    nom: 'Blue Night DJ',
    categorie: 'dj',
    lieu: 'Lille',
    description:
      'Set généraliste chic, son et lumière inclus, ouverture de bal préparée avec vous.',
    aPartirDe: '900 €',
    budget: 900,
    note: 4.6,
    etiquettes: ['Dancefloor', 'Son & lumière'],
    disponible: true,
    motsCles: ['dj', 'soirée', 'dansante', 'bal', 'dancefloor'],
  },
  {
    id: 'quartet-mirabeau',
    nom: 'Quartet Mirabeau',
    categorie: 'music',
    lieu: 'Amiens',
    description:
      'Quatuor à cordes pour la cérémonie et le dîner. Répertoire classique et reprises arrangées.',
    aPartirDe: '1 300 €',
    budget: 1300,
    note: 4.9,
    etiquettes: ['Cordes', 'Cérémonie'],
    disponible: true,
    motsCles: ['quartet', 'orchestre', 'groupe', 'cordes', 'classique', 'musique'],
  },
  {
    id: 'fleurs-d-aube',
    nom: "Fleurs d'Aube",
    categorie: 'flowers',
    lieu: 'Arras',
    description:
      'Arche florale, bouquets, centres de table. Fleurs de saison, circuit court.',
    aPartirDe: '600 €',
    budget: 600,
    note: 4.8,
    etiquettes: ['Arche', 'Saison'],
    disponible: true,
    motsCles: ['fleur', 'fleuriste', 'bouquet', 'arche', 'décoration florale'],
  },
  {
    id: 'maison-etoffe',
    nom: 'Maison Étoffe',
    categorie: 'dress',
    lieu: 'Paris',
    description:
      'Robes et costumes, essayages privés, retouches incluses jusqu’à quinze jours avant.',
    aPartirDe: '1 200 €',
    budget: 1200,
    note: 4.7,
    etiquettes: ['Robe', 'Costume'],
    disponible: true,
    motsCles: ['robe', 'costume', 'tenue', 'essayage', 'retouche'],
  },
  {
    id: 'atelier-lumiere',
    nom: 'Atelier Lumière',
    categorie: 'beauty',
    lieu: 'Lille',
    description:
      'Coiffure et maquillage sur le lieu des préparatifs, essai compris, retouches au cocktail.',
    aPartirDe: '380 €',
    budget: 380,
    note: 4.8,
    etiquettes: ['Coiffure', 'Maquillage'],
    disponible: true,
    motsCles: ['coiffure', 'maquillage', 'beauté', 'préparatifs', 'essai'],
  },
  {
    id: 'navettes-hesdin',
    nom: 'Navettes Hesdin',
    categorie: 'transport',
    lieu: 'Pas-de-Calais',
    description:
      'Deux minibus et un car, rotations jusqu’à trois heures du matin, chauffeurs dédiés.',
    aPartirDe: '740 €',
    budget: 740,
    note: 4.5,
    etiquettes: ['Navette', 'Nuit'],
    disponible: true,
    motsCles: ['navette', 'transport', 'bus', 'voiture', 'retour'],
  },
  {
    id: 'patisserie-verlaine',
    nom: 'Pâtisserie Verlaine',
    categorie: 'cake',
    lieu: 'Douai',
    description:
      'Wedding cake, pièce montée revisitée et bar à desserts. Dégustation offerte.',
    aPartirDe: '420 €',
    budget: 420,
    note: 4.7,
    etiquettes: ['Gâteau', 'Dégustation'],
    disponible: true,
    motsCles: ['gâteau', 'gateau', 'pièce montée', 'dessert', 'pâtisserie', 'cake'],
  },
]

/** Cartes proposées par l'agent à partir d'une phrase. */
export function chercherPrestataires(texte: string, limite = 3): Prestataire[] {
  const t = texte.toLowerCase()
  const notes = PRESTATAIRES.map((p) => {
    let score = 0
    for (const mot of p.motsCles) if (t.includes(mot)) score += 2
    if (t.includes(p.lieu.toLowerCase())) score += 1
    if (t.includes(p.nom.toLowerCase())) score += 5
    return { p, score }
  }).filter((x) => x.score > 0)

  notes.sort((a, b) => b.score - a.score || b.p.note - a.p.note)
  return notes.slice(0, limite).map((x) => x.p)
}

export function prestataireParId(id: string): Prestataire | undefined {
  return PRESTATAIRES.find((p) => p.id === id)
}
