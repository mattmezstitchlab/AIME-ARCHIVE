/**
 * La chronologie du Jour J — 12 septembre 2026.
 *
 * Chaque moment est tenu par un rôle (celui dont le clavier s'ouvre),
 * touche d'autres rôles (les ondes), et porte ses propres étapes.
 * Rien n'est stocké ailleurs : la chronologie est une donnée du projet,
 * lue par la page comme le clavier lit ses gestes.
 */

export type Categorie =
  | 'preparatifs'
  | 'ceremonie'
  | 'seuil'
  | 'repas'
  | 'musique'
  | 'photo'
  | 'trajet'

export type Etat = 'attente' | 'en-cours' | 'confirme'

export interface Etape {
  id: string
  l: string
}

export interface Moment {
  id: string
  /** HH:MM, heure locale du Jour J */
  h: string
  titre: string
  sous: string
  categorie: Categorie
  /** le rôle qui tient ce moment — son clavier s'ouvre depuis ici */
  pilote: string
  /** les rôles que ce moment déplace */
  ondes: string[]
  etat: Etat
  /** budget engagé, en euros */
  budget?: number
  /** un moment sous scellé ne se lit qu'avec le pare-feu levé */
  scelle?: boolean
  /** ce que le moment dit vraiment, une fois le scellé levé */
  vrai?: string
  etapes: Etape[]
}

export const CATEGORIES: Record<Categorie, { l: string; role: string }> = {
  preparatifs: { l: 'Préparatifs', role: 'coordo' },
  ceremonie: { l: 'Cérémonie', role: 'officiant' },
  seuil: { l: 'Seuil', role: 'mairie' },
  repas: { l: 'Repas', role: 'traiteur' },
  musique: { l: 'Musique', role: 'dj' },
  photo: { l: 'Photo', role: 'photo' },
  trajet: { l: 'Trajet', role: 'navette' },
}

const e = (...l: string[]): Etape[] =>
  l.map((t, i) => ({ id: `${i}-${t.slice(0, 8)}`, l: t }))

export const CHRONOLOGIE: Moment[] = [
  {
    id: 'aube',
    h: '08:30',
    titre: 'Ouverture du lieu',
    sous: 'Les clés changent de main, le plan B est affiché en cuisine.',
    categorie: 'preparatifs',
    pilote: 'lieu',
    ondes: ['coordo', 'traiteur', 'fleuriste'],
    etat: 'confirme',
    budget: 4200,
    etapes: e('Remise des clés', 'Plan B pluie affiché', 'Électricité vérifiée'),
  },
  {
    id: 'fleurs',
    h: '09:15',
    titre: 'Livraison florale',
    sous: 'Chaque tige a sa table : rien de coupé pour rien.',
    categorie: 'preparatifs',
    pilote: 'fleuriste',
    ondes: ['lieu', 'coordo', 'photo'],
    etat: 'confirme',
    budget: 1850,
    etapes: e('Arche montée', '14 centres de table', 'Bouquet de la mariée', 'Boutonnières'),
  },
  {
    id: 'apprets',
    h: '10:00',
    titre: 'Apprêts',
    sous: 'Coiffure, maquillage, et deux heures qui n’appartiennent qu’à vous.',
    categorie: 'preparatifs',
    pilote: 'couple',
    ondes: ['photo', 'famille', 'temoin'],
    etat: 'en-cours',
    budget: 900,
    etapes: e('Coiffure 10:00', 'Maquillage 10:45', 'Reportage préparatifs', 'Habillage 12:30'),
  },
  {
    id: 'mairie',
    h: '11:30',
    titre: 'Passage en mairie',
    sous: 'Le dossier est complet. Le reste n’est qu’une fête.',
    categorie: 'seuil',
    pilote: 'mairie',
    ondes: ['couple', 'temoin', 'famille', 'navette'],
    etat: 'confirme',
    etapes: e('Pièces déposées', 'Témoins déclarés', 'Salle réservée 11:30'),
  },
  {
    id: 'navettes',
    h: '13:45',
    titre: 'Navettes des invités',
    sous: 'Personne ne rentrera au volant fatigué — trois rotations, deux véhicules.',
    categorie: 'trajet',
    pilote: 'navette',
    ondes: ['invite', 'coordo', 'lieu'],
    etat: 'en-cours',
    budget: 1200,
    etapes: e('Rotation 13:45', 'Rotation 14:15', 'Retour 01:30', 'Liste des points de ramassage'),
  },
  {
    id: 'ceremonie',
    h: '15:00',
    titre: 'Cérémonie laïque',
    sous: 'Les mots sont prêts. Le silence aussi.',
    categorie: 'ceremonie',
    pilote: 'officiant',
    ondes: ['couple', 'temoin', 'enfants', 'dj', 'photo'],
    etat: 'en-cours',
    budget: 700,
    etapes: e('Déroulé validé', 'Lectures choisies', 'Alliances confiées', 'Sono extérieure testée'),
  },
  {
    id: 'enfants',
    h: '15:04',
    titre: 'Entrée des enfants d’honneur',
    sous: 'Six enfants, deux paniers, un seul couloir.',
    categorie: 'ceremonie',
    pilote: 'enfants',
    ondes: ['famille', 'photo', 'officiant'],
    etat: 'attente',
    etapes: e('Répétition la veille', 'Paniers de pétales', 'Un adulte au bout du couloir'),
  },
  {
    id: 'discours',
    h: '16:10',
    titre: 'Le discours du témoin',
    sous: 'Trois minutes quarante — la surprise reste intacte.',
    categorie: 'ceremonie',
    pilote: 'temoin',
    ondes: ['couple', 'dj', 'coordo'],
    etat: 'attente',
    scelle: true,
    vrai: 'Une lettre de la grand-mère du marié, lue en second — personne d’autre ne le sait.',
    etapes: e('Texte relu', 'Micro HF réservé', 'Top DJ à la fin'),
  },
  {
    id: 'cocktail',
    h: '17:00',
    titre: 'Vin d’honneur',
    sous: '148 personnes, six régimes, zéro improvisation.',
    categorie: 'repas',
    pilote: 'traiteur',
    ondes: ['invite', 'lieu', 'coordo', 'famille'],
    etat: 'confirme',
    budget: 2900,
    etapes: e('Menu validé', 'Régimes recensés', 'Personnel : 8 personnes', 'Acompte versé'),
  },
  {
    id: 'golden',
    h: '19:42',
    titre: 'Golden hour',
    sous: 'Sept minutes de miel — le seul moment que la lumière décide.',
    categorie: 'photo',
    pilote: 'photo',
    ondes: ['couple', 'coordo'],
    etat: 'confirme',
    budget: 2200,
    etapes: e('Repérage fait', 'Créneau tenu 19:42', 'Liste de clichés envoyée'),
  },
  {
    id: 'diner',
    h: '20:15',
    titre: 'Dîner assis',
    sous: 'Plan de table verrouillé, 134 couverts, service en deux vagues.',
    categorie: 'repas',
    pilote: 'traiteur',
    ondes: ['invite', 'famille', 'lieu', 'coordo'],
    etat: 'en-cours',
    budget: 11840,
    etapes: e('Plan de table figé', 'Dégustation réalisée', 'Contrat signé', 'Solde à J-7'),
  },
  {
    id: 'ouverture',
    h: '22:30',
    titre: 'Ouverture de bal',
    sous: 'BPM branché sur l’orchestration du Jour J.',
    categorie: 'musique',
    pilote: 'dj',
    ondes: ['couple', 'photo', 'invite'],
    etat: 'attente',
    budget: 1600,
    scelle: true,
    vrai: 'Le morceau a été changé hier par le couple — le DJ seul le sait.',
    etapes: e('Playlist envoyée', 'Morceau d’ouverture', 'Contrat signé', 'Fin de sono 02:00'),
  },
]

export const ETATS: Record<Etat, { l: string; suivant: Etat }> = {
  attente: { l: 'en attente', suivant: 'en-cours' },
  'en-cours': { l: 'en cours', suivant: 'confirme' },
  confirme: { l: 'confirmé', suivant: 'attente' },
}
