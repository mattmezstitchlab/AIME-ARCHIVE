import { Link, createFileRoute } from '@tanstack/react-router'
import { GESTES, PROFILS, R } from '@/data/roles'
import { STATS, dossierDuGeste, nb, teinte } from '@/lib/causal'
import { RANGEE_F } from '@/lib/touches-systeme'
import { useReglages } from '@/lib/reglages'
import { Reveal } from '@/components/Reveal'
import { Cascade } from '@/components/Cascade'
import { TERRAINS } from '@/data/terrains'

export const Route = createFileRoute('/manifeste')({
  head: () => ({ meta: [
    { title: 'Le manifeste — AIME® · Ripple' },
    { name: 'description', content: "Pourquoi un clavier par métier : une touche, un dossier, une onde, une mémoire. Le principe causal d'AIME® Ripple expliqué en trois gestes." },
    { property: 'og:title', content: 'Le manifeste — AIME® · Ripple' },
    { property: 'og:description', content: "Pourquoi un clavier par métier : une touche, un dossier, une onde, une mémoire. Le principe causal d'AIME® Ripple expliqué en trois gestes." },
  ] }),
  component: PageManifeste,
})

const TROIS = [
  {
    n: '01',
    t: 'Elle ouvre un dossier',
    d: 'Au-dessus du clavier : ce qu’il faut savoir, les chiffres, l’onde dessinée, les pièces jointes. Pas un tableau de bord — quatre cartes, lisibles debout, un samedi, sur un téléphone.',
  },
  {
    n: '02',
    t: 'Elle propage une onde',
    d: 'Un invité répond R : le traiteur passe à 134 couverts, le plan de table bouge, la navette gagne un siège. Trois métiers, zéro message écrit.',
  },
  {
    n: '03',
    t: 'Elle laisse une trace',
    d: 'La mémoire causale garde qui a fait quoi, à quelle heure, et ce que ça a déplacé. F3 montre la carte, le graphe montre les arêtes. Rien à reconstituer après.',
  },
]

const ACTIONS = [
  {
    k: '⏎',
    t: 'Agir',
    d: 'La décision est prise, l’onde partira, la mémoire l’écrit. Le compteur d’actes monte d’un cran.',
  },
  {
    k: '⌫',
    t: 'Reporter',
    d: 'Reporter est une décision, pas un oubli : elle s’inscrit au journal, en pointillés, sans propager quoi que ce soit.',
  },
  {
    k: ',',
    t: 'Emporter',
    d: 'Le dossier part au presse-papiers, en texte brut. Prêt à coller dans un mail, un SMS, un devis.',
  },
]




function PageManifeste() {
  const { reglages } = useReglages()
  const jour = reglages.theme === 'jour'
  const apercu = dossierDuGeste('lieu', 'P', GESTES.lieu.P)
  const cLieu = teinte(R.lieu, jour)

  return (
    <>
      {/* ------------------------------------------------------------------
          Un clavier par métier
      ------------------------------------------------------------------ */}
      <section
        className="mx-auto px-[var(--gutter)] pt-[clamp(3.5rem,10vw,7rem)]"
        style={{ maxWidth: 'var(--page)' }}
      >
        <Reveal>
          <p className="eyebrow">
            six métiers · {nb(148)} invités · zéro compte
          </p>
          <h1 className="display t-hero mt-4 max-w-[16ch]">
            Un clavier par métier.
            <br />
            <span style={{ color: 'var(--ink-2)' }}>Une touche, un dossier.</span>
          </h1>
          <p className="lede mt-6 max-w-[44rem]">
            Un mariage, c’est quinze rôles qui se parlent mal. Le Clavier Causal remplace les
            cent messages par un geste : une touche, et l’onde traverse ceux qu’elle concerne —
            sans réveiller les autres.
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-3">
            <Link to="/reglages" className="btn btn-primaire no-underline">
              Dire qui je suis
            </Link>
            <Link to="/" className="btn btn-secondaire no-underline">
              Essayer le clavier
            </Link>
          </div>
          <p className="mt-6 text-[0.8rem]" style={{ color: 'var(--ink-3)' }}>
            Aucun compte. Aucun envoi. Le clavier tourne entièrement dans votre navigateur.
          </p>
        </Reveal>
      </section>

      {/* ------------------------------------------------------------------
          Le panneau, tel qu'il s'ouvre vraiment
      ------------------------------------------------------------------ */}
      <section
        className="mx-auto mt-[clamp(3rem,7vw,5.5rem)] px-[var(--gutter)]"
        style={{ maxWidth: 'var(--page)' }}
      >
        <Reveal>
          <article className="card overflow-hidden" style={{ boxShadow: 'var(--shadow)' }}>
            <span className="block h-[3px] w-full" style={{ background: cLieu }} aria-hidden />
            <header
              className="border-b px-6 py-6 sm:px-9"
              style={{ borderColor: 'var(--line)' }}
            >
              <p className="flex flex-wrap items-center gap-2 text-[0.74rem]">
                <span className="h-2 w-2 rounded-full" style={{ background: cLieu }} aria-hidden />
                <span className="font-medium" style={{ color: cLieu }}>
                  profil Lieu
                </span>
                <span style={{ color: 'var(--ink-3)' }}>· couche 1 · </span>
                <span className="mono" style={{ color: 'var(--ink-2)' }}>
                  touche P
                </span>
              </p>
              <h2 className="display t-2 mt-2">{apercu.titre}</h2>
              <p className="lede mt-2 max-w-[46rem] !text-[1rem]">{apercu.sous}</p>
            </header>

            <div className="grid gap-6 px-6 py-7 sm:px-9 lg:grid-cols-[1fr_1.1fr]">
              <div>
                <p className="eyebrow">Ce qu’il faut savoir</p>
                <dl className="card-2 mt-3 divide-y" style={{ borderColor: 'var(--line)' }}>
                  {apercu.faits.map(([l, v]) => (
                    <div
                      key={l}
                      className="flex flex-wrap items-baseline justify-between gap-3 px-4 py-2.5"
                      style={{ borderColor: 'var(--line)' }}
                    >
                      <dt className="text-[0.82rem]" style={{ color: 'var(--ink-2)' }}>
                        {l}
                      </dt>
                      <dd className="text-[0.88rem] font-medium">{v}</dd>
                    </div>
                  ))}
                </dl>
              </div>
              <div>
                <p className="eyebrow">L’onde — six métiers pivotent</p>
                <div className="card-2 mt-3 overflow-x-auto p-4">
                  <Cascade source="lieu" arcs={apercu.arcs} jour={jour} pareFeu={false} />
                </div>
              </div>
            </div>

            <footer
              className="border-t px-6 py-5 sm:px-9"
              style={{ borderColor: 'var(--line)', background: 'var(--surface-2)' }}
            >
              <p className="eyebrow mb-3">Actions — aux touches seulement</p>
              <ul className="grid gap-2 sm:grid-cols-3">
                {apercu.actions.map((a, i) => (
                  <li
                    key={a.l}
                    className="flex items-center gap-3 rounded-xl border px-3.5 py-2.5"
                    style={{ borderColor: 'var(--line)', background: 'var(--surface)' }}
                  >
                    <span
                      className="mono grid h-7 w-8 shrink-0 place-items-center rounded-lg border text-[0.8rem]"
                      style={{
                        borderColor: 'var(--line)',
                        color: a.t === 'acte' ? cLieu : 'var(--ink-2)',
                      }}
                    >
                      {['⏎', '⌫', ','][i]}
                    </span>
                    <span className="min-w-0 flex-1 text-[0.84rem]">{a.l}</span>
                  </li>
                ))}
              </ul>
            </footer>
          </article>
        </Reveal>

        <Reveal delai={80}>
          <p className="display t-2 mx-auto mt-12 max-w-[30ch] text-center">
            Il n’y a pas de bouton « Envoyer à tout le monde ».
            <br />
            <span style={{ color: 'var(--ink-2)' }}>
              Il y a une touche, et elle ne dérange que les bonnes personnes.
            </span>
          </p>
        </Reveal>
      </section>

      {/* ------------------------------------------------------------------
          Une touche fait trois choses
      ------------------------------------------------------------------ */}
      <section
        className="mx-auto mt-[clamp(4rem,10vw,8rem)] px-[var(--gutter)]"
        style={{ maxWidth: 'var(--page)' }}
      >
        <Reveal>
          <h2 className="display t-1 max-w-[20ch]">
            Une touche fait trois choses — et jamais plus.
          </h2>
          <p className="lede mt-4 max-w-[44rem]">
            C’est la contrainte qui rend l’objet lisible. On ne l’a pas contournée une seule fois.
          </p>
        </Reveal>
        <div className="mt-10 grid gap-5 md:grid-cols-3">
          {TROIS.map((c, i) => (
            <Reveal key={c.n} delai={i * 90}>
              <article className="card lift h-full px-6 py-7">
                <p className="mono text-[0.74rem]" style={{ color: 'var(--ink-3)' }}>
                  {c.n}
                </p>
                <h3 className="display t-3 mt-2">{c.t}</h3>
                <p className="mt-2.5 text-[0.92rem]" style={{ color: 'var(--ink-2)' }}>
                  {c.d}
                </p>
              </article>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ------------------------------------------------------------------
          Les actions ne s'actionnent qu'aux touches
      ------------------------------------------------------------------ */}
      <section
        className="mx-auto mt-[clamp(4rem,10vw,8rem)] px-[var(--gutter)]"
        style={{ maxWidth: 'var(--page)' }}
      >
        <Reveal>
          <h2 className="display t-1 max-w-[20ch]">
            Les actions ne s’actionnent qu’aux touches.
          </h2>
          <p className="lede mt-4 max-w-[46rem]">
            Trois touches, toujours les mêmes, quel que soit le dossier ouvert. On apprend le
            clavier une fois, on ne cherche plus jamais où cliquer.
          </p>
        </Reveal>
        <div className="mt-10 grid gap-5 md:grid-cols-3">
          {ACTIONS.map((a, i) => (
            <Reveal key={a.k} delai={i * 90}>
              <article className="card h-full px-6 py-7">
                <span
                  className="cap mono grid h-12 w-14 place-items-center text-[1.15rem]"
                  aria-hidden
                >
                  {a.k}
                </span>
                <h3 className="display t-3 mt-4">{a.t}</h3>
                <p className="mt-2.5 text-[0.92rem]" style={{ color: 'var(--ink-2)' }}>
                  {a.d}
                </p>
              </article>
            </Reveal>
          ))}
        </div>
        <Reveal delai={60}>
          <p className="mt-6 max-w-[52rem] text-[0.88rem]" style={{ color: 'var(--ink-3)' }}>
            Ces trois touches sont dormantes tant qu’aucun dossier n’est ouvert — et présentes sur
            le clavier affiché, cliquables : la contrainte est une pédagogie, pas un piège pour qui
            ne peut pas taper.
          </p>
        </Reveal>
      </section>

      {/* ------------------------------------------------------------------
          Six métiers, six claviers
      ------------------------------------------------------------------ */}
      <section
        className="mx-auto mt-[clamp(4rem,10vw,8rem)] px-[var(--gutter)]"
        style={{ maxWidth: 'var(--page)' }}
      >
        <Reveal>
          <h2 className="display t-1 max-w-[18ch]">Six métiers, six claviers.</h2>
          <p className="lede mt-4 max-w-[46rem]">
            Le même moteur, découpé six fois. Ce qu’un rôle ne doit pas voir n’est pas grisé, ni
            caché derrière un mot de passe : la touche n’existe pas sur son clavier.
          </p>
        </Reveal>
        <div className="mt-10 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {PROFILS.map((p, i) => (
            <Reveal key={p.id} delai={i * 60}>
              <article className="card lift h-full px-5 py-6">
                <p className="flex items-baseline gap-2">
                  <span className="mono text-[0.74rem]" style={{ color: 'var(--ink-3)' }}>
                    {p.n}
                  </span>
                  <span className="display t-3">{p.nom}</span>
                </p>
                <p className="mt-2 text-[0.88rem]" style={{ color: 'var(--ink-2)' }}>
                  {p.tagline}
                </p>
                <p className="mt-3 text-[0.78rem]" style={{ color: 'var(--ink-3)' }}>
                  {p.pour}
                </p>
                <p
                  className="mt-4 border-t pt-3 text-[0.76rem]"
                  style={{ borderColor: 'var(--line)', color: 'var(--ink-3)' }}
                >
                  {p.note}
                </p>
              </article>
            </Reveal>
          ))}
        </div>
        <Reveal delai={80}>
          <p className="display t-2 mx-auto mt-12 max-w-[28ch] text-center">
            Le clavier des mariés ne montre pas le flashmob.
            <br />
            <span style={{ color: 'var(--ink-2)' }}>
              Celui des témoins, oui. C’est le même moteur.
            </span>
          </p>
        </Reveal>
      </section>

      {/* ------------------------------------------------------------------
          Accessible par construction
      ------------------------------------------------------------------ */}
      <section
        className="mx-auto mt-[clamp(4rem,10vw,8rem)] px-[var(--gutter)]"
        style={{ maxWidth: 'var(--page)' }}
      >
        <Reveal>
          <h2 className="display t-1 max-w-[18ch]">Accessible par construction.</h2>
          <p className="lede mt-4 max-w-[46rem]">
            La rangée F1–F12 n’est pas une démonstration : elle règle vraiment la page, et le
            réglage suit d’une page à l’autre. Conformité EAA visée sans page « accessibilité »
            séparée.
          </p>
        </Reveal>
        <Reveal delai={70}>
          <ul className="mt-8 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {[...RANGEE_F, { k: 'esc', l: 'tout remettre à plat' }].map((f) => (
              <li key={f.k} className="card-2 flex items-center gap-3 px-4 py-3">
                <span
                  className="mono grid h-7 min-w-12 shrink-0 place-items-center rounded-md border px-1.5 text-[0.7rem]"
                  style={{ borderColor: 'var(--line)', color: 'var(--ink-2)' }}
                >
                  {f.k}
                </span>
                <span className="text-[0.86rem]">{f.l}</span>
              </li>
            ))}
          </ul>
        </Reveal>
        <Reveal delai={90}>
          <p className="mt-6 max-w-[52rem] text-[0.88rem]" style={{ color: 'var(--ink-3)' }}>
            Tout est atteignable au clavier seul, chaque touche porte son{' '}
            <span className="mono">aria-label</span>, les graphes portent leur description, et les
            animations se coupent — d’un appui, ou parce que le système l’a déjà demandé.
          </p>
        </Reveal>
      </section>

      {/* ------------------------------------------------------------------
          Le mariage n'est qu'un premier terrain
      ------------------------------------------------------------------ */}
      <section
        className="mx-auto mt-[clamp(4rem,10vw,8rem)] px-[var(--gutter)]"
        style={{ maxWidth: 'var(--page)' }}
      >
        <Reveal>
          <h2 className="display t-1 max-w-[20ch]">Le mariage n’est qu’un premier terrain.</h2>
          <p className="lede mt-4 max-w-[48rem]">
            Un mariage est le pire cas d’école qu’on puisse choisir : beaucoup de rôles, aucune
            hiérarchie, une date immuable, et des secrets à tenir. Ce qui tient là tient ailleurs.
          </p>
        </Reveal>
        <div className="mt-10 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {TERRAINS.map((t, i) => (
            <Reveal key={t.id} delai={i * 60}>
              <Link
                to="/terrains/$terrain"
                params={{ terrain: t.id }}
                className="card lift block h-full px-5 py-6 no-underline"
                style={{ color: 'var(--ink)' }}
              >
                <h3 className="display t-3">{t.nom}</h3>
                <p className="mt-2.5 text-[0.88rem]" style={{ color: 'var(--ink-2)' }}>
                  {t.d}
                </p>
                <p className="mono mt-4 text-[0.72rem]" style={{ color: 'var(--ink-3)' }}>
                  {t.m}
                </p>
                <p className="mt-3 text-[0.76rem]" style={{ color: 'var(--gold)' }}>
                  Ouvrir le clavier {t.nom.toLowerCase()} →
                </p>
              </Link>
            </Reveal>
          ))}
        </div>
        <Reveal>
          <p className="mt-6">
            <Link to="/terrains" className="btn btn-secondaire no-underline">
              Voir les cinq terrains
            </Link>
          </p>
        </Reveal>

      </section>

      {/* ------------------------------------------------------------------
          Commencez par qui vous êtes
      ------------------------------------------------------------------ */}
      <section
        className="mx-auto mt-[clamp(4rem,10vw,8rem)] px-[var(--gutter)]"
        style={{ maxWidth: 'var(--page)' }}
      >
        <Reveal>
          <div className="card px-7 py-[clamp(3rem,7vw,5rem)] text-center">
            <h2 className="display t-1 mx-auto max-w-[16ch]">Commencez par qui vous êtes.</h2>
            <p className="lede mx-auto mt-4 max-w-[36rem]">
              Un chiffre, un clavier. Trente secondes, et vous n’aurez plus jamais à expliquer
              votre rôle.
            </p>
            <div className="mt-8 flex flex-wrap justify-center gap-3">
              <Link to="/reglages" className="btn btn-primaire no-underline">
                Choisir mon profil
              </Link>
              <Link to="/" className="btn btn-secondaire no-underline">
                Ouvrir le clavier tel quel
              </Link>
            </div>
            <p className="mt-8 text-[0.78rem]" style={{ color: 'var(--ink-3)' }}>
              {nb(STATS.roles)} rôles · {nb(STATS.gestes)} gestes · {nb(STATS.aretes)} arêtes ·{' '}
              {nb(STATS.masquees)} ondes sous scellé.
            </p>
          </div>
        </Reveal>
      </section>
    </>
  )
}
