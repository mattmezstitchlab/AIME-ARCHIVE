import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  HeadContent,
  Link,
  Outlet,
  Scripts,
  createRootRouteWithContext,
  useRouter,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";

import { Chrome } from "@/components/Chrome";
import { FournisseurReglages, SCRIPT_SANS_CLIGNOTEMENT } from "@/lib/reglages";
import { FournisseurToast } from "@/lib/toast";
import { reportLovableError } from "../lib/lovable-error-reporting";

import appCss from "../styles.css?url";

const TITRE = "AIME® · Ripple — Le Clavier Causal";
const DESCRIPTION =
  "Un clavier par métier. Une touche est un geste, un geste ouvre un dossier et propage une onde chez tous ceux qu’elle concerne — sans réveiller les autres.";

function NotFoundComponent() {
  return (
    <div className="mx-auto flex min-h-[60vh] max-w-[var(--page)] flex-col items-center justify-center px-[var(--gutter)] text-center">
      <p className="mono text-[0.72rem]" style={{ color: "var(--ink-3)" }}>
        404
      </p>
      <h1 className="display mt-3 text-[clamp(1.8rem,4vw,2.8rem)]">Cette touche n’existe pas</h1>
      <p className="mt-3 max-w-[34rem] text-[0.9rem]" style={{ color: "var(--ink-2)" }}>
        La page demandée n’est pas sur le clavier. Revenez à la rangée principale.
      </p>
      <Link
        to="/"
        className="mt-7 rounded-full px-5 py-2.5 text-[0.85rem] no-underline"
        style={{ background: "var(--accent)", color: "var(--accent-ink)" }}
      >
        Retour au clavier
      </Link>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="mx-auto flex min-h-[60vh] max-w-[var(--page)] flex-col items-center justify-center px-[var(--gutter)] text-center">
      <h1 className="display text-[clamp(1.6rem,3.4vw,2.4rem)]">Cette page n’a pas chargé</h1>
      <p className="mt-3 max-w-[34rem] text-[0.9rem]" style={{ color: "var(--ink-2)" }}>
        Une onde s’est perdue en chemin. Réessayez, ou revenez au clavier.
      </p>
      <div className="mt-7 flex flex-wrap justify-center gap-3">
        <button
          type="button"
          onClick={() => {
            router.invalidate();
            reset();
          }}
          className="rounded-full px-5 py-2.5 text-[0.85rem]"
          style={{ background: "var(--accent)", color: "var(--accent-ink)" }}
        >
          Réessayer
        </button>
        <Link
          to="/"
          className="rounded-full border px-5 py-2.5 text-[0.85rem] no-underline"
          style={{ borderColor: "var(--line)", color: "var(--ink)" }}
        >
          Retour au clavier
        </Link>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1, viewport-fit=cover" },
      { title: TITRE },
      { name: "description", content: DESCRIPTION },
      { name: "theme-color", content: "#08080a" },
      { property: "og:title", content: TITRE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { title: "Lovable App" },
      { property: "og:title", content: "Lovable App" },
      { name: "twitter:title", content: "Lovable App" },
      { name: "description", content: "Page Architect assembles and completes missing pages for your content." },
      { property: "og:description", content: "Page Architect assembles and completes missing pages for your content." },
      { name: "twitter:description", content: "Page Architect assembles and completes missing pages for your content." },
      { property: "og:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/e78547ad-e1e9-4896-84ae-1ac536cabd89/id-preview-3491f7ad--cd2032b3-c689-4d3c-8b05-2b966de44c05.lovable.app-1785250531806.png" },
      { name: "twitter:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/e78547ad-e1e9-4896-84ae-1ac536cabd89/id-preview-3491f7ad--cd2032b3-c689-4d3c-8b05-2b966de44c05.lovable.app-1785250531806.png" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Figtree:wght@300;400;500;600;700&family=IBM+Plex+Mono:wght@400;500&display=swap",
      },
    ],
  }),
  shellComponent: RootDocument,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootDocument({ children }: { children: ReactNode }) {
  return (
    <html lang="fr" data-theme="nuit">
      <head>
        <HeadContent />
        <script dangerouslySetInnerHTML={{ __html: SCRIPT_SANS_CLIGNOTEMENT }} />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();

  return (
    <QueryClientProvider client={queryClient}>
      <FournisseurReglages>
        <FournisseurToast>
          <Chrome>
            <Outlet />
          </Chrome>
        </FournisseurToast>
      </FournisseurReglages>
    </QueryClientProvider>
  );
}
