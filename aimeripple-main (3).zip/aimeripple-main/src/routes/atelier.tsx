import { createFileRoute } from '@tanstack/react-router'
import { Atelier } from '@/components/atelier/Atelier'
import { Reveal } from '@/components/Reveal'

export const Route = createFileRoute('/atelier')({
  head: () => ({
    meta: [
      { title: 'L’atelier — la timeline qui se parle · AIME® Ripple' },
      {
        name: 'description',
        content:
          'Une phrase devient une journée entière : l’agent déplie la timeline, sort des cartes de prestataires en discutant, recale les heures et tient le budget.',
      },
      { property: 'og:title', content: 'L’atelier — la timeline qui se parle · AIME® Ripple' },
      {
        property: 'og:description',
        content:
          'Le moteur de timeline d’AIME® sans clavier : on décrit, l’agent déplie, propose, déplace et chiffre.',
      },
      { property: 'og:type', content: 'website' },
      { name: 'twitter:card', content: 'summary_large_image' },
    ],
  }),
  component: PageAtelier,
})

function PageAtelier() {
  return (
    <div className="mx-auto px-[var(--gutter)] py-12" style={{ maxWidth: 'var(--page)' }}>
      <Reveal>
        <header className="max-w-2xl">
          <p className="eyebrow">L’atelier</p>
          <h1 className="t-1 mt-2">La timeline qui se parle.</h1>
          <p className="lede mt-4">
            Ici, pas de clavier : une phrase. L’agent la déplie en journée, sort des cartes quand un
            poste manque, déplace les heures que vous lui dictez et chiffre au fur et à mesure.
          </p>
        </header>
      </Reveal>
      <Atelier />
    </div>
  )
}
