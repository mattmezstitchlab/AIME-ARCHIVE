import { useState } from 'react'
import { Link, createFileRoute, notFound } from '@tanstack/react-router'
import { TERRAIN, TERRAINS } from '@/data/terrains'
import { useReglages } from '@/lib/reglages'
import { useToast } from '@/lib/toast'
import { ClavierTerrain } from '@/components/ClavierTerrain'
import { Reveal } from '@/components/Reveal'

export const Route = createFileRoute('/terrains/$terrain')({
  loader: ({ params }) => {
    const t = TERRAIN[params.terrain]
    if (!t) throw notFound()
    return { nom: t.nom, d: t.d, m: t.m }
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return {
        meta: [
          { title: 'Terrain introuvable — AIME® · Ripple' },
          { name: 'robots', content: 'noindex' },
        ],
      }
    }
    
    const titre = `${loaderData.nom} — un clavier causal par métier | AIME® · Ripple`
    
    return {
      meta: [
        { title: titre },
        { name: 'description', content: `${loaderData.d} ${loaderData.m}.` },
        { property: 'og:title', content: titre },
        { property: 'og:description', content: loaderData.d },
        { property: 'og:type', content: 'article' },
        { name: 'twitter:card', content: 'summary_large_image' },
      ],
    }
  },
  component: PageTerrain,
})

function PageTerrain() {
  const { terrain: id } = Route.useParams()
  const t = TERRAIN[id]
  const { reglages, profilActif } = useReglages()
  const toast = useToast()
  
  // Nouveaux états pour gérer les fonctionnalités avancées
  const [pareFeu, setPareFeu] = useState(false)
  const [modeMobile, setModeMobile] = useState(false)
  
  const jour = reglages.theme === 'jour'

  if (!t) return null

  const i = TERRAINS.findIndex((x) => x.id === t.id)
  const suivant = TERRAINS[(i + 1) % TERRAINS.length]

  return (
    <div 
      className={`transition-all duration-500 ${modeMobile ? 'fixed inset-0 z-[100] bg-black overflow-y-auto px-4 py-8' : 'mx-auto px-[var(--gutter)] py-12'}`} 
      style={{ maxWidth: modeMobile ? '100%' : 'var(--page)' }}
    >
      {!modeMobile && (
        <Reveal>
          <p className="eyebrow mb-3">
            <Link to="/terrains" className="no-underline" style={{ color: 'var(--ink-3)' }}>
              Les terrains
            </Link>{' '}
            · {t.m}
          </p>
          <h1 className="display text-[clamp(1.9rem,5vw,3.1rem)] leading-[1.05] max-w-[20ch]">
            {t.nom}
          </h1>
          <p className="lede mt-4 max-w-[46rem]">{t.d}</p>
          <p className="mt-3 max-w-[46rem] text-[0.92rem] leading-relaxed" style={{ color: 'var(--ink-2)' }}>
            {t.contexte}
          </p>
        </Reveal>
      )}

      {!modeMobile && (
        <Reveal delai={60}>
          <div className="mt-6 grid gap-3 sm:grid-cols-2">
            <p className="card-2 px-4 py-3 text-[0.84rem]" style={{ color: 'var(--ink-2)' }}>
              <span className="eyebrow mb-1 block">Ce que ça remplace</span>
              {t.avant}
            </p>
            <p className="card-2 px-4 py-3 text-[0.84rem]" style={{ color: 'var(--ink-2)' }}>
              <span className="eyebrow mb-1 block">Le pare-feu, ici</span>
              {t.feu}
            </p>
          </div>
        </Reveal>
      )}

      <div className={`mt-7 mb-5 flex flex-wrap items-center justify-between gap-3 ${modeMobile ? 'sticky top-0 z-50 bg-black/80 backdrop-blur-md pb-4' : ''}`}>
        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={() =>
              setPareFeu((v) => {
                toast(v ? 'Pare-feu refermé' : 'Pare-feu levé — les ondes scellées se lisent')
                return !v
              })
            }
            className="rounded-full border px-3.5 py-1.5 text-[0.78rem] transition-colors"
            style={{
              borderColor: pareFeu ? 'var(--gold)' : 'var(--line)',
              color: pareFeu ? 'var(--gold)' : 'var(--ink-2)',
            }}
            aria-pressed={pareFeu}
          >
            Pare-feu causal · {pareFeu ? 'levé' : 'scellé'}
          </button>
          
          {!modeMobile && (
            <p className="text-[0.78rem]" style={{ color: 'var(--ink-3)' }}>
              Démonstration locale — profil{' '}
              <span style={{ color: 'var(--ink-2)' }}>{profilActif.court}</span>
            </p>
          )}
        </div>

        {/* Bouton de bascule Mode Mobile / Cockpit */}
        <button
          type="button"
          onClick={() => {
            setModeMobile(!modeMobile)
            toast(!modeMobile ? 'Mode Terrain activé : interface optimisée pour le mobile' : 'Retour au mode bureau')
          }}
          className="rounded-full border px-4 py-1.5 text-[0.78rem] transition-colors hover:bg-white/10"
          style={{ borderColor: 'var(--line)', color: modeMobile ? 'var(--white)' : 'var(--ink-2)' }}
        >
          {modeMobile ? '✕ Quitter le mode terrain' : '📱 Mode Terrain (Plein écran)'}
        </button>
      </div>

      <ClavierTerrain terrain={t} jour={jour} pareFeu={pareFeu} />

      {!modeMobile && (
        <>
          <Reveal>
            <section className="mt-16">
              <div className="mb-6 flex items-center justify-between border-b pb-4" style={{ borderColor: 'var(--line)' }}>
                <h2 className="display t-2">Le Cockpit (Vue Opérationnelle)</h2>
                <span className="rounded-full border px-2 py-1 text-[0.7rem] uppercase tracking-widest" style={{ borderColor: 'var(--line)', color: 'var(--ink-3)' }}>
                  Aperçu du futur Dashboard
                </span>
              </div>
              <p className="mb-6 text-[0.9rem]" style={{ color: 'var(--ink-2)' }}>
                Contrairement à la mémoire causale qui affiche l'historique chronologique, le cockpit trie les ondes par rôle. Chaque métier voit instantanément sa propre "To-Do List" générée par le système.
              </p>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {t.roles.slice(0, 3).map((r) => (
                  <div key={r.id} className="card-2 overflow-hidden">
                    <div className="border-b px-4 py-3" style={{ borderColor: 'var(--line)', borderTop: `3px solid ${jour ? r.cJour : r.c}` }}>
                      <span className="font-semibold" style={{ color: jour ? r.cJour : r.c }}>{r.court}</span>
                    </div>
                    <div className="p-4">
                      <ul className="space-y-3">
                        <li className="flex items-start gap-2 text-[0.85rem]">
                          <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-white/20" />
                          <span style={{ color: 'var(--ink-2)' }}>En attente de vos actions suite aux dernières ondes...</span>
                        </li>
                      </ul>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          </Reveal>

          <Reveal>
            <section className="mt-16">
              <h2 className="display t-1">Ce que l’onde change</h2>
              <div className="mt-5 grid gap-4 md:grid-cols-3">
                {t.preuve.map((p) => (
                  <article key={p.l} className="card-2 px-4 py-4">
                    <p className="text-[0.82rem]" style={{ color: 'var(--ink-2)' }}>
                      {p.l}
                    </p>
                    <p className="mt-3 flex items-baseline gap-2">
                      <span
                        className="mono text-[0.95rem] line-through"
                        style={{ color: 'var(--ink-3)' }}
                      >
                        {p.avant}
                      </span>
                      <span style={{ color: 'var(--ink-3)' }}>→</span>
                      <span className="display text-[1.35rem]" style={{ color: 'var(--gold)' }}>
                        {p.apres}
                      </span>
                    </p>
                  </article>
                ))}
              </div>
            </section>
          </Reveal>

          <Reveal>
            <nav className="mt-12 flex flex-wrap items-center gap-3">
              <Link
                to="/terrains/$terrain"
                params={{ terrain: suivant.id }}
                className="btn btn-primaire no-underline"
              >
                Terrain suivant : {suivant.nom}
              </Link>
              <Link to="/" className="btn btn-secondaire no-underline">
                Revenir au clavier du mariage
              </Link>
            </nav>
          </Reveal>
        </>
      )}
    </div>
  )
}
