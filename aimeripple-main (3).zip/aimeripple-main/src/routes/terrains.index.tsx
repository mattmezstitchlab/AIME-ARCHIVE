import { Link, createFileRoute } from '@tanstack/react-router'
import { TERRAINS } from '@/data/terrains'
import { useReglages } from '@/lib/reglages'
import { Reveal } from '@/components/Reveal'

export const Route = createFileRoute('/terrains/')({
  head: () => ({
    meta: [
      { title: 'Les terrains — le clavier causal hors du mariage | AIME® · Ripple' },
      {
        name: 'description',
        content:
          'Chantier, hôpital de jour, tournage, festival, déménagement, obsèques : cinq terrains où le même clavier causal tient — rôles, ondes, pare-feu, mémoire.',
      },
      { property: 'og:title', content: 'Les terrains — le clavier causal hors du mariage' },
      {
        property: 'og:description',
        content:
          'La preuve par cinq métiers : une touche, un dossier, une onde. Seul le vocabulaire change.',
      },
      { property: 'og:type', content: 'website' },
      { name: 'twitter:card', content: 'summary_large_image' },
    ],
  }),
  component: PageTerrains,
})

function PageTerrains() {
  const { reglages } = useReglages()
  const jour = reglages.theme === 'jour'

  return (
    <div className="mx-auto px-[var(--gutter)] py-12" style={{ maxWidth: 'var(--page)' }}>
      <Reveal>
        <header className="max-w-[48rem]">
          <p className="eyebrow mb-3">Les terrains · la preuve par cinq métiers</p>
          <h1 className="display text-[clamp(1.9rem,5vw,3.1rem)] leading-[1.05]">
            Le mariage n’était qu’un terrain d’essai
          </h1>
          <p className="mt-4 text-[1rem] leading-relaxed" style={{ color: 'var(--ink-2)' }}>
            Partout où des métiers dépendent les uns des autres sans se parler assez, le même
            objet tient : des rôles, une touche par geste, une onde qui ne réveille que les
            bonnes personnes, un pare-feu, une mémoire. Chaque terrain ci-dessous a son propre
            clavier — pressez une touche, l’onde court.
          </p>
        </header>
      </Reveal>

      <div className="mt-10 grid gap-5 md:grid-cols-2">
        {TERRAINS.map((t, i) => (
          <Reveal key={t.id} delai={i * 60}>
            <Link
              to="/terrains/$terrain"
              params={{ terrain: t.id }}
              className="card block h-full overflow-hidden no-underline transition-transform hover:-translate-y-[2px]"
              style={{ color: 'var(--ink)' }}
            >
              <span
                className="flex h-[3px] w-full"
                aria-hidden
                style={{ background: 'transparent' }}
              >
                {t.roles.map((r) => (
                  <span
                    key={r.id}
                    className="h-full flex-1"
                    style={{ background: jour ? r.cJour : r.c }}
                  />
                ))}
              </span>
              <div className="px-5 py-5">
                <p className="eyebrow">{t.m}</p>
                <h2 className="display t-2 mt-2">{t.nom}</h2>
                <p className="mt-2 text-[0.9rem] leading-relaxed" style={{ color: 'var(--ink-2)' }}>
                  {t.d}
                </p>
                <p className="mt-4 flex flex-wrap gap-2 text-[0.72rem]">
                  {t.roles.map((r) => (
                    <span
                      key={r.id}
                      className="rounded-full border px-2.5 py-0.5"
                      style={{ borderColor: 'var(--line)', color: jour ? r.cJour : r.c }}
                    >
                      {r.court}
                    </span>
                  ))}
                </p>
                <p className="mt-4 text-[0.78rem]" style={{ color: 'var(--ink-3)' }}>
                  {t.gestes.length} gestes · {t.roles.length} rôles · ouvrir le clavier →
                </p>
              </div>
            </Link>
          </Reveal>
        ))}
      </div>
    </div>
  )
}
