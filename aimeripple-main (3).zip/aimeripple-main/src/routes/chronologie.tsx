import { useState } from 'react'
import { createFileRoute, useNavigate } from '@tanstack/react-router'
import { useReglages } from '@/lib/reglages'
import { useToast } from '@/lib/toast'
import { Chronologie } from '@/components/Chronologie'
import { Reveal } from '@/components/Reveal'

export const Route = createFileRoute('/chronologie')({
  head: () => ({
    meta: [
      { title: 'La chronologie du Jour J — AIME® · Ripple' },
      {
        name: 'description',
        content:
          'Douze moments du 12 septembre 2026, tenus chacun par un rôle : choisissez-en un, l’onde causale parcourt la journée et allume tout ce qu’elle déplace.',
      },
      { property: 'og:title', content: 'La chronologie du Jour J — AIME® · Ripple' },
      {
        property: 'og:description',
        content:
          'Le clavier causal vu en longueur : budget, étapes, ondes et moments sous scellé, du lever du jour à l’ouverture de bal.',
      },
      { property: 'og:type', content: 'website' },
      { name: 'twitter:card', content: 'summary_large_image' },
    ],
  }),
  component: PageChronologie,
})

function PageChronologie() {
  const { reglages, profilActif, regler } = useReglages()
  const toast = useToast()
  const navigate = useNavigate()
  const [pareFeu, setPareFeu] = useState(false)
  const jour = reglages.theme === 'jour'
  const ouvrable = profilActif.feu === 'ouvrable'

  return (
    <div className="mx-auto px-[var(--gutter)] py-12" style={{ maxWidth: 'var(--page)' }}>
      <Reveal>
        <header className="mb-10 max-w-[46rem]">
          <p className="eyebrow mb-3">La chronologie · 12 septembre 2026</p>
          <h1 className="display text-[clamp(1.9rem,5vw,3.1rem)] leading-[1.05]">
            La même journée, vue en longueur
          </h1>
          <p className="mt-4 text-[1rem] leading-relaxed" style={{ color: 'var(--ink-2)' }}>
            Le clavier propage les ondes dans l’espace des rôles ; la chronologie les
            propage dans le temps. Choisissez un moment : ses rôles s’allument, puis
            tous les moments qu’ils tiennent plus tard, l’un après l’autre.
          </p>
        </header>
      </Reveal>

      <div className="mb-6 flex flex-wrap items-center gap-3">
        <button
          type="button"
          onClick={() => {
            if (!ouvrable) {
              toast(
                `Pare-feu scellé sur le profil ${profilActif.nom} — ce qu’on vous prépare ne s’ouvre pas d’ici`,
              )
              return
            }
            setPareFeu((v) => {
              toast(v ? 'Pare-feu refermé' : 'Pare-feu ouvert — les moments scellés se lisent')
              return !v
            })
          }}
          className="rounded-full border px-3.5 py-1.5 text-[0.78rem] transition-colors"
          style={{
            borderColor: pareFeu ? 'var(--gold)' : 'var(--line)',
            color: pareFeu ? 'var(--gold)' : 'var(--ink-2)',
          }}
          aria-pressed={pareFeu}
        >
          Pare-feu causal · {pareFeu ? 'levé' : 'scellé'}
        </button>
        <p className="text-[0.78rem]" style={{ color: 'var(--ink-3)' }}>
          Profil <span style={{ color: 'var(--ink-2)' }}>{profilActif.court}</span> — les
          états, les étapes et le budget restent dans ce navigateur.
        </p>
      </div>

      <Chronologie
        jour={jour}
        pareFeu={pareFeu}
        onOuvrirClavier={(rid) => {
          regler({ role: rid })
          void navigate({ to: '/' })
        }}
      />
    </div>
  )
}
