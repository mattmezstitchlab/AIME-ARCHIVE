import { useEffect, useRef } from "react";

export default function useAutoProjectRail(itemCount) {
  const railRef = useRef(null);
  const direction = useRef(1);
  const pauseUntil = useRef(0);
  const dragging = useRef(null);
  const suppressClick = useRef(false);

  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return undefined;
    let frame;
    let previous = performance.now();
    const animate = (now) => {
      const rail = railRef.current;
      if (rail && !dragging.current && now > pauseUntil.current) {
        const maximum = rail.scrollWidth - rail.clientWidth;
        if (maximum > 1) {
          rail.scrollLeft += direction.current * ((now - previous) * 0.014);
          if (rail.scrollLeft >= maximum - 1) direction.current = -1;
          if (rail.scrollLeft <= 1) direction.current = 1;
        }
      }
      previous = now;
      frame = requestAnimationFrame(animate);
    };
    frame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(frame);
  }, [itemCount]);

  const pause = () => { pauseUntil.current = performance.now() + 1800; };
  const onPointerDown = (event) => {
    pause();
    suppressClick.current = false;
    if (event.pointerType !== "mouse") return;
    dragging.current = { x: event.clientX, scroll: event.currentTarget.scrollLeft };
    event.currentTarget.setPointerCapture(event.pointerId);
  };
  const onPointerMove = (event) => {
    if (!dragging.current) return;
    const distance = event.clientX - dragging.current.x;
    if (Math.abs(distance) > 5) suppressClick.current = true;
    event.currentTarget.scrollLeft = dragging.current.scroll - distance;
  };
  const onPointerUp = () => { dragging.current = null; pause(); };
  const onClickCapture = (event) => {
    if (!suppressClick.current) return;
    event.preventDefault();
    event.stopPropagation();
    suppressClick.current = false;
  };

  return { railRef, railProps: { onPointerDown, onPointerMove, onPointerUp, onPointerCancel: onPointerUp, onWheel: pause, onClickCapture } };
}