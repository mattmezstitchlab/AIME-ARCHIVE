import React from "react";
import { Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import HeroReliefAnimation from "@/components/portfolio/HeroReliefAnimation";

export default function Contact() {
  const urlParams = new URLSearchParams(window.location.search);
  const projectSlug = urlParams.get("slug") || "";
  return (
    <main className="relative min-h-screen overflow-hidden bg-black px-5 py-6 text-white sm:px-8 lg:px-12">
      <HeroReliefAnimation className="fixed inset-0 h-screen w-full opacity-70" />
      <div className="fixed inset-0 bg-black/50" />
      <div className="relative z-10 mx-auto max-w-6xl">
        <Link to={projectSlug ? `/projects/${projectSlug}` : "/"} className="inline-flex min-h-11 items-center gap-2 rounded-full border border-white/20 bg-white/10 px-4 text-sm backdrop-blur-xl"><ArrowLeft className="h-4 w-4" /> Retour</Link>
        <section className="flex min-h-[calc(100vh-6rem)] items-center py-8">
          <div className="max-w-3xl"><p className="text-xs uppercase tracking-[0.3em] text-white/50">Contact conversationnel</p><h1 className="mt-5 font-display text-5xl font-semibold leading-[0.9] tracking-[-0.06em] sm:text-7xl">Parlons de votre projet.</h1><p className="mt-6 max-w-xl text-base leading-7 text-white/65">AIME Concierge répond à vos questions, prépare la demande avec vous et ne l’envoie à Matthieu qu’après votre confirmation.</p></div>
        </section>
      </div>
    </main>
  );
}