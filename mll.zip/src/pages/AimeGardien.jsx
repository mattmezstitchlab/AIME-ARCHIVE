import React from "react";
import AimeGardienExperience from "@/components/aime-gardien/AimeGardienExperience";

export default function AimeGardien() {
  return <AimeGardienExperience />;
}