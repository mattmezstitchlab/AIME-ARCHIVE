import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import ProjectHero from "@/components/portfolio/ProjectHero";
import AtlasCategoryBrowser from "@/components/portfolio/AtlasCategoryBrowser";
import MagazineHero from "@/components/magazine/MagazineHero";
import HomeEditorialFeatures from "@/components/home-magazine/HomeEditorialFeatures";
import { sortProjects } from "@/components/portfolio/projectConstants";
import { dedupeProjects } from "@/components/portfolio/projectCoherence";

export default function Home() {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadProjects = async () => {
      const data = await base44.entities.Project.filter({ visible: true }, "display_order", 1000);
      setProjects(dedupeProjects(sortProjects(data)));
      setLoading(false);
    };
    loadProjects();
  }, []);

  useEffect(() => {
    return base44.entities.Project.subscribe((event) => {
      setProjects((current) => {
        if (event.type === "delete" || event.data?.visible === false) return current.filter((project) => project.id !== event.id);
        const exists = current.some((project) => project.id === event.id);
        const next = exists
          ? current.map((project) => project.id === event.id ? { ...project, ...event.data } : project)
          : event.data?.visible ? [...current, event.data] : current;
        return dedupeProjects(sortProjects(next));
      });
    });
  }, []);

  useEffect(() => {
    const refreshProjects = async () => {
      const data = await base44.entities.Project.filter({ visible: true }, "display_order", 1000);
      setProjects(dedupeProjects(sortProjects(data)));
    };
    window.addEventListener("atlas-projects-updated", refreshProjects);
    return () => window.removeEventListener("atlas-projects-updated", refreshProjects);
  }, []);

  return (
    <main className="relative min-h-screen overflow-x-hidden bg-background text-foreground">
      <ProjectHero projects={projects} />
      <MagazineHero />
      {!loading && <HomeEditorialFeatures projects={projects} />}
      <section id="atlas-complet" className="relative z-10 scroll-mt-6 py-20">
        <div className="mx-auto max-w-none">
          <div className="mb-8 flex flex-col justify-between gap-5 px-5 sm:flex-row sm:items-end sm:px-8 lg:px-12">
            <div>
              <h2 className="font-display text-4xl font-semibold tracking-[-0.05em] text-foreground sm:text-5xl">Atlas des {projects.length} projets visibles</h2>
            </div>
            <p className="max-w-md text-sm leading-6 text-white">
              Corpus complet importé depuis l’Atlas : familles, intentions, fiches détaillées et visuels reconstruits.
            </p>
          </div>
          {loading ? (
            <div className="grid grid-cols-2 gap-px bg-white/10 sm:grid-cols-3 lg:grid-cols-4">
              {[1, 2, 3, 4, 5, 6, 7, 8].map((item) => <div key={item} className="h-32 animate-pulse bg-white/[0.04]" />)}
            </div>
          ) : projects.length ? <AtlasCategoryBrowser projects={projects} /> : (
            <div className="p-12 text-center"><p className="font-display text-3xl text-foreground">Aucun projet visible.</p></div>
          )}
        </div>
      </section>
    </main>
  );
}