import React, { useState } from "react";
import StampHeader from "@/components/stamp-studio-pro/StampHeader";
import StampCanvas from "@/components/stamp-studio-pro/StampCanvas";
import SealedOrientationIntro from "@/components/stamp-studio-pro/SealedOrientationIntro";
import SoberOrientationNotice from "@/components/stamp-studio-pro/SoberOrientationNotice";
import EntryModePanel from "@/components/stamp-studio-pro/EntryModePanel";
import OfficialOrientation from "@/components/stamp-studio-pro/OfficialOrientation";
import ProtectionSections from "@/components/stamp-studio-pro/ProtectionSections";
import PhotoPanel from "@/components/stamp-studio-pro/panels/PhotoPanel";
import TextPanel from "@/components/stamp-studio-pro/panels/TextPanel";
import OrientationPanel from "@/components/stamp-studio-pro/panels/OrientationPanel";
import CodePanel from "@/components/stamp-studio-pro/panels/CodePanel";
import { initialStampStudioState } from "@/lib/stampStudioState";

const steps = [
  { id: "photo", label: "Portrait" },
  { id: "text", label: "Texte" },
  { id: "seal", label: "Validation" }
];

export default function StampStudio() {
  const [stamp, setStamp] = useState(initialStampStudioState);
  const [step, setStep] = useState(0);
  const update = (field, value) => setStamp((prev) => ({ ...prev, [field]: value }));
  const orientationMode = ["concern", "situation"].includes(stamp.entry_mode);
  const hasPortrait = stamp.portrait_mode === "no_face" || !!stamp.generated_url;
  const hasOrientation = !!stamp.situation_type || !!stamp.short_timeline || !!stamp.declared_facts;
  const canContinue = step === 0 ? hasPortrait && stamp.image_authorized : step === 1 ? (orientationMode ? hasOrientation : !!stamp.title && !!stamp.note) : true;

  return (
    <main className="min-h-screen bg-black text-white">
      <StampHeader />
      <div className="space-y-5 px-5 py-5 sm:px-10">
        <SealedOrientationIntro />
        <SoberOrientationNotice />
        <EntryModePanel stamp={stamp} update={update} />
      </div>
      <div className="grid min-h-[calc(100vh-8rem)] lg:grid-cols-[30rem_minmax(0,1fr)]">
        <aside className="space-y-5 border-t border-white/10 p-5 lg:border-r lg:border-t-0 lg:p-6">
          <section className="rounded-[2rem] border border-white/10 bg-white/[0.035] p-5">
            <p className="text-xs uppercase tracking-[0.24em] text-white/40">Création guidée</p>
            <h2 className="mt-2 font-display text-3xl font-semibold tracking-[-0.05em] text-white">AIME Pré-Plainte / Timbre de Protection</h2>
            <div className="mt-5 grid grid-cols-3 gap-2">
              {steps.map((item, index) => (
                <button key={item.id} onClick={() => setStep(index)} className={`rounded-full px-3 py-2 text-[0.62rem] uppercase tracking-[0.16em] transition ${step === index ? "bg-white text-black" : "border border-white/10 text-white/50"}`}>
                  {index + 1}. {item.label}
                </button>
              ))}
            </div>
            <p className="mt-4 text-sm leading-6 text-white/58">Transformer une parole ou une intention en objet structuré : code, date, mémoire, orientation et validation humaine obligatoire. AIME ne reçoit jamais de plainte officielle.</p>
          </section>

          {step === 0 && <PhotoPanel stamp={stamp} update={update} onComplete={() => setStep(1)} />}
          {step === 1 && (orientationMode ? <OrientationPanel stamp={stamp} update={update} /> : <TextPanel stamp={stamp} update={update} />)}
          {step === 2 && <CodePanel stamp={stamp} update={update} />}

          <div className="grid grid-cols-2 gap-3">
            <button onClick={() => setStep(Math.max(0, step - 1))} disabled={step === 0} className="min-h-12 rounded-full border border-white/15 text-sm text-white/75 disabled:opacity-35">Retour</button>
            <button onClick={() => setStep(Math.min(steps.length - 1, step + 1))} disabled={!canContinue || step === steps.length - 1} className="min-h-12 rounded-full bg-white text-sm font-medium text-black disabled:opacity-35">Continuer</button>
          </div>
        </aside>
        <StampCanvas stamp={stamp} />
      </div>
      <section className="space-y-5 px-5 pb-10 sm:px-10">
        <ProtectionSections />
        <OfficialOrientation />
      </section>
    </main>
  );
}