import React from "react";
import { Navigate } from "react-router-dom";

export default function LeCreateur() {
  return <Navigate to="/magazine#createateur" replace />;
}