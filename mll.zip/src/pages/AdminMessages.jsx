import React, { useEffect, useState } from "react";
import { Navigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Loader2 } from "lucide-react";
import AdminShell from "@/components/admin/AdminShell";
import BusinessProfileForm from "@/components/admin/BusinessProfileForm";
import MessageRequestCard from "@/components/admin/MessageRequestCard";
import { ADMIN_ACCESS_KEY } from "@/components/portfolio/projectConstants";

export default function AdminMessages() {
  const [messages, setMessages] = useState([]);
  const [documents, setDocuments] = useState([]);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const unlocked = localStorage.getItem(ADMIN_ACCESS_KEY) === "true";

  const load = async () => {
    const [messageData, documentData, profileData] = await Promise.all([
      base44.entities.ContactMessage.list("-created_date", 200),
      base44.entities.CommercialDocument.list("-created_date", 500),
      base44.entities.BusinessProfile.list("-updated_date", 1)
    ]);
    setMessages(messageData);
    setDocuments(documentData);
    setProfile(profileData[0] || null);
    setLoading(false);
  };

  useEffect(() => { if (unlocked) load(); }, [unlocked]);
  if (!unlocked) return <Navigate to="/admin" replace />;

  const markDone = async (message) => {
    await base44.entities.ContactMessage.update(message.id, { status: "traité" });
    load();
  };

  return (
    <AdminShell title="Demandes reçues">
      <BusinessProfileForm profile={profile} onSaved={load} />
      {loading ? (
        <div className="flex h-80 items-center justify-center rounded-[2rem] border border-white/10 bg-card/50"><Loader2 className="h-8 w-8 animate-spin text-muted-foreground" /></div>
      ) : messages.length ? (
        <div className="grid gap-4">{messages.map((message) => <MessageRequestCard key={message.id} message={message} profile={profile} documents={documents} onCreated={load} onDone={markDone} />)}</div>
      ) : (
        <div className="rounded-[2rem] border border-white/10 bg-card/50 p-12 text-center"><p className="font-display text-3xl text-foreground">Aucune demande pour le moment.</p></div>
      )}
    </AdminShell>
  );
}