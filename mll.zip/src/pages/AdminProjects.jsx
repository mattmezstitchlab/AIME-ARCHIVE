import React, { useEffect, useState } from "react";
import { Link, Navigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Eye, EyeOff, Image, Loader2, Pencil, Plus, Star, Trash2 } from "lucide-react";
import AdminShell from "@/components/admin/AdminShell";
import { ADMIN_ACCESS_KEY, sortProjects } from "@/components/portfolio/projectConstants";
import { buildMobileHomepagePrompt } from "@/components/admin/projectStudio";
import AdminOverviewStats from "@/components/admin/AdminOverviewStats";
import ProjectDuplicateAudit from "@/components/admin/ProjectDuplicateAudit";

export default function AdminProjects() {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [generatingVisualId, setGeneratingVisualId] = useState(null);
  const unlocked = localStorage.getItem(ADMIN_ACCESS_KEY) === "true";

  const load = async () => {
    const data = await base44.entities.Project.list("display_order", 1000);
    setProjects(sortProjects(data));
    setLoading(false);
  };

  useEffect(() => {
    if (unlocked) load();
  }, [unlocked]);

  if (!unlocked) return <Navigate to="/admin" replace />;

  const updateProject = async (project, updates) => {
    await base44.entities.Project.update(project.id, { ...updates, updated_at: new Date().toISOString() });
    load();
  };

  const generateProjectVisual = async (project) => {
    setGeneratingVisualId(project.id);
    try {
      const result = await base44.integrations.Core.GenerateImage({
        prompt: buildMobileHomepagePrompt(project)
      });
      await updateProject(project, { main_screenshot_url: result.url });
    } finally {
      setGeneratingVisualId(null);
    }
  };

  const deleteProject = async (project) => {
    if (!window.confirm(`Supprimer définitivement “${project.title}” ?`)) return;
    await base44.entities.Project.delete(project.id);
    load();
  };

  return (
    <AdminShell title="Gestion des projets" action={<Link to="/admin/projects/new" className="inline-flex min-h-11 items-center gap-2 rounded-full bg-primary px-5 text-sm font-medium text-primary-foreground transition-colors duration-200 hover:bg-accent hover:text-accent-foreground"><Plus className="h-4 w-4" /> Nouveau projet</Link>}>
      {loading ? (
        <div className="h-80 animate-pulse rounded-[2rem] bg-white/[0.04]" />
      ) : (
        <>
          <AdminOverviewStats projects={projects} />
          <ProjectDuplicateAudit projects={projects} />
          <div className="overflow-hidden rounded-[2rem] border border-white/10 bg-black/65 backdrop-blur-xl">
          <div className="grid grid-cols-[1.4fr_0.7fr_0.7fr_0.6fr_1fr] gap-4 border-b border-white/10 px-6 py-4 text-xs uppercase tracking-[0.18em] text-muted-foreground max-lg:hidden">
            <span>Projet</span><span>Catégorie</span><span>Statut</span><span>Ordre</span><span>Actions</span>
          </div>
          <div className="divide-y divide-white/10">
            {projects.map((project) => (
              <article key={project.id} className="grid gap-4 px-6 py-5 lg:grid-cols-[1.4fr_0.7fr_0.7fr_0.6fr_1fr] lg:items-center">
                <div className="flex min-w-0 items-center gap-4">
                  <div className="h-16 w-24 overflow-hidden rounded-xl border border-white/10 bg-white/[0.04]">
                    {project.main_screenshot_url && <img src={project.main_screenshot_url} alt="" className="h-full w-full object-cover" loading="lazy" />}
                  </div>
                  <div className="min-w-0">
                    <h2 className="truncate font-display text-xl text-foreground">{project.title}</h2>
                    <p className="truncate text-sm text-muted-foreground">/{project.slug}</p>
                  </div>
                </div>
                <span className="text-sm text-muted-foreground">{project.category}</span>
                <span className="text-sm text-muted-foreground">{project.status}</span>
                <input aria-label={`Ordre de ${project.title}`} type="number" value={project.display_order || 0} onChange={(e) => updateProject(project, { display_order: Number(e.target.value) })} className="min-h-11 w-24 rounded-xl border border-white/10 bg-white/[0.04] px-3 text-foreground" />
                <div className="flex flex-wrap gap-2">
                  <button onClick={() => updateProject(project, { visible: !project.visible })} className="min-h-11 rounded-full border border-white/10 px-3 text-muted-foreground" aria-label="Basculer visibilité">{project.visible ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}</button>
                  <button onClick={() => updateProject(project, { featured: !project.featured })} className={`min-h-11 rounded-full border px-3 ${project.featured ? "border-accent text-accent" : "border-white/10 text-muted-foreground"}`} aria-label="Mettre en avant"><Star className="h-4 w-4" /></button>
                  <button onClick={() => generateProjectVisual(project)} disabled={generatingVisualId === project.id} className="min-h-11 rounded-full border border-white/10 px-3 text-muted-foreground disabled:opacity-60" aria-label="Générer un visuel IA">{generatingVisualId === project.id ? <Loader2 className="h-4 w-4 animate-spin" /> : <Image className="h-4 w-4" />}</button>
                  <Link to={`/admin/projects/${project.id}/edit`} className="inline-flex min-h-11 items-center rounded-full border border-white/10 px-3 text-muted-foreground" aria-label="Modifier"><Pencil className="h-4 w-4" /></Link>
                  <button onClick={() => deleteProject(project)} className="min-h-11 rounded-full border border-destructive/30 px-3 text-destructive" aria-label="Supprimer"><Trash2 className="h-4 w-4" /></button>
                </div>
              </article>
            ))}
          </div>
        </div>
        </>
      )}
    </AdminShell>
  );
}