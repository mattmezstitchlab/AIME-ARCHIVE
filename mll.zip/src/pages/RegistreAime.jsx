import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import HeroReliefAnimation from "@/components/portfolio/HeroReliefAnimation";
import RegistreGeneratorWindow from "@/components/registre/RegistreGeneratorWindow";
import RegistreGeneratedProject from "@/components/registre/RegistreGeneratedProject";

export default function RegistreAime() {
  const [generatedProject, setGeneratedProject] = useState(null);

  useEffect(() => {
    if (!generatedProject) return;
    setTimeout(() => document.getElementById("fiche-generee")?.scrollIntoView({ behavior: "smooth", block: "start" }), 150);
  }, [generatedProject]);

  return (
    <main className="min-h-screen overflow-hidden bg-black text-white">
      <section className="relative flex min-h-screen flex-col px-5 py-8 sm:px-8 lg:px-12">
        <div className="absolute inset-0 z-0 overflow-hidden">
          <HeroReliefAnimation className="fixed inset-0 h-screen w-full opacity-75" />
          <div className="absolute inset-0 bg-black/62" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_22%,rgba(255,255,255,0.18),transparent_28%)]" />
          <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-black via-black/70 to-transparent" />
        </div>

        <Link to="/" className="relative z-10 inline-flex min-h-11 w-fit items-center gap-2 rounded-full border border-white/20 bg-white/10 px-4 text-sm backdrop-blur-xl transition-colors hover:border-white/40">
          <ArrowLeft className="h-4 w-4" /> Retour
        </Link>

        <div className="relative z-10 flex w-full flex-1 items-center justify-center py-14">
          <RegistreGeneratorWindow onStart={() => setGeneratedProject(null)} onGenerated={setGeneratedProject} />
        </div>
      </section>
      <RegistreGeneratedProject project={generatedProject} />
    </main>
  );
}