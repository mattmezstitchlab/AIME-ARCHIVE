import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, ArrowUpRight, Database, MessageCircle, PenLine } from "lucide-react";
import { base44 } from "@/api/base44Client";
import HeroReliefAnimation from "@/components/portfolio/HeroReliefAnimation";

export default function MonEspace() {
  const [projects, setProjects] = useState([]);

  useEffect(() => {
    const loadProjects = async () => {
      const data = await base44.entities.Project.filter({ visible: true }, "display_order", 200);
      setProjects(data);
    };
    loadProjects();
  }, []);

  const flagshipCount = projects.filter((project) => project.featured).length;
  const familyCount = new Set(projects.map((project) => project.category).filter(Boolean)).size;

  return (
    <main className="relative min-h-screen overflow-hidden bg-black px-5 py-8 text-white sm:px-8 lg:px-12">
      <div className="absolute inset-0 z-0 overflow-hidden">
        <HeroReliefAnimation className="fixed inset-0 h-screen w-full opacity-70" />
        <div className="absolute inset-0 bg-black/62" />
      </div>
      <div className="relative z-10 mx-auto max-w-7xl">
        <Link to="/" className="inline-flex min-h-11 items-center gap-2 rounded-full border border-white/20 bg-white/10 px-4 text-sm backdrop-blur-xl">
          <ArrowLeft className="h-4 w-4" /> Retour
        </Link>
        <section className="max-w-5xl py-20">
          <p className="text-xs uppercase tracking-[0.32em] text-white/60">Mon espace</p>
          <h1 className="mt-6 font-display text-6xl font-semibold leading-[0.88] tracking-[-0.07em] sm:text-8xl">Piloter l’Atlas AIME.</h1>
          <p className="mt-8 max-w-3xl text-xl leading-9 text-white/78">Vue rapide du corpus importé, accès aux fiches, messages et outils d’administration.</p>
        </section>
        <section className="grid gap-4 md:grid-cols-3">
          {[{label: "Projets", value: projects.length}, {label: "Familles", value: familyCount}, {label: "Phares", value: flagshipCount}].map((item) => (
            <div key={item.label} className="rounded-[2rem] border border-white/10 bg-white/[0.06] p-6 backdrop-blur-2xl">
              <p className="text-xs uppercase tracking-[0.24em] text-white/45">{item.label}</p>
              <p className="mt-4 font-display text-5xl font-semibold">{item.value}</p>
            </div>
          ))}
        </section>
        <section className="mt-6 grid gap-4 md:grid-cols-3">
          <Link to="/admin/projects" className="rounded-[2rem] border border-white/10 bg-white p-6 text-black"><Database className="h-5 w-5" /><p className="mt-6 font-semibold">Administrer les projets</p></Link>
          <Link to="/admin/messages" className="rounded-[2rem] border border-white/10 bg-white/[0.08] p-6 text-white"><MessageCircle className="h-5 w-5" /><p className="mt-6 font-semibold">Lire les messages</p></Link>
          <Link to="/contact" className="rounded-[2rem] border border-white/10 bg-white/[0.08] p-6 text-white"><PenLine className="h-5 w-5" /><p className="mt-6 font-semibold">Déposer une demande</p></Link>
        </section>
      </div>
    </main>
  );
}