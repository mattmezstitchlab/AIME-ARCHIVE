import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ADMIN_ACCESS_KEY, DEFAULT_ADMIN_CODE } from "@/components/portfolio/projectConstants";
import HeroReliefAnimation from "@/components/portfolio/HeroReliefAnimation";

export default function AdminLogin() {
  const [code, setCode] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const submit = (event) => {
    event.preventDefault();
    if (code.trim() === DEFAULT_ADMIN_CODE) {
      localStorage.setItem(ADMIN_ACCESS_KEY, "true");
      navigate("/admin/projects");
    } else {
      setError("Code incorrect. Essayez MEZLAB2026 pour cette version locale.");
    }
  };

  return (
    <main className="relative flex min-h-screen items-center justify-center overflow-hidden bg-black px-5 text-foreground">
      <HeroReliefAnimation className="absolute inset-0 h-full w-full opacity-55" />
      <div className="absolute inset-0 bg-black/45" aria-hidden="true" />
      <div className="relative z-10 w-full max-w-md rounded-[2rem] border border-white/15 bg-black/65 p-8 shadow-[0_30px_120px_rgba(0,0,0,0.8)] backdrop-blur-2xl">
        <Link to="/" className="mb-6 inline-flex min-h-11 items-center rounded-full border border-white/10 px-5 text-sm text-muted-foreground transition-colors duration-200 hover:border-white/30 hover:text-foreground">Retour au site</Link>
        <p className="text-sm uppercase tracking-[0.28em] text-accent">Accès studio</p>
        <h1 className="mt-5 font-display text-5xl font-semibold tracking-[-0.06em] text-foreground">Admin AIME</h1>
        <p className="mt-5 text-sm leading-6 text-muted-foreground">Interface protégée par code secret pour gérer les pages de site.</p>
        <form onSubmit={submit} className="mt-8 space-y-4">
          <label htmlFor="admin-code" className="block text-sm text-muted-foreground">Code secret</label>
          <input id="admin-code" type="password" value={code} onChange={(e) => setCode(e.target.value)} className="min-h-12 w-full rounded-2xl border border-white/10 bg-white/[0.04] px-4 text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring" autoFocus />
          {error && <p className="text-sm text-destructive">{error}</p>}
          <button type="submit" className="min-h-12 w-full rounded-full bg-primary px-6 font-medium text-primary-foreground transition-colors duration-200 hover:bg-accent hover:text-accent-foreground">Entrer dans AIME</button>
        </form>
      </div>
    </main>
  );
}