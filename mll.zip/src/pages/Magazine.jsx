import React from "react";
import { Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import MagazineHero from "@/components/magazine/MagazineHero";
import MagazineContents from "@/components/magazine/MagazineContents";
import MagazineArticleSection from "@/components/magazine/MagazineArticleSection";
import MagazineAgentGrid from "@/components/magazine/MagazineAgentGrid";
import MagazineColophonPage from "@/components/magazine/MagazineColophonPage";
import { magazineChapters as chapters } from "@/components/magazine/magazineData";

const agents = [
  {
    name: "CERISE",
    role: "Gardienne de l’accueil sensible",
    quote: "Avant de raconter, il faut être accueilli sans être jugé.",
    text: "Cerise ouvre l’espace AIME. Elle reçoit les présences, pose le cadre, rappelle les limites et veille à ce qu’aucune parole sensible ne soit forcée, exposée ou confondue avec une démarche officielle.",
    stamp: "AIME-ACCUEIL-001",
    image: "https://media.base44.com/images/public/6a26f7e77a120b841e3ff78d/5b528d968_generated_image.png",
  },
  {
    name: "VINZ",
    role: "Veilleur d’orientation",
    quote: "Orienter, ce n’est pas décider à la place de quelqu’un. C’est rendre les chemins lisibles.",
    text: "Vinz distingue l’urgence, l’intention, le besoin de relais et la nécessité d’une validation humaine. Il aide à préparer une parole structurée sans jamais remplacer les services compétents.",
    stamp: "AIME-ORIENT-002",
    image: "https://media.base44.com/images/public/6a26f7e77a120b841e3ff78d/30d97bdb2_generated_image.png",
  },
  {
    name: "MARLON",
    role: "Ordonnateur des faits",
    quote: "Un fait fragile mérite une forme claire.",
    text: "Marlon classe les dates, les éléments disponibles, les manques, les ressentis et les étapes. Il ne juge pas : il remet de l’ordre pour que la mémoire reste compréhensible et transmissible.",
    stamp: "AIME-FAITS-003",
    image: "https://media.base44.com/images/public/6a26f7e77a120b841e3ff78d/bba764340_generated_image.png",
  },
  {
    name: "YUNA",
    role: "Archiviste de la mémoire protégée",
    quote: "Une mémoire n’est pas un stockage. C’est une promesse tenue dans le temps.",
    text: "Yuna garde les traces, les timbres, les récits privés et les présences publiques. Elle sépare ce qui peut être montré de ce qui doit rester scellé, relu ou transmis avec prudence.",
    stamp: "AIME-MEMOIRE-004",
    image: "https://media.base44.com/images/public/6a26f7e77a120b841e3ff78d/fa0a0249f_generated_image.png",
  },
  {
    name: "OLIVE",
    role: "Passeuse de liens humains",
    quote: "Protéger, c’est aussi savoir vers qui se tourner.",
    text: "Olive relie les personnes, les proches, les partenaires et les relais utiles. Elle garde un ton simple, humain et non institutionnel, sans jamais exposer ce qui relève de l’intime.",
    stamp: "AIME-RELAIS-005",
    image: "https://media.base44.com/images/public/6a26f7e77a120b841e3ff78d/59a94a5e0_generated_image.png",
  },
  {
    name: "SOLAL",
    role: "Architecte du scellé AIME",
    quote: "Une architecture tient quand elle protège ce qu’elle contient.",
    text: "Solal relie le Registre, le Studio Stamp, les validations humaines et les espaces publics. Il veille à ce que chaque trace ait sa juste place : visible, privée, partenaire ou scellée.",
    stamp: "AIME-SCELLE-006",
    image: "https://media.base44.com/images/public/6a26f7e77a120b841e3ff78d/cb375dd09_generated_image.png",
  },
];

export default function Magazine() {
  return (
    <main className="min-h-screen bg-black">
      <Link to="/" className="fixed left-5 top-5 z-50 inline-flex items-center gap-2 rounded-full border border-black/10 bg-[#f4efe4]/80 px-4 py-2 text-xs font-black uppercase tracking-[0.18em] text-stone-950 backdrop-blur-xl transition hover:bg-stone-950 hover:text-white">
        <ArrowLeft className="h-4 w-4" /> Accueil
      </Link>
      <MagazineHero />
      <MagazineContents />
      {chapters.slice(0, 4).map((chapter) => <MagazineArticleSection key={chapter.id} {...chapter} />)}
      <MagazineAgentGrid agents={agents} />
      {chapters.slice(4).map((chapter) => <MagazineArticleSection key={chapter.id} {...chapter} />)}
      <MagazineColophonPage />
    </main>
  );
}