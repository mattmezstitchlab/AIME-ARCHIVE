import React, { useEffect, useState } from "react";
import { Link, Navigate, useParams } from "react-router-dom";
import { ArrowLeft, Mail, Printer } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { ADMIN_ACCESS_KEY } from "@/components/portfolio/projectConstants";
import CommercialDocumentView from "@/components/admin/CommercialDocumentView";

export default function AdminCommercialDocument() {
  const { id } = useParams();
  const [document, setDocument] = useState(null);
  const [loading, setLoading] = useState(true);
  const unlocked = localStorage.getItem(ADMIN_ACCESS_KEY) === "true";
  useEffect(() => { if (unlocked) base44.entities.CommercialDocument.get(id).then((data) => { setDocument(data); setLoading(false); }); }, [id, unlocked]);
  if (!unlocked) return <Navigate to="/admin" replace />;
  if (loading) return <main className="min-h-screen bg-black p-12 text-white">Chargement…</main>;
  if (!document) return <main className="min-h-screen bg-black p-12 text-white">Document introuvable.</main>;
  const subject = encodeURIComponent(`${document.title} ${document.number}`);
  return (
    <main className="min-h-screen bg-black p-4 sm:p-8 print:bg-white print:p-0">
      <nav className="mx-auto mb-6 flex max-w-4xl flex-wrap gap-3 print:hidden"><Link to="/admin/messages" className="inline-flex min-h-11 items-center gap-2 rounded-full border border-white/15 px-5 text-sm text-white"><ArrowLeft className="h-4 w-4" /> Demandes</Link><button onClick={() => window.print()} className="inline-flex min-h-11 items-center gap-2 rounded-full bg-white px-5 text-sm text-black"><Printer className="h-4 w-4" /> Imprimer / PDF</button><a href={`mailto:${document.recipient?.email}?subject=${subject}`} className="inline-flex min-h-11 items-center gap-2 rounded-full border border-white/15 px-5 text-sm text-white"><Mail className="h-4 w-4" /> Préparer la réponse</a></nav>
      <CommercialDocumentView document={document} />
    </main>
  );
}