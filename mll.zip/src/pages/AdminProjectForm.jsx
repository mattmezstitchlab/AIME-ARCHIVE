import React, { useEffect, useState } from "react";
import { Navigate, useNavigate, useParams } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import AdminShell from "@/components/admin/AdminShell";
import ProjectEditor from "@/components/admin/ProjectEditor";
import { ADMIN_ACCESS_KEY } from "@/components/portfolio/projectConstants";

export default function AdminProjectForm() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [project, setProject] = useState(null);
  const [loading, setLoading] = useState(!!id);
  const unlocked = localStorage.getItem(ADMIN_ACCESS_KEY) === "true";

  useEffect(() => {
    const load = async () => {
      if (!id || !unlocked) return;
      const data = await base44.entities.Project.filter({ id });
      setProject(data[0] || null);
      setLoading(false);
    };
    load();
  }, [id, unlocked]);

  if (!unlocked) return <Navigate to="/admin" replace />;

  const save = async (payload) => {
    if (id) {
      await base44.entities.Project.update(id, payload);
    } else {
      await base44.entities.Project.create(payload);
    }
    navigate("/admin/projects");
  };

  return (
    <AdminShell title={id ? "Modifier un projet" : "Ajouter un projet"}>
      {loading ? <div className="h-96 animate-pulse rounded-[2rem] bg-white/[0.04]" /> : <ProjectEditor initialProject={project} onSave={save} />}
    </AdminShell>
  );
}