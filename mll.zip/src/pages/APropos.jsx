import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import FounderMagazinePage from "@/components/founder-magazine/FounderMagazinePage";
import FounderIntroSpread from "@/components/founder-magazine/FounderIntroSpread";
import { CURATED_PROJECT_SLUGS } from "@/components/portfolio/projectCoherence";

export default function APropos() {
  const [page, setPage] = useState(null);
  const [projects, setProjects] = useState(null);
  useEffect(() => {
    Promise.allSettled([base44.entities.FounderPage.list("-updated_at", 1), base44.entities.Project.filter({ visible: true }, "display_order", 1000)]).then(([pageResult, projectResult]) => {
      const rows = pageResult.status === "fulfilled" ? pageResult.value : [];
      const items = projectResult.status === "fulfilled" ? projectResult.value : [];
      const curated = CURATED_PROJECT_SLUGS.map((slug) => items.find((item) => item.slug === slug)).filter(Boolean);
      setPage(rows[0] || false);
      setProjects(curated.length ? curated : items.filter((item) => item.featured));
    });
    return base44.entities.FounderPage.subscribe((event) => { if (event.type === "delete") setPage(false); else setPage((current) => ({ ...(current || {}), ...event.data })); });
  }, []);
  if (page === null || projects === null) return <main className="flex min-h-screen items-center justify-center bg-background text-foreground"><div className="text-center"><div className="mx-auto h-8 w-8 animate-spin rounded-full border-2 border-white/20 border-t-white" /><p className="mt-4 text-sm text-white/60">Chargement du portrait…</p></div></main>;
  if (!page) return <main className="min-h-screen overflow-hidden bg-background text-foreground"><FounderIntroSpread /><div className="flex min-h-[50svh] items-center justify-center px-5 py-16 text-center"><div><p className="font-display text-4xl font-semibold tracking-[-0.05em]">La biographie sera bientôt disponible.</p><Link to="/" className="mt-8 inline-flex min-h-11 items-center rounded-full border border-white/20 bg-black/30 px-5 text-sm backdrop-blur-xl">Retour à l’accueil</Link></div></div></main>;
  return <FounderMagazinePage page={page} projects={projects} />;
}