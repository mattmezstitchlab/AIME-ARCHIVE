import React, { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { ArrowLeft, ArrowUpRight, ExternalLink } from "lucide-react";

const DetailBlock = ({ title, children }) => (
  <section className="min-w-0 border-t border-white/30 pt-4">
    <p className="text-[0.52rem] font-black uppercase tracking-[0.2em] text-white/45">{title}</p>
    <div className="mt-3 break-words text-xs leading-5 text-white/70">{children}</div>
  </section>
);

export default function ProjectDetail() {
  const { slug } = useParams();
  const [project, setProject] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeVisual, setActiveVisual] = useState(0);

  useEffect(() => {
    const loadProject = async () => {
      const results = await base44.entities.Project.filter({ slug, visible: true });
      setProject(results[0] || null);
      setActiveVisual(0);
      setLoading(false);
    };
    loadProject();
  }, [slug]);

  useEffect(() => {
    if (!project) return;
    const imageCount = [project.main_screenshot_url, ...(project.gallery || []).map((item) => item?.url)].filter(Boolean).slice(0, 3).length;
    if (imageCount <= 1) return;
    const timer = setInterval(() => setActiveVisual((current) => (current + 1) % imageCount), 3000);
    return () => clearInterval(timer);
  }, [project?.id]);

  if (loading) {
    return <main className="min-h-screen bg-background p-8 text-foreground"><div className="mx-auto h-[70vh] max-w-7xl animate-pulse rounded-[2rem] bg-white/[0.04]" /></main>;
  }

  if (!project) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-background p-8 text-center text-foreground">
        <div>
          <p className="font-display text-5xl">Projet introuvable</p>
          <Link to="/" className="mt-8 inline-flex min-h-11 items-center rounded-full border border-white/10 px-5 text-sm text-accent">Retour à la galerie</Link>
        </div>
      </main>
    );
  }

  const visuals = [
    { url: project.main_screenshot_url, title: "Vision", description: project.long_description || project.short_description },
    ...(project.gallery || []),
  ].filter((item, index, array) => item?.url && array.findIndex((candidate) => candidate.url === item.url) === index).slice(0, 3);
  const activeItem = visuals[activeVisual] || visuals[0];

  return (
    <main className="min-h-screen bg-background text-foreground">
      <section className="overflow-hidden bg-black px-5 py-5 sm:px-8 lg:px-12">
        <div className="relative mx-auto min-h-[calc(100svh-2.5rem)] max-w-7xl overflow-hidden bg-card">
          {activeItem?.url ? <img src={activeItem.url} alt={`Visuel ${activeItem.title || project.title}`} className="absolute inset-0 h-full w-full object-cover object-center" /> : <div className="absolute inset-0 bg-[radial-gradient(circle_at_35%_20%,rgba(255,255,255,0.20),transparent_34%),linear-gradient(135deg,#111827,#020617)]" />}
          <div className="absolute inset-0 bg-gradient-to-b from-black/45 via-black/25 to-black/90" aria-hidden="true" />
          <div className="relative z-10 flex min-h-[calc(100svh-2.5rem)] flex-col">
            <div className="p-4 sm:p-6">
              <Link to="/" className="inline-flex min-h-11 items-center gap-2 px-2 text-sm text-white/75 transition-colors hover:text-white"><ArrowLeft className="h-4 w-4" /> Retour</Link>
            </div>
            <div className="mt-auto max-w-5xl px-5 pb-10 pt-20 sm:px-8 sm:pb-12 lg:px-12">
              <div className="mb-6 flex flex-wrap gap-2">
                {[project.category, project.status, project.year, project.project_type, project.maturity_level].filter(Boolean).map((item) => <span key={item} className="rounded-full bg-black/35 px-3 py-1 text-xs text-white/80 backdrop-blur-xl">{item}</span>)}
              </div>
              <h1 className="max-w-5xl break-words font-display text-4xl font-semibold leading-[0.9] tracking-[-0.06em] text-white sm:text-6xl lg:text-7xl">{project.title}</h1>
              <p className="mt-6 max-w-2xl text-base leading-7 text-white/80 sm:text-lg">{project.short_description}</p>
              {activeItem?.description && <p className="mt-4 max-w-2xl text-sm leading-6 text-white/65">{activeItem.description}</p>}
              <div className="mt-8 flex flex-wrap gap-3">
                {project.url && <a href={project.url} target="_blank" rel="noopener noreferrer" className="inline-flex min-h-12 items-center gap-3 rounded-full bg-white px-6 text-sm font-medium text-black">Ouvrir le site <ArrowUpRight className="h-4 w-4" /></a>}
                {project.demo_url && <a href={project.demo_url} target="_blank" rel="noopener noreferrer" className="inline-flex min-h-12 items-center gap-3 rounded-full bg-black/45 px-6 text-sm font-medium text-white backdrop-blur-xl">Voir la démo <ArrowUpRight className="h-4 w-4" /></a>}
              </div>
            </div>
            {visuals.length > 0 && <nav className="grid grid-cols-3 bg-black/75 backdrop-blur-2xl" aria-label="Visuels du projet">
              {visuals.map((item, index) => <button key={item.url} onClick={() => setActiveVisual(index)} className={`min-h-16 min-w-0 px-3 text-center transition-colors ${activeVisual === index ? "bg-white/15 text-white" : "text-white/55 hover:bg-white/10 hover:text-white"}`}><span className="text-[0.56rem] font-bold uppercase tracking-[0.2em]">0{index + 1}</span><span className="ml-2 text-xs font-semibold sm:text-sm">{item.title || `Vue ${index + 1}`}</span></button>)}
            </nav>}
          </div>
        </div>
      </section>

      <section className="relative z-10 bg-black px-5 py-14 sm:px-8 lg:px-12">
        <div className="mx-auto max-w-7xl">
          <div className="mb-10 grid gap-6 lg:grid-cols-[0.75fr_1.25fr] lg:items-end">
            <p className="text-xs uppercase tracking-[0.28em] text-white/55">Fiche condensée</p>
            <p className="text-lg leading-8 text-white/75">Tous les textes du projet sont regroupés ici en colonnes courtes, sans répétition avec le hero.</p>
          </div>
          <div className="grid min-w-0 grid-cols-2 gap-4 md:grid-cols-4">
            <DetailBlock title="Problème résolu"><p>{project.problem || "À préciser."}</p></DetailBlock>
            <DetailBlock title="Solution proposée"><p>{project.solution || "À préciser."}</p></DetailBlock>
            <DetailBlock title="Présentation du projet"><p>{project.long_description || project.solution || "Une présentation détaillée sera bientôt disponible."}</p></DetailBlock>
            <DetailBlock title="Niveau d’automatisation"><p>{project.automation_level || "À préciser."}</p></DetailBlock>
            <DetailBlock title="Accessibilité intégrée"><p>{project.accessibility_integrated || project.accessibility_status || "Préparation et amélioration avec validation humaine."}</p></DetailBlock>
            <DetailBlock title="Widget accessibilité"><p>{project.accessibility_widget ? `Statut : ${project.accessibility_widget}` : "Prévu selon le projet."}</p></DetailBlock>
            <DetailBlock title="Évolutions possibles"><p>{project.possible_evolutions || project.mechanics?.next_evolutions || "À préciser."}</p></DetailBlock>
            <DetailBlock title="Avant / après"><p>{project.before_after || "À préciser."}</p></DetailBlock>
            <DetailBlock title="Fonctionnalités principales">
              <ul className="space-y-3">
                {(project.features || []).slice(0, 8).map((feature) => <li key={feature}>— {feature}</li>)}
              </ul>
            </DetailBlock>
            <DetailBlock title="Technologies utilisées">
              <div className="flex flex-wrap gap-2">
                {(project.technologies || []).map((tech) => <span key={tech} className="rounded-full border border-white/10 px-3 py-1 text-xs text-white/80">{tech}</span>)}
              </div>
            </DetailBlock>
            <DetailBlock title="Décision humaine / validation"><p>{project.human_validation || "Validation humaine conservée à chaque étape sensible."}</p></DetailBlock>
            <DetailBlock title="Préparation administrative"><p>Paiement : {project.payment_integrated || "non"} · Facture électronique / Pennylane : {project.e_invoice_status || "prévu"}</p></DetailBlock>
          </div>
        </div>
      </section>

      <footer className="relative z-10 border-t border-white/10 bg-black px-5 py-12 sm:px-8 lg:px-12">
        <div className="mx-auto flex max-w-7xl flex-col justify-between gap-6 sm:flex-row sm:items-center">
          <p className="font-display text-2xl text-foreground">AIME, Architecture intelligente de la mémoire ensemble.</p>
          <div className="flex flex-wrap gap-4">
            <Link to={`/contact?project=${encodeURIComponent(project.title)}&slug=${encodeURIComponent(project.slug)}`} className="inline-flex items-center gap-2 rounded-full bg-white px-5 py-3 text-sm font-medium text-black">Créer un projet similaire <ArrowUpRight className="h-4 w-4" /></Link>
            {project.url && <a href={project.url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 text-accent">Ouvrir le site <ExternalLink className="h-4 w-4" /></a>}
          </div>
        </div>
      </footer>
    </main>
  );
}