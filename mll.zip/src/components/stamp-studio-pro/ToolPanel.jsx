import React from "react";
import PhotoPanel from "./panels/PhotoPanel";
import TextPanel from "./panels/TextPanel";
import ColorPanel from "./panels/ColorPanel";
import FormatPanel from "./panels/FormatPanel";
import FramePanel from "./panels/FramePanel";
import PixellePanel from "./panels/PixellePanel";
import CodePanel from "./panels/CodePanel";

export default function ToolPanel({ activeTool, stamp, update }) {
  if (activeTool === "photo") return <PhotoPanel stamp={stamp} update={update} />;
  if (activeTool === "text") return <TextPanel stamp={stamp} update={update} />;
  if (activeTool === "style") return <ColorPanel stamp={stamp} update={update} />;
  if (activeTool === "frame") return <><FormatPanel stamp={stamp} update={update} /><FramePanel stamp={stamp} update={update} /></>;
  if (activeTool === "pixelle") return <PixellePanel stamp={stamp} update={update} />;
  return <CodePanel stamp={stamp} update={update} />;
}