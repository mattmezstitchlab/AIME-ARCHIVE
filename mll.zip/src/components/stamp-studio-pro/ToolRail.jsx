import React from "react";
import { Image, Type, Palette, Frame, Sparkles, BadgeCheck } from "lucide-react";

const tools = [
  { id: "photo", label: "Portrait", icon: Image },
  { id: "text", label: "Intention", icon: Type },
  { id: "frame", label: "Format", icon: Frame },
  { id: "style", label: "Papier", icon: Palette },
  { id: "pixelle", label: "Gravure", icon: Sparkles },
  { id: "seal", label: "Sceller", icon: BadgeCheck }
];

export default function ToolRail({ activeTool, onToolChange }) {
  return (
    <nav className="flex gap-2 overflow-x-auto border-b border-white/10 bg-black px-4 py-3 lg:flex-col lg:border-b-0 lg:border-r lg:px-3">
      {tools.map((tool, index) => {
        const Icon = tool.icon;
        return (
          <button key={tool.id} onClick={() => onToolChange(tool.id)} className={`inline-flex min-h-14 min-w-20 flex-col items-center justify-center gap-1 rounded-2xl px-3 text-[0.62rem] uppercase tracking-[0.12em] transition lg:min-w-0 ${activeTool === tool.id ? "bg-white text-black" : "border border-white/10 text-white/55 hover:text-white"}`}>
            <span className="text-[0.55rem] opacity-55">0{index + 1}</span><Icon className="h-4 w-4" /> {tool.label}
          </button>
        );
      })}
    </nav>
  );
}