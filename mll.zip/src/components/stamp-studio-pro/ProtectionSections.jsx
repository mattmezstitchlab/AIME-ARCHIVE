import React from "react";

const protections = [
  "aucune plainte officielle",
  "aucune enquête",
  "aucune décision automatique",
  "aucune qualification juridique automatique",
  "aucun score de danger",
  "aucun score de crédibilité",
  "confidentialité par défaut",
  "validation humaine obligatoire",
  "droit de suppression",
  "export privé",
  "publication impossible pour les situations sensibles"
];

export default function ProtectionSections() {
  return (
    <div className="grid gap-5 lg:grid-cols-3">
      <section className="rounded-[2rem] border border-white/10 bg-white/[0.035] p-6">
        <p className="text-xs uppercase tracking-[0.24em] text-white/40">Pourquoi un scellé ?</p>
        <p className="mt-4 text-sm leading-7 text-white/65">Le scellé AIME ne certifie pas les faits. Il conserve une version claire, datée et relisible d’une parole ou d’une intention. Il aide à préparer la transmission aux bons relais.</p>
      </section>
      <section className="rounded-[2rem] border border-white/10 bg-white/[0.035] p-6">
        <p className="text-xs uppercase tracking-[0.24em] text-white/40">Garanties</p>
        <ul className="mt-4 space-y-2 text-sm leading-6 text-white/65">
          {protections.map((item) => <li key={item}>• {item}</li>)}
        </ul>
      </section>
      <section className="rounded-[2rem] border border-white/10 bg-white/[0.035] p-6">
        <p className="text-xs uppercase tracking-[0.24em] text-white/40">Mode institutionnel — prototype</p>
        <p className="mt-4 text-sm leading-7 text-white/65">Une version institutionnelle pourrait permettre à des professionnels autorisés de relire des dossiers, générer des synthèses, repérer les pièces manquantes, préparer les relances et suivre les statuts, sans décision automatique.</p>
      </section>
    </div>
  );
}