import React from "react";

const statusLabels = {
  privé: "privé",
  en_attente_validation: "en attente de validation",
  public: "public"
};

export default function StampCanvas({ stamp }) {
  const image = stamp.portrait_mode === "no_face" ? "" : stamp.generated_url || stamp.photo_url;
  const status = stamp.status_label || statusLabels[stamp.status] || "privé";

  return (
    <section className="flex min-h-[38rem] items-start justify-center bg-[radial-gradient(circle_at_50%_0%,rgba(255,255,255,0.12),transparent_34%),#050505] px-5 pb-5 pt-6 sm:px-10 sm:pb-10 sm:pt-8">
      <div className="w-full max-w-md rounded-[1.7rem] bg-white p-3 text-black shadow-[0_34px_90px_rgba(0,0,0,0.45)] sm:p-4">
        <div className="relative z-[1] aspect-[3/4] overflow-hidden rounded-[1.35rem] bg-white shadow-inner">
          {image ? (
            <img src={image} alt="Portrait gravé façon timbre" className="absolute inset-0 h-full w-full object-cover object-top grayscale contrast-125" />
          ) : (
            <div className="absolute inset-0 flex items-center justify-center bg-white p-5 text-center font-mono text-[0.62rem] uppercase tracking-[0.18em] text-black/35">
              {stamp.portrait_mode === "no_face" ? "Présence sans visage identifiable" : "Importez une photo"}
            </div>
          )}

          <div className="absolute inset-x-4 top-4 z-20 flex items-center justify-between gap-4 font-mono text-[0.55rem] font-bold uppercase tracking-[0.18em] text-black/65 sm:text-[0.62rem]">
            <span>{stamp.code || "AIME-2026-000"}</span>
            <span>{new Date().toLocaleDateString("fr-FR")}</span>
          </div>

          <div className="absolute inset-x-4 bottom-4 z-20 rounded-[1rem] bg-white/82 p-3 backdrop-blur-sm">
            <p className="font-mono text-[0.5rem] font-bold uppercase tracking-[0.16em] text-black/45">{stamp.intention_type} · {stamp.visibility}</p>
            <h2 className="mt-1 font-display text-2xl font-semibold leading-none tracking-[-0.05em] text-black">{stamp.title}</h2>
            <p className="mt-2 line-clamp-3 text-[0.72rem] font-medium leading-4 text-black/68">{stamp.note}</p>
            <div className="mt-2 flex flex-wrap gap-1.5 font-mono text-[0.45rem] uppercase tracking-[0.14em] text-black/55">
              <span className="rounded-full bg-white px-2.5 py-1.5">{stamp.visibility}</span>
              <span className="rounded-full bg-white px-2.5 py-1.5">{status}</span>
            </div>
          </div>

          <div className="absolute inset-0 pointer-events-none bg-[linear-gradient(180deg,rgba(255,255,255,0.08)_0%,transparent_35%,rgba(0,0,0,0.08)_100%)]" />
        </div>
      </div>
    </section>
  );
}