import React from "react";

export default function SafetyNotice() {
  return (
    <div className="space-y-3">
      <section className="rounded-[1.6rem] border border-red-300/25 bg-red-950/25 p-4 text-sm leading-6 text-red-50">
        <p className="font-semibold">Danger immédiat : 17 ou 112.</p>
        <p>Urgence par SMS : 114.</p>
        <p>Enfance en danger : 119.</p>
        <p className="text-red-100/70">AIME n’est pas un service d’urgence.</p>
      </section>
      <section className="rounded-[1.6rem] border border-white/10 bg-white/[0.035] p-4 text-xs leading-5 text-white/55">
        AIME est un registre symbolique de présence, de mémoire et d’intention. Il ne remplace ni la justice, ni les associations, ni les professionnels de santé, ni les services d’urgence. L’IA aide à formuler, clarifier et orienter. La validation reste humaine.
      </section>
    </div>
  );
}