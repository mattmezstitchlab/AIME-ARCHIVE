import React from "react";

const layers = ["Portrait gravé", "Cadre dentelé", "Code AIME", "Date", "Note d’intention", "Validation humaine"];

export default function LayerStack() {
  return (
    <section className="rounded-[2rem] border border-white/10 bg-white/[0.035] p-5">
      <p className="text-xs uppercase tracking-[0.24em] text-white/40">Calques</p>
      <div className="mt-4 space-y-2">
        {layers.map((layer, index) => (
          <div key={layer} className="flex items-center justify-between rounded-2xl border border-white/10 px-4 py-3 text-sm text-white/65">
            <span>{layer}</span><span className="text-white/30">0{index + 1}</span>
          </div>
        ))}
      </div>
    </section>
  );
}