import React from "react";

export default function SealedOrientationIntro() {
  return (
    <section className="rounded-[2rem] border border-white/10 bg-white/[0.035] p-6 shadow-[0_24px_80px_rgba(0,0,0,0.35)] sm:p-8">
      <p className="text-xs uppercase tracking-[0.26em] text-white/40">Protection · Mémoire · Orientation</p>
      <h1 className="mt-3 font-display text-4xl font-semibold tracking-[-0.06em] text-white sm:text-5xl">AIME Scellé d’Orientation</h1>
      <p className="mt-5 text-sm leading-7 text-white/66 sm:text-base sm:leading-8">
        AIME ne remplace pas la justice. AIME ne reçoit pas une plainte officielle, ne mène pas d’enquête, ne désigne aucun coupable et ne rend aucune décision. AIME propose un outil de préparation, de mémoire et d’orientation. L’IA aide à structurer une parole : faits déclarés, dates, lieux, personnes concernées, éléments disponibles, pièces manquantes, niveau d’urgence ressenti et relais possibles. L’humain valide. Les services officiels restent seuls compétents pour recevoir une plainte, enquêter et juger.
      </p>
      <p className="mt-5 rounded-2xl border border-white/10 bg-white px-5 py-4 text-sm font-semibold leading-6 text-black">
        Le but : éviter qu’une parole se perde avant d’arriver au bon endroit.
      </p>
    </section>
  );
}