import React from "react";

const services = [
  ["17 / 112", "danger immédiat"],
  ["114", "urgence par SMS pour personnes ne pouvant pas parler ou entendre"],
  ["119", "enfance en danger"],
  ["PNAV / Ma Sécurité", "violences sexuelles, sexistes, conjugales ou intrafamiliales"],
  ["116006", "aide aux victimes"],
  ["3018", "cyberharcèlement et violences numériques"],
  ["PHAROS", "contenus illicites en ligne"]
];

export default function OfficialOrientation() {
  return (
    <section id="orientation-officielle" className="rounded-[2rem] border border-white/10 bg-white/[0.035] p-5">
      <p className="text-xs uppercase tracking-[0.24em] text-white/40">Orientation officielle</p>
      <div className="mt-4 grid gap-2">
        {services.map(([name, detail]) => (
          <div key={name} className="rounded-2xl border border-white/10 bg-black/25 p-3 text-sm leading-6 text-white/65">
            <span className="font-semibold text-white">{name}</span> : {detail}
          </div>
        ))}
      </div>
      <p className="mt-4 rounded-2xl border border-white/10 bg-black/30 p-4 text-sm font-semibold leading-6 text-white">L’IA prépare. L’humain valide. Les services officiels restent seuls compétents pour recevoir une plainte, enquêter et juger.</p>
    </section>
  );
}