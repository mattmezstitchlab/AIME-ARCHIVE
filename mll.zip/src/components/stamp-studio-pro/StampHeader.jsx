import React from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, ShieldCheck } from "lucide-react";

export default function StampHeader() {
  return (
    <header className="flex flex-col gap-5 border-b border-white/10 px-5 py-5 sm:px-8 lg:flex-row lg:items-center lg:justify-between lg:px-10">
      <div className="flex items-start gap-4">
        <Link to="/registre-aime" className="inline-flex min-h-11 items-center gap-2 rounded-full border border-white/15 px-4 text-sm text-white/75 transition hover:border-white/35">
          <ArrowLeft className="h-4 w-4" /> Registre
        </Link>
        <div>
          <p className="text-xs uppercase tracking-[0.3em] text-white/45">AIME® Timbre</p>
          <h1 className="mt-2 font-display text-4xl font-semibold tracking-[-0.06em] text-white sm:text-6xl">Créer un timbre AIME</h1>
        </div>
      </div>
      <div className="max-w-md rounded-2xl border border-white/10 bg-white/[0.035] p-4 text-sm leading-6 text-white/62">
        <ShieldCheck className="mb-2 h-5 w-5 text-white" /> Outil créatif symbolique : aucune promesse juridique, validation humaine obligatoire avant toute visibilité publique.
      </div>
    </header>
  );
}