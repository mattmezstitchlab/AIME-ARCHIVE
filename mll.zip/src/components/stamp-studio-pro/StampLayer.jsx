import React from "react";

export default function StampLayer({ name, children }) {
  return <div data-layer={name}>{children}</div>;
}