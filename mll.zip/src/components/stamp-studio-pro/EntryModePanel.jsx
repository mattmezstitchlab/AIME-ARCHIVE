import React from "react";

const modes = [
  { id: "support", label: "Je soutiens un mouvement" },
  { id: "symbolic", label: "Je crée une présence symbolique" },
  { id: "concern", label: "Je veux signaler une inquiétude" },
  { id: "situation", label: "Je suis concerné(e) par une situation" },
  { id: "professional", label: "Je suis professionnel / association / institution" }
];

const privateModes = ["concern", "situation"];

export default function EntryModePanel({ stamp, update }) {
  const selectMode = (modeId) => {
    update("entry_mode", modeId);
    if (privateModes.includes(modeId)) {
      update("visibility", "privé");
      update("status_label", "brouillon");
    }
  };

  return (
    <section className="rounded-[2rem] border border-white/10 bg-white/[0.035] p-5">
      <p className="text-xs uppercase tracking-[0.24em] text-white/40">Entrée</p>
      <h2 className="mt-2 font-display text-3xl font-semibold tracking-[-0.05em] text-white">Pourquoi créez-vous ce timbre ?</h2>
      <div className="mt-5 grid gap-2">
        {modes.map((mode) => (
          <button key={mode.id} onClick={() => selectMode(mode.id)} className={`rounded-2xl border p-4 text-left text-sm transition ${stamp.entry_mode === mode.id ? "border-white bg-white text-black" : "border-white/10 bg-black/25 text-white/65 hover:border-white/30"}`}>
            {mode.label}
          </button>
        ))}
      </div>
    </section>
  );
}