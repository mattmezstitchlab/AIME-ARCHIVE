import React from "react";

export default function SoberOrientationNotice() {
  return (
    <section className="grid gap-3 rounded-[2rem] border border-white/10 bg-black/35 p-5 sm:grid-cols-4 sm:p-6">
      <div className="sm:col-span-2">
        <p className="text-xs uppercase tracking-[0.24em] text-white/40">Cadre d’usage</p>
        <p className="mt-2 text-sm leading-6 text-white/64">Préparer, mémoriser, orienter. Jamais remplacer la justice, une plainte officielle, une enquête ou une décision humaine.</p>
      </div>
      <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-4 text-sm leading-6 text-white/70">
        Danger immédiat : <span className="font-semibold text-white">17 ou 112</span><br />Urgence par SMS : <span className="font-semibold text-white">114</span>
      </div>
      <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-4 text-sm leading-6 text-white/70">
        Enfance en danger : <span className="font-semibold text-white">119</span><br />AIME n’est pas un service d’urgence.
      </div>
    </section>
  );
}