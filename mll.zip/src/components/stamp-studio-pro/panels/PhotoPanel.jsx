import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Loader2, Wand2 } from "lucide-react";
import { PORTRAIT_MODES } from "@/lib/stampStudioPresets";
import PanelShell from "./PanelShell";

export default function PhotoPanel({ stamp, update, onComplete }) {
  const [loading, setLoading] = useState(false);

  const selectMode = (modeId) => {
    update("portrait_mode", modeId);
    if (modeId === "no_face") {
      update("photo_url", "");
      update("generated_url", "");
    }
  };

  const uploadPhoto = async (file) => {
    if (!file || !stamp.image_authorized) return;
    setLoading(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    update("photo_url", file_url);
    update("generated_url", "");
    const result = await base44.integrations.Core.GenerateImage({
      prompt: "Transformer le portrait fourni en portrait gravé façon timbre, noir et blanc, style taille-douce. Conserver strictement l'identité de la personne : mêmes traits du visage, même morphologie, même âge apparent, même expression, même regard, même nez, même bouche, même forme du visage. Ne pas inventer un autre visage. Le rendu doit être une gravure symbolique inspirée du langage visuel du timbre, sobre, digne, fond clair propre. Important : ne pas créer de timbre complet, ne pas ajouter de bordure, pas de perforations, pas de carte, pas de texte, pas de date, pas de code, pas de cadre extérieur. Le résultat doit être une illustration de portrait seule, fidèle à la photo importée, centrée, prête à être placée dans le timbre.",
      existing_image_urls: [file_url]
    });
    update("generated_url", result.url);
    setLoading(false);
    onComplete?.();
  };

  return (
    <PanelShell eyebrow="Étape 1" title="Choisir la présence visuelle">
      <p className="text-sm leading-6 text-white/58">Choisissez le type d’image, confirmez vos droits, puis importez la photo : elle devient un portrait gravé façon timbre, sans cadre ni texte.</p>

      <div className="grid gap-2">
        {PORTRAIT_MODES.map((mode) => (
          <button key={mode.id} onClick={() => selectMode(mode.id)} className={`rounded-2xl border p-4 text-left transition ${stamp.portrait_mode === mode.id ? "border-white bg-white text-black" : "border-white/10 bg-black/25 text-white"}`}>
            <span className="block text-sm font-semibold">{mode.label}</span>
            <span className={`mt-1 block text-xs leading-5 ${stamp.portrait_mode === mode.id ? "text-black/62" : "text-white/48"}`}>{mode.detail}</span>
          </button>
        ))}
      </div>

      <label className="flex gap-3 rounded-2xl border border-white/10 bg-black/30 p-4 text-sm leading-6 text-white/70">
        <input type="checkbox" checked={!!stamp.image_authorized} onChange={(e) => update("image_authorized", e.target.checked)} className="mt-1 h-4 w-4" />
        <span>Je confirme être autorisé(e) à utiliser cette image et je comprends qu’aucune photo de mineur ne doit être publiée sans consentement légal.</span>
      </label>

      {stamp.portrait_mode !== "no_face" ? (
        <input type="file" accept="image/*" disabled={!stamp.image_authorized || loading} onChange={(e) => uploadPhoto(e.target.files?.[0])} className="block w-full text-sm text-white/60 disabled:opacity-40 file:mr-4 file:min-h-11 file:rounded-full file:border-0 file:bg-white file:px-5 file:text-black" />
      ) : (
        <div className="rounded-2xl border border-white/10 bg-black/30 p-4 text-sm leading-6 text-white/58">Ce mode affiche une présence symbolique sans visage identifiable. Vous pourrez continuer dès que la confirmation est cochée.</div>
      )}

      {loading && <div className="flex min-h-28 items-center justify-center gap-3 rounded-2xl border border-white/10 bg-black/30 text-sm text-white/65"><Loader2 className="h-4 w-4 animate-spin" /> Génération du portrait gravé façon timbre…</div>}
      {stamp.generated_url && <img src={stamp.generated_url} alt="Portrait gravé façon timbre" className="aspect-[4/5] w-full rounded-2xl object-cover grayscale" />}
      {!loading && stamp.generated_url && <p className="inline-flex items-center gap-2 text-sm text-white/55"><Wand2 className="h-4 w-4" /> Portrait gravé façon timbre.</p>}
    </PanelShell>
  );
}