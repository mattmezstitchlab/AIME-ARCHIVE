import React from "react";
import { STAMP_FORMATS } from "@/lib/stampStudioPresets";
import PanelShell from "./PanelShell";

export default function FormatPanel({ stamp, update }) {
  return (
    <PanelShell eyebrow="Format" title="Proportion du timbre">
      <div className="grid grid-cols-3 gap-3">
        {STAMP_FORMATS.map((format) => (
          <button key={format.id} onClick={() => update("format", format.id)} className={`rounded-2xl border p-4 text-sm text-white transition ${stamp.format === format.id ? "border-white bg-white/10" : "border-white/10"}`}>
            <span className="mx-auto mb-3 block w-12 rounded-lg border border-white/35" style={{ aspectRatio: format.ratio }} />
            {format.label}
          </button>
        ))}
      </div>
    </PanelShell>
  );
}