import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Loader2, BadgeCheck } from "lucide-react";
import { createAimeCode } from "@/lib/stampStudioState";
import PanelShell from "./PanelShell";

export default function CodePanel({ stamp, update }) {
  const [saving, setSaving] = useState(false);
  const [created, setCreated] = useState(null);
  const hasPortrait = stamp.portrait_mode === "no_face" || !!stamp.generated_url;

  const seal = async () => {
    setSaving(true);
    const code = stamp.code || createAimeCode();
    const orientationMode = ["concern", "situation"].includes(stamp.entry_mode);
    const payload = {
      code,
      entry_mode: stamp.entry_mode,
      intention_type: orientationMode ? "orientation" : stamp.intention_type,
      title: stamp.title,
      note: stamp.note,
      portrait_url: stamp.portrait_mode === "no_face" ? "presence-sans-visage" : stamp.generated_url || stamp.photo_url,
      visibility: orientationMode ? "privé" : stamp.visibility,
      portrait_mode: stamp.portrait_mode,
      campaign_mode: !!stamp.campaign_mode,
      image_authorized: !!stamp.image_authorized,
      layout_mode: "photo_text",
      orientation_code: code,
      situation_type: stamp.situation_type,
      concerned_person: stamp.concerned_person,
      approx_age: stamp.approx_age,
      department: stamp.department,
      short_timeline: stamp.short_timeline,
      declared_facts: stamp.declared_facts,
      available_elements: stamp.available_elements,
      missing_elements: stamp.missing_elements,
      felt_urgency: stamp.felt_urgency,
      recommended_relay: stamp.recommended_relay,
      human_validation_required: true,
      charter_accepted: true,
      status: orientationMode ? "brouillon" : "en_attente_validation",
      stamp_date: new Date().toISOString().slice(0, 10)
    };
    const record = await base44.entities.AimeStamp.create(payload);
    update("code", code);
    update("charter_accepted", true);
    update("status_label", orientationMode ? "brouillon" : "en attente de validation");
    setCreated(record);
    setSaving(false);
  };

  return (
    <PanelShell eyebrow="Validation" title="Sceller sans publier">
      <p className="rounded-2xl border border-white/10 bg-black/30 p-4 text-sm leading-6 text-white/62">Le scellement crée un timbre AIME privé ou semi-public en attente de validation humaine. Aucune publication n’est automatique, aucune promesse de preuve juridique n’est faite, et les récits sensibles ne doivent pas être exposés sans avertissement.</p>
      <button onClick={seal} disabled={saving || !stamp.title || !stamp.note || !hasPortrait || !stamp.image_authorized} className="inline-flex min-h-12 w-full items-center justify-center gap-2 rounded-full bg-white px-5 text-sm font-medium text-black disabled:opacity-60">
        {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <BadgeCheck className="h-4 w-4" />}
        {saving ? "Scellement…" : "Sceller dans AIME"}
      </button>
      {created && <div className="rounded-2xl border border-white/10 p-4"><p className="text-xs uppercase tracking-[0.2em] text-white/45">Timbre créé, en attente de validation humaine</p><p className="mt-2 font-display text-2xl text-white">{created.code}</p></div>}
    </PanelShell>
  );
}