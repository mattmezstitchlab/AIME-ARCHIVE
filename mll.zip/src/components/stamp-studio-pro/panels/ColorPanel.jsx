import React from "react";
import { STAMP_PALETTES } from "@/lib/stampStudioPresets";
import PanelShell from "./PanelShell";

export default function ColorPanel({ stamp, update }) {
  return (
    <PanelShell eyebrow="Palette" title="Couleur et papier">
      <div className="grid gap-3">
        {STAMP_PALETTES.map((palette) => (
          <button key={palette.id} onClick={() => update("palette", palette.id)} className={`flex min-h-14 items-center justify-between rounded-2xl border px-4 text-left transition ${stamp.palette === palette.id ? "border-white bg-white/10" : "border-white/10"}`}>
            <span className="text-sm text-white">{palette.label}</span>
            <span className="flex gap-2"><i className="h-5 w-5 rounded-full border border-white/20" style={{ backgroundColor: palette.background }} /><i className="h-5 w-5 rounded-full border border-white/20" style={{ backgroundColor: palette.ink }} /></span>
          </button>
        ))}
      </div>
    </PanelShell>
  );
}