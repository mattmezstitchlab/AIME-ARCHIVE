import React from "react";
import PanelShell from "./PanelShell";

export default function OrnamentPanel() {
  return <PanelShell eyebrow="Ornements" title="Ornements sobres"><p className="text-sm leading-6 text-white/60">Le studio privilégie une gravure digne, sans image choquante ni surcharge décorative.</p></PanelShell>;
}