import React from "react";
import { INTENTIONS, MANIFESTO_TEMPLATES, VISIBILITIES } from "@/lib/stampStudioPresets";
import PanelShell from "./PanelShell";

const inputClass = "min-h-11 w-full rounded-2xl border border-white/10 bg-black/30 px-4 text-white placeholder:text-white/35 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/35";
const labelClass = "mb-2 block text-xs uppercase tracking-[0.2em] text-white/45";

export default function TextPanel({ stamp, update }) {
  const privateMode = ["concern", "situation"].includes(stamp.entry_mode);

  return (
    <PanelShell eyebrow="Contenu" title="Campagne / Manifeste">
      <label className="flex items-center justify-between gap-3 rounded-2xl border border-white/10 bg-black/30 p-4 text-sm text-white/70">
        <span>Activer le mode Campagne / Manifeste</span>
        <input type="checkbox" checked={!!stamp.campaign_mode} onChange={(e) => update("campaign_mode", e.target.checked)} className="h-4 w-4" />
      </label>

      <label><span className={labelClass}>Titre</span><input className={inputClass} value={stamp.title} onChange={(e) => update("title", e.target.value)} /></label>

      <div>
        <span className={labelClass}>Modèles de texte</span>
        <div className="grid gap-2">
          {MANIFESTO_TEMPLATES.map((template) => (
            <button key={template} onClick={() => update("note", template)} className="rounded-2xl border border-white/10 bg-black/25 p-3 text-left text-xs leading-5 text-white/62 transition hover:border-white/30 hover:text-white">
              {template}
            </button>
          ))}
        </div>
      </div>

      <label className="block"><span className={labelClass}>Texte manifeste</span><textarea className={`${inputClass} min-h-40 py-3`} maxLength={520} value={stamp.note} onChange={(e) => update("note", e.target.value)} /></label>
      <div className="grid gap-4 sm:grid-cols-2">
        <label><span className={labelClass}>Intention</span><select className={inputClass} value={stamp.intention_type} onChange={(e) => update("intention_type", e.target.value)}>{INTENTIONS.map((item) => <option key={item}>{item}</option>)}</select></label>
        {privateMode ? (
          <div><span className={labelClass}>Visibilité</span><div className="flex min-h-11 items-center rounded-2xl border border-white/10 bg-black/30 px-4 text-sm text-white/62">privé — publication publique désactivée</div></div>
        ) : (
          <label><span className={labelClass}>Visibilité</span><select className={inputClass} value={stamp.visibility} onChange={(e) => update("visibility", e.target.value)}>{VISIBILITIES.map((item) => <option key={item}>{item}</option>)}</select></label>
        )}
      </div>
    </PanelShell>
  );
}