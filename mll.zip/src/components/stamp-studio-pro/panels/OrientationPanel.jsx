import React from "react";
import PanelShell from "./PanelShell";

const inputClass = "min-h-11 w-full rounded-2xl border border-white/10 bg-black/30 px-4 text-white placeholder:text-white/35 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/35";
const labelClass = "mb-2 block text-xs uppercase tracking-[0.2em] text-white/45";
const textareaClass = `${inputClass} min-h-24 py-3`;

export default function OrientationPanel({ stamp, update }) {
  const currentDate = new Date().toLocaleDateString("fr-FR");

  return (
    <PanelShell eyebrow="Pré-orientation" title="Fiche AIME d’orientation">
      <p className="rounded-2xl border border-white/10 bg-black/30 p-4 text-sm leading-6 text-white/62">Ce mode reste privé : il prépare une fiche lisible, sans plainte officielle, sans qualification juridique et sans publication publique.</p>
      <div className="grid gap-3 sm:grid-cols-2">
        <div className="rounded-2xl border border-white/10 bg-black/30 p-4"><span className={labelClass}>Code AIME</span><p className="text-sm text-white">{stamp.code || "généré à la validation"}</p></div>
        <div className="rounded-2xl border border-white/10 bg-black/30 p-4"><span className={labelClass}>Date</span><p className="text-sm text-white">{currentDate}</p></div>
        <div className="rounded-2xl border border-white/10 bg-black/30 p-4"><span className={labelClass}>Statut</span><p className="text-sm text-white">privé · brouillon</p></div>
        <div className="rounded-2xl border border-white/10 bg-black/30 p-4"><span className={labelClass}>Validation humaine</span><p className="text-sm text-white">obligatoire</p></div>
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <label><span className={labelClass}>Type de situation</span><input className={inputClass} value={stamp.situation_type || ""} onChange={(e) => update("situation_type", e.target.value)} /></label>
        <label><span className={labelClass}>Personne concernée</span><select className={inputClass} value={stamp.concerned_person || "moi"} onChange={(e) => update("concerned_person", e.target.value)}><option>moi</option><option>enfant</option><option>proche</option><option>témoin</option></select></label>
        <label><span className={labelClass}>Âge approximatif</span><input className={inputClass} value={stamp.approx_age || ""} onChange={(e) => update("approx_age", e.target.value)} /></label>
        <label><span className={labelClass}>Département</span><input className={inputClass} value={stamp.department || ""} onChange={(e) => update("department", e.target.value)} /></label>
      </div>
      <label className="block"><span className={labelClass}>Chronologie courte</span><textarea className={textareaClass} value={stamp.short_timeline || ""} onChange={(e) => update("short_timeline", e.target.value)} /></label>
      <label className="block"><span className={labelClass}>Faits déclarés</span><textarea className={textareaClass} value={stamp.declared_facts || ""} onChange={(e) => update("declared_facts", e.target.value)} /></label>
      <label className="block"><span className={labelClass}>Éléments disponibles</span><textarea className={textareaClass} value={stamp.available_elements || ""} onChange={(e) => update("available_elements", e.target.value)} /></label>
      <label className="block"><span className={labelClass}>Pièces manquantes</span><textarea className={textareaClass} value={stamp.missing_elements || ""} onChange={(e) => update("missing_elements", e.target.value)} /></label>
      <div className="grid gap-4 sm:grid-cols-2">
        <label><span className={labelClass}>Urgence ressentie</span><select className={inputClass} value={stamp.felt_urgency || "à préciser"} onChange={(e) => update("felt_urgency", e.target.value)}><option>à préciser</option><option>faible</option><option>moyenne</option><option>forte</option><option>danger immédiat</option></select></label>
        <label><span className={labelClass}>Relais recommandé</span><input className={inputClass} value={stamp.recommended_relay || "services officiels / association spécialisée"} onChange={(e) => update("recommended_relay", e.target.value)} /></label>
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        <button type="button" onClick={() => window.print()} className="inline-flex min-h-12 items-center justify-center rounded-full bg-white px-5 text-sm font-medium text-black">Export PDF privé</button>
        <a href="#orientation-officielle" className="inline-flex min-h-12 items-center justify-center rounded-full border border-white/15 px-5 text-sm font-medium text-white">Voir les services officiels</a>
      </div>
      <div className="rounded-2xl border border-white/10 bg-black/30 p-4 text-sm leading-6 text-white/62">Statut : brouillon · Validation humaine : obligatoire</div>
    </PanelShell>
  );
}