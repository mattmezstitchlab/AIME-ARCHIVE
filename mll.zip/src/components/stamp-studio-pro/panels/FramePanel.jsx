import React from "react";
import { STAMP_FRAMES } from "@/lib/stampStudioPresets";
import PanelShell from "./PanelShell";

export default function FramePanel({ stamp, update }) {
  return (
    <PanelShell eyebrow="Cadre" title="Bord du timbre">
      <div className="grid gap-3">
        {STAMP_FRAMES.map((frame) => (
          <button key={frame.id} onClick={() => update("frame", frame.id)} className={`rounded-2xl border p-4 text-left text-sm text-white transition ${stamp.frame === frame.id ? "border-white bg-white/10" : "border-white/10"}`}>
            {frame.label}
          </button>
        ))}
      </div>
    </PanelShell>
  );
}