import React from "react";
import PanelShell from "./PanelShell";

export default function PresetsPanel() {
  return <PanelShell eyebrow="Presets" title="Présélections"><p className="text-sm leading-6 text-white/60">Les réglages essentiels sont disponibles dans les panneaux Style, Cadre et Texte.</p></PanelShell>;
}