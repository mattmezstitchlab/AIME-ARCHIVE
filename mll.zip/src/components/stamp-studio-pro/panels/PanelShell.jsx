import React from "react";

export default function PanelShell({ eyebrow, title, children }) {
  return (
    <section className="space-y-5 rounded-[2rem] border border-white/10 bg-white/[0.035] p-5">
      <div>
        <p className="text-xs uppercase tracking-[0.24em] text-white/40">{eyebrow}</p>
        <h2 className="mt-2 font-display text-3xl font-semibold tracking-[-0.05em] text-white">{title}</h2>
      </div>
      {children}
    </section>
  );
}