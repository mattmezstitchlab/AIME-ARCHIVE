import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Loader2, Sparkles } from "lucide-react";
import PanelShell from "./PanelShell";

export default function PixellePanel({ stamp, update }) {
  const [prompt, setPrompt] = useState("portrait symbolique en gravure, sobre, noir et blanc, digne");
  const [loading, setLoading] = useState(false);

  const generate = async () => {
    setLoading(true);
    const result = await base44.integrations.Core.GenerateImage({
      prompt: `Créer une illustration de timbre AIME, style gravure noir et blanc premium, sobre, digne, non sensationnaliste, sans texte lisible. Sujet : ${prompt}. Intention : ${stamp.intention_type}.`
    });
    update("generated_url", result.url);
    setLoading(false);
  };

  return (
    <PanelShell eyebrow="Pixelle" title="Génération créative">
      <textarea className="min-h-28 w-full rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-white placeholder:text-white/35 focus-visible:outline-none" value={prompt} onChange={(e) => setPrompt(e.target.value)} />
      <button onClick={generate} disabled={loading} className="inline-flex min-h-12 w-full items-center justify-center gap-2 rounded-full bg-white px-5 text-sm font-medium text-black disabled:opacity-60">
        {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
        {loading ? "Génération…" : "Générer une gravure"}
      </button>
    </PanelShell>
  );
}