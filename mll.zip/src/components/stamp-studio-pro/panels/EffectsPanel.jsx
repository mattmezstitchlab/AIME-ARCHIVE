import React from "react";
import PanelShell from "./PanelShell";

export default function EffectsPanel() {
  return <PanelShell eyebrow="Effets" title="Gravure"><p className="text-sm leading-6 text-white/60">Le rendu applique une esthétique noir et blanc, contraste renforcé et texture de papier.</p></PanelShell>;
}