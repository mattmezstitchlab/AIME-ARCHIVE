import React, { useEffect, useMemo, useState } from "react";
import { base44 } from "@/api/base44Client";

export default function RegistreGeneratorWindow({ onStart, onGenerated }) {
  const [idea, setIdea] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [stepIndex, setStepIndex] = useState(0);

  const steps = useMemo(() => [
    "Relève les mots clés et l’intention principale.",
    "Analyse les détails humains, visuels et émotionnels.",
    "Structure une carte projet cohérente avec l’Atlas.",
    "Prépare le visuel en situation humaine.",
    "Assemble la fiche en trois colonnes."
  ], []);

  useEffect(() => {
    if (!loading) return;
    const timer = setInterval(() => setStepIndex((current) => (current + 1) % steps.length), 1800);
    return () => clearInterval(timer);
  }, [loading, steps.length]);

  const understood = idea.trim().replace(/\s+/g, " ").slice(0, 170);

  const generate = async () => {
    if (!idea.trim()) return;
    onStart?.();
    setLoading(true);
    setStepIndex(0);
    setError("");
    const schema = {
      type: "object",
      properties: {
        title: { type: "string" },
        category: { type: "string" },
        short_description: { type: "string" },
        vision: { type: "string" },
        intention: { type: "string" },
        human_situation: { type: "string" },
        public_value: { type: "string" },
        key_features: { type: "array", items: { type: "string" } },
        next_steps: { type: "array", items: { type: "string" } },
        image_prompt: { type: "string" }
      },
      required: ["title", "category", "short_description", "vision", "intention", "human_situation", "public_value", "key_features", "next_steps", "image_prompt"]
    };

    try {
      const project = await base44.integrations.Core.InvokeLLM({
        prompt: `Transforme cette idée en fiche projet AIME, ton sobre, institutionnel, humain, clair. Idée: ${idea}`,
        response_json_schema: schema
      });
      const image = await base44.integrations.Core.GenerateImage({
        prompt: `${project.image_prompt}. Scène humaine réaliste, lumière douce, esthétique premium glassmorphism, noir profond, photographie éditoriale, sans texte, sans logo.`
      });
      onGenerated({ ...project, image_url: image.url, source_idea: idea });
    } catch (err) {
      setError("La génération n’a pas abouti. Réessayez avec une idée plus courte.");
    }
    setLoading(false);
  };

  return (
    <div className="mx-auto w-full max-w-sm rounded-[2rem] border border-white/14 bg-[#14171d] p-3 text-white shadow-2xl shadow-black/50">
      <div className="rounded-[1.5rem] border-2 border-dashed border-white/25 p-4">
        <div className="mb-4 flex items-center justify-between border-b border-white/10 pb-3 text-[0.62rem] uppercase tracking-[0.2em] text-white/50">
          <span>AIME-PRESENCE</span><span>Générateur</span>
        </div>

        {loading ? (
          <div className="flex min-h-[22rem] flex-col items-center justify-center text-center">
            <div className="relative h-28 w-28">
              <div className="absolute inset-0 animate-spin rounded-full" style={{ background: "repeating-conic-gradient(from 0deg,#111827 0deg 7deg,transparent 7deg 15deg,#60a5fa 15deg 22deg,transparent 22deg 31deg,#f59e0b 31deg 38deg,transparent 38deg 48deg,#ffffff 48deg 54deg,transparent 54deg 64deg)" }} />
              <div className="absolute inset-3 rounded-full bg-[#14171d]" />
              <div className="absolute inset-10 rounded-full bg-white/80" />
            </div>
            <p className="mt-6 text-[0.62rem] font-bold uppercase tracking-[0.24em] text-white/45">Génération en cours</p>
            <p className="mt-3 text-sm font-semibold text-white">{steps[stepIndex]}</p>
            <div className="mt-5 rounded-2xl border border-white/10 bg-white/[0.06] p-4 text-left text-xs leading-5 text-white/62">
              <p><span className="font-bold text-white">Compris :</span> {understood}{idea.length > 170 ? "…" : ""}</p>
              <p className="mt-3"><span className="font-bold text-white">Action :</span> générer un visuel humain, une carte projet et une fiche structurée.</p>
            </div>
          </div>
        ) : (
          <>
            <textarea value={idea} onChange={(event) => setIdea(event.target.value)} placeholder="Décrire une idée, une vision, un projet, un événement…" className="min-h-28 w-full resize-none rounded-2xl border border-white/10 bg-black/25 p-4 text-sm leading-6 text-white outline-none placeholder:text-white/35 focus:border-white/35" />
            {error && <p className="mt-3 text-xs leading-5 text-red-300">{error}</p>}
            <button type="button" onClick={generate} disabled={!idea.trim()} className="mt-4 inline-flex min-h-12 w-full items-center justify-center rounded-full bg-white px-5 text-sm font-semibold text-black transition hover:bg-white/88 disabled:cursor-not-allowed disabled:opacity-45">
              Générer
            </button>
          </>
        )}
      </div>
    </div>
  );
}