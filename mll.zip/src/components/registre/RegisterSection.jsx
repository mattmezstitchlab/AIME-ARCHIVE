import React from "react";

export default function RegisterSection({ id, eyebrow, title, children, className = "" }) {
  return (
    <section id={id} className={`border-t border-white/10 px-5 py-16 sm:px-8 lg:px-12 ${className}`}>
      <div className="mx-auto max-w-7xl">
        {eyebrow && <p className="text-xs uppercase tracking-[0.28em] text-white/50">{eyebrow}</p>}
        {title && <h2 className="mt-5 max-w-5xl font-display text-4xl font-semibold leading-tight tracking-[-0.05em] text-white sm:text-6xl">{title}</h2>}
        <div className="mt-8 text-base leading-8 text-white/75 sm:text-lg">{children}</div>
      </div>
    </section>
  );
}