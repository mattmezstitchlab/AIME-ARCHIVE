import React from "react";

export default function RegisterStampCard({ stamp = {} }) {
  const displayDate = stamp.stamp_date ? new Date(stamp.stamp_date).toLocaleDateString("fr-FR") : "08.06.2026";
  const statusLabel = stamp.status && stamp.status !== "validé_humainement" ? "Présence en attente de validation humaine" : "Présence validée humainement";

  return (
    <div className="mx-auto max-w-sm rounded-[2rem] border border-white/20 bg-[#f4efe3] p-3 text-black shadow-2xl">
      <div className="rounded-[1.5rem] border-2 border-dashed border-black/55 p-5">
        <div className="aspect-[4/5] overflow-hidden rounded-xl border border-black/25 bg-[radial-gradient(circle_at_35%_20%,rgba(0,0,0,0.18),transparent_24%),repeating-linear-gradient(135deg,rgba(0,0,0,0.18)_0_1px,transparent_1px_6px)]">
          {stamp.portrait_url && <img src={stamp.portrait_url} alt="Portrait ou illustration du timbre" className="h-full w-full object-cover grayscale contrast-125 mix-blend-multiply" />}
        </div>
        <div className="mt-5 flex items-center justify-between gap-4 border-t border-black/20 pt-4 text-[0.65rem] uppercase tracking-[0.2em]">
          <span>{stamp.code || "AIME-0001"}</span>
          <span>{displayDate}</span>
        </div>
        {stamp.title && <p className="mt-3 text-xs uppercase tracking-[0.22em] text-black/50">{stamp.title}</p>}
        <p className="mt-4 font-display text-2xl font-semibold leading-none tracking-[-0.05em]">{statusLabel}</p>
        <p className="mt-3 text-xs leading-5 text-black/70">{stamp.note || "Transformer une parole en mémoire structurée, avec dignité, consentement et protection."}</p>
        <p className="mt-4 rounded-full border border-black/20 px-3 py-2 text-center text-[0.62rem] uppercase tracking-[0.18em] text-black/60">Visibilité : {stamp.visibility || "privé"}</p>
      </div>
    </div>
  );
}