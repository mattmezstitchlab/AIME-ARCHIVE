import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";

const visibleStatuses = ["validé_humainement", "public"];
const visibleScopes = ["public", "partenaire", "semi-public"];

export default function AimeTrombinoscope() {
  const [stamps, setStamps] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadStamps = async () => {
      const results = await Promise.all(
        visibleStatuses.flatMap((status) =>
          visibleScopes.map((visibility) =>
            base44.entities.AimeStamp.filter({ status, visibility }, "-stamp_date", 12)
          )
        )
      );
      const unique = Array.from(new Map(results.flat().map((stamp) => [stamp.id, stamp])).values());
      setStamps(unique.slice(0, 24));
      setLoading(false);
    };

    loadStamps();
  }, []);

  if (loading) {
    return <div className="min-h-48 rounded-[2rem] border border-white/10 bg-white/[0.03]" />;
  }

  if (!stamps.length) {
    return (
      <div className="rounded-[2rem] border border-white/10 bg-white/[0.03] p-8 text-center">
        <p className="mx-auto max-w-2xl text-base leading-7 text-white/65">Le trombinoscope affichera ici les timbres AIME validés humainement et autorisés à être visibles. Les récits sensibles restent privés.</p>
        <Link to="/stamp-studio" className="mt-6 inline-flex min-h-12 items-center rounded-full bg-white px-6 text-sm font-medium text-black">Créer un timbre</Link>
      </div>
    );
  }

  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {stamps.map((stamp) => {
        const hasPortrait = stamp.portrait_url && stamp.portrait_url !== "presence-sans-visage";
        return (
          <article key={stamp.id} className="rounded-[1.6rem] border border-white/10 bg-white/[0.04] p-3">
            <div className="aspect-[4/5] overflow-hidden rounded-[1.25rem] border border-white/10 bg-[radial-gradient(circle_at_35%_20%,rgba(255,255,255,0.16),transparent_24%),repeating-linear-gradient(135deg,rgba(255,255,255,0.12)_0_1px,transparent_1px_7px)]">
              {hasPortrait ? <img src={stamp.portrait_url} alt={stamp.title || "Timbre AIME"} className="h-full w-full object-cover grayscale contrast-125" /> : null}
            </div>
            <div className="p-3">
              <p className="text-[0.62rem] uppercase tracking-[0.2em] text-white/40">{stamp.code}</p>
              <h3 className="mt-3 font-display text-2xl font-semibold leading-none tracking-[-0.04em] text-white">{stamp.title || "Présence AIME"}</h3>
              <div className="mt-4 flex flex-wrap gap-2 text-[0.58rem] uppercase tracking-[0.16em] text-white/55">
                <span className="rounded-full border border-white/10 px-2.5 py-1.5">{stamp.intention_type}</span>
                <span className="rounded-full border border-white/10 px-2.5 py-1.5">{stamp.visibility}</span>
              </div>
            </div>
          </article>
        );
      })}
    </div>
  );
}