import React from "react";
import { ArrowUpRight } from "lucide-react";

const Column = ({ title, children }) => (
  <section className="rounded-[1.5rem] border border-white/10 bg-[#14171d] p-5 backdrop-blur-xl">
    <p className="text-[0.62rem] font-bold uppercase tracking-[0.22em] text-white/45">{title}</p>
    <div className="mt-4 text-sm leading-7 text-white/75">{children}</div>
  </section>
);

export default function RegistreGeneratedProject({ project }) {
  if (!project) return null;

  return (
    <section id="fiche-generee" className="relative z-10 mx-auto w-full max-w-7xl scroll-mt-6 px-5 pb-16 sm:px-8 lg:px-12">
      <div className="mb-8 overflow-hidden rounded-[2rem] border border-white/10 bg-[#14171d]">
        <div className="aspect-[16/7] bg-cover bg-center" style={{ backgroundImage: `url(${project.image_url})` }} />
      </div>
      <div className="grid gap-6 lg:grid-cols-[0.82fr_1.18fr]">
        <article className="overflow-hidden rounded-[2rem] border border-white/10 bg-[#14171d]">
          <div className="aspect-[4/5] bg-cover bg-center" style={{ backgroundImage: `url(${project.image_url})` }} />
          <div className="p-5">
            <div className="mb-3 flex items-center justify-between gap-3 text-xs text-white">
              <span>{project.category}</span><ArrowUpRight className="h-4 w-4" />
            </div>
            <h2 className="font-display text-3xl font-semibold tracking-[-0.05em] text-white">{project.title}</h2>
            <p className="mt-3 text-sm leading-6 text-white/78">{project.short_description}</p>
          </div>
        </article>
        <div className="grid gap-4 md:grid-cols-3">
          <Column title="Vision"><p>{project.vision}</p></Column>
          <Column title="Situation humaine"><p>{project.human_situation}</p></Column>
          <Column title="Valeur publique"><p>{project.public_value}</p></Column>
          <Column title="Intention"><p>{project.intention}</p></Column>
          <Column title="Fonctions">
            <ul className="space-y-2">{project.key_features?.map((item) => <li key={item}>— {item}</li>)}</ul>
          </Column>
          <Column title="Prochaines étapes">
            <ul className="space-y-2">{project.next_steps?.map((item) => <li key={item}>— {item}</li>)}</ul>
          </Column>
        </div>
      </div>
    </section>
  );
}