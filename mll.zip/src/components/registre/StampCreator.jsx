import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Loader2, Upload } from "lucide-react";
import RegisterStampCard from "./RegisterStampCard";

const inputClass = "min-h-12 w-full rounded-2xl border border-white/15 bg-white/[0.04] px-4 text-white placeholder:text-white/35 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/40";
const labelClass = "mb-2 block text-xs uppercase tracking-[0.22em] text-white/50";

const createStampCode = () => {
  const date = new Date();
  const year = date.getFullYear();
  const random = Math.random().toString(36).slice(2, 7).toUpperCase();
  return `AIME-${year}-${random}`;
};

export default function StampCreator() {
  const [stamp, setStamp] = useState(null);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    intention_type: "présence",
    title: "",
    note: "",
    visibility: "privé",
    charter_accepted: false,
    portrait_url: ""
  });

  const update = (field, value) => setForm((prev) => ({ ...prev, [field]: value }));

  const uploadPortrait = async (file) => {
    if (!file) return;
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    update("portrait_url", file_url);
  };

  const submit = async (event) => {
    event.preventDefault();
    setSaving(true);
    const stamp_date = new Date().toISOString().slice(0, 10);
    const payload = {
      ...form,
      code: createStampCode(),
      stamp_date,
      status: "en_attente_validation"
    };
    const created = await base44.entities.AimeStamp.create(payload);
    setStamp(created);
    setSaving(false);
  };

  return (
    <div className="grid gap-8 lg:grid-cols-[1.05fr_0.95fr] lg:items-start">
      <form onSubmit={submit} className="rounded-[2rem] border border-white/10 bg-white/[0.035] p-6 sm:p-8">
        <p className="mb-6 rounded-2xl border border-white/10 bg-black/35 p-4 text-sm leading-6 text-white/65">
          Ne saisissez pas de témoignage sensible public ici. Le timbre formalise une intention courte ; toute situation grave doit être orientée vers les services officiels et validée par un humain.
        </p>

        <div className="grid gap-5 md:grid-cols-2">
          <label>
            <span className={labelClass}>Intention</span>
            <select className={inputClass} value={form.intention_type} onChange={(e) => update("intention_type", e.target.value)}>
              {['mémoire', 'présence', 'intention', 'protection', 'orientation', 'projet'].map((value) => <option key={value} value={value}>{value}</option>)}
            </select>
          </label>
          <label>
            <span className={labelClass}>Visibilité</span>
            <select className={inputClass} value={form.visibility} onChange={(e) => update("visibility", e.target.value)}>
              {['privé', 'semi-public', 'public', 'partenaire'].map((value) => <option key={value} value={value}>{value}</option>)}
            </select>
          </label>
          <label className="md:col-span-2">
            <span className={labelClass}>Titre du timbre</span>
            <input className={inputClass} value={form.title} onChange={(e) => update("title", e.target.value)} placeholder="Ex. Présence, mémoire, projet, intention…" required />
          </label>
          <label className="md:col-span-2">
            <span className={labelClass}>Note d’intention courte</span>
            <textarea className={`${inputClass} min-h-32 py-3`} value={form.note} onChange={(e) => update("note", e.target.value)} maxLength={220} placeholder="Texte bref, digne, non sensible, sans accusation publique." />
          </label>
          <label className="md:col-span-2">
            <span className={labelClass}>Portrait ou illustration</span>
            <div className="flex flex-col gap-3 rounded-2xl border border-white/10 bg-black/20 p-4">
              <input type="file" accept="image/*" onChange={(e) => uploadPortrait(e.target.files?.[0])} className="text-sm text-white/60 file:mr-4 file:min-h-11 file:rounded-full file:border-0 file:bg-white file:px-5 file:text-black" />
              {form.portrait_url && <span className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.18em] text-white/55"><Upload className="h-4 w-4" /> Illustration ajoutée</span>}
            </div>
          </label>
        </div>

        <label className="mt-6 flex gap-3 rounded-2xl border border-white/10 p-4 text-sm leading-6 text-white/70">
          <input type="checkbox" checked={form.charter_accepted} onChange={(e) => update("charter_accepted", e.target.checked)} required className="mt-1" />
          <span>Je comprends qu’AIME ne remplace ni la justice, ni la police, ni les associations, ni les professionnels, et que toute validation reste humaine.</span>
        </label>

        <button disabled={saving} className="mt-6 inline-flex min-h-12 w-full items-center justify-center gap-2 rounded-full bg-white px-6 text-sm font-medium text-black transition hover:bg-white/85 disabled:opacity-60">
          {saving && <Loader2 className="h-4 w-4 animate-spin" />}
          {saving ? "Création du timbre…" : "Créer le timbre AIME"}
        </button>
      </form>

      <div className="space-y-5">
        <RegisterStampCard stamp={stamp || { ...form, status: "en_attente_validation" }} />
        {stamp && (
          <div className="rounded-[2rem] border border-white/10 bg-white/[0.035] p-6 text-white">
            <p className="text-xs uppercase tracking-[0.24em] text-white/45">Timbre créé</p>
            <p className="mt-3 font-display text-3xl font-semibold tracking-[-0.04em]">{stamp.code}</p>
            <p className="mt-3 text-sm leading-6 text-white/65">Statut : en attente de validation humaine. Ce timbre est enregistré et pourra être vérifié avant toute visibilité publique.</p>
          </div>
        )}
      </div>
    </div>
  );
}