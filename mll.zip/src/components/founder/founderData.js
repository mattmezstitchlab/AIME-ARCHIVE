export const founderMilestones = [
  { year: "Après les études", title: "De l’art au souffle", text: "Sa biographie YouTube publique situe le début du parcours après des études d’art. L’image, la scène et le son formeront ensuite un même langage." },
  { year: "2006–2021", title: "Quinze ans de scène", text: "En 2021, La Voix du Nord évoque environ un millier de mariages en quinze ans, auxquels s’ajoutent événements d’entreprise, anniversaires et clubs." },
  { year: "2018–2020", title: "Trois distinctions", text: "Son profil professionnel mentionne les Zankyou International Wedding Awards en 2018, 2019 et 2020." },
  { year: "2024", title: "Le catalogue s’écrit", text: "Une série de Sax Edits et de reprises paraît sur les plateformes : As It Was, Une Simple Histoire, Mon Amour, Sailing ou Gypsy Woman." },
  { year: "2025", title: "Des œuvres originales", text: "PAX AMOR LUX, Piou Piou et La danse du ciel prolongent l’univers vers une musique de lumière, de lien et de transmission." },
  { year: "Aujourd’hui", title: "AIME® et Matt Mez Lab", text: "Le musicien est aussi le fondateur public de la marque AIME® / Innovation & Digital Lab, où mémoire, interfaces et intelligence artificielle se rencontrent." },
];

export const founderSources = [
  { label: "Portrait · La Voix du Nord", detail: "6 mars 2021", href: "https://www.lavoixdunord.fr/952881/article/2021-03-06/frelinghien-qui-est-matt-mez-le-musicien-qui-veut-faire-un-peu-danser-ce" },
  { label: "Profil · Mariages.net", detail: "Services et expérience", href: "https://www.mariages.net/musique-mariage/matt-mez-sax--e206799" },
  { label: "Chaîne · YouTube", detail: "Créations et prestations", href: "https://www.youtube.com/@mattmezsax" },
  { label: "Artiste · Spotify", detail: "Discographie officielle", href: "https://open.spotify.com/artist/65JfcB7pfUQeVU23sXNYEs" },
  { label: "Profil · LinkedIn", detail: "Parcours professionnel", href: "https://fr.linkedin.com/in/matthieu-lecointre-37186611a" },
  { label: "Page officielle · Facebook", detail: "Matt Mez Sax", href: "https://www.facebook.com/mattmezsaxofficiel/" },
  { label: "Journal visuel · Instagram", detail: "@mattmezsax", href: "https://www.instagram.com/mattmezsax/" },
];

export const releases2024 = ["As It Was · Sax Edit", "The Winner Takes It All", "Une Simple Histoire · Sax Edit", "Mon Amour · Sax Cover", "Sailing · Sax Edit", "Gypsy Woman · Sax Edit"];
export const releases2025 = ["PAX AMOR LUX", "Piou Piou · Love Becomes Light", "La danse du ciel", "RHAPSODIE DU SACRÉ-CŒUR"];