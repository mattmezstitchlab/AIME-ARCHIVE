import React from "react";

export default function FounderBiography() {
  return (
    <section className="border-y border-white/10 bg-card px-5 py-24 text-white sm:px-8 lg:px-12">
      <div className="mx-auto max-w-7xl">
        <p className="text-xs uppercase tracking-[0.3em] text-white/45">03 · Biographie</p>
        <h2 className="mt-5 max-w-5xl font-display text-5xl font-semibold leading-[0.9] tracking-[-0.06em] sm:text-7xl">Créer des moments qui restent.</h2>
        <div className="mt-12 grid gap-10 text-base leading-8 text-white/65 md:grid-cols-3">
          <article><h3 className="font-display text-2xl text-white">L’image avant le son</h3><p className="mt-4">Sa biographie publique place des études d’art au commencement. Cette formation éclaire une pratique où la composition, la lumière, la présence et le rythme comptent autant que la virtuosité.</p></article>
          <article><h3 className="font-display text-2xl text-white">Le saxophone au milieu des vies</h3><p className="mt-4">Pendant quinze ans, Matt Mez Sax accompagne mariages, cérémonies, cocktails, événements d’entreprise, anniversaires et clubs. En 2021, La Voix du Nord estimait ce parcours à près d’un millier de mariages.</p></article>
          <article><h3 className="font-display text-2xl text-white">Du spectacle à la transmission</h3><p className="mt-4">Les reprises, Sax Edits et œuvres originales ont construit une archive musicale publique. Avec Matt Mez Lab et AIME®, le même geste devient numérique : préserver une intention, clarifier un parcours et laisser une trace humaine.</p></article>
        </div>
      </div>
    </section>
  );
}