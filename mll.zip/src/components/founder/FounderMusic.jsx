import React from "react";
import { releases2024, releases2025 } from "@/components/founder/founderData";

function ReleaseList({ year, items }) { return <div className="border-t border-white/15 py-6"><p className="font-display text-5xl tracking-[-0.07em] text-white/25">{year}</p><ul className="mt-6 space-y-3">{items.map((item) => <li key={item} className="border-b border-white/10 pb-3 text-sm text-white/70">{item}</li>)}</ul></div>; }

export default function FounderMusic() {
  return (
    <section className="border-y border-white/10 bg-card px-5 py-24 text-white sm:px-8 lg:px-12">
      <div className="mx-auto grid max-w-7xl gap-12 lg:grid-cols-[1.1fr_0.9fr]"><article><p className="text-xs uppercase tracking-[0.3em] text-white/45">04 · Matt Mez Sax</p><h2 className="mt-5 font-display text-5xl font-semibold leading-[0.9] tracking-[-0.06em] sm:text-7xl">Quinze ans de scène, puis l’écriture.</h2><p className="mt-8 max-w-2xl text-lg leading-8 text-white/65">La Voix du Nord évoquait en 2021 environ un millier de mariages en quinze ans, avec des événements d’entreprise, anniversaires et clubs. Son offre publique couvre cérémonies, cocktails, vins d’honneur et soirées, en solo, duo ou avec DJ.</p><p className="mt-5 max-w-2xl text-sm leading-7 text-white/45">Les plateformes associent son nom civil à la composition de plusieurs créations récentes et Matt Mez Sax à leur interprétation ou production. Les disponibilités et conditions restent toujours à confirmer directement.</p></article><div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-1 xl:grid-cols-2"><ReleaseList year="2024" items={releases2024} /><ReleaseList year="2025" items={releases2025} /></div></div>
    </section>
  );
}