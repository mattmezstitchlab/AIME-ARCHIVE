import React from "react";

const portraitUrl = "https://lvdneng.rosselcdn.net/sites/default/files/dpistyles_v2/vdn_864w/2021/03/06/node_952881/50688233/public/2021/03/06/B9726343109Z.1_20210306171203_000%2BGOVHNMRB2.2-0.jpg?itok=NrZEsPzm1615047131";

export default function FounderPortrait() {
  return (
    <section id="portrait" className="scroll-mt-8 border-b border-white/10 bg-black px-5 py-24 text-white sm:px-8 lg:px-12">
      <div className="mx-auto grid max-w-7xl gap-12 lg:grid-cols-[0.85fr_1.15fr] lg:items-center">
        <figure className="overflow-hidden rounded-[2rem] bg-card"><img src={portraitUrl} alt="Matthieu Lecointre, Matt Mez Sax, avec son saxophone au bord de la Lys" className="aspect-[4/5] h-full w-full object-cover grayscale" /><figcaption className="px-5 py-4 text-[0.6rem] uppercase tracking-[0.2em] text-white/45">Frelinghien · Photo publiée par La Voix du Nord · 2021</figcaption></figure>
        <article><p className="text-xs uppercase tracking-[0.3em] text-white/45">01 · Identité</p><h2 className="mt-5 font-display text-5xl font-semibold leading-[0.9] tracking-[-0.06em] sm:text-7xl">Le souffle comme fil conducteur.</h2><div className="mt-8 space-y-5 text-base leading-8 text-white/65 sm:text-lg"><p>Matt Mez Sax est le nom de scène de Matthieu Laurent Lecointre, saxophoniste événementiel français ancré dans le Nord et la métropole lilloise.</p><p>Sa présence publique relie deux gestes : faire circuler l’émotion par la musique et donner une forme claire aux idées par le design numérique. La scène, l’image et l’interface ne sont pas trois carrières séparées, mais trois manières d’organiser une rencontre.</p><p>Sur scène, il revendique un univers électro-jazzy, lounge et deep house, capable de passer d’un moment suspendu à une énergie dansante.</p></div></article>
      </div>
    </section>
  );
}