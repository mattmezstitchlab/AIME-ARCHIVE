import React from "react";
import { founderMilestones } from "@/components/founder/founderData";

export default function FounderTimeline() {
  return (
    <section className="bg-black px-5 py-24 text-white sm:px-8 lg:px-12">
      <div className="mx-auto max-w-7xl"><p className="text-xs uppercase tracking-[0.3em] text-white/45">02 · Trajectoire publique</p><h2 className="mt-5 max-w-4xl font-display text-5xl font-semibold leading-[0.9] tracking-[-0.06em] sm:text-7xl">De l’art à la scène, de la scène à AIME.</h2>
        <div className="mt-14 grid gap-px overflow-hidden rounded-[2rem] border border-white/10 bg-white/10 md:grid-cols-2 lg:grid-cols-3">{founderMilestones.map((item) => <article key={item.title} className="min-h-64 bg-background p-7"><p className="text-[0.62rem] uppercase tracking-[0.22em] text-white/40">{item.year}</p><h3 className="mt-8 font-display text-3xl font-semibold tracking-[-0.05em]">{item.title}</h3><p className="mt-4 text-sm leading-7 text-white/60">{item.text}</p></article>)}</div>
      </div>
    </section>
  );
}