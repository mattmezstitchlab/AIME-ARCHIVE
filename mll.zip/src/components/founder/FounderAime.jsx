import React from "react";
import { Link } from "react-router-dom";
import { ArrowUpRight } from "lucide-react";

export default function FounderAime() {
  return (
    <section className="bg-black px-5 py-28 text-white sm:px-8 lg:px-12"><div className="mx-auto max-w-7xl"><p className="text-xs uppercase tracking-[0.3em] text-white/45">05 · Le fondateur</p><div className="mt-6 grid gap-10 lg:grid-cols-[1.2fr_0.8fr]"><h2 className="font-display text-6xl font-semibold leading-[0.85] tracking-[-0.07em] sm:text-8xl">AIME® : faire de la mémoire une architecture.</h2><div className="space-y-5 text-base leading-8 text-white/60"><p>Sa page officielle présente Matthieu comme fondateur de la marque AIME® / Innovation & Digital Lab. Le laboratoire prolonge une même recherche : protéger l’intention, rendre les parcours lisibles et laisser la décision finale à l’humain.</p><p>Registres, timbres, agents et interfaces deviennent les instruments d’un orchestre numérique : l’IA prépare, organise et révèle ; l’humain relit, choisit et valide.</p><div className="flex flex-wrap gap-3 pt-4"><Link to="/aime-gardien" className="inline-flex min-h-11 items-center gap-2 rounded-full bg-white px-5 text-sm font-medium text-black">Découvrir AIME <ArrowUpRight className="h-4 w-4" /></Link><Link to="/magazine" className="inline-flex min-h-11 items-center rounded-full border border-white/20 px-5 text-sm">Lire le magazine</Link></div></div></div></div></section>
  );
}