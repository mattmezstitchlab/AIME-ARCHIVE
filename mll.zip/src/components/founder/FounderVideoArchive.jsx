import React from "react";
import { ArrowUpRight } from "lucide-react";

const playlistId = "UUKINTpRnSl4hbxYdCX6eogQ";

export default function FounderVideoArchive() {
  return (
    <section id="videos" className="border-y border-white/10 bg-card px-5 py-24 text-white sm:px-8 lg:px-12">
      <div className="mx-auto max-w-7xl">
        <p className="text-xs uppercase tracking-[0.3em] text-white/45">07 · Filmographie publique</p>
        <div className="mt-5 flex flex-col justify-between gap-7 lg:flex-row lg:items-end"><h2 className="max-w-4xl font-display text-5xl font-semibold leading-[0.9] tracking-[-0.06em] sm:text-7xl">Toutes les vidéos, dans la playlist officielle.</h2><a href="https://www.youtube.com/@mattmezsax/videos" target="_blank" rel="noreferrer" className="inline-flex min-h-11 items-center gap-2 text-sm">Ouvrir la chaîne <ArrowUpRight className="h-4 w-4" /></a></div>
        <div className="mt-12 overflow-hidden rounded-[2rem] border border-white/10 bg-black"><iframe className="aspect-video w-full" src={`https://www.youtube-nocookie.com/embed/videoseries?list=${playlistId}`} title="Toutes les vidéos publiques de Matt Mez Sax" loading="lazy" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowFullScreen /></div>
        <p className="mt-5 max-w-3xl text-xs leading-6 text-white/40">La playlist des mises en ligne est gérée par YouTube : les nouvelles publications apparaissent automatiquement avec leurs miniatures, du plus récent au plus ancien.</p>
      </div>
    </section>
  );
}