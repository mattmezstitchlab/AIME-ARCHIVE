import React from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, ArrowDown } from "lucide-react";
import HeroReliefAnimation from "@/components/portfolio/HeroReliefAnimation";

export default function FounderHero() {
  return (
    <header className="relative min-h-screen overflow-hidden bg-black px-5 py-6 text-white sm:px-8 lg:px-12">
      <HeroReliefAnimation className="absolute inset-0 h-full w-full opacity-80" />
      <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-black/45 to-black" />
      <div className="relative z-10 mx-auto flex min-h-[calc(100vh-3rem)] max-w-7xl flex-col">
        <nav className="flex items-center justify-between"><Link to="/" className="inline-flex min-h-11 items-center gap-2 rounded-full border border-white/20 bg-black/30 px-4 text-sm backdrop-blur-xl"><ArrowLeft className="h-4 w-4" /> Accueil</Link><span className="text-[0.6rem] uppercase tracking-[0.28em] text-white/50">Portrait documenté · 2026</span></nav>
        <div className="mt-auto max-w-5xl pb-12 pt-28">
          <p className="text-xs uppercase tracking-[0.34em] text-white/50">Hommage · Matt Mez Sax · Fondateur AIME®</p>
          <h1 className="mt-6 font-display text-6xl font-semibold leading-[0.82] tracking-[-0.075em] sm:text-8xl lg:text-[9rem]">Matthieu Laurent Lecointre.</h1>
          <p className="mt-8 max-w-2xl text-lg leading-8 text-white/65 sm:text-xl">Une vie en mouvement, entre études d’art, saxophone, scènes partagées, création musicale et architectures numériques sensibles.</p>
          <div className="mt-10 flex flex-wrap gap-3"><a href="#portrait" className="inline-flex min-h-11 items-center gap-2 rounded-full bg-white px-5 text-sm font-medium text-black">Lire le portrait <ArrowDown className="h-4 w-4" /></a><a href="#videos" className="inline-flex min-h-11 items-center rounded-full border border-white/20 bg-black/20 px-5 text-sm backdrop-blur-xl">Voir les vidéos</a></div>
        </div>
      </div>
    </header>
  );
}