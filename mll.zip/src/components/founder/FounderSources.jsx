import React from "react";
import { ArrowUpRight } from "lucide-react";
import { founderSources } from "@/components/founder/founderData";

export default function FounderSources() {
  return (
    <section className="bg-background px-5 py-24 text-white sm:px-8 lg:px-12"><div className="mx-auto max-w-7xl"><p className="text-xs uppercase tracking-[0.3em] text-white/45">08 · Sources consultées</p><div className="mt-8 grid gap-px overflow-hidden rounded-[2rem] border border-white/10 bg-white/10 md:grid-cols-2">{founderSources.map((source) => <a key={source.href} href={source.href} target="_blank" rel="noreferrer" className="group flex min-h-32 items-end justify-between gap-5 bg-background p-6 transition-colors hover:bg-card"><div><p className="text-sm font-medium">{source.label}</p><p className="mt-2 text-xs text-white/40">{source.detail}</p></div><ArrowUpRight className="h-5 w-5 text-white/40 transition-transform group-hover:-translate-y-1 group-hover:translate-x-1" /></a>)}</div><p className="mt-6 max-w-3xl text-xs leading-6 text-white/35">Portrait établi à partir de sources publiques recoupées en juillet 2026. Les audiences, disponibilités, tarifs et informations de plateforme évoluent : ils ne sont volontairement pas figés ici.</p></div></section>
  );
}