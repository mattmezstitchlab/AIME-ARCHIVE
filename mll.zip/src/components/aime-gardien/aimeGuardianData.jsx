export const UNKNOWN_TEXT = "Information inconnue ou à préciser.";

export const sensitiveKeywords = [
  "enfant",
  "mineur",
  "agression",
  "viol",
  "violence",
  "danger",
  "menace",
  "plainte",
  "urgence",
  "harcèlement",
  "témoin",
  "peur",
  "victime",
  "abus",
];

export const modes = {
  presence: {
    label: "Présence",
    phrase: "Mémoire, soutien, timbre public après validation.",
    role: "Accueillir une parole, une mémoire, une trace ou une intention personnelle.",
    output: ["note privée", "timbre symbolique", "présence validable", "public possible uniquement après validation humaine"],
    rule: "Ne jamais transformer une présence en plainte ou signalement automatique.",
  },
  manifesto: {
    label: "Manifeste",
    phrase: "Photo d’enfance, texte manifeste, charte signée.",
    role: "Créer un timbre manifeste symbolique avec une image autorisée ou une présence sans visage.",
    output: ["photo de moi enfant si je suis majeur(e)", "portrait actuel gravé", "présence sans visage identifiable", "texte manifeste éditable"],
    rule: "Ne jamais publier sans validation explicite, ni collecter de témoignage sensible public.",
    samples: [
      "Pour l’enfant que j’ai été. Pour celles qui ont parlé. Pour celles qu’on n’a pas entendues.",
      "Je crée ce timbre pour inscrire une présence : celle de l’enfant que j’ai été, celle des filles qu’on doit protéger, celle des femmes qui refusent le silence.",
      "Une photo, une mémoire, une intention : ne plus laisser les paroles disparaître.",
    ],
    validation: "Je confirme être majeur(e), utiliser une image dont j’ai les droits, comprendre que ce timbre est symbolique et qu’il ne constitue ni une plainte, ni une preuve, ni un document officiel.",
  },
  protection: {
    label: "Protection",
    phrase: "Situation sensible, privé obligatoire.",
    role: "Traiter les situations sensibles en confidentialité stricte.",
    output: ["privé obligatoire", "aucune publication", "export privé uniquement", "validation humaine obligatoire", "relais essentiels : 17 / 112 / 114 / 119"],
    rule: "Ce mode prépare une fiche privée. Il ne reçoit pas de plainte officielle.",
  },
  pilot: {
    label: "Pilote",
    phrase: "Démonstrateur fermé, données fictives.",
    role: "Démonstrateur institutionnel sans données sensibles réelles.",
    output: ["données fictives uniquement", "aucun cas réel", "aucun transfert officiel", "audit visible", "rôles simulés"],
    rule: "Ne jamais utiliser de cas réel dans le démonstrateur public.",
    roles: ["créateur", "écoutant", "validateur", "observateur", "administrateur"],
  },
};

export const agents = [
  { name: "Urgence", phrase: "Je rappelle les relais essentiels.", function: "Rappeler les relais essentiels et les limites de l’outil.", limit: "Ne classe pas les dossiers par danger." },
  { name: "Écoute", phrase: "Je vous aide à formuler sans juger.", function: "Aider à formuler sans juger.", limit: "Ne valide pas la véracité." },
  { name: "Temps", phrase: "Je remets les éléments dans l’ordre.", function: "Remettre les éléments dans l’ordre.", limit: "Ne conclut pas à une causalité." },
  { name: "Pièces", phrase: "Je distingue ce qui existe et ce qui manque.", function: "Distinguer pièces présentes, absentes et à clarifier.", limit: "Ne qualifie pas la valeur probante." },
  { name: "Relais", phrase: "Je propose des portes possibles.", function: "Proposer des portes humaines possibles.", limit: "Ne prescrit pas une action obligatoire." },
  { name: "Scellé", phrase: "Je prépare une fiche privée, datée, versionnée.", function: "Préparer une fiche privée, datée et versionnée.", limit: "Ne crée pas d’acte officiel." },
];

export const guardianLines = [
  "Je ne juge pas. Je garde.",
  "Vous pouvez écrire avec vos mots.",
  "Les dates peuvent être approximatives.",
  "Rien n’est publié automatiquement.",
];

export const accordionItems = [
  {
    title: "Ce que la machine prépare",
    items: [
      "accueille une parole avec méthode",
      "aide à formuler avec ses propres mots",
      "structure une chronologie, même approximative",
      "distingue les éléments disponibles et manquants",
      "prépare une orientation possible",
      "date, versionne et scelle une fiche privée",
      "prépare un export privé non officiel",
      "demande une validation humaine avant toute exposition",
    ],
  },
  {
    title: "Ce qu’elle ne fait jamais",
    items: [
      "aucune plainte officielle",
      "aucune enquête",
      "aucun coupable désigné",
      "aucune qualification juridique automatique",
      "aucun score de danger",
      "aucun score de crédibilité",
      "aucune transmission automatique",
      "ne remplace pas police, gendarmerie, justice, avocat, association ou professionnel",
    ],
  },
  {
    title: "Conformité par conception",
    items: [
      "données minimisées",
      "privé par défaut en Mode Protection",
      "aucune plainte officielle, aucune enquête, aucune décision automatique",
      "aucun score de danger, aucun score de crédibilité",
      "journal d’audit, validation humaine et export privé non officiel",
      "AIPD / RGPD à prévoir avant toute expérimentation sensible",
      "version souveraine possible en environnement fermé",
    ],
  },
  {
    title: "Version souveraine / pilote institutionnel",
    text: "AIME Gardien peut fonctionner en démonstrateur public sans données sensibles, puis en version fermée, hébergée en environnement souverain, avec accès par rôles, journal d’audit, données minimisées et validation humaine obligatoire.",
    items: ["données fictives", "aucun cas réel", "aucun transfert", "audit visible", "rôles simulés", "fiche exemple"],
  },
];