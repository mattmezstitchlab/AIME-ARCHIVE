import React, { useEffect } from "react";
import { X } from "lucide-react";
import { UNKNOWN_TEXT, modes } from "./aimeGuardianData";

const orientationFields = [
  ["Personne concernée", "moi / enfant / proche / témoin / professionnel"],
  ["Département", UNKNOWN_TEXT],
  ["Chronologie courte", "Éléments à remettre dans l’ordre, même approximativement."],
  ["Faits déclarés", "Texte préparatoire, non qualifié juridiquement."],
  ["Éléments disponibles", "Documents, dates, traces ou repères déjà connus."],
  ["Pièces manquantes", "Ce qui manque est simplement noté comme manquant."],
  ["Relais possible", "Porte humaine à identifier ou confirmer."],
];

export default function AimeGardienDrawer({ open, onClose, code, mode, clarityLevel, createdAt, modifiedAt, sensitiveLock }) {
  useEffect(() => {
    if (!open) return undefined;
    const handleKeyDown = (event) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [open, onClose]);

  if (!open) return null;

  const journal = [
    ["créé le", createdAt],
    ["dernière modification", modifiedAt],
    ["mode choisi", modes[mode]?.label || "Présence"],
    ["statut", sensitiveLock ? "privé obligatoire" : "brouillon"],
    ["niveau de clarté", clarityLevel],
    ["export privé", "oui — non officiel"],
    ["validation humaine", "requise"],
    ["version", "v0.1"],
    ["rôle de relecture", "humain responsable"],
    ["transmission automatique", "non"],
  ];

  return (
    <div className="fixed inset-0 z-50" role="dialog" aria-modal="true" aria-labelledby="orientation-title">
      <button type="button" aria-label="Fermer la fiche" onClick={onClose} className="absolute inset-0 cursor-default bg-black/70 backdrop-blur-sm" />
      <aside className="absolute right-0 top-0 flex h-full w-full max-w-xl flex-col overflow-y-auto border-l border-amber-100/15 bg-[#080913] p-5 text-white shadow-[-30px_0_100px_rgba(0,0,0,0.55)] sm:p-7">
        <div className="flex items-start justify-between gap-4">
          <div>
            <p className="text-xs font-bold uppercase tracking-[0.28em] text-amber-100/50">Fiche d’orientation</p>
            <h2 id="orientation-title" className="mt-3 font-display text-4xl font-semibold tracking-[-0.06em]">Scellé AIME — non officiel</h2>
            <p className="mt-3 text-sm leading-6 text-white/64">Fiche privée de préparation. Ne vaut ni plainte, ni preuve, ni décision.</p>
          </div>
          <button type="button" onClick={onClose} className="rounded-full border border-white/10 p-3 text-white/70 outline-none transition hover:bg-white hover:text-black focus-visible:ring-2 focus-visible:ring-amber-200/70">
            <X className="h-4 w-4" aria-hidden="true" />
            <span className="sr-only">Fermer</span>
          </button>
        </div>

        <div className="mt-6 grid gap-3 rounded-[1.5rem] border border-amber-100/15 bg-amber-100/[0.055] p-4 text-sm sm:grid-cols-2">
          <p><span className="block text-white/42">Code AIME</span><strong>{code}</strong></p>
          <p><span className="block text-white/42">Date</span><strong>{createdAt}</strong></p>
          <p><span className="block text-white/42">Mode</span><strong>{modes[mode]?.label}</strong></p>
          <p><span className="block text-white/42">Statut</span><strong>{sensitiveLock ? "privé obligatoire" : "brouillon"}</strong></p>
        </div>

        <div className="mt-6 grid gap-3">
          {orientationFields.map(([label, value]) => (
            <div key={label} className="rounded-2xl border border-white/10 bg-white/[0.035] p-4">
              <p className="text-[10px] font-bold uppercase tracking-[0.24em] text-white/40">{label}</p>
              <p className="mt-2 text-sm leading-6 text-white/72">{value}</p>
            </div>
          ))}
        </div>

        <div className="mt-6 rounded-[1.5rem] border border-white/10 bg-black/30 p-4">
          <h3 className="font-display text-2xl font-semibold tracking-[-0.04em]">Journal de garde</h3>
          <dl className="mt-4 grid gap-2 text-sm">
            {journal.map(([label, value]) => (
              <div key={label} className="grid grid-cols-[1fr_auto] gap-4 border-b border-white/10 pb-2 last:border-b-0">
                <dt className="text-white/45">{label}</dt>
                <dd className="text-right font-semibold text-white/82">{value}</dd>
              </div>
            ))}
          </dl>
        </div>
      </aside>
    </div>
  );
}