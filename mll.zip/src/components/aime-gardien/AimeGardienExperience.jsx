import React, { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import AimeGardienAccordions from "./AimeGardienAccordions";
import AimeGardienDrawer from "./AimeGardienDrawer";
import AimeGardienMachine from "./AimeGardienMachine";
import { sensitiveKeywords } from "./aimeGuardianData";

function createCode() {
  const number = Math.floor(100 + Math.random() * 900);
  const letters = Math.random().toString(36).slice(2, 5).toUpperCase();
  return `${number}-${letters}`;
}

function formatDate(date) {
  return date.toLocaleDateString("fr-FR", { day: "2-digit", month: "2-digit", year: "numeric" });
}

function hasSensitiveContent(value) {
  const text = value.toLowerCase();
  return sensitiveKeywords.some((keyword) => text.includes(keyword));
}

function getClarityLevel({ prompt, capsuleEnabled, capsuleDate, capsuleMessage, prepared }) {
  const hasPrompt = !!prompt?.trim() && prompt !== "Information inconnue ou à préciser.";
  const capsuleReady = !capsuleEnabled || !!capsuleDate || !!capsuleMessage?.trim();
  if (prepared) return "prêt à relire";
  if (hasPrompt && capsuleReady && capsuleEnabled) return "clair";
  if (hasPrompt || capsuleEnabled || capsuleMessage?.trim()) return "partiel";
  return "à compléter";
}

export default function AimeGardienExperience() {
  const [code] = useState(createCode);
  const [mode, setMode] = useState("presence");
  const [prompt, setPrompt] = useState("");
  const [capsuleEnabled, setCapsuleEnabled] = useState(false);
  const [capsuleDate, setCapsuleDate] = useState("");
  const [capsuleMessage, setCapsuleMessage] = useState("");
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [prepared, setPrepared] = useState(false);
  const [screenRequest, setScreenRequest] = useState(0);
  const [createdAt] = useState(() => new Date());
  const [modifiedAt, setModifiedAt] = useState(() => new Date());
  const [quickExitNote, setQuickExitNote] = useState(false);

  const sensitiveLock = useMemo(() => hasSensitiveContent(`${prompt} ${capsuleMessage}`), [prompt, capsuleMessage]);

  useEffect(() => {
    if (sensitiveLock) setMode("protection");
  }, [sensitiveLock]);

  useEffect(() => {
    setModifiedAt(new Date());
  }, [mode, prompt, capsuleEnabled, capsuleDate, capsuleMessage, prepared]);

  const clarityLevel = useMemo(
    () => getClarityLevel({ prompt, capsuleEnabled, capsuleDate, capsuleMessage, prepared }),
    [prompt, capsuleEnabled, capsuleDate, capsuleMessage, prepared]
  );

  const scrollToMachine = () => {
    document.getElementById("aime-guardian-machine")?.scrollIntoView({ behavior: "smooth", block: "center" });
  };

  const handlePilot = () => {
    setMode("pilot");
    scrollToMachine();
  };

  const handleFrame = () => {
    setScreenRequest((value) => value + 1);
    scrollToMachine();
  };

  const handleQuickExit = () => {
    setDrawerOpen(false);
    setQuickExitNote(true);
    window.location.href = "/";
  };

  return (
    <main className="min-h-screen overflow-hidden bg-[#03040a] text-white">
      <div className="absolute inset-0 -z-0 bg-[radial-gradient(circle_at_18%_8%,rgba(218,185,110,0.18),transparent_30%),radial-gradient(circle_at_82%_18%,rgba(35,50,96,0.32),transparent_34%),linear-gradient(180deg,#03040a_0%,#070915_52%,#020205_100%)]" />
      <div className="relative z-10 px-5 py-6 sm:px-8 lg:px-12">
        <nav className="mx-auto flex max-w-7xl items-center justify-between gap-4" aria-label="Navigation AIME Gardien">
          <Link to="/" className="inline-flex min-h-11 items-center gap-2 rounded-full border border-white/15 bg-white/[0.04] px-4 py-3 text-xs font-semibold uppercase tracking-[0.2em] text-white/78 transition-colors hover:bg-white hover:text-black focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-200/70">
            <ArrowLeft className="h-4 w-4" aria-hidden="true" /> Accueil
          </Link>
          <button type="button" onClick={handleQuickExit} className="min-h-11 rounded-full border border-amber-200/25 bg-amber-200/10 px-4 py-3 text-xs font-semibold uppercase tracking-[0.2em] text-amber-100 transition-colors hover:bg-amber-100 hover:text-black focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-200/70">
            Quitter vite
          </button>
        </nav>

        {quickExitNote && <p role="status" className="sr-only">Sortie rapide de l’interface. Pensez à votre historique si nécessaire.</p>}

        <section className="mx-auto grid max-w-7xl items-center gap-10 py-12 lg:grid-cols-[0.88fr_1fr] lg:py-14">
          <header className="max-w-2xl">
            <p className="text-xs font-bold uppercase tracking-[0.35em] text-amber-100/48">AIME Gardien · Machine de pré-orientation humaine</p>
            <h1 className="mt-5 font-display text-5xl font-semibold leading-[0.9] tracking-[-0.08em] text-white sm:text-7xl lg:text-8xl">
              Le scellé avant le sceau.
            </h1>
            <p className="mt-6 max-w-xl text-lg leading-8 text-white/72">
              AIME Gardien accueille, guide et structure une parole ou un dossier sans remplacer la justice.
            </p>
            <p className="mt-4 max-w-xl text-sm leading-6 text-white/54">
              Une machine de renfort pour préparer la clarté : mode, intention, timbre, fiche privée, journal de garde, niveau de clarté et validation humaine.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <button type="button" onClick={scrollToMachine} className="rounded-full bg-[#f4efe4] px-5 py-3 text-xs font-black uppercase tracking-[0.18em] text-stone-950 transition hover:bg-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-200/70">
                Démarrer la machine
              </button>
              <button type="button" onClick={handleFrame} className="rounded-full border border-white/15 px-5 py-3 text-xs font-black uppercase tracking-[0.18em] text-white/82 transition hover:bg-white hover:text-black focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-200/70">
                Voir le cadre
              </button>
              <button type="button" onClick={handlePilot} className="rounded-full border border-white/15 px-5 py-3 text-xs font-black uppercase tracking-[0.18em] text-white/82 transition hover:bg-white hover:text-black focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-200/70">
                Mode Pilote
              </button>
            </div>
            <p className="mt-7 rounded-[1.4rem] border border-white/10 bg-white/[0.035] p-4 text-sm leading-6 text-white/68">
              AIME Gardien prépare la clarté. Il n’évalue pas les personnes, ne qualifie pas juridiquement les faits, ne transmet rien automatiquement et ne remplace aucune autorité.
            </p>
          </header>

          <AimeGardienMachine
            code={code}
            mode={mode}
            setMode={setMode}
            prompt={prompt}
            setPrompt={setPrompt}
            capsuleEnabled={capsuleEnabled}
            setCapsuleEnabled={setCapsuleEnabled}
            capsuleDate={capsuleDate}
            setCapsuleDate={setCapsuleDate}
            capsuleMessage={capsuleMessage}
            setCapsuleMessage={setCapsuleMessage}
            clarityLevel={clarityLevel}
            sensitiveLock={sensitiveLock}
            prepared={prepared}
            setPrepared={setPrepared}
            onOpenSheet={() => setDrawerOpen(true)}
            onQuickExit={handleQuickExit}
            screenRequest={screenRequest}
          />
        </section>

        <AimeGardienAccordions />

        <footer className="mx-auto mt-12 max-w-5xl border-t border-white/10 py-8 text-center">
          <p className="font-display text-3xl font-semibold tracking-[-0.05em] text-white">Le scellé avant le sceau.</p>
          <p className="mt-3 text-sm font-semibold uppercase tracking-[0.22em] text-amber-100/70">L’IA prépare. L’humain valide. Rien n’est transmis automatiquement.</p>
        </footer>
      </div>

      <AimeGardienDrawer
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        code={code}
        mode={mode}
        clarityLevel={clarityLevel}
        createdAt={formatDate(createdAt)}
        modifiedAt={formatDate(modifiedAt)}
        sensitiveLock={sensitiveLock}
      />
    </main>
  );
}