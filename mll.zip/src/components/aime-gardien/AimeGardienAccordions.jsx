import React, { useState } from "react";
import { ChevronDown } from "lucide-react";
import { accordionItems } from "./aimeGuardianData";

export default function AimeGardienAccordions() {
  const [open, setOpen] = useState(null);

  return (
    <section className="mx-auto grid max-w-4xl gap-3" aria-label="Cadre AIME Gardien">
      {accordionItems.map((item, index) => {
        const active = open === index;
        return (
          <article key={item.title} className="overflow-hidden rounded-[1.35rem] border border-white/10 bg-white/[0.035]">
            <button
              type="button"
              aria-expanded={active}
              onClick={() => setOpen(active ? null : index)}
              className="flex w-full items-center justify-between gap-4 p-5 text-left outline-none transition hover:bg-white/[0.035] focus-visible:ring-2 focus-visible:ring-amber-200/70"
            >
              <span className="font-display text-xl font-semibold tracking-[-0.04em] text-white sm:text-2xl">{item.title}</span>
              <ChevronDown aria-hidden="true" className={`h-5 w-5 flex-shrink-0 text-amber-100/70 transition-transform ${active ? "rotate-180" : ""}`} />
            </button>
            {active && (
              <div className="border-t border-white/10 px-5 pb-5 pt-4 text-sm leading-6 text-white/70">
                {item.text && <p className="mb-3">{item.text}</p>}
                <ul className="grid gap-2">
                  {item.items.map((line) => (
                    <li key={line} className="flex gap-2">
                      <span aria-hidden="true" className="mt-2 h-1.5 w-1.5 rounded-full bg-amber-200/70" />
                      <span>{line}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </article>
        );
      })}
    </section>
  );
}