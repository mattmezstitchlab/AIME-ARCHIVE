import React from "react";
import { Lock, Shield, Sparkles } from "lucide-react";
import { UNKNOWN_TEXT } from "./aimeGuardianData";

export default function AimeGardienMachine({
  code,
  prompt,
  setPrompt,
  sensitiveLock,
  setPrepared,
  onOpenSheet,
  onQuickExit,
}) {
  const handleUnknown = () => {
    setPrompt(UNKNOWN_TEXT);
  };

  const handlePrepare = () => {
    setPrepared(true);
    if (sensitiveLock) {
      onOpenSheet();
    }
  };

  return (
    <section id="aime-guardian-machine" aria-label="Machine AIME Gardien" className="mx-auto w-full max-w-[400px]">
      <div className="relative overflow-hidden rounded-[2.4rem] border border-white/20 bg-white/[0.08] p-3 text-white shadow-[0_34px_120px_rgba(0,0,0,0.6)] backdrop-blur-3xl">
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_22%_0%,rgba(255,255,255,0.24),transparent_30%),linear-gradient(145deg,rgba(255,255,255,0.16),rgba(255,255,255,0.035))]" />
        <div className="pointer-events-none absolute left-1/2 top-3 h-1.5 w-14 -translate-x-1/2 rounded-full bg-black/35 ring-1 ring-white/15" />

        <div className="relative rounded-[2rem] border border-white/10 bg-black/25 p-4 shadow-[inset_0_1px_0_rgba(255,255,255,0.22)]">
          <header className="flex items-center justify-between gap-3">
            <div className="flex min-w-0 items-center gap-3">
              <span className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-2xl bg-white/12 shadow-inner backdrop-blur-xl">
                <Shield className="h-5 w-5 text-white" aria-hidden="true" />
              </span>
              <div className="min-w-0">
                <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-white/48">AIME Gardien</p>
                <p className="mt-1 truncate text-sm font-semibold text-white/88">Espace privé</p>
              </div>
            </div>
            <p className="flex-shrink-0 rounded-full bg-white/12 px-3 py-2 font-mono text-[10px] font-bold tracking-[0.16em] text-white/82 ring-1 ring-white/10">{code}</p>
          </header>

          <div className="mt-5 rounded-[1.8rem] border border-white/10 bg-white/[0.075] p-5 shadow-[inset_0_1px_0_rgba(255,255,255,0.16)] backdrop-blur-2xl">
            <p className="text-[11px] font-bold uppercase tracking-[0.24em] text-white/42">1 · Écrire</p>
            <h2 className="mt-3 font-display text-3xl font-semibold leading-tight tracking-[-0.06em] text-white">Posez vos mots simplement.</h2>
            <p className="mt-3 text-sm leading-6 text-white/58">Même si ce n’est pas clair. Même si c’est incomplet.</p>

            <div className="mt-5 flex items-center gap-3 rounded-2xl bg-black/20 px-4 py-3 ring-1 ring-white/10">
              <input
                id="guardian-prompt"
                type="text"
                value={prompt}
                onChange={(event) => setPrompt(event.target.value)}
                placeholder="Écrire ici…"
                className="min-w-0 flex-1 bg-transparent text-base text-white outline-none placeholder:text-white/34 focus-visible:ring-2 focus-visible:ring-white/70"
              />
              <Sparkles className="h-4 w-4 flex-shrink-0 text-white/45" aria-hidden="true" />
            </div>
          </div>

          {sensitiveLock && (
            <div className="mt-3 rounded-[1.5rem] bg-amber-300/12 p-4 text-sm leading-6 text-amber-50 ring-1 ring-amber-200/20">
              <strong>Privé obligatoire.</strong><br />En danger immédiat : 17 / 112 / 114 / 119.
            </div>
          )}

          <div className="mt-4 grid gap-2">
            <button type="button" onClick={handlePrepare} className="min-h-12 rounded-full bg-white px-5 text-xs font-black uppercase tracking-[0.16em] text-slate-950 outline-none transition hover:bg-white/90 focus-visible:ring-2 focus-visible:ring-white/70">
              2 · Préparer ma fiche
            </button>
            <div className="grid grid-cols-2 gap-2">
              <button type="button" onClick={handleUnknown} className="min-h-11 rounded-full bg-white/10 px-4 text-[10px] font-bold uppercase tracking-[0.12em] text-white/72 outline-none transition hover:bg-white/16 focus-visible:ring-2 focus-visible:ring-white/70">
                Je ne sais pas
              </button>
              <button type="button" onClick={onOpenSheet} className="min-h-11 rounded-full bg-white/10 px-4 text-[10px] font-bold uppercase tracking-[0.12em] text-white/72 outline-none transition hover:bg-white/16 focus-visible:ring-2 focus-visible:ring-white/70">
                Voir la fiche
              </button>
            </div>
          </div>

          <footer className="mt-4 flex items-center justify-between gap-3 text-[11px] font-semibold uppercase tracking-[0.14em] text-white/45">
            <p><Lock className="mr-1 inline h-3 w-3" aria-hidden="true" /> Rien n’est envoyé seul.</p>
            <button type="button" onClick={onQuickExit} className="rounded-full bg-white/10 px-4 py-2 text-[10px] font-bold uppercase tracking-[0.14em] text-white/62 outline-none transition hover:bg-white hover:text-slate-950 focus-visible:ring-2 focus-visible:ring-white/70">Quitter</button>
          </footer>
        </div>
      </div>
    </section>
  );
}