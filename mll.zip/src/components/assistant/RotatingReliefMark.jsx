import React from "react";

export default function RotatingReliefMark() {
  return (
    <span className="relative block h-5 w-5" aria-hidden="true">
      <svg viewBox="0 0 24 24" className="absolute inset-0 h-full w-full animate-[spin_8s_linear_infinite] fill-none stroke-current">
        <circle cx="12" cy="12" r="9" strokeWidth="1.2" strokeDasharray="17 8" />
        <circle cx="12" cy="12" r="5.5" strokeWidth="0.8" strokeDasharray="8 5" opacity="0.55" />
      </svg>
      <svg viewBox="0 0 24 24" className="absolute inset-1 h-3 w-3 animate-[spin_5s_linear_infinite_reverse] fill-none stroke-current opacity-70">
        <path d="M12 2a10 10 0 0 1 9.2 6.1M22 12a10 10 0 0 1-6.2 9.2M12 22a10 10 0 0 1-9.2-6.1M2 12a10 10 0 0 1 6.2-9.2" strokeWidth="1.5" strokeLinecap="round" />
      </svg>
    </span>
  );
}