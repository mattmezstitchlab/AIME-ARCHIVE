import React, { useState } from "react";
import { Plus } from "lucide-react";
import { useLocation } from "react-router-dom";
import AimeConcierge from "@/components/assistant/AimeConcierge";

export default function SiteAssistant() {
  const [open, setOpen] = useState(false);
  const { pathname, search } = useLocation();
  const projectTitle = new URLSearchParams(search).get("project") || "";
  const starter = projectTitle ? `Bonjour, j’aimerais parler d’un projet similaire à ${projectTitle}.` : "";
  const isAboutPage = pathname === "/a-propos" || pathname === "/APropos";
  if (pathname.startsWith("/admin")) return null;
  return (
    <aside className={`fixed bottom-4 z-50 sm:bottom-6 ${isAboutPage ? "right-4 sm:right-6" : "left-1/2 -translate-x-1/2"} ${open ? "w-[calc(100vw-2rem)] sm:w-[21.75rem]" : "w-20"}`}>
      {open && <div className="mb-4 w-full"><AimeConcierge starter={starter} onClose={() => setOpen(false)} /></div>}
      <button onClick={() => setOpen((current) => !current)} className={`aime-launcher flex h-20 w-20 items-center justify-center rounded-full text-white ${isAboutPage ? "ml-auto" : "mx-auto"}`} aria-expanded={open} aria-label={open ? "Fermer AIME Concierge" : "Ouvrir AIME Concierge"}><Plus className={`h-8 w-8 transition-transform duration-300 ${open ? "rotate-45" : ""}`} /></button>
    </aside>
  );
}