import React, { useEffect, useRef, useState } from "react";
import { Send } from "lucide-react";
import { base44 } from "@/api/base44Client";
import AssistantMessage from "@/components/assistant/AssistantMessage";
import ConciergeHeader from "@/components/assistant/ConciergeHeader";

const STORAGE_KEY = "aime_concierge_conversation";
const suggestions = ["Parler d’un projet numérique", "Réserver une prestation musicale", "Découvrir le studio"];

export default function AimeConcierge({ embedded = false, starter = "", onClose }) {
  const [conversationId, setConversationId] = useState("");
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState(starter);
  const [sending, setSending] = useState(false);
  const conversationRef = useRef(null);
  const endRef = useRef(null);

  useEffect(() => {
    let active = true;
    const start = async () => {
      const savedId = localStorage.getItem(STORAGE_KEY);
      let conversation;
      try { conversation = savedId ? await base44.agents.getConversation(savedId) : null; } catch { conversation = null; }
      if (!conversation) {
        conversation = await base44.agents.createConversation({ agent_name: "aime_concierge", metadata: { name: "Conversation site", description: "Accueil et demande client" } });
        localStorage.setItem(STORAGE_KEY, conversation.id);
      }
      if (active) { conversationRef.current = conversation; setConversationId(conversation.id); setMessages(conversation.messages || []); }
    };
    start();
    return () => { active = false; };
  }, []);

  useEffect(() => {
    if (!conversationId) return undefined;
    return base44.agents.subscribeToConversation(conversationId, (data) => {
      conversationRef.current = data;
      setMessages(data.messages || []);
      if (data.messages?.at(-1)?.role === "assistant") setSending(false);
    });
  }, [conversationId]);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  const send = async (text = input) => {
    const content = text.trim();
    if (!content || !conversationRef.current || sending) return;
    setInput("");
    setSending(true);
    await base44.agents.addMessage(conversationRef.current, { role: "user", content });
  };

  const restart = async () => {
    if (sending) return;
    setSending(true);
    const conversation = await base44.agents.createConversation({ agent_name: "aime_concierge", metadata: { name: "Conversation site", description: "Accueil et demande client" } });
    localStorage.setItem(STORAGE_KEY, conversation.id);
    conversationRef.current = conversation;
    setConversationId(conversation.id);
    setMessages([]);
    setInput(starter);
    setSending(false);
  };

  return (
    <section className={embedded ? "flex h-[min(72vh,46rem)] flex-col overflow-hidden rounded-[1.6rem] border border-white/15 bg-black text-white shadow-2xl" : "flex h-[35rem] flex-col overflow-hidden rounded-[1.6rem] border border-white/15 bg-black text-white shadow-2xl"} aria-label="Assistant AIME Concierge">
      <ConciergeHeader onClose={onClose} onRestart={restart} sending={sending} />
      <div className="flex-1 space-y-4 overflow-y-auto px-4 py-5" aria-live="polite">
        {!messages.length && <div className="flex items-end gap-2"><span className="mb-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-white/20 text-[0.55rem] text-white/80">AIME</span><div className="max-w-[78%] rounded-[1.2rem] rounded-bl-none bg-[#202020] px-3 py-2.5 text-[0.8rem] leading-[1.45] text-white/90">Bonjour, je suis l’assistant de Matthieu. Je peux répondre à vos questions ou préparer votre demande avec vous, jusqu’à sa confirmation.</div></div>}
        {!messages.length && <div className="flex flex-col items-end gap-2">{suggestions.map((label) => <button key={label} onClick={() => send(label)} className="rounded-full bg-white px-3.5 py-2 text-xs text-black hover:bg-white/85">{label}</button>)}</div>}
        {messages.map((message, index) => <AssistantMessage key={`${message.role}-${index}`} message={message} />)}
        {sending && <div className="flex items-center gap-2 pl-10 text-xs text-white/60"><span className="flex h-9 w-9 items-center justify-center rounded-full bg-[#242424] text-base tracking-[0.12em]">•••</span>AIME Concierge écrit…</div>}
        <div ref={endRef} />
      </div>
      <form onSubmit={(event) => { event.preventDefault(); send(); }} className="flex h-[4.25rem] items-center gap-3 border-t border-white/15 px-5"><label className="sr-only" htmlFor="aime-assistant-message">Votre message</label><textarea id="aime-assistant-message" rows="1" value={input} onChange={(event) => setInput(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); send(); } }} placeholder="Écrivez votre message…" className="min-h-10 flex-1 resize-none bg-transparent py-2.5 text-xs text-white outline-none placeholder:text-white/35" /><button type="submit" disabled={sending || !input.trim()} className="inline-flex min-h-10 items-center gap-2 px-1 text-xs font-medium text-white disabled:opacity-40" aria-label="Envoyer">Envoyer<Send className="h-3.5 w-3.5" /></button></form>
    </section>
  );
}