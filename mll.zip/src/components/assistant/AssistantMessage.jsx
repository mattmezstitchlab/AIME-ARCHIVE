import React from "react";
import ReactMarkdown from "react-markdown";
import { CheckCircle2, Loader2, XCircle } from "lucide-react";

function ToolState({ toolCall }) {
  const pending = ["pending", "running", "in_progress"].includes(toolCall.status);
  const failed = ["failed", "error"].includes(toolCall.status);
  const projection = toolCall.display_projection;
  const label = projection?.hide_details && projection?.details_redacted
    ? (pending ? projection.active_label : failed ? projection.error_label : projection.label)
    : (pending ? "Traitement en cours…" : failed ? "Action non aboutie" : "Action terminée");
  const Icon = pending ? Loader2 : failed ? XCircle : CheckCircle2;
  return <p className="mt-2 inline-flex items-center gap-2 rounded-full border border-white/10 px-3 py-1 text-xs text-white/55"><Icon className={`h-3.5 w-3.5 ${pending ? "animate-spin" : ""}`} />{label}</p>;
}

export default function AssistantMessage({ message }) {
  const user = message.role === "user";
  return (
    <div className={user ? "flex justify-end" : "flex justify-start"}>
      <div className={user ? "max-w-[85%] rounded-[1.4rem] rounded-br-md bg-white px-4 py-3 text-sm leading-6 text-black" : "max-w-[90%] rounded-[1.4rem] rounded-bl-md bg-white/[0.07] px-4 py-3 text-sm leading-6 text-white/85"}>
        {message.content && (user ? <p className="whitespace-pre-wrap">{message.content}</p> : <ReactMarkdown>{message.content}</ReactMarkdown>)}
        {message.tool_calls?.map((toolCall, index) => <ToolState key={`${toolCall.name}-${index}`} toolCall={toolCall} />)}
      </div>
    </div>
  );
}