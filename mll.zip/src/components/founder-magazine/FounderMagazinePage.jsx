import React from "react";
import FounderIntroSpread from "@/components/founder-magazine/FounderIntroSpread";
import FounderEditorialChapter from "@/components/founder-magazine/FounderEditorialChapter";
import FounderPlaylistSpread from "@/components/founder-magazine/FounderPlaylistSpread";
import FounderSourcesSpread from "@/components/founder-magazine/FounderSourcesSpread";

export default function FounderMagazinePage({ page, projects }) {
  return (
    <main className="min-h-screen overflow-x-hidden bg-background"><FounderIntroSpread page={page} />{(page.chapters || []).map((chapter, index) => <FounderEditorialChapter key={`${chapter.number}-${chapter.title}`} chapter={chapter} project={projects.length ? projects[index % projects.length] : null} index={index} />)}<FounderPlaylistSpread playlistId={page.youtube_playlist_id} /><FounderSourcesSpread sources={page.sources} /></main>
  );
}