import React from "react";
import { ArrowDown, ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";
import HeroReliefAnimation from "@/components/portfolio/HeroReliefAnimation";

export default function FounderMagazineHero({ page }) {
  return (
    <header className="relative min-h-screen overflow-hidden bg-black text-white">
      <HeroReliefAnimation className="absolute inset-0 h-full w-full opacity-55" />
      <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-black/55 to-black" />
      <div className="relative z-10 mx-auto flex min-h-screen max-w-7xl flex-col px-5 py-6 sm:px-8 lg:px-12">
        <nav className="flex items-center justify-between"><Link to="/" className="inline-flex min-h-11 items-center gap-2 rounded-full border border-white/20 bg-black/30 px-4 text-sm backdrop-blur-xl"><ArrowLeft className="h-4 w-4" /> Accueil</Link><span className="text-[0.6rem] uppercase tracking-[0.28em] text-white/50">Portrait documenté · 2026</span></nav>
        <div className="mt-auto grid items-end gap-10 pb-12 pt-24 lg:grid-cols-[1.1fr_0.55fr]">
          <div><p className="text-xs uppercase tracking-[0.34em] text-white/50">{page.hero_kicker}</p><h1 className="mt-6 font-display text-6xl font-semibold leading-[0.82] tracking-[-0.075em] sm:text-8xl lg:text-[8rem]">{page.hero_title}</h1><p className="mt-8 max-w-2xl text-lg leading-8 text-white/65">{page.hero_intro}</p><a href="#biographie" className="mt-9 inline-flex min-h-11 items-center gap-2 rounded-full bg-white px-5 text-sm font-medium text-black">Lire le portrait <ArrowDown className="h-4 w-4" /></a></div>
          {page.hero_image_url && <img src={page.hero_image_url} alt={`Portrait en couleur de ${page.hero_title}`} className="hidden aspect-[4/5] w-full rounded-[2rem] object-cover lg:block" />}
        </div>
      </div>
    </header>
  );
}