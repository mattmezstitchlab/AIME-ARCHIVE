import React from "react";
import EditorialTextGrid from "@/components/home-magazine/EditorialTextGrid";
import EditorialProjectShowcase from "@/components/home-magazine/EditorialProjectShowcase";

export default function FounderEditorialChapter({ chapter, project, index }) {
  return (
    <section id={index === 0 ? "biographie" : `bio-${chapter.number}`} className="scroll-mt-6 overflow-hidden bg-primary text-primary-foreground">
      <article className="mx-auto grid max-w-7xl gap-8 px-5 py-16 sm:px-8 lg:grid-cols-[0.28fr_minmax(0,1fr)] lg:gap-10 lg:px-12 lg:py-24">
        <aside className="lg:sticky lg:top-24 lg:h-fit"><p className="font-display text-7xl font-semibold leading-none tracking-[-0.08em] text-primary-foreground/20">{chapter.number}</p><p className="mt-5 text-xs font-black uppercase tracking-[0.28em] text-primary-foreground/45">{chapter.kicker}</p></aside>
        <div><h2 className="max-w-4xl font-display text-3xl font-semibold leading-[0.95] tracking-[-0.05em] sm:text-4xl lg:text-5xl">{chapter.title}</h2><EditorialTextGrid paragraphs={chapter.paragraphs || []} />{chapter.quote && <blockquote className="mt-9 border-l-2 border-primary-foreground pl-6 font-display text-3xl italic leading-tight tracking-[-0.04em]">« {chapter.quote} »</blockquote>}{chapter.note && <div className="mt-10 rounded-[1.5rem] border border-primary-foreground/15 bg-primary-foreground/5 p-6 text-sm leading-7 text-primary-foreground/65"><span className="mb-3 block text-xs font-black uppercase tracking-[0.24em] text-primary-foreground/45">Note documentaire</span>{chapter.note}</div>}</div>
      </article>
      {project && <EditorialProjectShowcase project={project} related={[]} showRail={false} />}
    </section>
  );
}