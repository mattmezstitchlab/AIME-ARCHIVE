import React from "react";
import { ArrowUpRight } from "lucide-react";

export default function FounderSourcesSpread({ sources = [] }) {
  return (
    <section className="bg-primary px-5 py-20 text-primary-foreground sm:px-8 lg:px-12"><div className="mx-auto max-w-7xl"><p className="text-xs font-black uppercase tracking-[0.28em] text-primary-foreground/45">08 · Sources publiques</p><h2 className="mt-5 font-display text-5xl font-semibold tracking-[-0.06em]">Lire, écouter, vérifier.</h2><div className="mt-10 grid gap-px overflow-hidden bg-primary-foreground/20 md:grid-cols-2 lg:grid-cols-3">{sources.map((source) => <a key={source.url} href={source.url} target="_blank" rel="noreferrer" className="group flex min-h-44 flex-col justify-between bg-black p-6 text-white"><p className="text-[0.6rem] uppercase tracking-[0.22em] text-white/45">{source.detail}</p><div className="flex items-end justify-between gap-5"><h3 className="font-display text-2xl font-semibold tracking-[-0.04em]">{source.label}</h3><ArrowUpRight className="h-5 w-5 transition-transform group-hover:-translate-y-1 group-hover:translate-x-1" /></div></a>)}</div><p className="mt-6 max-w-3xl text-xs leading-6 text-primary-foreground/45">Portrait établi à partir de sources publiques recoupées. Les informations susceptibles d’évoluer ne sont pas présentées comme définitives.</p></div></section>
  );
}