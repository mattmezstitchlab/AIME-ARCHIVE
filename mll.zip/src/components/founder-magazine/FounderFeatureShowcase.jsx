import React from "react";
import { ArrowUpRight } from "lucide-react";

export default function FounderFeatureShowcase({ chapter }) {
  const external = chapter.feature_url?.startsWith("http");
  const linkProps = external ? { target: "_blank", rel: "noreferrer" } : {};
  return (
    <div className="bg-black text-white">
      <div className="grid border-y border-white/15 md:grid-cols-[0.9fr_1.1fr]">
        <a href={chapter.feature_url} {...linkProps} className="group flex min-h-72 flex-col justify-between p-6 sm:min-h-80 sm:p-9 md:min-h-[32rem]"><p className="text-[0.62rem] uppercase tracking-[0.24em] text-white/45">{chapter.feature_label}</p><div><h3 className="font-display text-3xl font-semibold leading-[0.95] tracking-[-0.05em] sm:text-5xl">{chapter.feature_title}</h3><p className="mt-5 max-w-xl text-sm leading-6 text-white/65">{chapter.feature_description}</p><ArrowUpRight className="mt-6 h-5 w-5 transition-transform group-hover:-translate-y-1 group-hover:translate-x-1" /></div></a>
        <a href={chapter.feature_url} {...linkProps} className="group relative min-h-[28rem] overflow-hidden border-t border-white/15 md:min-h-[32rem] md:border-l md:border-t-0">{chapter.feature_image_url && <img src={chapter.feature_image_url} alt={chapter.feature_title} className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />}<div className="absolute inset-0 bg-gradient-to-t from-black/35 to-transparent" /></a>
      </div>
    </div>
  );
}