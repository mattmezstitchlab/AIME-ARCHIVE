import React from "react";
import { ArrowUpRight } from "lucide-react";
import useAutoProjectRail from "@/hooks/useAutoProjectRail";

export default function FounderArchiveRail({ archives = [] }) {
  const { railRef, railProps } = useAutoProjectRail(archives.length);
  if (!archives.length) return null;
  return (
    <div className="overflow-hidden border-x border-b border-white/15 bg-black py-6 text-white">
      <p className="mb-5 px-6 text-[0.62rem] font-black uppercase tracking-[0.24em] text-white/45">Archives associées · Faites glisser</p>
      <div ref={railRef} {...railProps} className="project-rail-scroll flex w-full cursor-grab select-none overflow-x-auto active:cursor-grabbing">
        {archives.map((item, index) => <a key={`${item.external_url}-${index}`} href={item.external_url} target="_blank" rel="noreferrer" className="group relative aspect-[4/3] w-[70vw] max-w-[28rem] shrink-0 overflow-hidden border-r border-white/15 bg-card"><img src={item.image_url} alt={item.title} className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" loading="lazy" /><div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/10 to-transparent" /><div className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-5 p-5"><div><p className="text-[0.58rem] uppercase tracking-[0.22em] text-white/55">{item.category}</p><h3 className="mt-2 font-display text-2xl font-semibold leading-none tracking-[-0.04em]">{item.title}</h3></div><ArrowUpRight className="h-5 w-5" /></div></a>)}
      </div>
    </div>
  );
}