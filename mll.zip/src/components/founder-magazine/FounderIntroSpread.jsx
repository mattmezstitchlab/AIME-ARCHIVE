import React from "react";
import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";

const teamImageUrl = "https://media.base44.com/images/public/6a26f7e77a120b841e3ff78d/81f9ecc7e_ChatGPTImage9juin202603_05_32.png";

export default function FounderIntroSpread({ page = {} }) {
  const title = page.hero_title || "Le fondateur et son orchestre.";
  const intro = page.hero_intro || "Une revue AIME sur la mémoire, la protection, les agents et l’architecture sensible.";
  return (
    <section className="grid md:grid-cols-2">
      <article className="flex min-h-[50svh] flex-col justify-between bg-primary px-5 py-8 text-primary-foreground sm:px-8 sm:py-10 lg:px-12">
        <nav className="flex flex-wrap items-center gap-3" aria-label="Navigation À propos"><Link to="/" className="font-display text-2xl font-semibold tracking-[-0.06em]">AIME®</Link><Link to="/" className="inline-flex min-h-11 items-center gap-2 rounded-full border border-primary-foreground/15 px-4 text-sm"><ArrowLeft className="h-4 w-4" /> Retour</Link></nav>
        <div className="pt-16"><p className="text-[0.56rem] font-black uppercase tracking-[0.22em] text-primary-foreground/45">{page.hero_kicker || "Portrait documenté · 2026"}</p><h1 className="mt-6 max-w-3xl font-display text-5xl font-semibold leading-[0.88] tracking-[-0.06em] sm:text-6xl lg:text-7xl">{title}</h1><p className="mt-6 max-w-xl text-sm leading-6 text-primary-foreground/65">{intro}</p></div>
      </article>
      <figure className="min-h-[50svh] overflow-hidden bg-black"><img src={teamImageUrl} alt="L’équipe AIME réunie autour de son fondateur" className="h-full min-h-[50svh] w-full object-cover object-center" /></figure>
    </section>
  );
}