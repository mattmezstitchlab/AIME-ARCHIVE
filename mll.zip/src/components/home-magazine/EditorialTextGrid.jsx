import React from "react";

function createBlocks(paragraphs) {
  const words = paragraphs.join(" ").trim().split(/\s+/);
  return Array.from({ length: 4 }, (_, index) => {
    const start = Math.floor((index * words.length) / 4);
    const end = Math.floor(((index + 1) * words.length) / 4);
    return words.slice(start, end).join(" ");
  });
}

export default function EditorialTextGrid({ paragraphs }) {
  const blocks = createBlocks(paragraphs);
  return (
    <div className="mt-8 grid w-full min-w-0 grid-cols-2 gap-4 md:grid-cols-4">
      {blocks.map((block, index) => (
        <div key={`${index}-${block.slice(0, 16)}`} className="min-w-0 border-t border-primary-foreground/30 pt-4">
          <span className="text-[0.52rem] font-black uppercase tracking-[0.2em] text-primary-foreground/45">{String(index + 1).padStart(2, "0")}</span>
          <p className="mt-3 break-words text-xs leading-5 text-primary-foreground/70">{block}</p>
        </div>
      ))}
    </div>
  );
}