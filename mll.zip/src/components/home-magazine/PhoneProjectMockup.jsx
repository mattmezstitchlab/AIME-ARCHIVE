import React from "react";

const Device = ({ image, title, light = false, className = "" }) => (
  <div className={`relative aspect-[9/19.5] rounded-[2.8rem] border p-2 shadow-2xl ${light ? "border-primary-foreground/20 bg-primary" : "border-white/25 bg-black"} ${className}`}>
    <div className="absolute left-1/2 top-3 z-20 h-5 w-20 -translate-x-1/2 rounded-full bg-black" aria-hidden="true" />
    <div className="h-full overflow-hidden rounded-[2.35rem] bg-card">{image ? <img src={image} alt={`Écran d’accueil mobile de ${title}`} className="h-full w-full object-cover object-top" loading="lazy" /> : null}</div>
  </div>
);

export default function PhoneProjectMockup({ image, title, style = "black" }) {
  if (style === "duo") return <div className="relative mx-auto flex w-[60%] items-center justify-center pt-8"><Device image={image} title={title} className="w-[52%] -rotate-6" /><Device image={image} title={title} className="-ml-7 mt-10 w-[52%] rotate-6" /></div>;
  return (
    <div className={`relative mx-auto w-[50%] max-w-[13rem] pt-8 md:w-[46%] md:max-w-[14rem] ${style === "floating" ? "-rotate-3" : ""}`}>
      <Device image={image} title={title} light={style === "silver"} />
    </div>
  );
}