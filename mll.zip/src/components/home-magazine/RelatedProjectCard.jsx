import React from "react";
import { Link } from "react-router-dom";
import { ArrowUpRight } from "lucide-react";

export default function RelatedProjectCard({ project }) {
  const image = project.main_screenshot_url || project.gallery?.[0]?.url;
  return (
    <Link to={`/projects/${project.slug}`} className="group grid grid-cols-[5rem_1fr_auto] items-center gap-4 border-t border-white/15 py-4 text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
      <div className="aspect-square overflow-hidden bg-card">
        {image && <img src={image} alt="" className="h-full w-full scale-[1.72] object-cover transition-transform duration-500 group-hover:scale-[1.82]" loading="lazy" />}
      </div>
      <div className="min-w-0">
        <p className="text-[0.62rem] uppercase tracking-[0.22em] text-white/45">{project.category}</p>
        <h3 className="mt-1 line-clamp-2 font-display text-xl font-semibold leading-none tracking-[-0.04em]">{project.title}</h3>
      </div>
      <ArrowUpRight className="h-4 w-4 text-white/55" />
    </Link>
  );
}