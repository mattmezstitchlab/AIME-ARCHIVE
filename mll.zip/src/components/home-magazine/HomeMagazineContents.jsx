import React from "react";
import { magazineChapters } from "@/components/magazine/magazineData";

export default function HomeMagazineContents({ projects }) {
  const items = [
    ...projects.map((project, index) => ({
      number: magazineChapters[index]?.number || String(index + 1).padStart(2, "0"),
      title: magazineChapters[index]?.title || project.title,
      subtitle: `${magazineChapters[index]?.kicker || project.category} · ${project.title}`,
      href: `#magazine-${magazineChapters[index]?.id || project.slug}`,
    })),
    { number: "07", title: "L’Atlas complet", subtitle: "Tous les projets en lien", href: "#atlas-complet" },
  ];

  return (
    <section id="sommaire" className="bg-background px-5 py-20 text-foreground sm:px-8 lg:px-12">
      <div className="mx-auto max-w-7xl">
        <p className="text-xs uppercase tracking-[0.32em] text-white/45">Sommaire · Les dossiers à la une</p>
        <div className="mt-8 grid gap-px bg-white/10 md:grid-cols-2 lg:grid-cols-4">
          {items.map((item) => (
            <a key={`${item.number}-${item.title}`} href={item.href} className="group min-h-48 bg-background p-5 transition-colors hover:bg-card">
              <span className="font-display text-5xl tracking-[-0.08em] text-white/20 group-hover:text-white/50">{item.number}</span>
              <span className="mt-8 block text-[0.62rem] font-bold uppercase tracking-[0.22em] text-white/45">{item.subtitle}</span>
              <h2 className="mt-2 font-display text-2xl font-semibold leading-none tracking-[-0.05em] text-white">{item.title}</h2>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}