import React from "react";
import FeaturedProjectStory from "@/components/home-magazine/FeaturedProjectStory";
import { magazineChapters } from "@/components/magazine/magazineData";
import { CURATED_PROJECT_SLUGS } from "@/components/portfolio/projectCoherence";

const chapterProjects = {
  edito: "aime-marque",
  "appel-citoyen": "notice",
  portrait: "atlas-base44-matt-mez",
  createur: "maison-memoire",
  architecture: "aime-stamp-registry",
  manifeste: "memorix",
};

export default function HomeEditorialFeatures({ projects }) {
  const fallback = projects.filter((project) => project.featured);
  const stories = magazineChapters.map((chapter, index) => ({ chapter, project: projects.find((item) => item.slug === chapterProjects[chapter.id]) || fallback[index] })).filter((item) => item.project);
  if (!stories.length) return null;

  return <>{stories.map(({ chapter, project }, index) => {
    const sameCategory = projects.filter((item) => !CURATED_PROJECT_SLUGS.includes(item.slug) && item.category === project.category);
    return <FeaturedProjectStory key={chapter.id} project={project} chapter={chapter} related={sameCategory.slice(0, 6)} index={index} />;
  })}</>;
}