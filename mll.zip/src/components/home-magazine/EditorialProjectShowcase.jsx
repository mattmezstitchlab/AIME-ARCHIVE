import React from "react";
import { Link } from "react-router-dom";
import { ArrowUpRight } from "lucide-react";
import HorizontalProjectRail from "@/components/home-magazine/HorizontalProjectRail";
import PhoneProjectMockup from "@/components/home-magazine/PhoneProjectMockup";
import HeroReliefAnimation from "@/components/portfolio/HeroReliefAnimation";
import { parseVisualSettings } from "@/components/admin/projectStudio";

export default function EditorialProjectShowcase({ project, related, showRail = true }) {
  const leadImage = project.main_screenshot_url || project.gallery?.[0]?.url;
  const visualSettings = parseVisualSettings(project.reconstruction_note);
  return (
    <div className="relative bg-black text-white">
      <div className="grid border-y border-white/15 md:grid-cols-[0.9fr_1.1fr]">
        <Link to={`/projects/${project.slug}`} className="group flex min-h-72 min-w-0 flex-col justify-between bg-black p-6 sm:min-h-80 sm:p-9 md:min-h-[32rem]">
          <p className="text-[0.62rem] uppercase tracking-[0.24em] text-white/45">Projet associé · {project.category}</p>
          <div><h3 className="break-words font-display text-2xl font-semibold leading-[0.95] tracking-[-0.05em] sm:text-4xl">{project.title}</h3><p className="mt-5 max-w-xl text-sm leading-6 text-white/65">{project.short_description}</p><ArrowUpRight className="mt-6 h-5 w-5 transition-transform group-hover:translate-x-1 group-hover:-translate-y-1" /></div>
        </Link>
        <Link to={`/projects/${project.slug}`} className="group relative z-10 min-h-[30rem] min-w-0 overflow-hidden border-t border-white/15 bg-black pt-14 md:min-h-[32rem] md:border-l md:border-t-0 md:pt-0">
          {visualSettings.background === "relief" && <HeroReliefAnimation className="absolute inset-0 h-full w-full opacity-65" />}
          <div className="relative z-10"><PhoneProjectMockup image={leadImage} title={project.title} style={visualSettings.mockup} /></div>
        </Link>
      </div>
      {showRail && <HorizontalProjectRail project={project} related={related} />}
    </div>
  );
}