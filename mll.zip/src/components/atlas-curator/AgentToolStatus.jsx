import React, { useState } from "react";
import { Check, ChevronDown, LoaderCircle, TriangleAlert } from "lucide-react";

const parse = (value) => {
  if (typeof value !== "string") return value;
  try { return JSON.parse(value); } catch { return value; }
};

export default function AgentToolStatus({ toolCall }) {
  const [open, setOpen] = useState(false);
  const running = ["pending", "running", "in_progress"].includes(toolCall.status);
  const result = parse(toolCall.results);
  const failed = ["failed", "error"].includes(toolCall.status) || result?.success === false || /error|failed/i.test(String(toolCall.results || ""));
  const projection = toolCall.display_projection;
  const hidden = projection?.hide_details && projection?.details_redacted;
  const label = running ? projection?.active_label || "Action en cours" : failed ? projection?.error_label || "Action échouée" : projection?.label || "Action terminée";
  const Icon = running ? LoaderCircle : failed ? TriangleAlert : Check;

  return (
    <div className="mt-3 border border-white/10 bg-black/30 text-xs text-white/70">
      <button type="button" onClick={() => !hidden && setOpen(!open)} className="flex w-full items-center gap-2 px-3 py-2 text-left" aria-expanded={open}>
        <Icon className={`h-3.5 w-3.5 ${running ? "animate-spin" : ""}`} />
        <span className="flex-1">{label}</span>
        {!hidden && <ChevronDown className={`h-3.5 w-3.5 transition ${open ? "rotate-180" : ""}`} />}
      </button>
      {open && !hidden && <pre className="max-h-44 overflow-auto border-t border-white/10 p-3 text-[10px] leading-5">{JSON.stringify({ paramètres: parse(toolCall.arguments_string), résultat: result }, null, 2)}</pre>}
    </div>
  );
}