import React from "react";
import ReactMarkdown from "react-markdown";
import AgentToolStatus from "@/components/atlas-curator/AgentToolStatus";

export default function AgentMessage({ message }) {
  const isUser = message.role === "user";
  return (
    <div className={`flex ${isUser ? "justify-end" : "justify-start"}`}>
      <div className={`max-w-[88%] p-4 text-sm leading-6 ${isUser ? "bg-white text-black" : "border border-white/10 bg-white/[0.04] text-white/85"}`}>
        {message.content && (isUser ? <p className="whitespace-pre-wrap">{message.content}</p> : <ReactMarkdown className="space-y-3">{message.content}</ReactMarkdown>)}
        {message.tool_calls?.map((toolCall, index) => <AgentToolStatus key={`${toolCall.name}-${index}`} toolCall={toolCall} />)}
      </div>
    </div>
  );
}