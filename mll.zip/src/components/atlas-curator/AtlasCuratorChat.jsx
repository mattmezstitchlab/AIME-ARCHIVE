import React, { useEffect, useRef, useState } from "react";
import { ChevronDown, LoaderCircle, MessageCircle, Send } from "lucide-react";
import { base44 } from "@/api/base44Client";
import AgentMessage from "@/components/atlas-curator/AgentMessage";
import AtlasCuratorWelcome from "@/components/atlas-curator/AtlasCuratorWelcome";

export default function AtlasCuratorChat() {
  const [conversation, setConversation] = useState(null);
  const [messages, setMessages] = useState([]);
  const [draft, setDraft] = useState("");
  const [sending, setSending] = useState(false);
  const [open, setOpen] = useState(true);
  const [error, setError] = useState("");
  const endRef = useRef(null);

  useEffect(() => {
    let mounted = true;
    base44.agents.listConversations({ agent_name: "atlas_curator" }).then(async (items) => {
      if (!mounted || !items?.length) return;
      const saved = await base44.agents.getConversation(items[0].id);
      if (mounted) { setConversation(saved); setMessages(saved.messages || []); }
    }).catch(() => {});
    return () => { mounted = false; };
  }, []);
  useEffect(() => {
    if (!conversation?.id) return;
    return base44.agents.subscribeToConversation(conversation.id, (data) => {
      setMessages(data.messages || []);
      window.dispatchEvent(new Event("atlas-projects-updated"));
    });
  }, [conversation?.id]);
  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  const submitMessage = async (content) => {
    if (!content.trim() || sending) return;
    setSending(true); setError("");
    try {
      let active = conversation;
      if (!active) {
        active = await base44.agents.createConversation({ agent_name: "atlas_curator", metadata: { name: "Direction de l’Atlas", description: "Conversation éditoriale et artistique" } });
        setConversation(active);
      }
      setDraft(""); setMessages((current) => [...current, { role: "user", content }]);
      await base44.agents.addMessage(active, { role: "user", content });
    } catch (err) { setError(err.message || "Impossible de contacter ATLAS CURATOR. Connectez-vous puis réessayez."); }
    finally { setSending(false); }
  };

  if (!open) return <button type="button" onClick={() => setOpen(true)} className="fixed bottom-4 right-4 z-30 inline-flex min-h-14 cursor-pointer items-center gap-3 rounded-full bg-white px-5 text-sm font-semibold text-black shadow-2xl focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"><MessageCircle className="h-5 w-5" /> Parler à ATLAS CURATOR</button>;

  return (
    <section aria-label="Conversation avec ATLAS CURATOR" className="fixed inset-x-3 bottom-3 z-30 flex h-[min(34rem,calc(100vh-1.5rem))] flex-col overflow-hidden rounded-[1.5rem] border border-white/20 bg-black/95 text-white shadow-2xl backdrop-blur-2xl sm:left-auto sm:right-5 sm:w-[min(46rem,calc(100vw-2.5rem))]">
      <header className="flex min-h-16 items-center gap-3 border-b border-white/10 px-5"><span className="h-2 w-2 rounded-full bg-emerald-400" aria-hidden="true" /><div className="min-w-0 flex-1"><h2 className="truncate text-sm font-semibold tracking-[0.12em]">ATLAS CURATOR</h2><p className="truncate text-xs text-white/55">Direction éditoriale et artistique · validation humaine</p></div><button type="button" onClick={() => setOpen(false)} className="inline-flex min-h-11 min-w-11 cursor-pointer items-center justify-center rounded-full hover:bg-white/10 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white" aria-label="Réduire la conversation"><ChevronDown className="h-5 w-5" /></button></header>
      <div className="flex-1 space-y-4 overflow-y-auto p-4 sm:p-6">{messages.length ? messages.map((message, index) => <AgentMessage key={index} message={message} />) : <AtlasCuratorWelcome onChoose={submitMessage} disabled={sending} />}<div ref={endRef} /></div>
      {error && <p role="alert" className="border-t border-white/10 px-4 py-3 text-xs text-red-300">{error}</p>}
      <form onSubmit={(event) => { event.preventDefault(); submitMessage(draft.trim()); }} className="flex items-end border-t border-white/10 bg-black"><label className="sr-only" htmlFor="atlas-message">Message à ATLAS CURATOR</label><textarea id="atlas-message" value={draft} onChange={(event) => setDraft(event.target.value)} rows={1} placeholder="Demander une analyse, une réécriture, un visuel…" className="min-h-16 flex-1 resize-none bg-transparent p-5 text-base leading-6 text-white outline-none placeholder:text-white/35" /><button type="submit" disabled={sending || !draft.trim()} className="m-2 inline-flex min-h-12 min-w-12 cursor-pointer items-center justify-center rounded-full bg-white text-black disabled:cursor-not-allowed disabled:opacity-30" aria-label="Envoyer le message">{sending ? <LoaderCircle className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}</button></form>
    </section>
  );
}