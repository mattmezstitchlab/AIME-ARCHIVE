import React from "react";
import { Image, Search, WandSparkles } from "lucide-react";

const missions = [
  { icon: Search, title: "Auditer l’Atlas", text: "Identifier les fiches à retravailler en priorité.", prompt: "Audite l’Atlas et propose les 3 fiches à retravailler en priorité, sans rien modifier." },
  { icon: WandSparkles, title: "Réécrire une fiche", text: "Préparer un avant/après professionnel et fidèle.", prompt: "Aide-moi à choisir une fiche puis prépare une proposition de réécriture complète, sans la modifier." },
  { icon: Image, title: "Repenser un visuel", text: "Créer une direction réaliste avant génération.", prompt: "Choisis un projet dont le visuel doit être amélioré et propose une direction photographique réaliste, sans générer encore." },
];

export default function AtlasCuratorWelcome({ onChoose, disabled }) {
  return (
    <div className="space-y-5">
      <div><p className="text-xs uppercase tracking-[0.24em] text-white/50">Conversation guidée</p><h3 className="mt-2 font-display text-3xl font-semibold tracking-[-0.05em] text-white">Que voulez-vous améliorer ?</h3></div>
      <div className="grid gap-2 sm:grid-cols-3">{missions.map(({ icon: Icon, title, text, prompt }) => <button key={title} type="button" onClick={() => onChoose(prompt)} disabled={disabled} className="min-h-32 cursor-pointer border border-white/15 bg-white/[0.04] p-4 text-left transition-colors duration-200 hover:bg-white/[0.09] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white disabled:opacity-40"><Icon className="h-4 w-4" /><strong className="mt-5 block text-sm text-white">{title}</strong><span className="mt-2 block text-xs leading-5 text-white/60">{text}</span></button>)}</div>
      <p className="text-xs leading-5 text-white/45">L’agent lit les projets et prépare ses propositions. Toute modification ou génération reste soumise à votre confirmation explicite.</p>
    </div>
  );
}