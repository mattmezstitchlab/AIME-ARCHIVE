import React from "react";
import { Plus, Trash2 } from "lucide-react";
import { founderInput, founderLabel } from "@/components/admin/founderAdminStyles";

export default function FounderArchiveEditor({ items, update, add, remove }) {
  return (
    <section className="rounded-[2rem] border border-white/10 bg-card/50 p-6"><div className="mb-6 flex items-center justify-between"><h2 className="font-display text-3xl">Rail d’archives</h2><button type="button" onClick={add} className="inline-flex min-h-11 items-center gap-2 rounded-full border border-white/15 px-4"><Plus className="h-4 w-4" /> Ajouter</button></div><div className="space-y-4">{items.map((item, index) => <div key={index} className="grid gap-3 rounded-2xl border border-white/10 p-4 md:grid-cols-2">{[["title","Titre"],["category","Catégorie"],["image_url","URL image couleur"],["external_url","Lien externe"]].map(([key,label]) => <label key={key}><span className={founderLabel}>{label}</span><input className={founderInput} value={item[key] || ""} onChange={(e) => update(index, { [key]: e.target.value })} /></label>)}<button type="button" onClick={() => remove(index)} className="inline-flex min-h-11 items-center gap-2 text-sm text-destructive"><Trash2 className="h-4 w-4" /> Supprimer</button></div>)}</div></section>
  );
}