export const founderInput = "min-h-11 w-full rounded-2xl border border-white/10 bg-white/[0.04] px-4 text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring";
export const founderTextarea = `${founderInput} min-h-28 py-3`;
export const founderLabel = "mb-2 block text-sm text-muted-foreground";