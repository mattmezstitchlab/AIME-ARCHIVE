import React from "react";
import { dedupeProjects } from "@/components/portfolio/projectCoherence";

export default function AdminOverviewStats({ projects }) {
  const stats = [
    ["Fiches", projects.length],
    ["Projets uniques", dedupeProjects(projects).length],
    ["Visibles", projects.filter((project) => project.visible).length],
    ["À la une", projects.filter((project) => project.featured).length]
  ];
  return (
    <section className="mb-6 grid gap-px overflow-hidden rounded-[2rem] border border-white/10 bg-white/10 sm:grid-cols-2 lg:grid-cols-4">
      {stats.map(([label, value]) => <div key={label} className="bg-black/70 p-6 backdrop-blur-xl"><p className="text-xs uppercase tracking-[0.2em] text-white/40">{label}</p><p className="mt-3 font-display text-4xl font-semibold tracking-[-0.06em] text-white">{value}</p></div>)}
    </section>
  );
}