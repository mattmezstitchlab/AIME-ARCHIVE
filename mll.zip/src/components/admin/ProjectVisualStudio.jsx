import React, { useState } from "react";
import MockupPicker from "@/components/admin/MockupPicker";
import MockupPreview from "@/components/admin/MockupPreview";
import BackgroundPicker from "@/components/admin/BackgroundPicker";
import ProjectVisualActions from "@/components/admin/ProjectVisualActions";
import { buildVisualSettings, parseVisualSettings } from "@/components/admin/projectStudio";

export default function ProjectVisualStudio({ project, onChange, onMessage }) {
  const saved = parseVisualSettings(project.reconstruction_note);
  const [mockup, setMockup] = useState(saved.mockup);
  const [background, setBackground] = useState(saved.background);
  const saveSettings = (nextMockup, nextBackground) => onChange("reconstruction_note", buildVisualSettings(nextMockup, nextBackground));
  const chooseMockup = (value) => { setMockup(value); saveSettings(value, background); };
  const chooseBackground = (value) => { setBackground(value); saveSettings(mockup, value); };
  return (
    <section className="space-y-5 rounded-[2rem] border border-white/10 bg-card/50 p-6">
      <div><p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent">Atelier visuel</p><h2 className="mt-3 font-display text-2xl text-foreground">Écran, mockup & fond</h2></div>
      <MockupPreview image={project.main_screenshot_url} style={mockup} background={background} />
      <MockupPicker value={mockup} onChange={chooseMockup} />
      <BackgroundPicker value={background} onChange={chooseBackground} />
      <ProjectVisualActions project={project} onChange={onChange} onMessage={onMessage} />
      <p className="text-xs leading-5 text-muted-foreground">Le site applique automatiquement le mockup et le fond choisis autour de l’écran pur.</p>
    </section>
  );
}