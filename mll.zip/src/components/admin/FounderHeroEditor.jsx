import React from "react";
import { founderInput, founderLabel, founderTextarea } from "@/components/admin/founderAdminStyles";

export default function FounderHeroEditor({ page, update, upload }) {
  return (
    <section className="rounded-[2rem] border border-white/10 bg-card/50 p-6"><h2 className="mb-6 font-display text-3xl">Ouverture</h2><div className="grid gap-5 md:grid-cols-2"><label><span className={founderLabel}>Sur-titre</span><input className={founderInput} value={page.hero_kicker || ""} onChange={(e) => update("hero_kicker", e.target.value)} /></label><label><span className={founderLabel}>Titre principal</span><input className={founderInput} value={page.hero_title || ""} onChange={(e) => update("hero_title", e.target.value)} /></label><label className="md:col-span-2"><span className={founderLabel}>Introduction</span><textarea className={founderTextarea} value={page.hero_intro || ""} onChange={(e) => update("hero_intro", e.target.value)} /></label><label className="md:col-span-2"><span className={founderLabel}>Portrait couleur — URL ou fichier</span><input className={founderInput} value={page.hero_image_url || ""} onChange={(e) => update("hero_image_url", e.target.value)} /><input type="file" accept="image/*" onChange={(e) => upload(e.target.files?.[0], "hero_image_url")} className="mt-3 text-xs text-muted-foreground" /></label></div></section>
  );
}