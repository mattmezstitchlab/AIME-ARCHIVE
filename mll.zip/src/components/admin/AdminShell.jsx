import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { ADMIN_ACCESS_KEY } from "@/components/portfolio/projectConstants";
import HeroReliefAnimation from "@/components/portfolio/HeroReliefAnimation";

export default function AdminShell({ children, title, action }) {
  const navigate = useNavigate();
  const logout = () => {
    localStorage.removeItem(ADMIN_ACCESS_KEY);
    navigate("/admin");
  };

  return (
    <main className="relative min-h-screen overflow-hidden bg-black px-5 py-6 text-foreground sm:px-8 lg:px-12">
      <HeroReliefAnimation className="fixed inset-0 h-full w-full opacity-30" />
      <div className="fixed inset-0 bg-gradient-to-b from-black/20 via-black/75 to-black" aria-hidden="true" />
      <div className="relative z-10 mx-auto max-w-[90rem]">
        <header className="sticky top-4 z-30 mb-10 flex flex-col justify-between gap-5 rounded-[2rem] border border-white/10 bg-black/70 p-5 shadow-2xl backdrop-blur-2xl sm:flex-row sm:items-center">
          <div>
            <Link to="/" className="text-xs uppercase tracking-[0.28em] text-white/45">AIME · Studio central</Link>
            <h1 className="mt-2 font-display text-3xl font-semibold tracking-[-0.05em] text-white sm:text-4xl">{title}</h1>
          </div>
          <nav className="flex flex-wrap gap-2" aria-label="Navigation administration">
            {action}
            <Link to="/admin/projects" className="inline-flex min-h-11 items-center rounded-full border border-white/10 px-5 text-sm text-white/60 transition-colors hover:bg-white hover:text-black">Projets</Link>
            <Link to="/admin/biographie" className="inline-flex min-h-11 items-center rounded-full border border-white/10 px-5 text-sm text-white/60 transition-colors hover:bg-white hover:text-black">Biographie</Link>
            <Link to="/admin/messages" className="inline-flex min-h-11 items-center rounded-full border border-white/10 px-5 text-sm text-white/60 transition-colors hover:bg-white hover:text-black">Demandes</Link>
            <Link to="/" className="inline-flex min-h-11 items-center rounded-full border border-white/10 px-5 text-sm text-white/60 transition-colors hover:bg-white hover:text-black">Voir le site</Link>
            <button onClick={logout} className="min-h-11 rounded-full border border-white/10 px-5 text-sm text-white/60 transition-colors hover:bg-white hover:text-black">Verrouiller</button>
          </nav>
        </header>
        {children}
      </div>
    </main>
  );
}