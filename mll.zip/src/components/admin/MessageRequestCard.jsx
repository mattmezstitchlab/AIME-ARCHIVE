import React, { useState } from "react";
import { Link } from "react-router-dom";
import { CheckCircle2, FileText, Mail } from "lucide-react";
import DocumentComposer from "@/components/admin/DocumentComposer";
import RequestAudit from "@/components/admin/RequestAudit";
import { documentLabel } from "@/components/admin/commercialDocuments";

const reasons = { projet_similaire: "Projet similaire", evenement: "Événement", collaboration: "Collaboration", information: "Information", autre: "Autre" };

export default function MessageRequestCard({ message, profile, documents, onCreated, onDone }) {
  const [composer, setComposer] = useState(null);
  const linked = documents.filter((item) => item.message_id === message.id);
  const eventDetails = [["Date", [message.event_date, message.event_time].filter(Boolean).join(" · ")], ["Événement", message.event_type], ["Lieu", [message.venue_name, message.venue_address, message.city].filter(Boolean).join(", ")], ["Invités", message.guest_count], ["Budget", message.budget], ["Prestation", message.performance_details]].filter(([, value]) => value);
  const replySubject = encodeURIComponent(`Votre demande ${message.project_title || message.event_type || "AIME"}`);
  return (
    <article className="rounded-[2rem] border border-white/10 bg-card/50 p-6">
      <div className="flex flex-col justify-between gap-6 xl:flex-row xl:items-start">
        <div className="min-w-0 flex-1">
          <div className="mb-3 flex flex-wrap gap-2"><span className="rounded-full border border-white/10 px-3 py-1 text-xs text-white/55">{message.status || "nouveau"}</span><span className="rounded-full border border-white/10 px-3 py-1 text-xs text-white/55">{reasons[message.reason] || "Message"}</span>{message.project_title && <span className="rounded-full border border-white/10 px-3 py-1 text-xs text-white/55">{message.project_title}</span>}</div>
          <h2 className="font-display text-3xl font-semibold tracking-[-0.04em] text-white">{message.name}</h2>
          <div className="mt-2 flex flex-wrap gap-4 text-sm text-white/55"><a href={`mailto:${message.email}?subject=${replySubject}`} className="inline-flex items-center gap-2 hover:text-white"><Mail className="h-4 w-4" /> {message.email}</a>{message.phone && <a href={`tel:${message.phone}`}>{message.phone}</a>}</div>
          {eventDetails.length > 0 && <dl className="mt-5 grid gap-3 sm:grid-cols-2">{eventDetails.map(([label, value]) => <div key={label}><dt className="text-xs uppercase tracking-[0.16em] text-white/40">{label}</dt><dd className="mt-1 text-sm text-white/75">{value}</dd></div>)}</dl>}
          <p className="mt-5 whitespace-pre-wrap text-sm leading-7 text-white/75">{message.message}</p>
          <RequestAudit message={message} />
          {linked.length > 0 && <div className="mt-5 flex flex-wrap gap-2">{linked.map((document) => <Link key={document.id} to={`/admin/documents/${document.id}`} className="inline-flex min-h-10 items-center gap-2 rounded-full border border-white/15 px-4 text-sm text-white/70"><FileText className="h-4 w-4" /> {documentLabel(document.type)} {document.number}</Link>)}</div>}
        </div>
        <div className="flex shrink-0 flex-wrap gap-2">{["devis", "contrat", "facture"].map((type) => <button key={type} onClick={() => setComposer(type)} className="min-h-10 rounded-full border border-white/10 px-4 text-sm text-white/65 hover:bg-white hover:text-black">{documentLabel(type)}</button>)}<button onClick={() => onDone(message)} className="min-h-10 rounded-full border border-white/10 px-4 text-white/60"><CheckCircle2 className="h-4 w-4" /></button></div>
      </div>
      {composer && <DocumentComposer type={composer} message={message} profile={profile} documents={documents} onCreated={(document) => { setComposer(null); onCreated(document); }} onClose={() => setComposer(null)} />}
    </article>
  );
}