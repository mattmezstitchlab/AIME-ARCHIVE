import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";

const fields = [["full_name", "Nom complet"], ["business_name", "Nom commercial"], ["email", "Email"], ["phone", "Téléphone"], ["address", "Adresse"], ["postal_code", "Code postal"], ["city", "Ville"], ["country", "Pays"], ["legal_status", "Statut juridique"], ["siret", "SIRET"], ["vat_number", "N° TVA"], ["iban", "IBAN"], ["bic", "BIC"]];
const inputClass = "min-h-11 w-full rounded-xl border border-white/10 bg-white/[0.04] px-4 text-white placeholder:text-white/35";
const empty = { full_name: "Matthieu Lecointre", business_name: "", email: "matthieu.lecointre@gmail.com", phone: "", address: "", postal_code: "", city: "", country: "France", legal_status: "", siret: "", vat_number: "", iban: "", bic: "", vat_exemption: true, default_terms: "Règlement à 30 jours. Acompte requis pour confirmer la réservation.", default_deposit_percent: 30 };

export default function BusinessProfileForm({ profile, onSaved }) {
  const [form, setForm] = useState(empty);
  const [saving, setSaving] = useState(false);
  useEffect(() => { setForm({ ...empty, ...(profile || {}) }); }, [profile?.id]);
  const update = (key, value) => setForm((current) => ({ ...current, [key]: value }));
  const save = async (event) => {
    event.preventDefault();
    setSaving(true);
    const payload = { ...form, default_deposit_percent: Number(form.default_deposit_percent) || 0 };
    const saved = profile?.id ? await base44.entities.BusinessProfile.update(profile.id, payload) : await base44.entities.BusinessProfile.create(payload);
    setSaving(false);
    onSaved(saved);
  };
  return (
    <details className="mb-6 rounded-[2rem] border border-white/10 bg-card/50 p-6">
      <summary className="cursor-pointer font-display text-2xl text-white">Coordonnées personnelles des documents</summary>
      <form onSubmit={save} className="mt-6 grid gap-4 md:grid-cols-2">
        {fields.map(([key, label]) => <label key={key}><span className="mb-2 block text-xs text-white/55">{label}</span><input className={inputClass} value={form[key] || ""} onChange={(e) => update(key, e.target.value)} required={["full_name", "email", "phone", "address", "postal_code", "city", "legal_status", "siret"].includes(key)} /></label>)}
        <label><span className="mb-2 block text-xs text-white/55">Acompte par défaut (%)</span><input type="number" className={inputClass} value={form.default_deposit_percent} onChange={(e) => update("default_deposit_percent", e.target.value)} /></label>
        <label className="flex items-center gap-3 pt-6"><input type="checkbox" checked={form.vat_exemption} onChange={(e) => update("vat_exemption", e.target.checked)} /> TVA non applicable</label>
        <label className="md:col-span-2"><span className="mb-2 block text-xs text-white/55">Conditions par défaut</span><textarea className={`${inputClass} min-h-24 py-3`} value={form.default_terms} onChange={(e) => update("default_terms", e.target.value)} /></label>
        <button disabled={saving} className="min-h-11 rounded-full bg-white px-5 text-sm font-medium text-black disabled:opacity-60">{saving ? "Enregistrement…" : "Enregistrer les coordonnées"}</button>
      </form>
    </details>
  );
}