import { base44 } from "@/api/base44Client";

export const MOCKUP_STYLES = [
  { id: "black", label: "Mobile noir", detail: "Sobre et éditorial" },
  { id: "silver", label: "Mobile argent", detail: "Clair et premium" },
  { id: "floating", label: "Mobile flottant", detail: "Dynamique et moderne" },
  { id: "duo", label: "Duo mobile", detail: "Deux vues produit" }
];

export const BACKGROUND_STYLES = [
  { id: "relief", label: "Relief animé", detail: "Traits en mouvement" },
  { id: "black", label: "Noir uni", detail: "Fond éditorial sobre" }
];

export const parseVisualSettings = (note = "") => {
  const settings = Object.fromEntries(note.split("|").map((item) => item.split(":")));
  return { mockup: settings.mockup || "black", background: settings.background || "relief" };
};

export const buildVisualSettings = (mockup, background) => `mockup:${mockup}|background:${background}`;

export const buildMobileHomepagePrompt = (project) => `Créer une capture verticale 9:16 très haute fidélité de la page d’accueil mobile du projet « ${project.title || "Projet"} ». Montrer uniquement l’interface du site bord à bord, sans téléphone, sans appareil, sans main, sans bureau et sans mise en scène. Le résultat doit ressembler à une vraie page web mobile moderne, prête à être intégrée dans un mockup. Catégorie : ${project.category || "projet numérique"}. Intention : ${project.short_description || project.long_description || "interface numérique utile et élégante"}. Problème : ${project.problem || ""}. Solution : ${project.solution || ""}. Fonctionnalités : ${(project.features || []).join(", ")}. Composer un hero clair avec le nom du projet, une promesse courte, un appel à l’action, puis 2 ou 3 modules fonctionnels crédibles. Direction premium contemporaine, typographie éditoriale nette, navigation mobile réaliste, hiérarchie très lisible, textes français courts, aucun faux logo de marque tierce.`;

export async function generateProjectCopy(project) {
  return base44.integrations.Core.InvokeLLM({
    prompt: `Rédige en français une fiche de travail complète, précise et non générique pour le projet « ${project.title || "sans titre"} ». Appuie-toi sur les informations déjà présentes et développe une direction produit cohérente sans inventer de faits techniques non confirmés. Catégorie : ${project.category || ""}. Description : ${project.short_description || project.long_description || ""}. Problème : ${project.problem || ""}. Solution : ${project.solution || ""}.`,
    response_json_schema: {
      type: "object",
      properties: {
        title: { type: "string" }, slug_seed: { type: "string" }, short_description: { type: "string" }, long_description: { type: "string" }, problem: { type: "string" }, solution: { type: "string" }, role: { type: "string" }, automation_level: { type: "string" }, accessibility_integrated: { type: "string" }, possible_evolutions: { type: "string" }, before_after: { type: "string" }, human_validation: { type: "string" }, dominant_color: { type: "string" },
        features: { type: "array", items: { type: "string" } }, technologies: { type: "array", items: { type: "string" } }, tags: { type: "array", items: { type: "string" } },
        mechanics: { type: "object", properties: { logic: { type: "string" }, workflows: { type: "string" }, user_roles: { type: "string" }, ai_modules: { type: "string" }, automations: { type: "string" }, next_evolutions: { type: "string" } } }
      },
      required: ["short_description", "long_description", "problem", "solution", "role", "features", "technologies", "tags", "mechanics"]
    }
  });
}