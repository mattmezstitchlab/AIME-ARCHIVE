import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { buildCommercialDocument, documentLabel } from "@/components/admin/commercialDocuments";

const inputClass = "min-h-11 w-full rounded-xl border border-white/10 bg-black/30 px-4 text-white";

export default function DocumentComposer({ type, message, profile, documents, onCreated, onClose }) {
  const parsedBudget = Number(String(message.budget || "").replace(/[^0-9,.]/g, "").replace(",", ".")) || "";
  const [amount, setAmount] = useState(parsedBudget);
  const [description, setDescription] = useState(message.reason === "evenement" ? `Prestation musicale — ${message.event_type || "événement"}${message.event_date ? ` du ${message.event_date}` : ""}` : `Accompagnement — ${message.project_title || "projet"}`);
  const [notes, setNotes] = useState(message.performance_details || message.message || "");
  const [saving, setSaving] = useState(false);
  const profileReady = profile && ["full_name", "email", "phone", "address", "postal_code", "city", "legal_status", "siret"].every((key) => profile[key]);
  const submit = async (event) => {
    event.preventDefault();
    setSaving(true);
    const existingCount = documents.filter((item) => item.type === type).length;
    const payload = buildCommercialDocument({ type, message, profile, amount, description, notes, existingCount });
    const created = await base44.entities.CommercialDocument.create(payload);
    if (type === "devis") await base44.entities.ContactMessage.update(message.id, { status: "devis_préparé" });
    setSaving(false);
    onCreated(created);
  };
  if (!profileReady) return <div className="mt-5 rounded-2xl border border-white/15 p-4 text-sm text-white/65">Complétez d’abord les coordonnées personnelles en haut de la page pour finaliser un document.</div>;
  return (
    <form onSubmit={submit} className="mt-5 grid gap-3 rounded-2xl border border-white/15 bg-black/30 p-4">
      <p className="text-sm font-medium text-white">Finaliser : {documentLabel(type)}</p>
      <input className={inputClass} value={description} onChange={(e) => setDescription(e.target.value)} required />
      <input type="number" min="0" step="0.01" className={inputClass} value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="Montant HT en euros" required />
      <textarea className={`${inputClass} min-h-24 py-3`} value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Notes et détails" />
      <div className="flex gap-2"><button disabled={saving} className="min-h-10 rounded-full bg-white px-4 text-sm text-black disabled:opacity-60">{saving ? "Création…" : `Finaliser le ${documentLabel(type).toLowerCase()}`}</button><button type="button" onClick={onClose} className="min-h-10 rounded-full border border-white/10 px-4 text-sm text-white/60">Annuler</button></div>
    </form>
  );
}