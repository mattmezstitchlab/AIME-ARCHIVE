import React from "react";
import { Plus, Trash2 } from "lucide-react";
import { founderInput, founderLabel } from "@/components/admin/founderAdminStyles";

export default function FounderSourceEditor({ items, update, add, remove, playlistId, updatePlaylist }) {
  return (
    <section className="rounded-[2rem] border border-white/10 bg-card/50 p-6"><div className="mb-6 flex items-center justify-between"><h2 className="font-display text-3xl">Sources & vidéos</h2><button type="button" onClick={add} className="inline-flex min-h-11 items-center gap-2 rounded-full border border-white/15 px-4"><Plus className="h-4 w-4" /> Source</button></div><label className="mb-6 block"><span className={founderLabel}>Identifiant de la playlist YouTube officielle</span><input className={founderInput} value={playlistId || ""} onChange={(e) => updatePlaylist(e.target.value)} /></label><div className="space-y-4">{items.map((item, index) => <div key={index} className="grid gap-3 rounded-2xl border border-white/10 p-4 md:grid-cols-3">{[["label","Nom"],["detail","Détail"],["url","URL"]].map(([key,label]) => <label key={key}><span className={founderLabel}>{label}</span><input className={founderInput} value={item[key] || ""} onChange={(e) => update(index, { [key]: e.target.value })} /></label>)}<button type="button" onClick={() => remove(index)} className="inline-flex min-h-11 items-center gap-2 text-sm text-destructive"><Trash2 className="h-4 w-4" /> Supprimer</button></div>)}</div></section>
  );
}