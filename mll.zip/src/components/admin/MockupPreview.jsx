import React from "react";
import HeroReliefAnimation from "@/components/portfolio/HeroReliefAnimation";

const Screen = ({ image, className = "" }) => (
  <div className={`relative z-10 aspect-[9/19.5] overflow-hidden rounded-[2.4rem] border bg-black p-2 shadow-2xl ${className}`}>
    <span className="absolute left-1/2 top-3 z-10 h-4 w-16 -translate-x-1/2 rounded-full bg-black" />
    <div className="h-full overflow-hidden rounded-[2rem] bg-card">{image && <img src={image} alt="Aperçu mobile du projet" className="h-full w-full object-cover object-top" />}</div>
  </div>
);

const Backdrop = ({ background, children }) => <div className="relative flex min-h-[28rem] items-center justify-center overflow-hidden rounded-[2rem] bg-black p-8">{background === "relief" && <HeroReliefAnimation className="absolute inset-0 h-full w-full opacity-65" />}{children}</div>;

export default function MockupPreview({ image, style, background }) {
  if (style === "duo") return <Backdrop background={background}><Screen image={image} className="w-44 -rotate-6 border-white/25" /><Screen image={image} className="-ml-8 mt-14 w-44 rotate-6 border-white/25" /></Backdrop>;
  if (style === "floating") return <Backdrop background={background}><Screen image={image} className="w-52 -rotate-3 border-white/25 shadow-white/10" /></Backdrop>;
  if (style === "silver") return <Backdrop background={background}><Screen image={image} className="w-52 border-white/50 bg-white" /></Backdrop>;
  return <Backdrop background={background}><Screen image={image} className="w-52 border-white/25" /></Backdrop>;
}