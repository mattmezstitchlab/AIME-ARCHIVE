import React, { useState } from "react";
import { Loader2, Sparkles } from "lucide-react";
import { generateProjectCopy } from "@/components/admin/projectStudio";

export default function ProjectAIStudio({ project, onGenerated, onMessage }) {
  const [generating, setGenerating] = useState(false);

  const generate = async () => {
    if (!project.title && !project.short_description) return onMessage("Ajoutez un titre ou une description avant la génération.");
    setGenerating(true);
    onMessage("Génération de la base éditoriale…");
    try {
      const result = await generateProjectCopy(project);
      onGenerated(result);
    } catch (error) {
      onMessage(`La génération a échoué : ${error.message}`);
    } finally {
      setGenerating(false);
    }
  };

  return (
    <section className="rounded-[2rem] border border-white/10 bg-card/50 p-6">
      <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent">Studio IA</p>
      <h2 className="mt-3 font-display text-2xl text-foreground">Base éditoriale complète</h2>
      <p className="my-5 text-sm leading-6 text-muted-foreground">L’IA prépare tous les textes à partir des informations déjà connues. Rien n’est publié avant votre validation et l’enregistrement.</p>
      <button type="button" onClick={generate} disabled={generating} className="inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-full bg-accent px-5 text-sm font-medium text-accent-foreground disabled:opacity-60">
        {generating ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
        {generating ? "Génération…" : "Générer ou réécrire les textes"}
      </button>
    </section>
  );
}