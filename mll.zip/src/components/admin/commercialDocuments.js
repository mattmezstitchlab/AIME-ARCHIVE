const prefixes = { devis: "DEV", contrat: "CTR", facture: "FAC" };
const titles = { devis: "Devis de prestation", contrat: "Contrat de prestation", facture: "Facture de prestation" };

export const documentLabel = (type) => ({ devis: "Devis", contrat: "Contrat", facture: "Facture" }[type] || type);

export function buildCommercialDocument({ type, message, profile, amount, description, notes, existingCount }) {
  const issueDate = new Date();
  const dueDate = new Date(issueDate);
  dueDate.setDate(dueDate.getDate() + 30);
  const subtotal = Number(amount);
  const vatRate = profile.vat_exemption ? 0 : 20;
  const tax = subtotal * vatRate / 100;
  const sequence = String(existingCount + 1).padStart(4, "0");
  return {
    message_id: message.id,
    type,
    number: `${prefixes[type]}-${issueDate.getFullYear()}-${sequence}`,
    status: "finalisé",
    title: message.reason === "evenement" ? `${titles[type]} musicale` : titles[type],
    issue_date: issueDate.toISOString().slice(0, 10),
    due_date: dueDate.toISOString().slice(0, 10),
    event_date: message.event_date || undefined,
    recipient: { name: message.name, email: message.email, phone: message.phone || "", address: [message.venue_address, message.city].filter(Boolean).join(", ") },
    issuer: { ...profile },
    lines: [{ description, quantity: 1, unit_price: subtotal, vat_rate: vatRate }],
    subtotal,
    tax,
    total: subtotal + tax,
    deposit_percent: Number(profile.default_deposit_percent) || 0,
    notes,
    terms: profile.default_terms || "Règlement à 30 jours. Toute modification de la prestation fait l’objet d’un accord écrit."
  };
}