import React, { useState } from "react";
import { Copy, Loader2, Sparkles, Upload } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { buildMobileHomepagePrompt } from "@/components/admin/projectStudio";

export default function ProjectVisualActions({ project, onChange, onMessage }) {
  const [generating, setGenerating] = useState(false);
  const prompt = buildMobileHomepagePrompt(project);

  const generate = async () => {
    if (!project.title && !project.short_description) return onMessage("Ajoutez un titre ou une description avant de générer l’écran.");
    setGenerating(true); onMessage("Génération de la page d’accueil mobile…");
    try { const result = await base44.integrations.Core.GenerateImage({ prompt }); onChange("main_screenshot_url", result.url); onMessage("Écran généré. Choisissez son mockup puis enregistrez le projet."); }
    catch (error) { onMessage(`La génération a échoué : ${error.message}`); }
    finally { setGenerating(false); }
  };

  const upload = async (file) => {
    if (!file) return;
    onMessage("Import du visuel…");
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    onChange("main_screenshot_url", file_url); onMessage("Visuel importé.");
  };

  return (
    <div className="space-y-3">
      <button type="button" onClick={generate} disabled={generating} className="inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-full bg-accent px-5 text-sm font-medium text-accent-foreground disabled:opacity-60">{generating ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}{generating ? "Génération…" : "Générer l’accueil mobile"}</button>
      <button type="button" onClick={() => navigator.clipboard.writeText(prompt).then(() => onMessage("Prompt copié pour votre outil externe."))} className="inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-full border border-white/10 text-sm text-muted-foreground"><Copy className="h-4 w-4" /> Copier le prompt</button>
      <label className="flex min-h-11 cursor-pointer items-center justify-center gap-2 rounded-full border border-white/10 text-sm text-muted-foreground"><Upload className="h-4 w-4" /> Importer un visuel<input type="file" accept="image/*" className="sr-only" onChange={(event) => upload(event.target.files?.[0])} /></label>
      <input aria-label="URL du visuel principal" value={project.main_screenshot_url || ""} onChange={(event) => onChange("main_screenshot_url", event.target.value)} placeholder="Ou coller une URL d’image" className="min-h-11 w-full rounded-2xl border border-white/10 bg-white/[0.04] px-4 text-sm text-foreground placeholder:text-muted-foreground" />
    </div>
  );
}