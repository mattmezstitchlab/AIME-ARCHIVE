import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { createSlug, PROJECT_CATEGORIES, PROJECT_STATUSES } from "@/components/portfolio/projectConstants";
import { Loader2, Plus, Trash2, Wand2 } from "lucide-react";
import ProjectAIStudio from "@/components/admin/ProjectAIStudio";
import ProjectVisualStudio from "@/components/admin/ProjectVisualStudio";

const emptyMechanics = { logic: "", workflows: "", user_roles: "", ai_modules: "", automations: "", next_evolutions: "" };
const PROJECT_TYPES = ["personnel", "client", "expérimental", "concept", "Registre / Mémoire / Protection"];
const MATURITY_LEVELS = ["idée", "prototype", "MVP", "en ligne", "gelé"];
const ACCESSIBILITY_STATUSES = ["non prévue", "prévue", "intégrée", "auditée"];
const YES_NO_PLANNED = ["oui", "non", "prévu"];
const inputClass = "min-h-11 w-full rounded-2xl border border-white/10 bg-white/[0.04] px-4 text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring";
const textareaClass = `${inputClass} min-h-32 py-3`;
const labelClass = "mb-2 block text-sm text-muted-foreground";

const toList = (value) => value.split(",").map((item) => item.trim()).filter(Boolean);
const fromList = (value) => (value || []).join(", ");

export default function ProjectEditor({ initialProject, onSave }) {
  const [saving, setSaving] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [message, setMessage] = useState("");
  const [project, setProject] = useState({
    title: "",
    slug: "",
    url: "",
    demo_url: "",
    admin_private_url: "",
    short_description: "",
    long_description: "",
    problem: "",
    solution: "",
    features: [],
    technologies: [],
    category: "Expérimental",
    status: "Prototype",
    project_type: "concept",
    maturity_level: "prototype",
    accessibility_status: "prévue",
    accessibility_widget: "prévu",
    payment_integrated: "non",
    e_invoice_status: "prévu",
    automation_level: "",
    accessibility_integrated: "",
    possible_evolutions: "",
    before_after: "",
    prompt_source: "",
    human_validation: "",
    last_updated_at: new Date().toISOString().slice(0, 10),
    register_title: "",
    register_manifesto: "",
    register_charter: "",
    emergency_text: "",
    partners_text: "",
    register_visibility: "privé",
    register_status: "brouillon",
    allow_stamp_creation: "non",
    year: new Date().getFullYear(),
    tags: [],
    main_screenshot_url: "",
    gallery: [],
    mechanics: emptyMechanics,
    dominant_color: "",
    featured: false,
    visible: true,
    display_order: 0,
    ...initialProject,
    mechanics: { ...emptyMechanics, ...(initialProject?.mechanics || {}) }
  });
  const [featuresInput, setFeaturesInput] = useState(fromList(initialProject?.features));
  const [technologiesInput, setTechnologiesInput] = useState(fromList(initialProject?.technologies));
  const [tagsInput, setTagsInput] = useState(fromList(initialProject?.tags));

  const update = (field, value) => setProject((prev) => ({ ...prev, [field]: value }));
  const updateMechanics = (field, value) => setProject((prev) => ({ ...prev, mechanics: { ...prev.mechanics, [field]: value } }));

  const uploadMain = async (file) => {
    if (!file) return;
    setMessage("Upload du visuel en cours…");
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    update("main_screenshot_url", file_url);
    setMessage("Visuel principal ajouté.");
  };

  const analyzeUrl = async () => {
    if (!project.url) {
      setMessage("Ajoutez une URL avant l'analyse.");
      return;
    }
    setAnalyzing(true);
    const response = await base44.functions.invoke("generateProjectScreenshot", { url: project.url });
    const data = response.data || {};
    setProject((prev) => ({
      ...prev,
      title: prev.title || data.title || "",
      slug: prev.slug || createSlug(data.title || prev.title || "projet"),
      short_description: prev.short_description || data.short_description || "",
      tags: prev.tags?.length ? prev.tags : data.tags || [],
      dominant_color: prev.dominant_color || data.dominant_color || "",
      main_screenshot_url: prev.main_screenshot_url || data.main_screenshot_url || ""
    }));
    if (!tagsInput && data.tags?.length) setTagsInput(fromList(data.tags));
    setMessage(data.api_configured ? "Analyse terminée." : "Analyse texte terminée. Capture automatique : connexion API à configurer.");
    setAnalyzing(false);
  };

  const applyGeneratedTexts = (generated) => {
    const { slug_seed: slugSeed, title: generatedTitle, ...generatedFields } = generated;
    const nextTitle = project.title || generatedTitle || "";
    setProject((prev) => ({ ...prev, ...generatedFields, title: nextTitle, slug: prev.slug || createSlug(slugSeed || nextTitle), mechanics: { ...prev.mechanics, ...(generated.mechanics || {}) } }));
    setFeaturesInput(fromList(generated.features));
    setTechnologiesInput(fromList(generated.technologies));
    setTagsInput(fromList(generated.tags));
    setMessage("Base éditoriale générée. Relisez et ajustez chaque champ avant d’enregistrer.");
  };

  const addGalleryItem = () => update("gallery", [...(project.gallery || []), { url: "", description: "" }]);
  const updateGalleryItem = (index, field, value) => {
    const next = [...(project.gallery || [])];
    next[index] = { ...next[index], [field]: value };
    update("gallery", next);
  };
  const removeGalleryItem = (index) => update("gallery", (project.gallery || []).filter((_, itemIndex) => itemIndex !== index));

  const submit = async (event) => {
    event.preventDefault();
    setSaving(true);
    const now = new Date().toISOString();
    await onSave({
      ...project,
      features: toList(featuresInput),
      technologies: toList(technologiesInput),
      tags: toList(tagsInput),
      slug: project.slug || createSlug(project.title),
      year: Number(project.year) || new Date().getFullYear(),
      display_order: Number(project.display_order) || 0,
      updated_at: now,
      created_at: project.created_at || now
    });
    setSaving(false);
  };

  return (
    <form onSubmit={submit} className="grid gap-6 lg:grid-cols-[1fr_0.8fr]">
      <div className="space-y-6">
        <section className="rounded-[2rem] border border-white/10 bg-card/50 p-6">
          <div className="grid gap-5 md:grid-cols-2">
            <label><span className={labelClass}>Titre</span><input className={inputClass} value={project.title} onChange={(e) => update("title", e.target.value)} onBlur={() => !project.slug && update("slug", createSlug(project.title))} required /></label>
            <label><span className={labelClass}>Slug</span><input className={inputClass} value={project.slug} onChange={(e) => update("slug", createSlug(e.target.value))} required /></label>
            <label className="md:col-span-2"><span className={labelClass}>URL publique</span><div className="flex gap-3"><input className={inputClass} value={project.url} onChange={(e) => update("url", e.target.value)} placeholder="https://…" /><button type="button" onClick={analyzeUrl} disabled={analyzing} className="min-h-11 rounded-2xl bg-accent px-5 text-sm font-medium text-accent-foreground disabled:opacity-60" aria-label="Analyser l'URL">{analyzing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Wand2 className="h-4 w-4" />}</button></div></label>
            <label><span className={labelClass}>URL démo</span><input className={inputClass} value={project.demo_url || ""} onChange={(e) => update("demo_url", e.target.value)} placeholder="https://…" /></label>
            <label><span className={labelClass}>URL admin privée</span><input className={inputClass} value={project.admin_private_url || ""} onChange={(e) => update("admin_private_url", e.target.value)} placeholder="https://…" /></label>
            <label className="md:col-span-2"><span className={labelClass}>Description courte</span><textarea className={textareaClass} value={project.short_description} onChange={(e) => update("short_description", e.target.value)} /></label>
            <label className="md:col-span-2"><span className={labelClass}>Description longue</span><textarea className={textareaClass} value={project.long_description} onChange={(e) => update("long_description", e.target.value)} /></label>
          </div>
        </section>

        <section className="rounded-[2rem] border border-white/10 bg-card/50 p-6">
          <h2 className="mb-5 font-display text-2xl text-foreground">Intention et système</h2>
          <div className="grid gap-5 md:grid-cols-2">
            <label><span className={labelClass}>Problème résolu</span><textarea className={textareaClass} value={project.problem} onChange={(e) => update("problem", e.target.value)} /></label>
            <label><span className={labelClass}>Solution proposée</span><textarea className={textareaClass} value={project.solution} onChange={(e) => update("solution", e.target.value)} /></label>
            <label><span className={labelClass}>Niveau d’automatisation</span><textarea className={textareaClass} value={project.automation_level || ""} onChange={(e) => update("automation_level", e.target.value)} /></label>
            <label><span className={labelClass}>Accessibilité intégrée</span><textarea className={textareaClass} value={project.accessibility_integrated || ""} onChange={(e) => update("accessibility_integrated", e.target.value)} /></label>
            <label className="md:col-span-2"><span className={labelClass}>Évolutions possibles</span><textarea className={textareaClass} value={project.possible_evolutions || ""} onChange={(e) => update("possible_evolutions", e.target.value)} /></label>
          </div>
        </section>

        <section className="rounded-[2rem] border border-white/10 bg-card/50 p-6">
          <h2 className="mb-5 font-display text-2xl text-foreground">Voir la mécanique invisible</h2>
          <div className="grid gap-5 md:grid-cols-2">
            {[["logic", "Logique du projet"], ["workflows", "Workflows"], ["user_roles", "Rôles utilisateurs"], ["ai_modules", "Modules IA"], ["automations", "Automatisations"], ["next_evolutions", "Prochaines évolutions"]].map(([key, label]) => (
              <label key={key}><span className={labelClass}>{label}</span><textarea className={textareaClass} value={project.mechanics?.[key] || ""} onChange={(e) => updateMechanics(key, e.target.value)} /></label>
            ))}
          </div>
        </section>
      </div>

      <aside className="space-y-6">
        <ProjectAIStudio project={project} onGenerated={applyGeneratedTexts} onMessage={setMessage} />

        <section className="rounded-[2rem] border border-white/10 bg-card/50 p-6">
          <h2 className="mb-5 font-display text-2xl text-foreground">Publication</h2>
          <div className="grid gap-5">
            <label><span className={labelClass}>Catégorie</span><select className={inputClass} value={project.category} onChange={(e) => update("category", e.target.value)}>{PROJECT_CATEGORIES.filter((category) => category !== "Tous").map((category) => <option key={category} value={category}>{category}</option>)}</select></label>
            <label><span className={labelClass}>Statut</span><select className={inputClass} value={project.status} onChange={(e) => update("status", e.target.value)}>{PROJECT_STATUSES.map((status) => <option key={status} value={status}>{status}</option>)}</select></label>
            <label><span className={labelClass}>Type de projet</span><select className={inputClass} value={project.project_type || "concept"} onChange={(e) => update("project_type", e.target.value)}>{PROJECT_TYPES.map((type) => <option key={type} value={type}>{type}</option>)}</select></label>
            <label><span className={labelClass}>Niveau de maturité</span><select className={inputClass} value={project.maturity_level || "prototype"} onChange={(e) => update("maturity_level", e.target.value)}>{MATURITY_LEVELS.map((level) => <option key={level} value={level}>{level}</option>)}</select></label>
            <label><span className={labelClass}>Accessibilité</span><select className={inputClass} value={project.accessibility_status || "prévue"} onChange={(e) => update("accessibility_status", e.target.value)}>{ACCESSIBILITY_STATUSES.map((status) => <option key={status} value={status}>{status}</option>)}</select></label>
            <label><span className={labelClass}>Widget accessibilité</span><select className={inputClass} value={project.accessibility_widget || "prévu"} onChange={(e) => update("accessibility_widget", e.target.value)}>{YES_NO_PLANNED.map((value) => <option key={value} value={value}>{value}</option>)}</select></label>
            <label><span className={labelClass}>Paiement intégré</span><select className={inputClass} value={project.payment_integrated || "non"} onChange={(e) => update("payment_integrated", e.target.value)}>{YES_NO_PLANNED.map((value) => <option key={value} value={value}>{value}</option>)}</select></label>
            <label><span className={labelClass}>Facture électronique / Pennylane</span><select className={inputClass} value={project.e_invoice_status || "prévu"} onChange={(e) => update("e_invoice_status", e.target.value)}>{YES_NO_PLANNED.map((value) => <option key={value} value={value}>{value}</option>)}</select></label>
            <label><span className={labelClass}>Année</span><input type="number" className={inputClass} value={project.year} onChange={(e) => update("year", e.target.value)} /></label>
            <label><span className={labelClass}>Ordre d'affichage</span><input type="number" className={inputClass} value={project.display_order} onChange={(e) => update("display_order", e.target.value)} /></label>
            <label className="flex min-h-11 items-center gap-3"><input type="checkbox" checked={!!project.visible} onChange={(e) => update("visible", e.target.checked)} /> Visible publiquement</label>
            <label className="flex min-h-11 items-center gap-3"><input type="checkbox" checked={!!project.featured} onChange={(e) => update("featured", e.target.checked)} /> Mettre en avant</label>
          </div>
        </section>

        <ProjectVisualStudio project={project} onChange={update} onMessage={setMessage} />

        <section className="rounded-[2rem] border border-white/10 bg-card/50 p-6">
          <h2 className="mb-5 font-display text-2xl text-foreground">Listes</h2>
          <label><span className={labelClass}>Fonctionnalités — séparées par virgules</span><textarea className={textareaClass} value={featuresInput} onChange={(e) => setFeaturesInput(e.target.value)} /></label>
          <label className="mt-4 block"><span className={labelClass}>Technologies — séparées par virgules</span><textarea className={textareaClass} value={technologiesInput} onChange={(e) => setTechnologiesInput(e.target.value)} /></label>
          <label className="mt-4 block"><span className={labelClass}>Tags — séparés par virgules</span><input className={inputClass} value={tagsInput} onChange={(e) => setTagsInput(e.target.value)} /></label>
        </section>

        <section className="rounded-[2rem] border border-white/10 bg-card/50 p-6">
          <h2 className="mb-5 font-display text-2xl text-foreground">Registre / Mémoire / Protection</h2>
          <label><span className={labelClass}>Titre du registre</span><input className={inputClass} value={project.register_title || ""} onChange={(e) => update("register_title", e.target.value)} /></label>
          <label className="mt-4 block"><span className={labelClass}>Manifeste</span><textarea className={textareaClass} value={project.register_manifesto || ""} onChange={(e) => update("register_manifesto", e.target.value)} /></label>
          <label className="mt-4 block"><span className={labelClass}>Charte</span><textarea className={textareaClass} value={project.register_charter || ""} onChange={(e) => update("register_charter", e.target.value)} /></label>
          <label className="mt-4 block"><span className={labelClass}>Texte d’urgence</span><textarea className={textareaClass} value={project.emergency_text || ""} onChange={(e) => update("emergency_text", e.target.value)} /></label>
          <label className="mt-4 block"><span className={labelClass}>Partenaires</span><textarea className={textareaClass} value={project.partners_text || ""} onChange={(e) => update("partners_text", e.target.value)} /></label>
          <label className="mt-4 block"><span className={labelClass}>Visibilité</span><select className={inputClass} value={project.register_visibility || "privé"} onChange={(e) => update("register_visibility", e.target.value)}>{["privé", "semi-public", "public", "partenaire"].map((value) => <option key={value} value={value}>{value}</option>)}</select></label>
          <label className="mt-4 block"><span className={labelClass}>Statut du registre</span><select className={inputClass} value={project.register_status || "brouillon"} onChange={(e) => update("register_status", e.target.value)}>{["brouillon", "ouvert", "en pause"].map((value) => <option key={value} value={value}>{value}</option>)}</select></label>
          <label className="mt-4 block"><span className={labelClass}>Autoriser création de timbre</span><select className={inputClass} value={project.allow_stamp_creation || "non"} onChange={(e) => update("allow_stamp_creation", e.target.value)}>{["oui", "non"].map((value) => <option key={value} value={value}>{value}</option>)}</select></label>
        </section>

        <section className="rounded-[2rem] border border-white/10 bg-card/50 p-6">
          <h2 className="mb-5 font-display text-2xl text-foreground">Mémoire projet</h2>
          <label><span className={labelClass}>Avant / après</span><textarea className={textareaClass} value={project.before_after || ""} onChange={(e) => update("before_after", e.target.value)} /></label>
          <label className="mt-4 block"><span className={labelClass}>Prompt source</span><textarea className={textareaClass} value={project.prompt_source || ""} onChange={(e) => update("prompt_source", e.target.value)} /></label>
          <label className="mt-4 block"><span className={labelClass}>Décision humaine / validation</span><textarea className={textareaClass} value={project.human_validation || ""} onChange={(e) => update("human_validation", e.target.value)} /></label>
          <label className="mt-4 block"><span className={labelClass}>Date de dernière mise à jour</span><input type="date" className={inputClass} value={project.last_updated_at || ""} onChange={(e) => update("last_updated_at", e.target.value)} /></label>
        </section>

        <section className="rounded-[2rem] border border-white/10 bg-card/50 p-6">
          <div className="mb-5 flex items-center justify-between gap-4"><h2 className="font-display text-2xl text-foreground">Galerie de pages de site</h2><button type="button" onClick={addGalleryItem} className="min-h-11 rounded-full border border-white/10 px-4 text-sm" aria-label="Ajouter une image"><Plus className="h-4 w-4" /></button></div>
          <div className="space-y-4">
            {(project.gallery || []).map((item, index) => (
              <div key={index} className="rounded-2xl border border-white/10 p-4">
                <input className={inputClass} placeholder="URL image" value={item.url} onChange={(e) => updateGalleryItem(index, "url", e.target.value)} />
                <textarea className={`${textareaClass} mt-3`} placeholder="Description" value={item.description} onChange={(e) => updateGalleryItem(index, "description", e.target.value)} />
                <button type="button" onClick={() => removeGalleryItem(index)} className="mt-3 inline-flex min-h-11 items-center gap-2 rounded-full border border-destructive/30 px-4 text-sm text-destructive"><Trash2 className="h-4 w-4" /> Supprimer</button>
              </div>
            ))}
          </div>
        </section>

        {message && <p className="rounded-2xl border border-white/10 bg-white/[0.04] p-4 text-sm text-muted-foreground">{message}</p>}
        <button disabled={saving} type="submit" className="min-h-12 w-full rounded-full bg-primary px-6 font-medium text-primary-foreground transition-colors duration-200 hover:bg-accent hover:text-accent-foreground disabled:opacity-60">
          {saving ? "Enregistrement…" : "Enregistrer le projet"}
        </button>
      </aside>
    </form>
  );
}