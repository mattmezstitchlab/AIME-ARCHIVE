import React from "react";
import { MOCKUP_STYLES } from "@/components/admin/projectStudio";

export default function MockupPicker({ value, onChange }) {
  return (
    <div>
      <p className="mb-3 text-sm text-muted-foreground">Choisir le mockup de présentation</p>
      <div className="grid grid-cols-2 gap-2">
        {MOCKUP_STYLES.map((item) => (
          <button key={item.id} type="button" onClick={() => onChange(item.id)} className={`min-h-16 rounded-2xl border p-3 text-left transition-colors ${value === item.id ? "border-primary bg-primary text-primary-foreground" : "border-white/10 bg-white/[0.04] text-foreground"}`}>
            <span className="block text-sm font-semibold">{item.label}</span>
            <span className={`mt-1 block text-xs ${value === item.id ? "text-primary-foreground/60" : "text-muted-foreground"}`}>{item.detail}</span>
          </button>
        ))}
      </div>
    </div>
  );
}