import React from "react";

export default function RequestAudit({ message }) {
  const checks = message.reason === "evenement"
    ? [["Téléphone", message.phone], ["Date", message.event_date], ["Type", message.event_type], ["Lieu", message.venue_address && message.city], ["Prestation", message.performance_details || message.message], ["Budget", message.budget]]
    : [["Téléphone", message.phone], ["Besoin", message.message], ["Référence", message.project_title || message.reason !== "projet_similaire"]];
  const complete = checks.filter(([, value]) => value).length;
  const missing = checks.filter(([, value]) => !value).map(([label]) => label);
  return (
    <div className="mt-5 rounded-2xl border border-white/10 bg-white/[0.03] p-4">
      <div className="flex items-center justify-between text-xs uppercase tracking-[0.18em] text-white/50"><span>Audit de la demande</span><span>{complete}/{checks.length}</span></div>
      <div className="mt-3 h-1 overflow-hidden rounded-full bg-white/10"><div className="h-full bg-white" style={{ width: `${(complete / checks.length) * 100}%` }} /></div>
      <p className="mt-3 text-xs text-white/55">{missing.length ? `À demander : ${missing.join(", ")}.` : "Dossier suffisamment précis pour préparer une proposition."}</p>
    </div>
  );
}