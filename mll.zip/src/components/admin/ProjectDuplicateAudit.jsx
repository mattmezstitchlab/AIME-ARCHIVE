import React, { useMemo } from "react";
import { Link } from "react-router-dom";
import { projectVisual } from "@/components/portfolio/projectCoherence";

const duplicateGroups = (projects, getKey) => Object.values(projects.reduce((groups, project) => {
  const key = getKey(project);
  if (key) groups[key] = [...(groups[key] || []), project];
  return groups;
}, {})).filter((group) => group.length > 1);

export default function ProjectDuplicateAudit({ projects }) {
  const audit = useMemo(() => ({
    slugs: duplicateGroups(projects, (project) => project.slug?.trim().toLowerCase()),
    visuals: duplicateGroups(projects, projectVisual)
  }), [projects]);
  return (
    <details className="group mb-6 overflow-hidden rounded-[2rem] border border-white/10 bg-black/65 backdrop-blur-xl">
      <summary className="flex cursor-pointer list-none items-center justify-between gap-5 p-6"><div><p className="text-xs uppercase tracking-[0.2em] text-white/40">Audit de cohérence</p><h2 className="mt-2 font-display text-2xl text-white">{audit.slugs.length} slugs · {audit.visuals.length} visuels dupliqués</h2></div><span className="rounded-full border border-white/15 px-4 py-2 text-xs text-white/60 group-open:bg-white group-open:text-black">Détails</span></summary>
      <div className="max-h-96 space-y-5 overflow-y-auto border-t border-white/10 p-6">
        {[...audit.slugs.map((items) => ["Slug", items]), ...audit.visuals.map((items) => ["Visuel", items])].map(([type, items], index) => <div key={`${type}-${index}`}><p className="text-xs uppercase tracking-[0.18em] text-white/35">{type} · {items[0].slug || items[0].title}</p><div className="mt-2 flex flex-wrap gap-2">{items.map((project) => <Link key={project.id} to={`/admin/projects/${project.id}/edit`} className="rounded-full border border-white/10 px-3 py-2 text-sm text-white/70 hover:border-white/30 hover:text-white">{project.title}</Link>)}</div></div>)}
        {!audit.slugs.length && !audit.visuals.length && <p className="text-sm text-white/60">Aucun doublon détecté.</p>}
      </div>
    </details>
  );
}