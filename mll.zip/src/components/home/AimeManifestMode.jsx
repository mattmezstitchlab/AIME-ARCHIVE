import React, { useMemo, useRef, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Download, Lock, Send, Globe, Upload, CheckCircle2 } from "lucide-react";
import AimeManifestStampPreview from "./AimeManifestStampPreview";

const templates = [
  "Pour l’enfant que j’ai été. Pour celles qui ont parlé. Pour celles qu’on n’a pas entendues.",
  "Je crée ce timbre pour inscrire une présence : celle de l’enfant que j’ai été, celle des filles qu’on doit protéger, celle des femmes qui refusent le silence.",
  "Une photo, une mémoire, une intention : ne plus laisser les paroles disparaître.",
];

const dangerWords = ["danger", "violence", "menace", "plainte", "agression", "urgence", "enfant en danger", "119", "112", "114", "17"];

const presenceOptions = [
  ["child_photo", "Photo de moi enfant", "Uniquement si je suis majeur(e) et que j’utilise ma propre photo."],
  ["current_engraved", "Portrait actuel gravé", "Portrait gravé symbolique inspiré du langage visuel du timbre."],
  ["no_face", "Présence sans visage identifiable", "Une trace visuelle sans visage reconnaissable."],
];

const steps = ["Choisir la présence", "Générer le portrait gravé", "Ajouter le texte manifeste", "Valider / enregistrer / exporter"];

function today() {
  return new Date().toLocaleDateString("fr-FR", { day: "2-digit", month: "2-digit", year: "numeric" });
}

export default function AimeManifestMode({ code }) {
  const fileRef = useRef(null);
  const [step, setStep] = useState(0);
  const [status, setStatus] = useState("brouillon privé");
  const [saving, setSaving] = useState(false);
  const [uploadedFile, setUploadedFile] = useState(null);
  const [data, setData] = useState({
    presence: "child_photo",
    imageUrl: "",
    manifestText: templates[0],
    visibility: "privé",
    confirmed: false,
  });

  const protectionTriggered = useMemo(() => {
    const text = data.manifestText.toLowerCase();
    return dangerWords.some((word) => text.includes(word));
  }, [data.manifestText]);

  const effectiveVisibility = protectionTriggered ? "privé" : data.visibility;
  const previewData = { ...data, visibility: effectiveVisibility };

  const handleFile = (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    setUploadedFile(file);
    setData((prev) => ({ ...prev, imageUrl: URL.createObjectURL(file) }));
    setStatus("portrait gravé symbolique généré");
  };

  const saveStamp = async (newStatus) => {
    setSaving(true);
    let portraitUrl = data.imageUrl;
    if (uploadedFile) {
      const upload = await base44.integrations.Core.UploadFile({ file: uploadedFile });
      portraitUrl = upload.file_url;
    }
    await base44.entities.AimeStamp.create({
      code,
      entry_mode: "symbolic",
      intention_type: "manifeste",
      title: "Mode Manifeste — L’enfant que j’ai été",
      note: data.manifestText,
      portrait_url: portraitUrl,
      portrait_mode: data.presence === "child_photo" ? "child_self" : data.presence === "current_engraved" ? "current_portrait" : "no_face",
      visibility: effectiveVisibility,
      image_authorized: data.confirmed,
      charter_accepted: data.confirmed,
      status: newStatus,
      stamp_date: new Date().toISOString().split("T")[0],
      human_validation_required: true,
    });
    setStatus(newStatus === "en_attente_validation" ? "soumis à validation humaine" : "enregistré en privé");
    setSaving(false);
  };

  const exportImage = () => {
    const safeText = data.manifestText.replace(/[&<>]/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[char]));
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="800" viewBox="0 0 1200 800"><rect width="1200" height="800" fill="#f4efe4"/><rect x="70" y="70" width="1060" height="660" rx="42" fill="#ede2cf" stroke="#1c1917" stroke-width="3" stroke-dasharray="12 14"/><text x="110" y="140" font-family="Georgia" font-size="54" fill="#1c1917">AIME · Mode Manifeste</text><text x="110" y="205" font-family="monospace" font-size="28" fill="#57534e">${code} · ${today()} · ${effectiveVisibility}</text><foreignObject x="110" y="260" width="980" height="300"><div xmlns="http://www.w3.org/1999/xhtml" style="font-family:Georgia;font-size:42px;line-height:1.18;color:#1c1917;">${safeText}</div></foreignObject><text x="110" y="660" font-family="Arial" font-size="28" fill="#57534e">Présence symbolique — non officielle.</text></svg>`;
    const blob = new Blob([svg], { type: "image/svg+xml" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `${code}-manifeste.svg`;
    link.click();
    URL.revokeObjectURL(url);
    setStatus("export image téléchargé");
  };

  const canAct = data.confirmed && !saving;

  return (
    <section className="rounded-[2rem] border border-white/10 bg-white/[0.04] p-6 shadow-[0_24px_90px_rgba(0,0,0,0.22)]">
      <div className="flex flex-col justify-between gap-5 lg:flex-row lg:items-end">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.32em] text-white/42">Mode Manifeste</p>
          <h2 className="mt-3 font-display text-5xl font-semibold leading-none tracking-[-0.07em] text-white">L’enfant que j’ai été</h2>
          <p className="mt-4 max-w-3xl text-base leading-7 text-white/68">Créer un timbre manifeste symbolique à partir d’une présence autorisée, d’un texte manifeste, d’un code AIME, d’une date, d’une visibilité et d’une validation humaine.</p>
        </div>
        <div className="rounded-full border border-white/15 px-4 py-3 font-mono text-xs uppercase tracking-[0.2em] text-white/70">{code}</div>
      </div>

      {protectionTriggered && (
        <div className="mt-6 rounded-[1.4rem] border border-amber-300/45 bg-amber-200/14 p-5 text-sm font-semibold leading-6 text-amber-50">
          Cette situation relève du Mode Protection. La visibilité publique est désactivée. En cas de danger immédiat : 17 / 112 / 114. Enfance en danger : 119.
        </div>
      )}

      <div className="mt-6 grid gap-3 sm:grid-cols-4">
        {steps.map((label, index) => (
          <button key={label} type="button" onClick={() => setStep(index)} className={`rounded-full border px-4 py-3 text-xs font-semibold uppercase tracking-[0.16em] transition-colors ${step === index ? "border-[#f4efe4] bg-[#f4efe4] text-stone-950" : "border-white/12 bg-black/20 text-white/58 hover:bg-white/[0.08]"}`}>
            {index + 1}. {label}
          </button>
        ))}
      </div>

      <div className="mt-6 rounded-[1.6rem] border border-white/10 bg-black/25 p-5">
        {step === 0 && (
          <div className="grid gap-3 lg:grid-cols-3">
            {presenceOptions.map(([value, title, text]) => (
              <button key={value} type="button" onClick={() => setData((prev) => ({ ...prev, presence: value }))} className={`rounded-[1.3rem] border p-5 text-left transition-colors ${data.presence === value ? "border-[#f4efe4] bg-[#f4efe4] text-stone-950" : "border-white/10 bg-white/[0.04] text-white"}`}>
                <h3 className="font-display text-3xl font-semibold tracking-[-0.05em]">{title}</h3>
                <p className={`mt-3 text-sm leading-6 ${data.presence === value ? "text-stone-700" : "text-white/62"}`}>{text}</p>
              </button>
            ))}
          </div>
        )}

        {step === 1 && (
          <div className="grid gap-6 lg:grid-cols-[0.7fr_1fr] lg:items-center">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.28em] text-white/42">Portrait gravé</p>
              <h3 className="mt-3 font-display text-4xl font-semibold tracking-[-0.06em] text-white">Portrait gravé symbolique inspiré du langage visuel du timbre.</h3>
              <p className="mt-4 text-sm leading-6 text-white/64">Importez une image autorisée, ou continuez avec une présence sans visage identifiable.</p>
              <button type="button" onClick={() => fileRef.current?.click()} className="mt-5 inline-flex min-h-11 items-center gap-2 rounded-full bg-[#f4efe4] px-5 py-3 text-xs font-semibold uppercase tracking-[0.18em] text-stone-950">
                <Upload className="h-4 w-4" /> Importer l’image
              </button>
              <input ref={fileRef} type="file" accept="image/*" onChange={handleFile} className="hidden" />
            </div>
            <div className="overflow-hidden rounded-[1.5rem] border border-white/10 bg-[#f4efe4] p-4">
              {data.imageUrl ? <img src={data.imageUrl} alt="Aperçu gravé" className="h-80 w-full object-cover grayscale contrast-125 sepia" /> : <div className="flex h-80 items-center justify-center rounded-[1rem] bg-[repeating-linear-gradient(45deg,#e9decf_0_2px,#d4c6b4_2px_4px)] text-center text-sm uppercase tracking-[0.2em] text-stone-500">Aperçu gravé symbolique</div>}
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="grid gap-5 lg:grid-cols-[1fr_0.8fr]">
            <div>
              <label className="text-xs font-semibold uppercase tracking-[0.28em] text-white/42">Texte manifeste</label>
              <textarea value={data.manifestText} onChange={(event) => setData((prev) => ({ ...prev, manifestText: event.target.value }))} rows={9} className="mt-3 w-full resize-none rounded-[1.3rem] border border-white/10 bg-white/[0.06] p-4 text-base leading-7 text-white outline-none placeholder:text-white/30" />
            </div>
            <div className="space-y-3">
              <p className="text-xs font-semibold uppercase tracking-[0.28em] text-white/42">Modèles éditables</p>
              {templates.map((template) => (
                <button key={template} type="button" onClick={() => setData((prev) => ({ ...prev, manifestText: template }))} className="block w-full rounded-2xl border border-white/10 bg-white/[0.04] p-4 text-left text-sm leading-6 text-white/68 transition-colors hover:bg-white/[0.08]">
                  “{template}”
                </button>
              ))}
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-5">
            <div className="grid gap-4 lg:grid-cols-[0.7fr_1fr]">
              <div className="rounded-[1.3rem] border border-white/10 bg-white/[0.04] p-5">
                <label className="text-xs font-semibold uppercase tracking-[0.28em] text-white/42">Visibilité</label>
                <select value={effectiveVisibility} disabled={protectionTriggered} onChange={(event) => setData((prev) => ({ ...prev, visibility: event.target.value }))} className="mt-3 w-full rounded-full border border-white/10 bg-black px-4 py-3 text-sm text-white outline-none disabled:opacity-50">
                  <option value="privé">privé</option>
                  <option value="semi-public">semi-public</option>
                  <option value="public">public</option>
                  <option value="partenaire">partenaire</option>
                </select>
                <label className="mt-5 flex gap-3 text-sm leading-6 text-white/72">
                  <input type="checkbox" checked={data.confirmed} onChange={(event) => setData((prev) => ({ ...prev, confirmed: event.target.checked }))} className="mt-1 h-4 w-4" />
                  Je confirme être majeur(e), utiliser une image dont j’ai les droits, comprendre que ce timbre est symbolique et qu’il ne constitue ni une plainte, ni une preuve, ni un document officiel.
                </label>
              </div>
              <AimeManifestStampPreview data={previewData} previewUrl={data.imageUrl} code={code} date={today()} status={status} />
            </div>
            <div className="flex flex-wrap gap-3">
              <button type="button" disabled={!canAct} onClick={() => saveStamp("privé")} className="inline-flex min-h-11 items-center gap-2 rounded-full bg-[#f4efe4] px-5 py-3 text-xs font-semibold uppercase tracking-[0.18em] text-stone-950 disabled:opacity-40"><Lock className="h-4 w-4" /> Enregistrer en privé</button>
              <button type="button" disabled={!canAct} onClick={() => saveStamp("en_attente_validation")} className="inline-flex min-h-11 items-center gap-2 rounded-full border border-white/20 px-5 py-3 text-xs font-semibold uppercase tracking-[0.18em] text-white disabled:opacity-40"><Send className="h-4 w-4" /> Soumettre à validation</button>
              <button type="button" disabled={!data.confirmed} onClick={exportImage} className="inline-flex min-h-11 items-center gap-2 rounded-full border border-white/20 px-5 py-3 text-xs font-semibold uppercase tracking-[0.18em] text-white disabled:opacity-40"><Download className="h-4 w-4" /> Exporter en image</button>
              <button type="button" disabled={!data.confirmed || protectionTriggered || status !== "soumis à validation humaine"} onClick={() => setStatus("page publique possible après validation")} className="inline-flex min-h-11 items-center gap-2 rounded-full border border-white/20 px-5 py-3 text-xs font-semibold uppercase tracking-[0.18em] text-white disabled:opacity-40"><Globe className="h-4 w-4" /> Créer une page publique après validation</button>
            </div>
            {status && <p className="inline-flex items-center gap-2 text-sm text-white/62"><CheckCircle2 className="h-4 w-4" /> {status}</p>}
          </div>
        )}
      </div>
    </section>
  );
}