import React from "react";
import { X } from "lucide-react";

const modeLabels = {
  presence: "Mode Présence",
  manifesto: "Mode Manifeste",
  protection: "Mode Protection",
  pilot: "Mode Pilote",
};

const rows = [
  ["Personne concernée", "moi / enfant / proche / témoin / professionnel"],
  ["Chronologie", "Dates possibles, lieux, périodes."],
  ["Faits déclarés", "Formulation libre, non qualifiée."],
  ["Éléments disponibles", "Documents, messages, photos, notes."],
  ["Pièces manquantes", "Notées simplement comme manquantes."],
  ["Relais possible", "Association, avocat, professionnel, service officiel."],
];

export default function AimeGuardianSheetDrawer({ open, onClose, code, mode, clarityLevel, createdAt, modifiedAt, sensitiveLock = false }) {
  if (!open) return null;

  const journalRows = [
    ["Créé le", createdAt],
    ["Dernière modification", modifiedAt],
    ["Mode choisi", modeLabels[mode]],
    ["Statut", "Brouillon à relire"],
    ["Niveau de clarté", clarityLevel],
    ["Export privé", "Oui · non officiel"],
    ["Validation humaine", "Obligatoire"],
    ["Version", "v1.0"],
    ["Rôle de relecture", mode === "pilot" ? "validateur simulé" : "humain habilité"],
    ["Transmission automatique", "non"],
  ];

  return (
    <div className="fixed inset-0 z-[80] bg-black/60 backdrop-blur-sm" role="dialog" aria-modal="true">
      <button className="absolute inset-0 h-full w-full cursor-default" aria-label="Fermer la fiche" onClick={onClose} />
      <aside className="absolute right-0 top-0 h-full w-full max-w-xl overflow-y-auto border-l border-stone-200 bg-[#f4efe4] p-6 text-stone-950 shadow-[-30px_0_90px_rgba(0,0,0,0.45)]">
        <div className="flex items-start justify-between gap-4">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.28em] text-stone-500">Fiche privée non officielle</p>
            <h2 className="mt-3 font-display text-5xl font-semibold tracking-[-0.07em]">Le scellé avant le sceau.</h2>
          </div>
          <button onClick={onClose} className="flex h-10 w-10 items-center justify-center rounded-full border border-stone-300 bg-white/50" aria-label="Fermer">
            <X className="h-5 w-5" />
          </button>
        </div>

        {sensitiveLock && (
          <div className="mt-5 rounded-2xl border border-amber-400/50 bg-amber-50/80 p-4 text-sm leading-6 text-amber-950">
            <p className="font-bold">Cette situation relève du Mode Protection. Privé obligatoire. Aucune publication.</p>
            <p className="mt-1 font-mono text-xs">Relais essentiels : 17 / 112 / 114 / 119</p>
          </div>
        )}

        <div className="mt-6 grid gap-3 rounded-2xl border border-stone-200 bg-white/65 p-4 text-sm sm:grid-cols-2">
          <p><span className="text-stone-500">Code AIME</span><br /><span className="font-mono font-bold tracking-[0.14em]">{code}</span></p>
          <p><span className="text-stone-500">Date</span><br />{createdAt}</p>
          <p><span className="text-stone-500">Mode</span><br />{modeLabels[mode]}</p>
          <p><span className="text-stone-500">Statut</span><br />Brouillon à relire</p>
          <p><span className="text-stone-500">Niveau de clarté de la fiche</span><br />{clarityLevel}</p>
          <p><span className="text-stone-500">Export privé</span><br />Disponible · non officiel</p>
        </div>

        {mode === "pilot" && (
          <div className="mt-5 rounded-2xl border border-stone-200 bg-white/70 p-4">
            <p className="text-xs font-semibold uppercase tracking-[0.24em] text-stone-500">Rôles simulés en démonstrateur</p>
            <p className="mt-3 text-sm leading-6 text-stone-700">créateur · écoutant · validateur · observateur · administrateur</p>
            <p className="mt-2 text-xs text-stone-500">Aucun cas réel.</p>
          </div>
        )}

        <div className="mt-5 divide-y divide-stone-200 overflow-hidden rounded-2xl border border-stone-200 bg-white">
          {rows.map(([label, value]) => (
            <div key={label} className="p-4">
              <p className="text-[10px] font-semibold uppercase tracking-[0.22em] text-stone-400">{label}</p>
              <p className="mt-1 text-sm leading-6 text-stone-700">{value}</p>
            </div>
          ))}
        </div>

        <div className="mt-5 rounded-2xl border border-stone-200 bg-white/70 p-4">
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-stone-500">Journal de garde</p>
          <div className="mt-3 grid gap-2 text-sm sm:grid-cols-2">
            {journalRows.map(([label, value]) => (
              <p key={label} className="rounded-xl bg-stone-50 p-3"><span className="text-stone-500">{label}</span><br />{value}</p>
            ))}
          </div>
        </div>

        <p className="mt-5 rounded-2xl border border-stone-200 bg-white/60 p-4 text-sm leading-6 text-stone-700">
          L’IA prépare. L’humain valide. Rien n’est transmis automatiquement.
        </p>
      </aside>
    </div>
  );
}