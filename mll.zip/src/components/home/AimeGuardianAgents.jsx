import React from "react";

export const guardianAgents = [
  ["Urgence", "Je rappelle les relais essentiels."],
  ["Écoute", "Je vous aide à formuler sans juger."],
  ["Temps", "Je remets les éléments dans l’ordre."],
  ["Pièces", "Je distingue ce qui existe et ce qui manque."],
  ["Relais", "Je propose des portes possibles."],
  ["Scellé", "Je prépare une fiche privée, datée, versionnée."],
];

export default function AimeGuardianAgents() {
  return (
    <div className="rounded-[2rem] border border-white/10 bg-white/[0.04] p-6 shadow-[0_24px_90px_rgba(0,0,0,0.22)]">
      <p className="text-xs font-semibold uppercase tracking-[0.3em] text-white/42">Calibration humaine · 6 agents</p>
      <div className="mt-5 grid gap-3 sm:grid-cols-2">
        {guardianAgents.map(([name, text], index) => (
          <article key={name} className="rounded-2xl border border-white/10 bg-black/25 p-4">
            <div className="flex items-center gap-3">
              <span className="flex h-8 w-8 items-center justify-center rounded-full bg-[#f4efe4] text-xs font-bold text-stone-950">
                {index + 1}
              </span>
              <h3 className="font-display text-2xl font-semibold tracking-[-0.05em]">{name}</h3>
            </div>
            <p className="mt-3 text-sm leading-6 text-white/64">{text}</p>
          </article>
        ))}
      </div>
    </div>
  );
}