import React, { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import NeumorphicMachine from "@/components/machine/NeumorphicMachine";
import AimeGuardianSheetDrawer from "./AimeGuardianSheetDrawer";
import AimeGuardianAccordions from "./AimeGuardianAccordions";

const prompts = [
  "Transformer une présence en timbre AIME protecteur",
  "Créer une trace douce, lisible et scellée",
  "Composer un timbre de mémoire sensible",
];

const sensitiveKeywords = [
  "enfant", "agression", "viol", "menace", "danger", "violence", "plainte", "urgence", "mineur", "harcèlement", "témoin", "peur"
];

function containsSensitiveSituation(value) {
  const text = value.toLowerCase();
  return sensitiveKeywords.some((keyword) => text.includes(keyword));
}

const defaultStampUrl = "https://media.base44.com/images/public/6a26f7e77a120b841e3ff78d/facce4c56_generated_image.png";

function createCode() {
  return `AIME-${Math.random().toString(36).slice(2, 5).toUpperCase()}-${Math.random().toString(36).slice(2, 5).toUpperCase()}`;
}

function formatDate(date) {
  return date.toLocaleDateString("fr-FR", { day: "2-digit", month: "2-digit", year: "numeric" });
}

function getClarityLevel({ prompt, photoUrl, capsuleEnabled, stampUrl }) {
  const hasPrompt = !!prompt?.trim() && prompt !== "Information inconnue ou à préciser.";
  if (stampUrl) return "prêt à relire";
  if (hasPrompt && (photoUrl || capsuleEnabled)) return "clair";
  if (hasPrompt || photoUrl || capsuleEnabled) return "partiel";
  return "à compléter";
}

const sectionGlow = {
  presence: "rgba(244,239,228,0.14)",
  manifesto: "rgba(234,216,188,0.15)",
  protection: "rgba(245,158,11,0.12)",
  pilot: "rgba(16,185,129,0.1)",
};

export default function HomeStampMachineSection() {
  const [code, setCode] = useState(createCode());
  const [stampUrl, setStampUrl] = useState(null);
  const [photoUrl, setPhotoUrl] = useState(null);
  const [prompt, setPrompt] = useState(prompts[0]);
  const [busy, setBusy] = useState(false);
  const [printing, setPrinting] = useState(false);
  const [capsuleEnabled, setCapsuleEnabled] = useState(false);
  const [capsuleDate, setCapsuleDate] = useState("");
  const [capsuleMessage, setCapsuleMessage] = useState("");
  const [selectedMode, setSelectedMode] = useState("presence");
  const [sheetOpen, setSheetOpen] = useState(false);
  const [frameSignal, setFrameSignal] = useState(0);
  const [createdAt] = useState(() => new Date());
  const [modifiedAt, setModifiedAt] = useState(() => new Date());

  useEffect(() => {
    return () => {
      if (photoUrl?.startsWith("blob:")) URL.revokeObjectURL(photoUrl);
    };
  }, [photoUrl]);

  useEffect(() => {
    setModifiedAt(new Date());
  }, [prompt, photoUrl, capsuleEnabled, capsuleDate, capsuleMessage, selectedMode, stampUrl]);

  const sensitiveLock = useMemo(() => containsSensitiveSituation(prompt || ""), [prompt]);

  useEffect(() => {
    if (sensitiveLock) setSelectedMode("protection");
  }, [sensitiveLock]);

  const clarityLevel = useMemo(
    () => getClarityLevel({ prompt, photoUrl, capsuleEnabled, stampUrl }),
    [prompt, photoUrl, capsuleEnabled, stampUrl]
  );

  const handlePhotoChange = (file) => {
    if (photoUrl?.startsWith("blob:")) URL.revokeObjectURL(photoUrl);
    setPhotoUrl(URL.createObjectURL(file));
    setStampUrl(null);
  };

  const handlePrint = () => {
    if (sensitiveLock) {
      setStampUrl(null);
      setSheetOpen(true);
      return;
    }

    setBusy(true);
    setStampUrl(null);
    setTimeout(() => {
      setBusy(false);
      setPrinting(true);
      setStampUrl(photoUrl || defaultStampUrl);
      setTimeout(() => setPrinting(false), 1400);
    }, 700);
  };

  const handleModeChange = (mode) => {
    if (sensitiveLock && mode !== "protection") return;
    setSelectedMode(mode);
  };

  const handleNew = () => {
    setCode(createCode());
    setStampUrl(null);
    setPrompt(prompts[0]);
    setCapsuleEnabled(false);
    setCapsuleDate("");
    setCapsuleMessage("");
  };

  return (
    <section className="relative z-10 overflow-hidden border-y border-white/10 bg-black px-5 py-8 text-white sm:px-8 lg:px-12 lg:py-10">
      <div className="absolute inset-0" style={{ background: `radial-gradient(circle at 22% 12%, ${sectionGlow[selectedMode]}, transparent 30%), radial-gradient(circle at 78% 20%, rgba(255,255,255,0.09), transparent 32%)` }} />
      <div className="relative mx-auto max-w-7xl space-y-10">
        <div className="flex items-center justify-between gap-4">
          <Link to="/" className="inline-flex min-h-11 items-center gap-2 rounded-full border border-white/15 bg-white/[0.04] px-4 py-3 text-xs font-semibold uppercase tracking-[0.2em] text-white/78 transition-colors hover:bg-white hover:text-black">
            <ArrowLeft className="h-4 w-4" /> Accueil
          </Link>
          <a href="/" onClick={() => setSheetOpen(false)} className="min-h-11 rounded-full border border-amber-300/30 bg-amber-300/10 px-4 py-3 text-xs font-semibold uppercase tracking-[0.2em] text-amber-100 transition-colors hover:bg-amber-100 hover:text-black">
            Quitter vite
          </a>
        </div>

        <div id="machine-aime" className="grid items-center gap-10 lg:grid-cols-[0.9fr_1fr]">
          <div className="mx-auto max-w-2xl lg:mx-0">
            <p className="text-xs font-semibold uppercase tracking-[0.35em] text-white/45">AIME Gardien</p>
            <h1 className="mt-5 font-display text-5xl font-semibold leading-[0.92] tracking-[-0.08em] sm:text-7xl">
              Accueillir d’abord. Orienter ensuite.
            </h1>
            <p className="mt-6 max-w-xl text-lg leading-8 text-white/72">
              Une interface de pré-orientation : elle aide à poser les mots, garde une trace privée et rappelle le cadre humain.
            </p>

            <div className="mt-8 grid gap-3 sm:grid-cols-3 lg:grid-cols-1">
              <div className="rounded-[1.5rem] border border-white/10 bg-white/[0.045] p-4">
                <p className="text-[10px] font-bold uppercase tracking-[0.24em] text-white/42">01 · Accueil</p>
                <p className="mt-2 text-sm leading-6 text-white/70">Écrire simplement, même si tout n’est pas clair.</p>
              </div>
              <div className="rounded-[1.5rem] border border-white/10 bg-white/[0.045] p-4">
                <p className="text-[10px] font-bold uppercase tracking-[0.24em] text-white/42">02 · Scellé</p>
                <p className="mt-2 text-sm leading-6 text-white/70">Préparer une fiche privée, datée, relisible.</p>
              </div>
              <div className="rounded-[1.5rem] border border-white/10 bg-white/[0.045] p-4">
                <p className="text-[10px] font-bold uppercase tracking-[0.24em] text-white/42">03 · Validation</p>
                <p className="mt-2 text-sm leading-6 text-white/70">Aucune transmission automatique : l’humain décide.</p>
              </div>
            </div>

            <div className="mt-7 flex flex-wrap gap-3">
              <button type="button" onClick={() => setFrameSignal((value) => value + 1)} className="rounded-full bg-[#f4efe4] px-5 py-3 text-xs font-bold uppercase tracking-[0.18em] text-stone-950">Voir le cadre</button>
              <button type="button" onClick={() => handleModeChange("pilot")} className="rounded-full border border-white/15 px-5 py-3 text-xs font-bold uppercase tracking-[0.18em] text-white/80">Mode Pilote</button>
            </div>
          </div>

          <NeumorphicMachine
            code={code}
            stampUrl={stampUrl}
            photoUrl={photoUrl}
            prompt={prompt}
            onPromptChange={setPrompt}
            onPhotoChange={handlePhotoChange}
            onPrint={handlePrint}
            onNew={handleNew}
            busy={busy}
            printing={printing}
            capsuleEnabled={capsuleEnabled}
            onCapsuleToggle={setCapsuleEnabled}
            capsuleDate={capsuleDate}
            onCapsuleDateChange={setCapsuleDate}
            capsuleMessage={capsuleMessage}
            onCapsuleMessageChange={setCapsuleMessage}
            mode={selectedMode}
            onModeChange={handleModeChange}
            sensitiveLock={sensitiveLock}
            onOpenSheet={() => setSheetOpen(true)}
            clarityLevel={clarityLevel}
            frameSignal={frameSignal}
            onRandom={() => setPrompt(prompts[Math.floor(Math.random() * prompts.length)])}
          />
        </div>

        <AimeGuardianAccordions />
      </div>

      <AimeGuardianSheetDrawer
        open={sheetOpen}
        onClose={() => setSheetOpen(false)}
        code={code}
        mode={selectedMode}
        clarityLevel={clarityLevel}
        createdAt={formatDate(createdAt)}
        modifiedAt={formatDate(modifiedAt)}
        sensitiveLock={sensitiveLock}
      />
    </section>
  );
}