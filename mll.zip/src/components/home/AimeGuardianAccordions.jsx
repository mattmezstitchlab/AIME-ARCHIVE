import React, { useState } from "react";
import { ChevronDown } from "lucide-react";

const items = [
  {
    title: "Ce que la machine prépare",
    text: "Une parole structurée, un code AIME, un timbre ou une fiche privée, datée et relisible.",
  },
  {
    title: "Ce qu’elle ne fait jamais",
    text: "Aucune plainte officielle, aucune enquête, aucun coupable désigné, aucune qualification juridique, aucun score de danger, aucun score de crédibilité, aucune décision automatique et aucune transmission automatique. AIME ne remplace pas police, gendarmerie, justice, avocat, association ou professionnel.",
  },
  {
    title: "Mode institutionnel fermé",
    text: "Le Mode Pilote sert de démonstrateur avec données fictives, rôles de validation et aucun cas réel.",
  },
  {
    title: "Conformité par conception",
    text: "Données minimisées, privé par défaut en Mode Protection, aucune plainte officielle, aucune enquête, aucune décision automatique, aucun score de danger ou de crédibilité, journal d’audit, validation humaine, export privé non officiel. AIPD / RGPD à prévoir avant toute expérimentation sensible.",
  },
  {
    title: "Version souveraine possible",
    text: "AIME Gardien peut fonctionner en démonstrateur public sans données sensibles, puis en version fermée, hébergée en environnement souverain, avec accès par rôles, journal d’audit, données minimisées et validation humaine obligatoire.",
  },
];

export default function AimeGuardianAccordions() {
  const [open, setOpen] = useState(null);

  return (
    <div className="mx-auto grid max-w-5xl gap-3">
      {items.map((item, index) => {
        const active = open === index;
        return (
          <div key={item.title} className="overflow-hidden rounded-[1.4rem] border border-white/10 bg-white/[0.035]">
            <button type="button" onClick={() => setOpen(active ? null : index)} className="flex w-full items-center justify-between gap-4 p-5 text-left">
              <span className="font-display text-2xl font-semibold tracking-[-0.04em] text-white">{item.title}</span>
              <ChevronDown className={`h-5 w-5 text-white/55 transition-transform ${active ? "rotate-180" : ""}`} />
            </button>
            {active && <p className="border-t border-white/10 px-5 pb-5 pt-4 text-sm leading-6 text-white/64">{item.text}</p>}
          </div>
        );
      })}
    </div>
  );
}