import React from "react";

const modes = [
  {
    id: "presence",
    title: "Mode Présence",
    tone: "Mémoire · soutien",
    rule: "Timbre public possible seulement après validation humaine.",
  },
  {
    id: "manifesto",
    title: "Mode Manifeste",
    tone: "L’enfant que j’ai été",
    rule: "Timbre symbolique, droits d’image, charte signée et validation humaine obligatoire.",
  },
  {
    id: "protection",
    title: "Mode Protection",
    tone: "Situation sensible · privé obligatoire",
    rule: "Publication désactivée, export privé uniquement.",
  },
  {
    id: "pilot",
    title: "Mode Pilote",
    tone: "Démonstrateur institutionnel",
    rule: "Données fictives, audit visible, aucun cas réel, aucun transfert officiel.",
  },
];

const activeStyles = {
  presence: "border-[#f4efe4] bg-[#f4efe4] text-stone-950 shadow-[0_24px_80px_rgba(244,239,228,0.16)]",
  manifesto: "border-[#ead8bc] bg-[#ead8bc] text-stone-950 shadow-[0_24px_80px_rgba(234,216,188,0.16)]",
  protection: "border-amber-200 bg-amber-100/95 text-stone-950 shadow-[0_24px_80px_rgba(245,158,11,0.14)]",
  pilot: "border-emerald-100 bg-emerald-50 text-stone-950 shadow-[0_24px_80px_rgba(16,185,129,0.12)]",
};

export default function AimeGuardianUsageModes({ selectedMode, onSelectMode }) {
  return (
    <div className="grid gap-3 lg:grid-cols-4">
      {modes.map((mode) => {
        const active = selectedMode === mode.id;
        return (
          <button
            key={mode.id}
            type="button"
            onClick={() => onSelectMode(mode.id)}
            className={`min-h-44 rounded-[1.4rem] border p-5 text-left transition-colors ${
              active ? activeStyles[mode.id] : "border-white/12 bg-white/[0.04] text-white hover:bg-white/[0.08]"
            }`}
          >
            <p className={`text-xs font-semibold uppercase tracking-[0.24em] ${active ? "text-stone-500" : "text-white/42"}`}>AIME Gardien</p>
            <h3 className="mt-3 font-display text-3xl font-semibold tracking-[-0.05em]">{mode.title}</h3>
            <p className={`mt-2 text-sm font-semibold uppercase tracking-[0.16em] ${active ? "text-stone-600" : "text-white/58"}`}>{mode.tone}</p>
            <p className={`mt-4 text-sm leading-6 ${active ? "text-stone-700" : "text-white/62"}`}>{mode.rule}</p>
          </button>
        );
      })}
    </div>
  );
}