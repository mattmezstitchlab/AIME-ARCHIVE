import React from "react";
import { AlertTriangle } from "lucide-react";

export default function AimeGuardianBanner({ mode = "presence" }) {
  const protection = mode === "protection";

  return (
    <div className={`rounded-[1.6rem] border p-5 shadow-[0_20px_70px_rgba(0,0,0,0.25)] backdrop-blur-xl ${protection ? "border-amber-300/45 bg-amber-200/14 text-amber-50" : "border-white/10 bg-white/[0.035] text-white"}`}>
      <div className="flex flex-col gap-4 sm:flex-row sm:items-start">
        <div className={`flex h-11 w-11 flex-shrink-0 items-center justify-center rounded-full ${protection ? "bg-amber-200 text-black" : "bg-[#f4efe4] text-stone-950"}`}>
          <AlertTriangle className="h-5 w-5" />
        </div>
        <div>
          <p className="text-sm font-semibold uppercase tracking-[0.22em]">
            Danger immédiat : 17 ou 112. Urgence par SMS : 114. Enfance en danger : 119.
          </p>
          <p className="mt-2 text-sm leading-6 text-white/72">AIME Gardien n’est pas un service d’urgence. Ce bandeau est un rappel de relais essentiels.</p>
        </div>
      </div>
    </div>
  );
}