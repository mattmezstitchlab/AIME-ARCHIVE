import React from "react";

const does = [
  "accueille une parole avec méthode",
  "aide à formuler avec ses propres mots",
  "structure une chronologie, même approximative",
  "distingue les éléments disponibles et manquants",
  "prépare une orientation possible",
  "date, versionne et scelle une fiche privée",
  "prépare un export privé non officiel",
  "demande une validation humaine avant toute exposition",
];

const notDo = [
  "aucune plainte officielle",
  "aucune enquête",
  "aucun coupable désigné",
  "aucune qualification juridique automatique",
  "aucun score de danger",
  "aucun score de crédibilité",
  "aucune transmission automatique",
  "privé par défaut en mode Protection",
];

function ListBlock({ title, items, light = false }) {
  return (
    <div className={`rounded-[2rem] border p-6 ${light ? "border-stone-200 bg-[#f4efe4] text-stone-950" : "border-white/10 bg-white/[0.04] text-white"}`}>
      <h3 className="font-display text-4xl font-semibold tracking-[-0.06em]">{title}</h3>
      <ul className="mt-5 space-y-3">
        {items.map((item) => (
          <li key={item} className={`flex gap-3 text-sm leading-6 ${light ? "text-stone-700" : "text-white/68"}`}>
            <span className={`mt-2 h-1.5 w-1.5 flex-shrink-0 rounded-full ${light ? "bg-stone-950" : "bg-white"}`} />
            {item}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default function AimeGuardianInfoBlocks() {
  return (
    <div className="grid gap-5 lg:grid-cols-2">
      <ListBlock title="Ce que la machine fait" items={does} light />
      <ListBlock title="Ce que la machine ne fait pas" items={notDo} />
    </div>
  );
}