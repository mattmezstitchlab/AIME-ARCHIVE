import React from "react";

const modeLabels = {
  presence: "Mode Présence",
  manifesto: "Mode Manifeste",
  protection: "Mode Protection",
  pilot: "Mode Pilote",
};

const fields = [
  ["Personne concernée", "moi / enfant / proche / témoin / professionnel"],
  ["Département", "Information inconnue ou à préciser."],
  ["Chronologie courte", "dates possibles, lieux, périodes"],
  ["Faits déclarés", "formulation libre, non qualifiée"],
  ["Éléments disponibles", "documents, messages, photos, notes"],
  ["Pièces manquantes", "notées simplement comme manquantes"],
  ["Relais possible", "association, avocat, professionnel, service officiel"],
];

export default function AimeGuardianOrientationSheet({ code, selectedMode, clarityLevel, createdAt, modifiedAt }) {
  return (
    <aside className="rounded-[2rem] border border-white/20 bg-[#f4efe4] p-6 text-stone-950 shadow-[0_30px_90px_rgba(0,0,0,0.35)]">
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.28em] text-stone-500">Fiche d’orientation générée</p>
          <h3 className="mt-2 font-display text-4xl font-semibold tracking-[-0.06em]">Scellé AIME</h3>
        </div>
        <div className="rotate-[-4deg] rounded-full border-2 border-stone-900 px-4 py-2 text-center font-mono text-[10px] font-bold uppercase tracking-[0.18em] text-stone-900">
          Non officiel
        </div>
      </div>

      <p className="mt-4 rounded-2xl border border-stone-300 bg-white/65 p-4 text-sm leading-6 text-stone-700">
        Fiche privée de préparation. Ne vaut ni plainte, ni preuve, ni décision.
      </p>

      <div className="mt-4 rounded-2xl border border-stone-200 bg-white p-4">
        <div className="grid gap-3 text-sm sm:grid-cols-2">
          <div>
            <span className="text-xs uppercase tracking-[0.22em] text-stone-400">Code AIME</span>
            <p className="mt-1 font-mono font-bold tracking-[0.16em]">{code}</p>
          </div>
          <div>
            <span className="text-xs uppercase tracking-[0.22em] text-stone-400">Niveau de clarté</span>
            <p className="mt-1 font-semibold text-emerald-800">{clarityLevel}</p>
          </div>
        </div>
      </div>

      <div className="mt-4 divide-y divide-stone-200 overflow-hidden rounded-2xl border border-stone-200 bg-white">
        {fields.map(([label, value]) => (
          <div key={label} className="grid gap-1 p-3">
            <span className="text-[10px] font-semibold uppercase tracking-[0.22em] text-stone-400">{label}</span>
            <span className="text-sm leading-5 text-stone-700">{value}</span>
          </div>
        ))}
      </div>

      <div className="mt-4 rounded-2xl border border-stone-200 bg-white p-4">
        <p className="text-xs font-semibold uppercase tracking-[0.24em] text-stone-500">Journal de garde</p>
        <dl className="mt-3 grid gap-2 text-sm text-stone-700 sm:grid-cols-2">
          <div><dt className="text-stone-400">Créé le</dt><dd>{createdAt}</dd></div>
          <div><dt className="text-stone-400">Mode choisi</dt><dd>{modeLabels[selectedMode]}</dd></div>
          <div><dt className="text-stone-400">Dernière modification</dt><dd>{modifiedAt}</dd></div>
          <div><dt className="text-stone-400">Statut</dt><dd>Brouillon à relire</dd></div>
          <div><dt className="text-stone-400">Export privé</dt><dd>Disponible</dd></div>
          <div><dt className="text-stone-400">Validation humaine</dt><dd>Obligatoire</dd></div>
          <div><dt className="text-stone-400">Version</dt><dd>v1.0</dd></div>
        </dl>
      </div>
    </aside>
  );
}