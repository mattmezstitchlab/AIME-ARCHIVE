import React from "react";

function QrGlyph() {
  return (
    <div className="grid h-20 w-20 grid-cols-5 gap-1 rounded-lg bg-stone-950 p-2" aria-label="QR code symbolique">
      {Array.from({ length: 25 }).map((_, index) => (
        <span key={index} className={`${[0, 1, 3, 5, 6, 9, 10, 12, 15, 18, 19, 20, 22, 24].includes(index) ? "bg-white" : "bg-stone-950"} rounded-[1px]`} />
      ))}
    </div>
  );
}

export default function AimeManifestStampPreview({ data, previewUrl, code, date, status }) {
  const intention = data.presence === "child_photo" ? "L’enfant que j’ai été" : data.presence === "current_engraved" ? "Portrait actuel gravé" : "Présence sans visage";

  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <article className="stamp-perforated bg-[#f4efe4] p-5 text-stone-950">
        <p className="text-[10px] font-semibold uppercase tracking-[0.28em] text-stone-500">Recto · timbre manifeste</p>
        <div className="mt-4 overflow-hidden rounded-[1.2rem] border border-stone-300 bg-stone-200">
          {previewUrl ? (
            <img src={previewUrl} alt="Portrait gravé symbolique" className="h-64 w-full object-cover grayscale contrast-125 sepia" />
          ) : (
            <div className="flex h-64 items-center justify-center bg-[radial-gradient(circle_at_center,#d7cbb8,transparent_62%),repeating-linear-gradient(45deg,#e9decf_0_2px,#d4c6b4_2px_4px)] text-center text-sm uppercase tracking-[0.2em] text-stone-500">
              Présence symbolique
            </div>
          )}
        </div>
        <div className="mt-4 grid gap-2 text-sm">
          <p><span className="text-stone-500">Code AIME</span> · <span className="font-mono font-bold tracking-[0.14em]">{code}</span></p>
          <p><span className="text-stone-500">Date</span> · {date}</p>
          <p><span className="text-stone-500">Intention</span> · {intention}</p>
          <p><span className="text-stone-500">Statut</span> · {status}</p>
        </div>
      </article>

      <article className="stamp-perforated bg-[#ede2cf] p-5 text-stone-950">
        <p className="text-[10px] font-semibold uppercase tracking-[0.28em] text-stone-500">Verso · manifeste</p>
        <blockquote className="mt-5 min-h-44 rounded-[1.2rem] border border-stone-300 bg-white/55 p-4 font-display text-2xl font-semibold leading-tight tracking-[-0.04em]">
          “{data.manifestText || "Texte manifeste à écrire."}”
        </blockquote>
        <div className="mt-4 flex items-end justify-between gap-4">
          <div className="space-y-2 text-sm text-stone-700">
            <p><span className="text-stone-500">Visibilité</span> · {data.visibility}</p>
            <p><span className="text-stone-500">Charte signée</span> · {data.confirmed ? "oui" : "non"}</p>
            <p className="font-semibold">Présence symbolique — non officielle.</p>
          </div>
          <QrGlyph />
        </div>
      </article>
    </div>
  );
}