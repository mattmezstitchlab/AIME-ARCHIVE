import React from "react";

export default function AimeGuardianTrustBlock() {
  return (
    <div className="rounded-[2rem] border border-white/10 bg-white/[0.04] p-8 shadow-[0_24px_90px_rgba(0,0,0,0.22)]">
      <p className="text-xs font-semibold uppercase tracking-[0.32em] text-white/42">Confiance</p>
      <h3 className="mt-4 font-display text-5xl font-semibold leading-none tracking-[-0.07em] text-white">Une machine, pas un chatbot.</h3>
      <p className="mt-5 max-w-4xl text-lg leading-8 text-white/70">
        AIME Gardien n’est pas une chatbot. C’est une machine de pré-orientation : elle accueille, structure, date, versionne et prépare une parole. L’IA prépare. L’humain valide.
      </p>
    </div>
  );
}