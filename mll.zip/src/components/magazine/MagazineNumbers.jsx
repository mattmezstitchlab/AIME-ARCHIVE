import React from "react";

const numbers = [
  ["06", "Agents", "Une équipe, pas un automate."],
  ["04", "Degrés", "Privé, semi-public, public, partenaire."],
  ["∞", "Timbres", "Chaque présence peut être scellée."],
  ["01", "Registre", "Un lieu pour protéger la mémoire."],
];

export default function MagazineNumbers() {
  return (
    <section className="bg-stone-50 px-5 py-24 text-stone-950 sm:px-8 lg:px-12">
      <div className="mx-auto max-w-7xl">
        <p className="text-xs uppercase tracking-[0.32em] text-stone-500">Données · p. 23</p>
        <h2 className="mt-6 max-w-3xl font-display text-6xl font-semibold leading-none tracking-[-0.07em] sm:text-8xl">AIME en chiffres</h2>
        <p className="mt-8 max-w-2xl text-xl leading-8 text-stone-600">Ce qui se mesure dans une machine qui aime — et ce qui résiste à la mesure.</p>
        <div className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {numbers.map(([value, label, text]) => (
            <article key={label} className="rounded-[2rem] border border-stone-200 bg-white p-8">
              <div className="font-display text-7xl font-semibold tracking-[-0.08em]">{value}</div>
              <h3 className="mt-5 text-xs font-semibold uppercase tracking-[0.25em] text-stone-500">{label}</h3>
              <p className="mt-4 text-sm leading-6 text-stone-600">{text}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}