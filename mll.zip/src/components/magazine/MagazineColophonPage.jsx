import React from "react";
import { Link } from "react-router-dom";

export default function MagazineColophonPage() {
  return (
    <section className="bg-black px-5 py-24 text-white sm:px-8 lg:px-12">
      <div className="mx-auto max-w-7xl text-center">
        <p className="text-xs uppercase tracking-[0.32em] text-white/45">Colophon · fin du numéro</p>
        <h2 className="mx-auto mt-6 max-w-5xl font-display text-6xl font-semibold leading-none tracking-[-0.07em] sm:text-8xl">
          AIME® Magazine — Numéro 01
        </h2>
        <p className="mx-auto mt-10 max-w-3xl text-lg leading-8 text-white/65">
          Direction éditoriale : Matt Mez. Univers : AIME. Ce numéro assemble la couverture, le sommaire, l’édito, le portrait, les agents, les chiffres, l’architecture et le manifeste dans une forme web complète.
        </p>
        <div className="mt-12 flex flex-wrap justify-center gap-3">
          <Link to="/" className="rounded-full bg-white px-5 py-3 text-xs font-semibold uppercase tracking-[0.22em] text-black transition hover:bg-white/85">Retour accueil</Link>
          <Link to="/registre-aime" className="rounded-full border border-white/15 px-5 py-3 text-xs font-semibold uppercase tracking-[0.22em] text-white transition hover:border-white/45">Registre AIME</Link>
        </div>
      </div>
    </section>
  );
}