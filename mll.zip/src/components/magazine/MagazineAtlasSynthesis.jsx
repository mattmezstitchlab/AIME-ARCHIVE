import React from "react";
import { Link } from "react-router-dom";
import { ArrowUpRight } from "lucide-react";

const families = [
  "IA sensible",
  "Mémoire & transmission",
  "Outils métier",
  "Édition & média",
  "Accessibilité",
  "Événementiel"
];

export default function MagazineAtlasSynthesis() {
  return (
    <section className="bg-[#f4efe4] px-5 py-24 text-stone-950 sm:px-8 lg:px-12">
      <div className="mx-auto grid max-w-7xl gap-12 lg:grid-cols-[0.8fr_1.2fr] lg:items-end">
        <div>
          <p className="text-xs font-black uppercase tracking-[0.32em] text-stone-500">Atlas · p. 10</p>
          <h2 className="mt-6 font-display text-6xl font-semibold leading-[0.9] tracking-[-0.07em] sm:text-8xl">162 projets, une même architecture.</h2>
        </div>
        <div className="space-y-8">
          <p className="text-xl leading-9 text-stone-700">Le catalogue complet de l’Atlas AIME devient la matière vivante du site : chaque fiche garde son intention, sa famille, ses visuels reconstruits et sa logique de transmission.</p>
          <div className="grid gap-2 sm:grid-cols-2">
            {families.map((family) => <span key={family} className="rounded-full border border-stone-300 px-4 py-3 text-sm font-semibold text-stone-700">{family}</span>)}
          </div>
          <Link to="/" className="inline-flex min-h-12 items-center gap-3 rounded-full bg-stone-950 px-6 text-sm font-bold text-white">
            Voir le catalogue <ArrowUpRight className="h-4 w-4" />
          </Link>
        </div>
      </div>
    </section>
  );
}