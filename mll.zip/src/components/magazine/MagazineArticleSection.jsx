import React from "react";

export default function MagazineArticleSection({ id, number, kicker, title, paragraphs, quote, note }) {
  return (
    <section id={id} className="scroll-mt-20 border-t border-stone-200 bg-[#f4efe4] px-5 py-20 text-stone-950 sm:px-8 lg:px-12">
      <article className="mx-auto grid max-w-7xl gap-10 lg:grid-cols-[0.34fr_1fr]">
        <aside className="lg:sticky lg:top-24 lg:h-fit">
          <p className="font-display text-7xl font-semibold leading-none tracking-[-0.08em] text-stone-300">{number}</p>
          <p className="mt-5 text-xs font-black uppercase tracking-[0.28em] text-stone-500">{kicker}</p>
        </aside>
        <div className="max-w-4xl">
          <h2 className="font-display text-5xl font-semibold leading-[0.92] tracking-[-0.07em] sm:text-7xl lg:text-8xl">{title}</h2>
          <div className="mt-10 columns-1 gap-12 text-lg leading-9 text-stone-700 lg:columns-2">
            {paragraphs.map((paragraph) => (
              <p key={paragraph} className="mb-7 break-inside-avoid">{paragraph}</p>
            ))}
          </div>
          {quote && (
            <blockquote className="mt-10 border-l-2 border-stone-950 pl-6 font-display text-3xl italic leading-tight tracking-[-0.04em] text-stone-950 sm:text-4xl">
              « {quote} »
            </blockquote>
          )}
          {note && (
            <div className="mt-10 rounded-[1.5rem] border border-stone-300 bg-white/45 p-6 text-sm leading-7 text-stone-700">
              <span className="mb-3 block text-xs font-black uppercase tracking-[0.24em] text-stone-500">Note AIME</span>
              {note}
            </div>
          )}
        </div>
      </article>
    </section>
  );
}