import React from "react";

export default function MagazineQuoteSpread({ eyebrow, quote, author }) {
  return (
    <section className="flex min-h-[70vh] items-center justify-center bg-black px-5 py-24 text-white sm:px-8 lg:px-12">
      <div className="mx-auto max-w-5xl text-center">
        <p className="text-xs uppercase tracking-[0.35em] text-white/40">{eyebrow}</p>
        <div className="mt-10 font-display text-8xl leading-none text-white/20">“</div>
        <blockquote className="mx-auto max-w-4xl font-display text-5xl italic leading-tight tracking-[-0.05em] sm:text-7xl">
          {quote}
        </blockquote>
        <p className="mt-10 text-xs uppercase tracking-[0.3em] text-white/45">{author}</p>
      </div>
    </section>
  );
}