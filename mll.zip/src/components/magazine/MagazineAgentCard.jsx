import React from "react";

export default function MagazineAgentCard({ agent, index }) {
  return (
    <article className="grid overflow-hidden border-t border-white/10 bg-black text-white lg:grid-cols-[0.9fr_1.1fr]">
      <div className="min-h-[520px] bg-white/[0.03]">
        <img src={agent.image} alt={agent.name} className="h-full w-full object-cover" loading="lazy" />
      </div>
      <div className="flex min-h-[520px] flex-col justify-between p-8 sm:p-12 lg:p-16">
        <div>
          <p className="text-xs uppercase tracking-[0.28em] text-white/45">L’équipe · {String(index + 1).padStart(2, "0")} / 06</p>
          <h3 className="mt-8 font-display text-6xl font-semibold tracking-[-0.07em] sm:text-8xl">{agent.name}</h3>
          <p className="mt-4 text-lg uppercase tracking-[0.18em] text-white/55">{agent.role}</p>
          <blockquote className="mt-10 max-w-2xl font-display text-3xl italic leading-tight tracking-[-0.04em] text-white/92">
            « {agent.quote} »
          </blockquote>
          <p className="mt-8 max-w-2xl text-base leading-8 text-white/66">{agent.text}</p>
        </div>
        <div className="mt-10 flex flex-wrap items-center gap-3 text-xs uppercase tracking-[0.2em] text-white/55">
          <span className="rounded-full border border-white/15 px-4 py-2">{agent.stamp}</span>
          <span>● Agent actif</span>
        </div>
      </div>
    </article>
  );
}