import React from "react";
import { Quote } from "lucide-react";

export default function MagazineEditorialBlock() {
  return (
    <section className="bg-black px-5 py-24 text-white sm:px-8 lg:px-12">
      <div className="mx-auto grid max-w-7xl gap-12 lg:grid-cols-[0.75fr_1.25fr]">
        <aside className="lg:sticky lg:top-10 lg:self-start">
          <p className="text-xs uppercase tracking-[0.32em] text-white/45">Édito · p. 04</p>
          <Quote className="mt-8 h-12 w-12 text-white/30" />
          <p className="mt-6 font-display text-4xl italic leading-tight tracking-[-0.04em] text-white/90">
            Un magazine n’est pas un produit. C’est un rendez-vous.
          </p>
        </aside>
        <article className="max-w-3xl">
          <h2 className="font-display text-5xl font-semibold leading-none tracking-[-0.06em] sm:text-7xl">
            Pourquoi nous publions ce magazine
          </h2>
          <div className="mt-10 space-y-7 text-lg leading-9 text-white/72">
            <p>AIME n’est pas un produit. AIME est un atelier. Un studio. Une presse. Nous fabriquons des machines, des timbres, des espaces, des mémoires. Nous fabriquons aussi un magazine.</p>
            <p>Ce premier numéro est une déclaration d’intention. Il dit qui nous sommes, pourquoi nous existons, et qui sont les esprits qui peuplent ce lieu.</p>
            <p>Nous croyons que la technologie peut être hospitalière. Qu’elle peut soigner les détails. Qu’elle peut tenir ensemble ce qui tend à se défaire.</p>
          </div>
          <p className="mt-10 text-sm uppercase tracking-[0.25em] text-white/45">Matt Mez · Direction</p>
        </article>
      </div>
    </section>
  );
}