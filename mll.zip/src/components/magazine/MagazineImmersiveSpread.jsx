import React from "react";

export default function MagazineImmersiveSpread() {
  return (
    <section className="relative min-h-screen overflow-hidden bg-black text-white">
      <img src="https://media.base44.com/images/public/69eeb34f81c5b83d17b25683/f70239705_generated_image.png" alt="L’équipe AIME au travail dans l’atelier" className="absolute inset-0 h-full w-full object-cover opacity-80" loading="lazy" />
      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent" />
      <div className="relative z-10 flex min-h-screen items-end px-5 py-12 sm:px-8 lg:px-12">
        <div className="max-w-2xl">
          <p className="text-xs uppercase tracking-[0.32em] text-white/55">L’atelier · p. 20</p>
          <p className="mt-5 font-display text-4xl italic leading-tight tracking-[-0.04em] sm:text-6xl">
            Dans l’atelier, un mardi de mai. La rédaction relit, taille, recoud.
          </p>
          <p className="mt-6 text-lg leading-8 text-white/65">Aucune page n’est jamais finie tant qu’on en parle encore.</p>
        </div>
      </div>
    </section>
  );
}