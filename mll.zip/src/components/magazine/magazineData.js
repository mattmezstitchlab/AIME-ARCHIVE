export const magazineChapters = [
  {
    id: "edito", number: "01", kicker: "Édito", title: "Une machine pour aimer mieux.",
    paragraphs: [
      "AIME n’est pas seulement un outil. C’est une manière de rendre lisible ce qui se perd quand les systèmes deviennent trop froids : l’intention, la mémoire, la responsabilité et la protection.",
      "Le magazine raconte cette architecture sans la rendre lourde. Il met en page une intuition simple : chaque parole sensible mérite une forme claire, un cadre humain, et une place juste entre le privé, le public et le scellé.",
      "À travers le Registre, le Studio Stamp, les agents et les espaces de transmission, AIME cherche moins à remplacer les humains qu’à protéger le moment où ils doivent décider, relire, transmettre ou demander de l’aide.",
    ],
    quote: "Aimer, ce n’est pas exposer. C’est protéger.",
    note: "Cette édition garde le contenu construit autour d’AIME Gardien, mais le présente comme une revue : chapitres courts, rythme visuel, lecture respirante.",
  },
  {
    id: "appel-citoyen", number: "02", kicker: "Appel citoyen", title: "Apaiser sans effacer.",
    paragraphs: [
      "AIME porte une idée de réconciliation : ne pas ajouter du bruit au bruit, ne pas transformer la douleur en spectacle, ne pas confondre visibilité et vérité.",
      "Dans les sujets sensibles, la première urgence est parfois de ralentir. Écrire, préparer, relire, distinguer ce qui relève d’un récit intime, d’une orientation, d’une transmission ou d’une alerte réelle.",
      "L’appel citoyen n’est pas un bloc manifeste isolé. C’est un principe de design : chaque bouton, chaque fiche, chaque agent doit réduire la violence du parcours et augmenter la clarté.",
    ],
    quote: "Calmer n’est pas minimiser. C’est rendre possible une parole juste.",
  },
  {
    id: "portrait", number: "03", kicker: "Portrait", title: "L’homme derrière la machine.",
    paragraphs: [
      "Derrière AIME, il y a une histoire de mémoire, de création et de réparation. Une volonté de transformer des fragments personnels en architecture utile, partageable, et suffisamment robuste pour protéger les autres.",
      "Le fondateur n’est pas présenté comme une figure héroïque, mais comme un chef d’orchestre : quelqu’un qui donne une place aux voix, aux agents, aux outils et aux silences.",
      "Le magazine conserve cette dimension intime, mais la traite avec sobriété : moins de grands blocs, plus de respiration, comme un article long où chaque section ouvre une porte.",
    ],
  },
  {
    id: "createur", number: "04", kicker: "Le créateur", title: "Mont Noir, mémoire familiale, transmission.",
    paragraphs: [
      "Le territoire intime d’AIME passe par la mémoire familiale, les lieux fondateurs, les livres, les traces et les objets qui gardent quelque chose de vivant quand les personnes ne peuvent plus tout porter seules.",
      "Cette mémoire ne devient pas un décor. Elle devient une méthode : classer sans assécher, protéger sans enfermer, transmettre sans surexposer.",
      "C’est ce qui rapproche AIME d’un magazine : une forme éditoriale capable de faire cohabiter récit, preuves, visuels, agents, manifeste et architecture.",
    ],
  },
  {
    id: "architecture", number: "05", kicker: "Architecture", title: "Registre, timbre, scellé.",
    paragraphs: [
      "L’architecture AIME tient en trois gestes : écrire une intention, préparer une fiche lisible, puis décider ce qui peut être vu, relu, transmis ou gardé privé.",
      "Le timbre n’est pas un gadget graphique. Il agit comme une marque de présence : un signe qui dit qu’une parole existe, mais qu’elle n’a pas forcément vocation à être exposée.",
      "Les agents organisent ce passage. Ils ne valident pas à la place d’un humain ; ils rendent la matière plus claire pour que la validation humaine reste possible et responsable.",
    ],
    quote: "Une architecture tient quand elle protège ce qu’elle contient.",
  },
  {
    id: "manifeste", number: "06", kicker: "Manifeste", title: "La mémoire est un acte.",
    paragraphs: [
      "Garder une mémoire, ce n’est pas seulement stocker une donnée. C’est décider de sa forme, de sa temporalité, de son niveau de visibilité, et de la personne qui pourra la relire demain.",
      "AIME défend une technologie qui ne pousse pas tout vers la publication. Certaines choses doivent être préparées, certaines doivent rester scellées, certaines doivent être transmises avec prudence.",
      "Le magazine devient alors le bon format : il ne simplifie pas à l’extrême, il compose. Il laisse une place aux textes, aux images, aux agents et aux silences.",
    ],
    quote: "Une mémoire n’est pas un stockage. C’est une promesse tenue dans le temps.",
  },
];