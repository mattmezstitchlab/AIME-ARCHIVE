import React from "react";
import { ArrowDownRight } from "lucide-react";
import { magazineChapters } from "@/components/magazine/magazineData";

export default function MagazineHeroContents() {
  const items = [...magazineChapters, { id: "atlas-complet", number: "08", kicker: "Index", title: "L’Atlas complet" }];
  return (
    <nav id="sommaire" aria-label="Sommaire du magazine" className="flex h-full min-h-0 flex-col bg-black text-white">
      <header className="border-b border-white/15 p-6 sm:p-8"><p className="text-[0.62rem] font-black uppercase tracking-[0.26em] text-white/55">AIME® Magazine · Sommaire</p><p className="mt-4 max-w-md text-sm leading-6 text-white/60">Parcourez les chapitres éditoriaux et les projets qui les accompagnent.</p></header>
      <div className="min-h-0 flex-1 overflow-y-auto">
        {items.map((item) => <a key={item.id} href={item.id === "atlas-complet" ? "#atlas-complet" : `#magazine-${item.id}`} className="group grid grid-cols-[3.5rem_1fr_auto] gap-4 border-b border-white/15 p-5 transition-colors hover:bg-white/10 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-white sm:p-6"><span className="font-display text-3xl font-semibold tracking-[-0.06em] text-white/25">{item.number}</span><span><span className="block text-[0.58rem] font-black uppercase tracking-[0.22em] text-white/45">{item.kicker}</span><span className="mt-1 block font-display text-xl font-semibold leading-tight tracking-[-0.04em] text-white sm:text-2xl">{item.title}</span></span><ArrowDownRight className="h-4 w-4 text-white/65 transition-transform group-hover:translate-x-1 group-hover:translate-y-1" /></a>) }
      </div>
    </nav>
  );
}