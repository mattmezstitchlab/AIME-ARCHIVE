import React from "react";
import { Link } from "react-router-dom";

const chapters = [
  {
    title: "De l’art à l’interface",
    text: "Son parcours traverse l’image, le saxophone, la scène, les cérémonies, les sites web, les applications, les registres, les outils d’entraide et les systèmes symboliques. Chaque forme semble différente, mais la question reste la même : comment transformer une intention fragile en forme claire, utile et transmissible ?"
  },
  {
    title: "AIME, architecture d’une intuition",
    text: "AIME n’est pas né comme une application classique. C’est une recherche sur la mémoire, les liens, les non-dits, et la manière dont une parole, une émotion, une situation ou un projet peuvent être structurés sans être trahis."
  },
  {
    title: "L’enfant, la mémoire, la libération",
    text: "Dans son travail de jeunesse, Matthieu s’est représenté enfant. Ce geste devient aujourd’hui une matrice : l’enfant comme origine, mémoire sensible, blessure possible, mais aussi figure de libération et de transmission."
  },
  {
    title: "L’IA comme achèvement, pas comme rupture",
    text: "L’intelligence artificielle ne remplace pas l’humain. Elle rend visible une recherche ancienne : transformer une phrase en projet, une présence en timbre, une mémoire en registre, une émotion en parcours. L’IA prépare. L’humain valide. L’intention donne le sens."
  }
];

export default function MagazineCreatorBiography() {
  return (
    <section id="createateur" className="scroll-mt-20 bg-stone-50 px-5 py-24 text-stone-950 sm:px-8 lg:px-12">
      <div className="mx-auto max-w-7xl">
        <div className="grid gap-12 lg:grid-cols-[0.9fr_1.1fr] lg:items-start">
          <div className="lg:sticky lg:top-12">
            <p className="text-xs uppercase tracking-[0.32em] text-stone-500">Le créateur · p. 12</p>
            <h2 className="mt-6 font-display text-6xl font-semibold leading-[0.9] tracking-[-0.07em] sm:text-8xl">
              Matthieu Laurent Lecointre.
            </h2>
            <p className="mt-7 max-w-xl text-xl leading-9 text-stone-600">
              Concepteur AIME, directeur artistique, musicien, architecte d’interfaces et chercheur d’intentions.
            </p>
          </div>

          <div className="space-y-10">
            <article className="rounded-[2.2rem] bg-black p-6 text-white sm:p-10">
              <p className="text-xs uppercase tracking-[0.28em] text-white/45">Depuis le Mont Noir</p>
              <h3 className="mt-5 font-display text-4xl font-semibold leading-tight tracking-[-0.05em] sm:text-6xl">
                Écrire contre le chaos.
              </h3>
              <div className="mt-7 space-y-5 text-base leading-8 text-white/72 sm:text-lg">
                <p>
                  Matthieu Laurent Lecointre, connu aussi sous le nom de Matt Mez, construit depuis plus de vingt ans un langage entre l’image, le son, la mémoire et l’interface.
                </p>
                <p>
                  Cette édition s’écrit au lendemain du 8 juin, date de naissance de Marguerite Yourcenar. Le lien n’est pas décoratif : vivre au Mont Noir, près de la villa où elle a grandi enfant, inscrit AIME dans un territoire de mémoire, de littérature, d’exil, de transmission et de responsabilité.
                </p>
                <p>
                  Dans une époque saturée de bruit, de crises, d’images, de récits fragmentés et de chaos social, AIME cherche une réponse calme : créer des formes qui protègent les présences, gardent les traces, orientent sans juger et transmettent sans déformer.
                </p>
              </div>
            </article>

            <div className="grid gap-4 md:grid-cols-2">
              {chapters.map((chapter) => (
                <article key={chapter.title} className="rounded-[1.8rem] border border-stone-200 bg-white p-6 shadow-sm">
                  <h3 className="font-display text-3xl font-semibold tracking-[-0.05em] text-stone-950">{chapter.title}</h3>
                  <p className="mt-4 text-sm leading-7 text-stone-600">{chapter.text}</p>
                </article>
              ))}
            </div>

            <article className="rounded-[2.2rem] border border-stone-300 bg-stone-100 p-6 sm:p-10">
              <p className="font-display text-3xl leading-tight tracking-[-0.04em] text-stone-950 sm:text-5xl">
                AIME donne une forme à ce qui cherche à naître, une mémoire à ce qui risque d’être oublié, une interface à ce qui n’avait pas encore de place.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <Link to="/registre-aime" className="rounded-full bg-stone-950 px-5 py-3 text-xs font-semibold uppercase tracking-[0.22em] text-white transition hover:bg-stone-800">
                  Voir le Registre
                </Link>
                <Link to="/stamp-studio" className="rounded-full border border-stone-300 px-5 py-3 text-xs font-semibold uppercase tracking-[0.22em] text-stone-950 transition hover:bg-white">
                  Créer un timbre
                </Link>
              </div>
            </article>
          </div>
        </div>
      </div>
    </section>
  );
}