import React from "react";

const chapters = [
  ["01", "L’origine", "Il n’a pas commencé par AIME. Il a commencé par un mariage. À la fin de cette journée-là, quelque chose lui a manqué : une architecture, la possibilité que tout ce qui avait été vécu reste vivant."],
  ["02", "L’idée du timbre", "Le timbre est venu en premier. Pas un reçu administratif : un sceau qui dit ceci a eu lieu, ceci compte, ceci est attesté."],
  ["03", "Pourquoi des agents", "Une seule application ne suffisait pas. Il fallait plusieurs machines, chacune avec son métier, son ton, son rythme — et derrière chaque machine, un esprit."],
  ["04", "Ce qu’il refuse", "Le bruit, l’optimisation pour l’optimisation, les notifications inutiles, les interfaces qui pressent et les machines qui prétendent comprendre sans demander."],
  ["05", "Le projet", "AIME est une architecture pour que les choses humaines tiennent. Un homme qui a refusé de laisser les choses se perdre."],
];

export default function MagazinePortrait() {
  return (
    <section className="bg-stone-50 px-5 py-24 text-stone-950 sm:px-8 lg:px-12">
      <div className="mx-auto grid max-w-7xl gap-12 lg:grid-cols-[0.9fr_1.1fr]">
        <div>
          <p className="text-xs uppercase tracking-[0.32em] text-stone-500">Portrait · p. 08</p>
          <h2 className="mt-6 font-display text-6xl font-semibold leading-none tracking-[-0.07em] sm:text-8xl">
            Portrait d’un homme qui voulait que les choses tiennent
          </h2>
          <p className="mt-8 max-w-xl text-lg leading-8 text-stone-600">
            Par l’équipe AIME · Photographies depuis l’atelier. L’histoire du fondateur racontée depuis l’intérieur de la machine.
          </p>
        </div>
        <div className="space-y-5">
          {chapters.map(([number, title, text]) => (
            <article key={number} className="rounded-[2rem] border border-stone-200 bg-white p-7 shadow-sm">
              <span className="font-display text-5xl tracking-[-0.08em] text-stone-300">{number}</span>
              <h3 className="mt-3 font-display text-3xl font-semibold tracking-[-0.05em]">{title}</h3>
              <p className="mt-4 text-base leading-8 text-stone-600">{text}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}