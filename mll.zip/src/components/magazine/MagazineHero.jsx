import React from "react";

const heroImageUrl = "https://media.base44.com/images/public/6a26f7e77a120b841e3ff78d/b82b1e20e_Gemini_Generated_Image_xkvvf8xkvvf8xkvv.png";

export default function MagazineHero() {
  return (
    <section className="relative flex h-[100svh] min-h-[36rem] w-full items-center justify-center overflow-hidden bg-black px-5 text-center text-white sm:px-8 lg:px-12">
      <img src={heroImageUrl} alt="Une mariée célébrée au cœur de ses invités" className="absolute inset-0 h-full w-full object-cover object-center" fetchPriority="high" />
      <div className="absolute inset-0 bg-black/25" aria-hidden="true" />
      <h1 className="relative z-10 max-w-6xl font-display text-4xl font-semibold leading-[0.92] tracking-[-0.06em] drop-shadow-2xl sm:text-6xl lg:text-8xl">Architecture intelligente de la mémoire ensemble.</h1>
    </section>
  );
}