import React from "react";

export default function MagazineAgentGrid({ agents }) {
  return (
    <section id="equipe" className="scroll-mt-20 bg-black px-5 py-24 text-white sm:px-8 lg:px-12">
      <div className="mx-auto max-w-7xl">
        <div className="grid gap-8 lg:grid-cols-[0.8fr_1.2fr] lg:items-end">
          <div>
            <p className="text-xs uppercase tracking-[0.32em] text-white/45">Intelligence collective · p. 14</p>
            <h2 className="mt-6 font-display text-6xl font-semibold leading-none tracking-[-0.07em] sm:text-8xl">Les agents AIME.</h2>
          </div>
          <p className="max-w-2xl text-lg leading-8 text-white/62">Un fondateur humain, six présences spécialisées. Chaque agent a une fonction claire : accueillir, orienter, classer, protéger, relier et sceller.</p>
        </div>

        <div className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {agents.map((agent, index) => (
            <article key={agent.name} className="group overflow-hidden border border-white/10 bg-white/[0.035]">
              <div className="aspect-[4/5] overflow-hidden bg-white/[0.03]">
                <img src={agent.image} alt={agent.name} className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" loading="lazy" />
              </div>
              <div className="p-6">
                <div className="flex items-center justify-between gap-4 text-[0.62rem] font-black uppercase tracking-[0.22em] text-white/42">
                  <span>{String(index + 1).padStart(2, "0")}</span>
                  <span>{agent.stamp}</span>
                </div>
                <h3 className="mt-5 font-display text-4xl font-semibold tracking-[-0.06em]">{agent.name}</h3>
                <p className="mt-2 text-xs font-semibold uppercase tracking-[0.18em] text-white/48">{agent.role}</p>
                <blockquote className="mt-6 text-lg leading-7 text-white/88">« {agent.quote} »</blockquote>
                <p className="mt-5 text-sm leading-7 text-white/58">{agent.text}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}