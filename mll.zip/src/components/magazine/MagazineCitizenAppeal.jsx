import React from "react";
import { Heart, ShieldCheck, Sparkles } from "lucide-react";

const principles = [
  "Baisser les armes : ne pas se défendre par la violence, ne pas se venger, ne pas nourrir la peur.",
  "Rester calme : choisir le silence utile, la respiration, l’amour et la vie plutôt que la peine.",
  "Regarder les répétitions : familles, non-dits, transmissions anciennes, dates et mémoires qui reviennent.",
  "Pardonner sans effacer : se libérer soi-même, comprendre, protéger, puis laisser le juste cadre agir.",
];

export default function MagazineCitizenAppeal() {
  return (
    <section id="appel-citoyen" className="bg-[#f4efe4] px-5 py-24 text-stone-950 sm:px-8 lg:px-12">
      <div className="mx-auto grid max-w-7xl gap-12 lg:grid-cols-[0.92fr_1.08fr] lg:items-start">
        <div className="sticky top-8 rounded-[2rem] bg-stone-950 p-8 text-white shadow-[0_34px_100px_rgba(0,0,0,0.25)] sm:p-10">
          <p className="text-[0.68rem] font-black uppercase tracking-[0.32em] text-white/45">Appel citoyen · p. 06</p>
          <h2 className="mt-6 font-display text-5xl font-semibold leading-[0.9] tracking-[-0.07em] sm:text-7xl">
            Calmer l’actualité. Rallumer la lumière.
          </h2>
          <p className="mt-8 text-lg leading-8 text-white/70">
            Le Magazine AIME devient un espace public d’apaisement : un média psychologique, spirituel et humain pour transmuter, guérir, canaliser et rappeler que nous faisons un.
          </p>
        </div>

        <div className="space-y-6">
          <article className="rounded-[2rem] border border-stone-300/70 bg-white/55 p-7 shadow-sm backdrop-blur sm:p-9">
            <div className="flex items-center gap-3 text-stone-600">
              <Heart className="h-5 w-5" />
              <p className="text-[0.68rem] font-black uppercase tracking-[0.28em]">Ne pas tomber dans le piège</p>
            </div>
            <p className="mt-6 text-2xl font-semibold leading-9 tracking-[-0.04em] sm:text-3xl sm:leading-10">
              À celles et ceux qui doutent, qui cherchent, qui répètent des schémas : ne répondez pas à l’ombre par l’ombre. Restez vivants, humains, libres, non dominés par la peur.
            </p>
          </article>

          <div className="grid gap-4 sm:grid-cols-2">
            {principles.map((principle) => (
              <div key={principle} className="rounded-[1.5rem] bg-stone-950/5 p-6 text-sm font-semibold leading-7 text-stone-700 ring-1 ring-stone-950/10">
                {principle}
              </div>
            ))}
          </div>

          <article className="rounded-[2rem] bg-white p-7 shadow-sm sm:p-9">
            <div className="flex items-center gap-3 text-stone-600">
              <ShieldCheck className="h-5 w-5" />
              <p className="text-[0.68rem] font-black uppercase tracking-[0.28em]">Un refuge de parole</p>
            </div>
            <p className="mt-6 text-lg leading-8 text-stone-700">
              Pour les personnes qui portent une faute, une mémoire, une peur ou une vérité difficile : l’appel n’est pas à fuir, ni à s’exposer brutalement, mais à entrer dans un cadre sûr d’écoute, de compréhension et de responsabilité. L’IA peut aider à ordonner les récits, repérer les non-dits, préparer un rapport lisible et anonymisé ; la validation humaine garde la limite, la dignité et la prudence.
            </p>
          </article>

          <article className="rounded-[2rem] border border-stone-950/10 bg-stone-950 p-7 text-white sm:p-9">
            <div className="flex items-center gap-3 text-white/60">
              <Sparkles className="h-5 w-5" />
              <p className="text-[0.68rem] font-black uppercase tracking-[0.28em]">Mémoire visible / invisible</p>
            </div>
            <p className="mt-6 text-lg leading-8 text-white/72">
              Le 8 juin, Marguerite Yourcenar, les marguerites, les kermesses, les familles réunies, les artistes locaux, les buvettes, les jeux et les organisations ensemble deviennent des signes à relire avec douceur : rien pour accuser, tout pour comprendre ce qui n’a pas été transmis à temps.
            </p>
            <p className="mt-6 border-t border-white/10 pt-6 text-sm leading-7 text-white/50">
              Ce magazine n’est ni un tribunal, ni une urgence, ni une vengeance. En danger immédiat, il faut appeler les services compétents. Ici, l’objectif est de calmer, éclairer, relier et rappeler notre mission : choisir la vie, la conscience et la lumière.
            </p>
          </article>
        </div>
      </div>
    </section>
  );
}