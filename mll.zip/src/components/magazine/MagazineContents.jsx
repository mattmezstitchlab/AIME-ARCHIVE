import React from "react";

const items = [
  ["01", "Édito", "Pourquoi AIME existe", "#edito"],
  ["02", "Appel citoyen", "Apaiser sans exposer", "#appel-citoyen"],
  ["03", "Portrait", "L’homme derrière la machine", "#portrait"],
  ["04", "Le créateur", "Mont Noir, mémoire familiale", "#createur"],
  ["05", "Agents", "Six présences spécialisées", "#equipe"],
  ["06", "Architecture", "Registre, timbre, scellé", "#architecture"],
  ["07", "Manifeste", "La mémoire est un acte", "#manifeste"],
];

export default function MagazineContents() {
  return (
    <section id="sommaire" className="bg-black px-5 py-20 text-white sm:px-8 lg:px-12">
      <div className="mx-auto max-w-7xl">
        <p className="text-xs uppercase tracking-[0.32em] text-white/45">Sommaire</p>
        <div className="mt-8 grid gap-3 md:grid-cols-2 lg:grid-cols-4">
          {items.map(([number, title, subtitle, href]) => (
            <a key={number} href={href} className="group min-h-44 border border-white/10 bg-white/[0.035] p-5 transition hover:border-white/35 hover:bg-white/[0.07]">
              <span className="font-display text-5xl tracking-[-0.08em] text-white/24 group-hover:text-white/50">{number}</span>
              <span className="mt-8 block text-xs font-black uppercase tracking-[0.24em] text-white/45">{title}</span>
              <h2 className="mt-2 font-display text-2xl font-semibold leading-none tracking-[-0.05em]">{subtitle}</h2>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}