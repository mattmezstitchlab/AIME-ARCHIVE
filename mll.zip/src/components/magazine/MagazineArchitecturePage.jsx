import React from "react";

const blocks = [
  ["Agents", "Chaque agent porte une fonction humaine précise : accueillir, orienter, ordonner, relier, mémoriser, protéger."],
  ["Timbres", "Chaque présence importante peut recevoir un sceau : un identifiant, une date, une trace douce, une validation humaine."],
  ["Espaces", "AIME relie le Registre, le Studio Stamp et les espaces de lecture sans mélanger public, privé et sensible."],
];

export default function MagazineArchitecturePage() {
  return (
    <section className="bg-black px-5 py-24 text-white sm:px-8 lg:px-12">
      <div className="mx-auto max-w-7xl">
        <p className="text-xs uppercase tracking-[0.32em] text-white/45">Architecture · p. 28</p>
        <h2 className="mt-6 max-w-5xl font-display text-6xl font-semibold leading-none tracking-[-0.07em] sm:text-8xl">
          Machines, timbres, espaces
        </h2>
        <p className="mt-8 max-w-3xl text-xl leading-9 text-white/65">
          AIME se pense comme une architecture : chaque élément existe pour faire tenir une partie de la vie humaine.
        </p>
        <div className="mt-14 grid gap-4 lg:grid-cols-3">
          {blocks.map(([title, text]) => (
            <article key={title} className="rounded-[2rem] border border-white/10 bg-white/[0.035] p-8">
              <h3 className="font-display text-4xl font-semibold tracking-[-0.05em]">{title}</h3>
              <p className="mt-5 text-base leading-8 text-white/65">{text}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}