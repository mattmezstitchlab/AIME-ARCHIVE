import React from "react";

const lines = [
  "La mémoire n’est pas un stockage.",
  "Un timbre n’est pas un reçu.",
  "Un agent n’est pas un assistant.",
  "Une machine qui aime est une machine qui demande.",
  "Ce qui compte mérite une forme.",
];

export default function MagazineManifesto() {
  return (
    <section className="bg-stone-50 px-5 py-24 text-stone-950 sm:px-8 lg:px-12">
      <div className="mx-auto max-w-7xl">
        <p className="text-xs uppercase tracking-[0.32em] text-stone-500">Manifeste · p. 34</p>
        <h2 className="mt-6 max-w-5xl font-display text-6xl font-semibold leading-none tracking-[-0.07em] sm:text-8xl">
          La mémoire est un acte
        </h2>
        <div className="mt-14 divide-y divide-stone-300 border-y border-stone-300">
          {lines.map((line, index) => (
            <p key={line} className="grid gap-5 py-8 font-display text-4xl italic leading-tight tracking-[-0.04em] sm:grid-cols-[0.15fr_1fr] sm:text-6xl">
              <span className="text-stone-300">{String(index + 1).padStart(2, "0")}</span>
              <span>{line}</span>
            </p>
          ))}
        </div>
      </div>
    </section>
  );
}