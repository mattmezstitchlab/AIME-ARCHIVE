import React from "react";
import { PROJECT_CATEGORIES } from "./projectConstants";

export default function FilterBar({ active, onChange }) {
  return (
    <div className="sticky top-0 z-20 border-y border-white/10 bg-background/80 px-5 py-4 backdrop-blur-xl sm:px-8 lg:px-12">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4">
        <span className="text-xs uppercase tracking-[0.24em] text-foreground">Filtrer</span>
        <label className="sr-only" htmlFor="project-category-filter">Filtrer les projets</label>
        <select
          id="project-category-filter"
          value={active}
          onChange={(event) => onChange(event.target.value)}
          className="min-h-11 w-full max-w-xs cursor-pointer rounded-full border border-white/20 bg-white/10 px-5 text-sm text-foreground backdrop-blur-xl transition-colors duration-200 hover:border-white/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          {PROJECT_CATEGORIES.map((category) => (
            <option key={category} value={category} className="bg-black text-white">
              {category}
            </option>
          ))}
        </select>
      </div>
    </div>
  );
}