import React from "react";
import { Link } from "react-router-dom";
import { ArrowUpRight } from "lucide-react";

export default function ProjectHero() {
  return (
    <header className="absolute inset-x-0 top-0 z-20 overflow-hidden px-5 py-5 sm:px-8 lg:px-12">
      <nav className="mx-auto flex max-w-7xl flex-col gap-4" aria-label="Navigation principale">
        <div className="flex items-start justify-between gap-5">
          <Link to="/" className="w-fit text-white">
            <span className="block font-display text-3xl font-semibold leading-none tracking-[-0.08em] sm:text-4xl">AI+ME</span>
          </Link>
          <Link to="/a-propos" className="inline-flex min-h-11 shrink-0 items-center gap-2 rounded-full border border-white/20 bg-black/25 px-4 text-xs font-medium text-white backdrop-blur-xl transition-colors hover:bg-white hover:text-black">À propos <ArrowUpRight className="h-4 w-4" /></Link>
        </div>
      </nav>
    </header>
  );
}