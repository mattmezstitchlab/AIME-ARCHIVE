import React from "react";
import { Link } from "react-router-dom";
import { Sparkles, Stamp, Layers, FileText } from "lucide-react";

const coverImageUrl = "https://media.base44.com/images/public/6a26f7e77a120b841e3ff78d/df196df8f_image.png";

const magazineIdeas = [
  { icon: <Stamp className="h-5 w-5 text-white" />, title: "Agents de protection", text: "Six figures AIME portent chacune une fonction : accueillir, orienter, ordonner, relier, mémoriser et sceller." },
  { icon: <Layers className="h-5 w-5 text-white" />, title: "Récit éditorial", text: "Le magazine raconte l’univers AIME sans tout expliquer : il donne une voix, une forme et un rythme aux projets reliés." },
  { icon: <FileText className="h-5 w-5 text-white" />, title: "Mémoire transmissible", text: "Chaque page peut devenir un support de preuve douce, de manifeste, de registre ou de présentation partenaire." },
];

export default function AimeMagazineSection() {
  return (
    <section className="relative z-10 border-y border-white/10 bg-black px-5 py-20 sm:px-8 lg:px-12">
      <div className="mx-auto max-w-7xl">
        <div className="grid gap-10 lg:grid-cols-[0.92fr_1.08fr] lg:items-end">
          <div>
            <p className="text-xs uppercase tracking-[0.28em] text-white/55">Magazine AIME — numéro 1</p>
            <h2 className="mt-5 font-display text-5xl font-semibold leading-[0.94] tracking-[-0.06em] text-white sm:text-7xl">
              Une couverture, des agents, une mémoire protégée.
            </h2>
            <p className="mt-7 text-lg leading-8 text-white/72">
              Le magazine devient la face éditoriale d’AIME : il met en scène les agents, explique la logique du Registre, relie le Studio Stamp et prépare les futurs projets autour de la mémoire, de la protection et de la transmission.
            </p>
          </div>
          <div className="overflow-hidden rounded-[2.4rem] border border-white/10 bg-white/[0.04] p-3 shadow-2xl shadow-black/40">
            <img src={coverImageUrl} alt="Couverture du magazine AIME avec l’équipe d’agents" className="aspect-square w-full rounded-[1.8rem] object-cover" loading="lazy" />
          </div>
        </div>

        <div className="mt-12 grid gap-4 lg:grid-cols-3">
          {magazineIdeas.map((item) => (
            <article key={item.title} className="rounded-[2rem] border border-white/10 bg-white/[0.035] p-6 backdrop-blur-xl">
              <div className="mb-8 inline-flex h-12 w-12 items-center justify-center rounded-full border border-white/15 bg-white/10">
                {item.icon}
              </div>
              <h3 className="font-display text-3xl font-semibold tracking-[-0.05em] text-white">{item.title}</h3>
              <p className="mt-4 text-sm leading-6 text-white/68">{item.text}</p>
            </article>
          ))}
        </div>

        <div className="mt-5 rounded-[2rem] border border-white/10 bg-white p-6 text-black sm:p-8">
          <div className="flex items-center gap-3 text-xs uppercase tracking-[0.24em] text-black/55">
            <Sparkles className="h-4 w-4" /> Ligne éditoriale
          </div>
          <p className="mt-4 max-w-4xl text-2xl leading-9 tracking-[-0.03em]">
            À garder comme colonne vertébrale : le Registre protège les présences, le Stamp Studio crée les scellés, le Magazine raconte l’architecture, et les futurs projets AIME prolongent cette même logique.
          </p>
          <Link to="/magazine" className="mt-7 inline-flex rounded-full bg-black px-5 py-3 text-xs font-semibold uppercase tracking-[0.22em] text-white transition hover:bg-black/80">
            Ouvrir le magazine
          </Link>
        </div>
      </div>
    </section>
  );
}