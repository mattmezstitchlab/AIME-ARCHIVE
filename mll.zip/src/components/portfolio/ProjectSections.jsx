import React from "react";
import ProjectCard from "@/components/portfolio/ProjectCard";

const projectOrder = (project) => project.display_order ?? 999;

export default function ProjectSections({ projects }) {
  const featured = projects.filter((project) => project.featured);
  const groups = projects.filter((project) => !project.featured).reduce((result, project) => {
    const category = project.category || "Autres projets";
    result[category] = [...(result[category] || []), project];
    return result;
  }, {});
  const sections = [
    ...(featured.length ? [{ title: "À la une", projects: featured }] : []),
    ...Object.entries(groups)
      .sort(([, first], [, second]) => projectOrder(first[0]) - projectOrder(second[0]))
      .map(([title, items]) => ({ title, projects: items })),
  ];

  return sections.map((section) => (
    <section key={section.title} className="mb-16" aria-labelledby={`section-${section.title}`}>
      <div className="mb-5 flex items-end justify-between px-5 sm:px-8 lg:px-12">
        <h3 id={`section-${section.title}`} className="font-display text-3xl font-semibold tracking-[-0.04em] text-white">{section.title}</h3>
        <span className="text-xs uppercase tracking-[0.22em] text-white/55">{section.projects.length} projets</span>
      </div>
      <div className="grid gap-0 sm:grid-cols-3">
        {section.projects.map((project, index) => <ProjectCard key={project.id} project={project} index={index} />)}
      </div>
    </section>
  ));
}