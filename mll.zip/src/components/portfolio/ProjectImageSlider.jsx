import React, { useMemo, useState } from "react";
import ImageFrame from "./ImageFrame";

export default function ProjectImageSlider({ project, visuals }) {
  const [active, setActive] = useState(0);
  const items = useMemo(() => visuals.filter((item) => item?.url).slice(0, 3), [visuals]);

  if (!items.length) return null;

  return (
    <section className="relative z-10 bg-black px-5 py-20 sm:px-8 lg:px-12">
      <div className="mx-auto max-w-7xl">
        <div className="mb-8 flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
          <div>
            <p className="text-xs uppercase tracking-[0.28em] text-white/45">Slides Atlas</p>
            <h2 className="mt-3 font-display text-4xl font-semibold tracking-[-0.05em] text-white">Trois vues pour lire le projet.</h2>
          </div>
          <p className="max-w-sm text-sm leading-6 text-white/58">Visuels reconstruits depuis le corpus Atlas pour remplacer les anciennes photos génériques.</p>
        </div>
        <ImageFrame src={items[active].url} alt={items[active].title || project.title} className="aspect-[16/10]" />
        <div className="mt-5 grid gap-3 sm:grid-cols-3">
          {items.map((item, index) => (
            <button key={`${item.url}-${index}`} onClick={() => setActive(index)} className={`rounded-[1.2rem] border p-3 text-left transition ${active === index ? "border-white/60 bg-white/12" : "border-white/10 bg-white/[0.04] hover:border-white/30"}`}>
              <span className="text-xs uppercase tracking-[0.22em] text-white/45">0{index + 1}</span>
              <p className="mt-2 text-sm font-semibold text-white">{item.title || `Vue ${index + 1}`}</p>
              {item.description && <p className="mt-2 line-clamp-2 text-xs leading-5 text-white/55">{item.description}</p>}
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}