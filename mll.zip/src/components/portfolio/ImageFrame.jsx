import React from "react";

export default function ImageFrame({ src, alt, className = "", imageClassName = "", priority = false }) {
  return (
    <div className={`relative overflow-hidden rounded-[2rem] border border-white/10 bg-gradient-to-br from-white/10 via-white/[0.03] to-transparent shadow-[0_30px_120px_rgba(0,0,0,0.7)] ${className}`}>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_0%,rgba(201,168,76,0.18),transparent_35%),linear-gradient(180deg,rgba(255,255,255,0.08),transparent)]" />
      {src ? (
        <img
          src={src}
          alt={alt}
          width="1400"
          height="900"
          loading={priority ? "eager" : "lazy"}
          fetchPriority={priority ? "high" : "auto"}
          className={`relative h-full w-full object-cover ${imageClassName}`}
        />
      ) : (
        <div className="relative flex min-h-[280px] items-center justify-center p-10 text-center">
          <div>
            <div className="mx-auto mb-5 h-16 w-16 rounded-full border border-accent/40 bg-accent/10" />
            <p className="font-display text-2xl text-foreground">Visuel à révéler</p>
            <p className="mt-2 text-sm text-muted-foreground">Ajoutez une capture depuis l'espace admin.</p>
          </div>
        </div>
      )}
    </div>
  );
}