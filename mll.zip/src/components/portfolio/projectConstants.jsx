export const PROJECT_CATEGORIES = [
  "Tous",
  "AIME",
  "Mariage",
  "Événementiel",
  "IA",
  "Institutionnel",
  "Accessibilité",
  "Musique",
  "Immobilier",
  "Intermittents",
  "Expérimental"
];

export const PROJECT_STATUSES = [
  "En production",
  "En développement",
  "Archivé",
  "Prototype"
];

export const ADMIN_ACCESS_KEY = "mattmezlab_admin_unlocked";
export const DEFAULT_ADMIN_CODE = "MEZLAB2026";

export const createSlug = (value = "") =>
  value
    .toString()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)+/g, "");

export const sortProjects = (projects = []) =>
  [...projects].sort((a, b) => {
    if (!!a.featured !== !!b.featured) return a.featured ? -1 : 1;
    return (a.display_order ?? 999) - (b.display_order ?? 999);
  });