import React, { useMemo } from "react";
import AtlasCategoryStory from "@/components/portfolio/AtlasCategoryStory";
import { CURATED_PROJECT_SLUGS } from "@/components/portfolio/projectCoherence";

export default function AtlasCategoryBrowser({ projects }) {
  const groups = useMemo(() => Object.entries(projects.filter((project) => !CURATED_PROJECT_SLUGS.includes(project.slug)).reduce((result, project) => {
    const category = project.category || "Autres projets";
    result[category] = [...(result[category] || []), project];
    return result;
  }, {})).sort(([, first], [, second]) => (first[0]?.display_order ?? 999) - (second[0]?.display_order ?? 999)), [projects]);

  return (
    <div className="w-full bg-black text-white">
      {groups.map(([category, items], index) => <AtlasCategoryStory key={category} category={category} projects={items} index={index} />)}
    </div>
  );
}