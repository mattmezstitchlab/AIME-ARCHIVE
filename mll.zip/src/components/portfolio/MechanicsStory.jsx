import React from "react";

const steps = [
  ["logic", "Logique du projet"],
  ["workflows", "Workflows"],
  ["user_roles", "Rôles utilisateurs"],
  ["ai_modules", "Modules IA"],
  ["automations", "Automatisations"],
  ["next_evolutions", "Prochaines évolutions"]
];

export default function MechanicsStory({ mechanics = {} }) {
  return (
    <section className="relative px-5 py-24 sm:px-8 lg:px-12 lg:py-36">
      <div className="absolute inset-0 -z-10 bg-[radial-gradient(circle_at_50%_20%,rgba(201,168,76,0.12),transparent_34%)]" />
      <div className="mx-auto max-w-7xl">
        <div className="sticky top-20 mb-20 max-w-3xl">
          <p className="text-sm uppercase tracking-[0.28em] text-accent">Voir la mécanique invisible</p>
          <h2 className="mt-6 font-display text-5xl font-semibold tracking-[-0.05em] text-foreground sm:text-6xl">
            Ce que l'interface ne montre pas au premier regard.
          </h2>
        </div>

        <div className="ml-auto grid max-w-4xl gap-8">
          {steps.map(([key, title], index) => (
            <article key={key} className="min-h-[48vh] rounded-[2rem] border border-white/10 bg-card/45 p-8 shadow-[0_30px_100px_rgba(0,0,0,0.35)] backdrop-blur-xl sm:p-10">
              <div className="mb-10 flex items-center justify-between gap-6">
                <span className="font-display text-6xl text-accent/40">0{index + 1}</span>
                <span className="rounded-full border border-white/10 px-4 py-2 text-xs uppercase tracking-[0.2em] text-muted-foreground">Système caché</span>
              </div>
              <h3 className="font-display text-4xl font-semibold tracking-[-0.04em] text-foreground">{title}</h3>
              <p className="mt-6 whitespace-pre-line text-lg leading-9 text-muted-foreground">
                {mechanics?.[key] || "Cette dimension sera documentée depuis l'espace admin."}
              </p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}