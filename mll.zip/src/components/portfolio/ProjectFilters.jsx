import React from "react";
import { Search } from "lucide-react";

export default function ProjectFilters({ categories, activeCategory, setActiveCategory, query, setQuery, total, shown }) {
  return (
    <div className="flex w-full flex-col gap-3 sm:flex-row sm:items-center">
      <select
        value={activeCategory}
        onChange={(event) => setActiveCategory(event.target.value)}
        className="min-h-11 w-full rounded-full border border-white/10 bg-black/45 px-4 text-sm font-semibold text-white outline-none backdrop-blur-xl focus:border-white/35 sm:w-72"
      >
        <option value="Tous">Tous les projets</option>
        <option value="Phares">Projets phares</option>
        {categories.map((category) => (
          <option key={category} value={category}>{category}</option>
        ))}
      </select>
      <label className="flex min-h-11 w-full items-center gap-3 rounded-full border border-white/10 bg-black/45 px-4 text-sm text-white/75 backdrop-blur-xl sm:w-80">
        <Search className="h-4 w-4 text-white/45" aria-hidden="true" />
        <input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Chercher un projet…"
          className="min-w-0 flex-1 bg-transparent outline-none placeholder:text-white/35"
        />
      </label>
    </div>
  );
}