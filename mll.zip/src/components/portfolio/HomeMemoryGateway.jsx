import React from "react";
import { Link } from "react-router-dom";
import { ArrowUpRight } from "lucide-react";

const coverImageUrl = "https://media.base44.com/images/public/69eeb34f81c5b83d17b25683/2a226f953_generated_image.png";

export default function HomeMemoryGateway() {
  return (
    <section className="relative z-10 border-y border-white/10 bg-black px-5 py-16 sm:px-8 lg:px-12">
      <div className="mx-auto grid max-w-7xl gap-8 lg:grid-cols-[0.9fr_1.1fr] lg:items-stretch">
        <div className="relative min-h-[24rem] overflow-hidden rounded-[2rem] border border-white/10 bg-stone-950 sm:min-h-[34rem]">
          <img src={coverImageUrl} alt="Visuel AIME Magazine" className="absolute inset-0 h-full w-full object-cover object-center" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-black/10" />
        </div>
        <div className="flex flex-col justify-between rounded-[2rem] border border-white/10 bg-white/[0.035] p-6 sm:p-8 lg:p-10">
          <div>
            <p className="text-xs uppercase tracking-[0.32em] text-white/45">Magazine · Registre · Timbres</p>
            <h2 className="mt-6 max-w-4xl font-display text-5xl font-semibold leading-[0.9] tracking-[-0.07em] text-white sm:text-7xl">
              Pour la mémoire, l’intention et la protection.
            </h2>
            <p className="mt-8 max-w-2xl text-lg leading-8 text-white/68">
              AIME relie l’éditorial, le registre et les timbres : raconter, structurer, orienter, sans jamais remplacer les humains ni les services officiels.
            </p>
          </div>
          <div className="mt-10 flex flex-wrap gap-3">
            <Link to="/magazine" className="inline-flex min-h-12 items-center gap-3 rounded-full bg-white px-6 text-sm font-medium text-black transition hover:bg-white/85">
              Accès magazine <ArrowUpRight className="h-4 w-4" />
            </Link>
            <Link to="/registre-aime" className="inline-flex min-h-12 items-center gap-3 rounded-full border border-white/15 px-6 text-sm text-white/80 transition hover:border-white/40">
              Accès registre <ArrowUpRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}