import React, { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowUpRight, X } from "lucide-react";
import ImageFrame from "./ImageFrame";

const compactText = (value = "", max = 430) => {
  const text = Array.isArray(value) ? value.join(" · ") : value;
  return text && text.length > max ? `${text.slice(0, max).trim()}…` : text;
};

export default function ProjectCard({ project, index = 0 }) {
  const [expanded, setExpanded] = useState(false);

  const synthesis = useMemo(() => compactText([
    project.short_description,
    project.long_description,
    project.problem && `Problème : ${project.problem}`,
    project.solution && `Solution : ${project.solution}`,
    project.features?.length ? `Fonctions : ${project.features.join(", ")}` : "",
    project.role && `Rôle : ${project.role}`,
    project.automation_level && `Automatisation : ${project.automation_level}`,
    project.accessibility_integrated && `Accessibilité : ${project.accessibility_integrated}`,
    project.possible_evolutions && `Évolutions : ${project.possible_evolutions}`,
  ].filter(Boolean).join(" ")), [project]);

  return (
    <article className="group h-full overflow-hidden border border-white/10 bg-black">
      {expanded ? (
        <div className="flex aspect-[4/5] flex-col justify-between bg-black p-5 text-white">
          <div>
            <div className="mb-5 flex items-center justify-between gap-3 text-xs uppercase tracking-[0.22em] text-white/70">
              <span>{project.category}</span>
              <button onClick={() => setExpanded(false)} className="rounded-full border border-white/15 p-2 transition-colors hover:border-white/50" aria-label="Fermer la synthèse">
                <X className="h-4 w-4" />
              </button>
            </div>
            <h2 className="font-display text-3xl font-semibold tracking-[-0.05em] text-white">{project.title}</h2>
            <p className="mt-5 text-sm leading-6 text-white/85">{synthesis}</p>
          </div>
          <Link to={`/projects/${project.slug}`} className="mt-6 inline-flex items-center gap-2 text-xs uppercase tracking-[0.22em] text-white/80 hover:text-white">
            Voir le projet <ArrowUpRight className="h-4 w-4" />
          </Link>
        </div>
      ) : (
        <>
          <Link to={`/projects/${project.slug}`} className="block focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
            <ImageFrame
              src={project.main_screenshot_url || project.gallery?.[0]?.url}
              alt={`Capture du projet ${project.title}`}
              className="aspect-[4/5] rounded-none border-0"
              imageClassName="scale-[1.9] transition-transform duration-700 group-hover:scale-[2]"
              priority={index < 4}
            />
          </Link>
          <button type="button" onClick={() => setExpanded(true)} className="block w-full bg-black p-4 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
            <div className="mb-3 flex items-center justify-between gap-3 text-xs text-white">
              <span>{project.category}</span>
              <span className="ml-auto">{project.featured ? `Projet phare · ${String(index + 1).padStart(2, "0")}` : ""}</span>
              <ArrowUpRight className="h-4 w-4 text-white" />
            </div>
            <h2 className="font-display text-2xl font-semibold tracking-[-0.04em] text-white">{project.title}</h2>
            <p className="mt-2 line-clamp-3 text-sm leading-5 text-white">{project.short_description}</p>
          </button>
        </>
      )}
    </article>
  );
}