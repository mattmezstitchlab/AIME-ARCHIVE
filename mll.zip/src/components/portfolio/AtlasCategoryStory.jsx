import React from "react";
import FeaturedProjectStory from "@/components/home-magazine/FeaturedProjectStory";

const editorialChapter = (category, projects, index) => {
  const lead = projects[0];
  const names = projects.slice(0, 4).map((project) => project.title).join(", ");
  return {
    id: `atlas-${index + 8}`,
    number: String(index + 8).padStart(2, "0"),
    kicker: `Atlas · ${String(projects.length).padStart(2, "0")} projets`,
    title: category,
    paragraphs: [
      `Cette famille éditoriale réunit ${projects.length} projet${projects.length > 1 ? "s" : ""} autour d’une même intention : rendre visible une pratique, une méthode et les usages qu’elle protège. ${names}.`,
      lead.long_description || lead.short_description || `Le projet ${lead.title} ouvre ce chapitre et donne une forme concrète à cette catégorie de l’Atlas.`,
      lead.solution || lead.problem || `Chaque fiche documente une réponse, son degré de maturité et les choix humains qui permettent de la faire évoluer sans perdre son intention initiale.`
    ],
    quote: lead.key_takeaway || "Chaque catégorie est un chapitre, chaque projet une preuve de travail."
  };
};

export default function AtlasCategoryStory({ category, projects, index }) {
  const chapter = editorialChapter(category, projects, index);
  return <FeaturedProjectStory project={projects[0]} chapter={chapter} related={projects.slice(1)} index={index + 7} />;
}