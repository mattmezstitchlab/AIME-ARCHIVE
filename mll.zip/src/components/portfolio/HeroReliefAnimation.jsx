import React, { useEffect, useRef } from "react";

export default function HeroReliefAnimation({ className = "" }) {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const context = canvas.getContext("2d");
    let animationFrame;
    let width = 0;
    let height = 0;
    let dpr = 1;
    let isVisible = true;

    const resize = () => {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      const bounds = canvas.getBoundingClientRect();
      width = Math.max(1, bounds.width);
      height = Math.max(1, bounds.height);
      canvas.width = width * dpr;
      canvas.height = height * dpr;
      context.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    const vortices = [
      { x: 0.18, y: 0.34, force: 1.8, radius: 250 },
      { x: 0.54, y: 0.36, force: -1.35, radius: 210 },
      { x: 0.36, y: 0.72, force: 1.25, radius: 230 },
      { x: 0.86, y: 0.14, force: -1.65, radius: 270 },
    ];

    const draw = (time) => {
      if (!isVisible) return;
      const t = time * 0.00028;
      context.fillStyle = "#000000";
      context.fillRect(0, 0, width, height);

      const step = width < 720 ? 16 : 13;
      const lineLength = width < 720 ? 7 : 9;

      for (let y = -30; y < height + 30; y += step) {
        for (let x = -30; x < width + 30; x += step) {
          const nx = x / width;
          const ny = y / height;
          let angle = Math.sin(nx * 11 + t * 1.8) * 0.8 + Math.cos(ny * 9 - t) * 0.65;
          let relief = 0;

          for (const vortex of vortices) {
            const cx = vortex.x * width + Math.sin(t * 2 + vortex.force) * 42;
            const cy = vortex.y * height + Math.cos(t * 1.6 + vortex.force) * 34;
            const dx = x - cx;
            const dy = y - cy;
            const distance = Math.hypot(dx, dy) || 1;
            const influence = Math.max(0, 1 - distance / vortex.radius);
            angle += Math.atan2(dy, dx) * influence * vortex.force;
            relief += influence * influence;
          }

          const wave = Math.sin(x * 0.018 + y * 0.012 + t * 5) * 0.5 + 0.5;
          const light = Math.min(1, relief * 0.9 + wave * 0.22);
          const alpha = 0.08 + light * 0.74;
          const red = Math.floor(70 + light * 130 + nx * 28);
          const blue = Math.floor(92 + light * 112 + (1 - ny) * 24);
          const white = Math.floor(105 + light * 132);
          const traitSeed = Math.sin(x * 12.9898 + y * 78.233) * 43758.5453;
          const traitNoise = traitSeed - Math.floor(traitSeed);
          const transmissionPath = x * 0.028 + y * 0.017 - t * 10;
          const transmission = traitNoise > 0.78
            ? Math.pow(Math.max(0, Math.sin(transmissionPath + traitNoise * 6.28)), 16) * 0.72
            : 0;
          const rainbowHue = (t * 170 + x * 0.24 + y * 0.12) % 360;

          const length = lineLength + relief * 10 + transmission * 1.2;
          const half = length / 2;
          const dx = Math.cos(angle) * half;
          const dy = Math.sin(angle) * half;

          context.beginPath();
          context.moveTo(x - dx, y - dy);
          context.lineTo(x + dx, y + dy);
          context.strokeStyle = transmission > 0.18
            ? `hsla(${rainbowHue}, 95%, ${58 + light * 24}%, ${Math.min(0.95, alpha + transmission * 0.42)})`
            : `rgba(218, 222, 232, ${Math.min(0.82, alpha)})`;
          context.lineWidth = 0.72 + relief * 1.1 + transmission * 1.4;
          context.lineCap = "round";
          context.stroke();
        }
      }

      context.fillStyle = "rgba(0, 0, 0, 0.34)";
      context.fillRect(0, 0, width, height);
      animationFrame = requestAnimationFrame(draw);
    };

    const resizeObserver = new ResizeObserver(resize);
    const visibilityObserver = new IntersectionObserver(([entry]) => {
      isVisible = entry.isIntersecting;
      if (isVisible && !animationFrame) animationFrame = requestAnimationFrame(draw);
      if (!isVisible && animationFrame) { cancelAnimationFrame(animationFrame); animationFrame = null; }
    });
    resize();
    resizeObserver.observe(canvas);
    visibilityObserver.observe(canvas);
    animationFrame = requestAnimationFrame(draw);

    return () => {
      resizeObserver.disconnect();
      visibilityObserver.disconnect();
      if (animationFrame) cancelAnimationFrame(animationFrame);
    };
  }, []);

  return <canvas ref={canvasRef} className={className} aria-hidden="true" />;
}