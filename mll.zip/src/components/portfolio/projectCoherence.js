export const CURATED_PROJECT_SLUGS = [
  "aime-marque",
  "notice",
  "atlas-base44-matt-mez",
  "maison-memoire",
  "aime-stamp-registry",
  "memorix"
];

export const projectVisual = (project) => project.main_screenshot_url || project.gallery?.[0]?.url || "";

export function dedupeProjects(projects) {
  const slugs = new Set();
  const visuals = new Set();
  return projects.filter((project) => {
    const slug = (project.slug || project.id || "").trim().toLowerCase();
    const visual = projectVisual(project);
    if ((slug && slugs.has(slug)) || (visual && visuals.has(visual))) return false;
    if (slug) slugs.add(slug);
    if (visual) visuals.add(visual);
    return true;
  });
}