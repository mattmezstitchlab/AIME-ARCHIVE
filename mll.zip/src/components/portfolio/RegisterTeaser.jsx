import React from "react";
import { Link } from "react-router-dom";
import { ArrowUpRight } from "lucide-react";
import RegisterStampCard from "@/components/registre/RegisterStampCard";

export default function RegisterTeaser() {
  return (
    <section className="relative z-10 border-y border-white/10 px-5 py-20 sm:px-8 lg:px-12">
      <div className="mx-auto grid max-w-7xl gap-12 lg:grid-cols-[1.05fr_0.95fr] lg:items-center">
        <div>
          <p className="text-xs uppercase tracking-[0.28em] text-white/55">Le Registre AIME — Les enfants devenus grands</p>
          <h2 className="mt-5 max-w-5xl font-display text-5xl font-semibold leading-[0.95] tracking-[-0.06em] text-white sm:text-7xl">
            Une porte pour la mémoire, l’intention et la protection.
          </h2>
          <p className="mt-7 max-w-3xl text-lg leading-8 text-white/78">
            Un espace public sobre pour annoncer le registre AIME : présence, charte, code, portrait gravé, visibilité choisie et validation humaine obligatoire.
          </p>
          <p className="mt-5 max-w-3xl rounded-2xl border border-white/10 p-5 text-sm leading-6 text-white/65">
            AIME ne remplace ni la justice, ni la police, ni les associations, ni les professionnels. L’IA écoute, clarifie et oriente ; l’humain valide.
          </p>
          <Link to="/registre-aime" className="mt-9 inline-flex min-h-12 items-center gap-3 rounded-full bg-white px-6 text-sm font-medium text-black transition-colors hover:bg-white/85">
            Découvrir le Registre AIME <ArrowUpRight className="h-4 w-4" />
          </Link>
        </div>
        <RegisterStampCard />
      </div>
    </section>
  );
}