import React from "react";

export default function PerforatedStamp({ imageUrl, code, width = 170 }) {
  return (
    <div
      className="stamp-perforated bg-stone-100 p-3 text-stone-950"
      style={{ width }}
    >
      <div className="overflow-hidden rounded-xl border border-stone-300 bg-stone-200">
        <img
          src={imageUrl}
          alt="Timbre AIME"
          className="h-36 w-full object-cover"
        />
      </div>
      <div className="mt-3 text-center">
        <p className="text-[8px] font-bold uppercase tracking-[0.34em] text-stone-500">AIME</p>
        <p className="mt-1 font-mono text-[10px] font-bold tracking-[0.18em] text-stone-800">{code}</p>
      </div>
    </div>
  );
}