import React from "react";
import { Lock } from "lucide-react";

const unknownText = "Information inconnue ou à préciser.";

export default function CapsuleToggle({
  enabled,
  onToggle,
  unlockDate,
  onUnlockDateChange,
  message,
  onMessageChange,
  disabled,
}) {
  return (
    <div
      className="mb-3 rounded-2xl px-3 py-2.5"
      style={{
        background: "#ede7dc",
        boxShadow: enabled
          ? "inset 4px 4px 10px #cfc6b8, inset -4px -4px 10px #fffaf0, 0 0 0 2px rgba(180,193,148,0.5)"
          : "inset 4px 4px 10px #cfc6b8, inset -4px -4px 10px #fffaf0",
      }}
    >
      <button
        type="button"
        onClick={() => !disabled && onToggle(!enabled)}
        disabled={disabled}
        className="flex min-h-11 w-full items-center justify-between text-stone-600 disabled:opacity-50"
      >
        <span className="flex items-center gap-2 text-[10px] font-semibold uppercase tracking-[0.3em]">
          <Lock className="h-3 w-3" strokeWidth={2} /> Capsule temporelle
        </span>
        <span className="relative inline-block" style={{ width: 30, height: 16 }}>
          <span className="absolute inset-0 rounded-full transition-colors" style={{ background: enabled ? "#a8b67d" : "#cdd1d8" }} />
          <span
            className="absolute top-0.5 h-3 w-3 rounded-full bg-white transition-all"
            style={{ left: enabled ? 14 : 2, boxShadow: "0 1px 2px rgba(0,0,0,0.25)" }}
          />
        </span>
      </button>

      {enabled && (
        <div className="mt-2.5 space-y-2">
          <input
            type="date"
            value={unlockDate || ""}
            onChange={(e) => onUnlockDateChange(e.target.value)}
            disabled={disabled}
            min={new Date().toISOString().split("T")[0]}
            className="w-full border-b border-stone-300 bg-transparent pb-1 text-xs text-stone-700 outline-none"
          />
          <textarea
            placeholder="Message scellé…"
            value={message || ""}
            onChange={(e) => onMessageChange(e.target.value)}
            disabled={disabled}
            rows={2}
            className="w-full resize-none bg-transparent text-xs text-stone-700 outline-none placeholder:text-stone-400"
          />
          <button
            type="button"
            onClick={() => onMessageChange(unknownText)}
            disabled={disabled}
            className="min-h-9 rounded-full border border-stone-300 px-3 text-[10px] font-semibold uppercase tracking-[0.18em] text-stone-600 transition-colors hover:bg-white disabled:opacity-50"
          >
            Je ne sais pas encore
          </button>
        </div>
      )}
    </div>
  );
}