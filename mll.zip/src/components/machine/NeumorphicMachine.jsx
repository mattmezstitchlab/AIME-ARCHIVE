import React, { useEffect, useRef, useState } from "react";
import { Upload, Loader2, Power, Sparkles } from "lucide-react";
import PerforatedStamp from "./PerforatedStamp";
import { playPrinterSound, playStampClick } from "@/lib/useMachineSound";
import { guardianAgents } from "@/components/home/AimeGuardianAgents";

const unknownText = "Information inconnue ou à préciser.";

const modes = {
  presence: ["Présence", "Mémoire, soutien, timbre public après validation."],
  manifesto: ["Manifeste", "Photo d’enfance, texte manifeste, charte signée."],
  protection: ["Protection", "Situation sensible, privé obligatoire."],
  pilot: ["Pilote", "Démonstrateur fermé, données fictives."],
};

const modeFrames = {
  presence: "Timbre de mémoire ou de soutien, visibilité possible seulement après validation humaine.",
  manifesto: "Timbre symbolique : présence autorisée, texte manifeste, charte signée et validation humaine.",
  protection: "Situation sensible : visibilité publique désactivée, fiche privée et relais essentiels rappelés.",
  pilot: "Démonstrateur fermé : données fictives, aucun cas réel, audit visible.",
};

export default function NeumorphicMachine({
  code,
  stampUrl,
  photoUrl,
  prompt,
  onPromptChange,
  onPhotoChange,
  onPrint,
  onNew,
  busy,
  printing,
  capsuleEnabled,
  onCapsuleToggle,
  capsuleDate,
  onCapsuleDateChange,
  capsuleMessage,
  onCapsuleMessageChange,
  mode = "presence",
  onModeChange,
  onRandom,
  onOpenSheet,
  clarityLevel,
  sensitiveLock = false,
  frameSignal = 0,
}) {
  const fileRef = useRef(null);
  const [focused, setFocused] = useState(false);
  const [activeAgent, setActiveAgent] = useState(null);
  const [showFrame, setShowFrame] = useState(false);

  useEffect(() => {
    if (frameSignal > 0) {
      setShowFrame(true);
      setActiveAgent(null);
    }
  }, [frameSignal]);

  const [modeLabel, modeLine] = modes[mode] || modes.presence;
  const agentText = activeAgent ? guardianAgents.find(([name]) => name === activeAgent)?.[1] : null;

  const handleFile = (event) => {
    const file = event.target.files?.[0];
    if (file) onPhotoChange(file);
  };

  useEffect(() => {
    if (busy) playPrinterSound(1200);
  }, [busy]);

  useEffect(() => {
    if (!stampUrl) return;
    playPrinterSound(1400);
    const timer = setTimeout(() => playStampClick(), 1250);
    return () => clearTimeout(timer);
  }, [stampUrl]);

  return (
    <div className="relative mx-auto w-full max-w-[430px] lg:w-[410px]">
      <div
        className="relative flex h-[680px] flex-col overflow-hidden rounded-[38px] border border-white/45 bg-[#f1eadf] bg-[radial-gradient(circle_at_25%_10%,rgba(255,255,255,0.82),transparent_26%),linear-gradient(135deg,rgba(255,255,255,0.36),transparent_45%)] p-4 text-stone-950 shadow-[0_28px_80px_rgba(0,0,0,0.5),inset_1px_1px_1px_rgba(255,255,255,0.7)] sm:h-[680px]"
      >
        <div className="flex items-center justify-between rounded-2xl bg-white/35 px-4 py-3 shadow-[inset_3px_3px_8px_#cfc6b8,inset_-3px_-3px_8px_#fffaf0]">
          <div>
            <p className="text-[9px] font-bold uppercase tracking-[0.32em] text-stone-500">AIME Gardien</p>
            <p className="mt-1 text-xs font-semibold text-stone-700">Le scellé avant le sceau.</p>
          </div>
          <div className="rounded-full bg-stone-950 px-3 py-1.5 font-mono text-[10px] font-bold tracking-[0.16em] text-[#f4efe4]">{code?.replace("AIME-", "")}</div>
        </div>

        <div className="mt-3 grid grid-cols-4 gap-1">
          {Object.entries(modes).map(([value, [label]]) => (
            <button
              key={value}
              type="button"
              onClick={() => onModeChange?.(value)}
              disabled={sensitiveLock && value !== "protection"}
              className={`min-h-8 rounded-full px-1.5 text-[8px] font-bold uppercase tracking-[0.1em] transition ${mode === value ? "bg-stone-950 text-[#f4efe4]" : "bg-white/45 text-stone-600 hover:bg-white/70"} ${sensitiveLock && value !== "protection" ? "cursor-not-allowed opacity-35" : ""}`}
            >
              {label}
            </button>
          ))}
        </div>

        <div className={`mt-3 rounded-[1.45rem] border p-3 shadow-[inset_4px_4px_10px_rgba(120,105,82,0.18),inset_-3px_-3px_8px_rgba(255,255,255,0.55)] ${mode === "protection" ? "border-amber-500/45 bg-[#eef2d8]" : "border-stone-300/60 bg-[#f7f0df]"}`}>
          <div className="mb-2 flex items-start justify-between gap-3">
            <div>
              <p className="font-mono text-[10px] font-bold uppercase tracking-[0.24em] text-stone-700/70">Mode {modeLabel}</p>
              <p className="mt-1 text-xs font-semibold leading-4 text-stone-900">{modeLine}</p>
            </div>
            <button type="button" onClick={() => setShowFrame(true)} className="flex-shrink-0 rounded-full bg-stone-950/85 px-3 py-2 text-[8px] font-bold uppercase tracking-[0.12em] text-[#f4efe4]">
              Voir le cadre du mode
            </button>
          </div>

          <div className="h-[140px] overflow-y-auto rounded-[1.05rem] border border-stone-900/10 bg-white/45 p-3">
            {showFrame ? (
              <div className="space-y-3">
                <p className="font-mono text-[10px] font-bold uppercase tracking-[0.22em] text-stone-600">Cadre du mode</p>
                <p className="text-sm leading-6 text-stone-800">{modeFrames[mode]}</p>
                <button type="button" onClick={() => setShowFrame(false)} className="rounded-full bg-stone-950 px-4 py-2 text-[10px] font-bold uppercase tracking-[0.18em] text-[#f4efe4]">Retour</button>
              </div>
            ) : agentText ? (
              <div className="flex min-h-full flex-col justify-center text-center">
                <p className="font-display text-4xl font-semibold tracking-[-0.06em] text-stone-950">{activeAgent}</p>
                <p className="mx-auto mt-4 max-w-xs text-base leading-7 text-stone-700">{agentText}</p>
              </div>
            ) : stampUrl ? (
              <div className="flex min-h-full flex-col items-center justify-center gap-3">
                <PerforatedStamp imageUrl={stampUrl} code={code} width={156} />
                <p className="text-center text-[10px] font-bold uppercase tracking-[0.2em] text-stone-600">{printing ? "Sortie du timbre" : "Timbre prêt à relire"}</p>
              </div>
            ) : (
              <div className="space-y-2">
                <p className="font-mono text-[10px] font-bold uppercase tracking-[0.22em] text-stone-600">3 actions</p>
                <ol className="space-y-1 text-xs leading-5 text-stone-800">
                  <li>1. Choisir un mode.</li>
                  <li>2. Écrire ou importer.</li>
                  <li>3. Générer une fiche / timbre.</li>
                </ol>
                <div className="rounded-2xl bg-white/55 p-3 text-xs leading-5 text-stone-700">
                  {sensitiveLock ? (
                    <div>
                      <p className="font-bold text-amber-800">Cette situation relève du Mode Protection. Privé obligatoire. Aucune publication.</p>
                      <p className="mt-1 font-mono text-[11px] text-stone-700">Relais essentiels : 17 / 112 / 114 / 119</p>
                    </div>
                  ) : (
                    <>
                      {mode === "protection" && "Privé obligatoire. Aucune publication."}
                      {mode === "pilot" && "Données fictives. Aucun cas réel."}
                      {mode === "manifesto" && "Photo d’enfance, portrait gravé ou présence sans visage."}
                      {mode === "presence" && "Mémoire, soutien, trace symbolique."}
                    </>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="mt-3">
          <p className="mb-1.5 text-center text-[8px] font-bold uppercase tracking-[0.28em] text-stone-500">Calibration</p>
          <div className="grid grid-cols-6 gap-1">
            {guardianAgents.map(([name], index) => (
              <button
                key={name}
                type="button"
                onClick={() => {
                  setActiveAgent(activeAgent === name ? null : name);
                  setShowFrame(false);
                }}
                className={`flex h-8 items-center justify-center rounded-full text-[8px] font-bold ${activeAgent === name ? "bg-stone-950 text-[#f4efe4]" : "bg-white/45 text-stone-600"}`}
                title={name}
              >
                {index + 1}
              </button>
            ))}
          </div>

        </div>

        <div className="mt-3 rounded-2xl bg-[#eee8dc] px-4 py-2.5 shadow-[inset_4px_4px_10px_#cfc6b8,inset_-4px_-4px_10px_#fffaf0]">
          <div className="flex items-center gap-2">
            <input
              type="text"
              placeholder="Écrire avec vos mots…"
              value={prompt}
              onChange={(event) => onPromptChange(event.target.value)}
              onFocus={() => setFocused(true)}
              onBlur={() => setFocused(false)}
              disabled={busy}
              className="flex-1 bg-transparent text-sm text-stone-700 outline-none placeholder:text-stone-400"
            />
            {onRandom && (
              <button type="button" onClick={onRandom} disabled={busy} aria-label="Suggestion" className={`flex h-8 w-8 items-center justify-center rounded-full bg-white/65 text-stone-600 ${focused ? "ring-2 ring-stone-300" : ""}`}>
                <Sparkles className="h-4 w-4" />
              </button>
            )}
          </div>
        </div>

        <div className="mt-2 rounded-2xl bg-white/35 px-4 py-1.5 text-[9px] font-semibold uppercase tracking-[0.16em] text-stone-500">
          Capsule temporelle compacte · {sensitiveLock ? "verrou privé actif" : "prête dans la fiche"}
        </div>

        <div className="mt-auto rounded-2xl bg-white/45 px-3 py-2 text-[10px] leading-4 text-stone-700">
          <div className="grid grid-cols-4 gap-1">
            <p><span className="text-stone-500">Mode</span><br />{modeLabel}</p>
            <p><span className="text-stone-500">Statut</span><br />Brouillon</p>
            <p><span className="text-stone-500">Clarté</span><br />{clarityLevel}</p>
            <p><span className="text-stone-500">Export</span><br />Privé</p>
          </div>
        </div>

        <div className="mt-3 grid grid-cols-[auto_1fr_auto] gap-2">
          <button onClick={() => fileRef.current?.click()} disabled={busy} aria-label="Importer" className="flex h-10 w-10 items-center justify-center rounded-full bg-[#eee8dc] text-stone-500 shadow-[5px_5px_11px_#cfc6b8,-5px_-5px_11px_#fffaf0]">
            {photoUrl ? <img src={photoUrl} alt="" className="h-8 w-8 rounded-full object-cover" /> : <Upload className="h-4 w-4" />}
            <input ref={fileRef} type="file" accept="image/*" onChange={handleFile} className="hidden" />
          </button>
          <button onClick={onPrint} disabled={busy} className="min-h-10 rounded-full bg-stone-950 px-3 text-[10px] font-bold uppercase tracking-[0.12em] text-[#f4efe4] shadow-[0_12px_30px_rgba(0,0,0,0.25)]">
            {busy ? <Loader2 className="mx-auto h-4 w-4 animate-spin" /> : sensitiveLock ? "Préparer fiche privée" : "Transformer en timbre AIME"}
          </button>
          <button onClick={onNew} disabled={busy} aria-label="Réinitialiser" className="flex h-10 w-10 items-center justify-center rounded-full bg-[#eee8dc] text-stone-500 shadow-[5px_5px_11px_#cfc6b8,-5px_-5px_11px_#fffaf0]">
            <Power className="h-4 w-4" />
          </button>
          <button onClick={() => onPromptChange(unknownText)} disabled={busy} className="col-span-2 min-h-8 rounded-full bg-white/55 px-4 text-[10px] font-bold uppercase tracking-[0.14em] text-stone-600">Je ne sais pas encore</button>
          <button onClick={onOpenSheet} className="min-h-8 rounded-full bg-white/55 px-3 text-[10px] font-bold uppercase tracking-[0.12em] text-stone-600">Voir la fiche</button>
        </div>

        <p className="mt-2 text-center text-[10px] font-semibold leading-4 text-stone-500">Le scellé avant le sceau. L’IA prépare. L’humain valide. Rien n’est transmis automatiquement.</p>
      </div>
    </div>
  );
}