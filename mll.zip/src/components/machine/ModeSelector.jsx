import React from "react";

const modes = [
  { value: "classic", label: "Classique" },
  { value: "map", label: "Carte" },
];

export default function ModeSelector({ mode, onChange, disabled }) {
  return (
    <div className="mb-3 grid grid-cols-2 gap-2">
      {modes.map((item) => (
        <button
          key={item.value}
          type="button"
          disabled={disabled}
          onClick={() => onChange(item.value)}
          className="rounded-full px-3 py-2 text-[9px] font-semibold uppercase tracking-[0.28em] transition disabled:opacity-50"
          style={{
            color: mode === item.value ? "#1f2937" : "#78716c",
            background: "#e6e9ef",
            boxShadow:
              mode === item.value
                ? "inset 3px 3px 7px #c5c8cd, inset -3px -3px 7px #ffffff"
                : "4px 4px 8px #c5c8cd, -4px -4px 8px #ffffff",
          }}
        >
          {item.label}
        </button>
      ))}
    </div>
  );
}