import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Send } from "lucide-react";
import EventRequestFields from "@/components/contact/EventRequestFields";

const inputClass = "min-h-12 w-full rounded-2xl border border-white/10 bg-white/[0.06] px-4 text-white placeholder:text-white/35 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white";
const labels = { projet_similaire: "Créer un projet similaire", evenement: "Événement · Saxophoniste / musicien", collaboration: "Collaboration", information: "Demande d’information", autre: "Autre" };

export default function ContactRequestForm({ projectTitle, projectSlug, onSent }) {
  const [sending, setSending] = useState(false);
  const [error, setError] = useState("");
  const [form, setForm] = useState({ name: "", email: "", phone: "", reason: projectTitle ? "projet_similaire" : "information", project_title: projectTitle, project_slug: projectSlug, message: projectTitle ? `Bonjour Matthieu, j’aimerais créer un projet similaire à ${projectTitle}.` : "", event_date: "", event_time: "", event_type: "", venue_name: "", venue_address: "", city: "", guest_count: "", performance_details: "", budget: "" });
  const update = (field, value) => setForm((current) => ({ ...current, [field]: value }));

  const submit = async (event) => {
    event.preventDefault();
    setSending(true);
    setError("");
    const payload = { ...form, guest_count: form.guest_count ? Number(form.guest_count) : undefined, status: "nouveau" };
    try {
      await base44.entities.ContactMessage.create(payload);
      const details = Object.entries(payload).filter(([, value]) => value !== "" && value !== undefined).map(([key, value]) => `${key} : ${value}`).join("\n");
      await base44.integrations.Core.SendEmail({ to: "matthieu.lecointre@gmail.com", subject: `[AIME] ${labels[form.reason]} — ${form.name}`, body: `Une nouvelle demande est disponible dans l’espace admin.\n\n${details}` });
      onSent();
    } catch (submissionError) {
      setError("La demande n’a pas pu être envoyée. Vérifiez les informations puis réessayez.");
    } finally {
      setSending(false);
    }
  };

  return (
    <form onSubmit={submit} className="space-y-4">
      <label><span className="mb-2 block text-xs text-white/60">Raison du message</span><select className={inputClass} value={form.reason} onChange={(e) => update("reason", e.target.value)}>{Object.entries(labels).map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select></label>
      <div className="grid gap-4 sm:grid-cols-2"><input className={inputClass} value={form.name} onChange={(e) => update("name", e.target.value)} placeholder="Nom" required /><input className={inputClass} type="email" value={form.email} onChange={(e) => update("email", e.target.value)} placeholder="Email" required /></div>
      <input className={inputClass} value={form.phone} onChange={(e) => update("phone", e.target.value)} placeholder="Téléphone" />
      {form.reason === "evenement" && <EventRequestFields form={form} update={update} />}
      {form.reason === "projet_similaire" && <input className={inputClass} value={form.project_title} onChange={(e) => update("project_title", e.target.value)} placeholder="Projet de référence" />}
      <textarea className={`${inputClass} min-h-40 py-4`} value={form.message} onChange={(e) => update("message", e.target.value)} placeholder={form.reason === "evenement" ? "Précisions, déroulé et attentes pour la prestation" : "Votre message"} required />
      {error && <p className="rounded-2xl border border-white/15 bg-white/[0.06] p-4 text-sm text-white/75">{error}</p>}
      <button disabled={sending} className="inline-flex min-h-12 w-full items-center justify-center gap-3 rounded-full bg-white px-6 text-sm font-medium text-black hover:bg-white/85 disabled:opacity-60">{sending ? "Envoi…" : "Envoyer la demande"} <Send className="h-4 w-4" /></button>
    </form>
  );
}