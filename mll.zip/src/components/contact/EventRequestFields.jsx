import React from "react";

const inputClass = "min-h-12 w-full rounded-2xl border border-white/10 bg-white/[0.06] px-4 text-white placeholder:text-white/35 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white";

export default function EventRequestFields({ form, update }) {
  return (
    <div className="grid gap-4 rounded-[1.5rem] border border-white/10 bg-white/[0.04] p-4 sm:grid-cols-2">
      <p className="sm:col-span-2 text-xs uppercase tracking-[0.22em] text-white/50">Prestation saxophoniste · musicien</p>
      <label><span className="mb-2 block text-xs text-white/60">Date</span><input type="date" className={inputClass} value={form.event_date} onChange={(e) => update("event_date", e.target.value)} required /></label>
      <label><span className="mb-2 block text-xs text-white/60">Horaire</span><input type="time" className={inputClass} value={form.event_time} onChange={(e) => update("event_time", e.target.value)} /></label>
      <label><span className="mb-2 block text-xs text-white/60">Type d’événement</span><select className={inputClass} value={form.event_type} onChange={(e) => update("event_type", e.target.value)} required><option value="">Sélectionner</option><option>Mariage</option><option>Anniversaire</option><option>Soirée privée</option><option>Événement d’entreprise</option><option>Cocktail</option><option>Festival</option><option>Autre</option></select></label>
      <label><span className="mb-2 block text-xs text-white/60">Nombre d’invités</span><input type="number" min="1" className={inputClass} value={form.guest_count} onChange={(e) => update("guest_count", e.target.value)} placeholder="Ex. 120" /></label>
      <input className={inputClass} value={form.venue_name} onChange={(e) => update("venue_name", e.target.value)} placeholder="Nom du lieu" />
      <input className={inputClass} value={form.city} onChange={(e) => update("city", e.target.value)} placeholder="Ville" required />
      <input className={`${inputClass} sm:col-span-2`} value={form.venue_address} onChange={(e) => update("venue_address", e.target.value)} placeholder="Adresse complète de la prestation" required />
      <input className={inputClass} value={form.budget} onChange={(e) => update("budget", e.target.value)} placeholder="Budget indicatif" />
      <input className={inputClass} value={form.performance_details} onChange={(e) => update("performance_details", e.target.value)} placeholder="Durée, ambiance, morceaux souhaités…" />
    </div>
  );
}