import { createClientFromRequest } from 'npm:@base44/sdk@0.8.38';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    const { message_id: messageId } = await req.json();
    if (!messageId) return Response.json({ error: 'message_id is required' }, { status: 400 });

    const message = await base44.asServiceRole.entities.ContactMessage.get(messageId);
    if (!message) return Response.json({ error: 'Contact request not found' }, { status: 404 });
    const reasons = { projet_similaire: 'Projet numérique', evenement: 'Événement · Musique', collaboration: 'Collaboration', information: 'Information', autre: 'Autre' };
    const rows = [
      ['Nom', message.name], ['Email', message.email], ['Téléphone', message.phone],
      ['Motif', reasons[message.reason] || message.reason], ['Projet', message.project_title],
      ['Date', message.event_date], ['Horaire', message.event_time], ['Événement', message.event_type],
      ['Lieu', [message.venue_name, message.venue_address, message.city].filter(Boolean).join(', ')],
      ['Invités', message.guest_count], ['Prestation', message.performance_details],
      ['Budget', message.budget], ['Message', message.message]
    ].filter(([, value]) => value !== undefined && value !== null && value !== '');
    const body = `Une nouvelle demande confirmée est disponible dans l’espace admin.\n\n${rows.map(([label, value]) => `${label} : ${value}`).join('\n')}`;

    await base44.asServiceRole.integrations.Core.SendEmail({
      to: 'matthieu.lecointre@gmail.com',
      subject: `[AIME] ${reasons[message.reason] || 'Nouvelle demande'} — ${message.name}`,
      body
    });
    return Response.json({ success: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});