Deno.serve(async (req) => {
  try {
    const payload = await req.json();
    const url = payload?.url;

    if (!url || typeof url !== "string") {
      return Response.json({ error: "URL requise" }, { status: 400 });
    }

    const parsedUrl = new URL(url.startsWith("http") ? url : `https://${url}`);
    const response = await fetch(parsedUrl.toString(), {
      headers: {
        "User-Agent": "MattMezLabPreviewBot/1.0"
      }
    });
    const html = await response.text();

    const titleMatch = html.match(/<title[^>]*>([^<]*)<\/title>/i);
    const descriptionMatch = html.match(/<meta[^>]+name=["']description["'][^>]+content=["']([^"']*)["']/i)
      || html.match(/<meta[^>]+property=["']og:description["'][^>]+content=["']([^"']*)["']/i);
    const imageMatch = html.match(/<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']*)["']/i);

    const clean = (value) => (value || "").replace(/\s+/g, " ").trim();
    const title = clean(titleMatch?.[1]) || parsedUrl.hostname.replace(/^www\./, "");
    const shortDescription = clean(descriptionMatch?.[1]) || `Une capsule digitale issue de ${parsedUrl.hostname.replace(/^www\./, "")}.`;
    const hostnameParts = parsedUrl.hostname.replace(/^www\./, "").split(".").filter(Boolean);
    const suggestedTags = Array.from(new Set([
      hostnameParts[0],
      "interface",
      "système",
      "expérience"
    ].filter(Boolean)));

    let mainScreenshotUrl = clean(imageMatch?.[1]) || "";
    if (mainScreenshotUrl && mainScreenshotUrl.startsWith("/")) {
      mainScreenshotUrl = `${parsedUrl.origin}${mainScreenshotUrl}`;
    }

    return Response.json({
      title,
      short_description: shortDescription.slice(0, 260),
      tags: suggestedTags,
      dominant_color: "#C9A84C",
      main_screenshot_url: mainScreenshotUrl,
      api_configured: false,
      screenshot_status: "fallback_metadata_only",
      message: "Métadonnées récupérées. La capture automatique nécessitera une API externe configurée côté backend."
    });
  } catch (error) {
    return Response.json({
      error: error.message,
      api_configured: false,
      message: "Impossible d'analyser cette URL. Utilisez le champ image URL manuel ou l'upload."
    }, { status: 500 });
  }
});