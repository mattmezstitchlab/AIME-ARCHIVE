import { createClientFromRequest } from 'npm:@base44/sdk@0.8.38';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const payload = await req.json();
    const projectTitle = typeof payload?.projectTitle === 'string' ? payload.projectTitle.trim() : '';
    const direction = typeof payload?.direction === 'string' ? payload.direction.trim() : '';
    const existingImageUrls = Array.isArray(payload?.existingImageUrls) ? payload.existingImageUrls.filter(Boolean).slice(0, 3) : [];

    if (!projectTitle || !direction) {
      return Response.json({ error: 'Le titre du projet et la direction visuelle sont requis.' }, { status: 400 });
    }

    const prompt = `Créer un visuel photographique ultra-réaliste pour le portfolio professionnel du projet « ${projectTitle} ». ${direction}. Montrer une utilisation humaine crédible du produit dans un environnement réel, avec une interface lisible sur un appareil contemporain, une lumière naturelle cinématographique, des proportions réalistes et aucun texte inventé en gros plan. Composition éditoriale premium, sobre, crédible, sans rendu 3D artificiel ni esthétique publicitaire générique.`;

    const result = await base44.integrations.Core.GenerateImage({
      prompt,
      existing_image_urls: existingImageUrls.length ? existingImageUrls : null
    });

    return Response.json({ url: result.url, prompt });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});