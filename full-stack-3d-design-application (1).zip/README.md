# LE MONDE AIME

> Réseau citoyen de dons, de collectes et de relais solidaires — prototype interactif.

Chaque don devient une **boîte virtuelle 3D** : cartons, boîtes à chaussures, ou
**cubes cristallins** pour les dons immatériels (énergie, temps, compétences,
expériences). Une **carte postale vivante** avec timbre accompagne chaque geste,
et les associations proches peuvent repérer les dons, activer des relais et
suivre l'activité.

⚠️ **Statut : prototype / bêta technique.** À ne pas exposer publiquement avec de
vraies données personnelles en l'état (voir la section « Limites connues »).

---

## Stack

- **Next.js 16** (App Router) + **React 19**
- **PostgreSQL** via **Drizzle ORM**
- **Three.js** (scène 3D tactile, cubes iridescents)
- **Tailwind CSS v4**
- **TypeScript**

---

## Démarrage local

### 1. Prérequis
- Node.js 20+
- Une base PostgreSQL accessible

### 2. Installation

```bash
npm install
cp .env.example .env      # puis renseignez DATABASE_URL
```

### 3. Base de données

```bash
npx drizzle-kit push      # crée les tables
```

Les données de démonstration (boîtes, cube, dons, utilisateurs) sont insérées
automatiquement au premier chargement via `ensureSeeded()`.

### 4. Lancement

```bash
npm run dev               # développement
# ou
npm run build && npm start # production
```

- Landing : `http://localhost:3000/`
- Atelier interactif : `http://localhost:3000/atelier`

---

## Scripts

| Commande | Rôle |
|----------|------|
| `npm run dev` | Serveur de développement |
| `npm run build` | Build de production |
| `npm start` | Serveur de production |
| `npm run lint` | ESLint |
| `npx drizzle-kit push` | Applique le schéma à la base |

---

## Architecture

```
src/
  app/
    page.tsx                 # Landing (hero, démo cube, concept)
    atelier/page.tsx         # Application interactive
    api/                     # Routes API (boxes, studio, auth, health…)
  components/
    Atelier3DScene.tsx       # Moteur 3D (cartons, shoebox, cube iridescent)
    app/                     # Header, sidebar, dock, inspecteur, modales
    landing/                 # Démos 3D de la landing
  db/                        # Schéma Drizzle + connexion
  lib/                       # Seed, auth, tampons partagés
docs/
  interface-architecture.md  # Règles d'architecture d'interface
```

---

## Limites connues (avant mise en production)

Ce dépôt est un prototype. Avant un usage réel :

- **Authentification** : mots de passe en clair, sessions non sécurisées, pas de
  contrôle de propriété → à remplacer par une vraie solution (Auth.js + hachage).
- **Médias** : photos/vidéos encodées en base64 → à déplacer vers un stockage
  objet (S3 / R2).
- **Géolocalisation** : points de collecte en texte libre → pas de carte ni de
  recherche par distance.
- **Relais** : déclaratif uniquement, pas de mise en relation réelle.
- **Cycle de vie des dons** : la remise supprime la boîte → à remplacer par des
  statuts (disponible / réservé / remis / archivé).
- **Timbre** : génération graphique (Canvas), pas d'IA malgré le champ « prompt ».
- **Impression** : `window.print()`, pas de PDF calibré 15 × 10 cm.

---

## Licence

Voir le fichier [LICENSE](./LICENSE).
