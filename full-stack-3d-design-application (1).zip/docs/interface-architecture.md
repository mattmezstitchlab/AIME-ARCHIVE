# LE MONDE AIME — Architecture d’interface

## Principe produit

La boîte virtuelle est la source de vérité. Elle contient le don, sa photo, son état, son histoire, son point de collecte, son relais éventuel et ses compléments documentaires.

La scène 3D reste le contenu principal. L’interface ne la recouvre pas avec des outils concurrents.

## Arborescence d’interface

```text
src/
  app/
    page.tsx                         # État, orchestration et appels API
    globals.css                      # Tokens et primitives visuelles
    layout.tsx                       # Polices et métadonnées
  components/
    Atelier3DScene.tsx               # Moteur tactile 3D
    AuthModal.tsx                    # Profils citoyens et associations
    PasseportSolidaireModal.tsx      # Registre des participations
    ShippingLabelModal.tsx           # Fiche publique imprimable
    app/
      AppHeader.tsx                  # Identité, métriques, profil
      AppSidebar.tsx                 # Navigation primaire
      CommandDock.tsx                # Capsule de commandes
      BoxInspector.tsx               # Lecture et actions d’une boîte
      DonationModals.tsx             # Création boîte et ajout don
      PostcardComposer.tsx            # Complément contextuel carte + timbre
```

## Zones fixes

1. **Header** — identité, deux métriques utiles, profil actif.
2. **Rail gauche** — Explorer, Citoyens, Associations, Relais, Activité, Passeport.
3. **Scène centrale** — boîtes 3D et interactions tactiles.
4. **Inspecteur droit** — identité, collecte/relais, dons et actions.
5. **Command Center bas** — création, suggestions, recherche, liste, caméra, tournée.

## Carte postale et timbre

La carte postale n’est pas une destination de navigation et ne possède pas de studio séparé dans le produit.

- À la création d’une boîte, une carte et un timbre sont générés automatiquement côté serveur.
- La photo de la carte peut être celle du don, d’un particulier, d’une équipe ou d’une communication.
- Depuis l’inspecteur, l’utilisateur peut ouvrir **Voir / personnaliser la carte postale**.
- Le composer affiche un objet postal 15 × 10 cm : recto image et verso avec zone message, lignes d’adresse et timbre.
- La personnalisation met à jour la carte existante ; elle ne crée pas de doublon.

## Boîte à chaussures

- `boxType = CARTON` pour les dons généralistes.
- `boxType = SHOEBOX` pour les chaussures uniquement.
- Une shoebox utilise un volume 3D horizontal avec couvercle séparé.
- La pointure EU est stockée sur la boîte et sur le don, puis affichée dans l’inspecteur et sur le marquage 3D.

## Règles typographiques

- **Inter** : toute l’interface et les titres.
- **IBM Plex Mono** : codes, références et heures uniquement.
- **Caveat** : annotations manuscrites physiques et message de carte postale.

## Règles de couleur

- Interface strictement noir, blanc et gris.
- Kraft et photos = contenu de la boîte, jamais accents d’interface.
- Aucun statut ne dépend d’une couleur seule.

## Critères de suppression

Un élément est retiré s’il duplique une commande, masque la scène, ne déclenche aucune action métier ou transforme une sortie documentaire en outil indépendant.
