import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "LE MONDE AIME — Boîtes de dons et relais solidaires",
  description:
    "Créez une boîte virtuelle, photographiez les dons disponibles et connectez-les aux associations, points de collecte et relais solidaires proches.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fr">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          rel="preconnect"
          href="https://fonts.gstatic.com"
          crossOrigin="anonymous"
        />
        <link
          href="https://fonts.googleapis.com/css2?family=Caveat:wght@500;600;700&family=IBM+Plex+Mono:wght@400;500;600&family=Inter:wght@400;500;600;700;800;900&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
