"use client";

import React, { useEffect, useMemo, useRef, useState } from "react";
import { Award } from "lucide-react";
import { Atelier3DScene, type BoxData } from "@/components/Atelier3DScene";
import { AuthModal, type DemoUser } from "@/components/AuthModal";
import {
  PasseportSolidaireModal,
  type CitizenStampData,
} from "@/components/PasseportSolidaireModal";
import { ShippingLabelModal } from "@/components/ShippingLabelModal";
import { AppHeader } from "@/components/app/AppHeader";
import {
  AppSidebar,
  type SidebarSection,
} from "@/components/app/AppSidebar";
import { BoxInspector } from "@/components/app/BoxInspector";
import { CommandDock } from "@/components/app/CommandDock";
import {
  AddDonationModal,
  CreateBoxModal,
  DONATION_PHOTOS,
  type AddDonationForm,
  type CreateBoxForm,
} from "@/components/app/DonationModals";
import {
  PostcardComposer,
  type StudioPostcard,
} from "@/components/app/PostcardComposer";

type ShipmentLog = {
  id: number;
  boxId: number | null;
  boxCode: string;
  eventType: string;
  message: string;
  authorName: string;
  createdAt: string;
};

const initialCreateForm: CreateBoxForm = {
  boxRole: "DONATEUR",
  boxType: "CARTON",
  name: "",
  pickupPoint: "Kiosque Citoyen Voltaire · Paris 11e",
  city: "Paris",
  firstItem: "",
  photoUrl: DONATION_PHOTOS[0].url,
  condition: "Comme neuf",
  story: "Offert avec soin pour une nouvelle vie.",
  shoeSizeEu: "",
  futureDonationType: "ENERGY_WATT",
  futureDonationValue: "120 kWh solaires disponibles",
  postcardPhotoUrl: DONATION_PHOTOS[0].url,
  postcardSource: "DON",
  postcardTitle: "Message du réseau",
  postcardMessage: "Bonjour, ce don est disponible et peut être récupéré au point indiqué.",
  stampValue: "Monde Relais",
  relaisNeeded: false,
  relaisRoute: "Covoiturage bénévole disponible le week-end",
};

const initialDonationForm: AddDonationForm = {
  name: "",
  photoUrl: DONATION_PHOTOS[1].url,
  condition: "Comme neuf",
  story: "Don documenté et disponible.",
};

export default function LeMondeAimePage() {
  const [boxes, setBoxes] = useState<BoxData[]>([]);
  const [logs, setLogs] = useState<ShipmentLog[]>([]);
  const [stamps, setStamps] = useState<CitizenStampData[]>([]);
  const [postcards, setPostcards] = useState<StudioPostcard[]>([]);
  const [currentUser, setCurrentUser] = useState<DemoUser | null>(null);
  const [allUsers, setAllUsers] = useState<DemoUser[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const [activeSection, setActiveSection] = useState<SidebarSection>("all");
  const [selectedBoxId, setSelectedBoxId] = useState<number | null>(null);
  const [openBoxIds, setOpenBoxIds] = useState<Set<number>>(new Set());
  const [drawerTab, setDrawerTab] = useState<"inspect" | "journal">("inspect");

  const [searchQuery, setSearchQuery] = useState("");
  const [searchShake, setSearchShake] = useState(false);
  const [linkCopied, setLinkCopied] = useState(false);

  const [createOpen, setCreateOpen] = useState(false);
  const [addDonationOpen, setAddDonationOpen] = useState(false);
  const [sheetOpen, setSheetOpen] = useState(false);
  const [postcardOpen, setPostcardOpen] = useState(false);
  const [passportOpen, setPassportOpen] = useState(false);
  const [authOpen, setAuthOpen] = useState(false);

  const [createForm, setCreateForm] = useState<CreateBoxForm>(initialCreateForm);
  const [donationForm, setDonationForm] = useState<AddDonationForm>(initialDonationForm);
  const [submittingBox, setSubmittingBox] = useState(false);
  const [submittingDonation, setSubmittingDonation] = useState(false);

  const [toast, setToast] = useState<string | null>(null);
  const toastTimer = useRef<NodeJS.Timeout | null>(null);
  const resetCameraRef = useRef<(() => void) | null>(null);

  const notify = (message: string) => {
    setToast(message);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), 3300);
  };

  const loadData = async (options?: { preserveSelection?: boolean }) => {
    try {
      const [boxesResponse, authResponse, studioResponse] = await Promise.all([
        fetch("/api/boxes"),
        fetch("/api/auth"),
        fetch("/api/studio"),
      ]);

      if (boxesResponse.ok) {
        const data = await boxesResponse.json();
        const loadedBoxes: BoxData[] = data.boxes ?? [];
        setBoxes(loadedBoxes);
        setLogs(data.logs ?? []);
        setStamps(data.stamps ?? []);

        if (!options?.preserveSelection) {
          const params = new URLSearchParams(window.location.search);
          const requestedCode = params.get("boite") || params.get("colis");
          const requestedBox = requestedCode
            ? loadedBoxes.find(
                (box) => box.code.toUpperCase() === requestedCode.toUpperCase()
              )
            : null;
          const initialBox = requestedBox ?? loadedBoxes[0] ?? null;
          setSelectedBoxId(initialBox?.id ?? null);
          if (requestedBox) setOpenBoxIds(new Set([requestedBox.id]));
        }
      }

      if (authResponse.ok) {
        const data = await authResponse.json();
        setCurrentUser(data.user ?? null);
        setAllUsers(data.users ?? []);
      }

      if (studioResponse.ok) {
        const data = await studioResponse.json();
        setPostcards(data.postcards ?? []);
      }
    } catch (error) {
      console.error(error);
      notify("Le réseau est momentanément indisponible.");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
    return () => {
      if (toastTimer.current) clearTimeout(toastTimer.current);
    };
  }, []);

  const visibleBoxes = useMemo(() => {
    if (activeSection === "citizens") {
      return boxes.filter((box) => box.boxRole === "DONATEUR");
    }
    if (activeSection === "associations") {
      return boxes.filter((box) => box.boxRole === "ASSOCIATION");
    }
    if (activeSection === "relays") {
      return boxes.filter((box) => box.relaisNeeded);
    }
    if (activeSection === "cubes") {
      return boxes.filter((box) => box.boxType === "IRIDESCENT_CUBE");
    }
    return boxes;
  }, [activeSection, boxes]);

  const selectedBox = useMemo(
    () => boxes.find((box) => box.id === selectedBoxId) ?? null,
    [boxes, selectedBoxId]
  );

  const donationsCount = useMemo(
    () => boxes.reduce((total, box) => total + box.items.length, 0),
    [boxes]
  );

  const selectBox = (box: BoxData) => {
    setSelectedBoxId(box.id);
    setDrawerTab("inspect");
    window.history.replaceState(
      null,
      "",
      `?boite=${encodeURIComponent(box.code)}`
    );
  };

  const changeSection = (section: SidebarSection) => {
    setActiveSection(section);
    if (section === "activity") {
      setDrawerTab("journal");
      if (!selectedBoxId && boxes[0]) setSelectedBoxId(boxes[0].id);
      return;
    }

    setDrawerTab("inspect");
    const firstMatch =
      section === "citizens"
        ? boxes.find((box) => box.boxRole === "DONATEUR")
        : section === "associations"
          ? boxes.find((box) => box.boxRole === "ASSOCIATION")
          : section === "cubes"
            ? boxes.find((box) => box.boxType === "IRIDESCENT_CUBE")
          : section === "relays"
            ? boxes.find((box) => box.relaisNeeded)
            : boxes[0];
    if (firstMatch) setSelectedBoxId(firstMatch.id);
  };

  const toggleBox3D = (boxId: number) => {
    setOpenBoxIds((current) => {
      const next = new Set(current);
      if (next.has(boxId)) next.delete(boxId);
      else next.add(boxId);
      return next;
    });
  };

  const repositionBox = async (boxId: number, posX: number, posZ: number) => {
    setBoxes((current) =>
      current.map((box) => (box.id === boxId ? { ...box, posX, posZ } : box))
    );
    try {
      await fetch(`/api/boxes/${boxId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ posX, posZ, silent: true }),
      });
    } catch {
      notify("La nouvelle position n’a pas pu être enregistrée.");
    }
  };

  const runSearch = (override?: string) => {
    const query = (override ?? searchQuery).trim().toLowerCase();
    if (override) setSearchQuery(override);
    if (!query) return;

    const results = boxes.filter(
      (box) =>
        box.name.toLowerCase().includes(query) ||
        box.kind.toLowerCase().includes(query) ||
        box.pickupPoint.toLowerCase().includes(query) ||
        box.city.toLowerCase().includes(query) ||
        box.code.toLowerCase().includes(query) ||
        box.items.some((item) => item.name.toLowerCase().includes(query))
    );

    if (!results.length) {
      setSearchShake(false);
      window.setTimeout(() => setSearchShake(true), 10);
      notify(`Aucune boîte trouvée pour « ${query} ».`);
      return;
    }

    setActiveSection("all");
    selectBox(results[0]);
    setOpenBoxIds((current) => new Set(current).add(results[0].id));
    notify(`${results.length} résultat${results.length > 1 ? "s" : ""}.`);
  };

  const openCreate = (role?: "DONATEUR" | "ASSOCIATION") => {
    const inferredRole =
      role ?? (activeSection === "associations" ? "ASSOCIATION" : "DONATEUR");
    setCreateForm({ ...initialCreateForm, boxRole: inferredRole });
    setCreateOpen(true);
  };

  const submitCreateBox = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!createForm.name.trim()) return;
    setSubmittingBox(true);
    try {
      const response = await fetch("/api/boxes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...createForm,
          kind: createForm.boxType === "SHOEBOX" ? "Chaussures" : undefined,
        }),
      });
      const data = await response.json();
      if (!response.ok) {
        notify(data.error ?? "Impossible de créer cette boîte.");
        return;
      }
      setBoxes((current) => [...current, data.box]);
      setSelectedBoxId(data.box.id);
      setOpenBoxIds((current) => new Set(current).add(data.box.id));
      setCreateOpen(false);
      notify(
        data.box.boxType === "IRIDESCENT_CUBE"
          ? `Cube ${data.box.code} créé avec son don immatériel.`
          : `Boîte ${data.box.code} créée avec carte postale et timbre.`
      );
      await loadData({ preserveSelection: true });
    } catch {
      notify("Impossible de créer cette boîte.");
    } finally {
      setSubmittingBox(false);
    }
  };

  const submitDonation = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!selectedBox || !donationForm.name.trim()) return;
    setSubmittingDonation(true);
    try {
      const response = await fetch(`/api/boxes/${selectedBox.id}/items`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(donationForm),
      });
      const data = await response.json();
      if (!response.ok) {
        notify(data.error ?? "Impossible d’ajouter ce don.");
        return;
      }
      setBoxes((current) =>
        current.map((box) =>
          box.id === selectedBox.id
            ? { ...box, items: [...box.items, data.item] }
            : box
        )
      );
      setOpenBoxIds((current) => new Set(current).add(selectedBox.id));
      setAddDonationOpen(false);
      setDonationForm(initialDonationForm);
      notify("Don ajouté et documenté.");
      await loadData({ preserveSelection: true });
    } catch {
      notify("Impossible d’ajouter ce don.");
    } finally {
      setSubmittingDonation(false);
    }
  };

  const removeDonation = async (itemId: number) => {
    if (!selectedBox) return;
    const response = await fetch(
      `/api/boxes/${selectedBox.id}/items?itemId=${itemId}`,
      { method: "DELETE" }
    );
    if (response.ok) {
      setBoxes((current) =>
        current.map((box) =>
          box.id === selectedBox.id
            ? { ...box, items: box.items.filter((item) => item.id !== itemId) }
            : box
        )
      );
      notify("Don retiré de la boîte.");
    }
  };

  const activateRelay = async () => {
    if (!selectedBox) return;
    const response = await fetch(`/api/boxes/${selectedBox.id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "activate_relais" }),
    });
    if (response.ok) {
      notify("Relais solidaire activé.");
      await loadData({ preserveSelection: true });
    }
  };

  const updatePickup = async (pickupPoint: string) => {
    if (!selectedBox || !pickupPoint.trim()) return;
    const response = await fetch(`/api/boxes/${selectedBox.id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ pickupPoint: pickupPoint.trim() }),
    });
    if (response.ok) {
      setBoxes((current) =>
        current.map((box) =>
          box.id === selectedBox.id ? { ...box, pickupPoint } : box
        )
      );
      notify("Point de collecte mis à jour.");
    }
  };

  const confirmHandover = async () => {
    if (!selectedBox) return;
    const response = await fetch(`/api/boxes/${selectedBox.id}`, {
      method: "DELETE",
    });
    if (response.ok) {
      const remaining = boxes.filter((box) => box.id !== selectedBox.id);
      setBoxes(remaining);
      setSelectedBoxId(remaining[0]?.id ?? null);
      notify("Remise confirmée et ajoutée au passeport.");
      await loadData({ preserveSelection: true });
    }
  };

  const copyLink = () => {
    if (!selectedBox) return;
    navigator.clipboard.writeText(
      `${window.location.origin}/atelier?boite=${encodeURIComponent(selectedBox.code)}`
    );
    setLinkCopied(true);
    window.setTimeout(() => setLinkCopied(false), 2200);
  };

  return (
    <main className="h-screen w-screen overflow-hidden bg-[#f0efeb]">
      <Atelier3DScene
        boxes={visibleBoxes}
        selectedBoxId={selectedBoxId}
        openBoxIds={openBoxIds}
        onSelectBox={selectBox}
        onToggleOpen={toggleBox3D}
        onBoxRepositioned={repositionBox}
        registerCameraReset={(reset) => {
          resetCameraRef.current = reset;
        }}
      />
      <div className="grain-overlay" />

      <AppSidebar
        activeSection={activeSection}
        onSectionChange={changeSection}
        onOpenPassport={() => setPassportOpen(true)}
        stampsCount={stamps.length}
      />

      <AppHeader
        boxesCount={boxes.length}
        donationsCount={donationsCount}
        currentUser={currentUser}
        onOpenAuth={() => setAuthOpen(true)}
      />

      <BoxInspector
        box={selectedBox}
        logs={logs}
        tab={drawerTab}
        isOpen3D={selectedBox ? openBoxIds.has(selectedBox.id) : false}
        linkCopied={linkCopied}
        onTabChange={setDrawerTab}
        onClose={() => setSelectedBoxId(null)}
        onCopyLink={copyLink}
        onOpenSheet={() => setSheetOpen(true)}
        onOpenPostcard={() => setPostcardOpen(true)}
        onToggle3D={() => selectedBox && toggleBox3D(selectedBox.id)}
        onAddDonation={() => {
          setDonationForm(initialDonationForm);
          setAddDonationOpen(true);
        }}
        onRemoveDonation={removeDonation}
        onActivateRelay={activateRelay}
        onConfirmHandover={confirmHandover}
        onUpdatePickup={updatePickup}
      />

      <CommandDock
        boxes={visibleBoxes}
        selectedBoxId={selectedBoxId}
        searchQuery={searchQuery}
        onSearchQueryChange={setSearchQuery}
        onSearch={runSearch}
        onSelectBox={selectBox}
        onCreateBox={() => openCreate()}
        onResetCamera={() => resetCameraRef.current?.()}
        searchShake={searchShake}
      />

      {toast && (
        <div className="pointer-events-none fixed left-[calc(50%+36px)] top-[86px] z-40 -translate-x-1/2 rounded-full bg-[#11110f] px-4 py-2.5 text-[11px] font-medium text-white shadow-xl">
          <span className="flex items-center gap-2">
            <Award className="h-3.5 w-3.5" />
            {toast}
          </span>
        </div>
      )}

      <CreateBoxModal
        open={createOpen}
        value={createForm}
        submitting={submittingBox}
        onChange={setCreateForm}
        onClose={() => setCreateOpen(false)}
        onSubmit={submitCreateBox}
      />

      <AddDonationModal
        open={addDonationOpen}
        boxName={selectedBox?.name ?? "la boîte"}
        value={donationForm}
        submitting={submittingDonation}
        onChange={setDonationForm}
        onClose={() => setAddDonationOpen(false)}
        onSubmit={submitDonation}
      />

      <ShippingLabelModal
        box={sheetOpen ? selectedBox : null}
        onClose={() => setSheetOpen(false)}
      />

      <PostcardComposer
        open={postcardOpen}
        box={selectedBox}
        user={currentUser}
        postcards={postcards}
        onClose={() => setPostcardOpen(false)}
        onSaved={async () => {
          await loadData({ preserveSelection: true });
        }}
      />

      <PasseportSolidaireModal
        isOpen={passportOpen}
        onClose={() => setPassportOpen(false)}
        stamps={stamps}
        userName={currentUser?.name ?? "Clara Moreau"}
        badgeCode={currentUser?.badgeCode ?? "LMA-CITOYEN-01"}
      />

      <AuthModal
        isOpen={authOpen}
        onClose={() => setAuthOpen(false)}
        currentUser={currentUser}
        users={allUsers}
        onAuthSuccess={(user) => {
          setCurrentUser(user);
          notify(`Profil actif : ${user.name}`);
        }}
      />

      {isLoading && (
        <div className="fixed inset-0 z-[100] grid place-items-center bg-[#fbfaf7]">
          <div className="text-center">
            <div className="text-[38px] font-black tracking-[-0.065em]">LE MONDE AIME</div>
            <p className="mt-3 text-[10px] font-medium uppercase tracking-[0.18em] text-black/40">
              Chargement du réseau solidaire
            </p>
          </div>
        </div>
      )}
    </main>
  );
}
