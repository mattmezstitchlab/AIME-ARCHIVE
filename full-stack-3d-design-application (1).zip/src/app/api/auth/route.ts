import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import {
  getCurrentUser,
  setSessionUser,
  clearSessionUser,
} from "@/lib/auth";
import { ensureSeeded } from "@/lib/seed";

export async function GET() {
  await ensureSeeded();
  const current = await getCurrentUser();
  const allUsers = await db.select().from(users);
  const activeUser = current || allUsers[0] || null;

  // Le profil par défaut présenté dans l’interface est aussi le profil serveur
  // qui signe les créations tant qu’aucun autre profil n’a été sélectionné.
  if (!current && activeUser) await setSessionUser(activeUser.id);

  return NextResponse.json({
    user: activeUser,
    users: allUsers,
  });
}

export async function POST(req: Request) {
  try {
    await ensureSeeded();
    const body = await req.json();
    const action = body.action || "login";

    if (action === "logout") {
      await clearSessionUser();
      return NextResponse.json({ user: null });
    }

    if (action === "switch") {
      const userId = Number(body.userId);
      const found = await db
        .select()
        .from(users)
        .where(eq(users.id, userId))
        .limit(1);

      if (!found.length) {
        return NextResponse.json(
          { error: "Utilisateur introuvable" },
          { status: 404 }
        );
      }

      await setSessionUser(found[0].id);
      return NextResponse.json({ user: found[0] });
    }

    if (action === "register") {
      const email = String(body.email || "").trim().toLowerCase();
      const name = String(body.name || "").trim();
      const password = String(body.password || "").trim();
      const role = String(body.role || "Citoyen donateur").trim();
      const city = String(body.city || "Paris").trim();

      if (!email || !name || password.length < 3) {
        return NextResponse.json(
          {
            error:
              "Nom, e-mail et mot de passe (min. 3 caractères) requis.",
          },
          { status: 400 }
        );
      }

      const existing = await db
        .select()
        .from(users)
        .where(eq(users.email, email))
        .limit(1);

      if (existing.length) {
        return NextResponse.json(
          { error: "Un compte avec cet e-mail existe déjà." },
          { status: 409 }
        );
      }

      const badgeCode = `ATELIER-${Math.floor(100 + Math.random() * 900)}`;
      const [newUser] = await db
        .insert(users)
        .values({
          email,
          name,
          passwordHash: password,
          role,
          city,
          badgeCode,
        })
        .returning();

      await setSessionUser(newUser.id);
      return NextResponse.json({ user: newUser }, { status: 201 });
    }

    // Default: login
    const email = String(body.email || "").trim().toLowerCase();
    const password = String(body.password || "").trim();

    const found = await db
      .select()
      .from(users)
      .where(eq(users.email, email))
      .limit(1);

    if (!found.length || found[0].passwordHash !== password) {
      return NextResponse.json(
        { error: "E-mail ou mot de passe incorrect." },
        { status: 401 }
      );
    }

    await setSessionUser(found[0].id);
    return NextResponse.json({ user: found[0] });
  } catch (err: unknown) {
    console.error("POST /api/auth error:", err);
    return NextResponse.json(
      { error: "Erreur d'authentification" },
      { status: 500 }
    );
  }
}
