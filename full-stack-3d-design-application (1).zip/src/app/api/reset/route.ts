import { NextResponse } from "next/server";
import { ensureSeeded } from "@/lib/seed";

export async function POST() {
  try {
    await ensureSeeded(true);
    return NextResponse.json({ ok: true });
  } catch (err: unknown) {
    console.error("POST /api/reset error:", err);
    return NextResponse.json(
      { error: "Impossible de réinitialiser l'atelier" },
      { status: 500 }
    );
  }
}
