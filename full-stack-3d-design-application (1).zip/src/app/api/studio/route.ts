import { NextResponse } from "next/server";
import { db } from "@/db";
import { documentLabels, postcards } from "@/db/schema";
import { ensureSeeded } from "@/lib/seed";
import { getCurrentUser } from "@/lib/auth";
import { desc } from "drizzle-orm";

export async function GET() {
  await ensureSeeded();
  const currentUser = await getCurrentUser();
  const docs = await db.select().from(postcards).orderBy(desc(postcards.updatedAt));
  const labels = await db
    .select()
    .from(documentLabels)
    .orderBy(desc(documentLabels.updatedAt));

  return NextResponse.json({
    user: currentUser,
    postcards: docs,
    labels,
  });
}

export async function POST(req: Request) {
  try {
    const currentUser = await getCurrentUser();
    const body = await req.json();
    const type = String(body.type || "postcard");

    if (type === "postcard") {
      const [created] = await db
        .insert(postcards)
        .values({
          boxId: Number(body.boxId) || null,
          userId: currentUser?.id ?? null,
          title: body.title || "Carte postale solidaire",
          format: body.format || "POSTCARD",
          photoUrl: body.photoUrl,
          mediaType: body.mediaType || "IMAGE",
          portraitUrl: body.portraitUrl || currentUser?.portraitUrl || null,
          postcardSource: body.postcardSource || "DON",
          frontTitle: body.frontTitle || "LE MONDE AIME",
          message: body.message || "",
          recipientName: body.recipientName || "Point de collecte",
          recipientAddress: body.recipientAddress || "",
          stampLabel: body.stampLabel || "Participation documentée",
          stampValue: body.stampValue || "Monde Relais",
          stampCountry: body.stampCountry || "France",
          stampPrompt: body.stampPrompt || null,
          stampImageUrl: body.stampImageUrl || null,
          sealType: body.sealType || "SCELLÉ SIMPLE",
          foldedLayout: Boolean(body.foldedLayout),
        })
        .returning();
      return NextResponse.json({ postcard: created }, { status: 201 });
    }

    const [created] = await db
      .insert(documentLabels)
      .values({
        boxId: Number(body.boxId) || null,
        userId: currentUser?.id ?? null,
        labelType: body.labelType || "COLLECTE",
        title: body.title || "Étiquette transport",
        carrierName: body.carrierName || "LE MONDE AIME",
        recipientName: body.recipientName || "",
        recipientAddress: body.recipientAddress || "",
        senderName: body.senderName || currentUser?.name || "LE MONDE AIME",
        senderAddress: body.senderAddress || currentUser?.city || "",
        trackingCode:
          body.trackingCode ||
          `LMA-${Math.random().toString(36).slice(2, 8).toUpperCase()}`,
        notes: body.notes || "",
      })
      .returning();

    return NextResponse.json({ label: created }, { status: 201 });
  } catch {
    return NextResponse.json(
      { error: "Impossible de créer ce document." },
      { status: 500 }
    );
  }
}
