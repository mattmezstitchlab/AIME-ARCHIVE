import { NextResponse } from "next/server";
import { db } from "@/db";
import { documentLabels, postcards } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function PUT(
  req: Request,
  { params }: { params: Promise<{ kind: string; id: string }> }
) {
  try {
    const { kind, id } = await params;
    const numericId = Number(id);
    if (Number.isNaN(numericId)) {
      return NextResponse.json({ error: "Identifiant invalide." }, { status: 400 });
    }

    const body = await req.json();
    const { type: _type, boxId: _boxId, userId: _userId, id: _bodyId, ...payload } = body;

    if (kind === "postcards") {
      const [updated] = await db
        .update(postcards)
        .set({
          title: payload.title,
          format: payload.format,
          photoUrl: payload.photoUrl,
          mediaType: payload.mediaType,
          portraitUrl: payload.portraitUrl,
          postcardSource: payload.postcardSource,
          frontTitle: payload.frontTitle,
          message: payload.message,
          recipientName: payload.recipientName,
          recipientAddress: payload.recipientAddress,
          stampLabel: payload.stampLabel,
          stampValue: payload.stampValue,
          stampCountry: payload.stampCountry,
          stampPrompt: payload.stampPrompt,
          stampImageUrl: payload.stampImageUrl,
          sealType: payload.sealType,
          foldedLayout: payload.foldedLayout,
          updatedAt: new Date(),
        })
        .where(eq(postcards.id, numericId))
        .returning();

      if (!updated) return NextResponse.json({ error: "Carte introuvable." }, { status: 404 });
      return NextResponse.json({ postcard: updated });
    }

    const [updated] = await db
      .update(documentLabels)
      .set({
        labelType: payload.labelType,
        title: payload.title,
        carrierName: payload.carrierName,
        recipientName: payload.recipientName,
        recipientAddress: payload.recipientAddress,
        senderName: payload.senderName,
        senderAddress: payload.senderAddress,
        trackingCode: payload.trackingCode,
        notes: payload.notes,
        updatedAt: new Date(),
      })
      .where(eq(documentLabels.id, numericId))
      .returning();

    if (!updated) return NextResponse.json({ error: "Étiquette introuvable." }, { status: 404 });
    return NextResponse.json({ label: updated });
  } catch (error) {
    console.error("PUT /api/studio/[kind]/[id] error:", error);
    return NextResponse.json({ error: "Impossible de mettre à jour ce document." }, { status: 500 });
  }
}

export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ kind: string; id: string }> }
) {
  const { kind, id } = await params;
  const numericId = Number(id);
  if (Number.isNaN(numericId)) {
    return NextResponse.json({ error: "Identifiant invalide." }, { status: 400 });
  }

  if (kind === "postcards") {
    await db.delete(postcards).where(eq(postcards.id, numericId));
  } else {
    await db.delete(documentLabels).where(eq(documentLabels.id, numericId));
  }
  return NextResponse.json({ deletedId: numericId });
}
