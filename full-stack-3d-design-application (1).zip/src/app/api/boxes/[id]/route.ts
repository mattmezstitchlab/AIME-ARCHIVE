import { NextResponse } from "next/server";
import { db } from "@/db";
import { boxes, boxItems, shipmentLogs, citizenStamps } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";

export async function PUT(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const boxId = Number(id);
    if (isNaN(boxId)) {
      return NextResponse.json({ error: "ID de boîte invalide" }, { status: 400 });
    }

    const body = await req.json();
    const currentUser = await getCurrentUser();
    const authorName = currentUser?.name ?? "Citoyen LE MONDE AIME";

    const existing = await db
      .select()
      .from(boxes)
      .where(eq(boxes.id, boxId))
      .limit(1);

    if (!existing.length) {
      return NextResponse.json({ error: "Boîte introuvable" }, { status: 404 });
    }

    const currentBox = existing[0];
    const updateData: Record<string, unknown> = {
      updatedAt: new Date(),
    };

    let logMessage = "";

    if (typeof body.posX === "number" && typeof body.posZ === "number") {
      updateData.posX = body.posX;
      updateData.posZ = body.posZ;
      if (typeof body.rotY === "number") updateData.rotY = body.rotY;
      logMessage = `Déplacement de la boîte ${currentBox.code} dans l'espace solidaire 3D`;
    }

    if (body.name !== undefined) updateData.name = String(body.name).trim();
    if (body.pickupPoint !== undefined)
      updateData.pickupPoint = String(body.pickupPoint).trim();
    if (body.city !== undefined) updateData.city = String(body.city).trim();
    if (body.kind !== undefined) updateData.kind = String(body.kind).trim();
    if (body.description !== undefined)
      updateData.description = String(body.description).trim();
    if (body.relaisNeeded !== undefined)
      updateData.relaisNeeded = Boolean(body.relaisNeeded);
    if (body.relaisRoute !== undefined)
      updateData.relaisRoute = String(body.relaisRoute).trim();
    if (body.note1 !== undefined) updateData.note1 = String(body.note1).trim();

    // Activer un Relais Solidaire citoyen
    if (body.action === "activate_relais") {
      updateData.relaisNeeded = true;
      updateData.relaisRoute = `Relais Solidaire activé par ${authorName} (${currentBox.city} → Point Collecte)`;
      updateData.stampsText = `★ TAMPON DE RELAIS CITOYEN · PARRAINÉ PAR ${authorName.toUpperCase()}`;

      await db.insert(citizenStamps).values({
        stampCode: "RELAIS_PARRAIN",
        stampTitle: `TAMPON RELAIS SOLIDAIRE · ${currentBox.code}`,
        stampCity: currentBox.city.toUpperCase(),
        stampColor: "#4A6B52",
        awardedToName: authorName,
        awardedReason: `Prise en charge d'un relais longue distance pour le don de « ${currentBox.name} »`,
      });

      logMessage = `Relais Solidaire engagé par ${authorName} pour la boîte ${currentBox.code}`;
    }

    const [updated] = await db
      .update(boxes)
      .set(updateData)
      .where(eq(boxes.id, boxId))
      .returning();

    const items = await db
      .select()
      .from(boxItems)
      .where(eq(boxItems.boxId, boxId));

    if (logMessage && !body.silent) {
      await db.insert(shipmentLogs).values({
        boxId: updated.id,
        boxCode: updated.code,
        eventType:
          body.action === "activate_relais"
            ? "TAMPON_RELAIS_DÉCERNÉ"
            : body.posX !== undefined
            ? "COLIS_DÉPLACÉ"
            : "COLIS_MODIFIÉ",
        message:
          logMessage ||
          `Mise à jour des informations du point de collecte de « ${updated.name} » (${updated.code})`,
        authorName,
      });
    }

    return NextResponse.json({
      box: {
        ...updated,
        items,
      },
    });
  } catch (err: unknown) {
    console.error("PUT /api/boxes/[id] error:", err);
    return NextResponse.json(
      { error: "Impossible de modifier la boîte" },
      { status: 500 }
    );
  }
}

export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const boxId = Number(id);
    if (isNaN(boxId)) {
      return NextResponse.json({ error: "ID invalide" }, { status: 400 });
    }

    const currentUser = await getCurrentUser();
    const authorName = currentUser?.name ?? "Citoyen LE MONDE AIME";

    const existing = await db
      .select()
      .from(boxes)
      .where(eq(boxes.id, boxId))
      .limit(1);

    if (!existing.length) {
      return NextResponse.json({ error: "Boîte introuvable" }, { status: 404 });
    }

    const target = existing[0];

    // Décernement du TAMPON FINAL DE REMISE DU DON ("DON REMIS & TAMPONNÉ")
    await db.insert(citizenStamps).values({
      stampCode: "DON_REMIS_FINAL",
      stampTitle: `TAMPON D'OR DE REMISE · ${target.code}`,
      stampCity: target.city.toUpperCase(),
      stampColor: "#A77B33",
      awardedToName: authorName,
      awardedReason: `Don solidaire « ${target.name} » remis en main propre au point de collecte ${target.pickupPoint}`,
    });

    await db.insert(shipmentLogs).values({
      boxId: null,
      boxCode: target.code,
      eventType: "DON_REMIS_ET_TAMPONNÉ",
      message: `REMISE CONFIRMÉE : La boîte « ${target.name} » (${target.code}) a été remise au point ${target.pickupPoint} ! +1 Tampon d'Or certifié LE MONDE AIME.`,
      authorName,
    });

    await db.delete(boxes).where(eq(boxes.id, boxId));

    return NextResponse.json({
      deletedId: boxId,
      code: target.code,
    });
  } catch (err: unknown) {
    console.error("DELETE /api/boxes/[id] error:", err);
    return NextResponse.json(
      { error: "Impossible de clôturer la boîte" },
      { status: 500 }
    );
  }
}
