import { NextResponse } from "next/server";
import { db } from "@/db";
import { boxes, boxItems, shipmentLogs, citizenStamps } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";

const PALETTE = [
  "#a34a4a",
  "#4a6b52",
  "#3f5d7a",
  "#c26d5a",
  "#a77b33",
  "#8a7a9a",
];

function inferItemType(name: string): string {
  const n = name.toLowerCase();
  if (/livre|cahier|album|magazine|roman|partition|carnet/.test(n))
    return "book";
  if (
    /pull|écharpe|chaussette|vêtement|t-shirt|plaid|couverture|gant|bonnet|manteau|laine/.test(
      n
    )
  )
    return "fold";
  if (/peluche|ballon|doudou|ours/.test(n)) return "ball";
  if (/confiture|bocal|pot|miel|soupe|vase|gâteau|bonbon|conserve/.test(n))
    return "jar";
  if (/lettre|carte|courrier|affiche|document|dessin|manuscrit/.test(n))
    return "envelope";
  if (/crayon|stylo|outil|trousse|perceuse|marteau|tournevis|ciseau|guitare/.test(n))
    return "tool";
  if (/plante|fleur|bouture|cactus|graine/.test(n)) return "plant";
  if (/jeu|jouet|cube|écusson|badge|puzzle|vélo/.test(n)) return "toy";
  return "gift";
}

export async function POST(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const boxId = Number(id);
    if (isNaN(boxId)) {
      return NextResponse.json({ error: "ID de boîte invalide" }, { status: 400 });
    }

    const body = await req.json();
    const name = String(body.name || body.obj || "").trim();
    if (!name) {
      return NextResponse.json(
        { error: "Le nom du don ne peut pas être vide" },
        { status: 400 }
      );
    }

    const foundBox = await db
      .select()
      .from(boxes)
      .where(eq(boxes.id, boxId))
      .limit(1);

    if (!foundBox.length) {
      return NextResponse.json({ error: "Boîte introuvable" }, { status: 404 });
    }

    const box = foundBox[0];
    const currentUser = await getCurrentUser();
    const authorName = currentUser?.name ?? "Citoyen LE MONDE AIME";

    const currentItemsCount = await db
      .select()
      .from(boxItems)
      .where(eq(boxItems.boxId, boxId));

    if (currentItemsCount.length >= 12) {
      return NextResponse.json(
        { error: "Cette boîte contient déjà 12 dons photos (maximum par carton)." },
        { status: 400 }
      );
    }

    const itemType = body.itemType || inferItemType(name);
    const colorHex =
      body.colorHex ||
      PALETTE[(currentItemsCount.length + boxId) % PALETTE.length];

    const photoUrl =
      body.photoUrl ||
      "https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?auto=format&fit=crop&w=600&q=80";
    const condition = body.condition || "Comme neuf";
    const story =
      body.story ||
      "Déposé en photo avec soin pour une association ou une famille de proximité.";

    const [newItem] = await db
      .insert(boxItems)
      .values({
        boxId,
        name,
        itemType,
        colorHex,
        photoUrl,
        condition,
        story,
        addedByUserName: authorName,
      })
      .returning();

    await db
      .update(boxes)
      .set({
        updatedAt: new Date(),
        stampsText: `★ TAMPON CITOYEN CERTIFIÉ · ${currentItemsCount.length + 1} DONS PHOTOS`,
      })
      .where(eq(boxes.id, boxId));

    // Décernement d'un Tampon / Timbre d'engagement pour cet ajout photo de don
    const [newStamp] = await db
      .insert(citizenStamps)
      .values({
        stampCode: "DON_PHOTO_VERIFIE",
        stampTitle: `TAMPON PHOTO VÉRIFIÉ · « ${name.toUpperCase().slice(0, 24)} »`,
        stampCity: box.city.toUpperCase(),
        stampColor: "#B0492F",
        awardedToName: authorName,
        awardedReason: `Ajout photo du don « ${name} » (${condition}) dans la boîte ${box.code}`,
      })
      .returning();

    await db.insert(shipmentLogs).values({
      boxId,
      boxCode: box.code,
      eventType: "DON_PHOTO_DÉPOSÉ",
      message: `Dépôt photo du don « ${name} » (${condition}) dans la boîte ${box.code} « ${box.name} » — 1 Tampon décérné !`,
      authorName,
    });

    return NextResponse.json(
      {
        item: newItem,
        stamp: newStamp,
      },
      { status: 201 }
    );
  } catch (err: unknown) {
    console.error("POST /api/boxes/[id]/items error:", err);
    return NextResponse.json(
      { error: "Impossible de déposer ce don" },
      { status: 500 }
    );
  }
}

export async function DELETE(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const boxId = Number(id);
    const url = new URL(req.url);
    const itemId = Number(url.searchParams.get("itemId"));

    if (isNaN(boxId) || isNaN(itemId)) {
      return NextResponse.json({ error: "IDs invalides" }, { status: 400 });
    }

    const currentUser = await getCurrentUser();
    const authorName = currentUser?.name ?? "Citoyen LE MONDE AIME";

    const itemToDelete = await db
      .select()
      .from(boxItems)
      .where(and(eq(boxItems.id, itemId), eq(boxItems.boxId, boxId)))
      .limit(1);

    if (itemToDelete.length) {
      await db.delete(boxItems).where(eq(boxItems.id, itemId));
      const box = await db
        .select()
        .from(boxes)
        .where(eq(boxes.id, boxId))
        .limit(1);
      if (box[0]) {
        await db.insert(shipmentLogs).values({
          boxId,
          boxCode: box[0].code,
          eventType: "DON_RÉSERVÉ_OU_RETIRÉ",
          message: `Don « ${itemToDelete[0].name} » réservé ou retiré de la boîte ${box[0].code}`,
          authorName,
        });
      }
    }

    return NextResponse.json({ deletedItemId: itemId });
  } catch (err: unknown) {
    console.error("DELETE /api/boxes/[id]/items error:", err);
    return NextResponse.json(
      { error: "Impossible de retirer ce don" },
      { status: 500 }
    );
  }
}
