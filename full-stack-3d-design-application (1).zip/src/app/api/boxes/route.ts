import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  boxes,
  boxItems,
  shipmentLogs,
  citizenStamps,
  postcards,
  documentLabels,
} from "@/db/schema";
import { ensureSeeded } from "@/lib/seed";
import { getCurrentUser } from "@/lib/auth";
import { desc, asc } from "drizzle-orm";

const NOTES1 = [
  "donner change le monde",
  "seconde vie solidaire",
  "offert avec tout mon cœur",
  "relais citoyen actif",
  "pour un enfant qui sourit",
  "zéro gaspillage, 100% lien",
];

const NOTES2 = [
  "tampon LE MONDE AIME #2026",
  "photo du don vérifiée",
  "disponible en point collecte",
  "relais covoiturage possible",
  "association agréée",
  "premier don citoyen",
];

const PALETTE = [
  "#b8b3a8",
  "#8f8b83",
  "#a8a39a",
  "#c4bcae",
  "#7a7670",
  "#98938a",
];

function inferItemType(name: string, boxType?: string): string {
  const n = name.toLowerCase();
  if (boxType === "SHOEBOX" || /chaussure|baskets|sneakers|sandale|botte/.test(n)) {
    return "shoe";
  }
  if (/livre|cahier|album|magazine|roman|partition|carnet/.test(n)) return "book";
  if (/pull|écharpe|chaussette|vêtement|t-shirt|plaid|couverture|gant|bonnet|manteau|laine/.test(n)) return "fold";
  if (/peluche|ballon|doudou|ours/.test(n)) return "ball";
  if (/confiture|bocal|pot|miel|soupe|vase|gâteau|bonbon|conserve/.test(n)) return "jar";
  if (/lettre|carte|courrier|affiche|document|dessin|manuscrit/.test(n)) return "envelope";
  if (/crayon|stylo|outil|trousse|perceuse|marteau|tournevis|ciseau|guitare/.test(n)) return "tool";
  if (/plante|fleur|bouture|cactus|graine/.test(n)) return "plant";
  if (/jeu|jouet|cube|écusson|badge|puzzle|vélo/.test(n)) return "toy";
  return "gift";
}

function findFreeSpot(existing: Array<{ posX: number; posZ: number }>): [number, number] {
  for (let k = 0; k < 60; k++) {
    const a = Math.random() * Math.PI * 2;
    const r = 1.8 + Math.random() * 2.8;
    const x = Math.sin(a) * r;
    const z = Math.cos(a) * r;
    if (existing.every((b) => Math.hypot(b.posX - x, b.posZ - z) > 2.2)) {
      return [x, z];
    }
  }
  return [Math.sin(Math.random() * 6) * 3.8, Math.cos(Math.random() * 6) * 3.8];
}

export async function GET() {
  try {
    await ensureSeeded();
    const currentUser = await getCurrentUser();
    const allBoxes = await db.select().from(boxes).orderBy(asc(boxes.id));
    const allItems = await db.select().from(boxItems).orderBy(asc(boxItems.id));
    const recentLogs = await db.select().from(shipmentLogs).orderBy(desc(shipmentLogs.createdAt)).limit(30);
    const allStamps = await db.select().from(citizenStamps).orderBy(desc(citizenStamps.createdAt)).limit(20);

    const itemsByBoxId = new Map<number, typeof allItems>();
    for (const item of allItems) {
      const list = itemsByBoxId.get(item.boxId) ?? [];
      list.push(item);
      itemsByBoxId.set(item.boxId, list);
    }

    return NextResponse.json({
      boxes: allBoxes.map((box) => ({ ...box, items: itemsByBoxId.get(box.id) ?? [] })),
      logs: recentLogs,
      stamps: allStamps,
      user: currentUser,
    });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Erreur lors du chargement des boîtes." }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const currentUser = await getCurrentUser();
    const authorName = currentUser?.name ?? "Citoyen LE MONDE AIME";
    const name = String(body.name || "").trim();
    if (!name) {
      return NextResponse.json({ error: "Le nom de la boîte est obligatoire." }, { status: 400 });
    }

    const allBoxes = await db.select().from(boxes);
    if (allBoxes.length >= 16) {
      return NextResponse.json({ error: "L'espace 3D contient déjà 16 boîtes." }, { status: 400 });
    }

    const nextIndex = allBoxes.length + 1;
    const boxRole = body.boxRole || "DONATEUR";
    const boxType = body.boxType || (String(body.kind || "").toLowerCase().includes("chauss") ? "SHOEBOX" : "CARTON");
    const codePrefix = boxRole === "ASSOCIATION" ? "ASSO" : boxRole === "POINT_RELAIS" ? "RELAIS" : boxType === "IRIDESCENT_CUBE" ? "CUB" : "DON";
    const code = body.code || `${codePrefix}-${String(nextIndex).padStart(2, "0")}`;
    const kind = body.kind || (boxType === "SHOEBOX" ? "Chaussures" : "Vêtements & Dons");
    const pickupPoint = body.pickupPoint || body.destination || "Kiosque Solidaire · Point LE MONDE AIME";
    const city = body.city || "Paris";
    const shoeSizeEu = body.shoeSizeEu ? String(body.shoeSizeEu) : null;
    const description =
      body.description ||
      (boxType === "SHOEBOX"
        ? `Boîte à chaussures dédiée aux pointures ${shoeSizeEu || "à préciser"}, disponible sur ${pickupPoint}.`
        : boxRole === "ASSOCIATION"
          ? `Boîte d'association pour collecter des dons sur ${pickupPoint}.`
          : `Boîte virtuelle citoyenne mettant à disposition des dons vérifiés sur ${pickupPoint}.`);

    const relaisNeeded = Boolean(body.relaisNeeded);
    const relaisRoute = body.relaisRoute || (relaisNeeded ? `Relais Solidaire activé vers ${pickupPoint}` : `Remise de proximité (${pickupPoint})`);
    const firstItemName = body.firstItem || body.obj || (boxType === "SHOEBOX" ? "Paire de chaussures" : "Premier Don Solidaire");
    const photoUrl = body.photoUrl || "https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?auto=format&fit=crop&w=600&q=80";
    const portraitUrl = body.portraitUrl || currentUser?.portraitUrl || null;
    const condition = body.condition || "Comme neuf";
    const story = body.story || "Offert avec le cœur sur la plateforme citoyenne LE MONDE AIME.";
    const [freeX, freeZ] = typeof body.posX === "number" && typeof body.posZ === "number" ? [body.posX, body.posZ] : findFreeSpot(allBoxes);

    const [createdBox] = await db
      .insert(boxes)
      .values({
        code,
        boxRole,
        boxType,
        kind,
        name,
        pickupPoint,
        city,
        description,
        note1: body.note1 || NOTES1[nextIndex % NOTES1.length],
        note2: body.note2 || NOTES2[nextIndex % NOTES2.length],
        relaisNeeded,
        relaisRoute,
        stampsText: body.stampsText || "Participation documentée",
        shoeSizeEu,
        posX: freeX,
        posZ: freeZ,
        rotY: body.rotY ?? (Math.random() * 0.9 - 0.45),
        createdByUserId: currentUser?.id ?? null,
      })
      .returning();

    const [createdItem] = await db
      .insert(boxItems)
      .values({
        boxId: createdBox.id,
        name: firstItemName,
        itemType: inferItemType(firstItemName, boxType),
        colorHex: PALETTE[nextIndex % PALETTE.length],
        photoUrl,
        condition,
        story,
        shoeSizeEu,
        futureDonationType:
          boxType === "IRIDESCENT_CUBE"
            ? body.futureDonationType || "SKILL_CAPSULE"
            : null,
        futureDonationValue:
          boxType === "IRIDESCENT_CUBE"
            ? body.futureDonationValue || firstItemName
            : null,
        addedByUserName: authorName,
      })
      .returning();

    let newStamp = null;
    const isCrystalCube = boxType === "IRIDESCENT_CUBE";

    if (!isCrystalCube) {
      const defaultRecipientName =
        boxRole === "ASSOCIATION" ? name : `${name} · complément documentaire`;
      const defaultRecipientAddress = `${pickupPoint}${city ? `\n${city}` : ""}`;

      await db.insert(postcards).values({
        boxId: createdBox.id,
        userId: currentUser?.id ?? null,
        title: body.postcardTitle || "Carte postale de présentation",
        format: body.postcardFormat || "POSTCARD",
        photoUrl: body.postcardPhotoUrl || photoUrl,
        portraitUrl,
        postcardSource: body.postcardSource || "DON",
        frontTitle: body.frontTitle || "LE MONDE AIME",
        message:
          body.postcardMessage ||
          `Bonjour, ce don est disponible au point ${pickupPoint}. Merci de me prévenir avant retrait.`,
        recipientName: body.recipientName || defaultRecipientName,
        recipientAddress: body.recipientAddress || defaultRecipientAddress,
        stampLabel: body.stampLabel || "Participation active",
        stampValue:
          body.stampValue ||
          (boxType === "SHOEBOX" ? `Pointure ${shoeSizeEu || "N/A"}` : "Monde Relais"),
        stampCountry: body.stampCountry || "France",
        sealType: body.sealType || "SCELLÉ SIMPLE",
        foldedLayout: false,
      });

      if (body.createLabel !== false) {
        await db.insert(documentLabels).values({
          boxId: createdBox.id,
          userId: currentUser?.id ?? null,
          labelType: body.labelType || (relaisNeeded ? "RELAIS" : "COLLECTE"),
          title:
            body.labelTitle ||
            (boxType === "SHOEBOX" ? "Étiquette boîte à chaussures" : "Étiquette de collecte"),
          carrierName: body.carrierName || "LE MONDE AIME",
          recipientName: body.recipientName || defaultRecipientName,
          recipientAddress: body.recipientAddress || defaultRecipientAddress,
          senderName: body.senderName || authorName,
          senderAddress: body.senderAddress || (currentUser?.city ?? city),
          trackingCode: body.trackingCode || `${code}-DOC-${String(nextIndex).padStart(3, "0")}`,
          notes:
            body.labelNotes ||
            (boxType === "SHOEBOX"
              ? `Boîte dédiée chaussures · pointure ${shoeSizeEu || "à préciser"}`
              : "Support de collecte généré automatiquement"),
        });
      }

      [newStamp] = await db
        .insert(citizenStamps)
        .values({
          stampCode:
            boxRole === "ASSOCIATION"
              ? "BOITE_ASSO"
              : relaisNeeded
                ? "RELAIS_CITOYEN"
                : "DON_PHOTO",
          stampTitle:
            boxType === "SHOEBOX" ? `BOÎTE CHAUSSURES · ${code}` : `BOÎTE CRÉÉE · ${code}`,
          stampCity: city.toUpperCase(),
          stampColor: "#11110f",
          awardedToName: authorName,
          awardedReason: `Création de la boîte « ${name} » avec son complément documentaire.`,
        })
        .returning();
    }

    await db.insert(shipmentLogs).values({
      boxId: createdBox.id,
      boxCode: createdBox.code,
      eventType: isCrystalCube ? "CUBE_IMMATÉRIEL_CRÉÉ" : "BOÎTE_CRÉÉE",
      message: isCrystalCube
        ? `Le cube ${createdBox.code} représente un don immatériel : ${createdItem.futureDonationValue}.`
        : `La boîte ${createdBox.code} a été créée avec son don et son complément documentaire.`,
      authorName,
    });

    return NextResponse.json(
      {
        box: { ...createdBox, items: [createdItem] },
        stamp: newStamp,
        createdPostcard: !isCrystalCube,
      },
      { status: 201 }
    );
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Impossible de créer la boîte virtuelle." }, { status: 500 });
  }
}
