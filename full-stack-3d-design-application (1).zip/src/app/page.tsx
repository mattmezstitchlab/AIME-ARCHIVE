"use client";

import React, { useEffect } from "react";
import Link from "next/link";
import dynamic from "next/dynamic";
import {
  ArrowRight,
  ArrowUpRight,
  Box,
  Camera,
  Footprints,
  HandHeart,
  MapPin,
  Route,
  Stamp,
  Video,
} from "lucide-react";
import { LandingStamps } from "@/components/landing/LandingStamps";

const LandingBoxDemo = dynamic(
  () => import("@/components/landing/LandingBoxDemo").then((m) => m.LandingBoxDemo),
  {
    ssr: false,
    loading: () => (
      <div className="grid h-[420px] w-full place-items-center rounded-2xl border border-black/15 bg-[#f0efeb] text-[12px] text-black/40 sm:h-[520px]">
        Chargement de la boîte 3D…
      </div>
    ),
  }
);

const CrystalCubeDemo = dynamic(
  () => import("@/components/landing/CrystalCubeDemo").then((m) => m.CrystalCubeDemo),
  {
    ssr: false,
    loading: () => (
      <div className="grid h-[460px] w-full place-items-center rounded-2xl border border-white/10 bg-black text-[12px] text-white/40 sm:h-[560px]">
        Initialisation du cube cristallin…
      </div>
    ),
  }
);

const POSTCARD_PHOTO = "/images/hero-lma.jpg";

export default function LandingPage() {
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get("boite") || params.get("colis")) {
      window.location.replace(`/atelier${window.location.search}`);
    }
  }, []);

  return (
    <main className="h-screen overflow-y-auto bg-[#faf9f6] text-[#11110f]">
      <header className="sticky top-0 z-30 border-b border-black/10 bg-[#faf9f6]/90 backdrop-blur-md">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-3.5">
          <span className="text-[11px] font-semibold uppercase tracking-[0.22em]">
            Le Monde Aime<span className="align-super text-[8px]">®</span>
          </span>
          <nav className="hidden items-center gap-6 text-[12px] font-medium text-black/55 md:flex">
            <a href="#concept" className="hover:text-black">Le concept</a>
            <a href="#atelier" className="hover:text-black">L’atelier</a>
            <a href="#carte" className="hover:text-black">Carte postale</a>
            <a href="#passeport" className="hover:text-black">Tampons</a>
          </nav>
          <Link
            href="/atelier"
            className="flex items-center gap-2 rounded-full bg-[#11110f] px-4 py-2 text-[12px] font-semibold text-white transition hover:bg-black/75"
          >
            Entrer dans l’atelier <ArrowRight className="h-3.5 w-3.5" />
          </Link>
        </div>
      </header>

      {/* HERO — grand visuel de fond */}
      <section className="relative isolate overflow-hidden bg-black text-white">
        <img
          src="/images/hero-lma.jpg"
          alt=""
          className="absolute inset-0 h-full w-full object-cover object-center"
        />
        <div className="absolute inset-0 bg-black/25" />
        <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-black/55" />

        <div className="relative mx-auto flex min-h-[92vh] max-w-6xl flex-col items-center justify-center px-5 py-24 text-center">
          <p className="mb-6 text-[11px] font-medium uppercase tracking-[0.28em] text-white/60">
            Votre don. Une seule source de vérité.
          </p>
          <h1 className="text-[clamp(56px,11vw,132px)] font-black leading-[0.92] tracking-[-0.05em] drop-shadow-[0_18px_40px_rgba(0,0,0,0.5)]">
            LE MONDE
            <br />
            AIME<span className="align-super text-[0.28em]">®</span>
          </h1>
          <p className="mt-4 text-[12px] font-semibold uppercase tracking-[0.3em] text-white/70">
            Réseau citoyen de dons
          </p>
          <p className="mt-8 max-w-xl text-[15px] leading-7 text-white/75">
            Chaque don devient une boîte virtuelle visible en 3D. Les associations
            proches la repèrent, les citoyens relais la font voyager, et une carte
            postale vivante accompagne chaque geste.
          </p>
          <div className="mt-10 flex flex-wrap items-center justify-center gap-3">
            <Link
              href="/atelier"
              className="flex items-center gap-2 rounded-full bg-white px-6 py-3 text-[13px] font-semibold text-black transition hover:bg-white/90"
            >
              Entrer dans l’atelier 3D <ArrowRight className="h-4 w-4" />
            </Link>
            <a
              href="#atelier"
              className="flex items-center gap-2 rounded-full border border-white/30 px-6 py-3 text-[13px] font-semibold text-white/85 backdrop-blur-sm transition hover:border-white/70 hover:text-white"
            >
              Voir une boîte en 3D
            </a>
          </div>
          <p className="mt-8 font-mono text-[10px] uppercase tracking-[0.14em] text-white/35">
            Démonstration interactive · boîtes réelles · données persistées
          </p>
        </div>
      </section>

      {/* CUBE CRISTALLIN — dons immatériels */}
      <section className="bg-[#080808] text-white">
        <div className="mx-auto max-w-6xl px-5 py-20">
          <div className="grid items-end gap-8 lg:grid-cols-[1fr_420px]">
            <div>
              <p className="font-mono text-[10px] font-medium uppercase tracking-[0.16em] text-white/40">
                Une seconde famille de dons
              </p>
              <h2 className="mt-3 max-w-3xl text-[clamp(32px,5vw,56px)] font-extrabold leading-[1.01] tracking-[-0.05em]">
                Le cube cristallin contient ce qu’aucun carton ne peut transporter.
              </h2>
            </div>
            <p className="text-[13px] leading-6 text-white/55">
              Ni tampon, ni carte, ni emballage. Le cube représente un engagement immatériel
              mesurable : énergie partagée, temps disponible, compétence transmise ou accès
              à une expérience. Son cœur lumineux est la donnée du don.
            </p>
          </div>

          <div className="mt-10">
            <CrystalCubeDemo />
          </div>

          <div className="mt-8 grid gap-px overflow-hidden rounded-2xl border border-white/10 bg-white/10 sm:grid-cols-2 lg:grid-cols-4">
            {[
              ["Énergie", "Un surplus solaire exprimé en kWh et attribué à un foyer ou un lieu solidaire."],
              ["Temps", "Des heures disponibles pour accompagner, écouter, apprendre ou résoudre un problème."],
              ["Compétence", "Un savoir transmissible avec objectif, durée, niveau et résultat attendu."],
              ["Expérience", "Un accès partagé à une visite, un atelier, une œuvre ou une immersion à distance."],
            ].map(([title, description], index) => (
              <div key={title} className="bg-[#080808] p-6">
                <span className="font-mono text-[9px] text-white/30">0{index + 1}</span>
                <h3 className="mt-8 text-[18px] font-bold tracking-[-0.03em]">{title}</h3>
                <p className="mt-2 text-[11px] leading-5 text-white/45">{description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CONCEPT */}
      <section id="concept" className="mx-auto max-w-6xl px-5 py-20">
        <p className="font-mono text-[10px] font-medium uppercase tracking-[0.16em] text-black/40">
          Le concept
        </p>
        <h2 className="mt-3 max-w-3xl text-[clamp(30px,5vw,52px)] font-extrabold leading-[1.02] tracking-[-0.045em]">
          Rendre un don visible, c’est déjà le faire exister.
        </h2>
        <div className="mt-12 grid border-t border-black/15 md:grid-cols-3">
          {[
            {
              n: "01",
              icon: HandHeart,
              t: "Donner",
              d: "Vous créez une boîte virtuelle, photographiez le don, indiquez l’état et le point de collecte de proximité. La boîte apparaît dans l’atelier 3D, tamponnée et documentée.",
            },
            {
              n: "02",
              icon: MapPin,
              t: "Collecter",
              d: "Les associations ouvrent leurs propres boîtes pour signaler ce qu’elles recherchent et où. Les citoyens proches voient les appels et déposent leurs dons au bon endroit.",
            },
            {
              n: "03",
              icon: Route,
              t: "Relayer",
              d: "Si le don est loin, un voyageur ou un covoiturage solidaire active un relais. Le trajet, la prise en charge et la remise sont tracés, tampon après tampon.",
            },
          ].map((item) => (
            <div
              key={item.n}
              className="border-b border-black/15 py-8 md:border-b-0 md:border-r md:px-8 md:py-2 md:first:pl-0 md:last:border-r-0 md:last:pr-0"
            >
              <div className="flex items-center justify-between">
                <span className="font-mono text-[11px] text-black/40">{item.n}</span>
                <item.icon className="h-5 w-5 text-black/70" strokeWidth={1.6} />
              </div>
              <h3 className="mt-10 text-[22px] font-bold tracking-[-0.03em]">{item.t}</h3>
              <p className="mt-3 text-[13px] leading-6 text-black/55">{item.d}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ATELIER — vraie boîte 3D manipulable */}
      <section id="atelier" className="border-y border-black/10 bg-[#f0efeb]">
        <div className="mx-auto max-w-6xl px-5 py-20">
          <div className="flex flex-wrap items-end justify-between gap-6">
            <div>
              <p className="font-mono text-[10px] font-medium uppercase tracking-[0.16em] text-black/40">
                L’atelier
              </p>
              <h2 className="mt-3 max-w-2xl text-[clamp(30px,4.5vw,46px)] font-extrabold leading-[1.04] tracking-[-0.045em]">
                Des boîtes que l’on touche, ouvre et déplace.
              </h2>
            </div>
            <p className="max-w-sm text-[13px] leading-6 text-black/55">
              Ci-dessous, une vraie boîte du réseau : carton kraft, étiquette, tampons
              officiels et polaroid du don à l’intérieur. Faites-la pivoter, ouvrez-la.
            </p>
          </div>

          <div className="mt-10">
            <LandingBoxDemo />
          </div>

          <div className="mt-10 grid gap-px overflow-hidden rounded-2xl border border-black/15 bg-black/15 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { icon: Box, t: "Carton 3D", d: "Rabats qui s’ouvrent, dons en polaroid, glisser-déposer au sol." },
              { icon: Footprints, t: "Boîte à chaussures", d: "Contenant dédié aux chaussures, pointure EU affichée sur la boîte." },
              { icon: MapPin, t: "Points de collecte", d: "Kiosques, locaux associatifs, halls : chaque boîte a son point réel." },
              { icon: Route, t: "Relais citoyens", d: "Un trajet déclaré suffit pour faire voyager un don trop lointain." },
            ].map((card) => (
              <div key={card.t} className="bg-[#faf9f6] p-6">
                <card.icon className="h-5 w-5" strokeWidth={1.6} />
                <h3 className="mt-8 text-[18px] font-bold tracking-[-0.02em]">{card.t}</h3>
                <p className="mt-2 text-[12px] leading-5 text-black/50">{card.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CARTE POSTALE */}
      <section id="carte" className="mx-auto max-w-6xl px-5 py-20">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          <div>
            <p className="font-mono text-[10px] font-medium uppercase tracking-[0.16em] text-black/40">
              La signature du réseau
            </p>
            <h2 className="mt-3 text-[clamp(30px,4.5vw,46px)] font-extrabold leading-[1.04] tracking-[-0.045em]">
              Une carte postale vivante, éditée comme un objet.
            </h2>
            <p className="mt-5 max-w-md text-[14px] leading-7 text-black/60">
              Chaque boîte génère sa carte postale. On écrit dessus, on la retourne,
              on importe une photo ou une vidéo au recto, et l’on compose un vrai
              timbre dentelé à partir d’un portrait et d’un prompt.
            </p>
            <ul className="mt-8 space-y-3 text-[13px] text-black/70">
              <li className="flex items-center gap-3">
                <Camera className="h-4 w-4 shrink-0" strokeWidth={1.8} />
                Recto éditable : titre, usage, photo ou vidéo importée.
              </li>
              <li className="flex items-center gap-3">
                <Video className="h-4 w-4 shrink-0" strokeWidth={1.8} />
                Carte « vivante » : une vidéo peut remplacer l’image.
              </li>
              <li className="flex items-center gap-3">
                <Stamp className="h-4 w-4 shrink-0" strokeWidth={1.8} />
                Timbre généré en noir et blanc, avec portrait et mention.
              </li>
              <li className="flex items-center gap-3">
                <ArrowUpRight className="h-4 w-4 shrink-0" strokeWidth={1.8} />
                Verso postal : message manuscrit, adresse, impression.
              </li>
            </ul>
          </div>

          <div className="relative mx-auto w-full max-w-[440px]">
            <div className="absolute -right-4 top-2 aspect-[3/2] w-[86%] rotate-3 rounded-md border border-black/10 bg-white p-3 shadow-xl">
              <div className="flex h-full gap-3">
                <div className="flex-1 border-r border-black/10 pr-3">
                  <div className="font-mono text-[7px] uppercase tracking-[0.12em] text-black/40">Message</div>
                  <p className="mt-2 font-hand text-[15px] leading-[1.5] text-black/70">
                    Bonjour, ce don vous attend au point de collecte. Merci de me prévenir avant le retrait.
                  </p>
                </div>
                <div className="flex w-[38%] flex-col">
                  <div className="ml-auto h-12 w-10 border border-black/30 bg-[#f0efeb] p-0.5">
                    <div className="grid h-full place-items-center font-mono text-[6px] text-black/40">LMA</div>
                  </div>
                  <div className="mt-3 space-y-2">
                    <div className="h-px bg-black/25" />
                    <div className="h-px bg-black/25" />
                    <div className="h-px bg-black/25" />
                  </div>
                </div>
              </div>
            </div>
            <div className="relative aspect-[3/2] w-[86%] -rotate-2 overflow-hidden rounded-md border border-black/10 bg-black shadow-2xl">
              <img src={POSTCARD_PHOTO} alt="Don photographié" className="h-full w-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/75 to-transparent" />
              <div className="absolute bottom-3 left-4 right-4">
                <p className="text-[22px] font-black tracking-[-0.05em] text-white">LE MONDE AIME</p>
                <p className="text-[9px] font-semibold uppercase tracking-[0.16em] text-white/70">
                  Carte postale solidaire
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* PASSEPORT — vrais tampons */}
      <section id="passeport" className="border-t border-black/10 bg-[#f0efeb]">
        <div className="mx-auto grid max-w-6xl items-center gap-12 px-5 py-20 lg:grid-cols-[1fr_auto]">
          <div className="max-w-xl">
            <p className="font-mono text-[10px] font-medium uppercase tracking-[0.16em] text-black/40">
              Participation active
            </p>
            <h2 className="mt-3 text-[clamp(26px,3.6vw,40px)] font-extrabold leading-[1.05] tracking-[-0.04em]">
              Chaque action laisse un tampon dans votre passeport solidaire.
            </h2>
            <p className="mt-4 text-[13px] leading-6 text-black/55">
              Ce sont exactement les tampons apposés sur les cartons de l’atelier :
              même encre, même gravure, même langage. Don documenté, relais activé,
              remise confirmée, carte émise.
            </p>
          </div>
          <div className="lg:pl-6">
            <LandingStamps />
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="relative isolate overflow-hidden bg-black text-white">
        <img
          src="/images/hero-lma.jpg"
          alt=""
          className="absolute inset-0 h-full w-full object-cover object-center"
        />
        <div className="absolute inset-0 bg-black/40" />
        <div className="relative mx-auto flex max-w-4xl flex-col items-center px-5 py-24 text-center">
          <h2 className="text-[clamp(34px,6vw,72px)] font-black leading-[0.98] tracking-[-0.05em] drop-shadow-[0_18px_40px_rgba(0,0,0,0.4)]">
            Le don devient
            <br />
            un lieu de rencontre.
          </h2>
          <p className="mt-6 max-w-md text-[14px] leading-7 text-white/75">
            Entrez dans l’atelier interactif : créez une boîte, déposez un don en
            photo, retournez la carte postale et générez votre timbre.
          </p>
          <Link
            href="/atelier"
            className="mt-10 flex items-center gap-2 rounded-full bg-white px-7 py-3.5 text-[13px] font-semibold text-black transition hover:bg-white/90"
          >
            Entrer dans l’atelier 3D <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>

      <footer className="border-t border-black/10">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-5 py-8 text-[11px] text-black/40 md:flex-row">
          <span className="font-semibold uppercase tracking-[0.2em] text-black/55">
            Le Monde Aime<span className="align-super text-[8px]">®</span>
          </span>
          <span>Prototype interactif · réseau citoyen de dons, collectes et relais</span>
          <span className="font-mono">lemondeaime.org</span>
        </div>
      </footer>
    </main>
  );
}
