"use client";

import React, { useState } from "react";
import { Check, UserPlus, X } from "lucide-react";

export type DemoUser = {
  id: number;
  name: string;
  email: string;
  role: string;
  city?: string;
  badgeCode: string;
};

type AuthModalProps = {
  isOpen: boolean;
  onClose: () => void;
  currentUser: DemoUser | null;
  users: DemoUser[];
  onAuthSuccess: (user: DemoUser) => void;
};

export function AuthModal({
  isOpen,
  onClose,
  currentUser,
  users,
  onAuthSuccess,
}: AuthModalProps) {
  const [mode, setMode] = useState<"profiles" | "register">("profiles");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [role, setRole] = useState("Citoyen donateur");
  const [city, setCity] = useState("Paris 11e");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  if (!isOpen) return null;

  const switchUser = async (user: DemoUser) => {
    setLoading(true);
    setError("");
    try {
      const response = await fetch("/api/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "switch", userId: user.id }),
      });
      const data = await response.json();
      if (!response.ok) {
        setError(data.error ?? "Impossible d’activer ce profil.");
        return;
      }
      onAuthSuccess(data.user);
      onClose();
    } catch {
      setError("Le service est momentanément indisponible.");
    } finally {
      setLoading(false);
    }
  };

  const register = async (event: React.FormEvent) => {
    event.preventDefault();
    setLoading(true);
    setError("");
    try {
      const response = await fetch("/api/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "register",
          name,
          email,
          password: "aime2026",
          role,
          city,
        }),
      });
      const data = await response.json();
      if (!response.ok) {
        setError(data.error ?? "Impossible de créer ce profil.");
        return;
      }
      onAuthSuccess(data.user);
      onClose();
    } catch {
      setError("Le service est momentanément indisponible.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/35 p-4 backdrop-blur-sm">
      <div className="w-full max-w-[470px] rounded-[24px] border border-black/15 bg-[#fbfaf7] shadow-2xl">
        <div className="flex items-start justify-between border-b border-black/10 px-6 py-5">
          <div>
            <span className="ui-kicker">Compte</span>
            <h2 className="mt-1 text-[24px] font-extrabold tracking-[-0.05em]">Profil LE MONDE AIME</h2>
          </div>
          <button onClick={onClose} className="grid h-9 w-9 place-items-center rounded-full text-black/40 hover:bg-black/[0.06] hover:text-black">
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="p-6">
          <div className="mb-5 flex rounded-full bg-black/[0.045] p-1">
            <button
              onClick={() => setMode("profiles")}
              className={`flex-1 rounded-full py-2 text-[11px] font-semibold transition ${
                mode === "profiles" ? "bg-[#11110f] text-white" : "text-black/45 hover:text-black"
              }`}
            >
              Profils disponibles
            </button>
            <button
              onClick={() => setMode("register")}
              className={`flex-1 rounded-full py-2 text-[11px] font-semibold transition ${
                mode === "register" ? "bg-[#11110f] text-white" : "text-black/45 hover:text-black"
              }`}
            >
              Nouveau profil
            </button>
          </div>

          {error && <div className="mb-4 rounded-xl border border-black/15 bg-black/[0.04] p-3 text-[11px]">{error}</div>}

          {mode === "profiles" ? (
            <div className="space-y-2">
              {users.map((user) => {
                const active = currentUser?.id === user.id;
                const initials = user.name
                  .split(" ")
                  .map((part) => part[0])
                  .join("")
                  .slice(0, 2);
                return (
                  <button
                    key={user.id}
                    disabled={loading}
                    onClick={() => switchUser(user)}
                    className={`flex w-full items-center justify-between rounded-2xl border p-3 text-left transition ${
                      active ? "border-black bg-[#11110f] text-white" : "border-black/10 bg-white hover:border-black/30"
                    }`}
                  >
                    <span className="flex items-center gap-3">
                      <span className={`grid h-9 w-9 place-items-center rounded-full text-[10px] font-bold ${active ? "bg-white text-black" : "bg-[#11110f] text-white"}`}>
                        {initials}
                      </span>
                      <span>
                        <strong className="block text-[12px]">{user.name}</strong>
                        <span className={`mt-1 block text-[10px] ${active ? "text-white/55" : "text-black/40"}`}>
                          {user.role} · {user.city}
                        </span>
                      </span>
                    </span>
                    {active && <Check className="h-4 w-4" />}
                  </button>
                );
              })}
            </div>
          ) : (
            <form onSubmit={register} className="space-y-3">
              <input
                required
                value={name}
                onChange={(event) => setName(event.target.value)}
                placeholder="Nom complet ou association"
                className="w-full rounded-xl border border-black/15 bg-white px-3.5 py-3 text-[13px] outline-none focus:border-black/40"
              />
              <input
                required
                type="email"
                value={email}
                onChange={(event) => setEmail(event.target.value)}
                placeholder="Adresse e-mail"
                className="w-full rounded-xl border border-black/15 bg-white px-3.5 py-3 text-[13px] outline-none focus:border-black/40"
              />
              <div className="grid grid-cols-2 gap-2">
                <select
                  value={role}
                  onChange={(event) => setRole(event.target.value)}
                  className="rounded-xl border border-black/15 bg-white px-3 py-3 text-[12px] outline-none"
                >
                  <option>Citoyen donateur</option>
                  <option>Association partenaire</option>
                  <option>Relais solidaire</option>
                </select>
                <input
                  value={city}
                  onChange={(event) => setCity(event.target.value)}
                  placeholder="Ville"
                  className="rounded-xl border border-black/15 bg-white px-3 py-3 text-[12px] outline-none focus:border-black/40"
                />
              </div>
              <button
                type="submit"
                disabled={loading}
                className="flex h-11 w-full items-center justify-center gap-2 rounded-full bg-[#11110f] text-[12px] font-semibold text-white hover:bg-black/75 disabled:opacity-50"
              >
                <UserPlus className="h-4 w-4" />
                Créer le profil
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
