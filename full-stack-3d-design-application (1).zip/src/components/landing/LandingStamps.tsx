"use client";

import React, { useEffect, useRef } from "react";
import { drawCitizenStamp } from "@/lib/stamps";

export function LandingStamps() {
  const ref = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const size = 512;
    canvas.width = size * dpr;
    canvas.height = size * dpr;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.scale(dpr, dpr);
    drawCitizenStamp(ctx, size, "TAMPON CITOYEN");
  }, []);

  return (
    <canvas
      ref={ref}
      className="h-[240px] w-[240px] sm:h-[300px] sm:w-[300px] lg:h-[340px] lg:w-[340px]"
      aria-label="Tampon officiel LE MONDE AIME"
    />
  );
}
