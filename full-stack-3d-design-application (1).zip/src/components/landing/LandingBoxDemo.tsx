"use client";

import React, { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { MousePointerClick, PackageOpen, RotateCw } from "lucide-react";
import { drawCitizenStamp, drawRelayStamp } from "@/lib/stamps";

const DEMO_PHOTO =
  "https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?auto=format&fit=crop&w=600&q=80";

export function LandingBoxDemo() {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const openRef = useRef(false);
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.innerHTML = "";
    container.appendChild(renderer.domElement);
    const canvas = renderer.domElement;
    canvas.style.touchAction = "none";
    canvas.style.cursor = "grab";

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(
      36,
      container.clientWidth / container.clientHeight,
      0.1,
      100
    );

    scene.add(new THREE.HemisphereLight(0xfffaf0, 0xcfc4b0, 1.15));
    const key = new THREE.DirectionalLight(0xfff1dd, 2.2);
    key.position.set(5, 9, 6);
    key.castShadow = true;
    key.shadow.mapSize.set(1024, 1024);
    key.shadow.camera.left = -5;
    key.shadow.camera.right = 5;
    key.shadow.camera.top = 5;
    key.shadow.camera.bottom = -5;
    key.shadow.bias = -0.0005;
    key.shadow.normalBias = 0.02;
    scene.add(key);
    const fill = new THREE.DirectionalLight(0xdfe6ee, 0.6);
    fill.position.set(-5, 4, -3);
    scene.add(fill);

    const maxAniso = renderer.capabilities.getMaxAnisotropy();
    function canvasTex(
      w: number,
      h: number,
      draw: (ctx: CanvasRenderingContext2D, w: number, h: number) => void
    ) {
      const c = document.createElement("canvas");
      c.width = w;
      c.height = h;
      const ctx = c.getContext("2d")!;
      draw(ctx, w, h);
      const t = new THREE.CanvasTexture(c);
      t.colorSpace = THREE.SRGBColorSpace;
      t.anisotropy = maxAniso;
      return t;
    }

    // Kraft paper, identical language to the atelier boxes.
    const cardTex = canvasTex(512, 512, (x, w, h) => {
      x.fillStyle = "#c79a63";
      x.fillRect(0, 0, w, h);
      const img = x.getImageData(0, 0, w, h);
      const d = img.data;
      for (let i = 0; i < d.length; i += 4) {
        const n = (Math.random() - 0.5) * 24;
        d[i] += n;
        d[i + 1] += n * 0.9;
        d[i + 2] += n * 0.7;
      }
      x.putImageData(img, 0, 0);
      x.globalAlpha = 0.07;
      for (let i = 0; i < 260; i++) {
        x.strokeStyle = Math.random() > 0.5 ? "#8a6a3f" : "#e8ca97";
        x.lineWidth = 1;
        const sx = Math.random() * w;
        const sy = Math.random() * h;
        const a = Math.random() * Math.PI;
        const l = 12 + Math.random() * 70;
        x.beginPath();
        x.moveTo(sx, sy);
        x.lineTo(sx + Math.cos(a) * l, sy + Math.sin(a) * l);
        x.stroke();
      }
      x.globalAlpha = 0.05;
      x.fillStyle = "#6e4f2a";
      for (let yy = 0; yy < h; yy += 7) x.fillRect(0, yy, w, 2);
      x.globalAlpha = 1;
    });

    const edgeTex = canvasTex(256, 256, (x, w, h) => {
      x.fillStyle = "#b98a55";
      x.fillRect(0, 0, w, h);
      for (let i = 0; i < w; i += 9) {
        x.fillStyle = "#8a6238";
        x.fillRect(i, 0, 3, h);
        x.fillStyle = "#d8ac74";
        x.fillRect(i + 5, 0, 2, h);
      }
    });

    // Official stamps, shared with the atelier.
    const stampTex = canvasTex(256, 256, (ctx) => drawCitizenStamp(ctx, 256));
    const relayTex = canvasTex(320, 200, (ctx) => drawRelayStamp(ctx, 320, 200));

    const labelTex = canvasTex(512, 352, (x) => {
      x.clearRect(0, 0, 512, 352);
      x.fillStyle = "rgba(255,255,255,.97)";
      x.fillRect(6, 6, 500, 340);
      x.strokeStyle = "#11110f";
      x.lineWidth = 4;
      x.strokeRect(6, 6, 500, 340);
      x.fillStyle = "#11110f";
      x.textAlign = "left";
      x.font = "900 34px Inter, sans-serif";
      x.fillText("LE MONDE AIME", 28, 54);
      x.fillStyle = "#2c2b28";
      x.fillRect(28, 68, 454, 3);
      x.fillStyle = "rgba(17,17,15,.55)";
      x.font = '600 14px "IBM Plex Mono", monospace';
      x.fillText("DONATEUR CITOYEN", 28, 98);
      x.fillStyle = "#11110f";
      x.font = "700 31px Inter, sans-serif";
      x.fillText("BOÎTE DE DÉMONSTRATION", 28, 134);
      x.fillStyle = "rgba(17,17,15,.55)";
      x.font = '600 14px "IBM Plex Mono", monospace';
      x.fillText("POINT DE COLLECTE", 28, 168);
      x.fillStyle = "#11110f";
      x.font = '600 22px "IBM Plex Mono", monospace';
      x.fillText("Kiosque Voltaire · Paris", 28, 202);
      x.strokeStyle = "rgba(17,17,15,.4)";
      x.lineWidth = 2;
      x.strokeRect(330, 96, 122, 60);
      x.font = '700 32px "IBM Plex Mono", monospace';
      x.textAlign = "center";
      x.fillText("DON-01", 391, 138);
      let bx = 28;
      x.fillStyle = "rgba(17,17,15,.85)";
      let seed = 7;
      while (bx < 462) {
        seed = (seed * 9301 + 49297) % 233280;
        const bw = 1.5 + (seed / 233280) * 4;
        x.fillRect(bx, 236, bw, 70);
        seed = (seed * 9301 + 49297) % 233280;
        bx += bw + 1.5 + (seed / 233280) * 4;
      }
      x.textAlign = "left";
      x.font = '700 14px "IBM Plex Mono", monospace';
      x.fillStyle = "#242321";
      x.fillText("TAMPON CITOYEN CERTIFIÉ", 28, 332);
    });

    const handTex = canvasTex(512, 144, (x, w, h) => {
      x.clearRect(0, 0, w, h);
      x.font = "600 62px Caveat, cursive";
      x.fillStyle = "rgba(48,40,30,.92)";
      x.textAlign = "center";
      x.textBaseline = "middle";
      x.fillText("donner change le monde", w / 2, h / 2);
    });

    const tapeTex = canvasTex(256, 256, (x, w, h) => {
      x.clearRect(0, 0, w, h);
      x.fillStyle = "rgba(255,251,238,.72)";
      x.fillRect(0, 0, w, h);
      for (let i = 0; i < 600; i++) {
        x.fillStyle = `rgba(${(210 + Math.random() * 40) | 0},${(200 + Math.random() * 40) | 0},${(170 + Math.random() * 40) | 0},${0.04 + Math.random() * 0.08})`;
        x.fillRect(Math.random() * w, Math.random() * h, 2 + Math.random() * 3, 1 + Math.random() * 2);
      }
    });

    const matO = new THREE.MeshStandardMaterial({ map: cardTex, roughness: 0.94 });
    const matI = new THREE.MeshStandardMaterial({ map: cardTex, color: 0xb59d7f, roughness: 0.98 });
    const E = new THREE.MeshStandardMaterial({ map: edgeTex, roughness: 0.96 });
    const tapeMat = new THREE.MeshStandardMaterial({
      map: tapeTex,
      transparent: true,
      roughness: 0.25,
      depthWrite: false,
      color: 0xfff8ea,
    });
    const decoMat = (tex: THREE.Texture) =>
      new THREE.MeshStandardMaterial({ map: tex, transparent: true, roughness: 0.85 });

    const root = new THREE.Group();
    scene.add(root);

    const W = 1.7;
    const D = 1.25;
    const H = 0.82;
    const T = 0.05;
    const TF = 0.045;
    const L = D / 2 + 0.015;

    const add = (m: THREE.Mesh, x: number, y: number, z: number) => {
      m.position.set(x, y, z);
      m.castShadow = true;
      m.receiveShadow = true;
      root.add(m);
      return m;
    };

    add(new THREE.Mesh(new THREE.BoxGeometry(W, T, D), matO), 0, T / 2, 0);
    add(new THREE.Mesh(new THREE.BoxGeometry(W, H, T), [E, E, E, E, matO, matI]), 0, T + H / 2, D / 2 - T / 2);
    add(new THREE.Mesh(new THREE.BoxGeometry(W, H, T), [E, E, E, E, matI, matO]), 0, T + H / 2, -(D / 2 - T / 2));
    add(new THREE.Mesh(new THREE.BoxGeometry(T, H, D - 2 * T), [matO, matI, E, E, E, E]), -(W / 2 - T / 2), T + H / 2, 0);
    add(new THREE.Mesh(new THREE.BoxGeometry(T, H, D - 2 * T), [matI, matO, E, E, E, E]), W / 2 - T / 2, T + H / 2, 0);

    const fMat = [E, E, matO, matI, E, E];
    const mkFlap = (w: number, d: number, px: number, py: number, pz: number, mx: number, mz: number) => {
      const piv = new THREE.Group();
      piv.position.set(px, py, pz);
      root.add(piv);
      const m = new THREE.Mesh(new THREE.BoxGeometry(w, TF, d), fMat);
      m.position.set(mx, 0, mz);
      m.castShadow = true;
      m.receiveShadow = true;
      piv.add(m);
      return piv;
    };

    const flaps = {
      front: mkFlap(W - 2 * T, L, 0, T + H + TF / 2, D / 2 - T / 2, 0, -L / 2),
      back: mkFlap(W - 2 * T, L, 0, T + H + TF / 2, -(D / 2 - T / 2), 0, L / 2),
      left: mkFlap(L, D - 2 * T, -(W / 2 - T / 2), T + H - TF / 2, 0, L / 2, 0),
      right: mkFlap(L, D - 2 * T, W / 2 - T / 2, T + H - TF / 2, 0, -L / 2, 0),
    };

    const deco = (tex: THREE.Texture, w: number, h: number, parent: THREE.Group, x: number, z: number, rot = 0) => {
      const g = new THREE.PlaneGeometry(w, h);
      g.rotateZ(rot);
      g.rotateX(-Math.PI / 2);
      const m = new THREE.Mesh(g, decoMat(tex));
      m.position.set(x, TF / 2 + 0.005, z);
      parent.add(m);
    };
    const tape = (parent: THREE.Group, x: number, z: number) => {
      const g = new THREE.PlaneGeometry(0.09, 0.56);
      g.rotateX(-Math.PI / 2);
      const m = new THREE.Mesh(g, tapeMat);
      m.position.set(x, TF / 2 + 0.009, z);
      m.renderOrder = 3;
      parent.add(m);
    };

    deco(labelTex, 0.62, 0.42, flaps.front, 0.3, -0.3, -0.06);
    deco(relayTex, 0.38, 0.23, flaps.front, -0.45, -0.36, 0.12);
    tape(flaps.front, 0.55, -0.36);
    tape(flaps.front, -0.55, -0.36);
    deco(stampTex, 0.42, 0.42, flaps.back, -0.42, 0.3, 0.1);
    deco(handTex, 0.72, 0.2, flaps.back, 0.3, 0.26, -0.05);
    tape(flaps.back, 0.55, 0.36);
    tape(flaps.back, -0.55, 0.36);

    // Side stencil + stamp
    const stencilTex = canvasTex(512, 128, (x, w, h) => {
      x.clearRect(0, 0, w, h);
      x.font = "900 52px Inter, sans-serif";
      x.textBaseline = "middle";
      x.textAlign = "center";
      x.fillStyle = "rgba(38,32,26,.85)";
      x.fillText("LE MONDE AIME", w / 2, h / 2 - 10);
      x.font = '700 17px "IBM Plex Mono", monospace';
      x.fillStyle = "#2c2b28";
      x.fillText("BOÎTE VIRTUELLE DE DONS", w / 2, h / 2 + 28);
    });
    {
      const g = new THREE.PlaneGeometry(0.88, 0.22);
      const m = new THREE.Mesh(g, decoMat(stencilTex));
      m.position.set(-0.12, 0.5, D / 2 + 0.005);
      root.add(m);
    }
    {
      const g = new THREE.PlaneGeometry(0.36, 0.36);
      g.rotateY(Math.PI / 2);
      const m = new THREE.Mesh(g, decoMat(stampTex));
      m.position.set(W / 2 + 0.005, 0.46, -0.05);
      root.add(m);
    }

    // Donation inside: folded textile + polaroid
    const inner = new THREE.Group();
    root.add(inner);
    const fold = new THREE.Mesh(
      new THREE.BoxGeometry(0.42, 0.14, 0.34),
      new THREE.MeshStandardMaterial({ color: 0xbdb6a8, roughness: 0.9 })
    );
    fold.position.set(-0.18, 0.12, 0.05);
    fold.castShadow = true;
    inner.add(fold);

    const polaroidTex = canvasTex(256, 310, (x, w, h) => {
      x.fillStyle = "#FFFEFA";
      x.fillRect(0, 0, w, h);
      x.strokeStyle = "rgba(17,17,15,.22)";
      x.lineWidth = 3;
      x.strokeRect(2, 2, w - 4, h - 4);
      x.fillStyle = "#EBE5D8";
      x.fillRect(16, 16, w - 32, 220);
      x.fillStyle = "#11110f";
      x.textAlign = "center";
      x.font = "700 17px Inter, sans-serif";
      x.fillText("PULL EN LAINE", w / 2, 266);
      x.fillStyle = "#242321";
      x.font = '700 12px "IBM Plex Mono", monospace';
      x.fillText("PHOTO DU DON", w / 2, 292);
    });
    const loader = new THREE.TextureLoader();
    loader.load(DEMO_PHOTO, (tex) => {
      tex.colorSpace = THREE.SRGBColorSpace;
      const c = document.createElement("canvas");
      c.width = 256;
      c.height = 310;
      const ctx = c.getContext("2d");
      const src = tex.image as HTMLImageElement;
      if (ctx && src) {
        ctx.fillStyle = "#FFFEFA";
        ctx.fillRect(0, 0, 256, 310);
        ctx.strokeStyle = "rgba(17,17,15,.22)";
        ctx.lineWidth = 3;
        ctx.strokeRect(2, 2, 252, 306);
        ctx.save();
        ctx.beginPath();
        ctx.rect(16, 16, 224, 220);
        ctx.clip();
        const scale = Math.max(224 / src.width, 220 / src.height);
        ctx.drawImage(
          src,
          16 + (224 - src.width * scale) / 2,
          16 + (220 - src.height * scale) / 2,
          src.width * scale,
          src.height * scale
        );
        ctx.restore();
        ctx.fillStyle = "#11110f";
        ctx.textAlign = "center";
        ctx.font = "700 17px Inter, sans-serif";
        ctx.fillText("PULL EN LAINE", 128, 266);
        ctx.fillStyle = "#242321";
        ctx.font = '700 12px "IBM Plex Mono", monospace';
        ctx.fillText("PHOTO DU DON", 128, 292);
        const updated = new THREE.CanvasTexture(c);
        updated.colorSpace = THREE.SRGBColorSpace;
        (polaroid.material as THREE.MeshStandardMaterial).map = updated;
        (polaroid.material as THREE.MeshStandardMaterial).needsUpdate = true;
      }
    });

    const polaroid = new THREE.Mesh(
      new THREE.PlaneGeometry(0.34, 0.41),
      new THREE.MeshStandardMaterial({ map: polaroidTex, roughness: 0.7, side: THREE.DoubleSide })
    );
    polaroid.rotation.x = -Math.PI / 2 + 0.2;
    polaroid.rotation.z = -0.14;
    polaroid.position.set(0.34, 0.24, -0.02);
    polaroid.castShadow = true;
    inner.add(polaroid);

    // Ground shadow catcher
    const ground = new THREE.Mesh(
      new THREE.CircleGeometry(6, 48),
      new THREE.ShadowMaterial({ opacity: 0.16 })
    );
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    scene.add(ground);

    // Camera orbit state
    let theta = -0.55;
    let phi = 1.02;
    let sTheta = -1.4;
    let sPhi = 1.25;
    const radius = 4.6;
    const target = new THREE.Vector3(0, 0.42, 0);
    let dragging = false;
    let lastX = 0;
    let lastY = 0;
    let moved = false;
    let lastInteract = performance.now();

    const onPointerDown = (e: PointerEvent) => {
      dragging = true;
      moved = false;
      lastX = e.clientX;
      lastY = e.clientY;
      canvas.setPointerCapture(e.pointerId);
      canvas.style.cursor = "grabbing";
      lastInteract = performance.now();
    };
    const onPointerMove = (e: PointerEvent) => {
      if (!dragging) return;
      const dx = e.clientX - lastX;
      const dy = e.clientY - lastY;
      if (Math.abs(dx) + Math.abs(dy) > 4) moved = true;
      theta -= dx * 0.008;
      phi = Math.max(0.35, Math.min(1.4, phi - dy * 0.005));
      lastX = e.clientX;
      lastY = e.clientY;
      lastInteract = performance.now();
    };
    const onPointerUp = () => {
      if (dragging && !moved) {
        openRef.current = !openRef.current;
        setIsOpen(openRef.current);
      }
      dragging = false;
      canvas.style.cursor = "grab";
      lastInteract = performance.now();
    };

    canvas.addEventListener("pointerdown", onPointerDown);
    canvas.addEventListener("pointermove", onPointerMove);
    canvas.addEventListener("pointerup", onPointerUp);
    canvas.addEventListener("pointercancel", onPointerUp);

    const onResize = () => {
      if (!container.clientWidth || !container.clientHeight) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };
    const observer = new ResizeObserver(onResize);
    observer.observe(container);

    let openT = 0;
    let frame = 0;
    const clock = new THREE.Clock();

    const animate = () => {
      frame = requestAnimationFrame(animate);
      const dt = Math.min(clock.getDelta(), 0.05);
      const now = performance.now();

      if (!dragging && now - lastInteract > 3000) theta += dt * 0.14;

      sTheta += (theta - sTheta) * 0.08;
      sPhi += (phi - sPhi) * 0.08;
      const sp = Math.sin(sPhi);
      camera.position.set(
        target.x + radius * sp * Math.sin(sTheta),
        target.y + radius * Math.cos(sPhi),
        target.z + radius * sp * Math.cos(sTheta)
      );
      camera.lookAt(target);

      const goal = openRef.current ? 1 : 0;
      openT += (goal - openT) * Math.min(1, dt * 4.6);
      const largeK = Math.max(0, Math.min(1, openT / 0.58));
      const smallK = Math.max(0, Math.min(1, (openT - 0.48) / 0.52));
      flaps.front.rotation.x = largeK * 1.98;
      flaps.back.rotation.x = -largeK * 1.98;
      flaps.left.rotation.z = smallK * 1.85;
      flaps.right.rotation.z = -smallK * 1.85;
      inner.children.forEach((child, i) => {
        const base = i === 0 ? 0.12 : 0.24;
        child.position.y = base + openT * 0.16 + Math.sin(now * 0.0012 + i * 1.6) * 0.006 * openT;
      });

      renderer.render(scene, camera);
    };
    animate();

    return () => {
      cancelAnimationFrame(frame);
      observer.disconnect();
      canvas.removeEventListener("pointerdown", onPointerDown);
      canvas.removeEventListener("pointermove", onPointerMove);
      canvas.removeEventListener("pointerup", onPointerUp);
      canvas.removeEventListener("pointercancel", onPointerUp);
      renderer.dispose();
    };
  }, []);

  return (
    <div className="relative overflow-hidden rounded-2xl border border-black/15 bg-gradient-to-b from-[#f6f4f0] to-[#e9e7e1]">
      <div ref={containerRef} className="h-[420px] w-full sm:h-[520px]" />

      <div className="pointer-events-none absolute left-4 top-4 flex flex-col gap-1.5">
        <span className="w-fit rounded-full border border-black/15 bg-white/85 px-3 py-1.5 font-mono text-[10px] font-medium uppercase tracking-[0.12em] text-black/60 backdrop-blur">
          Démo interactive · même moteur que l’atelier
        </span>
      </div>

      <div className="pointer-events-none absolute bottom-4 left-4 right-4 flex flex-wrap items-center justify-between gap-2">
        <div className="flex gap-2">
          <span className="flex items-center gap-1.5 rounded-full border border-black/15 bg-white/85 px-3 py-1.5 text-[11px] font-medium text-black/65 backdrop-blur">
            <RotateCw className="h-3.5 w-3.5" /> Glissez pour pivoter
          </span>
          <span className="flex items-center gap-1.5 rounded-full border border-black/15 bg-white/85 px-3 py-1.5 text-[11px] font-medium text-black/65 backdrop-blur">
            <MousePointerClick className="h-3.5 w-3.5" /> Cliquez pour ouvrir
          </span>
        </div>
        <button
          onClick={() => {
            openRef.current = !openRef.current;
            setIsOpen(openRef.current);
          }}
          className="pointer-events-auto flex items-center gap-2 rounded-full bg-[#11110f] px-4 py-2 text-[12px] font-semibold text-white transition hover:bg-black/75"
        >
          <PackageOpen className="h-4 w-4" />
          {isOpen ? "Fermer la boîte" : "Ouvrir la boîte"}
        </button>
      </div>
    </div>
  );
}
