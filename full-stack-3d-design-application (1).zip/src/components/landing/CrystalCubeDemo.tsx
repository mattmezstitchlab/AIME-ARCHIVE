"use client";

import React, { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { Rotate3D, Sparkles } from "lucide-react";

export function CrystalCubeDemo() {
  const hostRef = useRef<HTMLDivElement | null>(null);
  const openRef = useRef(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(host.clientWidth, host.clientHeight);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.35;
    renderer.shadowMap.enabled = true;
    host.innerHTML = "";
    host.appendChild(renderer.domElement);

    const canvas = renderer.domElement;
    canvas.style.cursor = "grab";
    canvas.style.touchAction = "none";

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(
      38,
      host.clientWidth / host.clientHeight,
      0.1,
      50
    );

    scene.add(new THREE.HemisphereLight(0xffffff, 0x18131f, 1.4));
    const key = new THREE.DirectionalLight(0xffffff, 3.2);
    key.position.set(5, 8, 6);
    key.castShadow = true;
    scene.add(key);
    const magenta = new THREE.PointLight(0xff25c8, 18, 8);
    magenta.position.set(-2.4, 1.2, 1.8);
    scene.add(magenta);
    const cyan = new THREE.PointLight(0x25d9ff, 18, 8);
    cyan.position.set(2.5, 1.4, -1.5);
    scene.add(cyan);
    const amber = new THREE.PointLight(0xffa319, 15, 7);
    amber.position.set(0, -0.2, 2.5);
    scene.add(amber);

    const root = new THREE.Group();
    root.position.y = 0.05;
    scene.add(root);

    const colors = [
      0xff246d,
      0xffb10f,
      0x20d8ff,
      0x813cff,
      0x00e59b,
      0xff6424,
      0x315fff,
      0xf029df,
    ];
    const blockSize = 0.88;
    const gap = 0.025;
    const offset = (blockSize + gap) / 2;

    function glass(color: number) {
      return new THREE.MeshPhysicalMaterial({
        color,
        roughness: 0.025,
        metalness: 0,
        transmission: 0.76,
        thickness: 1.25,
        ior: 1.58,
        iridescence: 1,
        iridescenceIOR: 1.9,
        iridescenceThicknessRange: [120, 900],
        clearcoat: 1,
        clearcoatRoughness: 0.015,
        transparent: true,
        opacity: 0.94,
      });
    }

    const lower = new THREE.Group();
    const lid = new THREE.Group();
    lid.userData.closedY = blockSize + gap;
    root.add(lower, lid);

    let index = 0;
    for (const y of [0, 1]) {
      const parent = y === 0 ? lower : lid;
      for (const x of [-1, 1]) {
        for (const z of [-1, 1]) {
          const block = new THREE.Mesh(
            new THREE.BoxGeometry(blockSize, blockSize, blockSize),
            glass(colors[index++])
          );
          block.position.set(x * offset, blockSize / 2, z * offset);
          block.castShadow = true;
          parent.add(block);
        }
      }
    }
    lid.position.y = lid.userData.closedY;

    const core = new THREE.Mesh(
      new THREE.IcosahedronGeometry(0.29, 2),
      new THREE.MeshPhysicalMaterial({
        color: 0xffffff,
        emissive: 0x7455ff,
        emissiveIntensity: 3,
        transmission: 0.4,
        roughness: 0,
        iridescence: 1,
      })
    );
    core.position.y = 0.92;
    root.add(core);

    const orbitA = new THREE.Mesh(
      new THREE.TorusGeometry(0.55, 0.012, 12, 80),
      new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.45 })
    );
    orbitA.position.y = 0.92;
    orbitA.rotation.x = 1.15;
    root.add(orbitA);
    const orbitB = orbitA.clone();
    orbitB.rotation.set(0.35, 0.8, 0.2);
    root.add(orbitB);

    const ground = new THREE.Mesh(
      new THREE.CircleGeometry(5, 64),
      new THREE.MeshStandardMaterial({
        color: 0x090909,
        roughness: 0.28,
        metalness: 0.42,
      })
    );
    ground.rotation.x = -Math.PI / 2;
    ground.position.y = -0.01;
    ground.receiveShadow = true;
    scene.add(ground);

    let theta = -0.6;
    let phi = 1.03;
    let dragging = false;
    let lastX = 0;
    let lastY = 0;
    let moved = false;
    let lastInput = performance.now();

    const down = (event: PointerEvent) => {
      dragging = true;
      moved = false;
      lastX = event.clientX;
      lastY = event.clientY;
      canvas.setPointerCapture(event.pointerId);
      canvas.style.cursor = "grabbing";
      lastInput = performance.now();
    };
    const move = (event: PointerEvent) => {
      if (!dragging) return;
      const dx = event.clientX - lastX;
      const dy = event.clientY - lastY;
      if (Math.abs(dx) + Math.abs(dy) > 4) moved = true;
      theta -= dx * 0.008;
      phi = Math.max(0.45, Math.min(1.35, phi - dy * 0.005));
      lastX = event.clientX;
      lastY = event.clientY;
      lastInput = performance.now();
    };
    const up = () => {
      if (dragging && !moved) {
        openRef.current = !openRef.current;
        setOpen(openRef.current);
      }
      dragging = false;
      canvas.style.cursor = "grab";
      lastInput = performance.now();
    };
    canvas.addEventListener("pointerdown", down);
    canvas.addEventListener("pointermove", move);
    canvas.addEventListener("pointerup", up);
    canvas.addEventListener("pointercancel", up);

    const resize = () => {
      if (!host.clientWidth || !host.clientHeight) return;
      camera.aspect = host.clientWidth / host.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(host.clientWidth, host.clientHeight);
    };
    const observer = new ResizeObserver(resize);
    observer.observe(host);

    let lidT = 0;
    let frame = 0;
    const clock = new THREE.Clock();
    const animate = () => {
      frame = requestAnimationFrame(animate);
      const dt = Math.min(clock.getDelta(), 0.05);
      const now = performance.now();
      if (!dragging && now - lastInput > 2200) theta += dt * 0.17;

      const radius = 4.8;
      const sp = Math.sin(phi);
      camera.position.set(
        radius * sp * Math.sin(theta),
        0.72 + radius * Math.cos(phi),
        radius * sp * Math.cos(theta)
      );
      camera.lookAt(0, 0.85, 0);

      const goal = openRef.current ? 1 : 0;
      lidT += (goal - lidT) * Math.min(1, dt * 4.5);
      lid.position.y = lid.userData.closedY + lidT * 1.05;
      lid.rotation.y = lidT * 0.72;
      core.rotation.x += dt * 0.45;
      core.rotation.y += dt * 0.7;
      const pulse = 1 + Math.sin(now * 0.0035) * 0.08 + lidT * 0.3;
      core.scale.setScalar(pulse);
      orbitA.rotation.z += dt * 0.42;
      orbitB.rotation.y -= dt * 0.31;

      renderer.render(scene, camera);
    };
    animate();

    return () => {
      cancelAnimationFrame(frame);
      observer.disconnect();
      canvas.removeEventListener("pointerdown", down);
      canvas.removeEventListener("pointermove", move);
      canvas.removeEventListener("pointerup", up);
      canvas.removeEventListener("pointercancel", up);
      renderer.dispose();
    };
  }, []);

  return (
    <div className="relative overflow-hidden rounded-2xl border border-white/10 bg-black">
      <div ref={hostRef} className="h-[460px] w-full sm:h-[560px]" />
      <div className="pointer-events-none absolute left-4 top-4 rounded-full border border-white/15 bg-black/35 px-3 py-1.5 font-mono text-[9px] uppercase tracking-[0.12em] text-white/65 backdrop-blur-md">
        Cube dichroïque · démo temps réel
      </div>
      <div className="absolute bottom-4 left-4 right-4 flex flex-wrap items-center justify-between gap-2">
        <span className="pointer-events-none flex items-center gap-2 rounded-full border border-white/15 bg-black/35 px-3 py-1.5 text-[10px] text-white/65 backdrop-blur-md">
          <Rotate3D className="h-3.5 w-3.5" /> Glissez pour explorer
        </span>
        <button
          onClick={() => {
            openRef.current = !openRef.current;
            setOpen(openRef.current);
          }}
          className="flex items-center gap-2 rounded-full bg-white px-4 py-2 text-[11px] font-semibold text-black transition hover:bg-white/90"
        >
          <Sparkles className="h-3.5 w-3.5" />
          {open ? "Refermer le cube" : "Révéler le don"}
        </button>
      </div>
    </div>
  );
}
