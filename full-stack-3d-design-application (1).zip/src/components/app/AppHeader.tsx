"use client";

import { UserRound } from "lucide-react";
import type { DemoUser } from "@/components/AuthModal";

type AppHeaderProps = {
  boxesCount: number;
  donationsCount: number;
  currentUser: DemoUser | null;
  onOpenAuth: () => void;
};

export function AppHeader({
  boxesCount,
  donationsCount,
  currentUser,
  onOpenAuth,
}: AppHeaderProps) {
  const initials = currentUser?.name
    ? currentUser.name
        .split(" ")
        .map((part) => part[0])
        .join("")
        .slice(0, 2)
        .toUpperCase()
    : "CM";

  return (
    <header className="fixed left-[72px] right-0 top-0 z-30 h-[72px] border-b border-black/10 bg-[#fbfaf7]/94 backdrop-blur-xl">
      <div className="flex h-full items-center justify-between px-6 lg:px-8">
        <div className="flex min-w-0 items-center gap-5">
          <div className="min-w-0">
            <h1 className="truncate text-[22px] font-black tracking-[-0.055em] text-[#11110f] sm:text-[25px]">
              LE MONDE AIME
            </h1>
            <p className="mt-0.5 hidden text-[10px] font-medium uppercase tracking-[0.18em] text-black/40 sm:block">
              Réseau citoyen de dons et de relais
            </p>
          </div>

          <div className="hidden h-8 w-px bg-black/10 md:block" />

          <div className="hidden items-center gap-5 text-[12px] md:flex">
            <div className="flex items-center gap-2">
              <span className="h-1.5 w-1.5 rounded-full bg-[#11110f]" />
              <span className="font-semibold tabular-nums">{boxesCount}</span>
              <span className="text-black/45">boîtes actives</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="font-semibold tabular-nums">{donationsCount}</span>
              <span className="text-black/45">dons documentés</span>
            </div>
          </div>
        </div>

        <button
          onClick={onOpenAuth}
          className="flex items-center gap-2.5 rounded-full border border-black/10 bg-white/60 py-1.5 pl-1.5 pr-3 transition hover:border-black/25 hover:bg-white"
          aria-label="Ouvrir le profil"
        >
          <span className="grid h-8 w-8 place-items-center rounded-full bg-[#11110f] text-[11px] font-bold text-white">
            {initials}
          </span>
          <span className="hidden text-left lg:block">
            <span className="block max-w-40 truncate text-[12px] font-semibold leading-none">
              {currentUser?.name ?? "Clara Moreau"}
            </span>
            <span className="mt-1 block max-w-40 truncate text-[10px] text-black/45">
              {currentUser?.role ?? "Citoyenne donatrice"}
            </span>
          </span>
          <UserRound className="h-4 w-4 text-black/45" />
        </button>
      </div>
    </header>
  );
}
