"use client";

import React from "react";
import {
  Award,
  Box,
  Camera,
  Check,
  ChevronRight,
  History,
  MapPin,
  PackageOpen,
  Printer,
  Route,
  Share2,
  Stamp,
  Trash2,
  X,
} from "lucide-react";
import type { BoxData } from "@/components/Atelier3DScene";

type ShipmentLog = {
  id: number;
  boxId: number | null;
  boxCode: string;
  eventType: string;
  message: string;
  authorName: string;
  createdAt: string;
};

type BoxInspectorProps = {
  box: BoxData | null;
  logs: ShipmentLog[];
  tab: "inspect" | "journal";
  isOpen3D: boolean;
  linkCopied: boolean;
  onTabChange: (tab: "inspect" | "journal") => void;
  onClose: () => void;
  onCopyLink: () => void;
  onOpenSheet: () => void;
  onOpenPostcard: () => void;
  onToggle3D: () => void;
  onAddDonation: () => void;
  onRemoveDonation: (itemId: number) => void;
  onActivateRelay: () => void;
  onConfirmHandover: () => void;
  onUpdatePickup: (value: string) => Promise<void>;
};

export function BoxInspector({
  box,
  logs,
  tab,
  isOpen3D,
  linkCopied,
  onTabChange,
  onClose,
  onCopyLink,
  onOpenSheet,
  onOpenPostcard,
  onToggle3D,
  onAddDonation,
  onRemoveDonation,
  onActivateRelay,
  onConfirmHandover,
  onUpdatePickup,
}: BoxInspectorProps) {
  const [editingPickup, setEditingPickup] = React.useState(false);
  const [pickupValue, setPickupValue] = React.useState("");

  React.useEffect(() => {
    setPickupValue(box?.pickupPoint ?? "");
    setEditingPickup(false);
  }, [box?.id, box?.pickupPoint]);

  if (!box) return null;

  const relevantLogs = logs.filter(
    (log) => log.boxId === box.id || log.boxCode === box.code
  );

  return (
    <aside className="pointer-events-none fixed bottom-[92px] right-4 top-[88px] z-20 w-[min(392px,calc(100vw-104px))]">
      <div className="ui-surface pointer-events-auto flex h-full flex-col overflow-hidden rounded-[24px]">
        <div className="flex h-[58px] shrink-0 items-center justify-between border-b border-black/10 px-4">
          <div className="flex items-center gap-1 rounded-full bg-black/[0.045] p-1">
            <button
              onClick={() => onTabChange("inspect")}
              className={`flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[11px] font-semibold transition ${
                tab === "inspect" ? "bg-[#11110f] text-white" : "text-black/45 hover:text-black"
              }`}
            >
              <Box className="h-3.5 w-3.5" />
              Contenu
            </button>
            <button
              onClick={() => onTabChange("journal")}
              className={`flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[11px] font-semibold transition ${
                tab === "journal" ? "bg-[#11110f] text-white" : "text-black/45 hover:text-black"
              }`}
            >
              <History className="h-3.5 w-3.5" />
              Activité
            </button>
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={onCopyLink}
              className="grid h-8 w-8 place-items-center rounded-full border border-black/10 text-black/45 transition hover:border-black/25 hover:text-black"
              aria-label="Copier le lien"
            >
              {linkCopied ? <Check className="h-3.5 w-3.5" /> : <Share2 className="h-3.5 w-3.5" />}
            </button>
            <button
              onClick={onOpenSheet}
              className="grid h-8 w-8 place-items-center rounded-full border border-black/10 text-black/45 transition hover:border-black/25 hover:text-black"
              aria-label="Ouvrir la fiche"
            >
              <Printer className="h-3.5 w-3.5" />
            </button>
            <button
              onClick={onClose}
              className="grid h-8 w-8 place-items-center rounded-full text-black/35 transition hover:bg-black/[0.06] hover:text-black"
              aria-label="Fermer le panneau"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {tab === "inspect" ? (
          <>
            <div className="min-h-0 flex-1 overflow-y-auto px-5 py-5">
              {/* 1. Identity */}
              <section className="border-b border-black/10 pb-5">
                <div className="mb-2 flex items-center justify-between">
                  <span className="ui-kicker">
                    {box.boxRole === "ASSOCIATION" ? "Association" : "Boîte citoyenne"}
                  </span>
                  <span className="font-mono text-[10px] font-medium text-black/45">{box.code}</span>
                </div>
                <h2 className="text-[28px] font-extrabold leading-[1.03] tracking-[-0.055em] text-[#11110f]">
                  {box.name}
                </h2>
                <p className="mt-3 text-[13px] leading-6 text-black/58">{box.description}</p>
                {box.boxType === "IRIDESCENT_CUBE" && box.items[0] && (
                  <div className="mt-3 rounded-2xl border border-black/10 bg-black/[0.035] p-3.5">
                    <span className="ui-kicker">Don immatériel</span>
                    <p className="mt-2 text-[12px] font-semibold">
                      {box.items[0].futureDonationType?.replaceAll("_", " ")}
                    </p>
                    <p className="mt-1 font-mono text-[11px] text-black/50">
                      {box.items[0].futureDonationValue}
                    </p>
                  </div>
                )}
                {box.boxType === "SHOEBOX" && box.shoeSizeEu && (
                  <div className="mt-3 inline-flex rounded-full border border-black/10 bg-black/[0.03] px-3 py-1 text-[11px] font-semibold text-black/65">
                    Pointure EU {box.shoeSizeEu}
                  </div>
                )}
              </section>

              {/* 2. Logistics */}
              <section className="border-b border-black/10 py-5">
                <div className="mb-3 flex items-center justify-between">
                  <span className="ui-kicker">Collecte</span>
                  {!editingPickup && (
                    <button
                      onClick={() => setEditingPickup(true)}
                      className="text-[11px] font-medium text-black/40 underline underline-offset-2 hover:text-black"
                    >
                      Modifier
                    </button>
                  )}
                </div>

                {editingPickup ? (
                  <div className="flex gap-2">
                    <input
                      value={pickupValue}
                      onChange={(event) => setPickupValue(event.target.value)}
                      className="min-w-0 flex-1 rounded-xl border border-black/15 bg-white px-3 py-2.5 text-[12px] outline-none focus:border-black/40"
                    />
                    <button
                      onClick={async () => {
                        await onUpdatePickup(pickupValue);
                        setEditingPickup(false);
                      }}
                      className="rounded-xl bg-[#11110f] px-3 text-[11px] font-semibold text-white"
                    >
                      Valider
                    </button>
                  </div>
                ) : (
                  <div className="flex items-start gap-3 rounded-2xl bg-black/[0.035] p-3.5">
                    <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-black/55" />
                    <div>
                      <p className="text-[12px] font-semibold leading-5">{box.pickupPoint}</p>
                      <p className="mt-0.5 text-[10px] text-black/40">{box.city} · Point déclaré</p>
                    </div>
                  </div>
                )}

                {box.relaisNeeded ? (
                  <div className="mt-2 flex items-start gap-3 rounded-2xl border border-black/10 p-3.5">
                    <Route className="mt-0.5 h-4 w-4 shrink-0 text-black/55" />
                    <div>
                      <p className="text-[11px] font-semibold">Relais actif</p>
                      <p className="mt-1 text-[11px] leading-5 text-black/50">{box.relaisRoute}</p>
                    </div>
                  </div>
                ) : (
                  <button
                    onClick={onActivateRelay}
                    className="mt-2 flex w-full items-center justify-between rounded-2xl border border-dashed border-black/25 px-3.5 py-3 text-left transition hover:border-black/50 hover:bg-black/[0.025]"
                  >
                    <span className="flex items-center gap-3">
                      <Route className="h-4 w-4 text-black/45" />
                      <span>
                        <span className="block text-[11px] font-semibold">Activer un relais</span>
                        <span className="mt-0.5 block text-[10px] text-black/40">Voyageur ou covoiturage solidaire</span>
                      </span>
                    </span>
                    <ChevronRight className="h-4 w-4 text-black/30" />
                  </button>
                )}
              </section>

              {/* 3. Donations */}
              <section className="pt-5">
                <div className="mb-3 flex items-center justify-between">
                  <span className="ui-kicker">
                    {box.boxType === "IRIDESCENT_CUBE"
                      ? "Donnée du cœur"
                      : `Dons documentés · ${box.items.length}/12`}
                  </span>
                  {box.boxType !== "IRIDESCENT_CUBE" && (
                    <button
                      onClick={onAddDonation}
                      className="flex items-center gap-1.5 text-[11px] font-semibold hover:opacity-55"
                    >
                      <Camera className="h-3.5 w-3.5" />
                      Ajouter
                    </button>
                  )}
                </div>

                {box.items.length === 0 ? (
                  <button
                    onClick={onAddDonation}
                    className="w-full rounded-2xl border border-dashed border-black/20 py-8 text-[12px] text-black/45 hover:border-black/40"
                  >
                    Ajouter le premier don en photo
                  </button>
                ) : (
                  <div className="space-y-2">
                    {box.items.map((item, index) => (
                      <article key={item.id ?? index} className="flex gap-3 rounded-2xl border border-black/10 bg-white p-3">
                        {item.photoUrl ? (
                          <img
                            src={item.photoUrl}
                            alt={item.name}
                            className="h-[68px] w-[68px] shrink-0 rounded-xl object-cover grayscale-[20%]"
                          />
                        ) : (
                          <div className="grid h-[68px] w-[68px] shrink-0 place-items-center rounded-xl bg-black/[0.05] text-[10px] text-black/35">
                            Photo
                          </div>
                        )}
                        <div className="min-w-0 flex-1">
                          <div className="flex items-start justify-between gap-2">
                            <h3 className="truncate text-[12px] font-semibold">{item.name}</h3>
                            {item.id && (
                              <button
                                onClick={() => onRemoveDonation(item.id!)}
                                className="shrink-0 text-black/25 transition hover:text-black"
                                aria-label="Retirer le don"
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </button>
                            )}
                          </div>
                          <div className="mt-1 flex flex-wrap gap-1.5">
                            <span className="inline-block rounded-md bg-black/[0.06] px-1.5 py-0.5 text-[9px] font-semibold text-black/55">
                              {item.condition || "Comme neuf"}
                            </span>
                            {item.shoeSizeEu && (
                              <span className="inline-block rounded-md bg-black/[0.06] px-1.5 py-0.5 text-[9px] font-semibold text-black/55">
                                EU {item.shoeSizeEu}
                              </span>
                            )}
                          </div>
                          <p className="mt-1 line-clamp-2 text-[10px] leading-4 text-black/45">{item.story}</p>
                        </div>
                      </article>
                    ))}
                  </div>
                )}
              </section>
            </div>

            {/* 4. Actions */}
            <div className="shrink-0 border-t border-black/10 bg-[#fbfaf7] p-4">
              <div className={`grid gap-2 ${box.boxType === "IRIDESCENT_CUBE" ? "grid-cols-1" : "grid-cols-2"}`}>
                <button
                  onClick={onToggle3D}
                  className="flex h-10 items-center justify-center gap-2 rounded-xl bg-[#11110f] text-[11px] font-semibold text-white transition hover:bg-black/75"
                >
                  <PackageOpen className="h-4 w-4" />
                  {box.boxType === "IRIDESCENT_CUBE"
                    ? isOpen3D
                      ? "Refermer le cube"
                      : "Révéler le cœur"
                    : isOpen3D
                      ? "Fermer la boîte"
                      : "Ouvrir en 3D"}
                </button>
                {box.boxType !== "IRIDESCENT_CUBE" && (
                  <button
                    onClick={onAddDonation}
                    className="flex h-10 items-center justify-center gap-2 rounded-xl border border-black/15 bg-white text-[11px] font-semibold transition hover:border-black/35"
                  >
                    <Camera className="h-4 w-4" />
                    Ajouter un don
                  </button>
                )}
              </div>
              {box.boxType !== "IRIDESCENT_CUBE" && (
                <button
                  onClick={onOpenPostcard}
                  className="mt-2 flex h-10 w-full items-center justify-center gap-2 rounded-xl border border-black/15 bg-white text-[11px] font-semibold transition hover:border-black/35 hover:bg-black/[0.03]"
                >
                  <Stamp className="h-4 w-4" />
                  Voir / personnaliser la carte postale
                </button>
              )}
              <button
                onClick={onConfirmHandover}
                className="mt-2 flex h-10 w-full items-center justify-center gap-2 rounded-xl border border-black/15 text-[11px] font-semibold transition hover:bg-black/[0.04]"
              >
                <Award className="h-4 w-4" />
                Confirmer la remise au point de collecte
              </button>
            </div>
          </>
        ) : (
          <div className="min-h-0 flex-1 overflow-y-auto p-5">
            <div className="mb-4 flex items-end justify-between">
              <div>
                <span className="ui-kicker">Traçabilité</span>
                <h2 className="mt-1 text-[20px] font-bold tracking-[-0.035em]">Journal de la boîte</h2>
              </div>
              <span className="font-mono text-[10px] text-black/40">{box.code}</span>
            </div>

            {relevantLogs.length === 0 ? (
              <div className="rounded-2xl border border-dashed border-black/20 py-10 text-center text-[12px] text-black/40">
                Aucun événement pour cette boîte.
              </div>
            ) : (
              <div className="relative space-y-0 pl-5 before:absolute before:bottom-2 before:left-[5px] before:top-2 before:w-px before:bg-black/10">
                {relevantLogs.map((log) => (
                  <article key={log.id} className="relative pb-5">
                    <span className="absolute -left-5 top-1 h-[11px] w-[11px] rounded-full border-2 border-[#fbfaf7] bg-[#11110f]" />
                    <div className="mb-1 flex items-center justify-between">
                      <span className="text-[10px] font-semibold uppercase tracking-[0.08em] text-black/45">{log.eventType}</span>
                      <span className="font-mono text-[9px] text-black/30">
                        {new Date(log.createdAt).toLocaleTimeString("fr-FR", {
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </span>
                    </div>
                    <p className="text-[12px] leading-5 text-black/65">{log.message}</p>
                    <p className="mt-1 text-[10px] text-black/35">Par {log.authorName}</p>
                  </article>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </aside>
  );
}
