"use client";

import React from "react";
import {
  ArrowRight,
  ChevronDown,
  Focus,
  List,
  Plus,
  Search,
  X,
} from "lucide-react";
import type { BoxData } from "@/components/Atelier3DScene";

type CommandDockProps = {
  boxes: BoxData[];
  selectedBoxId: number | null;
  searchQuery: string;
  onSearchQueryChange: (value: string) => void;
  onSearch: (value?: string) => void;
  onSelectBox: (box: BoxData) => void;
  onCreateBox: () => void;
  onResetCamera: () => void;
  searchShake: boolean;
};

const suggestions = [
  "Pull en laine",
  "Livres jeunesse",
  "Vélo enfant",
  "Fournitures scolaires",
  "Paris 11e",
  "Lyon 7e",
  "Marseille",
];

export function CommandDock({
  boxes,
  selectedBoxId,
  searchQuery,
  onSearchQueryChange,
  onSearch,
  onSelectBox,
  onCreateBox,
  onResetCamera,
  searchShake,
}: CommandDockProps) {
  const [openPanel, setOpenPanel] = React.useState<"suggestions" | "list" | null>(null);

  return (
    <div className="pointer-events-none fixed bottom-5 left-[calc(50%+36px)] z-30 flex w-[min(880px,calc(100vw-112px))] -translate-x-1/2 flex-col items-center">
      {openPanel === "suggestions" && (
        <div className="ui-surface pointer-events-auto mb-2.5 w-full rounded-2xl p-4">
          <div className="mb-3 flex items-center justify-between">
            <span className="ui-kicker">Suggestions</span>
            <button
              onClick={() => setOpenPanel(null)}
              className="rounded-full p-1 text-black/35 transition hover:bg-black/[0.06] hover:text-black"
              aria-label="Fermer"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
          <div className="flex flex-wrap gap-2">
            {suggestions.map((suggestion) => (
              <button
                key={suggestion}
                onClick={() => {
                  onSearch(suggestion);
                  setOpenPanel(null);
                }}
                className="rounded-full border border-black/10 bg-white px-3.5 py-2 text-[12px] font-medium text-black/70 transition hover:border-black/30 hover:text-black"
              >
                {suggestion}
              </button>
            ))}
          </div>
        </div>
      )}

      {openPanel === "list" && (
        <div className="ui-surface pointer-events-auto mb-2.5 w-full rounded-2xl p-4">
          <div className="mb-3 flex items-center justify-between">
            <div>
              <span className="ui-kicker">Boîtes visibles</span>
              <span className="ml-2 font-mono text-[10px] text-black/40">{boxes.length}</span>
            </div>
            <button
              onClick={() => setOpenPanel(null)}
              className="rounded-full p-1 text-black/35 transition hover:bg-black/[0.06] hover:text-black"
              aria-label="Fermer"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
          <div className="flex gap-2 overflow-x-auto pb-1">
            {boxes.map((box) => (
              <button
                key={box.id}
                onClick={() => {
                  onSelectBox(box);
                  setOpenPanel(null);
                }}
                className={`min-w-48 rounded-xl border p-3 text-left transition ${
                  selectedBoxId === box.id
                    ? "border-black bg-[#11110f] text-white"
                    : "border-black/10 bg-white text-black hover:border-black/30"
                }`}
              >
                <div className="mb-1.5 flex items-center justify-between">
                  <span className="font-mono text-[10px] font-medium">{box.code}</span>
                  <span className={`text-[10px] ${selectedBoxId === box.id ? "text-white/55" : "text-black/40"}`}>
                    {box.items.length} don{box.items.length > 1 ? "s" : ""}
                  </span>
                </div>
                <p className="truncate text-[12px] font-semibold">{box.name}</p>
                <p className={`mt-1 truncate text-[10px] ${selectedBoxId === box.id ? "text-white/55" : "text-black/45"}`}>
                  {box.city}
                </p>
              </button>
            ))}
          </div>
        </div>
      )}

      <div
        className={`ui-surface pointer-events-auto flex w-full items-center gap-1.5 rounded-full p-1.5 ${
          searchShake ? "animate-shake" : ""
        }`}
      >
        <button
          onClick={onCreateBox}
          className="flex h-11 shrink-0 items-center gap-2 rounded-full bg-[#11110f] px-4 text-[12px] font-semibold text-white transition hover:bg-black/75"
        >
          <Plus className="h-4 w-4" />
          <span className="hidden sm:inline">Nouvelle boîte</span>
        </button>

        <button
          onClick={() => setOpenPanel(openPanel === "suggestions" ? null : "suggestions")}
          className={`grid h-11 w-11 shrink-0 place-items-center rounded-full transition ${
            openPanel === "suggestions"
              ? "bg-[#11110f] text-white"
              : "bg-black/[0.05] text-black/60 hover:bg-black/[0.09] hover:text-black"
          }`}
          aria-label="Afficher les suggestions"
          title="Suggestions"
        >
          {openPanel === "suggestions" ? (
            <ChevronDown className="h-4 w-4" />
          ) : (
            <Plus className="h-4 w-4" />
          )}
        </button>

        <div className="flex h-11 min-w-0 flex-1 items-center gap-2 rounded-full border border-black/10 bg-white px-4 focus-within:border-black/30">
          <Search className="h-4 w-4 shrink-0 text-black/30" />
          <input
            type="text"
            value={searchQuery}
            onChange={(event) => onSearchQueryChange(event.target.value)}
            onKeyDown={(event) => event.key === "Enter" && onSearch()}
            placeholder="Rechercher un don, une ville, un point de collecte…"
            className="min-w-0 flex-1 bg-transparent text-[13px] font-medium outline-none placeholder:text-black/30"
          />
          {searchQuery && (
            <button
              onClick={() => onSearchQueryChange("")}
              className="text-black/30 hover:text-black"
              aria-label="Effacer la recherche"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          )}
          <button
            onClick={() => onSearch()}
            className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-[#11110f] text-white transition hover:bg-black/75"
            aria-label="Lancer la recherche"
          >
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>

        <button
          onClick={() => setOpenPanel(openPanel === "list" ? null : "list")}
          className={`grid h-11 w-11 shrink-0 place-items-center rounded-full border transition ${
            openPanel === "list"
              ? "border-black bg-[#11110f] text-white"
              : "border-black/10 bg-white text-black/55 hover:border-black/30 hover:text-black"
          }`}
          aria-label="Afficher la liste des boîtes"
          title="Liste des boîtes"
        >
          <List className="h-4 w-4" />
        </button>

        <button
          onClick={onResetCamera}
          className="hidden h-11 shrink-0 items-center gap-1.5 rounded-full border border-black/10 bg-white px-3.5 text-[12px] font-semibold text-black/60 transition hover:border-black/30 hover:text-black md:flex"
          aria-label="Recentrer la caméra 3D sur l’ensemble des boîtes"
          title="Recentrer la caméra 3D (aucune géolocalisation)"
        >
          <Focus className="h-4 w-4" />
          <span className="hidden lg:inline">Recentrer</span>
        </button>


      </div>
    </div>
  );
}
