"use client";

import {
  Boxes,
  UsersRound,
  Building2,
  Route,
  Activity,
  Stamp,
  HelpCircle,
  Package,
} from "lucide-react";

export type SidebarSection =
  | "all"
  | "citizens"
  | "associations"
  | "relays"
  | "cubes"
  | "activity";

type AppSidebarProps = {
  activeSection: SidebarSection;
  onSectionChange: (section: SidebarSection) => void;
  onOpenPassport: () => void;
  stampsCount: number;
};

const items: Array<{
  id: SidebarSection;
  label: string;
  icon: typeof Boxes;
}> = [
  { id: "all", label: "Explorer", icon: Boxes },
  { id: "citizens", label: "Citoyens", icon: UsersRound },
  { id: "associations", label: "Associations", icon: Building2 },
  { id: "relays", label: "Relais", icon: Route },
  { id: "cubes", label: "Cubes du futur", icon: Package },
  { id: "activity", label: "Activité", icon: Activity },
];

export function AppSidebar({
  activeSection,
  onSectionChange,
  onOpenPassport,
  stampsCount,
}: AppSidebarProps) {
  return (
    <aside className="fixed bottom-0 left-0 top-0 z-40 flex w-[72px] flex-col items-center border-r border-black/10 bg-[#fbfaf7] py-4">
      <div className="grid h-10 w-10 place-items-center rounded-xl bg-[#11110f] text-[14px] font-black tracking-[-0.05em] text-white">
        MA
      </div>

      <nav className="mt-8 flex flex-1 flex-col items-center gap-2" aria-label="Navigation principale">
        {items.map((item) => {
          const Icon = item.icon;
          const active = activeSection === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onSectionChange(item.id)}
              className={`group relative grid h-11 w-11 place-items-center rounded-xl transition ${
                active
                  ? "bg-[#11110f] text-white"
                  : "text-black/45 hover:bg-black/[0.05] hover:text-black"
              }`}
              aria-label={item.label}
              title={item.label}
            >
              <Icon className="h-[18px] w-[18px]" strokeWidth={1.8} />
              <span className="pointer-events-none absolute left-[54px] z-50 hidden whitespace-nowrap rounded-lg bg-[#11110f] px-2.5 py-1.5 text-[11px] font-medium text-white shadow-xl group-hover:block">
                {item.label}
              </span>
            </button>
          );
        })}
      </nav>

      <div className="flex flex-col items-center gap-2">
        <button
          onClick={onOpenPassport}
          className="group relative grid h-11 w-11 place-items-center rounded-xl text-black/45 transition hover:bg-black/[0.05] hover:text-black"
          aria-label="Passeport solidaire"
          title="Passeport solidaire"
        >
          <Stamp className="h-[18px] w-[18px]" strokeWidth={1.8} />
          <span className="absolute right-0 top-0 grid h-4 min-w-4 place-items-center rounded-full bg-[#11110f] px-1 text-[9px] font-bold text-white">
            {stampsCount}
          </span>
          <span className="pointer-events-none absolute left-[54px] z-50 hidden whitespace-nowrap rounded-lg bg-[#11110f] px-2.5 py-1.5 text-[11px] font-medium text-white shadow-xl group-hover:block">
            Passeport solidaire
          </span>
        </button>

        <button
          className="grid h-11 w-11 place-items-center rounded-xl text-black/35 transition hover:bg-black/[0.05] hover:text-black"
          aria-label="Aide"
          title="Aide"
        >
          <HelpCircle className="h-[18px] w-[18px]" strokeWidth={1.8} />
        </button>
      </div>
    </aside>
  );
}
