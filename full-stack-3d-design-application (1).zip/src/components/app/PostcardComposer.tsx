"use client";

import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  Check,
  ImagePlus,
  Printer,
  RotateCcw,
  Save,
  Sparkles,
  UserRound,
  Video,
  X,
} from "lucide-react";
import type { BoxData } from "@/components/Atelier3DScene";
import type { DemoUser } from "@/components/AuthModal";

export type StudioPostcard = {
  id: number;
  boxId: number | null;
  title: string;
  format: string;
  photoUrl: string;
  mediaType?: string;
  portraitUrl?: string | null;
  postcardSource?: string;
  frontTitle: string;
  message: string;
  recipientName: string;
  recipientAddress: string;
  stampLabel: string;
  stampValue: string;
  stampCountry: string;
  stampPrompt?: string | null;
  stampImageUrl?: string | null;
  sealType: string;
  foldedLayout: boolean;
};

type PostcardComposerProps = {
  open: boolean;
  box: BoxData | null;
  user: DemoUser | null;
  postcards: StudioPostcard[];
  onClose: () => void;
  onSaved: () => Promise<void>;
};

const SOURCE_LABELS: Record<string, string> = {
  DON: "Photo du don",
  PARTICULIER: "Portrait particulier",
  EQUIPE: "Photo d’équipe",
  COMMUNICATION: "Communication réseau",
};
const SOURCE_CYCLE = Object.keys(SOURCE_LABELS);
const MAX_MEDIA_BYTES = 6 * 1024 * 1024;

function loadStampPhoto(url: string): Promise<HTMLImageElement | null> {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = () => resolve(null);
    img.src = url;
  });
}

async function generateStampDataUrl(options: {
  photoUrl?: string | null;
  prompt: string;
  value: string;
  country: string;
}): Promise<string> {
  const canvas = document.createElement("canvas");
  const W = 300;
  const H = 372;
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext("2d");
  if (!ctx) return "";

  // Perforated stamp silhouette
  ctx.clearRect(0, 0, W, H);
  ctx.fillStyle = "#fffefa";
  ctx.fillRect(0, 0, W, H);
  ctx.globalCompositeOperation = "destination-out";
  const step = 18;
  const r = 5;
  for (let x = 0; x <= W; x += step) {
    ctx.beginPath();
    ctx.arc(x, 0, r, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.arc(x, H, r, 0, Math.PI * 2);
    ctx.fill();
  }
  for (let y = 0; y <= H; y += step) {
    ctx.beginPath();
    ctx.arc(0, y, r, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.arc(W, y, r, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.globalCompositeOperation = "source-over";

  const photo = options.photoUrl ? await loadStampPhoto(options.photoUrl) : null;
  const px = 26;
  const py = 26;
  const pw = W - 52;
  const ph = 232;

  if (photo) {
    ctx.save();
    ctx.beginPath();
    ctx.rect(px, py, pw, ph);
    ctx.clip();
    ctx.filter = "grayscale(1) contrast(1.08) brightness(1.02)";
    const scale = Math.max(pw / photo.width, ph / photo.height);
    const dw = photo.width * scale;
    const dh = photo.height * scale;
    ctx.drawImage(photo, px + (pw - dw) / 2, py + (ph - dh) / 2, dw, dh);
    ctx.filter = "none";
    ctx.restore();
    ctx.strokeStyle = "rgba(17,17,15,0.25)";
    ctx.lineWidth = 2;
    ctx.strokeRect(px, py, pw, ph);
  } else {
    ctx.fillStyle = "#f0efeb";
    ctx.fillRect(px, py, pw, ph);
    ctx.strokeStyle = "rgba(17,17,15,0.2)";
    ctx.lineWidth = 2;
    ctx.strokeRect(px, py, pw, ph);
    ctx.fillStyle = "#11110f";
    ctx.font = "800 40px Inter";
    ctx.textAlign = "center";
    ctx.fillText("LMA", W / 2, py + ph / 2 + 14);
  }

  ctx.fillStyle = "#11110f";
  ctx.textAlign = "left";
  ctx.font = "800 26px Inter";
  ctx.fillText(options.value.toUpperCase().slice(0, 16), px, H - 78);
  ctx.textAlign = "right";
  ctx.font = "600 12px Inter";
  ctx.fillText("LE MONDE AIME", W - px, H - 80);

  ctx.fillStyle = "rgba(17,17,15,0.62)";
  ctx.textAlign = "center";
  ctx.font = "500 11px IBM Plex Mono";
  const promptText = (options.prompt || "Solidarité citoyenne").toUpperCase();
  ctx.fillText(promptText.slice(0, 34), W / 2, H - 46);
  ctx.fillText(options.country.toUpperCase().slice(0, 34), W / 2, H - 30);

  return canvas.toDataURL("image/png");
}

function fallbackStampDataUrl(label: string, value: string, country: string) {
  const canvas = document.createElement("canvas");
  canvas.width = 200;
  canvas.height = 150;
  const ctx = canvas.getContext("2d");
  if (!ctx) return "";
  ctx.fillStyle = "#fbfaf7";
  ctx.fillRect(0, 0, 200, 150);
  ctx.strokeStyle = "#11110f";
  ctx.lineWidth = 3;
  ctx.setLineDash([4, 3]);
  ctx.strokeRect(4, 4, 192, 142);
  ctx.setLineDash([]);
  ctx.fillStyle = "#11110f";
  ctx.textAlign = "center";
  ctx.font = "800 18px Inter";
  ctx.fillText("LE MONDE", 100, 42);
  ctx.fillText("AIME", 100, 62);
  ctx.beginPath();
  ctx.arc(100, 88, 16, 0, Math.PI * 2);
  ctx.stroke();
  ctx.font = "600 12px Inter";
  ctx.fillText("LMA", 100, 93);
  ctx.font = "500 7px IBM Plex Mono";
  ctx.fillText(label.toUpperCase().slice(0, 26), 100, 118);
  ctx.fillText(`${value.toUpperCase().slice(0, 16)} · ${country.toUpperCase().slice(0, 10)}`, 100, 130);
  return canvas.toDataURL();
}

export function PostcardComposer({
  open,
  box,
  user,
  postcards,
  onClose,
  onSaved,
}: PostcardComposerProps) {
  const base = useMemo<StudioPostcard>(() => {
    const existing = postcards.find((card) => card.boxId === box?.id);
    return (
      existing ?? {
        id: 0,
        boxId: box?.id ?? null,
        title: "Carte postale solidaire",
        format: "POSTCARD",
        photoUrl: box?.items[0]?.photoUrl ?? "",
        mediaType: "IMAGE",
        portraitUrl: null,
        postcardSource: "DON",
        frontTitle: "LE MONDE AIME",
        message: "Bonjour, ce don est disponible. Merci de me prévenir avant tout retrait.",
        recipientName: box?.name ?? "Point de collecte",
        recipientAddress: box?.pickupPoint ?? "",
        stampLabel: "Participation documentée",
        stampValue: "Monde Relais",
        stampCountry: "France",
        stampPrompt: "Solidarité citoyenne",
        stampImageUrl: null,
        sealType: "SCELLÉ SIMPLE",
        foldedLayout: false,
      }
    );
  }, [box, postcards]);

  const [form, setForm] = useState<StudioPostcard>(base);
  const [side, setSide] = useState<"front" | "back">("front");
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [stampEditorOpen, setStampEditorOpen] = useState(false);
  const [stampGenerating, setStampGenerating] = useState(false);
  const [stampDraftPhoto, setStampDraftPhoto] = useState<string | null>(null);
  const [stampDraftPrompt, setStampDraftPrompt] = useState("Solidarité citoyenne");
  const mediaInputRef = useRef<HTMLInputElement | null>(null);
  const stampInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    setForm(base);
    setSide("front");
    setSaved(false);
    setStampEditorOpen(false);
    setStampDraftPrompt(base.stampPrompt || "Solidarité citoyenne");
    setStampDraftPhoto(null);
  }, [base]);

  useEffect(() => {
    if (!open) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [onClose, open]);

  if (!open || !box) return null;

  const userProfileUrl = (user as (DemoUser & { portraitUrl?: string }) | null)?.portraitUrl || null;
  const stampImage = form.stampImageUrl || fallbackStampDataUrl(form.stampLabel, form.stampValue, form.stampCountry);
  const isFlipped = side === "back";
  const isVideo = form.mediaType === "VIDEO";

  const handleImportMedia = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    if (file.size > MAX_MEDIA_BYTES) {
      window.alert("Ce média dépasse 6 Mo. Choisissez un fichier plus léger.");
      event.target.value = "";
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      setForm((prev) => ({
        ...prev,
        photoUrl: String(reader.result),
        mediaType: file.type.startsWith("video/") ? "VIDEO" : "IMAGE",
      }));
    };
    reader.readAsDataURL(file);
    event.target.value = "";
  };

  const handleImportStampPhoto = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    if (file.size > MAX_MEDIA_BYTES) {
      window.alert("Cette photo dépasse 6 Mo.");
      event.target.value = "";
      return;
    }
    const reader = new FileReader();
    reader.onload = () => setStampDraftPhoto(String(reader.result));
    reader.readAsDataURL(file);
    event.target.value = "";
  };

  const generateStamp = async () => {
    setStampGenerating(true);
    try {
      const dataUrl = await generateStampDataUrl({
        photoUrl: stampDraftPhoto,
        prompt: stampDraftPrompt,
        value: form.stampValue,
        country: form.stampCountry,
      });
      setForm((prev) => ({
        ...prev,
        stampImageUrl: dataUrl,
        stampPrompt: stampDraftPrompt,
      }));
    } finally {
      setStampGenerating(false);
    }
  };

  const cycleSource = () => {
    const currentIndex = SOURCE_CYCLE.indexOf(form.postcardSource || "DON");
    const next = SOURCE_CYCLE[(currentIndex + 1) % SOURCE_CYCLE.length];
    setForm((prev) => ({ ...prev, postcardSource: next }));
  };

  const save = async () => {
    setSaving(true);
    try {
      const endpoint = form.id ? `/api/studio/postcards/${form.id}` : "/api/studio";
      await fetch(endpoint, {
        method: form.id ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type: "postcard", ...form, boxId: box.id }),
      });
      await onSaved();
      setSaved(true);
      window.setTimeout(() => setSaved(false), 1800);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-black/30 p-4 backdrop-blur-[2px]">
      <div className="flex w-full max-w-[560px] flex-col items-center py-4">
        <div className="mb-4 flex w-full items-center justify-between">
          <div>
            <span className="font-mono text-[10px] font-medium uppercase tracking-[0.14em] text-white/70">
              Complément de {box.code}
            </span>
            <p className="mt-0.5 text-[13px] font-semibold text-white">Carte postale vivante</p>
          </div>
          <button
            onClick={onClose}
            className="grid h-9 w-9 place-items-center rounded-full border border-white/20 bg-white/10 text-white transition hover:bg-white/20"
            aria-label="Fermer la carte postale"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div style={{ perspective: "1600px" }} className="w-full">
          <div
            style={{
              transformStyle: "preserve-3d",
              transform: isFlipped ? "rotateY(180deg)" : "rotateY(0deg)",
              transition: "transform 0.6s cubic-bezier(.4,.2,.2,1)",
            }}
            className="relative aspect-[3/2] w-full"
          >
            {/* FRONT */}
            <div
              style={{ backfaceVisibility: "hidden" }}
              className="absolute inset-0 overflow-hidden rounded-[10px] border border-black/10 bg-black shadow-[0_25px_60px_rgba(0,0,0,0.35)]"
            >
              {form.photoUrl ? (
                isVideo ? (
                  <video src={form.photoUrl} className="h-full w-full object-cover" autoPlay muted loop playsInline />
                ) : (
                  <img src={form.photoUrl} alt={form.title} className="h-full w-full object-cover" />
                )
              ) : (
                <div className="grid h-full place-items-center bg-[#deddd8] text-[12px] text-black/40">
                  Aucun média — importez une photo ou une vidéo
                </div>
              )}
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent" />

              <div className="absolute left-3 top-3 flex gap-1.5">
                <button
                  onClick={() => mediaInputRef.current?.click()}
                  className="flex items-center gap-1.5 rounded-full bg-black/45 px-3 py-1.5 text-[11px] font-semibold text-white backdrop-blur-md transition hover:bg-black/65"
                >
                  {isVideo ? <Video className="h-3.5 w-3.5" /> : <ImagePlus className="h-3.5 w-3.5" />}
                  Importer média
                </button>
                {isVideo && (
                  <span className="flex items-center gap-1 rounded-full bg-white/90 px-2.5 py-1 text-[9px] font-bold uppercase tracking-[0.1em] text-black">
                    Vivante
                  </span>
                )}
              </div>
              <input ref={mediaInputRef} type="file" accept="image/*,video/*" className="hidden" onChange={handleImportMedia} />

              <button
                onClick={cycleSource}
                className="absolute right-3 top-3 rounded-full bg-black/45 px-2.5 py-1 text-[9px] font-semibold uppercase tracking-[0.1em] text-white backdrop-blur-md transition hover:bg-black/65"
                title="Changer l’usage de la carte"
              >
                {SOURCE_LABELS[form.postcardSource || "DON"]}
              </button>

              <div className="absolute inset-x-4 bottom-4">
                <input
                  value={form.frontTitle}
                  onChange={(event) => setForm({ ...form, frontTitle: event.target.value })}
                  placeholder="LE MONDE AIME"
                  className="w-full border-0 bg-transparent text-[26px] font-black leading-none tracking-[-0.06em] text-white outline-none placeholder:text-white/40"
                />
                <input
                  value={form.title}
                  onChange={(event) => setForm({ ...form, title: event.target.value })}
                  placeholder="Sous-titre de la carte"
                  className="mt-1 w-full border-0 bg-transparent text-[11px] font-medium uppercase tracking-[0.14em] text-white/75 outline-none placeholder:text-white/40"
                />
              </div>
            </div>

            {/* BACK */}
            <div
              style={{ backfaceVisibility: "hidden", transform: "rotateY(180deg)" }}
              className="absolute inset-0 flex rounded-[10px] border border-black/10 bg-[#fffefa] p-4 shadow-[0_25px_60px_rgba(0,0,0,0.35)]"
            >
              <div className="flex min-w-0 flex-1 flex-col border-r border-black/15 pr-4">
                <span className="font-mono text-[9px] font-medium uppercase tracking-[0.13em] text-black/40">Message</span>
                <textarea
                  value={form.message}
                  onChange={(event) => setForm({ ...form, message: event.target.value })}
                  placeholder="Écrivez votre message ici…"
                  className="mt-2 flex-1 resize-none border-0 bg-transparent font-hand text-[19px] leading-[1.4] text-black/80 outline-none placeholder:text-black/30"
                  style={{
                    backgroundImage:
                      "repeating-linear-gradient(transparent, transparent 33px, rgba(17,17,15,0.14) 34px)",
                    backgroundPosition: "0 12px",
                  }}
                />
              </div>

              <div className="flex w-[40%] min-w-0 flex-col pl-4">
                <div className="flex justify-end">
                  {/* Stamp slot: click to customize */}
                  <button
                    onClick={() => setStampEditorOpen((current) => !current)}
                    className={`relative w-[104px] transition ${stampEditorOpen ? "ring-2 ring-black/50 ring-offset-2" : "hover:opacity-80"}`}
                    title="Personnaliser le timbre"
                  >
                    <img src={stampImage} alt="Timbre" className="w-full" />
                    <span className="absolute inset-x-0 -bottom-4 text-center font-mono text-[8px] uppercase tracking-[0.08em] text-black/35">
                      {form.stampImageUrl ? "Timbre personnalisé" : "Cliquer pour personnaliser"}
                    </span>
                  </button>
                </div>

                <div className="mt-6 flex-1">
                  <span className="font-mono text-[9px] font-medium uppercase tracking-[0.13em] text-black/40">Destinataire</span>
                  <input
                    value={form.recipientName}
                    onChange={(event) => setForm({ ...form, recipientName: event.target.value })}
                    placeholder="Nom du destinataire"
                    className="mt-1.5 w-full border-0 border-b border-black/15 bg-transparent pb-1 text-[12px] font-bold outline-none placeholder:text-black/30"
                  />
                  <textarea
                    value={form.recipientAddress}
                    onChange={(event) => setForm({ ...form, recipientAddress: event.target.value })}
                    placeholder="Adresse du point de collecte"
                    rows={3}
                    className="mt-2 w-full resize-none border-0 bg-transparent text-[10px] leading-5 text-black/60 outline-none placeholder:text-black/30"
                    style={{
                      backgroundImage:
                        "repeating-linear-gradient(transparent, transparent 19px, rgba(17,17,15,0.16) 20px)",
                    }}
                  />
                </div>

                <div className="flex items-center justify-between border-t border-black/10 pt-2 font-mono text-[8px] uppercase tracking-[0.08em] text-black/35">
                  <span>{form.stampCountry}</span>
                  <span>LMA</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Inline stamp editor, appears under the card when the stamp slot is clicked */}
        {stampEditorOpen && (
          <div className="mt-6 w-full rounded-[18px] border border-white/20 bg-white/95 p-4 shadow-2xl backdrop-blur-md">
            <div className="mb-3 flex items-center justify-between">
              <span className="font-mono text-[10px] font-medium uppercase tracking-[0.13em] text-black/50">
                Générateur de timbre
              </span>
              <button onClick={() => setStampEditorOpen(false)} className="text-[11px] font-semibold text-black/40 hover:text-black">
                Fermer
              </button>
            </div>

            <div className="flex flex-col gap-3 sm:flex-row">
              <div className="flex w-full flex-col gap-2 sm:w-[190px]">
                <div className="grid h-[84px] w-[68px] place-items-center overflow-hidden rounded border border-black/15 bg-[#f0efeb]">
                  {stampDraftPhoto ? (
                    <img src={stampDraftPhoto} alt="Photo du timbre" className="h-full w-full object-cover grayscale" />
                  ) : (
                    <UserRound className="h-6 w-6 text-black/25" />
                  )}
                </div>
                <button
                  onClick={() => stampInputRef.current?.click()}
                  className="flex items-center justify-center gap-1.5 rounded-full border border-black/20 bg-white px-3 py-2 text-[11px] font-semibold text-black/70 hover:border-black/40"
                >
                  <ImagePlus className="h-3.5 w-3.5" /> Importer photo
                </button>
                {userProfileUrl && (
                  <button
                    onClick={() => setStampDraftPhoto(userProfileUrl)}
                    className="flex items-center justify-center gap-1.5 rounded-full border border-black/20 bg-white px-3 py-2 text-[11px] font-semibold text-black/70 hover:border-black/40"
                  >
                    <UserRound className="h-3.5 w-3.5" /> Mon portrait
                  </button>
                )}
                <input ref={stampInputRef} type="file" accept="image/*" className="hidden" onChange={handleImportStampPhoto} />
              </div>

              <div className="flex-1 space-y-2">
                <div>
                  <label className="mb-1 block font-mono text-[9px] font-medium uppercase tracking-[0.12em] text-black/45">
                    Prompt du timbre
                  </label>
                  <input
                    value={stampDraftPrompt}
                    onChange={(event) => setStampDraftPrompt(event.target.value)}
                    placeholder="Solidarité citoyenne"
                    className="w-full rounded-lg border border-black/15 px-3 py-2 text-[12px] outline-none focus:border-black/40"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="mb-1 block font-mono text-[9px] font-medium uppercase tracking-[0.12em] text-black/45">
                      Valeur
                    </label>
                    <input
                      value={form.stampValue}
                      onChange={(event) => setForm({ ...form, stampValue: event.target.value })}
                      className="w-full rounded-lg border border-black/15 px-3 py-2 text-[12px] outline-none focus:border-black/40"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block font-mono text-[9px] font-medium uppercase tracking-[0.12em] text-black/45">
                      Pays
                    </label>
                    <input
                      value={form.stampCountry}
                      onChange={(event) => setForm({ ...form, stampCountry: event.target.value })}
                      className="w-full rounded-lg border border-black/15 px-3 py-2 text-[12px] outline-none focus:border-black/40"
                    />
                  </div>
                </div>
                <div className="flex gap-2 pt-1">
                  <button
                    onClick={generateStamp}
                    disabled={stampGenerating}
                    className="flex h-9 flex-1 items-center justify-center gap-1.5 rounded-full bg-[#11110f] text-[11px] font-semibold text-white hover:bg-black/75 disabled:opacity-50"
                  >
                    <Sparkles className="h-3.5 w-3.5" />
                    {stampGenerating ? "Génération…" : "Générer le timbre"}
                  </button>
                  {form.stampImageUrl && (
                    <button
                      onClick={() => setForm({ ...form, stampImageUrl: null })}
                      className="h-9 rounded-full border border-black/20 px-3 text-[11px] font-semibold text-black/60 hover:border-black/40"
                    >
                      Timbre générique
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        <button
          onClick={() => setSide(isFlipped ? "front" : "back")}
          className="mt-4 flex items-center gap-2 rounded-full border border-white/25 bg-white/10 px-4 py-2 text-[12px] font-semibold text-white backdrop-blur-md transition hover:bg-white/20"
        >
          <RotateCcw className="h-3.5 w-3.5" />
          {isFlipped ? "Retourner au recto" : "Retourner au verso"}
        </button>

        <div className="mt-5 flex items-center gap-2">
          <button
            onClick={onClose}
            className="h-10 rounded-full border border-white/25 bg-white/10 px-4 text-[12px] font-semibold text-white backdrop-blur-md transition hover:bg-white/20"
          >
            Fermer
          </button>
          <button
            onClick={save}
            disabled={saving}
            className="flex h-10 items-center gap-2 rounded-full bg-white px-5 text-[12px] font-semibold text-black transition hover:bg-white/90 disabled:opacity-50"
          >
            {saved ? <Check className="h-4 w-4" /> : <Save className="h-4 w-4" />}
            {saving ? "Enregistrement…" : saved ? "Enregistré" : "Enregistrer"}
          </button>
          <button
            onClick={() => window.print()}
            className="flex h-10 items-center gap-2 rounded-full border border-white/25 bg-white/10 px-4 text-[12px] font-semibold text-white backdrop-blur-md transition hover:bg-white/20"
          >
            <Printer className="h-4 w-4" /> Imprimer
          </button>
        </div>
      </div>
    </div>
  );
}
