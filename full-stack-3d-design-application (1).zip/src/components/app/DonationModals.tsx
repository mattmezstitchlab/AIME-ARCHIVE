"use client";

import { Box, Building2, Camera, Check, Route, UserRound, X } from "lucide-react";

export const DONATION_PHOTOS = [
  {
    label: "Pull en laine",
    url: "https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?auto=format&fit=crop&w=600&q=80",
  },
  {
    label: "Livres jeunesse",
    url: "https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=600&q=80",
  },
  {
    label: "Peluche",
    url: "https://images.unsplash.com/photo-1559454403-b8fb88521f11?auto=format&fit=crop&w=600&q=80",
  },
  {
    label: "Fournitures scolaires",
    url: "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=600&q=80",
  },
  {
    label: "Manteau",
    url: "https://images.unsplash.com/photo-1544923246-77307dd654cb?auto=format&fit=crop&w=600&q=80",
  },
  {
    label: "Guitare",
    url: "https://images.unsplash.com/photo-1510915361894-db8b60106cb1?auto=format&fit=crop&w=600&q=80",
  },
  {
    label: "Vélo enfant",
    url: "https://images.unsplash.com/photo-1558981806-ec527fa84c39?auto=format&fit=crop&w=600&q=80",
  },
];

export const POSTCARD_IMAGES = [
  {
    label: "Photo du don",
    source: "DON",
    url: DONATION_PHOTOS[0].url,
  },
  {
    label: "Portrait particulier",
    source: "PARTICULIER",
    url: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=600&q=80",
  },
  {
    label: "Photo d’équipe",
    source: "EQUIPE",
    url: "https://images.unsplash.com/photo-1529156069898-49953e39b3ac?auto=format&fit=crop&w=600&q=80",
  },
  {
    label: "Communication réseau",
    source: "COMMUNICATION",
    url: "https://images.unsplash.com/photo-1556761175-b413da4baf72?auto=format&fit=crop&w=600&q=80",
  },
];

export type CreateBoxForm = {
  boxRole: "DONATEUR" | "ASSOCIATION";
  boxType: "CARTON" | "SHOEBOX" | "IRIDESCENT_CUBE";
  name: string;
  pickupPoint: string;
  city: string;
  firstItem: string;
  photoUrl: string;
  condition: string;
  story: string;
  shoeSizeEu: string;
  futureDonationType: string;
  futureDonationValue: string;
  postcardPhotoUrl: string;
  postcardSource: string;
  postcardTitle: string;
  postcardMessage: string;
  stampValue: string;
  relaisNeeded: boolean;
  relaisRoute: string;
};

export type AddDonationForm = {
  name: string;
  photoUrl: string;
  condition: string;
  story: string;
};

type CreateBoxModalProps = {
  open: boolean;
  value: CreateBoxForm;
  submitting: boolean;
  onChange: (next: CreateBoxForm) => void;
  onClose: () => void;
  onSubmit: (event: React.FormEvent) => void;
};

function FieldLabel({ children }: { children: React.ReactNode }) {
  return <label className="mb-1.5 block text-[10px] font-semibold uppercase tracking-[0.12em] text-black/45">{children}</label>;
}

function PhotoPicker({
  value,
  onChange,
}: {
  value: string;
  onChange: (value: string) => void;
}) {
  return (
    <div className="flex gap-2 overflow-x-auto pb-1">
      {DONATION_PHOTOS.map((photo) => (
        <button
          type="button"
          key={photo.url}
          title={photo.label}
          onClick={() => onChange(photo.url)}
          className={`relative h-14 w-14 shrink-0 overflow-hidden rounded-xl border-2 transition ${
            value === photo.url ? "border-black" : "border-transparent opacity-55 hover:opacity-100"
          }`}
        >
          <img src={photo.url} alt={photo.label} className="h-full w-full object-cover" />
          {value === photo.url && (
            <span className="absolute inset-0 grid place-items-center bg-black/25 text-white">
              <Check className="h-4 w-4" />
            </span>
          )}
        </button>
      ))}
    </div>
  );
}

export function CreateBoxModal({
  open,
  value,
  submitting,
  onChange,
  onClose,
  onSubmit,
}: CreateBoxModalProps) {
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/35 p-4 backdrop-blur-sm">
      <div className="max-h-[92vh] w-full max-w-[580px] overflow-y-auto rounded-[24px] border border-black/15 bg-[#fbfaf7] shadow-2xl">
        <div className="sticky top-0 z-10 flex items-start justify-between border-b border-black/10 bg-[#fbfaf7]/95 px-6 py-5 backdrop-blur-xl">
          <div>
            <span className="ui-kicker">Nouvelle boîte</span>
            <h2 className="mt-1 text-[26px] font-extrabold tracking-[-0.05em]">Documenter une mise à disposition</h2>
          </div>
          <button onClick={onClose} className="grid h-9 w-9 place-items-center rounded-full text-black/40 hover:bg-black/[0.06] hover:text-black">
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={onSubmit} className="space-y-5 p-6">
          <section>
            <span className="ui-kicker">01 · Type de boîte</span>
            <div className="mt-3 grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => onChange({ ...value, boxRole: "DONATEUR" })}
                className={`rounded-2xl border p-4 text-left transition ${
                  value.boxRole === "DONATEUR" ? "border-black bg-[#11110f] text-white" : "border-black/10 bg-white hover:border-black/30"
                }`}
              >
                <UserRound className="mb-3 h-5 w-5" />
                <strong className="block text-[12px]">Citoyen donateur</strong>
                <span className={`mt-1 block text-[10px] leading-4 ${value.boxRole === "DONATEUR" ? "text-white/55" : "text-black/45"}`}>
                  Mettre des objets à disposition
                </span>
              </button>
              <button
                type="button"
                onClick={() => onChange({ ...value, boxRole: "ASSOCIATION" })}
                className={`rounded-2xl border p-4 text-left transition ${
                  value.boxRole === "ASSOCIATION" ? "border-black bg-[#11110f] text-white" : "border-black/10 bg-white hover:border-black/30"
                }`}
              >
                <Building2 className="mb-3 h-5 w-5" />
                <strong className="block text-[12px]">Association</strong>
                <span className={`mt-1 block text-[10px] leading-4 ${value.boxRole === "ASSOCIATION" ? "text-white/55" : "text-black/45"}`}>
                  Publier les dons recherchés
                </span>
              </button>
            </div>
          </section>

          <section className="border-t border-black/10 pt-5">
            <span className="ui-kicker">02 · Identité et collecte</span>
            <div className="mt-3 space-y-3">
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => onChange({ ...value, boxType: "CARTON" })}
                  className={`rounded-2xl border p-3 text-left transition ${
                    value.boxType === "CARTON" ? "border-black bg-[#11110f] text-white" : "border-black/10 bg-white hover:border-black/30"
                  }`}
                >
                  <Box className="mb-2 h-4 w-4" />
                  <strong className="block text-[11px]">Carton</strong>
                  <span className={`mt-0.5 block text-[9px] ${value.boxType === "CARTON" ? "text-white/55" : "text-black/45"}`}>
                    Standard
                  </span>
                </button>
                <button
                  type="button"
                  onClick={() => onChange({ ...value, boxType: "SHOEBOX" })}
                  className={`rounded-2xl border p-3 text-left transition ${
                    value.boxType === "SHOEBOX" ? "border-black bg-[#11110f] text-white" : "border-black/10 bg-white hover:border-black/30"
                  }`}
                >
                  <Box className="mb-2 h-4 w-4" />
                  <strong className="block text-[11px]">Chaussures</strong>
                  <span className={`mt-0.5 block text-[9px] ${value.boxType === "SHOEBOX" ? "text-white/55" : "text-black/45"}`}>
                    Pointure EU
                  </span>
                </button>
                <button
                  type="button"
                  onClick={() => onChange({ ...value, boxType: "IRIDESCENT_CUBE" })}
                  className={`rounded-2xl border p-3 text-left transition ${
                    value.boxType === "IRIDESCENT_CUBE" ? "border-black bg-[#11110f] text-white" : "border-black/10 bg-white hover:border-black/30"
                  }`}
                >
                  <Box className="mb-2 h-4 w-4" />
                  <strong className="block text-[11px]">Cube du futur</strong>
                  <span className={`mt-0.5 block text-[9px] ${value.boxType === "IRIDESCENT_CUBE" ? "text-white/55" : "text-black/45"}`}>
                    Énergie & temps
                  </span>
                </button>
              </div>
              <div>
                <FieldLabel>{value.boxRole === "ASSOCIATION" ? "Nom de l’association" : "Nom de la boîte"}</FieldLabel>
                <input
                  required
                  value={value.name}
                  onChange={(event) => onChange({ ...value, name: event.target.value })}
                  placeholder={value.boxRole === "ASSOCIATION" ? "Antenne locale, école, refuge…" : "Boîte de la famille…"}
                  className="w-full rounded-xl border border-black/15 bg-white px-3.5 py-3 text-[13px] outline-none focus:border-black/40"
                />
              </div>
              <div className="grid grid-cols-[1fr_140px] gap-2">
                <div>
                  <FieldLabel>Point de collecte</FieldLabel>
                  <input
                    required
                    value={value.pickupPoint}
                    onChange={(event) => onChange({ ...value, pickupPoint: event.target.value })}
                    className="w-full rounded-xl border border-black/15 bg-white px-3.5 py-3 text-[13px] outline-none focus:border-black/40"
                  />
                </div>
                <div>
                  <FieldLabel>Ville</FieldLabel>
                  <input
                    required
                    value={value.city}
                    onChange={(event) => onChange({ ...value, city: event.target.value })}
                    className="w-full rounded-xl border border-black/15 bg-white px-3.5 py-3 text-[13px] outline-none focus:border-black/40"
                  />
                </div>
              </div>
            </div>
          </section>

          <section className="border-t border-black/10 pt-5">
            <span className="ui-kicker">
              03 · {value.boxType === "IRIDESCENT_CUBE" ? "Don immatériel" : "Premier don"}
            </span>
            <div className="mt-3 space-y-3 rounded-2xl border border-black/10 bg-white p-4">
              {value.boxType === "IRIDESCENT_CUBE" && (
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <FieldLabel>Nature du don</FieldLabel>
                    <select
                      value={value.futureDonationType}
                      onChange={(event) => onChange({ ...value, futureDonationType: event.target.value })}
                      className="w-full rounded-xl border border-black/15 bg-white px-3 py-3 text-[12px] outline-none"
                    >
                      <option value="ENERGY_WATT">Énergie partagée</option>
                      <option value="TIME_CAPSULE">Temps disponible</option>
                      <option value="SKILL_CAPSULE">Compétence transmise</option>
                      <option value="SENSORY_BUBBLE">Expérience accessible</option>
                    </select>
                  </div>
                  <div>
                    <FieldLabel>Valeur mesurable</FieldLabel>
                    <input
                      value={value.futureDonationValue}
                      onChange={(event) => onChange({ ...value, futureDonationValue: event.target.value })}
                      placeholder="120 kWh, 6 heures…"
                      className="w-full rounded-xl border border-black/15 px-3 py-3 text-[12px] outline-none focus:border-black/40"
                    />
                  </div>
                </div>
              )}
              <div>
                <FieldLabel>{value.boxType === "IRIDESCENT_CUBE" ? "Nom de la capsule" : "Objet"}</FieldLabel>
                <input
                  required
                  value={value.firstItem}
                  onChange={(event) => onChange({ ...value, firstItem: event.target.value })}
                  placeholder="Pull en laine, livres, vélo…"
                  className="w-full rounded-xl border border-black/15 px-3.5 py-3 text-[13px] outline-none focus:border-black/40"
                />
              </div>
              {value.boxType !== "IRIDESCENT_CUBE" && (
                <div>
                  <FieldLabel>Photo</FieldLabel>
                  <PhotoPicker value={value.photoUrl} onChange={(photoUrl) => onChange({ ...value, photoUrl })} />
                </div>
              )}
              {value.boxType === "SHOEBOX" && (
                <div>
                  <FieldLabel>Pointure EU</FieldLabel>
                  <input
                    value={value.shoeSizeEu}
                    onChange={(event) => onChange({ ...value, shoeSizeEu: event.target.value })}
                    placeholder="ex. 38, 41, 44"
                    className="w-full rounded-xl border border-black/15 bg-white px-3.5 py-3 text-[12px] outline-none focus:border-black/40"
                  />
                </div>
              )}
              <div className={`grid gap-2 ${value.boxType === "IRIDESCENT_CUBE" ? "grid-cols-1" : "grid-cols-2"}`}>
                {value.boxType !== "IRIDESCENT_CUBE" && (
                  <div>
                    <FieldLabel>État</FieldLabel>
                    <select
                      value={value.condition}
                      onChange={(event) => onChange({ ...value, condition: event.target.value })}
                      className="w-full rounded-xl border border-black/15 bg-white px-3 py-3 text-[12px] outline-none"
                    >
                      <option>Neuf avec étiquette</option>
                      <option>Comme neuf</option>
                      <option>Très bon état</option>
                      <option>Bon état</option>
                    </select>
                  </div>
                )}
                <div>
                  <FieldLabel>{value.boxType === "IRIDESCENT_CUBE" ? "Finalité et bénéficiaire" : "Détails"}</FieldLabel>
                  <input
                    value={value.story}
                    onChange={(event) => onChange({ ...value, story: event.target.value })}
                    className="w-full rounded-xl border border-black/15 px-3 py-3 text-[12px] outline-none focus:border-black/40"
                  />
                </div>
              </div>
            </div>
          </section>

          {value.boxType !== "IRIDESCENT_CUBE" && (
          <section className="border-t border-black/10 pt-5">
            <span className="ui-kicker">04 · Carte postale jointe</span>
            <div className="mt-3 rounded-2xl border border-black/10 bg-white p-4">
              <p className="text-[12px] font-semibold">Une carte postale et un timbre sont générés automatiquement.</p>
              <p className="mt-1 text-[11px] leading-5 text-black/45">
                Elle peut montrer le don, un particulier, une équipe ou une communication du réseau, puis être glissée dans chaque boîte.
              </p>
              <div className="mt-3 grid grid-cols-2 gap-2">
                <div>
                  <FieldLabel>Usage de la carte</FieldLabel>
                  <select
                    value={value.postcardSource}
                    onChange={(event) => onChange({ ...value, postcardSource: event.target.value })}
                    className="w-full rounded-xl border border-black/15 bg-white px-3 py-3 text-[12px] outline-none"
                  >
                    <option value="DON">Photo du don</option>
                    <option value="PARTICULIER">Portrait particulier</option>
                    <option value="EQUIPE">Photo d’équipe</option>
                    <option value="COMMUNICATION">Communication réseau</option>
                  </select>
                </div>
                <div>
                  <FieldLabel>Titre de la carte</FieldLabel>
                  <input
                    value={value.postcardTitle}
                    onChange={(event) => onChange({ ...value, postcardTitle: event.target.value })}
                    placeholder="Message du réseau"
                    className="w-full rounded-xl border border-black/15 bg-white px-3 py-3 text-[12px] outline-none focus:border-black/40"
                  />
                </div>
              </div>
              <div className="mt-3">
                <FieldLabel>Visuel de la carte</FieldLabel>
                <div className="flex gap-2 overflow-x-auto pb-1">
                  {POSTCARD_IMAGES.map((image) => (
                    <button
                      key={image.url}
                      type="button"
                      onClick={() => onChange({ ...value, postcardPhotoUrl: image.url, postcardSource: image.source })}
                      className={`relative h-14 w-20 shrink-0 overflow-hidden rounded-xl border-2 ${value.postcardPhotoUrl === image.url ? "border-black" : "border-transparent opacity-60 hover:opacity-100"}`}
                    >
                      <img src={image.url} alt={image.label} className="h-full w-full object-cover" />
                      {value.postcardPhotoUrl === image.url && <span className="absolute right-1 top-1 rounded-full bg-black p-1 text-white"><Check className="h-3 w-3" /></span>}
                    </button>
                  ))}
                </div>
              </div>
              <div className="mt-3 grid grid-cols-2 gap-2">
                <input
                  value={value.stampValue}
                  onChange={(event) => onChange({ ...value, stampValue: event.target.value })}
                  placeholder="Timbre / série"
                  className="rounded-xl border border-black/15 bg-white px-3 py-3 text-[12px] outline-none focus:border-black/40"
                />
                <input
                  value={value.postcardMessage}
                  onChange={(event) => onChange({ ...value, postcardMessage: event.target.value })}
                  placeholder="Message court au dos"
                  className="rounded-xl border border-black/15 bg-white px-3 py-3 text-[12px] outline-none focus:border-black/40"
                />
              </div>
            </div>
          </section>
          )}

          {value.boxType !== "IRIDESCENT_CUBE" && (
          <section className="border-t border-black/10 pt-5">
            <button
              type="button"
              onClick={() => onChange({ ...value, relaisNeeded: !value.relaisNeeded })}
              className={`flex w-full items-center justify-between rounded-2xl border p-4 text-left transition ${
                value.relaisNeeded ? "border-black bg-black/[0.04]" : "border-black/10 bg-white"
              }`}
            >
              <span className="flex items-center gap-3">
                <Route className="h-5 w-5" />
                <span>
                  <strong className="block text-[12px]">Relais longue distance</strong>
                  <span className="mt-1 block text-[10px] text-black/45">À activer lorsque le don est éloigné</span>
                </span>
              </span>
              <span className={`h-5 w-9 rounded-full p-0.5 transition ${value.relaisNeeded ? "bg-[#11110f]" : "bg-black/10"}`}>
                <span className={`block h-4 w-4 rounded-full bg-white shadow transition ${value.relaisNeeded ? "translate-x-4" : "translate-x-0"}`} />
              </span>
            </button>
            {value.relaisNeeded && (
              <input
                value={value.relaisRoute}
                onChange={(event) => onChange({ ...value, relaisRoute: event.target.value })}
                placeholder="Trajet ou disponibilité proposée"
                className="mt-2 w-full rounded-xl border border-black/15 bg-white px-3.5 py-3 text-[12px] outline-none focus:border-black/40"
              />
            )}
          </section>
          )}

          <div className="flex justify-end gap-2 border-t border-black/10 pt-5">
            <button type="button" onClick={onClose} className="h-11 rounded-full border border-black/15 px-5 text-[12px] font-semibold hover:bg-black/[0.04]">
              Annuler
            </button>
            <button type="submit" disabled={submitting} className="h-11 rounded-full bg-[#11110f] px-6 text-[12px] font-semibold text-white hover:bg-black/75 disabled:opacity-50">
              {submitting ? "Création…" : "Créer la boîte"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

type AddDonationModalProps = {
  open: boolean;
  boxName: string;
  value: AddDonationForm;
  submitting: boolean;
  onChange: (next: AddDonationForm) => void;
  onClose: () => void;
  onSubmit: (event: React.FormEvent) => void;
};

export function AddDonationModal({
  open,
  boxName,
  value,
  submitting,
  onChange,
  onClose,
  onSubmit,
}: AddDonationModalProps) {
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/35 p-4 backdrop-blur-sm">
      <div className="w-full max-w-[480px] rounded-[24px] border border-black/15 bg-[#fbfaf7] shadow-2xl">
        <div className="flex items-start justify-between border-b border-black/10 px-6 py-5">
          <div>
            <span className="ui-kicker">Nouveau don</span>
            <h2 className="mt-1 text-[23px] font-extrabold tracking-[-0.045em]">Ajouter à « {boxName} »</h2>
          </div>
          <button onClick={onClose} className="grid h-9 w-9 place-items-center rounded-full text-black/40 hover:bg-black/[0.06] hover:text-black">
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={onSubmit} className="space-y-4 p-6">
          <div>
            <FieldLabel>Objet</FieldLabel>
            <input
              required
              value={value.name}
              onChange={(event) => onChange({ ...value, name: event.target.value })}
              placeholder="Décrivez le don"
              className="w-full rounded-xl border border-black/15 bg-white px-3.5 py-3 text-[13px] outline-none focus:border-black/40"
            />
          </div>
          <div>
            <FieldLabel>Photo du don</FieldLabel>
            <PhotoPicker value={value.photoUrl} onChange={(photoUrl) => onChange({ ...value, photoUrl })} />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <FieldLabel>État</FieldLabel>
              <select
                value={value.condition}
                onChange={(event) => onChange({ ...value, condition: event.target.value })}
                className="w-full rounded-xl border border-black/15 bg-white px-3 py-3 text-[12px] outline-none"
              >
                <option>Neuf avec étiquette</option>
                <option>Comme neuf</option>
                <option>Très bon état</option>
                <option>Bon état</option>
              </select>
            </div>
            <div>
              <FieldLabel>Détails</FieldLabel>
              <input
                value={value.story}
                onChange={(event) => onChange({ ...value, story: event.target.value })}
                className="w-full rounded-xl border border-black/15 bg-white px-3 py-3 text-[12px] outline-none focus:border-black/40"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 border-t border-black/10 pt-5">
            <button type="button" onClick={onClose} className="h-11 rounded-full border border-black/15 px-5 text-[12px] font-semibold hover:bg-black/[0.04]">
              Annuler
            </button>
            <button type="submit" disabled={submitting} className="flex h-11 items-center gap-2 rounded-full bg-[#11110f] px-6 text-[12px] font-semibold text-white hover:bg-black/75 disabled:opacity-50">
              <Camera className="h-4 w-4" />
              {submitting ? "Ajout…" : "Ajouter le don"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
