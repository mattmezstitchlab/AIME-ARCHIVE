"use client";

import { Award, CheckCircle2, Stamp, X } from "lucide-react";

export type CitizenStampData = {
  id: number;
  stampCode: string;
  stampTitle: string;
  stampCity: string;
  stampColor: string;
  awardedToName: string;
  awardedReason: string;
  createdAt?: string;
};

type PasseportSolidaireModalProps = {
  isOpen: boolean;
  onClose: () => void;
  stamps: CitizenStampData[];
  userName: string;
  badgeCode: string;
};

export function PasseportSolidaireModal({
  isOpen,
  onClose,
  stamps,
  userName,
  badgeCode,
}: PasseportSolidaireModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/35 p-4 backdrop-blur-sm">
      <div className="flex max-h-[90vh] w-full max-w-[720px] flex-col overflow-hidden rounded-[24px] border border-black/15 bg-[#fbfaf7] shadow-2xl">
        <div className="flex shrink-0 items-center justify-between border-b border-black/10 px-6 py-5">
          <div className="flex items-center gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-full bg-[#11110f] text-white">
              <Stamp className="h-4 w-4" />
            </div>
            <div>
              <span className="ui-kicker">Passeport solidaire</span>
              <h2 className="mt-1 text-[22px] font-extrabold tracking-[-0.045em]">{userName}</h2>
            </div>
          </div>
          <button onClick={onClose} className="grid h-9 w-9 place-items-center rounded-full text-black/40 hover:bg-black/[0.06] hover:text-black">
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="min-h-0 flex-1 overflow-y-auto p-6">
          <div className="mb-6 grid grid-cols-2 rounded-2xl border border-black/10 bg-white">
            <div className="border-r border-black/10 p-4">
              <span className="ui-kicker">Identifiant</span>
              <p className="mt-2 font-mono text-[12px] font-medium">{badgeCode}</p>
            </div>
            <div className="p-4">
              <span className="ui-kicker">Participations validées</span>
              <p className="mt-2 flex items-center gap-2 text-[16px] font-bold">
                <Award className="h-4 w-4" />
                {stamps.length}
              </p>
            </div>
          </div>

          <div className="mb-3 flex items-center justify-between">
            <span className="ui-kicker">Historique des participations</span>
            <span className="text-[10px] text-black/35">Dons · Relais · Collectes</span>
          </div>

          {stamps.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-black/20 py-12 text-center text-[12px] text-black/40">
              Aucune participation validée.
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
              {stamps.map((stamp) => (
                <article key={stamp.id} className="rounded-2xl border border-black/10 bg-white p-4">
                  <div className="mb-3 flex items-center justify-between">
                    <span className="flex items-center gap-1.5 font-mono text-[9px] uppercase tracking-[0.08em] text-black/45">
                      <CheckCircle2 className="h-3.5 w-3.5" />
                      {stamp.stampCity}
                    </span>
                    <span className="font-mono text-[8px] text-black/25">{stamp.stampCode}</span>
                  </div>
                  <h3 className="text-[12px] font-semibold leading-5">{stamp.stampTitle}</h3>
                  <p className="mt-2 text-[10px] leading-4 text-black/48">{stamp.awardedReason}</p>
                  <p className="mt-3 border-t border-black/8 pt-2 text-[9px] text-black/35">
                    Attribué à {stamp.awardedToName}
                  </p>
                </article>
              ))}
            </div>
          )}
        </div>

        <div className="flex shrink-0 items-center justify-between border-t border-black/10 bg-[#fbfaf7] px-6 py-4">
          <p className="text-[10px] text-black/40">Les participations sont liées aux actions enregistrées.</p>
          <button onClick={onClose} className="h-10 rounded-full bg-[#11110f] px-5 text-[11px] font-semibold text-white hover:bg-black/75">
            Fermer
          </button>
        </div>
      </div>
    </div>
  );
}
