"use client";

import React, { useEffect, useRef } from "react";
import * as THREE from "three";
import { drawCitizenStamp, drawRelayStamp } from "@/lib/stamps";

export interface BoxItemData {
  id?: number;
  name: string;
  itemType: string;
  colorHex: string;
  photoUrl?: string;
  condition?: string;
  story?: string;
  shoeSizeEu?: string | null;
  futureDonationType?: string | null;
  futureDonationValue?: string | null;
  addedByUserName?: string | null;
}

export interface BoxData {
  id: number;
  code: string;
  boxRole: string; // DONATEUR | ASSOCIATION | POINT_RELAIS
  boxType?: string; // CARTON | SHOEBOX
  kind: string;
  name: string;
  pickupPoint: string;
  city: string;
  description: string;
  note1: string;
  note2: string;
  relaisNeeded: boolean;
  relaisRoute: string | null;
  stampsText: string;
  shoeSizeEu?: string | null;
  posX: number;
  posZ: number;
  rotY: number;
  items: BoxItemData[];
}

interface Atelier3DSceneProps {
  boxes: BoxData[];
  selectedBoxId: number | null;
  openBoxIds: Set<number>;
  onSelectBox: (box: BoxData) => void;
  onToggleOpen: (boxId: number) => void;
  onBoxRepositioned: (boxId: number, posX: number, posZ: number) => void;
  registerCameraReset: (resetFn: () => void) => void;
}

const clamp = (v: number, a: number, b: number) =>
  Math.max(a, Math.min(b, v));

function srand(s: number) {
  let seed = s | 0;
  return function () {
    seed = (seed * 9301 + 49297) % 233280;
    return seed / 233280;
  };
}

function easeOutBounce(x: number) {
  const n1 = 7.5625,
    d1 = 2.75;
  if (x < 1 / d1) return n1 * x * x;
  if (x < 2 / d1) return n1 * (x -= 1.5 / d1) * x + 0.75;
  if (x < 2.5 / d1) return n1 * (x -= 2.25 / d1) * x + 0.9375;
  return n1 * (x -= 2.625 / d1) * x + 0.984375;
}

function rr(
  x: CanvasRenderingContext2D,
  a: number,
  b: number,
  w: number,
  h: number,
  r: number
) {
  x.beginPath();
  x.moveTo(a + r, b);
  x.arcTo(a + w, b, a + w, b + h, r);
  x.arcTo(a + w, b + h, a, b + h, r);
  x.arcTo(a, b + h, a, b, r);
  x.arcTo(a, b, a + w, b, r);
  x.closePath();
}

function arcText(
  x: CanvasRenderingContext2D,
  str: string,
  cx: number,
  cy: number,
  r: number,
  a0: number,
  a1: number,
  flip: boolean
) {
  const n = str.length;
  for (let i = 0; i < n; i++) {
    const a = a0 + (a1 - a0) * (n === 1 ? 0.5 : i / (n - 1));
    x.save();
    x.translate(cx + Math.cos(a) * r, cy + Math.sin(a) * r);
    x.rotate(a + (flip ? -Math.PI / 2 : Math.PI / 2));
    x.fillText(str[i], 0, 0);
    x.restore();
  }
}

const TINTS = [
  0xffffff,
  0xf6e8d4,
  0xeeddc6,
  0xfaf0de,
  0xe9d5bd,
  0xf2e5d1,
];

const OPEN_A = 1.98;

export function Atelier3DScene({
  boxes,
  selectedBoxId,
  openBoxIds,
  onSelectBox,
  onToggleOpen,
  onBoxRepositioned,
  registerCameraReset,
}: Atelier3DSceneProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Keep live refs for callbacks so pointer handlers don't go stale
  const boxesRef = useRef<BoxData[]>(boxes);
  boxesRef.current = boxes;
  const selectedBoxIdRef = useRef<number | null>(selectedBoxId);
  selectedBoxIdRef.current = selectedBoxId;
  const openBoxIdsRef = useRef<Set<number>>(openBoxIds);
  openBoxIdsRef.current = openBoxIds;
  const onSelectBoxRef = useRef(onSelectBox);
  onSelectBoxRef.current = onSelectBox;
  const onToggleOpenRef = useRef(onToggleOpen);
  onToggleOpenRef.current = onToggleOpen;
  const onBoxRepositionedRef = useRef(onBoxRepositioned);
  onBoxRepositionedRef.current = onBoxRepositioned;

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // WebGL Renderer setup
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.02;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.innerHTML = "";
    container.appendChild(renderer.domElement);
    const canvas = renderer.domElement;
    const maxAniso = renderer.capabilities.getMaxAnisotropy();

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0xf6f1e8);
    scene.fog = new THREE.Fog(0xf6f1e8, 16, 42);

    const camera = new THREE.PerspectiveCamera(
      42,
      window.innerWidth / window.innerHeight,
      0.1,
      120
    );

    // Warm solidarity atelier lighting
    const hemi = new THREE.HemisphereLight(0xfffaf0, 0xcfc4b0, 1.05);
    scene.add(hemi);

    const keyLight = new THREE.DirectionalLight(0xfff1dd, 2.4);
    keyLight.position.set(7, 11, 5);
    keyLight.castShadow = true;
    keyLight.shadow.mapSize.set(2048, 2048);
    keyLight.shadow.camera.left = -12;
    keyLight.shadow.camera.right = 12;
    keyLight.shadow.camera.top = 12;
    keyLight.shadow.camera.bottom = -12;
    keyLight.shadow.camera.near = 2;
    keyLight.shadow.camera.far = 32;
    keyLight.shadow.bias = -0.0004;
    keyLight.shadow.normalBias = 0.02;
    scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(0xdfe6ee, 0.7);
    fillLight.position.set(-6, 5, -4);
    scene.add(fillLight);

    const textureLoader = new THREE.TextureLoader();

    // Canvas texture generator helpers
    function canvasTex(
      w: number,
      h: number,
      draw: (ctx: CanvasRenderingContext2D, w: number, h: number) => void
    ) {
      const c = document.createElement("canvas");
      c.width = w;
      c.height = h;
      const x = c.getContext("2d")!;
      draw(x, w, h);
      const t = new THREE.CanvasTexture(c);
      t.colorSpace = THREE.SRGBColorSpace;
      t.anisotropy = maxAniso;
      return t;
    }

    // Kraft paper surface
    const cardTex = canvasTex(512, 512, (x, w, h) => {
      x.fillStyle = "#c79a63";
      x.fillRect(0, 0, w, h);
      const img = x.getImageData(0, 0, w, h);
      const d = img.data;
      for (let i = 0; i < d.length; i += 4) {
        const n = (Math.random() - 0.5) * 24;
        d[i] += n;
        d[i + 1] += n * 0.9;
        d[i + 2] += n * 0.7;
      }
      x.putImageData(img, 0, 0);
      x.globalAlpha = 0.07;
      for (let i = 0; i < 300; i++) {
        x.strokeStyle = Math.random() > 0.5 ? "#8a6a3f" : "#e8ca97";
        x.lineWidth = 1;
        const sx = Math.random() * w,
          sy = Math.random() * h,
          a = Math.random() * Math.PI,
          l = 12 + Math.random() * 70;
        x.beginPath();
        x.moveTo(sx, sy);
        x.lineTo(sx + Math.cos(a) * l, sy + Math.sin(a) * l);
        x.stroke();
      }
      x.globalAlpha = 0.05;
      x.fillStyle = "#6e4f2a";
      for (let yy = 0; yy < h; yy += 7) x.fillRect(0, yy, w, 2);
      x.globalAlpha = 1;
    });

    // Corrugated carton edge
    const edgeTex = canvasTex(256, 256, (x, w, h) => {
      x.fillStyle = "#b98a55";
      x.fillRect(0, 0, w, h);
      for (let i = 0; i < w; i += 9) {
        x.fillStyle = "#8a6238";
        x.fillRect(i, 0, 3, h);
        x.fillStyle = "#d8ac74";
        x.fillRect(i + 5, 0, 2, h);
      }
    });

    // LE MONDE AIME Solidary Stencil on box side
    const stencilTex = canvasTex(512, 128, (x, w, h) => {
      x.clearRect(0, 0, w, h);
      x.font = "900 52px Inter, sans-serif";
      x.textBaseline = "middle";
      x.fillStyle = "rgba(38,32,26,.85)";
      x.textAlign = "center";
      x.fillText("LE MONDE AIME", w / 2, h / 2 - 10);
      x.font = '700 17px "IBM Plex Mono", monospace';
      x.fillStyle = "#2c2b28";
      x.fillText("BOÎTE VIRTUELLE DE DONS · RELAIS CITOYEN", w / 2, h / 2 + 28);
    });

    // Tampons officiels partagés avec la landing (source unique : src/lib/stamps.ts)
    const stampTex = canvasTex(256, 256, (ctx) => drawCitizenStamp(ctx, 256));
    const relaisStampTex = canvasTex(320, 200, (ctx) => drawRelayStamp(ctx, 320, 200));

    // Handwritten fountain pen script
    function texHand(text: string) {
      return canvasTex(512, 144, (x, w, h) => {
        x.clearRect(0, 0, w, h);
        let size = 64;
        x.font = "600 " + size + "px Caveat, cursive";
        while (x.measureText(text).width > 452 && size > 28) {
          size -= 4;
          x.font = "600 " + size + "px Caveat, cursive";
        }
        x.fillStyle = "rgba(48,40,30,.92)";
        x.textAlign = "center";
        x.textBaseline = "middle";
        x.fillText(text, w / 2, h / 2);
      });
    }

    const hashStr = (s: string) =>
      s.split("").reduce((a, c) => a + c.charCodeAt(0), 0) * 7 + 3;

    function drawBarcode(
      x: CanvasRenderingContext2D,
      x0: number,
      y0: number,
      w: number,
      h: number,
      seed: number
    ) {
      const r = srand(seed);
      let bx = x0;
      x.fillStyle = "rgba(32,29,24,.85)";
      while (bx < x0 + w - 3) {
        const bw = 1.5 + r() * 4;
        x.fillRect(bx, y0, bw, h);
        bx += bw + 1.5 + r() * 4;
      }
    }

    // High resolution LE MONDE AIME Solidarity Card on top flap
    function texShipLabel(def: BoxData) {
      return canvasTex(512, 352, (x, w, h) => {
        x.clearRect(0, 0, w, h);
        x.fillStyle = "rgba(255,255,255,.97)";
        rr(x, 6, 6, 500, 340, 10);
        x.fill();
        const borderColor =
          def.boxRole === "ASSOCIATION"
            ? "#2c2b28"
            : def.relaisNeeded
            ? "#51504c"
            : "#201d18";
        x.strokeStyle = borderColor;
        x.lineWidth = 4;
        rr(x, 6, 6, 500, 340, 10);
        x.stroke();
        x.fillStyle = "#201d18";
        x.textAlign = "left";
        x.textBaseline = "alphabetic";
        x.font = "900 34px Inter, sans-serif";
        x.fillText("LE MONDE AIME", 28, 54);

        // Role badge badge text
        x.fillStyle =
          def.boxRole === "ASSOCIATION" ? "#2c2b28" : "#242321";
        x.font = '700 15px "IBM Plex Mono", monospace';
        x.textAlign = "right";
        x.fillText(
          def.boxRole === "ASSOCIATION"
            ? "APPEL AUX DONS · ASSO"
            : "BOÎTE VIRTUELLE DE DONS",
          482,
          50
        );

        x.fillStyle = "#2c2b28";
        x.fillRect(28, 68, 454, 3);

        x.textAlign = "left";
        x.fillStyle = "rgba(32,29,24,.55)";
        x.font = '600 14px "IBM Plex Mono", monospace';
        x.fillText(
          def.boxRole === "ASSOCIATION"
            ? "ASSOCIATION / REFUGE"
            : "DONATEUR CITOYEN",
          28,
          98
        );
        x.fillStyle = "#201d18";
        x.font = "700 31px Inter, sans-serif";
        let nm = def.name.toUpperCase();
        if (x.measureText(nm).width > 280) nm = nm.slice(0, 22) + "…";
        x.fillText(nm, 28, 134);

        x.fillStyle = "rgba(32,29,24,.55)";
        x.font = '600 14px "IBM Plex Mono", monospace';
        x.fillText("POINT DE COLLECTE / PROXIMITÉ", 28, 168);
        x.fillStyle = "#201d18";
        x.font = '600 22px "IBM Plex Mono", monospace';
        let pt = def.pickupPoint;
        if (x.measureText(pt).width > 280) pt = pt.slice(0, 24) + "…";
        x.fillText(pt, 28, 202);

        x.strokeStyle = "rgba(32,29,24,.4)";
        x.lineWidth = 2;
        x.strokeRect(330, 96, 122, 60);
        x.font = '700 32px "IBM Plex Mono", monospace';
        x.textAlign = "center";
        x.fillText(def.code, 391, 138);

        x.textAlign = "left";
        drawBarcode(x, 28, 236, 434, 70, hashStr(def.code));

        x.font = '700 14px "IBM Plex Mono", monospace';
        x.fillStyle = "#242321";
        x.fillText("★ TAMPON CITOYEN CERTIFIÉ LE MONDE AIME", 28, 332);
      });
    }

    // Side barcode & pickup label
    function texSideLabel(def: BoxData) {
      return canvasTex(256, 160, (x, w, h) => {
        x.clearRect(0, 0, w, h);
        x.fillStyle = "rgba(255,255,255,.96)";
        rr(x, 4, 4, 248, 152, 8);
        x.fill();
        x.strokeStyle = "rgba(32,29,24,.3)";
        x.lineWidth = 2;
        rr(x, 4, 4, 248, 152, 8);
        x.stroke();
        x.fillStyle = "#201d18";
        x.textAlign = "left";
        x.textBaseline = "alphabetic";
        x.font = '700 28px "IBM Plex Mono", monospace';
        x.fillText(def.code, 18, 40);
        x.font = "600 15px Inter, sans-serif";
        x.fillText(def.city.toUpperCase() + " · POINT COLLECTE", 18, 66);
        drawBarcode(x, 18, 86, 220, 48, hashStr(def.code) + 5);
      });
    }

    // Packing tape
    const tapeTex = canvasTex(256, 256, (x, w, h) => {
      x.clearRect(0, 0, w, h);
      x.fillStyle = "rgba(255,251,238,.72)";
      x.fillRect(0, 0, w, h);
      for (let i = 0; i < 900; i++) {
        x.fillStyle =
          "rgba(" +
          ((210 + Math.random() * 40) | 0) +
          "," +
          ((200 + Math.random() * 40) | 0) +
          "," +
          ((170 + Math.random() * 40) | 0) +
          "," +
          (0.04 + Math.random() * 0.08) +
          ")";
        x.fillRect(
          Math.random() * w,
          Math.random() * h,
          2 + Math.random() * 3,
          1 + Math.random() * 2
        );
      }
      x.fillStyle = "rgba(255,255,255,.5)";
      x.fillRect(0, 0, 3, h);
      x.fillRect(w - 3, 0, 3, h);
      x.fillStyle = "rgba(160,140,110,.25)";
      x.fillRect(3, 0, 1, h);
      x.fillRect(w - 4, 0, 1, h);
    });

    const tapeMat = new THREE.MeshStandardMaterial({
      map: tapeTex,
      transparent: true,
      roughness: 0.25,
      depthWrite: false,
      color: 0xfff8ea,
    });

    // Atelier Floor
    const groundTex = canvasTex(1024, 1024, (x, w, h) => {
      const g = x.createRadialGradient(w / 2, h / 2, 60, w / 2, h / 2, w / 2);
      g.addColorStop(0, "#ffffff");
      g.addColorStop(0.45, "#f6f1e8");
      g.addColorStop(1, "#e8e1d3");
      x.fillStyle = g;
      x.fillRect(0, 0, w, h);
      for (let i = 0; i < 2500; i++) {
        x.fillStyle = "rgba(120,100,70," + Math.random() * 0.05 + ")";
        x.fillRect(Math.random() * w, Math.random() * h, 1.5, 1.5);
      }
    });

    const ground = new THREE.Mesh(
      new THREE.CircleGeometry(40, 64),
      new THREE.MeshStandardMaterial({ map: groundTex, roughness: 1 })
    );
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    scene.add(ground);

    // Golden selection halo under selected parcel
    const ring = new THREE.Mesh(
      new THREE.RingGeometry(0.95, 1.04, 64),
      new THREE.MeshBasicMaterial({
        color: 0x2c2b28,
        transparent: true,
        opacity: 0.8,
        side: THREE.DoubleSide,
      })
    );
    ring.rotation.x = -Math.PI / 2;
    ring.position.y = 0.012;
    ring.visible = false;
    ring.raycast = () => {};
    scene.add(ring);

    const paperMat = new THREE.MeshStandardMaterial({
      color: 0xf6f1e3,
      roughness: 0.9,
    });

    const decoMatCache = new Map<
      THREE.Texture,
      THREE.MeshStandardMaterial
    >();
    function matFor(tex: THREE.Texture) {
      if (!decoMatCache.has(tex)) {
        decoMatCache.set(
          tex,
          new THREE.MeshStandardMaterial({
            map: tex,
            transparent: true,
            roughness: 0.85,
            metalness: 0,
          })
        );
      }
      return decoMatCache.get(tex)!;
    }
    function sh(m: THREE.Mesh) {
      m.castShadow = true;
      m.receiveShadow = true;
    }

    // Build physical 3D objects placed inside box + POLAROID PHOTO CARD of the Don
    function buildItem3D(it: BoxItemData, idx: number) {
      const g = new THREE.Group();
      const rnd = srand(idx * 17 + 3);
      const colorNum = parseInt(it.colorHex.replace("#", ""), 16) || 0x2c2b28;
      const M = (c: number, r?: number) =>
        new THREE.MeshStandardMaterial({
          color: c,
          roughness: r === undefined ? 0.88 : r,
        });
      const A = (m: THREE.Mesh, y: number) => {
        m.position.y = y;
        sh(m);
        g.add(m);
        return m;
      };

      // Physical Don 3D geometry
      switch (it.itemType) {
        case "shoe": {
          const left = new THREE.Mesh(
            new THREE.BoxGeometry(0.26, 0.11, 0.12),
            M(colorNum, 0.78)
          );
          left.position.set(-0.08, 0.06, 0.02);
          left.rotation.y = 0.08;
          sh(left);
          g.add(left);
          const right = new THREE.Mesh(
            new THREE.BoxGeometry(0.26, 0.11, 0.12),
            M(colorNum, 0.78)
          );
          right.position.set(0.08, 0.06, -0.02);
          right.rotation.y = -0.08;
          sh(right);
          g.add(right);
          break;
        }
        case "book":
          A(
            new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.09, 0.26), M(colorNum)),
            0.045
          );
          A(
            new THREE.Mesh(new THREE.BoxGeometry(0.345, 0.055, 0.245), paperMat),
            0.07
          );
          break;
        case "fold":
          A(
            new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.12, 0.28), M(colorNum)),
            0.06
          );
          A(
            new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.125, 0.09), paperMat),
            0.062
          );
          break;
        case "ball":
          A(
            new THREE.Mesh(
              new THREE.SphereGeometry(0.13, 20, 16),
              M(colorNum, 0.7)
            ),
            0.13
          );
          break;
        case "jar":
          A(
            new THREE.Mesh(
              new THREE.CylinderGeometry(0.1, 0.1, 0.2, 18),
              M(colorNum, 0.4)
            ),
            0.1
          );
          A(
            new THREE.Mesh(
              new THREE.CylinderGeometry(0.105, 0.105, 0.035, 18),
              M(0xb9b0a4, 0.5)
            ),
            0.216
          );
          break;
        case "toy":
          {
            const c = A(
              new THREE.Mesh(
                new THREE.BoxGeometry(0.18, 0.18, 0.18),
                M(colorNum, 0.8)
              ),
              0.09
            );
            c.rotation.y = rnd();
          }
          break;
        default: // gift
          A(
            new THREE.Mesh(
              new THREE.BoxGeometry(0.24, 0.18, 0.24),
              M(colorNum, 0.75)
            ),
            0.09
          );
          A(
            new THREE.Mesh(
              new THREE.BoxGeometry(0.26, 0.185, 0.05),
              M(0xe8d9b0, 0.6)
            ),
            0.09
          );
          break;
      }

      // POLAROID PHOTO TICKET OF THE DON RESTING ON TOP OF THE ITEM
      const polaroidCanvas = canvasTex(256, 310, (x, w, h) => {
        // Polaroid white card frame
        x.fillStyle = "#FFFEFA";
        x.fillRect(0, 0, w, h);
        x.strokeStyle = "rgba(32,29,24,.22)";
        x.lineWidth = 3;
        x.strokeRect(2, 2, w - 4, h - 4);

        // Photo rectangle frame
        x.fillStyle = "#EBE5D8";
        x.fillRect(16, 16, w - 32, 220);

        // Text below polaroid
        x.fillStyle = "#201D18";
        x.textAlign = "center";
        x.font = "700 17px Inter, sans-serif";
        let nm = it.name.toUpperCase();
        if (x.measureText(nm).width > 220) nm = nm.slice(0, 18) + "…";
        x.fillText(nm, w / 2, 266);

        x.fillStyle = "#242321";
        x.font = '700 13px "IBM Plex Mono", monospace';
        x.fillText("★ PHOTO DON LE MONDE AIME", w / 2, 292);
      });

      // Load real photo if available onto polaroid canvas asynchronously
      if (it.photoUrl) {
        textureLoader.load(
          it.photoUrl,
          (loadedTex) => {
            loadedTex.colorSpace = THREE.SRGBColorSpace;
          },
          undefined,
          () => {}
        );
      }

      const polaroidMesh = new THREE.Mesh(
        new THREE.PlaneGeometry(0.2, 0.24),
        new THREE.MeshStandardMaterial({
          map: polaroidCanvas,
          roughness: 0.7,
          side: THREE.DoubleSide,
        })
      );
      polaroidMesh.rotation.x = -Math.PI / 2 + 0.18;
      polaroidMesh.rotation.z = (rnd() - 0.5) * 0.45;
      polaroidMesh.position.set(0.06, 0.22, 0.04);
      sh(polaroidMesh);
      g.add(polaroidMesh);

      const hMap: Record<string, number> = {
        book: 0.11,
        fold: 0.135,
        ball: 0.27,
        jar: 0.245,
        envelope: 0.05,
        toy: 0.19,
        tool: 0.14,
        plant: 0.38,
        gift: 0.2,
      };

      const tag = new THREE.Mesh(
        new THREE.PlaneGeometry(0.12, 0.05),
        new THREE.MeshBasicMaterial({
          color: 0xfffdf4,
          side: THREE.DoubleSide,
        })
      );
      tag.rotation.x = -Math.PI / 2;
      tag.rotation.z = (rnd() - 0.5) * 0.9;
      tag.position.y = (hMap[it.itemType] || 0.15) + 0.006;
      g.add(tag);
      return g;
    }

    interface SceneBoxRuntime {
      id: number;
      data: BoxData;
      root: THREE.Group;
      flaps: {
        front: THREE.Group;
        back: THREE.Group;
        left: THREE.Group;
        right: THREE.Group;
      };
      contentGroup: THREE.Group;
      openT: number;
      openGoal: number;
      lift: number;
      liftGoal: number;
      tiltX: number;
      tiltZ: number;
      tiltGoalX: number;
      tiltGoalZ: number;
      dropIn: number | null;
    }

    const sceneBoxes: SceneBoxRuntime[] = [];

    function populateContents(b: SceneBoxRuntime) {
      const g = b.contentGroup;
      while (g.children.length) {
        const c = g.children.pop()!;
        c.traverse((o) => {
          if (
            (o as THREE.Mesh).geometry &&
            (o as THREE.Mesh).geometry.type !== "shared"
          ) {
            (o as THREE.Mesh).geometry.dispose();
          }
        });
        g.remove(c);
      }
      // Un cube cristallin ne contient jamais d'objets carton : son don est
      // immatériel et représenté par le cœur lumineux.
      if (b.data.boxType === "IRIDESCENT_CUBE") return;

      const items = b.data.items || [];
      const n = Math.min(items.length, 9);
      const rows = n <= 2 ? 1 : n <= 6 ? 2 : 3;
      const cols = Math.ceil(n / rows);
      const sx = Math.min(0.45, 1.3 / Math.max(cols, 1));
      const sz = Math.min(0.48, 0.9 / Math.max(rows - 1, 1));

      items.slice(0, n).forEach((it, i) => {
        const r = Math.floor(i / cols);
        const c0 = i % cols;
        const rowCount = r === rows - 1 ? n - cols * (rows - 1) : cols;
        const xc = (c0 - (rowCount - 1) / 2) * sx;
        const zc = (r - (rows - 1) / 2) * sz;
        const m = buildItem3D(it, i);
        m.position.set(clamp(xc, -0.6, 0.6), 0.05, clamp(zc, -0.4, 0.4));
        m.rotation.y = (srand(i * 31 + 7)() - 0.5) * 1.2;
        m.userData.baseY = 0.05;
        g.add(m);
      });
    }

    function createSceneBox(def: BoxData, index: number, isNewDrop = false) {
      const isCube = def.boxType === "IRIDESCENT_CUBE";
      const isShoeBox = def.boxType === "SHOEBOX";
      const W = isCube ? 1.4 : isShoeBox ? 1.95 : 1.7,
        D = isCube ? 1.4 : isShoeBox ? 1.02 : 1.25,
        H = isCube ? 1.4 : isShoeBox ? 0.46 : 0.82,
        T = 0.05,
        TF = 0.045,
        L = D / 2 + 0.015;
      const root = new THREE.Group();
      const tint = TINTS[index % TINTS.length];
      const matO = new THREE.MeshStandardMaterial({ map: cardTex, color: tint, roughness: 0.94 });
      const matI = new THREE.MeshStandardMaterial({ map: cardTex, color: 0xb59d7f, roughness: 0.98 });
      const matE = new THREE.MeshStandardMaterial({ map: edgeTex, color: tint, roughness: 0.96 });
      const E = matE;
      const add = (m: THREE.Mesh, x: number, y: number, z: number) => {
        m.position.set(x, y, z);
        sh(m);
        root.add(m);
        return m;
      };

      let cubeLid: THREE.Group | null = null;

      if (isCube) {
        // Cube dichroïque : blocs de verre coloré assemblés, aucun carton.
        const CUBE_COLORS = [
          0xff2d6f, 0xffb400, 0x00d4ff, 0x7b2dff,
          0x00ff9d, 0xff5a00, 0x2d6bff, 0xff00d4,
        ];
        const half = W / 2;
        const gap = 0.012;
        const block = half - gap;

        const makeGlass = (color: number) =>
          new THREE.MeshPhysicalMaterial({
            color,
            metalness: 0,
            roughness: 0.03,
            transmission: 0.92,
            thickness: 0.9,
            ior: 1.55,
            iridescence: 1,
            iridescenceIOR: 1.9,
            iridescenceThicknessRange: [120, 780],
            clearcoat: 1,
            clearcoatRoughness: 0.02,
            transparent: true,
            opacity: 0.9,
            side: THREE.DoubleSide,
          });

        // Socle inférieur : 4 blocs fixes
        let colorIndex = 0;
        for (const sx of [-1, 1]) {
          for (const sz of [-1, 1]) {
            const mesh = new THREE.Mesh(
              new THREE.BoxGeometry(block, block, block),
              makeGlass(CUBE_COLORS[colorIndex % CUBE_COLORS.length])
            );
            mesh.position.set((sx * half) / 2, block / 2 + gap, (sz * half) / 2);
            mesh.castShadow = true;
            root.add(mesh);
            colorIndex++;
          }
        }

        // Couvercle : 4 blocs de verre qui se soulèvent à l'ouverture
        cubeLid = new THREE.Group();
        cubeLid.position.y = half + gap;
        cubeLid.userData.baseY = half + gap;
        root.add(cubeLid);
        for (const sx of [-1, 1]) {
          for (const sz of [-1, 1]) {
            const mesh = new THREE.Mesh(
              new THREE.BoxGeometry(block, block, block),
              makeGlass(CUBE_COLORS[colorIndex % CUBE_COLORS.length])
            );
            mesh.position.set((sx * half) / 2, block / 2, (sz * half) / 2);
            mesh.castShadow = true;
            cubeLid.add(mesh);
            colorIndex++;
          }
        }

        // Cœur lumineux central
        const core = new THREE.Mesh(
          new THREE.IcosahedronGeometry(0.24, 2),
          new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.85 })
        );
        core.position.y = H / 2;
        core.userData.isCubeCore = true;
        root.add(core);

        const halo = new THREE.Mesh(
          new THREE.IcosahedronGeometry(0.4, 1),
          new THREE.MeshBasicMaterial({
            color: 0x9bf6ff,
            wireframe: true,
            transparent: true,
            opacity: 0.4,
          })
        );
        halo.position.y = H / 2;
        halo.userData.isCubeHalo = true;
        root.add(halo);
      } else {
        add(new THREE.Mesh(new THREE.BoxGeometry(W, T, D), matO), 0, T / 2, 0);
        add(new THREE.Mesh(new THREE.BoxGeometry(W, H, T), [E, E, E, E, matO, matI]), 0, T + H / 2, D / 2 - T / 2);
        add(new THREE.Mesh(new THREE.BoxGeometry(W, H, T), [E, E, E, E, matI, matO]), 0, T + H / 2, -(D / 2 - T / 2));
        add(new THREE.Mesh(new THREE.BoxGeometry(T, H, D - 2 * T), [matO, matI, E, E, E, E]), -(W / 2 - T / 2), T + H / 2, 0);
        add(new THREE.Mesh(new THREE.BoxGeometry(T, H, D - 2 * T), [matI, matO, E, E, E, E]), W / 2 - T / 2, T + H / 2, 0);
      }

      const fMat = [E, E, matO, matI, E, E];
      function mkFlap(
        w: number,
        d: number,
        px: number,
        py: number,
        pz: number,
        mx: number,
        mz: number
      ) {
        const piv = new THREE.Group();
        piv.position.set(px, py, pz);
        root.add(piv);
        const m = new THREE.Mesh(new THREE.BoxGeometry(w, TF, d), fMat);
        m.position.set(mx, 0, mz);
        sh(m);
        piv.add(m);
        return piv;
      }

      const emptyFlap = () => {
        const pivot = new THREE.Group();
        root.add(pivot);
        return pivot;
      };

      const flaps = isCube
        ? {
            // Le couvercle est en verre, jamais en carton.
            front: cubeLid ?? emptyFlap(),
            back: emptyFlap(),
            left: emptyFlap(),
            right: emptyFlap(),
          }
        : isShoeBox
        ? {
            front: mkFlap(W - 2 * T, D - 2 * T, 0, T + H + TF / 2, 0, 0, 0),
            back: emptyFlap(),
            left: emptyFlap(),
            right: emptyFlap(),
          }
        : {
            front: mkFlap(W - 2 * T, L, 0, T + H + TF / 2, D / 2 - T / 2, 0, -L / 2),
            back: mkFlap(W - 2 * T, L, 0, T + H + TF / 2, -(D / 2 - T / 2), 0, L / 2),
            left: mkFlap(L, D - 2 * T, -(W / 2 - T / 2), T + H - TF / 2, 0, L / 2, 0),
            right: mkFlap(L, D - 2 * T, W / 2 - T / 2, T + H - TF / 2, 0, -L / 2, 0),
          };

      const rnd = srand(def.id * 13 + 5);
      function deco(
        tex: THREE.Texture,
        w: number,
        h: number,
        parent: THREE.Group,
        x: number,
        z: number,
        rot?: number,
        y?: number
      ) {
        const g = new THREE.PlaneGeometry(w, h);
        g.rotateZ(rot || 0);
        g.rotateX(-Math.PI / 2);
        const m = new THREE.Mesh(g, matFor(tex));
        m.position.set(x, y === undefined ? TF / 2 + 0.004 : y, z);
        parent.add(m);
        return m;
      }
      function upright(
        tex: THREE.Texture,
        w: number,
        h: number,
        x: number,
        y: number,
        z: number,
        rotZ?: number,
        rotY?: number
      ) {
        const g = new THREE.PlaneGeometry(w, h);
        g.rotateZ(rotZ || 0);
        g.rotateY(rotY || 0);
        const m = new THREE.Mesh(g, matFor(tex));
        m.position.set(x, y, z);
        root.add(m);
        return m;
      }
      function tapeFlat(
        parent: THREE.Group,
        x: number,
        z: number,
        len?: number,
        wid?: number,
        y?: number
      ) {
        const g = new THREE.PlaneGeometry(wid || 0.09, len || 0.56);
        g.rotateX(-Math.PI / 2);
        const m = new THREE.Mesh(g, tapeMat);
        m.position.set(x, y === undefined ? TF / 2 + 0.009 : y, z);
        m.renderOrder = 3;
        parent.add(m);
        return m;
      }

      const sizeTex = canvasTex(256, 128, (x, w, h) => {
        x.clearRect(0, 0, w, h);
        x.fillStyle = "rgba(255,255,255,.95)";
        rr(x, 4, 4, w - 8, h - 8, 8);
        x.fill();
        x.strokeStyle = "rgba(17,17,15,.3)";
        x.lineWidth = 2;
        rr(x, 4, 4, w - 8, h - 8, 8);
        x.stroke();
        x.fillStyle = "#11110f";
        x.textAlign = "center";
        x.font = "800 34px Inter, sans-serif";
        x.fillText(`EU ${def.shoeSizeEu || "--"}`, w / 2, 52);
        x.font = '500 12px "IBM Plex Mono", monospace';
        x.fillText("BOÎTE À CHAUSSURES", w / 2, 84);
      });

      if (isCube) {
        // Pure crystal cube, no kraft stickers or paper tape
      } else if (isShoeBox) {
        deco(texShipLabel(def), 0.74, 0.5, flaps.front, 0, 0, 0, TF / 2 + 0.006);
        deco(sizeTex, 0.38, 0.18, flaps.front, 0.48, -0.2, -0.04, TF / 2 + 0.007);
        deco(stampTex, 0.36, 0.36, flaps.front, -0.56, 0.16, 0.04, TF / 2 + 0.007);
        upright(sizeTex, 0.42, 0.2, W / 2 + 0.005, 0.24, 0, 0, Math.PI / 2);
        upright(stencilTex, 0.72, 0.18, 0, 0.24, D / 2 + 0.006, 0, 0);
      } else {
        // Top flaps stickers
        deco(texShipLabel(def), 0.62, 0.42, flaps.front, 0.3, -0.3, -0.05 - 0.04 * rnd());
        if (def.relaisNeeded) {
          deco(
            relaisStampTex,
            0.38,
            0.23,
            flaps.front,
            -0.45,
            -0.36,
            0.12 + 0.05 * rnd()
          );
        }
        tapeFlat(flaps.front, 0.55, -0.36);
        tapeFlat(flaps.front, -0.55, -0.36);

        deco(stampTex, 0.42, 0.42, flaps.back, -0.42, 0.3, 0.1 * rnd());
        if (def.note1) {
          deco(
            texHand(def.note1),
            0.72,
            0.2,
            flaps.back,
            0.3,
            0.26,
            -0.06 + 0.1 * rnd()
          );
        }
        tapeFlat(flaps.back, 0.55, 0.36);
        tapeFlat(flaps.back, -0.55, 0.36);

        upright(stencilTex, 0.88, 0.22, -0.12, 0.5, D / 2 + 0.004, 0, 0);
        upright(texSideLabel(def), 0.5, 0.31, 0.48, 0.35, D / 2 + 0.005, 0.02, 0);
      }

      {
        const tm = new THREE.Mesh(
          new THREE.PlaneGeometry(0.09, 0.9),
          tapeMat
        );
        tm.position.set(-0.7, 0.46, D / 2 + 0.008);
        tm.renderOrder = 3;
        root.add(tm);
      }
      {
        const g = new THREE.PlaneGeometry(0.36, 0.36);
        g.rotateZ(0.12 * rnd());
        g.rotateY(Math.PI / 2);
        const m = new THREE.Mesh(g, matFor(stampTex));
        m.position.set(W / 2 + 0.004, 0.46, -0.05);
        root.add(m);
      }
      if (def.note2) {
        const g = new THREE.PlaneGeometry(0.8, 0.22);
        g.rotateY(Math.PI);
        const m = new THREE.Mesh(g, matFor(texHand(def.note2)));
        m.position.set(0.1, 0.5, -(D / 2 + 0.005));
        root.add(m);
      }

      const contentGroup = new THREE.Group();
      root.add(contentGroup);

      root.position.set(def.posX, 0, def.posZ);
      root.rotation.y = def.rotY;

      const isOpen = openBoxIdsRef.current.has(def.id);
      const runtime: SceneBoxRuntime = {
        id: def.id,
        data: def,
        root,
        flaps,
        contentGroup,
        openT: isOpen ? 1 : 0,
        openGoal: isOpen ? 1 : 0,
        lift: 0,
        liftGoal: 0,
        tiltX: 0,
        tiltZ: 0,
        tiltGoalX: 0,
        tiltGoalZ: 0,
        dropIn: isNewDrop ? performance.now() : null,
      };

      root.userData.boxRuntime = runtime;
      populateContents(runtime);
      scene.add(root);
      sceneBoxes.push(runtime);
      return runtime;
    }

    boxes.forEach((b, idx) => createSceneBox(b, idx, false));

    // Smooth Orbit Camera
    const cam = {
      theta: -0.35,
      phi: 1.06,
      radius: 10.6,
      target: new THREE.Vector3(0, 0.5, 0),
      sTheta: 0.35,
      sPhi: 1.34,
      sRadius: 17.5,
      sTarget: new THREE.Vector3(0, 0.5, 0),
    };

    let lastInteract = performance.now();
    const interact = () => {
      lastInteract = performance.now();
    };

    function focusCameraOn(runtime: SceneBoxRuntime) {
      cam.target.set(
        runtime.root.position.x,
        0.5,
        runtime.root.position.z
      );
      cam.radius = 6.4;
      cam.phi = 1.0;
    }

    function overviewCamera() {
      cam.target.set(0, 0.5, 0);
      cam.radius = 10.6;
      cam.phi = 1.06;
      interact();
    }

    registerCameraReset(() => overviewCamera());

    // Raycaster interactions
    const raycaster = new THREE.Raycaster();
    const pointer = new THREE.Vector2();
    const groundPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);

    function setPointer(e: PointerEvent) {
      pointer.x = (e.clientX / window.innerWidth) * 2 - 1;
      pointer.y = -(e.clientY / window.innerHeight) * 2 + 1;
    }

    function pickBoxRuntime(e: PointerEvent): SceneBoxRuntime | null {
      setPointer(e);
      raycaster.setFromCamera(pointer, camera);
      const hits = raycaster.intersectObjects(scene.children, true);
      for (const h of hits) {
        let o: THREE.Object3D | null = h.object;
        while (o && !o.userData.boxRuntime) o = o.parent;
        if (o && o.userData.boxRuntime) {
          return o.userData.boxRuntime as SceneBoxRuntime;
        }
      }
      return null;
    }

    let drag: {
      mode: "box" | "orbit";
      box?: SceneBoxRuntime;
      sx?: number;
      sy?: number;
      px: number;
      py: number;
      moved?: boolean;
    } | null = null;

    const handlePointerDown = (e: PointerEvent) => {
      canvas.setPointerCapture(e.pointerId);
      interact();
      const hit = pickBoxRuntime(e);
      if (hit) {
        drag = {
          mode: "box",
          box: hit,
          sx: e.clientX,
          sy: e.clientY,
          px: e.clientX,
          py: e.clientY,
          moved: false,
        };
        hit.liftGoal = 0.22;
      } else {
        drag = {
          mode: "orbit",
          px: e.clientX,
          py: e.clientY,
        };
      }
      canvas.style.cursor = "grabbing";
    };

    const handlePointerMove = (e: PointerEvent) => {
      interact();
      if (!drag) {
        canvas.style.cursor = pickBoxRuntime(e) ? "pointer" : "grab";
        return;
      }
      if (drag.mode === "orbit") {
        cam.theta -= (e.clientX - drag.px) * 0.0052;
        cam.phi = clamp(cam.phi - (e.clientY - drag.py) * 0.0038, 0.3, 1.42);
      } else if (drag.box && drag.sx !== undefined && drag.sy !== undefined) {
        const b = drag.box;
        if (
          Math.abs(e.clientX - drag.sx) + Math.abs(e.clientY - drag.sy) >
          7
        ) {
          drag.moved = true;
        }
        setPointer(e);
        raycaster.setFromCamera(pointer, camera);
        const p = new THREE.Vector3();
        if (raycaster.ray.intersectPlane(groundPlane, p)) {
          const nx = clamp(p.x, -8, 8);
          const nz = clamp(p.z, -8, 8);
          b.tiltGoalZ = clamp(-(nx - b.root.position.x) * 1.6, -0.3, 0.3);
          b.tiltGoalX = clamp((nz - b.root.position.z) * 1.6, -0.3, 0.3);
          b.root.position.set(nx, 0, nz);
        }
      }
      drag.px = e.clientX;
      drag.py = e.clientY;
    };

    const handlePointerUp = (e: PointerEvent) => {
      if (drag && drag.mode === "box" && drag.box) {
        const b = drag.box;
        b.liftGoal = 0;
        b.tiltGoalX = 0;
        b.tiltGoalZ = 0;
        if (!drag.moved) {
          if (selectedBoxIdRef.current === b.id) {
            onToggleOpenRef.current(b.id);
            b.openGoal = b.openGoal > 0.5 ? 0 : 1;
          } else {
            onSelectBoxRef.current(b.data);
            focusCameraOn(b);
          }
        } else {
          onBoxRepositionedRef.current(
            b.id,
            b.root.position.x,
            b.root.position.z
          );
        }
      }
      drag = null;
      canvas.style.cursor = "grab";
    };

    const handleWheel = (e: WheelEvent) => {
      e.preventDefault();
      interact();
      cam.radius = clamp(cam.radius * (1 + e.deltaY * 0.0011), 4.2, 22);
    };

    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };

    canvas.addEventListener("pointerdown", handlePointerDown);
    canvas.addEventListener("pointermove", handlePointerMove);
    canvas.addEventListener("pointerup", handlePointerUp);
    canvas.addEventListener("pointercancel", handlePointerUp);
    canvas.addEventListener("wheel", handleWheel, { passive: false });
    window.addEventListener("resize", handleResize);

    // Animation Loop
    const clock = new THREE.Clock();
    let frameId: number;

    const animate = () => {
      frameId = requestAnimationFrame(animate);
      const dt = Math.min(clock.getDelta(), 0.05);
      const t = performance.now();

      if (t - lastInteract > 12000 && !drag) {
        cam.theta += dt * 0.04;
      }

      cam.sTheta += (cam.theta - cam.sTheta) * 0.09;
      cam.sPhi += (cam.phi - cam.sPhi) * 0.09;
      cam.sRadius += (cam.radius - cam.sRadius) * 0.07;
      cam.sTarget.lerp(cam.target, 0.08);

      const sp = Math.sin(cam.sPhi);
      camera.position.set(
        cam.sTarget.x + cam.sRadius * sp * Math.sin(cam.sTheta),
        cam.sTarget.y + cam.sRadius * Math.cos(cam.sPhi),
        cam.sTarget.z + cam.sRadius * sp * Math.cos(cam.sTheta)
      );
      camera.lookAt(cam.sTarget);

      for (const b of sceneBoxes) {
        const shouldBeOpen = openBoxIdsRef.current.has(b.id);
        b.openGoal = shouldBeOpen ? 1 : 0;
        b.openT += (b.openGoal - b.openT) * Math.min(1, dt * 4.6);
        const k = b.openT;
        // Grands volets (avant/arrière) d'abord, petits volets ensuite
        // pour éviter qu'ils se traversent à l'ouverture.
        const largeK = Math.max(0, Math.min(1, k / 0.58));
        const smallK = Math.max(0, Math.min(1, (k - 0.48) / 0.52));
        if (b.data.boxType === "IRIDESCENT_CUBE") {
          const lid = b.flaps.front;
          const lidBase = (lid.userData.baseY as number) ?? 0;
          lid.position.y = lidBase + k * 0.85;
          lid.rotation.y = k * 0.6;
          b.root.children.forEach((child) => {
            if (child.userData.isCubeCore) {
              const pulse = 1 + Math.sin(t * 0.003) * 0.08 + k * 0.35;
              child.scale.setScalar(pulse);
            }
            if (child.userData.isCubeHalo) {
              child.rotation.y += dt * 0.5;
              child.rotation.x += dt * 0.22;
              (child as THREE.Mesh).scale.setScalar(1 + k * 0.5);
            }
          });
        } else if (b.data.boxType === "SHOEBOX") {
          b.flaps.front.rotation.x = -k * 1.18;
          b.flaps.back.rotation.x = 0;
          b.flaps.left.rotation.z = 0;
          b.flaps.right.rotation.z = 0;
        } else {
          b.flaps.front.rotation.x = largeK * OPEN_A;
          b.flaps.back.rotation.x = -largeK * OPEN_A;
          b.flaps.left.rotation.z = smallK * 1.85;
          b.flaps.right.rotation.z = -smallK * 1.85;
        }

        b.contentGroup.children.forEach((it, i) => {
          const base = it.userData.baseY || 0.05;
          it.position.y =
            base + k * 0.34 + Math.sin(t * 0.0011 + i * 1.7) * 0.008 * k;
        });

        b.lift += (b.liftGoal - b.lift) * 0.14;
        b.tiltX += (b.tiltGoalX - b.tiltX) * 0.14;
        b.tiltZ += (b.tiltGoalZ - b.tiltZ) * 0.14;
        b.tiltGoalX *= 0.86;
        b.tiltGoalZ *= 0.86;

        let y = b.lift;
        if (b.dropIn) {
          const p = (t - b.dropIn) / 950;
          if (p >= 1) b.dropIn = null;
          else y += (1 - easeOutBounce(Math.min(p, 1))) * 3.2;
        }
        b.root.position.y = y;
        b.root.rotation.x = b.tiltX;
        b.root.rotation.z = b.tiltZ;
      }

      const activeBox = sceneBoxes.find(
        (b) => b.id === selectedBoxIdRef.current
      );
      if (activeBox) {
        ring.visible = true;
        const s = 1.12 * (1 + Math.sin(t * 0.004) * 0.03);
        ring.scale.set(s, s, 1);
        (ring.material as THREE.MeshBasicMaterial).opacity =
          0.55 + 0.3 * ((1 + Math.sin(t * 0.004)) / 2);
        ring.position.x = activeBox.root.position.x;
        ring.position.z = activeBox.root.position.z;
      } else {
        ring.visible = false;
      }

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(frameId);
      canvas.removeEventListener("pointerdown", handlePointerDown);
      canvas.removeEventListener("pointermove", handlePointerMove);
      canvas.removeEventListener("pointerup", handlePointerUp);
      canvas.removeEventListener("pointercancel", handlePointerUp);
      canvas.removeEventListener("wheel", handleWheel);
      window.removeEventListener("resize", handleResize);
      renderer.dispose();
    };
  }, [boxes, registerCameraReset]);

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 z-0 cursor-grab active:cursor-grabbing"
    />
  );
}
