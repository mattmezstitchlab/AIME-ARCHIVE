"use client";

import React, { useState } from "react";
import { Check, Link2, MapPin, Printer, Route, X } from "lucide-react";
import type { BoxData } from "./Atelier3DScene";

type ShippingLabelModalProps = {
  box: BoxData | null;
  onClose: () => void;
};

export function ShippingLabelModal({ box, onClose }: ShippingLabelModalProps) {
  const [copied, setCopied] = useState(false);
  if (!box) return null;

  const copyLink = () => {
    navigator.clipboard.writeText(
      `${window.location.origin}/?boite=${encodeURIComponent(box.code)}`
    );
    setCopied(true);
    window.setTimeout(() => setCopied(false), 2200);
  };

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/35 p-4 backdrop-blur-sm">
      <div className="w-full max-w-[560px] rounded-[24px] border border-black/15 bg-[#fbfaf7] shadow-2xl">
        <div className="flex items-center justify-between border-b border-black/10 px-6 py-5">
          <div>
            <span className="ui-kicker">Fiche publique</span>
            <h2 className="mt-1 text-[22px] font-extrabold tracking-[-0.045em]">LE MONDE AIME</h2>
          </div>
          <button onClick={onClose} className="grid h-9 w-9 place-items-center rounded-full text-black/40 hover:bg-black/[0.06] hover:text-black">
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="p-6">
          <article className="rounded-2xl border-2 border-black bg-white p-5">
            <div className="flex items-start justify-between border-b border-black pb-4">
              <div>
                <p className="font-mono text-[10px] uppercase tracking-[0.12em] text-black/45">Boîte virtuelle</p>
                <p className="mt-1 font-mono text-[28px] font-semibold tracking-[-0.04em]">{box.code}</p>
              </div>
              <div className="text-right">
                <p className="text-[10px] font-semibold uppercase tracking-[0.12em] text-black/45">
                  {box.boxRole === "ASSOCIATION" ? "Association" : "Citoyen"}
                </p>
                <p className="mt-1 text-[12px] font-semibold">{box.city}</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-5 py-5">
              <div>
                <span className="ui-kicker">Titulaire</span>
                <h3 className="mt-2 text-[17px] font-bold leading-tight">{box.name}</h3>
              </div>
              <div>
                <span className="ui-kicker">Point de collecte</span>
                <p className="mt-2 flex items-start gap-1.5 text-[12px] font-medium leading-5">
                  <MapPin className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                  {box.pickupPoint}
                </p>
              </div>
            </div>

            {box.relaisNeeded && (
              <div className="flex items-start gap-2 border-y border-black/15 py-3 text-[11px]">
                <Route className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                <span><strong>Relais actif.</strong> {box.relaisRoute}</span>
              </div>
            )}

            <div className="mt-5 flex h-12 items-stretch justify-between gap-5">
              <div className="flex flex-1 items-stretch gap-[2px] overflow-hidden">
                {[...(box.code + box.name)].map((character, index) => (
                  <span
                    key={`${character}-${index}`}
                    className="bg-black"
                    style={{
                      width: `${(character.charCodeAt(0) % 4) + 1}px`,
                      height: `${100 - (index % 3) * 14}%`,
                    }}
                  />
                ))}
              </div>
              <div className="grid h-12 w-12 grid-cols-5 gap-[1px] bg-white p-1 ring-1 ring-black">
                {Array.from({ length: 25 }).map((_, index) => (
                  <span key={index} className={(index * 7 + box.id) % 3 ? "bg-black" : "bg-white"} />
                ))}
              </div>
            </div>
            <p className="mt-2 font-mono text-[8px] uppercase tracking-[0.13em] text-black/45">
              lemondeaime.org · {box.code} · fiche de mise à disposition
            </p>
          </article>

          <div className="mt-5 flex items-center justify-between gap-3">
            <button onClick={copyLink} className="flex h-10 items-center gap-2 rounded-full border border-black/15 px-4 text-[11px] font-semibold hover:border-black/35">
              {copied ? <Check className="h-3.5 w-3.5" /> : <Link2 className="h-3.5 w-3.5" />}
              {copied ? "Lien copié" : "Copier le lien"}
            </button>
            <button onClick={() => window.print()} className="flex h-10 items-center gap-2 rounded-full bg-[#11110f] px-5 text-[11px] font-semibold text-white hover:bg-black/75">
              <Printer className="h-3.5 w-3.5" />
              Imprimer la fiche
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
