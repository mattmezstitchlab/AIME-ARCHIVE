import { db } from "@/db";
import {
  users,
  boxes,
  boxItems,
  shipmentLogs,
  citizenStamps,
  postcards,
  documentLabels,
} from "@/db/schema";
import { count } from "drizzle-orm";

const DON_PHOTOS = {
  pullLaine:
    "https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?auto=format&fit=crop&w=600&q=80",
  livresJeunesse:
    "https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=600&q=80",
  pelucheOurs:
    "https://images.unsplash.com/photo-1559454403-b8fb88521f11?auto=format&fit=crop&w=600&q=80",
  chaussures:
    "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=600&q=80",
  crystalCore:
    "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=600&q=80",
  portraitClara:
    "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=600&q=80",
  portraitThomas:
    "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=600&q=80",
};

export const INITIAL_BOXES = [
  {
    code: "DON-01",
    boxRole: "DONATEUR",
    boxType: "CARTON",
    kind: "Vêtements & Hiver",
    name: "Boîte de Clara Moreau",
    pickupPoint: "Kiosque Citoyen Voltaire · Paris 11e",
    city: "Paris",
    description:
      "Je mets à disposition 3 pulls en laine mérinos lavés avec soin et un manteau d'hiver enfant. Remise au point de collecte ou via relais solidaire.",
    note1: "donner change le monde",
    note2: "photo du don vérifiée",
    relaisNeeded: false,
    relaisRoute: "Remise locale directe",
    stampsText: "Participation documentée",
    shoeSizeEu: null,
    posX: 0.15,
    posZ: 3.35,
    rotY: 0.06,
    items: [
      {
        name: "Pull en laine mérinos écru",
        itemType: "fold",
        colorHex: "#bdb6a8",
        photoUrl: DON_PHOTOS.pullLaine,
        condition: "Comme neuf",
        story: "Tricoté main, taille M, idéal pour passer l'hiver au chaud.",
        shoeSizeEu: null,
        futureDonationType: null,
        futureDonationValue: null,
      },
    ],
  },
  {
    code: "CUB-02",
    boxRole: "DONATEUR",
    boxType: "IRIDESCENT_CUBE",
    kind: "Don du futur · Énergie & Temps",
    name: "Cube Cristallin · Watt-Solidarité",
    pickupPoint: "Hub Innovation Solidaire · Paris 13e",
    city: "Paris",
    description:
      "Cube iridescent scellé par cryptographie quantique : transfert direct de 120 kWh de surplus d'énergie solaire et 6 heures de mentorat numérique.",
    note1: "don du futur · énergie pure",
    note2: "zéro matière, 100% impact",
    relaisNeeded: true,
    relaisRoute: "Transfert réseau instantané",
    stampsText: "Cube cristallin vérifié",
    shoeSizeEu: null,
    posX: -2.4,
    posZ: 1.8,
    rotY: 0.32,
    items: [
      {
        name: "Capsule Watt-Solidarité & Mentorat",
        itemType: "gift",
        colorHex: "#e0aaff",
        photoUrl: DON_PHOTOS.crystalCore,
        condition: "Actif & crypté",
        story: "120 kWh solaires partagés + 6h de mentorat code/langues pour un jeune étudiant.",
        shoeSizeEu: null,
        futureDonationType: "ENERGY_WATT",
        futureDonationValue: "120 kWh + 6h mentorat",
      },
    ],
  },
  {
    code: "SHO-03",
    boxRole: "DONATEUR",
    boxType: "SHOEBOX",
    kind: "Chaussures",
    name: "Boîte chaussures · Sarah M.",
    pickupPoint: "Point relais Oberkampf · Paris 11e",
    city: "Paris",
    description:
      "Boîte à chaussures dédiée à une paire de baskets propres et prêtes à être remises. Pointure affichée pour éviter toute ambiguïté.",
    note1: "chaussures disponibles",
    note2: "pointure vérifiée",
    relaisNeeded: false,
    relaisRoute: "Remise locale directe",
    stampsText: "Pointure documentée",
    shoeSizeEu: "39",
    posX: 2.3,
    posZ: 2.1,
    rotY: -0.45,
    items: [
      {
        name: "Paire de baskets blanches",
        itemType: "shoe",
        colorHex: "#9b978d",
        photoUrl: DON_PHOTOS.chaussures,
        condition: "Très bon état",
        story: "Semelles propres, pointure 39, idéale pour usage quotidien.",
        shoeSizeEu: "39",
        futureDonationType: null,
        futureDonationValue: null,
      },
    ],
  },
  {
    code: "ASSO-04",
    boxRole: "ASSOCIATION",
    boxType: "CARTON",
    kind: "Appel aux dons · Enfance",
    name: "LE MONDE AIME · Antenne Lyon",
    pickupPoint: "Local Solidaire Guillotière · Lyon 7e",
    city: "Lyon",
    description:
      "Nous recherchons des livres jeunesse illustrés et des jeux éducatifs complets pour les familles accompagnées ce mois-ci.",
    note1: "appel aux dons",
    note2: "point de collecte déclaré",
    relaisNeeded: true,
    relaisRoute: "Relais citoyen Paris → Lyon disponible",
    stampsText: "Collecte structurée",
    shoeSizeEu: null,
    posX: -3.35,
    posZ: 0.8,
    rotY: -1.25,
    items: [
      {
        name: "Lot de 12 albums illustrés jeunesse",
        itemType: "book",
        colorHex: "#8f897d",
        photoUrl: DON_PHOTOS.livresJeunesse,
        condition: "Comme neuf",
        story: "Donné par une famille parisienne via un trajet solidaire.",
        shoeSizeEu: null,
        futureDonationType: null,
        futureDonationValue: null,
      },
    ],
  },
];

export async function ensureSeeded(forceReset = false) {
  if (forceReset) {
    await db.delete(documentLabels);
    await db.delete(postcards);
    await db.delete(citizenStamps);
    await db.delete(shipmentLogs);
    await db.delete(boxItems);
    await db.delete(boxes);
    await db.delete(users);
  }

  const existingUsers = await db.select({ value: count() }).from(users);
  if (Number(existingUsers[0]?.value ?? 0) === 0) {
    await db.insert(users).values([
      {
        email: "clara.moreau@lemondeaime.org",
        name: "Clara Moreau",
        passwordHash: "demo1234",
        role: "Citoyenne donatrice",
        city: "Paris 11e",
        portraitUrl: DON_PHOTOS.portraitClara,
        badgeCode: "LMA-CITOYEN-01",
        stampsCount: 7,
      },
      {
        email: "contact@antenne-lyon.lemondeaime.org",
        name: "Antenne Lyon",
        passwordHash: "demo1234",
        role: "Association partenaire",
        city: "Lyon 7e",
        badgeCode: "LMA-ASSO-LYON",
        stampsCount: 24,
      },
      {
        email: "thomas.gauthier@lemondeaime.org",
        name: "Thomas Gauthier",
        passwordHash: "demo1234",
        role: "Relais solidaire",
        city: "Bordeaux",
        portraitUrl: DON_PHOTOS.portraitThomas,
        badgeCode: "LMA-RELAIS-09",
        stampsCount: 15,
      },
    ]);
  }

  const existingBoxes = await db.select({ value: count() }).from(boxes);
  if (Number(existingBoxes[0]?.value ?? 0) === 0) {
    for (const seededBox of INITIAL_BOXES) {
      const { items, ...boxValues } = seededBox;
      const [insertedBox] = await db.insert(boxes).values(boxValues).returning();
      for (const item of items) {
        await db.insert(boxItems).values({
          boxId: insertedBox.id,
          ...item,
          addedByUserName: seededBox.name,
        });
      }
      await db.insert(shipmentLogs).values([
        {
          boxId: insertedBox.id,
          boxCode: seededBox.code,
          eventType: "BOÎTE_CRÉÉE",
          message: `${seededBox.name} a publié une boîte au point ${seededBox.pickupPoint}.`,
          authorName: seededBox.name,
        },
      ]);

      if (seededBox.boxType !== "IRIDESCENT_CUBE") {
        const [firstItem] = items;
        await db.insert(postcards).values({
          boxId: insertedBox.id,
          userId: null,
          title: seededBox.boxType === "SHOEBOX" ? "Carte chaussure" : "Carte de présentation",
          format: "POSTCARD",
          photoUrl: firstItem.photoUrl,
          portraitUrl: null,
          postcardSource: "DON",
          frontTitle: "LE MONDE AIME",
          message: `Bonjour, ce don est disponible au point ${seededBox.pickupPoint}. Merci de me prévenir avant retrait.`,
          recipientName: seededBox.name,
          recipientAddress: `${seededBox.pickupPoint}\n${seededBox.city}`,
          stampLabel: "Participation documentée",
          stampValue: seededBox.boxType === "SHOEBOX" ? `EU ${seededBox.shoeSizeEu}` : "Monde Relais",
          stampCountry: "France",
          sealType: "SCELLÉ SIMPLE",
          foldedLayout: false,
        });
      }
    }
  }

  const existingStamps = await db.select({ value: count() }).from(citizenStamps);
  if (Number(existingStamps[0]?.value ?? 0) === 0) {
    await db.insert(citizenStamps).values([
      {
        stampCode: "DON_PHOTO_VERIFIE",
        stampTitle: "Participation documentée",
        stampCity: "PARIS 11E",
        stampColor: "#11110f",
        awardedToName: "Clara Moreau",
        awardedReason: "Ajout d’un don photographié disponible à proximité.",
      },
      {
        stampCode: "CUBE_CRISTALLIN",
        stampTitle: "Capsule d'énergie activée",
        stampCity: "PARIS 13E",
        stampColor: "#11110f",
        awardedToName: "Clara Moreau",
        awardedReason: "Publication d'un cube cristallin de dons du futur (kWh solaires & temps partagé).",
      },
    ]);
  }
}
