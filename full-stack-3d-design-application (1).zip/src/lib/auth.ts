import { cookies } from "next/headers";
import { db } from "@/db";
import { users, User } from "@/db/schema";
import { eq } from "drizzle-orm";

const COOKIE_NAME = "aime_atelier_session";

export async function getCurrentUser(): Promise<User | null> {
  try {
    const cookieStore = await cookies();
    const userIdRaw = cookieStore.get(COOKIE_NAME)?.value;
    if (!userIdRaw) return null;
    const userId = Number(userIdRaw);
    if (isNaN(userId)) return null;

    const found = await db
      .select()
      .from(users)
      .where(eq(users.id, userId))
      .limit(1);

    return found[0] ?? null;
  } catch {
    return null;
  }
}

export async function setSessionUser(userId: number) {
  const cookieStore = await cookies();
  cookieStore.set(COOKIE_NAME, String(userId), {
    httpOnly: true,
    path: "/",
    sameSite: "lax",
    maxAge: 60 * 60 * 24 * 14, // 14 days
  });
}

export async function clearSessionUser() {
  const cookieStore = await cookies();
  cookieStore.delete(COOKIE_NAME);
}
