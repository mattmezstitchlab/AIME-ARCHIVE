/**
 * Tampons officiels LE MONDE AIME.
 *
 * Source de vérité unique : ces fonctions sont utilisées à la fois par la scène 3D
 * (textures appliquées sur les cartons) et par l'interface 2D (landing, passeport).
 * Un tampon validé dans l'atelier doit être strictement identique partout ailleurs.
 */

export function roundedRect(
  ctx: CanvasRenderingContext2D,
  a: number,
  b: number,
  w: number,
  h: number,
  r: number
) {
  ctx.beginPath();
  ctx.moveTo(a + r, b);
  ctx.arcTo(a + w, b, a + w, b + h, r);
  ctx.arcTo(a + w, b + h, a, b + h, r);
  ctx.arcTo(a, b + h, a, b, r);
  ctx.arcTo(a, b, a + w, b, r);
  ctx.closePath();
}

export function arcText(
  ctx: CanvasRenderingContext2D,
  str: string,
  cx: number,
  cy: number,
  r: number,
  a0: number,
  a1: number,
  flip: boolean
) {
  const n = str.length;
  for (let i = 0; i < n; i++) {
    const a = a0 + (a1 - a0) * (n === 1 ? 0.5 : i / (n - 1));
    ctx.save();
    ctx.translate(cx + Math.cos(a) * r, cy + Math.sin(a) * r);
    ctx.rotate(a + (flip ? -Math.PI / 2 : Math.PI / 2));
    ctx.fillText(str[i], 0, 0);
    ctx.restore();
  }
}

/** Tampon circulaire principal apposé sur les rabats des cartons. */
export function drawCitizenStamp(
  ctx: CanvasRenderingContext2D,
  size = 256,
  subtitle = "TAMPON CITOYEN"
) {
  const cx = size / 2;
  const cy = size / 2;
  const s = size / 256;
  ctx.clearRect(0, 0, size, size);
  ctx.fillStyle = "rgba(35,34,32,.92)";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.strokeStyle = "rgba(35,34,32,.88)";
  ctx.lineWidth = 7 * s;
  ctx.beginPath();
  ctx.arc(cx, cy, 112 * s, 0, Math.PI * 2);
  ctx.stroke();
  ctx.lineWidth = 2.5 * s;
  ctx.beginPath();
  ctx.arc(cx, cy, 72 * s, 0, Math.PI * 2);
  ctx.stroke();
  ctx.font = `700 ${15 * s}px "IBM Plex Mono", monospace`;
  arcText(ctx, "LE MONDE AIME · SOLIDARITÉ", cx, cy, 92 * s, -Math.PI + 0.42, -0.42, false);
  arcText(ctx, "PARTICIPATION ACTIVE CITOYENNE", cx, cy, 92 * s, Math.PI - 0.45, 0.45, true);
  ctx.font = `900 ${32 * s}px Inter, sans-serif`;
  ctx.fillText("AIME", cx, cy - 8 * s);
  ctx.font = `700 ${13 * s}px "IBM Plex Mono", monospace`;
  ctx.fillText(subtitle, cx, cy + 24 * s);
}

/** Tampon rectangulaire de relais apposé sur les cartons en transit. */
export function drawRelayStamp(
  ctx: CanvasRenderingContext2D,
  width = 320,
  height = 200,
  title = "RELAIS AIME",
  subtitle = "TRANSIT CITOYEN DISPONIBLE"
) {
  const s = width / 320;
  ctx.clearRect(0, 0, width, height);
  ctx.strokeStyle = "rgba(65,64,61,.88)";
  ctx.lineWidth = 7 * s;
  roundedRect(ctx, 10 * s, 10 * s, 300 * s, 180 * s, 14 * s);
  ctx.stroke();
  ctx.lineWidth = 2 * s;
  roundedRect(ctx, 22 * s, 22 * s, 276 * s, 156 * s, 8 * s);
  ctx.stroke();
  ctx.fillStyle = "rgba(65,64,61,.92)";
  ctx.textAlign = "center";
  ctx.textBaseline = "alphabetic";
  ctx.font = `900 ${46 * s}px Inter, sans-serif`;
  ctx.fillText(title, width / 2, 88 * s);
  ctx.font = `700 ${14 * s}px "IBM Plex Mono", monospace`;
  ctx.fillText(subtitle, width / 2, 134 * s);
}

export function citizenStampDataUrl(size = 256, subtitle = "TAMPON CITOYEN") {
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext("2d");
  if (!ctx) return "";
  drawCitizenStamp(ctx, size, subtitle);
  return canvas.toDataURL();
}

export function relayStampDataUrl(
  width = 320,
  height = 200,
  title = "RELAIS AIME",
  subtitle = "TRANSIT CITOYEN DISPONIBLE"
) {
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  if (!ctx) return "";
  drawRelayStamp(ctx, width, height, title, subtitle);
  return canvas.toDataURL();
}
