import {
  pgTable,
  serial,
  text,
  varchar,
  boolean,
  real,
  timestamp,
  integer,
} from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }).notNull(),
  passwordHash: text("password_hash").notNull(),
  role: varchar("role", { length: 64 }).notNull().default("Citoyen Donateur"),
  city: varchar("city", { length: 128 }).notNull().default("Paris 11e"),
  portraitUrl: text("portrait_url"),
  badgeCode: varchar("badge_code", { length: 32 }).notNull().default("LMA-CITOYEN-01"),
  stampsCount: integer("stamps_count").notNull().default(4),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const boxes = pgTable("boxes", {
  id: serial("id").primaryKey(),
  code: varchar("code", { length: 32 }).notNull().unique(),
  boxRole: varchar("box_role", { length: 64 }).notNull().default("DONATEUR"),
  boxType: varchar("box_type", { length: 32 }).notNull().default("CARTON"), // CARTON | SHOEBOX | IRIDESCENT_CUBE
  kind: varchar("kind", { length: 64 }).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  pickupPoint: varchar("pickup_point", { length: 255 }).notNull(),
  city: varchar("city", { length: 128 }).notNull().default("Paris"),
  description: text("description").notNull(),
  note1: varchar("note1", { length: 128 }).notNull().default("donner change le monde"),
  note2: varchar("note2", { length: 128 }).notNull().default("seconde vie solidaire"),
  relaisNeeded: boolean("relais_needed").notNull().default(false),
  relaisRoute: varchar("relais_route", { length: 255 }).default("Remise locale directe"),
  stampsText: varchar("stamps_text", { length: 255 }).notNull().default("DON VÉRIFIÉ · RELAIS CITOYEN"),
  shoeSizeEu: varchar("shoe_size_eu", { length: 32 }),
  posX: real("pos_x").notNull().default(0),
  posZ: real("pos_z").notNull().default(0),
  rotY: real("rot_y").notNull().default(0),
  createdByUserId: integer("created_by_user_id"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const boxItems = pgTable("box_items", {
  id: serial("id").primaryKey(),
  boxId: integer("box_id")
    .notNull()
    .references(() => boxes.id, { onDelete: "cascade" }),
  name: varchar("name", { length: 255 }).notNull(),
  itemType: varchar("item_type", { length: 64 }).notNull(),
  colorHex: varchar("color_hex", { length: 32 }).notNull().default("#a77b33"),
  photoUrl: text("photo_url").notNull(),
  condition: varchar("condition", { length: 64 }).notNull().default("Comme neuf"),
  story: text("story").notNull().default("Donné avec le cœur pour une nouvelle vie."),
  reservedByAssoName: varchar("reserved_by_asso_name", { length: 255 }),
  shoeSizeEu: varchar("shoe_size_eu", { length: 32 }),
  futureDonationType: varchar("future_donation_type", { length: 64 }).default("SKILL_CAPSULE"), // SKILL_CAPSULE | ENERGY_WATT | SENSORY_BUBBLE | VOICE_MEMORY
  futureDonationValue: varchar("future_donation_value", { length: 128 }), // ex: "4 heures de mentorat" ou "50 kWh solaires"

  addedByUserName: varchar("added_by_user_name", { length: 255 }).default("Citoyen LE MONDE AIME"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const shipmentLogs = pgTable("shipment_logs", {
  id: serial("id").primaryKey(),
  boxId: integer("box_id").references(() => boxes.id, { onDelete: "set null" }),
  boxCode: varchar("box_code", { length: 32 }).notNull(),
  eventType: varchar("event_type", { length: 64 }).notNull(),
  message: text("message").notNull(),
  authorName: varchar("author_name", { length: 128 }).notNull().default("LE MONDE AIME"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const citizenStamps = pgTable("citizen_stamps", {
  id: serial("id").primaryKey(),
  stampCode: varchar("stamp_code", { length: 64 }).notNull(),
  stampTitle: varchar("stamp_title", { length: 128 }).notNull(),
  stampCity: varchar("stamp_city", { length: 128 }).notNull(),
  stampColor: varchar("stamp_color", { length: 32 }).notNull().default("#11110f"),
  awardedToName: varchar("awarded_to_name", { length: 128 }).notNull(),
  awardedReason: text("awarded_reason").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const postcards = pgTable("postcards", {
  id: serial("id").primaryKey(),
  boxId: integer("box_id").references(() => boxes.id, { onDelete: "cascade" }),
  userId: integer("user_id").references(() => users.id, { onDelete: "set null" }),
  title: varchar("title", { length: 255 }).notNull().default("Carte postale solidaire"),
  format: varchar("format", { length: 32 }).notNull().default("POSTCARD"),
  photoUrl: text("photo_url").notNull(),
  mediaType: varchar("media_type", { length: 16 }).notNull().default("IMAGE"), // IMAGE | VIDEO
  portraitUrl: text("portrait_url"),
  postcardSource: varchar("postcard_source", { length: 64 }).notNull().default("DON"), // DON | PARTICULIER | EQUIPE | COMMUNICATION
  frontTitle: varchar("front_title", { length: 255 }).notNull().default("LE MONDE AIME"),
  message: text("message").notNull().default(""),
  recipientName: varchar("recipient_name", { length: 255 }).notNull().default("Point de collecte"),
  recipientAddress: text("recipient_address").notNull().default(""),
  stampLabel: varchar("stamp_label", { length: 128 }).notNull().default("Participation documentée"),
  stampValue: varchar("stamp_value", { length: 32 }).notNull().default("Monde Relais"),
  stampCountry: varchar("stamp_country", { length: 128 }).notNull().default("France"),
  stampPrompt: varchar("stamp_prompt", { length: 255 }),
  stampImageUrl: text("stamp_image_url"),
  sealType: varchar("seal_type", { length: 64 }).notNull().default("SCELLÉ SIMPLE"),
  foldedLayout: boolean("folded_layout").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const documentLabels = pgTable("document_labels", {
  id: serial("id").primaryKey(),
  boxId: integer("box_id").references(() => boxes.id, { onDelete: "cascade" }),
  userId: integer("user_id").references(() => users.id, { onDelete: "set null" }),
  labelType: varchar("label_type", { length: 64 }).notNull().default("COLLECTE"),
  title: varchar("title", { length: 255 }).notNull().default("Étiquette transport"),
  carrierName: varchar("carrier_name", { length: 128 }).notNull().default("LE MONDE AIME"),
  recipientName: varchar("recipient_name", { length: 255 }).notNull(),
  recipientAddress: text("recipient_address").notNull(),
  senderName: varchar("sender_name", { length: 255 }).notNull().default("LE MONDE AIME"),
  senderAddress: text("sender_address").notNull().default(""),
  trackingCode: varchar("tracking_code", { length: 128 }).notNull().default("LMA-000000"),
  notes: text("notes").notNull().default(""),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type Box = typeof boxes.$inferSelect;
export type BoxItem = typeof boxItems.$inferSelect;
export type ShipmentLog = typeof shipmentLogs.$inferSelect;
export type CitizenStamp = typeof citizenStamps.$inferSelect;
export type Postcard = typeof postcards.$inferSelect;
export type DocumentLabel = typeof documentLabels.$inferSelect;
