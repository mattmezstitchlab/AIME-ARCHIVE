import React from 'react';
import { Outlet, NavLink, Link } from 'react-router-dom';
import { LayoutGrid, MessageSquare, Clock, Users, CalendarDays, GitBranch, Radio } from 'lucide-react';
import GaiaMark from '@/components/brand/GaiaMark';
import { WorldProvider } from '@/lib/WorldContext';
import WorldSelector from '@/components/WorldSelector';

const NAV = [
  { to: '/overview', label: "Vue d'ensemble", icon: LayoutGrid },
  { to: '/chat', label: 'Chat GAÏA', icon: MessageSquare },
  { to: '/timeline', label: 'Chronos', icon: Clock },
  { to: '/people', label: 'People Graph', icon: Users },
  { to: '/events', label: 'Événements', icon: CalendarDays },
  { to: '/scenarios', label: 'Scénarios', icon: GitBranch },
  { to: '/live', label: 'Jour J', icon: Radio },
];

export default function Layout() {
  return (
    <WorldProvider>
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      <div className="sticky top-0 z-30 px-4 pt-4 pb-2">
        <nav className="mx-auto max-w-5xl flex items-center justify-between gap-4 rounded-full border border-border bg-background/85 backdrop-blur-xl px-4 py-2 shadow-[0_8px_24px_rgba(0,0,0,0.06)]">
          <Link to="/" className="flex items-center gap-2.5 no-underline shrink-0">
            <GaiaMark className="w-6 h-6 text-foreground" />
            <span className="flex flex-col leading-[1.15]">
              <strong className="text-[13px] font-semibold tracking-[0.18em]">GAÏA</strong>
              <span className="text-[8px] tracking-[0.12em] uppercase text-muted-foreground">
                Wedding Universe<br />Engine
              </span>
            </span>
          </Link>

          <div className="flex items-center gap-1">
            {NAV.map(({ to, label, icon: Icon }) => (
              <NavLink
                key={to}
                to={to}
                title={label}
                aria-label={label}
                className={({ isActive }) =>
                  `w-9 h-9 flex items-center justify-center rounded-full transition-colors ${
                    isActive ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:bg-secondary hover:text-foreground'
                  }`
                }
              >
                <Icon className="w-4 h-4" strokeWidth={1.6} />
              </NavLink>
            ))}
          </div>

          <div className="shrink-0">
            <WorldSelector />
          </div>
        </nav>
      </div>
      <main className="flex-1">
        <Outlet />
      </main>
      <footer className="aime-footer">
        <div className="footer-inner">
          <div className="footer-brand">
            <div className="footer-lockup">
              <GaiaMark className="w-6 h-6 text-white" />
              <span>GAÏA — Wedding Universe Engine</span>
            </div>
            <p>
              Système d'orchestration causale du mariage — par AIME®<br />
              Vous vivez votre mariage. GAÏA en comprend la complexité.
            </p>
          </div>
          <div className="footer-version">
            <p>Release</p>
            <span>v1.0 · Août 2026</span>
          </div>
        </div>
      </footer>
    </div>
    </WorldProvider>
  );
}