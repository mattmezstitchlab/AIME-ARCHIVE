import React from 'react';
import { levelStyle, CONSTRAINT_STATUS_LABELS } from '@/lib/levels';
import Avatar from '@/components/identity/Avatar';
import AvatarStack from '@/components/identity/AvatarStack';

const TYPE_LABELS = { setup: 'Installation', service: 'Service', moment: 'Moment', travel: 'Trajet', teardown: 'Démontage' };
const STATUS_LABELS = { planned: 'Prévu', confirmed: 'Confirmé', delayed: 'Retard', done: 'Terminé' };
const CONSTRAINT_LEVEL = { violated: 'CRITICAL', unknown: 'MEDIUM', blocked: 'HIGH', satisfied: 'INFO' };

export default function TimeBlockCard({ block, entity, constraints, people = [] }) {
  return (
    <article>
      <span />
      <div className="min-w-0 flex-1">
        <time>
          {block.start_time}
          {block.end_time && ` → ${block.end_time}`} · {entity?.name} · {TYPE_LABELS[block.block_type] || block.block_type}
          {block.buffer_minutes > 0 && ` · marge ${block.buffer_minutes} min`}
        </time>
        <div className="flex items-center gap-3 flex-wrap">
          {entity && <Avatar entity={entity} size="sm" />}
          <p className="font-medium">{block.label}</p>
          <span className={block.status === 'delayed' ? 'aime-tag-dark' : block.status === 'confirmed' ? 'aime-tag-live' : 'aime-tag'}>
            {STATUS_LABELS[block.status] || block.status}
          </span>
        </div>
        {people.length > 0 && <AvatarStack entities={people} max={6} className="mt-2" />}
        {constraints.length > 0 && (
          <div className="mt-2 space-y-1">
            {constraints.map((c) => {
              const lv = levelStyle(CONSTRAINT_LEVEL[c.status] || 'MEDIUM');
              return (
                <div key={c.id} className="flex items-center gap-2 text-xs text-muted-foreground">
                  <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${lv.dot}`} />
                  {c.description} · {CONSTRAINT_STATUS_LABELS[c.status] || c.status}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </article>
  );
}