import React from 'react';
import Avatar from '@/components/identity/Avatar';

export default function AvatarStack({ entities = [], max = 4, size = 'sm', className = '' }) {
  const shown = entities.slice(0, max);
  const rest = entities.length - shown.length;
  if (!entities.length) return null;
  return (
    <div className={`flex items-center ${className}`}>
      <div className="flex -space-x-2">
        {shown.map((e, i) => (
          <span key={e.id || i} className="ring-2 ring-background rounded-full inline-flex">
            <Avatar entity={e} size={size} badge={false} />
          </span>
        ))}
      </div>
      {rest > 0 && <span className="ml-2 text-xs text-muted-foreground">+{rest}</span>}
    </div>
  );
}