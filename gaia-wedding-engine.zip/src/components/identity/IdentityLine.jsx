import React from 'react';
import Avatar from '@/components/identity/Avatar';
import { identityOf } from '@/lib/identity';

export default function IdentityLine({ entity, size = 'md', subtitle, right }) {
  const id = identityOf(entity);
  return (
    <div className="flex items-center gap-3 min-w-0">
      <Avatar entity={entity} size={size} />
      <div className="min-w-0">
        <p className="text-sm font-semibold text-foreground truncate">{id.name}</p>
        <p className="text-xs text-muted-foreground truncate">{subtitle || id.role}</p>
      </div>
      {right}
    </div>
  );
}