import React from 'react';
import { identityOf } from '@/lib/identity';

const SIZES = {
  xs: 'w-6 h-6 text-[9px]',
  sm: 'w-8 h-8 text-[10px]',
  md: 'w-10 h-10 text-xs',
  lg: 'w-14 h-14 text-sm',
  xl: 'w-20 h-20 text-base',
};

const SHAPES = { circle: 'rounded-full', square: 'rounded-none', rounded: 'rounded-lg' };

const STATE_RING = {
  default: 'ring-1 ring-border',
  selected: 'ring-2 ring-foreground',
  confirmed: 'ring-2 ring-[#4ADE80]',
  pending: 'ring-2 ring-[#FACC15]',
  declined: 'ring-1 ring-border opacity-50',
  warning: 'ring-2 ring-[#60A5FA]',
  conflict: 'ring-2 ring-[#F87171]',
};

const STATE_DOT = {
  confirmed: 'bg-[#4ADE80]', pending: 'bg-[#FACC15]', warning: 'bg-[#60A5FA]',
  declined: 'bg-[#727169]', conflict: 'bg-[#F87171]',
};

export default function Avatar({ entity, size = 'md', shape = 'circle', state, badge = true, title }) {
  const id = identityOf(entity);
  const s = state || id.state;
  return (
    <span className={`relative inline-flex shrink-0 ${SIZES[size]}`} title={title || `${id.name}${id.role ? ` · ${id.role}` : ''}`}>
      <span className={`w-full h-full overflow-hidden bg-secondary text-muted-foreground flex items-center justify-center font-semibold ${SHAPES[shape]} ${STATE_RING[s] || STATE_RING.default}`}>
        {id.photo ? (
          <img src={id.photo} alt={id.name} loading="lazy" decoding="async" className="w-full h-full object-cover" />
        ) : (
          id.initials
        )}
      </span>
      {badge && STATE_DOT[s] && (
        <span className={`absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border-2 border-background ${STATE_DOT[s]}`} />
      )}
    </span>
  );
}