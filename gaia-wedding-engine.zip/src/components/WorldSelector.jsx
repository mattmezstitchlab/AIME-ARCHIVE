import React from 'react';
import { useWorld } from '@/hooks/useWorld';

export default function WorldSelector() {
  const { worlds, activeWorldId, setActiveWorldId } = useWorld();
  if (worlds.length < 2) return null;
  return (
    <select
      value={activeWorldId || ''}
      onChange={(e) => setActiveWorldId(e.target.value)}
      className="text-xs bg-secondary border border-border rounded-full px-3 py-1.5 text-foreground outline-none"
      aria-label="Univers actif"
    >
      {worlds.map((w) => (
        <option key={w.id} value={w.id}>{w.name}</option>
      ))}
    </select>
  );
}