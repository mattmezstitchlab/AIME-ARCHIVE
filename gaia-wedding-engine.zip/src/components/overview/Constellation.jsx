import React from 'react';
import { motion } from 'framer-motion';

const TYPE_COLORS = {
  vendor: '#121212',
  moment: '#60A5FA',
  place: '#4ADE80',
  person: '#FACC15',
  resource: '#F87171',
};

const R = 38;
const HUB = 14;

export default function Constellation({ entities }) {
  const n = entities.length || 1;
  const nodes = entities.map((e, i) => {
    const a = (i / n) * 2 * Math.PI - Math.PI / 2;
    return {
      ...e,
      x: 50 + R * Math.cos(a),
      y: 50 + R * Math.sin(a),
      hx: 50 + HUB * Math.cos(a),
      hy: 50 + HUB * Math.sin(a),
    };
  });

  return (
    <div className="relative aspect-square max-w-lg mx-auto">
      <svg className="absolute inset-0 w-full h-full overflow-visible" viewBox="0 0 100 100">
        <circle cx="50" cy="50" r={R} fill="none" stroke="#121212" strokeOpacity="0.07" strokeWidth="0.3" />
        {nodes.map((node) => (
          <line
            key={`l-${node.id}`}
            x1={node.hx}
            y1={node.hy}
            x2={node.x}
            y2={node.y}
            stroke="#121212"
            strokeOpacity="0.12"
            strokeWidth="0.3"
          />
        ))}
        {nodes.map((node, i) => (
          <motion.circle
            key={`c-${node.id}`}
            cx={node.x}
            cy={node.y}
            r="1.4"
            fill={TYPE_COLORS[node.entity_type] || '#121212'}
            stroke="#FFFFFF"
            strokeWidth="0.8"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: i * 0.06 }}
          />
        ))}
      </svg>

      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-24 h-24 rounded-full bg-background border border-border shadow-[0_1px_3px_rgba(0,0,0,0.08)] flex items-center justify-center">
        <span className="text-lg font-semibold text-foreground tracking-[-0.04em]">GAÏA</span>
      </div>

      {nodes.map((node) => (
        <span
          key={`t-${node.id}`}
          className="absolute -translate-x-1/2 text-[11px] text-muted-foreground whitespace-nowrap"
          style={{ left: `${node.x}%`, top: `calc(${node.y}% + 10px)` }}
        >
          {node.name}
        </span>
      ))}
    </div>
  );
}