import React from 'react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { Activity } from 'lucide-react';

const SEVERITY_DOT = { info: 'aime-blue', warning: 'aime-yellow', critical: 'aime-red' };

export default function EventFeed({ events }) {
  return (
    <section className="aime-hud">
      <header>
        <span className="aime-hud-title">EVENT BUS</span>
        <span className="aime-hud-live">● LIVE</span>
      </header>
      {events.length === 0 && (
        <div className="aime-hud-row">
          <span>Aucun événement pour le moment.</span>
        </div>
      )}
      {events.slice(0, 8).map((ev) => (
        <div key={ev.id} className="aime-hud-row">
          <Activity className="w-3.5 h-3.5 text-white/70" strokeWidth={2} />
          <span>
            {ev.event_type} · {ev.source} · {format(new Date(ev.created_date), 'd MMM HH:mm', { locale: fr })}
          </span>
          <i className={`aime-dot ${SEVERITY_DOT[ev.severity] || 'aime-blue'}`} />
        </div>
      ))}
    </section>
  );
}