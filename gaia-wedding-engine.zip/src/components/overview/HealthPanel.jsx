import React from 'react';
import { levelStyle } from '@/lib/levels';

export default function HealthPanel({ health }) {
  if (!health) {
    return (
      <div className="rounded-xl border border-border bg-background p-6 shadow-[0_1px_3px_rgba(0,0,0,0.08)]">
        <span className="aime-tag">État de santé du mariage</span>
        <p className="text-sm text-muted-foreground mt-4">Jamais calculé. Lancez « Recalculer le monde ».</p>
      </div>
    );
  }
  return (
    <div className="rounded-xl border border-border bg-background p-6 shadow-[0_1px_3px_rgba(0,0,0,0.08)]">
      <span className="aime-tag">État de santé du mariage</span>
      <div className="flex items-baseline gap-2 mt-4">
        <span className="text-5xl font-bold text-foreground tracking-[-0.04em]">{health.score}</span>
        <span className="text-muted-foreground text-sm">/ 100</span>
      </div>
      <div className="mt-6 space-y-3">
        {(health.dims || []).map((d) => {
          const lv = levelStyle(d.level);
          return (
            <div key={d.label} className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">{d.label}{d.count ? ` · ${d.count}` : ''}</span>
              <span className={`w-2.5 h-2.5 rounded-full ${lv.dot}`} />
            </div>
          );
        })}
      </div>
      {health.attention > 0 && (
        <p className="mt-6 text-xs text-orange-600 font-medium">
          {health.attention} élément{health.attention > 1 ? 's' : ''} nécessite{health.attention > 1 ? 'nt' : ''} votre attention.
        </p>
      )}
      {health.computed_at && (
        <p className="mt-2 text-[11px] text-muted-foreground">
          Calculé le {new Date(health.computed_at).toLocaleString('fr-FR')} · pénalité {health.penalty}
        </p>
      )}
    </div>
  );
}