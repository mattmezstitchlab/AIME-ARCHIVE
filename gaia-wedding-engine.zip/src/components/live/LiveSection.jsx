import React from 'react';

export default function LiveSection({ title, icon: Icon, dot = 'aime-blue', items = [], empty }) {
  return (
    <section className="aime-hud">
      <header>
        <span className="aime-hud-title">{title.toUpperCase()}</span>
        <span className="aime-hud-live">● LIVE</span>
      </header>
      {items.length === 0 && (
        <div className="aime-hud-row">
          <span style={{ color: 'rgba(255,255,255,.5)' }}>{empty || 'Rien à signaler.'}</span>
        </div>
      )}
      {items.map((item) => (
        <div key={item.id} className="aime-hud-row">
          {Icon && <Icon className="w-3.5 h-3.5 text-white/70" strokeWidth={2} />}
          <span>{item.text}</span>
          <i className={`aime-dot ${item.dot || dot}`} />
        </div>
      ))}
    </section>
  );
}