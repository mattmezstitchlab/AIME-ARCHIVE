import React from 'react';
import ImpactCard from '@/components/chat/ImpactCard';
import { SCENARIO_STATUS_LABELS } from '@/lib/levels';

export default function ScenarioCard({ scenario, onApply, onAbandon, onRollback, busy }) {
  return (
    <div className="rounded-xl border border-border bg-card p-5">
      <p className="text-xs text-muted-foreground">
        Source : {scenario.source === 'gaia' ? 'GAÏA' : 'Utilisateur'} · {SCENARIO_STATUS_LABELS[scenario.status] || scenario.status}
        {scenario.applied_at && ` · appliqué le ${new Date(scenario.applied_at).toLocaleString('fr-FR')}`}
        {scenario.reverted_at && ` · annulé le ${new Date(scenario.reverted_at).toLocaleString('fr-FR')}`}
      </p>
      <ImpactCard scenario={scenario} onApply={onApply} onAbandon={onAbandon} onRollback={onRollback} busy={busy} />
    </div>
  );
}