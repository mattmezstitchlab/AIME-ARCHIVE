import React from 'react';

// Symbole GAÏA : un noyau (le couple) et l'orbite du monde qui l'entoure.
export default function GaiaMark({ className = 'w-6 h-6', color = 'currentColor', strokeWidth = 1.2 }) {
  return (
    <svg viewBox="0 0 32 32" fill="none" className={className} aria-hidden="true">
      <circle cx="16" cy="16" r="13" stroke={color} strokeWidth={strokeWidth} opacity="0.35" />
      <ellipse cx="16" cy="16" rx="13" ry="5.5" stroke={color} strokeWidth={strokeWidth} opacity="0.55" />
      <ellipse cx="16" cy="16" rx="13" ry="5.5" stroke={color} strokeWidth={strokeWidth} opacity="0.55" transform="rotate(60 16 16)" />
      <ellipse cx="16" cy="16" rx="13" ry="5.5" stroke={color} strokeWidth={strokeWidth} opacity="0.55" transform="rotate(-60 16 16)" />
      <circle cx="16" cy="16" r="3.4" fill={color} />
    </svg>
  );
}