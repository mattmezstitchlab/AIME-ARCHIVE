import React from 'react';
import { Link } from 'react-router-dom';
import Reveal from './Reveal';
import { COUPLE_IMAGE } from '@/lib/pantheon';

export default function CoupleSection() {
  return (
    <section className="relative min-h-screen flex items-end overflow-hidden bg-black">
      <img
        src={COUPLE_IMAGE}
        alt="Le couple au centre de l'univers"
        loading="lazy"
        decoding="async"
        className="absolute inset-0 w-full h-full object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-black/20" />
      <div className="relative w-full max-w-[1200px] mx-auto px-6 md:px-12 pb-24 md:pb-32 space-y-8">
        <Reveal>
          <h2 className="text-white font-bold tracking-[-0.06em] leading-[0.85] text-[17vw] md:text-[10rem]">ET VOUS…</h2>
        </Reveal>
        <Reveal delay={0.2}>
          <p className="text-white text-xl md:text-3xl font-semibold tracking-[-0.03em] max-w-2xl leading-tight">
            Tous ces mondes existent pour un seul événement.<br />Le vôtre.
          </p>
        </Reveal>
        <Reveal delay={0.35}>
          <div className="flex flex-wrap gap-3 pt-2">
            <Link to="/overview" className="aime-btn-primary no-underline">Créer mon univers</Link>
            <Link
              to="/chat"
              className="aime-btn-secondary no-underline"
              style={{ background: 'transparent', border: '1px solid rgba(255,255,255,0.4)', color: '#fff' }}
            >
              Entrer dans GAÏA
            </Link>
          </div>
        </Reveal>
      </div>
    </section>
  );
}