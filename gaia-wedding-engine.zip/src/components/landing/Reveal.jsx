import React from 'react';
import { motion, useReducedMotion } from 'framer-motion';

// Apparition cinématographique — sobre, jamais gadget.
export default function Reveal({ children, delay = 0, y = 24, className = '' }) {
  const reduced = useReducedMotion();
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y: reduced ? 0 : y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-80px' }}
      transition={{ duration: reduced ? 0.3 : 0.9, delay: reduced ? 0 : delay, ease: [0.23, 1, 0.32, 1] }}
    >
      {children}
    </motion.div>
  );
}