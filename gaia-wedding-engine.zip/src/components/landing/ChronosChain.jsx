import React from 'react';
import { ArrowDown } from 'lucide-react';
import Reveal from './Reveal';

// Exemple de démonstration — mêmes valeurs que la section « Et si… ».
const CHAIN = [
  { label: 'Photographe', shift: '+60 min' },
  { label: 'Séance couple', shift: '+30 min' },
  { label: 'Cérémonie', shift: 'bloqué' },
  { label: 'Cocktail', shift: 'inchangé' },
];

export default function ChronosChain() {
  return (
    <div className="aime-hud max-w-sm">
      <header>
        <span className="aime-hud-title">PROPAGATION TEMPORELLE</span>
        <span className="aime-hud-live">Démonstration</span>
      </header>
      {CHAIN.map((s, i) => (
        <Reveal key={s.label} delay={i * 0.08}>
          <div className="aime-hud-row">
            <span className={`aime-dot ${s.shift === 'inchangé' ? 'aime-green' : s.shift === 'bloqué' ? 'aime-red' : 'aime-yellow'}`} />
            <span>{s.label}</span>
            <span className="text-[11px] text-white/60 shrink-0">{s.shift}</span>
          </div>
          {i < CHAIN.length - 1 && <ArrowDown className="w-3 h-3 text-white/25 mx-auto my-1" strokeWidth={1.5} />}
        </Reveal>
      ))}
    </div>
  );
}