import React from 'react';
import { CAST } from '@/lib/landingCast';

// Les visages du monde — le même langage visuel que dans l'application.
export default function CastRow({ ids, dark = true, showRoles = true, className = '' }) {
  const people = ids ? CAST.filter((c) => ids.includes(c.id)) : CAST;
  return (
    <div className={`flex flex-wrap gap-x-6 gap-y-5 ${className}`}>
      {people.map((p) => (
        <div key={p.id} className="flex items-center gap-3 min-w-0">
          <img
            src={p.photo}
            alt={p.name}
            loading="lazy"
            decoding="async"
            onError={(e) => { e.currentTarget.style.opacity = '0'; }}
            className={`w-11 h-11 rounded-full object-cover shrink-0 ring-1 ${dark ? 'bg-white/10 ring-white/25' : 'bg-secondary ring-black/10'}`}
          />
          {showRoles && (
            <div className="min-w-0">
              <p className={`text-xs font-medium truncate ${dark ? 'text-white' : 'text-foreground'}`}>{p.name}</p>
              <p className={`text-[10px] tracking-[0.16em] uppercase ${dark ? 'text-white/40' : 'text-muted-foreground'}`}>{p.role}</p>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}