import React from 'react';
import { Link } from 'react-router-dom';
import GaiaMark from '@/components/brand/GaiaMark';

export default function LandingHeader() {
  return (
    <header className="fixed top-0 inset-x-0 z-40">
      <div className="max-w-[1200px] mx-auto px-5 md:px-12 h-16 flex items-center justify-between gap-4">
        <Link to="/" className="flex items-center gap-3 no-underline shrink-0">
          <GaiaMark className="w-7 h-7 text-white" />
          <span className="text-white text-sm font-semibold tracking-[0.18em]">GAÏA</span>
        </Link>
        <nav className="flex items-center gap-5 md:gap-8">
          <a href="#pantheon" className="hidden sm:inline text-[11px] tracking-[0.24em] uppercase text-white/60 hover:text-white no-underline">
            Panthéon
          </a>
          <a href="#what-if" className="hidden sm:inline text-[11px] tracking-[0.24em] uppercase text-white/60 hover:text-white no-underline">
            Comment ça marche
          </a>
          <Link to="/overview" className="aime-btn-primary no-underline whitespace-nowrap">Entrer dans l'univers</Link>
        </nav>
      </div>
    </header>
  );
}