import React from 'react';
import Reveal from './Reveal';
import CastRow from './CastRow';
import { PANTHEON, CONVERGENCE_IMAGE } from '@/lib/pantheon';

export default function ConvergenceSection() {
  return (
    <section className="relative min-h-screen flex items-center overflow-hidden bg-black">
      <img
        src={CONVERGENCE_IMAGE}
        alt="La convergence des mondes"
        loading="lazy"
        decoding="async"
        className="absolute inset-0 w-full h-full object-cover opacity-60"
      />
      <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/55 to-black" />
      <div className="relative max-w-[1200px] mx-auto px-6 md:px-12 py-32 space-y-12">
        <div className="flex flex-wrap gap-x-6 gap-y-2 max-w-3xl">
          {PANTHEON.filter((d) => d.key !== 'gaia').map((d, i) => (
            <Reveal key={d.key} delay={i * 0.04}>
              <span className="text-[11px] md:text-xs tracking-[0.3em] uppercase text-white/40">{d.name}</span>
            </Reveal>
          ))}
        </div>
        <Reveal delay={0.25}>
          <CastRow showRoles={false} className="max-w-lg gap-x-2" />
        </Reveal>
        <Reveal delay={0.35}>
          <h2 className="text-white font-bold tracking-[-0.05em] leading-[0.85] text-7xl md:text-[12rem]">GAÏA</h2>
        </Reveal>
        <Reveal delay={0.45}>
          <p className="text-white text-2xl md:text-4xl font-semibold tracking-[-0.03em] leading-tight max-w-2xl">
            Une seule réalité.<br />Des milliers de relations.<br />Une intelligence pour les orchestrer.
          </p>
        </Reveal>
      </div>
    </section>
  );
}