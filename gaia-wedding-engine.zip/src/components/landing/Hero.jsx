import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { HERO_IMAGE } from '@/lib/pantheon';

export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-end overflow-hidden bg-foreground">
      <motion.img
        src={HERO_IMAGE}
        alt="Un mariage monumental sous un ciel impossible"
        className="absolute inset-0 w-full h-full object-cover"
        initial={{ scale: 1.12, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 2.4, ease: [0.23, 1, 0.32, 1] }}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/25 to-black/45" />

      <div className="relative w-full max-w-[1200px] mx-auto px-6 md:px-12 pb-20 md:pb-28">
        <motion.div
          initial={{ opacity: 0, y: 32 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.2, delay: 0.5, ease: [0.23, 1, 0.32, 1] }}
          className="max-w-3xl space-y-6"
        >
          <p className="text-[11px] tracking-[0.4em] uppercase text-white/60">Chef d'orchestre harmonique</p>
          <h1 className="text-white font-bold leading-[0.9] tracking-[-0.05em] text-[19vw] md:text-[11rem]">GAÏA</h1>
          <p className="text-2xl md:text-4xl text-white font-semibold tracking-[-0.03em] leading-tight">
            Un mariage n'est pas une liste de tâches.<br />C'est un monde vivant.
          </p>
          <p className="text-sm md:text-base text-white/70 max-w-xl leading-relaxed">
            GAÏA comprend les personnes, les événements, les ressources, les lieux, le temps et les contraintes
            qui composent votre mariage.
          </p>
          <div className="flex flex-wrap gap-3 pt-2">
            <Link to="/overview" className="aime-btn-primary no-underline">Entrer dans l'univers</Link>
            <Link to="/chat" className="aime-btn-secondary no-underline" style={{ background: 'transparent', border: '1px solid rgba(255,255,255,0.4)', color: '#fff' }}>
              Parler à GAÏA
            </Link>
          </div>
        </motion.div>
      </div>
    </section>
  );
}