import React from 'react';
import Reveal from './Reveal';

export default function UnknownSection() {
  return (
    <section className="bg-foreground py-40 md:py-64">
      <div className="max-w-[1200px] mx-auto px-6 md:px-12 space-y-12">
        <Reveal>
          <h2 className="text-white font-bold tracking-[-0.06em] leading-[0.85] text-[19vw] md:text-[14rem]">UNKNOWN</h2>
        </Reveal>
        <Reveal delay={0.2}>
          <p className="text-white text-2xl md:text-5xl font-semibold tracking-[-0.03em] max-w-3xl leading-tight">
            Quand GAÏA ne sait pas,<br />elle ne prétend pas savoir.
          </p>
        </Reveal>
      </div>
    </section>
  );
}