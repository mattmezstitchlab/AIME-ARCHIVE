import React from 'react';
import Reveal from './Reveal';
import CastRow from './CastRow';
import { Users, CalendarDays, Clock, MapPin, Briefcase, Package, ShieldAlert, Share2 } from 'lucide-react';

const DIMENSIONS = [
  { icon: Users, label: 'Personnes', desc: 'Familles, témoins, enfants, invités — avec leurs liens réels.' },
  { icon: CalendarDays, label: 'Événements', desc: 'Cérémonie, cocktail, dîner, soirée — reliés à tout le reste.' },
  { icon: Clock, label: 'Temps', desc: 'Blocs, marges, échéances, propagation.' },
  { icon: MapPin, label: 'Lieux', desc: 'Salles, extérieurs, capacités, accès.' },
  { icon: Briefcase, label: 'Prestataires', desc: 'Capacités déclarées, disponibilités, engagements.' },
  { icon: Package, label: 'Ressources', desc: 'Matériel, couverts, transport, technique.' },
  { icon: ShieldAlert, label: 'Contraintes', desc: 'Ce qui doit être vrai pour que le monde tienne.' },
  { icon: Share2, label: 'Relations', desc: 'Le tissu qui relie chaque élément à tous les autres.' },
];

export default function WorldModelSection() {
  return (
    <section className="bg-foreground text-background py-28 md:py-40">
      <div className="max-w-[1200px] mx-auto px-6 md:px-12 space-y-14">
        <Reveal>
          <p className="text-[11px] tracking-[0.4em] uppercase text-white/40">World Model</p>
          <h2 className="mt-5 text-3xl md:text-5xl font-bold tracking-[-0.05em] text-white max-w-3xl leading-tight">
            GAÏA ne gère pas seulement votre mariage.<br />Elle comprend le monde qui le compose.
          </h2>
        </Reveal>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-px bg-white/10 rounded-xl overflow-hidden">
          {DIMENSIONS.map(({ icon: Icon, label, desc }, i) => (
            <Reveal key={label} delay={i * 0.05}>
              <div className="h-full bg-[#121212] p-6 space-y-3">
                <Icon className="w-5 h-5 text-white/60" strokeWidth={1.4} />
                <p className="text-white text-sm font-semibold tracking-[0.08em] uppercase">{label}</p>
                <p className="text-white/50 text-xs leading-relaxed">{desc}</p>
              </div>
            </Reveal>
          ))}
        </div>

        <Reveal>
          <div className="space-y-6">
            <p className="text-white text-xl md:text-2xl font-semibold tracking-[-0.03em] max-w-2xl">
              Un monde, ce sont d'abord des visages.
            </p>
            <CastRow className="max-w-3xl" />
            <p className="text-white/40 text-xs max-w-2xl leading-relaxed">
              Ce langage visuel est celui de l'application — pas une illustration.
            </p>
          </div>
        </Reveal>
      </div>
    </section>
  );
}