import React from 'react';
import Reveal from './Reveal';
import PropagationStep from './PropagationStep';

const STEPS = [
  { kind: 'Prestataire', label: 'PHOTOGRAPHE', before: '14:00', after: '15:00', state: 'IMPACT', cast: ['photographe'] },
  { kind: 'Événement', label: 'SÉANCE COUPLE', before: '15:00', after: '15:30', state: 'IMPACT', cast: ['mariee', 'marie', 'photographe'] },
  { kind: 'Événement', label: 'CÉRÉMONIE', before: '16:30', after: '16:30', state: 'BLOCKED', cast: ['mariee', 'marie', 'temoin', 'musicien'] },
  { kind: 'Événement', label: 'COCKTAIL', before: '17:30', after: '17:30', state: 'NO_IMPACT', cast: ['traiteur', 'fleuriste'] },
];

export default function WhatIfSection() {
  return (
    <section id="what-if" className="bg-background py-28 md:py-44">
      <div className="max-w-[1100px] mx-auto px-6 md:px-12">
        <Reveal>
          <p className="text-[11px] tracking-[0.4em] uppercase text-muted-foreground">Et si…</p>
          <span className="aime-tag mt-4 inline-block">Exemple de démonstration</span>
          <h2 className="mt-6 text-4xl md:text-7xl font-bold tracking-[-0.05em] leading-[0.95] text-foreground max-w-3xl">
            Et si le photographe arrivait à 15h00 ?
          </h2>
        </Reveal>

        <div className="mt-16 md:mt-24 max-w-2xl">
          {STEPS.map((s, i) => (
            <PropagationStep key={s.label} step={s} index={i} last={i === STEPS.length - 1} />
          ))}
        </div>

        <Reveal delay={0.2}>
          <p className="mt-10 text-2xl md:text-4xl font-semibold tracking-[-0.03em] text-foreground max-w-2xl leading-tight">
            GAÏA ne devine pas.<br />Elle rejoue le monde entier.
          </p>
          <p className="mt-5 text-sm text-muted-foreground max-w-md leading-relaxed">
            La cérémonie ne peut pas absorber ce retard : BLOCKED. La décision, elle, vous appartient.
            Cet exemple illustre le raisonnement du moteur ; dans l'application, chaque résultat est calculé
            sur votre univers réel.
          </p>
        </Reveal>
      </div>
    </section>
  );
}