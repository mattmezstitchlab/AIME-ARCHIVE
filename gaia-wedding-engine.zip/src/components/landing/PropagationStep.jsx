import React from 'react';
import { motion } from 'framer-motion';
import { byId } from '@/lib/landingCast';

const STATE_COLOR = { NO_IMPACT: 'text-emerald-600', IMPACT: 'text-amber-600', BLOCKED: 'text-foreground' };

export default function PropagationStep({ step, index, last }) {
  const people = (step.cast || []).map(byId).filter(Boolean);
  return (
    <motion.div
      initial={{ opacity: 0, y: 18 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-60px' }}
      transition={{ duration: 0.7, delay: index * 0.35, ease: [0.23, 1, 0.32, 1] }}
      className="relative pl-8"
    >
      {!last && <span className="absolute left-[7px] top-6 bottom-[-28px] w-px bg-border" />}
      <span className="absolute left-0 top-2 w-3.5 h-3.5 rounded-full bg-foreground" />
      <div className="pb-8">
        <p className="text-[10px] tracking-[0.28em] uppercase text-muted-foreground">{step.kind}</p>
        <div className="mt-1.5 flex flex-wrap items-baseline gap-x-4">
          <h3 className="text-2xl md:text-4xl font-bold tracking-[-0.04em] text-foreground">{step.label}</h3>
          <p className="text-sm text-muted-foreground">
            <span className="line-through">{step.before}</span> → <span className="text-foreground font-medium">{step.after}</span>
          </p>
        </div>
        <div className="mt-3 flex items-center gap-3 flex-wrap">
          <div className="flex -space-x-2">
            {people.map((p) => (
              <img key={p.id} src={p.photo} alt={p.name} loading="lazy" decoding="async"
                onError={(e) => { e.currentTarget.style.opacity = '0'; }}
                className="w-8 h-8 rounded-full object-cover bg-secondary ring-2 ring-background" />
            ))}
          </div>
          <span className={`text-[11px] tracking-[0.24em] uppercase font-semibold ${STATE_COLOR[step.state]}`}>{step.state}</span>
        </div>
      </div>
    </motion.div>
  );
}