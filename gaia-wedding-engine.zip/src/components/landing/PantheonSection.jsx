import React from 'react';
import { PANTHEON } from '@/lib/pantheon';
import DeityBlock from './DeityBlock';
import ChronosChain from './ChronosChain';
import Reveal from './Reveal';

export default function PantheonSection() {
  return (
    <section id="pantheon" className="bg-[#0C0C0C]">
      <div className="max-w-[1200px] mx-auto px-6 md:px-12 py-28 md:py-40 space-y-6">
        <Reveal>
          <p className="text-[11px] tracking-[0.4em] uppercase text-white/40">Le Panthéon</p>
          <h2 className="mt-5 text-white font-bold tracking-[-0.05em] leading-[0.9] text-5xl md:text-8xl">
            Les forces<br />d'un mariage vivant
          </h2>
          <p className="mt-6 text-white/50 max-w-xl text-sm leading-relaxed">
            Quatorze chapitres. Un seul monde. Une seule intelligence pour le tenir ensemble.
          </p>
        </Reveal>
      </div>

      {PANTHEON.map((deity, i) => (
        <DeityBlock key={deity.key} deity={deity} index={i}>
          {deity.key === 'chronos' ? <ChronosChain /> : null}
        </DeityBlock>
      ))}
    </section>
  );
}