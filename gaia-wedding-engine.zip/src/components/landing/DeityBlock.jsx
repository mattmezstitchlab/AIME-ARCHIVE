import React, { useRef } from 'react';
import { motion, useScroll, useTransform, useReducedMotion } from 'framer-motion';
import Reveal from './Reveal';

export default function DeityBlock({ deity, index, children }) {
  const ref = useRef(null);
  const reduced = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start end', 'end start'] });
  const y = useTransform(scrollYProgress, [0, 1], reduced ? ['0%', '0%'] : ['-5%', '5%']);
  const flip = index % 2 === 1;

  return (
    <section ref={ref} className="relative border-t border-white/10">
      <div className={`max-w-[1400px] mx-auto grid lg:grid-cols-2 items-stretch ${flip ? 'lg:[direction:rtl]' : ''}`}>
        <div className="relative h-[56vh] lg:h-[94vh] overflow-hidden">
          <motion.img
            src={deity.image}
            alt={`${deity.name} — ${deity.title}`}
            loading="lazy"
            decoding="async"
            style={{ y }}
            className="absolute inset-0 w-full h-[110%] object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-black/20" />
        </div>

        <div className="[direction:ltr] flex items-center px-6 md:px-16 py-16 lg:py-0">
          <div className="space-y-8 max-w-xl">
            <Reveal>
              <p className="text-[11px] tracking-[0.4em] uppercase text-white/35">
                Chapitre {String(index + 1).padStart(2, '0')}
              </p>
              <h3 className="mt-5 text-white font-bold tracking-[-0.05em] leading-[0.9] text-6xl md:text-8xl">{deity.name}</h3>
            </Reveal>
            <Reveal delay={0.12}>
              <p className="text-white text-2xl md:text-4xl font-semibold tracking-[-0.03em] leading-[1.1]">
                {deity.line}
              </p>
            </Reveal>
            <Reveal delay={0.22}>
              <p className="text-white/60 text-sm md:text-base leading-relaxed">{deity.manifesto}</p>
            </Reveal>
            <Reveal delay={0.3}>
              <div className="border-t border-white/10 pt-5 space-y-1.5">
                <p className="text-[10px] tracking-[0.28em] uppercase text-white/30">{deity.title}</p>
                <p className="text-white/55 text-sm">{deity.innovation}</p>
              </div>
            </Reveal>
            {children && <Reveal delay={0.36}>{children}</Reveal>}
          </div>
        </div>
      </div>
    </section>
  );
}