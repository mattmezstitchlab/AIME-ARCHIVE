import React from 'react';
import Reveal from './Reveal';

const LINES = [
  ['Les dieux', 'sont les dimensions.'],
  ['GAÏA', 'est le système.'],
  ['Le couple', 'est le centre.'],
  ['Le mariage', 'est le monde.'],
];

export default function DoctrineSection() {
  return (
    <section className="bg-background py-28 md:py-40">
      <div className="max-w-[1200px] mx-auto px-6 md:px-12 space-y-3">
        {LINES.map(([a, b], i) => (
          <Reveal key={a} delay={i * 0.08}>
            <p className="text-3xl md:text-6xl font-bold tracking-[-0.05em] leading-tight">
              <span className="text-foreground">{a} </span>
              <span className="text-muted-foreground">{b}</span>
            </p>
          </Reveal>
        ))}
      </div>
    </section>
  );
}