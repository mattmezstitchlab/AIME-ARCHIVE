import React from 'react';
import Avatar from '@/components/identity/Avatar';
import AvatarStack from '@/components/identity/AvatarStack';
import { identityOf } from '@/lib/identity';
import { RESOURCE_TYPE_LABELS, AVAILABILITY_LABELS } from '@/lib/resources';

const AVAILABILITY_CLASS = { AVAILABLE: 'aime-tag-live', UNAVAILABLE: 'aime-tag-dark' };

export default function ResourceCard({ resource, services = [], team = [], blocks = [], conflicts = [] }) {
  const id = identityOf(resource);
  const availability = resource.availability || 'UNKNOWN';
  return (
    <div className={`rounded-xl border bg-background p-5 space-y-3 ${conflicts.length ? 'border-[#F87171]' : 'border-border'}`}>
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-3 min-w-0">
          <Avatar entity={resource} size="lg" shape="rounded" state={conflicts.length ? 'conflict' : undefined} />
          <div className="min-w-0">
            <p className="text-sm font-semibold text-foreground truncate">{id.name}</p>
            <p className="text-xs text-muted-foreground">
              {RESOURCE_TYPE_LABELS[resource.entity_type] || resource.entity_type}
              {resource.role ? ` · ${resource.role}` : ''}
              {resource.location ? ` · ${resource.location}` : ''}
            </p>
          </div>
        </div>
        <span className={AVAILABILITY_CLASS[availability] || 'aime-tag'}>{AVAILABILITY_LABELS[availability]}</span>
      </div>

      <p className="text-xs text-muted-foreground">
        {resource.capability ? `Capacité : ${resource.capability}` : 'Capacité non déclarée'}
        {typeof resource.capability_capacity === 'number' && ` · ${resource.capability_capacity} ${resource.capability_unit || ''}`}
        {typeof resource.capacity === 'number' && ` · ${resource.capacity} place(s)`}
      </p>
      <p className="text-xs text-muted-foreground">
        {resource.available_from && resource.available_to
          ? `${resource.available_from} — ${resource.available_to}`
          : 'Fenêtre de disponibilité inconnue'}
      </p>

      {services.length > 0 && (
        <p className="text-xs text-foreground">Services : {services.map((s) => s.name).join(' · ')}</p>
      )}

      {team.length > 0 && (
        <div className="flex items-center gap-3">
          <AvatarStack entities={team} size="xs" />
          <span className="text-xs text-muted-foreground">{team.map((t) => t.name).join(' · ')}</span>
        </div>
      )}

      {blocks.length > 0 && (
        <div className="space-y-1">
          {blocks.map((b) => (
            <p key={b.id} className="text-xs text-muted-foreground">{b.start_time}{b.end_time ? ` → ${b.end_time}` : ''} · {b.label}</p>
          ))}
        </div>
      )}

      {conflicts.map((c, i) => (
        <p key={i} className="text-xs text-red-600">{c.type} · {c.message}</p>
      ))}
    </div>
  );
}