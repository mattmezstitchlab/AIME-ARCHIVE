import React from 'react';
import { EVENT_STATUS_LABELS } from '@/lib/events';

const STATUS_COLOR = { EVENT_READY: '#4ADE80', EVENT_AT_RISK: '#FACC15', EVENT_BLOCKED: '#F87171', EVENT_UNKNOWN: '#E5E3DC' };
const COL = 240;
const CENTER = 170;

// Représentation du graphe : temps horizontal, éléments requis autour de chaque événement.
export default function EventGraph({ view }) {
  const evaluations = view.events
    .map((e) => ({ event: e, ev: view.evalOf(e.id) }))
    .filter((x) => x.ev)
    .sort((a, b) => (a.ev.interval?.start ?? 1e9) - (b.ev.interval?.start ?? 1e9));

  if (!evaluations.length) return <p className="text-sm text-muted-foreground">Aucun événement à représenter.</p>;

  const width = Math.max(720, evaluations.length * COL);
  const pos = {};
  evaluations.forEach(({ event }, i) => { pos[event.id] = COL / 2 + i * COL; });

  return (
    <div className="overflow-x-auto rounded-xl border border-border bg-background p-4">
      <svg width={width} height="340" role="img" aria-label="Graphe des événements">
        {/* enchaînements */}
        {view.events.flatMap((e) => view.dependenciesOf(e.id)
          .filter((r) => r.from_entity_id === e.id && pos[r.to_entity_id] !== undefined)
          .map((r) => (
            <line key={r.id} x1={pos[e.id] + 46} y1={CENTER} x2={pos[r.to_entity_id] - 46} y2={CENTER}
              stroke="#121212" strokeWidth="1" strokeDasharray="4 4" />
          )))}

        {evaluations.map(({ event, ev }) => {
          const x = pos[event.id];
          const people = view.participantsOf(event.id).slice(0, 4);
          const reqs = (ev.requirements || []).slice(0, 4);
          return (
            <g key={event.id}>
              <text x={x} y={26} textAnchor="middle" fontSize="11" fill="#727169">{ev.time || 'horaire inconnu'}</text>
              {/* personnes au-dessus */}
              {people.map((p, i) => (
                <g key={p.id}>
                  <circle cx={x - 45 + i * 30} cy={72} r="12" fill="#F5F3F0" stroke="#121212" strokeWidth="1" />
                  {p.avatar_url && (
                    <>
                      <clipPath id={`ev-p-${event.id}-${p.id}`}><circle cx={x - 45 + i * 30} cy={72} r="12" /></clipPath>
                      <image href={p.avatar_url} x={x - 57 + i * 30} y={60} width="24" height="24"
                        preserveAspectRatio="xMidYMid slice" clipPath={`url(#ev-p-${event.id}-${p.id})`} />
                    </>
                  )}
                  <line x1={x - 45 + i * 30} y1={84} x2={x} y2={CENTER - 26} stroke="#E5E3DC" strokeWidth="1" />
                </g>
              ))}

              {/* l'événement */}
              <rect x={x - 76} y={CENTER - 26} width="152" height="52" rx="12" fill="#121212" />
              <circle cx={x - 60} cy={CENTER} r="5" fill={STATUS_COLOR[ev.status]} />
              <text x={x + 4} y={CENTER - 4} textAnchor="middle" fontSize="12" fill="#FFFFFF">{event.name}</text>
              <text x={x + 4} y={CENTER + 13} textAnchor="middle" fontSize="10" fill="rgba(255,255,255,0.65)">
                {EVENT_STATUS_LABELS[ev.status]}
              </text>

              {/* ressources / prestataires / lieu en dessous */}
              {reqs.map((r, i) => (
                <g key={i}>
                  <line x1={x} y1={CENTER + 26} x2={x} y2={CENTER + 54 + i * 26} stroke="#E5E3DC" strokeWidth="1" />
                  <circle cx={x - 62} cy={CENTER + 54 + i * 26} r="4"
                    fill={r.state === 'OK' ? '#4ADE80' : r.state === 'MISSING' ? '#F87171' : '#FACC15'} />
                  <text x={x - 52} y={CENTER + 58 + i * 26} fontSize="11" fill="#121212">{r.label.slice(0, 22)}</text>
                </g>
              ))}
            </g>
          );
        })}
      </svg>
    </div>
  );
}