import React from 'react';
import { MapPin, Check, HelpCircle, X } from 'lucide-react';
import Avatar from '@/components/identity/Avatar';
import AvatarStack from '@/components/identity/AvatarStack';
import { levelStyle } from '@/lib/levels';
import { EVENT_STATUS_LABELS, EVENT_STATUS_LEVEL, EVENT_CATEGORY_LABELS, REQUIREMENT_LABELS } from '@/lib/events';

const STATE_ICON = {
  OK: <Check className="w-3.5 h-3.5 text-green-600" strokeWidth={1.8} />,
  UNKNOWN: <HelpCircle className="w-3.5 h-3.5 text-[#B08900]" strokeWidth={1.8} />,
  MISSING: <X className="w-3.5 h-3.5 text-red-600" strokeWidth={1.8} />,
};

export default function EventCard({ event, evaluation, participants = [], venue, conflicts = [], dependencies = [] }) {
  const status = evaluation?.status || 'EVENT_UNKNOWN';
  const lv = levelStyle(EVENT_STATUS_LEVEL[status]);
  const requirements = evaluation?.requirements || [];
  return (
    <article className={`rounded-xl border bg-background p-5 space-y-3 ${lv.ring}`}>
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <span className="aime-tag">{EVENT_CATEGORY_LABELS[event.category] || event.category || 'Événement'}</span>
          <h3 className="text-base font-semibold text-foreground mt-2">{event.name}</h3>
          <p className="text-xs text-muted-foreground">{evaluation?.time || 'Horaire inconnu'}</p>
        </div>
        <span className="flex items-center gap-2 text-xs shrink-0">
          <span className={`w-2 h-2 rounded-full ${lv.dot}`} />
          {EVENT_STATUS_LABELS[status]}
        </span>
      </div>

      {venue && (
        <p className="flex items-center gap-2 text-xs text-foreground">
          <MapPin className="w-3.5 h-3.5 text-muted-foreground" strokeWidth={1.5} /> {venue.name}
        </p>
      )}

      {participants.length > 0 && (
        <div className="flex items-center gap-3">
          <AvatarStack entities={participants} max={6} />
          <span className="text-xs text-muted-foreground truncate">{participants.map((p) => p.first_name || p.name).join(' · ')}</span>
        </div>
      )}

      <div className="space-y-1.5">
        {requirements.length === 0 && <p className="text-xs text-muted-foreground">Aucune exigence déclarée : état inconnu.</p>}
        {requirements.map((r, i) => (
          <div key={i} className="flex items-center gap-2 text-xs">
            {STATE_ICON[r.state]}
            {r.entity ? <Avatar entity={r.entity} size="xs" badge={false} /> : null}
            <span className="text-foreground truncate">{r.label}</span>
            <span className="text-muted-foreground">· {REQUIREMENT_LABELS[r.relation_type] || r.relation_type}</span>
          </div>
        ))}
      </div>

      {dependencies.length > 0 && (
        <p className="text-xs text-muted-foreground">{dependencies.length} dépendance(s) d'enchaînement.</p>
      )}

      {conflicts.map((c, i) => (
        <p key={i} className="text-xs text-red-600">{c.type} · {c.message}</p>
      ))}
    </article>
  );
}