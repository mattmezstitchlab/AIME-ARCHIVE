import React, { useState } from 'react';
import { RSVP_LABELS } from '@/lib/social';
import Avatar from '@/components/identity/Avatar';
import AvatarStack from '@/components/identity/AvatarStack';

export default function TableCard({ table, seated, people, constraintStatus, onAssign, busy }) {
  const [choice, setChoice] = useState('');
  const attending = seated.filter((p) => p.rsvp_status !== 'DECLINED');
  const over = typeof table.capacity === 'number' && attending.length > table.capacity;

  return (
    <div className="rounded-xl border border-border bg-background p-5 space-y-3">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-sm font-semibold text-foreground">{table.name}</p>
          <p className="text-xs text-muted-foreground">{table.location || 'emplacement inconnu'}</p>
        </div>
        <div className="flex items-center gap-2">
          {over && <span className="aime-tag-dark">Capacity</span>}
          <span className={over ? 'aime-tag-dark' : 'aime-tag'}>
            {attending.length}/{typeof table.capacity === 'number' ? table.capacity : '?'} places
          </span>
        </div>
      </div>

      {seated.length > 0 && (
        <div className="flex items-center gap-3">
          <AvatarStack entities={seated} max={6} />
          <span className="text-xs text-muted-foreground truncate">{seated.map((p) => p.first_name || p.name).join(' · ')}</span>
        </div>
      )}

      {constraintStatus && <p className="text-xs text-muted-foreground">Capacité : {constraintStatus}</p>}

      <div className="space-y-1">
        {seated.length === 0 && <p className="text-xs text-muted-foreground">Aucune personne affectée.</p>}
        {seated.map((p) => (
          <div key={p.id} className="flex items-center gap-2 text-xs text-foreground">
            <Avatar entity={p} size="xs" badge={false} />
            {p.name} <span className="text-muted-foreground">· {RSVP_LABELS[p.rsvp_status] || 'RSVP inconnu'}</span>
          </div>
        ))}
      </div>

      <div className="flex flex-wrap items-center gap-2 pt-1">
        <select
          className="flex-1 min-w-[160px] rounded-full border border-border bg-background px-4 py-2 text-sm outline-none focus:border-ring"
          value={choice}
          onChange={(e) => setChoice(e.target.value)}
        >
          <option value="">Affecter une personne…</option>
          {people.filter((p) => !seated.some((s) => s.id === p.id)).map((p) => (
            <option key={p.id} value={p.id}>{p.name}</option>
          ))}
        </select>
        <button
          className="aime-btn-secondary"
          disabled={!choice || busy}
          style={{ opacity: !choice || busy ? 0.4 : 1 }}
          onClick={() => onAssign(choice, table)}
        >
          Simuler l'affectation
        </button>
      </div>
    </div>
  );
}