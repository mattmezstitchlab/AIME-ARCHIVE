import React from 'react';
import { RSVP_LABELS, RSVP_ORDER, RELATION_LABELS } from '@/lib/social';
import { TRUTH_LABELS } from '@/lib/levels';
import Avatar from '@/components/identity/Avatar';

const RSVP_CLASS = { CONFIRMED: 'aime-tag-live', DECLINED: 'aime-tag-dark' };

export default function PersonCard({ person, table, relations, byId, onRsvp, busy }) {
  return (
    <div className="rounded-xl border border-border bg-background p-5 space-y-3">
      <div className="flex items-start justify-between gap-3">
        <Avatar entity={person} size="lg" />
        <div className="min-w-0 flex-1">
          <p className="text-sm font-semibold text-foreground">{person.name}</p>
          <p className="text-xs text-muted-foreground">
            {person.role || 'invité'} · fiabilité : {TRUTH_LABELS[person.truth_status] || 'inconnue'}
            {table ? ` · ${table.name}` : ' · aucune table'}
          </p>
        </div>
        <span className={RSVP_CLASS[person.rsvp_status] || 'aime-tag'}>
          {RSVP_LABELS[person.rsvp_status] || 'RSVP inconnu'}
        </span>
      </div>

      {(person.accessibility || []).length > 0 && (
        <p className="text-xs text-muted-foreground">Accessibilité : {person.accessibility.join(' · ')}</p>
      )}

      {relations.length > 0 && (
        <div className="space-y-1">
          {relations.map((r) => {
            const other = byId[r.from_entity_id === person.id ? r.to_entity_id : r.from_entity_id];
            const outgoing = r.from_entity_id === person.id;
            return (
              <p key={r.id} className="text-xs text-muted-foreground">
                {outgoing ? `${RELATION_LABELS[r.relation_type] || r.relation_type} ${other?.name || '—'}`
                  : `${other?.name || '—'} · ${RELATION_LABELS[r.relation_type] || r.relation_type} lui`}
              </p>
            );
          })}
        </div>
      )}

      <div className="flex flex-wrap gap-2 pt-1">
        {RSVP_ORDER.filter((s) => s !== person.rsvp_status).map((status) => (
          <button
            key={status}
            className="aime-btn-primary"
            style={{ padding: '6px 14px', fontSize: 12, opacity: busy ? 0.5 : 1 }}
            disabled={busy}
            onClick={() => onRsvp(person, status)}
          >
            {RSVP_LABELS[status]}
          </button>
        ))}
      </div>
    </div>
  );
}