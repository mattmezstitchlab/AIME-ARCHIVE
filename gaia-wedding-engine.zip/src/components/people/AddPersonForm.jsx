import React, { useState } from 'react';
import { engine } from '@/lib/engineClient';
import { useWorld } from '@/hooks/useWorld';
import { UserPlus, Loader2 } from 'lucide-react';

export default function AddPersonForm() {
  const { activeWorldId, refresh } = useWorld();
  const [first, setFirst] = useState('');
  const [last, setLast] = useState('');
  const [role, setRole] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    if (!first.trim() || busy) return;
    setBusy(true);
    await engine.createEntity(activeWorldId, {
      name: `${first.trim()} ${last.trim()}`.trim(),
      entity_type: 'person',
      first_name: first.trim(),
      last_name: last.trim(),
      role: role.trim(),
      rsvp_status: 'INVITED',
      truth_status: 'proposed',
    });
    setFirst(''); setLast(''); setRole('');
    refresh();
    setBusy(false);
  };

  const field = 'flex-1 min-w-[120px] rounded-full border border-border bg-background px-4 py-2 text-sm outline-none focus:border-ring';

  return (
    <div className="flex flex-wrap items-center gap-2 rounded-xl border border-border bg-card p-4 mb-6">
      <input className={field} value={first} onChange={(e) => setFirst(e.target.value)} placeholder="Prénom" />
      <input className={field} value={last} onChange={(e) => setLast(e.target.value)} placeholder="Nom" />
      <input className={field} value={role} onChange={(e) => setRole(e.target.value)} placeholder="Rôle (témoin, parent…)" />
      <button className="aime-btn-secondary" onClick={submit} disabled={busy || !first.trim()} style={{ opacity: busy || !first.trim() ? 0.4 : 1 }}>
        {busy ? <Loader2 className="w-3.5 h-3.5 animate-spin" strokeWidth={1.5} /> : <UserPlus className="w-3.5 h-3.5" strokeWidth={1.5} />}
        Ajouter la personne
      </button>
    </div>
  );
}