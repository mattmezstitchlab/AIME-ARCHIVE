import React from 'react';
import { motion } from 'framer-motion';
import { SOCIAL_CONSTRAINT_LABELS } from '@/lib/social';

const W = 900;
const H = 620;
const CX = W / 2;
const CY = H / 2;
const GROUP_R = 150;
const PERSON_R = 250;

const RSVP_COLOR = { CONFIRMED: '#4ADE80', PENDING: '#FACC15', MAYBE: '#60A5FA', DECLINED: '#727169', INVITED: '#E5E3DC' };
const CONSTRAINT_COLOR = { must_be_separated: '#F87171', different_table: '#F87171', must_be_near: '#4ADE80', same_table: '#4ADE80' };

export default function SocialConstellation({ view, constraints }) {
  const { people, groups, membersOf, byId } = view;
  const groupPos = {};
  groups.forEach((g, i) => {
    const a = (i / Math.max(groups.length, 1)) * Math.PI * 2 - Math.PI / 2;
    groupPos[g.id] = { x: CX + Math.cos(a) * GROUP_R, y: CY + Math.sin(a) * GROUP_R };
  });

  const ordered = groups.flatMap((g) => membersOf(g.id).map((p) => ({ person: p, group: g })));
  const placed = new Set(ordered.map((o) => o.person.id));
  const loose = people.filter((p) => !placed.has(p.id)).map((p) => ({ person: p, group: null }));
  const nodes = [...ordered, ...loose];
  const personPos = {};
  nodes.forEach((n, i) => {
    const a = (i / Math.max(nodes.length, 1)) * Math.PI * 2 - Math.PI / 2;
    personPos[n.person.id] = { x: CX + Math.cos(a) * PERSON_R, y: CY + Math.sin(a) * PERSON_R, group: n.group };
  });

  return (
    <div className="relative w-full overflow-x-auto rounded-xl border border-border bg-card">
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full min-w-[720px]">
        {groups.map((g) => (
          <line key={`gc-${g.id}`} x1={CX} y1={CY} x2={groupPos[g.id].x} y2={groupPos[g.id].y} stroke="#E5E3DC" strokeWidth="1" />
        ))}
        {nodes.map(({ person, group }) => {
          const p = personPos[person.id];
          const target = group ? groupPos[group.id] : { x: CX, y: CY };
          return <line key={`pc-${person.id}`} x1={p.x} y1={p.y} x2={target.x} y2={target.y} stroke="#E5E3DC" strokeWidth="1" />;
        })}
        {view.social.map((r) => {
          const a = personPos[r.from_entity_id];
          const b = personPos[r.to_entity_id];
          if (!a || !b) return null;
          return <line key={`sr-${r.id}`} x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke="#121212" strokeOpacity="0.25" strokeWidth="1" strokeDasharray="4 4" />;
        })}
        {constraints.map((c) => {
          const a = personPos[c.entity_id];
          const b = personPos[c.target_entity_id];
          const color = CONSTRAINT_COLOR[c.constraint_type];
          if (!a || !b || !color) return null;
          return <line key={`cs-${c.id}`} x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke={color} strokeWidth="2" strokeOpacity={c.status === 'violated' ? 1 : 0.45} />;
        })}
        {groups.map((g) => (
          <circle key={g.id} cx={groupPos[g.id].x} cy={groupPos[g.id].y} r="10" fill="#F5F3F0" stroke="#121212" strokeWidth="1.5" />
        ))}
        <defs>
          {nodes.filter(({ person }) => person.avatar_url).map(({ person }) => (
            <clipPath key={`clip-${person.id}`} id={`clip-${person.id}`}>
              <circle cx={personPos[person.id].x} cy={personPos[person.id].y} r="14" />
            </clipPath>
          ))}
        </defs>
        {nodes.map(({ person }) => {
          const pos = personPos[person.id];
          if (person.avatar_url) {
            return (
              <g key={person.id}>
                <image
                  href={person.avatar_url}
                  x={pos.x - 14} y={pos.y - 14} width="28" height="28"
                  preserveAspectRatio="xMidYMid slice"
                  clipPath={`url(#clip-${person.id})`}
                />
                <circle cx={pos.x} cy={pos.y} r="14" fill="none" stroke={RSVP_COLOR[person.rsvp_status] || '#E5E3DC'} strokeWidth="2" />
              </g>
            );
          }
          return (
            <motion.circle
              key={person.id}
              cx={pos.x}
              cy={pos.y}
              r="7"
              fill={RSVP_COLOR[person.rsvp_status] || '#E5E3DC'}
              stroke="#121212"
              strokeWidth="1"
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.4 }}
            />
          );
        })}
        <circle cx={CX} cy={CY} r="34" fill="#121212" />
        <text x={CX} y={CY + 4} textAnchor="middle" fill="#FFFFFF" fontSize="12" fontWeight="600">GAÏA</text>
        {groups.map((g) => (
          <text key={`gt-${g.id}`} x={groupPos[g.id].x} y={groupPos[g.id].y - 16} textAnchor="middle" fontSize="11" fill="#727169">{g.name}</text>
        ))}
        {nodes.map(({ person }) => (
          <text key={`pt-${person.id}`} x={personPos[person.id].x} y={personPos[person.id].y - (person.avatar_url ? 20 : 12)} textAnchor="middle" fontSize="11" fill="#121212">
            {person.first_name || person.name}
          </text>
        ))}
      </svg>
      <div className="flex flex-wrap gap-4 px-5 pb-5 text-xs text-muted-foreground">
        <span>— relation sociale</span>
        <span className="text-green-600">— {SOCIAL_CONSTRAINT_LABELS.must_be_near}</span>
        <span className="text-red-600">— {SOCIAL_CONSTRAINT_LABELS.must_be_separated}</span>
        <span>● couleur du nœud = RSVP</span>
      </div>
    </div>
  );
}