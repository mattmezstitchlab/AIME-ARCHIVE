import React from 'react';
import SocialNav from '@/components/people/SocialNav';

export default function SocialHeader({ title, subtitle, actions }) {
  return (
    <header className="pt-12 pb-6 space-y-4">
      <span className="aime-tag">People Graph</span>
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h2 className="text-3xl font-bold text-foreground">{title}</h2>
          <p className="text-xs text-muted-foreground mt-2 max-w-2xl">{subtitle}</p>
        </div>
        {actions}
      </div>
      <SocialNav />
    </header>
  );
}