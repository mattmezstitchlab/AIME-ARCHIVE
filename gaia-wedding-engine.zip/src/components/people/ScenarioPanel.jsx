import React from 'react';
import ImpactCard from '@/components/chat/ImpactCard';

// Panneau de décision partagé par toutes les vues sociales.
export default function ScenarioPanel({ pending, message, busy, onApply, onAbandon }) {
  if (!pending && !message) return null;
  return (
    <div className="rounded-xl border border-border bg-card p-5 mb-6">
      <p className="text-xs text-muted-foreground">Résultat calculé par le moteur déterministe — rien n'est modifié sans votre décision.</p>
      {message && <p className="text-sm text-foreground mt-2">{message}</p>}
      {pending && (
        <ImpactCard
          scenario={pending.scenario}
          result={pending.result}
          onApply={onApply}
          onAbandon={onAbandon}
          busy={busy}
        />
      )}
    </div>
  );
}