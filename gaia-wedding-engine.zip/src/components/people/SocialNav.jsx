import React from 'react';
import { NavLink } from 'react-router-dom';

const TABS = [
  { to: '/people', label: 'Personnes' },
  { to: '/groups', label: 'Groupes' },
  { to: '/social-graph', label: 'Constellation' },
  { to: '/social-constraints', label: 'Contraintes humaines' },
  { to: '/tables', label: 'Tables' },
  { to: '/resources', label: 'Ressources' },
];

export default function SocialNav() {
  return (
    <div className="flex flex-wrap gap-2">
      {TABS.map(({ to, label }) => (
        <NavLink key={to} to={to} className="no-underline">
          {({ isActive }) => (
            <span className={isActive ? 'aime-btn-secondary' : 'aime-btn-primary'} style={{ padding: '8px 18px', fontSize: 13 }}>
              {label}
            </span>
          )}
        </NavLink>
      ))}
    </div>
  );
}