import React from 'react';
import { levelStyle, RESULT_LABELS, SCENARIO_STATUS_LABELS } from '@/lib/levels';
import { Check, X, Loader2, Undo2 } from 'lucide-react';
import Avatar from '@/components/identity/Avatar';
import AvatarStack from '@/components/identity/AvatarStack';
import { useWorld } from '@/hooks/useWorld';

export default function ImpactCard({ scenario, result, onApply, onAbandon, onRollback, busy }) {
  const { data } = useWorld();
  if (!scenario) return null;
  const type = result?.type || scenario.result_type;
  // Représentation seulement : les entités affichées sont retrouvées dans le World, jamais inventées.
  const byName = Object.fromEntries((data?.entities || []).map((e) => [e.name, e]));
  const affected = [
    ...(scenario.impacts || []).map((i) => byName[i.entity_name]),
    ...(scenario.changes || []).map((c) => byName[c.block_label] || byName[c.target_label]),
  ]
    .filter(Boolean)
    .filter((e, i, arr) => arr.findIndex((x) => x.id === e.id) === i);
  return (
    <div className="mt-3 rounded-xl border border-border bg-background p-5 space-y-3 shadow-[0_1px_3px_rgba(0,0,0,0.08)]">
      <div className="space-y-2">
        <span className={type === 'BLOCKED' || type === 'CONFLICT' ? 'aime-tag-dark' : 'aime-tag'}>
          {RESULT_LABELS[type] || 'Résultat causal'}
        </span>
        <p className="text-sm text-foreground font-medium">{scenario.title}</p>
        {affected.length > 0 && <AvatarStack entities={affected} max={5} />}
      </div>

      {(scenario.changes || []).map((ch, i) => (
        <p key={i} className="text-xs text-muted-foreground">
          {ch.block_label || ch.target_label}
          {ch.kind === 'relation_set' ? '' : (
            <> : <span className="line-through">{ch.old_value}</span> → <span className="text-foreground font-semibold">{ch.new_value}</span></>
          )}
          {ch.reason && ` — ${ch.reason}`}
        </p>
      ))}

      {result?.blockers?.length > 0 && (
        <div className="space-y-1">
          {result.blockers.map((b, i) => (
            <p key={i} className="text-xs text-red-600">Bloquant : {b}</p>
          ))}
        </div>
      )}

      <div className="space-y-2">
        {(scenario.impacts || []).length === 0 && (
          <p className="text-xs text-green-600">Aucun impact détecté sur le reste de l'univers.</p>
        )}
        {(scenario.impacts || []).map((imp, i) => {
          const lv = levelStyle(imp.level);
          return (
            <div key={i} className="flex items-start gap-2 text-xs">
              {byName[imp.entity_name]
                ? <Avatar entity={byName[imp.entity_name]} size="xs" badge={false} />
                : <span className={`w-2 h-2 rounded-full mt-1 shrink-0 ${lv.dot}`} />}
              <div>
                <span className={`${lv.text} font-semibold`}>{imp.entity_name} · {lv.label}</span>
                <p className="text-muted-foreground">{imp.reason}</p>
              </div>
            </div>
          );
        })}
      </div>

      {result?.unknowns?.length > 0 && (
        <p className="text-xs text-muted-foreground">
          Informations manquantes : {result.unknowns.map((u) => u.description).join(' · ')}
        </p>
      )}

      {scenario.status === 'draft' ? (
        <div className="flex gap-2 pt-1">
          <button className="aime-btn-secondary" disabled={busy} onClick={() => onApply(scenario)} style={{ opacity: busy ? 0.5 : 1 }}>
            {busy ? <Loader2 className="w-3.5 h-3.5 animate-spin" strokeWidth={1.5} /> : <Check className="w-3.5 h-3.5" strokeWidth={1.5} />}
            Appliquer le scénario
          </button>
          <button className="aime-btn-primary" disabled={busy} onClick={() => onAbandon(scenario)} style={{ opacity: busy ? 0.5 : 1 }}>
            <X className="w-3.5 h-3.5" strokeWidth={1.5} />
            Abandonner
          </button>
        </div>
      ) : (
        <div className="flex items-center gap-2 flex-wrap pt-1">
          <span className={scenario.status === 'applied' ? 'aime-tag-live' : 'aime-tag'}>
            {SCENARIO_STATUS_LABELS[scenario.status] || scenario.status}
          </span>
          {scenario.failure_reason && <span className="text-xs text-red-600">{scenario.failure_reason}</span>}
          {scenario.status === 'applied' && onRollback && (
            <button className="aime-btn-primary" disabled={busy} onClick={() => onRollback(scenario)} style={{ opacity: busy ? 0.5 : 1 }}>
              <Undo2 className="w-3.5 h-3.5" strokeWidth={1.5} />
              Annuler et restaurer
            </button>
          )}
        </div>
      )}
    </div>
  );
}