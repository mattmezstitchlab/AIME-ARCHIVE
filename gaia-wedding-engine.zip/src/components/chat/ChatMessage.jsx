import React from 'react';
import GaiaMark from '@/components/brand/GaiaMark';
import ImpactCard from './ImpactCard';

export default function ChatMessage({ message, onApply, onAbandon, onRollback, busy }) {
  const isUser = message.role === 'user';
  return (
    <div className={`flex ${isUser ? 'justify-end' : 'justify-start'} mb-5`}>
      <div className={`max-w-[85%] ${isUser ? '' : 'flex gap-3'}`}>
        {!isUser && (
          <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center shrink-0 mt-1">
            <GaiaMark className="w-5 h-5 text-primary-foreground" />
          </div>
        )}
        <div className="min-w-0">
          <div
            className={`rounded-xl px-4 py-3 text-sm leading-relaxed whitespace-pre-wrap border ${
              isUser
                ? 'bg-secondary text-foreground border-border'
                : 'bg-background text-foreground border-border shadow-[0_1px_3px_rgba(0,0,0,0.08)]'
            }`}
          >
            {message.text}
          </div>
          {message.scenario && (
            <ImpactCard
              scenario={message.scenario}
              result={message.result}
              onApply={onApply}
              onAbandon={onAbandon}
              onRollback={onRollback}
              busy={busy}
            />
          )}
        </div>
      </div>
    </div>
  );
}