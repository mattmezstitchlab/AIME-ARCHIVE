# EventCore — Phase 1 (passive)

> **Statut** : documentation-only · `v0.1.0-phase1-passive`
> **Effet sur AIME Cachet** : **strictement aucun**.

---

## 🎯 Objectif

Cette couche expose, **en lecture seule**, les briques techniques génériques
déjà présentes dans AIME Cachet (scellement, timeline, wallets, studio).

Elle prépare narrativement une éventuelle généralisation **future** à d'autres
types d'événements (mariage, conférence, festival, atelier, etc.), **sans
modifier le produit existant**.

---

## 🔒 Règles non-négociables (Phase 1)

1. **Aucun fichier existant n'est modifié.**
2. **Aucun import existant n'est modifié.**
3. **Aucune page, route, UI ou comportement n'est altéré.**
4. **L'entité `Prestation` n'est pas renommée.** Elle reste l'entité officielle.
5. **Le hash intermittent v1 est figé.**
   `HASHED_FIELDS`, `sealCachet`, `verifyCachet` ne sont pas touchés.
6. **Aucune nouvelle verticale n'est créée** (pas d'Atelier, pas de Wedding…).
7. **Aucune nouvelle route n'est créée.**
8. **Aucune migration de données.**

Si cette couche disparaissait demain, **AIME Cachet fonctionnerait exactement
comme avant**. C'est la définition d'une couche passive.

---

## 📂 Fichiers créés (uniquement)

```
lib/event-core/
├── index.js                       (point d'entrée + HASH_PROFILES_PLANNED)
├── README.md                      (ce fichier)
├── seal/
│   └── index.js                   (ré-export verificationHash + cachetCode + sealedState)
├── timeline/
│   └── index.js                   (ré-export timelineScale + buildTimeline)
├── wallets/
│   └── index.js                   (ré-export wallets + walletFilter)
├── studio/
│   └── index.js                   (ré-export docCatalog + docTemplates)
└── verticals/
    └── intermittence.js           (config consolidée — référence passive)
```

---

## 🧭 Ce que chaque ré-export représente

| Module | Source réelle | Pourquoi exposé ici |
|---|---|---|
| `event-core/seal` | `lib/verificationHash.js`, `lib/cachetCode.js`, `lib/sealedState.js` | Scellement technique universel : empreinte SHA-256 + code unique + 3 états (none/synced/stale). Brique candidate à une réutilisation. |
| `event-core/timeline` | `lib/timelineScale.js`, `lib/aimeData.js` | Timeline multi-échelle (année/mois/jour/programme) déjà agnostique. |
| `event-core/wallets` | `lib/wallets.js`, `lib/walletFilter.js` | Wallets intelligents (entité `Wallet` + filtres). Modèle universel. |
| `event-core/studio` | `lib/docCatalog.js`, `lib/docTemplates.js` | Presets visuels (papier, police, accent, watermark) + catalogue documentaire. |
| `event-core/verticals/intermittence` | (config narrative) | Fiche d'identité de la verticale existante. Liste les fichiers protégés. |

---

## 🔒 Fichiers protégés (rappel)

Ces fichiers concentrent la logique légale, juridique et administrative
spécifique aux intermittents. **Aucune modification sans accord explicite**.

### Moteur officiel
- `lib/intermittent507.js` (coefficients Unédic, PRA, AJ)

### Scellement & vérification (HASH FIGÉ)
- `lib/verificationHash.js` (`HASHED_FIELDS` : 8 champs gravés dans les hashes existants)
- `lib/cachetCode.js` (préfixe `AIME-CCH-*`)
- `lib/sealedState.js`
- `functions/sealCachet`
- `functions/verifyCachet`

### Pages cœur
- `pages/Dashboard507.jsx`
- `pages/FicheView.jsx`
- `pages/Verify.jsx`

### Document central (recto/verso/templates)
- `components/aime/fiche/FichePaper`
- `components/aime/fiche/FicheVerso`
- Les 14 `*Paper.jsx` (CachetPaper, DevisPaper, NoteHonorairesPaper, RecuPaper,
  PresencePaper, CessionPaper, FraisPaper, DpaePaper, AemPaper, AttPePaper,
  GusoPaper, CddUPaper, CessionDroitsPaper, AvenantPaper)

### Cockpit 507h
- Tous `components/aime/dashboard/*`

### PDF & mentions légales
- `lib/ficheGenerator.js` (mentions GUSO, AEM, MdA, art. 293 B CGI…)

---

## ⚖️ Vocabulaire juridique imposé

### Signature
**Ne jamais écrire** : « signature électronique » (sans précision).
**Utiliser** au choix :
- signature manuscrite visuelle
- signature préparatoire
- signature non qualifiée

**Disclaimer obligatoire** :
> Cette signature ne vaut pas signature électronique qualifiée.

### Scellement
- ✅ « empreinte technique », « cohérence technique vérifiée », « scellement technique »
- ❌ « certifié », « officiel », « validé administrativement », « preuve opposable »

### Documents administratifs (DPAE, AEM, GUSO, France Travail, Urssaf, Audiens…)
**Toujours présentés comme** :
- aide préparatoire
- checklist
- pré-remplissage indicatif
- à vérifier humainement
- **sans valeur officielle**
- **non opposable**

> Les organismes officiels restent seuls compétents pour confirmer droits,
> déclarations et validations.

---

## 🧬 Hash profiles (référence future uniquement)

Déclaré dans `index.js` → `HASH_PROFILES_PLANNED`. **Non implémenté.**

| Profil | Statut | Note |
|---|---|---|
| `intermittence_v1` | active | Profil officiel AIME (figé). Réf. `lib/verificationHash.js`. |
| `event_v1` | planned | Profil générique événementiel. Non implémenté. |
| `wedding_v1` | planned | Profil mariage. Non implémenté. |

Tout nouveau profil devra être ajouté **à côté**, sans toucher au profil
`intermittence_v1`, pour ne pas casser rétroactivement les fiches déjà scellées.

---

## 🔄 Plan de rollback

Suppression simple, sans aucun impact :

```bash
rm -rf src/lib/event-core/
```

Aucun fichier existant ne référence `@/lib/event-core/*` à ce stade.
La suppression ne casse rien. AIME Cachet continue de fonctionner à
l'identique.

---

## ✅ Preuve de non-modification

Cette Phase 1 n'a touché aucun fichier existant. Seuls les 7 fichiers
suivants ont été **créés** :

1. `lib/event-core/index.js`
2. `lib/event-core/README.md`
3. `lib/event-core/seal/index.js`
4. `lib/event-core/timeline/index.js`
5. `lib/event-core/wallets/index.js`
6. `lib/event-core/studio/index.js`
7. `lib/event-core/verticals/intermittence.js`

Aucun import existant dans `pages/`, `components/`, `functions/`, `App.jsx`,
`index.css`, `tailwind.config.js` n'a été touché.

---

## ⏭️ Ce que cette Phase 1 ne fait PAS

- ❌ Ne crée pas de nouvelle verticale (Atelier, Wedding, Conference…)
- ❌ Ne crée pas de nouvelle route
- ❌ Ne crée pas d'adaptateur `RecordView` / `AimeRecordAdapter`
- ❌ Ne modifie ni n'étend `HASHED_FIELDS`
- ❌ Ne touche pas à `sealCachet` / `verifyCachet`
- ❌ Ne prépare pas d'UI EventCore
- ❌ Ne migre aucune donnée
- ❌ Ne renomme aucune entité

Toute étape ultérieure (extraction d'un adaptateur de lecture, premier vertical
pilote, page publique générique, etc.) fera l'objet d'une décision explicite
et d'une Phase 2 distincte.

---

# M. Doctrine AIME CanvasCore

> Section doctrinale — **doctrine uniquement**, aucun code applicatif.
> Aucune modification fonctionnelle. AIME Cachet reste intact.

## Préambule

L'audit a révélé que **AIME Cachet n'est pas seulement un outil pour
intermittents du spectacle**. C'est déjà le premier vertical d'un moteur
beaucoup plus large que nous nommons ici **AIME CanvasCore**.

Le projet possède déjà — sans l'avoir formalisé — toutes les pièces d'un
moteur universel de création, édition, rangement, projection et
vérification d'objets composables (fiches, documents, pages, héros,
invitations, affiches, billets, mini-sites, programmes, plannings…).

Cette section pose la doctrine. Elle n'implémente rien. Elle nomme.

---

## 1. Pourquoi AIME Cachet est déjà un canvas intelligent

Le centre de l'application n'est pas "un PDF" ni "une fiche cachet". C'est un
**canvas éditable, observable, scellable et projetable**. Trois propriétés le
rendent intelligent :

- **Composable** — il accepte plusieurs gabarits (`docCatalog.js` expose déjà
  4 catégories et 14 documents distincts, tous rendus dans le même canevas).
- **Auto-conscient** — il connaît son état (`status`, `missing_documents`,
  `verification_hash`, `verification_hash_at`) et sait dire "je suis brouillon",
  "j'ai changé depuis mon scellement", "il me manque 3 pièces".
- **Adressable** — chaque instance possède un identifiant unique stable
  (`cachet_code`, format `AIME-CCH-YYYYMMDD-XXXXXX`) qui sert de clé
  publique vérifiable.

Un canvas intelligent, c'est un objet qui **sait ce qu'il est, où il en est,
et qui peut prouver son intégrité**. AIME Cachet a déjà tout cela.

---

## 2. Pourquoi le Studio est un éditeur universel

Le panneau Studio (à droite) **ne dépend d'aucun champ métier intermittent**.
Il manipule des dimensions purement visuelles et structurelles :

- **Apparence** : papier (`PAPER_FORMATS` : A4, A5, ticket, carte), police
  (`FONT_PRESETS` : Inter, Bebas, Playfair, Mono, Caveat), accent
  (`ACCENT_COLORS` × 8), fond (`FICHE_BACKGROUNDS` : photos, gradients).
- **Identité** : tampon, signature, watermark (`WATERMARK_PRESETS`).
- **Contenu** : champs spécifiques au document courant.
- **Certification** : QR, scellement technique, mention préparatoire.
- **IA** : pré-remplissage, suggestions.

Ce découpage est **agnostique du vertical**. Le Studio sait personnaliser
n'importe quel canevas central : une fiche cachet, une invitation, un héros
de page, une affiche, un billet, un cartel d'exposition. Il n'a besoin que
de savoir **quelle est la liste des champs éditables** du document courant.

Le Studio est donc déjà un **éditeur visuel universel**. Il ne reste qu'à
l'alimenter avec d'autres gabarits.

---

## 3. Pourquoi le cockpit 507h est un modèle de cockpit de projection

`Dashboard507` n'est pas "le cockpit intermittent". C'est **le premier exemple
concret d'un cockpit de projection** : un tableau de bord qui prend des
objets bruts (prestations) et en projette des dimensions de futur (PRA
dynamique, anniversaire, AJ estimée, scénarios "et si").

La structure abstraite est :

1. **Agréger** — sommer/filtrer les objets selon des règles métier.
2. **Mesurer** — compteurs principaux (heures, montants, statuts).
3. **Projeter** — extrapoler le futur (échéances, manques, scénarios).
4. **Alerter** — signaler ce qui menace l'objectif (anniversaire critique,
   docs manquants, hash périmé).
5. **Suggérer** — proposer la prochaine action.

Ce squelette est rejouable pour n'importe quel vertical :

- **Mariage** : budget consommé, prestataires signés, RSVP confirmés, tâches
  J-30 / J-7, planning Jour J.
- **Conférence** : speakers confirmés, sessions prêtes, inscriptions vendues,
  salles attribuées, sponsors signés, deadlines abstracts.
- **Festival** : artistes contractualisés, scènes équilibrées, balances
  planifiées, accréditations émises, jauge anticipée, risques météo/sécurité.
- **Atelier** : places réservées, matériel disponible, attestations à émettre.

Le cockpit AIME 507 reste intact comme **référence vivante** du modèle.
Chaque vertical définira sa propre table d'agrégation, ses propres seuils,
ses propres alertes — mais la structure du cockpit ne change pas.

> **Garde-fou** : `lib/intermittent507.js` (coefficients Unédic, PRA, AJ)
> reste strictement protégé. Aucune généralisation ne doit toucher à ce
> moteur officiel.

---

## 4. Pourquoi les wallets sont un registre intelligent

L'entité `Wallet` (`name` + `icon` + `color` + `order`) est déjà
universelle. Combinée aux `SMART_WALLETS` (filtres calculés à la volée),
elle constitue un **registre intelligent** : un classeur dans lequel les
objets se rangent **soit manuellement** (`wallet_id`), **soit
automatiquement** (par règle).

Deux dimensions cohabitent déjà :

- **Wallets persistés** — dossiers créés par l'utilisateur (`Wallet` entité,
  affichés dans `WalletSidebar`).
- **Smart wallets** — vues calculées, jamais stockées ("Cette année",
  "À transmettre", "Validé", "Non rangées"…).

C'est exactement le pattern d'un **registre métier** : une liste filtrable
selon des règles déclaratives. Chaque vertical pourra définir ses propres
smart wallets sans modifier le moteur :

- **Mariage** : "Prestataires signés", "En attente devis", "Payés".
- **Conférence** : "Speakers confirmés", "Abstracts manquants", "Replays
  disponibles".
- **Festival** : "Têtes d'affiche", "Soirée 1", "Scène B", "Sans contrat".

Les wallets sont déjà l'**index navigable du moteur**.

---

## 5. Pourquoi la fiche centrale peut devenir document, page, héros, affiche, invitation ou mini-site

La "fiche" (`FichePaper`) est en réalité une **surface composable**. Elle est
définie par :

- un **format** (A4, A5, ticket, carte — ou demain : hero 16/9, story 9/16,
  affiche A3, page web fluide) ;
- un **gabarit** (cachet, devis, reçu — ou demain : invitation, billet,
  cartel, fiche prestataire, page publique d'événement) ;
- des **données** (l'objet métier sous-jacent) ;
- une **identité visuelle** (Studio).

Le moteur ne "sait" pas qu'il rend un document plutôt qu'une page. Il rend
**un canevas paramétré**. La distinction entre "document", "page" et "héros"
n'est qu'une question de format + de gabarit + de destination de sortie
(PDF, URL publique, image partageable).

C'est pourquoi le canvas central peut, sans changer de moteur, devenir :

| Format / destination | Objet rendu |
|---|---|
| PDF A4 | Document administratif préparatoire |
| PDF A5 / ticket | Reçu, billet, attestation |
| Page web publique | Mini-site événement, RSVP, programme |
| Hero 16/9 | Visuel d'en-tête de page |
| Story 9/16 | Invitation digitale partageable |
| Carte 85×55 | Badge, carton d'invitation |

Un seul canvas. Plusieurs sorties. Plusieurs gabarits.

---

## 6. Pourquoi le verso QR est une couche d'accès, de partage et de vérification

Le verso de la fiche AIME n'est pas "le dos d'un PDF". C'est une **couche
universelle à trois fonctions** :

- **Accès** — le QR contient une URL publique (`/verify/:cachetCode`) qui
  rend l'objet consultable sans login.
- **Partage** — la même URL peut être envoyée par email, SMS, WhatsApp ou
  imprimée, avec un préfixe explicite `[BROUILLON AIME — non opposable]`
  (`lib/shareCopy.js`).
- **Vérification** — le hash SHA-256 (`verification_hash`) permet à un tiers
  de comparer ce qu'il voit avec ce qui a été scellé. Trois états possibles :
  `none` (jamais scellé), `synced` (cohérent), `stale` (modifié depuis).

Ce trio **accès + partage + vérification** est exactement ce qu'il faut
pour n'importe quel objet événementiel :

- Un billet de concert → URL d'accès + partage WhatsApp + vérification
  d'authenticité à l'entrée.
- Une invitation de mariage → URL RSVP + partage + preuve d'invité légitime.
- Un cartel d'exposition → QR vers fiche œuvre publique + partage social.
- Une attestation d'atelier → URL de consultation + preuve d'émission.

Le verso QR est donc une **primitive de plateforme**, pas un détail visuel.

> **Garde-fou** : la liste `HASHED_FIELDS` actuelle est figée pour
> intermittence_v1. Tout nouveau profil (`event_v1`, `wedding_v1`…) doit
> être ajouté à côté, jamais à la place.

---

## 7. Comment éviter les doublons entre les verticales

La règle d'or : **un seul moteur, plusieurs configurations**.

Concrètement, on ne réécrit jamais :

- ❌ un nouveau canvas par vertical → on **paramètre** le canvas existant ;
- ❌ un nouveau Studio par vertical → on **injecte** les champs spécifiques
  dans le Studio existant ;
- ❌ un nouveau moteur de wallets → on **déclare** un autre tableau de
  `SMART_WALLETS` ;
- ❌ un nouveau cockpit from scratch → on **configure** les agrégations,
  seuils et alertes du cockpit existant ;
- ❌ un nouveau moteur de scellement → on **ajoute un profil de hash** dans
  `HASH_PROFILES_PLANNED` ;
- ❌ un nouveau chat IA → on **change le prompt système** et les **intents
  locaux** ; le runtime reste le même.

Chaque vertical apporte uniquement :

1. Une **liste de gabarits** (templates de documents/pages/billets).
2. Une **liste de smart wallets**.
3. Une **table de cockpit** (agrégations + seuils + alertes).
4. Un **prompt assistant** + des intents locaux.
5. Un **profil de hash** dédié.
6. Un **vocabulaire** (libellés, disclaimers, mentions légales).

Tout le reste est mutualisé.

---

## 8. Comment chaque vertical peut avoir son vocabulaire propre sans recréer le moteur

Le vocabulaire d'un vertical est une **table de libellés**, pas du code.
Dans AIME Cachet aujourd'hui, on parle de "prestation", "employeur",
"cachet", "annexe", "intermittent". Pour un mariage, on parlerait de
"prestataire", "jour J", "invité", "devis". Pour une conférence, de
"speaker", "session", "track", "sponsor".

Le moteur ne doit jamais "savoir" qu'il manipule des cachets ou des
mariages. Il manipule des **objets métiers nommés par le vertical**. La
verticale fournit :

- un **dictionnaire** (clé technique → libellé affiché) ;
- des **mentions légales** spécifiques (jamais hardcodées dans le moteur) ;
- un **vocabulaire juridique** strict (cf. règles AIME : signature
  préparatoire vs électronique, scellement technique vs certification, etc.) ;
- un **disclaimer** systématique pour les documents administratifs.

Les contraintes juridiques d'AIME Cachet doivent rester **structurellement
encodées** dans la verticale `intermittence` :

- documents administratifs (DPAE, AEM, GUSO, France Travail, Urssaf,
  Audiens, MdA) toujours marqués *aide préparatoire · sans valeur
  officielle · non opposable* ;
- vocabulaire signature : *signature manuscrite visuelle*, *signature
  préparatoire*, *signature non qualifiée* — jamais "signature électronique"
  seule, avec disclaimer *"Cette signature ne vaut pas signature
  électronique qualifiée."* ;
- vocabulaire scellement : *empreinte technique*, *cohérence technique
  vérifiée*, *scellement technique* — jamais *certifié*, *officiel*,
  *validé administrativement*, *preuve opposable*.

Autres verticales auront leurs propres contraintes (médicales, fiscales,
assurantielles…). Chacune les déclare dans son fichier de configuration.

---

## 9. Comment garder AIME Cachet intact tout en révélant le moteur universel

La règle est simple et stricte : **AIME CanvasCore se construit à côté, pas
au-dessus, et jamais à la place** d'AIME Cachet.

Concrètement :

- **AIME Cachet** = vertical Intermittents. Routes `/app`, `/507`,
  `/fiche/:id`, `/verify/:cachetCode`, etc. Entité `Prestation`. Hash
  `intermittence_v1`. Tout cela est **gelé**.
- **AIME CanvasCore** = couche `lib/event-core/` documentaire et
  technique. Aujourd'hui passive (Phase 1). Demain, elle pourra accueillir
  les briques génériques extraites (sans modifier celles d'AIME) et les
  configurations par vertical.
- **Nouveaux verticaux** = créés à côté, avec leurs propres routes, leurs
  propres entités si nécessaire (jamais en renommant `Prestation`). Ils
  consomment le moteur, ne le modifient pas.

Une extraction se fait **par projection en lecture**, pas par migration.
Exemple : si un jour un adaptateur `RecordView` est nécessaire pour qu'un
rendu générique puisse afficher une `Prestation`, ce sera un
**adaptateur de lecture** ("projette une Prestation en Record"), jamais une
réécriture de l'entité.

---

## 10. Pourquoi la prochaine étape doit rester simple, additive et sans casse

L'erreur classique serait de "réorganiser" AIME Cachet pour préparer le
moteur. C'est exactement **ce qu'il ne faut pas faire**. AIME Cachet est en
production, ses utilisateurs ont des hashes scellés, des fiches signées,
des documents partagés. Toute réorganisation invasive casserait le produit.

La méthode est inverse : on **révèle** le moteur en l'**ajoutant à côté**.

Principes de la suite :

1. **Additif** — chaque étape ajoute des fichiers, n'en modifie aucun de
   ceux qui sont protégés.
2. **Réversible** — chaque étape doit être supprimable sans impact (rollback
   = `rm -rf` d'un dossier).
3. **Documenté** — chaque étape précise ce qu'elle expose, ce qu'elle
   protège, ce qu'elle ne fait pas.
4. **Validé** — aucune étape n'est lancée sans validation explicite.
5. **Petit** — on préfère 10 étapes simples à une grande refonte.

La Phase 1 actuelle (couche `lib/event-core/` passive) respecte ces 5
règles. Les phases suivantes devront elles aussi les respecter.

---

## Conclusion

- **AIME Cachet** est le **premier vertical**. Il reste intact, premium,
  juridiquement prudent, en production.
- **AIME CanvasCore** est le **moteur** : canvas central, Studio,
  bibliothèque, wallets, timeline, cockpit, assistant IA, verso QR,
  scellement, partage. Il n'est pas un produit en soi : c'est l'ossature
  réutilisable révélée par AIME Cachet.
- **EventCore** ne sera qu'une **configuration événementielle** de ce
  moteur — pas un produit séparé, pas une concurrence à AIME Cachet, pas
  un fork. Juste un jeu de gabarits, de wallets, de cockpit et de prompts
  qui s'inscrit dans le même moteur.

Le trio à retenir :

> **AIME Cachet** est ce qu'on voit aujourd'hui.
> **AIME CanvasCore** est ce qu'on découvre derrière.
> **EventCore** est ce qu'on pourra construire demain — sans rien casser.