import React, { useEffect, useState, useMemo } from "react";
import { Link } from "react-router-dom";
import { Calendar } from "lucide-react";
import { base44 } from "@/api/base44Client";
import CockpitTimelineLayout from "@/components/shared/cockpit/CockpitTimelineLayout";
import EventHero from "@/components/event/cockpit/EventHero";
import EventMilestones from "@/components/event/cockpit/EventMilestones";
import EventSuggestions from "@/components/event/cockpit/EventSuggestions";
import EventTimeline from "@/components/event/cockpit/EventTimeline";
import EventCreateButton from "@/components/event/EventCreateButton";
import EventDraftBanner from "@/components/event/EventDraftBanner";
import { EVENT_DOCTRINE_LABELS } from "@/lib/event-core/verticals/event";

/**
 * /events — Cockpit événementiel (Phase 2A).
 *
 * Couche 3 (Event) — consomme la couche partagée via les adaptateurs Event.
 * Reste hors SideRail/MobileMenu — accès par URL uniquement.
 * Doctrine : brouillon privé, non opposable, aucune action externe.
 */
export default function EventsCockpit() {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const list = await base44.entities.EventRecord.list("-created_date", 200);
      setEvents(list || []);
      setLoading(false);
    })();
  }, []);

  const latestEvent = useMemo(() => (events.length ? events[0] : null), [events]);

  const header = (
    <div className="flex items-start justify-between gap-4">
      <div>
        <div className="flex items-center gap-2 mb-1">
          <Calendar className="w-4 h-4 text-zinc-500" />
          <span className="text-[10px] tracking-[0.2em] uppercase text-zinc-500 font-semibold">
            AIME Event · Phase 2A
          </span>
        </div>
        <h1 className="font-display text-3xl text-zinc-900">Cockpit événementiel</h1>
        <p className="text-sm text-zinc-600 mt-1">
          Brouillons préparatoires — strictement privés, non opposables.
        </p>
      </div>
      <div className="flex items-center gap-2 shrink-0">
        <Link to="/app" className="text-[11px] text-zinc-500 hover:text-zinc-900 underline">
          ← Retour AIME Cachet
        </Link>
        <EventCreateButton label="Nouvel événement" />
      </div>
    </div>
  );

  return (
    <CockpitTimelineLayout
      header={header}
      cockpit={
        <>
          <div className="bg-white rounded-2xl border border-zinc-100 p-6">
            <EventHero events={events} />
          </div>
          <EventMilestones latestEvent={latestEvent} />
          <EventSuggestions />
          <DoctrineFooter />
        </>
      }
      timeline={
        <>
          <EventDraftBanner />
          <EventTimeline events={events} loading={loading} />
        </>
      }
    />
  );
}

function DoctrineFooter() {
  return (
    <div className="text-[10px] text-zinc-400 italic leading-snug px-2">
      {EVENT_DOCTRINE_LABELS.preparatory} · {EVENT_DOCTRINE_LABELS.human_review} ·{" "}
      {EVENT_DOCTRINE_LABELS.no_official}
    </div>
  );
}