import React, { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { getEventType } from "@/lib/event-core/verticals/event";
import EventDraftBanner from "@/components/event/EventDraftBanner";
import EventCard from "@/components/event/EventCard";
import EventCreateButton from "@/components/event/EventCreateButton";
import EventTypeRecommendedDocs from "@/components/event/EventTypeRecommendedDocs";

/**
 * /events/:type — Liste filtrée par type d'événement (Phase 2A).
 */
export default function EventsType() {
  const { type: typeKey } = useParams();
  const type = getEventType(typeKey);
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const list = await base44.entities.EventRecord.filter(
        { eventType: typeKey },
        "-created_date",
        200,
      );
      setEvents(list || []);
      setLoading(false);
    })();
  }, [typeKey]);

  if (!type) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-zinc-50 gap-4">
        <p className="text-zinc-600">Type d'événement inconnu.</p>
        <Link to="/events" className="text-sm text-aime-red hover:underline">← Retour aux événements</Link>
      </div>
    );
  }

  const Icon = type.icon;

  return (
    <div className="min-h-screen bg-zinc-50">
      <header className="border-b border-zinc-200 bg-white">
        <div className="max-w-6xl mx-auto px-6 py-6">
          <Link to="/events" className="inline-flex items-center gap-1 text-[11px] text-zinc-500 hover:text-zinc-900 mb-3">
            <ArrowLeft className="w-3 h-3" />
            Tous les événements
          </Link>
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl flex items-center justify-center bg-zinc-100 text-zinc-900">
                <Icon className="w-6 h-6" />
              </div>
              <div>
                <div className="text-[10px] tracking-[0.2em] uppercase text-zinc-500 font-semibold">AIME Event</div>
                <h1 className="font-display text-2xl text-zinc-900">{type.label}</h1>
                <p className="text-sm text-zinc-600 mt-0.5">{type.description}</p>
              </div>
            </div>
            <EventCreateButton defaultType={type.key} label={`Créer un ${type.label.toLowerCase()}`} />
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-6 space-y-6">
        <EventDraftBanner />

        {/* Hub préparatoire — lecture seule, lit la config event-core. */}
        <EventTypeRecommendedDocs type={type} />

        <section>
          <h2 className="text-[11px] tracking-[0.2em] uppercase text-zinc-500 font-semibold mb-3">
            Événements de type "{type.label}" ({events.length})
          </h2>
          {loading ? (
            <div className="text-center py-12 text-zinc-400 text-sm">Chargement…</div>
          ) : events.length === 0 ? (
            <div className="text-center py-12 px-4 rounded-xl border border-dashed border-zinc-300 bg-white">
              <p className="text-sm text-zinc-600 mb-3">
                Aucun {type.label.toLowerCase()} pour le moment.
              </p>
              <EventCreateButton defaultType={type.key} label="Créer un premier brouillon" />
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {events.map((ev) => <EventCard key={ev.id} event={ev} />)}
            </div>
          )}
        </section>
      </main>
    </div>
  );
}