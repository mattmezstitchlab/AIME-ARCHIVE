import React, { useEffect, useState, useMemo } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Plus, Layers, CalendarHeart, FileText, MapPin, Calendar } from "lucide-react";
import { base44 } from "@/api/base44Client";
import GlobalToolbar from "@/components/aime/GlobalToolbar";
import SideRail from "@/components/aime/SideRail";
import CollapsibleTimelineGroup from "@/components/shared/cockpit/CollapsibleTimelineGroup";
import { getEventType } from "@/lib/event-core/verticals/event";

function StatusBadge({ label, color }) {
  const COLORS = {
    green: "bg-green-50 text-green-700 border-green-200",
    blue: "bg-blue-50 text-blue-700 border-blue-200",
    yellow: "bg-yellow-50 text-yellow-700 border-yellow-200",
    zinc: "bg-zinc-100 text-zinc-600 border-zinc-200",
    red: "bg-red-50 text-red-700 border-red-200",
  };
  return (
    <span className={`text-[9px] uppercase tracking-wider font-semibold px-1.5 py-0.5 rounded border ${COLORS[color] || COLORS.zinc}`}>
      {label}
    </span>
  );
}

const STATUS_PRESTATION = {
  brouillon:       { label: "Brouillon",       color: "zinc" },
  a_completer:     { label: "A completer",     color: "yellow" },
  pret_a_verifier: { label: "Pret verifier",   color: "blue" },
  transmis:        { label: "Transmis",         color: "blue" },
  valide:          { label: "Valide",           color: "green" },
};

const STATUS_EVENT = {
  brouillon:       { label: "Brouillon",        color: "zinc" },
  en_preparation:  { label: "En preparation",   color: "yellow" },
  pret_a_partager: { label: "Pret partager",    color: "blue" },
  archive:         { label: "Archive",          color: "zinc" },
};

function PrestationRow({ item }) {
  const s = STATUS_PRESTATION[item.status] || STATUS_PRESTATION.brouillon;
  return (
    <Link
      to={`/fiche/${item.id}`}
      className="flex items-center gap-3 p-3 rounded-xl border border-zinc-100 bg-white hover:border-zinc-300 hover:shadow-sm transition-all group"
    >
      <div className="w-9 h-9 rounded-lg bg-zinc-100 flex items-center justify-center shrink-0 group-hover:bg-zinc-200 transition-colors">
        <FileText className="w-4 h-4 text-zinc-700" />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-[10px] tracking-[0.15em] uppercase font-semibold text-aime-red">
            Cachet
          </span>
          <StatusBadge label={s.label} color={s.color} />
        </div>
        <p className="text-[13px] font-medium text-zinc-900 truncate mt-0.5">
          {item.production || item.employer || "Prestation sans titre"}
        </p>
        <div className="flex items-center gap-3 mt-0.5 text-[11px] text-zinc-500">
          {item.employer && <span className="truncate max-w-[140px]">{item.employer}</span>}
          {item.location && (
            <span className="flex items-center gap-0.5 truncate max-w-[120px]">
              <MapPin className="w-2.5 h-2.5 shrink-0" />
              {item.location}
            </span>
          )}
          {item.amount != null && (
            <span className="ml-auto font-semibold text-zinc-700 shrink-0">{item.amount} EUR</span>
          )}
        </div>
      </div>
    </Link>
  );
}

function EventRow({ item }) {
  const s = STATUS_EVENT[item.status] || STATUS_EVENT.brouillon;
  const type = getEventType(item.eventType);
  const Icon = type?.icon;
  return (
    <Link
      to={`/events/fiche/${item.id}`}
      className="flex items-center gap-3 p-3 rounded-xl border border-zinc-100 bg-white hover:border-zinc-300 hover:shadow-sm transition-all group"
    >
      <div className="w-9 h-9 rounded-lg bg-zinc-100 flex items-center justify-center shrink-0 group-hover:bg-zinc-200 transition-colors">
        {Icon ? <Icon className="w-4 h-4 text-zinc-700" /> : <CalendarHeart className="w-4 h-4 text-zinc-700" />}
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-[10px] tracking-[0.15em] uppercase font-semibold text-violet-600">
            {type?.label || "Evenement"}
          </span>
          <StatusBadge label={s.label} color={s.color} />
        </div>
        <p className="text-[13px] font-medium text-zinc-900 truncate mt-0.5">
          {item.title || "Evenement sans titre"}
        </p>
        <div className="flex items-center gap-3 mt-0.5 text-[11px] text-zinc-500">
          {item.location && (
            <span className="flex items-center gap-0.5 truncate max-w-[140px]">
              <MapPin className="w-2.5 h-2.5 shrink-0" />
              {item.location}
            </span>
          )}
          {item.date && (
            <span className="flex items-center gap-0.5 shrink-0">
              <Calendar className="w-2.5 h-2.5 shrink-0" />
              {new Date(item.date).toLocaleDateString("fr-FR", { day: "numeric", month: "short" })}
            </span>
          )}
        </div>
      </div>
    </Link>
  );
}

export default function MesActivites() {
  const navigate = useNavigate();
  const [prestations, setPrestations] = useState([]);
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      base44.entities.Prestation.list("-date", 500),
      base44.entities.EventRecord.list("-created_date", 500),
    ]).then(([p, e]) => {
      setPrestations(p || []);
      setEvents(e || []);
      setLoading(false);
    });
  }, []);

  const unified = useMemo(() => {
    const items = [
      ...prestations.map((p) => ({
        _kind: "prestation",
        _sortDate: p.date || p.created_date || new Date().toISOString(),
        ...p,
      })),
      ...events.map((e) => ({
        _kind: "event",
        _sortDate: e.date || e.created_date || new Date().toISOString(),
        ...e,
      })),
    ];
    return items.sort((a, b) => new Date(b._sortDate) - new Date(a._sortDate));
  }, [prestations, events]);

  const groups = useMemo(() => {
    const map = new Map();
    unified.forEach((item) => {
      const d = new Date(item._sortDate);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
      const label = d.toLocaleDateString("fr-FR", { month: "long", year: "numeric" });
      if (!map.has(key)) map.set(key, { key, label, ts: d.getTime(), items: [] });
      map.get(key).items.push(item);
    });
    return Array.from(map.values()).sort((a, b) => b.ts - a.ts);
  }, [unified]);

  const total = prestations.length + events.length;

  return (
    <div className="min-h-screen bg-zinc-50">
      <SideRail />
      <GlobalToolbar back="/app" showBack title="Mes activites" />

      <div className="lg:pl-16 pt-16 lg:pt-8">
        <div className="max-w-3xl mx-auto px-4 py-6 space-y-4">

          <div className="flex items-center justify-between gap-4 mb-2">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Layers className="w-4 h-4 text-zinc-500" />
                <span className="text-[10px] tracking-[0.2em] uppercase text-zinc-500 font-semibold">
                  Vue unifiee
                </span>
              </div>
              <h1 className="font-display text-2xl text-zinc-900">Mes activites</h1>
              <p className="text-sm text-zinc-500 mt-0.5">
                {total} activite{total > 1 ? "s" : ""} au total
              </p>
            </div>
            <button
              onClick={() => navigate("/app?new=1")}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-full bg-zinc-900 hover:bg-aime-red text-white text-sm font-medium transition-colors shrink-0"
            >
              <Plus className="w-4 h-4" />
              Nouveau
            </button>
          </div>

          <div className="flex items-center gap-4 text-[11px] text-zinc-500">
            <span className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-aime-red inline-block" />
              Cachet intermittence
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-violet-500 inline-block" />
              Evenement preparatoire
            </span>
          </div>

          {loading ? (
            <div className="text-center py-16 text-zinc-400 text-sm">Chargement...</div>
          ) : unified.length === 0 ? (
            <div className="text-center py-16 px-4 rounded-xl border border-dashed border-zinc-300 bg-white">
              <p className="text-sm text-zinc-600 mb-4">Aucune activite pour le moment.</p>
              <div className="flex flex-wrap gap-3 justify-center">
                <Link
                  to="/app?new=1"
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-zinc-900 text-white text-sm font-medium"
                >
                  <FileText className="w-3.5 h-3.5" />
                  Nouvelle fiche cachet
                </Link>
                <Link
                  to="/events"
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full border border-zinc-200 bg-white text-zinc-700 text-sm font-medium"
                >
                  <CalendarHeart className="w-3.5 h-3.5" />
                  Nouvel evenement
                </Link>
              </div>
            </div>
          ) : (
            <div className="space-y-2">
              {groups.map((g, idx) => (
                <CollapsibleTimelineGroup
                  key={g.key}
                  label={g.label}
                  sublabel={`${g.items.length} activite${g.items.length > 1 ? "s" : ""}`}
                  defaultOpen={idx === 0}
                >
                  {g.items.map((item) =>
                    item._kind === "prestation" ? (
                      <PrestationRow key={`p-${item.id}`} item={item} />
                    ) : (
                      <EventRow key={`e-${item.id}`} item={item} />
                    )
                  )}
                </CollapsibleTimelineGroup>
              ))}
            </div>
          )}

          <p className="text-[9px] text-zinc-400 italic text-center pt-2">
            AIME - Outil preparatoire prive. Les organismes officiels restent seuls competents.
          </p>
        </div>
      </div>
    </div>
  );
}