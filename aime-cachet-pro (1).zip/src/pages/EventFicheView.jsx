import React, { useEffect, useState } from "react";
import { Link, useParams, useNavigate } from "react-router-dom";
import { ArrowLeft, Pencil, RotateCw, Trash2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import EventDraftBanner from "@/components/event/EventDraftBanner";
import EventFichePaper from "@/components/event/EventFichePaper";
import EventFicheVerso from "@/components/event/EventFicheVerso";
import EventStudio from "@/components/event/EventStudio";
// Canvas Surface Mode — rail invisible. v1 : seul 'document' est actif.
// Tout autre mode retombe silencieusement sur EventFichePaper.
import { resolveSurfaceRenderer } from "@/lib/event-core/surfaces";

/**
 * /events/fiche/:id — Fiche événementielle générique (Phase 2A).
 * Canvas central + Studio à droite + verso événementiel (QR indicatif).
 * Aucun scellement, aucun hash officiel, aucun /verify.
 */
export default function EventFicheView() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [event, setEvent] = useState(null);
  const [loading, setLoading] = useState(true);
  const [flipped, setFlipped] = useState(false);
  const [studioOpen, setStudioOpen] = useState(false);
  const [paperScale, setPaperScale] = useState(0.85);

  useEffect(() => {
    (async () => {
      const e = await base44.entities.EventRecord.get(id);
      setEvent(e);
      setLoading(false);
    })();
  }, [id]);

  useEffect(() => {
    const compute = () => {
      const vw = window.innerWidth;
      if (vw < 640) setPaperScale(Math.max(0.4, (vw - 32) / 794));
      else if (vw < 1024) setPaperScale(0.7);
      else setPaperScale(0.85);
    };
    compute();
    window.addEventListener("resize", compute);
    return () => window.removeEventListener("resize", compute);
  }, []);

  const handleDelete = async () => {
    if (!confirm("Supprimer définitivement ce brouillon d'événement ?")) return;
    await base44.entities.EventRecord.delete(id);
    toast.success("Brouillon supprimé");
    navigate("/events");
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-zinc-900">
        <div className="w-8 h-8 border-4 border-white/20 border-t-white rounded-full animate-spin" />
      </div>
    );
  }

  if (!event) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-zinc-900 text-white gap-4">
        <p>Événement introuvable.</p>
        <Link to="/events" className="px-5 py-2 bg-aime-red rounded-full text-sm">Retour</Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-zinc-900 via-zinc-800 to-zinc-900 relative overflow-x-hidden">
      {/* Top bar */}
      <div className="sticky top-0 z-20 bg-zinc-900/80 backdrop-blur-xl border-b border-white/10">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between gap-3">
          <Link to="/events" className="inline-flex items-center gap-1 text-[12px] text-zinc-300 hover:text-white">
            <ArrowLeft className="w-3.5 h-3.5" />
            Mes événements
          </Link>
          <div className="flex items-center gap-2">
            {/* Zone secondaire : Supprimer — isolée à gauche, distancie du CTA principal. */}
            <button
              onClick={handleDelete}
              className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-white/5 hover:bg-red-500/30 text-zinc-400 hover:text-red-400 transition-colors"
              title="Supprimer le brouillon"
              aria-label="Supprimer le brouillon"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
            <span className="w-px h-5 bg-white/15 mx-1" aria-hidden />

            <EventDraftBanner compact />
            <button
              onClick={() => setFlipped((f) => !f)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white text-[12px]"
            >
              <RotateCw className="w-3.5 h-3.5" />
              {flipped ? "Recto" : "Verso"}
            </button>
            <button
              onClick={() => setStudioOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-aime-red hover:bg-red-700 text-white text-[12px]"
            >
              <Pencil className="w-3.5 h-3.5" />
              Éditer
            </button>
          </div>
        </div>
      </div>

      <div className="relative z-10 pt-10 pb-20 px-2 flex justify-center overflow-hidden" style={{ perspective: "2400px" }}>
        <div style={{ transformOrigin: "top center", transform: `scale(${paperScale})` }}>
          <div
            className="relative transition-transform duration-[800ms]"
            style={{
              transformStyle: "preserve-3d",
              transform: flipped ? "rotateY(180deg)" : "rotateY(0deg)",
              width: "210mm",
              minHeight: "297mm",
            }}
          >
            <div className="absolute inset-0" style={{ backfaceVisibility: "hidden", WebkitBackfaceVisibility: "hidden" }}>
              {(() => {
                // Résolution du renderer central via le registre Canvas Surface.
                // En v1, retourne TOUJOURS EventFichePaper (seule surface active).
                const SurfaceRenderer = resolveSurfaceRenderer(event.surfaceMode);
                return <SurfaceRenderer event={event} />;
              })()}
            </div>
            <div
              className="absolute inset-0"
              style={{ backfaceVisibility: "hidden", WebkitBackfaceVisibility: "hidden", transform: "rotateY(180deg)" }}
            >
              <EventFicheVerso event={event} />
            </div>
          </div>
        </div>
      </div>

      <EventStudio
        open={studioOpen}
        onClose={() => setStudioOpen(false)}
        event={event}
        onChange={setEvent}
      />
    </div>
  );
}