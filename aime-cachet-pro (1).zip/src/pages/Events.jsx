import React, { useEffect, useState, useMemo } from "react";
import { Link } from "react-router-dom";
import { Calendar, ArrowLeft } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { EVENT_TYPES_LIST } from "@/lib/event-core/verticals/event";
import EventDraftBanner from "@/components/event/EventDraftBanner";
import EventTypeCard from "@/components/event/EventTypeCard";
import EventCreateButton from "@/components/event/EventCreateButton";

/**
 * /events — Registre événementiel privé (Phase 2A).
 * Accessible uniquement par URL directe (pas dans la navigation SideRail).
 */
/**
 * /events/types — Galerie de types d'événements.
 *
 * Vue allégée (post-simplification cockpit) : ne montre plus la liste
 * complète des événements (déjà dans le cockpit /events sous forme de
 * timeline accordéon). Sert uniquement de point d'entrée par type.
 */
export default function Events() {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const list = await base44.entities.EventRecord.list("-created_date", 200);
      setEvents(list || []);
      setLoading(false);
    })();
  }, []);

  const countsByType = useMemo(() => {
    const m = {};
    events.forEach((e) => { m[e.eventType] = (m[e.eventType] || 0) + 1; });
    return m;
  }, [events]);

  return (
    <div className="min-h-screen bg-zinc-50">
      <header className="border-b border-zinc-200 bg-white">
        <div className="max-w-6xl mx-auto px-6 py-6 flex items-start justify-between gap-4">
          <div>
            <Link to="/events" className="inline-flex items-center gap-1 text-[11px] text-zinc-500 hover:text-zinc-900 mb-2">
              <ArrowLeft className="w-3 h-3" />
              Cockpit événementiel
            </Link>
            <div className="flex items-center gap-2 mb-1">
              <Calendar className="w-4 h-4 text-zinc-500" />
              <span className="text-[10px] tracking-[0.2em] uppercase text-zinc-500 font-semibold">AIME Event</span>
            </div>
            <h1 className="font-display text-3xl text-zinc-900">Types d'événements</h1>
            <p className="text-sm text-zinc-600 mt-1">
              Choisissez un type pour parcourir vos brouillons ou en créer un nouveau.
            </p>
          </div>
          <EventCreateButton />
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-6 space-y-6">
        <EventDraftBanner />

        <section>
          {loading ? (
            <div className="text-center py-12 text-zinc-400 text-sm">Chargement…</div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
              {EVENT_TYPES_LIST.map((t) => (
                <EventTypeCard key={t.key} type={t} count={countsByType[t.key] || 0} />
              ))}
            </div>
          )}
        </section>
      </main>
    </div>
  );
}