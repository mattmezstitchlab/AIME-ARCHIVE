import React, { useState } from "react";
import { Download, FileSpreadsheet, X, AlertCircle, CheckCircle2 } from "lucide-react";

/**
 * Bouton + modal d'export GUSO.
 *
 * Génère un fichier CSV avec les colonnes attendues par GUSO pour
 * les déclarations d'employeurs occasionnels (spectacle vivant).
 *
 * Doctrine : export préparatoire. L'utilisateur doit valider les données
 * avant toute transmission officielle au portail GUSO.
 */

// Colonnes GUSO (format import portail GUSO v2)
const GUSO_HEADERS = [
  "SIRET_Employeur",
  "Raison_Sociale",
  "Date_Debut",
  "Date_Fin",
  "Nature_Emploi",
  "Qualification",
  "Nb_Cachets",
  "Nb_Heures",
  "Salaire_Brut_EUR",
  "Secteur",
  "Annexe",
  "Lieu",
  "Production",
  "Notes",
];

function prestationToGusoRow(p) {
  return [
    p.employer_siret || "",
    p.employer || "",
    p.date || "",
    p.date || "",                            // date fin = date début (prestation journalière)
    p.type === "Technicien" ? "Technicien" : "Artiste",
    p.nature || "",
    "1",                                     // 1 cachet par fiche
    p.duration_hours != null ? String(p.duration_hours) : "",
    p.amount != null ? String(p.amount) : "",
    p.sector === "audiovisuel" ? "Audiovisuel" : "Spectacle vivant",
    p.annexe ? `Annexe ${p.annexe}` : "",
    p.location || "",
    p.production || "",
    p.custom_notes || "",
  ];
}

function escapeCSV(val) {
  if (val == null) return "";
  const s = String(val);
  if (s.includes(";") || s.includes('"') || s.includes("\n")) {
    return `"${s.replace(/"/g, '""')}"`;
  }
  return s;
}

function buildCSV(prestations) {
  const rows = [GUSO_HEADERS, ...prestations.map(prestationToGusoRow)];
  return rows.map((row) => row.map(escapeCSV).join(";")).join("\n");
}

function downloadCSV(content, filename) {
  const BOM = "\uFEFF"; // UTF-8 BOM pour Excel
  const blob = new Blob([BOM + content], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export default function ExportGusoButton({ prestations = [] }) {
  const [open, setOpen] = useState(false);
  const [scope, setScope] = useState("guso"); // "guso" = occasionnels uniquement | "all" = toutes

  const eligible = prestations.filter((p) => p.employer_kind === "occasionnel");
  const toExport = scope === "guso" ? eligible : prestations;

  const handleExport = () => {
    if (toExport.length === 0) return;
    const csv = buildCSV(toExport);
    const date = new Date().toISOString().slice(0, 10);
    downloadCSV(csv, `AIME_GUSO_export_${date}.csv`);
    setOpen(false);
  };

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-full border border-zinc-200 bg-white hover:border-zinc-900 text-zinc-700 hover:text-zinc-900 text-sm font-medium transition-colors"
      >
        <Download className="w-3.5 h-3.5" />
        Export GUSO
      </button>

      {open && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4"
          onClick={() => setOpen(false)}
        >
          <div
            className="bg-white rounded-2xl w-full max-w-md shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="flex items-center justify-between px-5 py-4 border-b border-zinc-100">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-lg bg-green-50 flex items-center justify-center">
                  <FileSpreadsheet className="w-4 h-4 text-green-700" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-zinc-900">Export GUSO</h3>
                  <p className="text-[10px] text-zinc-500">Format CSV import portail GUSO</p>
                </div>
              </div>
              <button onClick={() => setOpen(false)} className="text-zinc-400 hover:text-zinc-900">
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Body */}
            <div className="px-5 py-4 space-y-4">
              {/* Bandeau doctrinal */}
              <div className="flex items-start gap-2 p-3 rounded-lg bg-amber-50 border border-amber-200">
                <AlertCircle className="w-3.5 h-3.5 text-amber-700 shrink-0 mt-0.5" />
                <p className="text-[10px] text-amber-900 leading-relaxed">
                  Export préparatoire. Vérifiez chaque ligne avant import sur le portail GUSO.
                  Les SIRET et montants doivent être exacts. Sans valeur administrative directe.
                </p>
              </div>

              {/* Sélection du scope */}
              <div className="space-y-2">
                <p className="text-[11px] font-semibold text-zinc-700 uppercase tracking-wider">
                  Périmètre d&apos;export
                </p>
                <label className="flex items-start gap-3 p-3 rounded-xl border cursor-pointer transition-colors hover:border-zinc-400"
                  style={{ borderColor: scope === "guso" ? "#16a34a" : undefined, background: scope === "guso" ? "#f0fdf4" : undefined }}>
                  <input type="radio" name="scope" value="guso" checked={scope === "guso"} onChange={() => setScope("guso")} className="mt-0.5" />
                  <div>
                    <div className="text-[12px] font-semibold text-zinc-900">
                      Employeurs occasionnels uniquement
                      <span className="ml-2 text-[10px] font-normal text-green-700 bg-green-50 px-1.5 py-0.5 rounded-full border border-green-200">
                        Recommandé GUSO
                      </span>
                    </div>
                    <div className="text-[11px] text-zinc-500 mt-0.5">
                      {eligible.length} fiche{eligible.length > 1 ? "s" : ""} éligibles
                    </div>
                  </div>
                </label>
                <label className="flex items-start gap-3 p-3 rounded-xl border cursor-pointer transition-colors hover:border-zinc-400"
                  style={{ borderColor: scope === "all" ? "#3f3f46" : undefined, background: scope === "all" ? "#fafafa" : undefined }}>
                  <input type="radio" name="scope" value="all" checked={scope === "all"} onChange={() => setScope("all")} className="mt-0.5" />
                  <div>
                    <div className="text-[12px] font-semibold text-zinc-900">Toutes les fiches</div>
                    <div className="text-[11px] text-zinc-500 mt-0.5">{prestations.length} fiche{prestations.length > 1 ? "s" : ""} au total</div>
                  </div>
                </label>
              </div>

              {/* Aperçu colonnes */}
              <div>
                <p className="text-[11px] font-semibold text-zinc-700 uppercase tracking-wider mb-2">
                  Colonnes exportées
                </p>
                <div className="flex flex-wrap gap-1">
                  {GUSO_HEADERS.map((h) => (
                    <span key={h} className="text-[9px] px-1.5 py-0.5 rounded bg-zinc-100 text-zinc-600 font-mono">
                      {h}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="px-5 py-4 border-t border-zinc-100 flex items-center justify-between gap-3">
              <button
                onClick={() => setOpen(false)}
                className="text-sm text-zinc-500 hover:text-zinc-900 transition-colors"
              >
                Annuler
              </button>
              <button
                onClick={handleExport}
                disabled={toExport.length === 0}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-zinc-900 hover:bg-green-700 text-white text-sm font-medium transition-colors disabled:opacity-40 disabled:pointer-events-none"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                Exporter {toExport.length} fiche{toExport.length > 1 ? "s" : ""}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}