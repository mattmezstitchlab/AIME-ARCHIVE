import React, { useEffect } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import {
  X,
  Files,
  Gauge,
  HelpCircle,
  Settings,
  Home,
  Sparkles,
  Search,
  Bell,
  UserRound,
  CalendarHeart,
} from "lucide-react";

/**
 * Menu burger mobile AIME Cachet.
 *
 * Donne accès aux actions principales du SideRail desktop sur écrans < lg.
 * - Nouvelle fiche → /app?new=1 (déclenche création immédiate côté Accueil)
 * - Mes fiches → /prestations
 * - Cockpit 507 → /507
 * - Accueil → /app
 * - Aide → /aide
 * - Paramètres → /parametres
 *
 * Strictement client-side. Aucune action externe.
 */
export default function MobileMenu({ open, onClose }) {
  const navigate = useNavigate();
  const { pathname } = useLocation();

  // Bloque le scroll body quand ouvert
  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, [open]);

  if (!open) return null;

  const handleCreate = () => {
    onClose();
    navigate("/app?new=1");
  };

  const handleSearch = () => {
    onClose();
    // Délai pour laisser le menu se fermer avant d'ouvrir la recherche.
    // Si un parent a fourni onOpenSearch, on le préfère. Sinon, on déclenche
    // un événement custom que GlobalToolbar / AimeHeader peuvent écouter.
    setTimeout(() => {
      window.dispatchEvent(new CustomEvent("aime:open-search"));
    }, 50);
  };

  const goTo = (path) => {
    onClose();
    navigate(path);
  };

  const Item = ({ icon: Icon, label, hint, onClick, accent = false }) => (
    <button
      type="button"
      onClick={onClick}
      className={`w-full flex items-center gap-3 px-4 py-3.5 rounded-xl border transition-colors text-left ${
        accent
          ? "bg-aime-red/10 border-aime-red/30 text-white hover:bg-aime-red/15"
          : "bg-white/[0.04] border-white/10 text-zinc-100 hover:bg-white/[0.07]"
      }`}
    >
      <span
        className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${
          accent ? "bg-aime-red/20 text-aime-red" : "bg-white/5 text-zinc-300"
        }`}
      >
        <Icon className="w-4 h-4" />
      </span>
      <span className="flex-1 min-w-0">
        <span className="block text-[13px] font-semibold leading-tight">{label}</span>
        {hint && (
          <span className="block text-[10px] text-zinc-500 mt-0.5 truncate">{hint}</span>
        )}
      </span>
    </button>
  );

  return (
    <>
      <div
        className="fixed inset-0 z-[60] bg-black/60 backdrop-blur-sm lg:hidden"
        onClick={onClose}
      />
      <aside
        className="fixed top-0 left-0 bottom-0 z-[61] w-[88%] max-w-[340px] bg-aime-black text-white shadow-2xl border-r border-white/5 flex flex-col pb-[env(safe-area-inset-bottom)] lg:hidden"
        role="dialog"
        aria-label="Menu principal"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3.5 border-b border-white/5">
          <Link
            to="/app"
            onClick={onClose}
            className="flex items-center gap-2"
            aria-label="Accueil AIME 507"
          >
            <span className="font-display font-black text-[14px] tracking-wider leading-none text-white">
              AIME<span className="text-aime-red">®</span>
            </span>
            <span className="flex items-center gap-0.5 font-display font-black leading-none text-white text-[16px]">
              <span>5</span>
              <span className="text-aime-red">♥</span>
              <span>7</span>
            </span>
          </Link>
          <button
            type="button"
            onClick={onClose}
            aria-label="Fermer le menu"
            className="w-9 h-9 rounded-full flex items-center justify-center text-zinc-400 hover:text-white hover:bg-white/5"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Sections */}
        <div className="flex-1 overflow-y-auto px-3 py-4 space-y-2">
          <div className="px-1 pb-1 text-[9px] tracking-[0.22em] text-zinc-500 font-semibold uppercase">
            Action
          </div>
          <Item
            icon={Sparkles}
            label="Nouvelle fiche"
            hint="Créer une fiche cachet"
            onClick={handleCreate}
            accent
          />

          <div className="px-1 pb-1 pt-3 text-[9px] tracking-[0.22em] text-zinc-500 font-semibold uppercase">
            Navigation
          </div>
          <Item
            icon={Home}
            label="Accueil"
            hint="Tableau de bord"
            onClick={() => goTo("/app")}
          />
          <Item
            icon={Files}
            label="Mes fiches"
            hint="Liste des prestations"
            onClick={() => goTo("/prestations")}
          />
          <Item
            icon={Gauge}
            label="Cockpit 507"
            hint="Suivi des heures et statut"
            onClick={() => goTo("/507")}
          />

          <div className="px-1 pb-1 pt-3 text-[9px] tracking-[0.22em] text-zinc-500 font-semibold uppercase">
            Outils
          </div>
          <Item
            icon={Search}
            label="Recherche"
            hint="Recherche rapide (overlay)"
            onClick={handleSearch}
          />
          <Item
            icon={Bell}
            label="Notifications"
            hint="Centre de notifications"
            onClick={() => goTo("/notifications")}
          />
          <Item
            icon={UserRound}
            label="Mon profil"
            hint="Compte et préférences"
            onClick={() => goTo("/profil")}
          />

          <div className="px-1 pb-1 pt-3 text-[9px] tracking-[0.22em] text-zinc-500 font-semibold uppercase">
            AIME Event
          </div>
          <Item
            icon={CalendarHeart}
            label="Cockpit événements"
            hint="Vue d'ensemble Events"
            onClick={() => goTo("/events")}
          />
          <Item
            icon={Sparkles}
            label="Types d'événements"
            hint="Mariage, concert, festival…"
            onClick={() => goTo("/events/types")}
          />

          <div className="px-1 pb-1 pt-3 text-[9px] tracking-[0.22em] text-zinc-500 font-semibold uppercase">
            Compte
          </div>
          <Item
            icon={HelpCircle}
            label="Aide"
            hint="Centre d'aide"
            onClick={() => goTo("/aide")}
          />
          <Item
            icon={Settings}
            label="Paramètres"
            hint="Préférences"
            onClick={() => goTo("/parametres")}
          />
        </div>

        {/* Footer doctrinal */}
        <div className="px-4 py-3 border-t border-white/5 bg-white/[0.02]">
          <p className="text-[9px] text-zinc-500 leading-relaxed italic">
            AIME® 507 — Cockpit privé. Sans valeur officielle.
          </p>
          {pathname && (
            <p className="text-[9px] text-zinc-600 mt-1 truncate">Page courante : {pathname}</p>
          )}
        </div>
      </aside>
    </>
  );
}