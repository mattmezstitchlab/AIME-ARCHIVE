import React from "react";
import { Link, useLocation } from "react-router-dom";
import { Home, Files, Gauge, CalendarHeart, Layers } from "lucide-react";

/**
 * Barre de navigation mobile fixe — style iOS tab bar.
 * Visible uniquement sur mobile (< lg).
 * Affiche 5 onglets : Accueil · Fiches · 507 · Events · Activités.
 *
 * Injectée globalement dans App.jsx (AuthenticatedApp).
 * Masquée sur : landing (/), verify, fiche/:id (ToolPalette présente),
 * events/fiche/:id (EventStudio présent).
 */

const TABS = [
  { label: "Accueil",   icon: Home,          href: "/app" },
  { label: "Fiches",    icon: Files,         href: "/prestations" },
  { label: "507",       icon: Gauge,         href: "/507" },
  { label: "Events",    icon: CalendarHeart, href: "/events" },
  { label: "Activités", icon: Layers,        href: "/activites" },
];

const HIDDEN_PATTERNS = [
  /^\/$/, // landing
  /^\/verify\//,
  /^\/fiche\//,         // FicheView a sa propre ToolPalette
  /^\/events\/fiche\//, // EventFicheView a son propre studio
];

export default function MobileBottomNav() {
  const { pathname } = useLocation();

  // Masquer sur certaines pages
  if (HIDDEN_PATTERNS.some((re) => re.test(pathname))) return null;

  return (
    <nav
      className="fixed bottom-0 left-0 right-0 z-[55] lg:hidden"
      style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
    >
      {/* Fond flouté */}
      <div className="bg-white/95 backdrop-blur-xl border-t border-zinc-200 px-1 py-1 flex items-stretch">
        {TABS.map((tab) => {
          const Icon = tab.icon;
          const active =
            tab.href === "/app"
              ? pathname === "/app"
              : pathname.startsWith(tab.href);

          return (
            <Link
              key={tab.href}
              to={tab.href}
              className={`flex-1 flex flex-col items-center justify-center gap-0.5 py-2 rounded-xl transition-colors ${
                active ? "text-aime-red" : "text-zinc-400"
              }`}
            >
              <Icon className={`w-5 h-5 transition-transform ${active ? "scale-110" : ""}`} />
              <span className={`text-[9px] font-semibold tracking-wide ${active ? "text-aime-red" : "text-zinc-400"}`}>
                {tab.label}
              </span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}