import React from "react";
import { Link } from "react-router-dom";
import { ArrowRight, MapPin, FileText, AlertTriangle } from "lucide-react";
import { STATUS_META, formatDateFR } from "@/lib/aimeData";
import PrestationSealedBadge from "@/components/aime/PrestationSealedBadge";
import { getSealedStateSync } from "@/lib/sealedState";

export default function PrestationCard({ prestation }) {
  const d = formatDateFR(prestation.date);
  const s = STATUS_META[prestation.status];
  const missing = prestation.missing_documents || 0;

  return (
    <Link
      to={`/fiche/${prestation.id}`}
      className="group block bg-white border border-zinc-200 hover:border-zinc-900 hover:shadow-md rounded-2xl p-4 sm:p-5 transition-shadow transition-colors min-w-0"
    >
      <div className="flex items-start justify-between mb-3">
        <div className="min-w-0">
          <div className="text-[10px] tracking-[0.2em] text-zinc-500 uppercase">
            {d.day} {d.month} {d.year}
          </div>
          <h3 className="text-zinc-900 font-medium text-lg mt-1 leading-tight break-words">
            {prestation.employer || "Fiche sans employeur"}
          </h3>
        </div>
        <ArrowRight className="w-4 h-4 text-zinc-400 group-hover:text-aime-red group-hover:translate-x-0.5 transition-all mt-2" />
      </div>

      {/* Badge scellement v1.5 — affiché uniquement si la fiche a une empreinte */}
      <div className="-mt-1 mb-2">
        <PrestationSealedBadge state={getSealedStateSync(prestation)} compact />
      </div>

      <div className="flex flex-wrap items-center gap-3 text-xs text-zinc-500 mb-4">
        {prestation.location && (
          <span className="inline-flex items-center gap-1.5">
            <MapPin className="w-3 h-3" />
            {prestation.location}
          </span>
        )}
        {prestation.type && <span>{prestation.type}</span>}
        {prestation.amount > 0 && <span className="text-zinc-900 font-medium">{prestation.amount} €</span>}
      </div>

      <div className="flex items-center justify-between pt-3 border-t border-zinc-100">
        <span className="inline-flex items-center gap-1.5 text-xs">
          <span className={`w-1.5 h-1.5 rounded-full ${s?.dot || "bg-zinc-400"}`} />
          <span className={s?.text || "text-zinc-600"}>{s?.label || prestation.status}</span>
        </span>

        {missing > 0 ? (
          <span className="inline-flex items-center gap-1 text-[11px] text-aime-red">
            <AlertTriangle className="w-3 h-3" />
            {missing} doc{missing > 1 ? "s" : ""}
          </span>
        ) : (
          <span className="inline-flex items-center gap-1 text-[11px] text-zinc-500">
            <FileText className="w-3 h-3" />
            {prestation.cachet_code ? prestation.cachet_code.slice(-6) : "—"}
          </span>
        )}
      </div>
    </Link>
  );
}