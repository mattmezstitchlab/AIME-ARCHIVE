import React, { useState, useEffect, useRef } from "react";
import { CalendarHeart, ChevronDown, X } from "lucide-react";
import { EVENT_TYPES_LIST } from "@/lib/event-core/verticals/event";

/**
 * Sélecteur de type d'événement — jumeau du DocPicker pour les évènements.
 * Placé à côté du DocPicker dans FicheTopBar.
 * onSelect(key | null) — null = effacer le type.
 */
export default function EventTypePicker({ eventType, onSelect }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    const onClick = (e) => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  const current = EVENT_TYPES_LIST.find((t) => t.key === eventType);
  const Icon = current?.icon || CalendarHeart;

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen((o) => !o)}
        className={`inline-flex items-center gap-2 backdrop-blur-xl border rounded-full pl-2.5 pr-3 py-2 shadow-sm hover:shadow-md transition-all h-9 ${
          eventType
            ? "bg-purple-600 text-white border-purple-500"
            : "bg-white/95 text-zinc-900 border-zinc-200"
        }`}
      >
        <span className={`w-5 h-5 rounded-full flex items-center justify-center ${
          eventType ? "bg-white/20" : "bg-purple-100 text-purple-600"
        }`}>
          <Icon className="w-3 h-3" />
        </span>
        <span className="text-[12px] font-medium">
          {current ? current.label : "Événement"}
        </span>
        {eventType ? (
          <button
            onClick={(e) => { e.stopPropagation(); onSelect(null); }}
            className="ml-0.5 text-white/70 hover:text-white"
            aria-label="Effacer le type d'événement"
          >
            <X className="w-3 h-3" />
          </button>
        ) : (
          <ChevronDown className={`w-3.5 h-3.5 text-zinc-500 transition-transform ${open ? "rotate-180" : ""}`} />
        )}
      </button>

      {open && (
        <div className="absolute top-full left-0 mt-2 w-[220px] bg-white border border-zinc-200 rounded-2xl shadow-2xl z-50 overflow-hidden">
          <div className="px-3 py-2 border-b border-zinc-100">
            <div className="text-[10px] tracking-[0.2em] text-zinc-500 font-semibold uppercase">Type d'événement</div>
            <div className="text-[11px] text-zinc-600 mt-0.5">Affiche la fiche événement dans le canvas</div>
          </div>
          <div className="p-1.5 max-h-[60vh] overflow-y-auto">
            {EVENT_TYPES_LIST.map((t) => {
              const TIcon = t.icon;
              const isActive = eventType === t.key;
              return (
                <button
                  key={t.key}
                  onClick={() => { onSelect(t.key); setOpen(false); }}
                  className={`w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-left transition-colors ${
                    isActive ? "bg-purple-600 text-white" : "hover:bg-zinc-50"
                  }`}
                >
                  <span className={`w-7 h-7 rounded-md flex items-center justify-center shrink-0 ${
                    isActive ? "bg-white/20" : "bg-zinc-100"
                  }`}>
                    <TIcon className={`w-3.5 h-3.5 ${isActive ? "text-white" : "text-zinc-700"}`} />
                  </span>
                  <div className="min-w-0">
                    <span className={`block text-[12px] font-medium leading-tight ${isActive ? "text-white" : "text-zinc-900"}`}>
                      {t.label}
                    </span>
                    <span className={`block text-[10px] truncate ${isActive ? "text-white/70" : "text-zinc-500"}`}>
                      {t.description}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}