import React, { useEffect, useState } from "react";
import { Link, ExternalLink } from "lucide-react";
import { EVENT_TYPES_LIST } from "@/lib/event-core/verticals/event";
import { base44 } from "@/api/base44Client";

/**
 * Section "Événement" du Studio — permet d'associer la fiche cachet
 * à un type d'événement et optionnellement à un EventRecord existant.
 *
 * Unification Cachet ↔ AIME Event. Phase 2A — préparatoire uniquement.
 */
export default function SectionEvenement({ eventType, onEventTypeChange, eventRecordId, onEventRecordChange }) {
  const [events, setEvents] = useState([]);
  const [loadingEvents, setLoadingEvents] = useState(false);

  // Charge les EventRecords du même type si un type est sélectionné
  useEffect(() => {
    if (!eventType) { setEvents([]); return; }
    setLoadingEvents(true);
    base44.entities.EventRecord.filter({ eventType })
      .then((res) => setEvents(res || []))
      .finally(() => setLoadingEvents(false));
  }, [eventType]);

  return (
    <div className="space-y-4 px-4 py-3">
      {/* Sélecteur de type */}
      <div>
        <p className="text-[10px] text-zinc-400 uppercase tracking-wider font-semibold mb-2">
          Type d&apos;événement
        </p>
        <div className="grid grid-cols-2 gap-1.5">
          {EVENT_TYPES_LIST.map((t) => {
            const Icon = t.icon;
            const active = eventType === t.key;
            return (
              <button
                key={t.key}
                onClick={() => {
                  onEventTypeChange(active ? null : t.key);
                  if (active) onEventRecordChange(null);
                }}
                className={`flex items-center gap-2 px-2.5 py-2 rounded-lg border text-left transition-all ${
                  active
                    ? "bg-aime-red/20 border-aime-red/60 text-white"
                    : "bg-white/5 border-white/10 text-zinc-400 hover:bg-white/10 hover:text-zinc-200"
                }`}
              >
                <Icon className="w-3.5 h-3.5 shrink-0" />
                <span className="text-[11px] font-medium truncate">{t.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Lien vers un EventRecord existant */}
      {eventType && (
        <div>
          <p className="text-[10px] text-zinc-400 uppercase tracking-wider font-semibold mb-2">
            Lier à un événement existant
          </p>
          {loadingEvents ? (
            <p className="text-[11px] text-zinc-500">Chargement…</p>
          ) : events.length === 0 ? (
            <div className="space-y-2">
              <p className="text-[11px] text-zinc-500 italic">
                Aucun événement de ce type.
              </p>
              <a
                href="/events"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 text-[11px] text-aime-red hover:underline"
              >
                <ExternalLink className="w-3 h-3" />
                Créer dans AIME Event
              </a>
            </div>
          ) : (
            <div className="space-y-1 max-h-40 overflow-y-auto">
              {/* Option "aucun" */}
              <button
                onClick={() => onEventRecordChange(null)}
                className={`w-full text-left px-2.5 py-1.5 rounded-lg text-[11px] border transition-all ${
                  !eventRecordId
                    ? "bg-white/10 border-white/20 text-white"
                    : "bg-transparent border-transparent text-zinc-500 hover:bg-white/5 hover:text-zinc-300"
                }`}
              >
                Aucun (type uniquement)
              </button>
              {events.map((ev) => (
                <button
                  key={ev.id}
                  onClick={() => onEventRecordChange(ev.id === eventRecordId ? null : ev.id)}
                  className={`w-full text-left px-2.5 py-1.5 rounded-lg text-[11px] border transition-all ${
                    eventRecordId === ev.id
                      ? "bg-aime-red/20 border-aime-red/40 text-white"
                      : "bg-transparent border-white/5 text-zinc-400 hover:bg-white/5 hover:text-zinc-200"
                  }`}
                >
                  <span className="block truncate font-medium">{ev.title || "Sans titre"}</span>
                  {ev.date && (
                    <span className="text-[9px] text-zinc-500">
                      {new Date(ev.date).toLocaleDateString("fr-FR")}
                    </span>
                  )}
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Lien de navigation rapide */}
      {eventRecordId && (
        <a
          href={`/events/fiche/${eventRecordId}`}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1.5 text-[11px] text-aime-red hover:underline"
        >
          <Link className="w-3 h-3" />
          Ouvrir la fiche événement
        </a>
      )}

      <p className="text-[9px] text-zinc-600 italic leading-relaxed pt-1">
        Association préparatoire. Sans valeur officielle.
      </p>
    </div>
  );
}