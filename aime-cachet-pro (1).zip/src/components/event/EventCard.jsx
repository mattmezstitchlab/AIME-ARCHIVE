import React from "react";
import { Link } from "react-router-dom";
import { Calendar, MapPin } from "lucide-react";
import { getEventType, getEventStatus } from "@/lib/event-core/verticals/event";

/**
 * Carte d'événement — utilisée dans la liste /events et /events/:type.
 */
export default function EventCard({ event }) {
  const type = getEventType(event.eventType);
  const status = getEventStatus(event.status);
  const Icon = type?.icon;

  return (
    <Link
      to={`/events/fiche/${event.id}`}
      className="group flex flex-col gap-2 p-4 rounded-xl bg-white border border-zinc-200 hover:border-zinc-400 hover:shadow-sm transition-all"
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-2 min-w-0">
          {Icon && (
            <div className="w-7 h-7 rounded-md flex items-center justify-center shrink-0 bg-zinc-100 text-zinc-900">
              <Icon className="w-3.5 h-3.5" />
            </div>
          )}
          <div className="min-w-0">
            <div className="text-sm font-semibold text-zinc-900 truncate">
              {event.title || "Événement sans titre"}
            </div>
            <div className="text-[10px] text-zinc-500 uppercase tracking-wider">
              {type?.label || "—"}
            </div>
          </div>
        </div>
        <span
          className="text-[9px] uppercase tracking-wider font-semibold px-1.5 py-0.5 rounded shrink-0"
          style={{ backgroundColor: `${status.color}20`, color: status.color }}
        >
          {status.label}
        </span>
      </div>

      <div className="flex items-center gap-3 text-[11px] text-zinc-500">
        {event.date && (
          <span className="inline-flex items-center gap-1">
            <Calendar className="w-3 h-3" />
            {event.date}
          </span>
        )}
        {event.location && (
          <span className="inline-flex items-center gap-1 truncate">
            <MapPin className="w-3 h-3" />
            {event.location}
          </span>
        )}
      </div>
    </Link>
  );
}