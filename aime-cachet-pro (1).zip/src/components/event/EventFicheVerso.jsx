import React from "react";
import QRBadge from "@/components/aime/fiche/QRBadge";
import { Calendar, MapPin, User, Tag } from "lucide-react";
import { getEventType, EVENT_DOCTRINE_LABELS } from "@/lib/event-core/verticals/event";

/**
 * Verso événementiel — QR INDICATIF uniquement.
 * Pas de hash officiel. Pas de scellement. Pas de /verify.
 */
export default function EventFicheVerso({ event }) {
  const type = getEventType(event.eventType);
  const accessUrl = `${window.location.origin}/events/fiche/${event.id}`;

  const Row = ({ icon: Icon, label, value }) => (
    <div className="flex items-start gap-2 py-1.5 border-b border-zinc-100">
      <Icon className="w-3.5 h-3.5 text-zinc-400 mt-0.5 shrink-0" />
      <span className="text-[10px] uppercase tracking-wider text-zinc-500 w-24 shrink-0">{label}</span>
      <span className="text-[11px] text-zinc-800 flex-1">{value || "—"}</span>
    </div>
  );

  return (
    <div
      className="bg-white shadow-2xl mx-auto relative"
      style={{ width: "210mm", minHeight: "297mm", padding: "20mm 18mm" }}
    >
      <div className="absolute inset-0 pointer-events-none flex items-center justify-center" aria-hidden>
        <span className="text-[100px] font-black tracking-widest opacity-[0.05] select-none rotate-[-25deg] whitespace-nowrap text-zinc-900">
          BROUILLON
        </span>
      </div>

      <div className="relative">
        <div className="text-center mb-8">
          <div className="text-[10px] tracking-[0.2em] uppercase text-zinc-400 font-semibold">
            AIME Event · Verso
          </div>
          <div className="font-display text-xl text-zinc-900 mt-1">{event.title || "Événement"}</div>
        </div>

        <div className="flex flex-col items-center mb-8">
          <QRBadge value={accessUrl} size={140} label={event.id?.slice(0, 8).toUpperCase()} />
          <div className="text-[10px] tracking-wider uppercase text-zinc-500 mt-3 font-semibold">
            {EVENT_DOCTRINE_LABELS.qr_indicative}
          </div>
          <div className="text-[9px] text-zinc-400 italic mt-1 text-center max-w-md">
            Ce QR pointe vers une fiche interne. Il n'a aucune valeur de certification ni de vérification officielle.
          </div>
        </div>

        <div className="max-w-md mx-auto">
          <Row icon={Tag} label="Type" value={type?.label} />
          <Row icon={Calendar} label="Date" value={event.date} />
          <Row icon={MapPin} label="Lieu" value={event.location} />
          <Row icon={User} label="Organisateur" value={event.organizer} />
        </div>

        <div className="absolute bottom-0 left-0 right-0 px-0 pt-12">
          <div className="border-t border-zinc-200 pt-4 text-center space-y-1">
            <div className="text-[9px] text-zinc-500 tracking-wider uppercase">
              {EVENT_DOCTRINE_LABELS.preparatory}
            </div>
            <div className="text-[8px] text-zinc-400 italic">
              {EVENT_DOCTRINE_LABELS.no_official} · {EVENT_DOCTRINE_LABELS.human_review} · {EVENT_DOCTRINE_LABELS.version_kept}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}