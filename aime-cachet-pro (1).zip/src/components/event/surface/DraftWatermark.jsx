import React from "react";

/**
 * Watermark "BROUILLON" — extraction non destructive depuis EventFichePaper.
 *
 * Reproduction strictement identique à l'inline original :
 *   - même texte ("BROUILLON")
 *   - même positionnement (absolute inset-0, centré)
 *   - même rotation (-25deg)
 *   - même opacité (0.05)
 *   - même taille (100px)
 *   - même graisse (font-black)
 *   - même letter-spacing (tracking-widest)
 *   - même couleur (text-zinc-900)
 *   - même comportement (pointer-events-none, select-none, whitespace-nowrap, aria-hidden)
 *
 * Aucun paramètre exposé en v1 — composant volontairement figé pour garantir
 * l'identité visuelle avec l'état antérieur à l'extraction.
 *
 * Doctrine : strictement préparatoire, jamais opposable.
 */
export default function DraftWatermark() {
  // Filigrane "BROUILLON" retiré sur demande — sur toutes les surfaces Event.
  // Composant conservé (return null) pour ne pas casser les imports existants.
  return null;
}