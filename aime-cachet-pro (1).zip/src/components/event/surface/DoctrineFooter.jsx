import React from "react";
import { EVENT_DOCTRINE_LABELS } from "@/lib/event-core/verticals/event";

/**
 * Footer doctrinal — extraction non destructive depuis EventFichePaper.
 *
 * Reproduction strictement identique à l'inline original :
 *   - même conteneur positionné (absolute bottom-8 left-0 right-0 px-[18mm])
 *   - même séparateur (border-t border-zinc-200 pt-3)
 *   - même centrage (text-center)
 *   - même typographie ligne 1 (text-[9px] tracking-wider uppercase, text-zinc-500)
 *   - même typographie ligne 2 (text-[8px] italic, text-zinc-400, mt-1)
 *   - même wording exact :
 *       "{preparatory} · {human_review}"
 *       "{no_official} — ne constitue pas un document officiel."
 *
 * Aucun paramètre exposé en v1 — composant volontairement figé pour garantir
 * l'identité visuelle avec l'état antérieur à l'extraction.
 *
 * Doctrine : strictement préparatoire, jamais opposable.
 */
export default function DoctrineFooter() {
  return (
    <div className="absolute bottom-8 left-0 right-0 px-[18mm]">
      <div className="border-t border-zinc-200 pt-3 text-center">
        <div className="text-[9px] text-zinc-500 tracking-wider uppercase">
          {EVENT_DOCTRINE_LABELS.preparatory} · {EVENT_DOCTRINE_LABELS.human_review}
        </div>
        <div className="text-[8px] text-zinc-400 italic mt-1">
          {EVENT_DOCTRINE_LABELS.no_official} — ne constitue pas un document officiel.
        </div>
      </div>
    </div>
  );
}