import React from "react";
import { LayoutGrid, BookOpen, ArrowLeft } from "lucide-react";
import CockpitSuggestions from "@/components/shared/cockpit/CockpitSuggestions";

/**
 * EventSuggestions — adaptateur métier Event.
 *
 * Couche 3 (Event) — consomme CockpitSuggestions (couche 1 partagée).
 * Liste de raccourcis internes — aucune action externe, aucun envoi.
 */
export default function EventSuggestions() {
  const suggestions = [
    {
      key: "types",
      icon: LayoutGrid,
      label: "Voir tous les types",
      hint: "Sélectionner un type d'événement",
      to: "/events/types",
    },
    {
      key: "cachet",
      icon: ArrowLeft,
      label: "Retour AIME Cachet",
      hint: "Revenir à la verticale intermittence",
      to: "/app",
    },
    {
      key: "aide",
      icon: BookOpen,
      label: "Aide & doctrine",
      hint: "Comprendre les brouillons préparatoires",
      to: "/aide",
    },
  ];

  return <CockpitSuggestions title="Raccourcis" suggestions={suggestions} />;
}