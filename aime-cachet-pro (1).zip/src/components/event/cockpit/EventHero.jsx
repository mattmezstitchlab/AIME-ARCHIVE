import React from "react";
import CockpitHero from "@/components/shared/cockpit/CockpitHero";

/**
 * EventHero — adaptateur métier Event.
 *
 * Couche 3 (Event) — consomme CockpitHero (couche 1 partagée).
 * Aucun import depuis components/aime/*.
 *
 * Props :
 * - events : tableau d'EventRecord (peut être vide)
 */
export default function EventHero({ events = [] }) {
  const total = events.length;
  const enPreparation = events.filter(
    (e) => e.status === "en_preparation" || e.status === "pret_a_partager"
  ).length;
  const brouillons = events.filter((e) => e.status === "brouillon" || !e.status).length;

  const title =
    total === 0 ? "Aucun événement" : `${total} événement${total > 1 ? "s" : ""}`;
  const subtitle =
    total === 0
      ? "Créez votre premier brouillon pour commencer."
      : `${enPreparation} en préparation · ${brouillons} en brouillon`;

  return (
    <CockpitHero
      eyebrow="AIME EVENT · BROUILLONS PRIVÉS"
      title={title}
      subtitle={subtitle}
      accent="sky"
    />
  );
}