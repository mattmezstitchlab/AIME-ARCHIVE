import React from "react";
import TimelineCard from "@/components/shared/cockpit/TimelineCard";
import { getEventType, getEventStatus } from "@/lib/event-core/verticals/event";

/**
 * EventTimelineCard — adaptateur métier Event.
 *
 * Couche 3 (Event) — consomme TimelineCard (couche 1 partagée).
 * Convertit un EventRecord en props pour la coque générique.
 *
 * Props :
 * - event : EventRecord
 */
export default function EventTimelineCard({ event }) {
  const type = getEventType(event.eventType);
  const status = getEventStatus(event.status);
  const Icon = type?.icon || null;

  const subtitleParts = [];
  if (event.date) subtitleParts.push(formatDate(event.date));
  if (event.location) subtitleParts.push(event.location);
  if (!subtitleParts.length && type) subtitleParts.push(type.label);

  // Tone du badge selon le statut préparatoire
  const toneMap = {
    brouillon: "neutral",
    en_preparation: "sky",
    pret_a_partager: "emerald",
    archive: "neutral",
  };

  return (
    <TimelineCard
      icon={Icon}
      iconColor=""
      title={event.title || "Sans titre"}
      subtitle={subtitleParts.join(" · ")}
      badge={{ label: status.label, tone: toneMap[event.status] || "neutral" }}
      to={`/events/fiche/${event.id}`}
    />
  );
}

function formatDate(iso) {
  try {
    const d = new Date(iso);
    return d.toLocaleDateString("fr-FR", { day: "2-digit", month: "short", year: "numeric" });
  } catch {
    return iso;
  }
}