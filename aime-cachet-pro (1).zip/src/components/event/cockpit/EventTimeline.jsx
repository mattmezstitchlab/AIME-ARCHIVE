import React, { useMemo } from "react";
import { Link } from "react-router-dom";
import CollapsibleTimelineGroup from "@/components/shared/cockpit/CollapsibleTimelineGroup";
import EventTimelineCard from "./EventTimelineCard";
import EventCreateButton from "@/components/event/EventCreateButton";

/**
 * EventTimeline — timeline chronologique des EventRecord.
 *
 * Couche 3 (Event) — consomme TimelineGroup (couche 1 partagée).
 * Groupe par mois (selon event.date, puis event.created_date en fallback).
 *
 * Props :
 * - events  : tableau d'EventRecord
 * - loading : booléen
 */
export default function EventTimeline({ events = [], loading = false }) {
  const groups = useMemo(() => groupByMonth(events), [events]);

  if (loading) {
    return <div className="text-center py-12 text-sm text-zinc-400">Chargement…</div>;
  }

  if (!events.length) {
    return (
      <div className="text-center py-12 px-4 rounded-xl border border-dashed border-zinc-300 bg-white">
        <p className="text-sm text-zinc-600 mb-3">
          Aucun événement pour le moment.
        </p>
        <EventCreateButton label="Créer un premier brouillon" />
        <div className="mt-4 text-[11px] text-zinc-400">
          ou{" "}
          <Link to="/events/types" className="underline hover:text-zinc-700">
            parcourir les types
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {groups.map((g, idx) => (
        <CollapsibleTimelineGroup
          key={g.key}
          label={g.label}
          sublabel={`${g.events.length} événement${g.events.length > 1 ? "s" : ""}`}
          defaultOpen={idx === 0}
        >
          {g.events.map((ev) => (
            <EventTimelineCard key={ev.id} event={ev} />
          ))}
        </CollapsibleTimelineGroup>
      ))}
    </div>
  );
}

function groupByMonth(events) {
  const map = new Map();
  events.forEach((e) => {
    const iso = e.date || e.created_date || new Date().toISOString();
    const d = new Date(iso);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    const label = d.toLocaleDateString("fr-FR", { month: "long", year: "numeric" });
    if (!map.has(key)) map.set(key, { key, label, ts: d.getTime(), events: [] });
    map.get(key).events.push(e);
  });
  // Tri descendant (mois le plus récent en premier)
  return Array.from(map.values()).sort((a, b) => b.ts - a.ts);
}