import React from "react";
import CockpitMilestones from "@/components/shared/cockpit/CockpitMilestones";

/**
 * EventMilestones — adaptateur métier Event.
 *
 * Couche 3 (Event) — consomme CockpitMilestones (couche 1 partagée).
 * Affiche les jalons doctrinaux de l'événement le plus récent (= en cours d'édition).
 *
 * Props :
 * - latestEvent : EventRecord le plus récent (ou null si aucun)
 */
export default function EventMilestones({ latestEvent }) {
  if (!latestEvent) {
    return (
      <CockpitMilestones
        title="Jalons du premier événement"
        milestones={[
          { key: "create", label: "Créer un brouillon", hint: "Choisir un type d'événement", status: "current" },
          { key: "title", label: "Renseigner un titre", status: "todo" },
          { key: "date", label: "Fixer une date", status: "todo" },
          { key: "location", label: "Choisir un lieu", status: "todo" },
        ]}
      />
    );
  }

  const has = (v) => v !== undefined && v !== null && String(v).trim() !== "";
  const isPlaceholder = !has(latestEvent.title) || latestEvent.title === "Nouvel événement (brouillon)";

  const milestones = [
    {
      key: "create",
      label: "Brouillon créé",
      hint: latestEvent.eventType ? `Type : ${latestEvent.eventType}` : null,
      status: "done",
    },
    {
      key: "title",
      label: "Titre renseigné",
      status: isPlaceholder ? "current" : "done",
    },
    {
      key: "date",
      label: "Date fixée",
      hint: latestEvent.date || null,
      status: has(latestEvent.date) ? "done" : "current",
    },
    {
      key: "location",
      label: "Lieu choisi",
      hint: latestEvent.location || null,
      status: has(latestEvent.location) ? "done" : "todo",
    },
    {
      key: "surface",
      label: "Surface du canvas",
      hint: latestEvent.surfaceMode ? `Mode : ${latestEvent.surfaceMode}` : null,
      status: has(latestEvent.surfaceMode) ? "done" : "todo",
    },
  ];

  return <CockpitMilestones title="Dernier événement — préparation" milestones={milestones} />;
}