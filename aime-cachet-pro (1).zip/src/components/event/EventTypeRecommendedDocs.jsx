import React from "react";
import {
  FileText, Users, Calendar, ListChecks, Mail, Globe,
  CheckSquare, Wallet, Wrench, Phone,
} from "lucide-react";
import { EVENT_DOCUMENT_LIBRARY } from "@/lib/event-core/verticals/event";

/**
 * Hub documentaire en lecture seule pour /events/:type.
 * Affiche les documents recommandés déjà déclarés dans la config event-core.
 * AUCUNE création de document, aucune logique métier, aucun PDF, aucun hash.
 */

// Mapping local des icônes — uniquement celles déclarées dans EVENT_DOCUMENT_LIBRARY.
const ICONS = {
  FileText, Users, Calendar, ListChecks, Mail, Globe,
  CheckSquare, Wallet, Wrench, Phone,
};

export default function EventTypeRecommendedDocs({ type }) {
  return (
    <section className="rounded-xl border border-zinc-200 bg-white p-5">
      <div className="flex items-start gap-3 mb-4">
        <div
          className="w-8 h-8 rounded-md flex items-center justify-center shrink-0 mt-0.5"
          style={{ backgroundColor: `${type.color}15`, color: type.color }}
          aria-hidden
        >
          <FileText className="w-4 h-4" />
        </div>
        <div>
          <h2 className="text-[11px] tracking-[0.2em] uppercase text-zinc-500 font-semibold">
            Hub préparatoire · {type.label}
          </h2>
          <p className="text-[13px] text-zinc-700 leading-snug mt-1">
            Préparation type <strong>{type.label}</strong> : les documents recommandés ci-dessous
            servent de repères préparatoires.
          </p>
          <p className="text-[10px] text-zinc-400 italic mt-1">
            Aperçu en lecture seule — non implémentés en Phase 2A. À valider humainement.
          </p>
        </div>
      </div>

      <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
        {EVENT_DOCUMENT_LIBRARY.map((doc) => {
          const Icon = ICONS[doc.icon] || FileText;
          return (
            <li
              key={doc.key}
              className="flex items-start gap-2.5 px-3 py-2 rounded-lg border border-zinc-100 bg-zinc-50/50"
            >
              <div className="w-7 h-7 rounded-md flex items-center justify-center shrink-0 bg-white border border-zinc-200 text-zinc-500">
                <Icon className="w-3.5 h-3.5" />
              </div>
              <div className="min-w-0">
                <div className="text-[12px] font-semibold text-zinc-800 leading-tight">
                  {doc.label}
                </div>
                <div className="text-[10px] text-zinc-500 leading-snug mt-0.5">
                  {doc.description}
                </div>
              </div>
            </li>
          );
        })}
      </ul>
    </section>
  );
}