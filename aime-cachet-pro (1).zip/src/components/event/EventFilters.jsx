import React from "react";
import { Search } from "lucide-react";
import { EVENT_TYPES_LIST, EVENT_STATUSES } from "@/lib/event-core/verticals/event";

/**
 * Filtres pour la liste /events :
 * - recherche texte
 * - filtre par type
 * - filtre par statut
 */
export default function EventFilters({
  search, onSearchChange,
  typeFilter, onTypeFilterChange,
  statusFilter, onStatusFilterChange,
}) {
  return (
    <div className="flex flex-col md:flex-row gap-3">
      <div className="relative flex-1">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
        <input
          type="text"
          value={search}
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder="Rechercher un événement…"
          className="w-full pl-9 pr-3 py-2 rounded-lg border border-zinc-200 bg-white text-sm placeholder:text-zinc-400 focus:outline-none focus:border-zinc-400"
        />
      </div>
      <select
        value={typeFilter}
        onChange={(e) => onTypeFilterChange(e.target.value)}
        className="px-3 py-2 rounded-lg border border-zinc-200 bg-white text-sm focus:outline-none focus:border-zinc-400"
      >
        <option value="">Tous les types</option>
        {EVENT_TYPES_LIST.map((t) => (
          <option key={t.key} value={t.key}>{t.label}</option>
        ))}
      </select>
      <select
        value={statusFilter}
        onChange={(e) => onStatusFilterChange(e.target.value)}
        className="px-3 py-2 rounded-lg border border-zinc-200 bg-white text-sm focus:outline-none focus:border-zinc-400"
      >
        <option value="">Tous les statuts</option>
        {EVENT_STATUSES.map((s) => (
          <option key={s.key} value={s.key}>{s.label}</option>
        ))}
      </select>
    </div>
  );
}