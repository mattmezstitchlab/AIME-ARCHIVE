import React from "react";
import { Link } from "react-router-dom";

/**
 * Carte de type d'événement — utilisée dans /events et /events/:type.
 * Lit la configuration déclarative de event-core/verticals/event.js.
 */
export default function EventTypeCard({ type, count = 0 }) {
  const Icon = type.icon;
  return (
    <Link
      to={`/events/${type.key}`}
      className="group relative flex flex-col gap-2 p-4 rounded-xl bg-white border border-zinc-200 hover:border-zinc-400 transition-all"
    >
      <div className="flex items-center justify-between">
        <div className="w-9 h-9 rounded-lg flex items-center justify-center bg-zinc-100 text-zinc-900">
          <Icon className="w-4 h-4" />
        </div>
        <span className="text-[10px] tabular-nums text-zinc-400 font-medium">
          {count > 0 ? `${count}` : "—"}
        </span>
      </div>
      <div>
        <div className="text-sm font-semibold text-zinc-900 leading-tight">{type.label}</div>
        <div className="text-[11px] text-zinc-500 leading-snug mt-1 line-clamp-2">
          {type.description}
        </div>
      </div>
    </Link>
  );
}