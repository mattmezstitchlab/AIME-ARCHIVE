import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Plus, X } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import { EVENT_TYPES_LIST, getWeddingTemplate } from "@/lib/event-core/verticals/event";
import WeddingTemplatePicker from "./WeddingTemplatePicker";

/**
 * Bouton "Créer un événement" + modal de sélection du type.
 * Crée un EventRecord avec visibility='private_draft' strict.
 */
export default function EventCreateButton({ defaultType = null, label = "Créer un événement" }) {
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [creating, setCreating] = useState(false);
  // Étape 2 : si l'utilisateur a choisi "mariage", on affiche le picker de modèles.
  const [weddingStep, setWeddingStep] = useState(false);

  // Création "vierge" — comportement actuel strictement préservé.
  // Utilisée pour TOUS les types non-mariage, et pour mariage + "Commencer vide".
  const handleCreate = async (typeKey) => {
    setCreating(true);
    try {
      const ev = await base44.entities.EventRecord.create({
        eventType: typeKey,
        title: "Nouvel événement (brouillon)",
        status: "brouillon",
        visibility: "private_draft",
      });
      toast.success("Brouillon événement créé");
      navigate(`/events/fiche/${ev.id}`);
    } catch (e) {
      toast.error("Création impossible", { description: e.message });
    } finally {
      setCreating(false);
      setOpen(false);
      setWeddingStep(false);
    }
  };

  // Étape 1 : sélection du type. Si "mariage", on bascule vers l'étape 2 (sans créer).
  const handleTypePick = (typeKey) => {
    if (typeKey === "mariage") {
      setWeddingStep(true);
      return;
    }
    handleCreate(typeKey);
  };

  // Étape 2 : sélection d'un modèle mariage OU "Commencer vide".
  // - templateKey === null  → comportement actuel strictement préservé (= handleCreate("mariage")).
  // - templateKey !== null  → préremplissage à partir de WEDDING_TEMPLATES.
  const handleWeddingPick = async (templateKey) => {
    if (templateKey === null) {
      handleCreate("mariage");
      return;
    }
    const tpl = getWeddingTemplate(templateKey);
    if (!tpl) {
      handleCreate("mariage");
      return;
    }
    setCreating(true);
    try {
      const ev = await base44.entities.EventRecord.create({
        eventType: "mariage",
        visibility: "private_draft",
        ...tpl.values,
      });
      toast.success("Brouillon mariage créé");
      navigate(`/events/fiche/${ev.id}`);
    } catch (e) {
      toast.error("Création impossible", { description: e.message });
    } finally {
      setCreating(false);
      setOpen(false);
      setWeddingStep(false);
    }
  };

  const closeModal = () => {
    setOpen(false);
    setWeddingStep(false);
  };

  // Mode bouton direct : si defaultType="mariage", on ouvre le modal sur l'étape 2 (modèles).
  // Sinon comportement actuel strictement préservé : création immédiate.
  if (defaultType) {
    if (defaultType === "mariage") {
      return (
        <>
          <button
            onClick={() => {
              setOpen(true);
              setWeddingStep(true);
            }}
            disabled={creating}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-full bg-zinc-900 hover:bg-aime-red text-white text-sm font-medium transition-colors disabled:opacity-50"
          >
            <Plus className="w-4 h-4" />
            {label}
          </button>

          {open && weddingStep && (
            <div
              className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4"
              onClick={closeModal}
            >
              <div
                className="bg-white rounded-2xl p-6 w-full max-w-lg shadow-2xl"
                onClick={(e) => e.stopPropagation()}
              >
                <WeddingTemplatePicker
                  onPick={handleWeddingPick}
                  onClose={closeModal}
                  disabled={creating}
                />
              </div>
            </div>
          )}
        </>
      );
    }
    return (
      <button
        onClick={() => handleCreate(defaultType)}
        disabled={creating}
        className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-full bg-zinc-900 hover:bg-aime-red text-white text-sm font-medium transition-colors disabled:opacity-50"
      >
        <Plus className="w-4 h-4" />
        {label}
      </button>
    );
  }

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-full bg-zinc-900 hover:bg-aime-red text-white text-sm font-medium transition-colors"
      >
        <Plus className="w-4 h-4" />
        {label}
      </button>

      {open && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4"
          onClick={closeModal}
        >
          <div
            className="bg-white rounded-2xl p-6 w-full max-w-lg shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            {weddingStep ? (
              <WeddingTemplatePicker
                onPick={handleWeddingPick}
                onClose={closeModal}
                disabled={creating}
              />
            ) : (
              <>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-base font-semibold text-zinc-900">Choisir un type d'événement</h3>
                  <button onClick={closeModal} className="text-zinc-400 hover:text-zinc-900">
                    <X className="w-4 h-4" />
                  </button>
                </div>
                <p className="text-[11px] text-zinc-500 mb-4">
                  Le brouillon est créé en mode privé (<em>private_draft</em>). Vous pourrez tout modifier ensuite.
                </p>
                <div className="grid grid-cols-2 gap-2 max-h-[60vh] overflow-auto">
                  {EVENT_TYPES_LIST.map((t) => {
                    const Icon = t.icon;
                    return (
                      <button
                        key={t.key}
                        onClick={() => handleTypePick(t.key)}
                        disabled={creating}
                        className="flex items-center gap-2 p-3 rounded-lg border border-zinc-200 hover:border-zinc-400 text-left transition-all disabled:opacity-50"
                      >
                        <div className="w-8 h-8 rounded-md flex items-center justify-center shrink-0 bg-zinc-100 text-zinc-900">
                          <Icon className="w-4 h-4" />
                        </div>
                        <div className="min-w-0">
                          <div className="text-[12px] font-semibold text-zinc-900 truncate">{t.label}</div>
                          <div className="text-[10px] text-zinc-500 line-clamp-1">{t.description}</div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </>
  );
}