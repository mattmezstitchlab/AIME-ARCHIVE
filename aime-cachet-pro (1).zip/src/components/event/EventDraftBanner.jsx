import React from "react";
import { AlertCircle } from "lucide-react";

/**
 * Bandeau doctrinal AIME Event — affiché sur toutes les pages /events*
 * Rappelle que tout est brouillon préparatoire, non opposable.
 * Conforme CanvasCore §7.
 */
export default function EventDraftBanner({ compact = false }) {
  if (compact) {
    return (
      <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-50 border border-amber-200 text-[10px] text-amber-800 font-medium">
        <AlertCircle className="w-3 h-3" />
        Brouillon préparatoire — non opposable
      </div>
    );
  }
  return (
    <div className="flex items-start gap-2.5 px-3.5 py-2.5 rounded-xl bg-amber-50 border border-amber-200">
      <AlertCircle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
      <div className="text-[11px] text-amber-900 leading-relaxed">
        <strong>AIME Event — Phase 2A.</strong> Tous les événements créés ici sont des <strong>brouillons préparatoires</strong>,
        strictement privés (<em>private_draft</em>), <strong>non opposables</strong>, sans valeur officielle.
        Toute information doit être <strong>validée humainement</strong> avant toute communication officielle.
      </div>
    </div>
  );
}