import React from "react";
import { X, FileText } from "lucide-react";
import { WEDDING_TEMPLATES_LIST } from "@/lib/event-core/verticals/event";

/**
 * Étape 2 du modal de création — affichée UNIQUEMENT pour eventType === "mariage".
 * Propose 3 modèles préparatoires + une option "Commencer vide".
 *
 * Doctrine :
 * - Aucun nouveau champ EventRecord.
 * - Tous les modèles ne préremplissent que des champs existants et éditables.
 * - Wording prudent obligatoire affiché en tête.
 *
 * Props :
 * - onPick(templateKey | null) : null = "Commencer vide" (comportement actuel inchangé).
 * - onClose() : fermeture du modal.
 * - disabled : état de création en cours.
 */
export default function WeddingTemplatePicker({ onPick, onClose, disabled = false }) {
  return (
    <>
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-base font-semibold text-zinc-900">Choisir un modèle préparatoire</h3>
        <button
          onClick={onClose}
          className="text-zinc-400 hover:text-zinc-900"
          aria-label="Fermer"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="px-3 py-2 rounded-lg bg-pink-50 border border-pink-200 mb-4">
        <p className="text-[11px] text-pink-900 leading-snug">
          <strong>Modèle préparatoire — entièrement modifiable.</strong> Ces suggestions
          n'engagent personne et restent strictement privées.
        </p>
      </div>

      <div className="space-y-2">
        {WEDDING_TEMPLATES_LIST.map((tpl) => (
          <button
            key={tpl.key}
            onClick={() => onPick(tpl.key)}
            disabled={disabled}
            className="w-full flex items-start gap-3 p-3 rounded-lg border border-zinc-200 hover:border-pink-400 hover:bg-pink-50/40 text-left transition-all disabled:opacity-50"
          >
            <div className="text-2xl shrink-0 leading-none mt-0.5" aria-hidden>
              {tpl.emoji}
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-[13px] font-semibold text-zinc-900">{tpl.label}</div>
              <div className="text-[11px] text-zinc-500 mt-0.5">{tpl.tagline}</div>
            </div>
          </button>
        ))}

        {/* Option "Commencer vide" — strictement équivalente au comportement actuel. */}
        <button
          onClick={() => onPick(null)}
          disabled={disabled}
          className="w-full flex items-start gap-3 p-3 rounded-lg border border-dashed border-zinc-300 hover:border-zinc-500 text-left transition-all disabled:opacity-50"
        >
          <div className="w-8 h-8 rounded-md flex items-center justify-center shrink-0 bg-zinc-100 text-zinc-500 mt-0.5">
            <FileText className="w-4 h-4" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="text-[13px] font-semibold text-zinc-900">Commencer vide</div>
            <div className="text-[11px] text-zinc-500 mt-0.5">
              Brouillon vierge — aucun préremplissage.
            </div>
          </div>
        </button>
      </div>

      <div className="mt-4 text-[9px] text-zinc-400 italic leading-snug">
        Tous les modèles créent un brouillon strictement privé (<em>private_draft</em>) — aucune
        valeur officielle, aucun engagement.
      </div>
    </>
  );
}