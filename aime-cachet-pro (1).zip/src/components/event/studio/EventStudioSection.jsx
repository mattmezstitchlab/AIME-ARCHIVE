import React, { useState } from "react";
import { ChevronDown } from "lucide-react";

/**
 * Section repliable du Studio AIME Event.
 *
 * Composant strictement parallèle au StudioSection AIME Cachet (aucun import croisé).
 * Palette sobre, non rouge, pour préserver la distinction visuelle Event / Cachet.
 *
 * Props :
 *  - icon       : ReactNode (icône Lucide 3.5×3.5 recommandée)
 *  - title      : string (12px font-semibold)
 *  - subtitle   : string (10px zinc-500)
 *  - defaultOpen: boolean (ouvert au montage uniquement)
 *  - accent     : "zinc" (par défaut) | "amber" | "sky"
 *  - children   : contenu de la section
 *
 * État ouvert/fermé : local uniquement, session-scoped, non persisté.
 */
export default function EventStudioSection({
  icon,
  title,
  subtitle,
  defaultOpen = false,
  accent = "zinc",
  children,
}) {
  const [open, setOpen] = useState(defaultOpen);

  const accentClasses = {
    zinc: "bg-white/5 text-zinc-300",
    amber: "bg-amber-500/10 text-amber-300",
    sky: "bg-sky-500/10 text-sky-300",
  };
  const pastille = accentClasses[accent] || accentClasses.zinc;

  return (
    <div className="border-b border-white/5 last:border-b-0">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="w-full flex items-center gap-3 px-4 py-3.5 hover:bg-white/[0.03] transition-colors text-left"
      >
        {icon && (
          <span className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${pastille}`}>
            {icon}
          </span>
        )}
        <span className="flex-1 min-w-0">
          <span className="block text-[12px] font-semibold text-white leading-tight">{title}</span>
          {subtitle && (
            <span className="block text-[10px] text-zinc-500 mt-0.5 truncate">{subtitle}</span>
          )}
        </span>
        <ChevronDown
          className={`w-3.5 h-3.5 text-zinc-500 transition-transform shrink-0 ${open ? "rotate-180" : ""}`}
        />
      </button>
      {open && <div className="px-4 pb-4 pt-1 space-y-2">{children}</div>}
    </div>
  );
}