import React, { useState, useMemo } from "react";
import { ChevronDown, HelpCircle } from "lucide-react";
import { detectProposals } from "@/lib/event-core/propagation/detect-v0";

/**
 * Source Propagation Section — Studio événementiel v0.
 *
 * Doctrine : docs/aime-event-source-propagation-ui-v0-doctrine.md
 * Cadrage  : docs/aime-event-source-propagation-impl-v0-cadrage.md
 *
 * Règles strictes :
 *  - Section repliable, fermée par défaut.
 *  - Visible seulement si ≥ 1 proposition.
 *  - Aucun toast, aucune notification, aucune animation anxiogène.
 *  - Aucun bouton externe : envoyer, publier, signer, PDF, sceller, partager, facturer, notifier.
 *  - « Noter » : action non destructive — passe le statut local à « notée ».
 *    Le bouton ne déclenche aucune écriture, aucune action externe.
 *    Le badge affiche explicitement qu'aucune modification n'a été appliquée.
 *  - « Plus tard » / « Ignorer » : mémoire de session uniquement (perdue au rechargement).
 *  - « Voir pourquoi » : popover local.
 */
export default function SourcePropagationSection({ event }) {
  const [open, setOpen] = useState(false);
  // Mémoire de session — perdue au rechargement, conformément à l'UI doctrine §9.2.
  const [sessionStatus, setSessionStatus] = useState({});
  const [openWhyId, setOpenWhyId] = useState(null);

  const proposals = useMemo(() => detectProposals(event || {}), [event]);

  // Filtre : les propositions « ignorée » ou « plus tard » sont masquées de la liste visible.
  const visible = useMemo(() => {
    return proposals.filter((p) => {
      const s = sessionStatus[p.id];
      return s !== "ignorée" && s !== "plus tard";
    });
  }, [proposals, sessionStatus]);

  // Section masquée si aucune proposition visible.
  if (visible.length === 0) return null;

  const setStatus = (id, status) => {
    setSessionStatus((prev) => ({ ...prev, [id]: status }));
    if (openWhyId === id) setOpenWhyId(null);
  };

  return (
    <div>
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="w-full flex items-center justify-between text-left"
      >
        <div>
          <div className="text-[10px] tracking-[0.2em] uppercase text-zinc-400 font-semibold">
            Ce que cette information déclenche
          </div>
          <div className="text-[10px] text-zinc-500 mt-0.5">
            Cerise propose, vous validez.
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[10px] text-zinc-500 tabular-nums">{visible.length}</span>
          <ChevronDown
            className={`w-4 h-4 text-zinc-500 transition-transform ${open ? "rotate-180" : ""}`}
          />
        </div>
      </button>

      {open && (
        <div className="mt-3 space-y-2">
          {visible.map((p) => {
            const currentStatus = sessionStatus[p.id] || p.status;
            const isNoted = currentStatus === "notée";
            return (
              <div
                key={p.id}
                className={`px-3 py-2.5 rounded-lg border ${
                  isNoted
                    ? "bg-emerald-500/5 border-emerald-500/20"
                    : "bg-white/5 border-white/10"
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <div className="text-[11px] text-white font-medium leading-snug">
                      {p.title}
                    </div>
                    <div className="text-[10px] text-zinc-400 leading-snug mt-1">
                      {p.phrase}
                    </div>
                    {isNoted && (
                      <div className="text-[9px] text-emerald-300 mt-1 italic">
                        Notée en session — aucune modification appliquée.
                      </div>
                    )}
                  </div>
                  <button
                    type="button"
                    onClick={() => setOpenWhyId(openWhyId === p.id ? null : p.id)}
                    className="text-zinc-500 hover:text-zinc-300 shrink-0"
                    title="Voir pourquoi"
                  >
                    <HelpCircle className="w-3.5 h-3.5" />
                  </button>
                </div>

                {openWhyId === p.id && (
                  <div className="mt-2 px-2 py-1.5 rounded bg-black/30 border border-white/5 text-[10px] text-zinc-300 italic leading-snug">
                    {p.why}
                  </div>
                )}

                {!isNoted && (
                  <div className="flex flex-wrap gap-1.5 mt-2">
                    <button
                      type="button"
                      onClick={() => setStatus(p.id, "notée")}
                      className="px-2 py-1 rounded text-[10px] font-medium bg-white/10 text-white hover:bg-white/15 border border-white/10"
                    >
                      Noter
                    </button>
                    <button
                      type="button"
                      onClick={() => setOpenWhyId(openWhyId === p.id ? null : p.id)}
                      className="px-2 py-1 rounded text-[10px] text-zinc-300 hover:text-white border border-white/5"
                    >
                      Voir pourquoi
                    </button>
                    <button
                      type="button"
                      onClick={() => setStatus(p.id, "plus tard")}
                      className="px-2 py-1 rounded text-[10px] text-zinc-400 hover:text-zinc-200 border border-white/5"
                    >
                      Plus tard
                    </button>
                    <button
                      type="button"
                      onClick={() => setStatus(p.id, "ignorée")}
                      className="px-2 py-1 rounded text-[10px] text-zinc-500 hover:text-zinc-300 border border-white/5"
                    >
                      Ignorer
                    </button>
                  </div>
                )}
              </div>
            );
          })}

          <div className="mt-2 pt-2 border-t border-white/5 text-[9px] text-zinc-500 italic leading-snug space-y-0.5">
            <div>Une saisie, plusieurs supports. Vous validez chaque projection.</div>
            <div>Ces propositions restent privées, préparatoires et non opposables.</div>
            <div>Aucune action externe n'est déclenchée.</div>
          </div>
        </div>
      )}
    </div>
  );
}