import React, { useState } from "react";
import { ChevronDown } from "lucide-react";

/**
 * Surface Selector v0 — section repliable du Studio événementiel.
 *
 * Doctrine : docs/aime-event-surface-doctrine-pre-ui.md
 * Cadrage  : Surface Selector v0 — EventStudio (validé 2026-05-23).
 *
 * Règles strictes :
 *  - Affiche uniquement les surfaces ACTIVES ET AUTORISÉES pour le type courant.
 *  - Document A4 → tous types.
 *  - Faire-part → mariage, soiree_privee uniquement.
 *  - Toutes les surfaces planned sont TOTALEMENT MASQUÉES (aucune mention "à venir").
 *  - Aucun toast, aucun bouton enregistrer, aucun modal.
 *  - Repliée par défaut.
 */

// Matrice doctrinale — surfaces actuellement actives et autorisées par type.
// Toute évolution doit faire l'objet d'un freeze documentaire dédié.
const ALLOWED_SURFACES_BY_TYPE = {
  mariage: ["document", "faire_part"],
  soiree_privee: ["document", "faire_part"],
  concert: ["document"],
  spectacle: ["document"],
  festival: ["document"],
  conference: ["document"],
  exposition: ["document"],
  atelier: ["document"],
  associatif: ["document"],
  seminaire: ["document"],
};

const SURFACE_META = {
  document: {
    label: "Fiche préparatoire A4",
    description: "Fiche source de l'événement, tous types. N'est pas un site.",
  },
  faire_part: {
    label: "Faire-part",
    description: "Carte A5 préparatoire — mariages et soirées privées.",
  },
};

export default function SurfaceSelector({ event, onChange }) {
  const [open, setOpen] = useState(false);

  const allowed = ALLOWED_SURFACES_BY_TYPE[event.eventType] || ["document"];
  const current = event.surfaceMode || "document";

  return (
    <div>
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="w-full flex items-center justify-between text-left"
      >
        <div>
          <div className="text-[10px] tracking-[0.2em] uppercase text-zinc-400 font-semibold">
            Surface du canvas
          </div>
          <div className="text-[10px] text-zinc-500 mt-0.5">
            Choisissez la surface utilisée pour le rendu du brouillon.
          </div>
        </div>
        <ChevronDown
          className={`w-4 h-4 text-zinc-500 transition-transform ${open ? "rotate-180" : ""}`}
        />
      </button>

      {open && (
        <div className="mt-3 space-y-2">
          {allowed.map((key) => {
            const meta = SURFACE_META[key];
            if (!meta) return null;
            const checked = current === key;
            return (
              <label
                key={key}
                className={`flex items-start gap-3 px-3 py-2 rounded-lg border cursor-pointer transition-colors ${
                  checked
                    ? "bg-white/10 border-white/30"
                    : "bg-white/5 border-white/10 hover:bg-white/[0.07]"
                }`}
              >
                <input
                  type="radio"
                  name="surfaceMode"
                  value={key}
                  checked={checked}
                  onChange={() => onChange(key)}
                  className="mt-1 accent-white"
                />
                <div className="flex-1">
                  <div className="text-[12px] text-white font-medium">{meta.label}</div>
                  <div className="text-[10px] text-zinc-400 leading-snug mt-0.5">
                    {meta.description}
                  </div>
                </div>
              </label>
            );
          })}

          <div className="text-[9px] text-zinc-500 italic leading-snug pt-1">
            Toutes les surfaces restent privées, préparatoires et non opposables.
          </div>
        </div>
      )}
    </div>
  );
}