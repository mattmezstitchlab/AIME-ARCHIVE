import React from "react";
import { getEventType, getEventStatus, EVENT_DOCTRINE_LABELS } from "@/lib/event-core/verticals/event";
import DraftWatermark from "@/components/event/surface/DraftWatermark";
import DoctrineFooter from "@/components/event/surface/DoctrineFooter";

/**
 * Fiche événementielle générique — recto.
 * Adaptative au type via la configuration event-core.
 * Aucune certification. Aucun hash officiel. Brouillon préparatoire.
 */
export default function EventFichePaper({ event, accent = "#a855f7", paperRef }) {
  const type = getEventType(event.eventType);
  const status = getEventStatus(event.status);
  const Icon = type?.icon;
  const color = type?.color || accent;

  const Row = ({ label, value }) => (
    <div className="flex gap-3 py-2 border-b border-zinc-100">
      <span className="text-[10px] uppercase tracking-wider text-zinc-500 w-28 shrink-0 pt-0.5">{label}</span>
      <span className="text-[12px] text-zinc-900 flex-1">{value || <span className="text-zinc-300 italic">—</span>}</span>
    </div>
  );

  // Placeholder visible pour sections vides — garde une structure préparatoire claire.
  const PlaceholderBlock = () => (
    <div className="rounded-md border border-dashed border-zinc-200 bg-zinc-50/60 px-3 py-2">
      <p className="text-[11px] text-zinc-400 italic leading-snug">
        À renseigner (préparatoire)
      </p>
    </div>
  );

  return (
    <div
      ref={paperRef}
      className="bg-white shadow-2xl mx-auto relative"
      style={{ width: "210mm", minHeight: "297mm", padding: "20mm 18mm" }}
    >
      {/* Filigrane doctrinal — extrait dans DraftWatermark (identique visuellement) */}
      <DraftWatermark />

      {/* Header */}
      <div className="flex items-start justify-between mb-6 relative">
        <div className="flex items-center gap-3">
          {Icon && (
            <div
              className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{ backgroundColor: `${color}15`, color }}
            >
              <Icon className="w-6 h-6" />
            </div>
          )}
          <div>
            <div className="text-[10px] tracking-[0.2em] uppercase text-zinc-400 font-semibold">
              AIME Event · {type?.label || "Événement"}
            </div>
            <h1 className="font-display text-2xl text-zinc-900 leading-tight mt-1">
              {event.title || "Événement sans titre"}
            </h1>
          </div>
        </div>
        <span
          className="text-[9px] uppercase tracking-wider font-semibold px-2 py-1 rounded"
          style={{ backgroundColor: `${status.color}20`, color: status.color }}
        >
          {status.label}
        </span>
      </div>

      {/* Sections */}
      <div className="relative space-y-6">
        <div>
          <div className="text-[10px] tracking-[0.2em] uppercase font-semibold mb-2" style={{ color }}>
            Informations
          </div>
          <Row label="Type" value={type?.label} />
          <Row label="Date" value={event.date} />
          <Row label="Lieu" value={event.location} />
          <Row label="Organisateur" value={event.organizer} />
          <Row label="Public" value={event.audience} />
        </div>

        <div>
          <div className="text-[10px] tracking-[0.2em] uppercase font-semibold mb-2" style={{ color }}>
            Description
          </div>
          {event.description ? (
            <p className="text-[12px] text-zinc-700 leading-relaxed whitespace-pre-wrap">
              {event.description}
            </p>
          ) : (
            <PlaceholderBlock />
          )}
        </div>

        <div>
          <div className="text-[10px] tracking-[0.2em] uppercase font-semibold mb-2" style={{ color }}>
            Programme
          </div>
          {event.programme ? (
            <p className="text-[12px] text-zinc-700 leading-relaxed whitespace-pre-wrap">
              {event.programme}
            </p>
          ) : (
            <PlaceholderBlock />
          )}
        </div>

        <div>
          <div className="text-[10px] tracking-[0.2em] uppercase font-semibold mb-2" style={{ color }}>
            Prestataires
          </div>
          {event.prestataires ? (
            <p className="text-[12px] text-zinc-700 leading-relaxed whitespace-pre-wrap">
              {event.prestataires}
            </p>
          ) : (
            <PlaceholderBlock />
          )}
        </div>

        <div>
          <div className="text-[10px] tracking-[0.2em] uppercase font-semibold mb-2" style={{ color }}>
            Documents préparatoires
          </div>
          {Array.isArray(event.documents) && event.documents.length > 0 ? (
            <ul className="text-[12px] text-zinc-700 list-disc pl-5 space-y-1">
              {event.documents.map((d, i) => (
                <li key={d.key || i}>{d.label || d.key}</li>
              ))}
            </ul>
          ) : (
            <PlaceholderBlock />
          )}
        </div>

        {event.internal_notes && (
          <div className="border-t border-zinc-100 pt-4">
            <div className="text-[10px] tracking-[0.2em] uppercase font-semibold mb-2 text-zinc-500">
              Notes internes
            </div>
            <p className="text-[11px] text-zinc-600 italic leading-relaxed whitespace-pre-wrap">
              {event.internal_notes}
            </p>
          </div>
        )}

        {/* Bloc conditionnel : affiché UNIQUEMENT si type=mariage ET au moins un champ renseigné. */}
        {event.eventType === "mariage" &&
          (event.wedding_partners ||
            event.wedding_date_civil ||
            event.wedding_guest_count_estimate ||
            event.wedding_ceremony_type ||
            event.wedding_budget_estimate) && (
            <div className="border-t border-zinc-100 pt-4">
              <div className="text-[10px] tracking-[0.2em] uppercase font-semibold mb-1" style={{ color }}>
                Détails mariage
              </div>
              <p className="text-[9px] text-zinc-400 italic mb-2">
                Informations préparatoires — à confirmer humainement.
              </p>
              {event.wedding_partners && <Row label="Partenaires" value={event.wedding_partners} />}
              {event.wedding_date_civil && <Row label="Cérémonie civile" value={event.wedding_date_civil} />}
              {event.wedding_ceremony_type && (
                <Row
                  label="Type"
                  value={
                    {
                      civile: "Civile",
                      religieuse: "Religieuse",
                      laique: "Laïque",
                      mixte: "Mixte",
                      autre: "Autre",
                    }[event.wedding_ceremony_type] || event.wedding_ceremony_type
                  }
                />
              )}
              {event.wedding_guest_count_estimate != null && event.wedding_guest_count_estimate !== "" && (
                <Row label="Invités (est.)" value={`${event.wedding_guest_count_estimate}`} />
              )}
              {event.wedding_budget_estimate != null && event.wedding_budget_estimate !== "" && (
                <Row label="Budget (est.)" value={`${event.wedding_budget_estimate} €`} />
              )}
            </div>
          )}
      </div>

      {/* Footer doctrinal — extrait dans DoctrineFooter (identique visuellement) */}
      <DoctrineFooter />
    </div>
  );
}