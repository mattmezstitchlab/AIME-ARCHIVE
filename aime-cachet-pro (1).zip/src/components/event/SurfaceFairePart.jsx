import React from "react";
import DraftWatermark from "@/components/event/surface/DraftWatermark";
import DoctrineFooter from "@/components/event/surface/DoctrineFooter";

/**
 * SurfaceFairePart — première surface visible AIME Event (v0).
 *
 * DOCTRINE
 * --------
 *   - Surface PRÉPARATOIRE, PRIVÉE, NON OPPOSABLE.
 *   - Jamais envoyée. Jamais publique. Jamais imprimée officiellement.
 *   - Aucun RSVP, aucune liste d'invités, aucune donnée nominative de tiers.
 *   - Réutilise strictement DraftWatermark et DoctrineFooter (non modifiés).
 *
 * RENDU
 * -----
 *   - Format A5 portrait (148 × 210 mm).
 *   - Centré à l'intérieur du conteneur 3D A4 existant de EventFicheView
 *     (qui reste en 210 × 297 mm). Pas de modification de EventFicheView.
 *
 * CHAMPS AUTORISÉS (lecture seule depuis EventRecord)
 * ---------------------------------------------------
 *   title, date, location, description,
 *   wedding_partners, wedding_date_civil, wedding_ceremony_type
 *
 * CHAMPS STRICTEMENT INTERDITS SUR CETTE SURFACE
 * ----------------------------------------------
 *   internal_notes, wedding_budget_estimate, wedding_guest_count_estimate,
 *   prestataires, programme, toute donnée nominative tierce.
 */

// Formatage date long FR : "le 15 juin 2026". Préparatoire et défensif.
function formatLongDate(value) {
  if (!value) return "";
  try {
    const d = new Date(value);
    if (Number.isNaN(d.getTime())) return value;
    return d.toLocaleDateString("fr-FR", {
      day: "numeric",
      month: "long",
      year: "numeric",
    });
  } catch {
    return value;
  }
}

const CEREMONY_LABELS = {
  civile: "Cérémonie civile",
  religieuse: "Cérémonie religieuse",
  laique: "Cérémonie laïque",
  mixte: "Cérémonie mixte",
  autre: "Cérémonie",
};

export default function SurfaceFairePart({ event }) {
  const partners = event?.wedding_partners?.trim();
  const title = event?.title?.trim();
  const date = event?.date;
  const location = event?.location?.trim();
  const description = event?.description?.trim();
  const civilDate = event?.wedding_date_civil;
  const ceremonyType = event?.wedding_ceremony_type;

  // Headline = noms des partenaires si renseignés, sinon le titre.
  const headline = partners || title || "Titre à renseigner";

  // Mention cérémonie civile : affichée uniquement si renseignée ET distincte de date principale.
  const showCivilDate = !!civilDate && civilDate !== date;

  return (
    // Wrapper "page A4" transparent — conserve la zone de rendu attendue par EventFicheView
    // (210 × 297 mm) pour ne rien casser dans le conteneur 3D parent.
    // La carte A5 est centrée à l'intérieur.
    <div
      className="relative mx-auto flex items-center justify-center"
      style={{
        width: "210mm",
        minHeight: "297mm",
        backgroundColor: "transparent",
      }}
    >
      {/* CARTE A5 PORTRAIT — l'unique surface visible. */}
      <div
        className="relative shadow-2xl"
        style={{
          width: "148mm",
          height: "210mm",
          backgroundColor: "#FBF8F3", // ivoire chaud premium
          padding: "18mm 14mm",
        }}
      >
        {/* Liseré décoratif intérieur — filet rose poudré à 8mm du bord */}
        <div
          className="pointer-events-none absolute"
          style={{
            top: "8mm",
            right: "8mm",
            bottom: "8mm",
            left: "8mm",
            border: "0.5pt solid #E8D5D0",
          }}
          aria-hidden
        />

        {/* Watermark BROUILLON — composant partagé, réutilisé tel quel. */}
        <DraftWatermark />

        {/* Contenu central */}
        <div className="relative h-full flex flex-col items-center justify-center text-center">
          {/* Cartouche de tête — texte fixe, jamais personnalisé. */}
          <div
            className="text-[8px] tracking-[0.3em] uppercase mb-6"
            style={{ color: "#7A6E68" }}
          >
            Vous êtes convié·e·s à célébrer
          </div>

          {/* Filet ornemental haut */}
          <div className="flex items-center justify-center gap-3 mb-5 w-full">
            <div className="h-px flex-1 max-w-[20mm]" style={{ backgroundColor: "#C9A87C" }} />
            <span className="text-[10px]" style={{ color: "#9C7B3A" }}>✦</span>
            <div className="h-px flex-1 max-w-[20mm]" style={{ backgroundColor: "#C9A87C" }} />
          </div>

          {/* Headline — noms des partenaires ou titre */}
          <h1
            className="leading-[1.15] mb-2"
            style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: "26pt",
              fontWeight: 600,
              color: "#1F1B1A",
              letterSpacing: "-0.01em",
              whiteSpace: "pre-line",
            }}
          >
            {headline}
          </h1>

          {/* Filet ornemental bas */}
          <div className="flex items-center justify-center gap-3 mt-3 mb-6 w-full">
            <div className="h-px flex-1 max-w-[20mm]" style={{ backgroundColor: "#C9A87C" }} />
            <span className="text-[10px]" style={{ color: "#9C7B3A" }}>✦</span>
            <div className="h-px flex-1 max-w-[20mm]" style={{ backgroundColor: "#C9A87C" }} />
          </div>

          {/* Date principale */}
          {date ? (
            <div
              className="mb-1"
              style={{
                fontFamily: "'Caveat', cursive",
                fontSize: "22pt",
                color: "#7A2E3A",
                lineHeight: 1.1,
              }}
            >
              le {formatLongDate(date)}
            </div>
          ) : (
            <div
              className="mb-1 italic"
              style={{
                fontFamily: "'Caveat', cursive",
                fontSize: "20pt",
                color: "#B8A89E",
              }}
            >
              date à confirmer
            </div>
          )}

          {/* Lieu */}
          <div
            className="mt-3 mb-5"
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: "11pt",
              color: "#1F1B1A",
              letterSpacing: "0.02em",
            }}
          >
            {location || (
              <span className="italic" style={{ color: "#B8A89E" }}>
                lieu à préciser
              </span>
            )}
          </div>

          {/* Séparateur fin */}
          <div
            className="my-2"
            style={{ width: "30mm", height: "1px", backgroundColor: "#E8D5D0" }}
          />

          {/* Description — texte court préparatoire */}
          {description ? (
            <p
              className="mt-3 italic max-w-[110mm]"
              style={{
                fontFamily: "'Inter', sans-serif",
                fontSize: "10pt",
                color: "#7A6E68",
                lineHeight: 1.6,
              }}
            >
              {description}
            </p>
          ) : (
            <p
              className="mt-3 italic"
              style={{
                fontFamily: "'Inter', sans-serif",
                fontSize: "9pt",
                color: "#B8A89E",
              }}
            >
              Texte à renseigner (préparatoire)
            </p>
          )}

          {/* Mentions cérémonie — affichées uniquement si renseignées */}
          {(showCivilDate || ceremonyType) && (
            <div className="mt-6 space-y-1">
              {showCivilDate && (
                <div
                  className="tracking-wider"
                  style={{
                    fontFamily: "'Inter', sans-serif",
                    fontSize: "8.5pt",
                    color: "#7A6E68",
                    letterSpacing: "0.08em",
                  }}
                >
                  Cérémonie civile · le {formatLongDate(civilDate)}
                </div>
              )}
              {ceremonyType && (
                <div
                  className="tracking-wider uppercase"
                  style={{
                    fontFamily: "'Inter', sans-serif",
                    fontSize: "8pt",
                    color: "#7A6E68",
                    letterSpacing: "0.15em",
                  }}
                >
                  {CEREMONY_LABELS[ceremonyType] || "Cérémonie"}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer doctrinal — composant partagé, réutilisé tel quel.
            Positionné en bas absolu du papier A5 via son propre style. */}
        <DoctrineFooter />
      </div>
    </div>
  );
}