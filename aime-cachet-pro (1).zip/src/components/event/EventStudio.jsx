import React from "react";
import { X, Sparkles, FileText, Heart, ClipboardList, Library, Lightbulb, LayoutPanelTop, Lock } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { EVENT_STATUSES, EVENT_DOCUMENT_LIBRARY, EVENT_DOCTRINE_LABELS } from "@/lib/event-core/verticals/event";
import SurfaceSelector from "@/components/event/studio/SurfaceSelector";
import SourcePropagationSection from "@/components/event/studio/SourcePropagationSection";
import EventStudioSection from "@/components/event/studio/EventStudioSection";

/**
 * Studio événementiel — panneau latéral d'édition.
 * Sépare de StudioPanel (intermittents) pour éviter tout couplage.
 */
export default function EventStudio({ open, onClose, event, onChange }) {
  if (!open || !event) return null;

  const handleField = async (field, value) => {
    onChange({ ...event, [field]: value });
    // debounce léger côté backend
    clearTimeout(window.__eventStudioSave);
    window.__eventStudioSave = setTimeout(() => {
      base44.entities.EventRecord.update(event.id, { [field]: value });
    }, 600);
  };

  return (
    <>
      <div className="fixed inset-0 z-40 bg-black/40 lg:hidden" onClick={onClose} />
      <aside className="fixed right-0 top-0 bottom-0 z-50 w-full sm:w-[380px] sm:max-w-[90vw] bg-zinc-950 border-l border-white/10 text-white flex flex-col pb-[env(safe-area-inset-bottom)]">
        <div className="sticky top-0 z-10 flex items-center justify-between px-4 py-3.5 border-b border-white/5 bg-zinc-950/95 backdrop-blur-xl">
          <div>
            <div className="text-[13px] font-bold text-white leading-none">Studio Événement</div>
            <div className="text-[9px] text-zinc-500 tracking-wider uppercase mt-0.5">Cockpit · Préparation · Projections</div>
          </div>
          <button onClick={onClose} className="text-zinc-400 hover:text-white p-1">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto">
          <EventStudioSection
            icon={<Sparkles className="w-3.5 h-3.5" />}
            title="Informations principales"
            subtitle="Titre, date, lieu, organisateur"
            defaultOpen
          >
            <Field label="Titre" value={event.title} onChange={(v) => handleField("title", v)} />
            <Field label="Date" type="date" value={event.date} onChange={(v) => handleField("date", v)} />
            <Field label="Lieu" value={event.location} onChange={(v) => handleField("location", v)} />
            <Field label="Organisateur" value={event.organizer} onChange={(v) => handleField("organizer", v)} />
            <Field label="Public concerné" value={event.audience} onChange={(v) => handleField("audience", v)} />
          </EventStudioSection>

          <EventStudioSection
            icon={<FileText className="w-3.5 h-3.5" />}
            title="Contenu"
            subtitle="Description, programme, prestataires, notes"
          >
            <Field label="Description" textarea value={event.description} onChange={(v) => handleField("description", v)} />
            <Field label="Programme" textarea value={event.programme} onChange={(v) => handleField("programme", v)} />
            <Field label="Prestataires" textarea value={event.prestataires} onChange={(v) => handleField("prestataires", v)} />
            <Field label="Notes internes" textarea value={event.internal_notes} onChange={(v) => handleField("internal_notes", v)} />
          </EventStudioSection>

          {/* Section conditionnelle : affichée UNIQUEMENT pour le type "mariage". */}
          {event.eventType === "mariage" && (
            <EventStudioSection
              icon={<Heart className="w-3.5 h-3.5" />}
              title="Détails mariage"
              subtitle="Partenaires, cérémonie, invités"
            >
              <div className="px-3 py-2 rounded-lg bg-pink-500/10 border border-pink-500/20 text-[10px] text-pink-200 leading-snug mb-2">
                Informations préparatoires — à confirmer humainement. Strictement privées, non opposables.
              </div>
              <Field
                label="Futur·e·s marié·e·s / partenaires"
                value={event.wedding_partners}
                onChange={(v) => handleField("wedding_partners", v)}
              />
              <Field
                label="Date de cérémonie civile"
                type="date"
                value={event.wedding_date_civil}
                onChange={(v) => handleField("wedding_date_civil", v)}
              />
              <Field
                label="Nombre d'invités estimé"
                type="number"
                value={event.wedding_guest_count_estimate}
                onChange={(v) => handleField("wedding_guest_count_estimate", v === "" ? null : Number(v))}
              />
              <label className="block">
                <span className="block text-[10px] text-zinc-500 uppercase tracking-wider mb-1">Type de cérémonie</span>
                <select
                  value={event.wedding_ceremony_type || ""}
                  onChange={(e) => handleField("wedding_ceremony_type", e.target.value || null)}
                  className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-sm text-white"
                >
                  <option value="" className="bg-zinc-900">—</option>
                  <option value="civile" className="bg-zinc-900">Civile</option>
                  <option value="religieuse" className="bg-zinc-900">Religieuse</option>
                  <option value="laique" className="bg-zinc-900">Laïque</option>
                  <option value="mixte" className="bg-zinc-900">Mixte</option>
                  <option value="autre" className="bg-zinc-900">Autre</option>
                </select>
              </label>
              <Field
                label="Budget estimé (€)"
                type="number"
                value={event.wedding_budget_estimate}
                onChange={(v) => handleField("wedding_budget_estimate", v === "" ? null : Number(v))}
              />
            </EventStudioSection>
          )}

          <EventStudioSection
            icon={<ClipboardList className="w-3.5 h-3.5" />}
            title="Statut"
            subtitle="Étape interne de préparation"
          >
            <select
              value={event.status || "brouillon"}
              onChange={(e) => handleField("status", e.target.value)}
              className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-sm text-white"
            >
              {EVENT_STATUSES.map((s) => (
                <option key={s.key} value={s.key} className="bg-zinc-900">{s.label}</option>
              ))}
            </select>
          </EventStudioSection>

          <EventStudioSection
            icon={<Library className="w-3.5 h-3.5" />}
            title="Bibliothèque préparatoire"
            subtitle="Repères de travail"
          >
            <ul className="space-y-1.5">
              {EVENT_DOCUMENT_LIBRARY.map((d) => (
                <li key={d.key} className="flex items-start gap-2 text-[11px] text-zinc-300">
                  <span className="w-1.5 h-1.5 rounded-full bg-zinc-500 mt-1.5 shrink-0" />
                  <div>
                    <div className="font-medium text-white">{d.label}</div>
                    <div className="text-[10px] text-zinc-500">{d.description}</div>
                  </div>
                </li>
              ))}
            </ul>
            <div className="mt-3 text-[9px] text-zinc-500 italic">
              Repères préparatoires — privés, non opposables. Aucun document officiel n'est généré.
            </div>
          </EventStudioSection>

          <EventStudioSection
            icon={<Lightbulb className="w-3.5 h-3.5" />}
            title="Ce que cette information déclenche"
            subtitle="Cerise propose, vous validez"
            accent="amber"
          >
            <SourcePropagationSection event={event} />
          </EventStudioSection>

          <EventStudioSection
            icon={<LayoutPanelTop className="w-3.5 h-3.5" />}
            title="Surface du canvas"
            subtitle="Point de vue sur l'événement"
            accent="sky"
          >
            <SurfaceSelector event={event} onChange={(v) => handleField("surfaceMode", v)} />
          </EventStudioSection>

          <EventStudioSection
            icon={<Lock className="w-3.5 h-3.5" />}
            title="Visibilité"
            subtitle="Tous les événements restent privés"
            accent="amber"
          >
            <div className="px-3 py-2 rounded-lg bg-amber-500/10 border border-amber-500/30">
              <div className="text-[11px] text-amber-300 font-semibold">Brouillon privé (private_draft)</div>
              <div className="text-[10px] text-amber-200/70 mt-1">
                Phase 2A : tous les événements restent strictement privés. Aucun endpoint public.
              </div>
            </div>
          </EventStudioSection>
        </div>

        <div className="px-4 py-3 border-t border-white/5 bg-white/[0.02] text-[9px] text-zinc-500 italic leading-snug">
          {EVENT_DOCTRINE_LABELS.preparatory} · {EVENT_DOCTRINE_LABELS.human_review} · {EVENT_DOCTRINE_LABELS.no_official}
        </div>
      </aside>
    </>
  );
}

function Field({ label, value, onChange, type = "text", textarea = false }) {
  const className = "w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-sm text-white placeholder:text-zinc-500 focus:outline-none focus:border-white/30";
  return (
    <label className="block">
      <span className="block text-[10px] text-zinc-500 uppercase tracking-wider mb-1">{label}</span>
      {textarea ? (
        <textarea
          value={value || ""}
          onChange={(e) => onChange(e.target.value)}
          rows={3}
          className={className}
        />
      ) : (
        <input
          type={type}
          value={value || ""}
          onChange={(e) => onChange(e.target.value)}
          className={className}
        />
      )}
    </label>
  );
}