import React from "react";
import { Link } from "react-router-dom";

/**
 * TimelineCard — composant visuel pur.
 *
 * Couche 1 (partagée) — aucun import métier.
 * Coque générique de carte d'élément timeline (prestation, événement, etc.).
 *
 * Props :
 * - icon       : composant Lucide React (optionnel)
 * - iconColor  : classe Tailwind pour la couleur de l'icône (ex. "text-aime-red")
 * - title      : titre principal de la carte
 * - subtitle   : sous-titre (date, lieu...)
 * - badge      : { label, tone } — tone ∈ "neutral" | "red" | "emerald" | "amber" | "sky"
 * - rightSlot  : contenu libre à droite (compteur, jauge...)
 * - to         : route interne (rend la carte cliquable via Link)
 * - onClick    : ou callback si pas de route
 */
export default function TimelineCard({
  icon: Icon,
  iconColor = "text-zinc-600",
  title,
  subtitle,
  badge,
  rightSlot,
  to,
  onClick,
}) {
  const inner = (
    <div className="flex items-center gap-3 px-3.5 py-3 bg-white rounded-xl border border-zinc-100 hover:border-zinc-200 hover:shadow-sm transition-all">
      {Icon && (
        <div className={`w-9 h-9 rounded-lg bg-zinc-50 flex items-center justify-center shrink-0 ${iconColor}`}>
          <Icon className="w-4 h-4" />
        </div>
      )}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <div className="text-[13px] font-semibold text-zinc-900 leading-tight truncate">
            {title || <span className="text-zinc-400 italic">Sans titre</span>}
          </div>
          {badge && <Badge label={badge.label} tone={badge.tone} />}
        </div>
        {subtitle && (
          <div className="text-[11px] text-zinc-500 mt-0.5 leading-snug truncate">{subtitle}</div>
        )}
      </div>
      {rightSlot && <div className="shrink-0">{rightSlot}</div>}
    </div>
  );

  if (to) {
    return (
      <Link to={to} className="block">
        {inner}
      </Link>
    );
  }
  if (onClick) {
    return (
      <button type="button" onClick={onClick} className="block w-full text-left">
        {inner}
      </button>
    );
  }
  return inner;
}

function Badge({ label, tone = "neutral" }) {
  const toneMap = {
    neutral: "bg-zinc-100 text-zinc-700",
    red: "bg-aime-red/10 text-aime-red",
    emerald: "bg-emerald-100 text-emerald-700",
    amber: "bg-amber-100 text-amber-700",
    sky: "bg-sky-100 text-sky-700",
  };
  return (
    <span
      className={`text-[9px] tracking-wider uppercase font-semibold px-1.5 py-0.5 rounded ${
        toneMap[tone] || toneMap.neutral
      }`}
    >
      {label}
    </span>
  );
}