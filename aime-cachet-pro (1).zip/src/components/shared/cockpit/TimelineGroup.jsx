import React from "react";

/**
 * TimelineGroup — composant visuel pur.
 *
 * Couche 1 (partagée) — aucun import métier.
 * Header de groupe (mois, année, ou label libre) + slot enfants pour les cartes.
 *
 * Props :
 * - label    : libellé principal du groupe (ex. "Mai 2026")
 * - sublabel : libellé secondaire à droite (ex. "3 événements")
 * - children : cartes du groupe (généralement des TimelineCard)
 */
export default function TimelineGroup({ label, sublabel, children }) {
  return (
    <div className="space-y-2">
      {(label || sublabel) && (
        <div className="flex items-baseline justify-between px-1 pb-1 border-b border-zinc-100">
          {label && (
            <div className="text-[11px] tracking-[0.24em] text-zinc-500 font-semibold uppercase">
              {label}
            </div>
          )}
          {sublabel && (
            <div className="text-[10px] text-zinc-400 tabular-nums">{sublabel}</div>
          )}
        </div>
      )}
      <div className="space-y-2">{children}</div>
    </div>
  );
}