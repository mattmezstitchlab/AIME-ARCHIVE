import React from "react";

/**
 * CockpitTimelineLayout — composant visuel pur.
 *
 * Couche 1 (partagée) — aucun import métier.
 * Layout responsive : cockpit (gauche) + timeline (droite) sur desktop,
 * empilés verticalement sur mobile (cockpit haut, timeline bas).
 *
 * Props :
 * - cockpit   : node — contenu de la colonne cockpit (hero, jalons, suggestions)
 * - timeline  : node — contenu de la colonne timeline (groupes de cartes)
 * - header    : node — bandeau optionnel en haut (titre, actions)
 */
export default function CockpitTimelineLayout({ cockpit, timeline, header }) {
  return (
    <div className="min-h-screen bg-zinc-50">
      {header && (
        <div className="max-w-6xl mx-auto px-4 md:px-8 pt-20 md:pt-24 pb-4">{header}</div>
      )}
      <div className="max-w-6xl mx-auto px-4 md:px-8 pb-20">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Colonne cockpit — empilé sur mobile, gauche sur desktop */}
          <aside className="lg:col-span-5 space-y-4">{cockpit}</aside>

          {/* Colonne timeline — bas sur mobile, droite sur desktop */}
          <main className="lg:col-span-7 space-y-6">{timeline}</main>
        </div>
      </div>
    </div>
  );
}