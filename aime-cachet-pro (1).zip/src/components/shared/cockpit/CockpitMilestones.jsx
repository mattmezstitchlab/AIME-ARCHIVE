import React from "react";
import { Check, Circle, AlertCircle } from "lucide-react";

/**
 * CockpitMilestones — composant visuel pur.
 *
 * Couche 1 (partagée) — aucun import métier.
 * Liste de jalons doctrinaux (par ex. étapes de progression, statuts internes).
 *
 * Props :
 * - title     : titre de la section
 * - milestones: tableau d'objets { key, label, hint, status }
 *               status ∈ "done" | "current" | "todo" | "warning"
 */
export default function CockpitMilestones({ title = "Jalons", milestones = [] }) {
  if (!milestones.length) return null;

  return (
    <div className="bg-white rounded-2xl border border-zinc-100 p-5">
      <div className="text-[10px] tracking-[0.22em] text-zinc-400 font-semibold uppercase mb-4">
        {title}
      </div>
      <ul className="space-y-3">
        {milestones.map((m) => (
          <li key={m.key} className="flex items-start gap-3">
            <MilestoneIcon status={m.status} />
            <div className="flex-1 min-w-0">
              <div
                className={`text-[13px] font-medium leading-tight ${
                  m.status === "done"
                    ? "text-zinc-500 line-through"
                    : m.status === "warning"
                    ? "text-amber-700"
                    : "text-zinc-900"
                }`}
              >
                {m.label}
              </div>
              {m.hint && (
                <div className="text-[11px] text-zinc-500 mt-0.5 leading-snug">{m.hint}</div>
              )}
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

function MilestoneIcon({ status }) {
  if (status === "done") {
    return (
      <div className="w-5 h-5 rounded-full bg-emerald-500 flex items-center justify-center mt-0.5 shrink-0">
        <Check className="w-3 h-3 text-white" strokeWidth={3} />
      </div>
    );
  }
  if (status === "current") {
    return (
      <div className="w-5 h-5 rounded-full bg-aime-red flex items-center justify-center mt-0.5 shrink-0">
        <div className="w-2 h-2 rounded-full bg-white" />
      </div>
    );
  }
  if (status === "warning") {
    return (
      <div className="w-5 h-5 rounded-full bg-amber-100 flex items-center justify-center mt-0.5 shrink-0">
        <AlertCircle className="w-3 h-3 text-amber-600" />
      </div>
    );
  }
  return (
    <div className="w-5 h-5 rounded-full bg-zinc-100 flex items-center justify-center mt-0.5 shrink-0">
      <Circle className="w-3 h-3 text-zinc-300" />
    </div>
  );
}