import React from "react";

/**
 * CockpitHero — composant visuel pur.
 *
 * Couche 1 (partagée) — aucun import métier, aucune entité.
 * Reçoit tout en props. Affiche un compteur central, un eyebrow, un sous-titre,
 * et éventuellement une barre de progression.
 *
 * Props :
 * - eyebrow      : texte court en haut (ex. "AIME 507")
 * - title        : titre / compteur principal (ex. "412 / 507h" ou "3 événements")
 * - subtitle     : sous-titre descriptif
 * - progress     : nombre entre 0 et 100 (optionnel)
 * - accent       : "red" (défaut) | "sky" | "amber"
 * - children     : slot libre sous le titre (badges, mini-cartes)
 */
export default function CockpitHero({
  eyebrow,
  title,
  subtitle,
  progress,
  accent = "red",
  children,
}) {
  const accentMap = {
    red: { text: "text-aime-red", bar: "bg-aime-red" },
    sky: { text: "text-sky-500", bar: "bg-sky-500" },
    amber: { text: "text-amber-500", bar: "bg-amber-500" },
  };
  const a = accentMap[accent] || accentMap.red;
  const clamped = typeof progress === "number" ? Math.max(0, Math.min(100, progress)) : null;

  return (
    <div className="text-center">
      {eyebrow && (
        <div className={`inline-block text-[10px] tracking-[0.24em] font-semibold mb-3 ${a.text}`}>
          {eyebrow}
        </div>
      )}
      {title && (
        <h1 className="font-display font-black text-3xl md:text-5xl lg:text-6xl leading-[1.05] tracking-tight text-zinc-900">
          {title}
        </h1>
      )}
      {subtitle && (
        <p className="mt-3 text-sm md:text-base text-zinc-600 max-w-xl mx-auto leading-relaxed">
          {subtitle}
        </p>
      )}
      {clamped !== null && (
        <div className="mt-6 max-w-md mx-auto">
          <div className="h-1.5 rounded-full bg-zinc-200 overflow-hidden">
            <div
              className={`h-full ${a.bar} transition-all duration-500`}
              style={{ width: `${clamped}%` }}
            />
          </div>
          <div className="mt-1.5 text-[10px] text-zinc-500 tabular-nums">
            {clamped.toFixed(0)} %
          </div>
        </div>
      )}
      {children && <div className="mt-6">{children}</div>}
    </div>
  );
}