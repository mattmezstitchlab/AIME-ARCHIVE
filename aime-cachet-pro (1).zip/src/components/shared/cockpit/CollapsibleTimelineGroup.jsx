import React, { useState } from "react";
import { ChevronDown } from "lucide-react";

/**
 * CollapsibleTimelineGroup — variante repliable de TimelineGroup.
 *
 * Utilisé dans le cockpit Event pour éviter de charger visuellement
 * la page avec une grande liste. Chaque mois devient un accordéon.
 *
 * Props :
 * - label    : libellé principal (ex: "mai 2026")
 * - sublabel : libellé secondaire (ex: "3 événements")
 * - defaultOpen : si true, ouvert au montage (par défaut false)
 * - children : contenu (cards) — rendu uniquement si ouvert
 */
export default function CollapsibleTimelineGroup({
  label,
  sublabel,
  defaultOpen = false,
  children,
}) {
  const [open, setOpen] = useState(defaultOpen);

  return (
    <div className="rounded-xl border border-zinc-200 bg-white overflow-hidden">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-expanded={open}
        className="w-full flex items-center justify-between gap-3 px-4 py-3 hover:bg-zinc-50 transition-colors"
      >
        <div className="flex items-baseline gap-2 min-w-0">
          <span className="text-[11px] tracking-[0.18em] uppercase font-semibold text-zinc-900 truncate">
            {label}
          </span>
          {sublabel && (
            <span className="text-[10px] text-zinc-500 truncate">{sublabel}</span>
          )}
        </div>
        <ChevronDown
          className={`w-4 h-4 text-zinc-400 shrink-0 transition-transform ${
            open ? "rotate-180" : ""
          }`}
        />
      </button>
      {open && <div className="px-3 pb-3 pt-1 space-y-2">{children}</div>}
    </div>
  );
}