import React from "react";
import { Link } from "react-router-dom";
import { ChevronRight } from "lucide-react";

/**
 * CockpitSuggestions — composant visuel pur.
 *
 * Couche 1 (partagée) — aucun import métier.
 * Liste de suggestions cliquables (vers routes internes uniquement).
 *
 * Props :
 * - title       : titre de la section
 * - suggestions : tableau d'objets { key, icon, label, hint, to, onClick }
 *                 icon = composant Lucide React
 *                 to   = route interne (Link)
 *                 onClick = ou fonction si pas de route
 */
export default function CockpitSuggestions({ title = "Suggestions", suggestions = [] }) {
  if (!suggestions.length) return null;

  return (
    <div className="bg-white rounded-2xl border border-zinc-100 p-5">
      <div className="text-[10px] tracking-[0.22em] text-zinc-400 font-semibold uppercase mb-4">
        {title}
      </div>
      <ul className="space-y-2">
        {suggestions.map((s) => (
          <SuggestionItem key={s.key} suggestion={s} />
        ))}
      </ul>
    </div>
  );
}

function SuggestionItem({ suggestion }) {
  const { icon: Icon, label, hint, to, onClick } = suggestion;
  const content = (
    <>
      {Icon && (
        <div className="w-8 h-8 rounded-lg bg-zinc-100 flex items-center justify-center text-zinc-600 shrink-0">
          <Icon className="w-4 h-4" />
        </div>
      )}
      <div className="flex-1 min-w-0">
        <div className="text-[13px] font-medium text-zinc-900 leading-tight">{label}</div>
        {hint && (
          <div className="text-[11px] text-zinc-500 mt-0.5 leading-snug truncate">{hint}</div>
        )}
      </div>
      <ChevronRight className="w-4 h-4 text-zinc-300 shrink-0" />
    </>
  );

  const baseCls =
    "w-full flex items-center gap-3 px-2 py-2 rounded-lg hover:bg-zinc-50 transition-colors text-left";

  if (to) {
    return (
      <li>
        <Link to={to} className={baseCls}>
          {content}
        </Link>
      </li>
    );
  }
  return (
    <li>
      <button type="button" onClick={onClick} className={baseCls}>
        {content}
      </button>
    </li>
  );
}