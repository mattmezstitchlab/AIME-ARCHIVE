import React from "react";
import { FileText, Mail, LayoutPanelTop, Sparkles, ArrowDown } from "lucide-react";

/**
 * Section "Concept" — Une source, plusieurs surfaces.
 *
 * Pose la doctrine CanvasCore d'AIME :
 *  - Une seule saisie nourrit plusieurs supports
 *  - Aucune répétition, validation humaine
 *  - Brouillon privé, non opposable
 *
 * Style cosmonaute : fond noir étoilé, planète/orbite douce,
 * pas de rouge dominant — palette ivoire / sky pour les projections.
 */
export default function ConceptOneSourceManySurfaces() {
  return (
    <section className="relative overflow-hidden bg-black text-white">
      {/* Fond étoilé subtil */}
      <div
        className="absolute inset-0 opacity-60"
        aria-hidden="true"
        style={{
          backgroundImage:
            "radial-gradient(1px 1px at 12% 18%, rgba(255,255,255,0.55) 50%, transparent 51%)," +
            "radial-gradient(1px 1px at 78% 32%, rgba(255,255,255,0.45) 50%, transparent 51%)," +
            "radial-gradient(1px 1px at 42% 68%, rgba(255,255,255,0.5) 50%, transparent 51%)," +
            "radial-gradient(1.5px 1.5px at 88% 78%, rgba(255,255,255,0.4) 50%, transparent 51%)," +
            "radial-gradient(1px 1px at 22% 88%, rgba(255,255,255,0.35) 50%, transparent 51%)," +
            "radial-gradient(2px 2px at 60% 14%, rgba(255,255,255,0.6) 50%, transparent 51%)",
          backgroundSize: "100% 100%",
        }}
      />
      {/* Halo planète */}
      <div
        className="absolute -right-32 top-20 w-[420px] h-[420px] rounded-full blur-3xl opacity-30"
        style={{ background: "radial-gradient(circle, #ef4444 0%, transparent 70%)" }}
        aria-hidden="true"
      />
      <div
        className="absolute -left-24 bottom-10 w-[340px] h-[340px] rounded-full blur-3xl opacity-20"
        style={{ background: "radial-gradient(circle, #38bdf8 0%, transparent 70%)" }}
        aria-hidden="true"
      />

      <div className="relative max-w-5xl mx-auto px-5 md:px-8 py-20 md:py-28">
        {/* En-tête */}
        <div className="text-center mb-14">
          <div className="inline-block text-[10px] tracking-[0.28em] text-aime-red font-semibold mb-3">
            LA MÉTHODE AIME
          </div>
          <h2 className="font-display font-black text-3xl md:text-5xl tracking-tight leading-tight mb-5">
            Une source.<br />
            <span className="text-white/90">Plusieurs surfaces.</span><br />
            <span className="text-aime-red">Zéro répétition.</span>
          </h2>
          <p className="text-base md:text-lg text-white/70 leading-relaxed max-w-2xl mx-auto">
            Vous saisissez une information <strong className="text-white">une seule fois</strong>.
            AIME la projette sur les supports concernés — fiche, devis, programme, faire-part —
            et vous gardez la main sur chaque projection.
          </p>
        </div>

        {/* Schéma central : 1 source → N surfaces */}
        <div className="relative max-w-3xl mx-auto">
          {/* Source */}
          <div className="flex justify-center">
            <div className="relative">
              <div className="absolute inset-0 rounded-2xl bg-aime-red/30 blur-xl" aria-hidden="true" />
              <div className="relative bg-white text-zinc-900 rounded-2xl px-6 py-5 shadow-2xl border border-white/20">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-aime-red/10 flex items-center justify-center">
                    <Sparkles className="w-5 h-5 text-aime-red" />
                  </div>
                  <div>
                    <div className="text-[9px] tracking-[0.22em] text-zinc-500 font-semibold uppercase">
                      La source
                    </div>
                    <div className="font-display font-bold text-lg">Votre saisie</div>
                  </div>
                </div>
                <div className="mt-3 text-[11px] text-zinc-600 leading-snug">
                  Titre · date · lieu · partenaires · contenu
                </div>
              </div>
            </div>
          </div>

          {/* Flèche descendante animée */}
          <div className="flex justify-center my-6">
            <div className="flex flex-col items-center gap-1">
              <ArrowDown className="w-5 h-5 text-white/40 animate-bounce" strokeWidth={1.5} />
              <div className="text-[9px] tracking-[0.22em] text-white/40 font-semibold uppercase">
                Projection
              </div>
            </div>
          </div>

          {/* Surfaces (projections) */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <SurfaceCard
              icon={FileText}
              label="Fiche A4"
              accent="ivory"
              hint="Document préparatoire"
            />
            <SurfaceCard
              icon={Mail}
              label="Faire-part"
              accent="sky"
              hint="Carte personnalisée"
            />
            <SurfaceCard
              icon={LayoutPanelTop}
              label="Programme"
              accent="amber"
              hint="Déroulé partageable"
            />
          </div>
        </div>

        {/* Principes doctrinaux */}
        <div className="mt-16 grid sm:grid-cols-3 gap-4 max-w-3xl mx-auto">
          <Principle
            number="01"
            title="Vous saisissez une fois"
            text="Pas de double-saisie. La source nourrit toutes les surfaces."
          />
          <Principle
            number="02"
            title="AIME propose"
            text="Cerise détecte les surfaces concernées et vous propose la projection."
          />
          <Principle
            number="03"
            title="Vous validez"
            text="Aucune projection automatique. Chaque support reste sous votre contrôle."
          />
        </div>

        {/* Note doctrinale */}
        <div className="mt-12 text-center">
          <p className="text-[11px] text-white/40 italic max-w-xl mx-auto leading-relaxed">
            Brouillon privé. Préparatoire. Non opposable.
            AIME ne signe, ne scelle et ne transmet rien sans votre validation explicite.
          </p>
        </div>
      </div>
    </section>
  );
}

function SurfaceCard({ icon: Icon, label, accent, hint }) {
  const accentMap = {
    ivory: "bg-white/[0.06] border-white/15 text-white",
    sky: "bg-sky-500/[0.06] border-sky-500/20 text-sky-100",
    amber: "bg-amber-500/[0.06] border-amber-500/20 text-amber-100",
  };
  const iconBg = {
    ivory: "bg-white/10 text-white",
    sky: "bg-sky-500/15 text-sky-300",
    amber: "bg-amber-500/15 text-amber-300",
  };
  return (
    <div className={`rounded-xl border backdrop-blur-sm px-4 py-4 ${accentMap[accent]}`}>
      <div className={`w-9 h-9 rounded-lg flex items-center justify-center mb-3 ${iconBg[accent]}`}>
        <Icon className="w-4 h-4" strokeWidth={1.8} />
      </div>
      <div className="font-display font-bold text-sm leading-tight">{label}</div>
      <div className="text-[10px] text-white/50 mt-1">{hint}</div>
    </div>
  );
}

function Principle({ number, title, text }) {
  return (
    <div className="bg-white/[0.03] border border-white/10 rounded-xl p-4">
      <div className="text-[10px] tracking-[0.22em] text-aime-red font-bold mb-2">{number}</div>
      <div className="font-display font-bold text-sm text-white mb-1.5 leading-tight">{title}</div>
      <p className="text-[11px] text-white/60 leading-relaxed">{text}</p>
    </div>
  );
}