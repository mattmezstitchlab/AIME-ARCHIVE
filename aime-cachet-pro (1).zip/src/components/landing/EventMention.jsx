import React from "react";
import { Link } from "react-router-dom";
import { ArrowRight, Sparkles } from "lucide-react";

/**
 * Mention AIME Event sur la landing.
 *
 * Section courte, doctrinale : la méthode "une source, plusieurs surfaces"
 * s'étend aux événements privés (mariage, concert, festival…) en mode
 * brouillon strictement non opposable. Phase 2A : private_draft only.
 */
export default function EventMention() {
  return (
    <section className="bg-zinc-50 border-y border-zinc-100">
      <div className="max-w-5xl mx-auto px-5 md:px-8 py-16 md:py-20">
        <div className="grid md:grid-cols-[1fr_auto] gap-8 items-center">
          <div>
            <div className="inline-flex items-center gap-1.5 text-[10px] tracking-[0.22em] text-aime-red font-semibold mb-3">
              <Sparkles className="w-3 h-3" />
              NOUVEAU · AIME EVENT
            </div>
            <h2 className="font-display font-black text-2xl md:text-4xl tracking-tight text-zinc-900 mb-3">
              La même méthode,<br />pour vos événements privés.
            </h2>
            <p className="text-sm md:text-base text-zinc-600 leading-relaxed max-w-xl">
              Mariage, concert, festival, conférence, soirée privée… AIME Event
              applique la même doctrine « une source, plusieurs surfaces » à la
              préparation de vos événements : un seul brouillon, plusieurs
              rendus (faire-part, programme, fiche, affiche).
            </p>
            <p className="text-[11px] text-zinc-400 italic mt-3 max-w-xl">
              Strictement préparatoire et privé. Aucun document opposable, aucune
              transmission externe.
            </p>
          </div>

          <Link
            to="/events"
            className="inline-flex items-center gap-2 bg-zinc-900 hover:bg-black text-white font-medium px-5 py-3 rounded-full transition-colors shrink-0"
          >
            Découvrir AIME Event
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </div>
    </section>
  );
}