# AIME Event — Architecture miroir Cachet · Lot B (freeze)

**Statut** : 🟢 Implémenté et figé.
**Date** : 2026-05-24
**Référence** : `docs/aime-event-architecture-cachet-mirror-v0-cadrage.md` (Lot A)
**Phase de projet** : 2A maintenue.

---

## 1. Objet

Mise en place de la **couche 1 (partagée)** définie au Lot A.
Composants visuels purs dans `components/shared/cockpit/` — destinés à être consommés
indépendamment par la couche Cachet (existante) et la couche Event (à venir au Lot C).

---

## 2. Fichiers livrés

| Fichier | Rôle | Lignes |
|---|---|---|
| `components/shared/cockpit/CockpitHero.jsx` | Compteur central + eyebrow + sous-titre + progress | ~75 |
| `components/shared/cockpit/CockpitMilestones.jsx` | Liste de jalons (done/current/todo/warning) | ~85 |
| `components/shared/cockpit/CockpitSuggestions.jsx` | Liste de suggestions cliquables (Link ou onClick) | ~70 |
| `components/shared/cockpit/TimelineGroup.jsx` | Header de groupe (mois) + slot enfants | ~30 |
| `components/shared/cockpit/TimelineCard.jsx` | Coque générique de carte timeline | ~95 |
| `components/shared/cockpit/CockpitTimelineLayout.jsx` | Layout responsive cockpit + timeline | ~30 |

---

## 3. Garde-fous respectés

### 3.1 Pureté visuelle (Lot A §3 — couche 1)

🔒 **Zéro import depuis `entities/`** — vérifié dans les 6 fichiers.
🔒 **Zéro import depuis `lib/intermittent507.js`, `lib/event-core/*`, `lib/aimeData.js`** — vérifié.
🔒 **Zéro import depuis `components/aime/*` ni `components/event/*`** — vérifié.
🔒 Seuls imports autorisés : `react`, `react-router-dom` (uniquement `Link`), `lucide-react`.

### 3.2 Aucun impact sur l'existant

🔒 **Aucun fichier existant modifié.**
🔒 Le moteur 507 (`Dashboard507`, `MesPrestations`, `Timeline`, `AimeMachine`) reste **intact**.
🔒 La couche Event existante (`Events`, `EventsType`, `EventFicheView`, `EventStudio`) reste **intacte**.
🔒 `App.jsx` non touché — aucune route nouvelle à ce stade.

### 3.3 Phase 2A maintenue

🔒 Aucun composant ne mentionne Cachet, Event, 507, EventRecord ou Prestation.
🔒 Aucun composant n'introduit de scellement, hash, PDF officiel, envoi externe.
🔒 Les composants sont **agnostiques** — ils ne peuvent pas violer la doctrine puisqu'ils ne
   connaissent aucun domaine métier.

---

## 4. Interface des composants

### 4.1 CockpitHero

```
<CockpitHero
  eyebrow="AIME 507"
  title="412 / 507h"
  subtitle="80 % atteints"
  progress={80}
  accent="red" | "sky" | "amber"
>
  {/* slot libre */}
</CockpitHero>
```

### 4.2 CockpitMilestones

```
<CockpitMilestones
  title="Jalons"
  milestones={[
    { key, label, hint, status: "done" | "current" | "todo" | "warning" }
  ]}
/>
```

### 4.3 CockpitSuggestions

```
<CockpitSuggestions
  title="Suggestions"
  suggestions={[
    { key, icon: LucideIcon, label, hint, to } |
    { key, icon, label, hint, onClick }
  ]}
/>
```

### 4.4 TimelineGroup

```
<TimelineGroup label="Mai 2026" sublabel="3 événements">
  {/* TimelineCard list */}
</TimelineGroup>
```

### 4.5 TimelineCard

```
<TimelineCard
  icon={LucideIcon}
  iconColor="text-aime-red"
  title="..."
  subtitle="..."
  badge={{ label, tone: "neutral|red|emerald|amber|sky" }}
  rightSlot={<...>}
  to="/route"
/>
```

### 4.6 CockpitTimelineLayout

```
<CockpitTimelineLayout
  header={<...>}
  cockpit={<...>}
  timeline={<...>}
/>
```

Responsive : empilé en colonne sur mobile (`<lg`), côte-à-côte 5/7 colonnes à partir de `lg:`.

---

## 5. Non testé à ce stade

Aucun consommateur ne référence encore ces composants. La validation visuelle interviendra
au **Lot C** lorsque `EventsCockpit` les consommera.

---

## 6. Rollback

Suppression des 6 fichiers `components/shared/cockpit/*` et du présent freeze.
Aucun autre fichier n'est impacté — rollback strictement non destructif.

---

## 7. Prochaine étape — Lot C

`pages/EventsCockpit.jsx` + `components/event/cockpit/*` consommeront ces 6 composants pour
construire la page cockpit + timeline d'AIME Event.

**Lot C démarre sur validation explicite de ce freeze.**

---

**Fin du Lot B.**