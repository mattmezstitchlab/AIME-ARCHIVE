# 🧊 Freeze — Surface Shared : DraftWatermark + DoctrineFooter

**Statut** : ✅ Figé
**Date de freeze** : 23 mai 2026
**Phase** : AIME Event · Phase 2B.1 — Préparatifs graphiques partagés
**Périmètre** : Extraction non destructive de deux éléments visuels d'`EventFichePaper`
en composants partagés réutilisables, sans aucune modification visuelle perceptible.

---

## 1. Objet du freeze

Ce document fige l'**extraction non destructive** de deux blocs visuels jusqu'alors inline
dans `EventFichePaper.jsx` :

- le filigrane "BROUILLON" (watermark doctrinal),
- le footer doctrinal (mentions préparatoires + "ne constitue pas un document officiel").

Ces deux blocs deviennent des **composants partagés figés** sous `components/event/surface/`,
prêts à être réutilisés par de futures surfaces visibles (faire_part, programme, billet, etc.)
**sans qu'aucune surface visible ne soit encore créée par cette micro-action**.

Le rendu de la fiche A4 (`EventFichePaper`) reste **strictement identique** caractère par
caractère, classe par classe.

---

## 2. Objectif

| Cible | Détail |
|---|---|
| Mutualisation graphique | Préparer la réutilisation des deux éléments doctrinaux universels |
| Identité visuelle | Garantir que toute future surface affiche exactement le même watermark et le même footer |
| Cohérence doctrinale | Centraliser le wording préparatoire / non opposable en un seul endroit |
| Neutralité | Zéro changement visuel pour l'utilisateur final |

---

## 3. Fichiers créés (2)

| Fichier | Rôle | Statut |
|---|---|---|
| `components/event/surface/DraftWatermark.jsx` | Composant figé reproduisant le filigrane "BROUILLON" à l'identique | Créé · figé |
| `components/event/surface/DoctrineFooter.jsx` | Composant figé reproduisant le footer doctrinal à l'identique | Créé · figé |

### 3.1 Contrat des composants

Les deux composants sont **volontairement sans props** en v1 — aucun paramètre exposé.
Cette absence d'API garantit l'identité visuelle absolue avec l'inline original.

```jsx
<DraftWatermark />        // aucun paramètre
<DoctrineFooter />        // aucun paramètre
```

---

## 4. Fichier modifié (1)

| Fichier | Modifications |
|---|---|
| `components/event/EventFichePaper.jsx` | 3 ops via `anchor_replace` |

### 4.1 Détail des 3 ops

| # | Op | Effet |
|---|---|---|
| 1 | Ajout d'1 ligne d'import pour `DraftWatermark` et `DoctrineFooter` | Imports ajoutés en tête du fichier |
| 2 | Substitution du bloc inline du watermark par `<DraftWatermark />` | 5 lignes inline → 1 ligne JSX |
| 3 | Substitution du bloc inline du footer par `<DoctrineFooter />` | 10 lignes inline → 1 ligne JSX |

Aucune autre modification de `EventFichePaper.jsx`. Le reste du composant (header, sections,
bloc conditionnel mariage) est **strictement intact**.

---

## 5. Preuve d'équivalence visuelle

### 5.1 DraftWatermark — diff visuel = ∅

| Propriété | Avant (inline) | Après (`<DraftWatermark />`) |
|---|---|---|
| Texte | `BROUILLON` | `BROUILLON` |
| Conteneur | `absolute inset-0 pointer-events-none flex items-center justify-center` | **identique** |
| `aria-hidden` | ✅ | ✅ |
| Taille | `text-[100px]` | `text-[100px]` |
| Graisse | `font-black` | `font-black` |
| Letter-spacing | `tracking-widest` | `tracking-widest` |
| Opacité | `opacity-[0.05]` | `opacity-[0.05]` |
| Sélection | `select-none` | `select-none` |
| Rotation | `rotate-[-25deg]` | `rotate-[-25deg]` |
| Wrap | `whitespace-nowrap` | `whitespace-nowrap` |
| Couleur | `text-zinc-900` | `text-zinc-900` |

### 5.2 DoctrineFooter — diff visuel = ∅

| Propriété | Avant (inline) | Après (`<DoctrineFooter />`) |
|---|---|---|
| Conteneur position | `absolute bottom-8 left-0 right-0 px-[18mm]` | **identique** |
| Séparateur | `border-t border-zinc-200 pt-3 text-center` | **identique** |
| Ligne 1 typo | `text-[9px] text-zinc-500 tracking-wider uppercase` | **identique** |
| Ligne 1 wording | `{preparatory} · {human_review}` | **identique** (même source `EVENT_DOCTRINE_LABELS`) |
| Ligne 2 typo | `text-[8px] text-zinc-400 italic mt-1` | **identique** |
| Ligne 2 wording | `{no_official} — ne constitue pas un document officiel.` | **identique** |

### 5.3 Conclusion

Les deux composants extraits reproduisent **caractère par caractère** et **classe par classe**
les blocs inline d'origine. Le DOM rendu est strictement équivalent. Aucune divergence
de marge, padding, opacité, rotation, typographie, couleur ou wording n'a été introduite.

---

## 6. Preuve qu'aucune surface visible n'a été créée

| Vérification | Statut |
|---|---|
| Nouveau composant Hero | ❌ Non |
| Nouveau composant Faire-part | ❌ Non |
| Nouveau composant Billet | ❌ Non |
| Nouveau composant Programme | ❌ Non |
| Nouveau composant Affiche / Mini-site / Web page / Carte / Section | ❌ Non |
| `SurfaceSwitcher` créé | ❌ Non |
| `SurfaceFrame` actif créé | ❌ Non |
| Nouvelle route ajoutée à `App.jsx` | ❌ Non |
| Nouveau bouton dans la TopBar `EventFicheView` | ❌ Non |
| Nouvelle section dans `EventStudio` | ❌ Non |
| Modification de `EventCreateButton` | ❌ Non |
| Modification de `EventFicheVerso` | ❌ Non |

Les deux composants extraits sont **utilisés uniquement** par `EventFichePaper`. Aucun
autre fichier ne les importe en v1.

---

## 7. Preuve que le rail Canvas Surface n'a pas été modifié

| Élément du rail | Statut |
|---|---|
| `lib/event-core/surfaces/index.js` | ✅ Non touché |
| `SURFACE_REGISTRY` | ✅ Inchangé — 1 seule entrée active (`document → EventFichePaper`) |
| `DEFAULT_SURFACE_MODE` | ✅ Inchangé (`"document"`) |
| `resolveSurfaceRenderer()` | ✅ Inchangée |
| `isSurfaceActive()` | ✅ Inchangée |
| `entities/EventRecord.json` (champ `surfaceMode`) | ✅ Non touché |
| `pages/EventFicheView.jsx` | ✅ Non touché |

---

## 8. Preuve qu'AIME Cachet reste intact

| Périmètre AIME Cachet | Statut |
|---|---|
| `entities/Prestation.json`, `HistoryEvent.json`, `Wallet.json`, `AssistantReminder.json` | ✅ Non touchés |
| `functions/sealCachet`, `functions/verifyCachet` | ✅ Non touchés |
| `lib/verificationHash.js`, `HASHED_FIELDS` | ✅ Non touchés |
| `pages/FicheView.jsx`, `MesPrestations.jsx`, `Dashboard507.jsx`, `Verify.jsx`, `AimeCachet.jsx` | ✅ Non touchés |
| Tous les templates `*Paper.jsx` AIME Cachet | ✅ Non touchés |
| Routes `/app`, `/prestations`, `/507`, `/fiche/:id`, `/verify/:cachetCode` | ✅ Non touchées |
| Aucune backend function créée ou modifiée | ✅ Confirmé |
| Aucun PDF, hash, scellement, endpoint public, RSVP, module invités | ✅ Confirmé |

---

## 9. Rollback

### 9.1 Rollback complet (< 30 secondes · 3 actions)

1. **`components/event/EventFichePaper.jsx`** : restaurer les 3 ops à l'état pré-extraction :
   - retirer les 2 lignes d'import (`DraftWatermark`, `DoctrineFooter`),
   - réinjecter le bloc inline du watermark à la place de `<DraftWatermark />`,
   - réinjecter le bloc inline du footer doctrinal à la place de `<DoctrineFooter />`.
2. **`components/event/surface/DraftWatermark.jsx`** : supprimer le fichier.
3. **`components/event/surface/DoctrineFooter.jsx`** : supprimer le fichier.

### 9.2 Rollback partiel

- Continuer à utiliser les deux composants extraits dans `EventFichePaper` mais empêcher
  toute autre surface future de les importer : **aucun verrou technique ne l'impose**, le
  verrou est uniquement doctrinal (cf. §10).

### 9.3 Garantie

Les blocs extraits étant strictement équivalents à leurs versions inline, le rollback est
**indistinguable** de l'état post-action sur le plan visuel. Aucun EventRecord n'est affecté.
Aucun fichier AIME Cachet n'est concerné.

---

## 10. Interdictions pour la suite (verrous permanents tant que ce freeze est en vigueur)

Aucune des évolutions suivantes ne peut être ajoutée au périmètre `DraftWatermark` /
`DoctrineFooter` sans un nouveau freeze daté :

- ❌ Ajout de props ou de variantes visuelles aux deux composants extraits
- ❌ Modification du texte "BROUILLON" du watermark
- ❌ Modification du wording doctrinal du footer
- ❌ Modification de la rotation, opacité, taille, couleur ou typographie
- ❌ Suppression ou désactivation conditionnelle de l'un des deux composants
- ❌ Réutilisation par une surface visible **avant** que celle-ci ait fait l'objet d'un freeze dédié
- ❌ Extraction d'autres blocs inline d'`EventFichePaper` sans nouvelle micro-action freezée
- ❌ Modification de `EventFicheView`, `EventFicheVerso`, `EventStudio`, `EventCreateButton`,
  `EventRecord`, ou du registre `lib/event-core/surfaces/index.js` au prétexte de cette couche
- ❌ Création de PDF, hash, scellement, endpoint public, RSVP, module invités
- ❌ Modification de toute partie d'AIME Cachet

---

## 11. Fichiers de référence (snapshot logique)

```
components/event/surface/DraftWatermark.jsx
  └─ Composant sans props
     └─ Reproduit à l'identique le bloc <div absolute inset-0 ...><span ...>BROUILLON</span></div>

components/event/surface/DoctrineFooter.jsx
  └─ Composant sans props
     ├─ Import EVENT_DOCTRINE_LABELS depuis @/lib/event-core/verticals/event
     └─ Reproduit à l'identique le bloc <div absolute bottom-8 ...> footer doctrinal </div>

components/event/EventFichePaper.jsx
  ├─ +2 imports en tête
  ├─ <DraftWatermark />   (à la place du bloc inline filigrane)
  └─ <DoctrineFooter />   (à la place du bloc inline footer doctrinal)
```

---

## 12. Recommandation — prochaine étape

> **Prochaine étape recommandée : cadrage en lecture seule de la première surface visible —
> `faire_part`.**
>
> Objectif : produire un rapport de cadrage uniquement, **sans coder**, listant :
> - format envisagé (A5 portrait, 148×210mm),
> - composants à créer (`SurfaceFairePart.jsx`, `SurfaceFairePartVerso.jsx` ?),
> - réutilisation des composants partagés (`DraftWatermark`, `DoctrineFooter`),
> - données utilisées (toutes existantes : `title`, `date`, `location`, `description`, `wedding_*`),
> - où placer le `SurfaceSwitcher` (TopBar ? Studio ?),
> - intégration avec le rail Canvas Surface existant (passage de `status: "planned"`
>   à `status: "active"` pour la clé `faire_part`),
> - garanties doctrinales (aucun PDF, aucun hash, aucun endpoint public, aucun RSVP,
>   aucun module invités, watermark + footer présents, AIME Cachet intact),
> - risques et rollback,
> - première micro-action sûre possible (probablement : créer `SurfaceFairePart` mais le
>   laisser non sélectionnable, branchement dans le registre seulement).
>
> **Aucune ligne de code ne doit être écrite pour cette étape de cadrage.**

---

**Freeze signé** : 23 mai 2026 · AIME Event Phase 2B.1 · Surface Shared (DraftWatermark + DoctrineFooter)
**Prochain freeze requis avant** : toute évolution du périmètre listé en §10