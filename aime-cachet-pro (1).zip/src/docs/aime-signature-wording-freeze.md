# Freeze documentaire — Clarification vocabulaire « Signature »

**Date** : 23 mai 2026
**Type** : micro-action validée, exécutée, gelée
**Phase** : post-audit `/fiche/:id`, hors Phase 2 EventCore
**Statut** : ✅ Appliquée — aucun rollback nécessaire

---

## 1. Objectif de la correction

Aligner le vocabulaire affiché à l'utilisateur sur la **doctrine AIME CanvasCore §7** :

> AIME prépare. L'utilisateur vérifie. L'organisme officiel valide.
> Aucune affirmation administrative, aucune signature électronique qualifiée, aucune valeur opposable.

Le terme **« Signature électronique »** prêtait à confusion : il pouvait laisser croire à l'utilisateur qu'AIME produit une signature au sens du **règlement eIDAS** (signature électronique simple, avancée ou qualifiée), ce qui **n'est pas le cas**. AIME ne fournit qu'un **dessin manuscrit visuel** apposé sur un brouillon préparatoire.

La correction supprime cette ambiguïté en :
1. Renommant le libellé pour décrire précisément ce qui se passe techniquement ;
2. Ajoutant un disclaimer court qui exclut explicitement la qualification eIDAS.

---

## 2. Fichiers modifiés

| # | Fichier | Nature de la modification | Lignes affectées |
|---|---|---|---|
| 1 | `components/aime/fiche/SignaturePad.jsx` | Titre de la modale + disclaimer ajouté | 1 titre modifié + 1 `<p>` ajouté |
| 2 | `pages/FicheView.jsx` | Label sous la signature apposée sur le papier + disclaimer ajouté | 1 label modifié + 1 `<div>` ajouté |

**Total** : 2 fichiers, 2 opérations `anchor_replace`, ~4 lignes affectées.

---

## 3. Ancien libellé

### 3.1 `SignaturePad.jsx` (titre de la modale de capture)

```jsx
<h3 className="text-zinc-900 font-semibold text-base">Signature électronique</h3>
<p className="text-[11px] text-zinc-500 mt-0.5">Signez avec le doigt ou la souris</p>
```

### 3.2 `FicheView.jsx` (label affiché sous la signature sur le papier)

```jsx
<div className="text-[8px] tracking-wider text-zinc-600 uppercase mt-1 text-center">
  Signature électronique
</div>
```

---

## 4. Nouveau libellé

### 4.1 `SignaturePad.jsx` (titre de la modale de capture)

```jsx
<h3 className="text-zinc-900 font-semibold text-base">Signature manuscrite visuelle</h3>
<p className="text-[11px] text-zinc-500 mt-0.5">Signez avec le doigt ou la souris</p>
<p className="text-[10px] text-zinc-400 italic mt-1">
  Cette signature ne vaut pas signature électronique qualifiée.
</p>
```

### 4.2 `FicheView.jsx` (label affiché sous la signature sur le papier)

```jsx
<div className="text-[8px] tracking-wider text-zinc-600 uppercase mt-1 text-center">
  Signature manuscrite visuelle
</div>
<div className="text-[7px] text-zinc-400 italic mt-0.5 text-center">
  Cette signature ne vaut pas signature électronique qualifiée.
</div>
```

---

## 5. Disclaimer ajouté

**Texte exact (identique sur les deux emplacements)** :

> Cette signature ne vaut pas signature électronique qualifiée.

**Caractéristiques visuelles** :
- Style : italique
- Couleur : gris discret (`text-zinc-400`)
- Taille : 10px en modale, 7px sur le papier (cohérent avec les autres mentions légales déjà affichées)
- Positionnement : juste sous le titre / le label, pas en bandeau intrusif

**Intention** : être lisible mais non envahissant — l'utilisateur voit la mention sans qu'elle parasite l'expérience de signature.

---

## 6. Preuve qu'aucune logique n'a été modifiée

### 6.1 `SignaturePad.jsx`

| Élément | État |
|---|---|
| Refs canvas (`canvasRef`, `drawingRef`, `lastPosRef`) | ✅ Identiques |
| State `hasSignature` | ✅ Identique |
| Initialisation du canvas (dimensions 800×300, `lineWidth: 2.5`, `strokeStyle: "#0F0F0F"`, `lineCap: "round"`) | ✅ Identique |
| Handlers `getCoords`, `start`, `draw`, `stop`, `clear` | ✅ Identiques |
| Handler `apply()` → `canvas.toDataURL("image/png")` → `onApply(dataUrl)` | ✅ Identique |
| Bindings événements souris (`onMouseDown`, `onMouseMove`, `onMouseUp`, `onMouseLeave`) | ✅ Identiques |
| Bindings événements tactiles (`onTouchStart`, `onTouchMove`, `onTouchEnd`) | ✅ Identiques |
| Props acceptées (`open`, `onClose`, `onApply`) | ✅ Identiques |
| Imports React + lucide-react | ✅ Identiques |
| Boutons d'action (Effacer / Annuler / Apposer) | ✅ Identiques |

### 6.2 `FicheView.jsx`

| Élément | État |
|---|---|
| State `signature`, `signaturePadOpen` | ✅ Identiques |
| Handler `setSignature(dataUrl)` au callback `onApply` | ✅ Identique |
| Position absolute (`bottom-24 right-12 z-20 pointer-events-none`) | ✅ Identique |
| Balise `<img src={signature} alt="signature" className="w-[140px] opacity-90" />` | ✅ Identique |
| Tous les autres composants importés (14 templates `*Paper`, Studio, ToolPalette, etc.) | ✅ Identiques |
| `useEffect` de chargement de la prestation | ✅ Identique |
| `useEffect` de persistance débouncée de `custom_notes` | ✅ Identique |
| Calculs de `paperScale` | ✅ Identiques |
| Logique recto/verso (`flipped`) | ✅ Identique |

### 6.3 Vérifications transverses

| Vérification | Résultat |
|---|---|
| Aucun import ajouté | ✅ Confirmé |
| Aucun import supprimé | ✅ Confirmé |
| Aucune dépendance npm modifiée | ✅ Confirmé |
| Aucun nouveau state React | ✅ Confirmé |
| Aucun nouveau handler | ✅ Confirmé |
| Aucun appel SDK Base44 ajouté ou modifié | ✅ Confirmé |
| Aucun appel backend ajouté ou modifié | ✅ Confirmé |
| Aucun champ d'entité touché | ✅ Confirmé |
| Le `dataURL` produit reste strictement identique | ✅ Confirmé (canvas non modifié) |

**Conclusion** : les modifications sont **strictement textuelles + JSX additif** (2 balises `<p>`/`<div>` ajoutées pour les disclaimers, 2 chaînes de caractères reformulées).

---

## 7. Éléments explicitement NON touchés

### 7.1 Cœur de scellement

- ❌ `lib/verificationHash.js` — intact
- ❌ `HASHED_FIELDS` (les 8 champs figés) — intact
- ❌ `computeVerificationHash()` — intact
- ❌ `hashesMatch()` — intact
- ❌ `functions/sealCachet` — intact
- ❌ `functions/verifyCachet` — intact
- ❌ `components/aime/fiche/SealButton` — intact
- ❌ `components/aime/verify/HashCheckBadge` — intact

### 7.2 Génération PDF

- ❌ `lib/ficheGenerator.js` — intact
- ❌ Watermark PDF — intact
- ❌ Disclaimers PDF — intacts
- ❌ Fonction `drawVerifyQR` — intacte
- ❌ Footer PDF + mentions affiliation — intacts

### 7.3 Templates documentaires

- ❌ Aucun des 14 templates `*Paper.jsx` modifié
- ❌ `FichePaper`, `DevisPaper`, `NoteHonorairesPaper`, `RecuPaper`, `PresencePaper`, `CessionPaper`, `FraisPaper`, `DpaePaper`, `AemPaper`, `AttPePaper`, `GusoPaper`, `CddUPaper`, `CessionDroitsPaper`, `AvenantPaper` — tous intacts

### 7.4 Entités et données

- ❌ Entité `Prestation` — schéma intact
- ❌ Champ `verification_hash` — intact
- ❌ Champ `verification_hash_at` — intact
- ❌ Champ `cachet_code` — intact
- ❌ Champ `custom_notes` — intact
- ❌ Aucune migration de données
- ❌ Aucun renommage de champ

### 7.5 Routes et navigation

- ❌ `App.jsx` — intact
- ❌ Les 12 routes existantes — identiques
- ❌ `/verify/:cachetCode` (page publique) — intacte
- ❌ Aucun nouveau lien ajouté

### 7.6 Cockpit 507 et intermittence

- ❌ `lib/intermittent507.js` — intact
- ❌ `pages/Dashboard507` — intact
- ❌ Coefficients Unédic — intacts

### 7.7 Studio et UX adjacente

- ❌ `StudioPanel` et ses 5 sections — intacts
- ❌ `ToolPalette` (logique des boutons) — intacte
- ❌ `SaveMenu` (PDF / Cloud / Partage) — intact
- ❌ `StampDialog` — intact
- ❌ `DocPicker` — intact
- ❌ `FicheTopBar` — intact
- ❌ `FicheVerso` — intact
- ❌ `QRBadge` — intact

### 7.8 Architecture future

- ⛔ **Phase 2 EventCore : NON démarrée**
- ⛔ **Aucune verticale créée** (ni mariage, ni festival, ni conférence)
- ⛔ **Aucun nouveau document ajouté** à la bibliothèque
- ⛔ **Aucun nouveau composant générique extrait**
- ⛔ Le dossier `lib/event-core/` reste passif et inchangé

---

## 8. Rollback

Rollback **trivial** — 2 `anchor_replace` inversés.

### 8.1 Annuler `SignaturePad.jsx`

```
Remplacer :
  <h3>Signature manuscrite visuelle</h3>
  <p className="text-[11px]">Signez avec le doigt ou la souris</p>
  <p className="text-[10px] italic">Cette signature ne vaut pas signature électronique qualifiée.</p>

Par :
  <h3>Signature électronique</h3>
  <p className="text-[11px]">Signez avec le doigt ou la souris</p>
```

### 8.2 Annuler `FicheView.jsx`

```
Remplacer :
  <div className="text-[8px]">Signature manuscrite visuelle</div>
  <div className="text-[7px] italic">Cette signature ne vaut pas signature électronique qualifiée.</div>

Par :
  <div className="text-[8px]">Signature électronique</div>
```

### 8.3 Caractéristiques du rollback

| Aspect | Valeur |
|---|---|
| Temps estimé | < 30 secondes |
| Risque de régression | 🟢 Nul |
| Données affectées | 🟢 Aucune |
| Fiches déjà créées | 🟢 Inchangées (les signatures déjà apposées ne sont pas persistées sur l'entité, donc rien à migrer) |
| Hash existants | 🟢 Inchangés (la signature n'a jamais fait partie des `HASHED_FIELDS`) |
| PDF déjà générés | 🟢 Inchangés (export client-side ponctuel) |

---

## 9. Lien avec la doctrine AIME CanvasCore §7

La doctrine **AIME CanvasCore** (cf. `docs/aime-canvascore-doctrine.md`) établit en §7 les **invariants juridiques** qui protègent AIME comme moteur préparatoire et **interdisent toute affirmation administrative**.

### 9.1 Principes §7 concernés

- **§7.1 — Préparation, jamais opposabilité** : AIME prépare des brouillons, ne produit jamais de pièce officielle.
- **§7.2 — Le hash est technique, jamais administratif** : il atteste de la cohérence d'un fichier, pas de la validité d'une déclaration.
- **§7.3 — Le scellement n'est pas une certification** : vocabulaire neutre obligatoire (« empreinte technique », « cohérence technique »).
- **§7.4 — La signature est manuscrite visuelle, pas électronique qualifiée** : AIME ne fournit qu'un dessin apposé sur un brouillon ; il ne produit ni signature avancée ni signature qualifiée au sens eIDAS.
- **§7.5 — L'utilisateur reste seul responsable** des déclarations qu'il transmet aux organismes officiels.

### 9.2 Conformité après correction

| Principe §7 | Avant correction | Après correction |
|---|---|---|
| §7.4 — Signature non qualifiée | ⚠️ Ambigu (« Signature électronique » sans précision) | ✅ Conforme (« Signature manuscrite visuelle » + disclaimer eIDAS explicite) |
| §7.1, §7.2, §7.3, §7.5 | ✅ Déjà conformes | ✅ Toujours conformes (non touchés) |

### 9.3 Vocabulaire désormais en place

| Brique | Vocabulaire utilisé | Doctrine |
|---|---|---|
| Scellement | « Empreinte technique », « cohérence technique » | ✅ §7.2 / §7.3 |
| Hash badge | « Cohérence technique vérifiée » / « Incohérence technique détectée » | ✅ §7.2 |
| Page `/verify/:cachetCode` | « Document préparatoire privé — sans valeur officielle » | ✅ §7.1 |
| Watermark PDF | « BROUILLON PRÉPARATOIRE — NON OPPOSABLE » | ✅ §7.1 |
| Partage (email/SMS/WA/lien) | Préfixe `[BROUILLON AIME — non opposable]` | ✅ §7.1 |
| Tampon | « Tampon privé sans valeur officielle » | ✅ §7.1 |
| **Signature** | **« Signature manuscrite visuelle » + disclaimer eIDAS** | ✅ **§7.4 (corrigé)** |

### 9.4 Point de vigilance §7 désormais clos

Le **seul point de vigilance vocabulaire identifié dans l'audit `/fiche/:id`** (cf. `docs/aime-fiche-view-audit.md` §7.3 et §10) est désormais **résolu**.

---

## 📌 Synthèse du freeze

| Item | Valeur |
|---|---|
| Fichiers modifiés | 2 |
| Opérations `anchor_replace` | 2 |
| Lignes affectées | ~4 |
| Logique modifiée | ❌ Aucune |
| Données affectées | ❌ Aucune |
| Backend touché | ❌ Aucun |
| PDF modifié | ❌ Non |
| Hash modifié | ❌ Non |
| Routes modifiées | ❌ Aucune |
| Nouveau document ajouté | ❌ Aucun |
| Verticale créée | ❌ Aucune |
| Phase 2 EventCore | ⛔ NON démarrée |
| Conformité doctrine §7.4 | ✅ Atteinte |
| Rollback | 🟢 Trivial (< 30 s) |
| Risque résiduel | 🟢 Nul |

---

> **AIME Cachet reste strictement intact.**
> Seul le vocabulaire affiché à l'utilisateur a été précisé, en cohérence avec la doctrine AIME CanvasCore §7.

— Fin du freeze documentaire `aime-signature-wording-freeze` —