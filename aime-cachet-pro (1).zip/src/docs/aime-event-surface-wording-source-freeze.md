# AIME Event — Surface Wording & Source Doctrine — Freeze documentaire

**Date :** 2026-05-23
**Statut :** Gelé (mini-freeze wording + doctrine §0bis)
**Périmètre :** AIME Event uniquement — AIME Cachet strictement non impacté.
**Doctrine de référence :** `docs/aime-event-surface-doctrine-pre-ui.md`

---

## 1. Objectif

Figer deux points doctrinaux complémentaires :

1. **Wording UI** : la surface `document` doit être nommée **« Fiche préparatoire A4 »** dans toute interface visible. Plus jamais « Document A4 » seul, et **jamais** « Site », « Page », « Document » au sens générique.
2. **Modèle conceptuel** : un événement = **un seul `EventRecord`** (source unique) ; plusieurs surfaces = **plusieurs manières de regarder / présenter** cette même source. Toutes les surfaces existent conceptuellement en même temps sur un même `EventRecord` ; seules certaines sont techniquement actives et doctrinalement autorisées à un instant donné.

---

## 2. Fichiers modifiés

| Fichier | Nature de la modification |
|---|---|
| `components/event/studio/SurfaceSelector.jsx` | Wording de la surface `document` aligné : `label` et `description` uniquement. |
| `docs/aime-event-surface-doctrine-pre-ui.md` | Ajout de la section **§0bis — Modèle conceptuel : un EventRecord, plusieurs surfaces**. Aucune autre section modifiée. |
| `docs/aime-event-surface-wording-source-freeze.md` | Présent document de freeze. |

**Aucun autre fichier n'a été modifié.**

---

## 3. Ancien wording → Nouveau wording

### `components/event/studio/SurfaceSelector.jsx` — entrée `document`

| Champ | Avant | Après |
|---|---|---|
| `label` | `"Document A4"` | `"Fiche préparatoire A4"` |
| `description` | `"Fiche standard, tous types d'événements."` | `"Fiche source de l'événement, tous types. N'est pas un site."` |

### Wording inchangé

- Titre de section : « Surface du canvas » — **inchangé**.
- Sous-titre : « Choisissez la surface utilisée pour le rendu du brouillon. » — **inchangé**.
- Pied de section : « Toutes les surfaces restent privées, préparatoires et non opposables. » — **inchangé**.
- Surface `faire_part` (label + description) — **inchangée**.

---

## 4. Doctrine §0bis ajoutée

Section ajoutée dans `docs/aime-event-surface-doctrine-pre-ui.md`, immédiatement après le §0 Préambule.

**Règles principales actées :**

- **Un événement = un seul `EventRecord` (source unique).**
- **Plusieurs surfaces = plusieurs manières de regarder / présenter cette même source.**
- `surfaceMode` n'est **pas** un choix exclusif de format de sortie : c'est le **point de vue courant** sur la source commune.
- **La fiche A4 n'est PAS le site.** `document` est la **fiche source** structurée — point de vérité textuel. Toute UI doit la nommer **« Fiche préparatoire A4 »**.
- **`web_page` et `mini_site` seront des surfaces futures**, jamais des éditeurs séparés ni des entités distinctes. Elles seront alimentées par **le même `EventRecord`** via le registre CanvasCore.
- **`mini_site` sera un assemblage** de plusieurs surfaces (ex : `hero` + `programme` + `faire_part`) — pas un nouveau type d'objet.
- **Interdit** : éditeur de site séparé, entité `Website`, page de création de mini-site dédiée.
- **Obligatoire** : toute nouvelle vue passe par la chaîne `EventRecord → surfaceMode → registre → EventFicheView → renderer canvas`.

Le §0bis est **non négociable** et complète le §6 anti-doublon existant.

### Cartographie conceptuelle figée

| Surface | Nature conceptuelle |
|---|---|
| `document` | **Fiche source** — fiche préparatoire A4 structurée. Point de vérité textuel. |
| `faire_part` | Vue graphique A5 dérivée (mariages, soirées privées). |
| `hero` | Vue « section d'accueil » dérivée. |
| `programme` | Vue « déroulé » dérivée. |
| `billet` | Vue « admission préparatoire » dérivée (jamais opposable). |
| `carte` | Vue « carton » dérivée. |
| `affiche` | Vue « placard » dérivée (aperçu privé uniquement). |
| `web_page` | Vue « page web privée en aperçu » dérivée. **Jamais publiée en l'état.** |
| `mini_site` | **Assemblage** de plusieurs surfaces dérivées du même `EventRecord`. |
| `section` | Fragment réutilisable d'une autre surface. |
| `fiche_prestataire` | Vue centrée prestataires dérivée. |
| `fiche_evenement` | Vue événementielle alternative (à définir doctrinalement). |

---

## 5. Preuve qu'aucune logique n'a été modifiée

### 5.1 Composants de rendu — intacts

- `components/event/EventFichePaper.jsx` : 0 ligne modifiée.
- `components/event/SurfaceFairePart.jsx` : 0 ligne modifiée.
- `components/event/EventFicheVerso.jsx` : 0 ligne modifiée.
- `components/event/surface/DraftWatermark.jsx` : 0 ligne modifiée.
- `components/event/surface/DoctrineFooter.jsx` : 0 ligne modifiée.

### 5.2 Cœur Event — intact

- `pages/EventFicheView.jsx` : 0 ligne modifiée.
- `pages/Events.jsx`, `pages/EventsType.jsx` : 0 ligne modifiée.
- `components/event/EventStudio.jsx` : 0 ligne modifiée (modification précédente du §3 du freeze Surface Selector v0 inchangée).
- `components/event/EventCreateButton.jsx` : 0 ligne modifiée.
- `components/event/EventDraftBanner.jsx` : 0 ligne modifiée.

### 5.3 Registre et schémas — intacts

- `lib/event-core/surfaces/index.js` : 0 ligne modifiée. Aucune surface ajoutée, retirée, ni promue. `document` et `faire_part` restent les seules `active`.
- `lib/event-core/verticals/event.js` : 0 ligne modifiée.
- `entities/EventRecord.json` : 0 ligne modifiée. L'enum `surfaceMode` reste identique (12 valeurs).
- `App.jsx` : 0 ligne modifiée. Aucune route ajoutée.

### 5.4 `SurfaceSelector.jsx` — seule la table `SURFACE_META` (deux chaînes) est touchée

- Matrice `ALLOWED_SURFACES_BY_TYPE` : inchangée.
- Logique de filtrage par `eventType` : inchangée.
- Comportement `onChange` / radio group : inchangé.
- Section repliable, repliée par défaut : inchangée.
- Aucun nouveau hook, aucun nouvel effet de bord, aucun nouvel appel SDK.

### 5.5 AIME Cachet — strictement intact

- `components/aime/**` : 0 fichier modifié.
- `functions/sealCachet.js`, `functions/verifyCachet.js` : 0 ligne modifiée.
- Schéma `Prestation`, `HASHED_FIELDS`, `verification_hash`, `cachet_code` : inchangés.
- Routes `/app`, `/prestations`, `/507`, `/fiche/:id`, `/verify/:cachetCode` : comportement inchangé.
- Templates `*Paper.jsx` (Fiche, Recu, Cession, Frais, Presence, Devis, NoteHonoraires, Avenant, CddU, CessionDroits, Guso, Aem, AttPe, Dpae) : inchangés.

### 5.6 Aucun artefact opposable créé

- Aucun PDF généré.
- Aucun hash appliqué.
- Aucun scellement.
- Aucun endpoint public ouvert.
- Aucun RSVP, aucun module invités, aucun envoi.

---

## 6. Rollback

Le mini-freeze est **strictement non destructif** et trivialement réversible.

### Niveau 1 — rollback du wording uniquement

Dans `components/event/studio/SurfaceSelector.jsx`, restaurer la table `SURFACE_META.document` à l'identique :

```js
document: {
  label: "Document A4",
  description: "Fiche standard, tous types d'événements.",
},
```

Aucune autre action requise. Aucune migration de données. Les valeurs `surfaceMode` en base restent valides.

### Niveau 2 — rollback de la doctrine §0bis

Dans `docs/aime-event-surface-doctrine-pre-ui.md`, supprimer intégralement la section **§0bis — Modèle conceptuel : un EventRecord, plusieurs surfaces**.

Le document doctrinal retombe à l'état antérieur à ce mini-freeze.

### Niveau 3 — rollback complet du mini-freeze

1. Niveau 1.
2. Niveau 2.
3. `delete_file docs/aime-event-surface-wording-source-freeze.md`.

État identique à celui du freeze `docs/aime-event-surface-selector-v0-freeze.md`.

**Aucun risque de perte de données.** Aucun champ utilisateur, aucun rendu, aucune fonction n'est lié au wording ou au §0bis.

---

**Fin du mini-freeze.**