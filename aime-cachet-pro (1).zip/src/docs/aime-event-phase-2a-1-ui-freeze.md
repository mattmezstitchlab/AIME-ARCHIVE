# AIME Event — Phase 2A.1 · Freeze UI

**Date :** 23 mai 2026
**Version :** Phase 2A.1 (micro-ajustements UI)
**Auteur :** AIME — équipe produit
**Statut :** ✅ FREEZE — micro-ajustements UI uniquement, aucune logique métier modifiée

---

## 1. Objectif

Apporter **trois micro-ajustements UI strictement cosmétiques** à AIME Event Phase 2A
pour améliorer la lisibilité, la sécurité d'usage et la pédagogie préparatoire,
sans modifier aucune logique métier, sans créer de nouvelle route, sans introduire
de PDF, hash, scellement, endpoint public ou page publique.

Le périmètre Phase 2A reste intégralement préservé :
- tous les `EventRecord` restent `visibility='private_draft'` ;
- aucune fonction backend créée ou modifiée ;
- aucune navigation officielle AIME Cachet altérée ;
- la doctrine CanvasCore §7 reste applicable.

---

## 2. Fichiers modifiés

| Fichier | Type | Description |
|---|---|---|
| `components/event/EventFichePaper.jsx` | ✏️ Modifié | Ajout `PlaceholderBlock` interne + restructuration sections (toujours visibles) |
| `pages/EventFicheView.jsx` | ✏️ Modifié | Réorganisation TopBar — bouton Supprimer isolé + séparateur visuel |
| `pages/EventsType.jsx` | ✏️ Modifié | Import + insertion du nouveau composant hub |

## 3. Composant créé

| Fichier | Rôle |
|---|---|
| `components/event/EventTypeRecommendedDocs.jsx` | Hub documentaire **en lecture seule** : affiche les 10 documents recommandés déclarés dans `EVENT_DOCUMENT_LIBRARY` (config event-core). Aucune création, aucune action métier, aucun lien sortant. |

---

## 4. Changements UX appliqués

### Ajustement 1 — Fiche événement structurée

**Avant :** les sections `Programme`, `Prestataires` étaient affichées **conditionnellement**.
Une fiche neuve avec uniquement un titre paraissait « inachevée » : grande zone blanche
au milieu du A4.

**Après :** ces sections sont **toujours visibles**, avec un placeholder visuel :

```
PROGRAMME
┌────────────────────────────────────────┐
│ À renseigner (préparatoire)            │  ← boîte pointillée, italique, gris
└────────────────────────────────────────┘
```

- Sections désormais permanentes : `Description`, `Programme`, `Prestataires`,
  `Documents préparatoires` (nouvelle 4ᵉ section, lit `event.documents` si présent).
- Composant interne `PlaceholderBlock` — 4 lignes, zéro logique.
- **Vocabulaire conforme :** « À renseigner (préparatoire) » — aucune ambiguïté.

### Ajustement 2 — Bouton Supprimer isolé

**Avant :** la poubelle « Supprimer » était collée au CTA rouge « Éditer ».
Risque réel de clic involontaire `Éditer → Supprimer`.

**Après :**
- Poubelle déplacée à **l'extrême gauche** du groupe d'actions.
- **Séparateur vertical fin** (`w-px h-5 bg-white/15`) entre poubelle et reste.
- Couleur atténuée (`text-zinc-400`) pour signaler statut secondaire.
- Ajout `aria-label="Supprimer le brouillon"` pour l'accessibilité.
- Aucun changement à la fonction `handleDelete` — confirmation native conservée.

### Ajustement 3 — Hub préparatoire `/events/:type`

**Avant :** la page `/events/:type` se comportait comme un simple filtre.
Aucune trace des 10 documents déclarés dans la config event-core.

**Après :**
- Bloc « **HUB PRÉPARATOIRE · {Label}** » inséré sous le bandeau doctrinal.
- Phrase pédagogique conforme à la demande : *« Préparation type {Label} :
  les documents recommandés ci-dessous servent de repères préparatoires. »*
- Mention obligatoire : *« Aperçu en lecture seule — non implémentés en
  Phase 2A. À valider humainement. »*
- Grille 2 colonnes des 10 documents (icône Lucide + label + description),
  lue depuis `EVENT_DOCUMENT_LIBRARY`.
- **Aucun document créé, aucune action déclenchable, aucun lien sortant.**

---

## 5. Preuve qu'aucune logique sensible n'a été touchée

### 5.1 Logique cryptographique et certification

| Élément | Statut |
|---|---|
| `lib/verificationHash.js` (HASHED_FIELDS, canonicalize, computeHash) | ✅ Non touché |
| `functions/sealCachet` (backend, SHA-256, RLS) | ✅ Non touché |
| `functions/verifyCachet` (endpoint public read-only) | ✅ Non touché |
| Aucune nouvelle backend function créée | ✅ Confirmé |

### 5.2 Entités

| Entité | Statut |
|---|---|
| `Prestation` (schéma + RLS) | ✅ Non touchée |
| `EventRecord` (schéma + RLS) | ✅ Non touchée — seul le rendu visuel change |
| `User`, `Wallet`, `HistoryEvent`, `AssistantReminder` | ✅ Non touchées |

### 5.3 Fonctions métier

| Fonction | Statut |
|---|---|
| `handleDelete` dans `EventFicheView` | ✅ Identique (déplacement DOM uniquement) |
| `useEffect` de chargement événement | ✅ Inchangé |
| Filtres `base44.entities.EventRecord.filter` | ✅ Inchangés |
| Logique de scellement, vérification, génération PDF | ✅ Non touchée (jamais étendue à AIME Event) |

### 5.4 Surface publique

| Surface | Statut |
|---|---|
| Aucun nouvel endpoint public créé | ✅ Confirmé |
| Aucun PDF généré côté AIME Event | ✅ Confirmé |
| Aucun QR de vérification créé | ✅ Confirmé (QR existant reste indicatif) |
| Aucun hash technique créé pour `EventRecord` | ✅ Confirmé |
| `visibility='private_draft'` strict respecté | ✅ Confirmé |

---

## 6. Preuve qu'AIME Cachet reste intact

### 6.1 Routes AIME Cachet (inchangées)

| Route | Composant | Statut |
|---|---|---|
| `/` | `Landing` | ✅ Non modifié |
| `/app` | `AimeCachet` | ✅ Non modifié |
| `/prestations` | `MesPrestations` | ✅ Non modifié |
| `/507` | `Dashboard507` | ✅ Non modifié |
| `/fiche/:id` | `FicheView` | ✅ Non modifié |
| `/verify/:cachetCode` | `Verify` | ✅ Non modifié |
| `/recherche`, `/notifications`, `/profil`, `/aide`, `/parametres` | divers | ✅ Non modifiés |

### 6.2 Templates documentaires intermittents (14 fichiers)

Tous les `*Paper.jsx` strictement intacts :
`FichePaper`, `FicheVerso`, `RecuPaper`, `CessionPaper`, `FraisPaper`,
`PresencePaper`, `DevisPaper`, `NoteHonorairesPaper`, `AvenantPaper`,
`CddUPaper`, `CessionDroitsPaper`, `GusoPaper`, `AemPaper`, `AttPePaper`,
`DpaePaper`.

### 6.3 Composants AIME Cachet stratégiques

| Composant | Statut |
|---|---|
| `SealButton` | ✅ Non touché |
| `SectionCertification` | ✅ Non touchée |
| `StampGraphic`, `StampDialog` | ✅ Non touchés |
| `SignaturePad` | ✅ Non touché |
| `SideRail` | ✅ Non touché — AIME Event reste hors nav |
| `GlobalToolbar`, `LegalDisclaimer` | ✅ Non touchés |

### 6.4 Configuration doctrinale

| Fichier | Statut |
|---|---|
| `lib/event-core/verticals/intermittence.js` | ✅ Non touché |
| `lib/event-core/verticals/event.js` | ✅ Non touché (lu en lecture seule par le nouveau composant) |
| `docs/aime-canvascore-doctrine.md` | ✅ Non touché |
| `docs/aime-event-phase-2a-freeze.md` (freeze précédent) | ✅ Non touché |

### 6.5 Navigation

- **AIME Event reste accessible uniquement par URL directe** (`/events`, `/events/:type`, `/events/fiche/:id`).
- Aucune entrée AIME Event dans le `SideRail`.
- Aucun lien sortant depuis `AimeCachet`, `MesPrestations`, `Dashboard507`, `FicheView`.
- Seul un lien discret « ← Retour AIME Cachet » est présent dans le header `/events` (existait déjà avant Phase 2A.1).

---

## 7. Vérification visuelle (23 mai 2026)

Trois captures preview réelles obtenues sur les 3 routes :

### `/events`
- ✅ Bandeau doctrinal jaune lisible
- ✅ Grille 10 types intacte
- ✅ Compteurs cohérents (1 ou —)
- ✅ Lien « ← Retour AIME Cachet » présent

### `/events/spectacle`
- ✅ Bloc « HUB PRÉPARATOIRE · SPECTACLE » affiché
- ✅ Phrase pédagogique présente
- ✅ Mention « Aperçu en lecture seule — non implémentés en Phase 2A. À valider humainement. »
- ✅ 10 documents en grille 2 colonnes (Fiche événement, Fiche prestataire, Planning, Programme, Invitation, Aperçu public, Checklist, Budget, Fiche technique, Contacts utiles)
- ✅ Bouton « Créer un spectacle » conservé

### `/events/fiche/6a1120c1791314ae4592f0e8`
- ✅ Poubelle « Supprimer » à **l'extrême gauche** du groupe d'actions
- ✅ Séparateur vertical fin visible entre poubelle et bandeau compact
- ✅ Bouton « Éditer » rouge isolé à droite
- ✅ Sections `PROGRAMME`, `PRESTATAIRES`, `DOCUMENTS PRÉPARATOIRES` affichées avec placeholder « À renseigner (préparatoire) »
- ✅ Watermark `BROUILLON` toujours présent
- ✅ Footer doctrinal triple intact

---

## 8. Limites de la Phase 2A.1

### Ce qui est livré
- ✅ Placeholders visibles sur la fiche événement
- ✅ Bouton Supprimer isolé du bouton Éditer
- ✅ Hub documentaire en lecture seule sur `/events/:type`

### Ce qui n'est PAS livré (et ne doit pas l'être)
- ❌ Aucune génération PDF pour AIME Event
- ❌ Aucun hash technique pour `EventRecord`
- ❌ Aucun endpoint public `/verify/:eventCode`
- ❌ Aucune page publique d'événement
- ❌ Aucune intégration AIME Event ↔ AIME Cachet
- ❌ Aucune entrée AIME Event dans le `SideRail`
- ❌ Aucune création de nouveaux types d'événements
- ❌ Aucune modification de la config `event-core`

### Périmètre interdit jusqu'à autorisation explicite
- Implémentation effective des 10 documents recommandés
- Création d'une Phase 2B (génération, partage, vérification)
- Toute extension du domaine `EventRecord` (champs métier supplémentaires)
- Tout endpoint public lié à AIME Event
- Toute intégration avec `sealCachet` ou `verifyCachet`

---

## 9. Rollback

### Option A — Rollback complet de la Phase 2A.1

1. `anchor_replace` inverse sur `components/event/EventFichePaper.jsx`
   - retirer le composant interne `PlaceholderBlock` ;
   - restaurer les 3 sections conditionnelles (`{event.description && ...}`) ;
   - retirer la 4ᵉ section `Documents préparatoires`.
2. `anchor_replace` inverse sur `pages/EventFicheView.jsx`
   - replacer la poubelle après le bouton Éditer ;
   - retirer le séparateur vertical.
3. `anchor_replace` inverse sur `pages/EventsType.jsx`
   - retirer l'import `EventTypeRecommendedDocs` ;
   - retirer l'insertion du composant.
4. `delete_file` sur `components/event/EventTypeRecommendedDocs.jsx`.
5. `delete_file` sur `docs/aime-event-phase-2a-1-ui-freeze.md`.

**Durée estimée : < 2 minutes**

### Option B — Rollback partiel (par ajustement)

Chaque ajustement est isolé dans son propre fichier et **indépendant** des deux autres.
Il est possible d'annuler un seul ajustement sans toucher aux autres.

### Garantie

**Aucun rollback (complet ou partiel) ne peut affecter AIME Cachet**, car aucun fichier
AIME Cachet n'a été modifié.

---

## 10. Prochaine étape recommandée

### Phase 2A.2 (suggérée, non autorisée)

**Objectif :** clôturer Phase 2A avec deux micro-ajustements UX additionnels mineurs.

Pistes potentielles à discuter :
1. **Nettoyage des brouillons fantômes** : les 3 entrées « Nouvel événement (brouillon) »
   sans date ni lieu polluent visuellement `/events`. Proposer une action de purge manuelle
   par l'utilisateur (jamais automatique).
2. **Cohérence des selects** : remplacer les `<select>` natifs OS du registre `/events`
   par des composants `shadcn/ui` pour homogénéité visuelle.

**À NE PAS ENGAGER avant autorisation explicite.**

### Phase 2B (à formaliser séparément)

Hors périmètre actuel. Toute discussion sur :
- l'implémentation effective des 10 documents ;
- la génération PDF AIME Event ;
- une éventuelle vérification publique ;

devra faire l'objet d'un **CanvasCore dédié Phase 2B**, validé en amont,
documentant explicitement les garanties juridiques et la séparation
d'avec AIME Cachet.

---

## Signature documentaire

- **Doctrine appliquée :** CanvasCore §7 — brouillon préparatoire, non opposable
- **Doctrine non affectée :** EventCore Phase 1 (freeze conservé)
- **Périmètre Phase 2A :** strictement respecté
- **AIME Cachet :** intégralement préservé

🔒 **FREEZE Phase 2A.1 — Ne plus modifier sans autorisation explicite.**