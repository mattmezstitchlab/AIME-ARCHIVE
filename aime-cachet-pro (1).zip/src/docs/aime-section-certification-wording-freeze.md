# Freeze documentaire — Clarification vocabulaire `SectionCertification`

**Date** : 23 mai 2026
**Type** : micro-correction textuelle validée, exécutée, gelée
**Phase** : post-audit `/fiche/:id`, hors Phase 2 EventCore
**Statut** : ✅ Appliquée — aucun rollback nécessaire

---

## 1. Objectif de la correction

La section **Certification** du Studio (panneau droit de `/fiche/:id`) calculait localement un hash SHA-256 **différent** du hash officiel produit par le backend (`sealCachet`) :

| Niveau | Champs | Source |
|---|---|---|
| Hash **local** Studio | 5 champs (`code`, `employer`, `date`, `amount`, `ts` volatil) | `SectionCertification.jsx` |
| Hash **officiel** backend | 8 champs figés (`HASHED_FIELDS`) | `sealCachet` |

Les **anciens libellés** (« Empreinte cryptographique unique liée à votre document. », « Empreinte SHA-256 », « Hash SHA-256 », toast « Hash copié ») pouvaient laisser croire à l'utilisateur que ce hash local **était** l'empreinte officielle. Or :

- Le hash local **n'est jamais persisté** ;
- Il **ne correspond pas** au `verification_hash` stocké sur `Prestation` ;
- Il **n'est pas vérifiable** sur `/verify/:cachetCode` ;
- Il **change à chaque ouverture du Studio** (à cause du `timestamp` volatil).

La correction transforme cette section en **« aperçu local indicatif »** assumé, en cohérence avec la **doctrine AIME CanvasCore §7** : aucune affirmation administrative, vocabulaire neutre, distinction claire entre l'aperçu utilisateur et l'empreinte technique officielle.

---

## 2. Fichier modifié

| Fichier | Opérations | Nature |
|---|---|---|
| `components/aime/fiche/studio/SectionCertification.jsx` | 6 (5 reformulations + 1 mention d'aide + 1 constante locale) | Strictement textuelles + JSX additif |

**1 seul fichier**, 1 appel `anchor_replace` avec 6 opérations.

**Aucun autre fichier touché.**

---

## 3. Anciens libellés

### 3.1 Bandeau d'en-tête (ligne 40)
```jsx
<span className="text-[10px] text-aime-red leading-tight">
  Empreinte cryptographique unique liée à votre document.
</span>
```

### 3.2 Label du toggle (ligne 50)
```jsx
<span className="text-[12px] text-white font-medium">Empreinte SHA-256</span>
```

### 3.3 Label de l'encadré hash (ligne 85)
```jsx
<span className="text-[9px] tracking-wider text-zinc-500 uppercase">Hash SHA-256</span>
```

### 3.4 Toast après copie (ligne 81)
```jsx
onClick={copy(hash, "Hash copié")}
```

### 3.5 Mention d'aide
*(absente)*

---

## 4. Nouveaux libellés

### 4.1 Bandeau d'en-tête
```jsx
<span className="text-[10px] text-aime-red leading-tight">
  Aperçu local indicatif. L'empreinte technique officielle est générée au moment du scellement.
</span>
```

### 4.2 Label du toggle
```jsx
<span className="text-[12px] text-white font-medium">Aperçu SHA-256 (indicatif)</span>
```

### 4.3 Label de l'encadré hash
```jsx
<span className="text-[9px] tracking-wider text-zinc-500 uppercase">Aperçu SHA-256 — non scellé</span>
```

### 4.4 Toast après copie
```jsx
const HASH_COPY_LABEL = "Aperçu copié";
// ...
onClick={copy(hash, HASH_COPY_LABEL)}
```

**Note** : le toast est désormais piloté par une constante locale (`HASH_COPY_LABEL`) plutôt qu'une chaîne littérale. Comportement **strictement identique** — passe la même chaîne au helper `copy()`.

---

## 5. Mention d'aide ajoutée

Sous le bouton de copie du hash, un paragraphe discret a été inséré :

```jsx
<p className="text-[9px] text-zinc-500 italic leading-snug px-1">
  L'empreinte officielle (8 champs) est produite par le scellement. Voir le bouton « Sceller la fiche ».
</p>
```

| Caractéristique | Valeur |
|---|---|
| Style | 9px, italique, gris discret (`text-zinc-500`) |
| Comportement | Aucun (texte statique, pas de handler) |
| Lien fonctionnel | Aucun (mention indicative — l'utilisateur sait où chercher le bouton, qui reste à sa place habituelle dans la TopBar) |
| Intention | Rediriger mentalement vers le `SealButton`, source de vérité officielle |

---

## 6. Preuve qu'aucune logique n'a été modifiée

### 6.1 Calcul du hash local — strictement identique

| Élément | État |
|---|---|
| Fonction `sha256(text)` (Web Crypto API) | ✅ Identique |
| Algorithme `crypto.subtle.digest("SHA-256", ...)` | ✅ Identique |
| Encodage `TextEncoder` UTF-8 | ✅ Identique |
| Conversion hex (`b.toString(16).padStart(2, "0")`) | ✅ Identique |

### 6.2 Champs hashés localement — strictement identiques

```js
JSON.stringify({
  code: cachetCode,
  employer: prestation?.employer,
  date: prestation?.date,
  amount: prestation?.amount,
  ts: timestamp.toISOString(),
})
```

**Les 5 champs et leur ordre sont inchangés.** Le `JSON.stringify` produit exactement la même chaîne qu'avant. Le hash calculé est **bit pour bit identique** à celui produit avant la correction.

### 6.3 États React — strictement identiques

| Élément | État |
|---|---|
| `useState("")` pour `hash` | ✅ Identique |
| `useState(() => new Date())` pour `timestamp` | ✅ Identique |
| `useEffect` (dépendances `[cachetCode, prestation, timestamp]`) | ✅ Identique |
| `verifyUrl = window.location.origin + "/fiche/" + prestation?.id` | ✅ Identique |
| `tsLabel` (formatage FR `dateStyle: "short", timeStyle: "medium"`) | ✅ Identique |

### 6.4 Comportements interactifs — strictement identiques

| Élément | État |
|---|---|
| Helper `copy(val, msg)` (signature, body) | ✅ Identique |
| Toggle QR (`onToggleQR`, `showQR`) | ✅ Identique |
| Toggle hash (`onToggleHash`, `showHash`) | ✅ Identique |
| `QRBadge` (props `value={verifyUrl}`, `size={88}`, `label={cachetCode}`) | ✅ Identique |
| Troncature du hash affiché (`hash.slice(0, 32) + "…"`) | ✅ Identique |
| Placeholder « Calcul… » | ✅ Identique |

### 6.5 Imports, props, exports — strictement identiques

| Élément | État |
|---|---|
| `import React, { useState, useEffect }` | ✅ Identique |
| `import { Shield, Copy, Check }` | ✅ Identique |
| `import QRBadge` | ✅ Identique |
| `import { toast } from "sonner"` | ✅ Identique |
| Props (`cachetCode`, `prestation`, `showQR`, `onToggleQR`, `showHash`, `onToggleHash`) | ✅ Identiques |
| `export default function SectionCertification` | ✅ Identique |

### 6.6 Synthèse

Les modifications sont **strictement textuelles + JSX additif** :
- ✅ 4 chaînes de caractères reformulées (libellés affichés)
- ✅ 1 constante locale `HASH_COPY_LABEL` extraite (refactor sans changement de comportement)
- ✅ 1 balise `<p>` ajoutée (mention d'aide statique)

**Aucun handler, aucun state, aucun useEffect, aucun import, aucun calcul, aucune signature de fonction n'a été modifié.**

---

## 7. Confirmation : le hash backend officiel reste la seule source de vérité

| Source | Champs | Persistance | Vérifiable publiquement | Source de vérité ? |
|---|---|---|---|---|
| Hash **local** Studio (`SectionCertification`) | 5 (avec `ts` volatil) | ❌ Aucune | ❌ Non | ❌ **Aperçu indicatif uniquement** |
| Hash **officiel** backend (`sealCachet`) | 8 (`HASHED_FIELDS` figés) | ✅ `Prestation.verification_hash` + `verification_hash_at` | ✅ Via `/verify/:cachetCode` | ✅ **Source de vérité unique** |

### 7.1 Garanties techniques

| Garantie | État |
|---|---|
| `lib/verificationHash.js` non touché | ✅ Confirmé |
| `HASHED_FIELDS` (les 8 champs figés) non modifiés | ✅ Confirmé |
| `computeVerificationHash()` non touché | ✅ Confirmé |
| `hashesMatch()` non touché | ✅ Confirmé |
| `functions/sealCachet` non touché | ✅ Confirmé |
| `functions/verifyCachet` non touché | ✅ Confirmé |
| Champ `Prestation.verification_hash` non touché | ✅ Confirmé |
| Champ `Prestation.verification_hash_at` non touché | ✅ Confirmé |
| `SealButton` (calcul live + appel backend) non touché | ✅ Confirmé |
| `HashCheckBadge` (3 états `match`/`mismatch`/`absent`) non touché | ✅ Confirmé |

### 7.2 Conséquences pour l'utilisateur

- Les **fiches déjà scellées** conservent **exactement** leur `verification_hash` et `verification_hash_at`.
- Toute **nouvelle fiche scellée** produira le **même hash backend qu'avant** (8 champs figés via `sealCachet`).
- La page publique **`/verify/:cachetCode`** continue à afficher les mêmes états (`match`/`mismatch`/`absent`) sur la base du hash backend officiel.
- L'utilisateur perçoit désormais clairement, dans le Studio, qu'il consulte un **aperçu indicatif** et **non l'empreinte officielle**.

---

## 8. Éléments explicitement NON touchés

### 8.1 Backend
- ❌ `functions/sealCachet`
- ❌ `functions/verifyCachet`
- ❌ Aucune nouvelle fonction backend créée

### 8.2 Hash et scellement
- ❌ `lib/verificationHash.js`
- ❌ `HASHED_FIELDS` (8 champs figés)
- ❌ `components/aime/fiche/SealButton`
- ❌ `components/aime/verify/HashCheckBadge`

### 8.3 Verso et QR
- ❌ `components/aime/fiche/QRBadge`
- ❌ `components/aime/fiche/FicheVerso`

### 8.4 Structure Studio et page fiche
- ❌ `components/aime/fiche/studio/StudioPanel`
- ❌ `components/aime/fiche/studio/SectionApparence`
- ❌ `components/aime/fiche/studio/SectionIdentite`
- ❌ `components/aime/fiche/studio/SectionContenu`
- ❌ `components/aime/fiche/studio/SectionIA`
- ❌ `pages/FicheView`
- ❌ `pages/Verify`

### 8.5 Templates documentaires
- ❌ Aucun des 14 `*Paper.jsx` modifié
- ❌ `lib/ficheGenerator.js` (PDF)

### 8.6 Entités et données
- ❌ Entité `Prestation` (schéma intact)
- ❌ Champs `verification_hash`, `verification_hash_at`, `cachet_code`, `custom_notes`, `doc_type` intacts
- ❌ Aucune migration de données
- ❌ Aucun renommage

### 8.7 Routes et navigation
- ❌ `App.jsx`
- ❌ Les 12 routes existantes (identiques)

### 8.8 Cockpit 507 et intermittence
- ❌ `lib/intermittent507.js`
- ❌ `pages/Dashboard507`

### 8.9 Architecture future
- ⛔ **Phase 2 EventCore : NON démarrée**
- ⛔ **Aucune verticale créée**
- ⛔ **Aucun nouveau document ajouté** à la bibliothèque
- ⛔ **Aucun nouveau composant générique extrait**
- ⛔ Le dossier `lib/event-core/` reste passif et inchangé

---

## 9. Rollback

### 9.1 Méthode

1 seul `anchor_replace` inversé sur `components/aime/fiche/studio/SectionCertification.jsx` avec 6 opérations :

```
1. "Aperçu local indicatif. L'empreinte technique officielle..."
   → "Empreinte cryptographique unique liée à votre document."

2. "Aperçu SHA-256 (indicatif)"
   → "Empreinte SHA-256"

3. "Aperçu SHA-256 — non scellé"
   → "Hash SHA-256"

4. Retirer la constante HASH_COPY_LABEL
   et remettre copy(hash, "Hash copié") en littéral

5. Supprimer le <p> de mention d'aide ajouté
   sous le bouton de copie
```

### 9.2 Caractéristiques du rollback

| Aspect | Valeur |
|---|---|
| Fichiers à toucher | 1 seul (`SectionCertification.jsx`) |
| Temps estimé | < 30 secondes |
| Risque de régression | 🟢 Nul (modifications strictement textuelles) |
| Données affectées | 🟢 Aucune |
| Hash existants | 🟢 Inchangés (le hash local n'a jamais été persisté) |
| Fiches scellées | 🟢 Inchangées (hash backend non touché) |
| Compatibilité ascendante / descendante | ✅ Totale |

---

## 10. Lien avec la doctrine AIME CanvasCore §7

La doctrine **AIME CanvasCore** établit en §7 les **invariants juridiques** qui protègent AIME comme moteur préparatoire.

### 10.1 Principes §7 concernés

- **§7.1 — Préparation, jamais opposabilité** : AIME prépare des brouillons, ne produit jamais de pièce officielle.
- **§7.2 — Le hash est technique, jamais administratif** : le hash atteste de la cohérence d'un fichier, pas de la validité d'une déclaration.
- **§7.3 — Le scellement n'est pas une certification** : vocabulaire neutre obligatoire (« empreinte technique », « cohérence technique »).
- **§7.5 — L'utilisateur reste seul responsable** des déclarations qu'il transmet aux organismes officiels.

### 10.2 Conformité avant / après correction

| Principe §7 | Avant correction | Après correction |
|---|---|---|
| §7.2 — Distinction hash technique / administratif | ⚠️ Ambiguë (« Empreinte cryptographique unique liée à votre document » suggère unicité officielle) | ✅ Conforme (« Aperçu local indicatif » + mention de l'empreinte officielle distincte) |
| §7.3 — Vocabulaire neutre | ⚠️ Le terme « Hash SHA-256 » pouvait évoquer le hash officiel | ✅ « Aperçu SHA-256 — non scellé » + mention du scellement comme source officielle |
| §7.1, §7.5 | ✅ Déjà conformes | ✅ Toujours conformes (non touchés) |

### 10.3 Cohérence d'ensemble du vocabulaire de scellement

| Brique | Vocabulaire utilisé | Doctrine |
|---|---|---|
| `SealButton` (TopBar) | « Sceller la fiche », « empreinte technique » | ✅ §7.2 / §7.3 |
| `HashCheckBadge` (`/verify`) | « Cohérence technique vérifiée » / « Incohérence détectée » / « Hash non disponible » | ✅ §7.2 |
| Toast après scellement | « Cohérence technique scellée. Ne constitue pas une certification officielle. » | ✅ §7.3 |
| Page `/verify/:cachetCode` | « Cohérence technique uniquement — pas une certification officielle » | ✅ §7.1 / §7.3 |
| **Studio — section Certification** | **« Aperçu local indicatif » + « Aperçu SHA-256 (indicatif) » + « Aperçu SHA-256 — non scellé » + mention de l'empreinte officielle** | ✅ **§7.2 / §7.3 (corrigé)** |
| Signature manuscrite | « Signature manuscrite visuelle — ne vaut pas signature électronique qualifiée » | ✅ §7.4 (corrigé précédemment) |

### 10.4 Points de vigilance §7 désormais clos

Les **deux points de vigilance vocabulaire** identifiés dans l'audit `/fiche/:id` (cf. `docs/aime-fiche-view-audit.md` §10) sont désormais **résolus** :

1. ✅ Vocabulaire « Signature électronique » → « Signature manuscrite visuelle » (cf. `aime-signature-wording-freeze.md`)
2. ✅ Vocabulaire « Hash / Empreinte SHA-256 » Studio → « Aperçu SHA-256 (indicatif) / non scellé » (présent freeze)

L'ensemble de la page `/fiche/:id` est désormais **intégralement conforme à la doctrine §7**, sans aucune modification de logique métier ni de scellement.

---

## 📌 Synthèse du freeze

| Item | Valeur |
|---|---|
| Fichier modifié | 1 (`SectionCertification.jsx`) |
| Opérations `anchor_replace` | 6 (dans un seul appel) |
| Lignes affectées | ~7 |
| Logique modifiée | ❌ Aucune |
| Calcul du hash local | ❌ Identique (5 champs, SHA-256, `crypto.subtle`) |
| Hash backend officiel | ❌ Non touché (8 champs `HASHED_FIELDS`) |
| Backend touché | ❌ Aucun |
| Routes modifiées | ❌ Aucune |
| Données affectées | ❌ Aucune |
| Templates documentaires | ❌ Aucun modifié |
| Verso / QR / `/verify` | ❌ Non touchés |
| Cockpit 507 | ❌ Non touché |
| Phase 2 EventCore | ⛔ NON démarrée |
| Verticale créée | ❌ Aucune |
| Conformité doctrine §7.2 / §7.3 | ✅ Atteinte |
| Rollback | 🟢 Trivial (< 30 s) |
| Risque résiduel | 🟢 Nul |

---

> **AIME Cachet reste strictement intact.**
> Le hash backend officiel (8 champs `HASHED_FIELDS` via `sealCachet`) demeure **la seule source de vérité technique**.
> L'aperçu Studio est désormais clairement identifié comme **indicatif local**, en cohérence avec la doctrine AIME CanvasCore §7.

— Fin du freeze documentaire `aime-section-certification-wording-freeze` —