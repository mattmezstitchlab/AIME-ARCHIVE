# Audit ciblé — Page `/fiche/:id`

**Date** : 23 mai 2026
**Type** : audit documentaire — **lecture seule, aucun code modifié**
**Périmètre** : page `pages/FicheView` et toutes ses dépendances directes
**Objectif** : comprendre précisément comment cette page fonctionne et évaluer son potentiel comme cœur AIME CanvasCore, **sans rien casser** d'AIME Cachet

> Ce document est un audit. Il ne déclenche aucune action technique. Il ne modifie ni route, ni UI, ni template, ni hash. Phase 2 EventCore non démarrée.

---

## 1. Page et route

### 1.1 Identifiants

| Élément | Valeur |
|---|---|
| Fichier source | `pages/FicheView.jsx` (433 lignes) |
| Route applicative | `/fiche/:id` |
| Param URL | `id` (ID Prestation) → lu via `useParams()` |
| Composant exporté | `export default function FicheView()` |
| Persistance | Entité `Prestation` (Base44) |
| Génération PDF | `lib/ficheGenerator.js` (côté client, `jspdf`) |
| Page publique liée | `/verify/:cachetCode` (consultation lecture seule) |

### 1.2 Imports (vue d'ensemble)

| Catégorie | Modules importés |
|---|---|
| React | `useEffect`, `useRef`, `useState`, `useCallback` |
| Router | `useParams`, `useNavigate` |
| SDK | `base44` (entités + intégrations) |
| UI | `Pencil`, `Check` (lucide), `toast` (sonner) |
| Helpers | `generateFichePDF`, `generateCachetCode`, `formatTimestampFR`, `logEvent`, `FICHE_BACKGROUNDS`, `FONT_PRESETS`, `ACCENT_COLORS`, `PAPER_FORMATS`, `WATERMARK_PRESETS` |
| Templates `*Paper` (14) | Fiche, Devis, NoteHonoraires, Recu, Presence, Cession, Frais, Dpae, Aem, AttPe, Guso, CddU, CessionDroits, Avenant |
| Composants | `ToolPalette`, `StampDialog`, `DocPicker`, `SignaturePad`, `StudioPanel`, `FicheVerso`, `FicheTopBar`, `SideRail`, `SealButton` |

### 1.3 Composants enfants directs

| Composant | Rôle |
|---|---|
| `FicheTopBar` | Barre haute : `DocPicker` + bouton Verso + `SealButton` |
| `SideRail` (mobile/desktop) | Navigation latérale globale |
| `ToolPalette` | Barre flottante basse : Modifier, Signer, Tampon, Réinit, `SaveMenu` |
| `StampDialog` | Modale de configuration du tampon |
| `SignaturePad` | Modale de signature dessinée |
| `StudioPanel` | Tiroir latéral droit (5 sections) |
| `FicheVerso` | Verso (QR + métadonnées) |
| `PAPERS[docType]` | Template documentaire courant (l'un des 14) |
| `SealButton` (inline + flottant) | Bouton scellement technique |

### 1.4 Données chargées

```
useEffect → base44.entities.Prestation.get(id)
  → si pas de cachet_code → generateCachetCode() + Prestation.update()
  → setPrestation(p)
  → setDocType(p.doc_type || "cachet")
  → setCustomNotes(p.custom_notes || "")
```

**Source unique** : entité `Prestation` (champs `id`, `cachet_code`, `doc_type`, `custom_notes`, `verification_hash`, `verification_hash_at`, et tous les champs métier intermittence — date, employer, location, type, sector, annexe, etc.).

### 1.5 Actions disponibles (vue utilisateur)

| Action | Trigger | Effet |
|---|---|---|
| Choisir un document | `DocPicker` → `handleDocChange` | `setDocType` + `Prestation.update({doc_type})` |
| Basculer recto/verso | Bouton verso `FicheTopBar` | `setFlipped` (animation 3D 900ms) |
| Sceller la fiche | `SealButton` | `base44.functions.invoke("sealCachet")` |
| Éditer le texte | Toggle Studio ou bouton crayon | `setTextEditable(true)` → `contentEditable` sur le papier |
| Valider l'édition | Bouton ✓ | Persiste `custom_notes` dans `Prestation` |
| Poser un tampon | `StampDialog` puis clic sur le papier | Position locale (non persistée) |
| Apposer une signature | `SignaturePad` | Affichage local (non persistée) |
| Télécharger PDF | `SaveMenu → onDownload` | `generateFichePDF()` + `logEvent` |
| Cloud AIME | `SaveMenu → onCloud` | `logEvent` (event tracking) |
| Partager (email/WA/SMS/lien) | `SaveMenu` items | `mailto:`, `wa.me`, `sms:`, `navigator.clipboard` avec préfixe brouillon |
| Personnaliser | `StudioPanel` (5 sections) | États locaux (theme/background/font/accent/format/logo/watermark/headerText/showQR/showHash) |
| Audit IA | `SectionIA → runAudit` | `base44.integrations.Core.InvokeLLM` |
| Importer logo | `SectionIdentite` | `base44.integrations.Core.UploadFile` |

### 1.6 Risques de modification

| Risque | Niveau | Commentaire |
|---|---|---|
| Casser le scellement | 🔴 Critique | `SealButton` calcule un hash via `verificationHash.js` (8 champs figés `HASHED_FIELDS`). Tout renommage de champ casse les fiches déjà scellées. |
| Casser la persistance | 🟠 Élevé | `Prestation.update({doc_type})` immédiate + `custom_notes` débouncé 800 ms. Toute refonte du flux doit préserver les deux. |
| Casser le routage | 🟠 Élevé | `useParams().id` → `Prestation.get(id)`. Tout renommage de param ou d'entité casse la page. |
| Casser le PDF | 🟡 Moyen | `generateFichePDF` ne gère que 4 types (`cachet`, `devis`, `honoraires`, `recu`). Les 10 autres types sortent en PDF "cachet" générique. |
| Régression visuelle Studio | 🟡 Moyen | 5 sections couplées par 18 props. Toute extraction de logique générique doit conserver l'API. |

---

## 2. Canvas central

### 2.1 `FichePaper` (`components/aime/fiche/FichePaper`)

| Aspect | Constat |
|---|---|
| Dimensions | `width: 210mm; minHeight: 297mm; padding: 18mm` (A4 fixe en CSS) |
| Format réel | A4 portrait — **non variable** malgré le sélecteur `PAPER_FORMATS` |
| Champs rendus | 4 sections : A. Prestation, B. Employeur, C. Chemin admin, D. Documents à préparer (8 cases à cocher figées) |
| Édition inline | `textEditable` → ajoute `contentEditable + suppressContentEditableWarning` sur chaque cellule |
| Watermark | `DraftWatermark` importé… mais retourne `null` (voir §7.4 — désactivé) |
| Badge "Préparatoire" | Coin haut-droit, en dur |
| Tampon | Positionné absolu via `stampPosition` (non persisté entre rechargements) |
| Mentions légales | En dur (paragraphe affiliation organismes) |

**Verdict** : papier strictement A4, contenu strictement intermittent. Le format `PAPER_FORMATS` du Studio est exposé mais **non câblé** sur les `*Paper.jsx` (les composants n'acceptent pas `paperFormat` en prop).

### 2.2 `FicheTopBar` (`components/aime/fiche/FicheTopBar`)

Composé de :
- `GlobalToolbar` (toolbar globale droite, `showBack={false}`)
- Bloc gauche : `DocPicker` (embedded) + bouton verso + `SealButton` (inline)

Positionnement : `fixed top-3 left-3 right-3 sm:right-auto lg:left-20`. Pas d'`overflow-x-auto` (volontaire — éviterait le popover du DocPicker).

### 2.3 Recto / Verso

| Aspect | Constat |
|---|---|
| Animation | `transformStyle: preserve-3d` + `rotateY(0 / 180deg)` + `transition 900ms` |
| Perspective | `perspective: 2400px` sur le conteneur parent |
| Trigger | Bouton verso (TopBar) OU clic libre sur papier (si pas en édition / pas en studio / pas en stamp mode) |
| Backfaces | `backfaceVisibility: hidden` sur les deux faces |
| Stop propagation | Le verso a son propre `onClick` qui force `setFlipped(false)` |

### 2.4 Formats papier vs affichage mobile/desktop

| Mode | Stratégie |
|---|---|
| Échelle | `paperScale` calculé sur `window.innerWidth` |
| < 640px | `(vw - 32) / 794` (min 0.4) |
| < 1024px | `0.7` |
| ≥ 1024px | `0.85` |
| Recalcul | À chaque `resize`, listener nettoyé en `useEffect` cleanup |
| Mode édition | `cursor: pointer` (ou `crosshair` si `stampMode`) |

**Note** : le scale ne dépend **pas** de l'ouverture du Studio (commentaire explicite ligne 100-101 — le Studio flotte par-dessus, sans pousser la fiche).

### 2.5 Champs éditables et persistance

Deux mécanismes coexistent :

1. **Édition inline `contentEditable`** sur chaque `Row` du papier (déclenchée par `textEditable=true`).
   - À la validation (`handleValidateEdit`) → lecture des `[contenteditable="true"]` du `paperRef`, concaténation par ` · `, écriture dans `prestation.custom_notes`.
   - ⚠️ **Limite** : la concaténation écrase les valeurs individuelles. C'est un agrégat de notes, pas une édition champ par champ. Les valeurs natives (`date`, `employer`, etc.) ne sont **pas** modifiées par cette voie.

2. **Notes libres** (textarea dans `SectionContenu` du Studio).
   - Débouncé 800 ms via `useEffect` → `Prestation.update({custom_notes})`.

| Aspect | Constat |
|---|---|
| Édition réelle des champs Prestation | ❌ Non depuis cette page (pas d'éditeur de champs métier ici) |
| Édition `custom_notes` | ✅ Oui (Studio textarea + agrégat contentEditable) |
| Édition `doc_type` | ✅ Oui (DocPicker) |
| Édition `cachet_code` | ❌ Non (auto-généré une fois, immuable ensuite) |
| Édition `verification_hash` | ❌ Non depuis le frontend (uniquement via `sealCachet` backend) |

### 2.6 État réel vs mock

| Élément | Réel | Mock |
|---|---|---|
| Données prestation | ✅ Réel (Base44) | — |
| `cachet_code` | ✅ Réel + auto-généré | — |
| `verification_hash` | ✅ Réel (calcul backend) | — |
| `custom_notes` | ✅ Réel (persisté) | — |
| `theme`, `background`, `font`, `accent`, `paperFormat` | ❌ Volatil (state local React) | — |
| `logoUrl` | ⚠️ Upload réel via `Core.UploadFile` mais URL non persistée sur Prestation |
| `watermark`, `headerText` | ❌ Volatil | — |
| `stamp`, `stampPosition` | ❌ Volatil (perdus au reload) | — |
| `signature` | ❌ Volatile (perdue au reload) | — |
| `showQR`, `showHash` | ❌ Volatils | — |

**Conséquence** : le Studio **ne persiste rien** de ses choix visuels. C'est une session d'édition jetable. Voir §10 pour l'impact CanvasCore.

---

## 3. Bibliothèque AIME

### 3.1 `DocPicker` (`components/aime/fiche/DocPicker`)

| Aspect | Constat |
|---|---|
| Mode | `embedded` (intégré dans `FicheTopBar`) |
| Source | `DOC_CATEGORIES` depuis `lib/docCatalog.js` |
| Catégories | 4 (Spectacle vivant, Facturation, Déclarations, Contrats) |
| Documents totaux | 14 (tous `ready: true`) |
| Filtre `ready` | Géré : un doc `ready: false` aurait label « Bientôt » et serait désactivé. **Aucun doc dans cet état actuellement.** |
| Picker visuel | Popover absolu, max-height 70vh, scroll vertical |
| CTA « Demander un nouveau document » | Présent mais sans handler (purement visuel) |
| Sélection | `onSelect(doc.id)` → `handleDocChange` → persiste `doc_type` |

### 3.2 `DocSwitcher` (`components/aime/fiche/DocSwitcher`)

⚠️ **Composant existant mais non utilisé** dans `FicheView`. Référence `DOC_TEMPLATES` (4 docs seulement). Code legacy — n'est plus la source de vérité.

### 3.3 `DocMenu` (`components/aime/fiche/DocMenu`)

⚠️ **Composant existant mais non utilisé** dans `FicheView`. Référence également `DOC_TEMPLATES` (4 docs). Code legacy.

### 3.4 `docCatalog.js`

Catalogue complet et structuré. Catégories + presets visuels en un seul module :

| Export | Contenu |
|---|---|
| `DOC_CATEGORIES` | 4 catégories × 14 docs |
| `PAPER_FORMATS` | 4 formats (a4, a5, ticket, card) |
| `FONT_PRESETS` | 5 polices (inter, bebas, playfair, mono, caveat) |
| `ACCENT_COLORS` | 8 couleurs |
| `WATERMARK_PRESETS` | 5 (aucun, prep, brouillon, copie, specimen) |
| `findDoc(docId)` | Helper de lookup |

### 3.5 Bibliothèque — bilan

| Aspect | Constat |
|---|---|
| Documents affichés | 14 (DocPicker) |
| Documents réellement rendus comme React component | ✅ 14/14 (tous dans `PAPERS` de FicheView) |
| Documents éditables (`textEditable`) | ✅ 14/14 |
| Documents exportables PDF | ⚠️ **4/14 seulement** (cachet, devis, honoraires, recu). Les 10 autres passent en fallback `drawCachet` (PDF cachet générique). |
| Documents documentés DocSwitcher/DocMenu | ❌ 4/14 (composants legacy) |
| Documents manquants | Voir §11 |

---

## 4. Templates documents (14)

Pour chacun : rôle, état, champs, manques, risque, potentiel.

### 4.1 `FichePaper` (Cachet)

| Aspect | Détail |
|---|---|
| Rôle | Fiche récapitulative d'une prestation intermittente |
| État | ✅ Réel — toutes les données Prestation rendues |
| Champs utilisés | date, duration_hours, location, nature, type, sector, annexe, amount, employer, employer_contact, employer_email, employer_phone, employer_siret, employer_kind, missing_documents, status, cachet_code |
| Champs manquants | Aucun (le plus complet) |
| Risque juridique | ✅ Disclaimers explicites + badge "Préparatoire" + mentions affiliation |
| Potentiel générique | 🟢 **Très élevé** — c'est le canvas le plus proche d'un "Record générique" : un en-tête, des sections nommées, des rows label/value, un footer. |

### 4.2 `DevisPaper`

| Aspect | Détail |
|---|---|
| Rôle | Devis émetteur → destinataire (artiste vers structure) |
| État | ⚠️ Semi-réel — montre les données Prestation, mais "Émetteur" (artiste) = `"Votre nom"` en dur |
| Champs utilisés | date, employer, employer_contact, employer_email, employer_siret, nature, location, duration_hours, amount |
| Champs manquants | Nom de l'artiste, SIRET artiste, Adresse artiste, N° licence artiste (tous en `(à compléter)` ou `"Votre nom"`) |
| Risque juridique | ✅ Mention TVA art. 293 B + disclaimer préparatoire |
| Potentiel générique | 🟢 Élevé — modèle "tableau de prestations + total" rejouable pour facture événementielle, devis prestataire mariage, etc. |

### 4.3 `NoteHonorairesPaper`

| Aspect | Détail |
|---|---|
| Rôle | Note d'honoraires artiste-auteur (MdA / Urssaf Limousin) |
| État | ⚠️ Semi-réel — "Votre nom" + "(à compléter)" pour identité artiste-auteur |
| Champs utilisés | date, employer, employer_contact, employer_siret, nature, location, amount |
| Champs manquants | Identité artiste-auteur, N° SS artiste-auteur, SIRET artiste-auteur, RIB |
| Risque juridique | ✅ Disclaimers précompte + art. 293 B CGI + affiliation MdA/Urssaf |
| Potentiel générique | 🟡 Moyen — très spécifique au régime MdA, peu transférable hors intermittence. |

### 4.4 `RecuPaper`

| Aspect | Détail |
|---|---|
| Rôle | Reçu de versement signé bénéficiaire / payeur |
| État | ⚠️ Semi-réel — "Votre nom" en dur, montant affiché en chiffres uniquement (pas de conversion en lettres réelle) |
| Champs utilisés | date, employer, amount, nature, location, cachet_code |
| Champs manquants | Nom bénéficiaire, conversion montant en lettres (string générique `"X euros"`) |
| Risque juridique | ✅ Disclaimer "ne remplace ni bulletin, ni AEM, ni quittance" |
| Potentiel générique | 🟢 Élevé — modèle "reçu / quittance" rejouable (caution, acompte, dépôt). |

### 4.5 `PresencePaper`

| Aspect | Détail |
|---|---|
| Rôle | Feuille d'émargement (8 lignes vides) sur scène / plateau |
| État | ✅ Réel pour bloc Production + ❌ Mock pour tableau (8 lignes toutes vides) |
| Champs utilisés | date, employer, location, nature |
| Champs manquants | Liste des présents (aucun mécanisme de saisie multi-personnes) |
| Risque juridique | ✅ Disclaimer "ne remplace pas le registre unique" |
| Potentiel générique | 🟢 Très élevé — modèle "liste émargée" rejouable pour invités mariage, participants atelier, intervenants conférence. |

### 4.6 `CessionPaper` (Convention de cession)

| Aspect | Détail |
|---|---|
| Rôle | Cession droits de représentation entre producteur (cédant) et organisateur (cessionnaire) |
| État | ⚠️ Semi-réel — cédant = "Votre raison sociale" en dur |
| Champs utilisés | date, employer, employer_siret, employer_contact, nature, location, amount |
| Champs manquants | Identité cédant, SIRET cédant, Licence entrepreneur, Description détaillée du spectacle |
| Risque juridique | ✅ Mention licence + disclaimer "faire relire par avocat" |
| Potentiel générique | 🟡 Moyen — modèle juridique très spectacle vivant. |

### 4.7 `FraisPaper`

| Aspect | Détail |
|---|---|
| Rôle | Note de frais (transport, hébergement, repas) |
| État | ❌ Mock — 6 catégories préremplies + 4 lignes vides, tous montants `—` |
| Champs utilisés | date, employer, location, nature |
| Champs manquants | Aucun mécanisme de saisie des lignes de frais |
| Risque juridique | ✅ Disclaimer + obligation justificatifs |
| Potentiel générique | 🟢 Élevé — modèle "ligne de frais répétée" rejouable. |

### 4.8 `DpaePaper`

| Aspect | Détail |
|---|---|
| Rôle | Déclaration Préalable À l'Embauche (URSSAF) — brouillon |
| État | ⚠️ Semi-réel pour employeur, ❌ Mock pour salarié ("Votre nom" / "—") |
| Champs utilisés | date, employer, employer_siret, type, annexe, duration_hours, location |
| Champs manquants | N° SS salarié, Date naissance, Lieu naissance, Nationalité, Adresse employeur, N° adhésion médecine du travail |
| Risque juridique | 🔴 **Sensible** — formulaire officiel URSSAF. Disclaimer explicite "ne tient pas lieu de déclaration officielle". À surveiller. |
| Potentiel générique | 🔴 Faible — strictement intermittence. **À protéger.** |

### 4.9 `AemPaper`

| Aspect | Détail |
|---|---|
| Rôle | Attestation Employeur Mensuelle (Pôle Emploi Spectacle / France Travail) |
| État | ⚠️ Semi-réel — 1 ligne remplie + 5 lignes vides dans le tableau |
| Champs utilisés | date, employer, employer_siret, annexe, nature, duration_hours, amount |
| Champs manquants | Identité salarié complète, mécanisme multi-lignes, totaux calculés |
| Risque juridique | 🔴 **Sensible** — base du calcul ARE 507h. Disclaimer "ne se substitue pas à l'AEM officielle". |
| Potentiel générique | 🔴 Faible — strictement intermittence. **À protéger.** |

### 4.10 `AttPePaper` (Attestation Pôle Emploi)

| Aspect | Détail |
|---|---|
| Rôle | Attestation employeur de fin de contrat (France Travail) |
| État | ⚠️ Semi-réel — employeur réel, salarié en "Votre nom" |
| Champs utilisés | date, employer, employer_siret, employer_contact, type, annexe, duration_hours, amount |
| Champs manquants | N° SS, adresse salarié, indemnité congés payés, précarité |
| Risque juridique | 🔴 **Sensible** — document officiel France Travail. Disclaimer explicite. |
| Potentiel générique | 🔴 Faible — strictement intermittence. **À protéger.** |

### 4.11 `GusoPaper`

| Aspect | Détail |
|---|---|
| Rôle | Déclaration GUSO (Guichet Unique Spectacle Occasionnel) |
| État | ⚠️ Semi-réel — employeur réel, salarié + cotisations en dur |
| Champs utilisés | date, employer, employer_siret, employer_contact, type, nature, duration_hours, location, amount |
| Champs manquants | N° SS, adresse salarié, calcul réel des cotisations (Urssaf/France Travail/AFDAS/CMB/Audiens/Congés Spectacles), net à verser |
| Risque juridique | 🔴 **Sensible** — formulaire guso.fr. Disclaimer "récapitulatif de relecture". |
| Potentiel générique | 🔴 Faible — strictement intermittence. **À protéger.** |

### 4.12 `CddUPaper`

| Aspect | Détail |
|---|---|
| Rôle | Contrat à Durée Déterminée d'Usage (CDD U) — articles L.1242-2 3° et D.1242-1 |
| État | ⚠️ Semi-réel pour employeur, ❌ Mock pour salarié |
| Champs utilisés | date, employer, employer_siret, employer_contact, type, annexe, duration_hours, location, amount |
| Champs manquants | Salarié (nom, naissance, SS, adresse), Licence entrepreneur, Convention collective spécifique |
| Risque juridique | 🔴 **Sensible** — contrat de travail. Disclaimer "ne remplace pas un contrat validé par avocat". |
| Potentiel générique | 🟡 Moyen — squelette "contrat avec articles" rejouable, mais le contenu intermittent est très spécifique. |

### 4.13 `CessionDroitsPaper`

| Aspect | Détail |
|---|---|
| Rôle | Cession de droits voisins de l'artiste-interprète (articles L.211-1 et suivants CPI) |
| État | ⚠️ Semi-réel — cessionnaire réel, cédant en "Votre nom" |
| Champs utilisés | date, employer, employer_siret, employer_contact, nature, location, amount |
| Champs manquants | Identité cédant complète, étendue territoriale précise, exploitations secondaires |
| Risque juridique | 🟠 Élevé — droits de propriété intellectuelle. Disclaimer "faire relire par avocat spécialisé". |
| Potentiel générique | 🟡 Moyen — modèle "contrat de cession" rejouable, mais le CPI est spécifique. |

### 4.14 `AvenantPaper`

| Aspect | Détail |
|---|---|
| Rôle | Avenant à un contrat existant (modification de date, durée, montant, lieu, nature) |
| État | ✅ Bon squelette — affiche valeurs initiales avec ligne barrée + colonne "nouvelle valeur" à compléter |
| Champs utilisés | date, employer, location, duration_hours, amount, nature, cachet_code |
| Champs manquants | Champ "nouvelle valeur" non saisissable directement (à compléter manuellement à la main / impression) |
| Risque juridique | 🟠 Élevé — modification de contrat de travail. Disclaimer "faire relire par conseil spécialisé". |
| Potentiel générique | 🟢 Élevé — modèle "avant / après" rejouable (révision de devis, modification de billet, modification d'inscription). |

### 4.15 Tableau de synthèse templates

| Doc | État | Risque juridique | Potentiel générique | PDF dédié ? |
|---|---|---|---|---|
| Cachet | ✅ Complet | 🟢 Encadré | 🟢 Très élevé | ✅ |
| Devis | ⚠️ Semi-mock | 🟢 Encadré | 🟢 Élevé | ✅ |
| Honoraires | ⚠️ Semi-mock | 🟢 Encadré | 🟡 Moyen | ✅ |
| Reçu | ⚠️ Semi-mock | 🟢 Encadré | 🟢 Élevé | ✅ |
| Présence | ⚠️ Mock partiel | 🟢 Encadré | 🟢 Très élevé | ❌ fallback cachet |
| Cession | ⚠️ Semi-mock | 🟠 Élevé | 🟡 Moyen | ❌ fallback cachet |
| Frais | ❌ Mock total | 🟢 Encadré | 🟢 Élevé | ❌ fallback cachet |
| DPAE | ⚠️ Semi-mock | 🔴 Sensible | 🔴 Faible | ❌ fallback cachet |
| AEM | ⚠️ Semi-mock | 🔴 Sensible | 🔴 Faible | ❌ fallback cachet |
| Att. PE | ⚠️ Semi-mock | 🔴 Sensible | 🔴 Faible | ❌ fallback cachet |
| GUSO | ⚠️ Semi-mock | 🔴 Sensible | 🔴 Faible | ❌ fallback cachet |
| CDD U | ⚠️ Semi-mock | 🔴 Sensible | 🟡 Moyen | ❌ fallback cachet |
| Cession droits | ⚠️ Semi-mock | 🟠 Élevé | 🟡 Moyen | ❌ fallback cachet |
| Avenant | ✅ Bon squelette | 🟠 Élevé | 🟢 Élevé | ❌ fallback cachet |

---

## 5. Studio à droite

### 5.1 `StudioPanel` (panneau-mère)

| Aspect | Constat |
|---|---|
| Position | `fixed top-0 right-0 bottom-0 z-50 w-full sm:w-[340px]` |
| Mode mobile | Overlay sombre + dismiss au clic |
| Mode desktop | Tiroir flottant non-bloquant (le canvas reste visible) |
| Sections | 5 (`StudioSection` accordéons) |
| Header | "Studio · Créer · Sceller · Personnaliser" |
| Footer | "Document préparatoire AIME. Sans valeur officielle." |
| Props reçues | 18 props bidirectionnelles (state lifting depuis `FicheView`) |

### 5.2 `SectionApparence`

| Option | Réel ? | Modifie canvas ? | Persisté ? | Exporté PDF ? | Universel ? |
|---|---|---|---|---|---|
| Fond visuel (`FICHE_BACKGROUNDS` × 10) | ✅ | ✅ (bg derrière la fiche) | ❌ | ❌ (PDF n'utilise pas le fond) | 🟢 Oui |
| Thème clair/sombre | ✅ | ✅ (passé en prop aux `*Paper`) | ❌ | ❌ | 🟢 Oui |
| Couleur d'accent (`ACCENT_COLORS` × 8) | ⚠️ Partiel | ⚠️ Watermark + headerText uniquement | ❌ | ❌ | 🟢 Oui |
| Police (`FONT_PRESETS` × 5) | ✅ | ✅ (CSS `fontFamily` du wrapper) | ❌ | ❌ (PDF utilise helvetica) | 🟢 Oui |
| Format papier (`PAPER_FORMATS` × 4) | ⚠️ **Visuel uniquement** | ❌ (les `*Paper` ignorent ce param et restent A4) | ❌ | ❌ | 🟢 Oui (potentiel) |

### 5.3 `SectionIdentite`

| Option | Réel ? | Modifie canvas ? | Persisté ? | Exporté PDF ? | Universel ? |
|---|---|---|---|---|---|
| Logo (upload) | ✅ Upload réel via `Core.UploadFile` | ✅ (overlay top-right) | ❌ URL non persistée | ❌ | 🟢 Oui |
| En-tête personnalisé (text) | ✅ | ✅ (overlay top-center) | ❌ | ❌ | 🟢 Oui |
| Filigrane (`WATERMARK_PRESETS` × 5) | ✅ | ✅ (texte diagonal) | ❌ | ❌ | 🟢 Oui |

### 5.4 `SectionContenu`

| Option | Réel ? | Modifie canvas ? | Persisté ? | Exporté PDF ? | Universel ? |
|---|---|---|---|---|---|
| Toggle édition inline | ✅ | ✅ (`contentEditable`) | ✅ via `custom_notes` agrégé | ✅ (custom_notes dans PDF cachet section C) | 🟢 Oui |
| Notes libres (textarea) | ✅ | ⚠️ (non visible directement sur le papier — affichées dans le PDF) | ✅ débouncé 800 ms | ✅ | 🟢 Oui |
| Ajouter une page | ❌ "Bientôt" (disabled) | — | — | — | — |
| Réorganiser sections | ❌ "Bientôt" (disabled) | — | — | — | — |

### 5.5 `SectionCertification`

| Option | Réel ? | Modifie canvas ? | Persisté ? | Exporté PDF ? | Universel ? |
|---|---|---|---|---|---|
| QR de vérification | ✅ Toujours rendu sur verso | Toggle local visuel | ❌ | ✅ QR dans PDF (`drawVerifyQR`) | 🟢 Oui |
| Empreinte SHA-256 (visible) | ⚠️ Hash recalculé **localement** sur 5 champs (code, employer, date, amount, timestamp) ≠ hash backend officiel (8 champs) | Affichage uniquement | ❌ | ❌ | ⚠️ À unifier |
| Horodatage | ⚠️ `new Date()` au mount (volatil) | Affichage | ❌ | ❌ | ⚠️ |

⚠️ **Note importante** : `SectionCertification` calcule un hash local qui **n'est pas** le hash officiel `verification_hash` du backend. C'est un affichage informatif qui peut prêter à confusion. Le hash officiel reste celui produit par `sealCachet` (8 champs `HASHED_FIELDS`).

### 5.6 `SectionIA`

| Option | Réel ? | Modifie canvas ? | Persisté ? | Exporté PDF ? | Universel ? |
|---|---|---|---|---|---|
| Audit conformité (LLM) | ✅ via `InvokeLLM` (`claude_sonnet_4_6` non spécifié → modèle auto) | ❌ (affiche un résultat sous la section) | ❌ | ❌ | 🟢 Oui |
| Vérifier SIRET (INSEE Sirene) | ❌ "Bientôt" | — | — | — | 🟢 (potentiel élevé) |
| Traduire (EN/ES/IT) | ❌ "Bientôt" | — | — | — | 🟢 (potentiel élevé) |

Voir §9 pour audit détaillé IA.

### 5.7 `ToolPalette` (barre flottante basse)

| Bouton | Action | Réel ? |
|---|---|---|
| Modifier | `setStudioOpen(true)` | ✅ |
| Signer | `setSignaturePadOpen(true)` | ✅ |
| Tampon | `setStampDialogOpen(true)` | ✅ |
| Effacer (si tampon présent) | `onResetStamp` | ✅ |
| Enregistrer (`SaveMenu`) | Voir §5.8 | ✅ |

### 5.8 `SaveMenu`

| Item | Réel ? | Persisté ? |
|---|---|---|
| Télécharger PDF | ✅ `generateFichePDF` + `logEvent("document_generated")` | ✅ event tracking |
| Cloud AIME | ⚠️ `logEvent` uniquement — pas d'upload réel du PDF dans un dossier cloud distinct | ✅ event tracking |
| Email (`mailto:`) | ✅ ouvre app messagerie | ❌ |
| WhatsApp (`wa.me`) | ✅ ouvre WhatsApp | ❌ |
| SMS (`sms:`) | ✅ ouvre app SMS | ❌ |
| Copier le lien | ✅ avec préfixe `[BROUILLON AIME — non opposable]` | ❌ |

### 5.9 `EditMenu`

⚠️ **Composant existant mais non utilisé** dans `FicheView` (remplacé par `StudioPanel`). Code legacy.

### 5.10 `ShareMenu`

⚠️ **Composant existant mais non utilisé** dans `FicheView` (la fonction de partage est intégrée dans `SaveMenu`). Code legacy mais bien fait — reste réutilisable.

---

## 6. Verso / QR / vérification

### 6.1 `FicheVerso`

| Section | Contenu |
|---|---|
| Header | "AIME · VERSO · Page de vérification" |
| Hero | "Scannez pour vérifier" + `QRBadge` size=200 + cachetCode mono |
| Métadonnées | Code Cachet, Date prestation, Créé le (`created_date` formaté FR), URL vérification |
| Mentions | Disclaimer affiliation + "AIME prépare. L'utilisateur vérifie. L'organisme officiel valide." |
| Watermark | `DraftWatermark` (actuellement neutralisé — voir §7.4) |

### 6.2 `QRBadge`

| Aspect | Détail |
|---|---|
| Implémentation | API publique `quickchart.io/qr` (gratuit, sans backend) |
| Format URL | `?text=${encodeURIComponent(value)}&size=${size*3}&margin=1&ecLevel=M` |
| Dépendance externe | ⚠️ Service tiers — risque de panne externe |
| Universel ? | 🟢 Oui — composant pur, agnostique du métier |

### 6.3 `cachetCode` et `verifyUrl`

```
cachetCode = prestation.cachet_code || generateCachetCode()
verifyUrl = `${window.location.origin}/verify/${cachetCode}`
fallback = `${window.location.origin}/fiche/${prestation.id}`  // si pas de code
```

| Aspect | Détail |
|---|---|
| Format `cachet_code` | `AIME-CCH-YYYYMMDD-XXXXXX` (préfixe figé) |
| Auto-génération | Au premier chargement si absent (`useEffect` charge prestation) |
| Persistance | ✅ `Prestation.update({cachet_code})` immédiate |
| Immuabilité | ✅ Jamais regénéré ensuite |

### 6.4 Page `/verify/:cachetCode`

(rappel de l'audit Phase 1 — fichier protégé, non modifié)

| Aspect | Détail |
|---|---|
| Lecture | `base44.functions.invoke('verifyCachet', { code })` (backend asServiceRole) |
| Whitelist publique | 8 champs : `cachet_code`, `status`, `prestationDate`, `employerName`, `location`, `prestationType`, `sector`, `annex` + `verificationStatus`, `documentHash`, `expectedHash`, `hashSealedAt` |
| Données masquées | ❌ Jamais exposés : NIR, RIB, montants, signatures, notes privées, email/téléphone employeur, SIRET employeur |
| Empreinte vérifiée | `HashCheckBadge` avec 3 états (`match`, `mismatch`, `absent`) |
| Mentions légales | Toujours affichées, même si fiche introuvable |

### 6.5 `HashCheckBadge`

3 états strictement neutres :
- `match` → "Cohérence technique vérifiée"
- `mismatch` → "Incohérence technique détectée"
- `absent` → "Hash non disponible"

**Vocabulaire conforme** à la doctrine : jamais "certifié", "officiel", "validé administrativement", "preuve opposable".

### 6.6 Potentiel universel verso/QR

🟢 **Très élevé**. Le triptyque verso + QR + page publique avec whitelist est :
- agnostique du métier (le verso n'affiche que `cachet_code`, `date`, `created_date`, URL — données génériques) ;
- réutilisable pour n'importe quel objet AIME (invitation, billet, badge, attestation) ;
- déjà sécurisé (whitelist côté backend, jamais d'exposition de données sensibles).

**À conserver tel quel.** C'est probablement l'un des composants les plus mûrs et les plus réutilisables d'AIME.

---

## 7. Scellement

### 7.1 `SealButton`

| Aspect | Détail |
|---|---|
| Mode | `inline` (TopBar) + mode flottant (desktop fixed + mobile bottom-right) |
| Calcul live du hash | `computeVerificationHash(publicPayload)` côté frontend (mêmes 8 champs que backend) |
| Comparaison | `hashesMatch(storedHash, liveHash)` → 3 états : `never`, `synced`, `stale` |
| Modale de confirmation | Explicite : "Calcul SHA-256 sur 8 champs publics. Aucune donnée sensible (montants, RIB, NIR, signatures, notes privées)." |
| Appel backend | `base44.functions.invoke("sealCachet", { prestationId })` |
| Persistance | ✅ `verification_hash` + `verification_hash_at` mis à jour |
| Toast | "Cohérence technique scellée. Empreinte technique enregistrée. Ne constitue pas une certification officielle." |
| Lien après scellement | Lien vers `/verify/:cachetCode` |

✅ Vocabulaire parfaitement conforme à la doctrine. À protéger.

### 7.2 `StampDialog`

| Aspect | Détail |
|---|---|
| Personnalisation | Texte principal (12 char max), texte du haut (24 char), couleur (4 presets) |
| Presets | "PRÉPARÉ", "BROUILLON", "À VÉRIFIER", "RELU" |
| Position du tampon | Sélectionnée par clic sur le papier après confirmation |
| Persistance | ❌ Tampon perdu au reload (state local FicheView uniquement) |
| Disclaimer | "Tampon privé sans valeur officielle." |
| Universel ? | 🟢 Très élevé |

### 7.3 `SignaturePad`

| Aspect | Détail |
|---|---|
| Canvas | 800 × 300 px, trait 2.5 px, couleur fixe `#0F0F0F` |
| Capture | mouse + touch (mobile) |
| Output | `dataURL` PNG |
| Persistance | ❌ Signature perdue au reload (state local) |
| ⚠️ Disclaimer manquant | Le composant titre "Signature électronique" sans préciser "non qualifiée" ni "ne vaut pas signature électronique qualifiée". À noter. |
| ⚠️ Label sur le papier | Dans `FicheView` ligne 376 : `"Signature électronique"` — **terme à requalifier** selon la doctrine ("signature manuscrite visuelle" / "signature non qualifiée"). |

🔴 **Risque vocabulaire** : à corriger ultérieurement (non urgent, mais identifié).

### 7.4 `DraftWatermark`

⚠️ **Composant neutralisé** : le code actuel retourne `null` quel que soit le statut. C'est un placeholder hérité. Les watermarks affichés sur les `*Paper` viennent des `WATERMARK_PRESETS` du Studio (filigrane sélectionné par l'utilisateur), pas de `DraftWatermark`.

**Impact** : aucune régression (le composant n'affichait déjà rien). À nettoyer un jour, sans urgence.

### 7.5 Hash, horodatage, état scellé / à resceller

| Élément | Détail |
|---|---|
| Champs hashés | 8 (`cachetCode`, `status`, `prestationDate`, `employerName`, `location`, `prestationType`, `sector`, `annex`) — strictement figés (`HASHED_FIELDS`) |
| Algorithme | SHA-256 via Web Crypto API |
| Canonicalisation | JSON ordonné par `HASHED_FIELDS`, valeurs `String(v).trim()` |
| Stockage | `verification_hash` + `verification_hash_at` sur Prestation |
| État stale | Recalcul live → comparaison → si différent → bandeau "À resceller" |
| Vocabulaire | ✅ Conforme : "empreinte technique", "cohérence technique" |

### 7.6 Risques scellement

| Risque | Niveau | Détail |
|---|---|---|
| Modification de `HASHED_FIELDS` | 🔴 Critique | Casserait toutes les fiches déjà scellées |
| Renommage de l'entité `Prestation` | 🔴 Critique | Casserait `sealCachet` et `verifyCachet` |
| Modification de `sealCachet`/`verifyCachet` | 🔴 Critique | Idem |
| Vocabulaire affirmatif ("certifié", "officiel") | 🔴 Critique juridique | Aucune occurrence actuellement, à préserver |

---

## 8. Partage / export

### 8.1 PDF

| Aspect | Détail |
|---|---|
| Lib | `jspdf` (côté client) |
| Format | A4 portrait |
| Routeur | `docType ∈ {devis, honoraires, recu}` sinon fallback `drawCachet` |
| ⚠️ Coverage | **4/14 documents** ont un rendu PDF dédié. Les 10 autres tombent sur le PDF Cachet générique. |
| Watermark PDF | `BROUILLON PRÉPARATOIRE — NON OPPOSABLE SANS VALEUR OFFICIELLE` diagonal, tant que `status !== "valide"` |
| Badge "Préparatoire" | Encadré top-right |
| Footer | Disclaimer affiliation + horodatage + cachetCode |
| QR PDF | `drawVerifyQR` via `quickchart.io` en image PNG bas-droite + mentions "VÉRIFICATION TECHNIQUE — Cohérence technique uniquement — pas une certification officielle." |
| Tampon PDF | Si présent, dessiné en SVG vectoriel rotation 0° |
| Nom de fichier | `aime-brouillon-${docType}-${slugEmployer}-${date}.pdf` |

### 8.2 Email / WhatsApp / SMS / lien

Tous gérés par `SaveMenu` (et `ShareMenu` legacy, non utilisé) :

| Canal | URL scheme | Préfixe `[BROUILLON AIME — non opposable]` |
|---|---|---|
| Email | `mailto:?subject=...&body=...` | ✅ via `buildShareSubject` + `buildShareBody` |
| WhatsApp | `https://wa.me/?text=...` | ✅ |
| SMS | `sms:?body=...` | ✅ |
| Copier le lien | `navigator.clipboard.writeText(SHARE_PREFIX + url)` | ✅ |

Toast systématique : "L'envoi réel n'est pas confirmé par AIME."

### 8.3 Cloud AIME

⚠️ **Implémentation incomplète** : `handleCloud` appelle uniquement `logEvent("document_generated")`. Aucun upload réel du PDF dans un dossier cloud distinct. Le toast affiché ("Brouillon sauvegardé dans Cloud AIME") peut prêter à confusion : ce qui est sauvegardé, c'est la fiche elle-même (déjà persistée sur Prestation), pas un PDF dans un cloud séparé.

### 8.4 Disclaimers et préfixes

| Sortie | Préfixe / mention |
|---|---|
| Partage email/SMS/WA/lien | `[BROUILLON AIME — non opposable]` |
| PDF | Watermark diagonal + footer + mention "préparatoire" |
| Verso | "Document préparatoire privé — sans valeur officielle" |
| Page `/verify/:cachetCode` | Mentions obligatoires + watermark "BROUILLON PRÉPARATOIRE · NON OPPOSABLE" |
| Toast scellement | "Empreinte technique enregistrée. Ne constitue pas une certification officielle." |

✅ Vocabulaire globalement conforme. Voir §7.3 pour le seul point de vigilance (label "Signature électronique" → à reformuler).

---

## 9. IA sur la fiche

### 9.1 `SectionIA`

| Outil | État | Détail |
|---|---|---|
| **Audit conformité** | ✅ Réel | `InvokeLLM` avec prompt "expert administratif spectacle vivant" + JSON schema `{status, summary, issues[]}` |
| **Vérifier SIRET** | ❌ "Bientôt" | Pas d'appel API INSEE Sirene |
| **Traduire** | ❌ "Bientôt" | Pas d'appel LLM |

### 9.2 Détail audit conformité

| Aspect | Détail |
|---|---|
| Modèle | Non spécifié (`InvokeLLM` par défaut → `gpt_5_mini` ou auto) |
| Prompt | "Tu es un expert administratif du spectacle vivant français. Analyse cette fiche de prestation et identifie les éventuels problèmes de conformité. Sois concis (max 3 points). Données : ${JSON.stringify(prestation)}" |
| ⚠️ Risque | Envoie **toute la prestation** au LLM, y compris `employer_siret`, `employer_email`, `employer_phone`, `amount`. Pas de sanitisation préalable. |
| Sortie | `{status, summary, issues[]}` affichée dans une carte sombre sous les boutons |
| Persistance | ❌ Le résultat n'est pas sauvegardé sur Prestation |

### 9.3 Pré-remplissage IA

❌ **Aucun mécanisme de pré-remplissage IA** sur cette page. Les champs sont uniquement remplis par lecture de `Prestation` (saisie utilisateur via d'autres pages comme `MesPrestations`).

### 9.4 Actions IA possibles (non implémentées)

| Action | Potentiel |
|---|---|
| Vérifier SIRET via API INSEE | 🟢 Élevé — gain d'authenticité |
| Traduction multilingue | 🟢 Élevé — utile pour cessions internationales |
| Détection de doublons | 🟡 Moyen |
| Suggestion d'employeur récent | 🟡 Moyen |
| Détection de risques juridiques | 🟢 Élevé — extension naturelle de l'audit |
| Génération de message employeur | 🟢 Élevé — existe ailleurs (`message_generated` dans HistoryEvent) |

### 9.5 Universalité IA

🟢 **Très élevé**. Le pattern "audit LLM + schema JSON + affichage" est rejouable pour n'importe quel objet AIME en changeant seulement le prompt et le schema.

---

## 10. Potentiel CanvasCore — Matrice

Tableau récapitulatif : **chaque brique de `/fiche/:id`** projetée sur le moteur CanvasCore.

| Élément actuel | Rôle AIME Cachet | Rôle CanvasCore possible | Réutilisable tel quel | À adapter | À protéger | Risque |
|---|---|---|---|---|---|---|
| `FicheView` (page) | Page d'édition fiche cachet | Page d'édition objet AIME générique | ❌ | 🟢 Oui (extraction d'une `CanvasView` paramétrée) | — | 🟡 Moyen (couplage Prestation) |
| `FichePaper` | Cachet intermittent | Modèle "Record générique avec sections" | 🟡 Squelette oui, contenu non | 🟢 Oui | 🟢 Le fichier actuel reste vertical intermittent | 🟢 Faible si on en extrait un `GenericPaper` |
| `FicheTopBar` | Topbar Cachet (Doc + Verso + Sceller) | Topbar universelle (Doc + Verso + Sceller) | 🟢 Oui | 🟡 Légère (les libellés) | — | 🟢 Faible |
| `DocPicker` + `DOC_CATEGORIES` | Bibliothèque Cachet (14 docs) | Bibliothèque universelle (n verticales × n catégories) | 🟢 Oui (le composant) | 🟢 Oui (les données — un catalogue par vertical) | — | 🟢 Faible |
| `DocSwitcher`, `DocMenu`, `EditMenu`, `ShareMenu` | Legacy (non utilisés) | À supprimer ou réutiliser tel quel | — | — | — | ⚠️ Code mort à documenter |
| `StudioPanel` | Studio Cachet (5 sections) | Studio universel (5 sections agnostiques) | 🟢 Oui | 🟡 La section "Contenu" devra accepter une liste de champs spécifiques au vertical | — | 🟢 Faible |
| `SectionApparence` | Apparence visuelle | Apparence universelle | 🟢 Oui | — | — | 🟢 Faible |
| `SectionIdentite` | Logo + filigrane + en-tête | Identité universelle | 🟢 Oui | — | — | 🟢 Faible |
| `SectionContenu` | Édition inline + notes | Édition universelle | 🟡 Oui pour notes, mécanisme inline à généraliser | 🟢 Oui | — | 🟡 Moyen |
| `SectionCertification` | QR + hash visible (5 champs locaux ≠ backend) | Certification universelle | 🟡 Le concept oui | 🔴 Oui — unifier avec le hash backend (8 champs) | — | 🟠 Élevé — confusion possible |
| `SectionIA` | Audit Cachet (LLM) | IA universelle (audit / SIRET / traduction) | 🟢 Oui (pattern) | 🟢 Oui (prompt par vertical) | — | 🟡 Sanitisation à ajouter |
| `ToolPalette` | Barre flottante (Modifier/Signer/Tampon/Save) | Barre universelle | 🟢 Oui | — | — | 🟢 Faible |
| `SaveMenu` | PDF + Cloud + Partage | Save universel | 🟢 Oui | 🟡 Cloud à brancher réellement | — | 🟢 Faible |
| `FicheVerso` | Verso QR + métadonnées | Verso universel | 🟢 Oui | 🟡 Le label "VERSO" et le hero peuvent rester | — | 🟢 Faible |
| `QRBadge` | QR via quickchart | QR universel | 🟢 Oui | — | — | 🟡 Service tiers (faible mais réel) |
| `/verify/:cachetCode` | Vérification publique Cachet | Vérification publique universelle | 🟢 Oui (le pattern) | 🟢 Oui (whitelist par vertical) | 🔴 **Le profil `intermittence_v1` reste figé** | 🔴 Critique si on touche au hash |
| `HashCheckBadge` | Badge cohérence | Badge universel | 🟢 Oui | — | — | 🟢 Faible |
| `SealButton` + `sealCachet` + `verifyCachet` | Scellement Cachet | Scellement universel (un profil par vertical) | 🟢 Oui (le pattern) | 🟢 Oui (`HASH_PROFILES_PLANNED`) | 🔴 **Les fonctions et `HASHED_FIELDS` restent figés** | 🔴 Critique |
| `StampDialog` | Tampon visuel | Tampon universel | 🟢 Oui | — | — | 🟢 Faible |
| `SignaturePad` | Signature dessinée | Signature universelle | 🟢 Oui | 🟠 Vocabulaire à clarifier ("non qualifiée") | — | 🟠 Élevé (juridique) |
| `DraftWatermark` | Composant neutralisé | À nettoyer ou utiliser | — | — | — | 🟢 Faible |
| `generateFichePDF` | PDF Cachet (4 templates) | PDF universel | 🟡 Squelette oui | 🔴 Étendre aux 10 templates manquants | — | 🟡 Régression visuelle possible |
| `DOC_CATEGORIES` (`docCatalog.js`) | Catalogue intermittence | Source de vérité par vertical | 🟢 Oui | 🟢 Oui (un catalogue par vertical) | — | 🟢 Faible |
| Templates `*Paper` × 14 | 14 documents intermittents | Bibliothèque intermittence | ❌ | ❌ | 🔴 **Les 14 restent figés** (esp. DPAE/AEM/GUSO/AttPE = sensibles) | 🔴 Critique |

### Synthèse matrice

| Catégorie | Verdict |
|---|---|
| **Briques 100% réutilisables comme moteur** | Verso, QR, HashCheckBadge, ToolPalette, StampDialog, StudioPanel (squelette), QRBadge, SaveMenu |
| **Briques généralisables avec adaptateur** | FichePaper (squelette), FicheTopBar, DocPicker, SectionApparence/Identite/Contenu, SealButton (avec profils de hash) |
| **Briques strictement intermittence — à protéger** | Les 14 `*Paper.jsx`, `intermittent507.js`, `verificationHash.js`, `sealCachet`, `verifyCachet`, le profil `intermittence_v1` |
| **Code mort à documenter** | `DocSwitcher`, `DocMenu`, `EditMenu`, `ShareMenu`, `DraftWatermark` |
| **Points de vigilance** | `SectionCertification` (hash local ≠ backend), `SignaturePad` (vocabulaire), couverture PDF (4/14) |

---

## 11. Documents manquants

### 11.1 Méthode

Sont listés ci-dessous les documents intermittents qui **devraient idéalement** être dans la bibliothèque pour couvrir l'ensemble du parcours administratif. **Non créés maintenant.** Document de planification seulement.

### 11.2 Par famille

#### Famille A — Prestation (objet central)

| Document | Présent ? | Priorité |
|---|---|---|
| Fiche Cachet | ✅ | — |
| Feuille de présence | ✅ | — |
| Feuille de route artistique (planning détaillé répétitions + représentations) | ❌ | 🟢 Élevée |
| Rider technique (besoins son/lumière/scène) | ❌ | 🟡 Moyenne |
| Fiche de risque / DUERP allégé | ❌ | 🟡 Moyenne |

#### Famille B — Facturation

| Document | Présent ? | Priorité |
|---|---|---|
| Devis artiste | ✅ | — |
| Note d'honoraires (artiste-auteur) | ✅ | — |
| Reçu de cachet | ✅ | — |
| Note de frais | ✅ | — |
| **Facture** (régime entreprise / SARL / SASU) | ❌ | 🟢 Élevée |
| **Acompte / Reçu d'acompte** | ❌ | 🟢 Élevée |
| **Avoir** | ❌ | 🟡 Moyenne |
| **Relance de paiement** | ❌ | 🟡 Moyenne |

#### Famille C — Contrats

| Document | Présent ? | Priorité |
|---|---|---|
| CDD d'usage | ✅ | — |
| Avenant | ✅ | — |
| Convention de cession | ✅ | — |
| Cession de droits voisins | ✅ | — |
| **Contrat de coréalisation** | ❌ | 🟡 Moyenne |
| **Contrat de coproduction** | ❌ | 🟡 Moyenne |
| **Contrat de licence d'exploitation** | ❌ | 🟡 Moyenne |
| **Engagement / Lettre d'engagement** (forme courte) | ❌ | 🟢 Élevée |

#### Famille D — Déclaratif / Organismes

| Document | Présent ? | Priorité |
|---|---|---|
| DPAE | ✅ | — |
| AEM | ✅ | — |
| Attestation Pôle Emploi | ✅ | — |
| GUSO | ✅ | — |
| **Bulletin de salaire / fiche de paie préparatoire** | ❌ | 🟢 Élevée |
| **Déclaration Audiens / Congés Spectacles** | ❌ | 🟡 Moyenne |
| **Déclaration AFDAS** | ❌ | 🟡 Moyenne |
| **Déclaration médecine du travail (CMB)** | ❌ | 🟡 Moyenne |
| **DSN récapitulative** | ❌ | 🟠 Sensible — à manipuler avec prudence |

#### Famille E — Technique

| Document | Présent ? | Priorité |
|---|---|---|
| **Bon de commande matériel** | ❌ | 🟡 Moyenne |
| **PV de mise à disposition** | ❌ | 🟡 Moyenne |
| **Inventaire / Liste matériel** | ❌ | 🟡 Moyenne |

#### Famille F — Dossier complet (transverse)

| Document | Présent ? | Priorité |
|---|---|---|
| **Dossier de tournée** (compilation multi-prestations) | ❌ | 🟡 Moyenne |
| **Fiche de paie consolidée annuelle** | ❌ | 🟡 Moyenne |
| **Récapitulatif 507h à transmettre à France Travail** | ❌ | 🟢 Élevée (lien naturel avec Cockpit 507) |
| **Attestation sur l'honneur (déclaration de revenus)** | ❌ | 🟡 Moyenne |

### 11.3 Verdict

La bibliothèque actuelle couvre **14 documents sur ~30 utiles**. Les manques les plus prioritaires sont :
- **Facture** (régime entreprise) — manque évident pour les utilisateurs en SARL/SASU
- **Acompte / Reçu d'acompte** — usage fréquent
- **Engagement court** — alternative légère au CDD d'usage
- **Bulletin de salaire préparatoire** — demande fréquente
- **Récapitulatif 507h à France Travail** — lien naturel avec le cockpit existant

**Aucun de ces documents ne doit être créé maintenant.** Cette liste sert de feuille de route potentielle.

---

## 12. Recommandation

### 12.1 Ce qu'il faut **GARDER**

- ✅ **L'architecture générale de `FicheView`** : la séparation Canvas / TopBar / Studio / ToolPalette / Verso est saine et déjà universelle.
- ✅ **Le pattern de scellement** (`SealButton` + `sealCachet` + `verifyCachet` + `HashCheckBadge`) : irréprochable juridiquement, vocabulaire conforme.
- ✅ **Le verso QR** : composant le plus mûr et le plus universel.
- ✅ **La structure de `StudioPanel`** : 5 sections, accordéon, propulsion par props — bonne base pour la généralisation.
- ✅ **La bibliothèque `DOC_CATEGORIES`** : structure claire, extensible, déjà neutre techniquement.
- ✅ **Les disclaimers et préfixes de partage** (`SHARE_PREFIX`, `buildShareBody`) : exemplaires.
- ✅ **Le mode édition inline + notes débouncées** : pattern bien fait, à reproduire.

### 12.2 Ce qu'il faut **PROTÉGER**

- 🔴 **Les 14 templates `*Paper.jsx`** : aucune modification. Esp. DPAE / AEM / AttPE / GUSO (sensibles France Travail / URSSAF).
- 🔴 **`lib/intermittent507.js`** : moteur officiel, coefficients Unédic.
- 🔴 **`lib/verificationHash.js` + `HASHED_FIELDS`** : 8 champs figés. Toute modification casse les fiches scellées.
- 🔴 **`functions/sealCachet` + `functions/verifyCachet`** : fonctions backend gelées.
- 🔴 **`pages/FicheView.jsx`** : routeur central de la page — toute modification structurelle doit être additive.
- 🔴 **`pages/Verify.jsx`** : page publique de vérification.
- 🔴 **Entité `Prestation`** : ne JAMAIS renommer. Tout adaptateur futur passera par projection en lecture.
- 🔴 **Le profil de hash `intermittence_v1`** : figé.

### 12.3 Ce qu'il faut **COMPLÉTER** (non urgent, hors Phase 2)

- 🟡 **PDF des 10 templates manquants** : actuellement fallback `drawCachet`. Sortir un PDF dédié par template (10 fonctions `drawXxx` à ajouter dans `ficheGenerator.js`).
- 🟡 **Persistance des choix Studio** (theme, background, font, accent, watermark, headerText, logo) sur Prestation ou sur un sous-objet `studio_config`. Aujourd'hui jetable à chaque rechargement.
- 🟡 **Persistance de `stamp` et `signature`** : actuellement perdus au reload.
- 🟡 **Clarifier `SectionCertification`** : aujourd'hui calcule un hash local sur 5 champs (différent du backend sur 8 champs). À unifier ou à retirer pour éviter la confusion.
- 🟡 **Reformuler le label "Signature électronique"** en "Signature manuscrite visuelle" + ajouter le disclaimer "Cette signature ne vaut pas signature électronique qualifiée" dans `SignaturePad` et sur le papier (ligne 376 de `FicheView`).
- 🟡 **Brancher réellement le Cloud AIME** : actuellement uniquement `logEvent`, sans upload PDF.
- 🟡 **Câbler `PAPER_FORMATS`** : aujourd'hui exposé mais ignoré par les `*Paper.jsx`.
- 🟡 **Nettoyer le code mort** : `DocSwitcher`, `DocMenu`, `EditMenu`, `ShareMenu`, `DraftWatermark`. Soit supprimer, soit documenter explicitement comme legacy.
- 🟡 **Sanitiser la donnée envoyée à `InvokeLLM`** dans `SectionIA` (aujourd'hui : `JSON.stringify(prestation)` entier).
- 🟡 **Compléter la bibliothèque** : Facture, Acompte, Engagement court, Bulletin de salaire préparatoire, Récapitulatif 507h.

### 12.4 Ce qu'il **NE FAUT SURTOUT PAS FAIRE**

- ❌ **Ne pas renommer `Prestation`** ni aucun de ses champs.
- ❌ **Ne pas modifier les 14 `*Paper.jsx`**.
- ❌ **Ne pas modifier `HASHED_FIELDS`** (8 champs figés).
- ❌ **Ne pas démarrer Phase 2 EventCore** sans validation explicite.
- ❌ **Ne pas créer de verticale** (mariage, conférence, festival).
- ❌ **Ne pas créer de nouvelles routes** avant validation.
- ❌ **Ne pas modifier les fonctions backend `sealCachet` / `verifyCachet`**.
- ❌ **Ne pas remplacer `FicheView` par une version "généralisée"**. Toute généralisation passe par un **nouveau** composant à côté.
- ❌ **Ne pas modifier le vocabulaire juridique** ailleurs que pour clarifier (jamais pour affirmer).
- ❌ **Ne pas utiliser le terme "signature électronique qualifiée"** sauf en disclaimer négatif.
- ❌ **Ne pas mélanger les disclaimers entre verticales** (les mentions intermittence restent strictement réservées au vertical Intermittents).

### 12.5 Première modification sûre possible après cet audit

Si une modification additive, ciblée et sans risque devait être envisagée **après cet audit** (et **après validation explicite**), la plus sûre serait :

**Option recommandée — Clarification vocabulaire "Signature"**

Périmètre **minimal** :
- `SignaturePad` : modifier le titre `"Signature électronique"` → `"Signature manuscrite visuelle"` + ajouter une petite ligne disclaimer sous le titre : *"Cette signature ne vaut pas signature électronique qualifiée."*
- `FicheView` ligne 376 (label sur le papier) : modifier `"Signature électronique"` → `"Signature manuscrite visuelle"`.

Pourquoi cette option ?
- 🟢 Modification **additive** (ajoute un disclaimer, reformule un label) ;
- 🟢 Aucun impact sur la donnée, le hash, le scellement, le PDF ;
- 🟢 Renforce la conformité juridique (cohérence avec la doctrine AIME CanvasCore §7) ;
- 🟢 2 fichiers seulement, ~3 lignes modifiées au total ;
- 🟢 Rollback trivial (anchor_replace inversé).

**À NE PAS faire en première étape** :
- ❌ Extraire un `GenericPaper` du `FichePaper` (refonte trop large).
- ❌ Sortir un PDF dédié pour les 10 templates manquants (10 fonctions à écrire d'un coup).
- ❌ Persister les choix Studio sur Prestation (touche au schéma de données).
- ❌ Démarrer la Phase 2 EventCore.

**Cette option n'est PAS exécutée maintenant.** Elle est uniquement nommée comme la modification la plus sûre **si** une étape post-audit était décidée.

---

## 📌 Synthèse de l'audit

| Item | Valeur |
|---|---|
| Page auditée | `pages/FicheView.jsx` (433 lignes) |
| Composants enfants directs | 9 |
| Templates documentaires | 14 |
| Sections Studio | 5 |
| Briques 100% réutilisables (CanvasCore) | 8 |
| Briques généralisables avec adaptateur | 6 |
| Briques strictement intermittence à protéger | 14 + 5 modules backend/lib |
| Code mort identifié | 5 composants (`DocSwitcher`, `DocMenu`, `EditMenu`, `ShareMenu`, `DraftWatermark`) |
| Documents PDF dédiés | 4/14 (10 en fallback) |
| Points de vigilance juridique | 1 (vocabulaire "Signature électronique" sur SignaturePad + FicheView L.376) |
| Points de vigilance technique | 1 (hash local SectionCertification ≠ hash backend) |
| Documents intermittents manquants identifiés | ~16 (toutes familles confondues) |
| Risque global de toucher au moteur existant | 🔴 Élevé sans précautions |
| Potentiel CanvasCore | 🟢 **Très élevé** — la page est déjà à 70% un canvas universel |
| Phase 2 EventCore | ⛔ NON démarrée |

---

> **AIME Cachet** est ce qu'on voit aujourd'hui.
> **AIME CanvasCore** est ce qu'on découvre derrière, **en grande partie déjà construit dans `/fiche/:id`**.
> **EventCore** est ce qu'on pourra construire demain — sans rien casser de ce qui précède.

— Fin de l'audit `/fiche/:id` —