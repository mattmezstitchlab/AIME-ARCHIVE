# AIME Event — Source Propagation Engine v0 — Cadrage d'implémentation

**Date :** 2026-05-23
**Statut :** **Cadrage documentaire figé — non exécutable.**
**Périmètre :** AIME Event uniquement — AIME Cachet strictement intact.
**Nature :** Markdown déclaratif. Aucun code, aucun fichier JS, aucune UI, aucune entité, aucune route, aucun moteur runtime.

**Rattachement :**
- `docs/aime-event-source-propagation-doctrine.md` (cadrage SPE)
- `docs/aime-event-source-propagation-rules-v0-freeze.md` (freeze SPE v0)
- `docs/aime-event-source-propagation-ui-v0-doctrine.md` (doctrine UI v0)
- `docs/aime-event-surface-selector-v0-freeze.md`
- `docs/aime-event-surface-faire-part-v0-freeze.md`
- `docs/aime-event-surface-doctrine-pre-ui.md` (§0bis)

---

## Exergue — Formule doctrinale

> **Une source.**
> **Plusieurs projections.**
> **Zéro répétition.**
> **Studio intégré.**
> **Validation humaine.**

---

## 0. Objet du document

Ce document **prépare** l'implémentation future du Source Propagation Engine v0 **sans écrire une seule ligne de code**.

Il **fige** les micro-décisions techniques qui restaient ouvertes après l'audit de cohérence transverse, afin que toute implémentation future puisse se faire **en une seule itération contrôlée**, sans dérive doctrinale.

**Ce document n'autorise rien.** Il documente uniquement ce qui serait fait **si** une implémentation était ultérieurement validée explicitement.

---

## 1. Périmètre exact d'implémentation v0

### 1.1 Sources actives (5)

| Code | Champ `EventRecord` | Sémantique |
|---|---|---|
| `S-TITLE` | `title` | Titre de l'événement |
| `S-DATE` | `date` | Date principale |
| `S-LOCATION` | `location` | Lieu principal |
| `S-WED-PARTNERS` | `wedding_partners` | Noms des partenaires (mariage uniquement) |
| `S-WED-DATE-CIVIL` | `wedding_date_civil` | Date de cérémonie civile (mariage uniquement) |

**Aucune autre source en v0.** Toute extension exige un freeze dédié.

### 1.2 Surfaces concernées (2)

| Code | Surface | Composant |
|---|---|---|
| `document` | Fiche préparatoire A4 | `EventFichePaper` |
| `faire_part` | Faire-part | `SurfaceFairePart` |

**Aucune autre surface en v0.**

### 1.3 Wallet (1, calculé uniquement)

| Code | Nom | Persistance |
|---|---|---|
| `W-TODO` | « À compléter » | ❌ Aucune — section calculée à la volée, jamais entité `Wallet` créée |

### 1.4 Types de propositions (4)

| Code | Sens | Effet interne |
|---|---|---|
| `P-SURF-DOC` | Mise à jour de la Fiche préparatoire A4 | Préremplit un champ de la surface `document` |
| `P-SURF-FP` | Mise à jour du Faire-part | Préremplit un champ de la surface `faire_part` |
| `P-TODO-RM` | Retrait/résolution d'un item « À compléter » | Marque l'item comme résolu (calcul à la volée) |
| `P-CHECK` | Item de checklist simple | Ajoute un item « confirmer X » |

**Aucun autre type de proposition en v0.**

### 1.5 Plafonds doctrinaux

| Plafond | Valeur |
|---|---|
| Propositions max par source | **3** |
| Propositions max par `EventRecord` | **8** |
| Propagation transitive | **❌ Interdite** |

**Stratégie de débordement (rappel UI doctrine §12.1) :**
1. Propositions liées à la dernière source modifiée.
2. Propositions `P-SURF-DOC` et `P-SURF-FP`.
3. Propositions `P-CHECK`.
4. Propositions `P-TODO-RM`.

---

## 2. Fonction pure future — signature uniquement

### 2.1 Signature figée

```
detectProposals(eventRecord: EventRecord) → Proposition[]
```

### 2.2 Règles doctrinales de la fonction

| Règle | Statut |
|---|---|
| Fonction **pure** | ✅ Obligatoire |
| Aucune écriture en base | ✅ Obligatoire |
| Aucun appel réseau | ✅ Obligatoire |
| Aucun endpoint backend | ✅ Obligatoire |
| Aucun stockage persistant | ✅ Obligatoire |
| Aucun effet de bord (logs, mutations, etc.) | ✅ Obligatoire |
| Aucun accès à AIME Cachet | ✅ Obligatoire |
| Aucun accès à `Prestation`, `verification_hash`, `cachet_code` | ✅ Obligatoire |
| Recalcul à la volée à chaque appel | ✅ Obligatoire |
| Tri par priorité interne, plafonds appliqués | ✅ Obligatoire |
| Output déterministe pour un même input | ✅ Obligatoire |

### 2.3 Comportement attendu (pseudo-spécification, non exécutable)

```
detectProposals(eventRecord):
  propositions = []
  pour chaque source S parmi { S-TITLE, S-DATE, S-LOCATION, S-WED-PARTNERS, S-WED-DATE-CIVIL }:
    si la source est renseignée:
      ajouter ≤ 3 propositions de projection (P-SURF-DOC, P-SURF-FP) ou de résolution (P-TODO-RM)
    sinon:
      ajouter 1 proposition de type P-CHECK (« renseigner X »)
  appliquer le plafond global de 8 (stratégie §1.5)
  retourner propositions triées par priorité
```

**Aucune ligne de code à écrire à ce stade.**

---

## 3. Forme future de l'objet `Proposition` (structure théorique)

### 3.1 Champs

| Champ | Type théorique | Sens |
|---|---|---|
| `id` | string | Identifiant déterministe `${source}-${type}-${target}` |
| `source` | string ∈ { `S-TITLE`, `S-DATE`, `S-LOCATION`, `S-WED-PARTNERS`, `S-WED-DATE-CIVIL` } | Source d'origine |
| `type` | string ∈ { `P-SURF-DOC`, `P-SURF-FP`, `P-TODO-RM`, `P-CHECK` } | Type de proposition |
| `target` | string | Cible interne (champ, item, surface) |
| `title` | string | Titre court de la carte (wording §6) |
| `phrase` | string | Phrase descriptive (wording §6) |
| `why` | string | Texte du popover « Voir pourquoi » |
| `status` | string ∈ { `proposée`, `notée`, `ignorée`, `plus tard`, `obsolète` } | Statut courant |
| `priority` | number | Priorité interne (tri, plafonds) |

### 3.2 Persistance — strictement aucune en v0

| Élément | Statut v0 |
|---|---|
| Entité `PropagationProposal` | ❌ **Aucune** |
| Table de stockage | ❌ Aucune |
| Endpoint backend | ❌ Aucun |
| Champ ajouté à `EventRecord` | ❌ Aucun |
| `id` persistant | ❌ Recalculé à chaque rendu |

### 3.3 Statuts — où ils vivent en v0

| Statut | Vit où ? |
|---|---|
| `proposée` | Calculé à la volée depuis `EventRecord` |
| `notée` | Mémoire de session UI uniquement (l'utilisateur a pris note de la proposition) |
| `obsolète` | Calculé à la volée (la source a changé après décision — comportement émergent) |
| `ignorée` | **Mémoire de session UI uniquement** (perdue au rechargement) |
| `plus tard` | **Mémoire de session UI uniquement** (perdue au rechargement) |

**Rappel UI doctrine §9.2 :** la perte d'état session au rechargement est **acceptable en v0**.

---

## 4. Emplacement futur dans `EventStudio`

### 4.1 Position retenue

La future section **« Ce que cette information déclenche »** s'insérerait dans `components/event/EventStudio.jsx` **entre** la section `« Bibliothèque préparatoire »` et le composant `<SurfaceSelector …/>`.

**Justification :**
- Place la propagation à proximité directe du contenu qui la déclenche.
- Maintient `SurfaceSelector` à proximité du bloc `Visibilité` (cohérent avec son rôle de « point de vue »).
- Préserve la séparation doctrinale §3 de l'UI doctrine.

### 4.2 Caractéristiques imposées

| Caractéristique | Valeur |
|---|---|
| Section **repliable** | ✅ Obligatoire |
| **Fermée** par défaut | ✅ Obligatoire |
| Visible **uniquement** s'il existe ≥ 1 proposition | ✅ Obligatoire |
| Séparée visuellement de « Surface du canvas » | ✅ Obligatoire |
| Aucun badge rouge / coloré d'alerte | ✅ Obligatoire |
| Aucune notification / toast / modal automatique | ✅ Obligatoire |
| Aucun son, aucune vibration | ✅ Obligatoire |
| Aucune animation anxiogène | ✅ Obligatoire |

### 4.3 Ce que la future section **ne touche pas**

- ❌ `EventFicheView.jsx`
- ❌ `EventFichePaper.jsx`
- ❌ `EventFicheVerso.jsx`
- ❌ `SurfaceFairePart.jsx`
- ❌ `SurfaceSelector.jsx`
- ❌ Le canvas central, le système de flip, le scale, la barre TopBar de la page Fiche
- ❌ Le schéma `EventRecord`
- ❌ `App.jsx`, les routes, le menu latéral
- ❌ AIME Cachet (tous fichiers `components/aime/**`, `functions/sealCachet`, `functions/verifyCachet`, schéma `Prestation`)

---

## 5. Fichiers futurs concernés (documentation uniquement)

### 5.1 Fichiers potentiels à **créer** (si implémentation future validée)

| Fichier | Rôle | Caractéristiques |
|---|---|---|
| `lib/event-core/propagation/detect-v0.js` | Fonction pure `detectProposals` | Pure, sans état, sans réseau, sans I/O |
| `components/event/studio/SourcePropagationSection.jsx` | Composant focalisé — section repliable | Reçoit `event` et `onPrepare` en props, gère l'état de session local (ignorée/plus tard) |

### 5.2 Fichier potentiel à **modifier** (si implémentation future validée)

| Fichier | Modification anticipée | Volume estimé |
|---|---|---|
| `components/event/EventStudio.jsx` | 1 import + 1 insertion `<SourcePropagationSection …/>` entre `« Bibliothèque préparatoire »` et `<SurfaceSelector …/>` | 2 opérations `anchor_replace` |

### 5.3 Fichiers strictement **non touchés** (interdiction absolue)

| Fichier | Motif |
|---|---|
| `pages/EventFicheView.jsx` | Canvas central, hors périmètre |
| `components/event/EventFichePaper.jsx` | Rendu surface `document`, hors périmètre |
| `components/event/EventFicheVerso.jsx` | Verso interne, hors périmètre |
| `components/event/SurfaceFairePart.jsx` | Rendu surface `faire_part`, hors périmètre |
| `components/event/studio/SurfaceSelector.jsx` | Point de vue surface, hors périmètre |
| `entities/EventRecord.json` | Aucun nouveau champ |
| `App.jsx` | Aucune nouvelle route |
| `lib/event-core/surfaces/index.js` | Registre des surfaces, hors périmètre |
| `lib/event-core/verticals/event.js` | Configuration verticale, hors périmètre |
| **Tous les fichiers AIME Cachet** | `components/aime/**`, `functions/sealCachet`, `functions/verifyCachet`, schéma `Prestation`, `lib/verificationHash.js`, `lib/sealedState.js`, `lib/cachetCode.js`, `pages/AimeCachet`, `pages/FicheView`, `pages/Dashboard507`, `pages/Verify`, `pages/MesPrestations` |

---

## 6. Wording futur à respecter

### 6.1 Phrases obligatoires (à reprendre verbatim depuis l'UI doctrine §5)

| Emplacement | Texte exact |
|---|---|
| Sous-titre de la section | « Cerise propose, vous validez. » |
| Pied de section | « Ces propositions restent privées, préparatoires et non opposables. » |
| Pied de section (suite) | « Aucune action externe n'est déclenchée. » |
| Pied de section (suite) | « Aucune publication, aucun envoi, aucune signature. » |
| Pied de section (doctrine mémo vivant) | « Une saisie, plusieurs supports. Vous validez chaque projection. » |

### 6.2 Wording « Voir pourquoi » (à reprendre verbatim depuis l'UI doctrine §5.2)

> « Cette information a été saisie une fois. Cerise peut la projeter dans les supports concernés sans nouvelle saisie. Vous gardez la main sur chaque projection. »

### 6.3 Boutons autorisés

| Bouton | Effet attendu |
|---|---|
| **Noter** | Effet interne uniquement : marque la carte comme « notée » en mémoire de session. Aucune écriture, aucune action externe. Le badge précise « Notée en session — aucune modification appliquée. » |
| **Voir pourquoi** | Ouvre un popover affichant `proposition.why` |
| **Plus tard** | Masque la carte (mémoire de session) |
| **Ignorer** | Masque la carte jusqu'à modification ultérieure de la source (mémoire de session) |

### 6.4 Wording **strictement interdit**

| Terme interdit | Présence interdite dans |
|---|---|
| Envoyer | Boutons, libellés, tooltips, popovers, logs visibles |
| Publier | Idem |
| Signer | Idem |
| Générer PDF | Idem |
| Facturer | Idem |
| Partager | Idem |
| Sceller | Idem (réservé à AIME Cachet) |
| Notifier | Idem |
| Tout appliquer | Idem |
| Tout valider | Idem |
| Exporter, Certifier | Idem (rappel UI doctrine §7) |
| « automatique », « officiel », « IA » | Idem |

---

## 7. Tests manuels futurs

Tests à effectuer **si** l'implémentation est ultérieurement validée. **Aucun test n'est à exécuter à ce stade.**

### 7.1 Tests fonctionnels minimaux

| # | Scénario | Attendu |
|---|---|---|
| T-01 | `eventType: "mariage"` vide (aucune source renseignée) | Section masquée OU section affichant uniquement des `P-CHECK` ≤ 8 |
| T-02 | `eventType: "mariage"` avec `title` renseigné uniquement | Propositions liées à `S-TITLE` (`P-SURF-DOC`, `P-SURF-FP`) ; reste = `P-CHECK` |
| T-03 | `eventType: "mariage"` avec `date` renseigné uniquement | Propositions liées à `S-DATE` ; reste = `P-CHECK` |
| T-04 | `eventType: "mariage"` avec `location` renseigné uniquement | Propositions liées à `S-LOCATION` ; reste = `P-CHECK` |
| T-05 | `eventType: "mariage"` avec `wedding_partners` renseigné uniquement | Propositions liées à `S-WED-PARTNERS` ; reste = `P-CHECK` |
| T-06 | `eventType: "mariage"` avec `wedding_date_civil` renseigné uniquement | Propositions liées à `S-WED-DATE-CIVIL` ; reste = `P-CHECK` |
| T-07 | `eventType: "mariage"` avec les 5 sources renseignées | Maximum 8 propositions visibles |

### 7.2 Tests de garde-fous

| # | Vérification | Attendu |
|---|---|---|
| T-G1 | Aucun bouton interdit visible | ✅ |
| T-G2 | Aucune proposition liée à `surfaceMode` | ✅ |
| T-G3 | Aucune proposition liée à `eventType` comme source | ✅ |
| T-G4 | Aucun effet sur AIME Cachet (ouvrir `/app`, `/prestations`, `/fiche/:id`, `/507`, `/verify/:cachetCode`) | ✅ Aucun changement |
| T-G5 | Plafond ≤ 8 respecté | ✅ |
| T-G6 | Plafond ≤ 3 par source respecté | ✅ |
| T-G7 | Aucune création d'entité `PropagationProposal` en base | ✅ |
| T-G8 | Aucun appel réseau supplémentaire émis | ✅ |
| T-G9 | Recalcul à la volée à chaque rendu | ✅ |
| T-G10 | `Préparer` modifie uniquement `EventRecord` via `handleField` existant | ✅ |

### 7.3 Tests d'isolation AIME Cachet

| # | Vérification | Attendu |
|---|---|---|
| T-C1 | `functions/sealCachet` inchangé | ✅ |
| T-C2 | `functions/verifyCachet` inchangé | ✅ |
| T-C3 | Schéma `Prestation` inchangé | ✅ |
| T-C4 | Route `/verify/:cachetCode` inchangée | ✅ |
| T-C5 | Aucun fichier `components/aime/**` modifié | ✅ |

---

## 8. Rollback futur

**Rollback en deux niveaux**, applicables séparément ou ensemble.

### 8.1 Niveau 1 — désactivation immédiate

Retirer dans `components/event/EventStudio.jsx` :
- la ligne d'import `import SourcePropagationSection from "@/components/event/studio/SourcePropagationSection";`
- l'insertion `<SourcePropagationSection event={event} onPrepare={handleField} />`

→ Effet immédiat : la section disparaît. Aucun autre changement.

### 8.2 Niveau 2 — suppression complète

1. Effectuer le niveau 1.
2. `delete_file components/event/studio/SourcePropagationSection.jsx`
3. `delete_file lib/event-core/propagation/detect-v0.js`

### 8.3 Effets garantis

| Élément | Effet du rollback |
|---|---|
| Migration de données | ❌ Aucune nécessaire |
| Données à nettoyer | ❌ Aucune (rien n'a été persisté) |
| Entité à supprimer | ❌ Aucune (aucune entité créée) |
| Champ `EventRecord` à retirer | ❌ Aucun (aucun champ ajouté) |
| Impact AIME Cachet | ❌ Aucun |
| Impact `EventFicheView`, surfaces, registre | ❌ Aucun |
| Risque de perte de données | ❌ Aucun |

---

## 9. Correction mineure non bloquante

Le wording du composant `SurfaceSelector` (freezé en v0) affiche actuellement :

> « **Document A4** — Fiche standard, tous types d'événements. »

Or la doctrine `docs/aime-event-surface-wording-source-freeze.md` impose le wording **« Fiche préparatoire A4 »** dans toute communication doctrinale.

**Correction recommandée :** harmoniser le label en **« Fiche préparatoire A4 »** dans `SurfaceSelector.jsx` lors d'une itération dédiée du Surface Selector.

**Impact pour le cadrage SPE :** ❌ **Aucun.** Cette harmonisation relève d'un freeze d'itération du Surface Selector, pas du SPE. Le cadrage SPE peut être validé indépendamment.

---

## 10. Prochaine étape recommandée — **non exécutée**

Après validation explicite du présent cadrage :

> **Ne pas coder automatiquement.**
> **Demander une validation explicite supplémentaire** avant toute implémentation.

### 10.1 Procédure recommandée

1. Validation explicite du présent cadrage en chat (formulation attendue type : « Cadrage SPE v0 validé »).
2. Validation **séparée et explicite** de l'autorisation d'implémenter (formulation attendue type : « J'autorise l'implémentation du SPE v0 selon le cadrage »).
3. **Seulement après ces deux validations distinctes** : implémentation en une seule itération contrôlée, suivie d'un freeze documentaire `docs/aime-event-source-propagation-impl-v0-freeze.md`.

### 10.2 Garde-fou final

Aucune des étapes ci-dessus ne sera engagée sur la base d'une validation tacite, d'une interprétation extensive, ou d'une « micro-action évidente ». **Chaque pas exige une validation explicite indépendante.**

---

## 11. Confirmations finales du présent document

- ✅ Aucun code écrit.
- ✅ Aucun fichier JS créé.
- ✅ Aucune UI créée.
- ✅ Aucune entité créée.
- ✅ Aucune route ajoutée.
- ✅ Aucun moteur runtime créé.
- ✅ `EventStudio.jsx` inchangé.
- ✅ `EventFicheView.jsx`, `EventFichePaper.jsx`, `EventFicheVerso.jsx`, `SurfaceFairePart.jsx`, `SurfaceSelector.jsx` inchangés.
- ✅ Schéma `EventRecord` inchangé.
- ✅ Registre `lib/event-core/surfaces/index.js` inchangé.
- ✅ AIME Cachet strictement intact.
- ✅ Le présent document est strictement Markdown documentaire.

---

**Fin du cadrage d'implémentation SPE v0.**