# AIME CanvasCore — Doctrine du moteur vivant

**Date** : 23 mai 2026
**Type** : document doctrinal — **lecture seule, aucun code, aucune route, aucune entité, aucune UI**
**Statut** : doctrine validée, Phase 1 EventCore gelée, Phase 2 non démarrée

> Ce document a pour seul objet de **nommer clairement** le moteur déjà présent dans AIME Cachet, avant toute généralisation. Il ne déclenche aucune action technique. Il ne crée rien. Il ne modifie rien. Il pose un vocabulaire commun.

---

## Préambule

Au fil de la construction d'AIME Cachet, un constat est apparu : l'application n'est pas seulement un outil pour intermittents du spectacle. Elle contient, déjà visible, le squelette d'un moteur beaucoup plus large.

Ce moteur n'a pas encore de nom officiel dans le code. Ce document lui en donne un :

> **AIME CanvasCore.**

AIME Cachet est, à partir d'aujourd'hui, considéré comme le **premier vertical** de ce moteur. AIME Cachet reste intact, en production, premium, juridiquement prudent. AIME CanvasCore est la **doctrine supérieure** qui le décrit et qui éclaire toute extension future.

---

## 1. Définition de AIME CanvasCore

**AIME CanvasCore** est le moteur qui permet de **créer, éditer, personnaliser, ranger, projeter, partager et vérifier des objets AIME**.

### Sept verbes fondamentaux

| Verbe | Brique correspondante |
|---|---|
| **Créer** | Bibliothèque de modèles |
| **Éditer** | Canvas central |
| **Personnaliser** | Studio |
| **Ranger** | Wallets / Registre |
| **Projeter** | Cockpit / Timeline |
| **Partager** | Verso QR / ShareMenu |
| **Vérifier** | Page de vérification publique / Scellement |

Ces sept verbes sont les **invariants du moteur**. Ils ne dépendent d'aucune verticale. Ils sont déjà tous implémentés, sous une forme ou une autre, dans AIME Cachet.

### Qu'est-ce qu'un « objet AIME » ?

Un objet AIME est une entité composable, adressable, scellable et projetable. Il peut prendre, selon le format et le gabarit, n'importe laquelle de ces formes :

- une fiche ;
- un document ;
- une page publique ;
- une section de site ;
- un héros ;
- une affiche ;
- une invitation ;
- un billet ;
- un mini-site ;
- un programme ;
- une fiche prestataire ;
- une fiche invité ;
- une fiche intervenant ;
- une fiche événement ;
- un document administratif préparatoire.

Le moteur ne « sait » pas qu'il rend un cachet plutôt qu'une invitation. Il rend **un canevas paramétré**. La distinction est donnée par la combinaison **format + gabarit + destination de sortie** (PDF, URL publique, image partageable, QR vers fiche, etc.).

---

## 2. Les invariants du moteur

Treize briques composent AIME CanvasCore. Elles sont **toutes déjà visibles** dans AIME Cachet aujourd'hui.

### 2.1 Canvas central

La surface principale, éditable, observable, scellable. Elle accueille n'importe quel gabarit. Elle connaît son état (brouillon, à compléter, prêt à vérifier, transmis, validé). Elle expose un identifiant stable adressable.

### 2.2 Studio

Le panneau latéral droit. Il personnalise le rendu **sans connaître le métier**. Il manipule cinq dimensions strictement visuelles ou structurelles :

- apparence (papier, police, accent, fond)
- identité (logo, tampon, signature, watermark)
- contenu (champs spécifiques au gabarit)
- certification (QR, scellement, mention préparatoire)
- IA (pré-remplissage, suggestions)

Le Studio est, par construction, un **éditeur universel**.

### 2.3 Bibliothèque

Le catalogue de gabarits disponibles. Chaque entrée déclare un format, une liste de champs, un rendu. Aujourd'hui, la bibliothèque AIME Cachet contient 14 documents (cachet, devis, honoraires, reçu, présence, cession, frais, DPAE, AEM, attestation France Travail, GUSO, CDDU, cession de droits, avenant). Elle peut, sans modification du moteur, accueillir d'autres gabarits.

### 2.4 Recto / Verso

Le canvas est nativement **bifacial**. Le recto porte le contenu. Le verso porte l'accès, le partage et la vérification. Cette dualité est un invariant du moteur, pas une option visuelle.

### 2.5 QR

Le QR du verso pointe vers une URL publique. C'est la **clé d'accès** à la version vérifiable de l'objet. C'est aussi le **vecteur de partage** (impression, scan, transmission).

### 2.6 Scellement prudent

Le scellement calcule une empreinte technique SHA-256 sur une liste figée de champs publics. Il atteste uniquement de la **cohérence technique** entre ce qui est affiché et ce qui a été enregistré au moment du scellement. Il ne constitue **ni une certification administrative, ni une signature électronique légale, ni une preuve opposable**.

Trois états : `none` (jamais scellé), `synced` (cohérent), `stale` (modifié depuis le scellement).

### 2.7 Partage

Toute diffusion d'un brouillon AIME doit être préfixée par une mention explicite, par exemple : `[BROUILLON AIME — non opposable]`. Cette règle est portée par la couche partage du moteur.

### 2.8 Wallets

Le système de rangement. Deux dimensions cohabitent :

- **Wallets persistés** — dossiers créés par l'utilisateur (nom, icône, couleur, ordre).
- **Smart wallets** — vues calculées à la volée par règles déclaratives (« Cette année », « À transmettre », « Validé », « Non rangées »…).

### 2.9 Timeline

La projection chronologique des objets. Elle agrège l'activité par périodes, affiche les jalons, signale les événements récurrents, propose des regroupements visuels.

### 2.10 Cockpit

Le tableau de bord de projection. Il agrège, mesure, projette, alerte et suggère. Voir section 4 pour le détail.

### 2.11 Assistant IA

Le chat contextuel. Il lit l'état réel de l'utilisateur (objets, statuts, manques, cumul d'heures, hash périmé) et propose la prochaine action. Il accompagne, il n'agit pas seul.

### 2.12 Registre

L'index navigable de l'ensemble des objets. C'est la rencontre entre les Wallets (rangement) et la liste exhaustive (toutes les fiches). Il permet la recherche, le filtre, le tri.

### 2.13 Page de vérification

L'URL publique en lecture seule. Elle affiche uniquement les champs autorisés par la whitelist publique. Elle ne montre **jamais** les données sensibles (n° de sécurité sociale, RIB, montants, signatures, notes privées). Elle porte ses propres mentions légales obligatoires.

---

## 3. AIME Cachet comme premier vertical

### Ce qui reste intact

- **AIME Cachet reste intact.** Routes, entités, moteur 507h, hash `intermittence_v1`, templates documentaires, génération PDF, mentions légales, vocabulaire juridique : tout est gelé.
- **AIME Cachet est le vertical Intermittents.** Il porte la logique métier propre aux intermittents du spectacle (annexes 8 et 10, PRA, AJ, anniversaire, congé payé, formation, MdA, GUSO, France Travail, Urssaf, Audiens).
- **EventCore est une première couche passive.** La couche `lib/event-core/` créée en Phase 1 est strictement documentaire et techniquement orpheline. Elle n'est importée par aucun fichier applicatif. Elle peut être supprimée à tout moment sans impact.
- **CanvasCore est la doctrine supérieure.** Elle ne s'incarne dans aucun code. Elle est un cadre de pensée commun qui éclaire toute décision future.
- **Aucune logique intermittence ne doit être cassée.** C'est une règle absolue. Toute extension future passera **à côté** d'AIME Cachet, jamais **à travers**.

### La pyramide doctrinale

```
                  AIME CanvasCore
                (doctrine — ce document)
                        │
                        ▼
                  AIME EventCore
            (couche passive — Phase 1 figée)
                        │
                        ▼
                  AIME Cachet
        (vertical Intermittents — en production)
```

CanvasCore décrit. EventCore prépare techniquement (et reste passif). AIME Cachet fonctionne.

---

## 4. Le cockpit comme moteur de projection

Le cockpit 507h (`/507` dans AIME Cachet) n'est pas seulement un tableau de bord intermittent. C'est **le premier exemple concret d'un cockpit de projection**. Sa structure abstraite tient en cinq étapes :

1. **Agréger** les objets selon des règles métier.
2. **Mesurer** les compteurs principaux.
3. **Projeter** le futur (échéances, manques, scénarios).
4. **Alerter** sur ce qui menace l'objectif.
5. **Suggérer** la prochaine action.

Cette structure est rejouable pour n'importe quelle verticale, en changeant seulement la **table d'agrégations**, les **seuils** et les **alertes**.

### Cockpit intermittents (existant)

- 507 heures sur la période de référence d'affiliation
- PRA dynamique (recherche automatique de la meilleure fenêtre)
- Anniversaire (date d'examen des droits)
- Heures manquantes
- Scénarios « et si je fais X cachets / Y heures de formation »
- Alertes (anniversaire critique, documents manquants, hash périmé)

### Cockpit mariage (illustration doctrinale)

- Budget total et budget consommé
- Prestataires signés / en attente de devis
- Invités confirmés / en attente / refusés
- Planning Jour J avec dépendances
- Tâches critiques (J-30, J-15, J-7, J-1)

### Cockpit conférence (illustration doctrinale)

- Intervenants confirmés
- Sessions prêtes (slides, salle, créneau)
- Inscriptions vendues vs jauge
- Salles attribuées
- Sponsors signés et engagements
- Documents manquants (abstracts, bios, droits image)

### Cockpit festival (illustration doctrinale)

- Artistes contractualisés
- Scènes et équilibre de programmation
- Contrats émis / signés / payés
- Balances planifiées
- Accréditations émises
- Jauge anticipée
- Risques (météo, sécurité, technique)

> Ces trois illustrations ne sont pas des engagements de développement. Elles servent uniquement à montrer que **la même structure de cockpit** peut accueillir des contenus très différents sans réécriture du moteur.

---

## 5. La règle anti-doublon

C'est la règle d'or de CanvasCore. **Un seul moteur, plusieurs configurations.**

### Ce qu'il ne faut jamais faire

- ❌ Recréer un éditeur (canvas) par vertical.
- ❌ Créer un Studio différent par domaine.
- ❌ Dupliquer le système de QR.
- ❌ Recréer les wallets.
- ❌ Refaire une timeline.
- ❌ Réécrire un assistant IA from scratch.
- ❌ Réinventer le scellement.
- ❌ Multiplier les pages de vérification.

### Ce que chaque vertical apporte

Chaque verticale n'apporte que **six éléments de configuration** :

1. Une **liste de gabarits** (templates de documents / pages / billets).
2. Une **liste de smart wallets** (règles déclaratives).
3. Une **table de cockpit** (agrégations + seuils + alertes).
4. Un **prompt assistant** + intents locaux.
5. Un **profil de hash** dédié (jamais une modification du hash existant).
6. Un **vocabulaire** (libellés, disclaimers, mentions légales).

**Tout le reste est mutualisé.** C'est cette discipline qui empêche le projet de se disperser.

---

## 6. Différence CanvasCore / EventCore

Trois noms, trois rôles, trois niveaux.

| Nom | Nature | Rôle |
|---|---|---|
| **AIME CanvasCore** | Doctrine générale | Décrit le moteur de création universel. N'est incarné par aucun code. Vit dans ce document et dans la culture du projet. |
| **AIME EventCore** | Configuration événementielle | Configuration **possible** du moteur pour des objets événementiels. La Phase 1 (`lib/event-core/`) est purement passive et documentaire. Une éventuelle Phase 2 ajouterait des adaptateurs de lecture, jamais des modifications du code AIME Cachet. |
| **AIME Cachet** | Vertical en production | Vertical Intermittents existant. Reste intact. Premier exemple complet du moteur. |

### À retenir

- **CanvasCore** est ce qu'on **pense**.
- **EventCore** est ce qu'on **prépare** (et qui dort tant que rien ne le réveille).
- **AIME Cachet** est ce qu'on **utilise** aujourd'hui.

---

## 7. Cadrage juridique

Ce cadrage est **non négociable**. Il s'applique à AIME Cachet aujourd'hui et à toute verticale future.

### Documents administratifs

Tout document inspiré d'une procédure officielle (DPAE, AEM, attestation France Travail, GUSO, CDDU, fiches Urssaf, fiches Audiens, fiches MdA, formulaires fiscaux, etc.) doit être présenté comme :

- **aide préparatoire** ;
- **sans valeur officielle** ;
- **non opposable** ;
- nécessitant une **validation humaine** ;
- à vérifier auprès de l'**organisme officiel compétent**.

Disclaimer obligatoire à proximité de tout document de ce type :
> « Document préparatoire AIME — sans valeur officielle, non opposable. À vérifier humainement avant tout usage. AIME n'est ni mandaté ni affilié aux organismes officiels. »

### Signature

Le module de signature visuelle ne produit **jamais** une signature électronique légale.

Vocabulaire **autorisé** :
- « signature manuscrite visuelle »
- « signature préparatoire »
- « signature non qualifiée »

Vocabulaire **interdit** :
- « signature électronique qualifiée » (sauf dans un disclaimer négatif)
- « signature légale »
- « signature certifiée »
- « signature opposable »

Disclaimer obligatoire à proximité de toute signature dans l'application :
> « Cette signature ne vaut pas signature électronique qualifiée. »

### Scellement

Vocabulaire **autorisé** pour décrire le scellement :
- « empreinte technique »
- « cohérence technique vérifiée »
- « scellement technique »
- « brouillon scellé techniquement »

Vocabulaire **interdit** pour décrire le scellement :
- « certifié »
- « officiel »
- « validé administrativement »
- « preuve opposable »
- « certification officielle »
- « document officiel généré »
- « valeur officielle »

### Affiliation

Mention obligatoire dès qu'un organisme officiel est nommé :
> « AIME n'est ni mandaté ni affilié à GUSO, France Travail, Urssaf, Audiens ou Pôle Emploi Spectacle. »

### Verticales futures

Chaque verticale future (mariage, conférence, festival, atelier…) devra définir **son propre cadrage juridique** au démarrage. Aucun disclaimer d'AIME Cachet ne doit être recopié tel quel hors du vertical Intermittents.

---

## 8. Prochaine étape recommandée

> **Ne pas coder.** **Ne pas démarrer la Phase 2 EventCore.** **Ne pas créer de verticale.**

### Étape suivante : audit ciblé de `/fiche/:id`

Avant toute généralisation, il est nécessaire de **comprendre finement** ce que fait déjà la page la plus emblématique du moteur : la page d'édition d'une fiche AIME (`pages/FicheView`).

Cette page est la **manifestation visible la plus complète** d'AIME CanvasCore. Elle expose, en un seul endroit, presque tous les invariants du moteur.

### Périmètre de l'audit à venir

L'audit devra documenter, brique par brique, ce qui existe et comment c'est branché :

1. **Canvas central** — surface principale, scale responsive, gestion du clic, modes (édition / tampon / flip).
2. **Bibliothèque AIME** — sélecteur de document (`DocPicker`), 14 gabarits disponibles, switcheur, persistance du `doc_type`.
3. **Studio** — panneau latéral, ses 5 sections (Apparence, Identité, Contenu, Certification, IA), ses presets (`PAPER_FORMATS`, `FONT_PRESETS`, `ACCENT_COLORS`, `WATERMARK_PRESETS`, `FICHE_BACKGROUNDS`).
4. **Recto / Verso** — animation 3D flip, dualité native du canvas.
5. **QR** — `QRBadge`, génération de l'URL publique, position dans le verso.
6. **ShareMenu** — modes de partage disponibles, mention `[BROUILLON AIME — non opposable]`.
7. **SignaturePad** — capture visuelle, disclaimer obligatoire, persistance.
8. **Scellement** — `SealButton`, appel à `sealCachet`, états (`none`, `synced`, `stale`), affichage du hash et de la date de scellement.
9. **Champs éditables** — `contenteditable`, validation, sauvegarde dans `custom_notes`.
10. **Persistance** — débounce 800 ms sur `custom_notes`, persistance immédiate sur `doc_type`, gestion du `cachet_code`.
11. **Documents manquants** — détection, comptage, signalement, statut associé.

### Livrable attendu

Un document markdown unique :
- `docs/aime-fiche-view-audit.md` (nom suggéré, à confirmer)

Aucun code. Aucune modification applicative. Aucune route. Aucune entité.

### Pourquoi cet audit avant toute Phase 2

Parce qu'on ne **généralise** bien que ce qu'on a d'abord **observé** dans son détail réel. La page `/fiche/:id` est la première qui mérite cette observation, car elle concentre le plus grand nombre d'invariants du moteur.

---

## Conclusion

- **AIME CanvasCore** est nommé. C'est le moteur vivant qui existe déjà, en sept verbes et treize invariants.
- **AIME Cachet** reste intact, premier vertical et exemple complet du moteur.
- **AIME EventCore** est gelé en Phase 1, passif et silencieux.
- **La règle anti-doublon** est posée : un seul moteur, plusieurs configurations.
- **Le cadrage juridique** est verrouillé : préparatoire, non opposable, vocabulaire strict.
- **La prochaine étape** est un audit, pas du code.

> **AIME Cachet** est ce qu'on voit aujourd'hui.
> **AIME CanvasCore** est ce qu'on découvre derrière.
> **EventCore** est ce qu'on pourra construire demain — sans rien casser.

— Fin du document doctrinal —