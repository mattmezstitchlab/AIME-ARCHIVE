# 🧊 Freeze — Canvas Surface Foundation v1 (rail invisible)

**Statut** : ✅ Figé
**Date de freeze** : 23 mai 2026
**Phase** : AIME Event · Phase 2B.0 — Fondations multi-surface
**Périmètre** : Rail technique multi-surface, strictement invisible pour l'utilisateur

---

## 1. Objet du freeze

Ce document fige les **fondations techniques du Canvas Surface Mode** : ajout du champ
`surfaceMode` à `EventRecord`, création d'un registre de surfaces minimal, et
branchement transparent dans `EventFicheView`. Cette étape est **strictement invisible
pour l'utilisateur** — aucun changement perceptible n'est introduit.

Le rail prépare l'architecture multi-surface future (hero, faire-part, programme, billet, etc.)
sans en activer aucune. Toute future surface visible nécessitera un nouveau freeze daté.

---

## 2. Fichiers figés

| Fichier | Type | Rôle |
|---|---|---|
| `entities/EventRecord.json` | Étendu | Ajout du champ optionnel `surfaceMode` (enum 12 valeurs, default `document`) |
| `lib/event-core/surfaces/index.js` | Créé | Registre `SURFACE_REGISTRY` + helpers `resolveSurfaceRenderer()`, `isSurfaceActive()` |
| `pages/EventFicheView.jsx` | Modifié | 2 ops — import du resolver + substitution du composant central par `<SurfaceRenderer event={event} />` |

---

## 3. Champ ajouté à EventRecord

```json
"surfaceMode": {
  "type": "string",
  "enum": [
    "document", "hero", "faire_part", "programme", "billet",
    "carte", "web_page", "section", "affiche", "mini_site",
    "fiche_prestataire", "fiche_evenement"
  ],
  "default": "document"
}
```

| Propriété | Valeur |
|---|---|
| Type | `string` (enum) |
| Statut | Optionnel — jamais `required` |
| Default logique | `"document"` |
| Inclusion dans `HASHED_FIELDS` | ❌ Jamais |
| Inclusion dans un PDF | ❌ Jamais |
| Inclusion dans un scellement | ❌ Jamais |
| Exposition publique | ❌ Jamais |
| Nature | Strictement préparatoire, non opposable |

### 3.1 Valeur `fiche_invite` volontairement exclue

L'enum **n'inclut pas** `fiche_invite`. Cette exclusion est doctrinale et permanente
tant que ce freeze est en vigueur : pas de module invités, pas de RSVP, pas de
données nominatives d'invités.

---

## 4. Registre Canvas Surface (état figé)

| Clé | Status | Renderer | Visible UI |
|---|---|---|---|
| `document` | ✅ **active** | `EventFichePaper` | ✅ (comportement legacy) |
| `hero` | ⏸️ planned | — | ❌ |
| `faire_part` | ⏸️ planned | — | ❌ |
| `programme` | ⏸️ planned | — | ❌ |
| `billet` | ⏸️ planned | — | ❌ |
| `carte` | ⏸️ planned | — | ❌ |
| `web_page` | ⏸️ planned | — | ❌ |
| `section` | ⏸️ planned | — | ❌ |
| `affiche` | ⏸️ planned | — | ❌ |
| `mini_site` | ⏸️ planned | — | ❌ |
| `fiche_prestataire` | ⏸️ planned | — | ❌ |
| `fiche_evenement` | ⏸️ planned | — | ❌ |

### 4.1 Logique de fallback (figée)

```js
export function resolveSurfaceRenderer(mode) {
  const entry = SURFACE_REGISTRY[mode];
  if (entry && entry.status === "active" && entry.renderer) {
    return entry.renderer;     // seul "document" satisfait cette condition en v1
  }
  return SURFACE_REGISTRY[DEFAULT_SURFACE_MODE].renderer;  // = EventFichePaper
}
```

**Garantie** : tout mode non listé, planned, null, undefined ou inconnu retombe
**systématiquement** sur `EventFichePaper`. Le rendu A4 est doublement protégé.

---

## 5. Verrous doctrinaux

| Verrou | Statut |
|---|---|
| Champ `surfaceMode` optionnel | ✅ |
| Default logique `document` | ✅ |
| `fiche_invite` absent de l'enum | ✅ |
| Seul `document` actif dans le registre | ✅ |
| Toutes les autres surfaces marquées `planned` | ✅ |
| Fallback systématique vers `EventFichePaper` | ✅ |
| Aucun `SurfaceSwitcher` créé | ✅ |
| Aucun composant `SurfaceFrame` actif | ✅ |
| Aucune surface visible créée (hero, faire-part, programme, billet, affiche, mini-site, carte, web_page, section) | ✅ |
| Aucun changement visuel de la fiche A4 | ✅ |
| Aucun changement de la TopBar `EventFicheView` | ✅ |
| `EventFichePaper.jsx` non modifié | ✅ |
| `EventFicheVerso.jsx` non modifié | ✅ |
| `EventStudio.jsx` non modifié | ✅ |
| `EventCreateButton.jsx` non modifié par cette micro-action | ✅ |
| Watermark non extrait | ✅ |
| Footer doctrinal non extrait | ✅ |
| Aucun PDF généré | ✅ |
| Aucun hash calculé | ✅ |
| Aucun scellement opéré | ✅ |
| Aucune route publique créée | ✅ |
| Aucun endpoint public créé | ✅ |
| Aucun module invités, RSVP, co-organisation | ✅ |

---

## 6. Preuves de neutralité visuelle

### 6.1 Matrice de résolution du renderer

| `surfaceMode` reçu | Renderer résolu |
|---|---|
| absent (legacy, tous les EventRecord existants) | `EventFichePaper` |
| `null` | `EventFichePaper` |
| `undefined` | `EventFichePaper` |
| `"document"` | `EventFichePaper` |
| `"hero"` (planned) | `EventFichePaper` *(fallback)* |
| `"faire_part"` (planned) | `EventFichePaper` *(fallback)* |
| `"programme"` (planned) | `EventFichePaper` *(fallback)* |
| `"billet"` (planned) | `EventFichePaper` *(fallback)* |
| `"carte"` (planned) | `EventFichePaper` *(fallback)* |
| `"web_page"` (planned) | `EventFichePaper` *(fallback)* |
| `"section"` (planned) | `EventFichePaper` *(fallback)* |
| `"affiche"` (planned) | `EventFichePaper` *(fallback)* |
| `"mini_site"` (planned) | `EventFichePaper` *(fallback)* |
| `"fiche_prestataire"` (planned) | `EventFichePaper` *(fallback)* |
| `"fiche_evenement"` (planned) | `EventFichePaper` *(fallback)* |
| valeur inconnue | `EventFichePaper` *(fallback)* |

**100% des cas produisent le même rendu qu'avant cette micro-action.**

### 6.2 Vérifications UI

- 🔍 Aucune occurrence de `SurfaceSwitcher` dans le projet.
- 🔍 Aucune section "Surface" dans `EventStudio`.
- 🔍 Aucun bouton de choix de surface dans la TopBar `EventFicheView`.
- 🔍 Aucun choix de surface dans `EventCreateButton`.
- 🔍 TopBar `EventFicheView` inchangée (Retour · Trash2 · Banner · RotateCw · Pencil).

---

## 7. Garantie d'isolation AIME Cachet

Fichiers strictement non touchés par cette micro-action :

- `entities/Prestation.json`, `entities/HistoryEvent.json`, `entities/Wallet.json`, `entities/AssistantReminder.json`
- `lib/verificationHash.js`, `HASHED_FIELDS`
- `functions/sealCachet`, `functions/verifyCachet`
- `pages/FicheView.jsx`, `pages/MesPrestations.jsx`, `pages/Dashboard507.jsx`, `pages/Verify.jsx`, `pages/AimeCachet.jsx`
- Tous les templates `*Paper.jsx` AIME Cachet
- Routes `/app`, `/prestations`, `/507`, `/fiche/:id`, `/verify/:cachetCode`

Aucune backend function créée ou modifiée par cette micro-action.

---

## 8. Rollback

### 8.1 Rollback complet (< 30 secondes, 3 actions)

1. **`pages/EventFicheView.jsx`** : retirer l'import `resolveSurfaceRenderer` et remplacer
   le bloc `{(() => { const SurfaceRenderer = ... })()}` par `<EventFichePaper event={event} />`.
2. **`lib/event-core/surfaces/index.js`** : supprimer le fichier.
3. **`entities/EventRecord.json`** : retirer le champ `surfaceMode`. Rétro-compatible :
   les EventRecord existants ne dépendent pas de ce champ.

### 8.2 Rollback partiel

- Forcer `SURFACE_REGISTRY.document.status = "inactive"` → le fallback `DEFAULT_SURFACE_MODE`
  retombe quand même sur `EventFichePaper`. **Double protection** garantie.

### 8.3 Garantie

Aucun EventRecord existant n'a `surfaceMode` défini → tous résolvent `EventFichePaper` →
comportement **strictement identique** à l'état antérieur à cette micro-action.

---

## 9. Périmètre interdit (verrous permanents pour cette couche)

Tant que ce freeze est en vigueur, **aucune** des évolutions suivantes ne peut être ajoutée
au périmètre Canvas Surface Foundation sans un nouveau freeze daté :

- ❌ Activation d'une surface autre que `document` (hero, faire_part, programme, billet, etc.)
- ❌ Création d'un `SurfaceSwitcher` ou de tout sélecteur de surface visible
- ❌ Création d'un composant `SurfaceFrame` actif modifiant le rendu visuel
- ❌ Extraction du watermark `BROUILLON` hors d'`EventFichePaper`
- ❌ Extraction du footer doctrinal hors d'`EventFichePaper`
- ❌ Modification de `EventFichePaper.jsx`
- ❌ Modification de `EventFicheVerso.jsx`
- ❌ Modification de `EventStudio.jsx` pour exposer le choix de surface
- ❌ Modification de `EventCreateButton.jsx` pour préselectionner un `surfaceMode`
- ❌ Inclusion de `surfaceMode` dans un quelconque hash ou scellement
- ❌ Inclusion de `surfaceMode` dans un PDF ou une page publique
- ❌ Ajout de `fiche_invite` à l'enum (verrou doctrinal permanent)
- ❌ Création d'une nouvelle route publique
- ❌ Création d'un nouvel endpoint public
- ❌ Création d'un module invités, RSVP, co-organisation

---

## 10. Fichiers de référence (snapshot logique)

```
entities/EventRecord.json
  └─ surfaceMode : enum optionnel (12 valeurs · default "document" · fiche_invite EXCLU)

lib/event-core/surfaces/index.js
  ├─ SURFACE_REGISTRY         (1 active = "document", 11 planned)
  ├─ DEFAULT_SURFACE_MODE     = "document"
  ├─ resolveSurfaceRenderer() (fallback systématique vers EventFichePaper)
  └─ isSurfaceActive()        (helper, non utilisé en v1)

pages/EventFicheView.jsx
  ├─ Import resolveSurfaceRenderer
  └─ <SurfaceRenderer event={event} /> (= EventFichePaper en v1 strict)
```

---

## 11. Recommandation — prochaine micro-action possible

Une fois ce freeze entériné, la **prochaine micro-action sûre** envisageable
(non engagée — nécessite arbitrage explicite) serait :

> **Action #2 candidate : extraction non destructive de `DraftWatermark` et `DoctrineFooter`
> en composants partagés**, prêts à être réutilisés par de futures surfaces, sans modifier
> visuellement `EventFichePaper.jsx`.

Cette action préparerait l'arrivée d'une première surface visible (probablement `faire_part`
ou `programme`) lors d'une action #3 ultérieure, **chacune sous freeze indépendant**.

**Aucune action #2 n'est engagée par ce freeze.**

---

**Freeze signé** : 23 mai 2026 · AIME Event Phase 2B.0 · Canvas Surface Foundation v1
**Prochain freeze requis avant** : toute évolution du périmètre listé en §9