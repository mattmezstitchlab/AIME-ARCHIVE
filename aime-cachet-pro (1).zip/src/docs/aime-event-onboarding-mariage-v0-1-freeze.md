# 🧊 Freeze — Onboarding Mariage v0.1

**Statut** : ✅ Figé
**Date de freeze** : 23 mai 2026
**Phase** : AIME Event · Phase 2A.2 — Pilote Mariage
**Périmètre** : Onboarding préparatoire à modèles pour le type d'événement "mariage"

---

## 1. Objet du freeze

Ce document fige l'état de l'**Onboarding Mariage v0.1**, première itération d'un parcours
de création guidé pour les EventRecord de type `mariage`. La fonctionnalité prend la forme
d'un modal à 2 étapes proposant 3 modèles préparatoires + une option "Commencer vide".

Aucune modification de ce périmètre ne peut être engagée sans un nouveau freeze daté.

---

## 2. Fichiers figés

| Fichier | Type | Rôle |
|---|---|---|
| `lib/event-core/verticals/event.js` | Étendu | Définition de `WEDDING_TEMPLATES`, `WEDDING_TEMPLATES_LIST`, `getWeddingTemplate()` |
| `components/event/WeddingTemplatePicker.jsx` | Créé | Composant focalisé d'affichage des 3 modèles + option "Commencer vide" |
| `components/event/EventCreateButton.jsx` | Modifié | Modal à 2 étapes — bascule conditionnelle vers le picker si `eventType === "mariage"` |

---

## 3. Contenu figé

### 3.1 Modèles préparatoires (WEDDING_TEMPLATES)

| Clé | Label | Invités est. | Cérémonie | Documents recommandés |
|---|---|---|---|---|
| `intime` | Mariage intime | 30 | civile | fiche_event, planning, checklist, contacts_utiles |
| `classique` | Mariage classique | 100 | mixte | fiche_event, planning, programme, checklist, budget_simple, contacts_utiles |
| `festif` | Mariage festif | 180 | laïque | fiche_event, planning, programme, fiche_technique, checklist, budget_simple, contacts_utiles |

Champs préremplis par chaque modèle (uniquement des champs déjà existants et éditables) :
`title`, `audience`, `description`, `programme`, `prestataires`, `documents`,
`wedding_guest_count_estimate`, `wedding_ceremony_type`, `status`.

Champs **jamais préremplis** (laissés vides volontairement) :
`date`, `location`, `organizer`, `wedding_partners`, `wedding_date_civil`,
`wedding_budget_estimate`, `internal_notes`.

### 3.2 Flow utilisateur (modal à 2 étapes)

```
[ Bouton "Créer un événement" ]
        │
        ▼
[ Étape 1 — Choisir un type d'événement ]
        │
        ├─ Type ≠ mariage  ──►  handleCreate(typeKey)  ──►  Création immédiate (comportement legacy strictement préservé)
        │
        └─ Type === mariage ──► weddingStep = true
                                    │
                                    ▼
                          [ Étape 2 — WeddingTemplatePicker ]
                                    │
                                    ├─ Modèle choisi (intime|classique|festif) ──► Création avec préremplissage
                                    │
                                    └─ "Commencer vide" (templateKey = null) ──► handleCreate("mariage") (legacy strict)
```

### 3.3 Mode bouton direct (`defaultType="mariage"`)

Utilisé par `pages/EventsType.jsx` : ouvre directement le modal sur l'**étape 2** (picker de modèles),
sans passer par l'étape 1.

### 3.4 Wording doctrinal obligatoire

Affiché en tête du `WeddingTemplatePicker` :

> **Modèle préparatoire — entièrement modifiable.** Ces suggestions n'engagent personne
> et restent strictement privées.

Affiché en pied :

> Tous les modèles créent un brouillon strictement privé (*private_draft*) —
> aucune valeur officielle, aucun engagement.

---

## 4. Verrous doctrinaux

| Verrou | Statut |
|---|---|
| Aucun nouveau champ ajouté à `EventRecord` | ✅ |
| Tous les champs préremplis sont des champs existants et éditables | ✅ |
| Aucun RSVP | ✅ |
| Aucun module invités | ✅ |
| Aucune donnée nominative d'invités | ✅ |
| Aucune page publique créée | ✅ |
| Aucun endpoint public créé | ✅ |
| Aucun PDF généré | ✅ |
| Aucun hash calculé | ✅ |
| Aucun scellement opéré | ✅ |
| `visibility` reste `private_draft` pour tous les EventRecord créés | ✅ |
| Aucun champ marqué `required` ajouté | ✅ |
| Aucun import croisé avec AIME Cachet | ✅ |

---

## 5. Garantie de neutralité sur les autres types d'événements

| Type | Comportement post-freeze |
|---|---|
| `spectacle`, `concert`, `festival`, `conference`, `exposition`, `atelier`, `soiree_privee`, `associatif`, `seminaire` | **Strictement identique** au comportement antérieur — `handleCreate(typeKey)` direct, aucune étape 2 |
| `mariage` | Modal à 2 étapes — sauf "Commencer vide" qui appelle `handleCreate("mariage")` exact |

**Preuve technique** : dans `EventCreateButton.handleTypePick()`, seule la branche `typeKey === "mariage"`
bascule sur l'étape 2. Toutes les autres clés tombent dans `handleCreate(typeKey)`, exactement
comme avant cette micro-action.

**Preuve technique pour "Commencer vide"** : dans `handleWeddingPick(null)`, appel direct à
`handleCreate("mariage")` sans aucun champ supplémentaire — équivalent strict au comportement legacy.

---

## 6. Garantie d'isolation AIME Cachet

Fichiers strictement non touchés par cette micro-action :

- `entities/Prestation.json`, `entities/HistoryEvent.json`, `entities/Wallet.json`, `entities/AssistantReminder.json`
- `lib/verificationHash.js`, `HASHED_FIELDS`
- `functions/sealCachet`, `functions/verifyCachet`
- `pages/FicheView.jsx`, `pages/MesPrestations.jsx`, `pages/Dashboard507.jsx`, `pages/Verify.jsx`, `pages/AimeCachet.jsx`
- Tous les templates `*Paper.jsx` AIME Cachet
- Routes `/app`, `/prestations`, `/507`, `/fiche/:id`, `/verify/:cachetCode`

Aucune backend function créée ou modifiée par cette micro-action.

---

## 7. Rollback

### 7.1 Rollback complet (< 1 minute)

1. `components/event/EventCreateButton.jsx` : restaurer les 4 ops à l'état pré-modification
   (retirer `weddingStep`, `handleTypePick`, `handleWeddingPick`, `closeModal`,
   branche `defaultType === "mariage"`, branche `weddingStep` du modal).
2. `components/event/WeddingTemplatePicker.jsx` : supprimer le fichier.
3. `lib/event-core/verticals/event.js` : retirer `WEDDING_TEMPLATES`, `WEDDING_TEMPLATES_LIST`,
   `getWeddingTemplate` (les autres exports restent inchangés).

### 7.2 Rollback partiel

- Désactiver l'étape 2 en remplaçant `handleTypePick` par `handleCreate` directement
  → retour au comportement v0 sans toucher aux templates déclarés.
- Les `WEDDING_TEMPLATES` peuvent rester déclarés sans être utilisés (zéro impact).

### 7.3 Garantie

Aucun EventRecord existant n'est affecté. Les EventRecord créés via un modèle contiennent
uniquement des champs existants et éditables — un rollback les laisse parfaitement valides
et modifiables manuellement.

---

## 8. Périmètre interdit (verrous permanents pour cette couche)

Tant que ce freeze est en vigueur, **aucune** des évolutions suivantes ne peut être ajoutée
au périmètre Onboarding Mariage sans un nouveau freeze daté :

- ❌ Nouveaux modèles (au-delà des 3 existants + "Commencer vide")
- ❌ Modèles pour d'autres types d'événements
- ❌ Préremplissage de champs nominatifs (partenaires, organisateurs, invités)
- ❌ Préremplissage de `date`, `location`, `organizer`
- ❌ Préselection d'un `surfaceMode` (réservée à une évolution future explicite)
- ❌ Module invités, RSVP, partage public, page publique
- ❌ Génération PDF, hash, scellement
- ❌ Co-organisation, gestion de droits, partage de brouillon

---

## 9. Fichiers de référence (snapshot logique)

```
lib/event-core/verticals/event.js
  ├─ WEDDING_TEMPLATES = { intime, classique, festif }
  ├─ WEDDING_TEMPLATES_LIST
  └─ getWeddingTemplate(key)

components/event/WeddingTemplatePicker.jsx
  └─ Composant : 3 cartes modèles + 1 carte "Commencer vide" + wording doctrinal

components/event/EventCreateButton.jsx
  ├─ État weddingStep (bool)
  ├─ handleCreate(typeKey)                ← comportement legacy strict
  ├─ handleTypePick(typeKey)              ← aiguillage étape 1
  ├─ handleWeddingPick(templateKey|null)  ← étape 2
  └─ closeModal()
```

---

**Freeze signé** : 23 mai 2026 · AIME Event Phase 2A.2 · Onboarding Mariage v0.1
**Prochain freeze requis avant** : toute évolution du périmètre listé en §8