# AIME Event — Surface Doctrine Pre-UI

**Date :** 2026-05-23
**Statut :** Doctrine — préalable obligatoire à toute UI de sélection de surface
**Portée :** AIME Event uniquement — AIME Cachet hors périmètre et strictement intact.

---

## 0. Préambule

Ce document **précède** toute interface visible de sélection de surface dans AIME Event.

Il ne décrit aucun code, n'introduit aucune fonctionnalité, ne modifie aucun fichier existant. Il **tranche les questions doctrinales** ouvertes à l'issue du freeze `docs/aime-event-surface-faire-part-v0-freeze.md`, afin que toute évolution UI ultérieure parte d'un cadre stable et non ambigu.

Aucune action n'est autorisée sur la base de ce document tant qu'il n'a pas été **explicitement validé**. Une fois validé, il devient la **référence unique** pour la première UI de sélection de surface (v1 visible).

---

## 0bis. Modèle conceptuel — un EventRecord, plusieurs surfaces

**Règle fondamentale** (complète le §6 anti-doublon) :

> Un événement = **un seul `EventRecord`** (source unique).
> Plusieurs surfaces = **plusieurs manières de regarder / présenter** cette même source.

Toutes les surfaces existent **conceptuellement en même temps** sur un même `EventRecord` ; seules certaines sont **techniquement actives** et **doctrinalement autorisées** à un instant donné. `surfaceMode` n'est **pas** un choix exclusif de format de sortie : c'est le **point de vue courant** sur la source commune.

### Conséquences directes

- **Aucune surface n'est « le document » au sens générique.**
  - `document` est **la fiche préparatoire A4** : la **fiche source** structurée de l'événement.
  - `document` **n'est pas** le site, n'est pas la page publique, n'est pas un livrable final.
- **Wording imposé dans toute UI :** « Fiche préparatoire A4 ». **Jamais** « Document » seul, **jamais** « Site », **jamais** « Page ».
- **Les surfaces dérivées** (`faire_part`, et plus tard `hero`, `web_page`, `mini_site`, etc.) sont des **vues** de la fiche source, pas des entités séparées.
- **Le futur « site »** (`web_page`, `mini_site`) sera **une surface CanvasCore** parmi d'autres, alimentée par **le même `EventRecord`**. Il ne sera **jamais** un éditeur séparé, jamais une entité dédiée, jamais une page de création distincte.
- **Le `mini_site`** sera doctrinalement défini comme un **assemblage de plusieurs surfaces** (ex : `hero` + `programme` + `faire_part`) ordonnées, et non comme un nouveau type d'objet.

### Cartographie des surfaces (modèle conceptuel)

| Surface | Nature conceptuelle |
|---|---|
| `document` | **Fiche source** — fiche préparatoire A4 structurée. Point de vérité textuel. |
| `faire_part` | Vue graphique A5 dérivée (mariages, soirées privées). |
| `hero` | Vue « section d'accueil » dérivée — fragment visuel d'ouverture. |
| `programme` | Vue « déroulé » dérivée — lecture chronologique. |
| `billet` | Vue « admission préparatoire » dérivée (jamais opposable). |
| `carte` | Vue « carton » dérivée (invitation simple, plan d'accès, etc.). |
| `affiche` | Vue « placard » dérivée (aperçu privé uniquement). |
| `web_page` | Vue « page web privée en aperçu » dérivée. **Jamais** publiée en l'état. |
| `mini_site` | **Assemblage** de plusieurs surfaces dérivées du même `EventRecord`. |
| `section` | Fragment réutilisable d'une autre surface. |
| `fiche_prestataire` | Vue centrée prestataires dérivée. |
| `fiche_evenement` | Vue événementielle alternative (à définir doctrinalement). |

### Implications pour l'UI actuelle

- Le sélecteur Studio ne propose **pas** un choix exclusif « document **OU** faire-part » : il propose un **point de vue courant** sur la fiche source. Le `faire_part` ne remplace **jamais** la fiche A4 — il la **donne à voir autrement**.
- Le wording UI doit refléter cette doctrine : **« Fiche préparatoire A4 »**, **« Faire-part »**. Jamais d'opposition document / site / page.

### Implications pour les évolutions futures

- **Interdit** : un éditeur de site séparé, une entité `Website`, une page de création de mini-site dédiée.
- **Obligatoire** : toute nouvelle vue passe par la chaîne `EventRecord → surfaceMode → registre → EventFicheView → renderer canvas`.
- **Obligatoire** : le `mini_site`, quand il sera doctrinalement freezé, sera un **mode d'assemblage** de surfaces existantes — pas un nouvel éditeur.

Cette section 0bis est **non négociable** et complète le §6 anti-doublon : toute proposition contredisant le modèle « un EventRecord, plusieurs surfaces » doit être refusée d'emblée.

---

## 1. Matrice `eventType × surfaceMode`

Cette matrice définit, pour chaque type d'événement, **quelles surfaces sont doctrinalement légitimes**. Elle est indépendante de l'état technique (`active` / `planned`) : une case cochée signifie « surface autorisée en doctrine », pas « surface rendue aujourd'hui ».

Légende :
- ✅ **autorisée** — la surface a du sens doctrinal pour ce type d'événement
- 🟡 **autorisée plus tard** — sens doctrinal admis, mais surface encore `planned`
- ⛔ **non autorisée** — la surface n'a pas de sens doctrinal pour ce type

| `eventType` \ `surfaceMode` | `document` | `faire_part` | `programme` | `billet` | `carte` | `hero` | `affiche` | `web_page` | `mini_site` | `section` | `fiche_prestataire` | `fiche_evenement` |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| `mariage` | ✅ | ✅ | 🟡 | ⛔ | 🟡 | 🟡 | ⛔ | ⛔ | ⛔ | ⛔ | ⛔ | ⛔ |
| `soiree_privee` | ✅ | ✅ | 🟡 | 🟡 | 🟡 | 🟡 | ⛔ | ⛔ | ⛔ | ⛔ | ⛔ | ⛔ |
| `concert` | ✅ | ⛔ | 🟡 | 🟡 | ⛔ | 🟡 | 🟡 | ⛔ | ⛔ | ⛔ | ⛔ | ⛔ |
| `spectacle` | ✅ | ⛔ | 🟡 | 🟡 | ⛔ | 🟡 | 🟡 | ⛔ | ⛔ | ⛔ | ⛔ | ⛔ |
| `festival` | ✅ | ⛔ | 🟡 | 🟡 | ⛔ | 🟡 | 🟡 | ⛔ | ⛔ | ⛔ | ⛔ | ⛔ |
| `conference` | ✅ | ⛔ | 🟡 | ⛔ | 🟡 | 🟡 | ⛔ | ⛔ | ⛔ | ⛔ | ⛔ | ⛔ |
| `exposition` | ✅ | ⛔ | 🟡 | ⛔ | 🟡 | 🟡 | 🟡 | ⛔ | ⛔ | ⛔ | ⛔ | ⛔ |
| `atelier` | ✅ | ⛔ | 🟡 | ⛔ | 🟡 | ⛔ | ⛔ | ⛔ | ⛔ | ⛔ | ⛔ | ⛔ |
| `associatif` | ✅ | ⛔ | 🟡 | ⛔ | 🟡 | ⛔ | ⛔ | ⛔ | ⛔ | ⛔ | ⛔ | ⛔ |
| `seminaire` | ✅ | ⛔ | 🟡 | ⛔ | 🟡 | ⛔ | ⛔ | ⛔ | ⛔ | ⛔ | ⛔ | ⛔ |

**Lecture :**
- `document` est **universellement autorisée** : c'est la surface socle, toujours sélectionnable.
- `faire_part` n'est **autorisée doctrinalement** que pour `mariage` et `soiree_privee`. Toute apparition sur d'autres types est interdite.
- `web_page`, `mini_site`, `section`, `fiche_prestataire`, `fiche_evenement` ne sont **autorisées sur aucun type** à ce stade — leur sens doctrinal n'est pas tranché et leur risque d'apparence publique est trop élevé.
- Les surfaces marquées 🟡 restent **non sélectionnables** tant qu'elles ne sont pas individuellement freezées (voir §2 et §3).

**Règle d'application :**
La matrice est consultée **avant** d'afficher la moindre option dans l'UI. Une surface dont la case est ⛔ pour le type courant n'apparaît **jamais** dans la liste, même grisée.

---

## 2. Surfaces autorisées en v1 visible

La **première version UI** de sélection de surface dans `EventStudio` n'expose **que deux options** :

| Surface | Label UI proposé | Disponibilité |
|---|---|---|
| `document` | « Document A4 » | Tous types |
| `faire_part` | « Faire-part » | `mariage`, `soiree_privee` uniquement |

**Justification du choix prudent :**
- Ces deux surfaces sont les seules à être **techniquement `active`** dans `lib/event-core/surfaces/index.js`.
- Elles ont été **vérifiées visuellement** et freezées (`docs/aime-event-canvas-surface-foundation-v1-freeze.md`, `docs/aime-event-surface-faire-part-v0-freeze.md`).
- Elles sont **strictement préparatoires** par construction : `DraftWatermark` + `DoctrineFooter` présents, A4 ou A5 dans conteneur A4, aucun risque d'apparence opposable.
- Elles couvrent **80 % des cas d'usage Mariage** et **100 % des cas standards** (document A4 pour tous les autres types).

**Toute autre surface introduite dans l'UI v1 est interdite.**

---

## 3. Surfaces à **ne pas exposer** en v1

Sont **explicitement non sélectionnables** dans l'UI v1, quel que soit le type d'événement :

| Surface | Raison principale du non-exposition |
|---|---|
| `programme` | Pas encore freezée ; risque de confusion avec un programme officiel imprimable. |
| `billet` | Risque majeur — un « billet » suggère une admission réelle ; aucune doctrine de billetterie posée. |
| `carte` | Pas freezée ; ambigu (carte d'invité ? carte de visite ? plan d'accès ?). |
| `hero` | Pas freezée ; risque de ressembler à une bannière publique / vitrine. |
| `affiche` | Risque majeur — une « affiche » suggère un support diffusable hors app. |
| `web_page` | Risque majeur — suggère une page publique. Aucun endpoint public n'existe. |
| `mini_site` | Risque majeur — suggère un site invité. Aucun module invités, aucun RSVP. |
| `section` | Granularité non tranchée. |
| `fiche_prestataire` | Croise un domaine non encore ouvert (prestataires). |
| `fiche_evenement` | Doublon potentiel avec `document` ; sens non tranché. |

**Règle :** ces surfaces conservent leur statut `planned` dans le registre. Le `resolveSurfaceRenderer` continue de retomber silencieusement sur `document`. Aucune mention « bientôt » / « à venir » / « teaser » ne doit apparaître dans l'UI à leur sujet en v1.

---

## 4. Modèle de sélection UI

Comparaison des quatre modèles envisageables :

| Modèle | Avantages | Risques | Décision |
|---|---|---|---|
| **A. Sélection dans `EventStudio`** (section repliable) | Discret, contextualisé à l'édition, ne pollue pas le canvas, repli par défaut | Nécessite ouvrir le Studio pour voir l'option | ✅ **Retenu** |
| **B. `SurfaceSwitcher` dans TopBar** | Visible, rapide à manipuler | Met la sélection au même niveau que les actions « Éditer / Verso » → risque d'apparence opposable, contredit la doctrine préparatoire | ⛔ Rejeté |
| **C. Choix au moment de la création** | Pédagogique | Force un choix prématuré ; impossible à changer simplement ensuite | ⛔ Rejeté |
| **D. Choix dans la bibliothèque** | Centralise les surfaces | Crée une « galerie de templates » qui suggère un usage produit fini | ⛔ Rejeté |

**Décision retenue : modèle A.**

**Spécification doctrinale du modèle A (à respecter quand l'implémentation sera autorisée) :**
- Section **repliée par défaut** dans `EventStudio`, intitulée par exemple « Surface du canvas ».
- Listing **filtré** par la matrice du §1 : seules les surfaces ✅ pour le `eventType` courant **et** `active` techniquement apparaissent.
- En v1 : au maximum **deux entrées** (`document`, `faire_part`).
- Aucun aperçu graphique, aucune vignette de prévisualisation, aucune mention marketing.
- Wording neutre, doctrinal : « Document A4 », « Faire-part ». Aucun adjectif valorisant (« élégant », « premium », « pro »).
- Aucune entrée « Plus de surfaces… », « À venir », « Beta », « Nouveau ».
- Le changement de surface est **immédiatement réversible** et n'a **aucun effet de bord** (pas de migration de données, pas de génération, pas de scellement).

**Aucun `SurfaceSwitcher` TopBar n'est autorisé à ce stade.**

---

## 5. Garde-fous doctrinaux non négociables

Toute surface visible dans l'UI, **présente ou future**, doit respecter **sans exception** les invariants suivants :

### 5.1 Invariants de visibilité
- `visibility` reste **strictement** `private_draft`.
- Aucun endpoint public n'est ouvert pour la surface.
- Aucune URL partageable hors app authentifiée.
- Aucune mention « publier », « partager », « envoyer » dans l'UI de la surface.

### 5.2 Invariants doctrinaux
- La surface est **préparatoire**.
- La surface est **non opposable**.
- La surface n'a **aucune valeur officielle**.
- La surface doit être **validée humainement** avant tout usage hors app.

### 5.3 Invariants d'artefacts
- Aucun **PDF** généré.
- Aucun **hash** appliqué (le mécanisme `verification_hash` reste exclusif à `Prestation` / AIME Cachet).
- Aucun **scellement**.
- Aucune **certification**.
- Aucune **route `/verify`** étendue aux événements.

### 5.4 Invariants fonctionnels
- Aucun **RSVP**.
- Aucun **module invités**, aucune collecte d'adresses, aucun import de contacts.
- Aucun **envoi** d'email / SMS / lien.
- Aucune **billetterie**, aucun paiement.

### 5.5 Invariants visuels obligatoires
Toute surface visible **doit** conserver, en rendu :
- `DraftWatermark` (filigrane « BROUILLON » rotaté).
- `DoctrineFooter` (mention « Brouillon préparatoire — non opposable · À valider humainement / Aucune valeur officielle — ne constitue pas un document officiel »).
- Wording explicite **brouillon / préparatoire / non opposable / à valider humainement** dans la bannière supérieure de la page (`EventDraftBanner`).

**Aucune surface ne peut être promue `active` sans démonstration explicite, dans son freeze dédié, du respect de ces cinq familles d'invariants.**

---

## 6. Règle anti-doublon

Il est **interdit** de créer un éditeur séparé pour une surface, quelle qu'elle soit. Sont notamment proscrits :

| Interdit | Justification |
|---|---|
| Éditeur de **faire-part** séparé | Le faire-part est **un rendu** de `EventRecord`, pas une entité. |
| Éditeur de **site / mini-site** séparé | Idem. Et aucun site public n'existe. |
| Éditeur de **billet** séparé | Idem. Et aucune billetterie n'existe. |
| Éditeur d'**affiche** séparé | Idem. Et aucun support diffusable n'existe. |
| Page dédiée par surface | Romprait l'unicité du canvas central. |
| Entité séparée par surface | Multiplierait les schémas et casserait l'invariant `EventRecord` unique. |

**Règle unique et non négociable :**

> Tout rendu événementiel passe par la chaîne :
> **`EventRecord` → `surfaceMode` → registre `lib/event-core/surfaces` → `EventFicheView` → renderer canvas** (depuis `EventStudio` pour l'édition).

Aucun chemin alternatif n'est autorisé. Toute proposition contournant cette chaîne doit être **refusée d'emblée**, sans implémentation, sans prototype, sans branche d'essai.

---

## 7. Prochaine micro-action possible (si ce document est validé)

Si — et seulement si — ce document de doctrine est explicitement validé, **une seule micro-action** devient autorisée :

### Action autorisée

Créer dans `EventStudio` un **sélecteur discret** de surface, conforme strictement au modèle A décrit au §4, exposant **uniquement** :

- **Document A4** (`document`)
- **Faire-part** (`faire_part`) — visible **uniquement** si `eventType ∈ { mariage, soiree_privee }`

**Spécifications obligatoires de cette future micro-action :**
- Section repliée par défaut, intitulée « Surface du canvas ».
- Filtrage côté UI via la matrice du §1 (jamais en dur dans le composant).
- Aucune surface `planned` affichée — pas même en « à venir », « bientôt », « beta ».
- Changement de surface = simple `update` sur `EventRecord.surfaceMode`. Aucun effet de bord.
- Aucune modification du registre `lib/event-core/surfaces/index.js`.
- Aucune modification du schéma `EventRecord`.
- Aucun nouveau composant de rendu.
- Aucun nouveau composant doctrinal (réutilisation de `DraftWatermark` + `DoctrineFooter` uniquement).
- Aucun composant TopBar modifié.
- Aucun fichier AIME Cachet touché.

**Cette micro-action doit elle-même faire l'objet d'un freeze documentaire dédié** (`docs/aime-event-surface-selector-v1-freeze.md`) après vérification visuelle.

---

## 8. Interdictions explicites (récapitulatif)

Tant que la micro-action du §7 n'est pas explicitement autorisée :

- ❌ Ne pas modifier le code.
- ❌ Ne pas créer de `SurfaceSelector`, `SurfaceSwitcher`, `SurfacePicker`, `SurfaceMenu`, `SurfaceTabs`.
- ❌ Ne pas modifier `EventStudio`.
- ❌ Ne pas modifier `EventFicheView`.
- ❌ Ne pas modifier `EventFichePaper`.
- ❌ Ne pas modifier `SurfaceFairePart`.
- ❌ Ne pas modifier `lib/event-core/surfaces/index.js`.
- ❌ Ne pas modifier le schéma `EventRecord`.
- ❌ Ne pas ajouter de surface au registre.
- ❌ Ne pas activer `hero`, `programme`, `billet`, `carte`, `affiche`, `web_page`, `mini_site`, `section`, `fiche_prestataire`, `fiche_evenement`.
- ❌ Ne pas toucher AIME Cachet (`components/aime/**`, `functions/sealCachet`, `functions/verifyCachet`, schéma `Prestation`, `HASHED_FIELDS`, `/verify/:cachetCode`, tous les `*Paper.jsx` de Cachet).
- ❌ Ne pas ouvrir d'endpoint public, ne pas générer de PDF, ne pas hasher, ne pas sceller, ne pas créer de RSVP, ne pas créer de module invités.

---

## 9. Procédure de validation

Ce document est **valide** uniquement après :

1. Lecture explicite par le mainteneur doctrinal.
2. Validation explicite en chat (formulation type : « Doctrine Surface Pre-UI validée »).
3. Aucune modification de code n'a été tentée pendant la phase de validation.

Tant que la validation explicite n'est pas posée, **aucune action des §7 et §8 n'est autorisée**.

---

## 10. Référence croisée

Documents doctrinaux liés (lecture recommandée avant validation) :

- `docs/aime-event-phase-2a-freeze.md`
- `docs/aime-event-phase-2a-1-ui-freeze.md`
- `docs/aime-event-onboarding-mariage-v0-1-freeze.md`
- `docs/aime-event-wedding-studio-freeze.md`
- `docs/aime-event-canvas-surface-foundation-v1-freeze.md`
- `docs/aime-event-surface-shared-watermark-footer-freeze.md`
- `docs/aime-event-surface-faire-part-v0-freeze.md`
- `docs/aime-canvascore-doctrine.md`
- `docs/aime-eventcore-phase-1-freeze.md`

---

**Fin du document.**