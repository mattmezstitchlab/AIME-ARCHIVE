# AIME Event — Source Propagation Engine — Doctrine (cadrage)

**Date :** 2026-05-23
**Statut :** **Doctrine de cadrage — non implémentée.**
**Périmètre :** AIME Event uniquement — AIME Cachet strictement non concerné.
**Doctrines de référence :**
- `docs/aime-event-surface-doctrine-pre-ui.md` (modèle « un EventRecord, plusieurs surfaces »)
- `docs/aime-event-surface-wording-source-freeze.md` (wording « Fiche préparatoire A4 »)
- `docs/aime-canvascore-doctrine.md`

---

## 0. Préambule

Ce document **précède** toute implémentation. Il **ne décrit aucun code**, n'introduit aucune fonctionnalité visible, ne modifie aucun fichier existant. Il **fixe la doctrine** d'un futur moteur — le **Source Propagation Engine (SPE)** — afin que toute évolution ultérieure parte d'un cadre stable et non ambigu.

Aucune action n'est autorisée sur la base de ce document tant qu'il n'a pas été **explicitement validé** et qu'un freeze d'implémentation v0 n'a pas été émis.

---

## 1. Objectif

Quand une information est ajoutée, modifiée ou supprimée sur un `EventRecord`, **Cerise** (l'assistant AIME) doit être capable d'**identifier toutes les surfaces, documents, wallets, prestataires et actions** qui **dépendent** de cette information.

Le SPE est le **mécanisme de propagation** qui relie une donnée source à ses **dérivées préparatoires**.

### Exemple canonique

L'ajout d'une **date de mariage** à un `EventRecord` doit pouvoir alimenter :

- la **fiche préparatoire A4** ;
- le **faire-part** ;
- le **programme** ;
- le **planning Jour J** ;
- un **devis préparatoire** ;
- une **facture préparatoire** ;
- des **relances préparatoires** (rappels internes) ;
- une **checklist préparatoire** ;
- des **dossiers prestataires** (vues centrées prestataire) ;
- les futures surfaces **`web_page`** et **`mini_site`**.

Aucune de ces dérivées n'est **opposable**, **officielle**, ni **envoyée**. Toutes restent **strictement préparatoires** et **privées**.

---

## 2. Règle fondamentale — Cerise propose, l'humain valide

> **Cerise propose. L'humain valide. Toujours.**

Le SPE est un moteur de **proposition assistée**, jamais un moteur d'**exécution autonome**. Toute propagation doit :

1. Être **identifiée** par Cerise.
2. Être **présentée** à l'utilisateur sous forme de **proposition lisible**.
3. Être **explicitement validée** (un geste utilisateur dédié) avant tout effet sur le `EventRecord` ou ses surfaces.

L'utilisateur peut :
- **accepter** la proposition (totale ou partielle) ;
- **modifier** la proposition avant validation ;
- **rejeter** la proposition ;
- **différer** la proposition.

**Aucune propagation silencieuse.** **Aucune validation implicite.**

---

## 3. Périmètre fonctionnel — ce que le SPE FAIT

Le SPE est autorisé à :

| Verbe | Description |
|---|---|
| **Détecter** | Identifier qu'un champ source a changé et qu'il existe des dérivées potentielles. |
| **Préremplir** | Préparer des valeurs candidates dans les surfaces et documents dérivés, **en attente de validation**. |
| **Ranger** | Suggérer le rangement dans un wallet, une checklist, un dossier prestataire. |
| **Signaler** | Afficher un signal visuel non bloquant (badge, pastille, ligne d'historique) indiquant qu'une propagation est disponible. |
| **Proposer** | Émettre une proposition structurée, lisible, annulable, présentée à l'utilisateur. |
| **Préparer** | Construire des artefacts internes (brouillons, structures) **sans les rendre opposables, envoyables ou publiables**. |

---

## 4. Périmètre strictement interdit — ce que le SPE NE FAIT JAMAIS

Le SPE **n'a pas le droit** de produire d'**action externe automatique**. En particulier :

- ❌ **Aucun envoi** (email, SMS, notification externe, message tiers).
- ❌ **Aucune publication** (aucune surface ne devient publique, aucune URL ne s'ouvre).
- ❌ **Aucune signature** (numérique, manuscrite, électronique, ni cachet).
- ❌ **Aucune facture officielle** (aucun document opposable, aucun numéro de facture, aucune comptabilité).
- ❌ **Aucun devis envoyé** (les devis préparatoires restent internes et non transmis).
- ❌ **Aucune relance automatique sans validation** humaine explicite.
- ❌ **Aucun appel à un service tiers** (paiement, calendrier externe, CRM, etc.) sans déclenchement manuel.
- ❌ **Aucun scellement** au sens AIME Cachet. Le SPE **n'a aucun lien** avec `sealCachet` / `verifyCachet` / `verification_hash`.
- ❌ **Aucune modification rétroactive** d'un artefact déjà validé par l'humain sans nouvelle validation.

**Tout ce qui sort d'AIME Event vers le monde extérieur passe obligatoirement par un geste humain dédié.**

---

## 5. Modèle conceptuel

### 5.1 Source

La **source** est un champ (ou un ensemble de champs cohérents) d'un `EventRecord`. Exemples :
- `date`, `wedding_date_civil` ;
- `location` ;
- `wedding_partners` ;
- `wedding_guest_count_estimate` ;
- `organizer` ;
- `prestataires`.

### 5.2 Dérivées

Une **dérivée** est une cible préparatoire qui **dépend** d'une source. Une dérivée peut être :

- une **surface** (`document`, `faire_part`, `programme`, `hero`, `web_page`, `mini_site`, etc.) ;
- un **document préparatoire** (devis brouillon, facture brouillon, checklist) ;
- un **wallet** (dossier de rangement) ;
- une **action proposée** (rappel interne, suggestion, mémo) ;
- un **dossier prestataire** (vue centrée prestataire).

### 5.3 Lien de propagation

Un **lien de propagation** est une relation déclarative `source → dérivée` enregistrée dans une **table doctrinale** (à définir lors du freeze v0). Le SPE **ne déduit pas** les liens à la volée : ils sont **explicitement déclarés** dans `lib/event-core/` pour rester auditables.

### 5.4 Proposition

Une **proposition** est l'objet présenté à l'utilisateur. Elle contient :
- la **source** (champ + ancienne / nouvelle valeur) ;
- la **liste des dérivées impactées** ;
- pour chaque dérivée, la **valeur candidate** préremplie ;
- un **état** : `pending`, `accepted`, `modified`, `rejected`, `deferred`.

**Aucune proposition ne s'auto-applique.**

---

## 6. Invariants de sécurité

| # | Invariant |
|---|---|
| I-1 | Toute dérivée reste `private_draft`. Aucune surface ne devient publique via le SPE. |
| I-2 | Aucun envoi sortant. Aucun appel réseau vers un tiers déclenché par le SPE. |
| I-3 | Aucune mutation d'un artefact AIME Cachet. Le SPE est strictement isolé de `Prestation`, `cachet_code`, `verification_hash`. |
| I-4 | Toute proposition est **réversible** tant qu'elle n'a pas été validée. |
| I-5 | Une proposition validée peut être **annulée** par l'humain ; l'annulation ne ré-applique jamais l'ancienne proposition automatiquement. |
| I-6 | Le SPE n'écrit **jamais** dans une entité utilisée par AIME Cachet. |
| I-7 | Le SPE n'ouvre **jamais** d'URL externe ni de fenêtre de paiement. |
| I-8 | Toute propagation est **journalisée** (historique interne) pour audit. |
| I-9 | Le SPE peut être **désactivé globalement** sans rupture fonctionnelle d'AIME Event. |
| I-10 | Aucune surface future (`web_page`, `mini_site`, etc.) n'est ouverte au public par le SPE — il alimente, il ne publie pas. |

---

## 7. Architecture (cadrage, non implémentée)

Le SPE, lorsqu'il sera implémenté, devra :

1. Vivre dans `lib/event-core/propagation/` (chemin réservé, non créé à ce stade).
2. Exposer une **table déclarative** des liens `source → dérivées` — auditables, versionnés.
3. Exposer une **API pure** (fonctions sans effet de bord) : `detect(eventRecord, change) → Proposition[]`.
4. Être consommé par une **UI dédiée** dans `EventStudio` (panneau « Propositions de Cerise » à définir).
5. Persister les propositions dans une **entité dédiée** (nom réservé : `PropagationProposal`, **non créée** à ce stade).
6. Ne **jamais** être appelé depuis un composant AIME Cachet.

Toute implémentation devra faire l'objet d'un **freeze v0 dédié** (`docs/aime-event-source-propagation-v0-freeze.md`).

---

## 8. Wording imposé (pré-UI)

Pour toute future interface SPE :

- ✅ « Proposition de Cerise »
- ✅ « Préremplir »
- ✅ « Suggéré »
- ✅ « Brouillon préparatoire »
- ✅ « À valider »
- ❌ « Envoyer »
- ❌ « Publier »
- ❌ « Signer »
- ❌ « Facturer »
- ❌ « Confirmer définitivement »
- ❌ « Automatique » (sans qualificatif « proposition »)

---

## 9. Périmètres explicitement hors-scope du SPE

- **AIME Cachet** : totalement hors-scope. Aucun lien, aucune interaction.
- **Paiements Stripe** : hors-scope. Le SPE ne crée jamais de session Stripe, ne propose pas de checkout.
- **Connecteurs externes** (Google, Slack, etc.) : hors-scope au stade v0.
- **Génération PDF opposable** : hors-scope. Les dérivées sont des brouillons internes, jamais des artefacts officiels.
- **Synchronisation calendrier externe** : hors-scope.

---

## 10. Compatibilité doctrinale

Ce document est **strictement compatible** avec :

- §0bis de `docs/aime-event-surface-doctrine-pre-ui.md` (un EventRecord, plusieurs surfaces) — le SPE est précisément le moteur qui rend ce modèle exploitable.
- `docs/aime-event-surface-wording-source-freeze.md` — le SPE respecte le wording « Fiche préparatoire A4 ».
- `docs/aime-canvascore-doctrine.md` — le SPE alimente le canvas, ne le contourne pas.
- Freeze Phase 2A — aucune ouverture publique.

En cas de conflit futur entre ce document et un autre freeze, **le document le plus restrictif prévaut**.

---

## 11. Statut & prochaines étapes

- ✅ Doctrine de cadrage posée.
- ⏳ En attente : validation explicite de la doctrine.
- ⏳ En attente : freeze d'implémentation v0 (`docs/aime-event-source-propagation-v0-freeze.md`) — non rédigé à ce stade.
- ⏳ En attente : choix doctrinal du périmètre minimal de la v0 (quelle source, quelles dérivées).

**Aucune ligne de code SPE ne doit être écrite avant le freeze v0.**

---

**Fin du document de cadrage.**