# AIME Event — Source Propagation Rules v0 — Freeze documentaire

**Date :** 2026-05-23
**Statut :** **Freeze doctrinal — document figé.**
**Périmètre :** AIME Event uniquement — AIME Cachet strictement hors-scope.
**Nature :** Markdown déclaratif. **Non exécutable. Aucun code n'a été modifié.**

---

## 1. Objectif

Figer la **version réduite et prudente** du moteur cause → effet v0 (Source Propagation Engine, SPE) telle qu'elle résulte :

1. de la doctrine de cadrage (`docs/aime-event-source-propagation-doctrine.md`) ;
2. de l'itération réduite validée du draft v0 (`docs/aime-event-source-propagation-rules-v0-draft.md`, datée 2026-05-23) ;
3. de l'audit critique du 2026-05-23 ayant conduit à la réduction drastique du périmètre.

Ce freeze pose la **référence stable** pour toute itération doctrinale ou future implémentation. **Aucune implémentation n'est autorisée par ce document.** Tout passage à un code exécutable exigera un **freeze d'implémentation distinct**.

---

## 2. Fichier source figé

| Champ | Valeur |
|---|---|
| Chemin | `docs/aime-event-source-propagation-rules-v0-draft.md` |
| Version figée | Itération réduite du 2026-05-23 |
| Taille indicative | ~15 ko |
| Structure | §1 Objectif → §13 Rollback |
| Statut éditorial | **Figé.** Toute modification ultérieure exige un nouveau freeze documentaire. |

Le présent freeze ne duplique pas le contenu du draft : il **valide formellement** sa version courante et résume les décisions doctrinales qui le verrouillent.

---

## 3. Résumé du périmètre v0

Le SPE v0 est **drastiquement réduit** par rapport au draft initial :

| Dimension | Périmètre v0 |
|---|---|
| Sources actives | **5** |
| Surfaces alimentées | **2** (`document`, `faire_part`) |
| Wallets exposés | **1** (`W-TODO`) |
| Effets checklist | **5** items simples + 1 item de revue croisée |
| Documents générés automatiquement | **0** |
| Actions externes | **0** |
| Propositions comptables | **0** |
| Propositions officielles | **0** |
| Propagation transitive | **0** |
| Plafond par source | **3 propositions** |
| Plafond par `EventRecord` | **8 propositions** |

---

## 4. Sources actives v0

| Code | Champ `EventRecord` | Type |
|---|---|---|
| `S-TITLE` | `title` | string |
| `S-DATE` | `date` | date |
| `S-LOCATION` | `location` | string |
| `S-WED-PARTNERS` | `wedding_partners` | string *(mariage)* |
| `S-WED-DATE-CIVIL` | `wedding_date_civil` | date *(mariage)* |

Toutes les autres sources `EventRecord` restent **passives** (documentées, sans effet en v0).

---

## 5. Surfaces alimentées v0

| Surface | `surfaceMode` | Statut technique |
|---|---|---|
| Fiche préparatoire A4 | `document` | ✅ active |
| Faire-part | `faire_part` | ✅ active *(mariage, soirée privée)* |

**Aucune autre surface n'est alimentée par le SPE v0.** Les surfaces réservées (`hero`, `programme`, `billet`, `carte`, `web_page`, `mini_site`, etc.) restent **non alimentées**.

---

## 6. Wallet exposé v0

**Un seul wallet est exposé en v0 : `W-TODO` (« À compléter »).**

Comportement doctrinal :
- Source v0 renseignée → item retiré de `W-TODO`.
- Source v0 vidée → item ajouté à `W-TODO`.

Aucun autre wallet (`W-DOCS`, `W-PRESTA`, `W-BUDGET`, `W-SURF`, `W-DUE`, `W-VALID`) n'est exposé en v0.

---

## 7. Effets checklist simples v0

| Source | Item checklist |
|---|---|
| `S-DATE` | « Confirmer la date » |
| `S-LOCATION` | « Confirmer le lieu » |
| `S-WED-PARTNERS` | « Renseigner les partenaires » *(mariage)* |
| `S-WED-DATE-CIVIL` | « Confirmer la date civile » *(mariage)* |
| *(croisé)* | « Vérifier que la fiche préparatoire et le faire-part sont cohérents » |

**Aucun autre item checklist** ne peut être proposé par le SPE v0. Pas d'items J-*, pas d'items prestataires, pas d'items budget.

---

## 8. Plafonds

| Plafond | Valeur | Référence |
|---|---|---|
| Propositions actives par source | **≤ 3** | G-V0-16 du draft |
| Propositions actives par `EventRecord` | **≤ 8** | G-V0-17 du draft |

Au-delà du plafond par source, les nouvelles propositions remplacent les plus anciennes non validées. Au-delà du plafond par `EventRecord`, aucune nouvelle proposition n'est émise tant que l'humain n'a pas validé ou rejeté les propositions existantes.

---

## 9. Exclusion de `surfaceMode`

Conformément au §0bis de `docs/aime-event-surface-doctrine-pre-ui.md` et au §4.2 du draft v0 :

> `surfaceMode` est un **point de vue** sur la source commune, pas une donnée source.

**Changer la surface active ne déclenche aucune proposition SPE.** Exclusion **non négociable**, gelée par ce freeze.

---

## 10. Clarification — `eventType` est contexte, pas source active

Conformément au §4.1 du draft v0 :

> `eventType` sert à **initialiser le contexte** de l'événement, pas à déclencher des effets automatiques.

Changer `eventType` reconfigure le sous-graphe doctrinal entier (recommandations, surfaces autorisées, sections Studio). **Ce n'est pas une propagation**, c'est une **réinitialisation**.

**Le SPE v0 ne traite pas `eventType` comme une source.** Cette exclusion est gelée par ce freeze.

---

## 11. Éléments retirés de la v0

Liste exhaustive des éléments **interdits** dans les matrices v0 :

- Devis préparatoire.
- Facture préparatoire.
- Budget simple.
- Wallet « Budget ».
- Fiches prestataires auto.
- Contacts utiles auto.
- Plan de table.
- Relances prestataires.
- Rappels automatiques.
- Alertes de capacité.
- Alertes de dépassement budget.
- Planning Jour J automatique.
- Programme automatique.
- Échéances J-90 / J-60 / J-30 / J-7 / J-1.
- Génération automatique de document.
- Action externe (envoi, publication, signature, paiement).
- Proposition comptable.
- Proposition officielle.
- Propagation transitive A → B → C.

---

## 12. Roadmap — éléments déplacés (hors v0)

### 12.1 Roadmap v1 (sous freeze ultérieur)

- Surface `programme` + propagation `S-PROGRAMME`.
- Surface `hero` + propagation simple.
- Planning Jour J (document préparatoire interne).
- Checklist enrichie avec items J-*.
- Fiche prestataire auto (parsing contrôlé de `S-PRESTATAIRES`).
- Contacts utiles auto.
- Alertes de cohérence informatives.
- Wallets supplémentaires : `W-DOCS`, `W-PRESTA`, `W-DUE`, `W-SURF`.
- Sources actives `S-ORGANIZER`, `S-AUDIENCE`, `S-PROGRAMME`, `S-WED-CEREMONY`.

### 12.2 Roadmap v2 (sous freeze + refonte wording)

- Budget simple non comptable, **avec wording entièrement repensé**.
- Surfaces `web_page`, `mini_site` (assemblage).
- Sources actives `S-WED-GUESTS`, `S-WED-BUDGET`.
- Propagation transitive limitée (profondeur max 2, détection de cycles).
- Wallet `W-VALID` exposé en UI.

### 12.3 Roadmap v2+ (gel doctrinal strict)

- Devis / facture préparatoires : **interdits par défaut**. Réintroduction conditionnée à :
  - freeze doctrinal dédié ;
  - wording entièrement repensé (jamais « devis », jamais « facture ») ;
  - isolation visuelle et structurelle totale ;
  - revue juridique préalable.

---

## 13. Garde-fous figés

Les 22 garde-fous G-V0-1 à G-V0-22 du §11 du draft sont **figés par ce freeze**. Rappel des plus structurants :

| # | Invariant |
|---|---|
| G-V0-1 | Toute dérivée reste `private_draft`. |
| G-V0-2 | Aucun envoi sortant. |
| G-V0-3 | Aucune publication, aucune URL publique. |
| G-V0-4 | Aucune signature. |
| G-V0-5 | Aucun document officiel. |
| G-V0-6 | Aucun scellement, aucun hash, aucune interaction avec AIME Cachet. |
| G-V0-7 | Aucune relance externe, aucun rappel automatique. |
| G-V0-11 | `surfaceMode` n'est jamais une source. |
| G-V0-12 | `eventType` n'est jamais une source de propagation v0. |
| G-V0-16 | Maximum 3 propositions actives par source. |
| G-V0-17 | Maximum 8 propositions actives par `EventRecord`. |
| G-V0-18 | Aucune propagation transitive. |
| G-V0-19 | Aucune génération automatique de document. |
| G-V0-20 | Aucune proposition comptable. |
| G-V0-21 | Aucune proposition officielle. |
| G-V0-22 | Tout passage à un code exécutable exige un freeze d'implémentation explicite. |

---

## 14. Preuve — aucun code n'a été modifié

Vérifications associées à ce freeze :

- ✅ Aucun fichier `.js`, `.jsx`, `.ts`, `.tsx` créé ou modifié.
- ✅ Aucun fichier d'entité (`entities/*.json`) créé ou modifié.
- ✅ Aucun fichier d'agent (`agents/*.json`) créé ou modifié.
- ✅ Aucune fonction backend (`functions/*.js`) créée ou modifiée.
- ✅ Aucune route ajoutée à `App.jsx`.
- ✅ Aucun composant UI créé ou modifié.
- ✅ Aucun import ajouté nulle part.
- ✅ Aucune entité `PropagationProposal` créée.
- ✅ Aucun fichier `lib/event-core/propagation/*` créé.

Le présent freeze est **strictement documentaire**.

---

## 15. Preuve — AIME Cachet reste intact

- ✅ `components/aime/**` : 0 fichier modifié.
- ✅ `functions/sealCachet.js` : intact.
- ✅ `functions/verifyCachet.js` : intact.
- ✅ Schéma `Prestation` : inchangé.
- ✅ Champs `verification_hash`, `verification_hash_at`, `cachet_code` : inchangés.
- ✅ Constante `HASHED_FIELDS` : inchangée.
- ✅ Route `/verify/:cachetCode` : inchangée.
- ✅ Pages `AimeCachet`, `FicheView`, `MesPrestations`, `Dashboard507` : inchangées.
- ✅ Aucun PDF, aucun hash, aucun scellement, aucun endpoint public touché.

**AIME Cachet est strictement hors-scope** et le reste après ce freeze.

---

## 16. Rollback

Le freeze est **non destructif** et trivialement réversible.

### 16.1 Rollback du freeze (sans toucher au draft)

```
delete_file docs/aime-event-source-propagation-rules-v0-freeze.md
```

Le draft v0 reste en place et redevient document de travail non figé.

### 16.2 Rollback complet (freeze + draft)

```
delete_file docs/aime-event-source-propagation-rules-v0-freeze.md
delete_file docs/aime-event-source-propagation-rules-v0-draft.md
```

État final : seul `docs/aime-event-source-propagation-doctrine.md` (cadrage) subsiste. Aucun comportement applicatif modifié.

### 16.3 État après rollback

- Code d'AIME Event : intact.
- AIME Cachet : intact.
- Aucune migration, aucun nettoyage requis.

---

## 17. Prochaine étape recommandée — **non exécutée**

La prochaine étape **possible** (mais **non engagée** par ce freeze) consiste à :

1. **Rédiger** un freeze d'implémentation v0 séparé (`docs/aime-event-source-propagation-impl-v0-freeze.md`) qui :
   - Spécifie la **forme** de l'entité `PropagationProposal` (sans la créer).
   - Spécifie la **forme** d'un module pur `lib/event-core/propagation/rules-v0.js` (sans le créer).
   - Spécifie la **forme** d'une API pure `detect(eventRecord, change) → Proposition[]` (sans l'implémenter).
   - Spécifie le **point d'injection UI** minimal (sans l'implémenter).

2. **Faire valider** ce freeze d'implémentation explicitement avant tout passage au code.

3. **Seulement après validation** : envisager l'implémentation v0, sur un périmètre encore plus restreint si nécessaire (ex. uniquement `S-DATE` et `S-LOCATION` en première salve).

**Aucune de ces étapes n'est entreprise par ce freeze.** Le présent document fige uniquement les **règles doctrinales** ; il ne fige **aucune implémentation**.

---

## 18. Référence croisée

Documents doctrinaux liés :

- `docs/aime-event-source-propagation-doctrine.md` (cadrage SPE)
- `docs/aime-event-source-propagation-rules-v0-draft.md` (draft figé par ce document)
- `docs/aime-event-surface-doctrine-pre-ui.md` (modèle un EventRecord, plusieurs surfaces)
- `docs/aime-event-surface-wording-source-freeze.md` (wording « Fiche préparatoire A4 »)
- `docs/aime-event-surface-selector-v0-freeze.md` (Surface Selector v0)
- `docs/aime-canvascore-doctrine.md`
- `docs/aime-eventcore-phase-1-freeze.md`

---

**Fin du freeze documentaire.**