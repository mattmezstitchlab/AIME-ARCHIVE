# AIME Event — Source Propagation Engine v0 — Freeze d'implémentation

**Date :** 2026-05-23
**Statut :** **Gelé — implémentation v0 vérifiée visuellement et fonctionnellement.**
**Périmètre :** AIME Event uniquement — AIME Cachet strictement intact.
**Nature :** Markdown déclaratif documentant l'état figé du SPE v0 après micro-correction wording « Noter ».

**Rattachement :**
- `docs/aime-event-source-propagation-doctrine.md` (cadrage SPE général)
- `docs/aime-event-source-propagation-rules-v0-draft.md` (règles v0 réduites — brouillon)
- `docs/aime-event-source-propagation-rules-v0-freeze.md` (freeze règles SPE v0)
- `docs/aime-event-source-propagation-ui-v0-doctrine.md` (doctrine UI v0)
- `docs/aime-event-source-propagation-impl-v0-cadrage.md` (cadrage d'implémentation v0)
- `docs/aime-event-surface-doctrine-pre-ui.md`
- `docs/aime-event-surface-selector-v0-freeze.md`
- `docs/aime-event-surface-faire-part-v0-freeze.md`

---

## 1. Objectif

Figer formellement l'**implémentation v0** du Source Propagation Engine (SPE) après :

1. Implémentation initiale conforme à la doctrine UI v0 et au cadrage d'implémentation v0.
2. Vérification visuelle et fonctionnelle complète (rapport SPE v0 — analyse statique + simulation déterministe).
3. Arbitrage UX explicite du bouton ambigu : remplacement de **« Préparer »** par **« Noter »**.
4. Vérification ciblée finale du wording « Noter », du badge associé et du comportement strictement local/session.

Ce document **n'introduit aucun changement de code**. Il fige l'état atteint et constitue la référence stable pour toute évolution future, qui devra elle-même faire l'objet d'un freeze dédié.

---

## 2. Fichiers créés (depuis le cadrage d'implémentation v0)

| Fichier | Rôle |
|---|---|
| `lib/event-core/propagation/detect-v0.js` | Moteur déterministe pur de détection des propositions SPE v0. Fonction `detectProposals(event)` → `Proposition[]`. Aucun side effect, aucun import réseau, aucun cache. |
| `components/event/studio/SourcePropagationSection.jsx` | Section UI repliable « Ce que cette information déclenche » intégrée à `EventStudio`. Affiche les propositions calculées à la volée. Boutons : **Noter**, **Voir pourquoi**, **Plus tard**, **Ignorer**. Mémoire de session uniquement. |
| `docs/aime-event-source-propagation-impl-v0-freeze.md` | **Présent document.** |

---

## 3. Fichier modifié

| Fichier | Nature de la modification |
|---|---|
| `components/event/EventStudio.jsx` | Ajout de l'import `SourcePropagationSection` et insertion de `<SourcePropagationSection event={event} />` entre la section « Bibliothèque préparatoire » et la section « Surface du canvas ». Aucune autre modification. |

**Aucun autre fichier de code n'a été modifié dans le périmètre de l'implémentation SPE v0.**

Documents harmonisés au wording « Noter » lors de la micro-correction (sans impact code) :
- `docs/aime-event-source-propagation-impl-v0-cadrage.md`
- `docs/aime-event-source-propagation-ui-v0-doctrine.md`

---

## 4. Résumé du comportement

### 4.1 Flux complet

1. L'utilisateur ouvre `EventStudio` depuis `EventFicheView` (bouton « Éditer »).
2. Il saisit ou modifie des champs de l'`EventRecord` (`title`, `date`, `location`, `wedding_partners`, `wedding_date_civil`).
3. `detectProposals(event)` est recalculée à chaque rendu via `useMemo` à partir de l'état courant de l'`EventRecord`.
4. Si **au moins une proposition** est active, la section « Ce que cette information déclenche » devient visible (fermée par défaut).
5. L'utilisateur déplie la section et voit des cartes calmes, sans badge rouge, sans animation.
6. Pour chaque carte, 4 boutons sont disponibles : **Noter**, **Voir pourquoi**, **Plus tard**, **Ignorer**.
7. Les actions modifient uniquement un `useState` local (`sessionStatus`) — strictement aucune écriture externe.
8. Au rechargement de la page ou à la fermeture du Studio, l'état de session est perdu et toutes les cartes reviennent à `proposée`.

### 4.2 Statuts session

| Statut | Sens | Affichage |
|---|---|---|
| `proposée` | État par défaut, calculé à la volée | Carte visible avec 4 boutons |
| `notée` | L'utilisateur a cliqué « Noter » | Carte visible, fond emerald clair, badge « Notée en session — aucune modification appliquée. » |
| `plus tard` | L'utilisateur a cliqué « Plus tard » | Carte masquée (session uniquement) |
| `ignorée` | L'utilisateur a cliqué « Ignorer » | Carte masquée (session uniquement) |

Tous ces statuts vivent **exclusivement** dans le `useState(sessionStatus)` du composant. Aucun stockage backend, aucun `localStorage`, aucun `sessionStorage`.

---

## 5. Sources actives v0

| Code | Champ `EventRecord` | Filtre |
|---|---|---|
| `S-TITLE` | `title` | Tous types |
| `S-DATE` | `date` | Tous types |
| `S-LOCATION` | `location` | Tous types |
| `S-WED-PARTNERS` | `wedding_partners` | Mariage uniquement (`weddingOnly: true`) |
| `S-WED-DATE-CIVIL` | `wedding_date_civil` | Mariage uniquement (`weddingOnly: true`) |

**Aucune autre source n'est active en v0.** Les autres champs de l'`EventRecord` (`organizer`, `audience`, `description`, `programme`, `prestataires`, `wedding_guest_count_estimate`, `wedding_ceremony_type`, `wedding_budget_estimate`, `internal_notes`) sont **lus mais non utilisés comme déclencheurs** de propositions.

---

## 6. Surfaces concernées v0

| Surface | Code | Filtre par `eventType` |
|---|---|---|
| Fiche préparatoire A4 | `document` | Tous types |
| Faire-part | `faire_part` | `mariage`, `soiree_privee` uniquement |

**Aucune autre surface n'est ciblée par les propositions v0.** Les surfaces `hero`, `programme`, `billet`, `carte`, `web_page`, `section`, `affiche`, `mini_site`, `fiche_prestataire`, `fiche_evenement` restent `planned` et ne reçoivent **aucune** projection SPE v0.

---

## 7. Types de propositions v0

| Code | Type | Effet décrit |
|---|---|---|
| `P-SURF-DOC` | Projection vers la **Fiche préparatoire A4** | Suggestion de projection (jamais appliquée automatiquement) |
| `P-SURF-FP` | Projection vers le **Faire-part** | Suggestion de projection (jamais appliquée automatiquement) |
| `P-TODO-RM` | **Retrait** d'un item « À compléter » | Suggestion de résolution (calcul à la volée) |
| `P-CHECK` | Item de **checklist simple** | Suggestion « confirmer X » pour les sources vides |

**Aucun autre type de proposition n'est généré en v0.**

---

## 8. Plafonds v0

| Plafond | Valeur | Implémentation |
|---|---|---|
| Par source | **≤ 3 propositions** | `MAX_PER_SOURCE = 3` dans `detect-v0.js` |
| Par `EventRecord` | **≤ 8 propositions visibles** | `MAX_TOTAL = 8` dans `detect-v0.js` |
| Stratégie de troncature | Tri par priorité (`P-SURF-DOC` > `P-SURF-FP` > `P-CHECK` > `P-TODO-RM`), puis ordre stable des sources | Tri déterministe vérifié par simulation |

**Vérification mathématique (cf. rapport de vérification §4) :**
- 5 sources × 3 propositions max = 15 candidates théoriques.
- Après tri et troncature à 8 : strictement ≤ 8 visibles, plafonds toujours respectés.

---

## 9. Preuve — `eventType` est contexte / initialisation, jamais source

**Recherche exhaustive dans `lib/event-core/propagation/detect-v0.js` :**

- `eventType` est lu **uniquement** dans deux contextes filtrants :
  1. `isWedding = event.eventType === "mariage"` — pour appliquer le filtre `weddingOnly` sur les sources `S-WED-*`.
  2. `FAIRE_PART_TYPES.has(event.eventType)` — pour filtrer la cible `faire_part` (autorisée uniquement pour `mariage` et `soiree_privee`).
- `eventType` **n'apparaît dans aucune entrée du tableau `SOURCES`**.
- `eventType` **ne génère aucune proposition** directement.
- Modifier `eventType` ne crée pas de proposition spécifique : seules les sources `S-TITLE`, `S-DATE`, `S-LOCATION`, `S-WED-PARTNERS`, `S-WED-DATE-CIVIL` peuvent générer des propositions.

✅ **`eventType` est strictement un contexte de filtrage / initialisation. Conforme.**

---

## 10. Preuve — `surfaceMode` n'est pas une source

**Recherche exhaustive dans `lib/event-core/propagation/detect-v0.js` :**

- Le champ `event.surfaceMode` **n'est jamais lu** dans `detect-v0.js`.
- Aucune entrée de `SOURCES` ne mentionne `surfaceMode`.
- `surfaceMode` **ne génère aucune proposition**.
- Changer `surfaceMode` sur l'`EventRecord` **ne modifie pas la liste des propositions** retournées par `detectProposals(event)`.

✅ **`surfaceMode` est strictement un viewport / point de vue, jamais une source. Conforme à `aime-event-surface-doctrine-pre-ui.md` §0bis et G-11 de la doctrine UI v0.**

---

## 11. Preuve — « Noter » reste local/session

**Code exact du gestionnaire de clic (extrait de `SourcePropagationSection.jsx`) :**

```
const setStatus = (id, status) => {
  setSessionStatus((prev) => ({ ...prev, [id]: status }));
  if (openWhyId === id) setOpenWhyId(null);
};
```

**Stockage du statut :**

```
const [sessionStatus, setSessionStatus] = useState({});
```

**Analyse :**
- ✅ Le clic « Noter » appelle uniquement `setStatus(p.id, "notée")`.
- ✅ `setStatus` exécute exclusivement `setSessionStatus(...)` (mutation locale) + fermeture éventuelle du popover.
- ✅ `sessionStatus` est un `useState` local au composant.
- ✅ Aucun `useEffect` n'observe `sessionStatus` pour le synchroniser ailleurs.
- ✅ Aucun appel à `onChange` du parent, aucun appel à `base44.entities.*.update`, aucune écriture ailleurs.

**Conséquence au rechargement :**
1. `EventStudio` se démonte → `SourcePropagationSection` se démonte.
2. Le `useState(sessionStatus)` est perdu (React garbage collection).
3. Au remontage, `useState({})` réinitialise l'objet vide.
4. Toutes les cartes reviennent au statut par défaut `"proposée"`.

✅ **Statut « notée » strictement local et session-only. Conforme.**

---

## 12. Preuve — Aucune action externe

**Recherche exhaustive dans `components/event/studio/SourcePropagationSection.jsx` :**

| Action externe | Présence |
|---|---|
| Publication | ❌ Aucune (aucun bouton « Publier ») |
| Envoi (mail, SMS, webhook) | ❌ Aucune (aucun `mailto:`, aucun `fetch` vers tiers) |
| Signature | ❌ Aucune (aucun appel signature) |
| Génération PDF | ❌ Aucune (aucun import `jspdf`, `html2canvas`) |
| Hash | ❌ Aucune (aucun import `crypto`, aucun calcul `sha`) |
| Scellement | ❌ Aucune (aucun appel `sealCachet`, aucun champ `verification_hash`) |
| Endpoint public | ❌ Aucune route ouverte, aucun endpoint `/api/public/*` créé |
| Notification | ❌ Aucun toast, aucune `Notification(`, aucun `alert(` |
| Action de masse | ❌ Aucun bouton « Tout noter », « Tout accepter », « Tout préparer » |

✅ **Aucune action externe possible. Conforme à G-1 à G-19 de la doctrine UI v0.**

---

## 13. Preuve — Aucune écriture réseau

**Recherche exhaustive dans les 2 fichiers du SPE v0 (`detect-v0.js` + `SourcePropagationSection.jsx`) :**

| Mécanisme réseau | Présence |
|---|---|
| `fetch(` | ❌ Aucun |
| `XMLHttpRequest` | ❌ Aucun |
| `axios` | ❌ Aucun |
| `import { base44 }` | ❌ Aucun |
| `base44.*` (entities, functions, integrations, auth, analytics, agents) | ❌ Aucun |
| `.invoke(` | ❌ Aucun |
| `.list(`, `.filter(`, `.create(`, `.update(`, `.delete(`, `.get(` | ❌ Aucun |
| `.subscribe(` | ❌ Aucun |
| `WebSocket`, `EventSource` | ❌ Aucun |

**Imports complets de `SourcePropagationSection.jsx` :**
- `react`
- `lucide-react` (icônes `ChevronDown`, `HelpCircle`)
- `@/lib/event-core/propagation/detect-v0` (fonction pure)

**Imports complets de `detect-v0.js` :**
- (aucun import — module purement local)

✅ **Aucune écriture réseau possible. Le moteur SPE v0 est strictement client-side et pur.**

---

## 14. Preuve — Aucune entité `PropagationProposal` n'a été créée

**Vérification du dossier `entities/` :**

- ❌ Aucun fichier `entities/PropagationProposal.json` n'a été créé.
- ❌ Aucun fichier `entities/Proposition.json`, `entities/SpeProposal.json`, ou variante.
- ❌ Aucune nouvelle entité quelconque ajoutée pour le SPE v0.

**Conséquence doctrinale :**

Les propositions sont calculées **à la volée** depuis `detectProposals(eventRecord)` à chaque rendu. Aucune persistance, aucune historisation, aucune table. Conforme à §10 de la doctrine UI v0 (« La v0 ne crée aucune donnée nouvelle »).

✅ **Aucune entité créée. Conforme.**

---

## 15. Preuve — Aucun champ `EventRecord` n'a été ajouté

**Vérification du schéma `entities/EventRecord.json` :**

Liste complète des champs présents (inchangée depuis la dernière révision pré-SPE) :
- `eventType`, `title`, `date`, `location`, `organizer`, `audience`, `description`, `programme`, `prestataires`, `internal_notes`
- `status`, `visibility`, `public_code`
- `documents`, `studio_settings`
- `wedding_partners`, `wedding_date_civil`, `wedding_guest_count_estimate`, `wedding_ceremony_type`, `wedding_budget_estimate`
- `surfaceMode`

**Aucun champ ajouté pour le SPE v0.** Pas de `propagation_status`, pas de `noted_proposals`, pas de `spe_session_state`, pas de `propagation_meta`.

✅ **Schéma `EventRecord` strictement inchangé. Conforme.**

---

## 16. Preuve — AIME Cachet reste intact

| Zone Cachet | Statut |
|---|---|
| `components/aime/**` | ❌ 0 fichier touché |
| `functions/sealCachet.js` | ❌ 0 ligne modifiée |
| `functions/verifyCachet.js` | ❌ 0 ligne modifiée |
| `entities/Prestation.json` | ❌ Inchangée |
| `entities/HistoryEvent.json` | ❌ Inchangée |
| `entities/Wallet.json` | ❌ Inchangée |
| `entities/AssistantReminder.json` | ❌ Inchangée |
| `lib/verificationHash.js` | ❌ 0 ligne modifiée |
| `lib/sealedState.js` | ❌ 0 ligne modifiée |
| `lib/cachetCode.js` | ❌ 0 ligne modifiée |
| Routes `/app`, `/prestations`, `/507`, `/fiche/:id`, `/verify/:cachetCode` | ❌ Inchangées (App.jsx non touché) |
| `pages/AimeCachet`, `pages/FicheView`, `pages/Dashboard507`, `pages/Verify`, `pages/MesPrestations` | ❌ 0 fichier touché |
| Mécanisme de hash de vérification (`verification_hash`, `verification_hash_at`) | ❌ Exclusivement adossé à `Prestation`, jamais étendu à `EventRecord` |
| Mécanisme de scellement | ❌ Exclusivement Cachet, jamais étendu au SPE |

✅ **AIME Cachet strictement intact. Conforme à G-7, G-10 de la doctrine UI v0.**

---

## 17. Tests recommandés (procédure manuelle)

Aucun test automatisé n'a été créé en v0 (cf. cadrage d'implémentation §10). Les tests à effectuer manuellement avant validation utilisateur final :

### 17.1 Test du rendu de base

1. Ouvrir un événement existant via `/events/fiche/:id`.
2. Cliquer **Éditer** → `EventStudio` s'ouvre.
3. Vérifier la présence de la section **« Ce que cette information déclenche »** entre « Bibliothèque préparatoire » et « Surface du canvas ».
4. Vérifier que la section est **fermée par défaut**.
5. Vérifier le compteur discret à droite (« 5 », « 8 », etc.).
6. Vérifier l'absence de badge rouge, d'animation, de son.

### 17.2 Test du wording « Noter »

7. Déplier la section.
8. Vérifier que chaque carte affiche bien 4 boutons : **Noter**, **Voir pourquoi**, **Plus tard**, **Ignorer**.
9. Vérifier qu'**aucun bouton « Préparer »** n'apparaît nulle part.
10. Cliquer **Noter** sur une carte.
11. Vérifier que la carte passe en fond emerald clair.
12. Vérifier que le badge affiche exactement : **« Notée en session — aucune modification appliquée. »**
13. Vérifier que les 4 boutons disparaissent (carte non re-cliquable une fois notée).

### 17.3 Test des plafonds

14. Sur un mariage avec les 5 sources renseignées, vérifier que **≤ 8 cartes** sont affichées simultanément.
15. Vérifier qu'aucune source individuelle n'expose plus de **3 cartes**.

### 17.4 Test du filtrage `eventType`

16. Sur un événement `concert`, vérifier qu'**aucune carte `wedding_*`** n'apparaît.
17. Sur un événement `concert`, vérifier qu'**aucune carte ciblant le faire-part** n'apparaît.
18. Sur un mariage, vérifier que les cartes ciblant le faire-part apparaissent normalement.

### 17.5 Test de la mémoire de session

19. Cliquer **Plus tard** ou **Ignorer** sur plusieurs cartes → vérifier qu'elles disparaissent.
20. Recharger la page (`F5` ou Cmd+R).
21. Ré-ouvrir le Studio → vérifier que **toutes les cartes reviennent à l'état proposée** (mémoire perdue).
22. Cliquer **Noter** sur une carte, fermer le Studio, rouvrir → vérifier que la carte revient à proposée.

### 17.6 Test Network DevTools

23. Ouvrir DevTools → onglet **Network** → vider la liste.
24. Cliquer successivement **Noter**, **Voir pourquoi**, **Plus tard**, **Ignorer** sur 3 cartes différentes.
25. Vérifier que **0 nouvelle requête** apparaît dans Network (hors requêtes Studio non-SPE).

### 17.7 Test d'isolation Cachet

26. Aller sur `/app`, `/prestations`, `/fiche/:id` (Prestation), `/507`, `/verify/:cachetCode`.
27. Vérifier qu'**aucun comportement n'a changé** sur AIME Cachet.
28. Vérifier qu'aucune section « Ce que cette information déclenche » n'est apparue sur les fiches Cachet.

---

## 18. Rollback

Le freeze v0 est **strictement non destructif**. Trois niveaux de rollback possibles :

### 18.1 Niveau 1 — Annulation du wording « Noter » uniquement

Réappliquer en sens inverse les ops sur `SourcePropagationSection.jsx`, le cadrage et la doctrine UI :
- Remplacer « Noter » → « Préparer »
- Remplacer « notée » → « préparée »
- Remplacer « Notée en session — aucune modification appliquée. » → « Préparée (interne, non opposable) »

Aucun autre changement.

### 18.2 Niveau 2 — Désactivation de la section SPE dans le Studio

Dans `components/event/EventStudio.jsx` :
- Retirer la ligne `import SourcePropagationSection from "@/components/event/studio/SourcePropagationSection";`
- Retirer la ligne `<SourcePropagationSection event={event} />`

La section disparaît du Studio. Les fichiers `detect-v0.js` et `SourcePropagationSection.jsx` restent en place mais ne sont plus utilisés.

### 18.3 Niveau 3 — Suppression complète du SPE v0

Après le niveau 2 :
- `delete_file components/event/studio/SourcePropagationSection.jsx`
- `delete_file lib/event-core/propagation/detect-v0.js`

Aucune migration de données nécessaire :
- Aucune entité à supprimer.
- Aucun champ `EventRecord` à retirer.
- Aucun endpoint à fermer.
- Aucun document persistant à nettoyer.
- Aucun utilisateur impacté (mémoire de session perdue de toute façon à chaque rechargement).

**Aucun risque de perte de données.** Aucun artefact persistant n'existe.

---

## 19. Limites v0

### 19.1 Limites assumées par doctrine

| Limite | Justification |
|---|---|
| Statuts perdus au rechargement | Conforme à §9.2 et §10 de la doctrine UI v0. Acceptable en v0. |
| Aucune historisation des décisions « Ignorer / Plus tard » | Aucune entité créée. Re-décision possible au prochain affichage. |
| Aucune persistance des décisions « Noter » | Strictement local. Pas de mémoire entre sessions. |
| Maximum 8 propositions visibles | Plafond doctrinal pour préserver le calme préparatoire. |
| Aucune projection automatique | « Cerise propose, l'humain valide » — toujours. |
| Aucune notification, aucun toast | Conforme à §12 de la doctrine UI v0. |
| Aucun bouton de masse | Validation individuelle obligatoire. |
| Aucune extension à AIME Cachet | Isolation stricte garantie. |

### 19.2 Limites techniques

| Limite | Détail |
|---|---|
| Pas de scoring / priorité dynamique | Tri statique par type de proposition et ordre des sources. |
| Pas de mémoire des décisions inter-session | Recalcul intégral à chaque rendu. |
| Pas d'A/B testing du wording | Wording figé par cette doctrine. |
| Pas d'instrumentation analytics | Aucun event `base44.analytics.track`. |
| Pas de raccourcis clavier | Interaction souris/touch uniquement. |
| Pas d'export des propositions | Aucun « Copier la liste », aucun bouton d'export. |

---

## 20. Prochaine étape recommandée (non engagée)

**Aucune action n'est engagée par ce document.** Les pistes possibles, à arbitrer ultérieurement par freeze dédié :

### 20.1 Vérification runtime humaine

Effectuer la procédure de tests manuels §17 sur un parcours utilisateur complet, en environnement de preview Base44 authentifié. Recueillir les retours qualitatifs sur :
- Clarté du wording « Noter » et du badge associé.
- Perception du caractère préparatoire (zéro confusion avec un envoi réel).
- Acceptabilité du plafond 8.
- Ergonomie des 4 boutons par carte.

### 20.2 Audit de cohérence transverse

Effectuer un audit de cohérence entre les 5 freezes en place pour AIME Event :
- `aime-event-surface-doctrine-pre-ui.md`
- `aime-event-surface-selector-v0-freeze.md`
- `aime-event-surface-faire-part-v0-freeze.md`
- `aime-event-source-propagation-rules-v0-freeze.md`
- `aime-event-source-propagation-impl-v0-freeze.md` (présent document)

Objectifs : identifier les contradictions résiduelles, vérifier l'alignement du wording, confirmer que les garde-fous se renforcent mutuellement.

### 20.3 Extensions doctrinalement envisageables (jamais en v0)

À étudier dans un cadre v1 séparé, sous freeze dédié :
- Ajout d'une 6ᵉ source (par exemple `S-ORGANIZER` ou `S-AUDIENCE`).
- Ajout d'une 3ᵉ surface (par exemple `programme` ou `billet`, sous conditions doctrinales strictes).
- Persistance optionnelle des décisions « Ignorer » (avec entité `PropagationDecision` et nettoyage prévu).
- Wallet « À compléter » persistant.

**Toute extension v1+ exige un freeze documentaire préalable explicite.** Aucune extension n'est autorisée par le présent document.

---

## 21. Référence croisée

| Document | Rôle |
|---|---|
| `docs/aime-event-source-propagation-doctrine.md` | Cadrage SPE général |
| `docs/aime-event-source-propagation-rules-v0-draft.md` | Brouillon règles v0 |
| `docs/aime-event-source-propagation-rules-v0-freeze.md` | Freeze règles SPE v0 |
| `docs/aime-event-source-propagation-ui-v0-doctrine.md` | Doctrine UI v0 |
| `docs/aime-event-source-propagation-impl-v0-cadrage.md` | Cadrage d'implémentation v0 |
| **`docs/aime-event-source-propagation-impl-v0-freeze.md`** | **Présent document** |
| `docs/aime-event-surface-doctrine-pre-ui.md` | Doctrine pré-UI surfaces (§0bis) |
| `docs/aime-event-surface-wording-source-freeze.md` | Wording « Fiche préparatoire A4 » |
| `docs/aime-event-surface-selector-v0-freeze.md` | Surface Selector v0 |
| `docs/aime-event-surface-faire-part-v0-freeze.md` | Faire-part v0 |
| `docs/aime-canvascore-doctrine.md` | CanvasCore |

---

**Fin du freeze d'implémentation SPE v0.**