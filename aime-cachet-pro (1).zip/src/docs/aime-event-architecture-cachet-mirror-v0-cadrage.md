# AIME Event — Architecture miroir Cachet (Lot A · cadrage doctrinal v0)

**Statut** : 🟡 Cadrage — non implémenté, aucune écriture de code à ce stade.
**Date** : 2026-05-24
**Auteur** : Cerise (cadrage à valider par le copilote humain)
**Phase de projet** : 2A maintenue · `/events*` reste hors menu, brouillon privé, non opposable.

---

## 0. Objet du document

Ce cadrage **pose les règles** avant toute écriture de code permettant à `AIME Event` d'adopter
**l'architecture complète d'AIME Cachet** :

- Une **timeline** d'événements en préparation (équivalente à `/prestations`)
- Un **cockpit** central d'événements (équivalent à `/507`)
- Des **fiches événement** avec studio (existant — `EventFicheView`)
- Un **assistant** Cerise dédié événement (nouveau)
- Une couche de **composants visuels partagés** factorisés entre Cachet et Event

Le document ne contient **aucun code**. Il définit :
- ce qu'on fait,
- ce qu'on ne fait **jamais**,
- la séquence de lots de travail,
- les invariants de sécurité doctrinale,
- les critères de validation avant passage au Lot B.

---

## 1. Principe directeur

> **Même grammaire visuelle. Domaines fonctionnels strictement séparés.**

- L'utilisateur retrouve dans Event les mêmes **gestes**, les mêmes **codes visuels**,
  la même **ergonomie** que dans Cachet — pour ne pas avoir à réapprendre l'interface.
- Mais les **données**, les **entités**, la **doctrine** et les **invariants** restent
  **100 % séparés**. Aucune contamination de Cachet par Event, ni l'inverse.

Cela suppose une **couche partagée** de composants **visuels purs** — qui ne connaissent
ni `Prestation`, ni `EventRecord`, ni aucune entité métier.

---

## 2. Inventaire de l'existant

### 2.1 Côté Cachet (à NE PAS toucher dans ce chantier)

| Domaine | Fichiers principaux |
|---|---|
| Cockpit central | `pages/Dashboard507.jsx` |
| Timeline / liste | `pages/MesPrestations.jsx` + `components/aime/Timeline.jsx` + `components/aime/timeline/*` |
| Fiche détail | `pages/FicheView.jsx` + `components/aime/fiche/*` |
| Studio fiche | `components/aime/fiche/studio/*` |
| Assistant | `components/aime/machine/AimeMachine.jsx` + `components/aime/assistant/*` |
| Entités | `Prestation`, `HistoryEvent`, `Wallet`, `AssistantReminder` |

### 2.2 Côté Event (existant à étendre)

| Domaine | Fichiers principaux |
|---|---|
| Route racine | `pages/Events.jsx` (sélecteur de type) |
| Route par type | `pages/EventsType.jsx` (cartes par type) |
| Fiche détail | `pages/EventFicheView.jsx` |
| Studio | `components/event/EventStudio.jsx` + `EventStudioSection`, `SurfaceSelector`, `SourcePropagationSection` |
| Surface | `components/event/EventFichePaper.jsx`, `EventFicheVerso.jsx`, `SurfaceFairePart.jsx` |
| Doctrine code | `lib/event-core/*` |
| Entités | `EventRecord` |

### 2.3 Ce qui manque côté Event (à créer)

| Besoin | Statut |
|---|---|
| Cockpit central Event | ❌ à créer |
| Timeline chronologique Event | 🟡 partiel (Events affiche par type, pas par date) |
| Assistant Cerise Event | ❌ à créer |
| Entité log Event (`EventHistoryEvent`) | ❌ à créer |
| Composants visuels partagés | ❌ à factoriser |

---

## 3. Architecture cible (3 couches)

### Couche 1 — Composants visuels partagés (`components/shared/cockpit/`)

**Vocation** : composants **visuels purs**, sans logique métier, sans dépendance à `Prestation`
ou `EventRecord`. Reçoivent tout en props.

| Composant | Rôle |
|---|---|
| `CockpitHero` | Gros compteur central + sous-titre + éventuelle barre de progression |
| `CockpitMilestones` | Liste de jalons doctrinaux (titre, statut, description) |
| `CockpitSuggestions` | Liste de suggestions (icône, label, route) |
| `TimelineGroup` | Header de groupe (mois, année) + slot enfants |
| `TimelineCard` | Coque générique de carte timeline (icône, titre, sous-titre, badge, statut) |
| `CockpitTimelineLayout` | Layout côte-à-côte cockpit / timeline avec gestion responsive |

**Règle absolue** : **aucun import** depuis `entities/`, `lib/intermittent507.js`, `lib/event-core/`
ou `lib/aimeData.js`. Si un composant a besoin d'un calcul métier, il le reçoit déjà calculé.

### Couche 2 — Cachet (existante, intacte)

- `pages/Dashboard507` + `pages/MesPrestations` **continuent de fonctionner à l'identique**.
- Un **refactor optionnel et progressif** pourra plus tard consommer la couche 1, **sans
  régression visuelle ni fonctionnelle**. Ce refactor n'est **pas inclus** dans ce chantier.

### Couche 3 — Event (nouvelle, parallèle à Cachet)

| Fichier | Rôle |
|---|---|
| `pages/EventsCockpit.jsx` | Page hybride cockpit + timeline événements (route `/events`) |
| `components/event/cockpit/EventHero.jsx` | Utilise `CockpitHero`, alimente avec données `EventRecord` |
| `components/event/cockpit/EventMilestones.jsx` | Jalons doctrinaux propres à Event |
| `components/event/cockpit/EventSuggestions.jsx` | Suggestions Cerise contextualisées Event |
| `components/event/cockpit/EventTimeline.jsx` | Timeline chronologique `EventRecord` |
| `components/event/cockpit/EventTimelineCard.jsx` | Carte d'événement (utilise `TimelineCard`) |
| `components/event/assistant/EventAssistant.jsx` | Assistant Cerise dédié Event |
| `components/event/assistant/EventAssistantEngine.js` | Moteur de propositions Event (déterministe, pur) |
| `entities/EventHistoryEvent.json` | Journal d'événements préparatoires Event |

---

## 4. Invariants doctrinaux non négociables

### 4.1 Séparation Cachet ↔ Event

🔒 Aucun composant Event ne lit, n'écrit ni n'affiche une `Prestation`.
🔒 Aucun composant Cachet ne lit, n'écrit ni n'affiche un `EventRecord`.
🔒 Aucun composant partagé (couche 1) ne connaît `Prestation` ni `EventRecord`.
🔒 La couche 1 vit dans `components/shared/cockpit/` et **n'importe rien depuis `components/aime/*`
   ni `components/event/*`**.

### 4.2 Phase 2A maintenue

🔒 `/events*` reste **hors `SideRail`** et **hors `MobileMenu`** — accès **par URL uniquement**.
🔒 `EventRecord.visibility` reste **strictement** `private_draft`.
🔒 Aucun PDF officiel, aucun envoi externe, aucun scellement, aucun hash, aucun QR vérifiable
   côté Event.
🔒 La doctrine `EVENT_DOCTRINE_LABELS` (préparatoire · revue humaine · non officiel) doit
   apparaître dans chaque page Event.

### 4.3 Assistant Event

🔒 L'assistant Event **n'envoie rien**, **ne signe rien**, **ne scelle rien**, **ne publie rien**.
🔒 Reste strictement sur la grammaire **« Cerise propose, vous validez »**.
🔒 Aucune réutilisation directe du moteur Cachet (`assistantLocalEngine`, `aiAssistant`) — qui
   parle de 507h, AJ, annexes, hash : sans rapport avec Event.
🔒 Un moteur **dédié, séparé, déterministe** : `EventAssistantEngine.js`.

### 4.4 Entité `EventHistoryEvent`

🔒 **Strictement préparatoire**. Ne mentionne **jamais** un scellement, un envoi, un PDF officiel.
🔒 Schema parallèle à `HistoryEvent` mais **distinct** :
  - `kind` ∈ `event_created`, `event_updated`, `event_status_changed`, `event_surface_changed`,
            `event_proposition_noted`
  - `event_id` (au lieu de `prestation_id`)
  - Aucun champ `cachet_code`, aucun hash, aucune empreinte.
🔒 Aucune relation, aucun import croisé avec `HistoryEvent`.

### 4.5 Aucune modification du moteur 507

🔒 `Dashboard507`, `MesPrestations`, `FicheView`, `AimeMachine`, et tous les composants
   `components/aime/*` **ne sont pas touchés** par ce chantier.
🔒 Si un refactor visuel est tenté plus tard, il sera traité comme un **chantier séparé**,
   avec son propre cadrage et son propre freeze.

---

## 5. Séquence des lots

| Lot | Contenu | Risque | Pré-requis |
|---|---|---|---|
| **A** | **Doctrine de cadrage écrite** (ce document) | Faible | — |
| **B** | Couche 1 : composants visuels partagés `components/shared/cockpit/*` | Faible | Validation Lot A |
| **C** | `pages/EventsCockpit.jsx` + `components/event/cockpit/*` | Moyen | Validation Lot B |
| **D** | Entité `EventHistoryEvent` + hooks de log dans Event | Moyen | Validation Lot C |
| **E** | `EventAssistant` + `EventAssistantEngine` | Élevé | Validation Lots C et D |

Chaque lot dispose de **son propre freeze documentaire** au moment de sa clôture.

---

## 6. Critères de validation pour passer au Lot B

Le Lot A est considéré validé quand le copilote humain confirme :

1. ✅ Les **invariants doctrinaux** (§4) sont acceptés tels quels.
2. ✅ La **séquence des lots** (§5) est acceptée.
3. ✅ L'**architecture en 3 couches** (§3) est acceptée.
4. ✅ La **liste des composants partagés** (couche 1) est acceptée — sans entité métier importée.
5. ✅ La **liste des fichiers Event à créer** (couche 3) est acceptée.

Tant que ces 5 points ne sont pas confirmés, **aucun code n'est écrit**.

---

## 7. Points ouverts (à trancher avant Lot B)

🟡 **Route `/events`** : faut-il que `/events` devienne directement la `EventsCockpit`, ou
   garder le sélecteur de type actuel et créer `/events/cockpit` ?
   — Recommandation Cerise : `/events` = cockpit, et le sélecteur de type devient un bouton
   « + Nouvel événement » dans le cockpit.

🟡 **Création d'événement** : faut-il un bouton flottant dans le cockpit (comme `EventCreateButton`) ?
   — Recommandation Cerise : oui, en haut à droite du cockpit, ouvre un picker de type.

🟡 **Mention dans la Landing** : la mention discrète Event en footer est déjà en place. Pas de
   changement nécessaire avec ce chantier.

🟡 **Mobile** : le layout « côte-à-côte cockpit + timeline » doit-il rester côte-à-côte sur
   mobile ou se transformer en empilé (cockpit haut, timeline bas) ?
   — Recommandation Cerise : empilé sur mobile, côte-à-côte à partir de `lg:`.

🟡 **Assistant Event** : faut-il l'intégrer dès le cockpit ou attendre le Lot E pour ne pas
   surcharger ?
   — Recommandation Cerise : attendre le Lot E, le cockpit fonctionne sans assistant.

---

## 8. Rollback

Ce document **n'introduit aucun code**. Aucun rollback n'est nécessaire.
Le rollback de chaque lot ultérieur sera défini dans son propre freeze.

---

## 9. Annexe — Diagramme des dépendances autorisées

```
┌─────────────────────────────────────────────────────────────┐
│                       Couche 1 (partagée)                   │
│              components/shared/cockpit/*                    │
│                                                             │
│   ⛔ N'importe AUCUNE entité, AUCUN composant aime/event     │
└─────────────────┬───────────────────────────┬───────────────┘
                  │                           │
                  ▼                           ▼
┌─────────────────────────────┐  ┌─────────────────────────────┐
│       Couche 2 (Cachet)     │  │       Couche 3 (Event)      │
│   pages/Dashboard507        │  │   pages/EventsCockpit       │
│   pages/MesPrestations      │  │   components/event/cockpit/*│
│   pages/FicheView           │  │   components/event/assistant│
│   components/aime/*         │  │   pages/EventFicheView      │
│                             │  │                             │
│   entité : Prestation       │  │   entité : EventRecord      │
│   entité : HistoryEvent     │  │   entité : EventHistoryEvent│
│                             │  │                             │
│   ⛔ N'importe RIEN d'Event  │  │   ⛔ N'importe RIEN de Cachet│
└─────────────────────────────┘  └─────────────────────────────┘
```

---

**Fin du Lot A — Cadrage doctrinal.**

> Lot B (composants partagés) ne démarre que sur validation explicite de ce document.