# AIME Event — Surface Selector v0 — Freeze documentaire

**Date :** 2026-05-23
**Statut :** Gelé (v0 — sélecteur discret dans EventStudio)
**Périmètre :** AIME Event uniquement — AIME Cachet strictement non impacté.
**Doctrine de référence :** `docs/aime-event-surface-doctrine-pre-ui.md`

---

## 1. Objectif

Exposer **discrètement** dans `EventStudio` le choix de surface du canvas, en respectant strictement la doctrine Pre-UI :

- Section **repliable**, **repliée par défaut**, en bas du Studio (avant la section Visibilité).
- Affiche **uniquement** les surfaces **actives et autorisées** pour le type courant.
- Toutes les surfaces `planned` sont **totalement masquées** (aucune mention « à venir », « bientôt », « beta », « nouveau »).
- Aucun `SurfaceSwitcher` TopBar.

---

## 2. Fichiers créés

| Fichier | Rôle |
|---|---|
| `components/event/studio/SurfaceSelector.jsx` | Composant focalisé — section repliable, radio group, filtrage par `eventType` via la matrice doctrinale interne. |
| `docs/aime-event-surface-selector-v0-freeze.md` | Présent document de freeze. |

---

## 3. Fichiers modifiés

| Fichier | Nature de la modification |
|---|---|
| `components/event/EventStudio.jsx` | 1 import ajouté (`SurfaceSelector`) + 1 insertion du composant juste avant la section `Visibilité`. Aucune autre ligne modifiée. |

**Aucun autre fichier n'a été modifié.**

Restés **strictement intacts** :
- `pages/EventFicheView.jsx`
- `components/event/EventFichePaper.jsx`
- `components/event/EventFicheVerso.jsx`
- `components/event/SurfaceFairePart.jsx`
- `components/event/EventCreateButton.jsx`
- `components/event/EventDraftBanner.jsx`
- `components/event/surface/DraftWatermark.jsx`
- `components/event/surface/DoctrineFooter.jsx`
- `entities/EventRecord.json`
- `lib/event-core/surfaces/index.js`
- `lib/event-core/verticals/event.js`
- `App.jsx`
- L'intégralité de `components/aime/**` (AIME Cachet)
- L'intégralité de `functions/**` (`sealCachet`, `verifyCachet`)

---

## 4. Comportement vérifié

### 4.1 Affichage par type d'événement

| `eventType` | Options visibles dans le sélecteur |
|---|---|
| `mariage` | ✅ Document A4 + Faire-part |
| `soiree_privee` | ✅ Document A4 + Faire-part |
| `concert` | ✅ Document A4 uniquement |
| `spectacle` | ✅ Document A4 uniquement |
| `festival` | ✅ Document A4 uniquement |
| `conference` | ✅ Document A4 uniquement |
| `exposition` | ✅ Document A4 uniquement |
| `atelier` | ✅ Document A4 uniquement |
| `associatif` | ✅ Document A4 uniquement |
| `seminaire` | ✅ Document A4 uniquement |

**Aucune mention** des 10 surfaces `planned` (`hero`, `programme`, `billet`, `carte`, `web_page`, `section`, `affiche`, `mini_site`, `fiche_prestataire`, `fiche_evenement`).

### 4.2 Wording figé

| Élément | Wording exact |
|---|---|
| Titre | « Surface du canvas » |
| Sous-titre | « Choisissez la surface utilisée pour le rendu du brouillon. » |
| Option 1 | « Document A4 » — « Fiche standard, tous types d'événements. » |
| Option 2 | « Faire-part » — « Carte A5 préparatoire — mariages et soirées privées. » |
| Pied de section | « Toutes les surfaces restent privées, préparatoires et non opposables. » |

### 4.3 Comportement de sauvegarde

- ✅ Radio group natif (pas de select).
- ✅ Update immédiat de `event.surfaceMode` via `handleField("surfaceMode", v)` existant.
- ✅ Debounce Studio existant (600ms) déclenche `base44.entities.EventRecord.update`.
- ✅ Aucun toast.
- ✅ Aucun bouton « Enregistrer ».
- ✅ Aucun modal de confirmation.
- ✅ Section repliée par défaut (chevron rotaté à l'ouverture).

### 4.4 Rendu canvas

- ✅ Bascule vers `faire_part` → `resolveSurfaceRenderer` retourne `SurfaceFairePart` → rendu A5 dans conteneur A4.
- ✅ Retour à `document` → `resolveSurfaceRenderer` retourne `EventFichePaper` → rendu A4 standard.
- ✅ `DraftWatermark` + `DoctrineFooter` + `EventDraftBanner` toujours présents sur les deux surfaces.

---

## 5. Garde-fous doctrinaux respectés

| Invariant | Statut |
|---|---|
| `visibility: "private_draft"` inchangé | ✅ |
| Aucun PDF généré | ✅ |
| Aucun hash | ✅ |
| Aucun scellement | ✅ |
| Aucune route `/verify` étendue | ✅ |
| Aucun endpoint public | ✅ |
| Aucun RSVP | ✅ |
| Aucun module invités | ✅ |
| `DraftWatermark` + `DoctrineFooter` rendus | ✅ |
| Aucun `SurfaceSwitcher` TopBar | ✅ |
| AIME Cachet strictement intact | ✅ |

---

## 6. Rollback

**Niveau 1 — désactivation UI immédiate :**
Retirer dans `EventStudio.jsx` la ligne `<SurfaceSelector ... />` et son import. Aucune autre action requise. Les valeurs `surfaceMode` déjà enregistrées restent valides en base.

**Niveau 2 — suppression complète :**
1. Retrait du `<SurfaceSelector />` et de son import dans `EventStudio.jsx`.
2. `delete_file components/event/studio/SurfaceSelector.jsx`.

Aucune migration de données nécessaire. Aucun risque de perte. `surfaceMode` reste un champ valide du schéma `EventRecord`.

---

## 7. Prochaine micro-action recommandée

**Aucune action immédiate.** Le sélecteur v0 couvre le besoin doctrinal validé.

Avant toute évolution (ajout d'une 3ᵉ surface activable, déplacement du sélecteur, ouverture aux surfaces `planned`), il faudra :

1. Freezer la surface candidate (composant + rendu vérifié + doctrine du type).
2. Mettre à jour la matrice du document `aime-event-surface-doctrine-pre-ui.md`.
3. Créer un nouveau freeze documentaire dédié.

**Aucune modification du registre `lib/event-core/surfaces/index.js`, du schéma `EventRecord`, ou des renderers n'est autorisée sans freeze préalable.**

---

**Fin du freeze.**