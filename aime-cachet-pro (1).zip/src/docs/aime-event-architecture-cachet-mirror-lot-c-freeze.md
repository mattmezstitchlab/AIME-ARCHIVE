# AIME Event — Architecture miroir Cachet · Lot C (freeze)

**Statut** : 🟢 Implémenté et figé.
**Date** : 2026-05-24
**Référence** : Lot A (cadrage) + Lot B (composants partagés).
**Phase de projet** : 2A maintenue.

---

## 1. Objet

Mise en place de la **couche 3 (Event)** définie au Lot A :
- Page cockpit `/events` (`EventsCockpit`)
- 5 adaptateurs métier dans `components/event/cockpit/`
- Conservation de l'ancien sélecteur via l'alias `/events/types`

---

## 2. Fichiers livrés

| Fichier | Rôle | Lignes |
|---|---|---|
| `pages/EventsCockpit.jsx` | Page cockpit + timeline événements (route `/events`) | ~85 |
| `components/event/cockpit/EventHero.jsx` | Compteur global d'événements (utilise `CockpitHero`) | ~35 |
| `components/event/cockpit/EventMilestones.jsx` | Jalons doctrinaux du dernier événement (utilise `CockpitMilestones`) | ~60 |
| `components/event/cockpit/EventSuggestions.jsx` | 3 raccourcis internes (utilise `CockpitSuggestions`) | ~35 |
| `components/event/cockpit/EventTimeline.jsx` | Timeline chronologique groupée par mois (utilise `TimelineGroup`) | ~55 |
| `components/event/cockpit/EventTimelineCard.jsx` | Carte d'événement (utilise `TimelineCard`) | ~50 |

---

## 3. Modifications de l'existant

### `App.jsx` — 2 opérations (1 anchor_replace)

1. **Import** : ajout de `EventsCockpit` à côté de `Events`.
2. **Routes** :
   - `/events` → `<EventsCockpit />` (était `<Events />`)
   - `/events/types` → `<Events />` (**alias rétro-compatible**)
   - `/events/:type` et `/events/fiche/:id` **inchangés**.

Toutes les routes Event restent **hors `SideRail` et `MobileMenu`** — accès par URL uniquement.

---

## 4. Garde-fous respectés

### 4.1 Séparation Cachet ↔ Event (Lot A §4.1)

🔒 Aucun fichier Lot C n'importe depuis `components/aime/*`.
🔒 Aucun fichier Lot C ne touche à `Prestation` ou `HistoryEvent`.
🔒 Aucune entité Cachet n'est lue par Event.

### 4.2 Couche partagée intacte (Lot A §3 — couche 1)

🔒 `components/shared/cockpit/*` reste **vierge de tout import métier**.
🔒 La conversion EventRecord → props se fait **uniquement** dans les adaptateurs `components/event/cockpit/*`.

### 4.3 Phase 2A maintenue (Lot A §4.2)

🔒 `/events*` reste **hors `SideRail` et `MobileMenu`**.
🔒 `visibility` reste strictement `private_draft`.
🔒 Aucun PDF officiel, aucun envoi externe, aucun scellement, aucun hash, aucun QR vérifiable.
🔒 La doctrine `EVENT_DOCTRINE_LABELS` (préparatoire · revue humaine · non officiel) est affichée
   en bas du cockpit.

### 4.4 Assistant Event repoussé au Lot E

🔒 Aucun assistant n'est intégré au cockpit à ce stade — décision Lot A §7 Q4 respectée.

---

## 5. Structure de la page cockpit

```
┌─────────────────────────────────────────────────────────┐
│ Header (titre + retour Cachet + bouton Nouvel événement) │
├──────────────────────┬──────────────────────────────────┤
│  Cockpit (gauche)    │  Timeline (droite)               │
│  ────────────────    │  ────────────────                │
│  • EventHero         │  • EventDraftBanner              │
│    (compteur global) │  • EventTimeline                 │
│  • EventMilestones   │    └ TimelineGroup (mois)        │
│    (dernier event)   │      └ EventTimelineCard         │
│  • EventSuggestions  │                                  │
│  • DoctrineFooter    │                                  │
└──────────────────────┴──────────────────────────────────┘
```

Layout responsive (via `CockpitTimelineLayout`) :
- **Mobile (<lg)** : cockpit empilé au-dessus de la timeline.
- **Desktop (≥lg)** : 5/12 cockpit + 7/12 timeline côte-à-côte.

---

## 6. Routes finales

| Route | Composant | Statut |
|---|---|---|
| `/events` | `EventsCockpit` | 🆕 Cockpit principal |
| `/events/types` | `Events` (ancien sélecteur) | 🆕 Alias rétro-compatible |
| `/events/:type` | `EventsType` | Inchangé |
| `/events/fiche/:id` | `EventFicheView` | Inchangé |

---

## 7. Tests visuels suggérés (manuels)

1. Visiter `/events` sans aucun EventRecord en base → état vide affiché, bouton « + Nouvel événement » visible.
2. Créer un événement via le bouton du cockpit → redirection vers `/events/fiche/:id`.
3. Revenir sur `/events` → l'événement apparaît dans la timeline du mois courant, les jalons se mettent à jour.
4. Visiter `/events/types` → ancien sélecteur affiché à l'identique (rétro-compatibilité).
5. Vérifier mobile : cockpit empilé, timeline en bas.
6. Vérifier que `/events` **n'apparaît pas** dans le `SideRail` ni le `MobileMenu`.

---

## 8. Rollback

1. Supprimer les 6 fichiers `pages/EventsCockpit.jsx` + `components/event/cockpit/*`.
2. Dans `App.jsx` :
   - Retirer l'import `EventsCockpit`.
   - Restaurer `/events` → `<Events />`.
   - Supprimer la route `/events/types`.
3. Supprimer le présent freeze.

Aucun autre fichier impacté.

---

## 9. Points ouverts pour le Lot D

- Création de l'entité `EventHistoryEvent` (schéma parallèle à `HistoryEvent`).
- Hooks de log dans les flux Event (création, mise à jour, changement de statut, changement de surface).
- Aucun affichage de log à ce stade — pure couche de persistance préparatoire.

**Lot D démarre sur validation explicite de ce freeze.**

---

**Fin du Lot C.**