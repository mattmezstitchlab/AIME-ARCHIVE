# AIME Event — Freeze : Studio Mariage enrichi (micro-action #1)

**Date du freeze :** 23 mai 2026
**Phase :** AIME Event — Phase 2A.2 (micro-action verticale Mariage)
**Statut :** ✅ Gelé et validé après vérification visuelle
**Périmètre :** Strictement le type d'événement `mariage` — aucun impact sur les 9 autres types ni sur AIME Cachet

---

## 1. Objectif

Rendre le type `mariage` immédiatement plus parlant et utile dans le Studio événementiel, sans créer de nouvelle verticale complète, sans introduire de logique métier sensible, et sans toucher à AIME Cachet.

Cette micro-action constitue la première spécialisation visible d'un type d'événement au sein d'AIME Event, et sert de **pattern de référence** pour de futures spécialisations légères des autres types (festival, conférence, séminaire…) si elles sont un jour demandées.

---

## 2. Fichiers modifiés (3 — strictement)

| Fichier | Type de modification |
|---|---|
| `entities/EventRecord.json` | Ajout de 5 propriétés optionnelles `wedding_*` |
| `components/event/EventStudio.jsx` | Ajout d'une section conditionnelle "Détails mariage" |
| `components/event/EventFichePaper.jsx` | Ajout d'un bloc conditionnel en fin de fiche |

**Aucun autre fichier n'a été touché.**

---

## 3. Champs ajoutés

Tous les champs ont été ajoutés à l'entité `EventRecord` avec les contraintes suivantes :

| Champ | Type | Enum | Statut |
|---|---|---|---|
| `wedding_partners` | `string` | — | Optionnel · privé · préparatoire · non hashé |
| `wedding_date_civil` | `string` (format `date`) | — | Optionnel · privé · préparatoire · non hashé |
| `wedding_guest_count_estimate` | `number` | — | Optionnel · indicatif |
| `wedding_ceremony_type` | `string` | `civile` · `religieuse` · `laique` · `mixte` · `autre` | Optionnel · privé · préparatoire |
| `wedding_budget_estimate` | `number` | — | Optionnel · en € · non opposable |

**Garanties schéma :**
- Le tableau `required` reste exactement `["eventType", "title"]` — aucun nouveau champ requis.
- Aucun champ `wedding_*` n'est référencé par `lib/verificationHash.js` ni par aucun hash.
- Aucun champ `wedding_*` n'est exposé par un endpoint public.

---

## 4. Comportement conditionnel mariage

### 4.1 Dans `EventStudio.jsx`

La section "Détails mariage" est strictement guardée par :

```jsx
{event.eventType === "mariage" && (
  <Section title="Détails mariage">
    ...
  </Section>
)}
```

**Contenu de la section :**

- Bandeau pédagogique rose : *« Informations préparatoires — à confirmer humainement. Strictement privées, non opposables. »*
- 5 champs éditables avec la même logique de sauvegarde debounced que les autres sections du Studio (aucune nouvelle logique de persistance introduite).
- Le champ `wedding_ceremony_type` est rendu via un `<select>` avec une option vide + les 5 valeurs enum.

### 4.2 Dans `EventFichePaper.jsx`

Le bloc "Détails mariage" est doublement guardé :

```jsx
{event.eventType === "mariage" &&
  (event.wedding_partners ||
    event.wedding_date_civil ||
    event.wedding_guest_count_estimate ||
    event.wedding_ceremony_type ||
    event.wedding_budget_estimate) && (
    <div>...</div>
  )}
```

**Caractéristiques :**

- Affiché **uniquement** si type=mariage **ET** au moins un champ `wedding_*` est renseigné.
- Wording prudent obligatoire : *« Informations préparatoires — à confirmer humainement. »*
- Chaque ligne `<Row>` n'apparaît que si le champ correspondant est rempli → fiche jamais surchargée.
- Couleur d'accent mariage (`#ec4899`) appliquée uniquement au titre de section.

---

## 5. Preuve que les autres types ne sont pas impactés

| Vérification | Statut |
|---|---|
| Section "Détails mariage" guardée par `event.eventType === "mariage"` dans Studio | ✅ Invisible pour : spectacle, concert, festival, conférence, exposition, atelier, soirée privée, associatif, séminaire |
| Bloc "Détails mariage" guardé par la même condition dans la fiche | ✅ Aucun rendu pour les 9 autres types |
| Tous les champs `wedding_*` sont optionnels | ✅ Aucun impact sur les EventRecord existants |
| Sections génériques inchangées (Informations, Description, Programme, Prestataires, Documents) | ✅ Rendu strictement identique pour tous les types |
| Helpers `Row`, `PlaceholderBlock`, `Field`, `Section` non modifiés | ✅ Aucun changement de signature ou de comportement |
| `EventDraftBanner`, `EventFicheVerso`, `EventTypeRecommendedDocs` | ✅ Aucune modification |
| `pages/Events.jsx`, `pages/EventsType.jsx`, `pages/EventFicheView.jsx` | ✅ Aucune modification |
| `EVENT_TYPES.mariage` dans `lib/event-core/verticals/event.js` | ✅ Aucune modification — la spécialisation est purement UI, pas dans la config event-core |

---

## 6. Preuve qu'AIME Cachet reste intact

| Élément | Vérification |
|---|---|
| `entities/Prestation.json` | ✅ Non touché |
| `entities/HistoryEvent.json` | ✅ Non touché |
| `entities/Wallet.json` | ✅ Non touché |
| `entities/AssistantReminder.json` | ✅ Non touché |
| `lib/verificationHash.js` (et `HASHED_FIELDS`) | ✅ Non touché — les 8 champs publics restent inchangés |
| `functions/sealCachet` | ✅ Non touché |
| `functions/verifyCachet` | ✅ Non touché |
| `pages/FicheView.jsx` | ✅ Non touché |
| `pages/MesPrestations.jsx` | ✅ Non touché |
| `pages/Dashboard507.jsx` | ✅ Non touché |
| `pages/Verify.jsx` | ✅ Non touché |
| `pages/AimeCachet.jsx` | ✅ Non touché |
| Tous les templates `*Paper.jsx` AIME Cachet (FichePaper, FicheVerso, RecuPaper, CessionPaper, FraisPaper, PresencePaper, DevisPaper, NoteHonorairesPaper, AvenantPaper, CddUPaper, CessionDroitsPaper, GusoPaper, AemPaper, AttPePaper, DpaePaper) | ✅ Aucun modifié — aucune importation, aucune référence aux champs `wedding_*` |
| Routes `/app`, `/prestations`, `/507`, `/fiche/:id`, `/verify/:cachetCode` | ✅ Non touchées |
| `components/aime/SideRail.jsx`, `SealButton`, `SectionCertification`, `StampGraphic` | ✅ Non touchés |
| Aucune nouvelle backend function créée | ✅ Toujours uniquement `sealCachet` et `verifyCachet` |
| Aucun PDF, hash événementiel, scellement, endpoint public, page publique introduits | ✅ Confirmé |
| Aucun module invités, RSVP, co-organisation introduits | ✅ Confirmé |

---

## 7. Limites de cette micro-action

Cette micro-action est volontairement minimale. Ce qu'elle **ne fait pas** :

- ❌ Aucune validation de format (les dates, nombres, budgets ne sont pas validés au-delà du type natif HTML).
- ❌ Aucun calcul dérivé (pas de "coût par invité", pas de moyenne, pas de jauge).
- ❌ Aucune suggestion IA spécifique mariage.
- ❌ Aucun template de fiche mariage préchargé.
- ❌ Aucun document mariage spécifique (faire-part, planning du jour J, liste d'invités, checklist).
- ❌ Aucune timeline préparatoire J-12 mois → J.
- ❌ Aucune gestion d'invités ou RSVP.
- ❌ Aucune co-organisation entre deux comptes.
- ❌ Aucun partage privé sécurisé.
- ❌ Aucune personnalisation visuelle du hub `/events/mariage`.

Ces fonctionnalités sont **listées dans l'audit du 23 mai 2026** comme modules futurs envisageables, mais **ne sont pas engagées** par cette micro-action.

---

## 8. Rollback

### Option A — Rollback complet (< 1 minute)

1. **`entities/EventRecord.json`** : restaurer les 13 champs originaux (retirer `wedding_partners`, `wedding_date_civil`, `wedding_guest_count_estimate`, `wedding_ceremony_type`, `wedding_budget_estimate`).
2. **`components/event/EventStudio.jsx`** : retirer le bloc `{event.eventType === "mariage" && (<Section title="Détails mariage">...</Section>)}`.
3. **`components/event/EventFichePaper.jsx`** : retirer le bloc conditionnel mariage placé après la section "Notes internes".

### Option B — Rollback partiel

- Les 5 champs schéma peuvent rester (ils sont optionnels et sans impact métier) ; seul l'affichage UI peut être retiré.
- Le Studio et la Fiche peuvent être rollback indépendamment.

### Garantie

**Aucun rollback ne peut affecter AIME Cachet** — par construction, aucun fichier AIME Cachet n'a été touché.

Les EventRecord déjà créés avec des champs `wedding_*` renseignés conserveront leurs données en base ; si le schéma est restauré, ces champs deviennent silencieusement ignorés par l'UI mais persistent côté base (sans casser le rendu).

---

## 9. Prochaine étape recommandée

Aucune action n'est engagée. Toute évolution ultérieure devra faire l'objet d'une validation explicite et d'un audit complémentaire.

Si une suite est envisagée, l'ordre stratégique recommandé issu de l'audit du 23 mai 2026 reste :

1. **Checklist préparatoire mariage** — composant lecture seule avec items préchargés cochables, persistés dans `EventRecord.documents` (déjà disponible dans le schéma). Aucun nouveau champ. Effort faible, risque doctrinal nul.
2. **Templates de fiche mariage** — 3 modèles à choisir lors de la création (intime / classique / festif). Préremplit `description`, `programme`, et les champs `wedding_*`. Effort moyen, risque doctrinal nul.
3. **Identité visuelle mariage du hub `/events/mariage`** — typographie chaleureuse, imagerie pertinente, vocabulaire dédié. Effort faible, risque doctrinal nul.

**Modules à NE PAS engager sans CanvasCore dédié :**

- Gestion d'invités structurée (RGPD — données personnelles de tiers).
- RSVP indicatif.
- Co-organisation à deux comptes (refonte permissions).
- Partage privé en lecture avec témoins / wedding planner.

---

## 10. Verrous doctrinaux confirmés à ce freeze

| Verrou | Statut |
|---|---|
| `visibility` reste `private_draft` uniquement | ✅ |
| Aucun endpoint public exposé | ✅ |
| Aucun hash technique sur les champs `wedding_*` | ✅ |
| Aucune route publique créée | ✅ |
| Aucun PDF produit | ✅ |
| Aucun scellement opéré | ✅ |
| Vocabulaire doctrinal respecté : *brouillon · préparatoire · non opposable · à valider humainement* | ✅ |
| Watermark `BROUILLON` toujours présent sur la fiche | ✅ |
| Footer doctrinal toujours présent sur la fiche | ✅ |
| AIME Cachet strictement isolé | ✅ |

---

**Fin du freeze.**
Toute modification ultérieure de ces 3 fichiers ou de la doctrine ci-dessus nécessite un nouveau freeze daté.