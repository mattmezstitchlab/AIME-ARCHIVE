# AIME Event — Source Propagation UI v0 — Doctrine

**Date :** 2026-05-23
**Statut :** **Doctrine UI figée — non exécutable.**
**Périmètre :** AIME Event uniquement — AIME Cachet strictement intact.
**Nature :** Markdown déclaratif. Aucun code, aucune UI, aucune entité, aucune route, aucun moteur runtime.

**Rattachement :**
- `docs/aime-event-source-propagation-doctrine.md` (cadrage SPE)
- `docs/aime-event-source-propagation-rules-v0-draft.md` (règles v0 réduites)
- `docs/aime-event-source-propagation-rules-v0-freeze.md` (freeze SPE v0)
- `docs/aime-event-surface-doctrine-pre-ui.md` §0bis
- `docs/aime-event-surface-wording-source-freeze.md`
- `docs/aime-event-surface-selector-v0-freeze.md`

---

## Exergue — Formule doctrinale

> **Une source.**
> **Plusieurs projections.**
> **Zéro répétition.**
> **Studio intégré.**
> **Validation humaine.**

---

## 1. Principe central — Mémo vivant universel

Le Source Propagation Engine (SPE) est un **mémo vivant universel** :

1. Une information est **saisie une seule fois**.
2. Elle est **comprise** sémantiquement.
3. Elle est **rangée** dans les wallets et sections concernés.
4. Elle **nourrit** les supports qui en ont besoin.
5. **Cerise propose** des projections préparatoires.
6. **L'humain valide** chaque projection individuellement.

> Le SPE n'est pas un système d'automatisation. C'est un système de **non-répétition + validation**.

---

## 2. Les 6 missions du moteur

| # | Mission | Lecture mémo vivant |
|---|---|---|
| 1 | Comprendre ce que l'information signifie | Sémantique de la source |
| 2 | Savoir où elle doit être rangée | Wallets, sections |
| 3 | Identifier les supports concernés | Surfaces, documents préparatoires |
| 4 | Détecter ce qui manque encore | Items « À compléter » |
| 5 | Préparer des propositions | Cerise propose, ≤ 8 |
| 6 | Préserver la validation humaine | L'humain valide chaque projection |

Ces 6 missions sont **les 6 piliers** du SPE doctrinal. Toute fonctionnalité future doit s'y rattacher explicitement.

---

## 3. Emplacement UI retenu

**Section repliable dans `EventStudio`** intitulée :

> **« Ce que cette information déclenche »**

### 3.1 Règles d'apparition

| Règle | Valeur |
|---|---|
| État par défaut | **Fermée** |
| Visibilité | Uniquement s'il existe **au moins 1 proposition active** |
| Position | Sous les champs principaux, **séparée** de la section « Surface du canvas » |
| Ouverture automatique | **Interdite** |
| Badge rouge | **Interdit** |
| Notification | **Interdite** |
| Animation anxiogène | **Interdite** |
| Compteur | Discret, neutre (« 3 propositions »), **jamais coloré en rouge** |

### 3.2 Justification doctrinale

- `EventStudio` est le lieu d'édition contextuel — la section y est cohérente.
- La séparation visuelle avec « Surface du canvas » préserve la distinction §0bis : **surface = point de vue**, **propagation = effet sur les supports**.
- La section reste séparée des wallets pour préserver la distinction **wallet = rangement passif**, **proposition = suggestion active**.

---

## 4. Lecture doctrinale de l'UI

La section « Ce que cette information déclenche » est le **tableau de bord du mémo vivant**. Elle doit montrer **quatre colonnes conceptuelles** :

| Colonne conceptuelle | Contenu |
|---|---|
| **Ce qui existe déjà** | Champs sources déjà renseignés sur l'`EventRecord` |
| **Ce que cette information nourrit** | Supports actifs concernés (v0 : Fiche préparatoire A4 + Faire-part) |
| **Ce qui manque** | Sources non renseignées → items « À compléter » |
| **Ce que Cerise propose de préparer** | Propositions actives, ≤ 8, calmes, repliables |

Cette lecture n'est pas une exigence visuelle stricte de colonnes — c'est une **grille de lecture doctrinale** à laquelle la maquette finale devra se rattacher explicitement.

---

## 5. Wording obligatoire

### 5.1 Phrases obligatoires (à inclure systématiquement)

| Emplacement | Texte exact |
|---|---|
| Sous-titre de la section | « Cerise propose, vous validez. » |
| Pied de section | « Ces propositions restent privées, préparatoires et non opposables. » |
| Pied de section (suite) | « Aucune action externe n'est déclenchée. » |
| Pied de section (suite) | « Aucune publication, aucun envoi, aucune signature. » |
| Pied de section (doctrine mémo vivant) | « Une saisie, plusieurs supports. Vous validez chaque projection. » |

### 5.2 Wording « Voir pourquoi »

Texte exact à utiliser dans le popover explicatif :

> « Cette information a été saisie une fois. Cerise peut la projeter dans les supports concernés sans nouvelle saisie. Vous gardez la main sur chaque projection. »

### 5.3 Wording par carte (v0)

| Source | Titre | Phrase |
|---|---|---|
| `S-TITLE` | « Titre renseigné » | « Ce titre peut alimenter la fiche préparatoire A4 et le faire-part. » |
| `S-DATE` | « Date ajoutée » | « Cette date peut alimenter la fiche préparatoire A4 et le faire-part. » |
| `S-LOCATION` | « Lieu renseigné » | « Ce lieu peut alimenter la fiche préparatoire A4 et le faire-part. » |
| `S-WED-PARTNERS` | « Partenaires renseignés » | « Ces noms peuvent apparaître sur la fiche préparatoire A4 et le faire-part. » |
| `S-WED-DATE-CIVIL` | « Date civile renseignée » | « Cette date civile peut apparaître sur la fiche préparatoire A4 et le faire-part. » |
| *(croisé)* | « Cohérence à vérifier » | « Cerise peut vous rappeler de vérifier la cohérence entre la fiche préparatoire et le faire-part. » |

### 5.4 Wording strictement interdit

❌ « automatique » · « automatiquement »
❌ « officiel » · « officiellement »
❌ « envoyer » · « envoi » · « envoyé »
❌ « publier » · « publication » · « publié »
❌ « facturer » · « facture » · « facturation »
❌ « signer » · « signature » · « signé »
❌ « certifier » · « certification » · « certifié »
❌ « tout appliquer » · « valider automatiquement »
❌ « générer » · « générer un PDF »
❌ « partager » · « partage »
❌ « sceller » · « scellement »
❌ « notifier » · « notification »
❌ « urgent » · « important » · « attention »
❌ « recommandé » · « obligatoire » · « requis »
❌ « IA » · « intelligence artificielle »

---

## 6. Boutons autorisés

### 6.1 4 boutons exclusifs

| Bouton | Effet | Externe ? | Réversible |
|---|---|---|---|
| **Noter** | Applique la proposition **interne uniquement** : préremplit un champ de surface, retire un item de « À compléter », ou ajoute un item de checklist | ❌ Jamais | ✅ |
| **Voir pourquoi** | Ouvre un popover explicatif | ❌ Jamais | N/A |
| **Plus tard** | Masque la carte mais conserve la proposition | ❌ Jamais | ✅ |
| **Ignorer** | Masque jusqu'à modification ultérieure de la source | ❌ Jamais | ✅ |

### 6.2 Comportement strict de « Noter »

- N'envoie rien (mail, SMS, webhook).
- Ne publie rien.
- Ne signe rien.
- Ne génère aucun PDF.
- N'applique aucun hash.
- N'écrit pas sur AIME Cachet.
- Modifie **uniquement** : le champ correspondant de l'`EventRecord` (préremplissage) **ou** l'état interne d'un item calculé à la volée.

---

## 7. Boutons strictement interdits

❌ Envoyer
❌ Publier
❌ Signer
❌ Générer PDF
❌ Tout appliquer
❌ Tout valider
❌ Facturer
❌ Partager
❌ Sceller
❌ Notifier
❌ Exporter
❌ Certifier

**Aucun bouton de masse n'est autorisé en v0.** Pas de « Tout préparer », pas de « Tout accepter ». Chaque proposition se valide individuellement.

---

## 8. Types de propositions v0

**4 types uniquement.**

| Code | Type | Effet interne |
|---|---|---|
| `P-SURF-DOC` | Mise à jour de la **Fiche préparatoire A4** | Préremplit un champ sur la surface `document` |
| `P-SURF-FP` | Mise à jour du **Faire-part** | Préremplit un champ sur la surface `faire_part` |
| `P-TODO-RM` | **Retrait ou résolution** d'un item « À compléter » | Marque l'item comme résolu (calcul à la volée) |
| `P-CHECK` | Item de **checklist simple** | Ajoute un item « confirmer X » |

**Aucun autre type de proposition n'est autorisé en v0.**

---

## 9. Statuts doctrinaux

### 9.1 5 statuts conceptuels

| Statut | Sens |
|---|---|
| `proposée` | Visible dans la section, en attente d'action humaine |
| `notée` | L'humain a cliqué « Noter ». Effet interne appliqué |
| `ignorée` | L'humain a cliqué « Ignorer ». Masquée |
| `plus tard` | L'humain a cliqué « Plus tard ». Masquée jusqu'au prochain dépliement |
| `obsolète` | La source a changé après une décision. Recalculée |

### 9.2 Rappel — aucune entité en v0

> **Aucune entité `PropagationProposal` n'est créée en v0.**

Les statuts sont :
- soit **calculés à la volée** depuis l'état de l'`EventRecord` (cas `proposée`, `notée`, `obsolète`) ;
- soit **mémorisés en session UI** uniquement (cas `ignorée`, `plus tard`).

Si l'utilisateur recharge la page, les propositions `ignorée` / `plus tard` réapparaissent en `proposée`. **C'est acceptable en v0.**

---

## 10. Données et persistance — doctrine v0

| Élément | Statut v0 |
|---|---|
| Propositions calculées à la volée | ✅ Oui |
| Entité créée | ❌ Aucune |
| Table de stockage | ❌ Aucune |
| Endpoint backend | ❌ Aucun |
| Stockage persistant | ❌ Aucun |
| Nouveau champ `EventRecord` | ❌ Aucun |

**La v0 ne crée aucune donnée nouvelle.** Elle ne fait que **lire** `EventRecord`.

Signature doctrinale (non implémentée) :

```
detectProposals(eventRecord) → Proposition[]
```

- Fonction **pure**.
- **Aucun side effect.**
- **Aucun cache.**
- Recalcul à chaque rendu (volume négligeable).

---

## 11. Wallet « À compléter » — doctrine v0

| Caractéristique | Décision v0 |
|---|---|
| Section calculée | ✅ Oui |
| Persistance | ❌ Aucune |
| Vrai wallet runtime | ❌ Non — pas en v0 |
| Entité `Wallet` créée pour `W-TODO` | ❌ Non |

**Comportement :**
- Items dérivés **à la volée** depuis l'`EventRecord`.
- Pour chaque source v0 non renseignée → un item « Renseigner X ».
- Affichés à l'intérieur (ou à proximité directe) de la section « Ce que cette information déclenche ».

**En v1+**, possibilité de remonter le concept dans un vrai wallet persistant — **pas avant**, et **uniquement** sous freeze dédié.

---

## 12. Limitation du bruit

| Règle UX | Valeur |
|---|---|
| Plafond visible | **≤ 8 propositions** |
| Regroupement | Par source |
| Couleur d'alerte | ❌ Aucune |
| Notification système | ❌ Aucune |
| Son | ❌ Aucun |
| Vibration mobile | ❌ Aucune |
| Modal automatique | ❌ Aucun |
| Toast d'annonce | ❌ Aucun |
| Animation d'attention | ❌ Aucune (pas de pulse, pas de glow) |
| Sentiment d'urgence | ❌ Aucun |

**Ton général : calme préparatoire.**

Mots d'ordre : **discret**, **pédagogique**, **repliable**, **non intrusif**, **jamais anxiogène**, **jamais culpabilisant**.

### 12.1 Stratégie si > 8 propositions

Ordre de priorité :
1. Propositions liées à la **dernière source modifiée**.
2. Propositions de type `P-SURF-DOC` et `P-SURF-FP`.
3. Propositions de type `P-CHECK`.
4. Propositions de type `P-TODO-RM`.

Au-delà de 8 : **différées silencieusement** jusqu'à la prochaine session ou modification.

---

## 13. Exemple UX mariage

### 13.1 Situation

L'utilisateur renseigne dans `EventStudio` (type `mariage`) :

- `title = "Notre mariage"`
- `date = "2027-06-15"`
- `location = "Domaine de la Lys"`
- `wedding_partners = "Alice & Benoît"`
- `wedding_date_civil = "2027-06-14"`

### 13.2 Cartes proposées (6 maximum, plafond 8 respecté)

| # | Carte | Source | Boutons |
|---|---|---|---|
| 1 | « Titre renseigné » | `S-TITLE` | Noter · Voir pourquoi · Plus tard · Ignorer |
| 2 | « Date ajoutée » | `S-DATE` | Noter · Voir pourquoi · Plus tard · Ignorer |
| 3 | « Lieu renseigné » | `S-LOCATION` | Noter · Voir pourquoi · Plus tard · Ignorer |
| 4 | « Partenaires renseignés » | `S-WED-PARTNERS` | Noter · Voir pourquoi · Plus tard · Ignorer |
| 5 | « Date civile renseignée » | `S-WED-DATE-CIVIL` | Noter · Voir pourquoi · Plus tard · Ignorer |
| 6 | « Cohérence à vérifier » | *(croisé)* | Noter · Voir pourquoi · Plus tard · Ignorer |

### 13.3 Maquette doctrinale (description textuelle)

```
┌──────────────────────────────────────────────────────────────┐
│ Ce que cette information déclenche             (6 groupes) ▾ │
│ Cerise propose, vous validez.                                 │
├──────────────────────────────────────────────────────────────┤
│                                                                │
│  ▸ Date ajoutée                                                │
│    Cette date peut alimenter la fiche préparatoire A4 et le    │
│    faire-part.                                                 │
│    [ Noter ]     [ Voir pourquoi ]  [ Plus tard ]  [ Ignorer ] │
│                                                                │
│  ▸ Lieu renseigné                                              │
│    Ce lieu peut alimenter la fiche préparatoire A4 et le       │
│    faire-part.                                                 │
│    [ Noter ]     [ Voir pourquoi ]  [ Plus tard ]  [ Ignorer ] │
│                                                                │
│  …                                                             │
│                                                                │
├──────────────────────────────────────────────────────────────┤
│ Ces propositions restent privées, préparatoires et non         │
│ opposables. Aucune action externe n'est déclenchée. Aucune     │
│ publication, aucun envoi, aucune signature.                    │
│ Une saisie, plusieurs supports. Vous validez chaque projection.│
└──────────────────────────────────────────────────────────────┘
```

### 13.4 Popover « Voir pourquoi » — texte type

```
┌──────────────────────────────────────────────┐
│ Pourquoi cette proposition ?                  │
├──────────────────────────────────────────────┤
│ Cette information a été saisie une fois.      │
│ Cerise peut la projeter dans les supports     │
│ concernés sans nouvelle saisie. Vous gardez   │
│ la main sur chaque projection.                │
│                                                │
│ Source : Date principale (15 juin 2027)       │
│                                                │
│ Cibles préparatoires :                         │
│  · Fiche préparatoire A4 — champ « Date »      │
│  · Faire-part — champ « Date »                 │
│                                                │
│ Tout reste privé, préparatoire et non          │
│ opposable. Aucune action externe.              │
└──────────────────────────────────────────────┘
```

---

## 14. Risques et mitigations

| # | Risque | Gravité | Mitigation |
|---|---|---|---|
| R-UI-1 | Sur-automatisation perçue | Moyenne | Wording « propose » ; pas de « Tout préparer » ; validation individuelle |
| R-UI-2 | Bruit excessif | Faible | Plafond 8 ; regroupement par source ; section repliée |
| R-UI-3 | Confusion brouillon / officiel | Moyenne | Pied de section répété ; `DraftWatermark` + `DoctrineFooter` conservés |
| R-UI-4 | Fausse promesse IA | Moyenne | Aucune mention « IA » ; ton calme ; pas d'animation |
| R-UI-5 | Croire que le faire-part est envoyé | **Élevée** | Wording strict ; aucun bouton « Envoyer » ; popover explicatif |
| R-UI-6 | Complexification de `EventStudio` | Moyenne | Section repliée par défaut ; aucune autre modification |
| R-UI-7 | Contamination AIME Cachet | **Critique** | Zéro modification de Cachet — UI strictement AIME Event |
| R-UI-8 | Persistance accidentelle | Moyenne | v0 sans entité ; calcul à la volée |

### 14.1 Tentations doctrinales (mémo vivant)

| # | Tentation | Garde-fou |
|---|---|---|
| T-1 | « Puisqu'on évite la répétition, autant tout pousser partout » | Plafonds 3/source, 8/event ; pas de « Tout noter » |
| T-2 | « Puisque la source est unique, autant publier la projection » | §15 G-3, G-5 |
| T-3 | « Puisque c'est un mémo vivant, autant tout persister » | §10 v0 sans entité |
| T-4 | « Puisque c'est universel, autant l'étendre à AIME Cachet » | §15 G-7 |
| T-5 | « Puisque c'est un tableau de bord, autant le rendre proactif » | §12 calme préparatoire |
| T-6 | « Puisque ça nourrit plusieurs supports, autant générer les PDF » | §15 G-5 |

---

## 15. Garde-fous non négociables

| # | Invariant |
|---|---|
| G-1 | Toute dérivée reste `private_draft`. |
| G-2 | Aucune publication. |
| G-3 | Aucun envoi (mail, SMS, webhook, tiers). |
| G-4 | Aucune signature (électronique, manuscrite, cachet). |
| G-5 | Aucun PDF généré. |
| G-6 | Aucun hash appliqué. |
| G-7 | Aucun scellement, aucune écriture sur AIME Cachet. |
| G-8 | Aucun endpoint public ouvert. |
| G-9 | Aucune action externe. |
| G-10 | Aucune modification d'AIME Cachet. |
| G-11 | `surfaceMode` n'est jamais une source. |
| G-12 | `eventType` n'est jamais une source de propagation v0. |
| G-13 | Plafond strict : 3 propositions / source, 8 / `EventRecord`. |
| G-14 | Aucune propagation transitive. |
| G-15 | Aucune génération automatique de document. |
| G-16 | Aucune proposition comptable. |
| G-17 | Aucune proposition officielle. |
| G-18 | Aucun bouton de masse. |
| G-19 | Cerise propose, l'humain valide — toujours. |

### 15.1 Règle absolue

> **AIME prépare en cascade, mais ne publie jamais automatiquement.**
> **AIME ne signe pas. AIME n'envoie pas. AIME ne facture pas. AIME ne scelle pas.**
> **AIME ne rend rien officiel sans validation humaine.**

---

## 16. Rollback

Le document est **strictement non destructif**.

### 16.1 Commande de rollback

```
delete_file docs/aime-event-source-propagation-ui-v0-doctrine.md
```

### 16.2 État après rollback

- Aucun comportement applicatif modifié.
- Aucune migration.
- Aucun nettoyage.
- `EventStudio` inchangé.
- `EventFicheView` inchangé.
- `SurfaceSelector` inchangé.
- AIME Cachet intact.
- Le freeze SPE v0 reste en place.

---

## 17. Prochaine étape recommandée — **non exécutée**

La prochaine étape **possible** (mais **non engagée** par ce document) consiste à :

### Audit de cohérence transverse

Effectuer un audit de cohérence entre :

1. `docs/aime-event-source-propagation-rules-v0-freeze.md` (SPE v0 figé).
2. `docs/aime-event-source-propagation-ui-v0-doctrine.md` (présent document).
3. `docs/aime-event-surface-selector-v0-freeze.md` (Surface Selector).
4. `docs/aime-event-surface-faire-part-v0-freeze.md` (Faire-part).
5. `components/event/EventStudio.jsx` (lecture doctrinale uniquement, **aucune modification**).

**Objectifs de l'audit :**
- Vérifier l'absence de contradictions entre les freezes.
- Vérifier l'alignement du wording entre les documents.
- Vérifier que les garde-fous se renforcent mutuellement sans conflit.
- Identifier les zones de chevauchement non résolues.

**Cet audit serait livré sous forme de rapport Markdown documentaire.** Aucun code ne sera modifié.

> **Cette prochaine étape n'est pas engagée par le présent document.** Elle exige une validation explicite ultérieure.

---

## 18. Référence croisée

| Document | Rôle |
|---|---|
| `docs/aime-event-source-propagation-doctrine.md` | Cadrage SPE général |
| `docs/aime-event-source-propagation-rules-v0-draft.md` | Règles v0 réduites |
| `docs/aime-event-source-propagation-rules-v0-freeze.md` | Freeze SPE v0 |
| **`docs/aime-event-source-propagation-ui-v0-doctrine.md`** | **Présent document** |
| `docs/aime-event-surface-doctrine-pre-ui.md` | Doctrine pré-UI surfaces (§0bis) |
| `docs/aime-event-surface-wording-source-freeze.md` | Wording « Fiche préparatoire A4 » |
| `docs/aime-event-surface-selector-v0-freeze.md` | Surface Selector v0 |
| `docs/aime-event-surface-faire-part-v0-freeze.md` | Faire-part v0 |
| `docs/aime-canvascore-doctrine.md` | CanvasCore |

---

**Fin de la doctrine UI v0.**