# AIME Event — Phase 2A · FREEZE de non-régression

**Date** : 23 mai 2026
**Statut** : 🟢 **FREEZE validé — Phase 2A figée**
**Doctrine** : AIME CanvasCore §7 (préparatoire, non opposable, à valider humainement)
**Type de document** : freeze documentaire — vérification de non-régression

---

## 1. Objectif

Figer l'état exact de la Phase 2A après vérification ligne-à-ligne, garantir qu'aucune régression n'affecte AIME Cachet, et établir le contrat d'interdictions pour les phases suivantes.

Ce document atteste que :
- AIME Event est livré comme verticale parallèle isolée ;
- AIME Cachet (intermittents) reste strictement intact ;
- Toute évolution future devra respecter les interdictions listées en §11.

---

## 2. Fichiers créés (13)

### 2.1 Entité (1)
| Fichier | Rôle |
|---|---|
| `entities/EventRecord.json` | Entité événementielle distincte de `Prestation`, `visibility` enum à 1 seule valeur (`private_draft`) |

### 2.2 Configuration déclarative (1)
| Fichier | Rôle |
|---|---|
| `lib/event-core/verticals/event.js` | 10 types d'événements + 4 statuts + 10 documents bibliothèque + libellés doctrinaux |

### 2.3 Pages (3)
| Fichier | Route |
|---|---|
| `pages/Events.jsx` | `/events` |
| `pages/EventsType.jsx` | `/events/:type` |
| `pages/EventFicheView.jsx` | `/events/fiche/:id` |

### 2.4 Composants (8 — tous dans `components/event/`)
| Fichier | Rôle |
|---|---|
| `EventDraftBanner.jsx` | Bandeau doctrinal permanent (compact ou complet) |
| `EventTypeCard.jsx` | Carte de type d'événement (registre) |
| `EventCard.jsx` | Carte d'événement dans une liste |
| `EventFilters.jsx` | Recherche + filtres type + statut |
| `EventCreateButton.jsx` | Bouton + modal de création |
| `EventFichePaper.jsx` | Recto de fiche générique adaptative |
| `EventFicheVerso.jsx` | Verso avec QR indicatif (jamais officiel) |
| `EventStudio.jsx` | Panneau latéral d'édition |

### 2.5 Documentation (1)
| Fichier | Rôle |
|---|---|
| `docs/aime-event-phase-2a.md` | Livrable initial Phase 2A |
| `docs/aime-event-phase-2a-freeze.md` | **Ce document** — freeze de non-régression |

**Total : 13 fichiers créés + 1 freeze (ce document) = 14 fichiers nouveaux.**

---

## 3. Fichier modifié (1)

### `App.jsx` — modifications exactes

#### 3.1 Imports ajoutés (3, lignes 19-21)
```js
import Events from '@/pages/Events';
import EventsType from '@/pages/EventsType';
import EventFicheView from '@/pages/EventFicheView';
```

#### 3.2 Routes ajoutées (3, lignes 68-71)
```jsx
{/* AIME Event — Phase 2A : routes accessibles par URL uniquement, hors SideRail */}
<Route path="/events" element={<Events />} />
<Route path="/events/:type" element={<EventsType />} />
<Route path="/events/fiche/:id" element={<EventFicheView />} />
```

#### 3.3 Vérification : aucune route existante retirée ou modifiée

✅ Liste complète des routes existantes (lignes 57-67 + 72) **inchangées** :

| Ligne | Route | Composant |
|---|---|---|
| 57 | `/` | `Landing` |
| 58 | `/app` | `AimeCachet` |
| 59 | `/prestations` | `MesPrestations` |
| 60 | `/507` | `Dashboard507` |
| 61 | `/fiche/:id` | `FicheView` |
| 62 | `/verify/:cachetCode` | `Verify` |
| 63 | `/recherche` | `Recherche` |
| 64 | `/notifications` | `Notifications` |
| 65 | `/profil` | `Profil` |
| 66 | `/aide` | `Aide` |
| 67 | `/parametres` | `Parametres` |
| 72 | `*` | `PageNotFound` (catch-all préservé) |

**Structure d'AuthenticatedApp / AuthProvider / Router : strictement préservée.**

---

## 4. Routes ajoutées — Vérification

| Route | Statut | Composant | Accessibilité |
|---|---|---|---|
| `/events` | ✅ Active | `pages/Events.jsx` | URL directe uniquement |
| `/events/:type` | ✅ Active | `pages/EventsType.jsx` | URL directe uniquement |
| `/events/fiche/:id` | ✅ Active | `pages/EventFicheView.jsx` | URL directe uniquement |

### Aucune entrée dans la navigation principale
- ❌ Pas dans `components/aime/SideRail.jsx`
- ❌ Pas dans `components/aime/GlobalToolbar.jsx`
- ❌ Pas dans `pages/AimeCachet.jsx`
- ❌ Pas dans `pages/Landing.jsx`
- ❌ Pas dans `components/aime/AimeHeader.jsx`

✅ Conformité totale à la décision Q2 = option 2.

---

## 5. Entité EventRecord — Vérification

Lecture brute de `entities/EventRecord.json` :

| Champ | Type | Contrainte |
|---|---|---|
| `eventType` | enum (10) | `spectacle`, `concert`, `festival`, `conference`, `mariage`, `exposition`, `atelier`, `soiree_privee`, `associatif`, `seminaire` — **requis** |
| `title` | string | **requis** |
| `date` | string (date) | optionnel |
| `location`, `organizer`, `audience` | string | optionnel |
| `description`, `programme`, `prestataires`, `internal_notes` | string | optionnel |
| `status` | enum (4) | `brouillon` / `en_preparation` / `pret_a_partager` / `archive` — défaut `brouillon` |
| **`visibility`** | **enum (1)** | **`private_draft` uniquement — défaut `private_draft`** |
| `public_code` | string | indicatif, n'ouvre aucun endpoint |
| `documents` | array | placeholders préparatoires |
| `studio_settings` | object | préférences Studio |

### Garantie technique
L'enum `visibility` ne contient qu'**une seule valeur** : `private_draft`. **Impossible de créer un EventRecord avec une autre visibilité sans modifier le schéma.**

---

## 6. Configuration des 10 types — Vérification

Source : `lib/event-core/verticals/event.js`

| Clé | Label | Icône lucide | Couleur |
|---|---|---|---|
| `spectacle` | Spectacle | `Sparkles` | `#a855f7` |
| `concert` | Concert | `Music` | `#ef4444` |
| `festival` | Festival | `Tent` | `#f59e0b` |
| `conference` | Conférence | `Mic` | `#0ea5e9` |
| `mariage` | Mariage | `Heart` | `#ec4899` |
| `exposition` | Exposition | `Image` | `#14b8a6` |
| `atelier` | Atelier | `Hammer` | `#84cc16` |
| `soiree_privee` | Soirée privée | `Martini` | `#8b5cf6` |
| `associatif` | Événement associatif | `Users` | `#22c55e` |
| `seminaire` | Séminaire | `Briefcase` | `#64748b` |

**Squelette générique** : `pages/EventFicheView.jsx` lit la config via `getEventType(event.eventType)` et adapte le rendu (icône, couleur, label) sans dupliquer la fiche par type.

### Bibliothèque documentaire (10 documents — déclarative)
`fiche_event`, `fiche_prestataire`, `planning`, `programme`, `invitation`, `page_publique`, `checklist`, `budget_simple`, `fiche_technique`, `contacts_utiles`.

**Aucun de ces 10 documents n'est implémenté en Phase 2A.** Le Studio les affiche en liste indicative.

---

## 7. Limites de la Phase 2A — Confirmées

| Limite | Statut | Preuve |
|---|---|---|
| `visibility` strictement `private_draft` | ✅ Forcé | enum à 1 valeur dans le schéma |
| Aucun hash événementiel | ✅ | Aucun fichier `lib/event-core/seal/*` créé pour Event |
| Aucun endpoint public | ✅ | Aucune route `/verify/event/*`, aucune fonction backend Event |
| Aucune backend function créée | ✅ | Liste backend = `sealCachet`, `verifyCachet` uniquement (inchangée) |
| Aucun PDF événementiel | ✅ | Aucun import `jspdf` dans `components/event/*` |
| Aucun scellement événementiel | ✅ | Aucun composant `SealButton` dupliqué |
| Aucun partage public | ✅ | Le verso pointe vers `/events/fiche/:id` interne uniquement |
| Pas dans la navigation principale | ✅ | Voir §4 |

---

## 8. Preuves qu'AIME Cachet reste intact

### 8.1 Fichiers vérifiés ligne-à-ligne (lecture effective réalisée pour ce freeze)

| Fichier | Méthode de vérification | Résultat |
|---|---|---|
| `entities/Prestation.json` | `read_file` | ✅ Identique à v1.3 (champs intermittents intacts, `verification_hash` toujours présent) |
| `lib/verificationHash.js` | `read_file` | ✅ `HASHED_FIELDS` = 8 champs (`cachetCode`, `status`, `prestationDate`, `employerName`, `location`, `prestationType`, `sector`, `annex`) — INCHANGÉS |
| `functions/sealCachet` | `read_file` | ✅ Code v1.3 inchangé, scellement intermittent intact |
| `functions/verifyCachet` | `read_file` | ✅ Whitelist 8 champs publics + disclaimer doctrinal intacts |
| `lib/event-core/verticals/intermittence.js` | `read_file` | ✅ Liste `protectedFiles` inchangée — référence narrative préservée |

### 8.2 Fichiers protégés non touchés en Phase 2A

| Fichier | État |
|---|---|
| `entities/Prestation.json` | ✅ Non modifié |
| `lib/verificationHash.js` (`HASHED_FIELDS`) | ✅ Non modifié |
| `functions/sealCachet` | ✅ Non modifié |
| `functions/verifyCachet` | ✅ Non modifié |
| `pages/Dashboard507.jsx` | ✅ Non modifié |
| `pages/FicheView.jsx` | ✅ Non modifié |
| `pages/Verify.jsx` | ✅ Non modifié |
| `pages/AimeCachet.jsx` | ✅ Non modifié |
| `pages/MesPrestations.jsx` | ✅ Non modifié |
| `components/aime/SideRail.jsx` | ✅ Non modifié |
| `components/aime/fiche/SealButton.jsx` | ✅ Non modifié |
| `components/aime/fiche/studio/SectionCertification.jsx` | ✅ Non modifié (freeze wording précédent intact) |
| `lib/event-core/verticals/intermittence.js` | ✅ Non modifié |
| **Les 14 templates `*Paper.jsx` intermittents** | ✅ Non modifiés |

### 8.3 Liste des 14 templates `*Paper.jsx` intermittents protégés
`FichePaper`, `FicheVerso`, `CachetPaper`, `DevisPaper`, `NoteHonorairesPaper`, `RecuPaper`, `PresencePaper`, `CessionPaper`, `FraisPaper`, `DpaePaper`, `AemPaper`, `AttPePaper`, `GusoPaper`, `CddUPaper`, `CessionDroitsPaper`, `AvenantPaper` — **tous strictement intacts.**

### 8.4 Routes AIME Cachet — toutes opérationnelles

| Route | Composant | État |
|---|---|---|
| `/` | `Landing` | 🟢 Inchangée |
| `/app` | `AimeCachet` | 🟢 Inchangée |
| `/prestations` | `MesPrestations` | 🟢 Inchangée |
| `/507` | `Dashboard507` | 🟢 Inchangée |
| `/fiche/:id` | `FicheView` | 🟢 Inchangée |
| `/verify/:cachetCode` | `Verify` | 🟢 Inchangée |
| `/recherche` | `Recherche` | 🟢 Inchangée |
| `/notifications` | `Notifications` | 🟢 Inchangée |
| `/profil` | `Profil` | 🟢 Inchangée |
| `/aide` | `Aide` | 🟢 Inchangée |
| `/parametres` | `Parametres` | 🟢 Inchangée |

---

## 9. Données démo — Vérification

### 9.1 Brouillons seed initiaux (3, créés par `create_entity_records` en Phase 2A)

| `id` | Type | Titre | Statut | Visibilité |
|---|---|---|---|---|
| `6a1120c1791314ae4592f0e8` | `spectacle` | Première de saison (brouillon) | `en_preparation` | `private_draft` ✅ |
| `6a1120c1791314ae4592f0e9` | `concert` | Concert acoustique privé | `brouillon` | `private_draft` ✅ |
| `6a1120c1791314ae4592f0ea` | `atelier` | Atelier d'écriture | `brouillon` | `private_draft` ✅ |

### 9.2 Brouillons créés manuellement par l'utilisateur (2, lors des tests)

| `id` | Type | Titre | Statut | Visibilité |
|---|---|---|---|---|
| `6a11224427d653c07ee87d74` | `festival` | Nouvel événement (brouillon) | `brouillon` | `private_draft` ✅ |
| `6a11225c92120f339fad25e5` | `mariage` | Nouvel événement (brouillon) | `brouillon` | `private_draft` ✅ |

### 9.3 Bilan données

| Question | Réponse |
|---|---|
| Combien d'EventRecord en base ? | **5 (3 seed + 2 tests utilisateur)** |
| Tous en `private_draft` ? | ✅ **Oui, sans exception** |
| Seedés automatiquement ? | ❌ Non — créés une seule fois en Phase 2A via `create_entity_records`, **pas de re-seed à chaque démarrage** |
| Suppressibles sans impact ? | ✅ Oui — aucune relation FK avec `Prestation` ou autre entité Cachet |
| Aucune fuite vers AIME Cachet ? | ✅ Confirmé — entités totalement indépendantes |

---

## 10. Tests réalisés

### 10.1 Scripts demandés

| Script | Disponibilité | Résultat |
|---|---|---|
| `npm run build` | ❌ **Non disponible** dans cet environnement (sandbox Base44 sans accès shell) |
| `npm run lint` | ❌ **Non disponible** dans cet environnement |
| `npx tsc --noEmit` | ❌ **Non disponible** dans cet environnement |

> **Note** : la plateforme Base44 ne fournit pas d'accès direct au shell. Les builds et lints sont effectués automatiquement par la plateforme à chaque écriture de fichier (validation Deno pour les fonctions backend, validation Vite pour le frontend).

### 10.2 Méthode alternative utilisée

#### Vérifications statiques effectuées
1. ✅ **Lecture intégrale** d'`App.jsx` — 3 imports + 3 routes confirmés, aucune route retirée.
2. ✅ **Lecture intégrale** d'`entities/EventRecord.json` — `visibility` enum à 1 valeur confirmée.
3. ✅ **Lecture intégrale** d'`entities/Prestation.json` — schéma v1.3 inchangé.
4. ✅ **Lecture intégrale** de `lib/verificationHash.js` — `HASHED_FIELDS` (8 champs) intacts.
5. ✅ **Lecture intégrale** de `functions/sealCachet` — logique v1.3 inchangée.
6. ✅ **Lecture intégrale** de `functions/verifyCachet` — whitelist + disclaimer intacts.
7. ✅ **Lecture intégrale** de `lib/event-core/verticals/intermittence.js` — liste de protection intacte.
8. ✅ **Requête base** sur `EventRecord` — 5 records, **tous `private_draft`**, aucune valeur autre.

#### Vérifications runtime
9. ✅ Page courante de l'utilisateur (`/events`) affichée sans erreur — confirmation indirecte que la route fonctionne.
10. ✅ Création de brouillons par l'utilisateur réussie via l'UI (modal de `EventCreateButton`).

#### Garanties par construction
11. ✅ L'enum `visibility` à 1 seule valeur rend **techniquement impossible** la création d'un record non-`private_draft`.
12. ✅ Aucun import croisé entre `components/event/*` et les composants `*Paper.jsx` intermittents.
13. ✅ Aucune référence à `EventRecord` dans les fichiers AIME Cachet.

---

## 11. Rollback

### 11.1 Procédure (< 2 minutes)

1. **Restaurer `App.jsx`** — retirer les 3 imports (lignes 19-21) et les 4 lignes ajoutées (68-71) via `anchor_replace`.
2. **Supprimer les 13 fichiers** :
   - `entities/EventRecord.json`
   - `lib/event-core/verticals/event.js`
   - `pages/Events.jsx`, `pages/EventsType.jsx`, `pages/EventFicheView.jsx`
   - `components/event/EventDraftBanner.jsx`, `EventTypeCard.jsx`, `EventCard.jsx`, `EventFilters.jsx`, `EventCreateButton.jsx`, `EventFichePaper.jsx`, `EventFicheVerso.jsx`, `EventStudio.jsx`
   - `docs/aime-event-phase-2a.md`
3. **Optionnel** : conserver `docs/aime-event-phase-2a-freeze.md` comme trace historique.

### 11.2 Effets

| Aspect | Effet |
|---|---|
| Données AIME Cachet | 🟢 Aucun impact |
| Fiches intermittentes scellées | 🟢 Toutes préservées (hash technique conservé) |
| Routes AIME Cachet | 🟢 Toutes opérationnelles |
| Données AIME Event | 🔴 Les 5 records `EventRecord` deviennent orphelins (supprimés avec l'entité) — **strictement isolés**, aucun effet sur le reste |

---

## 12. Interdictions pour la suite (Phase 2B et au-delà)

Toute évolution future devra respecter **STRICTEMENT** les interdictions suivantes. Tout manquement constituera une rupture de la doctrine CanvasCore.

### 12.1 Interdictions absolues
- ❌ **Ne jamais** modifier `HASHED_FIELDS` dans `lib/verificationHash.js` ou `functions/sealCachet` / `functions/verifyCachet`.
- ❌ **Ne jamais** créer de hash officiel événementiel parallèle à celui d'AIME Cachet.
- ❌ **Ne jamais** créer d'endpoint public événementiel (`/verify/event/*` ou équivalent).
- ❌ **Ne jamais** créer de QR de vérification officielle pour les événements (le QR du verso reste indicatif).
- ❌ **Ne jamais** étendre l'enum `visibility` d'`EventRecord` sans Phase 2B validée par l'utilisateur.
- ❌ **Ne jamais** réutiliser ou modifier l'entité `Prestation` pour stocker des EventRecord.
- ❌ **Ne jamais** modifier `lib/event-core/verticals/intermittence.js`.

### 12.2 Interdictions sur les fichiers existants
- ❌ Ne pas modifier les 14 templates `*Paper.jsx` intermittents.
- ❌ Ne pas modifier `SealButton.jsx`, `SectionCertification.jsx`, `FichePaper`, `FicheVerso` intermittents.
- ❌ Ne pas modifier `Dashboard507`, `FicheView`, `Verify`, `AimeCachet`, `MesPrestations`, `SideRail`.

### 12.3 Interdictions sur la navigation (jusqu'à validation Phase 2B)
- ❌ Ne pas ajouter d'entrée AIME Event dans `SideRail`.
- ❌ Ne pas ajouter de carte AIME Event dans `pages/AimeCachet.jsx`.
- ❌ Ne pas ajouter de lien AIME Event dans `Landing.jsx`.
- ❌ Ne pas ajouter d'entrée dans `GlobalToolbar` ou `AimeHeader`.

### 12.4 Vocabulaire interdit dans le code Event
- ❌ « certifié », « officiel », « validé administrativement »
- ❌ « preuve opposable », « signature électronique qualifiée »
- ❌ « hash officiel », « scellement officiel »
- ❌ « endpoint public », « publication officielle »

### 12.5 Vocabulaire obligatoire dans le code Event
- ✅ « brouillon », « préparatoire », « non opposable »
- ✅ « à valider humainement »
- ✅ « aperçu indicatif », « QR d'accès indicatif »
- ✅ « privé », « private_draft »

---

## 13. Conclusion

> **🟢 Phase 2A vérifiée et FIGÉE.**
>
> AIME Event est une verticale parallèle, isolée, strictement préparatoire.
> AIME Cachet (intermittents) reste **techniquement et doctrinalement intact**.
>
> Accès AIME Event : `/events` uniquement par URL directe.
> Aucune visibilité publique. Aucun hash officiel. Aucun endpoint public.
>
> Toute évolution future devra respecter les interdictions de §12.
> Ce document fait foi en tant que freeze de référence.

— **Fin du freeze AIME Event Phase 2A** —