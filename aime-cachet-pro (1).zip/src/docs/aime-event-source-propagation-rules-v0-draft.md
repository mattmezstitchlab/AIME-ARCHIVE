# AIME Event — Source Propagation Rules v0 — Draft doctrinal (itération réduite)

**Date :** 2026-05-23
**Statut :** **Doctrine de travail passive — non exécutable. v0 réduite.**
**Périmètre :** AIME Event uniquement — AIME Cachet strictement hors-scope.
**Nature du document :** Markdown déclaratif. **Aucun code, aucun import, aucune entité, aucune UI.**

**Doctrines de référence :**
- `docs/aime-event-source-propagation-doctrine.md` (cadrage SPE)
- `docs/aime-event-surface-doctrine-pre-ui.md` §0bis (un EventRecord, plusieurs surfaces)
- `docs/aime-event-surface-wording-source-freeze.md` (wording « Fiche préparatoire A4 »)
- `docs/aime-canvascore-doctrine.md`

**Note d'itération :** ce document remplace le draft précédent suite à l'audit critique du 2026-05-23. La v0 est volontairement **drastiquement réduite** pour éviter tout risque de bruit, de confusion brouillon/officiel, ou de glissement comptable.

---

## 1. Objectif v0 réduit

Poser la **table déclarative minimale `source → effets`** du Source Propagation Engine (SPE), pour une v0 **strictement prudente, lisible et exploitable**.

La v0 décrite ici se limite à :
- **5 sources actives**.
- **2 surfaces alimentées** (déjà existantes).
- **1 wallet exposé** (« À compléter »).
- **5 effets checklist** simples.
- **0 document comptable**, **0 action externe**, **0 propagation transitive**.

Tout le reste — devis, factures, budget, prestataires auto, planning, alertes complexes, échéances J-* — est **explicitement exclu de la v0** et déplacé en Roadmap (§10).

Ce document reste **non exécutable**. Aucune ligne de code, aucune entité, aucune UI ne doit être créée sur sa base sans un **freeze v0 d'implémentation explicite** ultérieur.

---

## 2. Doctrine — Cerise propose, l'humain valide

> **Cerise propose. L'humain valide. Toujours.**

Le SPE est un moteur de **détection + proposition**, jamais d'**exécution autonome**.

Règles doctrinales v0, non négociables :

- **D-1** — Aucune proposition ne s'auto-applique. Toute application passe par un geste humain explicite.
- **D-2** — Cerise n'envoie rien, ne publie rien, ne signe rien, ne facture rien, ne scelle rien.
- **D-3** — Toute proposition est réversible avant validation.
- **D-4** — Toute proposition est journalisée pour audit.
- **D-5** — Le SPE est désactivable globalement sans rupture d'AIME Event.

---

## 3. Sources actives v0

**Seules 5 sources sont actives en v0.** Toutes les autres sources `EventRecord` sont **passives** (cf. §4).

| Code | Champ `EventRecord` | Type | Justification |
|---|---|---|---|
| `S-TITLE` | `title` | string | Alimente l'en-tête des deux surfaces actives. Risque minimal. |
| `S-DATE` | `date` | date | Date principale, donnée structurante mais sans propagation transitive. |
| `S-LOCATION` | `location` | string | Lieu, alimentation directe sans parsing. |
| `S-WED-PARTNERS` | `wedding_partners` | string | Mariage uniquement. Alimente la fiche A4 et le faire-part. |
| `S-WED-DATE-CIVIL` | `wedding_date_civil` | date | Mariage uniquement. Champ spécifique sans propagation budgétaire. |

**Critères de sélection :**
- Chaque source alimente **uniquement** les deux surfaces actives v1 (`document`, `faire_part`).
- Aucune source ne déclenche de document comptable ou de chaîne tierce.
- Aucune source n'exige de parsing de texte libre.

---

## 4. Sources passives / hors périmètre v0

Les sources suivantes sont **documentées** (un changement peut être détecté) mais **n'ont aucun effet en v0**. Elles seront réintroduites — si validées — lors de freezes ultérieurs (cf. §10).

| Code | Champ | Raison d'exclusion v0 |
|---|---|---|
| `S-EVT-TYPE` | `eventType` | **Source d'initialisation, pas de propagation.** Voir §4.1. |
| `S-ORGANIZER` | `organizer` | Effets limités, reportés à v1. |
| `S-AUDIENCE` | `audience` | Connotation dimensionnement → risque d'ouvrir la chaîne budget. |
| `S-DESCRIPTION` | `description` | Texte libre, parsing risqué. |
| `S-PROGRAMME` | `programme` | Surface `programme` non active. |
| `S-PRESTATAIRES` | `prestataires` | Texte libre + chaîne devis/contacts → reporté v1+. |
| `S-DOCUMENTS` | `documents` | Pas de propagation v0. |
| `S-WED-GUESTS` | `wedding_guest_count_estimate` | Chaîne budget/devis traiteur → reporté v1+. |
| `S-WED-CEREMONY` | `wedding_ceremony_type` | Chaîne programme/officiant → reporté v1. |
| `S-WED-BUDGET` | `wedding_budget_estimate` | Connotation comptable → reporté v2 minimum. |

### 4.1 Clarification — `eventType` n'est PAS une source de propagation v0

Conformément à l'audit critique :

> `eventType` sert à **initialiser le contexte** de l'événement, pas à déclencher des effets automatiques.

Changer `eventType` reconfigure le sous-graphe doctrinal entier (recommandations, surfaces autorisées, sections Studio). **Ce n'est pas une propagation**, c'est une **réinitialisation**. Le SPE v0 ne le traite pas comme une source.

### 4.2 Clarification — `surfaceMode` reste explicitement exclu

Conformément au §0bis de `docs/aime-event-surface-doctrine-pre-ui.md` :

> `surfaceMode` est un **point de vue** sur la source commune, pas une donnée source elle-même.

Changer la surface active **ne déclenche aucune proposition**. Exclusion non négociable.

---

## 5. Matrice source → surfaces v0

**Légende :** ✅ = alimentation active v0 · — = aucun effet.

| Source | `document` (Fiche A4) | `faire_part` |
|---|---|---|
| `S-TITLE` | ✅ | ✅ |
| `S-DATE` | ✅ | ✅ |
| `S-LOCATION` | ✅ | ✅ |
| `S-WED-PARTNERS` | ✅ | ✅ |
| `S-WED-DATE-CIVIL` | ✅ | ✅ |

**Aucune autre surface n'est alimentée en v0.** Les surfaces `hero`, `programme`, `billet`, `carte`, `web_page`, `mini_site`, etc., restent **réservées** et **non alimentées** par le SPE v0.

---

## 6. Matrice source → wallet « À compléter » v0

**Un seul wallet est exposé en v0 : `W-TODO` (« À compléter »).**

Logique : quand une source v0 **est renseignée**, l'item correspondant est **retiré** de `W-TODO`. Quand une source v0 **est vidée**, l'item est **ajouté** à `W-TODO`. C'est tout.

| Source | Item `W-TODO` géré |
|---|---|
| `S-TITLE` | « Donner un titre à l'événement » |
| `S-DATE` | « Renseigner la date principale » |
| `S-LOCATION` | « Renseigner le lieu » |
| `S-WED-PARTNERS` | « Renseigner les partenaires » *(mariage uniquement)* |
| `S-WED-DATE-CIVIL` | « Renseigner la date de cérémonie civile » *(mariage uniquement)* |

**Aucun autre wallet n'est exposé en v0.** Pas de `W-DOCS`, pas de `W-PRESTA`, pas de `W-BUDGET`, pas de `W-SURF`, pas de `W-DUE`, pas de `W-VALID` visible. La file d'attente des propositions reste une notion interne v1+.

---

## 7. Matrice source → checklist simple v0

**Seuls 5 effets checklist sont autorisés en v0.** Pas d'items J-*, pas d'items prestataires, pas d'items budget.

| Source | Item checklist proposé |
|---|---|
| `S-DATE` | « Confirmer la date » |
| `S-LOCATION` | « Confirmer le lieu » |
| `S-WED-PARTNERS` | « Renseigner les partenaires » *(mariage uniquement)* |
| `S-WED-DATE-CIVIL` | « Confirmer la date civile » *(mariage uniquement)* |
| *(croisé)* | « Vérifier que la fiche préparatoire et le faire-part sont cohérents » |

**L'item croisé** est le **seul item transverse autorisé** en v0. Il est proposé quand au moins une source v0 a été modifiée et que les deux surfaces existent. Il ne dérive pas d'une propagation transitive : c'est un item de **revue manuelle** demandé à l'humain.

---

## 8. Exemple mariage réduit

Cas canonique v0 : `EventRecord` de type `mariage`, utilisateur renseigne progressivement.

### 8.1 Renseignement de `wedding_date_civil = 2026-09-12`

**Source :** `S-WED-DATE-CIVIL`.

**Propositions v0 (max 3 par source) :**

| # | Dérivée | Catégorie | Statut |
|---|---|---|---|
| 1 | Fiche préparatoire A4 : champ « Cérémonie civile » prérempli | Surface | À valider |
| 2 | Faire-part : date affichée | Surface | À valider |
| 3 | Checklist : item « Confirmer la date civile » | Checklist | À valider |

**Wallet `W-TODO` :** l'item « Renseigner la date de cérémonie civile » est retiré.

**Effets v0 explicitement absents :**
- ❌ Pas de planning Jour J.
- ❌ Pas d'échéances J-90 / J-30 / J-7.
- ❌ Pas de relances prestataires.
- ❌ Pas d'alerte de cohérence avec `date` (reportée v1).
- ❌ Pas de devis, pas de facture, pas de budget.

### 8.2 Volume cumulé sur un mariage complet (5 sources v0)

| Source renseignée | Propositions générées |
|---|---|
| `S-TITLE` | 2 (Fiche A4, faire-part) |
| `S-DATE` | 3 (Fiche A4, faire-part, item checklist) |
| `S-LOCATION` | 3 (Fiche A4, faire-part, item checklist) |
| `S-WED-PARTNERS` | 3 (Fiche A4, faire-part, item checklist) |
| `S-WED-DATE-CIVIL` | 3 (Fiche A4, faire-part, item checklist) |
| *(croisé)* | 1 (item de revue cohérence) |
| **Total** | **≤ 8** |

**Plafond doctrinal respecté.** Cf. §11 (R-V0-1, R-V0-2).

---

## 9. Ce qui est explicitement exclu de la v0

Liste exhaustive — **aucun de ces éléments ne doit apparaître dans les matrices v0 ci-dessus** :

- ❌ Devis préparatoire (et toute mention « devis »).
- ❌ Facture préparatoire (et toute mention « facture »).
- ❌ Budget simple.
- ❌ Wallet « Budget ».
- ❌ Fiches prestataires auto-générées.
- ❌ Contacts utiles auto-générés.
- ❌ Plan de table.
- ❌ Relances prestataires.
- ❌ Rappels automatiques.
- ❌ Alertes de capacité.
- ❌ Alertes de dépassement budget.
- ❌ Planning Jour J automatique.
- ❌ Programme automatique.
- ❌ Échéances J-90 / J-60 / J-30 / J-7 / J-1.
- ❌ Génération automatique de document.
- ❌ Action externe (envoi, publication, signature, paiement).
- ❌ Proposition comptable de quelque nature.
- ❌ Proposition officielle de quelque nature.
- ❌ Propagation transitive (A → B → C).
- ❌ Surfaces autres que `document` et `faire_part`.
- ❌ Sources autres que les 5 listées au §3.

---

## 10. Roadmap v1 / v2

Les éléments suivants restent **valides doctrinalement** mais **hors périmètre v0**. Ils ne pourront être activés qu'au prix d'un freeze d'implémentation explicite et d'une revue doctrinale dédiée.

### 10.1 Roadmap v1 (sous réserve de freeze)

- Surface `programme` + propagation `S-PROGRAMME` → `programme`.
- Surface `hero` + propagation simple.
- Planning Jour J (document préparatoire interne).
- Checklist enrichie avec items J-* (jalons temporels).
- Fiche prestataire auto à partir de `S-PRESTATAIRES` (avec parsing contrôlé).
- Contacts utiles auto.
- Alertes de cohérence informatives (date passée, incohérence dates).
- Wallets supplémentaires : `W-DOCS`, `W-PRESTA`, `W-DUE`, `W-SURF`.
- Source active `S-ORGANIZER`, `S-AUDIENCE`, `S-PROGRAMME`, `S-WED-CEREMONY`.

### 10.2 Roadmap v2 (sous réserve de freeze + refonte wording)

- Budget simple « non comptable » (avec wording entièrement repensé, **jamais « budget »** comme tel).
- Surfaces `web_page`, `mini_site` (assemblage de surfaces existantes).
- Source active `S-WED-GUESTS`, `S-WED-BUDGET`.
- Propagation transitive limitée (A → B → C maximum profondeur 2, avec détection de cycles).
- Wallet « Validation humaine » (`W-VALID`) exposé en UI.

### 10.3 Roadmap v2+ — gel doctrinal strict

- Devis / facture **préparatoires** ne pourront être réintroduits **qu'avec** :
  - un freeze doctrinal dédié ;
  - un wording entièrement repensé (jamais « devis », jamais « facture ») ;
  - une isolation visuelle et structurelle totale ;
  - une revue juridique préalable.
- En l'absence de ces conditions, ces éléments restent **interdits**.

---

## 11. Garde-fous v0 (invariants non négociables)

| # | Invariant |
|---|---|
| G-V0-1 | Toute dérivée reste `private_draft`. |
| G-V0-2 | Aucun envoi sortant (email, SMS, webhook, tiers). |
| G-V0-3 | Aucune publication, aucune URL publique. |
| G-V0-4 | Aucune signature (électronique, manuscrite, cachet). |
| G-V0-5 | Aucun document officiel. |
| G-V0-6 | Aucun scellement, aucun hash, aucune interaction avec AIME Cachet. |
| G-V0-7 | Aucune relance externe. Aucun rappel automatique. |
| G-V0-8 | Toute proposition est réversible avant validation. |
| G-V0-9 | Toute propagation est journalisée. |
| G-V0-10 | Le SPE v0 est désactivable globalement sans rupture d'AIME Event. |
| G-V0-11 | `surfaceMode` n'est jamais une source. |
| G-V0-12 | `eventType` n'est jamais une source de propagation v0 (initialisation uniquement). |
| G-V0-13 | Aucun appel réseau tiers déclenché par le SPE. |
| G-V0-14 | Aucune écriture du SPE dans une entité AIME Cachet (`Prestation`, etc.). |
| G-V0-15 | Aucune création d'entité, route, fichier JS sur la base de ce document seul. |
| G-V0-16 | **Maximum 3 propositions actives par source.** |
| G-V0-17 | **Maximum 8 propositions actives par `EventRecord`.** |
| G-V0-18 | **Aucune propagation transitive en v0.** Seul `source → dérivée directe` autorisé. |
| G-V0-19 | **Aucune génération automatique de document** (les surfaces et items sont préremplis, pas générés). |
| G-V0-20 | **Aucune proposition comptable** de quelque nature. |
| G-V0-21 | **Aucune proposition officielle** de quelque nature. |
| G-V0-22 | Tout passage de ce Markdown à une config exécutable exige un freeze v0 d'implémentation explicite. |

---

## 12. Risques v0

| # | Risque | Gravité | Mitigation |
|---|---|---|---|
| R-V0-1 | Volume excessif de propositions | Faible | Plafond G-V0-16 (3/source) et G-V0-17 (8/event). |
| R-V0-2 | Propagation circulaire | Très faible | G-V0-18 : aucune propagation transitive. |
| R-V0-3 | Confusion brouillon / officiel | Faible | §9 : aucun document comptable n'apparaît dans les matrices v0. |
| R-V0-4 | Glissement vers action externe | Très faible | G-V0-2, G-V0-3, G-V0-7, G-V0-13. |
| R-V0-5 | Contamination AIME Cachet | Très faible | G-V0-6, G-V0-14. |
| R-V0-6 | Implémentation prématurée | Élevée | G-V0-15, G-V0-22 : document non exécutable. |
| R-V0-7 | Lecture rapide laissant croire à de l'automatique | Moyenne | §2 D-1 à D-5 ; wording « propose », jamais « génère » ni « automatique ». |
| R-V0-8 | Dérive du périmètre lors d'un futur freeze | Moyenne | Roadmap §10 strictement séparée des matrices v0. |

---

## 13. Rollback

Le document est **strictement non destructif** et trivialement réversible.

### 13.1 Rollback de l'itération réduite (retour au draft précédent)

Aucun rollback automatique possible : le draft précédent est remplacé. En cas de besoin, restaurer la version antérieure depuis l'historique Git.

### 13.2 Rollback complet du document

```
delete_file docs/aime-event-source-propagation-rules-v0-draft.md
```

**Aucune autre action requise.** Aucune migration. Aucun code à retoucher. Aucun champ utilisateur affecté. Aucun comportement d'AIME Event modifié.

### 13.3 État après rollback complet

- Doctrine SPE de cadrage `docs/aime-event-source-propagation-doctrine.md` : intacte.
- Code d'AIME Event : intact.
- AIME Cachet : intact.

---

**Fin du draft doctrinal v0 (itération réduite).**