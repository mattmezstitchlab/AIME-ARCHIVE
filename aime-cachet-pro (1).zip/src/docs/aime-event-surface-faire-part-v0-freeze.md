# AIME Event — Surface `faire_part` v0 — Freeze documentaire

**Date :** 2026-05-23
**Statut :** Gelé (v0 — vérification visuelle validée)
**Périmètre :** AIME Event uniquement — AIME Cachet strictement non impacté.

---

## 1. Objectif

Établir, de manière strictement non destructive, la **première surface canvas alternative** du système AIME Event : `faire_part`.

Cette surface constitue une **preuve technique** que le registre `lib/event-core/surfaces/` peut accueillir et router des rendus alternatifs sans toucher au cœur `EventFicheView` ni à la surface `document` (A4) déjà en place.

La surface est :
- **active techniquement** dans le registre,
- **invisible côté UI** (aucun sélecteur, aucun bouton, aucun switcher),
- **activable uniquement** par modification manuelle du champ `EventRecord.surfaceMode` en base.

Aucun utilisateur final ne peut, en v0, atteindre ce rendu via l'interface.

---

## 2. Doctrine respectée

- **Strictement préparatoire** — aucun document opposable, aucune valeur officielle.
- **Privé par construction** — `visibility: "private_draft"` inchangé.
- **Aucun hash, aucun scellement, aucun /verify, aucun PDF, aucun endpoint public, aucun RSVP, aucun module invités.**
- **AIME Cachet doctrine inchangée** — aucune ligne de code Cachet touchée.
- **Filigrane `BROUILLON` + footer doctrinal** présents sur la surface `faire_part` (composants partagés `DraftWatermark` et `DoctrineFooter`).

---

## 3. Fichiers créés

| Fichier | Rôle |
|---|---|
| `components/event/SurfaceFairePart.jsx` | Composant de rendu A5-portrait de la surface `faire_part`, monté dans un conteneur A4 transparent pour préserver le système de flip/scale existant. Réutilise `DraftWatermark` et `DoctrineFooter`. |
| `docs/aime-event-surface-faire-part-v0-freeze.md` | Présent document de freeze. |

---

## 4. Fichiers modifiés

| Fichier | Nature de la modification |
|---|---|
| `lib/event-core/surfaces/index.js` | Enregistrement de l'entrée `faire_part` dans le registre avec `status: "active"` et binding vers `SurfaceFairePart`. Aucun autre champ du registre modifié. |

**Aucun autre fichier n'a été modifié.**

Notamment, sont restés **strictement intacts** :
- `pages/EventFicheView.jsx`
- `components/event/EventFichePaper.jsx`
- `components/event/EventFicheVerso.jsx`
- `components/event/EventStudio.jsx`
- `components/event/surface/DraftWatermark.jsx`
- `components/event/surface/DoctrineFooter.jsx`
- `lib/event-core/verticals/event.js`
- L'intégralité de `components/aime/**` (AIME Cachet)
- L'intégralité de `functions/**` (`sealCachet`, `verifyCachet`)
- `App.jsx` (aucune nouvelle route)

---

## 5. `surfaceMode` concerné

- **Valeur activée en v0 :** `"faire_part"`
- **Valeur par défaut inchangée :** `"document"`
- **Valeurs `planned` non rendues (fallback silencieux vers `document`) :** `hero`, `programme`, `billet`, `carte`, `web_page`, `section`, `affiche`, `mini_site`, `fiche_prestataire`, `fiche_evenement`.

Le champ `surfaceMode` reste, conformément au schéma :
- **non opposable**,
- **jamais hashé**,
- **jamais scellé**,
- **jamais inclus dans un PDF**,
- **jamais exposé publiquement**,
- **non sélectionnable dans l'UI**.

---

## 6. Preuves de rendu

### 6.1 Preuve du rendu `faire_part`

Vérification effectuée le 2026-05-23 sur un `EventRecord` de test (`eventType: "mariage"`, `surfaceMode: "faire_part"`, partenaires « Alice & Benoît », cérémonie laïque, Château de Versailles, 15 juin 2026).

Rendu observé sur `/events/fiche/:id` :
- Carte A5-portrait centrée dans le conteneur A4 transparent.
- Liseré décoratif fin (double cadre intérieur).
- Suréchappe haute : `VOUS ÊTES CONVIÉ·E·S À CÉLÉBRER` (tracking large, gris doctrinal).
- Bloc central : noms des partenaires en typographie élégante (Playfair Display), séparateur ornemental.
- Date principale en accent doctrinal.
- Lieu (Château de Versailles), description libre, mention de la cérémonie civile et du type de cérémonie.
- Filigrane `BROUILLON` rotaté visible (composant partagé `DraftWatermark`, identique à `document`).
- Footer doctrinal complet en pied de carte (composant partagé `DoctrineFooter`) :
  `BROUILLON PRÉPARATOIRE — NON OPPOSABLE · À VALIDER HUMAINEMENT`
  `Aucune valeur officielle — ne constitue pas un document officiel.`
- Bandeau supérieur de l'app : badge doctrinal `Brouillon préparatoire — non opposable` toujours présent.

### 6.2 Preuve du fallback `document`

Sur le même `EventRecord`, après bascule manuelle de `surfaceMode` à `"document"` :
- Rendu A4 standard `EventFichePaper` restitué à l'identique : header pictogramme mariage, sections `INFORMATIONS / DESCRIPTION / PROGRAMME / PRESTATAIRES / DOCUMENTS PRÉPARATOIRES / DÉTAILS MARIAGE`, filigrane, footer doctrinal.
- **Aucune régression visuelle** par rapport à l'état antérieur au freeze Canvas Surface Foundation.

### 6.3 Preuve du fallback `hero` (planned) → `document`

Sur le même `EventRecord`, après bascule manuelle de `surfaceMode` à `"hero"` :
- Rendu observé **strictement identique** au rendu `document` ci-dessus.
- `resolveSurfaceRenderer("hero")` retourne silencieusement `EventFichePaper`, conformément à la logique du registre (statut `planned` ⇒ fallback).
- Aucun crash, aucun warning console, aucun message d'erreur visible.

---

## 7. Preuves d'isolation UI

### 7.1 Aucun `SurfaceSwitcher` visible

- Aucun composant `SurfaceSwitcher`, `SurfaceSelector`, `SurfacePicker`, `SurfaceMode*` n'existe dans le projet.
- `EventStudio` n'expose **aucun** contrôle (select, radio, toggle, bouton) lié au champ `surfaceMode`.
- `EventFicheView` n'expose **aucun** contrôle de sélection de surface dans la top-bar (boutons présents inchangés : `← Mes événements`, `Supprimer`, `EventDraftBanner`, `Verso`, `Éditer`).
- Recherche textuelle sur le projet : aucune occurrence d'un sélecteur d'UI lié à `surfaceMode`.

### 7.2 Aucune surface publique, aucun artefact opposable

Vérifié sur l'arborescence projet :
- **Aucune route publique** ajoutée dans `App.jsx`. Les routes `/events*` restent toutes derrière `AuthenticatedApp`.
- **Aucun endpoint public** ouvert dans `functions/`. Seules subsistent `sealCachet` et `verifyCachet` (AIME Cachet, inchangées).
- **Aucun export PDF** créé ou modifié pour la surface `faire_part`.
- **Aucun hash de vérification** appliqué à un `EventRecord` (le mécanisme `verification_hash` reste exclusif à `Prestation` / AIME Cachet).
- **Aucun scellement** appliqué à un `EventRecord`.
- **Aucun /verify** étendu aux événements.
- **Aucun module RSVP**, **aucun module invités**, **aucune collecte d'adresses**, **aucun envoi** créé.
- **Aucune mention publique** du `faire_part` n'est exposée à l'extérieur de l'app authentifiée.

### 7.3 Preuve qu'AIME Cachet reste intact

- `components/aime/**` : 0 fichier modifié.
- `functions/sealCachet.js` et `functions/verifyCachet.js` : 0 ligne modifiée.
- `lib/verificationHash.js`, `lib/sealedState.js`, `lib/cachetCode.js` : 0 ligne modifiée.
- `pages/AimeCachet.jsx`, `pages/FicheView.jsx`, `pages/Dashboard507.jsx`, `pages/Verify.jsx`, `pages/MesPrestations.jsx` : 0 ligne modifiée.
- Le schéma `Prestation` (incluant `verification_hash`, `verification_hash_at`, `cachet_code`) est inchangé.
- La route `/verify/:cachetCode` reste exclusivement adossée à AIME Cachet.

---

## 8. Procédure de test manuel

Aucun chemin UI n'expose la surface ; le test passe donc **exclusivement** par modification manuelle du champ `surfaceMode` en base de données.

1. **Créer un événement de test** depuis `/events` via le flux normal (recommandé : `eventType: "mariage"`, renseigner `title`, `wedding_partners`, `date`, `location`, `description`, `wedding_date_civil`, `wedding_ceremony_type`).
2. **Récupérer l'identifiant** de l'`EventRecord` créé (visible dans l'URL `/events/fiche/:id`).
3. **Activer la surface** : depuis le dashboard Base44 (entités → `EventRecord`), éditer le record et passer `surfaceMode` à `"faire_part"`.
4. **Vérifier le rendu** : recharger `/events/fiche/:id`. La surface A5 doit s'afficher avec filigrane et footer doctrinaux.
5. **Tester le fallback `document`** : repasser `surfaceMode` à `"document"`, recharger, vérifier le rendu A4 standard.
6. **Tester un fallback planned** : passer `surfaceMode` à `"hero"`, recharger, vérifier que le rendu A4 standard `document` s'affiche (fallback silencieux).
7. **Tester la cohérence Studio** : ouvrir `EventStudio` (bouton `Éditer`), vérifier qu'**aucun** contrôle de surface n'est exposé et qu'aucune section ne mentionne `surfaceMode`.
8. **Tester l'isolation Cachet** : ouvrir `/app`, `/prestations`, `/fiche/:id` (d'une `Prestation`), vérifier qu'aucun comportement n'a changé.
9. **Nettoyer** : supprimer l'`EventRecord` de test.

---

## 9. Rollback

Le freeze v0 est **strictement non destructif**. Rollback en deux gestes :

1. **Désactiver la surface dans le registre** : dans `lib/event-core/surfaces/index.js`, soit passer l'entrée `faire_part` à `status: "planned"`, soit retirer la ligne. La fonction `resolveSurfaceRenderer` retombera automatiquement sur `EventFichePaper` (`document`) pour tout `EventRecord` ayant `surfaceMode: "faire_part"`.
2. **Supprimer le composant** (optionnel) : `delete_file components/event/SurfaceFairePart.jsx`.

Aucun autre fichier n'a à être touché. Aucun `EventRecord` n'a à être migré : le champ `surfaceMode` reste valide en base, simplement non rendu.

**Aucun risque de perte de données.** Aucun champ utilisateur, aucun hash, aucun document, aucun export n'est lié à la surface.

---

## 10. Prochaine étape recommandée

**Ne pas créer de `SurfaceSwitcher` UI tant que les points suivants ne sont pas tranchés doctrinalement :**

1. **Quelles surfaces doivent passer à `status: "active"` en v1 ?**
   Candidats prioritaires possibles (à arbitrer) : `programme`, `billet`, `carte`. À écarter explicitement de toute UI tant que non actives : `web_page`, `mini_site`, `affiche` (risque d'apparence opposable).
2. **Quel modèle de sélection** : champ libre dans `EventStudio`, palette dédiée, ou tab-bar verticale au-dessus du canvas ? La décision doit préserver la lisibilité doctrinale (statut `BROUILLON` toujours dominant).
3. **Quels types d'événements autorisent quelles surfaces ?**
   Exemple : `faire_part` n'a de sens que pour `mariage` (et éventuellement `soiree_privee`). Il faudra une matrice `eventType × surfaceMode` dans `lib/event-core/verticals/event.js` avant toute exposition UI.
4. **Confirmer en doctrine que toute surface activée reste strictement préparatoire**, jamais imprimable en PDF officiel, jamais exportable hors de l'app authentifiée, jamais détachable de son filigrane `BROUILLON` et de son footer doctrinal.

Tant que ces quatre points ne sont pas écrits dans un freeze doctrinal dédié, **aucun `SurfaceSwitcher`, aucun sélecteur, aucun bouton de surface ne doit être introduit dans l'UI**.

---

**Fin du freeze.**