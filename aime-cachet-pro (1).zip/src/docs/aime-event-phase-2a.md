# AIME Event — Phase 2A · Livrable

**Date** : 23 mai 2026
**Statut** : ✅ Phase 2A appliquée
**Doctrine** : AIME CanvasCore §7 (préparatoire, non opposable, à valider humainement)

---

## 1. Décisions structurantes validées

| # | Question | Choix retenu |
|---|---|---|
| Q1 | Stockage EventRecord | **Entité EventRecord + flag `visibility='private_draft'` strict** |
| Q2 | Navigation `/events` | **Page autonome, accès uniquement par URL** (pas dans SideRail) |
| Q3 | Périmètre Phase 2A | **Squelette complet + 10 types déclarés en config + fiche générique adaptative** |

---

## 2. Fichiers créés

### 2.1 Entité
- ✅ `entities/EventRecord.json` — entité événementielle distincte de `Prestation`

### 2.2 Configuration déclarative
- ✅ `lib/event-core/verticals/event.js` — 10 types, 4 statuts, 10 documents préparatoires, mentions doctrinales

### 2.3 Pages (3 routes)
- ✅ `pages/Events.jsx` — `/events` (registre principal)
- ✅ `pages/EventsType.jsx` — `/events/:type` (vue filtrée par type)
- ✅ `pages/EventFicheView.jsx` — `/events/fiche/:id` (fiche événementielle générique)

### 2.4 Composants (8 composants focalisés)
- ✅ `components/event/EventDraftBanner.jsx` — bandeau doctrinal
- ✅ `components/event/EventTypeCard.jsx` — carte type d'événement
- ✅ `components/event/EventCard.jsx` — carte événement (liste)
- ✅ `components/event/EventFilters.jsx` — recherche + filtres type/statut
- ✅ `components/event/EventCreateButton.jsx` — bouton + modal de création
- ✅ `components/event/EventFichePaper.jsx` — recto de fiche générique
- ✅ `components/event/EventFicheVerso.jsx` — verso (QR indicatif)
- ✅ `components/event/EventStudio.jsx` — panneau d'édition latéral

### 2.5 Documentation
- ✅ `docs/aime-event-phase-2a.md` (présent fichier)

**Total : 13 fichiers créés.**

---

## 3. Fichiers modifiés

| Fichier | Nature | Opérations |
|---|---|---|
| `App.jsx` | 3 imports + 3 routes ajoutés | 2 ops `anchor_replace` |

**Aucun autre fichier touché.**

---

## 4. Routes ajoutées

| Route | Fichier | Accessibilité |
|---|---|---|
| `/events` | `pages/Events.jsx` | URL directe uniquement |
| `/events/:type` | `pages/EventsType.jsx` | URL directe uniquement |
| `/events/fiche/:id` | `pages/EventFicheView.jsx` | URL directe uniquement |

**Aucun lien depuis SideRail, TopBar, ou AimeCachet.** L'utilisateur doit taper l'URL.

---

## 5. Configuration des 10 types

Tous déclarés dans `lib/event-core/verticals/event.js` via `EVENT_TYPES` :

| Clé | Label | Icône | Couleur |
|---|---|---|---|
| `spectacle` | Spectacle | Sparkles | violet |
| `concert` | Concert | Music | rouge |
| `festival` | Festival | Tent | orange |
| `conference` | Conférence | Mic | bleu |
| `mariage` | Mariage | Heart | rose |
| `exposition` | Exposition | Image | teal |
| `atelier` | Atelier | Hammer | vert lime |
| `soiree_privee` | Soirée privée | Martini | violet clair |
| `associatif` | Événement associatif | Users | vert |
| `seminaire` | Séminaire | Briefcase | gris ardoise |

Chaque type contient : `label`, `icon`, `color`, `description`, `essential_fields`, `documents_recommended`, `statuses`, `ai_actions`, `public_preview_enabled`, `timeline_enabled`.

**Le rendu de fiche est générique** : une seule page `EventFicheView.jsx` lit la config et s'adapte au type via `getEventType(event.eventType)`.

---

## 6. Bibliothèque documentaire (10 documents)

Déclarée dans `EVENT_DOCUMENT_LIBRARY` (config uniquement, non implémentés en Phase 2A) :
1. Fiche événement
2. Fiche prestataire
3. Planning
4. Programme
5. Invitation
6. Aperçu public (brouillon)
7. Checklist
8. Budget simple
9. Fiche technique
10. Contacts utiles

---

## 7. Entité EventRecord

| Champ | Type | Notes |
|---|---|---|
| `eventType` | enum (10 valeurs) | Requis |
| `title` | string | Requis |
| `date`, `location`, `organizer`, `audience` | string | Informations essentielles |
| `description`, `programme`, `prestataires`, `internal_notes` | string | Contenu libre |
| `status` | enum (4) | `brouillon` / `en_preparation` / `pret_a_partager` / `archive` |
| **`visibility`** | enum (1) | **`private_draft` uniquement — Phase 2A** |
| `public_code` | string | Préparatoire, n'ouvre AUCUN endpoint |
| `documents` | array | Documents préparatoires liés |
| `studio_settings` | object | Préférences Studio |

**Champs auto** : `id`, `created_date`, `updated_date`, `created_by`.

---

## 8. Preuve qu'AIME Cachet reste intact

| Élément | État |
|---|---|
| Entité `Prestation` | ✅ Inchangée |
| `HASHED_FIELDS` (8 champs figés) | ✅ Inchangés |
| `lib/verificationHash.js` | ✅ Non touché |
| `functions/sealCachet` | ✅ Non touché |
| `functions/verifyCachet` | ✅ Non touché |
| Route `/prestations` | ✅ Inchangée |
| Route `/fiche/:id` (intermittent) | ✅ Inchangée |
| Route `/507` (Cockpit) | ✅ Inchangée |
| Route `/verify/:cachetCode` | ✅ Inchangée |
| `pages/FicheView.jsx` | ✅ Non touché |
| `pages/Dashboard507.jsx` | ✅ Non touché |
| `pages/Verify.jsx` | ✅ Non touché |
| `pages/AimeCachet.jsx` | ✅ Non touché |
| `pages/MesPrestations.jsx` | ✅ Non touché |
| `components/aime/SideRail.jsx` | ✅ Non touché |
| Les 14 templates `*Paper.jsx` (FichePaper, DevisPaper, etc.) | ✅ Non touchés |
| `components/aime/fiche/SealButton.jsx` | ✅ Non touché |
| `components/aime/fiche/studio/SectionCertification.jsx` | ✅ Non touché (freeze précédent intact) |
| `components/aime/fiche/QRBadge.jsx` | ✅ Non touché (juste **importé** par `EventFicheVerso`, pas modifié) |
| `lib/event-core/verticals/intermittence.js` | ✅ Non touché |

**Seul fichier AIME Cachet modifié** : `App.jsx` — uniquement par ajout (3 imports + 3 routes), aucun retrait.

---

## 9. Limites explicites de la Phase 2A

| Limite | État |
|---|---|
| Tous les EventRecord sont **`private_draft` strict** | ✅ Forcé par l'enum à 1 seule valeur |
| **Aucun hash officiel événementiel** | ✅ Aucun hash, aucun scellement |
| **Aucun endpoint public** | ✅ Aucune route publique, aucun `/verify/event/*` |
| **Aucune fonction backend événementielle** | ✅ Zéro backend function créée |
| **Aucune dépendance à `verifyCachet`** | ✅ Confirmé |
| **Aucune dépendance à `sealCachet`** | ✅ Confirmé |
| **QR du verso = indicatif** | ✅ Pointe vers `/events/fiche/:id` interne, libellé « QR d'accès indicatif » |
| **PDF/export** | ❌ Non implémenté en Phase 2A (canvas-only) |
| **Documents de la bibliothèque** | ❌ Déclarés en config mais non implémentés (placeholders dans le Studio) |
| **Actions IA** | ❌ Déclarées en config (`ai_actions`) mais non câblées |
| **Timeline événementielle** | ❌ Drapeau `timeline_enabled` présent mais composant non créé |
| **Partage / page publique** | ❌ Non implémenté — `visibility='private_draft'` strict |
| **Navigation SideRail** | ❌ Volontairement absente (décision Q2 option 2) |

---

## 10. Vocabulaire respecté

### Obligatoire (présent dans le code et l'UI) :
- ✅ « brouillon » — bandeau, statut, modal de création
- ✅ « préparatoire » — `EVENT_DOCTRINE_LABELS.preparatory`
- ✅ « non opposable » — bandeau, footer fiche
- ✅ « à valider humainement » — `EVENT_DOCTRINE_LABELS.human_review`
- ✅ « aperçu public » — config + bibliothèque
- ✅ « QR d'accès » — verso, libellé « QR d'accès indicatif »
- ✅ « version conservée » — footer verso

### Interdit (absent partout) :
- ❌ « certification officielle » — non utilisé
- ❌ « document officiel » — non utilisé
- ❌ « validation administrative » — non utilisé
- ❌ « preuve légale » — non utilisé
- ❌ « signature électronique qualifiée » — non utilisé

---

## 11. Rollback

### 11.1 Méthode

1. Retirer les 3 imports et 3 routes ajoutés dans `App.jsx` (1 `anchor_replace` inverse, 2 ops).
2. Supprimer les 13 fichiers créés :
   - `entities/EventRecord.json`
   - `lib/event-core/verticals/event.js`
   - `pages/Events.jsx`, `pages/EventsType.jsx`, `pages/EventFicheView.jsx`
   - `components/event/EventDraftBanner.jsx`
   - `components/event/EventTypeCard.jsx`
   - `components/event/EventCard.jsx`
   - `components/event/EventFilters.jsx`
   - `components/event/EventCreateButton.jsx`
   - `components/event/EventFichePaper.jsx`
   - `components/event/EventFicheVerso.jsx`
   - `components/event/EventStudio.jsx`
   - `docs/aime-event-phase-2a.md`

### 11.2 Caractéristiques

| Aspect | Valeur |
|---|---|
| Temps estimé | < 2 minutes |
| Risque de régression sur AIME Cachet | 🟢 Nul (aucun fichier Cachet modifié sauf App.jsx en ajout pur) |
| Données affectées | 🟢 Aucune sur `Prestation` (entité EventRecord supprimée → ses records aussi, mais isolés) |
| Compatibilité avec fiches scellées intermittentes | ✅ Totale |

---

## 12. Lien avec la doctrine AIME CanvasCore §7

| Principe §7 | Application en Phase 2A |
|---|---|
| §7.1 — Préparation, jamais opposabilité | ✅ Tous EventRecord = `private_draft`, bandeau permanent |
| §7.2 — Le hash est technique | ✅ **Aucun hash événementiel** en Phase 2A |
| §7.3 — Pas de certification | ✅ Aucun bouton « sceller », aucun scellement |
| §7.4 — Vocabulaire neutre | ✅ Voir section 10 |
| §7.5 — Responsabilité humaine | ✅ « À valider humainement » sur fiche, verso, Studio |

**La Phase 2A prouve que CanvasCore peut accueillir une verticale entière (entité + 3 routes + Studio + verso + bibliothèque + 10 types) sans toucher au cœur intermittent.**

---

> **🟢 Phase 2A appliquée.**
> AIME Cachet (intermittents) reste strictement intact.
> AIME Event est une verticale parallèle, isolée, privée, préparatoire.
> Accessible uniquement par URL directe : `/events`.

— Fin du livrable Phase 2A —