import React from 'react';

export default function Layout({ children }) {
  return (
    <div className="min-h-screen bg-zinc-50">
      <style>{`
        :root {
          --background: 0 0% 98%;
          --foreground: 240 10% 3.9%;
        }
        
        body {
          font-family: 'Inter', system-ui, -apple-system, sans-serif;
          -webkit-font-smoothing: antialiased;
          -moz-osx-font-smoothing: grayscale;
        }
        
        /* Custom scrollbar */
        ::-webkit-scrollbar {
          width: 8px;
          height: 8px;
        }
        
        ::-webkit-scrollbar-track {
          background: #f4f4f5;
        }
        
        ::-webkit-scrollbar-thumb {
          background: #d4d4d8;
          border-radius: 4px;
        }
        
        ::-webkit-scrollbar-thumb:hover {
          background: #a1a1aa;
        }
      `}</style>
      {children}
    </div>
  );
}