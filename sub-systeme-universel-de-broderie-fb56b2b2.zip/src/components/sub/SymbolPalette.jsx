import React from 'react';
import { cn } from "@/lib/utils";

const symbols = [
  { id: 'S01', shape: 'cross', label: 'Croix' },
  { id: 'S02', shape: 'square', label: 'Carré' },
  { id: 'S03', shape: 'circle', label: 'Cercle' },
  { id: 'S04', shape: 'diamond', label: 'Losange' },
  { id: 'S05', shape: 'triangle', label: 'Triangle' },
  { id: 'S06', shape: 'triangleDown', label: 'Triangle inv.' },
  { id: 'S07', shape: 'star', label: 'Étoile' },
  { id: 'S08', shape: 'dot', label: 'Point' },
  { id: 'S09', shape: 'slash', label: 'Barre' },
  { id: 'S10', shape: 'backslash', label: 'Barre inv.' },
  { id: 'S11', shape: 'plus', label: 'Plus' },
  { id: 'S12', shape: 'minus', label: 'Moins' },
];

const SymbolIcon = ({ shape, size = 20 }) => {
  const s = size;
  const half = s / 2;
  const quarter = s / 4;

  switch (shape) {
    case 'cross':
      return (
        <svg width={s} height={s} viewBox={`0 0 ${s} ${s}`}>
          <line x1={quarter} y1={quarter} x2={s - quarter} y2={s - quarter} stroke="currentColor" strokeWidth="2" />
          <line x1={s - quarter} y1={quarter} x2={quarter} y2={s - quarter} stroke="currentColor" strokeWidth="2" />
        </svg>
      );
    case 'square':
      return (
        <svg width={s} height={s} viewBox={`0 0 ${s} ${s}`}>
          <rect x={quarter} y={quarter} width={half} height={half} fill="currentColor" />
        </svg>
      );
    case 'circle':
      return (
        <svg width={s} height={s} viewBox={`0 0 ${s} ${s}`}>
          <circle cx={half} cy={half} r={quarter} fill="currentColor" />
        </svg>
      );
    case 'diamond':
      return (
        <svg width={s} height={s} viewBox={`0 0 ${s} ${s}`}>
          <polygon points={`${half},${quarter} ${s - quarter},${half} ${half},${s - quarter} ${quarter},${half}`} fill="currentColor" />
        </svg>
      );
    case 'triangle':
      return (
        <svg width={s} height={s} viewBox={`0 0 ${s} ${s}`}>
          <polygon points={`${half},${quarter} ${s - quarter},${s - quarter} ${quarter},${s - quarter}`} fill="currentColor" />
        </svg>
      );
    case 'triangleDown':
      return (
        <svg width={s} height={s} viewBox={`0 0 ${s} ${s}`}>
          <polygon points={`${quarter},${quarter} ${s - quarter},${quarter} ${half},${s - quarter}`} fill="currentColor" />
        </svg>
      );
    case 'star':
      return (
        <svg width={s} height={s} viewBox={`0 0 ${s} ${s}`}>
          <polygon points={`${half},2 ${half + 3},${half - 2} ${s - 2},${half - 2} ${half + 4},${half + 2} ${s - 4},${s - 2} ${half},${half + 4} ${4},${s - 2} ${half - 4},${half + 2} ${2},${half - 2} ${half - 3},${half - 2}`} fill="currentColor" />
        </svg>
      );
    case 'dot':
      return (
        <svg width={s} height={s} viewBox={`0 0 ${s} ${s}`}>
          <circle cx={half} cy={half} r={3} fill="currentColor" />
        </svg>
      );
    case 'slash':
      return (
        <svg width={s} height={s} viewBox={`0 0 ${s} ${s}`}>
          <line x1={s - quarter} y1={quarter} x2={quarter} y2={s - quarter} stroke="currentColor" strokeWidth="2" />
        </svg>
      );
    case 'backslash':
      return (
        <svg width={s} height={s} viewBox={`0 0 ${s} ${s}`}>
          <line x1={quarter} y1={quarter} x2={s - quarter} y2={s - quarter} stroke="currentColor" strokeWidth="2" />
        </svg>
      );
    case 'plus':
      return (
        <svg width={s} height={s} viewBox={`0 0 ${s} ${s}`}>
          <line x1={half} y1={quarter} x2={half} y2={s - quarter} stroke="currentColor" strokeWidth="2" />
          <line x1={quarter} y1={half} x2={s - quarter} y2={half} stroke="currentColor" strokeWidth="2" />
        </svg>
      );
    case 'minus':
      return (
        <svg width={s} height={s} viewBox={`0 0 ${s} ${s}`}>
          <line x1={quarter} y1={half} x2={s - quarter} y2={half} stroke="currentColor" strokeWidth="2" />
        </svg>
      );
    default:
      return null;
  }
};

export { symbols, SymbolIcon };

export default function SymbolPalette({ selectedSymbol, onSelectSymbol }) {
  return (
    <div className="bg-white border-t border-zinc-200 p-3">
      <div className="flex items-center gap-1 overflow-x-auto pb-1">
        <span className="text-xs text-zinc-500 mr-3 whitespace-nowrap">Symboles :</span>
        {symbols.map((symbol) => (
          <button
            key={symbol.id}
            onClick={() => onSelectSymbol(symbol)}
            className={cn(
              "flex flex-col items-center p-2 rounded-lg transition-all min-w-[50px]",
              selectedSymbol?.id === symbol.id 
                ? "bg-zinc-900 text-white" 
                : "bg-zinc-100 text-zinc-700 hover:bg-zinc-200"
            )}
            title={symbol.label}
          >
            <SymbolIcon shape={symbol.shape} size={20} />
            <span className="text-[10px] mt-1 font-mono">{symbol.id}</span>
          </button>
        ))}
      </div>
    </div>
  );
}