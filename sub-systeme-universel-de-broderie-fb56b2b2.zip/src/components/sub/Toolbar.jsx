import React from 'react';
import { cn } from "@/lib/utils";
import { MousePointer2, PenTool, Eraser, Hand, Square } from "lucide-react";

const tools = [
  { id: 'select', icon: MousePointer2, label: 'Sélection' },
  { id: 'symbol', icon: PenTool, label: 'Symbole' },
  { id: 'eraser', icon: Eraser, label: 'Gomme' },
  { id: 'hand', icon: Hand, label: 'Déplacement' },
  { id: 'zone', icon: Square, label: 'Zone' },
];

export default function Toolbar({ selectedTool, onSelectTool }) {
  return (
    <div className="w-14 bg-white border-r border-zinc-200 flex flex-col items-center py-4 gap-1">
      {tools.map((tool) => {
        const Icon = tool.icon;
        return (
          <button
            key={tool.id}
            onClick={() => onSelectTool(tool.id)}
            className={cn(
              "w-10 h-10 flex items-center justify-center rounded-lg transition-all",
              selectedTool === tool.id 
                ? "bg-zinc-900 text-white" 
                : "text-zinc-600 hover:bg-zinc-100"
            )}
            title={tool.label}
          >
            <Icon className="w-5 h-5" />
          </button>
        );
      })}
    </div>
  );
}