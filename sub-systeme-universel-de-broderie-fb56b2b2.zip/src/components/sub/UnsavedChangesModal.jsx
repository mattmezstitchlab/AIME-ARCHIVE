import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

export default function UnsavedChangesModal({ open, onSaveAndQuit, onQuitWithoutSaving, onCancel }) {
  return (
    <Dialog open={open} onOpenChange={onCancel}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Modifications non sauvegardées</DialogTitle>
        </DialogHeader>
        
        <p className="text-zinc-600 py-4">
          Voulez-vous sauvegarder votre projet avant de quitter ?
        </p>
        
        <DialogFooter className="flex flex-col sm:flex-row gap-2">
          <Button variant="outline" onClick={onCancel}>
            Annuler
          </Button>
          <Button variant="ghost" onClick={onQuitWithoutSaving} className="text-zinc-500">
            Quitter sans sauvegarder
          </Button>
          <Button onClick={onSaveAndQuit} className="bg-zinc-900 hover:bg-zinc-800">
            Sauvegarder et quitter
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}