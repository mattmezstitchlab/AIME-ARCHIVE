import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { FileDown, FileText, Image } from "lucide-react";

export default function ExportModal({ open, onClose, project, gridData }) {
  
  const exportLCR = () => {
    const data = {
      version: "1.0",
      name: project.name,
      format: project.format,
      width: project.width,
      height: project.height,
      orientation: project.orientation,
      gridData: gridData,
      exportedAt: new Date().toISOString()
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${project.name || 'projet'}.lcr`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    onClose();
  };

  const exportPNG = () => {
    // Create a canvas and draw the grid
    const cellSize = 20;
    const canvas = document.createElement('canvas');
    canvas.width = project.width * cellSize;
    canvas.height = project.height * cellSize;
    const ctx = canvas.getContext('2d');
    
    // White background
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Draw grid lines
    ctx.strokeStyle = '#e4e4e7';
    ctx.lineWidth = 0.5;
    
    for (let i = 0; i <= project.width; i++) {
      ctx.beginPath();
      ctx.moveTo(i * cellSize, 0);
      ctx.lineTo(i * cellSize, canvas.height);
      ctx.stroke();
    }
    
    for (let i = 0; i <= project.height; i++) {
      ctx.beginPath();
      ctx.moveTo(0, i * cellSize);
      ctx.lineTo(canvas.width, i * cellSize);
      ctx.stroke();
    }
    
    // Draw symbols
    ctx.fillStyle = '#18181b';
    ctx.font = `${cellSize - 4}px sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    
    Object.entries(gridData).forEach(([key, value]) => {
      const [row, col] = key.split('-').map(Number);
      const x = col * cellSize + cellSize / 2;
      const y = row * cellSize + cellSize / 2;
      
      if (value?.symbol) {
        // Draw symbol representation
        const symbol = value.symbol.id || '×';
        ctx.fillText(symbol.replace('S', ''), x, y);
      }
    });
    
    // Export
    canvas.toBlob((blob) => {
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${project.name || 'projet'}.png`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    });
    onClose();
  };

  const exportPDF = () => {
    // For now, we'll create a simple HTML-based print
    const printWindow = window.open('', '_blank');
    const cellSize = 15;
    
    let gridHTML = `
      <html>
        <head>
          <title>${project.name || 'Projet SUB'}</title>
          <style>
            body { font-family: system-ui, sans-serif; padding: 20px; }
            h1 { font-size: 18px; margin-bottom: 5px; }
            .info { font-size: 12px; color: #666; margin-bottom: 20px; }
            .grid { 
              display: grid; 
              grid-template-columns: repeat(${project.width}, ${cellSize}px);
              border: 1px solid #ccc;
              width: fit-content;
            }
            .cell { 
              width: ${cellSize}px; 
              height: ${cellSize}px; 
              border-right: 1px solid #eee;
              border-bottom: 1px solid #eee;
              display: flex;
              align-items: center;
              justify-content: center;
              font-size: 8px;
            }
            .cell:nth-child(10n) { border-right-color: #999; }
            @media print { body { padding: 0; } }
          </style>
        </head>
        <body>
          <h1>SUB – LECOINTRE</h1>
          <div class="info">
            ${project.name} • ${project.format} • ${project.width}×${project.height} points
          </div>
          <div class="grid">
    `;
    
    for (let row = 0; row < project.height; row++) {
      for (let col = 0; col < project.width; col++) {
        const key = `${row}-${col}`;
        const cellData = gridData[key];
        const content = cellData?.symbol?.id?.replace('S', '') || '';
        gridHTML += `<div class="cell">${content}</div>`;
      }
    }
    
    gridHTML += `
          </div>
        </body>
      </html>
    `;
    
    printWindow.document.write(gridHTML);
    printWindow.document.close();
    printWindow.print();
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Exporter la création</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-3 mt-4">
          <Button
            variant="outline"
            className="w-full justify-start h-auto py-4"
            onClick={exportLCR}
          >
            <FileDown className="w-5 h-5 mr-3 text-zinc-600" />
            <div className="text-left">
              <div className="font-medium">Fichier .LCR</div>
              <div className="text-xs text-zinc-500">Format LECOINTRE, réouvrable dans l'application</div>
            </div>
          </Button>
          
          <Button
            variant="outline"
            className="w-full justify-start h-auto py-4"
            onClick={exportPDF}
          >
            <FileText className="w-5 h-5 mr-3 text-zinc-600" />
            <div className="text-left">
              <div className="font-medium">Exporter en PDF</div>
              <div className="text-xs text-zinc-500">Grille haute définition pour impression</div>
            </div>
          </Button>
          
          <Button
            variant="outline"
            className="w-full justify-start h-auto py-4"
            onClick={exportPNG}
          >
            <Image className="w-5 h-5 mr-3 text-zinc-600" />
            <div className="text-left">
              <div className="font-medium">Exporter en image</div>
              <div className="text-xs text-zinc-500">Format PNG</div>
            </div>
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}