import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { ChevronRight } from "lucide-react";

const slides = [
  {
    title: "Une nouvelle manière de broder",
    text: "SUB / LECOINTRE simplifie les techniques de broderie en un langage clair et structuré. Une seule logique, quelques variantes, des symboles unifiés."
  },
  {
    title: "Du numérique au fil",
    text: "Ce que vous créez sur la grille peut être brodé en vrai, avec fil et toile. Chaque symbole correspond à une action claire à l'aiguille."
  },
  {
    title: "Des formats normalisés",
    text: "Choisissez parmi les formats SUB / LECOINTRE, enregistrez en .LCR, exportez en PDF ou image pour broder chez vous."
  }
];

export default function OnboardingSlides({ onComplete }) {
  const [currentSlide, setCurrentSlide] = useState(0);

  const handleNext = () => {
    if (currentSlide < slides.length - 1) {
      setCurrentSlide(currentSlide + 1);
    } else {
      onComplete();
    }
  };

  const handleSkip = () => {
    onComplete();
  };

  return (
    <div className="fixed inset-0 bg-zinc-900 flex flex-col items-center justify-center z-50">
      <div className="max-w-lg mx-auto px-8 text-center">
        <p className="text-zinc-500 text-sm mb-8 tracking-widest uppercase">
          {currentSlide === 0 ? "Pourquoi SUB ?" : currentSlide === 1 ? "Compatible avec le réel" : "Formats et fichiers"}
        </p>
        
        <h2 className="text-white text-3xl font-light mb-6 leading-relaxed">
          {slides[currentSlide].title}
        </h2>
        
        <p className="text-zinc-400 text-lg leading-relaxed mb-12">
          {slides[currentSlide].text}
        </p>

        <div className="flex items-center justify-center gap-2 mb-12">
          {slides.map((_, index) => (
            <div 
              key={index}
              className={`h-1 rounded-full transition-all duration-300 ${
                index === currentSlide ? 'w-8 bg-white' : 'w-2 bg-zinc-700'
              }`}
            />
          ))}
        </div>

        <div className="flex flex-col gap-3">
          <Button 
            onClick={handleNext}
            className="bg-white text-zinc-900 hover:bg-zinc-100 h-12 px-8 text-base font-medium"
          >
            {currentSlide < slides.length - 1 ? "Continuer" : "Commencer"}
            <ChevronRight className="w-4 h-4 ml-2" />
          </Button>
          
          {currentSlide < slides.length - 1 && (
            <button 
              onClick={handleSkip}
              className="text-zinc-500 hover:text-zinc-300 text-sm transition-colors"
            >
              Passer l'introduction
            </button>
          )}
        </div>
      </div>
    </div>
  );
}