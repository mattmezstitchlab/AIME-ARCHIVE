import React, { useState, useRef, useEffect, useCallback } from 'react';
import { SymbolIcon } from './SymbolPalette';

export default function GridEditor({ 
  width, 
  height, 
  gridData, 
  onGridChange, 
  selectedTool, 
  selectedSymbol,
  symbolSize = 'medium'
}) {
  const containerRef = useRef(null);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isPanning, setIsPanning] = useState(false);
  const [lastMousePos, setLastMousePos] = useState({ x: 0, y: 0 });
  const [isDrawing, setIsDrawing] = useState(false);

  const cellSizes = { small: 20, medium: 28, large: 40 };
  const cellSize = cellSizes[symbolSize] || 28;

  const handleWheel = useCallback((e) => {
    if (e.ctrlKey || e.metaKey) {
      e.preventDefault();
      const delta = e.deltaY > 0 ? -0.1 : 0.1;
      setZoom(prev => Math.max(0.25, Math.min(3, prev + delta)));
    }
  }, []);

  useEffect(() => {
    const container = containerRef.current;
    if (container) {
      container.addEventListener('wheel', handleWheel, { passive: false });
      return () => container.removeEventListener('wheel', handleWheel);
    }
  }, [handleWheel]);

  const handleCellClick = (row, col) => {
    if (selectedTool === 'hand') return;

    const newGrid = JSON.parse(JSON.stringify(gridData));
    const key = `${row}-${col}`;

    if (selectedTool === 'symbol' && selectedSymbol) {
      newGrid[key] = { symbol: selectedSymbol };
    } else if (selectedTool === 'eraser') {
      delete newGrid[key];
    } else if (selectedTool === 'select') {
      // Selection logic can be expanded
    }

    onGridChange(newGrid);
  };

  const handleMouseDown = (e, row, col) => {
    if (selectedTool === 'hand') {
      setIsPanning(true);
      setLastMousePos({ x: e.clientX, y: e.clientY });
    } else {
      setIsDrawing(true);
      handleCellClick(row, col);
    }
  };

  const handleMouseMove = (e, row, col) => {
    if (isPanning) {
      const dx = e.clientX - lastMousePos.x;
      const dy = e.clientY - lastMousePos.y;
      setPan(prev => ({ x: prev.x + dx, y: prev.y + dy }));
      setLastMousePos({ x: e.clientX, y: e.clientY });
    } else if (isDrawing && (selectedTool === 'symbol' || selectedTool === 'eraser')) {
      handleCellClick(row, col);
    }
  };

  const handleMouseUp = () => {
    setIsPanning(false);
    setIsDrawing(false);
  };

  const gridWidth = width * cellSize;
  const gridHeight = height * cellSize;

  return (
    <div 
      ref={containerRef}
      className="flex-1 overflow-hidden bg-zinc-100 relative"
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      style={{ cursor: selectedTool === 'hand' ? 'grab' : 'crosshair' }}
    >
      <div 
        className="absolute"
        style={{
          transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
          transformOrigin: 'center center',
          left: '50%',
          top: '50%',
          marginLeft: -gridWidth / 2,
          marginTop: -gridHeight / 2,
        }}
      >
        {/* Column numbers */}
        <div className="flex" style={{ marginLeft: 30 }}>
          {Array.from({ length: width }).map((_, col) => (
            col % 10 === 0 && (
              <div 
                key={col} 
                className="text-[10px] text-zinc-400 text-center"
                style={{ width: cellSize * 10, position: 'absolute', left: col * cellSize }}
              >
                {col}
              </div>
            )
          ))}
        </div>

        <div className="flex">
          {/* Row numbers */}
          <div className="flex flex-col" style={{ width: 30, marginTop: 20 }}>
            {Array.from({ length: height }).map((_, row) => (
              row % 10 === 0 && (
                <div 
                  key={row} 
                  className="text-[10px] text-zinc-400 text-right pr-2"
                  style={{ height: cellSize * 10, position: 'absolute', top: row * cellSize + 20 }}
                >
                  {row}
                </div>
              )
            ))}
          </div>

          {/* Grid */}
          <div 
            className="bg-white border border-zinc-300 shadow-sm"
            style={{ 
              display: 'grid',
              gridTemplateColumns: `repeat(${width}, ${cellSize}px)`,
              gridTemplateRows: `repeat(${height}, ${cellSize}px)`,
              marginTop: 20,
            }}
          >
            {Array.from({ length: height }).map((_, row) =>
              Array.from({ length: width }).map((_, col) => {
                const key = `${row}-${col}`;
                const cellData = gridData[key];
                const is10thCol = (col + 1) % 10 === 0;
                const is10thRow = (row + 1) % 10 === 0;

                return (
                  <div
                    key={key}
                    className={`
                      border-r border-b flex items-center justify-center
                      ${is10thCol ? 'border-r-zinc-400' : 'border-r-zinc-200'}
                      ${is10thRow ? 'border-b-zinc-400' : 'border-b-zinc-200'}
                      hover:bg-zinc-50 transition-colors
                    `}
                    style={{ width: cellSize, height: cellSize }}
                    onMouseDown={(e) => handleMouseDown(e, row, col)}
                    onMouseMove={(e) => handleMouseMove(e, row, col)}
                  >
                    {cellData?.symbol && (
                      <SymbolIcon 
                        shape={cellData.symbol.shape} 
                        size={cellSize - 6} 
                      />
                    )}
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>

      {/* Zoom controls */}
      <div className="absolute bottom-4 right-4 flex items-center gap-2 bg-white rounded-lg shadow-lg p-2">
        <button 
          onClick={() => setZoom(prev => Math.max(0.25, prev - 0.25))}
          className="w-8 h-8 flex items-center justify-center text-zinc-600 hover:bg-zinc-100 rounded"
        >
          −
        </button>
        <span className="text-sm text-zinc-600 min-w-[50px] text-center">
          {Math.round(zoom * 100)}%
        </span>
        <button 
          onClick={() => setZoom(prev => Math.min(3, prev + 0.25))}
          className="w-8 h-8 flex items-center justify-center text-zinc-600 hover:bg-zinc-100 rounded"
        >
          +
        </button>
        <button 
          onClick={() => { setZoom(1); setPan({ x: 0, y: 0 }); }}
          className="ml-2 px-2 h-8 text-xs text-zinc-500 hover:bg-zinc-100 rounded"
        >
          Reset
        </button>
      </div>
    </div>
  );
}