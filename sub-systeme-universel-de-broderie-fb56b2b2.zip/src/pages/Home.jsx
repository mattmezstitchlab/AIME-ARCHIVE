import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from "@/components/ui/button";
import { HelpCircle, Plus, FolderOpen } from "lucide-react";
import OnboardingSlides from '@/components/sub/OnboardingSlides';

export default function Home() {
  const [showOnboarding, setShowOnboarding] = useState(false);

  useEffect(() => {
    const hasSeenOnboarding = localStorage.getItem('sub_onboarding_seen');
    if (!hasSeenOnboarding) {
      setShowOnboarding(true);
    }
  }, []);

  const handleOnboardingComplete = () => {
    localStorage.setItem('sub_onboarding_seen', 'true');
    setShowOnboarding(false);
  };

  return (
    <div className="min-h-screen bg-zinc-50">
      {showOnboarding && <OnboardingSlides onComplete={handleOnboardingComplete} />}
      
      {/* Header */}
      <header className="bg-zinc-900 text-white">
        <div className="max-w-5xl mx-auto px-6 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">SUB</h1>
            <p className="text-zinc-400 text-sm">Système Universel de Broderie – LECOINTRE</p>
          </div>
          <Link to={createPageUrl('Help')}>
            <Button variant="ghost" className="text-zinc-400 hover:text-white hover:bg-zinc-800">
              <HelpCircle className="w-4 h-4 mr-2" />
              Aide
            </Button>
          </Link>
        </div>
      </header>

      {/* Main content */}
      <main className="max-w-2xl mx-auto px-6 py-20">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-light text-zinc-900 mb-6">
            Bienvenue dans <span className="font-semibold">SUB – LECOINTRE</span>
          </h2>
          <p className="text-lg text-zinc-600 leading-relaxed max-w-lg mx-auto">
            Une nouvelle manière de broder, plus simple, plus claire, universelle.
            Créez vos motifs, choisissez un format, imprimez vos grilles, ou brodez directement sur l'écran.
          </p>
        </div>

        <div className="flex flex-col items-center gap-4">
          <Link to={createPageUrl('NewProject')} className="w-full max-w-xs">
            <Button className="w-full h-14 bg-zinc-900 hover:bg-zinc-800 text-base font-medium">
              <Plus className="w-5 h-5 mr-2" />
              Créer un nouveau projet
            </Button>
          </Link>
          
          <Link to={createPageUrl('OpenProject')} className="w-full max-w-xs">
            <Button className="w-full h-14 bg-zinc-900 hover:bg-zinc-800 text-base font-medium">
              <FolderOpen className="w-5 h-5 mr-2" />
              Ouvrir un projet existant
            </Button>
          </Link>
          
          <Link 
            to={createPageUrl('Help')}
            className="mt-4 text-zinc-500 hover:text-zinc-900 transition-colors text-sm"
          >
            Comprendre la technique SUB / LECOINTRE →
          </Link>
        </div>

        {/* Decorative element */}
        <div className="mt-20 flex justify-center">
          <div className="grid grid-cols-5 gap-1 opacity-20">
            {Array.from({ length: 25 }).map((_, i) => (
              <div 
                key={i} 
                className={`w-4 h-4 ${i % 3 === 0 ? 'bg-zinc-400' : 'border border-zinc-300'}`}
              />
            ))}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="fixed bottom-0 left-0 right-0 py-4 text-center text-xs text-zinc-400">
        SUB – Système Universel de Broderie © LECOINTRE
      </footer>
    </div>
  );
}