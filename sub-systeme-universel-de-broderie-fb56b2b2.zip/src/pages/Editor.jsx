import React, { useState, useEffect, useCallback } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { base44 } from '@/api/base44Client';
import { Button } from "@/components/ui/button";
import { Save, Download, HelpCircle } from "lucide-react";
import Toolbar from '@/components/sub/Toolbar';
import GridEditor from '@/components/sub/GridEditor';
import SymbolPalette from '@/components/sub/SymbolPalette';
import ExportModal from '@/components/sub/ExportModal';
import UnsavedChangesModal from '@/components/sub/UnsavedChangesModal';

export default function Editor() {
  const navigate = useNavigate();
  const [project, setProject] = useState(null);
  const [gridData, setGridData] = useState({});
  const [selectedTool, setSelectedTool] = useState('symbol');
  const [selectedSymbol, setSelectedSymbol] = useState(null);
  const [hasChanges, setHasChanges] = useState(false);
  const [showExportModal, setShowExportModal] = useState(false);
  const [showUnsavedModal, setShowUnsavedModal] = useState(false);
  const [pendingNavigation, setPendingNavigation] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);

  const urlParams = new URLSearchParams(window.location.search);
  const projectId = urlParams.get('id');

  useEffect(() => {
    const loadProject = async () => {
      if (!projectId) {
        navigate(createPageUrl('Home'));
        return;
      }

      try {
        const projects = await base44.entities.Project.filter({ id: projectId });
        if (projects.length > 0) {
          const p = projects[0];
          setProject(p);
          setGridData(p.grid_data ? JSON.parse(p.grid_data) : {});
        } else {
          navigate(createPageUrl('Home'));
        }
      } catch (error) {
        console.error('Erreur chargement projet:', error);
        navigate(createPageUrl('Home'));
      } finally {
        setIsLoading(false);
      }
    };

    loadProject();
  }, [projectId, navigate]);

  const handleGridChange = useCallback((newGridData) => {
    setGridData(newGridData);
    setHasChanges(true);
  }, []);

  const handleSave = async () => {
    if (!project) return;
    setIsSaving(true);
    try {
      await base44.entities.Project.update(project.id, {
        grid_data: JSON.stringify(gridData)
      });
      setHasChanges(false);
    } catch (error) {
      console.error('Erreur sauvegarde:', error);
    } finally {
      setIsSaving(false);
    }
  };

  const handleNavigateAway = (destination) => {
    if (hasChanges) {
      setPendingNavigation(destination);
      setShowUnsavedModal(true);
    } else {
      navigate(createPageUrl(destination));
    }
  };

  const handleSaveAndQuit = async () => {
    await handleSave();
    setShowUnsavedModal(false);
    if (pendingNavigation) {
      navigate(createPageUrl(pendingNavigation));
    }
  };

  const handleQuitWithoutSaving = () => {
    setShowUnsavedModal(false);
    setHasChanges(false);
    if (pendingNavigation) {
      navigate(createPageUrl(pendingNavigation));
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-zinc-100 flex items-center justify-center">
        <div className="text-zinc-500">Chargement du projet...</div>
      </div>
    );
  }

  if (!project) {
    return (
      <div className="min-h-screen bg-zinc-100 flex items-center justify-center">
        <div className="text-zinc-500">Projet introuvable</div>
      </div>
    );
  }

  return (
    <div className="h-screen flex flex-col bg-zinc-100">
      {/* Header */}
      <header className="bg-zinc-900 text-white shrink-0">
        <div className="px-4 py-3 flex items-center justify-between">
          <button 
            onClick={() => handleNavigateAway('Home')}
            className="flex items-center hover:opacity-80 transition-opacity"
          >
            <span className="text-lg font-bold tracking-tight">SUB</span>
            <span className="text-zinc-500 mx-2">–</span>
            <span className="text-sm text-zinc-400">LECOINTRE</span>
          </button>

          <div className="flex items-center gap-2">
            <span className="text-sm text-zinc-300">{project.name}</span>
            <span className="text-xs text-zinc-500 bg-zinc-800 px-2 py-1 rounded">
              {project.format}
            </span>
            {hasChanges && (
              <span className="text-xs text-amber-400">● Non sauvegardé</span>
            )}
          </div>

          <div className="flex items-center gap-2">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={handleSave}
              disabled={isSaving || !hasChanges}
              className="text-zinc-300 hover:text-white hover:bg-zinc-800"
            >
              <Save className="w-4 h-4 mr-2" />
              {isSaving ? 'Sauvegarde...' : 'Sauvegarder'}
            </Button>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => setShowExportModal(true)}
              className="text-zinc-300 hover:text-white hover:bg-zinc-800"
            >
              <Download className="w-4 h-4 mr-2" />
              Exporter
            </Button>
            <Link to={createPageUrl('Help')}>
              <Button 
                variant="ghost" 
                size="sm"
                className="text-zinc-300 hover:text-white hover:bg-zinc-800"
              >
                <HelpCircle className="w-4 h-4 mr-2" />
                Aide
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Main editor area */}
      <div className="flex-1 flex overflow-hidden">
        <Toolbar selectedTool={selectedTool} onSelectTool={setSelectedTool} />
        
        <GridEditor
          width={project.width}
          height={project.height}
          gridData={gridData}
          onGridChange={handleGridChange}
          selectedTool={selectedTool}
          selectedSymbol={selectedSymbol}
          symbolSize={project.symbol_size}
        />
      </div>

      {/* Symbol palette */}
      <SymbolPalette 
        selectedSymbol={selectedSymbol} 
        onSelectSymbol={setSelectedSymbol} 
      />

      {/* Modals */}
      <ExportModal
        open={showExportModal}
        onClose={() => setShowExportModal(false)}
        project={project}
        gridData={gridData}
      />

      <UnsavedChangesModal
        open={showUnsavedModal}
        onSaveAndQuit={handleSaveAndQuit}
        onQuitWithoutSaving={handleQuitWithoutSaving}
        onCancel={() => setShowUnsavedModal(false)}
      />
    </div>
  );
}