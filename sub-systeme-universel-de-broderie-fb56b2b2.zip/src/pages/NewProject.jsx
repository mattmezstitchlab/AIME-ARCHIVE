import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { base44 } from '@/api/base44Client';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { ArrowLeft, Sparkles } from "lucide-react";

const traditionalFormats = [
  { id: 'A5', label: 'A5', desc: '148 × 210 mm', width: 148, height: 210 },
  { id: 'A4', label: 'A4', desc: '210 × 297 mm', width: 210, height: 297 },
  { id: 'A3', label: 'A3', desc: '297 × 420 mm', width: 297, height: 420 },
  { id: 'carre', label: 'Format carré', desc: '200 × 200 points', width: 200, height: 200 },
  { id: 'paysage', label: 'Format paysage', desc: '300 × 200 points', width: 300, height: 200 },
  { id: 'portrait', label: 'Format portrait', desc: '200 × 300 points', width: 200, height: 300 },
  { id: 'libre', label: 'Format libre', desc: 'Saisie manuelle', width: 100, height: 100 },
];

const subFormats = [
  { id: 'SUB-100', label: 'SUB-100', desc: '100 × 100 points – Format simple, idéal pour découvrir SUB', width: 100, height: 100 },
  { id: 'SUB-144', label: 'SUB-144', desc: 'Format optimisé pour 144 symboles officiels LECOINTRE', width: 144, height: 144 },
  { id: 'LECOINTRE-360', label: 'LECOINTRE-360', desc: '360 × 360 points – Haute définition pour portraits', width: 360, height: 360 },
  { id: 'SUB-Timeline', label: 'SUB Timeline', desc: '1000 × 50 points – Bande horizontale pour frises', width: 1000, height: 50 },
];

export default function NewProject() {
  const navigate = useNavigate();
  const [name, setName] = useState('');
  const [format, setFormat] = useState('SUB-100');
  const [customWidth, setCustomWidth] = useState(100);
  const [customHeight, setCustomHeight] = useState(100);
  const [orientation, setOrientation] = useState('portrait');
  const [symbolSize, setSymbolSize] = useState('medium');
  const [isLoading, setIsLoading] = useState(false);

  const getFormatDimensions = () => {
    if (format === 'libre') {
      return { width: parseInt(customWidth) || 100, height: parseInt(customHeight) || 100 };
    }
    const allFormats = [...traditionalFormats, ...subFormats];
    const selected = allFormats.find(f => f.id === format);
    return selected ? { width: selected.width, height: selected.height } : { width: 100, height: 100 };
  };

  const handleCreate = async () => {
    setIsLoading(true);
    try {
      const dims = getFormatDimensions();
      const project = await base44.entities.Project.create({
        name: name || 'Sans titre',
        format,
        width: dims.width,
        height: dims.height,
        orientation,
        symbol_size: symbolSize,
        grid_data: JSON.stringify({})
      });
      navigate(createPageUrl(`Editor?id=${project.id}`));
    } catch (error) {
      console.error('Erreur lors de la création:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-zinc-50">
      {/* Header */}
      <header className="bg-zinc-900 text-white">
        <div className="max-w-5xl mx-auto px-6 py-4 flex items-center">
          <Link to={createPageUrl('Home')} className="flex items-center text-zinc-400 hover:text-white transition-colors">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Retour
          </Link>
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-6 py-12">
        <h1 className="text-3xl font-light text-zinc-900 mb-2">Nouveau projet SUB / LECOINTRE</h1>
        <p className="text-zinc-500 mb-10">
          Choisissez un format de grille. Vous pouvez utiliser des formats traditionnels ou les nouveaux formats SUB / LECOINTRE.
        </p>

        <div className="space-y-8">
          {/* Nom du projet */}
          <div>
            <Label htmlFor="name" className="text-sm font-medium text-zinc-700">Nom du projet</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Ex : Fleur de Lys SUB, Portrait, Motif géométrique…"
              className="mt-2"
            />
          </div>

          {/* Nouveaux formats SUB */}
          <div className="bg-zinc-100 rounded-xl p-6 border-2 border-zinc-200">
            <div className="flex items-center gap-2 mb-4">
              <Sparkles className="w-4 h-4 text-zinc-600" />
              <span className="text-sm font-semibold text-zinc-900">Formats SUB / LECOINTRE</span>
              <span className="text-[10px] bg-zinc-900 text-white px-2 py-0.5 rounded-full">Nouveauté</span>
            </div>
            <RadioGroup value={format} onValueChange={setFormat} className="space-y-3">
              {subFormats.map((f) => (
                <div key={f.id} className="flex items-start space-x-3">
                  <RadioGroupItem value={f.id} id={f.id} className="mt-1" />
                  <Label htmlFor={f.id} className="cursor-pointer">
                    <div className="font-medium text-zinc-900">{f.label}</div>
                    <div className="text-sm text-zinc-500">{f.desc}</div>
                  </Label>
                </div>
              ))}
            </RadioGroup>
          </div>

          {/* Formats traditionnels */}
          <div>
            <h3 className="text-sm font-medium text-zinc-700 mb-4">Formats traditionnels</h3>
            <RadioGroup value={format} onValueChange={setFormat} className="space-y-3">
              {traditionalFormats.map((f) => (
                <div key={f.id} className="flex items-start space-x-3">
                  <RadioGroupItem value={f.id} id={f.id} className="mt-1" />
                  <Label htmlFor={f.id} className="cursor-pointer">
                    <div className="font-medium text-zinc-900">{f.label}</div>
                    <div className="text-sm text-zinc-500">{f.desc}</div>
                  </Label>
                </div>
              ))}
            </RadioGroup>

            {format === 'libre' && (
              <div className="mt-4 ml-6 flex gap-4">
                <div>
                  <Label className="text-xs text-zinc-500">Largeur (points)</Label>
                  <Input
                    type="number"
                    value={customWidth}
                    onChange={(e) => setCustomWidth(e.target.value)}
                    className="w-24 mt-1"
                    min={10}
                    max={2000}
                  />
                </div>
                <div>
                  <Label className="text-xs text-zinc-500">Hauteur (points)</Label>
                  <Input
                    type="number"
                    value={customHeight}
                    onChange={(e) => setCustomHeight(e.target.value)}
                    className="w-24 mt-1"
                    min={10}
                    max={2000}
                  />
                </div>
              </div>
            )}
          </div>

          {/* Orientation */}
          <div>
            <Label className="text-sm font-medium text-zinc-700 mb-3 block">Orientation de la grille</Label>
            <RadioGroup value={orientation} onValueChange={setOrientation} className="flex gap-4">
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="portrait" id="portrait" />
                <Label htmlFor="portrait">Portrait</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="paysage" id="paysage" />
                <Label htmlFor="paysage">Paysage</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="carre" id="carre-orient" />
                <Label htmlFor="carre-orient">Carré</Label>
              </div>
            </RadioGroup>
          </div>

          {/* Taille des symboles */}
          <div>
            <Label className="text-sm font-medium text-zinc-700 mb-3 block">Taille d'affichage des symboles</Label>
            <RadioGroup value={symbolSize} onValueChange={setSymbolSize} className="flex gap-4">
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="small" id="small" />
                <Label htmlFor="small">Petite</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="medium" id="medium" />
                <Label htmlFor="medium">Moyenne</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="large" id="large" />
                <Label htmlFor="large">Grande</Label>
              </div>
            </RadioGroup>
          </div>

          {/* Buttons */}
          <div className="flex justify-center gap-4 pt-6">
            <Link to={createPageUrl('Home')}>
              <Button variant="outline" className="px-8">
                Annuler
              </Button>
            </Link>
            <Button 
              onClick={handleCreate} 
              disabled={isLoading}
              className="px-8 bg-zinc-900 hover:bg-zinc-800"
            >
              {isLoading ? 'Création...' : 'Créer la grille'}
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
}