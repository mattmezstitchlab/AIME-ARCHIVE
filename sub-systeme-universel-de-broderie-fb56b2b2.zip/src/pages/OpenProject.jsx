import React, { useState, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Button } from "@/components/ui/button";
import { ArrowLeft, FolderOpen, Upload, Calendar, Grid3X3, Trash2 } from "lucide-react";
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function OpenProject() {
  const navigate = useNavigate();
  const fileInputRef = useRef(null);
  const [deleteId, setDeleteId] = useState(null);

  const { data: projects = [], isLoading, refetch } = useQuery({
    queryKey: ['projects'],
    queryFn: () => base44.entities.Project.list('-updated_date'),
  });

  const handleImportLCR = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const text = await file.text();
      const data = JSON.parse(text);
      
      const project = await base44.entities.Project.create({
        name: data.name || 'Projet importé',
        format: data.format || 'SUB-100',
        width: data.width || 100,
        height: data.height || 100,
        orientation: data.orientation || 'portrait',
        symbol_size: 'medium',
        grid_data: JSON.stringify(data.gridData || {})
      });

      navigate(createPageUrl(`Editor?id=${project.id}`));
    } catch (error) {
      console.error('Erreur import:', error);
      alert('Erreur lors de l\'import du fichier .LCR');
    }
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    try {
      await base44.entities.Project.delete(deleteId);
      refetch();
    } catch (error) {
      console.error('Erreur suppression:', error);
    }
    setDeleteId(null);
  };

  return (
    <div className="min-h-screen bg-zinc-50">
      {/* Header */}
      <header className="bg-zinc-900 text-white">
        <div className="max-w-5xl mx-auto px-6 py-4 flex items-center">
          <Link to={createPageUrl('Home')} className="flex items-center text-zinc-400 hover:text-white transition-colors">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Retour
          </Link>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-6 py-12">
        <h1 className="text-3xl font-light text-zinc-900 mb-2">Ouvrir un projet SUB / LECOINTRE</h1>
        <p className="text-zinc-500 mb-10">
          Retrouvez vos projets enregistrés ou importez un fichier .LCR
        </p>

        {/* Import button */}
        <div className="mb-8">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleImportLCR}
            accept=".lcr"
            className="hidden"
          />
          <Button
            variant="outline"
            onClick={() => fileInputRef.current?.click()}
            className="w-full h-14 border-dashed border-2 hover:border-zinc-400"
          >
            <Upload className="w-5 h-5 mr-2" />
            Importer un fichier .LCR
          </Button>
        </div>

        {/* Projects list */}
        <div className="space-y-3">
          {isLoading ? (
            <div className="text-center py-12 text-zinc-500">
              Chargement des projets...
            </div>
          ) : projects.length === 0 ? (
            <div className="text-center py-12">
              <FolderOpen className="w-12 h-12 text-zinc-300 mx-auto mb-4" />
              <p className="text-zinc-500">Aucun projet enregistré</p>
              <Link to={createPageUrl('NewProject')}>
                <Button className="mt-4 bg-zinc-900 hover:bg-zinc-800">
                  Créer votre premier projet
                </Button>
              </Link>
            </div>
          ) : (
            projects.map((project) => (
              <div
                key={project.id}
                className="bg-white rounded-xl border border-zinc-200 p-5 hover:shadow-md transition-shadow"
              >
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <h3 className="font-medium text-zinc-900 text-lg">{project.name}</h3>
                    <div className="flex items-center gap-4 mt-2 text-sm text-zinc-500">
                      <span className="flex items-center gap-1">
                        <Grid3X3 className="w-4 h-4" />
                        {project.format}
                      </span>
                      <span>{project.width} × {project.height} pts</span>
                      <span className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        {format(new Date(project.updated_date), 'dd MMM yyyy', { locale: fr })}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => setDeleteId(project.id)}
                      className="text-zinc-400 hover:text-red-600"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                    <Link to={createPageUrl(`Editor?id=${project.id}`)}>
                      <Button className="bg-zinc-900 hover:bg-zinc-800">
                        Ouvrir
                      </Button>
                    </Link>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </main>

      {/* Delete confirmation */}
      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Supprimer ce projet ?</AlertDialogTitle>
            <AlertDialogDescription>
              Cette action est irréversible. Le projet sera définitivement supprimé.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annuler</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">
              Supprimer
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}