import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from "@/components/ui/button";
import { ArrowLeft, Grid3X3, FileText, Monitor, Printer } from "lucide-react";

export default function Help() {
  const handleReviewOnboarding = () => {
    localStorage.removeItem('sub_onboarding_seen');
    window.location.href = createPageUrl('Home');
  };

  return (
    <div className="min-h-screen bg-zinc-50">
      {/* Header */}
      <header className="bg-zinc-900 text-white">
        <div className="max-w-5xl mx-auto px-6 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">SUB</h1>
            <p className="text-zinc-400 text-sm">Système Universel de Broderie – LECOINTRE</p>
          </div>
          <Link to={createPageUrl('Home')}>
            <Button variant="ghost" className="text-zinc-400 hover:text-white hover:bg-zinc-800">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour à l'accueil
            </Button>
          </Link>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-6 py-12">
        <h1 className="text-4xl font-light text-zinc-900 mb-4">
          Comprendre SUB / LECOINTRE
        </h1>
        <p className="text-lg text-zinc-500 mb-12">
          Guide complet de la nouvelle méthode de broderie universelle
        </p>

        {/* Section 1 */}
        <section className="mb-12">
          <div className="flex items-start gap-4 mb-4">
            <div className="w-12 h-12 rounded-xl bg-zinc-100 flex items-center justify-center shrink-0">
              <Grid3X3 className="w-6 h-6 text-zinc-600" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-zinc-900 mb-2">
                Qu'est-ce que SUB / LECOINTRE ?
              </h2>
              <p className="text-zinc-600 leading-relaxed">
                SUB (Système Universel de Broderie) est une méthode qui simplifie et unifie les techniques de broderie traditionnelles. 
                Au lieu de mémoriser des dizaines de types de points différents, SUB propose un système de symboles clairs et universels 
                placés sur une grille normalisée.
              </p>
              <p className="text-zinc-600 leading-relaxed mt-3">
                Chaque symbole correspond à un geste précis à l'aiguille, reproductible de manière identique quel que soit le projet ou le style de broderie.
              </p>
            </div>
          </div>
        </section>

        {/* Section 2 */}
        <section className="mb-12">
          <div className="flex items-start gap-4 mb-4">
            <div className="w-12 h-12 rounded-xl bg-zinc-100 flex items-center justify-center shrink-0">
              <FileText className="w-6 h-6 text-zinc-600" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-zinc-900 mb-2">
                Pourquoi c'est plus simple ?
              </h2>
              <ul className="text-zinc-600 leading-relaxed space-y-2">
                <li className="flex items-start gap-2">
                  <span className="text-zinc-400 mt-1">•</span>
                  <span><strong className="text-zinc-800">Moins de types de points à mémoriser</strong> – Une logique de base identique pour tous les projets.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-zinc-400 mt-1">•</span>
                  <span><strong className="text-zinc-800">Lecture de grille intuitive</strong> – Les symboles sont clairs, sans ambiguïté.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-zinc-400 mt-1">•</span>
                  <span><strong className="text-zinc-800">Formats normalisés</strong> – SUB-100, SUB-144, LECOINTRE-360… Choisissez le format adapté à votre projet.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-zinc-400 mt-1">•</span>
                  <span><strong className="text-zinc-800">Fichier dédié .LCR</strong> – Sauvegardez, partagez, reprenez vos projets facilement.</span>
                </li>
              </ul>
            </div>
          </div>
        </section>

        {/* Section 3 */}
        <section className="mb-12">
          <div className="flex items-start gap-4 mb-4">
            <div className="w-12 h-12 rounded-xl bg-zinc-100 flex items-center justify-center shrink-0">
              <Printer className="w-6 h-6 text-zinc-600" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-zinc-900 mb-2">
                Utilisation dans la vraie vie
              </h2>
              <p className="text-zinc-600 leading-relaxed mb-4">
                SUB / LECOINTRE est conçu pour être utilisé avec du vrai fil et de la vraie toile. Voici comment procéder :
              </p>
              <ol className="text-zinc-600 leading-relaxed space-y-3">
                <li className="flex items-start gap-3">
                  <span className="w-6 h-6 rounded-full bg-zinc-200 flex items-center justify-center text-sm font-medium text-zinc-700 shrink-0">1</span>
                  <span>Créez ou ouvrez votre projet dans l'application</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="w-6 h-6 rounded-full bg-zinc-200 flex items-center justify-center text-sm font-medium text-zinc-700 shrink-0">2</span>
                  <span>Exportez la grille en PDF (haute définition)</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="w-6 h-6 rounded-full bg-zinc-200 flex items-center justify-center text-sm font-medium text-zinc-700 shrink-0">3</span>
                  <span>Imprimez le PDF</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="w-6 h-6 rounded-full bg-zinc-200 flex items-center justify-center text-sm font-medium text-zinc-700 shrink-0">4</span>
                  <span>Brodez en suivant la grille comme une partition : chaque symbole vous indique où piquer et dans quelle direction</span>
                </li>
              </ol>
            </div>
          </div>
        </section>

        {/* Section 4 */}
        <section className="mb-12">
          <div className="flex items-start gap-4 mb-4">
            <div className="w-12 h-12 rounded-xl bg-zinc-100 flex items-center justify-center shrink-0">
              <Monitor className="w-6 h-6 text-zinc-600" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-zinc-900 mb-2">
                Utilisation numérique
              </h2>
              <p className="text-zinc-600 leading-relaxed">
                L'application vous permet également de créer et modifier vos motifs directement sur l'écran, sans avoir à imprimer. 
                C'est idéal pour :
              </p>
              <ul className="text-zinc-600 leading-relaxed mt-3 space-y-1">
                <li>• Concevoir de nouveaux motifs</li>
                <li>• Visualiser un projet avant de le broder</li>
                <li>• Partager vos créations (format .LCR)</li>
                <li>• Apprendre la méthode SUB de manière interactive</li>
              </ul>
            </div>
          </div>
        </section>

        {/* Formats reference */}
        <section className="mb-12 bg-zinc-100 rounded-2xl p-6">
          <h3 className="text-lg font-semibold text-zinc-900 mb-4">Formats SUB / LECOINTRE</h3>
          <div className="grid gap-3">
            <div className="bg-white rounded-lg p-4">
              <div className="font-medium text-zinc-900">SUB-100</div>
              <div className="text-sm text-zinc-500">100 × 100 points – Format simple pour débuter</div>
            </div>
            <div className="bg-white rounded-lg p-4">
              <div className="font-medium text-zinc-900">SUB-144</div>
              <div className="text-sm text-zinc-500">144 × 144 points – Optimisé pour les 144 symboles officiels</div>
            </div>
            <div className="bg-white rounded-lg p-4">
              <div className="font-medium text-zinc-900">LECOINTRE-360</div>
              <div className="text-sm text-zinc-500">360 × 360 points – Haute définition pour les projets ambitieux</div>
            </div>
            <div className="bg-white rounded-lg p-4">
              <div className="font-medium text-zinc-900">SUB Timeline</div>
              <div className="text-sm text-zinc-500">1000 × 50 points – Format bande horizontale pour frises</div>
            </div>
          </div>
        </section>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center pt-8">
          <Link to={createPageUrl('Home')}>
            <Button className="w-full sm:w-auto px-8 bg-zinc-900 hover:bg-zinc-800">
              Retour à l'accueil
            </Button>
          </Link>
          <Button 
            variant="outline" 
            className="w-full sm:w-auto px-8"
            onClick={handleReviewOnboarding}
          >
            Revoir l'introduction
          </Button>
        </div>
      </main>

      {/* Footer */}
      <footer className="py-8 text-center text-xs text-zinc-400">
        SUB – Système Universel de Broderie © LECOINTRE
      </footer>
    </div>
  );
}