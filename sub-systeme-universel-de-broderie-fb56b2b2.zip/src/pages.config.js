import Home from './pages/Home';
import NewProject from './pages/NewProject';
import Editor from './pages/Editor';
import OpenProject from './pages/OpenProject';
import Help from './pages/Help';


export const PAGES = {
    "Home": Home,
    "NewProject": NewProject,
    "Editor": Editor,
    "OpenProject": OpenProject,
    "Help": Help,
}

export const pagesConfig = {
    mainPage: "Home",
    Pages: PAGES,
};