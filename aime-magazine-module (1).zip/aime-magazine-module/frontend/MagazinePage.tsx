import { useState, useRef } from "react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import {
  Search, ArrowRight, BookOpen, MapPin, Users, Wallet, Sparkles,
  Heart, HandHeart, Music, FileText, Globe, Sun, BookHeart,
  Loader2, ChevronRight, ExternalLink, ArrowLeft, Send, Plus,
  Highlighter, Share2, Brain, Clock, Compass, Telescope,
  FolderOpen, Calendar, Newspaper, ListMusic, Map
} from "lucide-react";
import AimeLogo from "@/components/AimeLogo";

// ─── TEMPORAL ZONES ────────────────────────────────────────────────────────
type MagZone = "passe" | "present" | "futur";

// ─── CATEGORIES ─────────────────────────────────────────────────────────────
const CATEGORIES = [
  { id: "mariage", label: "Mariage", icon: Heart },
  { id: "lieux", label: "Lieux", icon: MapPin },
  { id: "prestataires", label: "Prestataires", icon: Users },
  { id: "budget", label: "Budget", icon: Wallet },
  { id: "inspirations", label: "Inspirations", icon: Sparkles },
  { id: "accessibilite", label: "Accessibilité", icon: Globe },
  { id: "solidarite", label: "Solidarité", icon: HandHeart },
  { id: "intermittents", label: "Intermittents", icon: Music },
  { id: "administratif", label: "Administratif", icon: FileText },
  { id: "carte-vivante", label: "Carte Vivante", icon: MapPin },
  { id: "lumen", label: "LUMEN", icon: Sun },
  { id: "histoires", label: "Histoires humaines", icon: BookHeart },
];

// ─── DEMO ARTICLES ─────────────────────────────────────────────────────────
const DEMO_ARTICLES_PRESENT = [
  {
    title: "Mariage en Provence : le guide complet",
    subtitle: "Organiser un mariage sous le soleil du Sud",
    chapo: "La Provence reste la destination préférée des couples français. Entre lavande, mas et gastronomie, voici comment organiser un mariage inoubliable.",
    category: "Lieux",
    readTime: "6 min",
  },
  {
    title: "Budget mariage 2026 : les vrais chiffres",
    subtitle: "Ce que coûte réellement un mariage aujourd'hui",
    chapo: "Entre inflation et nouvelles tendances, le budget moyen d'un mariage a évolué. Décryptage des postes de dépenses et conseils pour optimiser.",
    category: "Budget",
    readTime: "4 min",
  },
  {
    title: "Accessibilité : un mariage ouvert à tous",
    subtitle: "Inclure chaque invité, sans exception",
    chapo: "Handicap, mobilité réduite, régimes alimentaires, neurodiversité : comment penser un événement véritablement inclusif.",
    category: "Accessibilité",
    readTime: "5 min",
  },
];

const DEMO_ARTICLES_PASSE = [
  {
    title: "Retour sur les mariages de l'été 2025",
    subtitle: "Les tendances qui ont marqué la saison",
    chapo: "De la micro-cérémonie au festival wedding, retour sur les formats qui ont séduit les couples l'année dernière.",
    category: "Inspirations",
    readTime: "5 min",
  },
  {
    title: "Intermittents : bilan des cachets déclarés",
    subtitle: "Ce que la communauté a partagé",
    chapo: "Grâce aux données anonymisées de la communauté AIME®, voici un panorama des cachets et conditions de travail des intermittents.",
    category: "Intermittents",
    readTime: "4 min",
  },
  {
    title: "LUMEN : les gestes d'entraide de la communauté",
    subtitle: "Archives solidaires",
    chapo: "Découvrez comment la communauté AIME® a utilisé les crédits LUMEN pour s'entraider au quotidien.",
    category: "LUMEN",
    readTime: "3 min",
  },
];

const DEMO_ARTICLES_FUTUR = [
  {
    title: "Tendances mariage 2027 : ce qui se prépare",
    subtitle: "Inspiré par les projets de la communauté",
    chapo: "Grâce aux projets en cours des utilisateurs AIME®, voici les tendances émergentes pour les mariages de demain.",
    category: "Inspirations",
    readTime: "6 min",
  },
  {
    title: "Carte Vivante : les prestataires qui montent",
    subtitle: "Découverts par d'autres utilisateurs",
    chapo: "Prestataires recommandés, lieux atypiques repérés : ce que la communauté prépare pour ses événements futurs.",
    category: "Carte Vivante",
    readTime: "5 min",
  },
  {
    title: "Projets solidaires à venir",
    subtitle: "Ce que d'autres préparent avec AIME®",
    chapo: "Événements inclusifs, initiatives d'entraide, projets collaboratifs : découvrez ce qui se construit dans la communauté.",
    category: "Solidarité",
    readTime: "4 min",
  },
];

// ─── ARTICLE TYPE ───────────────────────────────────────────────────────────
interface Article {
  title: string;
  subtitle: string;
  chapo: string;
  category: string;
  body: { heading: string; text: string }[];
  practical_info: { label: string; value: string }[];
  key_points: string[];
  actions: { label: string; route: string }[];
  image_prompt: string;
  sources?: { name: string; url: string; role?: string }[];
  section_images?: { section_index: number; description: string; alt: string }[];
  providers?: { name: string; category: string; city: string; priceRange: string; description: string; section_index: number }[];
}

// ─── MAIN COMPONENT ─────────────────────────────────────────────────────────
export default function MagazinePage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [article, setArticle] = useState<Article | null>(null);
  const [generatedAt, setGeneratedAt] = useState<string | null>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);
  const [magZone, setMagZone] = useState<MagZone>("present");
  const [meHighlight, setMeHighlight] = useState(false);
  const [showPlusActions, setShowPlusActions] = useState(false);
  const [showMap, setShowMap] = useState(false);
  const [magInput, setMagInput] = useState("");
  const [chatMessages, setChatMessages] = useState<{ role: "user" | "assistant"; content: string }[]>([]);
  const [chatMode, setChatMode] = useState(true);
  const [chatLoading, setChatLoading] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const magazineChatMutation = trpc.aimeAgent.magazineChat.useMutation({
    onSuccess: (data: { response: string; shouldGenerate: boolean; generateQuery: string }) => {
      setChatMessages((prev) => [...prev, { role: "assistant", content: data.response }]);
      setChatLoading(false);
      if (data.shouldGenerate && data.generateQuery) {
        setTimeout(() => {
          setSearchQuery(data.generateQuery);
          searchMutation.mutate({ query: data.generateQuery, category: activeCategory || undefined, lang });
          setChatMode(false);
        }, 2000);
      }
    },
    onError: () => {
      setChatMessages((prev) => [...prev, { role: "assistant", content: "Oups, petit souci de mon c\u00f4t\u00e9. Redis-moi ?" }]);
      setChatLoading(false);
    },
  });
  const handleChatSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim() || chatLoading) return;
    const msg = searchQuery.trim();
    setChatMessages((prev) => [...prev, { role: "user", content: msg }]);
    setSearchQuery("");
    setChatLoading(true);
    magazineChatMutation.mutate({
      message: msg,
      history: chatMessages.slice(-12),
    });
  };
  const [relatedArticles, setRelatedArticles] = useState<any[]>([]);
  const [sectionImages, setSectionImages] = useState<Record<number, string>>({});
  const [coverImage, setCoverImage] = useState<string | null>(null);
  const [youtubeVideos, setYoutubeVideos] = useState<{ videoId: string; title: string; thumbnail: string; channelTitle: string }[]>([]);
  const [freePhotos, setFreePhotos] = useState<{ url: string; alt: string; photographer: string; source: string }[]>([]);
  const [structuredData, setStructuredData] = useState<{ type: string; label: string; value: string; source: string }[]>([]);
  const [suggestedModules, setSuggestedModules] = useState<{ module: string; label: string; context: string; section_index: number }[]>([]);
  const [providers, setProviders] = useState<{ name: string; category: string; city: string; priceRange: string; description: string; section_index: number }[]>([]);
  const generateImagesMutation = trpc.magazine.generateImages.useMutation({
    onSuccess: (data: { coverUrl?: string; sections: { index: number; url: string; alt: string }[] }) => {
      if (data.coverUrl) setCoverImage(data.coverUrl);
      const imgMap: Record<number, string> = {};
      data.sections.forEach((s: { index: number; url: string }) => { imgMap[s.index] = s.url; });
      setSectionImages(imgMap);
    },
  });
  const searchYouTubeMutation = trpc.magazine.searchYouTube.useMutation({
    onSuccess: (data: { videoId: string; title: string; thumbnail: string; channelTitle: string }[]) => {
      setYoutubeVideos(data);
    },
  });
  const searchPhotosMutation = trpc.magazine.searchPhotos.useMutation({
    onSuccess: (data: { url: string; alt: string; photographer: string; source: string }[]) => {
      setFreePhotos(data);
    },
  });
  const [selectedEdition, setSelectedEdition] = useState<string | null>(null);
  const [lang, setLang] = useState<string>("fr");

  // Fetch editions for Passé view
  const editionsQuery = trpc.magazine.editions.useQuery(undefined, { enabled: magZone === "passe" });
  const editionArticlesQuery = trpc.magazine.editionArticles.useQuery(
    { editionDate: selectedEdition || "" },
    { enabled: !!selectedEdition }
  );
  const recentQuery = trpc.magazine.recent.useQuery(undefined, { enabled: magZone === "passe" && !selectedEdition });

  const searchMutation = trpc.magazine.search.useMutation({
    onSuccess: (data: any) => {
      setArticle(data.article);
      setGeneratedAt(data.generatedAt);
      setRelatedArticles(data.relatedArticles || []);
      setSectionImages({});
      setCoverImage(null);
      setYoutubeVideos([]);
      setFreePhotos([]);
      setStructuredData(data.article?.structured_data || []);
      setSuggestedModules(data.article?.suggested_modules || []);
      setProviders(data.article?.providers || []);
      // Trigger image generation in background
      if (data.article?.image_prompt || data.article?.section_images?.length) {
        generateImagesMutation.mutate({
          imagePrompt: data.article.image_prompt || data.article.title,
          sectionImages: data.article.section_images || [],
        });
      }
      // Trigger YouTube search
      if (data.article?.youtube_keywords?.length) {
        searchYouTubeMutation.mutate({ keywords: data.article.youtube_keywords });
      }
      // Trigger photo search
      if (data.article?.photo_keywords?.length) {
        searchPhotosMutation.mutate({ keywords: data.article.photo_keywords });
      }
    },
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    searchMutation.mutate({
      query: searchQuery.trim(),
      category: activeCategory || undefined,
      lang,
    });
  };

  const handleMagSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!magInput.trim()) return;
    setSearchQuery(magInput);
    searchMutation.mutate({ query: magInput.trim(), category: activeCategory || undefined, lang });
    setMagInput("");
  };

  const handleCategoryClick = (catId: string) => {
    const cat = CATEGORIES.find((c) => c.id === catId);
    if (!cat) return;
    setActiveCategory(catId);
    setSearchQuery(cat.label);
    searchMutation.mutate({ query: cat.label, category: cat.label, lang });
  };

  const handleDemoClick = (demo: { title: string; category: string }) => {
    setSearchQuery(demo.title);
    setActiveCategory(null);
    searchMutation.mutate({ query: demo.title, category: demo.category, lang });
  };
  const handleRefine = (heading: string, type: string) => {
    const refinements: Record<string, string> = {
      approfondir: `Approfondir : ${heading}`,
      local: `Infos locales pour : ${heading}`,
      alternatives: `Alternatives pour : ${heading}`,
    };
    const query = refinements[type] || heading;
    setSearchQuery(query);
    searchMutation.mutate({ query, category: activeCategory || undefined, lang });
  };

  const today = new Date();
  const formattedDate = today.toLocaleDateString("fr-FR", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });
  const editionNumber = Math.floor((today.getTime() - new Date("2024-01-01").getTime()) / (1000 * 60 * 60 * 24));

  const demoArticles = magZone === "passe" ? DEMO_ARTICLES_PASSE : magZone === "futur" ? DEMO_ARTICLES_FUTUR : DEMO_ARTICLES_PRESENT;
  const zoneTitle = magZone === "passe" ? "ARCHIVES" : magZone === "futur" ? "INSPIRATIONS" : "À LA UNE";
  const zoneSubtitle = magZone === "passe" ? "Articles générés par la communauté" : magZone === "futur" ? "Ce que d'autres préparent avec AIME®" : "Sélection éditoriale du jour";

  return (
    <div className="min-h-screen bg-[#ECF0F3] pb-32">
      {/* ═══ HEADER ÉDITORIAL ═══ */}
      <header className="bg-[#ECF0F3]/90 backdrop-blur-sm sticky top-0 z-50" style={{ boxShadow: '8px 8px 16px #D1D9E6, -8px -8px 16px #FFFFFF' }}>
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          {/* Top bar */}
          <div className="flex items-center justify-between py-2">
            <Link href="/" className="flex items-center gap-2 text-[#1d1d1f]/60 hover:text-[#1d1d1f] transition-colors">
              <ArrowLeft size={14} />
              <span className="text-xs font-medium">AIME®</span>
            </Link>
            <span className="text-[10px] uppercase tracking-[0.2em] text-[#1d1d1f]/40 font-medium">
              Édition N°{editionNumber}
            </span>
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-[#1d1d1f]/40 capitalize">{formattedDate}</span>
              <select
                value={lang}
                onChange={(e) => setLang(e.target.value)}
                className="text-[10px] bg-transparent border-none outline-none text-[#1d1d1f]/50 font-bold uppercase cursor-pointer"
              >
                <option value="fr">FR</option>
                <option value="en">EN</option>
                <option value="es">ES</option>
                <option value="it">IT</option>
                <option value="de">DE</option>
                <option value="pt">PT</option>
              </select>
            </div>
          </div>
          {/* Title — coeur battant au-dessus */}
          <div className="py-4 sm:py-6 text-center">
            <div className="flex justify-center mb-3">
              <AimeLogo size={40} animate={true} />
            </div>
            <h1 className="font-display text-3xl sm:text-4xl md:text-5xl tracking-wide text-[#1d1d1f] uppercase">
              AIME<sup className="text-[10px] text-[#1d1d1f]/30">®</sup>{" "}
              <span className="font-light">MAGAZINE</span>
            </h1>
            <p className="text-[11px] sm:text-xs uppercase tracking-[0.25em] text-[#1d1d1f]/40 mt-2">
              Passé archive. Présent éclaire. Futur inspire.
            </p>
          </div>
        </div>
      </header>

      {/* ═══ HERO VISUEL ÉDITORIAL ═══ */}
      <div className="relative w-full h-48 sm:h-64 md:h-80 overflow-hidden">
        <img
          src="https://d2xsxph8kpxj0f.cloudfront.net/310519663634789976/UkPcyXZRQ2oqBvMFxaLujn/magazine-hero-editorial-kxb2psBsqaVRTaXRsvyWp3.webp"
          alt="Équipe éditoriale AIME Magazine"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#ECF0F3] via-transparent to-transparent" />
        <div className="absolute bottom-4 left-0 right-0 text-center">
          <p className="text-[10px] sm:text-xs uppercase tracking-[0.3em] text-[#1d1d1f]/70 font-medium">
            Le meilleur du monde entier, synthétisé pour vous
          </p>
        </div>
      </div>

      {/* ═══ TEMPORAL NAVIGATION — Passé / Présent / Futur ═══ */}
      <div className="flex justify-center py-4 px-4">
        <div className="inline-flex gap-2">
          {([
            { key: "passe" as MagZone, label: "PASSÉ", icon: Clock },
            { key: "present" as MagZone, label: "PRÉSENT", icon: Compass },
            { key: "futur" as MagZone, label: "FUTUR", icon: Telescope },
          ]).map(({ key, label, icon: Icon }) => (
            <button
              key={key}
              onClick={() => { setMagZone(key); setArticle(null); setActiveCategory(null); }}
              className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-bold uppercase tracking-[0.1em] transition-all ${
                magZone === key
                  ? "neu-btn-active text-[#1d1d1f]"
                  : "neu-card-sm text-[#1d1d1f]/50 hover:text-[#1d1d1f]"
              }`}
            >
              <Icon size={13} />
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* ═══ CONVERSATION AIME + SEARCH ═══ */}
      <section className="py-4 sm:py-8 px-4 sm:px-6">
        <div className="max-w-3xl mx-auto">
          {/* Zone de conversation AIME */}
          {chatMode && (
            <div className="mb-4 rounded-2xl p-4" style={{ background: '#ECF0F3', boxShadow: 'inset 4px 4px 8px #D1D9E6, inset -4px -4px 8px #FFFFFF' }}>
              {chatMessages.length === 0 && (
                <p className="text-[#5a6478] text-sm text-center py-4 italic">
                  Salut ! Je suis AIME, ta rédactrice en chef. Dis-moi ce que tu veux explorer et je prépare un article sur mesure.
                </p>
              )}
              {chatMessages.length > 0 && (
                <div className="max-h-60 overflow-y-auto space-y-3 mb-3 px-1">
                  {chatMessages.map((msg, i) => (
                    <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                      <div
                        className={`max-w-[80%] px-3.5 py-2.5 rounded-2xl text-sm leading-relaxed ${
                          msg.role === 'user'
                            ? 'bg-[#1d1d1f] text-white rounded-br-md'
                            : 'text-[#2d3748] rounded-bl-md'
                        }`}
                        style={msg.role === 'assistant' ? { background: '#ECF0F3', boxShadow: '3px 3px 6px #D1D9E6, -3px -3px 6px #FFFFFF' } : undefined}
                      >
                        {msg.content}
                      </div>
                    </div>
                  ))}
                  {chatLoading && (
                    <div className="flex justify-start">
                      <div className="px-3.5 py-2.5 rounded-2xl rounded-bl-md text-sm text-[#5a6478]" style={{ background: '#ECF0F3', boxShadow: '3px 3px 6px #D1D9E6, -3px -3px 6px #FFFFFF' }}>
                        <span className="animate-pulse">AIME réfléchit...</span>
                      </div>
                    </div>
                  )}
                  <div ref={chatEndRef} />
                </div>
              )}
            </div>
          )}
          {/* Champ de saisie unifié */}
          <form onSubmit={chatMode ? handleChatSend : handleSearch} className="relative">
            <div className="neu-card-inset rounded-2xl p-1.5 flex items-center gap-2">
              <div className="flex-1 flex items-center gap-3 px-4">
                <Search size={18} className="text-[#1d1d1f]/30 shrink-0" />
                <input
                  ref={searchInputRef}
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={chatMode ? "Discute avec AIME... elle prépare ton article" : "Une ville, un thème, une question, une intention..."}
                  className="flex-1 bg-transparent border-none outline-none text-[#1d1d1f] text-sm sm:text-base placeholder:text-[#1d1d1f]/30 py-3"
                />
              </div>
              <button
                type="submit"
                disabled={(chatMode ? chatLoading : searchMutation.isPending) || !searchQuery.trim()}
                className="neu-btn-square w-12 h-12 rounded-xl text-[#1d1d1f]/70 flex items-center justify-center shrink-0 disabled:opacity-40 transition-all active:scale-95"
              >
                {(chatMode ? chatLoading : searchMutation.isPending) ? (
                  <Loader2 size={18} className="animate-spin" />
                ) : (
                  <Send size={18} />
                )}
              </button>
            </div>
          </form>
          {/* Toggle mode + suggestions */}
          <div className="mt-3 flex items-center justify-between">
            <button
              onClick={() => setChatMode(!chatMode)}
              className="text-[11px] px-3 py-1.5 rounded-full neu-convex-sm text-[#5a6478] hover:text-[#1d1d1f] transition-all"
            >
              {chatMode ? "Mode recherche directe" : "Discuter avec AIME"}
            </button>
            <div className="flex flex-wrap gap-1.5">
              {(magZone === "passe"
                ? ["archives", "tendances 2025"]
                : magZone === "futur"
                ? ["tendances 2027", "innovations"]
                : ["mariage", "voyage", "artiste"]
              ).map((s) => (
                <button
                  key={s}
                  onClick={() => { setSearchQuery(s); if (!chatMode) searchMutation.mutate({ query: s, lang }); }}
                  className="text-[11px] px-2.5 py-1 rounded-full neu-convex-sm text-[#1d1d1f]/50 hover:text-[#1d1d1f] transition-all"
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ═══ CATEGORIES ═══ */}
      <section className="px-4 sm:px-6 pb-6">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-wrap gap-2 justify-center">
            {CATEGORIES.map((cat) => {
              const Icon = cat.icon;
              const isActive = activeCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => handleCategoryClick(cat.id)}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium transition-all active:scale-95 ${
                    isActive
                      ? "neu-btn-active text-[#1d1d1f]"
                      : "neu-card-sm text-[#1d1d1f]/60 hover:text-[#1d1d1f]"
                  }`}
                >
                  <Icon size={13} />
                  <span>{cat.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* ═══ ARTICLE RESULT ═══ */}
      {article && (
        <section className="px-4 sm:px-6 pb-8">
          <div className="max-w-4xl mx-auto">
            <ArticleView article={article} generatedAt={generatedAt} meHighlight={meHighlight} sectionImages={sectionImages} coverImage={coverImage} onRefine={handleRefine} youtubeVideos={youtubeVideos} freePhotos={freePhotos} structuredData={structuredData} suggestedModules={suggestedModules} providers={providers} showMap={showMap} />

            {/* Related articles from archives */}
            {relatedArticles.length > 0 && (
              <div className="mt-8">
                <h3 className="font-display text-lg uppercase tracking-wide text-[#1d1d1f] mb-4">ARTICLES CONNEXES</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {relatedArticles.map((rel: any) => (
                    <button
                      key={rel.id}
                      onClick={() => {
                        setArticle({
                          title: rel.title,
                          subtitle: rel.subtitle || "",
                          chapo: rel.chapo || "",
                          category: rel.category || "",
                          body: (rel.body as any) || [],
                          practical_info: (rel.practicalInfo as any) || [],
                          key_points: (rel.keyPoints as any) || [],
                          actions: (rel.actions as any) || [],
                          image_prompt: rel.imagePrompt || "",
                        });
                        setGeneratedAt(rel.createdAt);
                        setRelatedArticles([]);
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                      className="neu-card rounded-xl p-4 text-left hover:shadow-lg transition-all active:scale-[0.98]"
                    >
                      <span className="text-[9px] uppercase tracking-[0.15em] text-[#1d1d1f]/50 font-semibold">{rel.category}</span>
                      <h4 className="font-display text-sm uppercase tracking-wide text-[#1d1d1f] mt-1 leading-tight line-clamp-2">{rel.title}</h4>
                      <p className="text-[11px] text-[#1d1d1f]/40 mt-1 line-clamp-2">{rel.chapo}</p>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Back to list button */}
            <div className="mt-6 text-center">
              <button
                onClick={() => { setArticle(null); setRelatedArticles([]); }}
                className="neu-btn-square px-6 py-3 rounded-xl text-sm text-[#1d1d1f]/60 font-medium transition-all active:scale-95"
              >
                ← Retour au Magazine
              </button>
            </div>
          </div>
        </section>
      )}

      {/* ═══ LOADING STATE ═══ */}
      {searchMutation.isPending && !article && (
        <section className="px-4 sm:px-6 pb-8">
          <div className="max-w-4xl mx-auto text-center py-20">
            <Loader2 size={32} className="animate-spin text-[#1d1d1f]/30 mx-auto mb-4" />
            <p className="text-[#1d1d1f]/40 text-sm">Rédaction de l'article en cours...</p>
            <p className="text-[#1d1d1f]/25 text-xs mt-1">Le Magazine AIME® prépare votre contenu éditorial</p>
          </div>
        </section>
      )}

      {/* ═══ CONTENT GRID (conditional by zone) ═══ */}
      {!article && !searchMutation.isPending && (
        <section className="px-4 sm:px-6 pb-8">
          <div className="max-w-6xl mx-auto">

            {/* ─── PASSÉ : Archives / Couvertures Magazine ─── */}
            {magZone === "passe" && (
              <>
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h2 className="font-display text-xl sm:text-2xl uppercase tracking-wide text-[#1d1d1f]">ARCHIVES</h2>
                    <p className="text-xs text-[#1d1d1f]/40 mt-1">Chaque jour, un numéro compilé par la communauté</p>
                  </div>
                  <BookOpen size={18} className="text-[#1d1d1f]/20" />
                </div>

                {/* Edition covers */}
                {selectedEdition ? (
                  <div>
                    <button
                      onClick={() => setSelectedEdition(null)}
                      className="flex items-center gap-2 text-sm text-[#1d1d1f]/60 hover:text-[#1d1d1f] mb-4 transition-colors"
                    >
                      <ArrowLeft size={14} />
                      Retour aux éditions
                    </button>
                    <h3 className="font-display text-lg uppercase tracking-wide text-[#1d1d1f] mb-4">
                      Édition du {new Date(selectedEdition + "T00:00:00").toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" })}
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {editionArticlesQuery.data?.map((art: any) => (
                        <button
                          key={art.id}
                          onClick={() => {
                            setArticle({
                              title: art.title,
                              subtitle: art.subtitle || "",
                              chapo: art.chapo || "",
                              category: art.category || "",
                              body: (art.body as any) || [],
                              practical_info: (art.practicalInfo as any) || [],
                              key_points: (art.keyPoints as any) || [],
                              actions: (art.actions as any) || [],
                              image_prompt: art.imagePrompt || "",
                            });
                            setGeneratedAt(art.createdAt);
                            setCoverImage(art.coverImageUrl || null);
                          }}
                          className="neu-card rounded-2xl overflow-hidden text-left hover:shadow-lg transition-all active:scale-[0.98]"
                        >
                          {art.coverImageUrl ? (
                            <img src={art.coverImageUrl} alt={art.title} className="w-full h-32 object-cover" />
                          ) : (
                            <div className="w-full h-32 bg-gradient-to-br from-[#D1D9E6] to-[#ECF0F3] flex items-center justify-center">
                              <span className="text-3xl font-display uppercase tracking-wider text-[#1d1d1f]/10">{art.category?.[0] || 'A'}</span>
                            </div>
                          )}
                          <div className="p-5">
                            <span className="text-[10px] uppercase tracking-[0.15em] text-[#1d1d1f]/50 font-semibold">{art.category}</span>
                            <h4 className="font-display text-lg uppercase tracking-wide text-[#1d1d1f] mt-1 leading-tight">{art.title}</h4>
                            <p className="text-xs text-[#1d1d1f]/50 mt-1 italic line-clamp-2">{art.chapo}</p>
                          </div>
                        </button>
                      ))}
                      {editionArticlesQuery.isLoading && <Loader2 size={20} className="animate-spin text-[#1d1d1f]/30" />}
                    </div>
                  </div>
                ) : (
                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
                    {/* Edition cover cards — style magazine */}
                    {editionsQuery.data?.map((edition: any, i: number) => {
                      const dateObj = new Date(edition.editionDate + "T00:00:00");
                      const dayStr = dateObj.toLocaleDateString("fr-FR", { day: "2-digit", month: "short" }).toUpperCase();
                      const yearStr = dateObj.getFullYear().toString();
                      return (
                        <button
                          key={edition.editionDate}
                          onClick={() => setSelectedEdition(edition.editionDate)}
                          className="group relative aspect-[3/4] rounded-2xl overflow-hidden transition-all hover:scale-[1.02] active:scale-[0.98]"
                          style={{ background: 'linear-gradient(135deg, #1d1d1f 0%, #3a3a3c 100%)' }}
                        >
                          {/* Cover image if available */}
                          {edition.firstCoverImage && (
                            <img src={edition.firstCoverImage} alt="" className="absolute inset-0 w-full h-full object-cover opacity-60" />
                          )}
                          {/* Dark overlay */}
                          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-black/10" />
                          {/* Cover content */}
                          <div className="absolute inset-0 flex flex-col justify-between p-4">
                            {/* Top: edition info */}
                            <div className="flex items-center justify-between">
                              <span className="text-[8px] uppercase tracking-[0.2em] text-white/60 font-medium">ÉD. N°{edition.editionNumber}</span>
                              <span className="text-[8px] text-white/60">{dayStr} {yearStr}</span>
                            </div>
                            {/* Center: Heart + AIME MAGAZINE */}
                            <div className="text-center">
                              <div className="flex justify-center mb-1">
                                <svg width="20" height="18" viewBox="0 0 24 22" fill="#ec4899" xmlns="http://www.w3.org/2000/svg">
                                  <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
                                </svg>
                              </div>
                              <div className="text-white text-2xl sm:text-3xl font-bold tracking-wider">AIME<sup className="text-[7px] align-super text-white/50">®</sup></div>
                              <div className="text-white/80 text-[10px] sm:text-xs font-light tracking-[0.3em] uppercase">MAGAZINE</div>
                            </div>
                            {/* Bottom: theme + count */}
                            <div className="text-center">
                              <p className="text-white text-xs sm:text-sm font-medium uppercase tracking-wide line-clamp-2">
                                {edition.firstTitle}
                              </p>
                              <p className="text-white/50 text-[9px] mt-1">{edition.articleCount} article{edition.articleCount > 1 ? 's' : ''}</p>
                            </div>
                          </div>
                        </button>
                      );
                    })}

                    {/* Empty state */}
                    {(!editionsQuery.data || editionsQuery.data.length === 0) && !editionsQuery.isLoading && (
                      <div className="col-span-full text-center py-12">
                        <BookOpen size={32} className="text-[#1d1d1f]/20 mx-auto mb-3" />
                        <p className="text-sm text-[#1d1d1f]/40">Aucune archive pour l'instant</p>
                        <p className="text-xs text-[#1d1d1f]/25 mt-1">Générez des articles dans "Présent" pour construire les archives</p>
                      </div>
                    )}
                    {editionsQuery.isLoading && (
                      <div className="col-span-full text-center py-12">
                        <Loader2 size={24} className="animate-spin text-[#1d1d1f]/30 mx-auto" />
                      </div>
                    )}
                  </div>
                )}
              </>
            )}

            {/* ─── PRÉSENT : Demo articles + recherche ─── */}
            {magZone === "present" && (
              <>
                <div className="flex items-center justify-between mb-8">
                  <div>
                    <h2 className="font-display text-xl sm:text-2xl uppercase tracking-wide text-[#1d1d1f]">À LA UNE</h2>
                    <p className="text-xs text-[#1d1d1f]/40 mt-1">Sélection éditoriale du jour</p>
                  </div>
                  <BookOpen size={18} className="text-[#1d1d1f]/20" />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                  {DEMO_ARTICLES_PRESENT.map((demo, i) => (
                    <button
                      key={i}
                      onClick={() => handleDemoClick(demo)}
                      className="neu-card rounded-2xl p-5 text-left hover:shadow-lg transition-all group active:scale-[0.98]"
                    >
                      <span className="text-[10px] uppercase tracking-[0.15em] text-[#1d1d1f]/50 font-semibold">{demo.category}</span>
                      <h3 className="font-display text-lg sm:text-xl uppercase tracking-wide text-[#1d1d1f] mt-2 leading-tight group-hover:text-[#1d1d1f]/80 transition-colors">{demo.title}</h3>
                      <p className="text-xs text-[#1d1d1f]/50 mt-1 italic">{demo.subtitle}</p>
                      <p className="text-sm text-[#1d1d1f]/60 mt-3 leading-relaxed line-clamp-3">{demo.chapo}</p>
                      <div className="flex items-center justify-between mt-4 pt-3" style={{ boxShadow: 'inset 0 1px 2px #D1D9E6' }}>
                        <span className="text-[10px] text-[#1d1d1f]/30">{demo.readTime} de lecture</span>
                        <ChevronRight size={14} className="text-[#1d1d1f]/30 group-hover:translate-x-1 transition-transform" />
                      </div>
                    </button>
                  ))}
                </div>
              </>
            )}

            {/* ─── FUTUR : Inspirations communauté ─── */}
            {magZone === "futur" && (
              <>
                <div className="flex items-center justify-between mb-8">
                  <div>
                    <h2 className="font-display text-xl sm:text-2xl uppercase tracking-wide text-[#1d1d1f]">INSPIRATIONS</h2>
                    <p className="text-xs text-[#1d1d1f]/40 mt-1">Ce que d'autres préparent avec AIME®</p>
                  </div>
                  <Telescope size={18} className="text-[#1d1d1f]/20" />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                  {DEMO_ARTICLES_FUTUR.map((demo, i) => (
                    <button
                      key={i}
                      onClick={() => handleDemoClick(demo)}
                      className="neu-card rounded-2xl p-5 text-left hover:shadow-lg transition-all group active:scale-[0.98]"
                    >
                      <span className="text-[10px] uppercase tracking-[0.15em] text-[#1d1d1f]/50 font-semibold">{demo.category}</span>
                      <h3 className="font-display text-lg sm:text-xl uppercase tracking-wide text-[#1d1d1f] mt-2 leading-tight group-hover:text-[#1d1d1f]/80 transition-colors">{demo.title}</h3>
                      <p className="text-xs text-[#1d1d1f]/50 mt-1 italic">{demo.subtitle}</p>
                      <p className="text-sm text-[#1d1d1f]/60 mt-3 leading-relaxed line-clamp-3">{demo.chapo}</p>
                      <div className="flex items-center justify-between mt-4 pt-3" style={{ boxShadow: 'inset 0 1px 2px #D1D9E6' }}>
                        <span className="text-[10px] text-[#1d1d1f]/30">{demo.readTime} de lecture</span>
                        <ChevronRight size={14} className="text-[#1d1d1f]/30 group-hover:translate-x-1 transition-transform" />
                      </div>
                    </button>
                  ))}
                </div>
              </>
            )}

          </div>
        </section>
      )}

      {/* Baseline stratégique */}
      {!article && !searchMutation.isPending && (
        <div className="text-center py-6 px-4">
          <p className="text-[10px] sm:text-[11px] text-[#1d1d1f]/30 italic tracking-wide">
            Chaque recherche devient un article. Chaque article peut devenir une action. Chaque action enrichit AIME®.
          </p>
        </div>
      )}

      {/* ═══ FIXED BOTTOM BAR — AI | MAP | MÉMOIRE | + | PLAYLIST | DOC | ME ═══ */}
      <div className="fixed bottom-0 left-0 right-0 z-50 bg-[#ECF0F3] px-3 pb-5 pt-2" style={{ boxShadow: '-8px -8px 16px #FFFFFF, 8px 8px 16px #D1D9E6' }}>
        <div className="max-w-md mx-auto">
          {/* Search bar */}
          <form onSubmit={handleMagSearch} className="mb-2 neu-input-bar flex items-center gap-2 px-3 py-2.5 rounded-2xl">
            <Search size={14} className="text-gray-400 shrink-0" />
            <input
              ref={searchInputRef}
              type="text"
              value={magInput}
              onChange={(e) => setMagInput(e.target.value)}
              placeholder="Demandez au Magazine..."
              className="flex-1 bg-transparent text-gray-700 placeholder:text-gray-400 text-sm outline-none"
            />
            <button
              type="submit"
              disabled={!magInput.trim() || searchMutation.isPending}
              className="neu-send-btn w-8 h-8 rounded-xl flex items-center justify-center text-white transition-all disabled:opacity-30"
            >
              <Send size={12} strokeWidth={2.5} />
            </button>
          </form>
          {/* Toolbar icons: AI | MAP | MÉMOIRE | + | PLAYLIST | DOC | ME */}
          <div className="flex items-center justify-between">
            {/* AI */}
            <div className="group relative">
              <button
                onClick={() => toast.info("AI : crédits, paramètres et historique IA")}
                className="neu-btn-square w-11 h-11 flex-col gap-0.5 transition-all duration-200 hover:scale-110 hover:shadow-lg active:scale-95"
              >
                <Brain size={18} className="text-gray-600 group-hover:text-[#1d1d1f] transition-colors" />
                <span className="text-[7px] text-gray-500 font-semibold group-hover:text-[#1d1d1f]">AI</span>
              </button>
              <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-3 py-1.5 rounded-xl text-[10px] text-gray-700 font-medium whitespace-nowrap opacity-0 group-hover:opacity-100 transition-all duration-200 pointer-events-none" style={{ background: '#ECF0F3', boxShadow: '3px 3px 6px #D1D9E6, -3px -3px 6px #FFFFFF' }}>Crédits, paramètres et historique IA</div>
            </div>
            {/* MAP */}
            <div className="group relative">
              <button
                onClick={() => setShowMap(!showMap)}
                className={`neu-btn-square w-11 h-11 flex-col gap-0.5 transition-all duration-200 hover:scale-110 hover:shadow-lg active:scale-95 ${showMap ? 'ring-2 ring-gray-400' : ''}`}
              >
                <Map size={18} className="text-gray-600 group-hover:text-[#1d1d1f] transition-colors" />
                <span className="text-[7px] text-gray-500 font-semibold group-hover:text-[#1d1d1f]">Map</span>
              </button>
              <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-3 py-1.5 rounded-xl text-[10px] text-gray-700 font-medium whitespace-nowrap opacity-0 group-hover:opacity-100 transition-all duration-200 pointer-events-none" style={{ background: '#ECF0F3', boxShadow: '3px 3px 6px #D1D9E6, -3px -3px 6px #FFFFFF' }}>Carte des lieux et personnes</div>
            </div>
            {/* MÉMOIRE */}
            <div className="group relative">
              <button
                onClick={() => toast.info("Mémoire : capsules vocales, souvenirs, SLA")}
                className="neu-btn-square w-11 h-11 flex-col gap-0.5 transition-all duration-200 hover:scale-110 hover:shadow-lg active:scale-95"
              >
                <Compass size={18} className="text-gray-600 group-hover:text-[#1d1d1f] transition-colors" />
                <span className="text-[7px] text-gray-500 font-semibold group-hover:text-[#1d1d1f]">Mémoire</span>
              </button>
              <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-3 py-1.5 rounded-xl text-[10px] text-gray-700 font-medium whitespace-nowrap opacity-0 group-hover:opacity-100 transition-all duration-200 pointer-events-none" style={{ background: '#ECF0F3', boxShadow: '3px 3px 6px #D1D9E6, -3px -3px 6px #FFFFFF' }}>Capsules vocales et souvenirs</div>
            </div>
            {/* + (CENTRAL) */}
            <div className="group relative">
              <button
                onClick={() => toast.info("Créer : sortie, événement, projet, recherche")}
                className="w-14 h-14 rounded-full flex items-center justify-center text-white shadow-lg transition-all duration-200 hover:scale-110 hover:rotate-90 active:scale-95"
                style={{ background: '#1d1d1f', boxShadow: '4px 4px 8px #D1D9E6, -4px -4px 8px #FFFFFF, 0 4px 12px rgba(0,0,0,0.2)' }}
              >
                <Plus size={24} strokeWidth={2.5} />
              </button>
              <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-3 py-1.5 rounded-xl text-[10px] text-gray-700 font-medium whitespace-nowrap opacity-0 group-hover:opacity-100 transition-all duration-200 pointer-events-none" style={{ background: '#ECF0F3', boxShadow: '3px 3px 6px #D1D9E6, -3px -3px 6px #FFFFFF' }}>Créer un événement ou projet</div>
            </div>
            {/* PLAYLIST */}
            <div className="group relative">
              <button
                onClick={() => toast.info("Playlist : vos vidéos et musiques")}
                className="neu-btn-square w-11 h-11 flex-col gap-0.5 transition-all duration-200 hover:scale-110 hover:shadow-lg active:scale-95"
              >
                <ListMusic size={18} className="text-gray-600 group-hover:text-[#1d1d1f] transition-colors" />
                <span className="text-[7px] text-gray-500 font-semibold group-hover:text-[#1d1d1f]">Playlist</span>
              </button>
              <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-3 py-1.5 rounded-xl text-[10px] text-gray-700 font-medium whitespace-nowrap opacity-0 group-hover:opacity-100 transition-all duration-200 pointer-events-none" style={{ background: '#ECF0F3', boxShadow: '3px 3px 6px #D1D9E6, -3px -3px 6px #FFFFFF' }}>Vidéos et musiques sauvegardées</div>
            </div>
            {/* DOC */}
            <div className="group relative">
              <button
                onClick={() => toast.info("Documents : devis, contrats, factures")}
                className="neu-btn-square w-11 h-11 flex-col gap-0.5 transition-all duration-200 hover:scale-110 hover:shadow-lg active:scale-95"
              >
                <FileText size={18} className="text-gray-600 group-hover:text-[#1d1d1f] transition-colors" />
                <span className="text-[7px] text-gray-500 font-semibold group-hover:text-[#1d1d1f]">Doc</span>
              </button>
              <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-3 py-1.5 rounded-xl text-[10px] text-gray-700 font-medium whitespace-nowrap opacity-0 group-hover:opacity-100 transition-all duration-200 pointer-events-none" style={{ background: '#ECF0F3', boxShadow: '3px 3px 6px #D1D9E6, -3px -3px 6px #FFFFFF' }}>Devis, contrats et factures</div>
            </div>
            {/* ME (Profil) */}
            <div className="group relative">
              <button
                onClick={() => toast.info("Profil : statut, infos, préférences")}
                className="neu-btn-square w-11 h-11 flex-col gap-0.5 transition-all duration-200 hover:scale-110 hover:shadow-lg active:scale-95"
              >
                <Users size={18} className="text-gray-600 group-hover:text-[#1d1d1f] transition-colors" />
                <span className="text-[7px] text-gray-500 font-semibold group-hover:text-[#1d1d1f]">Me</span>
              </button>
              <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-3 py-1.5 rounded-xl text-[10px] text-gray-700 font-medium whitespace-nowrap opacity-0 group-hover:opacity-100 transition-all duration-200 pointer-events-none" style={{ background: '#ECF0F3', boxShadow: '3px 3px 6px #D1D9E6, -3px -3px 6px #FFFFFF' }}>Mon profil et statut</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── ARTICLE VIEW COMPONENT ─────────────────────────────────────────────────
function ArticleView({ article, generatedAt, meHighlight, sectionImages, coverImage, onRefine, youtubeVideos, freePhotos, structuredData, suggestedModules, providers, showMap }: {
  article: Article; generatedAt: string | null; meHighlight: boolean;
  sectionImages: Record<number, string>; coverImage: string | null;
  onRefine: (heading: string, type: string) => void;
  youtubeVideos: { videoId: string; title: string; thumbnail: string; channelTitle: string }[];
  freePhotos: { url: string; alt: string; photographer: string; source: string }[];
  structuredData: { type: string; label: string; value: string; source: string }[];
  suggestedModules: { module: string; label: string; context: string; section_index: number }[];
  providers: { name: string; category: string; city: string; priceRange: string; description: string; section_index: number }[];
  showMap: boolean;
}) {
  const handleRefine = onRefine;
  const [activeVideo, setActiveVideo] = useState<string | null>(null);
  return (
    <article className="neu-card rounded-3xl overflow-hidden">
      {/* Article header */}
      <div className="p-6 sm:p-10 pb-0">
        {/* Meta */}
        <div className="flex items-center gap-3 mb-4">
          <span className="text-[10px] uppercase tracking-[0.15em] text-[#1d1d1f]/70 font-semibold px-2 py-0.5 neu-convex-sm rounded-full">
            {article.category}
          </span>
          {generatedAt && (
            <span className="text-[10px] text-[#1d1d1f]/30">
              {new Date(generatedAt).toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" })}
            </span>
          )}
        </div>

        {/* Title */}
        <h1 className="font-display text-3xl sm:text-4xl md:text-5xl uppercase tracking-wide text-[#1d1d1f] leading-tight">
          {article.title}
        </h1>

        {/* Subtitle */}
        <p className="text-base sm:text-lg text-[#1d1d1f]/50 mt-2 italic">
          {article.subtitle}
        </p>

        {/* Chapô */}
        <p className={`text-base sm:text-lg mt-6 leading-relaxed font-medium border-l-3 border-[#D1D9E6] pl-4 transition-all ${
          meHighlight ? "text-[#1d1d1f] bg-red-50/60 rounded-r-lg pr-3 py-1" : "text-[#1d1d1f]/70"
        }`}>
          {article.chapo}
        </p>
      </div>
      {/* Cover image */}
      {coverImage && (
        <div className="mx-6 sm:mx-10 mt-6 rounded-2xl overflow-hidden" style={{ boxShadow: '6px 6px 12px #D1D9E6, -6px -6px 12px #FFFFFF' }}>
          <img src={coverImage} alt={article.title} className="w-full h-56 sm:h-72 object-cover" />
        </div>
      )}

      {/* Divider */}
      <div className="mx-6 sm:mx-10 my-8 h-px bg-gradient-to-r from-transparent via-gray-200 to-transparent" />

      {/* Body with images and interactive choices */}
      <div className="px-6 sm:px-10">
        {article.body.map((section, i) => (
          <div key={i} className="mb-10">
            <h2 className="font-display text-xl sm:text-2xl uppercase tracking-wide text-[#1d1d1f] mb-3">
              {section.heading}
            </h2>
            <div className={`text-sm sm:text-base leading-relaxed whitespace-pre-line transition-all ${
              meHighlight ? "text-[#1d1d1f]/40" : "text-[#1d1d1f]/70"
            }`}>
              {section.text}
            </div>
            {/* Section image (generated) */}
            {sectionImages[i] && (
              <div className="mt-4 rounded-xl overflow-hidden" style={{ boxShadow: '4px 4px 10px #D1D9E6, -4px -4px 10px #FFFFFF' }}>
                <img src={sectionImages[i]} alt={article.section_images?.[i]?.alt || section.heading} className="w-full h-48 sm:h-56 object-cover" />
              </div>
            )}
            {/* Interactive refinement choices */}
            {i < article.body.length - 1 && (
              <div className="mt-4 flex flex-wrap gap-2">
                <button
                  onClick={() => handleRefine(section.heading, "approfondir")}
                  className="text-[11px] px-3 py-1.5 rounded-lg text-[#1d1d1f]/60 hover:text-[#1d1d1f] transition-all"
                  style={{ background: '#ECF0F3', boxShadow: '2px 2px 5px #D1D9E6, -2px -2px 5px #FFFFFF' }}
                >
                  Approfondir
                </button>
                <button
                  onClick={() => handleRefine(section.heading, "local")}
                  className="text-[11px] px-3 py-1.5 rounded-lg text-[#1d1d1f]/60 hover:text-[#1d1d1f] transition-all"
                  style={{ background: '#ECF0F3', boxShadow: '2px 2px 5px #D1D9E6, -2px -2px 5px #FFFFFF' }}
                >
                  Infos locales
                </button>
                <button
                  onClick={() => handleRefine(section.heading, "alternatives")}
                  className="text-[11px] px-3 py-1.5 rounded-lg text-[#1d1d1f]/60 hover:text-[#1d1d1f] transition-all"
                  style={{ background: '#ECF0F3', boxShadow: '2px 2px 5px #D1D9E6, -2px -2px 5px #FFFFFF' }}
                >
                  Alternatives
                </button>
              </div>
            )}
            {/* Contextual modules for this section */}
            {suggestedModules.filter(m => m.section_index === i).map((mod, mi) => {
              const icons: Record<string, typeof FolderOpen> = { dossier: FolderOpen, agenda: Calendar, kiosque: Newspaper, playlist: ListMusic };
              const ModIcon = icons[mod.module] || Plus;
              return (
                <div key={mi} className="mt-3 flex items-center gap-3 p-3 rounded-xl" style={{ background: '#ECF0F3', boxShadow: 'inset 2px 2px 5px #D1D9E6, inset -2px -2px 5px #FFFFFF' }}>
                  <ModIcon size={18} className="text-gray-500 shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-[11px] font-semibold text-[#1d1d1f]/80 truncate">{mod.label}</p>
                    <p className="text-[10px] text-[#1d1d1f]/40 truncate">{mod.context}</p>
                  </div>
                  <button
                    onClick={() => toast.success(`Ajouté à ${mod.module} : ${mod.label}`)}
                    className="shrink-0 w-8 h-8 rounded-lg flex items-center justify-center text-gray-500 hover:text-[#1d1d1f] transition-all"
                    style={{ background: '#ECF0F3', boxShadow: '2px 2px 5px #D1D9E6, -2px -2px 5px #FFFFFF' }}
                  >
                    <Plus size={14} strokeWidth={2.5} />
                  </button>
                </div>
              );
            })}
            {/* Provider cards for this section */}
            {providers.filter(p => p.section_index === i).map((prov, pi) => (
              <div key={`prov-${pi}`} className="mt-3 p-4 rounded-xl" style={{ background: '#ECF0F3', boxShadow: '4px 4px 8px #D1D9E6, -4px -4px 8px #FFFFFF' }}>
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0" style={{ background: '#ECF0F3', boxShadow: 'inset 2px 2px 4px #D1D9E6, inset -2px -2px 4px #FFFFFF' }}>
                    <Users size={16} className="text-[#1d1d1f]/50" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="text-[12px] font-bold text-[#1d1d1f] truncate">{prov.name}</p>
                      <span className="text-[9px] uppercase tracking-wider px-1.5 py-0.5 rounded-full font-medium text-[#1d1d1f]/50" style={{ background: '#ECF0F3', boxShadow: 'inset 1px 1px 2px #D1D9E6, inset -1px -1px 2px #FFFFFF' }}>{prov.category}</span>
                    </div>
                    <p className="text-[11px] text-[#1d1d1f]/60 mt-0.5 line-clamp-2">{prov.description}</p>
                    <div className="flex items-center gap-3 mt-2">
                      {prov.city && (
                        <span className="flex items-center gap-1 text-[10px] text-[#1d1d1f]/40">
                          <MapPin size={10} />{prov.city}
                        </span>
                      )}
                      {prov.priceRange && (
                        <span className="flex items-center gap-1 text-[10px] text-[#1d1d1f]/40">
                          <Wallet size={10} />{prov.priceRange}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
                <div className="flex gap-2 mt-3">
                  <Link
                    href="/app"
                    className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-[11px] font-semibold text-[#1d1d1f]/70 transition-all hover:scale-[1.02] active:scale-95"
                    style={{ background: '#ECF0F3', boxShadow: '2px 2px 5px #D1D9E6, -2px -2px 5px #FFFFFF' }}
                  >
                    <FileText size={12} />
                    Demander un devis
                  </Link>
                  <button
                    onClick={() => toast.success(`${prov.name} ajouté à vos prestataires`)}
                    className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg text-[11px] font-medium text-[#1d1d1f]/50 transition-all hover:scale-[1.02] active:scale-95"
                    style={{ background: '#ECF0F3', boxShadow: '2px 2px 5px #D1D9E6, -2px -2px 5px #FFFFFF' }}
                  >
                    <Plus size={12} />
                    Ajouter
                  </button>
                </div>
              </div>
            ))}
          </div>
        ))}
      </div>

      {/* Key Points — always highlighted when ME is active */}
      {article.key_points.length > 0 && (
        <div className={`mx-6 sm:mx-10 mb-8 p-5 rounded-2xl transition-all ${
          meHighlight ? "bg-red-50/80 shadow-inner" : "neu-inset"
        }`}>
          <h3 className="font-display text-lg uppercase tracking-wide text-[#1d1d1f] mb-3">
            {meHighlight ? "✦ ESSENTIEL POUR VOUS" : "POINTS CLÉS"}
          </h3>
          <ul className="space-y-2">
            {article.key_points.map((point, i) => (
              <li key={i} className={`flex items-start gap-2 text-sm ${
                meHighlight ? "text-[#1d1d1f] font-medium" : "text-[#1d1d1f]/70"
              }`}>
                <span className={`w-1.5 h-1.5 rounded-full mt-1.5 shrink-0 ${meHighlight ? "bg-red-400" : "bg-[#D1D9E6]"}`} />
                <span>{point}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Practical Info */}
      {article.practical_info.length > 0 && (
        <div className={`mx-6 sm:mx-10 mb-8 p-5 rounded-2xl transition-all ${
          meHighlight ? "bg-red-50/40" : "neu-convex"
        }`}>
          <h3 className="font-display text-lg uppercase tracking-wide text-[#1d1d1f] mb-4">
            INFOS PRATIQUES
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {article.practical_info.map((info, i) => (
              <div key={i} className="flex flex-col gap-0.5">
                <span className="text-[10px] uppercase tracking-wider text-[#1d1d1f]/40 font-medium">{info.label}</span>
                <span className={`text-sm ${meHighlight ? "text-[#1d1d1f] font-medium" : "text-[#1d1d1f]/80"}`}>{info.value}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Actions CTA */}
      <div className="mx-6 sm:mx-10 mb-8 p-5 rounded-2xl neu-convex">
        <h3 className="font-display text-lg uppercase tracking-wide text-[#1d1d1f] mb-4">
          ACTIONS
        </h3>
        <div className="flex flex-wrap gap-2">
          {/* Enregistrer dans ME */}
          <button
            onClick={() => toast.success("Article enregistr\u00e9 dans votre espace ME")}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl neu-btn-square text-[#1d1d1f]/80 text-xs font-medium transition-all active:scale-95"
          >
            <Brain size={12} />
            <span>Enregistrer dans ME</span>
          </button>
          {/* Explorer sur la Carte */}
          <Link
            href="/app"
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl neu-btn-square text-[#1d1d1f]/80 text-xs font-medium transition-all active:scale-95"
          >
            <Compass size={12} />
            <span>Explorer sur la Carte</span>
          </Link>
          {/* Créer dans AIME */}
          {article.actions.map((action, i) => (
            <Link
              key={i}
              href={action.route}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl neu-btn-square text-[#1d1d1f]/80 text-xs font-medium transition-all active:scale-95"
            >
              <span>{action.label}</span>
              <ArrowRight size={12} />
            </Link>
          ))}
        </div>
      </div>

      {/* ═══ YOUTUBE VIDEOS ═══ */}
      {youtubeVideos.length > 0 && (
        <div className="mx-6 sm:mx-10 mb-8">
          <h3 className="font-display text-sm uppercase tracking-wide text-[#1d1d1f]/50 mb-4">
            VIDEOS
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {youtubeVideos.map((video) => (
              <div key={video.videoId} className="rounded-xl overflow-hidden neu-convex-sm">
                {activeVideo === video.videoId ? (
                  <iframe
                    src={`https://www.youtube.com/embed/${video.videoId}?autoplay=1`}
                    className="w-full aspect-video"
                    allow="autoplay; encrypted-media"
                    allowFullScreen
                  />
                ) : (
                  <button
                    onClick={() => setActiveVideo(video.videoId)}
                    className="relative w-full group"
                  >
                    <img
                      src={video.thumbnail}
                      alt={video.title}
                      className="w-full aspect-video object-cover"
                    />
                    <div className="absolute inset-0 flex items-center justify-center bg-black/20 group-hover:bg-black/30 transition-colors">
                      <div className="w-12 h-12 rounded-full bg-white/90 flex items-center justify-center">
                        <div className="w-0 h-0 border-t-[8px] border-t-transparent border-l-[14px] border-l-[#1d1d1f] border-b-[8px] border-b-transparent ml-1" />
                      </div>
                    </div>
                    <div className="absolute bottom-0 left-0 right-0 p-2 bg-gradient-to-t from-black/60 to-transparent">
                      <p className="text-[11px] text-white font-medium line-clamp-2">{video.title}</p>
                      {video.channelTitle && <p className="text-[9px] text-white/70">{video.channelTitle}</p>}
                    </div>
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ═══ FREE PHOTOS ═══ */}
      {freePhotos.length > 0 && (
        <div className="mx-6 sm:mx-10 mb-8">
          <h3 className="font-display text-sm uppercase tracking-wide text-[#1d1d1f]/50 mb-4">
            GALERIE
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {freePhotos.map((photo, i) => (
              <a key={i} href={photo.source} target="_blank" rel="noopener noreferrer" className="rounded-xl overflow-hidden neu-convex-sm group">
                <div className="relative">
                  <img src={photo.url} alt={photo.alt} className="w-full h-32 sm:h-40 object-cover group-hover:scale-105 transition-transform duration-300" />
                  <div className="absolute bottom-0 left-0 right-0 p-1.5 bg-gradient-to-t from-black/50 to-transparent">
                    <p className="text-[9px] text-white/80 truncate">{photo.photographer}</p>
                  </div>
                </div>
              </a>
            ))}
          </div>
          <p className="mt-2 text-[9px] text-[#1d1d1f]/30 italic">Photos libres de droits — Unsplash</p>
        </div>
      )}

      {/* ═══ STRUCTURED DATA ═══ */}
      {structuredData.length > 0 && (
        <div className="mx-6 sm:mx-10 mb-8 p-5 rounded-2xl" style={{ background: '#ECF0F3', boxShadow: 'inset 4px 4px 8px #D1D9E6, inset -4px -4px 8px #FFFFFF' }}>
          <h3 className="font-display text-sm uppercase tracking-wide text-[#1d1d1f]/50 mb-4">
            DONNEES PRATIQUES
          </h3>
          <div className="space-y-2">
            {structuredData.map((item, i) => (
              <div key={i} className="flex items-start gap-3 px-3 py-2 rounded-xl neu-convex-sm">
                <span className="text-[10px] uppercase tracking-wider text-[#1d1d1f]/40 font-bold min-w-[60px]">
                  {item.type === 'price' ? 'Tarif' : item.type === 'schedule' ? 'Horaire' : item.type === 'link' ? 'Lien' : item.type === 'address' ? 'Adresse' : item.type === 'contact' ? 'Contact' : 'Info'}
                </span>
                <div className="flex flex-col min-w-0">
                  <span className="text-[12px] text-[#1d1d1f]/80 font-medium">{item.label}</span>
                  <span className="text-[11px] text-[#1d1d1f]/60">{item.value}</span>
                  <span className="text-[9px] text-[#1d1d1f]/30 italic">{item.source}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Sources & Inspirations */}
      {article.sources && article.sources.length > 0 && (
        <div className="mx-6 sm:mx-10 mb-8 p-5 rounded-2xl neu-inset">
          <h3 className="font-display text-sm uppercase tracking-wide text-[#1d1d1f]/50 mb-3">
            SOURCES & INSPIRATIONS
          </h3>
          <div className="space-y-2">
            {article.sources.map((source: any, i: number) => (
              <a
                key={i}
                href={source.url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 px-3 py-2 rounded-xl neu-convex-sm hover:scale-[1.01] transition-all"
              >
                <Globe size={12} className="text-[#1d1d1f]/40 shrink-0" />
                <div className="flex flex-col min-w-0">
                  <span className="text-[11px] text-[#1d1d1f]/80 font-medium truncate">{source.name}</span>
                  {source.role && (
                    <span className="text-[9px] uppercase tracking-wider text-[#1d1d1f]/30">{source.role.replace('_', ' ')}</span>
                  )}
                </div>
                <ExternalLink size={9} className="opacity-30 ml-auto shrink-0" />
              </a>
            ))}
          </div>
          <p className="mt-3 text-[9px] text-[#1d1d1f]/30 italic">
            Contenu original AIME® — synthétisé, reformulé et structuré à partir de sources publiques.
          </p>
        </div>
      )}

      {/* ═══ RECHERCHES SIMILAIRES + PROFILS MEMBRES ═══ */}
      <div className="mx-6 sm:mx-10 mb-8">
        <h3 className="font-display text-sm uppercase tracking-wide text-[#1d1d1f]/50 mb-4">
          D'AUTRES ONT CHERCHÉ LA MÊME CHOSE
        </h3>
        {/* Profils membres */}
        <div className="flex gap-3 overflow-x-auto pb-3 mb-4 scrollbar-hide">
          {[
            { name: "Sophie M.", avatar: "S", need: "Cherche traiteur bio", location: "Paris" },
            { name: "Lucas D.", avatar: "L", need: "DJ pour 200 personnes", location: "Lyon" },
            { name: "Amélie R.", avatar: "A", need: "Lieu atypique bord de mer", location: "Marseille" },
            { name: "Thomas B.", avatar: "T", need: "Photographe reportage", location: "Bordeaux" },
            { name: "Camille F.", avatar: "C", need: "Fleuriste éco-responsable", location: "Nantes" },
          ].map((member, i) => (
            <button
              key={i}
              onClick={() => toast.info(`${member.name} — ${member.need} (${member.location})`)}
              className="shrink-0 flex flex-col items-center gap-1.5 p-3 rounded-xl transition-all hover:scale-105"
              style={{ background: '#ECF0F3', boxShadow: '3px 3px 6px #D1D9E6, -3px -3px 6px #FFFFFF' }}
            >
              <div className="w-10 h-10 rounded-full bg-gray-300 flex items-center justify-center text-sm font-bold text-gray-600">
                {member.avatar}
              </div>
              <span className="text-[9px] font-semibold text-[#1d1d1f]/70 whitespace-nowrap">{member.name}</span>
              <span className="text-[8px] text-[#1d1d1f]/40 whitespace-nowrap max-w-[80px] truncate">{member.need}</span>
            </button>
          ))}
        </div>
        {/* Articles similaires */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {[
            { title: "Les meilleurs lieux de réception en bord de mer", category: "LIEUX", readers: 24 },
            { title: "Budget mariage : comment optimiser sans sacrifier", category: "BUDGET", readers: 18 },
            { title: "Tendances déco 2026 pour cérémonies en plein air", category: "INSPIRATIONS", readers: 31 },
          ].map((similar, i) => (
            <button
              key={i}
              onClick={() => toast.info(`Article : ${similar.title}`)}
              className="text-left p-4 rounded-xl transition-all hover:scale-[1.02]"
              style={{ background: '#ECF0F3', boxShadow: '3px 3px 6px #D1D9E6, -3px -3px 6px #FFFFFF' }}
            >
              <span className="text-[9px] uppercase tracking-wider text-gray-400 font-medium">{similar.category}</span>
              <p className="text-xs font-semibold text-[#1d1d1f]/80 mt-1 line-clamp-2">{similar.title}</p>
              <div className="flex items-center gap-1 mt-2">
                <Users size={10} className="text-gray-400" />
                <span className="text-[9px] text-gray-400">{similar.readers} lecteurs</span>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* ═══ MODE MAP CONTEXTUELLE ═══ */}
      {showMap && (
        <div className="mx-6 sm:mx-10 mb-8">
          <h3 className="font-display text-sm uppercase tracking-wide text-[#1d1d1f]/50 mb-4">
            CARTE DU RÉSEAU
          </h3>
          <div className="relative rounded-2xl overflow-hidden h-64 sm:h-80" style={{ background: '#E2E8F0', boxShadow: 'inset 3px 3px 6px #D1D9E6, inset -3px -3px 6px #FFFFFF' }}>
            {/* Simulated map with nodes and connections */}
            <svg className="w-full h-full" viewBox="0 0 400 300" fill="none">
              {/* Background grid */}
              <defs>
                <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
                  <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#CBD5E1" strokeWidth="0.3" />
                </pattern>
              </defs>
              <rect width="400" height="300" fill="url(#grid)" />
              {/* Connection lines (dashed) */}
              <line x1="120" y1="80" x2="250" y2="150" stroke="#94A3B8" strokeWidth="1" strokeDasharray="4 3" />
              <line x1="250" y1="150" x2="320" y2="90" stroke="#94A3B8" strokeWidth="1" strokeDasharray="4 3" />
              <line x1="120" y1="80" x2="80" y2="200" stroke="#94A3B8" strokeWidth="1" strokeDasharray="4 3" />
              <line x1="250" y1="150" x2="180" y2="240" stroke="#94A3B8" strokeWidth="1" strokeDasharray="4 3" />
              <line x1="320" y1="90" x2="350" y2="220" stroke="#94A3B8" strokeWidth="1" strokeDasharray="4 3" />
              <line x1="80" y1="200" x2="180" y2="240" stroke="#94A3B8" strokeWidth="1" strokeDasharray="4 3" />
              {/* Location nodes */}
              <circle cx="120" cy="80" r="8" fill="#1d1d1f" opacity="0.7" />
              <text x="120" y="105" textAnchor="middle" className="text-[8px]" fill="#1d1d1f" opacity="0.6" fontSize="8">Paris</text>
              <circle cx="250" cy="150" r="10" fill="#1d1d1f" opacity="0.8" />
              <text x="250" y="175" textAnchor="middle" fill="#1d1d1f" opacity="0.6" fontSize="8">Lieu</text>
              <circle cx="320" cy="90" r="7" fill="#1d1d1f" opacity="0.6" />
              <text x="320" y="115" textAnchor="middle" fill="#1d1d1f" opacity="0.6" fontSize="8">Lyon</text>
              <circle cx="80" cy="200" r="6" fill="#1d1d1f" opacity="0.5" />
              <text x="80" y="225" textAnchor="middle" fill="#1d1d1f" opacity="0.6" fontSize="8">Nantes</text>
              <circle cx="180" cy="240" r="7" fill="#1d1d1f" opacity="0.6" />
              <text x="180" y="265" textAnchor="middle" fill="#1d1d1f" opacity="0.6" fontSize="8">Bordeaux</text>
              <circle cx="350" cy="220" r="6" fill="#1d1d1f" opacity="0.5" />
              <text x="350" y="245" textAnchor="middle" fill="#1d1d1f" opacity="0.6" fontSize="8">Marseille</text>
              {/* Person nodes (smaller, different style) */}
              <circle cx="140" cy="130" r="5" fill="#6366F1" opacity="0.7" />
              <circle cx="280" cy="120" r="5" fill="#6366F1" opacity="0.7" />
              <circle cx="200" cy="190" r="5" fill="#6366F1" opacity="0.7" />
              <circle cx="100" cy="160" r="5" fill="#6366F1" opacity="0.7" />
              <circle cx="300" cy="180" r="5" fill="#6366F1" opacity="0.7" />
            </svg>
            {/* Legend */}
            <div className="absolute bottom-3 left-3 flex items-center gap-4 bg-white/80 backdrop-blur-sm rounded-lg px-3 py-1.5">
              <div className="flex items-center gap-1.5">
                <div className="w-2.5 h-2.5 rounded-full bg-[#1d1d1f]/70" />
                <span className="text-[8px] text-gray-600">Lieux</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-2.5 h-2.5 rounded-full bg-indigo-500/70" />
                <span className="text-[8px] text-gray-600">Membres</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-4 border-t border-dashed border-gray-400" />
                <span className="text-[8px] text-gray-600">Connexions</span>
              </div>
            </div>
          </div>
          <p className="text-[9px] text-center text-[#1d1d1f]/30 mt-2 italic">
            Réseau de personnes et lieux liés à cette recherche
          </p>
        </div>
      )}

      {/* Footer */}
      <div className="px-6 sm:px-10 py-6 flex items-center justify-between" style={{ boxShadow: 'inset 0 1px 3px #D1D9E6' }}>
        <div className="flex items-center gap-2">
          <AimeLogo size={14} />
          <span className="text-[10px] uppercase tracking-[0.15em] text-[#1d1d1f]/30">Magazine AIME®</span>
        </div>
        <Link
          href="/app"
          className="text-xs text-[#1d1d1f]/60 font-medium hover:text-[#1d1d1f] transition-colors flex items-center gap-1"
        >
          Ouvrir l'app <ArrowRight size={12} />
        </Link>
      </div>
    </article>
  );
}
