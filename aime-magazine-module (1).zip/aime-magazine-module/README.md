# AIME® Magazine Module

Module complet de génération d'articles magazine via IA (LLM).

## Structure

```
backend/
  magazine-router.ts          # Procédures tRPC (search, generateImages, searchYouTube, searchPhotos, editions, etc.)
  magazine-system-prompt.ts   # Prompt système pour le LLM
  magazine-helpers.ts         # Fonctions utilitaires (tryExtractResponse, etc.)

frontend/
  MagazinePage.tsx           # Composant React complet avec UI
```

## Procédures tRPC disponibles

### `magazine.search`
Génère un article complet sur un sujet.

**Input:**
```ts
{
  query: string;           // Sujet de l'article (ex: "Mariage en Provence")
  category?: string;       // Catégorie optionnelle
  lang?: string;           // Langue (fr, en, es, it, de, pt)
}
```

**Output:**
```ts
{
  article: {
    title: string;
    subtitle: string;
    chapo: string;
    category: string;
    body: { heading: string; text: string }[];
    practical_info: { label: string; value: string }[];
    key_points: string[];
    actions: { label: string; route: string }[];
    image_prompt: string;
    sources?: { name: string; url: string; role?: string }[];
    section_images?: { section_index: number; description: string; alt: string }[];
    providers?: { name: string; category: string; city: string; priceRange: string; description: string; section_index: number }[];
    suggested_modules?: { module: string; label: string; context: string; section_index: number }[];
    youtube_keywords?: string[];
    photo_keywords?: string[];
    structured_data?: { type: string; label: string; value: string; source: string }[];
  };
  generatedAt: string;
  relatedArticles?: any[];
}
```

### Autres procédures
- `magazine.generateImages` — Génère les images (cover + sections)
- `magazine.searchYouTube` — Cherche des vidéos YouTube pertinentes
- `magazine.searchPhotos` — Cherche des photos libres (Unsplash, Pexels)
- `magazine.editions` — Liste les articles archivés par date
- `magazine.recent` — Récupère les articles récents
- `magazine.editionArticles` — Récupère les articles d'une édition spécifique
- `magazine.magazineChat` — Chat conversationnel pour affiner la recherche

## Intégration rapide

### Backend
1. Importer le `magazineRouter` dans `server/routers.ts`
2. Ajouter à l'`appRouter` : `magazine: magazineRouter`
3. S'assurer que `invokeLLM` est disponible (helper Manus)
4. S'assurer que la DB a les tables : `magazine_articles`, `magazine_editions`

### Frontend
1. Importer `MagazinePage` dans `App.tsx`
2. Ajouter la route : `<Route path="/magazine" component={MagazinePage} />`
3. S'assurer que `trpc` et `sonner` sont disponibles

## Dépendances

**Backend:** trpc, zod, Manus LLM API, Database (Drizzle ORM)
**Frontend:** React 19+, wouter, lucide-react, sonner, trpc

## Crédits

Chaque recherche consomme des crédits utilisateur (configurable dans `CREDIT_COSTS`).

## Notes

- Les articles sont sauvegardés en DB pour les archives
- Les images sont générées en parallèle (background)
- Les vidéos YouTube et photos libres sont cherchées automatiquement
- Le système supporte le multi-langue
- Les prestataires suggérés sont intégrés dans chaque article
