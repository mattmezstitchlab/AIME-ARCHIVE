function tryExtractResponse(content: string): string | null {
  try {
    const parsed = JSON.parse(content);
    return parsed.response || null;
  } catch {
    return null;
  }
}

async function updateSpacesFromParsed(weddingId: number, parsed: any) {
  // Update Couple space
  if (parsed.ambiance?.length || parsed.partnerName) {
    const data = JSON.stringify({ ambiance: parsed.ambiance, partnerName: parsed.partnerName });
    await db.upsertSpace(weddingId, "couple", data, "in_progress");
  }

  // Update Invités space
  if (parsed.guestCount) {
    const data = JSON.stringify({ guestCount: parsed.guestCount });
    await db.upsertSpace(weddingId, "invites", data, "in_progress");
