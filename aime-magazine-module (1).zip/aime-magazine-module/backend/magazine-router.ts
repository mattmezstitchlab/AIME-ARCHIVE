const MAGAZINE_SYSTEM_PROMPT = `Tu es le rédacteur en chef du Magazine AIME®. Tu produis du contenu éditorial ORIGINAL, structuré et utile.

MISSION :
- Transformer une recherche (ville, thème, mot-clé, intention) en article éditorial premium
- Synthétiser, reformuler, structurer et rendre actionnable. JAMAIS copier de paragraphes externes.
- Relier chaque sujet à une action possible dans l'écosystème AIME®
- Extraire la ville/région, le domaine thématique, le thème principal et des tags pertinents

DOMAINES : Mariage, Lieux, Prestataires, Budget, Inspirations, Accessibilité, Solidarité, Intermittents du spectacle, Administratif, Carte Vivante, LUMEN (entraide), Histoires humaines

SOURCES & INSPIRATIONS :
- Citer 3 à 8 sources web de référence utilisées pour composer l'article
- Pour chaque source : nom du site, URL, et rôle (inspiration, vérification, contexte, ressource_pratique)
- Exemples : Zankyou, The Knot, Mariage.net, WeddingWire, Vogue Weddings, Martha Stewart Weddings, Un Beau Jour, La Mariée aux Pieds Nus, etc.

IMAGES :
- Décrire précisément l'image idéale pour la couverture (image_prompt) et pour chaque section (section_images)
- Les descriptions serviront à générer des images par IA. Sois précis : ambiance, couleurs, composition, sujets.
- NE JAMAIS fournir d'URL d'images existantes.

SUJETS SENSIBLES :
- Si le sujet touche au droit, à la santé, à l'administratif, à la précarité ou aux finances : ajouter dans practical_info un item avec label "Mention importante" et value "Ce contenu est une aide d'organisation et d'information. Pour toute décision importante, vérifiez auprès des organismes compétents."

STYLE ÉDITORIAL :
- Ton professionnel, chaleureux, jamais commercial
- Phrases claires et aérées
- Informations vérifiables et utiles
- Toujours proposer des actions concrètes
- Si le sujet touche à la solidarité ou l'accessibilité, être respectueux et inclusif

MEDIAS :
- Génère des mots-clés YouTube pertinents (youtube_keywords) pour trouver des vidéos en rapport avec le sujet (3-5 mots-clés de recherche)
- Génère des mots-clés photos (photo_keywords) pour trouver des images libres de droits pertinentes (3-5 termes)
- Si le sujet implique des tarifs, horaires, transports, hébergements ou comparatifs : remplis structured_data avec des données concrètes (prix, liens, horaires, noms)
MODULES CONTEXTUELS :
- L'application dispose de 4 modules fonctionnels : dossier (documents, devis, contrats), agenda (événements, RDV, dates), kiosque (articles sauvegardés), playlist (vidéos, musiques)
- Pour chaque article, indique quels modules sont pertinents et à quelle section les afficher
- Exemples : un prestataire mentionné → module "dossier" ("Demander un devis"), un événement avec date → module "agenda" ("Ajouter au calendrier"), une vidéo → module "playlist" ("Ajouter à ma playlist")
- Génère 2 à 6 suggested_modules par article, répartis sur différentes sections
PRESTATAIRES & DEVIS :
- Si le sujet mentionne ou implique des prestataires (photographe, traiteur, DJ, fleuriste, lieu, décorateur, vidéaste, etc.), génère un tableau de prestataires suggérés dans le champ "providers"
- Chaque prestataire : name (nom réaliste ou générique type "Photographe recommandé"), category (photographe|traiteur|fleuriste|dj|videaste|lieu|decorateur|patissier|musicien|officiant|autre), city (ville si pertinent, sinon chaîne vide), priceRange (fourchette estimée ex: "1500-3000€"), description (1-2 phrases sur le service proposé), section_index (index section body où le prestataire est pertinent, 0-based)
- Génère 2 à 5 prestataires par article quand le sujet s'y prête (mariage, événement, lieu, budget, prestataires)
- Si le sujet n'implique pas de prestataires (voyage pur, culture, administratif), retourne un tableau vide
PHILOSOPHIE : Chaque recherche devient un article. Chaque article peut devenir une action. Chaque action enrichit AIME. Le magazine est un moteur de synthèse universelle : il prend le meilleur d'internet sur n'importe quel sujet et le restructure en une page magazine propre, légale et actionnable.`;

const magazineRouter = router({
  search: publicProcedure.input(z.object({
    query: z.string().min(1).max(200),
    category: z.string().optional(),
    lang: z.string().optional().default("fr"),
  })).mutation(async ({ input }) => {
    const categoryHint = input.category ? `Catégorie : ${input.category}. ` : "";
    const langHint = input.lang !== "fr" ? `\nLANGUE : Rédige l'article en ${input.lang === "en" ? "anglais" : input.lang === "es" ? "espagnol" : input.lang === "it" ? "italien" : input.lang === "de" ? "allemand" : input.lang === "pt" ? "portugais" : input.lang}. Adapte culturellement le contenu.` : "";
    const response = await invokeLLM({
      messages: [
        { role: "system", content: MAGAZINE_SYSTEM_PROMPT + langHint },
        { role: "user", content: `${categoryHint}Recherche : "${input.query}"

Génère un article éditorial complet et structuré sur ce sujet. L'article doit être original, informatif et actionnable. Inclus des informations pratiques concrètes, des conseils, et des suggestions d'actions dans AIME®.` },
      ],
      response_format: {
        type: "json_schema",
        json_schema: {
          name: "magazine_article",
          strict: true,
          schema: {
            type: "object",
            properties: {
              title: { type: "string", description: "Grand titre éditorial accrocheur" },
              subtitle: { type: "string", description: "Sous-titre ou angle de l'article" },
              chapo: { type: "string", description: "Chapô : 2-3 phrases d'introduction percutantes" },
              category: { type: "string", description: "Catégorie principale (Mariage, Lieux, Prestataires, Budget, Inspirations, Accessibilité, Solidarité, Intermittents, Administratif, Carte Vivante, LUMEN, Histoires humaines)" },
              domain: { type: "string", description: "Domaine thématique (mariage, spectacle, solidarité, administratif, inspiration, budget, lieu, prestataire)" },
              main_theme: { type: "string", description: "Thème principal en 2-4 mots (ex: Mariage en Provence, Budget Traiteur, DJ Intermittent)" },
              city: { type: "string", description: "Ville ou région mentionnée si pertinent, sinon chaîne vide" },
              tags: { type: "array", description: "5-10 mots-clés pour le référencement et les articles connexes", items: { type: "string" } },
              body: {
                type: "array",
                description: "Corps de l'article : paragraphes éditoriaux",
                items: {
                  type: "object",
                  properties: {
                    heading: { type: "string", description: "Titre de section" },
                    text: { type: "string", description: "Contenu du paragraphe (markdown léger autorisé)" },
                  },
                  required: ["heading", "text"],
                  additionalProperties: false,
                },
              },
              practical_info: {
                type: "array",
                description: "Encadrés pratiques (infos clés, chiffres, contacts, liens)",
                items: {
                  type: "object",
                  properties: {
                    label: { type: "string" },
                    value: { type: "string" },
                  },
                  required: ["label", "value"],
                  additionalProperties: false,
                },
              },
              key_points: {
                type: "array",
                description: "3-5 points clés à retenir",
                items: { type: "string" },
              },
              actions: {
                type: "array",
                description: "Suggestions d'actions dans AIME®",
                items: {
                  type: "object",
                  properties: {
                    label: { type: "string", description: "Texte du bouton d'action" },
                    route: { type: "string", description: "Route dans l'app AIME (/app)" },
                  },
                  required: ["label", "route"],
                  additionalProperties: false,
                },
              },
              image_prompt: { type: "string", description: "Description d'image idéale pour la couverture de l'article (pour génération future)" },
              sources: {
                type: "array",
                description: "3-8 sources web de référence utilisées pour composer l'article",
                items: {
                  type: "object",
                  properties: {
                    name: { type: "string", description: "Nom du site/média" },
                    url: { type: "string", description: "URL du site ou de l'article" },
                    role: { type: "string", description: "Rôle de la source : inspiration, verification, contexte, ressource_pratique" },
                  },
                  required: ["name", "url", "role"],
                  additionalProperties: false,
                },
              },
              section_images: {
                type: "array",
                description: "Description d'images pour chaque section du body (1 image par section). Décris précisément l'image idéale.",
                items: {
                  type: "object",
                  properties: {
                    section_index: { type: "number", description: "Index de la section body (0-based)" },
                    description: { type: "string", description: "Description précise de l'image idéale pour cette section" },
                    alt: { type: "string", description: "Texte alternatif de l'image" },
                  },
                  required: ["section_index", "description", "alt"],
                  additionalProperties: false,
                },
              },
              youtube_keywords: {
                type: "array",
                description: "3-5 mots-clés de recherche YouTube pour trouver des vidéos pertinentes sur le sujet",
                items: { type: "string" },
              },
              photo_keywords: {
                type: "array",
                description: "3-5 termes de recherche pour trouver des photos libres de droits (Unsplash/Pexels)",
                items: { type: "string" },
              },
              structured_data: {
                type: "array",
                description: "Données structurées : tarifs, horaires, liens de réservation, comparatifs, adresses. Vide si non pertinent.",
                items: {
                  type: "object",
                  properties: {
                    type: { type: "string", description: "Type: price, schedule, link, comparison, address, contact" },
                    label: { type: "string", description: "Libellé de la donnée" },
                    value: { type: "string", description: "Valeur (prix, horaire, URL, adresse...)" },
                    source: { type: "string", description: "Source de la donnée (nom du site)" },
                  },
                  required: ["type", "label", "value", "source"],
                  additionalProperties: false,
                },
              },
              suggested_modules: {
                type: "array",
                description: "Modules fonctionnels pertinents pour cet article. Chaque module indique une fonctionnalité utile (dossier, agenda, kiosque, playlist) avec un label et une action suggérée.",
                items: {
                  type: "object",
                  properties: {
                    module: { type: "string", description: "Type de module: dossier, agenda, kiosque, playlist" },
                    label: { type: "string", description: "Texte court décrivant l'action (ex: 'Ajouter ce devis', 'Planifier la visite', 'Sauvegarder l'article')" },
                    context: { type: "string", description: "Info contextuelle (ex: nom du prestataire, date suggérée, titre de la playlist)" },
                    section_index: { type: "integer", description: "Index de la section body où afficher ce module (0-based)" },
                  },
                  required: ["module", "label", "context", "section_index"],
                  additionalProperties: false,
                },
              },
              providers: {
                type: "array",
                description: "Prestataires suggérés en rapport avec le sujet de l'article. 2-5 prestataires si pertinent, tableau vide sinon.",
                items: {
                  type: "object",
                  properties: {
                    name: { type: "string", description: "Nom du prestataire (réaliste ou générique)" },
                    category: { type: "string", description: "Catégorie: photographe, traiteur, fleuriste, dj, videaste, lieu, decorateur, patissier, musicien, officiant, autre" },
                    city: { type: "string", description: "Ville si pertinent, sinon chaîne vide" },
                    priceRange: { type: "string", description: "Fourchette de prix estimée (ex: 1500-3000€)" },
                    description: { type: "string", description: "1-2 phrases décrivant le service proposé" },
                    section_index: { type: "integer", description: "Index de la section body où ce prestataire est pertinent (0-based)" },
                  },
                  required: ["name", "category", "city", "priceRange", "description", "section_index"],
                  additionalProperties: false,
                },
              },
            },
            required: ["title", "subtitle", "chapo", "category", "domain", "main_theme", "city", "tags", "body", "practical_info", "key_points", "actions", "image_prompt", "sources", "section_images", "youtube_keywords", "photo_keywords", "structured_data", "suggested_modules", "providers"],
            additionalProperties: false,
          },
        },
      },
    });
    try {
      const content = (response.choices?.[0]?.message?.content || "{}") as string;
      const article = JSON.parse(content);
      const generatedAt = new Date().toISOString();
      const now = new Date();
      const editionDate = now.toISOString().slice(0, 10);
      const editionNumber = Math.floor((now.getTime() - new Date("2024-01-01").getTime()) / (1000 * 60 * 60 * 24));
      // Generate slug from title
      const slug = (article.title || "")
        .toLowerCase()
        .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/^-|-$/g, "")
        .slice(0, 200);
      // Save to DB for archives
      try {
        // Generate cover image immediately for archives
        let coverUrl: string | null = null;
        try {
          const coverResult = await generateImage({
            prompt: `${article.image_prompt || article.title}. Style: editorial magazine cover, elegant, high quality photography, soft lighting`,
          });
          coverUrl = coverResult.url || null;
        } catch (imgErr) {
          console.warn("[Magazine] Cover image generation failed:", imgErr);
        }
        const articleId = await db.createMagazineArticle({
          title: article.title,
          slug,
          subtitle: article.subtitle,
          chapo: article.chapo,
          category: article.category,
          tags: article.tags || [],
          domain: article.domain || "",
          temporalMode: "present",
          mainTheme: article.main_theme || "",
          city: article.city || "",
          body: article.body,
          practicalInfo: article.practical_info,
          keyPoints: article.key_points,
          actions: article.actions,
          imagePrompt: article.image_prompt,
          coverImageUrl: coverUrl,
          sources: article.sources || [],
          sectionImages: article.section_images || [],
          searchQuery: input.query,
          editionDate,
          editionNumber,
        });
        // Get related articles (same category or matching tags)
        const related = await db.getRelatedArticles(article.category, articleId, 5);
        return { article, generatedAt, articleId, relatedArticles: related };
      } catch (saveErr) {
        console.warn("[Magazine] Failed to save article:", saveErr);
        return { article, generatedAt, articleId: null, relatedArticles: [] };
      }
    } catch {
      throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Impossible de g\u00e9n\u00e9rer l'article" });
    }
  }),

  // Generate images for article sections
  generateImages: publicProcedure.input(z.object({
    imagePrompt: z.string(),
    sectionImages: z.array(z.object({
      section_index: z.number(),
      description: z.string(),
      alt: z.string(),
    })),
  })).mutation(async ({ input }) => {
    const results: { coverUrl?: string; sections: { index: number; url: string; alt: string }[] } = {
      coverUrl: undefined,
      sections: [],
    };

    // Generate cover image
    try {
      const coverResult = await generateImage({
        prompt: `${input.imagePrompt}. Style: editorial magazine cover, elegant, high quality photography, soft lighting`,
      });
      results.coverUrl = coverResult.url;
    } catch (err) {
      console.warn("[Magazine] Cover image generation failed:", err);
    }

    // Generate section images (in parallel, max 3 at a time)
    const sectionPromises = input.sectionImages.slice(0, 4).map(async (section) => {
      try {
        const result = await generateImage({
          prompt: `${section.description}. Style: editorial illustration, elegant, magazine quality, soft natural lighting`,
        });
        return { index: section.section_index, url: result.url || "", alt: section.alt };
      } catch (err) {
        console.warn(`[Magazine] Section ${section.section_index} image failed:`, err);
        return null;
      }
    });

    const sectionResults = await Promise.all(sectionPromises);
    results.sections = sectionResults.filter((r): r is { index: number; url: string; alt: string } => r !== null && !!r.url);

    return results;
  }),

  // Get archives (editions grouped by day)
  editions: publicProcedure.query(async () => {
    return db.getMagazineEditions();
  }),

  // Get articles for a specific edition date
  editionArticles: publicProcedure.input(z.object({
    editionDate: z.string(),
  })).query(async ({ input }) => {
    return db.getMagazineArchivesByDate(input.editionDate);
  }),

  // Get related articles by category
  related: publicProcedure.input(z.object({
    category: z.string(),
    excludeId: z.number().optional(),
  })).query(async ({ input }) => {
    return db.getRelatedArticles(input.category, input.excludeId, 5);
  }),

  // Get all recent articles for browsing
  recent: publicProcedure.input(z.object({
    limit: z.number().min(1).max(100).default(20),
    offset: z.number().min(0).default(0),
  }).optional()).query(async ({ input }) => {
    const limit = input?.limit ?? 20;
    const offset = input?.offset ?? 0;
    return db.getMagazineArchives(limit, offset);
  }),
  // Search YouTube videos by keywords
  searchYouTube: publicProcedure.input(z.object({
    keywords: z.array(z.string()).min(1).max(5),
    maxResults: z.number().min(1).max(10).default(4),
  })).mutation(async ({ input }) => {
    const results: { videoId: string; title: string; thumbnail: string; channelTitle: string }[] = [];
    for (const keyword of input.keywords.slice(0, 3)) {
      try {
        const searchUrl = `https://www.youtube.com/results?search_query=${encodeURIComponent(keyword)}&sp=EgIQAQ%3D%3D`;
        const resp = await fetch(searchUrl, { headers: { 'User-Agent': 'Mozilla/5.0 (compatible; AIMEBot/1.0)' } });
        const html = await resp.text();
        // Extract video IDs from YouTube search results HTML
        const videoMatches = html.match(/"videoId":"([a-zA-Z0-9_-]{11})"/g) || [];
        const seen = new Set(results.map(r => r.videoId));
        for (const match of videoMatches.slice(0, 3)) {
          const id = match.match(/"videoId":"([a-zA-Z0-9_-]{11})"/)?.[1];
          if (id && !seen.has(id)) {
            seen.add(id);
            // Extract title from nearby context
            const titleMatch = html.match(new RegExp(`"videoId":"${id}"[^}]*"title":\{"runs":\[\{"text":"([^"]+)"`));
            const channelMatch = html.match(new RegExp(`"videoId":"${id}"[^}]*"ownerText":\{"runs":\[\{"text":"([^"]+)"`));
            results.push({
              videoId: id,
              title: titleMatch?.[1] || keyword,
              thumbnail: `https://img.youtube.com/vi/${id}/mqdefault.jpg`,
              channelTitle: channelMatch?.[1] || '',
            });
          }
        }
      } catch (err) {
        console.warn(`[Magazine] YouTube search failed for "${keyword}":`, err);
      }
    }
    return results.slice(0, input.maxResults);
  }),
  // Search free photos (Unsplash)
  searchPhotos: publicProcedure.input(z.object({
    keywords: z.array(z.string()).min(1).max(5),
    maxResults: z.number().min(1).max(8).default(4),
  })).mutation(async ({ input }) => {
    const results: { url: string; alt: string; photographer: string; source: string }[] = [];
    for (const keyword of input.keywords.slice(0, 3)) {
      try {
        // Use Unsplash source (no API key needed for random photos)
        const searchUrl = `https://unsplash.com/napi/search/photos?query=${encodeURIComponent(keyword)}&per_page=3`;
        const resp = await fetch(searchUrl, { headers: { 'Accept': 'application/json' } });
        if (resp.ok) {
          const data = await resp.json() as any;
          const photos = data?.results || [];
          for (const photo of photos) {
            results.push({
              url: photo.urls?.regular || photo.urls?.small || '',
              alt: photo.alt_description || keyword,
              photographer: photo.user?.name || 'Unknown',
              source: `https://unsplash.com/photos/${photo.id}`,
            });
          }
        }
      } catch (err) {
        console.warn(`[Magazine] Photo search failed for "${keyword}":`, err);
      }
    }
    return results.slice(0, input.maxResults);
  }),
});

// ─── AIME® Landing Agent Router (Proactive) ──────────────────────────────────
const AIME_LANDING_PROMPT = `Tu es AIME, assistante intelligente pour l'organisation d'evenements. Tu es chaleureuse, directe et professionnelle.
Ton ton : Simple, clair, bienveillant. Tu vouvoies par defaut. PAS d'emoticones, PAS de :coeur: :bulle: ou autre. Texte simple uniquement.
Contexte : L'utilisateur vient d'arriver sur la plateforme AIME.
Tes missions :
1. Comprendre ce que la personne cherche (mariage, evenement, prestation)
2. Poser des questions pertinentes pour cerner le projet
3. Guider vers les bonnes ressources
REGLES : 2-3 phrases max. Pas d'emoticones. Pas de :coeur: :bulle: :clin: etc. Texte simple et professionnel. Finis par une question.`;

const AIME_MAGAZINE_PROMPT = `Tu es AIME, redactrice en chef du Magazine AIME. Tu es fun, creative, curieuse et bienveillante.
Ton ton : Decontracte mais intelligent. Tu tutoies. Tu peux etre drole quand c'est pertinent. PAS d'emoticones.
Contexte : L'utilisateur veut generer un article/magazine sur un sujet. Tu dois l'aider a affiner sa demande avant de lancer la generation.

Ton flow de conversation :
1. COMPRENDRE : Pose 1-2 questions pour cerner le sujet (lieu ? date ? budget ? style ? angle ?)
2. PROPOSER : Suggere des angles ou sections a ajouter ("Tu veux que j'ajoute une section tarifs ?" / "Je pourrais chercher des videos sur le sujet, ca t'interesse ?")
3. RECAPITULER : Quand tu as assez d'infos (apres 2-3 echanges), presente un SOMMAIRE de ce que tu vas rediger. Utilise ce format :
   "Voici ce que j'ai prepare :\n1. [Titre section 1]\n2. [Titre section 2]\n3. [Titre section 3]\n...\nTu veux que je lance la generation ?"
4. CONFIRMER : Attends le "oui" / "go" / "lance" / "ok" de l'utilisateur avant d'inclure [GENERATE]

REGLES IMPORTANTES :
- 2-4 phrases max par reponse
- Pas d'emoticones, pas de :coeur: :bulle: etc.
- Sois fun et decontracte mais pertinent
- Propose toujours des idees supplementaires (videos, photos, tarifs, comparatifs...)
- Quand l'utilisateur confirme, reponds avec [GENERATE] suivi du sujet final optimise pour la recherche
  Exemple : "C'est parti ! [GENERATE] mariage boheme Provence juin 2026 budget 30000"
- Ne genere JAMAIS [GENERATE] sans confirmation explicite de l'utilisateur
- Si l'utilisateur dit directement "genere" ou "lance" des le premier message avec un sujet clair, tu peux proposer le sommaire et demander confirmation en une seule reponse

PERSONNALITE EQUIPE :
Tu fais partie d'une equipe de redaction. Quand un sujet necessite une expertise specifique, tu peux dire des choses comme :
- "Attend, cette partie la c'est mon collegue des finances, je lui demande..."
- "Notre correspondant local va verifier ca pour toi"
- "Je passe le relais a notre specialiste video pour cette section"
- "Mon collegue photographe me dit que..."
Ca rend la conversation vivante, comme une vraie redaction de magazine avec des specialistes. Utilise ca de temps en temps (pas a chaque message).

FLOW DE GENERATION (quand l'utilisateur confirme) :
Avant d'envoyer [GENERATE], fais une transition naturelle style :
- "Ok c'est bon, je passe ca a mon collegue. Il redige et me l'envoie, je te transmets ici..."
- "Parfait, je lance l'equipe dessus. Mon redacteur s'en occupe, tu vas recevoir ca ici dans un instant."
- "Top ! Mon collegue specialiste prend le relais, il redige tout et je te transmets des que c'est pret."
Puis inclus [GENERATE] a la fin de ta reponse.`;

const aimeAgentRouter = router({
  chat: publicProcedure
    .input(z.object({
      message: z.string().min(1).max(1000),
      history: z.array(z.object({ role: z.enum(["user", "assistant"]), content: z.string() })).optional().default([]),
      context: z.object({ isFirstVisit: z.boolean().optional(), page: z.string().optional() }).optional(),
    }))
    .mutation(async ({ input }) => {
      const msgs: Array<{ role: "system" | "user" | "assistant"; content: string }> = [
        { role: "system", content: AIME_LANDING_PROMPT },
      ];
      for (const m of input.history.slice(-10)) msgs.push({ role: m.role, content: m.content });
      msgs.push({ role: "user", content: input.message });
      try {
        const resp = await invokeLLM({ messages: msgs });
        const content = resp.choices?.[0]?.message?.content;
        const text = typeof content === "string" ? content : "Je suis la. Dis-moi tout !";
        const isFeedback = /bug|probl[e\u00e8]me|suggestion|id[\u00e9e]e|am[\u00e9e]liorer|manque|erreur|crash/i.test(input.message);
        if (isFeedback) {
          try {
            await db.createFeedback({ type: "suggestion", message: input.message, page: input.context?.page || "landing" });
            const { notifyOwner } = await import("./_core/notification");
            await notifyOwner({ title: "[AIME Agent] Feedback landing", content: input.message });
          } catch (e) { /* silent */ }
        }
        return { response: text, isFeedback };
      } catch (error) {
        return { response: "He, je suis la. Mon cerveau a eu un petit bug. Redis-moi ?", isFeedback: false };
      }
    }),

