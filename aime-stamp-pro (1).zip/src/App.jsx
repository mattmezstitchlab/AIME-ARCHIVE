import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import Home from '@/pages/Home';
import Showroom from '@/pages/Showroom';
import Universe from '@/pages/Universe';
import Verify from '@/pages/Verify';
import Wallet from '@/pages/Wallet';
import Planning from '@/pages/Planning';
import Budget from '@/pages/Budget';
import Concierge from '@/pages/Concierge';
import Book from '@/pages/Book';
// Add page imports here

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  return (
    <Routes>
      <Route path="/" element={<Showroom />} />
      <Route path="/stamps" element={<Home />} />
      <Route path="/universe/:id" element={<Universe />} />
      <Route path="/wallet" element={<Wallet />} />
      <Route path="/planning" element={<Planning />} />
      <Route path="/budget" element={<Budget />} />
      <Route path="/concierge" element={<Concierge />} />
      <Route path="/book" element={<Book />} />
      <Route path="/verify/:code" element={<Verify />} />
      {/* Add your page Route elements here */}
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App