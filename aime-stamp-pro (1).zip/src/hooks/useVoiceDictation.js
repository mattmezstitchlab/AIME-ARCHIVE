import { useEffect, useRef, useState } from "react";

/**
 * Hook for voice dictation using the Web Speech API.
 * Returns { supported, listening, transcript, start, stop, reset }
 */
export default function useVoiceDictation({ lang = "fr-FR" } = {}) {
  const recognitionRef = useRef(null);
  const [supported, setSupported] = useState(false);
  const [listening, setListening] = useState(false);
  const [transcript, setTranscript] = useState("");

  useEffect(() => {
    const SR =
      typeof window !== "undefined" &&
      (window.SpeechRecognition || window.webkitSpeechRecognition);
    if (!SR) return;
    setSupported(true);
    const rec = new SR();
    rec.lang = lang;
    rec.continuous = false;
    rec.interimResults = true;
    rec.onresult = (e) => {
      let txt = "";
      for (let i = 0; i < e.results.length; i++) {
        txt += e.results[i][0].transcript;
      }
      setTranscript(txt);
    };
    rec.onend = () => setListening(false);
    rec.onerror = () => setListening(false);
    recognitionRef.current = rec;
    return () => {
      try {
        rec.stop();
      } catch {}
    };
  }, [lang]);

  const start = () => {
    if (!recognitionRef.current || listening) return;
    setTranscript("");
    try {
      recognitionRef.current.start();
      setListening(true);
    } catch {}
  };

  const stop = () => {
    if (!recognitionRef.current) return;
    try {
      recognitionRef.current.stop();
    } catch {}
    setListening(false);
  };

  const reset = () => setTranscript("");

  return { supported, listening, transcript, start, stop, reset };
}