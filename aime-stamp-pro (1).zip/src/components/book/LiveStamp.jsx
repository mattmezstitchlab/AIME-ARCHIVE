import React from "react";
import { motion } from "framer-motion";
import { Sparkles, CheckCircle2, FileText, CreditCard } from "lucide-react";

const STAGES = {
  draft:     { ring: "ring-white/20",       glow: "shadow-white/10",   label: "Brouillon",     Icon: Sparkles,     color: "text-white/70" },
  quote:     { ring: "ring-amber-300/40",   glow: "shadow-amber-400/20", label: "Devis",       Icon: FileText,      color: "text-amber-200" },
  paid:      { ring: "ring-emerald-300/50", glow: "shadow-emerald-400/30", label: "Payé",     Icon: CreditCard,    color: "text-emerald-200" },
  confirmed: { ring: "ring-emerald-400/70", glow: "shadow-emerald-400/40", label: "Validé",   Icon: CheckCircle2,  color: "text-emerald-300" },
};

export default function LiveStamp({ booking, status = "draft" }) {
  const stage = STAGES[status] || STAGES.draft;
  const Icon = stage.Icon;
  const date = booking?.event_date
    ? new Date(booking.event_date).toLocaleDateString("fr-FR", { day: "2-digit", month: "long", year: "numeric" })
    : "—";

  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.85, rotate: -8 }}
      animate={{ opacity: 1, scale: 1, rotate: -3 }}
      transition={{ type: "spring", stiffness: 220, damping: 18 }}
      className="relative w-full max-w-sm aspect-[3/4] mx-auto"
    >
      <motion.div
        animate={{ rotate: status === "confirmed" ? -2 : -3 }}
        className={`relative w-full h-full bg-gradient-to-br from-stone-100 to-stone-200 rounded-lg ring-2 ${stage.ring} shadow-2xl ${stage.glow}`}
        style={{
          maskImage:
            "radial-gradient(circle at 6px 6px, transparent 4px, black 4.5px), radial-gradient(circle at 6px 6px, transparent 4px, black 4.5px)",
          maskSize: "12px 12px",
          maskComposite: "intersect",
          backgroundImage: `
            radial-gradient(circle at 0 50%, transparent 4px, transparent 4.5px),
            linear-gradient(to bottom right, #f5f5f4, #e7e5e4)`,
        }}
      >
        {/* Inner border */}
        <div className="absolute inset-3 border-2 border-stone-800/70 rounded-md flex flex-col items-center justify-between p-4 text-stone-800">
          <div className="text-[9px] tracking-[0.3em] uppercase font-bold opacity-80">
            Matt Mez Sax · AIME
          </div>

          <div className="flex flex-col items-center text-center gap-1.5">
            <Icon className={`w-9 h-9 ${stage.color.replace("text-", "text-stone-")} stroke-[1.5]`} />
            <div className="font-serif text-2xl leading-tight">
              {(booking?.event_type || "Événement").toUpperCase()}
            </div>
            <div className="text-[11px] font-mono">{date}</div>
            {booking?.client_name && (
              <div className="text-[10px] italic opacity-70 mt-1">{booking.client_name}</div>
            )}
            {booking?.event_location && (
              <div className="text-[10px] opacity-60">{booking.event_location}</div>
            )}
          </div>

          <div className="flex flex-col items-center gap-1">
            {booking?.price_total && (
              <div className="font-serif font-bold text-lg">
                {booking.price_total.toLocaleString("fr-FR")} €
              </div>
            )}
            <div className="text-[9px] font-mono tracking-[0.2em] opacity-70">
              {booking?.stamp_code || "AIME-XXX-XXX"}
            </div>
          </div>
        </div>

        {/* Status overlay */}
        {(status === "paid" || status === "confirmed") && (
          <motion.div
            initial={{ opacity: 0, scale: 1.5, rotate: 30 }}
            animate={{ opacity: 1, scale: 1, rotate: 12 }}
            transition={{ type: "spring", stiffness: 200, damping: 14, delay: 0.2 }}
            className="absolute top-6 right-2 px-3 py-1 border-4 border-emerald-700 text-emerald-700 font-bold text-sm tracking-widest rounded"
            style={{ fontFamily: "serif" }}
          >
            ✓ {stage.label.toUpperCase()}
          </motion.div>
        )}
      </motion.div>

      {/* Stage badge */}
      <div className="mt-4 flex justify-center">
        <div className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/[0.04] border border-white/10 text-[10px] uppercase tracking-[0.2em] ${stage.color}`}>
          <Icon className="w-3 h-3" />
          {stage.label}
        </div>
      </div>
    </motion.div>
  );
}