import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowRight, ArrowLeft, Loader2 } from "lucide-react";
import { EVENT_TYPES, OPTIONS } from "@/lib/bookingPricing";

const QUESTIONS = [
  "Quel type d'événement ?",
  "Combien de temps Matt doit-il jouer ?",
  "Souhaitez-vous des options ?",
  "Quel est votre nom ?",
  "Votre email ?",
  "Où aura lieu l'événement ?",
  "Récapitulatif & paiement",
];

export default function QuoteWizard({
  quoteStep,
  setQuoteStep,
  booking,
  setBooking,
  toggleOption,
  busy,
  onPay,
  lockedEventType = false,
}) {
  const total = QUESTIONS.length;
  const minStep = lockedEventType ? 1 : 0;

  const canNext = () => {
    switch (quoteStep) {
      case 0: return !!booking.event_type;
      case 1: return booking.duration_hours > 0;
      case 2: return true;
      case 3: return booking.client_name.trim().length > 0;
      case 4: return /\S+@\S+\.\S+/.test(booking.client_email);
      case 5: return true;
      default: return false;
    }
  };

  const next = () => setQuoteStep((s) => Math.min(s + 1, total - 1));
  const prev = () => setQuoteStep((s) => Math.max(s - 1, minStep));

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.3 }}
      className="flex flex-col items-center text-center w-full"
    >
      {/* Progress dots */}
      <div className="flex items-center gap-1 mb-4 w-full max-w-[240px]">
        {QUESTIONS.map((_, i) => (
          <div
            key={i}
            className={`h-1 flex-1 rounded-full transition-all ${
              i <= quoteStep ? "bg-amber-300" : "bg-white/10"
            }`}
          />
        ))}
      </div>

      <div className="text-[9px] uppercase tracking-[0.2em] text-white/40 mb-1.5">
        {quoteStep + 1} / {total}
      </div>
      <h2 className="text-base font-light mb-4 px-2">{QUESTIONS[quoteStep]}</h2>

      <AnimatePresence mode="wait">
        <motion.div
          key={quoteStep}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.25 }}
          className="w-full flex flex-col items-center"
        >
          {quoteStep === 0 && (
            <div className="flex flex-wrap gap-1.5 justify-center max-w-[260px]">
              {EVENT_TYPES.map((t) => (
                <button
                  key={t.id}
                  onClick={() => {
                    setBooking((b) => ({ ...b, event_type: t.id }));
                    setTimeout(next, 150);
                  }}
                  className={`px-3 py-1.5 rounded-full text-xs border transition ${
                    booking.event_type === t.id
                      ? "bg-amber-300 border-amber-300 text-black"
                      : "border-white/10 text-white/70 hover:border-white/30"
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>
          )}

          {quoteStep === 1 && (
            <div className="w-full max-w-[240px]">
              <div className="text-3xl font-light text-amber-200 mb-3">
                {booking.duration_hours} h
              </div>
              <input
                type="range" min={1} max={6} step={0.5}
                value={booking.duration_hours}
                onChange={(e) => setBooking((b) => ({ ...b, duration_hours: Number(e.target.value) }))}
                className="w-full accent-amber-300"
              />
              <div className="flex justify-between text-[10px] text-white/40 mt-1">
                <span>1h</span><span>6h</span>
              </div>
            </div>
          )}

          {quoteStep === 2 && (
            <div className="flex flex-col gap-1.5 w-full max-w-[240px]">
              {OPTIONS.map((o) => (
                <button
                  key={o.id}
                  onClick={() => toggleOption(o.id)}
                  className={`flex justify-between items-center px-3 py-2 rounded-lg text-xs border transition text-left ${
                    booking.options.includes(o.id)
                      ? "bg-amber-300/10 border-amber-300/40 text-amber-100"
                      : "border-white/10 text-white/60 hover:border-white/30"
                  }`}
                >
                  <span className="truncate">{o.label}</span>
                  <span className="font-mono shrink-0 ml-2">+{o.price}€</span>
                </button>
              ))}
            </div>
          )}

          {quoteStep === 3 && (
            <input
              autoFocus
              placeholder="Prénom Nom"
              value={booking.client_name}
              onChange={(e) => setBooking((b) => ({ ...b, client_name: e.target.value }))}
              onKeyDown={(e) => e.key === "Enter" && canNext() && next()}
              className="w-full max-w-[240px] bg-white/5 border border-white/10 rounded-xl px-3 py-2.5 text-sm text-center focus:outline-none focus:border-amber-300/50"
            />
          )}

          {quoteStep === 4 && (
            <input
              autoFocus
              type="email"
              placeholder="vous@email.com"
              value={booking.client_email}
              onChange={(e) => setBooking((b) => ({ ...b, client_email: e.target.value }))}
              onKeyDown={(e) => e.key === "Enter" && canNext() && next()}
              className="w-full max-w-[240px] bg-white/5 border border-white/10 rounded-xl px-3 py-2.5 text-sm text-center focus:outline-none focus:border-amber-300/50"
            />
          )}

          {quoteStep === 5 && (
            <input
              autoFocus
              placeholder="Ville, salle…"
              value={booking.event_location}
              onChange={(e) => setBooking((b) => ({ ...b, event_location: e.target.value }))}
              onKeyDown={(e) => e.key === "Enter" && next()}
              className="w-full max-w-[240px] bg-white/5 border border-white/10 rounded-xl px-3 py-2.5 text-sm text-center focus:outline-none focus:border-amber-300/50"
            />
          )}

          {quoteStep === 6 && (
            <div className="space-y-2.5 w-full max-w-[240px]">
              <div className="flex items-baseline justify-between pb-2 border-b border-white/10">
                <span className="text-[10px] uppercase tracking-widest text-white/50">Total</span>
                <span className="text-2xl font-light text-amber-200">{booking.price_total}€</span>
              </div>
              <button
                disabled={busy}
                onClick={() => onPay("deposit")}
                className="w-full py-2 rounded-lg border border-white/15 text-xs text-white/80 hover:bg-white/5 disabled:opacity-40"
              >
                Acompte 30% · {Math.round(booking.price_total * 0.3)}€
              </button>
              <button
                disabled={busy}
                onClick={() => onPay("full")}
                className="w-full py-2 rounded-lg bg-gradient-to-r from-amber-300 to-amber-500 text-black text-xs font-medium hover:brightness-110 transition disabled:opacity-40"
              >
                {busy ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : `Payer ${booking.price_total}€`}
              </button>
            </div>
          )}
        </motion.div>
      </AnimatePresence>

      {/* Nav buttons — round white with arrows */}
      {quoteStep < total - 1 && (
        <div className="flex items-center justify-center gap-3 mt-5">
          <button
            onClick={prev}
            disabled={quoteStep === minStep}
            aria-label="Retour"
            className="w-10 h-10 rounded-full bg-white text-black flex items-center justify-center hover:scale-105 active:scale-95 transition shadow-lg shadow-white/20 disabled:opacity-30 disabled:hover:scale-100"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <button
            onClick={next}
            disabled={!canNext()}
            aria-label="Suivant"
            className="w-10 h-10 rounded-full bg-white text-black flex items-center justify-center hover:scale-105 active:scale-95 transition shadow-lg shadow-white/20 disabled:opacity-30 disabled:hover:scale-100"
          >
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      )}

      {quoteStep === total - 1 && (
        <div className="flex justify-center mt-5">
          <button
            onClick={prev}
            aria-label="Modifier"
            className="w-9 h-9 rounded-full bg-white text-black flex items-center justify-center hover:scale-105 active:scale-95 transition shadow-lg shadow-white/20"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
        </div>
      )}
    </motion.div>
  );
}