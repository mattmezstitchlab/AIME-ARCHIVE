import React, { useEffect, useMemo, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

/**
 * ThermalTicket — vertical paper ticket animated like a thermal printer.
 * Lines appear progressively as the user fills the form on the right.
 */
export default function ThermalTicket({ booking, status = "draft", paidAt, ticketId }) {
  const lines = useMemo(() => buildLines(booking, status, paidAt, ticketId), [booking, status, paidAt, ticketId]);
  const scrollRef = useRef(null);

  // Auto-scroll to bottom when new lines arrive
  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    requestAnimationFrame(() => {
      el.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
    });
  }, [lines.length]);

  const isPaid = status === "paid" || status === "confirmed";

  return (
    <div className="relative w-[220px] mx-auto">
      {/* Paper — kraft vintage with serrated edges */}
      <div
        ref={scrollRef}
        className="relative font-mono text-[10px] leading-relaxed max-h-[400px] overflow-y-auto scroll-smooth"
        style={{
          backgroundColor: "#ede0c4",
          backgroundImage:
            "repeating-linear-gradient(0deg, rgba(90,60,20,0.06) 0px, rgba(90,60,20,0.06) 1px, transparent 1px, transparent 4px), radial-gradient(ellipse at 25% 15%, rgba(255,245,210,0.7) 0%, transparent 55%), radial-gradient(ellipse at 80% 85%, rgba(140,95,40,0.18) 0%, transparent 55%), radial-gradient(circle at 60% 40%, rgba(180,130,60,0.08) 0%, transparent 70%)",
          color: "#4a2f10",
          boxShadow:
            "0 22px 45px rgba(0,0,0,0.9), 0 6px 12px rgba(0,0,0,0.6), inset 0 0 25px rgba(120,80,30,0.18), inset 0 1px 0 rgba(255,245,210,0.5)",
        }}
      >
        {/* Top serrated edge */}
        <SerratedEdge top />

        <div className="px-5 pt-5 pb-6">
          <AnimatePresence initial={false}>
            {lines.map((line, idx) => (
              <PrintedLine key={line.key} line={line} index={idx} />
            ))}
          </AnimatePresence>

          {isPaid && (
            <motion.div
              initial={{ scale: 1.4, opacity: 0, rotate: -15 }}
              animate={{ scale: 1, opacity: 1, rotate: -8 }}
              transition={{ type: "spring", stiffness: 180, damping: 14, delay: 0.3 }}
              className="mt-5 mx-auto w-fit border-[3px] border-emerald-700 text-emerald-700 px-4 py-1 text-base font-bold tracking-[0.25em]"
              style={{ fontFamily: "serif" }}
            >
              ✓ TICKET VALIDÉ
            </motion.div>
          )}
        </div>

        {/* Bottom serrated edge */}
        <SerratedEdge />
      </div>
    </div>
  );
}

const SerratedEdge = ({ top }) => (
  <div
    className="h-2.5"
    style={{
      background: "inherit",
      maskImage: top
        ? "radial-gradient(circle at 5px 0, transparent 4px, black 4.5px)"
        : "radial-gradient(circle at 5px 10px, transparent 4px, black 4.5px)",
      WebkitMaskImage: top
        ? "radial-gradient(circle at 5px 0, transparent 4px, black 4.5px)"
        : "radial-gradient(circle at 5px 10px, transparent 4px, black 4.5px)",
      maskSize: "10px 10px",
      WebkitMaskSize: "10px 10px",
      maskRepeat: "repeat-x",
      WebkitMaskRepeat: "repeat-x",
    }}
  />
);

const PrintedLine = ({ line, index }) => {
  const text = line.text;
  const [shown, setShown] = useState(line.instant ? text : "");

  useEffect(() => {
    if (line.instant) { setShown(text); return; }
    let i = 0;
    setShown("");
    const speed = Math.max(8, 35 - text.length / 2);
    const t = setInterval(() => {
      i += 2;
      setShown(text.slice(0, i));
      if (i >= text.length) clearInterval(t);
    }, speed);
    return () => clearInterval(t);
  }, [text, line.instant]);

  return (
    <motion.div
      initial={{ opacity: 0, y: -4 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.18, delay: Math.min(index * 0.02, 0.3) }}
      className={lineClass(line)}
    >
      {line.type === "divider" ? (
        <div className="my-1.5" style={{ borderTop: "1px dashed rgba(80,50,15,0.4)" }} />
      ) : line.type === "row" ? (
        <div className="flex justify-between gap-2">
          <span style={{ opacity: 0.65 }}>{line.label}</span>
          <span className="font-bold">{shown}</span>
        </div>
      ) : (
        <div>{shown}</div>
      )}
    </motion.div>
  );
};

const lineClass = (line) => {
  if (line.type === "tinytop") return "text-center text-[8px] tracking-[0.4em] uppercase opacity-60 mb-1";
  if (line.type === "title") return "text-center font-bold text-lg tracking-[0.25em] my-0.5";
  if (line.type === "emblem") return "text-center text-base opacity-50 my-0.5";
  if (line.type === "subtitle") return "text-center text-[9px] tracking-[0.3em] uppercase opacity-70 mb-2 font-semibold";
  if (line.type === "header") return "text-[9px] tracking-[0.25em] uppercase opacity-60 mt-2 mb-0.5";
  if (line.type === "total") return "flex justify-between text-base font-bold mt-1";
  if (line.type === "stamp") return "text-center text-[9px] tracking-widest opacity-60 mt-3";
  return "";
};



/* ---------- Line builder ---------- */

const fmtDate = (iso) => iso
  ? new Date(iso).toLocaleDateString("fr-FR", { weekday: "short", day: "2-digit", month: "long", year: "numeric" })
  : null;

function buildLines(b, status, paidAt, ticketId) {
  const lines = [];
  const push = (line) => lines.push({ ...line, key: `${lines.length}-${line.text || line.label || line.type}` });

  push({ type: "tinytop", text: "AIME STAMP MACHINE", instant: true });
  push({ type: "title", text: "MATT MEZ SAX", instant: true });
  push({ type: "emblem", text: "✦", instant: true });
  push({ type: "subtitle", text: "VOTRE ÉVÉNEMENT PREND VIE", instant: true });
  push({ type: "divider", instant: true });

  if (b.event_type) {
    push({ type: "header", text: "ÉVÉNEMENT", instant: true });
    push({ type: "line", text: b.event_type.toUpperCase() });
  }
  if (b.event_date) {
    push({ type: "row", label: "Date", text: fmtDate(b.event_date) });
  }
  if (b.duration_hours) {
    push({ type: "row", label: "Durée", text: `${b.duration_hours} h` });
  }
  if (b.event_location) {
    push({ type: "row", label: "Lieu", text: b.event_location });
  }

  if (b.client_name || b.client_email) {
    push({ type: "divider", instant: true });
    push({ type: "header", text: "CLIENT", instant: true });
    if (b.client_name) push({ type: "line", text: b.client_name });
    if (b.client_email) push({ type: "line", text: b.client_email });
  }

  if (b.options && b.options.length > 0) {
    push({ type: "divider", instant: true });
    push({ type: "header", text: "OPTIONS", instant: true });
    b.options.forEach((opt) => {
      push({ type: "row", label: `+ ${opt.label}`, text: `${opt.price}€` });
    });
  }

  if (b.price_total > 0) {
    push({ type: "divider", instant: true });
    push({ type: "total", label: "TOTAL TTC", text: `${b.price_total} €` });
  }

  if (status === "paid" || status === "confirmed") {
    push({ type: "divider", instant: true });
    push({ type: "row", label: "Statut", text: "PAYÉ ✓" });
    if (paidAt) push({ type: "row", label: "Payé le", text: new Date(paidAt).toLocaleString("fr-FR") });
    if (b.deposit_amount) push({ type: "row", label: "Montant", text: `${b.deposit_amount} €` });
  }

  if (b.stamp_code || ticketId) {
    push({ type: "divider", instant: true });
    push({ type: "stamp", text: `#${ticketId || b.stamp_code}` });
  }

  return lines;
}