import React from "react";
import { motion } from "framer-motion";

/* ---------- Reusable decorative parts ---------- */

export const BrassScrew = ({ style }) => (
  <div
    className="absolute w-4 h-4 rounded-full"
    style={{
      ...style,
      background:
        "radial-gradient(circle at 35% 30%, #f5d987 0%, #c9a14a 35%, #6b4a18 80%, #2a1c08 100%)",
      boxShadow:
        "inset 0 1px 1px rgba(255,255,255,0.5), inset 0 -2px 3px rgba(0,0,0,0.5), 0 2px 3px rgba(0,0,0,0.6)",
    }}
  >
    <div
      className="absolute inset-0 m-auto"
      style={{
        width: "60%",
        height: "1.5px",
        top: "50%",
        transform: "translateY(-50%) rotate(35deg)",
        background:
          "linear-gradient(to right, transparent, rgba(0,0,0,0.7), transparent)",
        margin: "auto",
        left: 0, right: 0,
      }}
    />
  </div>
);

/* ---------- Top brass plate "AIME STAMP MACHINE" ---------- */

export const TopPlate = () => (
  <div
    className="absolute left-1/2 -translate-x-1/2 px-6 py-1.5 rounded-md"
    style={{
      top: "2.5%",
      background:
        "linear-gradient(to bottom, #f5d987 0%, #d4af5a 40%, #a07a2c 100%)",
      boxShadow:
        "inset 0 1px 1px rgba(255,255,255,0.6), inset 0 -2px 3px rgba(0,0,0,0.4), 0 4px 8px rgba(0,0,0,0.7)",
      zIndex: 30,
    }}
  >
    <div className="text-[10px] tracking-[0.35em] font-serif text-stone-900 font-bold whitespace-nowrap">
      AIME STAMP MACHINE
    </div>
  </div>
);

/* ---------- Animated gears (top-right) ---------- */

const GearSVG = ({ teeth = 12, size = 60, color = "#c9a14a" }) => {
  const r = size / 2;
  const inner = r * 0.5;
  const teethPath = Array.from({ length: teeth }).map((_, i) => {
    const a = (i / teeth) * Math.PI * 2;
    const a2 = ((i + 0.4) / teeth) * Math.PI * 2;
    const a3 = ((i + 0.6) / teeth) * Math.PI * 2;
    const a4 = ((i + 1) / teeth) * Math.PI * 2;
    const outer = r;
    const flat = r * 0.85;
    return `${i === 0 ? "M" : "L"}${Math.cos(a) * flat + r},${Math.sin(a) * flat + r} L${Math.cos(a2) * outer + r},${Math.sin(a2) * outer + r} L${Math.cos(a3) * outer + r},${Math.sin(a3) * outer + r} L${Math.cos(a4) * flat + r},${Math.sin(a4) * flat + r}`;
  }).join(" ") + " Z";
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      <defs>
        <radialGradient id={`gg-${size}`} cx="35%" cy="30%">
          <stop offset="0%" stopColor="#f5d987" />
          <stop offset="60%" stopColor={color} />
          <stop offset="100%" stopColor="#5a3e12" />
        </radialGradient>
      </defs>
      <path d={teethPath} fill={`url(#gg-${size})`} stroke="#3a2808" strokeWidth="0.5" />
      <circle cx={r} cy={r} r={inner} fill="#1a1208" stroke="#6b4a18" strokeWidth="1" />
      {[0, 60, 120, 180, 240, 300].map((deg) => (
        <circle
          key={deg}
          cx={r + Math.cos((deg * Math.PI) / 180) * inner * 0.55}
          cy={r + Math.sin((deg * Math.PI) / 180) * inner * 0.55}
          r="2" fill="#0a0805"
        />
      ))}
    </svg>
  );
};

export const Gears = () => (
  <div className="absolute" style={{ top: "12%", right: "14%", zIndex: 25, pointerEvents: "none" }}>
    <motion.div
      animate={{ rotate: 360 }}
      transition={{ duration: 18, repeat: Infinity, ease: "linear" }}
      style={{ filter: "drop-shadow(0 2px 3px rgba(0,0,0,0.6))" }}
    >
      <GearSVG teeth={14} size={56} />
    </motion.div>
    <motion.div
      animate={{ rotate: -360 }}
      transition={{ duration: 12, repeat: Infinity, ease: "linear" }}
      className="absolute"
      style={{ top: 38, left: 38, filter: "drop-shadow(0 2px 3px rgba(0,0,0,0.6))" }}
    >
      <GearSVG teeth={10} size={36} />
    </motion.div>
  </div>
);

/* ---------- Left dial with moving needle ---------- */

export const LeftDial = () => (
  <div
    className="absolute"
    style={{ left: "6%", top: "32%", width: "14%", aspectRatio: "1/2.4", zIndex: 25, pointerEvents: "none" }}
  >
    {/* Subtle curved arc — engraved into the brass body */}
    <svg
      viewBox="0 0 100 240"
      className="absolute inset-0 w-full h-full"
      style={{ filter: "drop-shadow(0 1px 0 rgba(255,235,180,0.15))" }}
    >
      <path
        d="M 80 10 Q 30 120 80 230"
        fill="none"
        stroke="rgba(0,0,0,0.55)"
        strokeWidth="2"
      />
      <path
        d="M 80 10 Q 30 120 80 230"
        fill="none"
        stroke="rgba(220,170,90,0.35)"
        strokeWidth="0.6"
      />
    </svg>
    {/* Brass knob — centered on the arc */}
    <div
      className="absolute left-1/2 top-1/2 w-8 h-8 rounded-full -translate-x-1/2 -translate-y-1/2"
      style={{
        background:
          "radial-gradient(circle at 35% 30%, #f5d987 0%, #c9a14a 40%, #6b4a18 80%, #2a1808 100%)",
        boxShadow:
          "inset 0 1px 1px rgba(255,235,180,0.5), inset 0 -2px 4px rgba(0,0,0,0.6), 0 4px 8px rgba(0,0,0,0.8)",
      }}
    >
      {/* Knob center dot */}
      <div
        className="absolute inset-0 m-auto w-2 h-2 rounded-full"
        style={{
          background: "radial-gradient(circle, #2a1808, #050302)",
          top: "50%", left: "50%", transform: "translate(-50%, -50%)",
        }}
      />
    </div>
  </div>
);

/* ---------- Right rolling drum (saxophone-like cylinder) ---------- */

export const RightDrum = () => (
  <div
    className="absolute"
    style={{ right: "4%", top: "32%", width: "13%", aspectRatio: "1/2.5", zIndex: 25, pointerEvents: "none" }}
  >
    {/* Cylinder body */}
    <div
      className="absolute inset-x-0 inset-y-[8%] rounded-md overflow-hidden"
      style={{
        background:
          "linear-gradient(to right, #4a4a4f 0%, #c0c0c5 25%, #e8e8ed 45%, #c0c0c5 65%, #5a5a5f 100%)",
        boxShadow:
          "inset 0 0 8px rgba(0,0,0,0.5), 0 4px 10px rgba(0,0,0,0.7)",
      }}
    >
      {/* Rotating texture inside */}
      <motion.div
        className="absolute inset-0"
        style={{
          backgroundImage:
            "repeating-linear-gradient(0deg, rgba(0,0,0,0.25) 0 2px, transparent 2px 6px)",
        }}
        animate={{ y: [0, -12] }}
        transition={{ duration: 1.2, repeat: Infinity, ease: "linear" }}
      />
      {/* Engraved sun emblem */}
      <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 flex justify-center">
        <div
          className="w-6 h-6 rounded-full flex items-center justify-center text-[10px]"
          style={{
            background:
              "radial-gradient(circle, #f5d987 0%, #a07a2c 60%, #5a3e12 100%)",
            boxShadow: "inset 0 1px 1px rgba(255,255,255,0.4)",
          }}
        >
          ☀
        </div>
      </div>
    </div>
    {/* Top cap */}
    <div
      className="absolute left-0 right-0 top-0 h-[10%] rounded-t-md"
      style={{
        background: "linear-gradient(to bottom, #f5d987, #a07a2c)",
        boxShadow: "inset 0 1px 1px rgba(255,255,255,0.5), 0 2px 4px rgba(0,0,0,0.6)",
      }}
    />
    {/* Bottom cap */}
    <div
      className="absolute left-0 right-0 bottom-0 h-[10%] rounded-b-md"
      style={{
        background: "linear-gradient(to bottom, #a07a2c, #4a3210)",
        boxShadow: "inset 0 -1px 1px rgba(255,255,255,0.3), 0 2px 4px rgba(0,0,0,0.6)",
      }}
    />
  </div>
);

/* ---------- Bottom-left tiny LED panel ---------- */

export const BottomLeftPanel = () => (
  <div
    className="absolute flex flex-col items-center gap-1 px-1.5 py-1 rounded"
    style={{
      left: "12%", bottom: "16%",
      background: "linear-gradient(to bottom, #1a1208, #050302)",
      border: "1px solid #4a3210",
      boxShadow: "inset 0 1px 2px rgba(0,0,0,0.8)",
      zIndex: 25,
    }}
  >
    <div className="flex flex-col gap-[2px]">
      {[0, 1, 2].map((i) => (
        <div key={i} className="w-3 h-[2px] bg-amber-300/60 rounded-full" />
      ))}
    </div>
    <div className="w-1.5 h-1.5 rounded-full bg-amber-400 shadow-[0_0_4px_rgba(245,217,135,0.9)] animate-pulse" />
  </div>
);

/* ---------- Bottom-right "EN LIGNE" LED ---------- */

export const StatusLED = () => (
  <div
    className="absolute flex items-center gap-1 px-2 py-1 rounded"
    style={{
      right: "12%", bottom: "16%",
      background: "linear-gradient(to bottom, #1a1208, #050302)",
      border: "1px solid #4a3210",
      boxShadow: "inset 0 1px 2px rgba(0,0,0,0.8)",
      zIndex: 25,
    }}
  >
    <div className="text-[7px] tracking-[0.2em] font-bold text-amber-300/80">EN LIGNE</div>
    <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 shadow-[0_0_5px_rgba(52,211,153,1)] animate-pulse" />
  </div>
);