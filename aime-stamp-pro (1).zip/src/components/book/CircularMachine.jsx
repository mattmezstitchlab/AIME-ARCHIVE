import React from "react";
import { motion } from "framer-motion";
import {
  BrassScrew, TopPlate, Gears, LeftDial, RightDrum, BottomLeftPanel, StatusLED,
} from "./MachineDecorations";

/**
 * Steampunk brass-and-gold circular machine.
 * Ornate brass body with engraved gears, dials, drums, vintage plate,
 * and a glowing golden neon ring around the central digital screen.
 * The thermal ticket emerges from a slot at the bottom.
 */
export default function CircularMachine({ children, ticket }) {
  return (
    <div className="relative w-full flex flex-col items-center">
      {/* MACHINE BODY */}
      <div className="relative" style={{ width: "min(480px, 88vw)", aspectRatio: "1 / 1" }}>
        {/* Soft warm halo around */}
        <div
          aria-hidden
          className="absolute -inset-8 rounded-full"
          style={{
            background:
              "radial-gradient(circle, rgba(245,217,135,0.18) 0%, transparent 65%)",
            filter: "blur(30px)",
          }}
        />

        {/* OUTER BRASS RING — bronze with strong chiaroscuro */}
        <div
          aria-hidden
          className="absolute inset-0 rounded-full"
          style={{
            background:
              "conic-gradient(from 90deg, #1a0e04 0deg, #3a2410 20deg, #6b4818 45deg, #a07028 75deg, #c89548 95deg, #b8842c 115deg, #7a5018 145deg, #2e1a08 180deg, #1a0e04 200deg, #4a2e10 240deg, #8a5e20 285deg, #6b4818 320deg, #2e1a08 360deg)",
            boxShadow:
              "0 35px 90px rgba(0,0,0,0.95), 0 10px 24px rgba(0,0,0,0.8), inset 0 0 60px rgba(0,0,0,0.85)",
          }}
        />

        {/* Brushed bronze texture — fine radial striations */}
        <div
          aria-hidden
          className="absolute inset-0 rounded-full pointer-events-none mix-blend-overlay opacity-70"
          style={{
            background:
              "repeating-conic-gradient(from 0deg, rgba(255,220,160,0.5) 0deg 0.25deg, rgba(0,0,0,0.55) 0.25deg 0.6deg, rgba(180,130,60,0.3) 0.6deg 1deg, transparent 1deg 1.8deg)",
            mask: "radial-gradient(circle, transparent 41%, black 42%, black 50%, transparent 50.5%)",
            WebkitMask: "radial-gradient(circle, transparent 41%, black 42%, black 50%, transparent 50.5%)",
          }}
        />

        {/* Top specular highlight — bright sheen */}
        <div
          aria-hidden
          className="absolute inset-0 rounded-full pointer-events-none"
          style={{
            background:
              "radial-gradient(ellipse 50% 22% at 50% 6%, rgba(255,235,180,0.85) 0%, rgba(220,170,90,0.4) 35%, transparent 65%)",
            mask: "radial-gradient(circle, transparent 41%, black 42%, black 50%, transparent 50.5%)",
            WebkitMask: "radial-gradient(circle, transparent 41%, black 42%, black 50%, transparent 50.5%)",
          }}
        />

        {/* Side highlights — left & right edge reflections */}
        <div
          aria-hidden
          className="absolute inset-0 rounded-full pointer-events-none"
          style={{
            background:
              "radial-gradient(ellipse 15% 40% at 92% 50%, rgba(220,170,90,0.5) 0%, transparent 60%), radial-gradient(ellipse 15% 40% at 8% 50%, rgba(180,130,60,0.35) 0%, transparent 60%)",
            mask: "radial-gradient(circle, transparent 41%, black 42%, black 50%, transparent 50.5%)",
            WebkitMask: "radial-gradient(circle, transparent 41%, black 42%, black 50%, transparent 50.5%)",
          }}
        />

        {/* Deep bottom shadow — chiaroscuro */}
        <div
          aria-hidden
          className="absolute inset-0 rounded-full pointer-events-none"
          style={{
            background:
              "radial-gradient(ellipse 80% 45% at 50% 98%, rgba(0,0,0,0.92) 0%, rgba(0,0,0,0.5) 45%, transparent 75%)",
            mask: "radial-gradient(circle, transparent 41%, black 42%, black 50%, transparent 50.5%)",
            WebkitMask: "radial-gradient(circle, transparent 41%, black 42%, black 50%, transparent 50.5%)",
          }}
        />

        {/* Engraved scale ticks on outer ring */}
        <div
          aria-hidden
          className="absolute inset-0 rounded-full pointer-events-none opacity-70"
          style={{
            background:
              "repeating-conic-gradient(from 0deg, rgba(0,0,0,0.7) 0deg 0.5deg, transparent 0.5deg 3deg)",
            mask: "radial-gradient(circle, transparent 46.5%, black 47%, black 49%, transparent 49.5%)",
            WebkitMask: "radial-gradient(circle, transparent 46.5%, black 47%, black 49%, transparent 49.5%)",
          }}
        />

        {/* Inner beveled bronze edge — adds 3D depth (dark on top, lit on bottom = inverted bevel) */}
        <div
          aria-hidden
          className="absolute rounded-full pointer-events-none"
          style={{
            inset: "5%",
            background:
              "conic-gradient(from 90deg, #1a0e04 0deg, #3a2410 60deg, #7a5018 130deg, #b8842c 175deg, #a07028 200deg, #5e3e14 260deg, #2a1808 320deg, #1a0e04 360deg)",
            boxShadow:
              "inset 0 6px 14px rgba(0,0,0,0.95), inset 0 -3px 6px rgba(220,170,90,0.35), 0 1px 2px rgba(255,235,180,0.15)",
          }}
        />

        {/* Dark inner brass bezel (recessed area) */}
        <div
          aria-hidden
          className="absolute inset-[7%] rounded-full"
          style={{
            background:
              "radial-gradient(circle at 30% 20%, #1a1208 0%, #0a0604 50%, #030201 100%)",
            boxShadow:
              "inset 0 8px 24px rgba(0,0,0,0.95), inset 0 -2px 8px rgba(245,217,135,0.06), inset 0 0 40px rgba(0,0,0,0.8)",
          }}
        />

        {/* Subtle inner brass rim highlight */}
        <div
          aria-hidden
          className="absolute inset-[7%] rounded-full pointer-events-none"
          style={{
            border: "1px solid transparent",
            background:
              "linear-gradient(180deg, rgba(245,217,135,0.4), transparent 30%, transparent 70%, rgba(0,0,0,0.6)) border-box",
            WebkitMask:
              "linear-gradient(#000 0 0) padding-box, linear-gradient(#000 0 0)",
            WebkitMaskComposite: "xor",
            maskComposite: "exclude",
          }}
        />

        {/* Decorative brass screws around bezel */}
        {[15, 75, 105, 165, 195, 255, 285, 345].map((deg, i) => (
          <div
            key={i}
            className="absolute left-1/2 top-1/2"
            style={{
              transform: `translate(-50%, -50%) rotate(${deg}deg) translateY(-44%) rotate(${-deg}deg)`,
            }}
          >
            <BrassScrew />
          </div>
        ))}

        {/* Top plate with brand */}
        <TopPlate />

        {/* Animated gears top-right */}
        <Gears />

        {/* Left dial with moving needle */}
        <LeftDial />

        {/* Right rotating drum */}
        <RightDrum />

        {/* DIGITAL SCREEN with golden neon ring */}
        <div
          className="absolute"
          style={{ inset: "16%", zIndex: 10 }}
        >
          {/* Golden neon halo */}
          <motion.div
            aria-hidden
            className="absolute -inset-1 rounded-full pointer-events-none"
            style={{
              background:
                "radial-gradient(circle, rgba(245,217,135,0.5) 0%, transparent 70%)",
              filter: "blur(8px)",
            }}
            animate={{ opacity: [0.6, 0.95, 0.6] }}
            transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
          />
          {/* Crisp neon ring */}
          <div
            aria-hidden
            className="absolute inset-0 rounded-full pointer-events-none"
            style={{
              border: "2px solid #f5d987",
              boxShadow:
                "0 0 12px rgba(245,217,135,0.9), 0 0 24px rgba(245,217,135,0.5), inset 0 0 12px rgba(245,217,135,0.5)",
            }}
          />

          {/* Screen surface */}
          <div
            className="absolute inset-[3%] rounded-full overflow-hidden"
            style={{
              background:
                "radial-gradient(circle at 50% 30%, #14110a 0%, #080604 70%, #040302 100%)",
              boxShadow:
                "inset 0 0 40px rgba(245,217,135,0.06), inset 0 0 8px rgba(0,0,0,0.9)",
            }}
          >
            {/* Subtle scanlines */}
            <div
              aria-hidden
              className="absolute inset-0 pointer-events-none opacity-[0.06] mix-blend-screen"
              style={{
                backgroundImage:
                  "repeating-linear-gradient(0deg, rgba(245,217,135,0.6) 0 1px, transparent 1px 3px)",
              }}
            />
            {/* Warm vignette */}
            <div
              aria-hidden
              className="absolute inset-0 pointer-events-none"
              style={{
                background:
                  "radial-gradient(ellipse at center, rgba(245,217,135,0.05) 0%, transparent 70%)",
              }}
            />

            {/* Top status bar */}
            <div className="absolute top-3 left-1/2 -translate-x-1/2 flex items-center gap-2 px-3 py-1 rounded-full bg-black/40 border border-amber-300/20 text-[9px] tracking-[0.3em] uppercase text-amber-200/80 z-10">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-300 animate-pulse shadow-[0_0_4px_rgba(245,217,135,0.9)]" />
              AIME · ONLINE
            </div>

            {/* Screen content (form) — clipped to circle */}
            <div
              className="absolute inset-0 flex items-center justify-center overflow-hidden"
              style={{
                padding: "14%",
                clipPath: "circle(50% at 50% 50%)",
                WebkitClipPath: "circle(50% at 50% 50%)",
              }}
            >
              <div className="w-full max-h-full overflow-y-auto no-scrollbar">
                {children}
              </div>
            </div>
          </div>
        </div>

        {/* Bottom side panels */}
        <BottomLeftPanel />
        <StatusLED />

        {/* SLOT (where ticket comes out) — bronze-trimmed near machine bottom */}
        <div
          className="absolute left-1/2 -translate-x-1/2"
          style={{
            bottom: "8%",
            width: "44%",
            height: "32px",
            zIndex: 20,
          }}
        >
          {/* Bronze frame with chiseled depth */}
          <div
            className="absolute inset-0 rounded-md"
            style={{
              background:
                "linear-gradient(to bottom, #b8842c 0%, #7a5018 25%, #2a1808 45%, #050302 50%, #2a1808 55%, #6b4818 75%, #a07028 100%)",
              boxShadow:
                "inset 0 4px 10px rgba(0,0,0,0.95), inset 0 -2px 4px rgba(220,170,90,0.3), 0 6px 14px rgba(0,0,0,0.8)",
            }}
          />
          {/* Inner dark mouth with warm inner glow */}
          <div
            className="absolute left-2 right-2 top-1/2 -translate-y-1/2 h-3 rounded-sm overflow-hidden"
            style={{
              background: "#000",
              boxShadow:
                "inset 0 3px 6px rgba(0,0,0,1), 0 0 14px rgba(220,170,90,0.55)",
            }}
          >
            {/* Subtle inner warm light */}
            <div
              className="absolute inset-0"
              style={{
                background:
                  "radial-gradient(ellipse at center, rgba(220,170,90,0.4) 0%, transparent 70%)",
              }}
            />
          </div>
          {/* LEDs flanking the slot */}
          <div className="absolute -top-1 left-2 w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse shadow-[0_0_6px_rgba(220,170,90,1)]" />
          <div className="absolute -top-1 right-2 w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse shadow-[0_0_6px_rgba(220,170,90,1)]" />
        </div>

        {/* TICKET emerging from the slot — positioned absolutely from slot */}
        <div
          className="absolute left-1/2 -translate-x-1/2 pointer-events-auto"
          style={{
            top: "calc(92% - 8px)",
            zIndex: 18,
          }}
        >
          <motion.div
            initial={{ y: -40, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
            className="origin-top relative"
          >
            {ticket}
            {/* Subtle shadow at the top edge — emerging from slot */}
            <div
              aria-hidden
              className="absolute top-0 left-0 right-0 pointer-events-none"
              style={{
                height: "24px",
                background:
                  "linear-gradient(to bottom, rgba(0,0,0,0.55) 0%, rgba(0,0,0,0.2) 50%, transparent 100%)",
                zIndex: 5,
              }}
            />
          </motion.div>
        </div>
      </div>
    </div>
  );
}