import React from "react";
import ReactMarkdown from "react-markdown";
import { Zap, Loader2, CheckCircle2, AlertCircle } from "lucide-react";

export default function MessageBubble({ message }) {
  const isUser = message.role === "user";

  return (
    <div className={`flex ${isUser ? "justify-end" : "justify-start"}`}>
      <div className={`max-w-[85%] ${isUser ? "" : "flex flex-col"}`}>
        {message.content && (
          <div
            className={`rounded-2xl px-4 py-2.5 text-sm ${
              isUser
                ? "bg-violet-500/20 border border-violet-400/30 text-violet-50"
                : "bg-white/[0.04] border border-white/10 text-white/90"
            }`}
          >
            {isUser ? (
              <p className="whitespace-pre-wrap">{message.content}</p>
            ) : (
              <ReactMarkdown
                components={{
                  p: ({ children }) => <p className="my-1 leading-relaxed">{children}</p>,
                  ul: ({ children }) => <ul className="my-1 ml-4 list-disc">{children}</ul>,
                  li: ({ children }) => <li className="my-0.5">{children}</li>,
                  strong: ({ children }) => <strong className="text-white">{children}</strong>,
                }}
              >
                {message.content}
              </ReactMarkdown>
            )}
          </div>
        )}

        {message.tool_calls?.length > 0 && (
          <div className="space-y-1 mt-1">
            {message.tool_calls.map((tc, i) => <ToolCallChip key={i} tc={tc} />)}
          </div>
        )}
      </div>
    </div>
  );
}

const ToolCallChip = ({ tc }) => {
  const status = tc.status || "pending";
  const isErr = tc.results && /error|failed/i.test(String(tc.results));
  const Icon = status === "running" || status === "in_progress" ? Loader2
    : status === "completed" || status === "success" ? (isErr ? AlertCircle : CheckCircle2)
    : Zap;
  const color = status === "completed" && !isErr ? "text-emerald-300" : isErr ? "text-red-300" : "text-white/50";
  const name = (tc.name || "fonction").split(".").reverse().join(" ").toLowerCase();
  return (
    <div className={`inline-flex items-center gap-1.5 text-[10px] px-2 py-1 rounded-md border border-white/10 bg-white/[0.02] ${color}`}>
      <Icon className={`w-3 h-3 ${status === "running" || status === "in_progress" ? "animate-spin" : ""}`} />
      <span className="capitalize">{name}</span>
    </div>
  );
};