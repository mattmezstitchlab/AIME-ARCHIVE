import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import MachineControlPanel from "./MachineControlPanel";

/**
 * Machine à imprimer des timbres-poste — tout-en-un.
 * - Cube métallique avec écran LED tactile au centre (panneau de contrôle).
 * - LEDs latérales colorées qui s'illuminent pendant l'impression.
 * - Fente d'éjection en bas d'où sort le timbre généré.
 */
export default function StampMachine({ loading, imageUrl, rotation = 0, code, controlProps }) {
  const ledColors = [
    "bg-red-500",
    "bg-amber-400",
    "bg-emerald-400",
    "bg-cyan-400",
    "bg-indigo-400",
    "bg-fuchsia-500",
  ];

  return (
    <div className="relative w-full max-w-xl mx-auto flex flex-col items-center">
      {/* Cube / boîtier de la machine */}
      <div className="relative w-full rounded-[28px] overflow-hidden shadow-[0_30px_80px_-20px_rgba(0,0,0,0.85)] border border-white/10">
        {/* Fond métallique brossé */}
        <div className="absolute inset-0 bg-gradient-to-br from-zinc-700 via-zinc-800 to-zinc-950" />
        <div
          className="absolute inset-0 opacity-20 mix-blend-overlay pointer-events-none"
          style={{
            backgroundImage:
              "repeating-linear-gradient(90deg, rgba(255,255,255,0.15) 0px, transparent 1px, transparent 3px)",
          }}
        />
        {/* Reflet supérieur */}
        <div className="absolute top-0 left-0 right-0 h-20 bg-gradient-to-b from-white/[0.08] to-transparent pointer-events-none" />

        {/* Vis dans les coins */}
        {[
          "top-3 left-3",
          "top-3 right-3",
          "bottom-3 left-3",
          "bottom-3 right-3",
        ].map((pos) => (
          <div
            key={pos}
            className={`absolute ${pos} w-2.5 h-2.5 rounded-full bg-zinc-900 border border-white/20 shadow-inner z-10`}
          >
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-1.5 h-px bg-white/30 rotate-45" />
            </div>
          </div>
        ))}

        {/* Plaque marque */}
        <div className="relative z-10 pt-5 pb-2 flex items-center justify-center">
          <div className="px-4 py-1 rounded-md bg-black/60 border border-white/10">
            <span className="font-mono text-[10px] tracking-[0.3em] text-white/70">
              AIME · STAMP MACHINE
            </span>
          </div>
        </div>

        {/* Contenu : LEDs latérales + écran tactile */}
        <div className="relative z-10 flex items-stretch gap-3 px-4 pb-4">
          {/* LEDs gauche */}
          <SideLeds colors={ledColors} loading={loading} />

          {/* Écran LED tactile central */}
          <div className="flex-1 rounded-xl bg-black/80 border-2 border-emerald-900/60 shadow-[inset_0_0_30px_rgba(0,0,0,0.9),0_0_20px_rgba(16,185,129,0.15)] p-3">
            <MachineControlPanel loading={loading} {...controlProps} />
          </div>

          {/* LEDs droite */}
          <SideLeds colors={[...ledColors].reverse()} loading={loading} />
        </div>

        {/* Fente d'éjection en bas */}
        <div className="relative z-10 flex justify-center pb-0">
          <div className="w-2/3 h-5 bg-black rounded-t-md shadow-[inset_0_3px_8px_rgba(0,0,0,0.9)] border-t border-white/10 relative overflow-hidden">
            <AnimatePresence>
              {loading && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: [0.3, 0.8, 0.3] }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 1, repeat: Infinity }}
                  className="absolute inset-0 bg-gradient-to-t from-amber-300/40 to-transparent"
                />
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>

      {/* Timbre qui sort de la fente */}
      <div className="relative w-full min-h-[18rem] -mt-2 flex justify-center">
        <AnimatePresence mode="wait">
          {imageUrl && !loading && (
            <motion.div
              key={imageUrl}
              initial={{ y: -60, opacity: 0, scale: 0.8 }}
              animate={{ y: 0, opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
              className="relative flex flex-col items-center pt-4"
            >
              <img
                src={imageUrl}
                alt="Stamp"
                crossOrigin="anonymous"
                style={{
                  transform: `rotate(${rotation}deg)`,
                  filter: "drop-shadow(0 12px 24px rgba(0,0,0,0.55))",
                }}
                className="w-56 h-56 object-contain"
              />
              {code && (
                <div className="mt-2 flex items-center gap-2 px-3 py-1.5 rounded-full border border-white/10 bg-white/[0.04] font-mono text-[11px] tracking-[0.2em] text-white/70">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400/80 animate-pulse" />
                  {code}
                </div>
              )}
            </motion.div>
          )}

          {loading && (
            <motion.div
              key="printing"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute top-2 flex flex-col items-center gap-2"
            >
              <motion.div
                initial={{ height: 0 }}
                animate={{ height: 80 }}
                transition={{ duration: 1.5, repeat: Infinity, repeatType: "reverse" }}
                className="w-24 bg-gradient-to-b from-amber-50 to-amber-100 rounded-b-sm shadow-md"
              />
              <p className="text-[10px] text-white/50 tracking-[0.2em] uppercase">
                Impression…
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

const SideLeds = ({ colors, loading }) => (
  <div className="flex flex-col items-center justify-center gap-2 py-2 px-1.5 rounded-lg bg-black/50 border border-white/5">
    {colors.map((c, i) => (
      <motion.div
        key={i}
        className={`w-2 h-2 rounded-full ${c}`}
        animate={
          loading
            ? {
                opacity: [0.25, 1, 0.25],
                boxShadow: [
                  "0 0 0px currentColor",
                  "0 0 10px currentColor",
                  "0 0 0px currentColor",
                ],
              }
            : { opacity: 0.3 }
        }
        transition={{
          duration: 1.2,
          repeat: loading ? Infinity : 0,
          delay: i * 0.12,
          ease: "easeInOut",
        }}
      />
    ))}
  </div>
);