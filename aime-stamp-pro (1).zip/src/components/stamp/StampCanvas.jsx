import React, { forwardRef } from "react";

const StampCanvas = forwardRef(({ imageUrl, rotation }, ref) => {
  // Transparent checkered background to show transparency
  const checkerStyle = {
    backgroundImage:
      "linear-gradient(45deg, rgba(255,255,255,0.04) 25%, transparent 25%, transparent 75%, rgba(255,255,255,0.04) 75%, rgba(255,255,255,0.04)), linear-gradient(45deg, rgba(255,255,255,0.04) 25%, transparent 25%, transparent 75%, rgba(255,255,255,0.04) 75%, rgba(255,255,255,0.04))",
    backgroundSize: "16px 16px",
    backgroundPosition: "0 0, 8px 8px",
  };

  return (
    <div
      ref={ref}
      className="relative p-10 rounded-2xl border border-white/10 shadow-[0_30px_80px_-20px_rgba(0,0,0,0.6)]"
      style={checkerStyle}
    >
      <img
        src={imageUrl}
        alt="Generated stamp"
        crossOrigin="anonymous"
        style={{
          transform: `rotate(${rotation}deg)`,
          filter: "drop-shadow(0 8px 20px rgba(0,0,0,0.4))",
        }}
        className="w-72 h-72 md:w-80 md:h-80 object-contain transition-transform duration-700"
      />
    </div>
  );
});

StampCanvas.displayName = "StampCanvas";
export default StampCanvas;