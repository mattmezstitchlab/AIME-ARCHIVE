import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";

/**
 * Compact, hoverable version of the steampunk circular machine.
 * Used on the showroom home page to present each event universe.
 * Each machine carries its own brass palette and signature glow.
 */
export default function MiniMachine({ universe }) {
  const { label, tagline, route, icon, palette } = universe;

  return (
    <Link
      to={route}
      className="group relative flex flex-col items-center"
    >
      {/* Outer halo */}
      <div
        aria-hidden
        className="absolute -inset-6 rounded-full opacity-60 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"
        style={{
          background: `radial-gradient(circle, ${palette.glow} 0%, transparent 65%)`,
          filter: "blur(28px)",
        }}
      />

      {/* Machine body */}
      <motion.div
        whileHover={{ scale: 1.04, y: -4 }}
        transition={{ type: "spring", stiffness: 220, damping: 18 }}
        className="relative"
        style={{ width: "min(220px, 60vw)", aspectRatio: "1 / 1" }}
      >
        {/* Outer brass ring */}
        <div
          aria-hidden
          className="absolute inset-0 rounded-full"
          style={{
            background: palette.ring,
            boxShadow:
              "0 25px 60px rgba(0,0,0,0.85), 0 6px 14px rgba(0,0,0,0.7), inset 0 0 40px rgba(0,0,0,0.7)",
          }}
        />

        {/* Brushed striations */}
        <div
          aria-hidden
          className="absolute inset-0 rounded-full pointer-events-none mix-blend-overlay opacity-60"
          style={{
            background:
              "repeating-conic-gradient(from 0deg, rgba(255,235,180,0.4) 0deg 0.3deg, rgba(0,0,0,0.5) 0.3deg 0.7deg, transparent 0.7deg 2deg)",
            mask: "radial-gradient(circle, transparent 41%, black 42%, black 50%, transparent 50.5%)",
            WebkitMask: "radial-gradient(circle, transparent 41%, black 42%, black 50%, transparent 50.5%)",
          }}
        />

        {/* Top sheen */}
        <div
          aria-hidden
          className="absolute inset-0 rounded-full pointer-events-none"
          style={{
            background:
              "radial-gradient(ellipse 50% 22% at 50% 6%, rgba(255,235,180,0.7) 0%, transparent 60%)",
            mask: "radial-gradient(circle, transparent 41%, black 42%, black 50%, transparent 50.5%)",
            WebkitMask: "radial-gradient(circle, transparent 41%, black 42%, black 50%, transparent 50.5%)",
          }}
        />

        {/* Inner dark bezel */}
        <div
          aria-hidden
          className="absolute inset-[7%] rounded-full"
          style={{
            background:
              "radial-gradient(circle at 30% 20%, #1a1208 0%, #0a0604 50%, #030201 100%)",
            boxShadow:
              "inset 0 6px 20px rgba(0,0,0,0.95), inset 0 0 30px rgba(0,0,0,0.8)",
          }}
        />

        {/* Neon ring (glow) */}
        <motion.div
          aria-hidden
          className="absolute rounded-full pointer-events-none"
          style={{
            inset: "16%",
            border: `2px solid ${palette.neon}`,
            boxShadow: `0 0 10px ${palette.glow}, inset 0 0 10px ${palette.glow}`,
          }}
          animate={{ opacity: [0.7, 1, 0.7] }}
          transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
        />

        {/* Inner screen */}
        <div
          className="absolute rounded-full overflow-hidden flex items-center justify-center"
          style={{
            inset: "19%",
            background:
              "radial-gradient(circle at 50% 30%, #14110a 0%, #080604 70%, #040302 100%)",
            boxShadow: "inset 0 0 30px rgba(0,0,0,0.9)",
          }}
        >
          {/* Scanlines */}
          <div
            aria-hidden
            className="absolute inset-0 pointer-events-none opacity-[0.08] mix-blend-screen"
            style={{
              backgroundImage:
                "repeating-linear-gradient(0deg, rgba(255,235,180,0.5) 0 1px, transparent 1px 3px)",
            }}
          />

          {/* Big icon */}
          <div className="text-5xl drop-shadow-[0_0_8px_rgba(0,0,0,0.8)] group-hover:scale-110 transition-transform duration-500">
            {icon}
          </div>

          {/* Tiny status badge */}
          <div className="absolute top-3 left-1/2 -translate-x-1/2 flex items-center gap-1 px-2 py-0.5 rounded-full bg-black/40 border border-white/10">
            <span
              className="w-1 h-1 rounded-full animate-pulse"
              style={{ background: palette.neon, boxShadow: `0 0 4px ${palette.neon}` }}
            />
            <span
              className="text-[7px] tracking-[0.3em] uppercase"
              style={{ color: palette.neon }}
            >
              Ready
            </span>
          </div>
        </div>

        {/* Decorative screws */}
        {[30, 150, 210, 330].map((deg) => (
          <div
            key={deg}
            className="absolute left-1/2 top-1/2 w-2 h-2 rounded-full"
            style={{
              transform: `translate(-50%, -50%) rotate(${deg}deg) translateY(-44%)`,
              background:
                "radial-gradient(circle at 35% 30%, #f5d987 0%, #c9a14a 40%, #6b4a18 80%, #2a1c08 100%)",
              boxShadow:
                "inset 0 1px 1px rgba(255,255,255,0.4), 0 1px 2px rgba(0,0,0,0.6)",
            }}
          />
        ))}
      </motion.div>

      {/* Label below */}
      <div className="mt-5 text-center">
        <div className={`text-[10px] tracking-[0.3em] uppercase mb-1 ${palette.accentText}`}>
          {tagline}
        </div>
        <div className="text-lg font-light text-white group-hover:text-white transition-colors">
          {label}
        </div>
      </div>
    </Link>
  );
}