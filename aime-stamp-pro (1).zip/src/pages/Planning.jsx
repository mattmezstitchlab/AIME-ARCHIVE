import React, { useState, useEffect, useMemo } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft, Calendar, Sparkles, Loader2, Check } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { generateRetroPlan } from "@/lib/retroPlanning";

export default function Planning() {
  const [weddingDate, setWeddingDate] = useState("");
  const [busy, setBusy] = useState(false);
  const [created, setCreated] = useState(0);
  const [existing, setExisting] = useState([]);

  useEffect(() => {
    const saved = localStorage.getItem("wedding_date");
    if (saved) setWeddingDate(saved);
    base44.entities.Stamp.list().then((all) => {
      const me = base44.auth.me().catch(() => null);
      Promise.resolve(me).then((u) => {
        const mine = u ? all.filter((s) => s.created_by === u.email) : all;
        setExisting(mine);
      });
    });
  }, []);

  const plan = useMemo(() => generateRetroPlan(weddingDate), [weddingDate]);

  const handleSaveDate = (d) => {
    setWeddingDate(d);
    localStorage.setItem("wedding_date", d);
  };

  const handleGenerate = async () => {
    if (!weddingDate || busy) return;
    setBusy(true);
    setCreated(0);
    for (const task of plan) {
      await base44.entities.Stamp.create({
        text: task.text,
        category: task.category,
        subcategory: task.subcategory,
        domain: task.domain,
        task_due_date: task.due_date,
        task_status: "a_faire",
        event_name: "Mariage",
        image_url: "",
        code: "",
      });
      setCreated((c) => c + 1);
    }
    setBusy(false);
  };

  const isPast = (d) => new Date(d) < new Date();

  return (
    <div className="min-h-screen bg-black text-white px-6 pt-20 pb-16 relative overflow-hidden">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-pink-500/[0.04] rounded-full blur-3xl pointer-events-none" />
      <Link to="/" className="absolute top-6 left-6 inline-flex items-center gap-2 text-xs text-white/50 hover:text-white">
        <ArrowLeft className="w-3.5 h-3.5" /> Retour
      </Link>

      <div className="relative z-10 max-w-4xl mx-auto">
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 mb-4 rounded-full border border-white/10 bg-white/[0.02] text-[11px] tracking-[0.2em] uppercase text-pink-200">
            <Calendar className="w-3 h-3" /> Rétro-planning
          </div>
          <h1 className="text-3xl md:text-4xl font-light">Compte à rebours du mariage</h1>
          <p className="mt-2 text-sm text-white/40">
            Choisissez la date · la machine génère automatiquement votre liste de timbres-tâches.
          </p>
        </div>

        <div className="flex flex-col items-center gap-3 mb-10">
          <input
            type="date"
            value={weddingDate}
            onChange={(e) => handleSaveDate(e.target.value)}
            className="bg-white/5 border border-white/10 rounded-lg px-4 py-2.5 text-sm text-white focus:outline-none focus:border-pink-300/50"
            style={{ colorScheme: "dark" }}
          />
          {weddingDate && (
            <button
              onClick={handleGenerate}
              disabled={busy}
              className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-gradient-to-r from-pink-500/30 to-rose-500/30 border border-pink-300/40 text-sm text-pink-100 hover:from-pink-500/50 hover:to-rose-500/50 transition-all disabled:opacity-50"
            >
              {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
              {busy ? `Création… ${created}/${plan.length}` : "Imprimer toute la série"}
            </button>
          )}
        </div>

        {weddingDate && (
          <div className="space-y-2">
            {plan.map((task, idx) => {
              const already = existing.find((s) => s.text === task.text && s.task_due_date === task.due_date);
              return (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.02 }}
                  className={`flex items-center gap-4 p-3 rounded-xl border ${
                    already ? "bg-emerald-500/5 border-emerald-400/30" : isPast(task.due_date) ? "bg-amber-500/5 border-amber-400/20" : "bg-white/[0.02] border-white/10"
                  }`}
                >
                  <div className="text-[10px] font-mono text-white/40 w-20 flex-shrink-0">
                    {new Date(task.due_date).toLocaleDateString("fr-FR")}
                  </div>
                  <div className="flex-1 text-sm text-white/90">{task.text}</div>
                  <div className="text-[10px] text-white/30 capitalize">{task.subcategory || task.category}</div>
                  {already && <Check className="w-4 h-4 text-emerald-400" />}
                </motion.div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}