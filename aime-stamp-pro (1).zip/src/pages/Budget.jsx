import React, { useState, useEffect, useMemo } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft, Wallet as WalletIcon, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { CATEGORY_TREE } from "@/lib/categoryTree";

export default function Budget() {
  const [stamps, setStamps] = useState([]);
  const [loading, setLoading] = useState(true);
  const [target, setTarget] = useState(() => Number(localStorage.getItem("budget_target") || 30000));

  useEffect(() => {
    (async () => {
      const me = await base44.auth.me().catch(() => null);
      const all = await base44.entities.Stamp.list();
      const mine = me ? all.filter((s) => s.created_by === me.email) : all;
      setStamps(mine.filter((s) => s.doc_amount && s.doc_amount > 0));
      setLoading(false);
    })();
  }, []);

  const handleTarget = (v) => {
    setTarget(v);
    localStorage.setItem("budget_target", String(v));
  };

  const { byCategory, byPrestataire, total } = useMemo(() => {
    let total = 0;
    const byCategory = {};
    const byPrestataire = {};
    for (const s of stamps) {
      total += s.doc_amount;
      const c = s.category || "autre";
      byCategory[c] = (byCategory[c] || 0) + s.doc_amount;
      if (c === "prestataire" && s.subcategory) {
        byPrestataire[s.subcategory] = (byPrestataire[s.subcategory] || 0) + s.doc_amount;
      }
    }
    return { byCategory, byPrestataire, total };
  }, [stamps]);

  const remaining = target - total;
  const pct = Math.min(100, Math.round((total / target) * 100));
  const overBudget = total > target;

  const fmt = (n) => n.toLocaleString("fr-FR", { maximumFractionDigits: 0 }) + " €";

  return (
    <div className="min-h-screen bg-black text-white px-6 pt-20 pb-16 relative overflow-hidden">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-amber-500/[0.04] rounded-full blur-3xl pointer-events-none" />
      <Link to="/" className="absolute top-6 left-6 inline-flex items-center gap-2 text-xs text-white/50 hover:text-white">
        <ArrowLeft className="w-3.5 h-3.5" /> Retour
      </Link>

      <div className="relative z-10 max-w-3xl mx-auto">
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 mb-4 rounded-full border border-white/10 bg-white/[0.02] text-[11px] tracking-[0.2em] uppercase text-amber-200">
            <WalletIcon className="w-3 h-3" /> Budget mariage
          </div>
          <h1 className="text-3xl md:text-4xl font-light">Suivi des dépenses</h1>
        </div>

        {loading ? (
          <div className="flex justify-center py-20"><Loader2 className="w-6 h-6 animate-spin text-white/30" /></div>
        ) : (
          <>
            {/* Total */}
            <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-6 mb-6">
              <div className="flex items-baseline justify-between mb-3">
                <span className="text-xs uppercase tracking-[0.2em] text-white/50">Dépensé</span>
                <span className={`text-3xl font-light ${overBudget ? "text-red-300" : "text-white"}`}>{fmt(total)}</span>
              </div>
              <div className="h-2 bg-white/5 rounded-full overflow-hidden mb-3">
                <div
                  className={`h-full transition-all ${overBudget ? "bg-red-400" : "bg-gradient-to-r from-amber-300 to-emerald-400"}`}
                  style={{ width: `${pct}%` }}
                />
              </div>
              <div className="flex items-center justify-between text-xs text-white/50">
                <div className="flex items-center gap-2">
                  <span>Budget cible</span>
                  <input
                    type="number"
                    value={target}
                    onChange={(e) => handleTarget(Number(e.target.value) || 0)}
                    className="bg-black/40 border border-white/10 rounded px-2 py-0.5 w-24 text-white text-right focus:outline-none focus:border-white/30"
                  />
                  <span>€</span>
                </div>
                <span className={overBudget ? "text-red-300" : "text-emerald-300"}>
                  {overBudget ? `Dépassement ${fmt(-remaining)}` : `Reste ${fmt(remaining)}`}
                </span>
              </div>
            </div>

            {/* Par catégorie */}
            <h2 className="text-xs uppercase tracking-[0.2em] text-white/50 mb-3">Par catégorie</h2>
            <div className="space-y-2 mb-8">
              {Object.entries(byCategory).sort((a, b) => b[1] - a[1]).map(([cat, amt]) => (
                <BarRow key={cat} label={CATEGORY_TREE[cat]?.label || cat} amount={amt} max={total} fmt={fmt} />
              ))}
              {Object.keys(byCategory).length === 0 && (
                <p className="text-sm text-white/40 text-center py-4">Aucun montant enregistré. Ajoutez des devis/factures sur vos timbres.</p>
              )}
            </div>

            {/* Par sous-catégorie prestataire */}
            {Object.keys(byPrestataire).length > 0 && (
              <>
                <h2 className="text-xs uppercase tracking-[0.2em] text-white/50 mb-3">Détail prestataires</h2>
                <div className="space-y-2">
                  {Object.entries(byPrestataire).sort((a, b) => b[1] - a[1]).map(([sub, amt]) => (
                    <BarRow
                      key={sub}
                      label={CATEGORY_TREE.prestataire.sub[sub]?.label || sub}
                      amount={amt}
                      max={byCategory.prestataire || 1}
                      fmt={fmt}
                      accent="text-blue-200"
                    />
                  ))}
                </div>
              </>
            )}
          </>
        )}
      </div>
    </div>
  );
}

const BarRow = ({ label, amount, max, fmt, accent = "text-white/80" }) => {
  const pct = Math.round((amount / max) * 100);
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="rounded-lg border border-white/5 bg-white/[0.02] p-3">
      <div className="flex justify-between items-baseline mb-1.5">
        <span className={`text-sm ${accent}`}>{label}</span>
        <span className="text-sm font-mono text-white/90">{fmt(amount)}</span>
      </div>
      <div className="h-1 bg-white/5 rounded-full overflow-hidden">
        <div className="h-full bg-gradient-to-r from-amber-400/60 to-emerald-400/60" style={{ width: `${pct}%` }} />
      </div>
    </motion.div>
  );
};