import React, { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Send, Loader2, Bot } from "lucide-react";
import { base44 } from "@/api/base44Client";
import MessageBubble from "@/components/concierge/MessageBubble";

const AGENT_NAME = "wedding_planner";

export default function Concierge() {
  const [conversation, setConversation] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => {
    (async () => {
      const list = await base44.agents.listConversations({ agent_name: AGENT_NAME });
      const existing = list?.[0];
      const conv = existing
        ? await base44.agents.getConversation(existing.id)
        : await base44.agents.createConversation({
            agent_name: AGENT_NAME,
            metadata: { name: "Mon mariage" },
          });
      setConversation(conv);
      setMessages(conv.messages || []);
    })();
  }, []);

  useEffect(() => {
    if (!conversation?.id) return;
    const unsub = base44.agents.subscribeToConversation(conversation.id, (data) => {
      setMessages(data.messages || []);
    });
    return unsub;
  }, [conversation?.id]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || sending || !conversation) return;
    const text = input.trim();
    setInput("");
    setSending(true);
    await base44.agents.addMessage(conversation, { role: "user", content: text });
    setSending(false);
  };

  const SUGGESTIONS = [
    "Ajoute le devis du fleuriste à 1500€",
    "Quelles tâches me restent à faire ?",
    "Combien j'ai dépensé en traiteur ?",
    "Crée une tâche : commander les alliances pour le 15 juin",
  ];

  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-violet-500/[0.05] rounded-full blur-3xl pointer-events-none" />
      <Link to="/" className="absolute top-6 left-6 inline-flex items-center gap-2 text-xs text-white/50 hover:text-white z-10">
        <ArrowLeft className="w-3.5 h-3.5" /> Retour
      </Link>

      <div className="flex-1 flex flex-col max-w-3xl w-full mx-auto px-6 pt-20 pb-6 relative z-10 min-h-0">
        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 mb-3 rounded-full border border-white/10 bg-white/[0.02] text-[11px] tracking-[0.2em] uppercase text-violet-200">
            <Bot className="w-3 h-3" /> Concierge IA
          </div>
          <h1 className="text-2xl font-light">Wedding Planner</h1>
          <p className="mt-1 text-xs text-white/40">Demandez-lui d'ajouter, modifier ou lister vos timbres.</p>
        </div>

        <div ref={scrollRef} className="flex-1 overflow-y-auto space-y-3 pr-1 min-h-0">
          {messages.length === 0 && (
            <div className="text-center py-10">
              <p className="text-sm text-white/50 mb-4">Bonjour ! Je suis votre wedding planner. Comment puis-je vous aider ?</p>
              <div className="flex flex-wrap justify-center gap-2">
                {SUGGESTIONS.map((s) => (
                  <button
                    key={s}
                    onClick={() => setInput(s)}
                    className="text-[11px] text-white/60 hover:text-white px-3 py-1.5 rounded-full border border-white/10 hover:border-white/30 transition-all"
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}
          {messages.map((m, i) => <MessageBubble key={i} message={m} />)}
        </div>

        <div className="mt-4 flex gap-2 items-end bg-white/5 border border-white/10 rounded-2xl p-2 focus-within:border-white/30">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); handleSend(); } }}
            rows={1}
            placeholder="Parlez à votre wedding planner…"
            className="flex-1 bg-transparent outline-none text-sm text-white placeholder:text-white/30 resize-none max-h-32 px-2 py-1.5"
          />
          <button
            onClick={handleSend}
            disabled={!input.trim() || sending}
            className="w-9 h-9 rounded-xl bg-gradient-to-br from-violet-400 to-fuchsia-500 text-white flex items-center justify-center disabled:opacity-40 hover:brightness-110"
          >
            {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
          </button>
        </div>
      </div>
    </div>
  );
}