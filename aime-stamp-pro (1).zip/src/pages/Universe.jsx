import React from "react";
import { useParams, Navigate } from "react-router-dom";
import { getUniverse } from "@/lib/universes";
import Book from "@/pages/Book";

/**
 * Dedicated page for one of the 5 event universes.
 * Re-uses the Book flow but locks the event type and themes the header.
 */
export default function Universe() {
  const { id } = useParams();
  const universe = getUniverse(id);

  if (!universe) {
    return <Navigate to="/" replace />;
  }

  return <Book universe={universe} />;
}