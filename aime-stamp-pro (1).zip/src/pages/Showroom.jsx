import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Music, Sparkles, Wallet as WalletIcon, Calendar, Bot, PiggyBank } from "lucide-react";
import { UNIVERSES } from "@/lib/universes";
import MiniMachine from "@/components/showroom/MiniMachine";

export default function Showroom() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-stone-950 to-black text-white px-6 py-12 relative overflow-hidden">
      {/* Ambient halos */}
      <div className="absolute top-0 left-1/4 w-[600px] h-[600px] bg-amber-500/[0.04] rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-1/4 w-[600px] h-[600px] bg-rose-500/[0.03] rounded-full blur-3xl pointer-events-none" />

      <div className="relative z-10 max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <div className="flex flex-wrap items-center justify-center gap-2 mb-5">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-white/10 bg-white/[0.02] text-[11px] tracking-[0.25em] uppercase text-amber-200/80">
              <Music className="w-3 h-3" /> Matt Mez Sax
            </div>
            <Link
              to="/stamps"
              className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-white/10 bg-white/[0.02] text-[11px] tracking-[0.25em] uppercase text-white/60 hover:text-white hover:border-white/30 transition-all"
            >
              <Sparkles className="w-3 h-3" /> Stamps
            </Link>
            <Link
              to="/wallet"
              className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-white/10 bg-white/[0.02] text-[11px] tracking-[0.25em] uppercase text-white/60 hover:text-white hover:border-white/30 transition-all"
            >
              <WalletIcon className="w-3 h-3" /> Wallet
            </Link>
            <Link
              to="/planning"
              className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-pink-300/20 bg-pink-500/[0.04] text-[11px] tracking-[0.25em] uppercase text-pink-200/80 hover:text-pink-100 hover:border-pink-300/40 transition-all"
            >
              <Calendar className="w-3 h-3" /> Planning
            </Link>
            <Link
              to="/budget"
              className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-amber-300/20 bg-amber-500/[0.04] text-[11px] tracking-[0.25em] uppercase text-amber-200/80 hover:text-amber-100 hover:border-amber-300/40 transition-all"
            >
              <PiggyBank className="w-3 h-3" /> Budget
            </Link>
            <Link
              to="/concierge"
              className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-violet-300/20 bg-violet-500/[0.04] text-[11px] tracking-[0.25em] uppercase text-violet-200/80 hover:text-violet-100 hover:border-violet-300/40 transition-all"
            >
              <Bot className="w-3 h-3" /> Concierge
            </Link>
          </div>

          <h1 className="text-4xl md:text-6xl font-light tracking-tight">
            Le Showroom AIME
          </h1>
          <p className="mt-4 text-sm md:text-base text-white/50 font-light max-w-xl mx-auto">
            Cinq machines, cinq univers. Choisissez celle qui correspond à votre événement —
            chacune imprime son propre ticket.
          </p>
        </motion.div>

        {/* Grid of machines */}
        <motion.div
          initial="hidden"
          animate="show"
          variants={{
            hidden: {},
            show: { transition: { staggerChildren: 0.12 } },
          }}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-16 justify-items-center"
        >
          {UNIVERSES.map((u) => (
            <motion.div
              key={u.id}
              variants={{
                hidden: { opacity: 0, y: 20 },
                show: { opacity: 1, y: 0, transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1] } },
              }}
              className="w-full flex justify-center"
            >
              <MiniMachine universe={u} />
            </motion.div>
          ))}
        </motion.div>

        {/* Footer caption */}
        <div className="mt-16 text-center text-[11px] tracking-[0.3em] uppercase text-white/30">
          ✦ Cliquez sur une machine pour entrer ✦
        </div>
      </div>
    </div>
  );
}