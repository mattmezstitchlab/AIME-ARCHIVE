import React, { useEffect, useState, useMemo } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import {
  Wallet as WalletIcon,
  ArrowLeft,
  Loader2,
  CheckCircle2,
  Circle,
  Clock,
  Lock,
  FileText,
} from "lucide-react";
import { CATEGORIES } from "@/components/stamp/CategoryPicker";
import { DOC_TYPES } from "@/components/stamp/DocTypePicker";
import SearchField from "@/components/stamp/SearchField";

const STATUS = {
  a_faire: { label: "À faire", Icon: Circle, color: "text-white/50" },
  en_cours: { label: "En cours", Icon: Clock, color: "text-amber-300" },
  fait: { label: "Fait", Icon: CheckCircle2, color: "text-emerald-300" },
  utilise: { label: "Utilisé", Icon: CheckCircle2, color: "text-blue-300" },
};

export default function Wallet() {
  const [stamps, setStamps] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("all");
  const [query, setQuery] = useState("");

  const load = async () => {
    setLoading(true);
    const me = await base44.auth.me().catch(() => null);
    const allRaw = await base44.entities.Stamp.list();
    const all = [...allRaw].sort(
      (a, b) => new Date(b.created_date) - new Date(a.created_date)
    );
    const mine = me ? all.filter((s) => s.created_by === me.email) : all;
    setStamps(mine);
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, []);

  const grouped = useMemo(() => {
    const q = query.trim().toLowerCase();
    const filtered = stamps.filter((s) => {
      if (filter !== "all" && s.category !== filter) return false;
      if (!q) return true;
      const hay = [
        s.text, s.code, s.person_name, s.event_name,
        s.task_notes, s.doc_reference, s.domain, s.subcategory,
      ].filter(Boolean).join(" ").toLowerCase();
      return hay.includes(q);
    });
    const byCat = {};
    for (const s of filtered) {
      const c = s.category || "personnel";
      (byCat[c] = byCat[c] || []).push(s);
    }
    return byCat;
  }, [stamps, filter, query]);

  const updateStatus = async (id, status) => {
    await base44.entities.Stamp.update(id, { task_status: status });
    setStamps((prev) =>
      prev.map((s) => (s.id === id ? { ...s, task_status: status } : s))
    );
  };

  const cycleStatus = (current) => {
    const order = ["a_faire", "en_cours", "fait", "utilise"];
    const i = order.indexOf(current || "a_faire");
    return order[(i + 1) % order.length];
  };

  const totals = useMemo(() => {
    const t = { all: stamps.length };
    for (const s of stamps) {
      const c = s.category || "personnel";
      t[c] = (t[c] || 0) + 1;
    }
    return t;
  }, [stamps]);

  return (
    <div className="min-h-screen bg-black text-white px-6 pt-20 pb-16 relative overflow-hidden">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-white/[0.03] rounded-full blur-3xl pointer-events-none" />

      <Link
        to="/"
        className="absolute top-6 left-6 inline-flex items-center gap-2 text-xs text-white/50 hover:text-white transition-colors"
      >
        <ArrowLeft className="w-3.5 h-3.5" />
        Retour
      </Link>

      <div className="relative z-10 max-w-5xl mx-auto">
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 mb-4 rounded-full border border-white/10 bg-white/[0.02] text-[11px] tracking-[0.2em] uppercase text-white/60">
            <WalletIcon className="w-3 h-3" />
            Mon Wallet
          </div>
          <h1 className="text-3xl md:text-4xl font-light">Tickets-Timbres</h1>
          <p className="mt-2 text-sm text-white/40">
            Vos timbres classés par catégorie comme des tickets de tâches.
          </p>
        </div>

        {/* Search field */}
        <div className="max-w-md mx-auto mb-4">
          <SearchField
            value={query}
            onChange={setQuery}
            placeholder="Rechercher dans le registre (nom, code, notes…)"
            variant="wallet"
          />
        </div>

        {/* Category filters */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-8">
          <FilterChip
            active={filter === "all"}
            onClick={() => setFilter("all")}
            label="Tout"
            count={totals.all || 0}
          />
          {CATEGORIES.map(({ id, label, Icon, color }) => (
            <FilterChip
              key={id}
              active={filter === id}
              onClick={() => setFilter(id)}
              label={label}
              count={totals[id] || 0}
              Icon={Icon}
              color={color}
            />
          ))}
        </div>

        {loading && (
          <div className="flex justify-center py-20">
            <Loader2 className="w-6 h-6 animate-spin text-white/30" />
          </div>
        )}

        {!loading && stamps.length === 0 && (
          <div className="text-center py-20 text-white/40 text-sm">
            Aucun timbre. <Link to="/" className="text-white/80 underline">Générez-en un</Link>.
          </div>
        )}

        {!loading &&
          Object.entries(grouped).map(([cat, list]) => {
            const meta = CATEGORIES.find((c) => c.id === cat) || CATEGORIES[4];
            const Icon = meta.Icon;
            return (
              <div key={cat} className="mb-10">
                <div className="flex items-center gap-2 mb-4">
                  <Icon className={`w-4 h-4 ${meta.color}`} />
                  <h2 className="text-sm uppercase tracking-[0.2em] text-white/70">
                    {meta.label}
                  </h2>
                  <span className="text-xs text-white/30">({list.length})</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {list.map((stamp, idx) => (
                    <TicketCard
                      key={stamp.id}
                      stamp={stamp}
                      idx={idx}
                      onCycle={() =>
                        updateStatus(stamp.id, cycleStatus(stamp.task_status))
                      }
                    />
                  ))}
                </div>
              </div>
            );
          })}
      </div>
    </div>
  );
}

const FilterChip = ({ active, onClick, label, count, Icon, color }) => (
  <button
    onClick={onClick}
    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs border transition-all ${
      active
        ? "bg-white text-black border-white"
        : "bg-white/[0.02] border-white/10 text-white/60 hover:text-white hover:border-white/30"
    }`}
  >
    {Icon && <Icon className={`w-3 h-3 ${active ? "" : color}`} />}
    {label}
    <span className="opacity-60">({count})</span>
  </button>
);

const TicketCard = ({ stamp, idx, onCycle }) => {
  const status = STATUS[stamp.task_status || "a_faire"];
  const StatusIcon = status.Icon;
  const isLocked =
    stamp.capsule_unlock_date &&
    new Date(stamp.capsule_unlock_date) > new Date();

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: idx * 0.04 }}
      className="relative rounded-2xl border border-white/10 bg-gradient-to-b from-white/[0.04] to-white/[0.01] p-4 hover:border-white/20 transition-all"
    >
      {/* Perforated edge effect on left */}
      <div
        className="absolute left-0 top-0 bottom-0 w-2"
        style={{
          backgroundImage:
            "radial-gradient(circle at 0 50%, transparent 3px, transparent 3px)",
          maskImage:
            "radial-gradient(circle at 0 6px, transparent 3px, black 3.5px)",
          maskSize: "100% 12px",
        }}
      />

      <div className="flex gap-4">
        <div className="w-20 h-20 flex-shrink-0 flex items-center justify-center bg-black/30 rounded-lg p-1.5">
          <img
            src={stamp.image_url}
            alt={stamp.text}
            style={{ transform: `rotate(${stamp.rotation || 0}deg)` }}
            className="max-w-full max-h-full object-contain"
          />
        </div>

        <div className="flex-1 min-w-0">
          <p className="font-mono text-[10px] tracking-[0.15em] text-white/50 truncate">
            {stamp.code}
          </p>
          <p className="text-sm text-white/90 truncate mt-0.5">{stamp.text}</p>

          {(stamp.person_name || stamp.event_name) && (
            <p className="text-[11px] text-white/60 truncate mt-0.5">
              {stamp.person_name}
              {stamp.person_name && stamp.event_name ? " · " : ""}
              {stamp.event_name}
            </p>
          )}

          {stamp.task_notes && (
            <p className="text-[11px] text-white/40 mt-1 line-clamp-2">
              {stamp.task_notes}
            </p>
          )}

          <div className="flex items-center gap-2 mt-2 flex-wrap">
            {stamp.doc_type && stamp.doc_type !== "aucun" && (() => {
              const docMeta = DOC_TYPES.find((d) => d.id === stamp.doc_type);
              const DocIcon = docMeta?.Icon || FileText;
              return (
                <span
                  className={`flex items-center gap-1 px-2 py-0.5 rounded-full bg-white/5 border border-white/10 text-[10px] ${docMeta?.color || "text-white/60"}`}
                >
                  <DocIcon className="w-3 h-3" />
                  {docMeta?.label || stamp.doc_type}
                  {stamp.doc_amount ? ` · ${stamp.doc_amount}€` : ""}
                </span>
              );
            })()}

            <button
              onClick={onCycle}
              className={`flex items-center gap-1 px-2 py-0.5 rounded-full bg-white/5 border border-white/10 text-[10px] ${status.color} hover:bg-white/10 transition-all`}
              title="Cliquer pour changer"
            >
              <StatusIcon className="w-3 h-3" />
              {status.label}
            </button>

            {stamp.task_due_date && (
              <span className="text-[10px] text-white/40">
                📅 {new Date(stamp.task_due_date).toLocaleDateString("fr-FR")}
              </span>
            )}

            {isLocked && (
              <span className="flex items-center gap-1 text-[10px] text-indigo-300">
                <Lock className="w-3 h-3" />
                Capsule
              </span>
            )}
          </div>
        </div>
      </div>
    </motion.div>
  );
};