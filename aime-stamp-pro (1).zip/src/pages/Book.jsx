import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Loader2, Calendar, ArrowRight, ArrowLeft, CheckCircle2, XCircle, AlertCircle, Download, Music, ArrowLeft as ArrowLeftIcon } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { computeQuote, EVENT_TYPES, OPTIONS } from "@/lib/bookingPricing";
import { generateAimeCode } from "@/lib/stampDna";
import ThermalTicket from "@/components/book/ThermalTicket";
import CircularMachine from "@/components/book/CircularMachine";
import QuoteWizard from "@/components/book/QuoteWizard";

const isInIframe = () => { try { return window.self !== window.top; } catch { return true; } };

export default function Book({ universe = null }) {
  const [step, setStep] = useState("date");           // date | availability | quote | paying | confirmed
  const [eventDate, setEventDate] = useState("");
  const [availability, setAvailability] = useState(null); // available | unavailable | to_confirm
  const [checking, setChecking] = useState(false);
  const [booking, setBooking] = useState({
    event_date: "",
    event_type: universe?.eventTypeId || "mariage",
    event_location: "",
    client_name: "",
    client_email: "",
    duration_hours: 2,
    options: [],
    price_total: 0,
    stamp_code: "",
  });
  const [bookingId, setBookingId] = useState(null);
  const [busy, setBusy] = useState(false);
  // If universe is locked, skip the "type" step (start at duration = step 1)
  const [quoteStep, setQuoteStep] = useState(0);

  // Detect return from Stripe
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const paid = params.get("paid");
    const id = params.get("booking");
    if (paid && id) {
      (async () => {
        setBusy(true);
        const b = await base44.entities.Booking.get(id);
        setBooking(b);
        setBookingId(id);
        // Trigger contract generation if not yet done
        if (!b.contract_url) {
          await base44.functions.invoke("generateContract", { booking_id: id, mode: "deposit" });
          const refreshed = await base44.entities.Booking.get(id);
          setBooking(refreshed);
        }
        setStep("confirmed");
        setBusy(false);
        // Clean URL
        window.history.replaceState({}, "", "/book");
      })();
    }
  }, []);

  // Live recompute price
  useEffect(() => {
    if (step === "quote") {
      setBooking((b) => ({ ...b, price_total: computeQuote(b) }));
    }
  }, [booking.event_type, booking.duration_hours, booking.options, step]);

  const handleCheckDate = async () => {
    if (!eventDate || checking) return;
    setChecking(true);
    const res = await base44.functions.invoke("checkAvailability", { event_date: eventDate });
    setAvailability(res.data?.status || "to_confirm");
    setBooking((b) => ({ ...b, event_date: eventDate }));
    setStep("availability");
    setChecking(false);
  };

  const handleStartQuote = () => {
    setBooking((b) => ({ ...b, stamp_code: generateAimeCode() }));
    setQuoteStep(universe ? 1 : 0); // skip the "type" step when locked
    setStep("quote");
  };

  const handlePay = async (mode) => {
    if (busy) return;
    if (isInIframe()) {
      alert("Le paiement ne fonctionne que depuis l'app publiée. Ouvrez l'app dans un nouvel onglet.");
      return;
    }
    setBusy(true);
    // Create booking record
    const created = bookingId
      ? await base44.entities.Booking.update(bookingId, { ...booking, status: "quote" })
      : await base44.entities.Booking.create({ ...booking, status: "quote" });
    const id = bookingId || created.id;
    setBookingId(id);

    const res = await base44.functions.invoke("createBookingCheckout", { booking_id: id, mode });
    if (res.data?.url) {
      window.location.href = res.data.url;
    } else {
      alert("Erreur lors de la création du paiement");
      setBusy(false);
    }
  };

  const toggleOption = (id) => {
    setBooking((b) => ({
      ...b,
      options: b.options.includes(id) ? b.options.filter((x) => x !== id) : [...b.options, id],
    }));
  };

  const stampStatus = step === "confirmed" ? "confirmed" : step === "quote" ? "quote" : "draft";

  // Enrich booking for the ticket: turn option ids into {label, price}
  const ticketBooking = {
    ...booking,
    event_type: EVENT_TYPES.find((t) => t.id === booking.event_type)?.label || booking.event_type,
    options: (booking.options || []).map((id) => OPTIONS.find((o) => o.id === id)).filter(Boolean),
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-stone-950 to-black text-white px-6 py-8 relative overflow-hidden">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[800px] bg-amber-500/[0.04] rounded-full blur-3xl pointer-events-none" />

      <div className="relative z-10 max-w-5xl mx-auto">
        {/* Back to showroom */}
        <div className="mb-4">
          <Link
            to="/"
            className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-white/10 bg-white/[0.02] text-[11px] tracking-[0.25em] uppercase text-white/60 hover:text-white hover:border-white/30 transition-all"
          >
            <ArrowLeftIcon className="w-3 h-3" /> Showroom
          </Link>
        </div>

        {/* Header */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 mb-4 rounded-full border border-white/10 bg-white/[0.02] text-[11px] tracking-[0.25em] uppercase text-amber-200/80">
            <Music className="w-3 h-3" /> Matt Mez Sax
            {universe && <span className="text-white/40">· {universe.label}</span>}
          </div>
          <h1 className="text-3xl md:text-5xl font-light tracking-tight">
            {universe ? universe.tagline : "Réservez votre saxophoniste"}
          </h1>
          <p className="mt-3 text-sm text-white/40">
            {universe ? universe.description : "Une date, un timbre, un contrat — en 60 secondes."}
          </p>
        </div>

        {/* Single column: Circular machine with embedded form + ticket coming from slot */}
        <CircularMachine
          ticket={
            <ThermalTicket
              booking={ticketBooking}
              status={stampStatus}
              paidAt={step === "confirmed" ? (booking.updated_date || new Date().toISOString()) : null}
              ticketId={bookingId}
            />
          }
        >
          <div className="text-cyan-50">
            <AnimatePresence mode="wait">
              {step === "date" && (
                <StepBlock key="date" title="Quelle est la date de votre événement ?">
                  <div className="flex gap-3">
                    <input
                      type="date"
                      value={eventDate}
                      onChange={(e) => setEventDate(e.target.value)}
                      min={new Date().toISOString().slice(0, 10)}
                      className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-amber-300/50"
                      style={{ colorScheme: "dark" }}
                    />
                    <button
                      onClick={handleCheckDate}
                      disabled={!eventDate || checking}
                      className="px-5 rounded-xl bg-gradient-to-r from-amber-300 to-amber-500 text-black font-medium disabled:opacity-40 hover:brightness-110 transition flex items-center gap-2"
                    >
                      {checking ? <Loader2 className="w-4 h-4 animate-spin" /> : <ArrowRight className="w-4 h-4" />}
                    </button>
                  </div>
                </StepBlock>
              )}

              {step === "availability" && (
                <StepBlock key="avail" title={
                  availability === "available" ? "✨ Disponible !" :
                  availability === "unavailable" ? "Indisponible" : "À confirmer"
                }>
                  <AvailabilityCard status={availability} date={eventDate} />
                  <div className="flex gap-2 mt-5">
                    <button
                      onClick={() => { setStep("date"); setAvailability(null); }}
                      className="flex-1 py-3 rounded-xl border border-white/10 text-sm text-white/70 hover:bg-white/5"
                    >
                      Autre date
                    </button>
                    {availability !== "unavailable" && (
                      <button
                        onClick={handleStartQuote}
                        className="flex-1 py-3 rounded-xl bg-gradient-to-r from-amber-300 to-amber-500 text-black font-medium hover:brightness-110 transition"
                      >
                        Recevoir mon devis
                      </button>
                    )}
                  </div>
                </StepBlock>
              )}

              {step === "quote" && (
                <QuoteWizard
                  quoteStep={quoteStep}
                  setQuoteStep={setQuoteStep}
                  booking={booking}
                  setBooking={setBooking}
                  toggleOption={toggleOption}
                  busy={busy}
                  onPay={handlePay}
                  lockedEventType={!!universe}
                />
              )}

              {step === "confirmed" && (
                <StepBlock key="confirmed" title="✓ Réservation confirmée">
                  <p className="text-sm text-white/60 mb-5">
                    Votre timbre est validé. Le contrat et la facture sont prêts.
                  </p>
                  <div className="space-y-2">
                    {booking.contract_url && (
                      <a
                        href={booking.contract_url} target="_blank" rel="noreferrer"
                        className="flex items-center gap-3 p-3 rounded-xl bg-white/[0.04] border border-white/10 hover:border-emerald-300/40 transition"
                      >
                        <Download className="w-4 h-4 text-emerald-300" />
                        <span className="text-sm flex-1">Contrat PDF</span>
                        <span className="text-[10px] text-white/40">Télécharger</span>
                      </a>
                    )}
                    {booking.invoice_url && (
                      <a
                        href={booking.invoice_url} target="_blank" rel="noreferrer"
                        className="flex items-center gap-3 p-3 rounded-xl bg-white/[0.04] border border-white/10 hover:border-emerald-300/40 transition"
                      >
                        <Download className="w-4 h-4 text-emerald-300" />
                        <span className="text-sm flex-1">Facture PDF</span>
                        <span className="text-[10px] text-white/40">Télécharger</span>
                      </a>
                    )}
                  </div>
                  <p className="text-[11px] text-white/40 mt-4 text-center">
                    Un email de confirmation a été envoyé à {booking.client_email}.
                  </p>
                </StepBlock>
              )}
            </AnimatePresence>
          </div>
        </CircularMachine>
      </div>
    </div>
  );
}

const StepBlock = ({ title, children }) => (
  <motion.div
    initial={{ opacity: 0, y: 12 }}
    animate={{ opacity: 1, y: 0 }}
    exit={{ opacity: 0, y: -12 }}
    transition={{ duration: 0.3 }}
  >
    <h2 className="text-xl font-light mb-4">{title}</h2>
    {children}
  </motion.div>
);

const Field = ({ label, children }) => (
  <div>
    <div className="text-[10px] uppercase tracking-[0.2em] text-white/40 mb-1.5">{label}</div>
    {children}
  </div>
);

const AvailabilityCard = ({ status, date }) => {
  const cfg = {
    available:    { Icon: CheckCircle2, color: "text-emerald-300", bg: "bg-emerald-500/10 border-emerald-400/30", text: "Cette date est libre. Réservez maintenant." },
    unavailable:  { Icon: XCircle,      color: "text-red-300",     bg: "bg-red-500/10 border-red-400/30",         text: "Désolé, Matt n'est pas disponible. Choisissez une autre date." },
    to_confirm:   { Icon: AlertCircle,  color: "text-amber-300",   bg: "bg-amber-500/10 border-amber-400/30",     text: "Date possible — sous réserve de confirmation rapide." },
  }[status] || {};
  const Icon = cfg.Icon || Calendar;
  return (
    <div className={`flex items-start gap-3 p-4 rounded-xl border ${cfg.bg}`}>
      <Icon className={`w-5 h-5 ${cfg.color} flex-shrink-0 mt-0.5`} />
      <div>
        <div className="text-sm text-white/90">{new Date(date).toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}</div>
        <div className={`text-xs mt-1 ${cfg.color}`}>{cfg.text}</div>
      </div>
    </div>
  );
};