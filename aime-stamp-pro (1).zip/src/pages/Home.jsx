import React, { useState, useRef } from "react";
import { Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { Download, FileText, Sparkles, Wallet as WalletIcon, Calendar, Bot, PiggyBank } from "lucide-react";
import StampMachine from "../components/stamp/StampMachine";
import DocumentEditor from "../components/stamp/DocumentEditor";
import StampHistory from "../components/stamp/StampHistory";
import CertificateButton from "../components/stamp/CertificateButton";
import EmailSendButton from "../components/stamp/EmailSendButton";
import StampRefineButton from "../components/stamp/StampRefineButton";
import { generateAimeCode, decodeDna } from "@/lib/stampDna";
import { jsPDF } from "jspdf";

const DOC_PROMPT_THEMES = {
  aucun: "",
  devis: "official quotation document, elegant ornate banner reading 'DEVIS', engraved scrolls and quill pen",
  facture: "official invoice document, elegant banner reading 'FACTURE', engraved coins, ledger book and quill",
  attestation: "official attestation certificate, ribbon and wax seal, engraved laurel wreath, banner 'ATTESTATION'",
  paiement: "payment receipt theme, engraved coins stack, banner 'PAIEMENT', ornate currency motifs",
  contrat: "contract theme, engraved scroll with ribbon and wax seal, banner 'CONTRAT', quill",
  autre: "official document, ornate engraved frame with ribbon banner",
};

const COLOR_PROMPTS = {
  red: "deep red ink color (#B22222), classic administrative red rubber stamp",
  crimson: "crimson red ink color (#7B1E2E), deep wine red official stamp",
  orange: "vivid orange ink color (#E07A1F), warm orange rubber stamp",
  amber: "amber ink color (#D97706), rich golden-amber stamp ink",
  yellow: "bright yellow ink color (#EAB308), sunny yellow stamp ink",
  gold: "metallic gold ink color (#C9A227), luxurious premium gold foil stamp finish",
  olive: "olive green ink color (#6B7B2A), military olive stamp",
  green: "forest green ink color (#1F7A3A), classic green rubber stamp",
  emerald: "emerald green ink color (#047857), vibrant emerald stamp ink",
  teal: "teal ink color (#0E7490), deep teal stamp",
  cyan: "cyan ink color (#0891B2), bright cyan stamp ink",
  sky: "sky blue ink color (#0369A1), light azure stamp",
  blue: "navy blue ink color (#1E3A8A), official blue rubber stamp",
  indigo: "indigo ink color (#3730A3), deep indigo stamp ink",
  violet: "violet ink color (#6D28D9), rich violet stamp",
  purple: "purple ink color (#7E22CE), royal purple stamp",
  magenta: "magenta ink color (#A21CAF), vivid magenta stamp",
  pink: "pink ink color (#DB2777), bright pink stamp",
  rose: "rose ink color (#E11D48), vibrant rose stamp",
  brown: "sepia brown ink color (#78350F), antique sepia stamp ink",
  black: "pure black ink color, official black rubber stamp",
  silver: "metallic silver ink color (#9CA3AF), shimmering silver foil finish",
};

const WEAR_PROMPTS = [
  "brand new stamp, crisp clean ink, sharp edges, perfectly even ink coverage, fresh recent imprint, no imperfections, pristine condition",
  "lightly used stamp, very subtle ink unevenness, mostly clean with tiny imperfections, recent imprint",
  "moderately worn stamp, visible ink irregularities, some areas lighter, natural hand-stamped imperfections, slightly faded edges",
  "well-worn vintage stamp, significantly faded areas, broken ink lines, missing patches of ink, aged paper with yellowing, decades old appearance",
  "extremely aged antique stamp, heavily faded and broken ink, large missing sections, stained yellowed paper, cracks, very old historical document feel, almost illegible in places",
];

export default function Home() {
  const [text, setText] = useState("");
  const [color, setColor] = useState("red");
  const [wear, setWear] = useState(2);
  const [imageUrl, setImageUrl] = useState(null);
  const [loading, setLoading] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [code, setCode] = useState(null);
  const [historyKey, setHistoryKey] = useState(0);
  const [aiDescription] = useState("");
  const [category, setCategory] = useState("personnel");
  const [subcategory, setSubcategory] = useState("");
  const [domain, setDomain] = useState("");
  const [taskNotes, setTaskNotes] = useState("");
  const [taskDueDate, setTaskDueDate] = useState("");
  const [capsuleEnabled, setCapsuleEnabled] = useState(false);
  const [capsuleDate, setCapsuleDate] = useState("");
  const [capsuleMessage, setCapsuleMessage] = useState("");
  const [docType, setDocType] = useState("aucun");
  const [docAmount, setDocAmount] = useState("");
  const [docReference, setDocReference] = useState("");
  const [eventName, setEventName] = useState("");
  const [personName, setPersonName] = useState("");
  const [personPhotoUrl, setPersonPhotoUrl] = useState("");
  const [extraPhotos, setExtraPhotos] = useState([]);
  const [stampId, setStampId] = useState(null);
  const photoInputRef = useRef(null);

  const handlePickPhoto = () => photoInputRef.current?.click();

  const handleScanExtracted = (out) => {
    if (!out) return;
    if (out.doc_type) setDocType(out.doc_type);
    if (out.doc_amount != null) setDocAmount(String(out.doc_amount));
    if (out.doc_reference) setDocReference(out.doc_reference);
    if (out.event_name) setEventName(out.event_name);
    if (out.person_name) setPersonName(out.person_name);
    if (out.doc_date) setTaskDueDate(out.doc_date);
    if (out.summary) setTaskNotes(out.summary);
    if (!text && out.doc_type) {
      const parts = [out.doc_type.toUpperCase()];
      if (out.person_name) parts.push(out.person_name);
      if (out.doc_amount != null) parts.push(`${out.doc_amount}€`);
      setText(parts.join(" – "));
    }
  };

  const handleStampRefined = (newUrl) => setImageUrl(newUrl);

  const handleGeniusApply = (out) => {
    if (!out) return;
    if (out.category) setCategory(out.category);
    if (out.subcategory !== undefined) setSubcategory(out.subcategory || "");
    if (out.domain !== undefined) setDomain(out.domain || "");
    if (out.text) setText(out.text);
    if (out.doc_type) setDocType(out.doc_type);
    if (out.doc_amount != null) setDocAmount(String(out.doc_amount));
    if (out.doc_reference) setDocReference(out.doc_reference);
    if (out.event_name) setEventName(out.event_name);
    if (out.person_name) setPersonName(out.person_name);
    if (out.task_notes) setTaskNotes(out.task_notes);
    if (out.task_due_date) setTaskDueDate(out.task_due_date);
    if (out.color) setColor(out.color);
    if (typeof out.wear === "number") setWear(out.wear);
  };

  const handlePhotoSelected = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setPersonPhotoUrl(file_url);
    e.target.value = "";
  };

  const handleGenerate = async () => {
    if (loading) return;

    let finalText = text.trim();
    if (!finalText) {
      const parts = [];
      if (docType !== "aucun") parts.push(docType.toUpperCase());
      if (eventName) parts.push(eventName);
      if (personName) parts.push(personName);
      if (docAmount) parts.push(`${docAmount}€`);
      finalText = parts.join(" – ") || "AIME STAMP";
      setText(finalText);
    }

    setLoading(true);
    setImageUrl(null);
    setCode(null);

    const newCode = generateAimeCode();
    const dna = decodeDna(newCode);
    // L'utilisateur peut surcharger la couleur via l'écran "Style".
    // Si la couleur choisie existe dans nos prompts, on la respecte ; sinon on retombe sur l'ADN.
    const dnaColor = COLOR_PROMPTS[color] ? color : dna.color;
    const dnaWear = wear !== 2 ? wear : dna.wear;

    const transparentSuffix =
      "PNG with fully transparent background, no paper, no background, no shadow, isolated cutout on pure transparency, alpha channel, only the stamp visible";

    const allPhotos = [
      ...(personPhotoUrl ? [personPhotoUrl] : []),
      ...(extraPhotos || []),
    ];

    let centralBlock;
    if (allPhotos.length > 1) {
      centralBlock = `, central illustration is an engraved group portrait combining all ${allPhotos.length} people from the reference photos${
        personName ? ` (${personName} and others)` : ""
      }, vintage stamp group portrait style with fine line engraving, ornamental medallion frame, all faces visible together`;
    } else if (personPhotoUrl) {
      centralBlock = `, central illustration is an engraved portrait of the person shown in the reference photo${
        personName ? ` (${personName})` : ""
      }, classic vintage stamp portrait style with fine line engraving, framed by ornamental oval medallion`;
    } else if (docType !== "aucun" && DOC_PROMPT_THEMES[docType]) {
      centralBlock = `, central illustration depicts: ${DOC_PROMPT_THEMES[docType]}`;
    } else if (aiDescription) {
      centralBlock = `, central illustration depicts: ${aiDescription}`;
    } else {
      centralBlock = `, central illustration depicts: ${dna.theme}`;
    }

    const docBannerBlock =
      docType !== "aucun"
        ? `, a clearly readable banner at the top of the stamp shows the word "${docType.toUpperCase()}"`
        : "";
    const eventBlock = eventName ? `, event context: "${eventName}"` : "";
    const amountBlock = docAmount
      ? `, denomination prominently shows "${docAmount} EUR"`
      : "";
    const dnaBorderBlock = `, decorative border style: ${dna.border}`;
    const dateBlock = taskDueDate
      ? `, date prominently shown: "${new Date(taskDueDate).toLocaleDateString("fr-FR")}"`
      : "";
    const personBlock =
      personName && !personPhotoUrl
        ? `, name engraved on stamp: "${personName}"`
        : "";

    const prompt = `Ultra realistic vintage postage stamp, classic postal stamp design with characteristic perforated serrated edges all around, detailed engraved illustration in the center, ornamental decorative border frame, denomination value clearly visible, country name and elegant typography, ${COLOR_PROMPTS[dnaColor]}, ${WEAR_PROMPTS[dnaWear]}${centralBlock}${docBannerBlock}${eventBlock}${amountBlock}${dateBlock}${personBlock}${dnaBorderBlock}, collector philatelic stamp aesthetic, intricate fine line engraving style, main text on stamp reads exactly: "${finalText}", with a small unique serial code "${newCode}" printed in tiny clean monospace font at the bottom edge of the stamp, centered composition, ${transparentSuffix}, photographic realism, high detail macro shot`;

    try {
      const genArgs = { prompt };
      if (allPhotos.length > 0) genArgs.existing_image_urls = allPhotos;
      const res = await base44.integrations.Core.GenerateImage(genArgs);
      const newRotation = Number(dna.rotation.toFixed(2));
      setImageUrl(res.url);
      setRotation(newRotation);
      setCode(newCode);
      setColor(dnaColor);
      setWear(dnaWear);

      const created = await base44.entities.Stamp.create({
        text: finalText,
        code: newCode,
        color: dnaColor,
        wear: dnaWear,
        image_url: res.url,
        rotation: newRotation,
        ai_description: aiDescription || undefined,
        category,
        subcategory: subcategory || undefined,
        domain: domain || undefined,
        task_notes: taskNotes || undefined,
        task_due_date: taskDueDate || undefined,
        task_status: "a_faire",
        capsule_unlock_date: capsuleEnabled ? capsuleDate || undefined : undefined,
        capsule_message: capsuleEnabled ? capsuleMessage || undefined : undefined,
        doc_type: docType,
        doc_amount: docAmount ? Number(docAmount) : undefined,
        doc_reference: docReference || undefined,
        event_name: eventName || undefined,
        person_name: personName || undefined,
        person_photo_url: personPhotoUrl || undefined,
        extra_photo_urls: extraPhotos.length ? extraPhotos : undefined,
      });
      setStampId(created?.id || null);
      setHistoryKey((k) => k + 1);
    } catch (e) {
      console.error(e);
    }
    setLoading(false);
  };

  const handleSelectFromHistory = (stamp) => {
    setImageUrl(stamp.image_url);
    setRotation(stamp.rotation || 0);
    setCode(stamp.code);
    setText(stamp.text);
    setStampId(stamp.id || null);
    if (stamp.color) setColor(stamp.color);
    if (typeof stamp.wear === "number") setWear(stamp.wear);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleDownloadPNG = async () => {
    if (!imageUrl) return;
    const response = await fetch(imageUrl);
    const blob = await response.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `stamp-${Date.now()}.png`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadPDF = async () => {
    if (!imageUrl) return;
    const response = await fetch(imageUrl);
    const blob = await response.blob();
    const reader = new FileReader();
    reader.onloadend = () => {
      const pdf = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
      const pageW = 210;
      const imgSize = 100;
      const x = (pageW - imgSize) / 2;
      pdf.addImage(reader.result, "PNG", x, 60, imgSize, imgSize);
      pdf.save(`stamp-${Date.now()}.pdf`);
    };
    reader.readAsDataURL(blob);
  };

  const controlProps = {
    text, setText,
    category, setCategory,
    subcategory, setSubcategory,
    domain, setDomain,
    onGeniusApply: handleGeniusApply,
    docType, setDocType,
    docAmount, setDocAmount,
    docReference, setDocReference,
    eventName, setEventName,
    personName, setPersonName,
    personPhotoUrl, setPersonPhotoUrl,
    onPickPhoto: handlePickPhoto,
    extraPhotos, setExtraPhotos,
    onScanExtracted: handleScanExtracted,
    taskNotes, setTaskNotes,
    taskDueDate, setTaskDueDate,
    capsuleEnabled, setCapsuleEnabled,
    capsuleDate, setCapsuleDate,
    capsuleMessage, setCapsuleMessage,
    color, setColor,
    wear, setWear,
    onGenerate: handleGenerate,
  };

  return (
    <div className="min-h-screen bg-black text-white flex flex-col items-center justify-start px-6 pt-16 pb-16 relative overflow-hidden">
      {/* Subtle radial glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-white/[0.03] rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-center mb-10 relative z-10"
      >
        <div className="flex items-center justify-center gap-3 mb-5">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-white/10 bg-white/[0.02] text-[11px] tracking-[0.2em] uppercase text-white/60">
            <Sparkles className="w-3 h-3" />
            AIME Stamp
          </div>
          <Link
            to="/wallet"
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-white/10 bg-white/[0.02] text-[11px] tracking-[0.2em] uppercase text-white/60 hover:text-white hover:border-white/30 transition-all"
          >
            <WalletIcon className="w-3 h-3" />
            Wallet
          </Link>
          <Link
            to="/planning"
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-pink-300/20 bg-pink-500/[0.04] text-[11px] tracking-[0.2em] uppercase text-pink-200/80 hover:text-pink-100 hover:border-pink-300/40 transition-all"
          >
            <Calendar className="w-3 h-3" />
            Planning
          </Link>
          <Link
            to="/budget"
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-amber-300/20 bg-amber-500/[0.04] text-[11px] tracking-[0.2em] uppercase text-amber-200/80 hover:text-amber-100 hover:border-amber-300/40 transition-all"
          >
            <PiggyBank className="w-3 h-3" />
            Budget
          </Link>
          <Link
            to="/concierge"
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-violet-300/20 bg-violet-500/[0.04] text-[11px] tracking-[0.2em] uppercase text-violet-200/80 hover:text-violet-100 hover:border-violet-300/40 transition-all"
          >
            <Bot className="w-3 h-3" />
            Concierge
          </Link>
        </div>
        <h1 className="text-3xl md:text-4xl font-light tracking-tight text-white">
          Machine à imprimer des Timbres
        </h1>
        <p className="mt-2 text-sm text-white/40 font-light">
          Naviguez sur l'écran tactile · Imprimez votre timbre.
        </p>
      </motion.div>

      {/* Hidden photo input — triggered from inside the machine screen */}
      <input
        ref={photoInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handlePhotoSelected}
      />

      {/* Machine */}
      <div className="w-full max-w-xl flex flex-col items-center relative z-10">
        <StampMachine
          loading={loading}
          imageUrl={imageUrl}
          rotation={rotation}
          code={code}
          controlProps={controlProps}
        />

        <AnimatePresence>
          {imageUrl && !loading && (
            <motion.div
              key="actions"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="flex flex-col items-center gap-6 mt-6 w-full"
            >
              <div className="flex gap-3 flex-wrap justify-center">
                <button
                  onClick={handleDownloadPNG}
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-white/5 border border-white/10 text-sm text-white/80 hover:bg-white/10 hover:text-white transition-all"
                >
                  <Download className="w-4 h-4" />
                  PNG transparent
                </button>
                <button
                  onClick={handleDownloadPDF}
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-white/5 border border-white/10 text-sm text-white/80 hover:bg-white/10 hover:text-white transition-all"
                >
                  <FileText className="w-4 h-4" />
                  PDF
                </button>
                <CertificateButton
                  stamp={{ text, code, color, wear, image_url: imageUrl, rotation }}
                />
                <StampRefineButton
                  stamp={{ id: stampId, text, code, image_url: imageUrl }}
                  onRefined={handleStampRefined}
                />
                <EmailSendButton
                  stamp={{ text, code, image_url: imageUrl }}
                />
              </div>

              <DocumentEditor stampUrl={imageUrl} rotation={rotation} />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <StampHistory refreshKey={historyKey} onSelect={handleSelectFromHistory} />
    </div>
  );
}