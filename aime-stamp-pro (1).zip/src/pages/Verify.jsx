import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { CheckCircle2, XCircle, Loader2, ArrowLeft, Calendar, Lock, Unlock } from "lucide-react";

export default function Verify() {
  const { code } = useParams();
  const [stamp, setStamp] = useState(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    const load = async () => {
      try {
        const results = await base44.entities.Stamp.filter({ code });
        if (results && results.length > 0) {
          setStamp(results[0]);
        } else {
          setNotFound(true);
        }
      } catch (e) {
        setNotFound(true);
      }
      setLoading(false);
    };
    load();
  }, [code]);

  return (
    <div className="min-h-screen bg-black text-white flex flex-col items-center justify-center px-6 py-16 relative overflow-hidden">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-white/[0.03] rounded-full blur-3xl pointer-events-none" />

      <Link
        to="/"
        className="absolute top-6 left-6 inline-flex items-center gap-2 text-xs text-white/50 hover:text-white transition-colors"
      >
        <ArrowLeft className="w-3.5 h-3.5" />
        Retour
      </Link>

      <div className="relative z-10 w-full max-w-md">
        {loading && (
          <div className="flex flex-col items-center gap-3 py-20">
            <Loader2 className="w-6 h-6 animate-spin text-white/40" />
            <p className="text-xs text-white/30">Vérification…</p>
          </div>
        )}

        {!loading && notFound && (
          <div className="flex flex-col items-center text-center gap-4 p-8 rounded-2xl border border-red-400/20 bg-red-500/[0.05]">
            <XCircle className="w-12 h-12 text-red-400" />
            <div>
              <h1 className="text-xl font-light">Timbre introuvable</h1>
              <p className="text-sm text-white/50 mt-2">
                Le code <span className="font-mono text-white/80">{code}</span> ne
                correspond à aucun timbre enregistré.
              </p>
            </div>
          </div>
        )}

        {!loading && stamp && (
          <div className="flex flex-col items-center text-center gap-6">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-emerald-400/30 bg-emerald-500/[0.08] text-emerald-300">
              <CheckCircle2 className="w-4 h-4" />
              <span className="text-xs uppercase tracking-[0.2em]">
                Timbre authentique
              </span>
            </div>

            <img
              src={stamp.image_url}
              alt={stamp.text}
              style={{ transform: `rotate(${stamp.rotation || 0}deg)` }}
              className="w-64 h-64 object-contain drop-shadow-[0_8px_20px_rgba(0,0,0,0.4)]"
            />

            <div className="font-mono text-sm tracking-[0.25em] text-white/90">
              {stamp.code}
            </div>

            <div className="w-full p-5 rounded-xl border border-white/10 bg-white/[0.02] text-left space-y-3">
              <Row label="Texte" value={stamp.text} />
              {stamp.doc_type && stamp.doc_type !== "aucun" && (
                <Row label="Document" value={String(stamp.doc_type).toUpperCase()} />
              )}
              {stamp.doc_amount != null && (
                <Row label="Montant" value={`${stamp.doc_amount} €`} />
              )}
              {stamp.doc_reference && (
                <Row label="Référence" value={stamp.doc_reference} />
              )}
              {stamp.event_name && (
                <Row label="Événement" value={stamp.event_name} />
              )}
              {stamp.person_name && (
                <Row label="Personne / Prestataire" value={stamp.person_name} />
              )}
              <Row label="Couleur" value={stamp.color} />
              <Row label="Usure" value={String(stamp.wear ?? "—")} />
              <Row
                label="Émission"
                value={
                  stamp.created_date
                    ? new Date(stamp.created_date).toLocaleString("fr-FR")
                    : "—"
                }
                icon={<Calendar className="w-3 h-3" />}
              />
            </div>

            {stamp.capsule_unlock_date && <Capsule stamp={stamp} />}
          </div>
        )}
      </div>
    </div>
  );
}

const Row = ({ label, value, icon }) => (
  <div className="flex items-center justify-between text-sm">
    <span className="text-white/40 text-xs uppercase tracking-wider flex items-center gap-1.5">
      {icon}
      {label}
    </span>
    <span className="text-white/90 font-light">{value}</span>
  </div>
);

const Capsule = ({ stamp }) => {
  const unlockDate = new Date(stamp.capsule_unlock_date);
  const isUnlocked = unlockDate <= new Date();
  return (
    <div
      className={`w-full p-5 rounded-xl border text-left ${
        isUnlocked
          ? "border-emerald-400/30 bg-emerald-500/[0.06]"
          : "border-indigo-400/30 bg-indigo-500/[0.06]"
      }`}
    >
      <div className="flex items-center gap-2 mb-2">
        {isUnlocked ? (
          <Unlock className="w-4 h-4 text-emerald-300" />
        ) : (
          <Lock className="w-4 h-4 text-indigo-300" />
        )}
        <span className="text-xs uppercase tracking-[0.15em] text-white/70">
          Time Capsule
        </span>
      </div>
      {isUnlocked ? (
        <p className="text-sm text-white/90 italic leading-relaxed">
          « {stamp.capsule_message || "Capsule ouverte."} »
        </p>
      ) : (
        <p className="text-xs text-white/50">
          Scellée jusqu'au{" "}
          <span className="text-indigo-200 font-medium">
            {unlockDate.toLocaleDateString("fr-FR", {
              day: "numeric",
              month: "long",
              year: "numeric",
            })}
          </span>
          .
        </p>
      )}
    </div>
  );
};