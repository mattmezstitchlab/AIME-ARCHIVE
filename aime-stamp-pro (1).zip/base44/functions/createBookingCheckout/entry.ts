import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';
import Stripe from 'npm:stripe@14.21.0';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY'));

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { booking_id, mode } = await req.json(); // mode: 'deposit' | 'full'
    if (!booking_id) {
      return Response.json({ error: 'booking_id required' }, { status: 400 });
    }

    const booking = await base44.asServiceRole.entities.Booking.get(booking_id);
    if (!booking) {
      return Response.json({ error: 'Booking not found' }, { status: 404 });
    }

    const total = Math.round((booking.price_total || 0) * 100);
    const amount = mode === 'full' ? total : Math.round(total * 0.3);
    const label = mode === 'full' ? 'Paiement complet' : 'Acompte 30%';

    const origin = req.headers.get('origin') || req.headers.get('referer') || '';

    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      payment_method_types: ['card'],
      line_items: [{
        price_data: {
          currency: 'eur',
          product_data: {
            name: `Matt Mez Sax — ${booking.event_type || 'Prestation'}`,
            description: `${label} · ${new Date(booking.event_date).toLocaleDateString('fr-FR')}`,
          },
          unit_amount: amount,
        },
        quantity: 1,
      }],
      customer_email: booking.client_email || undefined,
      success_url: `${origin}/book?booking=${booking_id}&paid=1`,
      cancel_url: `${origin}/book?booking=${booking_id}&cancelled=1`,
      metadata: {
        base44_app_id: Deno.env.get('BASE44_APP_ID'),
        booking_id,
        payment_mode: mode || 'deposit',
      },
    });

    await base44.asServiceRole.entities.Booking.update(booking_id, {
      stripe_session_id: session.id,
    });

    return Response.json({ url: session.url, session_id: session.id });
  } catch (error) {
    console.error('createBookingCheckout error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});