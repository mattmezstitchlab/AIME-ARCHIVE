import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';
import Stripe from 'npm:stripe@14.21.0';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY'));

Deno.serve(async (req) => {
  try {
    const sig = req.headers.get('stripe-signature');
    const body = await req.text();
    const secret = Deno.env.get('STRIPE_WEBHOOK_SECRET');

    let event;
    if (secret && sig) {
      event = await stripe.webhooks.constructEventAsync(body, sig, secret);
    } else {
      event = JSON.parse(body);
    }

    if (event.type === 'checkout.session.completed') {
      const session = event.data.object;
      const bookingId = session.metadata?.booking_id;
      const mode = session.metadata?.payment_mode || 'deposit';
      if (bookingId) {
        const base44 = createClientFromRequest(req);
        const amount = (session.amount_total || 0) / 100;
        await base44.asServiceRole.entities.Booking.update(bookingId, {
          status: 'paid',
          deposit_amount: amount,
        });
        // Generate contract afterwards (best-effort)
        try {
          await base44.asServiceRole.functions.invoke('generateContract', { booking_id: bookingId, mode });
        } catch (e) {
          console.error('contract gen failed:', e);
        }
      }
    }

    return Response.json({ received: true });
  } catch (error) {
    console.error('stripeBookingWebhook error:', error);
    return Response.json({ error: error.message }, { status: 400 });
  }
});