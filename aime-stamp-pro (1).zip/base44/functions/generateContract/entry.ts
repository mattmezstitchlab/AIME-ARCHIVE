import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';
import { jsPDF } from 'npm:jspdf@2.5.1';

const buildPdf = (booking, kind) => {
  const pdf = new jsPDF({ unit: 'mm', format: 'a4' });
  const W = pdf.internal.pageSize.getWidth();

  pdf.setDrawColor(180, 150, 80);
  pdf.setLineWidth(1);
  pdf.rect(10, 10, W - 20, 277);

  pdf.setFont('helvetica', 'bold');
  pdf.setFontSize(11);
  pdf.setTextColor(120, 100, 60);
  pdf.text('AIME STAMP MACHINE — MATT MEZ SAX', W / 2, 24, { align: 'center' });

  pdf.setFontSize(24);
  pdf.setTextColor(20, 20, 20);
  pdf.text(kind === 'invoice' ? 'FACTURE' : 'CONTRAT DE PRESTATION', W / 2, 42, { align: 'center' });

  pdf.setFontSize(10);
  pdf.setFont('helvetica', 'normal');
  pdf.setTextColor(80, 80, 80);
  pdf.text(`Émis le ${new Date().toLocaleDateString('fr-FR')}`, W / 2, 50, { align: 'center' });

  let y = 70;
  const row = (k, v) => {
    pdf.setFont('helvetica', 'bold');
    pdf.setTextColor(50, 50, 50);
    pdf.text(`${k}`, 25, y);
    pdf.setFont('helvetica', 'normal');
    pdf.setTextColor(30, 30, 30);
    pdf.text(String(v ?? '—'), 80, y);
    y += 8;
  };

  row('Client', booking.client_name || '—');
  row('Email', booking.client_email || '—');
  row('Téléphone', booking.client_phone || '—');
  row("Date de l'événement", new Date(booking.event_date).toLocaleDateString('fr-FR'));
  row("Type d'événement", booking.event_type || '—');
  row('Lieu', booking.event_location || '—');
  row('Durée', `${booking.duration_hours || 2} h`);
  row('Code timbre', booking.stamp_code || '—');

  y += 5;
  pdf.setDrawColor(200);
  pdf.line(25, y, W - 25, y);
  y += 10;

  pdf.setFont('helvetica', 'bold');
  pdf.setFontSize(13);
  pdf.text('MONTANT', 25, y);
  pdf.text(`${(booking.price_total || 0).toLocaleString('fr-FR')} € TTC`, W - 25, y, { align: 'right' });
  y += 8;

  if (booking.deposit_amount) {
    pdf.setFontSize(10);
    pdf.setFont('helvetica', 'normal');
    pdf.setTextColor(20, 120, 60);
    pdf.text('Payé', 25, y);
    pdf.text(`${booking.deposit_amount.toLocaleString('fr-FR')} €`, W - 25, y, { align: 'right' });
    y += 6;
    const remaining = (booking.price_total || 0) - booking.deposit_amount;
    if (remaining > 0.01) {
      pdf.setTextColor(180, 100, 0);
      pdf.text('Solde dû', 25, y);
      pdf.text(`${remaining.toLocaleString('fr-FR')} €`, W - 25, y, { align: 'right' });
      y += 6;
    }
  }

  y += 10;
  pdf.setTextColor(80, 80, 80);
  pdf.setFontSize(9);
  pdf.setFont('helvetica', 'italic');
  const intro = kind === 'invoice'
    ? "La présente facture atteste du paiement reçu pour la prestation détaillée ci-dessus."
    : "Le présent contrat engage Matt Mez Sax à fournir la prestation musicale décrite ci-dessus à la date convenue. Toute annulation à moins de 30 jours entraîne la conservation de l'acompte.";
  const lines = pdf.splitTextToSize(intro, W - 50);
  pdf.text(lines, 25, y);
  y += lines.length * 5 + 10;

  pdf.setFontSize(8);
  pdf.setTextColor(120, 120, 120);
  pdf.text('Document généré automatiquement par AIME Stamp Machine', W / 2, 285, { align: 'center' });

  return pdf.output('arraybuffer');
};

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { booking_id, mode } = await req.json();
    const booking = await base44.asServiceRole.entities.Booking.get(booking_id);
    if (!booking) {
      return Response.json({ error: 'Booking not found' }, { status: 404 });
    }

    const contractBytes = buildPdf(booking, 'contract');
    const invoiceBytes = buildPdf(booking, 'invoice');

    const contractFile = new File([contractBytes], `contrat-${booking_id}.pdf`, { type: 'application/pdf' });
    const invoiceFile = new File([invoiceBytes], `facture-${booking_id}.pdf`, { type: 'application/pdf' });

    const [{ file_url: contract_url }, { file_url: invoice_url }] = await Promise.all([
      base44.asServiceRole.integrations.Core.UploadFile({ file: contractFile }),
      base44.asServiceRole.integrations.Core.UploadFile({ file: invoiceFile }),
    ]);

    await base44.asServiceRole.entities.Booking.update(booking_id, {
      contract_url,
      invoice_url,
      status: mode === 'full' ? 'confirmed' : 'paid',
    });

    return Response.json({ contract_url, invoice_url });
  } catch (error) {
    console.error('generateContract error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});