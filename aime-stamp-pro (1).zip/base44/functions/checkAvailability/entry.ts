import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { event_date } = await req.json();
    if (!event_date) {
      return Response.json({ error: 'event_date required' }, { status: 400 });
    }

    // Look for existing CONFIRMED or PAID bookings on that date
    const all = await base44.asServiceRole.entities.Booking.filter({ event_date });
    const blocking = all.filter((b) => ['paid', 'confirmed'].includes(b.status));

    let status;
    if (blocking.length > 0) status = 'unavailable';
    else {
      // Day-of-week heuristic: Saturdays = "to_confirm" (likely busy), others = available
      const d = new Date(event_date);
      const dow = d.getUTCDay();
      const diffDays = Math.ceil((d - new Date()) / (1000 * 60 * 60 * 24));
      if (diffDays < 7) status = 'to_confirm';
      else status = 'available';
    }

    return Response.json({ status, date: event_date });
  } catch (error) {
    console.error('checkAvailability error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});