import GridEditor from './pages/GridEditor';
import Beethoven from './pages/Beethoven';
import Shop from './pages/Shop';
import MySales from './pages/MySales';
import AdminRevenue from './pages/AdminRevenue';
import MyPurchases from './pages/MyPurchases';
import Profile from './pages/Profile';
import GridEditorWrapper from './pages/GridEditorWrapper';
import Colors from './pages/Colors';
import Settings from './pages/Settings';
import Account from './pages/Account';
import AdminDashboard from './pages/AdminDashboard';
import ResetPassword from './pages/ResetPassword';
import VibratoryGallery from './pages/VibratoryGallery';
import Pricing from './pages/Pricing';
import StitchTypes from './pages/StitchTypes';
import StitchTechConfig from './pages/StitchTechConfig';
import ColorManager from './pages/ColorManager';
import Projects from './pages/Projects';
import VendreCreation from './pages/VendreCreation';
import DashboardProfil from './pages/DashboardProfil';
import __Layout from './Layout.jsx';


export const PAGES = {
    "GridEditor": GridEditor,
    "Beethoven": Beethoven,
    "Shop": Shop,
    "MySales": MySales,
    "AdminRevenue": AdminRevenue,
    "MyPurchases": MyPurchases,
    "Profile": Profile,
    "GridEditorWrapper": GridEditorWrapper,
    "Colors": Colors,
    "Settings": Settings,
    "Account": Account,
    "AdminDashboard": AdminDashboard,
    "ResetPassword": ResetPassword,
    "VibratoryGallery": VibratoryGallery,
    "Pricing": Pricing,
    "StitchTypes": StitchTypes,
    "StitchTechConfig": StitchTechConfig,
    "ColorManager": ColorManager,
    "Projects": Projects,
    "VendreCreation": VendreCreation,
    "DashboardProfil": DashboardProfil,
}

export const pagesConfig = {
    mainPage: "GridEditor",
    Pages: PAGES,
    Layout: __Layout,
};