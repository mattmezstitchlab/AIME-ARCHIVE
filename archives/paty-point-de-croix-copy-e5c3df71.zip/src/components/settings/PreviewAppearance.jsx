import React from 'react';
import { cn } from '@/lib/utils';

export default function PreviewAppearance({ settings }) {
  const isDark = settings.displayMode === 'dark';
  const textScale = settings.textSize / 100;
  const highContrast = settings.contrast === 'high';
  
  return (
    <div className={cn(
      "rounded-lg p-4 border transition-all",
      isDark ? "bg-slate-900 border-slate-700" : "bg-white border-slate-200"
    )}>
      <div className="space-y-3">
        <h3 
          className={cn(
            "font-semibold transition-all",
            isDark ? (highContrast ? "text-white" : "text-slate-100") : (highContrast ? "text-black" : "text-slate-900")
          )}
          style={{ fontSize: `${16 * textScale}px` }}
        >
          Exemple de texte
        </h3>
        <p 
          className={cn(
            "transition-all",
            isDark ? (highContrast ? "text-slate-100" : "text-slate-300") : (highContrast ? "text-slate-900" : "text-slate-600")
          )}
          style={{ fontSize: `${14 * textScale}px` }}
        >
          Ceci est un aperçu de l'apparence de votre interface PATYBEE.
        </p>
        <button 
          className={cn(
            "px-4 py-2 rounded-lg font-medium transition-all",
            settings.reduceAnimations && "transition-none",
            !settings.disableAnimations && "hover:scale-105",
            isDark ? "bg-slate-700 text-white hover:bg-slate-600" : "bg-slate-900 text-white hover:bg-slate-800"
          )}
          style={{ fontSize: `${14 * textScale}px` }}
        >
          Bouton exemple
        </button>
      </div>
    </div>
  );
}