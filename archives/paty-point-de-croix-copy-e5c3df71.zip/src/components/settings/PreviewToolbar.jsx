import React from 'react';
import { Hand, Pipette, Eraser, Sun } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function PreviewToolbar({ settings }) {
  const isCompact = settings.toolbarCompact;
  const showLabels = settings.showToolLabels;
  const position = settings.toolbarPosition;
  const iconSize = isCompact ? 16 : 20;
  
  const tools = [
    { icon: Hand, label: 'Déplacer' },
    { icon: Pipette, label: 'Pipette' },
    { icon: Eraser, label: 'Gomme' },
    { icon: Sun, label: 'Zone' }
  ];
  
  return (
    <div className="flex justify-center">
      <div 
        className={cn(
          "bg-white border border-slate-200 rounded-lg p-2 flex gap-2",
          position === 'left' && "flex-col",
          position === 'right' && "flex-col",
          position === 'floating' && "flex-row shadow-lg"
        )}
      >
        {tools.map((Tool, i) => (
          <div 
            key={i}
            className={cn(
              "flex items-center gap-2 p-2 rounded hover:bg-slate-100 cursor-pointer transition-colors",
              !showLabels && "justify-center",
              isCompact && "p-1"
            )}
          >
            <Tool.icon size={iconSize} className="text-slate-700" />
            {showLabels && (
              <span className="text-xs text-slate-700">{Tool.label}</span>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}