import React from 'react';

export default function PreviewVisual({ settings }) {
  const opacity = settings.visualOpacity / 100;
  const quality = settings.visualQuality;
  
  return (
    <div className="flex justify-center">
      <div className="relative bg-slate-100 border border-slate-200 rounded" style={{ width: 120, height: 120 }}>
        {/* Image de fond (simulée) */}
        {settings.showVisualBehind && (
          <div 
            className="absolute inset-0 rounded"
            style={{ 
              opacity,
              background: quality === 'high' 
                ? 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'
                : quality === 'low'
                ? 'linear-gradient(135deg, #a8a8a8 0%, #c0c0c0 100%)'
                : 'linear-gradient(135deg, #89a4d6 0%, #9b7fb8 100%)',
              filter: quality === 'low' ? 'blur(2px)' : 'none'
            }}
          />
        )}
        
        {/* Grille par-dessus */}
        <svg className="absolute inset-0 w-full h-full">
          {[0, 30, 60, 90, 120].map((pos, i) => (
            <React.Fragment key={i}>
              <line x1={pos} y1="0" x2={pos} y2="120" stroke="#333" strokeWidth="1" opacity="0.3" />
              <line x1="0" y1={pos} x2="120" y2={pos} stroke="#333" strokeWidth="1" opacity="0.3" />
            </React.Fragment>
          ))}
        </svg>
        
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="text-xs font-semibold text-slate-700 bg-white/80 px-2 py-1 rounded">
            Grille + Visuel
          </span>
        </div>
      </div>
    </div>
  );
}