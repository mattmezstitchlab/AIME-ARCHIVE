import React from 'react';

// Mini-grille de prévisualisation des réglages
export default function SettingsPreview({ settings }) {
  const gridSize = 10;
  const cellSize = 20;
  
  // Couleurs de démo
  const demoPattern = [
    { row: 2, col: 3, color: '#C8341F', symbol: '●' },
    { row: 2, col: 4, color: '#C8341F', symbol: '●' },
    { row: 3, col: 2, color: '#26823D', symbol: '▲' },
    { row: 3, col: 3, color: '#26823D', symbol: '▲' },
    { row: 3, col: 4, color: '#1E4C8A', symbol: '■' },
    { row: 3, col: 5, color: '#1E4C8A', symbol: '■' },
    { row: 4, col: 3, color: '#F6A14A', symbol: '◆' },
    { row: 4, col: 4, color: '#F6A14A', symbol: '◆' },
    { row: 5, col: 4, color: '#000000', symbol: '✕' },
    { row: 6, col: 3, color: '#C8341F', symbol: '●' },
    { row: 6, col: 4, color: '#C8341F', symbol: '●' },
    { row: 6, col: 5, color: '#26823D', symbol: '▲' },
    { row: 7, col: 4, color: '#1E4C8A', symbol: '■' },
  ];

  const isDark = settings.displayMode === 'dark';
  const bgColor = isDark ? '#1a1a2e' : '#ffffff';
  const gridColor = isDark ? 'rgba(255,255,255,0.15)' : `rgba(0,0,0,${settings.gridOpacity / 100})`;
  const textColor = isDark ? '#ffffff' : '#000000';
  const symbolScale = settings.symbolSize / 100;

  // Appliquer le mode daltonien aux couleurs
  const applyColorBlindFilter = (hex) => {
    if (settings.colorBlindMode === 'none') return hex;
    // Simulation simplifiée
    if (settings.colorBlindMode === 'protanopia' || settings.colorBlindMode === 'deuteranopia') {
      if (hex === '#C8341F') return '#B8860B'; // Rouge → Jaune-brun
      if (hex === '#26823D') return '#4682B4'; // Vert → Bleu
    }
    if (settings.colorBlindMode === 'tritanopia') {
      if (hex === '#1E4C8A') return '#8B4513'; // Bleu → Marron
      if (hex === '#F6A14A') return '#FF69B4'; // Orange → Rose
    }
    return hex;
  };

  return (
    <div 
      className="rounded-lg border overflow-hidden"
      style={{ 
        backgroundColor: bgColor,
        fontSize: `${settings.textSize}%`
      }}
    >
      <div className="p-3 border-b" style={{ borderColor: isDark ? '#333' : '#e2e8f0' }}>
        <span className="text-sm font-medium" style={{ color: textColor }}>
          Aperçu en direct
        </span>
      </div>
      
      <div className="p-4 flex items-center justify-center">
        <svg 
          width={gridSize * cellSize + 2} 
          height={gridSize * cellSize + 2}
          style={{ border: `1px solid ${gridColor}` }}
        >
          {/* Fond */}
          <rect width="100%" height="100%" fill={bgColor} />
          
          {/* Grille */}
          {settings.showGrid && (
            <g>
              {Array.from({ length: gridSize + 1 }).map((_, i) => (
                <React.Fragment key={i}>
                  <line
                    x1={i * cellSize}
                    y1={0}
                    x2={i * cellSize}
                    y2={gridSize * cellSize}
                    stroke={gridColor}
                    strokeWidth={i % 5 === 0 ? 2 : 1}
                  />
                  <line
                    x1={0}
                    y1={i * cellSize}
                    x2={gridSize * cellSize}
                    y2={i * cellSize}
                    stroke={gridColor}
                    strokeWidth={i % 5 === 0 ? 2 : 1}
                  />
                </React.Fragment>
              ))}
            </g>
          )}
          
          {/* Pattern de démo */}
          {demoPattern.map((cell, idx) => (
            <g key={idx}>
              {/* Couleur de fond */}
              <rect
                x={cell.col * cellSize + 1}
                y={cell.row * cellSize + 1}
                width={cellSize - 2}
                height={cellSize - 2}
                fill={applyColorBlindFilter(cell.color)}
                opacity={0.3}
              />
              {/* Symbole */}
              <text
                x={cell.col * cellSize + cellSize / 2}
                y={cell.row * cellSize + cellSize / 2 + 1}
                textAnchor="middle"
                dominantBaseline="middle"
                fontSize={12 * symbolScale}
                fontWeight="bold"
                fill={textColor}
              >
                {cell.symbol}
              </text>
            </g>
          ))}
          
          {/* Repère central */}
          {settings.showCenterMarker && (
            <g>
              <line
                x1={gridSize * cellSize / 2}
                y1={gridSize * cellSize / 2 - 15}
                x2={gridSize * cellSize / 2}
                y2={gridSize * cellSize / 2 + 15}
                stroke="#FF0000"
                strokeWidth={2}
              />
              <line
                x1={gridSize * cellSize / 2 - 15}
                y1={gridSize * cellSize / 2}
                x2={gridSize * cellSize / 2 + 15}
                y2={gridSize * cellSize / 2}
                stroke="#FF0000"
                strokeWidth={2}
              />
              <circle
                cx={gridSize * cellSize / 2}
                cy={gridSize * cellSize / 2}
                r={10}
                fill="none"
                stroke="#FF0000"
                strokeWidth={2}
              />
            </g>
          )}
        </svg>
      </div>
      
      {/* Mini-carte aperçu */}
      {settings.showMinimap && (
        <div 
          className="mx-4 mb-4 p-2 rounded border"
          style={{ 
            backgroundColor: isDark ? '#2a2a3e' : '#f8fafc',
            borderColor: isDark ? '#444' : '#e2e8f0',
            alignSelf: settings.minimapPosition === 'bottom-left' ? 'flex-start' : 'flex-end'
          }}
        >
          <div className="text-xs mb-1" style={{ color: textColor, opacity: 0.6 }}>
            Mini-carte ({settings.minimapPosition === 'bottom-left' ? 'Bas gauche' : 'Bas droite'})
          </div>
          <div 
            className="w-16 h-12 rounded"
            style={{ 
              background: `linear-gradient(135deg, ${isDark ? '#333' : '#e2e8f0'} 0%, ${isDark ? '#444' : '#cbd5e1'} 100%)`,
              border: '2px solid #3b82f6'
            }}
          />
        </div>
      )}
      
      {/* Indicateur sauvegarde auto */}
      <div 
        className="px-4 pb-4 text-xs"
        style={{ color: textColor, opacity: 0.6 }}
      >
        {settings.autoSave 
          ? `Sauvegarde auto : toutes les ${settings.autoSaveInterval} min`
          : 'Sauvegarde manuelle uniquement'
        }
      </div>
    </div>
  );
}