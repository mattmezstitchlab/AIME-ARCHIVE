import React from 'react';
import { cn } from '@/lib/utils';

export default function PreviewSymbols({ settings }) {
  const symbolScale = settings.symbolSize / 100;
  const xlMode = settings.xlMode;
  const enhanced = settings.enhancedReadability;
  
  const symbols = ['●', '■', '▲', '★', '◆', '○', '□', '△', '☆'];
  const colors = ['#E3242B', '#2F80ED', '#27AE60', '#F2994A', '#9B51E0', '#EB5757'];
  
  return (
    <div className="flex justify-center">
      <div className="bg-white border border-slate-200 rounded p-3">
        <div className="grid grid-cols-3 gap-2">
          {symbols.slice(0, 9).map((symbol, i) => (
            <div 
              key={i}
              className={cn(
                "flex items-center justify-center rounded border",
                enhanced ? "border-slate-900" : "border-slate-300"
              )}
              style={{ 
                width: 30,
                height: 30,
                backgroundColor: colors[i % colors.length] + '20'
              }}
            >
              <span 
                className={cn(
                  "transition-all",
                  enhanced ? "text-black font-bold" : "text-slate-900",
                  xlMode && "font-black"
                )}
                style={{ 
                  fontSize: `${(xlMode ? 18 : 14) * symbolScale}px`,
                  color: enhanced ? '#000000' : colors[i % colors.length]
                }}
              >
                {symbol}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}