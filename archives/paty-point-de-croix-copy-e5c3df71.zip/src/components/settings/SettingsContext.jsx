import React, { createContext, useContext, useState, useEffect } from 'react';
import { toast } from 'sonner';

const SettingsContext = createContext();

const DEFAULT_SETTINGS = {
  // Apparence
  displayMode: 'light', // 'light' | 'dark' | 'auto'
  textSize: 100, // 80–150
  contrast: 'standard',
  reduceAnimations: false,
  disableAnimations: false,
  
  // Mini-carte
  showMinimap: true,
  autoHideMinimap: false,
  minimapSize: 'normal',
  minimapDisplayMode: 'standard',
  minimapGraduationFrequency: 20,
  viewportThickness: 2,
  colorOpacity: 50,
  showMinimapNumbering: true,
  showMinimapCenterMarker: true,
  recenterOnCentralMarker: false,
  minimapPosition: 'bottom-right', // 'bottom-left' | 'bottom-right'
  minimapLayers: {
    progress: true,
    colors: true,
    zones: true
  },
  
  // Grille
  gridLineThickness: 1,
  gridOpacity: 30,
  showGrid: true,
  showEvery5: false,
  showNumbers: true,
  show10x10: true,
  showSecondary: false,
  centerMarkerSize: 10,
  centerMarkerOpacity: 100,
  showCenterMarker: true,
  centerMarkerStyle: 'cross-circle',
  mosaicLineThickness: 10,
  mosaicLineOpacity: 60,
  showMosaicInGrid: true,
  showMosaicInMinimap: true,
  showMosaicLabels: false,
  
  // Symboles & Couleurs
  symbolSize: 100,
  enhancedReadability: false,
  xlMode: false,
  disableThinSymbols: false,
  autoReplace: false,
  colorPalette: 'dmc',
  autoAdjustColor: false,
  colorBlindMode: 'none',
  colorPaletteMode: 'detailed', // simple, detailed
  colorPaletteSize: 'normal', // mini, normal, large
  colorPaletteStyle: 'classic', // classic, tabs
  autoExpandTab: true,
  highlightActiveColor: true,
  detailsPanelPosition: 'tab', // tab, sidebar
  
  // Visuel importé
  showVisualBehind: false,
  visualOpacity: 30,
  visualQuality: 'normal',
  autoAdaptSize: true,
  blendMode: false,
  
  // Palette d'outils
  toolbarPosition: 'left',
  showToolLabels: false,
  toolbarCompact: false,
  toolbarSize: 'normal',
  visibleTools: {
    pan: true,
    picker: true,
    eraser: true,
    dailyZone: true,
    symbolColor: true,
    selection: true,
    import: true,
    zoom: true,
    preview: true
  },
  
  // Navigation
  panMode: 'click-drag',
  zoomMode: 'wheel', // 'wheel' | 'buttons' | 'trackpad'
  zoomSmooth: true,
  zoomCenterPointer: true,
  verticalScroll: true,
  horizontalScroll: true,
  invertZoom: false,
  zoomSensitivity: 50,
  
  // Export & Sauvegarde
  autoSave: true,
  autoSaveInterval: 5, // minutes
  confirmBeforeClose: true,
  showSaveMessage: true,
  autoFileName: true,
  
  // Avancés
  showTechnicalIds: false,
  showPixelLimits: false,
  precisionMode: false,
  performanceMode: false,
  compatibility: false,
  defaultDpi: 150,
  
  // PatyBee IA
  patybee: {
    enableAnimations: true,
    reducedMotion: false,
    autoShowHelp: true
  },
  
  // Onboarding & Intro screens
  showNewGridIntro: true
};

export function SettingsProvider({ children }) {
  const [settings, setSettings] = useState(DEFAULT_SETTINGS);
  const [isLoaded, setIsLoaded] = useState(false);

  // Charger les réglages au montage
  useEffect(() => {
    const savedSettings = localStorage.getItem('patybee_settings');
    if (savedSettings) {
      try {
        const parsed = JSON.parse(savedSettings);
        setSettings({ ...DEFAULT_SETTINGS, ...parsed });
      } catch (e) {
        console.error('Error loading settings:', e);
      }
    }
    setIsLoaded(true);
  }, []);

  // Sauvegarder les réglages
  const saveSettings = (newSettings) => {
    setSettings(newSettings);
    localStorage.setItem('patybee_settings', JSON.stringify(newSettings));
    toast.success('Vos réglages ont été enregistrés et appliqués');
  };

  // Réinitialiser les réglages
  const resetSettings = () => {
    setSettings(DEFAULT_SETTINGS);
    localStorage.setItem('patybee_settings', JSON.stringify(DEFAULT_SETTINGS));
    toast.success('Réglages réinitialisés aux valeurs par défaut');
  };

  // Mettre à jour un réglage spécifique
  const updateSetting = (key, value) => {
    setSettings(prev => {
      const newSettings = { ...prev, [key]: value };
      return newSettings;
    });
  };

  return (
    <SettingsContext.Provider value={{ 
      settings, 
      saveSettings, 
      resetSettings, 
      updateSetting,
      isLoaded 
    }}>
      {children}
    </SettingsContext.Provider>
  );
}

export function useSettings() {
  const context = useContext(SettingsContext);
  if (!context) {
    throw new Error('useSettings must be used within a SettingsProvider');
  }
  return context;
}