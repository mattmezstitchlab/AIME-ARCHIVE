import React from 'react';
import { cn } from '@/lib/utils';

export default function PreviewMinimap({ settings }) {
  const baseSize = settings.minimapSize === 'compact' ? 80 : settings.minimapSize === 'large' ? 120 : 100;
  const showNumbers = settings.showMinimapNumbering;
  const showCenter = settings.showMinimapCenterMarker;
  const showMosaic = settings.showMinimapMosaicLines;
  
  return (
    <div className="flex justify-center">
      <div 
        className="relative bg-slate-50 border-2 border-slate-300 rounded"
        style={{ width: baseSize, height: baseSize }}
      >
        {/* Grille */}
        <svg className="absolute inset-0 w-full h-full">
          {/* Lignes de grille */}
          {[0, 0.2, 0.4, 0.6, 0.8, 1].map((pos, i) => (
            <React.Fragment key={i}>
              <line 
                x1={`${pos * 100}%`} y1="0" 
                x2={`${pos * 100}%`} y2="100%" 
                stroke="#E2E8F0" 
                strokeWidth="1"
              />
              <line 
                x1="0" y1={`${pos * 100}%`} 
                x2="100%" y2={`${pos * 100}%`} 
                stroke="#E2E8F0" 
                strokeWidth="1"
              />
            </React.Fragment>
          ))}
          
          {/* Lignes de mosaïque */}
          {showMosaic && settings.minimapLayers.mosaic && (
            <>
              <line x1="50%" y1="0" x2="50%" y2="100%" stroke="rgba(255,0,0,0.6)" strokeWidth="2" />
              <line x1="0" y1="50%" x2="100%" y2="50%" stroke="rgba(255,0,0,0.6)" strokeWidth="2" />
            </>
          )}
          
          {/* Repère central */}
          {showCenter && (
            <>
              <line x1="48%" y1="50%" x2="52%" y2="50%" stroke="#FF0000" strokeWidth="1.5" />
              <line x1="50%" y1="48%" x2="50%" y2="52%" stroke="#FF0000" strokeWidth="1.5" />
              <circle cx="50%" cy="50%" r="2" fill="#FF0000" />
            </>
          )}
          
          {/* Viewport (cadre bleu) */}
          <rect 
            x="30%" y="30%" 
            width="40%" height="40%" 
            fill="rgba(59, 130, 246, 0.2)" 
            stroke="#3B82F6" 
            strokeWidth="2"
          />
          
          {/* Progression si activée */}
          {settings.minimapLayers.progress && (
            <rect 
              x="10%" y="10%" 
              width="30%" height="30%" 
              fill="rgba(34, 197, 94, 0.3)" 
            />
          )}
        </svg>
        
        {/* Numérotation */}
        {showNumbers && (
          <div className="absolute inset-0 pointer-events-none">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 text-[8px] text-slate-600">0</div>
            <div className="absolute top-1/2 left-0 -translate-y-1/2 text-[8px] text-slate-600">0</div>
            <div className="absolute top-0 left-1/4 -translate-x-1/2 text-[8px] text-slate-500">-50</div>
            <div className="absolute top-0 right-1/4 translate-x-1/2 text-[8px] text-slate-500">50</div>
          </div>
        )}
      </div>
    </div>
  );
}