import React from 'react';

export default function PreviewGrid({ settings }) {
  const gridOpacity = settings.gridOpacity / 100;
  const lineThickness = settings.gridLineThickness;
  const showCenter = settings.showCenterMarker;
  const centerSize = settings.centerMarkerSize;
  const centerOpacity = settings.centerMarkerOpacity / 100;
  const mosaicThickness = settings.mosaicLineThickness;
  const mosaicOpacity = settings.mosaicLineOpacity / 100;
  
  return (
    <div className="flex justify-center">
      <div className="relative bg-slate-50 border border-slate-200 rounded" style={{ width: 150, height: 150 }}>
        <svg className="absolute inset-0 w-full h-full">
          {/* Grille principale */}
          {settings.showGrid && (
            <>
              {[0, 15, 30, 45, 60, 75, 90, 105, 120, 135, 150].map((pos, i) => (
                <React.Fragment key={i}>
                  <line 
                    x1={pos} y1="0" 
                    x2={pos} y2="150" 
                    stroke="#CBD5E1" 
                    strokeWidth={lineThickness}
                    opacity={gridOpacity}
                  />
                  <line 
                    x1="0" y1={pos} 
                    x2="150" y2={pos} 
                    stroke="#CBD5E1" 
                    strokeWidth={lineThickness}
                    opacity={gridOpacity}
                  />
                </React.Fragment>
              ))}
            </>
          )}
          
          {/* Lignes de mosaïque */}
          {settings.showMosaicInGrid && (
            <>
              <line 
                x1="75" y1="0" 
                x2="75" y2="150" 
                stroke="#FF0000" 
                strokeWidth={mosaicThickness}
                opacity={mosaicOpacity}
              />
              <line 
                x1="0" y1="75" 
                x2="150" y2="75" 
                stroke="#FF0000" 
                strokeWidth={mosaicThickness}
                opacity={mosaicOpacity}
              />
            </>
          )}
          
          {/* Repère central */}
          {showCenter && (
            <g opacity={centerOpacity}>
              {/* Croix */}
              <line 
                x1={75 - centerSize} y1="75" 
                x2={75 + centerSize} y2="75" 
                stroke="#FF0000" 
                strokeWidth="2"
              />
              <line 
                x1="75" y1={75 - centerSize} 
                x2="75" y2={75 + centerSize} 
                stroke="#FF0000" 
                strokeWidth="2"
              />
              
              {/* Cercle si style approprié */}
              {(settings.centerMarkerStyle === 'cross-circle' || settings.centerMarkerStyle === 'cross-halo') && (
                <circle 
                  cx="75" 
                  cy="75" 
                  r={centerSize * 0.8} 
                  fill="none" 
                  stroke="#FF0000" 
                  strokeWidth="2"
                />
              )}
              
              {/* Halo si activé */}
              {settings.centerMarkerStyle === 'cross-halo' && (
                <circle 
                  cx="75" 
                  cy="75" 
                  r={centerSize * 1.5} 
                  fill="rgba(255, 0, 0, 0.1)" 
                />
              )}
            </g>
          )}
        </svg>
      </div>
    </div>
  );
}