import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Move, Palette, Sparkles, ZoomIn, ZoomOut, Target, Maximize2 } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function PreviewMiniMap4D({ settings }) {
  const [activeTab, setActiveTab] = useState('navigation');
  const [zoomLevel, setZoomLevel] = useState('1×');
  const [autoSync, setAutoSync] = useState(true);

  return (
    <div className="bg-white border-2 border-slate-200 rounded-xl p-4 space-y-3">
      {/* En-tête */}
      <div className="space-y-1">
        <h3 className="text-sm font-semibold text-slate-900">Mini-carte 4D™</h3>
        <p className="text-xs text-slate-600">
          Aperçu miniature haute-précision de ta grille.
          Navigation instantanée + zoom + analyse couleur + IA-Focus.
        </p>
      </div>

      {/* Info zone et zoom */}
      <div className="flex items-center justify-between text-xs">
        <div className="space-y-0.5">
          <div className="text-slate-900 font-medium">Mini-carte 4D™</div>
          <div className="text-slate-500">Zone sélectionnée : dynamique</div>
        </div>
        <div className="space-y-1">
          <div className="text-slate-700 font-medium">Zoom :</div>
          <Select value={zoomLevel} onValueChange={setZoomLevel}>
            <SelectTrigger className="w-20 h-7 text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1×">1×</SelectItem>
              <SelectItem value="5×">5×</SelectItem>
              <SelectItem value="10×">10×</SelectItem>
              <SelectItem value="20×">20×</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Canvas preview */}
      <div className="relative w-60 h-60 mx-auto bg-slate-50 border border-slate-200 rounded-xl overflow-hidden">
        <svg className="absolute inset-0 w-full h-full">
          {/* Grille */}
          {[0, 0.2, 0.4, 0.6, 0.8, 1].map((pos, i) => (
            <React.Fragment key={i}>
              <line 
                x1={`${pos * 100}%`} y1="0" 
                x2={`${pos * 100}%`} y2="100%" 
                stroke="#E2E8F0" 
                strokeWidth="1"
              />
              <line 
                x1="0" y1={`${pos * 100}%`} 
                x2="100%" y2={`${pos * 100}%`} 
                stroke="#E2E8F0" 
                strokeWidth="1"
              />
            </React.Fragment>
          ))}
          
          {/* Repère central */}
          <line x1="48%" y1="50%" x2="52%" y2="50%" stroke="#EF4444" strokeWidth="2" />
          <line x1="50%" y1="48%" x2="50%" y2="52%" stroke="#EF4444" strokeWidth="2" />
          <circle cx="50%" cy="50%" r="3" fill="#EF4444" />
          
          {/* Viewport actuel */}
          <rect 
            x="30%" y="30%" 
            width="40%" height="40%" 
            fill="rgba(59, 130, 246, 0.15)" 
            stroke="#3B82F6" 
            strokeWidth="2.5"
          />
          
          {/* Zones de couleur (si onglet couleurs) */}
          {activeTab === 'colors' && (
            <>
              <rect x="10%" y="10%" width="20%" height="20%" fill="rgba(239, 68, 68, 0.4)" />
              <rect x="70%" y="70%" width="20%" height="20%" fill="rgba(34, 197, 94, 0.4)" />
            </>
          )}
          
          {/* Focus IA (si onglet IA) */}
          {activeTab === 'ia' && (
            <circle cx="50%" cy="50%" r="15%" fill="rgba(139, 92, 246, 0.3)" stroke="#8B5CF6" strokeWidth="2" />
          )}
        </svg>
      </div>

      {/* Onglets de mode */}
      <div className="flex gap-1.5">
        <Button
          size="sm"
          variant={activeTab === 'navigation' ? 'default' : 'outline'}
          onClick={() => setActiveTab('navigation')}
          className={cn(
            "flex-1 h-8 text-xs",
            activeTab === 'navigation' && "bg-slate-900 hover:bg-slate-800"
          )}
        >
          <Move className="w-3.5 h-3.5 mr-1.5" />
          Navigation
        </Button>
        <Button
          size="sm"
          variant={activeTab === 'colors' ? 'default' : 'outline'}
          onClick={() => setActiveTab('colors')}
          className={cn(
            "flex-1 h-8 text-xs",
            activeTab === 'colors' && "bg-slate-900 hover:bg-slate-800"
          )}
        >
          <Palette className="w-3.5 h-3.5 mr-1.5" />
          Couleurs
        </Button>
        <Button
          size="sm"
          variant={activeTab === 'ia' ? 'default' : 'outline'}
          onClick={() => setActiveTab('ia')}
          className={cn(
            "flex-1 h-8 text-xs",
            activeTab === 'ia' && "bg-slate-900 hover:bg-slate-800"
          )}
        >
          <Sparkles className="w-3.5 h-3.5 mr-1.5" />
          IA-Focus
        </Button>
      </div>

      {/* Boutons de zoom */}
      <div className="flex gap-1.5">
        <Button size="sm" variant="outline" className="flex-1 h-8">
          <ZoomIn className="w-3.5 h-3.5" />
        </Button>
        <Button size="sm" variant="outline" className="flex-1 h-8">
          <ZoomOut className="w-3.5 h-3.5" />
        </Button>
        <Button size="sm" variant="outline" className="flex-1 h-8">
          <Target className="w-3.5 h-3.5" />
        </Button>
        <Button size="sm" variant="outline" className="flex-1 h-8">
          <Maximize2 className="w-3.5 h-3.5" />
        </Button>
      </div>

      {/* Switch auto-sync */}
      <div className="flex items-center justify-between pt-2 border-t border-slate-200">
        <Label htmlFor="auto-sync" className="text-xs text-slate-700">
          Synchronisation automatique
        </Label>
        <Switch 
          id="auto-sync"
          checked={autoSync} 
          onCheckedChange={setAutoSync}
          className="scale-90"
        />
      </div>
    </div>
  );
}