import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Lock, Sparkles } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '../../utils';

const FEATURE_REQUIREMENTS = {
  import_image: ['basic', 'premium', 'creator'],
  import_pdf: ['premium', 'creator'],
  publish_shop: ['creator'],
  patybee_full: ['premium', 'creator'],
  advanced_tools: ['premium', 'creator']
};

export default function FeatureGate({ feature, children, fallback }) {
  const navigate = useNavigate();
  const [showUpgradeDialog, setShowUpgradeDialog] = useState(false);

  const { data: user } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me(),
  });

  const { data: subscription } = useQuery({
    queryKey: ['user-subscription', user?.email],
    queryFn: async () => {
      if (!user) return null;
      const subs = await base44.entities.UserSubscription.filter({ user_email: user.email });
      return subs[0] || { plan: 'free', status: 'none' };
    },
    enabled: !!user
  });

  const requiredPlans = FEATURE_REQUIREMENTS[feature] || [];
  const currentPlan = subscription?.plan || 'free';
  const hasAccess = requiredPlans.includes(currentPlan) || subscription?.status === 'trial';

  if (hasAccess) {
    return children;
  }

  const handleClick = () => {
    setShowUpgradeDialog(true);
  };

  const recommendedPlan = requiredPlans.includes('creator') ? 'creator' : 
                         requiredPlans.includes('premium') ? 'premium' : 'basic';

  return (
    <>
      <div onClick={handleClick} className="cursor-pointer">
        {fallback || (
          <div className="relative">
            <div className="absolute inset-0 bg-slate-900/10 backdrop-blur-sm rounded-lg flex items-center justify-center z-10">
              <div className="bg-white rounded-lg p-4 shadow-lg">
                <Lock className="w-6 h-6 text-slate-600 mx-auto mb-2" />
                <p className="text-sm text-slate-700">Fonction réservée</p>
              </div>
            </div>
            <div className="opacity-50 pointer-events-none">
              {children}
            </div>
          </div>
        )}
      </div>

      <Dialog open={showUpgradeDialog} onOpenChange={setShowUpgradeDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-purple-600" />
              Fonction réservée
            </DialogTitle>
            <DialogDescription>
              Cette fonctionnalité est disponible avec l'abonnement <strong>{recommendedPlan === 'creator' ? 'Créateur' : recommendedPlan === 'premium' ? 'Premium' : 'Basic'}</strong>.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <p className="text-sm text-slate-600">
              Passez à un forfait supérieur pour débloquer toutes les fonctionnalités de PatyBee.
            </p>
            
            <div className="flex gap-3">
              <Button
                onClick={() => {
                  setShowUpgradeDialog(false);
                  navigate(createPageUrl('Pricing'));
                }}
                className="flex-1 bg-purple-600 hover:bg-purple-700"
              >
                Voir les forfaits
              </Button>
              <Button
                onClick={() => setShowUpgradeDialog(false)}
                variant="outline"
                className="flex-1"
              >
                Plus tard
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}