import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Music, FileText, Download, Sparkles, Play, Pause } from 'lucide-react';
import { useVibratoryEngine } from '../patybee/VibratoryEngineContext';
import { usePatyBeeMatching } from '../patybee/PatyBeeMatchingContext';
import { toast } from 'sonner';

export default function VibratoryGallery() {
  const {
    certificate,
    generatedMusic,
    generatedStory,
    vibrationCode,
    createVibratoryArt,
    exportVibrationPackage
  } = useVibratoryEngine();
  
  const { userSignals, creativeProfile } = usePatyBeeMatching();
  const [isGenerating, setIsGenerating] = useState(false);
  const [showStory, setShowStory] = useState(false);
  const [showMusic, setShowMusic] = useState(false);

  const { data: user } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me(),
  });

  const { data: userProfile } = useQuery({
    queryKey: ['user-profile', user?.email],
    queryFn: async () => {
      if (!user) return null;
      const profiles = await base44.entities.UserProfile.filter({ created_by: user.email });
      return profiles[0] || null;
    },
    enabled: !!user,
  });

  const handleGenerateVibration = async () => {
    if (!userProfile || !creativeProfile) {
      toast.error('Complète ton profil créatif d\'abord');
      return;
    }
    
    setIsGenerating(true);
    
    try {
      await createVibratoryArt(creativeProfile, userSignals, null);
      toast.success('Ta vibration unique a été créée ! 🎨✨');
    } catch (error) {
      console.error('Erreur génération vibration:', error);
      toast.error('Erreur lors de la génération');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleExport = async () => {
    try {
      await exportVibrationPackage();
      toast.success('Package vibratoire exporté');
    } catch (error) {
      console.error('Erreur export:', error);
      toast.error('Erreur lors de l\'export');
    }
  };

  if (!certificate && !isGenerating) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-slate-100 p-8">
        <div className="container mx-auto max-w-4xl">
          <Card className="bg-gradient-to-br from-amber-50 to-yellow-50 border-amber-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-3">
                <Sparkles className="w-6 h-6 text-amber-600" />
                Crée ta Signature Vibratoire
              </CardTitle>
              <CardDescription>
                PatyBee transforme ton profil créatif en une œuvre unique : musique, histoire et certificat.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="bg-white p-6 rounded-lg">
                  <h3 className="font-semibold mb-4">Qu'est-ce qu'une Signature Vibratoire ?</h3>
                  <ul className="space-y-2 text-sm text-slate-600">
                    <li>• Une musique générée selon tes couleurs et ton rythme de broderie</li>
                    <li>• Une histoire poétique inspirée de tes symboles et émotions</li>
                    <li>• Un code vibratoire unique qui t'identifie</li>
                    <li>• Un certificat artistique exportable</li>
                  </ul>
                </div>
                
                <Button
                  onClick={handleGenerateVibration}
                  disabled={isGenerating}
                  className="w-full bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-600 hover:to-yellow-600"
                  size="lg"
                >
                  {isGenerating ? 'Création en cours...' : 'Créer ma Signature Vibratoire'}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (isGenerating) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-slate-100 p-8 flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="p-8 text-center">
            <div className="animate-spin w-16 h-16 border-4 border-amber-500 border-t-transparent rounded-full mx-auto mb-4"></div>
            <p className="text-slate-600">PatyBee crée ta vibration unique...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-slate-100 p-8">
      <div className="container mx-auto max-w-6xl">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-slate-900 mb-2">Ta Galerie Vibratoire</h1>
          <p className="text-slate-600">Ton univers créatif transformé en œuvre d'art</p>
        </div>

        {/* Certificat principal */}
        <Card className="mb-8 bg-gradient-to-br from-amber-50 to-yellow-50 border-amber-200">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span className="flex items-center gap-2">
                <Sparkles className="w-6 h-6 text-amber-600" />
                Certificat Vibratoire
              </span>
              <Button onClick={handleExport} variant="outline" size="sm">
                <Download className="w-4 h-4 mr-2" />
                Exporter
              </Button>
            </CardTitle>
            <CardDescription>{certificate?.signature}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* Code vibratoire */}
              <div className="bg-white p-4 rounded-lg">
                <p className="text-xs text-slate-500 mb-2">Code Vibratoire Unique</p>
                <p className="font-mono text-sm break-all text-slate-700">
                  {vibrationCode}
                </p>
              </div>

              {/* Palette */}
              {certificate?.palette && certificate.palette.length > 0 && (
                <div className="bg-white p-4 rounded-lg">
                  <p className="text-xs text-slate-500 mb-3">Palette Créative</p>
                  <div className="flex flex-wrap gap-2">
                    {certificate.palette.slice(0, 10).map((color, idx) => (
                      <div
                        key={idx}
                        className="w-12 h-12 rounded-lg shadow-md border-2 border-white"
                        style={{ backgroundColor: color.hex }}
                        title={color.name}
                      />
                    ))}
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Musique */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Music className="w-5 h-5 text-purple-600" />
                Ta Musique Vibratoire
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Button
                onClick={() => setShowMusic(!showMusic)}
                variant="outline"
                className="w-full mb-4"
              >
                {showMusic ? <Pause className="w-4 h-4 mr-2" /> : <Play className="w-4 h-4 mr-2" />}
                {showMusic ? 'Masquer' : 'Voir les détails'}
              </Button>
              
              {showMusic && generatedMusic && (
                <div className="space-y-2 text-sm">
                  <pre className="bg-slate-50 p-4 rounded-lg whitespace-pre-wrap text-xs">
                    {generatedMusic.description}
                  </pre>
                  <p className="text-xs text-slate-500 italic">
                    La musique sera générée prochainement via une API musicale
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Histoire */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-blue-600" />
                Ton Histoire Vibratoire
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Button
                onClick={() => setShowStory(!showStory)}
                variant="outline"
                className="w-full mb-4"
              >
                {showStory ? 'Masquer' : 'Lire l\'histoire'}
              </Button>
              
              {showStory && generatedStory && (
                <div className="bg-slate-50 p-4 rounded-lg">
                  <p className="text-sm leading-relaxed whitespace-pre-wrap text-slate-700">
                    {generatedStory}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Régénérer */}
        <div className="mt-8 text-center">
          <Button
            onClick={handleGenerateVibration}
            disabled={isGenerating}
            variant="outline"
          >
            Régénérer la vibration
          </Button>
        </div>
      </div>
    </div>
  );
}