import React from 'react';

export default function WatermarkOverlay({ type = 'preview' }) {
  if (type === 'preview') {
    return (
      <div className="absolute inset-0 pointer-events-none">
        {/* Grille de watermarks */}
        <div className="absolute inset-0 grid grid-cols-2 grid-rows-2 gap-4 p-4 opacity-30">
          {[...Array(4)].map((_, i) => (
            <div
              key={i}
              className="flex items-center justify-center text-white font-bold text-2xl transform rotate-[-20deg]"
              style={{
                textShadow: '2px 2px 4px rgba(0,0,0,0.5)'
              }}
            >
              <div className="text-center">
                <div className="text-3xl mb-2">🐝</div>
                <div>PATYBEE</div>
                <div className="text-sm mt-1">Aperçu</div>
                <div className="text-xs">Non reproductible</div>
              </div>
            </div>
          ))}
        </div>
        
        {/* Message en bas */}
        <div className="absolute bottom-0 left-0 right-0 bg-black/70 text-white text-xs py-2 px-3 text-center">
          Aperçu protégé – Grille complète disponible après achat
        </div>
      </div>
    );
  }

  if (type === 'export') {
    return (
      <div className="absolute bottom-2 right-2 pointer-events-none opacity-60">
        <div className="bg-white/90 px-3 py-2 rounded text-xs text-slate-700 shadow-md">
          <div className="font-semibold">PATYBEE – Licence personnelle</div>
          <div className="text-[10px] mt-0.5">Usage strictement personnel</div>
        </div>
      </div>
    );
  }

  return null;
}