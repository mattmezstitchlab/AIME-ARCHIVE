import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Eye, ShoppingCart, Shield } from 'lucide-react';

export default function PurchaseDialog({ open, onClose, grid }) {
  if (!grid) return null;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[900px] max-h-[80vh] flex flex-col p-0 overflow-hidden">
        {/* Header fixe */}
        <div className="px-6 pt-6 pb-4 border-b border-slate-200">
          <div className="inline-block bg-slate-100 border border-slate-300 px-3 py-1 rounded-full text-xs text-slate-700 mb-3">
            <Shield className="w-3 h-3 inline mr-1" />
            Licence personnelle
          </div>
          <h2 className="text-2xl font-bold text-slate-900 mb-1">{grid.title}</h2>
          <p className="text-slate-600">par {grid.creator_name}</p>
        </div>

        {/* Contenu scrollable */}
        <div className="flex-1 overflow-y-auto px-6 py-4 space-y-6">
          {/* Image de prévisualisation */}
          {grid.preview_image && (
            <div className="space-y-2">
              <div 
                className="w-full bg-slate-100 rounded-lg overflow-hidden relative select-none"
                style={{ 
                  maxHeight: '40vh',
                  userSelect: 'none', 
                  WebkitUserSelect: 'none' 
                }}
                onContextMenu={(e) => e.preventDefault()}
              >
                <img
                  src={grid.preview_image}
                  alt={grid.title}
                  className="w-full h-full object-contain blur-[1px]"
                  draggable="false"
                />
                {/* Watermark en overlay discret */}
                <div className="absolute inset-0 pointer-events-none">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-white/30 text-4xl font-bold rotate-[-45deg] select-none">
                      PATYBEE
                    </div>
                  </div>
                </div>
              </div>
              <p className="text-xs text-slate-500 text-center">
                Aperçu protégé – Grille complète disponible après achat
              </p>
            </div>
          )}

          {/* Description */}
          {grid.description && (
            <div>
              <h4 className="font-semibold text-slate-900 mb-2">Description</h4>
              <p className="text-slate-600 leading-relaxed">{grid.description}</p>
            </div>
          )}

          {/* Statistiques */}
          <div className="flex items-center gap-6 text-sm text-slate-600">
            <span className="flex items-center gap-2">
              <Eye className="w-4 h-4" />
              {grid.views_count || 0} vues
            </span>
          </div>

          {/* Information */}
          <div className="bg-slate-50 rounded-lg p-4 text-sm text-slate-600">
            <p>
              ℹ️ Le système de paiement sera bientôt disponible.
            </p>
          </div>
        </div>

        {/* Footer fixe avec bouton */}
        <div className="sticky bottom-0 bg-white border-t border-slate-200 px-6 py-4">
          <div className="flex items-center justify-between gap-4">
            <div className="flex-1">
              <p className="text-sm text-slate-600 mb-1">Prochainement disponible</p>
            </div>
            <Button 
              variant="outline" 
              onClick={onClose}
              className="border-slate-900 text-slate-900 hover:bg-slate-100"
            >
              Fermer
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}