import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import {
  ChevronDown,
  ChevronRight,
  Filter,
  Zap,
  RotateCcw,
  Sparkles,
  TrendingUp,
  Palette,
  Activity
} from 'lucide-react';
import { cn } from '@/lib/utils';

export default function PatyBeeFilterSortPro({ onFiltersChange, currentFilters = {} }) {
  const [isOpen, setIsOpen] = useState(false);
  const [expandedSections, setExpandedSections] = useState({
    filter: true,
    sort: false,
    smart: false
  });
  const [filters, setFilters] = useState({
    // Filtres de grille
    density: [],
    ambiance: [],
    stitchTypes: [],
    colorEmotion: [],
    gradients: [],
    
    // Tri des couleurs
    sortByQuantity: null,
    sortByDmc: null,
    sortByImpact: null,
    sortBySpeed: null,
    
    // Smart IA
    aiEnabled: true,
    aiAntiError: false,
    aiFluidExp: false,
    
    ...currentFilters
  });

  const toggleSection = (section) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  const updateFilter = (key, value) => {
    const newFilters = { ...filters, [key]: value };
    setFilters(newFilters);
    if (onFiltersChange) {
      onFiltersChange(newFilters);
    }
  };

  const toggleArrayFilter = (key, value) => {
    const current = filters[key] || [];
    const newValue = current.includes(value)
      ? current.filter(v => v !== value)
      : [...current, value];
    updateFilter(key, newValue);
  };

  const resetFilters = () => {
    const defaultFilters = {
      density: [],
      ambiance: [],
      stitchTypes: [],
      colorEmotion: [],
      gradients: [],
      sortByQuantity: null,
      sortByDmc: null,
      sortByImpact: null,
      sortBySpeed: null,
      aiEnabled: true,
      aiAntiError: false,
      aiFluidExp: false
    };
    setFilters(defaultFilters);
    if (onFiltersChange) {
      onFiltersChange(defaultFilters);
    }
  };

  const hasActiveFilters = () => {
    return filters.density.length > 0 ||
           filters.ambiance.length > 0 ||
           filters.stitchTypes.length > 0 ||
           filters.colorEmotion.length > 0 ||
           filters.gradients.length > 0 ||
           filters.sortByQuantity ||
           filters.sortByDmc ||
           filters.sortByImpact ||
           filters.sortBySpeed ||
           filters.aiAntiError ||
           filters.aiFluidExp;
  };

  const FilterButton = ({ active, onClick, children, aiRecommended }) => (
    <button
      onClick={onClick}
      className={cn(
        "relative px-3 py-1.5 text-xs rounded-md transition-all",
        active
          ? "bg-black text-white font-medium"
          : "bg-slate-100 text-slate-700 hover:bg-slate-200"
      )}
    >
      {children}
      {aiRecommended && filters.aiEnabled && (
        <Badge className="absolute -top-1 -right-1 h-4 w-4 p-0 flex items-center justify-center bg-yellow-400 text-black">
          <Zap className="w-2.5 h-2.5" />
        </Badge>
      )}
    </button>
  );

  return (
    <div className="relative">
      {/* Bouton principal */}
      <Button
        onClick={() => setIsOpen(!isOpen)}
        variant="outline"
        className="gap-2 bg-[#F5F5F5] hover:bg-[#EDEDED] border-slate-300"
      >
        <Filter className="w-4 h-4" />
        <Zap className="w-3 h-3" />
        <span>Filtres & Tri Pro™</span>
        {hasActiveFilters() && (
          <Badge className="ml-1 h-5 px-1.5 bg-black text-white text-xs">
            {[...filters.density, ...filters.ambiance, ...filters.stitchTypes].length}
          </Badge>
        )}
        <ChevronDown className={cn("w-4 h-4 transition-transform", isOpen && "rotate-180")} />
      </Button>

      {/* Menu déroulant */}
      {isOpen && (
        <div className="absolute top-full right-0 mt-2 w-80 bg-white border border-slate-200 rounded-lg shadow-xl z-50 overflow-hidden">
          <div className="max-h-[600px] overflow-y-auto">
            
            {/* Section 1: Filtrer la grille */}
            <div className="border-b border-slate-200">
              <button
                onClick={() => toggleSection('filter')}
                className="w-full px-4 py-3 flex items-center justify-between hover:bg-slate-50 transition-colors"
              >
                <div className="flex items-center gap-2">
                  <Activity className="w-4 h-4 text-slate-600" />
                  <span className="font-medium text-sm">Filtrer la grille</span>
                </div>
                {expandedSections.filter ? (
                  <ChevronDown className="w-4 h-4 text-slate-400" />
                ) : (
                  <ChevronRight className="w-4 h-4 text-slate-400" />
                )}
              </button>

              {expandedSections.filter && (
                <div className="px-4 pb-4 space-y-4">
                  {/* Densité de points */}
                  <div>
                    <label className="text-xs font-medium text-slate-700 mb-2 block">
                      Densité de points
                    </label>
                    <div className="flex flex-wrap gap-2">
                      <FilterButton
                        active={filters.density.includes('simple')}
                        onClick={() => toggleArrayFilter('density', 'simple')}
                      >
                        Zones simples
                      </FilterButton>
                      <FilterButton
                        active={filters.density.includes('detailed')}
                        onClick={() => toggleArrayFilter('density', 'detailed')}
                      >
                        Zones détaillées
                      </FilterButton>
                      <FilterButton
                        active={filters.density.includes('complex')}
                        onClick={() => toggleArrayFilter('density', 'complex')}
                        aiRecommended
                      >
                        Zones très complexes
                      </FilterButton>
                    </div>
                  </div>

                  {/* Ambiance de broderie™ */}
                  <div>
                    <label className="text-xs font-medium text-slate-700 mb-2 block">
                      Ambiance de broderie™
                    </label>
                    <div className="flex flex-wrap gap-2">
                      <FilterButton
                        active={filters.ambiance.includes('relaxing')}
                        onClick={() => toggleArrayFilter('ambiance', 'relaxing')}
                      >
                        Zones relaxantes
                      </FilterButton>
                      <FilterButton
                        active={filters.ambiance.includes('fast')}
                        onClick={() => toggleArrayFilter('ambiance', 'fast')}
                      >
                        Zones rapides
                      </FilterButton>
                      <FilterButton
                        active={filters.ambiance.includes('meditative')}
                        onClick={() => toggleArrayFilter('ambiance', 'meditative')}
                      >
                        Zones méditatives
                      </FilterButton>
                      <FilterButton
                        active={filters.ambiance.includes('technical')}
                        onClick={() => toggleArrayFilter('ambiance', 'technical')}
                      >
                        Zones techniques
                      </FilterButton>
                      <FilterButton
                        active={filters.ambiance.includes('satisfying')}
                        onClick={() => toggleArrayFilter('ambiance', 'satisfying')}
                        aiRecommended
                      >
                        Zones satisfaisantes
                      </FilterButton>
                    </div>
                  </div>

                  {/* Types de points présents */}
                  <div>
                    <label className="text-xs font-medium text-slate-700 mb-2 block">
                      Types de points présents
                    </label>
                    <div className="flex flex-wrap gap-2">
                      <FilterButton
                        active={filters.stitchTypes.includes('full')}
                        onClick={() => toggleArrayFilter('stitchTypes', 'full')}
                      >
                        Points complets
                      </FilterButton>
                      <FilterButton
                        active={filters.stitchTypes.includes('half')}
                        onClick={() => toggleArrayFilter('stitchTypes', 'half')}
                      >
                        Demi-points
                      </FilterButton>
                      <FilterButton
                        active={filters.stitchTypes.includes('backstitch')}
                        onClick={() => toggleArrayFilter('stitchTypes', 'backstitch')}
                      >
                        Backstitch
                      </FilterButton>
                      <FilterButton
                        active={filters.stitchTypes.includes('french')}
                        onClick={() => toggleArrayFilter('stitchTypes', 'french')}
                      >
                        Nœuds français
                      </FilterButton>
                      <FilterButton
                        active={filters.stitchTypes.includes('beads')}
                        onClick={() => toggleArrayFilter('stitchTypes', 'beads')}
                      >
                        Perles
                      </FilterButton>
                      <FilterButton
                        active={filters.stitchTypes.includes('metallic')}
                        onClick={() => toggleArrayFilter('stitchTypes', 'metallic')}
                      >
                        Métalliques
                      </FilterButton>
                    </div>
                  </div>

                  {/* Émotion des couleurs */}
                  <div>
                    <label className="text-xs font-medium text-slate-700 mb-2 block">
                      Émotion des couleurs
                    </label>
                    <div className="flex flex-wrap gap-2">
                      <FilterButton
                        active={filters.colorEmotion.includes('warm')}
                        onClick={() => toggleArrayFilter('colorEmotion', 'warm')}
                      >
                        Chaudes
                      </FilterButton>
                      <FilterButton
                        active={filters.colorEmotion.includes('cold')}
                        onClick={() => toggleArrayFilter('colorEmotion', 'cold')}
                      >
                        Froides
                      </FilterButton>
                      <FilterButton
                        active={filters.colorEmotion.includes('neutral')}
                        onClick={() => toggleArrayFilter('colorEmotion', 'neutral')}
                      >
                        Neutres
                      </FilterButton>
                      <FilterButton
                        active={filters.colorEmotion.includes('soft')}
                        onClick={() => toggleArrayFilter('colorEmotion', 'soft')}
                      >
                        Douces
                      </FilterButton>
                      <FilterButton
                        active={filters.colorEmotion.includes('vibrant')}
                        onClick={() => toggleArrayFilter('colorEmotion', 'vibrant')}
                      >
                        Vibrantes
                      </FilterButton>
                    </div>
                  </div>

                  {/* Zones avec dégradés */}
                  <div>
                    <label className="text-xs font-medium text-slate-700 mb-2 block">
                      Zones avec dégradés
                    </label>
                    <div className="flex flex-wrap gap-2">
                      <FilterButton
                        active={filters.gradients.includes('soft')}
                        onClick={() => toggleArrayFilter('gradients', 'soft')}
                      >
                        Dégradés doux
                      </FilterButton>
                      <FilterButton
                        active={filters.gradients.includes('strong')}
                        onClick={() => toggleArrayFilter('gradients', 'strong')}
                      >
                        Dégradés forts
                      </FilterButton>
                      <FilterButton
                        active={filters.gradients.includes('abrupt')}
                        onClick={() => toggleArrayFilter('gradients', 'abrupt')}
                      >
                        Mélanges brusques
                      </FilterButton>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Section 2: Trier les couleurs */}
            <div className="border-b border-slate-200">
              <button
                onClick={() => toggleSection('sort')}
                className="w-full px-4 py-3 flex items-center justify-between hover:bg-slate-50 transition-colors"
              >
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-slate-600" />
                  <span className="font-medium text-sm">Trier les couleurs</span>
                </div>
                {expandedSections.sort ? (
                  <ChevronDown className="w-4 h-4 text-slate-400" />
                ) : (
                  <ChevronRight className="w-4 h-4 text-slate-400" />
                )}
              </button>

              {expandedSections.sort && (
                <div className="px-4 pb-4 space-y-4">
                  {/* Trier par quantité */}
                  <div>
                    <label className="text-xs font-medium text-slate-700 mb-2 block">
                      Trier par quantité
                    </label>
                    <div className="flex flex-wrap gap-2">
                      <FilterButton
                        active={filters.sortByQuantity === 'most'}
                        onClick={() => updateFilter('sortByQuantity', filters.sortByQuantity === 'most' ? null : 'most')}
                      >
                        + utilisées
                      </FilterButton>
                      <FilterButton
                        active={filters.sortByQuantity === 'least'}
                        onClick={() => updateFilter('sortByQuantity', filters.sortByQuantity === 'least' ? null : 'least')}
                      >
                        - utilisées
                      </FilterButton>
                      <FilterButton
                        active={filters.sortByQuantity === 'balanced'}
                        onClick={() => updateFilter('sortByQuantity', filters.sortByQuantity === 'balanced' ? null : 'balanced')}
                        aiRecommended
                      >
                        Mélange équilibré
                      </FilterButton>
                    </div>
                  </div>

                  {/* Ordre DMC */}
                  <div>
                    <label className="text-xs font-medium text-slate-700 mb-2 block">
                      Ordre DMC
                    </label>
                    <div className="flex flex-wrap gap-2">
                      <FilterButton
                        active={filters.sortByDmc === 'asc'}
                        onClick={() => updateFilter('sortByDmc', filters.sortByDmc === 'asc' ? null : 'asc')}
                      >
                        Numéro croissant
                      </FilterButton>
                      <FilterButton
                        active={filters.sortByDmc === 'desc'}
                        onClick={() => updateFilter('sortByDmc', filters.sortByDmc === 'desc' ? null : 'desc')}
                      >
                        Numéro décroissant
                      </FilterButton>
                      <FilterButton
                        active={filters.sortByDmc === 'chromatic'}
                        onClick={() => updateFilter('sortByDmc', filters.sortByDmc === 'chromatic' ? null : 'chromatic')}
                      >
                        Familles chromatiques
                      </FilterButton>
                      <FilterButton
                        active={filters.sortByDmc === 'natural'}
                        onClick={() => updateFilter('sortByDmc', filters.sortByDmc === 'natural' ? null : 'natural')}
                        aiRecommended
                      >
                        Tri naturel (IA)
                      </FilterButton>
                    </div>
                  </div>

                  {/* Impact sur le rendu final */}
                  <div>
                    <label className="text-xs font-medium text-slate-700 mb-2 block">
                      Impact sur le rendu final (IA)
                    </label>
                    <div className="flex flex-wrap gap-2">
                      <FilterButton
                        active={filters.sortByImpact === 'structural'}
                        onClick={() => updateFilter('sortByImpact', filters.sortByImpact === 'structural' ? null : 'structural')}
                        aiRecommended
                      >
                        Couleurs structurelles
                      </FilterButton>
                      <FilterButton
                        active={filters.sortByImpact === 'shadows'}
                        onClick={() => updateFilter('sortByImpact', filters.sortByImpact === 'shadows' ? null : 'shadows')}
                      >
                        Couleurs d'ombres
                      </FilterButton>
                      <FilterButton
                        active={filters.sortByImpact === 'lights'}
                        onClick={() => updateFilter('sortByImpact', filters.sortByImpact === 'lights' ? null : 'lights')}
                      >
                        Couleurs de lumières
                      </FilterButton>
                      <FilterButton
                        active={filters.sortByImpact === 'relief'}
                        onClick={() => updateFilter('sortByImpact', filters.sortByImpact === 'relief' ? null : 'relief')}
                      >
                        Couleurs de relief
                      </FilterButton>
                      <FilterButton
                        active={filters.sortByImpact === 'face'}
                        onClick={() => updateFilter('sortByImpact', filters.sortByImpact === 'face' ? null : 'face')}
                        aiRecommended
                      >
                        Couleurs essentielles au visage
                      </FilterButton>
                    </div>
                  </div>

                  {/* Vitesse de broderie */}
                  <div>
                    <label className="text-xs font-medium text-slate-700 mb-2 block">
                      Vitesse de broderie
                    </label>
                    <div className="flex flex-wrap gap-2">
                      <FilterButton
                        active={filters.sortBySpeed === 'fast'}
                        onClick={() => updateFilter('sortBySpeed', filters.sortBySpeed === 'fast' ? null : 'fast')}
                      >
                        Zones rapides
                      </FilterButton>
                      <FilterButton
                        active={filters.sortBySpeed === 'slow'}
                        onClick={() => updateFilter('sortBySpeed', filters.sortBySpeed === 'slow' ? null : 'slow')}
                      >
                        Zones lentes
                      </FilterButton>
                      <FilterButton
                        active={filters.sortBySpeed === 'linear'}
                        onClick={() => updateFilter('sortBySpeed', filters.sortBySpeed === 'linear' ? null : 'linear')}
                      >
                        Zones linéaires
                      </FilterButton>
                      <FilterButton
                        active={filters.sortBySpeed === 'fragmented'}
                        onClick={() => updateFilter('sortBySpeed', filters.sortBySpeed === 'fragmented' ? null : 'fragmented')}
                      >
                        Zones fractionnées
                      </FilterButton>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Section 3: Smart Filters IA™ */}
            <div>
              <button
                onClick={() => toggleSection('smart')}
                className="w-full px-4 py-3 flex items-center justify-between hover:bg-slate-50 transition-colors"
              >
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-yellow-500" />
                  <span className="font-medium text-sm">Smart Filters IA™</span>
                </div>
                {expandedSections.smart ? (
                  <ChevronDown className="w-4 h-4 text-slate-400" />
                ) : (
                  <ChevronRight className="w-4 h-4 text-slate-400" />
                )}
              </button>

              {expandedSections.smart && (
                <div className="px-4 pb-4 space-y-4">
                  {/* IA : détecter automatiquement */}
                  <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <p className="text-xs font-medium text-slate-900 mb-1">
                          Activer IA Smart™
                        </p>
                        <p className="text-xs text-slate-600">
                          Propose les meilleurs filtres selon la zone affichée et optimise automatiquement
                        </p>
                      </div>
                      <Switch
                        checked={filters.aiEnabled}
                        onCheckedChange={(checked) => updateFilter('aiEnabled', checked)}
                      />
                    </div>
                  </div>

                  {/* IA : anti-erreurs */}
                  <div className="flex items-start justify-between p-3 bg-slate-50 rounded-lg">
                    <div className="flex-1">
                      <p className="text-xs font-medium text-slate-900 mb-1">
                        IA : Anti-erreurs
                      </p>
                      <p className="text-xs text-slate-600">
                        Signale les symboles proches et supprime les doublons de couleurs
                      </p>
                    </div>
                    <Switch
                      checked={filters.aiAntiError}
                      onCheckedChange={(checked) => updateFilter('aiAntiError', checked)}
                    />
                  </div>

                  {/* IA : expérience fluide */}
                  <div className="flex items-start justify-between p-3 bg-slate-50 rounded-lg">
                    <div className="flex-1">
                      <p className="text-xs font-medium text-slate-900 mb-1">
                        IA : Expérience de broderie fluide™
                      </p>
                      <p className="text-xs text-slate-600">
                        Réorganise la palette selon la progression et suggère la prochaine couleur idéale
                      </p>
                    </div>
                    <Switch
                      checked={filters.aiFluidExp}
                      onCheckedChange={(checked) => updateFilter('aiFluidExp', checked)}
                    />
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Bouton réinitialiser */}
          <div className="border-t border-slate-200 p-3">
            <button
              onClick={resetFilters}
              className="w-full flex items-center justify-center gap-2 py-2 text-xs text-slate-600 hover:text-slate-900 transition-colors"
            >
              <RotateCcw className="w-3 h-3" />
              Réinitialiser les filtres
            </button>
          </div>
        </div>
      )}

      {/* Overlay pour fermer au clic extérieur */}
      {isOpen && (
        <div
          className="fixed inset-0 z-40"
          onClick={() => setIsOpen(false)}
        />
      )}
    </div>
  );
}