import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { AlertCircle, Upload } from 'lucide-react';
import { toast } from 'sonner';

export default function PublishToShopDialog({ open, onClose, grid }) {
  const [title, setTitle] = useState(grid?.name || '');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState(5);
  const [isAuthorConfirmed, setIsAuthorConfirmed] = useState(false);
  const [isPublishing, setIsPublishing] = useState(false);
  const queryClient = useQueryClient();

  const publishMutation = useMutation({
    mutationFn: (data) => base44.entities.ShopGrid.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['shop-grids']);
      toast.success('Votre grille est maintenant disponible dans la Boutique PATYBEE.');
      onClose();
    },
  });

  const handlePublish = async () => {
    if (!isAuthorConfirmed) {
      toast.error('Vous devez confirmer être l\'auteur de cette création');
      return;
    }

    if (!title.trim()) {
      toast.error('Veuillez saisir un titre');
      return;
    }

    if (price <= 0) {
      toast.error('Le prix doit être supérieur à 0€');
      return;
    }

    setIsPublishing(true);

    try {
      const user = await base44.auth.me();

      // Créer l'image de prévisualisation (utiliser l'image du pattern si disponible)
      const previewImage = grid.pattern?.source_image || null;

      await publishMutation.mutateAsync({
        title: title.trim(),
        description: description.trim(),
        price: parseFloat(price),
        preview_image: previewImage,
        grid_data: grid,
        creator_name: user.full_name || user.email,
        creator_email: user.email,
        is_author_confirmed: true,
        original_grid_id: grid.id
      });
    } catch (error) {
      console.error('Erreur lors de la publication:', error);
      toast.error('Erreur lors de la publication');
    } finally {
      setIsPublishing(false);
    }
  };

  if (!grid) return null;

  return (
    <TooltipProvider delayDuration={500}>
      <Dialog open={open} onOpenChange={onClose}>
        <DialogContent className="sm:max-w-xl max-h-[90vh] flex flex-col p-0">
        {/* Header fixe */}
        <div className="px-6 pt-6 pb-4 border-b border-slate-200">
          <DialogHeader>
            <DialogTitle>Publier dans la Boutique</DialogTitle>
            <DialogDescription>
              Partagez votre création avec la communauté PATYBEE
            </DialogDescription>
          </DialogHeader>

          {/* Aperçu du projet - compact */}
          <div className="bg-slate-50 rounded-lg p-3 border border-slate-200 mt-4">
            <div className="flex items-center gap-3">
              {grid.pattern?.source_image && (
                <div className="w-20 h-20 bg-white rounded border border-slate-200 overflow-hidden flex-shrink-0">
                  <img
                    src={grid.pattern.source_image}
                    alt="Aperçu"
                    className="w-full h-full object-contain"
                    style={{ maxHeight: '80px' }}
                  />
                </div>
              )}
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-slate-900 mb-1">
                  Projet : {grid.name}
                </p>
                <p className="text-xs text-slate-600">
                  {grid.nb_colonnes} × {grid.nb_lignes} cases
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Zone scrollable */}
        <div className="flex-1 overflow-y-auto px-6 py-4 space-y-6">
          {/* Titre */}
          <div>
            <Label htmlFor="title">Titre de la grille *</Label>
            <Input
              id="title"
              placeholder="Ex: Fleurs de printemps"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="mt-1"
            />
          </div>

          {/* Description */}
          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              placeholder="Décrivez votre création, le style, les couleurs utilisées..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="mt-1 min-h-24"
            />
          </div>

          {/* Prix */}
          <div>
            <Tooltip>
              <TooltipTrigger asChild>
                <Label htmlFor="price">Prix (€) *</Label>
              </TooltipTrigger>
              <TooltipContent>
                <p>Choisir le prix de vente de votre grille</p>
              </TooltipContent>
            </Tooltip>
            <div className="flex gap-2 mt-1">
              <Input
                id="price"
                type="number"
                min="0.5"
                step="0.5"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                className="w-32"
              />
              <div className="flex gap-2">
                {[2, 5, 10].map((p) => (
                  <Button
                    key={p}
                    variant="outline"
                    size="sm"
                    onClick={() => setPrice(p)}
                  >
                    {p}€
                  </Button>
                ))}
              </div>
            </div>
          </div>

          {/* Confirmation auteur */}
          <Tooltip>
            <TooltipTrigger asChild>
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <p className="font-semibold text-amber-900 mb-2">
                      Protection des droits d'auteur
                    </p>
                    <div className="flex items-start gap-2">
                      <Checkbox
                        id="author-confirm"
                        checked={isAuthorConfirmed}
                        onCheckedChange={setIsAuthorConfirmed}
                        className="mt-0.5"
                      />
                      <Label
                        htmlFor="author-confirm"
                        className="text-sm text-amber-800 cursor-pointer"
                      >
                        Je confirme être l'auteur de ce motif et avoir tous les droits pour le publier
                      </Label>
                    </div>
                  </div>
                </div>
              </div>
            </TooltipTrigger>
            <TooltipContent>
              <p>Confirmer que vous êtes l'auteur du motif</p>
            </TooltipContent>
          </Tooltip>

          {/* Information commission */}
          <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
            <p className="text-sm text-purple-900 font-medium mb-2">
              💰 Modèle économique
            </p>
            <p className="text-sm text-purple-800">
              En publiant votre grille dans la Boutique PATYBEE, vous acceptez que PATYBEE retienne 
              une commission de <strong>15%</strong> sur chaque vente. Les <strong>85% restants</strong> vous 
              sont reversés en tant que créateur du modèle.
            </p>
          </div>

          {/* Protection des créateurs */}
          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
            <p className="text-sm text-green-900 font-medium mb-2">
              🛡️ PATYBEE protège vos grilles par :
            </p>
            <ul className="text-sm text-green-800 space-y-1 ml-4 list-disc">
              <li>Aperçu limité avant achat (basse résolution + watermark)</li>
              <li>Filigrane et identifiant unique sur les exports</li>
              <li>Historique des exports pour détecter les abus</li>
              <li>Licence personnelle pour chaque acheteur</li>
            </ul>
          </div>
        </div>

        {/* Footer fixe */}
        <div className="px-6 py-4 border-t border-slate-200 bg-white">
          <div className="flex items-center justify-between gap-3">
            <Button variant="outline" onClick={onClose} disabled={isPublishing}>
              Annuler
            </Button>
            <Button
              onClick={handlePublish}
              disabled={isPublishing || !isAuthorConfirmed}
              className="bg-slate-900 hover:bg-slate-800 gap-2"
            >
              {isPublishing ? (
                'Publication...'
              ) : (
                <>
                  <Upload className="w-4 h-4" />
                  Publier pour {price}€
                </>
              )}
            </Button>
          </div>
        </div>
        </DialogContent>
      </Dialog>
    </TooltipProvider>
  );
}