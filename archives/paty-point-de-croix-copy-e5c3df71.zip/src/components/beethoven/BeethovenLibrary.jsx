import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Music } from 'lucide-react';

const BEETHOVEN_SYMBOLS = [
  // AXES SACRÉS
  '✧', '✦', '✥', '✺', '✶', '❋', '❈', '❉', '❊', '✱',
  // ÉLÉMENTS
  '△', '▽', '▲', '▼', '⟁', '⧈', '⧉', '⌇', '✢', '✣',
  // ÉNERGIES & SPIRALES
  '۞', '☼', '☀', '☽', '☾', '☯', 'ϟ', 'Ϟ', 'ꙮ', '𖤐',
  // FLEURS, VIE, HARMONIE
  '✿', '❀', '✾', '✽', '❁', '❃', '❇', '❋', '✼', '✤',
  // ARCHETYPES & PORTES
  '⚚', '⚝', '⚞', '⚟', '⚯', '✠', '⌖', '⟡', '✙', '❖',
  // GÉOMÉTRIE SACRÉE
  '○', '●', '◍', '◉', '◎', '◈', '◆', '◇', '◪', '◫',
  // ÉTOILES & CONSTELLATIONS
  '★', '☆', '✪', '✩', '✫', '✬', '✭', '✮', '✯', '✵',
  // SYMBOLES VIBRATOIRES
  'ॐ', 'ૐ', 'ᚌ', 'ᛝ', 'ᛞ', 'ᚾ', 'ᛉ', 'ᚦ', 'ᛇ', 'ᛟ',
  // TRANSMUTATION / ALCHIMIE
  '🜁', '🜂', '🜄', '🜃', '🜚', '🜛', '🜜', '🜘', '🜙', '🜔',
  // ÉTHER / 5ᵉ ÉLÉMENT
  '✧⃝', '⊛', '⊚', '⊙', '⦿', '⦾', '⧙', '⧘', '✸', '✷'
];

const SYMBOL_CATEGORIES = [
  { name: 'Axes sacrés', range: [0, 10], icon: '⚜' },
  { name: 'Éléments', range: [10, 20], icon: '🔺' },
  { name: 'Énergies & Spirales', range: [20, 30], icon: '🌀' },
  { name: 'Fleurs, Vie, Harmonie', range: [30, 40], icon: '🌿' },
  { name: 'Archétypes & Portes', range: [40, 50], icon: '🔱' },
  { name: 'Géométrie sacrée', range: [50, 60], icon: '⧉' },
  { name: 'Étoiles & Constellations', range: [60, 70], icon: '💠' },
  { name: 'Symboles vibratoires', range: [70, 80], icon: '🕉' },
  { name: 'Transmutation / Alchimie', range: [80, 90], icon: '⚗' },
  { name: 'Éther / 5ᵉ élément', range: [90, 100], icon: '🔮' }
];

export default function BeethovenLibrary({ onSymbolSelect, selectedSymbol }) {
  const [activeCategory, setActiveCategory] = useState(0);

  const handleSymbolClick = (symbol) => {
    onSymbolSelect(symbol);
    toast.success(`Symbole sacré activé : ${symbol}`);
  };

  return (
    <div className="space-y-6">
      {/* En-tête */}
      <div className="text-center space-y-3 pb-6 border-b border-slate-200">
        <div className="flex items-center justify-center gap-3">
          <Music className="w-8 h-8 text-slate-900" />
          <h1 className="text-3xl font-bold text-slate-900">Bibliothèque Beethoven</h1>
        </div>
        <p className="text-slate-600 max-w-3xl mx-auto">
          Symboles sacrés & géométrie du 5ᵉ élément — Signatures vibratoires pour les grilles PATYBEE
        </p>
      </div>

      {/* Navigation par catégories */}
      <div className="flex flex-wrap gap-2 justify-center">
        {SYMBOL_CATEGORIES.map((category, index) => (
          <Button
            key={index}
            variant={activeCategory === index ? 'default' : 'outline'}
            size="sm"
            onClick={() => setActiveCategory(index)}
            className={activeCategory === index ? 'bg-slate-900 text-white' : ''}
          >
            <span className="mr-2">{category.icon}</span>
            {category.name}
          </Button>
        ))}
      </div>

      {/* Grille de symboles pour la catégorie active */}
      <div className="bg-white rounded-xl border-2 border-slate-200 p-6">
        <h2 className="text-lg font-semibold text-slate-900 mb-4 flex items-center gap-2">
          {SYMBOL_CATEGORIES[activeCategory].icon}
          {SYMBOL_CATEGORIES[activeCategory].name}
        </h2>
        
        <div className="grid grid-cols-10 gap-2">
          {BEETHOVEN_SYMBOLS.slice(
            SYMBOL_CATEGORIES[activeCategory].range[0],
            SYMBOL_CATEGORIES[activeCategory].range[1]
          ).map((symbol, index) => (
            <motion.button
              key={index}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => handleSymbolClick(symbol)}
              className={`
                h-14 flex items-center justify-center text-2xl font-bold
                rounded-lg border-2 transition-all
                ${selectedSymbol === symbol 
                  ? 'bg-slate-900 text-white border-slate-900 shadow-lg' 
                  : 'bg-white border-slate-200 hover:border-slate-400 hover:shadow-md'
                }
              `}
            >
              {symbol}
            </motion.button>
          ))}
        </div>
      </div>

      {/* Indicateur du symbole actif */}
      {selectedSymbol && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-slate-900 text-white rounded-xl p-4 flex items-center justify-between"
        >
          <div className="flex items-center gap-3">
            <Music className="w-5 h-5" />
            <span className="font-medium">Symbole Beethoven actif :</span>
          </div>
          <div className="text-3xl">{selectedSymbol}</div>
        </motion.div>
      )}
    </div>
  );
}

export { BEETHOVEN_SYMBOLS };