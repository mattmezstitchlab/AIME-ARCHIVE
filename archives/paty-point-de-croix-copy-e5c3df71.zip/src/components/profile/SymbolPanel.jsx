import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { getSymbolData, SYMBOL_MEANINGS } from './symbolMapping';
import { Edit2, Info } from 'lucide-react';

export default function SymbolPanel({ symbolId, profileData, onEditField, onScrollToField }) {
  const [activeTab, setActiveTab] = useState('data');
  
  if (!symbolId) {
    return (
      <Card className="h-full">
        <CardContent className="flex items-center justify-center h-full text-slate-500">
          <p className="text-center">
            Cliquez sur un symbole de la grille<br />pour voir ses informations
          </p>
        </CardContent>
      </Card>
    );
  }

  const symbolData = getSymbolData(symbolId);
  const symbolMeaning = SYMBOL_MEANINGS[symbolId] || {
    saison: 'Printemps',
    element: 'Air',
    chakra: 'Couronne',
    polarite: 'Neutre',
    note: 'Do',
    commentaire: 'Ce symbole représente une facette de votre identité vibratoire.'
  };

  const fieldValue = profileData?.[symbolData.field] || '';
  const isFilled = fieldValue && fieldValue.toString().trim() !== '';

  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div>
            <div className="text-2xl font-bold">Symbole n°{symbolId}</div>
            <div className="text-sm font-normal text-slate-600 mt-1">
              {symbolData.label} • {symbolData.category}
            </div>
          </div>
          <div className="text-4xl">{symbolData.symbol}</div>
        </CardTitle>
      </CardHeader>

      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="data">Donnée</TabsTrigger>
            <TabsTrigger value="meaning">Symbolique</TabsTrigger>
          </TabsList>

          <TabsContent value="data" className="space-y-4 mt-4">
            <div>
              <div className="text-sm font-medium text-slate-700 mb-2">
                {symbolData.label}
              </div>
              {isFilled ? (
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                  <p className="text-slate-900">{fieldValue}</p>
                </div>
              ) : (
                <div className="p-3 bg-amber-50 rounded-lg border border-amber-200">
                  <p className="text-sm text-amber-800">
                    Aucune donnée renseignée pour ce symbole.
                  </p>
                </div>
              )}
            </div>

            <Button
              onClick={() => onScrollToField(symbolData.field)}
              variant="outline"
              className="w-full gap-2"
            >
              <Edit2 className="w-4 h-4" />
              Éditer la donnée
            </Button>
          </TabsContent>

          <TabsContent value="meaning" className="space-y-4 mt-4">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-600">Saison</span>
                <span className="font-medium">{symbolMeaning.saison}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-600">Élément</span>
                <span className="font-medium">{symbolMeaning.element}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-600">Chakra</span>
                <span className="font-medium">{symbolMeaning.chakra}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-600">Polarité</span>
                <span className="font-medium">{symbolMeaning.polarite}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-600">Direction</span>
                <span className="font-medium">{symbolMeaning.direction}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-600">Note musicale</span>
                <span className="font-medium">{symbolMeaning.note}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-600">Fréquence</span>
                <span className="font-medium">{symbolMeaning.frequence}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-600">Intervalle</span>
                <span className="font-medium">{symbolMeaning.intervalle}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-600">Archétype</span>
                <span className="font-medium">{symbolMeaning.archetype}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-600">État</span>
                <span className={`font-medium ${
                  symbolMeaning.etat === 'Aligné' ? 'text-green-600' :
                  symbolMeaning.etat === 'Actif' ? 'text-blue-600' :
                  symbolMeaning.etat === 'En transformation' ? 'text-purple-600' :
                  'text-slate-600'
                }`}>
                  {symbolMeaning.etat}
                </span>
              </div>
            </div>

            <div className="mt-4 p-4 bg-purple-50 rounded-lg border border-purple-200">
              <div className="flex items-start gap-2">
                <Info className="w-5 h-5 text-purple-600 flex-shrink-0 mt-0.5" />
                <div className="space-y-2">
                  <p className="text-sm text-purple-900 font-medium">Lecture vibratoire</p>
                  <p className="text-sm text-purple-800">
                    {symbolMeaning.commentaire}
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-2 p-3 bg-amber-50 rounded-lg border border-amber-200">
              <p className="text-xs text-amber-900">
                <strong>Suggestion :</strong> {symbolMeaning.suggestion}
              </p>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}