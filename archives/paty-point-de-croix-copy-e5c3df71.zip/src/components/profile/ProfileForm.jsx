import React, { forwardRef } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Save } from 'lucide-react';

const ProfileForm = forwardRef(({ profileData, onUpdate, onSave, fieldRefs, onFieldHover }, ref) => {
  const handleChange = (field, value) => {
    onUpdate({ ...profileData, [field]: value });
  };

  const getMaxLength = (field) => {
    // Champs courts (noms, villes, etc.)
    const shortFields = ['prenom', 'deuxieme_prenom', 'nom', 'pseudo', 'ville_naissance', 'ville_actuelle', 
                         'pays_naissance', 'pays', 'nationalite', 'taille', 'couleur_yeux', 'couleur_cheveux',
                         'groupe_sanguin', 'mobilite', 'sens_dominant', 'note_musicale', 'instrument_vibratoire',
                         'frequence_dominante', 'mode_vibratoire', 'couleur_vibratoire', 'archetype_dominant',
                         'archetype_secondaire', 'style_decisionnel', 'metier_actuel', 'metier_ideal', 
                         'talent_cache', 'style_travail', 'cycle_actuel', 'cycle_futur', 'alignement_naturel',
                         'type_energie_corporelle', 'vitalite', 'type_attachement', 'style_amoureux',
                         'don_emotionnel', 'don_spirituel', 'harmonie_disharmonie'];
    
    // Champs moyens (adresses, téléphone, etc.)
    const mediumFields = ['adresse_actuelle', 'code_postal', 'telephone', 'enfants', 'langues_parlees'];
    
    // Champs longs (textarea, descriptions, etc.) - pas de limite stricte
    
    if (shortFields.includes(field)) return 80;
    if (mediumFields.includes(field)) return 150;
    return 500; // Pour les textarea
  };

  const FormField = ({ field, label, type = 'text', linkedSymbol, options = null }) => (
    <div 
      className="space-y-2"
      onMouseEnter={() => onFieldHover?.(field)}
      onMouseLeave={() => onFieldHover?.(null)}
    >
      <Label htmlFor={field} className="flex items-center justify-between">
        <span>{label}</span>
        {linkedSymbol && (
          <span className="text-xs text-slate-500">Lié au symbole : n°{linkedSymbol}</span>
        )}
      </Label>
      {type === 'textarea' ? (
        <Textarea
          id={field}
          ref={el => fieldRefs.current[field] = el}
          value={profileData?.[field] || ''}
          onChange={(e) => handleChange(field, e.target.value)}
          maxLength={getMaxLength(field)}
          className="min-h-24"
        />
      ) : type === 'select' ? (
        <Select value={profileData?.[field] || ''} onValueChange={(value) => handleChange(field, value)}>
          <SelectTrigger ref={el => fieldRefs.current[field] = el}>
            <SelectValue placeholder="Choisir..." />
          </SelectTrigger>
          <SelectContent>
            {options.map(opt => (
              <SelectItem key={opt} value={opt}>{opt}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      ) : type === 'number' ? (
        <Input
          id={field}
          type="number"
          min="1"
          max="10"
          ref={el => fieldRefs.current[field] = el}
          value={profileData?.[field] || ''}
          onChange={(e) => handleChange(field, e.target.value)}
        />
      ) : (
        <Input
          id={field}
          type={type}
          ref={el => fieldRefs.current[field] = el}
          value={profileData?.[field] || ''}
          onChange={(e) => handleChange(field, e.target.value)}
          maxLength={getMaxLength(field)}
        />
      )}
    </div>
  );

  return (
    <div ref={ref} className="bg-white rounded-xl border border-slate-200 p-6 shadow-md">
      <h2 className="text-2xl font-bold text-slate-900 mb-6">Données du Profil</h2>
      
      <Tabs defaultValue="identity" className="w-full">
        <TabsList className="grid w-full grid-cols-5 lg:grid-cols-10 gap-1 mb-6">
          <TabsTrigger value="identity">Identité</TabsTrigger>
          <TabsTrigger value="physique">Physique</TabsTrigger>
          <TabsTrigger value="emotion">Émotion</TabsTrigger>
          <TabsTrigger value="elements">Éléments</TabsTrigger>
          <TabsTrigger value="musique">Musique</TabsTrigger>
          <TabsTrigger value="archetypes">Archétypes</TabsTrigger>
          <TabsTrigger value="histoire">Histoire</TabsTrigger>
          <TabsTrigger value="pro">Pro</TabsTrigger>
          <TabsTrigger value="passions">Passions</TabsTrigger>
          <TabsTrigger value="futur">Futur</TabsTrigger>
        </TabsList>

        <TabsContent value="identity" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField field="prenom" label="Prénom" linkedSymbol={1} />
            <FormField field="deuxieme_prenom" label="Deuxième prénom" linkedSymbol={2} />
            <FormField field="nom" label="Nom" linkedSymbol={3} />
            <FormField field="pseudo" label="Pseudo / Nom d'artiste" linkedSymbol={4} />
            <FormField field="date_naissance" label="Date de naissance" type="date" linkedSymbol={5} />
            <FormField field="heure_naissance" label="Heure de naissance" type="time" linkedSymbol={6} />
            <FormField field="ville_naissance" label="Ville de naissance" linkedSymbol={7} />
            <FormField field="pays_naissance" label="Pays de naissance" linkedSymbol={8} />
            <FormField field="nationalite" label="Nationalité" linkedSymbol={9} />
            <FormField field="langues_parlees" label="Langues parlées" linkedSymbol={10} />
            <FormField field="signe_solaire" label="Signe solaire" linkedSymbol={5} />
            <FormField field="ascendant" label="Ascendant" linkedSymbol={6} />
            <FormField field="adresse_actuelle" label="Adresse actuelle" linkedSymbol={35} />
            <FormField field="ville_actuelle" label="Ville actuelle" linkedSymbol={20} />
            <FormField field="code_postal" label="Code postal" linkedSymbol={36} />
            <FormField field="pays" label="Pays" linkedSymbol={37} />
            <FormField field="telephone" label="Téléphone" linkedSymbol={30} />
          </div>
        </TabsContent>

        <TabsContent value="physique" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField field="taille" label="Taille" linkedSymbol={11} />
            <FormField field="couleur_yeux" label="Couleur des yeux" linkedSymbol={12} />
            <FormField field="couleur_cheveux" label="Couleur des cheveux" linkedSymbol={13} />
            <FormField field="particularites_physiques" label="Particularités physiques" type="textarea" linkedSymbol={14} />
            <FormField field="vitalite" label="Vitalité" linkedSymbol={15} />
            <FormField 
              field="etat_sante" 
              label="État de santé général" 
              type="select"
              options={['Très bon', 'Bon', 'Fragile', 'À surveiller']}
              linkedSymbol={15}
            />
            <FormField field="groupe_sanguin" label="Groupe sanguin" linkedSymbol={17} />
            <FormField field="mobilite" label="Mobilité" linkedSymbol={19} />
            <FormField field="sens_dominant" label="Sens dominant" linkedSymbol={18} />
            <FormField field="type_energie_corporelle" label="Type d'énergie corporelle" linkedSymbol={18} />
          </div>
        </TabsContent>

        <TabsContent value="emotion" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField 
              field="situation_amoureuse" 
              label="Situation amoureuse" 
              type="select"
              options={['Célibataire', 'En couple', 'Marié(e)', 'Séparé(e)', 'Autre']}
              linkedSymbol={21}
            />
            <FormField field="enfants" label="Enfants" linkedSymbol={22} />
            <FormField 
              field="blessure_emotionnelle" 
              label="Blessure émotionnelle dominante" 
              type="select"
              options={['Abandon', 'Rejet', 'Injustice', 'Trahison', 'Humiliation']}
              linkedSymbol={28}
            />
            <FormField field="relation_parents" label="Relation aux parents" type="textarea" linkedSymbol={23} />
            <FormField field="relation_soi" label="Relation à soi-même" type="textarea" linkedSymbol={25} />
            <FormField field="niveau_sensibilite" label="Niveau de sensibilité (1-10)" type="number" linkedSymbol={26} />
            <FormField field="empathie" label="Empathie (1-10)" type="number" linkedSymbol={27} />
            <FormField field="type_attachement" label="Type d'attachement" linkedSymbol={21} />
            <FormField field="style_amoureux" label="Style amoureux" linkedSymbol={21} />
            <FormField field="don_emotionnel" label="Don émotionnel dominant" linkedSymbol={29} />
            <FormField field="don_spirituel" label="Don spirituel principal" linkedSymbol={29} />
          </div>
        </TabsContent>

        <TabsContent value="elements" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField 
              field="saison_interieure" 
              label="Saison intérieure" 
              type="select"
              options={['Printemps', 'Été', 'Automne', 'Hiver']}
              linkedSymbol={31}
            />
            <FormField 
              field="element_dominant" 
              label="Élément dominant" 
              type="select"
              options={['Terre', 'Eau', 'Air', 'Feu', 'Éther']}
              linkedSymbol={32}
            />
            <FormField 
              field="element_faible" 
              label="Élément faible" 
              type="select"
              options={['Terre', 'Eau', 'Air', 'Feu', 'Éther']}
              linkedSymbol={33}
            />
            <FormField field="cycle_actuel" label="Cycle actuel" linkedSymbol={31} />
            <FormField field="cycle_futur" label="Cycle futur" linkedSymbol={31} />
            <FormField field="alignement_naturel" label="Alignement naturel" linkedSymbol={32} />
            <FormField field="anciennes_adresses" label="Anciennes adresses / lieux de vie" type="textarea" linkedSymbol={38} />
            <FormField field="voyages_importants" label="Voyages importants" type="textarea" linkedSymbol={39} />
          </div>
        </TabsContent>

        <TabsContent value="musique" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField field="note_musicale" label="Note fondamentale" linkedSymbol={41} />
            <FormField field="frequence_dominante" label="Fréquence dominante (Hz)" linkedSymbol={44} />
            <FormField field="instrument_vibratoire" label="Instrument vibratoire" linkedSymbol={42} />
            <FormField 
              field="rythme_vie" 
              label="Rythme de vie" 
              type="select"
              options={['Lent', 'Modéré', 'Rapide']}
              linkedSymbol={45}
            />
            <FormField field="harmonie_disharmonie" label="Harmonie vs Disharmonie" linkedSymbol={44} />
            <FormField field="mode_vibratoire" label="Mode vibratoire actuel" linkedSymbol={45} />
            <FormField field="couleur_vibratoire" label="Couleur vibratoire active" linkedSymbol={41} />
          </div>
        </TabsContent>

        <TabsContent value="archetypes" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField field="archetype_dominant" label="Archétype principal" linkedSymbol={51} />
            <FormField field="archetype_secondaire" label="Archétype secondaire" linkedSymbol={52} />
            <FormField field="traits_dominants" label="Traits dominants" type="textarea" linkedSymbol={53} />
            <FormField field="defauts_travailler" label="Défauts à travailler" type="textarea" linkedSymbol={54} />
            <FormField field="forces_principales" label="Forces" type="textarea" linkedSymbol={53} />
            <FormField field="style_decisionnel" label="Style décisionnel" linkedSymbol={51} />
            <FormField field="reaction_stress" label="Réaction au stress" type="textarea" linkedSymbol={55} />
            <FormField field="niveau_intuition" label="Niveau d'intuition (1-10)" type="number" linkedSymbol={52} />
          </div>
        </TabsContent>

        <TabsContent value="histoire" className="space-y-4">
          <div className="grid grid-cols-1 gap-4">
            <FormField field="moments_fondateurs" label="Moments fondateurs" type="textarea" linkedSymbol={61} />
            <FormField field="ruptures_changements" label="Ruptures / Changements majeurs" type="textarea" linkedSymbol={62} />
            <FormField field="rencontres_cles" label="Rencontres clés" type="textarea" linkedSymbol={63} />
            <FormField field="traumas_marquants" label="Traumas marquants" type="textarea" linkedSymbol={62} />
            <FormField field="initiations" label="Initiations" type="textarea" linkedSymbol={61} />
            <FormField field="lecons_apprises" label="Leçons apprises" type="textarea" linkedSymbol={64} />
            <FormField field="lecons_en_cours" label="Leçons en cours" type="textarea" linkedSymbol={65} />
            <FormField field="lecons_a_venir" label="Leçons à venir" type="textarea" linkedSymbol={66} />
          </div>
        </TabsContent>

        <TabsContent value="pro" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField field="metier_actuel" label="Métier actuel" linkedSymbol={71} />
            <FormField field="metier_ideal" label="Métier idéal" linkedSymbol={72} />
            <FormField field="talent_cache" label="Talent caché" linkedSymbol={72} />
            <FormField field="competences_cles" label="Compétences clés" type="textarea" linkedSymbol={73} />
            <FormField field="projet_en_cours" label="Projet en cours" type="textarea" linkedSymbol={74} />
            <FormField field="ambition_future" label="Ambition future" type="textarea" linkedSymbol={75} />
            <FormField field="style_travail" label="Style de travail" linkedSymbol={71} />
            <FormField field="niveau_leadership" label="Niveau de leadership (1-10)" type="number" linkedSymbol={78} />
            <FormField field="zone_confort" label="Zone de confort" type="textarea" linkedSymbol={71} />
            <FormField field="zone_expansion" label="Zone d'expansion" type="textarea" linkedSymbol={75} />
          </div>
        </TabsContent>

        <TabsContent value="passions" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField field="centres_interet_nature" label="Nature" type="textarea" linkedSymbol={82} />
            <FormField field="centres_interet_art" label="Art" type="textarea" linkedSymbol={81} />
            <FormField field="centres_interet_musique" label="Musique" type="textarea" linkedSymbol={81} />
            <FormField field="centres_interet_spiritualite" label="Spiritualité" type="textarea" linkedSymbol={83} />
            <FormField field="centres_interet_sport" label="Sport" type="textarea" linkedSymbol={84} />
            <FormField field="centres_interet_cuisine" label="Cuisine" type="textarea" linkedSymbol={85} />
            <FormField field="centres_interet_technologies" label="Technologies" type="textarea" linkedSymbol={86} />
            <FormField field="cause_sociale" label="Cause sociale ou écologique" type="textarea" linkedSymbol={87} />
            <FormField field="loisirs_principaux" label="Loisirs principaux" type="textarea" linkedSymbol={81} />
            <FormField field="outils_creatifs" label="Outils créatifs" type="textarea" linkedSymbol={81} />
          </div>
        </TabsContent>

        <TabsContent value="futur" className="space-y-4">
          <div className="grid grid-cols-1 gap-4">
            <FormField field="intentions_futures" label="Intentions futures" type="textarea" linkedSymbol={91} />
            <FormField field="objectifs" label="Objectifs" type="textarea" linkedSymbol={91} />
            <FormField field="missions" label="Missions" type="textarea" linkedSymbol={92} />
            <FormField field="mots_cles_vibratoires" label="Mots clés vibratoires" type="textarea" linkedSymbol={94} />
            <FormField field="messages_soi" label="Messages à soi-même" type="textarea" linkedSymbol={93} />
            <FormField field="mantras" label="Mantras" type="textarea" linkedSymbol={93} />
            <FormField field="ressources_interieures" label="Ressources intérieures" type="textarea" linkedSymbol={99} />
            <FormField field="vision_long_terme" label="Vision à long terme" type="textarea" linkedSymbol={100} />
          </div>
        </TabsContent>
      </Tabs>

      <div className="mt-8 flex items-center justify-between">
        <p className="text-xs text-slate-500 max-w-xl">
          Toutes vos données restent privées et sont utilisées uniquement pour générer votre Signature Vibratoire personnelle.
        </p>
        <Button onClick={onSave} className="gap-2 bg-purple-600 hover:bg-purple-700">
          <Save className="w-4 h-4" />
          Enregistrer mon profil
        </Button>
      </div>
    </div>
  );
});

ProfileForm.displayName = 'ProfileForm';

export default ProfileForm;