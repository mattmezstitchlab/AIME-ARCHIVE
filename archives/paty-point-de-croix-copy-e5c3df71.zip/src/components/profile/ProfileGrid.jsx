import React, { useState } from 'react';
import CaseProfil from './CaseProfil';
import SymbolPicker from './SymbolPicker';

export default function ProfileGrid() {
  const [showSymbolPicker, setShowSymbolPicker] = useState(false);
  const [selectedCell, setSelectedCell] = useState(null);
  const [cellData, setCellData] = useState({});
  
  // Générer 100 cases (10×10)
  const cells = Array.from({ length: 100 }, (_, i) => i);

  const handleCellClick = (index) => {
    setSelectedCell(index);
    setShowSymbolPicker(true);
  };

  const handleSymbolValidate = (symbol) => {
    if (selectedCell !== null) {
      setCellData(prev => ({
        ...prev,
        [selectedCell]: { symbol, color: '#000000', status: 'filled' }
      }));
    }
    setShowSymbolPicker(false);
    setSelectedCell(null);
  };

  const handleCancel = () => {
    setShowSymbolPicker(false);
    setSelectedCell(null);
  };

  return (
    <div className="flex flex-col items-center" style={{ margin: '20px' }}>
      <div className="grid grid-cols-10" style={{ width: '300px', gap: '4px' }}>
        {cells.map((index) => (
          <div key={index} onClick={() => handleCellClick(index)}>
            <CaseProfil 
              symbol={cellData[index]?.symbol}
              color={cellData[index]?.color}
              status={cellData[index]?.status || 'empty'}
            />
          </div>
        ))}
      </div>

      <SymbolPicker
        visible={showSymbolPicker}
        onCancel={handleCancel}
        onValidate={handleSymbolValidate}
      />
    </div>
  );
}