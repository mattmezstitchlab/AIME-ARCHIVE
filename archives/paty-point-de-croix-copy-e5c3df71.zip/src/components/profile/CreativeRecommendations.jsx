import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Sparkles, Users, Loader2, RefreshCw } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '../../utils';
import { toast } from 'sonner';

export default function CreativeRecommendations() {
  const navigate = useNavigate();
  const [isCalculating, setIsCalculating] = useState(false);

  const { data: user } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me(),
  });

  const { data: userProfile, refetch } = useQuery({
    queryKey: ['user-profile', user?.email],
    queryFn: async () => {
      if (!user) return null;
      const profiles = await base44.entities.UserProfile.filter({ created_by: user.email });
      return profiles[0] || null;
    },
    enabled: !!user,
  });

  const handleCalculateMatching = async () => {
    setIsCalculating(true);
    try {
      const response = await base44.functions.invoke('calculerMatchingCreatif', {});
      toast.success('Recommandations calculées avec succès');
      refetch();
    } catch (error) {
      toast.error('Erreur lors du calcul des recommandations');
      console.error(error);
    } finally {
      setIsCalculating(false);
    }
  };

  const matchingCreatif = userProfile?.matching_creatif || {};
  const recommandationsModeles = matchingCreatif.recommandations_modeles || [];
  const compatibilites = matchingCreatif.compatibilites || [];

  return (
    <div className="space-y-6">
      {/* Bouton de calcul/actualisation */}
      <div className="flex justify-end">
        <Button
          onClick={handleCalculateMatching}
          disabled={isCalculating}
          className="gap-2"
        >
          {isCalculating ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              Calcul en cours...
            </>
          ) : (
            <>
              <RefreshCw className="w-4 h-4" />
              Actualiser les recommandations
            </>
          )}
        </Button>
      </div>

      {/* Section Modèles recommandés */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-purple-600" />
            Recommandations créatives
          </CardTitle>
        </CardHeader>
        <CardContent>
          {recommandationsModeles.length === 0 ? (
            <p className="text-slate-600 text-center py-8">
              Aucune recommandation pour le moment. Calculez vos recommandations pour découvrir des modèles compatibles avec votre profil.
            </p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {recommandationsModeles.map((item, index) => (
                <Card key={index} className="overflow-hidden hover:shadow-lg transition-shadow">
                  <div className="aspect-video bg-slate-100 relative">
                    {item.modele?.preview_image ? (
                      <img
                        src={item.modele.preview_image}
                        alt={item.modele.titre}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-slate-400">
                        <Sparkles className="w-12 h-12" />
                      </div>
                    )}
                    <Badge className="absolute top-2 right-2 bg-purple-600">
                      {item.score}% compatible
                    </Badge>
                  </div>
                  <CardContent className="p-4">
                    <h3 className="font-semibold text-slate-900 mb-1">
                      {item.modele?.titre || 'Modèle'}
                    </h3>
                    {item.modele?.description && (
                      <p className="text-xs text-slate-600 mb-3 line-clamp-2">
                        {item.modele.description}
                      </p>
                    )}
                    <Button
                      size="sm"
                      className="w-full"
                      onClick={() => navigate(createPageUrl('Shop'))}
                    >
                      Voir le modèle
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Section Brodeuses compatibles */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="w-5 h-5 text-purple-600" />
            Brodeuses compatibles
          </CardTitle>
        </CardHeader>
        <CardContent>
          {compatibilites.length === 0 ? (
            <p className="text-slate-600 text-center py-8">
              Aucune compatibilité trouvée. Calculez vos recommandations pour découvrir des brodeuses partageant vos affinités créatives.
            </p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {compatibilites.map((item, index) => (
                <Card key={index} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-4 flex items-center gap-4">
                    <Avatar className="w-12 h-12">
                      <AvatarImage src={item.utilisateur?.photo_url} />
                      <AvatarFallback className="bg-purple-100 text-purple-600">
                        {item.utilisateur?.nom?.charAt(0).toUpperCase() || 'U'}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <h3 className="font-semibold text-slate-900">
                        {item.utilisateur?.nom || 'Utilisateur'}
                      </h3>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="outline" className="text-xs">
                          Affinité : {item.compatibilite}%
                        </Badge>
                      </div>
                      {item.points_communs && (
                        <div className="text-xs text-slate-600 mt-2">
                          {item.points_communs.couleurs?.length > 0 && (
                            <span>{item.points_communs.couleurs.length} couleurs communes</span>
                          )}
                          {item.points_communs.passions?.length > 0 && (
                            <span className="ml-2">{item.points_communs.passions.length} passions communes</span>
                          )}
                        </div>
                      )}
                    </div>
                    <Button size="sm" variant="outline">
                      Voir profil
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}