import React, { useEffect, useState } from 'react';
import { SYMBOL_GRID_MAPPING } from './symbolMapping';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';

export default function VibratoryGrid({ selectedSymbolId, onSymbolClick, profileData, hoveredField }) {
  const [pulsingSymbol, setPulsingSymbol] = useState(null);
  
  // Organiser les symboles en grille 10x10
  const grid = [];
  for (let i = 0; i < 10; i++) {
    const row = SYMBOL_GRID_MAPPING.slice(i * 10, (i + 1) * 10);
    grid.push(row);
  }

  const isSymbolFilled = (symbolData) => {
    if (!profileData) return false;
    return profileData[symbolData.field] && profileData[symbolData.field].toString().trim() !== '';
  };

  // Effet de pulsation quand un champ est rempli
  useEffect(() => {
    if (hoveredField) {
      const symbol = SYMBOL_GRID_MAPPING.find(s => s.field === hoveredField);
      if (symbol) {
        setPulsingSymbol(symbol.id);
      }
    } else {
      setPulsingSymbol(null);
    }
  }, [hoveredField]);

  return (
    <TooltipProvider delayDuration={300}>
      <div className="w-full max-w-3xl">
        <h2 className="text-2xl font-bold text-slate-900 mb-4">Signature Vibratoire 10×10</h2>
        <div className="bg-white rounded-xl border-2 border-slate-300 p-6 shadow-lg">
          <div className="grid grid-cols-10 gap-1">
            {grid.map((row, rowIndex) => (
              row.map((symbolData) => {
                const isSelected = selectedSymbolId === symbolData.id;
                const isFilled = isSymbolFilled(symbolData);
                
                const isPulsing = pulsingSymbol === symbolData.id;
                
                return (
                  <Tooltip key={symbolData.id}>
                    <TooltipTrigger asChild>
                      <button
                        onClick={() => onSymbolClick(symbolData.id)}
                        className={cn(
                          'aspect-square flex items-center justify-center text-2xl font-bold',
                          'border border-slate-200 rounded transition-all hover:scale-110',
                          isSelected && 'ring-2 ring-blue-500 bg-blue-50 scale-110 shadow-md',
                          isFilled && !isSelected && 'bg-green-50 border-green-300',
                          !isFilled && !isSelected && 'bg-slate-50 hover:bg-slate-100',
                          isPulsing && 'animate-pulse ring-2 ring-purple-400 bg-purple-100'
                        )}
                      >
                        {symbolData.symbol}
                      </button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p className="font-semibold">Symbole n°{symbolData.id} – {symbolData.label}</p>
                      <p className="text-xs text-slate-500">Catégorie : {symbolData.category}</p>
                    </TooltipContent>
                  </Tooltip>
                );
              })
            ))}
          </div>
          
          <div className="mt-6 flex items-center justify-center gap-6 text-xs text-slate-600">
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-green-50 border border-green-300 rounded" />
              <span>Renseigné</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-slate-50 border border-slate-200 rounded" />
              <span>À remplir</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-blue-50 border-2 border-blue-500 rounded" />
              <span>Sélectionné</span>
            </div>
          </div>
        </div>
      </div>
    </TooltipProvider>
  );
}