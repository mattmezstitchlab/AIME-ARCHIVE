// Bibliothèque officielle des 100 symboles PATYBEE - Version Révolutionnaire
// Symboles minimalistes, géométriques, noirs pleins, brevetables
// Conçus pour la Signature Vibratoire® 10×10

export const SYMBOL_GRID_MAPPING = [
  // Ligne 1: Fondamentaux (1-10) - Identité civile
  { id: 1, category: 'Identité', label: 'Prénom', field: 'prenom', symbol: '●', name: 'Point Central', meaning: 'âme / essence' },
  { id: 2, category: 'Identité', label: 'Deuxième prénom', field: 'deuxieme_prenom', symbol: '✚', name: 'Croix Pleine', meaning: 'alignement' },
  { id: 3, category: 'Identité', label: 'Nom', field: 'nom', symbol: '●', name: 'Cercle Plein', meaning: 'unité / cycle' },
  { id: 4, category: 'Identité', label: 'Pseudo', field: 'pseudo', symbol: '■', name: 'Carré Plein', meaning: 'matière / stabilité' },
  { id: 5, category: 'Identité', label: 'Date de naissance', field: 'date_naissance', symbol: '▲', name: 'Triangle Haut', meaning: 'feu / ascension' },
  { id: 6, category: 'Identité', label: 'Heure de naissance', field: 'heure_naissance', symbol: '▼', name: 'Triangle Bas', meaning: 'eau / profondeur' },
  { id: 7, category: 'Identité', label: 'Ville de naissance', field: 'ville_naissance', symbol: '│', name: 'Ligne Verticale', meaning: 'destinée' },
  { id: 8, category: 'Identité', label: 'Pays de naissance', field: 'pays_naissance', symbol: '─', name: 'Ligne Horizontale', meaning: 'présent' },
  { id: 9, category: 'Identité', label: 'Nationalité', field: 'nationalite', symbol: '╱', name: 'Diagonal Montante', meaning: 'expansion' },
  { id: 10, category: 'Identité', label: 'Langues parlées', field: 'langues_parlees', symbol: '╲', name: 'Diagonal Descendante', meaning: 'résolution' },
  
  // Ligne 2: Élémentaires (11-20) - Physique
  { id: 11, category: 'Physique', label: 'Taille', field: 'taille', symbol: '⌒', name: 'Arc Haut', meaning: 'protection' },
  { id: 12, category: 'Physique', label: 'Couleur des yeux', field: 'couleur_yeux', symbol: '⌓', name: 'Arc Bas', meaning: 'soutien' },
  { id: 13, category: 'Physique', label: 'Couleur des cheveux', field: 'couleur_cheveux', symbol: '∨', name: 'Chevron Bas', meaning: 'direction / choix' },
  { id: 14, category: 'Physique', label: 'Particularités', field: 'particularites_physiques', symbol: '∧', name: 'Chevron Haut', meaning: 'ambition' },
  { id: 15, category: 'Physique', label: 'Vitalité', field: 'vitalite', symbol: '═', name: 'Double Barre', meaning: 'intensité' },
  { id: 16, category: 'Physique', label: 'Santé', field: 'etat_sante', symbol: '‖', name: 'Double Verticale', meaning: 'dualité' },
  { id: 17, category: 'Physique', label: 'Groupe sanguin', field: 'groupe_sanguin', symbol: 'S', name: 'S Minimaliste', meaning: 'émotion' },
  { id: 18, category: 'Physique', label: 'Énergie', field: 'type_energie_corporelle', symbol: 'Z', name: 'Z Minimaliste', meaning: 'chaos / bascule' },
  { id: 19, category: 'Physique', label: 'Mobilité', field: 'mobilite', symbol: '┐', name: 'Angle Droit', meaning: 'structure' },
  { id: 20, category: 'Physique', label: 'Sens dominant', field: 'sens_dominant', symbol: ')', name: 'Courbe Simple', meaning: 'mouvement intérieur' },
  
  // Ligne 3: Temps / Vie (21-30) - Émotion & Relationnel
  { id: 21, category: 'Émotion', label: 'Situation amoureuse', field: 'situation_amoureuse', symbol: '●─', name: 'Point-Barre', meaning: 'naissance' },
  { id: 22, category: 'Émotion', label: 'Enfants', field: 'enfants', symbol: '─●', name: 'Barre-Point', meaning: 'accomplissement' },
  { id: 23, category: 'Émotion', label: 'Type attachement', field: 'type_attachement', symbol: '●‖●', name: 'Passage', meaning: 'rite / transition' },
  { id: 24, category: 'Émotion', label: 'Blessure', field: 'blessure_emotionnelle', symbol: '●●●', name: 'Héritage', meaning: 'transmission' },
  { id: 25, category: 'Émotion', label: 'Relation à soi', field: 'relation_soi', symbol: 'C', name: 'Boucle', meaning: 'retour' },
  { id: 26, category: 'Émotion', label: 'Sensibilité', field: 'niveau_sensibilite', symbol: '(─', name: 'Arc Décalé', meaning: 'croissance lente' },
  { id: 27, category: 'Émotion', label: 'Empathie', field: 'empathie', symbol: '▪', name: 'Blocage', meaning: 'densité / fixation' },
  { id: 28, category: 'Émotion', label: 'Don émotionnel', field: 'don_emotionnel', symbol: '/', name: 'Ascension', meaning: 'montée' },
  { id: 29, category: 'Émotion', label: 'Don spirituel', field: 'don_spirituel', symbol: '\\', name: 'Descente', meaning: 'repos' },
  { id: 30, category: 'Émotion', label: 'Style amoureux', field: 'style_amoureux', symbol: '┴', name: 'Pivot', meaning: 'changement majeur' },
  
  // Ligne 4: Spirituels (31-40) - Éléments & Saisons
  { id: 31, category: 'Éléments', label: 'Saison intérieure', field: 'saison_interieure', symbol: '◠', name: 'Spire Montante', meaning: 'éveil' },
  { id: 32, category: 'Éléments', label: 'Élément dominant', field: 'element_dominant', symbol: '●→', name: 'Vision', meaning: 'direction spirituelle' },
  { id: 33, category: 'Éléments', label: 'Élément faible', field: 'element_faible', symbol: '∧', name: 'Réception', meaning: 'ouverture intérieure' },
  { id: 34, category: 'Éléments', label: 'Cycle actuel', field: 'cycle_actuel', symbol: '∨', name: 'Émission', meaning: 'rayonnement' },
  { id: 35, category: 'Éléments', label: 'Cycle futur', field: 'cycle_futur', symbol: '⊤', name: 'Porte', meaning: 'seuil / initiation' },
  { id: 36, category: 'Éléments', label: 'Alignement', field: 'alignement_naturel', symbol: '✕', name: 'Croisement Divin', meaning: 'destin supérieur' },
  { id: 37, category: 'Éléments', label: 'Adresse', field: 'adresse_actuelle', symbol: '=', name: 'Respiration', meaning: 'paix' },
  { id: 38, category: 'Éléments', label: 'Anciennes adresses', field: 'anciennes_adresses', symbol: '~', name: 'Onde Psychique', meaning: 'intuition' },
  { id: 39, category: 'Éléments', label: 'Voyages', field: 'voyages_importants', symbol: '⟞', name: 'Crochet Karmique', meaning: 'mémoire ancienne' },
  { id: 40, category: 'Éléments', label: 'Ville/Pays', field: 'pays', symbol: '─●─', name: 'Canal Spirituel', meaning: 'guidance' },
  
  // Ligne 5: Émotionnels (41-50) - Musique & Vibrations
  { id: 41, category: 'Musique', label: 'Note fondamentale', field: 'note_musicale', symbol: '(', name: 'Fragile', meaning: 'vulnérabilité' },
  { id: 42, category: 'Musique', label: 'Instrument', field: 'instrument_vibratoire', symbol: ')', name: 'Fort', meaning: 'protection' },
  { id: 43, category: 'Musique', label: 'Fréquence', field: 'frequence_dominante', symbol: '┄', name: 'Blessure', meaning: 'cassure' },
  { id: 44, category: 'Musique', label: 'Harmonie', field: 'harmonie_disharmonie', symbol: '━', name: 'Guérison', meaning: 'reconstruction' },
  { id: 45, category: 'Musique', label: 'Rythme', field: 'rythme_vie', symbol: '● ●', name: 'Dualité', meaning: 'deux polarités' },
  { id: 46, category: 'Musique', label: 'Mode vibratoire', field: 'mode_vibratoire', symbol: '●ˍ', name: 'Suspension', meaning: 'attente' },
  { id: 47, category: 'Musique', label: 'Couleur vibratoire', field: 'couleur_vibratoire', symbol: '◆', name: 'Cœur Géométrique', meaning: 'amour pur' },
  { id: 48, category: 'Musique', label: 'Arts', field: 'centres_interet_art', symbol: '⟷', name: 'Lien', meaning: 'relation' },
  { id: 49, category: 'Musique', label: 'Musique', field: 'centres_interet_musique', symbol: '~', name: 'Onde Faible', meaning: 'sensibilité' },
  { id: 50, category: 'Musique', label: 'Spiritualité', field: 'centres_interet_spiritualite', symbol: '≈', name: 'Onde Forte', meaning: 'transformation émotionnelle' },
  
  // Ligne 6: Naturels (51-60) - Archétypes & Personnalité
  { id: 51, category: 'Archétypes', label: 'Archétype principal', field: 'archetype_dominant', symbol: '◁', name: 'Feuille', meaning: 'croissance' },
  { id: 52, category: 'Archétypes', label: 'Archétype secondaire', field: 'archetype_secondaire', symbol: '●', name: 'Graine', meaning: 'origine' },
  { id: 53, category: 'Archétypes', label: 'Traits dominants', field: 'traits_dominants', symbol: '│', name: 'Tronc', meaning: 'racine' },
  { id: 54, category: 'Archétypes', label: 'Défauts', field: 'defauts_travailler', symbol: '┤', name: 'Branche', meaning: 'expansion' },
  { id: 55, category: 'Archétypes', label: 'Forces', field: 'forces_principales', symbol: '⋱', name: 'Racines', meaning: 'passé profond' },
  { id: 56, category: 'Archétypes', label: 'Style décisionnel', field: 'style_decisionnel', symbol: '∩', name: 'Colline', meaning: 'épreuve douce' },
  { id: 57, category: 'Archétypes', label: 'Réaction stress', field: 'reaction_stress', symbol: '△', name: 'Montagne', meaning: 'ascension' },
  { id: 58, category: 'Archétypes', label: 'Intuition', field: 'niveau_intuition', symbol: '💧', name: 'Goutte', meaning: 'émotion pure' },
  { id: 59, category: 'Archétypes', label: 'Nature', field: 'centres_interet_nature', symbol: '～', name: 'Vent', meaning: 'mouvement de vie' },
  { id: 60, category: 'Archétypes', label: 'Sport', field: 'centres_interet_sport', symbol: '○', name: 'Soleil', meaning: 'vitalité' },
  
  // Ligne 7: Identitaires (61-70) - Histoire & Parcours
  { id: 61, category: 'Histoire', label: 'Moments fondateurs', field: 'moments_fondateurs', symbol: '/|', name: 'A abstrait', meaning: 'leadership' },
  { id: 62, category: 'Histoire', label: 'Ruptures', field: 'ruptures_changements', symbol: '|)', name: 'B abstrait', meaning: 'protection' },
  { id: 63, category: 'Histoire', label: 'Rencontres clés', field: 'rencontres_cles', symbol: '(', name: 'C abstrait', meaning: 'observation' },
  { id: 64, category: 'Histoire', label: 'Traumas', field: 'traumas_marquants', symbol: '|)', name: 'D abstrait', meaning: 'capacité / structure' },
  { id: 65, category: 'Histoire', label: 'Initiations', field: 'initiations', symbol: '//', name: 'M abstrait', meaning: 'créativité' },
  { id: 66, category: 'Histoire', label: 'Leçons apprises', field: 'lecons_apprises', symbol: 'S', name: 'S abstrait', meaning: 'sensibilité' },
  { id: 67, category: 'Histoire', label: 'Leçons en cours', field: 'lecons_en_cours', symbol: '⌐', name: 'L abstrait', meaning: 'loyauté' },
  { id: 68, category: 'Histoire', label: 'Leçons à venir', field: 'lecons_a_venir', symbol: '⊤', name: 'T abstrait', meaning: 'volonté' },
  { id: 69, category: 'Histoire', label: 'Passé', field: 'anciennes_adresses', symbol: '三', name: 'E abstrait', meaning: 'vision' },
  { id: 70, category: 'Histoire', label: 'Héritage', field: 'relation_parents', symbol: '|2', name: 'R abstrait', meaning: 'pensée' },
  
  // Ligne 8: Directionnels (71-80) - Vie professionnelle
  { id: 71, category: 'Professionnel', label: 'Métier actuel', field: 'metier_actuel', symbol: '↑', name: 'Nord', meaning: 'projection' },
  { id: 72, category: 'Professionnel', label: 'Métier idéal', field: 'metier_ideal', symbol: '↓', name: 'Sud', meaning: 'introspection' },
  { id: 73, category: 'Professionnel', label: 'Talent caché', field: 'talent_cache', symbol: '→', name: 'Est', meaning: 'mouvement' },
  { id: 74, category: 'Professionnel', label: 'Compétences', field: 'competences_cles', symbol: '←', name: 'Ouest', meaning: 'mémoire' },
  { id: 75, category: 'Professionnel', label: 'Projet', field: 'projet_en_cours', symbol: '↗', name: 'Nord-Est', meaning: 'ascension' },
  { id: 76, category: 'Professionnel', label: 'Ambition', field: 'ambition_future', symbol: '↖', name: 'Nord-Ouest', meaning: 'sagesse' },
  { id: 77, category: 'Professionnel', label: 'Style travail', field: 'style_travail', symbol: '↘', name: 'Sud-Est', meaning: 'libération' },
  { id: 78, category: 'Professionnel', label: 'Leadership', field: 'niveau_leadership', symbol: '↙', name: 'Sud-Ouest', meaning: 'dissolution' },
  { id: 79, category: 'Professionnel', label: 'Zone confort', field: 'zone_confort', symbol: '○●', name: 'Orbital', meaning: 'navigation intérieure' },
  { id: 80, category: 'Professionnel', label: 'Zone expansion', field: 'zone_expansion', symbol: '✚', name: 'Croix Directionnelle', meaning: 'alignement global' },
  
  // Ligne 9: Transformateurs (81-90) - Centres d'intérêt & Passions
  { id: 81, category: 'Passions', label: 'Arts', field: 'centres_interet_art', symbol: '─', name: 'Début', meaning: 'commencement' },
  { id: 82, category: 'Passions', label: 'Nature', field: 'centres_interet_nature', symbol: '━', name: 'Fin', meaning: 'achèvement' },
  { id: 83, category: 'Passions', label: 'Spiritualité', field: 'centres_interet_spiritualite', symbol: '⟰', name: 'Crochet Ascendant', meaning: 'initiation' },
  { id: 84, category: 'Passions', label: 'Sport', field: 'centres_interet_sport', symbol: '⟱', name: 'Crochet Descendant', meaning: 'abandon' },
  { id: 85, category: 'Passions', label: 'Cuisine', field: 'centres_interet_cuisine', symbol: 'Ƨ', name: 'Double Spirale', meaning: 'métamorphose' },
  { id: 86, category: 'Passions', label: 'Technologies', field: 'centres_interet_technologies', symbol: '◇', name: 'Carré Tourné', meaning: 'passage dimensionnel' },
  { id: 87, category: 'Passions', label: 'Cause sociale', field: 'cause_sociale', symbol: '◇', name: 'Sceau Simple', meaning: 'vérité' },
  { id: 88, category: 'Passions', label: 'Loisirs', field: 'loisirs_principaux', symbol: '◆', name: 'Sceau Double', meaning: 'vérité profonde' },
  { id: 89, category: 'Passions', label: 'Créativité', field: 'outils_creatifs', symbol: '◈', name: 'Sceau Trine', meaning: 'fusion' },
  { id: 90, category: 'Passions', label: 'Exploration', field: 'voyages_importants', symbol: 'π', name: 'Portail', meaning: 'ouverture dimensionnelle' },
  
  // Ligne 10: Ultimes (91-100) - Futur
  { id: 91, category: 'Futur', label: 'Intentions', field: 'intentions_futures', symbol: '●', name: 'Singularité', meaning: 'essence unique' },
  { id: 92, category: 'Futur', label: 'Objectifs', field: 'objectifs', symbol: '●─●', name: 'Lien Sacré', meaning: 'connexion' },
  { id: 93, category: 'Futur', label: 'Missions', field: 'missions', symbol: '●● ●', name: 'Trinité', meaning: 'tri-unité' },
  { id: 94, category: 'Futur', label: 'Vibrations', field: 'mots_cles_vibratoires', symbol: '(●)', name: 'Orbite', meaning: 'sphère personnelle' },
  { id: 95, category: 'Futur', label: 'Messages', field: 'messages_soi', symbol: '✖', name: 'Hypercroix', meaning: 'vérité absolue' },
  { id: 96, category: 'Futur', label: 'Mantras', field: 'mantras', symbol: '──', name: 'Ligne Infinie', meaning: 'existence' },
  { id: 97, category: 'Futur', label: 'Ressources', field: 'ressources_interieures', symbol: '~~', name: 'Onde Infinie', meaning: 'mémoire universelle' },
  { id: 98, category: 'Futur', label: 'Vision', field: 'vision_long_terme', symbol: '∇', name: 'Triangle Inversé Sacré', meaning: 'porte de l\'âme' },
  { id: 99, category: 'Futur', label: 'Potentiel', field: 'forces_principales', symbol: 'Ω', name: 'Omega', meaning: 'accomplissement' },
  { id: 100, category: 'Futur', label: 'Infini', field: 'mots_cles_vibratoires', symbol: 'Λ', name: 'Alpha', meaning: 'origine' }
];

// Données symboliques pour chaque symbole (lecture vibratoire complète)
export const SYMBOL_MEANINGS = {
  1: { saison: 'Printemps', element: 'Air', chakra: 'Couronne', polarite: 'Yang', direction: 'Est', note: 'Si', frequence: '963 Hz', etat: 'Actif', intervalle: 'Octave', archetype: 'Le Pionnier', commentaire: 'Le prénom porte la première vibration de ton identité, c\'est le son qui te nomme dans l\'univers.', suggestion: 'Médite sur la résonance de ton prénom.' },
  2: { saison: 'Été', element: 'Feu', chakra: 'Couronne', polarite: 'Yang', direction: 'Sud', note: 'La', frequence: '852 Hz', etat: 'Actif', intervalle: 'Septième', archetype: 'Le Passeur', commentaire: 'Le deuxième prénom enrichit ta signature sonore, il est ta facette cachée.', suggestion: 'Explore l\'histoire de ce prénom dans ta lignée.' },
  3: { saison: 'Automne', element: 'Terre', chakra: 'Racine', polarite: 'Yin', direction: 'Nord', note: 'Do', frequence: '256 Hz', etat: 'Aligné', intervalle: 'Fondamentale', archetype: 'L\'Ancêtre', commentaire: 'Le nom de famille ancre ton lignage terrestre et ta transmission familiale.', suggestion: 'Honore tes racines et ton héritage.' },
  4: { saison: 'Hiver', element: 'Eau', chakra: 'Sacré', polarite: 'Yin', direction: 'Ouest', note: 'Ré', frequence: '288 Hz', etat: 'Dormant', intervalle: 'Seconde', archetype: 'Le Créateur', commentaire: 'Le pseudo est ton identité choisie, celle que tu construis librement.', suggestion: 'Crée-toi consciemment.' },
  5: { saison: 'Printemps', element: 'Éther', chakra: 'Troisième œil', polarite: 'Neutre', direction: 'Centre', note: 'Sol', frequence: '384 Hz', etat: 'En transformation', intervalle: 'Quinte', archetype: 'Le Prophète', commentaire: 'Ta date de naissance fixe ton cycle cosmique et ton chemin de vie.', suggestion: 'Étudie ta numérologie et ton thème astral.' },
  6: { saison: 'Été', element: 'Feu', chakra: 'Plexus', polarite: 'Yang', direction: 'Sud-Est', note: 'La', frequence: '426 Hz', etat: 'Actif', intervalle: 'Sixième', archetype: 'Le Gardien du Temps', commentaire: 'L\'heure de naissance précise ton ascendant et ton rayonnement.', suggestion: 'Médite à l\'heure de ta naissance.' },
  7: { saison: 'Automne', element: 'Terre', chakra: 'Racine', polarite: 'Yin', direction: 'Nord-Ouest', note: 'Mi', frequence: '320 Hz', etat: 'Aligné', intervalle: 'Tierce', archetype: 'L\'Enraciné', commentaire: 'Le lieu de naissance est ton premier contact avec la Terre.', suggestion: 'Retourne sur ta terre natale si possible.' },
  8: { saison: 'Hiver', element: 'Eau', chakra: 'Sacré', polarite: 'Yin', direction: 'Ouest', note: 'Fa', frequence: '341 Hz', etat: 'Dormant', intervalle: 'Quarte', archetype: 'Le Voyageur', commentaire: 'Ton pays d\'origine définit ta première culture et ton identité collective.', suggestion: 'Explore tes racines culturelles.' },
  9: { saison: 'Printemps', element: 'Air', chakra: 'Gorge', polarite: 'Yang', direction: 'Est', note: 'Si', frequence: '480 Hz', etat: 'Actif', intervalle: 'Septième', archetype: 'Le Citoyen du Monde', commentaire: 'Ta nationalité est ton appartenance légale et symbolique.', suggestion: 'Questionne ton rapport à l\'identité nationale.' },
  10: { saison: 'Été', element: 'Éther', chakra: 'Gorge', polarite: 'Neutre', direction: 'Centre', note: 'Do', frequence: '512 Hz', etat: 'En transformation', intervalle: 'Octave', archetype: 'Le Polyglotte', commentaire: 'Les langues parlées sont des portes vers d\'autres mondes et pensées.', suggestion: 'Apprends une nouvelle langue pour élargir ta conscience.' }
};

// Générer les données manquantes pour les symboles 11-100 avec des valeurs par défaut
for (let i = 11; i <= 100; i++) {
  if (!SYMBOL_MEANINGS[i]) {
    const seasons = ['Printemps', 'Été', 'Automne', 'Hiver'];
    const elements = ['Terre', 'Eau', 'Air', 'Feu', 'Éther'];
    const chakras = ['Racine', 'Sacré', 'Plexus', 'Cœur', 'Gorge', 'Troisième œil', 'Couronne'];
    const polarites = ['Yin', 'Yang', 'Neutre'];
    const directions = ['Nord', 'Sud', 'Est', 'Ouest', 'Nord-Est', 'Nord-Ouest', 'Sud-Est', 'Sud-Ouest', 'Centre'];
    const notes = ['Do', 'Ré', 'Mi', 'Fa', 'Sol', 'La', 'Si'];
    const etats = ['Dormant', 'Actif', 'Aligné', 'En transformation'];
    const intervalles = ['Fondamentale', 'Seconde', 'Tierce', 'Quarte', 'Quinte', 'Sixième', 'Septième', 'Octave'];
    
    SYMBOL_MEANINGS[i] = {
      saison: seasons[i % seasons.length],
      element: elements[i % elements.length],
      chakra: chakras[i % chakras.length],
      polarite: polarites[i % polarites.length],
      direction: directions[i % directions.length],
      note: notes[i % notes.length],
      frequence: `${256 + (i * 7)}Hz`,
      etat: etats[i % etats.length],
      intervalle: intervalles[i % intervalles.length],
      archetype: 'Le Chercheur',
      commentaire: `Ce symbole représente une dimension unique de votre être. Il vibre à une fréquence spécifique et porte une sagesse particulière.`,
      suggestion: 'Méditez sur ce symbole pour en comprendre la profondeur.'
    };
  }
}

export const getCategoryForSymbol = (symbolId) => {
  const symbol = SYMBOL_GRID_MAPPING.find(s => s.id === symbolId);
  return symbol?.category || 'Autre';
};

export const getFieldForSymbol = (symbolId) => {
  const symbol = SYMBOL_GRID_MAPPING.find(s => s.id === symbolId);
  return symbol?.field || null;
};

export const getSymbolData = (symbolId) => {
  return SYMBOL_GRID_MAPPING.find(s => s.id === symbolId);
};