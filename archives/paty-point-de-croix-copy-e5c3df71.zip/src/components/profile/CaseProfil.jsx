import React from 'react';
import { cn } from '@/lib/utils';

export default function CaseProfil({ symbol = '', color = '#E0E0E0', status = 'empty' }) {
  return (
    <div
      className="cursor-pointer transition-all hover:scale-105"
      style={{
        width: '24px',
        height: '24px',
        border: '1px solid #CCC',
        borderRadius: '4px',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        fontSize: '14px',
        backgroundColor: status === 'filled' ? color : '#FFF'
      }}
    >
      {symbol && <span>{symbol}</span>}
    </div>
  );
}