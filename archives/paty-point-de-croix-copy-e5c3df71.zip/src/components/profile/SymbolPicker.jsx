import React, { useState } from 'react';
import { X, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

const SYMBOLS = ['○', '●', '△', '▲', '□', '■', '☆', '✦', '✚', '≡'];

export default function SymbolPicker({ visible = false, onCancel, onValidate }) {
  const [selectedSymbol, setSelectedSymbol] = useState(null);

  if (!visible) return null;

  const handleValidate = () => {
    if (selectedSymbol && onValidate) {
      onValidate(selectedSymbol);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl shadow-2xl p-6 max-w-md w-full">
        <h3 className="text-lg font-semibold text-slate-900 mb-4">Choisir un symbole</h3>
        
        <div className="grid grid-cols-5 gap-3 mb-6">
          {SYMBOLS.map((symbol) => (
            <button
              key={symbol}
              onClick={() => setSelectedSymbol(symbol)}
              className={cn(
                "w-full aspect-square rounded-lg border-2 flex items-center justify-center text-2xl transition-all",
                selectedSymbol === symbol
                  ? "border-purple-500 bg-purple-50 scale-110"
                  : "border-slate-300 hover:border-slate-400 hover:bg-slate-50"
              )}
            >
              {symbol}
            </button>
          ))}
        </div>

        <div className="flex gap-3">
          <Button
            variant="outline"
            onClick={onCancel}
            className="flex-1 gap-2"
          >
            <X className="w-4 h-4" />
            Annuler
          </Button>
          <Button
            onClick={handleValidate}
            disabled={!selectedSymbol}
            className="flex-1 gap-2 bg-purple-600 hover:bg-purple-700"
          >
            <Check className="w-4 h-4" />
            Valider
          </Button>
        </div>
      </div>
    </div>
  );
}