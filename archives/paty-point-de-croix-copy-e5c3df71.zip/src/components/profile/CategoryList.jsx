import React from 'react';
import { Heart, Palette, Droplet, Camera, Users, Plane } from 'lucide-react';
import { cn } from '@/lib/utils';

const CATEGORIES = [
  { id: 'emotion', label: 'Émotions', icon: Heart },
  { id: 'style', label: 'Style & préférences', icon: Palette },
  { id: 'couleurs', label: 'Couleurs favorites', icon: Droplet },
  { id: 'souvenirs', label: 'Souvenirs & anecdotes', icon: Camera },
  { id: 'famille', label: 'Famille', icon: Users },
  { id: 'voyages', label: 'Voyages', icon: Plane }
];

export default function CategoryList({ selectedCategory, onSelectCategory }) {
  return (
    <div className="bg-white rounded-xl shadow-lg border border-slate-200 p-6">
      <h3 className="text-lg font-semibold text-slate-900 mb-4">Catégories</h3>
      <div className="space-y-2">
        {CATEGORIES.map((category) => {
          const Icon = category.icon;
          const isSelected = selectedCategory === category.id;
          
          return (
            <button
              key={category.id}
              onClick={() => onSelectCategory(category.id)}
              className={cn(
                "w-full px-4 py-3 rounded-lg flex items-center gap-3 transition-all text-left",
                isSelected
                  ? "bg-purple-600 text-white shadow-md"
                  : "bg-slate-50 hover:bg-slate-100 text-slate-700"
              )}
            >
              <Icon className="w-5 h-5" />
              <span className="font-medium">{category.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}