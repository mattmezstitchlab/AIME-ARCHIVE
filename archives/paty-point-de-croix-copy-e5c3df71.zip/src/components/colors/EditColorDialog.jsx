import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

export default function EditColorDialog({ open, onClose, color, onSave }) {
  const [editedColor, setEditedColor] = useState(null);

  useEffect(() => {
    if (color) {
      setEditedColor({ ...color });
    }
  }, [color]);

  const handleSave = () => {
    if (!editedColor) return;
    onSave(editedColor);
  };

  if (!editedColor) return null;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Modifier la couleur</DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="flex items-center gap-4">
            <div
              className="w-20 h-20 rounded-lg border-2 border-slate-300"
              style={{ backgroundColor: editedColor.hex }}
            />
            <div className="flex-1 space-y-3">
              <div>
                <Label htmlFor="hex">Code couleur (HEX)</Label>
                <Input
                  id="hex"
                  value={editedColor.hex}
                  onChange={(e) => setEditedColor({ ...editedColor, hex: e.target.value })}
                  placeholder="#000000"
                />
              </div>
            </div>
          </div>

          <div>
            <Label htmlFor="dmcNumber">Numéro DMC</Label>
            <Input
              id="dmcNumber"
              value={editedColor.dmcNumber}
              onChange={(e) => setEditedColor({ ...editedColor, dmcNumber: e.target.value })}
              placeholder="DMC-310"
            />
          </div>

          <div>
            <Label htmlFor="name">Nom de la couleur</Label>
            <Input
              id="name"
              value={editedColor.name}
              onChange={(e) => setEditedColor({ ...editedColor, name: e.target.value })}
              placeholder="Noir"
            />
          </div>

          <div>
            <Label htmlFor="symbol">Symbole</Label>
            <Input
              id="symbol"
              value={editedColor.symbol}
              onChange={(e) => setEditedColor({ ...editedColor, symbol: e.target.value })}
              placeholder="●"
              maxLength={2}
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Annuler
          </Button>
          <Button onClick={handleSave}>
            Enregistrer et appliquer
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}