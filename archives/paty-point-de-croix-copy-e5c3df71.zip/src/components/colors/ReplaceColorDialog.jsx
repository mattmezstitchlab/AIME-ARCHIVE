import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';
import { Search } from 'lucide-react';

// Import de la palette DMC complète
import { DMC_COLORS } from '../grid/dmcColors';

export default function ReplaceColorDialog({ open, onClose, currentColor, onReplace }) {
  const [selectedDMC, setSelectedDMC] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredDMC = DMC_COLORS.filter(dmc => 
    dmc.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    dmc.number.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleReplace = () => {
    if (!selectedDMC) return;
    onReplace(selectedDMC);
    setSelectedDMC(null);
    setSearchQuery('');
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[80vh]">
        <DialogHeader>
          <DialogTitle>Remplacer par une couleur DMC</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Couleur actuelle */}
          <div className="flex items-center gap-4 p-4 bg-slate-50 rounded-lg">
            <div>
              <div className="text-xs text-slate-600 mb-1">Couleur actuelle</div>
              <div className="flex items-center gap-3">
                <div
                  className="w-12 h-12 rounded border-2 border-slate-300"
                  style={{ backgroundColor: currentColor?.hex }}
                />
                <div>
                  <div className="font-semibold">{currentColor?.dmcNumber}</div>
                  <div className="text-sm text-slate-600">{currentColor?.name}</div>
                </div>
              </div>
            </div>
          </div>

          {/* Recherche */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input
              placeholder="Rechercher une couleur DMC..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>

          {/* Liste des couleurs DMC */}
          <div className="border border-slate-200 rounded-lg overflow-hidden">
            <div className="max-h-[400px] overflow-y-auto">
              <table className="w-full">
                <thead className="bg-slate-50 border-b border-slate-200 sticky top-0">
                  <tr>
                    <th className="px-4 py-2 text-left text-xs font-medium text-slate-600 w-16">Aperçu</th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-slate-600 w-24">DMC</th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-slate-600">Nom</th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-slate-600 w-32">Code HEX</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredDMC.map((dmc) => (
                    <tr
                      key={dmc.number}
                      onClick={() => setSelectedDMC(dmc)}
                      className={cn(
                        "cursor-pointer transition-colors border-b border-slate-100",
                        selectedDMC?.number === dmc.number
                          ? "bg-indigo-50"
                          : "hover:bg-slate-50"
                      )}
                    >
                      <td className="px-4 py-2">
                        <div
                          className="w-8 h-8 rounded border border-slate-300"
                          style={{ backgroundColor: dmc.hex }}
                        />
                      </td>
                      <td className="px-4 py-2 text-sm font-medium">{dmc.number}</td>
                      <td className="px-4 py-2 text-sm">{dmc.name}</td>
                      <td className="px-4 py-2 text-sm text-slate-600">{dmc.hex}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Annuler
          </Button>
          <Button onClick={handleReplace} disabled={!selectedDMC}>
            Remplacer la couleur
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}