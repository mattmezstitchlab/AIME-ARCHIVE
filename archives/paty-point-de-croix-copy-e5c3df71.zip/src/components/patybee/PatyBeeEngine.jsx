import { useState, useEffect } from 'react';

// PatyBee Engine – Moteur principal d'analyse IA
// Aucune logique conditionnelle contenant des hooks.
// Tous les hooks sont déclarés AU DÉBUT du composant et jamais dans des if/return dynamiques.

// Fonction d'analyse de détails (simplifié pour commencer)
const detectDetails = (imageData) => {
  if (!imageData) return 0.5;
  
  // Pour l'instant, on retourne une valeur par défaut
  // Dans une version avancée, on analyserait réellement les pixels de l'image
  // pour détecter contrastes, gradients, zones complexes, etc.
  return 0.5; // Valeur moyenne par défaut
};

// Détection du type de motif
const detectMotifType = (imageData, detailLevel) => {
  if (!imageData) return 'fantaisie';
  
  // Analyse simplifiée - à améliorer avec vraie détection IA
  if (detailLevel > 0.6) return 'portrait';
  if (detailLevel > 0.4) return 'paysage';
  if (detailLevel < 0.3) return 'icone';
  return 'fantaisie';
};

// Conversion vers palette DMC (simulation)
const generateDMCMapping = (imageData, colorCount) => {
  if (!imageData) return {};
  
  // Simulation de mapping DMC
  const mapping = {};
  const dmcRefs = ['310', 'B5200', '321', '666', '702', '798', '973', '3865', '817', '995'];
  const dmcNames = ['Noir', 'Blanc Neige', 'Rouge', 'Rouge Vif', 'Vert', 'Bleu Foncé', 'Jaune', 'Blanc Cassé', 'Rouge Corail', 'Bleu Ciel'];
  
  for (let i = 0; i < Math.min(colorCount, 10); i++) {
    mapping[`cluster_${i}`] = {
      dmc: dmcRefs[i] || '310',
      name: dmcNames[i] || 'Couleur',
      rgb: [128, 128, 128],
      usagePercent: Math.round(100 / colorCount)
    };
  }
  
  return mapping;
};

// Analyse du sens des points
const generateStitchDirectionMap = (detailLevel, motifType) => {
  const zones = [];
  
  if (motifType === 'portrait') {
    zones.push(
      { type: 'fond', direction: 'diagonal', technique: 'halfCross' },
      { type: 'contour', direction: 'horizontal', technique: 'backstitch' },
      { type: 'détail', direction: 'varié', technique: 'fullCross' }
    );
  } else if (motifType === 'paysage') {
    zones.push(
      { type: 'fond', direction: 'horizontal', technique: 'halfCross' },
      { type: 'contour', direction: 'varié', technique: 'backstitch' }
    );
  } else if (motifType === 'icone') {
    zones.push(
      { type: 'contour', direction: 'horizontal', technique: 'backstitch' },
      { type: 'remplissage', direction: 'varié', technique: 'fullCross' }
    );
  } else {
    zones.push(
      { type: 'fond', direction: 'varié', technique: 'halfCross' },
      { type: 'détail', direction: 'varié', technique: 'fullCross' }
    );
  }
  
  return { zones };
};

// Profil de qualité recommandé
const detectQualityProfile = (detailLevel, motifType) => {
  if (motifType === 'portrait') return 'superfine';
  if (motifType === 'paysage') return 'douce';
  if (motifType === 'icone') return 'standard';
  return 'standard';
};

export const usePatyBeeEngine = (imageData) => {
  // Hooks fixes obligatoires
  const [autoSize, setAutoSize] = useState({ width: 150, height: 150 });
  const [autoColors, setAutoColors] = useState(40);
  const [autoTechniques, setAutoTechniques] = useState({
    fullCross: true,
    halfCross: true,
    backstitch: true,
    fractionals: true,
    frenchKnots: false,
    beads: false,
    metallics: false,
    longStitch: false,
  });
  
  // Nouvelles couches IA
  const [dmcMapping, setDmcMapping] = useState({});
  const [qualityProfile, setQualityProfile] = useState('standard');
  const [stitchDirectionMap, setStitchDirectionMap] = useState({ zones: [] });
  const [proProfile, setProProfile] = useState('fantaisie');

  const [analysisDone, setAnalysisDone] = useState(false);

  // Analyse IA — Toujours appelée une seule fois
  useEffect(() => {
    if (!imageData || analysisDone) return;

    // 1) Détection de complexité
    const detailLevel = detectDetails(imageData); // renvoie 0 → 1

    // 2) Détection du type de motif
    const motifType = detectMotifType(imageData, detailLevel);
    setProProfile(motifType);

    // 3) Dimensions recommandées (ajustées selon le type)
    let baseSize = 120 + Math.round(detailLevel * 80);
    if (motifType === 'portrait') baseSize = Math.max(150, baseSize);
    if (motifType === 'icone') baseSize = Math.min(120, baseSize);
    
    setAutoSize({
      width: baseSize,
      height: baseSize,
    });

    // 4) Profil de qualité recommandé
    const quality = detectQualityProfile(detailLevel, motifType);
    setQualityProfile(quality);

    // 5) Nombres de couleurs recommandées (ajustées selon qualité)
    let recommendedColors = 20 + Math.round(detailLevel * 50);
    if (quality === 'superfine') recommendedColors = Math.round(recommendedColors * 1.2);
    if (quality === 'douce') recommendedColors = Math.round(recommendedColors * 0.8);
    setAutoColors(recommendedColors);

    // 6) Conversion DMC
    const mapping = generateDMCMapping(imageData, recommendedColors);
    setDmcMapping(mapping);

    // 7) Techniques recommandées (ajustées selon le profil)
    let techniques = {
      fullCross: true,
      halfCross: detailLevel > 0.15,
      backstitch: detailLevel > 0.20,
      fractionals: detailLevel > 0.35,
      frenchKnots: detailLevel > 0.55,
      beads: detailLevel > 0.55,
      metallics: detailLevel > 0.70,
      longStitch: detailLevel > 0.75,
    };
    
    // Ajustements par profil
    if (motifType === 'portrait') {
      techniques.backstitch = true;
      techniques.halfCross = true;
    } else if (motifType === 'paysage') {
      techniques.halfCross = true;
      techniques.longStitch = true;
    } else if (motifType === 'icone') {
      techniques.backstitch = true;
      techniques.frenchKnots = false;
      techniques.beads = false;
    } else if (motifType === 'fantaisie') {
      techniques.frenchKnots = true;
      techniques.beads = true;
      techniques.metallics = detailLevel > 0.5;
    }
    
    setAutoTechniques(techniques);

    // 8) Analyse du sens des points
    const directionMap = generateStitchDirectionMap(detailLevel, motifType);
    setStitchDirectionMap(directionMap);

    setAnalysisDone(true);
  }, [imageData, analysisDone]);

  // Retourne les résultats stables
  return {
    autoSize,
    autoColors,
    autoTechniques,
    dmcMapping,
    qualityProfile,
    stitchDirectionMap,
    proProfile,
    analysisDone,
  };
};