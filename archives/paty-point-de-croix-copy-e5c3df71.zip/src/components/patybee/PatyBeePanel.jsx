import React, { useEffect, useRef, useState } from 'react';
import { X, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { motion, AnimatePresence } from 'framer-motion';
import { usePatyBee } from './PatyBeeContext';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

// Configuration BroodIA
const BROODIA = {
  name: 'BroodIA',
  greeting: "Hey ! Comment je peux t'aider ?",
  style: 'cool, fun, complice'
};

export default function PatyBeePanel({ isOpen, onClose }) {
  const {
    messages,
    addMessage,
    handleButtonAction,
    handleQuestionResponse,
    handleSymbolSelection
  } = usePatyBee();
  
  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);
  const [hasShownWelcome, setHasShownWelcome] = useState(false);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [userProfile, setUserProfile] = useState(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Message de bienvenue unique à l'ouverture
  useEffect(() => {
    if (isOpen && !hasShownWelcome && messages.length === 0) {
      setHasShownWelcome(true);
    }
    
    // Reset quand le panneau se ferme
    if (!isOpen) {
      setHasShownWelcome(false);
    }
  }, [isOpen]);

  // Charger le profil utilisateur pour le contexte
  useEffect(() => {
    const loadUserProfile = async () => {
      try {
        const user = await base44.auth.me();
        if (user) {
          const profiles = await base44.entities.UserProfile.filter({ created_by: user.email });
          if (profiles[0]) {
            setUserProfile(profiles[0]);
          }
        }
      } catch (error) {
        console.error('Erreur chargement profil:', error);
      }
    };
    
    if (isOpen) {
      loadUserProfile();
    }
  }, [isOpen]);

  // Envoyer un message
  const handleSendMessage = async () => {
    if (!inputValue.trim() || isLoading) return;

    const userMessage = inputValue.trim();
    setInputValue('');
    
    // Ajouter le message utilisateur
    addMessage({
      role: 'user',
      content: userMessage
    });

    setIsLoading(true);

    try {
      // Préparer le contexte utilisateur
      const context = buildUserContext();
      
      // Appeler l'IA avec le contexte
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `Tu es BroodIA, un assistant IA spécialisé en broderie point de croix.

STYLE : Cool, fun, complice, léger. Jamais infantilisant.
- Phrases courtes, claires, positives.
- Humour subtil possible.
- Toujours rassurant : "On va gérer ça ensemble."
- Max 2-3 phrases.

Tu peux aider sur :
- Navigation (GPS, zones, zoom)
- Couleurs DMC et symboles
- Outils (crayon, gomme, sélection)
- Affichage et filtres
- Import/Export
- Analyse de grille

Exemples de réponses :
- "Yes ! Direction D8 🚀"
- "Zoom x2, tu vas y voir super clair."
- "J'affiche la couleur 310, focus total 😎"

Contexte utilisateur:
${context}

Question: ${userMessage}

Réponds de manière concise, cool et fun.`,
        response_json_schema: null
      });

      // Ajouter la réponse de l'IA
      addMessage({
        role: 'assistant',
        content: response || "Je suis désolée, je n'ai pas pu traiter ta question. Peux-tu reformuler ?"
      });

    } catch (error) {
      console.error('Erreur IA:', error);
      addMessage({
        role: 'assistant',
        content: "Oups, petit bug 😅 On réessaie ?"
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Construire le contexte utilisateur pour l'IA
  const buildUserContext = () => {
    if (!userProfile) {
      return "Niveau: débutant (profil non renseigné)";
    }

    const profilCreatif = userProfile.profil_creatif || {};
    const parts = [];

    if (profilCreatif.niveau) {
      parts.push(`Niveau: ${profilCreatif.niveau}`);
    }

    if (profilCreatif.couleurs_favorites?.length > 0) {
      parts.push(`Couleurs favorites: ${profilCreatif.couleurs_favorites.join(', ')}`);
    }

    if (profilCreatif.styles_artistiques?.length > 0) {
      parts.push(`Styles artistiques: ${profilCreatif.styles_artistiques.join(', ')}`);
    }

    if (profilCreatif.rythme_broderie) {
      parts.push(`Rythme de broderie: ${profilCreatif.rythme_broderie}`);
    }

    return parts.length > 0 ? parts.join('\n') : "Profil en cours de construction";
  };

  // Gérer la touche Entrée
  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, y: 20, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 20, scale: 0.95 }}
          transition={{ type: 'spring', damping: 25, stiffness: 300 }}
          className="fixed bottom-6 right-6 w-96 h-[500px] bg-white shadow-2xl flex flex-col rounded-2xl border border-slate-200"
          style={{ zIndex: 99999 }}
        >
          {/* Header */}
          <div className="bg-black p-4 flex items-center justify-between rounded-t-2xl border-b border-[#232323]">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 bg-black rounded-lg border-2 border-[#F5C200] flex items-center justify-center">
                <span className="text-white text-xs font-bold">IA</span>
              </div>
              <div>
                <h3 className="font-bold text-white">{BROODIA.name}</h3>
                <p className="text-xs text-gray-400">Ton assistant cool 😎</p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              className="text-white hover:bg-white/10"
            >
              <X className="w-5 h-5" />
            </Button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-[#F9F9F9]">
            {messages.length === 0 && (
              <div className="text-center py-8">
                <div className="w-16 h-16 bg-black rounded-lg border-2 border-[#F5C200] flex items-center justify-center mx-auto mb-4">
                  <span className="text-white text-xl font-bold">IA</span>
                </div>
                <p className="text-sm text-slate-600">
                  Hey ! Je suis {BROODIA.name} 😎
                  <br />
                  {BROODIA.greeting}
                </p>
              </div>
            )}
            
            {messages.map((message, index) => (
              <div
                key={index}
                className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`max-w-[85%] ${message.role === 'user' ? 'flex justify-end' : ''}`}>
                  {message.role === 'assistant' && (
                    <div className="w-6 h-6 bg-black rounded-md border-2 border-[#F5C200] flex items-center justify-center mr-2 flex-shrink-0 mt-1">
                      <span className="text-white text-[10px] font-bold">IA</span>
                    </div>
                  )}
                  <div>
                    <div
                      className={`rounded-lg p-3 ${
                        message.role === 'user'
                          ? 'bg-slate-800 text-white'
                          : 'bg-white text-slate-900 border-l-3 border-black'
                      }`}
                    >
                      <p className="text-sm whitespace-pre-wrap leading-relaxed">{message.content}</p>
                    </div>

                    {/* Boutons d'action */}
                    {message.buttons && (
                      <div className="flex flex-wrap gap-2 mt-2">
                        {message.buttons.map((button, btnIndex) => (
                          <Button
                            key={btnIndex}
                            size="sm"
                            variant="outline"
                            onClick={() => handleButtonAction(button.action)}
                            className="text-xs"
                          >
                            {button.label}
                          </Button>
                        ))}
                      </div>
                    )}

                    {/* Options de réponse */}
                    {message.options && (
                      <div className="flex flex-col gap-2 mt-2">
                        {message.options.map((option, optIndex) => (
                          <Button
                            key={optIndex}
                            size="sm"
                            variant="outline"
                            onClick={() => handleQuestionResponse(option)}
                            className="text-xs text-left justify-start"
                          >
                            {option}
                          </Button>
                        ))}
                      </div>
                    )}

                    {/* Sélection de symboles */}
                    {message.symbols && (
                      <div className="grid grid-cols-5 gap-2 mt-2">
                        {message.symbols.map((symbol, symIndex) => (
                          <Button
                            key={symIndex}
                            size="sm"
                            variant="outline"
                            onClick={() => handleSymbolSelection(symbol)}
                            className="text-lg h-10 w-10 p-0"
                          >
                            {symbol}
                          </Button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          {/* Champ de saisie + bouton envoyer */}
          <div className="px-4 py-3 bg-white border-t border-[#E5E5E5]">
            <div className="flex gap-2">
              <Input
                ref={inputRef}
                type="text"
                placeholder="Dis-moi ce dont t'as besoin..."
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyPress={handleKeyPress}
                disabled={isLoading}
                className="flex-1 text-sm"
              />
              <Button
                onClick={handleSendMessage}
                disabled={!inputValue.trim() || isLoading}
                className="bg-black hover:bg-[#1A1A1A] text-white font-semibold rounded-md shadow-md"
                size="sm"
              >
                {isLoading ? (
                  <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <Send className="w-4 h-4" />
                )}
              </Button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}