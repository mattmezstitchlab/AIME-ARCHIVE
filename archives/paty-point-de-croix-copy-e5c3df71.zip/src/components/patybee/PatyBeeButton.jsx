import React from 'react';
import { usePatyBee } from './PatyBeeContext';
import { Button } from '@/components/ui/button';
import { getTutorial } from './tutorials';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu';
import { HelpCircle, BookOpen, Sparkles } from 'lucide-react';

export default function PatyBeeButton() {
  const { startTutorial, moveTo } = usePatyBee();

  const handleTutorial = (tutorialName) => {
    const steps = getTutorial(tutorialName);
    if (steps.length > 0) {
      startTutorial(steps);
    }
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="outline"
          size="sm"
          className="gap-2 bg-yellow-50 border-yellow-300 text-yellow-900 hover:bg-yellow-100"
        >
          <span className="text-lg">🐝</span>
          Aide PatyBee
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-64">
        <div className="px-2 py-2">
          <p className="text-xs text-slate-600 mb-2">
            Tutoriels pas à pas avec PatyBee
          </p>
        </div>
        
        <DropdownMenuSeparator />
        
        <DropdownMenuItem onClick={() => handleTutorial('firstSteps')}>
          <Sparkles className="w-4 h-4 mr-2" />
          Premiers pas sur PatyBee
        </DropdownMenuItem>
        
        <DropdownMenuItem onClick={() => handleTutorial('createGridFromImage')}>
          <BookOpen className="w-4 h-4 mr-2" />
          Créer une grille depuis une image
        </DropdownMenuItem>
        
        <DropdownMenuItem onClick={() => handleTutorial('importPdfMosaic')}>
          <BookOpen className="w-4 h-4 mr-2" />
          Importer un PDF en mosaïque
        </DropdownMenuItem>
        
        <DropdownMenuItem onClick={() => handleTutorial('createGridWithMosaic')}>
          <BookOpen className="w-4 h-4 mr-2" />
          Créer une grille avec mosaïque
        </DropdownMenuItem>
        
        <DropdownMenuItem onClick={() => handleTutorial('useMinimap')}>
          <BookOpen className="w-4 h-4 mr-2" />
          Utiliser la mini-carte
        </DropdownMenuItem>
        
        <DropdownMenuItem onClick={() => handleTutorial('useDailyZone')}>
          <BookOpen className="w-4 h-4 mr-2" />
          Zone du jour
        </DropdownMenuItem>
        
        <DropdownMenuItem onClick={() => handleTutorial('publishToShop')}>
          <BookOpen className="w-4 h-4 mr-2" />
          Publier dans la boutique
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}