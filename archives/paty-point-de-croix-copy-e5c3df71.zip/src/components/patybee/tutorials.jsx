// Définitions des tutoriels pas à pas pour PatyBee

export const TUTORIALS = {
  // Tutoriel : Créer une grille depuis une image
  createGridFromImage: [
    {
      target: '[data-patybee="import-button"]',
      message: '🐝 Étape 1/4 – Cliquez sur "Importer" pour choisir votre image.'
    },
    {
      target: '[data-patybee="image-import-option"]',
      message: '🐝 Étape 2/4 – Sélectionnez "Image (PNG / JPG)" pour importer votre photo.'
    },
    {
      target: '[data-patybee="file-selector"]',
      message: '🐝 Étape 3/4 – Choisissez votre fichier image depuis votre ordinateur.'
    },
    {
      target: '[data-patybee="generate-button"]',
      message: '🐝 Étape 4/4 – Ajustez les paramètres puis cliquez sur "Générer le motif". Votre grille sera créée automatiquement !'
    }
  ],

  // Tutoriel : Import PDF avec mosaïque
  importPdfMosaic: [
    {
      target: '[data-patybee="import-button"]',
      message: '🐝 Étape 1/5 – Commençons par cliquer sur "Importer".'
    },
    {
      target: '[data-patybee="pdf-mosaic-option"]',
      message: '🐝 Étape 2/5 – Sélectionnez "PDF complet (mosaïque de grilles)" pour reconstituer toutes les pages.'
    },
    {
      target: '[data-patybee="pdf-upload"]',
      message: '🐝 Étape 3/5 – Choisissez votre fichier PDF contenant les pages de grille.'
    },
    {
      target: '[data-patybee="mosaic-preview"]',
      message: '🐝 Étape 4/5 – Visualisez la mosaïque reconstituée. Chaque page est alignée automatiquement.'
    },
    {
      target: '[data-patybee="validate-mosaic"]',
      message: '🐝 Étape 5/5 – Validez la reconstitution. Votre grille complète est maintenant disponible !'
    }
  ],

  // Tutoriel : Nouvelle grille avec mosaïque
  createGridWithMosaic: [
    {
      target: '[data-patybee="new-grid-button"]',
      message: '🐝 Étape 1/4 – Cliquez sur "Nouvelle grille" pour commencer.'
    },
    {
      target: '[data-patybee="grid-size-selector"]',
      message: '🐝 Étape 2/4 – Choisissez la taille de votre grille (ex: 200×200).'
    },
    {
      target: '[data-patybee="mosaic-mode"]',
      message: '🐝 Étape 3/4 – Activez le mode mosaïque et sélectionnez le format (ex: 4×3 pages).'
    },
    {
      target: '[data-patybee="create-grid"]',
      message: '🐝 Étape 4/4 – Créez votre grille ! Les repères rouges de la mosaïque apparaîtront automatiquement.'
    }
  ],

  // Tutoriel : Publier dans la boutique
  publishToShop: [
    {
      target: '[data-patybee="projects-button"]',
      message: '🐝 Étape 1/5 – Ouvrez vos projets pour choisir la grille à publier.'
    },
    {
      target: '[data-patybee="project-item"]',
      message: '🐝 Étape 2/5 – Sélectionnez la grille que vous souhaitez vendre.'
    },
    {
      target: '[data-patybee="publish-button"]',
      message: '🐝 Étape 3/5 – Cliquez sur "Publier dans la boutique".'
    },
    {
      target: '[data-patybee="shop-form"]',
      message: '🐝 Étape 4/5 – Remplissez bien le titre, la description et fixez votre prix. Une belle présentation attire plus d\'acheteurs !'
    },
    {
      target: '[data-patybee="confirm-publish"]',
      message: '🐝 Étape 5/5 – Validez la publication. Votre grille sera visible dans la boutique PatyBee ! 🎉'
    }
  ],

  // Tutoriel : Utiliser la mini-carte
  useMinimap: [
    {
      target: '[data-patybee="minimap"]',
      message: '🐝 Étape 1/3 – Voici la mini-carte ! Elle affiche une vue d\'ensemble de votre grille.'
    },
    {
      target: '[data-patybee="minimap"]',
      message: '🐝 Étape 2/3 – Le rectangle blanc montre la zone actuellement visible dans la grille.'
    },
    {
      target: '[data-patybee="minimap"]',
      message: '🐝 Étape 3/3 – Cliquez n\'importe où sur la mini-carte pour vous déplacer instantanément à cet endroit !'
    }
  ],

  // Tutoriel : Zone du jour
  useDailyZone: [
    {
      target: '[data-patybee="daily-zone-button"]',
      message: '🐝 Étape 1/3 – Activez l\'outil "Zone du jour" pour délimiter votre zone de broderie.'
    },
    {
      target: '[data-patybee="grid-canvas"]',
      message: '🐝 Étape 2/3 – Tracez un rectangle sur la grille pour définir votre zone de travail quotidienne.'
    },
    {
      target: '[data-patybee="daily-zone-info"]',
      message: '🐝 Étape 3/3 – La zone sera surlignée en jaune. Vous pouvez la centrer ou l\'effacer à tout moment !'
    }
  ],

  // Tutoriel : Premier pas
  firstSteps: [
    {
      target: '[data-patybee="new-grid-button"]',
      message: '🐝 Bienvenue sur PatyBee ! Commençons par créer votre première grille. Cliquez ici.'
    },
    {
      target: '[data-patybee="import-button"]',
      message: '🐝 Ou importez une image existante pour la transformer en grille de point de croix.'
    },
    {
      target: '[data-patybee="toolbar"]',
      message: '🐝 La barre d\'outils vous donne accès à tous les outils : zoom, dessin, couleurs, symboles...'
    },
    {
      target: '[data-patybee="minimap"]',
      message: '🐝 La mini-carte vous aide à naviguer sur les grandes grilles. Je suis là si vous avez besoin d\'aide ! 🐝'
    }
  ]
};

// Helper pour récupérer un tutoriel
export function getTutorial(name) {
  return TUTORIALS[name] || [];
}