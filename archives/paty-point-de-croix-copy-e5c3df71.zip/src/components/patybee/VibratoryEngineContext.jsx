import React, { createContext, useContext, useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';

const VibratoryEngineContext = createContext();

export const useVibratoryEngine = () => {
  const context = useContext(VibratoryEngineContext);
  if (!context) {
    throw new Error('useVibratoryEngine must be used within VibratoryEngineProvider');
  }
  return context;
};

export const VibratoryEngineProvider = ({ children }) => {
  const [vibrationData, setVibrationData] = useState(null);
  const [vibrationCode, setVibrationCode] = useState(null);
  const [generatedMusic, setGeneratedMusic] = useState(null);
  const [generatedStory, setGeneratedStory] = useState(null);
  const [certificate, setCertificate] = useState(null);

  // [LOGIC:VIB_DATA_COLLECTION]
  const collectVibratoryData = (userProfile, userSignals) => {
    const data = {
      color_profile: userProfile.palette || [],
      shape_profile: userProfile.style || 'mixed',
      zone_flow: userProfile.flow || 'normal',
      emotion: userSignals.emotional_pattern || [],
      rhythm: userSignals.rhythm || 'normal',
      completion: {
        projects_created: userSignals.history?.projects_created || 0,
        projects_completed: userSignals.history?.projects_completed || 0
      }
    };
    
    setVibrationData(data);
    return data;
  };

  // [LOGIC:VIBRATION_CODE]
  const generateVibrationCode = (data) => {
    if (!data) return null;
    
    const codeComponents = [
      data.color_profile.map(c => c.hex).join(''),
      data.shape_profile,
      data.zone_flow,
      data.emotion.join(''),
      data.rhythm
    ].join('|');
    
    // Simple hash-like code (128 caractères)
    const hash = btoa(codeComponents).replace(/[^a-zA-Z0-9]/g, '').substring(0, 128);
    setVibrationCode(hash);
    return hash;
  };

  // [LOGIC:MUSIC_GENERATION]
  const generateMusic = async (data) => {
    if (!data) return null;
    
    const musicParams = {
      style: matchStyle(data.shape_profile),
      tempo: mapRhythmToTempo(data.rhythm),
      harmony: mapPaletteToChords(data.color_profile),
      energy: mapEmotionToIntensity(data.emotion),
      structure: buildStructure(data.completion)
    };
    
    // Générer description musicale
    const musicDescription = `
Style: ${musicParams.style}
Tempo: ${musicParams.tempo} BPM
Harmonie: ${musicParams.harmony.join(', ')}
Énergie: ${musicParams.energy}/10
Structure: ${musicParams.structure}
    `.trim();
    
    const music = {
      params: musicParams,
      description: musicDescription,
      url: null // À implémenter avec API musicale
    };
    
    setGeneratedMusic(music);
    return music;
  };

  const matchStyle = (shapeProfile) => {
    const styles = {
      nature: 'Organique et fluide',
      geometric: 'Minimaliste et rythmée',
      decorative: 'Ornementale et riche',
      mixed: 'Éclectique et variée'
    };
    return styles[shapeProfile] || styles.mixed;
  };

  const mapRhythmToTempo = (rhythm) => {
    const tempos = {
      slow: 70,
      normal: 90,
      fast: 110
    };
    return tempos[rhythm] || 90;
  };

  const mapPaletteToChords = (palette) => {
    if (!palette || palette.length === 0) return ['C', 'Am', 'F', 'G'];
    
    const chordMap = {
      warm: ['C', 'F', 'G', 'Am'],
      cold: ['Am', 'Dm', 'E', 'C'],
      pastel: ['Cmaj7', 'Fmaj7', 'Am7', 'G'],
      vibrant: ['C', 'E', 'Am', 'F']
    };
    
    // Classifier la palette
    const avgBrightness = palette.reduce((sum, c) => {
      const hex = c.hex.replace('#', '');
      const r = parseInt(hex.substr(0, 2), 16);
      const g = parseInt(hex.substr(2, 2), 16);
      const b = parseInt(hex.substr(4, 2), 16);
      return sum + (r + g + b) / 3;
    }, 0) / palette.length;
    
    if (avgBrightness > 200) return chordMap.pastel;
    if (avgBrightness > 150) return chordMap.warm;
    if (avgBrightness > 100) return chordMap.vibrant;
    return chordMap.cold;
  };

  const mapEmotionToIntensity = (emotions) => {
    if (!emotions || emotions.length === 0) return 5;
    
    const intensityMap = {
      'apaisée': 3,
      'énergique': 9,
      'nostalgique': 4,
      'concentrée': 6,
      'joyeuse': 8,
      'calme': 2,
      'intense': 10
    };
    
    const avg = emotions.reduce((sum, e) => {
      return sum + (intensityMap[e.toLowerCase()] || 5);
    }, 0) / emotions.length;
    
    return Math.round(avg);
  };

  const buildStructure = (completion) => {
    const ratio = completion.projects_completed / Math.max(completion.projects_created, 1);
    
    if (ratio > 0.8) return 'Complète et aboutie';
    if (ratio > 0.5) return 'Équilibrée et progressive';
    if (ratio > 0.2) return 'Exploratoire et libre';
    return 'Émergente et spontanée';
  };

  // [LOGIC:STORY_GENERATION]
  const generateStory = async (data) => {
    if (!data) return null;
    
    const storyElements = {
      theme: deriveThemeFromPalette(data.color_profile),
      symbols: deriveSymbolsNarrative(data.shape_profile),
      emotion: deriveEmotionNarrative(data.emotion),
      flow: deriveFlowNarrative(data.zone_flow)
    };
    
    // Générer texte poétique
    const story = `
${storyElements.theme}

${storyElements.symbols}

${storyElements.emotion}

${storyElements.flow}

Chaque point de croix est une note.
Chaque couleur, une vibration.
Chaque symbole, un fragment d'âme.
    `.trim();
    
    setGeneratedStory(story);
    return story;
  };

  const deriveThemeFromPalette = (palette) => {
    if (!palette || palette.length === 0) {
      return "Dans un espace infini, une signature prend forme.";
    }
    
    const colorCount = palette.length;
    
    if (colorCount <= 3) {
      return "Dans la simplicité, l'essentiel se révèle. Trois couleurs pour dire l'infini.";
    } else if (colorCount <= 7) {
      return "Un arc-en-ciel discret traverse ta signature. Chaque nuance porte un secret.";
    } else {
      return "Ta palette déborde de vie. Les couleurs dansent et se mêlent en une symphonie visuelle.";
    }
  };

  const deriveSymbolsNarrative = (style) => {
    const narratives = {
      nature: "Des fleurs brodées racontent le printemps que tu portes en toi.",
      geometric: "Des formes pures dessinent l'ordre de tes pensées.",
      decorative: "Des motifs ornementaux révèlent la richesse de ton univers intérieur.",
      mixed: "Libre et unique, ta broderie refuse les cadres."
    };
    return narratives[style] || narratives.mixed;
  };

  const deriveEmotionNarrative = (emotions) => {
    if (!emotions || emotions.length === 0) {
      return "Une émotion silencieuse guide chaque geste.";
    }
    
    const emotionText = emotions.join(', ');
    return `${emotionText} : voilà les émotions que tu tisses dans le fil.`;
  };

  const deriveFlowNarrative = (flow) => {
    const narratives = {
      structured: "Tu brodes avec méthode, zone par zone, comme on construit une cathédrale.",
      fluid: "Ton fil court librement sur la toile, au rythme de ton inspiration.",
      normal: "Tu avances avec équilibre, entre rigueur et spontanéité."
    };
    return narratives[flow] || narratives.normal;
  };

  // [LOGIC:VIBRATION_CERTIFICATE]
  const generateCertificate = async (userProfile, gridPreview) => {
    if (!vibrationData || !vibrationCode || !generatedMusic || !generatedStory) {
      return null;
    }
    
    const cert = {
      id: `CERT-${Date.now()}`,
      created_at: new Date().toISOString(),
      preview: gridPreview,
      palette: vibrationData.color_profile,
      symbols: vibrationData.shape_profile,
      emotion: vibrationData.emotion,
      music: generatedMusic,
      story: generatedStory,
      code: vibrationCode,
      user_name: userProfile.prenom || 'Artiste',
      signature: `Signature Vibratoire PatyBee™ - ${vibrationCode.substring(0, 16)}`
    };
    
    setCertificate(cert);
    return cert;
  };

  // [LOGIC:FUSION_VIBRATOIRE]
  const createVibratoryArt = async (userProfile, userSignals, gridPreview) => {
    // Collecter données
    const data = collectVibratoryData(userProfile, userSignals);
    
    // Générer code
    const code = generateVibrationCode(data);
    
    // Générer musique
    await generateMusic(data);
    
    // Générer histoire
    await generateStory(data);
    
    // Créer certificat
    const cert = await generateCertificate(userProfile, gridPreview);
    
    return cert;
  };

  // [EXPORT:VIBRATION_PACKAGE]
  const exportVibrationPackage = async () => {
    if (!certificate) return null;
    
    const packageData = {
      certificate: certificate,
      music: generatedMusic,
      story: generatedStory,
      code: vibrationCode,
      format: 'json'
    };
    
    // Créer fichier téléchargeable
    const blob = new Blob([JSON.stringify(packageData, null, 2)], { type: 'application/json' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `vibration-${certificate.id}.json`;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    a.remove();
    
    return packageData;
  };

  const value = {
    vibrationData,
    vibrationCode,
    generatedMusic,
    generatedStory,
    certificate,
    collectVibratoryData,
    generateVibrationCode,
    generateMusic,
    generateStory,
    generateCertificate,
    createVibratoryArt,
    exportVibrationPackage
  };

  return (
    <VibratoryEngineContext.Provider value={value}>
      {children}
    </VibratoryEngineContext.Provider>
  );
};