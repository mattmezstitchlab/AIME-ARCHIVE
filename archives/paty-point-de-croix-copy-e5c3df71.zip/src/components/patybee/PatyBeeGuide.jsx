import React from 'react';

// Composant désactivé - l'abeille flottante a été retirée
// Seul le bouton dans la barre du haut reste actif

export default function PatyBeeGuide() {
  return null;
}