import React, { createContext, useContext, useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';

const BroodIAContext = createContext();

// Alias pour compatibilité
export const usePatyBee = () => useBroodIA();

export const useBroodIA = () => {
  const context = useContext(BroodIAContext);
  if (!context) {
    throw new Error('useBroodIA must be used within BroodIAProvider');
  }
  return context;
};

// Configuration BroodIA
const BROODIA_CONFIG = {
  name: 'BroodIA',
  greeting: "Hey ! Je suis BroodIA, ton assistant point de croix. On va gérer ça ensemble 😎",
  style: 'cool, fun, complice'
};

// Questions prédéfinies par catégorie
const QUESTIONS_POOL = {
  emotion: [
    {
      text: "Aujourd'hui, tu te sens plutôt :",
      options: ["apaisée", "nostalgique", "pleine d'énergie", "concentrée"],
      zone: "emotion"
    }
  ],
  couleurs: [
    {
      text: "En ce moment, tu préfères broder plutôt :",
      options: [
        "des couleurs chaudes (rouge, orange, jaune)",
        "des couleurs froides (bleu, vert, violet)",
        "des couleurs pastel",
        "des couleurs très contrastées"
      ],
      zone: "couleurs"
    }
  ],
  style: [
    {
      text: "En broderie, tu te sens plus attirée par :",
      options: [
        "les fleurs et la nature",
        "les animaux",
        "les personnages / portraits",
        "les scènes de vie / paysages"
      ],
      zone: "style"
    }
  ],
  souvenir: [
    {
      text: "Est-ce que tu voudrais qu'un symbole représente un souvenir important pour toi ? (par exemple un voyage, une personne, un moment marquant)",
      options: ["Oui, un voyage", "Oui, une personne", "Oui, un moment marquant", "Non, pas maintenant"],
      zone: "souvenir"
    }
  ],
  famille: [
    {
      text: "Souhaites-tu qu'un symbole de ta grille de profil représente quelqu'un d'important dans ta vie ?",
      options: ["Ma famille", "Un ami proche", "Mon animal", "Plus tard"],
      zone: "famille"
    }
  ],
  technique: [
    {
      text: "Tu es plutôt :",
      options: [
        "patiente et minutieuse",
        "rapide et intuitive",
        "organisée avec une méthode",
        "freestyle, tu improvises 😄"
      ],
      zone: "technique"
    }
  ]
};

// 100 SYMBOLES DÉFINITIFS PAR CATÉGORIE
const SYMBOLS_BY_CATEGORY = {
  emotion: ["●", "○", "◆", "◇", "▲", "▼", "■", "□", "✦", "✚", "★", "✿"],
  couleurs: ["◼", "◻", "✧", "⌾", "▣", "▤", "▥", "▦", "▩", "❖"],
  style: ["✂", "🧵", "┼", "╳", "=", "∣", "‣", "▷", "◁", "●●", "↗", "∿", "∞", "☼", "☾"],
  famille: ["♡", "♥", "❣", "⌘", "⚘", "⚪", "⦿", "∗", "♢", "✱"],
  souvenir: ["❂", "✇", "⌖", "⌕", "✪", "≋", "≈", "∴", "⁂", "✥"],
  etats_interieurs: ["✺", "✣", "✤", "ϟ", "∇", "☐", "▣", "◦", "⁎", "•"],
  passions: ["♬", "✈", "⚽", "✏", "🖤", "⚓", "⛰", "☁", "❆", "✝", "⌛", "✎", "↺", "☯", "∆"],
  vie_quotidienne: ["⊙", "⊚", "⊖", "⊕", "⊗", "○○", "◐", "◑"],
  geometrie_sacree: ["✺", "△", "▽", "◬", "◮", "⌬", "⌘", "✧"],
  signature_vibratoire: ["✹", "✸"]
};

const ZONE_POSITIONS = {
  emotion: { startRow: 0, startCol: 0 },
  couleurs: { startRow: 8, startCol: 0 },
  style: { startRow: 0, startCol: 5 },
  souvenir: { startRow: 4, startCol: 4 },
  famille: { startRow: 2, startCol: 0 },
  technique: { startRow: 8, startCol: 7 },
  etats_interieurs: { startRow: 5, startCol: 0 },
  passions: { startRow: 0, startCol: 8 },
  vie_quotidienne: { startRow: 7, startCol: 3 },
  geometrie_sacree: { startRow: 6, startCol: 6 },
  signature_vibratoire: { startRow: 4, startCol: 5 }
};

export const PatyBeeProvider = ({ children }) => {
  const [isPanelOpen, setIsPanelOpen] = useState(false);
  const [messages, setMessages] = useState([]);
  const [currentQuestion, setCurrentQuestion] = useState(null);
  const [awaitingSymbolSelection, setAwaitingSymbolSelection] = useState(false);
  const [pendingResponse, setPendingResponse] = useState(null);
  const [currentMode, setCurrentMode] = useState('guidage'); // guidage, recommendation, error, profile, creative, motivation, expert
  const [userBehavior, setUserBehavior] = useState({
    clickErrors: 0,
    zoomCount: 0,
    colorChanges: 0,
    erasures: 0,
    hesitations: 0,
    lastAction: null,
    preferredColors: [],
    expertise: 'beginner' // beginner, intermediate, expert
  });

  // Message de bienvenue désactivé - ne s'affiche plus automatiquement

  const openPanel = () => setIsPanelOpen(true);
  const closePanel = () => setIsPanelOpen(false);
  const togglePanel = () => setIsPanelOpen(prev => !prev);

  const addMessage = (message) => {
    setMessages(prev => [...prev, { ...message, timestamp: Date.now() }]);
  };

  const showWelcomeMessage = () => {
    addMessage({
      role: 'assistant',
      content: BROODIA_CONFIG.greeting + "\n\nJe peux t'aider à :\n• naviguer dans ta grille,\n• retrouver tes couleurs DMC,\n• et tout le reste.\n\nOn commence ?",
      buttons: [
        { label: "Yes, go !", action: "explain" },
        { label: "Plus tard", action: "dismiss" }
      ]
    });
    openPanel();
  };

  const showProfileIntro = () => {
    addMessage({
      role: 'assistant',
      content: "Ton profil créatif, c'est ici 🎨\nPas de pression, on le remplit tranquille.\n\nÇa me permettra de te proposer des trucs qui te correspondent vraiment.",
      buttons: [
        { label: "C'est parti", action: "start_question" },
        { label: "Pas maintenant", action: "dismiss" }
      ]
    });
    openPanel();
  };

  const showContextualSuggestion = () => {
    addMessage({
      role: 'assistant',
      content: "Tu gères ! 👀\nEnvie d'enregistrer un petit détail dans ton profil ?",
      buttons: [
        { label: "Oui, une question", action: "start_question" },
        { label: "Plus tard", action: "dismiss" }
      ]
    });
    openPanel();
  };

  const startQuestion = () => {
    // Choisir une catégorie aléatoire
    const categories = Object.keys(QUESTIONS_POOL);
    const randomCategory = categories[Math.floor(Math.random() * categories.length)];
    const questions = QUESTIONS_POOL[randomCategory];
    const question = questions[0];

    setCurrentQuestion(question);
    addMessage({
      role: 'assistant',
      content: question.text,
      options: question.options
    });
  };

  const handleQuestionResponse = (response) => {
    setPendingResponse({ answer: response, zone: currentQuestion.zone });
    
    addMessage({
      role: 'user',
      content: response
    });

    // Récupérer les symboles de la catégorie correspondante
    const categorySymbols = SYMBOLS_BY_CATEGORY[currentQuestion.zone] || SYMBOLS_BY_CATEGORY.emotion;
    
    addMessage({
      role: 'assistant',
      content: "Parfait 😎\nChoisis un symbole pour représenter ça :",
      symbols: categorySymbols
    });

    setAwaitingSymbolSelection(true);
  };

  const handleSymbolSelection = async (symbol) => {
    if (!pendingResponse) return;

    try {
      // Calculer la position dans la zone correspondante
      const zone = ZONE_POSITIONS[pendingResponse.zone];
      const position = {
        row: zone.startRow,
        col: zone.startCol
      };

      addMessage({
        role: 'assistant',
        content: "C'est noté ! 💾\nTon profil évolue petit à petit."
      });

      // Sauvegarder dans le profil utilisateur
      // (À implémenter avec la grille de profil)

      setAwaitingSymbolSelection(false);
      setPendingResponse(null);
      setCurrentQuestion(null);

    } catch (error) {
      console.error('Erreur lors de la sauvegarde du symbole:', error);
      addMessage({
        role: 'assistant',
        content: "Oups, une petite erreur s'est produite. Réessayons plus tard !"
      });
    }
  };

  const handleButtonAction = (action) => {
    switch (action) {
      case "explain":
        addMessage({
          role: 'assistant',
          content: "Cool ! 🚀\n\nJe suis dispo à tout moment. Clique sur l'icône IA dans la barre.\n\nExplore, et si t'as besoin, je suis là !"
        });
        setCurrentMode('guidage');
        break;
      case "start_question":
        startQuestion();
        break;
      case "dismiss":
        addMessage({
          role: 'assistant',
          content: "Ok, je reste dans le coin 😎"
        });
        break;
      default:
        break;
    }
  };

  // MODE 1 - GUIDAGE
  const showGuidance = (context) => {
    const messages = {
      first_import: "Besoin d'un coup de main pour démarrer ? On va gérer ça ensemble 😎",
      empty_grid: "Un symbole ? Une couleur ? Dis-moi !",
      color_picker: "Clique sur une couleur pour la repérer dans ta grille.",
      zoom_tools: "Zoom avec la molette ou les boutons + / -"
    };
    
    if (messages[context]) {
      addMessage({
        role: 'assistant',
        content: messages[context]
      });
      openPanel();
    }
  };

  // MODE 2 - RECOMMANDATION
  const trackBehavior = (action, data = {}) => {
    setUserBehavior(prev => {
      const updated = { ...prev, lastAction: action };
      
      switch (action) {
        case 'zoom':
          updated.zoomCount = (prev.zoomCount || 0) + 1;
          if (updated.zoomCount > 5) {
            setTimeout(() => showRecommendation('precision'), 100);
          }
          break;
        case 'color_change':
          updated.colorChanges = (prev.colorChanges || 0) + 1;
          if (data.color && !prev.preferredColors.includes(data.color)) {
            updated.preferredColors = [...prev.preferredColors, data.color].slice(-5);
          }
          break;
        case 'erase':
          updated.erasures = (prev.erasures || 0) + 1;
          if (updated.erasures > 3) {
            setTimeout(() => showRecommendation('corrections'), 100);
          }
          break;
        case 'click_error':
          updated.clickErrors = (prev.clickErrors || 0) + 1;
          if (updated.clickErrors >= 3) {
            setTimeout(() => showError('wrong_click'), 100);
          }
          break;
      }
      
      return updated;
    });
  };

  const showRecommendation = (type) => {
    const recommendations = {
      precision: "Tu veux plus de précision ? Je peux activer la grille fine 🎯",
      corrections: "Pas mal de corrections… Mode sécurisé ?",
      colors: "T'aimes bien ces teintes ! Perso ta palette ?"
    };
    
    if (recommendations[type]) {
      addMessage({
        role: 'assistant',
        content: recommendations[type],
        buttons: [
          { label: "Yes !", action: `apply_${type}` },
          { label: "Non merci", action: "dismiss" }
        ]
      });
      openPanel();
      setCurrentMode('recommendation');
    }
  };

  // MODE 3 - ERREURS & AIDE
  const showError = (type) => {
    const errors = {
      wrong_click: "Hmm, ça coince… Je te montre ?",
      no_color: "Choisis une couleur d'abord ! Je te montre où.",
      wrong_tool: "Pas le bon outil 😅 Essaie celui-ci ➜"
    };
    
    if (errors[type]) {
      addMessage({
        role: 'assistant',
        content: errors[type],
        buttons: [
          { label: "Montre-moi", action: "show_help" },
          { label: "C'est bon", action: "dismiss" }
        ]
      });
      openPanel();
      setCurrentMode('error');
      
      // Reset error counter
      setUserBehavior(prev => ({ ...prev, clickErrors: 0 }));
    }
  };

  // MODE 5 - SOUTIEN CRÉATIF
  const showCreativeSupport = (matchingModel) => {
    addMessage({
      role: 'assistant',
      content: "Yo ! J'ai trouvé un modèle qui te correspond 🎨\nTes couleurs, ton style. Check ça !",
      buttons: [
        { label: "Je regarde", action: "view_model" },
        { label: "Plus tard", action: "dismiss" }
      ]
    });
    openPanel();
    setCurrentMode('creative');
  };

  // MODE 6 - MOTIVATION
  const showMotivation = (progress) => {
    const messages = [
      `Tu gères ! 🔥`,
      `Ça avance bien !`,
      `${progress}% sur cette couleur, on finit ensemble ?`
    ];
    
    addMessage({
      role: 'assistant',
      content: messages[Math.floor(Math.random() * messages.length)]
    });
    openPanel();
    setCurrentMode('motivation');
  };

  // MODE 7 - EXPERT
  const activateExpertMode = () => {
    addMessage({
      role: 'assistant',
      content: "Mode expert ON. Je te laisse bosser tranquille. Appelle-moi si besoin 👊"
    });
    setCurrentMode('expert');
    setUserBehavior(prev => ({ ...prev, expertise: 'expert' }));
  };

  // Messages contextuels désactivés - ne s'affichent plus automatiquement
  const showPageContext = (pageName) => {
    // Fonction désactivée pour éviter les messages automatiques
  };

  // Célébrer une victoire
  const celebrate = (message) => {
    addMessage({
      role: 'assistant',
      content: message || "Bien joué ! 🎉"
    });
    openPanel();
    setCurrentMode('motivation');
  };

  // ACTIONS BROODIA - Connexion au contexte global
  const executeAction = (action, params = {}) => {
    const event = new CustomEvent('broodiaAction', { detail: { action, params } });
    window.dispatchEvent(event);
  };

  // Navigation GPS
  const navigateToZone = (zone) => {
    executeAction('navigateToZone', { zone });
    addMessage({
      role: 'assistant',
      content: `Yes ! Direction ${zone} 🚀`
    });
  };

  // Zoom
  const setZoom = (level) => {
    executeAction('setZoom', { level });
    addMessage({
      role: 'assistant',
      content: `Zoom ${level === 'auto' ? 'auto' : 'x' + level}, tu vas y voir super clair 👀`
    });
  };

  // Filtrer par couleur
  const filterByColor = (colorCode) => {
    executeAction('filterByColor', { colorCode });
    addMessage({
      role: 'assistant',
      content: `J'affiche la couleur ${colorCode}, focus total 😎`
    });
  };

  // Changer d'outil
  const setTool = (toolName) => {
    executeAction('setTool', { toolName });
    addMessage({
      role: 'assistant',
      content: `${toolName} activé ! 🎯`
    });
  };

  // Ouvrir un menu
  const openMenu = (menuName) => {
    executeAction('openMenu', { menuName });
    addMessage({
      role: 'assistant',
      content: `C'est ouvert 👍`
    });
  };

  // Analyse de la grille
  const analyzeGrid = (type) => {
    executeAction('analyzeGrid', { type });
    const messages = {
      unstitched: "Je te montre les zones non brodées 🔍",
      errors: "Voyons les erreurs potentielles...",
      remaining: "Il reste quoi à faire ? Je check !"
    };
    addMessage({
      role: 'assistant',
      content: messages[type] || "Analyse en cours..."
    });
  };

  const value = {
    isPanelOpen,
    openPanel,
    closePanel,
    togglePanel,
    messages,
    addMessage,
    showWelcomeMessage,
    showProfileIntro,
    showContextualSuggestion,
    startQuestion,
    handleQuestionResponse,
    handleSymbolSelection,
    handleButtonAction,
    currentQuestion,
    awaitingSymbolSelection,
    currentMode,
    userBehavior,
    // 7 modes
    showGuidance,
    trackBehavior,
    showRecommendation,
    showError,
    showCreativeSupport,
    showMotivation,
    activateExpertMode,
    showPageContext,
    celebrate,
    // Actions BroodIA
    executeAction,
    navigateToZone,
    setZoom,
    filterByColor,
    setTool,
    openMenu,
    analyzeGrid,
    // Config
    config: BROODIA_CONFIG
  };

  return (
    <BroodIAContext.Provider value={value}>
      {children}
    </BroodIAContext.Provider>
  );
};