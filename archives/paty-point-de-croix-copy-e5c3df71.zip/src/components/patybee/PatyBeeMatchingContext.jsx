import React, { createContext, useContext, useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';

const PatyBeeMatchingContext = createContext();

export const usePatyBeeMatching = () => {
  const context = useContext(PatyBeeMatchingContext);
  if (!context) {
    throw new Error('usePatyBeeMatching must be used within PatyBeeMatchingProvider');
  }
  return context;
};

// Classification des types créatifs
const CREATIVE_TYPES = ["Apaisée", "Énergétique", "Précise", "Intuitive", "Visionnaire", "Classique"];

export const PatyBeeMatchingProvider = ({ children }) => {
  const [userSignals, setUserSignals] = useState({
    colors_used: [],
    symbols_used: [],
    symbols_ignored: [],
    complexity_level: 'beginner',
    zones_preferred: [],
    zones_ignored: [],
    rhythm: 'normal',
    emotional_pattern: [],
    history: {
      projects_created: 0,
      projects_abandoned: 0,
      projects_completed: 0
    },
    boutique: {
      models_viewed: [],
      models_purchased: []
    }
  });

  const [creativeProfile, setCreativeProfile] = useState({
    type: null,
    palette: [],
    level: 'beginner',
    style: null,
    flow: 'normal',
    updated: null
  });

  const [actionCounter, setActionCounter] = useState(0);

  // [LOGIC:USER_SIGNAL_CAPTURE]
  const captureSignal = (signalType, data) => {
    setUserSignals(prev => {
      const updated = { ...prev };
      
      switch (signalType) {
        case 'color_used':
          if (!updated.colors_used.find(c => c.hex === data.hex)) {
            updated.colors_used = [...updated.colors_used, data].slice(-20);
          }
          break;
        
        case 'symbol_used':
          const symbolEntry = updated.symbols_used.find(s => s.char === data.char);
          if (symbolEntry) {
            symbolEntry.count++;
          } else {
            updated.symbols_used = [...updated.symbols_used, { ...data, count: 1 }];
          }
          break;
        
        case 'zone_preferred':
          updated.zones_preferred = [...updated.zones_preferred, data].slice(-10);
          break;
        
        case 'complexity':
          updated.complexity_level = data;
          break;
        
        case 'rhythm':
          updated.rhythm = data;
          break;
        
        case 'model_viewed':
          updated.boutique.models_viewed = [...updated.boutique.models_viewed, data].slice(-50);
          break;
        
        case 'model_purchased':
          updated.boutique.models_purchased = [...updated.boutique.models_purchased, data];
          break;
        
        case 'project_created':
          updated.history.projects_created++;
          break;
        
        case 'project_completed':
          updated.history.projects_completed++;
          break;
      }
      
      return updated;
    });

    // Incrémenter le compteur d'actions
    setActionCounter(prev => prev + 1);
  };

  // [LOGIC:CREATIVE_PROFILE] - Mise à jour toutes les 12 actions
  useEffect(() => {
    if (actionCounter > 0 && actionCounter % 12 === 0) {
      updateCreativeProfile();
    }
  }, [actionCounter]);

  const updateCreativeProfile = () => {
    const profile = {
      type: classifyType(),
      palette: classifyPalette(),
      level: classifyLevel(),
      style: classifyStyle(),
      flow: classifyFlow(),
      updated: new Date().toISOString()
    };
    
    setCreativeProfile(profile);
    
    // Sauvegarder dans le profil utilisateur
    saveToUserProfile(profile);
  };

  const classifyType = () => {
    const signals = userSignals;
    
    // Analyse du type créatif basé sur les signaux
    if (signals.rhythm === 'slow' && signals.colors_used.length <= 5) {
      return 'Apaisée';
    } else if (signals.rhythm === 'fast' && signals.symbols_used.length > 10) {
      return 'Énergétique';
    } else if (signals.complexity_level === 'advanced' && signals.zones_preferred.length > 0) {
      return 'Précise';
    } else if (signals.symbols_ignored.length > 5) {
      return 'Intuitive';
    } else if (signals.colors_used.length > 15) {
      return 'Visionnaire';
    } else {
      return 'Classique';
    }
  };

  const classifyPalette = () => {
    // Retourner les couleurs les plus utilisées
    return userSignals.colors_used
      .sort((a, b) => (b.usage || 0) - (a.usage || 0))
      .slice(0, 10);
  };

  const classifyLevel = () => {
    const complexity = userSignals.complexity_level;
    const projectsCount = userSignals.history.projects_completed;
    
    if (projectsCount > 10 || complexity === 'advanced') return 'expert';
    if (projectsCount > 3 || complexity === 'intermediate') return 'intermediate';
    return 'beginner';
  };

  const classifyStyle = () => {
    const topSymbols = userSignals.symbols_used
      .sort((a, b) => b.count - a.count)
      .slice(0, 5)
      .map(s => s.char);
    
    if (topSymbols.includes('✿') || topSymbols.includes('⚘')) return 'nature';
    if (topSymbols.includes('●') || topSymbols.includes('■')) return 'geometric';
    if (topSymbols.includes('★') || topSymbols.includes('✦')) return 'decorative';
    return 'mixed';
  };

  const classifyFlow = () => {
    if (userSignals.zones_preferred.length > 5) return 'structured';
    if (userSignals.rhythm === 'fast') return 'fluid';
    return 'normal';
  };

  const saveToUserProfile = async (profile) => {
    try {
      const user = await base44.auth.me();
      if (!user) return;
      
      const profiles = await base44.entities.UserProfile.filter({ created_by: user.email });
      const userProfile = profiles[0];
      
      if (userProfile) {
        await base44.entities.UserProfile.update(userProfile.id, {
          profil_creatif: {
            ...userProfile.profil_creatif,
            signature_simplifiee: profile.type,
            historique_actions: userSignals
          }
        });
      }
    } catch (error) {
      console.error('Erreur sauvegarde profil créatif:', error);
    }
  };

  // [LOGIC:MATCHING_BOUTIQUE]
  const calculateModelMatch = (model) => {
    const scores = {
      palette: calculatePaletteMatch(model),
      style: calculateStyleMatch(model),
      level: calculateLevelMatch(model),
      emotion: calculateEmotionMatch(model),
      vibration: calculateVibrationMatch(model)
    };
    
    const globalScore = 
      scores.palette * 0.30 +
      scores.style * 0.30 +
      scores.level * 0.15 +
      scores.emotion * 0.15 +
      scores.vibration * 0.10;
    
    return {
      score: globalScore,
      details: scores,
      recommend: globalScore > 0.70
    };
  };

  const calculatePaletteMatch = (model) => {
    if (!model.grid_data?.pattern?.colors) return 0.5;
    
    const modelColors = model.grid_data.pattern.colors.map(c => c.hex);
    const userColors = creativeProfile.palette.map(c => c.hex);
    
    const matches = modelColors.filter(mc => userColors.includes(mc));
    return matches.length / Math.max(modelColors.length, 1);
  };

  const calculateStyleMatch = (model) => {
    // Analyse basée sur le titre et description
    const modelText = `${model.title} ${model.description}`.toLowerCase();
    const userStyle = creativeProfile.style;
    
    if (userStyle === 'nature' && (modelText.includes('fleur') || modelText.includes('nature'))) {
      return 1.0;
    }
    if (userStyle === 'geometric' && (modelText.includes('géométrique') || modelText.includes('moderne'))) {
      return 1.0;
    }
    return 0.5;
  };

  const calculateLevelMatch = (model) => {
    const modelComplexity = model.grid_data?.nb_colonnes * model.grid_data?.nb_lignes || 0;
    const userLevel = creativeProfile.level;
    
    if (userLevel === 'beginner' && modelComplexity < 10000) return 1.0;
    if (userLevel === 'intermediate' && modelComplexity < 30000) return 1.0;
    if (userLevel === 'expert') return 1.0;
    return 0.5;
  };

  const calculateEmotionMatch = (model) => {
    // Analyse des émotions via le titre et description
    return 0.7; // Baseline
  };

  const calculateVibrationMatch = (model) => {
    // Code vibratoire du modèle vs type créatif
    const vibrations = {
      'Apaisée': ['calme', 'doux', 'pastel'],
      'Énergétique': ['vibrant', 'coloré', 'dynamique'],
      'Précise': ['détaillé', 'complexe', 'précis'],
      'Intuitive': ['libre', 'créatif', 'unique'],
      'Visionnaire': ['moderne', 'original', 'artistique'],
      'Classique': ['traditionnel', 'classique', 'élégant']
    };
    
    const modelText = `${model.title} ${model.description}`.toLowerCase();
    const userVibrations = vibrations[creativeProfile.type] || [];
    
    const matches = userVibrations.filter(v => modelText.includes(v));
    return matches.length / Math.max(userVibrations.length, 1);
  };

  // [LOGIC:MATCHING_USERS]
  const calculateUserCompatibility = (otherUserProfile) => {
    const scores = {
      palette: calculatePaletteCompatibility(otherUserProfile),
      symbols: calculateSymbolsCompatibility(otherUserProfile),
      rhythm: calculateRhythmCompatibility(otherUserProfile),
      emotion: calculateEmotionCompatibility(otherUserProfile),
      skills: calculateSkillsCompatibility(otherUserProfile)
    };
    
    const globalScore = Object.values(scores).reduce((a, b) => a + b, 0) / Object.keys(scores).length;
    
    return {
      score: globalScore,
      details: scores,
      compatible: globalScore > 0.65
    };
  };

  const calculatePaletteCompatibility = (otherProfile) => {
    const myColors = creativeProfile.palette.map(c => c.hex);
    const theirColors = otherProfile.profil_creatif?.couleurs_favorites || [];
    
    const matches = myColors.filter(mc => theirColors.includes(mc));
    return matches.length / Math.max(myColors.length, 1);
  };

  const calculateSymbolsCompatibility = (otherProfile) => {
    const mySymbols = userSignals.symbols_used.map(s => s.char);
    const theirSymbols = otherProfile.profil_creatif?.symboles_favoris || [];
    
    const matches = mySymbols.filter(ms => theirSymbols.includes(ms));
    return matches.length / Math.max(mySymbols.length, 1);
  };

  const calculateRhythmCompatibility = (otherProfile) => {
    const myRhythm = userSignals.rhythm;
    const theirRhythm = otherProfile.profil_creatif?.rythme_broderie || 'normal';
    
    return myRhythm === theirRhythm ? 1.0 : 0.5;
  };

  const calculateEmotionCompatibility = (otherProfile) => {
    return 0.7; // Baseline
  };

  const calculateSkillsCompatibility = (otherProfile) => {
    const myLevel = creativeProfile.level;
    const theirLevel = otherProfile.profil_creatif?.niveau || 'beginner';
    
    return myLevel === theirLevel ? 1.0 : 0.7;
  };

  // [LOGIC:GRID_ANALYSIS]
  const analyzeGrid = (gridData) => {
    const analysis = {
      colors_used: extractColors(gridData),
      symbols_frequency: calculateSymbolFrequency(gridData),
      empty_zones: detectEmptyZones(gridData),
      overbroding: detectOverbroding(gridData),
      patterns: detectPatterns(gridData)
    };
    
    return analysis;
  };

  const extractColors = (gridData) => {
    const colors = new Set();
    gridData.stitches?.forEach(stitch => colors.add(stitch.color));
    return Array.from(colors);
  };

  const calculateSymbolFrequency = (gridData) => {
    const freq = {};
    gridData.stitches?.forEach(stitch => {
      if (stitch.symbol) {
        freq[stitch.symbol] = (freq[stitch.symbol] || 0) + 1;
      }
    });
    return freq;
  };

  const detectEmptyZones = (gridData) => {
    // Détection simplifiée des zones vides
    return [];
  };

  const detectOverbroding = (gridData) => {
    // Détection de surcharge
    const totalStitches = gridData.stitches?.length || 0;
    const gridSize = (gridData.nb_colonnes || 100) * (gridData.nb_lignes || 100);
    return totalStitches / gridSize > 0.8;
  };

  const detectPatterns = (gridData) => {
    // Détection de motifs répétitifs
    return [];
  };

  // [LOGIC:MODEL_VIBRATION]
  const calculateModelVibration = (model) => {
    return {
      serenity: detectColorHarmony(model),
      intensity: detectContrast(model),
      nostalgia: detectDesaturation(model),
      symmetry: detectGeometry(model),
      nature: detectNatureTheme(model),
      spirituality: detectSacredShapes(model)
    };
  };

  const detectColorHarmony = (model) => {
    // Analyse l'harmonie des couleurs
    return 0.7;
  };

  const detectContrast = (model) => {
    // Analyse le contraste
    return 0.5;
  };

  const detectDesaturation = (model) => {
    // Détecte les tons désaturés/vintage
    return 0.3;
  };

  const detectGeometry = (model) => {
    // Détecte la géométrie et symétrie
    return 0.6;
  };

  const detectNatureTheme = (model) => {
    const text = `${model.title} ${model.description}`.toLowerCase();
    return (text.includes('fleur') || text.includes('nature') || text.includes('animal')) ? 1.0 : 0.0;
  };

  const detectSacredShapes = (model) => {
    // Détecte les formes sacrées
    return 0.2;
  };

  const value = {
    userSignals,
    creativeProfile,
    captureSignal,
    updateCreativeProfile,
    calculateModelMatch,
    calculateUserCompatibility,
    analyzeGrid,
    calculateModelVibration
  };

  return (
    <PatyBeeMatchingContext.Provider value={value}>
      {children}
    </PatyBeeMatchingContext.Provider>
  );
};