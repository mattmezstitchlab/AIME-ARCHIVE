import React, { useEffect, useRef } from 'react';
import { motion } from 'framer-motion';

export default function MiniGrid({ type = 'matthieu' }) {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    const cellSize = 20;
    const rows = 10;
    const cols = 10;
    
    canvas.width = cols * cellSize;
    canvas.height = rows * cellSize;

    // Fond blanc
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Grille
    ctx.strokeStyle = '#e2e8f0';
    ctx.lineWidth = 1;
    
    for (let i = 0; i <= cols; i++) {
      ctx.beginPath();
      ctx.moveTo(i * cellSize, 0);
      ctx.lineTo(i * cellSize, rows * cellSize);
      ctx.stroke();
    }
    
    for (let i = 0; i <= rows; i++) {
      ctx.beginPath();
      ctx.moveTo(0, i * cellSize);
      ctx.lineTo(cols * cellSize, i * cellSize);
      ctx.stroke();
    }

    // Symboles selon le type
    ctx.font = 'bold 14px Arial';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = '#000000';

    const patterns = {
      matthieu: [
        ['', '', '', '', '', '', '', '', '', ''],
        ['', '', '', '', '', '', '', '', '', ''],
        ['', '', '', '', '', '', '', '', '', ''],
        ['', '', '', '', '', '', '', '', '', ''],
        ['', '', '', 'M', '', '♫', '', '', '', ''],
        ['', '', '', '', '●', '', '', '♫', '', ''],
        ['', '', '', '', '', '', '', '', '', ''],
        ['', '', '', 'M', '', '', '', '', '', ''],
        ['', '', '', '', '', '', '', '', '', ''],
        ['', '', '', '', '', '', '', '', '', '']
      ],
      broderie: [
        ['X', '●', '■', '▲', 'X', '●', '■', '▲', 'X', '●'],
        ['●', '■', '▲', 'X', '●', '■', '▲', 'X', '●', '■'],
        ['■', '▲', 'X', '●', '■', '▲', 'X', '●', '■', '▲'],
        ['▲', 'X', '●', '■', '▲', 'X', '●', '■', '▲', 'X'],
        ['X', '●', '■', '▲', 'X', '●', '■', '▲', 'X', '●'],
        ['●', '■', '▲', 'X', '●', '■', '▲', 'X', '●', '■'],
        ['■', '▲', 'X', '●', '■', '▲', 'X', '●', '■', '▲'],
        ['▲', 'X', '●', '■', '▲', 'X', '●', '■', '▲', 'X'],
        ['X', '●', '■', '▲', 'X', '●', '■', '▲', 'X', '●'],
        ['●', '■', '▲', 'X', '●', '■', '▲', 'X', '●', '■']
      ],
      therapie: [
        ['', '', '', '', '', '', '', '', '', ''],
        ['', '♥', '', '', '', '', '', '', '♥', ''],
        ['', '', '', '○', '', '', '○', '', '', ''],
        ['', '', '', '', '~', '~', '', '', '', ''],
        ['', '', '○', '', '', '', '', '○', '', ''],
        ['', '', '', '', '', '', '', '', '', ''],
        ['', '', '', '♥', '', '', '♥', '', '', ''],
        ['', '', '', '', '', '', '', '', '', ''],
        ['', '○', '', '', '', '', '', '', '○', ''],
        ['', '', '', '', '', '', '', '', '', '']
      ],
      opportunite: [
        ['', '', '', '', '', '', '', '', '', '✓'],
        ['', '', '', '', '', '', '', '', '✓', ''],
        ['', '', '', '', '', '', '', '★', '', ''],
        ['', '', '', '', '', '', '★', '', '', ''],
        ['', '', '', '', '', '↑', '', '', '', ''],
        ['', '', '', '', '↑', '', '', '', '', ''],
        ['', '', '', '★', '', '', '', '', '', ''],
        ['', '', '★', '', '', '', '', '', '', ''],
        ['', '✓', '', '', '', '', '', '', '', ''],
        ['✓', '', '', '', '', '', '', '', '', '']
      ]
    };

    const pattern = patterns[type] || patterns.matthieu;

    // Dessiner les symboles
    for (let row = 0; row < rows; row++) {
      for (let col = 0; col < cols; col++) {
        const symbol = pattern[row][col];
        const x = col * cellSize + cellSize / 2;
        const y = row * cellSize + cellSize / 2;
        ctx.fillText(symbol, x, y);
      }
    }
  }, [type]);

  return (
    <motion.div
      initial={{ scale: 0.8, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ duration: 0.6 }}
      className="flex-shrink-0"
    >
      <canvas
        ref={canvasRef}
        className="rounded-lg shadow-xl border-2 border-slate-200"
      />
    </motion.div>
  );
}