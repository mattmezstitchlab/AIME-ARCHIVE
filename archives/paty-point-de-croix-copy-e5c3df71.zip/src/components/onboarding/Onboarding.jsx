import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ChevronRight, X } from 'lucide-react';
import MiniGrid from './MiniGrid';

// Logo PATY
function PatyLogo({ animated = false }) {
  return (
    <motion.div
      animate={animated ? { scale: [1, 1.05, 1] } : {}}
      transition={animated ? { duration: 2, repeat: Infinity, ease: "easeInOut" } : {}}
      className="inline-block"
    >
      <svg width="80" height="80" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect width="32" height="32" rx="4" fill="#000000"/>
        <path d="M16 13L18.5 14.5V17.5L16 19L13.5 17.5V14.5L16 13Z" fill="#FFD700" stroke="#FFD700" strokeWidth="1"/>
        <path d="M16 8L18.5 9.5V12.5L16 14L13.5 12.5V9.5L16 8Z" stroke="#FFD700" strokeWidth="1" fill="none"/>
        <path d="M16 18L18.5 19.5V22.5L16 24L13.5 22.5V19.5L16 18Z" stroke="#FFD700" strokeWidth="1" fill="none"/>
        <path d="M20.5 10.5L23 12V15L20.5 16.5L18 15V12L20.5 10.5Z" stroke="#FFD700" strokeWidth="1" fill="none"/>
        <path d="M11.5 10.5L14 12V15L11.5 16.5L9 15V12L11.5 10.5Z" stroke="#FFD700" strokeWidth="1" fill="none"/>
        <path d="M20.5 15.5L23 17V20L20.5 21.5L18 20V17L20.5 15.5Z" stroke="#FFD700" strokeWidth="1" fill="none"/>
        <path d="M11.5 15.5L14 17V20L11.5 21.5L9 20V17L11.5 15.5Z" stroke="#FFD700" strokeWidth="1" fill="none"/>
      </svg>
    </motion.div>
  );
}

// Flèche animée
function AnimatedArrow({ direction = 'down', className = '' }) {
  const variants = {
    down: { y: [0, 10, 0] },
    right: { x: [0, 10, 0] },
    up: { y: [0, -10, 0] },
    left: { x: [0, -10, 0] }
  };

  return (
    <motion.div
      animate={variants[direction]}
      transition={{ duration: 1.5, repeat: Infinity }}
      className={className}
    >
      <svg width="40" height="40" viewBox="0 0 40 40" fill="none">
        <path d="M20 10 L20 30 M20 30 L15 25 M20 30 L25 25" 
          stroke="#FFD700" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    </motion.div>
  );
}

export default function Onboarding({ onComplete }) {
  const [currentSlide, setCurrentSlide] = useState(0);

  const slides = [
    // SLIDE 0 - Matthieu
    {
      content: (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex flex-col justify-between h-full px-12 py-12"
        >
          {/* Contenu principal */}
          <div className="flex items-center justify-center gap-8">
            <MiniGrid type="matthieu" />
            
            <div className="max-w-lg space-y-4">
              <p className="text-lg text-slate-700 leading-relaxed">
                Je viens du Nord, là où les racines et les symboles ont du sens.
              </p>
              <p className="text-lg text-slate-700 leading-relaxed">
                Ma vie a été un voyage intérieur : obstacles, renaissances, synchronicités.
              </p>
              <p className="text-lg text-slate-700 leading-relaxed">
                Ce chemin m'a conduit à créer une invention capable d'aider et de transformer chacun.
              </p>
            </div>
          </div>

          {/* Section bas */}
          <div className="space-y-4">
            <div className="flex justify-center">
              <Button variant="default" className="bg-slate-900 hover:bg-slate-800 w-3/5">
                Plus d'informations
              </Button>
            </div>

            <div className="flex items-center justify-center gap-2">
              <span className="text-xs font-bold text-slate-900">MATTHIEU</span>
              <span className="text-xs text-slate-400">• BRODERIE</span>
              <span className="text-xs text-slate-400">• ART-THÉRAPIE</span>
              <span className="text-xs text-slate-400">• OPPORTUNITÉ</span>
            </div>

            <div className="flex justify-end pr-6">
              <Button variant="outline" className="min-w-[100px]">
                Suivant
              </Button>
            </div>
          </div>
        </motion.div>
      ),
      buttonText: "Suivant"
    },

    // SLIDE 1 - Broderie
    {
      content: (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex flex-col justify-between h-full px-12 py-12"
        >
          {/* Contenu principal */}
          <div className="flex items-center justify-center gap-8">
            <MiniGrid type="broderie" />
            
            <div className="max-w-lg space-y-4">
              <p className="text-lg text-slate-700 leading-relaxed">
                PATYBEE supprime les PDF illisibles et les dizaines de pages.
              </p>
              <p className="text-lg text-slate-700 leading-relaxed">
                Un visuel → une grille complète DMC + symboles + marquage.
              </p>
              <p className="text-lg text-slate-700 leading-relaxed">
                Première technologie capable de reconstruire et corriger n'importe quelle grille.
              </p>
            </div>
          </div>

          {/* Section bas */}
          <div className="space-y-4">
            <div className="flex justify-center">
              <Button variant="default" className="bg-slate-900 hover:bg-slate-800 w-3/5">
                Plus d'informations
              </Button>
            </div>

            <div className="flex items-center justify-center gap-2">
              <span className="text-xs text-slate-400">MATTHIEU</span>
              <span className="text-xs font-bold text-slate-900">• BRODERIE</span>
              <span className="text-xs text-slate-400">• ART-THÉRAPIE</span>
              <span className="text-xs text-slate-400">• OPPORTUNITÉ</span>
            </div>

            <div className="flex justify-end pr-6">
              <Button variant="outline" className="min-w-[100px]">
                Suivant
              </Button>
            </div>
          </div>
        </motion.div>
      ),
      buttonText: "Suivant"
    },

    // SLIDE 2 - Art-thérapie
    {
      content: (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex flex-col justify-between h-full px-12 py-12"
        >
          {/* Contenu principal */}
          <div className="flex items-center justify-center gap-8">
            <MiniGrid type="therapie" />
            
            <div className="max-w-lg space-y-4">
              <p className="text-lg text-slate-700 leading-relaxed">
                Chaque symbole devient un miroir émotionnel.
              </p>
              <p className="text-lg text-slate-700 leading-relaxed">
                Broder, c'est libérer : un point défait un nœud intérieur.
              </p>
              <p className="text-lg text-slate-700 leading-relaxed">
                Première broderie thérapeutique intelligente : elle vous lit autant que vous la brodez.
              </p>
            </div>
          </div>

          {/* Section bas */}
          <div className="space-y-4">
            <div className="flex justify-center">
              <Button variant="default" className="bg-slate-900 hover:bg-slate-800 w-3/5">
                Plus d'informations
              </Button>
            </div>

            <div className="flex items-center justify-center gap-2">
              <span className="text-xs text-slate-400">MATTHIEU</span>
              <span className="text-xs text-slate-400">• BRODERIE</span>
              <span className="text-xs font-bold text-slate-900">• ART-THÉRAPIE</span>
              <span className="text-xs text-slate-400">• OPPORTUNITÉ</span>
            </div>

            <div className="flex justify-end pr-6">
              <Button variant="outline" className="min-w-[100px]">
                Suivant
              </Button>
            </div>
          </div>
        </motion.div>
      ),
      buttonText: "Suivant"
    },

    // SLIDE 3 - Opportunité
    {
      content: (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex flex-col justify-between h-full px-12 py-12"
        >
          {/* Contenu principal */}
          <div className="flex items-center justify-center gap-8">
            <MiniGrid type="opportunite" />
            
            <div className="max-w-lg space-y-4">
              <p className="text-lg text-slate-700 leading-relaxed">
                PATYBEE reconnecte chacun à son axe personnel.
              </p>
              <p className="text-lg text-slate-700 leading-relaxed">
                Il révèle ce que le système obscurcit : clarté, justice, autonomie.
              </p>
              <p className="text-lg text-slate-700 leading-relaxed">
                Un outil universel qui révèle, structure et libère.
              </p>
            </div>
          </div>

          {/* Section bas */}
          <div className="space-y-4">
            <div className="flex justify-center">
              <Button variant="default" className="bg-slate-900 hover:bg-slate-800 w-3/5">
                Plus d'informations
              </Button>
            </div>

            <div className="flex items-center justify-center gap-2">
              <span className="text-xs text-slate-400">MATTHIEU</span>
              <span className="text-xs text-slate-400">• BRODERIE</span>
              <span className="text-xs text-slate-400">• ART-THÉRAPIE</span>
              <span className="text-xs font-bold text-slate-900">• OPPORTUNITÉ</span>
            </div>

            <div className="flex justify-end pr-6">
              <Button variant="outline" className="min-w-[100px]">
                Suivant
              </Button>
            </div>
          </div>
        </motion.div>
      ),
      buttonText: "Suivant"
    },

    // SLIDE 2 - Fonctionnement PATYBEE
    {
      content: (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex flex-col items-center justify-center h-full space-y-8 px-8 py-12"
        >
          {/* Carré animé central */}
          <div className="relative w-96 h-96 bg-white rounded-2xl shadow-2xl border-2 border-slate-200 overflow-hidden">
            {/* ÉTAPE 1 - Import d'image */}
            <motion.div
              initial={{ y: 100, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.5, duration: 0.8 }}
              className="absolute inset-0 flex items-center justify-center"
            >
              <motion.div
                animate={{ scale: [1, 0.95, 1] }}
                transition={{ delay: 1.5, duration: 2, repeat: Infinity }}
                className="w-64 h-64 bg-gradient-to-br from-purple-300 via-pink-300 to-orange-300 rounded-xl"
              >
                <div className="w-full h-full flex items-center justify-center text-6xl">
                  🌸
                </div>
              </motion.div>
            </motion.div>

            {/* ÉTAPE 2 - Analyse (points colorés) */}
            {[...Array(12)].map((_, i) => (
              <motion.div
                key={`dot-${i}`}
                initial={{ scale: 0, opacity: 0 }}
                animate={{ scale: [0, 1.5, 0.8], opacity: [0, 1, 0] }}
                transition={{ 
                  delay: 2 + i * 0.1, 
                  duration: 1,
                  repeat: Infinity,
                  repeatDelay: 4
                }}
                className="absolute w-3 h-3 rounded-full"
                style={{
                  backgroundColor: ['#FF6B6B', '#4ECDC4', '#FFD93D', '#95E1D3'][i % 4],
                  top: `${20 + (i % 4) * 20}%`,
                  left: `${20 + Math.floor(i / 4) * 20}%`
                }}
              />
            ))}

            {/* ÉTAPE 3 - Palette DMC */}
            <motion.div
              initial={{ y: 100, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 3.5, duration: 0.6 }}
              className="absolute bottom-4 left-4 right-4 h-12 bg-slate-800 rounded-lg flex items-center gap-2 px-3"
            >
              {['#FF6B6B', '#4ECDC4', '#FFD93D', '#95E1D3', '#A8E6CF', '#F38181'].map((color, i) => (
                <motion.div
                  key={`palette-${i}`}
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 3.7 + i * 0.1 }}
                  className="w-8 h-8 rounded"
                  style={{ backgroundColor: color }}
                />
              ))}
            </motion.div>

            {/* ÉTAPE 4 - Grille + symboles */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.9 }}
              transition={{ delay: 4.5, duration: 0.8 }}
              className="absolute inset-8 grid grid-cols-5 gap-1"
            >
              {[...Array(25)].map((_, i) => (
                <motion.div
                  key={`grid-${i}`}
                  initial={{ scale: 0, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ delay: 4.7 + i * 0.03, duration: 0.3 }}
                  className="bg-white/90 backdrop-blur-sm rounded flex items-center justify-center text-xl font-bold border border-slate-200"
                >
                  {['●', '■', '▲', '◆', '★'][i % 5]}
                </motion.div>
              ))}
            </motion.div>

            {/* ÉTAPE 5 - Personnalisation (symbole qui change) */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ 
                opacity: [0, 1, 1, 0],
                scale: [1, 1.3, 1, 1]
              }}
              transition={{ 
                delay: 6,
                duration: 2,
                times: [0, 0.3, 0.7, 1],
                repeat: Infinity,
                repeatDelay: 2
              }}
              className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-16 h-16 bg-yellow-300 rounded-full flex items-center justify-center text-3xl font-bold shadow-lg"
            >
              <motion.span
                animate={{ rotate: [0, 180] }}
                transition={{ delay: 6.5, duration: 0.5, repeat: Infinity, repeatDelay: 3.5 }}
              >
                ●→○
              </motion.span>
            </motion.div>

            {/* ÉTAPE 6 - Cases brodées */}
            {[2, 7, 12, 17, 22].map((index, i) => (
              <motion.div
                key={`done-${i}`}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ 
                  delay: 8 + i * 0.2,
                  repeat: Infinity,
                  repeatDelay: 4
                }}
                className="absolute"
                style={{
                  top: `${32 + Math.floor(index / 5) * 20}%`,
                  left: `${32 + (index % 5) * 20}%`,
                  width: '12%',
                  height: '12%'
                }}
              >
                <motion.div
                  animate={{
                    boxShadow: [
                      '0 0 0 0 rgba(239, 68, 68, 0)',
                      '0 0 0 4px rgba(239, 68, 68, 0.4)',
                      '0 0 0 0 rgba(239, 68, 68, 0)'
                    ]
                  }}
                  transition={{ duration: 1, repeat: Infinity, repeatDelay: 3 }}
                  className="w-full h-full border-2 border-red-500 rounded"
                />
              </motion.div>
            ))}
          </div>

          {/* Texte marketing */}
          <div className="max-w-3xl space-y-6 text-center">
            <h2 className="text-4xl font-bold text-slate-900">
              PATYBEE™ — La broderie réinventée.
            </h2>

            <p className="text-lg text-slate-700 leading-relaxed">
              <strong>PATYBEE™</strong> est le premier logiciel qui transforme une simple image en une grille de broderie complète. 
              Aucun PDF, aucune recherche de motifs : tout commence avec votre image.
            </p>

            <p className="text-lg text-slate-700 leading-relaxed">
              Importez une photo, une illustration ou une couverture de motif. 
              PATYBEE™ détecte automatiquement les couleurs, génère une palette DMC fidèle et construit toute la grille, case par case.
            </p>

            <p className="text-lg text-slate-700 leading-relaxed">
              Un symbole ne vous convient pas ? Une couleur détectée doit être ajustée ? 
              Cliquez simplement sur une case : modifiez le symbole ou la couleur, et PATYBEE™ met tout à jour instantanément dans la grille entière.
            </p>

            <p className="text-lg text-slate-700 leading-relaxed">
              Brodez plus facilement que jamais grâce à une grille lisible, dynamique et entièrement personnalisable.
            </p>

            <p className="text-2xl font-bold text-slate-900 mt-8">
              "PATYBEE™ — Brodez ce que vous aimez."
            </p>
          </div>
        </motion.div>
      ),
      buttonText: "Commencer maintenant"
    },

    // SLIDE 3 - Plus besoin de PDF (optionnel, peut être retiré)
    {
      content: (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex flex-col items-center justify-center h-full space-y-8 px-8"
        >
          <h2 className="text-4xl font-bold text-slate-900">Fini les PDF compliqués.</h2>
          
          <div className="relative w-full max-w-4xl h-96 flex items-center justify-center">
            {/* PDF froissé qui disparaît */}
            <motion.div
              initial={{ scale: 1, rotate: 0, opacity: 1 }}
              animate={{ 
                scale: 0.5, 
                rotate: -15, 
                opacity: 0,
                x: -200
              }}
              transition={{ delay: 1, duration: 1 }}
              className="absolute"
            >
              <div className="w-64 h-80 bg-gradient-to-br from-slate-200 to-slate-300 rounded-lg shadow-2xl p-4 border-2 border-slate-400 transform rotate-3">
                <div className="text-xs text-slate-600 space-y-2">
                  <div className="h-3 bg-slate-400 w-3/4 rounded"></div>
                  <div className="h-2 bg-slate-300 w-full rounded"></div>
                  <div className="h-2 bg-slate-300 w-5/6 rounded"></div>
                  <div className="grid grid-cols-4 gap-1 mt-4">
                    {[...Array(16)].map((_, i) => (
                      <div key={i} className="h-8 bg-slate-300 rounded text-center text-xs">
                        ?
                      </div>
                    ))}
                  </div>
                  <div className="text-[8px] text-slate-500 mt-2">Page 1/12...</div>
                </div>
                <div className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-8 h-8 flex items-center justify-center text-xl">
                  ✕
                </div>
              </div>
            </motion.div>

            {/* Image qui arrive */}
            <motion.div
              initial={{ scale: 0.5, opacity: 0, x: 200 }}
              animate={{ scale: 1, opacity: 1, x: 0 }}
              transition={{ delay: 2, duration: 0.8 }}
              className="absolute"
            >
              <div className="w-64 h-64 bg-gradient-to-br from-purple-300 via-pink-300 to-orange-300 rounded-2xl shadow-xl flex items-center justify-center transform">
                <span className="text-6xl">🎨</span>
              </div>
            </motion.div>

            {/* Grille qui se construit */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8, y: 50 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              transition={{ delay: 3, duration: 0.8 }}
              className="absolute"
            >
              <div className="w-80 h-80 bg-white rounded-xl shadow-2xl p-4 border-2 border-slate-200">
                <div className="grid grid-cols-6 gap-2">
                  {[...Array(24)].map((_, i) => (
                    <motion.div
                      key={i}
                      initial={{ scale: 0, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      transition={{ delay: 3.2 + i * 0.05, duration: 0.3 }}
                      className="h-10 bg-slate-50 rounded flex items-center justify-center text-xl font-bold border border-slate-200"
                    >
                      {['●', '■', '▲', '◆', '★', '✦'][i % 6]}
                    </motion.div>
                  ))}
                </div>

                {/* Palette DMC en bas */}
                <motion.div
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 4.5, duration: 0.5 }}
                  className="mt-4 flex gap-2"
                >
                  {['#FF6B6B', '#4ECDC4', '#FFD93D', '#95E1D3', '#A8E6CF', '#F38181'].map((color, i) => (
                    <motion.div
                      key={i}
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ delay: 4.7 + i * 0.1 }}
                      className="w-10 h-10 rounded"
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </motion.div>
              </div>
            </motion.div>
          </div>

          <div className="max-w-3xl text-center space-y-4">
            <p className="text-lg text-slate-700 leading-relaxed">
              Avec PATY™, vous n'avez plus besoin de récupérer des PDF de grilles, de les reconstituer, 
              de déchiffrer les symboles des auteurs ou de jongler avec plusieurs pages introuvables sur Internet.
            </p>
            <p className="text-lg text-slate-700 leading-relaxed">
              <strong>Importez simplement un visuel</strong> : photo, illustration, image de couverture. 
              PATY™ analyse automatiquement les couleurs, crée les symboles, et génère une grille complète, 
              moderne et personnalisable.
            </p>
            <p className="text-lg font-semibold text-slate-900">
              Ici, c'est PATY™ qui crée la grille. Vous pouvez ensuite modifier les symboles et les couleurs DMC à la carte.
            </p>
          </div>
        </motion.div>
      ),
      buttonText: "Continuer"
    },

    // SLIDE 4 - Importer une image
    {
      content: (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex flex-col items-center justify-center h-full space-y-8 px-8"
        >
          <h2 className="text-3xl font-bold text-slate-900">Importez votre image</h2>
          
          <div className="relative w-full max-w-4xl h-96 bg-white rounded-xl border-2 border-slate-200 overflow-hidden">
            {/* Interface simplifiée */}
            <div className="absolute top-4 left-4 right-4 flex gap-2">
              <motion.button
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.5 }}
                className="px-4 py-2 bg-purple-600 text-white rounded-lg flex items-center gap-2"
              >
                <span>📁</span> Importer une image
              </motion.button>
            </div>

            {/* Flèche animée */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.8 }}
              className="absolute top-16 left-24"
            >
              <AnimatedArrow direction="up" />
            </motion.div>

            {/* Image apparaît */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 1.5 }}
              className="absolute inset-0 flex items-center justify-center"
            >
              <div className="w-64 h-64 bg-gradient-to-br from-purple-200 to-pink-200 rounded-lg flex items-center justify-center">
                <span className="text-6xl">🎨</span>
              </div>
            </motion.div>
          </div>

          <p className="text-lg text-slate-600 max-w-2xl text-center">
            Importez n'importe quelle image. PATY détecte automatiquement les couleurs et prépare votre grille.
          </p>
        </motion.div>
      ),
      buttonText: "Suivant"
    },

    // SLIDE 5 - Construction de la grille
    {
      content: (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex flex-col items-center justify-center h-full space-y-8 px-8"
        >
          <h2 className="text-3xl font-bold text-slate-900">Grille automatique</h2>
          
          <div className="relative w-full max-w-4xl h-96 bg-white rounded-xl border-2 border-slate-200 p-8">
            {/* Grille qui se dessine */}
            <motion.div
              initial={{ pathLength: 0 }}
              animate={{ pathLength: 1 }}
              transition={{ duration: 2 }}
              className="absolute inset-8"
            >
              <svg className="w-full h-full">
                {/* Lignes verticales */}
                {[...Array(8)].map((_, i) => (
                  <motion.line
                    key={`v${i}`}
                    x1={`${(i + 1) * 11}%`}
                    y1="0%"
                    x2={`${(i + 1) * 11}%`}
                    y2="100%"
                    stroke="#e2e8f0"
                    strokeWidth="1"
                    initial={{ pathLength: 0 }}
                    animate={{ pathLength: 1 }}
                    transition={{ delay: i * 0.1, duration: 0.5 }}
                  />
                ))}
                {/* Lignes horizontales */}
                {[...Array(6)].map((_, i) => (
                  <motion.line
                    key={`h${i}`}
                    x1="0%"
                    y1={`${(i + 1) * 14}%`}
                    x2="100%"
                    y2={`${(i + 1) * 14}%`}
                    stroke="#e2e8f0"
                    strokeWidth="1"
                    initial={{ pathLength: 0 }}
                    animate={{ pathLength: 1 }}
                    transition={{ delay: 0.8 + i * 0.1, duration: 0.5 }}
                  />
                ))}
              </svg>
            </motion.div>

            {/* Symboles qui apparaissent */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 2 }}
              className="absolute inset-8 grid grid-cols-8 gap-4"
            >
              {[...Array(24)].map((_, i) => (
                <motion.div
                  key={i}
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 2 + i * 0.05 }}
                  className="flex items-center justify-center text-xl font-bold"
                >
                  {['●', '■', '▲', '◆', '★'][i % 5]}
                </motion.div>
              ))}
            </motion.div>

            {/* Palette DMC qui monte */}
            <motion.div
              initial={{ y: 100, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 3 }}
              className="absolute bottom-4 left-4 right-4 h-16 bg-slate-100 rounded-lg flex items-center gap-2 px-4"
            >
              {['#FF6B6B', '#4ECDC4', '#FFD93D', '#95E1D3', '#A8E6CF'].map((color, i) => (
                <motion.div
                  key={i}
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 3.2 + i * 0.1 }}
                  className="w-12 h-12 rounded"
                  style={{ backgroundColor: color }}
                />
              ))}
            </motion.div>
          </div>

          <p className="text-lg text-slate-600 max-w-2xl text-center">
            PATY crée automatiquement une grille complète : couleurs DMC détectées, symboles assignés et rendu fidèle à l'image.
          </p>
        </motion.div>
      ),
      buttonText: "Suivant"
    },

    // SLIDE 6 - Sélectionner un symbole
    {
      content: (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex flex-col items-center justify-center h-full space-y-8 px-8"
        >
          <h2 className="text-3xl font-bold text-slate-900">Sélectionnez un symbole</h2>
          
          <div className="relative w-full max-w-4xl h-96 bg-white rounded-xl border-2 border-slate-200 p-8">
            {/* Grille avec symboles */}
            <div className="grid grid-cols-8 gap-4">
              {[...Array(40)].map((_, i) => {
                const isTarget = i === 12;
                const isHighlighted = [4, 12, 20, 28, 36].includes(i);
                
                return (
                  <motion.div
                    key={i}
                    className={`flex items-center justify-center text-2xl font-bold rounded transition-all ${
                      isHighlighted ? 'bg-yellow-200' : ''
                    }`}
                    animate={isHighlighted ? {
                      scale: [1, 1.1, 1],
                      backgroundColor: ['#fef08a', '#fde047', '#fef08a']
                    } : {}}
                    transition={{
                      delay: isTarget ? 1 : 2,
                      duration: 1,
                      repeat: Infinity
                    }}
                  >
                    {['●', '■', '▲', '◆', '★'][i % 5]}
                  </motion.div>
                );
              })}
            </div>

            {/* Flèche pointant un symbole */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
              className="absolute top-24 left-1/3"
            >
              <AnimatedArrow direction="down" />
            </motion.div>

            {/* Palette en bas avec halo */}
            <motion.div
              className="absolute bottom-4 left-4 right-4 h-16 bg-slate-100 rounded-lg flex items-center gap-2 px-4"
            >
              {['#FF6B6B', '#4ECDC4', '#FFD93D', '#95E1D3', '#A8E6CF'].map((color, i) => (
                <motion.div
                  key={i}
                  className="w-12 h-12 rounded relative"
                  style={{ backgroundColor: color }}
                  animate={i === 2 ? {
                    boxShadow: [
                      '0 0 0 0 rgba(255, 217, 61, 0)',
                      '0 0 0 8px rgba(255, 217, 61, 0.4)',
                      '0 0 0 0 rgba(255, 217, 61, 0)'
                    ]
                  } : {}}
                  transition={{
                    delay: 2,
                    duration: 1.5,
                    repeat: Infinity
                  }}
                />
              ))}
            </motion.div>
          </div>

          <p className="text-lg text-slate-600 max-w-2xl text-center">
            Cliquez sur n'importe quel symbole : PATY surligne toutes les cases identiques.
          </p>
        </motion.div>
      ),
      buttonText: "Modifier"
    },

    // SLIDE 7 - Modifier symbole & couleur
    {
      content: (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex flex-col items-center justify-center h-full space-y-8 px-8"
        >
          <h2 className="text-3xl font-bold text-slate-900">Modifiez en un clic</h2>
          
          <div className="relative w-full max-w-4xl h-96 bg-white rounded-xl border-2 border-slate-200 p-8">
            {/* Grille qui change */}
            <div className="grid grid-cols-8 gap-4 mb-20">
              {[...Array(24)].map((_, i) => {
                const willChange = [4, 12, 20].includes(i);
                
                return (
                  <motion.div
                    key={i}
                    className="flex items-center justify-center text-2xl font-bold"
                    animate={willChange ? {
                      rotate: [0, 180, 360],
                      scale: [1, 1.2, 1]
                    } : {}}
                    transition={{ delay: 2 + i * 0.1, duration: 0.8 }}
                  >
                    <motion.span
                      animate={willChange ? {
                        opacity: [1, 0, 1]
                      } : {}}
                      transition={{ delay: 2 + i * 0.1, duration: 0.4 }}
                    >
                      {willChange ? '◆' : ['●', '■', '▲'][i % 3]}
                    </motion.span>
                  </motion.div>
                );
              })}
            </div>

            {/* Palette de symboles qui apparaît */}
            <motion.div
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.5 }}
              className="absolute bottom-24 left-8 right-8 h-16 bg-slate-100 rounded-lg flex items-center gap-3 px-4"
            >
              {['●', '■', '▲', '◆', '★', '✦', '◇', '▼'].map((symbol, i) => (
                <motion.div
                  key={i}
                  className="w-12 h-12 flex items-center justify-center text-2xl font-bold rounded hover:bg-white cursor-pointer"
                  whileHover={{ scale: 1.1 }}
                  animate={i === 3 ? {
                    backgroundColor: ['transparent', '#fef08a', 'transparent']
                  } : {}}
                  transition={{
                    delay: 1.5,
                    duration: 0.5,
                    repeat: 3
                  }}
                >
                  {symbol}
                </motion.div>
              ))}
            </motion.div>

            {/* Palette couleurs DMC */}
            <motion.div
              className="absolute bottom-4 left-8 right-8 h-12 bg-slate-50 rounded-lg flex items-center gap-2 px-4"
            >
              {['#FF6B6B', '#4ECDC4', '#FFD93D', '#95E1D3', '#A8E6CF', '#F38181'].map((color, i) => (
                <motion.div
                  key={i}
                  className="w-10 h-10 rounded cursor-pointer"
                  style={{ backgroundColor: color }}
                  animate={i === 5 ? {
                    scale: [1, 1.15, 1],
                    boxShadow: [
                      '0 0 0 0 rgba(243, 129, 129, 0)',
                      '0 0 0 6px rgba(243, 129, 129, 0.4)',
                      '0 0 0 0 rgba(243, 129, 129, 0)'
                    ]
                  } : {}}
                  transition={{
                    delay: 3.5,
                    duration: 0.8,
                    repeat: 2
                  }}
                />
              ))}
            </motion.div>
          </div>

          <p className="text-lg text-slate-600 max-w-2xl text-center">
            Changez le symbole ou la couleur DMC d'un seul geste. PATY applique la modification à toute la grille.
          </p>
        </motion.div>
      ),
      buttonText: "Suivant"
    },

    // SLIDE 8 - Marquer comme brodé
    {
      content: (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex flex-col items-center justify-center h-full space-y-8 px-8"
        >
          <h2 className="text-3xl font-bold text-slate-900">Suivez votre progression</h2>
          
          <div className="relative w-full max-w-4xl h-96 bg-white rounded-xl border-2 border-slate-200 p-8">
            {/* Grille */}
            <div className="grid grid-cols-8 gap-4 mb-24">
              {[...Array(32)].map((_, i) => {
                const isDone = i < 12 || [16, 17, 18].includes(i);
                const willBeDone = [16, 17, 18].includes(i);
                
                return (
                  <motion.div
                    key={i}
                    className={`flex items-center justify-center text-2xl font-bold rounded relative ${
                      isDone ? 'bg-red-50' : ''
                    }`}
                    animate={willBeDone ? {
                      backgroundColor: ['transparent', '#fee2e2', '#fef2f2'],
                      scale: [1, 1.1, 1]
                    } : {}}
                    transition={{ delay: 2 + i * 0.05, duration: 0.5 }}
                  >
                    {['●', '■', '▲', '◆'][i % 4]}
                    {isDone && (
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        transition={{ delay: willBeDone ? 2 + i * 0.05 : 0 }}
                        className="absolute inset-0 border-2 border-red-500 rounded"
                      />
                    )}
                  </motion.div>
                );
              })}
            </div>

            {/* Bouton marquer comme brodé */}
            <motion.div
              className="absolute bottom-24 left-8"
            >
              <motion.button
                animate={{
                  scale: [1, 1.05, 1],
                  boxShadow: [
                    '0 0 0 0 rgba(34, 197, 94, 0)',
                    '0 0 0 8px rgba(34, 197, 94, 0.2)',
                    '0 0 0 0 rgba(34, 197, 94, 0)'
                  ]
                }}
                transition={{ delay: 1, duration: 1.5, repeat: Infinity }}
                className="px-6 py-3 bg-green-600 text-white rounded-lg font-medium"
              >
                ✓ Marquer comme brodé
              </motion.button>
            </motion.div>

            {/* Barre de progression */}
            <motion.div
              className="absolute bottom-8 left-8 right-8"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-slate-600">Progression</span>
                <motion.span
                  animate={{ opacity: [1, 0.5, 1] }}
                  transition={{ delay: 2.5, duration: 0.5, repeat: 2 }}
                  className="text-sm font-bold text-green-600"
                >
                  47% → 56%
                </motion.span>
              </div>
              <div className="w-full h-3 bg-slate-200 rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: '47%' }}
                  animate={{ width: '56%' }}
                  transition={{ delay: 2.5, duration: 1 }}
                  className="h-full bg-green-600 rounded-full"
                />
              </div>
            </motion.div>
          </div>

          <p className="text-lg text-slate-600 max-w-2xl text-center">
            Marquez vos points comme brodés. Suivez votre progression automatiquement.
          </p>
        </motion.div>
      ),
      buttonText: "Suivant"
    },

    // SLIDE 9 - Importer une grille existante
    {
      content: (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex flex-col items-center justify-center h-full space-y-8 px-8"
        >
          <h2 className="text-4xl font-bold text-slate-900">
            Vous avez déjà une grille ?
          </h2>

          <div className="relative w-full max-w-4xl h-96 flex items-center justify-center">
            {/* Image PDF/Grille qui apparaît */}
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.5, duration: 0.8 }}
              className="absolute"
            >
              <div className="w-80 h-96 bg-white rounded-xl shadow-2xl border-2 border-slate-200 p-6">
                {/* En-tête de grille */}
                <div className="text-xs text-slate-600 mb-4">
                  <div className="font-bold">Mon motif broderie</div>
                  <div className="text-[10px]">150 x 200 points</div>
                </div>

                {/* Grille avec symboles */}
                <div className="grid grid-cols-8 gap-0.5 mb-4">
                  {[...Array(40)].map((_, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: 1 + i * 0.02 }}
                      className="h-8 bg-slate-50 border border-slate-200 flex items-center justify-center text-sm font-bold"
                    >
                      {['●', '■', '▲', '◆', '★', '✦', '○', '□'][i % 8]}
                    </motion.div>
                  ))}
                </div>

                {/* Légende */}
                <motion.div
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 2, duration: 0.6 }}
                  className="text-[10px] space-y-1 bg-slate-50 p-2 rounded"
                >
                  <div className="font-bold text-slate-700">Légende :</div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold">●</span> DMC 310 - Noir
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold">■</span> DMC 666 - Rouge
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold">▲</span> DMC 444 - Jaune
                  </div>
                </motion.div>
              </div>
            </motion.div>

            {/* Animation de scan */}
            <motion.div
              initial={{ scaleY: 0, opacity: 0 }}
              animate={{ scaleY: 1, opacity: [0, 0.6, 0] }}
              transition={{ delay: 2.5, duration: 1.5 }}
              className="absolute w-80 h-1 bg-blue-500 blur-sm"
              style={{ transformOrigin: 'top' }}
            />

            {/* Extraction des symboles */}
            <motion.div
              initial={{ scale: 0, opacity: 0, x: 100 }}
              animate={{ scale: 1, opacity: 1, x: 150 }}
              transition={{ delay: 3.5, duration: 0.8 }}
              className="absolute bg-purple-100 border-2 border-purple-400 rounded-xl p-4 shadow-xl"
            >
              <div className="text-xs font-bold text-purple-900 mb-2">Symboles détectés</div>
              <div className="flex gap-2">
                {['●', '■', '▲', '◆', '★'].map((symbol, i) => (
                  <motion.div
                    key={i}
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 3.7 + i * 0.1 }}
                    className="w-8 h-8 bg-white rounded flex items-center justify-center font-bold"
                  >
                    {symbol}
                  </motion.div>
                ))}
              </div>
            </motion.div>

            {/* Palette DMC qui apparaît */}
            <motion.div
              initial={{ scale: 0, opacity: 0, x: -100 }}
              animate={{ scale: 1, opacity: 1, x: -150 }}
              transition={{ delay: 4.5, duration: 0.8 }}
              className="absolute bg-blue-100 border-2 border-blue-400 rounded-xl p-4 shadow-xl"
            >
              <div className="text-xs font-bold text-blue-900 mb-2">Palette DMC</div>
              <div className="flex gap-2">
                {['#000000', '#E3242B', '#FFD93D', '#4ECDC4', '#A8E6CF'].map((color, i) => (
                  <motion.div
                    key={i}
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 4.7 + i * 0.1 }}
                    className="w-8 h-8 rounded"
                    style={{ backgroundColor: color }}
                  />
                ))}
              </div>
            </motion.div>

            {/* Grille PATYBEE reconstruite */}
            <motion.div
              initial={{ scale: 0.5, opacity: 0, y: 100 }}
              animate={{ scale: 1, opacity: 1, y: 150 }}
              transition={{ delay: 5.5, duration: 1 }}
              className="absolute bg-white rounded-xl shadow-2xl border-2 border-green-400 p-3"
            >
              <div className="text-xs font-bold text-green-900 mb-2 flex items-center gap-2">
                <span className="text-lg">✓</span> Grille PATYBEE
              </div>
              <div className="grid grid-cols-6 gap-1">
                {[...Array(18)].map((_, i) => (
                  <motion.div
                    key={i}
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 5.7 + i * 0.03 }}
                    className="w-6 h-6 bg-slate-50 rounded flex items-center justify-center text-xs font-bold border border-slate-200"
                  >
                    {['●', '■', '▲', '◆', '★', '✦'][i % 6]}
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>

          <div className="max-w-3xl text-center space-y-4">
            <p className="text-lg text-slate-700 leading-relaxed">
              Vous avez une grille PDF déjà créée ? 
              Importez-la et <strong>PATYBEE™ détecte automatiquement les symboles</strong>, 
              les couleurs DMC et reconstruit toute la grille pour vous.
            </p>
            <p className="text-lg text-slate-700 leading-relaxed">
              Vous pouvez ensuite modifier les symboles, les couleurs, 
              et broder la grille comme si elle avait été créée dans PATYBEE™.
            </p>
          </div>
        </motion.div>
      ),
      buttonText: "Importer une grille existante"
    },

    // SLIDE 10 - Respect des auteurs & Marketplace
    {
      content: (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex flex-col items-center justify-center h-full space-y-8 px-8 py-12"
        >
          <h2 className="text-4xl font-bold text-slate-900">
            Respect des auteurs & Marketplace PATYBEE™
          </h2>

          {/* Animation centrale */}
          <div className="relative w-full max-w-5xl h-96 flex items-center justify-center">
            {/* ÉTAPE 1 - Import PDF */}
            <motion.div
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.5, duration: 0.6 }}
              className="absolute"
            >
              <div className="w-32 h-40 bg-red-100 border-2 border-red-400 rounded-lg shadow-xl flex items-center justify-center">
                <span className="text-5xl">📄</span>
              </div>
            </motion.div>

            {/* ÉTAPE 2 - Fenêtre de validation */}
            <motion.div
              initial={{ scale: 0, opacity: 0, y: -50 }}
              animate={{ scale: 1, opacity: 1, y: -80 }}
              transition={{ delay: 1.2, duration: 0.6 }}
              className="absolute bg-white border-2 border-blue-400 rounded-xl shadow-2xl p-4 w-80"
            >
              <div className="space-y-3">
                <div className="text-sm font-bold text-slate-900">Respect des droits d'auteur</div>
                <div className="flex items-start gap-2 text-xs text-slate-700">
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 1.8 }}
                    className="w-4 h-4 bg-green-500 rounded flex items-center justify-center text-white text-[10px] mt-0.5"
                  >
                    ✓
                  </motion.div>
                  <span>Je certifie avoir le droit d'utiliser ce fichier</span>
                </div>
                <div className="flex items-start gap-2 text-xs text-slate-700">
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 2.2 }}
                    className="w-4 h-4 bg-purple-500 rounded flex items-center justify-center text-white text-[10px] mt-0.5"
                  >
                    ✓
                  </motion.div>
                  <span>Je suis l'auteur de cette grille</span>
                </div>
              </div>
            </motion.div>

            {/* ÉTAPE 3 - Validation créateur */}
            <motion.div
              initial={{ scale: 0, opacity: 0, x: 100 }}
              animate={{ scale: 1, opacity: 1, x: 180 }}
              transition={{ delay: 2.8, duration: 0.6 }}
              className="absolute bg-green-50 border-2 border-green-500 rounded-xl shadow-xl p-4"
            >
              <div className="text-xs font-bold text-green-900 mb-2 flex items-center gap-2">
                <span className="text-lg">✓</span> Création validée
              </div>
              <div className="text-[10px] text-green-700">Royalties activées</div>
            </motion.div>

            {/* ÉTAPE 4 - Boutique */}
            <motion.div
              initial={{ scale: 0, opacity: 0, y: 80 }}
              animate={{ scale: 1, opacity: 1, y: 100 }}
              transition={{ delay: 3.5, duration: 0.6 }}
              className="absolute bg-white border-2 border-slate-200 rounded-xl shadow-xl p-3 w-64"
            >
              <div className="text-xs font-bold text-slate-900 mb-2">Boutique PATYBEE™</div>
              <div className="grid grid-cols-3 gap-2">
                {[1, 2, 3].map((i) => (
                  <motion.div
                    key={i}
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 3.7 + i * 0.1 }}
                    className="h-16 bg-gradient-to-br from-purple-100 to-pink-100 rounded border border-slate-200"
                  />
                ))}
              </div>
            </motion.div>

            {/* ÉTAPE 5 - Compteur royalties */}
            <motion.div
              initial={{ scale: 0, opacity: 0, x: -100 }}
              animate={{ scale: 1, opacity: 1, x: -180 }}
              transition={{ delay: 4.3, duration: 0.6 }}
              className="absolute bg-amber-50 border-2 border-amber-400 rounded-xl shadow-xl p-4"
            >
              <div className="text-xs font-bold text-amber-900 mb-1">Royalties générées</div>
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 4.8 }}
                className="text-2xl font-bold text-amber-600"
              >
                12,30 €
              </motion.div>
            </motion.div>
          </div>

          {/* Texte marketing */}
          <div className="max-w-4xl space-y-4 text-center">
            <p className="text-lg text-slate-700 leading-relaxed">
              <strong>PATYBEE™ protège les créateurs de grilles de point de croix.</strong><br />
              Lorsqu'une brodeuse importe un PDF, elle confirme qu'elle respecte les droits d'auteur.
            </p>

            <p className="text-lg text-slate-700 leading-relaxed">
              Si l'auteur d'origine est inscrit, il peut se déclarer comme créateur de la grille.<br />
              <strong>PATYBEE™ lui attribue alors automatiquement des royalties</strong>, au même titre qu'un artiste sur Spotify.
            </p>

            <div className="bg-purple-50 border-2 border-purple-200 rounded-xl p-6 text-left">
              <div className="text-base text-purple-900 space-y-2">
                <div className="font-bold text-lg mb-3">Les créateurs peuvent :</div>
                <div className="flex items-start gap-2">
                  <span className="text-purple-600">✔</span>
                  <span>Convertir leurs anciennes grilles PDF en projets PATYBEE™</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-purple-600">✔</span>
                  <span>Créer directement de nouvelles grilles dans l'application</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-purple-600">✔</span>
                  <span>Publier leurs créations dans la boutique PATYBEE™</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-purple-600">✔</span>
                  <span>Générer un revenu régulier, transparent et mérité</span>
                </div>
              </div>
            </div>

            <p className="text-2xl font-bold text-slate-900 mt-8">
              PATYBEE™ honore la créativité.<br />
              <span className="text-purple-700">Chaque grille a une histoire, chaque auteur a une signature.</span>
            </p>
          </div>
        </motion.div>
      ),
      buttonText: "Découvrir l'espace de travail"
    },

    // SLIDE 11 - Interface finale
    {
      content: (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex flex-col items-center justify-center h-full space-y-8 px-8"
        >
          <h2 className="text-3xl font-bold text-slate-900">Vous êtes prêt !</h2>
          
          <div className="relative w-full max-w-5xl h-96 bg-white rounded-xl border-2 border-slate-200 overflow-hidden">
            {/* Interface complète simplifiée */}
            <div className="flex h-full">
              {/* Panneau gauche - Outils */}
              <div className="w-20 bg-slate-100 border-r border-slate-200 p-2">
                <div className="space-y-2">
                  {['✋', '✏️', '🧹', '💧'].map((icon, i) => (
                    <div key={i} className="w-full h-12 bg-white rounded flex items-center justify-center text-xl">
                      {icon}
                    </div>
                  ))}
                </div>
              </div>

              {/* Zone centrale - Grille */}
              <div className="flex-1 p-4 bg-slate-50">
                <div className="w-full h-full border-2 border-slate-300 rounded grid grid-cols-6 gap-1 p-2">
                  {[...Array(24)].map((_, i) => (
                    <div key={i} className="bg-white rounded flex items-center justify-center text-sm">
                      {['●', '■', '▲'][i % 3]}
                    </div>
                  ))}
                </div>
              </div>

              {/* Panneau droit */}
              <div className="w-48 bg-slate-100 border-l border-slate-200 p-2 space-y-2">
                <div className="bg-white rounded p-2 text-xs">
                  <div className="font-bold mb-1">Affichage</div>
                  <div className="space-y-1">
                    <div>☑ Visuel</div>
                    <div>☑ Symboles</div>
                    <div>☑ Grille</div>
                  </div>
                </div>
                <div className="bg-white rounded p-2 text-xs">
                  <div className="font-bold mb-1">Progression</div>
                  <div className="h-2 bg-green-600 rounded w-3/4"></div>
                  <div className="mt-1">68%</div>
                </div>
              </div>
            </div>

            {/* Palette en bas */}
            <div className="absolute bottom-0 left-0 right-0 h-16 bg-slate-800 flex items-center gap-2 px-4">
              {['#FF6B6B', '#4ECDC4', '#FFD93D', '#95E1D3', '#A8E6CF'].map((color, i) => (
                <div key={i} className="w-10 h-10 rounded" style={{ backgroundColor: color }} />
              ))}
            </div>

            {/* Annotations séquentielles */}
            <AnimatePresence mode="wait">
              {[
                { delay: 0.5, pos: 'top-4 left-24', text: 'Outils : déplacer, éditer, effacer' },
                { delay: 2, pos: 'top-1/2 left-1/2 -translate-x-1/2', text: 'Votre zone de broderie' },
                { delay: 3.5, pos: 'bottom-20 left-1/2 -translate-x-1/2', text: 'Palette DMC et symboles' },
                { delay: 5, pos: 'top-4 right-52', text: 'Affichage et progression' }
              ].map((annotation, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, scale: 0 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0 }}
                  transition={{ delay: annotation.delay, duration: 0.5 }}
                  className={`absolute ${annotation.pos} bg-yellow-400 text-slate-900 px-3 py-2 rounded-lg text-sm font-medium shadow-lg z-10 whitespace-nowrap`}
                >
                  {annotation.text}
                  <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-0 h-0 border-l-8 border-r-8 border-t-8 border-transparent border-t-yellow-400" />
                </motion.div>
              ))}
            </AnimatePresence>
          </div>

          <p className="text-lg text-slate-600 max-w-2xl text-center">
            Vous êtes prêt. Importez votre première image et laissez PATY créer votre grille.
          </p>
        </motion.div>
      ),
      buttonText: "Commencer maintenant"
    }
  ];

  const handleNext = () => {
    if (currentSlide < slides.length - 1) {
      setCurrentSlide(currentSlide + 1);
    } else {
      onComplete();
    }
  };

  const handleSkip = () => {
    onComplete();
  };

  return (
    <div className="fixed inset-0 z-50 bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Bouton fermer */}
      <button
        onClick={handleSkip}
        className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 transition-colors"
      >
        <X className="w-6 h-6" />
      </button>

      {/* Contenu du slide */}
      <div className="h-full flex flex-col">
        <div className="flex-1 overflow-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentSlide}
              initial={{ opacity: 0, x: 100 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -100 }}
              transition={{ duration: 0.5 }}
              className="h-full"
            >
              {slides[currentSlide].content}
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Navigation en bas */}
        <div className="p-8 flex items-center justify-between border-t border-slate-200 bg-white">
          {/* Indicateurs (dots) */}
          <div className="flex items-center gap-2">
            {slides.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentSlide(index)}
                className={`h-2 rounded-full transition-all ${
                  index === currentSlide 
                    ? 'w-8 bg-slate-900' 
                    : 'w-2 bg-slate-300 hover:bg-slate-400'
                }`}
              />
            ))}
          </div>

          {/* Bouton suivant */}
          <Button
            onClick={handleNext}
            size="lg"
            className="bg-slate-900 hover:bg-slate-800 text-white px-8"
          >
            {slides[currentSlide].buttonText}
            <ChevronRight className="w-5 h-5 ml-2" />
          </Button>
        </div>
      </div>
    </div>
  );
}