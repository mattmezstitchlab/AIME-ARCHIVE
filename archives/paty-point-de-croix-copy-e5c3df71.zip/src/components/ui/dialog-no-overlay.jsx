
import * as React from "react"
import * as DialogPrimitive from "@radix-ui/react-dialog"
import { X } from "lucide-react"

import { cn } from "@/lib/utils"

const DialogNoOverlay = DialogPrimitive.Root

const DialogNoOverlayTrigger = DialogPrimitive.Trigger

const DialogNoOverlayPortal = DialogPrimitive.Portal

const DialogNoOverlayClose = DialogPrimitive.Close

const DialogNoOverlayContent = React.forwardRef(({ className, children, ...props }, ref) => (
  <DialogNoOverlayPortal>
    <DialogPrimitive.Content
      ref={ref}
      className={cn(
        "grid w-full max-w-lg gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 sm:rounded-lg",
        className
      )}
      {...props}
    >
      {children}
      <DialogPrimitive.Close className="absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground z-10">
        <X className="h-4 w-4" />
        <span className="sr-only">Close</span>
      </DialogPrimitive.Close>
    </DialogPrimitive.Content>
  </DialogNoOverlayPortal>
))
DialogNoOverlayContent.displayName = DialogPrimitive.Content.displayName

const DialogNoOverlayHeader = ({
  className,
  ...props
}) => (
  <div
    className={cn(
      "flex flex-col space-y-1.5 text-center sm:text-left",
      className
    )}
    {...props}
  />
)
DialogNoOverlayHeader.displayName = "DialogNoOverlayHeader"

const DialogNoOverlayFooter = ({
  className,
  ...props
}) => (
  <div
    className={cn(
      "flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2",
      className
    )}
    {...props}
  />
)
DialogNoOverlayFooter.displayName = "DialogNoOverlayFooter"

const DialogNoOverlayTitle = React.forwardRef(({ className, ...props }, ref) => (
  <DialogPrimitive.Title
    ref={ref}
    className={cn(
      "text-lg font-semibold leading-none tracking-tight",
      className
    )}
    {...props}
  />
))
DialogNoOverlayTitle.displayName = DialogPrimitive.Title.displayName

const DialogNoOverlayDescription = React.forwardRef(({ className, ...props }, ref) => (
  <DialogPrimitive.Description
    ref={ref}
    className={cn("text-sm text-muted-foreground", className)}
    {...props}
  />
))
DialogNoOverlayDescription.displayName = DialogPrimitive.Description.displayName

export {
  DialogNoOverlay,
  DialogNoOverlayPortal,
  DialogNoOverlayClose,
  DialogNoOverlayTrigger,
  DialogNoOverlayContent,
  DialogNoOverlayHeader,
  DialogNoOverlayFooter,
  DialogNoOverlayTitle,
  DialogNoOverlayDescription,
}
