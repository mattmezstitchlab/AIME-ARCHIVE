import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Grid3x3, Sparkles, FileType, Layers, Map, Wrench, Palette, ShoppingBag, LayoutDashboard, Shield, User } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '../../utils';
import { cn } from '@/lib/utils';

// Logo PatyBee - même que dans TopMenu
function PatyBeeLogo() {
  return (
    <svg width="52" height="52" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
      <style>
        {`
          @keyframes star-anim {
            0%, 100% { fill: #FFFFFF; transform: rotate(0deg); }
            5% { fill: #F5C200; }
            20% { fill: #F5C200; transform: rotate(360deg); }
            22%, 100% { fill: #FFFFFF; transform: rotate(360deg); }
          }
          
          @keyframes diamond-anim {
            0%, 22%, 100% { fill: #FFFFFF; transform: rotate(0deg); }
            27% { fill: #2F80ED; }
            42% { fill: #2F80ED; transform: rotate(15deg); }
            44%, 100% { fill: #FFFFFF; transform: rotate(0deg); }
          }
          
          @keyframes circle-anim {
            0%, 44%, 100% { fill: #FFFFFF; opacity: 1; }
            49% { fill: #27AE60; opacity: 1; }
            55% { fill: #27AE60; opacity: 0.4; }
            61% { fill: #27AE60; opacity: 1; }
            64%, 100% { fill: #FFFFFF; opacity: 1; }
          }
          
          @keyframes square-anim {
            0%, 64%, 100% { fill: #FFFFFF; transform: rotate(0deg); }
            69% { fill: #EB5BA9; }
            79% { fill: #EB5BA9; transform: rotate(90deg); }
            84% { fill: #EB5BA9; transform: rotate(0deg); }
            86%, 100% { fill: #FFFFFF; transform: rotate(0deg); }
          }
          
          .star { 
            animation: star-anim 3.7s ease-in-out infinite;
            transform-origin: 9px 8.5px;
          }
          .circle { 
            animation: circle-anim 3.7s ease-in-out infinite;
          }
          .square { 
            animation: square-anim 3.7s ease-in-out infinite;
            transform-origin: 7.5px 26px;
          }
          .diamond { 
            animation: diamond-anim 3.7s ease-in-out infinite;
            transform-origin: 26.5px 26px;
          }
        `}
      </style>
      
      <path className="star" d="M9 2L10.5 7L15.5 8.5L10.5 10L9 15L7.5 10L2.5 8.5L7.5 7L9 2Z" fill="#FFFFFF"/>
      <circle className="circle" cx="26.5" cy="9" r="5" fill="#FFFFFF"/>
      <rect className="square" x="2.5" y="21" width="10" height="10" fill="#FFFFFF"/>
      <path className="diamond" d="M26.5 21L31.5 26L26.5 31L21.5 26L26.5 21Z" fill="#FFFFFF"/>
    </svg>
  );
}

const SLIDES = [
  {
    id: 0,
    icon: Grid3x3,
    title: 'Grille Interactive',
    content: 'Générez une grille nette avec symboles et couleurs DMC en un clic.'
  },
  {
    id: 1,
    icon: Sparkles,
    title: 'Format Personnalisé',
    content: 'De 100 à 999 cases avec repères centrés pour un rendu professionnel.'
  },
  {
    id: 2,
    icon: FileType,
    title: 'Import PDF Automatique',
    content: 'Extrait et reconstitue la mosaïque complète avec repères.'
  },
  {
    id: 3,
    icon: Layers,
    title: 'Mosaïque Intelligente',
    content: 'Formats automatiques 2×2, 4×3, 5×4… optimisés pour votre grille.'
  },
  {
    id: 4,
    icon: Map,
    title: 'Mini-carte Intuitive',
    content: 'Visualisez tout, déplacez-vous d\'un clic, repères visibles partout.'
  },
  {
    id: 5,
    icon: Wrench,
    title: 'Outils Modernes',
    content: 'Zoom, pipette, effaceur, zone du jour… tout à portée de main.'
  },
  {
    id: 6,
    icon: Palette,
    title: 'Couleurs DMC',
    content: 'Reconnaissance automatique depuis la légende de votre PDF.'
  },
  {
    id: 7,
    icon: ShoppingBag,
    title: 'Boutique PatyBee',
    content: 'Publiez, vendez et achetez des grilles en toute sécurité.'
  },
  {
    id: 8,
    icon: LayoutDashboard,
    title: 'Espace Centralisé',
    content: 'Tous vos projets, achats, ventes et réglages en un seul endroit.'
  },
  {
    id: 9,
    icon: Shield,
    title: 'Sécurité Totale',
    content: 'Innovations protégées pour le respect des créateurs.'
  },
  {
    id: 10,
    icon: User,
    title: 'Par Matt Mez Sax',
    content: 'Musicien et inventeur passionné réinventant le point de croix.',
    isCreator: true
  }
];

export default function WelcomeSlides({ open, onClose }) {
  const navigate = useNavigate();
  const [currentSlide, setCurrentSlide] = useState(0);
  const [autoplayEnabled, setAutoplayEnabled] = useState(true);
  const [lastInteraction, setLastInteraction] = useState(Date.now());

  // Autoplay logic
  useEffect(() => {
    if (!open || !autoplayEnabled) return;

    const timeSinceInteraction = Date.now() - lastInteraction;
    
    // Si interaction récente (< 8 secondes), ne pas faire d'autoplay
    if (timeSinceInteraction < 8000) {
      const resumeTimer = setTimeout(() => {
        setAutoplayEnabled(true);
      }, 8000 - timeSinceInteraction);
      return () => clearTimeout(resumeTimer);
    }

    // Autoplay après 5 secondes
    const autoplayTimer = setTimeout(() => {
      if (currentSlide < SLIDES.length - 1) {
        setCurrentSlide(prev => prev + 1);
      } else {
        setCurrentSlide(0); // Boucler au début
      }
    }, 5000);

    return () => clearTimeout(autoplayTimer);
  }, [open, currentSlide, autoplayEnabled, lastInteraction]);

  const handleInteraction = () => {
    setLastInteraction(Date.now());
    setAutoplayEnabled(false);
  };

  const handleNext = () => {
    handleInteraction();
    if (currentSlide < SLIDES.length - 1) {
      setCurrentSlide(currentSlide + 1);
    } else {
      setCurrentSlide(0);
    }
  };

  const handlePrev = () => {
    handleInteraction();
    if (currentSlide > 0) {
      setCurrentSlide(currentSlide - 1);
    }
  };

  const handleDotClick = (index) => {
    handleInteraction();
    setCurrentSlide(index);
  };

  const handleSignup = () => {
    navigate(createPageUrl('Signup'));
    onClose();
  };

  const handleLogin = () => {
    navigate(createPageUrl('Login'));
    onClose();
  };

  const handleCreatorSlide = () => {
    handleInteraction();
    setCurrentSlide(10); // Slide du créateur
  };

  const handleSkip = () => {
    sessionStorage.setItem('patybee_slides_skipped', 'true');
    onClose();
    navigate(createPageUrl('Dashboard'));
  };

  if (!open) return null;

  const slide = SLIDES[currentSlide];

  return (
    <div 
      className="fixed inset-0 z-[9999] flex flex-col"
      style={{
        backgroundColor: 'rgba(0, 0, 0, 0.90)'
      }}
      onClick={handleInteraction}
    >
      {/* Logo en haut */}
      <div className="flex flex-col items-center pt-8 mb-8">
        <PatyBeeLogo />
        <p className="text-white text-3xl font-semibold mt-3 tracking-wide">PatyBee</p>
        <p className="text-white text-xs mt-2 opacity-70 text-center px-4">
          Le logiciel de point de croix nouvelle génération.<br />
          Simple. Innovant. Révolutionnaire.
        </p>
      </div>

      {/* Contenu du slide - structure fixe */}
      <div className="flex-1 flex flex-col items-center justify-start pt-20">
        <div className="max-w-[780px] w-full px-8 text-center">

          {/* Titre et icône des slides normaux - position fixe */}
          <div className="h-[180px] flex flex-col items-center justify-center mb-6">
              {/* Icône */}
              {slide.icon && (
                <div className="flex justify-center mb-6">
                  <slide.icon className="w-16 h-16 text-white" strokeWidth={1} />
                </div>
              )}

              <h2 className="text-[32px] font-semibold tracking-tight uppercase">
                {slide.title.split(' ').map((word, idx) => {
                  const colors = ['#F5C200', '#2F80ED', '#27AE60', '#EB5BA9'];
                  return (
                    <span key={idx} style={{ color: colors[idx % colors.length] }}>
                      {word}{idx < slide.title.split(' ').length - 1 ? ' ' : ''}
                    </span>
                  );
                })}
              </h2>
              </div>

          {/* Contenu du slide - toujours 2 lignes max, position fixe */}
          {slide.content && (
            <div className="h-[100px] flex items-start justify-center mb-12">
              <p className="text-[24px] text-[#CCCCCC] font-light leading-[1.4] max-w-2xl line-clamp-2">
                {slide.content}
              </p>
            </div>
          )}

          {/* Pagination (points) - plus bas et plus grands */}
          <div className="flex justify-center gap-4 mt-24" onClick={(e) => e.stopPropagation()}>
            {SLIDES.map((_, idx) => (
              <button
                key={idx}
                onClick={() => handleDotClick(idx)}
                className={cn(
                  "w-3 h-3 rounded-full transition-all",
                  idx === currentSlide 
                    ? "bg-white w-8" 
                    : "bg-[#444444] hover:bg-[#666666]"
                )}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Bouton Passer en bas à droite */}
      <button
        onClick={handleSkip}
        className="fixed bottom-4 right-4 text-white text-sm opacity-70 hover:opacity-100 transition-opacity"
      >
        Passer
      </button>

      {/* Zone fixe en bas */}
      <div className="pb-8 space-y-4" onClick={(e) => e.stopPropagation()}>
        {/* Bouton S'inscrire principal */}
        <div className="flex justify-center">
          <Button
            onClick={handleSignup}
            className="px-[26px] py-3 text-[18px] font-semibold bg-black text-white hover:bg-[#222] border-0 rounded-lg"
          >
            S'inscrire
          </Button>
        </div>

        {/* Textes secondaires */}
        <div className="space-y-2">
          <p className="text-[13px] text-[#AAAAAA] text-center">
            Essai gratuit 3 jours
          </p>
          <div className="flex justify-center gap-6">
            <button
              onClick={handleLogin}
              className="text-[14px] text-white underline hover:text-gray-300"
            >
              Se connecter
            </button>
            <button
              onClick={handleCreatorSlide}
              className="text-[14px] text-white hover:text-gray-300"
            >
              Présentation du Créateur
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}