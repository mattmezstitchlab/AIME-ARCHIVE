import React, { useState, useRef, useEffect } from 'react';
import { X, Circle, Star, CheckSquare, Edit3, Droplet, EyeOff, Eye, GitMerge, Copy, Trash2, Lock, Unlock, Sparkles } from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { Progress } from '@/components/ui/progress';

const DEFAULT_COLORS = [
  { id: 'default-1', hex: '#FFFFFF', name: 'Blanc', code: 'DMC BLANC', assignedSymbolChar: '○', totalCount: 0, doneCount: 0, progress: 0 },
  { id: 'default-2', hex: '#000000', name: 'Noir', code: 'DMC 310', assignedSymbolChar: '●', totalCount: 0, doneCount: 0, progress: 0 },
  { id: 'default-3', hex: '#D3D3D3', name: 'Gris clair', code: 'DMC 762', assignedSymbolChar: '△', totalCount: 0, doneCount: 0, progress: 0 },
  { id: 'default-4', hex: '#808080', name: 'Gris moyen', code: 'DMC 415', assignedSymbolChar: '▽', totalCount: 0, doneCount: 0, progress: 0 },
  { id: 'default-5', hex: '#404040', name: 'Gris foncé', code: 'DMC 413', assignedSymbolChar: '◆', totalCount: 0, doneCount: 0, progress: 0 },
  { id: 'default-6', hex: '#E3242B', name: 'Rouge', code: 'DMC 666', assignedSymbolChar: '★', totalCount: 0, doneCount: 0, progress: 0 },
  { id: 'default-7', hex: '#2F80ED', name: 'Bleu', code: 'DMC 797', assignedSymbolChar: '■', totalCount: 0, doneCount: 0, progress: 0 },
  { id: 'default-8', hex: '#27AE60', name: 'Vert', code: 'DMC 702', assignedSymbolChar: '▲', totalCount: 0, doneCount: 0, progress: 0 },
  { id: 'default-9', hex: '#F5C200', name: 'Jaune', code: 'DMC 973', assignedSymbolChar: '◇', totalCount: 0, doneCount: 0, progress: 0 },
  { id: 'default-10', hex: '#8B4513', name: 'Marron', code: 'DMC 433', assignedSymbolChar: '◈', totalCount: 0, doneCount: 0, progress: 0 }
];

export default function ColorCardsBar({ 
  colorPalette = [], 
  onColorClick,
  selectedColorId,
  settings = {},
  isLocked = false,
  onToggleLock,
  onAIAnalysis,
  onUpdateSymbol,
  onUpdateColor,
  onMarkAsDone,
  onDelete,
  onMergeWith,
  onIsolateColor,
  onShowRemaining,
  onToggleVisibility
}) {
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [detailsColorId, setDetailsColorId] = useState(null);
  const [activeTools, setActiveTools] = useState({});
  const panelRef = useRef(null);
  const paletteMode = settings.colorPaletteMode || 'detailed';
  const paletteSize = settings.colorPaletteSize || 'normal';
  
  // Utiliser les couleurs par défaut si palette vide
  const displayPalette = colorPalette.length > 0 ? colorPalette : DEFAULT_COLORS;

  // Tailles des cartes selon le mode
  const cardSizes = {
    mini: { width: 40, height: 80 },
    normal: { width: 60, height: 100 },
    large: { width: 90, height: 120 }
  };

  const size = cardSizes[paletteSize] || cardSizes.normal;
  const detailsColor = detailsColorId ? colorPalette.find(c => c.id === detailsColorId) : null;

  // Fermer le panneau si clic à l'extérieur
  useEffect(() => {
    function handleClickOutside(event) {
      if (panelRef.current && !panelRef.current.contains(event.target) && 
          !event.target.closest('[data-color-card]')) {
        setDetailsOpen(false);
        setDetailsColorId(null);
      }
    }

    if (detailsOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      return () => document.removeEventListener('mousedown', handleClickOutside);
    }
  }, [detailsOpen]);

  const handleColorClick = (colorId) => {
    // Si même couleur déjà ouverte, fermer
    if (detailsOpen && detailsColorId === colorId) {
      setDetailsOpen(false);
      setDetailsColorId(null);
      onColorClick?.(null);
    } else {
      // Nouvelle couleur: ouvrir le panneau
      setDetailsOpen(true);
      setDetailsColorId(colorId);
      onColorClick?.(colorId);
    }
  };

  const handleClosePanel = () => {
    setDetailsOpen(false);
    setDetailsColorId(null);
    setActiveTools({});
    onColorClick?.(null);
  };

  const toggleTool = (colorId, toolName) => {
    const key = `${colorId}-${toolName}`;
    setActiveTools(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  const isToolActive = (colorId, toolName) => {
    return activeTools[`${colorId}-${toolName}`] || false;
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 h-[140px] bg-white border-t border-slate-200 shadow-lg z-40 flex items-center">
      {/* Scroll horizontal des couleurs */}
      <div className="flex-1 overflow-x-auto overflow-y-hidden px-4 py-4">
        <div className="flex gap-3 h-full">
          {displayPalette.map((color) => (
            <ColorCard
              key={color.id}
              color={color}
              width={size.width}
              height={size.height}
              mode={paletteMode}
              isSelected={detailsColorId === color.id}
              isLocked={isLocked}
              onClick={() => !isLocked && handleColorClick(color.id)}
            />
          ))}
        </div>
      </div>

      {/* Panneau de détails à droite (dans la même barre) */}
      {detailsOpen && detailsColor && (
        <div 
          ref={panelRef}
          className="flex-shrink-0 h-full bg-slate-50 border-l border-slate-300 shadow-xl overflow-y-auto"
          style={{ width: `${size.width * 3}px` }}
        >
          <div className="p-3 space-y-3">
            {/* Header avec couleur */}
            <div 
              className="relative rounded-lg p-3 flex flex-col gap-2"
              style={{ backgroundColor: detailsColor.hex }}
            >
              <button
                onClick={handleClosePanel}
                className="absolute top-2 right-2 p-1 hover:bg-black/10 rounded transition-colors"
              >
                <X className="w-4 h-4 text-white drop-shadow" />
              </button>
              
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-white rounded flex items-center justify-center">
                  <span className="text-lg font-bold text-slate-900">
                    {detailsColor.assignedSymbolChar || '●'}
                  </span>
                </div>
                <div className="flex-1">
                  <p className="font-semibold text-xs text-white drop-shadow truncate">
                    {detailsColor.name || `Couleur ${detailsColor.id}`}
                  </p>
                  <p className="text-[10px] text-white/90 drop-shadow truncate">
                    {detailsColor.code || 'DMC N/A'}
                  </p>
                </div>
              </div>
              <p className="text-[10px] text-white/90 drop-shadow">
                {detailsColor.totalCount || 0} points au total
              </p>
            </div>

            {/* Grille 2×3 des outils */}
            <div className="grid grid-cols-2 gap-2">
              {/* Outil 1: Isoler la couleur */}
              <button
                onClick={() => {
                  toggleTool(detailsColor.id, 'isolate');
                  onIsolateColor?.(detailsColor.id);
                  toast.info(isToolActive(detailsColor.id, 'isolate') ? 'Toutes les couleurs affichées' : 'Couleur isolée');
                }}
                className={cn(
                  "aspect-square rounded-xl flex flex-col items-center justify-center gap-1 transition-all",
                  isToolActive(detailsColor.id, 'isolate')
                    ? "bg-[#F5C200] text-slate-900"
                    : "bg-slate-900 text-white hover:bg-slate-800"
                )}
              >
                <Circle className="w-5 h-5" />
                <span className="text-[9px] font-medium">Isoler</span>
              </button>

              {/* Outil 2: Voir points restants */}
              <button
                onClick={() => {
                  toggleTool(detailsColor.id, 'remaining');
                  onShowRemaining?.(detailsColor.id);
                  toast.info(isToolActive(detailsColor.id, 'remaining') ? 'Tous les points affichés' : 'Points restants surlignés');
                }}
                className={cn(
                  "aspect-square rounded-xl flex flex-col items-center justify-center gap-1 transition-all",
                  isToolActive(detailsColor.id, 'remaining')
                    ? "bg-[#F5C200] text-slate-900"
                    : "bg-slate-900 text-white hover:bg-slate-800"
                )}
              >
                <Star className="w-5 h-5" />
                <span className="text-[9px] font-medium">Restants</span>
              </button>

              {/* Outil 3: Marquer comme brodé */}
              <button
                onClick={() => {
                  onMarkAsDone?.(detailsColor.id);
                  toast.success('Tous les points marqués comme brodés');
                }}
                className="aspect-square rounded-xl bg-slate-900 text-white hover:bg-slate-800 flex flex-col items-center justify-center gap-1 transition-all"
              >
                <CheckSquare className="w-5 h-5" />
                <span className="text-[9px] font-medium">Brodé</span>
              </button>

              {/* Outil 4: Modifier le symbole */}
              <button
                onClick={() => onUpdateSymbol?.(detailsColor)}
                className="aspect-square rounded-xl bg-slate-900 text-white hover:bg-slate-800 flex flex-col items-center justify-center gap-1 transition-all"
              >
                <Edit3 className="w-5 h-5" />
                <span className="text-[9px] font-medium">Symbole</span>
              </button>

              {/* Outil 5: Modifier la couleur DMC */}
              <button
                onClick={() => onUpdateColor?.(detailsColor)}
                className="aspect-square rounded-xl bg-slate-900 text-white hover:bg-slate-800 flex flex-col items-center justify-center gap-1 transition-all"
              >
                <Droplet className="w-5 h-5" />
                <span className="text-[9px] font-medium">Couleur</span>
              </button>

              {/* Outil 6: Masquer/Afficher la couleur */}
              <button
                onClick={() => {
                  toggleTool(detailsColor.id, 'hidden');
                  onToggleVisibility?.(detailsColor.id);
                  toast.info(isToolActive(detailsColor.id, 'hidden') ? 'Couleur affichée' : 'Couleur masquée');
                }}
                className={cn(
                  "aspect-square rounded-xl flex flex-col items-center justify-center gap-1 transition-all",
                  isToolActive(detailsColor.id, 'hidden')
                    ? "bg-[#F5C200] text-slate-900"
                    : "bg-slate-900 text-white hover:bg-slate-800"
                )}
              >
                {isToolActive(detailsColor.id, 'hidden') ? (
                  <Eye className="w-5 h-5" />
                ) : (
                  <EyeOff className="w-5 h-5" />
                )}
                <span className="text-[9px] font-medium">
                  {isToolActive(detailsColor.id, 'hidden') ? 'Afficher' : 'Masquer'}
                </span>
              </button>
            </div>

            {/* Progression */}
            <div className="pt-3 border-t border-slate-200">
              <p className="text-[10px] text-slate-600 mb-2">
                {detailsColor.doneCount || 0} / {detailsColor.totalCount || 0} brodés ({detailsColor.progress || 0}%)
              </p>
              <Progress value={detailsColor.progress || 0} className="h-2" />
            </div>

            {/* Actions avancées */}
            <div className="pt-2 space-y-1">
              <button
                onClick={() => onMergeWith?.(detailsColor)}
                className="w-full text-left text-[11px] text-slate-700 hover:text-slate-900 flex items-center gap-2 py-1"
              >
                <GitMerge className="w-3 h-3" />
                Fusionner avec une autre couleur
              </button>
              <button
                onClick={() => {
                  toast.info('Duplication à venir');
                }}
                className="w-full text-left text-[11px] text-slate-700 hover:text-slate-900 flex items-center gap-2 py-1"
              >
                <Copy className="w-3 h-3" />
                Dupliquer cette couleur
              </button>
              <button
                onClick={() => {
                  if (confirm('Supprimer cette couleur ?')) {
                    onDelete?.(detailsColor.id);
                    handleClosePanel();
                  }
                }}
                className="w-full text-left text-[11px] text-red-600 hover:text-red-700 flex items-center gap-2 py-1"
              >
                <Trash2 className="w-3 h-3" />
                Supprimer cette couleur
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Boutons de contrôle à droite */}
      {!detailsOpen && (
        <div className="flex-shrink-0 flex items-center gap-2 px-4 border-l border-slate-200">
          <button
            onClick={onToggleLock}
            className={cn(
              "p-3 rounded-lg transition-all",
              isLocked 
                ? "bg-amber-100 text-amber-700 hover:bg-amber-200" 
                : "bg-slate-100 text-slate-600 hover:bg-slate-200"
            )}
            title={isLocked ? "Déverrouiller les couleurs" : "Verrouiller les couleurs"}
          >
            {isLocked ? <Lock className="w-5 h-5" /> : <Unlock className="w-5 h-5" />}
          </button>

          <button
            onClick={onAIAnalysis}
            className="p-3 rounded-lg bg-gradient-to-r from-purple-100 to-pink-100 text-purple-700 hover:from-purple-200 hover:to-pink-200 transition-all"
            title="Analyse IA de la palette"
          >
            <Sparkles className="w-5 h-5" />
          </button>
        </div>
      )}
    </div>
  );
}

function ColorCard({ color, width, height, mode, isSelected, isLocked, onClick }) {
  const showSymbol = mode === 'detailed' || mode === 'simple';
  const showCount = mode === 'detailed';

  return (
    <button
      onClick={onClick}
      disabled={isLocked}
      data-color-card
      className={cn(
        "flex-shrink-0 rounded-lg transition-all cursor-pointer relative",
        "hover:scale-105 hover:shadow-lg",
        isSelected && "ring-4 ring-yellow-400",
        isLocked && "opacity-50 cursor-not-allowed"
      )}
      style={{ width: `${width}px`, height: `${height}px` }}
    >
      <div className="w-full h-full flex flex-col">
        {/* Symbole en haut */}
        {showSymbol && (
          <div className="flex-shrink-0 flex items-center justify-center h-8 bg-white rounded-t-lg">
            <span className="text-xl font-bold text-slate-900">
              {color.assignedSymbolChar || '●'}
            </span>
          </div>
        )}

        {/* Rectangle de couleur */}
        <div 
          className="flex-1 rounded-b-lg"
          style={{ backgroundColor: color.hex }}
        />

        {/* Nombre de points en bas */}
        {showCount && (
          <div className="absolute bottom-1 left-0 right-0 text-center">
            <span className="text-[10px] text-white bg-black/50 px-1 rounded">
              {color.totalCount || 0}
            </span>
          </div>
        )}
      </div>
    </button>
  );
}