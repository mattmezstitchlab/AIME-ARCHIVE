import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '../../utils';
import {
  Pencil, Eraser, MousePointer2,
  ZoomIn, ZoomOut, Maximize, Grid3X3, Map, Sparkles, Image, Eye,
  ChevronDown
} from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { toast } from 'sonner';
import PencilToolsDropdown from './PencilToolsDropdown';
import EraserToolsDropdown from './EraserToolsDropdown';
import SelectionToolsDropdown from './SelectionToolsDropdown';
import ZoomToolsDropdown from './ZoomToolsDropdown';
import DisplayToolsDropdown from './DisplayToolsDropdown';

const COLORS = {
  background: '#111111',
  text: '#FFFFFF',
  accent: '#FFC94A',
  accentText: '#111111',
};

export default function StitchToolbar({
  currentTool,
  onToolSelect,
  currentZoom,
  onZoomChange,
  onCenterView,
  onZoomToSelection,
  onZoomToSymbol,
  onZoomAuto,
  showGrid,
  onToggleGrid,
  showSymbols,
  onToggleSymbols,
  showImage,
  onToggleImage,
  contrastMode,
  onContrastModeChange,
  symbolSizeMode,
  onSymbolSizeModeChange,
  antiFatigueMode,
  onAntiFatigueModeChange,
  focusColorMode,
  onFocusColorModeChange,
  highlightActiveMode,
  onHighlightActiveModeChange,
  nightMode,
  onNightModeChange,
  autoCountMode,
  onAutoCountModeChange,
  onNavigateToZone,
  onOpenIA,
  hasPattern,
  onImport,
  onSave,
  onExport,
  onOpenDashboard,
  showMiniMap,
  onToggleMiniMap,
  pattern,
  activeFilter,
  onFilterByStitchType,
  onFilterByColor,
  onFilterBySymbol,
  onResetFilters,
  isolationMode,
  onToggleIsolationMode,
  // Filtres avancés
  showUnstitchedZones,
  onToggleUnstitchedZones,
  showPotentialErrors,
  onTogglePotentialErrors,
  errorSensitivity,
  onErrorSensitivityChange,
  showMissingPoints,
  onToggleMissingPoints,
  unstitchedCount,
  potentialErrorsCount,
  missingPointsCount,
  currentPencilSubTool,
  onPencilSubToolSelect,
  currentEraserSubTool,
  onEraserSubToolSelect,
  currentSelectionSubTool,
  onSelectionSubToolSelect,
}) {
  const navigate = useNavigate();
  const [pencilDropdownOpen, setPencilDropdownOpen] = useState(false);
  const [eraserDropdownOpen, setEraserDropdownOpen] = useState(false);
  const [selectionDropdownOpen, setSelectionDropdownOpen] = useState(false);
  const [zoomDropdownOpen, setZoomDropdownOpen] = useState(false);
  const [displayDropdownOpen, setDisplayDropdownOpen] = useState(false);
  const ToolIcon = ({ icon: Icon, label, active, disabled, onClick }) => (
    <Tooltip>
      <TooltipTrigger asChild>
        <button
          onClick={onClick}
          disabled={disabled}
          style={{
            width: '42px',
            height: '42px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            borderRadius: '10px',
            backgroundColor: active ? COLORS.accent : 'rgba(255,255,255,0.06)',
            color: active ? COLORS.accentText : COLORS.text,
            cursor: disabled ? 'not-allowed' : 'pointer',
            opacity: disabled ? 0.35 : 1,
            border: 'none',
            transition: 'all 0.15s',
          }}
        >
          <Icon style={{ width: '20px', height: '20px' }} />
        </button>
      </TooltipTrigger>
      <TooltipContent side="bottom"><p>{label}</p></TooltipContent>
    </Tooltip>
  );

  const ToggleBtn = ({ icon: Icon, label, active, onClick }) => (
    <Tooltip>
      <TooltipTrigger asChild>
        <button
          onClick={onClick}
          style={{
            height: '38px',
            padding: '0 14px',
            borderRadius: '10px',
            backgroundColor: active ? COLORS.accent : 'rgba(255,255,255,0.08)',
            color: active ? COLORS.accentText : COLORS.text,
            fontWeight: 600,
            fontSize: '12px',
            border: 'none',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            transition: 'all 0.15s',
          }}
        >
          <Icon style={{ width: '16px', height: '16px' }} />
          <span>{label}</span>
        </button>
      </TooltipTrigger>
      <TooltipContent><p>{active ? 'Masquer' : 'Afficher'} {label.toLowerCase()}</p></TooltipContent>
    </Tooltip>
  );

  return (
    <TooltipProvider>
      <div
        style={{
          position: 'fixed',
          top: '56px',
          left: 0,
          right: 0,
          height: '52px',
          backgroundColor: COLORS.background,
          borderBottom: '1px solid #222',
          display: 'flex',
          alignItems: 'center',
          padding: '0 20px',
          gap: '8px',
          zIndex: 95,
        }}
      >
        {/* OUTILS DE DESSIN - Crayon avec Gomme et Sélection intégrés */}
        <div style={{ display: 'flex', gap: '6px', padding: '0 8px', borderRight: '1px solid #333' }}>
          <PencilToolsDropdown
            open={pencilDropdownOpen}
            onOpenChange={setPencilDropdownOpen}
            currentSubTool={currentPencilSubTool || currentEraserSubTool || currentSelectionSubTool || 'point-magique'}
            onSelectSubTool={(subTool) => {
              onPencilSubToolSelect?.(subTool);
              onToolSelect?.('pencil');
              setPencilDropdownOpen(false);
              if (showMiniMap) onToggleMiniMap?.();
              const names = {
                'point-magique': 'Point Magique™',
                'pinceau-remplissage': 'Pinceau Remplissage™',
                'stylo-dmc': 'Stylo Couleur DMC™'
              };
              toast.success(`${names[subTool]} activé`);
            }}
            onSelectEraserTool={(subTool) => {
              onEraserSubToolSelect?.(subTool);
              onToolSelect?.('erase');
              setPencilDropdownOpen(false);
              if (showMiniMap) onToggleMiniMap?.();
              const names = {
                'gomme-selective': 'Gomme Sélective™',
                'nettoyage-zone': 'Nettoyage de Zone™',
                'anti-bavure': 'Anti-Bavure™'
              };
              toast.success(`${names[subTool]} activé`);
            }}
            onSelectSelectionTool={(subTool) => {
              onSelectionSubToolSelect?.(subTool);
              onToolSelect?.('selection-ia');
              setPencilDropdownOpen(false);
              if (showMiniMap) onToggleMiniMap?.();
              const names = {
                'selection-symbole': 'Sélection par Symbole™',
                'selection-couleur': 'Sélection par Couleur™',
                'selection-forme': 'Sélection Intelligente™'
              };
              toast.success(`${names[subTool]} activé`);
            }}
          >
            <button
              onClick={() => setPencilDropdownOpen(!pencilDropdownOpen)}
              style={{
                width: '42px',
                height: '42px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                borderRadius: '10px',
                backgroundColor: (currentTool === 'cross' || currentTool === 'pencil' || currentTool === 'erase' || currentTool === 'selection-ia') ? COLORS.accent : 'rgba(255,255,255,0.06)',
                color: (currentTool === 'cross' || currentTool === 'pencil' || currentTool === 'erase' || currentTool === 'selection-ia') ? COLORS.accentText : COLORS.text,
                cursor: 'pointer',
                border: 'none',
                transition: 'all 0.15s',
              }}
            >
              <Pencil style={{ width: '18px', height: '18px' }} />
            </button>
          </PencilToolsDropdown>
        </div>



        {/* AFFICHAGE */}
        <div style={{ display: 'flex', gap: '6px', padding: '0 8px' }}>
          {/* Bouton Affichage avec dropdown */}
          <DisplayToolsDropdown
            open={displayDropdownOpen}
            onOpenChange={setDisplayDropdownOpen}
            showGrid={showGrid}
            onToggleGrid={onToggleGrid}
            showSymbols={showSymbols}
            onToggleSymbols={onToggleSymbols}
            showImage={showImage}
            onToggleImage={onToggleImage}
            contrastMode={contrastMode}
            onContrastModeChange={onContrastModeChange}
            symbolSizeMode={symbolSizeMode}
            onSymbolSizeModeChange={onSymbolSizeModeChange}
            antiFatigueMode={antiFatigueMode}
            onAntiFatigueModeChange={onAntiFatigueModeChange}
            focusColorMode={focusColorMode}
            onFocusColorModeChange={onFocusColorModeChange}
            highlightActiveMode={highlightActiveMode}
            onHighlightActiveModeChange={onHighlightActiveModeChange}
            nightMode={nightMode}
            onNightModeChange={onNightModeChange}
            autoCountMode={autoCountMode}
            onAutoCountModeChange={onAutoCountModeChange}
            onNavigateToZone={onNavigateToZone}
                              pattern={pattern}
                              activeFilter={activeFilter}
                              onFilterByStitchType={onFilterByStitchType}
                              onFilterByColor={onFilterByColor}
                              onFilterBySymbol={onFilterBySymbol}
                              onResetFilters={onResetFilters}
                              isolationMode={isolationMode}
                                                onToggleIsolationMode={onToggleIsolationMode}
                                                showUnstitchedZones={showUnstitchedZones}
                                                onToggleUnstitchedZones={onToggleUnstitchedZones}
                                                showPotentialErrors={showPotentialErrors}
                                                onTogglePotentialErrors={onTogglePotentialErrors}
                                                errorSensitivity={errorSensitivity}
                                                onErrorSensitivityChange={onErrorSensitivityChange}
                                                showMissingPoints={showMissingPoints}
                                                onToggleMissingPoints={onToggleMissingPoints}
                                                unstitchedCount={unstitchedCount}
                                                potentialErrorsCount={potentialErrorsCount}
                                                missingPointsCount={missingPointsCount}
                                                                >
            <button
                                onClick={() => setDisplayDropdownOpen(!displayDropdownOpen)}
                                style={{
                                  width: '42px',
                                  height: '42px',
                                  display: 'flex',
                                  alignItems: 'center',
                                  justifyContent: 'center',
                                  borderRadius: '10px',
                                  backgroundColor: 'rgba(255,255,255,0.06)',
                                  color: COLORS.text,
                                  border: 'none',
                                  cursor: 'pointer',
                                  transition: 'all 0.15s',
                                }}
                              >
                                <Eye style={{ width: '18px', height: '18px' }} />
                              </button>
          </DisplayToolsDropdown>
          {/* IA PLAY */}
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                onClick={onOpenIA}
                style={{
                  width: '42px',
                  height: '42px',
                  borderRadius: '10px',
                  backgroundColor: '#111',
                  border: '2px solid #FFC94A',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <span style={{ color: '#fff', fontWeight: 700, fontSize: '14px' }}>IA</span>
              </button>
            </TooltipTrigger>
            <TooltipContent><p>Assistant IA PatyBee</p></TooltipContent>
          </Tooltip>
          </div>



      </div>
    </TooltipProvider>
  );
}