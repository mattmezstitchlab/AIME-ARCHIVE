import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { FileText, Image as ImageIcon, Grid3x3, CheckSquare, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

export default function ImportPdfConfigDialog({ 
  open, 
  onClose, 
  preloadedFile,
  onExtractCover,
  onMosaicMode,
  onManualSelection
}) {
  const [pdfInfo, setPdfInfo] = useState({ pageCount: 0 });
  const [mode, setMode] = useState('cover');
  const [isProcessing, setIsProcessing] = useState(false);
  
  // Mode mosaïque
  const [pageRange, setPageRange] = useState('2-13');
  const [gridWidth, setGridWidth] = useState(4);
  const [gridHeight, setGridHeight] = useState(3);
  const [autoAlign, setAutoAlign] = useState(true);
  const [correctOffsets, setCorrectOffsets] = useState(true);
  
  // Mode sélection manuelle
  const [selectedPages, setSelectedPages] = useState([]);
  const [maintainOrder, setMaintainOrder] = useState(true);
  
  // Paramètres de sortie
  const [maxGridSize, setMaxGridSize] = useState(300);
  const [paletteMode, setPaletteMode] = useState('dmc');

  const fileInputRef = React.useRef(null);

  // Analyser le PDF au chargement
  useEffect(() => {
    if (preloadedFile && open) {
      analyzePdf(preloadedFile);
    }
  }, [preloadedFile, open]);

  const analyzePdf = async (file) => {
    try {
      if (!window.pdfjsLib) {
        toast.error('Module PDF en cours de chargement...');
        return;
      }

      const arrayBuffer = await file.arrayBuffer();
      const pdf = await window.pdfjsLib.getDocument({ data: arrayBuffer }).promise;
      
      setPdfInfo({
        pageCount: pdf.numPages
      });

      // Initialiser la sélection manuelle avec toutes les pages
      setSelectedPages(Array.from({ length: pdf.numPages }, (_, i) => i + 1));
    } catch (error) {
      console.error('Erreur analyse PDF:', error);
      toast.error('Impossible d\'analyser le PDF');
    }
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file && file.type === 'application/pdf') {
      analyzePdf(file);
    } else {
      toast.error('Veuillez sélectionner un fichier PDF');
    }
    e.target.value = '';
  };

  const formatFileSize = (bytes) => {
    if (!bytes) return '0 B';
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  const parsePageRange = (range) => {
    const pages = [];
    const parts = range.split(',');
    
    for (const part of parts) {
      if (part.includes('-')) {
        const [start, end] = part.split('-').map(n => parseInt(n.trim()));
        for (let i = start; i <= end; i++) {
          if (i >= 1 && i <= pdfInfo.pageCount) {
            pages.push(i);
          }
        }
      } else {
        const page = parseInt(part.trim());
        if (page >= 1 && page <= pdfInfo.pageCount) {
          pages.push(page);
        }
      }
    }
    
    return [...new Set(pages)].sort((a, b) => a - b);
  };

  const handleGenerate = async () => {
    if (!preloadedFile) {
      toast.error('Aucun fichier sélectionné');
      return;
    }

    if (mode === 'cover') {
      // Mode couverture - extraire la page 1 et ouvrir le dialogue image
      onExtractCover(preloadedFile);
      onClose();
    } else if (mode === 'mosaic') {
      // Mode mosaïque
      const pages = parsePageRange(pageRange);
      
      if (pages.length === 0) {
        toast.error('Plage de pages invalide');
        return;
      }

      if (pages.length !== gridWidth * gridHeight) {
        toast.warning(`Vous avez ${pages.length} pages mais une grille ${gridWidth}×${gridHeight} = ${gridWidth * gridHeight} cases`);
      }

      onMosaicMode({
        file: preloadedFile,
        pages,
        gridWidth,
        gridHeight,
        autoAlign,
        correctOffsets,
        maxGridSize,
        paletteMode
      });
      onClose();
    } else if (mode === 'manual') {
      // Mode sélection manuelle
      if (selectedPages.length === 0) {
        toast.error('Veuillez sélectionner au moins une page');
        return;
      }

      onManualSelection({
        file: preloadedFile,
        pages: selectedPages,
        maintainOrder,
        maxGridSize,
        paletteMode
      });
      onClose();
    }
  };

  const togglePage = (pageNum) => {
    setSelectedPages(prev => 
      prev.includes(pageNum) 
        ? prev.filter(p => p !== pageNum)
        : [...prev, pageNum].sort((a, b) => a - b)
    );
  };

  const selectAllPages = () => {
    setSelectedPages(Array.from({ length: pdfInfo.pageCount }, (_, i) => i + 1));
  };

  const deselectAllPages = () => {
    setSelectedPages([]);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Configurer votre PDF de grilles</DialogTitle>
          <DialogDescription>
            PatyBee a détecté un fichier PDF. Choisissez comment l'utiliser pour générer votre grille de broderie.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Section 1 - Fichier sélectionné */}
          {preloadedFile && (
            <div className="border border-slate-200 rounded-lg p-4 bg-slate-50">
              <div className="flex items-center justify-between">
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-slate-700 mb-1">Fichier sélectionné :</div>
                  <div className="space-y-1">
                    <div className="flex items-center gap-3">
                      <div className="font-semibold text-slate-900 truncate">{preloadedFile.name}</div>
                      <div className="text-sm text-slate-600">({formatFileSize(preloadedFile.size)})</div>
                    </div>
                    <div className="text-sm text-slate-600">
                      Nombre de pages détectées : <span className="font-semibold">{pdfInfo.pageCount}</span>
                    </div>
                  </div>
                </div>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="application/pdf"
                  onChange={handleFileChange}
                  className="hidden"
                />
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => fileInputRef.current?.click()}
                  className="text-slate-600 hover:text-slate-900"
                >
                  Changer de fichier…
                </Button>
              </div>
            </div>
          )}

          {/* Section 2 - Mode d'utilisation */}
          <div>
            <Label className="text-sm font-medium text-slate-900 mb-3 block">Mode d'utilisation du PDF</Label>
            
            <RadioGroup value={mode} onValueChange={setMode}>
              <div className="space-y-3">
                {/* Mode 1 - Couverture */}
                <div className="flex items-start gap-3 p-4 border-2 border-slate-200 rounded-lg hover:border-slate-300 cursor-pointer">
                  <RadioGroupItem value="cover" id="cover" className="mt-1" />
                  <label htmlFor="cover" className="flex-1 cursor-pointer">
                    <div className="flex items-center gap-2 mb-1">
                      <ImageIcon className="w-4 h-4 text-slate-600" />
                      <div className="font-semibold text-slate-900">Utiliser la couverture (visuel uniquement)</div>
                    </div>
                    <div className="text-sm text-slate-600">
                      PatyBee extrait la première page (souvent la photo du motif) pour générer une grille à partir de l'image.
                    </div>
                  </label>
                </div>

                {/* Mode 2 - Mosaïque */}
                <div className="flex items-start gap-3 p-4 border-2 border-slate-200 rounded-lg hover:border-slate-300 cursor-pointer">
                  <RadioGroupItem value="mosaic" id="mosaic" className="mt-1" />
                  <label htmlFor="mosaic" className="flex-1 cursor-pointer">
                    <div className="flex items-center gap-2 mb-1">
                      <Grid3x3 className="w-4 h-4 text-slate-600" />
                      <div className="font-semibold text-slate-900">Reconstruire la grille complète (mosaïque de pages)</div>
                    </div>
                    <div className="text-sm text-slate-600">
                      PatyBee utilise les pages de grilles du PDF pour reconstruire une seule grande grille complète.
                    </div>
                  </label>
                </div>

                {/* Mode 3 - Sélection manuelle */}
                <div className="flex items-start gap-3 p-4 border-2 border-slate-200 rounded-lg hover:border-slate-300 cursor-pointer">
                  <RadioGroupItem value="manual" id="manual" className="mt-1" />
                  <label htmlFor="manual" className="flex-1 cursor-pointer">
                    <div className="flex items-center gap-2 mb-1">
                      <CheckSquare className="w-4 h-4 text-slate-600" />
                      <div className="font-semibold text-slate-900">Sélectionner manuellement une ou plusieurs pages</div>
                    </div>
                    <div className="text-sm text-slate-600">
                      Choisis précisément les pages à inclure (utile si le PDF contient plusieurs motifs ou des pages inutiles).
                    </div>
                  </label>
                </div>
              </div>
            </RadioGroup>
          </div>

          {/* Section 3 - Options mosaïque */}
          {mode === 'mosaic' && (
            <div className="border border-indigo-200 rounded-lg p-4 bg-indigo-50 space-y-4">
              <h3 className="font-semibold text-slate-900">Configuration de la mosaïque de grilles</h3>
              
              <div>
                <Label htmlFor="pageRange" className="text-sm font-medium mb-2 block">
                  Pages de grilles
                </Label>
                <Input
                  id="pageRange"
                  value={pageRange}
                  onChange={(e) => setPageRange(e.target.value)}
                  placeholder="2-13"
                />
                <p className="text-xs text-slate-600 mt-1">
                  Indique les pages contenant les grilles (ex : 2-13 ou 2,3,6-9)
                </p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="gridWidth" className="text-sm font-medium mb-2 block">
                    Grilles en largeur
                  </Label>
                  <Input
                    id="gridWidth"
                    type="number"
                    min={1}
                    max={10}
                    value={gridWidth}
                    onChange={(e) => setGridWidth(parseInt(e.target.value) || 1)}
                  />
                </div>
                <div>
                  <Label htmlFor="gridHeight" className="text-sm font-medium mb-2 block">
                    Grilles en hauteur
                  </Label>
                  <Input
                    id="gridHeight"
                    type="number"
                    min={1}
                    max={10}
                    value={gridHeight}
                    onChange={(e) => setGridHeight(parseInt(e.target.value) || 1)}
                  />
                </div>
              </div>
              <p className="text-xs text-slate-600">
                Ex : {gridWidth} grilles en largeur × {gridHeight} en hauteur = {gridWidth * gridHeight} pages de grilles.
              </p>

              <div className="space-y-2">
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={autoAlign}
                    onChange={(e) => setAutoAlign(e.target.checked)}
                    className="rounded border-slate-300"
                  />
                  <span className="text-sm text-slate-700">Alignement automatique des repères</span>
                </label>

                <label className="flex items-center gap-2 pl-6">
                  <input
                    type="checkbox"
                    checked={correctOffsets}
                    onChange={(e) => setCorrectOffsets(e.target.checked)}
                    className="rounded border-slate-300"
                    disabled={!autoAlign}
                  />
                  <span className="text-sm text-slate-600">Corriger les décalages de quelques pixels entre les pages</span>
                </label>
              </div>

              {/* Aperçu schématique */}
              <div className="border border-slate-300 rounded-lg p-3 bg-white">
                <div className="text-xs font-medium text-slate-700 mb-2">Aperçu de la disposition :</div>
                <div 
                  className="grid gap-1"
                  style={{
                    gridTemplateColumns: `repeat(${gridWidth}, 1fr)`,
                    gridTemplateRows: `repeat(${gridHeight}, 1fr)`
                  }}
                >
                  {Array.from({ length: gridWidth * gridHeight }).map((_, i) => (
                    <div
                      key={i}
                      className="aspect-square border border-slate-300 rounded flex items-center justify-center text-xs text-slate-500 bg-slate-50"
                    >
                      {i + 1}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Section 4 - Sélection manuelle */}
          {mode === 'manual' && (
            <div className="border border-purple-200 rounded-lg p-4 bg-purple-50 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-slate-900">Pages disponibles</h3>
                <div className="flex gap-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={selectAllPages}
                  >
                    Tout sélectionner
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={deselectAllPages}
                  >
                    Tout désélectionner
                  </Button>
                </div>
              </div>

              <div className="max-h-64 overflow-y-auto border border-purple-200 rounded-lg bg-white p-2">
                <div className="grid grid-cols-4 gap-2">
                  {Array.from({ length: pdfInfo.pageCount }).map((_, i) => {
                    const pageNum = i + 1;
                    const isSelected = selectedPages.includes(pageNum);
                    
                    return (
                      <label
                        key={pageNum}
                        className={`flex items-center gap-2 p-2 border rounded cursor-pointer transition-colors ${
                          isSelected ? 'border-purple-500 bg-purple-50' : 'border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => togglePage(pageNum)}
                          className="rounded border-slate-300"
                        />
                        <div className="flex items-center gap-1">
                          <FileText className="w-3 h-3 text-slate-500" />
                          <span className="text-sm font-medium">Page {pageNum}</span>
                        </div>
                      </label>
                    );
                  })}
                </div>
              </div>

              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={maintainOrder}
                  onChange={(e) => setMaintainOrder(e.target.checked)}
                  className="rounded border-slate-300"
                />
                <span className="text-sm text-slate-700">Maintenir l'ordre des pages lors de l'assemblage</span>
              </label>
            </div>
          )}

          {/* Section 5 - Paramètres de sortie */}
          <div className="border-t border-slate-200 pt-4 space-y-4">
            <h3 className="font-semibold text-slate-900">Paramètres de sortie</h3>
            
            <div>
              <Label htmlFor="maxGridSize" className="text-sm font-medium mb-2 block">
                Taille maximale de la grande grille
              </Label>
              <Input
                id="maxGridSize"
                type="number"
                min={100}
                max={1000}
                value={maxGridSize}
                onChange={(e) => setMaxGridSize(parseInt(e.target.value) || 300)}
              />
              <p className="text-xs text-slate-600 mt-1">
                Pour les mosaïques, cette taille est répartie sur l'ensemble des pages assemblées.
              </p>
            </div>

            <div>
              <Label htmlFor="paletteMode" className="text-sm font-medium mb-2 block">
                Palette de fils
              </Label>
              <select
                id="paletteMode"
                value={paletteMode}
                onChange={(e) => setPaletteMode(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900"
              >
                <option value="dmc">Convertir automatiquement vers DMC (recommandé)</option>
                <option value="preserve">Conserver les symboles et couleurs du PDF</option>
              </select>
            </div>
          </div>
        </div>

        {/* Boutons d'action */}
        <DialogFooter className="gap-2">
          <Button
            variant="outline"
            onClick={onClose}
            disabled={isProcessing}
          >
            Annuler
          </Button>
          <Button
            onClick={handleGenerate}
            disabled={isProcessing || !preloadedFile}
            className="bg-indigo-600 hover:bg-indigo-700 text-white px-6"
          >
            {isProcessing ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Traitement...
              </>
            ) : (
              'Générer la grille'
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}