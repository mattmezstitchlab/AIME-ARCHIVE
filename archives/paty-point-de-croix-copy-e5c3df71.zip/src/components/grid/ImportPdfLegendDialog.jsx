import React, { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Upload, FileText, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

export default function ImportPdfLegendDialog({ open, onClose, onLegendImported }) {
  const [pdfFile, setPdfFile] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const handleFileSelect = (e) => {
    const file = e.target.files?.[0];
    if (file && file.type === 'application/pdf') {
      setPdfFile(file);
    }
  };

  const handleExtractLegend = async () => {
    if (!pdfFile) return;

    setIsProcessing(true);
    try {
      // Upload PDF
      const formData = new FormData();
      formData.append('file', pdfFile);
      const { file_url } = await base44.integrations.Core.UploadFile({ file: pdfFile });

      // Extract legend using AI
      const prompt = `Analyse ce PDF de broderie point de croix et extrait UNIQUEMENT la légende des symboles.
      
Pour chaque symbole trouvé, retourne :
- Le caractère du symbole (●, ■, ▲, etc.)
- Le code DMC (exemple: "310", "666", "B5200")
- Le nom de la couleur (exemple: "Noir", "Rouge vif")
- La couleur hex approximative (exemple: "#000000", "#E51837")

Retourne un tableau JSON avec cette structure exacte :
{
  "symbols": [
    { "symbol": "●", "dmc": "310", "name": "Noir", "hex": "#000000" }
  ]
}

IMPORTANT: Ne retourne QUE les symboles présents dans la légende du PDF.`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt,
        file_urls: [file_url],
        response_json_schema: {
          type: 'object',
          properties: {
            symbols: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  symbol: { type: 'string' },
                  dmc: { type: 'string' },
                  name: { type: 'string' },
                  hex: { type: 'string' }
                }
              }
            }
          }
        }
      });

      if (response.symbols && response.symbols.length > 0) {
        onLegendImported(response.symbols);
        toast.success(`${response.symbols.length} symboles importés depuis la légende`);
        setPdfFile(null);
        onClose();
      } else {
        toast.error('Aucun symbole trouvé dans la légende');
      }
    } catch (error) {
      console.error('Erreur extraction légende:', error);
      toast.error('Erreur lors de l\'extraction de la légende');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Importer une légende PDF</DialogTitle>
          <DialogDescription>
            Extrayez les symboles et couleurs DMC depuis un PDF de broderie
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {!pdfFile ? (
            <label className="flex flex-col items-center justify-center w-full h-48 border-2 border-dashed border-slate-300 rounded-xl cursor-pointer hover:bg-slate-50 transition-colors">
              <div className="flex flex-col items-center justify-center pt-5 pb-6">
                <Upload className="w-12 h-12 text-slate-400 mb-3" />
                <p className="mb-2 text-sm text-slate-600">
                  <span className="font-semibold">Cliquez pour choisir</span> ou glissez un PDF
                </p>
                <p className="text-xs text-slate-500">PDF de grille de broderie</p>
              </div>
              <input
                type="file"
                className="hidden"
                accept=".pdf"
                onChange={handleFileSelect}
              />
            </label>
          ) : (
            <div className="flex items-center gap-3 p-4 bg-slate-50 rounded-lg">
              <FileText className="w-10 h-10 text-slate-600" />
              <div className="flex-1">
                <p className="font-medium text-sm">{pdfFile.name}</p>
                <p className="text-xs text-slate-500">{(pdfFile.size / 1024 / 1024).toFixed(2)} Mo</p>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setPdfFile(null)}
                disabled={isProcessing}
              >
                Changer
              </Button>
            </div>
          )}

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
            <p className="text-xs text-blue-900">
              💡 <strong>Astuce :</strong> Cette fonction extrait uniquement les pages de légende 
              (symboles + codes DMC) pour enrichir votre palette sans recréer la grille.
            </p>
          </div>
        </div>

        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={onClose} disabled={isProcessing}>
            Annuler
          </Button>
          <Button 
            onClick={handleExtractLegend} 
            disabled={!pdfFile || isProcessing}
            className="bg-black hover:bg-slate-800"
          >
            {isProcessing ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Extraction en cours...
              </>
            ) : (
              'Extraire la légende'
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}