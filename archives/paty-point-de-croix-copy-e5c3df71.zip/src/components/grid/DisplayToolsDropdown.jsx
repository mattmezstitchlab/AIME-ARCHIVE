import React, { useState } from 'react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuSub,
  DropdownMenuSubTrigger,
  DropdownMenuSubContent,
} from '@/components/ui/dropdown-menu';
import { Eye, Grid3X3, Image, Sparkles, Moon, Target, Palette, Hash, Navigation, Filter, RotateCcw, Crosshair, AlertTriangle, GitCompare, Square, ChevronDown, Layers, ScanLine, Zap, Type } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

const STITCH_TYPES = [
  { id: 'full', label: 'Point complet', icon: '✕' },
  { id: 'half', label: 'Demi-point', icon: '/' },
  { id: 'quarter', label: 'Quart de point', icon: '·' },
  { id: 'three-quarter', label: 'Trois-quarts', icon: '⌐' },
  { id: 'backstitch', label: 'Backstitch', icon: '—' },
  { id: 'knot', label: 'Nœud français', icon: '●' },
  { id: 'special', label: 'Spécial', icon: '★' },
];

export default function DisplayToolsDropdown({ 
  children,
  showGrid,
  onToggleGrid,
  showSymbols,
  onToggleSymbols,
  showImage,
  onToggleImage,
  contrastMode = false,
  onContrastModeChange,
  symbolSizeMode = 'normal', // 'normal', 'mini', 'comfort', 'mega'
  onSymbolSizeModeChange,
  antiFatigueMode = false,
  onAntiFatigueModeChange,
  focusColorMode = false,
  onFocusColorModeChange,
  highlightActiveMode = false,
  onHighlightActiveModeChange,
  nightMode = false,
  onNightModeChange,
  autoCountMode = false,
  onAutoCountModeChange,
  onNavigateToZone,
  open,
  onOpenChange,
  // Filtres intelligents
  pattern,
  activeFilter,
  onFilterByStitchType,
  onFilterByColor,
  onFilterBySymbol,
  onResetFilters,
  isolationMode = false,
  onToggleIsolationMode,
  // Filtres avancés
  showUnstitchedZones = false,
  onToggleUnstitchedZones,
  showPotentialErrors = false,
  onTogglePotentialErrors,
  errorSensitivity = 'medium',
  onErrorSensitivityChange,
  showMissingPoints = false,
  onToggleMissingPoints,
  missingPointsCount = 0,
  potentialErrorsCount = 0,
  unstitchedCount = 0,
}) {
  const [gpsInput, setGpsInput] = useState('');
  
  // États des catégories ouvertes
  const [openCategory, setOpenCategory] = useState(null);
  
  const toggleCategory = (category) => {
    setOpenCategory(openCategory === category ? null : category);
  };

  // Vérifier si un filtre avancé est actif
  const hasAdvancedFilter = showUnstitchedZones || showPotentialErrors || showMissingPoints;

  const hasActiveFilter = activeFilter?.type;
  const hasAnyFilter = hasActiveFilter || hasAdvancedFilter;

  // Composant Catégorie cliquable
  const CategoryHeader = ({ id, icon: Icon, label, color, children, badge }) => {
    const isOpen = openCategory === id;
    return (
      <div className="mx-2 mb-1">
        <button
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
            toggleCategory(id);
          }}
          className={`w-full px-3 py-2.5 rounded-lg flex items-center justify-between transition-all ${
            isOpen ? 'bg-white/10' : 'hover:bg-white/5'
          }`}
        >
          <div className="flex items-center gap-2">
            <Icon className="w-4 h-4" style={{ color: color || '#FFC94A' }} />
            <span className="text-sm font-medium text-white">{label}</span>
            {badge && (
              <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-white/10 text-gray-400">{badge}</span>
            )}
          </div>
          <ChevronDown 
            className={`w-4 h-4 text-gray-500 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} 
          />
        </button>
        {isOpen && (
          <div className="mt-1 ml-2 pl-4 border-l border-[#333] space-y-0.5">
            {children}
          </div>
        )}
      </div>
    );
  };

  const ToggleItem = ({ label, active, onClick, icon: Icon, color, description, compact }) => (
    <button
      onClick={(e) => {
        e.preventDefault();
        e.stopPropagation();
        onClick?.();
      }}
      className={`w-full px-3 ${compact ? 'py-1.5' : 'py-2'} rounded-lg cursor-pointer hover:bg-white/5 transition-all duration-150 text-left`}
    >
      <div className="flex items-center justify-between w-full">
        <div className="flex items-center gap-2">
          {Icon && <Icon className={`w-4 h-4 transition-all duration-200 ${active ? 'scale-110' : ''}`} style={{ color: active ? (color || '#FFC94A') : '#888' }} />}
          <div>
            <span className={`text-sm transition-colors duration-150 ${active ? 'text-white font-medium' : 'text-gray-300'}`}>{label}</span>
            {description && !compact && <p className="text-[#666] text-[10px]">{description}</p>}
          </div>
        </div>
        <div 
          className={`w-9 h-5 rounded-full transition-all duration-200 flex items-center px-0.5 ${
            active ? 'bg-[#FFC94A]' : 'bg-[#333]'
          }`}
          style={{ boxShadow: active ? '0 0 8px rgba(255, 201, 74, 0.4)' : 'none' }}
        >
          <div 
            className={`w-4 h-4 rounded-full bg-white shadow-md transition-all duration-200 ${
              active ? 'translate-x-4' : 'translate-x-0'
            }`}
          />
        </div>
      </div>
    </button>
  );

  return (
    <DropdownMenu open={open} onOpenChange={onOpenChange}>
      <DropdownMenuTrigger asChild>
        {children}
      </DropdownMenuTrigger>
      <DropdownMenuContent 
        side="bottom" 
        align="start" 
        className="w-72 p-0 bg-[#1a1a1a] border-[#333] rounded-xl overflow-hidden max-h-[70vh] overflow-y-auto"
        sideOffset={8}
        collisionPadding={16}
      >
        {/* Header */}
        <div className="px-4 py-2.5 bg-gradient-to-r from-[#FFC94A]/20 to-transparent border-b border-[#333]">
          <div className="flex items-center gap-2">
            <Eye className="w-4 h-4 text-[#FFC94A]" />
            <span className="text-white font-semibold text-sm">Affichage</span>
          </div>
        </div>

        <div className="py-2">
          {/* CATÉGORIE 1: Éléments visuels */}
          <CategoryHeader id="visual" icon={Layers} label="Éléments visuels" color="#FFC94A">
            <ToggleItem label="Grille" active={showGrid} onClick={onToggleGrid} icon={Grid3X3} compact />
            <ToggleItem label="Symboles" active={showSymbols} onClick={onToggleSymbols} icon={Sparkles} compact />
            <ToggleItem label="Visuel" active={showImage} onClick={onToggleImage} icon={Image} compact />
            <ToggleItem label="Contraste fort" active={contrastMode} onClick={onContrastModeChange} icon={Eye} color="#10B981" compact />
            
            {/* Tailles de symboles */}
            <div className="px-2 py-1.5 mt-1">
              <div className="flex items-center gap-1.5 mb-2">
                <Type className="w-3.5 h-3.5 text-[#EC4899]" />
                <span className="text-xs text-gray-400">Taille des symboles</span>
              </div>
              <div className="flex flex-col gap-1">
                <button
                  onClick={(e) => { e.stopPropagation(); onSymbolSizeModeChange?.('mini'); }}
                  className={`w-full px-2 py-1.5 rounded-lg text-xs text-left flex items-center justify-between transition-all ${
                    symbolSizeMode === 'mini' ? 'bg-[#EC4899]/20 text-[#EC4899]' : 'hover:bg-white/5 text-gray-300'
                  }`}
                >
                  <span>MiniStitch™</span>
                  <span className="text-[10px] text-gray-500">+25%</span>
                </button>
                <button
                  onClick={(e) => { e.stopPropagation(); onSymbolSizeModeChange?.('comfort'); }}
                  className={`w-full px-2 py-1.5 rounded-lg text-xs text-left flex items-center justify-between transition-all ${
                    symbolSizeMode === 'comfort' ? 'bg-[#EC4899]/20 text-[#EC4899]' : 'hover:bg-white/5 text-gray-300'
                  }`}
                >
                  <span>ComfortStitch™</span>
                  <span className="text-[10px] text-gray-500">+75%</span>
                </button>
                <button
                  onClick={(e) => { e.stopPropagation(); onSymbolSizeModeChange?.('mega'); }}
                  className={`w-full px-2 py-1.5 rounded-lg text-xs text-left flex items-center justify-between transition-all ${
                    symbolSizeMode === 'mega' ? 'bg-[#EC4899]/20 text-[#EC4899]' : 'hover:bg-white/5 text-gray-300'
                  }`}
                >
                  <span>MegaStitch™</span>
                  <span className="text-[10px] text-gray-500">+150%</span>
                </button>
                {symbolSizeMode !== 'normal' && (
                  <button
                    onClick={(e) => { e.stopPropagation(); onSymbolSizeModeChange?.('normal'); }}
                    className="w-full px-2 py-1.5 rounded-lg text-xs text-left flex items-center gap-1.5 hover:bg-white/5 text-gray-400 mt-1 border-t border-[#333] pt-2"
                  >
                    <RotateCcw className="w-3 h-3" />
                    Réinitialiser taille
                  </button>
                )}
              </div>
            </div>
          </CategoryHeader>

          {/* CATÉGORIE 2: Navigation */}
          <CategoryHeader id="navigation" icon={Navigation} label="Navigation GPS" color="#3B82F6">
            <div className="px-2 py-2">
              <div className="flex items-center gap-2" style={{ minWidth: '200px' }}>
                <input
                  type="text"
                  value={gpsInput}
                  onChange={(e) => {
                    // Nettoyer et formater: supprimer espaces, convertir en majuscule
                    const cleaned = e.target.value.replace(/\s/g, '').toUpperCase();
                    // Autoriser uniquement: 1 lettre A-Z suivie de 0-3 chiffres
                    const match = cleaned.match(/^([A-Z]?)(\d{0,3})$/);
                    if (match || cleaned === '') {
                      setGpsInput(cleaned);
                    }
                  }}
                  placeholder="Ex: D8"
                  className="w-24 h-8 px-3 bg-[#222] border border-[#444] rounded-md text-white text-sm placeholder:text-gray-500 focus:outline-none focus:border-[#3B82F6] focus:ring-1 focus:ring-[#3B82F6]"
                  maxLength={4}
                  autoComplete="off"
                  autoCorrect="off"
                  autoCapitalize="characters"
                  spellCheck="false"
                  onKeyDown={(e) => {
                    e.stopPropagation();
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      if (gpsInput && /^[A-Z]\d+$/.test(gpsInput)) {
                        onNavigateToZone?.(gpsInput);
                      }
                    }
                  }}
                  onClick={(e) => e.stopPropagation()}
                  onFocus={(e) => e.stopPropagation()}
                  onMouseDown={(e) => e.stopPropagation()}
                />
                <Button
                  size="sm"
                  className="h-8 px-4 bg-[#3B82F6] hover:bg-[#2563EB] text-white font-semibold shrink-0"
                  onClick={(e) => {
                    e.stopPropagation();
                    e.preventDefault();
                    if (gpsInput && /^[A-Z]\d+$/.test(gpsInput)) {
                      onNavigateToZone?.(gpsInput);
                    }
                  }}
                >
                  GO
                </Button>
              </div>
              <p className="text-[#666] text-[10px] mt-1.5">Lettre + Chiffre (ex: D8, L24)</p>
            </div>
          </CategoryHeader>

          {/* CATÉGORIE 3: Filtres par type de point */}
          <CategoryHeader 
            id="filters" 
            icon={Filter} 
            label="Filtrer par type" 
            color="#EC4899"
            badge={activeFilter?.type === 'stitch' ? '1' : null}
          >
            {/* Indicateur de filtre actif */}
            {activeFilter?.type === 'stitch' && (
              <div className="px-2 py-1.5 mb-1 rounded-lg bg-[#FFC94A]/20 border border-[#FFC94A]/40">
                <div className="flex items-center justify-between">
                  <span className="text-[#FFC94A] text-xs font-medium">
                    Type: {STITCH_TYPES.find(s => s.id === activeFilter.value)?.label}
                  </span>
                  <button
                    onClick={(e) => { e.stopPropagation(); onResetFilters?.(); }}
                    className="text-[10px] text-[#FFC94A] hover:text-white"
                  >
                    <RotateCcw className="w-3 h-3" />
                  </button>
                </div>
              </div>
            )}

            {/* Liste des types de points */}
            {STITCH_TYPES.map(stitch => (
              <button
                key={stitch.id}
                onClick={(e) => { e.stopPropagation(); onFilterByStitchType?.(stitch.id); }}
                className={`w-full px-2 py-1.5 rounded-lg cursor-pointer text-xs text-left flex items-center gap-2 ${
                  activeFilter?.type === 'stitch' && activeFilter?.value === stitch.id
                    ? 'bg-[#EC4899]/20 text-[#EC4899]'
                    : 'hover:bg-white/5 text-gray-300'
                }`}
              >
                <span className="w-5 text-center">{stitch.icon}</span>
                {stitch.label}
              </button>
            ))}

            {/* Mode Isolation */}
            {activeFilter?.type === 'stitch' && (
              <ToggleItem 
                label="Mode Isolation" 
                active={isolationMode} 
                onClick={onToggleIsolationMode}
                icon={Eye}
                color="#F59E0B"
                compact
              />
            )}

            {/* Note: couleurs accessibles depuis la palette */}
            <div className="px-2 py-2 mt-1 border-t border-[#333]">
              <p className="text-[#666] text-[10px] italic">💡 Filtrer par couleur : utilisez la palette DMC en bas</p>
            </div>
          </CategoryHeader>

          {/* CATÉGORIE 4: Analyse avancée */}
          <CategoryHeader 
            id="analysis" 
            icon={ScanLine} 
            label="Analyse avancée" 
            color="#06B6D4"
            badge={hasAdvancedFilter ? '•' : null}
          >
            <ToggleItem 
              label="Zones non brodées" 
              active={showUnstitchedZones} 
              onClick={onToggleUnstitchedZones}
              icon={Square}
              color="#06B6D4"
              compact
            />
            {showUnstitchedZones && unstitchedCount > 0 && (
              <div className="px-2 py-1 text-[10px] text-[#06B6D4]">{unstitchedCount} cases vides</div>
            )}

            <ToggleItem 
              label="Erreurs potentielles" 
              active={showPotentialErrors} 
              onClick={onTogglePotentialErrors}
              icon={AlertTriangle}
              color="#EF4444"
              compact
            />
            {showPotentialErrors && (
              <div className="px-2 py-1.5">
                <div className="flex gap-1">
                  {['low', 'medium', 'high'].map(level => (
                    <button
                      key={level}
                      onClick={(e) => { e.stopPropagation(); onErrorSensitivityChange?.(level); }}
                      className={`flex-1 px-1.5 py-0.5 rounded text-[9px] font-medium ${
                        errorSensitivity === level ? 'bg-[#EF4444] text-white' : 'bg-[#222] text-[#888]'
                      }`}
                    >
                      {level === 'low' ? 'Faible' : level === 'medium' ? 'Moyen' : 'Fort'}
                    </button>
                  ))}
                </div>
                {potentialErrorsCount > 0 && (
                  <div className="text-[10px] text-[#EF4444] mt-1">{potentialErrorsCount} erreurs</div>
                )}
              </div>
            )}

            <ToggleItem 
              label="Points manquants" 
              active={showMissingPoints} 
              onClick={onToggleMissingPoints}
              icon={GitCompare}
              color="#A855F7"
              compact
            />
            {showMissingPoints && missingPointsCount > 0 && (
              <div className="px-2 py-1 text-[10px] text-[#A855F7]">{missingPointsCount} points restants</div>
            )}
          </CategoryHeader>

          {/* CATÉGORIE 5: Modes intelligents */}
          <CategoryHeader id="smart" icon={Zap} label="Modes intelligents" color="#F59E0B">
            <ToggleItem label="Anti-fatigue visuelle™" active={antiFatigueMode} onClick={onAntiFatigueModeChange} icon={Eye} color="#F59E0B" compact />
            <ToggleItem label="Surlignage zone active™" active={highlightActiveMode} onClick={onHighlightActiveModeChange} icon={Target} color="#3B82F6" compact />
            <ToggleItem label="Focus couleur™" active={focusColorMode} onClick={onFocusColorModeChange} icon={Palette} color="#8B5CF6" compact />
            <ToggleItem label="Comptage auto™" active={autoCountMode} onClick={onAutoCountModeChange} icon={Hash} color="#FFC94A" compact />
            <ToggleItem label="Mode Nuit Noir & Or™" active={nightMode} onClick={onNightModeChange} icon={Moon} color="#F59E0B" compact />
          </CategoryHeader>

          {/* Bouton Réinitialiser */}
          {hasAnyFilter && (
            <div className="mx-2 mt-2">
              <button
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  onResetFilters?.();
                  showUnstitchedZones && onToggleUnstitchedZones?.();
                  showPotentialErrors && onTogglePotentialErrors?.();
                  showMissingPoints && onToggleMissingPoints?.();
                }}
                className="w-full px-3 py-2 rounded-lg bg-[#333] hover:bg-[#444] text-white text-xs font-medium flex items-center justify-center gap-2"
              >
                <RotateCcw className="w-3 h-3" />
                Réinitialiser tout
              </button>
            </div>
          )}
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}