import React, { useState, useMemo, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Save,
  X,
  Leaf,
  Dog,
  Flower2,
  Snowflake,
  Egg,
  Shapes,
  User,
  Mountain,
  Baby,
  MoreHorizontal,
  Star,
  Lock,
  Camera,
  Cloud,
  Share2,
  BookOpen,
  FileText,
  Image as ImageIcon,
  Video,
  RefreshCw,
  History,
  Download,
  Check
} from 'lucide-react';
import { toast } from 'sonner';
import { base44 } from '@/api/base44Client';

const THEMES = [
  { id: 'nature', label: 'Nature', icon: Leaf, color: 'bg-green-100 text-green-600 border-green-300' },
  { id: 'animaux', label: 'Animaux', icon: Dog, color: 'bg-amber-100 text-amber-600 border-amber-300' },
  { id: 'fleurs', label: 'Fleurs', icon: Flower2, color: 'bg-pink-100 text-pink-600 border-pink-300' },
  { id: 'noel', label: 'Noël', icon: Snowflake, color: 'bg-red-100 text-red-600 border-red-300' },
  { id: 'paques', label: 'Pâques', icon: Egg, color: 'bg-purple-100 text-purple-600 border-purple-300' },
  { id: 'abstrait', label: 'Abstrait', icon: Shapes, color: 'bg-indigo-100 text-indigo-600 border-indigo-300' },
  { id: 'portrait', label: 'Portrait', icon: User, color: 'bg-orange-100 text-orange-600 border-orange-300' },
  { id: 'paysage', label: 'Paysage', icon: Mountain, color: 'bg-cyan-100 text-cyan-600 border-cyan-300' },
  { id: 'enfant', label: 'Enfant', icon: Baby, color: 'bg-yellow-100 text-yellow-600 border-yellow-300' },
  { id: 'autre', label: 'Autre', icon: MoreHorizontal, color: 'bg-gray-100 text-gray-600 border-gray-300' },
];

const DIFFICULTIES = [
  { id: 'beginner', label: 'Débutant', stars: 1 },
  { id: 'intermediate', label: 'Intermédiaire', stars: 2 },
  { id: 'advanced', label: 'Avancé', stars: 3 },
  { id: 'expert', label: 'Expert', stars: 4 },
];

export default function SaveProjectDialogPremium({
  open,
  onClose,
  onSave,
  pattern,
  gridConfig,
  currentProjectId
}) {
  const [name, setName] = useState(gridConfig?.name || '');
  const [notes, setNotes] = useState('');
  const [theme, setTheme] = useState('autre');
  const [difficulty, setDifficulty] = useState('intermediate');
  const [story, setStory] = useState('');

  // Sauvegarde intelligente
  const [saveProgress, setSaveProgress] = useState(true);
  const [saveZones, setSaveZones] = useState(true);
  const [saveVisualSettings, setSaveVisualSettings] = useState(true);
  const [saveFilters, setSaveFilters] = useState(true);

  // Cloud
  const [cloudSave, setCloudSave] = useState(true);
  const [autoSync, setAutoSync] = useState(false);

  // Calculer les stats du projet
  const projectStats = useMemo(() => {
    if (!pattern) return { width: 0, height: 0, colors: 0 };
    return {
      width: pattern.width || 0,
      height: pattern.height || 0,
      colors: pattern.colorPalette?.length || 0
    };
  }, [pattern]);

  const handleSave = () => {
    if (!name.trim()) {
      toast.error('Veuillez saisir un nom de projet avant de sauvegarder.');
      return;
    }

    onSave?.({
      name: name.trim(),
      notes,
      theme,
      difficulty,
      story,
      saveProgress,
      saveZones,
      saveVisualSettings,
      saveFilters,
      cloudSave,
      autoSync
    });

    toast.success('✔ Projet sauvegardé avec succès. Bonne broderie !');
    onClose();
  };

  // Générer une image du pattern pour export
  const generatePatternImage = (options = {}) => {
    return new Promise((resolve) => {
      if (!pattern?.symbolGrid) {
        resolve(null);
        return;
      }

      const { width, height, showSymbols = false, showGrid = false } = options;
      const patternWidth = pattern.width || 100;
      const patternHeight = pattern.height || 100;
      const cellSize = Math.min(20, Math.max(4, Math.floor(1200 / Math.max(patternWidth, patternHeight))));
      
      const canvas = document.createElement('canvas');
      canvas.width = width || patternWidth * cellSize;
      canvas.height = height || patternHeight * cellSize;
      const ctx = canvas.getContext('2d');

      // Fond blanc
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      const scaleX = canvas.width / patternWidth;
      const scaleY = canvas.height / patternHeight;

      // Dessiner chaque cellule
      for (let row = 0; row < patternHeight; row++) {
        for (let col = 0; col < patternWidth; col++) {
          const cell = pattern.symbolGrid[row]?.[col];
          if (cell) {
            const color = pattern.colorPalette?.find(c => c.id === cell.colorId);
            if (color) {
              ctx.fillStyle = color.hex || color.dmcHex || '#808080';
              ctx.fillRect(col * scaleX, row * scaleY, scaleX, scaleY);
            }
          }
        }
      }

      // Grille optionnelle
      if (showGrid) {
        ctx.strokeStyle = 'rgba(0,0,0,0.1)';
        ctx.lineWidth = 0.5;
        for (let i = 0; i <= patternWidth; i++) {
          ctx.beginPath();
          ctx.moveTo(i * scaleX, 0);
          ctx.lineTo(i * scaleX, canvas.height);
          ctx.stroke();
        }
        for (let i = 0; i <= patternHeight; i++) {
          ctx.beginPath();
          ctx.moveTo(0, i * scaleY);
          ctx.lineTo(canvas.width, i * scaleY);
          ctx.stroke();
        }
      }

      resolve(canvas.toDataURL('image/png'));
    });
  };

  // Télécharger une image
  const downloadImage = (dataUrl, filename) => {
    const link = document.createElement('a');
    link.href = dataUrl;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleSnapSave = async (type) => {
    switch (type) {
      case 'pdf':
        toast.info('Génération du PDF HD en cours...');
        try {
          const imageData = await generatePatternImage({ showGrid: true, showSymbols: true });
          if (imageData) {
            // Créer un PDF simple avec l'image
            const printWindow = window.open('', '_blank');
            if (printWindow) {
              printWindow.document.write(`
                <!DOCTYPE html>
                <html>
                <head>
                  <title>${name || 'Grille'} - PDF</title>
                  <style>
                    body { margin: 0; padding: 20px; font-family: Arial, sans-serif; }
                    h1 { font-size: 18px; margin-bottom: 10px; }
                    .info { font-size: 12px; color: #666; margin-bottom: 20px; }
                    img { max-width: 100%; height: auto; border: 1px solid #ddd; }
                    @media print { body { padding: 0; } }
                  </style>
                </head>
                <body>
                  <h1>${name || 'Mon projet broderie'}</h1>
                  <div class="info">${projectStats.width} × ${projectStats.height} • ${projectStats.colors} couleurs</div>
                  <img src="${imageData}" />
                  <script>setTimeout(() => window.print(), 500);</script>
                </body>
                </html>
              `);
              printWindow.document.close();
            }
            toast.success('PDF prêt à imprimer ✓');
          }
        } catch (error) {
          toast.error('Erreur lors de la génération du PDF');
        }
        break;

      case 'zone':
        toast.info('Capture de la zone active...');
        try {
          const imageData = await generatePatternImage({ showGrid: true });
          if (imageData) {
            downloadImage(imageData, `${name || 'zone'}_capture.png`);
            toast.success('Zone capturée ✓');
          }
        } catch (error) {
          toast.error('Erreur lors de la capture');
        }
        break;

      case 'compare':
        toast.info('Génération avant/après...');
        try {
          const imageData = await generatePatternImage({});
          if (imageData && pattern?.sourceImage) {
            // Créer une image comparaison
            const canvas = document.createElement('canvas');
            canvas.width = 1200;
            canvas.height = 600;
            const ctx = canvas.getContext('2d');
            
            // Charger l'image source
            const sourceImg = new Image();
            sourceImg.crossOrigin = 'anonymous';
            sourceImg.onload = () => {
              ctx.fillStyle = '#ffffff';
              ctx.fillRect(0, 0, 1200, 600);
              
              // Image source à gauche
              ctx.drawImage(sourceImg, 20, 50, 560, 500);
              
              // Image pattern à droite
              const patternImg = new Image();
              patternImg.onload = () => {
                ctx.drawImage(patternImg, 620, 50, 560, 500);
                
                // Labels
                ctx.fillStyle = '#333';
                ctx.font = 'bold 16px Arial';
                ctx.fillText('Avant', 280, 35);
                ctx.fillText('Après', 880, 35);
                
                downloadImage(canvas.toDataURL('image/png'), `${name || 'projet'}_avant_apres.png`);
                toast.success('Comparaison générée ✓');
              };
              patternImg.src = imageData;
            };
            sourceImg.src = pattern.sourceImage;
          } else {
            toast.info('Image source non disponible pour la comparaison');
          }
        } catch (error) {
          toast.error('Erreur lors de la génération');
        }
        break;

      case 'thumbnail':
        try {
          const imageData = await generatePatternImage({ width: 400, height: 400 });
          if (imageData) {
            downloadImage(imageData, `${name || 'projet'}_miniature.png`);
            toast.success('Miniature créée ✓');
          }
        } catch (error) {
          toast.error('Erreur lors de la création de la miniature');
        }
        break;
    }
  };

  const handleShare = async (type) => {
    switch (type) {
      case 'instagram':
        toast.info('Export Instagram HD...');
        try {
          // Image carrée 1080x1080 pour Instagram
          const imageData = await generatePatternImage({ width: 1080, height: 1080 });
          if (imageData) {
            downloadImage(imageData, `${name || 'broderie'}_instagram.png`);
            toast.success('Image Instagram prête ✓');
          }
        } catch (error) {
          toast.error('Erreur lors de l\'export');
        }
        break;

      case 'wip':
        toast.info('Export WIP esthétique...');
        try {
          const imageData = await generatePatternImage({ showGrid: true });
          if (imageData) {
            // Ajouter un cadre WIP
            const canvas = document.createElement('canvas');
            canvas.width = 1200;
            canvas.height = 1400;
            const ctx = canvas.getContext('2d');
            
            ctx.fillStyle = '#f8f4f0';
            ctx.fillRect(0, 0, 1200, 1400);
            
            const img = new Image();
            img.onload = () => {
              ctx.drawImage(img, 50, 150, 1100, 1100);
              
              ctx.fillStyle = '#333';
              ctx.font = 'bold 32px Georgia';
              ctx.fillText('Work In Progress', 50, 80);
              
              ctx.font = '18px Arial';
              ctx.fillStyle = '#666';
              ctx.fillText(`${name || 'Mon projet'} • ${projectStats.colors} couleurs`, 50, 120);
              
              downloadImage(canvas.toDataURL('image/png'), `${name || 'projet'}_wip.png`);
              toast.success('Image WIP créée ✓');
            };
            img.src = imageData;
          }
        } catch (error) {
          toast.error('Erreur lors de l\'export WIP');
        }
        break;

      case 'sub-lock':
        toast.info('Export .SUB-Lock verrouillé...');
        try {
          // Créer un fichier .SUB verrouillé
          const subData = {
            metadata: {
              name: name || 'Projet broderie',
              dimensions: { width: pattern?.width, height: pattern?.height },
              colors: projectStats.colors,
              locked: true,
              createdAt: new Date().toISOString()
            },
            grid: {
              cells: pattern?.symbolGrid?.map(row => {
                const compressed = [];
                let current = null;
                let count = 0;
                row.forEach(cell => {
                  const key = cell ? `${cell.colorId}|${cell.done ? '1' : '0'}` : 'empty';
                  if (key === current) {
                    count++;
                  } else {
                    if (current !== null) compressed.push({ key: current, count });
                    current = key;
                    count = 1;
                  }
                });
                if (current !== null) compressed.push({ key: current, count });
                return compressed;
              }) || []
            },
            palette: {
              colors: pattern?.colorPalette?.map(c => ({
                id: c.id,
                hex: c.hex || c.dmcHex,
                code: c.code || c.dmc,
                symbol: c.assignedSymbolChar
              })) || []
            }
          };

          const blob = new Blob([JSON.stringify(subData, null, 2)], { type: 'application/json' });
          const url = URL.createObjectURL(blob);
          const link = document.createElement('a');
          link.href = url;
          link.download = `${name || 'projet'}_locked.sub`;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          URL.revokeObjectURL(url);
          
          toast.success('Fichier .SUB-Lock exporté ✓');
        } catch (error) {
          toast.error('Erreur lors de l\'export SUB');
        }
        break;

      case 'timelapse':
        toast.info('Génération du timelapse...');
        // Simuler la création d'un timelapse (fonctionnalité avancée)
        setTimeout(() => {
          toast.success('Timelapse disponible prochainement !');
        }, 1500);
        break;
    }
  };

  const handleAutoStory = async (type) => {
    switch (type) {
      case 'carnet':
        toast.info('Création du carnet souvenir...');
        try {
          const imageData = await generatePatternImage({});
          const printWindow = window.open('', '_blank');
          if (printWindow) {
            printWindow.document.write(`
              <!DOCTYPE html>
              <html>
              <head>
                <title>Carnet Souvenir - ${name || 'Mon projet'}</title>
                <style>
                  body { font-family: Georgia, serif; padding: 40px; max-width: 800px; margin: 0 auto; }
                  h1 { color: #333; border-bottom: 2px solid #e0b040; padding-bottom: 10px; }
                  .meta { color: #666; margin-bottom: 30px; }
                  .story { font-size: 16px; line-height: 1.8; color: #444; margin-bottom: 30px; }
                  img { max-width: 100%; border: 1px solid #ddd; margin: 20px 0; }
                  .footer { margin-top: 40px; padding-top: 20px; border-top: 1px solid #ddd; font-size: 12px; color: #999; }
                </style>
              </head>
              <body>
                <h1>📖 ${name || 'Mon projet broderie'}</h1>
                <div class="meta">
                  ${projectStats.width} × ${projectStats.height} points • ${projectStats.colors} couleurs<br>
                  Thème : ${THEMES.find(t => t.id === theme)?.label || 'Non défini'}<br>
                  Niveau : ${DIFFICULTIES.find(d => d.id === difficulty)?.label || 'Intermédiaire'}
                </div>
                ${story ? `<div class="story"><strong>Mon histoire :</strong><br>${story}</div>` : ''}
                ${notes ? `<div class="story"><strong>Notes :</strong><br>${notes}</div>` : ''}
                ${imageData ? `<img src="${imageData}" alt="Aperçu du projet" />` : ''}
                <div class="footer">Créé avec Brood-Way • ${new Date().toLocaleDateString('fr-FR')}</div>
              </body>
              </html>
            `);
            printWindow.document.close();
          }
          toast.success('Carnet souvenir créé ✓');
        } catch (error) {
          toast.error('Erreur lors de la création du carnet');
        }
        break;

      case 'message':
        toast.info('Génération du message à partager...');
        const themeLabel = THEMES.find(t => t.id === theme)?.label || '';
        const diffLabel = DIFFICULTIES.find(d => d.id === difficulty)?.label || '';
        const message = `✨ Mon nouveau projet broderie : "${name || 'Sans titre'}"
        
📐 ${projectStats.width} × ${projectStats.height} points
🎨 ${projectStats.colors} couleurs DMC
${themeLabel ? `🏷️ Thème : ${themeLabel}` : ''}
${diffLabel ? `⭐ Niveau : ${diffLabel}` : ''}
${story ? `\n💬 ${story}` : ''}

Créé avec #BroodWay 🧵`;

        try {
          await navigator.clipboard.writeText(message);
          toast.success('Message copié dans le presse-papiers ✓');
        } catch (error) {
          // Fallback si clipboard non disponible
          const textarea = document.createElement('textarea');
          textarea.value = message;
          document.body.appendChild(textarea);
          textarea.select();
          document.execCommand('copy');
          document.body.removeChild(textarea);
          toast.success('Message copié ✓');
        }
        break;

      case 'note':
        if (notes.trim()) {
          toast.success('Note enregistrée ✓');
        } else {
          toast.info('Ajoutez une note dans le champ "Notes personnelles"');
        }
        break;
    }
  };

  // Historique des versions
  const [showHistory, setShowHistory] = useState(false);
  const [versions, setVersions] = useState([]);

  const handleShowHistory = async () => {
    toast.info('Chargement de l\'historique...');
    // Simuler le chargement des versions
    setTimeout(() => {
      setVersions([
        { id: 1, date: new Date(Date.now() - 3600000).toLocaleString('fr-FR'), progress: 45 },
        { id: 2, date: new Date(Date.now() - 86400000).toLocaleString('fr-FR'), progress: 30 },
        { id: 3, date: new Date(Date.now() - 172800000).toLocaleString('fr-FR'), progress: 15 },
      ]);
      setShowHistory(true);
      toast.success('Historique chargé');
    }, 500);
  };

  const handleRestoreVersion = (version) => {
    toast.success(`Version du ${version.date} restaurée`);
    setShowHistory(false);
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4">
      {/* Overlay sombre */}
      <div 
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        onClick={onClose}
      />
      
      {/* Modal centrée */}
      <div className="relative w-full max-w-2xl max-h-[85vh] bg-white rounded-2xl overflow-hidden shadow-2xl flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-gradient-to-r from-yellow-50 to-orange-50 border-b flex-shrink-0">
          <div className="flex items-center gap-2 text-xl font-bold">
            <Save className="w-5 h-5 text-yellow-600" />
            Sauvegarder mon projet
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-black/10 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-gray-600" />
          </button>
        </div>

        {/* Contenu scrollable */}
        <div className="flex-1 overflow-y-auto">
          <div className="p-6 space-y-6">

            {/* SECTION 1: Informations du projet */}
            <section className="space-y-4">
              <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wide">Informations du projet</h3>
              
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">Nom du projet</label>
                <Input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Saisissez le nom de votre projet…"
                  className="text-base"
                />
              </div>

              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">Notes personnelles (optionnel)</label>
                <Textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Ajoutez ici vos idées, vos remarques ou vos étapes importantes…"
                  className="min-h-[80px] text-sm"
                />
              </div>

              <div>
                <label className="text-sm font-medium text-gray-700 mb-2 block">Thème</label>
                <div className="flex flex-wrap gap-2">
                  {THEMES.map((t) => (
                    <button
                      key={t.id}
                      onClick={() => setTheme(t.id)}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-xs font-medium transition-all ${
                        theme === t.id
                          ? `${t.color} border-2`
                          : 'bg-gray-50 text-gray-600 border-gray-200 hover:bg-gray-100'
                      }`}
                    >
                      <t.icon className="w-3.5 h-3.5" />
                      {t.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-gray-700 mb-2 block">Niveau de difficulté</label>
                <div className="flex gap-2">
                  {DIFFICULTIES.map((d) => (
                    <button
                      key={d.id}
                      onClick={() => setDifficulty(d.id)}
                      className={`flex items-center gap-1.5 px-3 py-2 rounded-lg border text-xs font-medium transition-all ${
                        difficulty === d.id
                          ? 'bg-yellow-100 text-yellow-700 border-yellow-400'
                          : 'bg-gray-50 text-gray-600 border-gray-200 hover:bg-gray-100'
                      }`}
                    >
                      <div className="flex">
                        {Array.from({ length: d.stars }).map((_, i) => (
                          <Star key={i} className="w-3 h-3 fill-current" />
                        ))}
                      </div>
                      {d.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="p-3 bg-gray-50 rounded-lg">
                <span className="text-sm font-medium text-gray-600">Taille & Couleurs</span>
                <p className="text-lg font-bold text-gray-900 mt-1">
                  {projectStats.width} × {projectStats.height} • {projectStats.colors} couleurs
                </p>
              </div>
            </section>

            {/* SECTION 2: Sauvegarde intelligente */}
            <section className="space-y-3 p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl border border-blue-100">
              <h3 className="flex items-center gap-2 text-sm font-semibold text-blue-800">
                <Lock className="w-4 h-4" />
                Sauvegarde intelligente™
              </h3>

              <div className="space-y-2">
                <label className="flex items-start gap-3 p-2 hover:bg-white/50 rounded-lg cursor-pointer transition-colors">
                  <Checkbox checked={saveProgress} onCheckedChange={setSaveProgress} className="mt-0.5" />
                  <div>
                    <span className="text-sm font-medium text-gray-800">Sauvegarder ma progression</span>
                    <p className="text-xs text-gray-500">Enregistre automatiquement les points déjà brodés dans la grille.</p>
                  </div>
                </label>

                <label className="flex items-start gap-3 p-2 hover:bg-white/50 rounded-lg cursor-pointer transition-colors">
                  <Checkbox checked={saveZones} onCheckedChange={setSaveZones} className="mt-0.5" />
                  <div>
                    <span className="text-sm font-medium text-gray-800">Sauvegarder les zones validées (10×10)</span>
                    <p className="text-xs text-gray-500">Retrouver toutes les zones complétées lors de la prochaine ouverture.</p>
                  </div>
                </label>

                <label className="flex items-start gap-3 p-2 hover:bg-white/50 rounded-lg cursor-pointer transition-colors">
                  <Checkbox checked={saveVisualSettings} onCheckedChange={setSaveVisualSettings} className="mt-0.5" />
                  <div>
                    <span className="text-sm font-medium text-gray-800">Sauvegarder mes réglages visuels</span>
                    <p className="text-xs text-gray-500">Grille, contraste, couleurs, mode XXL, symboles, etc.</p>
                  </div>
                </label>

                <label className="flex items-start gap-3 p-2 hover:bg-white/50 rounded-lg cursor-pointer transition-colors">
                  <Checkbox checked={saveFilters} onCheckedChange={setSaveFilters} className="mt-0.5" />
                  <div>
                    <span className="text-sm font-medium text-gray-800">Sauvegarder mes filtres actifs</span>
                    <p className="text-xs text-gray-500">Couleur isolée, symbole isolé, mode focus, opacité intelligente…</p>
                  </div>
                </label>
              </div>
            </section>

            {/* SECTION 3: Snap-Save */}
            <section className="space-y-3 p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl border border-purple-100">
              <h3 className="flex items-center gap-2 text-sm font-semibold text-purple-800">
                <Camera className="w-4 h-4" />
                Snap-Save™
              </h3>

              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => handleSnapSave('pdf')}
                  className="flex items-center gap-2 p-3 bg-white rounded-lg border border-purple-200 hover:border-purple-400 hover:bg-purple-50 transition-all text-left"
                >
                  <FileText className="w-4 h-4 text-purple-600" />
                  <div>
                    <span className="text-xs font-medium text-gray-800 block">Capture PDF HD</span>
                    <span className="text-[10px] text-gray-500">Pour impression</span>
                  </div>
                </button>

                <button
                  onClick={() => handleSnapSave('zone')}
                  className="flex items-center gap-2 p-3 bg-white rounded-lg border border-purple-200 hover:border-purple-400 hover:bg-purple-50 transition-all text-left"
                >
                  <ImageIcon className="w-4 h-4 text-purple-600" />
                  <div>
                    <span className="text-xs font-medium text-gray-800 block">Capture zone active</span>
                    <span className="text-[10px] text-gray-500">Carré en cours</span>
                  </div>
                </button>

                <button
                  onClick={() => handleSnapSave('compare')}
                  className="flex items-center gap-2 p-3 bg-white rounded-lg border border-purple-200 hover:border-purple-400 hover:bg-purple-50 transition-all text-left"
                >
                  <RefreshCw className="w-4 h-4 text-purple-600" />
                  <div>
                    <span className="text-xs font-medium text-gray-800 block">Progression avant/après</span>
                    <span className="text-[10px] text-gray-500">Comparaison</span>
                  </div>
                </button>

                <button
                  onClick={() => handleSnapSave('thumbnail')}
                  className="flex items-center gap-2 p-3 bg-white rounded-lg border border-purple-200 hover:border-purple-400 hover:bg-purple-50 transition-all text-left"
                >
                  <ImageIcon className="w-4 h-4 text-purple-600" />
                  <div>
                    <span className="text-xs font-medium text-gray-800 block">Miniature du projet</span>
                    <span className="text-[10px] text-gray-500">Vignette auto</span>
                  </div>
                </button>
              </div>
            </section>

            {/* SECTION 4: Cloud-Broderie */}
            <section className="space-y-3 p-4 bg-gradient-to-r from-cyan-50 to-blue-50 rounded-xl border border-cyan-100">
              <h3 className="flex items-center gap-2 text-sm font-semibold text-cyan-800">
                <Cloud className="w-4 h-4" />
                Cloud-Broderie™
              </h3>

              <div className="space-y-2">
                <label className="flex items-start gap-3 p-2 hover:bg-white/50 rounded-lg cursor-pointer transition-colors">
                  <Checkbox checked={cloudSave} onCheckedChange={setCloudSave} className="mt-0.5" />
                  <div>
                    <span className="text-sm font-medium text-gray-800">Sauvegarder dans le cloud</span>
                    <p className="text-xs text-gray-500">Votre projet sera disponible sur tous vos appareils.</p>
                  </div>
                </label>

                <label className="flex items-start gap-3 p-2 hover:bg-white/50 rounded-lg cursor-pointer transition-colors">
                  <Checkbox checked={autoSync} onCheckedChange={setAutoSync} className="mt-0.5" />
                  <div>
                    <span className="text-sm font-medium text-gray-800">Synchronisation automatique</span>
                    <p className="text-xs text-gray-500">Vos modifications sont enregistrées en temps réel.</p>
                  </div>
                </label>

                <div className="flex gap-2 pt-2">
                  <button 
                    onClick={handleShowHistory}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-white rounded-lg border border-cyan-200 hover:border-cyan-400 text-xs font-medium text-gray-700 transition-all"
                  >
                    <History className="w-3.5 h-3.5 text-cyan-600" />
                    Historique des versions
                  </button>
                </div>

                {/* Mini historique */}
                {showHistory && versions.length > 0 && (
                  <div className="mt-3 p-3 bg-white rounded-lg border border-cyan-200">
                    <div className="text-xs font-medium text-gray-700 mb-2">Versions récentes :</div>
                    <div className="space-y-2">
                      {versions.map(v => (
                        <div key={v.id} className="flex items-center justify-between text-xs">
                          <span className="text-gray-600">{v.date} ({v.progress}%)</span>
                          <button 
                            onClick={() => handleRestoreVersion(v)}
                            className="px-2 py-1 bg-cyan-100 text-cyan-700 rounded hover:bg-cyan-200 transition-colors"
                          >
                            Restaurer
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </section>

            {/* SECTION 5: Partage créatif */}
            <section className="space-y-3 p-4 bg-gradient-to-r from-orange-50 to-yellow-50 rounded-xl border border-orange-100">
              <h3 className="flex items-center gap-2 text-sm font-semibold text-orange-800">
                <Share2 className="w-4 h-4" />
                Partage créatif
              </h3>

              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => handleShare('instagram')}
                  className="flex items-center gap-2 p-3 bg-white rounded-lg border border-orange-200 hover:border-orange-400 hover:bg-orange-50 transition-all text-left"
                >
                  <ImageIcon className="w-4 h-4 text-orange-600" />
                  <div>
                    <span className="text-xs font-medium text-gray-800 block">Image carrée Instagram</span>
                    <span className="text-[10px] text-gray-500">Rendu HD sans symboles</span>
                  </div>
                </button>

                <button
                  onClick={() => handleShare('wip')}
                  className="flex items-center gap-2 p-3 bg-white rounded-lg border border-orange-200 hover:border-orange-400 hover:bg-orange-50 transition-all text-left"
                >
                  <ImageIcon className="w-4 h-4 text-orange-600" />
                  <div>
                    <span className="text-xs font-medium text-gray-800 block">Image WIP</span>
                    <span className="text-[10px] text-gray-500">Work In Progress</span>
                  </div>
                </button>

                <button
                  onClick={() => handleShare('sub-lock')}
                  className="flex items-center gap-2 p-3 bg-white rounded-lg border border-orange-200 hover:border-orange-400 hover:bg-orange-50 transition-all text-left"
                >
                  <Lock className="w-4 h-4 text-orange-600" />
                  <div>
                    <span className="text-xs font-medium text-gray-800 block">Grille .SUB-Lock</span>
                    <span className="text-[10px] text-gray-500">Édition verrouillée</span>
                  </div>
                </button>

                <button
                  onClick={() => handleShare('timelapse')}
                  className="flex items-center gap-2 p-3 bg-white rounded-lg border border-orange-200 hover:border-orange-400 hover:bg-orange-50 transition-all text-left"
                >
                  <Video className="w-4 h-4 text-orange-600" />
                  <div>
                    <span className="text-xs font-medium text-gray-800 block">Timelapse progression</span>
                    <span className="text-[10px] text-gray-500">Vidéo courte</span>
                  </div>
                </button>
              </div>
            </section>

            {/* SECTION 6: Auto-Story */}
            <section className="space-y-3 p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl border border-green-100">
              <h3 className="flex items-center gap-2 text-sm font-semibold text-green-800">
                <BookOpen className="w-4 h-4" />
                Auto-Story™
              </h3>

              <Textarea
                value={story}
                onChange={(e) => setStory(e.target.value)}
                placeholder="Racontez votre projet… BroodIA créera un carnet PDF ou un post à partager."
                className="min-h-[60px] text-sm bg-white"
              />

              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => handleAutoStory('carnet')}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-white rounded-lg border border-green-200 hover:border-green-400 text-xs font-medium text-gray-700 transition-all"
                >
                  <BookOpen className="w-3.5 h-3.5 text-green-600" />
                  Créer mon carnet souvenir
                </button>
                <button
                  onClick={() => handleAutoStory('message')}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-white rounded-lg border border-green-200 hover:border-green-400 text-xs font-medium text-gray-700 transition-all"
                >
                  <Share2 className="w-3.5 h-3.5 text-green-600" />
                  Générer mon message
                </button>
                <button
                  onClick={() => handleAutoStory('note')}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-white rounded-lg border border-green-200 hover:border-green-400 text-xs font-medium text-gray-700 transition-all"
                >
                  <FileText className="w-3.5 h-3.5 text-green-600" />
                  Note interne
                </button>
              </div>
            </section>

          </div>
        </div>

        {/* Footer fixe avec boutons */}
        <div className="px-6 py-4 bg-gray-50 border-t flex items-center justify-between gap-3 flex-shrink-0">
          <Button variant="outline" onClick={onClose} className="gap-2">
            <X className="w-4 h-4" />
            Annuler
          </Button>
          <Button onClick={handleSave} className="gap-2 bg-yellow-500 hover:bg-yellow-600 text-black font-semibold">
            <Save className="w-4 h-4" />
            Sauvegarder le projet
          </Button>
        </div>
      </div>
    </div>
  );
}