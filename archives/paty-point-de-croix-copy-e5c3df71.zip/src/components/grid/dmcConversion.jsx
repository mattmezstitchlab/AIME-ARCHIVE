/**
 * Système de conversion automatique vers les couleurs DMC
 * Utilisé lors de l'import d'images pour générer une palette unifiée
 */

import { findClosestDMC, roundRGB } from './dmcColors';

/**
 * Convertit une liste de couleurs brutes détectées en palette DMC unifiée
 * @param {Array} rawColors - Liste des couleurs détectées { r, g, b, count }
 * @returns {Array} Palette DMC avec doublons fusionnés
 */
export function convertToDMCPalette(rawColors) {
  if (!rawColors || rawColors.length === 0) return [];

  // Étape 1: Regrouper les couleurs proches (anti-bruit)
  const groupedColors = groupSimilarColors(rawColors);

  // Étape 2: Convertir chaque groupe vers la couleur DMC la plus proche
  const mappedColors = groupedColors.map(color => {
    const closestDMC = findClosestDMC(color.r, color.g, color.b);
    return {
      dmcCode: closestDMC.code,
      name: closestDMC.name,
      r: closestDMC.r,
      g: closestDMC.g,
      b: closestDMC.b,
      hex: rgbToHex(closestDMC.r, closestDMC.g, closestDMC.b),
      pointsTotal: color.count,
      originalR: color.r,
      originalG: color.g,
      originalB: color.b
    };
  });

  // Étape 3: Fusionner les doublons DMC
  const mergedPalette = mergeDuplicateDMC(mappedColors);

  // Étape 4: Trier par nombre de points (du plus utilisé au moins utilisé)
  mergedPalette.sort((a, b) => b.pointsTotal - a.pointsTotal);

  return mergedPalette;
}

/**
 * Regroupe les couleurs très proches pour éviter une explosion de micro-variations
 */
function groupSimilarColors(rawColors, threshold = 16) {
  const groups = [];
  
  for (const color of rawColors) {
    // Arrondir RGB pour regrouper
    const roundedR = roundRGB(color.r, threshold);
    const roundedG = roundRGB(color.g, threshold);
    const roundedB = roundRGB(color.b, threshold);
    
    // Chercher un groupe existant
    const existingGroup = groups.find(g => 
      g.r === roundedR && g.g === roundedG && g.b === roundedB
    );
    
    if (existingGroup) {
      existingGroup.count += color.count;
    } else {
      groups.push({
        r: roundedR,
        g: roundedG,
        b: roundedB,
        count: color.count
      });
    }
  }
  
  return groups;
}

/**
 * Fusionne les couleurs DMC identiques en additionnant leurs points
 */
function mergeDuplicateDMC(mappedColors) {
  const dmcMap = new Map();
  
  for (const color of mappedColors) {
    if (dmcMap.has(color.dmcCode)) {
      const existing = dmcMap.get(color.dmcCode);
      existing.pointsTotal += color.pointsTotal;
    } else {
      dmcMap.set(color.dmcCode, { ...color });
    }
  }
  
  return Array.from(dmcMap.values());
}

/**
 * Convertit RGB en hex
 */
function rgbToHex(r, g, b) {
  return '#' + [r, g, b].map(x => {
    const hex = x.toString(16);
    return hex.length === 1 ? '0' + hex : hex;
  }).join('');
}

// Symboles standards de point de croix
const STANDARD_SYMBOLS = [
  '●', '✕', '▲', '■', '◆', '○', '▼', '◀', '▶', '★',
  '□', '△', '◇', '☆', '♦', '♥', '♣', '♠', '⊙', '⊗',
  '⊕', '⊖', '⊘', '⊚', '⊛', '⊜', '⊝', '⊞', '⊟', '⊠',
  '⊡', '▪', '▫', '▬', '▭', '▮', '▯', '▰', '▱', '▲',
  '△', '▴', '▵', '▶', '▷', '▸', '▹', '►', '▻', '▼',
  '▽', '▾', '▿', '◀', '◁', '◂', '◃', '◄', '◅', '◆',
  '◇', '◈', '◉', '◊', '○', '◌', '◍', '◎', '●', '◐',
  '◑', '◒', '◓', '◔', '◕', '◖', '◗', '◘', '◙', '◚',
  '◛', '◜', '◝', '◞', '◟', '◠', '◡', '◢', '◣', '◤'
];

/**
 * Assigne des symboles uniques à une palette DMC
 */
function assignSymbolsToDmcPalette(dmcPalette) {
  return dmcPalette.map((color, index) => ({
    ...color,
    symbolCode: STANDARD_SYMBOLS[index % STANDARD_SYMBOLS.length],
    symbolDisplay: STANDARD_SYMBOLS[index % STANDARD_SYMBOLS.length]
  }));
}

/**
 * Applique la conversion DMC à un pattern existant
 * Met à jour colorPalette avec les codes DMC et les symboles
 */
export function applyDMCConversionToPattern(pattern) {
  if (!pattern || !pattern.colorPalette) return pattern;

  // Extraire les couleurs brutes avec leurs counts
  const rawColors = pattern.colorPalette.map(color => {
    let r, g, b;
    
    if (color.hex) {
      r = parseInt(color.hex.slice(1, 3), 16);
      g = parseInt(color.hex.slice(3, 5), 16);
      b = parseInt(color.hex.slice(5, 7), 16);
    } else if (color.r !== undefined) {
      r = color.r;
      g = color.g;
      b = color.b;
    } else {
      // Fallback vers noir si couleur invalide
      r = 0;
      g = 0;
      b = 0;
    }
    
    return {
      r,
      g,
      b,
      count: color.totalCount || color.count || 0,
      originalId: color.id
    };
  });

  // Convertir en palette DMC
  let dmcPalette = convertToDMCPalette(rawColors);
  
  // S'assurer qu'il y a au moins une couleur
  if (dmcPalette.length === 0) {
    // Utiliser DMC-310 (noir) par défaut
    dmcPalette = [{
      dmcCode: '310',
      name: 'Noir',
      r: 0,
      g: 0,
      b: 0,
      hex: '#000000',
      pointsTotal: 0
    }];
  }
  
  // Assigner les symboles
  dmcPalette = assignSymbolsToDmcPalette(dmcPalette);

  // Créer une map de correspondance ancien ID -> nouveau DMC
  const idToDMC = new Map();
  const idToSymbol = new Map();
  
  pattern.colorPalette.forEach((oldColor, index) => {
    if (dmcPalette[index]) {
      idToDMC.set(oldColor.id, dmcPalette[index].dmcCode);
      idToSymbol.set(oldColor.id, dmcPalette[index].symbolCode);
    }
  });

  // Mettre à jour la palette avec les codes DMC et symboles
  const newColorPalette = dmcPalette.map((dmcColor, index) => {
    const oldColor = pattern.colorPalette[index] || {};
    
    return {
      id: `dmc-${dmcColor.dmcCode}`,
      dmcCode: dmcColor.dmcCode,
      code: dmcColor.dmcCode, // Alias pour compatibilité
      name: dmcColor.name,
      hex: dmcColor.hex,
      r: dmcColor.r,
      g: dmcColor.g,
      b: dmcColor.b,
      count: dmcColor.pointsTotal,
      totalCount: dmcColor.pointsTotal,
      doneCount: oldColor.doneCount || 0,
      progress: oldColor.progress || 0,
      assignedSymbolId: `symbol-${index}`,
      assignedSymbolChar: dmcColor.symbolCode,
      symbolCode: dmcColor.symbolCode,
      symbolDisplay: dmcColor.symbolDisplay,
      isVisible: true
    };
  });

  // Mettre à jour la symbolGrid pour utiliser les nouveaux IDs et symboles
  const newSymbolGrid = pattern.symbolGrid?.map(row =>
    row.map(cell => {
      if (!cell || !cell.colorId) return cell;
      
      const newDmcCode = idToDMC.get(cell.colorId);
      const newSymbol = idToSymbol.get(cell.colorId);
      
      if (newDmcCode) {
        return {
          ...cell,
          colorId: `dmc-${newDmcCode}`,
          dmcCode: newDmcCode,
          symbolCode: newSymbol
        };
      }
      
      return cell;
    })
  ) || [];

  return {
    ...pattern,
    colorPalette: newColorPalette,
    symbolGrid: newSymbolGrid,
    dmcConversionApplied: true,
    colorMapping: Object.fromEntries(idToDMC),
    symbolMapping: Object.fromEntries(idToSymbol)
  };
}