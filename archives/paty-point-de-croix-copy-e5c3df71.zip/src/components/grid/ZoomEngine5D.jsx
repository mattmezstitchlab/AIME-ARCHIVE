import { useEffect, useRef, useCallback } from 'react';
import { toast } from 'sonner';
import { useZoomState, getZoomRenderConfig } from './ZoomStateManager';

/**
 * ZOOM 5D™ ENGINE
 * Système de zoom intelligent multi-couches avec IA
 */

// Niveaux de zoom
export const ZOOM_LEVELS = {
  GLOBAL: 0,      // Vue globale
  GRID_10X10: 1,  // Vue repères 10x10
  DETAIL: 2,      // Vue détail avec symboles
  STITCH: 3,      // Vue point par point
  MICROSCOPE: 4   // Vue microscope ultra précise
};

// Valeurs de zoom correspondantes
const ZOOM_VALUES = {
  [ZOOM_LEVELS.GLOBAL]: 0.3,
  [ZOOM_LEVELS.GRID_10X10]: 0.8,
  [ZOOM_LEVELS.DETAIL]: 1.5,
  [ZOOM_LEVELS.STITCH]: 3.0,
  [ZOOM_LEVELS.MICROSCOPE]: 6.0
};

// Configuration des animations (spring Apple-like)
const ANIMATION_CONFIG = {
  duration: 220,
  tension: 170,
  friction: 26,
  mass: 1
};

/**
 * Hook principal du Zoom 5D™
 */
export function useZoomEngine5D({
  currentZoom,
  onZoomChange,
  onOffsetChange,
  canvasWidth,
  canvasHeight,
  gridConfig,
  pattern,
  selectedColorId,
  aiEnabled = false
}) {
  const animationFrameRef = useRef(null);
  const zoomAnimationRef = useRef(null);
  const lastWheelTimeRef = useRef(0);
  const accumulatedDeltaRef = useRef(0);
  
  // État centralisé
  const { 
    zoomLevel, 
    setZoomLevel, 
    setActualZoomValue, 
    setActiveColorId,
    setIsAnimating,
    iaFocusEnabled,
    canZoomIn,
    canZoomOut
  } = useZoomState();
  
  // Synchroniser la couleur active
  useEffect(() => {
    setActiveColorId(selectedColorId);
  }, [selectedColorId, setActiveColorId]);
  
  // Déterminer le niveau de zoom actuel
  const getCurrentZoomLevel = useCallback(() => {
    const zoom = currentZoom;
    if (zoom <= ZOOM_VALUES[ZOOM_LEVELS.GLOBAL]) return ZOOM_LEVELS.GLOBAL;
    if (zoom <= ZOOM_VALUES[ZOOM_LEVELS.GRID_10X10]) return ZOOM_LEVELS.GRID_10X10;
    if (zoom <= ZOOM_VALUES[ZOOM_LEVELS.DETAIL]) return ZOOM_LEVELS.DETAIL;
    if (zoom <= ZOOM_VALUES[ZOOM_LEVELS.STITCH]) return ZOOM_LEVELS.STITCH;
    return ZOOM_LEVELS.MICROSCOPE;
  }, [currentZoom]);

  // Animation spring avec rebond
  const animateZoom = useCallback((targetZoom, centerX, centerY) => {
    if (zoomAnimationRef.current) {
      cancelAnimationFrame(zoomAnimationRef.current);
    }

    setIsAnimating(true);
    const startZoom = currentZoom;
    const startTime = Date.now();
    
    const animate = () => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / ANIMATION_CONFIG.duration, 1);
      
      // Spring easing avec rebond léger
      const easeOutElastic = (t) => {
        const c4 = (2 * Math.PI) / 3;
        return t === 0 ? 0 : t === 1 ? 1 :
          Math.pow(2, -10 * t) * Math.sin((t * 10 - 0.75) * c4) + 1;
      };
      
      const easedProgress = easeOutElastic(progress);
      const newZoom = startZoom + (targetZoom - startZoom) * easedProgress;
      
      // Calculer les nouveaux offsets pour garder le centre
      if (centerX !== undefined && centerY !== undefined) {
        const containerWidth = canvasWidth;
        const containerHeight = canvasHeight;
        
        const oldOffsetX = (containerWidth / 2 - centerX * currentZoom);
        const oldOffsetY = (containerHeight / 2 - centerY * currentZoom);
        
        const newOffsetX = containerWidth / 2 - centerX * newZoom;
        const newOffsetY = containerHeight / 2 - centerY * newZoom;
        
        onOffsetChange(newOffsetX, newOffsetY);
      }
      
      onZoomChange(newZoom);
      
      if (progress < 1) {
        zoomAnimationRef.current = requestAnimationFrame(animate);
      } else {
        zoomAnimationRef.current = null;
        setIsAnimating(false);
      }
    };
    
    animate();
  }, [currentZoom, canvasWidth, canvasHeight, onZoomChange, onOffsetChange, setIsAnimating]);

  // Zoom vers un niveau spécifique
  const zoomToLevel = useCallback((level, centerX, centerY) => {
    const targetZoom = ZOOM_VALUES[level];
    setZoomLevel(level);
    setActualZoomValue(targetZoom);
    animateZoom(targetZoom, centerX, centerY);
    
    // Feedback utilisateur
    const levelNames = ['Globale', '10×10', 'Détail', 'Point', 'Microscope'];
    toast.success(`Zoom ${levelNames[level]}`);
  }, [animateZoom, setZoomLevel, setActualZoomValue]);

  // Zoom intelligent basé sur le contexte
  const smartZoom = useCallback((mouseX, mouseY) => {
    if (!pattern?.symbolGrid) {
      zoomToLevel(ZOOM_LEVELS.DETAIL, mouseX, mouseY);
      return;
    }

    // Analyser la zone sous le curseur
    const gridX = Math.floor(mouseX / gridConfig.taille_case);
    const gridY = Math.floor(mouseY / gridConfig.taille_case);
    
    const cell = pattern.symbolGrid[gridY]?.[gridX];
    
    if (cell) {
      // Si cellule brodée → zoom microscope pour vérifier
      if (cell.done) {
        zoomToLevel(ZOOM_LEVELS.MICROSCOPE, mouseX, mouseY);
        toast.info('Zoom microscope pour vérifier le point');
      } else {
        // Si non brodée → zoom stitch pour broder
        zoomToLevel(ZOOM_LEVELS.STITCH, mouseX, mouseY);
        toast.info('Zoom optimal pour broder');
      }
    } else {
      zoomToLevel(ZOOM_LEVELS.DETAIL, mouseX, mouseY);
    }
  }, [pattern, gridConfig, zoomToLevel]);

  // Zoom sur couleur active
  const zoomToActiveColor = useCallback(() => {
    if (!selectedColorId || !pattern?.symbolGrid) {
      toast.error('Aucune couleur sélectionnée');
      return;
    }

    // Trouver le centre de toutes les cases de cette couleur
    let totalX = 0, totalY = 0, count = 0;
    
    pattern.symbolGrid.forEach((row, rowIdx) => {
      row.forEach((cell, colIdx) => {
        if (cell?.colorId === selectedColorId && !cell.done) {
          totalX += colIdx;
          totalY += rowIdx;
          count++;
        }
      });
    });
    
    if (count > 0) {
      const centerCol = totalX / count;
      const centerRow = totalY / count;
      const centerX = centerCol * gridConfig.taille_case;
      const centerY = centerRow * gridConfig.taille_case;
      
      // Déterminer le niveau optimal selon la densité
      const density = count / (pattern.symbolGrid.length * pattern.symbolGrid[0].length);
      let targetLevel = ZOOM_LEVELS.DETAIL;
      
      if (density < 0.05) targetLevel = ZOOM_LEVELS.MICROSCOPE;
      else if (density < 0.15) targetLevel = ZOOM_LEVELS.STITCH;
      
      zoomToLevel(targetLevel, centerX, centerY);
      toast.success(`Zoom sur couleur (${count} points)`);
    } else {
      toast.info('Cette couleur est terminée !');
    }
  }, [selectedColorId, pattern, gridConfig, zoomToLevel]);

  // Zoom sur zone dense
  const zoomToDenseZone = useCallback(() => {
    if (!pattern?.symbolGrid) return;

    // Trouver la zone la plus dense de points non brodés
    let maxDensity = 0;
    let bestZone = { col: 0, row: 0 };
    const windowSize = 20;
    
    for (let row = 0; row < pattern.symbolGrid.length - windowSize; row += 5) {
      for (let col = 0; col < pattern.symbolGrid[0].length - windowSize; col += 5) {
        let density = 0;
        
        for (let r = row; r < row + windowSize && r < pattern.symbolGrid.length; r++) {
          for (let c = col; c < col + windowSize && c < pattern.symbolGrid[0].length; c++) {
            if (pattern.symbolGrid[r]?.[c] && !pattern.symbolGrid[r][c].done) {
              density++;
            }
          }
        }
        
        if (density > maxDensity) {
          maxDensity = density;
          bestZone = { col: col + windowSize / 2, row: row + windowSize / 2 };
        }
      }
    }
    
    if (maxDensity > 0) {
      const centerX = bestZone.col * gridConfig.taille_case;
      const centerY = bestZone.row * gridConfig.taille_case;
      zoomToLevel(ZOOM_LEVELS.STITCH, centerX, centerY);
      toast.success(`Zone dense trouvée (${maxDensity} points)`);
    }
  }, [pattern, gridConfig, zoomToLevel]);

  // Zoom sur points isolés
  const zoomToIsolatedStitches = useCallback(() => {
    if (!pattern?.symbolGrid) return;

    // Trouver le premier point isolé non brodé
    for (let rowIdx = 0; rowIdx < pattern.symbolGrid.length; rowIdx++) {
      for (let colIdx = 0; colIdx < pattern.symbolGrid[rowIdx].length; colIdx++) {
        const cell = pattern.symbolGrid[rowIdx][colIdx];
        if (cell && !cell.done) {
          // Vérifier si isolé
          const neighbors = [
            pattern.symbolGrid[rowIdx - 1]?.[colIdx],
            pattern.symbolGrid[rowIdx + 1]?.[colIdx],
            pattern.symbolGrid[rowIdx]?.[colIdx - 1],
            pattern.symbolGrid[rowIdx]?.[colIdx + 1],
          ].filter(n => n && n.done);
          
          if (neighbors.length >= 3) {
            const centerX = colIdx * gridConfig.taille_case;
            const centerY = rowIdx * gridConfig.taille_case;
            zoomToLevel(ZOOM_LEVELS.MICROSCOPE, centerX, centerY);
            toast.success('Point isolé détecté');
            return;
          }
        }
      }
    }
    
    toast.info('Aucun point isolé trouvé');
  }, [pattern, gridConfig, zoomToLevel]);

  // Réinitialiser le zoom
  const resetZoom = useCallback(() => {
    animateZoom(ZOOM_VALUES[ZOOM_LEVELS.DETAIL], canvasWidth / 2, canvasHeight / 2);
    toast.success('Zoom réinitialisé');
  }, [animateZoom, canvasWidth, canvasHeight]);

  // Gestion de la molette avec accumulation
  const handleWheel = useCallback((e) => {
    e.preventDefault();
    
    const now = Date.now();
    const timeSinceLastWheel = now - lastWheelTimeRef.current;
    lastWheelTimeRef.current = now;
    
    // Réinitialiser l'accumulation si trop de temps écoulé
    if (timeSinceLastWheel > 150) {
      accumulatedDeltaRef.current = 0;
    }
    
    accumulatedDeltaRef.current += e.deltaY;
    
    // Appliquer le zoom par paliers progressifs
    const sensitivity = 0.001;
    const zoomFactor = 1 - (e.deltaY * sensitivity);
    const newZoom = Math.max(0.1, Math.min(10, currentZoom * zoomFactor));
    
    // Mode microscope sur pression forte
    const isForcefulScroll = Math.abs(e.deltaY) > 100;
    if (isForcefulScroll && newZoom > ZOOM_VALUES[ZOOM_LEVELS.STITCH]) {
      zoomToLevel(ZOOM_LEVELS.MICROSCOPE, e.clientX, e.clientY);
      return;
    }
    
    // Calculer le point sous le curseur
    const rect = e.currentTarget.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;
    
    animateZoom(newZoom, mouseX, mouseY);
  }, [currentZoom, animateZoom, zoomToLevel]);

  // Gestion du double-clic
  const handleDoubleClick = useCallback((e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;
    
    smartZoom(mouseX, mouseY);
  }, [smartZoom]);

  // Gestion Cmd/Ctrl + Clic → zoom couleur active
  const handleClick = useCallback((e) => {
    if ((e.metaKey || e.ctrlKey) && selectedColorId) {
      e.preventDefault();
      zoomToActiveColor();
      toast.success('Zoom sur couleur active');
    } else if (e.shiftKey) {
      e.preventDefault();
      zoomToDenseZone();
      toast.success('Zoom sur zone dense');
    }
  }, [selectedColorId, zoomToActiveColor, zoomToDenseZone]);

  // Gestion des raccourcis clavier
  useEffect(() => {
    const handleKeyDown = (e) => {
      // + ou = → zoom avant
      if (e.key === '+' || e.key === '=') {
        e.preventDefault();
        const currentLevel = getCurrentZoomLevel();
        const nextLevel = Math.min(ZOOM_LEVELS.MICROSCOPE, currentLevel + 1);
        zoomToLevel(nextLevel, canvasWidth / 2, canvasHeight / 2);
      }
      
      // - → zoom arrière
      if (e.key === '-' || e.key === '_') {
        e.preventDefault();
        const currentLevel = getCurrentZoomLevel();
        const prevLevel = Math.max(ZOOM_LEVELS.GLOBAL, currentLevel - 1);
        zoomToLevel(prevLevel, canvasWidth / 2, canvasHeight / 2);
      }
      
      // 0 → réinitialiser
      if (e.key === '0') {
        e.preventDefault();
        resetZoom();
      }
      
      // Cmd/Ctrl + Clic → zoom couleur active (géré dans le canvas)
      // Shift + Clic → zoom zone dense (géré dans le canvas)
    };
    
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [getCurrentZoomLevel, zoomToLevel, resetZoom, canvasWidth, canvasHeight]);

  // Cleanup
  useEffect(() => {
    return () => {
      if (zoomAnimationRef.current) {
        cancelAnimationFrame(zoomAnimationRef.current);
      }
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, []);

  return {
    currentZoomLevel: getCurrentZoomLevel(),
    zoomToLevel,
    smartZoom,
    zoomToActiveColor,
    zoomToDenseZone,
    zoomToIsolatedStitches,
    resetZoom,
    handleWheel,
    handleDoubleClick,
    handleClick,
    ZOOM_LEVELS,
    ZOOM_VALUES,
    renderConfig: getZoomRenderConfig(zoomLevel, currentZoom)
  };
}

/**
 * Utilitaires de rendu selon le niveau de zoom
 */
export const getRenderConfig = (zoomLevel) => {
  switch (zoomLevel) {
    case ZOOM_LEVELS.GLOBAL:
      return {
        showGrid: false,
        showSymbols: false,
        showPattern: true,
        showProgress: true,
        opacity: 0.8,
        gridEvery: 50
      };
    
    case ZOOM_LEVELS.GRID_10X10:
      return {
        showGrid: true,
        showSymbols: false,
        showPattern: true,
        showProgress: true,
        opacity: 0.6,
        gridEvery: 10
      };
    
    case ZOOM_LEVELS.DETAIL:
      return {
        showGrid: true,
        showSymbols: true,
        showPattern: true,
        showProgress: true,
        opacity: 0.4,
        gridEvery: 10
      };
    
    case ZOOM_LEVELS.STITCH:
      return {
        showGrid: true,
        showSymbols: true,
        showPattern: true,
        showProgress: true,
        opacity: 0.2,
        gridEvery: 1
      };
    
    case ZOOM_LEVELS.MICROSCOPE:
      return {
        showGrid: true,
        showSymbols: true,
        showPattern: false,
        showProgress: true,
        opacity: 0,
        gridEvery: 1,
        highlightActive: true
      };
    
    default:
      return {
        showGrid: true,
        showSymbols: true,
        showPattern: true,
        showProgress: true,
        opacity: 0.5,
        gridEvery: 10
      };
  }
};