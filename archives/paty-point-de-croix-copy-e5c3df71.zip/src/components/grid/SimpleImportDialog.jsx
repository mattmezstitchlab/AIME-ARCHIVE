import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Upload, CheckCircle, X } from 'lucide-react';
import { toast } from 'sonner';

export default function SimpleImportDialog({ 
  open, 
  onClose, 
  onConfirm
}) {
  // ===== TOUS LES HOOKS EN HAUT - TOUJOURS APPELÉS =====
  const [file, setFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [gridSize, setGridSize] = useState(150);
  const [colorCount, setColorCount] = useState(40);
  const [isProcessing, setIsProcessing] = useState(false);

  // Reset quand le dialog s'ouvre
  useEffect(() => {
    if (open) {
      setFile(null);
      setPreviewUrl(null);
      setGridSize(150);
      setColorCount(40);
      setIsProcessing(false);
    }
  }, [open]);

  // Générer l'aperçu quand un fichier est sélectionné
  useEffect(() => {
    if (!file) {
      setPreviewUrl(null);
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      setPreviewUrl(e.target.result);
    };
    reader.readAsDataURL(file);
  }, [file]);

  // ===== FONCTIONS =====
  const handleFileSelect = (e) => {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;

    const extension = selectedFile.name.split('.').pop().toLowerCase();
    if (!['png', 'jpg', 'jpeg', 'pdf'].includes(extension)) {
      toast.error('Format non supporté. Utilisez PNG, JPG ou PDF.');
      return;
    }

    setFile(selectedFile);
  };

  const handleConfirm = () => {
    if (!file) {
      toast.error('Veuillez sélectionner un fichier');
      return;
    }

    if (gridSize < 50 || gridSize > 400) {
      toast.error('La taille doit être entre 50 et 400');
      return;
    }

    if (colorCount < 1 || colorCount > 90) {
      toast.error('Le nombre de couleurs doit être entre 1 et 90');
      return;
    }

    setIsProcessing(true);
    
    onConfirm?.({
      file,
      width: gridSize,
      height: gridSize,
      colorsCount: colorCount
    });
  };

  // ===== RENDER =====
  if (!open) return null;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-slate-900">Importer un visuel</h2>
            <button
              onClick={onClose}
              className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Content */}
          <div className="space-y-6">
            {/* File selector */}
            {!file && (
              <div className="border-2 border-dashed border-slate-300 rounded-lg p-8 text-center">
                <Upload className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                <p className="text-sm text-slate-600 mb-4">
                  Sélectionnez une image (PNG, JPG) ou un PDF
                </p>
                <label className="inline-block">
                  <input
                    type="file"
                    accept="image/png,image/jpeg,image/jpg,application/pdf"
                    onChange={handleFileSelect}
                    className="hidden"
                  />
                  <span className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 cursor-pointer inline-block">
                    Choisir un fichier
                  </span>
                </label>
              </div>
            )}

            {/* Preview + Config */}
            {file && previewUrl && (
              <div className="grid grid-cols-2 gap-6">
                {/* Preview */}
                <div>
                  <Label className="text-sm font-medium mb-2 block">Aperçu</Label>
                  <div className="border border-slate-200 rounded-lg overflow-hidden bg-slate-50">
                    <img 
                      src={previewUrl} 
                      alt="Aperçu" 
                      className="w-full h-auto"
                    />
                  </div>
                  <div className="mt-2 text-xs text-slate-600">
                    {file.name}
                  </div>
                </div>

                {/* Config */}
                <div className="space-y-4">
                  <div>
                    <Label className="text-sm font-medium mb-2 block">
                      Taille de la grille (en points)
                    </Label>
                    <Input
                      type="number"
                      min="50"
                      max="400"
                      value={gridSize}
                      onChange={(e) => setGridSize(Number(e.target.value))}
                    />
                    <div className="mt-1 text-xs text-slate-500">
                      Entre 50 et 400 points
                    </div>
                  </div>

                  <div>
                    <Label className="text-sm font-medium mb-2 block">
                      Nombre de couleurs maximum
                    </Label>
                    <Input
                      type="number"
                      min="1"
                      max="90"
                      value={colorCount}
                      onChange={(e) => setColorCount(Number(e.target.value))}
                    />
                    <div className="mt-1 text-xs text-slate-500">
                      Entre 1 et 90 couleurs DMC
                    </div>
                  </div>

                  <div className="p-3 bg-blue-50 rounded-lg text-xs text-slate-700">
                    💡 Plus la grille est grande et plus il y a de couleurs, plus le motif sera détaillé.
                  </div>

                  <Button
                    variant="outline"
                    onClick={() => {
                      setFile(null);
                      setPreviewUrl(null);
                    }}
                    className="w-full"
                  >
                    Choisir un autre fichier
                  </Button>
                </div>
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="flex items-center justify-end gap-3 mt-6 pt-6 border-t border-slate-200">
            <Button
              variant="outline"
              onClick={onClose}
              disabled={isProcessing}
            >
              Annuler
            </Button>
            <Button
              onClick={handleConfirm}
              disabled={!file || isProcessing}
              className="bg-green-600 hover:bg-green-700 text-white gap-2"
            >
              <CheckCircle className="w-4 h-4" />
              Générer la grille
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}