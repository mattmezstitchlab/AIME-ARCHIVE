import React from 'react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Eraser } from 'lucide-react';

const ERASER_TOOLS = [
  {
    id: 'gomme-selective',
    icon: '🧽',
    name: 'Gomme Sélective™',
    shortDesc: 'Effacer un symbole précis',
    description: 'Je n\'efface que CE symbole-là, partout ou en zone, sans toucher aux autres.',
    features: ['Ici uniquement', 'Partout dans la grille', 'Dans une zone'],
    color: '#A855F7',
  },
  {
    id: 'nettoyage-zone',
    icon: '🧼',
    name: 'Nettoyage de Zone™',
    shortDesc: 'Supprimer une zone entière',
    description: 'Je sélectionne un rectangle ou une forme, tout se nettoie proprement.',
    features: ['Rectangle', 'Lasso', 'Undo auto'],
    color: '#06B6D4',
  },
  {
    id: 'anti-bavure',
    icon: '🧹',
    name: 'Anti-Bavure™',
    shortDesc: 'Supprimer les points isolés',
    description: 'J\'efface automatiquement les pixels perdus, taches et symboles hors-pattern.',
    features: ['Points isolés', 'Pixels perdus', 'Auto-nettoyage'],
    color: '#10B981',
  },
];

export default function EraserToolsDropdown({ 
  children, 
  currentSubTool, 
  onSelectSubTool,
  open,
  onOpenChange 
}) {
  return (
    <DropdownMenu open={open} onOpenChange={onOpenChange}>
      <DropdownMenuTrigger asChild>
        {children}
      </DropdownMenuTrigger>
      <DropdownMenuContent 
        side="bottom" 
        align="start" 
        className="w-80 p-0 bg-[#1a1a1a] border-[#333] rounded-xl overflow-hidden"
        sideOffset={8}
      >
        {/* Header */}
        <div className="px-4 py-3 bg-gradient-to-r from-[#A855F7]/20 to-transparent border-b border-[#333]">
          <div className="flex items-center gap-2">
            <Eraser className="w-4 h-4 text-[#A855F7]" />
            <span className="text-white font-semibold text-sm">Outils de gomme</span>
          </div>
          <p className="text-[#888] text-xs mt-1">Effacez proprement, sans erreur</p>
        </div>

        {/* Tools list */}
        <div className="py-2">
          {ERASER_TOOLS.map((tool, index) => (
            <React.Fragment key={tool.id}>
              <DropdownMenuItem
                onClick={() => onSelectSubTool(tool.id)}
                className={`mx-2 px-3 py-3 rounded-lg cursor-pointer transition-all ${
                  currentSubTool === tool.id 
                    ? 'bg-white/10' 
                    : 'hover:bg-white/5'
                }`}
              >
                <div className="flex items-start gap-3 w-full">
                  {/* Icon circle */}
                  <div 
                    className="w-10 h-10 rounded-full flex items-center justify-center text-xl shrink-0"
                    style={{ backgroundColor: `${tool.color}20`, border: `2px solid ${tool.color}` }}
                  >
                    {tool.icon}
                  </div>
                  
                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-white font-semibold text-sm">{tool.name}</span>
                      {currentSubTool === tool.id && (
                        <span className="px-1.5 py-0.5 bg-[#A855F7] text-white text-[10px] font-bold rounded">
                          ACTIF
                        </span>
                      )}
                    </div>
                    <p className="text-[#A855F7] text-xs font-medium mt-0.5">{tool.shortDesc}</p>
                    <p className="text-[#888] text-xs mt-1 leading-relaxed">{tool.description}</p>
                    
                    {/* Features tags */}
                    <div className="flex flex-wrap gap-1 mt-2">
                      {tool.features.map((feature, i) => (
                        <span 
                          key={i}
                          className="px-2 py-0.5 bg-white/5 text-[#aaa] text-[10px] rounded-full"
                        >
                          ✓ {feature}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </DropdownMenuItem>
              
              {index < ERASER_TOOLS.length - 1 && (
                <div className="mx-4 my-1 h-px bg-[#333]" />
              )}
            </React.Fragment>
          ))}
        </div>

        {/* Footer */}
        <div className="px-4 py-2 bg-[#111] border-t border-[#333]">
          <p className="text-[#666] text-[10px] text-center">
            💡 Astuce : <kbd className="px-1 py-0.5 bg-[#333] rounded text-[#aaa]">Ctrl+Z</kbd> pour annuler une suppression
          </p>
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

export { ERASER_TOOLS };