import React from 'react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { ZoomIn, ZoomOut, RotateCcw, Target, Hand } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function ZoomControls({ 
  onZoomIn, 
  onZoomOut, 
  onResetZoom, 
  onCenter,
  onPanMode,
  isPanActive = false
}) {
  const iconClass = "w-5 h-5";
  
  return (
    <TooltipProvider delayDuration={300}>
      <div className="flex items-center justify-between gap-3 w-full">
        <Tooltip>
          <TooltipTrigger asChild>
            <button
              onClick={onZoomIn}
              className="flex items-center justify-center h-[34px] w-[34px] rounded-lg hover:bg-[#F4F4F4] transition-all hover:scale-110 text-black"
            >
              <ZoomIn className={iconClass} />
            </button>
          </TooltipTrigger>
          <TooltipContent side="bottom">
            <p>Zoom +</p>
          </TooltipContent>
        </Tooltip>

        <Tooltip>
          <TooltipTrigger asChild>
            <button
              onClick={onZoomOut}
              className="flex items-center justify-center h-[34px] w-[34px] rounded-lg hover:bg-[#F4F4F4] transition-all hover:scale-110 text-black"
            >
              <ZoomOut className={iconClass} />
            </button>
          </TooltipTrigger>
          <TooltipContent side="bottom">
            <p>Zoom –</p>
          </TooltipContent>
        </Tooltip>

        <Tooltip>
          <TooltipTrigger asChild>
            <button
              onClick={onResetZoom}
              className="flex items-center justify-center h-[34px] w-[34px] rounded-lg hover:bg-[#F4F4F4] transition-all hover:scale-110 text-black"
            >
              <RotateCcw className={iconClass} />
            </button>
          </TooltipTrigger>
          <TooltipContent side="bottom">
            <p>Réinitialiser</p>
          </TooltipContent>
        </Tooltip>

        <Tooltip>
          <TooltipTrigger asChild>
            <button
              onClick={onCenter}
              className="flex items-center justify-center h-[34px] w-[34px] rounded-lg hover:bg-[#F4F4F4] transition-all hover:scale-110 text-black"
            >
              <Target className={iconClass} />
            </button>
          </TooltipTrigger>
          <TooltipContent side="bottom">
            <p>Centrer</p>
          </TooltipContent>
        </Tooltip>

        <Tooltip>
          <TooltipTrigger asChild>
            <button
              onClick={onPanMode}
              className={cn(
                "flex items-center justify-center h-[34px] w-[34px] rounded-lg transition-all hover:scale-110",
                isPanActive 
                  ? "bg-[#F5C200] text-black" 
                  : "hover:bg-[#F4F4F4] text-black"
              )}
            >
              <Hand className={iconClass} />
            </button>
          </TooltipTrigger>
          <TooltipContent side="bottom">
            <p>Déplacer</p>
          </TooltipContent>
        </Tooltip>
      </div>
    </TooltipProvider>
  );
}