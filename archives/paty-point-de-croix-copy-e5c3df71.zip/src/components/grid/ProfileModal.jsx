import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { toast } from 'sonner';
import { User, Check, X } from 'lucide-react';

export default function ProfileModal({ onClose }) {
  const queryClient = useQueryClient();

  // Fetch user data
  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  // Fetch user profile
  const { data: profiles } = useQuery({
    queryKey: ['userProfile', user?.email],
    queryFn: () => base44.entities.UserProfile.filter({ created_by: user?.email }),
    enabled: !!user?.email,
  });

  const profile = profiles?.[0] || {};

  // Local state for editing
  const [formData, setFormData] = useState({
    prenom: '',
    nom: '',
    pays: '',
    adresse_actuelle: '',
  });

  useEffect(() => {
    if (profile) {
      setFormData({
        prenom: profile.prenom || '',
        nom: profile.nom || '',
        pays: profile.pays || '',
        adresse_actuelle: profile.adresse_actuelle || '',
      });
    }
  }, [profile]);

  const updateProfile = useMutation({
    mutationFn: async (data) => {
      if (profiles?.[0]?.id) {
        return base44.entities.UserProfile.update(profiles[0].id, data);
      } else {
        return base44.entities.UserProfile.create(data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['userProfile']);
      toast.success('✅ Profil mis à jour');
    },
  });

  return (
    <div 
      className="fixed inset-0 z-[100] flex items-center justify-center"
      style={{ backgroundColor: 'rgba(0,0,0,0.8)' }}
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <div 
        className="bg-[#111] rounded-2xl shadow-2xl overflow-hidden border border-[#333]"
        style={{ width: '90%', maxWidth: '500px' }}
      >
        {/* Header */}
        <div className="bg-black text-white px-6 py-4 flex items-center justify-between border-b border-[#333]">
          <div className="flex items-center gap-3">
            <User className="w-5 h-5 text-[#FFC94A]" />
            <h2 className="font-bold text-lg">Profil</h2>
          </div>
          <button
            onClick={onClose}
            className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          <Card className="bg-[#1a1a1a] border-[#333]">
            <CardContent className="p-6 space-y-6">
              {/* Avatar */}
              <div className="flex justify-center">
                <Avatar className="w-20 h-20 border-2 border-[#FFC94A]">
                  <AvatarImage src={profile?.photo_url} />
                  <AvatarFallback className="bg-[#FFC94A] text-black font-bold text-2xl">
                    {user?.full_name?.charAt(0) || 'U'}
                  </AvatarFallback>
                </Avatar>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-gray-300">Prénom</Label>
                  <Input 
                    value={formData.prenom} 
                    onChange={(e) => setFormData({...formData, prenom: e.target.value})}
                    placeholder="Votre prénom"
                    className="bg-[#222] border-[#444] text-white placeholder:text-gray-500"
                  />
                </div>
                <div>
                  <Label className="text-gray-300">Nom</Label>
                  <Input 
                    value={formData.nom} 
                    onChange={(e) => setFormData({...formData, nom: e.target.value})}
                    placeholder="Votre nom"
                    className="bg-[#222] border-[#444] text-white placeholder:text-gray-500"
                  />
                </div>
              </div>

              <div>
                <Label className="text-gray-300">Email</Label>
                <Input value={user?.email || ''} disabled className="bg-[#222] border-[#444] text-gray-400" />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-gray-300">Pays</Label>
                  <Input 
                    value={formData.pays} 
                    onChange={(e) => setFormData({...formData, pays: e.target.value})}
                    placeholder="France"
                    className="bg-[#222] border-[#444] text-white placeholder:text-gray-500"
                  />
                </div>
                <div>
                  <Label className="text-gray-300">Adresse</Label>
                  <Input 
                    value={formData.adresse_actuelle} 
                    onChange={(e) => setFormData({...formData, adresse_actuelle: e.target.value})}
                    placeholder="Votre adresse"
                    className="bg-[#222] border-[#444] text-white placeholder:text-gray-500"
                  />
                </div>
              </div>

              <Button 
                className="w-full bg-[#FFC94A] hover:bg-[#F59E0B] text-black font-semibold"
                onClick={() => updateProfile.mutate(formData)}
                disabled={updateProfile.isPending}
              >
                <Check className="w-4 h-4 mr-2" />
                {updateProfile.isPending ? 'Enregistrement...' : 'Enregistrer'}
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}