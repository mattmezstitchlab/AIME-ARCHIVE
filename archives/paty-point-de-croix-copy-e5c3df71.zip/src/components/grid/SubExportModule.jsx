import React, { useState, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { 
  X, Download, FileText, Image, Zap, Store, 
  Check, Loader2, Shield, Lock, Archive, Share2
} from 'lucide-react';
import { toast } from 'sonner';
import { createSubFile, SUB_FORMAT } from './subFormat';

export default function SubExportModule({ open, onClose, pattern, gridConfig }) {
  const [activeTab, setActiveTab] = useState('sub');
  const [isExporting, setIsExporting] = useState(false);
  const [exportComplete, setExportComplete] = useState(false);
  
  // Options d'export
  const [pdfOptions, setPdfOptions] = useState({
    dpi: 300,
    multipage: true,
    includeInfo: true,
    reinforcedSymbols: true
  });
  
  const [imageOptions, setImageOptions] = useState({
    format: 'png',
    width: 2000,
    watermark: false
  });
  
  const [shopOptions, setShopOptions] = useState({
    title: '',
    description: '',
    price: 4.99,
    category: 'patterns'
  });

  // Stats du pattern
  const stats = useMemo(() => {
    if (!pattern?.symbolGrid) return null;
    
    let totalPoints = 0;
    let zeroHoles = true;
    const colors = new Set();
    
    pattern.symbolGrid.forEach(row => {
      row.forEach(cell => {
        if (cell) {
          totalPoints++;
          colors.add(cell.colorId);
        } else {
          zeroHoles = false;
        }
      });
    });
    
    return {
      totalPoints,
      zeroHoles,
      colors: colors.size,
      width: pattern.width,
      height: pattern.height
    };
  }, [pattern]);

  // Hash d'intégrité
  const generateHash = (data) => {
    const str = JSON.stringify(data);
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      hash = ((hash << 5) - hash) + str.charCodeAt(i);
      hash = hash & hash;
    }
    return 'SUB-' + Math.abs(hash).toString(16).toUpperCase().padStart(8, '0');
  };

  // Export .SUB officiel
  const handleExportSub = async () => {
    if (!pattern) return;
    setIsExporting(true);

    try {
      await new Promise(r => setTimeout(r, 500));

      const subFile = createSubFile(pattern, {
        name: gridConfig?.name || 'grille_sub',
        author: 'PatyBee User',
        version: SUB_FORMAT.version
      });

      // Ajouter métadonnées complètes
      subFile.metadata = {
        ...subFile.metadata,
        exportDate: new Date().toISOString(),
        zeroHole: stats?.zeroHoles,
        encrypted: false,
        history: true
      };

      // Hash d'intégrité
      subFile.integrity = {
        hash: generateHash(subFile),
        verified: true,
        timestamp: new Date().toISOString()
      };

      const jsonString = JSON.stringify(subFile, null, 2);
      const blob = new Blob([jsonString], { type: 'application/x-sub' });
      downloadBlob(blob, `${gridConfig?.name || 'grille'}.sub`);

      setExportComplete(true);
      toast.success('✅ EXPORT SUB TERMINÉ — fichier prêt à être partagé ou vendu.');
    } catch (error) {
      toast.error('Erreur lors de l\'export');
    } finally {
      setIsExporting(false);
    }
  };

  // Export PDF HD
  const handleExportPDF = async () => {
    if (!pattern) return;
    setIsExporting(true);

    try {
      const { jsPDF } = await import('jspdf');
      await new Promise(r => setTimeout(r, 300));

      const doc = new jsPDF({
        orientation: pattern.width > pattern.height ? 'landscape' : 'portrait',
        unit: 'mm',
        format: 'a4'
      });

      const pageWidth = doc.internal.pageSize.getWidth();
      const pageHeight = doc.internal.pageSize.getHeight();

      // Page couverture
      if (pdfOptions.includeInfo) {
        doc.setFontSize(24);
        doc.text(gridConfig?.name || 'Grille SUB', pageWidth / 2, 40, { align: 'center' });
        
        doc.setFontSize(12);
        doc.text(`Dimensions: ${pattern.width} × ${pattern.height} points`, pageWidth / 2, 60, { align: 'center' });
        doc.text(`Couleurs: ${stats?.colors || 0} DMC`, pageWidth / 2, 70, { align: 'center' });
        doc.text(`Points totaux: ${stats?.totalPoints?.toLocaleString() || 0}`, pageWidth / 2, 80, { align: 'center' });
        
        // Badge Zéro Trou
        if (stats?.zeroHoles) {
          doc.setFillColor(34, 197, 94);
          doc.roundedRect(pageWidth / 2 - 30, 95, 60, 12, 3, 3, 'F');
          doc.setTextColor(255, 255, 255);
          doc.setFontSize(10);
          doc.text('✅ Zéro Trou SUB', pageWidth / 2, 103, { align: 'center' });
          doc.setTextColor(0, 0, 0);
        }

        doc.addPage();
      }

      // Page palette
      doc.setFontSize(16);
      doc.text('Palette DMC', 20, 20);
      
      let y = 35;
      pattern.colorPalette?.forEach((color, idx) => {
        if (y > pageHeight - 20) {
          doc.addPage();
          y = 20;
        }
        
        // Carré couleur
        const [r, g, b] = (color.hex || '#000000').replace('#', '').match(/.{2}/g).map(h => parseInt(h, 16));
        doc.setFillColor(r, g, b);
        doc.rect(20, y - 4, 8, 8, 'F');
        
        // Infos
        doc.setFontSize(10);
        doc.text(`${color.code || color.dmc || `Couleur ${idx + 1}`}`, 32, y);
        doc.text(`${color.symbol || color.assignedSymbolChar || '●'}`, 80, y);
        doc.text(`${color.totalCount || color.count || 0} pts`, 100, y);
        
        y += 12;
      });

      // Sauvegarder
      doc.save(`${gridConfig?.name || 'grille'}_SUB_HD.pdf`);
      toast.success('PDF HD exporté avec succès');
    } catch (error) {
      toast.error('Erreur lors de l\'export PDF');
    } finally {
      setIsExporting(false);
    }
  };

  // Export Image
  const handleExportImage = async () => {
    if (!pattern) return;
    setIsExporting(true);

    try {
      const canvas = document.createElement('canvas');
      const cellSize = Math.floor(imageOptions.width / pattern.width);
      canvas.width = pattern.width * cellSize;
      canvas.height = pattern.height * cellSize;
      const ctx = canvas.getContext('2d');

      // Fond blanc
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Dessiner les points
      pattern.symbolGrid.forEach((row, rowIdx) => {
        row.forEach((cell, colIdx) => {
          if (cell) {
            const color = pattern.colorPalette?.find(c => c.id === cell.colorId);
            const x = colIdx * cellSize;
            const y = rowIdx * cellSize;
            
            // Couleur de fond
            ctx.fillStyle = color?.hex || color?.dmcHex || '#cccccc';
            ctx.fillRect(x, y, cellSize, cellSize);
            
            // Symbole
            ctx.fillStyle = '#000000';
            ctx.font = `${cellSize * 0.6}px Arial`;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(
              cell.symbol || color?.symbol || color?.assignedSymbolChar || '●',
              x + cellSize / 2,
              y + cellSize / 2
            );
          }
        });
      });

      // Watermark optionnel
      if (imageOptions.watermark) {
        ctx.fillStyle = 'rgba(0, 0, 0, 0.1)';
        ctx.font = '24px Arial';
        ctx.textAlign = 'center';
        ctx.fillText('PatyBee SUB™', canvas.width / 2, canvas.height - 30);
      }

      canvas.toBlob((blob) => {
        downloadBlob(blob, `${gridConfig?.name || 'grille'}_SUB.${imageOptions.format}`);
        toast.success('Image exportée avec succès');
      }, `image/${imageOptions.format}`, 0.95);

    } catch (error) {
      toast.error('Erreur lors de l\'export image');
    } finally {
      setIsExporting(false);
    }
  };

  // Mise en vente boutique
  const handlePublishToShop = async () => {
    if (!shopOptions.title) {
      toast.error('Veuillez entrer un titre');
      return;
    }
    
    setIsExporting(true);
    await new Promise(r => setTimeout(r, 800));
    
    toast.success('Création mise en vente ! Commission PatyBee/SUB : 22%');
    setIsExporting(false);
    onClose();
  };

  const downloadBlob = (blob, filename) => {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  if (!open) return null;

  const tabs = [
    { id: 'sub', label: '.SUB', icon: Zap, color: 'bg-yellow-500' },
    { id: 'pdf', label: 'PDF HD', icon: FileText, color: 'bg-gray-500' },
    { id: 'image', label: 'Image', icon: Image, color: 'bg-gray-500' },
    { id: 'shop', label: 'Boutique', icon: Store, color: 'bg-purple-500' }
  ];

  return (
    <div className="fixed inset-0 z-[99999] flex items-center justify-center bg-black/70">
      <div className="bg-white rounded-2xl shadow-2xl w-[700px] max-h-[85vh] overflow-hidden">
        {/* Header */}
        <div className="bg-black px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-yellow-400 to-orange-500 flex items-center justify-center">
              <Download className="w-5 h-5 text-black" />
            </div>
            <div>
              <h2 className="text-lg font-black text-white">EXPORTATION SUB</h2>
              <p className="text-sm text-gray-400">Partager, vendre, archiver</p>
            </div>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center">
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b">
          {tabs.map(tab => {
            const TabIcon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex-1 px-4 py-3 flex items-center justify-center gap-2 font-medium transition-colors ${
                  activeTab === tab.id ? 'bg-gray-100 border-b-2 border-black' : 'hover:bg-gray-50'
                }`}
              >
                <TabIcon className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto" style={{ maxHeight: 'calc(85vh - 180px)' }}>
          {/* Export .SUB */}
          {activeTab === 'sub' && (
            <div className="space-y-6">
              <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4">
                <h3 className="font-bold text-yellow-800 flex items-center gap-2">
                  <Zap className="w-5 h-5" />
                  Format .SUB Officiel
                </h3>
                <p className="text-sm text-yellow-700 mt-1">
                  Format universel compressé, aucun symbole perdu, historique inclus.
                </p>
              </div>

              <div className="bg-gray-50 rounded-lg p-4 space-y-2">
                <div className="font-medium mb-2">Contenu du fichier .SUB :</div>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div className="flex items-center gap-2"><Check className="w-4 h-4 text-green-500" />Grille complète</div>
                  <div className="flex items-center gap-2"><Check className="w-4 h-4 text-green-500" />Couleurs DMC</div>
                  <div className="flex items-center gap-2"><Check className="w-4 h-4 text-green-500" />Symboles attribués</div>
                  <div className="flex items-center gap-2"><Check className="w-4 h-4 text-green-500" />Paramètres visuels</div>
                  <div className="flex items-center gap-2"><Check className="w-4 h-4 text-green-500" />Métadonnées</div>
                  <div className="flex items-center gap-2">
                    <Shield className="w-4 h-4 text-green-500" />
                    Statut Zéro Trou {stats?.zeroHoles ? '✅' : '⚠️'}
                  </div>
                </div>
              </div>

              <Button
                onClick={handleExportSub}
                disabled={isExporting || !pattern}
                className="w-full h-14 bg-gradient-to-r from-yellow-400 to-yellow-500 hover:from-yellow-500 hover:to-yellow-600 text-black font-bold text-lg"
              >
                {isExporting ? <Loader2 className="w-5 h-5 animate-spin mr-2" /> : <Zap className="w-5 h-5 mr-2" />}
                Exporter en .SUB
              </Button>
            </div>
          )}

          {/* Export PDF */}
          {activeTab === 'pdf' && (
            <div className="space-y-4">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label>Résolution 300 DPI</Label>
                  <Switch checked={pdfOptions.dpi === 300} onCheckedChange={(v) => setPdfOptions(p => ({...p, dpi: v ? 300 : 150}))} />
                </div>
                <div className="flex items-center justify-between">
                  <Label>Multipage automatique</Label>
                  <Switch checked={pdfOptions.multipage} onCheckedChange={(v) => setPdfOptions(p => ({...p, multipage: v}))} />
                </div>
                <div className="flex items-center justify-between">
                  <Label>Page infos (titre, palette)</Label>
                  <Switch checked={pdfOptions.includeInfo} onCheckedChange={(v) => setPdfOptions(p => ({...p, includeInfo: v}))} />
                </div>
                <div className="flex items-center justify-between">
                  <Label>Symboles renforcés</Label>
                  <Switch checked={pdfOptions.reinforcedSymbols} onCheckedChange={(v) => setPdfOptions(p => ({...p, reinforcedSymbols: v}))} />
                </div>
              </div>

              <Button onClick={handleExportPDF} disabled={isExporting || !pattern} variant="outline" className="w-full h-12">
                {isExporting ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <FileText className="w-4 h-4 mr-2" />}
                Exporter en PDF HD
              </Button>
            </div>
          )}

          {/* Export Image */}
          {activeTab === 'image' && (
            <div className="space-y-4">
              <div className="space-y-3">
                <div>
                  <Label>Format</Label>
                  <div className="flex gap-2 mt-2">
                    {['png', 'jpg'].map(f => (
                      <button
                        key={f}
                        onClick={() => setImageOptions(p => ({...p, format: f}))}
                        className={`px-4 py-2 rounded-lg border font-medium ${imageOptions.format === f ? 'bg-black text-white' : ''}`}
                      >
                        {f.toUpperCase()}
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <Label>Largeur (px)</Label>
                  <Input 
                    type="number" 
                    value={imageOptions.width} 
                    onChange={(e) => setImageOptions(p => ({...p, width: Number(e.target.value)}))}
                    className="mt-1"
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label>Ajouter watermark</Label>
                  <Switch checked={imageOptions.watermark} onCheckedChange={(v) => setImageOptions(p => ({...p, watermark: v}))} />
                </div>
              </div>

              <Button onClick={handleExportImage} disabled={isExporting || !pattern} variant="outline" className="w-full h-12">
                {isExporting ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Image className="w-4 h-4 mr-2" />}
                Exporter en IMAGE
              </Button>
            </div>
          )}

          {/* Boutique */}
          {activeTab === 'shop' && (
            <div className="space-y-4">
              <div className="bg-purple-50 border border-purple-200 rounded-lg p-3">
                <p className="text-sm text-purple-800">
                  <strong>Commission PatyBee/SUB :</strong> 22%
                </p>
              </div>

              <div className="space-y-3">
                <div>
                  <Label>Titre de la création</Label>
                  <Input 
                    value={shopOptions.title} 
                    onChange={(e) => setShopOptions(p => ({...p, title: e.target.value}))}
                    placeholder="Mon motif SUB"
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label>Description</Label>
                  <Textarea 
                    value={shopOptions.description} 
                    onChange={(e) => setShopOptions(p => ({...p, description: e.target.value}))}
                    placeholder="Décrivez votre création..."
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label>Prix (€)</Label>
                  <Input 
                    type="number" 
                    step="0.01"
                    value={shopOptions.price} 
                    onChange={(e) => setShopOptions(p => ({...p, price: Number(e.target.value)}))}
                    className="mt-1"
                  />
                </div>
              </div>

              <Button onClick={handlePublishToShop} disabled={isExporting} className="w-full h-12 bg-purple-600 hover:bg-purple-700">
                {isExporting ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Store className="w-4 h-4 mr-2" />}
                Mettre en vente
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}