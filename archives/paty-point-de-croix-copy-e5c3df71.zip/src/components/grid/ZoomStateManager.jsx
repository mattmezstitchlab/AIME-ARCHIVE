import React, { createContext, useContext, useState } from 'react';

/**
 * ZOOM 5D™ STATE MANAGER
 * Gestion centralisée de l'état du zoom
 */

const ZoomStateContext = createContext(null);

export function ZoomStateProvider({ children }) {
  const [zoomLevel, setZoomLevel] = useState(1);
  const [actualZoomValue, setActualZoomValue] = useState(1.0);
  const [viewCenter, setViewCenter] = useState({ x: 0, y: 0 });
  const [viewBox, setViewBox] = useState({ x: 0, y: 0, width: 0, height: 0 });
  const [activeColorId, setActiveColorId] = useState(null);
  const [iaFocusEnabled, setIaFocusEnabled] = useState(true);
  const [iaFocusMode, setIaFocusMode] = useState('auto');
  const [isAnimating, setIsAnimating] = useState(false);
  const [miniMapSync, setMiniMapSync] = useState(true);

  const state = {
    zoomLevel,
    zoomMin: 0,
    zoomMax: 4,
    actualZoomValue,
    viewCenter,
    viewBox,
    activeColorId,
    iaFocusEnabled,
    iaFocusMode,
    isAnimating,
    animationDuration: 220,
    miniMapSync,
    setZoomLevel,
    setActualZoomValue,
    setViewCenter,
    setViewBox,
    setActiveColorId,
    setIaFocusEnabled,
    setIaFocusMode,
    setIsAnimating,
    setMiniMapSync,
    canZoomIn: () => zoomLevel < 4,
    canZoomOut: () => zoomLevel > 0,
    reset: () => {
      setZoomLevel(1);
      setActualZoomValue(1.0);
      setViewCenter({ x: 0, y: 0 });
      setViewBox({ x: 0, y: 0, width: 0, height: 0 });
      setActiveColorId(null);
      setIsAnimating(false);
    }
  };

  return (
    <ZoomStateContext.Provider value={state}>
      {children}
    </ZoomStateContext.Provider>
  );
}

export function useZoomState() {
  const context = useContext(ZoomStateContext);
  if (!context) {
    // Retourner un objet par défaut au lieu de lancer une erreur
    return {
      zoomLevel: 1,
      zoomMin: 0,
      zoomMax: 4,
      actualZoomValue: 1.0,
      viewCenter: { x: 0, y: 0 },
      viewBox: { x: 0, y: 0, width: 0, height: 0 },
      activeColorId: null,
      iaFocusEnabled: true,
      iaFocusMode: 'auto',
      isAnimating: false,
      animationDuration: 220,
      miniMapSync: true,
      setZoomLevel: () => {},
      setActualZoomValue: () => {},
      setViewCenter: () => {},
      setViewBox: () => {},
      setActiveColorId: () => {},
      setIaFocusEnabled: () => {},
      setIaFocusMode: () => {},
      setIsAnimating: () => {},
      setMiniMapSync: () => {},
      canZoomIn: () => true,
      canZoomOut: () => true,
      reset: () => {}
    };
  }
  return context;
}

/**
 * Configuration de rendu selon le niveau de zoom
 */
export const getZoomRenderConfig = (zoomLevel, actualZoomValue) => {
  const configs = {
    0: {
      name: 'Global',
      color: 'bg-blue-500',
      showGrid: false,
      showSymbols: false,
      showPattern: true,
      showProgress: true,
      patternOpacity: 0.8,
      symbolOpacity: 0,
      gridEvery: 50,
      showMosaicGuides: false,
      showCenterMarker: false,
      showNumbers: false,
      cellHighlight: false
    },
    1: {
      name: '10×10',
      color: 'bg-green-500',
      showGrid: true,
      showSymbols: false,
      showPattern: true,
      showProgress: true,
      patternOpacity: 0.6,
      symbolOpacity: 0.3,
      gridEvery: 10,
      showMosaicGuides: true,
      showCenterMarker: true,
      showNumbers: true,
      cellHighlight: false
    },
    2: {
      name: 'Détail',
      color: 'bg-yellow-500',
      showGrid: true,
      showSymbols: true,
      showPattern: true,
      showProgress: true,
      patternOpacity: 0.4,
      symbolOpacity: 0.8,
      gridEvery: 10,
      showMosaicGuides: true,
      showCenterMarker: true,
      showNumbers: true,
      cellHighlight: false
    },
    3: {
      name: 'Point',
      color: 'bg-orange-500',
      showGrid: true,
      showSymbols: true,
      showPattern: true,
      showProgress: true,
      patternOpacity: 0.2,
      symbolOpacity: 1.0,
      gridEvery: 1,
      showMosaicGuides: true,
      showCenterMarker: true,
      showNumbers: true,
      cellHighlight: true,
      cellHighlightIntensity: 'low'
    },
    4: {
      name: 'Microscope',
      color: 'bg-red-500',
      showGrid: true,
      showSymbols: true,
      showPattern: false,
      showProgress: true,
      patternOpacity: 0,
      symbolOpacity: 1.0,
      gridEvery: 1,
      showMosaicGuides: false,
      showCenterMarker: false,
      showNumbers: true,
      cellHighlight: true,
      cellHighlightIntensity: 'high',
      pulseAnimation: true
    }
  };
  
  return configs[zoomLevel] || configs[1];
};

/**
 * Détection intelligente du niveau optimal
 */
export const detectOptimalZoomLevel = (context) => {
  const { density, hasSymbols, isDetailed, isIsolated } = context;
  
  // Point isolé → microscope
  if (isIsolated) return 4;
  
  // Zone détaillée → stitch
  if (isDetailed) return 3;
  
  // Zone avec symboles → détail
  if (hasSymbols) return 2;
  
  // Densité élevée → 10x10
  if (density > 0.5) return 1;
  
  // Par défaut → global
  return 0;
};