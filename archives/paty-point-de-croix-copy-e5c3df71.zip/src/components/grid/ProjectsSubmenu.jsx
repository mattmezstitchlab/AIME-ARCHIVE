import React, { useState, useMemo, useRef, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import {
  FolderOpen,
  Calendar,
  Clock,
  CheckCircle,
  PlayCircle,
  MoreVertical,
  Eye,
  Pencil,
  Trash2,
  Type,
  Loader2,
  X,
  AlertTriangle,
  ExternalLink
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { toast } from 'sonner';
import ProjectPreviewDialog from './ProjectPreviewDialog';
import ProjectsFullModal from './ProjectsFullModal';

const FILTERS = [
  { id: 'recent', label: 'Plus récent', icon: Clock },
  { id: 'date', label: 'Par date', icon: Calendar },
  { id: 'in_progress', label: 'En cours', icon: PlayCircle },
  { id: 'completed', label: 'Terminé', icon: CheckCircle },
];

// Composant miniature pour afficher un aperçu du projet
function ProjectThumbnail({ project }) {
  const canvasRef = useRef(null);

  useEffect(() => {
    if (!canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const pattern = project.pattern;

    ctx.fillStyle = '#222';
    ctx.fillRect(0, 0, 40, 40);

    if (!pattern?.symbolGrid) {
      ctx.fillStyle = '#444';
      ctx.font = '16px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('?', 20, 26);
      return;
    }

    const grid = pattern.symbolGrid;
    const rows = grid.length;
    const cols = grid[0]?.length || 0;
    if (rows === 0 || cols === 0) return;

    const cellSize = Math.min(40 / cols, 40 / rows, 2);
    const offsetX = (40 - cols * cellSize) / 2;
    const offsetY = (40 - rows * cellSize) / 2;

    for (let row = 0; row < rows; row++) {
      for (let col = 0; col < cols; col++) {
        const cell = grid[row]?.[col];
        if (cell?.color) {
          ctx.fillStyle = cell.color;
          ctx.fillRect(
            offsetX + col * cellSize,
            offsetY + row * cellSize,
            cellSize,
            cellSize
          );
        }
      }
    }
  }, [project]);

  return (
    <canvas
      ref={canvasRef}
      width={40}
      height={40}
      className="rounded-lg flex-shrink-0"
    />
  );
}

// Calcul du statut du projet
function getProjectStatus(project) {
  const grid = project.pattern?.symbolGrid;
  if (!grid) return null;
  const total = grid.flat().filter(c => c).length;
  const done = grid.flat().filter(c => c?.done).length;
  if (total === 0) return null;
  if (done === total) return 'completed';
  return 'in_progress';
}

export default function ProjectsSubmenu({ open, onOpenChange, onSelectProject, onClose }) {
  const [activeFilter, setActiveFilter] = useState('recent');
  const [renameId, setRenameId] = useState(null);
  const [renameValue, setRenameValue] = useState('');
  const [previewProject, setPreviewProject] = useState(null);
  const [deleteProject, setDeleteProject] = useState(null);
  const [showFullModal, setShowFullModal] = useState(false);
  const queryClient = useQueryClient();

  // Charger les projets
  const { data: projects = [], isLoading } = useQuery({
    queryKey: ['grids'],
    queryFn: () => base44.entities.Grid.list('-updated_date'),
    enabled: open,
  });

  // Mutation pour supprimer
  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Grid.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['grids'] });
      toast.success('Projet supprimé');
    },
  });

  // Mutation pour renommer
  const renameMutation = useMutation({
    mutationFn: ({ id, name }) => base44.entities.Grid.update(id, { name }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['grids'] });
      toast.success('Projet renommé');
      setRenameId(null);
    },
  });

  // Filtrer et trier les projets
  const filteredProjects = useMemo(() => {
    let result = [...projects];

    switch (activeFilter) {
      case 'recent':
        result.sort((a, b) => new Date(b.updated_date) - new Date(a.updated_date));
        break;
      case 'date':
        result.sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
        break;
      case 'in_progress':
        result = result.filter(p => {
          const grid = p.pattern?.symbolGrid;
          if (!grid) return true;
          const total = grid.flat().filter(c => c).length;
          const done = grid.flat().filter(c => c?.done).length;
          return done < total;
        });
        break;
      case 'completed':
        result = result.filter(p => {
          const grid = p.pattern?.symbolGrid;
          if (!grid) return false;
          const total = grid.flat().filter(c => c).length;
          const done = grid.flat().filter(c => c?.done).length;
          return total > 0 && done === total;
        });
        break;
    }

    return result;
  }, [projects, activeFilter]);

  const handleRename = (project) => {
    setRenameId(project.id);
    setRenameValue(project.name || '');
  };

  const submitRename = () => {
    if (renameId && renameValue.trim()) {
      renameMutation.mutate({ id: renameId, name: renameValue.trim() });
    }
  };

  const handleDelete = (project) => {
    setDeleteProject(project);
  };

  const confirmDelete = () => {
    if (deleteProject) {
      deleteMutation.mutate(deleteProject.id);
      setDeleteProject(null);
    }
  };

  const handleView = (project) => {
    setPreviewProject(project);
  };

  const handleEdit = (project) => {
    // Stocker l'ID du projet à charger et recharger la page
    localStorage.setItem('loadProjectId', project.id);
    window.location.reload();
  };

  const handleRowClick = (project) => {
    handleEdit(project);
  };

  const handleDoubleClick = (project) => {
    handleEdit(project);
  };

  if (!open) return null;

  return (
    <>
      {/* Modale pleine page des projets */}
      <ProjectsFullModal
        open={showFullModal}
        onClose={() => setShowFullModal(false)}
        activeFilter={activeFilter}
        setActiveFilter={setActiveFilter}
      />

      {/* Dialog de confirmation de suppression */}
      <AlertDialog open={!!deleteProject} onOpenChange={() => setDeleteProject(null)}>
        <AlertDialogContent className="bg-[#1a1a1a] border-[#333]">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-white flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-red-500" />
              Supprimer ce projet ?
            </AlertDialogTitle>
            <AlertDialogDescription className="text-gray-400">
              Le projet "{deleteProject?.name || 'Sans titre'}" sera définitivement supprimé.
              Cette action est irréversible.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-white/10 text-white border-0 hover:bg-white/20">
              Annuler
            </AlertDialogCancel>
            <AlertDialogAction 
              onClick={confirmDelete}
              className="bg-red-600 text-white hover:bg-red-700"
            >
              Supprimer
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Dialog d'aperçu */}
      <ProjectPreviewDialog
        project={previewProject}
        open={!!previewProject}
        onClose={() => setPreviewProject(null)}
      />

      <div 
        className="fixed inset-0 z-[300]"
        onClick={() => onOpenChange(false)}
      >
        <div 
          className="absolute top-16 right-4 w-96 bg-[#1a1a1a] border border-[#333] rounded-xl shadow-2xl overflow-hidden flex flex-col"
          style={{ maxHeight: 'calc(100vh - 100px)' }}
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="px-4 py-3 border-b border-[#333] flex items-center justify-between flex-shrink-0">
            <div className="flex items-center gap-2">
              <FolderOpen className="w-5 h-5 text-[#FFC94A]" />
              <span className="font-bold text-white">PROJETS</span>
            </div>
            <div className="flex items-center gap-1">
              <button 
                onClick={() => setShowFullModal(true)}
                className="px-2 py-1 bg-[#FFC94A] hover:bg-[#FFD666] text-black text-xs font-semibold rounded-lg flex items-center gap-1 transition-colors"
              >
                <ExternalLink className="w-3 h-3" />
                Ouvrir
              </button>
              <button 
                onClick={() => onOpenChange(false)}
                className="p-1 hover:bg-white/10 rounded"
              >
                <X className="w-4 h-4 text-gray-400" />
              </button>
            </div>
          </div>

          {/* Filtres */}
          <div className="px-3 py-2 border-b border-[#333] flex gap-1 overflow-x-auto flex-shrink-0">
            {FILTERS.map(filter => (
              <button
                key={filter.id}
                onClick={() => setActiveFilter(filter.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap flex items-center gap-1.5 transition-colors ${
                  activeFilter === filter.id
                    ? 'bg-[#FFC94A] text-black'
                    : 'bg-white/5 text-gray-300 hover:bg-white/10'
                }`}
              >
                <filter.icon className="w-3 h-3" />
                {filter.label}
              </button>
            ))}
          </div>

          {/* Liste des projets - scrollable */}
          <div className="flex-1 overflow-y-auto">
            {isLoading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="w-6 h-6 animate-spin text-gray-400" />
              </div>
            ) : filteredProjects.length === 0 ? (
              <div className="text-center py-8 text-gray-500 text-sm">
                Aucun projet
              </div>
            ) : (
              filteredProjects.map(project => {
                const status = getProjectStatus(project);
                
                return (
                  <div
                    key={project.id}
                    onClick={() => handleRowClick(project)}
                    onDoubleClick={() => handleDoubleClick(project)}
                    className="px-3 py-3 hover:bg-white/5 border-b border-[#222] last:border-0 flex items-center gap-3 cursor-pointer transition-colors"
                  >
                    {/* Vignette du projet */}
                    <ProjectThumbnail project={project} />

                    {/* Infos */}
                    <div className="flex-1 min-w-0">
                      {renameId === project.id ? (
                        <input
                          type="text"
                          value={renameValue}
                          onChange={(e) => setRenameValue(e.target.value)}
                          onBlur={submitRename}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') submitRename();
                            if (e.key === 'Escape') setRenameId(null);
                          }}
                          onClick={(e) => e.stopPropagation()}
                          className="w-full bg-white/10 border border-[#FFC94A] rounded px-2 py-1 text-sm text-white focus:outline-none"
                          autoFocus
                        />
                      ) : (
                        <>
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-medium text-white truncate">
                              {project.name || 'Sans titre'}
                            </span>
                            {status === 'completed' && (
                              <span className="px-1.5 py-0.5 bg-green-500/20 text-green-400 text-[10px] rounded-full">
                                Terminé
                              </span>
                            )}
                            {status === 'in_progress' && (
                              <span className="px-1.5 py-0.5 bg-blue-500/20 text-blue-400 text-[10px] rounded-full">
                                En cours
                              </span>
                            )}
                          </div>
                          <div className="text-xs text-gray-500 mt-0.5">
                            {new Date(project.updated_date).toLocaleDateString('fr-FR', {
                              day: 'numeric',
                              month: 'short',
                              year: 'numeric'
                            })}
                          </div>
                        </>
                      )}
                    </div>

                    {/* Menu actions */}
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <button 
                          onClick={(e) => e.stopPropagation()}
                          className="p-2 hover:bg-white/10 rounded-lg transition-colors"
                        >
                          <MoreVertical className="w-4 h-4 text-gray-400" />
                        </button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent 
                        align="end" 
                        className="w-44 bg-[#222] border-[#444] rounded-lg z-[400]"
                      >
                        <DropdownMenuItem
                          onClick={(e) => {
                            e.stopPropagation();
                            handleView(project);
                          }}
                          className="text-white hover:bg-white/10 cursor-pointer"
                        >
                          <Eye className="w-4 h-4 mr-2 text-blue-400" />
                          Afficher
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onClick={(e) => {
                            e.stopPropagation();
                            handleEdit(project);
                          }}
                          className="text-white hover:bg-white/10 cursor-pointer"
                        >
                          <Pencil className="w-4 h-4 mr-2 text-green-400" />
                          Modifier
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onClick={(e) => {
                            e.stopPropagation();
                            handleRename(project);
                          }}
                          className="text-white hover:bg-white/10 cursor-pointer"
                        >
                          <Type className="w-4 h-4 mr-2 text-yellow-400" />
                          Renommer
                        </DropdownMenuItem>
                        <DropdownMenuSeparator className="bg-[#444]" />
                        <DropdownMenuItem
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDelete(project);
                          }}
                          className="text-red-400 hover:bg-red-500/10 cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4 mr-2" />
                          Supprimer
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    </>
  );
}