// ═══════════════════════════════════════════════════════════════
// FORMAT .SUB — SYSTÈME UNIVERSEL DE BRODERIE
// Standard mondial pour le point de croix numérique
// ═══════════════════════════════════════════════════════════════

export const SUB_FORMAT = {
  extension: '.sub',
  mimeType: 'application/x-sub',
  version: '1.0.0',
  name: 'Système Universel de Broderie',
  description: 'Le PDF du point de croix — Format numérique standard et exclusif'
};

// Formats obsolètes remplacés par .SUB
export const OBSOLETE_FORMATS = ['.pbx', '.x', '.zero'];

// ═══════════════════════════════════════════════════════════════
// STRUCTURE D'UN FICHIER .SUB
// ═══════════════════════════════════════════════════════════════

export function createSubFile(pattern, metadata = {}) {
  const subFile = {
    // Header
    format: 'SUB',
    version: SUB_FORMAT.version,
    created: new Date().toISOString(),
    
    // 1️⃣ Méta-données
    metadata: {
      name: metadata.name || 'Sans titre',
      author: metadata.author || 'Anonyme',
      authorId: metadata.authorId || null,
      createdDate: metadata.createdDate || new Date().toISOString(),
      modifiedDate: new Date().toISOString(),
      dimensions: {
        width: pattern?.width || 0,
        height: pattern?.height || 0
      }
    },
    
    // 2️⃣ Palette Couleurs
    palette: {
      colors: pattern?.colors || [],
      dmcCodes: (pattern?.colors || []).map(c => ({
        hex: c.hex,
        dmc: c.dmc || c.code,
        name: c.name
      }))
    },
    
    // 3️⃣ Symboles
    symbols: {
      list: extractSymbols(pattern?.symbolGrid),
      mapping: createSymbolMapping(pattern?.symbolGrid)
    },
    
    // 4️⃣ Schéma de la Grille
    grid: {
      cells: compressGrid(pattern?.symbolGrid),
      stitchTypes: extractStitchTypes(pattern?.symbolGrid)
    },
    
    // 5️⃣ Visuel Source (optionnel)
    sourceImage: pattern?.sourceImage || null,
    thumbnail: metadata.thumbnail || null,
    
    // 6️⃣ Historique d'Édition
    history: {
      version: 1,
      modifications: []
    },
    
    // 7️⃣ Autorisation d'Usage
    license: {
      type: metadata.licenseType || 'personal',
      commercial: metadata.commercial || false,
      attribution: metadata.attribution || true
    }
  };
  
  return subFile;
}

// ═══════════════════════════════════════════════════════════════
// FONCTIONS D'EXTRACTION
// ═══════════════════════════════════════════════════════════════

function extractSymbols(symbolGrid) {
  if (!symbolGrid) return [];
  
  const symbols = new Set();
  symbolGrid.forEach(row => {
    row.forEach(cell => {
      if (cell?.symbol) symbols.add(cell.symbol);
    });
  });
  
  return Array.from(symbols);
}

function createSymbolMapping(symbolGrid) {
  if (!symbolGrid) return {};
  
  const mapping = {};
  symbolGrid.forEach(row => {
    row.forEach(cell => {
      if (cell?.symbol && cell?.color) {
        if (!mapping[cell.symbol]) {
          mapping[cell.symbol] = cell.color;
        }
      }
    });
  });
  
  return mapping;
}

function compressGrid(symbolGrid) {
  if (!symbolGrid) return [];
  
  // Compression RLE pour réduire la taille
  const compressed = [];
  
  symbolGrid.forEach((row, rowIdx) => {
    const compressedRow = [];
    let currentCell = null;
    let count = 0;
    
    row.forEach((cell, colIdx) => {
      const cellKey = cell ? `${cell.symbol}|${cell.color}|${cell.type || 'full'}` : 'empty';
      
      if (cellKey === currentCell) {
        count++;
      } else {
        if (currentCell !== null) {
          compressedRow.push({ key: currentCell, count });
        }
        currentCell = cellKey;
        count = 1;
      }
    });
    
    if (currentCell !== null) {
      compressedRow.push({ key: currentCell, count });
    }
    
    compressed.push(compressedRow);
  });
  
  return compressed;
}

function extractStitchTypes(symbolGrid) {
  if (!symbolGrid) return {};
  
  const types = {};
  symbolGrid.forEach(row => {
    row.forEach(cell => {
      if (cell?.type) {
        types[cell.type] = (types[cell.type] || 0) + 1;
      }
    });
  });
  
  return types;
}

// ═══════════════════════════════════════════════════════════════
// EXPORT .SUB
// ═══════════════════════════════════════════════════════════════

export function exportToSub(pattern, metadata = {}) {
  const subFile = createSubFile(pattern, metadata);
  const jsonString = JSON.stringify(subFile, null, 2);
  const blob = new Blob([jsonString], { type: SUB_FORMAT.mimeType });
  
  const filename = `${metadata.name || 'grille'}.sub`;
  
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  
  return { success: true, filename };
}

// ═══════════════════════════════════════════════════════════════
// IMPORT .SUB
// ═══════════════════════════════════════════════════════════════

export function importFromSub(fileContent) {
  try {
    const subFile = JSON.parse(fileContent);
    
    // Validation du format
    if (subFile.format !== 'SUB') {
      throw new Error('Format non reconnu');
    }
    
    // Décompression de la grille
    const symbolGrid = decompressGrid(subFile.grid.cells);
    
    return {
      success: true,
      pattern: {
        width: subFile.metadata.dimensions.width,
        height: subFile.metadata.dimensions.height,
        colors: subFile.palette.colors,
        symbolGrid,
        sourceImage: subFile.sourceImage
      },
      metadata: subFile.metadata,
      license: subFile.license
    };
  } catch (error) {
    return {
      success: false,
      error: error.message
    };
  }
}

function decompressGrid(compressedGrid) {
  if (!compressedGrid) return [];
  
  return compressedGrid.map(compressedRow => {
    const row = [];
    
    compressedRow.forEach(({ key, count }) => {
      for (let i = 0; i < count; i++) {
        if (key === 'empty') {
          row.push(null);
        } else {
          const [symbol, color, type] = key.split('|');
          row.push({ symbol, color, type });
        }
      }
    });
    
    return row;
  });
}

// ═══════════════════════════════════════════════════════════════
// CONVERSION DEPUIS ANCIENS FORMATS
// ═══════════════════════════════════════════════════════════════

export function convertToSub(oldFormatData, formatType) {
  // Convertit .PBX, .X, .ZERO vers .SUB
  console.log(`Converting from ${formatType} to .SUB`);
  
  // La structure interne est similaire, on crée simplement un nouveau fichier SUB
  return createSubFile(oldFormatData.pattern, oldFormatData.metadata);
}

// ═══════════════════════════════════════════════════════════════
// ÉCOSYSTÈME SUB
// ═══════════════════════════════════════════════════════════════

export const SUB_ECOSYSTEM = {
  app: 'SUB.App',
  store: 'SUB.Store',
  id: 'SUB.ID',
  cloud: 'SUB.Cloud',
  share: 'SUB.Share'
};

export const SUB_MARKETING = {
  tagline: 'Le PDF du point de croix',
  benefits: [
    'Format standard mondial',
    'Création et édition natives',
    'Export PDF et PNG',
    'Compatible écosystème SUB',
    'Prêt pour SDK mondial'
  ]
};