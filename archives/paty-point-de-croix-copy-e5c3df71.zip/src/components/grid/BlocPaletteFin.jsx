import React from 'react';
import { Plus } from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';

export default function BlocPaletteFin({ onClick }) {
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <button
            onClick={onClick}
            className="flex-shrink-0 bg-slate-50 rounded-lg border border-slate-300 hover:bg-slate-100 hover:border-slate-400 transition-all cursor-pointer shadow-sm hover:shadow-md"
            style={{ 
              width: '140px',
              minWidth: '140px',
              height: '95px'
            }}
          >
            <div className="h-full flex flex-col items-center justify-center gap-2 px-3">
              <Plus className="w-7 h-7 text-slate-600" />
              <div className="text-center">
                <div className="text-[11px] font-semibold text-slate-900">
                  Palette complète DMC
                </div>
                <div className="text-[10px] text-slate-500 mt-0.5">
                  Voir toutes les couleurs
                </div>
              </div>
            </div>
          </button>
        </TooltipTrigger>
        <TooltipContent>
          <p>Ouvrir la palette complète DMC</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}