import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Search, Star, Grid3x3, X } from 'lucide-react';
import { cn } from '@/lib/utils';
import { SYMBOL_CATEGORIES } from './SymbolLibrary';

const POPULAR_SYMBOLS = ["X", "○", "●", "□", "■", "▲", "▼", "◀", "▶", "×", "•", "△", "▽", "◎", "★", "♦", "▣"];

export default function SymbolPickerCompact({ selectedSymbol, onSymbolSelect }) {
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedCategory, setExpandedCategory] = useState(null);

  const filteredSymbols = () => {
    if (!searchQuery) return null;
    
    const results = [];
    SYMBOL_CATEGORIES.forEach((category) => {
      category.symbols.forEach((symbol) => {
        if (symbol.char.includes(searchQuery) || symbol.label.toLowerCase().includes(searchQuery.toLowerCase())) {
          results.push(symbol);
        }
      });
    });
    return results;
  };

  const searchResults = filteredSymbols();

  return (
    <div className="space-y-3">
      {/* Recherche */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
        <Input
          placeholder="Rechercher..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-9 h-8 text-xs"
        />
      </div>

      {/* Résultats de recherche */}
      {searchResults && searchResults.length > 0 ? (
        <div className="max-h-64 overflow-y-auto">
          <div className="text-xs font-medium text-slate-600 mb-2">
            {searchResults.length} résultat{searchResults.length > 1 ? 's' : ''}
          </div>
          <div className="grid grid-cols-6 gap-1">
            {searchResults.map((symbol) => (
              <button
                key={symbol.id}
                onClick={() => onSymbolSelect(symbol.char)}
                className={cn(
                  "w-8 h-8 flex items-center justify-center rounded border transition-all hover:border-slate-400 text-base",
                  selectedSymbol === symbol.char
                    ? "border-slate-800 bg-slate-100"
                    : "border-slate-200"
                )}
                title={symbol.label}
              >
                {symbol.char}
              </button>
            ))}
          </div>
        </div>
      ) : searchQuery && searchResults?.length === 0 ? (
        <div className="text-center py-4 text-xs text-slate-500">
          Aucun symbole trouvé
        </div>
      ) : (
        <Tabs defaultValue="popular" className="w-full">
          <TabsList className="grid w-full grid-cols-3 h-8">
            <TabsTrigger value="popular" className="text-xs">
              <Star className="w-3 h-3 mr-1" />
              Top
            </TabsTrigger>
            <TabsTrigger value="all" className="text-xs">Tous</TabsTrigger>
            <TabsTrigger value="none" className="text-xs">Aucun</TabsTrigger>
          </TabsList>

          {/* Populaires */}
          <TabsContent value="popular" className="mt-2">
            <div className="grid grid-cols-6 gap-1">
              {POPULAR_SYMBOLS.map((symbol, idx) => (
                <button
                  key={idx}
                  onClick={() => onSymbolSelect(symbol)}
                  className={cn(
                    "w-8 h-8 flex items-center justify-center rounded border transition-all hover:border-slate-400 text-base",
                    selectedSymbol === symbol
                      ? "border-slate-800 bg-slate-100"
                      : "border-slate-200"
                  )}
                  title={symbol}
                >
                  {symbol}
                </button>
              ))}
            </div>
          </TabsContent>

          {/* Tous les symboles */}
          <TabsContent value="all" className="mt-2 max-h-96 overflow-y-auto">
            <div className="space-y-3">
              {SYMBOL_CATEGORIES.map((category) => (
                <div key={category.id}>
                  <button
                    onClick={() => setExpandedCategory(expandedCategory === category.id ? null : category.id)}
                    className="w-full text-left text-xs font-semibold text-slate-700 hover:text-slate-900 mb-1.5 flex items-center justify-between"
                  >
                    {category.name}
                    <span className="text-slate-400">{expandedCategory === category.id ? '−' : '+'}</span>
                  </button>
                  {expandedCategory === category.id && (
                    <div className="grid grid-cols-6 gap-1 mb-2">
                      {category.symbols.map((symbol) => (
                        <button
                          key={symbol.id}
                          onClick={() => onSymbolSelect(symbol.char)}
                          className={cn(
                            "w-8 h-8 flex items-center justify-center rounded border transition-all hover:border-slate-400 text-base",
                            selectedSymbol === symbol.char
                              ? "border-slate-800 bg-slate-100"
                              : "border-slate-200"
                          )}
                          title={symbol.label}
                        >
                          {symbol.char}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </TabsContent>

          {/* Aucun symbole */}
          <TabsContent value="none" className="mt-2">
            <div className="text-center py-4">
              <Button
                onClick={() => onSymbolSelect(null)}
                variant={selectedSymbol === null ? "default" : "outline"}
                size="sm"
                className={cn(
                  "text-xs",
                  selectedSymbol === null && "bg-slate-800 hover:bg-slate-700"
                )}
              >
                {selectedSymbol === null ? <X className="w-3 h-3 mr-1" /> : null}
                Aucun symbole
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      )}

      {/* Symbole sélectionné */}
      {selectedSymbol && (
        <div className="border-t border-slate-200 pt-2 flex items-center justify-between">
          <span className="text-xs text-slate-500">Sélectionné:</span>
          <div className="flex items-center gap-2">
            <span className="text-2xl">{selectedSymbol}</span>
            <Button
              onClick={() => onSymbolSelect(null)}
              variant="ghost"
              size="sm"
              className="h-6 w-6 p-0"
            >
              <X className="w-3 h-3" />
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}