import React, { useState, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { X, Check, ArrowRight, Zap, AlertTriangle } from 'lucide-react';
import { toast } from 'sonner';
import { autoRepairSub, analyzeGrid } from './SubAutoRepairEngine';

export default function SubBeforeAfterDialog({ open, onClose, pattern, onApplySub }) {
  const [isApplying, setIsApplying] = useState(false);

  // Analyser la version originale et générer la version SUB
  const comparison = useMemo(() => {
    if (!pattern?.symbolGrid) return null;

    const originalAnalysis = analyzeGrid(pattern);
    
    // Simuler la version SUB corrigée
    const subResult = autoRepairSub(pattern, { mode: 'fast' });
    const subAnalysis = analyzeGrid(subResult.pattern);

    return {
      original: {
        totalCells: originalAnalysis.stats?.totalCells || 0,
        emptyCells: originalAnalysis.stats?.emptyCells || 0,
        missingSymbols: originalAnalysis.stats?.missingSymbols?.length || 0,
        orphanColors: originalAnalysis.stats?.orphanColors?.length || 0,
        invalidDMC: originalAnalysis.stats?.invalidDMC?.length || 0,
        isValid: originalAnalysis.isValid
      },
      sub: {
        totalCells: subAnalysis.stats?.totalCells || 0,
        emptyCells: subAnalysis.stats?.emptyCells || 0,
        missingSymbols: subAnalysis.stats?.missingSymbols?.length || 0,
        orphanColors: subAnalysis.stats?.orphanColors?.length || 0,
        invalidDMC: subAnalysis.stats?.invalidDMC?.length || 0,
        isValid: subAnalysis.isValid
      },
      repairs: subResult.summary,
      repairedPattern: subResult.pattern
    };
  }, [pattern]);

  const handleApplySub = async () => {
    if (!comparison?.repairedPattern) return;

    setIsApplying(true);
    await new Promise(r => setTimeout(r, 300));

    onApplySub?.(comparison.repairedPattern);
    toast.success('Version SUB appliquée avec succès !');
    onClose();
  };

  if (!open) return null;

  const criteria = [
    { 
      label: 'Trous', 
      before: comparison?.original.emptyCells > 0 ? 'Oui' : 'Non',
      after: 'Non',
      beforeBad: comparison?.original.emptyCells > 0
    },
    { 
      label: 'Symboles manquants', 
      before: comparison?.original.missingSymbols > 0 ? 'Oui' : 'Non',
      after: 'Non',
      beforeBad: comparison?.original.missingSymbols > 0
    },
    { 
      label: 'Palette optimisée', 
      before: 'Non',
      after: 'Oui',
      beforeBad: true
    },
    { 
      label: 'Points spéciaux', 
      before: 'Complexes',
      after: 'Simplifiés',
      beforeBad: true
    },
    { 
      label: 'Lecture', 
      before: 'Difficile',
      after: 'Claire',
      beforeBad: true
    },
    { 
      label: 'Brodabilité', 
      before: 'Parfois',
      after: 'Toujours',
      beforeBad: true
    }
  ];

  return (
    <div className="fixed inset-0 z-[99999] flex items-center justify-center bg-black/60">
      <div className="bg-white rounded-xl shadow-2xl w-[800px] max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="bg-black px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-yellow-400 to-yellow-600 flex items-center justify-center">
              <Zap className="w-5 h-5 text-black" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Mode Avant / Après SUB™</h2>
              <p className="text-sm text-gray-400">Comparez l'ancienne technique vs SUB</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center"
          >
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        {/* Split View */}
        <div className="grid grid-cols-2 divide-x">
          {/* AVANT */}
          <div className="p-6">
            <div className="flex items-center gap-2 mb-4">
              <X className="w-5 h-5 text-red-500" />
              <h3 className="font-bold text-lg">AVANT</h3>
              <span className="text-xs bg-red-100 text-red-700 px-2 py-0.5 rounded">Point classique</span>
            </div>
            
            {/* Aperçu */}
            <div className="w-full h-40 bg-gray-100 rounded-lg border-2 border-gray-300 mb-4 flex items-center justify-center relative overflow-hidden">
              {pattern?.sourceImage ? (
                <img src={pattern.sourceImage} alt="Original" className="w-full h-full object-contain opacity-70" />
              ) : (
                <span className="text-gray-400">Aperçu original</span>
              )}
              {/* Overlay avec problèmes */}
              <div className="absolute inset-0 bg-red-500/10 flex items-center justify-center">
                <AlertTriangle className="w-12 h-12 text-red-500/50" />
              </div>
            </div>

            {/* Stats */}
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">Cases vides :</span>
                <span className={comparison?.original.emptyCells > 0 ? 'text-red-600 font-bold' : 'text-green-600'}>
                  {comparison?.original.emptyCells || 0}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Symboles manquants :</span>
                <span className={comparison?.original.missingSymbols > 0 ? 'text-red-600 font-bold' : 'text-green-600'}>
                  {comparison?.original.missingSymbols || 0}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Couleurs orphelines :</span>
                <span className={comparison?.original.orphanColors > 0 ? 'text-orange-600' : 'text-green-600'}>
                  {comparison?.original.orphanColors || 0}
                </span>
              </div>
            </div>
          </div>

          {/* APRÈS SUB */}
          <div className="p-6 bg-yellow-50/30">
            <div className="flex items-center gap-2 mb-4">
              <Check className="w-5 h-5 text-green-500" />
              <h3 className="font-bold text-lg">APRÈS</h3>
              <span className="text-xs bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded font-semibold">SUB™</span>
            </div>
            
            {/* Aperçu */}
            <div className="w-full h-40 bg-white rounded-lg border-2 border-yellow-400 mb-4 flex items-center justify-center relative overflow-hidden">
              {pattern?.sourceImage ? (
                <img src={pattern.sourceImage} alt="SUB" className="w-full h-full object-contain" />
              ) : (
                <span className="text-gray-400">Aperçu SUB</span>
              )}
              {/* Overlay succès */}
              <div className="absolute bottom-2 right-2 bg-green-500 text-white text-xs px-2 py-1 rounded-full">
                ✓ 100% brodable
              </div>
            </div>

            {/* Stats */}
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">Cases vides :</span>
                <span className="text-green-600 font-bold">0 ✓</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Symboles manquants :</span>
                <span className="text-green-600 font-bold">0 ✓</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Palette optimisée :</span>
                <span className="text-green-600 font-bold">Oui ✓</span>
              </div>
            </div>
          </div>
        </div>

        {/* Tableau de comparaison */}
        <div className="px-6 py-4 border-t">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b">
                <th className="text-left py-2 font-medium text-gray-500">Critère</th>
                <th className="text-center py-2 font-medium text-red-500">Avant</th>
                <th className="text-center py-2 w-10"></th>
                <th className="text-center py-2 font-medium text-yellow-600">SUB™</th>
              </tr>
            </thead>
            <tbody>
              {criteria.map((c, idx) => (
                <tr key={idx} className="border-b last:border-0">
                  <td className="py-2 font-medium">{c.label}</td>
                  <td className={`py-2 text-center ${c.beforeBad ? 'text-red-600' : 'text-gray-600'}`}>
                    {c.before}
                  </td>
                  <td className="py-2 text-center">
                    <ArrowRight className="w-4 h-4 text-gray-400 mx-auto" />
                  </td>
                  <td className="py-2 text-center text-green-600 font-medium">{c.after}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Message */}
        <div className="px-6 py-3 bg-green-50 border-t border-green-200">
          <p className="text-sm text-green-800 text-center">
            ✅ Voici votre nouvelle version SUB, prête à broder.
          </p>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t bg-gray-50 flex items-center justify-between">
          <p className="text-xs text-gray-500">
            <span className="font-semibold text-yellow-600">SUB™</span> — La révolution de la broderie
          </p>
          <div className="flex gap-3">
            <Button variant="outline" onClick={onClose}>
              Annuler
            </Button>
            <Button
              onClick={handleApplySub}
              disabled={isApplying}
              className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold"
            >
              {isApplying ? 'Application...' : 'Appliquer SUB'}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}