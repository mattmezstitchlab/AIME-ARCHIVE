import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { 
  X, Upload, Zap, Check, Loader2, 
  Image, FileText, Grid3X3, Palette, 
  Type, Download, Play, RotateCcw,
  ChevronRight, Sparkles
} from 'lucide-react';
import { toast } from 'sonner';
import { DMC_LIBRARY } from './dmcLibrary';
import { createSubFile } from './subFormat';

// Symboles disponibles pour l'attribution
const SYMBOLS = [
  '●', '■', '▲', '◆', '★', '✦', '○', '□', '△', '◇',
  '✕', '✚', '♦', '♠', '♣', '♥', '▼', '◉', '◎', '⬟',
  '⬡', '⬢', '⬣', '✶', '✹', '✸', '✷', '❖', '⚫', '⚪',
  '◐', '◑', '◒', '◓', '▣', '▤', '▥', '▧', '▨', '▩',
  'α', 'β', 'γ', 'δ', 'ε', 'λ', 'μ', 'π', 'σ', 'Ω',
  'ᴀ', 'ʙ', 'ᴄ', 'ᴅ', 'ᴇ', 'ғ', 'ɢ', 'ʜ', 'ɪ', 'ᴊ'
];

const STEPS = [
  { id: 'upload', label: 'Import', icon: Upload },
  { id: 'analyze', label: 'Analyse IA', icon: Zap },
  { id: 'dimensions', label: 'Dimensions', icon: Grid3X3 },
  { id: 'colors', label: 'Couleurs', icon: Palette },
  { id: 'dmc', label: 'DMC', icon: Sparkles },
  { id: 'symbols', label: 'Symboles', icon: Type },
  { id: 'export', label: 'Export .SUB', icon: Download }
];

export default function SubImportDialog({ open, onClose, onComplete }) {
  const [currentStep, setCurrentStep] = useState(0);
  const [isProcessing, setIsProcessing] = useState(false);
  const [file, setFile] = useState(null);
  const [imageData, setImageData] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  
  // Configuration
  const [config, setConfig] = useState({
    width: 100,
    height: 140,
    preserveRatio: true,
    resolution: 'standard', // fine, standard, large
    colorCount: 24,
    unlimitedColors: false
  });
  
  // Résultats du pipeline
  const [results, setResults] = useState({
    cleanedImage: null,
    colors: [],
    dmcColors: [],
    symbolGrid: [],
    subFile: null
  });
  
  const fileInputRef = useRef(null);
  const canvasRef = useRef(null);

  // Reset à l'ouverture
  useEffect(() => {
    if (open) {
      setCurrentStep(0);
      setFile(null);
      setImageData(null);
      setPreviewUrl(null);
      setResults({ cleanedImage: null, colors: [], dmcColors: [], symbolGrid: [], subFile: null });
    }
  }, [open]);

  // Gérer l'upload de fichier
  const handleFileSelect = async (e) => {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;

    setFile(selectedFile);
    setIsProcessing(true);

    try {
      // Détection du type
      const fileType = selectedFile.type;
      
      if (fileType === 'application/x-sub' || selectedFile.name.endsWith('.sub')) {
        // Import direct d'un fichier .SUB
        const content = await selectedFile.text();
        const subData = JSON.parse(content);
        toast.success('Fichier .SUB importé avec succès');
        onComplete?.(subData);
        onClose();
        return;
      }

      if (fileType === 'application/pdf') {
        toast.info('Extraction de l\'image depuis le PDF...');
        // Pour l'instant, on simule - dans une vraie implémentation, utiliser pdf.js
      }

      // Charger l'image
      const url = URL.createObjectURL(selectedFile);
      setPreviewUrl(url);

      const img = new Image();
      img.onload = () => {
        // Stocker les données de l'image
        const canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0);
        
        const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        setImageData({ data: imgData, width: img.width, height: img.height, canvas });

        // Calculer les dimensions suggérées
        const ratio = img.width / img.height;
        const suggestedWidth = 100;
        const suggestedHeight = Math.round(suggestedWidth / ratio);
        setConfig(prev => ({ ...prev, width: suggestedWidth, height: suggestedHeight }));

        setCurrentStep(1);
        setIsProcessing(false);
        
        // Lancer l'analyse automatique
        runAnalysis(imgData, img.width, img.height);
      };
      img.src = url;

    } catch (error) {
      console.error('Erreur import:', error);
      toast.error('Erreur lors de l\'import du fichier');
      setIsProcessing(false);
    }
  };

  // Étape A - Analyse IA
  const runAnalysis = async (imgData, width, height) => {
    setIsProcessing(true);
    
    // Simulation d'analyse (dans une vraie implémentation, traitement réel)
    await new Promise(r => setTimeout(r, 500));
    
    setCurrentStep(2);
    setIsProcessing(false);
  };

  // Étape B à G - Pipeline complet
  const runFullPipeline = async () => {
    if (!imageData) return;
    
    setIsProcessing(true);

    try {
      // Étape B - Dimensions
      setCurrentStep(2);
      await new Promise(r => setTimeout(r, 300));

      // Étape C - Génération des points (0 case vide)
      setCurrentStep(3);
      const { colors, pixelColors } = await extractColors(imageData);
      
      // Étape D - Attribution couleurs
      await new Promise(r => setTimeout(r, 300));
      
      // Étape E - Conversion DMC
      setCurrentStep(4);
      const dmcColors = await convertToDMC(colors);
      
      // Étape F - Attribution symboles
      setCurrentStep(5);
      await new Promise(r => setTimeout(r, 300));
      const { symbolGrid, colorPalette } = await generateSymbolGrid(
        imageData, 
        config.width, 
        config.height, 
        dmcColors
      );

      // Étape G - Création du fichier .SUB
      setCurrentStep(6);
      await new Promise(r => setTimeout(r, 300));

      const pattern = {
        width: config.width,
        height: config.height,
        colors: colorPalette,
        symbolGrid,
        sourceImage: previewUrl
      };

      const subFile = createSubFile(pattern, {
        name: file?.name?.replace(/\.[^/.]+$/, '') || 'grille_sub',
        author: 'PatyBee User'
      });

      setResults({
        colors,
        dmcColors,
        symbolGrid,
        colorPalette,
        subFile,
        pattern
      });

      setIsProcessing(false);
      toast.success('Grille .SUB générée avec succès !');

    } catch (error) {
      console.error('Erreur pipeline:', error);
      toast.error('Erreur lors de la génération');
      setIsProcessing(false);
    }
  };

  // Extraction des couleurs
  const extractColors = async (imgData) => {
    const { data, width, height } = imgData;
    const colorMap = new Map();
    const pixelColors = [];

    // Parcourir tous les pixels
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const idx = (y * width + x) * 4;
        const r = data.data[idx];
        const g = data.data[idx + 1];
        const b = data.data[idx + 2];
        
        // Quantification pour regrouper les nuances
        const qr = Math.round(r / 16) * 16;
        const qg = Math.round(g / 16) * 16;
        const qb = Math.round(b / 16) * 16;
        
        const colorKey = `${qr},${qg},${qb}`;
        colorMap.set(colorKey, (colorMap.get(colorKey) || 0) + 1);
        pixelColors.push({ r, g, b, qr, qg, qb });
      }
    }

    // Trier par fréquence et prendre les N premières
    const sortedColors = Array.from(colorMap.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, config.unlimitedColors ? 100 : config.colorCount)
      .map(([key, count]) => {
        const [r, g, b] = key.split(',').map(Number);
        return { r, g, b, hex: rgbToHex(r, g, b), count };
      });

    return { colors: sortedColors, pixelColors };
  };

  // Conversion en DMC
  const convertToDMC = async (colors) => {
    return colors.map((color, idx) => {
      const dmc = findClosestDMC(color.hex);
      return {
        ...color,
        dmc: dmc.code,
        dmcName: dmc.name,
        dmcHex: dmc.hex,
        symbol: SYMBOLS[idx % SYMBOLS.length]
      };
    });
  };

  // Trouver la couleur DMC la plus proche
  const findClosestDMC = (hex) => {
    const rgb = hexToRgb(hex);
    let closest = DMC_LIBRARY[0];
    let minDist = Infinity;

    DMC_LIBRARY.forEach(dmc => {
      const dmcRgb = hexToRgb(dmc.hex);
      const dist = Math.sqrt(
        Math.pow(rgb.r - dmcRgb.r, 2) +
        Math.pow(rgb.g - dmcRgb.g, 2) +
        Math.pow(rgb.b - dmcRgb.b, 2)
      );
      if (dist < minDist) {
        minDist = dist;
        closest = dmc;
      }
    });

    return closest;
  };

  // Générer la grille de symboles (AUCUNE CASE VIDE)
  const generateSymbolGrid = async (imgData, targetWidth, targetHeight, dmcColors) => {
    const { data, width, height, canvas } = imgData;
    
    // Créer un canvas redimensionné
    const resizedCanvas = document.createElement('canvas');
    resizedCanvas.width = targetWidth;
    resizedCanvas.height = targetHeight;
    const ctx = resizedCanvas.getContext('2d');
    
    // Dessiner l'image redimensionnée
    ctx.drawImage(canvas, 0, 0, targetWidth, targetHeight);
    const resizedData = ctx.getImageData(0, 0, targetWidth, targetHeight);

    const symbolGrid = [];
    const colorPalette = [];
    const colorToSymbol = new Map();

    // Créer le mapping couleur -> symbole
    dmcColors.forEach((color, idx) => {
      colorToSymbol.set(color.dmcHex, {
        symbol: SYMBOLS[idx % SYMBOLS.length],
        dmc: color.dmc,
        name: color.dmcName,
        hex: color.dmcHex
      });
      colorPalette.push({
        hex: color.dmcHex,
        dmc: color.dmc,
        name: color.dmcName,
        symbol: SYMBOLS[idx % SYMBOLS.length]
      });
    });

    // Générer la grille - CHAQUE PIXEL = UN POINT
    for (let row = 0; row < targetHeight; row++) {
      const gridRow = [];
      for (let col = 0; col < targetWidth; col++) {
        const idx = (row * targetWidth + col) * 4;
        const r = resizedData.data[idx];
        const g = resizedData.data[idx + 1];
        const b = resizedData.data[idx + 2];
        const hex = rgbToHex(r, g, b);

        // Trouver la couleur DMC la plus proche
        const dmc = findClosestDMC(hex);
        const mapping = colorToSymbol.get(dmc.hex) || {
          symbol: SYMBOLS[0],
          dmc: dmc.code,
          name: dmc.name,
          hex: dmc.hex
        };

        // JAMAIS de case vide !
        gridRow.push({
          color: mapping.hex,
          symbol: mapping.symbol,
          dmc: mapping.dmc,
          type: 'full',
          done: false
        });
      }
      symbolGrid.push(gridRow);
    }

    return { symbolGrid, colorPalette };
  };

  // Utilitaires
  const rgbToHex = (r, g, b) => '#' + [r, g, b].map(x => x.toString(16).padStart(2, '0')).join('');
  
  const hexToRgb = (hex) => {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
      r: parseInt(result[1], 16),
      g: parseInt(result[2], 16),
      b: parseInt(result[3], 16)
    } : { r: 0, g: 0, b: 0 };
  };

  // Ouvrir dans l'éditeur
  const handleOpenInEditor = () => {
    if (results.pattern) {
      onComplete?.(results.pattern);
      onClose();
    }
  };

  // Sauvegarder le fichier .SUB
  const handleSaveSub = () => {
    if (!results.subFile) return;

    const jsonString = JSON.stringify(results.subFile, null, 2);
    const blob = new Blob([jsonString], { type: 'application/x-sub' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${file?.name?.replace(/\.[^/.]+$/, '') || 'grille'}.sub`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast.success('Fichier .SUB enregistré');
  };

  // Recommencer
  const handleReset = () => {
    setCurrentStep(0);
    setFile(null);
    setImageData(null);
    setPreviewUrl(null);
    setResults({ cleanedImage: null, colors: [], dmcColors: [], symbolGrid: [], subFile: null });
  };

  if (!open) return null;

  return (
    <div 
      className="fixed inset-0 flex items-center justify-center"
      style={{ zIndex: 999999, backgroundColor: 'rgba(0, 0, 0, 0.85)' }}
    >
      <div 
        className="bg-white rounded-2xl shadow-2xl overflow-hidden"
        style={{ width: '90vw', maxWidth: '900px', maxHeight: '90vh' }}
      >
        {/* Header */}
        <div className="bg-black px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-yellow-400 to-yellow-600 flex items-center justify-center">
              <Zap className="w-5 h-5 text-black" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white">Importer un projet</h2>
              <p className="text-sm text-gray-400">Transformez votre fichier en grille .SUB</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center"
          >
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        {/* Barre de progression */}
        <div className="px-6 py-4 bg-gray-50 border-b">
          <div className="flex items-center justify-between">
            {STEPS.map((step, idx) => {
              const StepIcon = step.icon;
              const isActive = idx === currentStep;
              const isComplete = idx < currentStep;
              const isFinal = idx === STEPS.length - 1 && results.subFile;

              return (
                <React.Fragment key={step.id}>
                  <div className="flex flex-col items-center">
                    <div 
                      className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${
                        isFinal ? 'bg-green-500 text-white' :
                        isComplete ? 'bg-yellow-500 text-black' :
                        isActive ? 'bg-black text-white' :
                        'bg-gray-200 text-gray-400'
                      }`}
                    >
                      {isFinal || isComplete ? (
                        <Check className="w-5 h-5" />
                      ) : (
                        <StepIcon className="w-5 h-5" />
                      )}
                    </div>
                    <span className={`text-xs mt-1 ${isActive ? 'font-semibold' : 'text-gray-500'}`}>
                      {step.label}
                    </span>
                  </div>
                  {idx < STEPS.length - 1 && (
                    <div className={`flex-1 h-0.5 mx-2 ${idx < currentStep ? 'bg-yellow-500' : 'bg-gray-200'}`} />
                  )}
                </React.Fragment>
              );
            })}
          </div>
        </div>

        {/* Contenu */}
        <div className="p-6 overflow-y-auto" style={{ maxHeight: 'calc(90vh - 200px)' }}>
          {/* Étape 0 - Upload */}
          {currentStep === 0 && !file && (
            <div className="text-center py-12">
              <div 
                className="border-2 border-dashed border-gray-300 rounded-xl p-12 hover:border-yellow-500 transition-colors cursor-pointer"
                onClick={() => fileInputRef.current?.click()}
              >
                <Upload className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">Importer un fichier</h3>
                <p className="text-gray-500 mb-4">Formats acceptés : JPG, PNG, PDF, SUB</p>
                <Button className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold">
                  Choisir un fichier
                </Button>
              </div>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*,.pdf,.sub"
                onChange={handleFileSelect}
                className="hidden"
              />
              <p className="text-sm text-gray-400 mt-4">
                Un seul bouton. L'application reconnaît automatiquement le format.
              </p>
            </div>
          )}

          {/* Étapes 1-5 - Traitement */}
          {currentStep >= 1 && currentStep < 6 && !results.subFile && (
            <div className="grid grid-cols-2 gap-6">
              {/* Aperçu */}
              <div className="space-y-4">
                <h3 className="font-semibold">Aperçu</h3>
                {previewUrl && (
                  <div className="border rounded-lg overflow-hidden bg-gray-100">
                    <img 
                      src={previewUrl} 
                      alt="Aperçu" 
                      className="w-full h-auto max-h-64 object-contain"
                    />
                  </div>
                )}
              </div>

              {/* Configuration */}
              <div className="space-y-4">
                <h3 className="font-semibold">Configuration</h3>
                
                {/* Dimensions */}
                <div className="space-y-2">
                  <label className="text-sm font-medium">Dimensions de la grille</label>
                  <div className="flex gap-2 items-center">
                    <input
                      type="number"
                      value={config.width}
                      onChange={(e) => {
                        const w = Number(e.target.value);
                        setConfig(prev => ({
                          ...prev,
                          width: w,
                          height: prev.preserveRatio && imageData 
                            ? Math.round(w * (imageData.height / imageData.width))
                            : prev.height
                        }));
                      }}
                      className="w-20 px-3 py-2 border rounded-lg"
                    />
                    <span>×</span>
                    <input
                      type="number"
                      value={config.height}
                      onChange={(e) => setConfig(prev => ({ ...prev, height: Number(e.target.value) }))}
                      className="w-20 px-3 py-2 border rounded-lg"
                      disabled={config.preserveRatio}
                    />
                    <span className="text-sm text-gray-500">points</span>
                  </div>
                  <label className="flex items-center gap-2 text-sm">
                    <input
                      type="checkbox"
                      checked={config.preserveRatio}
                      onChange={(e) => setConfig(prev => ({ ...prev, preserveRatio: e.target.checked }))}
                      className="accent-yellow-500"
                    />
                    Préserver les proportions
                  </label>
                </div>

                {/* Nombre de couleurs */}
                <div className="space-y-2">
                  <label className="text-sm font-medium">Nombre de couleurs</label>
                  <div className="flex gap-2 flex-wrap">
                    {[12, 24, 36, 48, 60].map(n => (
                      <button
                        key={n}
                        onClick={() => setConfig(prev => ({ ...prev, colorCount: n, unlimitedColors: false }))}
                        className={`px-3 py-1 rounded-lg border text-sm ${
                          config.colorCount === n && !config.unlimitedColors
                            ? 'bg-yellow-500 border-yellow-500 text-black font-semibold'
                            : 'hover:bg-gray-100'
                        }`}
                      >
                        {n}
                      </button>
                    ))}
                    <button
                      onClick={() => setConfig(prev => ({ ...prev, unlimitedColors: true }))}
                      className={`px-3 py-1 rounded-lg border text-sm ${
                        config.unlimitedColors
                          ? 'bg-yellow-500 border-yellow-500 text-black font-semibold'
                          : 'hover:bg-gray-100'
                      }`}
                    >
                      Illimité
                    </button>
                  </div>
                </div>

                {/* Résolution */}
                <div className="space-y-2">
                  <label className="text-sm font-medium">Résolution des points</label>
                  <div className="flex gap-2">
                    {['fine', 'standard', 'large'].map(res => (
                      <button
                        key={res}
                        onClick={() => setConfig(prev => ({ ...prev, resolution: res }))}
                        className={`flex-1 px-3 py-2 rounded-lg border text-sm capitalize ${
                          config.resolution === res
                            ? 'bg-black text-white'
                            : 'hover:bg-gray-100'
                        }`}
                      >
                        {res === 'fine' ? 'Fine' : res === 'standard' ? 'Standard' : 'Large'}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Bouton de génération */}
                <Button
                  onClick={runFullPipeline}
                  disabled={isProcessing}
                  className="w-full bg-gradient-to-r from-yellow-400 to-yellow-500 hover:from-yellow-500 hover:to-yellow-600 text-black font-semibold h-12"
                >
                  {isProcessing ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Génération en cours...
                    </>
                  ) : (
                    <>
                      <Play className="w-5 h-5 mr-2" />
                      Générer ma grille .SUB
                    </>
                  )}
                </Button>
              </div>
            </div>
          )}

          {/* Étape finale - Résultat */}
          {results.subFile && (
            <div className="text-center py-8">
              <div className="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
                <Check className="w-10 h-10 text-green-600" />
              </div>
              
              <h2 className="text-2xl font-bold mb-2">
                🎉 Votre grille SUB est prête !
              </h2>
              <p className="text-gray-600 mb-6">
                100% complète, 0 case vide.
              </p>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-4 max-w-md mx-auto mb-8">
                <div className="bg-gray-50 rounded-lg p-4">
                  <div className="text-2xl font-bold">{config.width}×{config.height}</div>
                  <div className="text-sm text-gray-500">Dimensions</div>
                </div>
                <div className="bg-gray-50 rounded-lg p-4">
                  <div className="text-2xl font-bold">{results.colorPalette?.length || 0}</div>
                  <div className="text-sm text-gray-500">Couleurs DMC</div>
                </div>
                <div className="bg-gray-50 rounded-lg p-4">
                  <div className="text-2xl font-bold">{config.width * config.height}</div>
                  <div className="text-sm text-gray-500">Points</div>
                </div>
              </div>

              {/* Boutons */}
              <div className="flex gap-4 justify-center">
                <Button
                  onClick={handleReset}
                  variant="outline"
                  className="gap-2"
                >
                  <RotateCcw className="w-4 h-4" />
                  Recommencer
                </Button>
                <Button
                  onClick={handleSaveSub}
                  variant="outline"
                  className="gap-2"
                >
                  <Download className="w-4 h-4" />
                  Enregistrer .SUB
                </Button>
                <Button
                  onClick={handleOpenInEditor}
                  className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold gap-2"
                >
                  <ChevronRight className="w-4 h-4" />
                  Ouvrir dans l'éditeur
                </Button>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-gray-50 border-t text-center">
          <p className="text-xs text-gray-500">
            <span className="font-semibold text-yellow-600">SUB™</span> — Premier format garantissant une grille sans trous, 100% prête à broder.
          </p>
        </div>
      </div>
    </div>
  );
}