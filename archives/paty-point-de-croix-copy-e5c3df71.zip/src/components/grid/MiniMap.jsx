import React, { useRef, useEffect, useState } from 'react';
import { cn } from '@/lib/utils';
import { useSettings } from '../settings/SettingsContext';
import { ZoomIn, ZoomOut, Target, Grid3x3, Eye, Ruler, ChevronDown, ChevronUp, Maximize2, Crosshair } from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import GridFormatDialog from './GridFormatDialog';

export default function MiniMap({
  nbColonnes,
  nbLignes,
  tailleCase,
  zoom,
  offsetX,
  offsetY,
  canvasWidth,
  canvasHeight,
  onNavigate,
  mosaicConfig,
  showMosaicGuides,
  onToggleMosaicGuides,
  showCenterMarker,
  onToggleCenterMarker,
  onZoomIn,
  onZoomOut,
  onResetZoom,
  pattern,
  selectedColorId,
  onChangeFormat
}) {
  const { settings } = useSettings();
  const canvasRef = useRef(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [showFormatDialog, setShowFormatDialog] = useState(false);
  const [showReperes, setShowReperes] = useState(true);
  
  const minimapDisplayMode = settings?.minimapDisplayMode || 'standard';
  const miniMapSize = 220;
  const padding = 30;
  const gridSize = miniMapSize - padding * 2;

  // Calculer les valeurs min/max en coordonnées centrées
  const centerCol = Math.floor(nbColonnes / 2);
  const centerRow = Math.floor(nbLignes / 2);
  const minX = -centerCol;
  const maxX = nbColonnes - centerCol - 1;
  const minY = -centerRow;
  const maxY = nbLignes - centerRow - 1;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || isCollapsed) return;

    const ctx = canvas.getContext('2d');
    const dpr = window.devicePixelRatio || 1;

    canvas.width = miniMapSize * dpr;
    canvas.height = miniMapSize * dpr;
    canvas.style.width = `${miniMapSize}px`;
    canvas.style.height = `${miniMapSize}px`;

    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, miniMapSize, miniMapSize);

    const gridWidth = nbColonnes * tailleCase;
    const gridHeight = nbLignes * tailleCase;
    const scale = Math.min(gridSize / gridWidth, gridSize / gridHeight) * 0.9;

    const offsetMiniX = padding + (gridSize - gridWidth * scale) / 2;
    const offsetMiniY = padding + (gridSize - gridHeight * scale) / 2;

    // Fond de la grille
    ctx.fillStyle = '#F8FAFC';
    ctx.fillRect(offsetMiniX, offsetMiniY, gridWidth * scale, gridHeight * scale);

    // Mode d'affichage intelligent
    if (minimapDisplayMode === 'progress' && pattern?.symbolGrid) {
      const cellWidth = (gridWidth * scale) / pattern.symbolGrid[0]?.length;
      const cellHeight = (gridHeight * scale) / pattern.symbolGrid.length;
      
      pattern.symbolGrid.forEach((row, rowIndex) => {
        row.forEach((cell, colIndex) => {
          if (cell?.done) {
            ctx.fillStyle = 'rgba(34, 197, 94, 0.4)';
            ctx.fillRect(
              offsetMiniX + colIndex * cellWidth,
              offsetMiniY + rowIndex * cellHeight,
              cellWidth,
              cellHeight
            );
          }
        });
      });
    } else if (minimapDisplayMode === 'activeColor' && selectedColorId && pattern?.symbolGrid) {
      const cellWidth = (gridWidth * scale) / pattern.symbolGrid[0]?.length;
      const cellHeight = (gridHeight * scale) / pattern.symbolGrid.length;
      
      pattern.symbolGrid.forEach((row, rowIndex) => {
        row.forEach((cell, colIndex) => {
          if (cell?.colorId === selectedColorId) {
            ctx.fillStyle = 'rgba(245, 194, 0, 0.6)';
            ctx.fillRect(
              offsetMiniX + colIndex * cellWidth,
              offsetMiniY + rowIndex * cellHeight,
              cellWidth,
              cellHeight
            );
          } else if (cell) {
            ctx.fillStyle = 'rgba(0, 0, 0, 0.1)';
            ctx.fillRect(
              offsetMiniX + colIndex * cellWidth,
              offsetMiniY + rowIndex * cellHeight,
              cellWidth,
              cellHeight
            );
          }
        });
      });
    }

    if (showReperes) {
      // Grille simplifiée (lignes tous les 10)
      ctx.strokeStyle = '#E2E8F0';
      ctx.lineWidth = 0.3;
      
      for (let col = 0; col <= nbColonnes; col += 10) {
        ctx.beginPath();
        ctx.moveTo(offsetMiniX + col * tailleCase * scale, offsetMiniY);
        ctx.lineTo(offsetMiniX + col * tailleCase * scale, offsetMiniY + gridHeight * scale);
        ctx.stroke();
      }
      
      for (let row = 0; row <= nbLignes; row += 10) {
        ctx.beginPath();
        ctx.moveTo(offsetMiniX, offsetMiniY + row * tailleCase * scale);
        ctx.lineTo(offsetMiniX + gridWidth * scale, offsetMiniY + row * tailleCase * scale);
        ctx.stroke();
      }

      // Lignes mosaïque rouges
      if (showMosaicGuides && mosaicConfig) {
        ctx.strokeStyle = 'rgba(239, 68, 68, 0.6)';
        ctx.lineWidth = 2;
        
        const pageWidth = mosaicConfig.pageWidth;
        const pageHeight = mosaicConfig.pageHeight;
        
        for (let col = pageWidth; col < nbColonnes; col += pageWidth) {
          ctx.beginPath();
          ctx.moveTo(offsetMiniX + col * tailleCase * scale, offsetMiniY);
          ctx.lineTo(offsetMiniX + col * tailleCase * scale, offsetMiniY + gridHeight * scale);
          ctx.stroke();
        }
        
        for (let row = pageHeight; row < nbLignes; row += pageHeight) {
          ctx.beginPath();
          ctx.moveTo(offsetMiniX, offsetMiniY + row * tailleCase * scale);
          ctx.lineTo(offsetMiniX + gridWidth * scale, offsetMiniY + row * tailleCase * scale);
          ctx.stroke();
        }
      }

      // Repère central (0,0)
      if (showCenterMarker) {
        const centerX = offsetMiniX + centerCol * tailleCase * scale;
        const centerY = offsetMiniY + centerRow * tailleCase * scale;
        
        ctx.strokeStyle = '#EF4444';
        ctx.fillStyle = '#EF4444';
        ctx.lineWidth = 1.5;
        
        // Cercle
        ctx.beginPath();
        ctx.arc(centerX, centerY, 3, 0, Math.PI * 2);
        ctx.fill();
        
        // Croix
        ctx.beginPath();
        ctx.moveTo(centerX - 6, centerY);
        ctx.lineTo(centerX + 6, centerY);
        ctx.moveTo(centerX, centerY - 6);
        ctx.lineTo(centerX, centerY + 6);
        ctx.stroke();
      }
    }

    // Zone visible (carré bleu)
    if (canvasWidth && canvasHeight) {
      const viewportWidth = canvasWidth / zoom;
      const viewportHeight = canvasHeight / zoom;
      
      const viewportX = -offsetX / zoom;
      const viewportY = -offsetY / zoom;
      
      const miniViewX = offsetMiniX + viewportX * scale;
      const miniViewY = offsetMiniY + viewportY * scale;
      const miniViewWidth = viewportWidth * scale;
      const miniViewHeight = viewportHeight * scale;
      
      // Halo
      ctx.shadowColor = 'rgba(59, 130, 246, 0.3)';
      ctx.shadowBlur = 8;
      
      ctx.strokeStyle = '#3B82F6';
      ctx.lineWidth = 2;
      ctx.fillStyle = 'rgba(59, 130, 246, 0.1)';
      ctx.fillRect(miniViewX, miniViewY, miniViewWidth, miniViewHeight);
      ctx.strokeRect(miniViewX, miniViewY, miniViewWidth, miniViewHeight);
      
      ctx.shadowColor = 'transparent';
      ctx.shadowBlur = 0;
    }

    // Bordure de la mini-carte
    ctx.strokeStyle = '#CBD5E1';
    ctx.lineWidth = 1;
    ctx.strokeRect(offsetMiniX, offsetMiniY, gridWidth * scale, gridHeight * scale);

    // Numérotation réduite (valeurs clés uniquement)
    ctx.fillStyle = '#64748B';
    ctx.font = '9px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    // Valeurs clés à afficher
    const keyValues = [-150, -100, -50, 0, 50, 100, 150];
    
    // Axe horizontal (haut) - valeurs clés
    keyValues.forEach(val => {
      if (val >= minX && val <= maxX) {
        const xPos = offsetMiniX + ((val - minX) / (maxX - minX)) * (gridWidth * scale);
        ctx.fillText(`${val}`, xPos, padding - 12);
      }
    });

    // Axe vertical (gauche) - valeurs clés
    ctx.save();
    ctx.textAlign = 'right';
    keyValues.forEach(val => {
      if (val >= minY && val <= maxY) {
        const yPos = offsetMiniY + ((val - minY) / (maxY - minY)) * (gridHeight * scale);
        ctx.fillText(`${val}`, padding - 12, yPos);
      }
    });
    ctx.restore();

  }, [nbColonnes, nbLignes, tailleCase, zoom, offsetX, offsetY, canvasWidth, canvasHeight, mosaicConfig, showMosaicGuides, showCenterMarker, minimapDisplayMode, pattern, selectedColorId, miniMapSize, padding, gridSize, isCollapsed, showReperes]);

  const handleMouseDown = (e) => {
    setIsDragging(true);
    handleNavigate(e);
  };

  const handleMouseMove = (e) => {
    if (isDragging) {
      handleNavigate(e);
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleMouseLeave = () => {
    setIsDragging(false);
  };

  const handleNavigate = (e) => {
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX - rect.left) * (miniMapSize / rect.width);
    const y = (e.clientY - rect.top) * (miniMapSize / rect.height);

    const gridWidth = nbColonnes * tailleCase;
    const gridHeight = nbLignes * tailleCase;
    const scale = Math.min(gridSize / gridWidth, gridSize / gridHeight) * 0.9;

    const offsetMiniX = padding + (gridSize - gridWidth * scale) / 2;
    const offsetMiniY = padding + (gridSize - gridHeight * scale) / 2;

    const gridX = (x - offsetMiniX) / scale;
    const gridY = (y - offsetMiniY) / scale;

    onNavigate(gridX, gridY);
  };

  return (
    <div className="relative bg-slate-50 rounded overflow-hidden" style={{ width: 220, height: 220 }}>
      <canvas
        ref={canvasRef}
        className="cursor-pointer w-full h-full"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseLeave}
      />
      
      {/* Dialog de format */}
      <GridFormatDialog
        open={showFormatDialog}
        onClose={() => setShowFormatDialog(false)}
        currentSize={nbColonnes}
        onApplyFormat={onChangeFormat}
      />
    </div>
  );
}