import React from 'react';
import { cn } from '@/lib/utils';
import { 
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';

export default function SimpleColorPalette({ 
  colorPalette = [], 
  selectedColorId,
  onColorSelect 
}) {
  if (!colorPalette || colorPalette.length === 0) {
    return null;
  }

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-[#F8F8F8] border-t border-[#E0E0E0] z-[2000]">
      <div className="h-[100px] overflow-x-auto overflow-y-hidden px-4">
        <div className="h-full flex items-center gap-1">
          {colorPalette.map((color) => {
            const isSelected = selectedColorId === color.id;
            
            return (
              <TooltipProvider key={color.id}>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <button
                      onClick={() => onColorSelect?.(color.id)}
                      className={cn(
                        "flex-shrink-0 w-[72px] h-[64px] rounded-md overflow-hidden transition-all",
                        isSelected && "ring-2 ring-black shadow-lg"
                      )}
                      style={{ backgroundColor: color.hex || '#D9D9D9' }}
                    >
                      {/* Badge blanc avec symbole en haut */}
                      <div className="w-full h-[20px] bg-white border-b border-[#E0E0E0] flex items-center justify-center">
                        <span className="text-[12px] font-semibold text-[#222222]">
                          {color.assignedSymbolChar || '●'}
                        </span>
                      </div>
                      
                      {/* Zone colorée avec infos */}
                      <div className="w-full h-[44px] px-1.5 pt-1 flex flex-col">
                        <div className="flex justify-between items-start text-[10px] font-medium text-white drop-shadow-sm">
                          <span>{color.code || 'DMC'}</span>
                          <span>{color.totalCount || 0}</span>
                        </div>
                      </div>
                    </button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <div className="text-xs">
                      <div className="font-bold">{color.code || 'DMC'}</div>
                      <div>{color.totalCount || 0} points</div>
                    </div>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            );
          })}
        </div>
      </div>
    </div>
  );
}