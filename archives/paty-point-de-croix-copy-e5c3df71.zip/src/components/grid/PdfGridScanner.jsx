import React, { useState, useRef, useCallback } from 'react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Progress } from '@/components/ui/progress';
import { toast } from 'sonner';
import { 
  ArrowLeft, FileText, Upload, Check, CheckSquare, Square, 
  Loader2, ZoomIn, ZoomOut, Maximize2, AlertTriangle, Grid3X3,
  ChevronRight, File, Trash2, GripVertical
} from 'lucide-react';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';

// Étapes du wizard
const STEPS = [
  { id: 1, label: '1. PDF' },
  { id: 2, label: '2. Pages' },
  { id: 3, label: '3. Reconstruction' },
  { id: 4, label: '4. Import' }
];

export default function PdfGridScanner({ open, onClose, onComplete }) {
  const [currentStep, setCurrentStep] = useState(1);
  const [pdfFile, setPdfFile] = useState(null);
  const [pdfPages, setPdfPages] = useState([]);
  const [selectedPages, setSelectedPages] = useState([]);
  const [gridColumns, setGridColumns] = useState(4);
  const [gridRows, setGridRows] = useState(3);
  const [autoDetectOrder, setAutoDetectOrder] = useState(true);
  const [mosaicAssignments, setMosaicAssignments] = useState({});
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingStep, setProcessingStep] = useState(0);
  const [processingProgress, setProcessingProgress] = useState(0);
  const [reconstructedGrid, setReconstructedGrid] = useState(null);
  const [gridZoom, setGridZoom] = useState(1);
  const [gridName, setGridName] = useState('');
  const [gridAuthor, setGridAuthor] = useState('');
  const [error, setError] = useState(null);
  
  const fileInputRef = useRef(null);
  const dropZoneRef = useRef(null);

  // Reset tout quand on ferme
  const handleClose = () => {
    setCurrentStep(1);
    setPdfFile(null);
    setPdfPages([]);
    setSelectedPages([]);
    setMosaicAssignments({});
    setReconstructedGrid(null);
    setError(null);
    setGridName('');
    setGridAuthor('');
    onClose();
  };

  // Gestion du drag & drop de fichier
  const handleDragOver = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (dropZoneRef.current) {
      dropZoneRef.current.classList.add('border-blue-500', 'bg-blue-500/10');
    }
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (dropZoneRef.current) {
      dropZoneRef.current.classList.remove('border-blue-500', 'bg-blue-500/10');
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (dropZoneRef.current) {
      dropZoneRef.current.classList.remove('border-blue-500', 'bg-blue-500/10');
    }
    
    const files = e.dataTransfer.files;
    if (files.length > 0 && files[0].type === 'application/pdf') {
      handleFileSelect(files[0]);
    } else {
      toast.error('Veuillez déposer un fichier PDF');
    }
  };

  const handleFileSelect = async (file) => {
    if (!file || file.type !== 'application/pdf') {
      toast.error('Veuillez sélectionner un fichier PDF');
      return;
    }

    setPdfFile(file);
    setGridName(file.name.replace('.pdf', ''));
    
    // Simuler la détection des pages (dans une vraie implémentation, on utiliserait pdf.js)
    // Pour l'instant, on simule un nombre de pages basé sur la taille du fichier
    const estimatedPages = Math.max(1, Math.min(50, Math.floor(file.size / 100000)));
    const pages = Array.from({ length: estimatedPages }, (_, i) => ({
      id: i + 1,
      number: i + 1,
      thumbnail: null // Serait généré par pdf.js
    }));
    
    setPdfPages(pages);
    // Pré-sélectionner toutes les pages sauf la première (souvent la couverture)
    setSelectedPages(pages.slice(1).map(p => p.id));
  };

  const handleFileInputChange = (e) => {
    const file = e.target.files?.[0];
    if (file) handleFileSelect(file);
  };

  // Sélection des pages
  const togglePageSelection = (pageId) => {
    setSelectedPages(prev => 
      prev.includes(pageId) 
        ? prev.filter(id => id !== pageId)
        : [...prev, pageId]
    );
  };

  const selectAllPages = () => setSelectedPages(pdfPages.map(p => p.id));
  const deselectAllPages = () => setSelectedPages([]);

  // Mise à jour automatique de la mosaïque
  React.useEffect(() => {
    if (autoDetectOrder && selectedPages.length > 0) {
      const sortedPages = [...selectedPages].sort((a, b) => a - b);
      const newAssignments = {};
      sortedPages.forEach((pageId, index) => {
        const col = index % gridColumns;
        const row = Math.floor(index / gridColumns);
        if (row < gridRows) {
          newAssignments[`${col}-${row}`] = pageId;
        }
      });
      setMosaicAssignments(newAssignments);
    }
  }, [autoDetectOrder, selectedPages, gridColumns, gridRows]);

  // Drag & drop pour la mosaïque manuelle
  const handleMosaicDragEnd = (result) => {
    if (!result.destination) return;
    
    const sourceId = result.draggableId;
    const destKey = result.destination.droppableId;
    
    setMosaicAssignments(prev => {
      const newAssignments = { ...prev };
      // Retirer l'ancienne assignation si elle existe
      Object.keys(newAssignments).forEach(key => {
        if (newAssignments[key] === parseInt(sourceId)) {
          delete newAssignments[key];
        }
      });
      // Assigner à la nouvelle position
      newAssignments[destKey] = parseInt(sourceId);
      return newAssignments;
    });
  };

  // Reconstruction de la grille
  const handleReconstruct = async () => {
    setIsProcessing(true);
    setError(null);
    setCurrentStep(3);

    const processingSteps = [
      'Conversion des pages PDF en images…',
      'Analyse de la grille (cases et symboles)…',
      'Fusion des pages en une seule grande grille…',
      'Préparation de la grille pour l\'espace de travail…'
    ];

    try {
      for (let i = 0; i < processingSteps.length; i++) {
        setProcessingStep(i);
        setProcessingProgress((i / processingSteps.length) * 100);
        
        // Simuler le traitement (dans une vraie implémentation, ce serait le vrai traitement)
        await new Promise(resolve => setTimeout(resolve, 800 + Math.random() * 400));
      }

      setProcessingProgress(100);
      
      // Simuler le résultat de la reconstruction
      const gridWidth = gridColumns * 50; // 50 points par page
      const gridHeight = gridRows * 50;
      
      setReconstructedGrid({
        width: gridWidth,
        height: gridHeight,
        pagesCount: selectedPages.length,
        colorsCount: Math.floor(Math.random() * 20) + 10,
        symbolType: 'carrés symboles',
        // Dans une vraie implémentation, on aurait les données de la grille ici
        symbolGrid: [],
        colorPalette: []
      });

      setIsProcessing(false);
    } catch (err) {
      setError('Impossible de reconstruire la grille. Veuillez vérifier le fichier PDF.');
      setIsProcessing(false);
    }
  };

  // Import final
  const handleImport = () => {
    if (!reconstructedGrid) return;

    const finalGrid = {
      ...reconstructedGrid,
      name: gridName || 'Grille importée',
      author: gridAuthor || '',
      sourceFile: pdfFile?.name
    };

    onComplete?.(finalGrid);
    handleClose();
    toast.success('Grille importée avec succès !');
  };

  // Rendu des étapes
  const renderStepIndicator = () => (
    <div className="flex items-center justify-center gap-2 mb-6">
      {STEPS.map((step, index) => (
        <React.Fragment key={step.id}>
          <div 
            className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
              currentStep === step.id 
                ? 'bg-blue-600 text-white' 
                : currentStep > step.id
                  ? 'bg-green-600 text-white'
                  : 'bg-gray-200 text-gray-500'
            }`}
          >
            {currentStep > step.id ? <Check className="w-4 h-4" /> : step.label}
          </div>
          {index < STEPS.length - 1 && (
            <ChevronRight className="w-4 h-4 text-gray-400" />
          )}
        </React.Fragment>
      ))}
    </div>
  );

  // Étape 1: Choisir le PDF
  const renderStep1 = () => (
    <div className="flex flex-col items-center justify-center min-h-[400px]">
      {!pdfFile ? (
        <div
          ref={dropZoneRef}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          className="w-full max-w-md p-12 border-2 border-dashed border-gray-300 rounded-xl text-center cursor-pointer hover:border-blue-400 hover:bg-blue-50/50 transition-all"
          onClick={() => fileInputRef.current?.click()}
        >
          <FileText className="w-16 h-16 mx-auto text-gray-400 mb-4" />
          <p className="text-gray-600 mb-2">Glissez-déposez votre fichier PDF de grille ici</p>
          <Button variant="outline" className="mt-4">
            <Upload className="w-4 h-4 mr-2" />
            Choisir un fichier
          </Button>
          <p className="text-xs text-gray-400 mt-4">Formats acceptés : PDF (1 à 50 pages)</p>
        </div>
      ) : (
        <div className="w-full max-w-md">
          <div className="bg-white border rounded-xl p-6 shadow-sm">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                <FileText className="w-6 h-6 text-red-600" />
              </div>
              <div className="flex-1">
                <p className="font-medium text-gray-900">{pdfFile.name}</p>
                <p className="text-sm text-green-600 mt-1">
                  <Check className="w-4 h-4 inline mr-1" />
                  {pdfPages.length} pages détectées
                </p>
                <p className="text-xs text-gray-400 mt-1">
                  {(pdfFile.size / 1024 / 1024).toFixed(2)} Mo
                </p>
              </div>
              <Button 
                variant="ghost" 
                size="icon"
                onClick={() => {
                  setPdfFile(null);
                  setPdfPages([]);
                  setSelectedPages([]);
                }}
              >
                <Trash2 className="w-4 h-4 text-gray-400" />
              </Button>
            </div>
          </div>
          
          <Button 
            className="w-full mt-6 bg-blue-600 hover:bg-blue-700"
            onClick={() => setCurrentStep(2)}
          >
            Continuer : sélectionner les pages de grille
            <ChevronRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      )}
      
      <input
        ref={fileInputRef}
        type="file"
        accept="application/pdf"
        onChange={handleFileInputChange}
        className="hidden"
      />
    </div>
  );

  // Étape 2: Sélectionner les pages
  const renderStep2 = () => (
    <div className="flex gap-6 h-[500px]">
      {/* Colonne gauche: Liste des pages */}
      <div className="w-64 flex flex-col bg-gray-50 rounded-xl p-4">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-semibold text-gray-900">Pages du PDF</h3>
          <span className="text-xs text-gray-500">{selectedPages.length}/{pdfPages.length}</span>
        </div>
        
        <div className="flex gap-2 mb-3">
          <Button variant="outline" size="sm" onClick={selectAllPages} className="flex-1 text-xs">
            Tout cocher
          </Button>
          <Button variant="outline" size="sm" onClick={deselectAllPages} className="flex-1 text-xs">
            Tout décocher
          </Button>
        </div>
        
        <p className="text-xs text-gray-500 mb-3">
          Cochez uniquement les pages de grilles (sans la couverture ni les légendes).
        </p>
        
        <div className="flex-1 overflow-y-auto space-y-2">
          {pdfPages.map(page => (
            <div
              key={page.id}
              onClick={() => togglePageSelection(page.id)}
              className={`flex items-center gap-3 p-2 rounded-lg cursor-pointer transition-all ${
                selectedPages.includes(page.id) 
                  ? 'bg-blue-100 border border-blue-300' 
                  : 'bg-white border border-gray-200 hover:bg-gray-100'
              }`}
            >
              <div className={`w-5 h-5 rounded flex items-center justify-center ${
                selectedPages.includes(page.id) ? 'bg-blue-600' : 'bg-gray-200'
              }`}>
                {selectedPages.includes(page.id) && <Check className="w-3 h-3 text-white" />}
              </div>
              <div className="w-10 h-14 bg-gray-200 rounded flex items-center justify-center text-xs text-gray-500">
                {page.number}
              </div>
              <span className="text-sm">Page {page.number}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Zone centrale: Mosaïque */}
      <div className="flex-1 flex flex-col">
        <h3 className="font-semibold text-gray-900 mb-3">Organisation des grilles</h3>
        
        {/* Paramètres */}
        <div className="bg-gray-50 rounded-xl p-4 mb-4">
          <div className="flex items-center gap-6 mb-3">
            <div className="flex items-center gap-2">
              <label className="text-sm text-gray-600">Colonnes :</label>
              <Input
                type="number"
                min={1}
                max={10}
                value={gridColumns}
                onChange={(e) => setGridColumns(parseInt(e.target.value) || 1)}
                className="w-16 h-8"
              />
            </div>
            <div className="flex items-center gap-2">
              <label className="text-sm text-gray-600">Lignes :</label>
              <Input
                type="number"
                min={1}
                max={10}
                value={gridRows}
                onChange={(e) => setGridRows(parseInt(e.target.value) || 1)}
                className="w-16 h-8"
              />
            </div>
            <span className="text-xs text-gray-500">
              = {gridColumns * gridRows} pages max
            </span>
          </div>
          
          <div className="flex items-center gap-3">
            <Switch
              checked={autoDetectOrder}
              onCheckedChange={setAutoDetectOrder}
            />
            <span className="text-sm text-gray-600">Détection automatique de l'ordre</span>
          </div>
          <p className="text-xs text-gray-400 mt-1 ml-12">
            Ordre de lecture : gauche → droite, haut → bas
          </p>
        </div>

        {/* Grille de mosaïque */}
        <div className="flex-1 overflow-auto">
          <div 
            className="grid gap-2 p-4 bg-white rounded-xl border"
            style={{ 
              gridTemplateColumns: `repeat(${gridColumns}, minmax(80px, 1fr))`,
              gridTemplateRows: `repeat(${gridRows}, minmax(60px, 1fr))`
            }}
          >
            {Array.from({ length: gridRows }).map((_, rowIndex) =>
              Array.from({ length: gridColumns }).map((_, colIndex) => {
                const key = `${colIndex}-${rowIndex}`;
                const assignedPageId = mosaicAssignments[key];
                const page = pdfPages.find(p => p.id === assignedPageId);
                
                return (
                  <div
                    key={key}
                    className={`border-2 border-dashed rounded-lg flex flex-col items-center justify-center p-2 min-h-[60px] transition-all ${
                      page 
                        ? 'border-blue-400 bg-blue-50' 
                        : 'border-gray-300 bg-gray-50'
                    }`}
                  >
                    {page ? (
                      <>
                        <div className="w-8 h-10 bg-blue-200 rounded flex items-center justify-center text-xs font-medium text-blue-700">
                          {page.number}
                        </div>
                        <span className="text-[10px] text-gray-500 mt-1">Page {page.number}</span>
                      </>
                    ) : (
                      <span className="text-[10px] text-gray-400">
                        Col {colIndex + 1} / Ligne {rowIndex + 1}
                      </span>
                    )}
                  </div>
                );
              })
            )}
          </div>
        </div>

        <p className="text-xs text-gray-500 mt-3 text-center">
          Vérifiez que chaque page scannée est au bon emplacement dans la mosaïque.
        </p>

        <Button 
          className="mt-4 bg-blue-600 hover:bg-blue-700"
          onClick={handleReconstruct}
          disabled={selectedPages.length === 0}
        >
          <Grid3X3 className="w-4 h-4 mr-2" />
          Reconstruire la grande grille
        </Button>
      </div>
    </div>
  );

  // Étape 3: Reconstruction
  const renderStep3 = () => {
    if (isProcessing) {
      const steps = [
        'Conversion des pages PDF en images…',
        'Analyse de la grille (cases et symboles)…',
        'Fusion des pages en une seule grande grille…',
        'Préparation de la grille pour l\'espace de travail…'
      ];

      return (
        <div className="flex flex-col items-center justify-center min-h-[400px]">
          <Loader2 className="w-12 h-12 text-blue-600 animate-spin mb-6" />
          <h3 className="text-xl font-semibold text-gray-900 mb-2">
            Reconstruction de la grille en cours…
          </h3>
          
          <div className="w-full max-w-md mt-6">
            <Progress value={processingProgress} className="h-2 mb-4" />
            
            <div className="space-y-2">
              {steps.map((step, index) => (
                <div 
                  key={index}
                  className={`flex items-center gap-2 text-sm ${
                    index < processingStep 
                      ? 'text-green-600' 
                      : index === processingStep 
                        ? 'text-blue-600 font-medium' 
                        : 'text-gray-400'
                  }`}
                >
                  {index < processingStep ? (
                    <Check className="w-4 h-4" />
                  ) : index === processingStep ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <div className="w-4 h-4" />
                  )}
                  {step}
                </div>
              ))}
            </div>
          </div>
          
          <p className="text-sm text-gray-500 mt-6">
            Cette opération peut prendre quelques instants selon le nombre de pages.
          </p>
        </div>
      );
    }

    if (error) {
      return (
        <div className="flex flex-col items-center justify-center min-h-[400px]">
          <AlertTriangle className="w-16 h-16 text-red-500 mb-4" />
          <h3 className="text-xl font-semibold text-gray-900 mb-2">
            Impossible de reconstruire la grille
          </h3>
          <p className="text-gray-600 text-center max-w-md mb-6">
            Nous n'avons pas réussi à analyser ce PDF comme une grille de point de croix. 
            Vérifiez que le fichier contient bien des grilles scannées de bonne qualité, 
            puis réessayez avec d'autres paramètres.
          </p>
          <div className="flex gap-3">
            <Button variant="outline" onClick={() => setCurrentStep(2)}>
              Revenir aux pages
            </Button>
            <Button onClick={() => {
              setPdfFile(null);
              setPdfPages([]);
              setSelectedPages([]);
              setCurrentStep(1);
              setError(null);
            }}>
              Choisir un autre PDF
            </Button>
          </div>
        </div>
      );
    }

    // Aperçu de la grille reconstruite
    return (
      <div className="flex flex-col h-[500px]">
        <h3 className="text-xl font-semibold text-gray-900 mb-4">Grille reconstruite</h3>
        
        <div className="flex gap-6 flex-1">
          {/* Zone d'aperçu */}
          <div className="flex-1 bg-gray-100 rounded-xl relative overflow-hidden">
            <div className="absolute top-4 right-4 flex gap-2 z-10">
              <Button 
                variant="secondary" 
                size="icon"
                onClick={() => setGridZoom(z => Math.min(z * 1.2, 3))}
              >
                <ZoomIn className="w-4 h-4" />
              </Button>
              <Button 
                variant="secondary" 
                size="icon"
                onClick={() => setGridZoom(z => Math.max(z / 1.2, 0.5))}
              >
                <ZoomOut className="w-4 h-4" />
              </Button>
              <Button 
                variant="secondary" 
                size="icon"
                onClick={() => setGridZoom(1)}
              >
                <Maximize2 className="w-4 h-4" />
              </Button>
            </div>
            
            <div 
              className="w-full h-full flex items-center justify-center"
              style={{ transform: `scale(${gridZoom})`, transition: 'transform 0.2s' }}
            >
              {/* Placeholder pour la grille reconstruite */}
              <div 
                className="bg-white border-2 border-gray-300 rounded-lg"
                style={{ 
                  width: `${Math.min(400, reconstructedGrid?.width || 200)}px`,
                  height: `${Math.min(300, reconstructedGrid?.height || 150)}px`,
                  backgroundImage: 'linear-gradient(45deg, #f0f0f0 25%, transparent 25%), linear-gradient(-45deg, #f0f0f0 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #f0f0f0 75%), linear-gradient(-45deg, transparent 75%, #f0f0f0 75%)',
                  backgroundSize: '20px 20px',
                  backgroundPosition: '0 0, 0 10px, 10px -10px, -10px 0px'
                }}
              >
                <div className="w-full h-full flex items-center justify-center text-gray-400">
                  <Grid3X3 className="w-12 h-12" />
                </div>
              </div>
            </div>
          </div>

          {/* Informations techniques */}
          <div className="w-64 bg-gray-50 rounded-xl p-4">
            <h4 className="font-medium text-gray-900 mb-4">Informations</h4>
            
            <div className="space-y-3">
              <div>
                <span className="text-xs text-gray-500">Taille de la grille</span>
                <p className="font-medium">{reconstructedGrid?.width} × {reconstructedGrid?.height} points</p>
              </div>
              <div>
                <span className="text-xs text-gray-500">Pages source</span>
                <p className="font-medium">{reconstructedGrid?.pagesCount} pages</p>
              </div>
              <div>
                <span className="text-xs text-gray-500">Couleurs détectées</span>
                <p className="font-medium">{reconstructedGrid?.colorsCount} couleurs</p>
              </div>
              <div>
                <span className="text-xs text-gray-500">Type de symboles</span>
                <p className="font-medium">{reconstructedGrid?.symbolType}</p>
              </div>
            </div>
            
            <p className="text-xs text-gray-400 mt-6">
              Si le rendu ne correspond pas à vos attentes, retournez à l'étape précédente pour modifier l'organisation des pages.
            </p>
          </div>
        </div>

        <div className="flex justify-center gap-3 mt-6">
          <Button variant="outline" onClick={() => setCurrentStep(2)}>
            Revenir aux pages
          </Button>
          <Button 
            className="bg-blue-600 hover:bg-blue-700"
            onClick={() => setCurrentStep(4)}
          >
            Importer cette grille dans l'espace de travail
          </Button>
        </div>
      </div>
    );
  };

  // Étape 4: Import final
  const renderStep4 = () => (
    <div className="flex flex-col items-center justify-center min-h-[400px]">
      <div className="w-full max-w-md bg-white border rounded-xl p-6 shadow-sm">
        <h3 className="text-xl font-semibold text-gray-900 mb-4">Nommer votre grille</h3>
        
        <div className="space-y-4">
          <div>
            <label className="text-sm font-medium text-gray-700 mb-1 block">
              Nom de la grille
            </label>
            <Input
              value={gridName}
              onChange={(e) => setGridName(e.target.value)}
              placeholder="Ma grille de point de croix"
            />
          </div>
          
          <div>
            <label className="text-sm font-medium text-gray-700 mb-1 block">
              Auteur / Créateur <span className="text-gray-400">(optionnel)</span>
            </label>
            <Input
              value={gridAuthor}
              onChange={(e) => setGridAuthor(e.target.value)}
              placeholder="Nom du créateur"
            />
          </div>
        </div>

        <Button 
          className="w-full mt-6 bg-blue-600 hover:bg-blue-700"
          onClick={handleImport}
        >
          <Check className="w-4 h-4 mr-2" />
          Valider et ouvrir la grille
        </Button>
      </div>
    </div>
  );

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-5xl h-[90vh] p-0 gap-0 overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b bg-white">
          <div className="flex items-center justify-between mb-2">
            <div>
              <h2 className="text-xl font-bold text-gray-900">Scanner une grille PDF</h2>
              <p className="text-sm text-gray-500">
                Importez un fichier PDF de point de croix, reconstruisez automatiquement la grande grille, puis envoyez-la dans l'espace de travail.
              </p>
            </div>
            <Button variant="ghost" onClick={handleClose} className="text-gray-500">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour à l'import
            </Button>
          </div>
          
          {renderStepIndicator()}
        </div>

        {/* Contenu */}
        <div className="flex-1 overflow-y-auto p-6 bg-gray-50">
          {currentStep === 1 && renderStep1()}
          {currentStep === 2 && renderStep2()}
          {currentStep === 3 && renderStep3()}
          {currentStep === 4 && renderStep4()}
        </div>
      </DialogContent>
    </Dialog>
  );
}