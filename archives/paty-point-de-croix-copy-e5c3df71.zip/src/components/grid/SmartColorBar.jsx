import React, { useState } from 'react';
import { cn } from '@/lib/utils';
import {
  Pipette,
  Eye,
  Eraser,
  Star,
  Target,
  Lock
} from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { Slider } from '@/components/ui/slider';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from 'sonner';

export default function SmartColorBar({
  colorPalette = [],
  selectedColorId,
  onColorSelect,
  onPickColor,
  onIsolateColor,
  onEraseColor,
  onMarkAsPriority,
  onGoToNextZone,
  onLockColor,
  symbolSize = 100,
  onSymbolSizeChange
}) {
  const [colorFilter, setColorFilter] = useState('all');
  const [usageFilter, setUsageFilter] = useState('all');

  // Filtrer les couleurs selon les filtres actifs
  const filteredColors = colorPalette.filter(color => {
    // Filtre d'état
    if (colorFilter === 'inProgress' && (color.progress === 0 || color.progress === 100)) return false;
    if (colorFilter === 'completed' && color.progress !== 100) return false;
    
    // Filtre d'usage
    if (usageFilter === 'low' && color.totalCount >= 100) return false;
    if (usageFilter === 'medium' && (color.totalCount < 100 || color.totalCount > 500)) return false;
    if (usageFilter === 'high' && color.totalCount <= 500) return false;
    
    return true;
  });

  const selectedColor = colorPalette.find(c => c.id === selectedColorId);
  const hasSelection = !!selectedColorId;
  
  // Calculer la taille des symboles dans les languettes (proportionnel au slider)
  const tabSymbolSize = Math.round((symbolSize / 100) * 24);

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-gradient-to-b from-slate-50 to-slate-100 border-t border-slate-300 shadow-2xl z-[2000]">
      <div className="h-[150px] flex items-stretch">
        
        {/* ZONE A - Outils couleur */}
        <div className="w-56 border-r border-slate-300 p-2.5 flex flex-col">
          <div className="text-[9px] font-medium text-slate-500 uppercase tracking-wider mb-2">
            Outils couleur
          </div>
          
          {/* Grille 2x3 des outils */}
          <div className="grid grid-cols-2 gap-1.5">
            <TooltipProvider>
              {/* Ligne 1 */}
              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => onPickColor?.()}
                    disabled={!hasSelection}
                    className={cn(
                      "h-[30px] rounded-md transition-all flex items-center justify-center",
                      hasSelection 
                        ? "bg-slate-100 hover:bg-slate-200 text-black" 
                        : "bg-slate-100 text-slate-300 cursor-not-allowed"
                    )}
                  >
                    <Pipette className="w-5 h-5" />
                  </button>
                </TooltipTrigger>
                <TooltipContent><p>Pipette</p></TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => onEraseColor?.(selectedColorId)}
                    disabled={!hasSelection}
                    className={cn(
                      "h-[30px] rounded-md transition-all flex items-center justify-center",
                      hasSelection 
                        ? "bg-slate-100 hover:bg-slate-200 text-black" 
                        : "bg-slate-100 text-slate-300 cursor-not-allowed"
                    )}
                  >
                    <Eraser className="w-5 h-5" />
                  </button>
                </TooltipTrigger>
                <TooltipContent><p>Gomme</p></TooltipContent>
              </Tooltip>

              {/* Ligne 2 */}
              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => onIsolateColor?.(selectedColorId)}
                    disabled={!hasSelection}
                    className={cn(
                      "h-[30px] rounded-md transition-all flex items-center justify-center",
                      hasSelection 
                        ? "bg-slate-100 hover:bg-slate-200 text-black" 
                        : "bg-slate-100 text-slate-300 cursor-not-allowed"
                    )}
                  >
                    <Eye className="w-5 h-5" />
                  </button>
                </TooltipTrigger>
                <TooltipContent><p>Œil</p></TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => onMarkAsPriority?.(selectedColorId)}
                    disabled={!hasSelection}
                    className={cn(
                      "h-[30px] rounded-md transition-all flex items-center justify-center",
                      hasSelection 
                        ? "bg-slate-100 hover:bg-slate-200 text-black" 
                        : "bg-slate-100 text-slate-300 cursor-not-allowed"
                    )}
                  >
                    <Star className="w-5 h-5" />
                  </button>
                </TooltipTrigger>
                <TooltipContent><p>Étoile</p></TooltipContent>
              </Tooltip>

              {/* Ligne 3 */}
              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => onGoToNextZone?.(selectedColorId)}
                    disabled={!hasSelection}
                    className={cn(
                      "h-[30px] rounded-md transition-all flex items-center justify-center",
                      hasSelection 
                        ? "bg-slate-100 hover:bg-slate-200 text-black" 
                        : "bg-slate-100 text-slate-300 cursor-not-allowed"
                    )}
                  >
                    <Target className="w-5 h-5" />
                  </button>
                </TooltipTrigger>
                <TooltipContent><p>Cible</p></TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => onLockColor?.(selectedColorId)}
                    disabled={!hasSelection}
                    className={cn(
                      "h-[30px] rounded-md transition-all flex items-center justify-center",
                      hasSelection 
                        ? "bg-slate-100 hover:bg-slate-200 text-black" 
                        : "bg-slate-100 text-slate-300 cursor-not-allowed"
                    )}
                  >
                    <Lock className="w-5 h-5" />
                  </button>
                </TooltipTrigger>
                <TooltipContent><p>Cadenas</p></TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
        </div>

        {/* ZONE B - Smart Bar PatyBee */}
        <div className="w-96 border-r border-slate-300 p-2.5 flex flex-col justify-between">
          <div className="text-[9px] font-medium text-slate-500 uppercase tracking-wider mb-2">
            PatyBee Smart Bar
          </div>

          {/* Filtres d'état */}
          <div className="flex gap-1.5 mb-2">
            <button
              onClick={() => setColorFilter('all')}
              className={cn(
                "flex-1 px-2 py-1.5 rounded-md text-[10px] font-medium transition-all",
                colorFilter === 'all'
                  ? "bg-slate-900 text-white"
                  : "bg-slate-100 text-slate-700 hover:bg-slate-200"
              )}
            >
              Toutes
            </button>
            <button
              onClick={() => setColorFilter('inProgress')}
              className={cn(
                "flex-1 px-2 py-1.5 rounded-md text-[10px] font-medium transition-all",
                colorFilter === 'inProgress'
                  ? "bg-slate-900 text-white"
                  : "bg-slate-100 text-slate-700 hover:bg-slate-200"
              )}
            >
              En cours
            </button>
            <button
              onClick={() => setColorFilter('completed')}
              className={cn(
                "flex-1 px-2 py-1.5 rounded-md text-[10px] font-medium transition-all",
                colorFilter === 'completed'
                  ? "bg-slate-900 text-white"
                  : "bg-slate-100 text-slate-700 hover:bg-slate-200"
              )}
            >
              Terminées
            </button>
          </div>

          {/* Filtre d'usage */}
          <div className="mb-2">
            <label className="text-[8px] text-slate-500 mb-1 block">
              Filtre d'usage
            </label>
            <Select value={usageFilter} onValueChange={setUsageFilter}>
              <SelectTrigger className="h-7 text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Toutes</SelectItem>
                <SelectItem value="low">Peu utilisées</SelectItem>
                <SelectItem value="medium">Moyennes</SelectItem>
                <SelectItem value="high">Très utilisées</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Taille symboles */}
          <div>
            <label className="text-[8px] text-slate-500 mb-1 block">
              Taille des symboles
            </label>
            <div className="flex items-center gap-2">
              <span className="text-[9px] text-slate-500">P</span>
              <Slider
                value={[symbolSize]}
                onValueChange={([value]) => onSymbolSizeChange?.(value)}
                min={60}
                max={140}
                step={10}
                className="flex-1"
              />
              <span className="text-[9px] text-slate-500">G</span>
            </div>
          </div>
        </div>

        {/* ZONE C - Palette de couleurs */}
        <div className="flex-1 overflow-x-auto overflow-y-hidden px-4">
          <div className="h-full flex items-end gap-3 pb-3">
            {filteredColors.map((color) => {
              const isCompleted = color.progress === 100;
              return (
                <TooltipProvider key={color.id}>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <button
                        onClick={() => onColorSelect?.(color.id)}
                        className={cn(
                          "flex-shrink-0 w-28 transition-all relative group",
                          selectedColorId === color.id && "drop-shadow-xl"
                        )}
                      >
                        {/* Carré blanc avec symbole au-dessus */}
                        <div className={cn(
                          "w-full h-12 bg-white rounded-t-lg shadow-md flex items-center justify-center mb-0.5 relative",
                          selectedColorId === color.id && "ring-2 ring-white ring-offset-2 ring-offset-slate-100"
                        )}>
                          <span 
                            className="font-bold text-slate-900"
                            style={{ fontSize: `${tabSymbolSize}px` }}
                          >
                            {color.assignedSymbolChar || '●'}
                          </span>
                          {isCompleted && (
                            <div className="absolute top-1 right-1 w-4 h-4 bg-green-500 rounded-full flex items-center justify-center">
                              <span className="text-white text-xs">✓</span>
                            </div>
                          )}
                        </div>

                        {/* Languette colorée */}
                        <div 
                          className="w-full h-24 rounded-b-lg shadow-lg relative overflow-hidden"
                          style={{ backgroundColor: color.hex }}
                        >
                          {/* Infos texte */}
                          <div className="absolute top-2 left-0 right-0 px-2">
                            <div className="flex justify-between items-start text-[9px] font-semibold text-white drop-shadow-md">
                              <span>{color.code || 'DMC'}</span>
                              <span>{color.totalCount || 0} pts</span>
                            </div>
                            <div className="text-[10px] font-medium text-white drop-shadow-md mt-1 text-center truncate">
                              {color.name || 'Sans nom'}
                            </div>
                          </div>

                          {/* Barre de progression */}
                          {color.progress > 0 && (
                            <div className="absolute bottom-0 left-0 right-0 h-2 bg-black/20">
                              <div 
                                className="h-full bg-white/90"
                                style={{ width: `${color.progress}%` }}
                              />
                            </div>
                          )}
                        </div>
                      </button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <div className="text-xs">
                        <div className="font-bold">{color.name || color.code}</div>
                        <div>{color.totalCount} pts – {color.progress}% brodé</div>
                      </div>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}