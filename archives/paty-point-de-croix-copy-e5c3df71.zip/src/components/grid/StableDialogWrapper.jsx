import React from 'react';

/**
 * Wrapper stable pour les dialogs
 * Garantit que les hooks sont toujours appelés dans le même ordre
 */
export default function StableDialogWrapper({ 
  isOpen, 
  children,
  onOpenChange 
}) {
  // Toujours appeler les mêmes hooks
  const [mounted, setMounted] = React.useState(false);
  
  React.useEffect(() => {
    setMounted(true);
  }, []);
  
  // Toujours rendre, mais cacher si pas ouvert
  if (!mounted) return null;
  
  return (
    <div style={{ display: isOpen ? 'block' : 'none' }}>
      {children}
    </div>
  );
}