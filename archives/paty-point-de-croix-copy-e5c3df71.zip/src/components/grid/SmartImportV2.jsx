import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import { 
  X, Zap, Upload, Loader2, Check, Image as ImageIcon,
  FileText, Settings2, Palette, Grid3X3, Link2, FolderArchive,
  ChevronDown, ChevronUp, Sparkles, Eye, Layers, Target, AlertCircle, Camera
} from 'lucide-react';
import { toast } from 'sonner';
import { base44 } from '@/api/base44Client';
import { DMC_LIBRARY } from './dmcLibrary';
import { repairGrid, gridQualityCheck } from './RepairEngine';
import PdfGridScanner from './PdfGridScanner';

const SYMBOLS = [
  '●', '■', '▲', '◆', '★', '✦', '○', '□', '△', '◇',
  '✕', '✚', '♦', '♠', '♣', '♥', '▼', '◉', '◎', '⬟'
];

const GRID_SIZES = [
  { value: 'auto', label: 'Auto (recommandé)' },
  { value: '50', label: '50 × 50' },
  { value: '80', label: '80 × 80' },
  { value: '100', label: '100 × 100' },
  { value: '120', label: '120 × 120' },
  { value: '160', label: '160 × 160' },
  { value: '200', label: '200 × 200' },
  { value: '250', label: '250 × 250' },
];

const PALETTES = [
  { value: 'dmc', label: 'DMC' },
  { value: 'anchor', label: 'Anchor' },
  { value: 'madeira', label: 'Madeira' },
  { value: 'custom', label: 'Personnalisée' },
];

const SYMBOL_MODES = [
  { value: 'fin', label: 'Fin', desc: 'Symboles légers et discrets' },
  { value: 'contraste', label: 'Contrasté', desc: 'Symboles bien visibles' },
  { value: 'daltonien', label: 'Daltonien', desc: 'Optimisé pour les daltoniens' },
  { value: 'solide', label: 'Solide', desc: 'Symboles remplis et épais' },
];

export default function SmartImportV2({ open, onClose, onComplete }) {
  const [step, setStep] = useState(1);
  const [file, setFile] = useState(null);
  const [fileType, setFileType] = useState(null); // 'image', 'pdf', 'sub', 'url', 'zip'
  const [previewUrl, setPreviewUrl] = useState(null);
  const [originalDimensions, setOriginalDimensions] = useState({ width: 0, height: 0 });
  const [isProcessing, setIsProcessing] = useState(false);
  const [urlInput, setUrlInput] = useState('');
  const [settingsOpen, setSettingsOpen] = useState(false);
  
  // Options utilisateur
  const [config, setConfig] = useState({
    gridSize: 'auto',
    customGridSize: 100,
    maxColors: 24,
    palette: 'dmc',
    symbolMode: 'contraste',
    autoSmooth: true,
    autoDenoise: true,
    autoUnify: true,
    antiConfusion: true,
    mosaicReconstruct: false,
    gpsAlignment: true,
    // Options avancées de conversion
    stitchTypes: {
      full: true,
      half: false,
      threeQuarter: false,
      backstitch: false,
      frenchKnot: false,
      special: false,
    },
    paletteType: 'dmc',
    symbolStyle: 'standard',
    conversionMode: 'broderie',
  });
  
  const [result, setResult] = useState(null);
  const [showPdfScanner, setShowPdfScanner] = useState(false);
  const imageInputRef = useRef(null);
  const pdfInputRef = useRef(null);
  const subInputRef = useRef(null);
  const zipInputRef = useRef(null);
  const cameraInputRef = useRef(null);

  useEffect(() => {
    if (open) {
      setStep(1);
      setFile(null);
      setFileType(null);
      setPreviewUrl(null);
      setResult(null);
      setUrlInput('');
    }
  }, [open]);

  // Sélection image
  const handleImageSelect = async (e) => {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;

    if (!selectedFile.type.startsWith('image/')) {
      toast.error('Format non supporté. Utilisez PNG ou JPG.');
      return;
    }

    setFile(selectedFile);
    setFileType('image');
    
    const url = URL.createObjectURL(selectedFile);
    setPreviewUrl(url);
    
    const img = new Image();
    img.onload = () => {
      setOriginalDimensions({ width: img.width, height: img.height });
      if (config.gridSize === 'auto') {
        const suggestedSize = Math.min(200, Math.max(50, Math.round(img.width / 5)));
        setConfig(prev => ({ ...prev, customGridSize: suggestedSize }));
      }
      setStep(2);
    };
    img.src = url;
  };

  // Sélection PDF - Ouvrir le scanner de grille PDF
  const handlePdfSelect = () => {
    setShowPdfScanner(true);
  };

  // Callback quand le scanner PDF a terminé
  const handlePdfScanComplete = (gridData) => {
    setShowPdfScanner(false);
    if (gridData) {
      // Créer un pattern à partir des données du scanner
      const pattern = {
        width: gridData.width || 100,
        height: gridData.height || 100,
        sourceImage: null,
        colorPalette: gridData.colorPalette || [],
        symbolGrid: gridData.symbolGrid || [],
        offsetCol: 0,
        offsetRow: 0
      };
      saveProjectAndComplete(pattern, gridData.name || 'Import PDF');
    }
  };

  // Sélection .SUB
  const handleSubSelect = async (e) => {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;

    const fileName = selectedFile.name.toLowerCase();
    if (!fileName.endsWith('.sub')) {
      toast.error('Format non supporté. Sélectionnez un fichier .SUB.');
      return;
    }

    try {
      const content = await selectedFile.text();
      const subData = JSON.parse(content);
      
      // Importer directement le fichier .SUB
      setFile(selectedFile);
      setFileType('sub');
      
      // Traitement immédiat du .SUB
      handleSubImport(subData);
    } catch (error) {
      toast.error('Erreur lors de la lecture du fichier .SUB');
    }
  };

  // Import .SUB direct
  const handleSubImport = (subData) => {
    if (subData.metadata && subData.grid) {
      const { metadata, grid, palette } = subData;
      
      const symbolGrid = [];
      if (grid.cells) {
        grid.cells.forEach(compressedRow => {
          const row = [];
          compressedRow.forEach(({ key, count }) => {
            for (let i = 0; i < count; i++) {
              if (key === 'empty') {
                row.push(null);
              } else {
                const [symbol, color, type] = key.split('|');
                row.push({ 
                  colorId: color,
                  symbol, 
                  color, 
                  type: type || 'full',
                  done: false
                });
              }
            }
          });
          symbolGrid.push(row);
        });
      }

      const importedPattern = {
        width: metadata.dimensions?.width || symbolGrid[0]?.length || 100,
        height: metadata.dimensions?.height || symbolGrid.length || 100,
        sourceImage: subData.sourceImage || null,
        colorPalette: palette?.colors || [],
        symbolGrid,
        offsetCol: 0,
        offsetRow: 0
      };

      saveProjectAndComplete(importedPattern, metadata.name || 'Import .SUB');
    }
  };

  // Import via URL
  const handleUrlImport = async () => {
    if (!urlInput.trim()) {
      toast.error('Veuillez entrer une URL valide');
      return;
    }

    setIsProcessing(true);
    try {
      const response = await fetch(urlInput);
      const blob = await response.blob();
      
      if (blob.type.startsWith('image/')) {
        const url = URL.createObjectURL(blob);
        setPreviewUrl(url);
        setFileType('image');
        
        const img = new Image();
        img.onload = () => {
          setOriginalDimensions({ width: img.width, height: img.height });
          setStep(2);
          setIsProcessing(false);
        };
        img.onerror = () => {
          toast.error('Impossible de charger l\'image depuis cette URL');
          setIsProcessing(false);
        };
        img.src = url;
      } else {
        toast.error('L\'URL ne pointe pas vers une image valide');
        setIsProcessing(false);
      }
    } catch (error) {
      toast.error('Erreur lors du chargement de l\'URL');
      setIsProcessing(false);
    }
  };

  // Sélection ZIP
  const handleZipSelect = async (e) => {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;

    if (!selectedFile.name.toLowerCase().endsWith('.zip')) {
      toast.error('Format non supporté. Sélectionnez un fichier ZIP.');
      return;
    }

    setFile(selectedFile);
    setFileType('zip');
    toast.info('Support ZIP: détection automatique en cours d\'implémentation');
    setStep(2);
  };

  // Conversion image
  const processImage = async () => {
    if (!previewUrl) return;
    
    // Fermer immédiatement la fenêtre et afficher le bandeau
    onClose();
    toast.loading('Conversion en cours…', { id: 'conversion-status' });

    try {
      const img = new Image();
      await new Promise((resolve, reject) => {
        img.onload = resolve;
        img.onerror = reject;
        img.src = previewUrl;
      });

      // Calculer dimensions
      const ratio = img.height / img.width;
      const baseSize = config.gridSize === 'auto' 
        ? config.customGridSize 
        : parseInt(config.gridSize);
      const width = baseSize;
      const height = Math.round(width * ratio);

      // Conversion
      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      ctx.imageSmoothingEnabled = config.autoSmooth;
      ctx.drawImage(img, 0, 0, width, height);
      
      const imageData = ctx.getImageData(0, 0, width, height);
      const sourceImage = canvas.toDataURL();

      // Extraction couleurs
      const colorMap = new Map();
      const pixels = [];
      
      for (let y = 0; y < height; y++) {
        for (let x = 0; x < width; x++) {
          const idx = (y * width + x) * 4;
          const r = imageData.data[idx];
          const g = imageData.data[idx + 1];
          const b = imageData.data[idx + 2];
          
          const qr = Math.round(r / 16) * 16;
          const qg = Math.round(g / 16) * 16;
          const qb = Math.round(b / 16) * 16;
          
          const key = `${qr},${qg},${qb}`;
          colorMap.set(key, (colorMap.get(key) || 0) + 1);
          pixels.push({ r, g, b, key });
        }
      }

      // Top couleurs
      const topColors = Array.from(colorMap.entries())
        .sort((a, b) => b[1] - a[1])
        .slice(0, config.maxColors);

      // Créer palette avec DMC
      const colorPalette = topColors.map(([key, count], idx) => {
        const [r, g, b] = key.split(',').map(Number);
        const hex = rgbToHex(r, g, b);
        const dmc = findClosestDMC(hex);
        
        return {
          id: `color-${idx}`,
          hex,
          dmc: dmc.code,
          dmcName: dmc.name,
          dmcHex: dmc.hex,
          code: `DMC-${dmc.code}`,
          name: dmc.name,
          symbol: SYMBOLS[idx % SYMBOLS.length],
          assignedSymbolChar: SYMBOLS[idx % SYMBOLS.length],
          count,
          totalCount: count
        };
      });

      // Mapping couleurs
      const keyToColorId = new Map();
      topColors.forEach(([key], idx) => keyToColorId.set(key, `color-${idx}`));

      // Générer grille
      const symbolGrid = [];
      let pixelIdx = 0;
      
      for (let row = 0; row < height; row++) {
        const gridRow = [];
        for (let col = 0; col < width; col++) {
          const pixel = pixels[pixelIdx++];
          let colorId = keyToColorId.get(pixel.key);
          
          if (!colorId) {
            let minDist = Infinity;
            colorPalette.forEach(c => {
              const rgb = hexToRgb(c.hex);
              const dist = Math.sqrt(
                Math.pow(pixel.r - rgb.r, 2) +
                Math.pow(pixel.g - rgb.g, 2) +
                Math.pow(pixel.b - rgb.b, 2)
              );
              if (dist < minDist) {
                minDist = dist;
                colorId = c.id;
              }
            });
          }
          
          gridRow.push({
            colorId: colorId || 'color-0',
            type: 'S1',
            done: false
          });
        }
        symbolGrid.push(gridRow);
      }

      // Créer pattern
      let pattern = {
        width,
        height,
        sourceImage,
        colorPalette,
        symbolGrid
      };

      // Réparation auto
      const repairResult = repairGrid(pattern);
      pattern = repairResult.pattern;

      // Sauvegarder et compléter
      const projectName = file?.name?.replace(/\.[^/.]+$/, '') || 'Import ' + new Date().toLocaleDateString('fr-FR');
      
      // Mettre à jour le bandeau de statut
      toast.dismiss('conversion-status');
      toast.success('Conversion terminée. Bonne broderie ✨', { duration: 3000 });
      
      await saveProjectAndComplete(pattern, projectName);

    } catch (error) {
      console.error('Erreur:', error);
      toast.dismiss('conversion-status');
      toast.error('Erreur lors de la conversion');
    }
  };

  // Sauvegarder le projet et terminer
  const saveProjectAndComplete = async (pattern, projectName) => {
    try {
      const user = await base44.auth.me();
      
      if (user) {
        // Créer automatiquement un projet
        const projectData = {
          name: projectName,
          nb_colonnes: Math.max(300, pattern.width * 2),
          nb_lignes: Math.max(300, pattern.height * 2),
          taille_case: 25,
          zoom: 1.0,
          offset_x: 0,
          offset_y: 0,
          stitches: [],
          pattern: {
            width: pattern.width,
            height: pattern.height,
            source_image: pattern.sourceImage,
            symbolGrid: pattern.symbolGrid,
            stitches: pattern.symbolGrid?.flat().filter(Boolean).map((cell, idx) => {
              const row = Math.floor(idx / pattern.width);
              const col = idx % pattern.width;
              return {
                col,
                row,
                color: cell.colorId,
                done: cell.done || false
              };
            }) || [],
            colors: pattern.colorPalette?.map(c => ({
              hex: c.hex || c.dmcHex,
              name: c.name || c.code,
              dmc: c.code || c.dmcCode
            })) || []
          }
        };

        const newProject = await base44.entities.Grid.create(projectData);
        
        // Enregistrer l'historique d'import
        console.log('Import history:', {
          projectId: newProject.id,
          fileName: file?.name,
          fileType,
          importDate: new Date().toISOString(),
          gridSize: `${pattern.width}×${pattern.height}`,
          colorsCount: pattern.colorPalette?.length
        });

        toast.success('✅ Projet créé et ajouté à "Mes Projets"');
      }
    } catch (error) {
      console.error('Erreur sauvegarde:', error);
    }

    // Compléter l'import
    onComplete?.(pattern);
    onClose();
  };

  // Utilitaires
  const rgbToHex = (r, g, b) => '#' + [r, g, b].map(x => x.toString(16).padStart(2, '0')).join('');
  
  const hexToRgb = (hex) => {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
      r: parseInt(result[1], 16),
      g: parseInt(result[2], 16),
      b: parseInt(result[3], 16)
    } : { r: 0, g: 0, b: 0 };
  };
  
  const findClosestDMC = (hex) => {
    const rgb = hexToRgb(hex);
    let closest = DMC_LIBRARY?.[0] || { code: '310', hex: '#000000', name: 'Noir' };
    let minDist = Infinity;
    
    (DMC_LIBRARY || []).forEach(dmc => {
      const dmcRgb = hexToRgb(dmc.hex);
      const dist = Math.sqrt(
        Math.pow(rgb.r - dmcRgb.r, 2) +
        Math.pow(rgb.g - dmcRgb.g, 2) +
        Math.pow(rgb.b - dmcRgb.b, 2)
      );
      if (dist < minDist) {
        minDist = dist;
        closest = dmc;
      }
    });
    
    return closest;
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 flex items-center justify-center" style={{ zIndex: 999999, backgroundColor: 'rgba(0,0,0,0.85)' }}>
      <div className="bg-white rounded-2xl shadow-2xl w-[750px] max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-yellow-400 to-yellow-500 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-black flex items-center justify-center">
              <Zap className="w-5 h-5 text-yellow-400" />
            </div>
            <div>
              <h2 className="text-lg font-black text-black">IMPORT INTELLIGENT</h2>
              <p className="text-sm text-black/70">Importez et convertissez vos fichiers</p>
            </div>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-black/10 hover:bg-black/20 flex items-center justify-center">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Progress */}
        <div className="px-6 py-3 bg-gray-50 border-b flex gap-2">
          {[1, 2, 3].map(s => (
            <div key={s} className={`flex-1 h-2 rounded-full ${step >= s ? 'bg-yellow-500' : 'bg-gray-200'}`} />
          ))}
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto" style={{ maxHeight: 'calc(90vh - 180px)' }}>
          {/* Étape 1: Sélection */}
          {step === 1 && (
            <div className="space-y-6">
              {/* Bouton unique : Importer une image */}
              <div className="flex justify-center">
                <button
                  onClick={() => imageInputRef.current?.click()}
                  className="flex flex-col items-center gap-3 p-8 border-2 border-dashed border-gray-300 rounded-xl hover:border-yellow-500 hover:bg-yellow-50 transition-all w-full max-w-sm"
                >
                  <div className="w-16 h-16 rounded-xl bg-blue-100 flex items-center justify-center">
                    <ImageIcon className="w-8 h-8 text-blue-600" />
                  </div>
                  <span className="font-semibold text-base">Importer une image</span>
                  <span className="text-sm text-gray-500">PNG, JPG, GIF, WebP</span>
                </button>
              </div>

              {/* Input caché */}
              <input ref={imageInputRef} type="file" accept="image/*" onChange={handleImageSelect} className="hidden" />
            </div>
          )}

          {/* Étape 2: Configuration */}
          {step === 2 && (
            <div className="space-y-6">
              {/* Aperçu */}
              <div className="flex gap-4">
                <div className="flex-shrink-0">
                  {previewUrl ? (
                    <img src={previewUrl} alt="Aperçu" className="w-32 h-32 object-contain rounded-lg border" />
                  ) : (
                    <div className="w-32 h-32 bg-gray-100 rounded-lg flex items-center justify-center">
                      <FileText className="w-8 h-8 text-gray-400" />
                    </div>
                  )}
                </div>
                <div className="flex-1">
                  <p className="font-medium">{file?.name || 'Fichier importé'}</p>
                  {originalDimensions.width > 0 && (
                    <p className="text-sm text-gray-500">Original : {originalDimensions.width} × {originalDimensions.height} px</p>
                  )}
                  <p className="text-sm text-gray-500 mt-1">Type : {fileType?.toUpperCase()}</p>
                  <p className="text-sm text-green-600 mt-1">✓ Ratio maintenu automatiquement</p>
                </div>
              </div>

              {/* Taille grille */}
              <div className="space-y-2">
                <Label className="flex items-center gap-2">
                  <Grid3X3 className="w-4 h-4" />
                  Taille de grille : {config.gridSize === 'auto' ? `${config.customGridSize} (auto)` : config.gridSize} points
                </Label>
                <Slider
                  value={[config.gridSize === 'auto' ? config.customGridSize : parseInt(config.gridSize)]}
                  onValueChange={([v]) => setConfig(p => ({...p, gridSize: 'auto', customGridSize: v}))}
                  min={30}
                  max={300}
                  step={10}
                />
              </div>

              {/* Nombre couleurs */}
              <div className="space-y-2">
                <Label className="flex items-center gap-2">
                  <Palette className="w-4 h-4" />
                  Nombre max de couleurs : {config.maxColors}
                </Label>
                <Slider
                  value={[config.maxColors]}
                  onValueChange={([v]) => setConfig(p => ({...p, maxColors: v}))}
                  min={4}
                  max={48}
                  step={2}
                />
              </div>

              {/* Options avancées de conversion */}
              <Collapsible>
                <CollapsibleTrigger className="w-full">
                  <div className="flex items-center justify-between p-3 bg-gradient-to-r from-purple-50 to-indigo-50 border border-purple-200 rounded-xl hover:bg-purple-100 transition-colors">
                    <div className="flex items-center gap-2">
                      <Settings2 className="w-4 h-4 text-purple-600" />
                      <span className="font-medium text-sm">Options avancées de conversion</span>
                    </div>
                    <ChevronDown className="w-4 h-4 text-purple-600" />
                  </div>
                </CollapsibleTrigger>
                <CollapsibleContent>
                  <div className="mt-3 p-4 border border-purple-100 rounded-xl space-y-5 bg-white">
                    
                    {/* Section 1: Styles de points détectés */}
                    <div className="space-y-3">
                      <div>
                        <h4 className="text-sm font-semibold text-gray-800 mb-1">Styles de points détectés</h4>
                        <p className="text-xs text-gray-500">Brood-Way analyse l'image pour détecter les styles de points possibles.</p>
                      </div>
                      <div className="grid grid-cols-3 gap-2">
                        <label className="flex items-center gap-2 p-2 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors">
                          <Checkbox 
                            checked={config.stitchTypes.full}
                            onCheckedChange={(v) => setConfig(p => ({...p, stitchTypes: {...p.stitchTypes, full: v}}))}
                          />
                          <span className="text-xs font-medium">Point complet (x)</span>
                        </label>
                        <label className="flex items-center gap-2 p-2 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors">
                          <Checkbox 
                            checked={config.stitchTypes.half}
                            onCheckedChange={(v) => setConfig(p => ({...p, stitchTypes: {...p.stitchTypes, half: v}}))}
                          />
                          <span className="text-xs font-medium">Demi-point (½)</span>
                        </label>
                        <label className="flex items-center gap-2 p-2 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors">
                          <Checkbox 
                            checked={config.stitchTypes.threeQuarter}
                            onCheckedChange={(v) => setConfig(p => ({...p, stitchTypes: {...p.stitchTypes, threeQuarter: v}}))}
                          />
                          <span className="text-xs font-medium">Trois-quarts (¾)</span>
                        </label>
                        <label className="flex items-center gap-2 p-2 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors">
                          <Checkbox 
                            checked={config.stitchTypes.backstitch}
                            onCheckedChange={(v) => setConfig(p => ({...p, stitchTypes: {...p.stitchTypes, backstitch: v}}))}
                          />
                          <span className="text-xs font-medium">Point arrière</span>
                        </label>
                        <label className="flex items-center gap-2 p-2 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors">
                          <Checkbox 
                            checked={config.stitchTypes.frenchKnot}
                            onCheckedChange={(v) => setConfig(p => ({...p, stitchTypes: {...p.stitchTypes, frenchKnot: v}}))}
                          />
                          <span className="text-xs font-medium">Nœud (French knot)</span>
                        </label>
                        <label className="flex items-center gap-2 p-2 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors">
                          <Checkbox 
                            checked={config.stitchTypes.special}
                            onCheckedChange={(v) => setConfig(p => ({...p, stitchTypes: {...p.stitchTypes, special: v}}))}
                          />
                          <span className="text-xs font-medium">Points spéciaux</span>
                        </label>
                      </div>
                      <p className="text-[10px] text-gray-400">Cochez les styles que vous souhaitez inclure dans votre grille.</p>
                    </div>

                    {/* Section 2: Palette & symboles */}
                    <div className="space-y-3 pt-3 border-t border-gray-100">
                      <h4 className="text-sm font-semibold text-gray-800">Palette & symboles</h4>
                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-1">
                          <Label className="text-xs text-gray-600">Choix de palette</Label>
                          <Select 
                            value={config.paletteType} 
                            onValueChange={(v) => setConfig(p => ({...p, paletteType: v}))}
                          >
                            <SelectTrigger className="h-9">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="dmc">DMC (par défaut)</SelectItem>
                              <SelectItem value="anchor">Anchor</SelectItem>
                              <SelectItem value="madeira">Madeira</SelectItem>
                              <SelectItem value="auto">Auto-détection</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs text-gray-600">Style de symboles</Label>
                          <Select 
                            value={config.symbolStyle} 
                            onValueChange={(v) => setConfig(p => ({...p, symbolStyle: v}))}
                          >
                            <SelectTrigger className="h-9">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="standard">Standard</SelectItem>
                              <SelectItem value="contraste">Contrasté</SelectItem>
                              <SelectItem value="daltonien">Daltonien</SelectItem>
                              <SelectItem value="gros">Gros symboles</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <p className="text-[10px] text-gray-400">Les symboles et couleurs seront optimisés pour une lecture confortable.</p>
                    </div>

                    {/* Section 3: Mode de conversion */}
                    <div className="space-y-3 pt-3 border-t border-gray-100">
                      <h4 className="text-sm font-semibold text-gray-800">Mode de conversion</h4>
                      <RadioGroup 
                        value={config.conversionMode} 
                        onValueChange={(v) => setConfig(p => ({...p, conversionMode: v}))}
                        className="flex gap-2"
                      >
                        <label className={`flex-1 flex items-center gap-2 p-3 rounded-lg border cursor-pointer transition-all ${config.conversionMode === 'fidele' ? 'border-purple-500 bg-purple-50' : 'border-gray-200 hover:border-gray-300'}`}>
                          <RadioGroupItem value="fidele" id="fidele" />
                          <div>
                            <span className="text-xs font-medium block">Fidèle au visuel</span>
                            <span className="text-[10px] text-gray-500">Respecte les couleurs d'origine</span>
                          </div>
                        </label>
                        <label className={`flex-1 flex items-center gap-2 p-3 rounded-lg border cursor-pointer transition-all ${config.conversionMode === 'broderie' ? 'border-purple-500 bg-purple-50' : 'border-gray-200 hover:border-gray-300'}`}>
                          <RadioGroupItem value="broderie" id="broderie" />
                          <div>
                            <span className="text-xs font-medium block">Optimisé broderie</span>
                            <span className="text-[10px] text-gray-500">Simplifie pour la broderie</span>
                          </div>
                        </label>
                        <label className={`flex-1 flex items-center gap-2 p-3 rounded-lg border cursor-pointer transition-all ${config.conversionMode === 'lisible' ? 'border-purple-500 bg-purple-50' : 'border-gray-200 hover:border-gray-300'}`}>
                          <RadioGroupItem value="lisible" id="lisible" />
                          <div>
                            <span className="text-xs font-medium block">Ultra lisible</span>
                            <span className="text-[10px] text-gray-500">Symboles très distincts</span>
                          </div>
                        </label>
                      </RadioGroup>
                      <p className="text-[10px] text-gray-400">Choisissez la priorité de la conversion.</p>
                    </div>
                  </div>
                </CollapsibleContent>
              </Collapsible>

              {/* Info */}
              <div className="p-3 bg-blue-50 rounded-lg flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-blue-500 mt-0.5 flex-shrink-0" />
                <div className="text-sm text-blue-700">
                  Un projet sera automatiquement créé dans "Mes Projets" avec une vignette générée.
                </div>
              </div>

              <div className="flex gap-3">
                <Button variant="outline" onClick={() => setStep(1)} className="flex-1">
                  Retour
                </Button>
                <Button onClick={processImage} className="flex-1 bg-black hover:bg-gray-800">
                  Convertir maintenant
                </Button>
              </div>
            </div>
          )}

          {/* Étape 3: Conversion */}
          {step === 3 && (
            <div className="text-center py-12">
              <Loader2 className="w-16 h-16 animate-spin text-yellow-500 mx-auto mb-4" />
              <p className="text-lg font-medium">Conversion en cours...</p>
              <p className="text-sm text-gray-500">Réparation automatique • Création du projet</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}