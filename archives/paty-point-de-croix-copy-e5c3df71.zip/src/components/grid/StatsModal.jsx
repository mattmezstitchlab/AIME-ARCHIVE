import React, { useState, useMemo, useEffect } from 'react';
import { X } from 'lucide-react';

const SPEED_OPTIONS = [
  { label: '80 pts/h', value: 80 },
  { label: '100 pts/h', value: 100 },
  { label: '120 pts/h', value: 120 },
  { label: '150 pts/h', value: 150 },
];

export default function StatsModal({
  isOpen,
  onClose,
  pattern,
  colorPalette = [],
  selectedColorId,
}) {
  const [stitchSpeed, setStitchSpeed] = useState(120);
  const [animatedPercent, setAnimatedPercent] = useState(0);

  // Calculs globaux
  const globalStats = useMemo(() => {
    if (!pattern?.symbolGrid) {
      return {
        totalPoints: 0,
        donePoints: 0,
        percent: 0,
        colorsCount: 0,
        colorsRemaining: 0,
        gridWidth: 0,
        gridHeight: 0,
        largestZone: { count: 0, percent: 0 },
      };
    }

    const grid = pattern.symbolGrid;
    const height = grid.length;
    const width = grid[0]?.length || 0;

    let totalPoints = 0;
    let donePoints = 0;
    const colorCounts = {};

    grid.forEach(row => {
      row?.forEach(cell => {
        if (cell?.colorId) {
          totalPoints++;
          if (cell.done) donePoints++;
          colorCounts[cell.colorId] = (colorCounts[cell.colorId] || 0) + 1;
        }
      });
    });

    const colorIds = Object.keys(colorCounts);
    const colorsCount = colorIds.length;

    // Couleurs restantes (non 100% brodées)
    let colorsRemaining = 0;
    colorIds.forEach(colorId => {
      const colorTotal = colorCounts[colorId];
      let colorDone = 0;
      grid.forEach(row => {
        row?.forEach(cell => {
          if (cell?.colorId === colorId && cell.done) colorDone++;
        });
      });
      if (colorDone < colorTotal) colorsRemaining++;
    });

    // Plus grande zone
    const sortedColors = Object.entries(colorCounts).sort((a, b) => b[1] - a[1]);
    const largestZone = sortedColors[0] 
      ? { count: sortedColors[0][1], percent: totalPoints > 0 ? Math.round((sortedColors[0][1] / totalPoints) * 1000) / 10 : 0 }
      : { count: 0, percent: 0 };

    const percent = totalPoints > 0 ? Math.round((donePoints / totalPoints) * 100) : 0;

    return {
      totalPoints,
      donePoints,
      percent,
      colorsCount,
      colorsRemaining,
      gridWidth: width,
      gridHeight: height,
      largestZone,
    };
  }, [pattern]);

  // Animation du pourcentage
  useEffect(() => {
    if (isOpen) {
      setAnimatedPercent(0);
      const target = globalStats.percent;
      const duration = 800;
      const startTime = Date.now();

      const animate = () => {
        const elapsed = Date.now() - startTime;
        const progress = Math.min(elapsed / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 3);
        setAnimatedPercent(Math.round(target * eased));

        if (progress < 1) {
          requestAnimationFrame(animate);
        }
      };

      requestAnimationFrame(animate);
    }
  }, [isOpen, globalStats.percent]);

  // Calculs de temps
  const timeStats = useMemo(() => {
    const totalHours = globalStats.totalPoints / stitchSpeed;
    const doneHours = globalStats.donePoints / stitchSpeed;
    const remainingHours = totalHours - doneHours;

    const formatTime = (hours) => {
      const h = Math.floor(hours);
      const m = Math.round((hours - h) * 60);
      return h > 0 ? `${h}h${m.toString().padStart(2, '0')}` : `${m}min`;
    };

    return {
      total: formatTime(totalHours),
      done: formatTime(doneHours),
      remaining: formatTime(remainingHours),
      totalRaw: Math.round(totalHours),
    };
  }, [globalStats, stitchSpeed]);

  // Top 5 couleurs
  const topColors = useMemo(() => {
    if (!pattern?.symbolGrid || !colorPalette.length) return [];

    const colorCounts = {};
    pattern.symbolGrid.forEach(row => {
      row?.forEach(cell => {
        if (cell?.colorId) {
          colorCounts[cell.colorId] = (colorCounts[cell.colorId] || 0) + 1;
        }
      });
    });

    return Object.entries(colorCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([colorId, count]) => {
        const color = colorPalette.find(c => c.id === colorId);
        const percent = globalStats.totalPoints > 0 
          ? Math.round((count / globalStats.totalPoints) * 1000) / 10 
          : 0;
        return {
          id: colorId,
          hex: color?.hex || color?.dmcHex || '#808080',
          code: String(color?.code || color?.dmc || '???').replace(/DMC[-\s]?/gi, ''),
          symbol: color?.assignedSymbolChar || '●',
          count,
          percent,
        };
      });
  }, [pattern, colorPalette, globalStats.totalPoints]);

  // Couleur sélectionnée
  const selectedColorStats = useMemo(() => {
    if (!selectedColorId || !pattern?.symbolGrid) return null;

    const color = colorPalette.find(c => c.id === selectedColorId);
    if (!color) return null;

    let totalCount = 0;
    let doneCount = 0;

    pattern.symbolGrid.forEach(row => {
      row?.forEach(cell => {
        if (cell?.colorId === selectedColorId) {
          totalCount++;
          if (cell.done) doneCount++;
        }
      });
    });

    const percent = globalStats.totalPoints > 0 
      ? Math.round((totalCount / globalStats.totalPoints) * 1000) / 10 
      : 0;
    const progressPercent = totalCount > 0 ? Math.round((doneCount / totalCount) * 100) : 0;
    const estimatedHours = totalCount / stitchSpeed;
    const h = Math.floor(estimatedHours);
    const m = Math.round((estimatedHours - h) * 60);
    const estimatedTime = h > 0 ? `${h}h${m.toString().padStart(2, '0')}` : `${m}min`;

    return {
      hex: color.hex || color.dmcHex || '#808080',
      code: String(color.code || color.dmc || '???').replace(/DMC[-\s]?/gi, ''),
      symbol: color.assignedSymbolChar || '●',
      totalCount,
      doneCount,
      percent,
      progressPercent,
      estimatedTime,
    };
  }, [selectedColorId, pattern, colorPalette, globalStats.totalPoints, stitchSpeed]);

  // Fermer au clic extérieur
  const handleBackdropClick = (e) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  if (!isOpen) return null;

  // Donut chart
  const radius = 70;
  const strokeWidth = 14;
  const circumference = 2 * Math.PI * radius;
  const strokeDasharray = circumference;
  const strokeDashoffset = circumference - (animatedPercent / 100) * circumference;

  return (
    <div
      onClick={handleBackdropClick}
      style={{
        position: 'fixed',
        inset: 0,
        backgroundColor: 'rgba(0,0,0,0.6)',
        zIndex: 20000,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        animation: 'fadeIn 0.2s ease-out',
      }}
    >
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        @keyframes scaleIn {
          from { opacity: 0; transform: scale(0.96); }
          to { opacity: 1; transform: scale(1); }
        }
      `}</style>

      <div
        style={{
          width: '780px',
          maxWidth: '95vw',
          height: '520px',
          maxHeight: '90vh',
          backgroundColor: '#FFFFFF',
          borderRadius: '16px',
          boxShadow: '0 25px 80px rgba(0,0,0,0.3)',
          position: 'relative',
          display: 'flex',
          flexDirection: 'column',
          overflow: 'hidden',
          animation: 'scaleIn 0.25s ease-out',
        }}
      >
        {/* Header */}
        <div style={{
          padding: '24px 32px 16px',
          borderBottom: '1px solid #E5E5E5',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
        }}>
          <h2 style={{
            fontSize: '20px',
            fontWeight: 700,
            color: '#111',
            margin: 0,
            letterSpacing: '-0.02em',
          }}>
            STATISTIQUES DU PROJET
          </h2>
          <button
            onClick={onClose}
            style={{
              width: '36px',
              height: '36px',
              borderRadius: '8px',
              border: 'none',
              backgroundColor: '#F5F5F5',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              transition: 'background 0.15s',
            }}
            onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#E8E8E8'}
            onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#F5F5F5'}
          >
            <X style={{ width: '18px', height: '18px', color: '#666' }} />
          </button>
        </div>

        {/* Contenu principal */}
        <div style={{
          flex: 1,
          display: 'flex',
          padding: '24px 32px',
          gap: '32px',
          overflowY: 'auto',
        }}>
          {/* Colonne gauche */}
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: '24px' }}>
            {/* Bloc global - 2 colonnes */}
            <div style={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              gap: '12px 24px',
            }}>
              <StatItem label="Total points" value={globalStats.totalPoints.toLocaleString()} />
              <StatItem label="Couleurs DMC" value={globalStats.colorsCount} />
              <StatItem label="Taille de grille" value={`${globalStats.gridWidth} × ${globalStats.gridHeight}`} />
              <StatItem label="Points brodés" value={`${globalStats.donePoints.toLocaleString()} (${globalStats.percent}%)`} />
              <StatItem label="Plus grande zone" value={`${globalStats.largestZone.count.toLocaleString()} pts (${globalStats.largestZone.percent}%)`} />
              <StatItem label="Couleurs restantes" value={globalStats.colorsRemaining} />
            </div>

            {/* Graphique donut */}
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '32px',
              padding: '16px 0',
            }}>
              <svg width="160" height="160" viewBox="0 0 160 160">
                {/* Fond gris */}
                <circle
                  cx="80"
                  cy="80"
                  r={radius}
                  fill="none"
                  stroke="#E5E5E5"
                  strokeWidth={strokeWidth}
                />
                {/* Progression */}
                <circle
                  cx="80"
                  cy="80"
                  r={radius}
                  fill="none"
                  stroke="#111"
                  strokeWidth={strokeWidth}
                  strokeLinecap="round"
                  strokeDasharray={strokeDasharray}
                  strokeDashoffset={strokeDashoffset}
                  transform="rotate(-90 80 80)"
                  style={{ transition: 'stroke-dashoffset 0.3s ease-out' }}
                />
                {/* Texte central */}
                <text x="80" y="75" textAnchor="middle" style={{ fontSize: '28px', fontWeight: 700, fill: '#111' }}>
                  {animatedPercent}%
                </text>
                <text x="80" y="95" textAnchor="middle" style={{ fontSize: '11px', fill: '#888' }}>
                  complété
                </text>
              </svg>

              {/* Temps estimé */}
              <div style={{ flex: 1 }}>
                <h4 style={{ fontSize: '13px', fontWeight: 600, color: '#666', marginBottom: '12px' }}>
                  Temps estimé
                </h4>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '13px' }}>
                    <span style={{ color: '#888' }}>Temps total</span>
                    <span style={{ fontWeight: 600, color: '#111' }}>~ {timeStats.totalRaw} heures</span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '13px' }}>
                    <span style={{ color: '#888' }}>Temps brodé</span>
                    <span style={{ fontWeight: 500, color: '#333' }}>{timeStats.done}</span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '13px' }}>
                    <span style={{ color: '#888' }}>Temps restant</span>
                    <span style={{ fontWeight: 600, color: '#111' }}>~ {timeStats.remaining}</span>
                  </div>
                </div>

                {/* Slider vitesse */}
                <div style={{ marginTop: '16px' }}>
                  <div style={{ fontSize: '11px', color: '#888', marginBottom: '8px' }}>
                    Vitesse de broderie
                  </div>
                  <div style={{ display: 'flex', gap: '6px' }}>
                    {SPEED_OPTIONS.map(opt => (
                      <button
                        key={opt.value}
                        onClick={() => setStitchSpeed(opt.value)}
                        style={{
                          flex: 1,
                          padding: '6px 8px',
                          fontSize: '11px',
                          fontWeight: stitchSpeed === opt.value ? 600 : 400,
                          color: stitchSpeed === opt.value ? '#FFF' : '#666',
                          backgroundColor: stitchSpeed === opt.value ? '#111' : '#F5F5F5',
                          border: 'none',
                          borderRadius: '6px',
                          cursor: 'pointer',
                          transition: 'all 0.15s',
                        }}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Top 5 couleurs */}
            <div>
              <h4 style={{ fontSize: '13px', fontWeight: 600, color: '#666', marginBottom: '12px' }}>
                Top 5 couleurs les plus utilisées
              </h4>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                {topColors.map((color, index) => (
                  <div
                    key={color.id}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px',
                      padding: '8px 12px',
                      backgroundColor: '#FAFAFA',
                      borderRadius: '8px',
                    }}
                  >
                    <span style={{ fontSize: '12px', color: '#888', width: '16px' }}>
                      {index + 1}.
                    </span>
                    <div
                      style={{
                        width: '24px',
                        height: '24px',
                        backgroundColor: color.hex,
                        borderRadius: '4px',
                        border: '1px solid rgba(0,0,0,0.1)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}
                    >
                      <span style={{
                        fontSize: '11px',
                        fontWeight: 700,
                        color: isLightColor(color.hex) ? '#000' : '#FFF',
                      }}>
                        {color.symbol}
                      </span>
                    </div>
                    <span style={{ fontSize: '13px', fontWeight: 600, color: '#111', width: '50px' }}>
                      {color.code}
                    </span>
                    <span style={{ fontSize: '12px', color: '#666', flex: 1 }}>
                      {color.count.toLocaleString()} pts
                    </span>
                    <span style={{ fontSize: '12px', color: '#888' }}>
                      {color.percent}%
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Colonne droite - Couleur sélectionnée */}
          {selectedColorStats && (
            <div style={{
              width: '200px',
              padding: '20px',
              backgroundColor: '#FAFAFA',
              borderRadius: '12px',
              alignSelf: 'flex-start',
            }}>
              <h4 style={{ fontSize: '12px', fontWeight: 600, color: '#888', marginBottom: '16px' }}>
                Couleur active
              </h4>
              
              <div style={{
                display: 'flex',
                alignItems: 'center',
                gap: '12px',
                marginBottom: '16px',
              }}>
                <div
                  style={{
                    width: '40px',
                    height: '40px',
                    backgroundColor: selectedColorStats.hex,
                    borderRadius: '8px',
                    border: '1px solid rgba(0,0,0,0.1)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <span style={{
                    fontSize: '16px',
                    fontWeight: 700,
                    color: isLightColor(selectedColorStats.hex) ? '#000' : '#FFF',
                  }}>
                    {selectedColorStats.symbol}
                  </span>
                </div>
                <span style={{ fontSize: '18px', fontWeight: 700, color: '#111' }}>
                  {selectedColorStats.code}
                </span>
              </div>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px' }}>
                  <span style={{ color: '#888' }}>Points</span>
                  <span style={{ fontWeight: 600, color: '#111' }}>{selectedColorStats.totalCount.toLocaleString()}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px' }}>
                  <span style={{ color: '#888' }}>% du total</span>
                  <span style={{ fontWeight: 500, color: '#333' }}>{selectedColorStats.percent}%</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px' }}>
                  <span style={{ color: '#888' }}>Temps estimé</span>
                  <span style={{ fontWeight: 500, color: '#333' }}>~{selectedColorStats.estimatedTime}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px' }}>
                  <span style={{ color: '#888' }}>Brodés</span>
                  <span style={{ fontWeight: 600, color: '#111' }}>
                    {selectedColorStats.doneCount.toLocaleString()} ({selectedColorStats.progressPercent}%)
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function StatItem({ label, value }) {
  return (
    <div>
      <div style={{ fontSize: '11px', color: '#888', marginBottom: '2px' }}>{label}</div>
      <div style={{ fontSize: '15px', fontWeight: 600, color: '#111' }}>{value}</div>
    </div>
  );
}

function isLightColor(hex) {
  if (!hex) return true;
  const c = hex.replace('#', '');
  const r = parseInt(c.substr(0, 2), 16);
  const g = parseInt(c.substr(2, 2), 16);
  const b = parseInt(c.substr(4, 2), 16);
  const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  return luminance > 0.6;
}