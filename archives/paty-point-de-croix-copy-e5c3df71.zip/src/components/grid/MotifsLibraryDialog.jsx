import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { cn } from '@/lib/utils';

const MOTIFS_LIBRARY = {
  animaux: [
    { id: 'butterfly', name: 'Papillon', pattern: [[1,1,1],[1,0,1],[1,1,1]] },
    { id: 'bird', name: 'Oiseau', pattern: [[0,1,0],[1,1,1],[0,1,0]] },
    { id: 'cat', name: 'Chat', pattern: [[1,0,1],[0,1,0],[1,1,1]] }
  ],
  nature: [
    { id: 'flower', name: 'Fleur', pattern: [[0,1,0],[1,1,1],[0,1,0]] },
    { id: 'tree', name: 'Arbre', pattern: [[0,1,0],[1,1,1],[0,1,0],[0,1,0]] },
    { id: 'leaf', name: 'Feuille', pattern: [[0,1],[1,1],[1,0]] }
  ],
  geometrique: [
    { id: 'star', name: 'Étoile', pattern: [[0,1,0],[1,1,1],[0,1,0]] },
    { id: 'heart', name: 'Cœur', pattern: [[1,0,1],[1,1,1],[0,1,0]] },
    { id: 'diamond', name: 'Losange', pattern: [[0,1,0],[1,0,1],[0,1,0]] }
  ],
  decorations: [
    { id: 'border1', name: 'Bordure 1', pattern: [[1,1,1],[1,0,1],[1,1,1]] },
    { id: 'corner', name: 'Coin', pattern: [[1,1],[1,0]] },
    { id: 'dots', name: 'Points', pattern: [[1,0,1],[0,0,0],[1,0,1]] }
  ]
};

export default function MotifsLibraryDialog({ open, onClose, onSelectMotif }) {
  const [activeTab, setActiveTab] = useState('animaux');

  const handleSelectMotif = (motif) => {
    onSelectMotif(motif);
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>Bibliothèque de motifs</DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-4 w-full">
            <TabsTrigger value="animaux">Animaux</TabsTrigger>
            <TabsTrigger value="nature">Nature</TabsTrigger>
            <TabsTrigger value="geometrique">Géométrique</TabsTrigger>
            <TabsTrigger value="decorations">Décorations</TabsTrigger>
          </TabsList>

          {Object.entries(MOTIFS_LIBRARY).map(([category, motifs]) => (
            <TabsContent key={category} value={category} className="mt-4">
              <div className="grid grid-cols-3 gap-4">
                {motifs.map((motif) => (
                  <button
                    key={motif.id}
                    onClick={() => handleSelectMotif(motif)}
                    className="p-4 border-2 border-slate-200 rounded-lg hover:border-slate-400 hover:bg-slate-50 transition-all"
                  >
                    <div className="flex flex-col items-center gap-2">
                      <MotifPreview pattern={motif.pattern} />
                      <span className="text-sm font-medium text-slate-700">
                        {motif.name}
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            </TabsContent>
          ))}
        </Tabs>

        <div className="flex justify-end">
          <Button variant="outline" onClick={onClose}>
            Fermer
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function MotifPreview({ pattern }) {
  return (
    <div className="inline-flex flex-col gap-0.5 bg-slate-100 p-2 rounded">
      {pattern.map((row, rowIndex) => (
        <div key={rowIndex} className="flex gap-0.5">
          {row.map((cell, colIndex) => (
            <div
              key={colIndex}
              className={cn(
                "w-3 h-3",
                cell === 1 ? "bg-slate-800" : "bg-transparent"
              )}
            />
          ))}
        </div>
      ))}
    </div>
  );
}