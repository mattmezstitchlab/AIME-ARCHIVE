import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { X, Check, Zap } from 'lucide-react';
import { SUB_STITCH_TYPES, SUB_STITCH_CATEGORIES } from './subStitchTypes';

export default function SubStitchPicker({ open, onClose, onSelect, currentStitch }) {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [hoveredStitch, setHoveredStitch] = useState(null);

  if (!open) return null;

  const filteredStitches = selectedCategory === 'all' 
    ? SUB_STITCH_TYPES 
    : SUB_STITCH_TYPES.filter(s => s.category === selectedCategory);

  return (
    <div className="fixed inset-0 z-[99999] flex items-center justify-center bg-black/60">
      <div className="bg-white rounded-xl shadow-2xl w-[600px] max-h-[80vh] overflow-hidden">
        {/* Header */}
        <div className="bg-black px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-yellow-400 to-yellow-600 flex items-center justify-center">
              <Zap className="w-5 h-5 text-black" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Points SUB™</h2>
              <p className="text-sm text-gray-400">12 points modernes et universels</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center"
          >
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        {/* Categories */}
        <div className="px-4 py-3 border-b bg-gray-50 flex gap-2 flex-wrap">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-3 py-1.5 rounded-full text-sm font-medium transition-colors ${
              selectedCategory === 'all' 
                ? 'bg-black text-white' 
                : 'bg-white border hover:bg-gray-100'
            }`}
          >
            Tous
          </button>
          {Object.entries(SUB_STITCH_CATEGORIES).map(([key, cat]) => (
            <button
              key={key}
              onClick={() => setSelectedCategory(key)}
              className={`px-3 py-1.5 rounded-full text-sm font-medium transition-colors ${
                selectedCategory === key 
                  ? 'bg-black text-white' 
                  : 'bg-white border hover:bg-gray-100'
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>

        {/* Grid of stitches */}
        <div className="p-4 overflow-y-auto" style={{ maxHeight: '400px' }}>
          <div className="grid grid-cols-3 gap-3">
            {filteredStitches.map(stitch => (
              <button
                key={stitch.id}
                onClick={() => {
                  onSelect(stitch);
                  onClose();
                }}
                onMouseEnter={() => setHoveredStitch(stitch)}
                onMouseLeave={() => setHoveredStitch(null)}
                className={`p-4 rounded-xl border-2 transition-all text-left ${
                  currentStitch?.id === stitch.id
                    ? 'border-yellow-500 bg-yellow-50'
                    : 'border-gray-200 hover:border-gray-400 hover:bg-gray-50'
                }`}
              >
                <div className="flex items-center gap-3 mb-2">
                  <div 
                    className="w-10 h-10 rounded-lg flex items-center justify-center text-2xl"
                    style={{ backgroundColor: stitch.color + '20' }}
                  >
                    {stitch.icon}
                  </div>
                  <div>
                    <div className="font-bold text-sm">{stitch.code}</div>
                    <div className="text-xs text-gray-500">Niveau {stitch.difficulty}</div>
                  </div>
                  {currentStitch?.id === stitch.id && (
                    <Check className="w-5 h-5 text-yellow-600 ml-auto" />
                  )}
                </div>
                <div className="text-sm font-medium">{stitch.name}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Info panel */}
        {hoveredStitch && (
          <div className="px-4 py-3 border-t bg-gray-50">
            <div className="flex items-start gap-3">
              <div 
                className="w-12 h-12 rounded-lg flex items-center justify-center text-3xl flex-shrink-0"
                style={{ backgroundColor: hoveredStitch.color + '20' }}
              >
                {hoveredStitch.icon}
              </div>
              <div className="flex-1">
                <div className="font-bold">{hoveredStitch.name}</div>
                <p className="text-sm text-gray-600 mt-1">{hoveredStitch.description}</p>
                <p className="text-xs text-gray-500 mt-1">
                  <strong>Usage :</strong> {hoveredStitch.usage}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="px-4 py-3 border-t bg-white flex items-center justify-between">
          <p className="text-xs text-gray-500">
            <span className="font-semibold text-yellow-600">SUB™</span> — 12 points. Zéro complexité. 100% brodable.
          </p>
          <Button variant="outline" onClick={onClose}>
            Fermer
          </Button>
        </div>
      </div>
    </div>
  );
}