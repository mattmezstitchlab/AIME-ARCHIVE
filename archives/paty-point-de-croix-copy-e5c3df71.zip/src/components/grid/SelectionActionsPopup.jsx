import React, { useMemo, useState } from 'react';
import { X, Trash2, Highlighter, Eye, EyeOff, Hash, Paintbrush, Sparkles, Square, Check } from 'lucide-react';
import { toast } from 'sonner';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';

export default function SelectionActionsPopup({
  selectedCells = [],
  pattern,
  selectedColorId,
  onClose,
  onEraseSelection,
  onHighlightSelection,
  onInverseHighlight,
  onAutoCount,
  onFillExact,
  onSmartFix,
  onMaskRest,
  onDeselect,
}) {
  const [lastAction, setLastAction] = useState(null);

  // Calculer les stats de la sélection
  const selectionStats = useMemo(() => {
    if (!pattern || selectedCells.length === 0) return null;

    const offsetCol = pattern.offsetCol || 0;
    const offsetRow = pattern.offsetRow || 0;
    const colorCounts = {};
    let emptyCount = 0;

    selectedCells.forEach(({ col, row }) => {
      const localCol = col - offsetCol;
      const localRow = row - offsetRow;
      const cell = pattern.symbolGrid?.[localRow]?.[localCol];
      if (cell?.colorId) {
        colorCounts[cell.colorId] = (colorCounts[cell.colorId] || 0) + 1;
      } else {
        emptyCount++;
      }
    });

    // Trouver la couleur dominante
    let dominantColorId = null;
    let maxCount = 0;
    Object.entries(colorCounts).forEach(([colorId, count]) => {
      if (count > maxCount) {
        maxCount = count;
        dominantColorId = colorId;
      }
    });

    const dominantColor = pattern.colorPalette?.find(c => c.id === dominantColorId);
    const filledPoints = Object.values(colorCounts).reduce((a, b) => a + b, 0);

    return {
      totalPoints: selectedCells.length,
      filledPoints,
      emptyPoints: emptyCount,
      dominantColor,
      dominantCount: maxCount,
      colorCounts,
    };
  }, [selectedCells, pattern]);

  if (selectedCells.length === 0) return null;

  // Exécuter une action sans fermer le panneau
  const handleAction = (actionName, callback) => {
    if (callback) {
      callback();
      setLastAction(actionName);
      // Effacer l'indicateur après 2 secondes
      setTimeout(() => setLastAction(null), 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center pointer-events-none">
      {/* Fond cliquable pour fermer */}
      <div 
        className="absolute inset-0 pointer-events-auto"
        onClick={onClose}
      />

      {/* Popup centré */}
      <div 
        className="relative bg-[#1a1a1a] rounded-2xl shadow-2xl border border-[#333] overflow-hidden pointer-events-auto"
        style={{ width: '320px', maxWidth: '90vw' }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-[#333] bg-gradient-to-r from-[#FFC94A]/10 to-transparent">
          <div className="flex items-center gap-2">
            <Square className="w-4 h-4 text-[#FFC94A]" />
            <span className="text-white font-semibold">
              Sélection ({selectedCells.length} cases)
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 hover:bg-white/10 rounded-lg transition-colors"
          >
            <X className="w-4 h-4 text-gray-400" />
          </button>
        </div>

        {/* Actions */}
        <TooltipProvider delayDuration={300}>
        <div className="p-3 space-y-1.5">
          {/* Effacer la sélection */}
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                onClick={() => handleAction('Effacer', onEraseSelection)}
                className="w-full px-4 py-2.5 rounded-xl flex items-center gap-3 transition-all bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20"
              >
                <Trash2 className="w-4 h-4" />
                <span className="text-sm font-medium flex-1 text-left">Effacer la sélection</span>
                {lastAction === 'Effacer' && <Check className="w-4 h-4 text-green-400" />}
              </button>
            </TooltipTrigger>
            <TooltipContent side="left"><p>Supprimer le contenu des cases sélectionnées</p></TooltipContent>
          </Tooltip>

          {/* Surligner la sélection */}
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                onClick={() => handleAction('Surligner', onHighlightSelection)}
                className="w-full px-4 py-2.5 rounded-xl flex items-center gap-3 transition-all bg-white/5 hover:bg-white/10 text-white"
              >
                <Highlighter className="w-4 h-4 text-yellow-400" />
                <span className="text-sm font-medium flex-1 text-left">Surligner la sélection</span>
                {lastAction === 'Surligner' && <Check className="w-4 h-4 text-green-400" />}
              </button>
            </TooltipTrigger>
            <TooltipContent side="left"><p>Mettre la sélection en avant, diminuer le reste</p></TooltipContent>
          </Tooltip>

          {/* Surlignage inversé */}
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                onClick={() => handleAction('Inversé', onInverseHighlight)}
                className="w-full px-4 py-2.5 rounded-xl flex items-center gap-3 transition-all bg-white/5 hover:bg-white/10 text-white"
              >
                <Eye className="w-4 h-4 text-blue-400" />
                <span className="text-sm font-medium flex-1 text-left">Surlignage inversé</span>
                {lastAction === 'Inversé' && <Check className="w-4 h-4 text-green-400" />}
              </button>
            </TooltipTrigger>
            <TooltipContent side="left"><p>Assombrir la sélection, mettre en avant le reste</p></TooltipContent>
          </Tooltip>

          {/* Auto-Count™ */}
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                onClick={() => handleAction('Auto-Count', onAutoCount)}
                className="w-full px-4 py-2.5 rounded-xl flex items-center gap-3 transition-all bg-white/5 hover:bg-white/10 text-white"
              >
                <Hash className="w-4 h-4 text-purple-400" />
                <span className="text-sm font-medium flex-1 text-left">Auto-Count™</span>
                {selectionStats?.dominantColor && (
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-gray-400">
                      {selectionStats.filledPoints} pts
                    </span>
                    <div 
                      className="w-4 h-4 rounded border border-white/20"
                      style={{ backgroundColor: selectionStats.dominantColor.hex || selectionStats.dominantColor.dmcHex }}
                    />
                  </div>
                )}
                {lastAction === 'Auto-Count' && <Check className="w-4 h-4 text-green-400" />}
              </button>
            </TooltipTrigger>
            <TooltipContent side="left"><p>Compter les points et couleurs de cette zone</p></TooltipContent>
          </Tooltip>

          {/* Fill Exact™ */}
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                onClick={() => handleAction('Fill', onFillExact)}
                disabled={!selectedColorId}
                className={`w-full px-4 py-2.5 rounded-xl flex items-center gap-3 transition-all ${
                  selectedColorId 
                    ? 'bg-white/5 hover:bg-white/10 text-white' 
                    : 'bg-white/5 text-gray-500 cursor-not-allowed opacity-50'
                }`}
              >
                <Paintbrush className="w-4 h-4 text-green-400" />
                <span className="text-sm font-medium flex-1 text-left">Fill Exact™</span>
                {selectedColorId ? (
                  <span className="text-xs text-gray-500">(couleur active)</span>
                ) : (
                  <span className="text-xs text-gray-600">(choisir couleur)</span>
                )}
                {lastAction === 'Fill' && <Check className="w-4 h-4 text-green-400" />}
              </button>
            </TooltipTrigger>
            <TooltipContent side="left"><p>Remplir la sélection avec la couleur active</p></TooltipContent>
          </Tooltip>

          {/* Smart-Fix™ */}
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                onClick={() => handleAction('Smart-Fix', onSmartFix)}
                className="w-full px-4 py-2.5 rounded-xl flex items-center gap-3 transition-all bg-gradient-to-r from-[#FFC94A]/10 to-transparent hover:from-[#FFC94A]/20 text-white border border-[#FFC94A]/20"
              >
                <Sparkles className="w-4 h-4 text-[#FFC94A]" />
                <span className="text-sm font-medium flex-1 text-left">Smart-Fix™</span>
                <span className="text-[10px] px-1.5 py-0.5 bg-[#FFC94A]/20 text-[#FFC94A] rounded">IA</span>
                {lastAction === 'Smart-Fix' && <Check className="w-4 h-4 text-green-400 ml-1" />}
              </button>
            </TooltipTrigger>
            <TooltipContent side="left"><p>Corriger automatiquement erreurs et incohérences</p></TooltipContent>
          </Tooltip>

          {/* Masquer le reste */}
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                onClick={() => handleAction('Masquer', onMaskRest)}
                className="w-full px-4 py-2.5 rounded-xl flex items-center gap-3 transition-all bg-white/5 hover:bg-white/10 text-white"
              >
                <EyeOff className="w-4 h-4 text-gray-400" />
                <span className="text-sm font-medium flex-1 text-left">Masquer le reste</span>
                {lastAction === 'Masquer' && <Check className="w-4 h-4 text-green-400" />}
              </button>
            </TooltipTrigger>
            <TooltipContent side="left"><p>Afficher uniquement la sélection, cacher le reste</p></TooltipContent>
          </Tooltip>

          {/* Séparateur */}
          <div className="border-t border-[#333] my-2" />

          {/* Désélectionner */}
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                onClick={onDeselect}
                className="w-full px-4 py-2.5 rounded-xl flex items-center gap-3 transition-all bg-gray-600/20 hover:bg-gray-600/30 text-gray-300 border border-gray-600/30"
              >
                <X className="w-4 h-4" />
                <span className="text-sm font-medium flex-1 text-left">Désélectionner</span>
              </button>
            </TooltipTrigger>
            <TooltipContent side="left"><p>Annuler la sélection actuelle</p></TooltipContent>
          </Tooltip>
        </div>
        </TooltipProvider>

        {/* Footer avec stats */}
        {selectionStats && (
          <div className="px-4 py-2 border-t border-[#333] bg-black/30">
            <div className="flex items-center justify-between text-xs text-gray-500">
              <span>{selectionStats.filledPoints} remplis • {selectionStats.emptyPoints} vides</span>
              {selectionStats.dominantColor && (
                <span className="flex items-center gap-1">
                  Dominant: 
                  <span style={{ color: selectionStats.dominantColor.hex || selectionStats.dominantColor.dmcHex }}>
                    {selectionStats.dominantColor.code || selectionStats.dominantColor.name}
                  </span>
                </span>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}