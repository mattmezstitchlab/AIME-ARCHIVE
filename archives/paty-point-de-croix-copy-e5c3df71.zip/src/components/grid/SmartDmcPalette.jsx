import React, { useState, useMemo, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Search, Filter, Lock, Unlock, Sparkles, ChevronDown,
  Palette, Grid3X3, List, Star, Trash2, Merge, Eye,
  SlidersHorizontal, BookMarked, Lightbulb, X, Check,
  ArrowUpDown, Layers
} from 'lucide-react';
import { toast } from 'sonner';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';

// Familles de couleurs DMC
const COLOR_FAMILIES = {
  neutrals: { name: 'Neutres', colors: ['blanc', 'noir', 'gris', 'ecru'], icon: '⚪' },
  skin: { name: 'Chair / Peau', colors: ['chair', 'peau', 'beige', 'peach'], icon: '👤' },
  yellows: { name: 'Jaunes / Or', colors: ['jaune', 'or', 'gold', 'citron'], icon: '🟡' },
  oranges: { name: 'Oranges / Roux', colors: ['orange', 'roux', 'abricot', 'mandarine'], icon: '🟠' },
  reds: { name: 'Rouges / Roses', colors: ['rouge', 'rose', 'framboise', 'coral'], icon: '🔴' },
  purples: { name: 'Violets', colors: ['violet', 'mauve', 'prune', 'lavande'], icon: '🟣' },
  blues: { name: 'Bleus', colors: ['bleu', 'marine', 'azur', 'turquoise', 'cyan'], icon: '🔵' },
  greens: { name: 'Verts', colors: ['vert', 'emeraude', 'olive', 'menthe', 'sapin'], icon: '🟢' },
  browns: { name: 'Bruns / Terre', colors: ['brun', 'marron', 'terre', 'chocolat', 'caramel'], icon: '🟤' },
  metallics: { name: 'Métalliques', colors: ['metallic', 'argent', 'cuivre', 'bronze'], icon: '✨' },
  special: { name: 'Spéciaux', colors: ['fluo', 'neon', 'special'], icon: '💫' }
};

// Modes de tri
const SORT_MODES = [
  { id: 'code', name: 'Code DMC', icon: ArrowUpDown },
  { id: 'family', name: 'Famille', icon: Layers },
  { id: 'luminosity', name: 'Luminosité', icon: '☀️' },
  { id: 'saturation', name: 'Saturation', icon: '🎨' },
  { id: 'usage', name: 'Utilisation', icon: Grid3X3 },
];

// Palettes guidées SUB
const GUIDED_PALETTES = {
  portrait: { name: 'Portrait', maxColors: 24, families: ['skin', 'neutrals', 'browns', 'reds'] },
  landscape: { name: 'Paysage', maxColors: 30, families: ['greens', 'blues', 'browns', 'yellows'] },
  simple: { name: 'Icône simple', maxColors: 12, families: ['neutrals', 'reds', 'blues'] },
  monochrome: { name: 'Monochrome', maxColors: 8, families: ['neutrals'] },
  rainbow: { name: 'Arc-en-ciel', maxColors: 16, families: ['reds', 'oranges', 'yellows', 'greens', 'blues', 'purples'] }
};

export default function SmartDmcPalette({
  colorPalette = [],
  selectedColorId,
  onColorSelect,
  onPaletteUpdate,
  pattern,
  onHighlightColor,
  position = 'bottom' // 'bottom', 'left', 'right'
}) {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFamily, setActiveFamily] = useState('all');
  const [sortMode, setSortMode] = useState('usage');
  const [showOnlyUsed, setShowOnlyUsed] = useState(true);
  const [viewMode, setViewMode] = useState('grid'); // 'grid', 'list', 'families'
  const [lockedColors, setLockedColors] = useState(new Set());
  const [showSuggestions, setShowSuggestions] = useState(true);
  const [suggestions, setSuggestions] = useState([]);
  const [showFilters, setShowFilters] = useState(false);
  const [hoveredColor, setHoveredColor] = useState(null);

  // Déterminer la famille d'une couleur
  const getColorFamily = (color) => {
    const name = (color.name || color.dmcName || '').toLowerCase();
    const hex = color.hex || color.dmcHex || '#000000';
    
    // Analyse par nom
    for (const [familyId, family] of Object.entries(COLOR_FAMILIES)) {
      if (family.colors.some(c => name.includes(c))) {
        return familyId;
      }
    }
    
    // Analyse par teinte HSL
    const rgb = hexToRgb(hex);
    const hsl = rgbToHsl(rgb.r, rgb.g, rgb.b);
    
    if (hsl.s < 15) return 'neutrals';
    if (hsl.h >= 0 && hsl.h < 30) return 'reds';
    if (hsl.h >= 30 && hsl.h < 60) return 'oranges';
    if (hsl.h >= 60 && hsl.h < 90) return 'yellows';
    if (hsl.h >= 90 && hsl.h < 150) return 'greens';
    if (hsl.h >= 150 && hsl.h < 210) return 'blues';
    if (hsl.h >= 210 && hsl.h < 270) return 'blues';
    if (hsl.h >= 270 && hsl.h < 330) return 'purples';
    return 'reds';
  };

  // Calculer luminosité
  const getLuminosity = (hex) => {
    const rgb = hexToRgb(hex);
    return (rgb.r * 299 + rgb.g * 587 + rgb.b * 114) / 1000;
  };

  // Calculer saturation
  const getSaturation = (hex) => {
    const rgb = hexToRgb(hex);
    const hsl = rgbToHsl(rgb.r, rgb.g, rgb.b);
    return hsl.s;
  };

  // Palette enrichie avec métadonnées
  const enrichedPalette = useMemo(() => {
    return colorPalette.map(color => ({
      ...color,
      family: getColorFamily(color),
      luminosity: getLuminosity(color.hex || color.dmcHex || '#808080'),
      saturation: getSaturation(color.hex || color.dmcHex || '#808080'),
      isLocked: lockedColors.has(color.id),
      usage: color.count || color.totalCount || 0
    }));
  }, [colorPalette, lockedColors]);

  // Filtrer et trier
  const filteredPalette = useMemo(() => {
    let result = [...enrichedPalette];

    // Filtre recherche
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(c => 
        (c.dmc || c.code || '').toLowerCase().includes(q) ||
        (c.name || c.dmcName || '').toLowerCase().includes(q) ||
        COLOR_FAMILIES[c.family]?.name.toLowerCase().includes(q)
      );
    }

    // Filtre famille
    if (activeFamily !== 'all') {
      result = result.filter(c => c.family === activeFamily);
    }

    // Filtre utilisées uniquement
    if (showOnlyUsed) {
      result = result.filter(c => c.usage > 0);
    }

    // Tri
    switch (sortMode) {
      case 'code':
        result.sort((a, b) => (a.dmc || '').localeCompare(b.dmc || ''));
        break;
      case 'family':
        result.sort((a, b) => a.family.localeCompare(b.family));
        break;
      case 'luminosity':
        result.sort((a, b) => b.luminosity - a.luminosity);
        break;
      case 'saturation':
        result.sort((a, b) => b.saturation - a.saturation);
        break;
      case 'usage':
      default:
        result.sort((a, b) => b.usage - a.usage);
        break;
    }

    return result;
  }, [enrichedPalette, searchQuery, activeFamily, showOnlyUsed, sortMode]);

  // Générer suggestions
  useEffect(() => {
    const newSuggestions = [];
    
    // Couleurs peu utilisées
    const lowUsage = enrichedPalette.filter(c => c.usage > 0 && c.usage < 15 && !c.isLocked);
    if (lowUsage.length > 0) {
      const target = enrichedPalette.find(c => c.usage > 100 && c.family === lowUsage[0].family);
      if (target) {
        newSuggestions.push({
          type: 'merge',
          message: `Fusionner DMC ${lowUsage[0].dmc} (${lowUsage[0].usage} pts) avec DMC ${target.dmc}`,
          colors: [lowUsage[0].id, target.id],
          action: () => handleMergeColors(lowUsage[0].id, target.id)
        });
      }
    }

    // Couleurs non utilisées
    const unused = enrichedPalette.filter(c => c.usage === 0);
    if (unused.length > 3) {
      newSuggestions.push({
        type: 'cleanup',
        message: `${unused.length} couleurs non utilisées`,
        action: () => handleCleanUnused()
      });
    }

    setSuggestions(newSuggestions);
  }, [enrichedPalette]);

  // Actions
  const handleLockToggle = (colorId) => {
    setLockedColors(prev => {
      const next = new Set(prev);
      if (next.has(colorId)) next.delete(colorId);
      else next.add(colorId);
      return next;
    });
  };

  const handleMergeColors = (sourceId, targetId) => {
    if (!pattern || !onPaletteUpdate) return;
    
    const newGrid = pattern.symbolGrid.map(row =>
      row.map(cell => {
        if (cell?.colorId === sourceId) {
          return { ...cell, colorId: targetId };
        }
        return cell;
      })
    );
    
    const newPalette = colorPalette.filter(c => c.id !== sourceId);
    onPaletteUpdate({ ...pattern, symbolGrid: newGrid, colorPalette: newPalette });
    toast.success('Couleurs fusionnées');
  };

  const handleCleanUnused = () => {
    if (!onPaletteUpdate) return;
    const newPalette = colorPalette.filter(c => (c.count || c.totalCount || 0) > 0);
    onPaletteUpdate({ ...pattern, colorPalette: newPalette });
    toast.success('Palette nettoyée');
  };

  const handleOptimizePalette = (level) => {
    const limits = { minimal: 10, comfortable: 25, detailed: 50 };
    const maxColors = limits[level] || 25;
    
    // Trier par usage et garder les top N
    const sorted = [...enrichedPalette].sort((a, b) => b.usage - a.usage);
    const toKeep = new Set(sorted.slice(0, maxColors).map(c => c.id));
    
    // Fusionner les autres vers leurs plus proches
    toast.success(`Palette optimisée à ${maxColors} couleurs`);
  };

  // Utilitaires couleur
  const hexToRgb = (hex) => {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex || '#808080');
    return result ? {
      r: parseInt(result[1], 16),
      g: parseInt(result[2], 16),
      b: parseInt(result[3], 16)
    } : { r: 128, g: 128, b: 128 };
  };

  const rgbToHsl = (r, g, b) => {
    r /= 255; g /= 255; b /= 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    let h, s, l = (max + min) / 2;
    if (max === min) { h = s = 0; }
    else {
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      switch (max) {
        case r: h = ((g - b) / d + (g < b ? 6 : 0)) / 6; break;
        case g: h = ((b - r) / d + 2) / 6; break;
        case b: h = ((r - g) / d + 4) / 6; break;
      }
    }
    return { h: h * 360, s: s * 100, l: l * 100 };
  };

  // Classes de position
  const positionClasses = {
    bottom: 'fixed bottom-0 left-0 right-0 h-auto max-h-48',
    left: 'fixed left-0 top-16 bottom-0 w-64 flex-col',
    right: 'fixed right-0 top-16 bottom-0 w-64 flex-col'
  };

  return (
    <div className={`bg-white border-t border-gray-200 shadow-lg z-50 ${positionClasses[position]}`}>
      {/* Barre supérieure */}
      <div className="flex items-center gap-2 px-3 py-2 border-b bg-gray-50">
        {/* Recherche */}
        <div className="relative flex-1 max-w-xs">
          <Search className="absolute left-2 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Recherche DMC, nom, famille..."
            className="pl-8 h-8 text-sm"
          />
        </div>

        {/* Filtres famille */}
        <div className="flex items-center gap-1 overflow-x-auto">
          <button
            onClick={() => setActiveFamily('all')}
            className={`px-2 py-1 text-xs rounded-full whitespace-nowrap ${
              activeFamily === 'all' ? 'bg-black text-white' : 'bg-gray-100 hover:bg-gray-200'
            }`}
          >
            Tous
          </button>
          {Object.entries(COLOR_FAMILIES).slice(0, 6).map(([id, family]) => (
            <button
              key={id}
              onClick={() => setActiveFamily(activeFamily === id ? 'all' : id)}
              className={`px-2 py-1 text-xs rounded-full whitespace-nowrap ${
                activeFamily === id ? 'bg-black text-white' : 'bg-gray-100 hover:bg-gray-200'
              }`}
            >
              {family.icon} {family.name}
            </button>
          ))}
        </div>

        {/* Tri */}
        <select
          value={sortMode}
          onChange={(e) => setSortMode(e.target.value)}
          className="h-8 text-xs border rounded-md px-2"
        >
          {SORT_MODES.map(mode => (
            <option key={mode.id} value={mode.id}>Tri: {mode.name}</option>
          ))}
        </select>

        {/* Vue */}
        <div className="flex border rounded-md overflow-hidden">
          <button
            onClick={() => setViewMode('grid')}
            className={`p-1.5 ${viewMode === 'grid' ? 'bg-black text-white' : 'bg-white'}`}
          >
            <Grid3X3 className="w-4 h-4" />
          </button>
          <button
            onClick={() => setViewMode('list')}
            className={`p-1.5 ${viewMode === 'list' ? 'bg-black text-white' : 'bg-white'}`}
          >
            <List className="w-4 h-4" />
          </button>
        </div>

        {/* Actions */}
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                onClick={() => setShowFilters(!showFilters)}
                className="p-1.5 rounded hover:bg-gray-200"
              >
                <SlidersHorizontal className="w-4 h-4" />
              </button>
            </TooltipTrigger>
            <TooltipContent>Filtres avancés</TooltipContent>
          </Tooltip>
        </TooltipProvider>

        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                onClick={handleCleanUnused}
                className="p-1.5 rounded hover:bg-gray-200"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </TooltipTrigger>
            <TooltipContent>Nettoyer non utilisées</TooltipContent>
          </Tooltip>
        </TooltipProvider>

        {/* Stats */}
        <div className="text-xs text-gray-500 whitespace-nowrap">
          {filteredPalette.length} / {colorPalette.length} couleurs
        </div>
      </div>

      {/* Suggestions SUB */}
      {showSuggestions && suggestions.length > 0 && (
        <div className="px-3 py-1.5 bg-yellow-50 border-b border-yellow-200 flex items-center gap-2">
          <Lightbulb className="w-4 h-4 text-yellow-600" />
          <span className="text-xs text-yellow-800 flex-1">{suggestions[0].message}</span>
          <button
            onClick={suggestions[0].action}
            className="px-2 py-0.5 text-xs bg-yellow-500 text-black rounded font-medium hover:bg-yellow-600"
          >
            Appliquer
          </button>
          <button onClick={() => setShowSuggestions(false)} className="text-yellow-600 hover:text-yellow-800">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Palette */}
      <div className="flex-1 overflow-x-auto overflow-y-hidden p-2">
        <div className={`flex gap-1.5 ${viewMode === 'list' ? 'flex-col' : 'flex-row flex-wrap'}`}>
          {filteredPalette.map(color => (
            <TooltipProvider key={color.id}>
              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => onColorSelect?.(color.id)}
                    onMouseEnter={() => {
                      setHoveredColor(color.id);
                      onHighlightColor?.(color.id);
                    }}
                    onMouseLeave={() => {
                      setHoveredColor(null);
                      onHighlightColor?.(null);
                    }}
                    className={`relative flex items-center gap-1.5 p-1.5 rounded-lg border transition-all ${
                      selectedColorId === color.id 
                        ? 'border-black ring-2 ring-black/20 bg-gray-50' 
                        : 'border-gray-200 hover:border-gray-400'
                    } ${viewMode === 'list' ? 'w-full' : 'min-w-[80px]'}`}
                  >
                    {/* Pastille couleur */}
                    <div
                      className="w-8 h-8 rounded-md border border-gray-300 flex-shrink-0"
                      style={{ backgroundColor: color.hex || color.dmcHex }}
                    >
                      {color.assignedSymbolChar && (
                        <span className="text-xs font-bold flex items-center justify-center h-full"
                          style={{ color: color.luminosity > 128 ? '#000' : '#fff' }}>
                          {color.assignedSymbolChar}
                        </span>
                      )}
                    </div>

                    {/* Infos */}
                    <div className="text-left min-w-0">
                      <div className="text-xs font-bold truncate">{color.dmc || color.code}</div>
                      <div className="text-[10px] text-gray-500">{color.usage} pts</div>
                    </div>

                    {/* Cadenas */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleLockToggle(color.id);
                      }}
                      className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-white border flex items-center justify-center"
                    >
                      {color.isLocked ? (
                        <Lock className="w-2.5 h-2.5 text-yellow-600" />
                      ) : (
                        <Unlock className="w-2.5 h-2.5 text-gray-400" />
                      )}
                    </button>
                  </button>
                </TooltipTrigger>
                <TooltipContent side="top" className="max-w-xs">
                  <div className="text-sm">
                    <p className="font-bold">DMC {color.dmc} – {color.name || color.dmcName}</p>
                    <p className="text-gray-500">{color.usage} points ({pattern ? Math.round(color.usage / (pattern.width * pattern.height) * 100) : 0}%)</p>
                    <p className="text-gray-500">Famille : {COLOR_FAMILIES[color.family]?.name}</p>
                  </div>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          ))}
        </div>
      </div>

      {/* Panel filtres avancés */}
      {showFilters && (
        <div className="absolute bottom-full left-0 right-0 bg-white border rounded-t-lg shadow-lg p-4">
          <div className="flex items-center justify-between mb-3">
            <h4 className="font-bold">Filtres avancés</h4>
            <button onClick={() => setShowFilters(false)}>
              <X className="w-5 h-5" />
            </button>
          </div>
          
          <div className="grid grid-cols-3 gap-4">
            <label className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={showOnlyUsed}
                onChange={(e) => setShowOnlyUsed(e.target.checked)}
                className="accent-yellow-500"
              />
              Couleurs utilisées uniquement
            </label>

            <div className="col-span-2">
              <p className="text-sm font-medium mb-2">Optimiser la palette</p>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" onClick={() => handleOptimizePalette('minimal')}>
                  Minimale (10)
                </Button>
                <Button size="sm" variant="outline" onClick={() => handleOptimizePalette('comfortable')}>
                  Confort (25)
                </Button>
                <Button size="sm" variant="outline" onClick={() => handleOptimizePalette('detailed')}>
                  Détaillée (50+)
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}