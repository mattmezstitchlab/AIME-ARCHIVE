import React, { useRef, useEffect, useCallback, useState } from 'react';
import { ZoomIn, ZoomOut, Maximize2, Navigation } from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';

// Convertir un numéro de ligne en lettre (0 = A, 25 = Z, 26 = AA, etc.)
const rowToLetter = (row) => {
  let result = '';
  let n = row;
  while (n >= 0) {
    result = String.fromCharCode(65 + (n % 26)) + result;
    n = Math.floor(n / 26) - 1;
  }
  return result;
};

// Niveaux de zoom prédéfinis
const ZOOM_LEVELS = [
  { label: '25%', value: 0.25 },
  { label: '50%', value: 0.5 },
  { label: '100%', value: 1 },
  { label: '150%', value: 1.5 },
  { label: '200%', value: 2 },
];

export default function FloatingMiniMapZoom({
  pattern,
  gridConfig,
  canvasSize,
  currentZoom,
  onZoomChange,
  onNavigate,
  onCenterView,
}) {
  const canvasRef = useRef(null);
  const [currentZone, setCurrentZone] = useState(null);
  const [hoveredBlock, setHoveredBlock] = useState(null);
  const [isDragging, setIsDragging] = useState(false);

  // Dimensions de la mini-carte
  const MAP_WIDTH = 140;
  const MAP_HEIGHT = 90;

  // Calculer les paramètres de scale
  const getScaleParams = useCallback(() => {
    if (!pattern) return null;

    const patternWidth = pattern.width || pattern.symbolGrid?.[0]?.length || 1;
    const patternHeight = pattern.height || pattern.symbolGrid?.length || 1;

    const scaleX = MAP_WIDTH / patternWidth;
    const scaleY = MAP_HEIGHT / patternHeight;
    const scale = Math.min(scaleX, scaleY) * 0.9;

    const offsetX = (MAP_WIDTH - patternWidth * scale) / 2;
    const offsetY = (MAP_HEIGHT - patternHeight * scale) / 2;

    return { patternWidth, patternHeight, scale, offsetX, offsetY };
  }, [pattern, MAP_WIDTH, MAP_HEIGHT]);

  // Dessiner la mini-carte
  const drawMiniMap = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas || !pattern) return;

    const ctx = canvas.getContext('2d');
    canvas.width = MAP_WIDTH;
    canvas.height = MAP_HEIGHT;

    // Fond
    ctx.fillStyle = '#1a1a1a';
    ctx.fillRect(0, 0, MAP_WIDTH, MAP_HEIGHT);

    if (!pattern.symbolGrid?.length) return;

    const params = getScaleParams();
    if (!params) return;

    const { patternWidth, patternHeight, scale, offsetX, offsetY } = params;

    // Dessiner le motif
    const step = Math.max(1, Math.floor(1 / scale));
    for (let row = 0; row < patternHeight; row += step) {
      for (let col = 0; col < patternWidth; col += step) {
        const cell = pattern.symbolGrid[row]?.[col];
        if (!cell) continue;

        const color = pattern.colorPalette?.find(c => c.id === cell.colorId);
        ctx.fillStyle = color?.hex || color?.dmcHex || '#666';
        ctx.fillRect(
          offsetX + col * scale,
          offsetY + row * scale,
          Math.max(1, scale * step),
          Math.max(1, scale * step)
        );
      }
    }

    // Dessiner le quadrillage 10x10
    const blockSize = 10;
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
    ctx.lineWidth = 0.5;
    
    for (let col = blockSize; col < patternWidth; col += blockSize) {
      const x = offsetX + col * scale;
      ctx.beginPath();
      ctx.moveTo(x, offsetY);
      ctx.lineTo(x, offsetY + patternHeight * scale);
      ctx.stroke();
    }
    
    for (let row = blockSize; row < patternHeight; row += blockSize) {
      const y = offsetY + row * scale;
      ctx.beginPath();
      ctx.moveTo(offsetX, y);
      ctx.lineTo(offsetX + patternWidth * scale, y);
      ctx.stroke();
    }

    // Surligner le bloc survolé
    if (hoveredBlock) {
      const hx = offsetX + hoveredBlock.col * scale;
      const hy = offsetY + hoveredBlock.row * scale;
      const hw = Math.min(blockSize, patternWidth - hoveredBlock.col) * scale;
      const hh = Math.min(blockSize, patternHeight - hoveredBlock.row) * scale;
      
      ctx.fillStyle = 'rgba(59, 130, 246, 0.3)';
      ctx.fillRect(hx, hy, hw, hh);
      ctx.strokeStyle = '#3B82F6';
      ctx.lineWidth = 1.5;
      ctx.strokeRect(hx, hy, hw, hh);
    }

    // Rectangle de vue actuelle (viewport) - ROUGE
    if (gridConfig && canvasSize.width > 0) {
      const zoom = gridConfig.zoom || 1;
      const taille = gridConfig.taille_case || 25;
      const patternOffsetCol = pattern.offsetCol || 0;
      const patternOffsetRow = pattern.offsetRow || 0;

      const visibleStartX = (-gridConfig.offset_x / zoom / taille) - patternOffsetCol;
      const visibleStartY = (-gridConfig.offset_y / zoom / taille) - patternOffsetRow;
      const visibleWidth = canvasSize.width / zoom / taille;
      const visibleHeight = canvasSize.height / zoom / taille;

      const rectX = offsetX + Math.max(0, visibleStartX) * scale;
      const rectY = offsetY + Math.max(0, visibleStartY) * scale;
      const rectW = Math.min(patternWidth - Math.max(0, visibleStartX), visibleWidth) * scale;
      const rectH = Math.min(patternHeight - Math.max(0, visibleStartY), visibleHeight) * scale;

      // Calculer la zone GPS actuelle
      const centerCol = Math.floor(visibleStartX + visibleWidth / 2);
      const centerRow = Math.floor(visibleStartY + visibleHeight / 2);
      const zoneCol = Math.floor(centerCol / blockSize);
      const zoneRow = Math.floor(centerRow / blockSize);
      const zoneLetter = rowToLetter(zoneRow);
      const zoneNumber = zoneCol + 1;
      
      if (centerCol >= 0 && centerRow >= 0 && centerCol < patternWidth && centerRow < patternHeight) {
        setCurrentZone(`${zoneLetter}${zoneNumber}`);
      }

      // Rectangle rouge
      ctx.shadowColor = 'rgba(255,0,0,0.5)';
      ctx.shadowBlur = 4;
      ctx.strokeStyle = '#FF3333';
      ctx.lineWidth = 2;
      ctx.strokeRect(rectX, rectY, Math.max(4, rectW), Math.max(4, rectH));
      ctx.shadowBlur = 0;
    }
  }, [pattern, gridConfig, canvasSize, getScaleParams, hoveredBlock]);

  useEffect(() => {
    drawMiniMap();
  }, [drawMiniMap]);

  // Convertir coordonnées canvas en coordonnées grille
  const canvasToGrid = (clientX, clientY) => {
    if (!canvasRef.current || !pattern) return null;

    const rect = canvasRef.current.getBoundingClientRect();
    const clickX = clientX - rect.left;
    const clickY = clientY - rect.top;

    const params = getScaleParams();
    if (!params) return null;

    const { patternWidth, patternHeight, scale, offsetX, offsetY } = params;

    const gridCol = Math.floor((clickX - offsetX) / scale);
    const gridRow = Math.floor((clickY - offsetY) / scale);

    if (gridCol >= 0 && gridCol < patternWidth && gridRow >= 0 && gridRow < patternHeight) {
      return { col: gridCol, row: gridRow };
    }
    return null;
  };

  // Navigation au clic
  const handleClick = (e) => {
    const gridPos = canvasToGrid(e.clientX, e.clientY);
    if (!gridPos || !pattern || !gridConfig) return;

    const patternOffsetCol = pattern.offsetCol || 0;
    const patternOffsetRow = pattern.offsetRow || 0;
    const taille = gridConfig.taille_case || 25;
    const zoom = gridConfig.zoom || 1;

    const targetX = (gridPos.col + patternOffsetCol) * taille * zoom;
    const targetY = (gridPos.row + patternOffsetRow) * taille * zoom;

    onNavigate?.(targetX, targetY);
  };

  // Gestion du survol
  const handleMouseMove = (e) => {
    if (isDragging) {
      handleClick(e);
      return;
    }
    
    const gridPos = canvasToGrid(e.clientX, e.clientY);
    if (gridPos) {
      const blockSize = 10;
      const blockCol = Math.floor(gridPos.col / blockSize) * blockSize;
      const blockRow = Math.floor(gridPos.row / blockSize) * blockSize;
      setHoveredBlock({ col: blockCol, row: blockRow });
    } else {
      setHoveredBlock(null);
    }
  };

  const handleMouseDown = (e) => {
    setIsDragging(true);
    handleClick(e);
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleMouseLeave = () => {
    setHoveredBlock(null);
    setIsDragging(false);
  };

  // Trouver le niveau de zoom actuel
  const getCurrentZoomLabel = () => {
    const pct = Math.round((currentZoom || 1) * 100);
    return `${pct}%`;
  };

  if (!pattern) return null;

  return (
    <TooltipProvider>
      <div
        style={{
          position: 'absolute',
          bottom: '150px', // Au-dessus de la palette DMC (qui fait ~140px)
          left: '28px', // Aligné avec la règle alphabet
          display: 'flex',
          alignItems: 'stretch',
          backgroundColor: 'rgba(17, 17, 17, 0.95)',
          borderRadius: '10px',
          overflow: 'hidden',
          border: '1px solid rgba(255,255,255,0.15)',
          boxShadow: '0 4px 20px rgba(0,0,0,0.4)',
          zIndex: 50,
        }}
      >
        {/* Mini-carte */}
        <div style={{ position: 'relative' }}>
          <canvas
            ref={canvasRef}
            onClick={handleClick}
            onMouseDown={handleMouseDown}
            onMouseUp={handleMouseUp}
            onMouseMove={handleMouseMove}
            onMouseLeave={handleMouseLeave}
            style={{
              width: `${MAP_WIDTH}px`,
              height: `${MAP_HEIGHT}px`,
              cursor: isDragging ? 'grabbing' : 'crosshair',
              display: 'block',
            }}
          />
          {/* Indicateur zone actuelle */}
          <div
            style={{
              position: 'absolute',
              bottom: '4px',
              left: '4px',
              backgroundColor: 'rgba(0,0,0,0.7)',
              padding: '2px 5px',
              borderRadius: '4px',
              fontSize: '9px',
              color: '#FFC94A',
              fontWeight: 600,
              display: 'flex',
              alignItems: 'center',
              gap: '2px',
            }}
          >
            <Navigation style={{ width: '8px', height: '8px' }} />
            {currentZone || '-'}
          </div>
          {/* Dimensions */}
          <div
            style={{
              position: 'absolute',
              bottom: '4px',
              right: '4px',
              backgroundColor: 'rgba(0,0,0,0.7)',
              padding: '2px 5px',
              borderRadius: '4px',
              fontSize: '8px',
              color: '#888',
            }}
          >
            {pattern.width}×{pattern.height}
          </div>
        </div>

        {/* Colonne de zoom verticale */}
        <div
          style={{
            display: 'flex',
            flexDirection: 'column',
            padding: '6px',
            gap: '4px',
            borderLeft: '1px solid rgba(255,255,255,0.1)',
            justifyContent: 'space-between',
            width: '36px',
          }}
        >
          {/* Bouton + */}
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                onClick={() => onZoomChange?.(Math.min(5, (currentZoom || 1) * 1.25), true)}
                style={{
                  width: '24px',
                  height: '24px',
                  borderRadius: '5px',
                  backgroundColor: 'rgba(255,255,255,0.1)',
                  color: '#fff',
                  border: 'none',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <ZoomIn style={{ width: '14px', height: '14px' }} />
              </button>
            </TooltipTrigger>
            <TooltipContent side="right"><p>Zoom +</p></TooltipContent>
          </Tooltip>

          {/* Bouton - */}
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                onClick={() => onZoomChange?.(Math.max(0.1, (currentZoom || 1) / 1.25), true)}
                style={{
                  width: '24px',
                  height: '24px',
                  borderRadius: '5px',
                  backgroundColor: 'rgba(255,255,255,0.1)',
                  color: '#fff',
                  border: 'none',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <ZoomOut style={{ width: '14px', height: '14px' }} />
              </button>
            </TooltipTrigger>
            <TooltipContent side="right"><p>Zoom -</p></TooltipContent>
          </Tooltip>

          {/* Indicateur zoom actuel */}
          <div
            style={{
              textAlign: 'center',
              fontSize: '9px',
              fontWeight: 700,
              color: '#FFC94A',
            }}
          >
            {getCurrentZoomLabel()}
          </div>

          {/* Boutons presets */}
          {ZOOM_LEVELS.slice(1, 4).map((level) => (
            <button
              key={level.value}
              onClick={() => onZoomChange?.(level.value, true)}
              style={{
                padding: '2px',
                borderRadius: '4px',
                backgroundColor: Math.abs((currentZoom || 1) - level.value) < 0.05 
                  ? '#FFC94A' 
                  : 'rgba(255,255,255,0.05)',
                color: Math.abs((currentZoom || 1) - level.value) < 0.05 
                  ? '#111' 
                  : '#888',
                border: 'none',
                cursor: 'pointer',
                fontSize: '8px',
                fontWeight: 500,
              }}
            >
              {level.label}
            </button>
          ))}

          {/* Recentrer */}
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                onClick={onCenterView}
                style={{
                  width: '24px',
                  height: '24px',
                  borderRadius: '5px',
                  backgroundColor: 'rgba(255,255,255,0.1)',
                  color: '#fff',
                  border: 'none',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <Maximize2 style={{ width: '12px', height: '12px' }} />
              </button>
            </TooltipTrigger>
            <TooltipContent side="right"><p>Recentrer</p></TooltipContent>
          </Tooltip>
        </div>
      </div>
    </TooltipProvider>
  );
}