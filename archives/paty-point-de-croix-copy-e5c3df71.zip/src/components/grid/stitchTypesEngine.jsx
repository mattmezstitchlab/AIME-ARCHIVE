/**
 * Moteur IA - Types de Points pour PatyBee
 * Analyse l'image et applique intelligemment les types de points
 */

// ========== 1. ANALYSE DU VISUEL ==========

export function analyserImage(imageData, width, height) {
  const totalPixels = width * height;
  
  let contoursFortsCount = 0;
  let zonesDouces = 0;
  let pointsLumiere = 0;
  let zonesUniformes = 0;
  let couleursMetalliques = 0;
  let microDetails = 0;
  let lignesFines = 0;
  let petitesZonesBrillantes = 0;
  
  // Analyse pixel par pixel
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const idx = (y * width + x) * 4;
      const r = imageData[idx];
      const g = imageData[idx + 1];
      const b = imageData[idx + 2];
      const brightness = (r + g + b) / 3;
      
      // Détection contours (différence avec voisins)
      if (x < width - 1 && y < height - 1) {
        const nextIdx = ((y * width) + x + 1) * 4;
        const diffH = Math.abs(brightness - ((imageData[nextIdx] + imageData[nextIdx + 1] + imageData[nextIdx + 2]) / 3));
        
        const belowIdx = (((y + 1) * width) + x) * 4;
        const diffV = Math.abs(brightness - ((imageData[belowIdx] + imageData[belowIdx + 1] + imageData[belowIdx + 2]) / 3));
        
        if (diffH > 60 || diffV > 60) contoursFortsCount++;
        if (diffH < 20 && diffV < 20) zonesUniformes++;
        if (diffH > 80 || diffV > 80) microDetails++;
      }
      
      // Points de lumière (très lumineux)
      if (brightness > 240) pointsLumiere++;
      
      // Zones douces (contraste faible)
      if (brightness > 100 && brightness < 200) zonesDouces++;
      
      // Couleurs métalliques (or/argent)
      const isGold = r > 200 && g > 180 && b < 150;
      const isSilver = Math.abs(r - g) < 20 && Math.abs(g - b) < 20 && r > 180;
      if (isGold || isSilver) couleursMetalliques++;
      
      // Petites zones brillantes (pour satin)
      if (brightness > 220 && brightness < 245) petitesZonesBrillantes++;
    }
  }
  
  return {
    pourcentageContoursFort: (contoursFortsCount / totalPixels) * 100,
    pourcentageZonesFaibleContraste: (zonesDouces / totalPixels) * 100,
    pourcentagePointsLumiere: (pointsLumiere / totalPixels) * 100,
    pourcentageZonesUniformes: (zonesUniformes / totalPixels) * 100,
    pourcentageCouleursMetalliques: (couleursMetalliques / totalPixels) * 100,
    pourcentageMicroDetails: (microDetails / totalPixels) * 100,
    nombreLignesFines: lignesFines,
    nombrePetitesZonesBrillantes: petitesZonesBrillantes,
    nombreFilamentsLongs: 0, // À implémenter
    nombreLignesLonguesContinue: 0 // À implémenter
  };
}

// ========== 2. CARTOGRAPHIE DES ZONES ==========

export function construireCartographie(pattern, imageAnalyse) {
  if (!pattern || !pattern.symbolGrid) return {};
  
  const cartographie = {};
  const width = pattern.width;
  const height = pattern.height;
  
  pattern.symbolGrid.forEach((row, y) => {
    row.forEach((cell, x) => {
      if (!cell) return;
      
      const id = `${x}-${y}`;
      
      // Analyser le contexte de cette case
      const brightness = getBrightness(cell);
      const hasStrongEdge = detectEdgeAt(pattern.symbolGrid, x, y);
      const isInUniformZone = detectUniformZone(pattern.symbolGrid, x, y);
      const isIsolatedBright = detectIsolatedBright(pattern.symbolGrid, x, y);
      
      cartographie[id] = {
        x,
        y,
        colorId: cell.colorId,
        zoneDouce: brightness > 100 && brightness < 200 && !hasStrongEdge,
        microDetail: hasStrongEdge && isSmallFeature(pattern.symbolGrid, x, y),
        estContourFort: hasStrongEdge,
        pointLumiereIsolé: brightness > 230 && isIsolatedBright,
        pointLumiereFort: brightness > 245,
        couleurMetallique: isMetallicColor(cell),
        appartientZoneUniformeLongue: isInUniformZone,
        appartientPetiteZoneBrillante: brightness > 220 && !isInUniformZone,
        appartientLigneContinue: detectContinuousLine(pattern.symbolGrid, x, y),
        appartientFilamentLong: detectFilament(pattern.symbolGrid, x, y),
        zoneTresDense: detectDenseZone(pattern.symbolGrid, x, y),
        estDetailImportant: hasStrongEdge && brightness > 200,
        zonePeuDense: !detectDenseZone(pattern.symbolGrid, x, y)
      };
    });
  });
  
  return cartographie;
}

// ========== 3. CALCUL DES SUGGESTIONS IA ==========

export function calculerSuggestionTypesDePoints(imageAnalyse, cartographie) {
  const result = {
    full: true, // Toujours activé
    half: imageAnalyse.pourcentageZonesFaibleContraste > 10,
    quarter: imageAnalyse.pourcentageMicroDetails > 8,
    threequarter: imageAnalyse.pourcentageMicroDetails > 8,
    backstitch: imageAnalyse.pourcentageContoursFort > 20,
    frenchknot: imageAnalyse.pourcentagePointsLumiere > 4,
    bead: imageAnalyse.pourcentagePointsLumiere > 6,
    metallic: imageAnalyse.pourcentageCouleursMetalliques > 3,
    longstitch: imageAnalyse.pourcentageZonesUniformes > 15,
    straightstitch: imageAnalyse.nombreLignesFines > 50,
    satin: imageAnalyse.nombrePetitesZonesBrillantes > 20,
    bullion: imageAnalyse.nombreFilamentsLongs > 10,
    couching: imageAnalyse.nombreLignesLonguesContinue > 5,
    IA_mix: false
  };
  
  return result;
}

// ========== 4. APPLICATION DES TYPES À LA GRILLE ==========

export function appliquerTypesDePoints(pattern, selectionUtilisateur, cartographie) {
  if (!pattern || !pattern.symbolGrid) return pattern;
  if (!selectionUtilisateur) selectionUtilisateur = { croix: true };
  
  const newPattern = { ...pattern };
  const backstitch = [];
  
  // Attribution d'un type à chaque case
  newPattern.symbolGrid = pattern.symbolGrid.map((row, y) =>
    row.map((cell, x) => {
      if (!cell) return cell;
      
      const id = `${x}-${y}`;
      const analyseCase = cartographie[id] || {};
      
      let type = 'full'; // Par défaut
      
      // Appliquer les règles selon la sélection utilisateur
      if (selectionUtilisateur.demi && analyseCase.zoneDouce) {
        type = 'half';
      }
      
      if (selectionUtilisateur.frac && analyseCase.microDetail) {
        type = 'quarter';
      }
      
      // Backstitch se superpose (calque séparé)
      if (selectionUtilisateur.back && analyseCase.estContourFort) {
        backstitch.push({ x, y, colorId: cell.colorId });
      }
      
      // Points spéciaux
      if (selectionUtilisateur.noeud && analyseCase.pointLumiereIsolé) {
        type = 'frenchknot';
      }
      
      if (selectionUtilisateur.perle && analyseCase.pointLumiereFort) {
        type = 'bead';
      }
      
      if (selectionUtilisateur.metal && analyseCase.couleurMetallique) {
        type = 'metallic';
      }
      
      if (selectionUtilisateur.long && analyseCase.appartientZoneUniformeLongue) {
        type = 'longstitch';
      }
      
      if (selectionUtilisateur.satin && analyseCase.appartientPetiteZoneBrillante) {
        type = 'satin';
      }
      
      if (selectionUtilisateur.couching && analyseCase.appartientLigneContinue) {
        type = 'couching';
      }
      
      if (selectionUtilisateur.bullion && analyseCase.appartientFilamentLong) {
        type = 'bullion';
      }
      
      // IA Mix : affinage automatique
      if (selectionUtilisateur.aiMixEnabled) {
        type = ajusterParIAMix(type, analyseCase, selectionUtilisateur);
      }
      
      return { ...cell, type };
    })
  );
  
  newPattern.backstitch = backstitch;
  
  return newPattern;
}

// ========== 5. IA MIX - AFFINAGE ==========

function ajusterParIAMix(typeActuel, analyseCase, selectionUtilisateur) {
  // Simplifier si zone très dense
  if (analyseCase.zoneTresDense) {
    if (['quarter', 'satin', 'bullion'].includes(typeActuel)) {
      return 'full';
    }
  }
  
  // Upgrader si détail important et zone peu dense
  if (analyseCase.estDetailImportant && analyseCase.zonePeuDense) {
    if (typeActuel === 'full' && selectionUtilisateur.half && analyseCase.zoneDouce) {
      return 'half';
    }
  }
  
  return typeActuel;
}

// ========== 6. STATISTIQUES PAR COULEUR ==========

export function mettreAJourStatsParCouleur(pattern) {
  if (!pattern || !pattern.colorPalette) return pattern;
  
  // Réinitialiser les stats
  const stats = {};
  pattern.colorPalette.forEach(color => {
    stats[color.id] = {
      total: 0,
      full: 0,
      half: 0,
      quarter: 0,
      backstitch: 0,
      frenchknot: 0,
      bead: 0,
      metallic: 0,
      longstitch: 0,
      straightstitch: 0,
      satin: 0,
      bullion: 0,
      couching: 0
    };
  });
  
  // Compter les types par couleur
  pattern.symbolGrid.flat().forEach(cell => {
    if (!cell) return;
    
    const colorStats = stats[cell.colorId];
    if (!colorStats) return;
    
    colorStats.total++;
    colorStats[cell.type] = (colorStats[cell.type] || 0) + 1;
  });
  
  // Backstitch
  if (pattern.backstitch) {
    pattern.backstitch.forEach(bs => {
      const colorStats = stats[bs.colorId];
      if (colorStats) {
        colorStats.backstitch++;
      }
    });
  }
  
  // Mettre à jour la palette avec les stats
  const newColorPalette = pattern.colorPalette.map(color => ({
    ...color,
    stitchTypeStats: stats[color.id]
  }));
  
  return { ...pattern, colorPalette: newColorPalette };
}

// ========== 7. PRÉPARATION DES CALQUES ==========

export function preparerCalquesTypesDePoints(pattern) {
  const calques = {
    full: [],
    half: [],
    quarter: [],
    backstitch: [],
    frenchknot: [],
    bead: [],
    metallic: [],
    longstitch: [],
    straightstitch: [],
    satin: [],
    bullion: [],
    couching: []
  };
  
  // Dispatcher les cases dans les calques
  pattern.symbolGrid.flat().forEach(cell => {
    if (!cell) return;
    
    const type = cell.type || 'full';
    if (calques[type]) {
      calques[type].push(cell);
    }
  });
  
  // Calque backstitch séparé
  if (pattern.backstitch) {
    calques.backstitch = pattern.backstitch;
  }
  
  return calques;
}

// ========== FONCTIONS UTILITAIRES ==========

function getBrightness(cell) {
  // Extraire luminosité depuis la couleur hex
  const hex = cell.color || '#808080';
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return (r + g + b) / 3;
}

function detectEdgeAt(grid, x, y) {
  if (!grid[y] || !grid[y][x]) return false;
  
  const current = grid[y][x];
  const neighbors = [
    grid[y]?.[x + 1],
    grid[y]?.[x - 1],
    grid[y + 1]?.[x],
    grid[y - 1]?.[x]
  ];
  
  return neighbors.some(n => n && n.colorId !== current.colorId);
}

function detectUniformZone(grid, x, y, radius = 2) {
  if (!grid[y] || !grid[y][x]) return false;
  
  const current = grid[y][x];
  let sameColorCount = 0;
  let totalChecked = 0;
  
  for (let dy = -radius; dy <= radius; dy++) {
    for (let dx = -radius; dx <= radius; dx++) {
      const cell = grid[y + dy]?.[x + dx];
      if (cell) {
        totalChecked++;
        if (cell.colorId === current.colorId) sameColorCount++;
      }
    }
  }
  
  return totalChecked > 0 && (sameColorCount / totalChecked) > 0.8;
}

function detectIsolatedBright(grid, x, y) {
  const neighbors = [
    grid[y]?.[x + 1],
    grid[y]?.[x - 1],
    grid[y + 1]?.[x],
    grid[y - 1]?.[x]
  ].filter(n => n);
  
  return neighbors.length < 4 || neighbors.every(n => getBrightness(n) < 200);
}

function isSmallFeature(grid, x, y) {
  let featureSize = 0;
  const visited = new Set();
  const queue = [[x, y]];
  
  while (queue.length > 0 && featureSize < 10) {
    const [cx, cy] = queue.shift();
    const key = `${cx}-${cy}`;
    
    if (visited.has(key)) continue;
    visited.add(key);
    featureSize++;
    
    // Ajouter voisins similaires
    [[0,1], [0,-1], [1,0], [-1,0]].forEach(([dx, dy]) => {
      const nx = cx + dx;
      const ny = cy + dy;
      if (grid[ny]?.[nx] && !visited.has(`${nx}-${ny}`)) {
        queue.push([nx, ny]);
      }
    });
  }
  
  return featureSize < 10;
}

function isMetallicColor(cell) {
  const hex = cell.color || '#808080';
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  
  const isGold = r > 200 && g > 180 && b < 150;
  const isSilver = Math.abs(r - g) < 20 && Math.abs(g - b) < 20 && r > 180;
  
  return isGold || isSilver;
}

function detectContinuousLine(grid, x, y) {
  // Détection ligne continue (horizontal ou vertical)
  let hCount = 0, vCount = 0;
  
  for (let i = -3; i <= 3; i++) {
    if (grid[y]?.[x + i]) hCount++;
    if (grid[y + i]?.[x]) vCount++;
  }
  
  return hCount >= 5 || vCount >= 5;
}

function detectFilament(grid, x, y) {
  // Détection filament (ligne fine et longue)
  return detectContinuousLine(grid, x, y) && !detectUniformZone(grid, x, y, 1);
}

function detectDenseZone(grid, x, y) {
  let cellCount = 0;
  
  for (let dy = -2; dy <= 2; dy++) {
    for (let dx = -2; dx <= 2; dx++) {
      if (grid[y + dy]?.[x + dx]) cellCount++;
    }
  }
  
  return cellCount > 20;
}