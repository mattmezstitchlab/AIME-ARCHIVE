import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { base44 } from '@/api/base44Client';
import { Upload, Image as ImageIcon, Loader2, Sparkles } from 'lucide-react';
import { toast } from 'sonner';
import { detectColors, generateSymbolGrid } from './ColorDetector';
import { SYMBOL_CATEGORIES } from './SymbolLibrary';

export default function ImportImageDialog({ 
  open, 
  onClose, 
  onImportComplete,
  onReferenceOnly,
  preloadedImage,
  preloadedFile
}) {
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState(preloadedImage || null);
  const [gridSize, setGridSize] = useState(150);
  const [maxColors, setMaxColors] = useState(40);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [preFilterColors, setPreFilterColors] = useState(false);
  const [printMode, setPrintMode] = useState(false);
  const [paletteProfile, setPaletteProfile] = useState('standard');

  // Charger le fichier pré-sélectionné
  useEffect(() => {
    if (preloadedFile && open) {
      setFile(preloadedFile);
      const reader = new FileReader();
      reader.onload = (e) => {
        setPreview(e.target.result);
      };
      reader.readAsDataURL(preloadedFile);
    }
  }, [preloadedFile, open]);

  useEffect(() => {
    if (preloadedImage) {
      setPreview(preloadedImage);
    }
  }, [preloadedImage]);

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      setFile(selectedFile);
      
      // Créer l'aperçu et calculer les proportions
      const reader = new FileReader();
      reader.onload = (e) => {
        setPreview(e.target.result);
        
        // Charger l'image pour obtenir ses dimensions
        const img = new Image();
        img.onload = () => {
          const aspectRatio = img.width / img.height;
          
          // Ajuster gridSize en fonction des proportions
          if (aspectRatio > 1) {
            // Image horizontale
            setGridSize(Math.round(100 * aspectRatio));
          } else {
            // Image verticale
            setGridSize(100);
          }
        };
        img.src = e.target.result;
      };
      reader.readAsDataURL(selectedFile);
    }
  };

  const handleImport = async () => {
    if (!file && !preloadedImage) {
      toast.error('Veuillez sélectionner une image');
      return;
    }

    setIsProcessing(true);

    try {
      // 1. Upload de l'image (ou utiliser l'image préchargée)
      let file_url;
      
      if (preloadedImage) {
        file_url = preloadedImage;
        toast.info('Utilisation du visuel de référence...');
      } else {
        toast.info('Upload de l\'image...');
        const uploadResponse = await base44.integrations.Core.UploadFile({ file });
        file_url = uploadResponse.file_url;
      }

      // 2. Pixeliser l'image
      toast.info('Pixelisation de l\'image...');
      const img = new Image();
      img.crossOrigin = 'anonymous';

      await new Promise((resolve, reject) => {
        img.onload = resolve;
        img.onerror = reject;
        img.src = file_url;
      });

      // Calculer les dimensions en gardant les proportions
      const aspectRatio = img.width / img.height;
      let width, height;
      if (aspectRatio > 1) {
        width = gridSize;
        height = Math.round(gridSize / aspectRatio);
      } else {
        height = gridSize;
        width = Math.round(gridSize * aspectRatio);
      }

      // Calculer la marge blanche (10% de la largeur, minimum 20px)
      const marginSize = Math.max(20, Math.round(width * 0.1));
      const canvasWithMargin = width + (marginSize * 2);
      const canvasWithMarginHeight = height + (marginSize * 2);

      // Créer le canvas pixelisé avec marge blanche
      const pixelCanvas = document.createElement('canvas');
      pixelCanvas.width = canvasWithMargin;
      pixelCanvas.height = canvasWithMarginHeight;
      const pixelCtx = pixelCanvas.getContext('2d');
      
      // Fond blanc
      pixelCtx.fillStyle = '#FFFFFF';
      pixelCtx.fillRect(0, 0, canvasWithMargin, canvasWithMarginHeight);
      
      // Dessiner l'image au centre avec marge
      pixelCtx.imageSmoothingEnabled = false;
      pixelCtx.drawImage(img, marginSize, marginSize, width, height);
      
      // Mettre à jour les dimensions finales
      width = canvasWithMargin;
      height = canvasWithMarginHeight;

      // 3. Détecter les couleurs
      toast.info('Détection des couleurs...');
      const colorPalette = detectColors(pixelCanvas, maxColors);

      // Ajouter totalCount et doneCount pour chaque couleur
      colorPalette.forEach(color => {
        color.totalCount = color.count;
        color.doneCount = 0;
        color.progress = 0;
      });

      // 4. Associer les symboles automatiquement
      toast.info('Association des symboles...');
      const allSymbols = SYMBOL_CATEGORIES.flatMap(cat => cat.symbols);
      colorPalette.forEach((color, index) => {
        const symbol = allSymbols[index % allSymbols.length];
        color.assignedSymbolId = symbol.id;
        color.assignedSymbolChar = symbol.char;
      });

      // 5. Générer la grille de symboles
      const symbolGrid = generateSymbolGrid(pixelCanvas, colorPalette);

      toast.success('Motif importé avec succès !');

      onImportComplete({
        width,
        height,
        sourceImage: file_url,
        colorPalette,
        symbolGrid
      });

      onClose();

      /* Ancien code IA commenté
      // 2. Analyse de l'image avec l'IA
      toast.info('Analyse de l\'image en cours...');
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze this cross-stitch pattern image and convert it to a grid format.
        
Instructions:
- IMPORTANT: Preserve the original image aspect ratio (width/height proportions)
- Target maximum dimension: ${gridSize} stitches (adjust the other dimension proportionally)
- Maximum ${colorCount} colors
- For each stitch, provide: row, column, and hex color
- Match colors to DMC thread colors when possible
- Return ONLY valid JSON, no markdown

Return format:
{
  "width": <number>,
  "height": <number>,
  "stitches": [
    {"row": 0, "col": 0, "color": "#E3242B"},
    ...
  ],
  "colors_used": [
    {"hex": "#E3242B", "name": "Rouge vif", "dmc": "DMC-666"},
    ...
  ]
}`,
        file_urls: [file_url],
        response_json_schema: {
          type: "object",
          properties: {
            width: { type: "integer" },
            height: { type: "integer" },
            stitches: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  row: { type: "integer" },
                  col: { type: "integer" },
                  color: { type: "string" }
                }
              }
            },
            colors_used: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  hex: { type: "string" },
                  name: { type: "string" },
                  dmc: { type: "string" }
                }
              }
            }
          }
        }
      });

      */
      
    } catch (error) {
      console.error('Erreur import:', error);
      toast.error('Erreur lors de l\'import de l\'image');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleImportAsReference = () => {
    if (preview && onReferenceOnly) {
      // Ouvrir le dialog de recadrage au lieu d'importer directement
      toast.info('Veuillez recadrer le visuel avant import');
      handleClose();
      // Le parent gérera l'ouverture du CropDialog
      onReferenceOnly(preview);
    }
  };

  const handleClose = () => {
    if (!isProcessing) {
      setFile(null);
      setPreview(null);
      onClose();
    }
  };

  const formatFileSize = (bytes) => {
    if (!bytes) return '0 B';
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Importer une image</DialogTitle>
          <DialogDescription>
            Transformez l'image sélectionnée en motif de point de croix.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Section A - Fichier sélectionné */}
          {file && (
            <div className="border border-slate-200 rounded-lg p-4 bg-slate-50">
              <div className="flex items-center justify-between">
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-slate-700 mb-1">Fichier sélectionné :</div>
                  <div className="flex items-center gap-3">
                    <div className="font-semibold text-slate-900 truncate">{file.name}</div>
                    <div className="text-sm text-slate-600">({formatFileSize(file.size)})</div>
                  </div>
                </div>
                <label className="cursor-pointer">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-slate-600 hover:text-slate-900"
                    asChild
                  >
                    <span>Changer d'image…</span>
                  </Button>
                  <Input
                    type="file"
                    accept="image/png,image/jpeg,image/jpg"
                    onChange={handleFileChange}
                    className="hidden"
                    disabled={isProcessing}
                  />
                </label>
              </div>
            </div>
          )}

          {/* Section B - Aperçu */}
          <div>
            <Label className="text-sm font-medium text-slate-900 mb-3 block">Aperçu du motif</Label>
            <div className="border-2 border-slate-200 rounded-lg overflow-hidden bg-slate-50">
              {preview ? (
                <img 
                  src={preview} 
                  alt="Aperçu" 
                  className="w-full h-64 object-contain"
                  onError={() => toast.error('Impossible d\'afficher l\'aperçu de l\'image, mais le fichier est bien sélectionné.')}
                />
              ) : (
                <div className="w-full h-64 flex items-center justify-center text-slate-400">
                  <div className="text-center">
                    <Upload className="w-12 h-12 mx-auto mb-2 opacity-50" />
                    <div className="text-sm">Aucune image sélectionnée</div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Section C - Paramètres de génération */}
          <div className="space-y-4">
            <div>
              <Label htmlFor="gridSize" className="text-sm font-medium text-slate-900 mb-2 block">
                Taille maximale de la grille
              </Label>
              <Input
                id="gridSize"
                type="number"
                min={20}
                max={400}
                value={gridSize}
                onChange={(e) => setGridSize(parseInt(e.target.value) || 150)}
                disabled={isProcessing}
              />
              <p className="text-xs text-slate-500 mt-1.5">
                Plus la grille est grande, plus les détails sont précis (mais la broderie sera plus longue).
              </p>
            </div>

            <div>
              <Label htmlFor="maxColors" className="text-sm font-medium text-slate-900 mb-2 block">
                Nombre de couleurs maximum
              </Label>
              <Input
                id="maxColors"
                type="number"
                min={2}
                max={120}
                value={maxColors}
                onChange={(e) => setMaxColors(parseInt(e.target.value) || 40)}
                disabled={isProcessing}
              />
              <p className="text-xs text-slate-500 mt-1.5">
                Réduisez le nombre de couleurs pour simplifier le motif.
              </p>
            </div>

            {/* Options avancées */}
            <div className="border-t border-slate-200 pt-4">
              <button
                onClick={() => setShowAdvanced(!showAdvanced)}
                className="flex items-center gap-2 text-sm font-medium text-slate-700 hover:text-slate-900"
                type="button"
              >
                <span>{showAdvanced ? '▼' : '▶'}</span>
                Options avancées
              </button>

              {showAdvanced && (
                <div className="mt-4 space-y-3 pl-6">
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={preFilterColors}
                      onChange={(e) => setPreFilterColors(e.target.checked)}
                      className="rounded border-slate-300"
                      disabled={isProcessing}
                    />
                    <span className="text-sm text-slate-700">
                      Pré-filtrer les couleurs proches
                    </span>
                  </label>

                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={printMode}
                      onChange={(e) => setPrintMode(e.target.checked)}
                      className="rounded border-slate-300"
                      disabled={isProcessing}
                    />
                    <span className="text-sm text-slate-700">
                      Préparer pour impression (fond blanc, contraste renforcé)
                    </span>
                  </label>

                  <div>
                    <Label className="text-sm text-slate-700 mb-2 block">
                      Profil de palette
                    </Label>
                    <select
                      value={paletteProfile}
                      onChange={(e) => setPaletteProfile(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900 text-sm"
                      disabled={isProcessing}
                    >
                      <option value="standard">Standard DMC</option>
                      <option value="soft">Palette douce</option>
                      <option value="contrast">Palette contrastée</option>
                    </select>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Boutons d'action */}
        <DialogFooter className="gap-2 pt-4 border-t border-slate-200">
          <Button
            variant="outline"
            onClick={handleClose}
            disabled={isProcessing}
          >
            Annuler
          </Button>
          <Button
            onClick={handleImport}
            disabled={(!file && !preloadedImage) || isProcessing}
            className="bg-indigo-600 hover:bg-indigo-700 text-white px-6"
          >
            {isProcessing ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Génération en cours...
              </>
            ) : (
              'Générer la grille'
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}