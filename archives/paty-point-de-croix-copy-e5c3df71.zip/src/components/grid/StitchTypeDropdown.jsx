import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { ChevronDown } from 'lucide-react';
import { cn } from '@/lib/utils';

const STITCH_TYPES = [
  { id: 'full', name: 'Point complet', icon: '✕', description: 'Full cross' },
  { id: 'half', name: 'Demi-point', icon: '/', description: 'Half cross' },
  { id: 'quarter', name: 'Quart de point', icon: '◸', description: 'Quarter stitch' },
  { id: 'three-quarter', name: 'Trois-quarts', icon: '◹', description: 'Three-quarter' },
  { id: 'backstitch', name: 'Point arrière', icon: '―', description: 'Backstitch' },
  { id: 'knot', name: 'Nœud français', icon: '●', description: 'French knot' },
  { id: 'bead', name: 'Perle', icon: '◆', description: 'Bead' }
];

export default function StitchTypeDropdown({ selectedType, onSelect, isActive, onActivate }) {
  const currentStitch = STITCH_TYPES.find(s => s.id === selectedType) || STITCH_TYPES[0];

  const handleSelect = (stitchId) => {
    onSelect(stitchId);
    onActivate();
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant={isActive ? "default" : "ghost"}
          size="sm"
          className={cn(
            "w-full justify-between gap-3 h-10 transition-all",
            isActive 
              ? "bg-slate-900 text-white hover:bg-slate-800 shadow-md" 
              : "hover:bg-slate-100 text-slate-700"
          )}
        >
          <span className="text-xl w-6">{currentStitch.icon}</span>
          <span className="text-sm font-medium flex-1 text-left">{currentStitch.name}</span>
          <ChevronDown className="w-4 h-4 opacity-60" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start" className="w-56">
        {STITCH_TYPES.map((stitch) => (
          <DropdownMenuItem
            key={stitch.id}
            onClick={() => handleSelect(stitch.id)}
            className={cn(
              "flex items-center gap-3 cursor-pointer",
              selectedType === stitch.id && "bg-slate-100"
            )}
          >
            <span className="text-xl w-6 text-center">{stitch.icon}</span>
            <div className="flex-1">
              <div className="text-sm font-medium">{stitch.name}</div>
              <div className="text-xs text-slate-500">{stitch.description}</div>
            </div>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

export { STITCH_TYPES };