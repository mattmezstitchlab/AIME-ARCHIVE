import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import GridCanvas from './GridCanvas';
import DmcBottomPalette from './DmcBottomPalette';
import SimpleImportDialog from './SimpleImportDialog';
import PreparePatternDialog from './PreparePatternDialog';
import AdvancedPatternPreparationPanel from './AdvancedPatternPreparationPanel';
import FloatingTutorialCarousel from './FloatingTutorialCarousel';
import WelcomeIntroCarousel from './WelcomeIntroCarousel';

import { Button } from '@/components/ui/button';
import { 
  Sparkles, Eraser, Pipette, Square, Eye, 
  Grid3x3, Target, ZoomIn, ZoomOut, Maximize2, ChevronDown, 
  ChevronRight, Box, Image as ImageIcon, Hand, Plus, Highlighter, 
  ArrowLeftRight, Undo, Redo, Map as MapIcon, X
} from 'lucide-react';
import SimpleMiniMap from './SimpleMiniMap';
import StitchToolbar from './StitchToolbar';
import { parseGPSCoordinate } from './GridRulersEnhanced';
import WelcomeHome from './WelcomeHome';

import RepairHolesDialog from './RepairHolesDialog';
import SubImportDialog from './SubImportDialog';
import SubAutoRepairDialog from './SubAutoRepairDialog';
import SubStitchPicker from './SubStitchPicker';
import SubExportDialog from './SubExportDialog';
import SubBeforeAfterDialog from './SubBeforeAfterDialog';
import SubDiscoveryCarousel from './SubDiscoveryCarousel';
import ImportSub2Dialog from './ImportSub2Dialog';
import SubDisplayEngine from './SubDisplayEngine';
import SubExportModule from './SubExportModule';
import { SubPointsPanel, SubPointsToolbar, SUB_POINTS } from './SubPointsSystem';
import SubPrintModule from './SubPrintModule';
import ImportSubAuto from './ImportSubAuto';
import SubStitchStylesPanel from './SubStitchStylesPanel';
import SubQuickGuide from './SubQuickGuide';
import ImageImportPro from './ImageImportPro';
import SmartImportV3 from './SmartImportV3';
import HelpCenter from './HelpCenter';
import { fixAllSymbols, checkSymbolsStatus, applySymbolsToGrid } from './symbolAssigner';
import { repairGrid, gridQualityCheck } from './RepairEngine';
import SaveProjectDialogPremium from './SaveProjectDialogPremium';
import SelectionActionsPopup from './SelectionActionsPopup';
import UnifiedToolbar from './UnifiedToolbar';
import MiniCartePro from './MiniCartePro';
import MainToolbar from './MainToolbar';
import DashboardModal from './DashboardModal';
import ProjectsModal from './ProjectsModal';
import { useSettings } from '../settings/SettingsContext';
import UndoRedoControls from './UndoRedoControls';
import FloatingMiniMapZoom from './FloatingMiniMapZoom';
import StatsModal from './StatsModal';

export default function SimpleGridEditor() {
  // ===== TOUS LES HOOKS EN HAUT - TOUJOURS APPELÉS =====
  const [gridConfig, setGridConfig] = useState({
    name: 'Nouvelle grille',
    nb_colonnes: 300,
    nb_lignes: 300,
    taille_case: 25,
    zoom: 1.0,
    offset_x: 0,
    offset_y: 0,
    stitches: []
  });

  const [pattern, setPattern] = useState(null);
  const [selectedColorId, setSelectedColorId] = useState(null);
  const [hoverCell, setHoverCell] = useState({ col: null, row: null });
  const [canvasSize, setCanvasSize] = useState({ width: 0, height: 0 });
  const [showImportDialog, setShowImportDialog] = useState(false);
  const [showPrepareDialog, setShowPrepareDialog] = useState(false);
  const [showAdvancedPreparationPanel, setShowAdvancedPreparationPanel] = useState(false);
  const [selectedFile, setSelectedFile] = useState(null);
  const [currentTool, setCurrentTool] = useState('pan');
  const [hasImportedVisual, setHasImportedVisual] = useState(false);
  const [showTutorialCarousel, setShowTutorialCarousel] = useState(false);
  
  const [selectionStart, setSelectionStart] = useState(null);
  const [selectionEnd, setSelectionEnd] = useState(null);
  const [showPatternImage, setShowPatternImage] = useState(true);
  const [showGrid, setShowGrid] = useState(true);
  const [showSymbols, setShowSymbols] = useState(true);
  const [showCenterMarker, setShowCenterMarker] = useState(true);
  const [show10x10, setShow10x10] = useState(true);
  const [showFloatingMiniMap, setShowFloatingMiniMap] = useState(false);
  const [expandedBlocks, setExpandedBlocks] = useState({});
  const [showSmartMap, setShowSmartMap] = useState(false);
  const [selectedCells, setSelectedCells] = useState([]);
  const [history, setHistory] = useState([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [isDragging, setIsDragging] = useState(false);
  const [dragStartCell, setDragStartCell] = useState(null);
  const [showRepairDialog, setShowRepairDialog] = useState(false);
  const [showSubImportDialog, setShowSubImportDialog] = useState(false);
  const [showSubRepairDialog, setShowSubRepairDialog] = useState(false);
  const [showSubStitchPicker, setShowSubStitchPicker] = useState(false);
  const [showSubExportDialog, setShowSubExportDialog] = useState(false);
  const [showSubBeforeAfterDialog, setShowSubBeforeAfterDialog] = useState(false);
  const [showSubDiscoveryCarousel, setShowSubDiscoveryCarousel] = useState(false);
  const [showImportSub2Dialog, setShowImportSub2Dialog] = useState(false);
  const [showSubExportModule, setShowSubExportModule] = useState(false);
  const [showSubPointsPanel, setShowSubPointsPanel] = useState(false);
  const [showSubPrintModule, setShowSubPrintModule] = useState(false);
  const [showImportSubAuto, setShowImportSubAuto] = useState(false);
  const [showSubStitchStyles, setShowSubStitchStyles] = useState(false);
  const [showSubQuickGuide, setShowSubQuickGuide] = useState(false);
  const [showImageImportPro, setShowImageImportPro] = useState(false);
  const [showSmartImportV3, setShowSmartImportV3] = useState(false);
  const [showHelpCenter, setShowHelpCenter] = useState(false);
  const [stitchStylesSettings, setStitchStylesSettings] = useState(null);
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [showDashboardModal, setShowDashboardModal] = useState(false);
  const [showWelcomeIntro, setShowWelcomeIntro] = useState(false);
  const [showProjectsModal, setShowProjectsModal] = useState(false);
  
  // Récupérer les settings globaux
  const { settings: userSettings } = useSettings();
  const [showSyncMiniMap, setShowSyncMiniMap] = useState(false);
  const [statsMode, setStatsMode] = useState(false);
  const [displayMode, setDisplayMode] = useState('mix');
  const [contrastMode, setContrastMode] = useState(false);
  const [symbolSizeMode, setSymbolSizeMode] = useState('normal'); // 'normal', 'mini', 'comfort', 'mega'
  const [antiFatigueMode, setAntiFatigueMode] = useState(false);
  const [focusColorMode, setFocusColorMode] = useState(false);
  const [highlightActiveMode, setHighlightActiveMode] = useState(false);
  const [nightMode, setNightMode] = useState(false);
  const [autoCountMode, setAutoCountMode] = useState(false);
  const [selectedStitch, setSelectedStitch] = useState('full');
  const [showBottomPalette, setShowBottomPalette] = useState(true); // TOUJOURS VISIBLE par défaut
  const [showColors, setShowColors] = useState(true);
  const [currentSubPoint, setCurrentSubPoint] = useState(SUB_POINTS[0]);
  const [currentPencilSubTool, setCurrentPencilSubTool] = useState('point-magique');
  const [currentEraserSubTool, setCurrentEraserSubTool] = useState('gomme-selective');
  const [currentSelectionSubTool, setCurrentSelectionSubTool] = useState('selection-symbole');
  const [currentHandSubTool, setCurrentHandSubTool] = useState('main-classique');
  const [currentSubStitch, setCurrentSubStitch] = useState(null);
  const [flashCell, setFlashCell] = useState(null); // Pour animation flash
      const [selectionRect, setSelectionRect] = useState(null); // Pour sélection rectangle
      const [highlightedZone, setHighlightedZone] = useState(null); // Pour surlignage GPS
      const [activeFilter, setActiveFilter] = useState(null); // Filtre intelligent actif
          const [isolationMode, setIsolationMode] = useState(false); // Mode isolation total
          // Filtres avancés
          const [showUnstitchedZones, setShowUnstitchedZones] = useState(false);
          const [showPotentialErrors, setShowPotentialErrors] = useState(false);
          const [errorSensitivity, setErrorSensitivity] = useState('medium');
          const [showMissingPoints, setShowMissingPoints] = useState(false);
          const [analysisResults, setAnalysisResults] = useState({ unstitched: 0, errors: 0, missing: 0, errorCells: [], unstitchedCells: [], missingCells: [] });
  const [isSelecting, setIsSelecting] = useState(false);
  const [currentProjectId, setCurrentProjectId] = useState(null); // ID du projet actuel
  const [showSelectionPopup, setShowSelectionPopup] = useState(false);
          const [selectionHighlightMode, setSelectionHighlightMode] = useState(null); // 'highlight' | 'inverse' | 'mask'
          const [paletteHoverColorId, setPaletteHoverColorId] = useState(null); // Survol palette DMC
          const [isolatedColorId, setIsolatedColorId] = useState(null); // Couleur isolée globale
          const fileInputRef = useRef(null);

  // Palette DMC par défaut
  const defaultDmcPalette = [
    { id: 'dmc-310', hex: '#000000', name: 'Noir', code: 'DMC-310', count: 0, totalCount: 0, doneCount: 0, progress: 0, assignedSymbolChar: '●' },
    { id: 'dmc-321', hex: '#C8341F', name: 'Rouge', code: 'DMC-321', count: 0, totalCount: 0, doneCount: 0, progress: 0, assignedSymbolChar: '✕' },
    { id: 'dmc-702', hex: '#26823D', name: 'Vert', code: 'DMC-702', count: 0, totalCount: 0, doneCount: 0, progress: 0, assignedSymbolChar: '▲' },
    { id: 'dmc-742', hex: '#F6A14A', name: 'Orange', code: 'DMC-742', count: 0, totalCount: 0, doneCount: 0, progress: 0, assignedSymbolChar: '■' },
    { id: 'dmc-796', hex: '#1E4C8A', name: 'Bleu', code: 'DMC-796', count: 0, totalCount: 0, doneCount: 0, progress: 0, assignedSymbolChar: '◆' },
    { id: 'dmc-3865', hex: '#F7F5ED', name: 'Blanc cassé', code: 'DMC-3865', count: 0, totalCount: 0, doneCount: 0, progress: 0, assignedSymbolChar: '○' }
  ];

  // Mesurer le canvas au montage
  useEffect(() => {
    const updateCanvasSize = () => {
      const canvasContainer = document.getElementById('simple-canvas-container');
      if (canvasContainer) {
        setCanvasSize({
          width: canvasContainer.offsetWidth,
          height: canvasContainer.offsetHeight
        });
      }
    };
    
    updateCanvasSize();
    
    window.addEventListener('resize', updateCanvasSize);
    return () => window.removeEventListener('resize', updateCanvasSize);
  }, []);

  // Raccourcis clavier
  useEffect(() => {
    const handleKeyDown = (e) => {
      const target = e.target;
      if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA') return;

      // Raccourcis Undo/Redo avec Ctrl/Cmd
      if (e.ctrlKey || e.metaKey) {
        if (e.shiftKey && e.key.toLowerCase() === 'z') {
          e.preventDefault();
          handleRedo();
          return;
        }
        if (e.key.toLowerCase() === 'z') {
          e.preventDefault();
          handleUndo();
          return;
        }
      }

      // Autres raccourcis (sans modificateurs)
      if (e.ctrlKey || e.metaKey || e.altKey) return;

      switch (e.key.toLowerCase()) {
        case 'v':
          e.preventDefault();
          setShowPatternImage(prev => !prev);
          break;
        case 'c':
          e.preventDefault();
          handleToolSelect('cross');
          toast.info('Outil Crayon activé');
          break;
        case 'g':
          e.preventDefault();
          handleToolSelect('erase');
          toast.info('Outil Gomme activé');
          break;
        case 's':
          e.preventDefault();
          handleToolSelect('selection-ia');
          toast.info('Outil Sélection activé');
          break;
        case 'escape':
          setSelectedCells([]);
          setSelectionRect(null);
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [pattern, historyIndex, history]);

  // Écouter l'événement d'ouverture du tutoriel depuis le header
  useEffect(() => {
    const handleOpenTutorial = () => setShowHelpCenter(true);
    window.addEventListener('openTutorial', handleOpenTutorial);
    return () => window.removeEventListener('openTutorial', handleOpenTutorial);
  }, []);

  // Afficher le carrousel d'aide au premier chargement
  useEffect(() => {
    const hasSeenHelp = localStorage.getItem('broodway_help_seen');
    if (!hasSeenHelp) {
      setShowHelpCenter(true);
      localStorage.setItem('broodway_help_seen', 'true');
    }
  }, []);

  // Centrer la vue quand les dimensions changent
  useEffect(() => {
    centerView();
  }, [gridConfig.nb_colonnes, gridConfig.nb_lignes]);

  // Synchroniser les réglages utilisateur
  useEffect(() => {
    if (userSettings) {
      setShowSyncMiniMap(userSettings.showMinimap ?? true);
      setShowGrid(userSettings.showGrid ?? true);
      setShowCenterMarker(userSettings.showCenterMarker ?? true);
    }
  }, [userSettings]);

  const handleFileSelect = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const handleFileChange = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const fileType = file.type;
    const fileName = file.name.toLowerCase();
    
    // Si c'est un fichier .SUB
    if (fileName.endsWith('.sub') || fileType === 'application/x-sub') {
      try {
        const content = await file.text();
        const subData = JSON.parse(content);
        handleSubImportComplete(subData);
        return;
      } catch (error) {
        toast.error('Erreur lors de la lecture du fichier .SUB');
        return;
      }
    }
    
    // Si c'est une image
    if (fileType.startsWith('image/')) {
      setSelectedFile(file);
      setShowPrepareDialog(true);
      return;
    }

    // Si c'est un PDF
    if (fileType === 'application/pdf') {
      setSelectedFile(file);
      setShowSubImportDialog(true);
      return;
    }

    toast.error('Format non supporté. Merci d\'utiliser une image (PNG, JPG), PDF ou .SUB.');
  };

  // Fonction pour assigner les symboles manquants à toute la palette
  const handleFixEmptySymbols = () => {
    if (!pattern) {
      toast.info('Aucun projet ouvert');
      return;
    }

    const { palette: fixedPalette, fixedCount } = fixAllSymbols(pattern.colorPalette);

    if (fixedCount > 0) {
      // Appliquer les symboles à la grille également
      const updatedGrid = applySymbolsToGrid(pattern.symbolGrid, fixedPalette);
      
      setPattern(prev => ({
        ...prev,
        colorPalette: fixedPalette,
        symbolGrid: updatedGrid
      }));
      toast.success(`Tous les symboles manquants ont été assignés. Aucune case colorée ne reste sans symbole. (${fixedCount} corrigé${fixedCount > 1 ? 's' : ''})`);
    } else {
      toast.info('Tous les symboles sont déjà assignés.');
    }
  };

  // Vérification automatique des symboles à l'ouverture d'un projet
  const [showSymbolFixPrompt, setShowSymbolFixPrompt] = useState(false);
  
  useEffect(() => {
    if (pattern?.colorPalette) {
      const status = checkSymbolsStatus(pattern.colorPalette);
      if (status.hasMissing || status.hasDuplicates) {
        setShowSymbolFixPrompt(true);
      }
    }
  }, [pattern?.colorPalette?.length]);

  // Gestion de l'import .SUB complet ou Smart Import V3
  const handleSubImportComplete = (patternData) => {
    if (!patternData) return;

    // Si c'est un fichier .SUB complet avec metadata
    if (patternData.metadata && patternData.grid) {
      const { metadata, grid, palette } = patternData;
      
      // Reconstruire le pattern depuis le format .SUB
      const symbolGrid = [];
      // Décompresser si nécessaire
      if (grid.cells) {
        grid.cells.forEach(compressedRow => {
          const row = [];
          compressedRow.forEach(({ key, count }) => {
            for (let i = 0; i < count; i++) {
              if (key === 'empty') {
                row.push(null);
              } else {
                const [symbol, color, type] = key.split('|');
                row.push({ 
                  colorId: color,
                  symbol, 
                  color, 
                  type: type || 'full',
                  done: false
                });
              }
            }
          });
          symbolGrid.push(row);
        });
      }

      const importedPattern = {
        width: metadata.dimensions?.width || symbolGrid[0]?.length || 100,
        height: metadata.dimensions?.height || symbolGrid.length || 100,
        sourceImage: patternData.sourceImage || null,
        colorPalette: palette?.colors || [],
        symbolGrid,
        offsetCol: 0,
        offsetRow: 0
      };

      setPattern(importedPattern);
      setHasImportedVisual(!!patternData.sourceImage);
      setGridConfig(prev => ({
        ...prev,
        name: metadata.name || 'Import .SUB',
        nb_colonnes: importedPattern.width,
        nb_lignes: importedPattern.height
      }));

      // Centrer avec zoom intelligent
      setTimeout(() => centerOnPattern(importedPattern.width, importedPattern.height, 0, 0, patternData.initialZoom), 100);
      return;
    }

    // Si c'est un pattern simple généré par SmartImportV3 ou SubImportDialog
    if (patternData.symbolGrid) {
      // Assigner automatiquement les symboles manquants
      const { palette: fixedPalette, fixedCount } = fixAllSymbols(patternData.colorPalette);

      // Grille = dimensions exactes du pattern (pas de zone vide autour)
      const importedPattern = {
        ...patternData,
        colorPalette: fixedPalette,
        offsetCol: 0,
        offsetRow: 0
      };

      setPattern(importedPattern);
      
      if (fixedCount > 0) {
        toast.success(`${fixedCount} symbole${fixedCount > 1 ? 's' : ''} manquant${fixedCount > 1 ? 's' : ''} assigné${fixedCount > 1 ? 's' : ''} automatiquement.`);
      }
      setHasImportedVisual(!!patternData.sourceImage);
      
      // Mettre à jour la config de grille pour correspondre exactement au pattern
      setGridConfig(prev => ({
        ...prev,
        name: 'Motif importé',
        nb_colonnes: patternData.width,
        nb_lignes: patternData.height
      }));

      // Centrer avec zoom intelligent après un court délai pour laisser le render se faire
      setTimeout(() => {
        centerOnPattern(patternData.width, patternData.height, 0, 0, patternData.initialZoom);
      }, 150);
    }
  };

  // Sauvegarder l'état automatiquement DANS WINDOW pour persistance entre navigations
  useEffect(() => {
    if (pattern || gridConfig.stitches.length > 0) {
      // Stocker le projet complet en mémoire pour qu'il persiste entre les pages
      window.__patybee_current_project = {
        pattern,
        gridConfig,
        selectedColorId,
        currentTool,
        hasImportedVisual,
        showPatternImage,
        showGrid,
        showSymbols,
        showCenterMarker,
        show10x10,
        currentProjectId,
        timestamp: Date.now()
      };
    }
  }, [pattern, gridConfig, selectedColorId, currentTool, hasImportedVisual, showPatternImage, showGrid, showSymbols, showCenterMarker, show10x10, currentProjectId]);

  // Charger le projet depuis la base de données au montage OU depuis la mémoire (navigation)
  useEffect(() => {
    const loadProject = async () => {
      // PRIORITÉ 1: Vérifier s'il y a un projet à charger depuis le Dashboard
      const projectIdToLoad = localStorage.getItem('loadProjectId');
      if (projectIdToLoad) {
        localStorage.removeItem('loadProjectId');
        try {
          // Récupérer tous les projets et filtrer par ID
          const allProjects = await base44.entities.Grid.list();
          const project = allProjects.find(p => p.id === projectIdToLoad);
          
          if (project) {
            setCurrentProjectId(project.id);
            setGridConfig({
              name: project.name || 'Sans nom',
              nb_colonnes: project.nb_colonnes || 300,
              nb_lignes: project.nb_lignes || 300,
              taille_case: project.taille_case || 25,
              zoom: project.zoom || 1.0,
              offset_x: project.offset_x || 0,
              offset_y: project.offset_y || 0,
              stitches: project.stitches || []
            });
            
            if (project.pattern) {
              // Reconstruire le symbolGrid depuis les stitches si nécessaire
              let symbolGrid = project.pattern.symbolGrid;
              
              // Si symbolGrid n'existe pas mais que stitches existe, reconstruire
              if ((!symbolGrid || symbolGrid.length === 0) && project.pattern.stitches?.length > 0) {
                const width = project.pattern.width || 100;
                const height = project.pattern.height || 100;
                symbolGrid = Array(height).fill(null).map(() => Array(width).fill(null));
                
                project.pattern.stitches.forEach(stitch => {
                  if (stitch.row >= 0 && stitch.row < height && stitch.col >= 0 && stitch.col < width) {
                    symbolGrid[stitch.row][stitch.col] = {
                      colorId: stitch.color,
                      done: stitch.done || false
                    };
                  }
                });
              }
              
              const loadedPattern = {
                width: project.pattern.width || 100,
                height: project.pattern.height || 100,
                sourceImage: project.pattern.source_image,
                colorPalette: project.pattern.colors?.map((c, idx) => ({
                  id: `color-${idx}`,
                  hex: c.hex,
                  name: c.name,
                  code: c.dmc,
                  assignedSymbolChar: ['●', '✕', '▲', '■', '◆', '○', '▼', '◀', '▶', '★'][idx % 10]
                })) || [],
                symbolGrid: symbolGrid || [],
                offsetCol: Math.floor(((project.nb_colonnes || 300) - (project.pattern.width || 100)) / 2),
                offsetRow: Math.floor(((project.nb_lignes || 300) - (project.pattern.height || 100)) / 2)
              };
              
              setPattern(loadedPattern);
              setHasImportedVisual(!!project.pattern.source_image);
              
              if (loadedPattern.width > 0 && loadedPattern.height > 0) {
                setTimeout(() => centerOnPattern(loadedPattern.width, loadedPattern.height, loadedPattern.offsetCol, loadedPattern.offsetRow), 200);
              }
            }
            toast.success('✅ Projet chargé');
            return;
          }
        } catch (error) {
          console.error('Erreur chargement projet:', error);
          toast.error('Erreur lors du chargement du projet');
        }
      }

      // PRIORITÉ 2: Restaurer le projet depuis la mémoire (navigation entre pages)
      if (window.__patybee_current_project) {
        const savedProject = window.__patybee_current_project;
        if (savedProject.pattern) {
          setPattern(savedProject.pattern);
          setGridConfig(savedProject.gridConfig);
          setSelectedColorId(savedProject.selectedColorId);
          setCurrentTool(savedProject.currentTool || 'pan');
          setHasImportedVisual(savedProject.hasImportedVisual);
          setShowPatternImage(savedProject.showPatternImage ?? true);
          setShowGrid(savedProject.showGrid ?? true);
          setShowSymbols(savedProject.showSymbols ?? true);
          setShowCenterMarker(savedProject.showCenterMarker ?? true);
          setShow10x10(savedProject.show10x10 ?? true);
          setCurrentProjectId(savedProject.currentProjectId);
          return;
        }
      }
    };

    loadProject();
  }, []);

  // État pour suivre l'ID du projet actuel - DÉPLACÉ PLUS HAUT

  // Générer une miniature du projet
  const generateThumbnail = () => {
    if (!pattern?.sourceImage) return null;
    return pattern.sourceImage; // Utiliser l'image source comme miniature
  };

  // Ouvrir le dialog de sauvegarde
  const handleSaveProject = () => {
    if (!pattern) {
      toast.info('Aucun projet à sauvegarder');
      return;
    }
    setShowSaveDialog(true);
  };

  // Sauvegarder le projet en base de données
  const handleSaveProjectConfirm = async (saveConfig) => {
    try {
      const user = await base44.auth.me();
      if (!user) {
        toast.error('Vous devez être connecté pour sauvegarder');
        return;
      }

      // Préparer les données du projet
      const projectData = {
        name: saveConfig.name,
        nb_colonnes: gridConfig.nb_colonnes,
        nb_lignes: gridConfig.nb_lignes,
        taille_case: gridConfig.taille_case,
        zoom: gridConfig.zoom,
        offset_x: gridConfig.offset_x,
        offset_y: gridConfig.offset_y,
        stitches: gridConfig.stitches || [],
        pattern: pattern ? {
          width: pattern.width,
          height: pattern.height,
          source_image: pattern.sourceImage,
          symbolGrid: pattern.symbolGrid,
          theme: saveConfig.theme,
          difficulty: saveConfig.difficulty,
          notes: saveConfig.notes,
          stitches: pattern.symbolGrid?.flat().filter(Boolean).map((cell, idx) => {
            const row = Math.floor(idx / pattern.width);
            const col = idx % pattern.width;
            return {
              col,
              row,
              color: cell.colorId,
              done: cell.done || false
            };
          }) || [],
          colors: pattern.colorPalette?.map(c => ({
            hex: c.hex || c.dmcHex,
            name: c.name || c.code,
            dmc: c.code || c.dmcCode
          })) || []
        } : null
      };

      // Si on a un ID de projet actuel, on met à jour
      if (currentProjectId) {
        await base44.entities.Grid.update(currentProjectId, projectData);
        toast.success('✅ Projet mis à jour');
      } else {
        // Sinon, créer un nouveau projet
        const newProject = await base44.entities.Grid.create(projectData);
        setCurrentProjectId(newProject.id);
        toast.success('✅ Projet ajouté à "Mes Projets"');
      }
      
      // Mettre à jour le nom de la grille
      setGridConfig(prev => ({ ...prev, name: saveConfig.name }));
    } catch (error) {
      console.error('Erreur sauvegarde:', error);
      toast.error('Erreur lors de la sauvegarde');
    }
  };

      // Exposer les handlers au Layout et fonction de remplissage
      useEffect(() => {
        if (typeof window !== 'undefined') {
          window.gridEditorHandlers = {
        onNewGrid: handleCreateNewGrid,
        onSave: handleSaveProject,
        onProjects: () => setShowProjectsModal(true),
        onImport: () => setShowSmartImportV3(true),
        onCloseProject: handleCloseProject,
        onOpenAdvancedStyles: () => setShowSubStitchStyles(true),
        onExport: () => setShowSubExportModule(true),
        hasUnsavedChanges: pattern !== null || gridConfig.stitches.length > 0,
        hasCurrentProject: pattern !== null,
        pattern,
        onOpenDashboard: () => setShowDashboardModal(true),
        onOpenWelcomeIntro: () => setShowWelcomeIntro(true),
        onUndo: handleUndo,
        onRedo: handleRedo,
        canUndo: historyIndex > 0,
        canRedo: historyIndex < history.length - 1,
        onToggleEdit: () => setCurrentTool(currentTool === 'pan' ? 'cross' : 'pan'),
        onTogglePreview: () => setShowPatternImage(!showPatternImage),
        isEditMode: currentTool !== 'pan',
        showPreview: showPatternImage,
        // Props pour les dropdowns du header
        currentTool,
        onToolSelect: handleToolSelect,
        showGrid,
        onToggleGrid: () => setShowGrid(!showGrid),
        showSymbols,
        onToggleSymbols: () => setShowSymbols(!showSymbols),
        contrastMode,
        onContrastModeChange: () => setContrastMode(!contrastMode),
        symbolSizeMode,
        onSymbolSizeModeChange: setSymbolSizeMode,
        antiFatigueMode,
        onAntiFatigueModeChange: () => setAntiFatigueMode(!antiFatigueMode),
        focusColorMode,
        onFocusColorModeChange: () => setFocusColorMode(!focusColorMode),
        highlightActiveMode,
        onHighlightActiveModeChange: () => setHighlightActiveMode(!highlightActiveMode),
        nightMode,
        onNightModeChange: () => setNightMode(!nightMode),
        autoCountMode,
        onAutoCountModeChange: () => setAutoCountMode(!autoCountMode),
        onNavigateToZone: handleNavigateToZone,
        activeFilter,
        onFilterByStitchType: (stitchType) => setActiveFilter({ type: 'stitch', value: stitchType }),
        onFilterByColor: (colorId, colorName) => { setActiveFilter({ type: 'color', value: colorId, label: colorName }); setSelectedColorId(colorId); },
        onFilterBySymbol: (symbol, colorId) => { setActiveFilter({ type: 'symbol', value: symbol, colorId }); setSelectedColorId(colorId); },
        onResetFilters: () => { setActiveFilter(null); setIsolationMode(false); setIsolatedColorId(null); },
        isolationMode,
        onToggleIsolationMode: () => setIsolationMode(!isolationMode),
        showUnstitchedZones,
        onToggleUnstitchedZones: () => setShowUnstitchedZones(!showUnstitchedZones),
        showPotentialErrors,
        onTogglePotentialErrors: () => setShowPotentialErrors(!showPotentialErrors),
        errorSensitivity,
        onErrorSensitivityChange: setErrorSensitivity,
        showMissingPoints,
        onToggleMissingPoints: () => setShowMissingPoints(!showMissingPoints),
        unstitchedCount: analysisResults.unstitched,
        potentialErrorsCount: analysisResults.errors,
        missingPointsCount: analysisResults.missing,
        currentPencilSubTool,
        onPencilSubToolSelect: setCurrentPencilSubTool,
        currentEraserSubTool,
        onEraserSubToolSelect: setCurrentEraserSubTool,
        currentSelectionSubTool,
        onSelectionSubToolSelect: setCurrentSelectionSubTool,
        statsMode,
        onStatsModeChange: setStatsMode,
        };
      
      // Exposer la fonction d'assignation des symboles manquants
      window.fixEmptySymbols = handleFixEmptySymbols;
      
      // Exposer la fonction de remplissage des trous
      window.fillIsolatedEmptyCells = () => {
        if (!pattern) {
          toast.error('Aucune grille chargée');
          return;
        }
        
        setPattern(prev => {
          const newSymbolGrid = fillIsolatedEmptyCells(prev.symbolGrid, prev.colorPalette);
          return { ...prev, symbolGrid: newSymbolGrid };
        });
      };
      
      // Exposer les actions de sélection pour BroodIA
      window.selectionActions = {
        eraseSelection: () => {
          if (selectedCells.length > 0) {
            handleEraseSelection();
            setShowSelectionPopup(false);
          }
        },
        highlightSelection: () => {
          if (selectedCells.length > 0) {
            setSelectionHighlightMode('highlight');
            setShowSelectionPopup(false);
          }
        },
        inverseHighlight: () => {
          if (selectedCells.length > 0) {
            setSelectionHighlightMode('inverse');
            setShowSelectionPopup(false);
          }
        },
        maskRest: () => {
          if (selectedCells.length > 0) {
            setSelectionHighlightMode('mask');
            setShowSelectionPopup(false);
          }
        },
        deselect: () => {
          setSelectedCells([]);
          setSelectionHighlightMode(null);
          setShowSelectionPopup(false);
        },
        getSelectedCount: () => selectedCells.length
      };
    }
    
    return () => {
      if (typeof window !== 'undefined') {
        delete window.gridEditorHandlers;
        delete window.fillIsolatedEmptyCells;
        delete window.fixEmptySymbols;
        delete window.selectionActions;
      }
    };
  }, [pattern, gridConfig.stitches, selectedCells]);

  // ===== FONCTIONS =====
  const centerView = () => {
    const canvasContainer = document.getElementById('simple-canvas-container');
    if (!canvasContainer) return;

    const containerWidth = canvasContainer.offsetWidth;
    const containerHeight = canvasContainer.offsetHeight;
    const gridWidth = gridConfig.nb_colonnes * gridConfig.taille_case * gridConfig.zoom;
    const gridHeight = gridConfig.nb_lignes * gridConfig.taille_case * gridConfig.zoom;

    setGridConfig(prev => ({
      ...prev,
      offset_x: (containerWidth - gridWidth) / 2,
      offset_y: (containerHeight - gridHeight) / 2
    }));
  };

  const handlePan = (dx, dy) => {
    setGridConfig(prev => ({
      ...prev,
      offset_x: prev.offset_x + dx,
      offset_y: prev.offset_y + dy
    }));
  };

  // Détecter la couleur de fond dominante (bords de l'image)
  const detectBackgroundColor = (imageData, width, height) => {
    const colorFreq = {};
    const borderPixels = [];

    // Échantillonner les bords
    for (let x = 0; x < width; x++) {
      borderPixels.push((0 * width + x) * 4); // Top
      borderPixels.push(((height - 1) * width + x) * 4); // Bottom
    }
    for (let y = 0; y < height; y++) {
      borderPixels.push((y * width + 0) * 4); // Left
      borderPixels.push((y * width + (width - 1)) * 4); // Right
    }

    borderPixels.forEach(idx => {
      const r = imageData.data[idx];
      const g = imageData.data[idx + 1];
      const b = imageData.data[idx + 2];
      const key = `${r},${g},${b}`;
      colorFreq[key] = (colorFreq[key] || 0) + 1;
    });

    const sorted = Object.entries(colorFreq).sort((a, b) => b[1] - a[1]);
    return sorted[0] ? sorted[0][0].split(',').map(Number) : [255, 255, 255];
  };

  // Vérifier si deux couleurs sont proches
  const colorsAreClose = (c1, c2, threshold = 30) => {
    const distance = Math.sqrt(
      Math.pow(c1[0] - c2[0], 2) +
      Math.pow(c1[1] - c2[1], 2) +
      Math.pow(c1[2] - c2[2], 2)
    );
    return distance < threshold;
  };

  const fillIsolatedEmptyCells = (symbolGrid, colorPalette) => {
    if (!symbolGrid || symbolGrid.length === 0) return symbolGrid;

    const height = symbolGrid.length;
    const width = symbolGrid[0].length;
    const newGrid = symbolGrid.map(row => [...row]);
    let filledCount = 0;

    // Passe 1: Remplir les cases avec 3+ voisins
    for (let row = 0; row < height; row++) {
      for (let col = 0; col < width; col++) {
        if (!newGrid[row][col]) {
          const neighbors = [];
          if (row > 0 && newGrid[row - 1][col]) neighbors.push(newGrid[row - 1][col]);
          if (row < height - 1 && newGrid[row + 1][col]) neighbors.push(newGrid[row + 1][col]);
          if (col > 0 && newGrid[row][col - 1]) neighbors.push(newGrid[row][col - 1]);
          if (col < width - 1 && newGrid[row][col + 1]) neighbors.push(newGrid[row][col + 1]);

          if (neighbors.length >= 3) {
            const colorCounts = {};
            neighbors.forEach(n => {
              colorCounts[n.colorId] = (colorCounts[n.colorId] || 0) + 1;
            });
            const dominantColor = Object.entries(colorCounts).sort((a, b) => b[1] - a[1])[0][0];
            newGrid[row][col] = { colorId: dominantColor, done: false };
            filledCount++;
          }
        }
      }
    }

    // Passe 2: Remplir les cases avec 2 voisins
    for (let row = 0; row < height; row++) {
      for (let col = 0; col < width; col++) {
        if (!newGrid[row][col]) {
          const neighbors = [];
          if (row > 0 && newGrid[row - 1][col]) neighbors.push(newGrid[row - 1][col]);
          if (row < height - 1 && newGrid[row + 1][col]) neighbors.push(newGrid[row + 1][col]);
          if (col > 0 && newGrid[row][col - 1]) neighbors.push(newGrid[row][col - 1]);
          if (col < width - 1 && newGrid[row][col + 1]) neighbors.push(newGrid[row][col + 1]);

          if (neighbors.length >= 2) {
            const colorCounts = {};
            neighbors.forEach(n => {
              colorCounts[n.colorId] = (colorCounts[n.colorId] || 0) + 1;
            });
            const dominantColor = Object.entries(colorCounts).sort((a, b) => b[1] - a[1])[0][0];
            newGrid[row][col] = { colorId: dominantColor, done: false };
            filledCount++;
          }
        }
      }
    }

    if (filledCount > 0) {
      toast.success(`${filledCount} case${filledCount > 1 ? 's' : ''} isolée${filledCount > 1 ? 's' : ''} remplie${filledCount > 1 ? 's' : ''}`);
    }

    return newGrid;
  };

  const handlePrepareConfirm = async (config) => {
    setShowPrepareDialog(false);
    setHasImportedVisual(false);
    toast.info('Génération de la grille en cours...');
    
    try {
      const { applyDMCConversionToPattern } = await import('./dmcConversion');
      
      const reader = new FileReader();
      reader.onload = async (e) => {
        const img = new Image();
        img.onload = async () => {
          const canvas = document.createElement('canvas');
          const targetWidth = config.width;
          const targetHeight = config.height;
          
          canvas.width = targetWidth;
          canvas.height = targetHeight;
          
          const ctx = canvas.getContext('2d');
          ctx.imageSmoothingEnabled = false;
          ctx.drawImage(img, 0, 0, targetWidth, targetHeight);
          
          const imageData = ctx.getImageData(0, 0, targetWidth, targetHeight);
          const sourceImage = canvas.toDataURL();

          // Détecter la couleur de fond (bords de l'image)
          const bgColor = detectBackgroundColor(imageData, targetWidth, targetHeight);

          // Fonction pour déterminer si un pixel est "fond"
          const isBackgroundPixel = (r, g, b, a) => {
            // FORCE: Ne jamais laisser de cases vides sauf si explicitement demandé
            if (!config.allowEmptyCells) return false;

            // Si transparence très élevée
            if (a < 50) return true;

            // Vérifier si proche de la couleur de fond détectée
            if (colorsAreClose([r, g, b], bgColor, config.backgroundTolerance)) {
              return true;
            }

            return false;
          };
          
          // Extraction des couleurs (exclure le fond)
          const colorFrequency = {};
          for (let i = 0; i < imageData.data.length; i += 4) {
            const r = imageData.data[i];
            const g = imageData.data[i + 1];
            const b = imageData.data[i + 2];
            const a = imageData.data[i + 3];

            if (isBackgroundPixel(r, g, b, a)) continue;

            const key = `${Math.round(r / 10) * 10},${Math.round(g / 10) * 10},${Math.round(b / 10) * 10}`;
            colorFrequency[key] = (colorFrequency[key] || 0) + 1;
          }

          const sortedColors = Object.entries(colorFrequency)
            .sort((a, b) => b[1] - a[1])
            .slice(0, config.colorsCount);

          // GARANTIE: Si aucune couleur détectée, forcer blanc cassé
          if (sortedColors.length === 0) {
            sortedColors.push(['245,245,240', 1]);
          }
          
          // Construire le pattern
          const importedPattern = {
            width: targetWidth,
            height: targetHeight,
            sourceImage,
            colorPalette: sortedColors.map(([rgb, count], idx) => {
              const [r, g, b] = rgb.split(',').map(Number);
              return {
                id: `color-${idx}`,
                hex: `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`,
                name: `Couleur ${idx + 1}`,
                count,
                totalCount: count,
                doneCount: 0,
                progress: 0,
                assignedSymbolId: `symbol-${idx}`,
                assignedSymbolChar: ['●', '✕', '▲', '■', '◆', '○', '▼', '◀', '▶', '★'][idx % 10]
              };
            }),
            symbolGrid: []
          };
          
          // Générer la grille de symboles - FORCE ALL PIXELS
          for (let row = 0; row < targetHeight; row++) {
            const rowData = [];
            for (let col = 0; col < targetWidth; col++) {
              const idx = (row * targetWidth + col) * 4;
              const r = imageData.data[idx];
              const g = imageData.data[idx + 1];
              const b = imageData.data[idx + 2];
              const a = imageData.data[idx + 3];

              // Vérifier si c'est un pixel de fond
              const isBg = isBackgroundPixel(r, g, b, a);

              if (isBg) {
                rowData.push(null);
                continue;
              }

              // Trouver la couleur correspondante
              const key = `${Math.round(r / 10) * 10},${Math.round(g / 10) * 10},${Math.round(b / 10) * 10}`;
              const colorIndex = sortedColors.findIndex(([k]) => k === key);

              if (colorIndex >= 0) {
                rowData.push({
                  colorId: `color-${colorIndex}`,
                  done: false
                });
              } else {
                // CORRECTION: Toujours assigner la couleur la plus proche
                const distances = sortedColors.map(([rgb]) => {
                  const [cr, cg, cb] = rgb.split(',').map(Number);
                  return Math.sqrt(Math.pow(r - cr, 2) + Math.pow(g - cg, 2) + Math.pow(b - cb, 2));
                });
                const closestIndex = distances.indexOf(Math.min(...distances));
                rowData.push({
                  colorId: `color-${closestIndex}`,
                  done: false
                });
              }
            }
            importedPattern.symbolGrid.push(rowData);
          }
          
          // GARANTIE 1: Remplir les trous isolés
          if (config.noHolesMode || config.autoFillHoles) {
            importedPattern.symbolGrid = fillIsolatedEmptyCells(importedPattern.symbolGrid, importedPattern.colorPalette);
          }

          // GARANTIE 2: Mode sans trous - éliminer 100% des cases vides
          if (config.noHolesMode || !config.allowEmptyCells) {
            for (let row = 0; row < importedPattern.height; row++) {
              for (let col = 0; col < importedPattern.width; col++) {
                if (!importedPattern.symbolGrid[row][col]) {
                  // Chercher la couleur dominante dans un rayon de 3
                  const neighbors = [];
                  for (let dr = -3; dr <= 3; dr++) {
                    for (let dc = -3; dc <= 3; dc++) {
                      const nr = row + dr;
                      const nc = col + dc;
                      if (nr >= 0 && nr < importedPattern.height && nc >= 0 && nc < importedPattern.width) {
                        const cell = importedPattern.symbolGrid[nr][nc];
                        if (cell) neighbors.push(cell.colorId);
                      }
                    }
                  }

                  // Utiliser la couleur dominante ou la première couleur disponible
                  if (neighbors.length > 0) {
                    const colorCounts = {};
                    neighbors.forEach(c => colorCounts[c] = (colorCounts[c] || 0) + 1);
                    const dominantColor = Object.entries(colorCounts).sort((a, b) => b[1] - a[1])[0][0];
                    importedPattern.symbolGrid[row][col] = { colorId: dominantColor, done: false };
                  } else {
                    // Dernier recours: première couleur
                    importedPattern.symbolGrid[row][col] = { colorId: 'color-0', done: false };
                  }
                }
              }
            }
          }

          // Appliquer la conversion DMC
          const processedPattern = applyDMCConversionToPattern(importedPattern);
          
          // Ajuster la grille
          const requiredCols = Math.max(gridConfig.nb_colonnes, processedPattern.width * 2);
          const requiredRows = Math.max(gridConfig.nb_lignes, processedPattern.height * 2);
          const offsetCol = Math.floor((requiredCols - processedPattern.width) / 2);
          const offsetRow = Math.floor((requiredRows - processedPattern.height) / 2);
          
          setGridConfig(prev => ({
            ...prev,
            name: 'Motif importé',
            nb_colonnes: requiredCols,
            nb_lignes: requiredRows
          }));
          
          setPattern({
            width: processedPattern.width,
            height: processedPattern.height,
            sourceImage: processedPattern.sourceImage,
            colorPalette: processedPattern.colorPalette,
            symbolGrid: processedPattern.symbolGrid,
            offsetCol,
            offsetRow,
            stitchTypes: config.stitchTypes,
            mode: config.mode
          });
          
          setHasImportedVisual(true);
          setShowPatternImage(true); // FORCE: Visuel visible par défaut
          setShowSymbols(true); // FORCE: Symboles visibles

          setTimeout(() => centerOnPattern(processedPattern.width, processedPattern.height, offsetCol, offsetRow), 100);

          toast.success('Grille générée avec succès ! ✓ Zéro case vide');
        };
        img.src = e.target.result;
      };
      reader.readAsDataURL(config.file);
    } catch (error) {
      console.error('Erreur import:', error);
      toast.error('Erreur lors de la génération de la grille');
    }
  };

  const handleAdvancedPreparationApply = async (config) => {
    toast.info('Application des réglages avancés...');
    
    // TODO: Implémenter la logique de préparation avancée
    // - Appliquer les types de points
    // - Fusionner les couleurs proches
    // - Supprimer les couleurs parasites
    // - Convertir en DMC
    // - Remplir les zones vides
    
    setShowAdvancedPreparationPanel(false);
    toast.success('Réglages appliqués avec succès !');
  };

  const handleImportConfirm = async (config) => {
    setShowImportDialog(false);
    setHasImportedVisual(false);
    toast.info('Génération de la grille en cours...');
    
    try {
      const { applyDMCConversionToPattern } = await import('./dmcConversion');
      
      const reader = new FileReader();
      reader.onload = async (e) => {
        const img = new Image();
        img.onload = async () => {
          const canvas = document.createElement('canvas');
          const targetWidth = config.width;
          const targetHeight = config.height;
          
          canvas.width = targetWidth;
          canvas.height = targetHeight;
          
          const ctx = canvas.getContext('2d');
          ctx.imageSmoothingEnabled = false;
          ctx.drawImage(img, 0, 0, targetWidth, targetHeight);
          
          const imageData = ctx.getImageData(0, 0, targetWidth, targetHeight);
          const sourceImage = canvas.toDataURL();
          
          // Extraction des couleurs
          const colorMap = new Map();
          for (let i = 0; i < imageData.data.length; i += 4) {
            const r = imageData.data[i];
            const g = imageData.data[i + 1];
            const b = imageData.data[i + 2];
            const a = imageData.data[i + 3];
            
            if (a < 128) continue;
            
            const key = `${Math.round(r / 10) * 10},${Math.round(g / 10) * 10},${Math.round(b / 10) * 10}`;
            colorMap.set(key, (colorMap.get(key) || 0) + 1);
          }
          
          const sortedColors = Array.from(colorMap.entries())
            .sort((a, b) => b[1] - a[1])
            .slice(0, config.colorsCount);
          
          // Construire le pattern
          const importedPattern = {
            width: targetWidth,
            height: targetHeight,
            sourceImage,
            colorPalette: sortedColors.map(([rgb, count], idx) => {
              const [r, g, b] = rgb.split(',').map(Number);
              return {
                id: `color-${idx}`,
                hex: `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`,
                name: `Couleur ${idx + 1}`,
                count,
                totalCount: count,
                doneCount: 0,
                progress: 0,
                assignedSymbolId: `symbol-${idx}`,
                assignedSymbolChar: ['●', '✕', '▲', '■', '◆', '○', '▼', '◀', '▶', '★'][idx % 10]
              };
            }),
            symbolGrid: []
          };
          
          // Générer la grille de symboles
          for (let row = 0; row < targetHeight; row++) {
            const rowData = [];
            for (let col = 0; col < targetWidth; col++) {
              const idx = (row * targetWidth + col) * 4;
              const r = imageData.data[idx];
              const g = imageData.data[idx + 1];
              const b = imageData.data[idx + 2];
              const a = imageData.data[idx + 3];
              
              if (a < 128) {
                rowData.push(null);
                continue;
              }
              
              const key = `${Math.round(r / 10) * 10},${Math.round(g / 10) * 10},${Math.round(b / 10) * 10}`;
              const colorIndex = sortedColors.findIndex(([k]) => k === key);
              
              if (colorIndex >= 0) {
                rowData.push({
                  colorId: `color-${colorIndex}`,
                  done: false
                });
              } else {
                rowData.push(null);
              }
            }
            importedPattern.symbolGrid.push(rowData);
          }
          
          // Appliquer la conversion DMC
          const processedPattern = applyDMCConversionToPattern(importedPattern);
          
          // Ajuster la grille
          const requiredCols = Math.max(gridConfig.nb_colonnes, processedPattern.width * 2);
          const requiredRows = Math.max(gridConfig.nb_lignes, processedPattern.height * 2);
          const offsetCol = Math.floor((requiredCols - processedPattern.width) / 2);
          const offsetRow = Math.floor((requiredRows - processedPattern.height) / 2);
          
          setGridConfig(prev => ({
            ...prev,
            name: 'Motif importé',
            nb_colonnes: requiredCols,
            nb_lignes: requiredRows
          }));
          
          setPattern({
            width: processedPattern.width,
            height: processedPattern.height,
            sourceImage: processedPattern.sourceImage,
            colorPalette: processedPattern.colorPalette,
            symbolGrid: processedPattern.symbolGrid,
            offsetCol,
            offsetRow
          });
          
          setHasImportedVisual(true);
          setShowPatternImage(true);
          setCurrentTool('cross'); // Mode Point par défaut après import
          
          setTimeout(() => centerOnPattern(processedPattern.width, processedPattern.height, offsetCol, offsetRow), 100);
          
          toast.success('Grille générée avec succès !');
        };
        img.src = e.target.result;
      };
      reader.readAsDataURL(config.file);
    } catch (error) {
      console.error('Erreur import:', error);
      toast.error('Erreur lors de la génération de la grille');
    }
  };

  const centerOnPattern = (patternWidth, patternHeight, offsetCol = 0, offsetRow = 0, initialZoom = null) => {
    const canvasContainer = document.getElementById('simple-canvas-container');
    if (!canvasContainer) return;

    const containerWidth = canvasContainer.offsetWidth;
    const containerHeight = canvasContainer.offsetHeight;

    let optimalZoom;
    
    // Utiliser le zoom initial fourni par SmartImportV3 si disponible
    if (initialZoom) {
      optimalZoom = initialZoom;
    } else {
      // Zoom intelligent basé sur la taille de la grille
      const maxDim = Math.max(patternWidth, patternHeight);
      
      if (maxDim < 250) {
        optimalZoom = 0.9; // Grilles petites : 90%
      } else if (maxDim <= 400) {
        optimalZoom = 0.75; // Grilles moyennes : 75%
      } else {
        optimalZoom = 0.6; // Grandes grilles : 60%
      }
      
      // S'assurer que les cases restent visibles (minimum 8px par case)
      const minCaseSize = 8;
      const minZoom = minCaseSize / gridConfig.taille_case;
      optimalZoom = Math.max(optimalZoom, minZoom);
    }

    // Calculer les dimensions de la grille = dimensions du pattern (pas de marge autour)
    const patternPixelWidth = patternWidth * gridConfig.taille_case * optimalZoom;
    const patternPixelHeight = patternHeight * gridConfig.taille_case * optimalZoom;

    // Centrer exactement sur le pattern
    const offsetX = (containerWidth - patternPixelWidth) / 2;
    const offsetY = (containerHeight - patternPixelHeight) / 2;

    setGridConfig(prev => ({
      ...prev,
      // Ajuster les dimensions de la grille pour correspondre exactement au pattern
      nb_colonnes: patternWidth,
      nb_lignes: patternHeight,
      zoom: optimalZoom,
      offset_x: offsetX,
      offset_y: offsetY
    }));
  };



  const handleMinimapNavigate = (gridX, gridY) => {
    const gridPixelWidth = gridConfig.nb_colonnes * gridConfig.taille_case * gridConfig.zoom;
    const gridPixelHeight = gridConfig.nb_lignes * gridConfig.taille_case * gridConfig.zoom;
    
    setGridConfig(prev => ({
      ...prev,
      offset_x: canvasSize.width / 2 - gridX * gridConfig.zoom,
      offset_y: canvasSize.height / 2 - gridY * gridConfig.zoom
    }));
  };

  const handleMinimapZoomToArea = (area) => {
    const canvasContainer = document.getElementById('simple-canvas-container');
    if (!canvasContainer) return;

    const containerWidth = canvasContainer.offsetWidth;
    const containerHeight = canvasContainer.offsetHeight;

    // Calculer le zoom nécessaire pour afficher la zone
    const zoomX = (containerWidth * 0.9) / area.width;
    const zoomY = (containerHeight * 0.9) / area.height;
    const optimalZoom = Math.min(zoomX, zoomY, 5);

    // Centrer sur la zone
    const centerX = area.x + area.width / 2;
    const centerY = area.y + area.height / 2;

    setGridConfig(prev => ({
      ...prev,
      zoom: optimalZoom,
      offset_x: containerWidth / 2 - centerX * optimalZoom,
      offset_y: containerHeight / 2 - centerY * optimalZoom
    }));
  };

  const handleZoomIn = () => {
    const canvasContainer = document.getElementById('simple-canvas-container');
    if (canvasContainer) {
      const containerWidth = canvasContainer.offsetWidth;
      const containerHeight = canvasContainer.offsetHeight;

      setGridConfig(prev => {
        const oldZoom = prev.zoom;
        const newZoom = Math.min(oldZoom * 1.2, 5);
        const tailleCase = prev.taille_case;

        // Centre actuel du viewport en coordonnées grille
        const viewportCenterX = (containerWidth / 2 - prev.offset_x) / (tailleCase * oldZoom);
        const viewportCenterY = (containerHeight / 2 - prev.offset_y) / (tailleCase * oldZoom);

        // Nouveaux offsets pour garder le centre
        const newOffsetX = containerWidth / 2 - viewportCenterX * tailleCase * newZoom;
        const newOffsetY = containerHeight / 2 - viewportCenterY * tailleCase * newZoom;

        return {
          ...prev,
          zoom: newZoom,
          offset_x: newOffsetX,
          offset_y: newOffsetY
        };
      });
    }
  };

  const handleZoomOut = () => {
    const canvasContainer = document.getElementById('simple-canvas-container');
    if (canvasContainer) {
      const containerWidth = canvasContainer.offsetWidth;
      const containerHeight = canvasContainer.offsetHeight;

      setGridConfig(prev => {
        const oldZoom = prev.zoom;
        const newZoom = Math.max(oldZoom / 1.2, 0.1);
        const tailleCase = prev.taille_case;

        // Centre actuel du viewport en coordonnées grille
        const viewportCenterX = (containerWidth / 2 - prev.offset_x) / (tailleCase * oldZoom);
        const viewportCenterY = (containerHeight / 2 - prev.offset_y) / (tailleCase * oldZoom);

        // Nouveaux offsets pour garder le centre
        const newOffsetX = containerWidth / 2 - viewportCenterX * tailleCase * newZoom;
        const newOffsetY = containerHeight / 2 - viewportCenterY * tailleCase * newZoom;

        return {
          ...prev,
          zoom: newZoom,
          offset_x: newOffsetX,
          offset_y: newOffsetY
        };
      });
    }
  };

  const handleResetView = () => {
    setGridConfig(prev => ({
      ...prev,
      zoom: 1.0
    }));
    setTimeout(() => centerView(), 50);
  };

  const resetGridStateToDefault = () => {
    // Réinitialiser la grille à l'état par défaut
    setGridConfig({
      name: 'Nouvelle grille',
      nb_colonnes: 300,
      nb_lignes: 300,
      taille_case: 25,
      zoom: 1.0,
      offset_x: 0,
      offset_y: 0,
      stitches: []
    });

    // Supprimer le visuel importé
    setPattern(null);
    setHasImportedVisual(false);
    setShowPatternImage(true);

    // Réinitialiser l'ID du projet actuel
    setCurrentProjectId(null);

    // Réinitialiser les sélections
    setSelectedColorId(null);
    setCurrentTool('pan');

    // Réinitialiser les options d'affichage
    setShowGrid(true);
    setShowSymbols(true);
    setShowCenterMarker(true);
    setShow10x10(true);
    setShowFloatingMiniMap(false);

    // Recentrer la vue
    setTimeout(() => centerView(), 100);
  };

  const handleCreateNewGrid = () => {
    resetGridStateToDefault();
    setShowImageImportPro(true);
  };

  const handleCloseProject = () => {
    resetGridStateToDefault();
  };

  // Sauvegarder l'état dans l'historique
  const saveToHistory = () => {
    const state = {
      pattern: pattern ? JSON.parse(JSON.stringify(pattern)) : null,
      gridConfig: JSON.parse(JSON.stringify(gridConfig)),
      timestamp: Date.now()
    };
    
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push(state);
    
    // Limiter l'historique à 50 états
    if (newHistory.length > 50) {
      newHistory.shift();
    } else {
      setHistoryIndex(prev => prev + 1);
    }
    
    setHistory(newHistory);
  };

  // Annuler
  const handleUndo = () => {
    if (historyIndex > 0) {
      const prevState = history[historyIndex - 1];
      setPattern(prevState.pattern);
      setGridConfig(prevState.gridConfig);
      setHistoryIndex(prev => prev - 1);
      toast.success('Action annulée');
    } else {
      toast.info('Aucune action à annuler');
    }
  };

  // Rétablir
  const handleRedo = () => {
    if (historyIndex < history.length - 1) {
      const nextState = history[historyIndex + 1];
      setPattern(nextState.pattern);
      setGridConfig(nextState.gridConfig);
      setHistoryIndex(prev => prev + 1);
      toast.success('Action rétablie');
    } else {
      toast.info('Aucune action à rétablir');
    }
  };

  const handleToolSelect = (tool) => {
    // Vérifier si on essaie d'utiliser certains outils sans motif
    if ((tool === 'selection-ia' || tool === 'cross' || tool === 'erase' || tool === 'symbol-picker') && !pattern) {
      toast.info('Importe d\'abord un motif pour utiliser cet outil.');
      return;
    }
    
    // Désactiver la sélection si on change d'outil
    if (tool !== 'selection-ia') {
      setSelectedCells([]);
      setSelectionRect(null);
    }
    
    // Pour l'outil Crayon, vérifier si une couleur est sélectionnée
    if ((tool === 'cross' || tool === 'pencil') && !selectedColorId && pattern) {
      toast.info('Choisissez une couleur avant de dessiner.');
      setShowBottomPalette(true);
    }
    
    // Pour les outils, activer le mode correspondant
    setCurrentTool(tool === 'pencil' ? 'cross' : tool);
  };

  // Flash animation pour feedback visuel
  const triggerFlash = (col, row, color = '#FFC94A') => {
    setFlashCell({ col, row, color });
    setTimeout(() => setFlashCell(null), 150);
  };

  // Navigation GPS vers une zone
  const handleNavigateToZone = (gpsInput) => {
    const coords = parseGPSCoordinate(gpsInput);
    if (!coords) {
      toast.error('Format invalide. Utilisez une lettre + un chiffre (ex: D8)');
      return;
    }

    const canvasContainer = document.getElementById('simple-canvas-container');
    if (!canvasContainer) return;

    // Obtenir les dimensions de la zone de grille (sans les règles)
    const containerWidth = canvasContainer.offsetWidth - 40; // 40px pour règle verticale
    const containerHeight = canvasContainer.offsetHeight - 36; // 36px pour règle horizontale

    // Arrondir au bloc 10x10 le plus proche
    const blockSize = 10;
    const blockCol = Math.floor(coords.col / blockSize) * blockSize;
    const blockRow = Math.floor(coords.row / blockSize) * blockSize;

    // Calculer le centre exact du bloc 10x10
    const centerCol = blockCol + blockSize / 2;
    const centerRow = blockRow + blockSize / 2;

    // Ajouter l'offset du pattern si présent
    const patternOffsetCol = pattern?.offsetCol || 0;
    const patternOffsetRow = pattern?.offsetRow || 0;

    // Calculer le zoom optimal pour afficher une zone 10x10
    const zonePixelSize = blockSize * gridConfig.taille_case;
    const zoomX = (containerWidth * 0.7) / zonePixelSize;
    const zoomY = (containerHeight * 0.7) / zonePixelSize;
    const optimalZoom = Math.min(zoomX, zoomY, 4);

    // Centrer sur le bloc exact (avec offset du pattern)
    const targetCol = centerCol + patternOffsetCol;
    const targetRow = centerRow + patternOffsetRow;
    const centerX = targetCol * gridConfig.taille_case * optimalZoom;
    const centerY = targetRow * gridConfig.taille_case * optimalZoom;

    // Sauvegarder l'état d'affichage actuel avant navigation
    const currentShowSymbols = showSymbols;
    const currentShowPatternImage = showPatternImage;
    const currentShowGrid = showGrid;

    // S'assurer qu'au moins un mode est actif (par défaut Mix = symboles + couleurs)
    if (!currentShowSymbols && !currentShowPatternImage) {
      setShowSymbols(true);
      setShowPatternImage(true);
    }

    setGridConfig(prev => ({
      ...prev,
      zoom: optimalZoom,
      offset_x: containerWidth / 2 - centerX,
      offset_y: containerHeight / 2 - centerY
    }));

    // Surligner temporairement la zone (coordonnées exactes du bloc)
    setHighlightedZone({ 
      letter: coords.letter, 
      number: coords.number, 
      row: blockRow + patternOffsetRow, 
      col: blockCol + patternOffsetCol 
    });
    
    // Retirer le surlignage après 3 secondes
    setTimeout(() => setHighlightedZone(null), 3000);

    toast.success(`Zone ${coords.letter}${coords.number}`);
  };

  // Sélection intelligente (propagation)
  const handleSelectionPropagation = (col, row) => {
    if (!pattern) return;
    
    const offsetCol = pattern.offsetCol || 0;
    const offsetRow = pattern.offsetRow || 0;
    const localCol = col - offsetCol;
    const localRow = row - offsetRow;
    
    if (localCol < 0 || localCol >= pattern.width || localRow < 0 || localRow >= pattern.height) return;
    
    const clickedCell = pattern.symbolGrid[localRow]?.[localCol];
    if (!clickedCell) return;
    
    const targetColorId = clickedCell.colorId;
    const selected = [];
    
    // Parcourir toute la grille pour trouver les cases avec le même symbole
    for (let r = 0; r < pattern.height; r++) {
      for (let c = 0; c < pattern.width; c++) {
        const cell = pattern.symbolGrid[r]?.[c];
        if (cell && cell.colorId === targetColorId) {
          selected.push({ col: c + offsetCol, row: r + offsetRow });
        }
      }
    }
    
    setSelectedCells(selected);
    setSelectedColorId(targetColorId);
    setShowSelectionPopup(true);
    
    const color = pattern.colorPalette.find(c => c.id === targetColorId);
    toast.success(`${selected.length} case${selected.length > 1 ? 's' : ''} sélectionnée${selected.length > 1 ? 's' : ''} (${color?.name || color?.code})`);
  };

  // Pipette
  const handlePipette = (col, row) => {
    if (!pattern) return;
    
    const offsetCol = pattern.offsetCol || 0;
    const offsetRow = pattern.offsetRow || 0;
    const localCol = col - offsetCol;
    const localRow = row - offsetRow;
    
    if (localCol < 0 || localCol >= pattern.width || localRow < 0 || localRow >= pattern.height) return;
    
    const cell = pattern.symbolGrid[localRow]?.[localCol];
    
    if (!cell) {
      setSelectedColorId(null);
      toast.info('Case vide - aucune couleur sélectionnée');
      return;
    }
    
    setSelectedColorId(cell.colorId);
    setCurrentTool('cross'); // Passer en mode ajout après pipette
    
    const color = pattern.colorPalette.find(c => c.id === cell.colorId);
    toast.success(`Couleur sélectionnée : ${color?.name || color?.code}`);
  };

  // Gomme avec drag
  const handleErase = (col, row) => {
    if (!pattern) return;
    
    saveToHistory();
    
    const offsetCol = pattern.offsetCol || 0;
    const offsetRow = pattern.offsetRow || 0;
    const localCol = col - offsetCol;
    const localRow = row - offsetRow;
    
    if (localCol < 0 || localCol >= pattern.width || localRow < 0 || localRow >= pattern.height) return;
    
    setPattern(prev => {
      const newSymbolGrid = [...prev.symbolGrid];
      if (!newSymbolGrid[localRow]) return prev;
      
      const newRow = [...newSymbolGrid[localRow]];
      newRow[localCol] = null;
      newSymbolGrid[localRow] = newRow;
      
      return { ...prev, symbolGrid: newSymbolGrid };
    });
  };

  // Gestion du survol couleur depuis la palette (preview visuel)
          const handlePaletteHoverColor = (colorId) => {
            setPaletteHoverColorId(colorId);
          };

          // Gestion de l'isolation d'une couleur (centrer + isoler)
          const handleIsolateColor = (colorId) => {
            if (!pattern || !colorId) return;

            setIsolatedColorId(colorId);

            // Trouver la zone la plus dense de cette couleur
            const offsetCol = pattern.offsetCol || 0;
            const offsetRow = pattern.offsetRow || 0;
            const occurrences = [];

            for (let r = 0; r < pattern.height; r++) {
              for (let c = 0; c < pattern.width; c++) {
                const cell = pattern.symbolGrid[r]?.[c];
                if (cell && cell.colorId === colorId) {
                  occurrences.push({ col: c + offsetCol, row: r + offsetRow });
                }
              }
            }

            if (occurrences.length > 0) {
              // Calculer le centre de gravité
              const avgCol = occurrences.reduce((sum, o) => sum + o.col, 0) / occurrences.length;
              const avgRow = occurrences.reduce((sum, o) => sum + o.row, 0) / occurrences.length;

              const canvasContainer = document.getElementById('simple-canvas-container');
              if (canvasContainer) {
                const newZoom = 2;
                const centerX = avgCol * gridConfig.taille_case * newZoom;
                const centerY = avgRow * gridConfig.taille_case * newZoom;

                setGridConfig(prev => ({
                  ...prev,
                  zoom: newZoom,
                  offset_x: canvasContainer.offsetWidth / 2 - centerX,
                  offset_y: canvasContainer.offsetHeight / 2 - centerY
                }));
              }

              const color = pattern.colorPalette.find(c => c.id === colorId);
              toast.success(`Couleur "${color?.code || color?.name}" isolée • ${occurrences.length} points`);
            }
          };

          // Surligneur (marquer comme brodé)
          const handleHighlight = (col, row) => {
    if (!pattern) return;
    
    saveToHistory();
    
    const offsetCol = pattern.offsetCol || 0;
    const offsetRow = pattern.offsetRow || 0;
    const localCol = col - offsetCol;
    const localRow = row - offsetRow;
    
    if (localCol < 0 || localCol >= pattern.width || localRow < 0 || localRow >= pattern.height) return;
    
    setPattern(prev => {
      const newSymbolGrid = [...prev.symbolGrid];
      if (!newSymbolGrid[localRow]) return prev;
      
      const newRow = [...newSymbolGrid[localRow]];
      const cell = newRow[localCol];
      
      if (!cell) return prev;
      
      newRow[localCol] = { ...cell, done: !cell.done };
      newSymbolGrid[localRow] = newRow;
      
      return { ...prev, symbolGrid: newSymbolGrid };
    });
  };

  // Effacer la sélection
  const handleEraseSelection = () => {
    if (selectedCells.length === 0) {
      toast.info('Aucune sélection à effacer');
      return;
    }
    
    saveToHistory();
    
    setPattern(prev => {
      const newSymbolGrid = [...prev.symbolGrid];
      const offsetCol = prev.offsetCol || 0;
      const offsetRow = prev.offsetRow || 0;
      
      selectedCells.forEach(({ col, row }) => {
        const localCol = col - offsetCol;
        const localRow = row - offsetRow;
        
        if (localRow >= 0 && localRow < prev.height && newSymbolGrid[localRow]) {
          const newRow = [...newSymbolGrid[localRow]];
          newRow[localCol] = null;
          newSymbolGrid[localRow] = newRow;
        }
      });
      
      return { ...prev, symbolGrid: newSymbolGrid };
    });
    
    toast.success(`${selectedCells.length} case${selectedCells.length > 1 ? 's' : ''} effacée${selectedCells.length > 1 ? 's' : ''}`);
    setSelectedCells([]);
  };

  // Réparer les trous
  const handleRepairHoles = (config) => {
    if (!pattern) return;
    
    saveToHistory();
    
    setPattern(prev => {
      if (!prev?.symbolGrid) return prev;
      
      const newSymbolGrid = prev.symbolGrid.map(row => row ? [...row] : []);
      const height = newSymbolGrid.length;
      const width = newSymbolGrid[0]?.length || 0;
      let repairedCount = 0;
      
      for (let row = 0; row < height; row++) {
        if (!newSymbolGrid[row]) continue;
        for (let col = 0; col < width; col++) {
          if (!newSymbolGrid[row][col]) {
            // Vérifier si c'est un bord
            if (config.preserveBackground) {
              const isBorder = row === 0 || row === height - 1 || col === 0 || col === width - 1;
              if (isBorder) continue;
            }
            
            // Compter les voisins remplis
            const neighbors = [];
            if (row > 0 && newSymbolGrid[row - 1]?.[col]) neighbors.push(newSymbolGrid[row - 1][col]);
            if (row < height - 1 && newSymbolGrid[row + 1]?.[col]) neighbors.push(newSymbolGrid[row + 1][col]);
            if (col > 0 && newSymbolGrid[row]?.[col - 1]) neighbors.push(newSymbolGrid[row][col - 1]);
            if (col < width - 1 && newSymbolGrid[row]?.[col + 1]) neighbors.push(newSymbolGrid[row][col + 1]);
            
            // Réparer si 3+ voisins
            if (neighbors.length >= 3) {
              const colorCounts = {};
              neighbors.forEach(n => {
                if (n?.colorId) colorCounts[n.colorId] = (colorCounts[n.colorId] || 0) + 1;
              });
              const sortedColors = Object.entries(colorCounts).sort((a, b) => b[1] - a[1]);
              if (sortedColors.length > 0) {
                const dominantColor = sortedColors[0][0];
                
                if (newSymbolGrid[row]) {
                  const newRow = [...newSymbolGrid[row]];
                  newRow[col] = { colorId: dominantColor, done: false };
                  newSymbolGrid[row] = newRow;
                  repairedCount++;
                }
              }
            }
          }
        }
      }
      
      if (repairedCount > 0) {
        toast.success(`PatyBee a réparé ${repairedCount} case${repairedCount > 1 ? 's' : ''} vide${repairedCount > 1 ? 's' : ''} 🐝`);
      } else {
        toast.info('Aucun trou à réparer !');
      }
      
      return { ...prev, symbolGrid: newSymbolGrid };
    });
    
    setShowRepairDialog(false);
  };

  const handleColorSelect = (colorId) => {
    setSelectedColorId(colorId === selectedColorId ? null : colorId);
  };

  const handleMarkColorAsDone = (colorId) => {
    setPattern(prev => {
      if (!prev) return prev;
      
      const newSymbolGrid = prev.symbolGrid.map(row =>
        row.map(cell => {
          if (cell && cell.colorId === colorId) {
            return { ...cell, done: true };
          }
          return cell;
        })
      );
      
      const newColorPalette = prev.colorPalette.map(color => {
        if (color.id === colorId) {
          return {
            ...color,
            doneCount: color.totalCount,
            progress: 100
          };
        }
        return color;
      });
      
      toast.success(`Couleur "${newColorPalette.find(c => c.id === colorId)?.name}" marquée comme terminée !`);
      
      return {
        ...prev,
        symbolGrid: newSymbolGrid,
        colorPalette: newColorPalette
      };
    });
  };

  // ===== RENDER =====
  return (
    <div className="h-screen flex flex-col bg-gradient-to-br from-slate-50 to-slate-100 overflow-hidden">


      {/* BARRE OUTILS BRODERIE supprimée - les outils sont maintenant dans le TopMenu */}
      {false && <StitchToolbar
        currentTool={currentTool}
        onToolSelect={(tool) => {
          if (tool === 'pencil') setCurrentTool('cross');
          else if (tool === 'erase') setCurrentTool('erase');
          else setCurrentTool(tool);
        }}
        currentZoom={gridConfig.zoom}
        onZoomChange={(newZoom, centerOnViewport = false) => {
          if (centerOnViewport) {
            const canvasContainer = document.getElementById('simple-canvas-container');
            if (canvasContainer) {
              const containerWidth = canvasContainer.offsetWidth;
              const containerHeight = canvasContainer.offsetHeight;
              const oldZoom = gridConfig.zoom;
              const tailleCase = gridConfig.taille_case;

              // Calculer le centre actuel du viewport en coordonnées grille
              const viewportCenterX = (containerWidth / 2 - gridConfig.offset_x) / (tailleCase * oldZoom);
              const viewportCenterY = (containerHeight / 2 - gridConfig.offset_y) / (tailleCase * oldZoom);

              // Calculer les nouveaux offsets pour garder ce centre après le zoom
              const newOffsetX = containerWidth / 2 - viewportCenterX * tailleCase * newZoom;
              const newOffsetY = containerHeight / 2 - viewportCenterY * tailleCase * newZoom;

              setGridConfig(prev => ({
                ...prev,
                zoom: newZoom,
                offset_x: newOffsetX,
                offset_y: newOffsetY
              }));
            }
          } else {
            setGridConfig(prev => ({ ...prev, zoom: newZoom }));
          }
        }}
        onZoomToSelection={() => {
          if (selectedCells.length > 0) {
            // Calculer la boîte englobante de la sélection
            const cols = selectedCells.map(c => c.col);
            const rows = selectedCells.map(c => c.row);
            const minCol = Math.min(...cols);
            const maxCol = Math.max(...cols);
            const minRow = Math.min(...rows);
            const maxRow = Math.max(...rows);
            const selectionWidth = (maxCol - minCol + 1) * gridConfig.taille_case;
            const selectionHeight = (maxRow - minRow + 1) * gridConfig.taille_case;
            const canvasContainer = document.getElementById('simple-canvas-container');
            if (canvasContainer) {
              // Marge de sécurité de 10%
              const zoomX = (canvasContainer.offsetWidth * 0.9) / selectionWidth;
              const zoomY = (canvasContainer.offsetHeight * 0.9) / selectionHeight;
              const newZoom = Math.min(zoomX, zoomY, 5);
              const centerCol = minCol + (maxCol - minCol + 1) / 2;
              const centerRow = minRow + (maxRow - minRow + 1) / 2;
              const centerX = centerCol * gridConfig.taille_case * newZoom;
              const centerY = centerRow * gridConfig.taille_case * newZoom;

              setGridConfig(prev => ({
                ...prev,
                zoom: newZoom,
                offset_x: canvasContainer.offsetWidth / 2 - centerX,
                offset_y: canvasContainer.offsetHeight / 2 - centerY
              }));

              // Surlignage temporaire de la sélection
              setHighlightedZone({ 
                col: minCol, 
                row: minRow, 
                width: maxCol - minCol + 1,
                height: maxRow - minRow + 1,
                isSelection: true
              });
              setTimeout(() => setHighlightedZone(null), 1000);

              toast.success(`Zoom sur ${selectedCells.length} case${selectedCells.length > 1 ? 's' : ''} sélectionnée${selectedCells.length > 1 ? 's' : ''}`);
            }
          } else {
            toast.info('Aucune zone sélectionnée. Sélectionne une zone puis relance "Zoom sur sélection".');
          }
        }}
        onZoomToSymbol={() => {
          if (selectedColorId && pattern) {
            const offsetCol = pattern.offsetCol || 0;
            const offsetRow = pattern.offsetRow || 0;

            // Trouver toutes les occurrences de ce symbole
            const occurrences = [];
            for (let r = 0; r < pattern.height; r++) {
              for (let c = 0; c < pattern.width; c++) {
                const cell = pattern.symbolGrid[r]?.[c];
                if (cell && cell.colorId === selectedColorId) {
                  occurrences.push({ col: c + offsetCol, row: r + offsetRow });
                }
              }
            }

            if (occurrences.length > 0) {
              // Trouver la zone la plus dense (cluster de symboles)
              // Utiliser le centre de gravité des occurrences
              const avgCol = occurrences.reduce((sum, o) => sum + o.col, 0) / occurrences.length;
              const avgRow = occurrences.reduce((sum, o) => sum + o.row, 0) / occurrences.length;

              // Trouver l'occurrence la plus proche du centre
              let closest = occurrences[0];
              let minDist = Infinity;
              occurrences.forEach(o => {
                const dist = Math.sqrt(Math.pow(o.col - avgCol, 2) + Math.pow(o.row - avgRow, 2));
                if (dist < minDist) {
                  minDist = dist;
                  closest = o;
                }
              });

              const canvasContainer = document.getElementById('simple-canvas-container');
              if (canvasContainer) {
                // Zoom 200% pour bonne lisibilité
                const newZoom = 2;
                const centerX = closest.col * gridConfig.taille_case * newZoom;
                const centerY = closest.row * gridConfig.taille_case * newZoom;

                setGridConfig(prev => ({
                  ...prev,
                  zoom: newZoom,
                  offset_x: canvasContainer.offsetWidth / 2 - centerX,
                  offset_y: canvasContainer.offsetHeight / 2 - centerY
                }));

                // Surbrillance temporaire
                triggerFlash(closest.col, closest.row, '#FFC94A');

                const color = pattern.colorPalette.find(c => c.id === selectedColorId);
                toast.success(`Zoom sur "${color?.name || color?.code}" (${occurrences.length} points)`);
              }
            }
          } else {
            toast.info('Tapote un symbole dans la grille ou choisis-en un dans la palette, puis relance "Zoom sur symbole".');
          }
        }}
        onZoomAuto={() => {
          const canvasContainer = document.getElementById('simple-canvas-container');
          if (!canvasContainer) return;

          const containerWidth = canvasContainer.offsetWidth;
          const containerHeight = canvasContainer.offsetHeight;

          if (pattern) {
            const offsetCol = pattern.offsetCol || 0;
            const offsetRow = pattern.offsetRow || 0;

            // Grille petite (≤ 80x80) : afficher tout
            if (pattern.width <= 80 && pattern.height <= 80) {
              const patternPixelWidth = pattern.width * gridConfig.taille_case;
              const patternPixelHeight = pattern.height * gridConfig.taille_case;
              const zoomX = (containerWidth * 0.9) / patternPixelWidth;
              const zoomY = (containerHeight * 0.9) / patternPixelHeight;
              const newZoom = Math.min(zoomX, zoomY, 3);

              const centerX = (offsetCol + pattern.width / 2) * gridConfig.taille_case * newZoom;
              const centerY = (offsetRow + pattern.height / 2) * gridConfig.taille_case * newZoom;

              setGridConfig(prev => ({
                ...prev,
                zoom: newZoom,
                offset_x: containerWidth / 2 - centerX,
                offset_y: containerHeight / 2 - centerY
              }));
              toast.success('Zoom automatique : grille entière visible');
            } else {
              // Grille grande : afficher environ 40x40 cases
              const targetSize = 40;
              const zonePixelSize = targetSize * gridConfig.taille_case;
              const zoomX = (containerWidth * 0.9) / zonePixelSize;
              const zoomY = (containerHeight * 0.9) / zonePixelSize;
              const newZoom = Math.min(zoomX, zoomY, 2.5);

              // Centrer sur le milieu du pattern ou la dernière zone active
              const centerCol = offsetCol + pattern.width / 2;
              const centerRow = offsetRow + pattern.height / 2;
              const centerX = centerCol * gridConfig.taille_case * newZoom;
              const centerY = centerRow * gridConfig.taille_case * newZoom;

              setGridConfig(prev => ({
                ...prev,
                zoom: newZoom,
                offset_x: containerWidth / 2 - centerX,
                offset_y: containerHeight / 2 - centerY
              }));
              toast.success('Zoom automatique ajusté');
            }
          } else {
            // Pas de pattern : centrer la grille vide
            const gridPixelWidth = gridConfig.nb_colonnes * gridConfig.taille_case;
            const gridPixelHeight = gridConfig.nb_lignes * gridConfig.taille_case;
            const zoomX = (containerWidth * 0.9) / gridPixelWidth;
            const zoomY = (containerHeight * 0.9) / gridPixelHeight;
            const newZoom = Math.min(zoomX, zoomY, 1);

            setGridConfig(prev => ({
              ...prev,
              zoom: newZoom,
              offset_x: (containerWidth - gridPixelWidth * newZoom) / 2,
              offset_y: (containerHeight - gridPixelHeight * newZoom) / 2
            }));
            toast.success('Vue centrée');
          }
        }}
        onCenterView={() => {
          if (pattern) {
            centerOnPattern(pattern.width, pattern.height, pattern.offsetCol || 0, pattern.offsetRow || 0);
          } else {
            centerView();
          }
        }}
        showGrid={showGrid}
        onToggleGrid={() => setShowGrid(!showGrid)}
        showSymbols={showSymbols}
        onToggleSymbols={() => setShowSymbols(!showSymbols)}
        showImage={showPatternImage}
        onToggleImage={() => setShowPatternImage(!showPatternImage)}
        contrastMode={contrastMode}
        onContrastModeChange={() => setContrastMode(!contrastMode)}
        symbolSizeMode={symbolSizeMode}
        onSymbolSizeModeChange={(mode) => setSymbolSizeMode(mode)}
        antiFatigueMode={antiFatigueMode}
        onAntiFatigueModeChange={() => setAntiFatigueMode(!antiFatigueMode)}
        focusColorMode={focusColorMode}
        onFocusColorModeChange={() => setFocusColorMode(!focusColorMode)}
        highlightActiveMode={highlightActiveMode}
        onHighlightActiveModeChange={() => setHighlightActiveMode(!highlightActiveMode)}
        nightMode={nightMode}
        onNightModeChange={() => setNightMode(!nightMode)}
        autoCountMode={autoCountMode}
        onAutoCountModeChange={() => setAutoCountMode(!autoCountMode)}
                      onNavigateToZone={handleNavigateToZone}
                      pattern={pattern}
                      activeFilter={activeFilter}
                      onFilterByStitchType={(stitchType) => {
                        setActiveFilter({ type: 'stitch', value: stitchType });
                      }}
                      onFilterByColor={(colorId, colorName) => {
                        setActiveFilter({ type: 'color', value: colorId, label: colorName });
                        setSelectedColorId(colorId);
                      }}
                      onFilterBySymbol={(symbol, colorId) => {
                        setActiveFilter({ type: 'symbol', value: symbol, colorId });
                        setSelectedColorId(colorId);
                      }}
                      onResetFilters={() => {
                                                    setActiveFilter(null);
                                                    setIsolationMode(false);
                                                    setIsolatedColorId(null); // Réinitialiser isolation couleur palette
                                                  }}
                      isolationMode={isolationMode}
                      onToggleIsolationMode={() => setIsolationMode(!isolationMode)}
              // Filtres avancés
              showUnstitchedZones={showUnstitchedZones}
              onToggleUnstitchedZones={() => {
                const newValue = !showUnstitchedZones;
                setShowUnstitchedZones(newValue);
                if (newValue && pattern) {
                  let count = 0;
                  const cells = [];
                  for (let r = 0; r < pattern.height; r++) {
                    for (let c = 0; c < pattern.width; c++) {
                      if (!pattern.symbolGrid[r]?.[c]) {
                        count++;
                        cells.push({ row: r, col: c });
                      }
                    }
                  }
                  setAnalysisResults(prev => ({ ...prev, unstitched: count, unstitchedCells: cells }));
                  if (count > 0) toast.info(`${count} case${count > 1 ? 's' : ''} vide${count > 1 ? 's' : ''} détectée${count > 1 ? 's' : ''}`);
                }
              }}
              showPotentialErrors={showPotentialErrors}
              onTogglePotentialErrors={() => {
                const newValue = !showPotentialErrors;
                setShowPotentialErrors(newValue);
                if (newValue && pattern) {
                  const thresholds = { low: 1, medium: 2, high: 3 };
                  const threshold = thresholds[errorSensitivity];
                  const errorCells = [];
                  for (let r = 1; r < pattern.height - 1; r++) {
                    for (let c = 1; c < pattern.width - 1; c++) {
                      const cell = pattern.symbolGrid[r]?.[c];
                      if (!cell) continue;
                      const neighbors = [
                        pattern.symbolGrid[r-1]?.[c],
                        pattern.symbolGrid[r+1]?.[c],
                        pattern.symbolGrid[r]?.[c-1],
                        pattern.symbolGrid[r]?.[c+1],
                        pattern.symbolGrid[r-1]?.[c-1],
                        pattern.symbolGrid[r-1]?.[c+1],
                        pattern.symbolGrid[r+1]?.[c-1],
                        pattern.symbolGrid[r+1]?.[c+1],
                      ].filter(n => n?.colorId === cell.colorId);
                      if (neighbors.length <= threshold) {
                        const otherNeighbors = [
                          pattern.symbolGrid[r-1]?.[c],
                          pattern.symbolGrid[r+1]?.[c],
                          pattern.symbolGrid[r]?.[c-1],
                          pattern.symbolGrid[r]?.[c+1],
                        ].filter(n => n && n.colorId !== cell.colorId);
                        if (otherNeighbors.length >= 3) {
                          errorCells.push({ row: r, col: c, colorId: cell.colorId });
                        }
                      }
                    }
                  }
                  setAnalysisResults(prev => ({ ...prev, errors: errorCells.length, errorCells }));
                  if (errorCells.length > 0) toast.warning(`${errorCells.length} erreur${errorCells.length > 1 ? 's' : ''} potentielle${errorCells.length > 1 ? 's' : ''}`);
                  else toast.success('Aucune erreur potentielle détectée');
                }
              }}
              errorSensitivity={errorSensitivity}
              onErrorSensitivityChange={(level) => {
                setErrorSensitivity(level);
                if (showPotentialErrors && pattern) {
                  const thresholds = { low: 1, medium: 2, high: 3 };
                  const threshold = thresholds[level];
                  const errorCells = [];
                  for (let r = 1; r < pattern.height - 1; r++) {
                    for (let c = 1; c < pattern.width - 1; c++) {
                      const cell = pattern.symbolGrid[r]?.[c];
                      if (!cell) continue;
                      const neighbors = [
                        pattern.symbolGrid[r-1]?.[c],
                        pattern.symbolGrid[r+1]?.[c],
                        pattern.symbolGrid[r]?.[c-1],
                        pattern.symbolGrid[r]?.[c+1],
                        pattern.symbolGrid[r-1]?.[c-1],
                        pattern.symbolGrid[r-1]?.[c+1],
                        pattern.symbolGrid[r+1]?.[c-1],
                        pattern.symbolGrid[r+1]?.[c+1],
                      ].filter(n => n?.colorId === cell.colorId);
                      if (neighbors.length <= threshold) {
                        const otherNeighbors = [
                          pattern.symbolGrid[r-1]?.[c],
                          pattern.symbolGrid[r+1]?.[c],
                          pattern.symbolGrid[r]?.[c-1],
                          pattern.symbolGrid[r]?.[c+1],
                        ].filter(n => n && n.colorId !== cell.colorId);
                        if (otherNeighbors.length >= 3) {
                          errorCells.push({ row: r, col: c, colorId: cell.colorId });
                        }
                      }
                    }
                  }
                  setAnalysisResults(prev => ({ ...prev, errors: errorCells.length, errorCells }));
                }
              }}
              showMissingPoints={showMissingPoints}
              onToggleMissingPoints={() => {
                const newValue = !showMissingPoints;
                setShowMissingPoints(newValue);
                if (newValue && pattern) {
                  let missingCount = 0;
                  const missingCells = [];
                  for (let r = 0; r < pattern.height; r++) {
                    for (let c = 0; c < pattern.width; c++) {
                      const cell = pattern.symbolGrid[r]?.[c];
                      if (cell && !cell.done) {
                        missingCount++;
                        missingCells.push({ row: r, col: c, colorId: cell.colorId });
                      }
                    }
                  }
                  setAnalysisResults(prev => ({ ...prev, missing: missingCount, missingCells }));
                  toast.info(`${missingCount} point${missingCount > 1 ? 's' : ''} restant${missingCount > 1 ? 's' : ''} à broder`);
                }
              }}
              unstitchedCount={analysisResults.unstitched}
              potentialErrorsCount={analysisResults.errors}
              missingPointsCount={analysisResults.missing}
        onOpenIA={() => {
          const event = new CustomEvent('togglePatyBee');
          window.dispatchEvent(event);
        }}
        onImport={() => setShowSmartImportV3(true)}
        onExport={() => setShowSubExportModule(true)}
        onSave={handleSaveProject}
        onOpenDashboard={() => setShowDashboardModal(true)}
        currentPencilSubTool={currentPencilSubTool}
        onPencilSubToolSelect={setCurrentPencilSubTool}
        currentEraserSubTool={currentEraserSubTool}
        onEraserSubToolSelect={setCurrentEraserSubTool}
        currentSelectionSubTool={currentSelectionSubTool}
        onSelectionSubToolSelect={setCurrentSelectionSubTool}
        currentHandSubTool={currentHandSubTool}
        onHandSubToolSelect={setCurrentHandSubTool}
        hasPattern={!!pattern}
                    showMiniMap={false}
                    onToggleMiniMap={() => {}}
                  />
        }

                  {/* Ancienne barre d'outils complètement supprimée */}
        {false && <div style={{display:'none'}}>
        <TooltipProvider>
          <div className="flex items-center gap-2.5 justify-between">
            {/* GROUPE 1 : OUTILS DE BASE */}
            <div className="flex items-center gap-2.5">
              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => handleToolSelect('selection-ia')}
                    className={`w-12 h-12 rounded-md flex items-center justify-center transition-colors ${
                      currentTool === 'selection-ia' ? 'bg-black text-white' : 'bg-[#F5F5F5] hover:bg-[#E5E5E5] text-black'
                    }`}
                  >
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M9 9l-3 3 3 3M15 9l3 3-3 3M12 3v18M3 12h18" />
                    </svg>
                  </button>
                </TooltipTrigger>
                <TooltipContent><p>Sélection intelligente (propagation)</p></TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => handleToolSelect('symbol-picker')}
                    className={`w-12 h-12 rounded-md flex items-center justify-center transition-colors ${
                      currentTool === 'symbol-picker' ? 'bg-black text-white' : 'bg-[#F5F5F5] hover:bg-[#E5E5E5] text-black'
                    }`}
                  >
                    <Pipette className="w-5 h-5" strokeWidth={2} />
                  </button>
                </TooltipTrigger>
                <TooltipContent><p>Pipette (couleur + symbole)</p></TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => handleToolSelect('cross')}
                    className={`w-12 h-12 rounded-md flex items-center justify-center transition-colors ${
                      currentTool === 'cross' ? 'bg-black text-white' : 'bg-[#F5F5F5] hover:bg-[#E5E5E5] text-black'
                    }`}
                  >
                    <Plus className="w-5 h-5" strokeWidth={2} />
                  </button>
                </TooltipTrigger>
                <TooltipContent><p>Ajouter un symbole</p></TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => handleToolSelect('erase')}
                    className={`w-12 h-12 rounded-md flex items-center justify-center transition-colors ${
                      currentTool === 'erase' ? 'bg-black text-white' : 'bg-[#F5F5F5] hover:bg-[#E5E5E5] text-black'
                    }`}
                  >
                    <Eraser className="w-5 h-5" strokeWidth={2} />
                  </button>
                </TooltipTrigger>
                <TooltipContent><p>Gomme</p></TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => handleToolSelect('highlight')}
                    className={`w-12 h-12 rounded-md flex items-center justify-center transition-colors ${
                      currentTool === 'highlight' ? 'bg-black text-white' : 'bg-[#F5F5F5] hover:bg-[#E5E5E5] text-black'
                    }`}
                  >
                    <Highlighter className="w-5 h-5" strokeWidth={2} />
                  </button>
                </TooltipTrigger>
                <TooltipContent><p>Surligneur (marquer comme brodé)</p></TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => toast.info('Remplacer un symbole : fonctionnalité à venir')}
                    className="w-12 h-12 rounded-md flex items-center justify-center transition-colors bg-[#F5F5F5] hover:bg-[#E5E5E5] text-black"
                  >
                    <ArrowLeftRight className="w-5 h-5" strokeWidth={2} />
                  </button>
                </TooltipTrigger>
                <TooltipContent><p>Remplacer un symbole</p></TooltipContent>
              </Tooltip>
            </div>

            <div className="w-px h-8 bg-gray-300" />

            {/* GROUPE 2 : OUTILS IA */}
            <div className="flex items-center gap-2.5">
              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => setShowSubRepairDialog(true)}
                    disabled={!pattern}
                    className={pattern 
                      ? "w-12 h-12 rounded-md flex items-center justify-center transition-colors bg-gradient-to-br from-yellow-100 to-yellow-200 hover:from-yellow-200 hover:to-yellow-300 text-black border border-yellow-400" 
                      : "w-12 h-12 rounded-md flex items-center justify-center transition-colors bg-[#F5F5F5] text-gray-400 cursor-not-allowed opacity-40"
                    }
                  >
                    <Sparkles className="w-5 h-5" strokeWidth={2} />
                  </button>
                </TooltipTrigger>
                <TooltipContent><p>Réparation Auto SUB™ (0 trou garanti)</p></TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => setShowSubStitchPicker(true)}
                    disabled={!pattern}
                    className={pattern 
                      ? "w-12 h-12 rounded-md flex items-center justify-center transition-colors bg-[#F5F5F5] hover:bg-[#E5E5E5] text-black" 
                      : "w-12 h-12 rounded-md flex items-center justify-center transition-colors bg-[#F5F5F5] text-gray-400 cursor-not-allowed opacity-40"
                    }
                  >
                    <span className="text-lg font-bold">S</span>
                  </button>
                </TooltipTrigger>
                <TooltipContent><p>Points SUB™ (12 types modernes)</p></TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => setShowSubBeforeAfterDialog(true)}
                    disabled={!pattern}
                    className={pattern 
                      ? "w-12 h-12 rounded-md flex items-center justify-center transition-colors bg-[#F5F5F5] hover:bg-[#E5E5E5] text-black" 
                      : "w-12 h-12 rounded-md flex items-center justify-center transition-colors bg-[#F5F5F5] text-gray-400 cursor-not-allowed opacity-40"
                    }
                  >
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <line x1="12" y1="2" x2="12" y2="22" />
                      <path d="M4 12h4M16 12h4" />
                    </svg>
                  </button>
                </TooltipTrigger>
                <TooltipContent><p>Mode Avant/Après SUB™</p></TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => setShowSubQuickGuide(true)}
                    className="w-12 h-12 rounded-md flex items-center justify-center transition-colors bg-gradient-to-br from-yellow-100 to-orange-100 hover:from-yellow-200 hover:to-orange-200 text-yellow-700 border border-yellow-300"
                  >
                    <span className="text-xs font-black">SUB</span>
                  </button>
                </TooltipTrigger>
                <TooltipContent><p>Guide rapide SUB™</p></TooltipContent>
              </Tooltip>
            </div>

            <div className="w-px h-8 bg-gray-300" />

            {/* GROUPE 3 : OUTILS DE NAVIGATION */}
            <div className="flex items-center gap-2.5">
              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => handleToolSelect('pan')}
                    className={`w-12 h-12 rounded-md flex items-center justify-center transition-colors ${
                      currentTool === 'pan' ? 'bg-black text-white' : 'bg-[#F5F5F5] hover:bg-[#E5E5E5] text-black'
                    }`}
                  >
                    <Hand className="w-5 h-5" strokeWidth={2} />
                  </button>
                </TooltipTrigger>
                <TooltipContent><p>Déplacement</p></TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={handleUndo}
                    disabled={historyIndex <= 0}
                    className={`w-12 h-12 rounded-md flex items-center justify-center transition-colors ${
                      historyIndex > 0 
                        ? 'bg-[#F5F5F5] hover:bg-[#E5E5E5] text-black' 
                        : 'bg-[#F5F5F5] text-gray-400 cursor-not-allowed'
                    }`}
                  >
                    <Undo className="w-5 h-5" strokeWidth={2} />
                  </button>
                </TooltipTrigger>
                <TooltipContent><p>Annuler {historyIndex > 0 ? `(${historyIndex} action${historyIndex > 1 ? 's' : ''})` : ''}</p></TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={handleRedo}
                    disabled={historyIndex >= history.length - 1}
                    className={`w-12 h-12 rounded-md flex items-center justify-center transition-colors ${
                      historyIndex < history.length - 1
                        ? 'bg-[#F5F5F5] hover:bg-[#E5E5E5] text-black' 
                        : 'bg-[#F5F5F5] text-gray-400 cursor-not-allowed'
                    }`}
                  >
                    <Redo className="w-5 h-5" strokeWidth={2} />
                  </button>
                </TooltipTrigger>
                <TooltipContent><p>Rétablir {historyIndex < history.length - 1 ? `(${history.length - 1 - historyIndex} action${history.length - 1 - historyIndex > 1 ? 's' : ''})` : ''}</p></TooltipContent>
              </Tooltip>
            </div>

            <div className="w-px h-8 bg-gray-300" />

            {/* GROUPE 4 : ZOOMS */}
            <div className="flex items-center gap-2.5">
              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={handleZoomIn}
                    className="w-12 h-12 rounded-md flex items-center justify-center transition-colors bg-[#F5F5F5] hover:bg-[#E5E5E5] text-black"
                  >
                    <ZoomIn className="w-5 h-5" strokeWidth={2} />
                  </button>
                </TooltipTrigger>
                <TooltipContent><p>Zoom +</p></TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={handleZoomOut}
                    className="w-12 h-12 rounded-md flex items-center justify-center transition-colors bg-[#F5F5F5] hover:bg-[#E5E5E5] text-black"
                  >
                    <ZoomOut className="w-5 h-5" strokeWidth={2} />
                  </button>
                </TooltipTrigger>
                <TooltipContent><p>Zoom -</p></TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={handleResetView}
                    className="w-12 h-12 rounded-md flex items-center justify-center transition-colors bg-[#F5F5F5] hover:bg-[#E5E5E5] text-black"
                  >
                    <Maximize2 className="w-5 h-5" strokeWidth={2} />
                  </button>
                </TooltipTrigger>
                <TooltipContent><p>Vue globale</p></TooltipContent>
              </Tooltip>
            </div>

            <div className="w-px h-8 bg-gray-300" />

            {/* GROUPE 5 : VISUEL / MINI-CARTE */}
            <div className="flex items-center gap-2.5">
              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => setShowPatternImage(!showPatternImage)}
                    disabled={!hasImportedVisual}
                    className={`w-12 h-12 rounded-md flex items-center justify-center transition-colors ${
                      showPatternImage && hasImportedVisual
                        ? 'bg-black text-white'
                        : 'bg-[#F5F5F5] hover:bg-[#E5E5E5] text-black'
                    } ${!hasImportedVisual ? 'opacity-40 cursor-not-allowed' : ''}`}
                  >
                    <ImageIcon className="w-5 h-5" strokeWidth={2} />
                  </button>
                </TooltipTrigger>
                <TooltipContent><p>Afficher / Masquer le visuel</p></TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => setShowSmartMap(!showSmartMap)}
                    className={`w-12 h-12 rounded-md flex items-center justify-center transition-colors ${
                      showSmartMap ? 'bg-black text-white' : 'bg-[#F5F5F5] hover:bg-[#E5E5E5] text-black'
                    }`}
                  >
                    <MapIcon className="w-5 h-5" strokeWidth={2} />
                  </button>
                </TooltipTrigger>
                <TooltipContent><p>Mini-carte Smart AI</p></TooltipContent>
                </Tooltip>
                </div>

                {/* BOUTONS À DROITE */}
                <div className="flex items-center gap-2.5 ml-auto">
                {/* Bouton PatyBee IA - Alvéole hexagonale */}
                <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => {
                      const event = new CustomEvent('togglePatyBee');
                      window.dispatchEvent(event);
                    }}
                    className="relative flex items-center justify-center transition-all group"
                    style={{ 
                      width: '48px',
                      height: '48px',
                      clipPath: 'polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)',
                      backgroundColor: '#F5C200',
                      border: '1px solid rgba(0,0,0,0.2)'
                    }}
                  >
                    <div className="transform group-hover:scale-105 transition-all">
                      <div className="relative w-7 h-7 rounded-lg bg-black group-hover:bg-gray-800 transition-colors flex items-center justify-center">
                        <span className="text-white font-bold text-xs tracking-tight">IA</span>
                        <div 
                          className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-full w-0 h-0"
                          style={{
                            borderLeft: '4px solid transparent',
                            borderRight: '4px solid transparent',
                            borderTop: '4px solid black'
                          }}
                        />
                      </div>
                    </div>
                  </button>
                </TooltipTrigger>
                <TooltipContent><p>Ouvrir la conversation avec PatyBee IA</p></TooltipContent>
                </Tooltip>

                {/* Bouton Fermer carré */}
                {pattern && (
                <Tooltip>
                  <TooltipTrigger asChild>
                    <button
                      onClick={handleCloseProject}
                      className="w-12 h-12 rounded-md flex items-center justify-center transition-colors bg-[#F5F5F5] hover:bg-red-500 hover:text-white text-black"
                    >
                      <X className="w-5 h-5" strokeWidth={2} />
                    </button>
                  </TooltipTrigger>
                  <TooltipContent><p>Fermer le projet</p></TooltipContent>
                </Tooltip>
                )}
                </div>
                </div>
                </TooltipProvider>
                </div>}

                {/* Main content - Zone scrollable (Header 70px seulement maintenant) */}
                <div className="flex-1 flex flex-col overflow-hidden min-h-0" style={{ marginTop: '0px' }}>

  

                  {/* Canvas central - ZONE PRINCIPALE */}
                  <main 
                    className="flex-1 overflow-hidden relative" 
                    id="simple-canvas-container" 
                    style={{ paddingBottom: showBottomPalette && pattern ? '100px' : '0' }}
                  >
                    {/* Écran d'accueil si aucun projet */}
                    {!pattern && (
                      <WelcomeHome
                        onOpenProjects={() => setShowProjectsModal(true)}
                        onImport={() => setShowSmartImportV3(true)}
                      />
                    )}

                    {/* Zone de grille - visible uniquement si un pattern est chargé */}
                    {pattern && (
                      <div className="absolute inset-0 bg-white overflow-hidden">

              {/* Surlignage de zone GPS temporaire */}
              {highlightedZone && (
                <div
                  className="absolute pointer-events-none z-20 transition-opacity duration-500"
                  style={{
                    left: `${gridConfig.offset_x + highlightedZone.col * gridConfig.taille_case * gridConfig.zoom}px`,
                    top: `${gridConfig.offset_y + highlightedZone.row * gridConfig.taille_case * gridConfig.zoom}px`,
                    width: `${10 * gridConfig.taille_case * gridConfig.zoom}px`,
                    height: `${10 * gridConfig.taille_case * gridConfig.zoom}px`,
                    border: nightMode ? '3px solid #FFD700' : '3px solid #3B82F6',
                    backgroundColor: nightMode ? 'rgba(255, 215, 0, 0.15)' : 'rgba(59, 130, 246, 0.15)',
                    borderRadius: '4px',
                    animation: 'pulse 1s ease-in-out infinite'
                  }}
                />
              )}

              {/* Bouton fermer en haut à droite */}
              {pattern && (
                <button
                  onClick={handleCloseProject}
                  style={{
                    position: 'absolute',
                    right: '16px',
                    top: '16px',
                    width: '34px',
                    height: '34px',
                    background: '#fff',
                    borderRadius: '6px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    cursor: 'pointer',
                    border: '1px solid rgba(0, 0, 0, 0.1)',
                    zIndex: 40,
                    transition: 'all 0.2s'
                  }}
                  onMouseEnter={(e) => e.currentTarget.style.background = '#f0f0f0'}
                  onMouseLeave={(e) => e.currentTarget.style.background = '#fff'}
                >
                  <X className="w-5 h-5 text-black" strokeWidth={2} />
                </button>
              )}
            {/* Affichage SUB Engine */}
            <SubDisplayEngine
              pattern={pattern}
              gridConfig={gridConfig}
              onGridConfigChange={setGridConfig}
            >

            
            <GridCanvas
              nbColonnes={gridConfig.nb_colonnes}
              nbLignes={gridConfig.nb_lignes}
              tailleCase={gridConfig.taille_case}
              zoom={gridConfig.zoom}
              offsetX={gridConfig.offset_x}
              offsetY={gridConfig.offset_y}
              repere10x10={show10x10}
              numerotation10x10={true}
              repereCentral={showCenterMarker}
              stitches={gridConfig.stitches}
              showGrid={showGrid}
              showSymbols={showSymbols}
              showPattern={true}
              currentTool={currentTool}
              patternSourceImage={pattern?.sourceImage}
              patternWidth={pattern?.width}
              patternHeight={pattern?.height}
              patternColorPalette={pattern?.colorPalette}
              patternSymbolGrid={pattern?.symbolGrid}
              showPatternImage={showPatternImage}
              showPatternSymbols={showSymbols}
              selectedColorId={selectedColorId}
              selectedSymbolId={null}
              pattern={pattern}
              onPan={handlePan}
              onHoverCell={(col, row) => setHoverCell({ col, row })}
              onSymbolPick={(colorId) => {
                setSelectedColorId(colorId);
                if (colorId) {
                  setCurrentTool('cross');
                  toast.success('Couleur sélectionnée ! Outil Point activé.');
                }
              }}
              onStitchAdd={(col, row, color) => {
                if (!pattern) return;

                // Vérifier qu'une couleur est sélectionnée
                if (!selectedColorId) {
                  toast.info('Choisissez une couleur avant de dessiner.');
                  setShowBottomPalette(true);
                  return;
                }

                saveToHistory();

                const offsetCol = pattern.offsetCol || 0;
                const offsetRow = pattern.offsetRow || 0;

                const localCol = col - offsetCol;
                const localRow = row - offsetRow;

                if (localCol >= 0 && localCol < pattern.width && localRow >= 0 && localRow < pattern.height) {
                  setPattern(prev => {
                    const newSymbolGrid = [...prev.symbolGrid];
                    if (!newSymbolGrid[localRow]) return prev;

                    const newRow = [...newSymbolGrid[localRow]];
                    const selectedColor = prev.colorPalette.find(c => c.id === selectedColorId);
                    if (selectedColor) {
                      newRow[localCol] = {
                        colorId: selectedColor.id,
                        done: false
                      };
                      newSymbolGrid[localRow] = newRow;

                      // Flash jaune + toast
                      triggerFlash(col, row);
                      toast.success('Point ajouté ✅', { duration: 1000 });
                    }

                    return { ...prev, symbolGrid: newSymbolGrid };
                  });
                }
              }}
              onStitchRemove={(col, row) => {
                if (!pattern) return;
                handleErase(col, row);
                triggerFlash(col, row, '#FFFFFF');
                toast.success('Point supprimé ✅', { duration: 1000 });
              }}
              onCellClick={(col, row) => {
                if (!pattern) return;

                if (currentTool === 'selection-ia') {
                  handleSelectionPropagation(col, row);
                } else if (currentTool === 'symbol-picker') {
                  handlePipette(col, row);
                } else if (currentTool === 'highlight') {
                  handleHighlight(col, row);
                }
              }}
              flashCell={flashCell}
              selectedCells={selectedCells}
              selectionHighlightMode={selectionHighlightMode}
              contrastMode={contrastMode}
              symbolSizeMode={symbolSizeMode}
              antiFatigueMode={antiFatigueMode}
              focusColorMode={focusColorMode}
              highlightActiveMode={highlightActiveMode}
              nightMode={nightMode}
                                  autoCountMode={autoCountMode}
                                                                          activeFilter={activeFilter}
                                                                                              isolationMode={isolationMode}
                                                                                              paletteHoverColorId={paletteHoverColorId}
                                                                                              isolatedColorId={isolatedColorId}
                                                      showUnstitchedZones={showUnstitchedZones}
                                                      showPotentialErrors={showPotentialErrors}
                                                      showMissingPoints={showMissingPoints}
                                                      analysisResults={analysisResults}
                              />
                              </SubDisplayEngine>
                          </div>
                        )}
                      </main>
                    </div>

      {/* BARRE DU BAS FIXE - Palette DMC uniquement */}
      {pattern && showBottomPalette && (
        <div 
          style={{ 
            position: 'fixed', 
            bottom: 0, 
            left: 0, 
            right: 0, 
            zIndex: 90,
          }}
        >
          <DmcBottomPalette
            colorPalette={pattern?.colorPalette || defaultDmcPalette}
            selectedColorId={selectedColorId}
            onColorSelect={handleColorSelect}
            onMarkAsStitched={handleMarkColorAsDone}
            onFixEmptySymbols={handleFixEmptySymbols}
            onUnmarkAsStitched={(colorId) => {
              setPattern(prev => {
                if (!prev) return prev;

                const newSymbolGrid = prev.symbolGrid.map(row =>
                  row.map(cell => {
                    if (cell && cell.colorId === colorId) {
                      return { ...cell, done: false };
                    }
                    return cell;
                  })
                );

                const newColorPalette = prev.colorPalette.map(color => {
                  if (color.id === colorId) {
                    return { ...color, doneCount: 0, progress: 0 };
                  }
                  return color;
                });

                return { ...prev, symbolGrid: newSymbolGrid, colorPalette: newColorPalette };
              });
            }}
            pattern={pattern}
            onHoverColor={handlePaletteHoverColor}
            onIsolateColor={handleIsolateColor}
            symbolSize={symbolSizeMode}
          />
        </div>
      )}

      {/* Mini-carte flottante + Zoom - Position bas gauche au-dessus de la palette */}
      {pattern && (
        <FloatingMiniMapZoom
          pattern={pattern}
          gridConfig={gridConfig}
          canvasSize={canvasSize}
          currentZoom={gridConfig.zoom}
          onZoomChange={(newZoom, centerOnViewport = false) => {
            if (centerOnViewport) {
              const canvasContainer = document.getElementById('simple-canvas-container');
              if (canvasContainer) {
                const containerWidth = canvasContainer.offsetWidth;
                const containerHeight = canvasContainer.offsetHeight;
                const oldZoom = gridConfig.zoom;
                const tailleCase = gridConfig.taille_case;

                const viewportCenterX = (containerWidth / 2 - gridConfig.offset_x) / (tailleCase * oldZoom);
                const viewportCenterY = (containerHeight / 2 - gridConfig.offset_y) / (tailleCase * oldZoom);

                const newOffsetX = containerWidth / 2 - viewportCenterX * tailleCase * newZoom;
                const newOffsetY = containerHeight / 2 - viewportCenterY * tailleCase * newZoom;

                setGridConfig(prev => ({
                  ...prev,
                  zoom: newZoom,
                  offset_x: newOffsetX,
                  offset_y: newOffsetY
                }));
              }
            } else {
              setGridConfig(prev => ({ ...prev, zoom: newZoom }));
            }
          }}
          onNavigate={(x, y) => {
            setGridConfig(prev => ({
              ...prev,
              offset_x: canvasSize.width / 2 - x,
              offset_y: canvasSize.height / 2 - y
            }));
          }}
          onCenterView={() => {
            if (pattern) {
              centerOnPattern(pattern.width, pattern.height, pattern.offsetCol || 0, pattern.offsetRow || 0);
            } else {
              centerView();
            }
          }}
        />
      )}

      {/* Input file caché */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/png,image/jpeg,image/jpg,application/pdf,.sub"
        onChange={handleFileChange}
        className="hidden"
      />

      {/* Dialog d'import ancien (gardé pour compatibilité) */}
      <SimpleImportDialog
        open={showImportDialog}
        onClose={() => setShowImportDialog(false)}
        onConfirm={handleImportConfirm}
      />

      {/* Nouveau dialogue de préparation */}
      <PreparePatternDialog
        open={showPrepareDialog}
        onClose={() => {
          setShowPrepareDialog(false);
          setSelectedFile(null);
        }}
        onConfirm={handlePrepareConfirm}
        importedFile={selectedFile}
      />

      {/* Panneau de préparation avancée */}
      <AdvancedPatternPreparationPanel
        open={showAdvancedPreparationPanel}
        onClose={() => setShowAdvancedPreparationPanel(false)}
        pattern={pattern}
        onApply={handleAdvancedPreparationApply}
      />

      {/* Dialog de réparation des trous */}
      <RepairHolesDialog
        open={showRepairDialog}
        onClose={() => setShowRepairDialog(false)}
        onConfirm={handleRepairHoles}
        pattern={pattern}
      />

      {/* Dialog d'import .SUB intelligent */}
      <SubImportDialog
        open={showSubImportDialog}
        onClose={() => setShowSubImportDialog(false)}
        onComplete={handleSubImportComplete}
      />

      {/* Dialog de réparation automatique SUB */}
      <SubAutoRepairDialog
        open={showSubRepairDialog}
        onClose={() => setShowSubRepairDialog(false)}
        pattern={pattern}
        onRepairComplete={(repairedPattern, summary) => {
          setPattern(repairedPattern);
          setShowSubRepairDialog(false);
        }}
      />

      {/* Sélecteur de points SUB */}
      <SubStitchPicker
        open={showSubStitchPicker}
        onClose={() => setShowSubStitchPicker(false)}
        onSelect={(stitch) => {
          setCurrentSubStitch(stitch);
          setCurrentTool('cross');
        }}
        currentStitch={currentSubStitch}
      />

      {/* Dialog d'export SUB */}
      <SubExportDialog
        open={showSubExportDialog}
        onClose={() => setShowSubExportDialog(false)}
        pattern={pattern}
        gridConfig={gridConfig}
      />

      {/* Dialog Avant/Après SUB */}
      <SubBeforeAfterDialog
        open={showSubBeforeAfterDialog}
        onClose={() => setShowSubBeforeAfterDialog(false)}
        pattern={pattern}
        onApplySub={(repairedPattern) => {
          setPattern(repairedPattern);
        }}
      />

      {/* Carrousel découverte SUB */}
      <SubDiscoveryCarousel
        open={showSubDiscoveryCarousel}
        onClose={() => setShowSubDiscoveryCarousel(false)}
        onStart={() => {
          setShowSubDiscoveryCarousel(false);
          setShowImportSub2Dialog(true);
        }}
      />

      {/* IMPORT SUB 2.0 - Module principal */}
      <ImportSub2Dialog
        open={showImportSub2Dialog}
        onClose={() => setShowImportSub2Dialog(false)}
        onComplete={handleSubImportComplete}
      />

      {/* Module Export SUB complet */}
      <SubExportModule
        open={showSubExportModule}
        onClose={() => setShowSubExportModule(false)}
        pattern={pattern}
        gridConfig={gridConfig}
      />

      {/* Panneau Points SUB */}
      <SubPointsPanel
        open={showSubPointsPanel}
        onClose={() => setShowSubPointsPanel(false)}
        onSelect={(point) => {
          setCurrentSubPoint(point);
          setShowSubPointsPanel(false);
        }}
        currentPoint={currentSubPoint}
      />

      {/* Module SUB Print */}
      <SubPrintModule
        open={showSubPrintModule}
        onClose={() => setShowSubPrintModule(false)}
        pattern={pattern}
        gridConfig={gridConfig}
      />

      {/* IMPORT SUB AUTO 3-en-1 */}
      <ImportSubAuto
        open={showImportSubAuto}
        onClose={() => setShowImportSubAuto(false)}
        onComplete={handleSubImportComplete}
      />

      {/* Panneau Styles de Points SUB */}
      <SubStitchStylesPanel
        open={showSubStitchStyles}
        onClose={() => setShowSubStitchStyles(false)}
        onApply={setStitchStylesSettings}
        currentSettings={stitchStylesSettings}
      />

      {/* Guide rapide SUB */}
      <SubQuickGuide
        open={showSubQuickGuide}
        onClose={() => setShowSubQuickGuide(false)}
      />

      {/* Import Image PRO (ancien) */}
      <ImageImportPro
        open={showImageImportPro}
        onClose={() => setShowImageImportPro(false)}
        onComplete={handleSubImportComplete}
      />

      {/* Smart Import V3 - Nouveau module d'import */}
      <SmartImportV3
        open={showSmartImportV3}
        onClose={() => setShowSmartImportV3(false)}
        onComplete={handleSubImportComplete}
      />

      {/* Dialog de sauvegarde Premium */}
      <SaveProjectDialogPremium
        open={showSaveDialog}
        onClose={() => setShowSaveDialog(false)}
        onSave={handleSaveProjectConfirm}
        pattern={pattern}
        gridConfig={gridConfig}
        currentProjectId={currentProjectId}
      />

      {/* Modal Dashboard (Profil & Réglages) */}
      <DashboardModal
        open={showDashboardModal}
        onClose={() => setShowDashboardModal(false)}
        onLoadProject={(projectId) => {
          localStorage.setItem('loadProjectId', projectId);
          window.location.reload();
        }}
      />

      {/* Modal Projets (style Boutique) */}
      <ProjectsModal
        open={showProjectsModal}
        onClose={() => setShowProjectsModal(false)}
        onImport={() => setShowSmartImportV3(true)}
      />

      {/* Carrousel tutoriel flottant */}
      <FloatingTutorialCarousel
        isOpen={showTutorialCarousel}
        onClose={() => setShowTutorialCarousel(false)}
        onImport={() => setShowSmartImportV3(true)}
      />

      {/* Centre d'aide complet */}
      <HelpCenter
        open={showHelpCenter}
        onClose={() => setShowHelpCenter(false)}
      />

      {/* Modal Statistiques Pro */}
      <StatsModal
        isOpen={statsMode}
        onClose={() => setStatsMode(false)}
        pattern={pattern}
        colorPalette={pattern?.colorPalette || []}
        selectedColorId={selectedColorId}
      />

      {/* Carrousel intro Brood-Way */}
      <WelcomeIntroCarousel
        isOpen={showWelcomeIntro}
        onClose={() => setShowWelcomeIntro(false)}
        onImport={() => setShowSmartImportV3(true)}
      />

      {/* Prompt de correction des symboles manquants */}
      {showSymbolFixPrompt && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            backgroundColor: 'rgba(0,0,0,0.6)',
            zIndex: 20000,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <div
            style={{
              backgroundColor: '#fff',
              borderRadius: '16px',
              padding: '32px',
              maxWidth: '420px',
              textAlign: 'center',
              boxShadow: '0 20px 60px rgba(0,0,0,0.3)',
            }}
          >
            <div style={{ fontSize: '48px', marginBottom: '16px' }}>⚠️</div>
            <h3 style={{ fontSize: '18px', fontWeight: 700, marginBottom: '12px', color: '#111' }}>
              Symboles manquants détectés
            </h3>
            <p style={{ fontSize: '14px', color: '#666', marginBottom: '24px', lineHeight: 1.5 }}>
              Certaines couleurs n'ont pas encore de symboles assignés. 
              Voulez-vous les assigner automatiquement maintenant ?
            </p>
            <div style={{ display: 'flex', gap: '12px', justifyContent: 'center' }}>
              <button
                onClick={() => {
                  handleFixEmptySymbols();
                  setShowSymbolFixPrompt(false);
                }}
                style={{
                  padding: '12px 24px',
                  backgroundColor: '#000',
                  color: '#fff',
                  border: 'none',
                  borderRadius: '8px',
                  fontSize: '14px',
                  fontWeight: 600,
                  cursor: 'pointer',
                }}
              >
                Oui, assigner
              </button>
              <button
                onClick={() => setShowSymbolFixPrompt(false)}
                style={{
                  padding: '12px 24px',
                  backgroundColor: '#f0f0f0',
                  color: '#333',
                  border: 'none',
                  borderRadius: '8px',
                  fontSize: '14px',
                  fontWeight: 500,
                  cursor: 'pointer',
                }}
              >
                Non, plus tard
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Popup d'actions de sélection */}
      {showSelectionPopup && selectedCells.length > 0 && (
        <SelectionActionsPopup
          selectedCells={selectedCells}
          pattern={pattern}
          selectedColorId={selectedColorId}
          onClose={() => setShowSelectionPopup(false)}
          onEraseSelection={() => {
            // Action LOCALE: Efface uniquement les cases sélectionnées
            handleEraseSelection();
            // Ne pas fermer le popup pour permettre d'enchaîner
          }}
          onHighlightSelection={() => {
            // Action LOCALE: Sélection 100%, reste 30%
            setSelectionHighlightMode('highlight');
            toast.success('Sélection surlignée (reste à 30%)');
          }}
          onInverseHighlight={() => {
            // Action LOCALE: Sélection contrastée, reste faible
            setSelectionHighlightMode('inverse');
            toast.success('Surlignage inversé activé');
          }}
          onAutoCount={() => {
            // Action LOCALE: Compte uniquement les points de la sélection
            if (!pattern) return;
            const offsetCol = pattern.offsetCol || 0;
            const offsetRow = pattern.offsetRow || 0;
            const colorCounts = {};
            let emptyCount = 0;

            selectedCells.forEach(({ col, row }) => {
              const localCol = col - offsetCol;
              const localRow = row - offsetRow;
              const cell = pattern.symbolGrid?.[localRow]?.[localCol];
              if (cell?.colorId) {
                colorCounts[cell.colorId] = (colorCounts[cell.colorId] || 0) + 1;
              } else {
                emptyCount++;
              }
            });

            const filledTotal = Object.values(colorCounts).reduce((a, b) => a + b, 0);
            let dominantColorId = null;
            let maxCount = 0;
            Object.entries(colorCounts).forEach(([colorId, count]) => {
              if (count > maxCount) {
                maxCount = count;
                dominantColorId = colorId;
              }
            });

            const dominantColor = pattern.colorPalette?.find(c => c.id === dominantColorId);
            toast.success(`${filledTotal} pts remplis • ${emptyCount} vides • Dominant: ${dominantColor?.code || dominantColor?.name || 'N/A'}`);
          }}
          onFillExact={() => {
            // Action LOCALE: Remplit la sélection avec la couleur active
            if (!pattern || !selectedColorId) {
              toast.info('Choisissez une couleur dans la palette');
              return;
            }

            saveToHistory();

            const offsetCol = pattern.offsetCol || 0;
            const offsetRow = pattern.offsetRow || 0;
            let filledCount = 0;

            setPattern(prev => {
              const newSymbolGrid = prev.symbolGrid.map(row => row ? [...row] : []);

              selectedCells.forEach(({ col, row }) => {
                const localCol = col - offsetCol;
                const localRow = row - offsetRow;

                if (localRow >= 0 && localRow < prev.height && localCol >= 0 && localCol < prev.width) {
                  if (!newSymbolGrid[localRow]) newSymbolGrid[localRow] = [];
                  newSymbolGrid[localRow][localCol] = { colorId: selectedColorId, done: false };
                  filledCount++;
                }
              });

              return { ...prev, symbolGrid: newSymbolGrid };
            });

            const activeColor = pattern.colorPalette?.find(c => c.id === selectedColorId);
            toast.success(`Fill Exact™: ${filledCount} cases → ${activeColor?.code || activeColor?.name || 'couleur'}`);
          }}
          onSmartFix={() => {
            // Action LOCALE: Analyse et corrige uniquement la zone sélectionnée
            if (!pattern) return;

            saveToHistory();

            const offsetCol = pattern.offsetCol || 0;
            const offsetRow = pattern.offsetRow || 0;
            let fixedCount = 0;
            let holesFilledCount = 0;

            setPattern(prev => {
              const newSymbolGrid = prev.symbolGrid.map(row => row ? [...row] : []);

              // Passe 1: Corriger les symboles isolés
              selectedCells.forEach(({ col, row }) => {
                const localCol = col - offsetCol;
                const localRow = row - offsetRow;
                const cell = newSymbolGrid[localRow]?.[localCol];

                if (!cell) return;

                // Analyser les voisins (4 directions)
                const neighbors = [];
                if (localRow > 0 && newSymbolGrid[localRow - 1]?.[localCol]) neighbors.push(newSymbolGrid[localRow - 1][localCol]);
                if (localRow < prev.height - 1 && newSymbolGrid[localRow + 1]?.[localCol]) neighbors.push(newSymbolGrid[localRow + 1][localCol]);
                if (localCol > 0 && newSymbolGrid[localRow]?.[localCol - 1]) neighbors.push(newSymbolGrid[localRow][localCol - 1]);
                if (localCol < prev.width - 1 && newSymbolGrid[localRow]?.[localCol + 1]) neighbors.push(newSymbolGrid[localRow][localCol + 1]);

                // Compter les couleurs voisines
                const colorCounts = {};
                neighbors.forEach(n => {
                  if (n?.colorId) colorCounts[n.colorId] = (colorCounts[n.colorId] || 0) + 1;
                });

                // Si la couleur actuelle est isolée (0-1 voisin) et une autre domine (3+)
                const currentColorCount = colorCounts[cell.colorId] || 0;
                const sortedColors = Object.entries(colorCounts).sort((a, b) => b[1] - a[1]);

                if (sortedColors.length > 0 && currentColorCount <= 1 && sortedColors[0][1] >= 3) {
                  newSymbolGrid[localRow][localCol] = { colorId: sortedColors[0][0], done: false };
                  fixedCount++;
                }
              });

              // Passe 2: Remplir les trous isolés dans la sélection
              selectedCells.forEach(({ col, row }) => {
                const localCol = col - offsetCol;
                const localRow = row - offsetRow;
                const cell = newSymbolGrid[localRow]?.[localCol];

                if (cell) return; // Pas un trou

                // Compter les voisins remplis
                const neighbors = [];
                if (localRow > 0 && newSymbolGrid[localRow - 1]?.[localCol]) neighbors.push(newSymbolGrid[localRow - 1][localCol]);
                if (localRow < prev.height - 1 && newSymbolGrid[localRow + 1]?.[localCol]) neighbors.push(newSymbolGrid[localRow + 1][localCol]);
                if (localCol > 0 && newSymbolGrid[localRow]?.[localCol - 1]) neighbors.push(newSymbolGrid[localRow][localCol - 1]);
                if (localCol < prev.width - 1 && newSymbolGrid[localRow]?.[localCol + 1]) neighbors.push(newSymbolGrid[localRow][localCol + 1]);

                if (neighbors.length >= 3) {
                  const colorCounts = {};
                  neighbors.forEach(n => {
                    if (n?.colorId) colorCounts[n.colorId] = (colorCounts[n.colorId] || 0) + 1;
                  });
                  const sortedColors = Object.entries(colorCounts).sort((a, b) => b[1] - a[1]);
                  if (sortedColors.length > 0) {
                    if (!newSymbolGrid[localRow]) newSymbolGrid[localRow] = [];
                    newSymbolGrid[localRow][localCol] = { colorId: sortedColors[0][0], done: false };
                    holesFilledCount++;
                  }
                }
              });

              return { ...prev, symbolGrid: newSymbolGrid };
            });

            if (fixedCount > 0 || holesFilledCount > 0) {
              toast.success(`Smart-Fix™: ${fixedCount} corrigé${fixedCount > 1 ? 's' : ''}, ${holesFilledCount} trou${holesFilledCount > 1 ? 's' : ''} rempli${holesFilledCount > 1 ? 's' : ''}`);
            } else {
              toast.info('Smart-Fix™: Sélection déjà propre ✓');
            }
          }}
          onMaskRest={() => {
            // Action LOCALE: Masque tout sauf la sélection (opacité ~0%)
            setSelectionHighlightMode('mask');
            toast.success('Reste masqué (sélection visible)');
          }}
          onDeselect={() => {
            // Désélectionner et réinitialiser l'affichage local
            setSelectedCells([]);
            setSelectionHighlightMode(null);
            setShowSelectionPopup(false);
          }}
        />
      )}
      </div>
      );
      }