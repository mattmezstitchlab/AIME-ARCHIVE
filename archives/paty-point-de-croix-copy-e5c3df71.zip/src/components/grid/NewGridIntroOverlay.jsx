import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Grid3x3, Sparkles, Bot, X } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function NewGridIntroOverlay({ 
  isOpen, 
  onCreateNewGrid, 
  onCancel,
  onDontShowAgain 
}) {
  const [dontShowAgain, setDontShowAgain] = useState(false);

  // Focus sur le bouton principal à l'ouverture
  useEffect(() => {
    if (isOpen) {
      const timer = setTimeout(() => {
        document.getElementById('create-grid-btn')?.focus();
      }, 100);
      return () => clearTimeout(timer);
    }
  }, [isOpen]);

  // Gérer la touche ESC
  useEffect(() => {
    const handleEscape = (e) => {
      if (e.key === 'Escape' && isOpen) {
        handleCancel();
      }
    };

    document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }, [isOpen]);

  const handleCreateGrid = () => {
    if (dontShowAgain) {
      onDontShowAgain();
    }
    onCreateNewGrid();
  };

  const handleCancel = () => {
    if (dontShowAgain) {
      onDontShowAgain();
    }
    onCancel();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.25 }}
          className="fixed inset-0 z-[100000] flex items-center justify-center"
          style={{ backgroundColor: 'rgba(0, 0, 0, 0.95)' }}
          onClick={(e) => {
            if (e.target === e.currentTarget) handleCancel();
          }}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="bg-white rounded-2xl shadow-2xl w-full mx-4 max-w-[720px] min-w-[320px] overflow-hidden"
            style={{ boxShadow: '0 18px 45px rgba(0,0,0,0.35)' }}
          >
            {/* Contenu de la carte */}
            <div className="p-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                
                {/* Colonne gauche - Illustration */}
                <div className="flex flex-col items-center justify-center">
                  <div className="w-full aspect-square bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-center mb-4">
                    {/* Illustration conceptuelle : Image → Grille → IA */}
                    <div className="relative w-40 h-40">
                      {/* Grille stylisée */}
                      <div className="absolute inset-0 grid grid-cols-6 grid-rows-6 gap-1 p-2">
                        {Array.from({ length: 36 }).map((_, i) => (
                          <div key={i} className="bg-slate-300 rounded-sm" />
                        ))}
                      </div>
                      
                      {/* Bulle IA en bas à droite */}
                      <div 
                        className="absolute -bottom-2 -right-2 w-12 h-12 bg-black rounded-lg border-2 border-[#F5C200] flex items-center justify-center shadow-lg"
                      >
                        <span className="text-white text-sm font-bold">IA</span>
                      </div>
                      
                      {/* Icône image en haut à gauche */}
                      <div className="absolute -top-2 -left-2 w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center shadow-lg">
                        <Grid3x3 className="w-5 h-5 text-white" />
                      </div>
                      
                      {/* Sparkles */}
                      <Sparkles className="absolute -top-4 right-8 w-6 h-6 text-[#F5C200]" />
                    </div>
                  </div>
                  
                  <p className="text-sm text-slate-600 text-center max-w-xs">
                    PatyBee transforme vos idées en grilles prêtes à broder
                  </p>
                </div>

                {/* Colonne droite - Texte et actions */}
                <div className="flex flex-col justify-between">
                  <div>
                    {/* Titre */}
                    <h2 className="text-2xl font-bold text-slate-900 mb-2">
                      Bienvenue dans ta nouvelle grille PatyBee
                    </h2>
                    
                    {/* Sous-titre */}
                    <p className="text-slate-600 mb-4">
                      PatyBee t'aide à transformer tes images en grilles optimisées, prêtes à broder avec tes fils DMC.
                    </p>
                    
                    {/* Paragraphe d'intro */}
                    <p className="text-sm text-slate-700 mb-4 font-medium">
                      Avant de générer ta nouvelle grille, voici ce que PatyBee fait pour toi automatiquement :
                    </p>
                    
                    {/* Liste des 3 points clés */}
                    <div className="space-y-3 mb-6">
                      {/* Point 1 */}
                      <div className="flex items-start gap-3">
                        <div className="w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="text-lg">🧵</span>
                        </div>
                        <div>
                          <h3 className="text-sm font-semibold text-slate-900">Conversion DMC intelligente</h3>
                          <p className="text-xs text-slate-600 leading-relaxed">
                            Les couleurs de ton image sont automatiquement rapprochées de la palette DMC, avec fusion des doublons et gestion des dégradés.
                          </p>
                        </div>
                      </div>
                      
                      {/* Point 2 */}
                      <div className="flex items-start gap-3">
                        <div className="w-8 h-8 rounded-full bg-amber-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="text-lg">✨</span>
                        </div>
                        <div>
                          <h3 className="text-sm font-semibold text-slate-900">Styles de points optimisés</h3>
                          <p className="text-xs text-slate-600 leading-relaxed">
                            Points complets, demi-points, backstitch, perles et effets spéciaux : PatyBee peut adapter la grille selon ton niveau et ton style.
                          </p>
                        </div>
                      </div>
                      
                      {/* Point 3 */}
                      <div className="flex items-start gap-3">
                        <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="text-lg">🤖</span>
                        </div>
                        <div>
                          <h3 className="text-sm font-semibold text-slate-900">Assistance IA intégrée</h3>
                          <p className="text-xs text-slate-600 leading-relaxed">
                            L'IA peut t'aider à simplifier le motif, réduire le nombre de couleurs, ajuster la taille et te proposer des options plus faciles à broder.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Boutons et checkbox */}
                  <div>
                    {/* Checkbox "Ne plus afficher" */}
                    <div className="mb-4 pb-4 border-t border-slate-200 pt-4">
                      <label className="flex items-center gap-2 cursor-pointer group">
                        <input
                          type="checkbox"
                          checked={dontShowAgain}
                          onChange={(e) => setDontShowAgain(e.target.checked)}
                          className="w-4 h-4 rounded border-slate-300 text-black focus:ring-2 focus:ring-black cursor-pointer"
                        />
                        <span className="text-xs text-slate-600 group-hover:text-slate-900 transition-colors">
                          Ne plus afficher cet écran
                        </span>
                      </label>
                    </div>
                    
                    {/* Boutons d'action */}
                    <div className="flex flex-col sm:flex-row gap-3">
                      <Button
                        id="create-grid-btn"
                        onClick={handleCreateGrid}
                        className="flex-1 bg-black hover:bg-[#1A1A1A] text-white font-semibold py-3 rounded-lg shadow-md"
                      >
                        Créer une nouvelle grille
                      </Button>
                      
                      <Button
                        onClick={handleCancel}
                        variant="outline"
                        className="flex-1 bg-slate-50 hover:bg-slate-100 text-slate-900 border border-slate-300 py-3 rounded-lg"
                      >
                        Revenir à ma grille actuelle
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}