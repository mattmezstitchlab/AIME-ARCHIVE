import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { 
  User, Mountain, Smile, Circle, Rainbow, 
  Check, ChevronRight, Sparkles, Info
} from 'lucide-react';
import { toast } from 'sonner';

const GUIDED_PALETTES = [
  {
    id: 'portrait',
    name: 'Portrait',
    icon: User,
    maxColors: 24,
    description: '3 teintes de peau, 2 couleurs de cheveux, 1 contour, dégradés doux',
    families: ['skin', 'browns', 'neutrals', 'reds'],
    previewColors: ['#FFDAB9', '#D2691E', '#8B4513', '#000000', '#FFE4E1', '#CD853F']
  },
  {
    id: 'landscape',
    name: 'Paysage',
    icon: Mountain,
    maxColors: 30,
    description: 'Ciel dégradé, végétation, terre, eau, lumière naturelle',
    families: ['blues', 'greens', 'browns', 'yellows'],
    previewColors: ['#87CEEB', '#228B22', '#8B4513', '#FFD700', '#006400', '#4682B4']
  },
  {
    id: 'simple',
    name: 'Icône simple',
    icon: Smile,
    maxColors: 12,
    description: 'Palette minimaliste pour motifs simples et lisibles',
    families: ['neutrals', 'reds', 'blues'],
    previewColors: ['#000000', '#FFFFFF', '#FF0000', '#0000FF', '#808080', '#FFD700']
  },
  {
    id: 'monochrome',
    name: 'Monochrome',
    icon: Circle,
    maxColors: 8,
    description: 'Nuances d\'une seule couleur pour effet élégant',
    families: ['neutrals'],
    previewColors: ['#000000', '#333333', '#666666', '#999999', '#CCCCCC', '#FFFFFF']
  },
  {
    id: 'rainbow',
    name: 'Arc-en-ciel',
    icon: Rainbow,
    maxColors: 16,
    description: 'Spectre complet de couleurs vives et joyeuses',
    families: ['reds', 'oranges', 'yellows', 'greens', 'blues', 'purples'],
    previewColors: ['#FF0000', '#FF7F00', '#FFFF00', '#00FF00', '#0000FF', '#8B00FF']
  }
];

export default function GuidedPaletteSelector({ onSelect, onClose }) {
  const [selectedPalette, setSelectedPalette] = useState(null);
  const [showDetails, setShowDetails] = useState(null);

  const handleApply = () => {
    if (!selectedPalette) {
      toast.error('Sélectionnez une palette');
      return;
    }
    
    const palette = GUIDED_PALETTES.find(p => p.id === selectedPalette);
    onSelect?.(palette);
    toast.success(`Palette "${palette.name}" appliquée`);
    onClose?.();
  };

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-[99999]">
      <div className="bg-white rounded-2xl w-[600px] max-h-[80vh] overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-yellow-400 to-orange-400 px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-black flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-yellow-400" />
            </div>
            <div>
              <h2 className="text-lg font-black text-black">PALETTE GUIDÉE SUB™</h2>
              <p className="text-sm text-black/70">Palettes optimisées pour débutants</p>
            </div>
          </div>
        </div>

        {/* Contenu */}
        <div className="p-6 space-y-4 overflow-y-auto" style={{ maxHeight: 'calc(80vh - 160px)' }}>
          <p className="text-sm text-gray-600">
            Choisissez un type de motif. Nous appliquerons automatiquement une palette 
            optimisée avec les couleurs essentielles.
          </p>

          <div className="space-y-3">
            {GUIDED_PALETTES.map(palette => {
              const Icon = palette.icon;
              const isSelected = selectedPalette === palette.id;

              return (
                <div
                  key={palette.id}
                  onClick={() => setSelectedPalette(palette.id)}
                  className={`p-4 rounded-xl border-2 cursor-pointer transition-all ${
                    isSelected 
                      ? 'border-yellow-500 bg-yellow-50' 
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-start gap-4">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                      isSelected ? 'bg-yellow-500 text-black' : 'bg-gray-100'
                    }`}>
                      <Icon className="w-6 h-6" />
                    </div>

                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <h3 className="font-bold">{palette.name}</h3>
                        <span className="text-sm text-gray-500">{palette.maxColors} couleurs max</span>
                      </div>
                      <p className="text-sm text-gray-600 mt-1">{palette.description}</p>

                      {/* Aperçu couleurs */}
                      <div className="flex gap-1 mt-3">
                        {palette.previewColors.map((color, idx) => (
                          <div
                            key={idx}
                            className="w-6 h-6 rounded border border-gray-300"
                            style={{ backgroundColor: color }}
                          />
                        ))}
                      </div>
                    </div>

                    {isSelected && (
                      <div className="w-6 h-6 rounded-full bg-yellow-500 flex items-center justify-center">
                        <Check className="w-4 h-4 text-black" />
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Info pédagogique */}
          {selectedPalette && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-start gap-3">
              <Info className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm text-blue-800">
                <strong>Conseil SUB :</strong> Cette palette a été optimisée pour vous. 
                Les couleurs clés (peau, contours) seront automatiquement verrouillées 
                pour éviter les modifications accidentelles.
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t bg-gray-50 flex justify-between">
          <Button variant="outline" onClick={onClose}>
            Annuler
          </Button>
          <Button 
            onClick={handleApply}
            disabled={!selectedPalette}
            className="bg-black hover:bg-gray-800 gap-2"
          >
            Appliquer cette palette
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}