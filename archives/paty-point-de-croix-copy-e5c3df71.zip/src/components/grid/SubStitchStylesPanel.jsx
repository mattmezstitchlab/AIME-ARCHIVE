import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Checkbox } from '@/components/ui/checkbox';
import { 
  X, Zap, Check, Info, Sparkles, 
  Target, Square, Layers, PenTool
} from 'lucide-react';
import { toast } from 'sonner';

// Points classiques
const CLASSIC_STITCHES = [
  {
    id: 'cross',
    name: 'Point de croix complet',
    description: 'Croix classique sur 2 fils (X). Base de tous les motifs.',
    icon: '✕',
    default: true
  },
  {
    id: 'half',
    name: 'Demi-point',
    description: 'Point en diagonale (/) ou (\\) pour les dégradés et les zones fines.',
    icon: '/',
    default: true
  },
  {
    id: 'quarter',
    name: 'Quart de point',
    description: '1/4 de croix pour les détails très précis (contours de visage, arrondis, etc.).',
    icon: '·',
    default: true
  },
  {
    id: 'backstitch',
    name: 'Point arrière (backstitch)',
    description: 'Trait de contour ou de détail, idéal pour les lettres, les traits du visage, les bordures.',
    icon: '─',
    default: true
  },
  {
    id: 'frenchknot',
    name: 'Nœud français',
    description: 'Petit point en relief pour les yeux, les fleurs, les perles, les boutons.',
    icon: '●',
    default: true
  }
];

// Nouveaux points SUB
const SUB_STITCHES = [
  {
    id: 'lecointre',
    name: 'Point LECOINTRE (Point Lorrain)',
    description: 'Point d\'ancrage en forme de croix de Lorraine (+ une barre supplémentaire).',
    usage: [
      'Renforcer les coins et les intersections de motifs',
      'Marquer le point de départ d\'un projet',
      'Éviter que le fil se défasse dans les zones très sollicitées'
    ],
    rule: '1 point LECOINTRE = 1 croix complète + 1 mini-barre horizontale supplémentaire au centre.',
    iaPlacement: 'L\'IA le place en priorité sur : les coins, le centre de la grille, les jonctions de grandes zones de couleur.',
    icon: '╋',
    color: '#1E40AF',
    default: true
  },
  {
    id: 'zero',
    name: 'Point ZERO',
    description: 'Petit point central rond (ou petit +) pour marquer un repère important.',
    usage: [
      'Centre de la grille',
      'Repères de symétrie',
      'Points de positionnement (yeux, cœur, centre d\'un motif)'
    ],
    rule: 'Jamais utilisé en remplissage. Servent uniquement de repères et peuvent être supprimés une fois la broderie commencée.',
    icon: '◎',
    color: '#EF4444',
    default: true
  },
  {
    id: 'subfill',
    name: 'Point SUB Fill',
    description: 'Point de remplissage optimisé pour les grandes surfaces.',
    usage: [
      'Réduit le changement de fil',
      'Crée une texture régulière',
      'Limite les trous et les sauts de fil derrière la toile'
    ],
    rule: 'Utilisé dans les grandes zones d\'une même couleur. L\'IA peut proposer automatiquement le Point SUB Fill pour toutes les zones > X cases contiguës.',
    icon: '▓',
    color: '#8B5CF6',
    default: true
  },
  {
    id: 'subcontour',
    name: 'Point SUB Contour',
    description: 'Variante simplifiée du backstitch.',
    usage: [
      'Lisibilité maximale',
      'Moins de changements de direction',
      'Contour net, facile à suivre'
    ],
    rule: 'Utilisé pour les contours principaux (silhouettes, objets). Le backstitch classique reste disponible pour les détails fins.',
    icon: '━',
    color: '#10B981',
    default: true
  }
];

export default function SubStitchStylesPanel({ open, onClose, onApply, currentSettings }) {
  // États des points classiques
  const [classicStitches, setClassicStitches] = useState(
    CLASSIC_STITCHES.reduce((acc, s) => ({ ...acc, [s.id]: s.default }), {})
  );
  
  // États des points SUB
  const [subStitches, setSubStitches] = useState(
    SUB_STITCHES.reduce((acc, s) => ({ ...acc, [s.id]: s.default }), {})
  );
  
  // États réparation des trous
  const [repairSettings, setRepairSettings] = useState({
    autoRepair: true,
    maxHoleSize: 3,
    preserveBackground: true
  });
  
  // Paramètre SUB Fill
  const [subFillThreshold, setSubFillThreshold] = useState(10);

  // Charger les paramètres existants
  useEffect(() => {
    if (currentSettings) {
      if (currentSettings.classicStitches) setClassicStitches(currentSettings.classicStitches);
      if (currentSettings.subStitches) setSubStitches(currentSettings.subStitches);
      if (currentSettings.repairSettings) setRepairSettings(currentSettings.repairSettings);
      if (currentSettings.subFillThreshold) setSubFillThreshold(currentSettings.subFillThreshold);
    }
  }, [currentSettings]);

  const handleApply = () => {
    const settings = {
      classicStitches,
      subStitches,
      repairSettings,
      subFillThreshold
    };
    
    onApply?.(settings);
    toast.success('Styles de points mis à jour');
    onClose();
  };

  // Compter les points actifs
  const activeClassicCount = Object.values(classicStitches).filter(Boolean).length;
  const activeSubCount = Object.values(subStitches).filter(Boolean).length;

  if (!open) return null;

  return (
    <div 
      className="fixed inset-0 flex items-center justify-center"
      style={{ zIndex: 999999, backgroundColor: 'rgba(0, 0, 0, 0.85)' }}
    >
      <div className="bg-white rounded-2xl shadow-2xl w-[900px] max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="bg-black px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-yellow-400 to-orange-500 flex items-center justify-center">
              <Layers className="w-5 h-5 text-black" />
            </div>
            <div>
              <h2 className="text-lg font-black text-white">Styles de points</h2>
              <p className="text-sm text-gray-400">Points classiques + innovations SUB</p>
            </div>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center">
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        {/* Intro */}
        <div className="px-6 py-3 bg-yellow-50 border-b border-yellow-200">
          <p className="text-sm text-yellow-800">
            Choisissez les types de points utilisés pour générer la grille. SUB conserve tous les points classiques 
            et ajoute des points innovants pour simplifier et renforcer la broderie.
          </p>
        </div>

        {/* Contenu scrollable */}
        <div className="p-6 overflow-y-auto" style={{ maxHeight: 'calc(90vh - 280px)' }}>
          {/* Section 1: Points classiques */}
          <div className="mb-8">
            <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
              <Square className="w-5 h-5" />
              Points classiques
            </h3>
            
            <div className="space-y-3">
              {CLASSIC_STITCHES.map(stitch => (
                <div 
                  key={stitch.id}
                  className={`p-4 rounded-lg border-2 transition-all ${
                    classicStitches[stitch.id] 
                      ? 'border-black bg-gray-50' 
                      : 'border-gray-200'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <Checkbox
                      id={stitch.id}
                      checked={classicStitches[stitch.id]}
                      onCheckedChange={(checked) => 
                        setClassicStitches(prev => ({...prev, [stitch.id]: checked}))
                      }
                      className="mt-1"
                    />
                    <div className="flex-1">
                      <div className="flex items-center gap-3">
                        <span className="text-2xl font-mono">{stitch.icon}</span>
                        <label htmlFor={stitch.id} className="font-semibold cursor-pointer">
                          {stitch.name}
                        </label>
                      </div>
                      <p className="text-sm text-gray-600 mt-1">{stitch.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Section 2: Points SUB */}
          <div className="mb-8">
            <h3 className="text-lg font-bold mb-2 flex items-center gap-2">
              <Zap className="w-5 h-5 text-yellow-500" />
              Points SUB – Innovations
            </h3>
            <p className="text-sm text-gray-600 mb-4">
              Les points SUB ont été conçus pour simplifier, renforcer et structurer la broderie moderne, 
              tout en restant réalisables avec du fil et une toile classiques.
            </p>
            
            <div className="space-y-4">
              {SUB_STITCHES.map(stitch => (
                <div 
                  key={stitch.id}
                  className={`p-4 rounded-xl border-2 transition-all ${
                    subStitches[stitch.id] 
                      ? 'border-yellow-500 bg-yellow-50' 
                      : 'border-gray-200'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <Checkbox
                      id={`sub-${stitch.id}`}
                      checked={subStitches[stitch.id]}
                      onCheckedChange={(checked) => 
                        setSubStitches(prev => ({...prev, [stitch.id]: checked}))
                      }
                      className="mt-1"
                    />
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <span 
                          className="text-2xl w-10 h-10 rounded-lg flex items-center justify-center"
                          style={{ backgroundColor: stitch.color + '20', color: stitch.color }}
                        >
                          {stitch.icon}
                        </span>
                        <label htmlFor={`sub-${stitch.id}`} className="font-bold cursor-pointer">
                          {stitch.name}
                        </label>
                      </div>
                      <p className="text-sm text-gray-700 mb-2">{stitch.description}</p>
                      
                      {stitch.usage && (
                        <div className="mb-2">
                          <p className="text-xs font-semibold text-gray-500 mb-1">Utilisation :</p>
                          <ul className="text-xs text-gray-600 space-y-0.5">
                            {stitch.usage.map((u, i) => (
                              <li key={i} className="flex items-start gap-1">
                                <span className="text-yellow-500">•</span>
                                {u}
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                      
                      <div className="bg-white rounded-lg p-2 border border-gray-200">
                        <p className="text-xs">
                          <span className="font-semibold">Règle :</span> {stitch.rule}
                        </p>
                        {stitch.iaPlacement && (
                          <p className="text-xs text-blue-600 mt-1">
                            <span className="font-semibold">IA :</span> {stitch.iaPlacement}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Seuil SUB Fill */}
            {subStitches.subfill && (
              <div className="mt-4 p-4 bg-purple-50 rounded-lg border border-purple-200">
                <Label className="font-semibold text-purple-800">
                  Seuil SUB Fill : {subFillThreshold} cases contiguës
                </Label>
                <p className="text-xs text-purple-600 mb-2">
                  L'IA proposera le Point SUB Fill pour les zones dépassant ce seuil.
                </p>
                <Slider
                  value={[subFillThreshold]}
                  onValueChange={([v]) => setSubFillThreshold(v)}
                  min={5}
                  max={50}
                  step={5}
                  className="mt-2"
                />
              </div>
            )}
          </div>

          {/* Section 3: Logique IA */}
          <div className="mb-8 p-4 bg-blue-50 rounded-xl border border-blue-200">
            <h4 className="font-bold text-blue-800 flex items-center gap-2 mb-2">
              <Sparkles className="w-5 h-5" />
              Logique IA des styles de points
            </h4>
            <p className="text-sm text-blue-700">
              L'IA choisit automatiquement le style de point le plus adapté :
            </p>
            <ul className="text-sm text-blue-700 mt-2 space-y-1">
              <li>• <strong>Points LECOINTRE</strong> pour les coins, centres et zones de renfort.</li>
              <li>• <strong>Points ZERO</strong> pour les repères de positionnement (centre, yeux, symboles clés).</li>
              <li>• <strong>Points SUB Fill</strong> pour les grandes zones de fond.</li>
              <li>• <strong>Backstitch / SUB Contour</strong> pour les contours.</li>
            </ul>
            <p className="text-sm text-blue-600 mt-2 italic">
              Vous pouvez ensuite ajuster manuellement chaque zone dans l'éditeur de grille.
            </p>
          </div>

          {/* Section 4: Réparation des trous */}
          <div className="p-4 bg-red-50 rounded-xl border border-red-200">
            <h4 className="font-bold text-red-800 flex items-center gap-2 mb-3">
              <Target className="w-5 h-5" />
              Réparer les trous
            </h4>
            <p className="text-sm text-red-700 mb-4">
              Analyse automatiquement les cases vides et les corrige pour éviter les manques dans la broderie.
            </p>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label className="font-medium">Réparation automatique des trous</Label>
                  <p className="text-xs text-gray-500">(recommandé) Toujours activée après chaque import ou conversion.</p>
                </div>
                <Switch
                  checked={repairSettings.autoRepair}
                  onCheckedChange={(v) => setRepairSettings(p => ({...p, autoRepair: v}))}
                />
              </div>
              
              <div>
                <Label className="font-medium">
                  Taille maximale des trous à réparer : {repairSettings.maxHoleSize} case{repairSettings.maxHoleSize > 1 ? 's' : ''}
                </Label>
                <Slider
                  value={[repairSettings.maxHoleSize]}
                  onValueChange={([v]) => setRepairSettings(p => ({...p, maxHoleSize: v}))}
                  min={1}
                  max={5}
                  step={1}
                  className="mt-2"
                  disabled={!repairSettings.autoRepair}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label className="font-medium">Préserver le fond clair</Label>
                  <p className="text-xs text-gray-500">Ne pas remplir les zones volontairement vides (fond, marges).</p>
                </div>
                <Switch
                  checked={repairSettings.preserveBackground}
                  onCheckedChange={(v) => setRepairSettings(p => ({...p, preserveBackground: v}))}
                  disabled={!repairSettings.autoRepair}
                />
              </div>
            </div>

            {repairSettings.autoRepair && (
              <div className="mt-4 p-3 bg-green-100 rounded-lg border border-green-300">
                <p className="text-sm text-green-800 font-medium flex items-center gap-2">
                  <Check className="w-4 h-4" />
                  Réparation terminée : 0 case vide restante dans la zone brodée.
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Récapitulatif */}
        <div className="px-6 py-3 bg-gray-100 border-t">
          <div className="text-sm">
            <p className="font-bold mb-1">Vous utilisez actuellement :</p>
            <p className="text-gray-700">
              • <strong>Points classiques :</strong> {
                CLASSIC_STITCHES.filter(s => classicStitches[s.id]).map(s => s.name.split(' ')[0].toLowerCase()).join(', ') || 'aucun'
              }
            </p>
            <p className="text-gray-700">
              • <strong>Points SUB :</strong> {
                SUB_STITCHES.filter(s => subStitches[s.id]).map(s => s.id.toUpperCase()).join(', ') || 'aucun'
              }
            </p>
            <p className="text-gray-700">
              • <strong>Réparation automatique des trous :</strong> {repairSettings.autoRepair ? 'ACTIVÉE' : 'DÉSACTIVÉE'}
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t flex justify-between items-center">
          <div className="text-sm text-gray-500">
            {activeClassicCount} points classiques • {activeSubCount} points SUB actifs
          </div>
          <div className="flex gap-3">
            <Button variant="outline" onClick={onClose}>Annuler</Button>
            <Button onClick={handleApply} className="bg-black hover:bg-gray-800">
              Appliquer les styles
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}