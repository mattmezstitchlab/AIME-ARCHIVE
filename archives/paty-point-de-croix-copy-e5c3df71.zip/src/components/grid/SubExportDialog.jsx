import React, { useState, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { X, Download, FileText, Image, Check, Loader2, Zap, Shield } from 'lucide-react';
import { toast } from 'sonner';
import { createSubFile, SUB_FORMAT } from './subFormat';

export default function SubExportDialog({ open, onClose, pattern, gridConfig }) {
  const [isExporting, setIsExporting] = useState(false);
  const [exportComplete, setExportComplete] = useState(false);

  // Calculer les statistiques
  const stats = useMemo(() => {
    if (!pattern?.symbolGrid) return null;

    let totalPoints = 0;
    let subPoints = 0;
    const dmcUsed = new Set();
    const subTypesUsed = new Set();

    pattern.symbolGrid.forEach(row => {
      row.forEach(cell => {
        if (cell) {
          totalPoints++;
          if (cell.type?.startsWith('S')) {
            subPoints++;
            subTypesUsed.add(cell.type);
          }
          if (cell.colorId) dmcUsed.add(cell.colorId);
        }
      });
    });

    // Estimer la taille du fichier (approximation)
    const estimatedSize = Math.round((totalPoints * 20 + 5000) / 1024);

    return {
      totalPoints,
      subPoints,
      dmcCount: pattern.colorPalette?.length || dmcUsed.size,
      subTypesCount: subTypesUsed.size,
      estimatedSize,
      width: pattern.width,
      height: pattern.height
    };
  }, [pattern]);

  // Générer le hash d'intégrité SUB
  const generateSubHash = (data) => {
    const str = JSON.stringify(data);
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    return 'SUB-' + Math.abs(hash).toString(16).toUpperCase().padStart(8, '0');
  };

  const handleExportSub = async () => {
    if (!pattern) {
      toast.error('Aucune grille à exporter');
      return;
    }

    setIsExporting(true);

    try {
      await new Promise(r => setTimeout(r, 500)); // UX delay

      // Créer le fichier SUB avec hash d'intégrité
      const subFile = createSubFile(pattern, {
        name: gridConfig?.name || 'grille_sub',
        author: 'PatyBee User',
        version: SUB_FORMAT.version
      });

      // Ajouter le hash d'intégrité
      subFile.integrity = {
        hash: generateSubHash(subFile),
        timestamp: new Date().toISOString(),
        version: SUB_FORMAT.version
      };

      // Télécharger
      const jsonString = JSON.stringify(subFile, null, 2);
      const blob = new Blob([jsonString], { type: 'application/x-sub' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${gridConfig?.name || 'grille'}.sub`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      setExportComplete(true);
      toast.success('Export .SUB réussi !');
    } catch (error) {
      console.error('Erreur export:', error);
      toast.error('Erreur lors de l\'export');
    } finally {
      setIsExporting(false);
    }
  };

  const handleExportPDF = () => {
    toast.info('Export PDF HD : fonctionnalité à venir');
  };

  const handleExportPNG = () => {
    toast.info('Export PNG : fonctionnalité à venir');
  };

  const handleExportJPEG = () => {
    toast.info('Export JPEG : fonctionnalité à venir');
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[99999] flex items-center justify-center bg-black/60">
      <div className="bg-white rounded-xl shadow-2xl w-[550px] overflow-hidden">
        {/* Header */}
        <div className="bg-black px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-yellow-400 to-yellow-600 flex items-center justify-center">
              <Download className="w-5 h-5 text-black" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Exporter en .SUB</h2>
              <p className="text-sm text-gray-400">Format universel 100% brodable</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center"
          >
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {exportComplete ? (
            <div className="text-center py-8">
              <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
                <Check className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-xl font-bold mb-2">Export terminé !</h3>
              <p className="text-gray-600">Votre fichier .SUB est prêt.</p>
            </div>
          ) : (
            <>
              {/* Aperçu miniature */}
              <div className="flex gap-4">
                <div className="w-24 h-24 bg-gray-100 rounded-lg border-2 border-gray-200 flex items-center justify-center overflow-hidden">
                  {pattern?.sourceImage ? (
                    <img src={pattern.sourceImage} alt="Aperçu" className="w-full h-full object-contain" />
                  ) : (
                    <Zap className="w-8 h-8 text-gray-400" />
                  )}
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-lg">{gridConfig?.name || 'Grille sans nom'}</h3>
                  <p className="text-sm text-gray-500 mt-1">
                    Format SUB™ — Système Universel de Broderie
                  </p>
                </div>
              </div>

              {/* Infos du projet */}
              {stats && (
                <div className="grid grid-cols-3 gap-3">
                  <div className="bg-gray-50 rounded-lg p-3 text-center">
                    <div className="text-xl font-bold">{stats.width}×{stats.height}</div>
                    <div className="text-xs text-gray-500">Dimensions</div>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-3 text-center">
                    <div className="text-xl font-bold">{stats.totalPoints.toLocaleString()}</div>
                    <div className="text-xs text-gray-500">Points totaux</div>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-3 text-center">
                    <div className="text-xl font-bold">{stats.dmcCount}</div>
                    <div className="text-xs text-gray-500">Couleurs DMC</div>
                  </div>
                  <div className="bg-yellow-50 rounded-lg p-3 text-center border border-yellow-200">
                    <div className="text-xl font-bold text-yellow-700">{stats.subPoints}</div>
                    <div className="text-xs text-yellow-600">Points SUB™</div>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-3 text-center">
                    <div className="text-xl font-bold">{stats.subTypesCount}</div>
                    <div className="text-xs text-gray-500">Types SUB</div>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-3 text-center">
                    <div className="text-xl font-bold">~{stats.estimatedSize} Ko</div>
                    <div className="text-xs text-gray-500">Taille estimée</div>
                  </div>
                </div>
              )}

              {/* Contenu du fichier */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Shield className="w-4 h-4 text-blue-600" />
                  <span className="text-sm font-semibold text-blue-800">Contenu du fichier .SUB</span>
                </div>
                <ul className="text-xs text-blue-700 space-y-1">
                  <li>✓ Grille complète (sans trou)</li>
                  <li>✓ Palette DMC optimisée</li>
                  <li>✓ Symboles affectés</li>
                  <li>✓ Points SUB™ utilisés</li>
                  <li>✓ Métadonnées projet</li>
                  <li>✓ Hash d'intégrité SUB</li>
                </ul>
              </div>

              {/* Boutons d'export */}
              <div className="space-y-2">
                <Button
                  onClick={handleExportSub}
                  disabled={isExporting || !pattern}
                  className="w-full h-12 bg-gradient-to-r from-yellow-400 to-yellow-500 hover:from-yellow-500 hover:to-yellow-600 text-black font-bold"
                >
                  {isExporting ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Export en cours...
                    </>
                  ) : (
                    <>
                      <Zap className="w-5 h-5 mr-2" />
                      Exporter en .SUB
                    </>
                  )}
                </Button>
                
                <div className="grid grid-cols-3 gap-2">
                  <Button variant="outline" onClick={handleExportPDF} className="gap-1">
                    <FileText className="w-4 h-4" />
                    PDF HD
                  </Button>
                  <Button variant="outline" onClick={handleExportPNG} className="gap-1">
                    <Image className="w-4 h-4" />
                    PNG
                  </Button>
                  <Button variant="outline" onClick={handleExportJPEG} className="gap-1">
                    <Image className="w-4 h-4" />
                    JPEG
                  </Button>
                </div>
              </div>
            </>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t bg-gray-50 flex items-center justify-between">
          <p className="text-xs text-gray-500">
            <span className="font-semibold text-yellow-600">SUB™</span> — Universel · Léger · Fidèle · 100% brodable
          </p>
          <Button variant="outline" onClick={onClose}>
            {exportComplete ? 'Fermer' : 'Annuler'}
          </Button>
        </div>
      </div>
    </div>
  );
}