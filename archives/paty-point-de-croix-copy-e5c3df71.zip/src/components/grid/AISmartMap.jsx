import React, { useState, useEffect, useRef } from "react";
import { ChevronDown, Search, Target, MousePointer, Droplet } from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';

export default function AISmartMap({ 
  pattern,
  gridConfig,
  canvasSize,
  onNavigate,
  projectId = 'default'
}) {
  const STORAGE_KEY = `aiSmartMap_${projectId}`;
  
  // États
  const [isMinimized, setIsMinimized] = useState(false);
  const [position, setPosition] = useState({ x: 20, y: window.innerHeight - 380 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  
  // Modes
  const [loupeActive, setLoupeActive] = useState(false);
  const [suivreCurseur, setSuivreCurseur] = useState(false);
  const [iaFocus, setIaFocus] = useState(false);
  
  // Refs
  const mapRef = useRef(null);
  const miniCanvasRef = useRef(null);
  
  // Charger l'état sauvegardé
  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        const state = JSON.parse(saved);
        setPosition(state.position || position);
        setIsMinimized(state.isMinimized || false);
        setLoupeActive(state.loupeActive || false);
        setSuivreCurseur(state.suivreCurseur || false);
        setIaFocus(state.iaFocus || false);
      } catch (e) {
        console.error('Erreur chargement état AISmartMap:', e);
      }
    }
  }, [projectId]);
  
  // Sauvegarder l'état
  useEffect(() => {
    const state = {
      position,
      isMinimized,
      loupeActive,
      suivreCurseur,
      iaFocus
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }, [position, isMinimized, loupeActive, suivreCurseur, iaFocus, STORAGE_KEY]);
  
  // Dessiner la mini-carte
  useEffect(() => {
    if (!miniCanvasRef.current || !pattern || isMinimized) return;
    
    const canvas = miniCanvasRef.current;
    const ctx = canvas.getContext('2d');
    const w = 220;
    const h = 180;
    
    canvas.width = w;
    canvas.height = h;
    
    // Fond
    ctx.fillStyle = '#0a0a0a';
    ctx.fillRect(0, 0, w, h);
    
    // Image du pattern
    if (pattern.sourceImage) {
      const img = new Image();
      img.onload = () => {
        const scale = Math.min(w / pattern.width, h / pattern.height);
        const drawW = pattern.width * scale;
        const drawH = pattern.height * scale;
        const offsetX = (w - drawW) / 2;
        const offsetY = (h - drawH) / 2;
        
        ctx.save();
        ctx.globalAlpha = iaFocus ? 0.4 : 0.6;
        ctx.drawImage(img, offsetX, offsetY, drawW, drawH);
        ctx.restore();
        
        // IA-Focus overlay
        if (iaFocus && pattern.colorPalette) {
          drawIAFocusOverlay(ctx, offsetX, offsetY, drawW, drawH);
        }
        
        // Grille 10x10
        ctx.strokeStyle = 'rgba(100, 100, 100, 0.3)';
        ctx.lineWidth = 1;
        for (let i = 0; i <= 10; i++) {
          const x = offsetX + (drawW / 10) * i;
          const y = offsetY + (drawH / 10) * i;
          ctx.beginPath();
          ctx.moveTo(x, offsetY);
          ctx.lineTo(x, offsetY + drawH);
          ctx.stroke();
          ctx.beginPath();
          ctx.moveTo(offsetX, y);
          ctx.lineTo(offsetX + drawW, y);
          ctx.stroke();
        }
        
        // Point rouge central
        ctx.fillStyle = '#ff0000';
        ctx.beginPath();
        ctx.arc(w / 2, h / 2, 4, 0, Math.PI * 2);
        ctx.fill();
        
        // Cadre bleu (viewport)
        drawViewportFrame(ctx, offsetX, offsetY, drawW, drawH);
      };
      img.src = pattern.sourceImage;
    } else {
      // Grille simple si pas d'image
      ctx.strokeStyle = 'rgba(100, 100, 100, 0.5)';
      ctx.lineWidth = 1;
      for (let i = 0; i <= 10; i++) {
        const x = (w / 10) * i;
        const y = (h / 10) * i;
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }
      
      ctx.fillStyle = '#ff0000';
      ctx.beginPath();
      ctx.arc(w / 2, h / 2, 4, 0, Math.PI * 2);
      ctx.fill();
      
      drawViewportFrame(ctx, 0, 0, w, h);
    }
  }, [pattern, iaFocus, gridConfig, canvasSize, isMinimized]);
  
  const drawViewportFrame = (ctx, offsetX, offsetY, drawW, drawH) => {
    if (!gridConfig || !canvasSize.width) return;
    
    const viewWidthInGrid = canvasSize.width / (gridConfig.taille_case * gridConfig.zoom);
    const viewHeightInGrid = canvasSize.height / (gridConfig.taille_case * gridConfig.zoom);
    
    const centerCol = -gridConfig.offset_x / (gridConfig.taille_case * gridConfig.zoom) + viewWidthInGrid / 2;
    const centerRow = -gridConfig.offset_y / (gridConfig.taille_case * gridConfig.zoom) + viewHeightInGrid / 2;
    
    const scaleX = drawW / gridConfig.nb_colonnes;
    const scaleY = drawH / gridConfig.nb_lignes;
    
    const frameX = offsetX + (centerCol - viewWidthInGrid / 2) * scaleX;
    const frameY = offsetY + (centerRow - viewHeightInGrid / 2) * scaleY;
    const frameW = viewWidthInGrid * scaleX;
    const frameH = viewHeightInGrid * scaleY;
    
    ctx.strokeStyle = '#4da6ff';
    ctx.lineWidth = 2;
    ctx.strokeRect(frameX, frameY, frameW, frameH);
  };
  
  const drawIAFocusOverlay = (ctx, offsetX, offsetY, drawW, drawH) => {
    if (!pattern.symbolGrid) return;
    
    const cellW = drawW / pattern.width;
    const cellH = drawH / pattern.height;
    
    // Carte de chaleur basique : zones avec plus de couleurs différentes
    for (let row = 0; row < pattern.height; row += 5) {
      for (let col = 0; col < pattern.width; col += 5) {
        const colors = new Set();
        for (let dr = 0; dr < 5 && row + dr < pattern.height; dr++) {
          for (let dc = 0; dc < 5 && col + dc < pattern.width; dc++) {
            const cell = pattern.symbolGrid[row + dr]?.[col + dc];
            if (cell) colors.add(cell.colorId);
          }
        }
        
        if (colors.size > 2) {
          const intensity = Math.min(colors.size / 5, 1);
          ctx.fillStyle = `rgba(255, 230, 102, ${intensity * 0.3})`;
          ctx.fillRect(
            offsetX + col * cellW,
            offsetY + row * cellH,
            cellW * 5,
            cellH * 5
          );
        }
      }
    }
  };
  
  // Gestion du drag
  const handleMouseDown = (e) => {
    if (e.target.closest('.no-drag')) return;
    setIsDragging(true);
    setDragOffset({
      x: e.clientX - position.x,
      y: e.clientY - position.y
    });
  };
  
  useEffect(() => {
    if (!isDragging) return;
    
    const handleMouseMove = (e) => {
      let newX = e.clientX - dragOffset.x;
      let newY = e.clientY - dragOffset.y;
      
      // Snap aux coins
      const SNAP_DISTANCE = 30;
      const w = isMinimized ? 60 : 260;
      const h = isMinimized ? 60 : 340;
      
      if (newX < SNAP_DISTANCE) newX = 20;
      if (newX + w > window.innerWidth - SNAP_DISTANCE) newX = window.innerWidth - w - 20;
      if (newY < SNAP_DISTANCE) newY = 80;
      if (newY + h > window.innerHeight - SNAP_DISTANCE) newY = window.innerHeight - h - 20;
      
      setPosition({ x: newX, y: newY });
    };
    
    const handleMouseUp = () => {
      setIsDragging(false);
    };
    
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
    
    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging, dragOffset, isMinimized]);
  
  // Clic dans la mini-carte pour navigation
  const handleCanvasClick = (e) => {
    if (!pattern || !onNavigate) return;
    
    const rect = miniCanvasRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    const w = 220;
    const h = 180;
    const scale = Math.min(w / pattern.width, h / pattern.height);
    const drawW = pattern.width * scale;
    const drawH = pattern.height * scale;
    const offsetX = (w - drawW) / 2;
    const offsetY = (h - drawH) / 2;
    
    const gridCol = ((x - offsetX) / drawW) * pattern.width;
    const gridRow = ((y - offsetY) / drawH) * pattern.height;
    
    if (gridCol >= 0 && gridCol < pattern.width && gridRow >= 0 && gridRow < pattern.height) {
      onNavigate(
        gridCol * gridConfig.taille_case,
        gridRow * gridConfig.taille_case
      );
    }
  };
  
  const handleRecenter = () => {
    const centerX = (gridConfig.nb_colonnes * gridConfig.taille_case * gridConfig.zoom) / 2;
    const centerY = (gridConfig.nb_lignes * gridConfig.taille_case * gridConfig.zoom) / 2;
    onNavigate?.(centerX, centerY);
  };
  
  if (!pattern) return null;
  
  // Mode minimisé
  if (isMinimized) {
    return (
      <div
        ref={mapRef}
        style={{
          position: 'fixed',
          left: position.x,
          top: position.y,
          width: 60,
          height: 60,
          background: 'rgba(20, 20, 20, 0.95)',
          borderRadius: 8,
          border: '1px solid rgba(200, 200, 200, 0.3)',
          cursor: isDragging ? 'grabbing' : 'grab',
          zIndex: 9998,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          userSelect: 'none'
        }}
        onMouseDown={handleMouseDown}
        onClick={() => setIsMinimized(false)}
      >
        <Target className="w-6 h-6 text-white" />
      </div>
    );
  }
  
  return (
    <TooltipProvider>
      <div
        ref={mapRef}
        style={{
          position: 'fixed',
          left: position.x,
          top: position.y,
          width: 260,
          background: 'rgba(20, 20, 20, 0.95)',
          borderRadius: 8,
          border: '1px solid rgba(200, 200, 200, 0.3)',
          boxShadow: '0 8px 24px rgba(0, 0, 0, 0.5)',
          zIndex: 9998,
          userSelect: 'none',
          backdropFilter: 'blur(8px)'
        }}
      >
        {/* Header */}
        <div
          style={{
            padding: '10px 12px',
            borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            cursor: isDragging ? 'grabbing' : 'grab'
          }}
          onMouseDown={handleMouseDown}
        >
          <span style={{ color: '#fff', fontSize: 13, fontWeight: 600 }}>
            Carte AI Smart™
          </span>
          <button
            className="no-drag"
            onClick={() => setIsMinimized(true)}
            style={{
              background: 'transparent',
              border: 'none',
              cursor: 'pointer',
              padding: 4,
              display: 'flex',
              alignItems: 'center'
            }}
          >
            <ChevronDown className="w-4 h-4 text-white opacity-60 hover:opacity-100" />
          </button>
        </div>
        
        {/* Canvas mini-carte */}
        <div style={{ padding: 12 }}>
          <canvas
            ref={miniCanvasRef}
            className="no-drag"
            onClick={handleCanvasClick}
            style={{
              width: '100%',
              height: 180,
              borderRadius: 6,
              cursor: loupeActive ? 'crosshair' : 'pointer'
            }}
          />
        </div>
        
        {/* Barre d'outils */}
        <div
          style={{
            padding: '8px 12px',
            borderTop: '1px solid rgba(255, 255, 255, 0.1)',
            display: 'flex',
            gap: 8,
            justifyContent: 'space-between'
          }}
        >
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                className="no-drag"
                onClick={() => setLoupeActive(!loupeActive)}
                style={{
                  flex: 1,
                  padding: '8px 0',
                  background: loupeActive ? 'rgba(77, 166, 255, 0.2)' : 'rgba(50, 50, 50, 0.8)',
                  border: '1px solid rgba(200, 200, 200, 0.2)',
                  borderRadius: 6,
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  position: 'relative'
                }}
              >
                <Search className="w-4 h-4 text-white" />
                {loupeActive && (
                  <div style={{
                    position: 'absolute',
                    top: 4,
                    right: 4,
                    width: 6,
                    height: 6,
                    background: '#4da6ff',
                    borderRadius: '50%'
                  }} />
                )}
              </button>
            </TooltipTrigger>
            <TooltipContent><p>Loupe dynamique</p></TooltipContent>
          </Tooltip>
          
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                className="no-drag"
                onClick={handleRecenter}
                style={{
                  flex: 1,
                  padding: '8px 0',
                  background: 'rgba(50, 50, 50, 0.8)',
                  border: '1px solid rgba(200, 200, 200, 0.2)',
                  borderRadius: 6,
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center'
                }}
              >
                <Target className="w-4 h-4 text-white" />
              </button>
            </TooltipTrigger>
            <TooltipContent><p>Revenir au centre</p></TooltipContent>
          </Tooltip>
          
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                className="no-drag"
                onClick={() => setSuivreCurseur(!suivreCurseur)}
                style={{
                  flex: 1,
                  padding: '8px 0',
                  background: suivreCurseur ? 'rgba(77, 166, 255, 0.2)' : 'rgba(50, 50, 50, 0.8)',
                  border: '1px solid rgba(200, 200, 200, 0.2)',
                  borderRadius: 6,
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  position: 'relative'
                }}
              >
                <MousePointer className="w-4 h-4 text-white" />
                {suivreCurseur && (
                  <div style={{
                    position: 'absolute',
                    top: 4,
                    right: 4,
                    width: 6,
                    height: 6,
                    background: '#4da6ff',
                    borderRadius: '50%'
                  }} />
                )}
              </button>
            </TooltipTrigger>
            <TooltipContent><p>Suivre le curseur</p></TooltipContent>
          </Tooltip>
          
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                className="no-drag"
                onClick={() => setIaFocus(!iaFocus)}
                style={{
                  flex: 1,
                  padding: '8px 0',
                  background: iaFocus ? 'rgba(255, 230, 102, 0.2)' : 'rgba(50, 50, 50, 0.8)',
                  border: '1px solid rgba(200, 200, 200, 0.2)',
                  borderRadius: 6,
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  position: 'relative'
                }}
              >
                <Droplet className="w-4 h-4 text-white" />
                {iaFocus && (
                  <div style={{
                    position: 'absolute',
                    top: 4,
                    right: 4,
                    width: 6,
                    height: 6,
                    background: '#ffe066',
                    borderRadius: '50%'
                  }} />
                )}
              </button>
            </TooltipTrigger>
            <TooltipContent><p>IA-Focus (zones détaillées)</p></TooltipContent>
          </Tooltip>
        </div>
      </div>
    </TooltipProvider>
  );
}