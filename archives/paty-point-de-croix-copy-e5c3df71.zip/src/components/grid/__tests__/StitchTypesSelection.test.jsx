/**
 * Tests pour le module Étape Types de Points
 * Valide l'UI, l'IA, et la navigation
 */

import { analyzeImageForStitchTypes, applyStitchTypeRules, STITCH_TYPES } from '../stitchTypes';

// ==================== TESTS UI ====================

describe('UI - Affichage écran', () => {
  test('Affiche le titre "Étape 2 · Types de points de broderie"', () => {
    const title = document.querySelector('h2');
    expect(title?.textContent).toContain('Étape 2');
  });

  test('Affiche les 3 colonnes (aperçu, IA, sélection)', () => {
    const columns = document.querySelectorAll('.grid > div');
    expect(columns.length).toBe(3);
  });

  test('Affiche le bouton "Ignorer" en haut à droite', () => {
    const skipBtn = document.querySelector('button:contains("Ignorer")');
    expect(skipBtn).toBeTruthy();
  });

  test('Affiche le bouton "Valider ces types de points" en bas', () => {
    const validateBtn = document.querySelector('button:contains("Valider")');
    expect(validateBtn).toBeTruthy();
  });
});

describe('UI - Comportement switches', () => {
  test('Point de croix complet est toujours ON et verrouillé', () => {
    const fullStitchSwitch = document.querySelector('[data-type="full"] input');
    expect(fullStitchSwitch?.checked).toBe(true);
    expect(fullStitchSwitch?.disabled).toBe(true);
  });

  test('Tous les autres switches sont activables', () => {
    const switches = document.querySelectorAll('[data-type]:not([data-type="full"]) input');
    switches.forEach(sw => {
      expect(sw.disabled).toBe(false);
    });
  });

  test('Cliquer sur un switch change son état', () => {
    const halfStitchSwitch = document.querySelector('[data-type="half"] input');
    const initialState = halfStitchSwitch?.checked;
    halfStitchSwitch?.click();
    expect(halfStitchSwitch?.checked).toBe(!initialState);
  });

  test('Switch IA Mix active l\'optimisation automatique', () => {
    const aiMixSwitch = document.querySelector('[data-type="ai-mix"] input');
    aiMixSwitch?.click();
    expect(aiMixSwitch?.checked).toBe(true);
    // Vérifier que plusieurs types sont activés automatiquement
    const enabledCount = document.querySelectorAll('input:checked').length;
    expect(enabledCount).toBeGreaterThan(3);
  });
});

describe('UI - Déploiement colonne droite', () => {
  test('Affiche 12 types de points + IA Mix', () => {
    const stitchItems = document.querySelectorAll('[data-stitch-item]');
    expect(stitchItems.length).toBe(13);
  });

  test('Chaque type a un pictogramme, nom, description', () => {
    const items = document.querySelectorAll('[data-stitch-item]');
    items.forEach(item => {
      expect(item.querySelector('.icon')).toBeTruthy();
      expect(item.querySelector('.name')).toBeTruthy();
      expect(item.querySelector('.description')).toBeTruthy();
    });
  });

  test('Lien "Tout en points de croix simples" désactive tout', () => {
    const simplifyLink = document.querySelector('[data-action="simplify"]');
    simplifyLink?.click();
    
    const checkedSwitches = document.querySelectorAll('input:checked:not([disabled])');
    expect(checkedSwitches.length).toBe(0);
  });
});

describe('UI - Mode Débutante', () => {
  test('Active uniquement croix, demi-point, backstitch', () => {
    const beginnerMode = document.querySelector('[value="beginner"]');
    beginnerMode?.click();
    
    const enabledTypes = Array.from(document.querySelectorAll('input:checked'))
      .map(el => el.dataset.type);
    
    expect(enabledTypes).toEqual(expect.arrayContaining(['full', 'half', 'backstitch']));
    expect(enabledTypes.length).toBe(3);
  });

  test('Désactive tous les points avancés', () => {
    const beginnerMode = document.querySelector('[value="beginner"]');
    beginnerMode?.click();
    
    const advancedTypes = ['bead', 'metallic', 'satin', 'bullion', 'couching'];
    advancedTypes.forEach(type => {
      const sw = document.querySelector(`[data-type="${type}"] input`);
      expect(sw?.checked).toBe(false);
    });
  });
});

describe('UI - Mode Avancée', () => {
  test('Active tous les types de points', () => {
    const advancedMode = document.querySelector('[value="advanced"]');
    advancedMode?.click();
    
    const enabledTypes = document.querySelectorAll('input:checked');
    expect(enabledTypes.length).toBeGreaterThan(5);
  });

  test('Active perles, métalliques, satin, etc', () => {
    const advancedMode = document.querySelector('[value="advanced"]');
    advancedMode?.click();
    
    const advancedTypes = ['bead', 'metallic', 'satin'];
    advancedTypes.forEach(type => {
      const sw = document.querySelector(`[data-type="${type}"] input`);
      expect(sw?.checked).toBe(true);
    });
  });
});

// ==================== TESTS IA ====================

describe('IA - Analyse contours', () => {
  test('Détecte les contours nets (> 15%)', () => {
    const imageData = createMockImageData({
      edgePercent: 40
    });
    
    const analysis = analyzeImageForStitchTypes(imageData, 100, 100);
    expect(analysis.backstitch).toBe(true);
  });

  test('Pas de contours nets (< 15%) = pas de backstitch', () => {
    const imageData = createMockImageData({
      edgePercent: 10
    });
    
    const analysis = analyzeImageForStitchTypes(imageData, 100, 100);
    expect(analysis.backstitch).toBe(false);
  });
});

describe('IA - Mapping propositions', () => {
  test('Zones lumineuses (> 8%) → Perles', () => {
    const imageData = createMockImageData({
      brightPercent: 10
    });
    
    const analysis = analyzeImageForStitchTypes(imageData, 100, 100);
    expect(analysis.bead).toBe(true);
  });

  test('Zones dorées/argentées (> 5%) → Métalliques', () => {
    const imageData = createMockImageData({
      metallicPercent: 8
    });
    
    const analysis = analyzeImageForStitchTypes(imageData, 100, 100);
    expect(analysis.metallic).toBe(true);
  });

  test('Zones douces (< 30% contours) → Demi-points', () => {
    const imageData = createMockImageData({
      edgePercent: 20
    });
    
    const analysis = analyzeImageForStitchTypes(imageData, 100, 100);
    expect(analysis.half).toBe(true);
  });

  test('Micro détails (> 5% lumineux) → Fractionnés', () => {
    const imageData = createMockImageData({
      brightPercent: 6
    });
    
    const analysis = analyzeImageForStitchTypes(imageData, 100, 100);
    expect(analysis.quarter).toBe(true);
  });
});

describe('IA - IA Mix', () => {
  test('IA Mix active automatiquement les types recommandés', () => {
    const imageData = createMockImageData({
      edgePercent: 45,
      brightPercent: 12,
      metallicPercent: 7
    });
    
    const analysis = analyzeImageForStitchTypes(imageData, 100, 100);
    
    expect(analysis.backstitch).toBe(true);
    expect(analysis.bead).toBe(true);
    expect(analysis.metallic).toBe(true);
  });

  test('IA Mix optimise le nombre de types', () => {
    const imageData = createMockImageData({
      edgePercent: 50,
      brightPercent: 35
    });
    
    const analysis = analyzeImageForStitchTypes(imageData, 100, 100);
    const enabledCount = Object.values(analysis).filter(v => v === true).length;
    
    // Ne devrait pas activer TOUS les types, juste les pertinents
    expect(enabledCount).toBeLessThan(Object.keys(STITCH_TYPES).length);
    expect(enabledCount).toBeGreaterThan(2);
  });
});

// ==================== TESTS NAVIGATION ====================

describe('Navigation - Bouton Ignorer', () => {
  test('Ignorer désactive tous les types avancés', () => {
    const skipBtn = document.querySelector('[data-action="skip"]');
    skipBtn?.click();
    
    const confirmedTypes = getConfirmedTypes();
    expect(confirmedTypes).toEqual(['full']);
  });

  test('Ignorer passe directement à la grille', () => {
    const skipBtn = document.querySelector('[data-action="skip"]');
    const navigateSpy = jest.fn();
    
    skipBtn?.addEventListener('click', navigateSpy);
    skipBtn?.click();
    
    expect(navigateSpy).toHaveBeenCalled();
  });
});

describe('Navigation - Valider et passer à la grille', () => {
  test('Valider enregistre les types choisis', () => {
    const halfSwitch = document.querySelector('[data-type="half"] input');
    const backSwitch = document.querySelector('[data-type="backstitch"] input');
    
    halfSwitch?.click();
    backSwitch?.click();
    
    const validateBtn = document.querySelector('[data-action="validate"]');
    validateBtn?.click();
    
    const config = getStitchConfig();
    expect(config.typesDePoints.demi).toBe(true);
    expect(config.typesDePoints.back).toBe(true);
  });

  test('Applique les règles de conversion', () => {
    const pattern = createMockPattern();
    const enabledTypes = ['full', 'half'];
    
    const processed = applyStitchTypeRules(pattern, enabledTypes);
    
    // Tous les backstitch doivent être supprimés
    const hasBackstitch = processed.symbolGrid.some(row =>
      row.some(cell => cell?.type === 'backstitch')
    );
    expect(hasBackstitch).toBe(false);
  });

  test('Convertit les types désactivés en croix complètes', () => {
    const pattern = createMockPattern({
      types: ['full', 'half', 'quarter', 'backstitch']
    });
    const enabledTypes = ['full'];
    
    const processed = applyStitchTypeRules(pattern, enabledTypes);
    
    // Tous devraient être convertis en 'full'
    const allFull = processed.symbolGrid.every(row =>
      row.every(cell => !cell || cell.type === 'full')
    );
    expect(allFull).toBe(true);
  });
});

describe('Navigation - Retour', () => {
  test('Bouton Retour ferme le dialog', () => {
    const backBtn = document.querySelector('[data-action="back"]');
    const closeSpy = jest.fn();
    
    backBtn?.addEventListener('click', closeSpy);
    backBtn?.click();
    
    expect(closeSpy).toHaveBeenCalled();
  });

  test('Retour ne sauvegarde pas les changements', () => {
    const halfSwitch = document.querySelector('[data-type="half"] input');
    halfSwitch?.click();
    
    const backBtn = document.querySelector('[data-action="back"]');
    backBtn?.click();
    
    const config = getStitchConfig();
    expect(config).toBeNull();
  });
});

// ==================== HELPERS ====================

function createMockImageData({ edgePercent = 0, brightPercent = 0, metallicPercent = 0 }) {
  const size = 100;
  const totalPixels = size * size;
  const imageData = new Uint8ClampedArray(totalPixels * 4);
  
  for (let i = 0; i < totalPixels; i++) {
    const idx = i * 4;
    
    // Simuler les pixels selon les pourcentages
    if (i < totalPixels * (brightPercent / 100)) {
      imageData[idx] = 255;
      imageData[idx + 1] = 255;
      imageData[idx + 2] = 255;
    } else if (i < totalPixels * (metallicPercent / 100)) {
      imageData[idx] = 220;
      imageData[idx + 1] = 200;
      imageData[idx + 2] = 100;
    } else {
      imageData[idx] = 128;
      imageData[idx + 1] = 128;
      imageData[idx + 2] = 128;
    }
    
    imageData[idx + 3] = 255; // Alpha
  }
  
  return imageData;
}

function createMockPattern({ types = ['full'] } = {}) {
  return {
    width: 10,
    height: 10,
    symbolGrid: Array(10).fill(null).map((_, row) =>
      Array(10).fill(null).map((_, col) => ({
        col,
        row,
        colorId: 'color-1',
        type: types[Math.floor(Math.random() * types.length)],
        done: false
      }))
    ),
    colorPalette: [
      { id: 'color-1', hex: '#FF0000', name: 'Rouge' }
    ]
  };
}

function getConfirmedTypes() {
  return window.__lastConfirmedTypes || [];
}

function getStitchConfig() {
  return window.__lastStitchConfig || null;
}