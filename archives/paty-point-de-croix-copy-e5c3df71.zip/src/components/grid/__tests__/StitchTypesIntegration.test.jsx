/**
 * Tests d'intégration - Types de Points & Export PDF
 * Validation complète du flux utilisateur et de la logique métier
 */

import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { analyserImage, construireCartographie, calculerSuggestionTypesDePoints, appliquerTypesDePoints } from '../stitchTypesEngine';
import { exporterPDFAvecTypesDePoints } from '../pdfExportStitchTypes';

// ========== 1. TEST FLUX COMPLET ==========

describe('Flux complet - Import → Sélection Types → Grille → Export', () => {
  test('Flux complet sans erreur', async () => {
    // ÉTAPE 1: Import visuel
    const file = new File(['dummy'], 'test.jpg', { type: 'image/jpeg' });
    const importDialog = render(<ImportImageDialog open={true} />);
    
    const fileInput = screen.getByLabelText(/importer une image/i);
    fireEvent.change(fileInput, { target: { files: [file] } });
    
    await waitFor(() => {
      expect(screen.getByText(/générer la grille/i)).toBeInTheDocument();
    });
    
    // Vérifier que la grille de base est créée
    fireEvent.click(screen.getByText(/générer la grille/i));
    
    await waitFor(() => {
      expect(screen.getByText(/étape 2/i)).toBeInTheDocument();
    });

    // ÉTAPE 2: Écran Types de points
    expect(screen.getByText(/types de points de broderie/i)).toBeInTheDocument();
    expect(screen.getByText(/ignorer/i)).toBeInTheDocument();
    expect(screen.getByText(/valider ces types/i)).toBeInTheDocument();
    
    // Vérifier les 3 colonnes
    expect(screen.getByText(/aperçu/i)).toBeInTheDocument();
    expect(screen.getByText(/proposition automatique/i)).toBeInTheDocument();
    expect(screen.getByText(/types de points inclus/i)).toBeInTheDocument();

    // ÉTAPE 3: Validation
    fireEvent.click(screen.getByText(/valider ces types/i));
    
    await waitFor(() => {
      expect(screen.getByTestId('grid-canvas')).toBeInTheDocument();
    });
    
    // Vérifier palette DMC visible
    expect(screen.getByTestId('dmc-palette')).toBeInTheDocument();

    // ÉTAPE 4: Export PDF
    fireEvent.click(screen.getByText(/exporter/i));
    fireEvent.click(screen.getByLabelText(/pdf complet/i));
    fireEvent.click(screen.getByText(/exporter/i));
    
    await waitFor(() => {
      expect(screen.getByText(/exporté avec succès/i)).toBeInTheDocument();
    });
  });

  test('Dimensionnement correct de la grille', () => {
    const config = {
      nb_colonnes: 300,
      nb_lignes: 300,
      repere_central: true
    };
    
    expect(config.nb_colonnes).toBe(300);
    expect(config.nb_lignes).toBe(300);
    expect(config.repere_central).toBe(true);
  });
});

// ========== 2. TEST UI ÉTAPE 2 ==========

describe('UI - Étape 2 Types de Points', () => {
  test('Affichage initial correct', () => {
    render(<StitchTypesSelectionDialog open={true} imageAnalysis={{}} />);
    
    // Switch IA activé par défaut
    const iaSwitch = screen.getByRole('switch', { name: /recommandation automatique/i });
    expect(iaSwitch).toBeChecked();
    
    // Point de croix toujours actif et verrouillé
    const fullStitchSwitch = screen.getByTestId('switch-full');
    expect(fullStitchSwitch).toBeChecked();
    expect(fullStitchSwitch).toBeDisabled();
  });

  test('Mode débutante désactive points spéciaux', () => {
    render(<StitchTypesSelectionDialog open={true} />);
    
    // Sélectionner mode débutante
    fireEvent.click(screen.getByLabelText(/mode débutante/i));
    
    // Vérifier désactivation points avancés
    expect(screen.getByTestId('switch-bead')).not.toBeChecked();
    expect(screen.getByTestId('switch-metallic')).not.toBeChecked();
    expect(screen.getByTestId('switch-satin')).not.toBeChecked();
    expect(screen.getByTestId('switch-bullion')).not.toBeChecked();
    expect(screen.getByTestId('switch-couching')).not.toBeChecked();
    
    // Vérifier activation points de base uniquement
    expect(screen.getByTestId('switch-full')).toBeChecked();
    expect(screen.getByTestId('switch-half')).toBeChecked();
    expect(screen.getByTestId('switch-backstitch')).toBeChecked();
  });

  test('Mode avancée active tous les types', () => {
    render(<StitchTypesSelectionDialog open={true} />);
    
    fireEvent.click(screen.getByLabelText(/mode avancée/i));
    
    const allSwitches = screen.getAllByRole('switch');
    const checkedCount = allSwitches.filter(s => s.checked && !s.disabled).length;
    
    expect(checkedCount).toBeGreaterThan(8);
  });

  test('IA Mix modifie automatiquement les types', () => {
    const mockAnalysis = {
      full: true,
      half: false,
      backstitch: true,
      bead: true,
      metallic: false
    };
    
    render(<StitchTypesSelectionDialog open={true} imageAnalysis={mockAnalysis} />);
    
    // Activer IA Mix
    const aiMixSwitch = screen.getByTestId('switch-ai-mix');
    fireEvent.click(aiMixSwitch);
    
    // Vérifier que les types recommandés sont activés
    expect(screen.getByTestId('switch-backstitch')).toBeChecked();
    expect(screen.getByTestId('switch-bead')).toBeChecked();
    expect(screen.getByTestId('switch-metallic')).not.toBeChecked();
  });

  test('Bouton Ignorer active uniquement croix', () => {
    render(<StitchTypesSelectionDialog open={true} onConfirm={jest.fn()} />);
    
    fireEvent.click(screen.getByText(/ignorer.*tout en points de croix/i));
    
    const config = { typesDePoints: { full: true } };
    expect(Object.keys(config.typesDePoints).length).toBe(1);
  });

  test('Lien "Tout en points de croix simples" désactive tout', () => {
    render(<StitchTypesSelectionDialog open={true} />);
    
    fireEvent.click(screen.getByText(/tout en points de croix simples/i));
    
    const activeSwitches = screen.getAllByRole('switch')
      .filter(s => s.checked && !s.disabled);
    
    expect(activeSwitches.length).toBe(1); // Seulement full
  });
});

// ========== 3. TEST MOTEUR IA ==========

describe('Moteur IA - Attribution des types de points', () => {
  test('Analyse IA détecte les contours', () => {
    const imageData = createMockImageWithEdges(50); // 50% contours
    const analysis = analyserImage(imageData, 100, 100);
    
    expect(analysis.pourcentageContoursFort).toBeGreaterThan(40);
    
    const suggestions = calculerSuggestionTypesDePoints(analysis, {});
    expect(suggestions.backstitch).toBe(true);
  });

  test('Analyse IA détecte les zones douces', () => {
    const imageData = createMockImageWithSoftZones(30); // 30% zones douces
    const analysis = analyserImage(imageData, 100, 100);
    
    expect(analysis.pourcentageZonesFaibleContraste).toBeGreaterThan(25);
    
    const suggestions = calculerSuggestionTypesDePoints(analysis, {});
    expect(suggestions.half).toBe(true);
  });

  test('Analyse IA détecte les points lumineux', () => {
    const imageData = createMockImageWithBrightSpots(7); // 7% points lumineux
    const analysis = analyserImage(imageData, 100, 100);
    
    expect(analysis.pourcentagePointsLumiere).toBeGreaterThan(6);
    
    const suggestions = calculerSuggestionTypesDePoints(analysis, {});
    expect(suggestions.bead).toBe(true);
  });

  test('Attribution correcte dans la grille', () => {
    const pattern = createMockPattern();
    const cartographie = construireCartographie(pattern, {});
    
    const selection = {
      full: true,
      half: true,
      backstitch: true,
      frenchknot: true
    };
    
    const processed = appliquerTypesDePoints(pattern, selection, cartographie);
    
    // Vérifier que différents types ont été assignés
    const types = new Set();
    processed.symbolGrid.flat().forEach(cell => {
      if (cell) types.add(cell.type);
    });
    
    expect(types.size).toBeGreaterThan(1);
    expect(types.has('full')).toBe(true);
  });

  test('IA Mix simplifie les zones denses', () => {
    const pattern = createMockDensePattern();
    const cartographie = construireCartographie(pattern, {});
    
    // Marquer zone comme très dense
    Object.values(cartographie).forEach(c => {
      c.zoneTresDense = true;
    });
    
    const selection = {
      full: true,
      quarter: true,
      satin: true,
      aiMixEnabled: true
    };
    
    const processed = appliquerTypesDePoints(pattern, selection, cartographie);
    
    // Dans les zones denses, IA Mix devrait convertir en croix simples
    const quarterCount = processed.symbolGrid.flat()
      .filter(c => c && c.type === 'quarter').length;
    
    expect(quarterCount).toBe(0); // Simplifiés en 'full'
  });

  test('IA Mix affine les zones peu denses', () => {
    const pattern = createMockSparsePattern();
    const cartographie = construireCartographie(pattern, {});
    
    // Marquer comme zone peu dense avec détail important
    Object.values(cartographie).forEach(c => {
      c.zonePeuDense = true;
      c.estDetailImportant = true;
      c.zoneDouce = true;
    });
    
    const selection = {
      full: true,
      half: true,
      aiMixEnabled: true
    };
    
    const processed = appliquerTypesDePoints(pattern, selection, cartographie);
    
    // Dans les zones peu denses, IA Mix devrait upgrader vers demi
    const halfCount = processed.symbolGrid.flat()
      .filter(c => c && c.type === 'half').length;
    
    expect(halfCount).toBeGreaterThan(0);
  });
});

// ========== 4. TEST PALETTE DMC ==========

describe('Palette DMC - Stats et Menu', () => {
  test('Affichage correct des blocs de couleur', () => {
    const palette = [
      { id: 'c1', hex: '#FF0000', code: 'DMC-321', totalCount: 150, assignedSymbolChar: '●' },
      { id: 'c2', hex: '#00FF00', code: 'DMC-702', totalCount: 200, assignedSymbolChar: '■' }
    ];
    
    render(<DmcBottomPalette colorPalette={palette} />);
    
    // Vérifier affichage
    expect(screen.getByText('DMC-321')).toBeInTheDocument();
    expect(screen.getByText('DMC-702')).toBeInTheDocument();
    expect(screen.getByText('150')).toBeInTheDocument();
    expect(screen.getByText('200')).toBeInTheDocument();
  });

  test('Statistiques par type de point correctes', () => {
    const color = {
      id: 'c1',
      code: 'DMC-310',
      stitchTypeStats: {
        total: 500,
        full: 450,
        half: 30,
        backstitch: 20
      }
    };
    
    expect(color.stitchTypeStats.total).toBe(500);
    expect(color.stitchTypeStats.full + color.stitchTypeStats.half + color.stitchTypeStats.backstitch).toBe(500);
  });

  test('Menu alvéole s\'ouvre au-dessus', () => {
    render(<DmcBottomPalette colorPalette={[{ id: 'c1', hex: '#000' }]} />);
    
    const optionsButton = screen.getByTestId('color-options-c1');
    fireEvent.click(optionsButton);
    
    const menu = screen.getByTestId('color-options-panel');
    expect(menu).toBeVisible();
    expect(menu).toHaveStyle({ zIndex: '9999' });
  });

  test('Actions du menu fonctionnelles', () => {
    const onIsolate = jest.fn();
    const onMerge = jest.fn();
    
    render(
      <DmcBottomPalette 
        colorPalette={[{ id: 'c1', hex: '#000' }]}
        onIsolate={onIsolate}
        onMerge={onMerge}
      />
    );
    
    fireEvent.click(screen.getByTestId('color-options-c1'));
    fireEvent.click(screen.getByText(/isoler/i));
    
    expect(onIsolate).toHaveBeenCalledWith(expect.objectContaining({ id: 'c1' }));
  });
});

// ========== 5. TEST EXPORT PDF ==========

describe('Export PDF - Structure et Contenu', () => {
  test('PDF contient 4 pages minimum', async () => {
    const grid = { name: 'Test', nb_colonnes: 50, nb_lignes: 50 };
    const pattern = createMockPattern();
    const typesActifs = { full: true, half: true, backstitch: true };
    
    const pdfSpy = jest.spyOn(window, 'jsPDF');
    
    await exporterPDFAvecTypesDePoints(grid, pattern, typesActifs);
    
    expect(pdfSpy).toHaveBeenCalled();
    // Vérifier qu'au moins 3 addPage() ont été appelés (page 1 auto + 3 ajouts = 4 pages)
  });

  test('Légende DMC complète dans le PDF', () => {
    const pattern = {
      colorPalette: [
        { code: 'DMC-310', assignedSymbolChar: '●', totalCount: 100, stitchTypeStats: { full: 80, half: 20 } },
        { code: 'DMC-321', assignedSymbolChar: '■', totalCount: 150, stitchTypeStats: { full: 150 } }
      ]
    };
    
    // Simuler la génération du tableau
    pattern.colorPalette.forEach(color => {
      expect(color.code).toMatch(/DMC-\d+/);
      expect(color.assignedSymbolChar).toBeTruthy();
      expect(color.totalCount).toBeGreaterThan(0);
      expect(color.stitchTypeStats.full).toBeDefined();
    });
  });

  test('Instructions techniques présentes pour types activés', () => {
    const typesActifs = {
      full: true,
      bead: true,
      metallic: true,
      couching: false
    };
    
    // Simuler la page d'instructions
    const instructions = [];
    if (typesActifs.bead) instructions.push('Perles');
    if (typesActifs.metallic) instructions.push('Fils métalliques');
    if (typesActifs.couching) instructions.push('Couching');
    
    expect(instructions).toContain('Perles');
    expect(instructions).toContain('Fils métalliques');
    expect(instructions).not.toContain('Couching');
  });

  test('PDF simple sans points avancés', async () => {
    const grid = { name: 'Simple', nb_colonnes: 30, nb_lignes: 30 };
    const pattern = createSimplePattern();
    const typesActifs = { full: true }; // Seulement croix
    
    await exporterPDFAvecTypesDePoints(grid, pattern, typesActifs);
    
    // Vérifier que seul le point de croix est mentionné
    expect(Object.keys(typesActifs).length).toBe(1);
  });
});

// ========== 6. TESTS DE RÉGRESSION ==========

describe('Régression - Scénarios simples', () => {
  test('Grille monochrome uniquement croix', () => {
    const pattern = {
      width: 20,
      height: 20,
      colorPalette: [{ id: 'c1', hex: '#000000', code: 'DMC-310', totalCount: 400 }],
      symbolGrid: Array(20).fill(null).map(() => 
        Array(20).fill({ colorId: 'c1', type: 'full' })
      )
    };
    
    expect(pattern.colorPalette.length).toBe(1);
    
    const allFull = pattern.symbolGrid.every(row =>
      row.every(cell => cell.type === 'full')
    );
    expect(allFull).toBe(true);
  });

  test('Désactivation de tous points avancés respectée', () => {
    const pattern = createMockPattern();
    const selection = {
      full: true,
      half: false,
      quarter: false,
      backstitch: false,
      frenchknot: false,
      bead: false
    };
    
    const processed = appliquerTypesDePoints(pattern, selection, {});
    
    const types = new Set();
    processed.symbolGrid.flat().forEach(cell => {
      if (cell) types.add(cell.type);
    });
    
    expect(types.size).toBe(1);
    expect(types.has('full')).toBe(true);
  });

  test('Grille 2-3 couleurs sans types spéciaux', () => {
    const pattern = {
      colorPalette: [
        { id: 'c1', hex: '#FF0000' },
        { id: 'c2', hex: '#00FF00' },
        { id: 'c3', hex: '#0000FF' }
      ],
      symbolGrid: createMixedColorGrid(3)
    };
    
    expect(pattern.colorPalette.length).toBe(3);
    
    const selection = { full: true };
    const processed = appliquerTypesDePoints(pattern, selection, {});
    
    const allCroix = processed.symbolGrid.flat().every(c => !c || c.type === 'full');
    expect(allCroix).toBe(true);
  });
});

// ========== HELPERS ==========

function createMockImageWithEdges(edgePercentage) {
  const size = 100;
  const data = new Uint8ClampedArray(size * size * 4);
  const edgeCount = Math.floor((size * size * edgePercentage) / 100);
  
  for (let i = 0; i < size * size; i++) {
    const isEdge = i < edgeCount;
    data[i * 4] = isEdge ? 0 : 128;
    data[i * 4 + 1] = isEdge ? 0 : 128;
    data[i * 4 + 2] = isEdge ? 0 : 128;
    data[i * 4 + 3] = 255;
  }
  
  return data;
}

function createMockImageWithSoftZones(softPercentage) {
  const size = 100;
  const data = new Uint8ClampedArray(size * size * 4);
  
  for (let i = 0; i < size * size; i++) {
    const value = i < (size * size * softPercentage / 100) ? 150 : 50;
    data[i * 4] = value;
    data[i * 4 + 1] = value;
    data[i * 4 + 2] = value;
    data[i * 4 + 3] = 255;
  }
  
  return data;
}

function createMockImageWithBrightSpots(brightPercentage) {
  const size = 100;
  const data = new Uint8ClampedArray(size * size * 4);
  
  for (let i = 0; i < size * size; i++) {
    const value = i < (size * size * brightPercentage / 100) ? 250 : 100;
    data[i * 4] = value;
    data[i * 4 + 1] = value;
    data[i * 4 + 2] = value;
    data[i * 4 + 3] = 255;
  }
  
  return data;
}

function createMockPattern() {
  return {
    width: 10,
    height: 10,
    symbolGrid: Array(10).fill(null).map(() =>
      Array(10).fill({ colorId: 'c1', type: 'full' })
    ),
    colorPalette: [{ id: 'c1', hex: '#000000' }]
  };
}

function createMockDensePattern() {
  return {
    width: 20,
    height: 20,
    symbolGrid: Array(20).fill(null).map(() =>
      Array(20).fill({ colorId: 'c1', type: 'quarter' })
    ),
    colorPalette: [{ id: 'c1', hex: '#000000' }]
  };
}

function createMockSparsePattern() {
  return {
    width: 20,
    height: 20,
    symbolGrid: Array(20).fill(null).map((_, y) =>
      Array(20).fill(null).map((_, x) => 
        (x + y) % 5 === 0 ? { colorId: 'c1', type: 'full' } : null
      )
    ),
    colorPalette: [{ id: 'c1', hex: '#000000' }]
  };
}

function createSimplePattern() {
  return {
    width: 10,
    height: 10,
    symbolGrid: Array(10).fill(null).map(() =>
      Array(10).fill({ colorId: 'c1', type: 'full' })
    ),
    colorPalette: [{ id: 'c1', hex: '#FF0000', code: 'DMC-321', totalCount: 100 }]
  };
}

function createMixedColorGrid(colorCount) {
  return Array(10).fill(null).map((_, y) =>
    Array(10).fill(null).map((_, x) => ({
      colorId: `c${(x + y) % colorCount + 1}`,
      type: 'full'
    }))
  );
}