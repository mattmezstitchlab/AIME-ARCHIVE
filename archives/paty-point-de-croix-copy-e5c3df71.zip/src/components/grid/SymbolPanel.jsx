import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { X, ChevronRight, ChevronLeft, Search } from 'lucide-react';
import { cn } from '@/lib/utils';
import { SYMBOL_CATEGORIES, searchSymbols } from './SymbolLibrary';

export default function SymbolPanel({ isOpen, onClose, selectedSymbol, onSymbolSelect }) {
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [hoveredSymbol, setHoveredSymbol] = useState(null);
  const [tempSelectedSymbol, setTempSelectedSymbol] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');

  const handleCategoryClick = (category) => {
    setSelectedCategory(category);
    setSearchQuery('');
  };

  const handleBackToCategories = () => {
    setSelectedCategory(null);
    setTempSelectedSymbol(null);
  };

  const handleSymbolClick = (symbol) => {
    setTempSelectedSymbol(symbol);
  };

  const handleUseSymbol = () => {
    if (tempSelectedSymbol) {
      onSymbolSelect(tempSelectedSymbol.char);
      onClose();
    }
  };

  const searchResults = searchQuery ? searchSymbols(searchQuery) : null;

  return (
    <>
      {/* Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/20 z-40"
          onClick={onClose}
        />
      )}

      {/* Panel coulissant */}
      <div className={cn(
        "fixed right-0 top-0 h-full w-[320px] bg-white shadow-2xl z-50 transition-transform duration-300 ease-in-out flex flex-col",
        isOpen ? "translate-x-0" : "translate-x-full"
      )}>
        {/* En-tête */}
        <div className="border-b border-slate-200 p-4 flex-shrink-0">
          <div className="flex items-center justify-between mb-2">
            <h2 className="text-lg font-bold text-slate-900">Symboles</h2>
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              className="h-8 w-8"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
          <p className="text-xs text-slate-500">
            Sélectionnez un symbole parmi la bibliothèque PATY.
          </p>

          {/* Recherche */}
          {!selectedCategory && (
            <div className="relative mt-3">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input
                placeholder="Rechercher..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9 h-9 text-sm"
              />
            </div>
          )}
        </div>

        {/* Contenu */}
        <div className="flex-1 overflow-y-auto">
          {/* Résultats de recherche */}
          {searchResults && searchResults.length > 0 ? (
            <div className="p-4">
              <div className="text-xs font-medium text-slate-600 mb-3">
                {searchResults.length} résultat{searchResults.length > 1 ? 's' : ''}
              </div>
              <div className="grid grid-cols-6 gap-2">
                {searchResults.map((symbol) => (
                  <button
                    key={symbol.id}
                    onClick={() => {
                      onSymbolSelect(symbol.char);
                      onClose();
                    }}
                    onMouseEnter={() => setHoveredSymbol(symbol)}
                    onMouseLeave={() => setHoveredSymbol(null)}
                    className={cn(
                      "relative w-12 h-12 flex items-center justify-center rounded-lg border-2 transition-all hover:border-blue-400 hover:shadow-md",
                      selectedSymbol === symbol.char
                        ? "border-blue-600 bg-blue-50"
                        : "border-slate-200"
                    )}
                    title={symbol.label}
                  >
                    <span className="text-2xl">{symbol.char}</span>
                    
                    {/* Tooltip */}
                    {hoveredSymbol?.id === symbol.id && (
                      <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 pointer-events-none z-50">
                        <div className="bg-slate-900 text-white text-xs px-2 py-1 rounded whitespace-nowrap">
                          {symbol.label}
                        </div>
                      </div>
                    )}
                  </button>
                ))}
              </div>
            </div>
          ) : searchQuery && !searchResults?.length ? (
            <div className="p-8 text-center text-sm text-slate-500">
              Aucun symbole trouvé
            </div>
          ) : selectedCategory ? (
            /* Grille de symboles */
            <div className="p-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={handleBackToCategories}
                className="mb-4 text-slate-600 hover:text-slate-900"
              >
                <ChevronLeft className="w-4 h-4 mr-1" />
                Catégories
              </Button>

              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-semibold text-slate-900 mb-1">
                    {selectedCategory.name}
                  </h3>
                  <p className="text-xs text-slate-500 mb-4">
                    {selectedCategory.description}
                  </p>
                </div>

                <div className="grid grid-cols-6 gap-2">
                  {selectedCategory.symbols.map((symbol) => (
                    <button
                      key={symbol.id}
                      onClick={() => handleSymbolClick(symbol)}
                      onMouseEnter={() => setHoveredSymbol(symbol)}
                      onMouseLeave={() => setHoveredSymbol(null)}
                      className={cn(
                        "relative w-12 h-12 flex items-center justify-center rounded-lg border-2 transition-all hover:border-blue-400 hover:shadow-md",
                        tempSelectedSymbol?.id === symbol.id
                          ? "border-blue-600 bg-blue-50"
                          : selectedSymbol === symbol.char
                          ? "border-slate-400 bg-slate-50"
                          : "border-slate-200"
                      )}
                      title={symbol.label}
                    >
                      <span className="text-2xl">{symbol.char}</span>
                      
                      {/* Tooltip */}
                      {hoveredSymbol?.id === symbol.id && (
                        <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 pointer-events-none z-50">
                          <div className="bg-slate-900 text-white text-xs px-2 py-1 rounded whitespace-nowrap">
                            {symbol.label}
                          </div>
                        </div>
                      )}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            /* Liste des catégories */
            <div className="p-4 space-y-2">
              {SYMBOL_CATEGORIES.map((category) => (
                <button
                  key={category.id}
                  onClick={() => handleCategoryClick(category)}
                  className="w-full bg-white hover:bg-slate-50 border border-slate-200 rounded-lg p-3 transition-all group text-left"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <h3 className="text-sm font-semibold text-slate-900 mb-1">
                        {category.name}
                      </h3>
                      <p className="text-xs text-slate-500">
                        {category.description}
                      </p>
                      <p className="text-xs text-slate-400 mt-1">
                        {category.symbols.length} symboles
                      </p>
                    </div>
                    <ChevronRight className="w-5 h-5 text-slate-400 group-hover:text-slate-600 transition-colors flex-shrink-0 ml-2" />
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Bouton fixe en bas (seulement si un symbole est sélectionné) */}
        {selectedCategory && tempSelectedSymbol && (
          <div className="border-t border-slate-200 p-4 flex-shrink-0 bg-white">
            <Button
              onClick={handleUseSymbol}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white"
            >
              Utiliser ce symbole
            </Button>
            <div className="mt-2 text-center">
              <span className="text-3xl">{tempSelectedSymbol.char}</span>
              <p className="text-xs text-slate-600 mt-1">
                {tempSelectedSymbol.label}
              </p>
            </div>
          </div>
        )}
      </div>
    </>
  );
}