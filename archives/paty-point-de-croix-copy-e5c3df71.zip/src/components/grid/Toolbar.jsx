import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { 
        ChevronDown,
        ChevronUp,
        Map,
        Image as ImageIcon,
        Type
      } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '../../utils';
import { useSettings } from '../settings/SettingsContext';

export default function Toolbar({ 
  currentTool, 
  onToolSelect,
  onZoomIn,
  onZoomOut,
  onResetZoom,
  onCenter,
  miniMapComponent,
  dailyZoneComponent,
  onOpenElements,
  referenceImage,
  isDailyZoneActive,
  onToggleDailyZone,
  mosaicConfig,
  showMosaicGuides,
  onToggleMosaicGuides
}) {
  const navigate = useNavigate();
  const { settings: userSettings } = useSettings();
  const [showMiniMap, setShowMiniMap] = useState(true);
  const [showDailyZone, setShowDailyZone] = useState(true);
  
  // Apply settings
  const showMinimapFromSettings = userSettings?.showMinimap ?? true;

  return (
    <TooltipProvider delayDuration={500}>
      <div className="bg-white/95 backdrop-blur-sm rounded-2xl shadow-xl border border-slate-200 p-4 space-y-3 w-64">
      {/* Titre principal */}
      <div className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-3">
        Mini-carte
      </div>

      {/* Aperçu du visuel de référence */}
      {referenceImage && (
        <div className="pb-3 border-b border-slate-200">
          <div className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider mb-2 px-1 flex items-center gap-1">
            <ImageIcon className="w-3 h-3" />
            Visuel de référence
          </div>
          <div className="relative w-full aspect-square bg-slate-50 rounded-lg border border-slate-200 overflow-hidden">
            <img 
              src={referenceImage} 
              alt="Référence" 
              className="w-full h-full object-contain"
            />
          </div>
        </div>
      )}

      {/* Mini-carte */}
      {miniMapComponent && showMinimapFromSettings && (
        <div className="pb-3 border-b border-slate-200">
          {showMiniMap && miniMapComponent}
        </div>
      )}
      
      {/* Palette d'outils essentiels */}
      <div className="pb-3 border-b border-slate-200">
        <div className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider mb-2 px-1">
          Outils
        </div>

        {/* Ligne 1: Gomme, Pipette, Zone du jour */}
        <div className="grid grid-cols-3 gap-2 mb-2">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <button
                  onClick={() => onToolSelect('erase')}
                  className={cn(
                    "aspect-square rounded-lg flex items-center justify-center transition-all",
                    currentTool === 'erase'
                      ? "bg-slate-900 text-white"
                      : "bg-slate-100 hover:bg-slate-200 text-slate-700"
                  )}
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3.75 6.75h16.5M6.75 6.75V18c0 .621.504 1.125 1.125 1.125h8.25c.621 0 1.125-.504 1.125-1.125V6.75m-13.5 0L4.5 3h15l1.5 3.75M10.5 11.25v6m3-6v6" />
                  </svg>
                </button>
              </TooltipTrigger>
              <TooltipContent><p>Gomme (E)</p></TooltipContent>
            </Tooltip>

            <Tooltip>
              <TooltipTrigger asChild>
                <button
                  onClick={() => onToolSelect('symbol-picker')}
                  className={cn(
                    "aspect-square rounded-lg flex items-center justify-center transition-all",
                    currentTool === 'symbol-picker'
                      ? "bg-slate-900 text-white"
                      : "bg-slate-100 hover:bg-slate-200 text-slate-700"
                  )}
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11.25l1.5 1.5.75-.75V8.758l2.276-.61a3 3 0 10-3.675-3.675l-.61 2.277H12l-.75.75 1.5 1.5M15 11.25l-8.47 8.47c-.34.34-.8.53-1.28.53s-.94-.19-1.28-.53l-.97-.97c-.34-.34-.53-.8-.53-1.28s.19-.94.53-1.28l8.47-8.47M15 11.25L18.75 15M2.036 12.322a1.012 1.012 0 010-1.538l1.03-.88a1.012 1.012 0 011.538 0l.88 1.03c.3.35.3.95 0 1.29l-.88 1.03c-.35.3-.95.3-1.29 0l-1.03-.88z" />
                  </svg>
                </button>
              </TooltipTrigger>
              <TooltipContent><p>Pipette de symbole (I)</p></TooltipContent>
            </Tooltip>

            <Tooltip>
              <TooltipTrigger asChild>
                <button
                  onClick={() => onToolSelect('daily-zone')}
                  className={cn(
                    "aspect-square rounded-lg flex items-center justify-center transition-all",
                    currentTool === 'daily-zone'
                      ? "bg-amber-200 text-amber-900"
                      : "bg-slate-100 hover:bg-slate-200 text-slate-700"
                  )}
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" />
                  </svg>
                </button>
              </TooltipTrigger>
              <TooltipContent><p>Zone du jour (Z)</p></TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>

        {/* Ligne 2: Texte/Motif, Sélection, Motifs spéciaux */}
        <div className="grid grid-cols-3 gap-2">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <button
                  onClick={onOpenElements}
                  className={cn(
                    "aspect-square rounded-lg flex items-center justify-center transition-all",
                    "bg-slate-100 hover:bg-slate-200 text-slate-700"
                  )}
                >
                  <Type className="w-5 h-5" />
                </button>
              </TooltipTrigger>
              <TooltipContent><p>Texte / Motif (T)</p></TooltipContent>
            </Tooltip>

            <Tooltip>
              <TooltipTrigger asChild>
                <button
                  onClick={() => onToolSelect('selection')}
                  className={cn(
                    "aspect-square rounded-lg flex items-center justify-center transition-all",
                    currentTool === 'selection'
                      ? "bg-slate-900 text-white"
                      : "bg-slate-100 hover:bg-slate-200 text-slate-700"
                  )}
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 15l-2 5L9 9l11 4-5 2zm0 0l5 5M7.188 2.239l.777 2.897M5.136 7.965l-2.898-.777M13.95 4.05l-2.122 2.122m-5.657 5.656l-2.12 2.122" />
                  </svg>
                </button>
              </TooltipTrigger>
              <TooltipContent><p>Sélection (S)</p></TooltipContent>
            </Tooltip>

            <Tooltip>
              <TooltipTrigger asChild>
                <button
                  onClick={() => onToolSelect('motif')}
                  className={cn(
                    "aspect-square rounded-lg flex items-center justify-center transition-all",
                    currentTool === 'motif' || currentTool === 'place-motif'
                      ? "bg-slate-900 text-white"
                      : "bg-slate-100 hover:bg-slate-200 text-slate-700"
                  )}
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 10l-2 1m0 0l-2-1m2 1v2.5M20 7l-2 1m2-1l-2-1m2 1v2.5M14 4l-2-1-2 1M4 7l2-1M4 7l2 1M4 7v2.5M12 21l-2-1m2 1l2-1m-2 1v-2.5M6 18l-2-1v-2.5M18 18l2-1v-2.5" />
                  </svg>
                </button>
              </TooltipTrigger>
              <TooltipContent><p>Motifs spéciaux (M)</p></TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
      </div>




      </div>
    </TooltipProvider>
  );
}