import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Palette, Edit2, CheckCircle2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import SymbolPickerDialog from './SymbolPickerDialog';
import { SYMBOL_CATEGORIES } from './SymbolLibrary';

export default function BottomPalette({
  colorPalette,
  onColorUpdate,
  selectedColorId,
  selectedSymbolId,
  onColorSelect,
  onMarkColorAsDone,
  onStartMarkingZone
}) {
  const [editingColorId, setEditingColorId] = useState(null);
  const [showSymbolPicker, setShowSymbolPicker] = useState(false);
  const [activeTab, setActiveTab] = useState('colors');

  const handleSymbolChange = (symbol) => {
    if (editingColorId) {
      const color = colorPalette.find(c => c.id === editingColorId);
      onColorUpdate({
        ...color,
        assignedSymbolId: symbol.id,
        assignedSymbolChar: symbol.char
      });
      setShowSymbolPicker(false);
      setEditingColorId(null);
    }
  };

  const handleNameChange = (colorId, newName) => {
    const color = colorPalette.find(c => c.id === colorId);
    onColorUpdate({ ...color, name: newName });
  };

  // Trouver la couleur sélectionnée (via colorId ou symbolId)
  const selectedColor = colorPalette?.find(c => 
    c.id === selectedColorId || c.assignedSymbolId === selectedSymbolId
  );

  if (!colorPalette || colorPalette.length === 0) {
    return null;
  }

  return (
    <TooltipProvider delayDuration={500}>
      <div className="bg-white border-t border-slate-200 shadow-lg">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <div className="border-b border-slate-200 px-4 py-2 flex items-center justify-between">
            <TabsList>
              <TabsTrigger value="colors" className="gap-2">
                <Palette className="w-4 h-4" />
                Couleurs détectées ({colorPalette.length})
              </TabsTrigger>
            </TabsList>

            {/* Actions rapides */}
            {selectedColor && (
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-2 px-3 py-1 bg-slate-100 rounded-lg">
                  <div 
                    className="w-6 h-6 rounded border-2 border-slate-300" 
                    style={{ backgroundColor: selectedColor.hex }}
                  />
                  <span className="text-xs font-medium">{selectedColor.assignedSymbolChar}</span>
                  <span className="text-xs text-slate-600">{selectedColor.name}</span>
                </div>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      size="sm"
                      onClick={() => onMarkColorAsDone(selectedColor.id)}
                      className="bg-green-600 hover:bg-green-700 text-white h-8"
                    >
                      <CheckCircle2 className="w-4 h-4 mr-2" />
                      Marquer comme brodé
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Marquer toutes les cases de cette couleur comme brodées</p>
                  </TooltipContent>
                </Tooltip>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => onStartMarkingZone(selectedColor.id)}
                      className="h-8"
                    >
                      Marquer une zone
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Délimiter une zone rectangulaire à marquer comme brodée</p>
                  </TooltipContent>
                </Tooltip>
              </div>
            )}
          </div>

          <TabsContent value="colors" className="m-0 p-4">
            <div className="flex gap-2 overflow-x-auto pb-2">
              {colorPalette.map((color) => {
                const isSelected = selectedColorId === color.id || 
                                   (selectedSymbolId && color.assignedSymbolId === selectedSymbolId);
                const progress = color.doneCount ? Math.round((color.doneCount / color.totalCount) * 100) : 0;
                
                return (
                  <div
                    key={color.id}
                    onClick={() => onColorSelect(color.id)}
                    className={cn(
                      "flex-shrink-0 w-48 p-3 rounded-lg border-2 transition-all cursor-pointer",
                      isSelected
                        ? "border-purple-500 bg-purple-50 shadow-lg ring-2 ring-purple-200"
                        : "border-slate-200 hover:border-slate-300 hover:shadow-md"
                    )}
                  >
                    {/* En-tête : couleur + symbole */}
                    <div className="flex items-center gap-2 mb-2">
                      <div
                        className="w-10 h-10 rounded border-2 border-slate-300 flex-shrink-0"
                        style={{ backgroundColor: color.hex }}
                      />
                      <div 
                        className="w-10 h-10 rounded border-2 border-slate-300 flex items-center justify-center flex-shrink-0 bg-white"
                      >
                        {color.assignedSymbolChar ? (
                          <span className="text-2xl font-bold">{color.assignedSymbolChar}</span>
                        ) : (
                          <span className="text-xs text-slate-400">?</span>
                        )}
                      </div>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={(e) => {
                          e.stopPropagation();
                          setEditingColorId(color.id);
                          setShowSymbolPicker(true);
                        }}
                        className="h-7 w-7 p-0 ml-auto"
                      >
                        <Edit2 className="w-3 h-3" />
                      </Button>
                    </div>

                    {/* Nom */}
                    <Input
                      value={color.name}
                      onChange={(e) => handleNameChange(color.id, e.target.value)}
                      onClick={(e) => e.stopPropagation()}
                      className="h-7 text-xs mb-2"
                    />

                    {/* Stats */}
                    <div className="flex items-center gap-2">
                      <Badge variant="secondary" className="text-[10px] px-1.5 py-0.5">
                        {color.totalCount || color.count} pts
                      </Badge>
                      {progress > 0 && (
                        <Badge variant="outline" className="text-[10px] px-1.5 py-0.5 bg-green-50">
                          {progress}%
                        </Badge>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Dialog de sélection de symbole */}
      <SymbolPickerDialog
        open={showSymbolPicker}
        onClose={() => {
          setShowSymbolPicker(false);
          setEditingColorId(null);
        }}
        onSelectSymbol={handleSymbolChange}
      />
    </TooltipProvider>
  );
}