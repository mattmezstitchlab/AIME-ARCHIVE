import React from 'react';
import { Check } from 'lucide-react';
import { cn } from '@/lib/utils';

// Palette de couleurs DMC standard
const DMC_COLORS = [
  { code: 'DMC-310', name: 'Noir', hex: '#000000' },
  { code: 'DMC-BLANC', name: 'Blanc', hex: '#FFFFFF' },
  { code: 'DMC-666', name: 'Rouge vif', hex: '#E3242B' },
  { code: 'DMC-321', name: 'Rouge', hex: '#C1082A' },
  { code: 'DMC-817', name: 'Rouge coquelicot', hex: '#BD0A2C' },
  { code: 'DMC-3832', name: 'Framboise', hex: '#DD457F' },
  { code: 'DMC-718', name: 'Prune', hex: '#A51A4F' },
  { code: 'DMC-553', name: 'Violet', hex: '#A37FB0' },
  { code: 'DMC-208', name: 'Lavande', hex: '#7B4D8E' },
  { code: 'DMC-550', name: 'Violet foncé', hex: '#4A264A' },
  { code: 'DMC-996', name: 'Cyan', hex: '#00AFCC' },
  { code: 'DMC-798', name: 'Bleu roi', hex: '#2B4E9A' },
  { code: 'DMC-825', name: 'Bleu marine', hex: '#2A4275' },
  { code: 'DMC-322', name: 'Bleu clair', hex: '#5B8FBF' },
  { code: 'DMC-519', name: 'Bleu ciel', hex: '#7FA3D1' },
  { code: 'DMC-3843', name: 'Bleu électrique', hex: '#00B2D6' },
  { code: 'DMC-992', name: 'Vert turquoise', hex: '#00A896' },
  { code: 'DMC-912', name: 'Vert émeraude', hex: '#00865F' },
  { code: 'DMC-909', name: 'Vert', hex: '#008940' },
  { code: 'DMC-702', name: 'Vert chartreuse', hex: '#4E9E37' },
  { code: 'DMC-704', name: 'Vert pomme', hex: '#91B93D' },
  { code: 'DMC-972', name: 'Jaune canari', hex: '#FFB619' },
  { code: 'DMC-973', name: 'Jaune vif', hex: '#FFD700' },
  { code: 'DMC-741', name: 'Orange', hex: '#FF8800' },
  { code: 'DMC-900', name: 'Orange brûlé', hex: '#D67231' },
  { code: 'DMC-946', name: 'Orange foncé', hex: '#DD5A2A' },
  { code: 'DMC-350', name: 'Corail', hex: '#E45254' },
  { code: 'DMC-3326', name: 'Rose', hex: '#F58BA2' },
  { code: 'DMC-899', name: 'Rose vif', hex: '#E93479' },
  { code: 'DMC-3823', name: 'Jaune pâle', hex: '#FFEBB9' },
  { code: 'DMC-951', name: 'Pêche', hex: '#FFCFA0' },
  { code: 'DMC-402', name: 'Caramel', hex: '#C77C3B' },
  { code: 'DMC-938', name: 'Marron', hex: '#5B3A29' },
  { code: 'DMC-762', name: 'Gris perle', hex: '#E6E6E6' },
  { code: 'DMC-415', name: 'Gris', hex: '#CCCCCC' },
  { code: 'DMC-414', name: 'Gris acier', hex: '#999999' },
];

export default function ColorPalette({ selectedColor, onColorSelect }) {
  return (
    <div className="bg-white rounded-2xl shadow-lg border border-slate-200 p-6">
      <h3 className="text-sm font-semibold text-slate-700 mb-4 uppercase tracking-wide">
        Palette de couleurs
      </h3>
      
      <div className="grid grid-cols-6 gap-2">
        {DMC_COLORS.map((color) => (
          <button
            key={color.code}
            onClick={() => onColorSelect(color)}
            className={cn(
              "w-10 h-10 rounded-lg border-2 transition-all hover:scale-110 relative group",
              selectedColor?.code === color.code
                ? "border-slate-800 ring-4 ring-slate-200"
                : "border-slate-300 hover:border-slate-400"
            )}
            style={{ backgroundColor: color.hex }}
            title={`${color.code} - ${color.name}`}
          >
            {selectedColor?.code === color.code && (
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="bg-white rounded-full p-0.5">
                  <Check className="w-4 h-4 text-slate-800" strokeWidth={3} />
                </div>
              </div>
            )}
            
            {/* Tooltip au survol */}
            <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-50">
              <div className="bg-slate-900 text-white text-xs px-2 py-1 rounded whitespace-nowrap">
                {color.name}
                <div className="text-slate-400 text-[10px]">{color.code}</div>
              </div>
            </div>
          </button>
        ))}
      </div>
      
      {selectedColor && (
        <div className="mt-4 pt-4 border-t border-slate-200">
          <div className="flex items-center gap-3">
            <div 
              className="w-12 h-12 rounded-lg border-2 border-slate-300"
              style={{ backgroundColor: selectedColor.hex }}
            />
            <div className="flex-1">
              <div className="text-sm font-medium text-slate-900">{selectedColor.name}</div>
              <div className="text-xs text-slate-500">{selectedColor.code}</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}