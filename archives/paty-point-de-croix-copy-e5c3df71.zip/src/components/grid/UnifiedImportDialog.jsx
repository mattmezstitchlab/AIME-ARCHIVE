import React, { useRef, useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { FileUp, Lightbulb, ChevronDown, FileText, FileCode } from 'lucide-react';
import { toast } from 'sonner';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";

export default function UnifiedImportDialog({ open, onClose, onSelectImageImport, onSelectPdfCoverImport, onSelectPdfMosaicImport, onSelectSubImport }) {
  const fileInputRef = useRef(null);
  const pdfInputRef = useRef(null);
  const subInputRef = useRef(null);
  const [advancedOpen, setAdvancedOpen] = useState(false);

  // Import image simple
  const handleImageSelect = (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    onClose();
    onSelectImageImport(file);
    event.target.value = '';
  };

  // Import PDF
  const handlePdfSelect = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      const arrayBuffer = await file.arrayBuffer();
      
      if (!window.pdfjsLib) {
        toast.error('Chargement du module PDF en cours...');
        return;
      }

      const pdf = await window.pdfjsLib.getDocument({ data: arrayBuffer }).promise;
      const numPages = pdf.numPages;

      onClose();
      
      if (numPages === 1) {
        onSelectPdfCoverImport(file);
      } else {
        onSelectPdfMosaicImport(file);
      }
    } catch (error) {
      console.error('Erreur lors de la lecture du PDF:', error);
      toast.error('Erreur lors de la lecture du PDF');
    }

    event.target.value = '';
  };

  // Import .SUB
  const handleSubSelect = (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    onClose();
    onSelectSubImport?.(file);
    event.target.value = '';
  };
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Importer un visuel</DialogTitle>
          <DialogDescription>
            Importez votre motif pour broder
          </DialogDescription>
        </DialogHeader>

        <div className="py-4 space-y-4">
          {/* Input caché pour image */}
          <input
            ref={fileInputRef}
            type="file"
            accept=".png,.jpg,.jpeg,.gif,.webp"
            onChange={handleImageSelect}
            className="hidden"
          />
          
          {/* Input caché pour PDF */}
          <input
            ref={pdfInputRef}
            type="file"
            accept=".pdf"
            onChange={handlePdfSelect}
            className="hidden"
          />
          
          {/* Input caché pour SUB */}
          <input
            ref={subInputRef}
            type="file"
            accept=".sub"
            onChange={handleSubSelect}
            className="hidden"
          />
          
          {/* Bouton principal : Importer une image */}
          <Button
            onClick={() => fileInputRef.current?.click()}
            className="w-full justify-start gap-4 h-auto py-5 bg-slate-900 hover:bg-slate-800 text-white"
          >
            <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-white/10">
              <FileUp className="w-5 h-5" />
            </div>
            <div className="flex-1 text-left">
              <div className="font-semibold text-base">Importer une image</div>
              <div className="text-sm opacity-70">PNG, JPG, GIF, WebP</div>
            </div>
          </Button>

          {/* Menu déroulant Import avancé */}
          <Collapsible open={advancedOpen} onOpenChange={setAdvancedOpen}>
            <CollapsibleTrigger asChild>
              <Button
                variant="outline"
                className="w-full justify-between h-auto py-3 text-slate-600"
              >
                <span className="font-medium">Import avancé</span>
                <ChevronDown className={`w-4 h-4 transition-transform ${advancedOpen ? 'rotate-180' : ''}`} />
              </Button>
            </CollapsibleTrigger>
            <CollapsibleContent className="mt-2 space-y-2">
              {/* Importer un PDF */}
              <Button
                variant="ghost"
                onClick={() => pdfInputRef.current?.click()}
                className="w-full justify-start gap-3 h-auto py-3 text-slate-700 hover:bg-slate-100"
              >
                <FileText className="w-5 h-5 text-red-500" />
                <div className="flex-1 text-left">
                  <div className="font-medium text-sm">Importer un PDF</div>
                  <div className="text-xs text-slate-500">Grille d'auteur, mosaïque multi-pages</div>
                </div>
              </Button>

              {/* Importer un .SUB */}
              <Button
                variant="ghost"
                onClick={() => subInputRef.current?.click()}
                className="w-full justify-start gap-3 h-auto py-3 text-slate-700 hover:bg-slate-100"
              >
                <FileCode className="w-5 h-5 text-purple-500" />
                <div className="flex-1 text-left">
                  <div className="font-medium text-sm">Importer un .SUB</div>
                  <div className="text-xs text-slate-500">Format PC Stitch / Pattern Maker</div>
                </div>
              </Button>
            </CollapsibleContent>
          </Collapsible>
        </div>

        <div className="bg-slate-50 rounded-lg p-4 text-sm text-slate-700 border border-slate-200">
          <div className="flex items-start gap-2">
            <Lightbulb className="w-4 h-4 text-slate-600 mt-0.5 flex-shrink-0" />
            <p>
              Le visuel sera affiché dans votre espace de travail. La grille sera générée uniquement quand vous cliquerez sur <strong>« Générer la grille »</strong>.
            </p>
          </div>
        </div>

        <div className="flex justify-end">
          <Button variant="outline" onClick={onClose}>
            Fermer
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}