import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { AlertTriangle } from 'lucide-react';
import { cn } from '@/lib/utils';

const FORMATS = [
  { value: 100, label: '100 × 100' },
  { value: 120, label: '120 × 120' },
  { value: 150, label: '150 × 150' },
  { value: 180, label: '180 × 180' },
  { value: 200, label: '200 × 200' },
  { value: 220, label: '220 × 220' },
  { value: 250, label: '250 × 250' },
  { value: 280, label: '280 × 280' },
  { value: 300, label: '300 × 300' },
  { value: 350, label: '350 × 350' },
  { value: 400, label: '400 × 400' },
  { value: 450, label: '450 × 450' },
  { value: 500, label: '500 × 500' },
  { value: 550, label: '550 × 550' },
  { value: 600, label: '600 × 600' },
  { value: 700, label: '700 × 700' },
  { value: 800, label: '800 × 800' },
  { value: 999, label: '999 × 999' }
];

export default function GridFormatDialog({ open, onClose, currentSize, onApplyFormat }) {
  const [selectedFormat, setSelectedFormat] = useState(currentSize || 200);

  const handleApply = () => {
    onApplyFormat(selectedFormat);
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <span className="text-2xl">📏</span>
            Format de la grille
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Avertissement */}
          <div className="flex items-start gap-3 p-3 bg-amber-50 border border-amber-200 rounded-lg">
            <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
            <p className="text-sm text-amber-800">
              Changer le format peut recadrer ou tronquer votre motif. Confirmez avant de valider.
            </p>
          </div>

          {/* Sélection du format */}
          <div className="grid grid-cols-3 gap-2 max-h-80 overflow-y-auto">
            {FORMATS.map((format) => (
              <button
                key={format.value}
                onClick={() => setSelectedFormat(format.value)}
                className={cn(
                  "p-3 rounded-lg border-2 transition-all text-sm font-medium",
                  selectedFormat === format.value
                    ? "border-[#F5C200] bg-[#F5C200]/10 text-slate-900"
                    : "border-slate-200 hover:border-slate-300 text-slate-600"
                )}
              >
                {format.label}
              </button>
            ))}
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={onClose}>
              Annuler
            </Button>
            <Button
              onClick={handleApply}
              className="bg-slate-900 hover:bg-slate-800"
            >
              Appliquer ce format
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}