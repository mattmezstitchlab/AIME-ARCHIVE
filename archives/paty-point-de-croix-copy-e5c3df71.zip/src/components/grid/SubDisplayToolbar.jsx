import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { 
  ZoomIn, ZoomOut, Search, Target, Eye, EyeOff, 
  Sparkles, Grid3X3, Check, Accessibility, Maximize2,
  Square, LayoutGrid
} from 'lucide-react';
import { toast } from 'sonner';

// Modes d'affichage SUB
export const SUB_DISPLAY_MODES = {
  CLASSIC: { id: 'classic', name: 'SUB Classique', cellRatio: 1 },
  LARGE: { id: 'large', name: 'SUB Large', cellRatio: 1.2 },
  PRO: { id: 'pro', name: 'SUB Pro', cellRatio: 0.8 }
};

export default function SubDisplayToolbar({
  onZoomIn,
  onZoomOut,
  onCenter,
  onToggleSymbols,
  onToggleColors,
  onSelectSymbol,
  onToggleDaltonianMode,
  onToggleZeroHoleCheck,
  onDisplayModeChange,
  showSymbols = true,
  showColors = true,
  daltonianMode = false,
  zeroHoleVerified = false,
  currentDisplayMode = 'classic',
  selectedSymbolFilter = null,
  pattern
}) {
  const [showLoupe, setShowLoupe] = useState(false);
  const [singleSymbolMode, setSingleSymbolMode] = useState(false);

  const handleToggleLoupe = () => {
    setShowLoupe(!showLoupe);
    toast.info(showLoupe ? 'Loupe désactivée' : 'Loupe dynamique activée');
  };

  const handleToggleSingleSymbol = () => {
    setSingleSymbolMode(!singleSymbolMode);
    if (!singleSymbolMode) {
      toast.info('Mode 1 Symbole : cliquez sur un symbole pour l\'isoler');
    } else {
      onSelectSymbol?.(null);
    }
  };

  const handleZeroHoleCheck = () => {
    onToggleZeroHoleCheck?.();
    if (!zeroHoleVerified) {
      // Vérifier s'il y a des trous
      let hasHoles = false;
      if (pattern?.symbolGrid) {
        for (const row of pattern.symbolGrid) {
          for (const cell of row) {
            if (!cell) {
              hasHoles = true;
              break;
            }
          }
          if (hasHoles) break;
        }
      }
      
      if (hasHoles) {
        toast.error('Anomalies détectées — Utilisez la réparation SUB');
      } else {
        toast.success('✅ Zéro Trou SUB — Grille parfaite !');
      }
    }
  };

  const cycleDisplayMode = () => {
    const modes = Object.keys(SUB_DISPLAY_MODES);
    const currentIndex = modes.indexOf(currentDisplayMode.toUpperCase());
    const nextIndex = (currentIndex + 1) % modes.length;
    const nextMode = modes[nextIndex].toLowerCase();
    onDisplayModeChange?.(nextMode);
    toast.info(`Mode ${SUB_DISPLAY_MODES[modes[nextIndex]].name}`);
  };

  return (
    <TooltipProvider>
      <div className="flex items-center gap-1 bg-white border rounded-lg p-1 shadow-sm">
        {/* Groupe Zoom */}
        <div className="flex items-center gap-0.5 border-r pr-1 mr-1">
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={onZoomIn}
              >
                <ZoomIn className="w-4 h-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent><p>Zoom +</p></TooltipContent>
          </Tooltip>

          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={onZoomOut}
              >
                <ZoomOut className="w-4 h-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent><p>Zoom -</p></TooltipContent>
          </Tooltip>

          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className={`h-8 w-8 ${showLoupe ? 'bg-yellow-100 text-yellow-700' : ''}`}
                onClick={handleToggleLoupe}
              >
                <Search className="w-4 h-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent><p>Loupe dynamique</p></TooltipContent>
          </Tooltip>

          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={onCenter}
              >
                <Target className="w-4 h-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent><p>Centrer</p></TooltipContent>
          </Tooltip>
        </div>

        {/* Groupe Affichage */}
        <div className="flex items-center gap-0.5 border-r pr-1 mr-1">
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className={`h-8 w-8 ${showSymbols ? 'bg-black text-white' : 'text-gray-400'}`}
                onClick={onToggleSymbols}
              >
                {showSymbols ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
              </Button>
            </TooltipTrigger>
            <TooltipContent><p>{showSymbols ? 'Masquer symboles' : 'Afficher symboles'}</p></TooltipContent>
          </Tooltip>

          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className={`h-8 w-8 ${showColors ? 'bg-black text-white' : 'text-gray-400'}`}
                onClick={onToggleColors}
              >
                <Square className="w-4 h-4" fill={showColors ? 'currentColor' : 'none'} />
              </Button>
            </TooltipTrigger>
            <TooltipContent><p>{showColors ? 'Masquer couleurs' : 'Afficher couleurs'}</p></TooltipContent>
          </Tooltip>

          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className={`h-8 w-8 ${singleSymbolMode ? 'bg-yellow-100 text-yellow-700' : ''}`}
                onClick={handleToggleSingleSymbol}
              >
                <Sparkles className="w-4 h-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent><p>Sélection SUB (isoler un symbole)</p></TooltipContent>
          </Tooltip>

          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className={`h-8 w-8 ${selectedSymbolFilter ? 'bg-purple-100 text-purple-700' : ''}`}
                onClick={handleToggleSingleSymbol}
              >
                <Grid3X3 className="w-4 h-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent><p>Mode 1 Symbole</p></TooltipContent>
          </Tooltip>
        </div>

        {/* Groupe Modes */}
        <div className="flex items-center gap-0.5 border-r pr-1 mr-1">
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className={`h-8 w-8 ${zeroHoleVerified ? 'bg-green-100 text-green-700' : ''}`}
                onClick={handleZeroHoleCheck}
              >
                <Check className="w-4 h-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent><p>Vérification Zéro Trou</p></TooltipContent>
          </Tooltip>

          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className={`h-8 w-8 ${daltonianMode ? 'bg-blue-100 text-blue-700' : ''}`}
                onClick={onToggleDaltonianMode}
              >
                <Accessibility className="w-4 h-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent><p>Mode Daltonien</p></TooltipContent>
          </Tooltip>

          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={cycleDisplayMode}
              >
                <LayoutGrid className="w-4 h-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent><p>Mode grille : {SUB_DISPLAY_MODES[currentDisplayMode.toUpperCase()]?.name}</p></TooltipContent>
          </Tooltip>
        </div>

        {/* Badge Zéro Trou */}
        {zeroHoleVerified && (
          <div className="flex items-center gap-1 px-2 py-1 bg-green-100 text-green-700 rounded-md text-xs font-bold">
            <Check className="w-3 h-3" />
            Zéro Trou SUB
          </div>
        )}
      </div>
    </TooltipProvider>
  );
}