import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { 
  Folder, 
  Search, 
  Calendar, 
  Palette, 
  Grid3x3,
  TrendingUp,
  MoreVertical,
  Trash2,
  Copy,
  Edit2,
  FolderOpen,
  Upload,
  Eye,
  ShoppingBag,
  Pencil,
  Files
} from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';

import PublishToShopDialog from '../shop/PublishToShopDialog';

export default function ProjectsDialog({ open, onClose, onSelect, onDelete }) {
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('date-desc');
  const [filterStatus, setFilterStatus] = useState('all');
  const [showPublishDialog, setShowPublishDialog] = useState(false);
  const [selectedGridToPublish, setSelectedGridToPublish] = useState(null);
  const [renamingGridId, setRenamingGridId] = useState(null);
  const [newGridName, setNewGridName] = useState('');
  const [deleteConfirmGrid, setDeleteConfirmGrid] = useState(null);

  const { data: grids, isLoading } = useQuery({
    queryKey: ['grids'],
    queryFn: () => base44.entities.Grid.list('-updated_date'),
    enabled: open,
  });

  const calculateProgress = (grid) => {
    if (!grid.pattern?.stitches) return 0;
    const totalStitches = grid.pattern.stitches.length;
    if (totalStitches === 0) return 0;
    const doneStitches = grid.pattern.stitches.filter(s => s.done).length;
    return Math.round((doneStitches / totalStitches) * 100);
  };

  const getFilteredAndSortedGrids = () => {
    if (!grids) return [];

    let filtered = [...grids];

    // Recherche
    if (searchQuery) {
      filtered = filtered.filter(g => 
        g.name.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Filtrage par statut
    if (filterStatus === 'in-progress') {
      filtered = filtered.filter(g => {
        const progress = calculateProgress(g);
        return progress > 0 && progress < 100;
      });
    } else if (filterStatus === 'completed') {
      filtered = filtered.filter(g => calculateProgress(g) === 100);
    } else if (filterStatus === 'not-started') {
      filtered = filtered.filter(g => calculateProgress(g) === 0);
    }

    // Tri
    filtered.sort((a, b) => {
      switch (sortBy) {
        case 'date-desc':
          return new Date(b.updated_date) - new Date(a.updated_date);
        case 'date-asc':
          return new Date(a.updated_date) - new Date(b.updated_date);
        case 'name-asc':
          return a.name.localeCompare(b.name);
        case 'name-desc':
          return b.name.localeCompare(a.name);
        case 'progress-asc':
          return calculateProgress(a) - calculateProgress(b);
        case 'progress-desc':
          return calculateProgress(b) - calculateProgress(a);
        case 'size-desc':
          return (b.nb_colonnes * b.nb_lignes) - (a.nb_colonnes * a.nb_lignes);
        case 'colors-desc':
          return (b.pattern?.colors?.length || 0) - (a.pattern?.colors?.length || 0);
        default:
          return 0;
      }
    });

    return filtered;
  };

  const filteredGrids = getFilteredAndSortedGrids();

  const handleRename = async (gridId) => {
    if (!newGridName.trim()) return;
    
    try {
      await base44.entities.Grid.update(gridId, { name: newGridName.trim() });
      setRenamingGridId(null);
      setNewGridName('');
    } catch (error) {
      console.error('Erreur lors du renommage:', error);
    }
  };

  const handleDuplicate = async (grid) => {
    try {
      const duplicateName = `${grid.name} - copie`;
      const duplicateData = {
        ...grid,
        name: duplicateName,
        id: undefined,
        created_date: undefined,
        updated_date: undefined
      };
      
      await base44.entities.Grid.create(duplicateData);
    } catch (error) {
      console.error('Erreur lors de la duplication:', error);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold flex items-center gap-2">
            <Folder className="w-6 h-6 text-slate-600" />
            Mes projets
          </DialogTitle>
          <DialogDescription>
            Retrouvez toutes vos grilles créées avec PATY
          </DialogDescription>
        </DialogHeader>

        {/* Filtres et recherche */}
        <div className="space-y-4 py-4 border-b">
          <div className="flex gap-4">
            {/* Recherche */}
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input
                  placeholder="Rechercher un projet..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            {/* Tri */}
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Trier par..." />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="date-desc">Plus récent</SelectItem>
                <SelectItem value="date-asc">Plus ancien</SelectItem>
                <SelectItem value="name-asc">Nom (A-Z)</SelectItem>
                <SelectItem value="name-desc">Nom (Z-A)</SelectItem>
                <SelectItem value="progress-desc">Plus avancé</SelectItem>
                <SelectItem value="progress-asc">Moins avancé</SelectItem>
                <SelectItem value="size-desc">Plus grande grille</SelectItem>
                <SelectItem value="colors-desc">Plus de couleurs</SelectItem>
              </SelectContent>
            </Select>

            {/* Filtre statut */}
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Statut" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous</SelectItem>
                <SelectItem value="in-progress">En cours</SelectItem>
                <SelectItem value="completed">Terminés</SelectItem>
                <SelectItem value="not-started">Non démarrés</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Liste des projets */}
        <div className="flex-1 overflow-y-auto">
          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <div className="text-slate-500">Chargement des projets...</div>
            </div>
          ) : filteredGrids.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <FolderOpen className="w-16 h-16 text-slate-300 mb-4" />
              <p className="text-slate-500 mb-2">
                {searchQuery || filterStatus !== 'all' 
                  ? 'Aucun projet trouvé avec ces critères'
                  : 'Aucun projet pour le moment'}
              </p>
              <p className="text-sm text-slate-400">
                {!searchQuery && filterStatus === 'all' && 'Créez une nouvelle grille ou importez une image pour commencer'}
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 p-4">
              {filteredGrids.map((grid) => {
                const progress = calculateProgress(grid);
                const colorCount = grid.pattern?.colors?.length || 0;
                
                return (
                  <div
                    key={grid.id}
                    className="border border-slate-200 rounded-xl overflow-hidden hover:shadow-lg transition-all bg-white"
                  >
                    {/* Aperçu miniature */}
                    <div className="h-32 bg-slate-100 relative">
                      {grid.pattern?.source_image ? (
                        <img 
                          src={grid.pattern.source_image}
                          alt={grid.name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <Grid3x3 className="w-12 h-12 text-slate-300" />
                        </div>
                      )}
                      
                      {/* Badge progression */}
                      {progress > 0 && (
                        <div className="absolute top-2 right-2">
                          <Badge 
                            className={`${
                              progress === 100 
                                ? 'bg-green-600' 
                                : progress > 50 
                                ? 'bg-blue-600' 
                                : 'bg-amber-600'
                            } text-white`}
                          >
                            {progress}%
                          </Badge>
                        </div>
                      )}
                    </div>

                    {/* Infos */}
                    <div className="p-4 space-y-3">
                      {/* Titre avec renommage inline */}
                      {renamingGridId === grid.id ? (
                        <div className="flex items-center gap-2">
                          <Input
                            value={newGridName}
                            onChange={(e) => setNewGridName(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleRename(grid.id);
                              if (e.key === 'Escape') {
                                setRenamingGridId(null);
                                setNewGridName('');
                              }
                            }}
                            className="flex-1 h-8 text-sm"
                            autoFocus
                          />
                          <Button
                            size="sm"
                            onClick={() => handleRename(grid.id)}
                            className="h-8 px-3"
                          >
                            OK
                          </Button>
                        </div>
                      ) : (
                        <h3 className="font-semibold text-slate-900 line-clamp-2">
                          {grid.name}
                        </h3>
                      )}

                      {/* Métadonnées */}
                      <div className="space-y-2 text-xs text-slate-600">
                        <div className="flex items-center gap-4">
                          <div className="flex items-center gap-1">
                            <Grid3x3 className="w-3 h-3" />
                            <span>{grid.nb_colonnes} × {grid.nb_lignes}</span>
                          </div>
                          {colorCount > 0 && (
                            <div className="flex items-center gap-1">
                              <Palette className="w-3 h-3" />
                              <span>{colorCount} couleurs</span>
                            </div>
                          )}
                        </div>
                        
                        <div className="flex items-center gap-1 text-slate-500">
                          <Calendar className="w-3 h-3" />
                          <span>
                            Modifié le {format(new Date(grid.updated_date), 'dd/MM/yyyy à HH:mm', { locale: fr })}
                          </span>
                        </div>
                      </div>

                      {/* Barre d'actions avec 5 icônes */}
                      <TooltipProvider>
                        <div className="flex items-center justify-center gap-3 pt-2 border-t">
                          {/* Ouvrir */}
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <button
                                onClick={() => {
                                  onSelect(grid);
                                  onClose();
                                }}
                                className="p-2 rounded-lg hover:bg-slate-100 transition-colors"
                              >
                                <Eye className="w-5 h-5 text-slate-700" />
                              </button>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>Ouvrir la grille dans l'éditeur</p>
                            </TooltipContent>
                          </Tooltip>

                          {/* Publier */}
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <button
                                onClick={() => {
                                  setSelectedGridToPublish(grid);
                                  setShowPublishDialog(true);
                                }}
                                className="p-2 rounded-lg hover:bg-purple-50 transition-colors"
                              >
                                <ShoppingBag className="w-5 h-5 text-purple-600" />
                              </button>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>Publier cette grille dans la Boutique</p>
                            </TooltipContent>
                          </Tooltip>

                          {/* Renommer */}
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <button
                                onClick={() => {
                                  setRenamingGridId(grid.id);
                                  setNewGridName(grid.name);
                                }}
                                className="p-2 rounded-lg hover:bg-slate-100 transition-colors"
                              >
                                <Pencil className="w-5 h-5 text-slate-700" />
                              </button>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>Renommer ce projet</p>
                            </TooltipContent>
                          </Tooltip>

                          {/* Dupliquer */}
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <button
                                onClick={() => handleDuplicate(grid)}
                                className="p-2 rounded-lg hover:bg-slate-100 transition-colors"
                              >
                                <Files className="w-5 h-5 text-slate-700" />
                              </button>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>Dupliquer ce projet</p>
                            </TooltipContent>
                          </Tooltip>

                          {/* Supprimer */}
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <button
                                onClick={() => setDeleteConfirmGrid(grid)}
                                className="p-2 rounded-lg hover:bg-red-50 transition-colors"
                              >
                                <Trash2 className="w-5 h-5 text-red-600" />
                              </button>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>Supprimer ce projet</p>
                            </TooltipContent>
                          </Tooltip>
                        </div>
                      </TooltipProvider>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Dialog de publication */}
        {selectedGridToPublish && (
          <PublishToShopDialog
            open={showPublishDialog}
            onClose={() => {
              setShowPublishDialog(false);
              setSelectedGridToPublish(null);
            }}
            grid={selectedGridToPublish}
          />
        )}

        {/* Dialog de confirmation de suppression */}
        <AlertDialog open={!!deleteConfirmGrid} onOpenChange={() => setDeleteConfirmGrid(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Supprimer ce projet ?</AlertDialogTitle>
              <AlertDialogDescription>
                Cette action est définitive. Voulez-vous vraiment supprimer cette grille ?
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Annuler</AlertDialogCancel>
              <AlertDialogAction
                onClick={() => {
                  if (deleteConfirmGrid) {
                    onDelete(deleteConfirmGrid.id);
                    setDeleteConfirmGrid(null);
                  }
                }}
                className="bg-red-600 hover:bg-red-700"
              >
                Supprimer
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </DialogContent>
    </Dialog>
  );
}