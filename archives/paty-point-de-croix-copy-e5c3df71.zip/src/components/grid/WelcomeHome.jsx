import React, { useState, useEffect } from 'react';
import { FolderOpen, Upload, Wrench, Pencil, Eraser, MousePointer2, ZoomIn, Move, Sparkles, ChevronLeft, ChevronRight } from 'lucide-react';

// Logo Broodway
function BroodwayLogo() {
  return (
    <img 
      src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6924cd1cd3887ccee5c3df71/216b87773_Capturedcran2025-11-28221419.png"
      alt="B×W"
      style={{ height: '32px', width: 'auto' }}
    />
  );
}

// Slides du carrousel
const SLIDES = [
  {
    title: "BROOD★WAY – LA NOUVELLE ÈRE DU POINT DE CROIX",
    text: "Convertissez vos images en grilles optimisées,\nchaque pixel analysé pour choisir les bons fils DMC,\nune grille parfaite prête à broder."
  },
  {
    title: "CONVERSION DMC INTELLIGENTE",
    text: "Chaque couleur brute est automatiquement\nrapprochée de la plus fidèle nuance DMC,\nsans doublons et avec gestion des dégradés."
  },
  {
    title: "STYLES DE POINTS OPTIMISÉS",
    text: "Points complets, demi-points, backstitch,\nnœuds, perles, effets spéciaux…\nle meilleur rendu pour chaque motif."
  },
  {
    title: "IA–FOCUS™ : LA PRÉCISION ÉVOLUÉE",
    text: "Une IA dédiée détecte les zones importantes,\nsimplifie ce qui doit l'être, détaille ce qui compte,\net équilibre votre motif comme une brodeuse experte."
  },
  {
    title: "MAPPING 4D™ – VOIR VOTRE GRILLE AUTREMENT",
    text: "Une mini-carte intelligente vous montre\nle repère central, vos déplacements,\net les zones techniques de votre motif."
  },
  {
    title: "L'EXPÉRIENCE BRODERIE RÉINVENTÉE",
    text: "Symbole parfait, DMC parfait,\ngrille parfaite en quelques secondes,\net une IA qui vous accompagne du début à la fin."
  }
];

// Liste des outils à présenter
const TOOLS_LIST = [
  { icon: Pencil, name: 'Crayon', desc: 'Dessinez des points de croix sur la grille. Sélectionnez une couleur DMC et placez vos symboles.' },
  { icon: Eraser, name: 'Gomme', desc: 'Effacez les points indésirables. Corrigez facilement vos erreurs de placement.' },
  { icon: MousePointer2, name: 'Sélection', desc: 'Sélectionnez une zone ou une couleur. Modifiez plusieurs points en une seule action.' },
  { icon: ZoomIn, name: 'Zoom', desc: 'Zoomez pour voir les détails. Naviguez précisément dans votre grille.' },
  { icon: Move, name: 'Déplacement', desc: 'Déplacez-vous librement sur la grille. Explorez chaque zone de votre projet.' },
  { icon: Sparkles, name: 'IA PatyBee', desc: 'Assistant intelligent pour optimiser vos grilles. Répare automatiquement les trous.' },
];

export default function WelcomeHome({ onOpenProjects, onImport }) {
  const [showTools, setShowTools] = useState(false);
  const [showCarousel, setShowCarousel] = useState(false);
  const [currentSlide, setCurrentSlide] = useState(0);
  const [autoPlay, setAutoPlay] = useState(true);

  // Auto-play carousel
  useEffect(() => {
    if (!showCarousel || !autoPlay) return;
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % SLIDES.length);
    }, 5000);
    return () => clearInterval(timer);
  }, [showCarousel, autoPlay]);

  const handlePrevious = () => {
    setAutoPlay(false);
    setCurrentSlide((prev) => (prev - 1 + SLIDES.length) % SLIDES.length);
  };

  const handleNext = () => {
    setAutoPlay(false);
    setCurrentSlide((prev) => (prev + 1) % SLIDES.length);
  };

  return (
    <div 
      style={{
        position: 'absolute',
        inset: 0,
        display: 'flex',
        flexDirection: 'row',
        flexWrap: 'wrap',
        alignItems: 'center',
        justifyContent: 'center',
        gap: '24px',
        rowGap: '12px',
        backgroundColor: '#f8f8f8',
        padding: '24px',
      }}
    >
      {/* Carré BROODWAY avec logo et carrousel */}
      <button
        onClick={() => {
          setShowCarousel(true);
          setCurrentSlide(0);
          setAutoPlay(true);
        }}
        style={{
          width: 'min(240px, 42vw)',
          height: 'min(240px, 42vw)',
          minWidth: '140px',
          minHeight: '140px',
          backgroundColor: '#000',
          borderRadius: '16px',
          border: 'none',
          cursor: 'pointer',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '16px',
          transition: 'all 0.2s ease',
          position: 'relative',
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.transform = 'scale(1.03)';
          e.currentTarget.style.boxShadow = '0 0 0 3px #fff, 0 8px 32px rgba(0,0,0,0.3)';
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.transform = 'scale(1)';
          e.currentTarget.style.boxShadow = 'none';
        }}
      >
        <BroodwayLogo />
        <div style={{ textAlign: 'center' }}>
          <div style={{ color: '#fff', fontSize: '18px', fontWeight: 700, letterSpacing: '1px' }}>
            DÉCOUVRIR
          </div>
          <div style={{ color: 'rgba(255,255,255,0.5)', fontSize: '12px', marginTop: '8px' }}>
            Les innovations Brood★Way
          </div>
        </div>
      </button>

      {/* Carré PROJETS */}
      <button
        onClick={onOpenProjects}
        style={{
          width: 'min(240px, 42vw)',
          height: 'min(240px, 42vw)',
          minWidth: '140px',
          minHeight: '140px',
          backgroundColor: '#000',
          borderRadius: '16px',
          border: 'none',
          cursor: 'pointer',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '16px',
          transition: 'all 0.2s ease',
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.transform = 'scale(1.03)';
          e.currentTarget.style.boxShadow = '0 0 0 3px #fff, 0 8px 32px rgba(0,0,0,0.3)';
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.transform = 'scale(1)';
          e.currentTarget.style.boxShadow = 'none';
        }}
      >
        <FolderOpen style={{ width: '48px', height: '48px', color: '#fff' }} />
        <div style={{ textAlign: 'center' }}>
          <div style={{ color: '#fff', fontSize: '18px', fontWeight: 700, letterSpacing: '1px' }}>
            PROJETS
          </div>
          <div style={{ color: 'rgba(255,255,255,0.5)', fontSize: '12px', marginTop: '8px' }}>
            Accéder à vos projets enregistrés
          </div>
        </div>
      </button>

      {/* Carré IMPORTER */}
      <button
        onClick={onImport}
        style={{
          width: 'min(240px, 42vw)',
          height: 'min(240px, 42vw)',
          minWidth: '140px',
          minHeight: '140px',
          backgroundColor: '#000',
          borderRadius: '16px',
          border: 'none',
          cursor: 'pointer',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '16px',
          transition: 'all 0.2s ease',
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.transform = 'scale(1.03)';
          e.currentTarget.style.boxShadow = '0 0 0 3px #fff, 0 8px 32px rgba(0,0,0,0.3)';
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.transform = 'scale(1)';
          e.currentTarget.style.boxShadow = 'none';
        }}
      >
        <Upload style={{ width: '48px', height: '48px', color: '#fff' }} />
        <div style={{ textAlign: 'center' }}>
          <div style={{ color: '#fff', fontSize: '18px', fontWeight: 700, letterSpacing: '1px' }}>
            IMPORTER
          </div>
          <div style={{ color: 'rgba(255,255,255,0.5)', fontSize: '12px', marginTop: '8px' }}>
            Créer une grille à partir d'une image
          </div>
        </div>
      </button>

      {/* Modal Carrousel Broodway */}
      {showCarousel && (
        <div
          onClick={() => setShowCarousel(false)}
          style={{
            position: 'fixed',
            inset: 0,
            backgroundColor: 'rgba(0,0,0,0.9)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 100,
            padding: '24px',
          }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            style={{
              backgroundColor: '#fff',
              borderRadius: '20px',
              padding: '0',
              maxWidth: '580px',
              width: '100%',
              maxHeight: '90vh',
              overflow: 'hidden',
            }}
          >
            {/* En-tête */}
            <div style={{ padding: '32px 32px 24px', textAlign: 'center' }}>
              <div style={{ display: 'flex', justifyContent: 'center', marginBottom: '16px' }}>
                <BroodwayLogo />
              </div>
              <h2 style={{ fontSize: '20px', fontWeight: 700, color: '#111', margin: 0 }}>
                Bienvenue sur Brood★Way
              </h2>
              <p style={{ fontSize: '13px', color: '#666', marginTop: '8px' }}>
                Découvrez les innovations qui transforment votre expérience broderie.
              </p>
            </div>

            {/* Zone carrousel */}
            <div style={{ position: 'relative', padding: '0 48px', minHeight: '180px', display: 'flex', alignItems: 'center' }}>
              {/* Flèche gauche */}
              <button
                onClick={handlePrevious}
                style={{
                  position: 'absolute',
                  left: '12px',
                  width: '36px',
                  height: '36px',
                  borderRadius: '50%',
                  backgroundColor: '#f0f0f0',
                  border: 'none',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <ChevronLeft style={{ width: '18px', height: '18px', color: '#333' }} />
              </button>

              {/* Contenu slide */}
              <div style={{ flex: 1, textAlign: 'center', padding: '0 16px' }}>
                <h3 style={{ fontSize: '16px', fontWeight: 700, color: '#111', marginBottom: '12px', letterSpacing: '0.5px' }}>
                  {SLIDES[currentSlide].title}
                </h3>
                <p style={{ fontSize: '14px', color: '#555', lineHeight: '1.6', whiteSpace: 'pre-line' }}>
                  {SLIDES[currentSlide].text}
                </p>
              </div>

              {/* Flèche droite */}
              <button
                onClick={handleNext}
                style={{
                  position: 'absolute',
                  right: '12px',
                  width: '36px',
                  height: '36px',
                  borderRadius: '50%',
                  backgroundColor: '#f0f0f0',
                  border: 'none',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <ChevronRight style={{ width: '18px', height: '18px', color: '#333' }} />
              </button>
            </div>

            {/* Puces de pagination */}
            <div style={{ display: 'flex', justifyContent: 'center', gap: '8px', padding: '24px 0' }}>
              {SLIDES.map((_, index) => (
                <button
                  key={index}
                  onClick={() => {
                    setAutoPlay(false);
                    setCurrentSlide(index);
                  }}
                  style={{
                    width: currentSlide === index ? '24px' : '8px',
                    height: '8px',
                    borderRadius: '4px',
                    backgroundColor: currentSlide === index ? '#111' : '#ccc',
                    border: 'none',
                    cursor: 'pointer',
                    transition: 'all 0.2s',
                  }}
                />
              ))}
            </div>

            {/* Bouton fermer */}
            <div style={{ padding: '0 32px 32px' }}>
              <button
                onClick={() => setShowCarousel(false)}
                style={{
                  width: '100%',
                  padding: '14px',
                  backgroundColor: '#000',
                  color: '#fff',
                  border: 'none',
                  borderRadius: '10px',
                  fontSize: '15px',
                  fontWeight: 600,
                  cursor: 'pointer',
                }}
              >
                Fermer
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Outils */}
      {showTools && (
        <div
          onClick={() => setShowTools(false)}
          style={{
            position: 'fixed',
            inset: 0,
            backgroundColor: 'rgba(0,0,0,0.7)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 100,
            padding: '24px',
          }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            style={{
              backgroundColor: '#111',
              borderRadius: '20px',
              padding: '32px',
              maxWidth: '600px',
              width: '100%',
              maxHeight: '80vh',
              overflowY: 'auto',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '24px' }}>
              <Wrench style={{ width: '28px', height: '28px', color: '#fff' }} />
              <h2 style={{ color: '#fff', fontSize: '22px', fontWeight: 700, margin: 0 }}>
                Outils disponibles
              </h2>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
              {TOOLS_LIST.map((tool, idx) => (
                <div
                  key={idx}
                  style={{
                    display: 'flex',
                    alignItems: 'flex-start',
                    gap: '16px',
                    padding: '16px',
                    backgroundColor: 'rgba(255,255,255,0.05)',
                    borderRadius: '12px',
                  }}
                >
                  <div
                    style={{
                      width: '44px',
                      height: '44px',
                      backgroundColor: 'rgba(255,255,255,0.1)',
                      borderRadius: '10px',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      flexShrink: 0,
                    }}
                  >
                    <tool.icon style={{ width: '22px', height: '22px', color: '#fff' }} />
                  </div>
                  <div>
                    <div style={{ color: '#fff', fontSize: '16px', fontWeight: 600 }}>
                      {tool.name}
                    </div>
                    <div style={{ color: 'rgba(255,255,255,0.5)', fontSize: '13px', marginTop: '4px', lineHeight: '1.4' }}>
                      {tool.desc}
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <button
              onClick={() => setShowTools(false)}
              style={{
                marginTop: '24px',
                width: '100%',
                padding: '14px',
                backgroundColor: '#fff',
                color: '#000',
                border: 'none',
                borderRadius: '10px',
                fontSize: '15px',
                fontWeight: 600,
                cursor: 'pointer',
              }}
            >
              Fermer
            </button>
          </div>
        </div>
      )}
      </div>
  );
}