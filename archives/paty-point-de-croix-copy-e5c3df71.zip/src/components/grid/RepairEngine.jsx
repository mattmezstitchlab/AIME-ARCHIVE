// MODULE REPAIR_ENGINE - Garantir 0 cases vides
import { DMC_LIBRARY } from './dmcLibrary';

const SYMBOLS = [
  '●', '■', '▲', '◆', '★', '✦', '○', '□', '△', '◇',
  '✕', '✚', '♦', '♠', '♣', '♥', '▼', '◉', '◎', '⬟',
  '⬡', '⬢', '⬣', '✶', '✹', '✸', '✷', '❖', '⚫', '⚪'
];

// Couleur DMC neutre par défaut
const DMC_NEUTRAL = { code: '415', hex: '#9E9E9E', name: 'Gris perle' };

/**
 * Calcule la distance RVB entre deux couleurs
 */
function colorDistance(hex1, hex2) {
  const rgb1 = hexToRgb(hex1);
  const rgb2 = hexToRgb(hex2);
  return Math.sqrt(
    Math.pow(rgb1.r - rgb2.r, 2) +
    Math.pow(rgb1.g - rgb2.g, 2) +
    Math.pow(rgb1.b - rgb2.b, 2)
  );
}

function hexToRgb(hex) {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result ? {
    r: parseInt(result[1], 16),
    g: parseInt(result[2], 16),
    b: parseInt(result[3], 16)
  } : { r: 128, g: 128, b: 128 };
}

/**
 * Trouve la couleur DMC la plus proche
 */
function findClosestDMC(hex) {
  let closest = DMC_NEUTRAL;
  let minDist = Infinity;
  
  (DMC_LIBRARY || []).forEach(dmc => {
    const dist = colorDistance(hex, dmc.hex);
    if (dist < minDist) {
      minDist = dist;
      closest = dmc;
    }
  });
  
  return closest;
}

/**
 * Récupère les 8 voisins d'une cellule
 */
function getNeighbors8(grid, row, col) {
  const neighbors = [];
  const directions = [
    [-1, -1], [-1, 0], [-1, 1],
    [0, -1],          [0, 1],
    [1, -1], [1, 0], [1, 1]
  ];
  
  directions.forEach(([dr, dc]) => {
    const nr = row + dr;
    const nc = col + dc;
    if (nr >= 0 && nr < grid.length && nc >= 0 && nc < grid[0]?.length) {
      const cell = grid[nr][nc];
      if (cell && cell.colorId) {
        neighbors.push(cell);
      }
    }
  });
  
  return neighbors;
}

/**
 * Trouve la couleur dominante parmi les voisins
 */
function getDominantNeighborColor(neighbors, palette) {
  if (!neighbors.length) return null;
  
  const counts = {};
  neighbors.forEach(n => {
    counts[n.colorId] = (counts[n.colorId] || 0) + 1;
  });
  
  const dominant = Object.entries(counts).sort((a, b) => b[1] - a[1])[0];
  return dominant ? dominant[0] : null;
}

/**
 * Module principal REPAIR_ENGINE
 * Garantit 0 cases vides dans la grille
 */
export function repairGrid(pattern, options = {}) {
  if (!pattern?.symbolGrid) {
    return { pattern, stats: { repaired: 0, total: 0, holes: 0 } };
  }

  const { symbolGrid, colorPalette = [] } = pattern;
  const height = symbolGrid.length;
  const width = symbolGrid[0]?.length || 0;
  
  let repairedCount = 0;
  let totalCells = 0;
  let holesDetected = 0;
  
  // Créer une nouvelle grille
  const newGrid = symbolGrid.map((row, rowIdx) => 
    row.map((cell, colIdx) => {
      totalCells++;
      
      // Cellule valide - on la garde
      if (cell && cell.colorId) {
        return cell;
      }
      
      // VOID détecté
      holesDetected++;
      
      // Récupérer les 8 voisins
      const neighbors = getNeighbors8(symbolGrid, rowIdx, colIdx);
      let colorId = getDominantNeighborColor(neighbors, colorPalette);
      
      // Si aucune couleur détectable, utiliser DMC gris 415
      if (!colorId) {
        // Chercher ou créer la couleur neutre
        let neutralColor = colorPalette.find(c => c.dmc === '415' || c.code === 'DMC-415');
        
        if (!neutralColor) {
          colorId = 'color-neutral';
        } else {
          colorId = neutralColor.id;
        }
      }
      
      repairedCount++;
      
      return {
        colorId,
        type: 'S11', // Point SUB VOID
        done: false,
        repaired: true
      };
    })
  );
  
  // Ajouter la couleur neutre si nécessaire
  let newPalette = [...colorPalette];
  const hasNeutral = newPalette.some(c => c.id === 'color-neutral');
  
  if (!hasNeutral && newGrid.some(row => row.some(c => c?.colorId === 'color-neutral'))) {
    newPalette.push({
      id: 'color-neutral',
      hex: DMC_NEUTRAL.hex,
      dmc: DMC_NEUTRAL.code,
      dmcName: DMC_NEUTRAL.name,
      code: `DMC-${DMC_NEUTRAL.code}`,
      name: DMC_NEUTRAL.name,
      symbol: '•',
      assignedSymbolChar: '•',
      count: 0,
      totalCount: 0
    });
  }
  
  // Mettre à jour les compteurs de couleurs
  newPalette = updateColorCounts(newGrid, newPalette);
  
  return {
    pattern: {
      ...pattern,
      symbolGrid: newGrid,
      colorPalette: newPalette
    },
    stats: {
      repaired: repairedCount,
      total: totalCells,
      holes: 0, // Après réparation = 0
      holesDetected
    }
  };
}

/**
 * Met à jour les compteurs de couleurs
 */
function updateColorCounts(grid, palette) {
  const counts = {};
  
  grid.forEach(row => {
    row.forEach(cell => {
      if (cell?.colorId) {
        counts[cell.colorId] = (counts[cell.colorId] || 0) + 1;
      }
    });
  });
  
  return palette.map(color => ({
    ...color,
    count: counts[color.id] || 0,
    totalCount: counts[color.id] || 0
  }));
}

/**
 * Vérification qualité de la grille
 */
export function gridQualityCheck(pattern) {
  if (!pattern?.symbolGrid) {
    return { valid: false, errors: ['Aucune grille détectée'] };
  }

  const errors = [];
  const warnings = [];
  
  let emptyCells = 0;
  let cellsWithoutSymbol = 0;
  let cellsWithoutColor = 0;
  
  // Scanner chaque cellule
  pattern.symbolGrid.forEach((row, r) => {
    row.forEach((cell, c) => {
      if (!cell) {
        emptyCells++;
      } else {
        if (!cell.colorId) cellsWithoutColor++;
      }
    });
  });
  
  // Vérifier les couleurs DMC
  const colorsWithoutDMC = (pattern.colorPalette || []).filter(c => !c.dmc && !c.code);
  
  // Vérifier les symboles
  const colorsWithoutSymbol = (pattern.colorPalette || []).filter(c => !c.symbol && !c.assignedSymbolChar);
  
  // Générer le rapport
  if (emptyCells > 0) errors.push(`${emptyCells} cases vides détectées`);
  if (cellsWithoutColor > 0) errors.push(`${cellsWithoutColor} cases sans couleur`);
  if (colorsWithoutDMC.length > 0) warnings.push(`${colorsWithoutDMC.length} couleurs sans DMC`);
  if (colorsWithoutSymbol.length > 0) warnings.push(`${colorsWithoutSymbol.length} couleurs sans symbole`);
  
  const totalCells = pattern.width * pattern.height;
  const filledCells = totalCells - emptyCells;
  
  return {
    valid: errors.length === 0,
    errors,
    warnings,
    stats: {
      totalCells,
      filledCells,
      emptyCells,
      colors: pattern.colorPalette?.length || 0,
      colorsLinked: pattern.colorPalette?.filter(c => c.dmc || c.code).length || 0,
      symbolsAssigned: pattern.colorPalette?.filter(c => c.symbol || c.assignedSymbolChar).length || 0,
      exportReady: errors.length === 0
    }
  };
}

export default { repairGrid, gridQualityCheck };