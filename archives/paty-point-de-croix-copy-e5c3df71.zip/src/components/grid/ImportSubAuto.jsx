import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { 
  X, Zap, Upload, Loader2, Check, AlertTriangle,
  Settings, Wand2, Wrench, FileText, Image as ImageIcon
} from 'lucide-react';
import { toast } from 'sonner';
import { DMC_LIBRARY } from './dmcLibrary';
import { autoRepairSub } from './SubAutoRepairEngine';
import { SUB_POINTS } from './SubPointsSystem';

// Symboles pour attribution automatique
const AUTO_SYMBOLS = [
  '●', '■', '▲', '◆', '★', '✦', '○', '□', '△', '◇',
  '✕', '✚', '♦', '♠', '♣', '♥', '▼', '◉', '◎', '⬟',
  '⬡', '⬢', '⬣', '✶', '✹', '✸', '✷', '❖', '⚫', '⚪'
];

// Étapes du processus
const STEPS = [
  { id: 'select', label: 'Sélection du fichier', icon: Upload },
  { id: 'convert', label: 'Conversion', icon: Wand2 },
  { id: 'repair', label: 'Réparation des trous', icon: Wrench },
  { id: 'optimize', label: 'Optimisation', icon: Settings },
  { id: 'done', label: 'Grille SUB prête', icon: Check }
];

// Messages de progression
const PROGRESS_MESSAGES = {
  select: '⏳ Analyse du fichier…',
  convert: '🧵 Conversion…',
  repair: '🔧 Réparation des trous…',
  optimize: '✨ Optimisation…',
  done: '✅ Grille SUB prête !'
};

export default function ImportSubAuto({ open, onClose, onComplete }) {
  // États
  const [mode, setMode] = useState('auto'); // auto, semi, pro
  const [currentStep, setCurrentStep] = useState(-1);
  const [isProcessing, setIsProcessing] = useState(false);
  const [file, setFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [error, setError] = useState(null);
  
  // Options semi-assisté
  const [semiOptions, setSemiOptions] = useState({
    colorTolerance: 15,
    repairLevel: 3, // 1-5
    enabledPointStyles: ['S1', 'S3', 'S5']
  });
  
  // Options pro
  const [proOptions, setProOptions] = useState({
    manualZones: false,
    advancedCorrections: false,
    forcePointStyle: null
  });
  
  // Résultats
  const [results, setResults] = useState({
    pattern: null,
    stats: null
  });
  
  const fileInputRef = useRef(null);

  // Reset à l'ouverture
  useEffect(() => {
    if (open) {
      setCurrentStep(-1);
      setFile(null);
      setPreviewUrl(null);
      setError(null);
      setResults({ pattern: null, stats: null });
    }
  }, [open]);

  // Gérer la sélection de fichier
  const handleFileSelect = async (e) => {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;

    const fileName = selectedFile.name.toLowerCase();
    const fileType = selectedFile.type;

    // Vérifier le format
    const validFormats = ['image/png', 'image/jpeg', 'image/jpg', 'application/pdf'];
    const isSubFile = fileName.endsWith('.sub');
    
    if (!validFormats.includes(fileType) && !isSubFile) {
      setError('Format non valide. Essayez PDF, JPG, PNG ou SUB.');
      return;
    }

    setFile(selectedFile);
    setError(null);

    // Aperçu pour les images
    if (fileType.startsWith('image/')) {
      const url = URL.createObjectURL(selectedFile);
      setPreviewUrl(url);
    }

    // Fichier .SUB : import direct
    if (isSubFile) {
      try {
        const content = await selectedFile.text();
        const subData = JSON.parse(content);
        onComplete?.(subData);
        toast.success('Fichier .SUB importé directement');
        onClose();
        return;
      } catch (err) {
        setError('Fichier .SUB invalide');
        return;
      }
    }
  };

  // Lancer le processus complet
  const runImportAuto = async () => {
    if (!file) return;
    
    setIsProcessing(true);
    setError(null);

    try {
      // ===== ÉTAPE 1: Sélection/Analyse =====
      setCurrentStep(0);
      await new Promise(r => setTimeout(r, 400));

      // Charger l'image
      const imageData = await loadImage(file);
      
      // ===== ÉTAPE 2: Conversion =====
      setCurrentStep(1);
      await new Promise(r => setTimeout(r, 500));

      // Extraire couleurs et créer grille
      const { colorPalette, symbolGrid, width, height } = await convertToGrid(
        imageData,
        mode === 'semi' ? semiOptions.colorTolerance : 15
      );

      // ===== ÉTAPE 3: Réparation =====
      setCurrentStep(2);
      await new Promise(r => setTimeout(r, 500));

      // Créer pattern initial
      let pattern = {
        width,
        height,
        sourceImage: previewUrl,
        colorPalette,
        symbolGrid
      };

      // Réparer avec le niveau approprié
      const repairLevel = mode === 'semi' ? semiOptions.repairLevel : 3;
      pattern = await repairGrid(pattern, repairLevel);

      // ===== ÉTAPE 4: Optimisation =====
      setCurrentStep(3);
      await new Promise(r => setTimeout(r, 400));

      // Optimiser
      pattern = await optimizeGrid(pattern, {
        mode,
        semiOptions,
        proOptions
      });

      // Assigner les points SUB
      const enabledPoints = mode === 'semi' 
        ? semiOptions.enabledPointStyles 
        : ['S1', 'S3', 'S5', 'S11'];
      
      pattern = assignSubPoints(pattern, enabledPoints, proOptions.forcePointStyle);

      // ===== ÉTAPE 5: Terminé =====
      setCurrentStep(4);
      await new Promise(r => setTimeout(r, 300));

      // Calculer stats
      const stats = calculateStats(pattern);

      setResults({ pattern, stats });
      toast.success('✅ Grille SUB prête !');

    } catch (err) {
      console.error('Erreur import:', err);
      setError(err.message || 'Erreur lors de l\'import');
    } finally {
      setIsProcessing(false);
    }
  };

  // Charger l'image
  const loadImage = (file) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          
          // Limiter la taille
          const maxSize = 200;
          let w = img.width;
          let h = img.height;
          
          if (w > maxSize || h > maxSize) {
            const ratio = Math.min(maxSize / w, maxSize / h);
            w = Math.round(w * ratio);
            h = Math.round(h * ratio);
          }
          
          canvas.width = w;
          canvas.height = h;
          const ctx = canvas.getContext('2d');
          ctx.imageSmoothingEnabled = false;
          ctx.drawImage(img, 0, 0, w, h);
          
          resolve({
            imageData: ctx.getImageData(0, 0, w, h),
            width: w,
            height: h,
            canvas
          });
        };
        img.onerror = () => reject(new Error('Impossible de charger l\'image'));
        img.src = e.target.result;
      };
      reader.onerror = () => reject(new Error('Erreur de lecture'));
      reader.readAsDataURL(file);
    });
  };

  // Convertir en grille
  const convertToGrid = async (imageData, tolerance) => {
    const { width, height, imageData: imgData } = imageData;
    const quantStep = Math.max(8, 32 - tolerance * 2);
    
    // Extraire et quantifier les couleurs
    const colorMap = new Map();
    const pixels = [];
    
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const idx = (y * width + x) * 4;
        const r = imgData.data[idx];
        const g = imgData.data[idx + 1];
        const b = imgData.data[idx + 2];
        
        const qr = Math.round(r / quantStep) * quantStep;
        const qg = Math.round(g / quantStep) * quantStep;
        const qb = Math.round(b / quantStep) * quantStep;
        
        const key = `${qr},${qg},${qb}`;
        colorMap.set(key, (colorMap.get(key) || 0) + 1);
        pixels.push({ r, g, b, key });
      }
    }
    
    // Top couleurs
    const topColors = Array.from(colorMap.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 48);
    
    // Créer palette avec DMC
    const colorPalette = topColors.map(([key, count], idx) => {
      const [r, g, b] = key.split(',').map(Number);
      const hex = rgbToHex(r, g, b);
      const dmc = findClosestDMC(hex);
      
      return {
        id: `color-${idx}`,
        hex,
        dmc: dmc.code,
        dmcName: dmc.name,
        dmcHex: dmc.hex,
        code: `DMC-${dmc.code}`,
        name: dmc.name,
        symbol: AUTO_SYMBOLS[idx % AUTO_SYMBOLS.length],
        assignedSymbolChar: AUTO_SYMBOLS[idx % AUTO_SYMBOLS.length],
        count,
        totalCount: count
      };
    });
    
    // Créer mapping
    const keyToColorId = new Map();
    topColors.forEach(([key], idx) => {
      keyToColorId.set(key, `color-${idx}`);
    });
    
    // Générer grille - JAMAIS de case vide
    const symbolGrid = [];
    let pixelIdx = 0;
    
    for (let row = 0; row < height; row++) {
      const gridRow = [];
      for (let col = 0; col < width; col++) {
        const pixel = pixels[pixelIdx++];
        let colorId = keyToColorId.get(pixel.key);
        
        if (!colorId) {
          // Trouver la couleur la plus proche
          let minDist = Infinity;
          colorPalette.forEach(c => {
            const rgb = hexToRgb(c.hex);
            const dist = Math.sqrt(
              Math.pow(pixel.r - rgb.r, 2) +
              Math.pow(pixel.g - rgb.g, 2) +
              Math.pow(pixel.b - rgb.b, 2)
            );
            if (dist < minDist) {
              minDist = dist;
              colorId = c.id;
            }
          });
        }
        
        gridRow.push({
          colorId: colorId || 'color-0',
          color: colorId || 'color-0',
          type: 'S1',
          done: false
        });
      }
      symbolGrid.push(gridRow);
    }
    
    return { colorPalette, symbolGrid, width, height };
  };

  // Réparer la grille
  const repairGrid = async (pattern, level) => {
    // Utiliser le moteur de réparation SUB
    const result = autoRepairSub(pattern, { 
      mode: level >= 3 ? 'expert' : 'fast'
    });
    
    if (result.success) {
      return result.pattern;
    }
    
    // Réparation manuelle si échec
    const newGrid = pattern.symbolGrid.map((row, rowIdx) => 
      row.map((cell, colIdx) => {
        if (cell && cell.colorId) return cell;
        
        // Trouver couleur dominante voisine
        const neighbors = getNeighbors(pattern.symbolGrid, rowIdx, colIdx, level);
        if (neighbors.length > 0) {
          const colorCounts = {};
          neighbors.forEach(n => {
            if (n?.colorId) {
              colorCounts[n.colorId] = (colorCounts[n.colorId] || 0) + 1;
            }
          });
          
          const dominant = Object.entries(colorCounts)
            .sort((a, b) => b[1] - a[1])[0];
          
          if (dominant) {
            return { colorId: dominant[0], type: 'S11', done: false };
          }
        }
        
        // Dernier recours
        return { colorId: 'color-0', type: 'S11', done: false };
      })
    );
    
    return { ...pattern, symbolGrid: newGrid };
  };

  // Obtenir voisins selon niveau
  const getNeighbors = (grid, row, col, level) => {
    const neighbors = [];
    const radius = level;
    
    for (let dr = -radius; dr <= radius; dr++) {
      for (let dc = -radius; dc <= radius; dc++) {
        if (dr === 0 && dc === 0) continue;
        const nr = row + dr;
        const nc = col + dc;
        if (nr >= 0 && nr < grid.length && nc >= 0 && nc < grid[0].length) {
          neighbors.push(grid[nr][nc]);
        }
      }
    }
    
    return neighbors;
  };

  // Optimiser la grille
  const optimizeGrid = async (pattern, options) => {
    let newPalette = [...pattern.colorPalette];
    let newGrid = pattern.symbolGrid.map(r => [...r]);
    
    // Fusionner couleurs proches
    const threshold = options.mode === 'semi' ? 30 - options.semiOptions?.colorTolerance : 20;
    const mergeMap = new Map();
    
    for (let i = 0; i < newPalette.length; i++) {
      for (let j = i + 1; j < newPalette.length; j++) {
        const c1 = hexToRgb(newPalette[i].hex);
        const c2 = hexToRgb(newPalette[j].hex);
        const dist = Math.sqrt(
          Math.pow(c1.r - c2.r, 2) +
          Math.pow(c1.g - c2.g, 2) +
          Math.pow(c1.b - c2.b, 2)
        );
        
        if (dist < threshold && !mergeMap.has(newPalette[j].id)) {
          mergeMap.set(newPalette[j].id, newPalette[i].id);
        }
      }
    }
    
    // Appliquer fusions
    if (mergeMap.size > 0) {
      newGrid = newGrid.map(row =>
        row.map(cell => {
          if (cell && mergeMap.has(cell.colorId)) {
            return { ...cell, colorId: mergeMap.get(cell.colorId) };
          }
          return cell;
        })
      );
      
      // Retirer couleurs fusionnées
      newPalette = newPalette.filter(c => !mergeMap.has(c.id));
    }
    
    // Réassigner symboles
    newPalette = newPalette.map((c, idx) => ({
      ...c,
      symbol: AUTO_SYMBOLS[idx % AUTO_SYMBOLS.length],
      assignedSymbolChar: AUTO_SYMBOLS[idx % AUTO_SYMBOLS.length]
    }));
    
    return { ...pattern, colorPalette: newPalette, symbolGrid: newGrid };
  };

  // Assigner points SUB
  const assignSubPoints = (pattern, enabledPoints, forceStyle) => {
    if (forceStyle) {
      // Forcer un style
      const newGrid = pattern.symbolGrid.map(row =>
        row.map(cell => cell ? { ...cell, type: forceStyle } : cell)
      );
      return { ...pattern, symbolGrid: newGrid };
    }
    
    // Attribution intelligente
    const newGrid = pattern.symbolGrid.map((row, rowIdx) =>
      row.map((cell, colIdx) => {
        if (!cell) return cell;
        
        let type = 'S1'; // UNI par défaut
        
        // Détection contour
        const isEdge = detectEdge(pattern.symbolGrid, rowIdx, colIdx);
        if (isEdge && enabledPoints.includes('S3')) {
          type = 'S3'; // TRACE
        }
        
        // Détection zone de transition
        const isTransition = detectTransition(pattern.symbolGrid, rowIdx, colIdx);
        if (isTransition && enabledPoints.includes('S5')) {
          type = 'S5'; // FUSION
        }
        
        return { ...cell, type };
      })
    );
    
    return { ...pattern, symbolGrid: newGrid };
  };

  // Détecter contour
  const detectEdge = (grid, row, col) => {
    const cell = grid[row]?.[col];
    if (!cell) return false;
    
    const neighbors = [
      grid[row - 1]?.[col],
      grid[row + 1]?.[col],
      grid[row]?.[col - 1],
      grid[row]?.[col + 1]
    ];
    
    return neighbors.some(n => !n || n.colorId !== cell.colorId);
  };

  // Détecter transition
  const detectTransition = (grid, row, col) => {
    const cell = grid[row]?.[col];
    if (!cell) return false;
    
    const neighbors = [
      grid[row - 1]?.[col - 1],
      grid[row - 1]?.[col + 1],
      grid[row + 1]?.[col - 1],
      grid[row + 1]?.[col + 1]
    ];
    
    const differentColors = neighbors.filter(n => n && n.colorId !== cell.colorId);
    return differentColors.length >= 2;
  };

  // Calculer stats
  const calculateStats = (pattern) => {
    let total = 0;
    let holes = 0;
    const types = {};
    
    pattern.symbolGrid.forEach(row => {
      row.forEach(cell => {
        if (cell) {
          total++;
          types[cell.type] = (types[cell.type] || 0) + 1;
        } else {
          holes++;
        }
      });
    });
    
    return {
      total,
      holes,
      colors: pattern.colorPalette.length,
      types,
      width: pattern.width,
      height: pattern.height
    };
  };

  // Utilitaires
  const rgbToHex = (r, g, b) => '#' + [r, g, b].map(x => x.toString(16).padStart(2, '0')).join('');
  
  const hexToRgb = (hex) => {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
      r: parseInt(result[1], 16),
      g: parseInt(result[2], 16),
      b: parseInt(result[3], 16)
    } : { r: 0, g: 0, b: 0 };
  };
  
  const findClosestDMC = (hex) => {
    const rgb = hexToRgb(hex);
    let closest = DMC_LIBRARY[0];
    let minDist = Infinity;
    
    DMC_LIBRARY.forEach(dmc => {
      const dmcRgb = hexToRgb(dmc.hex);
      const dist = Math.sqrt(
        Math.pow(rgb.r - dmcRgb.r, 2) +
        Math.pow(rgb.g - dmcRgb.g, 2) +
        Math.pow(rgb.b - dmcRgb.b, 2)
      );
      if (dist < minDist) {
        minDist = dist;
        closest = dmc;
      }
    });
    
    return closest;
  };

  // Ouvrir dans l'éditeur
  const handleOpenInEditor = () => {
    if (results.pattern) {
      // Générer nom automatique
      const now = new Date();
      const dateStr = now.toISOString().slice(0, 10).replace(/-/g, '');
      const timeStr = now.toTimeString().slice(0, 5).replace(':', '');
      results.pattern.name = `IMPORT_SUB_${dateStr}_${timeStr}`;
      
      onComplete?.(results.pattern);
      onClose();
    }
  };

  if (!open) return null;

  return (
    <div 
      className="fixed inset-0 flex items-center justify-center"
      style={{ zIndex: 999999, backgroundColor: 'rgba(0, 0, 0, 0.85)' }}
    >
      <div className="bg-white rounded-2xl shadow-2xl w-[850px] max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-yellow-400 to-yellow-500 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-black flex items-center justify-center">
              <Zap className="w-6 h-6 text-yellow-400" />
            </div>
            <div>
              <h2 className="text-xl font-black text-black">IMPORT SUB AUTO™</h2>
              <p className="text-sm text-black/70">Convertit • Répare • Finalise — sans aucun trou</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-black/10 hover:bg-black/20 flex items-center justify-center"
          >
            <X className="w-5 h-5 text-black" />
          </button>
        </div>

        {/* Barre de progression */}
        {currentStep >= 0 && !results.pattern && (
          <div className="px-6 py-4 bg-gray-50 border-b">
            <div className="flex items-center justify-between mb-2">
              {STEPS.map((step, idx) => {
                const StepIcon = step.icon;
                const isActive = idx === currentStep;
                const isComplete = idx < currentStep;
                
                return (
                  <React.Fragment key={step.id}>
                    <div className="flex flex-col items-center">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${
                        isComplete ? 'bg-green-500 text-white' :
                        isActive ? 'bg-yellow-500 text-black animate-pulse' :
                        'bg-gray-200 text-gray-400'
                      }`}>
                        {isComplete ? <Check className="w-5 h-5" /> : <StepIcon className="w-5 h-5" />}
                      </div>
                      <span className={`text-xs mt-1 ${isActive ? 'font-bold' : ''}`}>{step.label}</span>
                    </div>
                    {idx < STEPS.length - 1 && (
                      <div className={`flex-1 h-0.5 mx-2 ${idx < currentStep ? 'bg-green-500' : 'bg-gray-200'}`} />
                    )}
                  </React.Fragment>
                );
              })}
            </div>
            <p className="text-center text-sm font-medium text-gray-600">
              {PROGRESS_MESSAGES[STEPS[currentStep]?.id] || ''}
            </p>
          </div>
        )}

        {/* Contenu */}
        <div className="p-6 overflow-y-auto" style={{ maxHeight: 'calc(90vh - 200px)' }}>
          {/* Erreur */}
          {error && (
            <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-medium text-red-800">❌ {error}</p>
              </div>
            </div>
          )}

          {/* Écran de sélection */}
          {currentStep === -1 && !results.pattern && (
            <div className="space-y-6">
              {/* Sélection de mode */}
              <div className="grid grid-cols-3 gap-4">
                {[
                  { id: 'auto', name: 'Automatique', desc: 'Tout se fait sans réglage', icon: Zap, color: 'yellow' },
                  { id: 'semi', name: 'Semi-Assisté', desc: '3 paramètres ajustables', icon: Settings, color: 'blue' },
                  { id: 'pro', name: 'Pro', desc: 'Contrôle total', icon: Wrench, color: 'purple' }
                ].map(m => (
                  <button
                    key={m.id}
                    onClick={() => setMode(m.id)}
                    className={`p-4 rounded-xl border-2 text-left transition-all ${
                      mode === m.id 
                        ? `border-${m.color}-500 bg-${m.color}-50` 
                        : 'border-gray-200 hover:border-gray-400'
                    }`}
                  >
                    <m.icon className={`w-8 h-8 mb-2 ${mode === m.id ? `text-${m.color}-500` : 'text-gray-400'}`} />
                    <h3 className="font-bold">{m.name}</h3>
                    <p className="text-sm text-gray-500">{m.desc}</p>
                  </button>
                ))}
              </div>

              {/* Options Semi-Assisté */}
              {mode === 'semi' && (
                <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 space-y-4">
                  <h4 className="font-bold text-blue-800">Paramètres Semi-Assisté</h4>
                  
                  <div className="space-y-2">
                    <Label>Tolérance des couleurs : {semiOptions.colorTolerance}</Label>
                    <Slider
                      value={[semiOptions.colorTolerance]}
                      onValueChange={([v]) => setSemiOptions(p => ({...p, colorTolerance: v}))}
                      min={5}
                      max={30}
                      step={1}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Niveau de réparation : {semiOptions.repairLevel}</Label>
                    <Slider
                      value={[semiOptions.repairLevel]}
                      onValueChange={([v]) => setSemiOptions(p => ({...p, repairLevel: v}))}
                      min={1}
                      max={5}
                      step={1}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Styles de points activés</Label>
                    <div className="flex flex-wrap gap-2">
                      {['S1', 'S3', 'S5', 'S8', 'S11'].map(s => (
                        <button
                          key={s}
                          onClick={() => {
                            const enabled = semiOptions.enabledPointStyles.includes(s);
                            setSemiOptions(p => ({
                              ...p,
                              enabledPointStyles: enabled
                                ? p.enabledPointStyles.filter(x => x !== s)
                                : [...p.enabledPointStyles, s]
                            }));
                          }}
                          className={`px-3 py-1 rounded-lg text-sm font-medium ${
                            semiOptions.enabledPointStyles.includes(s)
                              ? 'bg-blue-500 text-white'
                              : 'bg-white border'
                          }`}
                        >
                          {s}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Options Pro */}
              {mode === 'pro' && (
                <div className="bg-purple-50 border border-purple-200 rounded-xl p-4 space-y-4">
                  <h4 className="font-bold text-purple-800">Options Pro</h4>
                  
                  <div className="flex items-center justify-between">
                    <Label>Sélection manuelle des zones</Label>
                    <Switch
                      checked={proOptions.manualZones}
                      onCheckedChange={(v) => setProOptions(p => ({...p, manualZones: v}))}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <Label>Corrections avancées</Label>
                    <Switch
                      checked={proOptions.advancedCorrections}
                      onCheckedChange={(v) => setProOptions(p => ({...p, advancedCorrections: v}))}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Forcer un style de point</Label>
                    <div className="flex flex-wrap gap-2">
                      <button
                        onClick={() => setProOptions(p => ({...p, forcePointStyle: null}))}
                        className={`px-3 py-1 rounded-lg text-sm font-medium ${
                          !proOptions.forcePointStyle ? 'bg-purple-500 text-white' : 'bg-white border'
                        }`}
                      >
                        Auto
                      </button>
                      {['S1', 'S3', 'S5', 'S6', 'S8'].map(s => (
                        <button
                          key={s}
                          onClick={() => setProOptions(p => ({...p, forcePointStyle: s}))}
                          className={`px-3 py-1 rounded-lg text-sm font-medium ${
                            proOptions.forcePointStyle === s ? 'bg-purple-500 text-white' : 'bg-white border'
                          }`}
                        >
                          {s}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Zone de drop */}
              <div
                className="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center hover:border-yellow-500 transition-colors cursor-pointer"
                onClick={() => fileInputRef.current?.click()}
              >
                {previewUrl ? (
                  <div className="space-y-4">
                    <img src={previewUrl} alt="Aperçu" className="max-h-48 mx-auto rounded-lg shadow" />
                    <p className="text-sm text-gray-500">{file?.name}</p>
                  </div>
                ) : (
                  <>
                    <Upload className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                    <p className="text-lg font-medium mb-2">Déposez votre fichier ici</p>
                    <p className="text-sm text-gray-500">PDF, JPG, PNG ou .SUB</p>
                  </>
                )}
              </div>

              <input
                ref={fileInputRef}
                type="file"
                accept="image/*,.pdf,.sub"
                onChange={handleFileSelect}
                className="hidden"
              />

              {/* Bouton principal */}
              <Button
                onClick={runImportAuto}
                disabled={!file || isProcessing}
                className="w-full h-14 bg-gradient-to-r from-yellow-400 to-yellow-500 hover:from-yellow-500 hover:to-yellow-600 text-black font-black text-lg"
              >
                {isProcessing ? (
                  <Loader2 className="w-6 h-6 animate-spin mr-2" />
                ) : (
                  <Zap className="w-6 h-6 mr-2" />
                )}
                IMPORT SUB AUTO™
              </Button>
            </div>
          )}

          {/* En cours */}
          {isProcessing && (
            <div className="text-center py-12">
              <Loader2 className="w-16 h-16 animate-spin text-yellow-500 mx-auto mb-6" />
              <h3 className="text-xl font-bold">{PROGRESS_MESSAGES[STEPS[currentStep]?.id]}</h3>
            </div>
          )}

          {/* Résultat */}
          {results.pattern && !isProcessing && (
            <div className="text-center space-y-6">
              <div className="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center mx-auto">
                <Check className="w-10 h-10 text-green-600" />
              </div>

              <div>
                <h2 className="text-2xl font-black">✅ Grille SUB prête !</h2>
                <p className="text-gray-600">Sans trou • Avec tous les symboles • Exportable en .SUB</p>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-4 gap-4 max-w-lg mx-auto">
                <div className="bg-gray-50 rounded-lg p-3 text-center">
                  <div className="text-2xl font-bold">{results.stats?.width}×{results.stats?.height}</div>
                  <div className="text-xs text-gray-500">Dimensions</div>
                </div>
                <div className="bg-gray-50 rounded-lg p-3 text-center">
                  <div className="text-2xl font-bold">{results.stats?.total?.toLocaleString()}</div>
                  <div className="text-xs text-gray-500">Points</div>
                </div>
                <div className="bg-gray-50 rounded-lg p-3 text-center">
                  <div className="text-2xl font-bold">{results.stats?.colors}</div>
                  <div className="text-xs text-gray-500">Couleurs</div>
                </div>
                <div className="bg-green-50 rounded-lg p-3 text-center border border-green-200">
                  <div className="text-2xl font-bold text-green-600">{results.stats?.holes}</div>
                  <div className="text-xs text-green-600">Trous</div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-4 justify-center">
                <Button variant="outline" onClick={() => {
                  setResults({ pattern: null, stats: null });
                  setCurrentStep(-1);
                }}>
                  Recommencer
                </Button>
                <Button
                  onClick={handleOpenInEditor}
                  className="bg-gradient-to-r from-yellow-400 to-yellow-500 text-black font-bold px-8"
                >
                  Ouvrir dans l'éditeur
                </Button>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-gray-50 border-t text-center">
          <p className="text-xs text-gray-500">
            <span className="font-black text-yellow-600">IMPORT SUB AUTO™</span> — Le premier import au monde qui convertit, répare et finalise sans aucun trou.
          </p>
        </div>
      </div>
    </div>
  );
}