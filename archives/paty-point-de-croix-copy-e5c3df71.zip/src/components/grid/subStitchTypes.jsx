// =============================================
// POINTS SUB™ — INNOVATION OFFICIELLE LECOINTRE
// 12 points modernes, simples, universels
// =============================================

export const SUB_STITCH_TYPES = [
  {
    id: 'S1',
    code: 'S1',
    name: 'Point SUB Uni',
    description: 'Point standard sans défaut — Base de toute broderie SUB',
    icon: '●',
    color: '#000000',
    category: 'base',
    difficulty: 1,
    usage: 'Remplissage standard, zones uniformes'
  },
  {
    id: 'S2',
    code: 'S2',
    name: 'Point SUB Double',
    description: 'Plus visible, idéal pour les contours marqués',
    icon: '◉',
    color: '#1a1a1a',
    category: 'structure',
    difficulty: 1,
    usage: 'Contours, bordures, délimitations fortes'
  },
  {
    id: 'S3',
    code: 'S3',
    name: 'Point SUB Diagonal',
    description: 'Effets inclinés pour dynamisme et mouvement',
    icon: '◇',
    color: '#333333',
    category: 'effect',
    difficulty: 2,
    usage: 'Lignes diagonales, cheveux, textures directionnelles'
  },
  {
    id: 'S4',
    code: 'S4',
    name: 'Point SUB Renfort',
    description: 'Zones fragiles et contrastes marqués',
    icon: '■',
    color: '#444444',
    category: 'structure',
    difficulty: 2,
    usage: 'Transitions fortes, zones de contraste élevé'
  },
  {
    id: 'S5',
    code: 'S5',
    name: 'Point SUB Gradient',
    description: 'Dégradés fluides entre couleurs proches',
    icon: '▣',
    color: '#555555',
    category: 'effect',
    difficulty: 3,
    usage: 'Dégradés, fondus, transitions douces'
  },
  {
    id: 'S6',
    code: 'S6',
    name: 'Point SUB Ombre',
    description: 'Volume et effet 3D pour profondeur',
    icon: '▤',
    color: '#666666',
    category: 'effect',
    difficulty: 3,
    usage: 'Ombres, profondeur, relief'
  },
  {
    id: 'S7',
    code: 'S7',
    name: 'Point SUB Lumière',
    description: 'Zones éclairées et reflets',
    icon: '✦',
    color: '#FFDD00',
    category: 'effect',
    difficulty: 3,
    usage: 'Reflets, brillance, lumière'
  },
  {
    id: 'S8',
    code: 'S8',
    name: 'Point SUB Mix',
    description: 'Fusion de 2 couleurs pour effet mélangé',
    icon: '◈',
    color: '#888888',
    category: 'advanced',
    difficulty: 4,
    usage: 'Mélanges optiques, textures complexes'
  },
  {
    id: 'S9',
    code: 'S9',
    name: 'Point SUB Pixel',
    description: 'Détails fins et précision maximale',
    icon: '▪',
    color: '#999999',
    category: 'detail',
    difficulty: 2,
    usage: 'Détails minutieux, yeux, petits éléments'
  },
  {
    id: 'S10',
    code: 'S10',
    name: 'Point SUB Contour',
    description: 'Délimitation nette des formes',
    icon: '□',
    color: '#000000',
    category: 'structure',
    difficulty: 2,
    usage: 'Contours externes, séparation de zones'
  },
  {
    id: 'S11',
    code: 'S11',
    name: 'Point SUB Emblème',
    description: 'Marqueurs et logos — Points spéciaux',
    icon: '★',
    color: '#C8341F',
    category: 'special',
    difficulty: 3,
    usage: 'Logos, signatures, points d\'intérêt'
  },
  {
    id: 'S0',
    code: 'S0',
    name: 'Point SUB Zero',
    description: 'Point de verrouillage — Brevet LECOINTRE SUB™',
    icon: '◎',
    color: '#F5C200',
    category: 'lock',
    difficulty: 1,
    usage: 'Verrouillage des transitions, ancrage des zones'
  }
];

// Catégories de points SUB
export const SUB_STITCH_CATEGORIES = {
  base: { name: 'Base', color: '#000000' },
  structure: { name: 'Structure', color: '#333333' },
  effect: { name: 'Effets', color: '#666666' },
  detail: { name: 'Détails', color: '#999999' },
  advanced: { name: 'Avancé', color: '#555555' },
  special: { name: 'Spécial', color: '#C8341F' },
  lock: { name: 'Verrouillage', color: '#F5C200' }
};

// Récupérer un point SUB par son code
export const getSubStitchByCode = (code) => {
  return SUB_STITCH_TYPES.find(s => s.code === code) || SUB_STITCH_TYPES[0];
};

// Récupérer tous les points d'une catégorie
export const getSubStitchesByCategory = (category) => {
  return SUB_STITCH_TYPES.filter(s => s.category === category);
};

// Déterminer automatiquement le meilleur point SUB pour une situation
export const autoSelectSubStitch = (context) => {
  const { isEdge, isGradient, isShadow, isHighlight, isDetail, isLogo, isTransition } = context;

  if (isLogo) return 'S11';
  if (isTransition) return 'S0';
  if (isHighlight) return 'S7';
  if (isShadow) return 'S6';
  if (isGradient) return 'S5';
  if (isEdge) return 'S10';
  if (isDetail) return 'S9';
  
  return 'S1'; // Par défaut: Point SUB Uni
};

// Message commercial
export const SUB_STITCH_MARKETING = {
  tagline: "12 points. Zéro complexité. 100% brodable.",
  description: "Les points SUB™ remplacent les anciens styles complexes par 12 outils simples, modernes, rapides et universels.",
  benefits: [
    "1 couleur = 1 point SUB",
    "Compatible DMC",
    "Aucune superposition",
    "Aucune ambiguïté visuelle",
    "Lecture universelle"
  ]
};