import React from 'react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu';
import { Search, Maximize, MousePointer2, Sparkles } from 'lucide-react';

const ZOOM_LEVELS = [
  { value: 0.1, label: '10%' },
  { value: 0.25, label: '25%' },
  { value: 0.5, label: '50%' },
  { value: 0.75, label: '75%' },
  { value: 1.0, label: '100%', isReset: true },
  { value: 1.5, label: '150%' },
  { value: 2.0, label: '200%' },
  { value: 3.0, label: '300%' },
  { value: 4.0, label: '400%' },
];

const SMART_ZOOMS = [
  { id: 'auto', icon: Maximize, label: 'Recentrer', color: '#10B981' },
];

export default function ZoomToolsDropdown({ 
  children, 
  currentZoom = 1,
  onZoomChange,
  onZoomToSelection,
  onZoomToSymbol,
  onZoomAuto,
  open,
  onOpenChange 
}) {
  const currentZoomPercent = Math.round(currentZoom * 100);

  const handleZoomSelect = (zoomValue) => {
    onZoomChange?.(zoomValue);
    onOpenChange?.(false);
  };

  const handleSmartZoom = (type) => {
    switch (type) {
      case 'selection':
        onZoomToSelection?.();
        break;
      case 'symbol':
        onZoomToSymbol?.();
        break;
      case 'auto':
        onZoomAuto?.();
        break;
    }
    onOpenChange?.(false);
  };

  return (
    <DropdownMenu open={open} onOpenChange={onOpenChange}>
      <DropdownMenuTrigger asChild>
        {children}
      </DropdownMenuTrigger>
      <DropdownMenuContent 
        side="bottom" 
        align="start" 
        className="w-52 p-0 bg-[#1a1a1a] border-[#333] rounded-xl overflow-hidden"
        sideOffset={8}
      >
        {/* Header */}
        <div className="px-4 py-2 bg-gradient-to-r from-[#FFC94A]/20 to-transparent border-b border-[#333]">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Search className="w-4 h-4 text-[#FFC94A]" />
              <span className="text-white font-semibold text-sm">Zoom</span>
            </div>
            <span className="text-[#FFC94A] font-bold text-sm">{currentZoomPercent}%</span>
          </div>
        </div>

        {/* Zoom levels */}
        <div className="py-1 max-h-64 overflow-y-auto">
          {ZOOM_LEVELS.map((level) => {
            const isActive = Math.abs(currentZoom - level.value) < 0.01;
            return (
              <DropdownMenuItem
                key={level.value}
                onClick={() => handleZoomSelect(level.value)}
                className={`mx-2 px-3 py-2 rounded-lg cursor-pointer transition-all ${
                  isActive 
                    ? 'bg-[#FFC94A] text-black' 
                    : 'hover:bg-white/5 text-white'
                }`}
              >
                <div className="flex items-center justify-between w-full">
                  <span className={`font-medium text-sm ${isActive ? 'text-black' : ''}`}>
                    {level.label}
                  </span>
                  {level.isReset && (
                    <span className={`text-xs px-1.5 py-0.5 rounded ${
                      isActive ? 'bg-black/20 text-black' : 'bg-white/10 text-[#888]'
                    }`}>
                      Reset
                    </span>
                  )}
                  {isActive && !level.isReset && (
                    <span className="text-black text-xs">✓</span>
                  )}
                </div>
              </DropdownMenuItem>
            );
          })}
        </div>

        <DropdownMenuSeparator className="bg-[#333] my-1" />

        {/* Smart zooms */}
        <div className="py-1 pb-2">
          {SMART_ZOOMS.map((smartZoom) => (
            <DropdownMenuItem
              key={smartZoom.id}
              onClick={() => handleSmartZoom(smartZoom.id)}
              className="mx-2 px-3 py-2 rounded-lg cursor-pointer hover:bg-white/5 transition-all"
            >
              <div className="flex items-center gap-2 w-full">
                <smartZoom.icon 
                  className="w-4 h-4" 
                  style={{ color: smartZoom.color }} 
                />
                <span className="text-white text-sm">{smartZoom.label}</span>
              </div>
            </DropdownMenuItem>
          ))}
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

export { ZOOM_LEVELS, SMART_ZOOMS };