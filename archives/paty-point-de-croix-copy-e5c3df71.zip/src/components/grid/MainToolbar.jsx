import React, { useState } from 'react';
import {
  Pencil, Eraser, PaintBucket, MousePointer2, Hand,
  ZoomIn, ZoomOut, Grid3X3, Type, Upload, Palette, Map,
  Menu, User, Settings, ShoppingBag, FolderOpen, HelpCircle, CreditCard, X
} from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { createPageUrl } from '@/utils';
import { Link } from 'react-router-dom';

// Couleurs PatyBee
const COLORS = {
  background: '#111111',
  text: '#FFFFFF',
  accent: '#FFC94A',
  accentText: '#111111',
  disabled: '#555555',
};

export default function MainToolbar({
  currentTool,
  onToolSelect,
  onZoomIn,
  onZoomOut,
  showGrid,
  onToggleGrid,
  showSymbols,
  onToggleSymbols,
  onImport,
  showPalette,
  onTogglePalette,
  showMiniMap,
  onToggleMiniMap,
  pattern,
}) {
  const hasPattern = !!pattern;
  const [showBurgerMenu, setShowBurgerMenu] = useState(false);

  // Icône outil
  const ToolIcon = ({ icon: Icon, label, active, disabled, onClick }) => (
    <Tooltip>
      <TooltipTrigger asChild>
        <button
          onClick={onClick}
          disabled={disabled}
          style={{
            width: '40px',
            height: '40px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            borderRadius: '8px',
            backgroundColor: active ? COLORS.accent : 'transparent',
            color: active ? COLORS.accentText : COLORS.text,
            cursor: disabled ? 'not-allowed' : 'pointer',
            opacity: disabled ? 0.4 : 1,
            border: 'none',
            transition: 'all 0.15s',
          }}
        >
          <Icon style={{ width: '20px', height: '20px' }} />
        </button>
      </TooltipTrigger>
      <TooltipContent side="bottom"><p>{label}</p></TooltipContent>
    </Tooltip>
  );

  // Bouton accent jaune
  const AccentBtn = ({ icon: Icon, label, onClick, disabled }) => (
    <Tooltip>
      <TooltipTrigger asChild>
        <button
          onClick={onClick}
          disabled={disabled}
          style={{
            height: '36px',
            padding: '0 14px',
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            borderRadius: '8px',
            backgroundColor: COLORS.accent,
            color: COLORS.accentText,
            fontWeight: 700,
            fontSize: '13px',
            border: 'none',
            cursor: disabled ? 'not-allowed' : 'pointer',
            opacity: disabled ? 0.5 : 1,
            whiteSpace: 'nowrap',
          }}
        >
          <Icon style={{ width: '18px', height: '18px' }} />
          <span>{label}</span>
        </button>
      </TooltipTrigger>
      <TooltipContent side="bottom"><p>{label}</p></TooltipContent>
    </Tooltip>
  );

  return (
    <TooltipProvider>
      {/* BARRE OUTILS BRODERIE - Fond noir fixe */}
      <div 
        style={{ 
          height: '56px', 
          backgroundColor: COLORS.background,
          display: 'flex',
          alignItems: 'center',
          padding: '0 16px',
          gap: '8px',
          width: '100%',
        }}
      >
        {/* LOGO PATYBEE */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', paddingRight: '16px', borderRight: '1px solid #333' }}>
          <div style={{
            width: '32px',
            height: '32px',
            backgroundColor: COLORS.accent,
            borderRadius: '8px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}>
            <span style={{ fontSize: '16px', fontWeight: 800, color: COLORS.accentText }}>P</span>
          </div>
          <span style={{ color: COLORS.text, fontWeight: 700, fontSize: '16px' }}>PatyBee</span>
        </div>

        {/* OUTILS DE DESSIN */}
        <ToolIcon icon={Pencil} label="Crayon" active={currentTool === 'cross' || currentTool === 'pencil'} onClick={() => onToolSelect?.('pencil')} />
        <ToolIcon icon={Eraser} label="Gomme" active={currentTool === 'erase'} onClick={() => onToolSelect?.('erase')} disabled={!hasPattern} />
        <ToolIcon icon={PaintBucket} label="Remplissage" active={currentTool === 'fill'} onClick={() => onToolSelect?.('fill')} disabled={!hasPattern} />
        <ToolIcon icon={MousePointer2} label="Sélection" active={currentTool === 'select'} onClick={() => onToolSelect?.('select')} />
        
        {/* Séparateur */}
        <div style={{ width: '1px', height: '28px', backgroundColor: '#333' }} />

        {/* ZOOM */}
        <ToolIcon icon={ZoomOut} label="Zoom –" onClick={onZoomOut} />
        <ToolIcon icon={ZoomIn} label="Zoom +" onClick={onZoomIn} />
        <ToolIcon icon={Hand} label="Déplacement" active={currentTool === 'pan'} onClick={() => onToolSelect?.('pan')} />

        {/* Séparateur */}
        <div style={{ width: '1px', height: '28px', backgroundColor: '#333' }} />

        {/* AFFICHAGE */}
        <ToolIcon icon={Grid3X3} label="Grille ON/OFF" active={showGrid} onClick={onToggleGrid} />
        <ToolIcon icon={Type} label="Symboles ON/OFF" active={showSymbols} onClick={onToggleSymbols} />

        {/* Séparateur */}
        <div style={{ width: '1px', height: '28px', backgroundColor: '#333' }} />

        {/* IMPORT SUB 2.0 */}
        <AccentBtn icon={Upload} label="Import SUB 2.0" onClick={onImport} />

        {/* PALETTE DMC */}
        <Tooltip>
          <TooltipTrigger asChild>
            <button
              onClick={onTogglePalette}
              style={{
                height: '36px',
                padding: '0 14px',
                borderRadius: '8px',
                backgroundColor: showPalette ? COLORS.accent : 'rgba(255,255,255,0.15)',
                color: showPalette ? COLORS.accentText : COLORS.text,
                fontWeight: 600,
                fontSize: '13px',
                border: 'none',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
              }}
            >
              <Palette style={{ width: '18px', height: '18px' }} />
              Palette DMC
            </button>
          </TooltipTrigger>
          <TooltipContent><p>{showPalette ? 'Masquer' : 'Afficher'} la palette DMC</p></TooltipContent>
        </Tooltip>

        {/* CARTE PRO */}
        <Tooltip>
          <TooltipTrigger asChild>
            <button
              onClick={onToggleMiniMap}
              style={{
                height: '36px',
                padding: '0 14px',
                borderRadius: '8px',
                backgroundColor: showMiniMap ? COLORS.accent : 'rgba(255,255,255,0.15)',
                color: showMiniMap ? COLORS.accentText : COLORS.text,
                fontWeight: 600,
                fontSize: '13px',
                border: 'none',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
              }}
            >
              <Map style={{ width: '18px', height: '18px' }} />
              Carte Pro™
            </button>
          </TooltipTrigger>
          <TooltipContent><p>{showMiniMap ? 'Masquer' : 'Afficher'} la Mini-Carte Pro™</p></TooltipContent>
        </Tooltip>

        {/* Espace flexible */}
        <div style={{ flex: 1 }} />

        {/* MENU BURGER */}
        <Tooltip>
          <TooltipTrigger asChild>
            <button
              onClick={() => setShowBurgerMenu(!showBurgerMenu)}
              style={{
                width: '40px',
                height: '40px',
                borderRadius: '8px',
                backgroundColor: showBurgerMenu ? COLORS.accent : 'rgba(255,255,255,0.1)',
                color: showBurgerMenu ? COLORS.accentText : COLORS.text,
                border: 'none',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Menu style={{ width: '22px', height: '22px' }} />
            </button>
          </TooltipTrigger>
          <TooltipContent><p>Menu</p></TooltipContent>
        </Tooltip>
      </div>

      {/* MENU BURGER (panneau latéral) */}
      {showBurgerMenu && (
        <>
          {/* Overlay */}
          <div 
            onClick={() => setShowBurgerMenu(false)}
            style={{
              position: 'fixed',
              inset: 0,
              backgroundColor: 'rgba(0,0,0,0.5)',
              zIndex: 998,
            }}
          />
          {/* Panneau */}
          <div
            style={{
              position: 'fixed',
              top: 0,
              right: 0,
              width: '280px',
              height: '100vh',
              backgroundColor: '#111',
              zIndex: 999,
              padding: '20px',
              display: 'flex',
              flexDirection: 'column',
              gap: '8px',
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
              <span style={{ color: COLORS.text, fontWeight: 700, fontSize: '18px' }}>Menu</span>
              <button
                onClick={() => setShowBurgerMenu(false)}
                style={{ background: 'none', border: 'none', cursor: 'pointer' }}
              >
                <X style={{ width: '24px', height: '24px', color: '#888' }} />
              </button>
            </div>

            <Link to={createPageUrl('Profile')} style={{ textDecoration: 'none' }}>
              <MenuLink icon={User} label="Profil" />
            </Link>
            <Link to={createPageUrl('Settings')} style={{ textDecoration: 'none' }}>
              <MenuLink icon={Settings} label="Réglages" />
            </Link>
            <Link to={createPageUrl('Shop')} style={{ textDecoration: 'none' }}>
              <MenuLink icon={ShoppingBag} label="Boutique" />
            </Link>
            <Link to={createPageUrl('Projects')} style={{ textDecoration: 'none' }}>
              <MenuLink icon={FolderOpen} label="Mes patrons" />
            </Link>
            <Link to={createPageUrl('Help')} style={{ textDecoration: 'none' }}>
              <MenuLink icon={HelpCircle} label="Aide / Tutoriels" />
            </Link>
            <Link to={createPageUrl('Pricing')} style={{ textDecoration: 'none' }}>
              <MenuLink icon={CreditCard} label="Abonnement" />
            </Link>
          </div>
        </>
      )}
    </TooltipProvider>
  );
}

// Composant lien menu
function MenuLink({ icon: Icon, label }) {
  return (
    <div
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: '12px',
        padding: '14px 16px',
        borderRadius: '10px',
        backgroundColor: 'rgba(255,255,255,0.05)',
        color: '#fff',
        cursor: 'pointer',
        transition: 'background 0.15s',
      }}
      onMouseEnter={(e) => e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.1)'}
      onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.05)'}
    >
      <Icon style={{ width: '20px', height: '20px', color: '#FFC94A' }} />
      <span style={{ fontSize: '14px', fontWeight: 500 }}>{label}</span>
    </div>
  );
}