import React from 'react';
import { Undo2, Redo2 } from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';

export default function UndoRedoControls({ 
  canUndo, 
  canRedo, 
  onUndo, 
  onRedo 
}) {
  return (
    <TooltipProvider delayDuration={300}>
      <div 
        className="w-full h-9 bg-[#F5F5F5] border-b border-gray-200 flex items-center px-3 gap-2"
        style={{ 
          boxShadow: '0 1px 3px rgba(0,0,0,0.05)'
        }}
      >
        {/* Bouton Annuler */}
        <Tooltip>
          <TooltipTrigger asChild>
            <button
              onClick={onUndo}
              disabled={!canUndo}
              className={`w-8 h-8 rounded-md flex items-center justify-center transition-all duration-200 ${
                canUndo 
                  ? 'bg-white hover:bg-gray-100 text-gray-700 border border-gray-300 cursor-pointer' 
                  : 'bg-gray-100 text-gray-400 border border-gray-200 cursor-not-allowed'
              }`}
              aria-label="Annuler"
            >
              <Undo2 className="w-4 h-4" />
            </button>
          </TooltipTrigger>
          <TooltipContent side="bottom" className="bg-black text-white text-xs">
            <p>Annuler (Ctrl+Z)</p>
          </TooltipContent>
        </Tooltip>

        {/* Bouton Rétablir */}
        <Tooltip>
          <TooltipTrigger asChild>
            <button
              onClick={onRedo}
              disabled={!canRedo}
              className={`w-8 h-8 rounded-md flex items-center justify-center transition-all duration-200 ${
                canRedo 
                  ? 'bg-white hover:bg-gray-100 text-gray-700 border border-gray-300 cursor-pointer' 
                  : 'bg-gray-100 text-gray-400 border border-gray-200 cursor-not-allowed'
              }`}
              aria-label="Rétablir"
            >
              <Redo2 className="w-4 h-4" />
            </button>
          </TooltipTrigger>
          <TooltipContent side="bottom" className="bg-black text-white text-xs">
            <p>Rétablir (Ctrl+Shift+Z)</p>
          </TooltipContent>
        </Tooltip>

        {/* Séparateur visuel */}
        <div className="h-5 w-px bg-gray-300 ml-1" />
        
        {/* Label optionnel */}
        <span className="text-xs text-gray-500 hidden sm:inline">Actions</span>
      </div>
    </TooltipProvider>
  );
}