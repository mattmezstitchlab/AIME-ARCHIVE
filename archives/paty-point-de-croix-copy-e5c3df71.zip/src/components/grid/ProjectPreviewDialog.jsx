import React, { useRef, useEffect } from 'react';
import { X, Grid3X3, Palette } from 'lucide-react';

export default function ProjectPreviewDialog({ project, open, onClose }) {
  const canvasRef = useRef(null);

  useEffect(() => {
    if (!open || !project || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const pattern = project.pattern;

    if (!pattern?.symbolGrid) {
      ctx.fillStyle = '#1a1a1a';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = '#666';
      ctx.font = '14px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('Aucun motif', canvas.width / 2, canvas.height / 2);
      return;
    }

    const grid = pattern.symbolGrid;
    const rows = grid.length;
    const cols = grid[0]?.length || 0;

    if (rows === 0 || cols === 0) return;

    const cellSize = Math.min(
      Math.floor(canvas.width / cols),
      Math.floor(canvas.height / rows),
      8
    );

    const offsetX = Math.floor((canvas.width - cols * cellSize) / 2);
    const offsetY = Math.floor((canvas.height - rows * cellSize) / 2);

    ctx.fillStyle = '#1a1a1a';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    for (let row = 0; row < rows; row++) {
      for (let col = 0; col < cols; col++) {
        const cell = grid[row]?.[col];
        if (cell?.color) {
          ctx.fillStyle = cell.color;
          ctx.fillRect(
            offsetX + col * cellSize,
            offsetY + row * cellSize,
            cellSize,
            cellSize
          );
        }
      }
    }
  }, [open, project]);

  if (!open || !project) return null;

  const pattern = project.pattern;
  const grid = pattern?.symbolGrid;
  const rows = grid?.length || 0;
  const cols = grid?.[0]?.length || 0;
  const colors = pattern?.colors || [];

  return (
    <div className="fixed inset-0 z-[500] flex items-center justify-center">
      <div 
        className="absolute inset-0 bg-black/70 backdrop-blur-sm"
        onClick={onClose}
      />
      
      <div className="relative bg-[#111] rounded-2xl shadow-2xl border border-[#333] w-[600px] max-w-[90vw] max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-[#333] flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-white">{project.name || 'Sans titre'}</h2>
            <p className="text-xs text-gray-500">Mode lecture seule</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-white/10 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-gray-400" />
          </button>
        </div>

        {/* Aperçu */}
        <div className="p-6">
          <canvas
            ref={canvasRef}
            width={500}
            height={400}
            className="w-full bg-[#0a0a0a] rounded-lg border border-[#222]"
          />
        </div>

        {/* Infos */}
        <div className="px-6 pb-6 flex gap-4">
          <div className="flex items-center gap-2 px-3 py-2 bg-white/5 rounded-lg">
            <Grid3X3 className="w-4 h-4 text-[#FFC94A]" />
            <span className="text-sm text-white">{cols} × {rows}</span>
          </div>
          <div className="flex items-center gap-2 px-3 py-2 bg-white/5 rounded-lg">
            <Palette className="w-4 h-4 text-[#A855F7]" />
            <span className="text-sm text-white">{colors.length} couleurs</span>
          </div>
          <div className="text-xs text-gray-500 ml-auto self-center">
            Modifié le {new Date(project.updated_date).toLocaleDateString('fr-FR')}
          </div>
        </div>
      </div>
    </div>
  );
}