import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { X, ChevronLeft, ChevronRight, Zap, Sparkles, Target, Cpu, Globe, Rocket } from 'lucide-react';

const SLIDES = [
  {
    id: 1,
    title: 'RÉVOLUTION',
    subtitle: 'SUB : le premier système universel de broderie moderne.',
    icon: Zap,
    color: 'from-yellow-400 to-orange-500',
    description: 'Oubliez les formats obsolètes. SUB™ unifie la création, le partage et la broderie dans un seul standard mondial.'
  },
  {
    id: 2,
    title: 'SIMPLICITÉ',
    subtitle: '12 points SUB remplacent des centaines de techniques complexes.',
    icon: Sparkles,
    color: 'from-pink-400 to-purple-500',
    description: 'Du Point Uni au Point Zero, chaque point SUB est conçu pour être immédiatement compréhensible et reproductible.'
  },
  {
    id: 3,
    title: 'PRÉCISION',
    subtitle: 'Zéro trou. Zéro symbole manquant. Zéro erreur.',
    icon: Target,
    color: 'from-green-400 to-teal-500',
    description: 'Le moteur SUB garantit que chaque grille est 100% complète. Plus jamais de surprise au milieu d\'un ouvrage.'
  },
  {
    id: 4,
    title: 'TECHNOLOGIE',
    subtitle: 'Analyse automatique, réparation instantanée, optimisation DMC.',
    icon: Cpu,
    color: 'from-blue-400 to-indigo-500',
    description: 'L\'intelligence artificielle SUB corrige, optimise et prépare vos motifs en un clic. Technologie LECOINTRE brevetée.'
  },
  {
    id: 5,
    title: 'UNIVERSALITÉ',
    subtitle: 'Compatible avec toutes les brodeuses, tous les pays, tous les niveaux.',
    icon: Globe,
    color: 'from-cyan-400 to-blue-500',
    description: 'Que vous soyez débutante ou experte, en France ou au Japon, SUB parle le même langage universel.'
  },
  {
    id: 6,
    title: 'L\'AVENIR',
    subtitle: 'SUB™ : la nouvelle norme mondiale du point.',
    icon: Rocket,
    color: 'from-orange-400 to-red-500',
    description: 'Rejoignez la révolution. Créez, partagez et brodez avec le format qui définira les 50 prochaines années.'
  }
];

export default function SubDiscoveryCarousel({ open, onClose, onStart }) {
  const [currentSlide, setCurrentSlide] = useState(0);

  if (!open) return null;

  const slide = SLIDES[currentSlide];
  const SlideIcon = slide.icon;

  const nextSlide = () => {
    setCurrentSlide(prev => (prev + 1) % SLIDES.length);
  };

  const prevSlide = () => {
    setCurrentSlide(prev => (prev - 1 + SLIDES.length) % SLIDES.length);
  };

  const handleStart = () => {
    onStart?.();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[99999] flex items-center justify-center bg-black/80">
      <div className="relative w-full max-w-2xl mx-4">
        {/* Card principale */}
        <div className="bg-white rounded-2xl shadow-2xl overflow-hidden">
          {/* Header avec gradient */}
          <div className={`bg-gradient-to-r ${slide.color} px-8 py-12 text-center relative`}>
            {/* Bouton fermer */}
            <button
              onClick={onClose}
              className="absolute top-4 right-4 w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center transition-colors"
            >
              <X className="w-5 h-5 text-white" />
            </button>

            {/* Icône */}
            <div className="w-20 h-20 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center mx-auto mb-6">
              <SlideIcon className="w-10 h-10 text-white" />
            </div>

            {/* Titre */}
            <h2 className="text-4xl font-black text-white mb-2 tracking-tight">
              {slide.title}
            </h2>
            <p className="text-white/90 text-lg font-medium max-w-md mx-auto">
              {slide.subtitle}
            </p>
          </div>

          {/* Contenu */}
          <div className="px-8 py-6">
            <p className="text-gray-600 text-center text-lg leading-relaxed">
              {slide.description}
            </p>
          </div>

          {/* Indicateurs */}
          <div className="flex justify-center gap-2 pb-4">
            {SLIDES.map((_, idx) => (
              <button
                key={idx}
                onClick={() => setCurrentSlide(idx)}
                className={`w-2.5 h-2.5 rounded-full transition-all ${
                  idx === currentSlide ? 'bg-yellow-500 w-8' : 'bg-gray-300 hover:bg-gray-400'
                }`}
              />
            ))}
          </div>

          {/* Navigation */}
          <div className="px-6 py-4 border-t bg-gray-50 flex items-center justify-between">
            <Button
              variant="ghost"
              onClick={prevSlide}
              disabled={currentSlide === 0}
              className="gap-1"
            >
              <ChevronLeft className="w-4 h-4" />
              Précédent
            </Button>

            <div className="flex gap-3">
              {currentSlide === SLIDES.length - 1 ? (
                <Button
                  onClick={handleStart}
                  className="bg-gradient-to-r from-yellow-400 to-yellow-500 hover:from-yellow-500 hover:to-yellow-600 text-black font-bold px-8"
                >
                  <Zap className="w-4 h-4 mr-2" />
                  Essayer SUB maintenant
                </Button>
              ) : (
                <Button
                  onClick={nextSlide}
                  className="bg-black text-white hover:bg-gray-800 gap-1"
                >
                  Suivant
                  <ChevronRight className="w-4 h-4" />
                </Button>
              )}
            </div>
          </div>
        </div>

        {/* Badge SUB */}
        <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 bg-black text-white text-xs font-bold px-4 py-1.5 rounded-full">
          SUB™ — Système Universel de Broderie
        </div>
      </div>
    </div>
  );
}