import React, { useRef, useEffect, useState } from 'react';
import { cn } from '@/lib/utils';
import { useSettings } from '../settings/SettingsContext';
import { usePatyBee } from '../patybee/PatyBeeContext';
import { 
  ZoomIn, ZoomOut, Maximize2, RefreshCw, Navigation2, 
  Palette, Sparkles, Eye, EyeOff, Lightbulb, ChevronRight,
  Grid3x3, MapPin, Target
} from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';

export default function MiniMap4D({
  nbColonnes,
  nbLignes,
  tailleCase,
  zoom,
  offsetX,
  offsetY,
  canvasWidth,
  canvasHeight,
  onNavigate,
  mosaicConfig,
  showMosaicGuides,
  onToggleMosaicGuides,
  showCenterMarker,
  onToggleCenterMarker,
  onZoomIn,
  onZoomOut,
  onResetZoom,
  pattern,
  selectedColorId,
  onChangeFormat,
  onZoomToColor,
  onZoomToDenseZone,
  onZoomToIsolated
}) {
  const { settings } = useSettings();
  const { showGuidance } = usePatyBee();
  const canvasRef = useRef(null);
  
  const [activeTab, setActiveTab] = useState('navigation');
  const [isDragging, setIsDragging] = useState(false);
  const [autoSync, setAutoSync] = useState(true);
  const [highlightMode, setHighlightMode] = useState('none'); // none, color, confetti, dense
  const [aiEnabled, setAiEnabled] = useState(false);
  const [aiSuggestion, setAiSuggestion] = useState(null);
  const [displayMode, setDisplayMode] = useState('standard'); // standard, detailed, simplified, fog
  
  const miniMapSize = 280;
  const padding = 20;
  const gridSize = miniMapSize - padding * 2;
  
  // Détection du niveau de zoom
  const getZoomLevelName = () => {
    if (zoom <= 0.4) return { name: 'Globale', color: 'bg-blue-500' };
    if (zoom <= 1.0) return { name: '10×10', color: 'bg-green-500' };
    if (zoom <= 2.0) return { name: 'Détail', color: 'bg-yellow-500' };
    if (zoom <= 4.0) return { name: 'Point', color: 'bg-orange-500' };
    return { name: 'Microscope', color: 'bg-red-500' };
  };
  
  const zoomLevel = getZoomLevelName();

  const centerCol = Math.floor(nbColonnes / 2);
  const centerRow = Math.floor(nbLignes / 2);

  // Analyse IA pour suggestions
  useEffect(() => {
    if (aiEnabled && pattern?.symbolGrid) {
      const timer = setTimeout(() => {
        analyzePatternForSuggestions();
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [aiEnabled, pattern, offsetX, offsetY]);

  const analyzePatternForSuggestions = () => {
    if (!pattern?.symbolGrid) return;

    // Détection zones oubliées, points isolés, etc.
    let isolated = 0;
    let forgotten = 0;
    
    pattern.symbolGrid.forEach((row, rowIdx) => {
      row.forEach((cell, colIdx) => {
        if (cell && !cell.done) {
          // Vérifier si isolé
          const neighbors = [
            pattern.symbolGrid[rowIdx - 1]?.[colIdx],
            pattern.symbolGrid[rowIdx + 1]?.[colIdx],
            pattern.symbolGrid[rowIdx]?.[colIdx - 1],
            pattern.symbolGrid[rowIdx]?.[colIdx + 1],
          ].filter(n => n && n.done);
          
          if (neighbors.length >= 3) {
            isolated++;
          }
          if (rowIdx < pattern.symbolGrid.length / 2) {
            forgotten++;
          }
        }
      });
    });

    if (isolated > 10) {
      setAiSuggestion({
        type: 'isolated',
        count: isolated,
        message: `J'ai trouvé ${isolated} points isolés non brodés. Je t'emmène ?`,
        zone: { col: centerCol, row: Math.floor(nbLignes * 0.3) }
      });
    } else if (forgotten > 50) {
      setAiSuggestion({
        type: 'forgotten',
        count: forgotten,
        message: 'Il reste une zone importante en haut non terminée.',
        zone: { col: centerCol, row: Math.floor(nbLignes * 0.2) }
      });
    }
  };

  // Dessin du canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    const dpr = window.devicePixelRatio || 1;

    canvas.width = miniMapSize * dpr;
    canvas.height = miniMapSize * dpr;
    canvas.style.width = `${miniMapSize}px`;
    canvas.style.height = `${miniMapSize}px`;

    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, miniMapSize, miniMapSize);

    const gridWidth = nbColonnes * tailleCase;
    const gridHeight = nbLignes * tailleCase;
    const scale = Math.min(gridSize / gridWidth, gridSize / gridHeight) * 0.95;

    const offsetMiniX = padding + (gridSize - gridWidth * scale) / 2;
    const offsetMiniY = padding + (gridSize - gridHeight * scale) / 2;

    // Fond
    ctx.fillStyle = displayMode === 'fog' ? '#1F2937' : '#F8FAFC';
    ctx.fillRect(offsetMiniX, offsetMiniY, gridWidth * scale, gridHeight * scale);

    // Mode d'affichage
    if (pattern?.symbolGrid) {
      const cellWidth = (gridWidth * scale) / pattern.symbolGrid[0]?.length;
      const cellHeight = (gridHeight * scale) / pattern.symbolGrid.length;
      
      pattern.symbolGrid.forEach((row, rowIndex) => {
        row.forEach((cell, colIndex) => {
          if (!cell) return;

          // Mode highlight couleur
          if (highlightMode === 'color' && selectedColorId) {
            if (cell.colorId === selectedColorId) {
              ctx.fillStyle = 'rgba(253, 224, 71, 0.8)';
            } else {
              ctx.fillStyle = 'rgba(0, 0, 0, 0.1)';
            }
            ctx.fillRect(
              offsetMiniX + colIndex * cellWidth,
              offsetMiniY + rowIndex * cellHeight,
              cellWidth,
              cellHeight
            );
          }
          // Mode progression
          else if (displayMode === 'standard' || displayMode === 'simplified') {
            if (cell.done) {
              ctx.fillStyle = 'rgba(34, 197, 94, 0.5)';
              ctx.fillRect(
                offsetMiniX + colIndex * cellWidth,
                offsetMiniY + rowIndex * cellHeight,
                cellWidth,
                cellHeight
              );
            }
          }
          // Mode fog (brouillard)
          else if (displayMode === 'fog') {
            if (cell.done) {
              ctx.fillStyle = 'rgba(34, 197, 94, 0.6)';
            } else {
              ctx.fillStyle = 'rgba(55, 65, 81, 0.9)';
            }
            ctx.fillRect(
              offsetMiniX + colIndex * cellWidth,
              offsetMiniY + rowIndex * cellHeight,
              cellWidth,
              cellHeight
            );
          }
        });
      });

      // Mode confetti (points isolés)
      if (highlightMode === 'confetti') {
        pattern.symbolGrid.forEach((row, rowIndex) => {
          row.forEach((cell, colIndex) => {
            if (cell && !cell.done) {
              const neighbors = [
                pattern.symbolGrid[rowIndex - 1]?.[colIndex],
                pattern.symbolGrid[rowIndex + 1]?.[colIndex],
                pattern.symbolGrid[rowIndex]?.[colIndex - 1],
                pattern.symbolGrid[rowIndex]?.[colIdx + 1],
              ].filter(n => n && !n.done);
              
              if (neighbors.length <= 1) {
                ctx.fillStyle = 'rgba(236, 72, 153, 0.7)';
                ctx.fillRect(
                  offsetMiniX + colIndex * cellWidth,
                  offsetMiniY + rowIndex * cellHeight,
                  cellWidth,
                  cellHeight
                );
              }
            }
          });
        });
      }

      // Mode zones denses
      if (highlightMode === 'dense') {
        pattern.symbolGrid.forEach((row, rowIndex) => {
          row.forEach((cell, colIndex) => {
            if (cell && cell.done) {
              const neighbors = [
                pattern.symbolGrid[rowIndex - 1]?.[colIndex],
                pattern.symbolGrid[rowIndex + 1]?.[colIndex],
                pattern.symbolGrid[rowIndex]?.[colIndex - 1],
                pattern.symbolGrid[rowIndex]?.[colIndex + 1],
              ].filter(n => n && n.done);
              
              if (neighbors.length >= 3) {
                ctx.fillStyle = 'rgba(139, 92, 246, 0.6)';
                ctx.fillRect(
                  offsetMiniX + colIndex * cellWidth,
                  offsetMiniY + rowIndex * cellHeight,
                  cellWidth,
                  cellHeight
                );
              }
            }
          });
        });
      }
    }

    // Grille 10x10
    if (displayMode !== 'fog') {
      ctx.strokeStyle = '#E2E8F0';
      ctx.lineWidth = 0.3;
      
      for (let col = 0; col <= nbColonnes; col += 10) {
        ctx.beginPath();
        ctx.moveTo(offsetMiniX + col * tailleCase * scale, offsetMiniY);
        ctx.lineTo(offsetMiniX + col * tailleCase * scale, offsetMiniY + gridHeight * scale);
        ctx.stroke();
      }
      
      for (let row = 0; row <= nbLignes; row += 10) {
        ctx.beginPath();
        ctx.moveTo(offsetMiniX, offsetMiniY + row * tailleCase * scale);
        ctx.lineTo(offsetMiniX + gridWidth * scale, offsetMiniY + row * tailleCase * scale);
        ctx.stroke();
      }
    }

    // Mosaïque
    if (showMosaicGuides && mosaicConfig) {
      ctx.strokeStyle = 'rgba(239, 68, 68, 0.6)';
      ctx.lineWidth = 2;
      
      const pageWidth = mosaicConfig.pageWidth;
      const pageHeight = mosaicConfig.pageHeight;
      
      for (let col = pageWidth; col < nbColonnes; col += pageWidth) {
        ctx.beginPath();
        ctx.moveTo(offsetMiniX + col * tailleCase * scale, offsetMiniY);
        ctx.lineTo(offsetMiniX + col * tailleCase * scale, offsetMiniY + gridHeight * scale);
        ctx.stroke();
      }
      
      for (let row = pageHeight; row < nbLignes; row += pageHeight) {
        ctx.beginPath();
        ctx.moveTo(offsetMiniX, offsetMiniY + row * tailleCase * scale);
        ctx.lineTo(offsetMiniX + gridWidth * scale, offsetMiniY + row * tailleCase * scale);
        ctx.stroke();
      }
    }

    // Centre
    if (showCenterMarker) {
      const centerX = offsetMiniX + centerCol * tailleCase * scale;
      const centerY = offsetMiniY + centerRow * tailleCase * scale;
      
      ctx.strokeStyle = '#EF4444';
      ctx.fillStyle = '#EF4444';
      ctx.lineWidth = 1.5;
      
      ctx.beginPath();
      ctx.arc(centerX, centerY, 3, 0, Math.PI * 2);
      ctx.fill();
      
      ctx.beginPath();
      ctx.moveTo(centerX - 6, centerY);
      ctx.lineTo(centerX + 6, centerY);
      ctx.moveTo(centerX, centerY - 6);
      ctx.lineTo(centerX, centerY + 6);
      ctx.stroke();
    }

    // Zone visible (curseur bleu)
    if (canvasWidth && canvasHeight) {
      const viewportWidth = canvasWidth / zoom;
      const viewportHeight = canvasHeight / zoom;
      
      const viewportX = -offsetX / zoom;
      const viewportY = -offsetY / zoom;
      
      const miniViewX = offsetMiniX + viewportX * scale;
      const miniViewY = offsetMiniY + viewportY * scale;
      const miniViewWidth = viewportWidth * scale;
      const miniViewHeight = viewportHeight * scale;
      
      ctx.shadowColor = 'rgba(59, 130, 246, 0.4)';
      ctx.shadowBlur = 10;
      
      ctx.strokeStyle = '#3B82F6';
      ctx.lineWidth = 2.5;
      ctx.fillStyle = 'rgba(59, 130, 246, 0.15)';
      ctx.fillRect(miniViewX, miniViewY, miniViewWidth, miniViewHeight);
      ctx.strokeRect(miniViewX, miniViewY, miniViewWidth, miniViewHeight);
      
      ctx.shadowColor = 'transparent';
      ctx.shadowBlur = 0;
    }

    // Suggestion IA
    if (aiSuggestion && activeTab === 'ia-focus') {
      const suggestionX = offsetMiniX + aiSuggestion.zone.col * tailleCase * scale;
      const suggestionY = offsetMiniY + aiSuggestion.zone.row * tailleCase * scale;
      
      ctx.strokeStyle = '#F59E0B';
      ctx.fillStyle = 'rgba(245, 158, 11, 0.3)';
      ctx.lineWidth = 2;
      
      ctx.beginPath();
      ctx.arc(suggestionX, suggestionY, 15, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
    }

    // Bordure
    ctx.strokeStyle = '#CBD5E1';
    ctx.lineWidth = 1;
    ctx.strokeRect(offsetMiniX, offsetMiniY, gridWidth * scale, gridHeight * scale);

  }, [nbColonnes, nbLignes, tailleCase, zoom, offsetX, offsetY, canvasWidth, canvasHeight, 
      pattern, selectedColorId, highlightMode, displayMode, showCenterMarker, showMosaicGuides, 
      mosaicConfig, aiSuggestion, activeTab]);

  const handleMouseDown = (e) => {
    setIsDragging(true);
    handleNavigate(e);
  };

  const handleMouseMove = (e) => {
    if (isDragging) {
      handleNavigate(e);
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleMouseLeave = () => {
    setIsDragging(false);
  };

  const handleNavigate = (e) => {
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX - rect.left) * (miniMapSize / rect.width);
    const y = (e.clientY - rect.top) * (miniMapSize / rect.height);

    const gridWidth = nbColonnes * tailleCase;
    const gridHeight = nbLignes * tailleCase;
    const scale = Math.min(gridSize / gridWidth, gridSize / gridHeight) * 0.95;

    const offsetMiniX = padding + (gridSize - gridWidth * scale) / 2;
    const offsetMiniY = padding + (gridSize - gridHeight * scale) / 2;

    const gridX = (x - offsetMiniX) / scale;
    const gridY = (y - offsetMiniY) / scale;

    onNavigate(gridX, gridY);
  };

  const handleGoToSuggestion = () => {
    if (aiSuggestion) {
      const gridX = aiSuggestion.zone.col * tailleCase;
      const gridY = aiSuggestion.zone.row * tailleCase;
      onNavigate(gridX, gridY);
      toast.success('Navigation vers la zone suggérée');
      setAiSuggestion(null);
    }
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-lg overflow-hidden" style={{ width: 280 }}>
      {/* En-tête */}
      <div className="px-4 py-3 border-b border-slate-200 bg-gradient-to-r from-slate-50 to-white">
        <div className="flex items-center gap-2">
          <MapPin className="w-4 h-4 text-indigo-600" />
          <h3 className="font-bold text-sm text-slate-900">Mini-carte 4D™</h3>
          <div className="flex items-center gap-1 ml-auto">
            <Badge variant="secondary" className="text-xs">
              Zoom: {zoomLevel.name}
            </Badge>
            <div className={cn("w-2 h-2 rounded-full", zoomLevel.color)} />
          </div>
        </div>
      </div>

      {/* Onglets */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="w-full grid grid-cols-3 p-1 bg-slate-50">
          <TabsTrigger value="navigation" className="text-xs">
            <Navigation2 className="w-3 h-3 mr-1" />
            Navigation
          </TabsTrigger>
          <TabsTrigger value="colors" className="text-xs">
            <Palette className="w-3 h-3 mr-1" />
            Couleurs
          </TabsTrigger>
          <TabsTrigger value="ia-focus" className="text-xs">
            <Sparkles className="w-3 h-3 mr-1" />
            IA-Focus
          </TabsTrigger>
        </TabsList>

        {/* Contenu - Navigation */}
        <TabsContent value="navigation" className="p-3 space-y-3 m-0">
          <div className="rounded-lg overflow-hidden border border-slate-200 shadow-sm">
            <canvas
              ref={canvasRef}
              className="cursor-pointer w-full h-full bg-slate-50"
              onMouseDown={handleMouseDown}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              onMouseLeave={handleMouseLeave}
            />
          </div>

          {/* Contrôles zoom */}
          <div className="flex items-center gap-2">
            <Button
              size="sm"
              variant="outline"
              onClick={onZoomIn}
              className="flex-1 h-8 text-xs"
            >
              <ZoomIn className="w-3 h-3 mr-1" />
              +
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={onZoomOut}
              className="flex-1 h-8 text-xs"
            >
              <ZoomOut className="w-3 h-3 mr-1" />
              –
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={onResetZoom}
              className="flex-1 h-8 text-xs"
            >
              <Maximize2 className="w-3 h-3 mr-1" />
              ⤧
            </Button>
          </div>

          {/* Synchronisation auto */}
          <div className="flex items-center justify-between p-2 bg-slate-50 rounded-lg">
            <div className="flex items-center gap-2">
              <RefreshCw className={cn("w-3 h-3 text-slate-600", autoSync && "animate-spin")} />
              <span className="text-xs font-medium text-slate-700">Sync auto</span>
            </div>
            <Switch
              checked={autoSync}
              onCheckedChange={setAutoSync}
              className="scale-75"
            />
          </div>
        </TabsContent>

        {/* Contenu - Couleurs & Symboles */}
        <TabsContent value="colors" className="p-3 space-y-3 m-0">
          <div className="rounded-lg overflow-hidden border border-slate-200 shadow-sm">
            <canvas
              ref={canvasRef}
              className="cursor-pointer w-full h-full bg-slate-50"
              onMouseDown={handleMouseDown}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              onMouseLeave={handleMouseLeave}
            />
          </div>

          {/* Modes de highlight */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-700">Mode d'affichage</label>
            <div className="grid grid-cols-2 gap-2">
              <Button
                size="sm"
                variant={highlightMode === 'color' ? 'default' : 'outline'}
                onClick={() => setHighlightMode(highlightMode === 'color' ? 'none' : 'color')}
                className="h-8 text-xs justify-start"
              >
                <Target className="w-3 h-3 mr-1" />
                Couleur active
              </Button>
              <Button
                size="sm"
                variant={highlightMode === 'confetti' ? 'default' : 'outline'}
                onClick={() => setHighlightMode(highlightMode === 'confetti' ? 'none' : 'confetti')}
                className="h-8 text-xs justify-start"
              >
                <Grid3x3 className="w-3 h-3 mr-1" />
                Confettis
              </Button>
              <Button
                size="sm"
                variant={highlightMode === 'dense' ? 'default' : 'outline'}
                onClick={() => setHighlightMode(highlightMode === 'dense' ? 'none' : 'dense')}
                className="h-8 text-xs justify-start col-span-2"
              >
                <Eye className="w-3 h-3 mr-1" />
                Zones denses
              </Button>
            </div>
          </div>

          {/* Actions rapides */}
          <div className="p-2 bg-indigo-50 rounded-lg border border-indigo-200">
            <p className="text-xs text-indigo-700 mb-2 font-medium">Zoom rapide</p>
            <div className="space-y-1">
              <button
                onClick={onZoomToColor}
                className="w-full text-left text-xs py-1.5 px-2 hover:bg-white rounded transition-colors text-slate-700"
              >
                🎯 Zoom sur couleur active
              </button>
              <button
                onClick={onZoomToDenseZone}
                className="w-full text-left text-xs py-1.5 px-2 hover:bg-white rounded transition-colors text-slate-700"
              >
                🔍 Zoom zone dense
              </button>
              <button
                onClick={onZoomToIsolated}
                className="w-full text-left text-xs py-1.5 px-2 hover:bg-white rounded transition-colors text-slate-700"
              >
                ✨ Zoom points isolés
              </button>
              <button
                onClick={() => setHighlightMode('none')}
                className="w-full text-left text-xs py-1.5 px-2 hover:bg-white rounded transition-colors text-slate-700"
              >
                🌈 Retour normal
              </button>
            </div>
          </div>
        </TabsContent>

        {/* Contenu - IA-Focus */}
        <TabsContent value="ia-focus" className="p-3 space-y-3 m-0">
          <div className="rounded-lg overflow-hidden border border-slate-200 shadow-sm">
            <canvas
              ref={canvasRef}
              className="cursor-pointer w-full h-full bg-slate-50"
              onMouseDown={handleMouseDown}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              onMouseLeave={handleMouseLeave}
            />
          </div>

          {/* Activation IA */}
          <div className="flex items-center justify-between p-3 bg-gradient-to-r from-indigo-50 to-purple-50 rounded-lg border border-indigo-200">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-600" />
              <span className="text-xs font-semibold text-slate-900">IA activée</span>
            </div>
            <Switch
              checked={aiEnabled}
              onCheckedChange={setAiEnabled}
              className="scale-75"
            />
          </div>

          {/* Suggestions IA */}
          {aiEnabled && aiSuggestion ? (
            <div className="p-3 bg-amber-50 rounded-lg border border-amber-200">
              <div className="flex items-start gap-2 mb-2">
                <Lightbulb className="w-4 h-4 text-amber-600 mt-0.5" />
                <p className="text-xs text-amber-900 font-medium flex-1">
                  {aiSuggestion.message}
                </p>
              </div>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  onClick={handleGoToSuggestion}
                  className="flex-1 h-7 text-xs bg-amber-600 hover:bg-amber-700"
                >
                  👍 Oui, emmène-moi
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setAiSuggestion(null)}
                  className="flex-1 h-7 text-xs"
                >
                  👎 Non merci
                </Button>
              </div>
            </div>
          ) : aiEnabled ? (
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
              <p className="text-xs text-slate-600 text-center">
                L'IA analyse ta broderie...
              </p>
            </div>
          ) : (
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
              <p className="text-xs text-slate-600 text-center">
                Active l'IA pour recevoir des suggestions intelligentes
              </p>
            </div>
          )}

          {/* Statistiques IA */}
          {aiEnabled && (
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-600">Zones oubliées</span>
                <Badge variant="outline" className="text-xs">2</Badge>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-600">Points isolés</span>
                <Badge variant="outline" className="text-xs">18</Badge>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-600">Zones lentes</span>
                <Badge variant="outline" className="text-xs">1</Badge>
              </div>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}