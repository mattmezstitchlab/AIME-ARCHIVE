import React, { useState, useEffect } from 'react';
import { ArrowLeft, ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

// Logo PatyBee
function PatyBeeLogo() {
  return (
    <svg width="52" height="52" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
      <style>
        {`
          @keyframes star-anim {
            0%, 100% { fill: #FFFFFF; transform: rotate(0deg); }
            5% { fill: #F5C200; }
            20% { fill: #F5C200; transform: rotate(360deg); }
            22%, 100% { fill: #FFFFFF; transform: rotate(360deg); }
          }
          
          @keyframes diamond-anim {
            0%, 22%, 100% { fill: #FFFFFF; transform: rotate(0deg); }
            27% { fill: #2F80ED; }
            42% { fill: #2F80ED; transform: rotate(15deg); }
            44%, 100% { fill: #FFFFFF; transform: rotate(0deg); }
          }
          
          @keyframes circle-anim {
            0%, 44%, 100% { fill: #FFFFFF; opacity: 1; }
            49% { fill: #27AE60; opacity: 1; }
            55% { fill: #27AE60; opacity: 0.4; }
            61% { fill: #27AE60; opacity: 1; }
            64%, 100% { fill: #FFFFFF; opacity: 1; }
          }
          
          @keyframes square-anim {
            0%, 64%, 100% { fill: #FFFFFF; transform: rotate(0deg); }
            69% { fill: #EB5BA9; }
            79% { fill: #EB5BA9; transform: rotate(90deg); }
            84% { fill: #EB5BA9; transform: rotate(0deg); }
            86%, 100% { fill: #FFFFFF; transform: rotate(0deg); }
          }
          
          .star { 
            animation: star-anim 3.7s ease-in-out infinite;
            transform-origin: 9px 8.5px;
          }
          .circle { 
            animation: circle-anim 3.7s ease-in-out infinite;
          }
          .square { 
            animation: square-anim 3.7s ease-in-out infinite;
            transform-origin: 7.5px 26px;
          }
          .diamond { 
            animation: diamond-anim 3.7s ease-in-out infinite;
            transform-origin: 26.5px 26px;
          }
        `}
      </style>
      
      <path className="star" d="M9 2L10.5 7L15.5 8.5L10.5 10L9 15L7.5 10L2.5 8.5L7.5 7L9 2Z" fill="#FFFFFF"/>
      <circle className="circle" cx="26.5" cy="9" r="5" fill="#FFFFFF"/>
      <rect className="square" x="2.5" y="21" width="10" height="10" fill="#FFFFFF"/>
      <path className="diamond" d="M26.5 21L31.5 26L26.5 31L21.5 26L26.5 21Z" fill="#FFFFFF"/>
    </svg>
  );
}

const SLIDES = [
  {
    title: "OFFRE DÉCOUVERTE",
    items: [
      "3 jours complets gratuits",
      "Accès à l'éditeur professionnel",
      "Conversion DMC instantanée",
      "IA PatyBee active",
      "Export PDF haute définition",
      "Aucune carte bancaire nécessaire"
    ]
  },
  {
    title: "FORFAIT ESSENTIEL",
    price: "2,99 €/mois",
    items: [
      "Illimité : création de grilles",
      "Palette DMC complète",
      "IA couleur (simplification / fusion intelligente)",
      "Import images JPG/PNG",
      "Export PDF simple",
      "Assistance IA"
    ]
  },
  {
    title: "FORFAIT ADVANCED",
    price: "6,99 €/mois",
    items: [
      "Tout l'Essentiel",
      "Import PDF multi-pages",
      "Détection auto des doublons DMC",
      "IA Correction Zone Vides",
      "Mini-carte dynamique + zoom intelligent",
      "Préparateur de motifs (ombres, dégradés)"
    ]
  },
  {
    title: "FORFAIT PRO",
    price: "9,99 €/mois",
    items: [
      "Tout l'Advanced",
      "Export PBX (brevet PatyBee)",
      "Mise en vente de ses créations",
      "Optimisation intelligente des couleurs complexes",
      "Gestion avancée des symboles",
      "5 Go stockage cloud"
    ]
  },
  {
    title: "FORFAIT ULTIMATE",
    price: "14,99 €/mois",
    items: [
      "Tout le PRO",
      "IA Vision 6D complète",
      "Analyse émotionnelle + suggestions personnalisées",
      "Priorité support 24h",
      "Accès anticipé aux futures innovations",
      "Stockage illimité"
    ]
  },
  {
    title: "CREATORS PASS",
    price: "GRATUIT À VIE",
    items: [
      "Pour les créateurs qui vendent sur la boutique",
      "Accès complet PRO sans frais",
      "Conditions : vendre au moins 1 grille / an",
      "0 € tant que condition remplie",
      "Visibilité mondiale"
    ]
  },
  {
    title: "COMMISSION PATYBEE",
    price: "22%",
    items: [
      "PatyBee retient 22 % sur chaque vente",
      "Couverture des coûts de diffusion mondiale",
      "Sécurisation des droits d'auteur",
      "Paiement direct sur votre portefeuille interne",
      "Utilisable pour acheter d'autres grilles"
    ]
  }
];

export default function SubscriptionCarousel({ isOpen, onBack, onSubscribe }) {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  // Auto-rotation toutes les 5 secondes
  useEffect(() => {
    if (!isOpen || isPaused) return;

    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % SLIDES.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [isOpen, isPaused]);

  if (!isOpen) return null;

  const currentSlideData = SLIDES[currentSlide];

  const goToNext = () => {
    setCurrentSlide((prev) => (prev + 1) % SLIDES.length);
  };

  const goToPrev = () => {
    setCurrentSlide((prev) => (prev - 1 + SLIDES.length) % SLIDES.length);
  };

  const goToSlide = (index) => {
    setCurrentSlide(index);
  };

  return (
    <div 
      className="fixed inset-0 z-[101] flex flex-col items-center justify-center"
      style={{ backgroundColor: 'rgba(0, 0, 0, 0.95)' }}
    >
      {/* Bouton RETOUR en haut à gauche */}
      <button
        onClick={onBack}
        className="absolute top-8 left-8 flex items-center gap-2 text-white hover:text-white/80 transition-colors"
      >
        <ArrowLeft className="w-5 h-5" />
        <span className="text-lg font-medium">RETOUR</span>
      </button>

      {/* Logo PatyBee TOP CENTER */}
      <div className="absolute top-12 left-1/2 -translate-x-1/2 flex flex-col items-center gap-3">
        <PatyBeeLogo />
        <div className="flex text-4xl font-semibold tracking-wide text-white">
          <span>Paty</span>
          <span>Bee</span>
        </div>
      </div>

      {/* Contenu du carrousel */}
      <div 
        className="relative w-full max-w-3xl mx-4"
        onMouseEnter={() => setIsPaused(true)}
        onMouseLeave={() => setIsPaused(false)}
      >
        {/* Contenu du slide */}
        <div className="p-12 min-h-[500px] flex flex-col items-center justify-center text-center">
          {/* Titre avec animation */}
          <h2 className="text-5xl font-bold text-white mb-4 tracking-tight animate-in fade-in slide-in-from-bottom-4 duration-500">
            {currentSlideData.title}
          </h2>

          {/* Prix si présent */}
          {currentSlideData.price && (
            <div className="text-3xl font-bold text-[#FFD200] mb-8 animate-in fade-in duration-700 delay-100">
              {currentSlideData.price}
            </div>
          )}

          {/* Liste des items */}
          <div className="space-y-3 text-left max-w-xl animate-in fade-in slide-in-from-bottom-2 duration-700 delay-200">
            {currentSlideData.items.map((item, index) => (
              <div key={index} className="flex items-start gap-3">
                <div className="w-2 h-2 bg-[#FFD200] rounded-full mt-2 flex-shrink-0" />
                <span className="text-lg text-white/80 leading-relaxed">{item}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Navigation flèches */}
        <div className="absolute top-1/2 -translate-y-1/2 left-0 right-0 flex items-center justify-between px-4 pointer-events-none">
          <button
            onClick={goToPrev}
            className="pointer-events-auto w-12 h-12 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors"
          >
            <ChevronLeft className="w-6 h-6 text-white" />
          </button>
          <button
            onClick={goToNext}
            className="pointer-events-auto w-12 h-12 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors"
          >
            <ChevronRight className="w-6 h-6 text-white" />
          </button>
        </div>

        {/* Indicateurs de slide */}
        <div className="flex justify-center gap-2 mt-8">
          {SLIDES.map((_, index) => (
            <button
              key={index}
              onClick={() => goToSlide(index)}
              className={`w-2 h-2 rounded-full transition-all ${
                index === currentSlide 
                  ? 'bg-[#FFD200] w-8' 
                  : 'bg-white/30 hover:bg-white/50'
              }`}
            />
          ))}
        </div>
      </div>

      {/* Bouton S'ABONNER MAINTENANT en bas */}
      <div className="absolute bottom-12 left-1/2 -translate-x-1/2">
        <Button
          onClick={onSubscribe}
          className="bg-[#FFD200] hover:bg-[#E5BD00] text-black font-bold px-12 py-7 text-xl rounded-lg shadow-2xl"
        >
          S'ABONNER MAINTENANT
        </Button>
      </div>
    </div>
  );
}