import React, { useState, useMemo } from 'react';
import { X, Search, Sparkles, ArrowRight, Palette, Target } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { DMC_LIBRARY } from './dmcLibrary';

export default function FullDmcPaletteDialog({
  open,
  onClose,
  currentPalette = [],
  selectedColorInPalette,
  onAddColor,
  onReplaceColor
}) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDmcColor, setSelectedDmcColor] = useState(null);
  const [activeFilters, setActiveFilters] = useState(['all']);

  // Filtres disponibles
  const filters = [
    { id: 'all', label: 'Tous' },
    { id: 'standard', label: 'Coton standard' },
    { id: 'metallic', label: 'Étoiles métalliques' },
    { id: 'special', label: 'Perles / Échevettes spéciales' },
    { id: 'pastel', label: 'Pastels' },
    { id: 'skin', label: 'Peaux' },
    { id: 'neutral', label: 'Neutres' },
    { id: 'variegated', label: 'Ombrés / Variations' },
    { id: 'popular', label: 'Les plus utilisés' },
    { id: 'rare', label: 'Les plus rares' },
    { id: 'ai', label: 'Couleurs IA recommandées' }
  ];

  const toggleFilter = (filterId) => {
    if (filterId === 'all') {
      setActiveFilters(['all']);
    } else {
      const newFilters = activeFilters.includes(filterId)
        ? activeFilters.filter(f => f !== filterId)
        : [...activeFilters.filter(f => f !== 'all'), filterId];
      
      setActiveFilters(newFilters.length === 0 ? ['all'] : newFilters);
    }
  };

  // Fonction helper pour convertir hex en RGB
  const hexToRgb = (hex) => {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
      r: parseInt(result[1], 16),
      g: parseInt(result[2], 16),
      b: parseInt(result[3], 16)
    } : { r: 0, g: 0, b: 0 };
  };

  // Calculer la luminosité pour choisir le contraste texte
  const getTextColor = (hex) => {
    const rgb = hexToRgb(hex);
    const luminance = (0.299 * rgb.r + 0.587 * rgb.g + 0.114 * rgb.b) / 255;
    return luminance > 0.5 ? '#000000' : '#FFFFFF';
  };

  // Fonction de recherche intelligente avec filtres
  const filteredColors = useMemo(() => {
    let colors = [...DMC_LIBRARY];

    // Appliquer les filtres
    if (!activeFilters.includes('all')) {
      if (activeFilters.includes('pastel')) {
        colors = colors.filter(c => {
          const rgb = hexToRgb(c.hex);
          const lightness = (Math.max(rgb.r, rgb.g, rgb.b) + Math.min(rgb.r, rgb.g, rgb.b)) / 2;
          return lightness > 200;
        });
      }
      if (activeFilters.includes('skin')) {
        colors = colors.filter(c =>
          c.name.toLowerCase().includes('skin') ||
          c.name.toLowerCase().includes('flesh') ||
          c.name.toLowerCase().includes('peach') ||
          ['950', '3774', '407', '842', '435'].includes(c.code)
        );
      }
      if (activeFilters.includes('neutral')) {
        colors = colors.filter(c => {
          const rgb = hexToRgb(c.hex);
          const variance = Math.abs(rgb.r - rgb.g) + Math.abs(rgb.g - rgb.b) + Math.abs(rgb.b - rgb.r);
          return variance < 30;
        });
      }
      if (activeFilters.includes('popular')) {
        const popularCodes = ['310', 'blanc', 'ecru', '321', '666', '796', '972', '3865'];
        colors = colors.filter(c => popularCodes.includes(c.code.toLowerCase()));
      }
    }

    // Recherche intelligente
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      colors = colors.filter(color => {
        const codeMatch = color.code.toLowerCase().includes(query);
        const nameMatch = color.name.toLowerCase().includes(query);

        // Recherche par teinte
        const teintes = {
          'bleu': ['blue', 'navy', 'azure', 'cobalt'],
          'rouge': ['red', 'crimson', 'scarlet', 'ruby'],
          'vert': ['green', 'emerald', 'lime', 'olive'],
          'jaune': ['yellow', 'gold', 'lemon'],
          'rose': ['pink', 'rose', 'magenta'],
          'violet': ['purple', 'violet', 'lavender'],
          'orange': ['orange', 'coral', 'peach'],
          'marron': ['brown', 'tan', 'mocha'],
          'gris': ['gray', 'grey', 'silver'],
          'noir': ['black', 'charcoal'],
          'blanc': ['white', 'cream', 'ivory'],
          'chair': ['skin', 'flesh', 'peach']
        };

        let teinteMatch = false;
        for (const [key, values] of Object.entries(teintes)) {
          if (query.includes(key)) {
            teinteMatch = values.some(v => color.name.toLowerCase().includes(v));
          }
        }

        // Recherche par usage
        const usages = {
          'ciel': ['blue', 'sky', 'azure'],
          'ocean': ['blue', 'navy', 'turquoise'],
          'foret': ['green', 'olive'],
          'peau': ['skin', 'flesh', 'peach'],
          'ombre': ['black', 'gray', 'charcoal'],
          'contour': ['black', 'navy', 'charcoal']
        };

        let usageMatch = false;
        for (const [key, values] of Object.entries(usages)) {
          if (query.includes(key)) {
            usageMatch = values.some(v => color.name.toLowerCase().includes(v));
          }
        }

        return codeMatch || nameMatch || teinteMatch || usageMatch;
      });
    }

    return colors;
  }, [searchQuery, activeFilters]);

  // Trouver des nuances proches
  const findSimilarShades = (color) => {
    if (!color) return { lighter: [], darker: [], similar: [] };

    const allColors = DMC_LIBRARY.filter(c => c.code !== color.code);

    // Calculer la distance de couleur
    const colorDistance = (c1, c2) => {
      const r1 = hexToRgb(c1.hex);
      const r2 = hexToRgb(c2.hex);
      return Math.sqrt(
        Math.pow(r1.r - r2.r, 2) +
        Math.pow(r1.g - r2.g, 2) +
        Math.pow(r1.b - r2.b, 2)
      );
    };

    const sorted = allColors
      .map(c => ({ color: c, distance: colorDistance(color, c) }))
      .sort((a, b) => a.distance - b.distance);

    return {
      lighter: sorted.slice(0, 3).map(s => s.color),
      darker: sorted.slice(3, 6).map(s => s.color),
      similar: sorted.slice(6, 9).map(s => s.color)
    };
  };

  const handleUseColor = () => {
    if (!selectedDmcColor) return;

    onAddColor?.({
      code: `DMC-${selectedDmcColor.code}`,
      name: selectedDmcColor.name,
      hex: selectedDmcColor.hex,
      family: selectedDmcColor.family
    });
    
    toast.success(`DMC ${selectedDmcColor.code} ajouté à la palette`);
    setSelectedDmcColor(null);
  };

  const handleReplaceColor = () => {
    if (!selectedDmcColor || !selectedColorInPalette) return;

    onReplaceColor?.(selectedColorInPalette.id, {
      code: `DMC-${selectedDmcColor.code}`,
      name: selectedDmcColor.name,
      hex: selectedDmcColor.hex,
      family: selectedDmcColor.family
    });
    
    toast.success(`Couleur remplacée par DMC ${selectedDmcColor.code}`);
    setSelectedDmcColor(null);
    onClose();
  };

  const similarShades = findSimilarShades(selectedDmcColor);

  if (!open) return null;

  return (
    <div 
      className="fixed inset-0 flex items-center justify-center"
      style={{ zIndex: 999999, backgroundColor: 'rgba(0, 0, 0, 0.85)' }}
      onClick={onClose}
    >
      <div
        className="bg-[#111] rounded-2xl shadow-2xl flex overflow-hidden border border-[#444]"
        style={{ width: '80vw', height: '75vh' }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Panel principal */}
        <div className="flex-1 flex flex-col">
          {/* Header */}
          <div className="p-6 flex items-center justify-between border-b border-[#333]">
            <h2 className="text-3xl font-bold" style={{ color: '#FFD441' }}>
              PALETTE COMPLÈTE DMC
            </h2>
            <button
              onClick={onClose}
              className="w-10 h-10 rounded-lg hover:bg-white/10 flex items-center justify-center transition-colors"
            >
              <X className="w-6 h-6 text-white" />
            </button>
          </div>

          {/* Barre de recherche */}
          <div className="p-6 border-b border-[#333]">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <Input
                type="text"
                placeholder="Rechercher une couleur DMC… (numéro, nom, teinte, usage…)"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-12 bg-[#222] border-[#444] text-white placeholder:text-slate-500 h-12 text-base"
              />
              <Sparkles className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-yellow-400" />
            </div>
          </div>

          {/* Filtres */}
          <div className="px-6 py-4 border-b border-[#333]">
            <div className="flex flex-wrap gap-2">
              {filters.map(filter => (
                <button
                  key={filter.id}
                  onClick={() => toggleFilter(filter.id)}
                  className={`px-4 py-2 rounded-lg text-sm font-semibold transition-colors ${
                    activeFilters.includes(filter.id)
                      ? 'bg-black text-white'
                      : 'bg-[#222] text-slate-400 hover:bg-[#333]'
                  }`}
                >
                  {filter.label}
                </button>
              ))}
            </div>
          </div>

          {/* Grille de couleurs */}
          <div className="flex-1 overflow-y-auto p-6">
            <div className="grid grid-cols-10 gap-3">
              {filteredColors.map((color) => (
                <button
                  key={color.code}
                  onClick={() => setSelectedDmcColor(color)}
                  className="group relative"
                  title={`${color.code} - ${color.name}`}
                >
                  <div
                    className="w-full aspect-square rounded-lg border-2 transition-all group-hover:border-white group-hover:scale-110 group-hover:shadow-lg"
                    style={{
                      backgroundColor: color.hex,
                      borderColor: selectedDmcColor?.code === color.code ? '#FFD441' : '#444'
                    }}
                  />
                  <div
                    className="absolute bottom-1 left-1 right-1 text-center text-[10px] font-bold px-1 py-0.5 rounded"
                    style={{
                      color: getTextColor(color.hex),
                      backgroundColor: `${color.hex}dd`
                    }}
                  >
                    {color.code}
                  </div>

                  {/* Tooltip au survol */}
                  <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-10">
                    <div className="bg-black text-white text-xs px-3 py-2 rounded-lg whitespace-nowrap shadow-xl">
                      <div className="font-semibold">{color.code} — {color.name}</div>
                    </div>
                  </div>
                </button>
              ))}
            </div>

            {filteredColors.length === 0 && (
              <div className="text-center py-12 text-slate-500">
                Aucune couleur trouvée
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="p-4 border-t border-[#333] flex items-center justify-between">
            <span className="text-sm text-slate-400">
              {filteredColors.length} couleurs affichées — filtrées selon vos préférences
            </span>
            <Button
              onClick={onClose}
              className="bg-black hover:bg-[#222] text-white"
            >
              Fermer
            </Button>
          </div>
        </div>

        {/* Panneau latéral de détails */}
        {selectedDmcColor && (
          <div className="w-96 border-l border-[#333] bg-[#0a0a0a] flex flex-col">
            <div className="p-6 flex-1 overflow-y-auto">
              {/* Grand carré de couleur */}
              <div
                className="w-full h-48 rounded-xl mb-6 border-2 border-[#444]"
                style={{ backgroundColor: selectedDmcColor.hex }}
              />

              {/* Info couleur */}
              <div className="space-y-4 mb-6">
                <div>
                  <div className="text-2xl font-bold text-white mb-1">
                    DMC {selectedDmcColor.code}
                  </div>
                  <div className="text-lg text-slate-300">
                    {selectedDmcColor.name}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div className="bg-[#1a1a1a] p-3 rounded-lg">
                    <div className="text-slate-500 mb-1">RGB</div>
                    <div className="text-white font-mono">
                      {(() => {
                        const rgb = hexToRgb(selectedDmcColor.hex);
                        return `${rgb.r}, ${rgb.g}, ${rgb.b}`;
                      })()}
                    </div>
                  </div>
                  <div className="bg-[#1a1a1a] p-3 rounded-lg">
                    <div className="text-slate-500 mb-1">Hex</div>
                    <div className="text-white font-mono">{selectedDmcColor.hex}</div>
                  </div>
                </div>

                {/* Conseils IA */}
                <div className="bg-gradient-to-br from-yellow-500/10 to-orange-500/10 border border-yellow-500/20 rounded-lg p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Sparkles className="w-4 h-4 text-yellow-400" />
                    <span className="text-sm font-semibold text-yellow-400">Conseils IA</span>
                  </div>
                  <p className="text-sm text-slate-300">
                    Idéal pour : contours, dégradés, reflets.
                  </p>
                </div>
              </div>

              {/* Nuances proches */}
              <div className="mb-6">
                <div className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
                  <Target className="w-4 h-4" />
                  Nuances proches
                </div>
                <div className="space-y-2">
                  <div>
                    <div className="text-xs text-slate-500 mb-1">Plus claires</div>
                    <div className="flex gap-2">
                      {similarShades.lighter.map(shade => (
                        <button
                          key={shade.code}
                          onClick={() => setSelectedDmcColor(shade)}
                          className="w-12 h-12 rounded-lg border border-[#444] hover:border-white transition-colors"
                          style={{ backgroundColor: shade.hex }}
                          title={shade.code}
                        />
                      ))}
                    </div>
                  </div>
                  <div>
                    <div className="text-xs text-slate-500 mb-1">Plus foncées</div>
                    <div className="flex gap-2">
                      {similarShades.darker.map(shade => (
                        <button
                          key={shade.code}
                          onClick={() => setSelectedDmcColor(shade)}
                          className="w-12 h-12 rounded-lg border border-[#444] hover:border-white transition-colors"
                          style={{ backgroundColor: shade.hex }}
                          title={shade.code}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Boutons d'action */}
            <div className="p-6 border-t border-[#333] space-y-3">
              <Button
                onClick={handleUseColor}
                className="w-full h-12 text-base font-semibold bg-gradient-to-r from-yellow-400 to-yellow-500 hover:from-yellow-500 hover:to-yellow-600 text-black"
              >
                <Palette className="w-5 h-5 mr-2" />
                Utiliser dans ma grille
              </Button>

              {selectedColorInPalette && (
                <Button
                  onClick={handleReplaceColor}
                  className="w-full h-12 text-base font-semibold bg-black hover:bg-[#222] text-white border border-[#444]"
                >
                  <ArrowRight className="w-5 h-5 mr-2" />
                  Remplacer la couleur actuelle
                </Button>
              )}

              <button
                onClick={() => setSelectedDmcColor(null)}
                className="w-full h-10 text-sm text-slate-400 hover:text-white transition-colors"
              >
                Voir les nuances proches
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}