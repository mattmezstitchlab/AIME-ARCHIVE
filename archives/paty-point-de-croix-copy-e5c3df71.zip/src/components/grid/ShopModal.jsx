import React, { useState } from 'react';
import { X, ShoppingBag, Grid3X3, Scissors, Heart, Star, Palette, Upload, ChevronRight, Sparkles, Flower2, Cat, Home, TreePine, Baby, ArrowLeft, ShoppingCart, Check, FolderOpen, Loader2 } from 'lucide-react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '../../utils';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import ShopSubmitPanel from './ShopSubmitPanel';

const CATEGORIES = [
  {
    id: 'grilles',
    label: 'Grilles par thème',
    icon: Grid3X3,
    color: '#EC4899',
    subcategories: [
      { id: 'fleurs', label: 'Fleurs & Nature', icon: Flower2, count: 24 },
      { id: 'animaux', label: 'Animaux', icon: Cat, count: 18 },
      { id: 'maison', label: 'Maison & Déco', icon: Home, count: 12 },
      { id: 'noel', label: 'Noël & Fêtes', icon: TreePine, count: 31 },
      { id: 'enfants', label: 'Enfants & Bébés', icon: Baby, count: 15 },
      { id: 'moderne', label: 'Moderne & Abstrait', icon: Sparkles, count: 9 },
    ]
  },
  {
    id: 'fournitures',
    label: 'Fournitures & Matériel',
    icon: Scissors,
    color: '#8B5CF6',
    subcategories: [
      { id: 'fils', label: 'Fils DMC', count: 456 },
      { id: 'toiles', label: 'Toiles Aïda', count: 28 },
      { id: 'aiguilles', label: 'Aiguilles', count: 15 },
      { id: 'tambours', label: 'Tambours & Cadres', count: 22 },
      { id: 'kits', label: 'Kits complets', count: 45 },
      { id: 'accessoires', label: 'Accessoires', count: 67 },
    ]
  },
  {
    id: 'populaires',
    label: 'Les plus populaires',
    icon: Star,
    color: '#F59E0B',
    subcategories: []
  },
  {
    id: 'nouveautes',
    label: 'Nouveautés',
    icon: Sparkles,
    color: '#10B981',
    subcategories: []
  },
  {
    id: 'favoris',
    label: 'Mes favoris',
    icon: Heart,
    color: '#EF4444',
    subcategories: []
  },
];

const FEATURED_GRIDS = [
  { id: 1, title: 'Bouquet de roses', author: 'Marie L.', price: 4.99, image: 'https://images.unsplash.com/photo-1455659817273-f96807779a8a?w=200&h=200&fit=crop', category: 'fleurs' },
  { id: 2, title: 'Chat endormi', author: 'Sophie B.', price: 3.99, image: 'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=200&h=200&fit=crop', category: 'animaux' },
  { id: 3, title: 'Sapin de Noël', author: 'Claire D.', price: 5.99, image: 'https://images.unsplash.com/photo-1512389142860-9c449e58a814?w=200&h=200&fit=crop', category: 'noel' },
  { id: 4, title: 'Maison cottage', author: 'Emma R.', price: 6.99, image: 'https://images.unsplash.com/photo-1518780664697-55e3ad937233?w=200&h=200&fit=crop', category: 'maison' },
];

export default function ShopModal({ open, onClose }) {
  const navigate = useNavigate();
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [selectedSubcategory, setSelectedSubcategory] = useState(null);
  const [favorites, setFavorites] = useState([]);
  const [cart, setCart] = useState([]);
  const [showSubmitPanel, setShowSubmitPanel] = useState(false);

  const handleSubmitGrid = () => {
    setShowSubmitPanel(true);
  };

  const toggleFavorite = (gridId) => {
    setFavorites(prev => 
      prev.includes(gridId) 
        ? prev.filter(id => id !== gridId)
        : [...prev, gridId]
    );
    toast.success(favorites.includes(gridId) ? 'Retiré des favoris' : 'Ajouté aux favoris');
  };

  const addToCart = (grid) => {
    if (!cart.find(item => item.id === grid.id)) {
      setCart(prev => [...prev, grid]);
      toast.success(`"${grid.title}" ajouté au panier`);
    } else {
      toast.info('Déjà dans le panier');
    }
  };

  const handleBuyGrid = (grid) => {
    addToCart(grid);
    toast.success(`Achat de "${grid.title}" - Redirection vers le paiement...`, { duration: 2000 });
  };

  const handleCategoryClick = (category) => {
    setSelectedCategory(category);
    setSelectedSubcategory(null);
  };

  const handleBack = () => {
    if (selectedSubcategory) {
      setSelectedSubcategory(null);
    } else {
      setSelectedCategory(null);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="w-[95vw] max-w-4xl h-[90vh] md:h-[80vh] p-0 bg-[#0a0a0a] border-[#222] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#222] bg-gradient-to-r from-[#EC4899]/10 to-[#8B5CF6]/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#EC4899] to-[#8B5CF6] flex items-center justify-center">
              <ShoppingBag className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white">Boutique</h2>
              <p className="text-xs text-gray-400">Grilles, fournitures et plus encore</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4 text-white" />
          </button>
        </div>

        <div className="flex flex-col md:flex-row h-[calc(100%-72px)]">
          {/* Sidebar catégories */}
          <div className="w-full md:w-64 border-b md:border-b-0 md:border-r border-[#222] p-3 md:p-4 overflow-x-auto md:overflow-y-auto flex-shrink-0">
            <div className="flex md:flex-col gap-2 md:space-y-0 overflow-x-auto md:overflow-x-visible pb-2 md:pb-0">
              {CATEGORIES.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => handleCategoryClick(cat)}
                  className={`flex-shrink-0 px-3 md:px-4 py-2 md:py-3 rounded-xl flex items-center gap-2 md:gap-3 transition-all whitespace-nowrap ${
                    selectedCategory?.id === cat.id
                      ? 'bg-white/10 border border-white/20'
                      : 'hover:bg-white/5'
                  }`}
                >
                  <cat.icon className="w-4 h-4 md:w-5 md:h-5" style={{ color: cat.color }} />
                  <span className="text-xs md:text-sm font-medium text-white">{cat.label}</span>
                </button>
              ))}
            </div>

            {/* Bouton Soumettre une grille */}
            <div className="hidden md:block mt-6 pt-6 border-t border-[#222]">
              <button
                onClick={handleSubmitGrid}
                className="w-full px-4 py-3 rounded-xl font-semibold flex items-center justify-center gap-2 transition-all bg-gradient-to-r from-[#FFC94A] to-[#F59E0B] text-black hover:opacity-90"
              >
                <Upload className="w-4 h-4" />
                Soumettre une grille
              </button>
              <p className="text-[10px] text-gray-500 text-center mt-2">
                Vendez vos créations et gagnez 85% des ventes
              </p>
            </div>
          </div>

          {/* Contenu principal */}
          <div className="flex-1 p-4 md:p-6 overflow-y-auto">
            {!selectedCategory ? (
              /* Vue d'accueil */
              <div className="space-y-8">
                {/* Bannière */}
                <div className="relative rounded-2xl overflow-hidden bg-gradient-to-r from-[#EC4899] to-[#8B5CF6] p-6">
                  <div className="relative z-10">
                    <h3 className="text-2xl font-bold text-white mb-2">Bienvenue dans la Boutique</h3>
                    <p className="text-white/80 text-sm max-w-md">
                      Découvrez des centaines de grilles de point de croix, du matériel de qualité et partagez vos créations avec la communauté.
                    </p>
                  </div>
                  <div className="absolute right-4 bottom-4 opacity-20">
                    <Palette className="w-32 h-32 text-white" />
                  </div>
                </div>

                {/* Grilles populaires */}
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <h4 className="text-lg font-semibold text-white">Grilles populaires</h4>
                    <button className="text-sm text-[#FFC94A] hover:underline flex items-center gap-1">
                      Voir tout <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-4">
                    {FEATURED_GRIDS.map((grid) => (
                      <div
                        key={grid.id}
                        className="bg-[#1a1a1a] rounded-xl overflow-hidden border border-[#333] hover:border-[#FFC94A]/50 transition-colors cursor-pointer group"
                      >
                        <div className="aspect-square overflow-hidden">
                          <img
                            src={grid.image}
                            alt={grid.title}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                          />
                        </div>
                        <div className="p-3">
                          <h5 className="text-sm font-medium text-white truncate">{grid.title}</h5>
                          <p className="text-xs text-gray-400">{grid.author}</p>
                          <div className="flex items-center justify-between mt-2">
                            <span className="text-[#FFC94A] font-bold">{grid.price}€</span>
                            <div className="flex items-center gap-2">
                              <button 
                                onClick={(e) => { e.stopPropagation(); addToCart(grid); }}
                                className="p-1 hover:bg-white/10 rounded transition-colors"
                              >
                                <ShoppingCart className="w-4 h-4 text-gray-400 hover:text-[#FFC94A]" />
                              </button>
                              <button 
                                onClick={(e) => { e.stopPropagation(); toggleFavorite(grid.id); }}
                                className="p-1 hover:bg-white/10 rounded transition-colors"
                              >
                                <Heart className={`w-4 h-4 transition-colors ${favorites.includes(grid.id) ? 'text-red-500 fill-red-500' : 'text-gray-500 hover:text-red-500'}`} />
                              </button>
                            </div>
                          </div>
                          <button
                            onClick={(e) => { e.stopPropagation(); handleBuyGrid(grid); }}
                            className="w-full mt-2 py-1.5 bg-[#FFC94A] hover:bg-[#FFD666] text-black text-xs font-semibold rounded-lg transition-colors"
                          >
                            Acheter
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Catégories rapides */}
                <div>
                  <h4 className="text-lg font-semibold text-white mb-4">Explorer par catégorie</h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                    {CATEGORIES.slice(0, 3).map((cat) => (
                      <button
                        key={cat.id}
                        onClick={() => handleCategoryClick(cat)}
                        className="p-4 rounded-xl bg-[#1a1a1a] border border-[#333] hover:border-white/30 transition-all flex items-center gap-3"
                      >
                        <cat.icon className="w-6 h-6" style={{ color: cat.color }} />
                        <span className="text-sm font-medium text-white">{cat.label}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              /* Vue catégorie */
              <div>
                <button
                  onClick={handleBack}
                  className="text-sm text-gray-400 hover:text-white mb-4 flex items-center gap-1"
                >
                  ← Retour
                </button>
                
                <div className="flex items-center gap-3 mb-6">
                  <selectedCategory.icon className="w-8 h-8" style={{ color: selectedCategory.color }} />
                  <h3 className="text-xl font-bold text-white">{selectedCategory.label}</h3>
                </div>

                {selectedCategory.subcategories.length > 0 && !selectedSubcategory ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 md:gap-4">
                    {selectedCategory.subcategories.map((sub) => (
                      <button
                        key={sub.id}
                        onClick={() => setSelectedSubcategory(sub)}
                        className="p-4 rounded-xl bg-[#1a1a1a] border border-[#333] hover:border-white/30 transition-all text-left"
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            {sub.icon && <sub.icon className="w-5 h-5 text-gray-400" />}
                            <span className="text-sm font-medium text-white">{sub.label}</span>
                          </div>
                          <span className="text-xs text-gray-500">{sub.count} articles</span>
                        </div>
                      </button>
                    ))}
                  </div>
                ) : selectedSubcategory ? (
                  /* Vue sous-catégorie avec grilles */
                  <div>
                    <button
                      onClick={() => setSelectedSubcategory(null)}
                      className="text-sm text-gray-400 hover:text-white mb-4 flex items-center gap-1"
                    >
                      <ArrowLeft className="w-4 h-4" /> Retour aux catégories
                    </button>
                    <h4 className="text-lg font-semibold text-white mb-4">{selectedSubcategory.label}</h4>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 md:gap-4">
                      {FEATURED_GRIDS.map((grid) => (
                        <div
                          key={grid.id}
                          className="bg-[#1a1a1a] rounded-xl overflow-hidden border border-[#333] hover:border-[#FFC94A]/50 transition-colors cursor-pointer group"
                        >
                          <div className="aspect-square overflow-hidden">
                            <img
                              src={grid.image}
                              alt={grid.title}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                            />
                          </div>
                          <div className="p-3">
                            <h5 className="text-sm font-medium text-white truncate">{grid.title}</h5>
                            <p className="text-xs text-gray-400">{grid.author}</p>
                            <div className="flex items-center justify-between mt-2">
                              <span className="text-[#FFC94A] font-bold">{grid.price}€</span>
                              <div className="flex items-center gap-1">
                                <button 
                                  onClick={(e) => { e.stopPropagation(); addToCart(grid); }}
                                  className="p-1 hover:bg-white/10 rounded"
                                >
                                  <ShoppingCart className="w-3 h-3 text-gray-400 hover:text-[#FFC94A]" />
                                </button>
                                <button 
                                  onClick={(e) => { e.stopPropagation(); toggleFavorite(grid.id); }}
                                  className="p-1 hover:bg-white/10 rounded"
                                >
                                  <Heart className={`w-3 h-3 ${favorites.includes(grid.id) ? 'text-red-500 fill-red-500' : 'text-gray-400'}`} />
                                </button>
                              </div>
                            </div>
                            <button
                              onClick={(e) => { e.stopPropagation(); handleBuyGrid(grid); }}
                              className="w-full mt-2 py-1 bg-[#FFC94A] hover:bg-[#FFD666] text-black text-xs font-semibold rounded transition-colors"
                            >
                              Acheter
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : selectedCategory.id === 'favoris' ? (
                  <div className="text-center py-12">
                    {favorites.length === 0 ? (
                      <div className="text-gray-500">
                        <Heart className="w-12 h-12 mx-auto mb-4 opacity-30" />
                        <p>Aucun favori pour le moment</p>
                        <p className="text-xs mt-2">Cliquez sur ❤️ pour ajouter des grilles</p>
                      </div>
                    ) : (
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 md:gap-4">
                        {FEATURED_GRIDS.filter(g => favorites.includes(g.id)).map((grid) => (
                          <div key={grid.id} className="bg-[#1a1a1a] rounded-xl overflow-hidden border border-[#333]">
                            <div className="aspect-square overflow-hidden">
                              <img src={grid.image} alt={grid.title} className="w-full h-full object-cover" />
                            </div>
                            <div className="p-3">
                              <h5 className="text-sm font-medium text-white">{grid.title}</h5>
                              <span className="text-[#FFC94A] font-bold">{grid.price}€</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 md:gap-4">
                    {FEATURED_GRIDS.map((grid) => (
                      <div
                        key={grid.id}
                        className="bg-[#1a1a1a] rounded-xl overflow-hidden border border-[#333] hover:border-[#FFC94A]/50 transition-colors cursor-pointer group"
                      >
                        <div className="aspect-square overflow-hidden">
                          <img
                            src={grid.image}
                            alt={grid.title}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                          />
                        </div>
                        <div className="p-3">
                          <h5 className="text-sm font-medium text-white truncate">{grid.title}</h5>
                          <p className="text-xs text-gray-400">{grid.author}</p>
                          <div className="flex items-center justify-between mt-2">
                            <span className="text-[#FFC94A] font-bold">{grid.price}€</span>
                            <div className="flex items-center gap-1">
                              <button 
                                onClick={(e) => { e.stopPropagation(); addToCart(grid); }}
                                className="p-1 hover:bg-white/10 rounded"
                              >
                                <ShoppingCart className="w-3 h-3 text-gray-400 hover:text-[#FFC94A]" />
                              </button>
                              <button 
                                onClick={(e) => { e.stopPropagation(); toggleFavorite(grid.id); }}
                                className="p-1 hover:bg-white/10 rounded"
                              >
                                <Heart className={`w-3 h-3 ${favorites.includes(grid.id) ? 'text-red-500 fill-red-500' : 'text-gray-400'}`} />
                              </button>
                            </div>
                          </div>
                          <button
                            onClick={(e) => { e.stopPropagation(); handleBuyGrid(grid); }}
                            className="w-full mt-2 py-1 bg-[#FFC94A] hover:bg-[#FFD666] text-black text-xs font-semibold rounded transition-colors"
                          >
                            Acheter
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </DialogContent>

      {/* Panel de soumission */}
      <ShopSubmitPanel 
        open={showSubmitPanel} 
        onClose={() => setShowSubmitPanel(false)} 
      />
    </Dialog>
  );
}