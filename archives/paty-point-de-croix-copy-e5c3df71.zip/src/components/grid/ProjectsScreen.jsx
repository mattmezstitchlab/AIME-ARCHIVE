import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { 
  Plus, 
  ArrowLeft, 
  MoreVertical, 
  Folder, 
  Calendar, 
  Grid3x3, 
  Palette,
  Pencil,
  Copy,
  Trash2,
  Search,
  X
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { toast } from 'sonner';

// Composant miniature de projet
function ProjectThumbnail({ pattern }) {
  const canvasRef = React.useRef(null);

  React.useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    const size = 80;
    canvas.width = size;
    canvas.height = size;

    ctx.fillStyle = '#f5f5f5';
    ctx.fillRect(0, 0, size, size);

    if (pattern?.source_image) {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        ctx.drawImage(img, 0, 0, size, size);
      };
      img.src = pattern.source_image;
    } else if (pattern?.stitches?.length > 0) {
      // Dessiner une miniature basée sur les points
      const cellSize = size / Math.max(pattern.width || 20, pattern.height || 20);
      pattern.stitches.slice(0, 500).forEach(stitch => {
        ctx.fillStyle = stitch.color || '#666';
        ctx.fillRect(stitch.col * cellSize, stitch.row * cellSize, cellSize, cellSize);
      });
    } else {
      // Icône par défaut
      ctx.fillStyle = '#ddd';
      ctx.font = '32px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('🧵', size / 2, size / 2);
    }
  }, [pattern]);

  return (
    <canvas 
      ref={canvasRef} 
      className="w-20 h-20 rounded-lg border border-gray-200 object-cover"
    />
  );
}

// Carte de projet
function ProjectCard({ project, onOpen, onRename, onDuplicate, onDelete }) {
  const pattern = project.pattern || {};
  const colorCount = pattern.colors?.length || 0;
  const gridSize = pattern.width && pattern.height 
    ? `${pattern.width} × ${pattern.height}` 
    : `${project.nb_colonnes || 300} × ${project.nb_lignes || 300}`;

  const formatDate = (dateStr) => {
    if (!dateStr) return 'Date inconnue';
    const date = new Date(dateStr);
    return date.toLocaleDateString('fr-FR', { 
      day: 'numeric', 
      month: 'short', 
      year: 'numeric' 
    });
  };

  return (
    <div className="bg-white rounded-xl border border-gray-200 p-4 hover:shadow-lg transition-all duration-200 hover:border-gray-300">
      <div className="flex gap-4">
        {/* Miniature */}
        <ProjectThumbnail pattern={pattern} />

        {/* Infos */}
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <h3 className="font-semibold text-gray-900 truncate">
              {project.name || 'Projet sans nom'}
            </h3>
            
            {/* Menu actions */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="p-1 rounded hover:bg-gray-100 transition-colors">
                  <MoreVertical className="w-4 h-4 text-gray-500" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-40">
                <DropdownMenuItem onClick={() => onRename(project)}>
                  <Pencil className="w-4 h-4 mr-2" />
                  Renommer
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => onDuplicate(project)}>
                  <Copy className="w-4 h-4 mr-2" />
                  Dupliquer
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem 
                  onClick={() => onDelete(project)}
                  className="text-red-600 focus:text-red-600"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Supprimer
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          {/* Métadonnées */}
          <div className="mt-2 space-y-1">
            <div className="flex items-center gap-2 text-xs text-gray-500">
              <Calendar className="w-3 h-3" />
              <span>{formatDate(project.updated_date || project.created_date)}</span>
            </div>
            <div className="flex items-center gap-4 text-xs text-gray-500">
              <div className="flex items-center gap-1">
                <Grid3x3 className="w-3 h-3" />
                <span>{gridSize}</span>
              </div>
              {colorCount > 0 && (
                <div className="flex items-center gap-1">
                  <Palette className="w-3 h-3" />
                  <span>{colorCount} couleurs</span>
                </div>
              )}
            </div>
          </div>

          {/* Bouton Ouvrir */}
          <Button 
            onClick={() => onOpen(project)}
            className="mt-3 h-8 text-sm bg-black hover:bg-gray-800"
          >
            Ouvrir
          </Button>
        </div>
      </div>
    </div>
  );
}

export default function ProjectsScreen({ onClose, onOpenProject, onNewProject }) {
  const queryClient = useQueryClient();
  const [searchQuery, setSearchQuery] = useState('');
  const [projectToDelete, setProjectToDelete] = useState(null);
  const [projectToRename, setProjectToRename] = useState(null);
  const [newName, setNewName] = useState('');

  // Charger les projets
  const { data: projects = [], isLoading } = useQuery({
    queryKey: ['projects'],
    queryFn: () => base44.entities.Grid.list('-updated_date'),
  });

  // Mutation supprimer
  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Grid.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['projects'] });
      toast.success('Projet supprimé');
      setProjectToDelete(null);
    },
    onError: () => toast.error('Erreur lors de la suppression'),
  });

  // Mutation renommer
  const renameMutation = useMutation({
    mutationFn: ({ id, name }) => base44.entities.Grid.update(id, { name }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['projects'] });
      toast.success('Projet renommé');
      setProjectToRename(null);
      setNewName('');
    },
    onError: () => toast.error('Erreur lors du renommage'),
  });

  // Mutation dupliquer
  const duplicateMutation = useMutation({
    mutationFn: async (project) => {
      const { id, created_date, updated_date, created_by, ...data } = project;
      return base44.entities.Grid.create({
        ...data,
        name: `${project.name || 'Projet'} (copie)`,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['projects'] });
      toast.success('Projet dupliqué');
    },
    onError: () => toast.error('Erreur lors de la duplication'),
  });

  // Filtrer les projets
  const filteredProjects = projects.filter(p => 
    !searchQuery || 
    (p.name || '').toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleOpenProject = (project) => {
    onOpenProject?.(project.id);
    onClose?.();
  };

  const handleRename = (project) => {
    setProjectToRename(project);
    setNewName(project.name || '');
  };

  const handleConfirmRename = () => {
    if (projectToRename && newName.trim()) {
      renameMutation.mutate({ id: projectToRename.id, name: newName.trim() });
    }
  };

  return (
    <div 
      className="fixed inset-0 z-[200] flex items-center justify-center"
      style={{ backgroundColor: 'rgba(0, 0, 0, 0.8)' }}
      onClick={(e) => {
        // Fermer si clic sur l'overlay (pas sur la fenêtre)
        if (e.target === e.currentTarget) {
          onClose?.();
        }
      }}
    >
      {/* Fenêtre modale */}
      <div 
        className="bg-[#111] rounded-xl shadow-2xl flex flex-col overflow-hidden"
        style={{ 
          width: '90%', 
          maxWidth: '1100px', 
          height: '85%', 
          maxHeight: '800px' 
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <header className="flex-shrink-0 h-16 bg-black flex items-center justify-between px-4 sm:px-6 border-b border-gray-800">
          <div className="flex items-center gap-4">
            <div>
              <h1 className="text-lg font-bold text-white">Mes projets</h1>
              <p className="text-xs text-gray-400 hidden sm:block">
                Retrouvez toutes vos grilles enregistrées
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Button 
              onClick={() => {
                onClose?.();
                onNewProject?.();
              }}
              className="bg-[#FFC94A] hover:bg-[#FFD666] text-black font-medium"
            >
              <Plus className="w-4 h-4 mr-2" />
              <span className="hidden sm:inline">Nouveau projet</span>
              <span className="sm:hidden">Nouveau</span>
            </Button>
            
            {/* Bouton fermer */}
            <button
              onClick={onClose}
              className="w-10 h-10 rounded-lg bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors"
            >
              <X className="w-5 h-5 text-white" />
            </button>
          </div>
        </header>

        {/* Barre de recherche */}
        <div className="flex-shrink-0 p-4 border-b border-gray-800 bg-[#0a0a0a]">
          <div className="max-w-md relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
            <Input
              type="text"
              placeholder="Rechercher un projet..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 h-10 bg-[#1a1a1a] border-gray-700 text-white placeholder:text-gray-500"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 p-1 hover:bg-gray-700 rounded"
              >
                <X className="w-4 h-4 text-gray-400" />
              </button>
            )}
          </div>
        </div>

        {/* Contenu principal */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 bg-[#0a0a0a]">
          {isLoading ? (
            <div className="flex items-center justify-center h-64">
              <div className="animate-spin w-8 h-8 border-4 border-gray-600 border-t-[#FFC94A] rounded-full" />
            </div>
          ) : filteredProjects.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-64 text-center">
              <Folder className="w-16 h-16 text-gray-600 mb-4" />
              {searchQuery ? (
                <>
                  <h3 className="text-lg font-medium text-gray-300">Aucun résultat</h3>
                  <p className="text-gray-500 mt-1">
                    Aucun projet ne correspond à "{searchQuery}"
                  </p>
                </>
              ) : (
                <>
                  <h3 className="text-lg font-medium text-gray-300">
                    Vous n'avez pas encore de projet
                  </h3>
                  <p className="text-gray-500 mt-1 mb-4">
                    Créez votre première grille de broderie !
                  </p>
                  <Button 
                    onClick={() => {
                      onClose?.();
                      onNewProject?.();
                    }}
                    className="bg-[#FFC94A] hover:bg-[#FFD666] text-black font-medium"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Créer mon premier projet
                  </Button>
                </>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredProjects.map((project) => (
                <ProjectCard
                  key={project.id}
                  project={project}
                  onOpen={handleOpenProject}
                  onRename={handleRename}
                  onDuplicate={(p) => duplicateMutation.mutate(p)}
                  onDelete={(p) => setProjectToDelete(p)}
                />
              ))}
            </div>
          )}
        </main>
      </div>

      {/* Dialog de confirmation suppression */}
      <AlertDialog open={!!projectToDelete} onOpenChange={() => setProjectToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Supprimer ce projet ?</AlertDialogTitle>
            <AlertDialogDescription>
              Le projet "{projectToDelete?.name || 'Sans nom'}" sera définitivement supprimé. 
              Cette action est irréversible.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annuler</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteMutation.mutate(projectToDelete.id)}
              className="bg-red-600 hover:bg-red-700"
            >
              Supprimer
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Dialog renommer */}
      <AlertDialog open={!!projectToRename} onOpenChange={() => setProjectToRename(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Renommer le projet</AlertDialogTitle>
          </AlertDialogHeader>
          <Input
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            placeholder="Nouveau nom du projet"
            className="mt-2"
            autoFocus
            onKeyDown={(e) => e.key === 'Enter' && handleConfirmRename()}
          />
          <AlertDialogFooter>
            <AlertDialogCancel>Annuler</AlertDialogCancel>
            <AlertDialogAction onClick={handleConfirmRename}>
              Renommer
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}