/**
 * Moteur d'exportation PatyBee 2.0
 * Gère l'export en PDF, PNG et format propriétaire PBX
 */

import jsPDF from 'jspdf';

// ========== EXPORT PDF ==========

export async function exportToPDF(pattern, options = {}) {
  const {
    quality = 'hq', // 'hq' ou 'eco'
    format = 'a4-portrait',
    includeLegend = true,
    includeSymbolTable = true,
    includeDimensions = true,
    includeGuides = true,
    includeCover = false,
    includeSignature = true,
    includeThreadInfo = true,
    includeSpecialStitches = true,
    symbolSize = 'medium', // 'small', 'medium', 'large'
    colorBlindMode = false,
    inkSaverMode = false,
    includeQRCode = false
  } = options;

  const dpi = quality === 'hq' ? 300 : 150;
  
  // Créer le PDF
  const doc = new jsPDF({
    orientation: format.includes('portrait') ? 'portrait' : 'landscape',
    unit: 'mm',
    format: format.includes('letter') ? 'letter' : 'a4'
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();

  let currentPage = 1;

  // Page de couverture
  if (includeCover) {
    addCoverPage(doc, pattern, pageWidth, pageHeight);
    doc.addPage();
    currentPage++;
  }

  // Légende des couleurs DMC
  if (includeLegend) {
    addLegendPage(doc, pattern, pageWidth, pageHeight, includeThreadInfo);
    doc.addPage();
    currentPage++;
  }

  // Tableau symboles <-> couleurs
  if (includeSymbolTable) {
    addSymbolTablePage(doc, pattern, pageWidth, pageHeight);
    doc.addPage();
    currentPage++;
  }

  // Grille principale
  await addGridPages(doc, pattern, {
    pageWidth,
    pageHeight,
    dpi,
    symbolSize,
    includeGuides,
    includeDimensions,
    colorBlindMode,
    inkSaverMode
  });

  // Signature PatyBee
  if (includeSignature) {
    addPatyBeeSignature(doc, pageWidth, pageHeight);
  }

  // QR Code
  if (includeQRCode) {
    // TODO: Implémenter génération QR Code
  }

  return doc;
}

function addCoverPage(doc, pattern, width, height) {
  // Titre centré
  doc.setFontSize(32);
  doc.setFont(undefined, 'bold');
  doc.text(pattern.name || 'Ma Grille de Broderie', width / 2, 60, { align: 'center' });

  // Informations
  doc.setFontSize(14);
  doc.setFont(undefined, 'normal');
  doc.text(`${pattern.width} × ${pattern.height} points`, width / 2, 80, { align: 'center' });
  doc.text(`${pattern.colorPalette?.length || 0} couleurs DMC`, width / 2, 90, { align: 'center' });

  // Date
  doc.setFontSize(12);
  doc.text(new Date().toLocaleDateString('fr-FR'), width / 2, height - 30, { align: 'center' });

  // Logo PatyBee
  doc.setFontSize(10);
  doc.setTextColor(100, 100, 100);
  doc.text('Créé avec PatyBee', width / 2, height - 20, { align: 'center' });
}

function addLegendPage(doc, pattern, width, height, includeThreadInfo) {
  doc.setFontSize(18);
  doc.setFont(undefined, 'bold');
  doc.text('Légende des Couleurs DMC', 20, 20);

  if (!pattern.colorPalette) return;

  let y = 35;
  const lineHeight = 8;

  doc.setFontSize(10);
  doc.setFont(undefined, 'normal');

  pattern.colorPalette.forEach((color, index) => {
    if (y > height - 30) {
      doc.addPage();
      y = 20;
    }

    // Rectangle de couleur
    doc.setFillColor(color.r, color.g, color.b);
    doc.rect(20, y - 5, 10, 6, 'F');

    // Code DMC
    doc.setFont(undefined, 'bold');
    doc.text(`DMC ${color.dmcCode || color.code || '?'}`, 35, y);

    // Nom
    doc.setFont(undefined, 'normal');
    doc.text(color.name || 'Sans nom', 65, y);

    // Symbole
    if (color.assignedSymbolChar) {
      doc.text(`${color.assignedSymbolChar}`, 140, y);
    }

    // Nombre de points
    doc.text(`${color.totalCount || color.count || 0} pts`, 155, y);

    // Fils conseillés
    if (includeThreadInfo) {
      const skeins = Math.ceil((color.totalCount || 0) / 400);
      doc.text(`${skeins} écheveau${skeins > 1 ? 'x' : ''}`, 180, y);
    }

    y += lineHeight;
  });
}

function addSymbolTablePage(doc, pattern, width, height) {
  doc.setFontSize(18);
  doc.setFont(undefined, 'bold');
  doc.text('Tableau des Symboles', 20, 20);

  if (!pattern.colorPalette) return;

  let x = 20;
  let y = 35;
  const cellSize = 15;
  const cols = 8;

  doc.setFontSize(10);

  pattern.colorPalette.forEach((color, index) => {
    if (index > 0 && index % cols === 0) {
      y += cellSize + 5;
      x = 20;
    }

    if (y > height - 30) {
      doc.addPage();
      y = 35;
      x = 20;
    }

    // Carré de couleur
    doc.setFillColor(color.r, color.g, color.b);
    doc.rect(x, y, cellSize, cellSize, 'F');
    doc.setDrawColor(0, 0, 0);
    doc.rect(x, y, cellSize, cellSize, 'S');

    // Symbole
    if (color.assignedSymbolChar) {
      doc.setFontSize(12);
      doc.text(color.assignedSymbolChar, x + cellSize / 2, y + cellSize / 2 + 2, { align: 'center' });
    }

    // Code DMC en dessous
    doc.setFontSize(7);
    doc.text(color.dmcCode || color.code || '?', x + cellSize / 2, y + cellSize + 4, { align: 'center' });

    x += cellSize + 5;
  });
}

async function addGridPages(doc, pattern, options) {
  const { pageWidth, pageHeight, dpi, symbolSize, includeGuides, inkSaverMode } = options;

  // Pour l'instant, dessiner une page simple
  // TODO: Implémenter pagination intelligente si grille > 1 page

  const margin = 20;
  const availableWidth = pageWidth - 2 * margin;
  const availableHeight = pageHeight - 2 * margin;

  const cellSize = Math.min(
    availableWidth / pattern.width,
    availableHeight / pattern.height
  );

  // Dessiner la grille
  for (let y = 0; y < pattern.height; y++) {
    for (let x = 0; x < pattern.width; x++) {
      const cell = pattern.symbolGrid?.[y]?.[x];
      if (!cell) continue;

      const px = margin + x * cellSize;
      const py = margin + y * cellSize;

      // Fond de couleur (sauf si mode économie d'encre)
      if (!inkSaverMode) {
        const color = pattern.colorPalette.find(c => c.id === cell.colorId);
        if (color) {
          doc.setFillColor(color.r, color.g, color.b);
          doc.rect(px, py, cellSize, cellSize, 'F');
        }
      }

      // Bordure de cellule
      doc.setDrawColor(inkSaverMode ? 150 : 200, inkSaverMode ? 150 : 200, inkSaverMode ? 150 : 200);
      doc.rect(px, py, cellSize, cellSize, 'S');

      // Symbole
      if (cell.symbol || cell.assignedSymbolChar) {
        doc.setFontSize(symbolSize === 'large' ? 8 : symbolSize === 'small' ? 4 : 6);
        doc.setTextColor(0, 0, 0);
        const symbol = cell.assignedSymbolChar || cell.symbol || '';
        doc.text(symbol, px + cellSize / 2, py + cellSize / 2 + 1, { align: 'center' });
      }
    }
  }

  // Repères
  if (includeGuides) {
    // Repère 10x10
    doc.setDrawColor(255, 0, 0);
    doc.setLineWidth(0.5);
    for (let i = 0; i <= pattern.width; i += 10) {
      const px = margin + i * cellSize;
      doc.line(px, margin, px, margin + pattern.height * cellSize);
    }
    for (let i = 0; i <= pattern.height; i += 10) {
      const py = margin + i * cellSize;
      doc.line(margin, py, margin + pattern.width * cellSize, py);
    }
  }
}

function addPatyBeeSignature(doc, width, height) {
  doc.setFontSize(8);
  doc.setTextColor(150, 150, 150);
  doc.text('Généré avec PatyBee - L\'IA de la broderie', width / 2, height - 5, { align: 'center' });
}

// ========== EXPORT PNG ==========

export async function exportToPNG(pattern, options = {}) {
  const {
    includeGrid = true,
    includeSymbols = true,
    includeColors = true,
    resolution = '2k', // '1080p', '2k', '4k', '6000px'
    backgroundColor = 'white' // 'white' ou 'transparent'
  } = options;

  // Résolutions
  const resolutions = {
    '1080p': 1920,
    '2k': 2560,
    '4k': 3840,
    '6000px': 6000
  };

  const targetWidth = resolutions[resolution] || 2560;

  // Créer un canvas
  const canvas = document.createElement('canvas');
  const cellSize = Math.floor(targetWidth / pattern.width);
  canvas.width = pattern.width * cellSize;
  canvas.height = pattern.height * cellSize;

  const ctx = canvas.getContext('2d');

  // Fond
  if (backgroundColor === 'white') {
    ctx.fillStyle = 'white';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  }

  // Dessiner la grille
  for (let y = 0; y < pattern.height; y++) {
    for (let x = 0; x < pattern.width; x++) {
      const cell = pattern.symbolGrid?.[y]?.[x];
      if (!cell) continue;

      const px = x * cellSize;
      const py = y * cellSize;

      // Couleur de fond
      if (includeGrid) {
        const color = pattern.colorPalette.find(c => c.id === cell.colorId);
        if (color) {
          ctx.fillStyle = `rgb(${color.r}, ${color.g}, ${color.b})`;
          ctx.fillRect(px, py, cellSize, cellSize);
        }
      }

      // Bordure
      ctx.strokeStyle = '#ddd';
      ctx.strokeRect(px, py, cellSize, cellSize);

      // Symbole
      if (includeSymbols && cell.assignedSymbolChar) {
        ctx.fillStyle = 'black';
        ctx.font = `${cellSize * 0.6}px Arial`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(cell.assignedSymbolChar, px + cellSize / 2, py + cellSize / 2);
      }
    }
  }

  return canvas.toDataURL('image/png');
}

// ========== EXPORT FORMAT PATYBEE (.PBX) ==========

export function exportToPBX(pattern, metadata = {}) {
  const pbxData = {
    version: '2.0',
    format: 'PatyBee',
    created: new Date().toISOString(),
    metadata: {
      author: metadata.author || 'Anonymous',
      title: pattern.name || 'Untitled',
      description: metadata.description || '',
      license: metadata.license || 'private',
      ...metadata
    },
    grid: {
      width: pattern.width,
      height: pattern.height,
      symbolGrid: pattern.symbolGrid,
      zoom: pattern.zoom,
      offset_x: pattern.offset_x,
      offset_y: pattern.offset_y
    },
    palette: {
      colors: pattern.colorPalette,
      dmcConversionApplied: pattern.dmcConversionApplied || false
    },
    stitchTypes: {
      enabled: pattern.stitchTypesEnabled || [],
      calques: pattern.calques || {}
    },
    optimization: {
      applied: pattern.optimizationComplete || false,
      steps: pattern.optimizationSteps || [],
      date: pattern.optimizationDate || null
    },
    mosaic: pattern.mosaic || null,
    guides: {
      center: pattern.repere_central,
      grid10x10: pattern.repere_10x10,
      numbering: pattern.numerotation_10x10
    },
    original: metadata.includeOriginal ? pattern.original : null
  };

  return JSON.stringify(pbxData, null, 2);
}

export function downloadPBX(pbxData, filename) {
  const blob = new Blob([pbxData], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename.endsWith('.pbx') ? filename : `${filename}.pbx`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export function downloadPDF(doc, filename) {
  doc.save(filename.endsWith('.pdf') ? filename : `${filename}.pdf`);
}

export function downloadPNG(dataUrl, filename) {
  const a = document.createElement('a');
  a.href = dataUrl;
  a.download = filename.endsWith('.png') ? filename : `${filename}.png`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}