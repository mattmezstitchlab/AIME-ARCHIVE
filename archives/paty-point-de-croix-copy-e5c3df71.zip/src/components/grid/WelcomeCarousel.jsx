import React, { useState, useEffect } from 'react';
import { X, ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { motion, AnimatePresence } from 'framer-motion';

// Logo PatyBee
function PatyBeeLogo() {
  return (
    <svg width="60" height="60" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
      <style>
        {`
          @keyframes star-anim {
            0%, 100% { fill: #000000; transform: rotate(0deg); }
            5% { fill: #F5C200; }
            20% { fill: #F5C200; transform: rotate(360deg); }
            22%, 100% { fill: #000000; transform: rotate(360deg); }
          }
          
          @keyframes diamond-anim {
            0%, 22%, 100% { fill: #000000; transform: rotate(0deg); }
            27% { fill: #2F80ED; }
            42% { fill: #2F80ED; transform: rotate(15deg); }
            44%, 100% { fill: #000000; transform: rotate(0deg); }
          }
          
          @keyframes circle-anim {
            0%, 44%, 100% { fill: #000000; opacity: 1; }
            49% { fill: #27AE60; opacity: 1; }
            55% { fill: #27AE60; opacity: 0.4; }
            61% { fill: #27AE60; opacity: 1; }
            64%, 100% { fill: #000000; opacity: 1; }
          }
          
          @keyframes square-anim {
            0%, 64%, 100% { fill: #000000; transform: rotate(0deg); }
            69% { fill: #EB5BA9; }
            79% { fill: #EB5BA9; transform: rotate(90deg); }
            84% { fill: #EB5BA9; transform: rotate(0deg); }
            86%, 100% { fill: #000000; transform: rotate(0deg); }
          }
          
          .star { 
            animation: star-anim 3.7s ease-in-out infinite;
            transform-origin: 9px 8.5px;
          }
          .circle { 
            animation: circle-anim 3.7s ease-in-out infinite;
          }
          .square { 
            animation: square-anim 3.7s ease-in-out infinite;
            transform-origin: 7.5px 26px;
          }
          .diamond { 
            animation: diamond-anim 3.7s ease-in-out infinite;
            transform-origin: 26.5px 26px;
          }
        `}
      </style>
      
      <path className="star" d="M9 2L10.5 7L15.5 8.5L10.5 10L9 15L7.5 10L2.5 8.5L7.5 7L9 2Z" fill="#000000"/>
      <circle className="circle" cx="26.5" cy="9" r="5" fill="#000000"/>
      <rect className="square" x="2.5" y="21" width="10" height="10" fill="#000000"/>
      <path className="diamond" d="M26.5 21L31.5 26L26.5 31L21.5 26L26.5 21Z" fill="#000000"/>
    </svg>
  );
}

const SLIDES = [
  {
    title: "PATYBEE – LA NOUVELLE ÈRE DU POINT DE CROIX",
    text: "PatyBee convertit tes images en grilles optimisées,\nanalyse chaque pixel pour choisir les bons fils,\net construit pour toi la grille parfaite, prête à broder."
  },
  {
    title: "CONVERSION DMC INTELLIGENTE",
    text: "Chaque couleur brute est automatiquement\nrapprochée de la plus fidèle nuance DMC,\nsans doublons et avec gestion des dégradés."
  },
  {
    title: "STYLES DE POINTS OPTIMISÉS",
    text: "Points complets, demi-points, backstitch,\nnœuds, perles, effets spéciaux…\nPatyBee choisit ce qui rend ton motif le plus beau."
  },
  {
    title: "IA–FOCUS™ : LA PRÉCISION ÉVOLUÉE",
    text: "Une IA dédiée détecte les zones importantes,\nsimplifie ce qui doit l'être, détaille ce qui compte,\net équilibre ton motif comme une brodeuse experte."
  },
  {
    title: "MAPPING 4D™ – VOIR TA GRILLE AUTREMENT",
    text: "Une mini-carte intelligente te montre\nle repère central, tes déplacements,\net les zones techniques de ton motif."
  },
  {
    title: "L'EXPÉRIENCE BRODERIE RÉINVENTÉE",
    text: "Symbole parfait, DMC parfait,\ngrille parfaite en quelques secondes,\net une IA qui t'accompagne du début à la fin."
  }
];

export default function WelcomeCarousel({ isOpen, onStart, onContinue, onDontShowAgain }) {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [dontShowAgain, setDontShowAgain] = useState(false);
  const [autoPlay, setAutoPlay] = useState(true);

  // Auto-play carousel
  useEffect(() => {
    if (!isOpen || !autoPlay) return;

    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % SLIDES.length);
    }, 5000);

    return () => clearInterval(timer);
  }, [isOpen, autoPlay]);

  // Reset when opening
  useEffect(() => {
    if (isOpen) {
      setCurrentSlide(0);
      setAutoPlay(true);
    }
  }, [isOpen]);

  const handlePrevious = () => {
    setAutoPlay(false);
    setCurrentSlide((prev) => (prev - 1 + SLIDES.length) % SLIDES.length);
  };

  const handleNext = () => {
    setAutoPlay(false);
    setCurrentSlide((prev) => (prev + 1) % SLIDES.length);
  };

  const handleDotClick = (index) => {
    setAutoPlay(false);
    setCurrentSlide(index);
  };

  const handleClose = () => {
    if (dontShowAgain) {
      onDontShowAgain();
    }
    onContinue();
  };

  const handleStart = () => {
    if (dontShowAgain) {
      onDontShowAgain();
    }
    onStart();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center">
      {/* Fond noir semi-transparent */}
      <div className="absolute inset-0 bg-black" style={{ opacity: 0.95 }} />

      {/* Bloc de contenu */}
      <div className="relative bg-slate-50 rounded-2xl shadow-2xl w-[580px] max-w-[90vw] max-h-[90vh] overflow-hidden">
        {/* Bouton fermer */}
        <button
          onClick={handleClose}
          className="absolute top-4 right-4 w-8 h-8 rounded-lg bg-black/5 hover:bg-black/10 flex items-center justify-center transition-colors z-10"
        >
          <X className="w-5 h-5 text-slate-700" />
        </button>

        {/* En-tête fixe */}
        <div className="px-12 pt-10 pb-6 text-center">
          <div className="flex justify-center mb-4">
            <PatyBeeLogo />
          </div>
          <h1 className="text-2xl font-bold text-slate-900 mb-3">
            Bienvenue dans ta nouvelle grille PatyBee
          </h1>
          <p className="text-sm text-slate-600 leading-relaxed">
            PatyBee t'aide à transformer tes images en grilles optimisées, prêtes à broder avec les fils DMC.<br />
            Avant de commencer, découvre en quelques écrans ce que PatyBee fait pour toi automatiquement.
          </p>
        </div>

        {/* Zone carrousel */}
        <div className="relative px-12 py-8 min-h-[240px] flex items-center">
          {/* Flèche gauche */}
          <button
            onClick={handlePrevious}
            className="absolute left-4 w-10 h-10 rounded-full bg-black/5 hover:bg-black/10 flex items-center justify-center transition-colors"
          >
            <ChevronLeft className="w-5 h-5 text-slate-700" />
          </button>

          {/* Contenu du slide */}
          <div className="flex-1 text-center px-8">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentSlide}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
                className="space-y-4"
              >
                <h2 className="text-lg font-bold text-slate-900 uppercase tracking-tight">
                  {SLIDES[currentSlide].title}
                </h2>
                <p className="text-sm text-slate-600 leading-relaxed whitespace-pre-line">
                  {SLIDES[currentSlide].text}
                </p>
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Flèche droite */}
          <button
            onClick={handleNext}
            className="absolute right-4 w-10 h-10 rounded-full bg-black/5 hover:bg-black/10 flex items-center justify-center transition-colors"
          >
            <ChevronRight className="w-5 h-5 text-slate-700" />
          </button>
        </div>

        {/* Puces de pagination */}
        <div className="flex justify-center gap-2 pb-8">
          {SLIDES.map((_, index) => (
            <button
              key={index}
              onClick={() => handleDotClick(index)}
              className={`w-2 h-2 rounded-full transition-all ${
                currentSlide === index
                  ? 'bg-slate-900 w-6'
                  : 'bg-slate-300 hover:bg-slate-400'
              }`}
            />
          ))}
        </div>

        {/* Boutons d'action */}
        <div className="px-12 pb-8 space-y-4">
          <div className="flex gap-3">
            <Button
              onClick={handleStart}
              className="flex-1 bg-black hover:bg-slate-800 text-white font-semibold py-3"
            >
              COMMENCER
            </Button>
            <Button
              onClick={handleClose}
              variant="outline"
              className="flex-1 bg-transparent border-2 border-slate-300 text-slate-900 hover:bg-slate-100 font-semibold py-3"
            >
              CONTINUER
            </Button>
          </div>

          {/* Checkbox "Ne plus afficher" */}
          <label className="flex items-center gap-2 text-xs text-slate-600 cursor-pointer">
            <input
              type="checkbox"
              checked={dontShowAgain}
              onChange={(e) => setDontShowAgain(e.target.checked)}
              className="w-4 h-4 rounded border-slate-300"
            />
            <span>Ne plus afficher cet écran au démarrage d'une nouvelle grille</span>
          </label>
        </div>
      </div>
    </div>
  );
}