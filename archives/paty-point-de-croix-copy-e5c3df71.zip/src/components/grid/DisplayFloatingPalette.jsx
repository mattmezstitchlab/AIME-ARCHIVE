import React from 'react';
import { 
  Grid3X3, 
  Hash, 
  Droplet, 
  Image, 
  Moon, 
  Sun,
  ZoomIn, 
  Layers,
  Star,
  Crosshair,
  Bookmark
} from 'lucide-react';
import { toast } from 'sonner';

const DISPLAY_TOGGLES = [
  { id: 'showGrid', icon: Grid3X3, label: 'Quadrillage' },
  { id: 'showSymbols', icon: Hash, label: 'Symboles' },
  { id: 'showColors', icon: Droplet, label: 'Couleurs réelles' },
  { id: 'showBackgroundImg', icon: Image, label: 'Image de fond (50%)' },
  { id: 'showOverlayOriginal', icon: Layers, label: 'Calques' },
];

const SYMBOL_SIZES = [
  { id: 'small', stars: 1, label: 'Petit' },
  { id: 'medium', stars: 2, label: 'Moyen' },
  { id: 'large', stars: 3, label: 'Grand' },
];

// Composant dropdown pour la taille des symboles (une seule étoile avec menu vertical)
function SymbolSizeDropdown({ symbolSize, onSymbolSizeChange }) {
  const [isOpen, setIsOpen] = React.useState(false);
  const currentSize = SYMBOL_SIZES.find(s => s.id === symbolSize) || SYMBOL_SIZES[1];

  // Taille de l'étoile selon le mode actif
  const starSizeMap = { small: 'w-3 h-3', medium: 'w-4 h-4', large: 'w-5 h-5' };
  const currentStarSize = starSizeMap[symbolSize] || 'w-4 h-4';

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="relative group"
        style={{
          width: '36px',
          height: '36px',
          borderRadius: '10px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          backgroundColor: isOpen ? '#000000' : '#FFFFFF',
          border: 'none',
          cursor: 'pointer',
          transition: 'all 100ms ease',
        }}
        onMouseEnter={(e) => {
          if (!isOpen) e.currentTarget.style.backgroundColor = '#EFEFEF';
        }}
        onMouseLeave={(e) => {
          if (!isOpen) e.currentTarget.style.backgroundColor = '#FFFFFF';
        }}
      >
        {/* Une seule étoile dont la taille varie */}
        <Star 
          className={currentStarSize}
          style={{ 
            color: isOpen ? '#FFFFFF' : '#000000',
            fill: isOpen ? '#FFFFFF' : '#000000',
          }}
        />
        
        {!isOpen && (
          <div
            className="absolute top-full mt-2 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity whitespace-nowrap"
            style={{
              backgroundColor: '#000000',
              color: '#FFFFFF',
              fontSize: '11px',
              padding: '5px 8px',
              borderRadius: '6px',
              zIndex: 300,
            }}
          >
            Taille symboles
          </div>
        )}
      </button>

      {/* Dropdown vertical - icônes uniquement, pas de texte */}
      {isOpen && (
        <>
          {/* Overlay pour fermer */}
          <div 
            className="fixed inset-0 z-[199]" 
            onClick={() => setIsOpen(false)}
          />
          
          <div
            className="absolute z-[200]"
            style={{
              top: 'calc(100% + 6px)',
              left: '50%',
              transform: 'translateX(-50%)',
              backgroundColor: '#FFFFFF',
              borderRadius: '10px',
              boxShadow: '0 4px 20px rgba(0,0,0,0.15)',
              padding: '6px',
              animation: 'fadeSlideIn 120ms ease-out',
            }}
          >
            {SYMBOL_SIZES.map((size) => {
              const isActiveSize = symbolSize === size.id;
              const sizeClass = starSizeMap[size.id];
              
              return (
                <button
                  key={size.id}
                  onClick={() => {
                    onSymbolSizeChange?.(size.id);
                    setIsOpen(false);
                  }}
                  style={{
                    width: '36px',
                    height: '36px',
                    borderRadius: '8px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    backgroundColor: isActiveSize ? '#000000' : '#FFFFFF',
                    border: 'none',
                    cursor: 'pointer',
                    transition: 'all 100ms ease',
                    marginBottom: '2px',
                  }}
                  onMouseEnter={(e) => {
                    if (!isActiveSize) e.currentTarget.style.backgroundColor = '#EFEFEF';
                  }}
                  onMouseLeave={(e) => {
                    if (!isActiveSize) e.currentTarget.style.backgroundColor = '#FFFFFF';
                  }}
                >
                  <Star 
                    className={sizeClass}
                    style={{ 
                      color: isActiveSize ? '#FFFFFF' : '#000000',
                      fill: isActiveSize ? '#FFFFFF' : '#000000',
                    }}
                  />
                </button>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
}

export default function DisplayFloatingPalette({ 
  isOpen, 
  hasGrid = false,
  // États d'affichage
  showGrid = true,
  showSymbols = true,
  showColors = true,
  showBackgroundImg = false,
  showOverlayOriginal = false,
  themeDark = false,
  symbolSize = 'medium',
  autoZoomEnabled = false,
  // Handlers
  onToggleGrid,
  onToggleSymbols,
  onToggleColors,
  onToggleBackgroundImg,
  onToggleOverlayOriginal,
  onToggleTheme,
  onAutoZoom,
  onCenterView,
  onAddFavorite,
  onSymbolSizeChange,
  onClose 
}) {
  if (!isOpen) return null;

  // Map des états pour simplifier
  const stateMap = {
    showGrid,
    showSymbols,
    showColors,
    showBackgroundImg,
    showOverlayOriginal,
  };

  const toggleMap = {
    showGrid: onToggleGrid,
    showSymbols: onToggleSymbols,
    showColors: onToggleColors,
    showBackgroundImg: onToggleBackgroundImg,
    showOverlayOriginal: onToggleOverlayOriginal,
  };

  return (
    <div
      className="absolute z-[200]"
      style={{
        top: 'calc(100% + 10px)',
        left: '50%',
        transform: 'translateX(-50%)',
        animation: 'fadeSlideIn 120ms ease-out',
      }}
    >
      <div
        className="flex items-center gap-1 px-2"
        style={{
          height: '52px',
          backgroundColor: '#FFFFFF',
          borderRadius: '10px',
          boxShadow: '0 4px 20px rgba(0,0,0,0.15)',
          padding: '6px 8px',
        }}
      >
        {/* Options d'affichage ON/OFF */}
        {DISPLAY_TOGGLES.map((option) => {
          const Icon = option.icon;
          const isActive = stateMap[option.id];
          const handler = toggleMap[option.id];
          
          return (
            <button
              key={option.id}
              onClick={() => {
                handler?.();
                toast.success(`${option.label} ${isActive ? 'désactivé' : 'activé'}`);
              }}
              disabled={!hasGrid}
              className="relative group"
              style={{
                width: '36px',
                height: '36px',
                borderRadius: '10px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                backgroundColor: isActive ? '#000000' : '#FFFFFF',
                border: 'none',
                cursor: hasGrid ? 'pointer' : 'not-allowed',
                opacity: hasGrid ? 1 : 0.4,
                transition: 'all 100ms ease',
                transform: 'scale(1)',
              }}
              onMouseDown={(e) => hasGrid && (e.currentTarget.style.transform = 'scale(0.95)')}
              onMouseUp={(e) => e.currentTarget.style.transform = 'scale(1)'}
              onMouseEnter={(e) => {
                if (!isActive && hasGrid) e.currentTarget.style.backgroundColor = '#EFEFEF';
              }}
              onMouseLeave={(e) => {
                if (!isActive) e.currentTarget.style.backgroundColor = '#FFFFFF';
                e.currentTarget.style.transform = 'scale(1)';
              }}
            >
              <Icon 
                className="w-5 h-5" 
                style={{ color: isActive ? '#FFFFFF' : '#000000' }}
                strokeWidth={1.8}
              />
              
              {/* Tooltip */}
              <div
                className="absolute top-full mt-2 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity whitespace-nowrap"
                style={{
                  backgroundColor: '#000000',
                  color: '#FFFFFF',
                  fontSize: '11px',
                  padding: '5px 8px',
                  borderRadius: '6px',
                  zIndex: 300,
                }}
              >
                {option.label} {isActive ? '(ON)' : '(OFF)'}
              </div>
            </button>
          );
        })}

        {/* Séparateur */}
        <div style={{ width: '1px', height: '28px', backgroundColor: '#E0E0E0', margin: '0 4px' }} />

        {/* Mode Nuit/Jour */}
        <button
          onClick={() => {
            onToggleTheme?.();
            toast.success(themeDark ? 'Mode clair activé' : 'Mode nuit activé');
          }}
          className="relative group"
          style={{
            width: '36px',
            height: '36px',
            borderRadius: '10px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            backgroundColor: themeDark ? '#000000' : '#FFFFFF',
            border: 'none',
            cursor: 'pointer',
            transition: 'all 100ms ease',
            transform: 'scale(1)',
          }}
          onMouseDown={(e) => e.currentTarget.style.transform = 'scale(0.95)'}
          onMouseUp={(e) => e.currentTarget.style.transform = 'scale(1)'}
          onMouseEnter={(e) => {
            if (!themeDark) e.currentTarget.style.backgroundColor = '#EFEFEF';
          }}
          onMouseLeave={(e) => {
            if (!themeDark) e.currentTarget.style.backgroundColor = '#FFFFFF';
            e.currentTarget.style.transform = 'scale(1)';
          }}
        >
          {themeDark ? (
            <Sun className="w-5 h-5" style={{ color: '#FFFFFF' }} strokeWidth={1.8} />
          ) : (
            <Moon className="w-5 h-5" style={{ color: '#000000' }} strokeWidth={1.8} />
          )}
          
          <div
            className="absolute top-full mt-2 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity whitespace-nowrap"
            style={{
              backgroundColor: '#000000',
              color: '#FFFFFF',
              fontSize: '11px',
              padding: '5px 8px',
              borderRadius: '6px',
              zIndex: 300,
            }}
          >
            {themeDark ? 'Mode clair' : 'Mode nuit'}
          </div>
        </button>

        {/* Zoom Auto */}
        <button
          onClick={() => {
            onAutoZoom?.();
            toast.success(autoZoomEnabled ? 'Auto-zoom désactivé' : 'Auto-zoom activé');
          }}
          disabled={!hasGrid}
          className="relative group"
          style={{
            width: '36px',
            height: '36px',
            borderRadius: '10px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            backgroundColor: autoZoomEnabled ? '#000000' : '#FFFFFF',
            border: 'none',
            cursor: hasGrid ? 'pointer' : 'not-allowed',
            opacity: hasGrid ? 1 : 0.4,
            transition: 'all 100ms ease',
            transform: 'scale(1)',
          }}
          onMouseDown={(e) => hasGrid && (e.currentTarget.style.transform = 'scale(0.95)')}
          onMouseUp={(e) => e.currentTarget.style.transform = 'scale(1)'}
          onMouseEnter={(e) => {
            if (!autoZoomEnabled && hasGrid) e.currentTarget.style.backgroundColor = '#EFEFEF';
          }}
          onMouseLeave={(e) => {
            if (!autoZoomEnabled) e.currentTarget.style.backgroundColor = '#FFFFFF';
            e.currentTarget.style.transform = 'scale(1)';
          }}
        >
          <div className="relative">
            <ZoomIn className="w-5 h-5" style={{ color: autoZoomEnabled ? '#FFFFFF' : '#000000' }} strokeWidth={1.8} />
            <span 
              style={{ 
                position: 'absolute', 
                bottom: '-2px', 
                right: '-4px', 
                fontSize: '8px', 
                fontWeight: 'bold',
                color: autoZoomEnabled ? '#FFFFFF' : '#000000'
              }}
            >
              A
            </span>
          </div>
          
          <div
            className="absolute top-full mt-2 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity whitespace-nowrap"
            style={{
              backgroundColor: '#000000',
              color: '#FFFFFF',
              fontSize: '11px',
              padding: '5px 8px',
              borderRadius: '6px',
              zIndex: 300,
            }}
          >
            Zoom automatique {autoZoomEnabled ? '(ON)' : '(OFF)'}
          </div>
        </button>

        {/* Centrer la vue */}
        <button
          onClick={() => {
            onCenterView?.();
            toast.success('Vue centrée sur la grille');
          }}
          disabled={!hasGrid}
          className="relative group"
          style={{
            width: '36px',
            height: '36px',
            borderRadius: '10px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            backgroundColor: '#FFFFFF',
            border: 'none',
            cursor: hasGrid ? 'pointer' : 'not-allowed',
            opacity: hasGrid ? 1 : 0.4,
            transition: 'all 100ms ease',
            transform: 'scale(1)',
          }}
          onMouseDown={(e) => hasGrid && (e.currentTarget.style.transform = 'scale(0.95)')}
          onMouseUp={(e) => e.currentTarget.style.transform = 'scale(1)'}
          onMouseEnter={(e) => hasGrid && (e.currentTarget.style.backgroundColor = '#EFEFEF')}
          onMouseLeave={(e) => {
            e.currentTarget.style.backgroundColor = '#FFFFFF';
            e.currentTarget.style.transform = 'scale(1)';
          }}
        >
          <Crosshair className="w-5 h-5" style={{ color: '#000000' }} strokeWidth={1.8} />
          
          <div
            className="absolute top-full mt-2 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity whitespace-nowrap"
            style={{
              backgroundColor: '#000000',
              color: '#FFFFFF',
              fontSize: '11px',
              padding: '5px 8px',
              borderRadius: '6px',
              zIndex: 300,
            }}
          >
            Centrer la grille
          </div>
        </button>

        {/* Favori / Marque-page */}
        <button
          onClick={() => {
            onAddFavorite?.();
            toast.success('Favori ajouté');
          }}
          disabled={!hasGrid}
          className="relative group"
          style={{
            width: '36px',
            height: '36px',
            borderRadius: '10px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            backgroundColor: '#FFFFFF',
            border: 'none',
            cursor: hasGrid ? 'pointer' : 'not-allowed',
            opacity: hasGrid ? 1 : 0.4,
            transition: 'all 100ms ease',
            transform: 'scale(1)',
          }}
          onMouseDown={(e) => hasGrid && (e.currentTarget.style.transform = 'scale(0.95)')}
          onMouseUp={(e) => e.currentTarget.style.transform = 'scale(1)'}
          onMouseEnter={(e) => hasGrid && (e.currentTarget.style.backgroundColor = '#EFEFEF')}
          onMouseLeave={(e) => {
            e.currentTarget.style.backgroundColor = '#FFFFFF';
            e.currentTarget.style.transform = 'scale(1)';
          }}
        >
          <Bookmark className="w-5 h-5" style={{ color: '#000000' }} strokeWidth={1.8} />
          
          <div
            className="absolute top-full mt-2 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity whitespace-nowrap"
            style={{
              backgroundColor: '#000000',
              color: '#FFFFFF',
              fontSize: '11px',
              padding: '5px 8px',
              borderRadius: '6px',
              zIndex: 300,
            }}
          >
            Ajouter un favori
          </div>
        </button>

        {/* Séparateur */}
        <div style={{ width: '1px', height: '28px', backgroundColor: '#E0E0E0', margin: '0 4px' }} />

        {/* Taille symboles - Une seule étoile avec dropdown vertical */}
        <SymbolSizeDropdown 
          symbolSize={symbolSize} 
          onSymbolSizeChange={onSymbolSizeChange} 
        />
      </div>

      <style>{`
        @keyframes fadeSlideIn {
          from {
            opacity: 0;
            transform: translateX(-50%) translateY(-4px);
          }
          to {
            opacity: 1;
            transform: translateX(-50%) translateY(0);
          }
        }
      `}</style>
    </div>
  );
}