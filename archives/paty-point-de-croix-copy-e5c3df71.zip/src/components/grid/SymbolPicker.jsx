import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Search, Star, Grid3x3 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { SYMBOL_CATEGORIES, POPULAR_SYMBOLS } from './SymbolLibrary';

export default function SymbolPicker({ selectedSymbol, onSymbolSelect }) {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredSymbols = () => {
    if (!searchQuery) return null;
    
    const results = [];
    Object.entries(SYMBOL_CATEGORIES).forEach(([categoryName, subcategories]) => {
      Object.entries(subcategories).forEach(([subName, symbols]) => {
        const matches = symbols.filter(s => 
          s.toLowerCase().includes(searchQuery.toLowerCase())
        );
        if (matches.length > 0) {
          results.push(...matches);
        }
      });
    });
    return results;
  };

  const searchResults = filteredSymbols();

  return (
    <Card className="bg-white rounded-2xl shadow-lg border border-slate-200">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-semibold text-slate-700 uppercase tracking-wide flex items-center gap-2">
          <Grid3x3 className="w-4 h-4" />
          Symboles
        </CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Recherche */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input
            placeholder="Rechercher un symbole..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9 h-9 text-sm"
          />
        </div>

        {/* Résultats de recherche */}
        {searchResults && searchResults.length > 0 ? (
          <div className="border border-slate-200 rounded-lg p-3 max-h-[400px] overflow-y-auto">
            <div className="text-xs font-medium text-slate-600 mb-2">
              {searchResults.length} résultat{searchResults.length > 1 ? 's' : ''}
            </div>
            <div className="grid grid-cols-8 gap-1">
              {searchResults.map((symbol, idx) => (
                <button
                  key={idx}
                  onClick={() => onSymbolSelect(symbol)}
                  className={cn(
                    "w-9 h-9 flex items-center justify-center rounded border-2 transition-all hover:border-slate-400 text-lg font-medium",
                    selectedSymbol === symbol
                      ? "border-slate-800 bg-slate-100"
                      : "border-slate-200"
                  )}
                  title={symbol}
                >
                  {symbol}
                </button>
              ))}
            </div>
          </div>
        ) : searchQuery && searchResults?.length === 0 ? (
          <div className="text-center py-8 text-sm text-slate-500">
            Aucun symbole trouvé
          </div>
        ) : (
          <Tabs defaultValue="popular" className="w-full">
            <TabsList className="grid w-full grid-cols-3 h-9">
              <TabsTrigger value="popular" className="text-xs">
                <Star className="w-3 h-3 mr-1" />
                Populaires
              </TabsTrigger>
              <TabsTrigger value="all" className="text-xs">Tous</TabsTrigger>
              <TabsTrigger value="none" className="text-xs">Aucun</TabsTrigger>
            </TabsList>

            {/* Populaires */}
            <TabsContent value="popular" className="mt-3">
              <div className="grid grid-cols-8 gap-1">
                {POPULAR_SYMBOLS.map((symbol, idx) => (
                  <button
                    key={idx}
                    onClick={() => onSymbolSelect(symbol)}
                    className={cn(
                      "w-9 h-9 flex items-center justify-center rounded border-2 transition-all hover:border-slate-400 text-lg font-medium",
                      selectedSymbol === symbol
                        ? "border-slate-800 bg-slate-100"
                        : "border-slate-200"
                    )}
                    title={symbol}
                  >
                    {symbol}
                  </button>
                ))}
              </div>
            </TabsContent>

            {/* Tous les symboles */}
            <TabsContent value="all" className="mt-3 max-h-[500px] overflow-y-auto">
              <div className="space-y-4">
                {Object.entries(SYMBOL_CATEGORIES).map(([categoryName, subcategories]) => (
                  <div key={categoryName}>
                    <div className="text-xs font-semibold text-slate-700 mb-2 uppercase tracking-wider">
                      {categoryName}
                    </div>
                    <div className="space-y-3">
                      {Object.entries(subcategories).map(([subName, symbols]) => (
                        <div key={subName}>
                          <div className="text-xs text-slate-500 mb-1.5">{subName}</div>
                          <div className="grid grid-cols-8 gap-1">
                            {symbols.map((symbol, idx) => (
                              <button
                                key={idx}
                                onClick={() => onSymbolSelect(symbol)}
                                className={cn(
                                  "w-9 h-9 flex items-center justify-center rounded border-2 transition-all hover:border-slate-400 text-lg font-medium",
                                  selectedSymbol === symbol
                                    ? "border-slate-800 bg-slate-100"
                                    : "border-slate-200"
                                )}
                                title={symbol}
                              >
                                {symbol}
                              </button>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>

            {/* Aucun symbole */}
            <TabsContent value="none" className="mt-3">
              <div className="text-center py-8">
                <Button
                  onClick={() => onSymbolSelect(null)}
                  variant={selectedSymbol === null ? "default" : "outline"}
                  className={cn(
                    selectedSymbol === null && "bg-slate-800 hover:bg-slate-700"
                  )}
                >
                  Désélectionner le symbole
                </Button>
                <p className="text-xs text-slate-500 mt-3">
                  Les points n'auront que leur couleur
                </p>
              </div>
            </TabsContent>
          </Tabs>
        )}
      </CardContent>
    </Card>
  );
}