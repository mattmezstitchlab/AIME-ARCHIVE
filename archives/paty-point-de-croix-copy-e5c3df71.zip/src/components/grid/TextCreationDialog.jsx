import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export default function TextCreationDialog({ open, onClose, onConfirm, selectedColor }) {
  const [text, setText] = useState('');
  const [size, setSize] = useState('medium');

  const handleConfirm = () => {
    if (!text.trim()) return;
    
    onConfirm({
      text: text.trim(),
      size,
      color: selectedColor
    });
    
    setText('');
    setSize('medium');
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Ajouter un texte</DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>Texte à afficher</Label>
            <Input
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Entrez votre texte..."
              autoFocus
            />
          </div>

          <div className="space-y-2">
            <Label>Taille</Label>
            <Select value={size} onValueChange={setSize}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="small">Petit</SelectItem>
                <SelectItem value="medium">Moyen</SelectItem>
                <SelectItem value="large">Grand</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Couleur</Label>
            <div className="flex items-center gap-2">
              <div 
                className="w-8 h-8 rounded border-2 border-slate-300"
                style={{ backgroundColor: selectedColor?.hex || '#000000' }}
              />
              <span className="text-sm text-slate-600">
                {selectedColor?.name || 'Couleur active'}
              </span>
            </div>
          </div>
        </div>

        <div className="flex gap-2 justify-end">
          <Button variant="outline" onClick={onClose}>
            Annuler
          </Button>
          <Button onClick={handleConfirm} disabled={!text.trim()}>
            Ajouter le texte
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}