import React from 'react';
import { cn } from '@/lib/utils';

export default function SimplifiedColorPalette({
  colorPalette = [],
  selectedColorId,
  onColorSelect
}) {
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t-2 border-slate-200 shadow-2xl z-[2000] h-[120px]">
      <div className="h-full overflow-x-auto overflow-y-hidden px-4 flex items-center gap-3">
        {colorPalette.map((color) => (
          <button
            key={color.id}
            onClick={() => onColorSelect?.(color.id)}
            className={cn(
              "flex-shrink-0 w-24 h-[100px] rounded-lg transition-all relative overflow-hidden",
              selectedColorId === color.id
                ? "ring-2 ring-slate-400 shadow-lg"
                : "hover:shadow-md"
            )}
            style={{ backgroundColor: color.hex }}
          >
            {/* Symbole en haut dans cartouche blanc */}
            <div className="absolute top-2 left-1/2 -translate-x-1/2 bg-white rounded px-2 py-1 shadow-sm">
              <span className="text-base font-bold text-slate-900">
                {color.assignedSymbolChar || '●'}
              </span>
            </div>

            {/* Nombre de points en bas */}
            <div className="absolute bottom-2 left-0 right-0 flex justify-center">
              <span className="text-xs text-white font-bold drop-shadow-lg">
                {color.totalCount || 0} pts
              </span>
            </div>

            {/* Barre de progression */}
            {color.progress > 0 && (
              <div className="absolute bottom-0 left-0 right-0 h-1.5 bg-white/30">
                <div 
                  className="h-full bg-green-400"
                  style={{ width: `${color.progress}%` }}
                />
              </div>
            )}
          </button>
        ))}
      </div>
    </div>
  );
}