import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { base44 } from '@/api/base44Client';
import { Upload, FileText, Loader2, Sparkles } from 'lucide-react';
import { toast } from 'sonner';
import { detectColors, generateSymbolGrid } from './ColorDetector';
import { SYMBOL_CATEGORIES } from './SymbolLibrary';

export default function ImportPdfDialog({ 
  open, 
  onClose, 
  onImportComplete 
}) {
  const [file, setFile] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [gridSize, setGridSize] = useState(50);
  const [maxColors, setMaxColors] = useState(20);
  const [selectedDpi, setSelectedDpi] = useState(72);

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile && selectedFile.type === 'application/pdf') {
      setFile(selectedFile);
    } else {
      toast.error('Veuillez sélectionner un fichier PDF');
    }
  };

  const handleImport = async () => {
    if (!file) {
      toast.error('Veuillez sélectionner un fichier PDF');
      return;
    }

    setIsProcessing(true);

    try {
      toast.info(`Lecture du PDF... (résolution choisie : ${selectedDpi} dpi)`);

      const pdfjsLib = window['pdfjs-dist/build/pdf'];
      pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';

      const fileReader = new FileReader();
      
      fileReader.onload = async function() {
        try {
          const typedArray = new Uint8Array(this.result);
          
          const pdf = await pdfjsLib.getDocument({ data: typedArray }).promise;
          
          if (pdf.numPages === 0) {
            toast.error('PDF invalide : aucune page trouvée');
            setIsProcessing(false);
            return;
          }

          toast.info(`Conversion de la première page… (résolution : ${selectedDpi} dpi)`);

          const page = await pdf.getPage(1);
          
          // Ajuster l'échelle selon le DPI choisi
          let scale;
          if (selectedDpi === 72) {
            scale = 1.5;
          } else if (selectedDpi === 150) {
            scale = 3.0;
          } else { // 300 dpi
            scale = 6.0;
          }
          
          const viewport = page.getViewport({ scale });
          
          const maxWidth = selectedDpi === 72 ? 1200 : selectedDpi === 150 ? 2000 : 3000;
          const finalScale = viewport.width > maxWidth ? (maxWidth / viewport.width) * scale : scale;
          const finalViewport = page.getViewport({ scale: finalScale });

          const canvas = document.createElement('canvas');
          const context = canvas.getContext('2d');
          canvas.width = finalViewport.width;
          canvas.height = finalViewport.height;

          await page.render({
            canvasContext: context,
            viewport: finalViewport
          }).promise;

          // Qualité JPEG selon DPI
          const jpegQuality = selectedDpi === 72 ? 0.7 : selectedDpi === 150 ? 0.8 : 0.9;
          const imageDataUrl = canvas.toDataURL('image/jpeg', jpegQuality);

          // Maintenant traiter comme une image normale
          toast.info('Pixelisation de l\'image...');
          
          const img = new Image();
          img.onload = async () => {
            try {
              // Calculer les dimensions
              const aspectRatio = img.width / img.height;
              let width, height;
              if (aspectRatio > 1) {
                width = gridSize;
                height = Math.round(gridSize / aspectRatio);
              } else {
                height = gridSize;
                width = Math.round(gridSize * aspectRatio);
              }

              // Calculer la marge blanche (10% de la largeur, minimum 20px)
              const marginSize = Math.max(20, Math.round(width * 0.1));
              const canvasWithMargin = width + (marginSize * 2);
              const canvasWithMarginHeight = height + (marginSize * 2);

              // Créer le canvas pixelisé avec marge blanche
              const pixelCanvas = document.createElement('canvas');
              pixelCanvas.width = canvasWithMargin;
              pixelCanvas.height = canvasWithMarginHeight;
              const pixelCtx = pixelCanvas.getContext('2d');
              
              // Fond blanc
              pixelCtx.fillStyle = '#FFFFFF';
              pixelCtx.fillRect(0, 0, canvasWithMargin, canvasWithMarginHeight);
              
              // Dessiner l'image au centre avec marge
              pixelCtx.imageSmoothingEnabled = false;
              pixelCtx.drawImage(img, marginSize, marginSize, width, height);
              
              // Mettre à jour les dimensions finales
              width = canvasWithMargin;
              height = canvasWithMarginHeight;

              // Détecter les couleurs
              toast.info('Détection des couleurs...');
              const colorPalette = detectColors(pixelCanvas, maxColors);

              colorPalette.forEach(color => {
                color.totalCount = color.count;
                color.doneCount = 0;
                color.progress = 0;
              });

              // Associer les symboles
              toast.info('Association des symboles...');
              const allSymbols = SYMBOL_CATEGORIES.flatMap(cat => cat.symbols);
              colorPalette.forEach((color, index) => {
                const symbol = allSymbols[index % allSymbols.length];
                color.assignedSymbolId = symbol.id;
                color.assignedSymbolChar = symbol.char;
              });

              // Générer la grille
              const symbolGrid = generateSymbolGrid(pixelCanvas, colorPalette);

              // Nettoyer la mémoire
              canvas.width = 0;
              canvas.height = 0;

              toast.success('Première page du PDF extraite. Recadrez avant génération.');

              // Au lieu de générer directement, ouvrir le dialog de recadrage
              // Passer par le parent pour ouvrir CropDialog
              onImportComplete({
                width,
                height,
                sourceImage: imageDataUrl,
                colorPalette,
                symbolGrid,
                needsCrop: true // Flag pour indiquer qu'il faut recadrer
              });

              handleClose();

            } catch (error) {
              console.error('Erreur traitement:', error);
              toast.error('Erreur lors du traitement de l\'image');
              setIsProcessing(false);
            }
          };

          img.onerror = () => {
            toast.error('Erreur lors du chargement de l\'image');
            setIsProcessing(false);
          };

          img.src = imageDataUrl;

        } catch (error) {
          console.error('Erreur conversion:', error);
          toast.error('Impossible de convertir la première page du PDF');
          setIsProcessing(false);
        }
      };

      fileReader.onerror = () => {
        toast.error('Erreur lors de la lecture du fichier PDF');
        setIsProcessing(false);
      };

      fileReader.readAsArrayBuffer(file);

    } catch (error) {
      console.error('Erreur extraction PDF:', error);
      toast.error('Erreur lors de l\'extraction de la couverture');
      setIsProcessing(false);
    }
  };

  const handleClose = () => {
    setFile(null);
    setIsProcessing(false);
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-purple-600" />
            Importer la première page d'un PDF
          </DialogTitle>
          <DialogDescription>
            Conversion automatique en motif de point de croix
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Upload */}
          <div className="space-y-2">
            <Label className="text-sm font-medium">Fichier PDF</Label>
            <div className="border-2 border-dashed border-slate-300 rounded-xl p-6 hover:border-slate-400 transition-colors">
              <Input
                type="file"
                accept=".pdf"
                onChange={handleFileChange}
                className="hidden"
                id="pdf-upload"
              />
              <label htmlFor="pdf-upload" className="flex flex-col items-center gap-3 cursor-pointer">
                <FileText className="w-12 h-12 text-slate-400" />
                <div className="text-center">
                  <p className="text-sm font-medium text-slate-700">
                    {file ? file.name : 'Cliquez pour sélectionner un PDF'}
                  </p>
                  <p className="text-xs text-slate-500 mt-1">
                    La première page sera extraite et convertie
                  </p>
                </div>
              </label>
            </div>
          </div>

          {/* Sélection de résolution */}
          {file && !isProcessing && (
            <div className="space-y-3">
              <Label className="text-sm font-medium">Choisissez la résolution d'import de la première page :</Label>
              <div className="grid gap-2">
                <button
                  onClick={() => setSelectedDpi(72)}
                  className={`p-4 rounded-lg border-2 transition-all text-left ${
                    selectedDpi === 72 
                      ? 'border-purple-600 bg-purple-50' 
                      : 'border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-semibold text-slate-900">72 dpi (Rapide, recommandé)</p>
                      <p className="text-xs text-slate-600 mt-1">Qualité 70% • Import rapide</p>
                    </div>
                    {selectedDpi === 72 && (
                      <div className="w-5 h-5 rounded-full bg-purple-600 flex items-center justify-center">
                        <div className="w-2 h-2 rounded-full bg-white" />
                      </div>
                    )}
                  </div>
                </button>

                <button
                  onClick={() => setSelectedDpi(150)}
                  className={`p-4 rounded-lg border-2 transition-all text-left ${
                    selectedDpi === 150 
                      ? 'border-purple-600 bg-purple-50' 
                      : 'border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-semibold text-slate-900">150 dpi (Qualité moyenne)</p>
                      <p className="text-xs text-slate-600 mt-1">Qualité 80% • Équilibre qualité/vitesse</p>
                    </div>
                    {selectedDpi === 150 && (
                      <div className="w-5 h-5 rounded-full bg-purple-600 flex items-center justify-center">
                        <div className="w-2 h-2 rounded-full bg-white" />
                      </div>
                    )}
                  </div>
                </button>

                <button
                  onClick={() => setSelectedDpi(300)}
                  className={`p-4 rounded-lg border-2 transition-all text-left ${
                    selectedDpi === 300 
                      ? 'border-purple-600 bg-purple-50' 
                      : 'border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-semibold text-slate-900">300 dpi (Haute qualité, plus long)</p>
                      <p className="text-xs text-slate-600 mt-1">Qualité 90% • Meilleure résolution</p>
                    </div>
                    {selectedDpi === 300 && (
                      <div className="w-5 h-5 rounded-full bg-purple-600 flex items-center justify-center">
                        <div className="w-2 h-2 rounded-full bg-white" />
                      </div>
                    )}
                  </div>
                </button>
              </div>
            </div>
          )}

          {/* Paramètres */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="gridSize" className="text-sm font-medium">
                Taille maximale
              </Label>
              <Input
                id="gridSize"
                type="number"
                min={20}
                max={500}
                value={gridSize}
                onChange={(e) => setGridSize(parseInt(e.target.value) || 50)}
                disabled={isProcessing}
                className="h-10"
              />
              <p className="text-xs text-slate-500">Dimension max (proportions préservées)</p>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="maxColors" className="text-sm font-medium">
                Nombre de couleurs
              </Label>
              <Input
                id="maxColors"
                type="number"
                min={3}
                max={90}
                value={maxColors}
                onChange={(e) => setMaxColors(parseInt(e.target.value) || 90)}
                disabled={isProcessing}
                className="h-10"
              />
              <p className="text-xs text-slate-500">Maximum de couleurs détectées</p>
            </div>
          </div>

          {/* État de traitement */}
          {isProcessing && (
            <div className="flex items-center gap-3 bg-blue-50 border border-blue-200 rounded-lg p-4">
              <Loader2 className="w-5 h-5 animate-spin text-blue-600" />
              <div>
                <p className="font-medium text-blue-900">Traitement en cours...</p>
                <p className="text-sm text-blue-700">
                  Extraction et conversion automatique...
                </p>
              </div>
            </div>
          )}

          <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
            <p className="text-sm text-purple-900">
              <strong>Import automatique :</strong> La première page du PDF sera convertie en JPEG 
              et traitée exactement comme une image normale. Grille générée automatiquement.
            </p>
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button 
            variant="outline" 
            onClick={handleClose} 
            disabled={isProcessing}
          >
            Annuler
          </Button>
          <Button
            onClick={handleImport}
            disabled={!file || isProcessing}
            className="bg-purple-600 hover:bg-purple-700"
          >
            {isProcessing ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Traitement en cours...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 mr-2" />
                Générer le motif
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}