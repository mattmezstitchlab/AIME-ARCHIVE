import React, { useState, useMemo, useRef, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import {
  FolderOpen,
  Calendar,
  Clock,
  CheckCircle,
  PlayCircle,
  MoreVertical,
  Eye,
  Pencil,
  Trash2,
  Type,
  Loader2,
  X,
  AlertTriangle,
  Grid3X3,
  ExternalLink
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { toast } from 'sonner';
import ProjectPreviewDialog from './ProjectPreviewDialog';

const FILTERS = [
  { id: 'recent', label: 'Plus récent', icon: Clock },
  { id: 'date', label: 'Par date', icon: Calendar },
  { id: 'in_progress', label: 'En cours', icon: PlayCircle },
  { id: 'completed', label: 'Terminé', icon: CheckCircle },
];

// Composant miniature pour afficher un aperçu du projet
function ProjectThumbnail({ project, size = 80 }) {
  const canvasRef = useRef(null);

  useEffect(() => {
    if (!canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const pattern = project.pattern;

    ctx.fillStyle = '#1a1a1a';
    ctx.fillRect(0, 0, size, size);

    // Si on a une image source, l'afficher
    if (pattern?.source_image) {
      const img = new Image();
      img.onload = () => {
        ctx.drawImage(img, 0, 0, size, size);
      };
      img.src = pattern.source_image;
      return;
    }

    if (!pattern?.symbolGrid) {
      ctx.fillStyle = '#333';
      ctx.font = `${size/3}px sans-serif`;
      ctx.textAlign = 'center';
      ctx.fillText('?', size/2, size/2 + size/8);
      return;
    }

    const grid = pattern.symbolGrid;
    const rows = grid.length;
    const cols = grid[0]?.length || 0;
    if (rows === 0 || cols === 0) return;

    const cellSize = Math.min(size / cols, size / rows, 4);
    const offsetX = (size - cols * cellSize) / 2;
    const offsetY = (size - rows * cellSize) / 2;

    for (let row = 0; row < rows; row++) {
      for (let col = 0; col < cols; col++) {
        const cell = grid[row]?.[col];
        if (cell?.color) {
          ctx.fillStyle = cell.color;
          ctx.fillRect(
            offsetX + col * cellSize,
            offsetY + row * cellSize,
            cellSize,
            cellSize
          );
        }
      }
    }
  }, [project, size]);

  return (
    <canvas
      ref={canvasRef}
      width={size}
      height={size}
      className="rounded-lg flex-shrink-0"
    />
  );
}

// Calcul du statut du projet
function getProjectStatus(project) {
  const grid = project.pattern?.symbolGrid;
  if (!grid) return null;
  const total = grid.flat().filter(c => c).length;
  const done = grid.flat().filter(c => c?.done).length;
  if (total === 0) return null;
  if (done === total) return 'completed';
  return 'in_progress';
}

export default function ProjectsFullModal({ open, onClose, activeFilter, setActiveFilter }) {
  const [renameId, setRenameId] = useState(null);
  const [renameValue, setRenameValue] = useState('');
  const [previewProject, setPreviewProject] = useState(null);
  const [deleteProject, setDeleteProject] = useState(null);
  const queryClient = useQueryClient();

  // Charger les projets
  const { data: projects = [], isLoading } = useQuery({
    queryKey: ['grids'],
    queryFn: () => base44.entities.Grid.list('-updated_date'),
    enabled: open,
  });

  // Mutation pour supprimer
  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Grid.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['grids'] });
      toast.success('Projet supprimé');
    },
  });

  // Mutation pour renommer
  const renameMutation = useMutation({
    mutationFn: ({ id, name }) => base44.entities.Grid.update(id, { name }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['grids'] });
      toast.success('Projet renommé');
      setRenameId(null);
    },
  });

  // Filtrer et trier les projets
  const filteredProjects = useMemo(() => {
    let result = [...projects];

    switch (activeFilter) {
      case 'recent':
        result.sort((a, b) => new Date(b.updated_date) - new Date(a.updated_date));
        break;
      case 'date':
        result.sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
        break;
      case 'in_progress':
        result = result.filter(p => {
          const grid = p.pattern?.symbolGrid;
          if (!grid) return true;
          const total = grid.flat().filter(c => c).length;
          const done = grid.flat().filter(c => c?.done).length;
          return done < total;
        });
        break;
      case 'completed':
        result = result.filter(p => {
          const grid = p.pattern?.symbolGrid;
          if (!grid) return false;
          const total = grid.flat().filter(c => c).length;
          const done = grid.flat().filter(c => c?.done).length;
          return total > 0 && done === total;
        });
        break;
    }

    return result;
  }, [projects, activeFilter]);

  const handleRename = (project) => {
    setRenameId(project.id);
    setRenameValue(project.name || '');
  };

  const submitRename = () => {
    if (renameId && renameValue.trim()) {
      renameMutation.mutate({ id: renameId, name: renameValue.trim() });
    }
  };

  const handleDelete = (project) => {
    setDeleteProject(project);
  };

  const confirmDelete = () => {
    if (deleteProject) {
      deleteMutation.mutate(deleteProject.id);
      setDeleteProject(null);
    }
  };

  const handleView = (project) => {
    setPreviewProject(project);
  };

  const handleEdit = (project) => {
    localStorage.setItem('loadProjectId', project.id);
    window.location.reload();
  };

  if (!open) return null;

  return (
    <>
      {/* Dialog de confirmation de suppression */}
      <AlertDialog open={!!deleteProject} onOpenChange={() => setDeleteProject(null)}>
        <AlertDialogContent className="bg-[#1a1a1a] border-[#333]">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-white flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-red-500" />
              Supprimer ce projet ?
            </AlertDialogTitle>
            <AlertDialogDescription className="text-gray-400">
              Le projet "{deleteProject?.name || 'Sans titre'}" sera définitivement supprimé.
              Cette action est irréversible.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-white/10 text-white border-0 hover:bg-white/20">
              Annuler
            </AlertDialogCancel>
            <AlertDialogAction 
              onClick={confirmDelete}
              className="bg-red-600 text-white hover:bg-red-700"
            >
              Supprimer
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Dialog d'aperçu */}
      <ProjectPreviewDialog
        project={previewProject}
        open={!!previewProject}
        onClose={() => setPreviewProject(null)}
      />

      {/* Modale plein écran */}
      <div className="fixed inset-0 z-[500] flex items-center justify-center">
        {/* Fond sombre */}
        <div 
          className="absolute inset-0 bg-black/70 backdrop-blur-sm"
          onClick={onClose}
        />

        {/* Contenu de la modale */}
        <div 
          className="relative bg-[#111] rounded-2xl shadow-2xl border border-[#333] overflow-hidden flex flex-col"
          style={{ width: '900px', maxWidth: '95vw', maxHeight: '85vh' }}
        >
          {/* Header */}
          <div className="px-6 py-4 border-b border-[#333] flex items-center justify-between flex-shrink-0 bg-gradient-to-r from-[#FFC94A]/10 to-transparent">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#FFC94A] to-[#F97316] flex items-center justify-center">
                <FolderOpen className="w-5 h-5 text-black" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-white">Mes Projets</h2>
                <p className="text-xs text-gray-400">{projects.length} projet{projects.length > 1 ? 's' : ''}</p>
              </div>
            </div>
            <button 
              onClick={onClose}
              className="p-2 hover:bg-white/10 rounded-lg transition-colors"
            >
              <X className="w-5 h-5 text-gray-400" />
            </button>
          </div>

          {/* Filtres */}
          <div className="px-6 py-3 border-b border-[#333] flex gap-2 overflow-x-auto flex-shrink-0">
            {FILTERS.map(filter => (
              <button
                key={filter.id}
                onClick={() => setActiveFilter(filter.id)}
                className={`px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap flex items-center gap-2 transition-colors ${
                  activeFilter === filter.id
                    ? 'bg-[#FFC94A] text-black'
                    : 'bg-white/5 text-gray-300 hover:bg-white/10'
                }`}
              >
                <filter.icon className="w-4 h-4" />
                {filter.label}
              </button>
            ))}
          </div>

          {/* Grille des projets */}
          <div className="flex-1 overflow-y-auto p-6">
            {isLoading ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="w-8 h-8 animate-spin text-[#FFC94A]" />
              </div>
            ) : filteredProjects.length === 0 ? (
              <div className="text-center py-12">
                <Grid3X3 className="w-16 h-16 mx-auto mb-4 text-gray-600" />
                <p className="text-gray-400">Aucun projet trouvé</p>
                <p className="text-xs text-gray-500 mt-1">Importez une image pour commencer</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {filteredProjects.map(project => {
                  const status = getProjectStatus(project);
                  
                  return (
                    <div
                      key={project.id}
                      className="bg-[#1a1a1a] rounded-xl border border-[#333] overflow-hidden hover:border-[#FFC94A]/50 transition-all cursor-pointer group"
                      onClick={() => handleEdit(project)}
                    >
                      {/* Vignette */}
                      <div className="aspect-square bg-[#222] flex items-center justify-center overflow-hidden relative">
                        {project.pattern?.source_image ? (
                          <img 
                            src={project.pattern.source_image} 
                            alt={project.name}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                          />
                        ) : (
                          <ProjectThumbnail project={project} size={150} />
                        )}
                        
                        {/* Overlay au hover */}
                        <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                          <div className="px-4 py-2 bg-[#FFC94A] rounded-lg text-black text-sm font-semibold flex items-center gap-2">
                            <Pencil className="w-4 h-4" />
                            Modifier
                          </div>
                        </div>

                        {/* Badge statut */}
                        {status && (
                          <div className="absolute top-2 right-2">
                            {status === 'completed' ? (
                              <span className="px-2 py-1 bg-green-500/90 text-white text-[10px] font-medium rounded-full flex items-center gap-1">
                                <CheckCircle className="w-3 h-3" />
                                Terminé
                              </span>
                            ) : (
                              <span className="px-2 py-1 bg-blue-500/90 text-white text-[10px] font-medium rounded-full flex items-center gap-1">
                                <PlayCircle className="w-3 h-3" />
                                En cours
                              </span>
                            )}
                          </div>
                        )}
                      </div>

                      {/* Infos */}
                      <div className="p-3">
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0 flex-1">
                            {renameId === project.id ? (
                              <input
                                type="text"
                                value={renameValue}
                                onChange={(e) => setRenameValue(e.target.value)}
                                onBlur={submitRename}
                                onKeyDown={(e) => {
                                  if (e.key === 'Enter') submitRename();
                                  if (e.key === 'Escape') setRenameId(null);
                                }}
                                onClick={(e) => e.stopPropagation()}
                                className="w-full bg-white/10 border border-[#FFC94A] rounded px-2 py-1 text-sm text-white focus:outline-none"
                                autoFocus
                              />
                            ) : (
                              <h4 className="text-sm font-medium text-white truncate">
                                {project.name || 'Sans titre'}
                              </h4>
                            )}
                            <p className="text-xs text-gray-500 mt-1">
                              {new Date(project.updated_date).toLocaleDateString('fr-FR', {
                                day: 'numeric',
                                month: 'short',
                                year: 'numeric'
                              })}
                            </p>
                          </div>

                          {/* Menu actions */}
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <button 
                                onClick={(e) => e.stopPropagation()}
                                className="p-1.5 hover:bg-white/10 rounded-lg transition-colors"
                              >
                                <MoreVertical className="w-4 h-4 text-gray-400" />
                              </button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent 
                              align="end" 
                              className="w-44 bg-[#222] border-[#444] rounded-lg z-[600]"
                            >
                              <DropdownMenuItem
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleView(project);
                                }}
                                className="text-white hover:bg-white/10 cursor-pointer"
                              >
                                <Eye className="w-4 h-4 mr-2 text-blue-400" />
                                Afficher
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleEdit(project);
                                }}
                                className="text-white hover:bg-white/10 cursor-pointer"
                              >
                                <Pencil className="w-4 h-4 mr-2 text-green-400" />
                                Modifier
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleRename(project);
                                }}
                                className="text-white hover:bg-white/10 cursor-pointer"
                              >
                                <Type className="w-4 h-4 mr-2 text-yellow-400" />
                                Renommer
                              </DropdownMenuItem>
                              <DropdownMenuSeparator className="bg-[#444]" />
                              <DropdownMenuItem
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleDelete(project);
                                }}
                                className="text-red-400 hover:bg-red-500/10 cursor-pointer"
                              >
                                <Trash2 className="w-4 h-4 mr-2" />
                                Supprimer
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
}