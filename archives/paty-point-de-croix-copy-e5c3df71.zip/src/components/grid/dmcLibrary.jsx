// Bibliothèque DMC interne - Nuancier complet des fils à broder DMC
// Format : { code, name, rgb: [r, g, b], category }

export const DMC_LIBRARY = [
  // Blancs et écrus
  { code: 'B5200', name: 'Blanc pur', rgb: [255, 255, 255], hex: '#FFFFFF', family: 'white' },
  { code: 'Ecru', name: 'Écru', rgb: [240, 234, 218], hex: '#F0EADA', family: 'white' },
  
  // Rouges
  { code: '304', name: 'Rouge moyen', rgb: [177, 13, 58], hex: '#B10D3A', family: 'red' },
  { code: '321', name: 'Rouge', rgb: [199, 30, 60], hex: '#C71E3C', family: 'red' },
  { code: '498', name: 'Rouge foncé', rgb: [167, 17, 43], hex: '#A7112B', family: 'red' },
  { code: '666', name: 'Rouge vif', rgb: [227, 36, 43], hex: '#E3242B', family: 'red' },
  { code: '815', name: 'Grenat moyen', rgb: [131, 14, 42], hex: '#830E2A', family: 'red' },
  
  // Roses
  { code: '3326', name: 'Rose clair', rgb: [255, 157, 150], hex: '#FF9D96', family: 'pink' },
  { code: '3708', name: 'Rose melon', rgb: [254, 164, 189], hex: '#FEA4BD', family: 'pink' },
  { code: '3706', name: 'Rose melon moyen', rgb: [255, 140, 174], hex: '#FF8CAE', family: 'pink' },
  { code: '3705', name: 'Rose melon foncé', rgb: [255, 111, 149], hex: '#FF6F95', family: 'pink' },
  
  // Oranges
  { code: '740', name: 'Tangerine', rgb: [255, 143, 0], hex: '#FF8F00', family: 'orange' },
  { code: '741', name: 'Tangerine moyen', rgb: [255, 163, 43], hex: '#FFA32B', family: 'orange' },
  { code: '742', name: 'Tangerine clair', rgb: [255, 184, 77], hex: '#FFB84D', family: 'orange' },
  { code: '970', name: 'Citrouille', rgb: [247, 139, 19], hex: '#F78B13', family: 'orange' },
  
  // Jaunes
  { code: '307', name: 'Citron', rgb: [253, 237, 84], hex: '#FDED54', family: 'yellow' },
  { code: '444', name: 'Citron foncé', rgb: [255, 214, 0], hex: '#FFD600', family: 'yellow' },
  { code: '445', name: 'Citron clair', rgb: [255, 242, 152], hex: '#FFF298', family: 'yellow' },
  { code: '726', name: 'Topaze clair', rgb: [252, 213, 87], hex: '#FCD557', family: 'yellow' },
  { code: '727', name: 'Topaze très clair', rgb: [255, 235, 168], hex: '#FFEBA8', family: 'yellow' },
  
  // Verts
  { code: '310', name: 'Noir', rgb: [0, 0, 0], hex: '#000000', family: 'black' },
  { code: '367', name: 'Vert pistache foncé', rgb: [97, 122, 82], hex: '#617A52', family: 'green' },
  { code: '368', name: 'Vert pistache clair', rgb: [166, 194, 152], hex: '#A6C298', family: 'green' },
  { code: '469', name: 'Avocat', rgb: [114, 132, 60], hex: '#72843C', family: 'green' },
  { code: '470', name: 'Avocat clair', rgb: [150, 168, 75], hex: '#96A84B', family: 'green' },
  { code: '895', name: 'Vert sapin très foncé', rgb: [30, 66, 44], hex: '#1E422C', family: 'green' },
  { code: '699', name: 'Vert sapin', rgb: [0, 96, 47], hex: '#00602F', family: 'green' },
  { code: '701', name: 'Vert clair', rgb: [79, 108, 69], hex: '#4F6C45', family: 'green' },
  { code: '702', name: 'Vert Kelly', rgb: [93, 164, 74], hex: '#5DA44A', family: 'green' },
  { code: '704', name: 'Vert chartreuse', rgb: [194, 209, 91], hex: '#C2D15B', family: 'green' },
  
  // Bleus
  { code: '311', name: 'Bleu marine moyen', rgb: [0, 63, 103], hex: '#003F67', family: 'blue' },
  { code: '312', name: 'Bleu marine très foncé', rgb: [0, 49, 82], hex: '#003152', family: 'blue' },
  { code: '322', name: 'Bleu marine clair', rgb: [90, 143, 184], hex: '#5A8FB8', family: 'blue' },
  { code: '336', name: 'Bleu marine', rgb: [37, 66, 100], hex: '#254264', family: 'blue' },
  { code: '792', name: 'Bleu marine très foncé', rgb: [84, 106, 140], hex: '#546A8C', family: 'blue' },
  { code: '793', name: 'Bleu moyen clair', rgb: [146, 168, 209], hex: '#92A8D1', family: 'blue' },
  { code: '794', name: 'Bleu clair', rgb: [175, 196, 230], hex: '#AFC4E6', family: 'blue' },
  { code: '796', name: 'Bleu roi foncé', rgb: [66, 86, 129], hex: '#425681', family: 'blue' },
  { code: '798', name: 'Bleu delft foncé', rgb: [70, 107, 162], hex: '#466BA2', family: 'blue' },
  { code: '799', name: 'Bleu delft moyen', rgb: [127, 169, 209], hex: '#7FA9D1', family: 'blue' },
  { code: '800', name: 'Bleu delft pâle', rgb: [194, 215, 237], hex: '#C2D7ED', family: 'blue' },
  { code: '809', name: 'Bleu delft', rgb: [148, 178, 207], hex: '#94B2CF', family: 'blue' },
  { code: '3325', name: 'Bleu bébé clair', rgb: [198, 216, 233], hex: '#C6D8E9', family: 'blue' },
  { code: '3755', name: 'Bleu bébé', rgb: [146, 179, 210], hex: '#92B3D2', family: 'blue' },
  { code: '3760', name: 'Bleu Wedgwood moyen', rgb: [99, 143, 171], hex: '#638FAB', family: 'blue' },
  
  // Violets et pourpres
  { code: '208', name: 'Lavande très foncé', rgb: [131, 91, 139], hex: '#835B8B', family: 'purple' },
  { code: '209', name: 'Lavande foncé', rgb: [163, 123, 167], hex: '#A37BA7', family: 'purple' },
  { code: '210', name: 'Lavande moyen', rgb: [195, 159, 195], hex: '#C39FC3', family: 'purple' },
  { code: '211', name: 'Lavande clair', rgb: [221, 202, 220], hex: '#DDCADC', family: 'purple' },
  { code: '550', name: 'Violet très foncé', rgb: [92, 24, 96], hex: '#5C1860', family: 'purple' },
  { code: '552', name: 'Violet moyen', rgb: [128, 60, 119], hex: '#803C77', family: 'purple' },
  { code: '553', name: 'Violet', rgb: [163, 99, 150], hex: '#A36396', family: 'purple' },
  { code: '554', name: 'Violet clair', rgb: [222, 192, 215], hex: '#DEC0D7', family: 'purple' },
  
  // Marrons et beiges
  { code: '433', name: 'Brun moyen', rgb: [122, 69, 31], hex: '#7A451F', family: 'brown' },
  { code: '434', name: 'Brun clair', rgb: [152, 94, 51], hex: '#985E33', family: 'brown' },
  { code: '435', name: 'Brun très clair', rgb: [184, 119, 72], hex: '#B87748', family: 'brown' },
  { code: '436', name: 'Havane', rgb: [203, 144, 81], hex: '#CB9051', family: 'brown' },
  { code: '437', name: 'Havane clair', rgb: [228, 187, 142], hex: '#E4BB8E', family: 'brown' },
  { code: '738', name: 'Havane très clair', rgb: [236, 204, 158], hex: '#ECCC9E', family: 'brown' },
  { code: '739', name: 'Crème très clair', rgb: [248, 228, 200], hex: '#F8E4C8', family: 'skin' },
  { code: '801', name: 'Brun café foncé', rgb: [101, 57, 25], hex: '#653919', family: 'brown' },
  { code: '840', name: 'Beige moyen', rgb: [191, 166, 137], hex: '#BFA689', family: 'brown' },
  { code: '841', name: 'Beige clair', rgb: [212, 190, 166], hex: '#D4BEA6', family: 'skin' },
  { code: '842', name: 'Beige très clair', rgb: [231, 212, 193], hex: '#E7D4C1', family: 'skin' },
  
  // Gris
  { code: '414', name: 'Gris acier foncé', rgb: [140, 140, 140], hex: '#8C8C8C', family: 'gray' },
  { code: '415', name: 'Gris perle', rgb: [180, 180, 180], hex: '#B4B4B4', family: 'gray' },
  { code: '762', name: 'Gris perle très clair', rgb: [220, 220, 220], hex: '#DCDCDC', family: 'gray' },
  { code: '318', name: 'Gris acier clair', rgb: [171, 171, 171], hex: '#ABABAB', family: 'gray' },
  { code: '317', name: 'Gris étain', rgb: [108, 108, 108], hex: '#6C6C6C', family: 'gray' },
  { code: '648', name: 'Gris castor clair', rgb: [188, 180, 172], hex: '#BCB4AC', family: 'gray' },
  { code: '647', name: 'Gris castor moyen', rgb: [176, 166, 156], hex: '#B0A69C', family: 'gray' },
  { code: '646', name: 'Gris castor foncé', rgb: [135, 125, 115], hex: '#877D73', family: 'gray' },
];

// Fonction pour trouver le DMC le plus proche d'une couleur RGB
export function findClosestDMC(rgb) {
  let minDistance = Infinity;
  let closestDMC = DMC_LIBRARY[0];
  
  for (const dmc of DMC_LIBRARY) {
    // Calcul de distance euclidienne RGB (simplifié)
    // Pour une meilleure précision, utiliser LAB
    const distance = Math.sqrt(
      Math.pow(rgb[0] - dmc.rgb[0], 2) +
      Math.pow(rgb[1] - dmc.rgb[1], 2) +
      Math.pow(rgb[2] - dmc.rgb[2], 2)
    );
    
    if (distance < minDistance) {
      minDistance = distance;
      closestDMC = dmc;
    }
  }
  
  return {
    ...closestDMC,
    confidence: minDistance < 30 ? 'high' : minDistance < 60 ? 'medium' : 'low',
    distance: minDistance
  };
}

// Convertir hex en RGB
export function hexToRgb(hex) {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result ? [
    parseInt(result[1], 16),
    parseInt(result[2], 16),
    parseInt(result[3], 16)
  ] : [0, 0, 0];
}

// Convertir RGB en hex
export function rgbToHex(rgb) {
  return '#' + rgb.map(x => {
    const hex = x.toString(16);
    return hex.length === 1 ? '0' + hex : hex;
  }).join('');
}