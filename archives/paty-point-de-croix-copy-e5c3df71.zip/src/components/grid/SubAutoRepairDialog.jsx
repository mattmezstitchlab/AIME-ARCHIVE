import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { X, Zap, Check, AlertTriangle, Loader2, Wrench } from 'lucide-react';
import { analyzeGrid, autoRepairSub } from './SubAutoRepairEngine';

export default function SubAutoRepairDialog({ open, onClose, pattern, onRepairComplete }) {
  const [mode, setMode] = useState('fast'); // 'fast' ou 'expert'
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isRepairing, setIsRepairing] = useState(false);
  const [analysis, setAnalysis] = useState(null);
  const [repairResult, setRepairResult] = useState(null);

  useEffect(() => {
    if (open && pattern) {
      runAnalysis();
    }
  }, [open, pattern]);

  const runAnalysis = async () => {
    setIsAnalyzing(true);
    setRepairResult(null);
    
    // Simulation d'un délai pour l'UX
    await new Promise(r => setTimeout(r, 300));
    
    const result = analyzeGrid(pattern);
    setAnalysis(result);
    setIsAnalyzing(false);
  };

  const handleRepair = async () => {
    setIsRepairing(true);
    
    // Simulation d'un délai pour l'UX
    await new Promise(r => setTimeout(r, 500));
    
    const result = autoRepairSub(pattern, { mode });
    setRepairResult(result);
    setIsRepairing(false);

    if (result.success) {
      onRepairComplete?.(result.pattern, result.summary);
    }
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[99999] flex items-center justify-center bg-black/60">
      <div className="bg-white rounded-xl shadow-2xl w-[550px] max-h-[85vh] overflow-hidden">
        {/* Header */}
        <div className="bg-black px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-yellow-400 to-yellow-600 flex items-center justify-center">
              <Wrench className="w-5 h-5 text-black" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Réparation Auto SUB™</h2>
              <p className="text-sm text-gray-400">0 trou — 0 erreur — 100% brodable</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center"
          >
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6 overflow-y-auto" style={{ maxHeight: 'calc(85vh - 180px)' }}>
          {/* Analyse */}
          {isAnalyzing ? (
            <div className="text-center py-8">
              <Loader2 className="w-12 h-12 animate-spin text-yellow-500 mx-auto mb-4" />
              <p className="text-gray-600">Analyse de la grille en cours...</p>
            </div>
          ) : analysis && !repairResult ? (
            <>
              {/* Résultat de l'analyse */}
              <div className={`p-4 rounded-lg border-2 ${
                analysis.isValid 
                  ? 'border-green-300 bg-green-50' 
                  : 'border-orange-300 bg-orange-50'
              }`}>
                <div className="flex items-center gap-3 mb-3">
                  {analysis.isValid ? (
                    <Check className="w-6 h-6 text-green-600" />
                  ) : (
                    <AlertTriangle className="w-6 h-6 text-orange-600" />
                  )}
                  <div className="font-bold">
                    {analysis.isValid 
                      ? 'Grille valide !' 
                      : `${analysis.errors.length} problème${analysis.errors.length > 1 ? 's' : ''} détecté${analysis.errors.length > 1 ? 's' : ''}`
                    }
                  </div>
                </div>

                {/* Stats */}
                <div className="grid grid-cols-3 gap-3 mb-4">
                  <div className="bg-white rounded-lg p-3 text-center">
                    <div className="text-2xl font-bold">{analysis.stats?.totalCells || 0}</div>
                    <div className="text-xs text-gray-500">Cases totales</div>
                  </div>
                  <div className="bg-white rounded-lg p-3 text-center">
                    <div className="text-2xl font-bold text-green-600">{analysis.stats?.filledCells || 0}</div>
                    <div className="text-xs text-gray-500">Remplies</div>
                  </div>
                  <div className="bg-white rounded-lg p-3 text-center">
                    <div className={`text-2xl font-bold ${analysis.stats?.emptyCells > 0 ? 'text-red-600' : 'text-green-600'}`}>
                      {analysis.stats?.emptyCells || 0}
                    </div>
                    <div className="text-xs text-gray-500">Vides</div>
                  </div>
                </div>

                {/* Liste des erreurs */}
                {!analysis.isValid && (
                  <div className="space-y-2">
                    {analysis.errors.map((error, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-sm text-orange-800">
                        <div className="w-1.5 h-1.5 rounded-full bg-orange-500" />
                        {error}
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Mode de réparation */}
              {!analysis.isValid && (
                <div>
                  <label className="text-sm font-medium mb-3 block">Mode de réparation</label>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      onClick={() => setMode('fast')}
                      className={`p-4 rounded-xl border-2 text-left transition-all ${
                        mode === 'fast' 
                          ? 'border-yellow-500 bg-yellow-50' 
                          : 'border-gray-200 hover:border-gray-400'
                      }`}
                    >
                      <div className="flex items-center gap-2 mb-1">
                        <Zap className="w-5 h-5 text-yellow-600" />
                        <span className="font-bold">Rapide</span>
                      </div>
                      <p className="text-xs text-gray-600">
                        Répare automatiquement sans poser de questions
                      </p>
                    </button>
                    <button
                      onClick={() => setMode('expert')}
                      className={`p-4 rounded-xl border-2 text-left transition-all ${
                        mode === 'expert' 
                          ? 'border-yellow-500 bg-yellow-50' 
                          : 'border-gray-200 hover:border-gray-400'
                      }`}
                    >
                      <div className="flex items-center gap-2 mb-1">
                        <Wrench className="w-5 h-5 text-gray-600" />
                        <span className="font-bold">Expert</span>
                      </div>
                      <p className="text-xs text-gray-600">
                        Affiche la liste des corrections avant application
                      </p>
                    </button>
                  </div>
                </div>
              )}
            </>
          ) : null}

          {/* Résultat de la réparation */}
          {repairResult && (
            <div className="space-y-4">
              <div className="p-4 rounded-lg border-2 border-green-300 bg-green-50">
                <div className="flex items-center gap-3 mb-3">
                  <Check className="w-6 h-6 text-green-600" />
                  <div className="font-bold text-green-800">Réparation terminée !</div>
                </div>
                <p className="text-sm text-green-700">{repairResult.message}</p>
              </div>

              {/* Résumé des réparations */}
              <div className="bg-gray-50 rounded-lg p-4">
                <h3 className="font-bold mb-3">Résumé des corrections</h3>
                <div className="grid grid-cols-2 gap-3">
                  {repairResult.summary.holesRepaired > 0 && (
                    <div className="flex items-center gap-2 text-sm">
                      <Check className="w-4 h-4 text-green-600" />
                      <span>{repairResult.summary.holesRepaired} trous remplis</span>
                    </div>
                  )}
                  {repairResult.summary.symbolsAssigned > 0 && (
                    <div className="flex items-center gap-2 text-sm">
                      <Check className="w-4 h-4 text-green-600" />
                      <span>{repairResult.summary.symbolsAssigned} symboles assignés</span>
                    </div>
                  )}
                  {repairResult.summary.dmcCorrected > 0 && (
                    <div className="flex items-center gap-2 text-sm">
                      <Check className="w-4 h-4 text-green-600" />
                      <span>{repairResult.summary.dmcCorrected} DMC corrigés</span>
                    </div>
                  )}
                  {repairResult.summary.colorsMerged > 0 && (
                    <div className="flex items-center gap-2 text-sm">
                      <Check className="w-4 h-4 text-green-600" />
                      <span>{repairResult.summary.colorsMerged} couleurs fusionnées</span>
                    </div>
                  )}
                  {repairResult.summary.finalFills > 0 && (
                    <div className="flex items-center gap-2 text-sm">
                      <Check className="w-4 h-4 text-green-600" />
                      <span>{repairResult.summary.finalFills} cases finales</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Liste détaillée en mode expert */}
              {mode === 'expert' && repairResult.repairs.length > 0 && (
                <div className="bg-gray-50 rounded-lg p-4 max-h-40 overflow-y-auto">
                  <h3 className="font-bold mb-2 text-sm">Détail des {repairResult.repairs.length} corrections</h3>
                  <div className="space-y-1 text-xs text-gray-600">
                    {repairResult.repairs.slice(0, 50).map((r, idx) => (
                      <div key={idx}>
                        {r.type === 'hole_filled' && `• Case [${r.row},${r.col}] remplie`}
                        {r.type === 'symbol_assigned' && `• Symbole ${r.symbol} assigné [${r.row},${r.col}]`}
                        {r.type === 'dmc_corrected' && `• DMC ${r.dmc} assigné`}
                        {r.type === 'color_merged' && `• Couleur fusionnée`}
                        {r.type === 'final_fill' && `• Case [${r.row},${r.col}] verrouillée`}
                      </div>
                    ))}
                    {repairResult.repairs.length > 50 && (
                      <div className="font-medium">... et {repairResult.repairs.length - 50} autres corrections</div>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t bg-gray-50 flex items-center justify-between">
          <p className="text-xs text-gray-500">
            <span className="font-semibold text-yellow-600">SUB™</span> — Une grille SUB ne peut jamais rester incomplète.
          </p>
          <div className="flex gap-3">
            <Button variant="outline" onClick={onClose}>
              {repairResult ? 'Fermer' : 'Annuler'}
            </Button>
            {!repairResult && analysis && !analysis.isValid && (
              <Button 
                onClick={handleRepair}
                disabled={isRepairing}
                className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold"
              >
                {isRepairing ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Réparation...
                  </>
                ) : (
                  <>
                    <Wrench className="w-4 h-4 mr-2" />
                    Réparer maintenant
                  </>
                )}
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}