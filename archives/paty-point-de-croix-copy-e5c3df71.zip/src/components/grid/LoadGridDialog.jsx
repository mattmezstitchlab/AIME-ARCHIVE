import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Loader2, Grid3x3 } from 'lucide-react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';

export default function LoadGridDialog({ open, onClose, onSelect }) {
  const { data: grids, isLoading } = useQuery({
    queryKey: ['grids'],
    queryFn: () => base44.entities.Grid.list('-updated_date', 50),
    enabled: open,
  });

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl max-h-[80vh]">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold">Charger une grille</DialogTitle>
          <DialogDescription>
            Sélectionnez une grille existante pour continuer votre travail.
          </DialogDescription>
        </DialogHeader>
        
        <div className="py-4 overflow-y-auto max-h-[500px]">
          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-8 h-8 animate-spin text-slate-400" />
            </div>
          ) : grids?.length === 0 ? (
            <div className="text-center py-12 text-slate-500">
              <Grid3x3 className="w-12 h-12 mx-auto mb-3 opacity-30" />
              <p>Aucune grille sauvegardée</p>
            </div>
          ) : (
            <div className="grid gap-3">
              {grids?.map((grid) => (
                <button
                  key={grid.id}
                  onClick={() => {
                    onSelect(grid);
                    onClose();
                  }}
                  className="flex items-start gap-4 p-4 border border-slate-200 rounded-xl hover:bg-slate-50 hover:border-slate-300 transition-all text-left group"
                >
                  <div className="w-12 h-12 bg-slate-100 rounded-lg flex items-center justify-center group-hover:bg-slate-200 transition-colors">
                    <Grid3x3 className="w-6 h-6 text-slate-600" />
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold text-slate-900 mb-1">
                      {grid.name}
                    </div>
                    <div className="text-sm text-slate-600 mb-2">
                      {grid.nb_colonnes} × {grid.nb_lignes} cases
                      {grid.stitches?.length > 0 && (
                        <span className="ml-2">• {grid.stitches.length} points</span>
                      )}
                    </div>
                    <div className="text-xs text-slate-500">
                      Modifié le {format(new Date(grid.updated_date), 'dd MMM yyyy à HH:mm', { locale: fr })}
                    </div>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}