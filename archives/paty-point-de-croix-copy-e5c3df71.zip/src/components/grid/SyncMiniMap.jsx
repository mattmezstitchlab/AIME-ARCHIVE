import React, { useRef, useEffect, useState } from 'react';
import { X, Maximize2, Minimize2 } from 'lucide-react';

export default function SyncMiniMap({
  pattern,
  gridConfig,
  canvasSize,
  onNavigate,
  visible = true,
  onClose
}) {
  const canvasRef = useRef(null);
  const [isExpanded, setIsExpanded] = useState(false);

  // Redessiner la mini-carte quand le pattern ou la config change
  useEffect(() => {
    if (!visible || !pattern || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const size = isExpanded ? 200 : 120;
    
    canvas.width = size;
    canvas.height = size;

    // Fond
    ctx.fillStyle = '#f8f8f8';
    ctx.fillRect(0, 0, size, size);

    // Calculer l'échelle
    const patternWidth = pattern.width || 100;
    const patternHeight = pattern.height || 100;
    const scale = Math.min(size / patternWidth, size / patternHeight) * 0.9;
    const offsetX = (size - patternWidth * scale) / 2;
    const offsetY = (size - patternHeight * scale) / 2;

    // Dessiner les cellules
    if (pattern.symbolGrid) {
      pattern.symbolGrid.forEach((row, rowIdx) => {
        row.forEach((cell, colIdx) => {
          if (cell && cell.colorId) {
            const color = pattern.colorPalette?.find(c => c.id === cell.colorId);
            ctx.fillStyle = color?.hex || color?.dmcHex || '#ccc';
            ctx.fillRect(
              offsetX + colIdx * scale,
              offsetY + rowIdx * scale,
              Math.max(1, scale),
              Math.max(1, scale)
            );
          }
        });
      });
    }

    // Dessiner la zone visible (viewport)
    if (gridConfig && canvasSize.width > 0) {
      const zoom = gridConfig.zoom || 1;
      const taille = gridConfig.taille_case || 25;
      const patternOffset = pattern.offsetCol || 0;
      const patternOffsetRow = pattern.offsetRow || 0;

      // Calculer la zone visible en coordonnées grille
      const visibleLeft = (-gridConfig.offset_x) / (taille * zoom);
      const visibleTop = (-gridConfig.offset_y) / (taille * zoom);
      const visibleWidth = canvasSize.width / (taille * zoom);
      const visibleHeight = canvasSize.height / (taille * zoom);

      // Convertir en coordonnées pattern
      const viewX = Math.max(0, visibleLeft - patternOffset);
      const viewY = Math.max(0, visibleTop - patternOffsetRow);
      const viewW = Math.min(patternWidth, visibleWidth);
      const viewH = Math.min(patternHeight, visibleHeight);

      // Dessiner le rectangle de vue
      ctx.strokeStyle = '#FF0000';
      ctx.lineWidth = 2;
      ctx.strokeRect(
        offsetX + viewX * scale,
        offsetY + viewY * scale,
        viewW * scale,
        viewH * scale
      );
    }

    // Bordure
    ctx.strokeStyle = '#ddd';
    ctx.lineWidth = 1;
    ctx.strokeRect(0, 0, size, size);

  }, [pattern, gridConfig, canvasSize, visible, isExpanded]);

  // Gérer le clic pour navigation
  const handleClick = (e) => {
    if (!pattern || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const size = isExpanded ? 200 : 120;
    const patternWidth = pattern.width || 100;
    const patternHeight = pattern.height || 100;
    const scale = Math.min(size / patternWidth, size / patternHeight) * 0.9;
    const offsetX = (size - patternWidth * scale) / 2;
    const offsetY = (size - patternHeight * scale) / 2;

    // Convertir en coordonnées grille
    const gridX = (x - offsetX) / scale + (pattern.offsetCol || 0);
    const gridY = (y - offsetY) / scale + (pattern.offsetRow || 0);

    // Convertir en coordonnées pixel pour centrer la vue
    const taille = gridConfig?.taille_case || 25;
    const pixelX = gridX * taille;
    const pixelY = gridY * taille;

    onNavigate?.(pixelX, pixelY);
  };

  if (!visible) return null;

  return (
    <div 
      className="fixed bottom-4 left-4 bg-white rounded-lg shadow-xl border border-gray-200 overflow-hidden z-40"
      style={{ width: isExpanded ? 220 : 140, height: isExpanded ? 240 : 160 }}
    >
      {/* Header */}
      <div className="bg-gray-100 px-2 py-1 flex items-center justify-between border-b">
        <span className="text-xs font-medium text-gray-600">Mini-Carte</span>
        <div className="flex items-center gap-1">
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="w-5 h-5 rounded hover:bg-gray-200 flex items-center justify-center"
          >
            {isExpanded ? (
              <Minimize2 className="w-3 h-3 text-gray-500" />
            ) : (
              <Maximize2 className="w-3 h-3 text-gray-500" />
            )}
          </button>
          <button
            onClick={onClose}
            className="w-5 h-5 rounded hover:bg-gray-200 flex items-center justify-center"
          >
            <X className="w-3 h-3 text-gray-500" />
          </button>
        </div>
      </div>

      {/* Canvas */}
      <div className="p-2 flex items-center justify-center">
        <canvas
          ref={canvasRef}
          onClick={handleClick}
          className="cursor-crosshair"
          style={{ 
            width: isExpanded ? 200 : 120, 
            height: isExpanded ? 200 : 120 
          }}
        />
      </div>

      {/* Status */}
      {pattern && (
        <div className="px-2 pb-1 text-center">
          <span className="text-[10px] text-gray-400">
            {pattern.width}×{pattern.height} • Clic pour naviguer
          </span>
        </div>
      )}
    </div>
  );
}