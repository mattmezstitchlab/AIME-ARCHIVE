import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { X, Sparkles, Zap, CheckCircle } from 'lucide-react';
import { detectHolesForPointZero } from './stitchTypes';

export default function RepairHolesDialog({ 
  open, 
  onClose, 
  onConfirm,
  pattern
}) {
  const [maxHoleSize, setMaxHoleSize] = useState(3); // Par défaut 3 cases (SUB™)
  const [preserveBackground, setPreserveBackground] = useState(true);
  const [detectedHoles, setDetectedHoles] = useState(0);
  const [mode, setMode] = useState('auto'); // auto, manual, no_empty

  // Détecter les trous avec Point Zero SUB™
  useEffect(() => {
    if (!open || !pattern?.symbolGrid) return;
    
    const { count } = detectHolesForPointZero(pattern.symbolGrid, {
      maxHoleSize,
      preserveBackground
    });
    
    setDetectedHoles(count);
  }, [open, pattern, preserveBackground, maxHoleSize]);

  const handleRepair = () => {
    onConfirm({ maxHoleSize, preserveBackground, mode });
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center">
      {/* Overlay */}
      <div className="absolute inset-0 bg-black/60" onClick={onClose} />
      
      {/* Dialog */}
      <div className="relative w-[90vw] max-w-[500px] bg-white rounded-xl shadow-2xl flex flex-col border border-[#E0E0E0]">
        
        {/* HEADER */}
        <div className="flex-shrink-0 bg-[#111] px-6 py-4 flex items-center justify-between rounded-t-xl">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#F5C200] flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-black" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Réparer les trous</h2>
              <p className="text-sm text-[#999]">
                Analyse et comble les cases vides
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-all"
          >
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        {/* CONTENU */}
        <div className="p-6 space-y-6">
          {/* Badge SUB™ */}
          <div className="bg-gradient-to-r from-yellow-50 to-orange-50 border border-yellow-200 rounded-lg p-3">
            <div className="flex items-center gap-2">
              <Zap className="w-4 h-4 text-yellow-600" />
              <span className="text-sm font-semibold text-yellow-800">
                Point Zero — Technologie LECOINTRE SUB™
              </span>
            </div>
            <p className="text-xs text-yellow-700 mt-1">
              Remplissage intelligent des cases vides — Motifs parfaits, prêts à broder.
            </p>
          </div>

          {/* Nombre de trous détectés */}
          <div className="p-4 bg-[#F5F5F5] rounded-lg border border-[#E0E0E0]">
            <div className="text-sm text-[#777] mb-1">Trous détectés :</div>
            <div className="text-3xl font-bold text-black">
              {detectedHoles}
              <span className="text-lg text-[#777] font-normal ml-2">
                case{detectedHoles > 1 ? 's' : ''} vide{detectedHoles > 1 ? 's' : ''}
              </span>
            </div>
            {detectedHoles === 0 && (
              <div className="flex items-center gap-2 mt-2 text-green-600">
                <CheckCircle className="w-4 h-4" />
                <span className="text-sm font-medium">Grille complétée — Aucun trou restant</span>
              </div>
            )}
          </div>

          {/* Mode de réparation */}
          <div>
            <label className="text-sm font-medium text-black mb-3 block">
              Mode de réparation
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => setMode('auto')}
                className={`p-3 rounded-lg border-2 transition-all text-center ${
                  mode === 'auto' 
                    ? 'border-[#F5C200] bg-yellow-50' 
                    : 'border-[#E0E0E0] hover:border-[#CCC]'
                }`}
              >
                <div className="text-lg mb-1">🤖</div>
                <div className="text-xs font-medium">Auto (IA)</div>
              </button>
              <button
                onClick={() => setMode('manual')}
                className={`p-3 rounded-lg border-2 transition-all text-center ${
                  mode === 'manual' 
                    ? 'border-[#F5C200] bg-yellow-50' 
                    : 'border-[#E0E0E0] hover:border-[#CCC]'
                }`}
              >
                <div className="text-lg mb-1">✋</div>
                <div className="text-xs font-medium">Manuel</div>
              </button>
              <button
                onClick={() => setMode('no_empty')}
                className={`p-3 rounded-lg border-2 transition-all text-center ${
                  mode === 'no_empty' 
                    ? 'border-[#F5C200] bg-yellow-50' 
                    : 'border-[#E0E0E0] hover:border-[#CCC]'
                }`}
              >
                <div className="text-lg mb-1">🚫</div>
                <div className="text-xs font-medium">Sans vide</div>
              </button>
            </div>
          </div>

          {/* Taille max des trous */}
          <div>
            <label className="text-sm font-medium text-black mb-3 block">
              Taille maximum des trous à réparer automatiquement
            </label>
            <input
              type="range"
              min="1"
              max="5"
              value={maxHoleSize}
              onChange={(e) => setMaxHoleSize(Number(e.target.value))}
              className="w-full h-2 bg-[#E0E0E0] rounded-lg appearance-none cursor-pointer accent-[#F5C200]"
            />
            <div className="flex justify-between text-xs text-[#777] mt-2">
              <span>1 case</span>
              <span className="font-semibold text-black">{maxHoleSize} case{maxHoleSize > 1 ? 's' : ''}</span>
              <span>5 cases</span>
            </div>
          </div>

          {/* Préserver le fond */}
          <div className="flex items-start gap-3">
            <input
              type="checkbox"
              checked={preserveBackground}
              onChange={(e) => setPreserveBackground(e.target.checked)}
              className="mt-1 w-4 h-4 accent-[#F5C200]"
            />
            <div className="flex-1">
              <div className="text-sm font-medium text-black">Préserver les bords du motif</div>
              <div className="text-xs text-[#777] mt-1">
                Ne pas toucher aux bords et aux grandes zones vides intentionnelles
              </div>
            </div>
          </div>

          {/* Message sécurité brodeuse */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-xs text-blue-800">
            <strong>Sécurité brodeuse :</strong> Aucun trou = aucune erreur oubliée en broderie réelle. 
            Motif 100% exploitable, PDF 100% complet.
          </div>
        </div>

        {/* FOOTER */}
        <div className="flex-shrink-0 bg-[#F7F7F7] border-t border-[#E0E0E0] px-6 py-4 flex items-center justify-end gap-3 rounded-b-xl">
          <Button
            variant="outline"
            onClick={onClose}
            className="px-6 py-2 bg-white border border-[#DDDDDD] text-[#555] hover:bg-[#F0F0F0] rounded-lg"
          >
            Annuler
          </Button>

          <Button
            onClick={handleRepair}
            disabled={detectedHoles === 0}
            className="px-8 py-2 bg-[#F5C200] hover:bg-[#E5B200] text-black font-semibold rounded-lg shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Réparer maintenant
          </Button>
        </div>
      </div>
    </div>
  );
}