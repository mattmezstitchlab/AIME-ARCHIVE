import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Type, Shapes, Image as ImageIcon, Search } from 'lucide-react';
import { toast } from 'sonner';
import { MOTIFS_LIBRARY } from './MotifsLibrary';

// Police de caractères simplifiée pour le point de croix
const CROSS_STITCH_FONT = {
  'A': [[0,1,1,0],[1,0,0,1],[1,1,1,1],[1,0,0,1],[1,0,0,1]],
  'B': [[1,1,1,0],[1,0,0,1],[1,1,1,0],[1,0,0,1],[1,1,1,0]],
  'C': [[0,1,1,1],[1,0,0,0],[1,0,0,0],[1,0,0,0],[0,1,1,1]],
  'D': [[1,1,1,0],[1,0,0,1],[1,0,0,1],[1,0,0,1],[1,1,1,0]],
  'E': [[1,1,1,1],[1,0,0,0],[1,1,1,0],[1,0,0,0],[1,1,1,1]],
  'F': [[1,1,1,1],[1,0,0,0],[1,1,1,0],[1,0,0,0],[1,0,0,0]],
  'G': [[0,1,1,1],[1,0,0,0],[1,0,1,1],[1,0,0,1],[0,1,1,0]],
  'H': [[1,0,0,1],[1,0,0,1],[1,1,1,1],[1,0,0,1],[1,0,0,1]],
  'I': [[1,1,1],[0,1,0],[0,1,0],[0,1,0],[1,1,1]],
  'J': [[0,0,1],[0,0,1],[0,0,1],[1,0,1],[0,1,0]],
  'K': [[1,0,0,1],[1,0,1,0],[1,1,0,0],[1,0,1,0],[1,0,0,1]],
  'L': [[1,0,0,0],[1,0,0,0],[1,0,0,0],[1,0,0,0],[1,1,1,1]],
  'M': [[1,0,0,0,1],[1,1,0,1,1],[1,0,1,0,1],[1,0,0,0,1],[1,0,0,0,1]],
  'N': [[1,0,0,1],[1,1,0,1],[1,0,1,1],[1,0,0,1],[1,0,0,1]],
  'O': [[0,1,1,0],[1,0,0,1],[1,0,0,1],[1,0,0,1],[0,1,1,0]],
  'P': [[1,1,1,0],[1,0,0,1],[1,1,1,0],[1,0,0,0],[1,0,0,0]],
  'Q': [[0,1,1,0],[1,0,0,1],[1,0,0,1],[1,0,1,0],[0,1,0,1]],
  'R': [[1,1,1,0],[1,0,0,1],[1,1,1,0],[1,0,1,0],[1,0,0,1]],
  'S': [[0,1,1,1],[1,0,0,0],[0,1,1,0],[0,0,0,1],[1,1,1,0]],
  'T': [[1,1,1],[0,1,0],[0,1,0],[0,1,0],[0,1,0]],
  'U': [[1,0,0,1],[1,0,0,1],[1,0,0,1],[1,0,0,1],[0,1,1,0]],
  'V': [[1,0,0,1],[1,0,0,1],[1,0,0,1],[0,1,1,0],[0,1,0,0]],
  'W': [[1,0,0,0,1],[1,0,0,0,1],[1,0,1,0,1],[1,1,0,1,1],[1,0,0,0,1]],
  'X': [[1,0,0,1],[0,1,1,0],[0,1,0,0],[0,1,1,0],[1,0,0,1]],
  'Y': [[1,0,1],[0,1,0],[0,1,0],[0,1,0],[0,1,0]],
  'Z': [[1,1,1,1],[0,0,1,0],[0,1,0,0],[1,0,0,0],[1,1,1,1]],
  ' ': [[0,0],[0,0],[0,0],[0,0],[0,0]],
  '0': [[0,1,1,0],[1,0,0,1],[1,0,0,1],[1,0,0,1],[0,1,1,0]],
  '1': [[0,1,0],[1,1,0],[0,1,0],[0,1,0],[1,1,1]],
  '2': [[1,1,1,0],[0,0,0,1],[0,1,1,0],[1,0,0,0],[1,1,1,1]],
  '3': [[1,1,1,0],[0,0,0,1],[0,1,1,0],[0,0,0,1],[1,1,1,0]],
  '4': [[1,0,1,0],[1,0,1,0],[1,1,1,1],[0,0,1,0],[0,0,1,0]],
  '5': [[1,1,1,1],[1,0,0,0],[1,1,1,0],[0,0,0,1],[1,1,1,0]],
  '6': [[0,1,1,0],[1,0,0,0],[1,1,1,0],[1,0,0,1],[0,1,1,0]],
  '7': [[1,1,1,1],[0,0,0,1],[0,0,1,0],[0,1,0,0],[1,0,0,0]],
  '8': [[0,1,1,0],[1,0,0,1],[0,1,1,0],[1,0,0,1],[0,1,1,0]],
  '9': [[0,1,1,0],[1,0,0,1],[0,1,1,1],[0,0,0,1],[0,1,1,0]],
};

export default function ElementsDialog({ open, onClose, onElementGenerated }) {
  const [text, setText] = useState('');
  const [textSize, setTextSize] = useState('Moyen');
  const [textColor, setTextColor] = useState('#000000');
  const [motifSearch, setMotifSearch] = useState('');

  const convertTextToPattern = (inputText) => {
    const upperText = inputText.toUpperCase();
    const lines = [];
    
    // Calculer la hauteur maximale
    const height = 5;
    
    // Pour chaque ligne de pixels
    for (let row = 0; row < height; row++) {
      const rowPixels = [];
      
      // Pour chaque caractère
      for (let i = 0; i < upperText.length; i++) {
        const char = upperText[i];
        const charPattern = CROSS_STITCH_FONT[char] || CROSS_STITCH_FONT[' '];
        
        if (charPattern && charPattern[row]) {
          rowPixels.push(...charPattern[row]);
        }
        
        // Espace entre les caractères
        if (i < upperText.length - 1) {
          rowPixels.push(0);
        }
      }
      
      lines.push(rowPixels);
    }
    
    // Ajuster la taille selon le paramètre
    let scale = 1;
    if (textSize === 'Petit') scale = 1;
    if (textSize === 'Moyen') scale = 2;
    if (textSize === 'Grand') scale = 3;
    
    if (scale > 1) {
      const scaledLines = [];
      lines.forEach(line => {
        const scaledLine = [];
        line.forEach(pixel => {
          for (let i = 0; i < scale; i++) {
            scaledLine.push(pixel);
          }
        });
        for (let i = 0; i < scale; i++) {
          scaledLines.push(scaledLine);
        }
      });
      return scaledLines;
    }
    
    return lines;
  };

  const handleGenerateText = () => {
    if (!text.trim()) {
      toast.error('Veuillez entrer du texte');
      return;
    }
    
    const pattern = convertTextToPattern(text);
    
    onElementGenerated({
      type: 'text',
      pattern,
      color: textColor,
      name: `Texte: ${text}`
    });
    
    toast.success('Texte généré !');
  };

  const handleSelectMotif = (motif) => {
    onElementGenerated({
      type: 'motif',
      pattern: motif.pattern,
      color: textColor,
      name: motif.name
    });
    
    toast.success(`Motif "${motif.name}" sélectionné`);
  };

  const handleImportVector = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    toast.info('Import d\'image en cours...');
    
    // Pour l'instant, on simule une conversion simple
    // Dans une vraie implémentation, on utiliserait Canvas pour pixeliser l'image
    toast.error('Fonctionnalité en développement');
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            ✨ Éléments & Textes
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="text" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="text">
              <Type className="w-4 h-4 mr-2" />
              Texte
            </TabsTrigger>
            <TabsTrigger value="motifs">
              <Shapes className="w-4 h-4 mr-2" />
              Motifs
            </TabsTrigger>
            <TabsTrigger value="vector">
              <ImageIcon className="w-4 h-4 mr-2" />
              Vectoriel
            </TabsTrigger>
          </TabsList>

          {/* TAB TEXTE */}
          <TabsContent value="text" className="space-y-4">
            <div>
              <Label htmlFor="input-text">Votre texte</Label>
              <Input
                id="input-text"
                placeholder="Entrez votre texte..."
                value={text}
                onChange={(e) => setText(e.target.value)}
                maxLength={20}
              />
              <p className="text-xs text-slate-500 mt-1">
                Maximum 20 caractères
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="text-size">Taille</Label>
                <Select value={textSize} onValueChange={setTextSize}>
                  <SelectTrigger id="text-size">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Petit">Petit</SelectItem>
                    <SelectItem value="Moyen">Moyen</SelectItem>
                    <SelectItem value="Grand">Grand</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="text-color">Couleur</Label>
                <div className="flex gap-2">
                  <Input
                    id="text-color"
                    type="color"
                    value={textColor}
                    onChange={(e) => setTextColor(e.target.value)}
                    className="w-16 h-10"
                  />
                  <Input
                    value={textColor}
                    onChange={(e) => setTextColor(e.target.value)}
                    className="flex-1"
                  />
                </div>
              </div>
            </div>

            <Button
              onClick={handleGenerateText}
              className="w-full bg-slate-900 hover:bg-slate-800"
            >
              Générer le texte
            </Button>
          </TabsContent>

          {/* TAB MOTIFS */}
          <TabsContent value="motifs" className="space-y-4">
            <div className="flex items-center gap-2">
              <Search className="w-4 h-4 text-slate-400" />
              <Input
                placeholder="Rechercher un motif..."
                value={motifSearch}
                onChange={(e) => setMotifSearch(e.target.value)}
              />
            </div>

            <p className="text-xs text-slate-500">
              {MOTIFS_LIBRARY.filter(m => 
                m.name.toLowerCase().includes(motifSearch.toLowerCase())
              ).length} motifs disponibles
            </p>

            <div className="grid grid-cols-4 gap-3 max-h-96 overflow-y-auto pr-2">
              {MOTIFS_LIBRARY
                .filter(m => m.name.toLowerCase().includes(motifSearch.toLowerCase()))
                .map((motif) => (
                <button
                  key={motif.id}
                  onClick={() => handleSelectMotif(motif)}
                  className="border-2 border-slate-200 rounded-lg p-3 hover:border-slate-900 hover:bg-slate-50 transition-colors"
                >
                  <div className="mb-2">
                    <div className="grid gap-0.5" style={{
                      gridTemplateColumns: `repeat(${motif.pattern[0].length}, 1fr)`
                    }}>
                      {motif.pattern.map((row, i) =>
                        row.map((cell, j) => (
                          <div
                            key={`${i}-${j}`}
                            className="aspect-square rounded-sm"
                            style={{
                              backgroundColor: cell ? textColor : '#f1f5f9'
                            }}
                          />
                        ))
                      )}
                    </div>
                  </div>
                  <p className="text-xs font-medium text-slate-700">
                    {motif.name}
                  </p>
                </button>
              ))}
            </div>
          </TabsContent>

          {/* TAB VECTORIEL */}
          <TabsContent value="vector" className="space-y-4">
            <p className="text-sm text-slate-600">
              Importez un fichier SVG ou PNG et convertissez-le en grille de broderie
            </p>

            <div className="border-2 border-dashed border-slate-300 rounded-lg p-8 text-center">
              <Input
                type="file"
                accept=".svg,.png,.jpg,.jpeg"
                onChange={handleImportVector}
                className="hidden"
                id="vector-upload"
              />
              <label htmlFor="vector-upload" className="cursor-pointer">
                <ImageIcon className="w-12 h-12 mx-auto mb-4 text-slate-400" />
                <p className="text-sm text-slate-600 mb-2">
                  Cliquez pour importer un fichier
                </p>
                <p className="text-xs text-slate-400">
                  SVG, PNG, JPG (max 100x100 pixels)
                </p>
              </label>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <p className="text-xs text-blue-900">
                <strong>À venir :</strong> Import et conversion automatique d'images vectorielles en grilles de point de croix.
              </p>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}