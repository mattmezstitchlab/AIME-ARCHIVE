import React, { useRef, useEffect } from 'react';

export default function SimpleMiniMap({
  gridConfig,
  pattern,
  canvasSize,
  onNavigate,
  showPatternImage,
  showCenterMarker,
  show10x10
}) {
  const canvasRef = useRef(null);
  const miniMapSize = 200;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    const scale = miniMapSize / Math.max(gridConfig.nb_colonnes, gridConfig.nb_lignes);

    // Clear
    ctx.clearRect(0, 0, miniMapSize, miniMapSize);

    // Fond blanc
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, miniMapSize, miniMapSize);

    // Grille globale
    ctx.strokeStyle = '#E5E5E5';
    ctx.lineWidth = 1;
    ctx.strokeRect(0, 0, gridConfig.nb_colonnes * scale, gridConfig.nb_lignes * scale);

    // Pattern image si disponible
    if (showPatternImage && pattern?.sourceImage) {
      const img = new Image();
      img.onload = () => {
        const offsetCol = pattern.offsetCol || 0;
        const offsetRow = pattern.offsetRow || 0;
        ctx.globalAlpha = 0.7;
        ctx.drawImage(
          img,
          offsetCol * scale,
          offsetRow * scale,
          pattern.width * scale,
          pattern.height * scale
        );
        ctx.globalAlpha = 1;
      };
      img.src = pattern.sourceImage;
    }

    // Repères 10×10 (rouges)
    if (show10x10) {
      ctx.strokeStyle = '#EF4444';
      ctx.lineWidth = 1;
      for (let i = 10; i <= gridConfig.nb_colonnes; i += 10) {
        ctx.beginPath();
        ctx.moveTo(i * scale, 0);
        ctx.lineTo(i * scale, gridConfig.nb_lignes * scale);
        ctx.stroke();
      }
      for (let i = 10; i <= gridConfig.nb_lignes; i += 10) {
        ctx.beginPath();
        ctx.moveTo(0, i * scale);
        ctx.lineTo(gridConfig.nb_colonnes * scale, i * scale);
        ctx.stroke();
      }
    }

    // Centre (croix rouge)
    if (showCenterMarker) {
      const centerX = (gridConfig.nb_colonnes / 2) * scale;
      const centerY = (gridConfig.nb_lignes / 2) * scale;
      ctx.strokeStyle = '#EF4444';
      ctx.lineWidth = 2;
      const size = 8;
      ctx.beginPath();
      ctx.moveTo(centerX - size, centerY);
      ctx.lineTo(centerX + size, centerY);
      ctx.moveTo(centerX, centerY - size);
      ctx.lineTo(centerX, centerY + size);
      ctx.stroke();
    }

    // Viewport (carré bleu)
    if (canvasSize.width > 0 && canvasSize.height > 0) {
      const viewportWidth = (canvasSize.width / (gridConfig.zoom * gridConfig.taille_case)) * scale;
      const viewportHeight = (canvasSize.height / (gridConfig.zoom * gridConfig.taille_case)) * scale;
      const viewportX = (-gridConfig.offset_x / (gridConfig.zoom * gridConfig.taille_case)) * scale;
      const viewportY = (-gridConfig.offset_y / (gridConfig.zoom * gridConfig.taille_case)) * scale;

      ctx.strokeStyle = '#3B82F6';
      ctx.lineWidth = 2;
      ctx.strokeRect(viewportX, viewportY, viewportWidth, viewportHeight);
    }

    // Numérotation simplifiée (extrémités uniquement)
    ctx.fillStyle = '#64748B';
    ctx.font = '10px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('0', (gridConfig.nb_colonnes / 2) * scale, 12);
    ctx.fillText(gridConfig.nb_colonnes.toString(), gridConfig.nb_colonnes * scale - 10, gridConfig.nb_lignes * scale - 4);

  }, [gridConfig, pattern, canvasSize, showPatternImage, showCenterMarker, show10x10]);

  const handleClick = (e) => {
    const rect = canvasRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const scale = miniMapSize / Math.max(gridConfig.nb_colonnes, gridConfig.nb_lignes);
    const gridX = (x / scale) * gridConfig.taille_case;
    const gridY = (y / scale) * gridConfig.taille_case;
    onNavigate(gridX, gridY);
  };

  return (
    <div className="bg-white border border-slate-200 rounded-lg p-3">
      <div className="text-xs font-medium text-slate-700 mb-2">Aperçu</div>
      <canvas
        ref={canvasRef}
        width={miniMapSize}
        height={miniMapSize}
        onClick={handleClick}
        className="cursor-pointer border border-slate-200 rounded"
      />
    </div>
  );
}