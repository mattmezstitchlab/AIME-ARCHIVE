import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { 
  X, Printer, FileText, Check, Loader2, 
  Accessibility, Palette, BookOpen, Grid3X3
} from 'lucide-react';
import { toast } from 'sonner';

const PRINT_MODES = [
  {
    id: 'standard',
    name: 'MODE STANDARD',
    description: '10×10 par page, symboles noirs renforcés, coordonnées visibles',
    icon: Grid3X3
  },
  {
    id: 'daltonien',
    name: 'MODE DALTONIEN',
    description: 'Contraste extrême, symboles surlignés, couleurs adaptées',
    icon: Accessibility
  },
  {
    id: 'color',
    name: 'MODE SUB COLOR',
    description: 'Impression couleur, palette SUB visible, légende incluse',
    icon: Palette
  }
];

const PAGE_FORMATS = [
  { id: 'a4', name: 'A4', width: 210, height: 297 },
  { id: 'letter', name: 'Letter', width: 216, height: 279 },
  { id: 'custom', name: 'Personnalisé', width: 200, height: 280 }
];

export default function SubPrintModule({ open, onClose, pattern, gridConfig }) {
  const [printMode, setPrintMode] = useState('standard');
  const [pageFormat, setPageFormat] = useState('a4');
  const [options, setOptions] = useState({
    includeCover: true,
    includePalette: true,
    autoMargins: true,
    gridSize: 10 // 10x10 par section
  });
  const [isPrinting, setIsPrinting] = useState(false);

  const handlePrint = async () => {
    if (!pattern) {
      toast.error('Aucune grille à imprimer');
      return;
    }

    setIsPrinting(true);

    try {
      const { jsPDF } = await import('jspdf');
      
      const format = PAGE_FORMATS.find(f => f.id === pageFormat);
      const isLandscape = pattern.width > pattern.height;
      
      const doc = new jsPDF({
        orientation: isLandscape ? 'landscape' : 'portrait',
        unit: 'mm',
        format: pageFormat === 'custom' ? [format.width, format.height] : pageFormat
      });

      const pageWidth = doc.internal.pageSize.getWidth();
      const pageHeight = doc.internal.pageSize.getHeight();
      const margin = options.autoMargins ? 15 : 10;

      // === PAGE COUVERTURE ===
      if (options.includeCover) {
        // Titre
        doc.setFontSize(28);
        doc.setFont('helvetica', 'bold');
        doc.text(gridConfig?.name || 'Grille SUB', pageWidth / 2, 50, { align: 'center' });

        // Auteur
        doc.setFontSize(14);
        doc.setFont('helvetica', 'normal');
        doc.text('Créé avec PatyBee SUB™', pageWidth / 2, 65, { align: 'center' });

        // Dimensions
        doc.setFontSize(12);
        doc.text(`Dimensions : ${pattern.width} × ${pattern.height} points`, pageWidth / 2, 85, { align: 'center' });
        doc.text(`Couleurs : ${pattern.colorPalette?.length || 0} DMC`, pageWidth / 2, 95, { align: 'center' });

        // Aperçu miniature
        const miniSize = 60;
        const miniX = (pageWidth - miniSize) / 2;
        const miniY = 110;
        
        doc.setDrawColor(200);
        doc.setLineWidth(0.5);
        doc.rect(miniX, miniY, miniSize, miniSize * (pattern.height / pattern.width));

        // Badge SUB
        doc.setFillColor(250, 204, 21);
        doc.roundedRect(pageWidth / 2 - 25, 190, 50, 15, 3, 3, 'F');
        doc.setFontSize(10);
        doc.setFont('helvetica', 'bold');
        doc.setTextColor(0, 0, 0);
        doc.text('✅ Certifié SUB', pageWidth / 2, 200, { align: 'center' });
        doc.setTextColor(0, 0, 0);

        doc.addPage();
      }

      // === PAGE PALETTE SUB ===
      if (options.includePalette && pattern.colorPalette) {
        doc.setFontSize(18);
        doc.setFont('helvetica', 'bold');
        doc.text('Palette SUB', margin, 25);

        doc.setFontSize(10);
        doc.setFont('helvetica', 'normal');

        let y = 40;
        const colWidth = (pageWidth - margin * 2) / 3;

        pattern.colorPalette.forEach((color, idx) => {
          const col = idx % 3;
          const x = margin + col * colWidth;

          if (col === 0 && idx > 0) y += 20;
          if (y > pageHeight - 30) {
            doc.addPage();
            y = 25;
          }

          // Carré couleur
          const rgb = hexToRgb(color.hex || color.dmcHex || '#cccccc');
          doc.setFillColor(rgb.r, rgb.g, rgb.b);
          doc.rect(x, y - 4, 8, 8, 'F');
          doc.setDrawColor(100);
          doc.rect(x, y - 4, 8, 8, 'S');

          // Infos
          doc.setFontSize(9);
          doc.text(`${color.code || color.dmc || 'DMC'}`, x + 12, y);
          doc.text(`${color.symbol || color.assignedSymbolChar || '●'}`, x + 45, y);
          doc.text(`${color.totalCount || color.count || 0} pts`, x + 55, y);
        });

        doc.addPage();
      }

      // === PAGES DE GRILLE ===
      const cellsPerPage = options.gridSize;
      const availableWidth = pageWidth - margin * 2;
      const availableHeight = pageHeight - margin * 2 - 15; // Espace pour numéros
      const cellSize = Math.min(availableWidth / cellsPerPage, availableHeight / cellsPerPage);

      const pagesX = Math.ceil(pattern.width / cellsPerPage);
      const pagesY = Math.ceil(pattern.height / cellsPerPage);

      for (let py = 0; py < pagesY; py++) {
        for (let px = 0; px < pagesX; px++) {
          const startCol = px * cellsPerPage;
          const startRow = py * cellsPerPage;
          const endCol = Math.min(startCol + cellsPerPage, pattern.width);
          const endRow = Math.min(startRow + cellsPerPage, pattern.height);

          // Coordonnées
          doc.setFontSize(8);
          doc.setFont('helvetica', 'normal');
          doc.text(`Section ${px + 1}-${py + 1} | Colonnes ${startCol + 1}-${endCol} | Lignes ${startRow + 1}-${endRow}`, margin, 10);

          // Numéros de colonnes
          for (let c = startCol; c < endCol; c++) {
            const x = margin + (c - startCol) * cellSize + cellSize / 2;
            if ((c + 1) % 5 === 0 || c === startCol) {
              doc.text(String(c + 1), x, 18, { align: 'center' });
            }
          }

          // Dessiner les cellules
          for (let row = startRow; row < endRow; row++) {
            const y = margin + 10 + (row - startRow) * cellSize;

            // Numéro de ligne
            if ((row + 1) % 5 === 0 || row === startRow) {
              doc.text(String(row + 1), margin - 5, y + cellSize / 2 + 2, { align: 'right' });
            }

            for (let col = startCol; col < endCol; col++) {
              const x = margin + (col - startCol) * cellSize;
              const cell = pattern.symbolGrid?.[row]?.[col];

              // Fond de cellule
              if (cell && printMode === 'color') {
                const color = pattern.colorPalette?.find(c => c.id === cell.colorId);
                if (color) {
                  const rgb = hexToRgb(color.hex || color.dmcHex || '#ffffff');
                  doc.setFillColor(rgb.r, rgb.g, rgb.b);
                  doc.rect(x, y, cellSize, cellSize, 'F');
                }
              }

              // Bordure
              doc.setDrawColor(200);
              doc.setLineWidth(0.1);
              doc.rect(x, y, cellSize, cellSize, 'S');

              // Symbole
              if (cell) {
                const color = pattern.colorPalette?.find(c => c.id === cell.colorId);
                const symbol = cell.symbol || color?.symbol || color?.assignedSymbolChar || '●';

                doc.setFontSize(cellSize * 0.6);
                doc.setFont('helvetica', 'bold');

                if (printMode === 'daltonien') {
                  // Mode daltonien : symbole sur fond contrasté
                  doc.setFillColor(255, 255, 255);
                  doc.rect(x + 1, y + 1, cellSize - 2, cellSize - 2, 'F');
                  doc.setTextColor(0, 0, 0);
                } else if (printMode === 'color') {
                  // Mode couleur : symbole noir ou blanc selon contraste
                  const color = pattern.colorPalette?.find(c => c.id === cell.colorId);
                  const rgb = hexToRgb(color?.hex || '#ffffff');
                  const luminance = (0.299 * rgb.r + 0.587 * rgb.g + 0.114 * rgb.b) / 255;
                  doc.setTextColor(luminance > 0.5 ? 0 : 255);
                } else {
                  doc.setTextColor(0, 0, 0);
                }

                doc.text(symbol, x + cellSize / 2, y + cellSize / 2 + 2, { align: 'center' });
                doc.setTextColor(0, 0, 0);
              }
            }
          }

          // Lignes épaisses tous les 10
          doc.setDrawColor(0);
          doc.setLineWidth(0.5);
          for (let c = startCol; c <= endCol; c++) {
            if ((c - startCol) % 10 === 0 || c === endCol) {
              const x = margin + (c - startCol) * cellSize;
              doc.line(x, margin + 10, x, margin + 10 + (endRow - startRow) * cellSize);
            }
          }
          for (let r = startRow; r <= endRow; r++) {
            if ((r - startRow) % 10 === 0 || r === endRow) {
              const y = margin + 10 + (r - startRow) * cellSize;
              doc.line(margin, y, margin + (endCol - startCol) * cellSize, y);
            }
          }

          if (px < pagesX - 1 || py < pagesY - 1) {
            doc.addPage();
          }
        }
      }

      // Sauvegarder
      doc.save(`${gridConfig?.name || 'grille'}_SUB_PRINT.pdf`);
      toast.success('✅ SUB PRINT PRÊT — votre création peut être imprimée ou éditée.');

    } catch (error) {
      console.error('Erreur impression:', error);
      toast.error('Erreur lors de la génération du PDF');
    } finally {
      setIsPrinting(false);
    }
  };

  const hexToRgb = (hex) => {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
      r: parseInt(result[1], 16),
      g: parseInt(result[2], 16),
      b: parseInt(result[3], 16)
    } : { r: 200, g: 200, b: 200 };
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[99999] flex items-center justify-center bg-black/70">
      <div className="bg-white rounded-2xl shadow-2xl w-[600px] max-h-[85vh] overflow-hidden">
        {/* Header */}
        <div className="bg-black px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center">
              <Printer className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-lg font-black text-white">SUB PRINT</h2>
              <p className="text-sm text-gray-400">Imprimer comme un éditeur</p>
            </div>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center">
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6 overflow-y-auto" style={{ maxHeight: 'calc(85vh - 140px)' }}>
          {/* Mode d'impression */}
          <div className="space-y-3">
            <Label className="font-semibold">Mode d'impression</Label>
            <RadioGroup value={printMode} onValueChange={setPrintMode}>
              {PRINT_MODES.map(mode => {
                const ModeIcon = mode.icon;
                return (
                  <div
                    key={mode.id}
                    className={`flex items-start gap-3 p-3 rounded-lg border-2 cursor-pointer transition-all ${
                      printMode === mode.id ? 'border-black bg-gray-50' : 'border-gray-200 hover:border-gray-400'
                    }`}
                    onClick={() => setPrintMode(mode.id)}
                  >
                    <RadioGroupItem value={mode.id} id={mode.id} className="mt-1" />
                    <ModeIcon className="w-5 h-5 mt-0.5 text-gray-600" />
                    <div className="flex-1">
                      <label htmlFor={mode.id} className="font-medium cursor-pointer">{mode.name}</label>
                      <p className="text-sm text-gray-500">{mode.description}</p>
                    </div>
                  </div>
                );
              })}
            </RadioGroup>
          </div>

          {/* Format de page */}
          <div className="space-y-3">
            <Label className="font-semibold">Format de page</Label>
            <div className="flex gap-2">
              {PAGE_FORMATS.map(format => (
                <button
                  key={format.id}
                  onClick={() => setPageFormat(format.id)}
                  className={`px-4 py-2 rounded-lg border-2 font-medium ${
                    pageFormat === format.id ? 'border-black bg-black text-white' : 'border-gray-200 hover:border-gray-400'
                  }`}
                >
                  {format.name}
                </button>
              ))}
            </div>
          </div>

          {/* Options */}
          <div className="space-y-3">
            <Label className="font-semibold">Options</Label>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="flex items-center gap-2">
                  <BookOpen className="w-4 h-4" />
                  Page couverture
                </Label>
                <Switch 
                  checked={options.includeCover} 
                  onCheckedChange={(v) => setOptions(p => ({...p, includeCover: v}))} 
                />
              </div>
              <div className="flex items-center justify-between">
                <Label className="flex items-center gap-2">
                  <Palette className="w-4 h-4" />
                  Page palette SUB
                </Label>
                <Switch 
                  checked={options.includePalette} 
                  onCheckedChange={(v) => setOptions(p => ({...p, includePalette: v}))} 
                />
              </div>
              <div className="flex items-center justify-between">
                <Label>Marges imprimante automatiques</Label>
                <Switch 
                  checked={options.autoMargins} 
                  onCheckedChange={(v) => setOptions(p => ({...p, autoMargins: v}))} 
                />
              </div>
            </div>
          </div>

          {/* Grille par page */}
          <div className="space-y-3">
            <Label className="font-semibold">Cases par section</Label>
            <div className="flex gap-2">
              {[10, 15, 20, 25].map(size => (
                <button
                  key={size}
                  onClick={() => setOptions(p => ({...p, gridSize: size}))}
                  className={`px-4 py-2 rounded-lg border-2 font-medium ${
                    options.gridSize === size ? 'border-black bg-black text-white' : 'border-gray-200 hover:border-gray-400'
                  }`}
                >
                  {size}×{size}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t bg-gray-50 flex items-center justify-between">
          <p className="text-xs text-gray-500">
            Format: PDF Haute Définition
          </p>
          <div className="flex gap-3">
            <Button variant="outline" onClick={onClose}>Annuler</Button>
            <Button 
              onClick={handlePrint} 
              disabled={isPrinting || !pattern}
              className="bg-blue-600 hover:bg-blue-700 gap-2"
            >
              {isPrinting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Printer className="w-4 h-4" />}
              Générer PDF
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}