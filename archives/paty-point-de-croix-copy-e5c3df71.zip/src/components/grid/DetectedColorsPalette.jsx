import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { Eye, Palette, TrendingUp, ChevronDown, ChevronUp } from 'lucide-react';
import { useState } from 'react';

export default function DetectedColorsPalette({ 
  colorPalette,
  showImage,
  onToggleImage,
  showSymbols,
  onToggleSymbols,
  showGrid,
  onToggleGrid
}) {
  const [showDisplaySection, setShowDisplaySection] = useState(true);
  const [showColorsSection, setShowColorsSection] = useState(true);
  const [showProgressSection, setShowProgressSection] = useState(true);

  // Calculer la progression globale
  const totalStitches = colorPalette?.reduce((sum, color) => sum + (color.totalCount || 0), 0) || 0;
  const doneStitches = colorPalette?.reduce((sum, color) => sum + (color.doneCount || 0), 0) || 0;
  const globalProgress = totalStitches > 0 ? Math.round((doneStitches / totalStitches) * 100) : 0;

  return (
    <TooltipProvider delayDuration={500}>
      <div className="space-y-4">
      {/* Section Affichage */}
      <Card className="bg-white rounded-xl shadow-sm border border-slate-200">
        <CardHeader 
          className="pb-2 cursor-pointer"
          onClick={() => setShowDisplaySection(!showDisplaySection)}
        >
          <CardTitle className="text-sm font-semibold text-slate-700 uppercase tracking-wide flex items-center justify-between">
            <span className="flex items-center gap-2">
              <Eye className="w-4 h-4" />
              Affichage
            </span>
            {showDisplaySection ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </CardTitle>
        </CardHeader>
        
        {showDisplaySection && (
          <CardContent className="space-y-3 pt-2">
            <Tooltip>
              <TooltipTrigger asChild>
                <div className="flex items-center justify-between">
                  <Label htmlFor="show-image" className="text-sm font-medium">
                    Visuel importé
                  </Label>
                  <Switch
                    id="show-image"
                    checked={showImage}
                    onCheckedChange={onToggleImage}
                  />
                </div>
              </TooltipTrigger>
              <TooltipContent side="left">
                <p>Afficher ou masquer l'image de référence</p>
              </TooltipContent>
            </Tooltip>
            
            <Tooltip>
              <TooltipTrigger asChild>
                <div className="flex items-center justify-between">
                  <Label htmlFor="show-symbols" className="text-sm font-medium">
                    Symboles
                  </Label>
                  <Switch
                    id="show-symbols"
                    checked={showSymbols}
                    onCheckedChange={onToggleSymbols}
                  />
                </div>
              </TooltipTrigger>
              <TooltipContent side="left">
                <p>Afficher ou masquer les symboles dans la grille</p>
              </TooltipContent>
            </Tooltip>
            
            <Tooltip>
              <TooltipTrigger asChild>
                <div className="flex items-center justify-between">
                  <Label htmlFor="show-grid" className="text-sm font-medium">
                    Grille
                  </Label>
                  <Switch
                    id="show-grid"
                    checked={showGrid}
                    onCheckedChange={onToggleGrid}
                  />
                </div>
              </TooltipTrigger>
              <TooltipContent side="left">
                <p>Afficher ou masquer les lignes de la grille</p>
              </TooltipContent>
            </Tooltip>
            
            <div className="flex items-center justify-between opacity-50">
              <Label className="text-sm font-medium text-slate-500">
                Repère central ●
              </Label>
              <Switch
                checked={true}
                disabled
              />
            </div>
          </CardContent>
        )}
      </Card>

      {/* Section Couleurs détectées (résumé) */}
      {colorPalette && colorPalette.length > 0 && (
        <Card className="bg-white rounded-xl shadow-sm border border-slate-200">
          <CardHeader 
            className="pb-2 cursor-pointer"
            onClick={() => setShowColorsSection(!showColorsSection)}
          >
            <CardTitle className="text-sm font-semibold text-slate-700 uppercase tracking-wide flex items-center justify-between">
              <span className="flex items-center gap-2">
                <Palette className="w-4 h-4" />
                Couleurs détectées
              </span>
              {showColorsSection ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </CardTitle>
          </CardHeader>
          
          {showColorsSection && (
            <CardContent className="pt-2 space-y-3">
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="text-sm px-2 py-1">
                  {colorPalette.length} couleurs
                </Badge>
              </div>

              {/* Aperçu miniature des 3 premières couleurs */}
              <div className="flex gap-2">
                {colorPalette.slice(0, 3).map((color) => (
                  <div key={color.id} className="flex items-center gap-1">
                    <div
                      className="w-6 h-6 rounded border border-slate-300"
                      style={{ backgroundColor: color.hex }}
                    />
                    <span className="text-sm font-bold">{color.assignedSymbolChar}</span>
                  </div>
                ))}
                {colorPalette.length > 3 && (
                  <span className="text-xs text-slate-500 self-center">
                    +{colorPalette.length - 3} autres
                  </span>
                )}
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-2 text-xs text-blue-900">
                👇 Voir toutes les couleurs dans la palette en bas
              </div>
            </CardContent>
          )}
        </Card>
      )}

      {/* Section Progression */}
      {colorPalette && colorPalette.length > 0 && (
        <Card className="bg-white rounded-xl shadow-sm border border-slate-200">
          <CardHeader 
            className="pb-2 cursor-pointer"
            onClick={() => setShowProgressSection(!showProgressSection)}
          >
            <CardTitle className="text-sm font-semibold text-slate-700 uppercase tracking-wide flex items-center justify-between">
              <span className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4" />
                Progression
              </span>
              {showProgressSection ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </CardTitle>
          </CardHeader>
          
          {showProgressSection && (
            <CardContent className="pt-2 space-y-3">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-600">Progression globale</span>
                  <Badge 
                    className={`${
                      globalProgress === 100 
                        ? 'bg-green-600' 
                        : globalProgress > 50 
                        ? 'bg-blue-600' 
                        : 'bg-amber-600'
                    } text-white`}
                  >
                    {globalProgress}%
                  </Badge>
                </div>

                {/* Barre de progression */}
                <div className="w-full bg-slate-200 rounded-full h-2">
                  <div
                    className={`h-2 rounded-full transition-all ${
                      globalProgress === 100 
                        ? 'bg-green-600' 
                        : globalProgress > 50 
                        ? 'bg-blue-600' 
                        : 'bg-amber-600'
                    }`}
                    style={{ width: `${globalProgress}%` }}
                  />
                </div>

                <div className="text-xs text-slate-600">
                  {doneStitches} / {totalStitches} points brodés
                </div>
              </div>
            </CardContent>
          )}
        </Card>
      )}
      </div>
    </TooltipProvider>
  );
}