import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, X, Upload, Palette, MousePointer, Download, Map, Sparkles, CreditCard } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '../../utils';

const SLIDES = [
  {
    icon: Upload,
    title: "Importer un motif",
    text: "Cliquez sur le bouton Import pour charger une image ou un PDF. PatyBee convertit automatiquement votre visuel en grille de point de croix."
  },
  {
    icon: Palette,
    title: "Palette de couleurs",
    text: "La palette DMC s'affiche en bas de l'écran. Cliquez sur une couleur pour la sélectionner et visualiser tous ses points dans la grille."
  },
  {
    icon: MousePointer,
    title: "Navigation",
    text: "Utilisez la molette pour zoomer, cliquez et glissez pour vous déplacer. La barre d'outils offre des contrôles de zoom et de centrage."
  },
  {
    icon: Map,
    title: "Mini-carte",
    text: "La mini-carte en bas à droite vous permet de naviguer rapidement dans votre grille et de voir votre position actuelle."
  },
  {
    icon: Sparkles,
    title: "Assistant PatyBee",
    text: "Cliquez sur le bouton IA dans la barre d'outils pour discuter avec PatyBee, votre assistant intelligent qui vous guide."
  },
  {
    icon: Download,
    title: "Exporter",
    text: "Une fois satisfait, exportez votre grille en PDF haute définition ou en image PNG pour l'imprimer ou la partager."
  }
];

export default function FloatingTutorialCarousel({ isOpen, onClose, onImport }) {
  const [currentSlide, setCurrentSlide] = useState(0);
  const navigate = useNavigate();

  useEffect(() => {
    if (isOpen) setCurrentSlide(0);
  }, [isOpen]);

  if (!isOpen) return null;

  const slide = SLIDES[currentSlide];
  const Icon = slide.icon;

  const goNext = () => setCurrentSlide((prev) => (prev + 1) % SLIDES.length);
  const goPrev = () => setCurrentSlide((prev) => (prev - 1 + SLIDES.length) % SLIDES.length);

  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center pointer-events-none">
      {/* Backdrop semi-transparent */}
      <div 
        className="absolute inset-0 bg-black/40 pointer-events-auto"
        onClick={onClose}
      />
      
      {/* Carrousel flottant */}
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-lg mx-4 pointer-events-auto overflow-hidden">
        {/* Bouton fermer */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center transition-colors z-10"
        >
          <X className="w-4 h-4 text-slate-600" />
        </button>

        {/* Header */}
        <div className="bg-gradient-to-r from-yellow-400 to-yellow-500 px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-white/20 flex items-center justify-center">
              <Icon className="w-5 h-5 text-black" />
            </div>
            <div>
              <p className="text-xs text-black/60 font-medium">Étape {currentSlide + 1}/{SLIDES.length}</p>
              <h3 className="text-lg font-bold text-black">{slide.title}</h3>
            </div>
          </div>
        </div>

        {/* Contenu */}
        <div className="p-6">
          <p className="text-slate-600 leading-relaxed">{slide.text}</p>
        </div>

        {/* Navigation */}
        <div className="px-6 pb-6 flex items-center justify-between">
          {/* Indicateurs */}
          <div className="flex gap-1.5">
            {SLIDES.map((_, idx) => (
              <button
                key={idx}
                onClick={() => setCurrentSlide(idx)}
                className={`h-1.5 rounded-full transition-all ${
                  idx === currentSlide ? 'w-6 bg-yellow-500' : 'w-1.5 bg-slate-200 hover:bg-slate-300'
                }`}
              />
            ))}
          </div>

          {/* Boutons navigation */}
          <div className="flex gap-2">
            <button
              onClick={goPrev}
              className="w-9 h-9 rounded-lg bg-slate-100 hover:bg-slate-200 flex items-center justify-center transition-colors"
            >
              <ChevronLeft className="w-4 h-4 text-slate-600" />
            </button>
            
            {currentSlide === SLIDES.length - 1 ? (
              <div className="flex gap-2">
                <Button
                  onClick={() => {
                    onClose();
                    if (onImport) onImport();
                  }}
                  className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold px-4"
                >
                  Commencer
                </Button>
                <Button
                  onClick={() => {
                    onClose();
                    navigate(createPageUrl('Pricing'));
                  }}
                  variant="outline"
                  className="border-yellow-500 text-yellow-600 hover:bg-yellow-50 font-semibold px-4"
                >
                  <CreditCard className="w-4 h-4 mr-2" />
                  S'abonner
                </Button>
              </div>
            ) : (
              <button
                onClick={goNext}
                className="w-9 h-9 rounded-lg bg-slate-100 hover:bg-slate-200 flex items-center justify-center transition-colors"
              >
                <ChevronRight className="w-4 h-4 text-slate-600" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}