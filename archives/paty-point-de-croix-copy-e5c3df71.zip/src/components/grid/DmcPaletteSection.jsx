import React, { useState } from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

const BeeIcon = ({ className }) => (
  <svg className={cn("w-4 h-4", className)} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M12 4c-2 0-3 1-3 3v2c0 1 0 2 1 3l-2 2c-1 0-2 1-2 2v2c0 2 1 3 3 3h6c2 0 3-1 3-3v-2c0-1-1-2-2-2l-2-2c1-1 1-2 1-3V7c0-2-1-3-3-3z" />
    <circle cx="12" cy="12" r="1" fill="currentColor" />
  </svg>
);

export default function DmcPaletteSection({ colorPalette = [] }) {
  const [filter, setFilter] = useState('all');
  const [sortBy, setSortBy] = useState('count');

  // Filtrage
  let filteredColors = [...colorPalette];
  if (filter === 'low') {
    filteredColors = filteredColors.filter(c => (c.totalCount || 0) < 50);
  } else if (filter === 'high') {
    filteredColors = filteredColors.filter(c => (c.totalCount || 0) >= 50);
  }

  // Tri
  filteredColors.sort((a, b) => {
    if (sortBy === 'count') return (b.totalCount || 0) - (a.totalCount || 0);
    if (sortBy === 'dmc') return (a.code || '').localeCompare(b.code || '');
    if (sortBy === 'symbol') return (a.assignedSymbolChar || '').localeCompare(b.assignedSymbolChar || '');
    return 0;
  });

  return (
    <div className="space-y-4">
      {/* Titre */}
      <h2 className="text-xl font-bold text-slate-900">Palette DMC complète</h2>

      {/* Filtres et tri */}
      <div className="flex gap-3">
        <Select value={filter} onValueChange={setFilter}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="Filtrer" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Toutes</SelectItem>
            <SelectItem value="low">Peu utilisées</SelectItem>
            <SelectItem value="high">Souvent utilisées</SelectItem>
          </SelectContent>
        </Select>

        <Select value={sortBy} onValueChange={setSortBy}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="Trier par" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="count">Nombre de points</SelectItem>
            <SelectItem value="dmc">Code DMC</SelectItem>
            <SelectItem value="symbol">Symboles</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Grille de couleurs */}
      <div className="grid grid-cols-8 gap-2.5">
        {filteredColors.map((color) => (
          <div
            key={color.id}
            className="bg-white border border-slate-200 rounded-lg p-2 hover:shadow-md transition-shadow"
          >
            {/* Rectangle de couleur */}
            <div
              className="w-full h-[46px] rounded-md mb-2"
              style={{ backgroundColor: color.hex }}
            />

            {/* Rectangle symbole */}
            <div className="w-8 h-8 bg-white border border-slate-200 rounded flex items-center justify-center mb-2 mx-auto">
              <span className="text-lg font-bold text-slate-800">
                {color.assignedSymbolChar || '●'}
              </span>
            </div>

            {/* Code DMC */}
            <div className="text-xs font-semibold text-slate-900 text-center mb-1">
              DMC {color.code || '???'}
            </div>

            {/* Nombre de points */}
            <div className="text-xs text-slate-600 text-center mb-2">
              {color.totalCount || 0} pts
            </div>

            {/* Bouton alvéole */}
            <Button
              variant="ghost"
              size="sm"
              className="w-full h-7 text-amber-600 hover:text-amber-700 hover:bg-amber-50"
            >
              <BeeIcon className="w-3.5 h-3.5" />
            </Button>
          </div>
        ))}
      </div>

      {filteredColors.length === 0 && (
        <div className="text-center py-8 text-slate-500">
          Aucune couleur ne correspond aux filtres sélectionnés
        </div>
      )}
    </div>
  );
}