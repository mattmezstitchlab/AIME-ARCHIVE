import React, { useState } from 'react';
import { useColorPalette } from './ColorPaletteContext';
import { cn } from '@/lib/utils';
import { 
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';

export default function GlobalColorPalette() {
  const { palette, isVisible } = useColorPalette();
  const [selectedColorId, setSelectedColorId] = useState(null);

  if (!isVisible || !palette || palette.length === 0) {
    return null;
  }

  const handleColorSelect = (colorId) => {
    setSelectedColorId(prev => prev === colorId ? null : colorId);
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-gradient-to-b from-slate-50 to-slate-100 border-t border-slate-300 shadow-2xl z-[2000]">
      <div className="h-[110px] overflow-x-auto overflow-y-hidden px-4">
        <div className="h-full flex items-end gap-3 pb-3">
          {palette.map((color) => {
            const isCompleted = color.progress === 100;
            const isSelected = selectedColorId === color.id;
            
            return (
              <TooltipProvider key={color.id}>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <button
                      onClick={() => handleColorSelect(color.id)}
                      className={cn(
                        "flex-shrink-0 w-28 transition-all relative group",
                        isSelected && "drop-shadow-xl"
                      )}
                    >
                      {/* Carré blanc avec symbole au-dessus */}
                      <div className={cn(
                        "w-full h-12 bg-white rounded-t-lg shadow-md flex items-center justify-center mb-0.5 relative",
                        isSelected && "ring-2 ring-slate-400"
                      )}>
                        <span className="font-bold text-slate-900 text-2xl">
                          {color.assignedSymbolChar || '●'}
                        </span>
                        {isCompleted && (
                          <div className="absolute top-1 right-1 w-4 h-4 bg-green-500 rounded-full flex items-center justify-center">
                            <span className="text-white text-xs">✓</span>
                          </div>
                        )}
                      </div>

                      {/* Languette colorée */}
                      <div 
                        className="w-full h-16 rounded-b-lg shadow-lg relative overflow-hidden"
                        style={{ backgroundColor: color.hex }}
                      >
                        {/* Infos texte */}
                        <div className="absolute top-1 left-0 right-0 px-2">
                          <div className="flex justify-between items-start text-[9px] font-semibold text-white drop-shadow-md">
                            <span>{color.code || 'DMC'}</span>
                            <span>{color.totalCount || 0} pts</span>
                          </div>
                          <div className="text-[10px] font-medium text-white drop-shadow-md mt-1 text-center truncate">
                            {color.name || 'Sans nom'}
                          </div>
                        </div>

                        {/* Barre de progression */}
                        {color.progress > 0 && (
                          <div className="absolute bottom-0 left-0 right-0 h-2 bg-black/20">
                            <div 
                              className="h-full bg-white/90"
                              style={{ width: `${color.progress}%` }}
                            />
                          </div>
                        )}
                      </div>
                    </button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <div className="text-xs">
                      <div className="font-bold">{color.name || color.code}</div>
                      <div>{color.totalCount} pts – {color.progress}% brodé</div>
                    </div>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            );
          })}
        </div>
      </div>
    </div>
  );
}