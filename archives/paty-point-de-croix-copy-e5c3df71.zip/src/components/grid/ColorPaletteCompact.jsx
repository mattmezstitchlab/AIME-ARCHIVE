import React from 'react';
import { Check } from 'lucide-react';
import { cn } from '@/lib/utils';

// Palette de couleurs DMC complète
const DMC_COLORS = [
  // Blanc et Noir
  { code: 'BLANC', name: 'Blanc', hex: '#FFFFFF' },
  { code: 'ECRU', name: 'Écru', hex: '#F3E7D3' },
  { code: 'B5200', name: 'Blanc neige', hex: '#FAFAFA' },
  { code: '310', name: 'Noir', hex: '#000000' },
  
  // Jaunes
  { code: '3078', name: 'Jaune pâle', hex: '#FFF7C7' },
  { code: '727', name: 'Jaune clair', hex: '#FFF8B8' },
  { code: '744', name: 'Jaune citron pâle', hex: '#FFED9B' },
  { code: '745', name: 'Jaune clair', hex: '#FFE8A4' },
  { code: '3823', name: 'Jaune crème', hex: '#FFEBB9' },
  { code: '677', name: 'Vieux or clair', hex: '#F3E1A4' },
  { code: '422', name: 'Noisette clair', hex: '#D7A36A' },
  { code: '3820', name: 'Or paille', hex: '#E6AE5C' },
  { code: '3852', name: 'Or foncé', hex: '#D89C4D' },
  { code: '972', name: 'Jaune canari', hex: '#FFB619' },
  { code: '973', name: 'Jaune vif', hex: '#FFD700' },
  { code: '307', name: 'Jaune citron', hex: '#FFD500' },
  { code: '743', name: 'Jaune moyen', hex: '#FFC734' },
  { code: '444', name: 'Jaune citron foncé', hex: '#FFB700' },
  { code: '3821', name: 'Or', hex: '#D89835' },
  { code: '742', name: 'Tangerine clair', hex: '#FFBA4D' },
  { code: '741', name: 'Orange', hex: '#FF8800' },
  { code: '740', name: 'Orange vif', hex: '#FF7700' },
  { code: '947', name: 'Brûlé', hex: '#FF6A00' },
  { code: '970', name: 'Citrouille', hex: '#FF5500' },
  { code: '946', name: 'Orange brûlé', hex: '#DD5A2A' },
  { code: '900', name: 'Orange foncé', hex: '#D67231' },
  { code: '608', name: 'Orange vif', hex: '#FF6600' },
  { code: '606', name: 'Rouge orange', hex: '#FF4500' },
  
  // Rouges
  { code: '3708', name: 'Rouge pastèque clair', hex: '#FFA6C0' },
  { code: '3706', name: 'Rouge pastèque', hex: '#FF8FA6' },
  { code: '3705', name: 'Rouge pastèque foncé', hex: '#FF6A8A' },
  { code: '3801', name: 'Rouge pastèque très foncé', hex: '#E94568' },
  { code: '666', name: 'Rouge vif', hex: '#E3242B' },
  { code: '321', name: 'Rouge', hex: '#C1082A' },
  { code: '304', name: 'Rouge moyen', hex: '#AF0032' },
  { code: '498', name: 'Rouge foncé', hex: '#8E0032' },
  { code: '816', name: 'Grenat', hex: '#7A0028' },
  { code: '815', name: 'Grenat moyen', hex: '#640021' },
  { code: '814', name: 'Grenat foncé', hex: '#560021' },
  { code: '817', name: 'Rouge coquelicot', hex: '#BD0A2C' },
  { code: '3831', name: 'Framboise', hex: '#B8315C' },
  { code: '3777', name: 'Terra cotta', hex: '#A64536' },
  { code: '356', name: 'Terra cotta moyen', hex: '#C16455' },
  { code: '355', name: 'Terra cotta foncé', hex: '#8E3D35' },
  
  // Roses
  { code: '819', name: 'Rose pâle', hex: '#FFE0E8' },
  { code: '818', name: 'Rose clair', hex: '#FFCBD9' },
  { code: '957', name: 'Rose pâle', hex: '#FFAFCE' },
  { code: '963', name: 'Rose très clair', hex: '#FFABC5' },
  { code: '3716', name: 'Rose moyen clair', hex: '#FF95B7' },
  { code: '962', name: 'Rose moyen', hex: '#E67AA3' },
  { code: '961', name: 'Rose foncé', hex: '#D4598F' },
  { code: '3833', name: 'Framboise clair', hex: '#E65C8C' },
  { code: '3832', name: 'Framboise', hex: '#DD457F' },
  { code: '3350', name: 'Rose foncé', hex: '#C5406E' },
  { code: '150', name: 'Rose très foncé', hex: '#AA2D5B' },
  { code: '3326', name: 'Rose', hex: '#F58BA2' },
  { code: '899', name: 'Rose vif', hex: '#E93479' },
  { code: '335', name: 'Rose', hex: '#D42A5F' },
  { code: '326', name: 'Rose très foncé', hex: '#BE1E52' },
  { code: '309', name: 'Rose foncé', hex: '#AF0A42' },
  
  // Prunes et Violets
  { code: '718', name: 'Prune', hex: '#A51A4F' },
  { code: '917', name: 'Prune moyen', hex: '#890D3A' },
  { code: '915', name: 'Prune foncé', hex: '#6E0830' },
  { code: '3687', name: 'Mauve', hex: '#C57C8E' },
  { code: '3685', name: 'Mauve foncé', hex: '#963A57' },
  { code: '3607', name: 'Prune clair', hex: '#C54F7B' },
  { code: '3609', name: 'Prune très clair', hex: '#E59FC7' },
  { code: '3608', name: 'Prune moyen', hex: '#DC79AE' },
  { code: '553', name: 'Violet', hex: '#A37FB0' },
  { code: '554', name: 'Violet clair', hex: '#D4A0D0' },
  { code: '208', name: 'Lavande', hex: '#7B4D8E' },
  { code: '209', name: 'Lavande foncé', hex: '#A285B8' },
  { code: '210', name: 'Lavande moyen', hex: '#C9B3D6' },
  { code: '211', name: 'Lavande clair', hex: '#E1D5E7' },
  { code: '550', name: 'Violet foncé', hex: '#4A264A' },
  { code: '552', name: 'Violet moyen', hex: '#6D4373' },
  { code: '3746', name: 'Violet bleu', hex: '#9B7FB9' },
  { code: '333', name: 'Bleu violet', hex: '#5A437D' },
  { code: '340', name: 'Bleu violet moyen', hex: '#9C87B5' },
  { code: '3747', name: 'Bleu violet clair', hex: '#D8D6E8' },
  
  // Bleus
  { code: '157', name: 'Bleu clair', hex: '#C5DCE8' },
  { code: '3756', name: 'Bleu très clair', hex: '#DDEAF4' },
  { code: '828', name: 'Bleu ciel', hex: '#B5D9E8' },
  { code: '800', name: 'Bleu clair', hex: '#8CB8D0' },
  { code: '809', name: 'Bleu Delft', hex: '#8EB8CA' },
  { code: '3325', name: 'Bleu ciel', hex: '#A6C6DB' },
  { code: '3755', name: 'Bleu', hex: '#8DB3CA' },
  { code: '519', name: 'Bleu ciel', hex: '#7FA3D1' },
  { code: '518', name: 'Bleu clair', hex: '#5C8AA8' },
  { code: '3760', name: 'Bleu turquoise', hex: '#4D8BA6' },
  { code: '3766', name: 'Bleu paon', hex: '#3A7A97' },
  { code: '996', name: 'Cyan', hex: '#00AFCC' },
  { code: '3843', name: 'Bleu électrique', hex: '#00B2D6' },
  { code: '995', name: 'Bleu électrique foncé', hex: '#0093B2' },
  { code: '3846', name: 'Turquoise', hex: '#05AABC' },
  { code: '3845', name: 'Turquoise moyen', hex: '#009EB4' },
  { code: '3844', name: 'Turquoise foncé', hex: '#008899' },
  { code: '798', name: 'Bleu roi', hex: '#2B4E9A' },
  { code: '797', name: 'Bleu roi', hex: '#21467A' },
  { code: '796', name: 'Bleu roi foncé', hex: '#1A3A66' },
  { code: '820', name: 'Bleu roi très foncé', hex: '#133152' },
  { code: '825', name: 'Bleu marine', hex: '#2A4275' },
  { code: '824', name: 'Bleu très foncé', hex: '#1C3857' },
  { code: '823', name: 'Bleu marine foncé', hex: '#152E4A' },
  { code: '939', name: 'Bleu marine très foncé', hex: '#0F2438' },
  { code: '322', name: 'Bleu clair', hex: '#5B8FBF' },
  { code: '312', name: 'Bleu marine clair', hex: '#2E5A7A' },
  { code: '803', name: 'Bleu ultra foncé', hex: '#1A3C5A' },
  { code: '336', name: 'Bleu marine', hex: '#1F4A6B' },
  
  // Verts
  { code: '3761', name: 'Bleu ciel clair', hex: '#C5E3E8' },
  { code: '3811', name: 'Turquoise clair', hex: '#A8DCE1' },
  { code: '959', name: 'Bleu-vert moyen', hex: '#8BC9C9' },
  { code: '958', name: 'Bleu-vert', hex: '#5FACAE' },
  { code: '3849', name: 'Vert turquoise', hex: '#52A9A3' },
  { code: '3848', name: 'Vert turquoise moyen', hex: '#448B85' },
  { code: '3847', name: 'Vert turquoise foncé', hex: '#327672' },
  { code: '964', name: 'Vert d\'eau', hex: '#C5E5E4' },
  { code: '992', name: 'Vert turquoise', hex: '#00A896' },
  { code: '943', name: 'Vert turquoise moyen', hex: '#008E7D' },
  { code: '3768', name: 'Gris-vert foncé', hex: '#447074' },
  { code: '3812', name: 'Vert très foncé', hex: '#00524C' },
  { code: '561', name: 'Vert de gris', hex: '#1F5E4F' },
  { code: '562', name: 'Vert de gris moyen', hex: '#3A7A6E' },
  { code: '563', name: 'Vert de gris clair', hex: '#80B9AD' },
  { code: '564', name: 'Vert très clair', hex: '#AEDBC9' },
  { code: '912', name: 'Vert émeraude', hex: '#00865F' },
  { code: '911', name: 'Vert émeraude moyen', hex: '#007252' },
  { code: '910', name: 'Vert émeraude foncé', hex: '#005E43' },
  { code: '909', name: 'Vert', hex: '#008940' },
  { code: '3818', name: 'Vert très foncé', hex: '#006638' },
  { code: '368', name: 'Vert clair', hex: '#8DC780' },
  { code: '320', name: 'Vert pistache moyen', hex: '#59A27B' },
  { code: '367', name: 'Vert pistache foncé', hex: '#427850' },
  { code: '319', name: 'Vert pistache très foncé', hex: '#2D5A3A' },
  { code: '890', name: 'Vert sapin', hex: '#195028' },
  { code: '704', name: 'Vert pomme', hex: '#91B93D' },
  { code: '703', name: 'Vert chartreuse', hex: '#7AA12E' },
  { code: '702', name: 'Vert Kelly', hex: '#478F27' },
  { code: '701', name: 'Vert Kelly moyen', hex: '#3D7D1E' },
  { code: '700', name: 'Vert moyen', hex: '#2F6A19' },
  { code: '699', name: 'Vert foncé', hex: '#1F5715' },
  { code: '907', name: 'Vert pomme clair', hex: '#C5DB3D' },
  { code: '906', name: 'Vert pomme moyen', hex: '#8FB828' },
  { code: '905', name: 'Vert perroquet', hex: '#669F17' },
  { code: '904', name: 'Vert perroquet foncé', hex: '#4E8412' },
  { code: '472', name: 'Vert avocat clair', hex: '#C8E265' },
  { code: '471', name: 'Vert avocat', hex: '#A6C754' },
  { code: '470', name: 'Vert avocat moyen', hex: '#84A744' },
  { code: '469', name: 'Vert avocat foncé', hex: '#667C32' },
  { code: '937', name: 'Vert avocat très foncé', hex: '#4A5A25' },
  { code: '936', name: 'Vert très foncé', hex: '#3D4A1F' },
  
  // Marrons
  { code: '3865', name: 'Écru foncé', hex: '#F9EAD7' },
  { code: '739', name: 'Crème', hex: '#F8E6C9' },
  { code: '738', name: 'Tan très clair', hex: '#EFD9B3' },
  { code: '437', name: 'Tan clair', hex: '#E5C097' },
  { code: '436', name: 'Tan', hex: '#D1A46A' },
  { code: '435', name: 'Brun clair', hex: '#B88551' },
  { code: '434', name: 'Brun', hex: '#996633' },
  { code: '433', name: 'Brun moyen', hex: '#7A4F27' },
  { code: '801', name: 'Café', hex: '#5E3A1E' },
  { code: '898', name: 'Café très foncé', hex: '#4A2B14' },
  { code: '938', name: 'Marron', hex: '#5B3A29' },
  { code: '3371', name: 'Marron noir', hex: '#3D2314' },
  { code: '951', name: 'Pêche', hex: '#FFCFA0' },
  { code: '945', name: 'Chair', hex: '#FFD7B3' },
  { code: '402', name: 'Caramel', hex: '#C77C3B' },
  { code: '3776', name: 'Brique', hex: '#B35A2A' },
  { code: '301', name: 'Acajou', hex: '#8B3A1F' },
  { code: '400', name: 'Marron foncé', hex: '#9A5930' },
  { code: '300', name: 'Acajou foncé', hex: '#734018' },
  { code: '3781', name: 'Marron foncé', hex: '#5C3E27' },
  
  // Gris
  { code: '762', name: 'Gris perle', hex: '#E6E6E6' },
  { code: '415', name: 'Gris', hex: '#CCCCCC' },
  { code: '318', name: 'Gris acier clair', hex: '#B0B0B0' },
  { code: '414', name: 'Gris acier', hex: '#999999' },
  { code: '168', name: 'Gris étain', hex: '#C5C5C5' },
  { code: '169', name: 'Gris étain clair', hex: '#A5A5A5' },
  { code: '317', name: 'Gris étain', hex: '#8E8E8E' },
  { code: '413', name: 'Gris foncé', hex: '#7A7A7A' },
  { code: '3799', name: 'Gris charbon', hex: '#636363' },
  { code: '535', name: 'Gris cendré', hex: '#4F4F4F' },
  { code: '3024', name: 'Gris brun', hex: '#D5CFCC' },
  { code: '647', name: 'Castor gris moyen', hex: '#B7B1AA' },
  { code: '646', name: 'Castor gris foncé', hex: '#8C8279' },
  { code: '645', name: 'Castor gris très foncé', hex: '#5A524A' },
  { code: '844', name: 'Gris castor', hex: '#4D433D' },
  { code: '640', name: 'Beige gris', hex: '#A89986' },
  { code: '642', name: 'Beige gris foncé', hex: '#917861' },
  { code: '3787', name: 'Brun gris', hex: '#6F5F52' },
  { code: '3021', name: 'Brun très foncé', hex: '#523F34' },
  { code: '3790', name: 'Beige gris ultra foncé', hex: '#8C7860' },
];

export default function ColorPaletteCompact({ selectedColor, onColorSelect }) {
  return (
    <div className="space-y-3">
      <div className="grid grid-cols-6 gap-1.5">
        {DMC_COLORS.map((color) => (
          <button
            key={color.code}
            onClick={() => onColorSelect(color)}
            className={cn(
              "w-8 h-8 rounded border-2 transition-all hover:scale-110 relative group",
              selectedColor?.code === color.code
                ? "border-slate-800 ring-2 ring-slate-200"
                : "border-slate-300 hover:border-slate-400"
            )}
            style={{ backgroundColor: color.hex }}
            title={`${color.code} - ${color.name}`}
          >
            {selectedColor?.code === color.code && (
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="bg-white rounded-full p-0.5">
                  <Check className="w-3 h-3 text-slate-800" strokeWidth={3} />
                </div>
              </div>
            )}
            
            {/* Tooltip */}
            <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-50 whitespace-nowrap">
              <div className="bg-slate-900 text-white text-xs px-2 py-1 rounded">
                {color.name}
              </div>
            </div>
          </button>
        ))}
      </div>
      
      {selectedColor && (
        <div className="border-t border-slate-200 pt-2">
          <div className="flex items-center gap-2">
            <div 
              className="w-8 h-8 rounded border-2 border-slate-300 flex-shrink-0"
              style={{ backgroundColor: selectedColor.hex }}
            />
            <div className="flex-1 min-w-0">
              <div className="text-xs font-medium text-slate-900 truncate">{selectedColor.name}</div>
              <div className="text-[10px] text-slate-500">{selectedColor.code}</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}