import React, { useState, useRef, useEffect } from 'react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { FileDown, FileImage, Package, Loader2, CheckCircle, X } from 'lucide-react';
import { toast } from 'sonner';
import { 
  exportToPDF, 
  exportToPNG, 
  exportToPBX, 
  downloadPDF, 
  downloadPNG, 
  downloadPBX 
} from './exportEngine';

export default function ExportDialogV2({ open, onClose, pattern, gridName }) {
  const [activeTab, setActiveTab] = useState('pdf');
  const [exporting, setExporting] = useState(false);
  const [previewImage, setPreviewImage] = useState(null);

  // Options PDF
  const [pdfQuality, setPdfQuality] = useState('hq');
  const [pdfFormat, setPdfFormat] = useState('a4-portrait');
  const [pdfIncludeLegend, setPdfIncludeLegend] = useState(true);
  const [pdfIncludeSymbolTable, setPdfIncludeSymbolTable] = useState(true);
  const [pdfIncludeDimensions, setPdfIncludeDimensions] = useState(true);
  const [pdfIncludeGuides, setPdfIncludeGuides] = useState(true);
  const [pdfIncludeCover, setPdfIncludeCover] = useState(false);
  const [pdfIncludeSignature, setPdfIncludeSignature] = useState(true);
  const [pdfIncludeThreadInfo, setPdfIncludeThreadInfo] = useState(true);
  const [pdfIncludeSpecialStitches, setPdfIncludeSpecialStitches] = useState(true);
  const [pdfSymbolSize, setPdfSymbolSize] = useState('medium');
  const [pdfColorBlindMode, setPdfColorBlindMode] = useState(false);
  const [pdfInkSaverMode, setPdfInkSaverMode] = useState(false);
  const [pdfIncludeQRCode, setPdfIncludeQRCode] = useState(false);

  // Options PNG
  const [pngIncludeGrid, setPngIncludeGrid] = useState(true);
  const [pngIncludeSymbols, setPngIncludeSymbols] = useState(true);
  const [pngIncludeColors, setPngIncludeColors] = useState(true);
  const [pngResolution, setPngResolution] = useState('2k');
  const [pngBackground, setPngBackground] = useState('white');

  // Options PBX
  const [pbxIncludeOriginal, setPbxIncludeOriginal] = useState(false);

  // Aperçu
  const previewCanvasRef = useRef(null);

  useEffect(() => {
    if (open && pattern) {
      generatePreview();
    }
  }, [open, pattern, activeTab]);

  const generatePreview = async () => {
    if (!pattern || !previewCanvasRef.current) return;

    const canvas = previewCanvasRef.current;
    const ctx = canvas.getContext('2d');
    
    canvas.width = 400;
    canvas.height = 400;

    const cellSize = Math.min(canvas.width / pattern.width, canvas.height / pattern.height);

    ctx.fillStyle = 'white';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Dessiner un aperçu simplifié
    for (let y = 0; y < Math.min(pattern.height, 50); y++) {
      for (let x = 0; x < Math.min(pattern.width, 50); x++) {
        const cell = pattern.symbolGrid?.[y]?.[x];
        if (!cell) continue;

        const color = pattern.colorPalette?.find(c => c.id === cell.colorId);
        if (color) {
          ctx.fillStyle = `rgb(${color.r}, ${color.g}, ${color.b})`;
          ctx.fillRect(x * cellSize, y * cellSize, cellSize, cellSize);
        }

        ctx.strokeStyle = '#ddd';
        ctx.strokeRect(x * cellSize, y * cellSize, cellSize, cellSize);
      }
    }

    setPreviewImage(canvas.toDataURL());
  };

  const handleExportPDF = async () => {
    if (!pattern) return;

    setExporting(true);
    try {
      const doc = await exportToPDF(pattern, {
        quality: pdfQuality,
        format: pdfFormat,
        includeLegend: pdfIncludeLegend,
        includeSymbolTable: pdfIncludeSymbolTable,
        includeDimensions: pdfIncludeDimensions,
        includeGuides: pdfIncludeGuides,
        includeCover: pdfIncludeCover,
        includeSignature: pdfIncludeSignature,
        includeThreadInfo: pdfIncludeThreadInfo,
        includeSpecialStitches: pdfIncludeSpecialStitches,
        symbolSize: pdfSymbolSize,
        colorBlindMode: pdfColorBlindMode,
        inkSaverMode: pdfInkSaverMode,
        includeQRCode: pdfIncludeQRCode
      });

      downloadPDF(doc, gridName || 'grille-patybee');
      toast.success('PDF exporté avec succès !');
      onClose();
    } catch (error) {
      console.error('Erreur export PDF:', error);
      toast.error('Erreur lors de l\'export PDF');
    } finally {
      setExporting(false);
    }
  };

  const handleExportPNG = async () => {
    if (!pattern) return;

    setExporting(true);
    try {
      const dataUrl = await exportToPNG(pattern, {
        includeGrid: pngIncludeGrid,
        includeSymbols: pngIncludeSymbols,
        includeColors: pngIncludeColors,
        resolution: pngResolution,
        backgroundColor: pngBackground
      });

      downloadPNG(dataUrl, gridName || 'grille-patybee');
      toast.success('Image exportée avec succès !');
      onClose();
    } catch (error) {
      console.error('Erreur export PNG:', error);
      toast.error('Erreur lors de l\'export PNG');
    } finally {
      setExporting(false);
    }
  };

  const handleExportPBX = async () => {
    if (!pattern) return;

    setExporting(true);
    try {
      const pbxData = exportToPBX(pattern, {
        includeOriginal: pbxIncludeOriginal,
        author: 'User',
        title: gridName || 'Ma grille'
      });

      downloadPBX(pbxData, gridName || 'grille-patybee');
      toast.success('Fichier .PBX exporté avec succès !');
      onClose();
    } catch (error) {
      console.error('Erreur export PBX:', error);
      toast.error('Erreur lors de l\'export PBX');
    } finally {
      setExporting(false);
    }
  };

  if (!pattern) return null;

  // Gérer fermeture au clavier (Échap)
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'Escape' && open) {
        onClose();
      }
    };

    if (open) {
      document.addEventListener('keydown', handleKeyDown);
      // Bloquer le scroll du body
      document.body.style.overflow = 'hidden';
    }

    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = '';
    };
  }, [open, onClose]);

  return (
    <>
      {open && (
        <>
          {/* Overlay fond noir avec opacité */}
          <div 
            className="fixed inset-0 bg-black transition-opacity duration-200"
            style={{ 
              opacity: 0.65,
              zIndex: 9000 
            }}
            onClick={onClose}
          />
          
          {/* Conteneur de la fenêtre modale */}
          <div 
            className="fixed inset-0 flex items-center justify-center"
            style={{ zIndex: 9001, pointerEvents: 'none' }}
          >
            <div 
              className="w-[900px] max-w-[85vw] max-h-[90vh] bg-[#1A1A1A] rounded-xl overflow-hidden flex flex-col pointer-events-auto"
              style={{ 
                boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.7)' 
              }}
              onClick={(e) => e.stopPropagation()}
            >
          {/* EN-TÊTE */}
          <div className="px-8 py-5 border-b border-[#333]">
            {/* Ligne 1: Titre + Bouton fermer */}
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-2xl font-bold text-white tracking-tight">Exporter ma grille</h2>
              <button
                onClick={onClose}
                className="w-9 h-9 flex items-center justify-center rounded-full hover:bg-[#333] transition-all duration-200"
                aria-label="Fermer"
              >
                <X className="w-5 h-5 text-white" />
              </button>
            </div>

            {/* Ligne 2: Sous-titre */}
            <p className="text-sm text-[#B3B3B3] mb-5">
              Choisissez le format d'export et les options adaptées à votre broderie.
            </p>

            {/* Ligne 3: Barre d'onglets */}
            <div className="flex gap-2">
              <button
                onClick={() => setActiveTab('pdf')}
                className={`flex-1 px-5 py-3 rounded-lg text-sm font-semibold transition-all duration-200 ${
                  activeTab === 'pdf'
                    ? 'bg-[#FFC93C] text-black shadow-lg'
                    : 'bg-transparent text-[#E0E0E0] border border-[#444] hover:bg-[#222]'
                }`}
              >
                <FileDown className="w-4 h-4 inline mr-2" />
                PDF
              </button>
              <button
                onClick={() => setActiveTab('image')}
                className={`flex-1 px-5 py-3 rounded-lg text-sm font-semibold transition-all duration-200 ${
                  activeTab === 'image'
                    ? 'bg-[#FFC93C] text-black shadow-lg'
                    : 'bg-transparent text-[#E0E0E0] border border-[#444] hover:bg-[#222]'
                }`}
              >
                <FileImage className="w-4 h-4 inline mr-2" />
                Image
              </button>
              <button
                onClick={() => setActiveTab('pbx')}
                className={`flex-1 px-5 py-3 rounded-lg text-sm font-semibold transition-all duration-200 ${
                  activeTab === 'pbx'
                    ? 'bg-[#FFC93C] text-black shadow-lg'
                    : 'bg-transparent text-[#E0E0E0] border border-[#444] hover:bg-[#222]'
                }`}
              >
                <Package className="w-4 h-4 inline mr-2" />
                PatyBee (.PBX)
              </button>
            </div>
          </div>

          {/* CORPS - 2 colonnes */}
          <div className="flex flex-1 overflow-hidden">
            {/* COLONNE GAUCHE - Options */}
            <div className="flex-1 overflow-y-auto px-8 py-6 space-y-5">
              {/* ONGLET PDF */}
              {activeTab === 'pdf' && (
                <div className="space-y-5">
                  <h3 className="text-base font-semibold text-[#E0E0E0]">Format PDF</h3>

                  {/* Type de PDF */}
                  <div className="space-y-3 bg-[#222] p-4 rounded-lg">
                    <Label className="text-[#E0E0E0] text-sm font-medium">Type de PDF</Label>
                    <div className="space-y-2">
                      <button
                        onClick={() => setPdfQuality('hq')}
                        className={`w-full p-3 rounded-md text-left transition-all duration-200 ${
                          pdfQuality === 'hq'
                            ? 'bg-[#FFC93C]/20 border-2 border-[#FFC93C]'
                            : 'bg-[#1A1A1A] border border-[#444] hover:border-[#666]'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                            pdfQuality === 'hq' ? 'border-[#FFC93C]' : 'border-[#666]'
                          }`}>
                            {pdfQuality === 'hq' && <div className="w-2 h-2 rounded-full bg-[#FFC93C]" />}
                          </div>
                          <div className="flex-1">
                            <div className="font-semibold text-white text-sm">PDF Haute Qualité (300 DPI)</div>
                            <div className="text-xs text-[#B3B3B3]">Symboles vectoriels, traits ultra nets</div>
                          </div>
                        </div>
                      </button>
                      
                      <button
                        onClick={() => setPdfQuality('eco')}
                        className={`w-full p-3 rounded-md text-left transition-all duration-200 ${
                          pdfQuality === 'eco'
                            ? 'bg-[#FFC93C]/20 border-2 border-[#FFC93C]'
                            : 'bg-[#1A1A1A] border border-[#444] hover:border-[#666]'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                            pdfQuality === 'eco' ? 'border-[#FFC93C]' : 'border-[#666]'
                          }`}>
                            {pdfQuality === 'eco' && <div className="w-2 h-2 rounded-full bg-[#FFC93C]" />}
                          </div>
                          <div className="flex-1">
                            <div className="font-semibold text-white text-sm">PDF Économique (150 DPI)</div>
                            <div className="text-xs text-[#B3B3B3]">Pour impressions rapides</div>
                          </div>
                        </div>
                      </button>
                    </div>
                  </div>

                  {/* Format de page */}
                  <div className="space-y-2 bg-[#222] p-4 rounded-lg">
                    <Label className="text-[#E0E0E0] text-sm font-medium">Format de page</Label>
                    <select
                      value={pdfFormat}
                      onChange={(e) => setPdfFormat(e.target.value)}
                      className="w-full px-3 py-2 bg-[#1A1A1A] border border-[#444] rounded-md text-white text-sm focus:outline-none focus:border-[#FFC93C]"
                    >
                      <option value="a4-portrait">A4 portrait</option>
                      <option value="a4-landscape">A4 paysage</option>
                      <option value="letter-portrait">US Letter</option>
                      <option value="single-page">Page unique (poster)</option>
                    </select>
                  </div>

                  {/* Cases à cocher */}
                  <div className="space-y-2 bg-[#222] p-4 rounded-lg">
                    <Label className="text-[#E0E0E0] text-sm font-medium mb-2 block">Options</Label>
                    {[
                      { id: 'legend', label: 'Inclure la légende DMC', checked: pdfIncludeLegend, onChange: setPdfIncludeLegend },
                      { id: 'symbols', label: 'Inclure le tableau symboles ↔ couleurs', checked: pdfIncludeSymbolTable, onChange: setPdfIncludeSymbolTable },
                      { id: 'guides', label: 'Afficher les repères 10x10', checked: pdfIncludeGuides, onChange: setPdfIncludeGuides },
                      { id: 'dims', label: 'Afficher le centre de la grille', checked: pdfIncludeDimensions, onChange: setPdfIncludeDimensions },
                      { id: 'special', label: 'Afficher les types de points', checked: pdfIncludeSpecialStitches, onChange: setPdfIncludeSpecialStitches },
                      { id: 'cover', label: 'Ajouter une page de couverture', checked: pdfIncludeCover, onChange: setPdfIncludeCover },
                      { id: 'sig', label: 'Ajouter la signature PatyBee', checked: pdfIncludeSignature, onChange: setPdfIncludeSignature },
                      { id: 'ink', label: 'Mode économie d\'encre', checked: pdfInkSaverMode, onChange: setPdfInkSaverMode },
                      { id: 'colorblind', label: 'Mode daltonisme', checked: pdfColorBlindMode, onChange: setPdfColorBlindMode }
                    ].map((option) => (
                      <label key={option.id} className="flex items-center gap-3 cursor-pointer group py-1.5">
                        <input
                          type="checkbox"
                          checked={option.checked}
                          onChange={(e) => option.onChange(e.target.checked)}
                          className="w-4 h-4 rounded border-[#666] bg-[#1A1A1A] checked:bg-[#FFC93C] checked:border-[#FFC93C] focus:ring-1 focus:ring-[#FFC93C]"
                        />
                        <span className="text-sm text-[#E0E0E0] group-hover:text-white transition-colors">
                          {option.label}
                        </span>
                      </label>
                    ))}
                  </div>

                  {/* QR Code */}
                  <div className="p-3 bg-slate-800/50 rounded-lg">
                    <label className="flex items-center gap-3 cursor-pointer group">
                      <input
                        type="checkbox"
                        checked={pdfIncludeQRCode}
                        onChange={(e) => setPdfIncludeQRCode(e.target.checked)}
                        className="w-4 h-4 rounded border-slate-600 bg-slate-800 checked:bg-indigo-500 checked:border-indigo-500"
                      />
                      <div>
                        <div className="text-sm font-medium text-white">Ajouter le QR Code Human™</div>
                        <div className="text-xs text-slate-400">Lien vers la grille PatyBee</div>
                      </div>
                    </label>
                  </div>

                  {/* Taille symboles */}
                  <div className="space-y-2 bg-[#222] p-4 rounded-lg">
                    <Label className="text-[#E0E0E0] text-sm font-medium">Taille des symboles</Label>
                    <div className="flex gap-2">
                      {['small', 'medium', 'large'].map((size) => (
                        <button
                          key={size}
                          onClick={() => setPdfSymbolSize(size)}
                          className={`flex-1 px-4 py-2 rounded-md text-sm font-semibold transition-all duration-200 ${
                            pdfSymbolSize === size
                              ? 'bg-[#000] text-white'
                              : 'bg-[#1A1A1A] text-[#B3B3B3] border border-[#444] hover:bg-[#333]'
                          }`}
                        >
                          {size === 'small' ? 'Petits' : size === 'medium' ? 'Moyens' : 'Grands'}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* ONGLET IMAGE */}
              {activeTab === 'image' && (
                <div className="space-y-6">
                  <h3 className="text-lg font-semibold text-white">Export en image PNG</h3>

                  {/* Type de rendu */}
                  <div className="space-y-2">
                    <Label className="text-white">Type de rendu</Label>
                    <div className="space-y-2">
                      {[
                        { value: 'grid-symbols', label: 'Grille + symboles' },
                        { value: 'grid-only', label: 'Grille seule' },
                        { value: 'visual', label: 'Visuel final sans grille' }
                      ].map((option) => (
                        <button
                          key={option.value}
                          onClick={() => setPngIncludeSymbols(option.value === 'grid-symbols')}
                          className={`w-full p-3 rounded-lg border-2 text-left transition-colors ${
                            (option.value === 'grid-symbols' && pngIncludeSymbols) ||
                            (option.value === 'grid-only' && !pngIncludeSymbols)
                              ? 'border-green-500 bg-green-500/10'
                              : 'border-slate-700 bg-slate-800/50 hover:border-slate-600'
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                              (option.value === 'grid-symbols' && pngIncludeSymbols) ||
                              (option.value === 'grid-only' && !pngIncludeSymbols)
                                ? 'border-green-500'
                                : 'border-slate-600'
                            }`}>
                              {((option.value === 'grid-symbols' && pngIncludeSymbols) ||
                                (option.value === 'grid-only' && !pngIncludeSymbols)) && (
                                <div className="w-3 h-3 rounded-full bg-green-500" />
                              )}
                            </div>
                            <span className="text-white font-medium">{option.label}</span>
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Résolution */}
                  <div className="space-y-2">
                    <Label className="text-white">Résolution</Label>
                    <select
                      value={pngResolution}
                      onChange={(e) => setPngResolution(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:border-green-500"
                    >
                      <option value="1080p">1080p (1920px)</option>
                      <option value="2k">2K (2560px)</option>
                      <option value="4k">4K (3840px)</option>
                      <option value="6000px">6000px (côté le plus long)</option>
                    </select>
                  </div>

                  {/* Fond */}
                  <div className="space-y-2">
                    <Label className="text-white">Fond</Label>
                    <div className="flex gap-2">
                      {[
                        { value: 'white', label: 'Fond blanc' },
                        { value: 'transparent', label: 'Fond transparent' }
                      ].map((option) => (
                        <button
                          key={option.value}
                          onClick={() => setPngBackground(option.value)}
                          className={`flex-1 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                            pngBackground === option.value
                              ? 'bg-green-500 text-white'
                              : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                          }`}
                        >
                          {option.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Cases à cocher */}
                  <div className="space-y-3">
                    {[
                      { label: 'Afficher le centre', checked: true },
                      { label: 'Afficher les repères 10x10', checked: pngIncludeGrid, onChange: setPngIncludeGrid },
                      { label: 'Afficher la légende en dessous', checked: pngIncludeColors, onChange: setPngIncludeColors }
                    ].map((option, index) => (
                      <label key={index} className="flex items-center gap-3 cursor-pointer group">
                        <input
                          type="checkbox"
                          checked={option.checked}
                          onChange={(e) => option.onChange?.(e.target.checked)}
                          className="w-4 h-4 rounded border-slate-600 bg-slate-800 checked:bg-green-500 checked:border-green-500"
                        />
                        <span className="text-sm text-slate-300 group-hover:text-white transition-colors">
                          {option.label}
                        </span>
                      </label>
                    ))}
                  </div>
                </div>
              )}

              {/* ONGLET PBX */}
              {activeTab === 'pbx' && (
                <div className="space-y-6">
                  <h3 className="text-lg font-semibold text-white">Format projet PatyBee (.PBX)</h3>

                  {/* Texte explicatif */}
                  <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-700">
                    <p className="text-sm text-slate-300 mb-3">
                      Ce format conserve l'intégralité de votre projet : palette DMC, symboles, 
                      types de points, historique d'optimisation IA, profil brodeuse, etc.
                    </p>
                    <ul className="text-sm text-slate-400 space-y-1.5">
                      <li className="flex items-start gap-2">
                        <span className="text-purple-400">•</span>
                        Palette DMC complète
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-purple-400">•</span>
                        Types de points et perles
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-purple-400">•</span>
                        Optimisations IA appliquées
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-purple-400">•</span>
                        Historique et métadonnées
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-purple-400">•</span>
                        Mosaïque et repères
                      </li>
                    </ul>
                  </div>

                  {/* Cases à cocher */}
                  <div className="space-y-3">
                    <label className="flex items-center gap-3 cursor-pointer group">
                      <input
                        type="checkbox"
                        checked={pbxIncludeOriginal}
                        onChange={(e) => setPbxIncludeOriginal(e.target.checked)}
                        className="w-4 h-4 rounded border-slate-600 bg-slate-800 checked:bg-purple-500 checked:border-purple-500"
                      />
                      <span className="text-sm text-slate-300 group-hover:text-white transition-colors">
                        Inclure la version originale
                      </span>
                    </label>
                    
                    <label className="flex items-center gap-3 cursor-pointer group">
                      <input
                        type="checkbox"
                        defaultChecked
                        className="w-4 h-4 rounded border-slate-600 bg-slate-800 checked:bg-purple-500 checked:border-purple-500"
                      />
                      <span className="text-sm text-slate-300 group-hover:text-white transition-colors">
                        Inclure la version optimisée IA
                      </span>
                    </label>
                    
                    <label className="flex items-center gap-3 cursor-pointer group">
                      <input
                        type="checkbox"
                        defaultChecked
                        className="w-4 h-4 rounded border-slate-600 bg-slate-800 checked:bg-purple-500 checked:border-purple-500"
                      />
                      <span className="text-sm text-slate-300 group-hover:text-white transition-colors">
                        Inclure l'historique des optimisations
                      </span>
                    </label>
                    
                    <label className="flex items-center gap-3 cursor-pointer group">
                      <input
                        type="checkbox"
                        className="w-4 h-4 rounded border-slate-600 bg-slate-800 checked:bg-purple-500 checked:border-purple-500"
                      />
                      <span className="text-sm text-slate-300 group-hover:text-white transition-colors">
                        Inclure mon profil (signature vibratoire)
                      </span>
                    </label>
                  </div>

                  {/* Info */}
                  <div className="text-xs text-slate-500 p-3 bg-slate-900/50 rounded-lg">
                    Ce fichier pourra être réouvert et modifié dans PatyBee ou utilisé pour la boutique.
                  </div>
                </div>
              )}
            </div>

            {/* COLONNE DROITE - Prévisualisation */}
            <div className="w-[40%] border-l border-[#333] p-6 bg-[#111]">
              <h3 className="text-base font-semibold text-[#E0E0E0] mb-4">Aperçu</h3>
              
              <div className="bg-[#222] rounded-lg p-3 mb-4 border border-[#333]">
                <canvas 
                  ref={previewCanvasRef}
                  className="w-full h-auto rounded"
                />
              </div>

              {/* Infos récapitulatives */}
              {pattern && (
                <div className="space-y-2.5 text-sm">
                  <div className="flex justify-between text-[#B3B3B3]">
                    <span>Format:</span>
                    <span className="text-white font-semibold">
                      {activeTab === 'pdf' && (pdfFormat.includes('portrait') ? 'A4 portrait' : 'A4 paysage')}
                      {activeTab === 'image' && `PNG ${pngResolution}`}
                      {activeTab === 'pbx' && 'Fichier .PBX'}
                    </span>
                  </div>
                  <div className="flex justify-between text-[#B3B3B3]">
                    <span>Couleurs:</span>
                    <span className="text-white font-semibold">{pattern.colorPalette?.length || 0} DMC</span>
                  </div>
                  <div className="flex justify-between text-[#B3B3B3]">
                    <span>Dimensions:</span>
                    <span className="text-white font-semibold">{pattern.width} × {pattern.height}</span>
                  </div>
                  {activeTab === 'pdf' && (
                    <div className="flex justify-between text-[#B3B3B3]">
                      <span>Pages estimées:</span>
                      <span className="text-white font-semibold">1-2</span>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* PIED DE PAGE */}
          <div className="px-8 py-5 border-t border-[#333] flex items-center justify-between">
            <button
              onClick={onClose}
              className="text-sm text-[#E0E0E0] hover:text-white transition-colors flex items-center gap-2 font-medium"
            >
              ← Retour à l'éditeur
            </button>

            <div className="flex gap-3">
              <Button
                onClick={
                  activeTab === 'pdf' ? handleExportPDF :
                  activeTab === 'image' ? handleExportPNG :
                  handleExportPBX
                }
                disabled={exporting}
                className="bg-[#000] hover:bg-[#111] text-white font-semibold px-6 py-2.5 rounded-lg transition-all duration-200 disabled:opacity-50"
              >
                {exporting ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Export en cours...
                  </>
                ) : (
                  <>
                    {activeTab === 'pdf' && <><FileDown className="w-4 h-4 mr-2" />Exporter en PDF</>}
                    {activeTab === 'image' && <><FileImage className="w-4 h-4 mr-2" />Exporter en PNG</>}
                    {activeTab === 'pbx' && <><Package className="w-4 h-4 mr-2" />Exporter en .PBX</>}
                  </>
                )}
              </Button>
            </div>
          </div>
            </div>
          </div>
        </>
      )}
    </>
  );
}