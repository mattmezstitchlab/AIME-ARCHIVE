import React, { useState, useEffect, useRef } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import {
  X, ChevronLeft, ChevronRight, Check, AlertTriangle,
  Loader2, Image as ImageIcon, Tag, DollarSign, Eye,
  Lock, ShoppingBag, Sparkles, FileCheck, CheckCircle2,
  XCircle, Info, Grid3X3, Palette
} from 'lucide-react';

// Composant miniature projet
function ProjectThumbnail({ project, size = 60 }) {
  const canvasRef = useRef(null);

  useEffect(() => {
    if (!canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const pattern = project.pattern;

    ctx.fillStyle = '#1a1a1a';
    ctx.fillRect(0, 0, size, size);

    if (!pattern?.symbolGrid) {
      ctx.fillStyle = '#444';
      ctx.font = `${size/3}px sans-serif`;
      ctx.textAlign = 'center';
      ctx.fillText('?', size/2, size/2 + size/8);
      return;
    }

    // Dessiner l'image source si disponible
    if (pattern.source_image || pattern.sourceImage) {
      const img = new Image();
      img.onload = () => {
        ctx.drawImage(img, 0, 0, size, size);
      };
      img.src = pattern.source_image || pattern.sourceImage;
      return;
    }

    const grid = pattern.symbolGrid;
    const rows = grid.length;
    const cols = grid[0]?.length || 0;
    if (rows === 0 || cols === 0) return;

    const cellSize = Math.min(size / cols, size / rows, 2);
    const offsetX = (size - cols * cellSize) / 2;
    const offsetY = (size - rows * cellSize) / 2;

    for (let row = 0; row < rows; row++) {
      for (let col = 0; col < cols; col++) {
        const cell = grid[row]?.[col];
        if (cell) {
          ctx.fillStyle = cell.color || '#888';
          ctx.fillRect(
            offsetX + col * cellSize,
            offsetY + row * cellSize,
            cellSize,
            cellSize
          );
        }
      }
    }
  }, [project, size]);

  return (
    <canvas
      ref={canvasRef}
      width={size}
      height={size}
      className="rounded-lg flex-shrink-0"
    />
  );
}

// Étape 1 : Sélection du projet (GRILLE CENTRALE STYLE BOUTIQUE)
function StepSelectProject({ projects, isLoading, selectedProject, onSelect, onContinue }) {
  // Calculer infos pour chaque projet
  const getProjectInfo = (project) => {
    const pattern = project.pattern;
    const width = pattern?.width || 0;
    const height = pattern?.height || 0;
    const colorCount = pattern?.colors?.length || pattern?.colorPalette?.length || 0;
    return { width, height, colorCount };
  };

  return (
    <div className="flex flex-col h-full">
      {/* Bannière */}
      <div className="relative rounded-2xl overflow-hidden bg-gradient-to-r from-[#FFC94A] to-[#F59E0B] p-6 mb-6">
        <div className="relative z-10">
          <h3 className="text-2xl font-bold text-black mb-2">Choisir un projet</h3>
          <p className="text-black/70 text-sm max-w-md">
            Sélectionnez la grille que vous souhaitez soumettre à la Boutique.
          </p>
        </div>
        <div className="absolute right-4 bottom-4 opacity-20">
          <Palette className="w-32 h-32 text-black" />
        </div>
      </div>

      {/* Grille de projets */}
      <div className="flex-1 overflow-y-auto">
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-[#FFC94A]" />
          </div>
        ) : projects.length === 0 ? (
          <div className="text-center py-12 text-gray-500">
            <Grid3X3 className="w-12 h-12 mx-auto mb-4 opacity-30" />
            <p>Aucun projet disponible.</p>
            <p className="text-sm mt-2">Créez d'abord un projet dans l'éditeur.</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {projects.map(project => {
              const info = getProjectInfo(project);
              const isSelected = selectedProject?.id === project.id;
              
              return (
                <button
                  key={project.id}
                  onClick={() => onSelect(project)}
                  className={`relative bg-[#1a1a1a] rounded-xl overflow-hidden border-[3px] transition-all cursor-pointer group ${
                    isSelected 
                      ? 'border-[#FCD53F] bg-[#252525] shadow-[0_0_20px_rgba(252,213,63,0.3)]' 
                      : 'border-[#333] hover:border-[#FFC94A]/50 hover:shadow-[0_0_15px_rgba(255,201,74,0.15)]'
                  }`}
                  title="Cliquez pour choisir ce projet."
                >
                  {/* Badge sélectionné */}
                  {isSelected && (
                    <div className="absolute top-2 right-2 z-10 w-6 h-6 rounded-full bg-[#FCD53F] flex items-center justify-center">
                      <Check className="w-4 h-4 text-black" strokeWidth={3} />
                    </div>
                  )}

                  {/* Vignette */}
                  <div className={`aspect-square bg-[#222] flex items-center justify-center overflow-hidden transition-transform ${
                    isSelected ? 'scale-105' : 'group-hover:scale-[1.02]'
                  }`}>
                    {project.pattern?.source_image || project.pattern?.sourceImage ? (
                      <img 
                        src={project.pattern.source_image || project.pattern.sourceImage} 
                        alt={project.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <ProjectThumbnail project={project} size={150} />
                    )}
                  </div>

                  {/* Infos */}
                  <div className={`p-3 transition-colors ${isSelected ? 'bg-[#1f1f1f]' : ''}`}>
                    <h5 className="text-sm font-medium text-white truncate">
                      {project.name || 'Sans titre'}
                    </h5>
                    <div className="flex items-center gap-2 mt-1 text-xs text-gray-500">
                      <span>{info.width} × {info.height}</span>
                      {info.colorCount > 0 && (
                        <>
                          <span>•</span>
                          <span>{info.colorCount} couleurs</span>
                        </>
                      )}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* Footer avec boutons */}
      <div className="flex justify-center gap-4 pt-6 mt-4 border-t border-[#333]">
        <Button 
          onClick={onContinue}
          disabled={!selectedProject}
          className={`px-8 py-3 text-base font-semibold transition-all ${
            selectedProject 
              ? 'bg-[#FFC94A] text-black hover:bg-[#FFD666]' 
              : 'bg-white/10 text-gray-500 cursor-not-allowed'
          }`}
        >
          Continuer
          <ChevronRight className="w-5 h-5 ml-2" />
        </Button>
      </div>
    </div>
  );
}

// Étape 2 : Vérification automatique
function StepVerification({ project, onContinue, onBack }) {
  const [checks, setChecks] = useState({
    size: { status: 'loading', message: '' },
    colors: { status: 'loading', message: '' },
    sub: { status: 'loading', message: '' },
    symbols: { status: 'loading', message: '' },
    copyright: { status: 'loading', message: '' },
  });

  useEffect(() => {
    const runChecks = async () => {
      await new Promise(r => setTimeout(r, 500));
      
      const pattern = project.pattern;
      const width = pattern?.width || 0;
      const height = pattern?.height || 0;
      const colorCount = pattern?.colors?.length || pattern?.colorPalette?.length || 0;

      setChecks({
        size: {
          status: width >= 20 && height >= 20 ? 'success' : 'warning',
          message: `${width} × ${height} points${width < 20 || height < 20 ? ' (minimum recommandé : 20×20)' : ''}`
        },
        colors: {
          status: colorCount > 0 && colorCount <= 50 ? 'success' : colorCount > 50 ? 'warning' : 'error',
          message: `${colorCount} couleur${colorCount > 1 ? 's' : ''} détectée${colorCount > 1 ? 's' : ''}${colorCount > 50 ? ' (beaucoup de couleurs)' : ''}`
        },
        sub: {
          status: 'success',
          message: 'Format SUB™ compatible'
        },
        symbols: {
          status: 'success',
          message: 'Tous les symboles sont valides'
        },
        copyright: {
          status: 'pending',
          message: 'Vous devrez confirmer vos droits d\'auteur'
        },
      });
    };

    runChecks();
  }, [project]);

  const allChecksOk = Object.values(checks).every(c => c.status !== 'error' && c.status !== 'loading');

  const StatusIcon = ({ status }) => {
    switch (status) {
      case 'success': return <CheckCircle2 className="w-5 h-5 text-green-500" />;
      case 'warning': return <AlertTriangle className="w-5 h-5 text-yellow-500" />;
      case 'error': return <XCircle className="w-5 h-5 text-red-500" />;
      case 'pending': return <Info className="w-5 h-5 text-blue-500" />;
      default: return <Loader2 className="w-5 h-5 animate-spin text-gray-400" />;
    }
  };

  return (
    <div className="max-w-xl mx-auto space-y-6">
      <div className="text-center mb-6">
        <h3 className="text-xl font-bold text-white mb-2">Vérification du projet</h3>
        <p className="text-sm text-gray-400">Nous vérifions que votre projet est prêt pour la boutique.</p>
      </div>

      <div className="flex items-center gap-4 p-4 bg-white/5 rounded-xl mb-4">
        <ProjectThumbnail project={project} size={80} />
        <div>
          <h4 className="font-medium text-white">{project.name || 'Sans titre'}</h4>
          <p className="text-sm text-gray-400">
            {project.pattern?.width || '?'} × {project.pattern?.height || '?'} points
          </p>
        </div>
      </div>

      <div className="space-y-3">
        {Object.entries(checks).map(([key, check]) => (
          <div key={key} className="flex items-center gap-3 p-3 bg-white/5 rounded-lg">
            <StatusIcon status={check.status} />
            <div className="flex-1">
              <span className="text-sm text-white capitalize">
                {key === 'size' && 'Taille'}
                {key === 'colors' && 'Couleurs'}
                {key === 'sub' && 'Compatibilité SUB'}
                {key === 'symbols' && 'Symboles'}
                {key === 'copyright' && 'Droits d\'auteur'}
              </span>
              <p className="text-xs text-gray-400">{check.message}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="flex justify-center gap-4 pt-4">
        <Button variant="outline" onClick={onBack} className="px-6 bg-white/5 border-white/10 text-white hover:bg-white/10">
          <ChevronLeft className="w-4 h-4 mr-1" />
          Retour
        </Button>
        <Button 
          onClick={onContinue} 
          disabled={!allChecksOk}
          className="px-6 bg-[#FFC94A] text-black hover:bg-[#FFD666]"
        >
          Continuer
          <ChevronRight className="w-4 h-4 ml-1" />
        </Button>
      </div>
    </div>
  );
}

// Étape 3 : Fiche produit
function StepProductDetails({ project, productData, setProductData, onContinue, onBack }) {
  const TAGS = ['Floral', 'Animaux', 'Abstrait', 'Géométrique', 'Portrait', 'Paysage', 'Mandala', 'Vintage', 'Moderne', 'Enfant'];
  const DIFFICULTIES = ['Débutant', 'Intermédiaire', 'Avancé', 'Expert'];
  const PACK_CONTENTS = [
    { id: 'grid', label: 'Grille PDF haute définition', default: true },
    { id: 'legend', label: 'Légende des couleurs DMC', default: true },
    { id: 'preview', label: 'Aperçu du rendu final', default: true },
    { id: 'instructions', label: 'Instructions de broderie', default: false },
    { id: 'sub', label: 'Fichier .SUB éditable', default: false },
  ];

  return (
    <div className="max-w-xl mx-auto space-y-6">
      <div className="text-center mb-4">
        <h3 className="text-xl font-bold text-white mb-2">Préparer la fiche produit</h3>
        <p className="text-sm text-gray-400">Décrivez votre création pour attirer les acheteurs.</p>
      </div>

      <div className="space-y-4 max-h-[50vh] overflow-y-auto pr-2">
        {/* Titre */}
        <div className="space-y-1">
          <Label className="text-white text-sm">Titre du motif *</Label>
          <Input
            value={productData.title}
            onChange={(e) => setProductData(p => ({...p, title: e.target.value}))}
            placeholder="Ex: Roses éternelles"
            className="bg-white/5 border-white/10 text-white"
          />
        </div>

        {/* Description */}
        <div className="space-y-1">
          <Label className="text-white text-sm">Description</Label>
          <Textarea
            value={productData.description}
            onChange={(e) => setProductData(p => ({...p, description: e.target.value}))}
            placeholder="Décrivez votre motif, son style, son inspiration..."
            className="bg-white/5 border-white/10 text-white h-20"
          />
        </div>

        {/* Tags */}
        <div className="space-y-2">
          <Label className="text-white text-sm">Tags / Style</Label>
          <div className="flex flex-wrap gap-2">
            {TAGS.map(tag => (
              <button
                key={tag}
                onClick={() => {
                  setProductData(p => ({
                    ...p,
                    tags: p.tags.includes(tag) 
                      ? p.tags.filter(t => t !== tag)
                      : [...p.tags, tag]
                  }));
                }}
                className={`px-3 py-1 rounded-full text-xs font-medium transition-colors ${
                  productData.tags.includes(tag)
                    ? 'bg-[#FFC94A] text-black'
                    : 'bg-white/10 text-gray-300 hover:bg-white/20'
                }`}
              >
                {tag}
              </button>
            ))}
          </div>
        </div>

        {/* Difficulté */}
        <div className="space-y-2">
          <Label className="text-white text-sm">Difficulté</Label>
          <div className="flex gap-2">
            {DIFFICULTIES.map(diff => (
              <button
                key={diff}
                onClick={() => setProductData(p => ({...p, difficulty: diff}))}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                  productData.difficulty === diff
                    ? 'bg-[#FFC94A] text-black'
                    : 'bg-white/10 text-gray-300 hover:bg-white/20'
                }`}
              >
                {diff}
              </button>
            ))}
          </div>
        </div>

        {/* Vignette */}
        <div className="space-y-2">
          <Label className="text-white text-sm">Vignette</Label>
          <div className="flex items-center gap-4 p-3 bg-white/5 rounded-lg">
            <ProjectThumbnail project={project} size={80} />
            <div className="flex-1">
              <p className="text-sm text-gray-400 mb-2">Vignette générée automatiquement à partir de votre grille.</p>
              <Button size="sm" variant="outline" className="bg-white/5 border-white/10 text-white hover:bg-white/10 text-xs">
                Changer l'image
              </Button>
            </div>
          </div>
        </div>

        {/* Contenu du pack */}
        <div className="space-y-2">
          <Label className="text-white text-sm">Contenu du pack</Label>
          <div className="space-y-2">
            {PACK_CONTENTS.map(item => (
              <label key={item.id} className="flex items-center gap-3 p-2 bg-white/5 rounded-lg cursor-pointer hover:bg-white/10 transition-colors">
                <Checkbox
                  checked={productData.packContents.includes(item.id)}
                  onCheckedChange={(checked) => {
                    setProductData(p => ({
                      ...p,
                      packContents: checked
                        ? [...p.packContents, item.id]
                        : p.packContents.filter(i => i !== item.id)
                    }));
                  }}
                />
                <span className="text-sm text-white">{item.label}</span>
              </label>
            ))}
          </div>
        </div>
      </div>

      <div className="flex justify-center gap-4 pt-4">
        <Button variant="outline" onClick={onBack} className="px-6 bg-white/5 border-white/10 text-white hover:bg-white/10">
          <ChevronLeft className="w-4 h-4 mr-1" />
          Retour
        </Button>
        <Button 
          onClick={onContinue}
          disabled={!productData.title.trim()}
          className="px-6 bg-[#FFC94A] text-black hover:bg-[#FFD666]"
        >
          Tarifs & droits
          <ChevronRight className="w-4 h-4 ml-1" />
        </Button>
      </div>
    </div>
  );
}

// Étape 4 : Tarifs & droits
function StepPricingRights({ productData, setProductData, onContinue, onBack }) {
  const suggestedPrice = 4.99;

  return (
    <div className="max-w-xl mx-auto space-y-6">
      <div className="text-center mb-4">
        <h3 className="text-xl font-bold text-white mb-2">Tarifs & droits</h3>
        <p className="text-sm text-gray-400">Définissez le prix et confirmez vos droits.</p>
      </div>

      <div className="space-y-4 max-h-[50vh] overflow-y-auto pr-2">
        {/* Prix */}
        <div className="space-y-2">
          <Label className="text-white text-sm">Prix de vente</Label>
          <div className="flex items-center gap-3">
            <div className="relative flex-1">
              <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                type="number"
                min="0.99"
                step="0.50"
                value={productData.price}
                onChange={(e) => setProductData(p => ({...p, price: parseFloat(e.target.value) || 0}))}
                className="pl-9 bg-white/5 border-white/10 text-white"
              />
            </div>
            <span className="text-gray-400">€</span>
          </div>
          <p className="text-xs text-gray-500">
            Prix conseillé : {suggestedPrice.toFixed(2)} € • Vous recevrez 85% du prix de vente
          </p>
        </div>

        {/* Droits d'auteur */}
        <div className="space-y-3 p-4 bg-white/5 rounded-xl">
          <h4 className="font-medium text-white flex items-center gap-2">
            <FileCheck className="w-4 h-4 text-[#FFC94A]" />
            Droits d'auteur
          </h4>
          
          <label className="flex items-start gap-3 cursor-pointer">
            <Checkbox
              checked={productData.isOriginal}
              onCheckedChange={(v) => setProductData(p => ({...p, isOriginal: v}))}
              className="mt-1"
            />
            <div>
              <span className="text-sm text-white">Je suis l'auteur original de ce motif</span>
              <p className="text-xs text-gray-500">Ce motif est une création personnelle et originale.</p>
            </div>
          </label>

          <label className="flex items-start gap-3 cursor-pointer">
            <Checkbox
              checked={productData.hasRights}
              onCheckedChange={(v) => setProductData(p => ({...p, hasRights: v}))}
              className="mt-1"
            />
            <div>
              <span className="text-sm text-white">J'ai les droits de commercialisation</span>
              <p className="text-xs text-gray-500">Je détiens tous les droits nécessaires pour vendre ce motif.</p>
            </div>
          </label>

          <label className="flex items-start gap-3 cursor-pointer">
            <Checkbox
              checked={productData.acceptTerms}
              onCheckedChange={(v) => setProductData(p => ({...p, acceptTerms: v}))}
              className="mt-1"
            />
            <div>
              <span className="text-sm text-white">J'accepte les conditions de vente</span>
              <p className="text-xs text-gray-500">J'ai lu et j'accepte les conditions générales de vente de Brood-Way.</p>
            </div>
          </label>
        </div>

        {/* Visibilité */}
        <div className="space-y-2">
          <Label className="text-white text-sm">Visibilité</Label>
          <RadioGroup
            value={productData.visibility}
            onValueChange={(v) => setProductData(p => ({...p, visibility: v}))}
            className="space-y-2"
          >
            <label className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-all ${
              productData.visibility === 'public' ? 'border-[#FFC94A] bg-[#FFC94A]/10' : 'border-white/10 bg-white/5 hover:bg-white/10'
            }`}>
              <RadioGroupItem value="public" />
              <Eye className="w-4 h-4 text-green-500" />
              <div>
                <span className="text-sm font-medium text-white">Public</span>
                <p className="text-xs text-gray-500">Visible par tous dans la boutique</p>
              </div>
            </label>
            <label className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-all ${
              productData.visibility === 'private' ? 'border-[#FFC94A] bg-[#FFC94A]/10' : 'border-white/10 bg-white/5 hover:bg-white/10'
            }`}>
              <RadioGroupItem value="private" />
              <Lock className="w-4 h-4 text-yellow-500" />
              <div>
                <span className="text-sm font-medium text-white">Privé</span>
                <p className="text-xs text-gray-500">Accessible uniquement via un lien direct</p>
              </div>
            </label>
            <label className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-all ${
              productData.visibility === 'broodway' ? 'border-[#FFC94A] bg-[#FFC94A]/10' : 'border-white/10 bg-white/5 hover:bg-white/10'
            }`}>
              <RadioGroupItem value="broodway" />
              <ShoppingBag className="w-4 h-4 text-[#FFC94A]" />
              <div>
                <span className="text-sm font-medium text-white">Boutique Brood-Way</span>
                <p className="text-xs text-gray-500">Mis en avant dans notre sélection officielle</p>
              </div>
            </label>
          </RadioGroup>
        </div>
      </div>

      <div className="flex justify-center gap-4 pt-4">
        <Button variant="outline" onClick={onBack} className="px-6 bg-white/5 border-white/10 text-white hover:bg-white/10">
          <ChevronLeft className="w-4 h-4 mr-1" />
          Retour
        </Button>
        <Button 
          onClick={onContinue}
          disabled={!productData.isOriginal || !productData.hasRights || !productData.acceptTerms}
          className="px-6 bg-[#FFC94A] text-black hover:bg-[#FFD666]"
        >
          Étape suivante
          <ChevronRight className="w-4 h-4 ml-1" />
        </Button>
      </div>
    </div>
  );
}

// Étape 5 : Confirmation
function StepConfirmation({ project, productData, onSubmit, onBack, isSubmitting }) {
  return (
    <div className="max-w-xl mx-auto space-y-6">
      <div className="text-center mb-4">
        <h3 className="text-xl font-bold text-white mb-2">Confirmation</h3>
        <p className="text-sm text-gray-400">Vérifiez les informations avant de soumettre.</p>
      </div>

      <div className="space-y-3 max-h-[50vh] overflow-y-auto pr-2">
        {/* Récap visuel */}
        <div className="flex items-center gap-4 p-4 bg-white/5 rounded-xl">
          <ProjectThumbnail project={project} size={80} />
          <div className="flex-1">
            <h4 className="font-bold text-white text-lg">{productData.title}</h4>
            <p className="text-sm text-gray-400">{project.pattern?.width} × {project.pattern?.height} points</p>
            <div className="flex items-center gap-2 mt-1">
              <Badge className="bg-[#FFC94A]/20 text-[#FFC94A] border-0">{productData.difficulty}</Badge>
              <span className="text-lg font-bold text-[#FFC94A]">{productData.price.toFixed(2)} €</span>
            </div>
          </div>
        </div>

        {/* Détails */}
        <div className="space-y-2 p-4 bg-white/5 rounded-xl">
          <div className="flex justify-between text-sm">
            <span className="text-gray-400">Description</span>
            <span className="text-white text-right max-w-[200px] truncate">{productData.description || '-'}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-400">Tags</span>
            <span className="text-white">{productData.tags.join(', ') || '-'}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-400">Visibilité</span>
            <span className="text-white capitalize">{productData.visibility}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-400">Contenu du pack</span>
            <span className="text-white">{productData.packContents.length} éléments</span>
          </div>
        </div>

        {/* Revenus estimés */}
        <div className="p-4 bg-gradient-to-r from-green-500/10 to-emerald-500/10 border border-green-500/20 rounded-xl">
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-300">Revenus par vente</span>
            <span className="text-xl font-bold text-green-400">{(productData.price * 0.85).toFixed(2)} €</span>
          </div>
          <p className="text-xs text-gray-500 mt-1">Commission Brood-Way : 15%</p>
        </div>
      </div>

      <div className="flex justify-center gap-4 pt-4">
        <Button variant="outline" onClick={onBack} className="px-6 bg-white/5 border-white/10 text-white hover:bg-white/10">
          <ChevronLeft className="w-4 h-4 mr-1" />
          Retour
        </Button>
        <Button 
          onClick={onSubmit}
          disabled={isSubmitting}
          className="px-6 bg-gradient-to-r from-[#FFC94A] to-[#FFD666] text-black hover:opacity-90 font-bold"
        >
          {isSubmitting ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Soumission...
            </>
          ) : (
            <>
              <ShoppingBag className="w-4 h-4 mr-2" />
              Soumettre à la Boutique
            </>
          )}
        </Button>
      </div>
    </div>
  );
}

// Étape 6 : Succès
function StepSuccess({ productData, onClose }) {
  return (
    <div className="flex flex-col items-center justify-center py-8 text-center max-w-md mx-auto">
      <div className="w-20 h-20 rounded-full bg-green-500/20 flex items-center justify-center mb-6">
        <CheckCircle2 className="w-10 h-10 text-green-500" />
      </div>
      
      <h3 className="text-xl font-bold text-white mb-2">Projet soumis avec succès !</h3>
      <p className="text-gray-400 mb-6 max-w-xs">
        Votre motif "{productData.title}" a été soumis à la boutique Brood-Way. 
        Vous recevrez une notification une fois validé.
      </p>

      <div className="p-4 bg-white/5 rounded-xl w-full mb-6">
        <div className="flex items-center justify-between text-sm">
          <span className="text-gray-400">Statut</span>
          <Badge className="bg-yellow-500/20 text-yellow-400 border-0">En attente de validation</Badge>
        </div>
      </div>

      <Button onClick={onClose} className="bg-[#FFC94A] text-black hover:bg-[#FFD666]">
        Fermer
      </Button>
    </div>
  );
}

// Composant principal - FENÊTRE CENTRALE STYLE BOUTIQUE
export default function ShopSubmitPanel({ open, onClose }) {
  const queryClient = useQueryClient();
  const [step, setStep] = useState(1);
  const [selectedProject, setSelectedProject] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const [productData, setProductData] = useState({
    title: '',
    description: '',
    tags: [],
    difficulty: 'Intermédiaire',
    packContents: ['grid', 'legend', 'preview'],
    price: 4.99,
    isOriginal: false,
    hasRights: false,
    acceptTerms: false,
    visibility: 'public',
  });

  // Charger les projets
  const { data: projects = [], isLoading } = useQuery({
    queryKey: ['grids'],
    queryFn: () => base44.entities.Grid.list('-updated_date'),
    enabled: open,
  });

  // Reset quand on ouvre
  useEffect(() => {
    if (open) {
      setStep(1);
      setSelectedProject(null);
      setProductData({
        title: '',
        description: '',
        tags: [],
        difficulty: 'Intermédiaire',
        packContents: ['grid', 'legend', 'preview'],
        price: 4.99,
        isOriginal: false,
        hasRights: false,
        acceptTerms: false,
        visibility: 'public',
      });
    }
  }, [open]);

  const handleSelectProject = (project) => {
    setSelectedProject(project);
    setProductData(p => ({
      ...p,
      title: project.name || 'Sans titre',
    }));
  };

  const handleContinueFromStep1 = () => {
    if (selectedProject) {
      setStep(2);
    }
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    try {
      const user = await base44.auth.me();
      
      await base44.entities.ShopGrid.create({
        title: productData.title,
        description: productData.description,
        creator_name: user?.full_name || 'Anonyme',
        creator_email: user?.email,
        tags: productData.tags,
        difficulty: productData.difficulty.toLowerCase(),
        is_author_confirmed: productData.isOriginal && productData.hasRights,
        original_grid_id: selectedProject.id,
        pattern_size: {
          width: selectedProject.pattern?.width || 0,
          height: selectedProject.pattern?.height || 0,
        },
        grid_data: selectedProject,
        preview_image: selectedProject.pattern?.source_image || selectedProject.pattern?.sourceImage,
      });

      queryClient.invalidateQueries({ queryKey: ['shopGrids'] });
      setStep(6);
    } catch (error) {
      console.error('Erreur soumission:', error);
      toast.error('Erreur lors de la soumission');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="w-[90vw] max-w-5xl h-[85vh] p-0 bg-[#0a0a0a] border-[#222] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#222] bg-gradient-to-r from-[#FFC94A]/10 to-[#F59E0B]/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#FFC94A] to-[#FFD666] flex items-center justify-center">
              <ShoppingBag className="w-5 h-5 text-black" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white">Soumettre à la Boutique</h2>
              <p className="text-xs text-gray-400">Étape {step}/5</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4 text-white" />
          </button>
        </div>

        {/* Progress bar */}
        {step < 6 && (
          <div className="px-6 py-3 border-b border-[#222]">
            <div className="flex gap-1">
              {[1, 2, 3, 4, 5].map(s => (
                <div
                  key={s}
                  className={`flex-1 h-1.5 rounded-full transition-colors ${
                    s <= step ? 'bg-[#FFC94A]' : 'bg-white/10'
                  }`}
                />
              ))}
            </div>
          </div>
        )}

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {step === 1 && (
            <StepSelectProject
              projects={projects}
              isLoading={isLoading}
              selectedProject={selectedProject}
              onSelect={handleSelectProject}
              onContinue={handleContinueFromStep1}
            />
          )}
          {step === 2 && selectedProject && (
            <StepVerification
              project={selectedProject}
              onContinue={() => setStep(3)}
              onBack={() => setStep(1)}
            />
          )}
          {step === 3 && selectedProject && (
            <StepProductDetails
              project={selectedProject}
              productData={productData}
              setProductData={setProductData}
              onContinue={() => setStep(4)}
              onBack={() => setStep(2)}
            />
          )}
          {step === 4 && (
            <StepPricingRights
              productData={productData}
              setProductData={setProductData}
              onContinue={() => setStep(5)}
              onBack={() => setStep(3)}
            />
          )}
          {step === 5 && selectedProject && (
            <StepConfirmation
              project={selectedProject}
              productData={productData}
              onSubmit={handleSubmit}
              onBack={() => setStep(4)}
              isSubmitting={isSubmitting}
            />
          )}
          {step === 6 && (
            <StepSuccess
              productData={productData}
              onClose={onClose}
            />
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}