import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Copy, Trash2, X } from 'lucide-react';

export default function ObjectPropertiesPanel({ 
  object, 
  onClose, 
  onUpdate, 
  onDuplicate, 
  onDelete 
}) {
  if (!object) return null;

  const isText = object.type === 'text';
  const isMotif = object.type === 'motif';

  return (
    <div className="absolute top-20 right-4 w-80 bg-white rounded-xl shadow-2xl border border-slate-200 z-50">
      <div className="p-4 border-b border-slate-200 flex items-center justify-between">
        <h3 className="font-semibold text-slate-900">
          {isText ? 'Propriétés du texte' : 'Propriétés du motif'}
        </h3>
        <button
          onClick={onClose}
          className="p-1 hover:bg-slate-100 rounded transition-colors"
        >
          <X className="w-4 h-4 text-slate-400" />
        </button>
      </div>

      <div className="p-4 space-y-4">
        {/* Contenu du texte */}
        {isText && (
          <div className="space-y-2">
            <Label>Contenu du texte</Label>
            <Input
              value={object.text}
              onChange={(e) => onUpdate({ ...object, text: e.target.value })}
            />
          </div>
        )}

        {/* Nom du motif */}
        {isMotif && (
          <div className="space-y-2">
            <Label>Nom du motif</Label>
            <p className="text-sm text-slate-600">{object.name}</p>
          </div>
        )}

        {/* Taille */}
        {isText && (
          <div className="space-y-2">
            <Label>Taille</Label>
            <Select 
              value={object.size} 
              onValueChange={(v) => onUpdate({ ...object, size: v })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="small">Petit</SelectItem>
                <SelectItem value="medium">Moyen</SelectItem>
                <SelectItem value="large">Grand</SelectItem>
              </SelectContent>
            </Select>
          </div>
        )}

        {/* Scale pour motif */}
        {isMotif && (
          <div className="space-y-2">
            <Label>Échelle ({Math.round(object.scale * 100)}%)</Label>
            <input
              type="range"
              min="50"
              max="300"
              value={object.scale * 100}
              onChange={(e) => onUpdate({ ...object, scale: parseInt(e.target.value) / 100 })}
              className="w-full"
            />
          </div>
        )}

        {/* Rotation */}
        <div className="space-y-2">
          <Label>Rotation ({object.rotation}°)</Label>
          <input
            type="range"
            min="0"
            max="360"
            step="15"
            value={object.rotation}
            onChange={(e) => onUpdate({ ...object, rotation: parseInt(e.target.value) })}
            className="w-full"
          />
        </div>

        {/* Position */}
        <div className="space-y-2">
          <Label>Position</Label>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <Input
                type="number"
                value={object.x}
                onChange={(e) => onUpdate({ ...object, x: parseInt(e.target.value) || 0 })}
                placeholder="X"
              />
            </div>
            <div>
              <Input
                type="number"
                value={object.y}
                onChange={(e) => onUpdate({ ...object, y: parseInt(e.target.value) || 0 })}
                placeholder="Y"
              />
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="pt-4 border-t border-slate-200 space-y-2">
          <Button
            variant="outline"
            className="w-full justify-start"
            onClick={onDuplicate}
          >
            <Copy className="w-4 h-4 mr-2" />
            Dupliquer (Ctrl+D)
          </Button>
          <Button
            variant="outline"
            className="w-full justify-start text-red-600 hover:text-red-700 hover:bg-red-50"
            onClick={onDelete}
          >
            <Trash2 className="w-4 h-4 mr-2" />
            Supprimer
          </Button>
        </div>
      </div>
    </div>
  );
}