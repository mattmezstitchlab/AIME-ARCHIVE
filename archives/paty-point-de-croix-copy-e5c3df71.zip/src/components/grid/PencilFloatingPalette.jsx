import React from 'react';
import { 
  MousePointer2, 
  Pipette, 
  PaintBucket, 
  Eraser, 
  Pencil,
  FlipHorizontal,
  FlipVertical,
  RotateCw, 
  Trash2,
  RefreshCw,
  Hand
} from 'lucide-react';
import { toast } from 'sonner';

const TOOLS = [
  { id: 'select', icon: MousePointer2, label: 'Sélection rectangulaire', requiresSelection: false, requiresGrid: true },
  { id: 'pipette', icon: Pipette, label: 'Pipette DMC', requiresSelection: false, requiresGrid: true },
  { id: 'fill', icon: PaintBucket, label: 'Remplir une zone', requiresSelection: false, requiresGrid: true },
  { id: 'eraser', icon: Eraser, label: 'Gomme', requiresSelection: false, requiresGrid: true },
  { id: 'replaceColor', icon: RefreshCw, label: 'Remplacer couleur', requiresSelection: true, requiresGrid: true },
  { id: 'draw', icon: Pencil, label: 'Dessiner case par case', requiresSelection: false, requiresGrid: true },
  { id: 'pan', icon: Hand, label: 'Déplacement', requiresSelection: false, requiresGrid: false },
  { id: 'rotate', icon: RotateCw, label: 'Rotation 90°', requiresSelection: true, requiresGrid: true },
  { id: 'flipH', icon: FlipHorizontal, label: 'Miroir horizontal', requiresSelection: true, requiresGrid: true },
  { id: 'flipV', icon: FlipVertical, label: 'Miroir vertical', requiresSelection: true, requiresGrid: true },
  { id: 'delete', icon: Trash2, label: 'Supprimer sélection', requiresSelection: true, requiresGrid: true },
];

export default function PencilFloatingPalette({ 
  isOpen, 
  toolSelected = 'select',
  selectionActive = false,
  hasGrid = false,
  onToolSelect,
  onRotateSelection,
  onFlipSelection,
  onClearSelection,
  onClose 
}) {
  if (!isOpen) return null;

  const handleToolClick = (tool) => {
    // Si l'outil nécessite une grille et qu'il n'y en a pas
    if (tool.requiresGrid && !hasGrid) {
      toast.info("Aucune grille chargée. Importez d'abord une image ou ouvrez un projet.");
      return;
    }

    // Si l'outil nécessite une sélection et qu'il n'y en a pas
    if (tool.requiresSelection && !selectionActive) {
      return;
    }

    // Actions spéciales qui s'exécutent immédiatement
    if (tool.id === 'rotate' && selectionActive) {
      onRotateSelection?.(90);
      toast.success('Rotation 90° appliquée');
      return;
    }
    if (tool.id === 'flipH' && selectionActive) {
      onFlipSelection?.('horizontal');
      toast.success('Miroir horizontal appliqué');
      return;
    }
    if (tool.id === 'flipV' && selectionActive) {
      onFlipSelection?.('vertical');
      toast.success('Miroir vertical appliqué');
      return;
    }
    if (tool.id === 'delete' && selectionActive) {
      onClearSelection?.();
      toast.success('Sélection supprimée');
      return;
    }

    // Toast de feedback pour les modes
    const modeMessages = {
      'pipette': 'Mode pipette activé – cliquez sur une case pour sélectionner sa couleur.',
      'fill': 'Mode remplissage activé – cliquez sur une zone à remplir.',
      'select': 'Mode sélection activé – dessinez un rectangle.',
      'draw': 'Mode dessin activé – cliquez pour placer des points.',
      'eraser': 'Mode gomme activé – cliquez pour effacer.',
      'pan': 'Mode déplacement activé.',
    };

    if (modeMessages[tool.id] && toolSelected !== tool.id) {
      toast.success(modeMessages[tool.id]);
    }

    // Sinon, sélectionner l'outil
    onToolSelect?.(tool.id);
  };

  return (
    <div
      className="absolute z-[200]"
      style={{
        top: 'calc(100% + 10px)',
        left: '50%',
        transform: 'translateX(-50%)',
        animation: 'fadeSlideIn 120ms ease-out',
      }}
    >
      <div
        className="flex items-center gap-1 px-2"
        style={{
          height: '52px',
          backgroundColor: '#FFFFFF',
          borderRadius: '10px',
          boxShadow: '0 4px 20px rgba(0,0,0,0.15)',
          padding: '6px 8px',
        }}
      >
        {/* Outils principaux */}
        {TOOLS.map((tool) => {
          const Icon = tool.icon;
          const isActive = toolSelected === tool.id;
          const isDisabledBySelection = tool.requiresSelection && !selectionActive;
          const isDisabledByGrid = tool.requiresGrid && !hasGrid;
          const isDisabled = isDisabledBySelection || isDisabledByGrid;
          
          return (
            <button
              key={tool.id}
              onClick={() => handleToolClick(tool)}
              className="relative group"
              style={{
                width: '36px',
                height: '36px',
                borderRadius: '10px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                backgroundColor: isActive ? '#000000' : '#FFFFFF',
                border: 'none',
                cursor: isDisabled ? 'not-allowed' : 'pointer',
                opacity: isDisabled ? 0.4 : 1,
                transition: 'all 100ms ease',
                transform: 'scale(1)',
              }}
              onMouseDown={(e) => {
                if (!isDisabled) e.currentTarget.style.transform = 'scale(0.95)';
              }}
              onMouseUp={(e) => {
                e.currentTarget.style.transform = 'scale(1)';
              }}
              onMouseEnter={(e) => {
                if (!isActive && !isDisabled) e.currentTarget.style.backgroundColor = '#EFEFEF';
              }}
              onMouseLeave={(e) => {
                if (!isActive) e.currentTarget.style.backgroundColor = '#FFFFFF';
                e.currentTarget.style.transform = 'scale(1)';
              }}
            >
              <Icon 
                className="w-5 h-5" 
                style={{ color: isActive ? '#FFFFFF' : '#000000' }}
                strokeWidth={1.8}
              />
              
              {/* Tooltip */}
              <div
                className="absolute top-full mt-2 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity whitespace-nowrap"
                style={{
                  backgroundColor: '#000000',
                  color: '#FFFFFF',
                  fontSize: '11px',
                  padding: '5px 8px',
                  borderRadius: '6px',
                  zIndex: 300,
                }}
              >
                {tool.label}
                {isDisabledByGrid && ' (grille requise)'}
                {isDisabledBySelection && !isDisabledByGrid && ' (sélection requise)'}
              </div>
            </button>
          );
        })}


      </div>

      <style>{`
        @keyframes fadeSlideIn {
          from {
            opacity: 0;
            transform: translateX(-50%) translateY(-4px);
          }
          to {
            opacity: 1;
            transform: translateX(-50%) translateY(0);
          }
        }
      `}</style>
    </div>
  );
}