import React, { createContext, useContext, useState, useEffect } from 'react';

const ColorPaletteContext = createContext();

const DEFAULT_COLORS = [
  { id: 'default-1', hex: '#FFFFFF', name: 'Blanc', code: 'DMC BLANC', assignedSymbolChar: '○', totalCount: 0, doneCount: 0, progress: 0 },
  { id: 'default-2', hex: '#000000', name: 'Noir', code: 'DMC 310', assignedSymbolChar: '●', totalCount: 0, doneCount: 0, progress: 0 },
  { id: 'default-3', hex: '#D3D3D3', name: 'Gris clair', code: 'DMC 762', assignedSymbolChar: '△', totalCount: 0, doneCount: 0, progress: 0 },
  { id: 'default-4', hex: '#808080', name: 'Gris moyen', code: 'DMC 415', assignedSymbolChar: '▽', totalCount: 0, doneCount: 0, progress: 0 },
  { id: 'default-5', hex: '#404040', name: 'Gris foncé', code: 'DMC 413', assignedSymbolChar: '◆', totalCount: 0, doneCount: 0, progress: 0 },
  { id: 'default-6', hex: '#E3242B', name: 'Rouge', code: 'DMC 666', assignedSymbolChar: '★', totalCount: 0, doneCount: 0, progress: 0 },
  { id: 'default-7', hex: '#2F80ED', name: 'Bleu', code: 'DMC 797', assignedSymbolChar: '■', totalCount: 0, doneCount: 0, progress: 0 },
  { id: 'default-8', hex: '#27AE60', name: 'Vert', code: 'DMC 702', assignedSymbolChar: '▲', totalCount: 0, doneCount: 0, progress: 0 },
  { id: 'default-9', hex: '#F5C200', name: 'Jaune', code: 'DMC 973', assignedSymbolChar: '◇', totalCount: 0, doneCount: 0, progress: 0 },
  { id: 'default-10', hex: '#8B4513', name: 'Marron', code: 'DMC 433', assignedSymbolChar: '◈', totalCount: 0, doneCount: 0, progress: 0 }
];

export function ColorPaletteProvider({ children }) {
  const [palette, setPalette] = useState(DEFAULT_COLORS);
  const [isVisible, setIsVisible] = useState(true);
  const [selectedColorId, setSelectedColorId] = useState(null);

  const updatePalette = (newPalette) => {
    if (newPalette && newPalette.length > 0) {
      setPalette(newPalette);
    }
  };

  const resetToDefault = () => {
    setPalette(DEFAULT_COLORS);
  };

  return (
    <ColorPaletteContext.Provider 
      value={{ 
        palette, 
        updatePalette, 
        resetToDefault,
        isVisible, 
        setIsVisible,
        selectedColorId,
        setSelectedColorId
      }}
    >
      {children}
    </ColorPaletteContext.Provider>
  );
}

export function useColorPalette() {
  const context = useContext(ColorPaletteContext);
  if (!context) {
    throw new Error('useColorPalette must be used within a ColorPaletteProvider');
  }
  return context;
}