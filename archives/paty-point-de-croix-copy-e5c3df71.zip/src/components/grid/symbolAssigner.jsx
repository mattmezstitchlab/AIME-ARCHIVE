// Liste de symboles disponibles pour l'assignation automatique
// Ordre optimisé: symboles les plus lisibles en premier
export const SYMBOL_LIBRARY = [
  '▲', '●', '■', '◆', '○', '△', '□', '◎', '✦', '✳',
  '✖', '✚', '✢', '✺', '♢', '♣', '♠', '♡', '▣', '▪',
  '▫', '▴', '▾', '◂', '▸', '※', '★', '◐', '◑', '⬟',
  '⬡', '✧', '◈', '◇', '▼', '◀', '▶', '⬢', '⬣', '◉',
  '◍', '◌', '◯', '⬤', '◊', '✕', '✱', '✲', '✴', '✶',
  '✸', '✹', '❖', '❋', '❊', '❉', '❈', '⊛', '⊚', '⊙',
  '⊕', '⊗', '⊘', '⊜', '⊝', '⊞', '⊟', '⊠', '⊡', 'ϟ',
];

/**
 * Assigne automatiquement des symboles aux couleurs qui n'en ont pas
 * @param {Array} colorPalette - Palette de couleurs
 * @returns {Array} Palette avec symboles assignés
 */
export function assignMissingSymbols(colorPalette) {
  if (!colorPalette || colorPalette.length === 0) return colorPalette;

  // Collecter les symboles déjà utilisés
  const usedSymbols = new Set();
  colorPalette.forEach(color => {
    if (color.assignedSymbolChar && color.assignedSymbolChar.trim() !== '') {
      usedSymbols.add(color.assignedSymbolChar);
    }
  });

  // Trouver les symboles disponibles
  const availableSymbols = SYMBOL_LIBRARY.filter(s => !usedSymbols.has(s));

  let symbolIndex = 0;

  return colorPalette.map((color, idx) => {
    // Vérifier si le symbole est manquant ou vide
    const hasSymbol = color.assignedSymbolChar && color.assignedSymbolChar.trim() !== '';

    if (!hasSymbol) {
      // Assigner un nouveau symbole
      let newSymbol;
      if (symbolIndex < availableSymbols.length) {
        newSymbol = availableSymbols[symbolIndex];
        symbolIndex++;
      } else {
        // Si on a épuisé les symboles, utiliser un symbole avec index
        newSymbol = SYMBOL_LIBRARY[idx % SYMBOL_LIBRARY.length];
      }

      return {
        ...color,
        assignedSymbolId: color.assignedSymbolId || `symbol-${idx}`,
        assignedSymbolChar: newSymbol,
      };
    }

    return color;
  });
}

/**
 * Vérifie et corrige les doublons de symboles dans la palette
 * @param {Array} colorPalette - Palette de couleurs
 * @returns {Array} Palette sans doublons de symboles
 */
export function fixDuplicateSymbols(colorPalette) {
  if (!colorPalette || colorPalette.length === 0) return colorPalette;

  const symbolCount = {};
  const result = [];

  // Première passe: compter les occurrences
  colorPalette.forEach(color => {
    const symbol = color.assignedSymbolChar;
    if (symbol) {
      symbolCount[symbol] = (symbolCount[symbol] || 0) + 1;
    }
  });

  // Collecter les symboles uniques utilisés
  const usedSymbols = new Set();
  
  // Deuxième passe: réassigner les doublons
  colorPalette.forEach((color, idx) => {
    const symbol = color.assignedSymbolChar;

    if (!symbol || usedSymbols.has(symbol)) {
      // Trouver un nouveau symbole unique
      const availableSymbol = SYMBOL_LIBRARY.find(s => !usedSymbols.has(s));
      if (availableSymbol) {
        usedSymbols.add(availableSymbol);
        result.push({
          ...color,
          assignedSymbolId: `symbol-${idx}`,
          assignedSymbolChar: availableSymbol,
        });
      } else {
        // Fallback: symbole avec numéro
        const fallback = `${idx + 1}`;
        usedSymbols.add(fallback);
        result.push({
          ...color,
          assignedSymbolId: `symbol-${idx}`,
          assignedSymbolChar: fallback,
        });
      }
    } else {
      usedSymbols.add(symbol);
      result.push(color);
    }
  });

  return result;
}

/**
 * Fonction complète pour réparer tous les symboles d'une palette
 * - Assigne les symboles manquants
 * - Corrige les doublons
 * @param {Array} colorPalette - Palette de couleurs
 * @returns {{ palette: Array, fixedCount: number }} Palette réparée et nombre de corrections
 */
export function fixAllSymbols(colorPalette) {
  if (!colorPalette || colorPalette.length === 0) {
    return { palette: colorPalette, fixedCount: 0 };
  }

  // Compter les problèmes avant
  let missingCount = 0;
  const symbolsSeen = new Set();
  let duplicateCount = 0;

  colorPalette.forEach(color => {
    const symbol = color.assignedSymbolChar?.trim();
    if (!symbol) {
      missingCount++;
    } else if (symbolsSeen.has(symbol)) {
      duplicateCount++;
    } else {
      symbolsSeen.add(symbol);
    }
  });

  // Appliquer les corrections
  let fixedPalette = assignMissingSymbols(colorPalette);
  fixedPalette = fixDuplicateSymbols(fixedPalette);

  const fixedCount = missingCount + duplicateCount;

  return { palette: fixedPalette, fixedCount };
}

/**
 * Vérifie si la palette contient des symboles manquants ou en doublon
 * @param {Array} colorPalette - Palette de couleurs
 * @returns {{ hasMissing: boolean, hasDuplicates: boolean, missingCount: number, duplicateCount: number }}
 */
export function checkSymbolsStatus(colorPalette) {
  if (!colorPalette || colorPalette.length === 0) {
    return { hasMissing: false, hasDuplicates: false, missingCount: 0, duplicateCount: 0 };
  }

  let missingCount = 0;
  const symbolsSeen = new Set();
  let duplicateCount = 0;

  colorPalette.forEach(color => {
    const symbol = color.assignedSymbolChar?.trim();
    if (!symbol) {
      missingCount++;
    } else if (symbolsSeen.has(symbol)) {
      duplicateCount++;
    } else {
      symbolsSeen.add(symbol);
    }
  });

  return {
    hasMissing: missingCount > 0,
    hasDuplicates: duplicateCount > 0,
    missingCount,
    duplicateCount,
  };
}

/**
 * Applique les symboles de la palette à toutes les cellules de la grille
 * @param {Array} symbolGrid - Grille de symboles
 * @param {Array} colorPalette - Palette de couleurs avec symboles
 * @returns {Array} Grille mise à jour
 */
export function applySymbolsToGrid(symbolGrid, colorPalette) {
  if (!symbolGrid || !colorPalette) return symbolGrid;

  // Créer un map colorId -> symbol
  const symbolMap = {};
  colorPalette.forEach(color => {
    if (color.id && color.assignedSymbolChar) {
      symbolMap[color.id] = color.assignedSymbolChar;
    }
  });

  // Appliquer à chaque cellule
  return symbolGrid.map(row => 
    row?.map(cell => {
      if (cell && cell.colorId && symbolMap[cell.colorId]) {
        return { ...cell, symbol: symbolMap[cell.colorId] };
      }
      return cell;
    }) || []
  );
}