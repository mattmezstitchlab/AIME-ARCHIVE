import React from 'react';

// Convertir un numéro de ligne (0-based) en lettre (A, B, C, ..., Z, AA, AB, ...)
const rowToLetter = (row) => {
  const blockIndex = Math.floor(row / 10);
  if (blockIndex < 26) {
    return String.fromCharCode(65 + blockIndex);
  }
  // Pour les grands projets : AA, AB, etc.
  const first = Math.floor(blockIndex / 26) - 1;
  const second = blockIndex % 26;
  if (first >= 0) {
    return String.fromCharCode(65 + first) + String.fromCharCode(65 + second);
  }
  return String.fromCharCode(65 + second);
};

export default function GridRulers({
  nbColonnes,
  nbLignes,
  tailleCase,
  zoom,
  offsetX,
  offsetY,
  nightMode = false,
  highlightZone = null // { letter, number } pour surligner une zone
}) {
  const effectiveTailleCase = tailleCase * zoom;
  const rulerSize = 28;
  
  // Couleurs selon le mode
  const bgColor = nightMode ? '#111' : '#f8f8f8';
  const textColor = nightMode ? '#FFD700' : '#333';
  const borderColor = nightMode ? '#333' : '#ddd';
  const highlightBg = nightMode ? 'rgba(255, 215, 0, 0.3)' : 'rgba(59, 130, 246, 0.3)';
  
  // Calculer les graduations visibles
  const numHorizontalBlocks = Math.ceil(nbColonnes / 10);
  const numVerticalBlocks = Math.ceil(nbLignes / 10);
  
  // Graduations horizontales (numéros par 10)
  const horizontalMarks = [];
  for (let i = 0; i < numHorizontalBlocks; i++) {
    const colStart = i * 10;
    const x = offsetX + colStart * effectiveTailleCase;
    const width = 10 * effectiveTailleCase;
    const isHighlighted = highlightZone && highlightZone.number === i + 1;
    
    horizontalMarks.push(
      <div
        key={`h-${i}`}
        className="absolute flex items-center justify-center text-xs font-medium transition-all duration-200"
        style={{
          left: `${x}px`,
          top: 0,
          width: `${width}px`,
          height: `${rulerSize}px`,
          backgroundColor: isHighlighted ? highlightBg : 'transparent',
          color: textColor,
          borderRight: `1px solid ${borderColor}`,
        }}
      >
        {i + 1}
      </div>
    );
  }
  
  // Graduations verticales (lettres par 10)
  const verticalMarks = [];
  for (let i = 0; i < numVerticalBlocks; i++) {
    const rowStart = i * 10;
    const y = offsetY + rowStart * effectiveTailleCase;
    const height = 10 * effectiveTailleCase;
    const letter = rowToLetter(rowStart);
    const isHighlighted = highlightZone && highlightZone.letter === letter;
    
    verticalMarks.push(
      <div
        key={`v-${i}`}
        className="absolute flex items-center justify-center text-xs font-medium transition-all duration-200"
        style={{
          left: 0,
          top: `${y}px`,
          width: `${rulerSize}px`,
          height: `${height}px`,
          backgroundColor: isHighlighted ? highlightBg : 'transparent',
          color: textColor,
          borderBottom: `1px solid ${borderColor}`,
        }}
      >
        {letter}
      </div>
    );
  }
  
  return (
    <>
      {/* Règle horizontale (en haut) */}
      <div
        className="absolute z-30 overflow-hidden"
        style={{
          left: `${rulerSize}px`,
          top: 0,
          right: 0,
          height: `${rulerSize}px`,
          backgroundColor: bgColor,
          borderBottom: `1px solid ${borderColor}`,
        }}
      >
        <div className="relative h-full" style={{ width: `${nbColonnes * effectiveTailleCase + Math.abs(offsetX)}px` }}>
          {horizontalMarks}
        </div>
      </div>
      
      {/* Règle verticale (à gauche) */}
      <div
        className="absolute z-30 overflow-hidden"
        style={{
          left: 0,
          top: `${rulerSize}px`,
          width: `${rulerSize}px`,
          bottom: 0,
          backgroundColor: bgColor,
          borderRight: `1px solid ${borderColor}`,
        }}
      >
        <div className="relative w-full" style={{ height: `${nbLignes * effectiveTailleCase + Math.abs(offsetY)}px` }}>
          {verticalMarks}
        </div>
      </div>
      
      {/* Coin supérieur gauche */}
      <div
        className="absolute z-40"
        style={{
          left: 0,
          top: 0,
          width: `${rulerSize}px`,
          height: `${rulerSize}px`,
          backgroundColor: bgColor,
          borderRight: `1px solid ${borderColor}`,
          borderBottom: `1px solid ${borderColor}`,
        }}
      />
    </>
  );
}

// Utilitaire pour parser une coordonnée GPS (ex: "D8" -> { letter: "D", number: 8, row: 30, col: 70 })
export function parseGPSCoordinate(input) {
  if (!input) return null;
  
  const match = input.toUpperCase().match(/^([A-Z]{1,2})(\d+)$/);
  if (!match) return null;
  
  const letter = match[1];
  const number = parseInt(match[2], 10);
  
  // Convertir la lettre en index de bloc (A=0, B=1, ..., Z=25, AA=26, etc.)
  let letterIndex = 0;
  if (letter.length === 1) {
    letterIndex = letter.charCodeAt(0) - 65;
  } else {
    letterIndex = (letter.charCodeAt(0) - 65 + 1) * 26 + (letter.charCodeAt(1) - 65);
  }
  
  // Calculer la ligne et colonne de départ de la zone 10x10
  const row = letterIndex * 10;
  const col = (number - 1) * 10;
  
  return {
    letter,
    number,
    row,
    col,
    // Centre de la zone
    centerRow: row + 5,
    centerCol: col + 5
  };
}