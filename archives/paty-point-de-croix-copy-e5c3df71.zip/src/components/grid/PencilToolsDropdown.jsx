import React, { useState } from 'react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

// Outils simplifiés avec descriptions complètes
const PENCIL_TOOLS = [
  { 
    id: 'point', 
    name: 'Point', 
    category: 'pencil',
    description: 'Ajouter un point à l\'emplacement choisi.',
    tip: 'Maintiens pour poser plusieurs points.',
    activeState: 'Point en cours',
  },
  { 
    id: 'remplissage', 
    name: 'Remplissage', 
    category: 'pencil', 
    hasSettings: true,
    description: 'Remplir automatiquement une zone continue.',
    tip: 'Clique dans une zone pour la remplir.',
    activeState: 'Remplissage activé',
    settings: [
      { id: 'limite', label: 'Limite de zone', options: ['Petite', 'Moyenne', 'Large'] },
    ],
  },
  { 
    id: 'auto-couleur', 
    name: 'Auto-couleur', 
    category: 'pencil', 
    hasSettings: true,
    description: 'Choisir la couleur optimale automatiquement.',
    tip: 'Clique et l\'outil sélectionne la meilleure couleur.',
    activeState: 'Auto-couleur ON',
    settings: [
      { id: 'mode', label: 'Mode', options: ['Fidèle au visuel', 'Harmonisé', 'Contraste doux'] },
    ],
  },
];

const ERASER_TOOLS = [
  { 
    id: 'gomme-point', 
    name: 'Point', 
    category: 'eraser',
    description: 'Effacer un point sans affecter les autres.',
    tip: 'Parfait pour corriger un détail.',
    activeState: 'Gomme point active',
  },
  { 
    id: 'gomme-zone', 
    name: 'Zone', 
    category: 'eraser', 
    hasSettings: true,
    description: 'Effacer toute une zone en un geste.',
    tip: 'Clique dans la zone à nettoyer.',
    activeState: 'Gomme zone active',
    settings: [
      { id: 'etendue', label: 'Étendue', options: ['Petite', 'Moyenne', 'Large'] },
    ],
  },
];

const SELECTION_TOOLS = [
  { 
    id: 'selection-zone', 
    name: 'Zone', 
    category: 'selection',
    description: 'Sélectionner une partie de la grille.',
    tip: 'Clique et glisse pour tracer une zone.',
    activeState: 'Zone sélectionnée',
    hasSettings: true,
    settings: [
      { id: 'action', label: 'Action', options: ['Agrandir', 'Réduire', 'Annuler'] },
    ],
  },
  { 
    id: 'selection-intelligente', 
    name: 'Sélection intelligente', 
    category: 'selection', 
    hasSettings: true,
    description: 'Sélectionner les mêmes symboles automatiquement.',
    tip: 'Idéal pour travailler une couleur précise.',
    activeState: 'Sélection intelligente active',
    settings: [
      { id: 'etendue', label: 'Étendue', options: ['Zone visible', 'Projet entier'] },
    ],
  },
];

export default function PencilToolsDropdown({ 
  children, 
  currentSubTool, 
  onSelectSubTool,
  onSelectEraserTool,
  onSelectSelectionTool,
  open,
  onOpenChange 
}) {
  const [expandedTool, setExpandedTool] = useState(null);
  const [toolSettings, setToolSettings] = useState({
    remplissage: { limite: 'Moyenne' },
    'auto-couleur': { mode: 'Fidèle au visuel' },
    'gomme-zone': { etendue: 'Moyenne' },
    'selection-zone': { action: 'Agrandir' },
    'selection-intelligente': { etendue: 'Zone visible' },
  });

  const handleToolClick = (tool) => {
    if (tool.category === 'pencil') onSelectSubTool(tool.id);
    else if (tool.category === 'eraser') onSelectEraserTool?.(tool.id);
    else if (tool.category === 'selection') onSelectSelectionTool?.(tool.id);
    
    if (tool.hasSettings) {
      setExpandedTool(expandedTool === tool.id ? null : tool.id);
    } else {
      setExpandedTool(null);
    }
  };

  const updateSetting = (toolId, settingId, value) => {
    setToolSettings(prev => ({
      ...prev,
      [toolId]: { ...prev[toolId], [settingId]: value }
    }));
  };

  const renderToolItem = (tool, accentColor) => {
    const isActive = currentSubTool === tool.id;
    const isExpanded = expandedTool === tool.id;

    return (
      <div key={tool.id}>
        <button
          onClick={() => handleToolClick(tool)}
          className={`w-full text-left px-4 py-3 transition-all ${
            isActive 
              ? 'bg-white/10' 
              : 'hover:bg-white/5'
          }`}
        >
          <div className="flex items-center justify-between mb-1">
            <span className={`text-sm font-medium ${isActive ? 'text-white' : 'text-[#ccc]'}`}>
              {tool.name}
            </span>
            <div className="flex items-center gap-2">
              {isActive && (
                <span 
                  className="px-1.5 py-0.5 text-[9px] font-semibold rounded"
                  style={{ backgroundColor: accentColor, color: '#111' }}
                >
                  ACTIF
                </span>
              )}
              {tool.hasSettings && (
                <span className="text-[#555] text-[10px]">{isExpanded ? '▲' : '▼'}</span>
              )}
            </div>
          </div>
          <p className="text-[#666] text-[11px] leading-tight">{tool.description}</p>
        </button>

        {/* Sous-menu réglages */}
        {isExpanded && tool.hasSettings && tool.settings && (
          <div className="px-4 py-3 bg-[#0d0d0d] border-t border-[#222]">
            {/* Astuce */}
            <p className="text-[#888] text-[10px] mb-3 italic">💡 {tool.tip}</p>
            
            {/* Réglages */}
            {tool.settings.map(setting => (
              <div key={setting.id} className="mb-2">
                <label className="text-[#777] text-[10px] uppercase tracking-wide mb-1.5 block">
                  {setting.label}
                </label>
                <div className="flex gap-1 flex-wrap">
                  {setting.options.map(option => (
                    <button
                      key={option}
                      onClick={(e) => {
                        e.stopPropagation();
                        updateSetting(tool.id, setting.id, option);
                      }}
                      className={`px-2 py-1 text-[10px] rounded transition-all ${
                        toolSettings[tool.id]?.[setting.id] === option
                          ? 'bg-white/20 text-white'
                          : 'bg-white/5 text-[#888] hover:bg-white/10'
                      }`}
                    >
                      {option}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    );
  };

  return (
    <DropdownMenu open={open} onOpenChange={onOpenChange}>
      <DropdownMenuTrigger asChild>
        {children}
      </DropdownMenuTrigger>
      <DropdownMenuContent 
        side="bottom" 
        align="start" 
        className="w-64 p-0 bg-[#1a1a1a] border-[#333] rounded-xl overflow-hidden max-h-[80vh] overflow-y-auto"
        sideOffset={8}
      >
        {/* Section Crayon */}
        <div className="px-4 py-2.5 border-b border-[#333] bg-[#111]">
          <span className="text-[#FFC94A] font-semibold text-[11px] uppercase tracking-wider">
            Crayon
          </span>
          <p className="text-[#555] text-[10px] mt-0.5">Je dessine des points</p>
        </div>
        <div className="divide-y divide-[#222]">
          {PENCIL_TOOLS.map(tool => renderToolItem(tool, '#FFC94A'))}
        </div>

        {/* Section Gomme */}
        <div className="px-4 py-2.5 border-t border-b border-[#333] bg-[#111]">
          <span className="text-[#A855F7] font-semibold text-[11px] uppercase tracking-wider">
            Gomme
          </span>
          <p className="text-[#555] text-[10px] mt-0.5">J'efface des points</p>
        </div>
        <div className="divide-y divide-[#222]">
          {ERASER_TOOLS.map(tool => renderToolItem(tool, '#A855F7'))}
        </div>

        {/* Section Sélection */}
        <div className="px-4 py-2.5 border-t border-b border-[#333] bg-[#111]">
          <span className="text-[#3B82F6] font-semibold text-[11px] uppercase tracking-wider">
            Sélection
          </span>
          <p className="text-[#555] text-[10px] mt-0.5">Je cible une zone</p>
        </div>
        <div className="divide-y divide-[#222]">
          {SELECTION_TOOLS.map(tool => renderToolItem(tool, '#3B82F6'))}
        </div>

        {/* Footer raccourcis */}
        <div className="px-4 py-2.5 bg-[#0a0a0a] border-t border-[#333]">
          <p className="text-[#555] text-[9px] text-center">
            Échap annuler · Ctrl+Z retour · Maj+clic multiple
          </p>
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

export { PENCIL_TOOLS, ERASER_TOOLS, SELECTION_TOOLS };