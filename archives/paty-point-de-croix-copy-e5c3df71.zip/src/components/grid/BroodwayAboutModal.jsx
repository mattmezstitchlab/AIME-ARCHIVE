import React, { useState, useEffect } from 'react';
import { X, Upload, Map, Palette, Wand2, Eye, MapPin, Save, ShoppingBag, Bot, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';

// Symboles animés
const SYMBOLS = [
  { char: '✕', color: '#FFC94A' },
  { char: '●', color: '#EF4444' },
  { char: '▲', color: '#22C55E' },
  { char: '■', color: '#3B82F6' },
  { char: '◆', color: '#A855F7' },
  { char: '★', color: '#F97316' },
  { char: '♥', color: '#EC4899' },
  { char: '✿', color: '#14B8A6' },
];

// Logo BW central avec symbole animé
function BWCenterLogo() {
  const [symbolIndex, setSymbolIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setSymbolIndex(prev => (prev + 1) % SYMBOLS.length);
    }, 800);
    return () => clearInterval(interval);
  }, []);

  const currentSymbol = SYMBOLS[symbolIndex];

  return (
    <div className="flex items-center justify-center gap-2">
      <span 
        className="text-6xl font-black text-white tracking-tighter"
        style={{ fontFamily: 'system-ui, -apple-system, sans-serif' }}
      >
        B
      </span>
      <span 
        className="text-3xl font-bold transition-all duration-200"
        style={{ 
          color: currentSymbol.color, 
          textShadow: `0 0 20px ${currentSymbol.color}80`,
        }}
      >
        {currentSymbol.char}
      </span>
      <span 
        className="text-6xl font-black text-white tracking-tighter"
        style={{ fontFamily: 'system-ui, -apple-system, sans-serif' }}
      >
        W
      </span>
    </div>
  );
}

// Section de fonctionnalité
function FeatureSection({ icon: Icon, emoji, title, children }) {
  return (
    <div className="py-4 border-b border-[#222] last:border-0">
      <div className="flex items-start gap-3">
        <div className="w-8 h-8 rounded-lg bg-[#FFC94A]/20 flex items-center justify-center flex-shrink-0 mt-0.5">
          {emoji ? (
            <span className="text-base">{emoji}</span>
          ) : (
            <Icon className="w-4 h-4 text-[#FFC94A]" />
          )}
        </div>
        <div>
          <h4 className="text-white font-semibold text-sm mb-1">{title}</h4>
          <p className="text-gray-400 text-xs leading-relaxed">{children}</p>
        </div>
      </div>
    </div>
  );
}

export default function BroodwayAboutModal({ open, onClose, onImport }) {
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[500] flex items-center justify-center">
      {/* Fond assombri */}
      <div 
        className="absolute inset-0 bg-black/70 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Modal */}
      <div 
        className="relative bg-[#0a0a0a] rounded-2xl shadow-2xl border border-[#333] overflow-hidden flex flex-col"
        style={{ width: '550px', maxWidth: '95vw', maxHeight: '90vh' }}
      >
        {/* Bouton fermer */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 hover:bg-white/10 rounded-lg transition-colors z-10"
        >
          <X className="w-5 h-5 text-gray-400" />
        </button>

        {/* Header avec logo */}
        <div className="p-6 bg-gradient-to-b from-[#FFC94A]/10 to-transparent text-center flex-shrink-0">
          <BWCenterLogo />
          <p className="text-[#FFC94A] text-sm mt-3 font-medium">
            Là où chaque point devient éternel
          </p>
        </div>

        {/* Contenu scrollable */}
        <div className="flex-1 overflow-y-auto px-6 pb-4">
          {/* Introduction */}
          <div className="bg-gradient-to-r from-[#FFC94A]/10 to-[#F97316]/10 rounded-xl p-4 mb-4 border border-[#FFC94A]/20">
            <p className="text-gray-300 text-xs leading-relaxed">
              <span className="text-white font-semibold">Brood-Way™</span> est la première application de broderie conçue comme un véritable studio professionnel, mais pensée pour être utilisée aussi facilement qu'un carnet papier.
            </p>
            <p className="text-gray-400 text-xs leading-relaxed mt-2">
              Ici, vous n'avez plus besoin de chercher, reconstruire, compter, télécharger des PDF ou deviner la bonne couleur : tout est automatique, intelligent et instantané.
            </p>
          </div>

          {/* Fonctionnalités */}
          <FeatureSection icon={Upload} emoji="🧠" title="Import Intelligent™">
            Importez une image, un PDF, une grille découpée ou un scan… Brood-Way™ reconstruit automatiquement la grille complète, recolle les pages, génère les symboles, répare les manques et choisit les meilleures couleurs DMC pour vous.
          </FeatureSection>

          <FeatureSection icon={Map} emoji="🗺️" title="Navigation GPS 10×10">
            Tapez une "coordonnée" comme F12 : Brood-Way™ vous téléporte directement dans la zone que vous voulez broder. Plus rapide, plus clair, impossible de se perdre.
          </FeatureSection>

          <FeatureSection icon={Wand2} emoji="🎚️" title="Outils intelligents">
            Crayon, Gomme, Sélection, Remplissage… Chaque outil possède des modes intelligents (point magique, anti-bavure, nettoyage de zone, focus couleur…) pour aller 10x plus vite.
          </FeatureSection>

          <FeatureSection icon={Eye} emoji="🎨" title="Affichage Pro">
            Choisissez votre vue : Symboles, couleurs, mix, mode XXL, haute visibilité, mode nuit, anti-fatigue… Votre grille s'adapte à vous.
          </FeatureSection>

          <FeatureSection icon={MapPin} emoji="🧩" title="Mini-carte Pro™">
            Gardez toujours un aperçu de toute votre création, téléportez-vous d'un point à un autre, et suivez votre progression d'un simple coup d'œil.
          </FeatureSection>

          <FeatureSection icon={Save} emoji="💾" title="Sauvegarde intelligente">
            Votre progression est enregistrée automatiquement : zones complétées, réglages, styles d'affichage, position exacte dans la grille… Vous reprenez toujours là où vous vous êtes arrêté.
          </FeatureSection>

          <FeatureSection icon={ShoppingBag} emoji="🛒" title="Boutique intégrée">
            Transformez vos créations en modèles prêts à vendre. Un seul clic suffit pour générer la grille couleur, la grille symboles, la liste DMC, le fichier SUB et le PDF imprimable.
          </FeatureSection>

          <FeatureSection icon={Bot} emoji="🤖" title="BroodIA™ — Votre assistante">
            Posez-lui une question. Dites-lui où vous voulez aller. Demandez-lui comment faire. BroodIA™ peut vous guider, analyser votre grille, vous expliquer un outil, ou vous mener directement à la section désirée.
          </FeatureSection>

          {/* Conclusion */}
          <div className="bg-gradient-to-r from-[#FFC94A]/10 to-[#F97316]/10 rounded-xl p-4 mt-4 border border-[#FFC94A]/20">
            <p className="text-gray-300 text-xs leading-relaxed">
              C'est la version <span className="text-white font-semibold">moderne, rapide et intuitive</span> de la broderie traditionnelle, respectueuse des habitudes anciennes, mais propulsée par des technologies intelligentes.
            </p>
            <div className="flex flex-wrap gap-2 mt-3 text-xs text-[#FFC94A]">
              <span>👉 tout est automatisé</span>
              <span>👉 tout est plus clair</span>
              <span>👉 tout est plus agréable</span>
            </div>
          </div>
        </div>

        {/* Footer avec bouton */}
        <div className="p-4 border-t border-[#333] bg-[#111] flex-shrink-0">
          <Button
            onClick={() => {
              onClose();
              if (onImport) onImport();
            }}
            className="w-full bg-[#FFC94A] hover:bg-[#FFD666] text-black font-bold"
          >
            <Sparkles className="w-4 h-4 mr-2" />
            Commencer à broder
          </Button>
        </div>
      </div>
    </div>
  );
}