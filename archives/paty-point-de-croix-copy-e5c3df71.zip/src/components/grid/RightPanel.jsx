import React from 'react';
import { Eye, EyeOff, Grid3x3, Target, Image } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';

export default function RightPanel({
  showPatternImage,
  showPatternSymbols,
  showGrid,
  showCenterMarker,
  onTogglePatternImage,
  onTogglePatternSymbols,
  onToggleGrid,
  onToggleCenterMarker,
  pattern,
  onOpenColorPalette
}) {
  // Calculer la progression globale
  const totalStitches = pattern?.symbolGrid?.flat().filter(cell => cell).length || 0;
  const doneStitches = pattern?.symbolGrid?.flat().filter(cell => cell?.done).length || 0;
  const globalProgress = totalStitches > 0 ? Math.round((doneStitches / totalStitches) * 100) : 0;

  return (
    <aside className="w-80 p-4 flex-shrink-0 overflow-y-auto space-y-4" style={{ paddingBottom: '160px' }}>
      {/* Section Affichage */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4">
        <h3 className="text-sm font-semibold text-slate-700 mb-3">Affichage</h3>
        <div className="space-y-2">
          <button
            onClick={onTogglePatternImage}
            className={cn(
              "w-full flex items-center justify-between px-3 py-2 rounded-lg transition-all text-sm",
              showPatternImage
                ? "bg-slate-100 text-slate-900"
                : "bg-white hover:bg-slate-50 text-slate-600"
            )}
          >
            <span className="flex items-center gap-2">
              <Image className="w-4 h-4" />
              Visuel importé
            </span>
            {showPatternImage ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
          </button>

          <button
            onClick={onTogglePatternSymbols}
            className={cn(
              "w-full flex items-center justify-between px-3 py-2 rounded-lg transition-all text-sm",
              showPatternSymbols
                ? "bg-slate-100 text-slate-900"
                : "bg-white hover:bg-slate-50 text-slate-600"
            )}
          >
            <span className="flex items-center gap-2">
              <span className="text-lg">●</span>
              Symboles
            </span>
            {showPatternSymbols ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
          </button>

          <button
            onClick={onToggleGrid}
            className={cn(
              "w-full flex items-center justify-between px-3 py-2 rounded-lg transition-all text-sm",
              showGrid
                ? "bg-slate-100 text-slate-900"
                : "bg-white hover:bg-slate-50 text-slate-600"
            )}
          >
            <span className="flex items-center gap-2">
              <Grid3x3 className="w-4 h-4" />
              Grille
            </span>
            {showGrid ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
          </button>

          <button
            onClick={onToggleCenterMarker}
            className={cn(
              "w-full flex items-center justify-between px-3 py-2 rounded-lg transition-all text-sm",
              showCenterMarker
                ? "bg-slate-100 text-slate-900"
                : "bg-white hover:bg-slate-50 text-slate-600"
            )}
          >
            <span className="flex items-center gap-2">
              <Target className="w-4 h-4" />
              Repère central
            </span>
            {showCenterMarker ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Section Couleurs Détectées */}
      {pattern?.colorPalette && pattern.colorPalette.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4">
          <h3 className="text-sm font-semibold text-slate-700 mb-3">Couleurs détectées</h3>
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {pattern.colorPalette.map((color) => (
              <div
                key={color.id}
                className="flex items-center gap-2 p-2 rounded-lg hover:bg-slate-50 transition-colors"
              >
                <div
                  className="w-8 h-8 rounded border border-slate-300 flex-shrink-0"
                  style={{ backgroundColor: color.hex }}
                />
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-medium text-slate-900 truncate">
                    {color.name}
                  </div>
                  <div className="text-xs text-slate-500">
                    {color.totalCount} pts
                  </div>
                </div>
              </div>
            ))}
          </div>
          <Button
            onClick={onOpenColorPalette}
            variant="outline"
            className="w-full mt-3"
          >
            Voir palette complète
          </Button>
        </div>
      )}

      {/* Section Progression */}
      {pattern && (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4">
          <h3 className="text-sm font-semibold text-slate-700 mb-3">Progression</h3>
          <div className="space-y-3">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-slate-600">Progression globale</span>
                <span className="text-xs font-semibold text-slate-900">{globalProgress}%</span>
              </div>
              <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-emerald-500 to-emerald-600 transition-all duration-300"
                  style={{ width: `${globalProgress}%` }}
                />
              </div>
            </div>
            <div className="pt-2 border-t border-slate-200">
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-600">Points brodés</span>
                <span className="font-semibold text-slate-900">{doneStitches} / {totalStitches}</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </aside>
  );
}