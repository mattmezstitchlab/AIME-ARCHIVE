import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Sparkles, CheckCircle, Loader2, ArrowLeft } from 'lucide-react';
import { toast } from 'sonner';

const STEPS = [
  { id: 'clean', label: 'Nettoyage des défauts', emoji: '🧹' },
  { id: 'simplify', label: 'Simplification intelligente', emoji: '🎯' },
  { id: 'finalize', label: 'Optimisation finale', emoji: '✨' }
];

export default function OptimizationDialog({ open, onClose, pattern, onOptimized }) {
  const [currentStep, setCurrentStep] = useState(null);
  const [progress, setProgress] = useState(0);
  const [stats, setStats] = useState(null);
  const [optimizedPattern, setOptimizedPattern] = useState(null);
  const [originalPattern, setOriginalPattern] = useState(null);
  const [showComparison, setShowComparison] = useState(false);

  useEffect(() => {
    if (open && pattern) {
      setOriginalPattern(JSON.parse(JSON.stringify(pattern)));
      setCurrentStep(null);
      setProgress(0);
      setStats(null);
      setOptimizedPattern(null);
      setShowComparison(false);
    }
  }, [open, pattern]);

  const handleStartOptimization = async () => {
    if (!pattern) return;

    try {
      const { 
        cleanPatternDefects, 
        simplifyPattern, 
        applySimplification, 
        finalizeOptimization 
      } = await import('./patternOptimization');

      let currentPattern = JSON.parse(JSON.stringify(pattern));

      // Étape 1: Nettoyage
      setCurrentStep('clean');
      setProgress(10);
      await sleep(500);
      currentPattern = cleanPatternDefects(currentPattern);
      setProgress(33);
      await sleep(500);

      // Étape 2: Simplification
      setCurrentStep('simplify');
      setProgress(40);
      await sleep(500);
      const { stats: simplifyStats, colorGroups } = simplifyPattern(currentPattern, { threshold: 20 });
      setStats(simplifyStats);
      setProgress(50);
      await sleep(500);

      // Appliquer la simplification si utile
      if (simplifyStats.reductionPercent > 10) {
        currentPattern = applySimplification(currentPattern, colorGroups);
      }
      setProgress(66);
      await sleep(500);

      // Étape 3: Finalisation
      setCurrentStep('finalize');
      setProgress(75);
      await sleep(500);
      currentPattern = finalizeOptimization(currentPattern);
      setProgress(100);
      await sleep(500);

      setOptimizedPattern(currentPattern);
      setCurrentStep('complete');
      toast.success('Optimisation terminée avec succès !');

    } catch (error) {
      console.error('Erreur optimisation:', error);
      toast.error('Erreur lors de l\'optimisation');
      setCurrentStep(null);
    }
  };

  const handleValidate = () => {
    if (optimizedPattern) {
      onOptimized(optimizedPattern);
      onClose();
      toast.success('Motif optimisé appliqué');
    }
  };

  const handleCancel = () => {
    onClose();
    toast.info('Optimisation annulée');
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl bg-black/95 text-white border-slate-700">
        <div className="space-y-6">
          {/* En-tête */}
          <div className="text-center">
            <div className="flex items-center justify-center gap-2 mb-2">
              <Sparkles className="w-6 h-6 text-yellow-400" />
              <h2 className="text-2xl font-bold">Optimisation IA du Motif</h2>
            </div>
            <p className="text-slate-400 text-sm">
              PatyBee nettoie, simplifie et harmonise votre grille
            </p>
          </div>

          {/* Timeline des étapes */}
          {!currentStep && (
            <div className="space-y-3">
              {STEPS.map((step, index) => (
                <div
                  key={step.id}
                  className="flex items-center gap-3 p-3 bg-slate-800/50 rounded-lg border border-slate-700"
                >
                  <div className="text-2xl">{step.emoji}</div>
                  <div className="flex-1">
                    <div className="font-semibold text-sm">
                      {index + 1}. {step.label}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Progression */}
          {currentStep && currentStep !== 'complete' && (
            <div className="space-y-4">
              <div className="space-y-2">
                {STEPS.map((step) => (
                  <div
                    key={step.id}
                    className={`flex items-center gap-3 p-3 rounded-lg transition-all ${
                      currentStep === step.id
                        ? 'bg-indigo-600/30 border border-indigo-500'
                        : step.id === 'clean' && ['simplify', 'finalize'].includes(currentStep)
                        ? 'bg-green-600/20 border border-green-500'
                        : step.id === 'simplify' && currentStep === 'finalize'
                        ? 'bg-green-600/20 border border-green-500'
                        : 'bg-slate-800/30 border border-slate-700'
                    }`}
                  >
                    <div className="text-2xl">{step.emoji}</div>
                    <div className="flex-1">
                      <div className="font-semibold text-sm">{step.label}</div>
                    </div>
                    {currentStep === step.id && (
                      <Loader2 className="w-5 h-5 animate-spin text-indigo-400" />
                    )}
                    {(step.id === 'clean' && ['simplify', 'finalize'].includes(currentStep)) ||
                     (step.id === 'simplify' && currentStep === 'finalize') ? (
                      <CheckCircle className="w-5 h-5 text-green-400" />
                    ) : null}
                  </div>
                ))}
              </div>

              <Progress value={progress} className="h-2" />
              <div className="text-center text-sm text-slate-400">
                Traitement en cours... {progress}%
              </div>
            </div>
          )}

          {/* Résultats */}
          {currentStep === 'complete' && stats && (
            <div className="space-y-4">
              <div className="flex items-center justify-center gap-2 mb-4">
                <CheckCircle className="w-8 h-8 text-green-400" />
                <h3 className="text-xl font-bold text-green-400">
                  Optimisation terminée avec succès !
                </h3>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div className="bg-slate-800/50 rounded-lg p-4 text-center">
                  <div className="text-3xl font-bold text-indigo-400">
                    {stats.currentColors}
                  </div>
                  <div className="text-xs text-slate-400 mt-1">Couleurs avant</div>
                </div>
                <div className="bg-slate-800/50 rounded-lg p-4 text-center">
                  <div className="text-3xl font-bold text-green-400">
                    {stats.simplifiedColors}
                  </div>
                  <div className="text-xs text-slate-400 mt-1">Couleurs après</div>
                </div>
                <div className="bg-slate-800/50 rounded-lg p-4 text-center">
                  <div className="text-3xl font-bold text-yellow-400">
                    -{stats.reductionPercent}%
                  </div>
                  <div className="text-xs text-slate-400 mt-1">Réduction</div>
                </div>
              </div>

              {stats.complexityReduced && (
                <div className="bg-green-600/20 border border-green-500 rounded-lg p-3">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="w-5 h-5 text-green-400" />
                    <span className="text-sm font-semibold text-green-400">
                      Complexité réduite avec succès
                    </span>
                  </div>
                </div>
              )}

              {stats.recommendations && stats.recommendations.length > 0 && (
                <div className="space-y-2">
                  <div className="text-sm font-semibold text-slate-300">
                    Recommandations IA :
                  </div>
                  {stats.recommendations.map((rec, index) => (
                    <div
                      key={index}
                      className="flex items-start gap-2 text-sm text-slate-400"
                    >
                      <span className="text-yellow-400">•</span>
                      <span>{rec}</span>
                    </div>
                  ))}
                </div>
              )}

              <div className="text-sm text-slate-400 text-center">
                Votre motif est maintenant parfaitement brodable et lisible.
              </div>
            </div>
          )}

          {/* Boutons d'action */}
          <div className="flex gap-3">
            {!currentStep && (
              <>
                <Button
                  variant="outline"
                  onClick={handleCancel}
                  className="flex-1 border-slate-600 text-white hover:bg-slate-800"
                >
                  Annuler
                </Button>
                <Button
                  onClick={handleStartOptimization}
                  className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white"
                >
                  <Sparkles className="w-4 h-4 mr-2" />
                  Lancer l'optimisation
                </Button>
              </>
            )}

            {currentStep === 'complete' && (
              <>
                <Button
                  variant="outline"
                  onClick={() => setShowComparison(!showComparison)}
                  className="border-slate-600 text-white hover:bg-slate-800"
                >
                  {showComparison ? 'Masquer' : 'Voir'} avant/après
                </Button>
                <Button
                  variant="outline"
                  onClick={handleCancel}
                  className="border-slate-600 text-white hover:bg-slate-800"
                >
                  Revenir à l'original
                </Button>
                <Button
                  onClick={handleValidate}
                  className="bg-green-600 hover:bg-green-700 text-white"
                >
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Valider l'optimisation
                </Button>
              </>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}