// Utilitaire pour détecter et regrouper les couleurs d'une image

/**
 * Calcule la distance entre deux couleurs RGB
 */
function colorDistance(c1, c2) {
  const dr = c1.r - c2.r;
  const dg = c1.g - c2.g;
  const db = c1.b - c2.b;
  return Math.sqrt(dr * dr + dg * dg + db * db);
}

/**
 * Détecte et regroupe les couleurs d'une image pixelisée
 * @param {HTMLCanvasElement} pixelatedCanvas - Canvas contenant l'image pixelisée
 * @param {number} maxColors - Nombre maximum de couleurs à détecter
 * @param {number} threshold - Seuil de distance pour regrouper les couleurs
 * @returns {Array} Palette de couleurs détectées
 */
export function detectColors(pixelatedCanvas, maxColors = 90, threshold = 30) {
  const ctx = pixelatedCanvas.getContext('2d');
  const width = pixelatedCanvas.width;
  const height = pixelatedCanvas.height;
  const imageData = ctx.getImageData(0, 0, width, height);
  const pixels = imageData.data;
  
  // Extraire toutes les couleurs uniques
  const colorMap = new Map();
  
  for (let i = 0; i < pixels.length; i += 4) {
    const r = pixels[i];
    const g = pixels[i + 1];
    const b = pixels[i + 2];
    const a = pixels[i + 3];
    
    // Ignorer les pixels transparents
    if (a < 128) continue;
    
    const key = `${r},${g},${b}`;
    colorMap.set(key, (colorMap.get(key) || 0) + 1);
  }
  
  // Convertir en tableau de couleurs avec compteur
  let colors = Array.from(colorMap.entries()).map(([key, count]) => {
    const [r, g, b] = key.split(',').map(Number);
    return { r, g, b, count };
  });
  
  // Trier par fréquence décroissante
  colors.sort((a, b) => b.count - a.count);
  
  // Clustering : regrouper les couleurs proches
  const clusters = [];
  
  for (const color of colors) {
    // Trouver le cluster le plus proche
    let closestCluster = null;
    let minDistance = Infinity;
    
    for (const cluster of clusters) {
      const dist = colorDistance(color, cluster);
      if (dist < minDistance) {
        minDistance = dist;
        closestCluster = cluster;
      }
    }
    
    // Si une couleur proche existe et est sous le seuil, l'ajouter au cluster
    if (closestCluster && minDistance < threshold) {
      closestCluster.colors.push(color);
      closestCluster.totalCount += color.count;
      
      // Recalculer la couleur moyenne du cluster
      const totalPixels = closestCluster.colors.reduce((sum, c) => sum + c.count, 0);
      closestCluster.r = Math.round(
        closestCluster.colors.reduce((sum, c) => sum + c.r * c.count, 0) / totalPixels
      );
      closestCluster.g = Math.round(
        closestCluster.colors.reduce((sum, c) => sum + c.g * c.count, 0) / totalPixels
      );
      closestCluster.b = Math.round(
        closestCluster.colors.reduce((sum, c) => sum + c.b * c.count, 0) / totalPixels
      );
    } else {
      // Créer un nouveau cluster
      clusters.push({
        r: color.r,
        g: color.g,
        b: color.b,
        colors: [color],
        totalCount: color.count
      });
    }
  }
  
  // Trier les clusters par fréquence et limiter au nombre max
  clusters.sort((a, b) => b.totalCount - a.totalCount);
  const limitedClusters = clusters.slice(0, maxColors);
  
  // Créer la palette finale
  const palette = limitedClusters.map((cluster, index) => ({
    id: `COLOR_${String(index + 1).padStart(3, '0')}`,
    r: cluster.r,
    g: cluster.g,
    b: cluster.b,
    hex: `#${cluster.r.toString(16).padStart(2, '0')}${cluster.g.toString(16).padStart(2, '0')}${cluster.b.toString(16).padStart(2, '0')}`,
    name: `Couleur ${index + 1}`,
    count: cluster.totalCount,
    assignedSymbolId: null
  }));
  
  return palette;
}

/**
 * Trouve la couleur la plus proche dans une palette
 */
export function findClosestColor(r, g, b, palette) {
  let closestColor = null;
  let minDistance = Infinity;
  
  for (const color of palette) {
    const dist = colorDistance({ r, g, b }, color);
    if (dist < minDistance) {
      minDistance = dist;
      closestColor = color;
    }
  }
  
  return closestColor;
}

/**
 * Génère une grille de symboles basée sur l'image et la palette
 */
export function generateSymbolGrid(pixelatedCanvas, palette) {
  const ctx = pixelatedCanvas.getContext('2d');
  const width = pixelatedCanvas.width;
  const height = pixelatedCanvas.height;
  
  const grid = [];
  
  for (let row = 0; row < height; row++) {
    const rowData = [];
    for (let col = 0; col < width; col++) {
      const pixelData = ctx.getImageData(col, row, 1, 1).data;
      const r = pixelData[0];
      const g = pixelData[1];
      const b = pixelData[2];
      const a = pixelData[3];
      
      if (a < 128) {
        rowData.push(null); // Pixel transparent
      } else {
        const closestColor = findClosestColor(r, g, b, palette);
        rowData.push({
          colorId: closestColor.id,
          symbolId: closestColor.assignedSymbolId
        });
      }
    }
    grid.push(rowData);
  }
  
  return grid;
}