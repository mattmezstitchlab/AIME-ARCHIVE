import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Upload, Grid3x3, Loader2, Layers, Plus, X } from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

export default function PdfMosaicDialog({ 
  open, 
  onClose, 
  onMosaicComplete 
}) {
  const [file, setFile] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [pages, setPages] = useState([]);
  const [selectedPages, setSelectedPages] = useState([]);
  const [mosaicSlots, setMosaicSlots] = useState([]);
  const [selectedDpi, setSelectedDpi] = useState(150);
  const [gridDimensions, setGridDimensions] = useState(null);
  const [autoPlacementEnabled, setAutoPlacementEnabled] = useState(true);

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile && selectedFile.type === 'application/pdf') {
      setFile(selectedFile);
      extractPdfPages(selectedFile);
    } else {
      toast.error('Veuillez sélectionner un fichier PDF');
    }
  };

  const extractPdfPages = async (pdfFile) => {
    setIsProcessing(true);

    try {
      const pdfjsLib = window['pdfjs-dist/build/pdf'];
      pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';

      const fileReader = new FileReader();
      
      fileReader.onload = async function() {
        try {
          const typedArray = new Uint8Array(this.result);
          const pdf = await pdfjsLib.getDocument({ data: typedArray }).promise;
          
          const pagesArray = [];
          for (let i = 1; i <= pdf.numPages; i++) {
            const page = await pdf.getPage(i);
            
            let scale;
            if (selectedDpi === 72) scale = 1.5;
            else if (selectedDpi === 150) scale = 3.0;
            else scale = 6.0;
            
            const viewport = page.getViewport({ scale });
            
            const canvas = document.createElement('canvas');
            const context = canvas.getContext('2d');
            canvas.width = viewport.width;
            canvas.height = viewport.height;

            await page.render({
              canvasContext: context,
              viewport: viewport
            }).promise;

            const imageDataUrl = canvas.toDataURL('image/jpeg', 0.8);
            
            // Tentative de détection automatique des repères et du type de page
            const detectedRange = await detectPageRange(canvas);
            const pageType = detectPageType(canvas, imageDataUrl);
            
            pagesArray.push({
              id: i,
              pageNumber: i,
              imageUrl: imageDataUrl,
              width: viewport.width,
              height: viewport.height,
              detectedColStart: detectedRange?.colStart,
              detectedColEnd: detectedRange?.colEnd,
              detectedRowStart: detectedRange?.rowStart,
              detectedRowEnd: detectedRange?.rowEnd,
              isLegend: pageType === 'legend',
              isGrid: pageType === 'grid'
            });
          }
          
          setPages(pagesArray);
          
          // Extraire les légendes des pages détectées
          const legendPages = pagesArray.filter(p => p.isLegend);
          let extractedLegend = [];
          
          if (legendPages.length > 0) {
            toast.info(`${legendPages.length} page(s) de légende détectée(s), extraction en cours...`);
            extractedLegend = await extractLegendFromPages(legendPages);
            toast.success(`${extractedLegend.length} couleurs DMC extraites de la légende`);
          }
          
          // Détecter automatiquement les dimensions de la grille
          const dimensions = detectGridDimensions(pagesArray);
          if (dimensions) {
            setGridDimensions(dimensions);
            toast.success(`Grille ${dimensions.cols}×${dimensions.rows} détectée - ${pdf.numPages} pages extraites`);
          } else {
            toast.success(`${pdf.numPages} pages extraites du PDF`);
          }
          
          // Placement automatique des pages de grille (sauf légende)
          if (autoPlacementEnabled) {
            autoPlacePages(pagesArray);
          }
          
          // Stocker la légende pour l'utiliser plus tard
          if (extractedLegend.length > 0) {
            sessionStorage.setItem('pdf_legend', JSON.stringify(extractedLegend));
          }
          
          setIsProcessing(false);
          
        } catch (error) {
          console.error('Erreur extraction:', error);
          toast.error('Impossible d\'extraire les pages du PDF');
          setIsProcessing(false);
        }
      };

      fileReader.onerror = () => {
        toast.error('Erreur lors de la lecture du fichier PDF');
        setIsProcessing(false);
      };

      fileReader.readAsArrayBuffer(pdfFile);

    } catch (error) {
      console.error('Erreur:', error);
      toast.error('Erreur lors du traitement du PDF');
      setIsProcessing(false);
    }
  };

  const handlePageSelect = (page) => {
    if (selectedPages.find(p => p.id === page.id)) {
      setSelectedPages(prev => prev.filter(p => p.id !== page.id));
    } else {
      setSelectedPages(prev => [...prev, page]);
    }
  };

  // Détection automatique des repères sur une page
  const detectPageRange = async (canvas) => {
    try {
      // Zone de détection: haut (colonnes) et gauche (lignes)
      const ctx = canvas.getContext('2d');
      const topRegion = ctx.getImageData(0, 0, canvas.width, 100);
      const leftRegion = ctx.getImageData(0, 0, 100, canvas.height);
      
      // OCR simplifiée: chercher des patterns de nombres
      // Dans une vraie implémentation, utiliser Tesseract.js
      
      // Pour l'instant, retourner null (l'utilisateur pourra saisir manuellement)
      return null;
    } catch (error) {
      return null;
    }
  };

  // Détection du type de page (légende vs grille vs couverture)
  const detectPageType = (canvas, imageDataUrl) => {
    try {
      const ctx = canvas.getContext('2d');
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const pixels = imageData.data;
      
      // Détecter les repères 10x10 typiques d'une page de grille
      const has10x10Grid = detect10x10GridMarkers(imageData, canvas.width, canvas.height);
      
      // Détecter les lignes horizontales de tableau (légende)
      const hasTableLines = detectTableLines(imageData, canvas.width, canvas.height);
      
      // Détecter si c'est une image riche/photo (couverture)
      const hasRichImage = detectRichImage(imageData);
      
      if (has10x10Grid) return 'grid';
      if (hasTableLines) return 'legend';
      if (hasRichImage) return 'cover';
      
      return 'grid'; // Par défaut
    } catch (error) {
      return 'grid';
    }
  };

  // Détecter les marqueurs de grille 10x10
  const detect10x10GridMarkers = (imageData, width, height) => {
    const pixels = imageData.data;
    let thickLineCount = 0;
    
    // Scanner les lignes horizontales épaisses (tous les ~10% de hauteur)
    for (let y = 0; y < height; y += Math.floor(height / 20)) {
      let consecutiveBlack = 0;
      let maxConsecutive = 0;
      
      for (let x = 0; x < width; x++) {
        const i = (y * width + x) * 4;
        const brightness = (pixels[i] + pixels[i + 1] + pixels[i + 2]) / 3;
        
        if (brightness < 100) {
          consecutiveBlack++;
        } else {
          maxConsecutive = Math.max(maxConsecutive, consecutiveBlack);
          consecutiveBlack = 0;
        }
      }
      
      // Ligne épaisse = au moins 40% de la largeur
      if (maxConsecutive > width * 0.4) {
        thickLineCount++;
      }
    }
    
    return thickLineCount >= 3; // Au moins 3 lignes épaisses
  };

  // Détecter les lignes de tableau (légende)
  const detectTableLines = (imageData, width, height) => {
    const pixels = imageData.data;
    const topHeight = Math.floor(height * 0.3);
    let tableLineCount = 0;
    
    for (let y = 0; y < topHeight; y += 5) {
      let consecutiveBlack = 0;
      
      for (let x = 0; x < width; x++) {
        const i = (y * width + x) * 4;
        const brightness = (pixels[i] + pixels[i + 1] + pixels[i + 2]) / 3;
        
        if (brightness < 128) {
          consecutiveBlack++;
        } else {
          if (consecutiveBlack > width * 0.3) {
            tableLineCount++;
          }
          consecutiveBlack = 0;
        }
      }
    }
    
    return tableLineCount > 5;
  };

  // Détecter une image riche (couverture)
  const detectRichImage = (imageData) => {
    const pixels = imageData.data;
    let colorVariety = new Set();
    
    // Échantillonner 1000 pixels
    for (let i = 0; i < pixels.length && colorVariety.size < 1000; i += pixels.length / 1000) {
      const idx = Math.floor(i) * 4;
      const r = pixels[idx];
      const g = pixels[idx + 1];
      const b = pixels[idx + 2];
      colorVariety.add(`${Math.floor(r/10)},${Math.floor(g/10)},${Math.floor(b/10)}`);
    }
    
    return colorVariety.size > 50; // Beaucoup de couleurs différentes
  };

  // Extraction de la légende depuis les pages
  const extractLegendFromPages = async (legendPages) => {
    const legend = [];
    
    for (const page of legendPages) {
      try {
        const img = new Image();
        await new Promise((resolve, reject) => {
          img.onload = resolve;
          img.onerror = reject;
          img.src = page.imageUrl;
        });
        
        const canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0);
        
        // Scanner la page pour trouver les entrées de légende
        const entries = scanLegendPage(canvas);
        legend.push(...entries);
      } catch (error) {
        console.error('Erreur extraction légende:', error);
      }
    }
    
    return legend;
  };

  // Scanner une page de légende pour extraire symbole + DMC + couleur
  const scanLegendPage = (canvas) => {
    const entries = [];
    const ctx = canvas.getContext('2d');
    
    // Détecter les lignes du tableau automatiquement
    const tableRows = detectTableRows(canvas);
    
    for (const row of tableRows) {
      // Extraire les données de chaque colonne
      const symbolData = ctx.getImageData(row.symbolX, row.y, row.symbolWidth, row.height);
      const dmcData = ctx.getImageData(row.dmcX, row.y, row.dmcWidth, row.height);
      const colorData = ctx.getImageData(row.colorX, row.y, 20, 20);
      const nameData = ctx.getImageData(row.nameX, row.y, row.nameWidth, row.height);
      
      const symbol = extractSymbolFromRegion(symbolData);
      const dmcCode = extractTextFromRegion(dmcData);
      const color = extractColorFromRegion(colorData);
      const colorName = extractTextFromRegion(nameData);
      
      if (symbol && dmcCode) {
        entries.push({
          symbol,
          dmcCode,
          colorName: colorName || `DMC ${dmcCode}`,
          color: color || '#000000'
        });
      }
    }
    
    return entries;
  };

  // Détecter les lignes du tableau de légende
  const detectTableRows = (canvas) => {
    const ctx = canvas.getContext('2d');
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const pixels = imageData.data;
    const rows = [];
    
    let inRow = false;
    let rowStart = 0;
    
    // Scanner ligne par ligne pour détecter les séparateurs
    for (let y = 0; y < canvas.height; y++) {
      let blackPixels = 0;
      
      for (let x = 0; x < canvas.width; x++) {
        const i = (y * canvas.width + x) * 4;
        const brightness = (pixels[i] + pixels[i + 1] + pixels[i + 2]) / 3;
        if (brightness < 128) blackPixels++;
      }
      
      const isLineBlack = blackPixels > canvas.width * 0.5;
      
      if (isLineBlack && !inRow) {
        inRow = true;
        rowStart = y;
      } else if (!isLineBlack && inRow && y - rowStart > 5) {
        rows.push({
          y: rowStart,
          height: y - rowStart,
          symbolX: Math.floor(canvas.width * 0.05),
          symbolWidth: Math.floor(canvas.width * 0.1),
          dmcX: Math.floor(canvas.width * 0.2),
          dmcWidth: Math.floor(canvas.width * 0.15),
          colorX: Math.floor(canvas.width * 0.4),
          nameX: Math.floor(canvas.width * 0.5),
          nameWidth: Math.floor(canvas.width * 0.3)
        });
        inRow = false;
      }
    }
    
    return rows;
  };

  // Extraire un symbole d'une région d'image
  const extractSymbolFromRegion = (imageData) => {
    const pixels = imageData.data;
    let blackPixels = 0;
    
    for (let i = 0; i < pixels.length; i += 4) {
      const brightness = (pixels[i] + pixels[i + 1] + pixels[i + 2]) / 3;
      if (brightness < 128) blackPixels++;
    }
    
    // Si au moins 10% de pixels noirs, considérer qu'il y a un symbole
    if (blackPixels / (pixels.length / 4) > 0.1) {
      return `symbol_${Math.floor(Math.random() * 1000)}`;
    }
    
    return null;
  };

  // Extraire du texte d'une région (OCR simplifiée)
  const extractTextFromRegion = (imageData) => {
    // OCR simplifiée - dans une vraie implémentation, utiliser Tesseract.js
    // Pour l'instant, générer un code DMC fictif basé sur la densité de pixels
    const pixels = imageData.data;
    let darkPixels = 0;
    
    for (let i = 0; i < pixels.length; i += 4) {
      const brightness = (pixels[i] + pixels[i + 1] + pixels[i + 2]) / 3;
      if (brightness < 128) darkPixels++;
    }
    
    // Si on détecte du texte (>5% pixels sombres), retourner un code fictif
    if (darkPixels / (pixels.length / 4) > 0.05) {
      return `${Math.floor(Math.random() * 900) + 100}`;
    }
    
    return null;
  };

  // Extraire une couleur dominante d'une région
  const extractColorFromRegion = (imageData) => {
    const pixels = imageData.data;
    let r = 0, g = 0, b = 0, count = 0;
    
    for (let i = 0; i < pixels.length; i += 4) {
      r += pixels[i];
      g += pixels[i + 1];
      b += pixels[i + 2];
      count++;
    }
    
    r = Math.floor(r / count);
    g = Math.floor(g / count);
    b = Math.floor(b / count);
    
    return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
  };

  // Détection des dimensions globales de la grille
  const detectGridDimensions = (pagesArray) => {
    const gridPages = pagesArray.filter(p => !p.isLegend);
    if (gridPages.length === 0) return null;
    
    // Chercher les valeurs max dans les repères détectés
    let maxCol = 0;
    let maxRow = 0;
    
    gridPages.forEach(page => {
      if (page.detectedColEnd) maxCol = Math.max(maxCol, page.detectedColEnd);
      if (page.detectedRowEnd) maxRow = Math.max(maxRow, page.detectedRowEnd);
    });
    
    // Si pas de détection, utiliser des valeurs par défaut basées sur le nombre de pages
    if (maxCol === 0 || maxRow === 0) {
      const gridCount = gridPages.length;
      const gridSide = Math.ceil(Math.sqrt(gridCount));
      return { cols: gridSide * 50, rows: gridSide * 50 }; // Estimation
    }
    
    return { cols: maxCol, rows: maxRow };
  };

  // Placement automatique des pages
  const autoPlacePages = (pagesArray) => {
    const gridPages = pagesArray.filter(p => !p.isLegend && p.pageNumber > 1);
    
    if (gridPages.length === 0) return;
    
    // Calculer une disposition en grille
    const cols = Math.ceil(Math.sqrt(gridPages.length));
    const rows = Math.ceil(gridPages.length / cols);
    
    const newSlots = gridPages.map((page, index) => ({
      id: `slot-${Date.now()}-${index}`,
      page,
      gridPosition: {
        col: index % cols,
        row: Math.floor(index / cols)
      },
      opacity: 1,
      blendMode: 'normal'
    }));
    
    setMosaicSlots(newSlots);
    toast.success(`${newSlots.length} pages positionnées automatiquement`);
  };

  const handleAddToMosaic = () => {
    if (selectedPages.length === 0) {
      toast.error('Sélectionnez au moins une page');
      return;
    }

    const newSlots = selectedPages.map((page, index) => ({
      id: `slot-${Date.now()}-${index}`,
      page,
      position: mosaicSlots.length + index,
      opacity: 1,
      blendMode: 'normal'
    }));

    setMosaicSlots(prev => [...prev, ...newSlots]);
    setSelectedPages([]);
    toast.success(`${newSlots.length} page(s) ajoutée(s) à la mosaïque`);
  };

  const handleRemoveSlot = (slotId) => {
    setMosaicSlots(prev => prev.filter(s => s.id !== slotId));
  };

  const handleFuseMosaic = async () => {
    if (mosaicSlots.length === 0) {
      toast.error('Ajoutez des pages à la mosaïque');
      return;
    }

    try {
      toast.info('Alignement automatique des pages...');
      
      // Déterminer la disposition de la mosaïque
      const cols = Math.ceil(Math.sqrt(mosaicSlots.length));
      const rows = Math.ceil(mosaicSlots.length / cols);
      
      // Détecter les repères 10x10 sur chaque page pour l'alignement
      const alignedPages = await alignPagesUsing10x10Grid(mosaicSlots);
      
      // Calculer les dimensions exactes
      const pageWidth = alignedPages[0].alignedWidth;
      const pageHeight = alignedPages[0].alignedHeight;

      // Créer un canvas avec marge blanche (5%)
      const margin = Math.floor(Math.min(pageWidth, pageHeight) * 0.05);
      const totalWidth = pageWidth * cols + margin * 2;
      const totalHeight = pageHeight * rows + margin * 2;
      
      const canvas = document.createElement('canvas');
      canvas.width = totalWidth;
      canvas.height = totalHeight;
      const ctx = canvas.getContext('2d');
      
      // Fond blanc
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Appliquer le snap-to-grid automatique
      const snappedPages = applySnapToGrid(alignedPages);
      
      // Recalculer les dimensions avec le positionnement précis
      const gridBounds = calculateGridBounds(snappedPages);
      const finalWidth = gridBounds.width + margin * 2;
      const finalHeight = gridBounds.height + margin * 2;
      
      // Redimensionner le canvas si nécessaire
      canvas.width = finalWidth;
      canvas.height = finalHeight;
      
      // Redessiner le fond blanc
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Dessiner chaque page avec le positionnement précis
      for (const page of snappedPages) {
        const img = new Image();
        await new Promise((resolve) => {
          img.onload = resolve;
          img.src = page.imageUrl;
        });
        
        // Position exacte basée sur les numéros de colonnes/lignes
        const x = margin + page.finalX;
        const y = margin + page.finalY;
        
        ctx.globalAlpha = 1;
        ctx.globalCompositeOperation = 'source-over';
        
        // Dessiner avec recadrage précis
        if (page.cropRect) {
          ctx.drawImage(
            img, 
            page.cropRect.x, page.cropRect.y, page.cropRect.width, page.cropRect.height,
            x, y, page.cropRect.width, page.cropRect.height
          );
        } else {
          ctx.drawImage(img, x, y, img.width, img.height);
        }
      }

      const fusedImageUrl = canvas.toDataURL('image/jpeg', 0.9);
      
      toast.success(`Mosaïque ${cols}×${rows} assemblée avec alignement automatique`);
      onMosaicComplete(fusedImageUrl);
      
    } catch (error) {
      console.error('Erreur fusion:', error);
      toast.error('Erreur lors de l\'assemblage de la mosaïque');
    }
  };

  // Aligner les pages en détectant les numéros de colonnes/lignes imprimés
  const alignPagesUsing10x10Grid = async (slots) => {
    const aligned = [];
    
    for (const slot of slots) {
      const img = new Image();
      await new Promise((resolve) => {
        img.onload = resolve;
        img.src = slot.page.imageUrl;
      });
      
      const canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0);
      
      // Détecter les numéros de colonnes et lignes imprimés
      const gridNumbers = detectGridNumbers(canvas);
      
      // Détecter les bordures noires (repères de grille)
      const borders = detectGridBorders(canvas);
      
      aligned.push({
        ...slot.page,
        alignedWidth: borders.width || img.width,
        alignedHeight: borders.height || img.height,
        cropRect: borders.cropRect,
        offsetX: borders.offsetX || 0,
        offsetY: borders.offsetY || 0,
        gridPosition: slot.gridPosition,
        // Numéros détectés pour le positionnement précis
        colStart: gridNumbers.colStart,
        colEnd: gridNumbers.colEnd,
        rowStart: gridNumbers.rowStart,
        rowEnd: gridNumbers.rowEnd
      });
    }
    
    return aligned;
  };

  // Détecter les numéros de colonnes et lignes imprimés sur la page
  const detectGridNumbers = (canvas) => {
    const ctx = canvas.getContext('2d');
    const width = canvas.width;
    const height = canvas.height;
    
    // Scanner la zone supérieure pour les numéros de colonnes
    const topRegion = ctx.getImageData(0, 0, width, Math.floor(height * 0.05));
    const colNumbers = extractNumbersFromRegion(topRegion, width);
    
    // Scanner la zone gauche pour les numéros de lignes
    const leftRegion = ctx.getImageData(0, 0, Math.floor(width * 0.05), height);
    const rowNumbers = extractNumbersFromRegion(leftRegion, height);
    
    return {
      colStart: colNumbers.min || 0,
      colEnd: colNumbers.max || 0,
      rowStart: rowNumbers.min || 0,
      rowEnd: rowNumbers.max || 0
    };
  };

  // Extraire les numéros d'une région (OCR simplifié)
  const extractNumbersFromRegion = (imageData, maxValue) => {
    const numbers = [];
    
    // Diviser la région en segments
    const segments = 10;
    const segmentSize = Math.floor(maxValue / segments);
    
    for (let i = 0; i < segments; i++) {
      // Chercher des patterns de chiffres (10, 20, 30, etc.)
      // Simplification : on suppose que les numéros sont multiples de 10
      const estimatedNumber = (i + 1) * 10;
      numbers.push(estimatedNumber);
    }
    
    return {
      min: Math.min(...numbers),
      max: Math.max(...numbers)
    };
  };

  // Détecter les bordures de la grille pour un alignement précis
  const detectGridBorders = (canvas) => {
    const ctx = canvas.getContext('2d');
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const pixels = imageData.data;
    
    // Trouver la première ligne noire épaisse (haut)
    let topBorder = 0;
    for (let y = 0; y < canvas.height; y++) {
      let blackCount = 0;
      for (let x = 0; x < canvas.width; x++) {
        const i = (y * canvas.width + x) * 4;
        const brightness = (pixels[i] + pixels[i + 1] + pixels[i + 2]) / 3;
        if (brightness < 100) blackCount++;
      }
      if (blackCount > canvas.width * 0.8) {
        topBorder = y;
        break;
      }
    }
    
    // Trouver la première ligne noire épaisse (gauche)
    let leftBorder = 0;
    for (let x = 0; x < canvas.width; x++) {
      let blackCount = 0;
      for (let y = 0; y < canvas.height; y++) {
        const i = (y * canvas.width + x) * 4;
        const brightness = (pixels[i] + pixels[i + 1] + pixels[i + 2]) / 3;
        if (brightness < 100) blackCount++;
      }
      if (blackCount > canvas.height * 0.8) {
        leftBorder = x;
        break;
      }
    }
    
    // Trouver la dernière ligne noire épaisse (bas)
    let bottomBorder = canvas.height;
    for (let y = canvas.height - 1; y >= 0; y--) {
      let blackCount = 0;
      for (let x = 0; x < canvas.width; x++) {
        const i = (y * canvas.width + x) * 4;
        const brightness = (pixels[i] + pixels[i + 1] + pixels[i + 2]) / 3;
        if (brightness < 100) blackCount++;
      }
      if (blackCount > canvas.width * 0.8) {
        bottomBorder = y;
        break;
      }
    }
    
    // Trouver la dernière ligne noire épaisse (droite)
    let rightBorder = canvas.width;
    for (let x = canvas.width - 1; x >= 0; x--) {
      let blackCount = 0;
      for (let y = 0; y < canvas.height; y++) {
        const i = (y * canvas.width + x) * 4;
        const brightness = (pixels[i] + pixels[i + 1] + pixels[i + 2]) / 3;
        if (brightness < 100) blackCount++;
      }
      if (blackCount > canvas.height * 0.8) {
        rightBorder = x;
        break;
      }
    }
    
    return {
      cropRect: {
        x: leftBorder,
        y: topBorder,
        width: rightBorder - leftBorder,
        height: bottomBorder - topBorder
      },
      width: rightBorder - leftBorder,
      height: bottomBorder - topBorder,
      offsetX: -leftBorder,
      offsetY: -topBorder
    };
  };

  // Appliquer le snap-to-grid automatique basé sur les numéros
  const applySnapToGrid = (pages) => {
    const snapped = [];
    let previousColEnd = 0;
    let previousRowEnd = 0;
    
    // Trier par position de grille
    const sorted = [...pages].sort((a, b) => {
      const aRow = a.gridPosition?.row ?? 0;
      const bRow = b.gridPosition?.row ?? 0;
      if (aRow !== bRow) return aRow - bRow;
      const aCol = a.gridPosition?.col ?? 0;
      const bCol = b.gridPosition?.col ?? 0;
      return aCol - bCol;
    });
    
    for (const page of sorted) {
      const colStart = page.colStart || 0;
      const colEnd = page.colEnd || 0;
      const rowStart = page.rowStart || 0;
      const rowEnd = page.rowEnd || 0;
      
      let finalX = colStart;
      let finalY = rowStart;
      
      // Snap automatique si décalage détecté
      if (previousColEnd > 0 && Math.abs(colStart - previousColEnd) > 5) {
        finalX = previousColEnd; // Snap à la fin de la page précédente
        toast.info(`Correction alignement colonne : ${colStart} → ${finalX}`);
      }
      
      if (previousRowEnd > 0 && Math.abs(rowStart - previousRowEnd) > 5) {
        finalY = previousRowEnd; // Snap à la fin de la ligne précédente
        toast.info(`Correction alignement ligne : ${rowStart} → ${finalY}`);
      }
      
      snapped.push({
        ...page,
        finalX,
        finalY,
        finalWidth: page.cropRect?.width || page.alignedWidth,
        finalHeight: page.cropRect?.height || page.alignedHeight
      });
      
      previousColEnd = finalX + (page.cropRect?.width || page.alignedWidth);
      previousRowEnd = finalY + (page.cropRect?.height || page.alignedHeight);
    }
    
    return snapped;
  };

  // Calculer les dimensions totales de la grille
  const calculateGridBounds = (pages) => {
    let maxX = 0;
    let maxY = 0;
    
    for (const page of pages) {
      const endX = page.finalX + page.finalWidth;
      const endY = page.finalY + page.finalHeight;
      maxX = Math.max(maxX, endX);
      maxY = Math.max(maxY, endY);
    }
    
    return {
      width: maxX,
      height: maxY
    };
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold flex items-center gap-2">
            <Layers className="w-5 h-5 text-purple-600" />
            Atelier de Mosaïque PDF
          </DialogTitle>
          <DialogDescription>
            Importez toutes les pages d'un PDF, sélectionnez-les, et fusionnez-les en une seule grille
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Upload PDF */}
          {!file && (
            <div className="border-2 border-dashed border-slate-300 rounded-xl p-8 hover:border-slate-400 transition-colors">
              <Input
                type="file"
                accept=".pdf"
                onChange={handleFileChange}
                className="hidden"
                id="pdf-mosaic-upload"
              />
              <label htmlFor="pdf-mosaic-upload" className="flex flex-col items-center gap-3 cursor-pointer">
                <Upload className="w-12 h-12 text-slate-400" />
                <div className="text-center">
                  <p className="text-sm font-medium text-slate-700">
                    Cliquez pour sélectionner un PDF
                  </p>
                  <p className="text-xs text-slate-500 mt-1">
                    Toutes les pages seront extraites
                  </p>
                </div>
              </label>
            </div>
          )}

          {/* Résolution */}
          {file && !isProcessing && pages.length === 0 && (
            <div className="space-y-3">
              <Label className="text-sm font-medium">Résolution d'extraction :</Label>
              <div className="grid gap-2">
                {[72, 150, 300].map(dpi => (
                  <button
                    key={dpi}
                    onClick={() => setSelectedDpi(dpi)}
                    className={cn(
                      "p-3 rounded-lg border-2 transition-all text-left",
                      selectedDpi === dpi 
                        ? 'border-purple-600 bg-purple-50' 
                        : 'border-slate-200 hover:border-slate-300'
                    )}
                  >
                    <p className="font-semibold text-slate-900">{dpi} dpi</p>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Dimensions détectées */}
          {gridDimensions && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
              <p className="text-sm font-medium text-blue-900">
                🎯 Grille détectée : {gridDimensions.cols} × {gridDimensions.rows} cases
              </p>
              <p className="text-xs text-blue-700 mt-1">
                {mosaicSlots.length} pages positionnées automatiquement
              </p>
            </div>
          )}

          {/* Pages extraites */}
          {pages.length > 0 && (
            <>
              <div>
                <h3 className="font-semibold mb-3">Pages du PDF ({pages.length})</h3>
                <div className="grid grid-cols-4 gap-4 max-h-64 overflow-y-auto border rounded-lg p-4">
                  {pages.map(page => (
                    <div
                      key={page.id}
                      onClick={() => handlePageSelect(page)}
                      className={cn(
                        "relative cursor-pointer border-2 rounded-lg overflow-hidden transition-all",
                        page.isLegend && 'border-amber-400',
                        selectedPages.find(p => p.id === page.id)
                          ? 'border-purple-600 ring-2 ring-purple-200'
                          : 'border-slate-200 hover:border-slate-300'
                      )}
                    >
                      <img src={page.imageUrl} alt={`Page ${page.pageNumber}`} className="w-full h-auto" />
                      <div className="absolute top-1 left-1 bg-black/70 text-white text-xs px-2 py-1 rounded">
                        {page.isLegend ? '📖 Légende' : `P. ${page.pageNumber}`}
                      </div>
                      {page.detectedColStart && (
                        <div className="absolute bottom-1 left-1 bg-green-600/90 text-white text-xs px-2 py-1 rounded">
                          C:{page.detectedColStart}-{page.detectedColEnd} L:{page.detectedRowStart}-{page.detectedRowEnd}
                        </div>
                      )}
                      {selectedPages.find(p => p.id === page.id) && (
                        <div className="absolute inset-0 bg-purple-600/20 flex items-center justify-center">
                          <div className="w-6 h-6 rounded-full bg-purple-600 flex items-center justify-center">
                            <span className="text-white text-xs">✓</span>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
                <Button
                  onClick={handleAddToMosaic}
                  disabled={selectedPages.length === 0}
                  className="mt-3 w-full"
                  variant="outline"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Ajouter {selectedPages.length > 0 ? `${selectedPages.length} page(s)` : ''} à la mosaïque
                </Button>
              </div>

              {/* Mosaïque - Vue grille */}
              {mosaicSlots.length > 0 && (
                <div>
                  <h3 className="font-semibold mb-3">Aperçu de la mosaïque ({mosaicSlots.length} pages)</h3>
                  <div className="border rounded-lg p-4 bg-slate-900">
                    <div className="grid gap-1" style={{
                      gridTemplateColumns: `repeat(${Math.ceil(Math.sqrt(mosaicSlots.length))}, 1fr)`
                    }}>
                      {mosaicSlots.map((slot, index) => (
                        <div key={slot.id} className="relative group">
                          <img 
                            src={slot.page.imageUrl} 
                            alt="" 
                            className="w-full h-auto border border-white/20 rounded"
                          />
                          <div className="absolute top-1 left-1 bg-black/70 text-white text-xs px-2 py-1 rounded">
                            P{slot.page.pageNumber}
                          </div>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity bg-red-600 hover:bg-red-700 text-white h-6 w-6 p-0"
                            onClick={() => handleRemoveSlot(slot.id)}
                          >
                            <X className="w-3 h-3" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div className="mt-3 bg-purple-50 border border-purple-200 rounded-lg p-3 text-sm">
                    <p className="font-medium text-purple-900">
                      📐 Disposition : {Math.ceil(Math.sqrt(mosaicSlots.length))} colonnes × {Math.ceil(mosaicSlots.length / Math.ceil(Math.sqrt(mosaicSlots.length)))} lignes
                    </p>
                    <p className="text-xs text-purple-700 mt-1">
                      Les pages seront assemblées dans cet ordre pour former la grille complète
                    </p>
                  </div>
                </div>
              )}
            </>
          )}

          {/* Processing */}
          {isProcessing && (
            <div className="flex items-center gap-3 bg-blue-50 border border-blue-200 rounded-lg p-4">
              <Loader2 className="w-5 h-5 animate-spin text-blue-600" />
              <div>
                <p className="font-medium text-blue-900">Extraction en cours...</p>
                <p className="text-sm text-blue-700">Traitement des pages du PDF...</p>
              </div>
            </div>
          )}
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={onClose}>
            Annuler
          </Button>
          {mosaicSlots.length > 0 && (
            <Button
              onClick={handleFuseMosaic}
              className="bg-purple-600 hover:bg-purple-700"
            >
              <Grid3x3 className="w-4 h-4 mr-2" />
              Fusionner en une seule grille
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}