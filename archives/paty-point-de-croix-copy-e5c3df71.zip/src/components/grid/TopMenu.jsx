import React, { useState, useRef, useEffect, useMemo } from 'react';
import { 
  Download, 
  User, 
  Save, 
  Upload,
  HelpCircle,
  Menu,
  FolderOpen,
  ShoppingBag,
  Settings,
  Pencil,
  Eye,
  Undo,
  Redo,
  MessageCircle,
  BarChart3
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '../../utils';
import { toast } from 'sonner';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu';
import PatyBeePanel from '../patybee/PatyBeePanel';
import { useSettings } from '../settings/SettingsContext';
import ProjectsSubmenu from './ProjectsSubmenu';
import ShopModal from './ShopModal';
import BroodwayAboutModal from './BroodwayAboutModal';
import ProjectsScreen from './ProjectsScreen';
import ProfileModal from './ProfileModal';
import PencilFloatingPalette from './PencilFloatingPalette';
import DisplayFloatingPalette from './DisplayFloatingPalette';

// Logo B×W image
function BroodwayLogo() {
  return (
    <img 
      src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6924cd1cd3887ccee5c3df71/216b87773_Capturedcran2025-11-28221419.png"
      alt="B×W"
      style={{ height: '16px', width: 'auto' }}
    />
  );
}

export default function TopMenu({
  currentPageName,
  onNewGrid,
  onSave,
  onProjects,
  onImport,
  onCloseProject,
  onOpenAdvancedStyles,
  onExport,
  hasUnsavedChanges = false,
  hasCurrentProject = false,
  pattern = null,
  onOpenDashboard,
  onOpenWelcomeIntro,
  onUndo,
  onRedo,
  canUndo = false,
  canRedo = false,
  onToggleEdit,
  onTogglePreview,
  isEditMode = true,
  showPreview = true,
  // Props pour les dropdowns
  currentTool,
  onToolSelect,
  showGrid,
  onToggleGrid,
  showSymbols,
  onToggleSymbols,
  contrastMode,
  onContrastModeChange,
  symbolSizeMode,
  onSymbolSizeModeChange,
  antiFatigueMode,
  onAntiFatigueModeChange,
  focusColorMode,
  onFocusColorModeChange,
  highlightActiveMode,
  onHighlightActiveModeChange,
  nightMode,
  onNightModeChange,
  autoCountMode,
  onAutoCountModeChange,
  onNavigateToZone,
  activeFilter,
  onFilterByStitchType,
  onFilterByColor,
  onFilterBySymbol,
  onResetFilters,
  isolationMode,
  onToggleIsolationMode,
  showUnstitchedZones,
  onToggleUnstitchedZones,
  showPotentialErrors,
  onTogglePotentialErrors,
  errorSensitivity,
  onErrorSensitivityChange,
  showMissingPoints,
  onToggleMissingPoints,
  unstitchedCount,
  potentialErrorsCount,
  missingPointsCount,
  currentPencilSubTool,
  onPencilSubToolSelect,
  currentEraserSubTool,
  onEraserSubToolSelect,
  currentSelectionSubTool,
  onSelectionSubToolSelect,
  statsMode,
  onStatsModeChange,
}) {
  const navigate = useNavigate();
  const { settings, saveSettings } = useSettings();
  const [isPatyBeeOpen, setIsPatyBeeOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [projectsOpen, setProjectsOpen] = useState(false);
  const [projectsScreenOpen, setProjectsScreenOpen] = useState(false);
  const [shopOpen, setShopOpen] = useState(false);
  const [aboutOpen, setAboutOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [pencilPaletteOpen, setPencilPaletteOpen] = useState(false);
  const [displayPaletteOpen, setDisplayPaletteOpen] = useState(false);
  const pencilButtonRef = useRef(null);
  const displayButtonRef = useRef(null);

  // Fermer les palettes au clic extérieur
  useEffect(() => {
    const handleClickOutside = (e) => {
      // Vérifier si le clic est en dehors des deux palettes
      const isOutsidePencil = pencilButtonRef.current && !pencilButtonRef.current.contains(e.target);
      const isOutsideDisplay = displayButtonRef.current && !displayButtonRef.current.contains(e.target);
      
      if (pencilPaletteOpen && isOutsidePencil) {
        setPencilPaletteOpen(false);
      }
      if (displayPaletteOpen && isOutsideDisplay) {
        setDisplayPaletteOpen(false);
      }
    };

    const handleEscape = (e) => {
      if (e.key === 'Escape') {
        setPencilPaletteOpen(false);
        setDisplayPaletteOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('keydown', handleEscape);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleEscape);
    };
  }, [pencilPaletteOpen, displayPaletteOpen]);

  // Handlers pour toggle propre des palettes
  const handlePencilClick = () => {
    if (pencilPaletteOpen) {
      setPencilPaletteOpen(false);
    } else {
      setPencilPaletteOpen(true);
      setDisplayPaletteOpen(false);
    }
  };

  const handleDisplayClick = () => {
    if (displayPaletteOpen) {
      setDisplayPaletteOpen(false);
    } else {
      setDisplayPaletteOpen(true);
      setPencilPaletteOpen(false);
    }
  };
  
  const isGridEditorPage = currentPageName === 'GridEditor';

  // Gérer le toggle de PatyBee depuis la toolbar
  useEffect(() => {
    const handleToggle = () => {
      setIsPatyBeeOpen(prev => !prev);
    };
    
    window.addEventListener('togglePatyBee', handleToggle);
    return () => window.removeEventListener('togglePatyBee', handleToggle);
  }, []);
  
  // Vérifier si l'utilisateur est admin
  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: async () => {
      try {
        return await base44.auth.me();
      } catch {
        return null;
      }
    },
  });
  
  const isAdmin = user?.email === 'matthieu.lecointre@gmail.com';

  // Calculer la progression globale
  const globalProgress = React.useMemo(() => {
    if (!pattern?.symbolGrid) return { percent: 0, done: 0, total: 0 };

    const allCells = pattern.symbolGrid.flat().filter(cell => cell);
    const total = allCells.length;
    const done = allCells.filter(cell => cell.done).length;
    const percent = total > 0 ? Math.round((done / total) * 100) : 0;

    return { percent, done, total };
  }, [pattern]);

  const handleNewGridClick = () => {
    // Appeler directement la fonction onNewGrid qui gère le carrousel
    if (isGridEditorPage && onNewGrid) {
      onNewGrid();
    } else {
      navigate(createPageUrl('GridEditor'));
    }
  };


  
  const handleSelectProject = (project) => {
    // Émettre un événement pour charger le projet
    const event = new CustomEvent('loadProject', { detail: project });
    window.dispatchEvent(event);
  };

  return (
    <TooltipProvider>
      <PatyBeePanel isOpen={isPatyBeeOpen} onClose={() => setIsPatyBeeOpen(false)} />
      <ProjectsSubmenu 
        open={projectsOpen} 
        onOpenChange={setProjectsOpen}
        onSelectProject={handleSelectProject}
        onClose={() => setProjectsOpen(false)}
      />
      <ShopModal
                open={shopOpen}
                onClose={() => setShopOpen(false)}
              />
              <BroodwayAboutModal
                open={aboutOpen}
                onClose={() => setAboutOpen(false)}
                onImport={onImport}
              />

              {/* Écran Profil */}
              {profileOpen && (
                <ProfileModal onClose={() => setProfileOpen(false)} />
              )}

              {/* Écran Mes Projets (plein écran) */}
              {projectsScreenOpen && (
                <ProjectsScreen
                  onClose={() => setProjectsScreenOpen(false)}
                  onOpenProject={(projectId) => {
                    localStorage.setItem('loadProjectId', projectId);
                    window.location.reload();
                  }}
                  onNewProject={() => {
                    setProjectsScreenOpen(false);
                    onImport?.();
                  }}
                />
              )}

              <div className="bg-black border-b border-black fixed top-0 left-0 right-0 z-50" style={{ height: '70px' }}>
              <div className="flex items-center justify-between h-full px-4 md:px-8">
              {/* Logo BROOD★WAY à gauche */}
              <div className="flex items-center">
              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => navigate(createPageUrl('GridEditor'))}
                    className="transition-transform hover:scale-105 cursor-pointer"
                    aria-label="Retour à la grille"
                  >
                    <BroodwayLogo />
                  </button>
                </TooltipTrigger>
                <TooltipContent><p>Retour à la grille</p></TooltipContent>
              </Tooltip>
              </div>

              {/* Boutons outils au centre */}
              <div className="flex items-center gap-2">
              {/* Bouton Modifier (Crayon) avec palette flottante */}
              <div className="relative" ref={pencilButtonRef}>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <button
                      onClick={handlePencilClick}
                      className="w-12 h-12 rounded-lg flex items-center justify-center transition-all"
                      style={{
                        backgroundColor: pencilPaletteOpen || (currentTool === 'cross' || currentTool === 'pencil' || currentTool === 'erase' || currentTool === 'selection-ia') ? 'rgba(255,255,255,0.15)' : 'transparent',
                        border: 'none',
                      }}
                      onMouseEnter={(e) => e.currentTarget.style.boxShadow = '0 0 0 1px rgba(255,255,255,0.2)'}
                      onMouseLeave={(e) => e.currentTarget.style.boxShadow = 'none'}
                    >
                      <Pencil className="w-5 h-5 text-white" />
                    </button>
                  </TooltipTrigger>
                  <TooltipContent><p>Outils de dessin</p></TooltipContent>
                </Tooltip>
                
                <PencilFloatingPalette
                  isOpen={pencilPaletteOpen}
                  toolSelected={currentTool}
                  selectionActive={false}
                  hasGrid={hasCurrentProject}
                  symbolSize={symbolSizeMode || 'medium'}
                  onToolSelect={(toolId) => {
                    const toolMap = {
                      'select': 'selection-ia',
                      'pipette': 'symbol-picker',
                      'fill': 'fill',
                      'eraser': 'erase',
                      'replaceColor': 'replace',
                      'draw': 'cross',
                      'pan': 'pan',
                      'rotate': 'rotate',
                      'flipH': 'flip-h',
                      'flipV': 'flip-v',
                      'delete': 'delete-zone',
                    };
                    onToolSelect?.(toolMap[toolId] || toolId);
                  }}
                  onSymbolSizeChange={onSymbolSizeModeChange}
                  onRotateSelection={() => {}}
                  onFlipSelection={() => {}}
                  onClearSelection={() => {}}
                  onClose={() => setPencilPaletteOpen(false)}
                />
              </div>

              {/* Bouton Aperçu (Œil) avec palette flottante */}
              <div className="relative" ref={displayButtonRef}>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <button
                      onClick={handleDisplayClick}
                      className="w-12 h-12 rounded-lg flex items-center justify-center transition-all"
                      style={{
                        backgroundColor: displayPaletteOpen || showPreview ? 'rgba(255,255,255,0.15)' : 'transparent',
                        border: 'none',
                      }}
                      onMouseEnter={(e) => e.currentTarget.style.boxShadow = '0 0 0 1px rgba(255,255,255,0.2)'}
                      onMouseLeave={(e) => e.currentTarget.style.boxShadow = 'none'}
                    >
                      <Eye className="w-5 h-5 text-white" />
                    </button>
                  </TooltipTrigger>
                  <TooltipContent><p>Options d'affichage</p></TooltipContent>
                </Tooltip>
                
                <DisplayFloatingPalette
                  isOpen={displayPaletteOpen}
                  hasGrid={hasCurrentProject}
                  showGrid={showGrid}
                  showSymbols={showSymbols}
                  showColors={showPreview}
                  showBackgroundImg={showPreview}
                  showOverlayOriginal={false}
                  themeDark={nightMode}
                  symbolSize={symbolSizeMode || 'medium'}
                  autoZoomEnabled={false}
                  onToggleGrid={onToggleGrid}
                  onToggleSymbols={onToggleSymbols}
                  onToggleColors={onTogglePreview}
                  onToggleBackgroundImg={onTogglePreview}
                  onToggleOverlayOriginal={() => {}}
                  onToggleTheme={onNightModeChange}
                  onAutoZoom={() => {
                    const event = new CustomEvent('zoomAuto');
                    window.dispatchEvent(event);
                  }}
                  onCenterView={() => {
                    const event = new CustomEvent('centerView');
                    window.dispatchEvent(event);
                  }}
                  onAddFavorite={() => {
                    const event = new CustomEvent('addFavorite');
                    window.dispatchEvent(event);
                  }}
                  onSymbolSizeChange={onSymbolSizeModeChange}
                  onClose={() => setDisplayPaletteOpen(false)}
                />
              </div>

              {/* Bouton Undo */}
              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={onUndo}
                    disabled={!canUndo}
                    className="w-12 h-12 rounded-lg flex items-center justify-center transition-all"
                    style={{
                      backgroundColor: 'transparent',
                      border: 'none',
                      opacity: canUndo ? 1 : 0.4,
                      cursor: canUndo ? 'pointer' : 'not-allowed',
                    }}
                    onMouseEnter={(e) => canUndo && (e.currentTarget.style.boxShadow = '0 0 0 1px rgba(255,255,255,0.2)')}
                    onMouseLeave={(e) => e.currentTarget.style.boxShadow = 'none'}
                  >
                    <Undo className="w-5 h-5 text-white" />
                  </button>
                </TooltipTrigger>
                <TooltipContent><p>Annuler (Ctrl+Z)</p></TooltipContent>
              </Tooltip>

              {/* Bouton Redo */}
              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={onRedo}
                    disabled={!canRedo}
                    className="w-12 h-12 rounded-lg flex items-center justify-center transition-all"
                    style={{
                      backgroundColor: 'transparent',
                      border: 'none',
                      opacity: canRedo ? 1 : 0.4,
                      cursor: canRedo ? 'pointer' : 'not-allowed',
                    }}
                    onMouseEnter={(e) => canRedo && (e.currentTarget.style.boxShadow = '0 0 0 1px rgba(255,255,255,0.2)')}
                    onMouseLeave={(e) => e.currentTarget.style.boxShadow = 'none'}
                  >
                    <Redo className="w-5 h-5 text-white" />
                  </button>
                </TooltipTrigger>
                <TooltipContent><p>Rétablir (Ctrl+Shift+Z)</p></TooltipContent>
              </Tooltip>

              {/* Bouton Stats */}
              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => onStatsModeChange?.(!statsMode)}
                    className="w-12 h-12 rounded-lg flex items-center justify-center transition-all"
                    style={{
                      backgroundColor: statsMode ? 'rgba(255,255,255,0.15)' : 'transparent',
                      border: 'none',
                    }}
                    onMouseEnter={(e) => e.currentTarget.style.boxShadow = '0 0 0 1px rgba(255,255,255,0.2)'}
                    onMouseLeave={(e) => e.currentTarget.style.boxShadow = 'none'}
                  >
                    <BarChart3 className="w-5 h-5 text-white" />
                  </button>
                </TooltipTrigger>
                <TooltipContent><p>Statistiques avancées</p></TooltipContent>
              </Tooltip>

              {/* Bouton IA - icône conversation blanche */}
              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => {
                      const event = new CustomEvent('togglePatyBee');
                      window.dispatchEvent(event);
                    }}
                    className="w-10 h-10 flex items-center justify-center transition-all"
                    style={{
                      backgroundColor: 'transparent',
                      border: 'none',
                    }}
                    onMouseEnter={(e) => e.currentTarget.style.opacity = '0.7'}
                    onMouseLeave={(e) => e.currentTarget.style.opacity = '1'}
                  >
                    <MessageCircle className="w-6 h-6 text-white" />
                  </button>
                </TooltipTrigger>
                <TooltipContent><p>Assistant IA PatyBee</p></TooltipContent>
              </Tooltip>
              </div>

              {/* Menu burger à droite */}
            <DropdownMenu open={menuOpen} onOpenChange={setMenuOpen}>
              <DropdownMenuTrigger asChild>
                <button
                  className="w-10 h-10 rounded-lg flex items-center justify-center transition-all"
                  style={{
                    backgroundColor: menuOpen ? '#FFC94A' : 'rgba(255,255,255,0.1)',
                    color: menuOpen ? '#111' : '#fff',
                  }}
                >
                  <Menu className="w-5 h-5" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent 
                  align="end" 
                  className="w-52 bg-[#1a1a1a] border-[#333] rounded-xl p-1 z-[200]"
                >
                  {/* MES PROJETS - Action principale du burger */}
                  <DropdownMenuItem
                    onClick={() => {
                      setProjectsScreenOpen(true);
                      setMenuOpen(false);
                    }}
                    className="px-3 py-2.5 rounded-lg cursor-pointer hover:bg-white/10 text-white font-medium"
                  >
                    <FolderOpen className="w-4 h-4 mr-3 text-[#FFC94A]" />
                    Mes projets
                  </DropdownMenuItem>
                  <DropdownMenuSeparator className="bg-[#333] my-1" />
                  <DropdownMenuItem
                    onClick={() => {
                      onImport?.();
                      setMenuOpen(false);
                    }}
                    className="px-3 py-2.5 rounded-lg cursor-pointer hover:bg-white/10 text-white"
                  >
                    <Upload className="w-4 h-4 mr-3 text-[#10B981]" />
                    Importer
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onClick={() => {
                      onSave ? onSave() : toast.info('Ouvrez un projet pour sauvegarder');
                      setMenuOpen(false);
                    }}
                    className="px-3 py-2.5 rounded-lg cursor-pointer hover:bg-white/10 text-white"
                  >
                    <Save className="w-4 h-4 mr-3 text-[#3B82F6]" />
                    Sauvegarder
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onClick={() => {
                      onExport ? onExport() : toast.info('Ouvrez un projet pour exporter');
                      setMenuOpen(false);
                    }}
                    className="px-3 py-2.5 rounded-lg cursor-pointer hover:bg-white/10 text-white"
                  >
                    <Download className="w-4 h-4 mr-3 text-[#8B5CF6]" />
                    Exporter
                  </DropdownMenuItem>
                  <DropdownMenuSeparator className="bg-[#333] my-1" />
                  <DropdownMenuItem
                    onClick={() => {
                      setShopOpen(true);
                      setMenuOpen(false);
                    }}
                    className="px-3 py-2.5 rounded-lg cursor-pointer hover:bg-white/10 text-white"
                  >
                    <ShoppingBag className="w-4 h-4 mr-3 text-[#EC4899]" />
                    Boutique
                  </DropdownMenuItem>
                  <DropdownMenuSeparator className="bg-[#333] my-1" />
                  <DropdownMenuItem
                    onClick={() => {
                      const event = new CustomEvent('openTutorial');
                      window.dispatchEvent(event);
                      setMenuOpen(false);
                    }}
                    className="px-3 py-2.5 rounded-lg cursor-pointer hover:bg-white/10 text-white"
                  >
                    <HelpCircle className="w-4 h-4 mr-3 text-[#06B6D4]" />
                    Aide
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onClick={() => {
                      setProfileOpen(true);
                      setMenuOpen(false);
                    }}
                    className="px-3 py-2.5 rounded-lg cursor-pointer hover:bg-white/10 text-white"
                  >
                    <User className="w-4 h-4 mr-3 text-[#FFC94A]" />
                    Profil
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onClick={() => {
                      onOpenDashboard?.();
                      setMenuOpen(false);
                    }}
                    className="px-3 py-2.5 rounded-lg cursor-pointer hover:bg-white/10 text-white"
                  >
                    <Settings className="w-4 h-4 mr-3 text-[#9CA3AF]" />
                    Réglages
                  </DropdownMenuItem>

                </DropdownMenuContent>
            </DropdownMenu>

            </div>
            </div>

      </TooltipProvider>
      );
      }