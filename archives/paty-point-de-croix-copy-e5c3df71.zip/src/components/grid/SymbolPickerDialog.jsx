import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Search } from 'lucide-react';
import { SYMBOL_CATEGORIES, searchSymbols } from './SymbolLibrary';

export default function SymbolPickerDialog({ open, onClose, onSelectSymbol }) {
  const [searchQuery, setSearchQuery] = useState('');

  const handleSelect = (symbol) => {
    onSelectSymbol(symbol);
  };

  const filteredResults = searchQuery ? searchSymbols(searchQuery) : [];

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl max-h-[80vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle>Choisir un symbole</DialogTitle>
        </DialogHeader>

        {/* Recherche */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input
            placeholder="Rechercher un symbole..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
          />
        </div>

        {/* Résultats */}
        <div className="flex-1 overflow-y-auto">
          {searchQuery ? (
            // Résultats de recherche
            <div className="space-y-4">
              {filteredResults.length > 0 ? (
                filteredResults.map(result => (
                  <div key={result.categoryName} className="space-y-2">
                    <h3 className="text-sm font-semibold text-slate-700">
                      {result.categoryName}
                    </h3>
                    <div className="grid grid-cols-10 gap-2">
                      {result.symbols.map(symbol => (
                        <Button
                          key={symbol.id}
                          variant="outline"
                          className="h-12 text-xl font-bold hover:bg-blue-50 hover:border-blue-500"
                          onClick={() => handleSelect(symbol)}
                          title={symbol.label}
                        >
                          {symbol.char}
                        </Button>
                      ))}
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-center text-slate-500 py-8">
                  Aucun symbole trouvé
                </p>
              )}
            </div>
          ) : (
            // Onglets par catégorie
            <Tabs defaultValue={SYMBOL_CATEGORIES[0].id} className="w-full">
              <TabsList className="w-full flex-wrap h-auto">
                {SYMBOL_CATEGORIES.map(cat => (
                  <TabsTrigger key={cat.id} value={cat.id} className="text-xs">
                    {cat.name}
                  </TabsTrigger>
                ))}
              </TabsList>
              
              {SYMBOL_CATEGORIES.map(cat => (
                <TabsContent key={cat.id} value={cat.id} className="mt-4">
                  <p className="text-xs text-slate-600 mb-3">{cat.description}</p>
                  <div className="grid grid-cols-10 gap-2">
                    {cat.symbols.map(symbol => (
                      <Button
                        key={symbol.id}
                        variant="outline"
                        className="h-12 text-xl font-bold hover:bg-blue-50 hover:border-blue-500"
                        onClick={() => handleSelect(symbol)}
                        title={symbol.label}
                      >
                        {symbol.char}
                      </Button>
                    ))}
                  </div>
                </TabsContent>
              ))}
            </Tabs>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}