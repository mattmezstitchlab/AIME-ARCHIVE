/**
 * Export PDF avec Types de Points et Techniques Avancées
 * Module d'export détaillé pour PatyBee
 */

export async function exporterPDFAvecTypesDePoints(gridConfig, pattern, typesActifs, calques) {
  const { jsPDF } = await import('jspdf');
  
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4'
  });

  // Page 1 : Vue globale
  ajouterPage_VisuelGlobal(doc, gridConfig, pattern, typesActifs);
  
  // Page 2 : Tableau des couleurs et types de points
  doc.addPage();
  ajouterPage_LegendeCouleurs(doc, pattern, typesActifs);
  
  // Page 3 : Liste des types de points
  doc.addPage();
  ajouterPage_TypesDePoints(doc, typesActifs);
  
  // Page 4 : Instructions techniques
  doc.addPage();
  ajouterPage_InstructionsTechniques(doc, typesActifs);

  // Télécharger
  doc.save(`${gridConfig?.name || 'grille'}_patybee_complet.pdf`);
}

// ========== PAGE 1 : VISUEL GLOBAL ==========

function ajouterPage_VisuelGlobal(doc, gridConfig, pattern, typesActifs) {
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();

  // Titre
  doc.setFontSize(20);
  doc.setFont('helvetica', 'bold');
  doc.text('Grille de point de croix générée avec PatyBee', pageWidth / 2, 15, { align: 'center' });

  // Sous-titre
  doc.setFontSize(12);
  doc.setFont('helvetica', 'normal');
  doc.text('Vue globale de la grille, avec tous les points et couleurs.', pageWidth / 2, 22, { align: 'center' });

  // Info projet
  doc.setFontSize(10);
  doc.text(`Projet : ${gridConfig?.name || 'Sans nom'}`, 15, 30);
  doc.text(`Taille : ${gridConfig?.nb_colonnes || 0} × ${gridConfig?.nb_lignes || 0} cases`, 15, 36);
  
  if (pattern) {
    doc.text(`Motif importé : ${pattern.width} × ${pattern.height}`, 15, 42);
    doc.text(`Couleurs DMC : ${pattern.colorPalette?.length || 0}`, 15, 48);
  }

  // Image de la grille (simplifiée)
  const canvas = document.createElement('canvas');
  const imgSize = 140; // mm
  canvas.width = 1200;
  canvas.height = 1200;
  const ctx = canvas.getContext('2d');

  // Fond blanc
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Grille
  ctx.strokeStyle = '#cbd5e1';
  ctx.lineWidth = 1;
  const cols = gridConfig?.nb_colonnes || 50;
  const rows = gridConfig?.nb_lignes || 50;
  const cellSize = canvas.width / Math.max(cols, rows);

  for (let i = 0; i <= cols; i += 10) {
    ctx.beginPath();
    ctx.moveTo(i * cellSize, 0);
    ctx.lineTo(i * cellSize, canvas.height);
    ctx.stroke();
  }
  for (let i = 0; i <= rows; i += 10) {
    ctx.beginPath();
    ctx.moveTo(0, i * cellSize);
    ctx.lineTo(canvas.width, i * cellSize);
    ctx.stroke();
  }

  // Symboles du pattern
  if (pattern?.symbolGrid) {
    ctx.font = `${cellSize * 0.6}px Arial`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    pattern.symbolGrid.forEach((row, y) => {
      row.forEach((cell, x) => {
        if (cell) {
          const color = pattern.colorPalette?.find(c => c.id === cell.colorId);
          if (color) {
            ctx.fillStyle = color.hex;
            const px = x * cellSize + cellSize / 2;
            const py = y * cellSize + cellSize / 2;
            ctx.fillText(color.assignedSymbolChar || '●', px, py);
          }
        }
      });
    });
  }

  // Ajouter l'image
  const imgData = canvas.toDataURL('image/jpeg', 0.9);
  doc.addImage(imgData, 'JPEG', (pageWidth - imgSize) / 2, 55, imgSize, imgSize);

  // Résumé des types de points
  const resume = construireResumeTypesPoints(typesActifs);
  doc.setFontSize(9);
  doc.text(resume, pageWidth / 2, pageHeight - 15, { align: 'center', maxWidth: pageWidth - 30 });
}

function construireResumeTypesPoints(typesActifs) {
  const types = [];
  
  if (typesActifs.full) types.push('Point de croix');
  if (typesActifs.half) types.push('Demi-points');
  if (typesActifs.quarter) types.push('Points fractionnés');
  if (typesActifs.backstitch) types.push('Backstitch');
  if (typesActifs.frenchknot) types.push('Nœuds français');
  if (typesActifs.bead) types.push('Perles');
  if (typesActifs.metallic) types.push('Fils métalliques');
  if (typesActifs.longstitch) types.push('Points longs');
  if (typesActifs.straightstitch) types.push('Points droits');
  if (typesActifs.satin) types.push('Satin');
  if (typesActifs.bullion) types.push('Bullion');
  if (typesActifs.couching) types.push('Couching');

  return `Types de points utilisés : ${types.join(' · ')}`;
}

// ========== PAGE 2 : TABLEAU DES COULEURS ==========

function ajouterPage_LegendeCouleurs(doc, pattern, typesActifs) {
  const pageWidth = doc.internal.pageSize.getWidth();
  
  // Titre
  doc.setFontSize(18);
  doc.setFont('helvetica', 'bold');
  doc.text('Légende des couleurs et types de points', pageWidth / 2, 15, { align: 'center' });

  if (!pattern?.colorPalette) {
    doc.setFontSize(10);
    doc.text('Aucune palette de couleurs disponible', 15, 30);
    return;
  }

  // En-tête du tableau
  let y = 30;
  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.text('Symbole', 15, y);
  doc.text('DMC', 35, y);
  doc.text('Total', 70, y);
  doc.text('Types de points utilisés', 95, y);
  
  doc.setLineWidth(0.5);
  doc.line(15, y + 2, pageWidth - 15, y + 2);

  y += 8;
  doc.setFont('helvetica', 'normal');

  // Lignes du tableau
  pattern.colorPalette.forEach((color, index) => {
    if (y > 270) {
      doc.addPage();
      y = 20;
    }

    const stats = color.stitchTypeStats || {};
    
    // Symbole
    doc.setFontSize(12);
    doc.text(color.assignedSymbolChar || '●', 15, y);
    
    // Code DMC
    doc.setFontSize(9);
    doc.text(color.code || color.name || 'N/A', 35, y);
    
    // Total
    doc.text(String(stats.total || color.totalCount || 0), 70, y);
    
    // Types de points
    const typesTexte = construireTypesTexteParCouleur(stats);
    doc.setFontSize(8);
    doc.text(typesTexte, 95, y, { maxWidth: pageWidth - 110 });

    y += 7;
    
    // Ligne séparatrice tous les 5
    if ((index + 1) % 5 === 0) {
      doc.setDrawColor(220, 220, 220);
      doc.line(15, y, pageWidth - 15, y);
      y += 2;
    }
  });
}

function construireTypesTexteParCouleur(stats) {
  const parts = [];
  
  if (stats.full > 0) parts.push(`${stats.full} croix`);
  if (stats.half > 0) parts.push(`${stats.half} demi`);
  if (stats.quarter > 0) parts.push(`${stats.quarter} 1/4`);
  if (stats.backstitch > 0) parts.push(`${stats.backstitch} back`);
  if (stats.frenchknot > 0) parts.push(`${stats.frenchknot} nœud`);
  if (stats.bead > 0) parts.push(`${stats.bead} perle`);
  if (stats.metallic > 0) parts.push(`${stats.metallic} métal`);
  if (stats.longstitch > 0) parts.push(`${stats.longstitch} long`);
  if (stats.straightstitch > 0) parts.push(`${stats.straightstitch} droit`);
  if (stats.satin > 0) parts.push(`${stats.satin} satin`);
  if (stats.bullion > 0) parts.push(`${stats.bullion} bullion`);
  if (stats.couching > 0) parts.push(`${stats.couching} couch`);

  return parts.length > 0 ? parts.join(' | ') : 'Aucun point';
}

// ========== PAGE 3 : LISTE DES TYPES ==========

function ajouterPage_TypesDePoints(doc, typesActifs) {
  const pageWidth = doc.internal.pageSize.getWidth();
  
  // Titre
  doc.setFontSize(18);
  doc.setFont('helvetica', 'bold');
  doc.text('Types de points présents dans cette grille', pageWidth / 2, 15, { align: 'center' });

  // Intro
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  const intro = 'Cette grille utilise plusieurs techniques de broderie. Voici la liste des points inclus, pour t\'aider à préparer ton matériel et ton temps.';
  doc.text(intro, 15, 25, { maxWidth: pageWidth - 30 });

  let y = 40;
  doc.setFontSize(10);

  const pointsDescriptions = [
    { key: 'full', label: 'Point de croix complet', desc: 'Base du modèle' },
    { key: 'half', label: 'Demi-point', desc: 'Adoucir les dégradés et fonds délicats' },
    { key: 'quarter', label: 'Points fractionnés (¼ / ¾)', desc: 'Affiner les contours et courbes' },
    { key: 'backstitch', label: 'Backstitch', desc: 'Redessiner les lignes et contours' },
    { key: 'frenchknot', label: 'Nœuds français', desc: 'Points de lumière ou centres de fleurs' },
    { key: 'bead', label: 'Perles', desc: 'Ajout de relief et brillance' },
    { key: 'metallic', label: 'Fils métalliques', desc: 'Dorures, argent, effets précieux' },
    { key: 'longstitch', label: 'Points longs', desc: 'Grandes zones uniformes' },
    { key: 'straightstitch', label: 'Points droits', desc: 'Brins d\'herbe, petits traits' },
    { key: 'satin', label: 'Point de satin', desc: 'Surfaces lisses et brillantes' },
    { key: 'bullion', label: 'Bullion knot', desc: 'Effets 3D, boucles, texture' },
    { key: 'couching', label: 'Couching', desc: 'Fils posés à la surface' }
  ];

  pointsDescriptions.forEach(point => {
    if (typesActifs[point.key]) {
      if (y > 270) {
        doc.addPage();
        y = 20;
      }

      doc.setFont('helvetica', 'bold');
      doc.text(`• ${point.label}`, 15, y);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(9);
      doc.text(`  ${point.desc}`, 15, y + 5);
      
      y += 12;
    }
  });
}

// ========== PAGE 4 : INSTRUCTIONS TECHNIQUES ==========

function ajouterPage_InstructionsTechniques(doc, typesActifs) {
  const pageWidth = doc.internal.pageSize.getWidth();
  
  // Titre
  doc.setFontSize(18);
  doc.setFont('helvetica', 'bold');
  doc.text('Guide rapide des techniques de broderie', pageWidth / 2, 15, { align: 'center' });

  // Intro
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  const intro = 'Voici un mémo rapide pour chaque technique utilisée. Tu peux broder uniquement avec les points de croix si tu préfères, mais ces points spéciaux donnent davantage de relief et de vie au modèle.';
  doc.text(intro, 15, 25, { maxWidth: pageWidth - 30 });

  let y = 38;

  const instructions = [
    { 
      key: 'full', 
      titre: 'Point de croix complet',
      texte: 'Point de base : une croix entière sur une case. Toujours garder la même direction pour le brin supérieur sur toute la grille pour un rendu régulier.'
    },
    { 
      key: 'half', 
      titre: 'Demi-point',
      texte: 'Un seul passage en diagonale. Utilisé pour les fonds, les dégradés et les zones plus douces. Il consomme moins de fil et brode plus vite.'
    },
    { 
      key: 'quarter', 
      titre: 'Points fractionnés (¼ et ¾)',
      texte: 'Ces points permettent des courbes plus précises, surtout pour les visages, les lettres ou les endroits où un détail tombe entre deux cases.'
    },
    { 
      key: 'backstitch', 
      titre: 'Backstitch (point arrière)',
      texte: 'Brode les contours à la fin, par-dessus les croix. Utilise un fil plus fin si tu veux un rendu délicat. C\'est ce point qui fait souvent "sortir" le dessin.'
    },
    { 
      key: 'frenchknot', 
      titre: 'Nœuds français',
      texte: 'Enroule le fil autour de l\'aiguille 1 ou 2 fois, puis pique à côté du trou de sortie. Garde une tension régulière et ne tire pas trop fort pour éviter d\'écraser le nœud.'
    },
    { 
      key: 'bead', 
      titre: 'Perles',
      texte: 'À broder de préférence à la fin. Utilise un fil solide et fais un double passage si le modèle sera beaucoup manipulé. Fixe bien la perle pour qu\'elle reste orientée correctement.'
    },
    { 
      key: 'metallic', 
      titre: 'Fils métalliques',
      texte: 'Ces fils sont plus fragiles et peuvent s\'effilocher. Brode avec des aiguillées plus courtes, et si possible avec une aiguille à chas plus large. Tu peux aussi les utiliser en "couching" : posés et fixés par un fil normal.'
    },
    { 
      key: 'longstitch', 
      titre: 'Points longs',
      texte: 'Idéal pour couvrir une surface rapidement ou simuler des mèches de cheveux. Évite les zones trop grandes sans point d\'ancrage pour ne pas accrocher le fil.'
    },
    { 
      key: 'straightstitch', 
      titre: 'Points droits',
      texte: 'Petits traits simples pour ajouter des détails fins (herbes, moustaches, rayons). À broder en dernier pour ne pas les accrocher pendant le travail.'
    },
    { 
      key: 'satin', 
      titre: 'Point de satin',
      texte: 'Plusieurs passages parallèles pour remplir une petite zone. Pour un beau rendu, garde les brins bien serrés et réguliers, et évite les surfaces trop grandes (risque d\'accrochage).'
    },
    { 
      key: 'bullion', 
      titre: 'Bullion knot',
      texte: 'Semblable à un nœud français allongé, avec plusieurs enroulements. Très décoratif, mais demande un peu de pratique. Parfait pour fleurs, cheveux, ou effet 3D.'
    },
    { 
      key: 'couching', 
      titre: 'Couching (fils posés)',
      texte: 'On pose un fil à la surface du tissu, puis on le fixe par de petits points perpendiculaires avec un autre fil. Idéal pour des grandes lignes, motifs géométriques ou fils métalliques.'
    }
  ];

  instructions.forEach(instr => {
    if (typesActifs[instr.key]) {
      if (y > 260) {
        doc.addPage();
        y = 20;
      }

      // Titre de la technique
      doc.setFontSize(11);
      doc.setFont('helvetica', 'bold');
      doc.text(instr.titre, 15, y);
      
      // Texte explicatif
      y += 5;
      doc.setFontSize(9);
      doc.setFont('helvetica', 'normal');
      const lines = doc.splitTextToSize(instr.texte, pageWidth - 30);
      doc.text(lines, 15, y);
      
      y += lines.length * 4 + 6;
    }
  });
}