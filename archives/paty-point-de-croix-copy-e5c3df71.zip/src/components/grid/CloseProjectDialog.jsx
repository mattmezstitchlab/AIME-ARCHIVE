import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { AlertTriangle } from 'lucide-react';

export default function CloseProjectDialog({ 
  open, 
  onClose, 
  onSaveAndClose, 
  onCloseWithoutSave,
  hasUnsavedChanges 
}) {
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-amber-500" />
            Fermer le projet
          </DialogTitle>
          <DialogDescription>
            {hasUnsavedChanges 
              ? "Voulez-vous sauvegarder les modifications avant de fermer ce projet ?"
              : "Êtes-vous sûr de vouloir fermer ce projet ?"}
          </DialogDescription>
        </DialogHeader>

        <DialogFooter className="gap-2 sm:gap-0">
          <Button
            onClick={onClose}
            variant="outline"
          >
            Annuler
          </Button>
          
          {hasUnsavedChanges && (
            <Button
              onClick={onSaveAndClose}
              className="bg-slate-900 hover:bg-slate-800"
            >
              Sauvegarder et fermer
            </Button>
          )}
          
          <Button
            onClick={onCloseWithoutSave}
            variant="destructive"
          >
            {hasUnsavedChanges ? "Fermer sans sauvegarder" : "Fermer"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}