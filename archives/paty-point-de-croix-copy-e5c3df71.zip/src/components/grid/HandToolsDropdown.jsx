import React from 'react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Hand } from 'lucide-react';

const HAND_TOOLS = [
  {
    id: 'main-classique',
    icon: '✋',
    name: 'Main Classique',
    shortDesc: 'Déplacement libre',
    description: 'Glissez librement pour vous déplacer sur la grille.',
    features: ['Glisser', 'Zoomer', 'Navigation libre'],
    color: '#71717A',
  },
  {
    id: 'main-aimantee',
    icon: '🟡',
    name: 'Main Aimantée™',
    shortDesc: 'Alignement automatique',
    description: 'Je glisse, la grille s\'aligne toute seule sur les bords et zones utiles.',
    features: ['Centre auto', 'Zones denses', 'Clipsage intelligent'],
    color: '#FFC94A',
  },
  {
    id: 'main-gps',
    icon: '🔵',
    name: 'Main GPS™',
    shortDesc: 'Navigation par coordonnées',
    description: 'Je tape un symbole ou une coordonnée, l\'outil m\'y emmène directement.',
    features: ['Coordonnées', 'Symbole cible', 'Marque-pages'],
    color: '#3B82F6',
  },
  {
    id: 'main-suiveuse',
    icon: '🔴',
    name: 'Main Suiveuse™',
    shortDesc: 'Chemin de broderie guidé',
    description: 'L\'app me fait avancer de point en point, comme si je cousais.',
    features: ['Chemin optimal', 'Par couleur', 'Anti-oubli'],
    color: '#EF4444',
  },
];

export default function HandToolsDropdown({ 
  children, 
  currentSubTool, 
  onSelectSubTool,
  open,
  onOpenChange 
}) {
  return (
    <DropdownMenu open={open} onOpenChange={onOpenChange}>
      <DropdownMenuTrigger asChild>
        {children}
      </DropdownMenuTrigger>
      <DropdownMenuContent 
        side="bottom" 
        align="start" 
        className="w-80 p-0 bg-[#1a1a1a] border-[#333] rounded-xl overflow-hidden"
        sideOffset={8}
      >
        {/* Header */}
        <div className="px-4 py-3 bg-gradient-to-r from-[#71717A]/20 to-transparent border-b border-[#333]">
          <div className="flex items-center gap-2">
            <Hand className="w-4 h-4 text-[#aaa]" />
            <span className="text-white font-semibold text-sm">Outils de déplacement</span>
          </div>
          <p className="text-[#888] text-xs mt-1">Naviguez intelligemment sur votre grille</p>
        </div>

        {/* Tools list */}
        <div className="py-2">
          {HAND_TOOLS.map((tool, index) => (
            <React.Fragment key={tool.id}>
              <DropdownMenuItem
                onClick={() => onSelectSubTool(tool.id)}
                className={`mx-2 px-3 py-3 rounded-lg cursor-pointer transition-all ${
                  currentSubTool === tool.id 
                    ? 'bg-white/10' 
                    : 'hover:bg-white/5'
                }`}
              >
                <div className="flex items-start gap-3 w-full">
                  {/* Icon circle */}
                  <div 
                    className="w-10 h-10 rounded-full flex items-center justify-center text-xl shrink-0"
                    style={{ backgroundColor: `${tool.color}20`, border: `2px solid ${tool.color}` }}
                  >
                    {tool.icon}
                  </div>
                  
                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-white font-semibold text-sm">{tool.name}</span>
                      {currentSubTool === tool.id && (
                        <span 
                          className="px-1.5 py-0.5 text-white text-[10px] font-bold rounded"
                          style={{ backgroundColor: tool.color }}
                        >
                          ACTIF
                        </span>
                      )}
                    </div>
                    <p className="text-xs font-medium mt-0.5" style={{ color: tool.color }}>{tool.shortDesc}</p>
                    <p className="text-[#888] text-xs mt-1 leading-relaxed">{tool.description}</p>
                    
                    {/* Features tags */}
                    <div className="flex flex-wrap gap-1 mt-2">
                      {tool.features.map((feature, i) => (
                        <span 
                          key={i}
                          className="px-2 py-0.5 bg-white/5 text-[#aaa] text-[10px] rounded-full"
                        >
                          ✓ {feature}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </DropdownMenuItem>
              
              {index < HAND_TOOLS.length - 1 && (
                <div className="mx-4 my-1 h-px bg-[#333]" />
              )}
            </React.Fragment>
          ))}
        </div>

        {/* Footer */}
        <div className="px-4 py-2 bg-[#111] border-t border-[#333]">
          <p className="text-[#666] text-[10px] text-center">
            💡 Astuce : <kbd className="px-1 py-0.5 bg-[#333] rounded text-[#aaa]">Espace</kbd> + glisser pour déplacement rapide
          </p>
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

export { HAND_TOOLS };