import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { createPageUrl } from '../../utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import {
  User, Settings, FolderOpen, ShoppingBag,
  Camera, Edit2, Check, Trash2, Play, Pencil,
  SlidersHorizontal, Clock, Ruler, Palette, Eye,
  Accessibility, Bell, Save, Cloud, FileDown,
  Puzzle, Bot, MessageSquare, Lock, RotateCcw,
  Crown, ChevronRight, X, Sparkles
} from 'lucide-react';

export default function DashboardModal({ open, onClose, onLoadProject }) {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState('infos');
  const [projectFilter, setProjectFilter] = useState('all');
  const [editingProjectId, setEditingProjectId] = useState(null);
  const [editingProjectName, setEditingProjectName] = useState('');

  // Fetch user data
  const { data: user, isLoading: userLoading } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
    enabled: open,
  });

  // Fetch user profile
  const { data: profiles } = useQuery({
    queryKey: ['userProfile', user?.email],
    queryFn: () => base44.entities.UserProfile.filter({ created_by: user?.email }),
    enabled: !!user?.email && open,
  });

  // Fetch user projects
  const { data: projects = [] } = useQuery({
    queryKey: ['myProjects', user?.email],
    queryFn: () => base44.entities.Grid.filter({ created_by: user?.email }, '-updated_date'),
    enabled: !!user?.email && open,
  });

  const profile = profiles?.[0] || {};

  // Local state for editing
  const [formData, setFormData] = useState({
    prenom: '',
    nom: '',
    pays: '',
    adresse_actuelle: '',
  });

  useEffect(() => {
    if (profile) {
      setFormData({
        prenom: profile.prenom || '',
        nom: profile.nom || '',
        pays: profile.pays || '',
        adresse_actuelle: profile.adresse_actuelle || '',
      });
    }
  }, [profile]);

  // Calculate profile completion
  const calculateCompletion = () => {
    const fields = ['prenom', 'nom', 'pays', 'photo_url', 'adresse_actuelle'];
    const filled = fields.filter(f => profile?.[f]).length;
    return Math.round((filled / fields.length) * 100);
  };

  // Settings state
  const [settings, setSettings] = useState(() => {
    const saved = localStorage.getItem('patybee_dashboard_settings');
    return saved ? JSON.parse(saved) : {
      difficulty: 'Moyen',
      maxTime: 'Illimité',
      gridSize: 'Moyenne',
      visualStyle: 'Réaliste',
      colorMode: 'Couleurs',
      displayMode: 'Mix',
      accessibility: false,
      notifications: true,
      autoSave: true,
      cloudSync: true,
      exportFormat: 'PDF',
      guidedMode: false,
      aiHelp: 'Assistée',
      language: 'Français',
      privacy: 'Privé',
    };
  });

  const updateSetting = (key, value) => {
    const newSettings = { ...settings, [key]: value };
    setSettings(newSettings);
    localStorage.setItem('patybee_dashboard_settings', JSON.stringify(newSettings));
    toast.success('✅ Réglages mis à jour');
  };

  // Filter projects
  const filteredProjects = projects.filter(p => {
    if (projectFilter === 'all') return true;
    const progress = calculateProjectProgress(p);
    if (projectFilter === 'inProgress') return progress < 100;
    if (projectFilter === 'done') return progress === 100;
    return true;
  });

  // Calculate project progress
  function calculateProjectProgress(project) {
    if (!project?.pattern?.symbolGrid) return 0;
    const allCells = project.pattern.symbolGrid.flat().filter(c => c);
    if (allCells.length === 0) return 0;
    const done = allCells.filter(c => c.done).length;
    return Math.round((done / allCells.length) * 100);
  }

  const deleteProject = useMutation({
    mutationFn: (id) => base44.entities.Grid.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['myProjects']);
      toast.success('✅ Projet supprimé');
    },
  });

  const renameProject = useMutation({
    mutationFn: ({ id, name }) => base44.entities.Grid.update(id, { name }),
    onSuccess: () => {
      queryClient.invalidateQueries(['myProjects']);
      setEditingProjectId(null);
      toast.success('✅ Projet renommé');
    },
  });

  const updateProfile = useMutation({
    mutationFn: async (data) => {
      if (profiles?.[0]?.id) {
        return base44.entities.UserProfile.update(profiles[0].id, data);
      } else {
        return base44.entities.UserProfile.create(data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['userProfile']);
      toast.success('✅ Changements enregistrés');
    },
  });

  if (!open) return null;

  return (
    <div 
      className="fixed inset-0 z-[100] flex items-center justify-center"
      style={{ backgroundColor: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(4px)' }}
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <div 
        className="bg-[#111] rounded-2xl shadow-2xl overflow-hidden border border-[#333]"
        style={{ width: '90%', maxWidth: '900px', maxHeight: '85vh' }}
      >
        {/* Header */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Avatar className="w-12 h-12 border-2 border-amber-400">
              <AvatarImage src={profile?.photo_url} />
              <AvatarFallback className="bg-amber-500 text-white font-bold">
                {user?.full_name?.charAt(0) || 'U'}
              </AvatarFallback>
            </Avatar>
            <div>
              <h2 className="font-bold text-lg">{profile?.prenom || user?.full_name || 'Mon espace'}</h2>
              <p className="text-slate-400 text-sm">{user?.email}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="overflow-y-auto bg-[#111] p-6" style={{ maxHeight: 'calc(85vh - 100px)' }}>
          {/* RÉGLAGES */}
          <div>
              <div className="grid grid-cols-4 gap-3">
                {[
                  { icon: SlidersHorizontal, label: 'Difficulté', key: 'difficulty', type: 'select', options: ['Simple', 'Moyen', 'Avancé'] },
                  { icon: Clock, label: 'Temps max', key: 'maxTime', type: 'select', options: ['Court', 'Moyen', 'Long', 'Illimité'] },
                  { icon: Ruler, label: 'Taille grilles', key: 'gridSize', type: 'select', options: ['Petite', 'Moyenne', 'Grande'] },
                  { icon: Palette, label: 'Style visuel', key: 'visualStyle', type: 'select', options: ['Réaliste', 'Pixel', 'Minimal'] },
                  { icon: Bell, label: 'Notifications', key: 'notifications', type: 'toggle' },
                  { icon: Save, label: 'Sauvegarde auto', key: 'autoSave', type: 'toggle' },
                  { icon: Cloud, label: 'Cloud', key: 'cloudSync', type: 'toggle' },
                  { icon: FileDown, label: 'Export', key: 'exportFormat', type: 'select', options: ['PDF', 'PNG', 'PatyBee'] },
                ].map((item) => (
                  <Card key={item.key} className="hover:shadow-md transition-shadow bg-[#1a1a1a] border-[#333]">
                    <CardContent className="p-4 flex flex-col items-center text-center gap-2">
                      <div className="w-10 h-10 rounded-full bg-[#222] flex items-center justify-center">
                        <item.icon className="w-5 h-5 text-[#FFC94A]" />
                      </div>
                      <span className="text-sm font-medium text-white">{item.label}</span>
                      
                      {item.type === 'toggle' && (
                        <Switch
                          checked={settings[item.key] ?? false}
                          onCheckedChange={(v) => updateSetting(item.key, v)}
                        />
                      )}
                      
                      {item.type === 'select' && (
                        <Select
                          value={settings[item.key] || item.options[0]}
                          onValueChange={(v) => updateSetting(item.key, v)}
                        >
                          <SelectTrigger className="h-8 text-xs w-full bg-[#222] border-[#444] text-white">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent className="bg-[#222] border-[#444]">
                            {item.options.map((opt) => (
                              <SelectItem key={opt} value={opt} className="text-white hover:bg-white/10">{opt}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
          </div>
        </div>
      </div>
    </div>
  );
}