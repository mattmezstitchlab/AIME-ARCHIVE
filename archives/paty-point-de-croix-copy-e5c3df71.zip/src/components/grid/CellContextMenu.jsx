import React from 'react';
import { Button } from '@/components/ui/button';
import { Edit2, Palette } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function CellContextMenu({ 
  position, 
  cellData,
  onChangeSymbol,
  onChangeColor,
  onClose 
}) {
  if (!position || !cellData) return null;

  return (
    <>
      {/* Overlay pour fermer le menu */}
      <div 
        className="fixed inset-0 z-40"
        onClick={onClose}
      />
      
      {/* Menu contextuel */}
      <div
        className="fixed z-50 bg-white rounded-lg shadow-xl border border-slate-200 py-2 min-w-[200px]"
        style={{
          left: `${position.x}px`,
          top: `${position.y}px`,
        }}
      >
        <div className="px-3 py-2 border-b border-slate-200">
          <div className="flex items-center gap-2">
            <div
              className="w-6 h-6 rounded border border-slate-300"
              style={{ backgroundColor: cellData.color }}
            />
            <span className="text-lg font-bold">{cellData.symbol}</span>
            <span className="text-xs text-slate-500">
              ({cellData.colorName})
            </span>
          </div>
        </div>

        <div className="py-1">
          <Button
            variant="ghost"
            className="w-full justify-start gap-2 px-3 py-2 h-auto hover:bg-slate-100"
            onClick={() => {
              onChangeSymbol();
              onClose();
            }}
          >
            <Edit2 className="w-4 h-4" />
            <span>Changer le symbole...</span>
          </Button>

          <Button
            variant="ghost"
            className="w-full justify-start gap-2 px-3 py-2 h-auto hover:bg-slate-100"
            onClick={() => {
              onChangeColor();
              onClose();
            }}
          >
            <Palette className="w-4 h-4" />
            <span>Changer la couleur...</span>
          </Button>
        </div>
      </div>
    </>
  );
}