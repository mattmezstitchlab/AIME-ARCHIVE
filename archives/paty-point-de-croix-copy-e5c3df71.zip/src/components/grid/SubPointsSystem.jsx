import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { X, Check, Zap, RefreshCw, Droplets, Plus, Minus } from 'lucide-react';
import { toast } from 'sonner';

// Les 12 Points SUB Officiels
export const SUB_POINTS = [
  {
    id: 'S1',
    code: 'SUB-UNI',
    name: 'Point SUB UNI',
    description: 'Remplace le point de croix classique. 1 symbole = 1 unité. Plus rapide + plus précis.',
    icon: '▪',
    color: '#000000',
    category: 'base'
  },
  {
    id: 'S2',
    code: 'SUB-LORRAIN',
    name: 'Point SUB LORRAIN',
    description: 'Double barre verticale. Pour les lignes fortes / axes / renforts.',
    icon: '║',
    color: '#1E40AF',
    category: 'structure'
  },
  {
    id: 'S3',
    code: 'SUB-TRACE',
    name: 'Point SUB TRACE',
    description: 'Permet les contours ultra nets.',
    icon: '─',
    color: '#374151',
    category: 'contour'
  },
  {
    id: 'S4',
    code: 'SUB-SHADOW',
    name: 'Point SUB SHADOW',
    description: 'Gestion des ombres sans doublons.',
    icon: '░',
    color: '#6B7280',
    category: 'effet'
  },
  {
    id: 'S5',
    code: 'SUB-FUSION',
    name: 'Point SUB FUSION',
    description: 'Remplace tous les demi-points / quart de points.',
    icon: '◢',
    color: '#8B5CF6',
    category: 'base'
  },
  {
    id: 'S6',
    code: 'SUB-VELOURS',
    name: 'Point SUB VELOURS',
    description: 'Effet densité / intensité.',
    icon: '▓',
    color: '#7C3AED',
    category: 'texture'
  },
  {
    id: 'S7',
    code: 'SUB-RAIN',
    name: 'Point SUB RAIN',
    description: 'Dégradés directionnels.',
    icon: '▒',
    color: '#3B82F6',
    category: 'effet'
  },
  {
    id: 'S8',
    code: 'SUB-GOLD',
    name: 'Point SUB GOLD',
    description: 'Met en valeur zones clés.',
    icon: '★',
    color: '#F59E0B',
    category: 'accent'
  },
  {
    id: 'S9',
    code: 'SUB-LINK',
    name: 'Point SUB LINK',
    description: 'Pont entre deux zones (sans rupture).',
    icon: '⌇',
    color: '#10B981',
    category: 'structure'
  },
  {
    id: 'S10',
    code: 'SUB-SPARK',
    name: 'Point SUB SPARK',
    description: 'Accent visuel (1 pixel lumineux).',
    icon: '✦',
    color: '#EC4899',
    category: 'accent'
  },
  {
    id: 'S11',
    code: 'SUB-VOID',
    name: 'Point SUB VOID',
    description: 'Point invisible remplaçant les "trous".',
    icon: '○',
    color: '#E5E7EB',
    category: 'special'
  },
  {
    id: 'S12',
    code: 'SUB-KEY',
    name: 'Point SUB KEY',
    description: 'Point de verrouillage (repère central).',
    icon: '◉',
    color: '#EF4444',
    category: 'special'
  }
];

export const SUB_CATEGORIES = {
  base: { name: 'Base', color: '#000000' },
  structure: { name: 'Structure', color: '#1E40AF' },
  contour: { name: 'Contour', color: '#374151' },
  effet: { name: 'Effet', color: '#6B7280' },
  texture: { name: 'Texture', color: '#7C3AED' },
  accent: { name: 'Accent', color: '#F59E0B' },
  special: { name: 'Spécial', color: '#EF4444' }
};

// Panneau de sélection des Points SUB
export function SubPointsPanel({ open, onClose, onSelect, currentPoint }) {
  const [selectedCategory, setSelectedCategory] = useState('all');

  const filteredPoints = selectedCategory === 'all' 
    ? SUB_POINTS 
    : SUB_POINTS.filter(p => p.category === selectedCategory);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[99999] flex items-center justify-center bg-black/70">
      <div className="bg-white rounded-2xl shadow-2xl w-[800px] max-h-[85vh] overflow-hidden">
        {/* Header */}
        <div className="bg-black px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-yellow-400 to-orange-500 flex items-center justify-center">
              <Zap className="w-5 h-5 text-black" />
            </div>
            <div>
              <h2 className="text-lg font-black text-white">POINTS SUB</h2>
              <p className="text-sm text-gray-400">Le nouveau langage du point de croix</p>
            </div>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center">
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        {/* Catégories */}
        <div className="px-6 py-3 border-b flex gap-2 overflow-x-auto">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-3 py-1.5 rounded-full text-sm font-medium whitespace-nowrap ${
              selectedCategory === 'all' ? 'bg-black text-white' : 'bg-gray-100 hover:bg-gray-200'
            }`}
          >
            Tous (12)
          </button>
          {Object.entries(SUB_CATEGORIES).map(([key, cat]) => (
            <button
              key={key}
              onClick={() => setSelectedCategory(key)}
              className={`px-3 py-1.5 rounded-full text-sm font-medium whitespace-nowrap ${
                selectedCategory === key ? 'bg-black text-white' : 'bg-gray-100 hover:bg-gray-200'
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>

        {/* Grille des points */}
        <div className="p-6 overflow-y-auto" style={{ maxHeight: 'calc(85vh - 200px)' }}>
          <div className="grid grid-cols-3 gap-4">
            {filteredPoints.map((point) => (
              <button
                key={point.id}
                onClick={() => {
                  onSelect?.(point);
                  toast.success(`Point ${point.name} sélectionné`);
                }}
                className={`p-4 rounded-xl border-2 text-left transition-all hover:shadow-lg ${
                  currentPoint?.id === point.id 
                    ? 'border-yellow-500 bg-yellow-50' 
                    : 'border-gray-200 hover:border-gray-400'
                }`}
              >
                <div className="flex items-center gap-3 mb-2">
                  <div 
                    className="w-12 h-12 rounded-lg flex items-center justify-center text-2xl"
                    style={{ backgroundColor: point.color + '20', color: point.color }}
                  >
                    {point.icon}
                  </div>
                  <div>
                    <div className="font-bold text-sm">{point.id}</div>
                    <div className="text-xs text-gray-500">{point.code}</div>
                  </div>
                </div>
                <h4 className="font-semibold text-sm mb-1">{point.name}</h4>
                <p className="text-xs text-gray-600 line-clamp-2">{point.description}</p>
              </button>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t bg-green-50">
          <p className="text-sm text-green-800 text-center font-medium">
            ✅ SYSTÈME SUB ACTIVÉ — vous brodez avec la nouvelle norme.
          </p>
        </div>
      </div>
    </div>
  );
}

// Barre d'outils Points SUB
export function SubPointsToolbar({ onOpenPanel, currentPoint, onConvert, onAutoFill, onRepair, onDensityUp, onDensityDown, onLorrainMode }) {
  return (
    <TooltipProvider>
      <div className="flex items-center gap-1 bg-white border rounded-lg p-1 shadow-sm">
        {/* Sélecteur Point SUB */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant="ghost"
              size="sm"
              onClick={onOpenPanel}
              className="h-8 px-3 gap-2 bg-yellow-100 hover:bg-yellow-200 text-yellow-800"
            >
              <span className="text-lg">{currentPoint?.icon || '▪'}</span>
              <span className="text-xs font-bold">{currentPoint?.id || 'S1'}</span>
            </Button>
          </TooltipTrigger>
          <TooltipContent><p>Sélecteur de Point SUB</p></TooltipContent>
        </Tooltip>

        <div className="w-px h-6 bg-gray-300 mx-1" />

        {/* Convertisseur */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Button variant="ghost" size="icon" className="h-8 w-8 bg-purple-100 hover:bg-purple-200 text-purple-700" onClick={onConvert}>
              <RefreshCw className="w-4 h-4" />
            </Button>
          </TooltipTrigger>
          <TooltipContent><p>Convertir anciens points → SUB</p></TooltipContent>
        </Tooltip>

        {/* Remplissage auto */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={onAutoFill}>
              <Droplets className="w-4 h-4" />
            </Button>
          </TooltipTrigger>
          <TooltipContent><p>Remplissage automatique</p></TooltipContent>
        </Tooltip>

        {/* Réparation trous */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Button variant="ghost" size="icon" className="h-8 w-8 text-red-600" onClick={onRepair}>
              <Zap className="w-4 h-4" />
            </Button>
          </TooltipTrigger>
          <TooltipContent><p>Réparation des trous</p></TooltipContent>
        </Tooltip>

        <div className="w-px h-6 bg-gray-300 mx-1" />

        {/* Densité + */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Button variant="ghost" size="icon" className="h-8 w-8 text-red-500" onClick={onDensityUp}>
              <Plus className="w-4 h-4" />
            </Button>
          </TooltipTrigger>
          <TooltipContent><p>Densité SUB +</p></TooltipContent>
        </Tooltip>

        {/* Densité - */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Button variant="ghost" size="icon" className="h-8 w-8 text-blue-500" onClick={onDensityDown}>
              <Minus className="w-4 h-4" />
            </Button>
          </TooltipTrigger>
          <TooltipContent><p>Densité SUB -</p></TooltipContent>
        </Tooltip>

        {/* Mode Lorrain */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Button variant="ghost" size="icon" className="h-8 w-8 text-green-600" onClick={onLorrainMode}>
              <span className="font-bold text-sm">L</span>
            </Button>
          </TooltipTrigger>
          <TooltipContent><p>Mode LORRAIN</p></TooltipContent>
        </Tooltip>
      </div>
    </TooltipProvider>
  );
}

// Convertir anciens points vers SUB
export function convertToSubPoints(pattern) {
  if (!pattern?.symbolGrid) return pattern;

  const newGrid = pattern.symbolGrid.map(row => 
    row.map(cell => {
      if (!cell) return { ...cell, type: 'S11' }; // VOID pour les trous
      
      // Convertir selon le type existant
      const oldType = cell.type?.toLowerCase() || 'full';
      let newType = 'S1'; // UNI par défaut

      switch (oldType) {
        case 'half':
        case 'quarter':
        case 'threequarter':
          newType = 'S5'; // FUSION
          break;
        case 'backstitch':
          newType = 'S3'; // TRACE
          break;
        case 'frenchknot':
          newType = 'S10'; // SPARK
          break;
        case 'bead':
          newType = 'S8'; // GOLD
          break;
        default:
          newType = 'S1'; // UNI
      }

      return { ...cell, type: newType };
    })
  );

  return { ...pattern, symbolGrid: newGrid };
}

export default { SUB_POINTS, SUB_CATEGORIES, SubPointsPanel, SubPointsToolbar, convertToSubPoints };