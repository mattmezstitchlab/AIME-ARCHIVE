import React, { useState, useRef, useEffect } from 'react';
import { Target, Maximize2, Crosshair } from 'lucide-react';

export default function MiniMap4DEnhanced({
  gridConfig,
  pattern,
  canvasSize,
  onNavigate,
  onZoomToArea,
  showPatternImage = true
}) {
  const [isLoupeMode, setIsLoupeMode] = useState(false);
  const [selectionStart, setSelectionStart] = useState(null);
  const [selectionEnd, setSelectionEnd] = useState(null);
  const [isDragging, setIsDragging] = useState(false);
  const minimapRef = useRef(null);

  // Dimensions de la mini-carte
  const minimapWidth = 200;
  const minimapHeight = 200;

  // Calculer les dimensions de la grille complète en pixels
  const gridPixelWidth = gridConfig.nb_colonnes * gridConfig.taille_case * gridConfig.zoom;
  const gridPixelHeight = gridConfig.nb_lignes * gridConfig.taille_case * gridConfig.zoom;

  // Calculer le ratio pour afficher toute la grille dans la mini-carte
  const scaleX = minimapWidth / (gridConfig.nb_colonnes * gridConfig.taille_case);
  const scaleY = minimapHeight / (gridConfig.nb_lignes * gridConfig.taille_case);
  const scale = Math.min(scaleX, scaleY);

  const scaledGridWidth = gridConfig.nb_colonnes * gridConfig.taille_case * scale;
  const scaledGridHeight = gridConfig.nb_lignes * gridConfig.taille_case * scale;

  // Calculer la position et taille du carré bleu (zone visible)
  const getViewportRect = () => {
    if (!canvasSize.width || !canvasSize.height) return null;

    // Position de la vue dans la grille complète
    const viewX = -gridConfig.offset_x;
    const viewY = -gridConfig.offset_y;
    const viewWidth = canvasSize.width;
    const viewHeight = canvasSize.height;

    // Convertir en coordonnées de la mini-carte
    const miniViewX = (viewX / gridPixelWidth) * scaledGridWidth;
    const miniViewY = (viewY / gridPixelHeight) * scaledGridHeight;
    const miniViewWidth = (viewWidth / gridPixelWidth) * scaledGridWidth;
    const miniViewHeight = (viewHeight / gridPixelHeight) * scaledGridHeight;

    return {
      x: Math.max(0, Math.min(miniViewX, scaledGridWidth)),
      y: Math.max(0, Math.min(miniViewY, scaledGridHeight)),
      width: Math.min(miniViewWidth, scaledGridWidth),
      height: Math.min(miniViewHeight, scaledGridHeight)
    };
  };

  const viewportRect = getViewportRect();

  // Position du repère central
  const centerX = (gridConfig.nb_colonnes / 2) * gridConfig.taille_case * scale;
  const centerY = (gridConfig.nb_lignes / 2) * gridConfig.taille_case * scale;

  // Gérer le clic dans la mini-carte
  const handleMinimapClick = (e) => {
    if (isLoupeMode || isDragging) return;

    const rect = minimapRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    // Convertir en position de la grille
    const gridX = (x / scaledGridWidth) * gridPixelWidth;
    const gridY = (y / scaledGridHeight) * gridPixelHeight;

    // Centrer la vue sur ce point
    onNavigate(gridX, gridY);
  };

  // Mode loupe : sélection de zone
  const handleMouseDown = (e) => {
    if (!isLoupeMode) return;

    const rect = minimapRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    setSelectionStart({ x, y });
    setSelectionEnd({ x, y });
    setIsDragging(true);
  };

  const handleMouseMove = (e) => {
    if (!isDragging || !isLoupeMode) return;

    const rect = minimapRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    setSelectionEnd({ x, y });
  };

  const handleMouseUp = () => {
    if (!isDragging || !isLoupeMode) return;

    setIsDragging(false);

    if (selectionStart && selectionEnd) {
      // Calculer la zone sélectionnée
      const x1 = Math.min(selectionStart.x, selectionEnd.x);
      const y1 = Math.min(selectionStart.y, selectionEnd.y);
      const x2 = Math.max(selectionStart.x, selectionEnd.x);
      const y2 = Math.max(selectionStart.y, selectionEnd.y);

      // Convertir en coordonnées de la grille
      const gridX1 = (x1 / scaledGridWidth) * (gridConfig.nb_colonnes * gridConfig.taille_case);
      const gridY1 = (y1 / scaledGridHeight) * (gridConfig.nb_lignes * gridConfig.taille_case);
      const gridX2 = (x2 / scaledGridWidth) * (gridConfig.nb_colonnes * gridConfig.taille_case);
      const gridY2 = (y2 / scaledGridHeight) * (gridConfig.nb_lignes * gridConfig.taille_case);

      // Zoomer sur cette zone
      if (onZoomToArea) {
        onZoomToArea({
          x: gridX1,
          y: gridY1,
          width: gridX2 - gridX1,
          height: gridY2 - gridY1
        });
      }
    }

    setSelectionStart(null);
    setSelectionEnd(null);
    setIsLoupeMode(false);
  };

  const handleRecenter = () => {
    // Centrer sur le repère central
    const centerGridX = (gridConfig.nb_colonnes / 2) * gridConfig.taille_case;
    const centerGridY = (gridConfig.nb_lignes / 2) * gridConfig.taille_case;
    onNavigate(centerGridX, centerGridY);
  };

  const handleFitView = () => {
    // Afficher toute la grille
    if (onZoomToArea) {
      onZoomToArea({
        x: 0,
        y: 0,
        width: gridConfig.nb_colonnes * gridConfig.taille_case,
        height: gridConfig.nb_lignes * gridConfig.taille_case
      });
    }
  };

  return (
    <div className="space-y-3">
      {/* Header */}
      <div className="flex items-center justify-between text-xs">
        <span className="text-slate-700 font-medium">Mini-carte – Aperçu global</span>
        <span className="text-slate-500">Zoom: {Math.round(gridConfig.zoom * 100)}%</span>
      </div>

      {/* Zone de mini-carte */}
      <div
        ref={minimapRef}
        className={`relative bg-slate-100 rounded-lg border-2 border-slate-200 overflow-hidden ${
          isLoupeMode ? 'cursor-crosshair' : 'cursor-pointer'
        }`}
        style={{
          width: `${minimapWidth}px`,
          height: `${minimapHeight}px`
        }}
        onClick={handleMinimapClick}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      >
        {/* Grille miniature */}
        <div
          className="absolute"
          style={{
            width: `${scaledGridWidth}px`,
            height: `${scaledGridHeight}px`,
            left: `${(minimapWidth - scaledGridWidth) / 2}px`,
            top: `${(minimapHeight - scaledGridHeight) / 2}px`
          }}
        >
          {/* Fond de grille */}
          <div className="absolute inset-0 bg-white border border-slate-300" />

          {/* Visuel importé */}
          {pattern?.sourceImage && showPatternImage && (
            <img
              src={pattern.sourceImage}
              alt="Pattern"
              className="absolute inset-0 w-full h-full object-cover opacity-40"
              style={{
                imageRendering: 'pixelated'
              }}
            />
          )}

          {/* Repère central rouge */}
          <div
            className="absolute"
            style={{
              left: `${centerX}px`,
              top: `${centerY}px`,
              transform: 'translate(-50%, -50%)'
            }}
          >
            <div className="relative w-3 h-3">
              <div className="absolute inset-0 bg-red-500 rounded-full" />
              <div className="absolute left-1/2 top-0 w-px h-full bg-red-500 transform -translate-x-1/2" />
              <div className="absolute left-0 top-1/2 w-full h-px bg-red-500 transform -translate-y-1/2" />
            </div>
          </div>

          {/* Carré bleu (zone visible) */}
          {viewportRect && (
            <div
              className="absolute border-2 border-blue-500 bg-blue-500/10 pointer-events-none"
              style={{
                left: `${viewportRect.x}px`,
                top: `${viewportRect.y}px`,
                width: `${viewportRect.width}px`,
                height: `${viewportRect.height}px`
              }}
            />
          )}

          {/* Rectangle de sélection (mode loupe) */}
          {isLoupeMode && selectionStart && selectionEnd && (
            <div
              className="absolute border-2 border-purple-500 bg-purple-500/10 pointer-events-none"
              style={{
                left: `${Math.min(selectionStart.x, selectionEnd.x) - (minimapWidth - scaledGridWidth) / 2}px`,
                top: `${Math.min(selectionStart.y, selectionEnd.y) - (minimapHeight - scaledGridHeight) / 2}px`,
                width: `${Math.abs(selectionEnd.x - selectionStart.x)}px`,
                height: `${Math.abs(selectionEnd.y - selectionStart.y)}px`
              }}
            />
          )}
        </div>

        {/* Instructions mode loupe */}
        {isLoupeMode && (
          <div className="absolute bottom-2 left-2 right-2 bg-purple-600 text-white text-[10px] px-2 py-1 rounded text-center">
            Cliquez et glissez pour sélectionner une zone
          </div>
        )}
      </div>

      {/* Barre d'actions */}
      <div className="grid grid-cols-3 gap-2">
        <button
          onClick={() => setIsLoupeMode(!isLoupeMode)}
          className={`h-8 flex items-center justify-center rounded-lg transition-colors ${
            isLoupeMode
              ? 'bg-purple-600 text-white'
              : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
          }`}
          title="Mode loupe"
        >
          <Crosshair className="w-4 h-4" />
        </button>

        <button
          onClick={handleRecenter}
          className="h-8 flex items-center justify-center rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
          title="Recentrer sur le repère central"
        >
          <Target className="w-4 h-4" />
        </button>

        <button
          onClick={handleFitView}
          className="h-8 flex items-center justify-center rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
          title="Adapter la vue"
        >
          <Maximize2 className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}