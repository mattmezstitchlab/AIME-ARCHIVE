// =============================================
// MOTEUR DE RÉPARATION AUTOMATIQUE SUB™
// 0 trou — 0 symbole manquant — 100% brodable
// =============================================

import { DMC_LIBRARY } from './dmcLibrary';
import { SUB_STITCH_TYPES, autoSelectSubStitch } from './subStitchTypes';

// Symboles disponibles pour l'assignation automatique
const SYMBOLS = [
  '●', '■', '▲', '◆', '★', '✦', '○', '□', '△', '◇',
  '✕', '✚', '♦', '♠', '♣', '♥', '▼', '◉', '◎', '⬟',
  '⬡', '⬢', '⬣', '✶', '✹', '✸', '✷', '❖', '⚫', '⚪',
  '◐', '◑', '◒', '◓', '▣', '▤', '▥', '▧', '▨', '▩'
];

/**
 * Analyse complète d'une grille SUB
 */
export const analyzeGrid = (pattern) => {
  if (!pattern?.symbolGrid) {
    return { 
      isValid: false, 
      errors: ['Aucune grille détectée'],
      stats: null 
    };
  }

  const stats = {
    totalCells: 0,
    filledCells: 0,
    emptyCells: 0,
    isolatedHoles: 0,
    orphanColors: [],
    missingSymbols: [],
    invalidDMC: [],
    inconsistentCells: []
  };

  const colorUsage = new Map();
  const symbolUsage = new Map();

  // Parcourir toute la grille
  for (let row = 0; row < pattern.height; row++) {
    for (let col = 0; col < pattern.width; col++) {
      stats.totalCells++;
      const cell = pattern.symbolGrid[row]?.[col];

      if (!cell) {
        stats.emptyCells++;
        
        // Vérifier si c'est un trou isolé (entouré de cellules remplies)
        const neighbors = getNeighbors(pattern.symbolGrid, row, col, pattern.width, pattern.height);
        const filledNeighbors = neighbors.filter(n => n !== null).length;
        
        if (filledNeighbors >= 3) {
          stats.isolatedHoles++;
        }
      } else {
        stats.filledCells++;
        
        // Compter l'utilisation des couleurs
        const colorId = cell.colorId || cell.color;
        colorUsage.set(colorId, (colorUsage.get(colorId) || 0) + 1);
        
        // Compter l'utilisation des symboles
        if (cell.symbol) {
          symbolUsage.set(cell.symbol, (symbolUsage.get(cell.symbol) || 0) + 1);
        }
        
        // Vérifier si le symbole est manquant
        if (!cell.symbol) {
          stats.missingSymbols.push({ row, col, colorId });
        }
      }
    }
  }

  // Détecter les couleurs orphelines (moins de 5 occurrences)
  colorUsage.forEach((count, colorId) => {
    if (count < 5) {
      stats.orphanColors.push({ colorId, count });
    }
  });

  // Vérifier la validité DMC de la palette
  if (pattern.colorPalette) {
    pattern.colorPalette.forEach(color => {
      if (!color.dmc && !color.code?.startsWith('DMC')) {
        stats.invalidDMC.push(color.id);
      }
    });
  }

  const errors = [];
  if (stats.emptyCells > 0) errors.push(`${stats.emptyCells} cases vides détectées`);
  if (stats.isolatedHoles > 0) errors.push(`${stats.isolatedHoles} trous isolés`);
  if (stats.orphanColors.length > 0) errors.push(`${stats.orphanColors.length} couleurs orphelines`);
  if (stats.missingSymbols.length > 0) errors.push(`${stats.missingSymbols.length} symboles manquants`);
  if (stats.invalidDMC.length > 0) errors.push(`${stats.invalidDMC.length} couleurs sans DMC`);

  return {
    isValid: errors.length === 0,
    errors,
    stats,
    colorUsage,
    symbolUsage
  };
};

/**
 * Récupérer les voisins d'une cellule
 */
const getNeighbors = (grid, row, col, width, height) => {
  const neighbors = [];
  const directions = [[-1, 0], [1, 0], [0, -1], [0, 1]];
  
  directions.forEach(([dr, dc]) => {
    const nr = row + dr;
    const nc = col + dc;
    if (nr >= 0 && nr < height && nc >= 0 && nc < width) {
      neighbors.push(grid[nr]?.[nc] || null);
    }
  });
  
  return neighbors;
};

/**
 * Trouver la couleur DMC la plus proche
 */
const findClosestDMC = (hex) => {
  if (!hex) return DMC_LIBRARY[0];
  
  const rgb = hexToRgb(hex);
  let closest = DMC_LIBRARY[0];
  let minDist = Infinity;

  DMC_LIBRARY.forEach(dmc => {
    const dmcRgb = hexToRgb(dmc.hex);
    const dist = Math.sqrt(
      Math.pow(rgb.r - dmcRgb.r, 2) +
      Math.pow(rgb.g - dmcRgb.g, 2) +
      Math.pow(rgb.b - dmcRgb.b, 2)
    );
    if (dist < minDist) {
      minDist = dist;
      closest = dmc;
    }
  });

  return closest;
};

const hexToRgb = (hex) => {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result ? {
    r: parseInt(result[1], 16),
    g: parseInt(result[2], 16),
    b: parseInt(result[3], 16)
  } : { r: 0, g: 0, b: 0 };
};

/**
 * RÉPARATION AUTOMATIQUE SUB™
 * Corrige tous les problèmes en une seule passe
 */
export const autoRepairSub = (pattern, options = {}) => {
  const { mode = 'fast' } = options; // 'fast' ou 'expert'
  
  if (!pattern?.symbolGrid) {
    return { success: false, error: 'Aucune grille à réparer', repairs: [] };
  }

  const repairs = [];
  const newSymbolGrid = pattern.symbolGrid.map(row => row.map(cell => cell ? { ...cell } : null));
  const newColorPalette = [...(pattern.colorPalette || [])];
  
  // Créer un mapping couleur -> symbole
  const colorToSymbol = new Map();
  const usedSymbols = new Set();
  
  newColorPalette.forEach((color, idx) => {
    const symbol = color.assignedSymbolChar || color.symbol || SYMBOLS[idx % SYMBOLS.length];
    colorToSymbol.set(color.id, symbol);
    usedSymbols.add(symbol);
  });

  // ÉTAPE 1: Remplir les trous isolés
  let holesRepaired = 0;
  for (let row = 0; row < pattern.height; row++) {
    for (let col = 0; col < pattern.width; col++) {
      if (!newSymbolGrid[row][col]) {
        const neighbors = [];
        const directions = [[-1, 0], [1, 0], [0, -1], [0, 1], [-1, -1], [-1, 1], [1, -1], [1, 1]];
        
        directions.forEach(([dr, dc]) => {
          const nr = row + dr;
          const nc = col + dc;
          if (nr >= 0 && nr < pattern.height && nc >= 0 && nc < pattern.width) {
            const cell = newSymbolGrid[nr]?.[nc];
            if (cell) neighbors.push(cell);
          }
        });

        if (neighbors.length >= 2) {
          // Trouver la couleur dominante
          const colorCounts = {};
          neighbors.forEach(n => {
            const colorId = n.colorId || n.color;
            colorCounts[colorId] = (colorCounts[colorId] || 0) + 1;
          });
          
          const dominantColor = Object.entries(colorCounts).sort((a, b) => b[1] - a[1])[0][0];
          const symbol = colorToSymbol.get(dominantColor) || '●';
          
          // Déterminer le type de point SUB
          const stitchType = autoSelectSubStitch({
            isTransition: neighbors.length >= 4,
            isEdge: neighbors.length === 2
          });

          newSymbolGrid[row][col] = {
            colorId: dominantColor,
            symbol,
            type: stitchType,
            done: false,
            repaired: true
          };
          
          holesRepaired++;
          repairs.push({ type: 'hole_filled', row, col, colorId: dominantColor });
        }
      }
    }
  }

  // ÉTAPE 2: Assigner les symboles manquants
  let symbolsAssigned = 0;
  for (let row = 0; row < pattern.height; row++) {
    for (let col = 0; col < pattern.width; col++) {
      const cell = newSymbolGrid[row]?.[col];
      if (cell && !cell.symbol) {
        const colorId = cell.colorId || cell.color;
        let symbol = colorToSymbol.get(colorId);
        
        if (!symbol) {
          // Trouver un symbole non utilisé
          symbol = SYMBOLS.find(s => !usedSymbols.has(s)) || '●';
          colorToSymbol.set(colorId, symbol);
          usedSymbols.add(symbol);
        }
        
        newSymbolGrid[row][col] = { ...cell, symbol };
        symbolsAssigned++;
        repairs.push({ type: 'symbol_assigned', row, col, symbol });
      }
    }
  }

  // ÉTAPE 3: Corriger les couleurs DMC invalides
  let dmcCorrected = 0;
  newColorPalette.forEach((color, idx) => {
    if (!color.dmc && !color.code?.startsWith('DMC')) {
      const closestDMC = findClosestDMC(color.hex);
      newColorPalette[idx] = {
        ...color,
        dmc: closestDMC.code,
        dmcName: closestDMC.name,
        dmcHex: closestDMC.hex
      };
      dmcCorrected++;
      repairs.push({ type: 'dmc_corrected', colorId: color.id, dmc: closestDMC.code });
    }
  });

  // ÉTAPE 4: Fusionner les couleurs orphelines (< 5 occurrences)
  const colorUsage = new Map();
  for (let row = 0; row < pattern.height; row++) {
    for (let col = 0; col < pattern.width; col++) {
      const cell = newSymbolGrid[row]?.[col];
      if (cell) {
        const colorId = cell.colorId || cell.color;
        colorUsage.set(colorId, (colorUsage.get(colorId) || 0) + 1);
      }
    }
  }

  let colorsMerged = 0;
  const orphanColors = [];
  colorUsage.forEach((count, colorId) => {
    if (count < 5) {
      orphanColors.push(colorId);
    }
  });

  // Pour chaque couleur orpheline, la fusionner avec la couleur la plus proche
  orphanColors.forEach(orphanId => {
    const orphanColor = newColorPalette.find(c => c.id === orphanId);
    if (!orphanColor) return;

    // Trouver la couleur la plus proche (non orpheline)
    let closestId = null;
    let minDist = Infinity;
    
    newColorPalette.forEach(color => {
      if (color.id === orphanId || orphanColors.includes(color.id)) return;
      
      const orphanRgb = hexToRgb(orphanColor.hex);
      const colorRgb = hexToRgb(color.hex);
      const dist = Math.sqrt(
        Math.pow(orphanRgb.r - colorRgb.r, 2) +
        Math.pow(orphanRgb.g - colorRgb.g, 2) +
        Math.pow(orphanRgb.b - colorRgb.b, 2)
      );
      
      if (dist < minDist) {
        minDist = dist;
        closestId = color.id;
      }
    });

    if (closestId) {
      // Remplacer toutes les occurrences
      for (let row = 0; row < pattern.height; row++) {
        for (let col = 0; col < pattern.width; col++) {
          const cell = newSymbolGrid[row]?.[col];
          if (cell && (cell.colorId === orphanId || cell.color === orphanId)) {
            const newSymbol = colorToSymbol.get(closestId) || cell.symbol;
            newSymbolGrid[row][col] = { ...cell, colorId: closestId, color: closestId, symbol: newSymbol };
          }
        }
      }
      colorsMerged++;
      repairs.push({ type: 'color_merged', from: orphanId, to: closestId });
    }
  });

  // ÉTAPE 5: Remplissage final (garantie 0 trou)
  let finalFills = 0;
  for (let row = 0; row < pattern.height; row++) {
    for (let col = 0; col < pattern.width; col++) {
      if (!newSymbolGrid[row][col]) {
        // Chercher dans un rayon plus large
        const nearbyColors = [];
        for (let dr = -5; dr <= 5; dr++) {
          for (let dc = -5; dc <= 5; dc++) {
            const nr = row + dr;
            const nc = col + dc;
            if (nr >= 0 && nr < pattern.height && nc >= 0 && nc < pattern.width) {
              const cell = newSymbolGrid[nr]?.[nc];
              if (cell) nearbyColors.push(cell.colorId || cell.color);
            }
          }
        }

        if (nearbyColors.length > 0) {
          const colorCounts = {};
          nearbyColors.forEach(c => colorCounts[c] = (colorCounts[c] || 0) + 1);
          const dominantColor = Object.entries(colorCounts).sort((a, b) => b[1] - a[1])[0][0];
          const symbol = colorToSymbol.get(dominantColor) || '●';

          newSymbolGrid[row][col] = {
            colorId: dominantColor,
            symbol,
            type: 'S0', // Point Zero pour verrouillage
            done: false,
            repaired: true
          };
          finalFills++;
        } else {
          // Dernier recours: première couleur de la palette
          const firstColor = newColorPalette[0]?.id || 'color-0';
          const symbol = colorToSymbol.get(firstColor) || '●';
          
          newSymbolGrid[row][col] = {
            colorId: firstColor,
            symbol,
            type: 'S0',
            done: false,
            repaired: true
          };
          finalFills++;
        }
        
        repairs.push({ type: 'final_fill', row, col });
      }
    }
  }

  // Résumé
  const summary = {
    holesRepaired,
    symbolsAssigned,
    dmcCorrected,
    colorsMerged,
    finalFills,
    totalRepairs: repairs.length
  };

  return {
    success: true,
    pattern: {
      ...pattern,
      symbolGrid: newSymbolGrid,
      colorPalette: newColorPalette
    },
    repairs,
    summary,
    message: `✅ Réparation terminée : ${summary.totalRepairs} corrections appliquées. Votre grille est maintenant 100% complète.`
  };
};

/**
 * Vérifier si une grille est valide SUB
 */
export const isValidSubGrid = (pattern) => {
  const analysis = analyzeGrid(pattern);
  return analysis.isValid;
};