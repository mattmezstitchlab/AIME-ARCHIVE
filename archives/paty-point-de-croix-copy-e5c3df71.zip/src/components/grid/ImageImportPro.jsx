import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { 
  X, Upload, Loader2, Image as ImageIcon, Check, Palette, Grid3X3, 
  Merge, ChevronDown, ChevronUp, Sparkles, Link, Shield, RotateCcw,
  Eye, EyeOff, Zap, Settings2
} from 'lucide-react';
import { toast } from 'sonner';
import { base44 } from '@/api/base44Client';
import { DMC_LIBRARY } from './dmcLibrary';

// ==========================================
// SYMBOLES POUR LA GRILLE
// ==========================================
const SYMBOLS = [
  '●', '■', '▲', '◆', '★', '✦', '○', '□', '△', '◇',
  '✕', '✚', '♦', '♠', '♣', '♥', '▼', '◉', '◎', '⬟',
  '⬡', '⬢', '⊕', '⊗', '⊙', '⊛', '⊜', '⊝', '▣', '▤',
  '▥', '▦', '▧', '▨', '▩', '♢', '♤', '♧', '⬣', '⬤',
  '◐', '◑', '◒', '◓', '◔', '◕', '◖', '◗', '◘', '◙',
  '◚', '◛', '◜', '◝', '◞', '◟', '◠', '◡', '⊞', '⊟',
  '⊠', '⊡', '▢', '▣', '▤', '▥', '▦', '▧', '▨', '▩',
  '⬒', '⬓', '⬔', '⬕', '⬖', '⬗', '⬘', '⬙', '⬚', '⬛',
  '⬜', '⬝', '⬞', '⬟', '⬠', '⬡', '⬢', '⬣', '⬤', '⭐',
  '⭑', '⭒', '⭓', '⭔', '⭕', '⭖', '⭗', '⭘', '⭙', '⭚'
];

// ==========================================
// DELTA-E 2000 - CORRESPONDANCE COULEUR PRÉCISE
// ==========================================
function deltaE2000(lab1, lab2) {
  const [L1, a1, b1] = lab1;
  const [L2, a2, b2] = lab2;
  
  const kL = 1, kC = 1, kH = 1;
  
  const C1 = Math.sqrt(a1 * a1 + b1 * b1);
  const C2 = Math.sqrt(a2 * a2 + b2 * b2);
  const Cab = (C1 + C2) / 2;
  
  const G = 0.5 * (1 - Math.sqrt(Math.pow(Cab, 7) / (Math.pow(Cab, 7) + Math.pow(25, 7))));
  
  const a1p = a1 * (1 + G);
  const a2p = a2 * (1 + G);
  
  const C1p = Math.sqrt(a1p * a1p + b1 * b1);
  const C2p = Math.sqrt(a2p * a2p + b2 * b2);
  
  const h1p = Math.atan2(b1, a1p) * 180 / Math.PI;
  const h2p = Math.atan2(b2, a2p) * 180 / Math.PI;
  
  const h1pAdj = h1p < 0 ? h1p + 360 : h1p;
  const h2pAdj = h2p < 0 ? h2p + 360 : h2p;
  
  const dLp = L2 - L1;
  const dCp = C2p - C1p;
  
  let dhp = 0;
  if (C1p * C2p === 0) {
    dhp = 0;
  } else if (Math.abs(h2pAdj - h1pAdj) <= 180) {
    dhp = h2pAdj - h1pAdj;
  } else if (h2pAdj - h1pAdj > 180) {
    dhp = h2pAdj - h1pAdj - 360;
  } else {
    dhp = h2pAdj - h1pAdj + 360;
  }
  
  const dHp = 2 * Math.sqrt(C1p * C2p) * Math.sin(dhp * Math.PI / 360);
  
  const Lp = (L1 + L2) / 2;
  const Cp = (C1p + C2p) / 2;
  
  let Hp = 0;
  if (C1p * C2p === 0) {
    Hp = h1pAdj + h2pAdj;
  } else if (Math.abs(h1pAdj - h2pAdj) <= 180) {
    Hp = (h1pAdj + h2pAdj) / 2;
  } else if (h1pAdj + h2pAdj < 360) {
    Hp = (h1pAdj + h2pAdj + 360) / 2;
  } else {
    Hp = (h1pAdj + h2pAdj - 360) / 2;
  }
  
  const T = 1 - 0.17 * Math.cos((Hp - 30) * Math.PI / 180) 
            + 0.24 * Math.cos(2 * Hp * Math.PI / 180)
            + 0.32 * Math.cos((3 * Hp + 6) * Math.PI / 180)
            - 0.20 * Math.cos((4 * Hp - 63) * Math.PI / 180);
  
  const dTheta = 30 * Math.exp(-Math.pow((Hp - 275) / 25, 2));
  const RC = 2 * Math.sqrt(Math.pow(Cp, 7) / (Math.pow(Cp, 7) + Math.pow(25, 7)));
  const SL = 1 + (0.015 * Math.pow(Lp - 50, 2)) / Math.sqrt(20 + Math.pow(Lp - 50, 2));
  const SC = 1 + 0.045 * Cp;
  const SH = 1 + 0.015 * Cp * T;
  const RT = -Math.sin(2 * dTheta * Math.PI / 180) * RC;
  
  const dE = Math.sqrt(
    Math.pow(dLp / (kL * SL), 2) +
    Math.pow(dCp / (kC * SC), 2) +
    Math.pow(dHp / (kH * SH), 2) +
    RT * (dCp / (kC * SC)) * (dHp / (kH * SH))
  );
  
  return isNaN(dE) ? 100 : dE;
}

// ==========================================
// CONVERSION RGB VERS LAB
// ==========================================
function rgbToLab(r, g, b) {
  let rr = r / 255, gg = g / 255, bb = b / 255;
  
  rr = rr > 0.04045 ? Math.pow((rr + 0.055) / 1.055, 2.4) : rr / 12.92;
  gg = gg > 0.04045 ? Math.pow((gg + 0.055) / 1.055, 2.4) : gg / 12.92;
  bb = bb > 0.04045 ? Math.pow((bb + 0.055) / 1.055, 2.4) : bb / 12.92;
  
  rr *= 100; gg *= 100; bb *= 100;
  
  const x = rr * 0.4124564 + gg * 0.3575761 + bb * 0.1804375;
  const y = rr * 0.2126729 + gg * 0.7151522 + bb * 0.0721750;
  const z = rr * 0.0193339 + gg * 0.1191920 + bb * 0.9503041;
  
  let xx = x / 95.047, yy = y / 100.000, zz = z / 108.883;
  
  xx = xx > 0.008856 ? Math.pow(xx, 1/3) : (7.787 * xx) + 16/116;
  yy = yy > 0.008856 ? Math.pow(yy, 1/3) : (7.787 * yy) + 16/116;
  zz = zz > 0.008856 ? Math.pow(zz, 1/3) : (7.787 * zz) + 16/116;
  
  return [(116 * yy) - 16, 500 * (xx - yy), 200 * (yy - zz)];
}

// ==========================================
// HEX <-> RGB
// ==========================================
function hexToRgb(hex) {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result ? {
    r: parseInt(result[1], 16),
    g: parseInt(result[2], 16),
    b: parseInt(result[3], 16)
  } : { r: 0, g: 0, b: 0 };
}

function rgbToHex(r, g, b) {
  return '#' + [r, g, b].map(x => Math.max(0, Math.min(255, Math.round(x))).toString(16).padStart(2, '0')).join('');
}

// ==========================================
// CACHE LAB POUR DMC
// ==========================================
let dmcLabCache = null;
function getDmcLabCache() {
  if (!dmcLabCache) {
    dmcLabCache = (DMC_LIBRARY || []).map(dmc => {
      const rgb = hexToRgb(dmc.hex);
      const lab = rgbToLab(rgb.r, rgb.g, rgb.b);
      // Calculer saturation pour identifier couleurs fortes
      const max = Math.max(rgb.r, rgb.g, rgb.b);
      const min = Math.min(rgb.r, rgb.g, rgb.b);
      const saturation = max === 0 ? 0 : (max - min) / max;
      const isStrong = saturation > 0.5 && max > 100;
      
      return {
        ...dmc,
        lab,
        saturation,
        isStrong,
        isRed: rgb.r > 150 && rgb.r > rgb.g * 1.5 && rgb.r > rgb.b * 1.5,
        isBlue: rgb.b > 150 && rgb.b > rgb.r * 1.3 && rgb.b > rgb.g * 1.3,
        isWhite: rgb.r > 230 && rgb.g > 230 && rgb.b > 230,
        isBlack: rgb.r < 40 && rgb.g < 40 && rgb.b < 40
      };
    });
  }
  return dmcLabCache;
}

// ==========================================
// TROUVER DMC LE PLUS PROCHE (DELTA-E 2000)
// ==========================================
function findClosestDMC(r, g, b) {
  const lab = rgbToLab(r, g, b);
  const dmcColors = getDmcLabCache();
  
  let closest = dmcColors[0] || { code: '310', hex: '#000000', name: 'Noir' };
  let minDelta = Infinity;
  
  for (const dmc of dmcColors) {
    const delta = deltaE2000(lab, dmc.lab);
    if (delta < minDelta) {
      minDelta = delta;
      closest = dmc;
    }
  }
  
  return { ...closest, deltaE: minDelta };
}

// ==========================================
// UTILITAIRE : DÉTERMINER SI COULEUR CLAIRE
// ==========================================
function isLightColor(hex) {
  const rgb = hexToRgb(hex);
  const luminance = (0.299 * rgb.r + 0.587 * rgb.g + 0.114 * rgb.b) / 255;
  return luminance > 0.5;
}

// ==========================================
// MODES DE FOND
// ==========================================
const BACKGROUND_MODES = {
  FILLED: {
    id: 'filled',
    name: 'Fond brodé',
    description: 'Toutes les cases sont remplies avec une couleur DMC'
  },
  TRANSPARENT: {
    id: 'transparent',
    name: 'Fond transparent',
    description: 'Les zones de fond restent vides (non brodées)'
  }
};

// ==========================================
// MODES DE COULEUR
// ==========================================
const COLOR_MODES = {
  PRECISION: {
    id: 'precision',
    name: 'PRÉCISION',
    icon: '🔴',
    description: 'Jusqu\'à 120 couleurs DMC • Toutes les nuances conservées',
    maxColors: 120,
    minColors: 40
  },
  ESSENTIEL: {
    id: 'essentiel',
    name: 'ESSENTIEL',
    icon: '🟠',
    description: 'Palette simplifiée • Couleurs fortes préservées',
    maxColors: 40,
    minColors: 20
  },
  DUO: {
    id: 'duo',
    name: 'DUO',
    icon: '🟡',
    description: 'Les deux versions • Basculez entre détail et simplicité',
    maxColors: 120,
    minColors: 20
  }
};

// ==========================================
// COMPOSANT PRINCIPAL
// ==========================================
export default function ImageImportPro({ open, onClose, onComplete }) {
  // États initialisés
  const [step, setStep] = useState(1);
  const [sourceType, setSourceType] = useState(null); // 'file' | 'url'
  const [file, setFile] = useState(null);
  const [imageUrl, setImageUrl] = useState('');
  const [previewUrl, setPreviewUrl] = useState(null);
  const [originalDimensions, setOriginalDimensions] = useState({ width: 0, height: 0 });
  const [calculatedGrid, setCalculatedGrid] = useState({ width: 200, height: 200 });
  const [detailLevel, setDetailLevel] = useState(50); // 0-100 slider
  const [colorMode, setColorMode] = useState('precision');
  const [backgroundMode, setBackgroundMode] = useState('filled'); // 'filled' ou 'transparent'
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [progressMessage, setProgressMessage] = useState('');
  
  // Palettes
  const [fullPalette, setFullPalette] = useState([]); // Palette PRÉCISION complète
  const [essentialPalette, setEssentialPalette] = useState([]); // Palette ESSENTIEL
  const [currentPalette, setCurrentPalette] = useState([]); // Palette affichée
  const [showAllColors, setShowAllColors] = useState(false);
  const [viewMode, setViewMode] = useState('precision'); // Pour mode DUO
  
  // Pattern généré
  const [generatedPattern, setGeneratedPattern] = useState(null);
  const [symbolGrid, setSymbolGrid] = useState([]);
  
  // Couleurs protégées (ne pas fusionner)
  const [protectedColors, setProtectedColors] = useState(new Set());
  
  const imageInputRef = useRef(null);

  // Reset au open
  useEffect(() => {
    if (open) {
      setStep(1);
      setSourceType(null);
      setFile(null);
      setImageUrl('');
      setPreviewUrl(null);
      setOriginalDimensions({ width: 0, height: 0 });
      setCalculatedGrid({ width: 200, height: 200 });
      setDetailLevel(50);
      setColorMode('precision');
      setBackgroundMode('filled');
      setIsProcessing(false);
      setProgress(0);
      setProgressMessage('');
      setFullPalette([]);
      setEssentialPalette([]);
      setCurrentPalette([]);
      setShowAllColors(false);
      setViewMode('precision');
      setGeneratedPattern(null);
      setSymbolGrid([]);
      setProtectedColors(new Set());
    }
  }, [open]);

  // ==========================================
  // GESTION FICHIER IMAGE
  // ==========================================
  const handleImageSelect = async (e) => {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;

    const validTypes = ['image/png', 'image/jpeg', 'image/jpg', 'image/gif', 'image/webp'];
    if (!validTypes.includes(selectedFile.type)) {
      toast.error('Format non supporté. Utilisez PNG ou JPG.');
      return;
    }

    setFile(selectedFile);
    setSourceType('file');
    
    const url = URL.createObjectURL(selectedFile);
    loadImageFromUrl(url);
  };

  // ==========================================
  // GESTION URL IMAGE
  // ==========================================
  const handleUrlSubmit = async () => {
    if (!imageUrl.trim()) {
      toast.error('Veuillez entrer une URL');
      return;
    }

    try {
      setSourceType('url');
      // Tenter de charger l'image depuis l'URL
      loadImageFromUrl(imageUrl);
    } catch (error) {
      toast.error('Impossible de charger cette image');
    }
  };

  // ==========================================
  // CHARGER IMAGE DEPUIS URL
  // ==========================================
  const loadImageFromUrl = (url) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    
    img.onload = () => {
      const origW = img.width;
      const origH = img.height;
      setOriginalDimensions({ width: origW, height: origH });
      setPreviewUrl(url);
      
      // Calcul grille optimale (largeur/4, min 150, max 400)
      calculateOptimalGrid(origW, origH, detailLevel);
      setStep(2);
    };
    
    img.onerror = () => {
      toast.error('Impossible de charger cette image');
    };
    
    img.src = url;
  };

  // ==========================================
  // CALCUL GRILLE OPTIMALE
  // ==========================================
  const calculateOptimalGrid = (origW, origH, level) => {
    // Level 0 = moins de détails, level 100 = plus de détails
    const factor = 2 + (level / 100) * 4; // 2 à 6
    
    let gridW = Math.round(origW / factor);
    let gridH = Math.round(origH / factor);
    
    // Contraintes : min 150, max 400 sur le grand côté
    const maxSide = Math.max(gridW, gridH);
    const minSide = Math.min(gridW, gridH);
    
    if (maxSide > 400) {
      const ratio = 400 / maxSide;
      gridW = Math.round(gridW * ratio);
      gridH = Math.round(gridH * ratio);
    }
    
    if (maxSide < 150) {
      const ratio = 150 / maxSide;
      gridW = Math.round(gridW * ratio);
      gridH = Math.round(gridH * ratio);
    }
    
    // Min 100 sur le petit côté
    if (minSide < 100) {
      const ratio = 100 / minSide;
      gridW = Math.round(gridW * ratio);
      gridH = Math.round(gridH * ratio);
    }
    
    setCalculatedGrid({ width: gridW, height: gridH });
  };

  // Mise à jour grille quand slider change
  useEffect(() => {
    if (originalDimensions.width > 0) {
      calculateOptimalGrid(originalDimensions.width, originalDimensions.height, detailLevel);
    }
  }, [detailLevel, originalDimensions]);

  // ==========================================
  // CONVERSION PRO (COEUR DU MODULE)
  // ==========================================
  const processImagePro = async () => {
    if (!previewUrl) return;
    
    setIsProcessing(true);
    setProgress(0);
    setProgressMessage('Chargement de l\'image...');

    try {
      // Charger l'image
      const img = new Image();
      img.crossOrigin = 'anonymous';
      await new Promise((resolve, reject) => {
        img.onload = resolve;
        img.onerror = reject;
        img.src = previewUrl;
      });

      const { width, height } = calculatedGrid;
      setProgressMessage(`Création de la grille ${width}×${height}...`);
      
      // Canvas à la taille de la grille
      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = 'high';
      ctx.drawImage(img, 0, 0, width, height);
      
      const imageData = ctx.getImageData(0, 0, width, height);
      const sourceImage = canvas.toDataURL('image/png');

      setProgressMessage('Analyse pixel par pixel avec Delta-E 2000...');

      // ==========================================
      // ANALYSE PIXEL PAR PIXEL
      // ==========================================
      const colorMap = new Map(); // dmcCode -> { dmc, count, originalColors }
      const grid = [];
      const totalPixels = width * height;
      let processedPixels = 0;
      
      for (let row = 0; row < height; row++) {
        const gridRow = [];
        
        for (let col = 0; col < width; col++) {
          const idx = (row * width + col) * 4;
          const r = imageData.data[idx];
          const g = imageData.data[idx + 1];
          const b = imageData.data[idx + 2];
          
          // Trouver DMC le plus proche avec Delta-E 2000
          const dmc = findClosestDMC(r, g, b);
          
          // Ajouter à la map
          if (!colorMap.has(dmc.code)) {
            colorMap.set(dmc.code, {
              dmc,
              count: 0,
              originalColors: new Set()
            });
          }
          const entry = colorMap.get(dmc.code);
          entry.count++;
          entry.originalColors.add(rgbToHex(r, g, b));
          
          gridRow.push({
            colorId: `dmc-${dmc.code}`,
            dmcCode: dmc.code,
            type: 'S1',
            done: false
          });
          
          processedPixels++;
        }
        
        grid.push(gridRow);
        
        // Mise à jour progression tous les 5 rangs
        if (row % 5 === 0) {
          const pct = Math.round((processedPixels / totalPixels) * 80);
          setProgress(pct);
          await new Promise(r => setTimeout(r, 0));
        }
      }

      setSymbolGrid(grid);
      setProgress(85);
      setProgressMessage('Génération de la palette DMC...');

      // ==========================================
      // CRÉER PALETTE COMPLÈTE (PRÉCISION)
      // ==========================================
      const sortedColors = Array.from(colorMap.entries())
        .sort((a, b) => b[1].count - a[1].count);
      
      // Palette PRÉCISION : jusqu'à 120 couleurs, minimum 30
      const maxPrecision = Math.min(sortedColors.length, 120);
      const precisionPalette = sortedColors.slice(0, maxPrecision).map(([code, data], idx) => ({
        id: `dmc-${code}`,
        hex: data.dmc.hex,
        dmc: code,
        dmcName: data.dmc.name || code,
        dmcHex: data.dmc.hex,
        code: `DMC-${code}`,
        name: data.dmc.name || `DMC ${code}`,
        symbol: SYMBOLS[idx % SYMBOLS.length],
        assignedSymbolChar: SYMBOLS[idx % SYMBOLS.length],
        count: data.count,
        totalCount: data.count,
        deltaE: data.dmc.deltaE,
        originalColors: Array.from(data.originalColors).slice(0, 5),
        isStrong: data.dmc.isStrong,
        isRed: data.dmc.isRed,
        isBlue: data.dmc.isBlue,
        isWhite: data.dmc.isWhite,
        isBlack: data.dmc.isBlack,
        protected: data.dmc.isRed || data.dmc.isBlue || data.dmc.isWhite || data.dmc.isBlack
      }));

      setFullPalette(precisionPalette);

      setProgress(90);
      setProgressMessage('Création de la palette ESSENTIEL...');

      // ==========================================
      // CRÉER PALETTE ESSENTIEL (SIMPLIFIÉE)
      // ==========================================
      const essentialColors = createEssentialPalette(precisionPalette, 30);
      setEssentialPalette(essentialColors);

      setProgress(92);
      setProgressMessage('Post-traitement du fond...');

      // ==========================================
      // POST-TRAITEMENT DU FOND
      // ==========================================
      const processedGrid = postProcessGridBackground(grid, precisionPalette, backgroundMode);
      setSymbolGrid(processedGrid);

      setProgress(95);

      // Définir palette courante selon mode
      if (colorMode === 'precision' || colorMode === 'duo') {
        setCurrentPalette(precisionPalette);
        setViewMode('precision');
      } else {
        setCurrentPalette(essentialColors);
        setViewMode('essentiel');
      }

      // Protéger les couleurs fortes par défaut
      const protectedSet = new Set();
      precisionPalette.forEach(c => {
        if (c.isRed || c.isBlue || c.isWhite || c.isBlack) {
          protectedSet.add(c.id);
        }
      });
      setProtectedColors(protectedSet);

      setProgress(100);
      setProgressMessage('Terminé !');

      // Créer pattern avec grille post-traitée
      const pattern = {
        width,
        height,
        sourceImage,
        colorPalette: precisionPalette,
        symbolGrid: processedGrid,
        offsetCol: 0,
        offsetRow: 0
      };

      setGeneratedPattern(pattern);
      setStep(3);

    } catch (error) {
      console.error('Erreur:', error);
      toast.error('Erreur lors de la conversion : ' + error.message);
    } finally {
      setIsProcessing(false);
    }
  };

  // ==========================================
  // POST-TRAITEMENT DU FOND
  // ==========================================
  const postProcessGridBackground = (grid, palette, mode) => {
    if (!grid || !Array.isArray(grid)) return grid;

    if (mode === 'transparent') {
      // Laisser les cases vides telles quelles
      return grid;
    }

    // Mode "filled" : détecter la couleur dominante de fond
    const backgroundColorDMC = detectDominantBackgroundColorDMC(grid, palette);

    // Parcourir toute la grille et remplir les cases vides
    return grid.map(row =>
      row.map(cell => {
        if (!cell || !cell.colorId || !cell.dmcCode) {
          return {
            colorId: backgroundColorDMC.colorId,
            dmcCode: backgroundColorDMC.dmcCode,
            type: 'S1',
            done: false,
            isBackground: true
          };
        }
        return cell;
      })
    );
  };

  // ==========================================
  // DÉTECTER COULEUR DOMINANTE DE FOND
  // ==========================================
  const detectDominantBackgroundColorDMC = (grid, palette) => {
    const count = {};

    grid.forEach(row => {
      row.forEach(cell => {
        if (!cell || !cell.dmcCode) return;
        const code = cell.dmcCode;
        count[code] = (count[code] || 0) + 1;
      });
    });

    // Trouver la couleur la plus fréquente
    let dominant = null;
    let max = 0;
    Object.keys(count).forEach(code => {
      if (count[code] > max) {
        max = count[code];
        dominant = code;
      }
    });

    // Si rien trouvé, prendre blanc/écru ou première couleur
    if (!dominant && palette.length > 0) {
      const white = palette.find(c => 
        c.dmc === 'B5200' || c.dmc === 'BLANC' || c.dmc === 'ECRU' ||
        c.isWhite
      );
      if (white) {
        return { colorId: white.id, dmcCode: white.dmc };
      }
      return { colorId: palette[0].id, dmcCode: palette[0].dmc };
    }

    return { colorId: `dmc-${dominant}`, dmcCode: dominant };
  };

  // ==========================================
  // ASSURER SYMBOLES POUR PALETTE
  // ==========================================
  const ensureSymbolsForPalette = (palette) => {
    return palette.map((color, index) => ({
      ...color,
      symbol: color.symbol || SYMBOLS[index % SYMBOLS.length],
      assignedSymbolChar: color.assignedSymbolChar || SYMBOLS[index % SYMBOLS.length]
    }));
  };

  // ==========================================
  // CRÉER PALETTE ESSENTIEL
  // ==========================================
  const createEssentialPalette = (fullPalette, targetCount) => {
    if (fullPalette.length <= targetCount) return [...fullPalette];

    // Toujours garder les couleurs fortes (rouge, bleu, noir, blanc)
    const strongColors = fullPalette.filter(c => c.isRed || c.isBlue || c.isWhite || c.isBlack);
    const normalColors = fullPalette.filter(c => !c.isRed && !c.isBlue && !c.isWhite && !c.isBlack);
    
    // Trier par nombre de points
    normalColors.sort((a, b) => b.count - a.count);
    
    // Prendre les couleurs fortes + les plus utilisées
    const remaining = targetCount - strongColors.length;
    const selectedNormal = normalColors.slice(0, Math.max(0, remaining));
    
    const result = [...strongColors, ...selectedNormal];
    
    // Réassigner les symboles
    return result.map((c, idx) => ({
      ...c,
      symbol: SYMBOLS[idx % SYMBOLS.length],
      assignedSymbolChar: SYMBOLS[idx % SYMBOLS.length]
    }));
  };

  // ==========================================
  // RÉDUIRE LES COULEURS
  // ==========================================
  const reduceColors = (targetCount) => {
    if (fullPalette.length === 0) return;
    
    const reduced = createEssentialPalette(fullPalette, targetCount);
    setCurrentPalette(reduced);
    toast.success(`Palette réduite à ${reduced.length} couleurs`);
  };

  // ==========================================
  // RÉTABLIR TOUTES LES COULEURS
  // ==========================================
  const restoreAllColors = () => {
    setCurrentPalette([...fullPalette]);
    setViewMode('precision');
    toast.success('Palette complète restaurée');
  };

  // ==========================================
  // FUSIONNER COULEURS PROCHES
  // ==========================================
  const mergeCloseColors = () => {
    if (currentPalette.length === 0) return;

    const dmcCache = getDmcLabCache();
    const merged = [];
    const processed = new Set();

    for (const color of currentPalette) {
      if (processed.has(color.id)) continue;
      if (protectedColors.has(color.id)) {
        merged.push(color);
        processed.add(color.id);
        continue;
      }

      // Trouver couleurs proches (deltaE < 5)
      const similar = currentPalette.filter(c => {
        if (c.id === color.id || processed.has(c.id) || protectedColors.has(c.id)) return false;
        
        const rgb1 = hexToRgb(color.hex);
        const rgb2 = hexToRgb(c.hex);
        const lab1 = rgbToLab(rgb1.r, rgb1.g, rgb1.b);
        const lab2 = rgbToLab(rgb2.r, rgb2.g, rgb2.b);
        const delta = deltaE2000(lab1, lab2);
        
        return delta < 5;
      });

      if (similar.length > 0) {
        // Fusionner avec la couleur la plus utilisée
        let totalCount = color.count;
        similar.forEach(s => {
          totalCount += s.count;
          processed.add(s.id);
        });

        merged.push({
          ...color,
          count: totalCount,
          totalCount: totalCount
        });
      } else {
        merged.push(color);
      }
      processed.add(color.id);
    }

    // Réassigner symboles
    const final = merged.map((c, idx) => ({
      ...c,
      symbol: SYMBOLS[idx % SYMBOLS.length],
      assignedSymbolChar: SYMBOLS[idx % SYMBOLS.length]
    }));

    setCurrentPalette(final);
    toast.success(`${currentPalette.length - final.length} couleurs fusionnées`);
  };

  // ==========================================
  // PROTÉGER/DÉPROTÉGER COULEUR
  // ==========================================
  const toggleProtection = (colorId) => {
    const newSet = new Set(protectedColors);
    if (newSet.has(colorId)) {
      newSet.delete(colorId);
    } else {
      newSet.add(colorId);
    }
    setProtectedColors(newSet);
  };

  // ==========================================
  // PROTÉGER COULEURS FORTES
  // ==========================================
  const protectStrongColors = () => {
    const newSet = new Set(protectedColors);
    currentPalette.forEach(c => {
      if (c.isRed || c.isBlue || c.isWhite || c.isBlack || c.isStrong) {
        newSet.add(c.id);
      }
    });
    setProtectedColors(newSet);
    toast.success('Couleurs fortes protégées');
  };

  // ==========================================
  // BASCULER ENTRE PRÉCISION ET ESSENTIEL (MODE DUO)
  // ==========================================
  const toggleViewMode = () => {
    if (viewMode === 'precision') {
      setCurrentPalette(essentialPalette);
      setViewMode('essentiel');
    } else {
      setCurrentPalette(fullPalette);
      setViewMode('precision');
    }
  };

  // ==========================================
  // CHARGER EN MÉMOIRE ET COMMENCER (SANS SAUVEGARDER)
  // ==========================================
  const loadPatternAndStart = () => {
    if (!generatedPattern) return;

    const projectName = file?.name?.replace(/\.[^/.]+$/, '') || 'Projet en cours';
    
    // Mettre à jour le pattern avec la palette courante
    const finalPattern = {
      ...generatedPattern,
      colorPalette: currentPalette,
      name: projectName
    };

    // Passer le pattern au GridEditor (chargement en mémoire uniquement)
    // PAS de sauvegarde en base de données ici
    onComplete?.(finalPattern);
    onClose();
    
    toast.success(`Grille chargée • ${currentPalette.length} couleurs DMC`);
  };

  if (!open) return null;

  // ==========================================
  // RENDU
  // ==========================================
  return (
    <div className="fixed inset-0 flex items-center justify-center" style={{ zIndex: 999999, backgroundColor: 'rgba(0,0,0,0.9)' }}>
      <div className="bg-white rounded-2xl shadow-2xl w-[800px] max-h-[90vh] overflow-hidden">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-indigo-600 to-purple-600 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center">
              <Sparkles className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white">Smart Import V3</h2>
              <p className="text-sm text-white/80">PNG / JPEG • Palette DMC complète • Delta-E 2000</p>
            </div>
          </div>
          <button onClick={onClose} className="w-10 h-10 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center">
            <X className="w-6 h-6 text-white" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto" style={{ maxHeight: 'calc(90vh - 80px)' }}>
          
          {/* ==========================================
              ÉTAPE 1 : SÉLECTION SOURCE
          ========================================== */}
          {step === 1 && (
            <div className="space-y-6">
              {/* Option Fichier unique */}
              <button
                onClick={() => imageInputRef.current?.click()}
                className="w-full flex flex-col items-center gap-4 p-10 border-2 border-dashed border-gray-300 rounded-xl hover:border-indigo-500 hover:bg-indigo-50 transition-all"
              >
                <div className="w-20 h-20 rounded-2xl bg-indigo-100 flex items-center justify-center">
                  <Upload className="w-10 h-10 text-indigo-600" />
                </div>
                <span className="font-semibold text-xl">Importer une image</span>
                <span className="text-sm text-gray-500">PNG, JPG depuis votre appareil</span>
              </button>

              {/* Info PRO */}
              <div className="bg-gradient-to-r from-indigo-50 to-purple-50 border border-indigo-200 rounded-xl p-5">
                <h4 className="font-bold text-indigo-800 mb-3 flex items-center gap-2">
                  <Sparkles className="w-5 h-5" />
                  Smart Import V3 - Mode PRO
                </h4>
                <ul className="text-sm text-indigo-700 space-y-2">
                  <li className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-green-600" />
                    Image originale sans compression
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-green-600" />
                    Grille optimale 150×150 à 400×400 points
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-green-600" />
                    Analyse pixel par pixel avec Delta-E 2000
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-green-600" />
                    Palette DMC complète (30-120 couleurs)
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-green-600" />
                    Modes PRÉCISION, ESSENTIEL ou DUO
                  </li>
                </ul>
              </div>

              <input 
                ref={imageInputRef} 
                type="file" 
                accept="image/png,image/jpeg,image/jpg" 
                onChange={handleImageSelect} 
                className="hidden" 
              />
            </div>
          )}

          {/* ==========================================
              ÉTAPE 2 : CONFIGURATION
          ========================================== */}
          {step === 2 && !isProcessing && (
            <div className="space-y-6">
              {/* Aperçu + Infos */}
              <div className="flex gap-6">
                <div className="flex-shrink-0">
                  {previewUrl && (
                    <img 
                      src={previewUrl} 
                      alt="Aperçu" 
                      className="w-48 h-48 object-contain rounded-xl border-2 border-gray-200 shadow-lg bg-gray-100" 
                    />
                  )}
                </div>
                <div className="flex-1 space-y-4">
                  <div>
                    <p className="font-semibold text-lg">{file?.name || 'Image importée'}</p>
                    <p className="text-sm text-gray-500">
                      Image originale : {originalDimensions.width} × {originalDimensions.height} px
                    </p>
                  </div>
                  
                  {/* Grille calculée */}
                  <div className="bg-indigo-50 rounded-xl p-4">
                    <p className="text-sm text-indigo-600 mb-1 font-medium">Grille calculée</p>
                    <p className="text-2xl font-bold text-indigo-700">
                      {calculatedGrid.width} × {calculatedGrid.height} points
                    </p>
                    <p className="text-xs text-indigo-500 mt-1">
                      {(calculatedGrid.width * calculatedGrid.height).toLocaleString()} points au total
                    </p>
                  </div>
                </div>
              </div>

              {/* Slider niveau de détails */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label className="font-medium">Niveau de détails</Label>
                  <span className="text-sm text-gray-500">
                    {detailLevel < 30 ? 'Bas' : detailLevel < 70 ? 'Moyen' : 'Élevé'}
                  </span>
                </div>
                <Slider
                  value={[detailLevel]}
                  onValueChange={([val]) => setDetailLevel(val)}
                  min={0}
                  max={100}
                  step={5}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-gray-400">
                  <span>Moins de détails</span>
                  <span>Plus de détails</span>
                </div>
              </div>

              {/* Sélection mode couleur */}
              <div className="space-y-3">
                <Label className="font-medium">Mode de couleur</Label>
                <div className="grid grid-cols-3 gap-3">
                  {Object.values(COLOR_MODES).map(mode => (
                    <button
                      key={mode.id}
                      onClick={() => setColorMode(mode.id)}
                      className={`p-4 rounded-xl border-2 text-left transition-all ${
                        colorMode === mode.id 
                          ? 'border-indigo-500 bg-indigo-50' 
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xl">{mode.icon}</span>
                        <span className="font-bold">{mode.name}</span>
                      </div>
                      <p className="text-xs text-gray-600">{mode.description}</p>
                    </button>
                  ))}
                </div>
              </div>

              {/* Mode de fond */}
              <div className="space-y-3">
                <Label className="font-medium">Mode de fond</Label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={() => setBackgroundMode('filled')}
                    className={`p-3 rounded-xl border-2 text-left transition-all ${
                      backgroundMode === 'filled' 
                        ? 'border-indigo-500 bg-indigo-50' 
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded bg-amber-100 border border-amber-300" />
                      <span className="font-medium">Fond brodé</span>
                    </div>
                    <p className="text-xs text-gray-500 mt-1">Toutes les cases sont remplies</p>
                  </button>
                  <button
                    onClick={() => setBackgroundMode('transparent')}
                    className={`p-3 rounded-xl border-2 text-left transition-all ${
                      backgroundMode === 'transparent' 
                        ? 'border-indigo-500 bg-indigo-50' 
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded bg-white border border-gray-300" style={{ 
                        backgroundImage: 'linear-gradient(45deg, #ddd 25%, transparent 25%), linear-gradient(-45deg, #ddd 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #ddd 75%), linear-gradient(-45deg, transparent 75%, #ddd 75%)',
                        backgroundSize: '8px 8px',
                        backgroundPosition: '0 0, 0 4px, 4px -4px, -4px 0px'
                      }} />
                      <span className="font-medium">Fond transparent</span>
                    </div>
                    <p className="text-xs text-gray-500 mt-1">Les zones de fond restent vides</p>
                  </button>
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-3 pt-4">
                <Button variant="outline" onClick={() => setStep(1)} className="flex-1">
                  ← Changer d'image
                </Button>
                <Button onClick={processImagePro} className="flex-1 bg-indigo-600 hover:bg-indigo-700">
                  <Zap className="w-4 h-4 mr-2" />
                  Générer la grille
                </Button>
              </div>
            </div>
          )}

          {/* ==========================================
              PROGRESSION
          ========================================== */}
          {isProcessing && (
            <div className="text-center py-16 space-y-6">
              <div className="relative w-24 h-24 mx-auto">
                <Loader2 className="w-24 h-24 animate-spin text-indigo-500" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-lg font-bold text-indigo-600">{progress}%</span>
                </div>
              </div>
              <div>
                <p className="text-xl font-semibold text-gray-800">{progressMessage}</p>
                <p className="text-sm text-gray-500 mt-2">
                  Grille {calculatedGrid.width}×{calculatedGrid.height} • Analyse Delta-E 2000
                </p>
              </div>
              <div className="w-full max-w-md mx-auto bg-gray-200 rounded-full h-3">
                <div 
                  className="bg-gradient-to-r from-indigo-500 to-purple-500 h-3 rounded-full transition-all duration-300"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          )}

          {/* ==========================================
              ÉTAPE 3 : PALETTE GÉNÉRÉE
          ========================================== */}
          {step === 3 && !isProcessing && currentPalette.length > 0 && (
            <div className="space-y-6">
              {/* Header palette */}
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-xl flex items-center gap-2">
                    <Palette className="w-6 h-6 text-indigo-600" />
                    Palette DMC
                  </h3>
                  <p className="text-sm text-gray-500">
                    {currentPalette.length} couleurs • Mode {viewMode === 'precision' ? 'PRÉCISION' : 'ESSENTIEL'}
                  </p>
                </div>
                
                {/* Toggle mode DUO */}
                {colorMode === 'duo' && (
                  <Button 
                    variant="outline" 
                    onClick={toggleViewMode}
                    className="gap-2"
                  >
                    {viewMode === 'precision' ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                    {viewMode === 'precision' ? 'Version détaillée' : 'Version simplifiée'}
                  </Button>
                )}
              </div>

              {/* Boutons d'action */}
              <div className="flex flex-wrap gap-2">
                <Button variant="outline" size="sm" onClick={() => reduceColors(15)}>
                  15 couleurs
                </Button>
                <Button variant="outline" size="sm" onClick={() => reduceColors(25)}>
                  25 couleurs
                </Button>
                <Button variant="outline" size="sm" onClick={() => reduceColors(35)}>
                  35 couleurs
                </Button>
                <Button variant="outline" size="sm" onClick={() => reduceColors(50)}>
                  50 couleurs
                </Button>
                <div className="w-px h-8 bg-gray-300 mx-1" />
                <Button variant="outline" size="sm" onClick={restoreAllColors}>
                  <RotateCcw className="w-3 h-3 mr-1" />
                  Rétablir tout
                </Button>
                <Button variant="outline" size="sm" onClick={mergeCloseColors}>
                  <Merge className="w-3 h-3 mr-1" />
                  Fusionner proches
                </Button>
                <Button variant="outline" size="sm" onClick={protectStrongColors}>
                  <Shield className="w-3 h-3 mr-1" />
                  Protéger couleurs fortes
                </Button>
              </div>

              {/* Grille de couleurs */}
              <div className="border rounded-xl p-4 max-h-96 overflow-y-auto bg-gray-50">
                <div className="grid grid-cols-8 gap-2">
                  {(showAllColors ? currentPalette : currentPalette.slice(0, 32)).map((color, idx) => (
                    <div 
                      key={color.id}
                      className={`relative group cursor-pointer ${protectedColors.has(color.id) ? 'ring-2 ring-amber-400' : ''}`}
                      onClick={() => toggleProtection(color.id)}
                    >
                      <div 
                        className="w-full aspect-square rounded-lg border-2 border-white shadow-md flex items-center justify-center text-base font-bold"
                        style={{ backgroundColor: color.hex }}
                      >
                        <span style={{ 
                          color: isLightColor(color.hex) ? '#000' : '#fff',
                          textShadow: isLightColor(color.hex) ? 'none' : '0 1px 2px rgba(0,0,0,0.5)'
                        }}>
                          {color.symbol}
                        </span>
                        {protectedColors.has(color.id) && (
                          <Shield className="absolute top-0.5 right-0.5 w-3 h-3 text-amber-500" />
                        )}
                      </div>
                      <div className="text-center mt-1">
                        <p className="text-[10px] font-bold">DMC {color.dmc}</p>
                        <p className="text-[9px] text-gray-500">{color.count.toLocaleString()} pts</p>
                      </div>
                      
                      {/* Tooltip */}
                      <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-gray-900 text-white text-[10px] rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none z-10">
                        {color.dmcName} • ΔE: {color.deltaE?.toFixed(1)}
                        {protectedColors.has(color.id) && ' • 🛡️ Protégée'}
                      </div>
                    </div>
                  ))}
                </div>
                
                {currentPalette.length > 32 && (
                  <button
                    onClick={() => setShowAllColors(!showAllColors)}
                    className="w-full mt-4 py-2 text-sm text-indigo-600 hover:bg-indigo-50 rounded-lg flex items-center justify-center gap-2"
                  >
                    {showAllColors ? (
                      <>Voir moins <ChevronUp className="w-4 h-4" /></>
                    ) : (
                      <>Voir les {currentPalette.length - 32} autres couleurs <ChevronDown className="w-4 h-4" /></>
                    )}
                  </button>
                )}
              </div>

              {/* Résumé */}
              <div className="bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-xl p-5 flex items-center gap-4">
                <div className="w-14 h-14 rounded-full bg-green-100 flex items-center justify-center">
                  <Check className="w-8 h-8 text-green-600" />
                </div>
                <div className="flex-1">
                  <p className="font-bold text-green-800 text-lg">Grille générée avec succès !</p>
                  <p className="text-sm text-green-700">
                    {calculatedGrid.width} × {calculatedGrid.height} points • {currentPalette.length} couleurs DMC
                  </p>
                </div>
              </div>

              {/* Bouton final - Chargement instantané */}
              <Button onClick={loadPatternAndStart} className="w-full h-12 text-lg bg-green-600 hover:bg-green-700">
                <Check className="w-5 h-5 mr-2" />
                Commencer à broder
              </Button>
              <p className="text-xs text-center text-gray-500 mt-2">
                Pensez à sauvegarder votre projet ensuite pour le retrouver dans "Mes projets"
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}