import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { 
  X, ChevronLeft, ChevronRight, Heart, 
  Zap, Target, Layers, PenTool, Sparkles
} from 'lucide-react';

const GUIDE_SECTIONS = [
  {
    id: 'intro',
    title: 'Bienvenue dans SUB',
    subtitle: 'Comprendre – Broder – Profiter',
    icon: Heart,
    color: 'from-yellow-400 to-orange-500',
    content: (
      <div className="space-y-4">
        <p className="text-lg text-center italic text-gray-700">
          "Vous brodez comme d'habitude.<br/>
          Nous, on s'occupe de rendre chaque point plus simple, plus solide et plus beau."
        </p>
        
        <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4">
          <p className="font-medium mb-2">SUB ne remplace pas la broderie traditionnelle.</p>
          <p className="text-sm text-gray-600">SUB ajoute des points utiles pour rendre la broderie :</p>
          <div className="grid grid-cols-2 gap-2 mt-3">
            {['✅ plus simple', '✅ plus solide', '✅ plus lisible', '✅ plus rapide'].map((item, i) => (
              <div key={i} className="text-sm font-medium">{item}</div>
            ))}
          </div>
        </div>
        
        <p className="text-sm text-center text-gray-500">
          Tous les points SUB se brodent avec une aiguille et du fil classiques 
          sur toute toile (Aïda, étamine, lin, Lugana, etc.).
        </p>
      </div>
    )
  },
  {
    id: 'lecointre',
    title: 'Point LECOINTRE',
    subtitle: 'Aussi appelé POINT LORRAIN',
    icon: Zap,
    color: 'from-blue-500 to-blue-600',
    content: (
      <div className="space-y-4">
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
          <h4 className="font-bold text-blue-800 mb-2">À quoi ça sert ?</h4>
          <ul className="text-sm space-y-1 text-blue-700">
            <li>👉 Renforcer un coin, un centre ou une jonction fragile.</li>
            <li>👉 Éviter que le fil se défasse.</li>
            <li>👉 Marquer un "départ" clair dans l'ouvrage.</li>
          </ul>
        </div>
        
        <div className="bg-white border rounded-xl p-4">
          <h4 className="font-bold mb-2">Comment le broder ?</h4>
          <ol className="text-sm space-y-1 text-gray-700">
            <li>1. Broder une croix normale (X).</li>
            <li>2. Ajouter une petite barre horizontale au centre de la croix (—).</li>
          </ol>
          <p className="mt-3 text-center text-3xl">✚</p>
          <p className="text-xs text-center text-gray-500">Visuellement une croix avec "double bras"</p>
        </div>
        
        <div className="bg-gray-50 rounded-xl p-4">
          <h4 className="font-bold mb-2">Quand l'utiliser ?</h4>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div>• Au centre de la grille</div>
            <div>• Aux angles d'un grand motif</div>
            <div>• Changement de couleur</div>
            <div>• Début ou fin d'un fil</div>
          </div>
        </div>
        
        <div className="flex gap-2 justify-center">
          <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm">✔ Plus solide</span>
          <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm">✔ Plus propre</span>
          <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm">✔ Fil sécurisé</span>
        </div>
      </div>
    )
  },
  {
    id: 'zero',
    title: 'Point ZERO',
    subtitle: 'Le repère intelligent',
    icon: Target,
    color: 'from-red-500 to-red-600',
    content: (
      <div className="space-y-4">
        <div className="bg-red-50 border border-red-200 rounded-xl p-4">
          <h4 className="font-bold text-red-800 mb-2">À quoi ça sert ?</h4>
          <p className="text-sm text-red-700">👉 Marquer un repère important :</p>
          <div className="grid grid-cols-2 gap-2 mt-2 text-sm text-red-700">
            <div>• centre du visage</div>
            <div>• œil</div>
            <div>• cœur</div>
            <div>• point d'alignement</div>
          </div>
        </div>
        
        <div className="bg-white border rounded-xl p-4">
          <h4 className="font-bold mb-2">Comment le broder ?</h4>
          <p className="text-sm text-gray-700">Un mini point (1/4 de croix) ou un petit point droit.</p>
          <p className="mt-3 text-center text-3xl">◎</p>
        </div>
        
        <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4">
          <h4 className="font-bold text-yellow-800 mb-2">Spécial SUB :</h4>
          <ul className="text-sm space-y-1 text-yellow-700">
            <li>🔹 Le point ZERO est un repère, pas un remplissage.</li>
            <li>🔹 On peut le maintenir ou l'enlever une fois le motif posé.</li>
          </ul>
        </div>
        
        <div className="flex gap-2 justify-center">
          <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm">✔ On ne se perd plus</span>
          <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm">✔ Centre toujours visible</span>
        </div>
      </div>
    )
  },
  {
    id: 'subfill',
    title: 'Point SUB FILL',
    subtitle: 'Le remplissage optimisé',
    icon: Layers,
    color: 'from-purple-500 to-purple-600',
    content: (
      <div className="space-y-4">
        <div className="bg-purple-50 border border-purple-200 rounded-xl p-4">
          <h4 className="font-bold text-purple-800 mb-2">À quoi ça sert ?</h4>
          <ul className="text-sm space-y-1 text-purple-700">
            <li>👉 Remplir une grande zone sans changer mille fois de fil.</li>
            <li>👉 Faire un fond régulier et lisse.</li>
          </ul>
        </div>
        
        <div className="bg-white border rounded-xl p-4">
          <h4 className="font-bold mb-2">Comment le broder ?</h4>
          <p className="text-sm text-gray-700">Une série de demi-points (////) réguliers dans la même direction.</p>
          <p className="mt-3 text-center text-3xl tracking-widest">////</p>
        </div>
        
        <div className="bg-gray-50 rounded-xl p-4">
          <h4 className="font-bold mb-2">Quand ?</h4>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div>• Ciel</div>
            <div>• Peau</div>
            <div>• Fond uniforme</div>
            <div>• Robes / tissus</div>
          </div>
        </div>
        
        <div className="flex gap-2 justify-center flex-wrap">
          <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm">✔ Plus rapide</span>
          <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm">✔ Moins fatigant</span>
          <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm">✔ Moins de nœuds</span>
        </div>
      </div>
    )
  },
  {
    id: 'subcontour',
    title: 'Point SUB CONTOUR',
    subtitle: 'Le contour simplifié',
    icon: PenTool,
    color: 'from-green-500 to-green-600',
    content: (
      <div className="space-y-4">
        <div className="bg-green-50 border border-green-200 rounded-xl p-4">
          <h4 className="font-bold text-green-800 mb-2">À quoi ça sert ?</h4>
          <ul className="text-sm space-y-1 text-green-700">
            <li>👉 Faire le tour d'un motif sans revenir en arrière.</li>
            <li>👉 Un contour net, visible et facile à suivre.</li>
          </ul>
        </div>
        
        <div className="bg-white border rounded-xl p-4">
          <h4 className="font-bold mb-2">Comment le broder ?</h4>
          <p className="text-sm text-gray-700">Comme un point arrière, mais en lignes droites simples.</p>
          <p className="mt-3 text-center text-3xl">━━━</p>
        </div>
        
        <div className="bg-gray-50 rounded-xl p-4">
          <h4 className="font-bold mb-2">Quand ?</h4>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div>• Silhouette</div>
            <div>• Profil du visage</div>
            <div>• Objets</div>
            <div>• Lettres</div>
          </div>
        </div>
        
        <div className="flex gap-2 justify-center">
          <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm">✔ Visibilité maxi</span>
          <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm">✔ Idéal débutantes</span>
        </div>
      </div>
    )
  },
  {
    id: 'repair',
    title: 'Réparation Automatique',
    subtitle: 'Plus jamais de trous',
    icon: Sparkles,
    color: 'from-yellow-500 to-orange-500',
    content: (
      <div className="space-y-4">
        <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4">
          <h4 className="font-bold text-yellow-800 mb-2">🧷 BONUS : LA RÉPARATION AUTOMATIQUE</h4>
          <p className="text-sm text-yellow-700">SUB comble automatiquement les trous dans les zones brodées.</p>
        </div>
        
        <div className="grid grid-cols-1 gap-3">
          <div className="bg-green-50 border border-green-200 rounded-lg p-3 flex items-center gap-3">
            <span className="text-2xl">✅</span>
            <span className="font-medium">Plus de cases oubliées</span>
          </div>
          <div className="bg-green-50 border border-green-200 rounded-lg p-3 flex items-center gap-3">
            <span className="text-2xl">✅</span>
            <span className="font-medium">Plus de "trous blancs" involontaires</span>
          </div>
          <div className="bg-green-50 border border-green-200 rounded-lg p-3 flex items-center gap-3">
            <span className="text-2xl">✅</span>
            <span className="font-medium">Plus de surprises à la fin</span>
          </div>
        </div>
        
        <div className="bg-gray-900 text-white rounded-xl p-4">
          <h4 className="font-bold mb-3">⭐ IMPORTANT</h4>
          <p className="text-sm mb-2">Ces points…</p>
          <ul className="text-sm space-y-1 text-gray-300">
            <li>✅ sont 100% compatibles avec tous les points connus</li>
            <li>✅ se brodent avec du fil DMC classique</li>
            <li>✅ ne changent pas vos habitudes</li>
            <li>✅ sont facultatifs mais très pratiques</li>
          </ul>
        </div>
        
        <div className="text-center p-4 bg-yellow-100 rounded-xl border-2 border-yellow-400">
          <p className="font-bold text-yellow-800">
            SUB, c'est :<br/>
            🟡 "La broderie comme avant, mais en plus intelligent."
          </p>
        </div>
      </div>
    )
  },
  {
    id: 'result',
    title: 'Résultat pour vous',
    subtitle: 'Les avantages SUB',
    icon: Heart,
    color: 'from-pink-500 to-rose-500',
    content: (
      <div className="space-y-4">
        <div className="text-center mb-4">
          <span className="text-5xl">🎯</span>
        </div>
        
        <div className="grid grid-cols-1 gap-3">
          {[
            { icon: '✔', text: 'Elle se perd moins' },
            { icon: '✔', text: 'Elle change moins de fil' },
            { icon: '✔', text: 'Son ouvrage tient mieux dans le temps' },
            { icon: '✔', text: 'Elle brode plus vite' },
            { icon: '✔', text: 'Elle gagne en précision' }
          ].map((item, i) => (
            <div key={i} className="bg-white border-2 border-gray-200 rounded-lg p-4 flex items-center gap-3">
              <span className="text-green-500 text-xl font-bold">{item.icon}</span>
              <span className="font-medium">{item.text}</span>
            </div>
          ))}
        </div>
        
        <div className="bg-gradient-to-r from-yellow-400 to-orange-500 rounded-xl p-6 text-center">
          <p className="text-black font-bold text-lg mb-2">❤️ Bienvenue dans SUB.</p>
          <p className="text-black/80">
            Vous brodez comme d'habitude.<br/>
            Nous, on s'occupe de rendre chaque point<br/>
            plus simple, plus solide et plus beau.
          </p>
        </div>
      </div>
    )
  }
];

export default function SubQuickGuide({ open, onClose }) {
  const [currentIndex, setCurrentIndex] = useState(0);

  const currentSection = GUIDE_SECTIONS[currentIndex];
  const SectionIcon = currentSection.icon;

  const goNext = () => {
    if (currentIndex < GUIDE_SECTIONS.length - 1) {
      setCurrentIndex(currentIndex + 1);
    }
  };

  const goPrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
    }
  };

  if (!open) return null;

  return (
    <div 
      className="fixed inset-0 flex items-center justify-center"
      style={{ zIndex: 999999, backgroundColor: 'rgba(0, 0, 0, 0.85)' }}
    >
      <div className="bg-white rounded-2xl shadow-2xl w-[600px] max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className={`bg-gradient-to-r ${currentSection.color} px-6 py-4 flex items-center justify-between`}>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-white/20 backdrop-blur flex items-center justify-center">
              <SectionIcon className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-black text-white">{currentSection.title}</h2>
              <p className="text-sm text-white/80">{currentSection.subtitle}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center"
          >
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        {/* Indicateur de progression */}
        <div className="px-6 py-3 bg-gray-50 border-b flex items-center justify-center gap-2">
          {GUIDE_SECTIONS.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentIndex(idx)}
              className={`w-2.5 h-2.5 rounded-full transition-all ${
                idx === currentIndex 
                  ? 'bg-gray-800 w-6' 
                  : idx < currentIndex 
                    ? 'bg-green-500' 
                    : 'bg-gray-300'
              }`}
            />
          ))}
        </div>

        {/* Contenu */}
        <div className="p-6 overflow-y-auto" style={{ maxHeight: 'calc(90vh - 220px)' }}>
          {currentSection.content}
        </div>

        {/* Footer Navigation */}
        <div className="px-6 py-4 border-t bg-gray-50 flex items-center justify-between">
          <Button
            variant="outline"
            onClick={goPrev}
            disabled={currentIndex === 0}
            className="gap-2"
          >
            <ChevronLeft className="w-4 h-4" />
            Précédent
          </Button>
          
          <span className="text-sm text-gray-500">
            {currentIndex + 1} / {GUIDE_SECTIONS.length}
          </span>
          
          {currentIndex === GUIDE_SECTIONS.length - 1 ? (
            <Button onClick={onClose} className="bg-black hover:bg-gray-800 gap-2">
              Commencer
              <Zap className="w-4 h-4" />
            </Button>
          ) : (
            <Button onClick={goNext} className="gap-2">
              Suivant
              <ChevronRight className="w-4 h-4" />
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}