import React, { useState, useRef, useMemo, useEffect } from 'react';
import { EyeOff, Check, RotateCcw, Wand2 } from 'lucide-react';
import { checkSymbolsStatus } from './symbolAssigner';

export default function DmcBottomPalette({
  colorPalette = [],
  selectedColorId,
  onColorSelect,
  onMarkAsStitched,
  onUnmarkAsStitched,
  pattern,
  onHoverColor,
  onIsolateColor,
  symbolSize = 'medium',
  onFixEmptySymbols,
}) {
  const scrollRef = useRef(null);
  const [activeColorId, setActiveColorId] = useState(null);
  const [hiddenColors, setHiddenColors] = useState(new Set());

  // Taille du symbole selon le réglage global
  const symbolFontSize = useMemo(() => {
    switch (symbolSize) {
      case 'small': return '11px';
      case 'large': return '15px';
      default: return '13px';
    }
  }, [symbolSize]);

  // Vérifier si des symboles sont manquants
  const symbolsStatus = useMemo(() => {
    return checkSymbolsStatus(colorPalette);
  }, [colorPalette]);

  // Calculer les statistiques pour chaque couleur
  const colorsWithStats = useMemo(() => {
    if (!pattern?.symbolGrid || !colorPalette.length) return colorPalette;
    
    return colorPalette.map(color => {
      let totalCount = 0;
      let doneCount = 0;
      
      pattern.symbolGrid.forEach(row => {
        row?.forEach(cell => {
          if (cell?.colorId === color.id) {
            totalCount++;
            if (cell.done) doneCount++;
          }
        });
      });
      
      return {
        ...color,
        totalCount,
        doneCount,
        progress: totalCount > 0 ? Math.round((doneCount / totalCount) * 100) : 0,
      };
    }).filter(c => c.totalCount > 0).sort((a, b) => b.totalCount - a.totalCount);
  }, [colorPalette, pattern]);

  // Scroll automatique vers la couleur active
  useEffect(() => {
    if (activeColorId && scrollRef.current) {
      const activeButton = scrollRef.current.querySelector(`[data-color-id="${activeColorId}"]`);
      if (activeButton) {
        activeButton.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
      }
    }
  }, [activeColorId]);

  const handleColorClick = (color) => {
    if (activeColorId === color.id) {
      // Toggle OFF
      setActiveColorId(null);
      onColorSelect?.(null);
      onHoverColor?.(null);
    } else {
      // Toggle ON
      setActiveColorId(color.id);
      onColorSelect?.(color.id);
      onHoverColor?.(color.id);
    }
  };

  // Actions du micro-menu
  const handleMaskOthers = (colorId) => {
    const newHidden = new Set(colorsWithStats.map(c => c.id).filter(id => id !== colorId));
    setHiddenColors(newHidden);
    onIsolateColor?.(colorId);
  };

  const handleMarkAsDone = (colorId) => {
    onMarkAsStitched?.(colorId);
  };

  const handleResetDisplay = () => {
    setHiddenColors(new Set());
    setActiveColorId(null);
    onHoverColor?.(null);
  };

  if (!colorPalette || colorPalette.length === 0) {
    return null;
  }

  const activeColor = colorsWithStats.find(c => c.id === activeColorId);

  return (
    <>
      {/* BOUTON ASSIGNER SYMBOLES MANQUANTS - Affiché si nécessaire */}
      {(symbolsStatus.hasMissing || symbolsStatus.hasDuplicates) && onFixEmptySymbols && (
        <div
          style={{
            position: 'fixed',
            bottom: '108px',
            left: '16px',
            zIndex: 10002,
          }}
        >
          <button
            onClick={onFixEmptySymbols}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              padding: '10px 16px',
              backgroundColor: '#FFC94A',
              color: '#000',
              border: 'none',
              borderRadius: '8px',
              fontSize: '13px',
              fontWeight: 600,
              cursor: 'pointer',
              boxShadow: '0 2px 8px rgba(0,0,0,0.15)',
              animation: 'pulse 2s infinite',
            }}
          >
            <Wand2 style={{ width: '16px', height: '16px' }} />
            Assigner symboles manquants ({symbolsStatus.missingCount + symbolsStatus.duplicateCount})
          </button>
          <style>{`
            @keyframes pulse {
              0%, 100% { transform: scale(1); }
              50% { transform: scale(1.02); }
            }
          `}</style>
        </div>
      )}

      {/* MICRO-MENU CONTEXTUEL */}
      {activeColor && (
        <div 
          style={{
            position: 'fixed',
            bottom: '105px',
            left: '50%',
            transform: 'translateX(-50%)',
            zIndex: 10001,
            display: 'flex',
            alignItems: 'center',
            gap: '0',
            backgroundColor: '#FFFFFF',
            boxShadow: '0 2px 12px rgba(0,0,0,0.15)',
          }}
        >
          {/* Masquer les autres */}
          <button
            onClick={() => handleMaskOthers(activeColor.id)}
            style={{
              width: '40px',
              height: '40px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              backgroundColor: hiddenColors.size > 0 ? '#000' : '#FFF',
              border: 'none',
              cursor: 'pointer',
            }}
            title="Masquer les autres couleurs"
          >
            <EyeOff style={{ width: '18px', height: '18px', color: hiddenColors.size > 0 ? '#FFF' : '#000' }} />
          </button>

          {/* Marquer comme brodé */}
          <button
            onClick={() => handleMarkAsDone(activeColor.id)}
            style={{
              width: '40px',
              height: '40px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              backgroundColor: activeColor.progress === 100 ? '#000' : '#FFF',
              border: 'none',
              cursor: 'pointer',
            }}
            title="Marquer comme brodé"
          >
            <Check style={{ width: '18px', height: '18px', color: activeColor.progress === 100 ? '#FFF' : '#000' }} />
          </button>

          {/* Réinitialiser */}
          <button
            onClick={handleResetDisplay}
            style={{
              width: '40px',
              height: '40px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              backgroundColor: '#FFF',
              border: 'none',
              cursor: 'pointer',
            }}
            title="Réinitialiser l'affichage"
          >
            <RotateCcw style={{ width: '18px', height: '18px', color: '#000' }} />
          </button>
        </div>
      )}

      {/* PALETTE BASSE - Bande continue sans fond */}
      <div 
        style={{
          position: 'fixed',
          left: 0,
          right: 0,
          bottom: 0,
          height: '100px',
          zIndex: 10000,
          display: 'flex',
          alignItems: 'stretch',
          overflow: 'hidden',
        }}
      >
        {/* Zone scrollable */}
        <div
          ref={scrollRef}
          style={{
            flex: 1,
            overflowX: 'auto',
            overflowY: 'hidden',
            scrollBehavior: 'smooth',
            scrollbarWidth: 'none',
            msOverflowStyle: 'none',
          }}
        >
          <div
            style={{
              display: 'flex',
              alignItems: 'stretch',
              height: '100%',
            }}
          >
            {colorsWithStats.map((color) => {
              const isActive = activeColorId === color.id;
              const isDone = color.progress === 100;
              const colorHex = color.hex || color.dmcHex || '#808080';
              const dmcCode = String(color.code || color.dmc || '???').replace(/DMC[-\s]?/gi, '');
              const symbol = color.assignedSymbolChar || '●';

              return (
                <button
                  key={color.id}
                  data-color-id={color.id}
                  onClick={() => handleColorClick(color)}
                  style={{
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'stretch',
                    width: '85px',
                    height: '100%',
                    padding: 0,
                    margin: 0,
                    border: 'none',
                    borderRadius: 0,
                    cursor: 'pointer',
                    flexShrink: 0,
                    position: 'relative',
                    outline: isActive ? '3px solid #000' : 'none',
                    outlineOffset: '-3px',
                    zIndex: isActive ? 10 : 1,
                    background: 'transparent',
                  }}
                >
                  {/* Bandeau blanc supérieur */}
                  <div
                    style={{
                      width: '100%',
                      height: '28px',
                      backgroundColor: '#FFFFFF',
                      borderBottom: '1px solid #d0d0d0',
                      display: 'flex',
                      flexDirection: 'column',
                      justifyContent: 'center',
                      padding: '2px 6px',
                    }}
                  >
                    {/* Ligne 1: Code DMC + Symbole */}
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <span style={{ 
                        fontSize: '12px', 
                        fontWeight: 700, 
                        color: '#000',
                        textDecoration: isDone ? 'line-through' : 'none',
                      }}>
                        {dmcCode}
                      </span>
                      <span style={{ 
                        fontSize: symbolFontSize, 
                        fontWeight: 700, 
                        color: '#000',
                        textDecoration: isDone ? 'line-through' : 'none',
                      }}>
                        {symbol}
                      </span>
                    </div>
                    {/* Ligne 2: Nombre de points */}
                    <span style={{ fontSize: '9px', color: '#888', marginTop: '-1px' }}>
                      {color.totalCount} pts
                    </span>
                  </div>

                  {/* Zone couleur DMC */}
                  <div
                    style={{
                      flex: 1,
                      backgroundColor: colorHex,
                      position: 'relative',
                    }}
                  >
                    {/* Halo intérieur si actif */}
                    {isActive && (
                      <div style={{
                        position: 'absolute',
                        inset: 0,
                        backgroundColor: 'rgba(255,255,255,0.25)',
                        pointerEvents: 'none',
                      }} />
                    )}

                    {/* Overlay si brodé */}
                    {isDone && (
                      <div style={{
                        position: 'absolute',
                        inset: 0,
                        backgroundColor: 'rgba(128,128,128,0.5)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}>
                        <Check style={{ width: '24px', height: '24px', color: '#FFF' }} />
                      </div>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </>
  );
}