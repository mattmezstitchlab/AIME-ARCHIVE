import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { base44 } from '@/api/base44Client';
import { Upload, Image as ImageIcon, Grid3x3, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

export default function ImportGridPageDialog({ open, onClose, onImportComplete }) {
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState(null);
  const [gridWidth, setGridWidth] = useState(100);
  const [gridHeight, setGridHeight] = useState(100);
  const [offsetCol, setOffsetCol] = useState('center');
  const [offsetRow, setOffsetRow] = useState('center');
  const [isUploading, setIsUploading] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [autoDetected, setAutoDetected] = useState(false);
  const [uploadedImageUrl, setUploadedImageUrl] = useState(null);
  const [detectedColors, setDetectedColors] = useState([]);

  const analyzeGrid = async (imageFile) => {
    setIsAnalyzing(true);
    setAutoDetected(false);
    
    try {
      // Upload de l'image pour l'analyse
      const { file_url } = await base44.integrations.Core.UploadFile({ file: imageFile });
      setUploadedImageUrl(file_url);
      
      // Analyse avec IA pour détecter dimensions et couleurs
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyse cette image de grille de point de croix et extrait:
        
1. Le nombre de colonnes (cases horizontales) de la grille visible
2. Le nombre de lignes (cases verticales) de la grille visible
3. Toutes les couleurs distinctes utilisées dans la grille

Instructions importantes:
- Compte précisément les cases de la grille
- Pour chaque couleur unique visible, fournis son code hexadécimal
- Identifie le symbole affiché dans chaque case colorée (×, ○, △, □, •, etc.)
- Si pas de symbole visible ou juste une couleur unie, laisse le champ symbol vide ""
- Retourne UNIQUEMENT un JSON valide, pas de markdown

Format de retour:
{
  "columns": <nombre>,
  "rows": <nombre>,
  "colors": [
    {"hex": "#E3242B", "symbol": "×"},
    {"hex": "#2E3192", "symbol": ""},
    ...
  ]
}`,
        file_urls: [file_url],
        response_json_schema: {
          type: "object",
          properties: {
            columns: { type: "integer" },
            rows: { type: "integer" },
            colors: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  hex: { type: "string" },
                  symbol: { type: "string" }
                }
              }
            }
          }
        }
      });
      
      // Symboles par défaut si l'IA n'en trouve pas
      const defaultSymbols = ['×', '○', '△', '□', '◇', '★', '▲', '■', '●', '◆', '▼', '▽', '◁', '▷', '♦', '♥', '♠', '♣', '⊕', '⊗'];
      
      const colors = (result.colors || []).map((color, index) => ({
        ...color,
        symbol: color.symbol || defaultSymbols[index % defaultSymbols.length]
      }));
      
      setGridWidth(result.columns);
      setGridHeight(result.rows);
      setDetectedColors(colors);
      // Centrer automatiquement l'image
      setOffsetCol('center');
      setOffsetRow('center');
      setAutoDetected(true);
      
      toast.success(`Grille détectée: ${result.columns}x${result.rows} cases, ${colors.length} couleurs`);
      
    } catch (error) {
      console.error('Erreur analyse:', error);
      toast.error('Impossible d\'analyser la grille automatiquement');
      
      // Fallback: utiliser les proportions de l'image
      const img = new Image();
      img.onload = () => {
        const aspectRatio = img.width / img.height;
        if (aspectRatio > 1) {
          setGridWidth(100);
          setGridHeight(Math.round(100 / aspectRatio));
        } else {
          setGridHeight(100);
          setGridWidth(Math.round(100 * aspectRatio));
        }
      };
      img.src = URL.createObjectURL(imageFile);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      setFile(selectedFile);
      
      const reader = new FileReader();
      reader.onload = async (e) => {
        setPreview(e.target.result);
        
        // Analyser automatiquement la grille
        await analyzeGrid(selectedFile);
      };
      reader.readAsDataURL(selectedFile);
    }
  };

  const handleImport = async () => {
    if (!file) {
      toast.error('Veuillez sélectionner une image');
      return;
    }

    setIsUploading(true);

    try {
      let imageUrl = uploadedImageUrl;
      
      // Si l'image n'a pas encore été uploadée (analyse a échoué), l'uploader maintenant
      if (!imageUrl) {
        toast.info('Upload de l\'image...');
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        imageUrl = file_url;
      }

      toast.success('Grille importée avec succès !');

      onImportComplete({
        imageUrl: imageUrl,
        gridWidth: gridWidth,
        gridHeight: gridHeight,
        offsetCol: offsetCol === 'center' || offsetCol === null ? 'center' : offsetCol,
        offsetRow: offsetRow === 'center' || offsetRow === null ? 'center' : offsetRow,
        colors: detectedColors
      });

      // Réinitialiser
      setFile(null);
      setPreview(null);
      setUploadedImageUrl(null);
      setAutoDetected(false);
      setDetectedColors([]);
      setOffsetCol('center');
      setOffsetRow('center');
      onClose();
      
    } catch (error) {
      console.error('Erreur import:', error);
      toast.error('Erreur lors de l\'import de la grille');
    } finally {
      setIsUploading(false);
    }
  };

  const handleClose = () => {
    if (!isUploading && !isAnalyzing) {
      setFile(null);
      setPreview(null);
      setUploadedImageUrl(null);
      setAutoDetected(false);
      setDetectedColors([]);
      setOffsetCol('center');
      setOffsetRow('center');
      onClose();
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-xl">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold flex items-center gap-2">
            <Grid3x3 className="w-5 h-5 text-blue-600" />
            Importer une grille d'auteur
          </DialogTitle>
          <DialogDescription>
            Importez une page de grille existante qui s'alignera automatiquement sur votre canevas
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-6 py-4">
          {/* Zone d'upload */}
          <div className="space-y-2">
            <Label className="text-sm font-medium">Image de la grille</Label>
            <div className="border-2 border-dashed border-slate-300 rounded-xl p-6 hover:border-slate-400 transition-colors">
              {preview ? (
                <div className="space-y-3">
                  <img 
                    src={preview} 
                    alt="Aperçu" 
                    className="w-full h-48 object-contain rounded-lg bg-slate-50"
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setFile(null);
                      setPreview(null);
                      setAutoDetected(false);
                    }}
                    className="w-full"
                    disabled={isUploading || isAnalyzing}
                  >
                    <Upload className="w-4 h-4 mr-2" />
                    Choisir une autre image
                  </Button>
                </div>
              ) : (
                <label className="flex flex-col items-center gap-3 cursor-pointer">
                  <ImageIcon className="w-12 h-12 text-slate-400" />
                  <div className="text-center">
                    <p className="text-sm font-medium text-slate-700">
                      Cliquez pour sélectionner une image
                    </p>
                    <p className="text-xs text-slate-500 mt-1">
                      PNG, JPG - Image d'une grille de point de croix
                    </p>
                  </div>
                  <Input
                    type="file"
                    accept="image/png,image/jpeg,image/jpg"
                    onChange={handleFileChange}
                    className="hidden"
                  />
                </label>
              )}
            </div>
          </div>

          {/* Statut de détection */}
          {isAnalyzing && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-center gap-3">
              <Loader2 className="w-5 h-5 animate-spin text-blue-600" />
              <p className="text-sm text-blue-900">
                Analyse automatique de la grille en cours...
              </p>
            </div>
          )}
          
          {autoDetected && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-4 flex items-center gap-3">
              <div className="w-5 h-5 rounded-full bg-green-600 flex items-center justify-center">
                <span className="text-white text-xs">✓</span>
              </div>
              <p className="text-sm text-green-900">
                Grille détectée automatiquement ! Vous pouvez ajuster si nécessaire.
              </p>
            </div>
          )}

          {/* Dimensions de la grille */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="gridWidth" className="text-sm font-medium">
                Largeur (cases)
              </Label>
              <Input
                id="gridWidth"
                type="number"
                min={1}
                max={1000}
                value={gridWidth}
                onChange={(e) => setGridWidth(parseInt(e.target.value) || 1)}
                disabled={isUploading || isAnalyzing}
                className="h-10"
              />
              <p className="text-xs text-slate-500">Nombre de colonnes</p>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="gridHeight" className="text-sm font-medium">
                Hauteur (cases)
              </Label>
              <Input
                id="gridHeight"
                type="number"
                min={1}
                max={1000}
                value={gridHeight}
                onChange={(e) => setGridHeight(parseInt(e.target.value) || 1)}
                disabled={isUploading || isAnalyzing}
                className="h-10"
              />
              <p className="text-xs text-slate-500">Nombre de lignes</p>
            </div>
          </div>

          {/* Position de départ */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="offsetCol" className="text-sm font-medium">
                Décalage colonne
              </Label>
              <Input
                id="offsetCol"
                type="number"
                min={0}
                value={offsetCol === 'center' || offsetCol === null ? '' : offsetCol}
                onChange={(e) => setOffsetCol(e.target.value === '' ? 'center' : parseInt(e.target.value) || 0)}
                disabled={isUploading || isAnalyzing}
                placeholder="Auto (centré)"
                className="h-10"
              />
              <p className="text-xs text-slate-500">Position départ X</p>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="offsetRow" className="text-sm font-medium">
                Décalage ligne
              </Label>
              <Input
                id="offsetRow"
                type="number"
                min={0}
                value={offsetRow === 'center' || offsetRow === null ? '' : offsetRow}
                onChange={(e) => setOffsetRow(e.target.value === '' ? 'center' : parseInt(e.target.value) || 0)}
                disabled={isUploading || isAnalyzing}
                placeholder="Auto (centré)"
                className="h-10"
              />
              <p className="text-xs text-slate-500">Position départ Y</p>
            </div>
          </div>

          {/* Message d'info */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <p className="text-sm text-blue-900">
              <strong>Info :</strong> L'image sera alignée précisément sur la grille. 
              Spécifiez le nombre de cases que représente votre grille d'auteur.
            </p>
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button 
            variant="outline" 
            onClick={handleClose}
            disabled={isUploading}
          >
            Annuler
          </Button>
          <Button 
            onClick={handleImport}
            disabled={!file || isUploading || isAnalyzing}
            className="bg-blue-600 hover:bg-blue-700"
          >
            {isUploading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Import en cours...
              </>
            ) : (
              <>
                <Grid3x3 className="w-4 h-4 mr-2" />
                Importer la grille
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}