import React, { useRef, useEffect, useCallback, useState } from 'react';
import { ZoomIn, ZoomOut, Minimize2, Maximize2, Navigation } from 'lucide-react';
import { useSettings } from '../settings/SettingsContext';
import { toast } from 'sonner';

// Convertir un numéro de ligne en lettre (0 = A, 25 = Z, 26 = AA, etc.)
const rowToLetter = (row) => {
  let result = '';
  let n = row;
  while (n >= 0) {
    result = String.fromCharCode(65 + (n % 26)) + result;
    n = Math.floor(n / 26) - 1;
  }
  return result;
};

export default function MiniCartePro({
  pattern,
  gridConfig,
  canvasSize,
  onNavigate,
  onNavigateToZone,
  showSmartScan = false,
  onClose,
}) {
  const { settings: userSettings } = useSettings();
  const minimapPosition = userSettings?.minimapPosition || 'bottom-right';
  
  const canvasRef = useRef(null);
  const containerRef = useRef(null);
  const [complexZones, setComplexZones] = useState([]);
  const [zoomLevel, setZoomLevel] = useState(1); // x1 ou x2
  const [isDragging, setIsDragging] = useState(false);
  const [hoveredBlock, setHoveredBlock] = useState(null); // { letter, number, col, row }
  const [currentZone, setCurrentZone] = useState(null); // Zone actuellement visible
  const [isMinimized, setIsMinimized] = useState(false); // Réduction de la carte
  
  // Position de la carte (draggable) - initialisée selon les réglages
  const getInitialPosition = () => {
    if (minimapPosition === 'bottom-left') {
      return { x: window.innerWidth - 250, y: 180 };
    }
    return { x: 16, y: 180 };
  };
  const [position, setPosition] = useState(getInitialPosition());
  const [isDraggingCard, setIsDraggingCard] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });

  // Dimensions de base
  const BASE_WIDTH = 200;
  const BASE_HEIGHT = 140;
  const RULER_SIZE = 16; // Taille des règles GPS
  const MAP_WIDTH = BASE_WIDTH * zoomLevel;
  const MAP_HEIGHT = BASE_HEIGHT * zoomLevel;

  // Analyser les zones complexes (mode PRO)
  const analyzeComplexity = useCallback(() => {
    if (!pattern?.symbolGrid || !showSmartScan) {
      setComplexZones([]);
      return;
    }

    const zones = [];
    const blockSize = 12;
    const height = pattern.symbolGrid.length;
    const width = pattern.symbolGrid[0]?.length || 0;

    for (let by = 0; by < height; by += blockSize) {
      for (let bx = 0; bx < width; bx += blockSize) {
        const colors = new Set();
        let isolated = 0;
        let density = 0;

        for (let y = by; y < Math.min(by + blockSize, height); y++) {
          for (let x = bx; x < Math.min(bx + blockSize, width); x++) {
            const cell = pattern.symbolGrid[y]?.[x];
            if (cell?.colorId) {
              colors.add(cell.colorId);
              density++;
              // Vérifier isolation
              const neighbors = [
                pattern.symbolGrid[y-1]?.[x],
                pattern.symbolGrid[y+1]?.[x],
                pattern.symbolGrid[y]?.[x-1],
                pattern.symbolGrid[y]?.[x+1],
              ].filter(n => n?.colorId === cell.colorId);
              if (neighbors.length === 0) isolated++;
            }
          }
        }

        const complexity = colors.size * 2 + isolated * 3 + (density > 100 ? 5 : 0);
        if (complexity > 10) {
          zones.push({
            x: bx,
            y: by,
            w: blockSize,
            h: blockSize,
            complexity,
            type: isolated > 5 ? 'isolated' : colors.size > 8 ? 'complex' : density > 100 ? 'dense' : 'contrast'
          });
        }
      }
    }

    zones.sort((a, b) => b.complexity - a.complexity);
    setComplexZones(zones.slice(0, 5));
  }, [pattern, showSmartScan]);

  useEffect(() => {
    analyzeComplexity();
  }, [analyzeComplexity]);

  // Calculer les paramètres de scale
  const getScaleParams = useCallback(() => {
    if (!pattern) return null;

    const patternWidth = pattern.width || pattern.symbolGrid[0]?.length || 1;
    const patternHeight = pattern.height || pattern.symbolGrid.length || 1;

    const scaleX = MAP_WIDTH / patternWidth;
    const scaleY = MAP_HEIGHT / patternHeight;
    const scale = Math.min(scaleX, scaleY) * 0.9;

    const offsetX = (MAP_WIDTH - patternWidth * scale) / 2;
    const offsetY = (MAP_HEIGHT - patternHeight * scale) / 2;

    return { patternWidth, patternHeight, scale, offsetX, offsetY };
  }, [pattern, MAP_WIDTH, MAP_HEIGHT]);

  // Dessiner la mini-carte
  const drawMiniMap = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas || !pattern) return;

    const ctx = canvas.getContext('2d');
    canvas.width = MAP_WIDTH;
    canvas.height = MAP_HEIGHT;

    // Fond
    ctx.fillStyle = '#1a1a1a';
    ctx.fillRect(0, 0, MAP_WIDTH, MAP_HEIGHT);

    if (!pattern.symbolGrid?.length) return;

    const params = getScaleParams();
    if (!params) return;

    const { patternWidth, patternHeight, scale, offsetX, offsetY } = params;

    // Dessiner le motif
    const step = Math.max(1, Math.floor(1 / scale));
    for (let row = 0; row < patternHeight; row += step) {
      for (let col = 0; col < patternWidth; col += step) {
        const cell = pattern.symbolGrid[row]?.[col];
        if (!cell) continue;

        const color = pattern.colorPalette?.find(c => c.id === cell.colorId);
        ctx.fillStyle = color?.hex || color?.dmcHex || '#666';
        ctx.fillRect(
          offsetX + col * scale,
          offsetY + row * scale,
          Math.max(1, scale * step),
          Math.max(1, scale * step)
        );
      }
    }

    // Indicateurs Smart-Scan (zones complexes)
    if (showSmartScan && complexZones.length > 0) {
      complexZones.forEach(zone => {
        const zx = offsetX + zone.x * scale;
        const zy = offsetY + zone.y * scale;
        const zw = zone.w * scale;
        const zh = zone.h * scale;

        // Couleur selon type
        const colors = {
          isolated: { stroke: '#FF4444', fill: 'rgba(255,68,68,0.25)' },
          complex: { stroke: '#FF8800', fill: 'rgba(255,136,0,0.25)' },
          dense: { stroke: '#AA44FF', fill: 'rgba(170,68,255,0.25)' },
          contrast: { stroke: '#FFCC00', fill: 'rgba(255,204,0,0.25)' },
        };
        const c = colors[zone.type] || colors.contrast;

        ctx.strokeStyle = c.stroke;
        ctx.fillStyle = c.fill;
        ctx.lineWidth = 2;
        ctx.fillRect(zx, zy, zw, zh);
        ctx.strokeRect(zx, zy, zw, zh);
      });
    }

    // Dessiner le quadrillage 10x10
    const blockSize = 10;
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
    ctx.lineWidth = 0.5;
    
    // Lignes verticales (colonnes)
    for (let col = blockSize; col < patternWidth; col += blockSize) {
      const x = offsetX + col * scale;
      ctx.beginPath();
      ctx.moveTo(x, offsetY);
      ctx.lineTo(x, offsetY + patternHeight * scale);
      ctx.stroke();
    }
    
    // Lignes horizontales (lignes)
    for (let row = blockSize; row < patternHeight; row += blockSize) {
      const y = offsetY + row * scale;
      ctx.beginPath();
      ctx.moveTo(offsetX, y);
      ctx.lineTo(offsetX + patternWidth * scale, y);
      ctx.stroke();
    }

    // Surligner le bloc survolé
    if (hoveredBlock) {
      const hx = offsetX + hoveredBlock.col * scale;
      const hy = offsetY + hoveredBlock.row * scale;
      const hw = Math.min(blockSize, patternWidth - hoveredBlock.col) * scale;
      const hh = Math.min(blockSize, patternHeight - hoveredBlock.row) * scale;
      
      ctx.fillStyle = 'rgba(59, 130, 246, 0.3)';
      ctx.fillRect(hx, hy, hw, hh);
      ctx.strokeStyle = '#3B82F6';
      ctx.lineWidth = 1.5;
      ctx.strokeRect(hx, hy, hw, hh);
    }

    // Rectangle de vue actuelle (viewport) - ROUGE
    if (gridConfig && canvasSize.width > 0) {
      const zoom = gridConfig.zoom || 1;
      const taille = gridConfig.taille_case || 25;
      const patternOffsetCol = pattern.offsetCol || 0;
      const patternOffsetRow = pattern.offsetRow || 0;

      const visibleStartX = (-gridConfig.offset_x / zoom / taille) - patternOffsetCol;
      const visibleStartY = (-gridConfig.offset_y / zoom / taille) - patternOffsetRow;
      const visibleWidth = canvasSize.width / zoom / taille;
      const visibleHeight = canvasSize.height / zoom / taille;

      const rectX = offsetX + Math.max(0, visibleStartX) * scale;
      const rectY = offsetY + Math.max(0, visibleStartY) * scale;
      const rectW = Math.min(patternWidth - Math.max(0, visibleStartX), visibleWidth) * scale;
      const rectH = Math.min(patternHeight - Math.max(0, visibleStartY), visibleHeight) * scale;

      // Calculer la zone GPS actuelle (centre de la vue)
      const centerCol = Math.floor(visibleStartX + visibleWidth / 2);
      const centerRow = Math.floor(visibleStartY + visibleHeight / 2);
      const zoneCol = Math.floor(centerCol / blockSize);
      const zoneRow = Math.floor(centerRow / blockSize);
      const zoneLetter = rowToLetter(zoneRow);
      const zoneNumber = zoneCol + 1;
      
      // Mettre à jour la zone actuelle
      if (centerCol >= 0 && centerRow >= 0 && centerCol < patternWidth && centerRow < patternHeight) {
        setCurrentZone(`${zoneLetter}${zoneNumber}`);
      }

      // Rectangle rouge avec ombre
      ctx.shadowColor = 'rgba(255,0,0,0.5)';
      ctx.shadowBlur = 4;
      ctx.strokeStyle = '#FF3333';
      ctx.lineWidth = 2.5;
      ctx.strokeRect(rectX, rectY, Math.max(6, rectW), Math.max(6, rectH));
      ctx.shadowBlur = 0;
    }
  }, [pattern, gridConfig, canvasSize, showSmartScan, complexZones, getScaleParams, MAP_WIDTH, MAP_HEIGHT, hoveredBlock]);

  useEffect(() => {
    drawMiniMap();
  }, [drawMiniMap]);

  // Convertir coordonnées canvas en coordonnées grille
  const canvasToGrid = (clientX, clientY) => {
    if (!canvasRef.current || !pattern) return null;

    const rect = canvasRef.current.getBoundingClientRect();
    const clickX = clientX - rect.left;
    const clickY = clientY - rect.top;

    const params = getScaleParams();
    if (!params) return null;

    const { patternWidth, patternHeight, scale, offsetX, offsetY } = params;

    const gridCol = Math.floor((clickX - offsetX) / scale);
    const gridRow = Math.floor((clickY - offsetY) / scale);

    if (gridCol >= 0 && gridCol < patternWidth && gridRow >= 0 && gridRow < patternHeight) {
      return { col: gridCol, row: gridRow };
    }
    return null;
  };

  // Calculer le bloc GPS à partir des coordonnées canvas
  const getBlockFromCanvas = (clientX, clientY) => {
    const gridPos = canvasToGrid(clientX, clientY);
    if (!gridPos) return null;
    
    const blockSize = 10;
    const blockCol = Math.floor(gridPos.col / blockSize);
    const blockRow = Math.floor(gridPos.row / blockSize);
    const letter = rowToLetter(blockRow);
    const number = blockCol + 1;
    
    return {
      letter,
      number,
      col: blockCol * blockSize,
      row: blockRow * blockSize,
      gps: `${letter}${number}`
    };
  };

  // Gestion du survol
  const handleMouseMoveCanvas = (e) => {
    if (isDragging) return;
    
    const block = getBlockFromCanvas(e.clientX, e.clientY);
    setHoveredBlock(block);
  };

  const handleMouseLeaveCanvas = () => {
    setHoveredBlock(null);
  };

  // Navigation au clic
  const handleClick = (e) => {
    if (isDragging) return;

    const block = getBlockFromCanvas(e.clientX, e.clientY);
    if (!block) return;

    // Appeler la fonction GPS pour téléportation avec conservation de l'état
    if (onNavigateToZone) {
      onNavigateToZone(block.gps);
    } else {
      // Fallback : navigation directe vers le centre du bloc
      const blockSize = 10;
      const centerCol = block.col + blockSize / 2;
      const centerRow = block.row + blockSize / 2;
      navigateToPosition(centerCol, centerRow);
    }
  };

  // Navigation vers une position
  const navigateToPosition = (col, row) => {
    if (!pattern || !gridConfig) return;

    const patternOffsetCol = pattern.offsetCol || 0;
    const patternOffsetRow = pattern.offsetRow || 0;
    const taille = gridConfig.taille_case || 25;
    const zoom = gridConfig.zoom || 1;

    const targetX = (col + patternOffsetCol) * taille * zoom;
    const targetY = (row + patternOffsetRow) * taille * zoom;

    onNavigate?.(targetX, targetY);
  };

  // Drag du cadre rouge
  const handleMouseDown = (e) => {
    setIsDragging(true);
    handleDrag(e);
  };

  const handleMouseMove = (e) => {
    if (!isDragging) return;
    handleDrag(e);
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleDrag = (e) => {
    const gridPos = canvasToGrid(e.clientX, e.clientY);
    if (gridPos) {
      navigateToPosition(gridPos.col, gridPos.row);
    }
  };

  useEffect(() => {
    if (isDragging) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
      return () => {
        window.removeEventListener('mousemove', handleMouseMove);
        window.removeEventListener('mouseup', handleMouseUp);
      };
    }
  }, [isDragging]);

  // Drag de la carte elle-même
  const handleCardDragStart = (e) => {
    e.preventDefault();
    setIsDraggingCard(true);
    const rect = containerRef.current?.getBoundingClientRect();
    if (rect) {
      setDragOffset({
        x: e.clientX - (window.innerWidth - rect.right),
        y: e.clientY - (window.innerHeight - rect.bottom)
      });
    }
  };

  const handleCardDragMove = useCallback((e) => {
    if (!isDraggingCard) return;
    const newX = window.innerWidth - e.clientX + dragOffset.x - (containerRef.current?.offsetWidth || 0);
    const newY = window.innerHeight - e.clientY + dragOffset.y - (containerRef.current?.offsetHeight || 0);
    setPosition({
      x: Math.max(0, Math.min(window.innerWidth - 220, newX)),
      y: Math.max(0, Math.min(window.innerHeight - 200, newY))
    });
  }, [isDraggingCard, dragOffset]);

  const handleCardDragEnd = () => {
    setIsDraggingCard(false);
  };

  useEffect(() => {
    if (isDraggingCard) {
      window.addEventListener('mousemove', handleCardDragMove);
      window.addEventListener('mouseup', handleCardDragEnd);
      return () => {
        window.removeEventListener('mousemove', handleCardDragMove);
        window.removeEventListener('mouseup', handleCardDragEnd);
      };
    }
  }, [isDraggingCard, handleCardDragMove]);

  // Repositionner quand les réglages changent
  useEffect(() => {
    if (minimapPosition === 'bottom-left') {
      setPosition({ x: window.innerWidth - 250, y: 180 });
    } else {
      setPosition({ x: 16, y: 180 });
    }
  }, [minimapPosition]);

  // Fermer en cliquant à l'extérieur
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (containerRef.current && !containerRef.current.contains(e.target)) {
        onClose?.();
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [onClose]);

  if (!pattern) return null;

  return (
    <div
      ref={containerRef}
      style={{
        position: 'fixed',
        top: '120px',
        left: '16px',
        zIndex: 85,
        backgroundColor: '#111',
        borderRadius: '8px',
        overflow: 'hidden',
        boxShadow: '0 4px 20px rgba(0,0,0,0.4)',
        border: '1px solid #333',
        userSelect: 'none',
      }}
    >
      {/* Bouton réduire/agrandir */}
      <button
        onClick={() => setIsMinimized(!isMinimized)}
        style={{
          position: 'absolute',
          top: '4px',
          right: '4px',
          width: '20px',
          height: '20px',
          borderRadius: '4px',
          backgroundColor: 'rgba(0,0,0,0.6)',
          border: 'none',
          cursor: 'pointer',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 10,
        }}
      >
        {isMinimized ? (
          <Maximize2 style={{ width: '12px', height: '12px', color: '#fff' }} />
        ) : (
          <Minimize2 style={{ width: '12px', height: '12px', color: '#fff' }} />
        )}
      </button>

      {/* Mode réduit : juste un indicateur */}
      {isMinimized ? (
        <div
          style={{
            padding: '8px 32px 8px 12px',
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
          }}
        >
          <Navigation style={{ width: '12px', height: '12px', color: '#FFC94A' }} />
          <span style={{ color: '#FFC94A', fontWeight: 600, fontSize: '11px' }}>
            {currentZone || 'Carte'}
          </span>
        </div>
      ) : (
        <>

      {/* Zone avec règles GPS */}
      <div style={{ display: 'flex' }}>
        {/* Règle verticale (lettres) */}
        <div
          style={{
            width: `${RULER_SIZE}px`,
            height: `${MAP_HEIGHT}px`,
            backgroundColor: '#0a0a0a',
            display: 'flex',
            flexDirection: 'column',
            paddingTop: '0px',
          }}
        >
          {pattern && (() => {
            const params = getScaleParams();
            if (!params) return null;
            const { patternHeight, scale, offsetY } = params;
            const blockSize = 10;
            const numBlocks = Math.ceil(patternHeight / blockSize);
            const blockHeightPx = blockSize * scale;
            
            return Array.from({ length: Math.min(numBlocks, 26) }, (_, i) => {
              const letter = rowToLetter(i);
              const isHovered = hoveredBlock?.letter === letter;
              const isCurrent = currentZone?.startsWith(letter);
              
              return (
                <div
                  key={i}
                  style={{
                    height: `${blockHeightPx}px`,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: '8px',
                    fontWeight: isHovered || isCurrent ? 700 : 500,
                    color: isHovered ? '#3B82F6' : isCurrent ? '#FFC94A' : '#666',
                    marginTop: i === 0 ? `${offsetY}px` : 0,
                  }}
                >
                  {letter}
                </div>
              );
            });
          })()}
        </div>

        {/* Colonne principale avec règle horizontale + canvas */}
        <div>
          {/* Règle horizontale (chiffres) */}
          <div
            style={{
              width: `${MAP_WIDTH}px`,
              height: `${RULER_SIZE}px`,
              backgroundColor: '#0a0a0a',
              display: 'flex',
              paddingLeft: '0px',
            }}
          >
            {pattern && (() => {
              const params = getScaleParams();
              if (!params) return null;
              const { patternWidth, scale, offsetX } = params;
              const blockSize = 10;
              const numBlocks = Math.ceil(patternWidth / blockSize);
              const blockWidthPx = blockSize * scale;
              
              return Array.from({ length: numBlocks }, (_, i) => {
                const number = i + 1;
                const isHovered = hoveredBlock?.number === number;
                const isCurrent = currentZone?.endsWith(String(number));
                
                return (
                  <div
                    key={i}
                    style={{
                      width: `${blockWidthPx}px`,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: '8px',
                      fontWeight: isHovered || isCurrent ? 700 : 500,
                      color: isHovered ? '#3B82F6' : isCurrent ? '#FFC94A' : '#666',
                      marginLeft: i === 0 ? `${offsetX}px` : 0,
                    }}
                  >
                    {number}
                  </div>
                );
              });
            })()}
          </div>

          {/* Canvas */}
          <canvas
            ref={canvasRef}
            onClick={handleClick}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMoveCanvas}
            onMouseLeave={handleMouseLeaveCanvas}
            style={{
              width: `${MAP_WIDTH}px`,
              height: `${MAP_HEIGHT}px`,
              cursor: isDragging ? 'grabbing' : 'crosshair',
              display: 'block',
            }}
          />
        </div>
      </div>

      {/* Label du bloc survolé */}
      {hoveredBlock && (
        <div
          style={{
            position: 'absolute',
            top: `${RULER_SIZE + 4}px`,
            right: '4px',
            backgroundColor: 'rgba(59, 130, 246, 0.9)',
            color: '#fff',
            padding: '2px 6px',
            borderRadius: '4px',
            fontSize: '10px',
            fontWeight: 700,
            pointerEvents: 'none',
          }}
        >
          {hoveredBlock.gps}
        </div>
      )}

      {/* Info zone actuelle */}
      <div
        style={{
          padding: '4px 8px',
          backgroundColor: '#0a0a0a',
          fontSize: '9px',
          color: '#666',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
        }}
      >
        <span>{pattern.width}×{pattern.height}</span>
        {currentZone && (
          <span style={{ display: 'flex', alignItems: 'center', gap: '3px' }}>
            <Navigation style={{ width: '9px', height: '9px', color: '#FFC94A' }} />
            <span style={{ color: '#FFC94A', fontWeight: 600 }}>{currentZone}</span>
          </span>
        )}
      </div>
      </>
      )}
    </div>
  );
}