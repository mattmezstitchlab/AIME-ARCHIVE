import React from 'react';
import { Button } from '@/components/ui/button';
import { Check } from 'lucide-react';
import { cn } from '@/lib/utils';

const STITCH_TYPES = [
  { id: 'full', name: 'Point complet', icon: '✕', description: 'Full cross' },
  { id: 'half', name: 'Demi-point', icon: '/', description: 'Half cross' },
  { id: 'quarter', name: 'Quart', icon: '◸', description: 'Quarter stitch' },
  { id: 'three-quarter', name: 'Trois-quarts', icon: '◹', description: 'Three-quarter' },
  { id: 'backstitch', name: 'Point arrière', icon: '―', description: 'Backstitch' },
  { id: 'knot', name: 'Nœud français', icon: '●', description: 'French knot' },
  { id: 'bead', name: 'Perle', icon: '◆', description: 'Bead' }
];

export default function StitchTypeSelector({ selectedType, onSelect, compact = false }) {
  if (compact) {
    return (
      <div className="flex gap-1">
        {STITCH_TYPES.map((type) => (
          <Button
            key={type.id}
            onClick={() => onSelect(type.id)}
            variant={selectedType === type.id ? "default" : "outline"}
            size="sm"
            className={cn(
              "w-8 h-8 p-0 text-lg",
              selectedType === type.id && "bg-slate-900 text-white"
            )}
            title={type.name}
          >
            {type.icon}
          </Button>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-1">
      <div className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider mb-2 px-1">
        Type de point
      </div>
      {STITCH_TYPES.map((type) => {
        const isActive = selectedType === type.id;
        
        return (
          <Button
            key={type.id}
            onClick={() => onSelect(type.id)}
            variant={isActive ? "default" : "ghost"}
            size="sm"
            className={cn(
              "w-full justify-start gap-3 h-10 transition-all",
              isActive 
                ? "bg-slate-900 text-white hover:bg-slate-800 shadow-md" 
                : "hover:bg-slate-100 text-slate-700"
            )}
          >
            <span className="text-xl w-6 text-center">{type.icon}</span>
            <span className="text-sm font-medium flex-1 text-left">{type.name}</span>
            {isActive && <Check className="w-4 h-4" />}
          </Button>
        );
      })}
    </div>
  );
}

export { STITCH_TYPES };