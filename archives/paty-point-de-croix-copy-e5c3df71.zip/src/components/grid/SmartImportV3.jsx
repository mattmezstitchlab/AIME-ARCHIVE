import React, { useState, useEffect, useRef, useMemo } from 'react';
import { X, Upload, Image as ImageIcon } from 'lucide-react';
import { toast } from 'sonner';
import { fixAllSymbols } from './symbolAssigner';

// Tailles de grille prédéfinies
const SIZE_PRESETS = [
  { label: 'XS', maxDim: 50, detail: 'Très simplifié' },
  { label: 'S', maxDim: 80, detail: 'Simplifié' },
  { label: 'M', maxDim: 120, detail: 'Équilibré' },
  { label: 'L', maxDim: 180, detail: 'Détaillé' },
  { label: 'XL', maxDim: 250, detail: 'Très détaillé' },
  { label: 'XXL', maxDim: 350, detail: 'Maximum' },
];

// Options de palette DMC
const DMC_OPTIONS = [
  { label: 'AUTO', value: 'auto', description: 'recommandé' },
  { label: '30', value: 30 },
  { label: '60', value: 60 },
  { label: '90', value: 90 },
  { label: '120', value: 120 },
];

export default function SmartImportV3({ open, onClose, onComplete }) {
  const fileInputRef = useRef(null);
  const [selectedFile, setSelectedFile] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const [imageDimensions, setImageDimensions] = useState({ width: 0, height: 0 });
  
  // Réglages
  const [sizeIndex, setSizeIndex] = useState(2); // M par défaut
  const [dmcOption, setDmcOption] = useState('auto');
  const [showSymbols, setShowSymbols] = useState(true);
  const [stitchTypes, setStitchTypes] = useState({
    full: true,
    half: false,
    threeQuarter: false,
    backstitch: false,
    frenchKnot: false,
    longStitch: false,
    couching: false,
  });
  const [backgroundMode, setBackgroundMode] = useState('filled'); // 'filled' | 'transparent'
  
  const [isGenerating, setIsGenerating] = useState(false);

  // Calculs dynamiques
  const gridCalculations = useMemo(() => {
    if (!imageDimensions.width || !imageDimensions.height) {
      return { width: 0, height: 0, totalPoints: 0, estimatedColors: 0 };
    }

    const preset = SIZE_PRESETS[sizeIndex];
    const aspectRatio = imageDimensions.width / imageDimensions.height;
    
    let gridWidth, gridHeight;
    if (aspectRatio > 1) {
      gridWidth = preset.maxDim;
      gridHeight = Math.round(preset.maxDim / aspectRatio);
    } else {
      gridHeight = preset.maxDim;
      gridWidth = Math.round(preset.maxDim * aspectRatio);
    }

    const totalPoints = gridWidth * gridHeight;
    
    // Estimation des couleurs DMC
    let estimatedColors;
    if (dmcOption === 'auto') {
      // Auto: basé sur la complexité de l'image
      estimatedColors = Math.min(Math.round(totalPoints / 800), 90);
    } else {
      estimatedColors = parseInt(dmcOption);
    }

    return { width: gridWidth, height: gridHeight, totalPoints, estimatedColors };
  }, [imageDimensions, sizeIndex, dmcOption]);

  // Gain de points (comparé à la taille originale)
  const pointsGain = useMemo(() => {
    if (!imageDimensions.width) return { value: 0, percent: 0 };
    
    const originalPoints = imageDimensions.width * imageDimensions.height;
    const diff = gridCalculations.totalPoints - originalPoints;
    const percent = Math.round((diff / originalPoints) * 100);
    
    return { value: diff, percent };
  }, [imageDimensions, gridCalculations]);

  // Reset quand on ferme
  useEffect(() => {
    if (!open) {
      setSelectedFile(null);
      setImagePreview(null);
      setImageDimensions({ width: 0, height: 0 });
      setSizeIndex(2);
      setDmcOption('auto');
      setShowSymbols(true);
      setStitchTypes({ full: true, half: false, threeQuarter: false, backstitch: false, frenchKnot: false, longStitch: false, couching: false });
      setBackgroundMode('filled');
    }
  }, [open]);

  const handleFileSelect = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast.error('Veuillez sélectionner une image (PNG ou JPG)');
      return;
    }

    setSelectedFile(file);

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        setImageDimensions({ width: img.width, height: img.height });
        setImagePreview(event.target.result);
      };
      img.src = event.target.result;
    };
    reader.readAsDataURL(file);
  };

  const handleGenerate = async () => {
    if (!selectedFile || !imagePreview) {
      toast.error('Veuillez d\'abord importer une image');
      return;
    }

    setIsGenerating(true);

    try {
      const { applyDMCConversionToPattern } = await import('./dmcConversion');

      const img = new Image();
      img.onload = async () => {
        const canvas = document.createElement('canvas');
        const targetWidth = gridCalculations.width;
        const targetHeight = gridCalculations.height;

        canvas.width = targetWidth;
        canvas.height = targetHeight;

        const ctx = canvas.getContext('2d');
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';
        ctx.drawImage(img, 0, 0, targetWidth, targetHeight);

        const imageData = ctx.getImageData(0, 0, targetWidth, targetHeight);
        const sourceImage = canvas.toDataURL();

        // Nombre de couleurs cible
        const colorsCount = dmcOption === 'auto' 
          ? Math.min(Math.round(targetWidth * targetHeight / 800), 90)
          : parseInt(dmcOption);

        // Extraction des couleurs
        const colorFrequency = {};
        for (let i = 0; i < imageData.data.length; i += 4) {
          const r = imageData.data[i];
          const g = imageData.data[i + 1];
          const b = imageData.data[i + 2];
          const a = imageData.data[i + 3];

          if (backgroundMode === 'transparent' && a < 50) continue;

          const key = `${Math.round(r / 8) * 8},${Math.round(g / 8) * 8},${Math.round(b / 8) * 8}`;
          colorFrequency[key] = (colorFrequency[key] || 0) + 1;
        }

        const sortedColors = Object.entries(colorFrequency)
          .sort((a, b) => b[1] - a[1])
          .slice(0, colorsCount);

        if (sortedColors.length === 0) {
          sortedColors.push(['245,245,240', 1]);
        }

        // Symboles disponibles
        const symbols = ['●', '✕', '▲', '■', '◆', '○', '▼', '◀', '▶', '★', '◐', '◑', '▣', '⬟', '⬡', '✦', '✧', '◈', '◇', '△'];

        // Construire le pattern
        const importedPattern = {
          width: targetWidth,
          height: targetHeight,
          sourceImage,
          colorPalette: sortedColors.map(([rgb, count], idx) => {
            const [r, g, b] = rgb.split(',').map(Number);
            return {
              id: `color-${idx}`,
              hex: `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`,
              name: `Couleur ${idx + 1}`,
              count,
              totalCount: count,
              doneCount: 0,
              progress: 0,
              assignedSymbolId: `symbol-${idx}`,
              assignedSymbolChar: symbols[idx % symbols.length]
            };
          }),
          symbolGrid: []
        };

        // Générer la grille de symboles
        for (let row = 0; row < targetHeight; row++) {
          const rowData = [];
          for (let col = 0; col < targetWidth; col++) {
            const idx = (row * targetWidth + col) * 4;
            const r = imageData.data[idx];
            const g = imageData.data[idx + 1];
            const b = imageData.data[idx + 2];
            const a = imageData.data[idx + 3];

            if (backgroundMode === 'transparent' && a < 50) {
              rowData.push(null);
              continue;
            }

            const key = `${Math.round(r / 8) * 8},${Math.round(g / 8) * 8},${Math.round(b / 8) * 8}`;
            const colorIndex = sortedColors.findIndex(([k]) => k === key);

            if (colorIndex >= 0) {
              rowData.push({ colorId: `color-${colorIndex}`, done: false });
            } else {
              // Couleur la plus proche
              const distances = sortedColors.map(([rgb]) => {
                const [cr, cg, cb] = rgb.split(',').map(Number);
                return Math.sqrt(Math.pow(r - cr, 2) + Math.pow(g - cg, 2) + Math.pow(b - cb, 2));
              });
              const closestIndex = distances.indexOf(Math.min(...distances));
              rowData.push({ colorId: `color-${closestIndex}`, done: false });
            }
          }
          importedPattern.symbolGrid.push(rowData);
        }

        // Mode fond brodé: remplir les trous
        if (backgroundMode === 'filled') {
          for (let row = 0; row < targetHeight; row++) {
            for (let col = 0; col < targetWidth; col++) {
              if (!importedPattern.symbolGrid[row][col]) {
                const neighbors = [];
                for (let dr = -2; dr <= 2; dr++) {
                  for (let dc = -2; dc <= 2; dc++) {
                    const nr = row + dr;
                    const nc = col + dc;
                    if (nr >= 0 && nr < targetHeight && nc >= 0 && nc < targetWidth) {
                      const cell = importedPattern.symbolGrid[nr][nc];
                      if (cell) neighbors.push(cell.colorId);
                    }
                  }
                }

                if (neighbors.length > 0) {
                  const colorCounts = {};
                  neighbors.forEach(c => colorCounts[c] = (colorCounts[c] || 0) + 1);
                  const dominantColor = Object.entries(colorCounts).sort((a, b) => b[1] - a[1])[0][0];
                  importedPattern.symbolGrid[row][col] = { colorId: dominantColor, done: false };
                } else {
                  importedPattern.symbolGrid[row][col] = { colorId: 'color-0', done: false };
                }
              }
            }
          }
        }

        // Appliquer la conversion DMC
        const processedPattern = applyDMCConversionToPattern(importedPattern);

        // Assigner les symboles manquants et corriger les doublons
        const { palette: fixedPalette, fixedCount } = fixAllSymbols(processedPattern.colorPalette);
        processedPattern.colorPalette = fixedPalette;

        // Ajouter les métadonnées
        processedPattern.stitchTypes = stitchTypes;
        processedPattern.showSymbols = showSymbols;
        
        // Calculer le zoom initial intelligent
        const maxDim = Math.max(targetWidth, targetHeight);
        let initialZoom;
        if (maxDim < 250) {
          initialZoom = 0.9;
        } else if (maxDim <= 400) {
          initialZoom = 0.75;
        } else {
          initialZoom = 0.6;
        }
        processedPattern.initialZoom = initialZoom;

        setIsGenerating(false);
        onComplete(processedPattern);
        onClose();
        toast.success(`Grille ${targetWidth}×${targetHeight} générée avec ${processedPattern.colorPalette.length} couleurs DMC`);
      };

      img.src = imagePreview;
    } catch (error) {
      console.error('Erreur génération:', error);
      setIsGenerating(false);
      toast.error('Erreur lors de la génération');
    }
  };

  if (!open) return null;

  return (
    <div 
      className="fixed inset-0 z-[100] flex items-center justify-center p-4"
      style={{ backgroundColor: 'rgba(0,0,0,0.8)' }}
    >
      <div 
        className="relative w-full max-w-4xl max-h-[90vh] overflow-y-auto"
        style={{
          backgroundColor: '#000',
          borderRadius: '24px',
          padding: '40px',
        }}
      >
        {/* Bouton fermer */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 w-10 h-10 rounded-full border border-white/30 flex items-center justify-center hover:bg-white/10 transition-colors"
        >
          <X className="w-5 h-5 text-white" />
        </button>

        {/* Titre */}
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-white mb-1">Smart Import V3</h1>
          <p className="text-white/50 text-sm">PNG / JPG · Palette DMC intelligente · Analyse Delta-E 2000</p>
        </div>

        {/* Contenu 2 colonnes */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Colonne gauche - Import */}
          <div>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/png,image/jpeg,image/jpg"
              onChange={handleFileChange}
              className="hidden"
            />

            {!imagePreview ? (
              <button
                onClick={handleFileSelect}
                className="w-full aspect-square rounded-2xl flex flex-col items-center justify-center gap-4 transition-all hover:bg-[#1a1a1a]"
                style={{ backgroundColor: '#151515' }}
              >
                <Upload className="w-12 h-12 text-white/60" />
                <div className="text-center">
                  <p className="text-white font-medium">Importer une image</p>
                  <p className="text-white/40 text-sm mt-1">PNG / JPG depuis votre appareil</p>
                </div>
              </button>
            ) : (
              <div className="space-y-4">
                <div 
                  className="w-full aspect-square rounded-2xl overflow-hidden flex items-center justify-center"
                  style={{ backgroundColor: '#151515' }}
                >
                  <img 
                    src={imagePreview} 
                    alt="Aperçu" 
                    className="max-w-full max-h-full object-contain"
                  />
                </div>
                <p className="text-white/50 text-sm text-center">
                  Image originale : {imageDimensions.width} × {imageDimensions.height} px
                </p>
                <button
                  onClick={handleFileSelect}
                  className="w-full py-2 text-white/60 text-sm hover:text-white transition-colors"
                >
                  Changer d'image
                </button>
              </div>
            )}
          </div>

          {/* Colonne droite - Réglages */}
          <div className="space-y-6">
            {/* Bloc 1 - Informations grille */}
            <div 
              className="rounded-xl p-4"
              style={{ backgroundColor: '#1a1a1a' }}
            >
              <p className="text-white font-medium">
                Grille calculée : {gridCalculations.width} × {gridCalculations.height} points
              </p>
              <p className="text-white/50 text-sm mt-1">
                Total : {gridCalculations.totalPoints.toLocaleString()} points
              </p>
              <p className={`text-sm mt-1 ${backgroundMode === 'filled' ? 'text-emerald-400' : 'text-white/50'}`}>
                Cases vides : {backgroundMode === 'filled' ? '0 ✓' : '(zones de fond)'}
              </p>
              {pointsGain.value !== 0 && (
                <p className="text-emerald-400 text-sm mt-2">
                  Gain : {pointsGain.value > 0 ? '+' : ''}{pointsGain.value.toLocaleString()} points ({pointsGain.percent > 0 ? '+' : ''}{pointsGain.percent}%)
                </p>
              )}
            </div>

            {/* Bloc 2 - Taille & détails */}
            <div>
              <p className="text-white/70 text-sm mb-3">Taille de la grille / niveau de détail</p>
              <div className="flex gap-2">
                {SIZE_PRESETS.map((preset, idx) => (
                  <button
                    key={preset.label}
                    onClick={() => setSizeIndex(idx)}
                    className={`flex-1 py-2 px-1 rounded-lg text-sm font-medium transition-all ${
                      sizeIndex === idx
                        ? 'bg-white text-black'
                        : 'bg-white/10 text-white/70 hover:bg-white/20'
                    }`}
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
              <p className="text-white/40 text-xs mt-2 text-center">
                {SIZE_PRESETS[sizeIndex].detail} — max {SIZE_PRESETS[sizeIndex].maxDim} points
              </p>
            </div>

            {/* Bloc 3 - Palette DMC */}
            <div>
              <p className="text-white/70 text-sm mb-3">Palette DMC</p>
              <div className="flex gap-2 flex-wrap">
                {DMC_OPTIONS.map((option) => (
                  <button
                    key={option.value}
                    onClick={() => setDmcOption(option.value)}
                    className={`py-2 px-4 rounded-lg text-sm font-medium transition-all ${
                      dmcOption === option.value
                        ? 'bg-white text-black'
                        : 'bg-white/10 text-white/70 hover:bg-white/20'
                    }`}
                  >
                    {option.label}
                    {option.description && (
                      <span className="text-xs ml-1 opacity-60">({option.description})</span>
                    )}
                  </button>
                ))}
              </div>
              <p className="text-white/50 text-sm mt-3">
                ≈ {gridCalculations.estimatedColors} couleurs DMC utilisées
              </p>
              
              <label className="flex items-center gap-3 mt-4 cursor-pointer">
                <input
                  type="checkbox"
                  checked={showSymbols}
                  onChange={(e) => setShowSymbols(e.target.checked)}
                  className="w-4 h-4 rounded"
                />
                <span className="text-white/70 text-sm">Afficher les symboles dans la grille</span>
              </label>
              <p className="text-white/40 text-xs mt-1 ml-7">
                Chaque couleur DMC est automatiquement couplée à un symbole unique.
              </p>
            </div>

            {/* Bloc 4 - Styles de points */}
            <div>
              <p className="text-white/70 text-sm mb-3">Styles de points</p>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { key: 'full', label: 'Point entier' },
                  { key: 'half', label: 'Demi-point' },
                  { key: 'threeQuarter', label: '3/4 point' },
                  { key: 'backstitch', label: 'Point arrière' },
                  { key: 'frenchKnot', label: 'Point de nœud' },
                  { key: 'longStitch', label: 'Point long' },
                  { key: 'couching', label: 'Point de couchure' },
                ].map(({ key, label }) => (
                  <label key={key} className="flex items-center gap-3 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={stitchTypes[key]}
                      onChange={(e) => setStitchTypes(prev => ({ ...prev, [key]: e.target.checked }))}
                      className="w-4 h-4 rounded"
                    />
                    <span className="text-white/70 text-sm">{label}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Bloc 5 - Mode de fond */}
            <div>
              <p className="text-white/70 text-sm mb-3">Mode de fond</p>
              <div className="flex gap-2">
                <button
                  onClick={() => setBackgroundMode('filled')}
                  className={`flex-1 py-3 px-4 rounded-lg text-sm font-medium transition-all ${
                    backgroundMode === 'filled'
                      ? 'bg-white text-black'
                      : 'bg-white/10 text-white/70 hover:bg-white/20'
                  }`}
                >
                  ✅ Fond brodé
                </button>
                <button
                  onClick={() => setBackgroundMode('transparent')}
                  className={`flex-1 py-3 px-4 rounded-lg text-sm font-medium transition-all ${
                    backgroundMode === 'transparent'
                      ? 'bg-white text-black'
                      : 'bg-white/10 text-white/70 hover:bg-white/20'
                  }`}
                >
                  ☐ Fond transparent
                </button>
              </div>
              <p className="text-white/40 text-xs mt-2">
                {backgroundMode === 'filled' 
                  ? 'Toutes les cases sont remplies (aucune case vide). Chaque cellule aura un symbole DMC.'
                  : 'Les zones de fond peuvent rester vides (zones transparentes non brodées).'
                }
              </p>
            </div>
          </div>
        </div>

        {/* Barre d'action */}
        <div className="flex items-center justify-between mt-10 pt-6 border-t border-white/10">
          <button
            onClick={onClose}
            className="text-white/50 hover:text-white transition-colors"
          >
            Annuler
          </button>
          
          <button
            onClick={handleGenerate}
            disabled={!imagePreview || isGenerating}
            className={`px-8 py-3 rounded-xl font-semibold transition-all ${
              imagePreview && !isGenerating
                ? 'bg-blue-600 hover:bg-blue-500 text-white'
                : 'bg-white/20 text-white/40 cursor-not-allowed'
            }`}
          >
            {isGenerating ? 'Génération...' : 'Générer la grille'}
          </button>
        </div>
      </div>
    </div>
  );
}