import React, { useMemo, useCallback, useState, useRef } from 'react';

// Convertir un numéro de ligne (0-based) en lettre (A, B, C, ..., Z, AA, AB, ...)
const rowToLetter = (row) => {
  const blockIndex = Math.floor(row / 10);
  if (blockIndex < 26) {
    return String.fromCharCode(65 + blockIndex);
  }
  const first = Math.floor(blockIndex / 26) - 1;
  const second = blockIndex % 26;
  if (first >= 0) {
    return String.fromCharCode(65 + first) + String.fromCharCode(65 + second);
  }
  return String.fromCharCode(65 + second);
};

// Seuil de mouvement pour différencier clic et drag (en pixels)
const DRAG_THRESHOLD = 5;

// Règle horizontale (chiffres en haut) - CLIQUABLE GPS + DRAG SCROLL
export function HorizontalRuler({
  nbColonnes,
  tailleCase,
  zoom,
  offsetX,
  highlightZone = null,
  showSecondary = true,
  onNavigateToColumn = null,
  onDragScroll = null, // Callback pour scroll par drag (deltaX)
  currentViewCol = null
}) {
  const effectiveTailleCase = tailleCase * zoom;
  const [isDragging, setIsDragging] = useState(false);
  const dragRef = useRef({ startX: 0, startOffsetX: 0, hasMoved: false });
  
  // Styles améliorés
  const bgColor = '#000000';
  const textColor = '#888';
  const primaryTextColor = '#ffffff';
  const highlightTextColor = '#FFC94A';
  const centerColor = '#FF6B6B'; // Rouge pour le centre
  const borderColor = '#333';
  const highlightBg = 'rgba(255, 201, 74, 0.2)';
  const currentViewColor = '#FFC94A';
  const centerBg = 'rgba(255, 107, 107, 0.15)';
  
  const primaryHeight = 28;
  const secondaryHeight = showSecondary && zoom >= 0.6 ? 18 : 0;
  const totalHeight = primaryHeight + secondaryHeight;

  // Colonne centrale de la grille
  const centerCol = Math.floor(nbColonnes / 2);

  // Gestion du pointer down (début potentiel de drag ou clic)
  const handlePointerDown = useCallback((event) => {
    const rect = event.currentTarget.getBoundingClientRect();
    dragRef.current = {
      startX: event.clientX,
      startOffsetX: offsetX,
      hasMoved: false
    };
    setIsDragging(true);
    event.currentTarget.setPointerCapture(event.pointerId);
  }, [offsetX]);

  // Gestion du pointer move (drag en cours)
  const handlePointerMove = useCallback((event) => {
    if (!isDragging) return;
    
    const deltaX = event.clientX - dragRef.current.startX;
    
    // Vérifier si on a dépassé le seuil de drag
    if (Math.abs(deltaX) > DRAG_THRESHOLD) {
      dragRef.current.hasMoved = true;
    }
    
    if (dragRef.current.hasMoved && onDragScroll) {
      // Calculer le nouveau offset
      const newOffsetX = dragRef.current.startOffsetX + deltaX;
      onDragScroll(newOffsetX, null); // null pour Y = pas de changement vertical
    }
  }, [isDragging, onDragScroll]);

  // Gestion du pointer up (fin de drag ou clic)
  const handlePointerUp = useCallback((event) => {
    if (!isDragging) return;
    
    setIsDragging(false);
    event.currentTarget.releasePointerCapture(event.pointerId);
    
    // Si pas de mouvement significatif, c'est un clic = navigation GPS
    if (!dragRef.current.hasMoved && onNavigateToColumn) {
      const rect = event.currentTarget.getBoundingClientRect();
      const clickX = event.clientX - rect.left;
      const rulerWidth = rect.width;
      const ratio = clickX / rulerWidth;
      const targetCol = Math.round(ratio * (nbColonnes - 1));
      
      if (targetCol >= 0 && targetCol < nbColonnes) {
        onNavigateToColumn(targetCol);
      }
    }
  }, [isDragging, onNavigateToColumn, nbColonnes]);

  // Marques principales (par 10)
  const primaryMarks = useMemo(() => {
    const marks = [];
    const numBlocks = Math.ceil(nbColonnes / 10);
    const centerBlockIndex = Math.floor(centerCol / 10);
    
    for (let i = 0; i < numBlocks; i++) {
      const colStart = i * 10;
      const x = offsetX + colStart * effectiveTailleCase;
      const width = 10 * effectiveTailleCase;
      const isHighlighted = highlightZone && highlightZone.number === i + 1;
      const isCurrent = currentViewCol !== null && 
                        colStart <= currentViewCol && 
                        currentViewCol < colStart + 10;
      const isCenter = i === centerBlockIndex;
      
      if (x + width < -100 || x > window.innerWidth + 100) continue;
      
      marks.push(
        <div
          key={`p-${i}`}
          className="absolute flex items-center justify-center font-bold select-none"
          style={{
            left: `${x}px`,
            top: 0,
            width: `${width}px`,
            height: `${primaryHeight}px`,
            backgroundColor: isCenter ? centerBg : isHighlighted ? highlightBg : 'transparent',
            color: isCenter ? centerColor : isHighlighted ? highlightTextColor : isCurrent ? currentViewColor : primaryTextColor,
            fontSize: '14px',
            fontWeight: isCenter ? '800' : isCurrent ? '800' : '600',
            borderRight: `1px solid ${borderColor}`,
            textShadow: isCenter ? '0 0 8px rgba(255, 107, 107, 0.5)' : isCurrent ? '0 0 8px rgba(255, 201, 74, 0.5)' : 'none',
          }}
        >
          {isCenter ? `C${(i + 1) * 10}` : (i + 1) * 10}
        </div>
      );
    }
    return marks;
  }, [nbColonnes, effectiveTailleCase, offsetX, highlightZone, currentViewCol, centerCol]);

  // Marques secondaires (chaque colonne) - seulement si zoom suffisant
  const secondaryMarks = useMemo(() => {
    if (!showSecondary || zoom < 0.6) return null;
    
    const marks = [];
    const step = zoom >= 1.2 ? 1 : zoom >= 0.8 ? 2 : 5;
    
    for (let col = 0; col < nbColonnes; col += step) {
      const x = offsetX + col * effectiveTailleCase;
      const width = step * effectiveTailleCase;
      
      if (x + width < -50 || x > window.innerWidth + 50) continue;
      
      // Afficher uniquement si ce n'est pas un multiple de 10 (déjà affiché en primaire)
      if (col % 10 === 0) continue;
      
      marks.push(
        <div
          key={`s-${col}`}
          className="absolute flex items-center justify-center select-none"
          style={{
            left: `${x}px`,
            top: `${primaryHeight}px`,
            width: `${width}px`,
            height: `${secondaryHeight}px`,
            color: textColor,
            fontSize: '10px',
          }}
        >
          {col + 1}
        </div>
      );
    }
    return marks;
  }, [nbColonnes, effectiveTailleCase, offsetX, zoom, showSecondary]);

  // Indicateur de position actuelle (trait jaune)
  const currentViewIndicator = useMemo(() => {
    if (currentViewCol === null) return null;
    
    const x = offsetX + currentViewCol * effectiveTailleCase;
    
    return (
      <div
        className="absolute pointer-events-none"
        style={{
          left: `${x}px`,
          top: 0,
          width: '2px',
          height: `${totalHeight}px`,
          backgroundColor: currentViewColor,
          boxShadow: '0 0 6px rgba(255, 201, 74, 0.8)',
          zIndex: 10,
        }}
      />
    );
  }, [currentViewCol, offsetX, effectiveTailleCase, totalHeight]);

  // Indicateur du centre de la grille (trait rouge)
  const centerIndicator = useMemo(() => {
    const x = offsetX + centerCol * effectiveTailleCase;
    
    return (
      <div
        className="absolute pointer-events-none"
        style={{
          left: `${x}px`,
          top: 0,
          width: '3px',
          height: `${totalHeight}px`,
          backgroundColor: centerColor,
          boxShadow: '0 0 8px rgba(255, 107, 107, 0.6)',
          zIndex: 15,
        }}
      />
    );
  }, [centerCol, offsetX, effectiveTailleCase, totalHeight]);

  return (
    <div
      className="flex-1 overflow-hidden relative select-none"
      style={{
        height: `${totalHeight}px`,
        backgroundColor: bgColor,
        borderBottom: `1px solid ${borderColor}`,
        cursor: isDragging ? 'grabbing' : 'grab',
        touchAction: 'none',
      }}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerCancel={handlePointerUp}
      title="Cliquez pour naviguer • Glissez pour défiler"
    >
      {primaryMarks}
      {secondaryMarks}
      {centerIndicator}
      {currentViewIndicator}
    </div>
  );
}

// Règle verticale (lettres à gauche) - CLIQUABLE GPS + DRAG SCROLL
export function VerticalRuler({
  nbLignes,
  tailleCase,
  zoom,
  offsetY,
  highlightZone = null,
  showSecondary = true,
  onNavigateToRow = null,
  onDragScroll = null, // Callback pour scroll par drag (deltaY)
  currentViewRow = null
}) {
  const effectiveTailleCase = tailleCase * zoom;
  const [isDragging, setIsDragging] = useState(false);
  const dragRef = useRef({ startY: 0, startOffsetY: 0, hasMoved: false });
  
  // Styles améliorés
  const bgColor = '#000000';
  const textColor = '#888';
  const primaryTextColor = '#ffffff';
  const highlightTextColor = '#FFC94A';
  const centerColor = '#FF6B6B'; // Rouge pour le centre
  const borderColor = '#333';
  const highlightBg = 'rgba(255, 201, 74, 0.2)';
  const currentViewColor = '#FFC94A';
  const centerBg = 'rgba(255, 107, 107, 0.15)';
  
  const primaryWidth = 32;
  const secondaryWidth = showSecondary && zoom >= 0.6 ? 20 : 0;
  const totalWidth = primaryWidth + secondaryWidth;

  // Ligne centrale de la grille
  const centerRow = Math.floor(nbLignes / 2);

  // Gestion du pointer down (début potentiel de drag ou clic)
  const handlePointerDown = useCallback((event) => {
    dragRef.current = {
      startY: event.clientY,
      startOffsetY: offsetY,
      hasMoved: false
    };
    setIsDragging(true);
    event.currentTarget.setPointerCapture(event.pointerId);
  }, [offsetY]);

  // Gestion du pointer move (drag en cours)
  const handlePointerMove = useCallback((event) => {
    if (!isDragging) return;
    
    const deltaY = event.clientY - dragRef.current.startY;
    
    // Vérifier si on a dépassé le seuil de drag
    if (Math.abs(deltaY) > DRAG_THRESHOLD) {
      dragRef.current.hasMoved = true;
    }
    
    if (dragRef.current.hasMoved && onDragScroll) {
      // Calculer le nouveau offset
      const newOffsetY = dragRef.current.startOffsetY + deltaY;
      onDragScroll(null, newOffsetY); // null pour X = pas de changement horizontal
    }
  }, [isDragging, onDragScroll]);

  // Gestion du pointer up (fin de drag ou clic)
  const handlePointerUp = useCallback((event) => {
    if (!isDragging) return;
    
    setIsDragging(false);
    event.currentTarget.releasePointerCapture(event.pointerId);
    
    // Si pas de mouvement significatif, c'est un clic = navigation GPS
    if (!dragRef.current.hasMoved && onNavigateToRow) {
      const rect = event.currentTarget.getBoundingClientRect();
      const clickY = event.clientY - rect.top;
      const rulerHeight = rect.height;
      const ratio = clickY / rulerHeight;
      const targetRow = Math.round(ratio * (nbLignes - 1));
      
      if (targetRow >= 0 && targetRow < nbLignes) {
        onNavigateToRow(targetRow);
      }
    }
  }, [isDragging, onNavigateToRow, nbLignes]);

  // Marques principales (par 10 lignes = lettres)
  const primaryMarks = useMemo(() => {
    const marks = [];
    const numBlocks = Math.ceil(nbLignes / 10);
    const centerBlockIndex = Math.floor(centerRow / 10);
    
    for (let i = 0; i < numBlocks; i++) {
      const rowStart = i * 10;
      const y = offsetY + rowStart * effectiveTailleCase;
      const height = 10 * effectiveTailleCase;
      const letter = rowToLetter(rowStart);
      const isHighlighted = highlightZone && highlightZone.letter === letter;
      const isCurrent = currentViewRow !== null && 
                        rowStart <= currentViewRow && 
                        currentViewRow < rowStart + 10;
      const isCenter = i === centerBlockIndex;
      
      if (y + height < -100 || y > window.innerHeight + 100) continue;
      
      marks.push(
        <div
          key={`p-${i}`}
          className="absolute flex items-center justify-center font-bold select-none"
          style={{
            left: 0,
            top: `${y}px`,
            width: `${primaryWidth}px`,
            height: `${height}px`,
            backgroundColor: isCenter ? centerBg : isHighlighted ? highlightBg : 'transparent',
            color: isCenter ? centerColor : isHighlighted ? highlightTextColor : isCurrent ? currentViewColor : primaryTextColor,
            fontSize: isCenter ? '12px' : '14px',
            fontWeight: isCenter ? '800' : isCurrent ? '800' : '600',
            borderBottom: `1px solid ${borderColor}`,
            textShadow: isCenter ? '0 0 8px rgba(255, 107, 107, 0.5)' : isCurrent ? '0 0 8px rgba(255, 201, 74, 0.5)' : 'none',
          }}
        >
          {isCenter ? `C` : letter}
        </div>
      );
    }
    return marks;
  }, [nbLignes, effectiveTailleCase, offsetY, highlightZone, currentViewRow, centerRow]);

  // Marques secondaires (numéros de lignes) - seulement si zoom suffisant
  const secondaryMarks = useMemo(() => {
    if (!showSecondary || zoom < 0.6) return null;
    
    const marks = [];
    const step = zoom >= 1.2 ? 1 : zoom >= 0.8 ? 2 : 5;
    
    for (let row = 0; row < nbLignes; row += step) {
      const y = offsetY + row * effectiveTailleCase;
      const height = step * effectiveTailleCase;
      
      if (y + height < -50 || y > window.innerHeight + 50) continue;
      
      // Afficher uniquement si ce n'est pas un multiple de 10
      if (row % 10 === 0) continue;
      
      marks.push(
        <div
          key={`s-${row}`}
          className="absolute flex items-center justify-center select-none"
          style={{
            left: `${primaryWidth}px`,
            top: `${y}px`,
            width: `${secondaryWidth}px`,
            height: `${height}px`,
            color: textColor,
            fontSize: '10px',
          }}
        >
          {row + 1}
        </div>
      );
    }
    return marks;
  }, [nbLignes, effectiveTailleCase, offsetY, zoom, showSecondary]);

  // Indicateur de position actuelle (trait jaune)
  const currentViewIndicator = useMemo(() => {
    if (currentViewRow === null) return null;
    
    const y = offsetY + currentViewRow * effectiveTailleCase;
    
    return (
      <div
        className="absolute pointer-events-none"
        style={{
          left: 0,
          top: `${y}px`,
          width: `${totalWidth}px`,
          height: '2px',
          backgroundColor: currentViewColor,
          boxShadow: '0 0 6px rgba(255, 201, 74, 0.8)',
          zIndex: 10,
        }}
      />
    );
  }, [currentViewRow, offsetY, effectiveTailleCase, totalWidth]);

  // Indicateur du centre de la grille (trait rouge)
  const centerIndicator = useMemo(() => {
    const y = offsetY + centerRow * effectiveTailleCase;
    
    return (
      <div
        className="absolute pointer-events-none"
        style={{
          left: 0,
          top: `${y}px`,
          width: `${totalWidth}px`,
          height: '3px',
          backgroundColor: centerColor,
          boxShadow: '0 0 8px rgba(255, 107, 107, 0.6)',
          zIndex: 15,
        }}
      />
    );
  }, [centerRow, offsetY, effectiveTailleCase, totalWidth]);

  return (
    <div
      className="flex-shrink-0 overflow-hidden relative select-none"
      style={{
        width: `${totalWidth}px`,
        backgroundColor: bgColor,
        borderRight: `1px solid ${borderColor}`,
        cursor: isDragging ? 'grabbing' : 'grab',
        touchAction: 'none',
      }}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerCancel={handlePointerUp}
      title="Cliquez pour naviguer • Glissez pour défiler"
    >
      {primaryMarks}
      {secondaryMarks}
      {centerIndicator}
      {currentViewIndicator}
    </div>
  );
}

// Coin GPS (intersection des deux règles)
export function RulerCorner({ showSecondary = true, zoom = 1, onGPSInput = null }) {
  const bgColor = '#000000';
  const borderColor = '#333';
  const textColor = '#FFC94A';
  
  const primaryHeight = 28;
  const secondaryHeight = showSecondary && zoom >= 0.6 ? 18 : 0;
  const totalHeight = primaryHeight + secondaryHeight;
  
  const primaryWidth = 32;
  const secondaryWidth = showSecondary && zoom >= 0.6 ? 20 : 0;
  const totalWidth = primaryWidth + secondaryWidth;

  return (
    <div
      className="flex-shrink-0 flex items-center justify-center cursor-pointer hover:bg-gray-900 transition-colors"
      style={{
        width: `${totalWidth}px`,
        height: `${totalHeight}px`,
        backgroundColor: bgColor,
        borderRight: `1px solid ${borderColor}`,
        borderBottom: `1px solid ${borderColor}`,
      }}
      onClick={onGPSInput}
      title="Entrer des coordonnées GPS"
    >
      <span 
        className="font-bold"
        style={{ 
          fontSize: '11px', 
          color: textColor,
          textShadow: '0 0 4px rgba(255, 201, 74, 0.3)'
        }}
      >
        GPS
      </span>
    </div>
  );
}

// Export de la fonction utilitaire
export { rowToLetter };

// Utilitaire pour parser une coordonnée GPS
export function parseGPSCoordinate(input) {
  if (!input) return null;
  
  const match = input.toUpperCase().match(/^([A-Z]{1,2})(\d+)$/);
  if (!match) return null;
  
  const letter = match[1];
  const number = parseInt(match[2], 10);
  
  let letterIndex = 0;
  if (letter.length === 1) {
    letterIndex = letter.charCodeAt(0) - 65;
  } else {
    letterIndex = (letter.charCodeAt(0) - 65 + 1) * 26 + (letter.charCodeAt(1) - 65);
  }
  
  const row = letterIndex * 10;
  const col = (number - 1) * 10;
  
  return {
    letter,
    number,
    row,
    col,
    centerRow: row + 5,
    centerCol: col + 5
  };
}