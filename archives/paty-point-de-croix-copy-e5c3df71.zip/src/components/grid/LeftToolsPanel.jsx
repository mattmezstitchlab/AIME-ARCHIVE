import React, { useState } from 'react';
import { cn } from '@/lib/utils';
import {
  Hand,
  Eraser,
  Pipette,
  Circle,
  Slash,
  Sun,
  Type,
  Library,
  Calendar,
  ZoomIn,
  ZoomOut,
  Maximize2,
  Target,
  Grid3x3,
  Eye,
  Ruler,
  ChevronDown,
  ChevronRight,
  Sparkles,
  RotateCcw,
  Maximize,
  Moon,
  Crosshair,
  Hash,
  Move,
  Copy,
  Route,
  AlertTriangle,
  AlignCenter,
  Minimize2,
  Maximize as Expand,
  Image,
  ImagePlus,
  Grid
} from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import MiniMap4D from './MiniMap4D';

export default function LeftToolsPanel({
  currentTool,
  onToolSelect,
  onZoomIn,
  onZoomOut,
  onResetZoom,
  onCenter,
  showMosaicGuides,
  onToggleMosaicGuides,
  showCenterMarker,
  onToggleCenterMarker,
  onChangeFormat,
  onOpenTextMotif,
  onOpenMotifLibrary,
  onOpenOptimization,
  isDailyZoneActive,
  onToggleDailyZone,
  showPatternImage,
  onTogglePatternImage,
  showPatternSymbols,
  onTogglePatternSymbols,
  showGrid,
  onToggleGrid,
  onZoomToColor,
  onZoomToDenseZone,
  onZoomToIsolated,
  miniMapProps,
  showFloatingMiniMap,
  onToggleFloating,
  miniMapSyncAuto,
  onToggleSyncAuto,
  miniMapOverlays,
  onUpdateOverlays,
  visualGuides,
  onUpdateVisualGuides
}) {
  // ===== TOUS LES HOOKS EN HAUT - TOUJOURS APPELÉS =====
  const [expandedSections, setExpandedSections] = useState({
    miniMap: true,
    display6D: false,
    display: true
  });
  const [miniMapTab, setMiniMapTab] = useState('navigation');
  const [autoSync, setAutoSync] = useState(true);
  const [displayMode, setDisplayMode] = useState('gridSymbols');
  const [gridIntensity, setGridIntensity] = useState(60);
  const [symbolsContrast, setSymbolsContrast] = useState(100);
  const [imageOpacity, setImageOpacity] = useState(80);
  const [nightMode, setNightMode] = useState(false);
  const [colorMode6D, setColorMode6D] = useState('dmcnormal');
  const [iaVisuEnabled, setIaVisuEnabled] = useState(true);
  const [antiErrorMode, setAntiErrorMode] = useState(false);

  // ===== FONCTIONS =====
  const toggleSection = (section) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };



  return (
      <aside className="w-[260px] bg-white shadow-lg flex-shrink-0 overflow-y-auto relative">
        <div className="p-3 space-y-3">
        


        {/* BLOC OUTILS DE GRILLE PRO™ */}
        <div className="bg-white rounded-lg border border-slate-200">
          <div className="px-3 py-2 bg-slate-50 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-slate-600" />
              <span className="text-sm font-semibold text-slate-700">Outils de grille Pro™</span>
            </div>
          </div>

          <div className="p-3">
            <div className="grid grid-cols-2 gap-2">
              <TooltipProvider>
                {/* 1. Sélection magique IA™ */}
                <Tooltip>
                  <TooltipTrigger asChild>
                    <button
                      onClick={() => onToolSelect('selection-ia')}
                      className={cn(
                        "h-20 flex flex-col items-center justify-center gap-1.5 rounded-lg transition-all",
                        currentTool === 'selection-ia'
                          ? "bg-slate-900 text-white shadow-md"
                          : "bg-slate-100 hover:bg-slate-200 text-slate-700"
                      )}
                    >
                      <Sparkles className="w-6 h-6" />
                      <span className="text-[10px] font-medium text-center">Sélection IA</span>
                    </button>
                  </TooltipTrigger>
                  <TooltipContent side="right">
                    <p>Sélectionner automatiquement des zones de points<br/>(même couleur, même symbole, zones isolées, zones à optimiser)</p>
                  </TooltipContent>
                </Tooltip>

                {/* 2. Gomme Pro™ */}
                <Tooltip>
                  <TooltipTrigger asChild>
                    <button
                      onClick={() => onToolSelect('erase')}
                      className={cn(
                        "h-20 flex flex-col items-center justify-center gap-1.5 rounded-lg transition-all",
                        currentTool === 'erase'
                          ? "bg-slate-900 text-white shadow-md"
                          : "bg-slate-100 hover:bg-slate-200 text-slate-700"
                      )}
                    >
                      <Eraser className="w-6 h-6" />
                      <span className="text-[10px] font-medium text-center">Gomme Pro</span>
                    </button>
                  </TooltipTrigger>
                  <TooltipContent side="right">
                    <p>Effacer des points, des zones ou corriger<br/>les erreurs automatiquement</p>
                  </TooltipContent>
                </Tooltip>

                {/* 3. Pipette intelligente™ */}
                <Tooltip>
                  <TooltipTrigger asChild>
                    <button
                      onClick={() => onToolSelect('symbol-picker')}
                      className={cn(
                        "h-20 flex flex-col items-center justify-center gap-1.5 rounded-lg transition-all",
                        currentTool === 'symbol-picker'
                          ? "bg-slate-900 text-white shadow-md"
                          : "bg-slate-100 hover:bg-slate-200 text-slate-700"
                      )}
                    >
                      <Pipette className="w-6 h-6" />
                      <span className="text-[10px] font-medium text-center">Pipette</span>
                    </button>
                  </TooltipTrigger>
                  <TooltipContent side="right">
                    <p>Prendre une couleur ou un symbole depuis la grille<br/>et ouvrir les options avancées de cette couleur</p>
                  </TooltipContent>
                </Tooltip>

                {/* 4. Point Pro (× / ½ ×)™ */}
                <Tooltip>
                  <TooltipTrigger asChild>
                    <button
                      onClick={() => onToolSelect('cross')}
                      className={cn(
                        "h-20 flex flex-col items-center justify-center gap-1.5 rounded-lg transition-all",
                        currentTool === 'cross'
                          ? "bg-slate-900 text-white shadow-md"
                          : "bg-slate-100 hover:bg-slate-200 text-slate-700"
                      )}
                    >
                      <Circle className="w-6 h-6" />
                      <span className="text-[10px] font-medium text-center">Point Pro</span>
                    </button>
                  </TooltipTrigger>
                  <TooltipContent side="right">
                    <p>Ajouter ou corriger les points (croix, demi-points,<br/>points spéciaux) selon les règles de ta grille</p>
                  </TooltipContent>
                </Tooltip>

                {/* 5. Reformer & réaligner™ */}
                <Tooltip>
                  <TooltipTrigger asChild>
                    <button
                      onClick={() => onToolSelect('realign')}
                      className={cn(
                        "h-20 flex flex-col items-center justify-center gap-1.5 rounded-lg transition-all",
                        currentTool === 'realign'
                          ? "bg-slate-900 text-white shadow-md"
                          : "bg-slate-100 hover:bg-slate-200 text-slate-700"
                      )}
                    >
                      <Ruler className="w-6 h-6" />
                      <span className="text-[10px] font-medium text-center">Réaligner</span>
                    </button>
                  </TooltipTrigger>
                  <TooltipContent side="right">
                    <p>Lisser les contours, réaligner les lignes<br/>et corriger les dégradés automatiquement</p>
                  </TooltipContent>
                </Tooltip>

                {/* 6. Visuel+™ */}
                <Tooltip>
                  <TooltipTrigger asChild>
                    <button
                      onClick={() => onToolSelect('visual')}
                      className={cn(
                        "h-20 flex flex-col items-center justify-center gap-1.5 rounded-lg transition-all",
                        currentTool === 'visual'
                          ? "bg-slate-900 text-white shadow-md"
                          : "bg-slate-100 hover:bg-slate-200 text-slate-700"
                      )}
                    >
                      <Eye className="w-6 h-6" />
                      <span className="text-[10px] font-medium text-center">Visuel+</span>
                    </button>
                  </TooltipTrigger>
                  <TooltipContent side="right">
                    <p>Afficher / cacher le visuel importé<br/>et ajuster sa transparence</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
          </div>
        </div>

        {/* BLOC AFFICHAGE 6D™ */}
        <div className="bg-white rounded-lg border border-slate-200">
          <button
            onClick={() => toggleSection('display6D')}
            className="w-full px-3 py-2 flex items-center justify-between hover:bg-slate-50 rounded-t-lg"
          >
            <div className="flex items-center gap-2">
              <Eye className="w-4 h-4 text-slate-600" />
              <span className="text-sm font-semibold text-slate-700">Affichage 6D™</span>
            </div>
            {expandedSections.display6D ? (
              <ChevronDown className="w-4 h-4 text-slate-400" />
            ) : (
              <ChevronRight className="w-4 h-4 text-slate-400" />
            )}
          </button>

          {expandedSections.display6D && (
            <div className="p-3 border-t border-slate-100 space-y-4">
              
              {/* Mode de vue */}
              <div>
                <label className="text-xs font-medium text-slate-700 mb-2 block">Mode de vue</label>
                <div className="grid grid-cols-2 gap-1.5">
                  <button
                    onClick={() => setDisplayMode('gridSymbols')}
                    className={cn(
                      "px-2 py-2 rounded text-xs font-medium transition-colors flex flex-col items-center gap-1",
                      displayMode === 'gridSymbols'
                        ? "bg-slate-900 text-white"
                        : "bg-slate-100 hover:bg-slate-200 text-slate-700"
                    )}
                  >
                    <Grid3x3 className="w-4 h-4" />
                    <span>Grille + symboles</span>
                  </button>
                  <button
                    onClick={() => setDisplayMode('gridOnly')}
                    className={cn(
                      "px-2 py-2 rounded text-xs font-medium transition-colors flex flex-col items-center gap-1",
                      displayMode === 'gridOnly'
                        ? "bg-slate-900 text-white"
                        : "bg-slate-100 hover:bg-slate-200 text-slate-700"
                    )}
                  >
                    <Grid className="w-4 h-4" />
                    <span>Grille seule</span>
                  </button>
                  <button
                    onClick={() => setDisplayMode('photoGrid')}
                    className={cn(
                      "px-2 py-2 rounded text-xs font-medium transition-colors flex flex-col items-center gap-1",
                      displayMode === 'photoGrid'
                        ? "bg-slate-900 text-white"
                        : "bg-slate-100 hover:bg-slate-200 text-slate-700"
                    )}
                  >
                    <ImagePlus className="w-4 h-4" />
                    <span>Photo + grille</span>
                  </button>
                  <button
                    onClick={() => setDisplayMode('photoOnly')}
                    className={cn(
                      "px-2 py-2 rounded text-xs font-medium transition-colors flex flex-col items-center gap-1",
                      displayMode === 'photoOnly'
                        ? "bg-slate-900 text-white"
                        : "bg-slate-100 hover:bg-slate-200 text-slate-700"
                    )}
                  >
                    <Image className="w-4 h-4" />
                    <span>Photo seule</span>
                  </button>
                </div>
              </div>

              {/* Luminosité & contraste */}
              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-700">Luminosité & contraste</label>
                
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-[10px] text-slate-600">
                    <span>Intensité de la grille</span>
                    <span>{gridIntensity}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={gridIntensity}
                    onChange={(e) => setGridIntensity(Number(e.target.value))}
                    className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-slate-900"
                  />
                </div>

                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-[10px] text-slate-600">
                    <span>Contraste des symboles</span>
                    <span>{symbolsContrast}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="200"
                    value={symbolsContrast}
                    onChange={(e) => setSymbolsContrast(Number(e.target.value))}
                    className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-slate-900"
                  />
                </div>

                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-[10px] text-slate-600">
                    <span>Opacité du visuel importé</span>
                    <span>{imageOpacity}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={imageOpacity}
                    onChange={(e) => setImageOpacity(Number(e.target.value))}
                    className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-slate-900"
                  />
                </div>
              </div>

              {/* Mode Vision Nocturne */}
              <div className="flex items-center justify-between p-2 bg-slate-50 rounded-lg">
                <div className="flex items-center gap-2">
                  <Moon className="w-4 h-4 text-slate-600" />
                  <span className="text-xs text-slate-700">Mode Vision Nocturne</span>
                </div>
                <button
                  onClick={() => setNightMode(!nightMode)}
                  className={cn(
                    "relative inline-flex h-5 w-9 items-center rounded-full transition-colors",
                    nightMode ? "bg-slate-900" : "bg-slate-300"
                  )}
                >
                  <span
                    className={cn(
                      "inline-block h-4 w-4 transform rounded-full bg-white transition-transform",
                      nightMode ? "translate-x-5" : "translate-x-0.5"
                    )}
                  />
                </button>
              </div>

              {/* Guides & aides visuelles */}
              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-700">Guides & aides visuelles</label>
                <div className="space-y-1.5">
                  {[
                    { id: 'centerMark', label: 'Repère central', icon: Crosshair },
                    { id: 'grid10x10', label: 'Repères 10×10', icon: Hash },
                    { id: 'mainGrid', label: 'Grille principale', icon: Grid3x3 },
                    { id: 'axesXY', label: 'Axes X / Y', icon: Move },
                    { id: 'symbolClusters', label: 'Symboles dupliqués', icon: Copy },
                    { id: 'threadPath', label: 'Chemins de broderie', icon: Route }
                  ].map((guide) => {
                    const Icon = guide.icon;
                    const isActive = visualGuides[guide.id];
                    return (
                      <button
                        key={guide.id}
                        onClick={() => {
                          onUpdateVisualGuides({
                            ...visualGuides,
                            [guide.id]: !isActive
                          });
                        }}
                        className={cn(
                          "w-full flex items-center justify-between px-2 py-1.5 rounded transition-colors",
                          isActive ? "bg-slate-900 text-white" : "bg-slate-100 hover:bg-slate-200 text-slate-700"
                        )}
                      >
                        <div className="flex items-center gap-2">
                          <Icon className="w-3.5 h-3.5" />
                          <span className="text-xs">{guide.label}</span>
                        </div>
                        <div className={cn("w-4 h-4 rounded border-2 flex items-center justify-center", 
                          isActive ? "border-white" : "border-slate-300")}>
                          {isActive && <span className="text-[10px]">✓</span>}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Mode colorimétrique */}
              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-700">Mode colorimétrique</label>
                <select
                  value={colorMode6D}
                  onChange={(e) => setColorMode6D(e.target.value)}
                  className="w-full px-2 py-1.5 text-xs border border-slate-200 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-slate-900"
                >
                  <option value="dmcnormal">Vue DMC (standard)</option>
                  <option value="highContrast">Haute lisibilité</option>
                  <option value="daltoSafe">Daltonisme-safe</option>
                  <option value="pastel">Pastel doux</option>
                  <option value="hyperContrast">Super-Contraste 300%</option>
                  <option value="monoCheck">Monochrome de contrôle</option>
                </select>
              </div>

              {/* Boutons d'alignement */}
              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-700">Alignement</label>
                <div className="grid grid-cols-3 gap-1.5">
                  <button
                    onClick={onCenter}
                    className="px-2 py-2 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors flex flex-col items-center gap-1"
                  >
                    <AlignCenter className="w-4 h-4" />
                    <span className="text-[10px]">Centrer</span>
                  </button>
                  <button
                    onClick={onCenter}
                    className="px-2 py-2 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors flex flex-col items-center gap-1"
                  >
                    <Minimize2 className="w-4 h-4" />
                    <span className="text-[10px]">Adapter</span>
                  </button>
                  <button
                    onClick={() => document.documentElement.requestFullscreen()}
                    className="px-2 py-2 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors flex flex-col items-center gap-1"
                  >
                    <Expand className="w-4 h-4" />
                    <span className="text-[10px]">Plein écran</span>
                  </button>
                </div>
              </div>

              {/* IA-Visu™ */}
              <div className="p-2.5 bg-gradient-to-r from-indigo-50 to-purple-50 rounded-lg border border-indigo-200">
                <div className="flex items-start justify-between mb-1.5">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-indigo-600" />
                    <span className="text-xs font-semibold text-slate-900">IA-Visu™</span>
                  </div>
                  <button
                    onClick={() => setIaVisuEnabled(!iaVisuEnabled)}
                    className={cn(
                      "relative inline-flex h-5 w-9 items-center rounded-full transition-colors",
                      iaVisuEnabled ? "bg-indigo-600" : "bg-slate-300"
                    )}
                  >
                    <span
                      className={cn(
                        "inline-block h-4 w-4 transform rounded-full bg-white transition-transform",
                        iaVisuEnabled ? "translate-x-5" : "translate-x-0.5"
                      )}
                    />
                  </button>
                </div>
                <p className="text-[10px] text-slate-600 leading-relaxed">
                  Ajuste l'affichage selon la luminosité, le type de modèle et la complexité des couleurs.
                </p>
              </div>

              {/* Mode Anti-Erreur™ */}
              <div className="p-2.5 bg-amber-50 rounded-lg border border-amber-200">
                <div className="flex items-start justify-between mb-1.5">
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-amber-600" />
                    <span className="text-xs font-semibold text-slate-900">Mode Anti-Erreur™</span>
                  </div>
                  <button
                    onClick={() => setAntiErrorMode(!antiErrorMode)}
                    className={cn(
                      "relative inline-flex h-5 w-9 items-center rounded-full transition-colors",
                      antiErrorMode ? "bg-amber-600" : "bg-slate-300"
                    )}
                  >
                    <span
                      className={cn(
                        "inline-block h-4 w-4 transform rounded-full bg-white transition-transform",
                        antiErrorMode ? "translate-x-5" : "translate-x-0.5"
                      )}
                    />
                  </button>
                </div>
                <p className="text-[10px] text-slate-600 leading-relaxed">
                  Met automatiquement en évidence les zones ambiguës, symboles similaires ou risques de confusion.
                </p>
              </div>

            </div>
          )}
        </div>



        {/* BLOC MINI-CARTE 4D™ */}
        <div className="bg-white rounded-lg border border-slate-200">
          <button
            onClick={() => toggleSection('miniMap')}
            className="w-full px-3 py-2 flex items-center justify-between hover:bg-slate-50 rounded-t-lg"
          >
            <div className="flex items-center gap-2">
              <Target className="w-4 h-4 text-slate-600" />
              <span className="text-sm font-semibold text-slate-700">Mini-carte 4D™</span>
            </div>
            {expandedSections.miniMap ? (
              <ChevronDown className="w-4 h-4 text-slate-400" />
            ) : (
              <ChevronRight className="w-4 h-4 text-slate-400" />
            )}
          </button>

          {(expandedSections.miniMap && miniMapProps) && (
            <div className="p-3 border-t border-slate-100 space-y-3">
              {/* Sous-en-tête */}
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs font-medium text-slate-700">Mini-carte</div>
                  <div className="text-[10px] text-slate-500">Navigation rapide</div>
                </div>
                <div className="text-xs text-slate-600 bg-slate-100 px-2 py-1 rounded">
                  Zoom: {Math.round(miniMapProps.zoom * 100)}%
                </div>
              </div>

              {/* Toggle mini-carte flottante */}
              <div className="flex items-center justify-between p-2 bg-slate-50 rounded-lg">
                <span className="text-xs text-slate-700">Mini-carte flottante</span>
                <button
                  onClick={() => onToggleFloating(!showFloatingMiniMap)}
                  className={cn(
                    "relative inline-flex h-5 w-9 items-center rounded-full transition-colors",
                    showFloatingMiniMap ? "bg-slate-900" : "bg-slate-300"
                  )}
                >
                  <span
                    className={cn(
                      "inline-block h-4 w-4 transform rounded-full bg-white transition-transform",
                      showFloatingMiniMap ? "translate-x-5" : "translate-x-0.5"
                    )}
                  />
                </button>
              </div>

              {/* Onglets */}
              <div className="flex gap-1 bg-slate-100 rounded-lg p-1">
                <button
                  onClick={() => setMiniMapTab('navigation')}
                  className={cn(
                    "flex-1 px-2 py-1 rounded text-xs font-medium transition-colors",
                    miniMapTab === 'navigation'
                      ? "bg-white text-slate-900 shadow-sm"
                      : "text-slate-600 hover:text-slate-900"
                  )}
                >
                  Navigation
                </button>
                <button
                  onClick={() => setMiniMapTab('colors')}
                  className={cn(
                    "flex-1 px-2 py-1 rounded text-xs font-medium transition-colors",
                    miniMapTab === 'colors'
                      ? "bg-white text-slate-900 shadow-sm"
                      : "text-slate-600 hover:text-slate-900"
                  )}
                >
                  Couleurs
                </button>
                <button
                  onClick={() => setMiniMapTab('ia-focus')}
                  className={cn(
                    "flex-1 px-2 py-1 rounded text-xs font-medium transition-colors",
                    miniMapTab === 'ia-focus'
                      ? "bg-white text-slate-900 shadow-sm"
                      : "text-slate-600 hover:text-slate-900"
                  )}
                >
                  IA-Focus
                </button>
              </div>

              {/* Zone de mini-carte */}
              <div className="border border-slate-200 rounded-lg overflow-hidden bg-slate-50">
                <MiniMap4D
                  {...miniMapProps}
                  showMosaicGuides={showMosaicGuides}
                  onToggleMosaicGuides={onToggleMosaicGuides}
                  showCenterMarker={showCenterMarker}
                  onToggleCenterMarker={onToggleCenterMarker}
                  onZoomIn={onZoomIn}
                  onZoomOut={onZoomOut}
                  onResetZoom={onResetZoom}
                />
              </div>

              {/* Barre de zoom */}
              <div className="grid grid-cols-4 gap-2">
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <button
                        onClick={onZoomOut}
                        className="h-8 flex items-center justify-center rounded-lg bg-slate-100 hover:bg-slate-200 transition-colors"
                      >
                        <ZoomOut className="w-4 h-4 text-slate-700" />
                      </button>
                    </TooltipTrigger>
                    <TooltipContent><p>Zoom -</p></TooltipContent>
                  </Tooltip>

                  <Tooltip>
                    <TooltipTrigger asChild>
                      <button
                        onClick={onZoomIn}
                        className="h-8 flex items-center justify-center rounded-lg bg-slate-100 hover:bg-slate-200 transition-colors"
                      >
                        <ZoomIn className="w-4 h-4 text-slate-700" />
                      </button>
                    </TooltipTrigger>
                    <TooltipContent><p>Zoom +</p></TooltipContent>
                  </Tooltip>

                  <Tooltip>
                    <TooltipTrigger asChild>
                      <button
                        onClick={onResetZoom}
                        className="h-8 flex items-center justify-center rounded-lg bg-slate-100 hover:bg-slate-200 transition-colors"
                      >
                        <RotateCcw className="w-4 h-4 text-slate-700" />
                      </button>
                    </TooltipTrigger>
                    <TooltipContent><p>Réinitialiser vue</p></TooltipContent>
                  </Tooltip>

                  <Tooltip>
                    <TooltipTrigger asChild>
                      <button
                        onClick={onCenter}
                        className="h-8 flex items-center justify-center rounded-lg bg-slate-100 hover:bg-slate-200 transition-colors"
                      >
                        <Maximize className="w-4 h-4 text-slate-700" />
                      </button>
                    </TooltipTrigger>
                    <TooltipContent><p>Plein cadre</p></TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>

              {/* Toggle Sync auto */}
              <div className="flex items-center justify-between pt-2 border-t border-slate-200">
                <span className="text-xs text-slate-700">Sync auto</span>
                <button
                  onClick={() => onToggleSyncAuto(!miniMapSyncAuto)}
                  className={cn(
                    "relative inline-flex h-5 w-9 items-center rounded-full transition-colors",
                    miniMapSyncAuto ? "bg-slate-900" : "bg-slate-300"
                  )}
                >
                  <span
                    className={cn(
                      "inline-block h-4 w-4 transform rounded-full bg-white transition-transform",
                      miniMapSyncAuto ? "translate-x-5" : "translate-x-0.5"
                    )}
                  />
                </button>
              </div>

              {/* Couches visibles */}
              <div className="pt-2 border-t border-slate-200 space-y-2">
                <label className="text-xs font-medium text-slate-700">Couches visibles</label>
                <div className="space-y-1.5">
                  <button
                    onClick={() => onUpdateOverlays({ ...miniMapOverlays, showCenter: !miniMapOverlays.showCenter })}
                    className={cn(
                      "w-full flex items-center justify-between px-2 py-1.5 rounded text-xs transition-colors",
                      miniMapOverlays.showCenter ? "bg-slate-900 text-white" : "bg-slate-100 hover:bg-slate-200 text-slate-700"
                    )}
                  >
                    <div className="flex items-center gap-2">
                      <Crosshair className="w-3.5 h-3.5" />
                      <span>Repère central</span>
                    </div>
                  </button>
                  <button
                    onClick={() => onUpdateOverlays({ ...miniMapOverlays, show10x10Blocks: !miniMapOverlays.show10x10Blocks })}
                    className={cn(
                      "w-full flex items-center justify-between px-2 py-1.5 rounded text-xs transition-colors",
                      miniMapOverlays.show10x10Blocks ? "bg-slate-900 text-white" : "bg-slate-100 hover:bg-slate-200 text-slate-700"
                    )}
                  >
                    <div className="flex items-center gap-2">
                      <Hash className="w-3.5 h-3.5" />
                      <span>Blocs 10×10</span>
                    </div>
                  </button>
                  <button
                    onClick={() => onUpdateOverlays({ ...miniMapOverlays, showColorHeat: !miniMapOverlays.showColorHeat })}
                    className={cn(
                      "w-full flex items-center justify-between px-2 py-1.5 rounded text-xs transition-colors",
                      miniMapOverlays.showColorHeat ? "bg-slate-900 text-white" : "bg-slate-100 hover:bg-slate-200 text-slate-700"
                    )}
                  >
                    <div className="flex items-center gap-2">
                      <Eye className="w-3.5 h-3.5" />
                      <span>Carte de couleur</span>
                    </div>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        </div>
      </aside>
  );
}