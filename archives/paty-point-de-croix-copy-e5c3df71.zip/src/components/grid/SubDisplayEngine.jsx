import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { toast } from 'sonner';
import SubDisplayToolbar, { SUB_DISPLAY_MODES } from './SubDisplayToolbar';

// Couleurs optimisées pour daltoniens
const DALTONIEN_PALETTE = [
  '#000000', '#E69F00', '#56B4E9', '#009E73', '#F0E442',
  '#0072B2', '#D55E00', '#CC79A7', '#999999', '#FFFFFF'
];

// Contraste des symboles pour daltoniens
const DALTONIEN_SYMBOLS = {
  enhanced: true,
  strokeWidth: 2,
  fontSize: 1.4
};

export default function SubDisplayEngine({
  pattern,
  gridConfig,
  onGridConfigChange,
  children
}) {
  // États d'affichage
  const [displayOptions, setDisplayOptions] = useState({
    showSymbols: true,
    showColors: true,
    showCoordinates: true,
    showCenterMarker: true,
    showGoldenLine: false,
    showQuadrants: false,
    daltonianMode: false,
    zeroHoleVerified: false,
    displayMode: 'classic',
    selectedSymbolFilter: null,
    antiAliasing: true
  });

  // Loupe dynamique
  const [loupe, setLoupe] = useState({
    active: false,
    x: 0,
    y: 0,
    zoom: 3
  });

  // Vérification Zéro Trou
  const zeroHoleStatus = useMemo(() => {
    if (!pattern?.symbolGrid) return { valid: false, holes: 0, anomalies: [] };

    let holes = 0;
    const anomalies = [];

    pattern.symbolGrid.forEach((row, rowIdx) => {
      row.forEach((cell, colIdx) => {
        if (!cell) {
          holes++;
          anomalies.push({ row: rowIdx, col: colIdx, type: 'hole' });
        } else if (!cell.colorId) {
          anomalies.push({ row: rowIdx, col: colIdx, type: 'noColor' });
        }
      });
    });

    return {
      valid: holes === 0 && anomalies.length === 0,
      holes,
      anomalies
    };
  }, [pattern?.symbolGrid]);

  // Statistiques de la grille
  const gridStats = useMemo(() => {
    if (!pattern?.symbolGrid) return null;

    const symbolCounts = {};
    const colorCounts = {};
    let totalPoints = 0;

    pattern.symbolGrid.forEach(row => {
      row.forEach(cell => {
        if (cell) {
          totalPoints++;
          const symbol = cell.symbol || '●';
          const colorId = cell.colorId;
          symbolCounts[symbol] = (symbolCounts[symbol] || 0) + 1;
          colorCounts[colorId] = (colorCounts[colorId] || 0) + 1;
        }
      });
    });

    return {
      totalPoints,
      uniqueSymbols: Object.keys(symbolCounts).length,
      uniqueColors: Object.keys(colorCounts).length,
      symbolCounts,
      colorCounts
    };
  }, [pattern?.symbolGrid]);

  // Handlers
  const handleZoomIn = useCallback(() => {
    onGridConfigChange?.(prev => ({
      ...prev,
      zoom: Math.min(prev.zoom * 1.25, 8)
    }));
  }, [onGridConfigChange]);

  const handleZoomOut = useCallback(() => {
    onGridConfigChange?.(prev => ({
      ...prev,
      zoom: Math.max(prev.zoom / 1.25, 0.1)
    }));
  }, [onGridConfigChange]);

  const handleCenter = useCallback(() => {
    if (!pattern) return;
    
    // Calculer le centre du pattern
    const centerX = (pattern.width / 2) * gridConfig.taille_case;
    const centerY = (pattern.height / 2) * gridConfig.taille_case;
    
    onGridConfigChange?.(prev => ({
      ...prev,
      offset_x: window.innerWidth / 2 - centerX * prev.zoom,
      offset_y: window.innerHeight / 2 - centerY * prev.zoom
    }));
    
    toast.info('Vue centrée sur la grille');
  }, [pattern, gridConfig, onGridConfigChange]);

  const handleToggleSymbols = useCallback(() => {
    setDisplayOptions(prev => {
      const newValue = !prev.showSymbols;
      toast.info(newValue ? 'Symboles affichés' : 'Symboles masqués');
      return { ...prev, showSymbols: newValue };
    });
  }, []);

  const handleToggleColors = useCallback(() => {
    setDisplayOptions(prev => {
      const newValue = !prev.showColors;
      toast.info(newValue ? 'Couleurs affichées' : 'Couleurs masquées (symboles seuls)');
      return { ...prev, showColors: newValue };
    });
  }, []);

  const handleSelectSymbol = useCallback((symbolId) => {
    setDisplayOptions(prev => {
      if (symbolId === prev.selectedSymbolFilter) {
        toast.info('Filtre symbole désactivé');
        return { ...prev, selectedSymbolFilter: null };
      }
      
      if (symbolId) {
        const color = pattern?.colorPalette?.find(c => c.id === symbolId);
        toast.info(`Symbole isolé : ${color?.symbol || color?.assignedSymbolChar || '●'}`);
      }
      
      return { ...prev, selectedSymbolFilter: symbolId };
    });
  }, [pattern]);

  const handleToggleDaltonianMode = useCallback(() => {
    setDisplayOptions(prev => {
      const newValue = !prev.daltonianMode;
      toast.info(newValue ? 'Mode Daltonien activé' : 'Mode Daltonien désactivé');
      return { ...prev, daltonianMode: newValue };
    });
  }, []);

  const handleToggleZeroHoleCheck = useCallback(() => {
    setDisplayOptions(prev => ({
      ...prev,
      zeroHoleVerified: zeroHoleStatus.valid
    }));
  }, [zeroHoleStatus]);

  const handleDisplayModeChange = useCallback((mode) => {
    setDisplayOptions(prev => ({ ...prev, displayMode: mode }));
    
    // Ajuster la taille des cases selon le mode
    const modeConfig = SUB_DISPLAY_MODES[mode.toUpperCase()];
    if (modeConfig && onGridConfigChange) {
      onGridConfigChange(prev => ({
        ...prev,
        taille_case: 25 * modeConfig.cellRatio
      }));
    }
  }, [onGridConfigChange]);

  // Appliquer les couleurs daltonien
  const getDisplayColor = useCallback((color) => {
    if (!displayOptions.daltonianMode) return color.hex || color.dmcHex;
    
    // Mapper vers la palette daltonien
    const colorIndex = pattern?.colorPalette?.findIndex(c => c.id === color.id) || 0;
    return DALTONIEN_PALETTE[colorIndex % DALTONIEN_PALETTE.length];
  }, [displayOptions.daltonianMode, pattern?.colorPalette]);

  // Contexte de rendu pour le canvas
  const renderContext = useMemo(() => ({
    ...displayOptions,
    getDisplayColor,
    zeroHoleStatus,
    gridStats,
    loupe,
    daltonienSymbols: displayOptions.daltonianMode ? DALTONIEN_SYMBOLS : null
  }), [displayOptions, getDisplayColor, zeroHoleStatus, gridStats, loupe]);

  // Exposer le contexte globalement
  useEffect(() => {
    if (typeof window !== 'undefined') {
      window.subDisplayContext = renderContext;
    }
    return () => {
      if (typeof window !== 'undefined') {
        delete window.subDisplayContext;
      }
    };
  }, [renderContext]);

  // Message de validation
  useEffect(() => {
    if (displayOptions.zeroHoleVerified && zeroHoleStatus.valid) {
      // Le message est déjà affiché dans handleToggleZeroHoleCheck
    }
  }, [displayOptions.zeroHoleVerified, zeroHoleStatus.valid]);

  return (
    <div className="relative h-full">
      {/* Contenu enfant (canvas) */}
      {children}
    </div>
  );
}