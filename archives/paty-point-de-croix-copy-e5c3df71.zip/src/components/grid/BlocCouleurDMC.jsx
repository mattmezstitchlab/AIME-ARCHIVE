import React, { useState } from 'react';
import { cn } from '@/lib/utils';
import { AlertCircle } from 'lucide-react';
import ColorOptionsPanel from './ColorOptionsPanel';

export default function BlocCouleurDMC({
  color,
  isSelected,
  onClick,
  onChangeSymbol,
  onMerge,
  onIsolate,
  onHide,
  onDuplicate,
  onDelete,
  onMarkAsStitched,
  onFindInGrid,
  onShowOptimalPath,
  onShowRiskZones,
  onReplaceWithSimilar,
  onAiSuggestions,
  onOptimize
}) {
  const [showOptionsPanel, setShowOptionsPanel] = useState(false);
  const isDone = (color.progress || 0) === 100;
  const hasLowConfidence = color.confidence === 'low';
  
  const handleColorBandClick = (e) => {
    e.stopPropagation();
    onClick?.();
  };

  const handleSymbolClick = (e) => {
    e.stopPropagation();
    onChangeSymbol?.(color);
  };

  const handleTogglePanel = (e) => {
    e.stopPropagation();
    setShowOptionsPanel(!showOptionsPanel);
  };
  
  return (
    <div
      className={cn(
        "flex-shrink-0 bg-white rounded-lg transition-all relative group",
        isSelected 
          ? "ring-2 ring-slate-800 shadow-lg" 
          : "border border-slate-300 hover:border-slate-400 shadow-sm hover:shadow-md"
      )}
      style={{ 
        width: '140px',
        minWidth: '140px',
        height: '95px'
      }}
    >
      {/* Indicateur d'état en haut à droite */}
      {isDone && (
        <div className="absolute top-1 right-1 w-2 h-2 bg-green-500 rounded-full z-10" />
      )}
      
      {/* Alerte si confidence faible */}
      {hasLowConfidence && (
        <div className="absolute top-1 left-1 z-10">
          <AlertCircle className="w-3 h-3 text-orange-500" />
        </div>
      )}

      {/* PARTIE HAUTE : BANDE COULEUR (70%) + CARRÉ SYMBOLE (30%) */}
      <div className="flex h-[38px]">
        {/* Bande de couleur - 70% - CLIQUABLE */}
        <div
          onClick={handleColorBandClick}
          className="flex-[7] rounded-tl-lg cursor-pointer hover:brightness-110 transition-all"
          style={{ 
            backgroundColor: color.hex,
            border: color.hex === '#FFFFFF' || color.hex === '#ffffff' ? '1px solid #E5E7EB' : 'none'
          }}
        />
        
        {/* Carré symbole blanc - 30% - CLIQUABLE */}
        <div 
          onClick={handleSymbolClick}
          className="flex-[3] bg-white border-l border-slate-200 flex items-center justify-center rounded-tr-lg cursor-pointer hover:bg-slate-50 transition-colors"
          style={{ borderLeftWidth: '1px', borderLeftColor: '#E5E7EB' }}
        >
          <span 
            className="font-black text-slate-900"
            style={{ fontSize: '22px' }}
          >
            {color.assignedSymbolChar || '●'}
          </span>
        </div>
      </div>

      {/* PARTIE BASSE : INFO + ESPACE BLANC DOUBLÉ */}
      <div className="flex flex-col justify-between px-3 py-3 h-[57px] relative">
        {/* Ligne info */}
        <div className="flex flex-col gap-1">
          {/* Code DMC - UNIQUEMENT LE NUMÉRO */}
          <div className="text-[10px] font-bold text-slate-900">
            {color.code || '?'}
          </div>

          {/* Nombre de points */}
          <div className="text-[11px] font-semibold text-slate-600">
            {color.totalCount || 0}
          </div>
        </div>

        {/* Alvéole-abeille AGRANDIE - en bas à droite avec marge */}
        <div className="absolute bottom-3 right-3">
          <button
            onClick={handleTogglePanel}
            className={cn(
              "relative flex items-center justify-center transition-all group",
              showOptionsPanel && "brightness-90"
            )}
            style={{
              width: '36px',
              height: '36px',
              clipPath: 'polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)',
              backgroundColor: showOptionsPanel ? '#FDE68A' : '#F3F4F6'
            }}
            title="Options de cette couleur"
          >
            {/* Abeille géométrique minimaliste */}
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" className="text-slate-800 group-hover:text-amber-600 transition-colors">
              {/* Tête */}
              <circle cx="12" cy="8" r="2" stroke="currentColor" strokeWidth="1.5" fill="none" />
              {/* Corps avec rayures */}
              <ellipse cx="12" cy="15" rx="4.5" ry="6" stroke="currentColor" strokeWidth="1.5" fill="none" />
              <line x1="8" y1="13" x2="16" y2="13" stroke="currentColor" strokeWidth="1.5" />
              <line x1="8" y1="17" x2="16" y2="17" stroke="currentColor" strokeWidth="1.5" />
              {/* Aile gauche */}
              <path d="M7 12 C5 10, 3 10, 2 12 C3 14, 5 14, 7 12 Z" stroke="currentColor" strokeWidth="1.5" fill="none" />
              {/* Aile droite */}
              <path d="M17 12 C19 10, 21 10, 22 12 C21 14, 19 14, 17 12 Z" stroke="currentColor" strokeWidth="1.5" fill="none" />
            </svg>
            
            {/* Halo jaune au hover */}
            <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity blur-md" style={{ backgroundColor: 'rgba(251, 191, 36, 0.5)' }} />
          </button>
        </div>
      </div>

      {/* Panneau d'options - HORS DU BLOC, EN OVERLAY */}
      {showOptionsPanel && (
        <ColorOptionsPanel
          color={color}
          onClose={() => setShowOptionsPanel(false)}
          onIsolate={onIsolate}
          onMerge={onMerge}
          onHide={onHide}
          onChangeSymbol={onChangeSymbol}
          onShowRemaining={(c) => onFindInGrid?.(c)}
          onAiSuggestions={onAiSuggestions}
          onOptimize={onOptimize}
        />
      )}
    </div>
  );
}