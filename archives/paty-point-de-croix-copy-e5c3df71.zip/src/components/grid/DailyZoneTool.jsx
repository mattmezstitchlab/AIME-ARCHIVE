import React from 'react';
import { Button } from '@/components/ui/button';
import { Highlighter, X, Target } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function DailyZoneTool({ 
  isActive, 
  onToggle, 
  hasZone, 
  onClearZone,
  onCenterZone,
  onDarkenOutside,
  darkenOutside = false,
  stitchesInZone = 0,
  totalStitchesInZone = 0,
  zoneName = 'Zone du jour',
  onZoneNameChange
}) {
  const progress = totalStitchesInZone > 0 ? Math.round((stitchesInZone / totalStitchesInZone) * 100) : 0;

  return (
    <div className="bg-white/95 backdrop-blur-sm rounded-xl shadow-lg border border-slate-200 p-4 space-y-3">
      {/* En-tête */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Highlighter className="w-4 h-4 text-amber-600" />
          <span className="text-sm font-semibold text-slate-900">Zone du jour</span>
        </div>
        <Button
          onClick={onToggle}
          size="sm"
          variant={isActive ? "default" : "outline"}
          className={cn(
            "text-xs",
            isActive && "bg-amber-500 hover:bg-amber-600"
          )}
        >
          {isActive ? 'Actif' : 'Activer'}
        </Button>
      </div>

      {/* Options quand zone active */}
      {hasZone && (
        <>
          {/* Nom de la zone */}
          <div>
            <label className="text-[10px] text-slate-600 font-medium mb-1 block">Nom de la zone</label>
            <input
              type="text"
              value={zoneName}
              onChange={(e) => onZoneNameChange?.(e.target.value)}
              className="w-full px-2 py-1.5 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-400"
              placeholder="Zone du jour"
            />
          </div>

          {/* Compteur de progression */}
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-amber-900">
                {stitchesInZone} / {totalStitchesInZone} points brodés
              </span>
              <span className="text-xs font-bold text-amber-900">{progress}%</span>
            </div>
            <div className="w-full h-2 bg-amber-200 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-amber-400 to-amber-600 transition-all duration-300"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>

          {/* Actions rapides */}
          <div className="space-y-2">
            <div className="grid grid-cols-2 gap-2">
              <Button
                onClick={onCenterZone}
                size="sm"
                variant="outline"
                className="text-xs"
              >
                <Target className="w-3 h-3 mr-1" />
                Centrer
              </Button>
              <Button
                onClick={onDarkenOutside}
                size="sm"
                variant={darkenOutside ? "default" : "outline"}
                className={cn(
                  "text-xs",
                  darkenOutside && "bg-slate-700 hover:bg-slate-800"
                )}
              >
                Mode focus
              </Button>
            </div>
            <Button
              onClick={onClearZone}
              size="sm"
              variant="outline"
              className="w-full text-xs text-red-600 hover:text-red-700 hover:bg-red-50"
            >
              <X className="w-3 h-3 mr-1" />
              Réinitialiser la zone
            </Button>
          </div>
        </>
      )}

      {/* Message d'aide */}
      {isActive && !hasZone && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
          <p className="text-xs text-blue-900">
            Cliquez et glissez sur la grille pour définir votre zone de broderie du jour.
            Vous pourrez la déplacer et la redimensionner ensuite.
          </p>
        </div>
      )}
    </div>
  );
}