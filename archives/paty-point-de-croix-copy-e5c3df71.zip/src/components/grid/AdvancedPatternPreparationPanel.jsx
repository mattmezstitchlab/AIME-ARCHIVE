import React, { useState, useEffect } from 'react';
import { X, Sparkles, CheckCircle, AlertTriangle, Palette, Grid3x3, Droplets } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';

export default function AdvancedPatternPreparationPanel({ 
  open, 
  onClose, 
  pattern,
  onApply
}) {
  // ===== TOUS LES HOOKS EN HAUT - TOUJOURS APPELÉS =====
  const [mode, setMode] = useState('debutant');
  const [stitchTypes, setStitchTypes] = useState({
    fullCross: true,
    halfCross: false,
    backstitch: false,
    fractionals: false,
    frenchKnots: false,
    beads: false,
    metallics: false,
    longStitch: false
  });
  const [mergeSimilarColors, setMergeSimilarColors] = useState(true);
  const [removeParasiteColors, setRemoveParasiteColors] = useState(true);
  const [parasiteThreshold, setParasiteThreshold] = useState(10);
  const [limitColors, setLimitColors] = useState(false);
  const [maxColors, setMaxColors] = useState(40);
  const [convertToDmc, setConvertToDmc] = useState(true);
  const [avoidDmcDuplicates, setAvoidDmcDuplicates] = useState(true);
  const [fillEmptyCells, setFillEmptyCells] = useState(true);
  const [ignoreWhiteBackground, setIgnoreWhiteBackground] = useState(true);
  const [backgroundTolerance, setBackgroundTolerance] = useState(50);

  // Calculer les stats du motif
  const stats = React.useMemo(() => {
    if (!pattern?.symbolGrid) return { totalPoints: 0, colorCount: 0, emptyPercent: 0 };

    const allCells = pattern.symbolGrid.flat();
    const totalPoints = allCells.filter(cell => cell).length;
    const colorCount = pattern.colorPalette?.length || 0;
    const emptyPercent = Math.round((allCells.filter(c => !c).length / allCells.length) * 100);

    return { totalPoints, colorCount, emptyPercent };
  }, [pattern]);

  // ===== FONCTIONS =====
  const handleModeChange = (newMode) => {
    setMode(newMode);
    if (newMode === 'debutant') {
      setStitchTypes({
        fullCross: true,
        halfCross: false,
        backstitch: false,
        fractionals: false,
        frenchKnots: false,
        beads: false,
        metallics: false,
        longStitch: false
      });
    } else {
      setStitchTypes({
        fullCross: true,
        halfCross: true,
        backstitch: true,
        fractionals: false,
        frenchKnots: false,
        beads: false,
        metallics: false,
        longStitch: false
      });
    }
  };

  const handleToggleStitchType = (type) => {
    if (type === 'fullCross') return;
    if (mode === 'debutant') return;
    
    setStitchTypes(prev => ({
      ...prev,
      [type]: !prev[type]
    }));
  };

  const handleApply = () => {
    const config = {
      stitchTypes,
      mergeSimilarColors,
      removeParasiteColors,
      parasiteThreshold,
      limitColors,
      maxColors,
      convertToDmc,
      avoidDmcDuplicates,
      fillEmptyCells,
      ignoreWhiteBackground,
      backgroundTolerance
    };
    
    onApply(config);
  };

  // ===== RENDER - EARLY RETURN APRÈS TOUS LES HOOKS =====
  if (!open) return null;

  return (
    <div className="fixed inset-y-0 right-0 z-[100] w-[450px] bg-white shadow-2xl flex flex-col border-l border-slate-200">
      {/* HEADER */}
      <div className="flex-shrink-0 bg-[#111] px-6 py-4 flex items-center justify-between">
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-1">
            <Sparkles className="w-5 h-5 text-[#F5C200]" />
            <h2 className="text-lg font-bold text-white">Préparation avancée du motif</h2>
          </div>
          <p className="text-xs text-[#999] leading-relaxed">
            PatyBee analyse ton motif et t'aide à préparer une grille propre, lisible et agréable à broder.
          </p>
        </div>
        <button
          onClick={onClose}
          className="w-8 h-8 rounded-full bg-white/10 hover:bg-black hover:text-white flex items-center justify-center transition-all border border-[#555]"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Stats résumé */}
      <div className="flex-shrink-0 bg-[#F7F7F7] border-b border-[#E0E0E0] px-6 py-3 grid grid-cols-3 gap-4 text-center">
        <div>
          <div className="text-xs text-[#777]">Points</div>
          <div className="text-lg font-bold text-black">{stats.totalPoints}</div>
        </div>
        <div>
          <div className="text-xs text-[#777]">Couleurs</div>
          <div className="text-lg font-bold text-black">{stats.colorCount}</div>
        </div>
        <div>
          <div className="text-xs text-[#777]">Zones vides</div>
          <div className="text-lg font-bold text-black">{stats.emptyPercent}%</div>
        </div>
      </div>

      {/* CONTENU SCROLLABLE */}
      <div className="flex-1 overflow-y-auto px-6 py-6 space-y-6">
        
        {/* SECTION A - TYPES DE POINTS */}
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <Grid3x3 className="w-4 h-4 text-slate-600" />
            <h3 className="font-semibold text-base text-black">Types de points dans cette grille</h3>
          </div>

          {/* Modes */}
          <RadioGroup value={mode} onValueChange={handleModeChange}>
            <div className="space-y-2">
              <div 
                className={cn(
                  "flex items-start gap-3 p-3 rounded-lg border-2 cursor-pointer transition-all",
                  mode === 'debutant' 
                    ? "border-[#F5C200] bg-[#FFFBEB]" 
                    : "border-[#E0E0E0] hover:border-[#C0C0C0]"
                )}
                onClick={() => handleModeChange('debutant')}
              >
                <RadioGroupItem value="debutant" id="debutant" className="mt-1" />
                <div className="flex-1">
                  <Label htmlFor="debutant" className="font-semibold text-sm cursor-pointer text-black">
                    Mode débutante (simple)
                  </Label>
                  <p className="text-xs text-[#777] mt-1">
                    Points de croix complets uniquement, pas de demi-points, pas de points spéciaux.
                  </p>
                </div>
              </div>

              <div 
                className={cn(
                  "flex items-start gap-3 p-3 rounded-lg border-2 cursor-pointer transition-all",
                  mode === 'avance' 
                    ? "border-[#F5C200] bg-[#FFFBEB]" 
                    : "border-[#E0E0E0] hover:border-[#C0C0C0]"
                )}
                onClick={() => handleModeChange('avance')}
              >
                <RadioGroupItem value="avance" id="avance" className="mt-1" />
                <div className="flex-1">
                  <Label htmlFor="avance" className="font-semibold text-sm cursor-pointer text-black">
                    Mode avancé (toutes les techniques)
                  </Label>
                  <p className="text-xs text-[#777] mt-1">
                    Active les demi-points, backstitch, fractionnés, perles, effets spéciaux.
                  </p>
                </div>
              </div>
            </div>
          </RadioGroup>

          {/* Liste des types */}
          <div className="space-y-2">
            {[
              { id: 'fullCross', label: 'Point de croix complet', mandatory: true },
              { id: 'halfCross', label: 'Demi-point' },
              { id: 'backstitch', label: 'Backstitch (points arrière / contour)' },
              { id: 'fractionals', label: 'Points fractionnés (¼, ¾)' },
              { id: 'frenchKnots', label: 'Nœuds (French knots / points de lumière)' },
              { id: 'beads', label: 'Perles (beads)' },
              { id: 'metallics', label: 'Fils métalliques / effets spéciaux' }
            ].map(type => (
              <div
                key={type.id}
                className={cn(
                  "flex items-center justify-between p-2 rounded-lg border transition-all",
                  stitchTypes[type.id] ? "bg-[#F5F5F5] border-[#E0E0E0]" : "bg-white border-[#E0E0E0]",
                  (mode === 'debutant' && !type.mandatory) && "opacity-50"
                )}
              >
                <span className="text-xs text-black">{type.label}</span>
                <Switch
                  checked={stitchTypes[type.id]}
                  onCheckedChange={() => handleToggleStitchType(type.id)}
                  disabled={type.mandatory || mode === 'debutant'}
                />
              </div>
            ))}
          </div>
        </div>

        {/* SECTION B - NETTOYAGE COULEURS */}
        <div className="space-y-4 pt-4 border-t border-[#E0E0E0]">
          <div className="flex items-center gap-2">
            <Droplets className="w-4 h-4 text-slate-600" />
            <h3 className="font-semibold text-base text-black">Nettoyage des couleurs</h3>
          </div>

          <p className="text-xs text-[#777] leading-relaxed">
            PatyBee peut fusionner les couleurs trop proches, supprimer les couleurs parasites et simplifier ta palette.
          </p>

          <div className="space-y-3">
            <div className="flex items-start gap-3">
              <input
                type="checkbox"
                checked={mergeSimilarColors}
                onChange={(e) => setMergeSimilarColors(e.target.checked)}
                className="mt-1 w-4 h-4"
              />
              <div className="flex-1">
                <div className="text-sm font-medium text-black">Fusionner les couleurs très proches</div>
                <div className="text-xs text-[#777]">
                  Regrouper automatiquement les couleurs dont la différence est faible.
                </div>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <input
                type="checkbox"
                checked={removeParasiteColors}
                onChange={(e) => setRemoveParasiteColors(e.target.checked)}
                className="mt-1 w-4 h-4"
              />
              <div className="flex-1">
                <div className="text-sm font-medium text-black">Supprimer les couleurs parasites</div>
                <div className="text-xs text-[#777] mb-2">
                  Supprimer les couleurs qui n'apparaissent que sur quelques points isolés.
                </div>
                {removeParasiteColors && (
                  <div className="ml-1">
                    <label className="text-xs text-[#777]">Seuil minimum de points :</label>
                    <input
                      type="number"
                      min="1"
                      max="50"
                      value={parasiteThreshold}
                      onChange={(e) => setParasiteThreshold(Number(e.target.value))}
                      className="w-full mt-1 px-2 py-1 border border-[#E0E0E0] rounded text-sm"
                    />
                  </div>
                )}
              </div>
            </div>

            <div className="flex items-start gap-3">
              <input
                type="checkbox"
                checked={limitColors}
                onChange={(e) => setLimitColors(e.target.checked)}
                className="mt-1 w-4 h-4"
              />
              <div className="flex-1">
                <div className="text-sm font-medium text-black">Limiter le nombre total de couleurs</div>
                {limitColors && (
                  <div className="mt-2">
                    <input
                      type="range"
                      min="5"
                      max="90"
                      value={maxColors}
                      onChange={(e) => setMaxColors(Number(e.target.value))}
                      className="w-full h-2 bg-[#E0E0E0] rounded-lg appearance-none cursor-pointer accent-[#F5C200]"
                    />
                    <div className="flex justify-between text-xs text-[#777] mt-1">
                      <span>5</span>
                      <span className="font-semibold text-black">{maxColors} couleurs</span>
                      <span>90</span>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* SECTION C - CONVERSION DMC */}
        <div className="space-y-4 pt-4 border-t border-[#E0E0E0]">
          <div className="flex items-center gap-2">
            <Palette className="w-4 h-4 text-slate-600" />
            <h3 className="font-semibold text-base text-black">Conversion DMC & correspondances</h3>
          </div>

          <div className="flex items-start gap-3">
            <input
              type="checkbox"
              checked={convertToDmc}
              onChange={(e) => setConvertToDmc(e.target.checked)}
              className="mt-1 w-4 h-4"
            />
            <div className="flex-1">
              <div className="text-sm font-medium text-black">Convertir toutes les couleurs vers la palette DMC officielle</div>
              <div className="text-xs text-[#777] mt-1">
                Pour chaque couleur de ton motif, PatyBee choisit le DMC le plus proche et remplace les codes temporaires.
              </div>
            </div>
          </div>

          {convertToDmc && (
            <div className="ml-7">
              <div className="flex items-start gap-3">
                <input
                  type="checkbox"
                  checked={avoidDmcDuplicates}
                  onChange={(e) => setAvoidDmcDuplicates(e.target.checked)}
                  className="mt-1 w-4 h-4"
                />
                <div className="flex-1">
                  <div className="text-sm font-medium text-black">Éviter les doublons DMC</div>
                  <div className="text-xs text-[#777]">
                    Si plusieurs couleurs mènent au même code DMC, fusionner leurs points dans une seule couleur.
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* SECTION D - ZONES VIDES */}
        <div className="space-y-4 pt-4 border-t border-[#E0E0E0]">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-slate-600" />
            <h3 className="font-semibold text-base text-black">Zones vides & zones transparentes</h3>
          </div>

          <div className="space-y-3">
            <div className="flex items-start gap-3">
              <input
                type="checkbox"
                checked={fillEmptyCells}
                onChange={(e) => setFillEmptyCells(e.target.checked)}
                className="mt-1 w-4 h-4"
              />
              <div className="flex-1">
                <div className="text-sm font-medium text-black">Remplir les cases vides dans les zones visibles</div>
                <div className="text-xs text-[#777]">
                  Pour chaque pixel du visuel non transparent, s'assurer qu'une couleur et un symbole sont présents.
                </div>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <input
                type="checkbox"
                checked={ignoreWhiteBackground}
                onChange={(e) => setIgnoreWhiteBackground(e.target.checked)}
                className="mt-1 w-4 h-4"
              />
              <div className="flex-1">
                <div className="text-sm font-medium text-black">Ignorer le fond très clair (blanc / crème)</div>
                <div className="text-xs text-[#777] mb-2">
                  Considérer les couleurs très proches du blanc comme du fond (pas de point à broder).
                </div>
                {ignoreWhiteBackground && (
                  <div className="ml-1">
                    <label className="text-xs text-[#777]">Tolérance :</label>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={backgroundTolerance}
                      onChange={(e) => setBackgroundTolerance(Number(e.target.value))}
                      className="w-full h-2 bg-[#E0E0E0] rounded-lg appearance-none cursor-pointer accent-[#F5C200]"
                    />
                    <div className="flex justify-between text-xs text-[#777] mt-1">
                      <span>Faible</span>
                      <span className="font-semibold text-black">{backgroundTolerance}</span>
                      <span>Fort</span>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* FOOTER */}
      <div className="flex-shrink-0 bg-[#F7F7F7] border-t border-[#E0E0E0] px-6 py-4 flex items-center justify-between gap-3">
        <button
          onClick={onClose}
          className="text-sm text-[#777] hover:text-black transition-colors underline"
        >
          Fermer sans appliquer
        </button>

        <Button
          onClick={handleApply}
          className="px-6 py-2 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-lg shadow-sm flex items-center gap-2"
        >
          <CheckCircle className="w-4 h-4" />
          Appliquer ces réglages
        </Button>
      </div>
    </div>
  );
}