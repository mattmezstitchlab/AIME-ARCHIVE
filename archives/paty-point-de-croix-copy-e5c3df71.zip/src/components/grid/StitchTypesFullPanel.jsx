import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { ArrowLeft, CheckCircle, Sparkles, X, Check } from 'lucide-react';
import { cn } from '@/lib/utils';
import { usePatyBeeEngine } from '../patybee/PatyBeeEngine';

// Légende des types de points avec couleurs
const LEGEND_COLORS = {
  fullCross: '#8B5CF6',
  halfCross: '#06B6D4',
  backstitch: '#F59E0B',
  special: '#EC4899'
};

// Liste des types de points avec badges et catégories
const STITCH_TYPES = [
  { 
    id: 'full', 
    name: 'Point de croix complet', 
    desc: 'Base du modèle (1 case = 1 croix)', 
    badge: 'Essentiel',
    badgeColor: 'bg-purple-100 text-purple-700',
    mandatory: true,
    legendColor: 'fullCross'
  },
  { 
    id: 'half', 
    name: 'Demi-point', 
    desc: 'Adoucir les dégradés et les fonds',
    badge: 'Recommandé',
    badgeColor: 'bg-green-100 text-green-700',
    legendColor: 'halfCross'
  },
  { 
    id: 'quarter', 
    name: 'Points fractionnés (¼, ¾)', 
    desc: 'Affiner les arrondis et les angles',
    badge: 'Détails fins',
    badgeColor: 'bg-blue-100 text-blue-700',
    legendColor: 'special'
  },
  { 
    id: 'backstitch', 
    name: 'Points arrière (Backstitch)', 
    desc: 'Dessiner les contours et les détails',
    badge: 'Contours',
    badgeColor: 'bg-amber-100 text-amber-700',
    legendColor: 'backstitch'
  },
  { 
    id: 'frenchknot', 
    name: 'Nœuds français', 
    desc: 'Petits points de lumière ou centres de fleurs',
    badge: 'Lumière',
    badgeColor: 'bg-yellow-100 text-yellow-700',
    legendColor: 'special'
  },
  { 
    id: 'bead', 
    name: 'Perles (Beads)', 
    desc: 'Perles décoratives (yeux, bijoux, reflets)',
    badge: 'Effet perlé',
    badgeColor: 'bg-pink-100 text-pink-700',
    legendColor: 'special'
  },
  { 
    id: 'metallic', 
    name: 'Fils métalliques', 
    desc: 'Dorure, argent, effets brillants',
    badge: 'Effet brillant',
    badgeColor: 'bg-slate-100 text-slate-700',
    legendColor: 'special'
  },
  { 
    id: 'longstitch', 
    name: 'Point long / satin', 
    desc: 'Grandes surfaces uniformes (cheveux, aplats)',
    badge: 'Spéciaux',
    badgeColor: 'bg-indigo-100 text-indigo-700',
    legendColor: 'special'
  }
];

// Recommandations IA
const AI_RECOMMENDATIONS = [
  { text: 'Zones nettes → Points de croix complets', icon: '✓' },
  { text: 'Fonds doux → Demi-points', icon: '✓' },
  { text: 'Contours importants → Backstitch', icon: '✓' },
  { text: 'Détails fins → Points fractionnés (¼, ¾)', icon: '✓' },
  { text: 'Points de lumière → Nœuds / perles', icon: '✓' },
  { text: 'Effets spéciaux → Métalliques, satin', icon: '✓' }
];

export default function StitchTypesFullPanel({ 
  open, 
  onClose, 
  onConfirm,
  importedFile,
  initialConfig = {}
}) {
  // ===== TOUS LES HOOKS EN HAUT - TOUJOURS APPELÉS =====
  const [previewImage, setPreviewImage] = useState(null);
  const [selectedTypes, setSelectedTypes] = useState(['full', 'half', 'backstitch']);
  const [useAutoRecommendation, setUseAutoRecommendation] = useState(true);
  const [mode, setMode] = useState('debutant');
  const [customMode, setCustomMode] = useState(false);

  // Moteur IA PatyBee - TOUJOURS appelé (même avec previewImage null)
  const {
    autoSize,
    autoColors,
    autoTechniques,
    dmcMapping,
    qualityProfile: autoQualityProfile,
    stitchDirectionMap,
    proProfile: autoProProfile,
    analysisDone,
  } = usePatyBeeEngine(previewImage);

  // Générer l'aperçu à partir du fichier
  useEffect(() => {
    if (!importedFile) {
      setPreviewImage(null);
      return;
    }
    
    const reader = new FileReader();
    reader.onload = (e) => setPreviewImage(e.target.result);
    reader.readAsDataURL(importedFile);
  }, [importedFile]);

  // Synchroniser avec initialConfig au montage
  useEffect(() => {
    if (initialConfig.selectedTypes) {
      setSelectedTypes(initialConfig.selectedTypes);
    }
    if (initialConfig.modeUtilisation) {
      setMode(initialConfig.modeUtilisation);
    }
  }, []);

  // Sync avec l'analyse IA une fois terminée
  useEffect(() => {
    if (!analysisDone || !useAutoRecommendation) return;
    
    const recommendedTypes = ['full'];
    if (autoTechniques?.halfCross) recommendedTypes.push('half');
    if (autoTechniques?.backstitch) recommendedTypes.push('backstitch');
    if (autoTechniques?.fractionals) recommendedTypes.push('quarter');
    if (autoTechniques?.frenchKnots) recommendedTypes.push('frenchknot');
    if (autoTechniques?.beads) recommendedTypes.push('bead');
    if (autoTechniques?.metallics) recommendedTypes.push('metallic');
    if (autoTechniques?.longStitch) recommendedTypes.push('longstitch');
    
    setSelectedTypes(recommendedTypes);
  }, [analysisDone, useAutoRecommendation, autoTechniques]);

  // ===== FONCTIONS =====
  const handleModeChange = (newMode) => {
    setMode(newMode);
    setCustomMode(false);
    
    if (newMode === 'debutant') {
      setSelectedTypes(['full', 'half', 'backstitch']);
    } else {
      if (useAutoRecommendation && analysisDone && autoTechniques) {
        const recommendedTypes = ['full'];
        if (autoTechniques.halfCross) recommendedTypes.push('half');
        if (autoTechniques.backstitch) recommendedTypes.push('backstitch');
        if (autoTechniques.fractionals) recommendedTypes.push('quarter');
        if (autoTechniques.frenchKnots) recommendedTypes.push('frenchknot');
        if (autoTechniques.beads) recommendedTypes.push('bead');
        if (autoTechniques.metallics) recommendedTypes.push('metallic');
        if (autoTechniques.longStitch) recommendedTypes.push('longstitch');
        setSelectedTypes(recommendedTypes);
      } else {
        setSelectedTypes(['full', 'half', 'backstitch', 'quarter', 'frenchknot', 'bead', 'metallic', 'longstitch']);
      }
    }
  };

  const handleToggleType = (typeId) => {
    if (typeId === 'full') return;
    
    setSelectedTypes(prev => {
      const newTypes = prev.includes(typeId)
        ? prev.filter(id => id !== typeId)
        : [...prev, typeId];
      
      setCustomMode(true);
      return newTypes;
    });
  };

  const handleSkip = () => {
    const techniquesObj = {
      fullCross: true,
      halfCross: false,
      backstitch: false,
      fractionals: false,
      frenchKnots: false,
      beads: false,
      metallics: false,
      longStitch: false
    };

    onConfirm?.({
      width: autoSize?.width || 150,
      height: autoSize?.height || 150,
      colorsCount: autoColors || 40,
      qualityProfile: 'standard',
      proProfile: null,
      techniques: techniquesObj,
      dmcMapping: dmcMapping || {},
      stitchDirectionMap: stitchDirectionMap || {},
      selectedTypes: ['full'],
      useAutoRecommendation: false,
      modeUtilisation: 'debutant'
    });
  };

  const handleValidate = () => {
    if (selectedTypes.length === 0) {
      return;
    }

    const techniquesObj = {
      fullCross: selectedTypes.includes('full'),
      halfCross: selectedTypes.includes('half'),
      backstitch: selectedTypes.includes('backstitch'),
      fractionals: selectedTypes.includes('quarter'),
      frenchKnots: selectedTypes.includes('frenchknot'),
      beads: selectedTypes.includes('bead'),
      metallics: selectedTypes.includes('metallic'),
      longStitch: selectedTypes.includes('longstitch')
    };

    onConfirm?.({
      width: autoSize?.width || 150,
      height: autoSize?.height || 150,
      colorsCount: autoColors || 40,
      qualityProfile: autoQualityProfile || 'standard',
      proProfile: autoProProfile,
      techniques: techniquesObj,
      dmcMapping: dmcMapping || {},
      stitchDirectionMap: stitchDirectionMap || {},
      selectedTypes,
      useAutoRecommendation,
      modeUtilisation: customMode ? 'personnalise' : mode
    });
  };

  const activeCount = selectedTypes.length;

  // ===== RENDER - EARLY RETURN APRÈS TOUS LES HOOKS =====
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center">
      {/* Overlay */}
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      
      {/* Panel */}
      <div className="relative w-[95vw] max-w-[1100px] min-w-[920px] h-[80vh] bg-white rounded-2xl shadow-2xl overflow-hidden flex flex-col">
        
        {/* HEADER PATYBEE */}
        <div className="flex-shrink-0 bg-slate-900 text-white px-6 py-4 flex items-center justify-between">
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <Sparkles className="w-5 h-5 text-purple-400" />
              <h2 className="text-xl font-bold">Étape 2 · Types de points de broderie</h2>
            </div>
            <p className="text-sm text-slate-300">
              PatyBee analyse ton image et te propose automatiquement les types de points les plus adaptés. 
              Tu peux garder la proposition, la simplifier, ou tout régler à la main.
            </p>
          </div>
          <div className="flex items-center gap-4">
            <button
              onClick={handleSkip}
              className="text-sm text-slate-400 hover:text-white underline transition-colors"
            >
              Ignorer (tout en points de croix simples)
            </button>
            <button
              onClick={onClose}
              className="p-2 hover:bg-slate-800 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* CONTENU PRINCIPAL - Scrollable */}
        <div className="flex-1 overflow-y-auto p-6">
          {/* 3 COLONNES */}
          <div className="grid grid-cols-12 gap-6 mb-6">
            
            {/* COLONNE 1 - APERÇU (26%) */}
            <div className="col-span-3">
              <div className="bg-white rounded-xl border border-slate-200 p-4">
                <h3 className="font-semibold text-sm text-slate-900 mb-3">Aperçu du modèle</h3>
                
                {previewImage && (
                  <div className="rounded-lg overflow-hidden border border-slate-200 mb-4">
                    <img 
                      src={previewImage} 
                      alt="Aperçu" 
                      className="w-full h-auto"
                    />
                  </div>
                )}
                
                {/* Légende */}
                <div className="space-y-2">
                  <div className="text-xs font-medium text-slate-700 mb-2">Légende des types :</div>
                  {selectedTypes.includes('full') && (
                    <div className="flex items-center gap-2 text-xs">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: LEGEND_COLORS.fullCross }} />
                      <span className="text-slate-700">Points de croix</span>
                    </div>
                  )}
                  {selectedTypes.includes('half') && (
                    <div className="flex items-center gap-2 text-xs">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: LEGEND_COLORS.halfCross }} />
                      <span className="text-slate-700">Demi-points</span>
                    </div>
                  )}
                  {selectedTypes.includes('backstitch') && (
                    <div className="flex items-center gap-2 text-xs">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: LEGEND_COLORS.backstitch }} />
                      <span className="text-slate-700">Backstitch</span>
                    </div>
                  )}
                  {(selectedTypes.includes('quarter') || selectedTypes.includes('frenchknot') || 
                    selectedTypes.includes('bead') || selectedTypes.includes('metallic') || 
                    selectedTypes.includes('longstitch')) && (
                    <div className="flex items-center gap-2 text-xs">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: LEGEND_COLORS.special }} />
                      <span className="text-slate-700">Points spéciaux / perles / métalliques</span>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* COLONNE 2 - PROPOSITION IA (32%) */}
            <div className="col-span-4">
              <div className="bg-white rounded-xl border border-slate-200 p-4">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-semibold text-sm text-slate-900">Proposition automatique de PatyBee</h3>
                  {analysisDone && (
                    <div className="flex items-center gap-1 text-xs text-green-600">
                      <CheckCircle className="w-3 h-3" />
                      <span>Analyse terminée</span>
                    </div>
                  )}
                </div>
                
                {/* Liste des recommandations */}
                <div className="space-y-2 mb-4">
                  {AI_RECOMMENDATIONS.map((rec, idx) => (
                    <div key={idx} className="flex items-start gap-2 text-xs text-slate-700">
                      <Check className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                      <span>{rec.text}</span>
                    </div>
                  ))}
                </div>

                {/* Switch recommandation auto */}
                <div className="p-3 bg-gradient-to-r from-indigo-50 to-purple-50 rounded-lg border border-indigo-200">
                  <div className="flex items-start gap-3">
                    <Switch
                      checked={useAutoRecommendation}
                      onCheckedChange={setUseAutoRecommendation}
                    />
                    <div className="flex-1">
                      <div className="text-xs font-semibold text-slate-900 mb-1">
                        Utiliser la recommandation automatique
                      </div>
                      <div className="text-xs text-slate-600">
                        (recommandé)
                      </div>
                    </div>
                  </div>
                </div>

                {/* Résumé */}
                <div className="mt-4 p-3 bg-slate-50 rounded-lg">
                  <div className="text-xs text-slate-600">
                    {customMode ? (
                      <>Actuellement : <span className="font-semibold text-slate-900">paramètres personnalisés</span></>
                    ) : activeCount <= 3 ? (
                      <>Actuellement : <span className="font-semibold text-slate-900">mode simplifié</span> · idéal pour débuter</>
                    ) : (
                      <>Actuellement : <span className="font-semibold text-slate-900">{activeCount} types activés</span> · rendu riche en détails</>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* COLONNE 3 - LISTE DES TYPES (42%) */}
            <div className="col-span-5">
              <div className="bg-white rounded-xl border border-slate-200 p-4">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-semibold text-sm text-slate-900">Types de points inclus dans cette grille</h3>
                  <div className="px-2 py-1 bg-indigo-100 text-indigo-700 text-xs font-semibold rounded">
                    {activeCount} activés
                  </div>
                </div>

                {selectedTypes.length === 0 && (
                  <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-xs text-red-700 mb-3">
                    ⚠️ Au moins un type de point doit être actif pour générer la grille.
                  </div>
                )}

                {/* Liste scrollable */}
                <div className="space-y-2 max-h-[400px] overflow-y-auto pr-2">
                  {STITCH_TYPES.map(stitch => {
                    const isSelected = selectedTypes.includes(stitch.id);
                    
                    return (
                      <div
                        key={stitch.id}
                        className={cn(
                          "flex items-center gap-3 p-3 rounded-lg border transition-all",
                          stitch.mandatory 
                            ? "bg-purple-50 border-purple-200" 
                            : isSelected
                            ? "bg-slate-50 border-slate-300"
                            : "bg-white border-slate-200 opacity-60"
                        )}
                      >
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-semibold text-xs text-slate-900">{stitch.name}</span>
                            <span className={cn("text-[10px] px-1.5 py-0.5 rounded font-medium", stitch.badgeColor)}>
                              {stitch.badge}
                            </span>
                          </div>
                          <div className="text-xs text-slate-600">{stitch.desc}</div>
                        </div>
                        <Switch
                          checked={isSelected}
                          onCheckedChange={() => handleToggleType(stitch.id)}
                          disabled={stitch.mandatory}
                        />
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>

          {/* SECTION MODE D'UTILISATION */}
          <div className="bg-white rounded-xl border border-slate-200 p-4">
            <h3 className="font-semibold text-sm text-slate-900 mb-3">Mode d'utilisation</h3>
            
            <RadioGroup value={mode} onValueChange={handleModeChange}>
              <div className="grid grid-cols-2 gap-4">
                <div 
                  className={cn(
                    "p-4 rounded-lg border-2 cursor-pointer transition-all",
                    mode === 'debutant' 
                      ? "border-indigo-600 bg-indigo-50" 
                      : "border-slate-200 hover:border-slate-300"
                  )}
                  onClick={() => handleModeChange('debutant')}
                >
                  <div className="flex items-start gap-3">
                    <RadioGroupItem value="debutant" id="debutant" />
                    <div className="flex-1">
                      <Label htmlFor="debutant" className="font-semibold text-sm cursor-pointer">
                        Mode débutante (simple)
                      </Label>
                      <p className="text-xs text-slate-600 mt-1">
                        Uniquement points de croix complets, demi-points et backstitch. 
                        Pas de points fractionnés, perles ou effets spéciaux.
                      </p>
                    </div>
                  </div>
                </div>

                <div 
                  className={cn(
                    "p-4 rounded-lg border-2 cursor-pointer transition-all",
                    mode === 'avance' 
                      ? "border-indigo-600 bg-indigo-50" 
                      : "border-slate-200 hover:border-slate-300"
                  )}
                  onClick={() => handleModeChange('avance')}
                >
                  <div className="flex items-start gap-3">
                    <RadioGroupItem value="avance" id="avance" />
                    <div className="flex-1">
                      <Label htmlFor="avance" className="font-semibold text-sm cursor-pointer">
                        Mode avancée (toutes les techniques)
                      </Label>
                      <p className="text-xs text-slate-600 mt-1">
                        Active les points fractionnés, nœuds, perles, métalliques et points spéciaux 
                        pour un rendu premium.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </RadioGroup>

            {customMode && (
              <div className="mt-3 text-xs text-slate-600 italic">
                ✏️ Paramètres personnalisés
              </div>
            )}
          </div>
        </div>

        {/* FOOTER STICKY */}
        <div className="flex-shrink-0 bg-white border-t border-slate-200 px-6 py-4 flex items-center justify-between">
          <Button
            variant="outline"
            onClick={onClose}
            className="gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Revenir à l'étape précédente
          </Button>

          <div className="text-xs text-slate-500">
            Tu peux modifier ces choix plus tard depuis ton espace de travail.
          </div>

          <Button
            onClick={handleValidate}
            disabled={selectedTypes.length === 0}
            className="bg-green-600 hover:bg-green-700 text-white px-8 gap-2"
          >
            <CheckCircle className="w-4 h-4" />
            Valider ces choix et générer la grille
          </Button>
        </div>
      </div>
    </div>
  );
}