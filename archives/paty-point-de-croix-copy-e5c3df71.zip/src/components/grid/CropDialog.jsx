import React, { useState, useRef, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { ZoomIn, ZoomOut, RotateCcw, Square, Sparkles, Check, AlertCircle, ChevronDown, ChevronUp } from 'lucide-react';
import { toast } from 'sonner';
import { SYMBOL_CATEGORIES } from './SymbolLibrary';

export default function CropDialog({ 
  open, 
  onClose, 
  imageUrl,
  onCropComplete,
  legendData = null // Données de légende du PDF si disponibles
}) {
  const canvasRef = useRef(null);
  const containerRef = useRef(null);
  const [image, setImage] = useState(null);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [cropRect, setCropRect] = useState({ x: 50, y: 50, width: 300, height: 300 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState(null);
  const [resizing, setResizing] = useState(null);
  const [lockSquare, setLockSquare] = useState(false);
  const [lockGridRatio, setLockGridRatio] = useState(false);
  const [detectedSymbols, setDetectedSymbols] = useState([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [highlightedSymbol, setHighlightedSymbol] = useState(null);
  const [showSymbolPanel, setShowSymbolPanel] = useState(true);

  // Charger l'image
  useEffect(() => {
    if (!imageUrl) return;

    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      setImage(img);
      
      // Centrer le cadre de recadrage initial (rectangle libre, non carré)
      const canvas = canvasRef.current;
      if (canvas) {
        const width = img.width * 0.8;
        const height = img.height * 0.8;
        setCropRect({
          x: (img.width - width) / 2,
          y: (img.height - height) / 2,
          width: width,
          height: height
        });
      }
    };
    img.src = imageUrl;
  }, [imageUrl]);

  // Charger la légende depuis sessionStorage
  useEffect(() => {
    if (open) {
      const stored = sessionStorage.getItem('pdf_legend');
      if (stored) {
        try {
          const legend = JSON.parse(stored);
          setDetectedSymbols(legend.map((entry, index) => ({
            id: entry.symbol,
            symbol: entry.symbol,
            dmcCode: entry.dmcCode,
            colorName: entry.colorName,
            color: entry.color,
            preview: null, // Pas d'aperçu depuis l'image
            isFromLegend: true
          })));
          toast.success(`${legend.length} symboles chargés depuis la légende PDF`);
        } catch (error) {
          console.error('Erreur chargement légende:', error);
        }
      }
    }
  }, [open]);

  // Plus d'analyse de symboles depuis l'image

  // Dessiner sur le canvas
  useEffect(() => {
    if (!image || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const container = containerRef.current;
    
    if (!container) return;

    // Ajuster la taille du canvas au conteneur
    canvas.width = container.offsetWidth;
    canvas.height = container.offsetHeight;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Calculer l'échelle pour adapter l'image au canvas
    const scale = Math.min(
      canvas.width / image.width,
      canvas.height / image.height
    ) * zoom;

    const imgWidth = image.width * scale;
    const imgHeight = image.height * scale;
    const imgX = (canvas.width - imgWidth) / 2 + pan.x;
    const imgY = (canvas.height - imgHeight) / 2 + pan.y;

    // Dessiner l'image
    ctx.drawImage(image, imgX, imgY, imgWidth, imgHeight);

    // Overlay sombre
    ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Zone de recadrage transparente
    const cropX = imgX + (cropRect.x / image.width) * imgWidth;
    const cropY = imgY + (cropRect.y / image.height) * imgHeight;
    const cropW = (cropRect.width / image.width) * imgWidth;
    const cropH = (cropRect.height / image.height) * imgHeight;

    ctx.clearRect(cropX, cropY, cropW, cropH);
    ctx.drawImage(
      image,
      cropRect.x, cropRect.y, cropRect.width, cropRect.height,
      cropX, cropY, cropW, cropH
    );

    // Bordure du cadre de recadrage
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 2;
    ctx.strokeRect(cropX, cropY, cropW, cropH);

    // Poignées de redimensionnement
    const handleSize = 10;
    const handles = [
      { x: cropX - handleSize / 2, y: cropY - handleSize / 2, cursor: 'nw-resize' }, // top-left
      { x: cropX + cropW - handleSize / 2, y: cropY - handleSize / 2, cursor: 'ne-resize' }, // top-right
      { x: cropX - handleSize / 2, y: cropY + cropH - handleSize / 2, cursor: 'sw-resize' }, // bottom-left
      { x: cropX + cropW - handleSize / 2, y: cropY + cropH - handleSize / 2, cursor: 'se-resize' }, // bottom-right
      { x: cropX + cropW / 2 - handleSize / 2, y: cropY - handleSize / 2, cursor: 'n-resize' }, // top
      { x: cropX + cropW / 2 - handleSize / 2, y: cropY + cropH - handleSize / 2, cursor: 's-resize' }, // bottom
      { x: cropX - handleSize / 2, y: cropY + cropH / 2 - handleSize / 2, cursor: 'w-resize' }, // left
      { x: cropX + cropW - handleSize / 2, y: cropY + cropH / 2 - handleSize / 2, cursor: 'e-resize' }, // right
    ];

    ctx.fillStyle = '#ffffff';
    ctx.strokeStyle = '#3B82F6';
    ctx.lineWidth = 2;
    handles.forEach(handle => {
      ctx.fillRect(handle.x, handle.y, handleSize, handleSize);
      ctx.strokeRect(handle.x, handle.y, handleSize, handleSize);
    });

  }, [image, zoom, pan, cropRect]);

  const handleZoomIn = () => {
    setZoom(prev => Math.min(prev * 1.2, 5));
  };

  const handleZoomOut = () => {
    setZoom(prev => Math.max(prev / 1.2, 0.5));
  };

  const handleReset = () => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
    if (image) {
      // Rectangle couvrant 80% de l'image, centré
      const width = image.width * 0.8;
      const height = image.height * 0.8;
      setCropRect({
        x: (image.width - width) / 2,
        y: (image.height - height) / 2,
        width: width,
        height: height
      });
    }
  };

  const handleMouseDown = (e) => {
    if (!image || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    const scale = Math.min(
      canvas.width / image.width,
      canvas.height / image.height
    ) * zoom;

    const imgWidth = image.width * scale;
    const imgHeight = image.height * scale;
    const imgX = (canvas.width - imgWidth) / 2 + pan.x;
    const imgY = (canvas.height - imgHeight) / 2 + pan.y;

    const cropX = imgX + (cropRect.x / image.width) * imgWidth;
    const cropY = imgY + (cropRect.y / image.height) * imgHeight;
    const cropW = (cropRect.width / image.width) * imgWidth;
    const cropH = (cropRect.height / image.height) * imgHeight;

    const handleSize = 10;
    
    // Vérifier si on clique sur une poignée de redimensionnement
    const handles = [
      { x: cropX, y: cropY, type: 'nw' }, // top-left
      { x: cropX + cropW, y: cropY, type: 'ne' }, // top-right
      { x: cropX, y: cropY + cropH, type: 'sw' }, // bottom-left
      { x: cropX + cropW, y: cropY + cropH, type: 'se' }, // bottom-right
      { x: cropX + cropW / 2, y: cropY, type: 'n' }, // top
      { x: cropX + cropW / 2, y: cropY + cropH, type: 's' }, // bottom
      { x: cropX, y: cropY + cropH / 2, type: 'w' }, // left
      { x: cropX + cropW, y: cropY + cropH / 2, type: 'e' }, // right
    ];

    for (const handle of handles) {
      if (mouseX >= handle.x - handleSize / 2 && mouseX <= handle.x + handleSize / 2 &&
          mouseY >= handle.y - handleSize / 2 && mouseY <= handle.y + handleSize / 2) {
        setResizing(handle.type);
        setDragStart({ x: mouseX, y: mouseY, cropRect: { ...cropRect } });
        return;
      }
    }

    // Vérifier si on clique sur le cadre pour le déplacer
    if (mouseX >= cropX && mouseX <= cropX + cropW &&
        mouseY >= cropY && mouseY <= cropY + cropH) {
      setIsDragging(true);
      setDragStart({ x: mouseX - cropX, y: mouseY - cropY });
    }
  };

  const handleMouseMove = (e) => {
    if ((!isDragging && !resizing) || !image || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    const scale = Math.min(
      canvas.width / image.width,
      canvas.height / image.height
    ) * zoom;

    const imgWidth = image.width * scale;
    const imgHeight = image.height * scale;
    const imgX = (canvas.width - imgWidth) / 2 + pan.x;
    const imgY = (canvas.height - imgHeight) / 2 + pan.y;

    if (resizing) {
      const deltaX = ((mouseX - dragStart.x) / imgWidth) * image.width;
      const deltaY = ((mouseY - dragStart.y) / imgHeight) * image.height;
      const originalRect = dragStart.cropRect;

      let newRect = { ...originalRect };

      switch (resizing) {
        case 'nw': // Top-left
          newRect.x = originalRect.x + deltaX;
          newRect.y = originalRect.y + deltaY;
          newRect.width = originalRect.width - deltaX;
          newRect.height = originalRect.height - deltaY;
          break;
        case 'ne': // Top-right
          newRect.y = originalRect.y + deltaY;
          newRect.width = originalRect.width + deltaX;
          newRect.height = originalRect.height - deltaY;
          break;
        case 'sw': // Bottom-left
          newRect.x = originalRect.x + deltaX;
          newRect.width = originalRect.width - deltaX;
          newRect.height = originalRect.height + deltaY;
          break;
        case 'se': // Bottom-right
          newRect.width = originalRect.width + deltaX;
          newRect.height = originalRect.height + deltaY;
          break;
        case 'n': // Top
          newRect.y = originalRect.y + deltaY;
          newRect.height = originalRect.height - deltaY;
          break;
        case 's': // Bottom
          newRect.height = originalRect.height + deltaY;
          break;
        case 'w': // Left
          newRect.x = originalRect.x + deltaX;
          newRect.width = originalRect.width - deltaX;
          break;
        case 'e': // Right
          newRect.width = originalRect.width + deltaX;
          break;
      }

      // Appliquer le ratio carré si activé
      if (lockSquare && (resizing === 'nw' || resizing === 'ne' || resizing === 'sw' || resizing === 'se')) {
        const size = Math.min(newRect.width, newRect.height);
        if (resizing === 'nw') {
          newRect.x = originalRect.x + originalRect.width - size;
          newRect.y = originalRect.y + originalRect.height - size;
        } else if (resizing === 'ne') {
          newRect.y = originalRect.y + originalRect.height - size;
        } else if (resizing === 'sw') {
          newRect.x = originalRect.x + originalRect.width - size;
        }
        newRect.width = size;
        newRect.height = size;
      }

      // Limiter aux bordures de l'image
      newRect.x = Math.max(0, Math.min(newRect.x, image.width - 10));
      newRect.y = Math.max(0, Math.min(newRect.y, image.height - 10));
      newRect.width = Math.max(10, Math.min(newRect.width, image.width - newRect.x));
      newRect.height = Math.max(10, Math.min(newRect.height, image.height - newRect.y));

      setCropRect(newRect);
    } else if (isDragging) {
      const newCropX = ((mouseX - dragStart.x - imgX) / imgWidth) * image.width;
      const newCropY = ((mouseY - dragStart.y - imgY) / imgHeight) * image.height;

      setCropRect(prev => ({
        ...prev,
        x: Math.max(0, Math.min(newCropX, image.width - prev.width)),
        y: Math.max(0, Math.min(newCropY, image.height - prev.height))
      }));
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
    setDragStart(null);
    setResizing(null);
  };

  const handleValidate = async () => {
    if (!image) {
      toast.error('Aucune image à recadrer');
      return;
    }

    // Créer un canvas temporaire pour extraire la zone recadrée
    const tempCanvas = document.createElement('canvas');
    tempCanvas.width = cropRect.width;
    tempCanvas.height = cropRect.height;
    const tempCtx = tempCanvas.getContext('2d');

    tempCtx.drawImage(
      image,
      cropRect.x, cropRect.y, cropRect.width, cropRect.height,
      0, 0, cropRect.width, cropRect.height
    );

    const croppedImageUrl = tempCanvas.toDataURL('image/jpeg', 0.9);
    onCropComplete(croppedImageUrl);
  };

  const totalSymbols = detectedSymbols.length;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl max-h-[90vh] flex flex-col">
        <DialogHeader>
          <DialogTitle>Recadrer le visuel avant génération de la grille</DialogTitle>
          <DialogDescription>
            Ajustez le cadre de recadrage pour sélectionner la zone à importer dans la grille
          </DialogDescription>
        </DialogHeader>

        <div className="flex gap-4 flex-1 min-h-0">
          {/* Canvas principal */}
          <div 
            ref={containerRef}
            className="flex-1 min-h-[400px] bg-slate-900 rounded-lg relative overflow-hidden"
          >
          <canvas
            ref={canvasRef}
            className="w-full h-full"
            style={{ cursor: resizing ? 'crosshair' : isDragging ? 'grabbing' : 'grab' }}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseUp}
          />
          </div>

          {/* Panneau latéral des symboles */}
          {detectedSymbols.length > 0 && (
            <div className="w-80 flex flex-col bg-white rounded-lg border border-slate-200 overflow-hidden">
              {/* Header */}
              <div 
                className="p-4 border-b border-slate-200 cursor-pointer bg-purple-50"
                onClick={() => setShowSymbolPanel(!showSymbolPanel)}
              >
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold text-purple-900 flex items-center gap-2">
                    <Sparkles className="w-4 h-4" />
                    Symboles de la légende du PDF
                  </h3>
                  {showSymbolPanel ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </div>
                {showSymbolPanel && (
                  <div className="mt-2 space-y-1 text-xs text-purple-700">
                    <p className="font-medium">{totalSymbols} symboles trouvés dans la légende</p>
                    <p className="text-xs text-slate-600">Tous les symboles proviennent de la page instruction du PDF</p>
                  </div>
                )}
              </div>

              {/* Liste des symboles */}
              {showSymbolPanel && (
                <div className="flex-1 overflow-y-auto p-4 space-y-3">
                  {detectedSymbols.length === 0 ? (
                    <div className="text-center py-8 text-slate-500">
                      <p className="text-sm">Aucune légende trouvée dans le PDF</p>
                      <p className="text-xs mt-2">Les symboles seront détectés lors de la génération de la grille</p>
                    </div>
                  ) : (
                    detectedSymbols.map((symbol, index) => (
                      <div
                        key={symbol.id}
                        className="border border-slate-200 rounded-lg p-3 hover:border-purple-400 transition-colors"
                      >
                        <div className="flex items-start gap-3">
                          {/* Pastille de couleur */}
                          <div 
                            className="w-10 h-10 rounded border border-slate-300 flex-shrink-0"
                            style={{ backgroundColor: symbol.color }}
                          />

                          {/* Infos */}
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="font-medium text-sm text-slate-900">
                                DMC {symbol.dmcCode}
                              </span>
                            </div>
                            
                            <p className="text-xs text-slate-600 mb-1">
                              {symbol.colorName}
                            </p>

                            <p className="text-xs text-slate-500">
                              Symbole : {symbol.symbol}
                            </p>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}

              {/* Actions globales */}
              {showSymbolPanel && detectedSymbols.length > 0 && (
                <div className="p-4 border-t border-slate-200 bg-slate-50">
                  <Button
                    size="sm"
                    variant="outline"
                    className="w-full mb-2"
                    onClick={() => toast.info('Modification de la légende (prochainement)')}
                  >
                    Modifier la légende
                  </Button>
                  <p className="text-xs text-slate-500 text-center">
                    Les symboles seront mappés lors de la génération
                  </p>
                </div>
              )}
            </div>
          )}
        </div>

        <div className="space-y-4">
          <div className="flex items-center gap-4">
            <Button
              variant="outline"
              size="sm"
              onClick={handleZoomIn}
              className="gap-2"
            >
              <ZoomIn className="w-4 h-4" />
              Zoom +
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={handleZoomOut}
              className="gap-2"
            >
              <ZoomOut className="w-4 h-4" />
              Zoom -
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={handleReset}
              className="gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              Réinitialiser
            </Button>
          </div>

          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2">
              <Switch
                id="lock-square"
                checked={lockSquare}
                onCheckedChange={setLockSquare}
              />
              <Label htmlFor="lock-square" className="text-sm">
                Verrouiller le ratio carré (optionnel)
              </Label>
            </div>
            <div className="flex items-center gap-2">
              <Switch
                id="lock-grid"
                checked={lockGridRatio}
                onCheckedChange={setLockGridRatio}
              />
              <Label htmlFor="lock-grid" className="text-sm">
                Adapter à la taille de la grille (optionnel)
              </Label>
            </div>
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={onClose}>
            Annuler
          </Button>
          <Button
            onClick={handleValidate}
            className="bg-purple-600 hover:bg-purple-700"
          >
            <Square className="w-4 h-4 mr-2" />
            Valider le recadrage
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}