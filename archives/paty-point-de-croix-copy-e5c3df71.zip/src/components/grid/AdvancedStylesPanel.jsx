import React, { useState } from 'react';
import { X } from 'lucide-react';
import { cn } from '@/lib/utils';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';

const styles = [
  {
    id: 'half-stitch',
    name: 'Demi-point',
    description: 'Pour lisser les arrondis et créer des dégradés.',
    icon: (
      <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M4 16L16 4L16 16L4 16Z" fill="white"/>
      </svg>
    )
  },
  {
    id: 'quarter-stitch',
    name: 'Quart / Trois-quarts de point',
    description: 'Pour les zones miniatures et les contours délicats.',
    icon: (
      <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M10 10L16 4L16 10L10 10Z" fill="white"/>
        <line x1="4" y1="16" x2="16" y2="4" stroke="white" strokeWidth="2"/>
      </svg>
    )
  },
  {
    id: 'backstitch',
    name: 'Backstitch (point arrière)',
    description: 'Pour les contours, écriture, détails fins.',
    icon: (
      <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
        <line x1="4" y1="16" x2="16" y2="4" stroke="white" strokeWidth="2" strokeLinecap="round"/>
      </svg>
    )
  },
  {
    id: 'french-knot',
    name: 'Nœud français',
    description: 'Pour les cœurs de fleurs, effets en relief.',
    icon: (
      <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="10" cy="10" r="4" fill="white"/>
      </svg>
    )
  },
  {
    id: 'beads',
    name: 'Perles',
    description: 'Pour installer des points décoratifs spéciaux.',
    icon: (
      <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="7" y="7" width="6" height="6" fill="white"/>
      </svg>
    )
  }
];

export default function AdvancedStylesPanel({ open, onClose, enabledStyles = {}, onToggleStyle }) {
  if (!open) return null;

  return (
    <>
      {/* Overlay */}
      <div 
        className="fixed inset-0 bg-black/50 z-40"
        onClick={onClose}
      />

      {/* Panel */}
      <div className="fixed top-0 right-0 h-full w-80 bg-[#111] shadow-2xl z-50 flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-[#333]">
          <div>
            <h2 className="text-lg font-bold text-white mb-1">
              🧵 Styles avancés de broderie
            </h2>
            <p className="text-xs text-slate-400">
              Active ou désactive les techniques supplémentaires selon tes besoins.
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-white hover:text-slate-300 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-3">
          <TooltipProvider delayDuration={600}>
            {styles.map((style) => (
              <Tooltip key={style.id}>
                <TooltipTrigger asChild>
                  <div
                    className={cn(
                      "bg-[#1a1a1a] rounded-lg p-4 border transition-all cursor-pointer",
                      enabledStyles[style.id] 
                        ? "border-white bg-[#222]" 
                        : "border-[#333] hover:border-[#555]"
                    )}
                    onClick={() => onToggleStyle(style.id)}
                  >
                    <div className="flex items-start gap-3">
                      <div className="flex-shrink-0 w-10 h-10 bg-[#333] rounded-lg flex items-center justify-center">
                        {style.icon}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="text-sm font-semibold text-white">
                            {style.name}
                          </h3>
                          {enabledStyles[style.id] && (
                            <div className="w-2 h-2 bg-white rounded-full animate-pulse" />
                          )}
                        </div>
                        <p className="text-xs text-slate-400 leading-relaxed">
                          {style.description}
                        </p>
                      </div>
                    </div>
                  </div>
                </TooltipTrigger>
                <TooltipContent side="left">
                  <p>Activer pour utiliser ce point dans votre grille.</p>
                </TooltipContent>
              </Tooltip>
            ))}
          </TooltipProvider>
        </div>
      </div>
    </>
  );
}