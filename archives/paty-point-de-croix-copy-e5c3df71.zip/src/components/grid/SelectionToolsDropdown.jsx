import React from 'react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { MousePointer2 } from 'lucide-react';

const SELECTION_TOOLS = [
  {
    id: 'selection-symbole',
    icon: '🟡',
    name: 'Sélection par Symbole™',
    shortDesc: 'Sélectionner ce symbole partout',
    description: 'Je choisis un symbole, l\'app le sélectionne partout dans la grille ou une zone.',
    features: ['Partout', 'Dans une zone', 'Compter les points'],
    color: '#FFC94A',
  },
  {
    id: 'selection-couleur',
    icon: '🔵',
    name: 'Sélection par Couleur™',
    shortDesc: 'Isoler une couleur DMC',
    description: 'Je clique sur une couleur DMC, l\'app sélectionne toutes les cases correspondantes.',
    features: ['Couleur exacte', 'Tolérance réglable', 'Calcul de fil'],
    color: '#3B82F6',
  },
  {
    id: 'selection-forme',
    icon: '🔴',
    name: 'Sélection Intelligente™',
    shortDesc: 'Détection automatique des contours',
    description: 'Je trace grossièrement, l\'app détecte les bordures et sélectionne la forme.',
    features: ['Contours auto', 'Zone libre', 'Nouveau motif'],
    color: '#EF4444',
  },
];

export default function SelectionToolsDropdown({ 
  children, 
  currentSubTool, 
  onSelectSubTool,
  open,
  onOpenChange 
}) {
  return (
    <DropdownMenu open={open} onOpenChange={onOpenChange}>
      <DropdownMenuTrigger asChild>
        {children}
      </DropdownMenuTrigger>
      <DropdownMenuContent 
        side="bottom" 
        align="start" 
        className="w-80 p-0 bg-[#1a1a1a] border-[#333] rounded-xl overflow-hidden"
        sideOffset={8}
      >
        {/* Header */}
        <div className="px-4 py-3 bg-gradient-to-r from-[#3B82F6]/20 to-transparent border-b border-[#333]">
          <div className="flex items-center gap-2">
            <MousePointer2 className="w-4 h-4 text-[#3B82F6]" />
            <span className="text-white font-semibold text-sm">Outils de sélection</span>
          </div>
          <p className="text-[#888] text-xs mt-1">Sélectionnez intelligemment vos points</p>
        </div>

        {/* Tools list */}
        <div className="py-2">
          {SELECTION_TOOLS.map((tool, index) => (
            <React.Fragment key={tool.id}>
              <DropdownMenuItem
                onClick={() => onSelectSubTool(tool.id)}
                className={`mx-2 px-3 py-3 rounded-lg cursor-pointer transition-all ${
                  currentSubTool === tool.id 
                    ? 'bg-white/10' 
                    : 'hover:bg-white/5'
                }`}
              >
                <div className="flex items-start gap-3 w-full">
                  {/* Icon circle */}
                  <div 
                    className="w-10 h-10 rounded-full flex items-center justify-center text-xl shrink-0"
                    style={{ backgroundColor: `${tool.color}20`, border: `2px solid ${tool.color}` }}
                  >
                    {tool.icon}
                  </div>
                  
                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-white font-semibold text-sm">{tool.name}</span>
                      {currentSubTool === tool.id && (
                        <span className="px-1.5 py-0.5 bg-[#3B82F6] text-white text-[10px] font-bold rounded">
                          ACTIF
                        </span>
                      )}
                    </div>
                    <p className="text-[#3B82F6] text-xs font-medium mt-0.5">{tool.shortDesc}</p>
                    <p className="text-[#888] text-xs mt-1 leading-relaxed">{tool.description}</p>
                    
                    {/* Features tags */}
                    <div className="flex flex-wrap gap-1 mt-2">
                      {tool.features.map((feature, i) => (
                        <span 
                          key={i}
                          className="px-2 py-0.5 bg-white/5 text-[#aaa] text-[10px] rounded-full"
                        >
                          ✓ {feature}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </DropdownMenuItem>
              
              {index < SELECTION_TOOLS.length - 1 && (
                <div className="mx-4 my-1 h-px bg-[#333]" />
              )}
            </React.Fragment>
          ))}
        </div>

        {/* Footer */}
        <div className="px-4 py-2 bg-[#111] border-t border-[#333]">
          <p className="text-[#666] text-[10px] text-center">
            💡 Astuce : <kbd className="px-1 py-0.5 bg-[#333] rounded text-[#aaa]">Échap</kbd> pour désélectionner tout
          </p>
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

export { SELECTION_TOOLS };