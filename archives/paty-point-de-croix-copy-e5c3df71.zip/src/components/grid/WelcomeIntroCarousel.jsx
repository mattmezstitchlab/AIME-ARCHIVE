import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, X, Upload, Map, Palette, Wand2, Eye, MapPin, Save, ShoppingBag, Bot, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';

const SLIDES = [
  {
    icon: Sparkles,
    title: "Bienvenue dans Brood-Way™",
    subtitle: "Là où chaque point devient éternel.",
    text: `Brood-Way™ est la première application de broderie conçue comme un véritable studio professionnel, mais pensée pour être utilisée aussi facilement qu'un carnet papier.

Ici, vous n'avez plus besoin de chercher, reconstruire, compter, télécharger des PDF ou deviner la bonne couleur : tout est automatique, intelligent et instantané.`,
    highlight: true
  },
  {
    icon: Upload,
    title: "Import Intelligent™",
    emoji: "🧠",
    text: `Importez une image, un PDF, une grille découpée ou un scan…

Brood-Way™ reconstruit automatiquement la grille complète, recolle les pages, génère les symboles, répare les manques et choisit les meilleures couleurs DMC pour vous.`
  },
  {
    icon: Map,
    title: "Navigation GPS 10×10",
    emoji: "🗺️",
    text: `Tapez une "coordonnée" comme F12 : Brood-Way™ vous téléporte directement dans la zone que vous voulez broder.

C'est plus rapide, plus clair, et impossible de se perdre dans une grande grille.`
  },
  {
    icon: Wand2,
    title: "Outils intelligents",
    emoji: "🎚️",
    text: `Crayon, Gomme, Sélection, Remplissage…

Chaque outil possède des modes intelligents (point magique, anti-bavure, nettoyage de zone, sélection par symbole, focus couleur…) pour aller 10 fois plus vite qu'avec un PDF classique.`
  },
  {
    icon: Eye,
    title: "Affichage Pro",
    emoji: "🎨",
    text: `Choisissez votre vue : Symboles, couleurs, mix, mode XXL, haute visibilité, mode nuit, anti-fatigue…

Votre grille s'adapte à vous, pas l'inverse.`
  },
  {
    icon: MapPin,
    title: "Mini-carte Pro™",
    emoji: "🧩",
    text: `Gardez toujours un aperçu de toute votre création, téléportez-vous d'un point à un autre, et suivez votre progression d'un simple coup d'œil.`
  },
  {
    icon: Save,
    title: "Sauvegarde intelligente",
    emoji: "💾",
    text: `Votre progression est enregistrée automatiquement : zones complétées, réglages, styles d'affichage, position exacte dans la grille…

Vous reprenez toujours là où vous vous êtes arrêté.`
  },
  {
    icon: ShoppingBag,
    title: "Boutique intégrée",
    emoji: "🛒",
    text: `Transformez vos créations en modèles prêts à vendre. Un seul clic suffit pour générer :
• la grille couleur
• la grille symboles
• la liste DMC
• le fichier SUB officiel
• le PDF imprimable
• et la vignette du modèle

Puis soumettez le tout directement à la boutique Brood-Way™.`
  },
  {
    icon: Bot,
    title: "BroodIA™ — Votre assistante créative",
    emoji: "🤖",
    text: `Posez-lui une question. Dites-lui où vous voulez aller. Demandez-lui comment faire.

BroodIA™ peut vous guider, analyser votre grille, vous expliquer un outil, vous corriger, ou vous mener directement à la section désirée.`
  },
  {
    icon: Sparkles,
    title: "Prête pour une nouvelle façon de broder ?",
    subtitle: "Bienvenue dans Brood-Way™",
    text: `C'est la version moderne, rapide et intuitive de la broderie traditionnelle, respectueuse des habitudes anciennes, mais propulsée par des technologies intelligentes.

👉 tout est automatisé
👉 tout est plus clair
👉 tout est plus agréable
👉 et vous brodez avec plaisir, pas avec frustration.

Là où la broderie devient simple, moderne… et infiniment plus belle.`,
    highlight: true,
    isLast: true
  }
];

export default function WelcomeIntroCarousel({ isOpen, onClose, onImport }) {
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    if (isOpen) setCurrentSlide(0);
  }, [isOpen]);

  if (!isOpen) return null;

  const slide = SLIDES[currentSlide];
  const Icon = slide.icon;

  const goNext = () => setCurrentSlide((prev) => Math.min(prev + 1, SLIDES.length - 1));
  const goPrev = () => setCurrentSlide((prev) => Math.max(prev - 1, 0));

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center pointer-events-none">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/70 backdrop-blur-sm pointer-events-auto"
        onClick={onClose}
      />
      
      {/* Carrousel */}
      <div className="relative bg-[#0a0a0a] border border-[#333] rounded-2xl shadow-2xl w-full max-w-2xl mx-4 pointer-events-auto overflow-hidden max-h-[90vh] flex flex-col">
        {/* Bouton fermer */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors z-10"
        >
          <X className="w-4 h-4 text-white" />
        </button>

        {/* Header */}
        <div className={`px-6 py-5 ${slide.highlight ? 'bg-gradient-to-r from-[#FFC94A] to-[#F97316]' : 'bg-gradient-to-r from-[#FFC94A]/20 to-[#F97316]/20'}`}>
          <div className="flex items-center gap-4">
            <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${slide.highlight ? 'bg-black/20' : 'bg-[#FFC94A]/30'}`}>
              {slide.emoji ? (
                <span className="text-2xl">{slide.emoji}</span>
              ) : (
                <Icon className={`w-6 h-6 ${slide.highlight ? 'text-black' : 'text-[#FFC94A]'}`} />
              )}
            </div>
            <div>
              <p className={`text-xs font-medium ${slide.highlight ? 'text-black/60' : 'text-white/60'}`}>
                {currentSlide + 1} / {SLIDES.length}
              </p>
              <h3 className={`text-xl font-bold ${slide.highlight ? 'text-black' : 'text-white'}`}>
                {slide.title}
              </h3>
              {slide.subtitle && (
                <p className={`text-sm mt-0.5 ${slide.highlight ? 'text-black/80' : 'text-[#FFC94A]'}`}>
                  {slide.subtitle}
                </p>
              )}
            </div>
          </div>
        </div>

        {/* Contenu scrollable */}
        <div className="p-6 overflow-y-auto flex-1">
          <p className="text-gray-300 leading-relaxed whitespace-pre-line text-sm">
            {slide.text}
          </p>
        </div>

        {/* Navigation */}
        <div className="px-6 py-4 border-t border-[#333] flex items-center justify-between bg-[#111]">
          {/* Indicateurs */}
          <div className="flex gap-1.5">
            {SLIDES.map((_, idx) => (
              <button
                key={idx}
                onClick={() => setCurrentSlide(idx)}
                className={`h-1.5 rounded-full transition-all ${
                  idx === currentSlide 
                    ? 'w-6 bg-[#FFC94A]' 
                    : idx < currentSlide 
                      ? 'w-1.5 bg-[#FFC94A]/50' 
                      : 'w-1.5 bg-white/20 hover:bg-white/30'
                }`}
              />
            ))}
          </div>

          {/* Boutons navigation */}
          <div className="flex gap-2">
            {currentSlide > 0 && (
              <button
                onClick={goPrev}
                className="w-9 h-9 rounded-lg bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors"
              >
                <ChevronLeft className="w-4 h-4 text-white" />
              </button>
            )}
            
            {slide.isLast ? (
              <Button
                onClick={() => {
                  onClose();
                  if (onImport) onImport();
                }}
                className="bg-[#FFC94A] hover:bg-[#FFD666] text-black font-bold px-6"
              >
                <Sparkles className="w-4 h-4 mr-2" />
                Commencer à broder
              </Button>
            ) : (
              <button
                onClick={goNext}
                className="px-4 h-9 rounded-lg bg-[#FFC94A] hover:bg-[#FFD666] flex items-center justify-center transition-colors text-black font-semibold text-sm"
              >
                Suivant
                <ChevronRight className="w-4 h-4 ml-1" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}