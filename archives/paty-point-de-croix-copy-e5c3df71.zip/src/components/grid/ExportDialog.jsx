import React, { useState, useEffect, useRef } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { toast } from 'sonner';
import { FileDown, Zap } from 'lucide-react';
import { exportToSub, SUB_FORMAT } from './subFormat';

export default function ExportDialog({ open, onClose, gridConfig, pattern, currentGrid }) {
  const [exportType, setExportType] = useState('pdf');
  const [pdfOptions, setPdfOptions] = useState({
    pages: 'single',
    symbols: true,
    visual: true,
    guides: true,
    size: 'a4',
    orientation: 'portrait',
    dpi: 150,
    margins: 'auto',
    quality: 'original'
  });
  const [imageOptions, setImageOptions] = useState({
    format: 'png',
    resolution: 2000,
    transparent: false,
    includeGrid: true,
    includeSymbols: true,
    includeRedLines: true,
    includeCenterMarker: true,
    includeMinimap: false
  });
  const [exportZone, setExportZone] = useState('all');
  const [previewQuality, setPreviewQuality] = useState(false);
  const previewCanvasRef = useRef(null);

  // Vérifier si une grille est disponible
  const hasGrid = gridConfig && (gridConfig.stitches?.length > 0 || pattern);

  useEffect(() => {
    if (open && hasGrid) {
      generatePreview();
    }
  }, [open, exportType, pdfOptions, imageOptions, exportZone, previewQuality]);

  const generatePreview = () => {
    const canvas = previewCanvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    const width = 300;
    const height = 400;
    
    canvas.width = width;
    canvas.height = height;

    // Fond blanc
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, width, height);

    // Aperçu simplifié selon le type
    ctx.strokeStyle = '#cbd5e1';
    ctx.lineWidth = 1;

    if (exportType === 'pdf' || exportType === 'image') {
      // Grille
      if ((exportType === 'pdf' && pdfOptions.guides) || (exportType === 'image' && imageOptions.includeGrid)) {
        for (let i = 0; i <= 10; i++) {
          const x = 20 + (i * (width - 40) / 10);
          const y = 20 + (i * (height - 40) / 10);
          ctx.beginPath();
          ctx.moveTo(x, 20);
          ctx.lineTo(x, height - 20);
          ctx.stroke();
          ctx.beginPath();
          ctx.moveTo(20, y);
          ctx.lineTo(width - 20, y);
          ctx.stroke();
        }
      }

      // Symboles
      if ((exportType === 'pdf' && pdfOptions.symbols) || (exportType === 'image' && imageOptions.includeSymbols)) {
        ctx.fillStyle = '#000000';
        ctx.font = '16px Arial';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ['●', '■', '▲', '★', '◆'].forEach((symbol, i) => {
          ctx.fillText(symbol, 50 + i * 50, height / 2);
        });
      }

      // Repère central
      if ((exportType === 'pdf' && pdfOptions.guides) || (exportType === 'image' && imageOptions.includeCenterMarker)) {
        ctx.strokeStyle = '#ff0000';
        ctx.lineWidth = 2;
        const cx = width / 2;
        const cy = height / 2;
        ctx.beginPath();
        ctx.moveTo(cx - 10, cy);
        ctx.lineTo(cx + 10, cy);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(cx, cy - 10);
        ctx.lineTo(cx, cy + 10);
        ctx.stroke();
      }
    }

    // Label du type d'export
    ctx.fillStyle = '#000000';
    ctx.font = 'bold 14px Arial';
    ctx.textAlign = 'center';
    ctx.fillText(`Aperçu ${exportType.toUpperCase()}`, width / 2, height - 10);
  };

  const handleExport = async () => {
    try {
      if (exportType === 'pdf') {
        await exportToPDF();
      } else if (exportType === 'pdf-advanced') {
        await exportToPDFAdvanced();
      } else if (exportType === 'image') {
        await exportToImage();
      } else if (exportType === 'visual') {
        await exportVisual();
      } else if (exportType === 'data') {
        await exportData();
      } else if (exportType === 'sub') {
        await exportSub();
      }

      toast.success('Votre fichier a été exporté avec succès');
      onClose();
    } catch (error) {
      console.error('Export error:', error);
      toast.error('Erreur lors de l\'export');
    }
  };

  const exportToPDFAdvanced = async () => {
    if (!pattern) {
      toast.error('Aucun motif importé - l\'export avancé nécessite un motif avec types de points');
      return;
    }

    // Import du module d'export avancé
    const { exporterPDFAvecTypesDePoints } = await import('./pdfExportStitchTypes');
    
    // Récupérer les types actifs et les calques depuis le pattern
    const typesActifs = pattern.stitchTypes || {
      full: true,
      half: false,
      quarter: false,
      backstitch: false,
      frenchknot: false,
      bead: false,
      metallic: false,
      longstitch: false,
      straightstitch: false,
      satin: false,
      bullion: false,
      couching: false
    };

    const calques = pattern.calques || {};

    await exporterPDFAvecTypesDePoints(gridConfig, pattern, typesActifs, calques);
  };

  const exportToPDF = async () => {
    // Import dynamique de jsPDF
    const { jsPDF } = await import('jspdf');
    
    const doc = new jsPDF({
      orientation: pdfOptions.orientation,
      unit: 'mm',
      format: pdfOptions.size
    });

    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();

    // Titre
    doc.setFontSize(20);
    doc.text(gridConfig?.name || 'Grille PatyBee', pageWidth / 2, 20, { align: 'center' });

    // Générer le canvas de la grille
    const canvas = document.createElement('canvas');
    const scale = pdfOptions.dpi / 72;
    canvas.width = pageWidth * scale * 3.78; // mm to px
    canvas.height = (pageHeight - 30) * scale * 3.78;
    const ctx = canvas.getContext('2d');

    // Dessiner la grille
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    if (pdfOptions.guides) {
      ctx.strokeStyle = '#cbd5e1';
      ctx.lineWidth = 1;
      const cols = gridConfig?.nb_colonnes || 50;
      const rows = gridConfig?.nb_lignes || 50;
      const cellWidth = canvas.width / cols;
      const cellHeight = canvas.height / rows;

      for (let i = 0; i <= cols; i++) {
        ctx.beginPath();
        ctx.moveTo(i * cellWidth, 0);
        ctx.lineTo(i * cellWidth, canvas.height);
        ctx.stroke();
      }
      for (let i = 0; i <= rows; i++) {
        ctx.beginPath();
        ctx.moveTo(0, i * cellHeight);
        ctx.lineTo(canvas.width, i * cellHeight);
        ctx.stroke();
      }
    }

    // Ajouter l'image au PDF
    const imgData = canvas.toDataURL('image/jpeg', pdfOptions.quality === 'original' ? 1.0 : pdfOptions.quality === 'compressed' ? 0.7 : 0.3);
    doc.addImage(imgData, 'JPEG', 10, 25, pageWidth - 20, pageHeight - 35);

    // Télécharger
    doc.save(`${gridConfig?.name || 'grille'}_patybee.pdf`);
  };

  const exportToImage = async () => {
    const canvas = document.createElement('canvas');
    canvas.width = imageOptions.resolution;
    canvas.height = imageOptions.resolution;
    const ctx = canvas.getContext('2d');

    // Fond
    if (imageOptions.transparent && imageOptions.format === 'png') {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
    } else {
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    }

    // Grille
    if (imageOptions.includeGrid) {
      ctx.strokeStyle = '#cbd5e1';
      ctx.lineWidth = 1;
      const cols = gridConfig?.nb_colonnes || 50;
      const rows = gridConfig?.nb_lignes || 50;
      const cellSize = canvas.width / cols;

      for (let i = 0; i <= cols; i++) {
        ctx.beginPath();
        ctx.moveTo(i * cellSize, 0);
        ctx.lineTo(i * cellSize, canvas.height);
        ctx.stroke();
      }
      for (let i = 0; i <= rows; i++) {
        ctx.beginPath();
        ctx.moveTo(0, i * cellSize);
        ctx.lineTo(canvas.width, i * cellSize);
        ctx.stroke();
      }
    }

    // Symboles
    if (imageOptions.includeSymbols && gridConfig?.stitches) {
      ctx.font = `${canvas.width / 100}px Arial`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      const cellSize = canvas.width / (gridConfig.nb_colonnes || 50);

      gridConfig.stitches.forEach(stitch => {
        ctx.fillStyle = stitch.color || '#000000';
        const x = stitch.col * cellSize + cellSize / 2;
        const y = stitch.row * cellSize + cellSize / 2;
        ctx.fillText(stitch.symbol || '●', x, y);
      });
    }

    // Repère central
    if (imageOptions.includeCenterMarker) {
      ctx.strokeStyle = '#ff0000';
      ctx.lineWidth = 3;
      const cx = canvas.width / 2;
      const cy = canvas.height / 2;
      const size = canvas.width / 100;
      ctx.beginPath();
      ctx.moveTo(cx - size, cy);
      ctx.lineTo(cx + size, cy);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(cx, cy - size);
      ctx.lineTo(cx, cy + size);
      ctx.stroke();
    }

    // Télécharger
    canvas.toBlob((blob) => {
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${gridConfig?.name || 'grille'}_patybee.${imageOptions.format}`;
      a.click();
      URL.revokeObjectURL(url);
    }, `image/${imageOptions.format}`, imageOptions.format === 'jpg' ? 0.92 : 1.0);
  };

  const exportVisual = async () => {
    if (!pattern?.sourceImage) {
      toast.error('Aucun visuel importé');
      return;
    }

    // Télécharger l'image source
    const a = document.createElement('a');
    a.href = pattern.sourceImage;
    a.download = `visuel_${gridConfig?.name || 'patybee'}.png`;
    a.click();
  };

  const exportData = async () => {
    const data = {
      version: '1.0',
      grid: gridConfig,
      pattern: pattern ? {
        width: pattern.width,
        height: pattern.height,
        colors: pattern.colorPalette,
        symbolGrid: pattern.symbolGrid
      } : null,
      exportDate: new Date().toISOString()
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${gridConfig?.name || 'grille'}_patybee.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const exportSub = async () => {
    const result = exportToSub(pattern, {
      name: gridConfig?.name || 'grille',
      author: 'PatyBee User',
      licenseType: 'personal',
      commercial: false
    });
    
    if (result.success) {
      toast.success(`Fichier ${result.filename} exporté avec succès`);
    }
  };

  if (!hasGrid) {
    return (
      <Dialog open={open} onOpenChange={onClose}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Impossible d'exporter</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <p className="text-slate-600">
              Aucune grille n'est ouverte.
              <br />
              Ouvrez un projet ou importez un visuel avant d'exporter.
            </p>
          </div>
          <div className="flex justify-end">
            <Button onClick={onClose} variant="outline">
              Retour
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Exporter la grille</DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-12 gap-6 py-4">
          {/* Options - Gauche */}
          <div className="col-span-7 space-y-6">
            {/* Type d'export */}
            <div className="space-y-3">
              <Label className="text-base font-semibold">Type d'export</Label>
              <RadioGroup value={exportType} onValueChange={setExportType}>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="pdf" id="pdf" />
                  <Label htmlFor="pdf" className="cursor-pointer">Exporter en PDF (simple)</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="pdf-advanced" id="pdf-advanced" />
                  <Label htmlFor="pdf-advanced" className="cursor-pointer">Exporter en PDF complet (avec types de points)</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="image" id="image" />
                  <Label htmlFor="image" className="cursor-pointer">Exporter en image (PNG/JPG)</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="visual" id="visual" />
                  <Label htmlFor="visual" className="cursor-pointer">Exporter uniquement le visuel</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="data" id="data" />
                  <Label htmlFor="data" className="cursor-pointer">Exporter les données (.json)</Label>
                </div>
                <div className="flex items-center space-x-2 p-2 bg-gradient-to-r from-yellow-50 to-orange-50 rounded-lg border border-yellow-200">
                  <RadioGroupItem value="sub" id="sub" />
                  <Label htmlFor="sub" className="cursor-pointer flex items-center gap-2">
                    <Zap className="w-4 h-4 text-yellow-600" />
                    <span className="font-semibold text-yellow-800">Exporter en .SUB</span>
                    <span className="text-xs text-yellow-600">(Format standard SUB™)</span>
                  </Label>
                </div>
              </RadioGroup>
            </div>

            {/* Options PDF */}
            {(exportType === 'pdf' || exportType === 'pdf-advanced') && (
              <div className="space-y-4 p-4 bg-slate-50 rounded-lg">
                <h3 className="font-semibold">Options PDF</h3>
                
                {exportType === 'pdf-advanced' && (
                  <div className="p-3 bg-indigo-50 border border-indigo-200 rounded-lg">
                    <p className="text-sm text-indigo-900">
                      ✨ Export complet avec 4 pages : vue globale, tableau des couleurs par type de point, 
                      liste des techniques utilisées, et guide d'instructions détaillé.
                    </p>
                  </div>
                )}
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Type de pages</Label>
                    <Select value={pdfOptions.pages} onValueChange={(v) => setPdfOptions({...pdfOptions, pages: v})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="single">Une seule page</SelectItem>
                        <SelectItem value="multi">Multi-pages automatique</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Taille</Label>
                    <Select value={pdfOptions.size} onValueChange={(v) => setPdfOptions({...pdfOptions, size: v})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="a4">A4</SelectItem>
                        <SelectItem value="letter">Lettre</SelectItem>
                        <SelectItem value="auto">Automatique</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Orientation</Label>
                    <Select value={pdfOptions.orientation} onValueChange={(v) => setPdfOptions({...pdfOptions, orientation: v})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="portrait">Portrait</SelectItem>
                        <SelectItem value="landscape">Paysage</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Résolution</Label>
                    <Select value={String(pdfOptions.dpi)} onValueChange={(v) => setPdfOptions({...pdfOptions, dpi: Number(v)})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="72">72 DPI</SelectItem>
                        <SelectItem value="150">150 DPI</SelectItem>
                        <SelectItem value="300">300 DPI</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label>Inclure les symboles</Label>
                    <Switch checked={pdfOptions.symbols} onCheckedChange={(v) => setPdfOptions({...pdfOptions, symbols: v})} />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label>Inclure le visuel</Label>
                    <Switch checked={pdfOptions.visual} onCheckedChange={(v) => setPdfOptions({...pdfOptions, visual: v})} />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label>Inclure les repères</Label>
                    <Switch checked={pdfOptions.guides} onCheckedChange={(v) => setPdfOptions({...pdfOptions, guides: v})} />
                  </div>
                </div>
              </div>
            )}

            {/* Options Image */}
            {exportType === 'image' && (
              <div className="space-y-4 p-4 bg-slate-50 rounded-lg">
                <h3 className="font-semibold">Options Image</h3>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Format</Label>
                    <Select value={imageOptions.format} onValueChange={(v) => setImageOptions({...imageOptions, format: v})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="png">PNG</SelectItem>
                        <SelectItem value="jpg">JPG</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Résolution (px)</Label>
                    <Input 
                      type="number" 
                      value={imageOptions.resolution}
                      onChange={(e) => setImageOptions({...imageOptions, resolution: Number(e.target.value)})}
                    />
                  </div>
                </div>

                <div className="space-y-3">
                  {imageOptions.format === 'png' && (
                    <div className="flex items-center justify-between">
                      <Label>Fond transparent</Label>
                      <Switch checked={imageOptions.transparent} onCheckedChange={(v) => setImageOptions({...imageOptions, transparent: v})} />
                    </div>
                  )}
                  <div className="flex items-center justify-between">
                    <Label>Inclure la grille</Label>
                    <Switch checked={imageOptions.includeGrid} onCheckedChange={(v) => setImageOptions({...imageOptions, includeGrid: v})} />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label>Inclure les symboles</Label>
                    <Switch checked={imageOptions.includeSymbols} onCheckedChange={(v) => setImageOptions({...imageOptions, includeSymbols: v})} />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label>Inclure les lignes rouges</Label>
                    <Switch checked={imageOptions.includeRedLines} onCheckedChange={(v) => setImageOptions({...imageOptions, includeRedLines: v})} />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label>Inclure le repère central</Label>
                    <Switch checked={imageOptions.includeCenterMarker} onCheckedChange={(v) => setImageOptions({...imageOptions, includeCenterMarker: v})} />
                  </div>
                </div>
              </div>
            )}

            {/* Zone d'export */}
            <div className="space-y-3">
              <Label className="text-base font-semibold">Zone d'export</Label>
              <RadioGroup value={exportZone} onValueChange={setExportZone}>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="all" id="all" />
                  <Label htmlFor="all" className="cursor-pointer">Toute la grille</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="visible" id="visible" />
                  <Label htmlFor="visible" className="cursor-pointer">Zone visible uniquement</Label>
                </div>
              </RadioGroup>
            </div>
          </div>

          {/* Aperçu - Droite */}
          <div className="col-span-5">
            <div className="sticky top-4 space-y-4">
              <div className="space-y-2">
                <Label className="text-base font-semibold">Aperçu</Label>
                <div className="flex items-center space-x-2">
                  <Switch checked={previewQuality} onCheckedChange={setPreviewQuality} />
                  <Label className="text-sm text-slate-600">Haute qualité</Label>
                </div>
              </div>
              
              <div className="border-2 border-slate-200 rounded-lg p-4 bg-slate-50">
                <canvas 
                  ref={previewCanvasRef}
                  className="w-full h-auto border border-slate-300 bg-white"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex justify-end gap-3 pt-4 border-t">
          <Button onClick={onClose} variant="outline">
            Annuler
          </Button>
          <Button onClick={handleExport} className="bg-slate-900 hover:bg-slate-800 gap-2">
            <FileDown className="w-4 h-4" />
            Exporter
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}