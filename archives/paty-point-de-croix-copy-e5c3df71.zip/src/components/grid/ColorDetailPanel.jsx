import React, { useState } from 'react';
import { X, Edit2, CheckCircle, Trash2, GitMerge } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';

export default function ColorDetailPanel({ 
  color, 
  onClose, 
  onUpdateSymbol,
  onUpdateColor,
  onMarkAsDone,
  onDelete,
  onMergeWith,
  showAdvancedStats = false
}) {
  const [isEditing, setIsEditing] = useState(false);

  if (!color) return null;

  return (
    <div className="fixed right-0 top-[60px] bottom-[140px] w-80 bg-white border-l border-slate-200 shadow-xl z-50 overflow-y-auto">
      {/* Header */}
      <div className="sticky top-0 bg-white border-b border-slate-200 p-4 flex items-center justify-between">
        <h3 className="font-semibold text-lg">Détails de la couleur</h3>
        <button
          onClick={onClose}
          className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="p-4 space-y-6">
        {/* A. Informations générales */}
        <section className="space-y-3">
          <h4 className="font-medium text-sm text-slate-600">Informations générales</h4>
          
          {/* Aperçu couleur */}
          <div 
            className="w-full h-20 rounded-lg border-2 border-slate-200"
            style={{ backgroundColor: color.hex }}
          />
          
          <div className="space-y-1">
            <p className="text-sm">
              <span className="font-semibold">{color.name || 'Sans nom'}</span>
            </p>
            <p className="text-xs text-slate-600">
              Code: {color.code || 'N/A'}
            </p>
            <p className="text-xs text-slate-600">
              {color.totalCount || 0} points dans la grille
            </p>
          </div>

          {/* Symbole */}
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-slate-100 rounded flex items-center justify-center">
              <span className="text-xl font-bold">{color.assignedSymbolChar || '●'}</span>
            </div>
            <div className="text-xs text-slate-600">Symbole assigné</div>
          </div>
        </section>

        {/* B. Édition rapide */}
        <section className="space-y-3 pt-6 border-t border-slate-200">
          <h4 className="font-medium text-sm text-slate-600">Édition rapide</h4>
          
          <Button
            variant="outline"
            size="sm"
            className="w-full justify-start"
            onClick={() => onUpdateSymbol?.(color)}
          >
            <Edit2 className="w-4 h-4 mr-2" />
            Modifier le symbole
          </Button>

          <Button
            variant="outline"
            size="sm"
            className="w-full justify-start"
            onClick={() => onUpdateColor?.(color)}
          >
            <Edit2 className="w-4 h-4 mr-2" />
            Modifier la couleur DMC
          </Button>
        </section>

        {/* C. Marquer comme brodé */}
        <section className="space-y-3 pt-6 border-t border-slate-200">
          <h4 className="font-medium text-sm text-slate-600">Progression</h4>
          
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="mark-done" className="text-sm">Marqué comme brodé</Label>
              <Switch
                id="mark-done"
                checked={color.progress === 100}
                onCheckedChange={() => onMarkAsDone?.(color.id)}
              />
            </div>
            
            <Progress value={color.progress || 0} className="h-2" />
            
            <p className="text-xs text-slate-600">
              {color.doneCount || 0} / {color.totalCount || 0} points brodés ({color.progress || 0}%)
            </p>
          </div>
        </section>

        {/* D. Statistiques avancées */}
        {showAdvancedStats && (
          <section className="space-y-3 pt-6 border-t border-slate-200">
            <h4 className="font-medium text-sm text-slate-600">Statistiques avancées</h4>
            
            <div className="text-xs space-y-1">
              <p className="flex justify-between">
                <span className="text-slate-600">Taille moyenne des zones:</span>
                <span className="font-medium">3.2 points</span>
              </p>
              <p className="flex justify-between">
                <span className="text-slate-600">Répartition:</span>
                <span className="font-medium">Nord-Est</span>
              </p>
              <p className="flex justify-between">
                <span className="text-slate-600">Points restants:</span>
                <span className="font-medium">{(color.totalCount || 0) - (color.doneCount || 0)}</span>
              </p>
            </div>
          </section>
        )}

        {/* E. Actions */}
        <section className="space-y-2 pt-6 border-t border-slate-200">
          <h4 className="font-medium text-sm text-slate-600">Actions</h4>
          
          <Button
            variant="outline"
            size="sm"
            className="w-full justify-start text-slate-600"
            onClick={() => onMergeWith?.(color)}
          >
            <GitMerge className="w-4 h-4 mr-2" />
            Fusionner avec une autre couleur
          </Button>

          <Button
            variant="outline"
            size="sm"
            className="w-full justify-start text-red-600 hover:text-red-700 hover:bg-red-50"
            onClick={() => {
              if (confirm('Supprimer cette couleur de la grille ?')) {
                onDelete?.(color.id);
              }
            }}
          >
            <Trash2 className="w-4 h-4 mr-2" />
            Supprimer cette couleur
          </Button>
        </section>
      </div>
    </div>
  );
}