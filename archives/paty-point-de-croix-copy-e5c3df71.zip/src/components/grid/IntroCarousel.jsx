import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

// Logo PatyBee - Identique à celui du TopMenu
function PatyBeeLogo() {
  return (
    <svg width="52" height="52" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
      <style>
        {`
          @keyframes star-anim {
            0%, 100% { fill: #FFFFFF; transform: rotate(0deg); }
            5% { fill: #F5C200; }
            20% { fill: #F5C200; transform: rotate(360deg); }
            22%, 100% { fill: #FFFFFF; transform: rotate(360deg); }
          }
          
          @keyframes diamond-anim {
            0%, 22%, 100% { fill: #FFFFFF; transform: rotate(0deg); }
            27% { fill: #2F80ED; }
            42% { fill: #2F80ED; transform: rotate(15deg); }
            44%, 100% { fill: #FFFFFF; transform: rotate(0deg); }
          }
          
          @keyframes circle-anim {
            0%, 44%, 100% { fill: #FFFFFF; opacity: 1; }
            49% { fill: #27AE60; opacity: 1; }
            55% { fill: #27AE60; opacity: 0.4; }
            61% { fill: #27AE60; opacity: 1; }
            64%, 100% { fill: #FFFFFF; opacity: 1; }
          }
          
          @keyframes square-anim {
            0%, 64%, 100% { fill: #FFFFFF; transform: rotate(0deg); }
            69% { fill: #EB5BA9; }
            79% { fill: #EB5BA9; transform: rotate(90deg); }
            84% { fill: #EB5BA9; transform: rotate(0deg); }
            86%, 100% { fill: #FFFFFF; transform: rotate(0deg); }
          }
          
          .star { 
            animation: star-anim 3.7s ease-in-out infinite;
            transform-origin: 9px 8.5px;
          }
          .circle { 
            animation: circle-anim 3.7s ease-in-out infinite;
          }
          .square { 
            animation: square-anim 3.7s ease-in-out infinite;
            transform-origin: 7.5px 26px;
          }
          .diamond { 
            animation: diamond-anim 3.7s ease-in-out infinite;
            transform-origin: 26.5px 26px;
          }
        `}
      </style>
      
      <path className="star" d="M9 2L10.5 7L15.5 8.5L10.5 10L9 15L7.5 10L2.5 8.5L7.5 7L9 2Z" fill="#FFFFFF"/>
      <circle className="circle" cx="26.5" cy="9" r="5" fill="#FFFFFF"/>
      <rect className="square" x="2.5" y="21" width="10" height="10" fill="#FFFFFF"/>
      <path className="diamond" d="M26.5 21L31.5 26L26.5 31L21.5 26L26.5 21Z" fill="#FFFFFF"/>
    </svg>
  );
}

const SLIDES = [
  {
    title: "UNE INNOVATION BREVETÉE",
    text: "La première révolution du point de croix.\nImaginée pour transformer l'art de broder.\nDéposée comme une invention officielle.",
    button: null
  },
  {
    title: "UNE HISTOIRE INVISIBLE",
    text: "Née en 2005 par un jeune créateur.\nRévélée au monde en 2025.\nUn destin écrit dans la discrétion.",
    button: "En savoir plus"
  },
  {
    title: "LA REINE IA",
    text: "Un clic en haut à droite.\nDiscutez avec la Reine de la ruche.\nVotre guide et mentor personnel.",
    button: null
  },
  {
    title: "OPTIMISATION INTELLIGENTE",
    text: "Les couleurs deviennent simples.\nLes difficultés disparaissent.\nVotre temps est optimisé.",
    button: null
  },
  {
    title: "LA QUINTESSENCE",
    text: "Où que vous soyez dans la grille.\nPeu importe l'humeur ou la difficulté.\nVoici le miel pur de votre création.",
    button: null
  },
  {
    title: "SIGNATURE VIBRATOIRE",
    text: "Votre profil est un brevet.\nUne grille 10×10 = votre âme.\nUne identité vibratoire unique au monde.",
    button: null
  },
  {
    title: "IMPORTATION PARFAITE",
    text: "Images, PDF, mosaïques.\nUne précision exceptionnelle.\nLe nouveau format .PBX.",
    button: null
  },
  {
    title: "EXPORTATION HAUTE DÉFINITION",
    text: "PDF premium.\nImages optimisées.\nFichiers .PBX prêts à partager.",
    button: null
  },
  {
    title: "PRÉPARATION AVANCÉE",
    text: "Analyse, conversions, dégradés.\nCorrespondances automatiques.\nPréparation avant broderie.",
    button: null
  },
  {
    title: "BOUTIQUE MONDIALE",
    text: "Vendez vos créations.\n100% sécurité droits d'auteur.\nRevenus équitables pour toutes.",
    button: null
  },
  {
    title: "FILTRES & TRI PRO™",
    text: "Synchronicités de Jung.\nQR code humain breveté.\nCompatibilité âme–grille unique.",
    button: null
  },
  {
    title: "MAP ULTRA INTELLIGENTE",
    text: "Guidage avancé.\nNavigation instantanée.\nZones simples ou complexes.",
    button: null
  },
  {
    title: "ART-THÉRAPIE & INCLUSION",
    text: "Enfants, seniors, duos.\nGuérison émotionnelle.\nUn futur profondément humain.",
    button: null
  },
  {
    title: "UNE GRANDE MARQUE",
    text: "Prestige unique au monde.\nFondée sur l'Art conceptuel.\nBien plus grand que vous l'imaginez.",
    button: null
  }
];

export default function IntroCarousel({ isOpen, onStart, onSubscribe }) {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  // Auto-rotation toutes les 5 secondes
  useEffect(() => {
    if (!isOpen || isPaused) return;

    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % SLIDES.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [isOpen, isPaused]);

  if (!isOpen) return null;

  const currentSlideData = SLIDES[currentSlide];

  const goToNext = () => {
    setCurrentSlide((prev) => (prev + 1) % SLIDES.length);
  };

  const goToPrev = () => {
    setCurrentSlide((prev) => (prev - 1 + SLIDES.length) % SLIDES.length);
  };

  const goToSlide = (index) => {
    setCurrentSlide(index);
  };

  return (
    <div 
      className="fixed inset-0 z-[100] flex flex-col items-center justify-center"
      style={{ backgroundColor: 'rgba(0, 0, 0, 0.95)' }}
    >
      {/* Logo PatyBee TOP CENTER */}
      <div className="absolute top-12 left-1/2 -translate-x-1/2 flex flex-col items-center gap-3">
        <PatyBeeLogo />
        <div className="flex text-4xl font-semibold tracking-wide text-white">
          <span>Paty</span>
          <span>Bee</span>
        </div>
      </div>

      {/* Contenu du carrousel */}
      <div 
        className="relative w-full max-w-4xl mx-4"
        onMouseEnter={() => setIsPaused(true)}
        onMouseLeave={() => setIsPaused(false)}
      >
        {/* Contenu du slide */}
        <div className="p-12 min-h-[450px] flex flex-col items-center justify-center text-center">
          {/* Titre avec animation */}
          <h2 className="text-5xl font-bold text-white mb-8 tracking-tight animate-in fade-in slide-in-from-bottom-4 duration-500">
            {currentSlideData.title}
          </h2>

          {/* Texte avec animation */}
          <div className="text-xl text-white/70 leading-relaxed max-w-2xl whitespace-pre-line animate-in fade-in slide-in-from-bottom-2 duration-700 delay-200">
            {currentSlideData.text}
          </div>
        </div>

        {/* Navigation flèches */}
        <div className="absolute top-1/2 -translate-y-1/2 left-0 right-0 flex items-center justify-between px-4 pointer-events-none">
          <button
            onClick={goToPrev}
            className="pointer-events-auto w-12 h-12 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors"
          >
            <ChevronLeft className="w-6 h-6 text-white" />
          </button>
          <button
            onClick={goToNext}
            className="pointer-events-auto w-12 h-12 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors"
          >
            <ChevronRight className="w-6 h-6 text-white" />
          </button>
        </div>

        {/* Indicateurs de slide */}
        <div className="flex justify-center gap-2 mt-8">
          {SLIDES.map((_, index) => (
            <button
              key={index}
              onClick={() => goToSlide(index)}
              className={`w-2 h-2 rounded-full transition-all ${
                index === currentSlide 
                  ? 'bg-[#FFC800] w-8' 
                  : 'bg-white/30 hover:bg-white/50'
              }`}
            />
          ))}
        </div>
      </div>

      {/* Boutons globaux en bas */}
      <div className="absolute bottom-12 left-1/2 -translate-x-1/2 flex justify-center gap-4">
        <Button
          onClick={onStart}
          className="bg-[#FFC94A] hover:bg-[#FFD666] text-black font-bold px-10 py-6 text-lg rounded-lg"
        >
          IMPORTER UN MOTIF
        </Button>
        <Button
          onClick={onSubscribe}
          variant="outline"
          className="bg-transparent hover:bg-white/10 text-white border-2 border-white font-semibold px-10 py-6 text-lg rounded-lg"
        >
          S'ABONNER
        </Button>
      </div>
    </div>
  );
}