/**
 * Moteur d'export PDF avec types de points et techniques avancées
 */

import { jsPDF } from 'jspdf';

// ========== 1. POINT D'ENTRÉE ==========

export async function exporterPDFAvecTypesDePoints(grille, pattern, typesActifs) {
  const pdf = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4'
  });

  // Page 1: Visuel global
  await ajouterPage_VisuelGlobal(pdf, grille, pattern, typesActifs);

  // Page 2: Légende des couleurs avec types de points
  ajouterPage_LegendeCouleurs(pdf, pattern, typesActifs);

  // Page 3: Types de points utilisés
  ajouterPage_TypesDePoints(pdf, typesActifs);

  // Page 4: Instructions techniques
  ajouterPage_InstructionsTechniques(pdf, typesActifs);

  // Télécharger
  const fileName = `${grille.name || 'grille'}_${Date.now()}.pdf`;
  pdf.save(fileName);
  
  return fileName;
}

// ========== 2. PAGE 1 — VISUEL GLOBAL ==========

async function ajouterPage_VisuelGlobal(pdf, grille, pattern, typesActifs) {
  // Titre
  pdf.setFontSize(18);
  pdf.setFont('helvetica', 'bold');
  pdf.text('Grille de point de croix générée avec PatyBee', 105, 20, { align: 'center' });

  // Sous-titre
  pdf.setFontSize(10);
  pdf.setFont('helvetica', 'normal');
  pdf.text('Vue globale de la grille, avec tous les points et couleurs.', 105, 28, { align: 'center' });

  // Image de la grille (si pattern disponible)
  if (pattern && pattern.sourceImage) {
    try {
      const imgData = await loadImageAsBase64(pattern.sourceImage);
      const imgWidth = 150;
      const imgHeight = (pattern.height / pattern.width) * imgWidth;
      const x = (210 - imgWidth) / 2;
      pdf.addImage(imgData, 'PNG', x, 40, imgWidth, Math.min(imgHeight, 200));
    } catch (error) {
      console.error('Erreur chargement image:', error);
    }
  }

  // Informations de base
  pdf.setFontSize(9);
  const y = pattern ? 250 : 50;
  pdf.text(`Dimensions: ${grille.nb_colonnes} × ${grille.nb_lignes} cases`, 20, y);
  
  if (pattern && pattern.colorPalette) {
    pdf.text(`Couleurs DMC: ${pattern.colorPalette.length}`, 20, y + 6);
    const totalPoints = pattern.colorPalette.reduce((sum, c) => sum + (c.totalCount || 0), 0);
    pdf.text(`Nombre total de points: ${totalPoints}`, 20, y + 12);
  }

  // Résumé des types de points
  const resume = construireResumeTypesPoints(typesActifs);
  pdf.setFontSize(8);
  pdf.setFont('helvetica', 'italic');
  pdf.text(resume, 105, 280, { align: 'center', maxWidth: 170 });
}

function construireResumeTypesPoints(typesActifs) {
  if (!typesActifs) return 'Types de points: Point de croix complet uniquement';
  
  const types = [];
  if (typesActifs.full) types.push('Point de croix complet');
  if (typesActifs.half) types.push('Demi-points');
  if (typesActifs.quarter) types.push('Points fractionnés (¼/¾)');
  if (typesActifs.backstitch) types.push('Backstitch');
  if (typesActifs.frenchknot) types.push('Nœuds français');
  if (typesActifs.bead) types.push('Perles');
  if (typesActifs.metallic) types.push('Fils métalliques');
  if (typesActifs.longstitch) types.push('Points longs');
  if (typesActifs.straightstitch) types.push('Points droits');
  if (typesActifs.satin) types.push('Point de satin');
  if (typesActifs.bullion) types.push('Bullion knot');
  if (typesActifs.couching) types.push('Couching');

  return `Types de points utilisés: ${types.join(' · ')}`;
}

// ========== 3. PAGE 2 — LÉGENDE DES COULEURS ==========

function ajouterPage_LegendeCouleurs(pdf, pattern, typesActifs) {
  pdf.addPage();
  
  // Titre
  pdf.setFontSize(16);
  pdf.setFont('helvetica', 'bold');
  pdf.text('Légende des couleurs et types de points', 105, 20, { align: 'center' });

  if (!pattern || !pattern.colorPalette || pattern.colorPalette.length === 0) {
    pdf.setFontSize(10);
    pdf.text('Aucune palette de couleurs disponible', 105, 50, { align: 'center' });
    return;
  }

  // En-tête du tableau
  let y = 35;
  pdf.setFontSize(9);
  pdf.setFont('helvetica', 'bold');
  
  pdf.text('Couleur', 15, y);
  pdf.text('DMC', 35, y);
  pdf.text('Nom', 55, y);
  pdf.text('Symbole', 100, y);
  pdf.text('Points', 120, y);
  pdf.text('Types utilisés', 145, y);
  
  // Ligne de séparation
  pdf.setLineWidth(0.3);
  pdf.line(10, y + 2, 200, y + 2);

  // Contenu du tableau
  pdf.setFont('helvetica', 'normal');
  pdf.setFontSize(8);
  y += 8;

  pattern.colorPalette.forEach((color, index) => {
    if (y > 270) {
      pdf.addPage();
      y = 20;
      
      // Réafficher l'en-tête
      pdf.setFont('helvetica', 'bold');
      pdf.setFontSize(9);
      pdf.text('Couleur', 15, y);
      pdf.text('DMC', 35, y);
      pdf.text('Nom', 55, y);
      pdf.text('Symbole', 100, y);
      pdf.text('Points', 120, y);
      pdf.text('Types utilisés', 145, y);
      pdf.line(10, y + 2, 200, y + 2);
      
      pdf.setFont('helvetica', 'normal');
      pdf.setFontSize(8);
      y += 8;
    }

    // Carré de couleur
    pdf.setFillColor(color.hex);
    pdf.rect(15, y - 3, 8, 5, 'F');
    pdf.setDrawColor(0);
    pdf.rect(15, y - 3, 8, 5, 'S');

    // Code DMC
    pdf.text(color.code || '?', 35, y);

    // Nom de la couleur
    const colorName = (color.name || 'Sans nom').substring(0, 30);
    pdf.text(colorName, 55, y);

    // Symbole
    pdf.text(color.assignedSymbolChar || '●', 100, y);

    // Nombre de points
    pdf.text((color.totalCount || 0).toString(), 120, y);

    // Types de points utilisés pour cette couleur
    const typesForColor = getTypesForColor(color, typesActifs);
    pdf.setFontSize(7);
    pdf.text(typesForColor, 145, y, { maxWidth: 50 });
    pdf.setFontSize(8);

    y += 7;
  });
}

function getTypesForColor(color, typesActifs) {
  if (!color.stitchTypeStats || !typesActifs) return 'Croix';
  
  const types = [];
  const stats = color.stitchTypeStats;
  
  if (stats.full > 0) types.push(`Croix (${stats.full})`);
  if (stats.half > 0 && typesActifs.half) types.push(`½ (${stats.half})`);
  if (stats.quarter > 0 && typesActifs.quarter) types.push(`¼ (${stats.quarter})`);
  if (stats.frenchknot > 0 && typesActifs.frenchknot) types.push(`Nœud (${stats.frenchknot})`);
  if (stats.bead > 0 && typesActifs.bead) types.push(`Perle (${stats.bead})`);
  if (stats.metallic > 0 && typesActifs.metallic) types.push(`Metal (${stats.metallic})`);

  return types.length > 0 ? types.join(', ') : 'Croix';
}

// ========== 4. PAGE 3 — TYPES DE POINTS ==========

function ajouterPage_TypesDePoints(pdf, typesActifs) {
  pdf.addPage();
  
  // Titre
  pdf.setFontSize(16);
  pdf.setFont('helvetica', 'bold');
  pdf.text('Types de points utilisés dans ce modèle', 105, 20, { align: 'center' });

  let y = 35;
  pdf.setFontSize(10);
  pdf.setFont('helvetica', 'normal');

  // Types de base
  if (typesActifs?.full !== false) {
    ajouterTypeDePoint(pdf, y, '● Point de croix complet', 'Point de base, forme un X complet dans la case.');
    y += 15;
  }

  if (typesActifs?.half) {
    ajouterTypeDePoint(pdf, y, '/ Demi-point', 'Moitié du point de croix, forme une diagonale (/ ou \\).');
    y += 15;
  }

  if (typesActifs?.quarter) {
    ajouterTypeDePoint(pdf, y, '¼ Points fractionnés', 'Quart ou trois-quarts de point pour les détails fins.');
    y += 15;
  }

  if (typesActifs?.backstitch) {
    ajouterTypeDePoint(pdf, y, '— Backstitch', 'Point arrière pour délimiter les contours et ajouter des détails.');
    y += 15;
  }

  // Points spéciaux
  if (typesActifs?.frenchknot) {
    ajouterTypeDePoint(pdf, y, '• Nœud français', 'Petit nœud en relief pour les points isolés.');
    y += 15;
  }

  if (typesActifs?.bead) {
    ajouterTypeDePoint(pdf, y, '◦ Perles', 'Perles de rocaille pour les zones brillantes.');
    y += 15;
  }

  if (typesActifs?.metallic) {
    ajouterTypeDePoint(pdf, y, '✧ Fils métalliques', 'Fils métalliques or/argent pour l\'effet brillant.');
    y += 15;
  }

  // Points avancés
  if (typesActifs?.longstitch) {
    ajouterTypeDePoint(pdf, y, '│ Points longs', 'Points longs pour remplir rapidement les zones uniformes.');
    y += 15;
  }

  if (typesActifs?.satin) {
    ajouterTypeDePoint(pdf, y, '═ Point de satin', 'Points parallèles serrés pour un effet satiné.');
    y += 15;
  }

  if (typesActifs?.couching) {
    ajouterTypeDePoint(pdf, y, '∿ Couching', 'Fil posé maintenu par de petits points.');
    y += 15;
  }

  if (typesActifs?.bullion) {
    ajouterTypeDePoint(pdf, y, '∞ Bullion knot', 'Nœud enroulé en forme de baguette pour texture en relief.');
    y += 15;
  }
}

function ajouterTypeDePoint(pdf, y, titre, description) {
  pdf.setFont('helvetica', 'bold');
  pdf.text(titre, 20, y);
  
  pdf.setFont('helvetica', 'normal');
  pdf.setFontSize(9);
  pdf.text(description, 20, y + 5, { maxWidth: 170 });
  pdf.setFontSize(10);
}

// ========== 5. PAGE 4 — INSTRUCTIONS TECHNIQUES ==========

function ajouterPage_InstructionsTechniques(pdf, typesActifs) {
  pdf.addPage();
  
  // Titre
  pdf.setFontSize(16);
  pdf.setFont('helvetica', 'bold');
  pdf.text('Instructions techniques', 105, 20, { align: 'center' });

  let y = 35;
  pdf.setFontSize(10);
  pdf.setFont('helvetica', 'normal');

  // Instructions générales
  pdf.setFont('helvetica', 'bold');
  pdf.text('Matériel recommandé:', 20, y);
  y += 7;
  
  pdf.setFont('helvetica', 'normal');
  pdf.setFontSize(9);
  pdf.text('• Toile Aida ou lin selon votre préférence', 25, y);
  y += 5;
  pdf.text('• Fils DMC selon la palette fournie', 25, y);
  y += 5;
  pdf.text('• Aiguille à broder n°24 ou n°26', 25, y);
  y += 5;
  pdf.text('• Cercle ou tambour à broder', 25, y);
  y += 10;

  // Instructions spécifiques selon types activés
  pdf.setFont('helvetica', 'bold');
  pdf.setFontSize(10);
  pdf.text('Conseils par type de point:', 20, y);
  y += 7;
  pdf.setFont('helvetica', 'normal');
  pdf.setFontSize(9);

  if (typesActifs?.half) {
    pdf.text('Demi-points: Brodez tous les demi-points dans le même sens pour un rendu uniforme.', 20, y, { maxWidth: 170 });
    y += 10;
  }

  if (typesActifs?.backstitch) {
    pdf.text('Backstitch: À réaliser en dernier, après tous les points de croix, avec 2 brins de fil.', 20, y, { maxWidth: 170 });
    y += 10;
  }

  if (typesActifs?.frenchknot) {
    pdf.text('Nœuds français: Enroulez le fil 2 fois autour de l\'aiguille pour un nœud bien visible.', 20, y, { maxWidth: 170 });
    y += 10;
  }

  if (typesActifs?.bead) {
    pdf.text('Perles: Utilisez un fil fin et une aiguille spéciale perles. Fixez bien chaque perle.', 20, y, { maxWidth: 170 });
    y += 10;
  }

  if (typesActifs?.metallic) {
    pdf.text('Fils métalliques: Utilisez des longueurs courtes (30cm max) pour éviter l\'usure du fil.', 20, y, { maxWidth: 170 });
    y += 10;
  }

  if (typesActifs?.satin) {
    pdf.text('Point de satin: Gardez une tension régulière et des points bien parallèles pour un bel effet.', 20, y, { maxWidth: 170 });
    y += 10;
  }

  y += 10;
  pdf.setFont('helvetica', 'bold');
  pdf.text('Ordre de broderie recommandé:', 20, y);
  y += 7;
  pdf.setFont('helvetica', 'normal');
  pdf.text('1. Points de croix complets et demi-points', 25, y);
  y += 5;
  pdf.text('2. Points fractionnés', 25, y);
  y += 5;
  pdf.text('3. Points spéciaux (nœuds, perles, métalliques)', 25, y);
  y += 5;
  pdf.text('4. Backstitch et contours', 25, y);
  y += 5;
  pdf.text('5. Points décoratifs (satin, bullion, couching)', 25, y);
}

// ========== UTILITAIRES ==========

function loadImageAsBase64(url) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      
      const ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0);
      
      resolve(canvas.toDataURL('image/png'));
    };
    
    img.onerror = reject;
    img.src = url;
  });
}