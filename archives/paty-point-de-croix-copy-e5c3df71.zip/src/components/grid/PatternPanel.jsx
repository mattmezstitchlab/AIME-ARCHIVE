import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Eye, EyeOff, Image as ImageIcon, Palette, Sparkles } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function PatternPanel({ 
  pattern, 
  showPattern,
  onTogglePattern,
  onClearPattern,
  referenceImage,
  onGenerateFromReference
}) {
  if (!pattern && !referenceImage) return null;

  // Affichage pour visuel de référence sans grille
  if (referenceImage && !pattern) {
    return (
      <Card className="bg-white/90 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Image className="w-5 h-5" />
            Visuel de référence
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="aspect-square w-full overflow-hidden rounded-lg border border-slate-200">
            <img 
              src={referenceImage} 
              alt="Référence" 
              className="w-full h-full object-contain"
            />
          </div>
          
          <Button 
            onClick={onGenerateFromReference}
            className="w-full bg-purple-600 hover:bg-purple-700"
          >
            <Sparkles className="w-4 h-4 mr-2" />
            Générer la grille
          </Button>

          <div className="text-xs text-slate-500 bg-slate-50 p-3 rounded">
            💡 Votre visuel est chargé. Cliquez pour générer la grille avec détection automatique des couleurs et symboles.
          </div>
        </CardContent>
      </Card>
    );
  }

  const totalStitches = pattern.stitches?.length || 0;
  const doneStitches = pattern.stitches?.filter(s => s.done).length || 0;
  const progress = totalStitches > 0 ? (doneStitches / totalStitches) * 100 : 0;

  return (
    <Card className="bg-white rounded-2xl shadow-lg border border-slate-200">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-semibold text-slate-700 uppercase tracking-wide flex items-center gap-2">
          <ImageIcon className="w-4 h-4" />
          Motif importé
        </CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Aperçu de l'image source */}
        {pattern.sourceImage && (
          <div className="relative rounded-lg overflow-hidden border border-slate-200">
            <img 
              src={pattern.sourceImage} 
              alt="Motif source" 
              className="w-full h-32 object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent flex items-end p-2">
              <span className="text-xs text-white font-medium">
                {pattern.width} × {pattern.height}
              </span>
            </div>
          </div>
        )}

        {/* Progression */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-600">Progression</span>
            <span className="font-semibold text-slate-900">
              {doneStitches} / {totalStitches} points
            </span>
          </div>
          <Progress value={progress} className="h-2" />
          <p className="text-xs text-slate-500 text-center">
            {Math.round(progress)}% complété
          </p>
        </div>

        {/* Couleurs utilisées */}
        {pattern.colors && pattern.colors.length > 0 && (
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-xs font-medium text-slate-600">
              <Palette className="w-3 h-3" />
              Couleurs ({pattern.colors.length})
            </div>
            <div className="flex flex-wrap gap-1.5">
              {pattern.colors.map((color, idx) => (
                <div
                  key={idx}
                  className="group relative"
                  title={`${color.name} - ${color.dmc}`}
                >
                  <div
                    className="w-10 h-10 rounded border-2 border-slate-300 hover:border-slate-400 transition-colors flex items-center justify-center"
                    style={{ backgroundColor: color.hex }}
                  >
                    {color.symbol && (
                      <span className="text-lg font-bold text-black" style={{ textShadow: '0 0 2px white' }}>
                        {color.symbol}
                      </span>
                    )}
                  </div>
                  <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-50">
                    <div className="bg-slate-900 text-white text-xs px-2 py-1 rounded whitespace-nowrap">
                      {color.dmc}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Actions */}
        <div className="flex gap-2 pt-2">
          <Button
            variant={showPattern ? "default" : "outline"}
            size="sm"
            onClick={onTogglePattern}
            className={cn(
              "flex-1",
              showPattern && "bg-purple-600 hover:bg-purple-700"
            )}
          >
            {showPattern ? (
              <>
                <Eye className="w-4 h-4 mr-2" />
                Visible
              </>
            ) : (
              <>
                <EyeOff className="w-4 h-4 mr-2" />
                Masqué
              </>
            )}
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={onClearPattern}
            className="text-red-600 hover:text-red-700 hover:bg-red-50"
          >
            Effacer
          </Button>
        </div>

        {/* Info */}
        <div className="bg-slate-50 rounded-lg p-3 text-xs text-slate-600">
          <p className="mb-1">
            <strong>Astuce :</strong> Cliquez sur un point de croix du motif pour le marquer comme fait.
          </p>
          <p>
            Les points faits apparaissent avec un cercle autour.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}