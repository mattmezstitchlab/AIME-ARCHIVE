import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { X, Info } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function PreparePatternDialog({ 
  open, 
  onClose, 
  onConfirm,
  importedFile
}) {
  // ===== TOUS LES HOOKS EN HAUT =====
  const [previewImage, setPreviewImage] = useState(null);
  const [sourceWidth, setSourceWidth] = useState(0);
  const [sourceHeight, setSourceHeight] = useState(0);
  const [keepProportions, setKeepProportions] = useState(true);
  const [globalSize, setGlobalSize] = useState(150);
  const [manualWidth, setManualWidth] = useState(150);
  const [manualHeight, setManualHeight] = useState(150);
  const [maxColors, setMaxColors] = useState(40);
  const [allowEmptyCells, setAllowEmptyCells] = useState(false);
  const [noHolesMode, setNoHolesMode] = useState(true);
  const [backgroundTolerance, setBackgroundTolerance] = useState(20);
  const [autoFillHoles, setAutoFillHoles] = useState(true);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  
  // Nouveaux états pour types de points
  const [stitchTypes, setStitchTypes] = useState({
    fullCross: true,
    halfCross: false,
    quarterCross: false,
    backstitch: false,
    beads: false
  });
  
  // Nouveaux états pour qualité
  const [cleanIsolatedPixels, setCleanIsolatedPixels] = useState(true);
  const [smoothGradients, setSmoothGradients] = useState(true);
  const [mergeSimilarColors, setMergeSimilarColors] = useState(true);
  
  // Tolérance DMC
  const [dmcTolerance, setDmcTolerance] = useState('standard');

  // Générer l'aperçu à partir du fichier
  useEffect(() => {
    if (!importedFile) {
      setPreviewImage(null);
      return;
    }
    
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        setSourceWidth(img.width);
        setSourceHeight(img.height);
        setPreviewImage(e.target.result);
        
        // Initialiser les dimensions manuelles selon le ratio
        const ratio = img.width / img.height;
        if (ratio > 1) {
          setManualWidth(150);
          setManualHeight(Math.round(150 / ratio));
        } else {
          setManualHeight(150);
          setManualWidth(Math.round(150 * ratio));
        }
      };
      img.src = e.target.result;
    };
    reader.readAsDataURL(importedFile);
  }, [importedFile]);

  // Calculer les dimensions de la grille selon le ratio
  const calculateGridDimensions = () => {
    if (!sourceWidth || !sourceHeight) return { width: 150, height: 150 };
    
    if (keepProportions) {
      const ratio = sourceWidth / sourceHeight;
      
      if (ratio > 1) {
        // Paysage
        return {
          width: globalSize,
          height: Math.round(globalSize / ratio)
        };
      } else {
        // Portrait
        return {
          width: Math.round(globalSize * ratio),
          height: globalSize
        };
      }
    } else {
      return {
        width: manualWidth,
        height: manualHeight
      };
    }
  };

  // Calculer le ratio simplifié
  const getSimplifiedRatio = () => {
    if (!sourceWidth || !sourceHeight) return '';
    
    const gcd = (a, b) => b === 0 ? a : gcd(b, a % b);
    const divisor = gcd(sourceWidth, sourceHeight);
    const w = sourceWidth / divisor;
    const h = sourceHeight / divisor;
    
    // Cas spéciaux
    if (Math.abs(w / h - 16 / 9) < 0.01) return '16:9';
    if (Math.abs(w / h - 4 / 3) < 0.01) return '4:3';
    if (Math.abs(w / h - 3 / 2) < 0.01) return '3:2';
    if (Math.abs(w / h - 1) < 0.01) return '1:1';
    
    return `${Math.round(w)}:${Math.round(h)}`;
  };

  const gridDimensions = calculateGridDimensions();

  // ===== FONCTIONS =====
  const handleGenerate = async () => {
    if (!importedFile) return;
    
    setIsAnalyzing(true);
    
    try {
      // Préparer la configuration complète avec les bonnes dimensions
      const config = {
        file: importedFile,
        width: gridDimensions.width,
        height: gridDimensions.height,
        colorsCount: maxColors,
        allowEmptyCells,
        noHolesMode,
        backgroundTolerance,
        autoFillHoles,
        stitchTypes,
        cleanIsolatedPixels,
        smoothGradients,
        mergeSimilarColors,
        dmcTolerance,
        mode: 'debutant',
        useAutoRecommendation: true,
        useDmcConversion: true,
        filterSimilarColors: true
      };
      
      // Appeler le callback de confirmation
      await onConfirm(config);
      
    } catch (error) {
      console.error('Erreur génération:', error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  // ===== RENDER =====
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center">
      {/* Overlay */}
      <div className="absolute inset-0 bg-black/60" onClick={onClose} />
      
      {/* Dialog */}
      <div className="relative w-[95vw] max-w-[900px] max-h-[90vh] bg-[#F7F7F7] rounded-xl shadow-2xl flex flex-col border border-[#E0E0E0]">
        
        {/* HEADER */}
        <div className="flex-shrink-0 bg-[#111] px-6 py-4 flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold text-white mb-1">Importer une image</h2>
            <p className="text-sm text-[#999]">
              Transformez votre image en motif de point de croix
            </p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-black hover:text-white flex items-center justify-center transition-all border border-[#555]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* CONTENU - 2 COLONNES - SCROLLABLE */}
        <div className="flex-1 overflow-y-auto p-8" style={{ minHeight: 0 }}>
          <div className="grid grid-cols-12 gap-8">
            
            {/* COLONNE 1 - APERÇU */}
            <div className="col-span-5">
              <div className="bg-white rounded-lg border border-[#E0E0E0] p-5 sticky top-0">
                <h3 className="font-semibold text-base text-black mb-4">Aperçu du motif</h3>
                
                {/* Aperçu sans déformation - hauteur réduite sur petits écrans */}
                {previewImage && (
                  <div 
                    className="w-full h-48 sm:h-56 md:h-64 bg-[#F5F5F5] rounded-lg border border-[#E0E0E0] mb-4 flex items-center justify-center overflow-hidden"
                  >
                    <img 
                      src={previewImage} 
                      alt="Aperçu" 
                      className="max-w-full max-h-full object-contain"
                    />
                  </div>
                )}
                
                {/* Métadonnées */}
                <div className="space-y-2 text-sm text-[#555]">
                  <div className="flex justify-between">
                    <span>Dimensions source :</span>
                    <span className="font-semibold text-black">{sourceWidth} × {sourceHeight} px</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Proportions :</span>
                    <span className="font-semibold text-black">{getSimplifiedRatio()}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* COLONNE 2 - RÉGLAGES */}
            <div className="col-span-7">
              <div className="space-y-4 pb-4">
                {/* BLOC 1 - Dimensions de la grille */}
                <div className="bg-white rounded-lg border border-[#E0E0E0] p-5">
                  <h3 className="font-semibold text-base text-black mb-4">Dimensions de la grille</h3>
                  
                  {/* Toggle conserver proportions */}
                  <div className="flex items-center justify-between mb-4 p-3 bg-[#F5F5F5] rounded-lg">
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-black font-medium">Conserver les proportions</span>
                      <span className="text-xs text-[#777]">(recommandé)</span>
                    </div>
                    <Switch
                      checked={keepProportions}
                      onCheckedChange={setKeepProportions}
                    />
                  </div>

                  {keepProportions ? (
                    /* Slider unique si proportions conservées */
                    <div className="space-y-3">
                      <label className="text-sm font-medium text-black">
                        Taille globale
                      </label>
                      <input
                        type="range"
                        min="50"
                        max="400"
                        value={globalSize}
                        onChange={(e) => setGlobalSize(Number(e.target.value))}
                        className="w-full h-2 bg-[#E0E0E0] rounded-lg appearance-none cursor-pointer accent-[#F5C200]"
                      />
                      <div className="flex justify-between text-xs text-[#777]">
                        <span>50</span>
                        <span className="font-semibold text-black">{globalSize} points</span>
                        <span>400</span>
                      </div>
                      
                      {/* Grille résultante */}
                      <div className="mt-4 p-3 bg-[#F5F5F5] rounded-lg">
                        <div className="text-xs text-[#777] mb-1">Grille résultante :</div>
                        <div className="text-lg font-bold text-black">
                          {gridDimensions.width} × {gridDimensions.height} points
                        </div>
                      </div>
                    </div>
                  ) : (
                    /* Champs séparés si proportions désactivées */
                    <div className="space-y-4">
                      <div>
                        <label className="text-sm font-medium text-black mb-2 block">
                          Largeur
                        </label>
                        <input
                          type="number"
                          min="50"
                          max="400"
                          value={manualWidth}
                          onChange={(e) => setManualWidth(Number(e.target.value))}
                          className="w-full px-3 py-2 border border-[#E0E0E0] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#F5C200]"
                        />
                      </div>
                      
                      <div>
                        <label className="text-sm font-medium text-black mb-2 block">
                          Hauteur
                        </label>
                        <input
                          type="number"
                          min="50"
                          max="400"
                          value={manualHeight}
                          onChange={(e) => setManualHeight(Number(e.target.value))}
                          className="w-full px-3 py-2 border border-[#E0E0E0] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#F5C200]"
                        />
                      </div>
                      
                      {/* Warning déformation */}
                      <div className="flex items-start gap-2 p-3 bg-amber-50 border border-amber-200 rounded-lg">
                        <Info className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
                        <p className="text-xs text-amber-800">
                          Attention : des dimensions non proportionnelles peuvent déformer le motif.
                        </p>
                      </div>
                    </div>
                  )}
                </div>

                {/* BLOC 2 - Nombre de couleurs */}
                <div className="bg-white rounded-lg border border-[#E0E0E0] p-5">
                  <h3 className="font-semibold text-base text-black mb-4">Nombre de couleurs</h3>

                  <div className="space-y-3">
                    <label className="text-sm font-medium text-black">
                      Nombre de couleurs maximum
                    </label>
                    <input
                      type="range"
                      min="5"
                      max="90"
                      value={maxColors}
                      onChange={(e) => setMaxColors(Number(e.target.value))}
                      className="w-full h-2 bg-[#E0E0E0] rounded-lg appearance-none cursor-pointer accent-[#F5C200]"
                    />
                    <div className="flex justify-between text-xs text-[#777]">
                      <span>5</span>
                      <span className="font-semibold text-black">{maxColors} couleurs</span>
                      <span>90</span>
                    </div>
                    <p className="text-xs text-[#777] leading-relaxed">
                      Réduisez le nombre de couleurs pour simplifier votre motif.
                    </p>
                  </div>
                </div>

                {/* BLOC 3 - Styles de points */}
                <div className="bg-white rounded-lg border border-[#E0E0E0] p-5">
                  <h3 className="font-semibold text-base text-black mb-4">Styles de points</h3>
                  <p className="text-xs text-[#777] mb-4">L'IA analyse automatiquement les textures</p>
                  
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <input
                        type="checkbox"
                        checked={stitchTypes.fullCross}
                        onChange={(e) => setStitchTypes({...stitchTypes, fullCross: e.target.checked})}
                        className="w-4 h-4"
                      />
                      <span className="text-sm text-black">Point de croix complet</span>
                    </div>
                    
                    <div className="flex items-center gap-3">
                      <input
                        type="checkbox"
                        checked={stitchTypes.halfCross}
                        onChange={(e) => setStitchTypes({...stitchTypes, halfCross: e.target.checked})}
                        className="w-4 h-4"
                      />
                      <span className="text-sm text-black">Demi-point (détection auto)</span>
                    </div>
                    
                    <div className="flex items-center gap-3">
                      <input
                        type="checkbox"
                        checked={stitchTypes.quarterCross}
                        onChange={(e) => setStitchTypes({...stitchTypes, quarterCross: e.target.checked})}
                        className="w-4 h-4"
                      />
                      <span className="text-sm text-black">Quart de point (détection auto)</span>
                    </div>
                    
                    <div className="flex items-center gap-3">
                      <input
                        type="checkbox"
                        checked={stitchTypes.backstitch}
                        onChange={(e) => setStitchTypes({...stitchTypes, backstitch: e.target.checked})}
                        className="w-4 h-4"
                      />
                      <span className="text-sm text-black">Point arrière (contours)</span>
                    </div>
                    
                    <div className="flex items-center gap-3">
                      <input
                        type="checkbox"
                        checked={stitchTypes.beads}
                        onChange={(e) => setStitchTypes({...stitchTypes, beads: e.target.checked})}
                        className="w-4 h-4"
                      />
                      <span className="text-sm text-black">Perles (détection auto)</span>
                    </div>
                  </div>
                </div>

                {/* BLOC 4 - Qualité du rendu */}
                <div className="bg-white rounded-lg border border-[#E0E0E0] p-5">
                  <h3 className="font-semibold text-base text-black mb-4">Qualité du rendu</h3>
                  
                  <div className="space-y-3">
                    <div className="flex items-start gap-3">
                      <input
                        type="checkbox"
                        checked={cleanIsolatedPixels}
                        onChange={(e) => setCleanIsolatedPixels(e.target.checked)}
                        className="mt-1 w-4 h-4"
                      />
                      <div className="flex-1">
                        <div className="text-sm font-medium text-black">Nettoyer les pixels isolés</div>
                        <div className="text-xs text-[#777]">Supprime les points isolés parasites</div>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3">
                      <input
                        type="checkbox"
                        checked={smoothGradients}
                        onChange={(e) => setSmoothGradients(e.target.checked)}
                        className="mt-1 w-4 h-4"
                      />
                      <div className="flex-1">
                        <div className="text-sm font-medium text-black">Corriger les dégradés</div>
                        <div className="text-xs text-[#777]">Lisse les transitions de couleur</div>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3">
                      <input
                        type="checkbox"
                        checked={mergeSimilarColors}
                        onChange={(e) => setMergeSimilarColors(e.target.checked)}
                        className="mt-1 w-4 h-4"
                      />
                      <div className="flex-1">
                        <div className="text-sm font-medium text-black">Fusionner les couleurs trop similaires</div>
                        <div className="text-xs text-[#777]">Réduit les doublons de couleurs proches</div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* BLOC 5 - Conversion DMC */}
                <div className="bg-white rounded-lg border border-[#E0E0E0] p-5">
                  <h3 className="font-semibold text-base text-black mb-4">Conversion IA → Couleurs DMC</h3>
                  <p className="text-xs text-[#777] mb-4">Conversion par tolérance adaptative</p>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-black">Tolérance de conversion</label>
                    <select
                      value={dmcTolerance}
                      onChange={(e) => setDmcTolerance(e.target.value)}
                      className="w-full px-3 py-2 border border-[#E0E0E0] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#F5C200] bg-white"
                    >
                      <option value="precise">Très précise (fidèle aux couleurs)</option>
                      <option value="standard">Standard (équilibré)</option>
                      <option value="artistic">Artistique (liberté créative)</option>
                    </select>
                  </div>
                </div>

                {/* BLOC 6 - Gestion des cases vides */}
                <div className="bg-white rounded-lg border border-[#E0E0E0] p-5">
                  <h3 className="font-semibold text-base text-black mb-4">Gestion des cases vides</h3>

                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <input
                        type="checkbox"
                        checked={allowEmptyCells}
                        onChange={(e) => setAllowEmptyCells(e.target.checked)}
                        className="mt-1 w-4 h-4"
                      />
                      <div className="flex-1">
                        <div className="text-sm font-medium text-black">Autoriser des zones non brodées (cases vides)</div>
                        <div className="text-xs text-[#777] mt-1">
                          Par défaut, toute la zone de l'image est remplie. Activez cette option pour permettre des cases vides.
                        </div>
                      </div>
                    </div>

                    <div className="flex items-start gap-3">
                      <input
                        type="checkbox"
                        checked={noHolesMode}
                        onChange={(e) => {
                          setNoHolesMode(e.target.checked);
                          if (e.target.checked) {
                            setAutoFillHoles(true);
                          }
                        }}
                        className="mt-1 w-4 h-4"
                      />
                      <div className="flex-1">
                        <div className="text-sm font-medium text-black">Mode sans trous (0 case vide à l'intérieur du motif)</div>
                        <div className="text-xs text-[#777] mt-1">
                          Remplit automatiquement les petits trous vides à l'intérieur du motif pour éviter les oublis. Idéal pour les broderies pleines.
                        </div>
                      </div>
                    </div>

                    {allowEmptyCells && (
                      <>
                        <div className="ml-7 space-y-3 p-3 bg-[#F5F5F5] rounded-lg">
                          <div>
                            <label className="text-sm font-medium text-black">Tolérance de fond</label>
                            <p className="text-xs text-[#777] mb-2">
                              Ignore les pixels proches de la couleur de fond ou transparents
                            </p>
                            <input
                              type="range"
                              min="0"
                              max="100"
                              value={backgroundTolerance}
                              onChange={(e) => setBackgroundTolerance(Number(e.target.value))}
                              className="w-full h-2 bg-[#E0E0E0] rounded-lg appearance-none cursor-pointer accent-[#F5C200]"
                            />
                            <div className="flex justify-between text-xs text-[#777] mt-1">
                              <span>0</span>
                              <span className="font-semibold text-black">{backgroundTolerance}</span>
                              <span>100</span>
                            </div>
                          </div>
                        </div>

                        <div className="ml-7">
                          <div className="flex items-start gap-3">
                            <input
                              type="checkbox"
                              checked={autoFillHoles}
                              onChange={(e) => setAutoFillHoles(e.target.checked)}
                              disabled={noHolesMode}
                              className="mt-1 w-4 h-4 disabled:opacity-50"
                            />
                            <div className="flex-1">
                              <div className={cn("text-sm font-medium", noHolesMode ? "text-[#999]" : "text-black")}>
                                Remplir automatiquement les petits trous
                              </div>
                              <div className="text-xs text-[#777]">
                                {noHolesMode 
                                  ? "Activé automatiquement en mode sans trous" 
                                  : "Les petites zones vides isolées seront remplies avec la couleur dominante"
                                }
                              </div>
                            </div>
                          </div>
                        </div>
                      </>
                    )}
                  </div>
                </div>
                </div>
            </div>
          </div>
        </div>

        {/* FOOTER */}
        <div className="flex-shrink-0 bg-[#F7F7F7] border-t border-[#E0E0E0] px-8 py-4 flex items-center justify-end gap-3">
          <Button
            variant="outline"
            onClick={onClose}
            disabled={isAnalyzing}
            className="px-6 py-2 bg-white border border-[#DDDDDD] text-[#555] hover:bg-[#F0F0F0] rounded-lg"
          >
            Annuler
          </Button>

          <Button
            onClick={handleGenerate}
            disabled={isAnalyzing}
            className="px-8 py-2 bg-[#F5C200] hover:bg-[#E5B200] text-black font-semibold rounded-lg shadow-sm"
          >
            {isAnalyzing ? (
              <>
                <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin mr-2" />
                Génération en cours...
              </>
            ) : (
              'Générer la grille'
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}