import React from 'react';
import { 
  Eye, 
  EyeOff, 
  Merge, 
  Edit, 
  Target, 
  Eraser,
  Palette,
  Sparkles,
  Grid3x3
} from 'lucide-react';
import { cn } from '@/lib/utils';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';

const HexButton = ({ icon: Icon, tooltip, onClick, className }) => (
  <TooltipProvider>
    <Tooltip>
      <TooltipTrigger asChild>
        <button
          onClick={onClick}
          className={cn(
            "relative w-14 h-14 flex items-center justify-center transition-all",
            "hover:brightness-95",
            className
          )}
          style={{
            clipPath: 'polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)',
            backgroundColor: '#F3F4F6'
          }}
        >
          <Icon className="w-5 h-5 text-slate-800" />
        </button>
      </TooltipTrigger>
      <TooltipContent side="top">
        <p className="text-xs">{tooltip}</p>
      </TooltipContent>
    </Tooltip>
  </TooltipProvider>
);

export default function ColorOptionsPanel({
  color,
  onClose,
  onIsolate,
  onMerge,
  onHide,
  onChangeSymbol,
  onShowRemaining,
  onAiSuggestions,
  onOptimize,
  stitchTypeCounts = {}
}) {
  const isLowUsage = (color.totalCount || 0) < 10;
  const hasLowConfidence = color.confidence === 'low';
  
  // Déterminer la question contextuelle
  const getContextualQuestion = () => {
    if (isLowUsage) return "Couleur très peu utilisée : veux-tu l'optimiser ?";
    if (hasLowConfidence) return "Cette couleur est très isolée : veux-tu la simplifier ?";
    return "Beaucoup de confettis dans cette couleur : veux-tu un nettoyage automatique ?";
  };
  
  const handleOptimize = () => {
    onOptimize?.(color);
    onClose();
  };

  return (
    <div 
      className="fixed bg-white rounded-2xl shadow-2xl border-2 border-slate-200 p-5 animate-in slide-in-from-bottom-2"
      style={{ 
        width: '320px',
        zIndex: 999999,
        bottom: '130px',
        right: '20px'
      }}
      onClick={(e) => e.stopPropagation()}
    >
      {/* En-tête minimaliste : Question + Bouton OUI */}
      <div className="flex items-center justify-between gap-3 mb-5 pb-4 border-b border-slate-200">
        <span className="text-sm font-semibold text-black leading-snug">
          {getContextualQuestion()}
        </span>
        <button
          onClick={handleOptimize}
          className="px-4 py-1.5 bg-black text-white text-xs font-medium rounded-lg hover:bg-slate-800 transition-colors flex-shrink-0"
        >
          OUI
        </button>
      </div>

      {/* Grille d'actions hexagonales */}
      <div className="grid grid-cols-4 gap-2">
        <HexButton
          icon={Target}
          tooltip="Isoler cette couleur"
          onClick={() => {
            onIsolate?.(color);
            onClose();
          }}
        />
        <HexButton
          icon={Eye}
          tooltip="Voir uniquement ses points"
          onClick={() => {
            onShowRemaining?.(color);
            onClose();
          }}
        />
        <HexButton
          icon={EyeOff}
          tooltip="Masquer / afficher"
          onClick={() => {
            onHide?.(color);
            onClose();
          }}
        />
        <HexButton
          icon={Edit}
          tooltip="Modifier le symbole"
          onClick={() => {
            onChangeSymbol?.(color);
            onClose();
          }}
        />
        <HexButton
          icon={Merge}
          tooltip="Fusionner avec une autre"
          onClick={() => {
            onMerge?.(color);
            onClose();
          }}
        />
        <HexButton
          icon={Eraser}
          tooltip="Nettoyer les points isolés"
          onClick={() => {
            onClose();
          }}
        />
        <HexButton
          icon={Grid3x3}
          tooltip="Remplir les cases vides isolées"
          onClick={() => {
            if (window.fillIsolatedEmptyCells) {
              window.fillIsolatedEmptyCells();
            }
            onClose();
          }}
        />
        <HexButton
          icon={Palette}
          tooltip="Proposer alternative DMC"
          onClick={() => {
            onClose();
          }}
        />
        <HexButton
          icon={Sparkles}
          tooltip="Suggestions IA"
          onClick={() => {
            onAiSuggestions?.(color);
            onClose();
          }}
        />
      </div>
    </div>
  );
}