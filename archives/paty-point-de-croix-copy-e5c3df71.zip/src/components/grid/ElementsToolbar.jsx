import React from 'react';
import { Button } from '@/components/ui/button';
import { 
  Link2, 
  Unlink, 
  Check, 
  Trash2,
  X
} from 'lucide-react';
import { toast } from 'sonner';

export default function ElementsToolbar({
  selectedElements,
  selectedGroupId,
  elementGroups,
  placedElements,
  onGroup,
  onUngroup,
  onScale,
  onRotate,
  onApply,
  onDelete,
  onDeleteSelected,
  onClearSelection
}) {
  const selectedGroup = elementGroups.find(g => g.id === selectedGroupId);
  const currentScale = selectedGroup?.scale || 1;
  const currentRotation = selectedGroup?.rotation || 0;

  const hasSelection = selectedElements.length > 0 || selectedGroupId;

  if (!hasSelection && placedElements.length === 0) {
    return null;
  }

  return (
    <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 bg-white/95 backdrop-blur-sm rounded-xl shadow-xl border border-slate-200 p-3">
      <div className="flex items-center gap-2">
        {/* Supprimer la sélection */}
        {hasSelection && (
          <>
            <Button
              onClick={onDeleteSelected}
              size="sm"
              variant="outline"
              className="gap-2 text-red-600 hover:bg-red-50 border-red-300"
            >
              <Trash2 className="w-4 h-4" />
              Supprimer
            </Button>

            <Button
              onClick={onClearSelection}
              size="sm"
              variant="ghost"
              className="gap-2"
            >
              <X className="w-4 h-4" />
              Désélectionner
            </Button>

            <div className="w-px h-6 bg-slate-300" />
          </>
        )}
        {/* Grouper / Dégrouper */}
        {selectedElements.length > 1 && (
          <Button
            onClick={onGroup}
            size="sm"
            className="gap-2 bg-blue-600 hover:bg-blue-700"
          >
            <Link2 className="w-4 h-4" />
            Grouper
          </Button>
        )}

        {selectedGroupId && (
          <>
            <Button
              onClick={onUngroup}
              size="sm"
              variant="outline"
              className="gap-2"
            >
              <Unlink className="w-4 h-4" />
              Dégrouper
            </Button>

            <div className="w-px h-6 bg-slate-300" />

            {/* Échelle */}
            <div className="flex items-center gap-1">
              <span className="text-xs text-slate-600">Échelle:</span>
              {[1, 2, 3, 4].map(scale => (
                <Button
                  key={scale}
                  onClick={() => onScale(selectedGroupId, scale)}
                  size="sm"
                  variant={currentScale === scale ? "default" : "outline"}
                  className="w-8 h-8 p-0"
                >
                  {scale}x
                </Button>
              ))}
            </div>

            <div className="w-px h-6 bg-slate-300" />

            {/* Rotation */}
            <div className="flex items-center gap-1">
              <span className="text-xs text-slate-600">Rotation:</span>
              {[0, 90, 180, 270].map(angle => (
                <Button
                  key={angle}
                  onClick={() => onRotate(selectedGroupId, angle)}
                  size="sm"
                  variant={currentRotation === angle ? "default" : "outline"}
                  className="w-10 h-8 p-0 text-xs"
                >
                  {angle}°
                </Button>
              ))}
            </div>
          </>
        )}

        {placedElements.length > 0 && (
          <>
            <div className="w-px h-6 bg-slate-300" />
            
            <Button
              onClick={onApply}
              size="sm"
              className="gap-2 bg-green-600 hover:bg-green-700"
            >
              <Check className="w-4 h-4" />
              Appliquer à la grille
            </Button>

            <Button
              onClick={onDelete}
              size="sm"
              variant="outline"
              className="gap-2"
            >
              <X className="w-4 h-4" />
              Tout effacer
            </Button>
          </>
        )}
      </div>
    </div>
  );
}