import React, { useState, useEffect, useRef } from 'react';
import { X, ChevronLeft, ChevronRight, Volume2, VolumeX, Play, Pause, RotateCcw } from 'lucide-react';
import { Slider } from '@/components/ui/slider';

// Logo BROOD-WAY avec symbole animé
function BroodwayLogo() {
  const [symbolIndex, setSymbolIndex] = React.useState(0);
  const symbols = [
    { char: '✕', color: '#FFC94A' },
    { char: '●', color: '#EF4444' },
    { char: '▲', color: '#22C55E' },
    { char: '■', color: '#3B82F6' },
    { char: '◆', color: '#A855F7' },
    { char: '★', color: '#F97316' },
    { char: '♥', color: '#EC4899' },
    { char: '✿', color: '#14B8A6' },
  ];

  React.useEffect(() => {
    const interval = setInterval(() => {
      setSymbolIndex(prev => (prev + 1) % symbols.length);
    }, 800);
    return () => clearInterval(interval);
  }, []);

  const currentSymbol = symbols[symbolIndex];

  return (
    <div className="flex items-center justify-center">
      <span className="text-xl font-bold tracking-wide text-white">BROOD</span>
      <span 
        className="text-base font-bold mx-1 transition-all duration-200"
        style={{ color: currentSymbol.color, textShadow: `0 0 8px ${currentSymbol.color}60` }}
      >
        {currentSymbol.char}
      </span>
      <span className="text-xl font-bold tracking-wide text-white">WAY</span>
      <span className="text-xl ml-1" style={{ color: '#FFC94A' }}>♾️</span>
    </div>
  );
}

// Contenu des 42 écrans
const HELP_SCREENS = [
  // 🟡 INTRODUCTION (1-3)
  { category: 'intro', title: 'Bienvenue', description: 'Bienvenue sur Brood-Way, votre assistant de broderie intelligent. Créez, importez et brodez vos motifs en toute simplicité.' },
  { category: 'intro', title: 'Chaque point compte', description: 'Là où chaque point devient éternel. Brood-Way transforme vos images en grilles de broderie professionnelles.' },
  { category: 'intro', title: 'La grille 10×10', description: 'La grille est divisée en blocs de 10×10 cases pour faciliter le comptage. Les lignes épaisses vous aident à vous repérer.' },

  // 🟠 PROJETS (4-6)
  { category: 'projets', title: 'Créer un projet', description: 'Cliquez sur "Importer" dans le menu pour démarrer un nouveau projet à partir d\'une image ou d\'un PDF.' },
  { category: 'projets', title: 'Sauvegarder', description: 'Cliquez sur "Sauvegarder" pour enregistrer votre projet. Donnez-lui un nom clair pour le retrouver facilement.' },
  { category: 'projets', title: 'Mes projets', description: 'Accédez à "Projets" dans le menu pour retrouver tous vos travaux. Filtrez par date ou statut.' },

  // 🟣 IMPORT / CONVERSION (7-10)
  { category: 'import', title: 'Importer un motif', description: 'Chargez une image ou un PDF. Brood-Way le convertit automatiquement en grille de broderie.' },
  { category: 'import', title: 'Smart Import', description: 'L\'import intelligent analyse votre image et propose les meilleures couleurs DMC correspondantes.' },
  { category: 'import', title: 'Conversion', description: 'Ajustez la taille de la grille et le nombre de couleurs. Plus la grille est grande, plus le détail est fin.' },
  { category: 'import', title: 'Paramètres', description: 'Nommez votre projet, choisissez la taille et la palette de couleurs avant de valider l\'import.' },

  // 🟢 OUTILS PRINCIPAUX (11-13)
  { category: 'outils', title: 'Crayon', description: 'Dessinez des points sur la grille avec la couleur sélectionnée. Maintenez pour tracer en continu.' },
  { category: 'outils', title: 'Gomme', description: 'Effacez les points indésirables. Astuce : maintenez Shift pour effacer une zone entière.' },
  { category: 'outils', title: 'Sélection', description: 'Sélectionnez une zone pour la copier, déplacer ou supprimer. Cliquez-glissez pour définir la zone.' },

  // 🔵 ZOOM / NAVIGATION (14-19)
  { category: 'navigation', title: 'Zoom', description: 'Utilisez la molette de la souris ou les boutons +/- pour zoomer. Double-clic pour recentrer.' },
  { category: 'navigation', title: 'Zoom auto', description: 'Le zoom automatique ajuste la vue pour afficher tout le motif dans l\'écran.' },
  { category: 'navigation', title: 'Zoom symbole', description: 'Zoomez sur un symbole spécifique pour voir tous ses emplacements sur la grille.' },
  { category: 'navigation', title: 'Mini-Carte', description: 'La mini-carte en bas à gauche montre une vue d\'ensemble. Cliquez dessus pour naviguer rapidement.' },
  { category: 'navigation', title: 'Téléportation', description: 'Cliquez sur un bloc 10×10 dans la mini-carte pour vous y téléporter instantanément.' },
  { category: 'navigation', title: 'GPS', description: 'Entrez des coordonnées comme A-12 ou F-8 pour aller directement à cette position sur la grille.' },

  // ⚫ AFFICHAGE (20-27)
  { category: 'affichage', title: 'Grille', description: 'Affichez ou masquez les lignes de la grille selon vos préférences de travail.' },
  { category: 'affichage', title: 'Symboles', description: 'Affichez les symboles dans chaque case pour identifier les couleurs sans vous tromper.' },
  { category: 'affichage', title: 'Visuel importé', description: 'Superposez l\'image d\'origine sur la grille pour comparer avec votre travail.' },
  { category: 'affichage', title: 'Contraste fort', description: 'Augmente le contraste des couleurs pour mieux distinguer les nuances proches.' },
  { category: 'affichage', title: 'Mode XXL', description: 'Agrandit les symboles et les cases pour une meilleure lisibilité sur petit écran.' },
  { category: 'affichage', title: 'Mode Nuit', description: 'Inverse les couleurs pour réduire la fatigue oculaire en environnement sombre.' },
  { category: 'affichage', title: 'Anti-Fatigue', description: 'Applique des couleurs douces et réduit les contrastes pour broder plus longtemps.' },
  { category: 'affichage', title: 'Compteur Auto', description: 'Affiche automatiquement le nombre de points restants pour chaque couleur.' },

  // 🟤 EXPORT / PARTAGE (28-30)
  { category: 'export', title: 'Exporter', description: 'Exportez votre grille dans différents formats pour l\'imprimer ou la partager.' },
  { category: 'export', title: 'Formats', description: 'Choisissez entre SUB (universel), PDF (impression) ou Image (partage rapide).' },
  { category: 'export', title: 'Boutique', description: 'Partagez vos créations dans la boutique communautaire et découvrez celles des autres.' },

  // 🟡 PROFIL / COMPTE (31-34)
  { category: 'profil', title: 'Mon profil', description: 'Consultez et modifiez vos informations personnelles et préférences.' },
  { category: 'profil', title: 'Mes projets', description: 'Retrouvez tous vos projets sauvegardés, en cours ou terminés.' },
  { category: 'profil', title: 'La boutique', description: 'Explorez les créations de la communauté et téléchargez de nouveaux motifs.' },
  { category: 'profil', title: 'Réglages', description: 'Personnalisez l\'interface, les couleurs et le comportement de l\'application.' },

  // 🟢 IA ASSISTANTE (35-39)
  { category: 'ia', title: 'Poser une question', description: 'Demandez de l\'aide à l\'assistant IA. Il répond à toutes vos questions sur la broderie.' },
  { category: 'ia', title: 'Actions IA', description: 'L\'assistant peut exécuter des actions pour vous : changer d\'outil, zoomer, etc.' },
  { category: 'ia', title: 'Trouver un symbole', description: 'Demandez à l\'IA de localiser un symbole spécifique sur votre grille.' },
  { category: 'ia', title: 'Aller à une zone', description: 'Dites "Va en A-15" et l\'assistant vous y emmène directement.' },
  { category: 'ia', title: 'Conseils broderie', description: 'L\'assistant propose des astuces personnalisées selon votre projet et votre niveau.' },

  // 🔴 SÉCURITÉ / ERREURS (40-42)
  { category: 'securite', title: 'Annuler / Rétablir', description: 'Ctrl+Z pour annuler, Ctrl+Y pour rétablir. Corrigez vos erreurs en un clic.' },
  { category: 'securite', title: 'Historique', description: 'Consultez l\'historique de vos modifications et revenez à un état précédent.' },
  { category: 'securite', title: 'Mode hors-ligne', description: 'Travaillez sans connexion. Vos modifications seront synchronisées au retour en ligne.' },
];

const CATEGORY_COLORS = {
  intro: '#FFC94A',
  projets: '#F97316',
  import: '#A855F7',
  outils: '#22C55E',
  navigation: '#3B82F6',
  affichage: '#6B7280',
  export: '#92400E',
  profil: '#FFC94A',
  ia: '#22C55E',
  securite: '#EF4444',
};

// Broodia™ - Voix IA complice et souriante
const BROODIA_CONFIG = {
  name: 'Broodia™',
  greeting: 'Bonjour ! Je t\'accompagne point par point. 🐝',
  rate: 1.15, // Légèrement rapide pour max 6s
  pitch: 1.15, // Ton léger et souriant
  maxDuration: 6 // secondes max par écran
};

export default function HelpCenter({ open, onClose }) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [voiceEnabled, setVoiceEnabled] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(80);
  const [showVoicePanel, setShowVoicePanel] = useState(false);
  const [hasGreeted, setHasGreeted] = useState(false);
  const utteranceRef = useRef(null);
  const synthRef = useRef(null);

  // Initialiser la synthèse vocale
  useEffect(() => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      synthRef.current = window.speechSynthesis;
    }
  }, []);

  // Reset à l'ouverture
  useEffect(() => {
    if (open) {
      setCurrentIndex(0);
      stopSpeech();
    }
    return () => stopSpeech();
  }, [open]);

  // Lire le texte quand l'écran change et que la voix est activée
  useEffect(() => {
    if (voiceEnabled && !isMuted && open) {
      speakCurrentScreen();
    }
  }, [currentIndex, voiceEnabled, isMuted, open]);

  // Message d'accueil Broodia au premier lancement
  useEffect(() => {
    if (voiceEnabled && !hasGreeted && !isMuted) {
      speakText(BROODIA_CONFIG.greeting);
      setHasGreeted(true);
    }
  }, [voiceEnabled]);

  const stopSpeech = () => {
    if (synthRef.current) {
      synthRef.current.cancel();
    }
    setIsPlaying(false);
  };

  const speakText = (text) => {
    if (!synthRef.current || isMuted) return;
    
    stopSpeech();
    
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'fr-FR';
    utterance.rate = BROODIA_CONFIG.rate;
    utterance.pitch = BROODIA_CONFIG.pitch;
    utterance.volume = volume / 100;
    
    utterance.onstart = () => setIsPlaying(true);
    utterance.onend = () => setIsPlaying(false);
    utterance.onerror = () => setIsPlaying(false);
    
    utteranceRef.current = utterance;
    synthRef.current.speak(utterance);
  };

  const speakCurrentScreen = () => {
    if (!synthRef.current || isMuted) return;
    
    const screen = HELP_SCREENS[currentIndex];
    // Texte concis pour max 6 secondes
    const text = `${screen.title}. ${screen.description}`;
    speakText(text);
  };

  const toggleVoice = () => {
    if (voiceEnabled) {
      stopSpeech();
      setVoiceEnabled(false);
    } else {
      setVoiceEnabled(true);
    }
  };

  const togglePlayPause = () => {
    if (!synthRef.current) return;
    
    if (isPlaying) {
      synthRef.current.pause();
      setIsPlaying(false);
    } else if (synthRef.current.paused) {
      synthRef.current.resume();
      setIsPlaying(true);
    } else {
      speakCurrentScreen();
    }
  };

  const replaySpeech = () => {
    speakCurrentScreen();
  };

  const handleVolumeChange = (value) => {
    setVolume(value[0]);
    if (utteranceRef.current) {
      utteranceRef.current.volume = value[0] / 100;
    }
  };

  // Navigation clavier
  useEffect(() => {
    if (!open) return;
    const handleKeyDown = (e) => {
      if (e.key === 'ArrowLeft') goToPrev();
      if (e.key === 'ArrowRight') goToNext();
      if (e.key === 'Escape') {
        stopSpeech();
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [open, currentIndex]);

  // Écouter les demandes de lecture contextuelle d'outils
  useEffect(() => {
    const handleToolHelp = (e) => {
      const toolId = e.detail?.toolId;
      if (toolId && voiceEnabled && !isMuted) {
        // Trouver l'écran correspondant à l'outil
        const toolScreenIndex = HELP_SCREENS.findIndex(s => 
          s.title.toLowerCase().includes(toolId.toLowerCase())
        );
        if (toolScreenIndex >= 0) {
          setCurrentIndex(toolScreenIndex);
        }
      }
    };
    window.addEventListener('readToolHelp', handleToolHelp);
    return () => window.removeEventListener('readToolHelp', handleToolHelp);
  }, [voiceEnabled, isMuted]);

  const goToPrev = () => {
    stopSpeech();
    setCurrentIndex(prev => Math.max(0, prev - 1));
  };

  const goToNext = () => {
    stopSpeech();
    setCurrentIndex(prev => Math.min(HELP_SCREENS.length - 1, prev + 1));
  };

  const handleClose = () => {
    stopSpeech();
    onClose();
  };

  if (!open) return null;

  const screen = HELP_SCREENS[currentIndex];
  const categoryColor = CATEGORY_COLORS[screen.category] || '#FFC94A';

  return (
    <div className="fixed inset-0 z-[500] flex items-center justify-center">
      {/* Fond assombri */}
      <div 
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Popup */}
      <div 
        className="relative bg-[#111] rounded-2xl shadow-2xl border border-[#333] overflow-hidden"
        style={{ width: '420px', maxWidth: '90vw' }}
      >
        {/* Bouton X en haut à droite */}
        <div className="absolute top-3 right-3 z-10">
          <button
            onClick={handleClose}
            className="p-2 hover:bg-white/10 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-gray-400" />
          </button>
        </div>

        {/* Contenu */}
        <div className="p-8 pt-6">
          {/* Logo centré */}
          <div className="mb-6">
            <BroodwayLogo />
          </div>

          {/* Indicateur de catégorie */}
          <div className="flex justify-center mb-4">
            <span 
              className="px-3 py-1 rounded-full text-xs font-medium uppercase tracking-wider"
              style={{ backgroundColor: `${categoryColor}20`, color: categoryColor }}
            >
              {screen.category}
            </span>
          </div>

          {/* Titre */}
          <h2 className="text-2xl font-bold text-white text-center mb-3">
            {screen.title}
          </h2>

          {/* Description */}
          <p className="text-gray-400 text-center text-sm leading-relaxed min-h-[60px]">
            {screen.description}
          </p>
        </div>

        {/* Navigation en bas */}
        <div className="px-6 pb-6">
          <div className="flex items-center justify-between">
            {/* Flèche gauche */}
            <button
              onClick={goToPrev}
              disabled={currentIndex === 0}
              className={`p-3 rounded-xl transition-all ${
                currentIndex === 0
                  ? 'opacity-30 cursor-not-allowed'
                  : 'hover:bg-white/10 text-white'
              }`}
            >
              <ChevronLeft className="w-6 h-6" />
            </button>

            {/* Timeline dots */}
            <div className="flex items-center gap-1.5 max-w-[200px] overflow-hidden">
              {HELP_SCREENS.map((_, idx) => {
                const isActive = idx === currentIndex;
                const isNear = Math.abs(idx - currentIndex) <= 3;
                
                if (!isNear && idx !== 0 && idx !== HELP_SCREENS.length - 1) {
                  // Afficher des points de suspension pour les écrans éloignés
                  if (idx === currentIndex - 4 || idx === currentIndex + 4) {
                    return <span key={idx} className="text-gray-600 text-xs">…</span>;
                  }
                  return null;
                }

                return (
                  <button
                    key={idx}
                    onClick={() => setCurrentIndex(idx)}
                    className={`rounded-full transition-all ${
                      isActive
                        ? 'w-3 h-3 bg-[#FFC94A]'
                        : 'w-2 h-2 bg-gray-600 hover:bg-gray-500'
                    }`}
                  />
                );
              })}
            </div>

            {/* Flèche droite */}
            <button
              onClick={goToNext}
              disabled={currentIndex === HELP_SCREENS.length - 1}
              className={`p-3 rounded-xl transition-all ${
                currentIndex === HELP_SCREENS.length - 1
                  ? 'opacity-30 cursor-not-allowed'
                  : 'hover:bg-white/10 text-white'
              }`}
            >
              <ChevronRight className="w-6 h-6" />
            </button>
          </div>

          {/* Compteur */}
          <div className="text-center mt-3 text-xs text-gray-500">
            {currentIndex + 1} / {HELP_SCREENS.length}
          </div>
        </div>
      </div>
    </div>
  );
}