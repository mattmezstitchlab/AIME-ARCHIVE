// Types de points de broderie - Technologie LECOINTRE / SUB™
// Système Universel de Broderie

export const STITCH_TYPES = {
  // ═══════════════════════════════════════════════════════════════
  // POINTS STANDARDS (à conserver)
  // ═══════════════════════════════════════════════════════════════
  full: {
    id: 'full',
    name: 'Point de croix complet',
    category: 'standard',
    icon: '✕',
    description: 'Point de croix traditionnel',
    difficulty: 'beginner',
    color: '#000000'
  },
  half: {
    id: 'half',
    name: 'Demi-point',
    category: 'standard',
    icon: '/',
    description: 'Une seule diagonale — Détection auto',
    difficulty: 'beginner',
    color: '#4A4A4A',
    autoDetect: true
  },
  quarter: {
    id: 'quarter',
    name: 'Quart de point',
    category: 'standard',
    icon: '·',
    description: 'Point très fin — Détection auto',
    difficulty: 'intermediate',
    color: '#6A6A6A',
    autoDetect: true
  },
  threequarter: {
    id: 'threequarter',
    name: 'Trois-quarts',
    category: 'standard',
    icon: '⋏',
    description: 'Combinaison demi + quart',
    difficulty: 'intermediate',
    color: '#5A5A5A'
  },
  backstitch: {
    id: 'backstitch',
    name: 'Point arrière',
    category: 'standard',
    icon: '─',
    description: 'Contours et détails',
    difficulty: 'beginner',
    color: '#2C2C2C'
  },
  frenchknot: {
    id: 'frenchknot',
    name: 'Nœud français',
    category: 'standard',
    icon: '●',
    description: 'Points en relief',
    difficulty: 'intermediate',
    color: '#1A1A1A'
  },

  // ═══════════════════════════════════════════════════════════════
  // POINTS INNOVANTS SUB™ - TECHNOLOGIE LECOINTRE (Nouveaux)
  // ═══════════════════════════════════════════════════════════════
  lorrain: {
    id: 'lorrain',
    name: 'Point Lorrain / Point LECOINTRE',
    category: 'lecointre',
    icon: '⧋',
    description: 'Renfort structurel, précision dans les angles, stabilité des diagonales',
    difficulty: 'intermediate',
    color: '#8B4513',
    usage: 'Zones fines, dégradés directionnels, contours solides',
    autoDetect: true,
    detection: {
      areas: ['angles', 'corners', 'edges'],
      minAngle: 30,
      maxAngle: 60
    }
  },
  pivot: {
    id: 'pivot',
    name: 'Point Pivot',
    category: 'lecointre',
    icon: '↻',
    description: 'Rotation 360° autour d\'un pixel — Nouveauté mondiale',
    difficulty: 'advanced',
    color: '#9932CC',
    usage: 'Cheveux, arrondis, courbes continues',
    fluidityMode: true,
    detection: {
      areas: ['hair', 'curves', 'spirals'],
      curvature: 0.7
    }
  },
  nexus: {
    id: 'nexus',
    name: 'Point Nexus',
    category: 'lecointre',
    icon: '✦',
    description: 'Relie 4 zones ou couleurs en un seul point nodal — Brevet mondial',
    difficulty: 'advanced',
    color: '#FFD700',
    usage: 'Jonctions, centres, étoiles, fleurs',
    detection: {
      minConnections: 4,
      areas: ['junctions', 'centers', 'stars', 'flowers']
    }
  },
  zero: {
    id: 'zero',
    name: 'Point Zero',
    category: 'lecointre',
    icon: '◉',
    description: 'Remplacement automatique des cases vides — Remplissage intelligent SUB',
    difficulty: 'beginner',
    color: '#00CED1',
    usage: 'Remplissage intelligent, jamais de vide',
    modes: ['auto', 'manual', 'no_empty'],
    autoDetect: true
  },
  serpent: {
    id: 'serpent',
    name: 'Point Serpent',
    category: 'lecointre',
    icon: '∿',
    description: 'Chemin continu sans rupture, idéal pour lignes organiques',
    difficulty: 'intermediate',
    color: '#228B22',
    usage: 'Ombres, spirales, mouvements',
    detection: {
      continuous: true,
      minLength: 5
    }
  },
  croixLorraine: {
    id: 'croixLorraine',
    name: 'Point Croix de Lorraine',
    category: 'lecointre',
    icon: '☨',
    description: 'Double barre horizontale = double renfort + lisibilité extrême',
    difficulty: 'intermediate',
    color: '#DC143C',
    usage: 'Symboles, marques d\'importance, repères'
  },
  lumiere: {
    id: 'lumiere',
    name: 'Point Lumière',
    category: 'lecointre',
    icon: '✧',
    description: 'Accent lumineux sur pixel central par micro-dégradé',
    difficulty: 'advanced',
    color: '#FFFACD',
    usage: 'Reflets, or, halo, éclat (Marianne + arc-en-ciel)',
    detection: {
      brightness: { min: 230, max: 255 },
      areas: ['highlights', 'reflections', 'eyes']
    }
  },

  // ═══════════════════════════════════════════════════════════════
  // POINTS AVANCÉS CLASSIQUES
  // ═══════════════════════════════════════════════════════════════
  metallic: {
    id: 'metallic',
    name: 'Points métalliques',
    category: 'advanced',
    icon: '★',
    description: 'Fils métalliques',
    difficulty: 'advanced',
    color: '#C0C0C0',
    detection: {
      colors: ['#FFD86B', '#D7D7D7'],
      areas: ['jewelry', 'crowns', 'highlights']
    }
  },
  longstitch: {
    id: 'longstitch',
    name: 'Point long',
    category: 'advanced',
    icon: '━',
    description: 'Surfaces uniformes',
    difficulty: 'advanced',
    color: '#8B4513',
    detection: {
      minArea: 6,
      uniformity: 0.8
    }
  },
  straightstitch: {
    id: 'straightstitch',
    name: 'Point droit',
    category: 'advanced',
    icon: '│',
    description: 'Traits fins',
    difficulty: 'advanced',
    color: '#654321',
    detection: {
      thickness: 1,
      length: { min: 2, max: 10 }
    }
  },
  satin: {
    id: 'satin',
    name: 'Point de satin',
    category: 'advanced',
    icon: '▓',
    description: 'Surfaces brillantes',
    difficulty: 'expert',
    color: '#DAA520',
    detection: {
      areas: ['petals', 'wings', 'eyes'],
      maxSize: 20
    }
  },
  bullion: {
    id: 'bullion',
    name: 'Bullion Knot',
    category: 'advanced',
    icon: '∿',
    description: 'Nœuds allongés',
    difficulty: 'expert',
    color: '#B8860B',
    detection: {
      areas: ['hair', 'antennae', 'filaments']
    }
  },
  couching: {
    id: 'couching',
    name: 'Couching',
    category: 'advanced',
    icon: '≋',
    description: 'Fils posés',
    difficulty: 'expert',
    color: '#8B7355',
    detection: {
      continuous: true,
      minLength: 10
    }
  }
};

export const STITCH_CATEGORIES = {
  standard: {
    name: 'Points standards',
    description: 'Points de base pour débutantes'
  },
  lecointre: {
    name: 'Technologie LECOINTRE – SUB™',
    description: 'Points innovants brevetables — Système Universel de Broderie'
  },
  advanced: {
    name: 'Points avancés',
    description: 'Techniques expertes'
  }
};

export const PRESETS = {
  beginner: {
    name: 'Mode Débutante',
    enabled: ['full', 'half', 'backstitch', 'zero']
  },
  intermediate: {
    name: 'Mode Intermédiaire',
    enabled: ['full', 'half', 'quarter', 'backstitch', 'lorrain', 'serpent', 'zero']
  },
  advanced: {
    name: 'Mode Avancé SUB™',
    enabled: ['full', 'half', 'quarter', 'threequarter', 'backstitch', 'frenchknot', 
              'lorrain', 'pivot', 'nexus', 'zero', 'serpent', 'croixLorraine', 'lumiere']
  },
  expert: {
    name: 'Mode Expert + IA',
    enabled: Object.keys(STITCH_TYPES),
    autoAI: true
  }
};

// ═══════════════════════════════════════════════════════════════
// DÉTECTION IA DES TEXTURES
// ═══════════════════════════════════════════════════════════════
export function analyzeImageForStitchTypes(imageData, width, height) {
  const totalPixels = width * height;
  let brightPixels = 0;
  let darkPixels = 0;
  let metallicPixels = 0;
  let edgePixels = 0;
  let curvedPixels = 0;
  let junctionPixels = 0;

  // Analyse pixel par pixel
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const idx = (y * width + x) * 4;
      const r = imageData[idx];
      const g = imageData[idx + 1];
      const b = imageData[idx + 2];
      const brightness = (r + g + b) / 3;

      // Pixels lumineux (Point Lumière potentiel)
      if (brightness > 240) brightPixels++;
      
      // Pixels sombres (contours potentiels)
      if (brightness < 50) darkPixels++;

      // Métalliques (or/argent)
      const isGold = r > 200 && g > 180 && b < 150;
      const isSilver = Math.abs(r - g) < 20 && Math.abs(g - b) < 20 && r > 180;
      if (isGold || isSilver) metallicPixels++;

      // Détection de contours (Point Lorrain / backstitch)
      if (x < width - 1 && y < height - 1) {
        const nextIdx = ((y * width) + x + 1) * 4;
        const brightnessDiff = Math.abs(brightness - ((imageData[nextIdx] + imageData[nextIdx + 1] + imageData[nextIdx + 2]) / 3));
        if (brightnessDiff > 50) edgePixels++;
      }

      // Détection de courbes (Point Pivot)
      if (x > 0 && x < width - 1 && y > 0 && y < height - 1) {
        // Vérification basique de courbure
        const prevIdx = ((y * width) + x - 1) * 4;
        const nextIdx = ((y * width) + x + 1) * 4;
        const prevBr = (imageData[prevIdx] + imageData[prevIdx + 1] + imageData[prevIdx + 2]) / 3;
        const nextBr = (imageData[nextIdx] + imageData[nextIdx + 1] + imageData[nextIdx + 2]) / 3;
        if (Math.abs(prevBr - brightness) > 20 && Math.abs(nextBr - brightness) > 20) {
          curvedPixels++;
        }
      }

      // Détection de jonctions (Point Nexus) - 4 voisins différents
      if (x > 0 && x < width - 1 && y > 0 && y < height - 1) {
        const neighbors = [
          imageData[((y - 1) * width + x) * 4],
          imageData[((y + 1) * width + x) * 4],
          imageData[(y * width + x - 1) * 4],
          imageData[(y * width + x + 1) * 4]
        ];
        const uniqueColors = new Set(neighbors.map(n => Math.floor(n / 50)));
        if (uniqueColors.size >= 3) junctionPixels++;
      }
    }
  }

  // Calcul des pourcentages
  const brightPercent = (brightPixels / totalPixels) * 100;
  const edgePercent = (edgePixels / totalPixels) * 100;
  const metallicPercent = (metallicPixels / totalPixels) * 100;
  const curvedPercent = (curvedPixels / totalPixels) * 100;
  const junctionPercent = (junctionPixels / totalPixels) * 100;

  // Recommandations IA - SUB™
  return {
    // Standards
    full: true,
    half: edgePercent < 30,
    quarter: brightPercent > 5,
    backstitch: edgePercent > 15,
    frenchknot: brightPercent > 3,
    
    // LECOINTRE SUB™
    lorrain: edgePercent > 20,
    pivot: curvedPercent > 10,
    nexus: junctionPercent > 5,
    zero: true, // Toujours recommandé
    serpent: curvedPercent > 15,
    croixLorraine: false, // Choix manuel
    lumiere: brightPercent > 8,
    
    // Avancés
    metallic: metallicPercent > 5,
    longstitch: edgePercent < 20,
    straightstitch: false,
    satin: brightPercent > 4 && brightPercent < 10,
    bullion: false,
    couching: false
  };
}

// ═══════════════════════════════════════════════════════════════
// POINT ZERO - REMPLISSAGE INTELLIGENT
// ═══════════════════════════════════════════════════════════════
export function detectHolesForPointZero(symbolGrid, options = {}) {
  const { maxHoleSize = 3, preserveBackground = true } = options;
  
  if (!symbolGrid || symbolGrid.length === 0) return { holes: [], count: 0 };
  
  const height = symbolGrid.length;
  const width = symbolGrid[0]?.length || 0;
  const holes = [];
  
  for (let row = 0; row < height; row++) {
    for (let col = 0; col < width; col++) {
      if (!symbolGrid[row][col]) {
        // Compter les voisins remplis
        let filledNeighbors = 0;
        const neighborColors = [];
        const neighborSymbols = [];
        
        // Vérifier les 8 voisins
        for (let dy = -1; dy <= 1; dy++) {
          for (let dx = -1; dx <= 1; dx++) {
            if (dy === 0 && dx === 0) continue;
            const ny = row + dy;
            const nx = col + dx;
            if (ny >= 0 && ny < height && nx >= 0 && nx < width) {
              const neighbor = symbolGrid[ny][nx];
              if (neighbor) {
                filledNeighbors++;
                neighborColors.push(neighbor.color);
                neighborSymbols.push(neighbor.symbol);
              }
            }
          }
        }
        
        // Trou = au moins 3 voisins remplis (ou plus selon la taille max)
        if (filledNeighbors >= (8 - maxHoleSize)) {
          const isBorder = row === 0 || row === height - 1 || col === 0 || col === width - 1;
          if (!preserveBackground || !isBorder) {
            // Trouver la couleur dominante
            const colorCounts = {};
            neighborColors.forEach(c => {
              colorCounts[c] = (colorCounts[c] || 0) + 1;
            });
            const dominantColor = Object.entries(colorCounts).sort((a, b) => b[1] - a[1])[0]?.[0];
            
            // Trouver le symbole dominant
            const symbolCounts = {};
            neighborSymbols.forEach(s => {
              symbolCounts[s] = (symbolCounts[s] || 0) + 1;
            });
            const dominantSymbol = Object.entries(symbolCounts).sort((a, b) => b[1] - a[1])[0]?.[0];
            
            holes.push({
              row,
              col,
              suggestedColor: dominantColor,
              suggestedSymbol: dominantSymbol,
              neighborCount: filledNeighbors
            });
          }
        }
      }
    }
  }
  
  return { holes, count: holes.length };
}

export function applyPointZeroFill(symbolGrid, holes) {
  const newGrid = symbolGrid.map(row => [...row]);
  
  holes.forEach(hole => {
    newGrid[hole.row][hole.col] = {
      color: hole.suggestedColor,
      symbol: hole.suggestedSymbol,
      type: 'zero', // Marqué comme Point Zero
      autoFilled: true
    };
  });
  
  return newGrid;
}

// ═══════════════════════════════════════════════════════════════
// FONCTIONS UTILITAIRES
// ═══════════════════════════════════════════════════════════════
export function countStitchesByType(stitches) {
  const counts = {};
  
  Object.keys(STITCH_TYPES).forEach(type => {
    counts[type] = stitches.filter(s => s.type === type).length;
  });
  
  return counts;
}

export function optimizeWithAI(pattern, imageAnalysis) {
  const optimized = { ...pattern };
  const recommendations = {};
  
  if (imageAnalysis.edgePercent > 40) recommendations.backstitch = true;
  if (imageAnalysis.edgePercent > 25) recommendations.lorrain = true;
  if (imageAnalysis.brightPercent > 30) recommendations.half = true;
  if (imageAnalysis.brightPercent > 10) recommendations.lumiere = true;
  if (imageAnalysis.metallicPercent > 10) recommendations.metallic = true;
  if (imageAnalysis.brightPercent > 8) recommendations.quarter = true;
  if (imageAnalysis.brightPercent > 5) recommendations.frenchknot = true;
  if (imageAnalysis.curvedPercent > 15) recommendations.pivot = true;
  if (imageAnalysis.junctionPercent > 8) recommendations.nexus = true;
  
  recommendations.zero = true; // Toujours recommandé
  
  return recommendations;
}

export function applyStitchTypeRules(pattern, enabledTypes) {
  if (!pattern || !pattern.symbolGrid) return pattern;
  
  const newPattern = { ...pattern };
  let modified = false;

  // Si backstitch désactivé, supprimer les contours
  if (!enabledTypes.includes('backstitch')) {
    modified = true;
  }

  // Si demi-points désactivés, convertir en croix complètes
  if (!enabledTypes.includes('half')) {
    newPattern.symbolGrid = newPattern.symbolGrid.map(row =>
      row.map(cell => {
        if (cell && cell.type === 'half') {
          return { ...cell, type: 'full' };
        }
        return cell;
      })
    );
    modified = true;
  }

  // Si fractionnés désactivés, convertir
  if (!enabledTypes.includes('quarter')) {
    newPattern.symbolGrid = newPattern.symbolGrid.map(row =>
      row.map(cell => {
        if (cell && (cell.type === 'quarter' || cell.type === 'threequarter')) {
          return { ...cell, type: 'full' };
        }
        return cell;
      })
    );
    modified = true;
  }

  // Convertir les types spéciaux non sélectionnés
  const allTypes = Object.keys(STITCH_TYPES);
  allTypes.forEach(type => {
    if (!enabledTypes.includes(type) && type !== 'full') {
      newPattern.symbolGrid = newPattern.symbolGrid.map(row =>
        row.map(cell => {
          if (cell && cell.type === type) {
            return { ...cell, type: 'full' };
          }
          return cell;
        })
      );
      modified = true;
    }
  });

  return newPattern;
}

// ═══════════════════════════════════════════════════════════════
// MESSAGE MARKETING SUB™
// ═══════════════════════════════════════════════════════════════
export const SUB_MARKETING = {
  title: "Technologie LECOINTRE – SUB™",
  subtitle: "Système Universel de Broderie",
  tagline: "Première application au monde intégrant des points brevetables",
  benefits: [
    "✅ Broder plus vite",
    "✅ Broder sans trous",
    "✅ Broder plus précis",
    "✅ Broder plus réaliste",
    "✅ Broder même en débutant"
  ],
  compatibility: "Compatible broderie réelle + broderie numérique"
};