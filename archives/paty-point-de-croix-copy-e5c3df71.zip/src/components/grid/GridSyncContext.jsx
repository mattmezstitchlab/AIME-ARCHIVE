import React, { createContext, useContext, useState, useCallback } from 'react';

const GridSyncContext = createContext();

export function GridSyncProvider({ children }) {
  // États globaux
  const [selectedColorId, setSelectedColorId] = useState(null);
  const [selectedSymbolId, setSelectedSymbolId] = useState(null);
  const [activeTool, setActiveTool] = useState(null);
  const [gridSelection, setGridSelection] = useState({ type: 'none' });
  const [miniMapView, setMiniMapView] = useState({
    mode: 'navigation',
    zoomLevel: 100,
    centerX: 0,
    centerY: 0
  });
  const [paletteFilter, setPaletteFilter] = useState({
    usage: 'toutes',
    sortBy: 'numero'
  });
  const [isolatedColorId, setIsolatedColorId] = useState(null);
  const [highlightedPoints, setHighlightedPoints] = useState([]);

  // Synchronisation Grille → Palette
  const handleGridPointClick = useCallback((point, tool, modifiers = {}) => {
    if (tool === 'symbol-picker' || tool === 'pipette') {
      setSelectedColorId(point.colorId);
      setSelectedSymbolId(point.symbolId);
      
      // Ctrl/Cmd + clic → isoler
      if (modifiers.ctrl || modifiers.cmd) {
        setIsolatedColorId(point.colorId);
        setMiniMapView(prev => ({ ...prev, mode: 'couleurs' }));
      }
    } else if (tool === 'selection-ia') {
      // Sélection automatique de zone
      setGridSelection({
        type: 'color',
        colorId: point.colorId
      });
    }
  }, []);

  // Synchronisation Palette → Grille
  const handlePaletteColorClick = useCallback((colorId, symbolId) => {
    setSelectedColorId(colorId);
    setSelectedSymbolId(symbolId);
    setMiniMapView(prev => ({ ...prev, mode: 'couleurs' }));
  }, []);

  // Synchronisation Mini-carte → Grille
  const handleMinimapNavigate = useCallback((x, y) => {
    setMiniMapView(prev => ({
      ...prev,
      centerX: x,
      centerY: y
    }));
  }, []);

  const handleMinimapColorClick = useCallback((colorId) => {
    setSelectedColorId(colorId);
  }, []);

  // Réinitialisation
  const resetSelection = useCallback(() => {
    setSelectedColorId(null);
    setSelectedSymbolId(null);
    setGridSelection({ type: 'none' });
    setIsolatedColorId(null);
    setHighlightedPoints([]);
  }, []);

  // Actions de sélection
  const selectZone = useCallback((rect) => {
    setGridSelection({ type: 'zone', rect });
  }, []);

  const selectColorGlobal = useCallback((colorId) => {
    setGridSelection({ type: 'color', colorId });
    setSelectedColorId(colorId);
  }, []);

  const selectSymbolGlobal = useCallback((symbolId) => {
    setGridSelection({ type: 'symbol', symbolId });
    setSelectedSymbolId(symbolId);
  }, []);

  const isolateColor = useCallback((colorId) => {
    setIsolatedColorId(colorId);
    setSelectedColorId(colorId);
  }, []);

  const value = {
    // États
    selectedColorId,
    selectedSymbolId,
    activeTool,
    gridSelection,
    miniMapView,
    paletteFilter,
    isolatedColorId,
    highlightedPoints,
    
    // Setters
    setSelectedColorId,
    setSelectedSymbolId,
    setActiveTool,
    setGridSelection,
    setMiniMapView,
    setPaletteFilter,
    setIsolatedColorId,
    setHighlightedPoints,
    
    // Actions
    handleGridPointClick,
    handlePaletteColorClick,
    handleMinimapNavigate,
    handleMinimapColorClick,
    resetSelection,
    selectZone,
    selectColorGlobal,
    selectSymbolGlobal,
    isolateColor
  };

  return (
    <GridSyncContext.Provider value={value}>
      {children}
    </GridSyncContext.Provider>
  );
}

export function useGridSync() {
  const context = useContext(GridSyncContext);
  if (!context) {
    throw new Error('useGridSync must be used within a GridSyncProvider');
  }
  return context;
}