import React, { useRef, useEffect, useState } from 'react';
import { cn } from '@/lib/utils';
import CellContextMenu from './CellContextMenu';
import { useSettings } from '../settings/SettingsContext';

export default function GridCanvas({
  nbColonnes,
  nbLignes,
  tailleCase,
  zoom,
  offsetX,
  offsetY,
  repere10x10,
  numerotation10x10,
  repereCentral,
  stitches,
  patternStitches,
  showPattern,
  showGrid,
  showSymbols,
  gridPageOverlay,
  currentTool,
  selectedColor,
  patternSourceImage,
  patternWidth,
  patternHeight,
  patternColorPalette,
  patternSymbolGrid,
  showPatternImage,
  showPatternSymbols,
  selectedColorId,
  selectedSymbolId,
  isMarkingZone,
  dailyZone,
  isDailyZoneActive,
  stitchType = 'full',
  floatingElement,
  placedElements,
  selectedElements,
  selectedGroupId,
  referenceImage,
  pattern,
  onPan,
  onStitchAdd,
  onPlaceElement,
  onSelectElement,
  onStitchRemove,
  onStitchToggleDone,
  onHoverCell,
  onZoneMarkComplete,
  onDailyZoneComplete,
  onSymbolPick,
  onCellChangeSymbol,
  onCellChangeColor,
  mosaicConfig,
  showMosaicGuides,
  flashCell,
  onCellClick,
  // Nouveaux modes d'affichage
  contrastMode = false,
  symbolSizeMode = 'normal', // 'normal', 'mini', 'comfort', 'mega'
  antiFatigueMode = false,
  focusColorMode = false,
  highlightActiveMode = false,
  nightMode = false,
  autoCountMode = false,
  paletteHoverColorId = null, // Survol depuis palette DMC
  isolatedColorId = null // Couleur isolée globalement
}) {
  const canvasRef = useRef(null);
  const [isPanning, setIsPanning] = useState(false);
  const [lastPos, setLastPos] = useState({ x: 0, y: 0 });
  const [pixelatedImage, setPixelatedImage] = useState(null);
  const [gridPageImage, setGridPageImage] = useState(null);
  const [gridPagePixelated, setGridPagePixelated] = useState(null);
  const [zoneStart, setZoneStart] = useState(null);
  const [zoneEnd, setZoneEnd] = useState(null);
  const [contextMenu, setContextMenu] = useState(null);
  const [currentHoverCell, setCurrentHoverCell] = useState({ col: null, row: null });
  const [cursorStyle, setCursorStyle] = useState('default');
  const [referenceImageLoaded, setReferenceImageLoaded] = useState(null);
  const [hoverSymbolCount, setHoverSymbolCount] = useState(null);

  // Calculer le symbole survolé pour le mode Focus
  const hoveredColorId = React.useMemo(() => {
    // Priorité 1 : survol depuis la palette DMC
    if (paletteHoverColorId) return paletteHoverColorId;
    
    // Priorité 2 : couleur isolée globalement
    if (isolatedColorId) return isolatedColorId;
    
    // Priorité 3 : mode focus couleur avec survol grille
    if (!focusColorMode || !patternSymbolGrid || currentHoverCell.col === null) return null;
    
    const offsetCol = pattern?.offsetCol || 0;
    const offsetRow = pattern?.offsetRow || 0;
    const localCol = currentHoverCell.col - offsetCol;
    const localRow = currentHoverCell.row - offsetRow;
    
    if (localRow < 0 || localRow >= patternSymbolGrid.length || 
        localCol < 0 || !patternSymbolGrid[localRow] || localCol >= patternSymbolGrid[localRow].length) {
      return null;
    }
    
    const cell = patternSymbolGrid[localRow]?.[localCol];
    return cell?.colorId || null;
  }, [focusColorMode, currentHoverCell, patternSymbolGrid, pattern, paletteHoverColorId, isolatedColorId]);

  // Déterminer si on est en mode preview palette (survol) ou isolation
  const isPalettePreviewMode = !!paletteHoverColorId || !!isolatedColorId;
  
  // Apply settings from context
  const { settings: userSettings } = useSettings();
  const effectiveSettings = {
    showGrid: showGrid ?? userSettings?.showGrid ?? true,
    gridLineThickness: userSettings?.gridLineThickness ?? 1,
    gridOpacity: userSettings?.gridOpacity ?? 30,
    showCenterMarker: repereCentral ?? userSettings?.showCenterMarker ?? true,
    centerMarkerSize: userSettings?.centerMarkerSize ?? 10,
    centerMarkerStyle: userSettings?.centerMarkerStyle ?? 'cross-circle',
    mosaicLineThickness: userSettings?.mosaicLineThickness ?? 10,
    mosaicLineOpacity: userSettings?.mosaicLineOpacity ?? 60,
    showMosaicInGrid: userSettings?.showMosaicInGrid ?? true,
    symbolSize: userSettings?.symbolSize ?? 100
  };

  // Charger l'image de référence
  useEffect(() => {
    if (!referenceImage) {
      setReferenceImageLoaded(null);
      return;
    }

    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      setReferenceImageLoaded(img);
    };
    img.src = referenceImage;
  }, [referenceImage]);

  // Charger et pixeliser l'image source
  useEffect(() => {
    if (!patternSourceImage || !patternWidth || !patternHeight) {
      setPixelatedImage(null);
      return;
    }

    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      const tempCanvas = document.createElement('canvas');
      tempCanvas.width = patternWidth;
      tempCanvas.height = patternHeight;
      const tempCtx = tempCanvas.getContext('2d');
      
      // Désactiver le lissage pour effet pixelisé
      tempCtx.imageSmoothingEnabled = false;
      tempCtx.drawImage(img, 0, 0, patternWidth, patternHeight);
      
      setPixelatedImage(tempCanvas);
    };
    img.src = patternSourceImage;
  }, [patternSourceImage, patternWidth, patternHeight]);

  // Charger et pixeliser l'image de grille d'auteur
  useEffect(() => {
    if (!gridPageOverlay?.imageUrl) {
      setGridPageImage(null);
      setGridPagePixelated(null);
      return;
    }

    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      setGridPageImage(img);
      
      // Pixeliser l'image selon les dimensions de la grille
      const tempCanvas = document.createElement('canvas');
      tempCanvas.width = gridPageOverlay.gridWidth;
      tempCanvas.height = gridPageOverlay.gridHeight;
      const tempCtx = tempCanvas.getContext('2d');
      
      tempCtx.imageSmoothingEnabled = false;
      tempCtx.drawImage(img, 0, 0, gridPageOverlay.gridWidth, gridPageOverlay.gridHeight);
      
      setGridPagePixelated(tempCanvas);
    };
    img.src = gridPageOverlay.imageUrl;
  }, [gridPageOverlay]);

  // Dessiner la grille
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    const dpr = window.devicePixelRatio || 1;
    
    // Ajuster la taille du canvas
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);

    // Effacer et appliquer le fond selon le mode
    ctx.clearRect(0, 0, rect.width, rect.height);
    
    // Mode Nuit Noir & Or : fond noir
    if (nightMode) {
      ctx.fillStyle = '#000000';
      ctx.fillRect(0, 0, rect.width, rect.height);
    }
    // Mode Anti-fatigue : fond beige doux
    else if (antiFatigueMode) {
      ctx.fillStyle = '#F3EED9';
      ctx.fillRect(0, 0, rect.width, rect.height);
    }

    const effectiveTailleCase = tailleCase * zoom;

    // Appliquer le décalage
    ctx.save();
    ctx.translate(offsetX, offsetY);

    // Dessiner l'image de référence en arrière-plan (très en transparence)
    if (referenceImageLoaded) {
      ctx.globalAlpha = 0.3;

      // Calculer les dimensions pour couvrir toute la grille
      const gridPixelWidth = nbColonnes * effectiveTailleCase;
      const gridPixelHeight = nbLignes * effectiveTailleCase;

      // Centrer l'image dans la grille
      const imgAspect = referenceImageLoaded.width / referenceImageLoaded.height;
      const gridAspect = gridPixelWidth / gridPixelHeight;

      let drawWidth, drawHeight, drawX, drawY;

      if (imgAspect > gridAspect) {
        // Image plus large : ajuster à la hauteur
        drawHeight = gridPixelHeight;
        drawWidth = drawHeight * imgAspect;
        drawX = (gridPixelWidth - drawWidth) / 2;
        drawY = 0;
      } else {
        // Image plus haute : ajuster à la largeur
        drawWidth = gridPixelWidth;
        drawHeight = drawWidth / imgAspect;
        drawX = 0;
        drawY = (gridPixelHeight - drawHeight) / 2;
      }

      ctx.drawImage(referenceImageLoaded, drawX, drawY, drawWidth, drawHeight);
      ctx.globalAlpha = 1;
    }

    // Dessiner la grille d'auteur pixelisée SOUS tout (en premier)
    if (gridPagePixelated && gridPageOverlay) {
      ctx.globalAlpha = 0.8;
      ctx.imageSmoothingEnabled = false;

      // Calculer la position de départ pour centrer
      let offsetColPx, offsetRowPx;
      if (gridPageOverlay.offsetCol === 'center') {
        offsetColPx = Math.round((nbColonnes - gridPageOverlay.gridWidth) / 2);
      } else {
        offsetColPx = gridPageOverlay.offsetCol;
      }
      
      if (gridPageOverlay.offsetRow === 'center') {
        offsetRowPx = Math.round((nbLignes - gridPageOverlay.gridHeight) / 2);
      } else {
        offsetRowPx = gridPageOverlay.offsetRow;
      }

      // Dessiner chaque pixel comme une case de couleur
      for (let col = 0; col < gridPageOverlay.gridWidth; col++) {
        for (let row = 0; row < gridPageOverlay.gridHeight; row++) {
          const pixelData = gridPagePixelated.getContext('2d').getImageData(col, row, 1, 1).data;
          const r = pixelData[0];
          const g = pixelData[1];
          const b = pixelData[2];
          const a = pixelData[3];

          if (a > 128) { // Si pixel visible
            const x = (offsetColPx + col) * effectiveTailleCase;
            const y = (offsetRowPx + row) * effectiveTailleCase;
            
            // Dessiner le fond de couleur
            ctx.fillStyle = `rgba(${r}, ${g}, ${b}, 0.6)`;
            ctx.fillRect(x, y, effectiveTailleCase, effectiveTailleCase);
          }
        }
      }
      
      ctx.globalAlpha = 1;

      // Dessiner les symboles (après les couleurs, bien visibles)
      if (showSymbols && gridPageOverlay.colors?.length > 0) {
        ctx.font = `bold ${Math.max(14, effectiveTailleCase * 0.6)}px Arial, sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';

        // Créer une map de couleurs pour un matching plus rapide
        const colorMap = new Map();
        gridPageOverlay.colors.forEach(color => {
          if (color.symbol) {
            const cr = parseInt(color.hex.slice(1, 3), 16);
            const cg = parseInt(color.hex.slice(3, 5), 16);
            const cb = parseInt(color.hex.slice(5, 7), 16);
            colorMap.set(color.hex, { r: cr, g: cg, b: cb, symbol: color.symbol });
          }
        });

        for (let col = 0; col < gridPageOverlay.gridWidth; col++) {
          for (let row = 0; row < gridPageOverlay.gridHeight; row++) {
            const pixelData = gridPagePixelated.getContext('2d').getImageData(col, row, 1, 1).data;
            const r = pixelData[0];
            const g = pixelData[1];
            const b = pixelData[2];
            const a = pixelData[3];

            if (a > 128) {
              // Trouver la couleur la plus proche
              let bestMatch = null;
              let minDistance = Infinity;

              for (const [hex, colorData] of colorMap) {
                const distance = Math.sqrt(
                  Math.pow(colorData.r - r, 2) +
                  Math.pow(colorData.g - g, 2) +
                  Math.pow(colorData.b - b, 2)
                );

                if (distance < minDistance && distance < 50) {
                  minDistance = distance;
                  bestMatch = colorData;
                }
              }

              if (bestMatch?.symbol) {
                const x = (offsetColPx + col) * effectiveTailleCase;
                const y = (offsetRowPx + row) * effectiveTailleCase;

                // Symbole noir pur sans contour
                ctx.fillStyle = '#000000';
                ctx.fillText(
                  bestMatch.symbol,
                  x + effectiveTailleCase / 2,
                  y + effectiveTailleCase / 2
                );
              }
            }
          }
        }
      }
    }

    // Dessiner l'image pixelisée en arrière-plan si disponible
    if (pixelatedImage && showPattern && showPatternImage) {
      ctx.globalAlpha = 1.0;
      ctx.imageSmoothingEnabled = false;

      // Calculer l'offset de centrage (si fourni dans pattern)
      const offsetCol = pattern?.offsetCol || 0;
      const offsetRow = pattern?.offsetRow || 0;

      // Dessiner l'image pixel par pixel selon la taille des cases
      for (let col = 0; col < patternWidth; col++) {
        for (let row = 0; row < patternHeight; row++) {
          const pixelData = pixelatedImage.getContext('2d').getImageData(col, row, 1, 1).data;
          const r = pixelData[0];
          const g = pixelData[1];
          const b = pixelData[2];
          const a = pixelData[3];

          if (a > 0) {
            ctx.fillStyle = `rgba(${r}, ${g}, ${b}, ${a / 255})`;
            ctx.fillRect(
              (offsetCol + col) * effectiveTailleCase,
              (offsetRow + row) * effectiveTailleCase,
              effectiveTailleCase,
              effectiveTailleCase
            );
          }
        }
      }
      ctx.globalAlpha = 1;
    }

    // Dessiner la surbrillance pour le symbole sélectionné (pipette)
    if (selectedSymbolId && patternSymbolGrid && patternColorPalette) {
      for (let row = 0; row < patternSymbolGrid.length; row++) {
        for (let col = 0; col < patternSymbolGrid[row].length; col++) {
          const cell = patternSymbolGrid[row][col];
          if (!cell) continue;

          const color = patternColorPalette.find(c => c.id === cell.colorId);
          if (!color) continue;

          const x = col * effectiveTailleCase;
          const y = row * effectiveTailleCase;

          if (color.assignedSymbolId === selectedSymbolId) {
            // Surbrillance pour les cases avec le symbole sélectionné
            ctx.fillStyle = 'rgba(168, 85, 247, 0.3)';
            ctx.fillRect(x, y, effectiveTailleCase, effectiveTailleCase);

            // Bordure violette
            ctx.strokeStyle = 'rgba(168, 85, 247, 0.8)';
            ctx.lineWidth = 2;
            ctx.strokeRect(x, y, effectiveTailleCase, effectiveTailleCase);
          } else {
            // Diminuer l'opacité des autres cases
            ctx.fillStyle = 'rgba(255, 255, 255, 0.5)';
            ctx.fillRect(x, y, effectiveTailleCase, effectiveTailleCase);
          }
        }
      }
    } else if (selectedColorId && patternSymbolGrid && patternColorPalette) {
      // Surbrillance par couleur (mode original)
      for (let row = 0; row < patternSymbolGrid.length; row++) {
        for (let col = 0; col < patternSymbolGrid[row].length; col++) {
          const cell = patternSymbolGrid[row][col];
          if (!cell) continue;

          const x = col * effectiveTailleCase;
          const y = row * effectiveTailleCase;

          if (cell.colorId === selectedColorId) {
            // Surbrillance pour les cases de la couleur sélectionnée
            ctx.fillStyle = 'rgba(59, 130, 246, 0.3)';
            ctx.fillRect(x, y, effectiveTailleCase, effectiveTailleCase);

            // Bordure bleue
            ctx.strokeStyle = 'rgba(59, 130, 246, 0.8)';
            ctx.lineWidth = 2;
            ctx.strokeRect(x, y, effectiveTailleCase, effectiveTailleCase);
          } else {
            // Diminuer l'opacité des autres cases
            ctx.fillStyle = 'rgba(255, 255, 255, 0.5)';
            ctx.fillRect(x, y, effectiveTailleCase, effectiveTailleCase);
          }
        }
      }
    }

    // Dessiner les symboles du motif importé avec LOD (Level of Detail)
    if (showPattern && showPatternSymbols && patternSymbolGrid && patternColorPalette) {
      const currentZoom = zoom;

      // Calculer l'offset de centrage (si fourni dans pattern)
      const offsetCol = pattern?.offsetCol || 0;
      const offsetRow = pattern?.offsetRow || 0;

      if (currentZoom >= 0.4) {
        // Zoom moyen/élevé : dessiner les symboles
        const baseSymbolScale = currentZoom >= 1.0 ? 0.6 : 0.4;
        
        // Calculer le multiplicateur selon le mode de taille
        let sizeModeMultiplier = 1;
        switch (symbolSizeMode) {
          case 'mini': sizeModeMultiplier = 1.25; break;    // +25%
          case 'comfort': sizeModeMultiplier = 1.75; break; // +75%
          case 'mega': sizeModeMultiplier = 2.5; break;     // +150%
          default: sizeModeMultiplier = 1; break;
        }
        
        const symbolSizeMultiplier = (effectiveSettings.symbolSize / 100) * sizeModeMultiplier;
        const symbolScale = baseSymbolScale * symbolSizeMultiplier;
        // Mode Contraste fort : police plus épaisse
        const fontWeight = contrastMode ? '900' : (effectiveSettings.xlMode ? 'black' : 'bold');
        ctx.font = `${fontWeight} ${Math.max(10, effectiveTailleCase * symbolScale)}px Arial, sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';

        for (let row = 0; row < patternSymbolGrid.length; row++) {
          for (let col = 0; col < patternSymbolGrid[row].length; col++) {
            const cell = patternSymbolGrid[row][col];
            if (!cell) continue;

            const color = patternColorPalette.find(c => c.id === cell.colorId);
            if (!color || !color.assignedSymbolChar) continue;

            const x = (offsetCol + col) * effectiveTailleCase;
            const y = (offsetRow + row) * effectiveTailleCase;

            // Mode Focus Couleur ou Preview Palette : griser les autres couleurs
            const effectiveFocusColorId = hoveredColorId || selectedColorId;
            const shouldApplyFocus = isPalettePreviewMode || (focusColorMode && effectiveFocusColorId);
            
            if (shouldApplyFocus && effectiveFocusColorId && cell.colorId !== effectiveFocusColorId) {
              // Isolation : 10-20% pour le reste, 100% pour la couleur cible
              ctx.globalAlpha = isolatedColorId ? 0.15 : 0.30;
              ctx.fillStyle = '#888888';
            } else {
              ctx.globalAlpha = 1;
              // Mode Nuit Noir & Or : symboles dorés
              if (nightMode) {
                ctx.fillStyle = '#FFD700';
              }
              // Mode Contraste fort : noir pur
              else if (contrastMode) {
                ctx.fillStyle = '#000000';
              } else {
                ctx.fillStyle = '#000000';
              }
            }

            // Mode Contraste fort : ajouter un contour blanc
            if (contrastMode && !nightMode) {
              ctx.strokeStyle = '#FFFFFF';
              ctx.lineWidth = 2;
              ctx.strokeText(
                color.assignedSymbolChar,
                x + effectiveTailleCase / 2,
                y + effectiveTailleCase / 2
              );
            }

            ctx.fillText(
              color.assignedSymbolChar,
              x + effectiveTailleCase / 2,
              y + effectiveTailleCase / 2
            );
            
            ctx.globalAlpha = 1;
          }
        }
      } else {
        // Zoom faible : afficher uniquement des blocs de couleur
        for (let row = 0; row < patternSymbolGrid.length; row++) {
          for (let col = 0; col < patternSymbolGrid[row].length; col++) {
            const cell = patternSymbolGrid[row][col];
            if (!cell) continue;

            const color = patternColorPalette.find(c => c.id === cell.colorId);
            if (!color) continue;

            const x = (offsetCol + col) * effectiveTailleCase;
            const y = (offsetRow + row) * effectiveTailleCase;

            // Petit carré de couleur au centre
            const dotSize = Math.max(2, effectiveTailleCase * 0.3);
            ctx.fillStyle = color.hex;
            ctx.fillRect(
              x + (effectiveTailleCase - dotSize) / 2,
              y + (effectiveTailleCase - dotSize) / 2,
              dotSize,
              dotSize
            );
          }
        }
      }
      }
    
    // Marquage rouge pour les cases DONE
    if (showPattern && patternSymbolGrid && patternColorPalette) {
      // Calculer l'offset de centrage (si fourni dans pattern)
      const offsetCol = pattern?.offsetCol || 0;
      const offsetRow = pattern?.offsetRow || 0;

      for (let row = 0; row < patternSymbolGrid.length; row++) {
        for (let col = 0; col < patternSymbolGrid[row].length; col++) {
          const cell = patternSymbolGrid[row][col];
          if (!cell || !cell.done) continue;

          const x = (offsetCol + col) * effectiveTailleCase;
          const y = (offsetRow + row) * effectiveTailleCase;

          if (zoom >= 0.4) {
            // Contour rouge épais
            ctx.strokeStyle = '#FF0000';
            ctx.lineWidth = Math.max(2, 3 * zoom);
            ctx.strokeRect(x + 1, y + 1, effectiveTailleCase - 2, effectiveTailleCase - 2);
          } else {
            // Point rouge au centre pour petit zoom
            const dotSize = Math.max(2, effectiveTailleCase * 0.2);
            ctx.fillStyle = '#FF0000';
            ctx.fillRect(
              x + (effectiveTailleCase - dotSize) / 2,
              y + (effectiveTailleCase - dotSize) / 2,
              dotSize,
              dotSize
            );
          }
        }
      }
    }
    
    // Dessiner la zone du jour
    if (dailyZone) {
      const startX = dailyZone.startCol * effectiveTailleCase;
      const startY = dailyZone.startRow * effectiveTailleCase;
      const width = (dailyZone.endCol - dailyZone.startCol + 1) * effectiveTailleCase;
      const height = (dailyZone.endRow - dailyZone.startRow + 1) * effectiveTailleCase;
      
      // Halo jaune doux
      ctx.fillStyle = 'rgba(252, 211, 77, 0.2)';
      ctx.fillRect(startX, startY, width, height);
      
      // Bordure jaune
      ctx.strokeStyle = 'rgba(245, 158, 11, 0.6)';
      ctx.lineWidth = 2;
      ctx.strokeRect(startX, startY, width, height);
    }

    // Dessiner la zone de sélection pour le marquage
    if (isMarkingZone && zoneStart && zoneEnd) {
      const startX = Math.min(zoneStart.col, zoneEnd.col) * effectiveTailleCase;
      const startY = Math.min(zoneStart.row, zoneEnd.row) * effectiveTailleCase;
      const width = (Math.abs(zoneEnd.col - zoneStart.col) + 1) * effectiveTailleCase;
      const height = (Math.abs(zoneEnd.row - zoneStart.row) + 1) * effectiveTailleCase;
      
      // Rectangle de sélection
      ctx.fillStyle = 'rgba(34, 197, 94, 0.2)';
      ctx.fillRect(startX, startY, width, height);
      
      ctx.strokeStyle = 'rgba(34, 197, 94, 0.8)';
      ctx.lineWidth = 3;
      ctx.setLineDash([5, 5]);
      ctx.strokeRect(startX, startY, width, height);
      ctx.setLineDash([]);
    }
    
    // Dessiner la zone de sélection pour la zone du jour
    if (isDailyZoneActive && zoneStart && zoneEnd) {
      const startX = Math.min(zoneStart.col, zoneEnd.col) * effectiveTailleCase;
      const startY = Math.min(zoneStart.row, zoneEnd.row) * effectiveTailleCase;
      const width = (Math.abs(zoneEnd.col - zoneStart.col) + 1) * effectiveTailleCase;
      const height = (Math.abs(zoneEnd.row - zoneStart.row) + 1) * effectiveTailleCase;
      
      // Rectangle de sélection jaune
      ctx.fillStyle = 'rgba(252, 211, 77, 0.3)';
      ctx.fillRect(startX, startY, width, height);
      
      ctx.strokeStyle = 'rgba(245, 158, 11, 0.8)';
      ctx.lineWidth = 3;
      ctx.setLineDash([5, 5]);
      ctx.strokeRect(startX, startY, width, height);
      ctx.setLineDash([]);
    }

      // Dessiner le quadrillage seulement si showGrid est true
      if (effectiveSettings.showGrid) {
      // Dessiner le quadrillage standard
      // Mode Nuit : grille dorée subtile
      // Mode Contraste : grille plus visible
      const gridColor = nightMode 
        ? `rgba(255, 215, 0, 0.3)` 
        : contrastMode 
          ? `rgba(0, 0, 0, ${Math.min(effectiveSettings.gridOpacity * 1.5, 100) / 100})`
          : `rgba(224, 224, 224, ${effectiveSettings.gridOpacity / 100})`;
      ctx.strokeStyle = gridColor;
      ctx.lineWidth = contrastMode ? effectiveSettings.gridLineThickness * 1.5 : effectiveSettings.gridLineThickness;

      for (let col = 0; col <= nbColonnes; col++) {
        ctx.beginPath();
        ctx.moveTo(col * effectiveTailleCase, 0);
        ctx.lineTo(col * effectiveTailleCase, nbLignes * effectiveTailleCase);
        ctx.stroke();
      }

      for (let row = 0; row <= nbLignes; row++) {
        ctx.beginPath();
        ctx.moveTo(0, row * effectiveTailleCase);
        ctx.lineTo(nbColonnes * effectiveTailleCase, row * effectiveTailleCase);
        ctx.stroke();
      }

      // Dessiner les repères 10x10 (au-dessus du quadrillage standard)
      if (repere10x10) {
        ctx.strokeStyle = '#6A6A6A';
        ctx.lineWidth = 2;

        for (let col = 10; col <= nbColonnes; col += 10) {
          ctx.beginPath();
          ctx.moveTo(col * effectiveTailleCase, 0);
          ctx.lineTo(col * effectiveTailleCase, nbLignes * effectiveTailleCase);
          ctx.stroke();
        }

        for (let row = 10; row <= nbLignes; row += 10) {
          ctx.beginPath();
          ctx.moveTo(0, row * effectiveTailleCase);
          ctx.lineTo(nbColonnes * effectiveTailleCase, row * effectiveTailleCase);
          ctx.stroke();
        }
      }
      }

      // Dessiner les repères de mosaïque (sous les symboles, au-dessus de la grille)
      if (showMosaicGuides && mosaicConfig && effectiveSettings.showMosaicInGrid) {
        ctx.strokeStyle = `rgba(255, 0, 0, ${effectiveSettings.mosaicLineOpacity / 100})`;
        ctx.lineWidth = effectiveSettings.mosaicLineThickness;

        // Format portrait : pageWidth = nbColonnes / cols, pageHeight = pageWidth * 1.4
        const pageWidth = nbColonnes / mosaicConfig.cols;
        const pageHeight = pageWidth * 1.4;

        // Lignes verticales (séparation de colonnes)
        for (let i = 1; i < mosaicConfig.cols; i++) {
          const col = Math.round(i * pageWidth);
          const x = col * effectiveTailleCase;
          ctx.beginPath();
          ctx.moveTo(x, 0);
          ctx.lineTo(x, nbLignes * effectiveTailleCase);
          ctx.stroke();
        }

        // Lignes horizontales (séparation de lignes)
        const numHorizontalLines = Math.floor(nbLignes / pageHeight);
        for (let i = 1; i <= numHorizontalLines; i++) {
          const row = Math.round(i * pageHeight);
          if (row < nbLignes) {
            const y = row * effectiveTailleCase;
            ctx.beginPath();
            ctx.moveTo(0, y);
            ctx.lineTo(nbColonnes * effectiveTailleCase, y);
            ctx.stroke();
          }
        }
      }

    // Dessiner la numérotation (système centré sur 0)
    if (numerotation10x10) {
      ctx.fillStyle = '#64748B';
      ctx.font = `${Math.max(10, 12 * zoom)}px Inter, sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      
      const centerCol = Math.floor(nbColonnes / 2);
      const centerRow = Math.floor(nbLignes / 2);
      const maxHalfCols = Math.ceil(nbColonnes / 2);
      const maxHalfRows = Math.ceil(nbLignes / 2);
      
      // Numéros en haut (de gauche à droite)
      for (let offset = -maxHalfCols; offset <= maxHalfCols; offset += 10) {
        if (offset === 0) continue; // Skip center
        const col = centerCol + offset;
        if (col >= 0 && col <= nbColonnes) {
          ctx.fillText(
            Math.abs(offset).toString(),
            col * effectiveTailleCase,
            -15
          );
        }
      }
      
      // Afficher 0 au centre en haut
      ctx.fillText(
        '0',
        centerCol * effectiveTailleCase,
        -15
      );
      
      // Numéros à gauche (de haut en bas)
      ctx.textAlign = 'right';
      for (let offset = -maxHalfRows; offset <= maxHalfRows; offset += 10) {
        if (offset === 0) continue; // Skip center
        const row = centerRow + offset;
        if (row >= 0 && row <= nbLignes) {
          ctx.fillText(
            Math.abs(offset).toString(),
            -15,
            row * effectiveTailleCase
          );
        }
      }
      
      // Afficher 0 au centre à gauche
      ctx.fillText(
        '0',
        -15,
        centerRow * effectiveTailleCase
      );
    }

    // Dessiner le motif importé (en dessous)
    if (showPattern && patternStitches?.length > 0) {
      patternStitches.forEach(stitch => {
        const x = stitch.col * effectiveTailleCase;
        const y = stitch.row * effectiveTailleCase;
        
        // Si déjà fait, afficher différemment
        if (stitch.done) {
          ctx.strokeStyle = stitch.color;
          ctx.lineWidth = Math.max(2, 2 * zoom);
          ctx.lineCap = 'round';
          
          // Croix complète
          const padding = effectiveTailleCase * 0.15;
          ctx.beginPath();
          ctx.moveTo(x + padding, y + padding);
          ctx.lineTo(x + effectiveTailleCase - padding, y + effectiveTailleCase - padding);
          ctx.stroke();
          
          ctx.beginPath();
          ctx.moveTo(x + effectiveTailleCase - padding, y + padding);
          ctx.lineTo(x + padding, y + effectiveTailleCase - padding);
          ctx.stroke();
          
          // Cercle autour
          ctx.beginPath();
          ctx.arc(
            x + effectiveTailleCase / 2,
            y + effectiveTailleCase / 2,
            effectiveTailleCase * 0.35,
            0,
            Math.PI * 2
          );
          ctx.stroke();
        } else {
          // Point à faire : afficher en transparence
          ctx.globalAlpha = 0.3;
          ctx.fillStyle = stitch.color;
          ctx.fillRect(
            x + effectiveTailleCase * 0.2,
            y + effectiveTailleCase * 0.2,
            effectiveTailleCase * 0.6,
            effectiveTailleCase * 0.6
          );
          ctx.globalAlpha = 1;
        }
      });
    }

    // Dessiner les points de croix manuels (par dessus)
    stitches?.forEach(stitch => {
      const x = stitch.col * effectiveTailleCase;
      const y = stitch.row * effectiveTailleCase;
      const padding = effectiveTailleCase * 0.15;
      const stitchType = stitch.type || 'full';

      ctx.strokeStyle = stitch.color;
      ctx.fillStyle = stitch.color;
      ctx.lineWidth = Math.max(2, 2 * zoom);
      ctx.lineCap = 'round';

      // Dessiner selon le type de point
      switch (stitchType) {
        case 'full':
          // Si un symbole est défini, l'afficher (seulement si showSymbols est true)
          if (stitch.symbol && showSymbols) {
            ctx.fillStyle = '#000000';
            ctx.font = `bold ${Math.max(12, effectiveTailleCase * 0.6)}px Arial, sans-serif`;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(
              stitch.symbol,
              x + effectiveTailleCase / 2,
              y + effectiveTailleCase / 2
            );
          } else {
            // Croix complète (X)
            ctx.beginPath();
            ctx.moveTo(x + padding, y + padding);
            ctx.lineTo(x + effectiveTailleCase - padding, y + effectiveTailleCase - padding);
            ctx.stroke();

            ctx.beginPath();
            ctx.moveTo(x + effectiveTailleCase - padding, y + padding);
            ctx.lineTo(x + padding, y + effectiveTailleCase - padding);
            ctx.stroke();
          }
          break;

        case 'half':
          // Demi-point (diagonale)
          ctx.beginPath();
          if (stitch.orientation === '\\') {
            ctx.moveTo(x + padding, y + padding);
            ctx.lineTo(x + effectiveTailleCase - padding, y + effectiveTailleCase - padding);
          } else {
            ctx.moveTo(x + effectiveTailleCase - padding, y + padding);
            ctx.lineTo(x + padding, y + effectiveTailleCase - padding);
          }
          ctx.stroke();
          break;

        case 'quarter':
          // Quart de point (triangle)
          ctx.beginPath();
          ctx.moveTo(x + effectiveTailleCase / 2, y + effectiveTailleCase / 2);
          ctx.lineTo(x + padding, y + padding);
          ctx.lineTo(x + effectiveTailleCase - padding, y + padding);
          ctx.closePath();
          ctx.fill();
          break;

        case 'three-quarter':
          // Trois-quarts (demi + quart)
          // Demi-point
          ctx.beginPath();
          ctx.moveTo(x + effectiveTailleCase - padding, y + padding);
          ctx.lineTo(x + padding, y + effectiveTailleCase - padding);
          ctx.stroke();
          // Quart de point
          ctx.beginPath();
          ctx.moveTo(x + effectiveTailleCase / 2, y + effectiveTailleCase / 2);
          ctx.lineTo(x + padding, y + padding);
          ctx.lineTo(x + effectiveTailleCase - padding, y + padding);
          ctx.closePath();
          ctx.fill();
          break;

        case 'knot':
          // Nœud français (●)
          ctx.beginPath();
          ctx.arc(
            x + effectiveTailleCase / 2,
            y + effectiveTailleCase / 2,
            Math.max(2, effectiveTailleCase * 0.15),
            0,
            Math.PI * 2
          );
          ctx.fill();
          break;

        case 'bead':
          // Perle (◆)
          const size = effectiveTailleCase * 0.25;
          ctx.save();
          ctx.translate(x + effectiveTailleCase / 2, y + effectiveTailleCase / 2);
          ctx.rotate(Math.PI / 4);
          ctx.fillRect(-size / 2, -size / 2, size, size);
          ctx.restore();
          break;

        case 'backstitch':
          // Point arrière (ligne fine) - nécessite deux points
          // Pour l'instant, simple ligne horizontale
          ctx.lineWidth = Math.max(1, 1 * zoom);
          ctx.beginPath();
          ctx.moveTo(x + padding, y + effectiveTailleCase / 2);
          ctx.lineTo(x + effectiveTailleCase - padding, y + effectiveTailleCase / 2);
          ctx.stroke();
          break;
      }

      // Si fait, ajouter un cercle
      if (stitch.done) {
        ctx.strokeStyle = stitch.color;
        ctx.lineWidth = Math.max(1, 1.5 * zoom);
        ctx.beginPath();
        ctx.arc(
          x + effectiveTailleCase / 2,
          y + effectiveTailleCase / 2,
          effectiveTailleCase * 0.35,
          0,
          Math.PI * 2
        );
        ctx.stroke();
      }
    });

    // Mode Surlignage Actif : dessiner le highlight sur la case survolée
    if (highlightActiveMode && currentHoverCell.col !== null && currentHoverCell.row !== null) {
      const hoverX = currentHoverCell.col * effectiveTailleCase;
      const hoverY = currentHoverCell.row * effectiveTailleCase;
      
      // Case centrale : highlight fort
      ctx.fillStyle = nightMode ? 'rgba(255, 215, 0, 0.4)' : 'rgba(59, 130, 246, 0.4)';
      ctx.fillRect(hoverX, hoverY, effectiveTailleCase, effectiveTailleCase);
      
      // Bordure de la case survolée
      ctx.strokeStyle = nightMode ? '#FFD700' : '#3B82F6';
      ctx.lineWidth = 3;
      ctx.strokeRect(hoverX, hoverY, effectiveTailleCase, effectiveTailleCase);
      
      // Cases voisines : highlight léger
      const neighbors = [
        { col: currentHoverCell.col - 1, row: currentHoverCell.row },
        { col: currentHoverCell.col + 1, row: currentHoverCell.row },
        { col: currentHoverCell.col, row: currentHoverCell.row - 1 },
        { col: currentHoverCell.col, row: currentHoverCell.row + 1 },
      ];
      
      ctx.fillStyle = nightMode ? 'rgba(255, 215, 0, 0.15)' : 'rgba(59, 130, 246, 0.15)';
      neighbors.forEach(n => {
        if (n.col >= 0 && n.col < nbColonnes && n.row >= 0 && n.row < nbLignes) {
          ctx.fillRect(
            n.col * effectiveTailleCase,
            n.row * effectiveTailleCase,
            effectiveTailleCase,
            effectiveTailleCase
          );
        }
      });
    }

    // Mode Comptage Auto : le compteur est maintenant affiché en overlay HTML (voir return)

    // Dessiner le flash de feedback (si actif)
    if (flashCell) {
      const flashOffsetCol = pattern?.offsetCol || 0;
      const flashOffsetRow = pattern?.offsetRow || 0;
      const flashX = (flashCell.col) * effectiveTailleCase;
      const flashY = (flashCell.row) * effectiveTailleCase;
      
      ctx.fillStyle = flashCell.color || '#FFC94A';
      ctx.globalAlpha = 0.6;
      ctx.fillRect(flashX, flashY, effectiveTailleCase, effectiveTailleCase);
      ctx.globalAlpha = 1;
      
      // Bordure jaune épaisse
      ctx.strokeStyle = flashCell.color || '#FFC94A';
      ctx.lineWidth = 3;
      ctx.strokeRect(flashX, flashY, effectiveTailleCase, effectiveTailleCase);
    }

    // Dessiner le repère central (toujours au-dessus, toujours visible)
    if (effectiveSettings.showCenterMarker) {
      const centreCol = Math.floor(nbColonnes / 2);
      const centreLigne = Math.floor(nbLignes / 2);

      // Position exacte : centre mathématique de la grille
      const centerX = centreCol * effectiveTailleCase;
      const centerY = centreLigne * effectiveTailleCase;

      ctx.strokeStyle = '#FF0000';
      ctx.lineWidth = 2;
      ctx.globalAlpha = 1;
      ctx.lineCap = 'round';

      // Taille basée sur les settings
      const crossSize = effectiveSettings.centerMarkerSize * zoom;

      // Croix
      ctx.beginPath();
      ctx.moveTo(centerX, centerY - crossSize);
      ctx.lineTo(centerX, centerY + crossSize);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(centerX - crossSize, centerY);
      ctx.lineTo(centerX + crossSize, centerY);
      ctx.stroke();

      // Cercle si le style l'exige
      if (effectiveSettings.centerMarkerStyle === 'cross-circle' || effectiveSettings.centerMarkerStyle === 'cross-halo') {
        ctx.beginPath();
        ctx.arc(
          centerX, 
          centerY, 
          crossSize * 0.8,
          0, 
          Math.PI * 2
        );
        ctx.stroke();
      }

      // Halo si activé
      if (effectiveSettings.centerMarkerStyle === 'cross-halo') {
        ctx.fillStyle = 'rgba(255, 0, 0, 0.1)';
        ctx.beginPath();
        ctx.arc(centerX, centerY, crossSize * 1.5, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // Dessiner les éléments placés
    if (placedElements?.length > 0) {
      placedElements.forEach(element => {
        const scale = element.scale || 1;
        const isSelected = selectedElements?.includes(element.id) || 
                         element.groupId === selectedGroupId;

        element.pattern.forEach((row, rowIndex) => {
          row.forEach((cell, colIndex) => {
            if (cell === 1) {
              for (let sx = 0; sx < scale; sx++) {
                for (let sy = 0; sy < scale; sy++) {
                  const x = (element.x + colIndex * scale + sx) * effectiveTailleCase;
                  const y = (element.y + rowIndex * scale + sy) * effectiveTailleCase;

                  ctx.fillStyle = element.color;
                  ctx.fillRect(x, y, effectiveTailleCase, effectiveTailleCase);

                  ctx.strokeStyle = isSelected ? '#3B82F6' : '#000000';
                  ctx.lineWidth = isSelected ? 3 : 1;
                  ctx.strokeRect(x, y, effectiveTailleCase, effectiveTailleCase);
                }
              }
            }
          });
        });

        // Dessiner le cadre de sélection autour de l'élément
        if (isSelected) {
          const boundX = element.x * effectiveTailleCase;
          const boundY = element.y * effectiveTailleCase;
          const boundWidth = element.width * scale * effectiveTailleCase;
          const boundHeight = element.height * scale * effectiveTailleCase;

          // Cadre bleu en pointillés
          ctx.strokeStyle = '#3B82F6';
          ctx.lineWidth = 2;
          ctx.setLineDash([5, 5]);
          ctx.strokeRect(boundX - 2, boundY - 2, boundWidth + 4, boundHeight + 4);
          ctx.setLineDash([]);

          // Poignées aux coins
          const handleSize = Math.max(6, 6 * zoom);
          const handles = [
            { x: boundX, y: boundY }, // top-left
            { x: boundX + boundWidth, y: boundY }, // top-right
            { x: boundX, y: boundY + boundHeight }, // bottom-left
            { x: boundX + boundWidth, y: boundY + boundHeight } // bottom-right
          ];

          handles.forEach(handle => {
            ctx.fillStyle = '#FFFFFF';
            ctx.strokeStyle = '#3B82F6';
            ctx.lineWidth = 2;
            ctx.fillRect(
              handle.x - handleSize / 2,
              handle.y - handleSize / 2,
              handleSize,
              handleSize
            );
            ctx.strokeRect(
              handle.x - handleSize / 2,
              handle.y - handleSize / 2,
              handleSize,
              handleSize
            );
          });
        }
      });
    }

    // Dessiner l'élément flottant à placer
    if (floatingElement && currentTool === 'place-element' && currentHoverCell.col !== null) {
      ctx.globalAlpha = 0.6;

      floatingElement.pattern.forEach((row, rowIndex) => {
        row.forEach((cell, colIndex) => {
          if (cell === 1) {
            const x = (currentHoverCell.col + colIndex) * effectiveTailleCase;
            const y = (currentHoverCell.row + rowIndex) * effectiveTailleCase;

            ctx.fillStyle = floatingElement.color;
            ctx.fillRect(x, y, effectiveTailleCase, effectiveTailleCase);

            ctx.strokeStyle = '#000000';
            ctx.lineWidth = 2;
            ctx.strokeRect(x, y, effectiveTailleCase, effectiveTailleCase);
          }
        });
      });

      ctx.globalAlpha = 1;
    }

    ctx.restore();
    }, [nbColonnes, nbLignes, tailleCase, zoom, offsetX, offsetY, repere10x10, numerotation10x10, repereCentral, stitches, patternStitches, showPattern, showGrid, showSymbols, pixelatedImage, patternWidth, patternHeight, gridPageImage, gridPagePixelated, gridPageOverlay, patternColorPalette, patternSymbolGrid, showPatternImage, showPatternSymbols, selectedColorId, isMarkingZone, dailyZone, isDailyZoneActive, zoneStart, zoneEnd, floatingElement, placedElements, selectedElements, selectedGroupId, currentTool, currentHoverCell, mosaicConfig, showMosaicGuides, flashCell, contrastMode, symbolSizeMode, antiFatigueMode, focusColorMode, highlightActiveMode, nightMode, autoCountMode, pattern, hoveredColorId, paletteHoverColorId, isolatedColorId, isPalettePreviewMode]);

  // Détection d'élément sous le curseur
  const findElementAtCell = (col, row) => {
    if (!placedElements || placedElements.length === 0) return null;
    
    return [...placedElements].reverse().find(el => {
      const scale = el.scale || 1;
      return col >= el.x && 
             col < el.x + el.width * scale &&
             row >= el.y && 
             row < el.y + el.height * scale;
    });
  };

  // Gestion des événements souris/tactile
  const getGridCoordinates = (clientX, clientY) => {
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const x = clientX - rect.left - offsetX;
    const y = clientY - rect.top - offsetY;
    
    const effectiveTailleCase = tailleCase * zoom;
    const col = Math.floor(x / effectiveTailleCase);
    const row = Math.floor(y / effectiveTailleCase);
    
    if (col >= 0 && col < nbColonnes && row >= 0 && row < nbLignes) {
      return { col, row };
    }
    return null;
  };

  const handleMouseDown = (e) => {
    const coords = getGridCoordinates(e.clientX, e.clientY);

    if (currentTool === 'place-element' && coords && floatingElement && onPlaceElement) {
      onPlaceElement(coords.col, coords.row);
      return;
    }

    // Toujours vérifier si on clique sur un élément placé
    if (coords) {
      const clickedElement = findElementAtCell(coords.col, coords.row);

      if (clickedElement && onSelectElement) {
        onSelectElement(clickedElement.id);
        return;
      } else if (onSelectElement) {
        // Clic sur zone vide : désélectionner
        onSelectElement(null);
      }
    }

    if (currentTool === 'symbol-picker' && coords) {
      // Pipette de symbole : récupérer le symbole de la case cliquée
      if (patternSymbolGrid && patternSymbolGrid[coords.row] && patternSymbolGrid[coords.row][coords.col]) {
        const cell = patternSymbolGrid[coords.row][coords.col];
        if (cell && cell.colorId) {
          // Trouver la couleur dans la palette
          const color = patternColorPalette?.find(c => c.id === cell.colorId);
          if (color && onSymbolPick) {
            // Toujours remplacer la sélection précédente
            onSymbolPick(cell.colorId, color.assignedSymbolId, color.assignedSymbolChar, color.hex);
          }
        } else if (onSymbolPick) {
          // Case vide : désélectionner
          onSymbolPick(null, null, null, null);
        }
      } else if (onSymbolPick) {
        // Hors grille ou case vide : désélectionner
        onSymbolPick(null, null, null, null);
      }
    } else if (currentTool === 'zone-mark' && coords) {
      // Début de sélection de zone
      setZoneStart(coords);
      setZoneEnd(coords);
    } else if (currentTool === 'daily-zone' && coords) {
      // Début de sélection de zone du jour
      setZoneStart(coords);
      setZoneEnd(coords);
    } else if (currentTool === 'pan') {
      setIsPanning(true);
      setLastPos({ x: e.clientX, y: e.clientY });
    } else if (currentTool === 'cross' && coords) {
      onStitchAdd?.(coords.col, coords.row, selectedColor?.hex);
    } else if (currentTool === 'erase' && coords) {
      onStitchRemove?.(coords.col, coords.row);
    } else if (currentTool === 'selection-ia' && coords) {
      onCellClick?.(coords.col, coords.row);
    }
    
    // Si on clique sur un point du motif, le marquer comme fait/à faire
    if (coords && patternStitches?.length > 0 && onStitchToggleDone) {
      const patternStitch = patternStitches.find(
        s => s.col === coords.col && s.row === coords.row
      );
      if (patternStitch) {
        onStitchToggleDone(coords.col, coords.row);
      }
    }
  };

  const handleMouseMove = (e) => {
    if (isPanning) {
      const dx = e.clientX - lastPos.x;
      const dy = e.clientY - lastPos.y;
      onPan(dx, dy);
      setLastPos({ x: e.clientX, y: e.clientY });
    } else if ((currentTool === 'zone-mark' || currentTool === 'daily-zone') && zoneStart) {
      const coords = getGridCoordinates(e.clientX, e.clientY);
      if (coords) {
        setZoneEnd(coords);
      }
    } else {
      const coords = getGridCoordinates(e.clientX, e.clientY);
      if (coords) {
        setCurrentHoverCell(coords);
        onHoverCell(coords.col, coords.row);

        // Gérer le curseur
        const elementUnder = findElementAtCell(coords.col, coords.row);
        if (elementUnder) {
          setCursorStyle('pointer');
        } else if (currentTool === 'place-element') {
          setCursorStyle('copy');
        } else {
          setCursorStyle('default');
        }
      }
    }
  };

  const handleMouseUp = () => {
    if (currentTool === 'zone-mark' && zoneStart && zoneEnd && onZoneMarkComplete) {
      onZoneMarkComplete(zoneStart.col, zoneStart.row, zoneEnd.col, zoneEnd.row);
      setZoneStart(null);
      setZoneEnd(null);
    } else if (currentTool === 'daily-zone' && zoneStart && zoneEnd && onDailyZoneComplete) {
      onDailyZoneComplete(zoneStart.col, zoneStart.row, zoneEnd.col, zoneEnd.row);
      setZoneStart(null);
      setZoneEnd(null);
    }
    setIsPanning(false);
  };

  const handleContextMenu = (e) => {
    e.preventDefault();
    
    const coords = getGridCoordinates(e.clientX, e.clientY);
    if (!coords) return;

    // Vérifier si cette case a un symbole
    if (patternSymbolGrid && patternSymbolGrid[coords.row] && patternSymbolGrid[coords.row][coords.col]) {
      const cell = patternSymbolGrid[coords.row][coords.col];
      if (cell && cell.colorId) {
        const color = patternColorPalette?.find(c => c.id === cell.colorId);
        if (color) {
          setContextMenu({
            position: { x: e.clientX, y: e.clientY },
            cell: {
              col: coords.col,
              row: coords.row,
              colorId: cell.colorId,
              symbolId: color.assignedSymbolId,
              color: color.hex,
              symbol: color.assignedSymbolChar,
              colorName: color.name
            }
          });
        }
      }
    }
  };

  // Calculer le comptage du symbole survolé
  useEffect(() => {
    if (!autoCountMode || !patternSymbolGrid || !patternColorPalette) {
      setHoverSymbolCount(null);
      return;
    }
    
    if (currentHoverCell.col === null || currentHoverCell.row === null) {
      setHoverSymbolCount(null);
      return;
    }
    
    const offsetCol = pattern?.offsetCol || 0;
    const offsetRow = pattern?.offsetRow || 0;
    const localCol = currentHoverCell.col - offsetCol;
    const localRow = currentHoverCell.row - offsetRow;
    
    if (localRow < 0 || localRow >= patternSymbolGrid.length || 
        localCol < 0 || !patternSymbolGrid[localRow] || localCol >= patternSymbolGrid[localRow].length) {
      setHoverSymbolCount(null);
      return;
    }
    
    const cell = patternSymbolGrid[localRow][localCol];
    if (!cell || !cell.colorId) {
      setHoverSymbolCount(null);
      return;
    }
    
    // Compter tous les points de ce symbole
    let count = 0;
    for (let row = 0; row < patternSymbolGrid.length; row++) {
      for (let col = 0; col < (patternSymbolGrid[row]?.length || 0); col++) {
        const c = patternSymbolGrid[row][col];
        if (c && c.colorId === cell.colorId) {
          count++;
        }
      }
    }
    
    const color = patternColorPalette.find(c => c.id === cell.colorId);
    setHoverSymbolCount({
      count,
      symbol: color?.assignedSymbolChar || '●',
      colorName: color?.name || color?.code || ''
    });
  }, [autoCountMode, currentHoverCell, patternSymbolGrid, patternColorPalette, pattern]);

  return (
    <>
      {/* Overlay Anti-fatigue sépia */}
      {antiFatigueMode && (
        <div 
          className="absolute inset-0 pointer-events-none z-10 transition-opacity duration-300"
          style={{ 
            backgroundColor: 'rgba(180, 140, 80, 0.22)',
            mixBlendMode: 'multiply'
          }}
        />
      )}
      
      <canvas
        ref={canvasRef}
        style={{ cursor: isPanning ? 'grabbing' : (currentTool === 'pan' ? 'grab' : cursorStyle) }}
        className="w-full h-full bg-slate-50"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onContextMenu={handleContextMenu}
      />
      
      {/* Bulle de comptage auto au survol */}
      {autoCountMode && hoverSymbolCount && currentHoverCell.col !== null && (
        <div 
          className="absolute pointer-events-none z-20 transition-all duration-150"
          style={{
            left: '50%',
            top: '20px',
            transform: 'translateX(-50%)',
          }}
        >
          <div 
            className="px-4 py-2 rounded-lg shadow-lg flex items-center gap-2"
            style={{
              backgroundColor: nightMode ? 'rgba(0, 0, 0, 0.95)' : 'rgba(0, 0, 0, 0.85)',
              border: nightMode ? '1px solid #FFD700' : '1px solid rgba(255,255,255,0.2)'
            }}
          >
            <span 
              className="text-xl font-bold"
              style={{ color: nightMode ? '#FFD700' : '#FFC94A' }}
            >
              {hoverSymbolCount.symbol}
            </span>
            <span className="text-white font-medium">
              = {hoverSymbolCount.count} points
            </span>
            {hoverSymbolCount.colorName && (
              <span className="text-gray-400 text-sm ml-1">
                ({hoverSymbolCount.colorName})
              </span>
            )}
          </div>
        </div>
      )}
      
      {/* Menu contextuel */}
      {contextMenu && (
        <CellContextMenu
          position={contextMenu.position}
          cellData={contextMenu.cell}
          onChangeSymbol={() => {
            onCellChangeSymbol(contextMenu.cell);
            setContextMenu(null);
          }}
          onChangeColor={() => {
            onCellChangeColor(contextMenu.cell);
            setContextMenu(null);
          }}
          onClose={() => setContextMenu(null)}
        />
      )}
    </>
  );
}