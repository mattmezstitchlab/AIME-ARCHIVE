import React, { useState } from 'react';
import { cn } from '@/lib/utils';
import {
  Eye,
  Edit3,
  Droplet,
  CheckCircle2,
  GitMerge,
  Trash2
} from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';

export default function NewColorPalette({
  colorPalette = [],
  selectedColorId,
  onColorSelect,
  onIsolateColor,
  onUpdateSymbol,
  onUpdateColor,
  onMarkAsDone,
  onMergeWith,
  onDelete
}) {
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t-2 border-slate-200 shadow-2xl z-[2000] h-[140px]">
      <div className="h-full flex items-stretch">
        {/* Bloc d'outils couleurs (fixe à gauche) */}
        <div className="w-64 flex-shrink-0 bg-[#F4F4F4] border-r-2 border-slate-200 p-3 flex flex-col justify-center">
          <TooltipProvider>
            <div className="grid grid-cols-3 gap-2">
              {/* Rangée 1 */}
              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => selectedColorId && onIsolateColor?.(selectedColorId)}
                    disabled={!selectedColorId}
                    className={cn(
                      "aspect-square rounded-lg flex items-center justify-center transition-all",
                      selectedColorId
                        ? "bg-slate-200 hover:bg-slate-300 text-slate-900"
                        : "bg-slate-100 text-slate-400 cursor-not-allowed"
                    )}
                  >
                    <Eye className="w-5 h-5" />
                  </button>
                </TooltipTrigger>
                <TooltipContent><p>Isoler la couleur</p></TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => selectedColorId && onUpdateSymbol?.(colorPalette.find(c => c.id === selectedColorId))}
                    disabled={!selectedColorId}
                    className={cn(
                      "aspect-square rounded-lg flex items-center justify-center transition-all",
                      selectedColorId
                        ? "bg-slate-200 hover:bg-slate-300 text-slate-900"
                        : "bg-slate-100 text-slate-400 cursor-not-allowed"
                    )}
                  >
                    <Edit3 className="w-5 h-5" />
                  </button>
                </TooltipTrigger>
                <TooltipContent><p>Modifier le symbole</p></TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => selectedColorId && onUpdateColor?.(colorPalette.find(c => c.id === selectedColorId))}
                    disabled={!selectedColorId}
                    className={cn(
                      "aspect-square rounded-lg flex items-center justify-center transition-all",
                      selectedColorId
                        ? "bg-slate-200 hover:bg-slate-300 text-slate-900"
                        : "bg-slate-100 text-slate-400 cursor-not-allowed"
                    )}
                  >
                    <Droplet className="w-5 h-5" />
                  </button>
                </TooltipTrigger>
                <TooltipContent><p>Modifier la couleur DMC</p></TooltipContent>
              </Tooltip>

              {/* Rangée 2 */}
              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => selectedColorId && onMarkAsDone?.(selectedColorId)}
                    disabled={!selectedColorId}
                    className={cn(
                      "aspect-square rounded-lg flex items-center justify-center transition-all",
                      selectedColorId
                        ? "bg-slate-200 hover:bg-slate-300 text-slate-900"
                        : "bg-slate-100 text-slate-400 cursor-not-allowed"
                    )}
                  >
                    <CheckCircle2 className="w-5 h-5" />
                  </button>
                </TooltipTrigger>
                <TooltipContent><p>Marquer comme brodée</p></TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => selectedColorId && onMergeWith?.(colorPalette.find(c => c.id === selectedColorId))}
                    disabled={!selectedColorId}
                    className={cn(
                      "aspect-square rounded-lg flex items-center justify-center transition-all",
                      selectedColorId
                        ? "bg-slate-200 hover:bg-slate-300 text-slate-900"
                        : "bg-slate-100 text-slate-400 cursor-not-allowed"
                    )}
                  >
                    <GitMerge className="w-5 h-5" />
                  </button>
                </TooltipTrigger>
                <TooltipContent><p>Fusionner avec une autre</p></TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => {
                      if (selectedColorId && confirm('Supprimer cette couleur ?')) {
                        onDelete?.(selectedColorId);
                      }
                    }}
                    disabled={!selectedColorId}
                    className={cn(
                      "aspect-square rounded-lg flex items-center justify-center transition-all",
                      selectedColorId
                        ? "bg-red-100 hover:bg-red-200 text-red-700"
                        : "bg-slate-100 text-slate-400 cursor-not-allowed"
                    )}
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </TooltipTrigger>
                <TooltipContent><p>Supprimer cette couleur</p></TooltipContent>
              </Tooltip>
            </div>

            {/* Indicateur de couleur sélectionnée */}
            {selectedColorId && (
              <div className="mt-3 text-center">
                <p className="text-[10px] text-slate-600 font-medium">
                  Couleur active sélectionnée
                </p>
              </div>
            )}
          </TooltipProvider>
        </div>

        {/* Languettes de couleurs (scrollable) */}
        <div className="flex-1 overflow-x-auto overflow-y-hidden px-4 flex items-end gap-3 py-3">
          {colorPalette.map((color) => (
            <button
              key={color.id}
              onClick={() => onColorSelect?.(color.id)}
              className={cn(
                "flex-shrink-0 w-20 h-[110px] rounded-t-xl transition-all relative overflow-hidden",
                selectedColorId === color.id
                  ? "ring-4 ring-[#F5C200] ring-offset-2 shadow-xl transform scale-105"
                  : "hover:shadow-lg hover:transform hover:scale-102"
              )}
              style={{ backgroundColor: color.hex }}
            >
              {/* Symbole en haut */}
              <div className="absolute top-0 left-0 right-0 h-8 bg-white flex items-center justify-center">
                <span className="text-base font-bold text-slate-900">
                  {color.assignedSymbolChar || '●'}
                </span>
              </div>

              {/* Badge compteur */}
              <div className="absolute bottom-2 left-0 right-0 flex justify-center">
                <span className="text-[11px] text-white font-bold drop-shadow-lg bg-black/40 px-2 py-1 rounded">
                  {color.totalCount || 0} pts
                </span>
              </div>

              {/* Indicateur de progression */}
              {color.progress > 0 && (
                <div className="absolute bottom-0 left-0 right-0 h-1 bg-white/30">
                  <div 
                    className="h-full bg-green-400"
                    style={{ width: `${color.progress}%` }}
                  />
                </div>
              )}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}