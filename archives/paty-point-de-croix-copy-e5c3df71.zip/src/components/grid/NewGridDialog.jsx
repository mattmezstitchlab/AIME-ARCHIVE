import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Grid3x3, AlertCircle } from 'lucide-react';
import { cn } from '@/lib/utils';

const gridFormats = [
  100, 120, 150, 180, 200, 220, 250, 280, 300, 350, 400, 450, 500, 550, 600, 700, 800, 999
];

// Presets de mosaïque par format
const mosaicPresets = {
  100: [{ cols: 1, rows: 1 }, { cols: 2, rows: 2 }],
  120: [{ cols: 1, rows: 1 }, { cols: 2, rows: 2 }],
  150: [{ cols: 1, rows: 1 }, { cols: 2, rows: 2 }, { cols: 3, rows: 3 }],
  180: [{ cols: 2, rows: 2 }, { cols: 3, rows: 3 }],
  200: [{ cols: 2, rows: 2 }, { cols: 4, rows: 2 }, { cols: 4, rows: 3 }, { cols: 5, rows: 4 }],
  220: [{ cols: 2, rows: 2 }, { cols: 4, rows: 4 }],
  250: [{ cols: 2, rows: 2 }, { cols: 5, rows: 5 }],
  280: [{ cols: 2, rows: 2 }, { cols: 4, rows: 4 }],
  300: [{ cols: 2, rows: 2 }, { cols: 3, rows: 3 }, { cols: 4, rows: 4 }, { cols: 6, rows: 6 }],
  350: [{ cols: 2, rows: 2 }, { cols: 3, rows: 3 }, { cols: 5, rows: 5 }, { cols: 7, rows: 7 }],
  400: [{ cols: 2, rows: 2 }, { cols: 4, rows: 4 }, { cols: 8, rows: 8 }],
  450: [{ cols: 3, rows: 3 }, { cols: 5, rows: 5 }, { cols: 9, rows: 9 }],
  500: [{ cols: 2, rows: 2 }, { cols: 5, rows: 5 }, { cols: 10, rows: 10 }],
  550: [{ cols: 5, rows: 5 }, { cols: 11, rows: 11 }],
  600: [{ cols: 3, rows: 3 }, { cols: 6, rows: 6 }, { cols: 12, rows: 12 }],
  700: [{ cols: 7, rows: 7 }, { cols: 14, rows: 14 }],
  800: [{ cols: 4, rows: 4 }, { cols: 8, rows: 8 }, { cols: 16, rows: 16 }],
  999: [{ cols: 3, rows: 3 }, { cols: 10, rows: 10 }, { cols: 20, rows: 20 }]
};

export default function NewGridDialog({ open, onClose, onConfirm }) {
  const [gridName, setGridName] = useState('');
  const [selectedSize, setSelectedSize] = useState(200);
  const [mosaicMode, setMosaicMode] = useState('auto');
  const [selectedPreset, setSelectedPreset] = useState(null);
  const [customCols, setCustomCols] = useState(2);
  const [customRows, setCustomRows] = useState(2);

  useEffect(() => {
    if (mosaicMode === 'auto' && mosaicPresets[selectedSize]) {
      setSelectedPreset(mosaicPresets[selectedSize][0]);
    }
  }, [selectedSize, mosaicMode]);

  const handleConfirm = () => {
    let mosaicConfig = null;
    
    if (mosaicMode === 'auto' && selectedPreset) {
      mosaicConfig = { cols: selectedPreset.cols, rows: selectedPreset.rows };
    } else if (mosaicMode === 'custom') {
      mosaicConfig = { cols: customCols, rows: customRows };
    }

    onConfirm({
      name: gridName || `Grille ${selectedSize}×${selectedSize}`,
      nb_colonnes: selectedSize,
      nb_lignes: selectedSize,
      mosaic: mosaicConfig
    });
    
    onClose();
  };

  const getMosaicInfo = () => {
    if (mosaicMode === 'single') return null;
    
    let cols, rows;
    if (mosaicMode === 'auto' && selectedPreset) {
      cols = selectedPreset.cols;
      rows = selectedPreset.rows;
    } else if (mosaicMode === 'custom') {
      cols = customCols;
      rows = customRows;
    } else {
      return null;
    }
    
    // Format PORTRAIT : largeur = grille ÷ colonnes, hauteur = largeur × 1.4
    const pageWidth = Math.round(selectedSize / cols);
    const pageHeight = Math.round(pageWidth * 1.4);
    const totalPages = cols * rows;
    
    const isMultipleOf10 = pageWidth % 10 === 0;
    
    return { cols, rows, pageWidth, pageHeight, totalPages, isMultipleOf10 };
  };

  const mosaicInfo = getMosaicInfo();

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <Grid3x3 className="w-5 h-5" />
            Créer une nouvelle grille
          </DialogTitle>
          <DialogDescription>
            Définissez les paramètres de votre nouvelle grille de broderie
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* 1️⃣ Nom du projet */}
          <div className="space-y-2">
            <Label htmlFor="grid-name">Nom de la grille *</Label>
            <Input
              id="grid-name"
              placeholder="Ex : Bee 200x200"
              value={gridName}
              onChange={(e) => setGridName(e.target.value)}
            />
          </div>

          {/* 2️⃣ Format de la grille */}
          <div className="space-y-2">
            <Label htmlFor="format">Format de la grille (largeur × hauteur)</Label>
            <Select value={selectedSize.toString()} onValueChange={(v) => setSelectedSize(parseInt(v))}>
              <SelectTrigger id="format">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {gridFormats.map((size) => (
                  <SelectItem key={size} value={size.toString()}>
                    {size} × {size}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-xs text-slate-500">
              Toutes les grilles sont centrées sur le point 0,0.<br />
              Exemple 200 × 200 : la numérotation va de −100 à +100 en largeur et en hauteur.
            </p>
          </div>

          {/* 3️⃣ Mode de découpe */}
          <div className="space-y-3 border-t pt-4">
            <Label>Découper la grille en mosaïque de pages</Label>
            <RadioGroup value={mosaicMode} onValueChange={setMosaicMode}>
              <div className="flex items-start space-x-3 p-3 rounded-lg hover:bg-slate-50 cursor-pointer">
                <RadioGroupItem value="single" id="single" />
                <div className="flex-1">
                  <Label htmlFor="single" className="cursor-pointer font-medium">
                    Une seule page (aucune mosaïque)
                  </Label>
                  <p className="text-xs text-slate-500 mt-1">
                    La grille entière est affichée dans une seule page. Idéal pour les petits formats.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-3 p-3 rounded-lg hover:bg-slate-50 cursor-pointer">
                <RadioGroupItem value="auto" id="auto" />
                <div className="flex-1">
                  <Label htmlFor="auto" className="cursor-pointer font-medium">
                    Mosaïque automatique (recommandé)
                  </Label>
                  <p className="text-xs text-slate-500 mt-1">
                    PATYBEE propose automatiquement une mosaïque optimisée en fonction du format choisi.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-3 p-3 rounded-lg hover:bg-slate-50 cursor-pointer">
                <RadioGroupItem value="custom" id="custom" />
                <div className="flex-1">
                  <Label htmlFor="custom" className="cursor-pointer font-medium">
                    Mosaïque personnalisée
                  </Label>
                  <p className="text-xs text-slate-500 mt-1">
                    Permet de définir manuellement le nombre de colonnes et de lignes de la mosaïque.
                  </p>
                </div>
              </div>
            </RadioGroup>
          </div>

          {/* 4️⃣ Mosaïque automatique - Presets */}
          {mosaicMode === 'auto' && mosaicPresets[selectedSize] && (
            <div className="space-y-3 bg-slate-50 p-4 rounded-lg">
              <Label>Propositions de mosaïque pour ce format</Label>
              <div className="grid grid-cols-2 gap-3">
                {mosaicPresets[selectedSize].map((preset) => {
                  const pageWidth = Math.round(selectedSize / preset.cols);
                  const pageHeight = Math.round(pageWidth * 1.4);
                  const isSelected = selectedPreset?.cols === preset.cols && selectedPreset?.rows === preset.rows;
                  
                  return (
                    <button
                      key={`${preset.cols}x${preset.rows}`}
                      onClick={() => setSelectedPreset(preset)}
                      className={cn(
                        "p-3 rounded-lg border-2 text-left transition-all",
                        isSelected 
                          ? "border-slate-900 bg-white shadow-md" 
                          : "border-slate-200 hover:border-slate-400 bg-white"
                      )}
                    >
                      <div className="font-semibold text-slate-900">
                        {preset.cols} × {preset.rows} pages
                      </div>
                      <div className="text-xs text-slate-600 mt-1">
                        {preset.cols * preset.rows} pages portrait – ≈ {pageWidth} × {pageHeight} cases/page
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* 5️⃣ Mosaïque personnalisée */}
          {mosaicMode === 'custom' && (
            <div className="space-y-3 bg-slate-50 p-4 rounded-lg">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="custom-cols">Colonnes</Label>
                  <Input
                    id="custom-cols"
                    type="number"
                    min="1"
                    max="20"
                    value={customCols}
                    onChange={(e) => setCustomCols(parseInt(e.target.value) || 1)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="custom-rows">Lignes</Label>
                  <Input
                    id="custom-rows"
                    type="number"
                    min="1"
                    max="20"
                    value={customRows}
                    onChange={(e) => setCustomRows(parseInt(e.target.value) || 1)}
                  />
                </div>
              </div>
              
              {mosaicInfo && (
                <div className="mt-3 text-sm text-slate-700">
                  <p>
                    Votre grille de <strong>{selectedSize} × {selectedSize}</strong> cases sera découpée en{' '}
                    <strong>{mosaicInfo.cols} colonnes × {mosaicInfo.rows} lignes</strong>.
                  </p>
                  <p className="mt-1">
                    Taille approximative d'une page : <strong>~{mosaicInfo.pageWidth} × {mosaicInfo.pageHeight}</strong> cases.
                  </p>
                  
                  {!mosaicInfo.isMultipleOf10 && (
                    <div className="flex items-start gap-2 mt-3 p-2 bg-amber-50 border border-amber-200 rounded text-amber-800">
                      <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
                      <p className="text-xs">
                        Certaines pages ne feront pas exactement des blocs 10 × 10, PATYBEE ajustera automatiquement.
                      </p>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Aperçu de la mosaïque */}
          {mosaicInfo && (
            <div className="border-t pt-4">
              <div className="flex items-start gap-6">
                {/* Mini-légende visuelle */}
                <div className="flex-1">
                  <Label className="mb-3 block">Aperçu de la mosaïque</Label>
                  <div 
                    className="grid gap-1 p-4 bg-slate-100 rounded-lg inline-block"
                    style={{
                      gridTemplateColumns: `repeat(${mosaicInfo.cols}, 1fr)`,
                      maxWidth: '300px'
                    }}
                  >
                    {Array.from({ length: mosaicInfo.totalPages }).map((_, idx) => {
                      const col = (idx % mosaicInfo.cols) + 1;
                      const row = Math.floor(idx / mosaicInfo.cols) + 1;
                      
                      return (
                        <div
                          key={idx}
                          className={cn(
                            "border-2 rounded flex items-center justify-center text-[10px] font-medium",
                            idx === 0 
                              ? "bg-slate-900 text-white border-slate-900" 
                              : "bg-white text-slate-600 border-slate-300"
                          )}
                          style={{ 
                            aspectRatio: '10/14',
                            width: '30px'
                          }}
                          title="Format portrait (1:1.4)"
                        >
                          C{col}L{row}
                        </div>
                      );
                    })}
                  </div>
                  <p className="text-xs text-slate-500 mt-3">
                    Cette légende sera ajoutée automatiquement dans un coin de votre PDF exporté 
                    pour rappeler la structure de la mosaïque (comme sur les modèles professionnels).
                  </p>
                </div>

                {/* Infos récapitulatives */}
                <div className="flex-1 bg-slate-50 rounded-lg p-4 space-y-2">
                  <div className="text-sm">
                    <span className="text-slate-600">Grille :</span>{' '}
                    <span className="font-semibold text-slate-900">{selectedSize} × {selectedSize}</span>
                  </div>
                  <div className="text-sm">
                    <span className="text-slate-600">Mosaïque :</span>{' '}
                    <span className="font-semibold text-slate-900">
                      {mosaicInfo.cols} × {mosaicInfo.rows} ({mosaicInfo.totalPages} pages)
                    </span>
                  </div>
                  <div className="text-sm">
                    <span className="text-slate-600">Format portrait par page :</span>{' '}
                    <span className="font-semibold text-slate-900">
                      ~{mosaicInfo.pageWidth} × {mosaicInfo.pageHeight} cases
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Annuler
          </Button>
          <Button onClick={handleConfirm} className="bg-slate-900 hover:bg-slate-800">
            Créer la grille
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}