import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  ZoomIn, ZoomOut, Hand, Maximize2, Map,
  Pencil, Eraser, PaintBucket, Square, Copy, Trash2,
  Grid3X3, Layers, Palette, Eye, EyeOff,
  Sparkles, Wand2, RefreshCw, Zap,
  Upload, Download, FileText, Image as ImageIcon,
  X, ChevronDown, Check, Settings2
} from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel,
} from '@/components/ui/dropdown-menu';
import { toast } from 'sonner';

// Catégories d'outils
const TOOL_CATEGORIES = {
  navigation: {
    name: 'Navigation',
    tools: [
      { id: 'zoom-in', icon: ZoomIn, label: 'Zoom +', shortcut: '+' },
      { id: 'zoom-out', icon: ZoomOut, label: 'Zoom –', shortcut: '-' },
      { id: 'pan', icon: Hand, label: 'Déplacement', shortcut: 'H' },
      { id: 'fit', icon: Maximize2, label: 'Plein écran', shortcut: 'F' },
      { id: 'minimap', icon: Map, label: 'Mini-Carte', shortcut: 'M', toggle: true },
    ]
  },
  drawing: {
    name: 'Dessin',
    tools: [
      { id: 'pencil', icon: Pencil, label: 'Crayon', shortcut: 'P' },
      { id: 'eraser', icon: Eraser, label: 'Gomme', shortcut: 'E' },
      { id: 'fill', icon: PaintBucket, label: 'Remplissage', shortcut: 'G' },
      { id: 'select', icon: Square, label: 'Sélection zone', shortcut: 'S' },
      { id: 'duplicate', icon: Copy, label: 'Dupliquer', shortcut: 'D' },
      { id: 'delete-zone', icon: Trash2, label: 'Effacer zone', shortcut: 'Del' },
    ]
  },
  stitches: {
    name: 'Points',
    tools: [
      { id: 'full', icon: '✕', label: 'Point complet', isSymbol: true },
      { id: 'half', icon: '/', label: 'Demi-point', isSymbol: true },
      { id: 'quarter', icon: '·', label: 'Quart de point', isSymbol: true },
      { id: 'backstitch', icon: '—', label: 'Point arrière', isSymbol: true },
      { id: 'bead', icon: '●', label: 'Point perle', isSymbol: true },
      { id: 'sub-zero', icon: Sparkles, label: 'SUB Zero™', special: true },
    ]
  },
  ia: {
    name: 'IA',
    tools: [
      { id: 'recognize', icon: Eye, label: 'Reconnaître symboles' },
      { id: 'repair', icon: Wand2, label: 'Réparer trous' },
      { id: 'harmonize', icon: RefreshCw, label: 'Harmoniser palette' },
      { id: 'convert-sub', icon: Zap, label: 'Conversion SUB™' },
    ]
  },
  display: {
    name: 'Affichage',
    tools: [
      { id: 'show-grid', icon: Grid3X3, label: 'Grille', toggle: true },
      { id: 'mode-symbols', icon: '♦', label: 'Mode symboles', isSymbol: true },
      { id: 'mode-colors', icon: Palette, label: 'Mode couleurs' },
      { id: 'mode-mixed', icon: Layers, label: 'Mode mixte' },
    ]
  },
  io: {
    name: 'Import/Export',
    tools: [
      { id: 'import', icon: Upload, label: 'Importer' },
      { id: 'export-sub', icon: Download, label: 'Export SUB™' },
      { id: 'export-pdf', icon: FileText, label: 'Export PDF' },
      { id: 'export-legend', icon: ImageIcon, label: 'Légende couleurs' },
    ]
  }
};

export default function UnifiedToolbar({
  currentTool,
  onToolSelect,
  onZoomIn,
  onZoomOut,
  onFitView,
  onToggleMinimap,
  showMinimap,
  onToggleGrid,
  showGrid,
  onImport,
  onExportSub,
  onExportPdf,
  onRepairHoles,
  onConvertSub,
  pattern,
  displayMode,
  onDisplayModeChange,
  selectedStitch,
  onStitchSelect,
}) {
  const [activeToggles, setActiveToggles] = useState({
    minimap: showMinimap || false,
    'show-grid': showGrid !== false,
  });

  const hasPattern = !!pattern;

  const handleToolClick = (tool) => {
    // Outils de navigation
    if (tool.id === 'zoom-in') { onZoomIn?.(); return; }
    if (tool.id === 'zoom-out') { onZoomOut?.(); return; }
    if (tool.id === 'fit') { onFitView?.(); return; }
    if (tool.id === 'minimap') {
      setActiveToggles(prev => ({ ...prev, minimap: !prev.minimap }));
      onToggleMinimap?.();
      return;
    }

    // Outils d'affichage
    if (tool.id === 'show-grid') {
      setActiveToggles(prev => ({ ...prev, 'show-grid': !prev['show-grid'] }));
      onToggleGrid?.();
      return;
    }
    if (tool.id === 'mode-symbols') { onDisplayModeChange?.('symbols'); return; }
    if (tool.id === 'mode-colors') { onDisplayModeChange?.('colors'); return; }
    if (tool.id === 'mode-mixed') { onDisplayModeChange?.('mixed'); return; }

    // Outils IA
    if (tool.id === 'repair' || tool.id === 'sub-zero') {
      if (!hasPattern) {
        toast.error('Importez d\'abord une grille');
        return;
      }
      onRepairHoles?.();
      return;
    }
    if (tool.id === 'convert-sub') { onConvertSub?.(); return; }
    if (tool.id === 'harmonize') {
      toast.info('Harmonisation de palette en cours...');
      return;
    }
    if (tool.id === 'recognize') {
      toast.info('Reconnaissance des symboles...');
      return;
    }

    // Import/Export
    if (tool.id === 'import') { onImport?.(); return; }
    if (tool.id === 'export-sub') { onExportSub?.(); return; }
    if (tool.id === 'export-pdf') { onExportPdf?.(); return; }
    if (tool.id === 'export-legend') {
      toast.info('Export de la légende couleurs...');
      return;
    }

    // Types de points
    if (['full', 'half', 'quarter', 'backstitch', 'bead'].includes(tool.id)) {
      onStitchSelect?.(tool.id);
      onToolSelect?.('pencil');
      toast.success(`Point sélectionné : ${tool.label}`);
      return;
    }

    // Outils de dessin
    if (['pencil', 'eraser', 'fill', 'select', 'duplicate', 'delete-zone', 'pan'].includes(tool.id)) {
      onToolSelect?.(tool.id);
      return;
    }
  };

  const isToolActive = (tool) => {
    if (tool.toggle) return activeToggles[tool.id];
    if (['pencil', 'eraser', 'fill', 'select', 'duplicate', 'delete-zone', 'pan'].includes(tool.id)) {
      return currentTool === tool.id;
    }
    if (['full', 'half', 'quarter', 'backstitch', 'bead'].includes(tool.id)) {
      return selectedStitch === tool.id;
    }
    if (tool.id === 'mode-symbols') return displayMode === 'symbols';
    if (tool.id === 'mode-colors') return displayMode === 'colors';
    if (tool.id === 'mode-mixed') return displayMode === 'mixed';
    return false;
  };

  const isToolDisabled = (tool) => {
    // Outils nécessitant une grille
    const needsPattern = ['eraser', 'fill', 'select', 'duplicate', 'delete-zone', 
      'repair', 'sub-zero', 'recognize', 'harmonize', 'convert-sub',
      'export-sub', 'export-pdf', 'export-legend'];
    if (needsPattern.includes(tool.id) && !hasPattern) return true;
    return false;
  };

  const renderTool = (tool) => {
    const isActive = isToolActive(tool);
    const isDisabled = isToolDisabled(tool);
    const Icon = tool.icon;

    return (
      <Tooltip key={tool.id}>
        <TooltipTrigger asChild>
          <button
            onClick={() => handleToolClick(tool)}
            disabled={isDisabled}
            className={`
              w-9 h-9 rounded-md flex items-center justify-center transition-all
              ${isActive 
                ? 'bg-black text-white' 
                : 'bg-white hover:bg-gray-100 text-gray-700'
              }
              ${isDisabled ? 'opacity-40 cursor-not-allowed' : 'cursor-pointer'}
              ${tool.special ? 'bg-gradient-to-br from-yellow-100 to-yellow-200 border border-yellow-400 hover:from-yellow-200 hover:to-yellow-300' : 'border border-gray-200'}
            `}
          >
            {tool.isSymbol ? (
              <span className="text-sm font-bold">{tool.icon}</span>
            ) : (
              <Icon className="w-4 h-4" />
            )}
          </button>
        </TooltipTrigger>
        <TooltipContent side="bottom">
          <p className="font-medium">{tool.label}</p>
          {tool.shortcut && <p className="text-xs text-gray-400">Raccourci : {tool.shortcut}</p>}
          {isDisabled && <p className="text-xs text-orange-500">Nécessite une grille</p>}
        </TooltipContent>
      </Tooltip>
    );
  };

  return (
    <TooltipProvider>
      <div className="bg-white border-b border-gray-200 px-4 py-2 shadow-sm">
        <div className="flex items-center gap-1 justify-center flex-wrap">
          {/* Navigation */}
          <div className="flex items-center gap-0.5 px-2 border-r border-gray-200">
            <span className="text-[10px] text-gray-400 uppercase font-semibold mr-1">Nav</span>
            {TOOL_CATEGORIES.navigation.tools.map(renderTool)}
          </div>

          {/* Dessin */}
          <div className="flex items-center gap-0.5 px-2 border-r border-gray-200">
            <span className="text-[10px] text-gray-400 uppercase font-semibold mr-1">Dessin</span>
            {TOOL_CATEGORIES.drawing.tools.map(renderTool)}
          </div>

          {/* Points */}
          <div className="flex items-center gap-0.5 px-2 border-r border-gray-200">
            <span className="text-[10px] text-gray-400 uppercase font-semibold mr-1">Points</span>
            {TOOL_CATEGORIES.stitches.tools.map(renderTool)}
          </div>

          {/* IA */}
          <div className="flex items-center gap-0.5 px-2 border-r border-gray-200">
            <span className="text-[10px] text-gray-400 uppercase font-semibold mr-1">IA</span>
            {TOOL_CATEGORIES.ia.tools.map(renderTool)}
          </div>

          {/* Affichage */}
          <div className="flex items-center gap-0.5 px-2 border-r border-gray-200">
            <span className="text-[10px] text-gray-400 uppercase font-semibold mr-1">Vue</span>
            {TOOL_CATEGORIES.display.tools.map(renderTool)}
          </div>

          {/* Import/Export */}
          <div className="flex items-center gap-0.5 px-2">
            <span className="text-[10px] text-gray-400 uppercase font-semibold mr-1">I/O</span>
            {TOOL_CATEGORIES.io.tools.map(renderTool)}
          </div>

          {/* Indicateur SUB ZERO */}
          {hasPattern && (
            <div className="ml-4 px-3 py-1 bg-green-50 border border-green-200 rounded-full flex items-center gap-1.5">
              <Check className="w-3.5 h-3.5 text-green-600" />
              <span className="text-xs font-medium text-green-700">SUB ZERO™ actif</span>
            </div>
          )}
        </div>
      </div>
    </TooltipProvider>
  );
}