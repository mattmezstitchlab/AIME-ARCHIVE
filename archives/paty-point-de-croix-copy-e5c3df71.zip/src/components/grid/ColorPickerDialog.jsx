import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Search, Palette } from 'lucide-react';
import { cn } from '@/lib/utils';

// Palette DMC complète
const DMC_COLORS = [
  { code: 'DMC-666', name: 'Rouge vif', hex: '#E3242B' },
  { code: 'DMC-321', name: 'Rouge', hex: '#C1151B' },
  { code: 'DMC-498', name: 'Rouge foncé', hex: '#A90018' },
  { code: 'DMC-816', name: 'Grenat', hex: '#98041C' },
  { code: 'DMC-304', name: 'Rouge moyen', hex: '#BB002D' },
  { code: 'DMC-350', name: 'Corail moyen', hex: '#E84B52' },
  { code: 'DMC-351', name: 'Corail', hex: '#E96A6A' },
  { code: 'DMC-352', name: 'Corail clair', hex: '#F39489' },
  { code: 'DMC-353', name: 'Pêche', hex: '#FCBBA6' },
  { code: 'DMC-400', name: 'Acajou foncé', hex: '#A25835' },
  { code: 'DMC-301', name: 'Acajou moyen', hex: '#BC6534' },
  { code: 'DMC-300', name: 'Acajou très foncé', hex: '#76391E' },
  { code: 'DMC-919', name: 'Rouille', hex: '#B54733' },
  { code: 'DMC-920', name: 'Cuivre moyen', hex: '#C5613B' },
  { code: 'DMC-921', name: 'Cuivre', hex: '#CA6A43' },
  { code: 'DMC-922', name: 'Cuivre clair', hex: '#D88558' },
  { code: 'DMC-945', name: 'Chair', hex: '#F4C3A1' },
  { code: 'DMC-402', name: 'Acajou très clair', hex: '#F39767' },
  { code: 'DMC-743', name: 'Jaune moyen', hex: '#FFE36D' },
  { code: 'DMC-744', name: 'Jaune pâle', hex: '#FFEB9B' },
  { code: 'DMC-725', name: 'Topaze', hex: '#FFD54F' },
  { code: 'DMC-726', name: 'Topaze clair', hex: '#FFDE8F' },
  { code: 'DMC-307', name: 'Citron', hex: '#FFD200' },
  { code: 'DMC-973', name: 'Jaune canari vif', hex: '#FFE12B' },
  { code: 'DMC-444', name: 'Jaune foncé', hex: '#FFD320' },
  { code: 'DMC-445', name: 'Jaune très clair', hex: '#FFFAAD' },
  { code: 'DMC-3078', name: 'Jaune très pâle', hex: '#FFFAE8' },
  { code: 'DMC-727', name: 'Topaze très clair', hex: '#FFFACD' },
  { code: 'DMC-166', name: 'Vert olive moyen', hex: '#A5A044' },
  { code: 'DMC-165', name: 'Vert mousse très clair', hex: '#E4E990' },
  { code: 'DMC-164', name: 'Vert pistache clair', hex: '#B0C47C' },
  { code: 'DMC-989', name: 'Vert prairie', hex: '#87A860' },
  { code: 'DMC-988', name: 'Vert prairie moyen', hex: '#96AE6E' },
  { code: 'DMC-987', name: 'Vert prairie foncé', hex: '#76904E' },
  { code: 'DMC-986', name: 'Vert prairie très foncé', hex: '#5D7337' },
  { code: 'DMC-895', name: 'Vert chasseur très foncé', hex: '#3C5640' },
  { code: 'DMC-704', name: 'Vert chartreuse vif', hex: '#C5CF34' },
  { code: 'DMC-703', name: 'Vert chartreuse', hex: '#B9CA3D' },
  { code: 'DMC-702', name: 'Vert kelly', hex: '#66A345' },
  { code: 'DMC-701', name: 'Vert clair', hex: '#67944B' },
  { code: 'DMC-700', name: 'Vert vif', hex: '#2F7E3C' },
  { code: 'DMC-699', name: 'Vert', hex: '#1F6E36' },
  { code: 'DMC-996', name: 'Bleu électrique moyen', hex: '#40C2CF' },
  { code: 'DMC-995', name: 'Bleu électrique foncé', hex: '#0096AA' },
  { code: 'DMC-3843', name: 'Bleu électrique', hex: '#24B9CE' },
  { code: 'DMC-943', name: 'Vert d\'eau moyen', hex: '#0F8574' },
  { code: 'DMC-992', name: 'Vert d\'eau clair', hex: '#83D0BA' },
  { code: 'DMC-959', name: 'Vert d\'eau moyen', hex: '#8FC8B2' },
  { code: 'DMC-958', name: 'Vert d\'eau foncé', hex: '#50AE93' },
  { code: 'DMC-3761', name: 'Bleu ciel très clair', hex: '#CFEEF5' },
  { code: 'DMC-519', name: 'Bleu ciel', hex: '#A7CFDC' },
  { code: 'DMC-518', name: 'Bleu aqua clair', hex: '#6BADB7' },
  { code: 'DMC-517', name: 'Bleu foncé', hex: '#1C6D7C' },
  { code: 'DMC-747', name: 'Bleu ciel très pâle', hex: '#E9F5FB' },
  { code: 'DMC-827', name: 'Bleu très pâle', hex: '#C6DBE8' },
  { code: 'DMC-813', name: 'Bleu clair', hex: '#9FBDD6' },
  { code: 'DMC-826', name: 'Bleu moyen', hex: '#66A7CF' },
  { code: 'DMC-825', name: 'Bleu foncé', hex: '#3A75A1' },
  { code: 'DMC-824', name: 'Bleu très foncé', hex: '#1B5278' },
  { code: 'DMC-820', name: 'Bleu royal très foncé', hex: '#163A68' },
  { code: 'DMC-796', name: 'Bleu royal foncé', hex: '#13335B' },
  { code: 'DMC-797', name: 'Bleu royal', hex: '#1A4269' },
  { code: 'DMC-798', name: 'Bleu delft foncé', hex: '#3E5A7C' },
  { code: 'DMC-799', name: 'Bleu delft moyen', hex: '#8FA1BA' },
  { code: 'DMC-800', name: 'Bleu delft pâle', hex: '#CBD7E4' },
  { code: 'DMC-3325', name: 'Bleu bébé clair', hex: '#C5D9ED' },
  { code: 'DMC-3755', name: 'Bleu bébé', hex: '#93ABC4' },
  { code: 'DMC-334', name: 'Bleu moyen', hex: '#6F91BA' },
  { code: 'DMC-322', name: 'Bleu marine très foncé', hex: '#1D2951' },
  { code: 'DMC-312', name: 'Bleu marine très foncé', hex: '#2A3853' },
  { code: 'DMC-803', name: 'Bleu violet ultra foncé', hex: '#342E56' },
  { code: 'DMC-333', name: 'Bleu violet très foncé', hex: '#5A5189' },
  { code: 'DMC-791', name: 'Bleu violet foncé', hex: '#6C5988' },
  { code: 'DMC-792', name: 'Bleu violet moyen', hex: '#8E7BA0' },
  { code: 'DMC-793', name: 'Bleu violet clair', hex: '#B2A1BA' },
  { code: 'DMC-3807', name: 'Bleuet', hex: '#7AA7CA' },
  { code: 'DMC-3841', name: 'Bleu bébé pâle', hex: '#C9DCE8' },
  { code: 'DMC-156', name: 'Bleu lavande moyen', hex: '#8FA1C0' },
  { code: 'DMC-155', name: 'Bleu lavande moyen foncé', hex: '#8790BA' },
  { code: 'DMC-3747', name: 'Bleu pervenche très clair', hex: '#D6DFEF' },
  { code: 'DMC-341', name: 'Bleu lavande clair', hex: '#A9B6D0' },
  { code: 'DMC-340', name: 'Bleu lavande moyen', hex: '#A698C4' },
  { code: 'DMC-333', name: 'Bleu violet très foncé', hex: '#5A5189' },
  { code: 'DMC-208', name: 'Lavande très foncé', hex: '#824F99' },
  { code: 'DMC-209', name: 'Lavande foncé', hex: '#976CAD' },
  { code: 'DMC-210', name: 'Lavande moyen', hex: '#C19FCB' },
  { code: 'DMC-211', name: 'Lavande clair', hex: '#DCC3D9' },
  { code: 'DMC-554', name: 'Lilas clair', hex: '#DCC2E0' },
  { code: 'DMC-553', name: 'Lilas', hex: '#A57DB1' },
  { code: 'DMC-552', name: 'Lilas moyen', hex: '#97488F' },
  { code: 'DMC-550', name: 'Lilas très foncé', hex: '#632C61' },
  { code: 'DMC-718', name: 'Prune', hex: '#B4356C' },
  { code: 'DMC-917', name: 'Prune foncé', hex: '#8C2A51' },
  { code: 'DMC-915', name: 'Prune très foncé', hex: '#7B1E4F' },
  { code: 'DMC-3687', name: 'Mauve', hex: '#D28B9A' },
  { code: 'DMC-3685', name: 'Mauve très foncé', hex: '#7F132D' },
  { code: 'DMC-3726', name: 'Rose antique foncé', hex: '#B27283' },
  { code: 'DMC-3727', name: 'Rose antique clair', hex: '#D69AA5' },
  { code: 'DMC-778', name: 'Rose très clair', hex: '#D9ABAF' },
  { code: 'DMC-3689', name: 'Rose clair', hex: '#F5D1D3' },
  { code: 'DMC-760', name: 'Rose saumon', hex: '#F7B2AF' },
  { code: 'DMC-761', name: 'Rose saumon clair', hex: '#FCCCCA' },
  { code: 'DMC-3716', name: 'Rose très clair', hex: '#FFDDDD' },
  { code: 'DMC-962', name: 'Rose moyen', hex: '#EB8096' },
  { code: 'DMC-961', name: 'Rose foncé', hex: '#D8567C' },
  { code: 'DMC-309', name: 'Rose', hex: '#B3345D' },
  { code: 'DMC-899', name: 'Rose', hex: '#EC6C89' },
  { code: 'DMC-335', name: 'Rose', hex: '#E53E70' },
  { code: 'DMC-326', name: 'Rose très foncé', hex: '#C8235B' },
  { code: 'DMC-3708', name: 'Rose fuchsia clair', hex: '#F387AE' },
  { code: 'DMC-3806', name: 'Rose fuchsia', hex: '#F05B98' },
  { code: 'DMC-3805', name: 'Rose fuchsia', hex: '#E8428B' },
  { code: 'DMC-B5200', name: 'Blanc neige', hex: '#FFFFFF' },
  { code: 'DMC-WHITE', name: 'Blanc', hex: '#FFFFFF' },
  { code: 'DMC-ECRU', name: 'Écru', hex: '#F2E7D0' },
  { code: 'DMC-822', name: 'Beige gris clair', hex: '#DFD3BC' },
  { code: 'DMC-644', name: 'Beige moyen', hex: '#D2C5B0' },
  { code: 'DMC-642', name: 'Beige gris foncé', hex: '#B5A585' },
  { code: 'DMC-640', name: 'Beige gris très foncé', hex: '#8E7E68' },
  { code: 'DMC-739', name: 'Beige très clair', hex: '#F1E8D3' },
  { code: 'DMC-738', name: 'Beige clair', hex: '#E3D0B7' },
  { code: 'DMC-437', name: 'Beige', hex: '#D4A974' },
  { code: 'DMC-436', name: 'Beige', hex: '#C5874E' },
  { code: 'DMC-435', name: 'Beige très clair', hex: '#A16F3C' },
  { code: 'DMC-434', name: 'Marron clair', hex: '#956A3E' },
  { code: 'DMC-433', name: 'Marron moyen', hex: '#7A4F2D' },
  { code: 'DMC-801', name: 'Café foncé', hex: '#653926' },
  { code: 'DMC-898', name: 'Café très foncé', hex: '#4E2B1C' },
  { code: 'DMC-938', name: 'Café ultra foncé', hex: '#3A1D14' },
  { code: 'DMC-3371', name: 'Noir marron', hex: '#2B1410' },
  { code: 'DMC-310', name: 'Noir', hex: '#000000' },
  { code: 'DMC-3799', name: 'Gris étain très foncé', hex: '#51565A' },
  { code: 'DMC-413', name: 'Gris étain foncé', hex: '#696866' },
  { code: 'DMC-414', name: 'Gris étain', hex: '#A19B97' },
  { code: 'DMC-168', name: 'Étain très clair', hex: '#C7C8CA' },
  { code: 'DMC-762', name: 'Gris perle très clair', hex: '#E8E8E8' },
  { code: 'DMC-415', name: 'Gris perle', hex: '#CFCDC9' },
  { code: 'DMC-318', name: 'Gris acier clair', hex: '#ABACAE' },
  { code: 'DMC-317', name: 'Gris étain', hex: '#8A8B8E' },
];

export default function ColorPickerDialog({ 
  open, 
  onClose, 
  onSelectColor,
  currentColor 
}) {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredColors = DMC_COLORS.filter(color =>
    color.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    color.code.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Palette className="w-5 h-5" />
            Choisir une couleur DMC
          </DialogTitle>
        </DialogHeader>

        {/* Recherche */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input
            placeholder="Rechercher une couleur..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>

        {/* Grille de couleurs */}
        <div className="flex-1 overflow-y-auto">
          <div className="grid grid-cols-6 gap-2 p-2">
            {filteredColors.map((color) => {
              const isSelected = currentColor?.hex === color.hex;
              
              return (
                <button
                  key={color.code}
                  onClick={() => {
                    onSelectColor(color);
                    onClose();
                  }}
                  className={cn(
                    "flex flex-col items-center gap-2 p-2 rounded-lg border-2 transition-all hover:shadow-lg",
                    isSelected 
                      ? "border-purple-500 bg-purple-50 ring-2 ring-purple-200" 
                      : "border-slate-200 hover:border-slate-300"
                  )}
                >
                  <div
                    className="w-full h-12 rounded border border-slate-300"
                    style={{ backgroundColor: color.hex }}
                  />
                  <div className="text-center">
                    <div className="text-xs font-semibold text-slate-900">
                      {color.code.replace('DMC-', '')}
                    </div>
                    <div className="text-[10px] text-slate-600 line-clamp-2">
                      {color.name}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}