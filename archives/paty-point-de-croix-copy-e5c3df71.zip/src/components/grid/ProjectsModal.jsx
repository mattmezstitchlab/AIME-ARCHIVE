import React, { useState, useRef, useEffect } from 'react';
import { X, FolderOpen, Clock, Calendar, PlayCircle, CheckCircle, Star, Trash2, Pencil, Eye, Type, MoreVertical, Loader2, Grid3X3, Upload, ChevronRight, Palette, Plus } from 'lucide-react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

const FILTERS = [
  { id: 'all', label: 'Tous les projets', icon: FolderOpen, color: '#FFC94A' },
  { id: 'recent', label: 'Récents', icon: Clock, color: '#3B82F6' },
  { id: 'in_progress', label: 'En cours', icon: PlayCircle, color: '#F59E0B' },
  { id: 'completed', label: 'Terminés', icon: CheckCircle, color: '#10B981' },
  { id: 'favorites', label: 'Favoris', icon: Star, color: '#EF4444' },
];

// Composant miniature pour afficher un aperçu du projet
function ProjectThumbnail({ project, size = 80 }) {
  const canvasRef = useRef(null);

  useEffect(() => {
    if (!canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const pattern = project.pattern;

    ctx.fillStyle = '#1a1a1a';
    ctx.fillRect(0, 0, size, size);

    if (pattern?.source_image) {
      const img = new Image();
      img.onload = () => {
        ctx.drawImage(img, 0, 0, size, size);
      };
      img.src = pattern.source_image;
      return;
    }

    if (!pattern?.symbolGrid) {
      ctx.fillStyle = '#333';
      ctx.font = `${size/3}px sans-serif`;
      ctx.textAlign = 'center';
      ctx.fillText('?', size/2, size/2 + size/8);
      return;
    }

    const grid = pattern.symbolGrid;
    const rows = grid.length;
    const cols = grid[0]?.length || 0;
    if (rows === 0 || cols === 0) return;

    const cellSize = Math.min(size / cols, size / rows, 4);
    const offsetX = (size - cols * cellSize) / 2;
    const offsetY = (size - rows * cellSize) / 2;

    for (let row = 0; row < rows; row++) {
      for (let col = 0; col < cols; col++) {
        const cell = grid[row]?.[col];
        if (cell?.color) {
          ctx.fillStyle = cell.color;
          ctx.fillRect(
            offsetX + col * cellSize,
            offsetY + row * cellSize,
            cellSize,
            cellSize
          );
        }
      }
    }
  }, [project, size]);

  return (
    <canvas
      ref={canvasRef}
      width={size}
      height={size}
      className="rounded-lg flex-shrink-0"
    />
  );
}

// Calcul du statut du projet
function getProjectStatus(project) {
  const grid = project.pattern?.symbolGrid;
  if (!grid) return null;
  const total = grid.flat().filter(c => c).length;
  const done = grid.flat().filter(c => c?.done).length;
  if (total === 0) return null;
  if (done === total) return 'completed';
  return 'in_progress';
}

// Calcul du pourcentage de progression
function getProjectProgress(project) {
  const grid = project.pattern?.symbolGrid;
  if (!grid) return 0;
  const total = grid.flat().filter(c => c).length;
  const done = grid.flat().filter(c => c?.done).length;
  if (total === 0) return 0;
  return Math.round((done / total) * 100);
}

export default function ProjectsModal({ open, onClose, onImport }) {
  const [selectedFilter, setSelectedFilter] = useState(FILTERS[0]);
  const [favorites, setFavorites] = useState(() => {
    const saved = localStorage.getItem('broodway_project_favorites');
    return saved ? JSON.parse(saved) : [];
  });
  const [renameId, setRenameId] = useState(null);
  const [renameValue, setRenameValue] = useState('');
  const [deleteProject, setDeleteProject] = useState(null);
  const queryClient = useQueryClient();

  // Charger les projets
  const { data: projects = [], isLoading } = useQuery({
    queryKey: ['grids'],
    queryFn: () => base44.entities.Grid.list('-updated_date'),
    enabled: open,
  });

  // Mutation pour supprimer
  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Grid.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['grids'] });
      toast.success('Projet supprimé');
    },
  });

  // Mutation pour renommer
  const renameMutation = useMutation({
    mutationFn: ({ id, name }) => base44.entities.Grid.update(id, { name }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['grids'] });
      toast.success('Projet renommé');
      setRenameId(null);
    },
  });

  // Sauvegarder les favoris
  useEffect(() => {
    localStorage.setItem('broodway_project_favorites', JSON.stringify(favorites));
  }, [favorites]);

  const toggleFavorite = (projectId) => {
    setFavorites(prev => 
      prev.includes(projectId) 
        ? prev.filter(id => id !== projectId)
        : [...prev, projectId]
    );
    toast.success(favorites.includes(projectId) ? 'Retiré des favoris' : 'Ajouté aux favoris');
  };

  const handleRename = (project) => {
    setRenameId(project.id);
    setRenameValue(project.name || '');
  };

  const submitRename = () => {
    if (renameId && renameValue.trim()) {
      renameMutation.mutate({ id: renameId, name: renameValue.trim() });
    }
  };

  const handleDelete = (project) => {
    setDeleteProject(project);
  };

  const confirmDelete = () => {
    if (deleteProject) {
      deleteMutation.mutate(deleteProject.id);
      setDeleteProject(null);
    }
  };

  const handleOpenProject = (project) => {
    localStorage.setItem('loadProjectId', project.id);
    window.location.reload();
  };

  // Filtrer les projets
  const filteredProjects = React.useMemo(() => {
    let result = [...projects];

    switch (selectedFilter.id) {
      case 'recent':
        result.sort((a, b) => new Date(b.updated_date) - new Date(a.updated_date));
        result = result.slice(0, 10);
        break;
      case 'in_progress':
        result = result.filter(p => {
          const status = getProjectStatus(p);
          return status === 'in_progress' || status === null;
        });
        break;
      case 'completed':
        result = result.filter(p => getProjectStatus(p) === 'completed');
        break;
      case 'favorites':
        result = result.filter(p => favorites.includes(p.id));
        break;
      default:
        result.sort((a, b) => new Date(b.updated_date) - new Date(a.updated_date));
    }

    return result;
  }, [projects, selectedFilter, favorites]);

  return (
    <>
      {/* Dialog de confirmation de suppression */}
      <AlertDialog open={!!deleteProject} onOpenChange={() => setDeleteProject(null)}>
        <AlertDialogContent className="bg-[#1a1a1a] border-[#333]">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-white flex items-center gap-2">
              <Trash2 className="w-5 h-5 text-red-500" />
              Supprimer ce projet ?
            </AlertDialogTitle>
            <AlertDialogDescription className="text-gray-400">
              Le projet "{deleteProject?.name || 'Sans titre'}" sera définitivement supprimé.
              Cette action est irréversible.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-white/10 text-white border-0 hover:bg-white/20">
              Annuler
            </AlertDialogCancel>
            <AlertDialogAction 
              onClick={confirmDelete}
              className="bg-red-600 text-white hover:bg-red-700"
            >
              Supprimer
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Dialog open={open} onOpenChange={onClose}>
        <DialogContent className="w-[95vw] max-w-4xl h-[90vh] md:h-[80vh] p-0 bg-[#0a0a0a] border-[#222] overflow-hidden">
          {/* Header */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-[#222] bg-gradient-to-r from-[#FFC94A]/10 to-[#F97316]/10">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#FFC94A] to-[#F97316] flex items-center justify-center">
                <FolderOpen className="w-5 h-5 text-black" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-white">Mes Projets</h2>
                <p className="text-xs text-gray-400">{projects.length} projet{projects.length > 1 ? 's' : ''}</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-lg bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors"
            >
              <X className="w-4 h-4 text-white" />
            </button>
          </div>

          <div className="flex flex-col md:flex-row h-[calc(100%-72px)]">
            {/* Sidebar filtres */}
            <div className="w-full md:w-64 border-b md:border-b-0 md:border-r border-[#222] p-3 md:p-4 overflow-x-auto md:overflow-y-auto flex-shrink-0">
              <div className="flex md:flex-col gap-2 md:space-y-0 overflow-x-auto md:overflow-x-visible pb-2 md:pb-0">
                {FILTERS.map((filter) => (
                  <button
                    key={filter.id}
                    onClick={() => setSelectedFilter(filter)}
                    className={`flex-shrink-0 px-3 md:px-4 py-2 md:py-3 rounded-xl flex items-center gap-2 md:gap-3 transition-all whitespace-nowrap ${
                      selectedFilter.id === filter.id
                        ? 'bg-white/10 border border-white/20'
                        : 'hover:bg-white/5'
                    }`}
                  >
                    <filter.icon className="w-4 h-4 md:w-5 md:h-5" style={{ color: filter.color }} />
                    <span className="text-xs md:text-sm font-medium text-white">{filter.label}</span>
                  </button>
                ))}
              </div>

              {/* Bouton Nouveau projet */}
              <div className="hidden md:block mt-6 pt-6 border-t border-[#222]">
                <button
                  onClick={() => {
                    onClose();
                    if (onImport) onImport();
                  }}
                  className="w-full px-4 py-3 rounded-xl font-semibold flex items-center justify-center gap-2 transition-all bg-gradient-to-r from-[#FFC94A] to-[#F59E0B] text-black hover:opacity-90"
                >
                  <Plus className="w-4 h-4" />
                  Nouveau projet
                </button>
                <p className="text-[10px] text-gray-500 text-center mt-2">
                  Importez une image pour créer un nouveau projet
                </p>
              </div>
            </div>

            {/* Contenu principal */}
            <div className="flex-1 p-4 md:p-6 overflow-y-auto">
              {isLoading ? (
                <div className="flex items-center justify-center py-12">
                  <Loader2 className="w-8 h-8 animate-spin text-[#FFC94A]" />
                </div>
              ) : filteredProjects.length === 0 ? (
                <div className="text-center py-12">
                  {selectedFilter.id === 'favorites' ? (
                    <div className="text-gray-500">
                      <Star className="w-12 h-12 mx-auto mb-4 opacity-30" />
                      <p>Aucun favori pour le moment</p>
                      <p className="text-xs mt-2">Cliquez sur ⭐ pour ajouter des projets</p>
                    </div>
                  ) : selectedFilter.id === 'completed' ? (
                    <div className="text-gray-500">
                      <CheckCircle className="w-12 h-12 mx-auto mb-4 opacity-30" />
                      <p>Aucun projet terminé</p>
                      <p className="text-xs mt-2">Continuez à broder !</p>
                    </div>
                  ) : (
                    <div className="text-gray-500">
                      <Grid3X3 className="w-12 h-12 mx-auto mb-4 opacity-30" />
                      <p>Aucun projet trouvé</p>
                      <button
                        onClick={() => {
                          onClose();
                          if (onImport) onImport();
                        }}
                        className="mt-4 px-4 py-2 bg-[#FFC94A] hover:bg-[#FFD666] text-black text-sm font-semibold rounded-lg transition-colors"
                      >
                        Créer un projet
                      </button>
                    </div>
                  )}
                </div>
              ) : (
                <>
                  {/* Bannière d'accueil (seulement pour "Tous les projets") */}
                  {selectedFilter.id === 'all' && (
                    <div className="relative rounded-2xl overflow-hidden bg-gradient-to-r from-[#FFC94A] to-[#F97316] p-6 mb-6">
                      <div className="relative z-10">
                        <h3 className="text-2xl font-bold text-black mb-2">Vos créations</h3>
                        <p className="text-black/70 text-sm max-w-md">
                          Retrouvez tous vos projets de broderie. Cliquez sur un projet pour continuer à broder.
                        </p>
                      </div>
                      <div className="absolute right-4 bottom-4 opacity-20">
                        <Palette className="w-32 h-32 text-black" />
                      </div>
                    </div>
                  )}

                  {/* Grille des projets */}
                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-4">
                    {filteredProjects.map((project) => {
                      const status = getProjectStatus(project);
                      const progress = getProjectProgress(project);
                      
                      return (
                        <div
                          key={project.id}
                          onClick={() => handleOpenProject(project)}
                          className="bg-[#1a1a1a] rounded-xl overflow-hidden border border-[#333] hover:border-[#FFC94A]/50 transition-all cursor-pointer group"
                        >
                          {/* Vignette */}
                          <div className="aspect-square bg-[#222] flex items-center justify-center overflow-hidden relative">
                            {project.pattern?.source_image ? (
                              <img 
                                src={project.pattern.source_image} 
                                alt={project.name}
                                className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                              />
                            ) : (
                              <ProjectThumbnail project={project} size={150} />
                            )}
                            
                            {/* Overlay au hover */}
                            <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                              <div className="px-4 py-2 bg-[#FFC94A] rounded-lg text-black text-sm font-semibold flex items-center gap-2">
                                <Pencil className="w-4 h-4" />
                                Ouvrir
                              </div>
                            </div>

                            {/* Badge statut */}
                            {status && (
                              <div className="absolute top-2 left-2">
                                {status === 'completed' ? (
                                  <span className="px-2 py-1 bg-green-500/90 text-white text-[10px] font-medium rounded-full flex items-center gap-1">
                                    <CheckCircle className="w-3 h-3" />
                                    Terminé
                                  </span>
                                ) : (
                                  <span className="px-2 py-1 bg-blue-500/90 text-white text-[10px] font-medium rounded-full flex items-center gap-1">
                                    <PlayCircle className="w-3 h-3" />
                                    {progress}%
                                  </span>
                                )}
                              </div>
                            )}
                          </div>

                          {/* Infos */}
                          <div className="p-3">
                            <div className="flex items-start justify-between gap-2">
                              <div className="min-w-0 flex-1">
                                {renameId === project.id ? (
                                  <input
                                    type="text"
                                    value={renameValue}
                                    onChange={(e) => setRenameValue(e.target.value)}
                                    onBlur={submitRename}
                                    onKeyDown={(e) => {
                                      if (e.key === 'Enter') submitRename();
                                      if (e.key === 'Escape') setRenameId(null);
                                    }}
                                    onClick={(e) => e.stopPropagation()}
                                    className="w-full bg-white/10 border border-[#FFC94A] rounded px-2 py-1 text-sm text-white focus:outline-none"
                                    autoFocus
                                  />
                                ) : (
                                  <h5 className="text-sm font-medium text-white truncate">
                                    {project.name || 'Sans titre'}
                                  </h5>
                                )}
                                <p className="text-xs text-gray-500 mt-1">
                                  {new Date(project.updated_date).toLocaleDateString('fr-FR', {
                                    day: 'numeric',
                                    month: 'short'
                                  })}
                                </p>
                              </div>

                              <div className="flex items-center gap-1">
                                {/* Bouton favoris */}
                                <button 
                                  onClick={(e) => { e.stopPropagation(); toggleFavorite(project.id); }}
                                  className="p-1 hover:bg-white/10 rounded transition-colors"
                                >
                                  <Star className={`w-4 h-4 transition-colors ${favorites.includes(project.id) ? 'text-yellow-500 fill-yellow-500' : 'text-gray-500 hover:text-yellow-500'}`} />
                                </button>

                                {/* Menu actions */}
                                <DropdownMenu>
                                  <DropdownMenuTrigger asChild>
                                    <button 
                                      onClick={(e) => e.stopPropagation()}
                                      className="p-1 hover:bg-white/10 rounded-lg transition-colors"
                                    >
                                      <MoreVertical className="w-4 h-4 text-gray-400" />
                                    </button>
                                  </DropdownMenuTrigger>
                                  <DropdownMenuContent 
                                    align="end" 
                                    className="w-40 bg-[#222] border-[#444] rounded-lg z-[600]"
                                  >
                                    <DropdownMenuItem
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        handleOpenProject(project);
                                      }}
                                      className="text-white hover:bg-white/10 cursor-pointer"
                                    >
                                      <Pencil className="w-4 h-4 mr-2 text-green-400" />
                                      Ouvrir
                                    </DropdownMenuItem>
                                    <DropdownMenuItem
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        handleRename(project);
                                      }}
                                      className="text-white hover:bg-white/10 cursor-pointer"
                                    >
                                      <Type className="w-4 h-4 mr-2 text-yellow-400" />
                                      Renommer
                                    </DropdownMenuItem>
                                    <DropdownMenuSeparator className="bg-[#444]" />
                                    <DropdownMenuItem
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        handleDelete(project);
                                      }}
                                      className="text-red-400 hover:bg-red-500/10 cursor-pointer"
                                    >
                                      <Trash2 className="w-4 h-4 mr-2" />
                                      Supprimer
                                    </DropdownMenuItem>
                                  </DropdownMenuContent>
                                </DropdownMenu>
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}