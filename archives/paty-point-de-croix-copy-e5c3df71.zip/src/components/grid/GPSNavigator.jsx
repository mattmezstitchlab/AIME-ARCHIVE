import React, { useState } from 'react';
import { Compass, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

// Convertir un numéro de ligne en lettre (0 -> A, 26 -> AA, etc.)
function rowToLetter(row) {
  let result = '';
  let num = row;
  while (num >= 0) {
    result = String.fromCharCode(65 + (num % 26)) + result;
    num = Math.floor(num / 26) - 1;
  }
  return result;
}

export default function GPSNavigator({
  gridConfig,
  pattern,
  onNavigate,
}) {
  const [isOpen, setIsOpen] = useState(false);
  const [inputX, setInputX] = useState('');
  const [inputY, setInputY] = useState('');

  const handleOpen = () => {
    setIsOpen(true);
    setInputX('');
    setInputY('');
  };

  const handleClose = () => {
    setIsOpen(false);
  };

  const handleGo = () => {
    const col = parseInt(inputX, 10);
    const row = parseInt(inputY, 10);

    if (isNaN(col) || isNaN(row) || col < 1 || row < 1) {
      return;
    }

    // Convertir en 0-indexed
    const targetCol = col - 1;
    const targetRow = row - 1;

    // Appeler la fonction de navigation
    onNavigate?.(targetCol, targetRow);
    
    // Fermer le mode GPS
    setIsOpen(false);
  };

  const maxCol = pattern?.width || gridConfig?.nb_colonnes || 100;
  const maxRow = pattern?.height || gridConfig?.nb_lignes || 100;

  return (
    <>
      {/* Bouton GPS - Toujours visible */}
      <button
        onClick={handleOpen}
        style={{
          position: 'absolute',
          top: '16px',
          left: '16px',
          width: '48px',
          height: '48px',
          backgroundColor: '#000',
          borderRadius: '8px',
          border: 'none',
          cursor: 'pointer',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 50,
          boxShadow: '0 2px 8px rgba(0,0,0,0.3)',
        }}
      >
        <Compass className="w-6 h-6 text-white" />
      </button>

      {/* Mode GPS activé */}
      {isOpen && (
        <>
          {/* Overlay sombre */}
          <div
            style={{
              position: 'fixed',
              inset: 0,
              backgroundColor: 'rgba(0,0,0,0.5)',
              zIndex: 9998,
            }}
            onClick={handleClose}
          />

          {/* Barre horizontale noire - Colonnes */}
          <div
            style={{
              position: 'fixed',
              top: '60px',
              left: 0,
              right: 0,
              height: '32px',
              backgroundColor: '#000',
              zIndex: 9999,
              display: 'flex',
              alignItems: 'center',
              overflow: 'hidden',
              paddingLeft: '48px',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center' }}>
              {Array.from({ length: Math.min(maxCol, 50) }, (_, i) => (
                <div
                  key={i}
                  style={{
                    width: '32px',
                    height: '32px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: '#fff',
                    fontSize: '10px',
                    fontWeight: 600,
                    borderRight: '1px solid #333',
                  }}
                >
                  {i + 1}
                </div>
              ))}
              {maxCol > 50 && (
                <div style={{ color: '#888', fontSize: '10px', padding: '0 8px' }}>
                  ... → {maxCol}
                </div>
              )}
            </div>
          </div>

          {/* Barre verticale noire - Lignes */}
          <div
            style={{
              position: 'fixed',
              top: '92px',
              left: 0,
              bottom: 0,
              width: '48px',
              backgroundColor: '#000',
              zIndex: 9999,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              overflow: 'hidden',
              paddingTop: '8px',
            }}
          >
            {Array.from({ length: Math.min(maxRow, 30) }, (_, i) => (
              <div
                key={i}
                style={{
                  width: '48px',
                  height: '24px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  color: '#fff',
                  fontSize: '10px',
                  fontWeight: 600,
                  borderBottom: '1px solid #333',
                }}
              >
                {rowToLetter(i)}{i + 1}
              </div>
            ))}
            {maxRow > 30 && (
              <div style={{ color: '#888', fontSize: '10px', padding: '8px 0' }}>
                ↓ {maxRow}
              </div>
            )}
          </div>

          {/* Panneau GPS central */}
          <div
            style={{
              position: 'fixed',
              top: '50%',
              left: '50%',
              transform: 'translate(-50%, -50%)',
              backgroundColor: '#fff',
              borderRadius: '16px',
              padding: '24px',
              zIndex: 10000,
              minWidth: '300px',
              boxShadow: '0 8px 32px rgba(0,0,0,0.3)',
            }}
          >
            {/* Header */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <Compass className="w-5 h-5 text-black" />
                <h3 style={{ margin: 0, fontSize: '18px', fontWeight: 700, color: '#000' }}>
                  Coordonnées GPS
                </h3>
              </div>
              <button
                onClick={handleClose}
                style={{
                  width: '32px',
                  height: '32px',
                  borderRadius: '8px',
                  border: 'none',
                  backgroundColor: '#f0f0f0',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <X className="w-4 h-4 text-gray-600" />
              </button>
            </div>

            {/* Champs X et Y */}
            <div style={{ display: 'flex', gap: '12px', marginBottom: '20px' }}>
              <div style={{ flex: 1 }}>
                <Label style={{ fontSize: '12px', color: '#666', marginBottom: '6px', display: 'block' }}>
                  X (colonne)
                </Label>
                <Input
                  type="number"
                  min={1}
                  max={maxCol}
                  value={inputX}
                  onChange={(e) => setInputX(e.target.value)}
                  placeholder={`1 - ${maxCol}`}
                  style={{
                    fontSize: '16px',
                    padding: '12px',
                    border: '2px solid #e0e0e0',
                    borderRadius: '8px',
                  }}
                />
              </div>
              <div style={{ flex: 1 }}>
                <Label style={{ fontSize: '12px', color: '#666', marginBottom: '6px', display: 'block' }}>
                  Y (ligne)
                </Label>
                <Input
                  type="number"
                  min={1}
                  max={maxRow}
                  value={inputY}
                  onChange={(e) => setInputY(e.target.value)}
                  placeholder={`1 - ${maxRow}`}
                  style={{
                    fontSize: '16px',
                    padding: '12px',
                    border: '2px solid #e0e0e0',
                    borderRadius: '8px',
                  }}
                />
              </div>
            </div>

            {/* Boutons */}
            <div style={{ display: 'flex', gap: '12px' }}>
              <Button
                onClick={handleClose}
                style={{
                  flex: 1,
                  height: '48px',
                  backgroundColor: '#f0f0f0',
                  color: '#333',
                  border: 'none',
                  borderRadius: '8px',
                  fontSize: '14px',
                  fontWeight: 600,
                  cursor: 'pointer',
                }}
              >
                Fermer
              </Button>
              <Button
                onClick={handleGo}
                disabled={!inputX || !inputY}
                style={{
                  flex: 1,
                  height: '48px',
                  backgroundColor: '#000',
                  color: '#fff',
                  border: 'none',
                  borderRadius: '8px',
                  fontSize: '14px',
                  fontWeight: 600,
                  cursor: 'pointer',
                  opacity: (!inputX || !inputY) ? 0.5 : 1,
                }}
              >
                Aller
              </Button>
            </div>
          </div>
        </>
      )}
    </>
  );
}