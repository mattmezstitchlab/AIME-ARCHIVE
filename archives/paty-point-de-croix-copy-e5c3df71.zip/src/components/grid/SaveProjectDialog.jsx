import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Save, Palette, Grid3X3, Tag } from 'lucide-react';

const THEMES = [
  { id: 'nature', label: 'Nature', color: '#22C55E' },
  { id: 'animaux', label: 'Animaux', color: '#F59E0B' },
  { id: 'fleurs', label: 'Fleurs', color: '#EC4899' },
  { id: 'noel', label: 'Noël', color: '#EF4444' },
  { id: 'paques', label: 'Pâques', color: '#A855F7' },
  { id: 'abstrait', label: 'Abstrait', color: '#3B82F6' },
  { id: 'portrait', label: 'Portrait', color: '#6366F1' },
  { id: 'paysage', label: 'Paysage', color: '#14B8A6' },
  { id: 'enfant', label: 'Enfant', color: '#F472B6' },
  { id: 'autre', label: 'Autre', color: '#71717A' },
];

const DIFFICULTY = [
  { id: 'debutant', label: 'Débutant', icon: '⭐' },
  { id: 'intermediaire', label: 'Intermédiaire', icon: '⭐⭐' },
  { id: 'avance', label: 'Avancé', icon: '⭐⭐⭐' },
  { id: 'expert', label: 'Expert', icon: '⭐⭐⭐⭐' },
];

export default function SaveProjectDialog({ open, onClose, onSave, pattern, gridConfig, currentProjectId }) {
  const [name, setName] = useState('');
  const [theme, setTheme] = useState('autre');
  const [difficulty, setDifficulty] = useState('debutant');
  const [notes, setNotes] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  // Pré-remplir avec les infos existantes
  useEffect(() => {
    if (open) {
      setName(gridConfig?.name || 'Mon projet');
    }
  }, [open, gridConfig]);

  const handleSave = async () => {
    if (!name.trim()) return;

    setIsSaving(true);
    try {
      await onSave({
        name: name.trim(),
        theme,
        difficulty,
        notes: notes.trim(),
      });
      onClose();
    } catch (error) {
      console.error('Erreur sauvegarde:', error);
    } finally {
      setIsSaving(false);
    }
  };

  const patternInfo = pattern ? {
    width: pattern.width,
    height: pattern.height,
    colors: pattern.colorPalette?.length || 0,
  } : null;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Save className="w-5 h-5" />
            {currentProjectId ? 'Mettre à jour le projet' : 'Sauvegarder le projet'}
          </DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-2 gap-6 py-2">
          {/* Colonne gauche */}
          <div className="space-y-4">
            {/* Nom du projet */}
            <div className="space-y-2">
              <Label htmlFor="project-name">Nom du projet</Label>
              <Input
                id="project-name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Mon projet broderie"
                className="text-base"
              />
            </div>

            {/* Thème */}
            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <Tag className="w-4 h-4" />
                Thème
              </Label>
              <div className="grid grid-cols-5 gap-2">
                {THEMES.map((t) => (
                  <button
                    key={t.id}
                    onClick={() => setTheme(t.id)}
                    className={`flex flex-col items-center gap-1 p-2 rounded-lg border-2 transition-all ${
                      theme === t.id
                        ? 'border-black bg-gray-100'
                        : 'border-transparent bg-gray-50 hover:bg-gray-100'
                    }`}
                  >
                    <div
                      className="w-6 h-6 rounded-full"
                      style={{ backgroundColor: t.color }}
                    />
                    <span className="text-[10px] font-medium text-center leading-tight">
                      {t.label}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Difficulté */}
            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <Palette className="w-4 h-4" />
                Niveau de difficulté
              </Label>
              <div className="grid grid-cols-4 gap-2">
                {DIFFICULTY.map((d) => (
                  <button
                    key={d.id}
                    onClick={() => setDifficulty(d.id)}
                    className={`flex flex-col items-center gap-1 p-2 rounded-lg border-2 transition-all ${
                      difficulty === d.id
                        ? 'border-black bg-gray-100'
                        : 'border-transparent bg-gray-50 hover:bg-gray-100'
                    }`}
                  >
                    <span className="text-sm">{d.icon}</span>
                    <span className="text-[10px] font-medium">{d.label}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Colonne droite */}
          <div className="space-y-4">
            {/* Notes */}
            <div className="space-y-2">
              <Label htmlFor="notes">Notes (optionnel)</Label>
              <Textarea
                id="notes"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Ajoutez des notes personnelles..."
                className="h-32 resize-none"
              />
            </div>

            {/* Infos pattern */}
            {patternInfo && (
              <div className="flex items-center gap-4 p-3 bg-gray-50 rounded-lg text-sm text-gray-600">
                <div className="flex items-center gap-1">
                  <Grid3X3 className="w-4 h-4" />
                  <span>{patternInfo.width} × {patternInfo.height}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Palette className="w-4 h-4" />
                  <span>{patternInfo.colors} couleurs</span>
                </div>
              </div>
            )}

            {/* Actions */}
            <div className="flex gap-3 pt-4">
              <Button variant="outline" onClick={onClose} className="flex-1">
                Annuler
              </Button>
              <Button
                onClick={handleSave}
                disabled={!name.trim() || isSaving}
                className="flex-1 bg-black hover:bg-gray-800"
              >
                {isSaving ? 'Sauvegarde...' : currentProjectId ? 'Mettre à jour' : 'Sauvegarder'}
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}