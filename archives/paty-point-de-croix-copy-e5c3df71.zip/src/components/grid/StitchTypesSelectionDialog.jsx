import React, { useState } from 'react';
import { 
  Dialog,
  DialogContent 
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Input } from '@/components/ui/input';
import { ArrowLeft, Sparkles, CheckCircle, Lightbulb } from 'lucide-react';
import { cn } from '@/lib/utils';

// Liste fixe des types de points (jamais modifiée)
const STITCH_TYPES_LIST = [
  { id: 'full', name: 'Point de croix complet', desc: 'Base du modèle (1 case = 1 croix)', mandatory: true },
  { id: 'half', name: 'Demi-point', desc: 'Adoucit les dégradés et les fonds' },
  { id: 'quarter', name: 'Points fractionnés (¼ / ¾)', desc: 'Affiner les angles et arrondis' },
  { id: 'backstitch', name: 'Points arrière (Backstitch)', desc: 'Dessiner les contours et les détails' },
  { id: 'frenchknot', name: 'Nœuds français', desc: 'Petits points de lumière ou centres de fleurs' },
  { id: 'bead', name: 'Perles (Beads)', desc: 'Perles décoratives (yeux, bijoux, reflets)' },
  { id: 'metallic', name: 'Fils métalliques', desc: 'Dorures, argent, effets brillants' },
  { id: 'longstitch', name: 'Point long', desc: 'Grandes zones uniformes (cheveux, aplats)' }
];

// Recommandations IA (affichage statique)
const AI_RECOMMENDATIONS = [
  'Zones nettes → Points de croix complets',
  'Fonds doux → Demi-points',
  'Contours importants → Backstitch',
  'Détails fins → Fractionnés (¼ / ¾)',
  'Points de lumière → Nœuds / perles',
  'Effets spéciaux → Métalliques'
];

export default function StitchTypesSelectionDialog({ 
  open, 
  onClose, 
  onConfirm,
  previewImage,
  initialConfig = {}
}) {
  // HOOKS FIXES - TOUJOURS LE MÊME ORDRE - TOUJOURS APPELÉS
  const [selectedTypes, setSelectedTypes] = useState(['full', 'half', 'backstitch']);
  const [autoSuggestionEnabled, setAutoSuggestionEnabled] = useState(true);
  const [modeUtilisation, setModeUtilisation] = useState('debutant');
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Nouveaux états pour les réglages du modèle
  const [gridWidth, setGridWidth] = useState(150);
  const [gridHeight, setGridHeight] = useState(150);
  const [colorCount, setColorCount] = useState(40);
  const [autoOptimization, setAutoOptimization] = useState(true);
  
  // Synchroniser avec initialConfig uniquement au montage
  React.useEffect(() => {
    if (initialConfig.selectedTypes) {
      setSelectedTypes(initialConfig.selectedTypes);
    }
    if (initialConfig.modeUtilisation) {
      setModeUtilisation(initialConfig.modeUtilisation);
    }
    if (initialConfig.gridWidth) {
      setGridWidth(initialConfig.gridWidth);
    }
    if (initialConfig.gridHeight) {
      setGridHeight(initialConfig.gridHeight);
    }
    if (initialConfig.colorCount) {
      setColorCount(initialConfig.colorCount);
    }
  }, []);

  // Gestion du mode (simple mise à jour de state)
  const handleModeChange = (newMode) => {
    setModeUtilisation(newMode);
    if (newMode === 'debutant') {
      setSelectedTypes(['full', 'half', 'backstitch']);
    } else {
      setSelectedTypes(['full', 'half', 'quarter', 'backstitch', 'frenchknot', 'bead', 'metallic']);
    }
  };

  // Toggle type de point
  const handleToggleType = (typeId) => {
    if (typeId === 'full') return; // Point complet obligatoire
    
    setSelectedTypes(prev => 
      prev.includes(typeId)
        ? prev.filter(id => id !== typeId)
        : [...prev, typeId]
    );
  };

  // Ignorer (tout en points de croix)
  const handleSkip = () => {
    const config = {
      selectedTypes: ['full'],
      autoSuggestionEnabled: false,
      modeUtilisation: 'debutant'
    };
    onConfirm?.(config);
    onClose?.();
  };

  // Valider
  const handleValidate = () => {
    setIsSubmitting(true);
    const config = {
      selectedTypes,
      autoSuggestionEnabled,
      modeUtilisation,
      gridWidth,
      gridHeight,
      colorCount,
      autoOptimization
    };
    onConfirm?.(config);
    onClose?.();
  };

  // Ne rien rendre si pas ouvert (évite les hooks conditionnels dans le parent)
  if (!open) return null;
  
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-hidden p-0">
        <div className="flex flex-col h-full">
          {/* En-tête fixe */}
          <div className="flex-shrink-0 bg-white border-b border-slate-200 px-6 py-4">
            <div className="flex items-start justify-between">
              <div>
                <h2 className="text-2xl font-bold text-slate-900">
                  Étape 2 · Préparation du modèle et techniques de broderie
                </h2>
                <p className="text-slate-600 mt-1 text-sm">
                  PatyBee analyse ton visuel et te propose automatiquement la meilleure configuration pour convertir ton image en grille de broderie.
                </p>
              </div>
              <button
                onClick={handleSkip}
                className="text-sm text-slate-500 hover:text-slate-700 underline"
              >
                Ignorer (tout en points de croix simples)
              </button>
            </div>
          </div>

          {/* Contenu scrollable */}
          <div className="flex-1 overflow-y-auto">
            <div className="p-6">
              <div className="grid grid-cols-12 gap-6">
                {/* Colonne 1 - Aperçu + Réglages (4 colonnes) */}
                <div className="col-span-4">
                  <div className="space-y-4">
                    {/* Aperçu */}
                    <div className="bg-white rounded-lg border border-slate-200 p-4">
                      <h3 className="font-semibold text-sm mb-3">🔹 Aperçu du visuel importé</h3>

                      {previewImage && (
                        <div className="rounded-lg overflow-hidden border border-slate-200">
                          <img 
                            src={previewImage} 
                            alt="Aperçu" 
                            className="w-full h-auto"
                          />
                        </div>
                      )}
                    </div>

                    {/* Réglages du modèle */}
                    <div className="bg-white rounded-lg border border-slate-200 p-4 space-y-4">
                      <h3 className="font-semibold text-sm mb-3">Réglages du modèle</h3>

                      {/* Taille de la grille */}
                      <div>
                        <Label className="text-sm font-medium mb-2 block">Taille de la grille</Label>
                        <p className="text-xs text-slate-600 mb-3">
                          Définis la taille finale de ton motif en points
                        </p>

                        <div className="space-y-3">
                          <div>
                            <div className="flex items-center justify-between mb-1">
                              <span className="text-xs text-slate-600">Largeur (points)</span>
                              <span className="text-xs font-medium">{gridWidth}</span>
                            </div>
                            <Slider
                              value={[gridWidth]}
                              onValueChange={(val) => setGridWidth(val[0])}
                              min={50}
                              max={400}
                              step={10}
                              disabled={autoOptimization}
                            />
                          </div>

                          <div>
                            <div className="flex items-center justify-between mb-1">
                              <span className="text-xs text-slate-600">Hauteur (points)</span>
                              <span className="text-xs font-medium">{gridHeight}</span>
                            </div>
                            <Slider
                              value={[gridHeight]}
                              onValueChange={(val) => setGridHeight(val[0])}
                              min={50}
                              max={400}
                              step={10}
                              disabled={autoOptimization}
                            />
                          </div>
                        </div>

                        <div className="mt-2 p-2 bg-blue-50 rounded text-xs text-slate-600">
                          💡 Plus la grille est grande, plus les détails sont précis.
                        </div>
                      </div>

                      {/* Nombre de couleurs */}
                      <div>
                        <Label className="text-sm font-medium mb-2 block">Nombre de couleurs (palette DMC)</Label>
                        <p className="text-xs text-slate-600 mb-3">
                          Sélectionne la complexité du motif
                        </p>

                        <div className="flex items-center gap-3">
                          <Slider
                            value={[colorCount]}
                            onValueChange={(val) => setColorCount(val[0])}
                            min={1}
                            max={90}
                            step={1}
                            className="flex-1"
                            disabled={autoOptimization}
                          />
                          <div className="w-16 text-right">
                            <span className="text-sm font-semibold text-slate-900">{colorCount}</span>
                          </div>
                        </div>

                        <div className="mt-2 text-xs text-slate-600">
                          Couleurs sélectionnées : <span className="font-semibold">{colorCount}</span>
                        </div>
                      </div>

                      {/* Option IA */}
                      <div className="pt-3 border-t border-slate-200">
                        <div className="flex items-start gap-3 p-3 bg-gradient-to-r from-indigo-50 to-purple-50 rounded-lg">
                          <Switch
                            checked={autoOptimization}
                            onCheckedChange={setAutoOptimization}
                          />
                          <div className="flex-1">
                            <div className="text-sm font-semibold text-slate-900 mb-1">
                              Optimisation automatique
                            </div>
                            <div className="text-xs text-slate-600">
                              Laisser PatyBee choisir la taille et le nombre de couleurs optimaux (recommandé)
                            </div>
                            <div className="text-xs text-indigo-600 mt-1 flex items-center gap-1">
                              <Lightbulb className="w-3 h-3" />
                              Analyse de netteté, densité, zones sombres, portrait/objet
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Colonne 2 - Proposition IA (3 colonnes) */}
                <div className="col-span-3">
                  <div className="space-y-4">
                    {/* Proposition automatique */}
                    <div className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-lg border border-indigo-200 p-4">
                      <div className="flex items-center gap-2 mb-3">
                        <Sparkles className="w-4 h-4 text-indigo-600" />
                        <h3 className="font-semibold text-sm">Proposition automatique de PatyBee</h3>
                      </div>

                      <p className="text-xs text-slate-700 mb-3">
                        PatyBee détermine les techniques recommandées :
                      </p>

                      <div className="space-y-2 mb-4">
                        {AI_RECOMMENDATIONS.map((rec, idx) => (
                          <div key={idx} className="flex items-start gap-2 text-xs text-slate-700">
                            <span className="text-green-600 font-bold">✓</span>
                            <span>{rec}</span>
                          </div>
                        ))}
                      </div>

                      <div className="flex items-center gap-3 p-3 bg-white rounded-lg">
                        <Switch
                          checked={autoSuggestionEnabled}
                          onCheckedChange={setAutoSuggestionEnabled}
                        />
                        <div className="flex-1">
                          <div className="text-xs font-semibold">
                            Utiliser la recommandation automatique
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Mode d'utilisation */}
                    <div className="bg-white rounded-lg border border-slate-200 p-4">
                      <h4 className="text-sm font-semibold text-slate-900 mb-3">Mode d'utilisation</h4>
                      <RadioGroup value={modeUtilisation} onValueChange={handleModeChange}>
                        <div className="space-y-2">
                          <div className="flex items-start gap-2 p-2 border border-slate-200 rounded-lg hover:border-slate-300 transition-colors cursor-pointer">
                            <RadioGroupItem value="debutant" id="debutant" className="mt-0.5" />
                            <Label htmlFor="debutant" className="flex-1 cursor-pointer">
                              <div className="font-semibold text-xs">Mode débutante</div>
                            </Label>
                          </div>

                          <div className="flex items-start gap-2 p-2 border border-slate-200 rounded-lg hover:border-slate-300 transition-colors cursor-pointer">
                            <RadioGroupItem value="avance" id="avance" className="mt-0.5" />
                            <Label htmlFor="avance" className="flex-1 cursor-pointer">
                              <div className="font-semibold text-xs">Mode avancé (débloque toutes les techniques)</div>
                            </Label>
                          </div>
                        </div>
                      </RadioGroup>
                    </div>
                  </div>
                </div>

                {/* Colonne 3 - Liste des types (5 colonnes) */}
                <div className="col-span-5">
                  <div className="bg-white rounded-lg border border-slate-200 p-4 h-full flex flex-col">
                    <h3 className="font-semibold text-sm mb-1 flex-shrink-0">Techniques incluses pour cette grille</h3>
                    <p className="text-xs text-slate-600 mb-3 flex-shrink-0">
                      Active ou désactive les techniques de broderie
                    </p>

                    <div className="flex-1 overflow-y-auto space-y-2 pr-2">
                      {STITCH_TYPES_LIST.map(stitch => {
                        const isSelected = selectedTypes.includes(stitch.id);
                        
                        return (
                          <div
                            key={stitch.id}
                            className={cn(
                              "flex items-center gap-3 p-2.5 rounded-lg border transition-colors",
                              stitch.mandatory 
                                ? "bg-indigo-50 border-indigo-200" 
                                : "bg-slate-50 border-slate-200 hover:border-slate-300"
                            )}
                          >
                            <div className="flex-1 min-w-0">
                              <div className="font-semibold text-xs flex items-center gap-2">
                                {stitch.name}
                                {stitch.mandatory && (
                                  <span className="text-[10px] bg-indigo-600 text-white px-1.5 py-0.5 rounded">
                                    Essentiel
                                  </span>
                                )}
                              </div>
                              <div className="text-xs text-slate-500 mt-0.5">{stitch.desc}</div>
                            </div>
                            <Switch
                              checked={isSelected}
                              onCheckedChange={() => handleToggleType(stitch.id)}
                              disabled={stitch.mandatory}
                            />
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Footer fixe */}
          <div className="flex-shrink-0 bg-white border-t border-slate-200 px-6 py-4">
            <div className="flex items-center justify-between">
              <Button
                variant="outline"
                onClick={onClose}
                className="gap-2"
              >
                <ArrowLeft className="w-4 h-4" />
                Revenir à l'étape précédente
              </Button>
              
              <Button
                onClick={handleValidate}
                disabled={isSubmitting}
                className="bg-indigo-600 hover:bg-indigo-700 text-white px-8 gap-2"
              >
                <CheckCircle className="w-4 h-4" />
                Valider et générer la grille
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}