import React from 'react';
import { Button } from '@/components/ui/button';
import { Sparkles, Eye, Wand2, Blend, X } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useGridSync } from './GridSyncContext';

export default function ContextualActionsBar({ pattern, onOptimize, onIsolate, onFusion }) {
  const { gridSelection, resetSelection, isolateColor, selectedColorId } = useGridSync();

  if (gridSelection.type === 'none') return null;

  const handleIsolateZoneColors = () => {
    if (gridSelection.type === 'zone') {
      // TODO: Extraire les couleurs de la zone
      onIsolate?.(gridSelection.rect);
    }
  };

  const handleOptimizeZone = () => {
    if (gridSelection.type === 'zone') {
      onOptimize?.(gridSelection.rect);
    }
  };

  const handleIsolateColor = () => {
    if (gridSelection.type === 'color') {
      isolateColor(gridSelection.colorId);
    }
  };

  const handleOpenAI = () => {
    if (gridSelection.type === 'color') {
      // TODO: Ouvrir le panneau IA pour cette couleur
    }
  };

  const handleFusion = () => {
    if (gridSelection.type === 'color') {
      onFusion?.(gridSelection.colorId);
    }
  };

  return (
    <div className="fixed top-20 left-1/2 -translate-x-1/2 z-[100] pointer-events-auto">
      <div className="bg-slate-900 text-white rounded-lg shadow-2xl border border-slate-700 px-4 py-2 flex items-center gap-2">
        {/* Zone sélectionnée */}
        {gridSelection.type === 'zone' && (
          <>
            <Button
              size="sm"
              variant="ghost"
              onClick={handleIsolateZoneColors}
              className="text-white hover:bg-slate-800"
            >
              <Eye className="w-4 h-4 mr-2" />
              Isoler les couleurs de cette zone
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={handleOptimizeZone}
              className="text-white hover:bg-slate-800"
            >
              <Wand2 className="w-4 h-4 mr-2" />
              Optimiser les dégradés
            </Button>
          </>
        )}

        {/* Couleur sélectionnée */}
        {gridSelection.type === 'color' && (
          <>
            <Button
              size="sm"
              variant="ghost"
              onClick={handleIsolateColor}
              className="text-white hover:bg-slate-800"
            >
              <Eye className="w-4 h-4 mr-2" />
              Afficher uniquement cette couleur
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={handleOpenAI}
              className="text-white hover:bg-slate-800"
            >
              <Sparkles className="w-4 h-4 mr-2" />
              Assistant IA Bee
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={handleFusion}
              className="text-white hover:bg-slate-800"
            >
              <Blend className="w-4 h-4 mr-2" />
              Fusionner avec...
            </Button>
          </>
        )}

        {/* Bouton fermer */}
        <div className="border-l border-slate-700 pl-2 ml-2">
          <Button
            size="sm"
            variant="ghost"
            onClick={resetSelection}
            className="text-white hover:bg-slate-800 px-2"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}