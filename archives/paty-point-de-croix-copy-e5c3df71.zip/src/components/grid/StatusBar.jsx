import React from 'react';

export default function StatusBar({ 
  nbColonnes, 
  nbLignes, 
  zoom, 
  hoverCol, 
  hoverRow,
  stitchCount,
  gridName
}) {
  return (
    <div className="bg-white/95 backdrop-blur-sm border-t border-slate-200 px-6 py-3 flex items-center justify-between text-xs text-slate-600">
      <div className="flex items-center gap-6">
        {gridName && (
          <div className="font-semibold text-slate-900">
            {gridName}
          </div>
        )}
        <div className="flex items-center gap-2">
          <span className="text-slate-500">Taille:</span>
          <span className="font-medium text-slate-700">{nbColonnes} × {nbLignes}</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-slate-500">Zoom:</span>
          <span className="font-medium text-slate-700">{Math.round(zoom * 100)}%</span>
        </div>
        {stitchCount !== undefined && (
          <div className="flex items-center gap-2">
            <span className="text-slate-500">Points:</span>
            <span className="font-medium text-slate-700">{stitchCount}</span>
          </div>
        )}
      </div>
      
      {hoverCol !== null && hoverRow !== null && (
        <div className="flex items-center gap-2 bg-slate-100 px-3 py-1 rounded-full">
          <span className="text-slate-500">Position:</span>
          <span className="font-mono font-medium text-slate-900">
            Col {hoverCol + 1} / Ligne {hoverRow + 1}
          </span>
        </div>
      )}
    </div>
  );
}