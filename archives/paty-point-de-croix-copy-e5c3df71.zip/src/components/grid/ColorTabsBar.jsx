import React, { useState } from 'react';
import { X, Edit3, Droplet, CheckCircle2, Eye, Lasso, ZoomIn, GitMerge, Copy, Trash2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Progress } from '@/components/ui/progress';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { motion, AnimatePresence } from 'framer-motion';

export default function ColorTabsBar({
  colorPalette = [],
  onColorClick,
  selectedColorId,
  settings = {},
  isLocked = false,
  onToggleLock,
  onAIAnalysis,
  onUpdateSymbol,
  onUpdateColor,
  onMarkAsDone,
  onDelete,
  onMergeWith,
  onIsolateColor,
  onSelectAllPoints,
  onZoomToColor
}) {
  const [expandedColorId, setExpandedColorId] = useState(null);

  const handleColorClick = (colorId) => {
    if (isLocked) return;

    if (expandedColorId === colorId) {
      setExpandedColorId(null);
      onColorClick?.(null);
    } else {
      setExpandedColorId(colorId);
      onColorClick?.(colorId);
    }
  };

  // Fermer au clic en dehors
  React.useEffect(() => {
    const handleClickOutside = (e) => {
      if (expandedColorId && !e.target.closest('[data-color-tab]')) {
        setExpandedColorId(null);
        onColorClick?.(null);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [expandedColorId, onColorClick]);

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 shadow-2xl z-[2000]">
      <div className="h-20 flex items-end overflow-x-auto overflow-y-visible px-4 gap-2">
        <TooltipProvider>
          {colorPalette.map((color) => (
            <ColorTab
              key={color.id}
              color={color}
              isExpanded={expandedColorId === color.id}
              isActive={selectedColorId === color.id}
              onClick={() => handleColorClick(color.id)}
              onUpdateSymbol={onUpdateSymbol}
              onUpdateColor={onUpdateColor}
              onMarkAsDone={onMarkAsDone}
              onDelete={onDelete}
              onMergeWith={onMergeWith}
              onIsolateColor={onIsolateColor}
              onSelectAllPoints={onSelectAllPoints}
              onZoomToColor={onZoomToColor}
            />
          ))}
        </TooltipProvider>
      </div>
    </div>
  );
}

function ColorTab({
  color,
  isExpanded,
  isActive,
  onClick,
  onUpdateSymbol,
  onUpdateColor,
  onMarkAsDone,
  onDelete,
  onMergeWith,
  onIsolateColor,
  onSelectAllPoints,
  onZoomToColor
}) {
  return (
    <div className="relative flex-shrink-0" data-color-tab>
      {/* Bloc compact - languette */}
      <motion.div
        onClick={onClick}
        className={cn(
          "w-16 h-16 cursor-pointer transition-all overflow-hidden relative",
          "rounded-t-xl",
          isExpanded && "shadow-xl border-t-4 border-[#F5C200]",
          isActive && !isExpanded && "ring-2 ring-[#F5C200] ring-offset-2"
        )}
        style={{ backgroundColor: color.hex }}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        {/* Symbole en haut */}
        <div className="w-full h-6 bg-white flex items-center justify-center">
          <span className="text-sm font-bold text-slate-900">{color.assignedSymbolChar || '●'}</span>
        </div>
        
        {/* Bloc de couleur */}
        <div className="flex-1" />
        
        {/* Badge du nombre de points */}
        <div className="absolute bottom-1 left-0 right-0 flex justify-center">
          <span className="text-[10px] text-white font-semibold drop-shadow bg-black/30 px-2 py-0.5 rounded">
            {color.totalCount || 0}
          </span>
        </div>
      </motion.div>

      {/* Panneau déployé vers le haut */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ opacity: 0, y: 10, height: 0 }}
            animate={{ opacity: 1, y: 0, height: 'auto' }}
            exit={{ opacity: 0, y: 10, height: 0 }}
            transition={{ duration: 0.2, ease: 'easeOut' }}
            className="absolute bottom-full left-1/2 -translate-x-1/2 mb-0 w-72 bg-white border-2 border-[#F5C200] rounded-t-2xl shadow-2xl overflow-hidden z-50"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-4 space-y-3">
              {/* Ligne 1: Infos couleur */}
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-slate-900">{color.code || 'DMC N/A'}</span>
                  <button
                    onClick={onClick}
                    className="p-1 hover:bg-slate-100 rounded-full transition-colors"
                  >
                    <X className="w-4 h-4 text-slate-400" />
                  </button>
                </div>
                <p className="text-xs text-slate-600">{color.name || `Couleur ${color.id.substring(0, 8)}`}</p>
              </div>

              {/* Ligne 2: Progression */}
              <div className="bg-slate-50 rounded-lg p-2.5 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-700 font-medium">{color.totalCount || 0} points</span>
                  <span className="text-xs font-bold text-slate-900">{color.progress || 0}% brodé</span>
                </div>
                <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-green-400 to-green-600 transition-all duration-300"
                    style={{ width: `${color.progress || 0}%` }}
                  />
                </div>
              </div>

            {/* 6 boutons principaux (3 rangées de 2) */}
            <div className="grid grid-cols-2 gap-2">
              {/* Rangée 1 */}
              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => onClick()}
                    className="aspect-square rounded-xl bg-slate-900 hover:bg-slate-800 text-white flex items-center justify-center transition-all shadow-md hover:shadow-lg"
                  >
                    <Droplet className="w-6 h-6" />
                  </button>
                </TooltipTrigger>
                <TooltipContent side="top"><p>Définir comme couleur active</p></TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => onIsolateColor?.(color.id)}
                    className="aspect-square rounded-xl bg-slate-900 hover:bg-slate-800 text-white flex items-center justify-center transition-all shadow-md hover:shadow-lg"
                  >
                    <Eye className="w-6 h-6" />
                  </button>
                </TooltipTrigger>
                <TooltipContent side="top"><p>Afficher uniquement cette couleur</p></TooltipContent>
              </Tooltip>

              {/* Rangée 2 */}
              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => onUpdateSymbol?.(color)}
                    className="aspect-square rounded-xl bg-slate-900 hover:bg-slate-800 text-white flex items-center justify-center transition-all shadow-md hover:shadow-lg"
                  >
                    <Edit3 className="w-6 h-6" />
                  </button>
                </TooltipTrigger>
                <TooltipContent side="top"><p>Modifier le symbole</p></TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => onUpdateColor?.(color)}
                    className="aspect-square rounded-xl bg-slate-900 hover:bg-slate-800 text-white flex items-center justify-center transition-all shadow-md hover:shadow-lg"
                  >
                    <Droplet className="w-6 h-6" />
                  </button>
                </TooltipTrigger>
                <TooltipContent side="top"><p>Modifier la couleur DMC</p></TooltipContent>
              </Tooltip>

              {/* Rangée 3 */}
              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => onMarkAsDone?.(color.id)}
                    className="aspect-square rounded-xl bg-slate-900 hover:bg-slate-800 text-white flex items-center justify-center transition-all shadow-md hover:shadow-lg"
                  >
                    <CheckCircle2 className="w-6 h-6" />
                  </button>
                </TooltipTrigger>
                <TooltipContent side="top"><p>Marquer comme brodée</p></TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => onSelectAllPoints?.(color.id)}
                    className="aspect-square rounded-xl bg-slate-900 hover:bg-slate-800 text-white flex items-center justify-center transition-all shadow-md hover:shadow-lg"
                  >
                    <Lasso className="w-6 h-6" />
                  </button>
                </TooltipTrigger>
                <TooltipContent side="top"><p>Sélectionner toutes les cases</p></TooltipContent>
              </Tooltip>
            </div>

            {/* 3 boutons secondaires */}
            <div className="flex items-center justify-around pt-3 border-t-2 border-slate-100">
              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => onMergeWith?.(color)}
                    className="p-2.5 rounded-lg hover:bg-slate-100 text-slate-600 hover:text-slate-900 transition-all"
                  >
                    <GitMerge className="w-5 h-5" />
                  </button>
                </TooltipTrigger>
                <TooltipContent side="top"><p>Fusionner avec une autre</p></TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => {
                      // TODO: onDuplicate action
                    }}
                    className="p-2.5 rounded-lg hover:bg-slate-100 text-slate-600 hover:text-slate-900 transition-all"
                  >
                    <Copy className="w-5 h-5" />
                  </button>
                </TooltipTrigger>
                <TooltipContent side="top"><p>Dupliquer cette couleur</p></TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => {
                      if (confirm('Supprimer cette couleur ?')) {
                        onDelete?.(color.id);
                      }
                    }}
                    className="p-2.5 rounded-lg hover:bg-red-50 text-red-600 hover:text-red-700 transition-all"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </TooltipTrigger>
                <TooltipContent side="top"><p>Supprimer cette couleur</p></TooltipContent>
              </Tooltip>
            </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}