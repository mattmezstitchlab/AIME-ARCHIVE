import React, { useMemo } from 'react';
import { X } from 'lucide-react';

const POINTS_PER_HOUR = 120; // Base configurable

export default function StatsPanel({ 
  isOpen, 
  onClose, 
  pattern, 
  colorPalette = [],
  selectedColorId 
}) {
  // Calculs globaux
  const stats = useMemo(() => {
    if (!pattern?.symbolGrid) {
      return {
        totalPoints: 0,
        totalColors: 0,
        donePoints: 0,
        donePercent: 0,
        estimatedHours: 0,
        colorsFullyDone: 0,
        colorsRemaining: 0,
        topColors: [],
      };
    }

    let totalPoints = 0;
    let donePoints = 0;
    const colorCounts = {};

    pattern.symbolGrid.forEach(row => {
      row?.forEach(cell => {
        if (cell?.colorId) {
          totalPoints++;
          colorCounts[cell.colorId] = (colorCounts[cell.colorId] || 0) + 1;
          if (cell.done) donePoints++;
        }
      });
    });

    const totalColors = Object.keys(colorCounts).length;
    const donePercent = totalPoints > 0 ? Math.round((donePoints / totalPoints) * 100) : 0;
    const estimatedHours = Math.round((totalPoints / POINTS_PER_HOUR) * 10) / 10;

    // Top 3 couleurs
    const topColors = Object.entries(colorCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3)
      .map(([colorId, count]) => {
        const color = colorPalette.find(c => c.id === colorId);
        return {
          id: colorId,
          code: color?.code || color?.dmc || '???',
          count,
          percent: totalPoints > 0 ? Math.round((count / totalPoints) * 1000) / 10 : 0,
        };
      });

    // Couleurs terminées
    let colorsFullyDone = 0;
    colorPalette.forEach(color => {
      let colorTotal = 0;
      let colorDone = 0;
      pattern.symbolGrid.forEach(row => {
        row?.forEach(cell => {
          if (cell?.colorId === color.id) {
            colorTotal++;
            if (cell.done) colorDone++;
          }
        });
      });
      if (colorTotal > 0 && colorDone === colorTotal) colorsFullyDone++;
    });

    return {
      totalPoints,
      totalColors,
      donePoints,
      donePercent,
      estimatedHours,
      colorsFullyDone,
      colorsRemaining: totalColors - colorsFullyDone,
      topColors,
    };
  }, [pattern, colorPalette]);

  // Stats couleur sélectionnée
  const selectedColorStats = useMemo(() => {
    if (!selectedColorId || !pattern?.symbolGrid) return null;

    const color = colorPalette.find(c => c.id === selectedColorId);
    if (!color) return null;

    let colorTotal = 0;
    let colorDone = 0;

    pattern.symbolGrid.forEach(row => {
      row?.forEach(cell => {
        if (cell?.colorId === selectedColorId) {
          colorTotal++;
          if (cell.done) colorDone++;
        }
      });
    });

    const percent = stats.totalPoints > 0 ? Math.round((colorTotal / stats.totalPoints) * 1000) / 10 : 0;
    const donePercent = colorTotal > 0 ? Math.round((colorDone / colorTotal) * 100) : 0;
    const estimatedMinutes = Math.round((colorTotal / POINTS_PER_HOUR) * 60);
    const hours = Math.floor(estimatedMinutes / 60);
    const minutes = estimatedMinutes % 60;

    return {
      code: String(color.code || color.dmc || '???').replace(/DMC[-\s]?/gi, ''),
      symbol: color.assignedSymbolChar || '●',
      hex: color.hex || color.dmcHex || '#808080',
      totalPoints: colorTotal,
      percent,
      donePoints: colorDone,
      donePercent,
      estimatedTime: hours > 0 ? `${hours}h${minutes.toString().padStart(2, '0')}` : `${minutes}min`,
    };
  }, [selectedColorId, pattern, colorPalette, stats.totalPoints]);

  if (!isOpen) return null;

  const formatTime = (hours) => {
    const h = Math.floor(hours);
    const m = Math.round((hours - h) * 60);
    return h > 0 ? `${h}h${m.toString().padStart(2, '0')}` : `${m}min`;
  };

  return (
    <div
      style={{
        position: 'fixed',
        top: '80px',
        right: '16px',
        width: '260px',
        backgroundColor: '#FFFFFF',
        zIndex: 9998,
        boxShadow: '0 2px 12px rgba(0,0,0,0.15)',
      }}
    >
      {/* Header */}
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: '12px 16px',
        borderBottom: '1px solid #E0E0E0',
      }}>
        <span style={{ fontSize: '13px', fontWeight: 700, color: '#000' }}>
          Statistiques du projet
        </span>
        <button
          onClick={onClose}
          style={{
            width: '24px',
            height: '24px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            backgroundColor: 'transparent',
            border: 'none',
            cursor: 'pointer',
          }}
        >
          <X style={{ width: '16px', height: '16px', color: '#666' }} />
        </button>
      </div>

      {/* Résumé global */}
      <div style={{ padding: '12px 16px', borderBottom: '1px solid #E0E0E0' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px' }}>
          <span style={{ fontSize: '11px', color: '#666' }}>Total points</span>
          <span style={{ fontSize: '11px', fontWeight: 600, color: '#000' }}>
            {stats.totalPoints.toLocaleString()}
          </span>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px' }}>
          <span style={{ fontSize: '11px', color: '#666' }}>Couleurs DMC</span>
          <span style={{ fontSize: '11px', fontWeight: 600, color: '#000' }}>
            {stats.totalColors}
          </span>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <span style={{ fontSize: '11px', color: '#666' }}>Temps estimé</span>
          <span style={{ fontSize: '11px', fontWeight: 600, color: '#000' }}>
            ~ {formatTime(stats.estimatedHours)}
          </span>
        </div>
      </div>

      {/* Avancement */}
      <div style={{ padding: '12px 16px', borderBottom: '1px solid #E0E0E0' }}>
        <div style={{ fontSize: '11px', color: '#666', marginBottom: '6px' }}>Avancement</div>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px' }}>
          <span style={{ fontSize: '11px', color: '#000' }}>
            {stats.donePoints.toLocaleString()} pts brodés
          </span>
          <span style={{ fontSize: '11px', fontWeight: 600, color: '#000' }}>
            {stats.donePercent}%
          </span>
        </div>
        {/* Barre de progression */}
        <div style={{
          height: '6px',
          backgroundColor: '#E0E0E0',
          width: '100%',
        }}>
          <div style={{
            height: '100%',
            width: `${stats.donePercent}%`,
            backgroundColor: '#000',
          }} />
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '8px' }}>
          <span style={{ fontSize: '10px', color: '#888' }}>
            Terminées : {stats.colorsFullyDone}
          </span>
          <span style={{ fontSize: '10px', color: '#888' }}>
            Restantes : {stats.colorsRemaining}
          </span>
        </div>
      </div>

      {/* Top 3 couleurs */}
      <div style={{ padding: '12px 16px', borderBottom: selectedColorStats ? '1px solid #E0E0E0' : 'none' }}>
        <div style={{ fontSize: '11px', color: '#666', marginBottom: '8px' }}>Top couleurs</div>
        {stats.topColors.map((color, idx) => (
          <div key={color.id} style={{ 
            display: 'flex', 
            justifyContent: 'space-between', 
            marginBottom: idx < 2 ? '4px' : 0 
          }}>
            <span style={{ fontSize: '11px', color: '#000' }}>
              {color.code}
            </span>
            <span style={{ fontSize: '11px', color: '#666' }}>
              {color.count.toLocaleString()} pts ({color.percent}%)
            </span>
          </div>
        ))}
      </div>

      {/* Couleur sélectionnée */}
      {selectedColorStats && (
        <div style={{ padding: '12px 16px', backgroundColor: '#FAFAFA' }}>
          <div style={{ fontSize: '11px', color: '#666', marginBottom: '8px' }}>Couleur sélectionnée</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
            <div style={{
              width: '24px',
              height: '24px',
              backgroundColor: selectedColorStats.hex,
              border: '1px solid #CCC',
            }} />
            <span style={{ fontSize: '13px', fontWeight: 700, color: '#000' }}>
              {selectedColorStats.code}
            </span>
            <span style={{ fontSize: '13px', fontWeight: 600, color: '#000' }}>
              {selectedColorStats.symbol}
            </span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
            <span style={{ fontSize: '10px', color: '#666' }}>Points</span>
            <span style={{ fontSize: '10px', color: '#000' }}>
              {selectedColorStats.totalPoints.toLocaleString()} ({selectedColorStats.percent}%)
            </span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
            <span style={{ fontSize: '10px', color: '#666' }}>Temps estimé</span>
            <span style={{ fontSize: '10px', color: '#000' }}>
              ~ {selectedColorStats.estimatedTime}
            </span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <span style={{ fontSize: '10px', color: '#666' }}>Brodés</span>
            <span style={{ fontSize: '10px', color: '#000' }}>
              {selectedColorStats.donePoints.toLocaleString()} ({selectedColorStats.donePercent}%)
            </span>
          </div>
        </div>
      )}
    </div>
  );
}