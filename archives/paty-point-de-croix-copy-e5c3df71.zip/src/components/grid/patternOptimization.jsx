/**
 * Module d'optimisation IA pour les motifs de broderie
 * 3 étapes: Nettoyage, Simplification, Optimisation finale
 */

import { findClosestDMC, calculateColorDistance } from './dmcColors';

// ========== ÉTAPE 1: NETTOYAGE DES DÉFAUTS ==========

export function cleanPatternDefects(pattern) {
  if (!pattern || !pattern.symbolGrid) return pattern;

  let grid = JSON.parse(JSON.stringify(pattern.symbolGrid));
  const width = pattern.width;
  const height = pattern.height;

  // 1. Supprimer pixels isolés (< 3 points)
  grid = removeIsolatedPixels(grid, width, height);

  // 2. Corriger ruptures de contour
  grid = fixContourBreaks(grid, width, height);

  // 3. Supprimer micro-zones parasites (< 5 points)
  grid = removeMicroZones(grid, width, height, 5);

  // 4. Lisser les diagonales
  grid = smoothDiagonals(grid, width, height);

  // 5. Lisser les gradients
  grid = smoothGradients(grid, width, height);

  return {
    ...pattern,
    symbolGrid: grid,
    optimizationSteps: [...(pattern.optimizationSteps || []), 'clean']
  };
}

function removeIsolatedPixels(grid, width, height) {
  const newGrid = JSON.parse(JSON.stringify(grid));

  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const cell = grid[y]?.[x];
      if (!cell) continue;

      const neighbors = getNeighbors(grid, x, y);
      const sameColorNeighbors = neighbors.filter(n => n && n.colorId === cell.colorId);

      // Si < 3 voisins de même couleur, remplacer par couleur dominante locale
      if (sameColorNeighbors.length < 3) {
        const dominantColor = getDominantNeighborColor(grid, x, y, cell.colorId);
        if (dominantColor) {
          newGrid[y][x] = { ...newGrid[y][x], colorId: dominantColor };
        }
      }
    }
  }

  return newGrid;
}

function fixContourBreaks(grid, width, height) {
  const newGrid = JSON.parse(JSON.stringify(grid));

  for (let y = 1; y < height - 1; y++) {
    for (let x = 1; x < width - 1; x++) {
      const cell = grid[y]?.[x];
      if (!cell) continue;

      // Détecter les ruptures en diagonal
      const topLeft = grid[y - 1]?.[x - 1];
      const topRight = grid[y - 1]?.[x + 1];
      const bottomLeft = grid[y + 1]?.[x - 1];
      const bottomRight = grid[y + 1]?.[x + 1];

      if (topLeft && bottomRight && topLeft.colorId === bottomRight.colorId && 
          topLeft.colorId !== cell.colorId) {
        newGrid[y][x] = { ...newGrid[y][x], colorId: topLeft.colorId };
      }
    }
  }

  return newGrid;
}

function removeMicroZones(grid, width, height, threshold) {
  const visited = new Set();
  const zones = [];

  // Identifier toutes les zones connectées
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const cell = grid[y]?.[x];
      if (!cell || visited.has(`${x},${y}`)) continue;

      const zone = floodFill(grid, x, y, visited);
      zones.push(zone);
    }
  }

  // Supprimer les zones < threshold
  const newGrid = JSON.parse(JSON.stringify(grid));
  for (const zone of zones) {
    if (zone.cells.length < threshold) {
      for (const [zx, zy] of zone.cells) {
        const dominantColor = getDominantNeighborColor(grid, zx, zy, zone.colorId);
        if (dominantColor && newGrid[zy]?.[zx]) {
          newGrid[zy][zx] = { ...newGrid[zy][zx], colorId: dominantColor };
        }
      }
    }
  }

  return newGrid;
}

function smoothDiagonals(grid, width, height) {
  const newGrid = JSON.parse(JSON.stringify(grid));

  for (let y = 1; y < height - 1; y++) {
    for (let x = 1; x < width - 1; x++) {
      const cell = grid[y]?.[x];
      if (!cell) continue;

      const top = grid[y - 1]?.[x];
      const left = grid[y]?.[x - 1];
      const topLeft = grid[y - 1]?.[x - 1];

      // Pattern diagonal à lisser
      if (top && left && topLeft && 
          top.colorId === left.colorId && 
          top.colorId !== cell.colorId && 
          topLeft.colorId !== top.colorId) {
        newGrid[y][x] = { ...newGrid[y][x], colorId: top.colorId };
      }
    }
  }

  return newGrid;
}

function smoothGradients(grid, width, height) {
  // Détecter les changements de couleur trop fréquents
  const newGrid = JSON.parse(JSON.stringify(grid));

  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const cell = grid[y]?.[x];
      if (!cell) continue;

      const neighbors = getNeighbors(grid, x, y);
      const colorCounts = {};
      neighbors.forEach(n => {
        if (n) colorCounts[n.colorId] = (colorCounts[n.colorId] || 0) + 1;
      });

      const dominantColor = Object.entries(colorCounts).sort((a, b) => b[1] - a[1])[0];
      if (dominantColor && dominantColor[1] >= 5) {
        newGrid[y][x] = { ...newGrid[y][x], colorId: dominantColor[0] };
      }
    }
  }

  return newGrid;
}

// ========== ÉTAPE 2: SIMPLIFICATION INTELLIGENTE ==========

export function simplifyPattern(pattern, options = {}) {
  if (!pattern || !pattern.colorPalette) return { pattern, stats: {} };

  const threshold = options.threshold || 20; // Distance colorimétrique

  // Analyser la palette actuelle
  const currentColors = pattern.colorPalette.length;
  const colorGroups = groupSimilarDMCColors(pattern.colorPalette, threshold);

  // Calculer les statistiques
  const stats = {
    currentColors,
    simplifiedColors: colorGroups.length,
    reductionPercent: Math.round(((currentColors - colorGroups.length) / currentColors) * 100),
    complexityReduced: colorGroups.length < currentColors * 0.7,
    recommendations: generateRecommendations(pattern, colorGroups)
  };

  return { pattern, stats, colorGroups };
}

export function applySimplification(pattern, colorGroups) {
  if (!pattern || !colorGroups) return pattern;

  // Créer une map de remplacement
  const replacementMap = new Map();
  colorGroups.forEach(group => {
    group.colors.forEach(color => {
      replacementMap.set(color.id, group.representative.id);
    });
  });

  // Mettre à jour la grille
  const newGrid = pattern.symbolGrid.map(row =>
    row.map(cell => {
      if (!cell) return cell;
      const newColorId = replacementMap.get(cell.colorId) || cell.colorId;
      return { ...cell, colorId: newColorId };
    })
  );

  // Créer nouvelle palette avec uniquement les couleurs représentatives
  const newPalette = colorGroups.map(group => {
    const totalPoints = group.colors.reduce((sum, c) => sum + c.totalCount, 0);
    return {
      ...group.representative,
      totalCount: totalPoints,
      count: totalPoints
    };
  });

  return {
    ...pattern,
    symbolGrid: newGrid,
    colorPalette: newPalette,
    optimizationSteps: [...(pattern.optimizationSteps || []), 'simplify']
  };
}

function groupSimilarDMCColors(palette, threshold) {
  const groups = [];
  const used = new Set();

  for (const color of palette) {
    if (used.has(color.id)) continue;

    const group = {
      representative: color,
      colors: [color]
    };

    // Trouver toutes les couleurs similaires
    for (const other of palette) {
      if (other.id === color.id || used.has(other.id)) continue;

      const distance = calculateColorDistance(
        color.r, color.g, color.b,
        other.r, other.g, other.b
      );

      if (distance < threshold) {
        group.colors.push(other);
        used.add(other.id);
      }
    }

    used.add(color.id);
    groups.push(group);
  }

  return groups;
}

function generateRecommendations(pattern, colorGroups) {
  const recommendations = [];

  if (colorGroups.length > 30) {
    recommendations.push('Réduire encore le nombre de couleurs pour faciliter la broderie');
  }

  if (pattern.colorPalette.some(c => c.totalCount < 10)) {
    recommendations.push('Supprimer les couleurs avec très peu de points');
  }

  if (colorGroups.length < 10) {
    recommendations.push('Excellent! Nombre de couleurs optimal pour la broderie');
  }

  return recommendations;
}

// ========== ÉTAPE 3: OPTIMISATION FINALE ==========

export function finalizeOptimization(pattern) {
  if (!pattern) return pattern;

  let optimizedPattern = { ...pattern };

  // 1. Recalculer les bordures
  optimizedPattern = recalculateBorders(optimizedPattern);

  // 2. Redistribuer les symboles de manière optimale
  optimizedPattern = redistributeSymbols(optimizedPattern);

  // 3. Vérifier les zones de taille
  optimizedPattern = optimizeZoneSizes(optimizedPattern);

  // 4. Mettre à jour les statistiques
  optimizedPattern = updateStatistics(optimizedPattern);

  return {
    ...optimizedPattern,
    optimizationSteps: [...(optimizedPattern.optimizationSteps || []), 'finalize'],
    optimizationComplete: true,
    optimizationDate: new Date().toISOString()
  };
}

function recalculateBorders(pattern) {
  // Lisser les bordures entre zones de couleurs
  const newGrid = JSON.parse(JSON.stringify(pattern.symbolGrid));

  for (let y = 1; y < pattern.height - 1; y++) {
    for (let x = 1; x < pattern.width - 1; x++) {
      const cell = newGrid[y]?.[x];
      if (!cell) continue;

      const neighbors = getNeighbors(pattern.symbolGrid, x, y);
      const differentNeighbors = neighbors.filter(n => n && n.colorId !== cell.colorId).length;

      // Si entouré de couleurs différentes, c'est un point de bordure
      if (differentNeighbors >= 6) {
        // Garder tel quel pour contour net
      }
    }
  }

  return { ...pattern, symbolGrid: newGrid };
}

function redistributeSymbols(pattern) {
  // Réattribuer les symboles de manière contrastée et lisible
  const symbolPool = ['✕', '○', '△', '□', '◆', '●', '▲', '■', '◇', '▼', '▽', '◁', '▷', '⬡', '⬢', '⬣'];
  let symbolIndex = 0;

  const newPalette = pattern.colorPalette.map((color, index) => ({
    ...color,
    assignedSymbolChar: symbolPool[symbolIndex++ % symbolPool.length]
  }));

  return { ...pattern, colorPalette: newPalette };
}

function optimizeZoneSizes(pattern) {
  // Identifier les zones trop grandes qui nécessiteraient trop de changements de fil
  // Pour l'instant, juste retourner le pattern tel quel
  return pattern;
}

function updateStatistics(pattern) {
  // Recalculer toutes les statistiques
  const colorCounts = {};
  pattern.symbolGrid.flat().forEach(cell => {
    if (cell) {
      colorCounts[cell.colorId] = (colorCounts[cell.colorId] || 0) + 1;
    }
  });

  const newPalette = pattern.colorPalette.map(color => ({
    ...color,
    totalCount: colorCounts[color.id] || 0,
    count: colorCounts[color.id] || 0
  })).filter(c => c.totalCount > 0);

  return { ...pattern, colorPalette: newPalette };
}

// ========== FONCTIONS UTILITAIRES ==========

function getNeighbors(grid, x, y) {
  const neighbors = [];
  const offsets = [
    [-1, -1], [0, -1], [1, -1],
    [-1, 0],           [1, 0],
    [-1, 1],  [0, 1],  [1, 1]
  ];

  for (const [dx, dy] of offsets) {
    const nx = x + dx;
    const ny = y + dy;
    if (grid[ny]?.[nx]) {
      neighbors.push(grid[ny][nx]);
    }
  }

  return neighbors;
}

function getDominantNeighborColor(grid, x, y, excludeColorId) {
  const neighbors = getNeighbors(grid, x, y);
  const colorCounts = {};

  neighbors.forEach(n => {
    if (n && n.colorId !== excludeColorId) {
      colorCounts[n.colorId] = (colorCounts[n.colorId] || 0) + 1;
    }
  });

  const sorted = Object.entries(colorCounts).sort((a, b) => b[1] - a[1]);
  return sorted.length > 0 ? sorted[0][0] : null;
}

function floodFill(grid, startX, startY, visited) {
  const startCell = grid[startY]?.[startX];
  if (!startCell) return { colorId: null, cells: [] };

  const colorId = startCell.colorId;
  const cells = [];
  const queue = [[startX, startY]];

  while (queue.length > 0) {
    const [x, y] = queue.shift();
    const key = `${x},${y}`;

    if (visited.has(key)) continue;
    
    const cell = grid[y]?.[x];
    if (!cell || cell.colorId !== colorId) continue;

    visited.add(key);
    cells.push([x, y]);

    // Ajouter voisins directs (4-connectivité)
    [[0, -1], [1, 0], [0, 1], [-1, 0]].forEach(([dx, dy]) => {
      queue.push([x + dx, y + dy]);
    });
  }

  return { colorId, cells };
}