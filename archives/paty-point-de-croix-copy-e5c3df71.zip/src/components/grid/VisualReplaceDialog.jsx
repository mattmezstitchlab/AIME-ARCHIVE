import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { AlertTriangle } from 'lucide-react';

export default function VisualReplaceDialog({ open, onClose, onReplace, onCancel }) {
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-amber-500" />
            Remplacer le visuel existant ?
          </DialogTitle>
          <DialogDescription>
            Un visuel est déjà présent dans cette grille.
          </DialogDescription>
        </DialogHeader>

        <div className="py-4 space-y-3">
          <p className="text-sm text-slate-700">
            Voulez-vous le remplacer par le nouveau visuel ?
          </p>
          
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
            <p className="text-sm text-amber-900">
              <strong>Attention :</strong> Le visuel actuel sera définitivement supprimé et remplacé. 
              La vue sera réinitialisée, mais vos points de croix seront conservés.
            </p>
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={onCancel}>
            Annuler
          </Button>
          <Button 
            onClick={onReplace}
            className="bg-amber-600 hover:bg-amber-700"
          >
            Remplacer le visuel
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}