import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from './utils';
import TopMenu from './components/grid/TopMenu';
import { SettingsProvider } from './components/settings/SettingsContext';
import { PatyBeeProvider } from './components/patybee/PatyBeeContext';
import { PatyBeeMatchingProvider } from './components/patybee/PatyBeeMatchingContext';
import { VibratoryEngineProvider } from './components/patybee/VibratoryEngineContext';
import PatyBeeGuide from './components/patybee/PatyBeeGuide';
import { ColorPaletteProvider } from './components/grid/ColorPaletteContext';
import { ZoomStateProvider } from './components/grid/ZoomStateManager';
import { GridSyncProvider } from './components/grid/GridSyncContext';

export default function Layout({ children, currentPageName }) {
  const navigate = useNavigate();
  const [gridEditorHandlers, setGridEditorHandlers] = useState(null);

  // Écouter les handlers de GridEditor
  useEffect(() => {
    const checkHandlers = () => {
      if (window.gridEditorHandlers) {
        setGridEditorHandlers(window.gridEditorHandlers);
      } else {
        setGridEditorHandlers(null);
      }
    };

    checkHandlers();
    const interval = setInterval(checkHandlers, 100);

    return () => clearInterval(interval);
  }, [currentPageName]);

  return (
    <SettingsProvider>
      <PatyBeeProvider>
        <PatyBeeMatchingProvider>
          <VibratoryEngineProvider>
            <ColorPaletteProvider>
              <ZoomStateProvider>
                <GridSyncProvider>
            <div className="h-screen flex flex-col overflow-hidden">
            {/* Barre fixe en haut */}
            <TopMenu 
              currentPageName={currentPageName}
              onNewGrid={gridEditorHandlers?.onNewGrid}
              onSave={gridEditorHandlers?.onSave}
              onProjects={gridEditorHandlers?.onProjects}
              onImport={gridEditorHandlers?.onImport}
              onCloseProject={gridEditorHandlers?.onCloseProject}
              onOpenAdvancedStyles={gridEditorHandlers?.onOpenAdvancedStyles}
              onExport={gridEditorHandlers?.onExport}
              hasUnsavedChanges={gridEditorHandlers?.hasUnsavedChanges}
              hasCurrentProject={gridEditorHandlers?.hasCurrentProject}
              pattern={gridEditorHandlers?.pattern}
              onOpenDashboard={gridEditorHandlers?.onOpenDashboard}
              onOpenWelcomeIntro={gridEditorHandlers?.onOpenWelcomeIntro}
              onUndo={gridEditorHandlers?.onUndo}
              onRedo={gridEditorHandlers?.onRedo}
              canUndo={gridEditorHandlers?.canUndo}
              canRedo={gridEditorHandlers?.canRedo}
              onToggleEdit={gridEditorHandlers?.onToggleEdit}
              onTogglePreview={gridEditorHandlers?.onTogglePreview}
              isEditMode={gridEditorHandlers?.isEditMode}
              showPreview={gridEditorHandlers?.showPreview}
              currentTool={gridEditorHandlers?.currentTool}
              onToolSelect={gridEditorHandlers?.onToolSelect}
              showGrid={gridEditorHandlers?.showGrid}
              onToggleGrid={gridEditorHandlers?.onToggleGrid}
              showSymbols={gridEditorHandlers?.showSymbols}
              onToggleSymbols={gridEditorHandlers?.onToggleSymbols}
              contrastMode={gridEditorHandlers?.contrastMode}
              onContrastModeChange={gridEditorHandlers?.onContrastModeChange}
              symbolSizeMode={gridEditorHandlers?.symbolSizeMode}
              onSymbolSizeModeChange={gridEditorHandlers?.onSymbolSizeModeChange}
              antiFatigueMode={gridEditorHandlers?.antiFatigueMode}
              onAntiFatigueModeChange={gridEditorHandlers?.onAntiFatigueModeChange}
              focusColorMode={gridEditorHandlers?.focusColorMode}
              onFocusColorModeChange={gridEditorHandlers?.onFocusColorModeChange}
              highlightActiveMode={gridEditorHandlers?.highlightActiveMode}
              onHighlightActiveModeChange={gridEditorHandlers?.onHighlightActiveModeChange}
              nightMode={gridEditorHandlers?.nightMode}
              onNightModeChange={gridEditorHandlers?.onNightModeChange}
              autoCountMode={gridEditorHandlers?.autoCountMode}
              onAutoCountModeChange={gridEditorHandlers?.onAutoCountModeChange}
              onNavigateToZone={gridEditorHandlers?.onNavigateToZone}
              activeFilter={gridEditorHandlers?.activeFilter}
              onFilterByStitchType={gridEditorHandlers?.onFilterByStitchType}
              onFilterByColor={gridEditorHandlers?.onFilterByColor}
              onFilterBySymbol={gridEditorHandlers?.onFilterBySymbol}
              onResetFilters={gridEditorHandlers?.onResetFilters}
              isolationMode={gridEditorHandlers?.isolationMode}
              onToggleIsolationMode={gridEditorHandlers?.onToggleIsolationMode}
              showUnstitchedZones={gridEditorHandlers?.showUnstitchedZones}
              onToggleUnstitchedZones={gridEditorHandlers?.onToggleUnstitchedZones}
              showPotentialErrors={gridEditorHandlers?.showPotentialErrors}
              onTogglePotentialErrors={gridEditorHandlers?.onTogglePotentialErrors}
              errorSensitivity={gridEditorHandlers?.errorSensitivity}
              onErrorSensitivityChange={gridEditorHandlers?.onErrorSensitivityChange}
              showMissingPoints={gridEditorHandlers?.showMissingPoints}
              onToggleMissingPoints={gridEditorHandlers?.onToggleMissingPoints}
              unstitchedCount={gridEditorHandlers?.unstitchedCount}
              potentialErrorsCount={gridEditorHandlers?.potentialErrorsCount}
              missingPointsCount={gridEditorHandlers?.missingPointsCount}
              currentPencilSubTool={gridEditorHandlers?.currentPencilSubTool}
              onPencilSubToolSelect={gridEditorHandlers?.onPencilSubToolSelect}
              currentEraserSubTool={gridEditorHandlers?.currentEraserSubTool}
              onEraserSubToolSelect={gridEditorHandlers?.onEraserSubToolSelect}
              currentSelectionSubTool={gridEditorHandlers?.currentSelectionSubTool}
              onSelectionSubToolSelect={gridEditorHandlers?.onSelectionSubToolSelect}
            />
            
            {/* Contenu scrollable avec padding-top */}
            <div className="flex-1 overflow-y-auto" style={{ paddingTop: '70px' }}>
              {children}
            </div>

            {/* Guide PatyBee */}
            <PatyBeeGuide />
            </div>
                </GridSyncProvider>
                      </ZoomStateProvider>
                    </ColorPaletteProvider>
          </VibratoryEngineProvider>
        </PatyBeeMatchingProvider>
      </PatyBeeProvider>
    </SettingsProvider>
  );
}