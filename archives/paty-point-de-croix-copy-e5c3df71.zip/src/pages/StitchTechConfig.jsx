import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { 
  ArrowLeft, 
  X, 
  Slash, 
  Divide, 
  Minus, 
  Circle, 
  Sparkles, 
  Star,
  RotateCcw,
  Save
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

const STITCH_TECHNIQUES = [
  {
    id: 'fullCross',
    label: 'Point de croix complet',
    description: 'Type de point principal, utilisé dans la grande majorité des modèles.',
    icon: X,
    default: true
  },
  {
    id: 'halfCross',
    label: 'Demi-point',
    description: 'Idéal pour les ombrages et les remplissages plus légers.',
    icon: Slash,
    default: true
  },
  {
    id: 'quarterThreeQuarter',
    label: 'Quart / trois-quarts de point',
    description: 'Pour les contours fins et les détails subtils.',
    icon: Divide,
    default: true
  },
  {
    id: 'backstitch',
    label: 'Point arrière (backstitch)',
    description: 'Pour les contours, lettrages et lignes décoratives.',
    icon: Minus,
    default: true
  },
  {
    id: 'frenchKnot',
    label: 'Nœud français',
    description: 'Petit relief ponctuel, souvent utilisé pour les yeux, fleurs, détails.',
    icon: Circle,
    default: false
  },
  {
    id: 'beads',
    label: 'Perles',
    description: 'Ajoute des perles à la place de certains points pour un effet précieux.',
    icon: Star,
    default: false
  },
  {
    id: 'metallicThread',
    label: 'Fil métallique',
    description: 'Utilisation de fils métallisés (or, argent…) pour des zones brillantes.',
    icon: Sparkles,
    default: false
  },
  {
    id: 'longStitch',
    label: 'Long stitch / points longs',
    description: 'Points longs décoratifs pour certaines textures ou fonds.',
    icon: Minus,
    default: false
  }
];

const PRESETS = [
  {
    id: 'presetSimple',
    label: 'Broderie simple',
    description: 'Uniquement points de croix complets + demi-points.',
    config: {
      fullCross: true,
      halfCross: true,
      quarterThreeQuarter: false,
      backstitch: false,
      frenchKnot: false,
      beads: false,
      metallicThread: false,
      longStitch: false
    }
  },
  {
    id: 'presetDetail',
    label: 'Modèle détaillé',
    description: 'Active tous les points courants sauf perles et fils métallisés.',
    config: {
      fullCross: true,
      halfCross: true,
      quarterThreeQuarter: true,
      backstitch: true,
      frenchKnot: true,
      beads: false,
      metallicThread: false,
      longStitch: true
    }
  },
  {
    id: 'presetFull',
    label: 'Tout activer',
    description: 'Active toutes les techniques (avancé).',
    config: {
      fullCross: true,
      halfCross: true,
      quarterThreeQuarter: true,
      backstitch: true,
      frenchKnot: true,
      beads: true,
      metallicThread: true,
      longStitch: true
    }
  }
];

export default function StitchTechConfig() {
  const navigate = useNavigate();
  const [config, setConfig] = useState({});

  // Charger la config au montage
  useEffect(() => {
    const saved = localStorage.getItem('patybee_stitch_tech_config');
    if (saved) {
      try {
        setConfig(JSON.parse(saved));
      } catch (e) {
        resetToDefaults();
      }
    } else {
      resetToDefaults();
    }
  }, []);

  const resetToDefaults = () => {
    const defaults = {};
    STITCH_TECHNIQUES.forEach(tech => {
      defaults[tech.id] = tech.default;
    });
    setConfig(defaults);
  };

  const handleToggle = (id) => {
    setConfig(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const applyPreset = (preset) => {
    setConfig(preset.config);
    toast.success(`Préréglage "${preset.label}" appliqué`);
  };

  const handleSave = () => {
    localStorage.setItem('patybee_stitch_tech_config', JSON.stringify(config));
    toast.success('Vos préférences de techniques de broderie ont été enregistrées.');
    navigate(-1);
  };

  const handleCancel = () => {
    navigate(-1);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <div className="bg-white border-b border-slate-200">
        <div className="max-w-3xl mx-auto px-6 py-6">
          <button
            onClick={() => navigate(-1)}
            className="flex items-center gap-2 text-slate-600 hover:text-slate-900 mb-4 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="text-sm">Retour</span>
          </button>
          <h1 className="text-3xl font-bold text-slate-900 mb-2">
            Configurer les techniques de broderie
          </h1>
          <p className="text-slate-600">
            Choisissez quels types de points seront disponibles par défaut dans vos projets PatyBee.
          </p>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-3xl mx-auto px-6 py-8 space-y-8">
        
        {/* Info */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <p className="text-sm text-blue-900">
            Ces préférences s'appliquent comme réglage par défaut pour tous vos nouveaux projets. 
            Vous pourrez toujours ajuster les points au cas par cas dans chaque grille.
          </p>
        </div>

        {/* Techniques list */}
        <div className="space-y-4">
          <h2 className="text-xl font-semibold text-slate-900">Techniques disponibles par défaut</h2>
          
          <div className="grid gap-3">
            {STITCH_TECHNIQUES.map((tech) => {
              const Icon = tech.icon;
              const isActive = config[tech.id];
              
              return (
                <button
                  key={tech.id}
                  onClick={() => handleToggle(tech.id)}
                  className={cn(
                    "p-4 rounded-lg border-2 transition-all text-left",
                    isActive
                      ? "bg-slate-900 border-slate-900 text-white"
                      : "bg-white border-slate-200 hover:border-slate-300"
                  )}
                >
                  <div className="flex items-start gap-4">
                    <div className={cn(
                      "w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0",
                      isActive ? "bg-white/20" : "bg-slate-100"
                    )}>
                      <Icon className={cn("w-5 h-5", isActive ? "text-white" : "text-slate-700")} />
                    </div>
                    
                    <div className="flex-1">
                      <div className="font-semibold mb-1">{tech.label}</div>
                      <div className={cn(
                        "text-sm",
                        isActive ? "text-white/80" : "text-slate-600"
                      )}>
                        {tech.description}
                      </div>
                    </div>

                    <div className={cn(
                      "w-12 h-6 rounded-full transition-colors flex-shrink-0",
                      isActive ? "bg-white/30" : "bg-slate-200"
                    )}>
                      <div className={cn(
                        "w-5 h-5 rounded-full transition-transform mt-0.5",
                        isActive ? "translate-x-6 bg-white" : "translate-x-0.5 bg-slate-400"
                      )} />
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Presets */}
        <div className="space-y-4">
          <h2 className="text-xl font-semibold text-slate-900">Préréglages rapides</h2>
          
          <div className="grid gap-3">
            {PRESETS.map((preset) => (
              <button
                key={preset.id}
                onClick={() => applyPreset(preset)}
                className="p-4 rounded-lg border border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50 transition-all text-left"
              >
                <div className="font-semibold text-slate-900 mb-1">{preset.label}</div>
                <div className="text-sm text-slate-600">{preset.description}</div>
              </button>
            ))}
          </div>

          {/* IA-Mix Card */}
          <div className="mt-4 p-4 rounded-lg border border-slate-200 bg-slate-50">
            <div className="flex items-center gap-2 mb-2">
              <Sparkles className="w-5 h-5 text-indigo-600" />
              <span className="font-semibold text-slate-900">Activer l'IA Mix</span>
            </div>
            <p className="text-sm text-slate-600 mb-3">
              L'IA analyse vos préférences et active automatiquement les techniques les plus adaptées à votre façon de broder.
            </p>
            <Button
              onClick={() => {
                const aiConfig = {
                  fullCross: true,
                  halfCross: true,
                  quarterThreeQuarter: true,
                  backstitch: true,
                  frenchKnot: false,
                  beads: false,
                  metallicThread: false,
                  longStitch: false
                };
                setConfig(aiConfig);
                toast.info('IA Mix a activé les techniques adaptées : détails, contours et points essentiels.');
              }}
              className="w-full bg-slate-900 hover:bg-slate-800 text-white gap-2"
            >
              <Sparkles className="w-4 h-4" />
              Laisser PatyBee choisir pour moi
            </Button>
          </div>
        </div>

      </div>

      {/* Footer */}
      <div className="sticky bottom-0 bg-white border-t border-slate-200 py-4">
        <div className="max-w-3xl mx-auto px-6 flex items-center justify-between">
          <Button
            variant="ghost"
            onClick={resetToDefaults}
            className="gap-2"
          >
            <RotateCcw className="w-4 h-4" />
            Restaurer les valeurs par défaut
          </Button>

          <div className="flex gap-3">
            <Button
              variant="outline"
              onClick={handleCancel}
            >
              Annuler
            </Button>
            <Button
              onClick={handleSave}
              className="bg-slate-900 hover:bg-slate-800 text-white gap-2"
            >
              <Save className="w-4 h-4" />
              Enregistrer mes préférences
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}