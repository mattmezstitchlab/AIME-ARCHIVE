import React from 'react';
import GridEditor from './GridEditor';

export default function GridEditorWrapper() {
  return <GridEditor />;
}