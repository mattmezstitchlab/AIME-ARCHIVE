import React from 'react';
import SimpleGridEditor from '../components/grid/SimpleGridEditor';

/**
 * GRIDEDITOR - MODE SAFE
 * 
 * Version simplifiée et stable du GridEditor sans fonctionnalités avancées.
 * 
 * Fonctionnalités actives :
 * - Import d'image/PDF simplifié (pas d'étape 2)
 * - Grille de base avec canvas
 * - Palette DMC avec couleurs et symboles
 * 
 * Fonctionnalités désactivées temporairement (à réactiver étape par étape) :
 * - Étape 2 "Types de points" (StitchTypesSelectionDialog)
 * - Zoom Engine 5D
 * - ZoomStateManager
 * - Mini-carte 4D
 * - Affichage 6D
 * - IA-Focus
 * - LeftToolsPanel avancé
 * 
 * L'ancien code complexe a été sauvegardé dans pages/GridEditorComplex.jsx.backup
 * pour réactivation ultérieure une fois le safe mode stabilisé.
 */

export default function GridEditor() {
  return <SimpleGridEditor />;
}