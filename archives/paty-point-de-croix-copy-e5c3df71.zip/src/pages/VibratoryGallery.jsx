import VibratoryGallery from '../components/vibratory/VibratoryGallery';

export default VibratoryGallery;