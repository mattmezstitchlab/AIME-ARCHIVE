import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Sparkles, Eye, EyeOff } from 'lucide-react';
import { STITCH_TYPES, STITCH_CATEGORIES, PRESETS } from '../components/grid/stitchTypes';
import { toast } from 'sonner';

export default function StitchTypesPage() {
  const [enabledTypes, setEnabledTypes] = useState(['full', 'half', 'backstitch']);
  const [layerVisibility, setLayerVisibility] = useState({});
  const [layerOpacity, setLayerOpacity] = useState({});

  const handleToggleType = (typeId) => {
    setEnabledTypes(prev => 
      prev.includes(typeId) 
        ? prev.filter(id => id !== typeId)
        : [...prev, typeId]
    );
  };

  const handleApplyPreset = (presetKey) => {
    const preset = PRESETS[presetKey];
    setEnabledTypes(preset.enabled);
    toast.success(`Preset "${preset.name}" appliqué`);
  };

  const handleToggleAll = () => {
    if (enabledTypes.length === Object.keys(STITCH_TYPES).length) {
      setEnabledTypes([]);
      toast.info('Tous les types désactivés');
    } else {
      setEnabledTypes(Object.keys(STITCH_TYPES));
      toast.success('Tous les types activés');
    }
  };

  const standardTypes = Object.values(STITCH_TYPES).filter(t => t.category === 'standard');
  const advancedTypes = Object.values(STITCH_TYPES).filter(t => t.category === 'advanced');

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-8">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* En-tête */}
        <div>
          <h1 className="text-4xl font-bold text-slate-900 mb-2">Types de Points</h1>
          <p className="text-slate-600">
            Configurez les techniques de broderie disponibles dans vos projets
          </p>
        </div>

        {/* Presets rapides */}
        <Card className="p-6">
          <h2 className="text-xl font-semibold mb-4">Presets rapides</h2>
          <div className="flex gap-3 flex-wrap">
            <Button
              variant="outline"
              onClick={() => handleApplyPreset('beginner')}
            >
              Mode Débutante
            </Button>
            <Button
              variant="outline"
              onClick={() => handleApplyPreset('advanced')}
            >
              Mode Avancé
            </Button>
            <Button
              variant="outline"
              onClick={() => handleApplyPreset('expert')}
              className="gap-2"
            >
              <Sparkles className="w-4 h-4" />
              Mode Expert + IA
            </Button>
            <Button
              variant="outline"
              onClick={handleToggleAll}
            >
              {enabledTypes.length === Object.keys(STITCH_TYPES).length 
                ? 'Tout désactiver' 
                : 'Tout activer'}
            </Button>
          </div>
        </Card>

        {/* Points standards */}
        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-xl font-semibold">Points Standards</h2>
              <p className="text-sm text-slate-600">
                {STITCH_CATEGORIES.standard.description}
              </p>
            </div>
            <Badge variant="secondary">
              {standardTypes.filter(t => enabledTypes.includes(t.id)).length} / {standardTypes.length}
            </Badge>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {standardTypes.map(type => (
              <div
                key={type.id}
                className="flex items-center justify-between p-4 bg-white rounded-lg border border-slate-200 hover:border-slate-300 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div 
                    className="w-12 h-12 rounded-lg flex items-center justify-center text-2xl font-bold"
                    style={{ backgroundColor: `${type.color}20`, color: type.color }}
                  >
                    {type.icon}
                  </div>
                  <div>
                    <div className="font-semibold text-sm">{type.name}</div>
                    <div className="text-xs text-slate-500">{type.description}</div>
                  </div>
                </div>
                <Switch
                  checked={enabledTypes.includes(type.id)}
                  onCheckedChange={() => handleToggleType(type.id)}
                />
              </div>
            ))}
          </div>
        </Card>

        {/* Points avancés */}
        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-xl font-semibold">Points Avancés</h2>
              <p className="text-sm text-slate-600">
                {STITCH_CATEGORIES.advanced.description}
              </p>
            </div>
            <Badge variant="secondary">
              {advancedTypes.filter(t => enabledTypes.includes(t.id)).length} / {advancedTypes.length}
            </Badge>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {advancedTypes.map(type => (
              <div
                key={type.id}
                className="flex items-center justify-between p-4 bg-white rounded-lg border border-slate-200 hover:border-slate-300 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div 
                    className="w-12 h-12 rounded-lg flex items-center justify-center text-2xl font-bold"
                    style={{ backgroundColor: `${type.color}20`, color: type.color }}
                  >
                    {type.icon}
                  </div>
                  <div>
                    <div className="font-semibold text-sm">{type.name}</div>
                    <div className="text-xs text-slate-500">{type.description}</div>
                    <Badge 
                      variant="outline" 
                      className="text-[10px] mt-1"
                    >
                      {type.difficulty}
                    </Badge>
                  </div>
                </div>
                <Switch
                  checked={enabledTypes.includes(type.id)}
                  onCheckedChange={() => handleToggleType(type.id)}
                />
              </div>
            ))}
          </div>
        </Card>

        {/* IA Mix Automatique */}
        <Card className="p-6 bg-gradient-to-br from-indigo-50 to-purple-50 border-indigo-200">
          <div className="flex items-start gap-4">
            <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white">
              <Sparkles className="w-8 h-8" />
            </div>
            <div className="flex-1">
              <h3 className="text-xl font-bold text-slate-900 mb-2">
                IA Mix Automatique
              </h3>
              <p className="text-sm text-slate-700 mb-4">
                L'intelligence artificielle analyse votre image et choisit automatiquement les meilleurs types de points pour chaque zone, optimisant le rendu et la brodabilité.
              </p>
              <Button className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700">
                <Sparkles className="w-4 h-4 mr-2" />
                Activer l'IA Mix
              </Button>
            </div>
          </div>
        </Card>

        {/* Récapitulatif */}
        <Card className="p-6 bg-slate-50">
          <h3 className="font-semibold mb-2">Récapitulatif</h3>
          <p className="text-sm text-slate-600">
            {enabledTypes.length} type{enabledTypes.length > 1 ? 's' : ''} de point{enabledTypes.length > 1 ? 's' : ''} activé{enabledTypes.length > 1 ? 's' : ''} pour vos projets
          </p>
        </Card>
      </div>
    </div>
  );
}