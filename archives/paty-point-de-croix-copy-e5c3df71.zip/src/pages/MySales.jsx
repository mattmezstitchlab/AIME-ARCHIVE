import React from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { 
  TrendingUp, 
  DollarSign, 
  ShoppingBag, 
  Eye,
  Download
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function MySales() {
  const navigate = useNavigate();
  
  const { data: user } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me(),
  });

  const { data: myGrids, isLoading: gridsLoading } = useQuery({
    queryKey: ['my-shop-grids', user?.email],
    queryFn: async () => {
      if (!user) return [];
      return await base44.entities.ShopGrid.filter({ creator_email: user.email });
    },
    enabled: !!user,
    initialData: []
  });

  if (gridsLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center">
        <p className="text-slate-600">Chargement...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="container mx-auto px-8 py-8 space-y-8">
        {/* Statistiques globales */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="bg-white rounded-xl shadow-md border border-slate-200 p-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-lg bg-green-100 flex items-center justify-center">
                <DollarSign className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-slate-600">Revenus totaux</p>
                <p className="text-2xl font-bold text-slate-900">0.00€</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-md border border-slate-200 p-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                <ShoppingBag className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-slate-600">Ventes totales</p>
                <p className="text-2xl font-bold text-slate-900">0</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-md border border-slate-200 p-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-lg bg-purple-100 flex items-center justify-center">
                <TrendingUp className="w-5 h-5 text-purple-600" />
              </div>
              <div>
                <p className="text-sm text-slate-600">Solde disponible</p>
                <p className="text-2xl font-bold text-slate-900">0.00€</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-md border border-slate-200 p-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-lg bg-amber-100 flex items-center justify-center">
                <Download className="w-5 h-5 text-amber-600" />
              </div>
              <div>
                <p className="text-sm text-slate-600">Grilles publiées</p>
                <p className="text-2xl font-bold text-slate-900">
                  {myGrids.length}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Mes grilles publiées */}
        <div className="bg-white rounded-xl shadow-md border border-slate-200 p-6">
          <h2 className="text-xl font-bold text-slate-900 mb-4">Mes grilles publiées</h2>
          
          {myGrids.length === 0 ? (
            <p className="text-slate-600 text-center py-8">
              Vous n'avez pas encore publié de grille dans la Boutique
            </p>
          ) : (
            <div className="space-y-4">
              {myGrids.map((grid) => (
                <div
                  key={grid.id}
                  className="flex items-center gap-4 p-4 bg-slate-50 rounded-lg"
                >
                  {grid.preview_image && (
                    <div className="w-20 h-20 bg-white rounded border border-slate-200 overflow-hidden flex-shrink-0">
                      <img
                        src={grid.preview_image}
                        alt={grid.title}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  )}
                  
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-slate-900 mb-1">{grid.title}</h3>
                    <div className="flex items-center gap-4 text-sm text-slate-600">
                      <span className="flex items-center gap-1">
                        <Eye className="w-4 h-4" />
                        {grid.views_count || 0} vues
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Historique des transactions */}
        <div className="bg-white rounded-xl shadow-md border border-slate-200 p-6">
          <h2 className="text-xl font-bold text-slate-900 mb-4">Historique des ventes</h2>
          
          <p className="text-slate-600 text-center py-8">
            Aucune vente pour le moment
          </p>
        </div>
      </div>
    </div>
  );
}