import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Heart, Home, User, Calendar, Clock, Palette, Sparkles, Plane,
  Book, Music, Camera, Star, Users, Infinity, Smile, Cat, Flower2,
  Scissors, Sun, Moon, Coffee, Zap, Mountain, Waves, Wind,
  CloudRain, Snowflake, Leaf, TreePine, Apple, Cake, Wine,
  Gift, ShoppingBag, Shirt, Watch, Glasses, Crown, Target,
  Compass, Map, Flag, Anchor, Rocket, Lightbulb, Briefcase,
  GraduationCap, Award, Trophy, Medal, Gem, Diamond, CircleDot,
  Square, Triangle, Hexagon, Octagon, Circle, Box, Package,
  Archive, FolderOpen, FileText, Bookmark, Tag, Paperclip, Link,
  Lock, Key, Shield, Feather, Leaf as Leaf2, Bird, Fish,
  Bug, Paintbrush, Pen, Pencil, Eraser, Ruler, Droplet, Flame,
  Snowflake as Snow, Sunrise, Sunset, Rainbow, CloudSnow, Cloudy,
  Theater, Mic, Radio, Headphones, Volume2, Bell, AlertCircle,
  CheckCircle, XCircle, Info, HelpCircle, Plus, Minus, X as XIcon,
  Smartphone, Gamepad2, Film, Tv, Image, Building, Landmark,
  UtensilsCrossed, ChefHat, CookingPot, Scroll, Croissant,
  Baby, Puzzle, Wand2
} from 'lucide-react';

// Palette DMC de base pour sélection
const DMC_BASE_COLORS = [
  { code: 'DMC-321', hex: '#C8341F', name: 'Rouge' },
  { code: 'DMC-796', hex: '#1E4C8A', name: 'Bleu' },
  { code: 'DMC-702', hex: '#26823D', name: 'Vert' },
  { code: 'DMC-742', hex: '#F6A14A', name: 'Orange' },
  { code: 'DMC-208', hex: '#8B3A8B', name: 'Violet' },
  { code: 'DMC-310', hex: '#000000', name: 'Noir' },
  { code: 'DMC-3865', hex: '#F7F5ED', name: 'Blanc cassé' },
  { code: 'DMC-726', hex: '#F5C200', name: 'Jaune' },
  { code: 'DMC-3687', hex: '#CC546D', name: 'Rose' },
  { code: 'DMC-598', hex: '#5BA6CA', name: 'Bleu turquoise' },
];

// Définition des 100 symboles de la grille 10×10
const PROFILE_SYMBOLS = [
  { id: 'prenom', icon: User, label: 'Prénom', field: 'prenom' },
  { id: 'nom', icon: FileText, label: 'Nom de famille', field: 'nom' },
  { id: 'pseudo', icon: Tag, label: 'Pseudo / surnom', field: 'pseudo' },
  { id: 'date-naissance', icon: Calendar, label: 'Date de naissance', field: 'date_naissance' },
  { id: 'ville-actuelle', icon: Home, label: 'Ville actuelle', field: 'ville_actuelle' },
  { id: 'pays', icon: Map, label: 'Pays', field: 'pays' },
  { id: 'humeur', icon: Heart, label: 'État émotionnel / humeur', field: 'humeur' },
  { id: 'heure-broderie', icon: Clock, label: 'Heure de broderie préférée', field: 'heure_broderie' },
  { id: 'type-fils', icon: Sparkles, label: 'Types de fils préférés', field: 'type_fils' },
  { id: 'couleurs-dmc', icon: Palette, label: 'Couleurs DMC préférées', field: 'couleurs_dmc_preferees' },
  
  { id: 'technique-favorite', icon: Target, label: 'Technique favorite', field: 'technique_favorite' },
  { id: 'voyages', icon: Plane, label: 'Voyages marquants', field: 'voyages' },
  { id: 'themes-preferes', icon: Book, label: 'Thèmes / univers préférés', field: 'themes_preferes' },
  { id: 'musique', icon: Music, label: 'Musique pour broder', field: 'musique' },
  { id: 'style-motifs', icon: Camera, label: 'Style de motifs préférés', field: 'style_motifs' },
  { id: 'projets-reve', icon: Star, label: 'Projets rêve à broder', field: 'projets_reve' },
  { id: 'famille', icon: Users, label: 'Infos famille', field: 'famille' },
  { id: 'mantra', icon: Infinity, label: 'Mantra / valeur profonde', field: 'mantra' },
  { id: 'ton-emotionnel', icon: Smile, label: 'Ton émotionnel', field: 'ton_emotionnel' },
  { id: 'animal-prefere', icon: Cat, label: 'Animal préféré / totem', field: 'animal_prefere' },
  
  { id: 'fleur-preferee', icon: Flower2, label: 'Fleur / nature préférée', field: 'fleur_preferee' },
  { id: 'niveau-broderie', icon: Scissors, label: 'Niveau de broderie', field: 'niveau_broderie' },
  { id: 'saison-preferee', icon: Sun, label: 'Saison préférée', field: 'saison_preferee' },
  { id: 'moment-journee', icon: Sunrise, label: 'Moment de la journée préféré', field: 'moment_journee' },
  { id: 'boisson-preferee', icon: Coffee, label: 'Boisson préférée', field: 'boisson_preferee' },
  { id: 'lieu-inspiration', icon: Mountain, label: 'Lieu d\'inspiration', field: 'lieu_inspiration' },
  { id: 'element-nature', icon: Waves, label: 'Élément naturel préféré', field: 'element_nature' },
  { id: 'meteo-preferee', icon: CloudRain, label: 'Météo préférée', field: 'meteo_preferee' },
  { id: 'arbre-prefere', icon: TreePine, label: 'Arbre préféré', field: 'arbre_prefere' },
  { id: 'fruit-prefere', icon: Apple, label: 'Fruit préféré', field: 'fruit_prefere' },
  
  { id: 'dessert-prefere', icon: Cake, label: 'Dessert préféré', field: 'dessert_prefere' },
  { id: 'hobby-secondaire', icon: Gift, label: 'Hobby secondaire', field: 'hobby_secondaire' },
  { id: 'style-vestimentaire', icon: Shirt, label: 'Style vestimentaire', field: 'style_vestimentaire' },
  { id: 'accessoire-prefere', icon: Watch, label: 'Accessoire préféré', field: 'accessoire_prefere' },
  { id: 'lunettes', icon: Glasses, label: 'Porte des lunettes ?', field: 'lunettes' },
  { id: 'objectif-annee', icon: Trophy, label: 'Objectif de l\'année', field: 'objectif_annee' },
  { id: 'inspiration', icon: Lightbulb, label: 'Source d\'inspiration', field: 'inspiration' },
  { id: 'profession', icon: Briefcase, label: 'Profession / métier', field: 'profession' },
  { id: 'formation', icon: GraduationCap, label: 'Formation / études', field: 'formation' },
  { id: 'recompense', icon: Award, label: 'Récompense / fierté', field: 'recompense' },
  
  { id: 'pierre-preferee', icon: Gem, label: 'Pierre / cristal préféré', field: 'pierre_preferee' },
  { id: 'couleur-yeux', icon: CircleDot, label: 'Couleur des yeux', field: 'couleur_yeux' },
  { id: 'couleur-cheveux', icon: Feather, label: 'Couleur des cheveux', field: 'couleur_cheveux' },
  { id: 'signe-astrologique', icon: Compass, label: 'Signe astrologique', field: 'signe_astrologique' },
  { id: 'oiseau-prefere', icon: Bird, label: 'Oiseau préféré', field: 'oiseau_prefere' },
  { id: 'poisson-prefere', icon: Fish, label: 'Animal marin préféré', field: 'poisson_prefere' },
  { id: 'insecte-prefere', icon: Bug, label: 'Insecte préféré', field: 'insecte_prefere' },
  { id: 'outil-creation', icon: Paintbrush, label: 'Outil de création favori', field: 'outil_creation' },
  { id: 'stylo-prefere', icon: Pen, label: 'Type de stylo préféré', field: 'stylo_prefere' },
  { id: 'crayon-prefere', icon: Pencil, label: 'Crayon préféré', field: 'crayon_prefere' },
  
  { id: 'parfum-prefere', icon: Droplet, label: 'Parfum / odeur préférée', field: 'parfum_prefere' },
  { id: 'bougie-preferee', icon: Flame, label: 'Type de bougie préférée', field: 'bougie_preferee' },
  { id: 'temperature-ideale', icon: Snow, label: 'Température idéale', field: 'temperature_ideale' },
  { id: 'lever-coucher', icon: Sunset, label: 'Lever ou coucher de soleil ?', field: 'lever_coucher' },
  { id: 'arc-en-ciel', icon: Rainbow, label: 'Souvenir avec un arc-en-ciel', field: 'arc_en_ciel' },
  { id: 'spectacle-prefere', icon: Theater, label: 'Type de spectacle préféré', field: 'spectacle_prefere' },
  { id: 'instrument-musique', icon: Mic, label: 'Instrument de musique', field: 'instrument_musique' },
  { id: 'podcast-prefere', icon: Radio, label: 'Podcast / radio préférée', field: 'podcast_prefere' },
  { id: 'casque-audio', icon: Headphones, label: 'Type de casque audio', field: 'casque_audio' },
  { id: 'son-prefere', icon: Volume2, label: 'Son / bruit préféré', field: 'son_prefere' },
  
  { id: 'notification-preferee', icon: Bell, label: 'Notification préférée', field: 'notification_preferee' },
  { id: 'moment-calme', icon: Moon, label: 'Moment de calme quotidien', field: 'moment_calme' },
  { id: 'rituel-matin', icon: Sun, label: 'Rituel du matin', field: 'rituel_matin' },
  { id: 'rituel-soir', icon: Moon, label: 'Rituel du soir', field: 'rituel_soir' },
  { id: 'super-pouvoir', icon: Zap, label: 'Super-pouvoir rêvé', field: 'super_pouvoir' },
  { id: 'symbole-personnel', icon: Crown, label: 'Symbole personnel', field: 'symbole_personnel' },
  { id: 'objet-fetiche', icon: Key, label: 'Objet fétiche', field: 'objet_fetiche' },
  { id: 'collection', icon: Archive, label: 'Collection personnelle', field: 'collection' },
  { id: 'livre-prefere', icon: Book, label: 'Livre préféré', field: 'livre_prefere' },
  { id: 'citation-favorite', icon: Bookmark, label: 'Citation favorite', field: 'citation_favorite' },
  
  { id: 'mot-prefere', icon: Tag, label: 'Mot préféré', field: 'mot_prefere' },
  { id: 'langue-preferee', icon: Flag, label: 'Langue préférée', field: 'langue_preferee' },
  { id: 'destination-reve', icon: Anchor, label: 'Destination de rêve', field: 'destination_reve' },
  { id: 'moyen-transport', icon: Rocket, label: 'Moyen de transport préféré', field: 'moyen_transport' },
  { id: 'invention-utile', icon: Lightbulb, label: 'Invention la plus utile', field: 'invention_utile' },
  { id: 'application-preferee', icon: Smartphone, label: 'Application préférée', field: 'application_preferee' },
  { id: 'jeu-video', icon: Gamepad2, label: 'Jeu vidéo préféré', field: 'jeu_video' },
  { id: 'film-prefere', icon: Film, label: 'Film préféré', field: 'film_prefere' },
  { id: 'serie-preferee', icon: Tv, label: 'Série préférée', field: 'serie_preferee' },
  { id: 'artiste-prefere', icon: Palette, label: 'Artiste préféré', field: 'artiste_prefere' },
  
  { id: 'oeuvre-art', icon: Image, label: 'Œuvre d\'art favorite', field: 'oeuvre_art' },
  { id: 'musee-prefere', icon: Building, label: 'Musée préféré', field: 'musee_prefere' },
  { id: 'monument', icon: Landmark, label: 'Monument marquant', field: 'monument' },
  { id: 'plat-prefere', icon: UtensilsCrossed, label: 'Plat préféré', field: 'plat_prefere' },
  { id: 'restaurant-type', icon: ChefHat, label: 'Type de restaurant préféré', field: 'restaurant_type' },
  { id: 'cuisine-preferee', icon: CookingPot, label: 'Cuisine préférée', field: 'cuisine_preferee' },
  { id: 'recette-secrete', icon: Scroll, label: 'Recette secrète', field: 'recette_secrete' },
  { id: 'epice-preferee', icon: Flame, label: 'Épice préférée', field: 'epice_preferee' },
  { id: 'fromage-prefere', icon: Cake, label: 'Fromage préféré', field: 'fromage_prefere' },
  { id: 'chocolat-type', icon: Coffee, label: 'Type de chocolat préféré', field: 'chocolat_type' },
  
  { id: 'the-cafe', icon: Coffee, label: 'Thé ou café ?', field: 'the_cafe' },
  { id: 'petit-dejeuner', icon: Croissant, label: 'Petit-déjeuner idéal', field: 'petit_dejeuner' },
  { id: 'snack-prefere', icon: Apple, label: 'Snack préféré', field: 'snack_prefere' },
  { id: 'glace-parfum', icon: Snowflake, label: 'Parfum de glace préféré', field: 'glace_parfum' },
  { id: 'souvenir-enfance', icon: Baby, label: 'Souvenir d\'enfance', field: 'souvenir_enfance' },
  { id: 'jouet-enfance', icon: Puzzle, label: 'Jouet d\'enfance préféré', field: 'jouet_enfance' },
  { id: 'dessin-anime', icon: Sparkles, label: 'Dessin animé favori', field: 'dessin_anime' },
  { id: 'superheros', icon: Shield, label: 'Super-héros préféré', field: 'superheros' },
  { id: 'conte-fee', icon: Wand2, label: 'Conte de fées préféré', field: 'conte_fee' },
  { id: 'dernier-bonheur', icon: Heart, label: 'Dernier moment de bonheur', field: 'dernier_bonheur' },
];

export default function Profile() {
  const [selectedSymbol, setSelectedSymbol] = useState(null);
  const [formData, setFormData] = useState({});
  const [selectedColor, setSelectedColor] = useState(DMC_BASE_COLORS[0]);
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me(),
  });

  const { data: profile } = useQuery({
    queryKey: ['userProfile', user?.email],
    queryFn: async () => {
      if (!user) return null;
      const profiles = await base44.entities.UserProfile.filter({ created_by: user.email });
      return profiles[0] || null;
    },
    enabled: !!user,
  });

  const saveProfileMutation = useMutation({
    mutationFn: async (data) => {
      if (profile) {
        return await base44.entities.UserProfile.update(profile.id, data);
      } else {
        return await base44.entities.UserProfile.create(data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['userProfile'] });
      toast.success('Information enregistrée dans ton profil ✨');
      setSelectedSymbol(null);
    },
  });

  const handleSymbolClick = (symbol) => {
    setSelectedSymbol(symbol);
    
    // Charger les données existantes
    const savedData = profile?.profil_creatif?.grid_data?.[symbol.id];
    if (savedData) {
      setFormData({ [symbol.field]: savedData.value || '' });
      const color = DMC_BASE_COLORS.find(c => c.code === savedData.color);
      if (color) setSelectedColor(color);
    } else {
      setFormData({ [symbol.field]: '' });
      setSelectedColor(DMC_BASE_COLORS[0]);
    }
  };

  const handleSave = () => {
    if (!selectedSymbol) {
      toast.error('Clique d\'abord sur une case de la grille pour lier cette information');
      return;
    }
    
    if (!formData[selectedSymbol.field]) {
      toast.error('Renseigne au moins une information');
      return;
    }

    const gridData = profile?.profil_creatif?.grid_data || {};
    gridData[selectedSymbol.id] = {
      value: formData[selectedSymbol.field],
      color: selectedColor.code,
      filled: true
    };

    saveProfileMutation.mutate({
      profil_creatif: {
        ...profile?.profil_creatif,
        grid_data: gridData
      }
    });
  };

  // Vérifier si une case est remplie
  const isSymbolFilled = (symbolId) => {
    return profile?.profil_creatif?.grid_data?.[symbolId]?.filled || false;
  };

  // Obtenir la couleur d'une case remplie
  const getSymbolColor = (symbolId) => {
    const color = profile?.profil_creatif?.grid_data?.[symbolId]?.color;
    return DMC_BASE_COLORS.find(c => c.code === color) || DMC_BASE_COLORS[0];
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex flex-col">
      {/* Titre en haut à gauche */}
      <div className="px-8 pt-6 pb-4">
        <h1 className="text-2xl font-bold text-black">Mon Profil PatyBee</h1>
      </div>
      
      {/* Contenu principal */}
      <div className="flex-1 flex">
        {/* Grille 10×10 au centre */}
        <div className="flex-1 flex items-center justify-center p-8">
        <div className="grid grid-cols-10 gap-2">
          {PROFILE_SYMBOLS.map((symbol) => {
            const Icon = symbol.icon;
            const filled = isSymbolFilled(symbol.id);
            const color = filled ? getSymbolColor(symbol.id) : null;
            const isSelected = selectedSymbol?.id === symbol.id;

            return (
              <button
                key={symbol.id}
                onClick={() => handleSymbolClick(symbol)}
                className={`w-16 h-16 rounded-md flex items-center justify-center transition-all relative group ${
                  filled
                    ? 'shadow-md border border-slate-400'
                    : 'bg-gray-100 border border-gray-300 hover:border-gray-400'
                } ${
                  isSelected ? 'ring-4 ring-yellow-400 shadow-lg' : ''
                }`}
                style={filled ? { backgroundColor: color.hex } : {}}
                title={symbol.label}
              >
                <Icon className={`w-6 h-6 ${filled ? 'text-white' : 'text-gray-600'}`} strokeWidth={2} />
                
                {/* Tooltip */}
                <div className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-10 whitespace-nowrap">
                  <div className="bg-slate-900 text-white text-xs px-2 py-1 rounded">
                    {symbol.label}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
        </div>

        {/* Panneau latéral droit */}
        <div className="w-[30%] bg-white border-l border-slate-200 flex flex-col overflow-hidden">
        {!selectedSymbol ? (
          <div className="flex-1 flex items-center justify-center p-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-black rounded-lg mx-auto mb-4 flex items-center justify-center">
                <User className="w-8 h-8 text-white" />
              </div>
              <h2 className="text-xl font-bold text-slate-900 mb-2">Mon Profil PatyBee</h2>
              <p className="text-sm text-slate-600 leading-relaxed">
                Clique sur un symbole de la grille pour renseigner une information.
                <br /><br />
                Plus ta grille est complète, plus PatyBee pourra te proposer des grilles adaptées.
              </p>
            </div>
          </div>
        ) : (
          <div className="flex-1 flex flex-col">
            {/* Header */}
            <div className="p-6 border-b border-slate-200">
              <div className="flex items-center gap-3 mb-2">
                {React.createElement(selectedSymbol.icon, { className: 'w-8 h-8 text-black' })}
                <h2 className="text-xl font-bold text-slate-900">{selectedSymbol.label}</h2>
              </div>
              <p className="text-xs text-slate-500">
                Renseigne cette information pour que ta case devienne une couleur DMC dans ta grille profil.
              </p>
            </div>

            {/* Form */}
            <div className="flex-1 p-6 overflow-y-auto space-y-6">
              <div>
                <label className="text-sm font-medium text-slate-700 mb-2 block">
                  Ta réponse
                </label>
                <Textarea
                  placeholder="Écris ta réponse ici..."
                  value={formData[selectedSymbol.field] || ''}
                  onChange={(e) => setFormData({ ...formData, [selectedSymbol.field]: e.target.value })}
                  className="min-h-[120px]"
                />
              </div>

              {/* Sélecteur de couleur DMC */}
              <div>
                <label className="text-sm font-medium text-slate-700 mb-3 block">
                  Choisis une couleur DMC pour représenter cette information
                </label>
                <div className="grid grid-cols-5 gap-2">
                  {DMC_BASE_COLORS.map((color) => (
                    <button
                      key={color.code}
                      onClick={() => setSelectedColor(color)}
                      className={`w-full aspect-square rounded-lg border-2 transition-all ${
                        selectedColor.code === color.code
                          ? 'border-black scale-110 shadow-md'
                          : 'border-slate-300 hover:border-slate-400'
                      }`}
                      style={{ backgroundColor: color.hex }}
                      title={`${color.name} (${color.code})`}
                    />
                  ))}
                </div>
                <p className="text-xs text-slate-500 mt-2">
                  Couleur sélectionnée : <strong>{selectedColor.name}</strong> ({selectedColor.code})
                </p>
              </div>

              {/* Info */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg">
                <p className="text-xs text-slate-600">
                  <strong>Cette information sera utilisée pour :</strong>
                  <br />• Adapter les recommandations de modèles
                  <br />• Personnaliser les propositions de palettes
                  <br />• Créer ton profil créatif unique
                </p>
              </div>
            </div>

            {/* Actions */}
            <div className="p-6 border-t border-slate-200 space-y-3">
              <Button
                onClick={handleSave}
                className="w-full bg-black hover:bg-slate-800 text-white"
                disabled={!formData[selectedSymbol.field] || saveProfileMutation.isPending}
              >
                {saveProfileMutation.isPending ? 'Enregistrement...' : 'Enregistrer cette information'}
              </Button>
              
              <Button
                onClick={() => setSelectedSymbol(null)}
                variant="outline"
                className="w-full bg-slate-50 hover:bg-slate-100 text-slate-900"
              >
                Annuler
              </Button>
            </div>
          </div>
        )}
        </div>
      </div>
    </div>
  );
}