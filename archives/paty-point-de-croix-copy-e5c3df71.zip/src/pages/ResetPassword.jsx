import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '../utils';
import { toast } from 'sonner';
import { CheckCircle2 } from 'lucide-react';

// Logo PatyBee
function PatyBeeLogo() {
  return (
    <svg width="52" height="52" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
      <style>
        {`
          @keyframes star-anim {
            0%, 100% { fill: #FFFFFF; transform: rotate(0deg); }
            5% { fill: #F5C200; }
            20% { fill: #F5C200; transform: rotate(360deg); }
            22%, 100% { fill: #FFFFFF; transform: rotate(360deg); }
          }
          
          @keyframes diamond-anim {
            0%, 22%, 100% { fill: #FFFFFF; transform: rotate(0deg); }
            27% { fill: #2F80ED; }
            42% { fill: #2F80ED; transform: rotate(15deg); }
            44%, 100% { fill: #FFFFFF; transform: rotate(0deg); }
          }
          
          @keyframes circle-anim {
            0%, 44%, 100% { fill: #FFFFFF; opacity: 1; }
            49% { fill: #27AE60; opacity: 1; }
            55% { fill: #27AE60; opacity: 0.4; }
            61% { fill: #27AE60; opacity: 1; }
            64%, 100% { fill: #FFFFFF; opacity: 1; }
          }
          
          @keyframes square-anim {
            0%, 64%, 100% { fill: #FFFFFF; transform: rotate(0deg); }
            69% { fill: #EB5BA9; }
            79% { fill: #EB5BA9; transform: rotate(90deg); }
            84% { fill: #EB5BA9; transform: rotate(0deg); }
            86%, 100% { fill: #FFFFFF; transform: rotate(0deg); }
          }
          
          .star { 
            animation: star-anim 3.7s ease-in-out infinite;
            transform-origin: 9px 8.5px;
          }
          .circle { 
            animation: circle-anim 3.7s ease-in-out infinite;
          }
          .square { 
            animation: square-anim 3.7s ease-in-out infinite;
            transform-origin: 7.5px 26px;
          }
          .diamond { 
            animation: diamond-anim 3.7s ease-in-out infinite;
            transform-origin: 26.5px 26px;
          }
        `}
      </style>
      
      <path className="star" d="M9 2L10.5 7L15.5 8.5L10.5 10L9 15L7.5 10L2.5 8.5L7.5 7L9 2Z" fill="#FFFFFF"/>
      <circle className="circle" cx="26.5" cy="9" r="5" fill="#FFFFFF"/>
      <rect className="square" x="2.5" y="21" width="10" height="10" fill="#FFFFFF"/>
      <path className="diamond" d="M26.5 21L31.5 26L26.5 31L21.5 26L26.5 21Z" fill="#FFFFFF"/>
    </svg>
  );
}

export default function ResetPasswordPage() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);

    // Simuler l'envoi d'email
    setTimeout(() => {
      setIsLoading(false);
      setSuccess(true);
      toast.success('Email de réinitialisation envoyé !');
    }, 1500);
  };

  return (
    <div 
      className="min-h-screen flex items-center justify-center"
      style={{ backgroundColor: 'rgba(0, 0, 0, 0.92)' }}
    >
      <div className="w-full max-w-md px-8">
        {/* Logo et titre */}
        <div className="flex flex-col items-center mb-8">
          <PatyBeeLogo />
          <h1 className="text-white text-3xl font-semibold mt-4 tracking-wide">
            Réinitialiser le mot de passe
          </h1>
          <p className="text-gray-400 text-sm mt-2 text-center">
            Entrez votre email pour recevoir un lien de réinitialisation
          </p>
        </div>

        {success ? (
          <div className="space-y-6">
            <div className="bg-green-900/20 border border-green-500/50 rounded-lg p-6 text-center">
              <CheckCircle2 className="w-12 h-12 text-green-400 mx-auto mb-4" />
              <p className="text-green-400 font-medium mb-2">
                Email envoyé avec succès !
              </p>
              <p className="text-gray-300 text-sm">
                Vérifiez votre boîte de réception et suivez les instructions pour réinitialiser votre mot de passe.
              </p>
            </div>

            <Button
              onClick={() => navigate(createPageUrl('Login'))}
              className="w-full bg-black border border-gray-700 text-white hover:bg-[#1a1a1a] rounded-lg h-12 text-base"
            >
              Retour à la connexion
            </Button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Email */}
            <div className="space-y-2">
              <Label htmlFor="email" className="text-white text-sm">
                Email
              </Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="votre@email.com"
                className="bg-[#1a1a1a] border-[#333] text-white placeholder:text-gray-500"
                required
              />
            </div>

            {/* Bouton */}
            <Button
              type="submit"
              disabled={isLoading}
              className="w-full bg-black border border-gray-700 text-white hover:bg-[#1a1a1a] rounded-lg h-12 text-base"
            >
              {isLoading ? 'Envoi en cours...' : 'Envoyer le lien de réinitialisation'}
            </Button>

            {/* Retour connexion */}
            <div className="text-center">
              <button
                type="button"
                onClick={() => navigate(createPageUrl('Login'))}
                className="text-sm text-gray-400 hover:text-white transition-colors"
              >
                ← Retour à la connexion
              </button>
            </div>
          </form>
        )}

        {/* Retour accueil */}
        <div className="mt-8 text-center">
          <button
            onClick={() => navigate(createPageUrl('GridEditor'))}
            className="text-sm text-gray-500 hover:text-gray-300 transition-colors"
          >
            ← Retour à l'accueil
          </button>
        </div>
      </div>
    </div>
  );
}