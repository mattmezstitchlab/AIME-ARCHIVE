import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '../utils';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  ArrowLeft,
  ShoppingBag,
  CheckCircle2,
  Euro,
  Wallet,
  CreditCard,
  Grid3x3,
  Eye
} from 'lucide-react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

export default function VendreCreation() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  
  const [selectedProjectId, setSelectedProjectId] = useState(null);
  const [creationName, setCreationName] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [showBankingDialog, setShowBankingDialog] = useState(false);
  const [bankingInfo, setBankingInfo] = useState({
    firstName: '',
    lastName: '',
    iban: '',
    bic: '',
    address: ''
  });

  const { data: user } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me(),
  });

  const { data: projects, isLoading: projectsLoading } = useQuery({
    queryKey: ['projects', user?.email],
    queryFn: async () => {
      if (!user) return [];
      const grids = await base44.entities.Grid.filter({ created_by: user.email });
      return grids.sort((a, b) => new Date(b.updated_date) - new Date(a.updated_date));
    },
    enabled: !!user,
    initialData: []
  });

  const { data: creatorRevenue } = useQuery({
    queryKey: ['creator-revenue', user?.email],
    queryFn: async () => {
      if (!user) return null;
      const revenues = await base44.entities.CreatorRevenue.filter({ creator_email: user.email });
      return revenues[0] || null;
    },
    enabled: !!user,
  });

  const publishMutation = useMutation({
    mutationFn: async (data) => {
      // Générer le fichier .PBX (simulé pour le moment)
      const pbxData = {
        projectId: data.projectId,
        gridData: data.gridData,
        metadata: {
          author: user.email,
          authorName: user.full_name,
          title: data.title,
          price: data.price,
          createdAt: new Date().toISOString()
        }
      };

      // Créer l'entrée dans ShopGrid
      return await base44.entities.ShopGrid.create({
        title: data.title,
        description: data.description,
        preview_image: data.gridData.pattern?.sourceImage,
        grid_data: data.gridData,
        creator_name: user.full_name,
        creator_email: user.email,
        is_author_confirmed: true,
        original_grid_id: data.projectId,
        pattern_size: {
          width: data.gridData.nb_colonnes,
          height: data.gridData.nb_lignes
        }
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['shop-grids'] });
      toast.success('Ta création a été mise en vente dans la boutique PatyBee !');
      setTimeout(() => {
        navigate(createPageUrl('Shop'));
      }, 1500);
    },
  });

  const selectedProject = projects.find(p => p.id === selectedProjectId);

  const priceNum = parseFloat(price) || 0;
  const commission = priceNum * 0.22;
  const creatorGain = priceNum * 0.78;

  const canPublish = selectedProjectId && creationName.trim() && priceNum > 0;

  const handlePublish = () => {
    if (!canPublish) return;

    publishMutation.mutate({
      projectId: selectedProjectId,
      title: creationName,
      description,
      price: priceNum,
      gridData: selectedProject
    });
  };

  const handleSaveBanking = () => {
    // TODO: Sauvegarder les infos bancaires
    toast.success('Informations bancaires enregistrées');
    setShowBankingDialog(false);
  };

  // Calculer les statistiques du projet sélectionné
  const projectStats = selectedProject ? {
    totalPoints: selectedProject.pattern?.symbolGrid?.flat().filter(c => c).length || 0,
    colors: selectedProject.pattern?.colorPalette?.length || 0
  } : null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="container mx-auto px-8 py-8 max-w-6xl">
        {/* Header */}
        <div className="mb-8">
          <Button
            onClick={() => navigate(createPageUrl('Projects'))}
            variant="outline"
            className="gap-2 mb-4"
          >
            <ArrowLeft className="w-4 h-4" />
            Retour
          </Button>
          
          <h1 className="text-4xl font-bold text-slate-900 mb-2">Vendre une création</h1>
          <p className="text-slate-600">
            Choisis une grille, prépare ton fichier .PBX et mets-la en vente dans la boutique PatyBee.
          </p>
        </div>

        <div className="space-y-6">
          {/* Bloc 1 - Sélectionner une grille */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <span className="w-8 h-8 rounded-full bg-slate-900 text-white flex items-center justify-center text-sm">1</span>
                Sélectionner une grille
              </CardTitle>
              <CardDescription>
                Choisis le projet que tu veux mettre en vente
              </CardDescription>
            </CardHeader>
            <CardContent>
              {projectsLoading ? (
                <p className="text-slate-600">Chargement de tes projets...</p>
              ) : projects.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-slate-600 mb-4">Tu n'as pas encore de projet à vendre</p>
                  <Button onClick={() => navigate(createPageUrl('GridEditor'))}>
                    Créer un projet
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  <Select value={selectedProjectId || ''} onValueChange={setSelectedProjectId}>
                    <SelectTrigger>
                      <SelectValue placeholder="Sélectionne un projet" />
                    </SelectTrigger>
                    <SelectContent>
                      {projects.map((project) => (
                        <SelectItem key={project.id} value={project.id}>
                          {project.name} ({project.nb_colonnes} × {project.nb_lignes})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  {selectedProject && (
                    <div className="bg-slate-50 rounded-lg p-4 border border-slate-200">
                      <div className="flex gap-4">
                        {selectedProject.pattern?.sourceImage && (
                          <div className="w-24 h-24 rounded border border-slate-300 overflow-hidden flex-shrink-0">
                            <img
                              src={selectedProject.pattern.sourceImage}
                              alt={selectedProject.name}
                              className="w-full h-full object-cover"
                            />
                          </div>
                        )}
                        <div className="flex-1">
                          <h3 className="font-semibold text-slate-900 mb-2">{selectedProject.name}</h3>
                          <div className="space-y-1 text-sm text-slate-600">
                            <p>Dimensions : {selectedProject.nb_colonnes} × {selectedProject.nb_lignes}</p>
                            {projectStats && (
                              <>
                                <p>Nombre de couleurs : {projectStats.colors}</p>
                                <p>Nombre de points : {projectStats.totalPoints.toLocaleString('fr-FR')}</p>
                              </>
                            )}
                          </div>
                          <div className="mt-3 flex items-center gap-2 text-xs text-green-600">
                            <CheckCircle2 className="w-4 h-4" />
                            Fichier .PBX prêt à être généré pour cette grille
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Bloc 2 - Configurer l'offre */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <span className="w-8 h-8 rounded-full bg-slate-900 text-white flex items-center justify-center text-sm">2</span>
                Configurer ton offre
              </CardTitle>
              <CardDescription>
                Définis le nom, la description et le prix de ta création
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Nom de la création *
                </label>
                <Input
                  placeholder="ex: Abeille vintage sur fleurs de lys"
                  value={creationName}
                  onChange={(e) => setCreationName(e.target.value)}
                  disabled={!selectedProjectId}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Description courte
                </label>
                <Textarea
                  placeholder="Décris ta création : niveau de difficulté, taille finale, types de points utilisés..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  disabled={!selectedProjectId}
                  rows={3}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Prix de vente (TTC) *
                </label>
                <div className="relative">
                  <Input
                    type="number"
                    step="0.01"
                    min="0"
                    placeholder="10.00"
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    disabled={!selectedProjectId}
                    className="pr-12"
                  />
                  <Euro className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                </div>
                
                <div className="mt-3 p-3 bg-slate-50 rounded-lg border border-slate-200 text-sm">
                  <p className="text-slate-600 mb-2">
                    Vous recevrez <strong>78 %</strong> du montant de chaque vente. PatyBee garde <strong>22 %</strong> de commission pour le fonctionnement du site.
                  </p>
                  {priceNum > 0 && (
                    <div className="space-y-1 text-slate-700">
                      <p>• Votre gain par vente : <strong className="text-green-600">{creatorGain.toFixed(2)} €</strong></p>
                      <p>• Commission PatyBee (22 %) : <strong>{commission.toFixed(2)} €</strong></p>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Bloc 3 - Paiements & portefeuille */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <span className="w-8 h-8 rounded-full bg-slate-900 text-white flex items-center justify-center text-sm">3</span>
                Paiements & portefeuille
              </CardTitle>
              <CardDescription>
                Configure tes informations de paiement et consulte ton solde
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Infos bancaires */}
              <div>
                <h3 className="font-semibold text-slate-900 mb-2">Informations bancaires</h3>
                <p className="text-sm text-slate-600 mb-4">
                  Pour recevoir l'argent de tes ventes, tu peux renseigner tes informations bancaires.
                  Tu peux aussi laisser l'argent dans ton portefeuille PatyBee et l'utiliser pour acheter d'autres grilles.
                </p>
                <Button
                  variant="outline"
                  onClick={() => setShowBankingDialog(true)}
                  className="gap-2"
                >
                  <CreditCard className="w-4 h-4" />
                  Configurer mes informations bancaires
                </Button>
                <p className="text-xs text-slate-500 mt-3">
                  Sans informations bancaires, tes gains restent dans ton portefeuille et peuvent être utilisés pour acheter des grilles sur PatyBee. Tu pourras les transférer plus tard sur ton compte bancaire.
                </p>
              </div>

              {/* Portefeuille */}
              <div>
                <h3 className="font-semibold text-slate-900 mb-3 flex items-center gap-2">
                  <Wallet className="w-5 h-5" />
                  Ton portefeuille PatyBee
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <p className="text-xs text-green-700 mb-1">Solde disponible</p>
                    <p className="text-2xl font-bold text-green-900">
                      {(creatorRevenue?.available_balance || 0).toFixed(2)} €
                    </p>
                  </div>
                  <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                    <p className="text-xs text-amber-700 mb-1">En attente de transfert</p>
                    <p className="text-2xl font-bold text-amber-900">
                      {((creatorRevenue?.total_revenue || 0) - (creatorRevenue?.withdrawn_amount || 0) - (creatorRevenue?.available_balance || 0)).toFixed(2)} €
                    </p>
                  </div>
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <p className="text-xs text-blue-700 mb-1">Ventes confirmées</p>
                    <p className="text-2xl font-bold text-blue-900">
                      {(creatorRevenue?.total_revenue || 0).toFixed(2)} €
                    </p>
                  </div>
                </div>
                <div className="mt-4 flex gap-3">
                  <Button variant="outline" size="sm" onClick={() => navigate(createPageUrl('Shop'))}>
                    Utiliser mon solde pour acheter des grilles
                  </Button>
                  <Button variant="outline" size="sm" disabled>
                    Demander un virement bancaire
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Actions finales */}
          <div className="flex items-center justify-between pt-4">
            <Button
              variant="outline"
              onClick={() => navigate(createPageUrl('Projects'))}
            >
              Annuler
            </Button>
            <Button
              onClick={handlePublish}
              disabled={!canPublish || publishMutation.isPending}
              className="bg-green-600 hover:bg-green-700 text-white gap-2"
              size="lg"
            >
              <ShoppingBag className="w-5 h-5" />
              {publishMutation.isPending ? 'Mise en vente...' : 'Mettre en vente'}
            </Button>
          </div>
        </div>
      </div>

      {/* Dialog infos bancaires */}
      <Dialog open={showBankingDialog} onOpenChange={setShowBankingDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Informations bancaires</DialogTitle>
            <DialogDescription>
              Renseigne tes coordonnées bancaires pour recevoir tes paiements
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Prénom</label>
                <Input
                  value={bankingInfo.firstName}
                  onChange={(e) => setBankingInfo({ ...bankingInfo, firstName: e.target.value })}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Nom</label>
                <Input
                  value={bankingInfo.lastName}
                  onChange={(e) => setBankingInfo({ ...bankingInfo, lastName: e.target.value })}
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">IBAN</label>
              <Input
                placeholder="FR76 XXXX XXXX XXXX XXXX XXXX XXX"
                value={bankingInfo.iban}
                onChange={(e) => setBankingInfo({ ...bankingInfo, iban: e.target.value })}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">BIC</label>
              <Input
                placeholder="XXXXFRPP"
                value={bankingInfo.bic}
                onChange={(e) => setBankingInfo({ ...bankingInfo, bic: e.target.value })}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Adresse de facturation</label>
              <Textarea
                placeholder="Adresse complète"
                value={bankingInfo.address}
                onChange={(e) => setBankingInfo({ ...bankingInfo, address: e.target.value })}
                rows={2}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowBankingDialog(false)}>
              Annuler
            </Button>
            <Button onClick={handleSaveBanking} className="bg-slate-900 hover:bg-slate-800">
              Enregistrer mes informations bancaires
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}