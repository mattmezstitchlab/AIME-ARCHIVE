import React from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { ShoppingBag, Package } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '../utils';

export default function MyPurchases() {
  const navigate = useNavigate();
  
  const { data: user } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me(),
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <div className="bg-white border-b border-slate-200 px-8 py-6">
        <div className="container mx-auto">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Mes achats</h1>
          <p className="text-slate-600">Accédez à toutes vos grilles achetées</p>
        </div>
      </div>

      <div className="container mx-auto px-8 py-8">
        {/* Statistiques */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-xl shadow-md border border-slate-200 p-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                <ShoppingBag className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-slate-600">Grilles achetées</p>
                <p className="text-2xl font-bold text-slate-900">0</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-md border border-slate-200 p-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-purple-100 flex items-center justify-center">
                <Package className="w-5 h-5 text-purple-600" />
              </div>
              <div>
                <p className="text-sm text-slate-600">Montant total dépensé</p>
                <p className="text-2xl font-bold text-slate-900">0.00€</p>
              </div>
            </div>
          </div>
        </div>

        {/* Liste des achats */}
        <div className="bg-white rounded-xl shadow-md border border-slate-200 p-6">
          <h2 className="text-xl font-bold text-slate-900 mb-4">Vos grilles</h2>
          
          <div className="text-center py-12">
            <ShoppingBag className="w-16 h-16 text-slate-300 mx-auto mb-4" />
            <p className="text-slate-600 mb-2">Vous n'avez pas encore acheté de grille</p>
            <p className="text-sm text-slate-500 mb-4">
              Explorez la Boutique pour découvrir des créations uniques
            </p>
            <Button
              onClick={() => navigate(createPageUrl('Shop'))}
              className="bg-slate-900 hover:bg-slate-800"
            >
              Parcourir la Boutique
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}