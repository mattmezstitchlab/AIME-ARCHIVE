import React from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { DollarSign, TrendingUp, ShoppingBag, Users } from 'lucide-react';

export default function AdminRevenue() {
  const { data: transactions } = useQuery({
    queryKey: ['all-transactions'],
    queryFn: () => base44.entities.Transaction.list(),
    initialData: []
  });

  const { data: allBalances } = useQuery({
    queryKey: ['all-balances'],
    queryFn: () => base44.entities.CreatorBalance.list(),
    initialData: []
  });

  const { data: shopGrids } = useQuery({
    queryKey: ['all-shop-grids'],
    queryFn: () => base44.entities.ShopGrid.list(),
    initialData: []
  });

  // Calculer les statistiques globales
  const totalPlatformRevenue = transactions.reduce(
    (sum, t) => sum + (t.platform_share || 0), 
    0
  );

  const totalCreatorRevenue = transactions.reduce(
    (sum, t) => sum + (t.creator_share || 0), 
    0
  );

  const totalSales = transactions.length;
  const totalGrids = shopGrids.length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <header className="bg-white border-b border-slate-200 px-8 py-6">
        <div className="container mx-auto">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">
            Revenus PATYBEE - Administration
          </h1>
          <p className="text-slate-600">Vue d'ensemble des revenus de la plateforme</p>
        </div>
      </header>

      <div className="container mx-auto px-8 py-8 space-y-8">
        {/* Statistiques principales */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-xl shadow-lg p-6 text-white">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-12 h-12 rounded-lg bg-white/20 flex items-center justify-center">
                <DollarSign className="w-6 h-6" />
              </div>
              <div>
                <p className="text-sm opacity-90">Revenus PATYBEE</p>
                <p className="text-3xl font-bold">
                  {totalPlatformRevenue.toFixed(2)}€
                </p>
              </div>
            </div>
            <p className="text-xs opacity-80 mt-2">
              Commission 30% sur toutes les ventes
            </p>
          </div>

          <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl shadow-lg p-6 text-white">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-12 h-12 rounded-lg bg-white/20 flex items-center justify-center">
                <Users className="w-6 h-6" />
              </div>
              <div>
                <p className="text-sm opacity-90">Revenus créateurs</p>
                <p className="text-3xl font-bold">
                  {totalCreatorRevenue.toFixed(2)}€
                </p>
              </div>
            </div>
            <p className="text-xs opacity-80 mt-2">
              70% reversés aux créateurs
            </p>
          </div>

          <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl shadow-lg p-6 text-white">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-12 h-12 rounded-lg bg-white/20 flex items-center justify-center">
                <ShoppingBag className="w-6 h-6" />
              </div>
              <div>
                <p className="text-sm opacity-90">Ventes totales</p>
                <p className="text-3xl font-bold">{totalSales}</p>
              </div>
            </div>
            <p className="text-xs opacity-80 mt-2">
              Nombre de transactions
            </p>
          </div>

          <div className="bg-gradient-to-br from-amber-500 to-amber-600 rounded-xl shadow-lg p-6 text-white">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-12 h-12 rounded-lg bg-white/20 flex items-center justify-center">
                <TrendingUp className="w-6 h-6" />
              </div>
              <div>
                <p className="text-sm opacity-90">Grilles publiées</p>
                <p className="text-3xl font-bold">{totalGrids}</p>
              </div>
            </div>
            <p className="text-xs opacity-80 mt-2">
              Dans la boutique
            </p>
          </div>
        </div>

        {/* Top créateurs */}
        <div className="bg-white rounded-xl shadow-md border border-slate-200 p-6">
          <h2 className="text-xl font-bold text-slate-900 mb-4">
            Top créateurs par revenus
          </h2>
          
          {allBalances.length === 0 ? (
            <p className="text-slate-600 text-center py-8">
              Aucune donnée disponible
            </p>
          ) : (
            <div className="space-y-3">
              {allBalances
                .sort((a, b) => (b.total_revenue || 0) - (a.total_revenue || 0))
                .slice(0, 10)
                .map((balance, index) => (
                  <div
                    key={balance.id}
                    className="flex items-center justify-between p-4 bg-slate-50 rounded-lg"
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center font-bold text-purple-600">
                        {index + 1}
                      </div>
                      <div>
                        <p className="font-medium text-slate-900">
                          {balance.creator_email}
                        </p>
                        <p className="text-sm text-slate-600">
                          {balance.total_sales || 0} ventes
                        </p>
                      </div>
                    </div>
                    
                    <p className="font-bold text-green-600 text-lg">
                      {(balance.total_revenue || 0).toFixed(2)}€
                    </p>
                  </div>
                ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}