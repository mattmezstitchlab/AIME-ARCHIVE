import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import BeethovenLibrary from '../components/beethoven/BeethovenLibrary';
import { createPageUrl } from '../utils';

export default function BeethovenPage() {
  const navigate = useNavigate();
  const [selectedSymbol, setSelectedSymbol] = useState(
    localStorage.getItem('beethoven_active_symbol') || null
  );

  const handleSymbolSelect = (symbol) => {
    setSelectedSymbol(symbol);
    localStorage.setItem('beethoven_active_symbol', symbol);
  };

  const handleBackToEditor = () => {
    navigate(createPageUrl('GridEditor'));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Bouton retour */}
        <div className="mb-6 flex justify-between items-center">
          <Button
            variant="outline"
            onClick={handleBackToEditor}
            className="gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Retour à l'éditeur
          </Button>
          
          {selectedSymbol && (
            <Button
              onClick={handleBackToEditor}
              className="bg-slate-900 hover:bg-slate-800"
            >
              Utiliser dans l'éditeur
            </Button>
          )}
        </div>

        {/* Bibliothèque */}
        <BeethovenLibrary
          onSymbolSelect={handleSymbolSelect}
          selectedSymbol={selectedSymbol}
        />
      </div>
    </div>
  );
}