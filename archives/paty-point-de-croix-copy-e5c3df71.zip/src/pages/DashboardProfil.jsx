import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { createPageUrl } from '../utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import {
  User, Settings, FolderOpen, ShoppingBag,
  Camera, Edit2, Check, Trash2, Play, Pencil,
  SlidersHorizontal, Clock, Ruler, Palette, Eye,
  Accessibility, Bell, Save, Cloud, FileDown,
  Puzzle, Bot, MessageSquare, Lock, RotateCcw,
  Crown, ChevronRight, Home, Sparkles, Filter
} from 'lucide-react';

export default function DashboardProfil() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  
  // Lire le paramètre tab depuis l'URL
  const urlParams = new URLSearchParams(window.location.search);
  const initialTab = urlParams.get('tab') || 'infos';
  const [activeTab, setActiveTab] = useState(initialTab);
  const [projectFilter, setProjectFilter] = useState('all'); // all, inProgress, done
  const [editingProjectId, setEditingProjectId] = useState(null);
  const [editingProjectName, setEditingProjectName] = useState('');

  // Fetch user data
  const { data: user, isLoading: userLoading } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  // Fetch user profile
  const { data: profiles } = useQuery({
    queryKey: ['userProfile', user?.email],
    queryFn: () => base44.entities.UserProfile.filter({ created_by: user?.email }),
    enabled: !!user?.email,
  });

  // Fetch user projects - sorted by most recent
  const { data: projects = [] } = useQuery({
    queryKey: ['myProjects', user?.email],
    queryFn: () => base44.entities.Grid.filter({ created_by: user?.email }, '-updated_date'),
    enabled: !!user?.email,
  });

  const profile = profiles?.[0] || {};

  // Local state for editing
  const [formData, setFormData] = useState({
    prenom: '',
    nom: '',
    pays: '',
    adresse_actuelle: '',
  });

  useEffect(() => {
    if (profile) {
      setFormData({
        prenom: profile.prenom || '',
        nom: profile.nom || '',
        pays: profile.pays || '',
        adresse_actuelle: profile.adresse_actuelle || '',
      });
    }
  }, [profile]);

  // Calculate profile completion
  const calculateCompletion = () => {
    const fields = ['prenom', 'nom', 'pays', 'photo_url', 'adresse_actuelle'];
    const filled = fields.filter(f => profile?.[f]).length;
    return Math.round((filled / fields.length) * 100);
  };

  // Settings state (from localStorage) with defaults
  const [settings, setSettings] = useState(() => {
    const saved = localStorage.getItem('patybee_dashboard_settings');
    return saved ? JSON.parse(saved) : {
      difficulty: 'Moyen',
      maxTime: 'Illimité',
      gridSize: 'Moyenne',
      visualStyle: 'Réaliste',
      colorMode: 'Couleurs',
      displayMode: 'Mix',
      accessibility: false,
      notifications: true,
      autoSave: true,
      cloudSync: true,
      exportFormat: 'PDF',
      guidedMode: false,
      aiHelp: 'Assistée',
      language: 'Français',
      privacy: 'Privé',
    };
  });

  const updateSetting = (key, value) => {
    const newSettings = { ...settings, [key]: value };
    setSettings(newSettings);
    localStorage.setItem('patybee_dashboard_settings', JSON.stringify(newSettings));
    toast.success('✅ Réglages mis à jour');
  };

  // Settings grid items - 16 items in 4x4 grid
  const settingsItems = [
    { icon: SlidersHorizontal, label: 'Difficulté', key: 'difficulty', type: 'select', options: ['Simple', 'Moyen', 'Avancé'] },
    { icon: Clock, label: 'Temps max', key: 'maxTime', type: 'select', options: ['Court', 'Moyen', 'Long', 'Illimité'] },
    { icon: Ruler, label: 'Taille grilles', key: 'gridSize', type: 'select', options: ['Petite', 'Moyenne', 'Grande'] },
    { icon: Palette, label: 'Style visuel', key: 'visualStyle', type: 'select', options: ['Réaliste', 'Pixel', 'Minimal'] },
    { icon: Palette, label: 'Mode couleur', key: 'colorMode', type: 'select', options: ['Couleurs', 'N&B', 'Mix'] },
    { icon: Eye, label: 'Affichage', key: 'displayMode', type: 'select', options: ['Symboles', 'Couleurs', 'Mix'] },
    { icon: Accessibility, label: 'Accessibilité', key: 'accessibility', type: 'toggle', desc: 'Zoom / Gros symboles' },
    { icon: Bell, label: 'Notifications', key: 'notifications', type: 'toggle' },
    { icon: Save, label: 'Sauvegarde auto', key: 'autoSave', type: 'toggle', default: true },
    { icon: Cloud, label: 'Cloud', key: 'cloudSync', type: 'toggle' },
    { icon: FileDown, label: 'Export', key: 'exportFormat', type: 'select', options: ['PDF', 'PNG', 'PatyBee'] },
    { icon: Puzzle, label: 'Mode guidé', key: 'guidedMode', type: 'toggle' },
    { icon: Bot, label: 'Aide IA', key: 'aiHelp', type: 'select', options: ['Basique', 'Assistée', 'Expert'] },
    { icon: MessageSquare, label: 'Langue', key: 'language', type: 'select', options: ['FR', 'EN', 'ES'] },
    { icon: Lock, label: 'Confidentialité', key: 'privacy', type: 'select', options: ['Public', 'Privé', 'Masqué'] },
    { icon: RotateCcw, label: 'Réinitialiser', key: 'reset', type: 'action' },
  ];

  // Filter projects
  const filteredProjects = projects.filter(p => {
    if (projectFilter === 'all') return true;
    const progress = calculateProjectProgress(p);
    if (projectFilter === 'inProgress') return progress < 100;
    if (projectFilter === 'done') return progress === 100;
    return true;
  });

  // Calculate project progress
  function calculateProjectProgress(project) {
    if (!project?.pattern?.symbolGrid) return 0;
    const allCells = project.pattern.symbolGrid.flat().filter(c => c);
    if (allCells.length === 0) return 0;
    const done = allCells.filter(c => c.done).length;
    return Math.round((done / allCells.length) * 100);
  }

  const deleteProject = useMutation({
    mutationFn: (id) => base44.entities.Grid.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['myProjects']);
      toast.success('✅ Projet supprimé');
    },
  });

  const renameProject = useMutation({
    mutationFn: ({ id, name }) => base44.entities.Grid.update(id, { name }),
    onSuccess: () => {
      queryClient.invalidateQueries(['myProjects']);
      setEditingProjectId(null);
      toast.success('✅ Projet renommé');
    },
  });

  const updateProfile = useMutation({
    mutationFn: async (data) => {
      if (profiles?.[0]?.id) {
        return base44.entities.UserProfile.update(profiles[0].id, data);
      } else {
        return base44.entities.UserProfile.create(data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['userProfile']);
      toast.success('✅ Changements enregistrés');
    },
  });

  if (userLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-amber-500 border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 pb-24">
      {/* HEADER UTILISATEUR */}
      <div className="bg-white border-b border-slate-200 px-6 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-6">
            {/* Avatar */}
            <div className="relative">
              <Avatar className="w-24 h-24 border-4 border-white shadow-lg">
                <AvatarImage src={profile?.photo_url} />
                <AvatarFallback className="bg-amber-100 text-amber-700 text-2xl font-bold">
                  {user?.full_name?.charAt(0) || 'U'}
                </AvatarFallback>
              </Avatar>
              <button className="absolute bottom-0 right-0 w-8 h-8 bg-amber-500 rounded-full flex items-center justify-center text-white shadow-lg hover:bg-amber-600 transition-colors">
                <Camera className="w-4 h-4" />
              </button>
            </div>

            {/* Infos */}
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-1">
                <h1 className="text-2xl font-bold text-slate-900">
                  {profile?.prenom || user?.full_name || 'Utilisateur'}
                </h1>
                <Badge variant={user?.role === 'admin' ? 'default' : 'secondary'} className="gap-1">
                  {user?.role === 'admin' ? <Crown className="w-3 h-3" /> : null}
                  {user?.role === 'admin' ? 'Premium' : 'Gratuit'}
                </Badge>
              </div>
              <p className="text-slate-500 mb-3">{user?.email}</p>
              
              {/* Progress */}
              <div className="flex items-center gap-3">
                <span className="text-sm text-slate-600">Profil complété :</span>
                <Progress value={calculateCompletion()} className="w-32 h-2" />
                <span className="text-sm font-medium text-amber-600">{calculateCompletion()}%</span>
              </div>
            </div>

            {/* Actions */}
            <Button 
              variant="outline" 
              className="gap-2"
              onClick={() => {
                setActiveTab('infos');
                // Scroll vers la section après un court délai
                setTimeout(() => {
                  document.getElementById('mes-infos-section')?.scrollIntoView({ behavior: 'smooth' });
                }, 100);
              }}
            >
              <Edit2 className="w-4 h-4" />
              Modifier mon profil
            </Button>
          </div>
        </div>
      </div>

      {/* TABS */}
      <div className="max-w-4xl mx-auto px-6 py-6">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-4 mb-6">
            <TabsTrigger value="infos" className="gap-2">
              <User className="w-4 h-4" />
              Mes Infos
            </TabsTrigger>
            <TabsTrigger value="settings" className="gap-2">
              <Settings className="w-4 h-4" />
              Réglages
            </TabsTrigger>
            <TabsTrigger value="projects" className="gap-2">
              <FolderOpen className="w-4 h-4" />
              Mes Projets
            </TabsTrigger>
            <TabsTrigger value="shop" className="gap-2">
              <ShoppingBag className="w-4 h-4" />
              Boutique
            </TabsTrigger>
          </TabsList>

          {/* SECTION 1 - MES INFOS */}
          <TabsContent value="infos" id="mes-infos-section">
            <Card>
              <CardContent className="p-6 space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Prénom</Label>
                    <Input 
                      value={formData.prenom} 
                      onChange={(e) => setFormData({...formData, prenom: e.target.value})}
                      placeholder="Votre prénom"
                    />
                  </div>
                  <div>
                    <Label>Nom</Label>
                    <Input 
                      value={formData.nom} 
                      onChange={(e) => setFormData({...formData, nom: e.target.value})}
                      placeholder="Votre nom"
                    />
                  </div>
                </div>

                <div>
                  <Label>Email</Label>
                  <Input value={user?.email || ''} disabled className="bg-slate-50" />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Pays</Label>
                    <Input 
                      value={formData.pays} 
                      onChange={(e) => setFormData({...formData, pays: e.target.value})}
                      placeholder="France"
                    />
                  </div>
                  <div>
                    <Label>Adresse (optionnelle)</Label>
                    <Input 
                      value={formData.adresse_actuelle} 
                      onChange={(e) => setFormData({...formData, adresse_actuelle: e.target.value})}
                      placeholder="Votre adresse"
                    />
                  </div>
                </div>

                <div>
                  <Label>Photo de profil</Label>
                  <div className="flex items-center gap-4 mt-2">
                    <Avatar className="w-16 h-16">
                      <AvatarImage src={profile?.photo_url} />
                      <AvatarFallback>{user?.full_name?.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <Button variant="outline" size="sm">
                      <Camera className="w-4 h-4 mr-2" />
                      Changer la photo
                    </Button>
                  </div>
                </div>

                <Button 
                  className="w-full bg-amber-500 hover:bg-amber-600 text-white"
                  onClick={() => updateProfile.mutate(formData)}
                  disabled={updateProfile.isPending}
                >
                  <Check className="w-4 h-4 mr-2" />
                  {updateProfile.isPending ? 'Enregistrement...' : 'Mettre à jour mes infos'}
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* SECTION 2 - RÉGLAGES */}
          <TabsContent value="settings">
            <div className="grid grid-cols-4 gap-3">
              {settingsItems.map((item) => (
                <Card key={item.key} className="hover:shadow-md transition-shadow cursor-pointer">
                  <CardContent className="p-4 flex flex-col items-center text-center gap-2">
                    <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center mb-1">
                      <item.icon className="w-6 h-6 text-slate-700" />
                    </div>
                    <span className="text-sm font-medium text-slate-900">{item.label}</span>
                    
                    {item.type === 'toggle' && (
                      <Switch
                        checked={settings[item.key] ?? false}
                        onCheckedChange={(v) => updateSetting(item.key, v)}
                      />
                    )}
                    
                    {item.type === 'select' && (
                      <Select
                        value={settings[item.key] || item.options[0]}
                        onValueChange={(v) => updateSetting(item.key, v)}
                      >
                        <SelectTrigger className="h-8 text-xs w-full">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {item.options.map((opt) => (
                            <SelectItem key={opt} value={opt}>{opt}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}

                    {item.type === 'action' && (
                      <Button 
                        variant="ghost" 
                        size="sm"
                        className="text-red-500 hover:text-red-600 hover:bg-red-50"
                        onClick={() => {
                          if (confirm('Réinitialiser tous les réglages ?')) {
                            localStorage.removeItem('patybee_settings');
                            setSettings({});
                            toast.success('Réglages réinitialisés');
                          }
                        }}
                      >
                        Réinitialiser
                      </Button>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* SECTION 3 - MES PROJETS */}
          <TabsContent value="projects">
            <div className="flex items-center justify-between mb-4">
              <div className="flex gap-2">
                <Button 
                  variant={projectFilter === 'all' ? 'default' : 'ghost'} 
                  size="sm"
                  onClick={() => setProjectFilter('all')}
                  className={projectFilter === 'all' ? 'bg-amber-500 hover:bg-amber-600' : ''}
                >
                  Tous ({projects.length})
                </Button>
                <Button 
                  variant={projectFilter === 'inProgress' ? 'default' : 'ghost'} 
                  size="sm"
                  onClick={() => setProjectFilter('inProgress')}
                  className={projectFilter === 'inProgress' ? 'bg-amber-500 hover:bg-amber-600' : ''}
                >
                  En cours
                </Button>
                <Button 
                  variant={projectFilter === 'done' ? 'default' : 'ghost'} 
                  size="sm"
                  onClick={() => setProjectFilter('done')}
                  className={projectFilter === 'done' ? 'bg-amber-500 hover:bg-amber-600' : ''}
                >
                  Terminés
                </Button>
              </div>
              <Button 
                className="bg-amber-500 hover:bg-amber-600"
                onClick={() => navigate(createPageUrl('GridEditor'))}
              >
                Nouveau projet
              </Button>
            </div>

            {filteredProjects.length === 0 ? (
              <Card>
                <CardContent className="p-12 text-center">
                  <FolderOpen className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-slate-900 mb-2">
                    {projectFilter === 'all' ? 'Aucun projet' : projectFilter === 'inProgress' ? 'Aucun projet en cours' : 'Aucun projet terminé'}
                  </h3>
                  <p className="text-slate-500 mb-4">Commencez par importer une image ou créer une nouvelle grille</p>
                  <Button onClick={() => navigate(createPageUrl('GridEditor'))}>
                    Créer mon premier projet
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-3 gap-4">
                {filteredProjects.map((project) => {
                  const progress = calculateProjectProgress(project);
                  const isEditing = editingProjectId === project.id;
                  
                  return (
                    <Card key={project.id} className="overflow-hidden hover:shadow-lg transition-shadow group">
                      {/* Miniature */}
                      <div className="aspect-square bg-slate-100 relative">
                        {project.pattern?.source_image ? (
                          <img 
                            src={project.pattern.source_image} 
                            alt={project.name}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <Puzzle className="w-12 h-12 text-slate-300" />
                          </div>
                        )}
                        
                        {/* Status badge */}
                        <div className="absolute top-2 left-2">
                          <Badge className={progress === 100 ? 'bg-green-500' : 'bg-amber-500'}>
                            {progress === 100 ? 'Terminé' : 'En cours'}
                          </Badge>
                        </div>
                        
                        {/* Progress bar */}
                        {progress > 0 && progress < 100 && (
                          <div className="absolute bottom-0 left-0 right-0 h-1 bg-black/20">
                            <div 
                              className="h-full bg-amber-500"
                              style={{ width: `${progress}%` }}
                            />
                          </div>
                        )}
                        
                        {/* Actions overlay */}
                        <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                          <Button 
                            size="sm" 
                            className="bg-amber-500 hover:bg-amber-600"
                            onClick={() => {
                              localStorage.setItem('loadProjectId', project.id);
                              navigate(createPageUrl('GridEditor'));
                              toast.success('✅ Projet chargé');
                            }}
                          >
                            <Play className="w-4 h-4 mr-1" />
                            Continuer
                          </Button>
                          <Button 
                            size="sm" 
                            variant="secondary"
                            onClick={() => {
                              setEditingProjectId(project.id);
                              setEditingProjectName(project.name);
                            }}
                          >
                            <Pencil className="w-4 h-4" />
                          </Button>
                          <Button 
                            size="sm" 
                            variant="destructive"
                            onClick={() => {
                              if (confirm('Supprimer ce projet ?')) {
                                deleteProject.mutate(project.id);
                              }
                            }}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                      <CardContent className="p-3">
                        {isEditing ? (
                          <div className="flex gap-2">
                            <Input
                              value={editingProjectName}
                              onChange={(e) => setEditingProjectName(e.target.value)}
                              className="h-8 text-sm"
                              autoFocus
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                  renameProject.mutate({ id: project.id, name: editingProjectName });
                                }
                                if (e.key === 'Escape') {
                                  setEditingProjectId(null);
                                }
                              }}
                            />
                            <Button 
                              size="sm" 
                              className="h-8 px-2"
                              onClick={() => renameProject.mutate({ id: project.id, name: editingProjectName })}
                            >
                              <Check className="w-4 h-4" />
                            </Button>
                          </div>
                        ) : (
                          <>
                            <h4 className="font-medium text-slate-900 truncate">{project.name}</h4>
                            <div className="flex items-center justify-between">
                              <p className="text-xs text-slate-500">
                                {new Date(project.updated_date).toLocaleDateString('fr-FR')}
                              </p>
                              {progress > 0 && (
                                <span className="text-xs font-medium text-amber-600">{progress}%</span>
                              )}
                            </div>
                          </>
                        )}
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </TabsContent>

          {/* SECTION 4 - BOUTIQUE */}
          <TabsContent value="shop">
            <div className="grid grid-cols-2 gap-4">
              {[
                { title: 'Grilles Premium', desc: 'Modèles exclusifs', icon: Crown },
                { title: 'Kits & Packs', desc: 'Ensembles complets', icon: Puzzle },
                { title: 'Accessoires', desc: 'Outils et fournitures', icon: Settings },
                { title: 'Abonnements', desc: 'Accès illimité', icon: Cloud },
              ].map((cat) => (
                <Card 
                  key={cat.title} 
                  className="cursor-pointer hover:shadow-lg transition-shadow"
                  onClick={() => navigate(createPageUrl('Shop'))}
                >
                  <CardContent className="p-6 flex items-center gap-4">
                    <div className="w-14 h-14 rounded-xl bg-amber-100 flex items-center justify-center">
                      <cat.icon className="w-7 h-7 text-amber-600" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-slate-900">{cat.title}</h3>
                      <p className="text-sm text-slate-500">{cat.desc}</p>
                    </div>
                    <ChevronRight className="w-5 h-5 text-slate-400" />
                  </CardContent>
                </Card>
              ))}
            </div>

            <Card className="mt-6">
              <CardContent className="p-6">
                <h3 className="font-semibold text-slate-900 mb-4">Historique & Factures</h3>
                <p className="text-slate-500 text-sm">Aucun achat pour le moment</p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* BOTTOM NAVIGATION */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 px-4 py-2 z-50">
        <div className="max-w-lg mx-auto flex justify-around">
          {[
            { Icon: Home, label: 'Accueil', page: 'GridEditor' },
            { Icon: Settings, label: 'Dashboard', page: 'DashboardProfil', active: true },
            { Icon: Sparkles, label: 'Créer', page: 'GridEditor', accent: true },
            { Icon: ShoppingBag, label: 'Boutique', page: 'Shop' },
            { Icon: Bot, label: 'Aide IA', page: 'GridEditor' },
          ].map((item) => (
            <button
              key={item.label}
              onClick={() => navigate(createPageUrl(item.page))}
              className={`flex flex-col items-center py-2 px-4 rounded-lg transition-colors ${
                item.active ? 'bg-amber-100 text-amber-700' : 
                item.accent ? 'bg-amber-500 text-white' :
                'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <item.Icon className="w-5 h-5" />
              <span className="text-xs font-medium mt-1">{item.label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}