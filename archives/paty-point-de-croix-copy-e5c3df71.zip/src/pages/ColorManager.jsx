import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowLeft, RefreshCw, Trash2, Plus, Download, Upload, Edit, Replace } from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import EditColorDialog from '../components/colors/EditColorDialog';
import ReplaceColorDialog from '../components/colors/ReplaceColorDialog';
import { DMC_COLORS } from '../components/grid/dmcColors';

export default function ColorManager() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [selectedProjectColor, setSelectedProjectColor] = useState(null);
  const [currentProjectColors, setCurrentProjectColors] = useState([]);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showReplaceDialog, setShowReplaceDialog] = useState(false);

  // Charger les grilles pour extraire les couleurs
  const { data: grids } = useQuery({
    queryKey: ['grids'],
    queryFn: () => base44.entities.Grid.list(),
    initialData: []
  });

  // Recharger les couleurs depuis les grilles
  const reloadColorsFromGrid = () => {
    const allColors = new Map();

    grids.forEach(grid => {
      if (grid.pattern?.colorPalette) {
        grid.pattern.colorPalette.forEach(color => {
          const key = color.hex;
          if (allColors.has(key)) {
            const existing = allColors.get(key);
            existing.stitches += color.count || 0;
          } else {
            allColors.set(key, {
              id: color.id,
              hex: color.hex,
              dmcNumber: color.code || 'N/A',
              symbol: color.assignedSymbolChar || '●',
              name: color.name || 'Sans nom',
              stitches: color.count || 0
            });
          }
        });
      }
    });

    setCurrentProjectColors(Array.from(allColors.values()));
    toast.success('Couleurs rechargées depuis les grilles');
  };

  useEffect(() => {
    reloadColorsFromGrid();
  }, [grids]);

  const deleteSelectedProjectColor = () => {
    if (!selectedProjectColor) {
      toast.error('Aucune couleur sélectionnée');
      return;
    }

    setCurrentProjectColors(prev => prev.filter(c => c.id !== selectedProjectColor.id));
    setSelectedProjectColor(null);
    toast.success('Couleur supprimée');
  };

  const handleEditColor = () => {
    if (!selectedProjectColor) {
      toast.warning('Sélectionnez d\'abord une couleur dans la liste');
      return;
    }
    setShowEditDialog(true);
  };

  const handleSaveEditedColor = async (editedColor) => {
    // Mettre à jour la couleur dans la liste locale
    setCurrentProjectColors(prev => 
      prev.map(c => c.id === editedColor.id ? editedColor : c)
    );

    // Appliquer les changements aux grilles
    const updatedGrids = grids.map(grid => {
      if (grid.pattern?.colorPalette) {
        const updatedPalette = grid.pattern.colorPalette.map(color => {
          if (color.id === editedColor.id) {
            return {
              ...color,
              hex: editedColor.hex,
              code: editedColor.dmcNumber,
              name: editedColor.name,
              assignedSymbolChar: editedColor.symbol
            };
          }
          return color;
        });

        return {
          ...grid,
          pattern: {
            ...grid.pattern,
            colorPalette: updatedPalette
          }
        };
      }
      return grid;
    });

    // Sauvegarder les grilles modifiées
    for (const grid of updatedGrids) {
      if (grid.pattern?.colorPalette?.some(c => c.id === editedColor.id)) {
        await base44.entities.Grid.update(grid.id, {
          pattern: grid.pattern
        });
      }
    }

    setShowEditDialog(false);
    setSelectedProjectColor(editedColor);
    queryClient.invalidateQueries(['grids']);
    toast.success('Couleur mise à jour et appliquée à la grille');
  };

  const handleReplaceColor = () => {
    if (!selectedProjectColor) {
      toast.warning('Sélectionnez d\'abord une couleur à remplacer');
      return;
    }
    setShowReplaceDialog(true);
  };

  const handleReplaceWithDMC = async (dmcColor) => {
    const replacementColor = {
      ...selectedProjectColor,
      hex: dmcColor.hex,
      dmcNumber: dmcColor.number,
      name: dmcColor.name
    };

    // Mettre à jour localement
    setCurrentProjectColors(prev =>
      prev.map(c => c.id === selectedProjectColor.id ? replacementColor : c)
    );

    // Appliquer aux grilles
    for (const grid of grids) {
      if (grid.pattern?.colorPalette?.some(c => c.id === selectedProjectColor.id)) {
        const updatedPalette = grid.pattern.colorPalette.map(color =>
          color.id === selectedProjectColor.id
            ? { ...color, hex: dmcColor.hex, code: dmcColor.number, name: dmcColor.name }
            : color
        );

        await base44.entities.Grid.update(grid.id, {
          pattern: { ...grid.pattern, colorPalette: updatedPalette }
        });
      }
    }

    setShowReplaceDialog(false);
    setSelectedProjectColor(replacementColor);
    queryClient.invalidateQueries(['grids']);
    toast.success('La couleur a été remplacée dans le projet et sur la grille');
  };

  const handleApplyFullDMCPalette = () => {
    toast.success('La palette complète DMC est maintenant disponible pour cette grille');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <Button
            variant="ghost"
            onClick={() => navigate(-1)}
            className="mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Retour
          </Button>
          <h1 className="text-3xl font-bold text-slate-900">Couleurs & fils</h1>
          <p className="text-slate-600 mt-1">
            Gérer les couleurs DMC, les symboles associés et les palettes utilisées dans votre projet.
          </p>
        </div>

        {/* Two columns layout */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          
          {/* Colonne gauche - Liste des couleurs */}
          <div className="bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden">
            <div className="p-4 border-b border-slate-200">
              <h2 className="text-lg font-semibold text-slate-900">Couleurs utilisées dans ce projet</h2>
              <p className="text-sm text-slate-600 mt-1">
                Voici les couleurs actuellement associées aux symboles de votre grille.
              </p>
            </div>

            {/* Table */}
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-slate-50 border-b border-slate-200">
                  <tr>
                    <th className="px-4 py-3 text-left text-xs font-medium text-slate-600 w-16">Aperçu</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-slate-600 w-20">DMC</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-slate-600 w-20">Symbole</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-slate-600">Nom</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-slate-600 w-24">Points</th>
                  </tr>
                </thead>
                <tbody>
                  {currentProjectColors.length === 0 ? (
                    <tr>
                      <td colSpan="5" className="px-4 py-8 text-center text-slate-500">
                        Aucune couleur dans le projet
                      </td>
                    </tr>
                  ) : (
                    currentProjectColors.map((color) => (
                      <tr
                        key={color.id}
                        onClick={() => setSelectedProjectColor(color)}
                        className={cn(
                          "cursor-pointer transition-colors border-b border-slate-100",
                          selectedProjectColor?.id === color.id
                            ? "bg-indigo-50"
                            : "hover:bg-slate-50"
                        )}
                      >
                        <td className="px-4 py-3">
                          <div
                            className="w-8 h-8 rounded border border-slate-300"
                            style={{ backgroundColor: color.hex }}
                          />
                        </td>
                        <td className="px-4 py-3 text-sm font-medium">{color.dmcNumber}</td>
                        <td className="px-4 py-3">
                          <div className="w-8 h-8 flex items-center justify-center bg-slate-100 rounded border border-slate-300 font-bold">
                            {color.symbol}
                          </div>
                        </td>
                        <td className="px-4 py-3 text-sm">{color.name}</td>
                        <td className="px-4 py-3 text-sm text-slate-600">{color.stitches}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            {/* Footer */}
            <div className="p-4 border-t border-slate-200 flex items-center justify-between">
              <Button
                variant="ghost"
                onClick={reloadColorsFromGrid}
                className="gap-2"
              >
                <RefreshCw className="w-4 h-4" />
                Recharger depuis la grille
              </Button>
              <Button
                variant="secondary"
                onClick={deleteSelectedProjectColor}
                disabled={!selectedProjectColor}
                className="gap-2"
              >
                <Trash2 className="w-4 h-4" />
                Supprimer la couleur sélectionnée
              </Button>
            </div>
          </div>

          {/* Colonne droite - Détails & actions */}
          <div className="space-y-6">
            {/* Détails de la couleur sélectionnée */}
            <div className="bg-white rounded-xl shadow-lg border border-slate-200 p-6">
              <h2 className="text-lg font-semibold text-slate-900 mb-4">Détails de la couleur</h2>
              
              {selectedProjectColor ? (
                <div className="space-y-4">
                  <div className="flex items-center gap-4">
                    <div
                      className="w-20 h-20 rounded-lg border-2 border-slate-300"
                      style={{ backgroundColor: selectedProjectColor.hex }}
                    />
                    <div>
                      <div className="text-2xl font-bold">{selectedProjectColor.dmcNumber}</div>
                      <div className="text-slate-600">{selectedProjectColor.name}</div>
                      <div className="text-sm text-slate-500 mt-1">{selectedProjectColor.hex}</div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 pt-4 border-t border-slate-200">
                    <div>
                      <div className="text-xs text-slate-600">Symbole</div>
                      <div className="text-2xl font-bold mt-1">{selectedProjectColor.symbol}</div>
                    </div>
                    <div>
                      <div className="text-xs text-slate-600">Points brodés</div>
                      <div className="text-2xl font-bold mt-1">{selectedProjectColor.stitches}</div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8 text-slate-500">
                  Sélectionnez une couleur pour voir ses détails
                </div>
              )}
            </div>

            {/* Actions rapides */}
            <div className="bg-white rounded-xl shadow-lg border border-slate-200 p-6">
              <h2 className="text-lg font-semibold text-slate-900 mb-4">Actions rapides</h2>
              <div className="space-y-2">
                <Button 
                  variant="outline" 
                  className="w-full justify-start gap-2"
                  onClick={handleEditColor}
                  disabled={!selectedProjectColor}
                >
                  <Edit className="w-4 h-4" />
                  Modifier la couleur sélectionnée
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start gap-2"
                  onClick={handleReplaceColor}
                  disabled={!selectedProjectColor}
                >
                  <Replace className="w-4 h-4" />
                  Remplacer par une couleur DMC
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start gap-2"
                  onClick={handleApplyFullDMCPalette}
                >
                  <Plus className="w-4 h-4" />
                  Appliquer la palette DMC complète
                </Button>
                <Button variant="outline" className="w-full justify-start gap-2">
                  <Download className="w-4 h-4" />
                  Exporter la palette
                </Button>
                <Button variant="outline" className="w-full justify-start gap-2">
                  <Upload className="w-4 h-4" />
                  Importer une palette
                </Button>
              </div>
            </div>

            {/* Statistiques */}
            <div className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-xl border border-indigo-200 p-6">
              <h3 className="text-sm font-semibold text-slate-900 mb-3">Statistiques du projet</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-slate-600">Total couleurs</span>
                  <span className="font-semibold">{currentProjectColors.length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Total points</span>
                  <span className="font-semibold">
                    {currentProjectColors.reduce((sum, c) => sum + c.stitches, 0)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Couleur la plus utilisée</span>
                  <span className="font-semibold">
                    {currentProjectColors.length > 0
                      ? currentProjectColors.reduce((max, c) => c.stitches > max.stitches ? c : max).dmcNumber
                      : '-'}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Dialogs */}
        <EditColorDialog
          open={showEditDialog}
          onClose={() => setShowEditDialog(false)}
          color={selectedProjectColor}
          onSave={handleSaveEditedColor}
        />

        <ReplaceColorDialog
          open={showReplaceDialog}
          onClose={() => setShowReplaceDialog(false)}
          currentColor={selectedProjectColor}
          onReplace={handleReplaceWithDMC}
        />
      </div>
    </div>
  );
}