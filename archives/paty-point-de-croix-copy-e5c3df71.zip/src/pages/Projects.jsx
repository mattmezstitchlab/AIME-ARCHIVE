import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '../utils';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Folder,
  FolderOpen,
  Calendar,
  MoreVertical,
  Trash2,
  Copy,
  Edit2,
  ShoppingBag,
  FilePlus,
  Grid3x3,
  ArrowLeft
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

export default function Projects() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [renameDialogOpen, setRenameDialogOpen] = useState(false);
  const [selectedProject, setSelectedProject] = useState(null);
  const [newName, setNewName] = useState('');

  const { data: user } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me(),
  });

  const { data: projects, isLoading } = useQuery({
    queryKey: ['projects', user?.email],
    queryFn: async () => {
      if (!user) return [];
      const grids = await base44.entities.Grid.filter({ created_by: user.email });
      return grids.sort((a, b) => new Date(b.updated_date) - new Date(a.updated_date));
    },
    enabled: !!user,
    initialData: []
  });

  const deleteProjectMutation = useMutation({
    mutationFn: (projectId) => base44.entities.Grid.delete(projectId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['projects'] });
      toast.success('Projet supprimé');
      setDeleteDialogOpen(false);
    },
  });

  const renameProjectMutation = useMutation({
    mutationFn: ({ id, name }) => base44.entities.Grid.update(id, { name }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['projects'] });
      toast.success('Projet renommé');
      setRenameDialogOpen(false);
    },
  });

  const duplicateProjectMutation = useMutation({
    mutationFn: async (project) => {
      const duplicate = {
        name: `${project.name} (copie)`,
        nb_colonnes: project.nb_colonnes,
        nb_lignes: project.nb_lignes,
        taille_case: project.taille_case,
        zoom: project.zoom,
        offset_x: project.offset_x,
        offset_y: project.offset_y,
        repere_10x10: project.repere_10x10,
        numerotation_10x10: project.numerotation_10x10,
        repere_central: project.repere_central,
        stitches: project.stitches,
        pattern: project.pattern
      };
      return await base44.entities.Grid.create(duplicate);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['projects'] });
      toast.success('Projet dupliqué');
    },
  });

  const handleOpenProject = (project) => {
    // Sauvegarder le projet dans localStorage pour que l'éditeur le charge
    localStorage.setItem('gridEditorState', JSON.stringify({
      gridConfig: {
        name: project.name,
        nb_colonnes: project.nb_colonnes,
        nb_lignes: project.nb_lignes,
        taille_case: project.taille_case,
        zoom: project.zoom,
        offset_x: project.offset_x,
        offset_y: project.offset_y,
        stitches: project.stitches || []
      },
      pattern: project.pattern || null,
      timestamp: Date.now()
    }));
    navigate(createPageUrl('GridEditor'));
  };

  const handleDelete = (project) => {
    setSelectedProject(project);
    setDeleteDialogOpen(true);
  };

  const handleRename = (project) => {
    setSelectedProject(project);
    setNewName(project.name);
    setRenameDialogOpen(true);
  };

  const handleDuplicate = (project) => {
    duplicateProjectMutation.mutate(project);
  };

  const handleNewProject = () => {
    navigate(createPageUrl('GridEditor'));
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <p className="text-slate-600">Chargement...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <div className="container mx-auto px-8 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Button
              onClick={() => navigate(createPageUrl('Shop'))}
              variant="outline"
              className="gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Retour
            </Button>
            <div className="flex items-center gap-3">
              <Folder className="w-8 h-8 text-slate-900" />
              <h1 className="text-3xl font-bold text-slate-900">Mes projets</h1>
            </div>
          </div>
          <Button
            onClick={() => navigate(createPageUrl('VendreCreation'))}
            className="bg-black hover:bg-slate-800 text-white gap-2"
          >
            <ShoppingBag className="w-4 h-4" />
            Vendre une création
          </Button>
        </div>

        {/* Liste des projets */}
        {projects.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16">
            <div className="w-24 h-24 rounded-full bg-slate-100 flex items-center justify-center mb-6">
              <FolderOpen className="w-12 h-12 text-slate-400" />
            </div>
            <h2 className="text-xl font-semibold text-slate-900 mb-2">
              Tu n'as pas encore de projet enregistré
            </h2>
            <p className="text-slate-600 mb-6">
              Clique sur "Nouvelle grille" pour commencer.
            </p>
            <Button
              onClick={handleNewProject}
              className="bg-black hover:bg-slate-800 text-white gap-2"
            >
              <FilePlus className="w-4 h-4" />
              Créer mon premier projet
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {projects.map((project) => (
              <div
                key={project.id}
                className="bg-white border border-slate-200 rounded-xl overflow-hidden hover:shadow-lg transition-all"
              >
                {/* Preview */}
                <div className="aspect-square bg-slate-50 border-b border-slate-200 flex items-center justify-center relative group">
                  {project.pattern?.sourceImage ? (
                    <img
                      src={project.pattern.sourceImage}
                      alt={project.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <Grid3x3 className="w-16 h-16 text-slate-300" />
                  )}
                  
                  {/* Overlay au survol */}
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <Button
                      onClick={() => handleOpenProject(project)}
                      className="bg-white text-black hover:bg-slate-100"
                    >
                      Ouvrir
                    </Button>
                  </div>
                </div>

                {/* Info */}
                <div className="p-4">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="font-semibold text-slate-900 line-clamp-1 flex-1">
                      {project.name}
                    </h3>
                    
                    {/* Menu actions */}
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <button className="w-8 h-8 rounded-lg hover:bg-slate-100 flex items-center justify-center">
                          <MoreVertical className="w-4 h-4 text-slate-600" />
                        </button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => handleOpenProject(project)}>
                          <FolderOpen className="w-4 h-4 mr-2" />
                          Ouvrir
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleRename(project)}>
                          <Edit2 className="w-4 h-4 mr-2" />
                          Renommer
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleDuplicate(project)}>
                          <Copy className="w-4 h-4 mr-2" />
                          Dupliquer
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleDelete(project)} className="text-red-600">
                          <Trash2 className="w-4 h-4 mr-2" />
                          Supprimer
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>

                  <div className="flex items-center gap-2 text-xs text-slate-500">
                    <Calendar className="w-3 h-3" />
                    {new Date(project.updated_date).toLocaleDateString('fr-FR')}
                  </div>

                  {project.nb_colonnes && project.nb_lignes && (
                    <p className="text-xs text-slate-500 mt-1">
                      {project.nb_colonnes} × {project.nb_lignes}
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Dialog de suppression */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Supprimer le projet ?</DialogTitle>
            <DialogDescription>
              Êtes-vous sûr de vouloir supprimer "{selectedProject?.name}" ? Cette action est irréversible.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteDialogOpen(false)}>
              Annuler
            </Button>
            <Button
              variant="destructive"
              onClick={() => deleteProjectMutation.mutate(selectedProject?.id)}
              disabled={deleteProjectMutation.isPending}
            >
              {deleteProjectMutation.isPending ? 'Suppression...' : 'Supprimer'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dialog de renommage */}
      <Dialog open={renameDialogOpen} onOpenChange={setRenameDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Renommer le projet</DialogTitle>
          </DialogHeader>
          <Input
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            placeholder="Nom du projet"
          />
          <DialogFooter>
            <Button variant="outline" onClick={() => setRenameDialogOpen(false)}>
              Annuler
            </Button>
            <Button
              onClick={() => renameProjectMutation.mutate({ id: selectedProject?.id, name: newName })}
              disabled={!newName.trim() || renameProjectMutation.isPending}
              className="bg-black hover:bg-slate-800"
            >
              {renameProjectMutation.isPending ? 'Enregistrement...' : 'Enregistrer'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}