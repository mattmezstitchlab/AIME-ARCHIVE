import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { ArrowLeft, ChevronDown, ChevronRight, RotateCcw } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '../utils';
import { useSettings } from '../components/settings/SettingsContext';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { cn } from '@/lib/utils';
import SettingsPreview from '../components/settings/SettingsPreview';

export default function SettingsPage() {
  const navigate = useNavigate();
  const { settings, saveSettings, resetSettings } = useSettings();
  
  const [localSettings, setLocalSettings] = useState(settings);
  const [hasChanges, setHasChanges] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  
  const [expandedSections, setExpandedSections] = useState({
    appearance: true,
    grid: false,
    symbols: false,
    navigation: false,
    save: false
  });

  useEffect(() => {
    setLocalSettings(settings);
  }, [settings]);

  const toggleSection = (section) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  const updateLocalSetting = (key, value) => {
    setLocalSettings(prev => ({
      ...prev,
      [key]: value
    }));
    setHasChanges(true);
  };

  const handleSaveSettings = async () => {
    if (!hasChanges) return;
    setIsSaving(true);
    
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      saveSettings(localSettings);
      setHasChanges(false);
      setTimeout(() => setIsSaving(false), 1500);
    } catch (error) {
      setIsSaving(false);
    }
  };

  const handleResetSettings = () => {
    if (confirm('Réinitialiser tous les réglages ?')) {
      resetSettings();
      setLocalSettings(settings);
    }
  };

  const SectionHeader = ({ section, title }) => (
    <button
      onClick={() => toggleSection(section)}
      className="w-full flex items-center justify-between p-4 bg-slate-50 hover:bg-slate-100 transition-colors rounded-lg"
    >
      <h2 className="text-lg font-semibold text-slate-900">{title}</h2>
      {expandedSections[section] ? (
        <ChevronDown className="w-5 h-5 text-slate-600" />
      ) : (
        <ChevronRight className="w-5 h-5 text-slate-600" />
      )}
    </button>
  );

  return (
    <div className="min-h-screen bg-white pb-32">
      {/* Header */}
      <div className="bg-white border-b border-slate-200 px-8 py-6">
        <div className="flex items-center gap-4 mb-2">
          <button
            onClick={() => navigate(-1)}
            className="text-slate-600 hover:text-slate-900 transition-colors"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-3xl font-bold text-slate-900">Réglages</h1>
        </div>
        <p className="text-slate-600 ml-10">Personnalisez votre expérience PatyBee</p>
      </div>

      <div className="max-w-5xl mx-auto px-8 py-8 flex gap-8">
        {/* Colonne gauche : contrôles */}
        <div className="flex-1 space-y-4">
        {/* 1. Apparence */}
        <div className="border border-slate-200 rounded-lg overflow-hidden">
          <SectionHeader section="appearance" title="Apparence" />
          {expandedSections.appearance && (
            <div className="p-6 space-y-5 bg-white">
              <div className="space-y-2">
                <Label>Mode d'affichage</Label>
                <RadioGroup value={localSettings.displayMode} onValueChange={(v) => updateLocalSetting('displayMode', v)} className="flex gap-4">
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="light" id="light" />
                    <Label htmlFor="light" className="cursor-pointer">Clair</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="dark" id="dark" />
                    <Label htmlFor="dark" className="cursor-pointer">Sombre</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="auto" id="auto" />
                    <Label htmlFor="auto" className="cursor-pointer">Auto</Label>
                  </div>
                </RadioGroup>
              </div>

              <div className="space-y-2">
                <Label>Taille du texte : {localSettings.textSize}%</Label>
                <Slider 
                  value={[localSettings.textSize]} 
                  onValueChange={([v]) => updateLocalSetting('textSize', v)}
                  min={80}
                  max={150}
                  step={10}
                />
              </div>

              <div className="flex items-center justify-between">
                <Label>Réduire les animations</Label>
                <Switch checked={localSettings.reduceAnimations} onCheckedChange={(v) => updateLocalSetting('reduceAnimations', v)} />
              </div>
            </div>
          )}
        </div>

        {/* 2. Grille */}
        <div className="border border-slate-200 rounded-lg overflow-hidden">
          <SectionHeader section="grid" title="Grille & Repères" />
          {expandedSections.grid && (
            <div className="p-6 space-y-5 bg-white">
              <div className="flex items-center justify-between">
                <Label>Afficher la grille</Label>
                <Switch checked={localSettings.showGrid} onCheckedChange={(v) => updateLocalSetting('showGrid', v)} />
              </div>

              <div className="flex items-center justify-between">
                <Label>Afficher le repère central</Label>
                <Switch checked={localSettings.showCenterMarker} onCheckedChange={(v) => updateLocalSetting('showCenterMarker', v)} />
              </div>

              <div className="space-y-2">
                <Label>Opacité de la grille : {localSettings.gridOpacity}%</Label>
                <Slider 
                  value={[localSettings.gridOpacity]} 
                  onValueChange={([v]) => updateLocalSetting('gridOpacity', v)}
                  min={20}
                  max={100}
                  step={10}
                />
              </div>
            </div>
          )}
        </div>

        {/* 3. Symboles */}
        <div className="border border-slate-200 rounded-lg overflow-hidden">
          <SectionHeader section="symbols" title="Symboles & Couleurs" />
          {expandedSections.symbols && (
            <div className="p-6 space-y-5 bg-white">
              <div className="space-y-2">
                <Label>Taille des symboles : {localSettings.symbolSize}%</Label>
                <Slider 
                  value={[localSettings.symbolSize]} 
                  onValueChange={([v]) => updateLocalSetting('symbolSize', v)}
                  min={50}
                  max={200}
                  step={10}
                />
              </div>

              <div className="space-y-2">
                <Label>Mode daltonien</Label>
                <Select value={localSettings.colorBlindMode} onValueChange={(v) => updateLocalSetting('colorBlindMode', v)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Aucun</SelectItem>
                    <SelectItem value="protanopia">Protanopie</SelectItem>
                    <SelectItem value="deuteranopia">Deutéranopie</SelectItem>
                    <SelectItem value="tritanopia">Tritanopie</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}
        </div>

        {/* 4. Navigation */}
        <div className="border border-slate-200 rounded-lg overflow-hidden">
          <SectionHeader section="navigation" title="Navigation" />
          {expandedSections.navigation && (
            <div className="p-6 space-y-5 bg-white">
              <div className="space-y-2">
                <Label>Mode de zoom</Label>
                <Select value={localSettings.zoomMode || 'wheel'} onValueChange={(v) => updateLocalSetting('zoomMode', v)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="wheel">Molette de souris</SelectItem>
                    <SelectItem value="buttons">Boutons +/-</SelectItem>
                    <SelectItem value="trackpad">Trackpad (pinch)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center justify-between">
                <Label>Afficher la mini-carte</Label>
                <Switch checked={localSettings.showMinimap} onCheckedChange={(v) => updateLocalSetting('showMinimap', v)} />
              </div>

              {localSettings.showMinimap && (
                <div className="space-y-2">
                  <Label>Position de la mini-carte</Label>
                  <Select value={localSettings.minimapPosition || 'bottom-right'} onValueChange={(v) => updateLocalSetting('minimapPosition', v)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="bottom-left">Bas gauche</SelectItem>
                      <SelectItem value="bottom-right">Bas droite</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}

              <div className="flex items-center justify-between">
                <Label>Zoom centré sur le pointeur</Label>
                <Switch checked={localSettings.zoomCenterPointer} onCheckedChange={(v) => updateLocalSetting('zoomCenterPointer', v)} />
              </div>

              <div className="flex items-center justify-between">
                <Label>Inverser le sens du zoom</Label>
                <Switch checked={localSettings.invertZoom} onCheckedChange={(v) => updateLocalSetting('invertZoom', v)} />
              </div>
            </div>
          )}
        </div>

        {/* 5. Sauvegarde */}
        <div className="border border-slate-200 rounded-lg overflow-hidden">
          <SectionHeader section="save" title="Sauvegarde" />
          {expandedSections.save && (
            <div className="p-6 space-y-5 bg-white">
              <div className="flex items-center justify-between">
                <Label>Sauvegarde automatique</Label>
                <Switch checked={localSettings.autoSave} onCheckedChange={(v) => updateLocalSetting('autoSave', v)} />
              </div>

              {localSettings.autoSave && (
                <div className="space-y-2">
                  <Label>Intervalle de sauvegarde : {localSettings.autoSaveInterval} min</Label>
                  <Slider 
                    value={[localSettings.autoSaveInterval]} 
                    onValueChange={([v]) => updateLocalSetting('autoSaveInterval', v)}
                    min={1}
                    max={15}
                    step={1}
                  />
                  <p className="text-xs text-slate-500">
                    La sauvegarde automatique nécessite une connexion Internet stable.
                  </p>
                </div>
              )}

              <div className="flex items-center justify-between">
                <Label>Confirmation avant fermeture</Label>
                <Switch checked={localSettings.confirmBeforeClose} onCheckedChange={(v) => updateLocalSetting('confirmBeforeClose', v)} />
              </div>
            </div>
          )}
        </div>

        {/* Réinitialiser */}
        <div className="pt-4">
          <Button
            onClick={handleResetSettings}
            variant="outline"
            className="w-full gap-2"
          >
            <RotateCcw className="w-4 h-4" />
            Réinitialiser tous les réglages
          </Button>
        </div>
        </div>

        {/* Colonne droite : aperçu */}
        <div className="w-80 flex-shrink-0 sticky top-24">
          <SettingsPreview settings={localSettings} />
        </div>
      </div>

      {/* Fixed bottom bar */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 px-8 py-4 shadow-lg z-50">
        <div className="max-w-5xl mx-auto flex justify-between items-center">
          <div className="text-sm text-slate-600">
            {hasChanges && !isSaving && (
              <span className="text-amber-600">● Modifications non sauvegardées</span>
            )}
          </div>
          <Button
            onClick={handleSaveSettings}
            disabled={!hasChanges || isSaving}
            className={cn(
              "transition-all min-w-[180px]",
              !hasChanges ? "bg-slate-300 cursor-not-allowed" : "bg-slate-900 hover:bg-slate-800",
              isSaving && "bg-green-600"
            )}
          >
            {isSaving ? 'Enregistré ✓' : 'Enregistrer'}
          </Button>
        </div>
      </div>
    </div>
  );
}