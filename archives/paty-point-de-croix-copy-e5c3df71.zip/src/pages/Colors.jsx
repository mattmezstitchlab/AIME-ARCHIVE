import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ArrowLeft, Edit2, RefreshCw, Plus, Upload, Image } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '../utils';
import { toast } from 'sonner';

export default function ColorsPage() {
  const navigate = useNavigate();
  const [activeColors, setActiveColors] = useState([
    { id: 1, hex: '#E3242B', dmc: 'DMC-666', name: 'Rouge vif', count: 234 },
    { id: 2, hex: '#2F80ED', dmc: 'DMC-799', name: 'Bleu royal', count: 189 },
    { id: 3, hex: '#27AE60', dmc: 'DMC-701', name: 'Vert émeraude', count: 156 }
  ]);

  const [palettes] = useState([
    { id: 1, name: 'Palette DMC complète', colors: 489, type: 'dmc' },
    { id: 2, name: 'Palette perso – Coucher de soleil', colors: 12, type: 'custom' },
    { id: 3, name: 'Palette importée depuis image – Paysage', colors: 24, type: 'imported' }
  ]);

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="bg-white border-b border-slate-200 px-8 py-6">
        <div className="flex items-center gap-4 mb-2">
          <button
            onClick={() => navigate(createPageUrl('GridEditor'))}
            className="text-slate-600 hover:text-slate-900"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-3xl font-bold text-slate-900">Couleurs</h1>
        </div>
        <p className="text-slate-600 ml-10">Gérez vos fils, vos palettes et les couleurs associées à vos symboles.</p>
      </div>

      <div className="max-w-6xl mx-auto px-8 py-8 space-y-8">
        {/* Palette active */}
        <section className="bg-white border border-slate-200 rounded-lg p-6">
          <h2 className="text-xl font-semibold text-slate-900 mb-4">Palette active</h2>
          <p className="text-sm text-slate-600 mb-6">Couleurs actuellement utilisées dans votre grille</p>

          <div className="space-y-3">
            {activeColors.map(color => (
              <div key={color.id} className="flex items-center gap-4 p-4 bg-slate-50 rounded-lg">
                <div
                  className="w-12 h-12 rounded-lg border-2 border-slate-300"
                  style={{ backgroundColor: color.hex }}
                />
                <div className="flex-1">
                  <div className="font-semibold text-slate-900">{color.dmc}</div>
                  <div className="text-sm text-slate-600">{color.name}</div>
                  <div className="text-xs text-slate-500">{color.count} points utilisés</div>
                </div>
                <Button variant="outline" size="sm" className="gap-2">
                  <Edit2 className="w-4 h-4" />
                  Modifier
                </Button>
                <Button variant="outline" size="sm" className="gap-2">
                  <RefreshCw className="w-4 h-4" />
                  Remplacer par...
                </Button>
              </div>
            ))}
          </div>
        </section>

        {/* Bibliothèque de palettes */}
        <section className="bg-white border border-slate-200 rounded-lg p-6">
          <h2 className="text-xl font-semibold text-slate-900 mb-4">Bibliothèque de palettes</h2>
          <p className="text-sm text-slate-600 mb-6">Palettes sauvegardées et disponibles</p>

          <div className="space-y-3">
            {palettes.map(palette => (
              <div key={palette.id} className="flex items-center gap-4 p-4 bg-slate-50 rounded-lg">
                <div className="flex-1">
                  <div className="font-semibold text-slate-900">{palette.name}</div>
                  <div className="text-sm text-slate-600">{palette.colors} couleurs</div>
                </div>
                <Button variant="outline" size="sm">
                  Activer sur la grille
                </Button>
                <Button variant="ghost" size="sm">
                  Dupliquer
                </Button>
                <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-700">
                  Supprimer
                </Button>
              </div>
            ))}
          </div>
        </section>

        {/* Créer / Importer */}
        <section className="bg-white border border-slate-200 rounded-lg p-6">
          <h2 className="text-xl font-semibold text-slate-900 mb-4">Créer / Importer une palette</h2>

          <div className="grid grid-cols-3 gap-4">
            <Button variant="outline" className="h-24 flex flex-col gap-2">
              <Plus className="w-6 h-6" />
              <span>Créer une palette manuelle</span>
            </Button>
            <Button variant="outline" className="h-24 flex flex-col gap-2">
              <Image className="w-6 h-6" />
              <span>Générer depuis l'image du projet</span>
            </Button>
            <Button variant="outline" className="h-24 flex flex-col gap-2">
              <Upload className="w-6 h-6" />
              <span>Importer (.csv / .json)</span>
            </Button>
          </div>
        </section>

        {/* Footer */}
        <div className="flex items-center justify-between pt-6 border-t border-slate-200">
          <p className="text-sm text-slate-600">
            Les changements de couleurs ne modifient pas la position des points, seulement leur apparence et leur référence DMC.
          </p>
          <Button className="bg-slate-900 hover:bg-slate-800">
            Appliquer à la grille
          </Button>
        </div>
      </div>
    </div>
  );
}