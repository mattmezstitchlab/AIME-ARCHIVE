import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { 
  Search, TrendingUp, Clock, Eye, ShoppingCart, ShoppingBag, Receipt, Coins,
  DollarSign, Download, Package, Folder
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { usePatyBee } from '../components/patybee/PatyBeeContext';
import { usePatyBeeMatching } from '../components/patybee/PatyBeeMatchingContext';
import WatermarkOverlay from '../components/shop/WatermarkOverlay';
import PatyBeeFilterSortPro from '../components/shop/PatyBeeFilterSortPro';
import { createPageUrl } from '../utils';

export default function Shop() {
  const navigate = useNavigate();
  const { showPageContext } = usePatyBee();
  const { creativeProfile, calculateModelMatch } = usePatyBeeMatching();
  const [activeTab, setActiveTab] = useState('boutique');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('views');
  const [selectedGrid, setSelectedGrid] = useState(null);
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [sizeFilter, setSizeFilter] = useState('all');
  const [proFilters, setProFilters] = useState({});
  
  const { data: user } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me(),
  });

  // Messages automatiques désactivés

  const { data: shopGrids, isLoading } = useQuery({
    queryKey: ['shop-grids', sortBy],
    queryFn: async () => {
      const grids = await base44.entities.ShopGrid.list();
      
      // Tri
      if (sortBy === 'views') {
        return grids.sort((a, b) => (b.views_count || 0) - (a.views_count || 0));
      } else if (sortBy === 'recent') {
        return grids.sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
      }
      return grids;
    },
    initialData: []
  });

  const filteredGrids = shopGrids.filter(grid => {
    // Recherche
    const matchesSearch = grid.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          grid.creator_name?.toLowerCase().includes(searchQuery.toLowerCase());
    
    // Filtre de taille
    const gridData = grid.grid_data;
    const cols = gridData?.nb_colonnes || 0;
    const rows = gridData?.nb_lignes || 0;
    const maxDim = Math.max(cols, rows);
    const matchesSize = sizeFilter === 'all' ||
                        (sizeFilter === 'small' && maxDim <= 80) ||
                        (sizeFilter === 'medium' && maxDim > 80 && maxDim <= 150) ||
                        (sizeFilter === 'large' && maxDim > 150);
    
    return matchesSearch && matchesSize;
  });

  const handleViewGrid = async (grid) => {
    // Incrémenter le compteur de vues
    await base44.entities.ShopGrid.update(grid.id, {
      views_count: (grid.views_count || 0) + 1
    });
    
    setSelectedGrid(grid);
  };

  const { data: myGrids, isLoading: myGridsLoading } = useQuery({
    queryKey: ['my-shop-grids', user?.email],
    queryFn: async () => {
      if (!user) return [];
      return await base44.entities.ShopGrid.filter({ creator_email: user.email });
    },
    enabled: !!user,
    initialData: []
  });

  // Calculer les scores de matching pour chaque grille
  const gridsWithMatching = filteredGrids.map(grid => {
    const matching = calculateModelMatch(grid);
    return { ...grid, matchingScore: matching.score, matchingDetails: matching.details };
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="container mx-auto px-8 py-8">
        {/* Tabs */}
        <div className="flex gap-2 mb-6">
          <button
            onClick={() => setActiveTab('boutique')}
            className={`px-6 py-3 rounded-lg font-medium transition-all ${
              activeTab === 'boutique'
                ? 'bg-white text-slate-900 shadow-md'
                : 'bg-white/50 text-slate-600 hover:bg-white/80'
            }`}
          >
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-4 h-4" />
              Boutique
            </div>
          </button>
          <button
            onClick={() => setActiveTab('projets')}
            className={`px-6 py-3 rounded-lg font-medium transition-all ${
              activeTab === 'projets'
                ? 'bg-white text-slate-900 shadow-md'
                : 'bg-white/50 text-slate-600 hover:bg-white/80'
            }`}
          >
            <div className="flex items-center gap-2">
              <Folder className="w-4 h-4" />
              Projets
            </div>
          </button>
          <button
            onClick={() => setActiveTab('mes-achats')}
            className={`px-6 py-3 rounded-lg font-medium transition-all ${
              activeTab === 'mes-achats'
                ? 'bg-white text-slate-900 shadow-md'
                : 'bg-white/50 text-slate-600 hover:bg-white/80'
            }`}
          >
            <div className="flex items-center gap-2">
              <Receipt className="w-4 h-4" />
              Mes achats
            </div>
          </button>
          <button
            onClick={() => setActiveTab('mes-ventes')}
            className={`px-6 py-3 rounded-lg font-medium transition-all ${
              activeTab === 'mes-ventes'
                ? 'bg-white text-slate-900 shadow-md'
                : 'bg-white/50 text-slate-600 hover:bg-white/80'
            }`}
          >
            <div className="flex items-center gap-2">
              <Coins className="w-4 h-4" />
              Mes ventes
            </div>
          </button>
        </div>

        {/* Contenu selon l'onglet */}
        {activeTab === 'boutique' && (
          <>
        {/* Filtres et recherche */}
        <div className="bg-white rounded-xl shadow-md border border-slate-200 p-6 mb-8">
          <div className="space-y-4">
            {/* Ligne 1: Recherche et Menu Pro */}
            <div className="flex flex-col md:flex-row gap-4">
              {/* Recherche */}
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                  <Input
                    placeholder="Rechercher une grille ou un créateur..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>

              {/* Menu Filtres & Tri Pro™ */}
              <PatyBeeFilterSortPro
                currentFilters={proFilters}
                onFiltersChange={setProFilters}
              />
            </div>
          </div>
        </div>

        {/* Grille de produits */}
        {isLoading ? (
          <div className="text-center py-12">
            <p className="text-slate-600">Chargement...</p>
          </div>
        ) : filteredGrids.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-slate-600 mb-4">Aucune grille disponible pour le moment</p>
            <p className="text-sm text-slate-500">
              Soyez le premier à publier une création !
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {gridsWithMatching.map((grid) => (
              <div
                key={grid.id}
                className="bg-white rounded-xl shadow-md border border-slate-200 overflow-hidden hover:shadow-xl transition-all"
              >
                {/* Image */}
                <div 
                  className="aspect-square bg-slate-100 relative select-none"
                  onContextMenu={(e) => e.preventDefault()}
                  style={{ userSelect: 'none', WebkitUserSelect: 'none' }}
                >
                  {grid.preview_image ? (
                    <>
                      <img
                        src={grid.preview_image}
                        alt={grid.title}
                        className="w-full h-full object-cover blur-[1px]"
                        draggable="false"
                        onContextMenu={(e) => e.preventDefault()}
                      />
                      <WatermarkOverlay type="preview" />
                    </>
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-slate-400">
                      <ShoppingCart className="w-16 h-16" />
                    </div>
                  )}
                </div>

                {/* Contenu */}
                <div className="p-4">
                  <h3 className="font-bold text-lg text-slate-900 mb-1 line-clamp-1">
                    {grid.title}
                  </h3>
                  <p className="text-sm text-slate-600 mb-2">
                    par {grid.creator_name}
                  </p>
                  
                  {grid.grid_data && (
                    <p className="text-xs text-slate-500 mb-3">
                      {grid.grid_data.nb_colonnes} × {grid.grid_data.nb_lignes}
                    </p>
                  )}

                  {/* Stats */}
                  <div className="flex items-center gap-3 text-xs text-slate-500 mb-3">
                    <span className="flex items-center gap-1">
                      <Eye className="w-3 h-3" />
                      {grid.views_count || 0} vues
                    </span>
                  </div>

                  {/* Matching */}
                  {grid.matchingScore > 0.7 && creativeProfile && (
                    <div className="mb-3">
                      <span className="text-xs bg-amber-100 text-amber-800 px-2 py-1 rounded-full">
                        {Math.round(grid.matchingScore * 100)}% compatible
                      </span>
                    </div>
                  )}

                  {/* Actions */}
                  <div className="flex gap-2">
                    <Button
                      onClick={() => handleViewGrid(grid)}
                      variant="outline"
                      size="sm"
                      className="flex-1"
                    >
                      Voir
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
        </>
        )}

        {/* Onglet Projets */}
        {activeTab === 'projets' && (
          <div className="space-y-6">
            <div className="bg-white rounded-xl shadow-md border border-slate-200 p-6">
              <h2 className="text-xl font-bold text-slate-900 mb-4">Mes projets</h2>
              <p className="text-slate-600 text-center py-8">
                Redirection vers la page Projets en cours...
              </p>
              {setTimeout(() => navigate(createPageUrl('Projects')), 0)}
            </div>
          </div>
        )}

        {/* Onglet Mes achats */}
        {activeTab === 'mes-achats' && (
          <div className="space-y-6">
            {/* Statistiques */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white rounded-xl shadow-md border border-slate-200 p-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                    <ShoppingBag className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-sm text-slate-600">Grilles achetées</p>
                    <p className="text-2xl font-bold text-slate-900">0</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-md border border-slate-200 p-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-purple-100 flex items-center justify-center">
                    <Package className="w-5 h-5 text-purple-600" />
                  </div>
                  <div>
                    <p className="text-sm text-slate-600">Montant total dépensé</p>
                    <p className="text-2xl font-bold text-slate-900">0.00€</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Liste des achats */}
            <div className="bg-white rounded-xl shadow-md border border-slate-200 p-6">
              <h2 className="text-xl font-bold text-slate-900 mb-4">Vos grilles</h2>
              
              <div className="text-center py-12">
                <ShoppingBag className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                <p className="text-slate-600 mb-2">Vous n'avez pas encore acheté de grille</p>
                <p className="text-sm text-slate-500 mb-4">
                  Explorez la Boutique pour découvrir des créations uniques
                </p>
                <Button
                  onClick={() => setActiveTab('boutique')}
                  className="bg-slate-900 hover:bg-slate-800"
                >
                  Parcourir la Boutique
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Onglet Mes ventes */}
        {activeTab === 'mes-ventes' && (
          <div className="space-y-6">
            {/* Statistiques globales */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="bg-white rounded-xl shadow-md border border-slate-200 p-6">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 rounded-lg bg-green-100 flex items-center justify-center">
                    <DollarSign className="w-5 h-5 text-green-600" />
                  </div>
                  <div>
                    <p className="text-sm text-slate-600">Revenus totaux</p>
                    <p className="text-2xl font-bold text-slate-900">0.00€</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-md border border-slate-200 p-6">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                    <ShoppingBag className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-sm text-slate-600">Ventes totales</p>
                    <p className="text-2xl font-bold text-slate-900">0</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-md border border-slate-200 p-6">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 rounded-lg bg-purple-100 flex items-center justify-center">
                    <TrendingUp className="w-5 h-5 text-purple-600" />
                  </div>
                  <div>
                    <p className="text-sm text-slate-600">Solde disponible</p>
                    <p className="text-2xl font-bold text-slate-900">0.00€</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-md border border-slate-200 p-6">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 rounded-lg bg-amber-100 flex items-center justify-center">
                    <Download className="w-5 h-5 text-amber-600" />
                  </div>
                  <div>
                    <p className="text-sm text-slate-600">Grilles publiées</p>
                    <p className="text-2xl font-bold text-slate-900">
                      {myGrids.length}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Mes grilles publiées */}
            <div className="bg-white rounded-xl shadow-md border border-slate-200 p-6">
              <h2 className="text-xl font-bold text-slate-900 mb-4">Mes grilles publiées</h2>
              
              {myGridsLoading ? (
                <p className="text-slate-600 text-center py-8">Chargement...</p>
              ) : myGrids.length === 0 ? (
                <p className="text-slate-600 text-center py-8">
                  Vous n'avez pas encore publié de grille dans la Boutique
                </p>
              ) : (
                <div className="space-y-4">
                  {myGrids.map((grid) => (
                    <div
                      key={grid.id}
                      className="flex items-center gap-4 p-4 bg-slate-50 rounded-lg"
                    >
                      {grid.preview_image && (
                        <div className="w-20 h-20 bg-white rounded border border-slate-200 overflow-hidden flex-shrink-0">
                          <img
                            src={grid.preview_image}
                            alt={grid.title}
                            className="w-full h-full object-cover"
                          />
                        </div>
                      )}
                      
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold text-slate-900 mb-1">{grid.title}</h3>
                        <div className="flex items-center gap-4 text-sm text-slate-600">
                          <span className="flex items-center gap-1">
                            <Eye className="w-4 h-4" />
                            {grid.views_count || 0} vues
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Historique des transactions */}
            <div className="bg-white rounded-xl shadow-md border border-slate-200 p-6">
              <h2 className="text-xl font-bold text-slate-900 mb-4">Historique des ventes</h2>
              
              <p className="text-slate-600 text-center py-8">
                Aucune vente pour le moment
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}