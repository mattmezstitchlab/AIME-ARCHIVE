import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '../utils';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  BarChart3, 
  Users, 
  ShoppingBag, 
  MessageSquare, 
  Settings, 
  ArrowLeft,
  Search,
  CheckCircle,
  DollarSign,
  TrendingUp,
  Grid3x3
} from 'lucide-react';

export default function AdminDashboard() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('stats');
  const [searchUser, setSearchUser] = useState('');

  // Vérifier que c'est bien l'admin
  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  // Rediriger si pas admin
  React.useEffect(() => {
    if (user && user.email !== 'matthieu.lecointre@gmail.com') {
      navigate(createPageUrl('GridEditor'));
    }
  }, [user, navigate]);

  // Récupérer les données
  const { data: allUsers = [] } = useQuery({
    queryKey: ['allUsers'],
    queryFn: () => base44.entities.User.list(),
    enabled: user?.email === 'matthieu.lecointre@gmail.com'
  });

  const { data: transactions = [] } = useQuery({
    queryKey: ['allTransactions'],
    queryFn: () => base44.entities.Transaction.list(),
    enabled: user?.email === 'matthieu.lecointre@gmail.com'
  });

  const { data: shopGrids = [] } = useQuery({
    queryKey: ['allShopGrids'],
    queryFn: () => base44.entities.ShopGrid.list(),
    enabled: user?.email === 'matthieu.lecointre@gmail.com'
  });

  const { data: supportTickets = [] } = useQuery({
    queryKey: ['allSupportTickets'],
    queryFn: () => base44.entities.SupportTicket.list('-created_date'),
    enabled: user?.email === 'matthieu.lecointre@gmail.com'
  });

  // Calculs statistiques
  const totalRevenue = transactions.reduce((sum, t) => sum + (t.total_price || 0), 0);
  const platformCommission = transactions.reduce((sum, t) => sum + (t.platform_share || 0), 0);
  const totalSales = transactions.length;
  const totalGrids = shopGrids.length;

  const filteredUsers = allUsers.filter(u => 
    u.email?.toLowerCase().includes(searchUser.toLowerCase()) ||
    u.full_name?.toLowerCase().includes(searchUser.toLowerCase())
  );

  if (!user || user.email !== 'matthieu.lecointre@gmail.com') {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <p className="text-white">Accès réservé à l'administrateur</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800">
      {/* Header */}
      <div className="bg-black border-b border-slate-700 px-8 py-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate(createPageUrl('GridEditor'))}
              className="text-slate-400 hover:text-white"
            >
              <ArrowLeft className="w-6 h-6" />
            </button>
            <div>
              <h1 className="text-3xl font-bold text-white flex items-center gap-3">
                ⚡ Espace Administrateur PATYBEE
              </h1>
              <p className="text-slate-400 text-sm mt-1">
                Interface réservée au créateur du logiciel
              </p>
            </div>
          </div>
          <div className="text-sm text-slate-400">
            Admin : {user.full_name}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-8 py-8">
        {/* Navigation tabs */}
        <div className="flex gap-2 mb-8 flex-wrap">
          <Button
            onClick={() => setActiveTab('stats')}
            variant={activeTab === 'stats' ? 'default' : 'outline'}
            className="gap-2"
          >
            <BarChart3 className="w-4 h-4" />
            Statistiques
          </Button>
          <Button
            onClick={() => setActiveTab('users')}
            variant={activeTab === 'users' ? 'default' : 'outline'}
            className="gap-2"
          >
            <Users className="w-4 h-4" />
            Utilisateurs ({allUsers.length})
          </Button>
          <Button
            onClick={() => setActiveTab('shop')}
            variant={activeTab === 'shop' ? 'default' : 'outline'}
            className="gap-2"
          >
            <ShoppingBag className="w-4 h-4" />
            Boutique ({shopGrids.length})
          </Button>
          <Button
            onClick={() => setActiveTab('support')}
            variant={activeTab === 'support' ? 'default' : 'outline'}
            className="gap-2"
          >
            <MessageSquare className="w-4 h-4" />
            Assistance ({supportTickets.filter(t => t.status === 'new').length})
          </Button>
          <Button
            onClick={() => setActiveTab('settings')}
            variant={activeTab === 'settings' ? 'default' : 'outline'}
            className="gap-2"
          >
            <Settings className="w-4 h-4" />
            Réglages
          </Button>
        </div>

        {/* Contenu */}
        {activeTab === 'stats' && (
          <div className="space-y-6">
            {/* Cards statistiques */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-slate-800 border border-slate-700 rounded-lg p-6">
                <div className="flex items-center justify-between mb-2">
                  <Users className="w-8 h-8 text-blue-400" />
                  <span className="text-2xl font-bold text-white">{allUsers.length}</span>
                </div>
                <p className="text-slate-400 text-sm">Utilisateurs totaux</p>
              </div>

              <div className="bg-slate-800 border border-slate-700 rounded-lg p-6">
                <div className="flex items-center justify-between mb-2">
                  <TrendingUp className="w-8 h-8 text-green-400" />
                  <span className="text-2xl font-bold text-white">{totalSales}</span>
                </div>
                <p className="text-slate-400 text-sm">Ventes totales</p>
              </div>

              <div className="bg-slate-800 border border-slate-700 rounded-lg p-6">
                <div className="flex items-center justify-between mb-2">
                  <DollarSign className="w-8 h-8 text-yellow-400" />
                  <span className="text-2xl font-bold text-white">{totalRevenue.toFixed(2)}€</span>
                </div>
                <p className="text-slate-400 text-sm">Chiffre d'affaires</p>
              </div>

              <div className="bg-slate-800 border border-slate-700 rounded-lg p-6">
                <div className="flex items-center justify-between mb-2">
                  <DollarSign className="w-8 h-8 text-purple-400" />
                  <span className="text-2xl font-bold text-white">{platformCommission.toFixed(2)}€</span>
                </div>
                <p className="text-slate-400 text-sm">Commission (30%)</p>
              </div>

              <div className="bg-slate-800 border border-slate-700 rounded-lg p-6">
                <div className="flex items-center justify-between mb-2">
                  <Grid3x3 className="w-8 h-8 text-pink-400" />
                  <span className="text-2xl font-bold text-white">{totalGrids}</span>
                </div>
                <p className="text-slate-400 text-sm">Grilles publiées</p>
              </div>
            </div>

            {/* Dernières transactions */}
            <div className="bg-slate-800 border border-slate-700 rounded-lg p-6">
              <h2 className="text-xl font-bold text-white mb-4">Dernières transactions</h2>
              <div className="space-y-3">
                {transactions.slice(0, 10).map(transaction => (
                  <div key={transaction.id} className="flex items-center justify-between p-3 bg-slate-700/50 rounded-lg">
                    <div>
                      <p className="text-white font-medium">{transaction.grid_title}</p>
                      <p className="text-sm text-slate-400">
                        {transaction.buyer_email} → {transaction.creator_email}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-white font-bold">{transaction.total_price?.toFixed(2)}€</p>
                      <p className="text-xs text-green-400">
                        +{transaction.platform_share?.toFixed(2)}€ commission
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'users' && (
          <div className="space-y-6">
            <div className="bg-slate-800 border border-slate-700 rounded-lg p-6">
              <div className="flex items-center gap-4 mb-6">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <Input
                    value={searchUser}
                    onChange={(e) => setSearchUser(e.target.value)}
                    placeholder="Rechercher par email ou nom..."
                    className="pl-10 bg-slate-700 border-slate-600 text-white"
                  />
                </div>
              </div>

              <div className="space-y-3">
                {filteredUsers.map(u => (
                  <div key={u.id} className="p-4 bg-slate-700/50 rounded-lg">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-white font-medium">{u.full_name}</p>
                        <p className="text-sm text-slate-400">{u.email}</p>
                        <p className="text-xs text-slate-500 mt-1">
                          Inscrit le {new Date(u.created_date).toLocaleDateString('fr-FR')}
                        </p>
                      </div>
                      <div className="text-right">
                        <span className={`px-2 py-1 rounded text-xs ${
                          u.role === 'admin' ? 'bg-purple-500/20 text-purple-300' : 'bg-blue-500/20 text-blue-300'
                        }`}>
                          {u.role || 'user'}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'shop' && (
          <div className="bg-slate-800 border border-slate-700 rounded-lg p-6">
            <h2 className="text-xl font-bold text-white mb-4">Grilles en boutique</h2>
            <div className="space-y-3">
              {shopGrids.map(grid => (
                <div key={grid.id} className="p-4 bg-slate-700/50 rounded-lg">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-white font-medium">{grid.title}</p>
                      <p className="text-sm text-slate-400">
                        par {grid.creator_name} ({grid.creator_email})
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-white font-bold">{grid.price}€</p>
                      <p className="text-xs text-slate-400">
                        {grid.downloads_count || 0} téléchargements
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'support' && (
          <div className="bg-slate-800 border border-slate-700 rounded-lg p-6">
            <h2 className="text-xl font-bold text-white mb-4">Demandes d'assistance</h2>
            <div className="space-y-3">
              {supportTickets.map(ticket => (
                <div key={ticket.id} className="p-4 bg-slate-700/50 rounded-lg">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-1">
                      <p className="text-white font-medium">{ticket.subject}</p>
                      <p className="text-sm text-slate-400">{ticket.user_name} ({ticket.user_email})</p>
                      <p className="text-sm text-slate-300 mt-2">{ticket.message}</p>
                    </div>
                    <div className="flex flex-col items-end gap-2">
                      <span className={`px-2 py-1 rounded text-xs ${
                        ticket.status === 'new' ? 'bg-yellow-500/20 text-yellow-300' :
                        ticket.status === 'in_progress' ? 'bg-blue-500/20 text-blue-300' :
                        'bg-green-500/20 text-green-300'
                      }`}>
                        {ticket.status === 'new' ? 'Nouveau' :
                         ticket.status === 'in_progress' ? 'En cours' : 'Résolu'}
                      </span>
                      {ticket.status !== 'resolved' && (
                        <Button size="sm" variant="outline" className="gap-2">
                          <CheckCircle className="w-3 h-3" />
                          Résolu
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'settings' && (
          <div className="bg-slate-800 border border-slate-700 rounded-lg p-6">
            <h2 className="text-xl font-bold text-white mb-4">Réglages généraux</h2>
            <p className="text-slate-400">Section en développement</p>
          </div>
        )}
      </div>
    </div>
  );
}