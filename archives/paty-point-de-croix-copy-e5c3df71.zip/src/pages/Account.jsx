import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '../utils';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ArrowLeft, Download } from 'lucide-react';
import { toast } from 'sonner';

export default function AccountPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);

  const { data: subscription } = useQuery({
    queryKey: ['subscription', user?.email],
    queryFn: async () => {
      if (!user?.email) return null;
      const subs = await base44.entities.Subscription.filter({ user_email: user.email });
      return subs[0] || null;
    },
    enabled: !!user?.email
  });

  const { data: invoices = [] } = useQuery({
    queryKey: ['invoices', user?.email],
    queryFn: async () => {
      if (!user?.email) return [];
      return base44.entities.Invoice.filter({ user_email: user.email }, '-created_date');
    },
    enabled: !!user?.email
  });

  useEffect(() => {
    const loadUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
      } catch (error) {
        navigate(createPageUrl('Login'));
      }
    };
    loadUser();
  }, [navigate]);

  const cancelSubscriptionMutation = useMutation({
    mutationFn: async () => {
      await base44.entities.Subscription.update(subscription.id, {
        auto_renew: false
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['subscription']);
      toast.success('Renouvellement automatique annulé');
    }
  });

  const planNames = {
    decouverte: 'PatyBee Découverte',
    creatrice: 'PatyBee Créatrice',
    studio: 'PatyBee Studio'
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-slate-900"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="bg-white border-b border-slate-200 px-8 py-6">
        <div className="flex items-center gap-4 mb-2">
          <button
            onClick={() => navigate(createPageUrl('Dashboard'))}
            className="text-slate-600 hover:text-slate-900"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-3xl font-bold text-slate-900">Mon compte</h1>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-8 py-8 space-y-8">
        {/* Informations personnelles */}
        <section className="bg-white border border-slate-200 rounded-lg p-6">
          <h2 className="text-xl font-semibold text-slate-900 mb-4">Informations personnelles</h2>
          <div className="space-y-4">
            <div>
              <Label>Nom complet</Label>
              <Input value={user.full_name || ''} readOnly />
            </div>
            <div>
              <Label>Email</Label>
              <Input value={user.email} readOnly />
            </div>
          </div>
        </section>

        {/* Abonnement */}
        <section className="bg-white border border-slate-200 rounded-lg p-6">
          <h2 className="text-xl font-semibold text-slate-900 mb-4">Abonnement</h2>
          
          {subscription ? (
            <div className="space-y-4">
              <div className="flex justify-between items-center p-4 bg-slate-50 rounded-lg">
                <div>
                  <div className="font-semibold text-lg">{planNames[subscription.plan_type]}</div>
                  <div className="text-sm text-slate-600">
                    {subscription.price_monthly === 0 ? 'Gratuit' : `${subscription.price_monthly}€/mois`}
                  </div>
                  {subscription.renewal_date && (
                    <div className="text-sm text-slate-600 mt-1">
                      Renouvellement : {new Date(subscription.renewal_date).toLocaleDateString('fr-FR')}
                    </div>
                  )}
                  {!subscription.auto_renew && (
                    <div className="text-sm text-amber-600 mt-1">
                      Renouvellement automatique désactivé
                    </div>
                  )}
                </div>
                <div className="space-x-2">
                  <Button
                    variant="outline"
                    onClick={() => navigate(createPageUrl('Signup'))}
                  >
                    Changer de forfait
                  </Button>
                  {subscription.auto_renew && (
                    <Button
                      variant="destructive"
                      onClick={() => {
                        if (confirm('Annuler le renouvellement automatique ?')) {
                          cancelSubscriptionMutation.mutate();
                        }
                      }}
                    >
                      Annuler le renouvellement
                    </Button>
                  )}
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-slate-600 mb-4">Aucun abonnement actif</p>
              <Button onClick={() => navigate(createPageUrl('Signup'))}>
                Choisir un forfait
              </Button>
            </div>
          )}
        </section>

        {/* Factures */}
        <section className="bg-white border border-slate-200 rounded-lg p-6">
          <h2 className="text-xl font-semibold text-slate-900 mb-4">Factures & paiements</h2>
          
          {invoices.length > 0 ? (
            <div className="space-y-2">
              {invoices.map((invoice) => (
                <div key={invoice.id} className="flex justify-between items-center p-4 border border-slate-200 rounded-lg">
                  <div>
                    <div className="font-semibold">
                      {new Date(invoice.created_date).toLocaleDateString('fr-FR')}
                    </div>
                    <div className="text-sm text-slate-600">
                      {invoice.amount}€ • {invoice.status === 'paid' ? 'Payé' : 'En attente'}
                    </div>
                  </div>
                  <Button variant="outline" size="sm">
                    <Download className="w-4 h-4 mr-2" />
                    Télécharger
                  </Button>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-center text-slate-600 py-8">Aucune facture</p>
          )}
        </section>
      </div>
    </div>
  );
}