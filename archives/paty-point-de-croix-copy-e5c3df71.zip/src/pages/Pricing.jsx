import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Check, Sparkles, Crown, Zap } from 'lucide-react';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '../utils';

const PLANS = [
  {
    id: 'basic',
    name: 'PatyBee Basic',
    price: 5.90,
    icon: Zap,
    color: 'blue',
    features: [
      'Création et sauvegarde de projets',
      'Import d\'images simple',
      'Palette DMC de base',
      'Grille 10×10',
      'Export basique'
    ]
  },
  {
    id: 'premium',
    name: 'PatyBee Premium',
    price: 9.90,
    icon: Sparkles,
    color: 'purple',
    popular: true,
    features: [
      'Tous les outils de grille',
      'Import PDF (couverture)',
      'Zone du jour avancée',
      'PatyBee IA active',
      'Palette DMC complète',
      'Symboles personnalisés',
      'Export PDF avancé'
    ]
  },
  {
    id: 'creator',
    name: 'PatyBee Créateur',
    price: 14.90,
    icon: Crown,
    color: 'amber',
    features: [
      'Tout Premium',
      'Accès Boutique comme vendeur',
      'Publication de grilles',
      'Statistiques de ventes',
      'Royalties automatiques (85%)',
      'Badge créateur',
      'Support prioritaire'
    ]
  }
];

export default function Pricing() {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);

  const { data: user } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me(),
  });

  const { data: subscription } = useQuery({
    queryKey: ['user-subscription', user?.email],
    queryFn: async () => {
      if (!user) return null;
      const subs = await base44.entities.UserSubscription.filter({ user_email: user.email });
      return subs[0] || null;
    },
    enabled: !!user
  });

  const handleSubscribe = async (planId) => {
    if (!user) {
      toast.error('Veuillez vous connecter');
      return;
    }

    setIsLoading(true);

    try {
      const response = await base44.functions.invoke('createCheckoutSession', {
        type: 'subscription',
        plan: planId
      });

      if (response.data.url) {
        window.location.href = response.data.url;
      } else {
        toast.error('Erreur lors de la création de la session');
      }
    } catch (error) {
      console.error('Erreur:', error);
      toast.error('Erreur lors de la création de la session');
    } finally {
      setIsLoading(false);
    }
  };

  const handleStartTrial = async () => {
    if (!user) {
      toast.error('Veuillez vous connecter');
      return;
    }

    try {
      // Vérifier si un essai n'a pas déjà été utilisé
      if (subscription && subscription.status !== 'none') {
        toast.info('Vous avez déjà un abonnement ou un essai en cours');
        return;
      }

      const trialEnd = new Date();
      trialEnd.setDate(trialEnd.getDate() + 3);

      if (subscription) {
        await base44.entities.UserSubscription.update(subscription.id, {
          status: 'trial',
          plan: 'premium',
          trial_end: trialEnd.toISOString()
        });
      } else {
        await base44.entities.UserSubscription.create({
          user_email: user.email,
          status: 'trial',
          plan: 'premium',
          trial_end: trialEnd.toISOString()
        });
      }

      toast.success('Essai gratuit activé pour 3 jours !');
      navigate(createPageUrl('GridEditor'));
    } catch (error) {
      console.error('Erreur:', error);
      toast.error('Erreur lors de l\'activation de l\'essai');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 py-12">
      <div className="container mx-auto px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-slate-900 mb-4">
            Choisis ton forfait PatyBee
          </h1>
          <p className="text-lg text-slate-600 mb-6">
            Tous les forfaits incluent les mises à jour gratuites
          </p>
          
          <Button
            onClick={handleStartTrial}
            size="lg"
            className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
          >
            ✨ Essai gratuit 3 jours (Premium)
          </Button>
        </div>

        {/* Plans */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {PLANS.map((plan) => {
            const Icon = plan.icon;
            const isCurrentPlan = subscription?.plan === plan.id;
            
            return (
              <div
                key={plan.id}
                className={`bg-white rounded-2xl shadow-lg border-2 transition-all hover:shadow-xl ${
                  plan.popular ? 'border-purple-500 relative' : 'border-slate-200'
                } ${isCurrentPlan ? 'ring-2 ring-green-500' : ''}`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-gradient-to-r from-purple-600 to-pink-600 text-white px-4 py-1 rounded-full text-sm font-semibold">
                    🔥 Populaire
                  </div>
                )}

                <div className="p-8">
                  <div className={`w-12 h-12 rounded-lg bg-${plan.color}-100 flex items-center justify-center mb-4`}>
                    <Icon className={`w-6 h-6 text-${plan.color}-600`} />
                  </div>

                  <h3 className="text-2xl font-bold text-slate-900 mb-2">{plan.name}</h3>
                  
                  <div className="mb-6">
                    <span className="text-4xl font-bold text-slate-900">{plan.price}€</span>
                    <span className="text-slate-600">/mois</span>
                  </div>

                  <ul className="space-y-3 mb-8">
                    {plan.features.map((feature, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-sm text-slate-600">
                        <Check className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <Button
                    onClick={() => handleSubscribe(plan.id)}
                    disabled={isLoading || isCurrentPlan}
                    className={`w-full ${
                      plan.popular
                        ? 'bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700'
                        : 'bg-slate-900 hover:bg-slate-800'
                    }`}
                  >
                    {isCurrentPlan ? '✓ Forfait actuel' : 'S\'abonner'}
                  </Button>
                </div>
              </div>
            );
          })}
        </div>

        {/* FAQ / Info */}
        <div className="mt-16 max-w-3xl mx-auto bg-white rounded-xl shadow-md border border-slate-200 p-8">
          <h3 className="text-xl font-bold text-slate-900 mb-4">💳 Informations de paiement</h3>
          <ul className="space-y-2 text-sm text-slate-600">
            <li>• Paiement sécurisé via Stripe</li>
            <li>• Résiliation possible à tout moment</li>
            <li>• Essai gratuit de 3 jours (sans engagement)</li>
            <li>• Créateurs : 85% de commission sur chaque vente</li>
          </ul>
        </div>
      </div>
    </div>
  );
}