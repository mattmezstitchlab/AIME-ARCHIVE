import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Récupérer le profil utilisateur
    const profiles = await base44.entities.UserProfile.filter({ created_by: user.email });
    const userProfile = profiles[0];

    if (!userProfile || !userProfile.profil_creatif) {
      return Response.json({ 
        error: 'Profil créatif non trouvé',
        message: 'Veuillez d\'abord compléter votre profil créatif'
      }, { status: 404 });
    }

    const p = userProfile.profil_creatif;

    // Analyse couleurs
    const scoreCouleurs = (p.couleurs_favorites?.length || 0) * 5;

    // Analyse symboles
    const scoreSymboles = (p.symboles_favoris?.length || 0) * 3;

    // Analyse styles
    const scoreStyles = (p.styles_artistiques?.length || 0) * 7;

    // Analyse émotions
    const scoreEmotions = (p.themes_emotions?.length || 0) * 8;

    // Score de personnalité
    const scorePersonnalite = 
        (p.rythme_broderie === "rapide" ? 10 : 
         p.rythme_broderie === "lent" ? 5 : 8)
        + (p.preferences_complexite === "simple" ? 5 :
           p.preferences_complexite === "complexe" ? 10 : 8);

    // Score global
    const scoreGlobal = scoreCouleurs + scoreSymboles + scoreStyles + scoreEmotions + scorePersonnalite;

    // Signature simplifiée
    const signatureSimplifiee = "S-" + Math.floor(scoreGlobal * 1.37);

    // Trouver modèles compatibles
    const recommandationsModeles = await trouverModelesCompatibles(p, base44);

    // Trouver brodeuses compatibles
    const compatibilites = await trouverBrodeusesCompatibles(p, base44, user.email);

    // Recommandations de couleurs basées sur le profil
    const recommandationsCouleurs = genererRecommandationsCouleurs(p);

    // Mettre à jour le profil
    const updatedProfile = await base44.entities.UserProfile.update(userProfile.id, {
      profil_creatif: {
        ...p,
        signature_simplifiee: signatureSimplifiee
      },
      matching_creatif: {
        recommandations_modeles: recommandationsModeles,
        recommandations_artistes: [],
        recommandations_couleurs: recommandationsCouleurs,
        compatibilites: compatibilites
      }
    });

    return Response.json({
      success: true,
      scores: {
        couleurs: scoreCouleurs,
        symboles: scoreSymboles,
        styles: scoreStyles,
        emotions: scoreEmotions,
        personnalite: scorePersonnalite,
        global: scoreGlobal
      },
      signature: signatureSimplifiee,
      recommandations: {
        modeles: recommandationsModeles,
        couleurs: recommandationsCouleurs,
        compatibilites: compatibilites
      }
    });

  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});

// Fonction helper : trouver modèles compatibles
async function trouverModelesCompatibles(profilCreatif, base44) {
  try {
    // Récupérer les grilles de la boutique
    const shopGrids = await base44.entities.ShopGrid.list('-downloads_count', 50);
    
    const modeles = shopGrids.map(grid => {
      const gridData = grid.grid_data || {};
      
      // Extraire les couleurs du modèle
      const modeleColors = [];
      if (gridData.pattern?.colors) {
        modeleColors.push(...gridData.pattern.colors.map(c => c.hex));
      }
      if (gridData.stitches) {
        gridData.stitches.forEach(s => {
          if (s.color && !modeleColors.includes(s.color)) {
            modeleColors.push(s.color);
          }
        });
      }
      
      // Compatibilité couleurs : vérifier si couleurs favorites présentes
      const matchCouleurs = (profilCreatif.couleurs_favorites || []).some(c => 
        modeleColors.includes(c)
      ) ? 20 : 5;
      
      // Compatibilité style : analyser le titre et description
      const modeleText = `${grid.title} ${grid.description || ''}`.toLowerCase();
      const matchStyle = (profilCreatif.styles_artistiques || []).some(style => 
        modeleText.includes(style.toLowerCase())
      ) ? 30 : 10;
      
      // Compatibilité émotion : analyser thèmes émotionnels
      const matchEmotion = (profilCreatif.themes_emotions || []).some(emotion => 
        modeleText.includes(emotion.toLowerCase())
      ) ? 40 : 8;
      
      // Score de complexité selon préférence
      const nbPoints = gridData.stitches?.length || 0;
      let scoreComplexite = 0;
      if (profilCreatif.preferences_complexite === "simple" && nbPoints < 500) scoreComplexite = 15;
      if (profilCreatif.preferences_complexite === "equilibre" && nbPoints >= 500 && nbPoints <= 2000) scoreComplexite = 15;
      if (profilCreatif.preferences_complexite === "complexe" && nbPoints > 2000) scoreComplexite = 15;
      
      const score = matchCouleurs + matchStyle + matchEmotion + scoreComplexite;
      
      return {
        modele: {
          id: grid.id,
          titre: grid.title,
          description: grid.description,
          couleurs: modeleColors,
          preview_image: grid.preview_image
        },
        score: score,
        details: {
          matchCouleurs,
          matchStyle,
          matchEmotion,
          scoreComplexite
        }
      };
    });
    
    // Trier par score et retourner top 10
    return modeles
      .sort((a, b) => b.score - a.score)
      .slice(0, 10);
      
  } catch (error) {
    console.error('Erreur lors de la recherche de modèles:', error);
    return [];
  }
}

// Fonction helper : trouver brodeuses compatibles
async function trouverBrodeusesCompatibles(profilCreatif, base44, currentUserEmail) {
  try {
    // Récupérer les autres profils utilisateurs
    const allProfiles = await base44.asServiceRole.entities.UserProfile.list('-created_date', 50);
    
    const compatibilites = allProfiles
      .filter(profile => profile.created_by !== currentUserEmail && profile.profil_creatif)
      .map(profile => {
        let score = 0;
        const otherProfile = profile.profil_creatif;
        
        // Matching couleurs (4 points par couleur commune)
        const couleursCommunes = (profilCreatif.couleurs_favorites || [])
          .filter(c => (otherProfile.couleurs_favorites || []).includes(c));
        score += couleursCommunes.length * 4;
        
        // Matching symboles (3 points par symbole commun)
        const symbolesCommuns = (profilCreatif.symboles_favoris || [])
          .filter(s => (otherProfile.symboles_favoris || []).includes(s));
        score += symbolesCommuns.length * 3;
        
        // Matching passions (10 points par passion commune)
        const passionsCommunes = (profilCreatif.passions || [])
          .filter(p => (otherProfile.passions || []).includes(p));
        score += passionsCommunes.length * 10;
        
        // Matching styles artistiques
        const stylesCommuns = (profilCreatif.styles_artistiques || [])
          .filter(s => (otherProfile.styles_artistiques || []).includes(s));
        score += stylesCommuns.length * 5;
        
        // Bonus niveau et rythme similaires
        if (profilCreatif.niveau === otherProfile.niveau) score += 5;
        if (profilCreatif.rythme_broderie === otherProfile.rythme_broderie) score += 5;
        
        // Limiter le score à 100
        const compatibiliteScore = Math.min(100, Math.floor(score));
        
        return {
          utilisateur: {
            email: profile.created_by,
            nom: profile.pseudo || profile.prenom || 'Utilisateur',
            photo_url: profile.photo_url
          },
          compatibilite: compatibiliteScore,
          points_communs: {
            couleurs: couleursCommunes,
            symboles: symbolesCommuns,
            passions: passionsCommunes,
            styles: stylesCommuns
          }
        };
      })
      .filter(compat => compat.compatibilite > 10)
      .sort((a, b) => b.compatibilite - a.compatibilite)
      .slice(0, 10);
    
    return compatibilites;
    
  } catch (error) {
    console.error('Erreur lors de la recherche de compatibilités:', error);
    return [];
  }
}

// Fonction helper : générer recommandations de couleurs
function genererRecommandationsCouleurs(profilCreatif) {
  const palettesBase = {
    nature: ['#2D5016', '#8BC34A', '#CDDC39', '#795548', '#A1887F'],
    ocean: ['#006064', '#0097A7', '#00BCD4', '#4DD0E1', '#B2EBF2'],
    feu: ['#BF360C', '#E64A19', '#FF5722', '#FF7043', '#FFAB91'],
    pastel: ['#F8BBD0', '#E1BEE7', '#C5CAE9', '#B3E5FC', '#B2DFDB'],
    automne: ['#8D6E63', '#D84315', '#FF6F00', '#F57C00', '#FFA726']
  };
  
  // Recommander une palette selon les thèmes émotionnels
  const themes = profilCreatif.themes_emotions || [];
  
  if (themes.includes('nature') || themes.includes('zen')) {
    return palettesBase.nature;
  }
  if (themes.includes('ocean') || themes.includes('calme')) {
    return palettesBase.ocean;
  }
  if (themes.includes('passion') || themes.includes('energie')) {
    return palettesBase.feu;
  }
  if (themes.includes('douceur') || themes.includes('tendresse')) {
    return palettesBase.pastel;
  }
  
  // Par défaut, palette automne
  return palettesBase.automne;
}