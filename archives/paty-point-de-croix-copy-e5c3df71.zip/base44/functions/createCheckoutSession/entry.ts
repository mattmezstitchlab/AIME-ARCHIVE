import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';
import Stripe from 'npm:stripe';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY'), {
  apiVersion: '2023-10-16',
});

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Non authentifié' }, { status: 401 });
    }

    const { type, plan, shopGridId } = await req.json();

    // Récupérer ou créer le customer Stripe
    const subscriptions = await base44.entities.UserSubscription.filter({ user_email: user.email });
    let customerId = subscriptions[0]?.stripe_customer_id;

    if (!customerId) {
      const customer = await stripe.customers.create({
        email: user.email,
        metadata: { user_email: user.email }
      });
      customerId = customer.id;
    }

    const successUrl = `${req.headers.get('origin')}/GridEditor?session_id={CHECKOUT_SESSION_ID}`;
    const cancelUrl = `${req.headers.get('origin')}/GridEditor`;

    if (type === 'subscription') {
      // Créer une session d'abonnement
      const priceIds = {
        basic: 'price_basic_monthly', // À remplacer par vos vrais price IDs Stripe
        premium: 'price_premium_monthly',
        creator: 'price_creator_monthly'
      };

      const session = await stripe.checkout.sessions.create({
        customer: customerId,
        mode: 'subscription',
        line_items: [{
          price: priceIds[plan],
          quantity: 1
        }],
        success_url: successUrl,
        cancel_url: cancelUrl,
        metadata: {
          user_email: user.email,
          plan: plan,
          type: 'subscription'
        }
      });

      return Response.json({ sessionId: session.id, url: session.url });
    }

    if (type === 'pattern') {
      // Acheter une grille
      const shopGrids = await base44.asServiceRole.entities.ShopGrid.filter({ id: shopGridId });
      if (!shopGrids || shopGrids.length === 0) {
        return Response.json({ error: 'Grille introuvable' }, { status: 404 });
      }

      const grid = shopGrids[0];
      const amountInCents = Math.round(grid.price * 100);

      const session = await stripe.checkout.sessions.create({
        customer: customerId,
        mode: 'payment',
        line_items: [{
          price_data: {
            currency: 'eur',
            product_data: {
              name: grid.title,
              description: `Grille de broderie par ${grid.creator_name}`,
              images: grid.preview_image ? [grid.preview_image] : []
            },
            unit_amount: amountInCents
          },
          quantity: 1
        }],
        success_url: successUrl,
        cancel_url: cancelUrl,
        metadata: {
          user_email: user.email,
          shop_grid_id: shopGridId,
          creator_email: grid.creator_email,
          type: 'pattern_purchase'
        }
      });

      return Response.json({ sessionId: session.id, url: session.url });
    }

    return Response.json({ error: 'Type invalide' }, { status: 400 });
  } catch (error) {
    console.error('Erreur:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});