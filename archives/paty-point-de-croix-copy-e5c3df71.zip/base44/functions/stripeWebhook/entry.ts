import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';
import Stripe from 'npm:stripe';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY'), {
  apiVersion: '2023-10-16',
});

const webhookSecret = Deno.env.get('STRIPE_WEBHOOK_SECRET');

Deno.serve(async (req) => {
  try {
    const signature = req.headers.get('stripe-signature');
    const body = await req.text();

    // Vérifier la signature du webhook
    const event = stripe.webhooks.constructEvent(body, signature, webhookSecret);

    // Initialiser le SDK Base44 en mode service role
    const base44 = createClientFromRequest(req);

    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object;
        const metadata = session.metadata;

        if (metadata.type === 'subscription') {
          // Activer l'abonnement
          const subscriptions = await base44.asServiceRole.entities.UserSubscription.filter({
            user_email: metadata.user_email
          });

          if (subscriptions.length > 0) {
            await base44.asServiceRole.entities.UserSubscription.update(subscriptions[0].id, {
              stripe_customer_id: session.customer,
              stripe_subscription_id: session.subscription,
              status: 'active',
              plan: metadata.plan
            });
          } else {
            await base44.asServiceRole.entities.UserSubscription.create({
              user_email: metadata.user_email,
              stripe_customer_id: session.customer,
              stripe_subscription_id: session.subscription,
              status: 'active',
              plan: metadata.plan
            });
          }
        }

        if (metadata.type === 'pattern_purchase') {
          // Enregistrer l'achat de grille
          const amount = session.amount_total / 100;
          const creatorShare = amount * 0.85;
          const platformShare = amount * 0.15;

          await base44.asServiceRole.entities.PatternPurchase.create({
            user_email: metadata.user_email,
            shop_grid_id: metadata.shop_grid_id,
            stripe_payment_intent_id: session.payment_intent,
            amount_paid: amount,
            creator_email: metadata.creator_email,
            creator_share: creatorShare,
            platform_share: platformShare,
            grid_title: session.line_items?.data[0]?.description || 'Grille'
          });

          // Mettre à jour les revenus du créateur
          const revenues = await base44.asServiceRole.entities.CreatorRevenue.filter({
            creator_email: metadata.creator_email
          });

          if (revenues.length > 0) {
            const revenue = revenues[0];
            await base44.asServiceRole.entities.CreatorRevenue.update(revenue.id, {
              total_revenue: (revenue.total_revenue || 0) + creatorShare,
              total_sales: (revenue.total_sales || 0) + 1,
              available_balance: (revenue.available_balance || 0) + creatorShare
            });
          } else {
            await base44.asServiceRole.entities.CreatorRevenue.create({
              creator_email: metadata.creator_email,
              total_revenue: creatorShare,
              total_sales: 1,
              available_balance: creatorShare
            });
          }

          // Incrémenter le compteur de vues (à adapter selon votre logique)
          const grids = await base44.asServiceRole.entities.ShopGrid.filter({
            id: metadata.shop_grid_id
          });
          if (grids.length > 0) {
            await base44.asServiceRole.entities.ShopGrid.update(grids[0].id, {
              views_count: (grids[0].views_count || 0) + 1
            });
          }
        }
        break;
      }

      case 'customer.subscription.updated': {
        const subscription = event.data.object;
        const userEmail = subscription.metadata?.user_email;

        if (userEmail) {
          const subscriptions = await base44.asServiceRole.entities.UserSubscription.filter({
            user_email: userEmail
          });

          if (subscriptions.length > 0) {
            await base44.asServiceRole.entities.UserSubscription.update(subscriptions[0].id, {
              status: subscription.status === 'active' ? 'active' : 'past_due',
              current_period_end: new Date(subscription.current_period_end * 1000).toISOString()
            });
          }
        }
        break;
      }

      case 'customer.subscription.deleted': {
        const subscription = event.data.object;
        const userEmail = subscription.metadata?.user_email;

        if (userEmail) {
          const subscriptions = await base44.asServiceRole.entities.UserSubscription.filter({
            user_email: userEmail
          });

          if (subscriptions.length > 0) {
            await base44.asServiceRole.entities.UserSubscription.update(subscriptions[0].id, {
              status: 'cancelled',
              plan: 'free'
            });
          }
        }
        break;
      }
    }

    return Response.json({ received: true });
  } catch (error) {
    console.error('Webhook error:', error);
    return Response.json({ error: error.message }, { status: 400 });
  }
});