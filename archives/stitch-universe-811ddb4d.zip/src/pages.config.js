import Home from './pages/Home';
import Library from './pages/Library';
import Creator from './pages/Creator';
import PatternReader from './pages/PatternReader';
import Profile from './pages/Profile';
import DMCSettings from './pages/DMCSettings';
import StitchSettings from './pages/StitchSettings';
import PatyShop from './pages/PatyShop';
import WorkSettings from './pages/WorkSettings';
import GlobalRanking from './pages/GlobalRanking';
import Inspiration from './pages/Inspiration';
import Community from './pages/Community';
import Shop from './pages/Shop';
import RelaxMode from './pages/RelaxMode';
import __Layout from './Layout.jsx';


export const PAGES = {
    "Home": Home,
    "Library": Library,
    "Creator": Creator,
    "PatternReader": PatternReader,
    "Profile": Profile,
    "DMCSettings": DMCSettings,
    "StitchSettings": StitchSettings,
    "PatyShop": PatyShop,
    "WorkSettings": WorkSettings,
    "GlobalRanking": GlobalRanking,
    "Inspiration": Inspiration,
    "Community": Community,
    "Shop": Shop,
    "RelaxMode": RelaxMode,
}

export const pagesConfig = {
    mainPage: "Home",
    Pages: PAGES,
    Layout: __Layout,
};