import { base44 } from '@/api/base44Client';

/**
 * Get DMC color library from database or localStorage
 */
export const getDMCLibrary = async () => {
  try {
    const isAuth = await base44.auth.isAuthenticated();
    if (isAuth) {
      return await base44.entities.DMCColor.list();
    } else {
      const localColors = localStorage.getItem('paticroix_dmc_colors');
      return localColors ? JSON.parse(localColors) : [];
    }
  } catch (error) {
    console.error('Erreur chargement bibliothèque DMC:', error);
    return [];
  }
};

/**
 * Find DMC color by code
 */
export const findDMCByCode = async (code) => {
  const library = await getDMCLibrary();
  return library.find(c => c.code === code);
};

/**
 * Find closest DMC color by hex value
 */
export const findClosestDMC = async (targetHex) => {
  const library = await getDMCLibrary();
  if (library.length === 0) return null;

  // Convert hex to RGB
  const hexToRgb = (hex) => {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
      r: parseInt(result[1], 16),
      g: parseInt(result[2], 16),
      b: parseInt(result[3], 16)
    } : null;
  };

  // Calculate color distance
  const colorDistance = (rgb1, rgb2) => {
    return Math.sqrt(
      Math.pow(rgb1.r - rgb2.r, 2) +
      Math.pow(rgb1.g - rgb2.g, 2) +
      Math.pow(rgb1.b - rgb2.b, 2)
    );
  };

  const targetRgb = hexToRgb(targetHex);
  if (!targetRgb) return null;

  let closest = library[0];
  let minDistance = Infinity;

  for (const color of library) {
    const colorRgb = hexToRgb(color.color_hex);
    if (!colorRgb) continue;

    const distance = colorDistance(targetRgb, colorRgb);
    if (distance < minDistance) {
      minDistance = distance;
      closest = color;
    }
  }

  return closest;
};