/**
 * Image processing utilities for cross-stitch pattern generation
 */

/**
 * Resize image to exact grid dimensions
 */
export const resizeImageToGrid = (imageFile, width, height) => {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');

    img.onload = () => {
      canvas.width = width;
      canvas.height = height;

      // Draw image scaled to exact grid size
      ctx.drawImage(img, 0, 0, width, height);

      // Get image data
      const imageData = ctx.getImageData(0, 0, width, height);
      resolve(imageData);
    };

    img.onerror = reject;
    img.src = URL.createObjectURL(imageFile);
  });
};

/**
 * Quantize colors using median cut algorithm
 */
export const quantizeColors = (imageData, numColors) => {
  const pixels = [];
  const data = imageData.data;

  // Extract RGB values
  for (let i = 0; i < data.length; i += 4) {
    pixels.push({
      r: data[i],
      g: data[i + 1],
      b: data[i + 2]
    });
  }

  // Simple color quantization using k-means clustering
  const palette = kMeansClustering(pixels, numColors);
  
  return palette;
};

/**
 * K-means clustering for color quantization
 */
const kMeansClustering = (pixels, k) => {
  // Initialize centroids randomly
  let centroids = [];
  for (let i = 0; i < k; i++) {
    const randomPixel = pixels[Math.floor(Math.random() * pixels.length)];
    centroids.push({ ...randomPixel });
  }

  // Iterate to find optimal centroids
  for (let iteration = 0; iteration < 10; iteration++) {
    const clusters = Array.from({ length: k }, () => []);

    // Assign pixels to nearest centroid
    pixels.forEach(pixel => {
      let minDist = Infinity;
      let closestCluster = 0;

      centroids.forEach((centroid, idx) => {
        const dist = colorDistance(pixel, centroid);
        if (dist < minDist) {
          minDist = dist;
          closestCluster = idx;
        }
      });

      clusters[closestCluster].push(pixel);
    });

    // Recalculate centroids
    centroids = clusters.map(cluster => {
      if (cluster.length === 0) return centroids[0];

      const sum = cluster.reduce(
        (acc, pixel) => ({
          r: acc.r + pixel.r,
          g: acc.g + pixel.g,
          b: acc.b + pixel.b
        }),
        { r: 0, g: 0, b: 0 }
      );

      return {
        r: Math.round(sum.r / cluster.length),
        g: Math.round(sum.g / cluster.length),
        b: Math.round(sum.b / cluster.length)
      };
    });
  }

  return centroids;
};

/**
 * Calculate color distance
 */
const colorDistance = (c1, c2) => {
  return Math.sqrt(
    Math.pow(c1.r - c2.r, 2) +
    Math.pow(c1.g - c2.g, 2) +
    Math.pow(c1.b - c2.b, 2)
  );
};

/**
 * Map pixels to closest palette color
 */
export const mapToClosestColor = (pixel, palette) => {
  let minDist = Infinity;
  let closestColor = palette[0];

  palette.forEach(color => {
    const dist = colorDistance(pixel, color);
    if (dist < minDist) {
      minDist = dist;
      closestColor = color;
    }
  });

  return closestColor;
};

/**
 * Convert RGB to hex
 */
export const rgbToHex = (r, g, b) => {
  return '#' + [r, g, b].map(x => {
    const hex = x.toString(16);
    return hex.length === 1 ? '0' + hex : hex;
  }).join('');
};

/**
 * Generate symbols for colors
 */
const SYMBOLS = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '#', '@', '*', '+', '=', '%', '&', '$'];

export const assignSymbols = (palette) => {
  return palette.map((color, index) => ({
    ...color,
    symbol: SYMBOLS[index % SYMBOLS.length]
  }));
};