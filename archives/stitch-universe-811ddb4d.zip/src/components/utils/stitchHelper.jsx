import { base44 } from '@/api/base44Client';

/**
 * Get stitch settings from database or localStorage
 */
export const getStitchSettings = async () => {
  try {
    const isAuth = await base44.auth.isAuthenticated();
    if (isAuth) {
      const settings = await base44.entities.StitchSettings.list();
      return settings.length > 0 ? settings[0] : getDefaultSettings();
    } else {
      const localSettings = localStorage.getItem('paticroix_stitch_settings');
      return localSettings ? JSON.parse(localSettings) : getDefaultSettings();
    }
  } catch (error) {
    console.error('Erreur chargement paramètres points:', error);
    return getDefaultSettings();
  }
};

const getDefaultSettings = () => ({
  full_cross_enabled: true,
  half_stitch_enabled: false,
  quarter_stitch_enabled: false,
  backstitch_enabled: false,
  special_stitches_enabled: false,
  beads_enabled: false,
  bead_symbol: 'O',
  bead_color: '#FFD700',
  highlight_special_stitches: true,
  highlight_beads: true,
  show_bead_counter: true
});

/**
 * Check if a symbol represents a bead
 */
export const isBead = (symbol, settings) => {
  return settings?.beads_enabled && symbol === settings.bead_symbol;
};

/**
 * Get stitch type label
 */
export const getStitchTypeLabel = (type) => {
  const labels = {
    full_cross: 'Croix pleine',
    half_stitch: 'Demi-point',
    quarter_stitch: 'Quart de point',
    backstitch: 'Point arrière',
    special: 'Point spécial',
    bead: 'Perle'
  };
  return labels[type] || 'Croix pleine';
};