import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { X, Send, Sparkles, Grid3x3, Palette, Settings, Lightbulb, ShoppingBag } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { createPageUrl } from '../../utils';

const QUICK_ACTIONS = [
  {
    id: 'change_size',
    label: 'Changer la taille de ma grille',
    icon: Grid3x3,
    action: 'navigate',
    target: 'Creator',
    message: "Je t'emmène changer la taille. Tu peux ajuster largeur et hauteur pour ton projet."
  },
  {
    id: 'modify_stitches',
    label: 'Modifier les types de points',
    icon: Sparkles,
    action: 'navigate',
    target: 'StitchSettings',
    message: "Voici les types de points et perles. Active seulement ceux que tu utilises."
  },
  {
    id: 'modify_dmc',
    label: 'Modifier mes fils DMC',
    icon: Palette,
    action: 'navigate',
    target: 'DMCSettings',
    message: "Tu peux ici ajouter, renommer ou corriger tes fils DMC."
  },
  {
    id: 'simplify',
    label: 'Simplifier mon projet',
    icon: Lightbulb,
    action: 'navigate',
    target: 'Creator',
    message: "On peut simplifier : moins de couleurs, plus petit, ou seulement des croix pleines. Choisis ce que tu préfères."
  },
  {
    id: 'view_legend',
    label: 'Voir la légende et les couleurs',
    icon: Palette,
    action: 'navigate',
    target: 'Library',
    message: "Voici tous tes projets. Ouvre-en un pour voir la légende complète."
  },
  {
    id: 'shop',
    label: 'Voir la Boutique Paty',
    icon: ShoppingBag,
    action: 'navigate',
    target: 'PatyShop',
    message: "Voici mes suggestions de fournitures pour ton projet !"
  }
];

const FAQ = [
  {
    question: "Comment surligner une couleur dans la grille ?",
    answer: "Dans le lecteur, appuie sur un symbole dans la légende : tous les points de cette couleur seront surlignés.",
    target: null
  },
  {
    question: "Comment activer les perles ?",
    answer: "Va dans Paramètres > Points & perles et active 'Emplacements de perles'. Tu peux aussi choisir le symbole des perles.",
    target: 'StitchSettings'
  },
  {
    question: "Comment suivre ma progression ?",
    answer: "Dans le lecteur, chaque point que tu marques 'terminé' met à jour ton pourcentage et le nombre de points restants.",
    target: 'Library'
  },
  {
    question: "Comment modifier mes couleurs DMC ?",
    answer: "Va dans Profil > Paramètres DMC pour gérer ta bibliothèque de fils.",
    target: 'DMCSettings'
  }
];

export default function PatyChat({ onClose }) {
  const [messages, setMessages] = useState([
    {
      role: 'paty',
      message: "Bonjour ! 🧵✨ Je suis Paty, ton assistante broderie. Pose-moi une question ou utilise les boutons ci-dessous pour que je t'aide !",
      timestamp: new Date().toISOString()
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [showFaq, setShowFaq] = useState(false);
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = () => {
    if (!inputText.trim()) return;

    const userMessage = {
      role: 'user',
      message: inputText,
      timestamp: new Date().toISOString()
    };

    setMessages([...messages, userMessage, {
      role: 'paty',
      message: "Je suis là pour t'aider ! Utilise les boutons rapides ci-dessous pour les actions courantes, ou explore la FAQ. Bientôt, je pourrai répondre à toutes tes questions en direct ! 💬",
      timestamp: new Date().toISOString()
    }]);

    setInputText('');
  };

  const handleQuickAction = (action) => {
    const patyMessage = {
      role: 'paty',
      message: action.message,
      timestamp: new Date().toISOString()
    };
    setMessages([...messages, patyMessage]);

    setTimeout(() => {
      window.location.href = createPageUrl(action.target);
    }, 1000);
  };

  const handleFaqClick = (faq) => {
    const userMessage = {
      role: 'user',
      message: faq.question,
      timestamp: new Date().toISOString()
    };
    const patyMessage = {
      role: 'paty',
      message: faq.answer,
      timestamp: new Date().toISOString()
    };

    setMessages([...messages, userMessage, patyMessage]);
    setShowFaq(false);

    if (faq.target) {
      setTimeout(() => {
        window.location.href = createPageUrl(faq.target);
      }, 2000);
    }
  };

  return (
    <Card className="w-full h-full flex flex-col shadow-2xl border-2 border-indigo-200">
      <CardHeader className="bg-[#FF5F6D] text-white flex-shrink-0">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div 
              className="w-10 h-10 bg-white rounded-full flex items-center justify-center"
              style={{ animation: 'pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite' }}
            >
              <span 
                className="text-black font-bold text-lg"
                style={{ 
                  animation: 'spin-step 4s steps(4) infinite',
                  display: 'inline-block'
                }}
              >
                +++
              </span>
            </div>
            <div>
              <CardTitle className="text-white text-xl">PATY IA</CardTitle>
              <p className="text-sm text-white/90">Ton assistante broderie</p>
            </div>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose} className="text-white hover:bg-white/20">
            <X className="h-5 w-5" />
          </Button>
        </div>
      </CardHeader>
      
      <style>{`
        @keyframes spin-step {
          0% { transform: rotate(0deg); }
          25% { transform: rotate(90deg); }
          50% { transform: rotate(180deg); }
          75% { transform: rotate(270deg); }
          100% { transform: rotate(360deg); }
        }
      `}</style>

      <CardContent className="flex-1 flex flex-col p-0 overflow-hidden">
        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((msg, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[80%] rounded-2xl px-4 py-2 ${
                  msg.role === 'user'
                    ? 'bg-indigo-600 text-white'
                    : 'bg-slate-100 text-slate-800'
                }`}
              >
                <p className="text-sm">{msg.message}</p>
              </div>
            </motion.div>
          ))}
          <div ref={messagesEndRef} />
        </div>

        {/* Quick Actions */}
        <div className="border-t bg-slate-50 p-4 space-y-3">
          <p className="text-xs font-semibold text-slate-600 uppercase">Actions rapides</p>
          <div className="grid grid-cols-2 gap-2">
            {QUICK_ACTIONS.slice(0, 4).map((action) => {
              const Icon = action.icon;
              return (
                <Button
                  key={action.id}
                  variant="outline"
                  size="sm"
                  onClick={() => handleQuickAction(action)}
                  className="flex items-center gap-2 text-xs h-auto py-2"
                >
                  <Icon className="h-3 w-3" />
                  <span className="text-left">{action.label}</span>
                </Button>
              );
            })}
          </div>

          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowFaq(!showFaq)}
            className="w-full"
          >
            {showFaq ? 'Masquer' : 'Voir'} les questions fréquentes
          </Button>

          {showFaq && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              className="space-y-2"
            >
              {FAQ.map((faq, index) => (
                <Button
                  key={index}
                  variant="ghost"
                  size="sm"
                  onClick={() => handleFaqClick(faq)}
                  className="w-full text-left text-xs justify-start h-auto py-2"
                >
                  {faq.question}
                </Button>
              ))}
            </motion.div>
          )}
        </div>

        {/* Input */}
        <div className="border-t p-4 bg-white">
          <div className="flex gap-2">
            <Input
              placeholder="Pose-moi une question..."
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
            />
            <Button onClick={handleSendMessage} className="bg-[#FF5F6D] hover:bg-[#FF7A85]">
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}