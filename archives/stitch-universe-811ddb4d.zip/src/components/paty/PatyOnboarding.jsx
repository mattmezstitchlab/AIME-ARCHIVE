import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Sparkles, ArrowRight, ArrowLeft, Check } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { createPageUrl } from '../../utils';
import { base44 } from '@/api/base44Client';

const STEPS = [
  {
    id: 'project_type',
    question: "Bonjour, je suis Paty 🧵✨ Que veux-tu faire aujourd'hui ?",
    options: [
      { value: 'create', label: 'Créer une nouvelle grille à partir d\'une photo', target: 'Creator' },
      { value: 'import', label: 'Importer une grille existante (PDF / image)', target: 'Library' },
      { value: 'explore', label: 'Juste explorer l\'application', target: 'Home' }
    ]
  },
  {
    id: 'skill_level',
    question: "Tu te considères plutôt… ?",
    options: [
      { value: 'beginner', label: 'Débutant(e)' },
      { value: 'intermediate', label: 'Intermédiaire' },
      { value: 'expert', label: 'Expert(e)' }
    ]
  },
  {
    id: 'project_size',
    question: "Tu veux un projet plutôt :",
    options: [
      { value: 'small', label: 'Petit & rapide', description: '50×50 points, 10-15 couleurs' },
      { value: 'medium', label: 'Moyen', description: '100×100 points, 20-25 couleurs' },
      { value: 'large', label: 'Grand & détaillé', description: '150×150+ points, 30+ couleurs' }
    ]
  },
  {
    id: 'stitch_types',
    question: "Quels types de points tu veux utiliser ?",
    type: 'checkbox',
    options: [
      { value: 'full_cross_enabled', label: 'Point de croix simple' },
      { value: 'half_stitch_enabled', label: 'Demi-points' },
      { value: 'special_stitches_enabled', label: 'Points spéciaux' },
      { value: 'beads_enabled', label: 'Perles' }
    ]
  },
  {
    id: 'supplies',
    question: "Tu veux que je prépare aussi une liste de fournitures adaptée à ton projet ?",
    options: [
      { value: true, label: 'Oui, prépare-moi une liste' },
      { value: false, label: 'Non merci' }
    ]
  }
];

export default function PatyOnboarding({ onComplete }) {
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState({
    project_type: null,
    skill_level: null,
    project_size: null,
    stitch_types: {
      full_cross_enabled: true,
      half_stitch_enabled: false,
      special_stitches_enabled: false,
      beads_enabled: false
    },
    supplies: false
  });

  const currentStepData = STEPS[currentStep];
  const isLastStep = currentStep === STEPS.length - 1;

  const handleAnswer = (stepId, value) => {
    if (currentStepData.type === 'checkbox') {
      setAnswers({
        ...answers,
        [stepId]: {
          ...answers[stepId],
          [value]: !answers[stepId][value]
        }
      });
    } else {
      setAnswers({
        ...answers,
        [stepId]: value
      });
    }
  };

  const handleNext = () => {
    if (answers.project_type === 'explore' && currentStep === 0) {
      handleFinish();
      return;
    }
    
    if (currentStep < STEPS.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      handleFinish();
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleFinish = async () => {
    try {
      const isAuth = await base44.auth.isAuthenticated();
      
      // Save Paty settings
      if (isAuth) {
        try {
          const existing = await base44.entities.PatySettings.list();
          if (existing.length > 0) {
            await base44.entities.PatySettings.update(existing[0].id, {
              has_completed_onboarding: true,
              project_type: answers.project_type,
              skill_level: answers.skill_level,
              project_size: answers.project_size,
              wants_supplies_list: answers.supplies
            });
          } else {
            await base44.entities.PatySettings.create({
              has_completed_onboarding: true,
              project_type: answers.project_type,
              skill_level: answers.skill_level,
              project_size: answers.project_size,
              wants_supplies_list: answers.supplies
            });
          }
        } catch (error) {
          console.error('Erreur sauvegarde Paty settings:', error);
        }
      } else {
        localStorage.setItem('paticroix_paty_settings', JSON.stringify(answers));
      }

      // Save stitch settings
      const stitchSettings = answers.stitch_types;
      if (isAuth) {
        try {
          const existing = await base44.entities.StitchSettings.list();
          if (existing.length > 0) {
            await base44.entities.StitchSettings.update(existing[0].id, stitchSettings);
          } else {
            await base44.entities.StitchSettings.create(stitchSettings);
          }
        } catch (error) {
          console.error('Erreur sauvegarde stitch settings:', error);
        }
      } else {
        localStorage.setItem('paticroix_stitch_settings', JSON.stringify(stitchSettings));
      }

      // Navigate based on project type
      const projectOption = STEPS[0].options.find(o => o.value === answers.project_type);
      if (projectOption) {
        window.location.href = createPageUrl(projectOption.target);
      } else if (onComplete) {
        onComplete(answers);
      }
    } catch (error) {
      console.error('Erreur finalisation onboarding:', error);
    }
  };

  const getSummary = () => {
    const projectType = STEPS[0].options.find(o => o.value === answers.project_type)?.label;
    const skillLevel = STEPS[1].options.find(o => o.value === answers.skill_level)?.label;
    const projectSize = STEPS[2].options.find(o => o.value === answers.project_size)?.label;
    const stitchTypes = Object.entries(answers.stitch_types)
      .filter(([_, enabled]) => enabled)
      .map(([key]) => STEPS[3].options.find(o => o.value === key)?.label)
      .filter(Boolean);

    return (
      <div className="space-y-3 text-left">
        <p><strong>Projet :</strong> {projectType}</p>
        <p><strong>Niveau :</strong> {skillLevel}</p>
        <p><strong>Taille :</strong> {projectSize}</p>
        <p><strong>Points :</strong> {stitchTypes.join(', ')}</p>
        <p><strong>Fournitures :</strong> {answers.supplies ? 'Oui' : 'Non'}</p>
      </div>
    );
  };

  const canProceed = () => {
    if (currentStepData.type === 'checkbox') {
      return Object.values(answers[currentStepData.id] || {}).some(v => v);
    }
    return answers[currentStepData.id] !== null;
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-indigo-50 via-white to-pink-50">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-2xl"
      >
        <Card className="shadow-2xl border-2 border-indigo-200">
          <CardContent className="p-8">
            {/* Paty Avatar */}
            <div className="flex justify-center mb-6">
              <div className="w-20 h-20 rounded-full bg-gradient-to-br from-indigo-600 to-pink-600 flex items-center justify-center shadow-lg">
                <Sparkles className="h-10 w-10 text-white" />
              </div>
            </div>

            {/* Progress */}
            <div className="flex items-center justify-center gap-2 mb-8">
              {STEPS.map((_, index) => (
                <div
                  key={index}
                  className={`h-2 rounded-full transition-all ${
                    index === currentStep
                      ? 'w-8 bg-indigo-600'
                      : index < currentStep
                      ? 'w-2 bg-green-500'
                      : 'w-2 bg-slate-300'
                  }`}
                />
              ))}
            </div>

            <AnimatePresence mode="wait">
              {!isLastStep || !canProceed() ? (
                <motion.div
                  key={currentStep}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-6"
                >
                  {/* Question */}
                  <h2 className="text-2xl font-bold text-center text-slate-800 mb-8">
                    {currentStepData.question}
                  </h2>

                  {/* Options */}
                  <div className="space-y-3">
                    {currentStepData.options.map((option) => (
                      <Button
                        key={option.value}
                        variant={
                          currentStepData.type === 'checkbox'
                            ? answers[currentStepData.id]?.[option.value]
                              ? 'default'
                              : 'outline'
                            : answers[currentStepData.id] === option.value
                            ? 'default'
                            : 'outline'
                        }
                        onClick={() => handleAnswer(currentStepData.id, option.value)}
                        className={`w-full h-auto py-4 px-6 text-left justify-start ${
                          currentStepData.type === 'checkbox'
                            ? answers[currentStepData.id]?.[option.value]
                              ? 'bg-indigo-600 hover:bg-indigo-700'
                              : ''
                            : answers[currentStepData.id] === option.value
                            ? 'bg-indigo-600 hover:bg-indigo-700'
                            : ''
                        }`}
                      >
                        <div className="flex-1">
                          <div className="font-medium">{option.label}</div>
                          {option.description && (
                            <div className="text-xs opacity-80 mt-1">{option.description}</div>
                          )}
                        </div>
                        {currentStepData.type === 'checkbox' && answers[currentStepData.id]?.[option.value] && (
                          <Check className="h-5 w-5 ml-2" />
                        )}
                      </Button>
                    ))}
                  </div>
                </motion.div>
              ) : (
                <motion.div
                  key="summary"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="space-y-6"
                >
                  <h2 className="text-2xl font-bold text-center text-slate-800">
                    Récapitulatif de ton projet
                  </h2>
                  <div className="bg-slate-50 rounded-xl p-6">
                    {getSummary()}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Navigation */}
            <div className="flex gap-3 mt-8">
              {currentStep > 0 && (
                <Button
                  variant="outline"
                  onClick={handleBack}
                  className="flex-1"
                >
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Retour
                </Button>
              )}
              <Button
                onClick={handleNext}
                disabled={!canProceed()}
                className="flex-1 bg-gradient-to-r from-indigo-600 to-pink-600 hover:from-indigo-700 hover:to-pink-700"
              >
                {isLastStep && canProceed() ? 'OK Paty, on y va !' : 'Suivant'}
                <ArrowRight className="h-4 w-4 ml-2" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}