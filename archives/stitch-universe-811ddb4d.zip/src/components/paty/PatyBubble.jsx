import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import PatyChat from './PatyChat';

export default function PatyBubble({ isOpen, onClose }) {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, x: 100 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: 100 }}
          className="fixed bottom-0 right-0 top-0 w-full md:w-96 z-50 bg-white shadow-2xl"
        >
          <PatyChat onClose={onClose} />
        </motion.div>
      )}
    </AnimatePresence>
  );
}