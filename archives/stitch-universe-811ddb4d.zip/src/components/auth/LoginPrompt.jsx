import React from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { LogIn, UserPlus } from 'lucide-react';
import { motion } from 'framer-motion';

export default function LoginPrompt({ message = "Connecte-toi pour accéder à toutes les fonctionnalités" }) {
  const handleLogin = () => {
    base44.auth.redirectToLogin(window.location.pathname);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex items-center justify-center min-h-[60vh]"
    >
      <Card className="max-w-md w-full">
        <CardHeader>
          <CardTitle className="text-center text-2xl">
            Connexion requise
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-center text-slate-600">
            {message}
          </p>
          
          <div className="space-y-3">
            <Button
              onClick={handleLogin}
              className="w-full bg-gradient-to-r from-indigo-600 to-pink-600 hover:from-indigo-700 hover:to-pink-700 h-12"
            >
              <LogIn className="h-5 w-5 mr-2" />
              Se connecter
            </Button>
            
            <p className="text-center text-sm text-slate-500">
              Nouveau sur PATICROIX ? La connexion créera automatiquement ton compte.
            </p>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}