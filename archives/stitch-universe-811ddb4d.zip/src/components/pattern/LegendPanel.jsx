import React, { useState, useEffect } from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { CheckCircle2, Sparkles } from 'lucide-react';
import { motion } from 'framer-motion';
import { getDMCLibrary } from '../../components/utils/dmcHelper';
import { getStitchSettings, isBead } from '../utils/stitchHelper';

export default function LegendPanel({ 
  pattern, 
  progress, 
  darkMode, 
  selectedSymbol, 
  onSymbolSelect 
}) {
  const completedStitches = progress?.stitches_completed || [];
  const [dmcLibrary, setDmcLibrary] = useState([]);
  const [stitchSettings, setStitchSettings] = useState(null);

  useEffect(() => {
    loadDMCLibrary();
    loadStitchSettings();
  }, []);

  const loadDMCLibrary = async () => {
    const library = await getDMCLibrary();
    setDmcLibrary(library);
  };

  const loadStitchSettings = async () => {
    const settings = await getStitchSettings();
    setStitchSettings(settings);
  };

  const getDMCName = (dmcCode) => {
    const found = dmcLibrary.find(c => c.code === dmcCode);
    return found ? found.name : '';
  };

  const isBeadSymbol = (symbol) => {
    return stitchSettings?.beads_enabled && symbol === stitchSettings?.bead_symbol;
  };

  const getLegendStats = (symbol) => {
    const completed = completedStitches.filter(s => s.symbol === symbol).length;
    const total = pattern.legend.find(l => l.symbol === symbol)?.total_stitches || 0;
    return { completed, total, remaining: total - completed };
  };

  return (
    <div className="p-4">
      <h3 className={`text-lg font-semibold mb-4 ${darkMode ? 'text-white' : 'text-slate-800'}`}>
        Légende des fils
      </h3>
      
      <div className="space-y-2">
        {pattern.legend?.map((item, index) => {
          const stats = getLegendStats(item.symbol);
          const isSelected = selectedSymbol === item.symbol;
          const percentage = stats.total > 0 ? (stats.completed / stats.total) * 100 : 0;

          return (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.03 }}
            >
              <Button
                variant={isSelected ? "default" : "outline"}
                className={`w-full justify-start p-4 h-auto ${
                  isSelected ? 'bg-indigo-600 hover:bg-indigo-700' : ''
                } ${darkMode && !isSelected ? 'border-slate-700 text-slate-300' : ''}`}
                onClick={() => onSymbolSelect(isSelected ? null : item.symbol)}
              >
                <div className="flex items-center gap-3 w-full">
                  {isBeadSymbol(item.symbol) ? (
                    <div
                      className="w-8 h-8 rounded-lg flex items-center justify-center shadow-md flex-shrink-0 border-2"
                      style={{ 
                        backgroundColor: stitchSettings?.bead_color || '#FFD700',
                        borderColor: darkMode ? '#64748b' : '#cbd5e1'
                      }}
                    >
                      <Sparkles className="h-4 w-4 text-white" />
                    </div>
                  ) : (
                    <div
                      className="w-8 h-8 rounded-lg flex items-center justify-center text-white font-bold shadow-md flex-shrink-0"
                      style={{ backgroundColor: item.color_hex || '#94a3b8' }}
                    >
                      {item.symbol}
                    </div>
                  )}
                  
                  <div className="flex-1 text-left">
                    <div className="flex items-center justify-between mb-1">
                      <div>
                        {isBeadSymbol(item.symbol) ? (
                          <>
                            <span className="font-semibold text-sm">Perle</span>
                            <span className={`text-xs ml-2 ${darkMode && !isSelected ? 'text-slate-500' : 'text-slate-500'}`}>
                              {item.dmc_code}
                            </span>
                          </>
                        ) : (
                          <>
                            <span className="font-mono text-sm font-semibold">
                              {item.dmc_code}
                            </span>
                            {getDMCName(item.dmc_code) && (
                              <span className={`text-xs ml-2 ${darkMode && !isSelected ? 'text-slate-500' : 'text-slate-500'}`}>
                                {getDMCName(item.dmc_code)}
                              </span>
                            )}
                          </>
                        )}
                      </div>
                      {percentage === 100 && (
                        <CheckCircle2 className="h-4 w-4 text-green-500" />
                      )}
                    </div>
                    
                    <div className="flex items-center gap-2 text-xs">
                      <span className={darkMode && !isSelected ? 'text-slate-400' : 'text-slate-600'}>
                        {stats.completed}/{stats.total}
                      </span>
                      <div className="flex-1 h-1.5 bg-slate-200 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-green-500 transition-all duration-300"
                          style={{ width: `${percentage}%` }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </Button>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}