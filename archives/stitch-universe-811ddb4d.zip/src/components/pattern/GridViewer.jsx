import React, { useRef, useEffect, useState } from 'react';
import { motion } from 'framer-motion';

export default function GridViewer({ 
  pattern, 
  progress, 
  zoom, 
  darkMode, 
  selectedSymbol,
  highlightMode,
  onStitchToggle 
}) {
  const canvasRef = useRef(null);
  const containerRef = useRef(null);
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });

  const gridData = pattern.grid_data ? JSON.parse(pattern.grid_data) : [];
  const completedStitches = progress?.stitches_completed || [];

  useEffect(() => {
    drawGrid();
  }, [pattern, progress, zoom, darkMode, selectedSymbol, highlightMode]);

  const drawGrid = () => {
    const canvas = canvasRef.current;
    if (!canvas || !pattern.legend) return;

    const ctx = canvas.getContext('2d');
    const cellSize = 20 * zoom;
    const width = (pattern.grid_width || 100) * cellSize;
    const height = (pattern.grid_height || 100) * cellSize;

    canvas.width = width;
    canvas.height = height;

    // Background
    ctx.fillStyle = darkMode ? '#1e293b' : '#ffffff';
    ctx.fillRect(0, 0, width, height);

    // Draw grid and stitches
    for (let y = 0; y < (pattern.grid_height || 100); y++) {
      for (let x = 0; x < (pattern.grid_width || 100); x++) {
        const symbol = gridData[y]?.[x] || '';
        const isCompleted = completedStitches.some(s => s.x === x && s.y === y);
        const isHighlighted = highlightMode && selectedSymbol && symbol === selectedSymbol;

        // Cell background
        if (isHighlighted) {
          ctx.fillStyle = darkMode ? '#4f46e5' : '#e0e7ff';
          ctx.fillRect(x * cellSize, y * cellSize, cellSize, cellSize);
        }

        // Completed stitch
        if (isCompleted) {
          const legendItem = pattern.legend.find(l => l.symbol === symbol);
          ctx.fillStyle = legendItem?.color_hex || '#10b981';
          ctx.fillRect(x * cellSize + 2, y * cellSize + 2, cellSize - 4, cellSize - 4);
        }

        // Grid lines
        ctx.strokeStyle = darkMode ? '#374151' : '#e5e7eb';
        ctx.lineWidth = (x % 10 === 0 || y % 10 === 0) ? 2 : 0.5;
        ctx.strokeRect(x * cellSize, y * cellSize, cellSize, cellSize);

        // Symbol
        if (symbol && !isCompleted && cellSize > 10) {
          ctx.fillStyle = darkMode ? '#cbd5e1' : '#475569';
          ctx.font = `${Math.max(8, cellSize * 0.6)}px monospace`;
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(symbol, x * cellSize + cellSize / 2, y * cellSize + cellSize / 2);
        }
      }
    }
  };

  const handleCanvasClick = (e) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = Math.floor((e.clientX - rect.left) / (20 * zoom));
    const y = Math.floor((e.clientY - rect.top) / (20 * zoom));

    if (x >= 0 && x < pattern.grid_width && y >= 0 && y < pattern.grid_height) {
      const symbol = gridData[y]?.[x];
      if (symbol) {
        onStitchToggle(x, y, symbol);
      }
    }
  };

  return (
    <div 
      ref={containerRef}
      className="w-full h-full overflow-auto rounded-xl shadow-lg"
      style={{ cursor: isDragging ? 'grabbing' : 'grab' }}
    >
      <canvas
        ref={canvasRef}
        onClick={handleCanvasClick}
        className="mx-auto"
      />
    </div>
  );
}