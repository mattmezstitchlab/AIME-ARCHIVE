import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { TrendingUp, Target, Clock, Sparkles } from 'lucide-react';
import { getStitchSettings } from '../utils/stitchHelper';

export default function StatsBar({ pattern, progress, darkMode }) {
  const [stitchSettings, setStitchSettings] = useState(null);

  useEffect(() => {
    loadStitchSettings();
  }, []);

  const loadStitchSettings = async () => {
    const settings = await getStitchSettings();
    setStitchSettings(settings);
  };

  const beadCount = pattern.legend?.filter(l => l.symbol === stitchSettings?.bead_symbol).reduce((sum, l) => sum + l.total_stitches, 0) || 0;
  const completedBeads = progress?.stitches_completed?.filter(s => s.symbol === stitchSettings?.bead_symbol).length || 0;

  const stats = [
    {
      label: "Aujourd'hui",
      value: progress?.stitches_today || 0,
      icon: TrendingUp,
      color: 'text-green-600'
    },
    {
      label: 'Total',
      value: `${pattern.completed_stitches || 0}/${pattern.total_stitches || 0}`,
      icon: Target,
      color: 'text-indigo-600'
    },
    {
      label: 'Restants',
      value: (pattern.total_stitches || 0) - (pattern.completed_stitches || 0),
      icon: Clock,
      color: 'text-pink-600'
    }
  ];

  return (
    <div className="p-4 border-b border-slate-200">
      <h3 className={`text-sm font-semibold mb-3 ${darkMode ? 'text-white' : 'text-slate-800'}`}>
        Progression
      </h3>
      
      <div className="space-y-3">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Icon className={`h-4 w-4 ${stat.color}`} />
                <span className={`text-sm ${darkMode ? 'text-slate-300' : 'text-slate-600'}`}>
                  {stat.label}
                </span>
              </div>
              <span className={`font-semibold ${darkMode ? 'text-white' : 'text-slate-800'}`}>
                {stat.value}
              </span>
            </div>
          );
        })}
      </div>

      {stitchSettings?.beads_enabled && stitchSettings?.show_bead_counter && beadCount > 0 && (
        <div className="pt-3 border-t border-slate-200 mt-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-amber-600" />
              <span className={`text-sm ${darkMode ? 'text-slate-300' : 'text-slate-600'}`}>
                Perles
              </span>
            </div>
            <span className={`font-semibold ${darkMode ? 'text-white' : 'text-slate-800'}`}>
              {completedBeads}/{beadCount}
            </span>
          </div>
        </div>
      )}

      <div className="mt-4">
        <div className="flex justify-between text-sm mb-2">
          <span className={darkMode ? 'text-slate-300' : 'text-slate-600'}>
            Avancement
          </span>
          <span className={`font-semibold ${darkMode ? 'text-white' : 'text-slate-800'}`}>
            {Math.round(pattern.completion_percentage || 0)}%
          </span>
        </div>
        <div className="w-full h-3 bg-slate-200 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-indigo-500 to-pink-500 transition-all duration-500"
            style={{ width: `${pattern.completion_percentage || 0}%` }}
          />
        </div>
      </div>
    </div>
  );
}