import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Play, Edit, Copy, FileDown, Trash2, Save, X, Tag, Calendar, User, Clock, Grid3x3, Palette } from 'lucide-react';
import { base44 } from '@/api/base44Client';

export default function PatternDetailModal({ pattern, isOpen, onClose, onUpdate, onDelete, onOpen }) {
  const [isEditing, setIsEditing] = useState(false);
  const [editedPattern, setEditedPattern] = useState(pattern);

  const handleSave = async () => {
    try {
      await base44.entities.Pattern.update(pattern.id, {
        name: editedPattern.name,
        description: editedPattern.description,
        tags: editedPattern.tags
      });
      onUpdate();
      setIsEditing(false);
    } catch (error) {
      console.error('Erreur sauvegarde:', error);
    }
  };

  const handleDuplicate = async () => {
    try {
      await base44.entities.Pattern.create({
        ...pattern,
        name: `${pattern.name} (copie)`,
        id: undefined,
        created_date: undefined,
        completion_percentage: 0,
        completed_stitches: 0,
        is_completed: false
      });
      onUpdate();
      onClose();
    } catch (error) {
      console.error('Erreur duplication:', error);
    }
  };

  const handleDelete = async () => {
    if (confirm('Êtes-vous sûr de vouloir supprimer cette grille ?')) {
      await onDelete(pattern.id);
      onClose();
    }
  };

  if (!pattern) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Détails de la grille</DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="info" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="info">Informations</TabsTrigger>
            <TabsTrigger value="preview">Aperçu</TabsTrigger>
            <TabsTrigger value="colors">Couleurs DMC</TabsTrigger>
          </TabsList>

          <TabsContent value="info" className="space-y-6 mt-6">
            {/* Name */}
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Nom de la grille</label>
              {isEditing ? (
                <Input
                  value={editedPattern.name}
                  onChange={(e) => setEditedPattern({ ...editedPattern, name: e.target.value })}
                />
              ) : (
                <p className="text-lg font-semibold text-slate-800">{pattern.name}</p>
              )}
            </div>

            {/* Description */}
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Description</label>
              {isEditing ? (
                <Textarea
                  value={editedPattern.description || ''}
                  onChange={(e) => setEditedPattern({ ...editedPattern, description: e.target.value })}
                  placeholder="Ajouter une description..."
                />
              ) : (
                <p className="text-slate-600">{pattern.description || 'Aucune description'}</p>
              )}
            </div>

            {/* Progress */}
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium text-slate-700">Progression</span>
                <span className="text-sm font-semibold text-slate-800">
                  {Math.round(pattern.completion_percentage || 0)}%
                </span>
              </div>
              <div className="w-full bg-slate-200 rounded-full h-3 overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-fuchsia-500 to-purple-500"
                  style={{ width: `${pattern.completion_percentage || 0}%` }}
                />
              </div>
              <p className="text-xs text-slate-600 mt-2">
                {pattern.completed_stitches || 0} / {pattern.total_stitches || 0} points
              </p>
            </div>

            {/* Stats Grid */}
            <div className="grid md:grid-cols-2 gap-4">
              <div className="flex items-start gap-3 p-3 bg-slate-50 rounded-lg">
                <Grid3x3 className="h-5 w-5 text-fuchsia-600 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-slate-700">Taille</p>
                  <p className="text-lg font-semibold text-slate-800">
                    {pattern.grid_width}×{pattern.grid_height}
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3 bg-slate-50 rounded-lg">
                <Palette className="h-5 w-5 text-fuchsia-600 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-slate-700">Couleurs</p>
                  <p className="text-lg font-semibold text-slate-800">{pattern.color_count || 0}</p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3 bg-slate-50 rounded-lg">
                <Clock className="h-5 w-5 text-fuchsia-600 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-slate-700">Durée estimée</p>
                  <p className="text-lg font-semibold text-slate-800">
                    {pattern.estimated_hours ? `${Math.round(pattern.estimated_hours)}h` : 'Non calculé'}
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3 bg-slate-50 rounded-lg">
                <User className="h-5 w-5 text-fuchsia-600 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-slate-700">Créé par</p>
                  <p className="text-lg font-semibold text-slate-800">
                    {pattern.created_by_paty ? 'Paty' : pattern.source_type === 'generated' ? 'Moi' : 'Importé'}
                  </p>
                </div>
              </div>
            </div>

            {/* Tags */}
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Tags</label>
              <div className="flex flex-wrap gap-2">
                {pattern.tags && pattern.tags.length > 0 ? (
                  pattern.tags.map((tag, idx) => (
                    <Badge key={idx} variant="outline">
                      <Tag className="h-3 w-3 mr-1" />
                      {tag}
                    </Badge>
                  ))
                ) : (
                  <p className="text-sm text-slate-500">Aucun tag</p>
                )}
              </div>
            </div>

            {/* Metadata */}
            <div className="pt-4 border-t flex items-center gap-4 text-sm text-slate-600">
              <div className="flex items-center gap-1">
                <Calendar className="h-4 w-4" />
                Créé le {new Date(pattern.created_date).toLocaleDateString('fr-FR')}
              </div>
              {pattern.last_opened && (
                <div className="flex items-center gap-1">
                  <Clock className="h-4 w-4" />
                  Ouvert le {new Date(pattern.last_opened).toLocaleDateString('fr-FR')}
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="preview" className="mt-6">
            <div className="flex justify-center">
              {pattern.file_url ? (
                <img
                  src={pattern.file_url}
                  alt={pattern.name}
                  className="max-h-[500px] rounded-lg shadow-lg"
                />
              ) : (
                <div className="w-full h-64 bg-slate-100 rounded-lg flex items-center justify-center">
                  <p className="text-slate-500">Aucun aperçu disponible</p>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="colors" className="mt-6">
            {pattern.legend && pattern.legend.length > 0 ? (
              <div className="grid md:grid-cols-2 gap-3 max-h-96 overflow-y-auto">
                {pattern.legend.map((item, index) => (
                  <div
                    key={index}
                    className="flex items-center gap-3 p-3 rounded-lg bg-slate-50 hover:bg-slate-100 transition-colors"
                  >
                    <div
                      className="w-10 h-10 rounded-lg flex items-center justify-center text-white font-bold shadow-md"
                      style={{ backgroundColor: item.color_hex }}
                    >
                      {item.symbol}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-semibold">{item.dmc_code}</span>
                        <span className="text-sm text-slate-600">{item.dmc_name}</span>
                      </div>
                      <p className="text-xs text-slate-500">{item.total_stitches || 0} points</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <Palette className="h-16 w-16 text-slate-300 mx-auto mb-4" />
                <p className="text-slate-500">Aucune légende disponible</p>
              </div>
            )}
          </TabsContent>
        </Tabs>

        {/* Actions */}
        <div className="flex items-center justify-between pt-6 border-t">
          {isEditing ? (
            <div className="flex gap-2">
              <Button onClick={handleSave} className="bg-green-600 hover:bg-green-700">
                <Save className="h-4 w-4 mr-2" />
                Sauvegarder
              </Button>
              <Button variant="outline" onClick={() => setIsEditing(false)}>
                <X className="h-4 w-4 mr-2" />
                Annuler
              </Button>
            </div>
          ) : (
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setIsEditing(true)}>
                <Edit className="h-4 w-4 mr-2" />
                Modifier
              </Button>
              <Button variant="outline" onClick={handleDuplicate}>
                <Copy className="h-4 w-4 mr-2" />
                Dupliquer
              </Button>
              <Button variant="outline" onClick={() => alert('Export non implémenté')}>
                <FileDown className="h-4 w-4 mr-2" />
                Exporter
              </Button>
              <Button variant="destructive" onClick={handleDelete}>
                <Trash2 className="h-4 w-4 mr-2" />
                Supprimer
              </Button>
            </div>
          )}
          <Button
            onClick={() => {
              onClose();
              onOpen(pattern);
            }}
            className="bg-gradient-to-r from-fuchsia-600 to-purple-600"
          >
            <Play className="h-4 w-4 mr-2" />
            Ouvrir dans le lecteur
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}