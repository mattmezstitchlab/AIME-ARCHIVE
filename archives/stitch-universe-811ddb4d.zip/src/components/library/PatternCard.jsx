import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Clock, CheckCircle, Tag, MoreVertical } from 'lucide-react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';

export default function PatternCard({ pattern, onOpen, onShowDetails }) {
  const getDifficultyColor = (difficulty) => {
    const colors = {
      easy: 'bg-green-100 text-green-700',
      medium: 'bg-yellow-100 text-yellow-700',
      hard: 'bg-orange-100 text-orange-700',
      expert: 'bg-red-100 text-red-700'
    };
    return colors[difficulty] || 'bg-slate-100 text-slate-700';
  };

  const getDifficultyLabel = (difficulty) => {
    const labels = {
      easy: 'Facile',
      medium: 'Moyen',
      hard: 'Difficile',
      expert: 'Expert'
    };
    return labels[difficulty] || 'Non défini';
  };

  return (
    <Card className="hover:shadow-xl transition-all duration-300 group overflow-hidden">
      <div className="relative">
        {/* Thumbnail */}
        <div className="w-full h-48 bg-gradient-to-br from-slate-100 to-slate-200 flex items-center justify-center relative overflow-hidden">
          {pattern.file_url && (
            <img
              src={pattern.file_url}
              alt={pattern.name}
              className="w-full h-full object-cover"
            />
          )}
          <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors" />
        </div>

        {/* Status badges */}
        <div className="absolute top-3 left-3 flex gap-2">
          {pattern.is_completed && (
            <Badge className="bg-green-600">
              <CheckCircle className="h-3 w-3 mr-1" />
              Terminé
            </Badge>
          )}
          {pattern.difficulty && (
            <Badge className={getDifficultyColor(pattern.difficulty)}>
              {getDifficultyLabel(pattern.difficulty)}
            </Badge>
          )}
        </div>

        {/* More options */}
        <Button
          variant="ghost"
          size="icon"
          className="absolute top-3 right-3 bg-white/80 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity"
          onClick={(e) => {
            e.stopPropagation();
            onShowDetails(pattern);
          }}
        >
          <MoreVertical className="h-4 w-4" />
        </Button>
      </div>

      <CardContent className="p-4">
        <h3 className="text-lg font-semibold text-slate-800 mb-2 line-clamp-2">
          {pattern.name}
        </h3>

        {/* Tags */}
        {pattern.tags && pattern.tags.length > 0 && (
          <div className="flex flex-wrap gap-1 mb-3">
            {pattern.tags.slice(0, 2).map((tag, idx) => (
              <Badge key={idx} variant="outline" className="text-xs">
                <Tag className="h-3 w-3 mr-1" />
                {tag}
              </Badge>
            ))}
            {pattern.tags.length > 2 && (
              <Badge variant="outline" className="text-xs">
                +{pattern.tags.length - 2}
              </Badge>
            )}
          </div>
        )}

        {/* Progress */}
        <div className="mb-4">
          <div className="flex justify-between text-sm text-slate-600 mb-2">
            <span>Progression</span>
            <span className="font-semibold">{Math.round(pattern.completion_percentage || 0)}%</span>
          </div>
          <div className="w-full bg-slate-200 rounded-full h-2 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-fuchsia-500 to-purple-500 transition-all duration-500"
              style={{ width: `${pattern.completion_percentage || 0}%` }}
            />
          </div>
        </div>

        {/* Info */}
        <div className="flex items-center justify-between text-xs text-slate-600 mb-3">
          <span>{pattern.grid_width}×{pattern.grid_height}</span>
          <span>{pattern.color_count || 0} couleurs</span>
          {pattern.estimated_hours && (
            <span className="flex items-center gap-1">
              <Clock className="h-3 w-3" />
              {Math.round(pattern.estimated_hours)}h
            </span>
          )}
        </div>

        <Button
          onClick={() => onOpen(pattern)}
          className="w-full bg-gradient-to-r from-fuchsia-600 to-purple-600 hover:from-fuchsia-700 hover:to-purple-700"
        >
          Ouvrir
        </Button>
      </CardContent>
    </Card>
  );
}