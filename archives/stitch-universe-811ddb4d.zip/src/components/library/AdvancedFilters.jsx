import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { X, Filter, RotateCcw, Calendar as CalendarIcon } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const THEMES = [
  'Portrait', 'Animal', 'Nature', 'Fleur', 'Paysage', 'Dessin enfant',
  'Fantaisie', 'Religion / spirituel', 'Noël', 'Mariage', 'Bébé',
  'Géométrique', 'Pixel art', 'Abstrait'
];

const STITCH_TYPES = [
  { value: 'simple', label: 'Point de croix simple' },
  { value: 'half', label: 'Demi-points' },
  { value: 'special', label: 'Points spéciaux' },
  { value: 'beads', label: 'Perles' },
  { value: 'backstitch', label: 'Points arrière' },
  { value: 'full', label: 'Broderie complète' },
  { value: 'hybrid', label: 'Créations hybrides' }
];

const SIZE_PRESETS = [
  { value: 'small', label: 'Petit (< 80×80)', min: 0, max: 80 },
  { value: 'medium', label: 'Moyen (80-150)', min: 80, max: 150 },
  { value: 'large', label: 'Grand (150-250)', min: 150, max: 250 },
  { value: 'xlarge', label: 'Très grand (250+)', min: 250, max: 10000 }
];

const COLOR_RANGES = [
  { value: '1-5', label: '1-5 couleurs', min: 1, max: 5 },
  { value: '6-20', label: '6-20 couleurs', min: 6, max: 20 },
  { value: '21-40', label: '21-40 couleurs', min: 21, max: 40 },
  { value: '40+', label: '40+ couleurs', min: 40, max: 10000 }
];

const TIME_RANGES = [
  { value: '<5', label: '< 5 heures', max: 5 },
  { value: '5-20', label: '5-20 heures', min: 5, max: 20 },
  { value: '20-50', label: '20-50 heures', min: 20, max: 50 },
  { value: '50+', label: '50+ heures', min: 50 }
];

export default function AdvancedFilters({ isOpen, onClose, filters, onFiltersChange, onApply, onReset }) {
  const [localFilters, setLocalFilters] = useState(filters);

  const updateFilter = (key, value) => {
    setLocalFilters(prev => ({ ...prev, [key]: value }));
  };

  const toggleTheme = (theme) => {
    const current = localFilters.themes || [];
    const updated = current.includes(theme)
      ? current.filter(t => t !== theme)
      : [...current, theme];
    updateFilter('themes', updated);
  };

  const toggleStitchType = (type) => {
    const current = localFilters.stitchTypes || [];
    const updated = current.includes(type)
      ? current.filter(t => t !== type)
      : [...current, type];
    updateFilter('stitchTypes', updated);
  };

  const handleApply = () => {
    onFiltersChange(localFilters);
    onApply();
    onClose();
  };

  const handleReset = () => {
    const emptyFilters = {
      themes: [],
      dateFilter: 'all',
      creators: [],
      sizePreset: 'all',
      stitchTypes: [],
      colorRange: 'all',
      beadsFilter: 'all',
      status: [],
      patyMode: 'all',
      tags: '',
      timeRange: 'all',
      difficulty: 'all'
    };
    setLocalFilters(emptyFilters);
    onReset();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 z-40"
            onClick={onClose}
          />

          {/* Filter Panel */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed right-0 top-0 bottom-0 w-full md:w-[500px] bg-white shadow-2xl z-50 flex flex-col"
          >
            {/* Header */}
            <div className="p-6 border-b bg-gradient-to-r from-fuchsia-500 to-purple-600">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Filter className="h-6 w-6 text-white" />
                  <h2 className="text-2xl font-bold text-white">Filtres avancés</h2>
                </div>
                <Button variant="ghost" size="icon" onClick={onClose} className="text-white hover:bg-white/20">
                  <X className="h-5 w-5" />
                </Button>
              </div>
            </div>

            {/* Filters Content */}
            <div className="flex-1 p-6 overflow-y-auto">
              <div className="space-y-8">
                {/* Themes */}
                <div>
                  <Label className="text-lg font-semibold mb-3 block">Thèmes</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {THEMES.map(theme => (
                      <div key={theme} className="flex items-center space-x-2">
                        <Checkbox
                          id={`theme-${theme}`}
                          checked={(localFilters.themes || []).includes(theme)}
                          onCheckedChange={() => toggleTheme(theme)}
                        />
                        <label htmlFor={`theme-${theme}`} className="text-sm cursor-pointer">
                          {theme}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Date Filter */}
                <div>
                  <Label className="text-lg font-semibold mb-3 block">Dates</Label>
                  <Select value={localFilters.dateFilter || 'all'} onValueChange={(v) => updateFilter('dateFilter', v)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Toutes les dates</SelectItem>
                      <SelectItem value="today">Aujourd'hui</SelectItem>
                      <SelectItem value="week">Cette semaine</SelectItem>
                      <SelectItem value="month">Ce mois-ci</SelectItem>
                      <SelectItem value="year">Cette année</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Creator */}
                <div>
                  <Label className="text-lg font-semibold mb-3 block">Créateurs</Label>
                  <div className="space-y-2">
                    {['me', 'paty', 'imported', 'other'].map(creator => (
                      <div key={creator} className="flex items-center space-x-2">
                        <Checkbox
                          id={`creator-${creator}`}
                          checked={(localFilters.creators || []).includes(creator)}
                          onCheckedChange={() => {
                            const current = localFilters.creators || [];
                            const updated = current.includes(creator)
                              ? current.filter(c => c !== creator)
                              : [...current, creator];
                            updateFilter('creators', updated);
                          }}
                        />
                        <label htmlFor={`creator-${creator}`} className="text-sm cursor-pointer">
                          {creator === 'me' && 'Mes grilles'}
                          {creator === 'paty' && 'Créées via Paty'}
                          {creator === 'imported' && 'Grilles importées'}
                          {creator === 'other' && 'Autres personnes'}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Size */}
                <div>
                  <Label className="text-lg font-semibold mb-3 block">Taille de grille</Label>
                  <Select value={localFilters.sizePreset || 'all'} onValueChange={(v) => updateFilter('sizePreset', v)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Toutes les tailles</SelectItem>
                      {SIZE_PRESETS.map(preset => (
                        <SelectItem key={preset.value} value={preset.value}>{preset.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Stitch Types */}
                <div>
                  <Label className="text-lg font-semibold mb-3 block">Type de broderie</Label>
                  <div className="space-y-2">
                    {STITCH_TYPES.map(type => (
                      <div key={type.value} className="flex items-center space-x-2">
                        <Checkbox
                          id={`stitch-${type.value}`}
                          checked={(localFilters.stitchTypes || []).includes(type.value)}
                          onCheckedChange={() => toggleStitchType(type.value)}
                        />
                        <label htmlFor={`stitch-${type.value}`} className="text-sm cursor-pointer">
                          {type.label}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Color Range */}
                <div>
                  <Label className="text-lg font-semibold mb-3 block">Nombre de couleurs</Label>
                  <Select value={localFilters.colorRange || 'all'} onValueChange={(v) => updateFilter('colorRange', v)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Toutes</SelectItem>
                      {COLOR_RANGES.map(range => (
                        <SelectItem key={range.value} value={range.value}>{range.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Beads */}
                <div>
                  <Label className="text-lg font-semibold mb-3 block">Perles</Label>
                  <Select value={localFilters.beadsFilter || 'all'} onValueChange={(v) => updateFilter('beadsFilter', v)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Toutes</SelectItem>
                      <SelectItem value="with">Avec perles uniquement</SelectItem>
                      <SelectItem value="without">Sans perles uniquement</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Status */}
                <div>
                  <Label className="text-lg font-semibold mb-3 block">Statut</Label>
                  <div className="space-y-2">
                    {[
                      { value: 'never_started', label: 'Jamais commencé' },
                      { value: 'in_progress', label: 'En cours' },
                      { value: 'completed', label: 'Terminé' },
                      { value: 'preparation', label: 'Préparation' }
                    ].map(status => (
                      <div key={status.value} className="flex items-center space-x-2">
                        <Checkbox
                          id={`status-${status.value}`}
                          checked={(localFilters.status || []).includes(status.value)}
                          onCheckedChange={() => {
                            const current = localFilters.status || [];
                            const updated = current.includes(status.value)
                              ? current.filter(s => s !== status.value)
                              : [...current, status.value];
                            updateFilter('status', updated);
                          }}
                        />
                        <label htmlFor={`status-${status.value}`} className="text-sm cursor-pointer">
                          {status.label}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Paty Mode */}
                <div>
                  <Label className="text-lg font-semibold mb-3 block">Mode Paty</Label>
                  <Select value={localFilters.patyMode || 'all'} onValueChange={(v) => updateFilter('patyMode', v)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Tous</SelectItem>
                      <SelectItem value="paty">Créations assistées par Paty</SelectItem>
                      <SelectItem value="manual">Créations manuelles</SelectItem>
                      <SelectItem value="imported">Importations</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Tags */}
                <div>
                  <Label className="text-lg font-semibold mb-3 block">Tags</Label>
                  <Input
                    placeholder="Rechercher par tag..."
                    value={localFilters.tags || ''}
                    onChange={(e) => updateFilter('tags', e.target.value)}
                  />
                </div>

                {/* Time Range */}
                <div>
                  <Label className="text-lg font-semibold mb-3 block">Temps estimé</Label>
                  <Select value={localFilters.timeRange || 'all'} onValueChange={(v) => updateFilter('timeRange', v)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Tous</SelectItem>
                      {TIME_RANGES.map(range => (
                        <SelectItem key={range.value} value={range.value}>{range.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Difficulty */}
                <div>
                  <Label className="text-lg font-semibold mb-3 block">Difficulté</Label>
                  <Select value={localFilters.difficulty || 'all'} onValueChange={(v) => updateFilter('difficulty', v)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Toutes</SelectItem>
                      <SelectItem value="easy">Facile</SelectItem>
                      <SelectItem value="medium">Moyen</SelectItem>
                      <SelectItem value="hard">Difficile</SelectItem>
                      <SelectItem value="expert">Expert</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            {/* Footer Actions */}
            <div className="p-6 border-t bg-slate-50 space-y-3">
              <Button
                onClick={handleApply}
                className="w-full bg-gradient-to-r from-fuchsia-600 to-purple-600 hover:from-fuchsia-700 hover:to-purple-700"
              >
                <Filter className="h-4 w-4 mr-2" />
                Appliquer les filtres
              </Button>
              <Button
                onClick={handleReset}
                variant="outline"
                className="w-full"
              >
                <RotateCcw className="h-4 w-4 mr-2" />
                Réinitialiser
              </Button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}