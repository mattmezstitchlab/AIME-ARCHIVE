import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Clock, CheckCircle, Play, Sparkles, Timer, Star, Gem, Grid3x3 } from 'lucide-react';
import { motion } from 'framer-motion';

export default function SmartCollections({ patterns, onSelectCollection }) {
  const collections = [
    {
      id: 'in_progress',
      name: 'En cours',
      icon: Clock,
      count: patterns.filter(p => !p.is_completed && (p.completion_percentage || 0) > 0).length,
      color: 'bg-blue-100 text-blue-700',
      filter: (p) => !p.is_completed && (p.completion_percentage || 0) > 0
    },
    {
      id: 'completed',
      name: 'Terminé',
      icon: CheckCircle,
      count: patterns.filter(p => p.is_completed).length,
      color: 'bg-green-100 text-green-700',
      filter: (p) => p.is_completed
    },
    {
      id: 'never_started',
      name: 'Jamais commencé',
      icon: Play,
      count: patterns.filter(p => (p.completion_percentage || 0) === 0 && !p.is_completed).length,
      color: 'bg-slate-100 text-slate-700',
      filter: (p) => (p.completion_percentage || 0) === 0 && !p.is_completed
    },
    {
      id: 'paty',
      name: 'Créés avec Paty',
      icon: Sparkles,
      count: patterns.filter(p => p.created_by_paty).length,
      color: 'bg-fuchsia-100 text-fuchsia-700',
      filter: (p) => p.created_by_paty
    },
    {
      id: 'long',
      name: 'Projets longs',
      icon: Timer,
      count: patterns.filter(p => (p.estimated_hours || 0) >= 50).length,
      color: 'bg-orange-100 text-orange-700',
      filter: (p) => (p.estimated_hours || 0) >= 50
    },
    {
      id: 'easy',
      name: 'Projets faciles',
      icon: Star,
      count: patterns.filter(p => p.difficulty === 'easy').length,
      color: 'bg-yellow-100 text-yellow-700',
      filter: (p) => p.difficulty === 'easy'
    },
    {
      id: 'beads',
      name: 'Avec perles',
      icon: Gem,
      count: patterns.filter(p => p.has_beads).length,
      color: 'bg-pink-100 text-pink-700',
      filter: (p) => p.has_beads
    },
    {
      id: 'special',
      name: 'Points spéciaux',
      icon: Grid3x3,
      count: patterns.filter(p => p.stitch_types && p.stitch_types.includes('special')).length,
      color: 'bg-purple-100 text-purple-700',
      filter: (p) => p.stitch_types && p.stitch_types.includes('special')
    }
  ];

  return (
    <div className="mb-6">
      <h3 className="text-sm font-semibold text-slate-700 mb-3">Collections intelligentes</h3>
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-3">
        {collections.map((collection, index) => {
          const Icon = collection.icon;
          return (
            <motion.div
              key={collection.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <Card 
                className="hover:shadow-lg transition-all cursor-pointer"
                onClick={() => onSelectCollection(collection)}
              >
                <CardContent className="p-4 text-center">
                  <div className={`w-10 h-10 rounded-full ${collection.color} flex items-center justify-center mx-auto mb-2`}>
                    <Icon className="h-5 w-5" />
                  </div>
                  <p className="text-xs font-medium text-slate-700 mb-1">{collection.name}</p>
                  <Badge variant="secondary" className="text-xs">{collection.count}</Badge>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}