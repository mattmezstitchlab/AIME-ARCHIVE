import React from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Clock, Calendar, User } from 'lucide-react';

export default function PatternListItem({ pattern, onOpen, onShowDetails }) {
  const getCreatorLabel = (pattern) => {
    if (pattern.created_by_paty) return 'Paty';
    if (pattern.source_type === 'pdf_imported' || pattern.source_type === 'image_imported') return 'Importé';
    return 'Moi';
  };

  const getStitchTypeLabel = (types) => {
    if (!types || types.length === 0) return 'Point de croix simple';
    if (types.includes('beads')) return 'Avec perles';
    if (types.includes('special')) return 'Points spéciaux';
    if (types.includes('half')) return 'Demi-points';
    return 'Point de croix';
  };

  return (
    <div className="flex items-center gap-4 p-4 hover:bg-slate-50 rounded-lg transition-colors group">
      {/* Thumbnail */}
      <div className="w-16 h-16 rounded-lg bg-gradient-to-br from-slate-100 to-slate-200 flex-shrink-0 overflow-hidden">
        {pattern.file_url && (
          <img
            src={pattern.file_url}
            alt={pattern.name}
            className="w-full h-full object-cover"
          />
        )}
      </div>

      {/* Name */}
      <div className="flex-1 min-w-0">
        <h4 className="font-semibold text-slate-800 truncate">{pattern.name}</h4>
        <p className="text-sm text-slate-600">{pattern.grid_width}×{pattern.grid_height} • {pattern.color_count || 0} couleurs</p>
      </div>

      {/* Type */}
      <div className="hidden md:block w-32">
        <Badge variant="outline" className="text-xs">
          {getStitchTypeLabel(pattern.stitch_types)}
        </Badge>
      </div>

      {/* Duration */}
      {pattern.estimated_hours && (
        <div className="hidden lg:flex items-center gap-1 text-sm text-slate-600 w-24">
          <Clock className="h-4 w-4" />
          {Math.round(pattern.estimated_hours)}h
        </div>
      )}

      {/* Creator */}
      <div className="hidden lg:flex items-center gap-1 text-sm text-slate-600 w-24">
        <User className="h-4 w-4" />
        {getCreatorLabel(pattern)}
      </div>

      {/* Date */}
      <div className="hidden xl:flex items-center gap-1 text-sm text-slate-600 w-32">
        <Calendar className="h-4 w-4" />
        {new Date(pattern.created_date).toLocaleDateString('fr-FR')}
      </div>

      {/* Actions */}
      <div className="flex items-center gap-2">
        <Button
          variant="outline"
          size="sm"
          onClick={() => onShowDetails(pattern)}
        >
          Détails
        </Button>
        <Button
          size="sm"
          onClick={() => onOpen(pattern)}
          className="bg-gradient-to-r from-fuchsia-600 to-purple-600"
        >
          Ouvrir
        </Button>
      </div>
    </div>
  );
}