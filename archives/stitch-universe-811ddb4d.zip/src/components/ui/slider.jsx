import React, { useState, useRef } from 'react';

export function Slider({ value = [50], onValueChange, min = 0, max = 100, step = 1, className = '' }) {
  const [isDragging, setIsDragging] = useState(false);
  const sliderRef = useRef(null);

  const percentage = ((value[0] - min) / (max - min)) * 100;

  const handleMouseDown = (e) => {
    setIsDragging(true);
    updateValue(e);
  };

  const handleMouseMove = (e) => {
    if (isDragging) {
      updateValue(e);
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const updateValue = (e) => {
    if (!sliderRef.current) return;
    
    const rect = sliderRef.current.getBoundingClientRect();
    const x = Math.max(0, Math.min(e.clientX - rect.left, rect.width));
    const percentage = x / rect.width;
    const newValue = min + percentage * (max - min);
    const steppedValue = Math.round(newValue / step) * step;
    const clampedValue = Math.max(min, Math.min(max, steppedValue));
    
    if (onValueChange) {
      onValueChange([clampedValue]);
    }
  };

  React.useEffect(() => {
    if (isDragging) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
      return () => {
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
      };
    }
  }, [isDragging]);

  return (
    <div
      ref={sliderRef}
      className={`relative flex items-center w-full h-2 bg-slate-200 rounded-full cursor-pointer ${className}`}
      onMouseDown={handleMouseDown}
    >
      <div
        className="absolute h-full bg-[#FF5F6D] rounded-full"
        style={{ width: `${percentage}%` }}
      />
      <div
        className="absolute w-5 h-5 bg-white border-2 border-[#FF5F6D] rounded-full shadow-md transform -translate-x-1/2 transition-transform hover:scale-110"
        style={{ left: `${percentage}%` }}
      />
    </div>
  );
}