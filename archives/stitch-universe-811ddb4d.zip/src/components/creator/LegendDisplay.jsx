import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Eye } from 'lucide-react';

export default function LegendDisplay({ legend, onFilterColor }) {
  if (!legend || legend.length === 0) {
    return null;
  }

  const sortedLegend = [...legend].sort((a, b) => (b.total_stitches || 0) - (a.total_stitches || 0));

  const getStitchTypeLabel = (pointType) => {
    const types = {
      full_cross: 'Croix pleine',
      half_stitch: 'Demi-point',
      quarter_stitch: 'Quart de point',
      special: 'Point spécial',
      bead: 'Perle',
      backstitch: 'Point arrière'
    };
    return types[pointType] || 'Croix pleine';
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Légende des couleurs DMC</CardTitle>
        <p className="text-sm text-slate-600">
          {legend.length} couleur{legend.length > 1 ? 's' : ''} • Classé par nombre de points
        </p>
      </CardHeader>
      <CardContent>
        <div className="grid md:grid-cols-2 gap-3 max-h-96 overflow-y-auto">
          {sortedLegend.map((item, index) => (
            <div
              key={index}
              className="flex items-center gap-3 p-3 rounded-lg bg-slate-50 hover:bg-slate-100 transition-colors group"
            >
              <div
                className="w-12 h-12 rounded-lg flex items-center justify-center text-white font-bold shadow-md flex-shrink-0"
                style={{ backgroundColor: item.color_hex }}
              >
                {item.symbol}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-mono font-semibold text-slate-800">{item.dmc_code}</span>
                  <span className="text-sm text-slate-600 truncate">{item.dmc_name}</span>
                </div>
                <div className="flex items-center gap-2 text-xs">
                  <Badge variant="outline" className="text-xs">
                    {getStitchTypeLabel(item.point_type)}
                  </Badge>
                  <span className="text-slate-500">{item.total_stitches || 0} points</span>
                </div>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0"
                onClick={() => onFilterColor(item.symbol)}
                title="Voir uniquement cette couleur"
              >
                <Eye className="h-4 w-4" />
              </Button>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}