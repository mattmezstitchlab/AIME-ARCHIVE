import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Camera, Upload, Grid3x3 } from 'lucide-react';
import { motion } from 'framer-motion';

export default function ModeSelector({ selectedMode, onSelectMode }) {
  const modes = [
    {
      id: 'photo',
      name: 'Depuis une photo',
      icon: Camera,
      description: 'Transforme une photo en grille de broderie',
      gradient: 'from-blue-500 to-cyan-600'
    },
    {
      id: 'import',
      name: 'Importer une grille',
      icon: Upload,
      description: 'Importe un PDF ou une image existante',
      gradient: 'from-purple-500 to-pink-600'
    },
    {
      id: 'blank',
      name: 'Créer une grille vierge',
      icon: Grid3x3,
      description: 'Commence avec une grille vide',
      gradient: 'from-orange-500 to-red-600'
    }
  ];

  return (
    <div className="grid md:grid-cols-3 gap-6 mb-8">
      {modes.map((mode, index) => {
        const Icon = mode.icon;
        const isSelected = selectedMode === mode.id;
        return (
          <motion.div
            key={mode.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card
              className={`cursor-pointer transition-all duration-300 ${
                isSelected 
                  ? 'ring-4 ring-fuchsia-500 shadow-xl scale-105' 
                  : 'hover:shadow-lg hover:scale-102'
              }`}
              onClick={() => onSelectMode(mode.id)}
            >
              <CardContent className="p-6 text-center">
                <div className={`w-16 h-16 rounded-full bg-gradient-to-br ${mode.gradient} flex items-center justify-center mx-auto mb-4`}>
                  <Icon className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-slate-800 mb-2">{mode.name}</h3>
                <p className="text-sm text-slate-600">{mode.description}</p>
              </CardContent>
            </Card>
          </motion.div>
        );
      })}
    </div>
  );
}