import React from 'react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Image as ImageIcon, Grid3x3, Eye } from 'lucide-react';

export default function PreviewTabs({ originalImage, pixelizedPreview, gridWithSymbols }) {
  return (
    <Card>
      <CardContent className="p-6">
        <Tabs defaultValue="pixelized" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-6">
            <TabsTrigger value="original" className="flex items-center gap-2">
              <ImageIcon className="h-4 w-4" />
              Image originale
            </TabsTrigger>
            <TabsTrigger value="pixelized" className="flex items-center gap-2">
              <Grid3x3 className="h-4 w-4" />
              Aperçu pixelisé
            </TabsTrigger>
            <TabsTrigger value="symbols" className="flex items-center gap-2">
              <Eye className="h-4 w-4" />
              Grille avec symboles
            </TabsTrigger>
          </TabsList>

          <TabsContent value="original">
            <div className="space-y-4">
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                <p className="text-sm text-amber-900">
                  <strong>Image d'origine :</strong> Voici ton image de départ avant transformation.
                </p>
              </div>
              <div className="flex justify-center">
                {originalImage ? (
                  <img
                    src={originalImage}
                    alt="Original"
                    className="max-h-[500px] rounded-lg shadow-lg"
                  />
                ) : (
                  <div className="w-full h-64 bg-slate-100 rounded-lg flex items-center justify-center">
                    <p className="text-slate-500">Aucune image</p>
                  </div>
                )}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="pixelized">
            <div className="space-y-4">
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                <p className="text-sm text-amber-900">
                  <strong>Aperçu pixelisé :</strong> Chaque carré représente une case avec sa couleur DMC. 
                  C'est exactement comme ça que ta grille sera transformée.
                </p>
              </div>
              <div className="flex justify-center overflow-auto max-h-[600px] border rounded-lg bg-white">
                {pixelizedPreview || (
                  <div className="w-full h-64 bg-slate-100 flex items-center justify-center">
                    <p className="text-slate-500">Génère une grille pour voir l'aperçu</p>
                  </div>
                )}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="symbols">
            <div className="space-y-4">
              <div className="bg-indigo-50 border border-indigo-200 rounded-lg p-4">
                <p className="text-sm text-indigo-900">
                  <strong>Grille détaillée :</strong> Chaque symbole correspond à une couleur DMC. 
                  Utilise cette vue pour broder point par point.
                </p>
              </div>
              <div className="flex justify-center overflow-auto max-h-[600px] border rounded-lg bg-white">
                {gridWithSymbols || (
                  <div className="w-full h-64 bg-slate-100 flex items-center justify-center">
                    <p className="text-slate-500">Génère une grille pour voir les symboles</p>
                  </div>
                )}
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}