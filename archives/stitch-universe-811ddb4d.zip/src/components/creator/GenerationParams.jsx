import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';

export default function GenerationParams({ params, onParamsChange }) {
  const sizePresets = [
    { label: 'Petit', width: 50, height: 50 },
    { label: 'Moyen', width: 100, height: 100 },
    { label: 'Grand', width: 150, height: 150 },
    { label: 'Très grand', width: 200, height: 200 }
  ];

  const stitchTypes = [
    { value: 'simple', label: 'Point de croix simple' },
    { value: 'half', label: 'Point de croix + demi-points' },
    { value: 'special', label: 'Point de croix + demi-points + points spéciaux' },
    { value: 'beads', label: 'Point de croix + perles' },
    { value: 'hybrid', label: 'Point de croix + demi-points + spéciaux + perles' },
    { value: 'full', label: 'Broderie complète (tous types)' }
  ];

  const totalStitches = (params.width || 0) * (params.height || 0);

  return (
    <Card>
      <CardHeader>
        <CardTitle>Paramètres de génération</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Size */}
        <div>
          <Label className="mb-3 block">Taille de la grille</Label>
          <div className="grid grid-cols-4 gap-2 mb-4">
            {sizePresets.map((preset) => (
              <Button
                key={preset.label}
                variant="outline"
                size="sm"
                onClick={() => onParamsChange({ width: preset.width, height: preset.height })}
                className={params.width === preset.width && params.height === preset.height ? 'bg-fuchsia-50 border-fuchsia-500' : ''}
              >
                {preset.label}
              </Button>
            ))}
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-xs mb-1 block">Largeur (cases)</Label>
              <Input
                type="number"
                value={params.width || ''}
                onChange={(e) => onParamsChange({ width: parseInt(e.target.value) || 0 })}
                min="10"
                max="500"
              />
            </div>
            <div>
              <Label className="text-xs mb-1 block">Hauteur (cases)</Label>
              <Input
                type="number"
                value={params.height || ''}
                onChange={(e) => onParamsChange({ height: parseInt(e.target.value) || 0 })}
                min="10"
                max="500"
              />
            </div>
          </div>
          <Badge variant="outline" className="mt-2">
            Total: {totalStitches.toLocaleString()} points
          </Badge>
        </div>

        {/* Colors */}
        <div>
          <Label className="mb-3 block">Nombre de couleurs: {params.colorCount}</Label>
          <Slider
            value={[params.colorCount]}
            onValueChange={([value]) => onParamsChange({ colorCount: value })}
            min={1}
            max={60}
            step={1}
            className="mb-2"
          />
          <div className="flex justify-between text-xs text-slate-500">
            <span>1</span>
            <span>30</span>
            <span>60</span>
          </div>
        </div>

        {/* Stitch Type */}
        <div>
          <Label className="mb-2 block">Type de broderie</Label>
          <Select value={params.stitchType} onValueChange={(value) => onParamsChange({ stitchType: value })}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {stitchTypes.map((type) => (
                <SelectItem key={type.value} value={type.value}>
                  {type.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* DMC Palette */}
        <div>
          <Label className="mb-2 block">Palette DMC</Label>
          <Select value={params.dmcPalette} onValueChange={(value) => onParamsChange({ dmcPalette: value })}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Toute la palette DMC</SelectItem>
              <SelectItem value="selected">Mes couleurs sélectionnées uniquement</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Resolution */}
        <div>
          <Label className="mb-2 block">Résolution d'analyse</Label>
          <Select value={params.resolution} onValueChange={(value) => onParamsChange({ resolution: value })}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="auto">Automatique (recommandé)</SelectItem>
              <SelectItem value="high">Haute précision</SelectItem>
              <SelectItem value="fast">Rapide</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Simplification */}
        <div className="space-y-3 pt-4 border-t">
          <Label className="block font-semibold">Simplification de la grille</Label>
          
          <div className="flex items-center justify-between">
            <Label className="text-sm">Réduire les zones trop détaillées</Label>
            <Switch
              checked={params.reduceDetails}
              onCheckedChange={(checked) => onParamsChange({ reduceDetails: checked })}
            />
          </div>

          <div className="flex items-center justify-between">
            <Label className="text-sm">Adoucir les dégradés</Label>
            <Switch
              checked={params.smoothGradients}
              onCheckedChange={(checked) => onParamsChange({ smoothGradients: checked })}
            />
          </div>

          <div className="flex items-center justify-between">
            <Label className="text-sm">Uniformiser les zones proches</Label>
            <Switch
              checked={params.uniformizeZones}
              onCheckedChange={(checked) => onParamsChange({ uniformizeZones: checked })}
            />
          </div>

          <div className="flex items-center justify-between">
            <Label className="text-sm">Optimiser pour broderie réelle</Label>
            <Switch
              checked={params.optimizeReal}
              onCheckedChange={(checked) => onParamsChange({ optimizeReal: checked })}
            />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}