import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Home, Settings, User } from 'lucide-react';
import { createPageUrl } from './utils';
import PatyBubble from './components/paty/PatyBubble';

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [isPatyChatOpen, setIsPatyChatOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-100 flex flex-col">
      {/* Top Navigation */}
      <nav className="fixed top-0 left-0 right-0 bg-[#FF5F6D] shadow-lg z-50">
        <div className="bg-sky-600 px-8 py-4 flex items-center justify-between">
          {/* Left: PATY Title + Tagline */}
          <div>
            <h1 className="text-4xl font-black text-white tracking-tight" style={{ fontFamily: 'system-ui, -apple-system, sans-serif' }}>PATY</h1>
            <p className="text-xs text-white/90" style={{ fontFamily: 'Helvetica, Arial, sans-serif' }}>L'application N°1 Mondial de point de croix</p>
          </div>

          {/* Center: Paty IA Button */}
          <div className="absolute left-1/2 -translate-x-1/2">
            <button
              onClick={() => setIsPatyChatOpen(true)}
              className="flex items-center justify-center w-16 h-16 rounded-full bg-white shadow-lg hover:shadow-xl transition-all"
              style={{ animation: 'bubble-pulse 2s ease-in-out infinite' }}>

              <svg className="w-10 h-10 text-[#FF5F6D]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
              <span
                className="absolute text-[#FF5F6D] font-bold text-xl"
                style={{
                  animation: 'spin-rotate 3s linear infinite',
                  transform: 'translateY(-2px)'
                }}>

                +
              </span>
            </button>
          </div>

          {/* Right: Icons */}
          <div className="flex items-center gap-2">
            <Link
              to={createPageUrl('Home')}
              className="flex items-center justify-center w-10 h-10 rounded-full hover:bg-white/10 transition-all">

              <Home className="h-6 w-6 text-white" />
            </Link>
            <Link
              to={createPageUrl('Profile')}
              className="flex items-center justify-center w-10 h-10 rounded-full hover:bg-white/10 transition-all">

              <User className="h-6 w-6 text-white" />
            </Link>
            <Link
              to={createPageUrl('WorkSettings')}
              className="flex items-center justify-center w-10 h-10 rounded-full hover:bg-white/10 transition-all">

              <Settings className="h-6 w-6 text-white" />
            </Link>
          </div>
        </div>
      </nav>

      {/* Main Content with top padding */}
      <main className="flex-1 pt-24">
        {children}
      </main>

      {/* Paty Chat */}
      <PatyBubble isOpen={isPatyChatOpen} onClose={() => setIsPatyChatOpen(false)} />
      
      <style>{`
        @keyframes bubble-pulse {
          0%, 100% {
            transform: scale(1);
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
          }
          50% {
            transform: scale(1.1);
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.15);
          }
        }
        @keyframes spin-rotate {
          from {
            transform: rotate(0deg);
          }
          to {
            transform: rotate(360deg);
          }
        }
      `}</style>
    </div>);

}