import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Trophy, Medal, Crown } from 'lucide-react';
import { motion } from 'framer-motion';

export default function GlobalRanking() {
  const rankings = [
    { rank: 1, name: 'Marie L.', points: 125000, country: '🇫🇷', badge: 'Maître Brodeur' },
    { rank: 2, name: 'Sophie M.', points: 118500, country: '🇧🇪', badge: 'Expert' },
    { rank: 3, name: 'Claire D.', points: 112000, country: '🇨🇭', badge: 'Expert' },
    { rank: 4, name: 'Anne B.', points: 98000, country: '🇫🇷', badge: 'Avancé' },
    { rank: 5, name: 'Julie R.', points: 95000, country: '🇨🇦', badge: 'Avancé' }
  ];

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-[900px] mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-slate-800 mb-2">Classement mondial</h1>
          <p className="text-slate-600">Découvre les meilleurs brodeurs de la communauté</p>
        </div>

        <Tabs defaultValue="global" className="mb-8">
          <TabsList className="bg-slate-100 w-full">
            <TabsTrigger value="global">Mondial</TabsTrigger>
            <TabsTrigger value="country">Par pays</TabsTrigger>
            <TabsTrigger value="theme">Par thème</TabsTrigger>
            <TabsTrigger value="difficulty">Par difficulté</TabsTrigger>
            <TabsTrigger value="paty">Paty Master</TabsTrigger>
          </TabsList>

          <TabsContent value="global" className="mt-6">
            <div className="space-y-4">
              {rankings.map((user, index) => (
                <motion.div key={user.rank} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: index * 0.1 }}>
                  <Card className={`hover:shadow-lg transition-all ${user.rank <= 3 ? 'border-2 border-[#FF5F6D]' : ''}`}>
                    <CardContent className="p-6">
                      <div className="flex items-center gap-4">
                        <div className="flex-shrink-0">
                          {user.rank === 1 && <Crown className="h-8 w-8 text-[#FF5F6D]" />}
                          {user.rank === 2 && <Medal className="h-8 w-8 text-slate-400" />}
                          {user.rank === 3 && <Medal className="h-8 w-8 text-amber-600" />}
                          {user.rank > 3 && (
                            <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center font-bold text-slate-700">
                              {user.rank}
                            </div>
                          )}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-semibold text-lg">{user.name}</span>
                            <span className="text-2xl">{user.country}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge className="bg-[#FF5F6D]/20 text-[#FF5F6D] border-[#FF5F6D]/30">{user.badge}</Badge>
                            <span className="text-sm text-slate-600">{user.points.toLocaleString()} points</span>
                          </div>
                        </div>
                        {user.rank <= 3 && (
                          <Trophy className={`h-10 w-10 ${user.rank === 1 ? 'text-[#FF5F6D]' : user.rank === 2 ? 'text-slate-400' : 'text-amber-600'}`} />
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>

            <Card className="mt-8 bg-[#FF5F6D]/10 border-[#FF5F6D]/20">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-slate-600 mb-1">Ta position</p>
                    <p className="text-2xl font-bold text-slate-800">#247</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-slate-600 mb-1">Tes points</p>
                    <p className="text-2xl font-bold text-[#FF5F6D]">12,450</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="country">
            <Card>
              <CardContent className="p-12 text-center">
                <Trophy className="h-16 w-16 text-slate-300 mx-auto mb-4" />
                <p className="text-slate-500">Classement par pays bientôt disponible</p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="theme">
            <Card>
              <CardContent className="p-12 text-center">
                <Trophy className="h-16 w-16 text-slate-300 mx-auto mb-4" />
                <p className="text-slate-500">Classement par thème bientôt disponible</p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="difficulty">
            <Card>
              <CardContent className="p-12 text-center">
                <Trophy className="h-16 w-16 text-slate-300 mx-auto mb-4" />
                <p className="text-slate-500">Classement par difficulté bientôt disponible</p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="paty">
            <Card>
              <CardContent className="p-12 text-center">
                <Trophy className="h-16 w-16 text-slate-300 mx-auto mb-4" />
                <p className="text-slate-500">Classement Paty Master bientôt disponible</p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}