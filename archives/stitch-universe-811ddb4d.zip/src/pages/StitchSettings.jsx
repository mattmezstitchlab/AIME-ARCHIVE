import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ArrowLeft, Grid3x3, Sparkles } from 'lucide-react';
import { createPageUrl } from '../utils';
import { motion } from 'framer-motion';

const STITCH_TYPES = [
  {
    key: 'full_cross_enabled',
    label: 'Croix pleine',
    description: 'Le point de croix standard, recouvre entièrement la case'
  },
  {
    key: 'half_stitch_enabled',
    label: 'Demi-point',
    description: 'Point de croix sur la moitié de la case'
  },
  {
    key: 'quarter_stitch_enabled',
    label: 'Quart de point',
    description: 'Point sur un quart de la case'
  },
  {
    key: 'backstitch_enabled',
    label: 'Point arrière (backstitch)',
    description: 'Trait de contour entre les cases'
  },
  {
    key: 'special_stitches_enabled',
    label: 'Points spéciaux',
    description: 'Points décoratifs (nœud, étoile, etc.)'
  }
];

const BEAD_SYMBOLS = [
  { value: 'O', label: 'O (cercle)' },
  { value: '◇', label: '◇ (losange)' },
  { value: '⬤', label: '⬤ (rond plein)' },
  { value: '*', label: '* (étoile)' }
];

export default function StitchSettings() {
  const navigate = useNavigate();
  const [isAuthenticated, setIsAuthenticated] = useState(null);
  const [settings, setSettings] = useState({
    full_cross_enabled: true,
    half_stitch_enabled: false,
    quarter_stitch_enabled: false,
    backstitch_enabled: false,
    special_stitches_enabled: false,
    beads_enabled: false,
    bead_symbol: 'O',
    bead_color: '#FFD700',
    highlight_special_stitches: true,
    highlight_beads: true,
    show_bead_counter: true
  });
  const [settingsId, setSettingsId] = useState(null);

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const isAuth = await base44.auth.isAuthenticated();
      setIsAuthenticated(isAuth);

      if (isAuth) {
        const dbSettings = await base44.entities.StitchSettings.list();
        if (dbSettings.length > 0) {
          setSettings(dbSettings[0]);
          setSettingsId(dbSettings[0].id);
        } else {
          const created = await base44.entities.StitchSettings.create(settings);
          setSettingsId(created.id);
        }
      } else {
        const localSettings = localStorage.getItem('paticroix_stitch_settings');
        if (localSettings) {
          setSettings(JSON.parse(localSettings));
        }
      }
    } catch (error) {
      console.error('Erreur chargement paramètres:', error);
      const localSettings = localStorage.getItem('paticroix_stitch_settings');
      if (localSettings) {
        setSettings(JSON.parse(localSettings));
      }
      setIsAuthenticated(false);
    }
  };

  const updateSetting = async (key, value) => {
    const newSettings = { ...settings, [key]: value };
    setSettings(newSettings);

    try {
      if (isAuthenticated && settingsId) {
        await base44.entities.StitchSettings.update(settingsId, { [key]: value });
      } else {
        localStorage.setItem('paticroix_stitch_settings', JSON.stringify(newSettings));
      }
    } catch (error) {
      console.error('Erreur mise à jour paramètres:', error);
      localStorage.setItem('paticroix_stitch_settings', JSON.stringify(newSettings));
    }
  };

  return (
    <div className="min-h-screen p-4 md:p-8 md:ml-64">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate(createPageUrl('Profile'))}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <h1 className="text-4xl font-bold text-slate-800 mb-2">Types de points & perles</h1>
            <p className="text-slate-600">Active les types de points utilisés dans tes grilles et choisis leur représentation</p>
          </div>
        </div>

        {/* Stitch Types Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <Card className="mb-6 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Grid3x3 className="h-5 w-5 text-indigo-600" />
                Types de points
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {STITCH_TYPES.map((type, index) => (
                <motion.div
                  key={type.key}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="flex items-center justify-between p-4 rounded-lg bg-slate-50 hover:bg-slate-100 transition-colors"
                >
                  <div className="flex-1">
                    <Label htmlFor={type.key} className="text-base font-semibold text-slate-800 cursor-pointer">
                      {type.label}
                    </Label>
                    <p className="text-sm text-slate-600 mt-1">{type.description}</p>
                  </div>
                  <Switch
                    id={type.key}
                    checked={settings[type.key]}
                    onCheckedChange={(checked) => updateSetting(type.key, checked)}
                  />
                </motion.div>
              ))}
            </CardContent>
          </Card>
        </motion.div>

        {/* Beads Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Card className="mb-6 shadow-lg bg-gradient-to-br from-amber-50 to-yellow-50 border-amber-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-amber-600" />
                Perles
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <p className="text-sm text-slate-700">
                Active cette option si ta broderie contient des perles à emplacements précis.
              </p>

              <div className="flex items-center justify-between p-4 rounded-lg bg-white">
                <Label htmlFor="beads_enabled" className="text-base font-semibold text-slate-800 cursor-pointer">
                  Activer les emplacements de perles
                </Label>
                <Switch
                  id="beads_enabled"
                  checked={settings.beads_enabled}
                  onCheckedChange={(checked) => updateSetting('beads_enabled', checked)}
                />
              </div>

              {settings.beads_enabled && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  className="space-y-4 pl-4 border-l-4 border-amber-300"
                >
                  <div className="space-y-2">
                    <Label htmlFor="bead_symbol">Symbole des perles dans la grille</Label>
                    <Select
                      value={settings.bead_symbol}
                      onValueChange={(value) => updateSetting('bead_symbol', value)}
                    >
                      <SelectTrigger id="bead_symbol" className="bg-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {BEAD_SYMBOLS.map((symbol) => (
                          <SelectItem key={symbol.value} value={symbol.value}>
                            {symbol.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="bead_color">Couleur d'affichage des perles</Label>
                    <div className="flex gap-2">
                      <input
                        type="color"
                        id="bead_color"
                        value={settings.bead_color}
                        onChange={(e) => updateSetting('bead_color', e.target.value)}
                        className="w-16 h-10 rounded border-2 cursor-pointer bg-white"
                      />
                      <div className="flex-1 flex items-center px-4 rounded border-2 bg-white">
                        <span className="font-mono text-sm">{settings.bead_color}</span>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </CardContent>
          </Card>
        </motion.div>

        {/* Display Settings in Reader */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle>Affichage dans le lecteur</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-4 rounded-lg bg-slate-50">
                <Label htmlFor="highlight_special" className="cursor-pointer">
                  Surligner les points spéciaux
                </Label>
                <Switch
                  id="highlight_special"
                  checked={settings.highlight_special_stitches}
                  onCheckedChange={(checked) => updateSetting('highlight_special_stitches', checked)}
                />
              </div>

              <div className="flex items-center justify-between p-4 rounded-lg bg-slate-50">
                <Label htmlFor="highlight_beads" className="cursor-pointer">
                  Surligner les endroits pour les perles
                </Label>
                <Switch
                  id="highlight_beads"
                  checked={settings.highlight_beads}
                  onCheckedChange={(checked) => updateSetting('highlight_beads', checked)}
                />
              </div>

              <div className="flex items-center justify-between p-4 rounded-lg bg-slate-50">
                <Label htmlFor="show_counter" className="cursor-pointer">
                  Afficher un compteur de perles restantes
                </Label>
                <Switch
                  id="show_counter"
                  checked={settings.show_bead_counter}
                  onCheckedChange={(checked) => updateSetting('show_bead_counter', checked)}
                />
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Info Banner */}
        <Card className="mt-6 bg-slate-50 border-slate-200">
          <CardContent className="p-4">
            <p className="text-sm text-slate-600">
              💡 <strong>Astuce :</strong> Ces paramètres seront appliqués automatiquement dans le lecteur de grilles et lors de la génération de nouvelles grilles.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}