import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ShoppingCart, Package, Sparkles, ExternalLink } from 'lucide-react';
import { motion } from 'framer-motion';

export default function Shop() {
  const categories = [
    { name: 'Fils DMC', icon: Package, description: 'Tous les fils DMC pour tes projets', items: 24 },
    { name: 'Toiles', icon: Package, description: 'Toiles Aida de toutes tailles', items: 12 },
    { name: 'Aiguilles', icon: Package, description: 'Aiguilles adaptées à chaque projet', items: 8 },
    { name: 'Perles', icon: Sparkles, description: 'Perles de rocaille pour décorer', items: 15 },
    { name: 'Kits complets', icon: Package, description: 'Kits tout-en-un prêts à broder', items: 32 }
  ];

  const suggestions = [
    { name: 'Fil DMC 310 - Noir', price: '2,50 €', image: 'https://images.unsplash.com/photo-1452860606245-08befc0ff44b?w=200', reason: 'Recommandé pour ta grille actuelle' },
    { name: 'Toile Aida 14 pts - Blanc', price: '12,90 €', image: 'https://images.unsplash.com/photo-1515552726023-7125c8d07fb3?w=200', reason: 'Idéal pour projets moyens' }
  ];

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-[900px] mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-slate-800 mb-2">Boutique Paty</h1>
          <p className="text-slate-600">Tout le matériel dont tu as besoin pour tes projets</p>
        </div>

        <Card className="mb-8 bg-[#FF5F6D]/10 border-[#FF5F6D]/20">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Sparkles className="h-6 w-6 text-[#FF5F6D]" />
              Suggestions pour toi
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-4">
              {suggestions.map((item, index) => (
                <motion.div key={index} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.1 }}>
                  <Card className="hover:shadow-lg transition-all">
                    <CardContent className="p-4">
                      <div className="flex gap-4">
                        <img src={item.image} alt={item.name} className="w-20 h-20 rounded-lg object-cover" />
                        <div className="flex-1">
                          <h3 className="font-semibold text-slate-800 mb-1">{item.name}</h3>
                          <Badge variant="outline" className="text-xs mb-2">{item.reason}</Badge>
                          <div className="flex items-center justify-between">
                            <span className="text-lg font-bold text-[#FF5F6D]">{item.price}</span>
                            <Button size="sm" className="bg-[#FF5F6D] hover:bg-[#FF7A85]">
                              <ShoppingCart className="h-4 w-4 mr-1" />
                              Voir
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>

        <div className="grid md:grid-cols-2 gap-6">
          {categories.map((category, index) => {
            const Icon = category.icon;
            return (
              <motion.div key={index} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.1 }}>
                <Card className="hover:shadow-xl transition-all cursor-pointer h-full">
                  <CardHeader>
                    <div className="w-12 h-12 rounded-xl bg-[#FF5F6D] flex items-center justify-center mb-4">
                      <Icon className="h-6 w-6 text-white" />
                    </div>
                    <CardTitle className="text-lg">{category.name}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-slate-600 text-sm mb-3">{category.description}</p>
                    <Badge variant="outline">{category.items} produits</Badge>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>

        <Card className="mt-8 bg-slate-50 border-slate-200">
          <CardContent className="p-6 text-center">
            <ExternalLink className="h-12 w-12 text-slate-400 mx-auto mb-3" />
            <p className="text-slate-600 text-sm">
              Les liens d'achat te dirigent vers nos partenaires de confiance. 
              Paty peut recevoir une commission sur tes achats, ce qui nous aide à améliorer l'application.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}