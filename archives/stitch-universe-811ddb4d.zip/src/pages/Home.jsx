import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  FolderOpen, Wand2, Settings, Trophy, Lightbulb, Users, ShoppingBag,
  Flower2, Gamepad2, Leaf, TrendingUp, Clock, Award, Sparkles } from
'lucide-react';
import { createPageUrl } from '../utils';
import { motion } from 'framer-motion';

export default function Home() {
  const navigate = useNavigate();
  const [isAuthenticated, setIsAuthenticated] = useState(null);
  const [user, setUser] = useState(null);

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    const auth = await base44.auth.isAuthenticated();
    setIsAuthenticated(auth);
    if (auth) {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    }
  };

  const { data: patterns = [] } = useQuery({
    queryKey: ['patterns'],
    queryFn: async () => {
      if (!isAuthenticated) return [];
      return await base44.entities.Pattern.list('-last_opened');
    },
    enabled: isAuthenticated === true
  });

  const { data: progressList = [] } = useQuery({
    queryKey: ['progress'],
    queryFn: async () => {
      if (!isAuthenticated) return [];
      return await base44.entities.StitchProgress.list();
    },
    enabled: isAuthenticated === true
  });

  const stats = {
    stitchesThisMonth: progressList.reduce((sum, p) => sum + (p.stitches_completed?.length || 0), 0),
    hoursTotal: progressList.reduce((sum, p) => sum + (p.total_time_minutes || 0), 0) / 60,
    completedProjects: patterns.filter((p) => p.is_completed).length
  };

  const patyMessages = [
  "Simplifier ta dernière grille ?",
  "Tu veux apprendre un nouveau point ?",
  "Continue comme ça, ton projet avance bien !"];


  if (isAuthenticated === null) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin h-8 w-8 border-4 border-[#FF5F6D] border-t-transparent rounded-full"></div>
      </div>);

  }

  return (
    <div className="bg-slate-50 p-4 min-h-screen md:p-8">
      <div className="max-w-[900px] mx-auto">
        <div className="flex gap-8">
          {/* Main Content */}
          <div className="flex-1 space-y-8">
            
            {/* SECTION 1: Entrées essentielles (prioritaires) */}
            <div className="grid md:grid-cols-3 gap-6">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0 }}>

                <Card
                  className="cursor-pointer hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 bg-[#FF5F6D]/20 border-[#FF5F6D]/30"
                  onClick={() => navigate(createPageUrl('Library'))}>

                  <CardContent className="bg-red-50 p-8 text-center opacity-100">
                    <div className="w-20 h-20 mx-auto mb-4 flex items-center justify-center">
                      <FolderOpen className="h-16 w-16 text-[#FF5F6D]" />
                    </div>
                    <h3 className="text-xl font-bold text-[#FF5F6D] mb-3">MES GRILLES</h3>
                    <p className="text-sm text-slate-600">Toutes tes créations et projets regroupés en un seul endroit.</p>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}>

                <Card
                  className="cursor-pointer hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 bg-[#FF5F6D]/20 border-[#FF5F6D]/30"
                  onClick={() => navigate(createPageUrl('Creator'))}>

                  <CardContent className="p-8 text-center">
                    <div className="w-20 h-20 mx-auto mb-4 flex items-center justify-center">
                      <Wand2 className="h-16 w-16 text-[#FF5F6D]" />
                    </div>
                    <h3 className="text-xl font-bold text-[#FF5F6D] mb-3">CRÉER UNE GRILLE</h3>
                    <p className="text-sm text-slate-600">Génère une grille à partir d'une photo ou crée-la manuellement.</p>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}>

                <Card
                  className="cursor-pointer hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 bg-[#FF5F6D]/20 border-[#FF5F6D]/30"
                  onClick={() => navigate(createPageUrl('WorkSettings'))}>

                  <CardContent className="p-8 text-center">
                    <div className="w-20 h-20 mx-auto mb-4 flex items-center justify-center">
                      <Settings className="h-16 w-16 text-[#FF5F6D]" />
                    </div>
                    <h3 className="text-xl font-bold text-[#FF5F6D] mb-3">PARAMÈTRES DE TRAVAIL</h3>
                    <p className="text-sm text-slate-600">Configure ton environnement professionnel de broderie.</p>
                  </CardContent>
                </Card>
              </motion.div>
            </div>

            {/* SECTION 2: Mode Relax */}
            <div className="bg-neutral-50 p-6 rounded-2xl">
              <h2 className="text-2xl font-bold text-slate-800 mb-6 text-center">Mode Relax</h2>
              <div className="grid md:grid-cols-3 gap-4">
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.3 }}>

                  <Card
                    className="cursor-pointer hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
                    onClick={() => navigate(createPageUrl('RelaxMode'))}>

                    <CardContent className="p-6 text-center">
                      <div className="w-14 h-14 mx-auto mb-3 flex items-center justify-center">
                        <Flower2 className="h-12 w-12 text-[#FF5F6D]" />
                      </div>
                      <h3 className="text-lg font-bold text-[#FF5F6D] mb-2">Broderie Zen</h3>
                      <p className="text-xs text-slate-600">Brode virtuellement pour un moment de détente.</p>
                    </CardContent>
                  </Card>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.35 }}>

                  <Card
                    className="cursor-pointer hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
                    onClick={() => navigate(createPageUrl('RelaxMode'))}>

                    <CardContent className="p-6 text-center">
                      <div className="w-14 h-14 mx-auto mb-3 flex items-center justify-center">
                        <Gamepad2 className="h-12 w-12 text-[#FF5F6D]" />
                      </div>
                      <h3 className="text-lg font-bold text-[#FF5F6D] mb-2">Jeu Relax</h3>
                      <p className="text-xs text-slate-600">Complète des motifs simples sans pression.</p>
                    </CardContent>
                  </Card>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.4 }}>

                  <Card
                    className="cursor-pointer hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
                    onClick={() => navigate(createPageUrl('RelaxMode'))}>

                    <CardContent className="p-6 text-center">
                      <div className="w-14 h-14 mx-auto mb-3 flex items-center justify-center">
                        <Leaf className="h-12 w-12 text-[#FF5F6D]" />
                      </div>
                      <h3 className="text-lg font-bold text-[#FF5F6D] mb-2">Anti-Stress</h3>
                      <p className="text-xs text-slate-600">Un espace calme pour respirer et broder.</p>
                    </CardContent>
                  </Card>
                </motion.div>
              </div>
            </div>



            {/* Mode public - Call to action */}
            {!isAuthenticated &&
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
                <Card className="bg-gradient-to-r from-[#FF5F6D] to-[#FF7A85] text-white">
                  <CardContent className="p-8 text-center">
                    <h2 className="text-3xl font-bold mb-4">Créer mon compte gratuit</h2>
                    <p className="text-white/90 mb-6">Sauvegarde tes grilles, suis ta progression et accède à toutes les fonctionnalités</p>
                    <Button
                    size="lg"
                    className="bg-white text-[#FF5F6D] hover:bg-white/90"
                    onClick={() => base44.auth.redirectToLogin(window.location.pathname)}>

                      Créer mon compte gratuit
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            }
          </div>

          {/* Right Sidebar - Stats & Suggestions (authenticated only) */}
          {isAuthenticated &&
          <div className="w-64 space-y-4">
              {/* Suggestions Paty - EN PREMIER */}
              <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
                <Card className="bg-[#FF5F6D]/20 border-[#FF5F6D]/30">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-2">
                      <div className="w-8 h-8 rounded-full bg-[#FF5F6D] flex items-center justify-center flex-shrink-0">
                        <Sparkles className="h-4 w-4 text-white" />
                      </div>
                      <div>
                        <p className="text-xs font-semibold text-[#FF5F6D] mb-1">Paty suggère :</p>
                        <p className="text-xs text-slate-700">{patyMessages[Math.floor(Math.random() * patyMessages.length)]}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>

              {/* Stats rapides - BLOCS BLANCS */}
              <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.1 }}>
                <Card className="bg-white border-slate-200">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 mb-3">
                      <TrendingUp className="h-5 w-5 text-[#FF5F6D]" />
                      <Badge className="bg-[#FF5F6D]/20 text-[#FF5F6D] border-[#FF5F6D]/30">Ce mois</Badge>
                    </div>
                    <p className="text-2xl font-bold text-[#FF5F6D]">{stats.stitchesThisMonth}</p>
                    <p className="text-xs text-slate-600">Points brodés</p>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.15 }}>
                <Card className="bg-white border-slate-200">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 mb-3">
                      <Clock className="h-5 w-5 text-[#FF5F6D]" />
                      <Badge className="bg-[#FF5F6D]/20 text-[#FF5F6D] border-[#FF5F6D]/30">Total</Badge>
                    </div>
                    <p className="text-2xl font-bold text-[#FF5F6D]">{Math.round(stats.hoursTotal)}h</p>
                    <p className="text-xs text-slate-600">Heures brodées</p>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 }}>
                <Card className="bg-white border-slate-200">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 mb-3">
                      <Award className="h-5 w-5 text-[#FF5F6D]" />
                      <Badge className="bg-[#FF5F6D]/20 text-[#FF5F6D] border-[#FF5F6D]/30">Terminés</Badge>
                    </div>
                    <p className="text-2xl font-bold text-[#FF5F6D]">{stats.completedProjects}</p>
                    <p className="text-xs text-slate-600">Projets</p>
                  </CardContent>
                </Card>
              </motion.div>

              {/* Liens verticaux - SANS BLOC */}
              <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.25 }} className="space-y-2 pt-4">
                <button
                onClick={() => navigate(createPageUrl('GlobalRanking'))}
                className="w-full flex items-center gap-3 px-4 py-3 hover:bg-[#FF5F6D]/10 rounded-lg transition-all text-left">

                  <Trophy className="h-5 w-5 text-[#FF5F6D]" />
                  <span className="text-sm font-medium text-slate-700">Classement</span>
                </button>
                <button
                onClick={() => navigate(createPageUrl('Inspiration'))}
                className="w-full flex items-center gap-3 px-4 py-3 hover:bg-[#FF5F6D]/10 rounded-lg transition-all text-left">

                  <Lightbulb className="h-5 w-5 text-[#FF5F6D]" />
                  <span className="text-sm font-medium text-slate-700">Inspiration</span>
                </button>
                <button
                onClick={() => navigate(createPageUrl('Community'))}
                className="w-full flex items-center gap-3 px-4 py-3 hover:bg-[#FF5F6D]/10 rounded-lg transition-all text-left">

                  <Users className="h-5 w-5 text-[#FF5F6D]" />
                  <span className="text-sm font-medium text-slate-700">Communauté</span>
                </button>
                <button
                onClick={() => navigate(createPageUrl('Shop'))}
                className="w-full flex items-center gap-3 px-4 py-3 hover:bg-[#FF5F6D]/10 rounded-lg transition-all text-left">

                  <ShoppingBag className="h-5 w-5 text-[#FF5F6D]" />
                  <span className="text-sm font-medium text-slate-700">Boutique</span>
                </button>
              </motion.div>
            </div>
          }
        </div>
      </div>
    </div>);

}