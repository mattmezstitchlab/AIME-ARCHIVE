import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Heart, Music, Palette, Play } from 'lucide-react';
import { motion } from 'framer-motion';

export default function RelaxMode() {
  const relaxGames = [
    { title: 'Broderie Zen', description: 'Colorie des motifs simples pour te détendre', icon: Heart, gradient: 'from-[#FF5F6D] to-[#FF7A85]' },
    { title: 'Motifs automatiques', description: 'Laisse-toi guider par des patrons relaxants', icon: Palette, gradient: 'from-[#FF5F6D] to-[#FF7A85]' },
    { title: 'Ambiance musicale', description: 'Brode en écoutant des sons apaisants', icon: Music, gradient: 'from-[#FF5F6D] to-[#FF7A85]' }
  ];

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-[900px] mx-auto">
        <div className="mb-8 text-center">
          <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ duration: 0.5 }}>
            <h1 className="text-4xl font-bold text-slate-800 mb-2">Mode Relax</h1>
            <p className="text-slate-600">Détends-toi avec de la broderie numérique zen</p>
          </motion.div>
        </div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
          <Card className="bg-[#FF5F6D] text-white overflow-hidden relative">
            <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'repeating-linear-gradient(45deg, transparent, transparent 20px, rgba(255,255,255,0.1) 20px, rgba(255,255,255,0.1) 21px)' }} />
            <CardContent className="p-12 text-center relative z-10">
              <Heart className="h-16 w-16 mx-auto mb-4" />
              <h2 className="text-3xl font-bold mb-4">Bienvenue dans ton espace zen</h2>
              <p className="text-white/90 mb-6 max-w-2xl mx-auto">
                Prends une pause et détends-toi avec nos mini-jeux de broderie. 
                Pas de pression, pas de règles, juste du plaisir et de la relaxation.
              </p>
              <Button className="bg-white text-[#FF5F6D] hover:bg-white/90">
                <Play className="h-4 w-4 mr-2" />
                Commencer une session zen
              </Button>
            </CardContent>
          </Card>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-6 mb-8">
          {relaxGames.map((game, index) => {
            const Icon = game.icon;
            return (
              <motion.div key={index} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.15 }}>
                <Card className="hover:shadow-xl transition-all cursor-pointer h-full">
                  <CardContent className="p-6 text-center">
                    <div className={`w-16 h-16 rounded-full bg-gradient-to-br ${game.gradient} flex items-center justify-center mx-auto mb-4`}>
                      <Icon className="h-8 w-8 text-white" />
                    </div>
                    <h3 className="text-xl font-semibold text-slate-800 mb-2">{game.title}</h3>
                    <p className="text-slate-600 text-sm mb-4">{game.description}</p>
                    <Button variant="outline" className="w-full">Essayer</Button>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>

        <Card className="bg-[#FF5F6D]/10 border-[#FF5F6D]/20">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Heart className="h-6 w-6 text-[#FF5F6D]" />
              Ta progression relax
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center">
                <p className="text-3xl font-bold text-slate-800 mb-1">0</p>
                <p className="text-sm text-slate-600">Sessions zen</p>
              </div>
              <div className="text-center">
                <p className="text-3xl font-bold text-slate-800 mb-1">0 min</p>
                <p className="text-sm text-slate-600">Temps de relaxation</p>
              </div>
              <div className="text-center">
                <p className="text-3xl font-bold text-slate-800 mb-1">0</p>
                <p className="text-sm text-slate-600">Motifs complétés</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}