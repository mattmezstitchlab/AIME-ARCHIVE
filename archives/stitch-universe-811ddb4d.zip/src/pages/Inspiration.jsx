import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Youtube, Plus, Star, Play } from 'lucide-react';
import { motion } from 'framer-motion';

export default function Inspiration() {
  const [newChannelUrl, setNewChannelUrl] = useState('');

  const tutorials = [
    { title: 'Débuter le point de croix', channel: 'Broderie Passion', thumbnail: 'https://images.unsplash.com/photo-1600508774634-4e11d34730e2?w=400', level: 'Débutant', views: '125K' },
    { title: 'Ajouter des perles à ta broderie', channel: 'Atelier de Marie', thumbnail: 'https://images.unsplash.com/photo-1452860606245-08befc0ff44b?w=400', level: 'Intermédiaire', views: '89K' },
    { title: 'Points spéciaux avancés', channel: 'Pro Broderie', thumbnail: 'https://images.unsplash.com/photo-1515552726023-7125c8d07fb3?w=400', level: 'Expert', views: '67K' }
  ];

  const playlists = [
    { name: 'Collection Noël', count: 12, theme: 'Noël' },
    { name: 'Portraits réalistes', count: 8, theme: 'Portrait' },
    { name: 'Pixel Art', count: 15, theme: 'Pixel art' },
    { name: 'Nature & Animaux', count: 20, theme: 'Nature' }
  ];

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-[900px] mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-slate-800 mb-2">Inspiration & Tutoriels</h1>
          <p className="text-slate-600">Apprends de nouvelles techniques et trouve l'inspiration</p>
        </div>

        <Tabs defaultValue="tutorials" className="mb-8">
          <TabsList className="bg-slate-100 w-full">
            <TabsTrigger value="tutorials">Tutoriels</TabsTrigger>
            <TabsTrigger value="playlists">Playlists thématiques</TabsTrigger>
            <TabsTrigger value="paty">Sélection Paty</TabsTrigger>
            <TabsTrigger value="add">Ajouter une chaîne</TabsTrigger>
          </TabsList>

          <TabsContent value="tutorials" className="mt-6">
            <div className="flex gap-2 mb-6">
              <Badge variant="outline" className="cursor-pointer hover:bg-slate-100">Tous</Badge>
              <Badge variant="outline" className="cursor-pointer hover:bg-slate-100">Débutant</Badge>
              <Badge variant="outline" className="cursor-pointer hover:bg-slate-100">Intermédiaire</Badge>
              <Badge variant="outline" className="cursor-pointer hover:bg-slate-100">Expert</Badge>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              {tutorials.map((tutorial, index) => (
                <motion.div key={index} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.1 }}>
                  <Card className="hover:shadow-xl transition-all cursor-pointer group">
                    <div className="relative overflow-hidden rounded-t-lg">
                      <img src={tutorial.thumbnail} alt={tutorial.title} className="w-full h-48 object-cover group-hover:scale-105 transition-transform" />
                      <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <Play className="h-12 w-12 text-white" />
                      </div>
                      <Badge className="absolute top-3 right-3 bg-[#FF5F6D]">{tutorial.level}</Badge>
                    </div>
                    <CardContent className="p-4">
                      <h3 className="font-semibold text-slate-800 mb-2 line-clamp-2">{tutorial.title}</h3>
                      <div className="flex items-center justify-between text-sm text-slate-600">
                        <span className="flex items-center gap-1">
                          <Youtube className="h-4 w-4 text-red-500" />
                          {tutorial.channel}
                        </span>
                        <span>{tutorial.views} vues</span>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="playlists" className="mt-6">
            <div className="grid md:grid-cols-2 gap-6">
              {playlists.map((playlist, index) => (
                <motion.div key={index} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.1 }}>
                  <Card className="hover:shadow-xl transition-all cursor-pointer">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div>
                          <h3 className="font-semibold text-lg text-slate-800 mb-1">{playlist.name}</h3>
                          <p className="text-sm text-slate-600">{playlist.count} vidéos</p>
                        </div>
                        <Youtube className="h-8 w-8 text-red-500" />
                      </div>
                      <Badge variant="outline">{playlist.theme}</Badge>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="paty" className="mt-6">
            <Card className="bg-[#FF5F6D]/10 border-[#FF5F6D]/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Star className="h-6 w-6 text-[#FF5F6D]" />
                  Recommandations de Paty
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600">Paty sélectionne les meilleurs tutoriels pour toi en fonction de ton niveau et de tes projets en cours.</p>
                <div className="mt-4 p-4 bg-white rounded-lg">
                  <p className="text-sm text-slate-500">Fonctionnalité bientôt disponible</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="add" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Ajouter une chaîne YouTube</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">URL de la chaîne ou vidéo YouTube</label>
                  <Input placeholder="https://youtube.com/..." value={newChannelUrl} onChange={(e) => setNewChannelUrl(e.target.value)} />
                </div>
                <Button className="w-full bg-[#FF5F6D] hover:bg-[#FF7A85]">
                  <Plus className="h-4 w-4 mr-2" />
                  Ajouter à ma bibliothèque
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}