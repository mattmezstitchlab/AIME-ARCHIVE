import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { User } from 'lucide-react';
import { motion } from 'framer-motion';
import LoginPrompt from '../components/auth/LoginPrompt';

export default function Profile() {
  const [user, setUser] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(null);

  useEffect(() => {
    loadUserData();
  }, []);

  const loadUserData = async () => {
    try {
      const isAuth = await base44.auth.isAuthenticated();
      setIsAuthenticated(isAuth);
      
      if (!isAuth) {
        return;
      }

      const currentUser = await base44.auth.me();
      setUser(currentUser);
    } catch (error) {
      console.error('Erreur chargement profil:', error);
    }
  };

  if (isAuthenticated === null) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin h-8 w-8 border-4 border-[#FF5F6D] border-t-transparent rounded-full"></div>
      </div>
    );
  }

  if (isAuthenticated === false) {
    return (
      <div className="min-h-screen p-4 md:p-8">
        <div className="max-w-[900px] mx-auto">
          <LoginPrompt message="Connecte-toi pour voir ton profil !" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-[900px] mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-slate-800 mb-2">Profil</h1>
          <p className="text-slate-600">Tes informations personnelles</p>
        </div>

        {/* User Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <Card className="bg-[#FF5F6D]/10 border-[#FF5F6D]/20">
            <CardContent className="p-8">
              <div className="flex items-center gap-6">
                <div className="w-20 h-20 rounded-full bg-[#FF5F6D] flex items-center justify-center shadow-lg">
                  <User className="h-10 w-10 text-white" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-slate-800 mb-1">
                    {user?.full_name || 'Brodeuse anonyme'}
                  </h2>
                  <p className="text-slate-600">{user?.email || 'Non connecté'}</p>
                  <Badge className="mt-2 bg-[#FF5F6D]/20 text-[#FF5F6D] border-[#FF5F6D]/30">
                    Membre depuis {new Date(user?.created_date || Date.now()).toLocaleDateString('fr-FR', { month: 'long', year: 'numeric' })}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}