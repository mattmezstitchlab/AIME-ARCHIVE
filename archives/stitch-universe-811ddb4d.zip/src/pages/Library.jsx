import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Upload, Search, Filter, X, Grid3x3, List, Sparkles } from 'lucide-react';
import { createPageUrl } from '../utils';
import { motion, AnimatePresence } from 'framer-motion';
import BackButton from '../components/ui/BackButton';
import LoginPrompt from '../components/auth/LoginPrompt';
import AdvancedFilters from '../components/library/AdvancedFilters';
import SmartCollections from '../components/library/SmartCollections';
import PatternCard from '../components/library/PatternCard';
import PatternListItem from '../components/library/PatternListItem';
import PatternDetailModal from '../components/library/PatternDetailModal';

export default function Library() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [searchQuery, setSearchQuery] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(null);
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);
  const [viewMode, setViewMode] = useState('gallery');
  const [selectedPattern, setSelectedPattern] = useState(null);
  const [showPatternDetail, setShowPatternDetail] = useState(false);
  const [smartCollectionFilter, setSmartCollectionFilter] = useState(null);
  const [advancedFilters, setAdvancedFilters] = useState({
    themes: [],
    dateFilter: 'all',
    creators: [],
    sizePreset: 'all',
    stitchTypes: [],
    colorRange: 'all',
    beadsFilter: 'all',
    status: [],
    patyMode: 'all',
    tags: '',
    timeRange: 'all',
    difficulty: 'all'
  });

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    const auth = await base44.auth.isAuthenticated();
    setIsAuthenticated(auth);
  };

  const { data: patterns = [], isLoading } = useQuery({
    queryKey: ['patterns'],
    queryFn: async () => {
      const isAuth = await base44.auth.isAuthenticated();
      if (!isAuth) return [];
      return await base44.entities.Pattern.list('-last_opened');
    },
  });

  const deletePatternMutation = useMutation({
    mutationFn: (id) => base44.entities.Pattern.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['patterns'] }),
  });

  const handleImport = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    const isAuth = await base44.auth.isAuthenticated();
    if (!isAuth) {
      base44.auth.redirectToLogin(window.location.pathname);
      return;
    }

    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    await base44.entities.Pattern.create({
      name: file.name.replace(/\.[^/.]+$/, ''),
      source_type: file.type === 'application/pdf' ? 'pdf_imported' : 'image_imported',
      file_url: file_url,
      grid_width: 100,
      grid_height: 100,
      total_stitches: 0,
      last_opened: new Date().toISOString()
    });

    queryClient.invalidateQueries({ queryKey: ['patterns'] });
  };

  const openPattern = async (pattern) => {
    const isAuth = await base44.auth.isAuthenticated();
    if (!isAuth) {
      base44.auth.redirectToLogin(window.location.pathname);
      return;
    }

    await base44.entities.Pattern.update(pattern.id, {
      last_opened: new Date().toISOString()
    });

    navigate(createPageUrl('PatternReader') + `?id=${pattern.id}`);
  };

  const hasActiveFilters = () => {
    return advancedFilters.themes.length > 0 ||
           advancedFilters.dateFilter !== 'all' ||
           advancedFilters.creators.length > 0 ||
           advancedFilters.sizePreset !== 'all' ||
           advancedFilters.stitchTypes.length > 0 ||
           advancedFilters.colorRange !== 'all' ||
           advancedFilters.beadsFilter !== 'all' ||
           advancedFilters.status.length > 0 ||
           advancedFilters.patyMode !== 'all' ||
           advancedFilters.tags !== '' ||
           advancedFilters.timeRange !== 'all' ||
           advancedFilters.difficulty !== 'all';
  };

  const getActiveFilterCount = () => {
    let count = 0;
    if (advancedFilters.themes.length > 0) count++;
    if (advancedFilters.dateFilter !== 'all') count++;
    if (advancedFilters.creators.length > 0) count++;
    if (advancedFilters.sizePreset !== 'all') count++;
    if (advancedFilters.stitchTypes.length > 0) count++;
    if (advancedFilters.colorRange !== 'all') count++;
    if (advancedFilters.beadsFilter !== 'all') count++;
    if (advancedFilters.status.length > 0) count++;
    if (advancedFilters.patyMode !== 'all') count++;
    if (advancedFilters.tags !== '') count++;
    if (advancedFilters.timeRange !== 'all') count++;
    if (advancedFilters.difficulty !== 'all') count++;
    return count;
  };

  const filteredPatterns = patterns.filter(p => {
    if (smartCollectionFilter && !smartCollectionFilter.filter(p)) return false;

    const matchesSearch = searchQuery === '' || (
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (p.tags && p.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))) ||
      (p.theme && p.theme.some(t => t.toLowerCase().includes(searchQuery.toLowerCase()))) ||
      (p.creator_name && p.creator_name.toLowerCase().includes(searchQuery.toLowerCase()))
    );

    const matchesTheme = advancedFilters.themes.length === 0 || 
      (p.theme && advancedFilters.themes.some(t => p.theme.includes(t)));
    const matchesDate = advancedFilters.dateFilter === 'all' || (() => {
      if (!p.created_date) return true;
      const dayDiff = (new Date() - new Date(p.created_date)) / (1000 * 60 * 60 * 24);
      if (advancedFilters.dateFilter === 'today') return dayDiff < 1;
      if (advancedFilters.dateFilter === 'week') return dayDiff < 7;
      if (advancedFilters.dateFilter === 'month') return dayDiff < 30;
      if (advancedFilters.dateFilter === 'year') return dayDiff < 365;
      return true;
    })();
    const matchesCreator = advancedFilters.creators.length === 0 || advancedFilters.creators.includes(p.creator_type || 'me');
    const matchesSize = advancedFilters.sizePreset === 'all' || (() => {
      const size = Math.max(p.grid_width || 0, p.grid_height || 0);
      if (advancedFilters.sizePreset === 'small') return size < 80;
      if (advancedFilters.sizePreset === 'medium') return size >= 80 && size < 150;
      if (advancedFilters.sizePreset === 'large') return size >= 150 && size < 250;
      if (advancedFilters.sizePreset === 'xlarge') return size >= 250;
      return true;
    })();
    const matchesStitchType = advancedFilters.stitchTypes.length === 0 || 
      (p.stitch_types && advancedFilters.stitchTypes.some(t => p.stitch_types.includes(t)));
    const matchesColorRange = advancedFilters.colorRange === 'all' || (() => {
      const count = p.color_count || 0;
      if (advancedFilters.colorRange === '1-5') return count >= 1 && count <= 5;
      if (advancedFilters.colorRange === '6-20') return count >= 6 && count <= 20;
      if (advancedFilters.colorRange === '21-40') return count >= 21 && count <= 40;
      if (advancedFilters.colorRange === '40+') return count >= 40;
      return true;
    })();
    const matchesBeads = advancedFilters.beadsFilter === 'all' || 
      (advancedFilters.beadsFilter === 'with' && p.has_beads) ||
      (advancedFilters.beadsFilter === 'without' && !p.has_beads);
    const matchesStatus = advancedFilters.status.length === 0 || advancedFilters.status.includes(p.status || 'preparation');
    const matchesPatyMode = advancedFilters.patyMode === 'all' || 
      (advancedFilters.patyMode === 'paty' && p.created_by_paty) ||
      (advancedFilters.patyMode === 'manual' && !p.created_by_paty && p.source_type === 'generated') ||
      (advancedFilters.patyMode === 'imported' && (p.source_type === 'pdf_imported' || p.source_type === 'image_imported'));
    const matchesTags = advancedFilters.tags === '' || 
      (p.tags && p.tags.some(tag => tag.toLowerCase().includes(advancedFilters.tags.toLowerCase())));
    const matchesTimeRange = advancedFilters.timeRange === 'all' || (() => {
      const hours = p.estimated_hours || 0;
      if (advancedFilters.timeRange === '<5') return hours < 5;
      if (advancedFilters.timeRange === '5-20') return hours >= 5 && hours < 20;
      if (advancedFilters.timeRange === '20-50') return hours >= 20 && hours < 50;
      if (advancedFilters.timeRange === '50+') return hours >= 50;
      return true;
    })();
    const matchesDifficulty = advancedFilters.difficulty === 'all' || p.difficulty === advancedFilters.difficulty;

    return matchesSearch && matchesTheme && matchesDate && matchesCreator && matchesSize && 
           matchesStitchType && matchesColorRange && matchesBeads && matchesStatus && 
           matchesPatyMode && matchesTags && matchesTimeRange && matchesDifficulty;
  });

  const clearAllFilters = () => {
    setAdvancedFilters({
      themes: [], dateFilter: 'all', creators: [], sizePreset: 'all', stitchTypes: [],
      colorRange: 'all', beadsFilter: 'all', status: [], patyMode: 'all', tags: '',
      timeRange: 'all', difficulty: 'all'
    });
    setSmartCollectionFilter(null);
  };

  const handleSelectCollection = (collection) => {
    setSmartCollectionFilter(collection);
  };

  const handleShowDetails = (pattern) => {
    setSelectedPattern(pattern);
    setShowPatternDetail(true);
  };

  if (isAuthenticated === null) {
    return (
      <div className="min-h-screen flex items-center justify-center md:ml-64">
        <div className="animate-spin h-8 w-8 border-4 border-indigo-600 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  if (isAuthenticated === false) {
    return (
      <div className="min-h-screen p-4 md:p-8 md:ml-64">
        <LoginPrompt message="Connecte-toi pour accéder à ta bibliothèque de grilles et commencer à broder !" />
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-[900px] mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-slate-800 mb-2">Bibliothèque de grilles</h1>
          <p className="text-slate-600">Gère toutes tes grilles et projets de broderie</p>
        </div>

        {/* Menu de filtres rapides */}
        <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
          <Button
            variant={advancedFilters.status.length === 0 ? 'default' : 'outline'}
            size="sm"
            onClick={() => setAdvancedFilters({...advancedFilters, status: []})}
            className={advancedFilters.status.length === 0 ? 'bg-[#FF5F6D]' : ''}
          >
            Toutes
          </Button>
          <Button
            variant={advancedFilters.status.includes('in_progress') ? 'default' : 'outline'}
            size="sm"
            onClick={() => setAdvancedFilters({...advancedFilters, status: ['in_progress']})}
            className={advancedFilters.status.includes('in_progress') ? 'bg-[#FF5F6D]' : ''}
          >
            En cours
          </Button>
          <Button
            variant={advancedFilters.status.includes('completed') ? 'default' : 'outline'}
            size="sm"
            onClick={() => setAdvancedFilters({...advancedFilters, status: ['completed']})}
            className={advancedFilters.status.includes('completed') ? 'bg-[#FF5F6D]' : ''}
          >
            Terminées
          </Button>
          <Button
            variant={advancedFilters.status.includes('preparation') ? 'default' : 'outline'}
            size="sm"
            onClick={() => setAdvancedFilters({...advancedFilters, status: ['preparation']})}
            className={advancedFilters.status.includes('preparation') ? 'bg-[#FF5F6D]' : ''}
          >
            Préparation
          </Button>
          <Button
            variant={advancedFilters.status.includes('never_started') ? 'default' : 'outline'}
            size="sm"
            onClick={() => setAdvancedFilters({...advancedFilters, status: ['never_started']})}
            className={advancedFilters.status.includes('never_started') ? 'bg-[#FF5F6D]' : ''}
          >
            Jamais commencées
          </Button>
          <Button
            variant={advancedFilters.beadsFilter === 'with' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setAdvancedFilters({...advancedFilters, beadsFilter: advancedFilters.beadsFilter === 'with' ? 'all' : 'with'})}
            className={advancedFilters.beadsFilter === 'with' ? 'bg-[#FF5F6D]' : ''}
          >
            Perles
          </Button>
          <Button
            variant={advancedFilters.stitchTypes.includes('special') ? 'default' : 'outline'}
            size="sm"
            onClick={() => setAdvancedFilters({
              ...advancedFilters, 
              stitchTypes: advancedFilters.stitchTypes.includes('special') ? [] : ['special']
            })}
            className={advancedFilters.stitchTypes.includes('special') ? 'bg-[#FF5F6D]' : ''}
          >
            Points spéciaux
          </Button>
        </div>

        <div className="flex flex-col lg:flex-row gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
            <Input
              placeholder="Rechercher par nom, thème, tags, créateur..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>

          <div className="flex flex-wrap gap-2">
            <Button onClick={() => setShowAdvancedFilters(true)} variant="outline" className="relative">
              <Filter className="h-4 w-4 mr-2" />
              Filtrer
              {hasActiveFilters() && (
                <Badge className="ml-2 bg-fuchsia-500 text-white">{getActiveFilterCount()}</Badge>
              )}
            </Button>

            <div className="flex gap-1 border rounded-lg p-1">
              <Button
                variant={viewMode === 'gallery' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('gallery')}
                className={viewMode === 'gallery' ? 'bg-fuchsia-600' : ''}
              >
                <Grid3x3 className="h-4 w-4" />
              </Button>
              <Button
                variant={viewMode === 'list' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('list')}
                className={viewMode === 'list' ? 'bg-fuchsia-600' : ''}
              >
                <List className="h-4 w-4" />
              </Button>
            </div>

            <label htmlFor="file-upload">
              <Button className="bg-gradient-to-r from-indigo-600 to-indigo-700 cursor-pointer">
                <Upload className="h-4 w-4 mr-2" />
                Importer
              </Button>
              <input id="file-upload" type="file" accept=".pdf,.jpg,.jpeg,.png" onChange={handleImport} className="hidden" />
            </label>

            <Button variant="outline" className="bg-gradient-to-r from-purple-50 to-fuchsia-50">
              <Sparkles className="h-4 w-4 mr-2 text-fuchsia-600" />
              Organiser avec Paty
            </Button>
          </div>
        </div>

        <SmartCollections patterns={patterns} onSelectCollection={handleSelectCollection} />

        {(hasActiveFilters() || smartCollectionFilter) && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6 p-4 bg-fuchsia-50 border border-fuchsia-200 rounded-lg flex items-center justify-between"
          >
            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4 text-fuchsia-600" />
              <span className="text-sm font-medium text-fuchsia-900">
                {smartCollectionFilter ? `Collection : ${smartCollectionFilter.name}` : `Filtres actifs : ${getActiveFilterCount()}`}
              </span>
            </div>
            <Button variant="ghost" size="sm" onClick={clearAllFilters} className="text-fuchsia-600 hover:text-fuchsia-700 hover:bg-fuchsia-100">
              <X className="h-4 w-4 mr-1" />
              Effacer les filtres
            </Button>
          </motion.div>
        )}

        <AnimatePresence mode="popLayout">
          {isLoading ? (
            <div className="text-center py-12">
              <div className="animate-spin h-8 w-8 border-4 border-indigo-600 border-t-transparent rounded-full mx-auto"></div>
            </div>
          ) : filteredPatterns.length === 0 ? (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center py-16">
              <Search className="h-16 w-16 text-slate-300 mx-auto mb-4" />
              <p className="text-slate-500 text-lg">Aucune grille trouvée</p>
              <p className="text-slate-400 text-sm mt-2">
                {patterns.length === 0 ? "Importe ta première grille pour commencer" : "Essaie de modifier tes filtres de recherche"}
              </p>
            </motion.div>
          ) : viewMode === 'gallery' ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredPatterns.map((pattern, index) => (
                <motion.div key={pattern.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, scale: 0.9 }} transition={{ delay: index * 0.05 }}>
                  <PatternCard pattern={pattern} onOpen={openPattern} onShowDetails={handleShowDetails} />
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="space-y-2">
              {filteredPatterns.map((pattern, index) => (
                <motion.div key={pattern.id} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} transition={{ delay: index * 0.03 }}>
                  <PatternListItem pattern={pattern} onOpen={openPattern} onShowDetails={handleShowDetails} />
                </motion.div>
              ))}
            </div>
          )}
        </AnimatePresence>

        <AdvancedFilters
          isOpen={showAdvancedFilters}
          onClose={() => setShowAdvancedFilters(false)}
          filters={advancedFilters}
          onFiltersChange={setAdvancedFilters}
          onApply={() => setShowAdvancedFilters(false)}
          onReset={clearAllFilters}
        />

        <PatternDetailModal
          pattern={selectedPattern}
          isOpen={showPatternDetail}
          onClose={() => {
            setShowPatternDetail(false);
            setSelectedPattern(null);
          }}
          onUpdate={() => queryClient.invalidateQueries({ queryKey: ['patterns'] })}
          onDelete={(id) => deletePatternMutation.mutate(id)}
          onOpen={openPattern}
        />
      </div>
    </div>
  );
}