import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  ZoomIn, ZoomOut, Undo, ArrowLeft, Sun, Moon, 
  CheckCircle2, Circle, Pin
} from 'lucide-react';
import { createPageUrl } from '../utils';
import BackButton from '../components/ui/BackButton';
import GridViewer from '../components/pattern/GridViewer';
import LegendPanel from '../components/pattern/LegendPanel';
import StatsBar from '../components/pattern/StatsBar';

export default function PatternReader() {
  const navigate = useNavigate();
  const [pattern, setPattern] = useState(null);
  const [progress, setProgress] = useState(null);
  const [zoom, setZoom] = useState(1);
  const [darkMode, setDarkMode] = useState(false);
  const [highlightMode, setHighlightMode] = useState(true);
  const [selectedSymbol, setSelectedSymbol] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadPattern();
  }, []);

  const loadPattern = async () => {
    const params = new URLSearchParams(window.location.search);
    const patternId = params.get('id');
    
    if (!patternId) {
      navigate(createPageUrl('Library'));
      return;
    }

    try {
      const isAuth = await base44.auth.isAuthenticated();
      if (!isAuth) {
        base44.auth.redirectToLogin(window.location.pathname);
        return;
      }

      const patterns = await base44.entities.Pattern.filter({ id: patternId });
      if (patterns.length === 0) {
        navigate(createPageUrl('Library'));
        return;
      }

      const loadedPattern = patterns[0];
      setPattern(loadedPattern);

      const progressList = await base44.entities.StitchProgress.filter({ pattern_id: patternId });
      if (progressList.length > 0) {
        setProgress(progressList[0]);
      } else {
        const newProgress = await base44.entities.StitchProgress.create({
          pattern_id: patternId,
          stitches_completed: [],
          parked_threads: [],
          stitches_today: 0,
          total_time_minutes: 0,
          last_session_date: new Date().toISOString().split('T')[0]
        });
        setProgress(newProgress);
      }
    } catch (error) {
      console.error('Erreur chargement:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleStitchToggle = async (x, y, symbol) => {
    if (!progress) return;

    try {
      const stitches = progress.stitches_completed || [];
    const existingIndex = stitches.findIndex(s => s.x === x && s.y === y);

    let newStitches;
    if (existingIndex >= 0) {
      newStitches = stitches.filter((_, i) => i !== existingIndex);
    } else {
      newStitches = [...stitches, { x, y, symbol, completed_at: new Date().toISOString() }];
    }

    const completionPercentage = (newStitches.length / pattern.total_stitches) * 100;

    await base44.entities.StitchProgress.update(progress.id, {
      stitches_completed: newStitches,
      stitches_today: progress.stitches_today + (existingIndex >= 0 ? -1 : 1)
    });

    await base44.entities.Pattern.update(pattern.id, {
      completed_stitches: newStitches.length,
      completion_percentage: completionPercentage,
      is_completed: completionPercentage >= 100
    });

      setProgress({ ...progress, stitches_completed: newStitches });
      setPattern({ 
        ...pattern, 
        completed_stitches: newStitches.length,
        completion_percentage: completionPercentage 
      });
    } catch (error) {
      console.error('Erreur mise à jour:', error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center md:ml-64">
        <div className="animate-spin h-12 w-12 border-4 border-indigo-600 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  if (!pattern) return null;

  return (
    <div className={`min-h-screen md:ml-64 ${darkMode ? 'bg-slate-900' : 'bg-slate-50'}`}>
      {/* Top Bar */}
      <div className={`sticky top-0 z-40 ${darkMode ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200'} border-b`}>
        <div className="px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate(createPageUrl('Library'))}
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className={`font-semibold ${darkMode ? 'text-white' : 'text-slate-800'}`}>
                {pattern.name}
              </h1>
              <p className={`text-sm ${darkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                {Math.round(pattern.completion_percentage || 0)}% complété
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="icon"
              onClick={() => setZoom(Math.max(0.5, zoom - 0.25))}
            >
              <ZoomOut className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="icon"
              onClick={() => setZoom(Math.min(3, zoom + 0.25))}
            >
              <ZoomIn className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="icon"
              onClick={() => setDarkMode(!darkMode)}
            >
              {darkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </Button>
          </div>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row h-[calc(100vh-73px)]">
        {/* Main Grid Area */}
        <div className="flex-1 overflow-auto p-4">
          <GridViewer
            pattern={pattern}
            progress={progress}
            zoom={zoom}
            darkMode={darkMode}
            selectedSymbol={selectedSymbol}
            highlightMode={highlightMode}
            onStitchToggle={handleStitchToggle}
          />
        </div>

        {/* Sidebar */}
        <div className={`lg:w-80 ${darkMode ? 'bg-slate-800' : 'bg-white'} border-l ${darkMode ? 'border-slate-700' : 'border-slate-200'} overflow-auto`}>
          <StatsBar 
            pattern={pattern} 
            progress={progress} 
            darkMode={darkMode}
          />
          
          <LegendPanel
            pattern={pattern}
            progress={progress}
            darkMode={darkMode}
            selectedSymbol={selectedSymbol}
            onSymbolSelect={setSelectedSymbol}
          />
        </div>
      </div>
    </div>
  );
}