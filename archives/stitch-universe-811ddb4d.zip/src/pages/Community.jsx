import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Heart, MessageCircle, Share2, Trophy, Users } from 'lucide-react';
import { motion } from 'framer-motion';

export default function Community() {
  const projects = [
    { user: 'Marie L.', country: '🇫🇷', title: 'Portrait de chat terminé !', image: 'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=600', likes: 342, comments: 28, theme: 'Animal' },
    { user: 'Sophie M.', country: '🇧🇪', title: 'Paysage de montagne', image: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=600', likes: 289, comments: 19, theme: 'Paysage' },
    { user: 'Claire D.', country: '🇨🇭', title: 'Ma première grille avec perles', image: 'https://images.unsplash.com/photo-1515552726023-7125c8d07fb3?w=600', likes: 198, comments: 15, theme: 'Abstrait' }
  ];

  const challenges = [
    { name: 'Défi du mois : Noël', participants: 1247, endDate: '31 décembre', prize: 'Badge "Maître de Noël"' },
    { name: 'Projet géant collectif', participants: 3892, endDate: '15 janvier', prize: 'Badge "Bâtisseur"' }
  ];

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-[900px] mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-slate-800 mb-2">Communauté</h1>
          <p className="text-slate-600">Partage tes créations et découvre celles des autres</p>
        </div>

        <Tabs defaultValue="gallery" className="mb-8">
          <TabsList className="bg-slate-100 w-full">
            <TabsTrigger value="gallery">Galerie</TabsTrigger>
            <TabsTrigger value="challenges">Défis collectifs</TabsTrigger>
            <TabsTrigger value="share">Partager</TabsTrigger>
          </TabsList>

          <TabsContent value="gallery" className="mt-6">
            <div className="flex gap-2 mb-6 flex-wrap">
              <Badge variant="outline" className="cursor-pointer hover:bg-slate-100">Tous</Badge>
              <Badge variant="outline" className="cursor-pointer hover:bg-slate-100">Portrait</Badge>
              <Badge variant="outline" className="cursor-pointer hover:bg-slate-100">Animal</Badge>
              <Badge variant="outline" className="cursor-pointer hover:bg-slate-100">Paysage</Badge>
              <Badge variant="outline" className="cursor-pointer hover:bg-slate-100">Noël</Badge>
              <Badge variant="outline" className="cursor-pointer hover:bg-slate-100">Populaire</Badge>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              {projects.map((project, index) => (
                <motion.div key={index} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.1 }}>
                  <Card className="hover:shadow-xl transition-all overflow-hidden">
                    <div className="relative">
                      <img src={project.image} alt={project.title} className="w-full h-64 object-cover" />
                      <Badge className="absolute top-3 right-3 bg-[#FF5F6D]">{project.theme}</Badge>
                    </div>
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="font-semibold text-slate-800">{project.user}</span>
                        <span className="text-xl">{project.country}</span>
                      </div>
                      <p className="text-slate-700 mb-3">{project.title}</p>
                      <div className="flex items-center gap-4 text-sm text-slate-600">
                        <button className="flex items-center gap-1 hover:text-red-500 transition-colors">
                          <Heart className="h-4 w-4" />
                          {project.likes}
                        </button>
                        <button className="flex items-center gap-1 hover:text-blue-500 transition-colors">
                          <MessageCircle className="h-4 w-4" />
                          {project.comments}
                        </button>
                        <button className="flex items-center gap-1 hover:text-green-500 transition-colors">
                          <Share2 className="h-4 w-4" />
                        </button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="challenges" className="mt-6">
            <div className="space-y-6">
              {challenges.map((challenge, index) => (
                <motion.div key={index} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.1 }}>
                  <Card className="bg-[#FF5F6D]/10 border-[#FF5F6D]/20">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div>
                          <h3 className="text-xl font-bold text-slate-800 mb-2">{challenge.name}</h3>
                          <div className="flex items-center gap-4 text-sm text-slate-600">
                            <span className="flex items-center gap-1">
                              <Users className="h-4 w-4" />
                              {challenge.participants.toLocaleString()} participants
                            </span>
                            <span>Se termine le {challenge.endDate}</span>
                          </div>
                        </div>
                        <Trophy className="h-10 w-10 text-[#FF5F6D]" />
                      </div>
                      <div className="flex items-center justify-between">
                        <Badge className="bg-[#FF5F6D]/20 text-[#FF5F6D] border-[#FF5F6D]/30">{challenge.prize}</Badge>
                        <Button className="bg-[#FF5F6D] hover:bg-[#FF7A85]">Participer</Button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="share" className="mt-6">
            <Card>
              <CardContent className="p-12 text-center">
                <Share2 className="h-16 w-16 text-slate-300 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-slate-800 mb-2">Partage tes créations</h3>
                <p className="text-slate-600 mb-6">Montre tes projets terminés à la communauté</p>
                <Button className="bg-[#FF5F6D] hover:bg-[#FF7A85]">Partager un projet</Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}