import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { createPageUrl } from '../utils';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Slider } from '@/components/ui/slider';
import { Palette, Grid3x3, Plus, Trash2, Save, Sparkles, Square, Lightbulb, Eye, Target, Zap, Heart } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const DEFAULT_DMC_COLORS = [
  { code: '310', name: 'Noir / Black', color_hex: '#000000' },
  { code: '321', name: 'Rouge / Red', color_hex: '#C72B3B' },
  { code: '666', name: 'Rouge vif / Bright Red', color_hex: '#E31A1C' },
  { code: '740', name: 'Orange vif / Bright Orange', color_hex: '#FF6A00' },
  { code: '798', name: 'Bleu / Blue', color_hex: '#1C4F9C' },
  { code: 'B5200', name: 'Blanc / White', color_hex: '#FFFFFF' },
  { code: '413', name: 'Gris foncé / Dark Grey', color_hex: '#4A4A4A' },
  { code: '3371', name: 'Marron / Brown', color_hex: '#5B3A29' },
  { code: '725', name: 'Jaune / Yellow', color_hex: '#FFD900' }
];

const STITCH_TYPES = [
  { key: 'full_cross_enabled', label: 'Croix pleine', description: 'Le point de croix standard' },
  { key: 'half_stitch_enabled', label: 'Demi-point', description: 'Point sur la moitié de la case' },
  { key: 'quarter_stitch_enabled', label: 'Quart de point', description: 'Point sur un quart de la case' },
  { key: 'backstitch_enabled', label: 'Point arrière (backstitch)', description: 'Trait de contour' },
  { key: 'special_stitches_enabled', label: 'Points spéciaux', description: 'Points décoratifs' }
];

const BEAD_SYMBOLS = [
  { value: 'O', label: 'O (cercle)' },
  { value: '◇', label: '◇ (losange)' },
  { value: '⬤', label: '⬤ (rond plein)' },
  { value: '*', label: '* (étoile)' }
];

export default function WorkSettings() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('dmc');
  const [isAuthenticated, setIsAuthenticated] = useState(null);
  
  // DMC States
  const [colors, setColors] = useState([]);
  const [editingId, setEditingId] = useState(null);
  const [editingData, setEditingData] = useState({});
  const [newCode, setNewCode] = useState('');
  const [newName, setNewName] = useState('');
  const [newColorHex, setNewColorHex] = useState('#000000');
  
  // Stitch Settings States
  const [stitchSettings, setStitchSettings] = useState({
    full_cross_enabled: true,
    half_stitch_enabled: false,
    quarter_stitch_enabled: false,
    backstitch_enabled: false,
    special_stitches_enabled: false,
    beads_enabled: false,
    bead_symbol: 'O',
    bead_color: '#FFD700',
    highlight_special_stitches: true,
    highlight_beads: true,
    show_bead_counter: true
  });
  const [settingsId, setSettingsId] = useState(null);

  // Appearance Settings States
  const [appearanceSettings, setAppearanceSettings] = useState({
    symbol_size: 50,
    symbol_style: 'classic',
    contrast_level: 'normal',
    grid_background: 'white',
    grid_line_thickness: 'medium',
    grid_line_color: '#cbd5e1',
    show_1x1_grid: true,
    show_10x10_lines: true,
    grid_10x10_style: 'thin',
    initial_zoom: 100,
    smart_zoom_enabled: false,
    auto_center_enabled: false,
    colorblind_protanopia: false,
    colorblind_deuteranopia: false,
    colorblind_tritanopia: false,
    dark_mode_enabled: false,
    dark_mode_symbols: false
  });

  // Comfort Settings States
  const [comfortSettings, setComfortSettings] = useState({
    auto_highlight_color: true,
    shadow_unworked_zones: false,
    halo_selected_cell: true,
    highlight_special_stitches: true,
    highlight_beads: true,
    highlight_intensity: 70,
    show_stitch_counter: true,
    show_color_summary: true,
    show_stitch_type_summary: false,
    auto_mark_completed: true,
    play_click_sound: false,
    enable_paty_tips: true,
    enable_paty_corrections: true,
    show_tooltips: true,
    enable_voice_explanations: false,
    focus_mode_darken: false,
    focus_mode_row: false,
    focus_mode_column: false,
    validation_animation: 'discreet',
    wellness_timer_enabled: false,
    breathing_mode_enabled: false,
    paty_wellness_tips: true
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const isAuth = await base44.auth.isAuthenticated();
    setIsAuthenticated(isAuth);
    await loadColors();
    await loadStitchSettings();
    await loadAppearanceSettings();
    await loadComfortSettings();
  };

  const loadColors = async () => {
    try {
      if (isAuthenticated) {
        const dbColors = await base44.entities.DMCColor.list();
        if (dbColors.length === 0) {
          for (const color of DEFAULT_DMC_COLORS) {
            await base44.entities.DMCColor.create(color);
          }
          const freshColors = await base44.entities.DMCColor.list();
          setColors(freshColors);
        } else {
          setColors(dbColors);
        }
      } else {
        const localColors = localStorage.getItem('paticroix_dmc_colors');
        if (localColors) {
          setColors(JSON.parse(localColors));
        } else {
          localStorage.setItem('paticroix_dmc_colors', JSON.stringify(DEFAULT_DMC_COLORS));
          setColors(DEFAULT_DMC_COLORS);
        }
      }
    } catch (error) {
      console.error('Erreur chargement couleurs:', error);
    }
  };

  const loadStitchSettings = async () => {
    try {
      if (isAuthenticated) {
        const dbSettings = await base44.entities.StitchSettings.list();
        if (dbSettings.length > 0) {
          setStitchSettings(dbSettings[0]);
          setSettingsId(dbSettings[0].id);
        } else {
          const created = await base44.entities.StitchSettings.create(stitchSettings);
          setSettingsId(created.id);
        }
      } else {
        const localSettings = localStorage.getItem('paticroix_stitch_settings');
        if (localSettings) {
          setStitchSettings(JSON.parse(localSettings));
        }
      }
    } catch (error) {
      console.error('Erreur chargement paramètres:', error);
    }
  };

  const handleAddColor = async () => {
    if (!newCode.trim()) {
      alert('Le code DMC est requis');
      return;
    }

    const newColor = {
      code: newCode.trim(),
      name: newName.trim() || 'Sans nom',
      color_hex: newColorHex
    };

    try {
      if (isAuthenticated) {
        const created = await base44.entities.DMCColor.create(newColor);
        setColors([...colors, created]);
      } else {
        const id = Date.now().toString();
        const colorWithId = { ...newColor, id };
        const newColors = [...colors, colorWithId];
        setColors(newColors);
        localStorage.setItem('paticroix_dmc_colors', JSON.stringify(newColors));
      }
      setNewCode('');
      setNewName('');
      setNewColorHex('#000000');
    } catch (error) {
      console.error('Erreur ajout couleur:', error);
    }
  };

  const handleEditColor = (color) => {
    setEditingId(color.id);
    setEditingData({ code: color.code, name: color.name, color_hex: color.color_hex });
  };

  const handleSaveEdit = async (colorId) => {
    try {
      if (isAuthenticated) {
        await base44.entities.DMCColor.update(colorId, editingData);
        setColors(colors.map(c => c.id === colorId ? { ...c, ...editingData } : c));
      } else {
        const newColors = colors.map(c => c.id === colorId ? { ...c, ...editingData } : c);
        setColors(newColors);
        localStorage.setItem('paticroix_dmc_colors', JSON.stringify(newColors));
      }
      setEditingId(null);
      setEditingData({});
    } catch (error) {
      console.error('Erreur modification:', error);
    }
  };

  const handleDeleteColor = async (colorId) => {
    if (!confirm('Supprimer cette couleur DMC ?')) return;
    try {
      if (isAuthenticated) {
        await base44.entities.DMCColor.delete(colorId);
        setColors(colors.filter(c => c.id !== colorId));
      } else {
        const newColors = colors.filter(c => c.id !== colorId);
        setColors(newColors);
        localStorage.setItem('paticroix_dmc_colors', JSON.stringify(newColors));
      }
    } catch (error) {
      console.error('Erreur suppression:', error);
    }
  };

  const updateStitchSetting = async (key, value) => {
    const newSettings = { ...stitchSettings, [key]: value };
    setStitchSettings(newSettings);

    try {
      if (isAuthenticated && settingsId) {
        await base44.entities.StitchSettings.update(settingsId, { [key]: value });
      } else {
        localStorage.setItem('paticroix_stitch_settings', JSON.stringify(newSettings));
      }
    } catch (error) {
      console.error('Erreur mise à jour:', error);
    }
  };

  const loadAppearanceSettings = async () => {
    try {
      const saved = localStorage.getItem('paty_grid_appearance');
      if (saved) {
        setAppearanceSettings(JSON.parse(saved));
      }
    } catch (error) {
      console.error('Erreur chargement apparence:', error);
    }
  };

  const updateAppearanceSetting = (key, value) => {
    const newSettings = { ...appearanceSettings, [key]: value };
    setAppearanceSettings(newSettings);
    localStorage.setItem('paty_grid_appearance', JSON.stringify(newSettings));
  };

  const loadComfortSettings = async () => {
    try {
      const saved = localStorage.getItem('paty_comfort_settings');
      if (saved) {
        setComfortSettings(JSON.parse(saved));
      }
    } catch (error) {
      console.error('Erreur chargement confort:', error);
    }
  };

  const updateComfortSetting = (key, value) => {
    const newSettings = { ...comfortSettings, [key]: value };
    setComfortSettings(newSettings);
    localStorage.setItem('paty_comfort_settings', JSON.stringify(newSettings));
  };

  const tabs = [
    { id: 'dmc', label: 'Couleurs DMC', icon: Palette },
    { id: 'stitches', label: 'Types de points', icon: Grid3x3 },
    { id: 'appearance', label: 'Apparence de la grille', icon: Square },
    { id: 'comfort', label: 'Confort & aide', icon: Lightbulb }
  ];

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-[900px] mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-slate-800 mb-2">Paramètres de travail</h1>
          <p className="text-slate-600">Configure ton environnement de broderie</p>
        </div>

        {/* Horizontal Tabs Menu */}
        <div className="flex gap-2 mb-8 border-b border-slate-200 overflow-x-auto">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-6 py-3 font-medium transition-all border-b-2 whitespace-nowrap ${
                  activeTab === tab.id
                    ? 'text-[#FF5F6D] border-[#FF5F6D]'
                    : 'text-slate-600 border-transparent hover:text-slate-800'
                }`}
              >
                <Icon className="h-5 w-5" />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Tab Content */}
        <AnimatePresence mode="wait">
          {activeTab === 'dmc' && (
            <motion.div
              key="dmc"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-6"
            >
              {/* Colors Table */}
              <Card className="shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Palette className="h-5 w-5 text-[#FF5F6D]" />
                    Couleurs DMC
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-slate-50">
                          <TableHead className="font-semibold">Code</TableHead>
                          <TableHead className="font-semibold">Nom</TableHead>
                          <TableHead className="font-semibold">Couleur</TableHead>
                          <TableHead className="font-semibold text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {colors.map((color, index) => (
                          <motion.tr
                            key={color.id || index}
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            className="border-b hover:bg-slate-50"
                          >
                            <TableCell>
                              {editingId === color.id ? (
                                <Input
                                  value={editingData.code}
                                  onChange={(e) => setEditingData({ ...editingData, code: e.target.value })}
                                  className="w-24"
                                />
                              ) : (
                                <span className="font-mono font-semibold">{color.code}</span>
                              )}
                            </TableCell>
                            <TableCell>
                              {editingId === color.id ? (
                                <Input
                                  value={editingData.name}
                                  onChange={(e) => setEditingData({ ...editingData, name: e.target.value })}
                                />
                              ) : (
                                <span>{color.name}</span>
                              )}
                            </TableCell>
                            <TableCell>
                              {editingId === color.id ? (
                                <div className="flex items-center gap-2">
                                  <input
                                    type="color"
                                    value={editingData.color_hex}
                                    onChange={(e) => setEditingData({ ...editingData, color_hex: e.target.value })}
                                    className="w-12 h-8 rounded border cursor-pointer"
                                  />
                                  <Input
                                    value={editingData.color_hex}
                                    onChange={(e) => setEditingData({ ...editingData, color_hex: e.target.value })}
                                    className="w-24 font-mono text-sm"
                                  />
                                </div>
                              ) : (
                                <div className="flex items-center gap-2">
                                  <div className="w-8 h-8 rounded border-2" style={{ backgroundColor: color.color_hex }} />
                                  <span className="font-mono text-sm">{color.color_hex}</span>
                                </div>
                              )}
                            </TableCell>
                            <TableCell className="text-right">
                              {editingId === color.id ? (
                                <div className="flex items-center justify-end gap-2">
                                  <Button size="sm" onClick={() => handleSaveEdit(color.id)} className="bg-[#FF5F6D] hover:bg-[#FF7A85]">
                                    <Save className="h-4 w-4 mr-1" />
                                    Sauvegarder
                                  </Button>
                                  <Button size="sm" variant="outline" onClick={() => setEditingId(null)}>
                                    Annuler
                                  </Button>
                                </div>
                              ) : (
                                <div className="flex items-center justify-end gap-2">
                                  <Button size="sm" variant="outline" onClick={() => handleEditColor(color)}>
                                    Modifier
                                  </Button>
                                  <Button size="sm" variant="ghost" onClick={() => handleDeleteColor(color.id)} className="text-red-600">
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </div>
                              )}
                            </TableCell>
                          </motion.tr>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>

              {/* Add New Color */}
              <Card className="shadow-lg bg-[#FF5F6D]/5">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Plus className="h-5 w-5 text-[#FF5F6D]" />
                    Ajouter une couleur
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-3 gap-4 mb-4">
                    <div className="space-y-2">
                      <Label>Code DMC</Label>
                      <Input placeholder="ex: 413" value={newCode} onChange={(e) => setNewCode(e.target.value)} className="bg-white" />
                    </div>
                    <div className="space-y-2">
                      <Label>Nom</Label>
                      <Input placeholder="ex: Gris foncé" value={newName} onChange={(e) => setNewName(e.target.value)} className="bg-white" />
                    </div>
                    <div className="space-y-2">
                      <Label>Couleur</Label>
                      <div className="flex gap-2">
                        <input type="color" value={newColorHex} onChange={(e) => setNewColorHex(e.target.value)} className="w-14 h-10 rounded border-2 cursor-pointer" />
                        <Input value={newColorHex} onChange={(e) => setNewColorHex(e.target.value)} className="font-mono bg-white" />
                      </div>
                    </div>
                  </div>
                  <Button onClick={handleAddColor} className="w-full bg-[#FF5F6D] hover:bg-[#FF7A85]">
                    <Plus className="h-5 w-5 mr-2" />
                    Ajouter
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          )}

          {activeTab === 'stitches' && (
            <motion.div
              key="stitches"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-6"
            >
              {/* Stitch Types */}
              <Card className="shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Grid3x3 className="h-5 w-5 text-[#FF5F6D]" />
                    Types de points
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {STITCH_TYPES.map((type, index) => (
                    <div key={type.key} className="flex items-center justify-between p-4 rounded-lg bg-slate-50">
                      <div>
                        <Label className="text-base font-semibold">{type.label}</Label>
                        <p className="text-sm text-slate-600">{type.description}</p>
                      </div>
                      <Switch checked={stitchSettings[type.key]} onCheckedChange={(checked) => updateStitchSetting(type.key, checked)} />
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Beads */}
              <Card className="shadow-lg bg-amber-50 border-amber-200">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Sparkles className="h-5 w-5 text-amber-600" />
                    Perles
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between p-4 rounded-lg bg-white">
                    <Label className="font-semibold">Activer les perles</Label>
                    <Switch checked={stitchSettings.beads_enabled} onCheckedChange={(checked) => updateStitchSetting('beads_enabled', checked)} />
                  </div>

                  {stitchSettings.beads_enabled && (
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4 pl-4 border-l-4 border-amber-300">
                      <div className="space-y-2">
                        <Label>Symbole des perles</Label>
                        <Select value={stitchSettings.bead_symbol} onValueChange={(value) => updateStitchSetting('bead_symbol', value)}>
                          <SelectTrigger className="bg-white">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {BEAD_SYMBOLS.map((symbol) => (
                              <SelectItem key={symbol.value} value={symbol.value}>{symbol.label}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>Couleur d'affichage</Label>
                        <div className="flex gap-2">
                          <input type="color" value={stitchSettings.bead_color} onChange={(e) => updateStitchSetting('bead_color', e.target.value)} className="w-16 h-10 rounded border-2 cursor-pointer" />
                          <div className="flex-1 flex items-center px-4 rounded border-2 bg-white">
                            <span className="font-mono text-sm">{stitchSettings.bead_color}</span>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          )}

          {activeTab === 'appearance' && (
            <motion.div
              key="appearance"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-6"
            >
              <Card className="shadow-lg border-[#FF5F6D]/20">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Square className="h-5 w-5 text-[#FF5F6D]" />
                    Style des symboles
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-3">
                    <Label>Taille des symboles</Label>
                    <div className="flex items-center gap-4">
                      <span className="text-sm text-slate-600">Petit</span>
                      <Slider value={[appearanceSettings.symbol_size]} onValueChange={(value) => updateAppearanceSetting('symbol_size', value[0])} min={30} max={100} step={10} className="flex-1" />
                      <span className="text-sm text-slate-600">Grand</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Style des symboles</Label>
                    <Select value={appearanceSettings.symbol_style} onValueChange={(value) => updateAppearanceSetting('symbol_style', value)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="classic">Classique</SelectItem>
                        <SelectItem value="minimal">Fin minimaliste</SelectItem>
                        <SelectItem value="bold">Gras lisible</SelectItem>
                        <SelectItem value="accessible">Très lisible (accessibilité)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
              </Card>

              <Card className="shadow-lg border-[#FF5F6D]/20">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Palette className="h-5 w-5 text-[#FF5F6D]" />
                    Contraste & couleur de fond
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-2">
                    <Label>Contraste global</Label>
                    <Select value={appearanceSettings.contrast_level} onValueChange={(value) => updateAppearanceSetting('contrast_level', value)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Faible</SelectItem>
                        <SelectItem value="normal">Normal</SelectItem>
                        <SelectItem value="high">Élevé</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Couleur de fond de la grille</Label>
                    <Select value={appearanceSettings.grid_background} onValueChange={(value) => updateAppearanceSetting('grid_background', value)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="white">Blanc</SelectItem>
                        <SelectItem value="light-gray">Gris clair</SelectItem>
                        <SelectItem value="ivory">Papier ivoire</SelectItem>
                        <SelectItem value="transparent">Transparent / Aucun fond</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
              </Card>

              <Card className="shadow-lg border-[#FF5F6D]/20">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Grid3x3 className="h-5 w-5 text-[#FF5F6D]" />
                    Quadrillage
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between p-4 rounded-lg bg-slate-50">
                    <Label>Afficher quadrillage 1×1</Label>
                    <Switch checked={appearanceSettings.show_1x1_grid} onCheckedChange={(checked) => updateAppearanceSetting('show_1x1_grid', checked)} />
                  </div>
                  <div className="flex items-center justify-between p-4 rounded-lg bg-slate-50">
                    <Label>Afficher lignes 10×10</Label>
                    <Switch checked={appearanceSettings.show_10x10_lines} onCheckedChange={(checked) => updateAppearanceSetting('show_10x10_lines', checked)} />
                  </div>
                </CardContent>
              </Card>

              <Card className="shadow-lg border-[#FF5F6D]/20">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Eye className="h-5 w-5 text-[#FF5F6D]" />
                    Zoom & navigation
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <Label>Zoom initial (%)</Label>
                    <div className="flex items-center gap-4">
                      <Slider value={[appearanceSettings.initial_zoom]} onValueChange={(value) => updateAppearanceSetting('initial_zoom', value[0])} min={50} max={200} step={10} className="flex-1" />
                      <span className="text-sm font-semibold text-slate-700 w-12">{appearanceSettings.initial_zoom}%</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between p-4 rounded-lg bg-slate-50">
                    <div>
                      <Label>Activer zoom intelligent</Label>
                      <p className="text-sm text-slate-600">Centre sur l'endroit où on brode</p>
                    </div>
                    <Switch checked={appearanceSettings.smart_zoom_enabled} onCheckedChange={(checked) => updateAppearanceSetting('smart_zoom_enabled', checked)} />
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}

          {activeTab === 'comfort' && (
            <motion.div
              key="comfort"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-6"
            >
              <Card className="shadow-lg border-[#FF5F6D]/20">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Eye className="h-5 w-5 text-[#FF5F6D]" />
                    Aides visuelles
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between p-4 rounded-lg bg-slate-50">
                    <Label>Surlignage automatique de la couleur en cours</Label>
                    <Switch checked={comfortSettings.auto_highlight_color} onCheckedChange={(checked) => updateComfortSetting('auto_highlight_color', checked)} />
                  </div>
                  <div className="flex items-center justify-between p-4 rounded-lg bg-slate-50">
                    <Label>Ombre sur les zones non brodées</Label>
                    <Switch checked={comfortSettings.shadow_unworked_zones} onCheckedChange={(checked) => updateComfortSetting('shadow_unworked_zones', checked)} />
                  </div>
                  <div className="flex items-center justify-between p-4 rounded-lg bg-slate-50">
                    <Label>Effet halo autour de la case sélectionnée</Label>
                    <Switch checked={comfortSettings.halo_selected_cell} onCheckedChange={(checked) => updateComfortSetting('halo_selected_cell', checked)} />
                  </div>
                  <div className="space-y-3">
                    <Label>Intensité du surlignage</Label>
                    <div className="flex items-center gap-4">
                      <span className="text-sm text-slate-600">0%</span>
                      <Slider value={[comfortSettings.highlight_intensity]} onValueChange={(value) => updateComfortSetting('highlight_intensity', value[0])} min={0} max={100} step={10} className="flex-1" />
                      <span className="text-sm font-semibold text-slate-700 w-12">{comfortSettings.highlight_intensity}%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="shadow-lg border-[#FF5F6D]/20">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Lightbulb className="h-5 w-5 text-[#FF5F6D]" />
                    Lecture & suivi
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between p-4 rounded-lg bg-slate-50">
                    <Label>Compteur de points restant</Label>
                    <Switch checked={comfortSettings.show_stitch_counter} onCheckedChange={(checked) => updateComfortSetting('show_stitch_counter', checked)} />
                  </div>
                  <div className="flex items-center justify-between p-4 rounded-lg bg-slate-50">
                    <Label>Afficher un résumé par couleur</Label>
                    <Switch checked={comfortSettings.show_color_summary} onCheckedChange={(checked) => updateComfortSetting('show_color_summary', checked)} />
                  </div>
                  <div className="flex items-center justify-between p-4 rounded-lg bg-slate-50">
                    <div>
                      <Label>Son léger "clic doux" à chaque point validé</Label>
                      <p className="text-sm text-slate-600">Désactivable</p>
                    </div>
                    <Switch checked={comfortSettings.play_click_sound} onCheckedChange={(checked) => updateComfortSetting('play_click_sound', checked)} />
                  </div>
                </CardContent>
              </Card>

              <Card className="shadow-lg border-[#FF5F6D]/20 bg-[#FF5F6D]/5">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Sparkles className="h-5 w-5 text-[#FF5F6D]" />
                    Aide Paty
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between p-4 rounded-lg bg-white">
                    <Label>Activer les conseils de Paty</Label>
                    <Switch checked={comfortSettings.enable_paty_tips} onCheckedChange={(checked) => updateComfortSetting('enable_paty_tips', checked)} />
                  </div>
                  <div className="flex items-center justify-between p-4 rounded-lg bg-white">
                    <div>
                      <Label>Voir les infos-bulles</Label>
                      <p className="text-sm text-slate-600">Symboles, type de point, couleur</p>
                    </div>
                    <Switch checked={comfortSettings.show_tooltips} onCheckedChange={(checked) => updateComfortSetting('show_tooltips', checked)} />
                  </div>
                </CardContent>
              </Card>

              <Card className="shadow-lg border-[#FF5F6D]/20">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="h-5 w-5 text-[#FF5F6D]" />
                    Mode focus
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between p-4 rounded-lg bg-slate-50">
                    <Label>Assombrir tout sauf la case courante</Label>
                    <Switch checked={comfortSettings.focus_mode_darken} onCheckedChange={(checked) => updateComfortSetting('focus_mode_darken', checked)} />
                  </div>
                  <div className="flex items-center justify-between p-4 rounded-lg bg-slate-50">
                    <Label>Mode "ligne active" (highlight horizontal)</Label>
                    <Switch checked={comfortSettings.focus_mode_row} onCheckedChange={(checked) => updateComfortSetting('focus_mode_row', checked)} />
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}