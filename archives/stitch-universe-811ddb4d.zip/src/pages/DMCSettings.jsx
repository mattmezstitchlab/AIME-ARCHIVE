import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { ArrowLeft, Plus, Trash2, Save, Palette } from 'lucide-react';
import { createPageUrl } from '../utils';
import { motion, AnimatePresence } from 'framer-motion';

const DEFAULT_DMC_COLORS = [
  { code: '310', name: 'Noir / Black', color_hex: '#000000' },
  { code: '321', name: 'Rouge / Red', color_hex: '#C72B3B' },
  { code: '666', name: 'Rouge vif / Bright Red', color_hex: '#E31A1C' },
  { code: '740', name: 'Orange vif / Bright Orange', color_hex: '#FF6A00' },
  { code: '798', name: 'Bleu / Blue', color_hex: '#1C4F9C' },
  { code: 'B5200', name: 'Blanc / White', color_hex: '#FFFFFF' },
  { code: '310', name: 'Noir / Black', color_hex: '#000000' },
  { code: '413', name: 'Gris foncé / Dark Grey', color_hex: '#4A4A4A' },
  { code: '3371', name: 'Marron / Brown', color_hex: '#5B3A29' },
  { code: '725', name: 'Jaune / Yellow', color_hex: '#FFD900' }
];

export default function DMCSettings() {
  const navigate = useNavigate();
  const [isAuthenticated, setIsAuthenticated] = useState(null);
  const [colors, setColors] = useState([]);
  const [editingId, setEditingId] = useState(null);
  const [editingData, setEditingData] = useState({});
  
  // Form for adding new color
  const [newCode, setNewCode] = useState('');
  const [newName, setNewName] = useState('');
  const [newColorHex, setNewColorHex] = useState('#000000');

  useEffect(() => {
    loadColors();
  }, []);

  const loadColors = async () => {
    try {
      const isAuth = await base44.auth.isAuthenticated();
      setIsAuthenticated(isAuth);

      if (isAuth) {
        // Load from database
        const dbColors = await base44.entities.DMCColor.list();
        if (dbColors.length === 0) {
          // Initialize with default colors
          await initializeDefaultColors();
          const freshColors = await base44.entities.DMCColor.list();
          setColors(freshColors);
        } else {
          setColors(dbColors);
        }
      } else {
        // Load from localStorage
        const localColors = localStorage.getItem('paticroix_dmc_colors');
        if (localColors) {
          setColors(JSON.parse(localColors));
        } else {
          // Initialize with default colors
          localStorage.setItem('paticroix_dmc_colors', JSON.stringify(DEFAULT_DMC_COLORS));
          setColors(DEFAULT_DMC_COLORS);
        }
      }
    } catch (error) {
      console.error('Erreur chargement couleurs DMC:', error);
      // Fallback to localStorage
      const localColors = localStorage.getItem('paticroix_dmc_colors');
      if (localColors) {
        setColors(JSON.parse(localColors));
      } else {
        setColors(DEFAULT_DMC_COLORS);
      }
      setIsAuthenticated(false);
    }
  };

  const initializeDefaultColors = async () => {
    for (const color of DEFAULT_DMC_COLORS) {
      await base44.entities.DMCColor.create(color);
    }
  };

  const saveToStorage = async (newColors) => {
    if (isAuthenticated) {
      // Already saved to database
      return;
    } else {
      localStorage.setItem('paticroix_dmc_colors', JSON.stringify(newColors));
    }
  };

  const handleAdd = async () => {
    if (!newCode.trim()) {
      alert('Le code DMC est requis');
      return;
    }

    const newColor = {
      code: newCode.trim(),
      name: newName.trim() || 'Sans nom',
      color_hex: newColorHex
    };

    try {
      if (isAuthenticated) {
        const created = await base44.entities.DMCColor.create(newColor);
        setColors([...colors, created]);
      } else {
        const id = Date.now().toString();
        const colorWithId = { ...newColor, id };
        const newColors = [...colors, colorWithId];
        setColors(newColors);
        saveToStorage(newColors);
      }

      // Reset form
      setNewCode('');
      setNewName('');
      setNewColorHex('#000000');
    } catch (error) {
      console.error('Erreur ajout couleur:', error);
      alert('Erreur lors de l\'ajout de la couleur');
    }
  };

  const handleEdit = (color) => {
    setEditingId(color.id);
    setEditingData({
      code: color.code,
      name: color.name,
      color_hex: color.color_hex
    });
  };

  const handleSaveEdit = async (colorId) => {
    try {
      if (isAuthenticated) {
        await base44.entities.DMCColor.update(colorId, editingData);
        setColors(colors.map(c => c.id === colorId ? { ...c, ...editingData } : c));
      } else {
        const newColors = colors.map(c => 
          c.id === colorId ? { ...c, ...editingData } : c
        );
        setColors(newColors);
        saveToStorage(newColors);
      }
      setEditingId(null);
      setEditingData({});
    } catch (error) {
      console.error('Erreur modification:', error);
      alert('Erreur lors de la modification');
    }
  };

  const handleDelete = async (colorId) => {
    if (!confirm('Supprimer cette couleur DMC ?')) return;

    try {
      if (isAuthenticated) {
        await base44.entities.DMCColor.delete(colorId);
        setColors(colors.filter(c => c.id !== colorId));
      } else {
        const newColors = colors.filter(c => c.id !== colorId);
        setColors(newColors);
        saveToStorage(newColors);
      }
    } catch (error) {
      console.error('Erreur suppression:', error);
      alert('Erreur lors de la suppression');
    }
  };

  return (
    <div className="min-h-screen p-4 md:p-8 md:ml-64">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate(createPageUrl('Profile'))}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <h1 className="text-4xl font-bold text-slate-800 mb-2">Bibliothèque DMC</h1>
            <p className="text-slate-600">Gère ici toutes tes couleurs de fils</p>
          </div>
        </div>

        {/* Colors Table */}
        <Card className="mb-8 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Palette className="h-5 w-5 text-indigo-600" />
              Couleurs DMC
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-slate-50">
                    <TableHead className="font-semibold">Code</TableHead>
                    <TableHead className="font-semibold">Nom</TableHead>
                    <TableHead className="font-semibold">Couleur</TableHead>
                    <TableHead className="font-semibold text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <AnimatePresence mode="popLayout">
                    {colors.map((color, index) => (
                      <motion.tr
                        key={color.id || index}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, x: -20 }}
                        transition={{ delay: index * 0.03 }}
                        className="border-b hover:bg-slate-50"
                      >
                        <TableCell>
                          {editingId === color.id ? (
                            <Input
                              value={editingData.code}
                              onChange={(e) => setEditingData({ ...editingData, code: e.target.value })}
                              className="w-24"
                            />
                          ) : (
                            <span className="font-mono font-semibold text-slate-700">
                              {color.code}
                            </span>
                          )}
                        </TableCell>
                        <TableCell>
                          {editingId === color.id ? (
                            <Input
                              value={editingData.name}
                              onChange={(e) => setEditingData({ ...editingData, name: e.target.value })}
                            />
                          ) : (
                            <span className="text-slate-600">{color.name}</span>
                          )}
                        </TableCell>
                        <TableCell>
                          {editingId === color.id ? (
                            <div className="flex items-center gap-2">
                              <input
                                type="color"
                                value={editingData.color_hex}
                                onChange={(e) => setEditingData({ ...editingData, color_hex: e.target.value })}
                                className="w-12 h-8 rounded border cursor-pointer"
                              />
                              <Input
                                value={editingData.color_hex}
                                onChange={(e) => setEditingData({ ...editingData, color_hex: e.target.value })}
                                className="w-24 font-mono text-sm"
                              />
                            </div>
                          ) : (
                            <div className="flex items-center gap-2">
                              <div
                                className="w-8 h-8 rounded border-2 border-slate-300 shadow-sm"
                                style={{ backgroundColor: color.color_hex }}
                              />
                              <span className="font-mono text-sm text-slate-500">
                                {color.color_hex}
                              </span>
                            </div>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end gap-2">
                            {editingId === color.id ? (
                              <>
                                <Button
                                  size="sm"
                                  onClick={() => handleSaveEdit(color.id)}
                                  className="bg-green-600 hover:bg-green-700"
                                >
                                  <Save className="h-4 w-4 mr-1" />
                                  Sauvegarder
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => setEditingId(null)}
                                >
                                  Annuler
                                </Button>
                              </>
                            ) : (
                              <>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleEdit(color)}
                                >
                                  Modifier
                                </Button>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => handleDelete(color.id)}
                                  className="text-red-600 hover:text-red-700 hover:bg-red-50"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </>
                            )}
                          </div>
                        </TableCell>
                      </motion.tr>
                    ))}
                  </AnimatePresence>
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        {/* Add New Color */}
        <Card className="shadow-lg bg-gradient-to-br from-indigo-50 to-pink-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Plus className="h-5 w-5 text-indigo-600" />
              Ajouter une nouvelle couleur DMC
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-4 mb-4">
              <div className="space-y-2">
                <Label htmlFor="new-code">Code DMC</Label>
                <Input
                  id="new-code"
                  placeholder="ex: 413"
                  value={newCode}
                  onChange={(e) => setNewCode(e.target.value)}
                  className="bg-white"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="new-name">Nom de la couleur</Label>
                <Input
                  id="new-name"
                  placeholder="ex: Gris foncé"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  className="bg-white"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="new-color">Couleur</Label>
                <div className="flex gap-2">
                  <input
                    type="color"
                    id="new-color"
                    value={newColorHex}
                    onChange={(e) => setNewColorHex(e.target.value)}
                    className="w-14 h-10 rounded border-2 cursor-pointer bg-white"
                  />
                  <Input
                    value={newColorHex}
                    onChange={(e) => setNewColorHex(e.target.value)}
                    placeholder="#000000"
                    className="font-mono bg-white"
                  />
                </div>
              </div>
            </div>
            <Button
              onClick={handleAdd}
              className="w-full bg-gradient-to-r from-indigo-600 to-pink-600 hover:from-indigo-700 hover:to-pink-700 h-12"
            >
              <Plus className="h-5 w-5 mr-2" />
              Ajouter cette couleur
            </Button>
          </CardContent>
        </Card>

        {/* Info Banner */}
        <Card className="mt-6 bg-slate-50 border-slate-200">
          <CardContent className="p-4">
            <p className="text-sm text-slate-600">
              💡 <strong>Astuce :</strong> Ces couleurs DMC seront utilisées comme référence lors de la génération de grilles et dans les légendes de tes patrons.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}