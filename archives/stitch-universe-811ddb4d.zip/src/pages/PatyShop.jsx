import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Sparkles, ShoppingBag, Book, Settings, ExternalLink } from 'lucide-react';
import { createPageUrl } from '../utils';
import { motion } from 'framer-motion';
import { getDMCLibrary } from '../components/utils/dmcHelper';

export default function PatyShop() {
  const navigate = useNavigate();
  const [lastPattern, setLastPattern] = useState(null);
  const [dmcLibrary, setDmcLibrary] = useState([]);
  const [supplies, setSupplies] = useState([]);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const isAuth = await base44.auth.isAuthenticated();
      if (isAuth) {
        const settings = await base44.entities.UserSettings.list();
        if (settings.length > 0 && settings[0].last_pattern_opened) {
          const patterns = await base44.entities.Pattern.filter({ 
            id: settings[0].last_pattern_opened 
          });
          if (patterns.length > 0) {
            setLastPattern(patterns[0]);
            generateSupplies(patterns[0]);
          }
        }
      }

      const library = await getDMCLibrary();
      setDmcLibrary(library);
    } catch (error) {
      console.error('Erreur chargement données:', error);
    }
  };

  const generateSupplies = (pattern) => {
    const suppliesList = [];

    // Canvas suggestions
    const size = pattern.grid_width * pattern.grid_height;
    let canvasType = 'Aïda 14 points';
    if (size > 20000) canvasType = 'Aïda 16 points (détails fins)';
    if (size < 5000) canvasType = 'Aïda 11 points (débutant)';

    suppliesList.push({
      category: 'Toile',
      name: canvasType,
      description: `Toile adaptée pour une grille de ${pattern.grid_width}×${pattern.grid_height} points`,
      quantity: 1
    });

    // DMC threads
    if (pattern.legend && pattern.legend.length > 0) {
      pattern.legend.forEach(item => {
        if (item.dmc_code && item.total_stitches > 0) {
          const echeveaux = Math.ceil(item.total_stitches / 400);
          suppliesList.push({
            category: 'Fils DMC',
            name: `DMC ${item.dmc_code} - ${item.dmc_name || item.dmc_code}`,
            description: `${item.total_stitches} points`,
            quantity: echeveaux,
            color: item.color_hex
          });
        }
      });
    }

    // Accessories
    suppliesList.push(
      {
        category: 'Accessoires',
        name: 'Tambour à broder',
        description: 'Pour maintenir la toile tendue',
        quantity: 1
      },
      {
        category: 'Accessoires',
        name: 'Aiguilles à broder',
        description: 'Taille 24 ou 26',
        quantity: 1
      },
      {
        category: 'Accessoires',
        name: 'Ciseaux de broderie',
        description: 'Pour couper les fils',
        quantity: 1
      }
    );

    // Beads if enabled
    if (pattern.legend?.some(item => item.symbol === 'O' || item.symbol === '⬤')) {
      suppliesList.push({
        category: 'Perles',
        name: 'Perles de rocaille',
        description: 'Assortiment selon couleurs de la grille',
        quantity: 1
      });
    }

    setSupplies(suppliesList);
  };

  const groupedSupplies = supplies.reduce((acc, item) => {
    if (!acc[item.category]) {
      acc[item.category] = [];
    }
    acc[item.category].push(item);
    return acc;
  }, {});

  const HELP_LINKS = [
    {
      title: 'Guide des points & perles',
      description: 'Apprends les différents types de points',
      icon: Book,
      action: () => navigate(createPageUrl('StitchSettings'))
    },
    {
      title: 'Paramètres DMC',
      description: 'Gère ta bibliothèque de fils',
      icon: Settings,
      action: () => navigate(createPageUrl('DMCSettings'))
    },
    {
      title: 'Tutoriel du lecteur',
      description: 'Comment utiliser le lecteur de grilles',
      icon: Book,
      action: () => navigate(createPageUrl('Library'))
    },
    {
      title: 'Tutoriel du créateur',
      description: 'Crée des grilles depuis des photos',
      icon: Book,
      action: () => navigate(createPageUrl('Creator'))
    }
  ];

  return (
    <div className="min-h-screen p-4 md:p-8 md:ml-64">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate(createPageUrl('Profile'))}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-indigo-600 to-pink-600 flex items-center justify-center">
              <Sparkles className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold text-slate-800">Paty – Aide & Boutique</h1>
              <p className="text-slate-600">Tutoriels et fournitures pour ton projet</p>
            </div>
          </div>
        </div>

        {/* Help Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Book className="h-5 w-5 text-indigo-600" />
                Aide de Paty
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-4">
                {HELP_LINKS.map((link, index) => {
                  const Icon = link.icon;
                  return (
                    <Button
                      key={index}
                      variant="outline"
                      onClick={link.action}
                      className="h-auto py-4 px-6 justify-start"
                    >
                      <Icon className="h-5 w-5 mr-3 text-indigo-600" />
                      <div className="text-left">
                        <div className="font-semibold">{link.title}</div>
                        <div className="text-xs text-slate-500">{link.description}</div>
                      </div>
                    </Button>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Shop Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="bg-gradient-to-br from-amber-50 to-yellow-50 border-amber-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ShoppingBag className="h-5 w-5 text-amber-600" />
                Boutique Paty – Fournitures
              </CardTitle>
              {lastPattern && (
                <p className="text-sm text-slate-600">
                  Fournitures suggérées pour : <strong>{lastPattern.name}</strong>
                </p>
              )}
            </CardHeader>
            <CardContent>
              {supplies.length === 0 ? (
                <div className="text-center py-8">
                  <ShoppingBag className="h-12 w-12 text-slate-300 mx-auto mb-4" />
                  <p className="text-slate-600 mb-4">
                    Ouvre une grille pour voir les fournitures suggérées
                  </p>
                  <Button
                    onClick={() => navigate(createPageUrl('Library'))}
                    className="bg-gradient-to-r from-indigo-600 to-pink-600"
                  >
                    Voir mes grilles
                  </Button>
                </div>
              ) : (
                <div className="space-y-6">
                  {Object.entries(groupedSupplies).map(([category, items]) => (
                    <div key={category}>
                      <h3 className="font-semibold text-lg text-slate-800 mb-3 flex items-center gap-2">
                        {category}
                        <Badge variant="secondary">{items.length}</Badge>
                      </h3>
                      <div className="space-y-2">
                        {items.map((item, index) => (
                          <div
                            key={index}
                            className="flex items-center gap-3 p-3 rounded-lg bg-white hover:bg-slate-50 transition-colors"
                          >
                            {item.color && (
                              <div
                                className="w-8 h-8 rounded-lg shadow-md flex-shrink-0"
                                style={{ backgroundColor: item.color }}
                              />
                            )}
                            <div className="flex-1">
                              <div className="font-medium text-slate-800">{item.name}</div>
                              <div className="text-sm text-slate-500">{item.description}</div>
                            </div>
                            {item.quantity > 1 && (
                              <Badge variant="outline">×{item.quantity}</Badge>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}

                  <div className="pt-6 border-t">
                    <p className="text-sm text-slate-600 mb-4">
                      💡 <strong>Astuce :</strong> Ces fournitures sont calculées automatiquement selon ta grille. 
                      Tu peux aussi demander à Paty de préparer une liste personnalisée !
                    </p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}