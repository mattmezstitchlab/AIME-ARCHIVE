import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Loader2, Wand2, Save, FileDown, Sparkles, Camera, RefreshCw, Grid3x3 } from 'lucide-react';
import { createPageUrl } from '../utils';
import { motion } from 'framer-motion';
import BackButton from '../components/ui/BackButton';
import { getDMCLibrary } from '../components/utils/dmcHelper';
import ModeSelector from '../components/creator/ModeSelector';
import GenerationParams from '../components/creator/GenerationParams';
import PreviewTabs from '../components/creator/PreviewTabs';
import LegendDisplay from '../components/creator/LegendDisplay';

export default function Creator() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [isAuthenticated, setIsAuthenticated] = useState(null);
  const [mode, setMode] = useState('photo');
  const [file, setFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [patternName, setPatternName] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedPattern, setGeneratedPattern] = useState(null);
  const [params, setParams] = useState({
    width: 100,
    height: 100,
    colorCount: 20,
    stitchType: 'simple',
    dmcPalette: 'all',
    resolution: 'auto',
    reduceDetails: false,
    smoothGradients: false,
    uniformizeZones: false,
    optimizeReal: true
  });

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    const auth = await base44.auth.isAuthenticated();
    setIsAuthenticated(auth);
  };

  const updateParams = (updates) => {
    setParams(prev => ({ ...prev, ...updates }));
  };

  const handleFileChange = (event) => {
    const selectedFile = event.target.files[0];
    if (selectedFile) {
      setFile(selectedFile);
      setPreviewUrl(URL.createObjectURL(selectedFile));
      if (!patternName) {
        setPatternName(selectedFile.name.replace(/\.[^/.]+$/, ''));
      }
    }
  };

  const handleCameraCapture = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      alert('Fonctionnalité caméra à implémenter');
      stream.getTracks().forEach(track => track.stop());
    } catch (error) {
      alert('Impossible d\'accéder à la caméra');
    }
  };

  const handleGenerate = async () => {
    if (mode !== 'blank' && !file) {
      alert('Veuillez sélectionner un fichier');
      return;
    }

    setIsGenerating(true);

    try {
      const { resizeImageToGrid, quantizeColors, mapToClosestColor, rgbToHex, assignSymbols } = await import('../components/utils/imageProcessor');
      const dmcLibrary = await getDMCLibrary();

      const gridDimensions = { width: params.width, height: params.height };

      // ÉTAPE A : Créer l'image de travail aux dimensions exactes de la grille
      let workingImageData;
      if (mode === 'blank') {
        const canvas = document.createElement('canvas');
        canvas.width = gridDimensions.width;
        canvas.height = gridDimensions.height;
        const ctx = canvas.getContext('2d');
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        workingImageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      } else {
        workingImageData = await resizeImageToGrid(file, gridDimensions.width, gridDimensions.height);
      }

      // ÉTAPE B : Réduction de palette (nombre de couleurs demandé)
      const reducedPalette = quantizeColors(workingImageData, params.colorCount);
      const paletteWithSymbols = assignSymbols(reducedPalette);

      // Créer un mapping palette RGB -> DMC pour éviter de recalculer
      const paletteToDMC = new Map();
      paletteWithSymbols.forEach(color => {
        const colorKey = `${color.r},${color.g},${color.b}`;
        
        // Trouver le DMC le plus proche
        let dmcCode = '310';
        let dmcName = 'Noir';
        let dmcHex = '#000000';
        
        if (dmcLibrary.length > 0) {
          let minDist = Infinity;
          dmcLibrary.forEach(dmc => {
            const dmcRgb = hexToRgb(dmc.color_hex);
            if (dmcRgb) {
              const dist = Math.sqrt(
                Math.pow(color.r - dmcRgb.r, 2) +
                Math.pow(color.g - dmcRgb.g, 2) +
                Math.pow(color.b - dmcRgb.b, 2)
              );
              if (dist < minDist) {
                minDist = dist;
                dmcCode = dmc.code;
                dmcName = dmc.name;
                dmcHex = dmc.color_hex;
              }
            }
          });
        }

        // Déterminer le type de point
        let pointType = 'full_cross';
        const st = params.stitchType;
        if (st === 'half') {
          pointType = Math.random() > 0.7 ? 'half_stitch' : 'full_cross';
        } else if (st === 'special') {
          const rand = Math.random();
          if (rand > 0.85) pointType = 'special';
          else if (rand > 0.7) pointType = 'half_stitch';
          else pointType = 'full_cross';
        } else if (st === 'beads') {
          pointType = Math.random() > 0.85 ? 'bead' : 'full_cross';
        } else if (st === 'hybrid') {
          const rand = Math.random();
          if (rand > 0.9) pointType = 'bead';
          else if (rand > 0.8) pointType = 'special';
          else if (rand > 0.7) pointType = 'half_stitch';
          else pointType = 'full_cross';
        } else if (st === 'full') {
          const rand = Math.random();
          if (rand > 0.92) pointType = 'backstitch';
          else if (rand > 0.85) pointType = 'bead';
          else if (rand > 0.75) pointType = 'special';
          else if (rand > 0.65) pointType = 'half_stitch';
          else pointType = 'full_cross';
        }

        paletteToDMC.set(colorKey, {
          symbol: color.symbol,
          dmc_code: dmcCode,
          dmc_name: dmcName,
          dmc_hex: dmcHex,
          display_color: rgbToHex(color.r, color.g, color.b),
          point_type: pointType,
          rgb: color
        });
      });

      // ÉTAPE C : Construction de la matrice de grille
      const gridMatrix = [];
      const colorCounts = {};

      for (let y = 0; y < gridDimensions.height; y++) {
        const row = [];
        for (let x = 0; x < gridDimensions.width; x++) {
          const pixelIndex = (y * gridDimensions.width + x) * 4;
          const pixel = {
            r: workingImageData.data[pixelIndex],
            g: workingImageData.data[pixelIndex + 1],
            b: workingImageData.data[pixelIndex + 2]
          };

          // Mapper au plus proche dans la palette réduite
          const closestColor = mapToClosestColor(pixel, paletteWithSymbols);
          const colorKey = `${closestColor.r},${closestColor.g},${closestColor.b}`;
          
          colorCounts[colorKey] = (colorCounts[colorKey] || 0) + 1;

          // Récupérer les infos DMC depuis le mapping
          const dmcInfo = paletteToDMC.get(colorKey);

          row.push({
            rgb: closestColor,
            symbol: closestColor.symbol,
            colorKey: colorKey,
            dmc_code: dmcInfo?.dmc_code,
            dmc_name: dmcInfo?.dmc_name,
            display_color: dmcInfo?.display_color,
            point_type: dmcInfo?.point_type
          });
        }
        gridMatrix.push(row);
      }

      // ÉTAPE D : Construction de la légende
      const legend = [];
      paletteToDMC.forEach((dmcInfo, colorKey) => {
        const count = colorCounts[colorKey] || 0;
        if (count > 0) {
          legend.push({
            symbol: dmcInfo.symbol,
            dmc_code: dmcInfo.dmc_code,
            dmc_name: dmcInfo.dmc_name,
            color_hex: dmcInfo.dmc_hex,
            display_color: dmcInfo.display_color,
            point_type: dmcInfo.point_type,
            total_stitches: count,
            rgb: dmcInfo.rgb
          });
        }
      });

      let file_url = '';
      if (file) {
        const uploadResult = await base44.integrations.Core.UploadFile({ file });
        file_url = uploadResult.file_url;
      }

      setGeneratedPattern({
        name: patternName || 'Grille générée',
        source_type: 'generated',
        file_url: file_url,
        grid_width: gridDimensions.width,
        grid_height: gridDimensions.height,
        legend: legend,
        grid_matrix: gridMatrix,
        total_stitches: gridDimensions.width * gridDimensions.height,
        stitch_type: params.stitchType,
        color_count: legend.length
      });

    } catch (error) {
      console.error('Erreur génération:', error);
      alert('Erreur lors de la génération de la grille.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleRegenerate = () => {
    handleGenerate();
  };

  const hexToRgb = (hex) => {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
      r: parseInt(result[1], 16),
      g: parseInt(result[2], 16),
      b: parseInt(result[3], 16)
    } : null;
  };

  const handleSavePattern = async () => {
    if (!generatedPattern) return;

    const isAuth = await base44.auth.isAuthenticated();
    if (!isAuth) {
      if (confirm('Tu dois te connecter pour sauvegarder cette grille. Te connecter maintenant ?')) {
        base44.auth.redirectToLogin(window.location.pathname);
      }
      return;
    }

    try {
      const symbolMatrix = generatedPattern.grid_matrix.map(row =>
        row.map(cell => cell.symbol)
      );

      const pattern = await base44.entities.Pattern.create({
        name: generatedPattern.name,
        source_type: generatedPattern.source_type,
        file_url: generatedPattern.file_url,
        grid_width: generatedPattern.grid_width,
        grid_height: generatedPattern.grid_height,
        legend: generatedPattern.legend,
        grid_data: JSON.stringify(symbolMatrix),
        total_stitches: generatedPattern.total_stitches,
        color_count: generatedPattern.color_count,
        last_opened: new Date().toISOString()
      });

      queryClient.invalidateQueries({ queryKey: ['patterns'] });
      navigate(createPageUrl('PatternReader') + `?id=${pattern.id}`);
    } catch (error) {
      console.error('Erreur sauvegarde:', error);
      alert('Erreur lors de la sauvegarde.');
    }
  };

  const renderPixelizedPreview = () => {
    if (!generatedPattern) return null;
    const { grid_matrix, grid_width, grid_height } = generatedPattern;
    const cellSize = Math.max(3, Math.min(600 / grid_width, 600 / grid_height));

    return (
      <svg width={grid_width * cellSize} height={grid_height * cellSize}>
        {grid_matrix.map((row, y) => 
          row.map((cell, x) => (
            <rect
              key={`${y}-${x}`}
              x={x * cellSize}
              y={y * cellSize}
              width={cellSize}
              height={cellSize}
              fill={`rgb(${cell.rgb.r},${cell.rgb.g},${cell.rgb.b})`}
              stroke="none"
            />
          ))
        )}
      </svg>
    );
  };

  const renderGridWithSymbols = () => {
    if (!generatedPattern) return null;
    const { grid_matrix, grid_width, grid_height } = generatedPattern;
    const cellSize = 30;

    return (
      <svg width={grid_width * cellSize} height={grid_height * cellSize}>
        {Array.from({ length: grid_height + 1 }).map((_, i) => (
            <line
              key={`h-${i}`}
              x1={0}
              y1={i * cellSize}
              x2={grid_width * cellSize}
              y2={i * cellSize}
              stroke="#cbd5e1"
              strokeWidth="1"
            />
          ))}
          {Array.from({ length: grid_width + 1 }).map((_, i) => (
            <line
              key={`v-${i}`}
              x1={i * cellSize}
              y1={0}
              x2={i * cellSize}
              y2={grid_height * cellSize}
              stroke="#cbd5e1"
              strokeWidth="1"
            />
          ))}
        
        {grid_matrix.map((row, y) => 
          row.map((cell, x) => {
            const cx = x * cellSize + cellSize / 2;
            const cy = y * cellSize + cellSize / 2;
            const pointType = cell.point_type || 'full_cross';
            const displayColor = cell.display_color || '#334155';

            if (pointType === 'bead') {
              return (
                <circle
                  key={`${y}-${x}`}
                  cx={cx}
                  cy={cy}
                  r={cellSize * 0.25}
                  fill={displayColor}
                  stroke="#64748b"
                  strokeWidth="1"
                />
              );
            } else if (pointType === 'half_stitch') {
              return (
                <line
                  key={`${y}-${x}`}
                  x1={x * cellSize + 3}
                  y1={y * cellSize + 3}
                  x2={(x + 1) * cellSize - 3}
                  y2={(y + 1) * cellSize - 3}
                  stroke={displayColor}
                  strokeWidth="2"
                  strokeLinecap="round"
                />
              );
            } else if (pointType === 'special') {
              return (
                <g key={`${y}-${x}`}>
                  <line x1={cx} y1={cy - 8} x2={cx} y2={cy + 8} stroke={displayColor} strokeWidth="2" />
                  <line x1={cx - 8} y1={cy} x2={cx + 8} y2={cy} stroke={displayColor} strokeWidth="2" />
                  <line x1={cx - 6} y1={cy - 6} x2={cx + 6} y2={cy + 6} stroke={displayColor} strokeWidth="2" />
                  <line x1={cx - 6} y1={cy + 6} x2={cx + 6} y2={cy - 6} stroke={displayColor} strokeWidth="2" />
                </g>
              );
            } else {
              return (
                <g key={`${y}-${x}`}>
                  <line
                    x1={x * cellSize + 3}
                    y1={y * cellSize + 3}
                    x2={(x + 1) * cellSize - 3}
                    y2={(y + 1) * cellSize - 3}
                    stroke={displayColor}
                    strokeWidth="2"
                    strokeLinecap="round"
                  />
                  <line
                    x1={(x + 1) * cellSize - 3}
                    y1={y * cellSize + 3}
                    x2={x * cellSize + 3}
                    y2={(y + 1) * cellSize - 3}
                    stroke={displayColor}
                    strokeWidth="2"
                    strokeLinecap="round"
                  />
                </g>
              );
            }
          })
        )}
        {grid_matrix.map((row, y) => 
          row.map((cell, x) => (
            <text
              key={`sym-${y}-${x}`}
              x={x * cellSize + cellSize / 2}
              y={y * cellSize + cellSize / 2}
              textAnchor="middle"
              dominantBaseline="central"
              fontSize="10"
              fontWeight="bold"
              fill="#64748b"
              opacity="0.7"
            >
              {cell.symbol}
            </text>
          ))
        )}
      </svg>
    );
  };

  if (isAuthenticated === null) {
    return (
      <div className="min-h-screen flex items-center justify-center md:ml-64">
        <div className="animate-spin h-8 w-8 border-4 border-fuchsia-600 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-[900px] mx-auto">
        <div className="mb-8 flex items-center gap-4">
          <BackButton to={createPageUrl('Home')} />
          <div>
            <h1 className="text-4xl font-bold text-slate-800 mb-2">Créateur de grilles</h1>
            <p className="text-slate-600">Transforme une photo, importe une grille ou crée de zéro</p>
          </div>
        </div>

        {/* Mode Selector */}
        <ModeSelector selectedMode={mode} onSelectMode={setMode} />

        <div className="grid lg:grid-cols-2 gap-8 mb-8">
          {/* Import Zone */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            {mode === 'photo' && (
              <div className="space-y-4">
                {!previewUrl ? (
                  <div className="space-y-4">
                    <label htmlFor="image-upload" className="cursor-pointer block">
                      <div className="border-2 border-dashed border-slate-300 rounded-xl p-12 hover:border-fuchsia-400 hover:bg-fuchsia-50/50 transition-all text-center">
                        <Camera className="h-12 w-12 text-slate-400 mx-auto mb-4" />
                        <p className="text-slate-600 font-medium mb-2">Importer une photo</p>
                        <p className="text-sm text-slate-400">JPG, PNG (max 10 MB)</p>
                      </div>
                      <input
                        id="image-upload"
                        type="file"
                        accept="image/*"
                        onChange={handleFileChange}
                        className="hidden"
                      />
                    </label>
                    <Button variant="outline" onClick={handleCameraCapture} className="w-full">
                      <Camera className="h-4 w-4 mr-2" />
                      Prendre une photo
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <img src={previewUrl} alt="Preview" className="w-full rounded-xl shadow-lg" />
                    <Input
                      placeholder="Nom de la grille"
                      value={patternName}
                      onChange={(e) => setPatternName(e.target.value)}
                    />
                    <Button variant="outline" onClick={() => { setFile(null); setPreviewUrl(null); }} className="w-full">
                      Changer d'image
                    </Button>
                  </div>
                )}
              </div>
            )}

            {mode === 'import' && (
              <div className="space-y-4">
                {!previewUrl ? (
                  <label htmlFor="file-import" className="cursor-pointer block">
                    <div className="border-2 border-dashed border-slate-300 rounded-xl p-12 hover:border-fuchsia-400 hover:bg-fuchsia-50/50 transition-all text-center">
                      <FileDown className="h-12 w-12 text-slate-400 mx-auto mb-4" />
                      <p className="text-slate-600 font-medium mb-2">Importer un fichier</p>
                      <p className="text-sm text-slate-400">PDF, JPG, PNG</p>
                    </div>
                    <input
                      id="file-import"
                      type="file"
                      accept=".pdf,.jpg,.jpeg,.png"
                      onChange={handleFileChange}
                      className="hidden"
                    />
                  </label>
                ) : (
                  <div className="space-y-4">
                    <img src={previewUrl} alt="Preview" className="w-full rounded-xl shadow-lg" />
                    <Input
                      placeholder="Nom de la grille"
                      value={patternName}
                      onChange={(e) => setPatternName(e.target.value)}
                    />
                    <Button variant="outline" onClick={() => { setFile(null); setPreviewUrl(null); }} className="w-full">
                      Changer de fichier
                    </Button>
                  </div>
                )}
              </div>
            )}

            {mode === 'blank' && (
              <div className="border-2 border-slate-300 rounded-xl p-12 text-center">
                <Grid3x3 className="h-12 w-12 text-slate-400 mx-auto mb-4" />
                <p className="text-slate-600 font-medium mb-2">Grille vierge</p>
                <p className="text-sm text-slate-400 mb-4">Configure la taille et génère une grille vide</p>
                <Input
                  placeholder="Nom de la grille"
                  value={patternName}
                  onChange={(e) => setPatternName(e.target.value)}
                />
              </div>
            )}
          </motion.div>

          {/* Parameters */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
            <GenerationParams params={params} onParamsChange={updateParams} />
            <div className="mt-6 flex gap-3">
              <Button
                onClick={handleGenerate}
                disabled={isGenerating || (mode !== 'blank' && !file)}
                className="flex-1 bg-gradient-to-r from-fuchsia-600 to-purple-600 h-12"
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="h-5 w-5 mr-2 animate-spin" />
                    Génération...
                  </>
                ) : (
                  <>
                    <Wand2 className="h-5 w-5 mr-2" />
                    Générer la grille
                  </>
                )}
              </Button>
              <Button variant="outline" className="bg-gradient-to-r from-purple-50 to-fuchsia-50">
                <Sparkles className="h-4 w-4 mr-2 text-fuchsia-600" />
                Demander à Paty
              </Button>
            </div>
          </motion.div>
        </div>

        {/* Results */}
        {generatedPattern && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold text-slate-800">Aperçu de ta grille</h2>
              <div className="flex gap-2">
                <Button variant="outline" onClick={handleRegenerate}>
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Régénérer
                </Button>
                <Button variant="outline">
                  <FileDown className="h-4 w-4 mr-2" />
                  Exporter
                </Button>
                <Button onClick={handleSavePattern} className="bg-gradient-to-r from-green-600 to-emerald-600">
                  <Save className="h-4 w-4 mr-2" />
                  Enregistrer
                </Button>
              </div>
            </div>

            <div className="mb-4 p-3 bg-[#FF5F6D]/10 border border-[#FF5F6D]/20 rounded-lg">
              <p className="text-sm text-slate-700">
                <strong>💡 Info :</strong> Ta grille est générée à partir d'une version adaptée de ton image, selon la taille et le nombre de couleurs que tu as choisis. L'aperçu pixelisé et la grille reflètent exactement ce résultat.
              </p>
            </div>

            <PreviewTabs
              originalImage={previewUrl}
              pixelizedPreview={renderPixelizedPreview()}
              gridWithSymbols={renderGridWithSymbols()}
            />

            <LegendDisplay
              legend={generatedPattern.legend}
              onFilterColor={(symbol) => console.log('Filter:', symbol)}
            />
          </motion.div>
        )}
      </div>
    </div>
  );
}