import React from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function Layout({ children, currentPageName }) {
  return (
    <div className="w-full h-screen bg-black text-white overflow-hidden" style={{ width: '100vw', height: '100vh' }}>
      <main className="relative z-10 w-full h-full">
        {children}
      </main>
    </div>
  );
}