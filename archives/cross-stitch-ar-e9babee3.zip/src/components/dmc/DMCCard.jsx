import React from 'react';
import { motion } from 'framer-motion';
import { Check, Heart, Plus, Minus, ShoppingCart } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";

export default function DMCCard({ 
  thread, 
  userCollection,
  onToggleOwned,
  onToggleWishlist,
  onUpdateQuantity 
}) {
  const isOwned = userCollection?.status === 'owned';
  const isWishlisted = userCollection?.status === 'wishlist';
  const quantity = userCollection?.quantity || 0;

  return (
    <motion.div
      whileHover={{ y: -4 }}
      transition={{ duration: 0.2 }}
    >
      <Card className="bg-gray-800/50 border-gray-700 hover:border-gray-600 transition-all overflow-hidden">
        <CardContent className="p-0">
          {/* Color swatch */}
          <div 
            className="h-32 relative"
            style={{ backgroundColor: thread.color_hex }}
          >
            {isOwned && (
              <Badge className="absolute top-2 right-2 bg-emerald-500">
                <Check className="w-3 h-3 mr-1" />
                Possédé
              </Badge>
            )}
            {isWishlisted && (
              <Badge className="absolute top-2 right-2 bg-amber-500">
                <Heart className="w-3 h-3 mr-1" />
                Souhaité
              </Badge>
            )}
          </div>

          {/* Info */}
          <div className="p-4 space-y-3">
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-lg font-bold text-white font-mono">
                  DMC {thread.dmc_code}
                </span>
                <Badge variant="secondary" className="bg-gray-700 text-gray-300 text-xs">
                  {thread.color_family}
                </Badge>
              </div>
              <p className="text-sm text-gray-400">{thread.name}</p>
            </div>

            {/* Quantity control (if owned) */}
            {isOwned && (
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => onUpdateQuantity(thread.dmc_code, Math.max(1, quantity - 1))}
                  className="h-7 w-7 border-gray-700"
                >
                  <Minus className="w-3 h-3" />
                </Button>
                <span className="text-sm text-gray-300 min-w-[60px] text-center">
                  {quantity} écheveau{quantity > 1 ? 'x' : ''}
                </span>
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => onUpdateQuantity(thread.dmc_code, quantity + 1)}
                  className="h-7 w-7 border-gray-700"
                >
                  <Plus className="w-3 h-3" />
                </Button>
              </div>
            )}

            {/* Actions */}
            <div className="flex gap-2">
              <Button
                variant={isOwned ? "default" : "outline"}
                size="sm"
                onClick={() => onToggleOwned(thread.dmc_code)}
                className={isOwned ? "bg-emerald-500 hover:bg-emerald-600 flex-1" : "border-gray-700 flex-1"}
              >
                <Check className="w-4 h-4 mr-2" />
                {isOwned ? 'Possédé' : 'Marquer'}
              </Button>
              <Button
                variant={isWishlisted ? "default" : "outline"}
                size="icon"
                onClick={() => onToggleWishlist(thread.dmc_code)}
                className={isWishlisted ? "bg-amber-500 hover:bg-amber-600" : "border-gray-700"}
              >
                {isWishlisted ? <Heart className="w-4 h-4 fill-current" /> : <Heart className="w-4 h-4" />}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}