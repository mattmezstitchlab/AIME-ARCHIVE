import React from 'react';
import { Star, Zap } from 'lucide-react';
import { Badge } from "@/components/ui/badge";

export default function FeaturedBadge({ badge, featured_at }) {
  if (badge === 'none' || !badge) return null;

  const badges = {
    inspiration_mois: {
      label: 'Inspiration du mois',
      icon: <Star className="w-3 h-3" />,
      className: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30'
    },
    technique_mois: {
      label: 'Technique du mois',
      icon: <Zap className="w-3 h-3" />,
      className: 'bg-purple-500/20 text-purple-400 border-purple-500/30'
    }
  };

  const config = badges[badge];
  if (!config) return null;

  return (
    <Badge className={`border ${config.className} flex items-center gap-1`}>
      {config.icon}
      {config.label}
    </Badge>
  );
}