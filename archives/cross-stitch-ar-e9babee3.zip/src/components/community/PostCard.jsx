import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Heart, MessageCircle, User, Calendar } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar } from "@/components/ui/avatar";
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';

export default function PostCard({ post, currentUserEmail, onLike, onComment }) {
  const [showComments, setShowComments] = useState(false);
  const isLiked = post.likes?.includes(currentUserEmail);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <Card className="bg-gray-800/50 border-gray-700 overflow-hidden">
        <CardContent className="p-0">
          {/* Image */}
          {post.image_url && (
            <div className="relative h-64 sm:h-80 bg-gray-900">
              <img 
                src={post.image_url} 
                alt={post.title}
                className="w-full h-full object-cover"
              />
            </div>
          )}

          {/* Content */}
          <div className="p-4 space-y-3">
            {/* Author & Date */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center">
                  <User className="w-4 h-4 text-white" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-white">{post.created_by}</p>
                  <p className="text-xs text-gray-400 flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    {format(new Date(post.created_date), 'dd MMM yyyy', { locale: fr })}
                  </p>
                </div>
              </div>
              <div className="flex gap-1 flex-wrap">
              {post.pattern_title && (
                <Badge variant="secondary" className="bg-purple-500/20 text-purple-400 text-xs">
                  📋 {post.pattern_title}
                </Badge>
              )}
              {post.group_name && (
                <Badge variant="secondary" className="bg-blue-500/20 text-blue-400 text-xs">
                  👥 {post.group_name}
                </Badge>
              )}
            </div>
            </div>

            {/* Title & Description */}
            <div>
              <h3 className="text-lg font-semibold text-white mb-1">{post.title}</h3>
              <p className="text-gray-300 text-sm">{post.description}</p>
            </div>

            {/* Tags */}
            {post.tags?.length > 0 && (
              <div className="flex gap-2 flex-wrap">
                {post.tags.map((tag, idx) => (
                  <Badge key={idx} variant="outline" className="border-gray-600 text-gray-400 text-xs">
                    #{tag}
                  </Badge>
                ))}
              </div>
            )}

            {/* Actions */}
            <div className="flex items-center gap-4 pt-2 border-t border-gray-700">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => onLike(post.id, isLiked)}
                className={isLiked ? "text-red-400 hover:text-red-300" : "text-gray-400 hover:text-white"}
              >
                <Heart className={`w-4 h-4 mr-2 ${isLiked ? 'fill-current' : ''}`} />
                {post.likes?.length || 0}
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowComments(!showComments)}
                className="text-gray-400 hover:text-white"
              >
                <MessageCircle className="w-4 h-4 mr-2" />
                {post.comments_count || 0}
              </Button>
            </div>

            {/* Comments Section */}
            {showComments && (
              <div className="pt-3 border-t border-gray-700">
                {onComment && (
                  <div>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => onComment(post.id)}
                      className="border-gray-700"
                    >
                      Ajouter un commentaire
                    </Button>
                  </div>
                )}
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}