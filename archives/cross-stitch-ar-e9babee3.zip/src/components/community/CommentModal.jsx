import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X, Send } from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar } from "@/components/ui/avatar";
import { toast } from "sonner";
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';

export default function CommentModal({ postId, onClose }) {
  const [comment, setComment] = useState('');
  const queryClient = useQueryClient();

  const { data: comments = [], isLoading } = useQuery({
    queryKey: ['comments', postId],
    queryFn: () => base44.entities.PostComment.filter({ post_id: postId })
  });

  const { data: user } = useQuery({
    queryKey: ['current-user'],
    queryFn: () => base44.auth.me()
  });

  const createCommentMutation = useMutation({
    mutationFn: (data) => base44.entities.PostComment.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['comments', postId]);
      queryClient.invalidateQueries(['community-posts']);
      setComment('');
      toast.success('Commentaire ajouté');
    }
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!comment.trim()) return;

    await createCommentMutation.mutateAsync({
      post_id: postId,
      comment: comment.trim(),
      author_name: user?.full_name || 'Anonyme'
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] bg-black/80 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.9, y: 20 }}
        onClick={(e) => e.stopPropagation()}
        className="max-w-2xl w-full max-h-[80vh] flex flex-col"
      >
        <Card className="bg-gray-900 border-gray-700 flex flex-col max-h-full">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-white">Commentaires</CardTitle>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </CardHeader>
          <CardContent className="flex-1 overflow-y-auto space-y-4">
            {/* Comments List */}
            {isLoading ? (
              <p className="text-gray-400 text-center">Chargement...</p>
            ) : comments.length === 0 ? (
              <p className="text-gray-400 text-center">Aucun commentaire pour le moment</p>
            ) : (
              <div className="space-y-3">
                {comments.map(c => (
                  <div key={c.id} className="bg-gray-800/50 rounded-lg p-3">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="w-6 h-6 rounded-full bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center text-xs text-white">
                        {c.author_name?.[0]?.toUpperCase()}
                      </div>
                      <div>
                        <p className="text-sm font-semibold text-white">{c.author_name}</p>
                        <p className="text-xs text-gray-400">
                          {format(new Date(c.created_date), 'dd MMM yyyy HH:mm', { locale: fr })}
                        </p>
                      </div>
                    </div>
                    <p className="text-gray-300 text-sm">{c.comment}</p>
                  </div>
                ))}
              </div>
            )}

            {/* Add Comment Form */}
            <form onSubmit={handleSubmit} className="space-y-3 pt-4 border-t border-gray-700">
              <Textarea
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                placeholder="Écrire un commentaire..."
                className="bg-gray-800 border-gray-700 text-white"
                rows={3}
              />
              <Button
                type="submit"
                disabled={!comment.trim() || createCommentMutation.isPending}
                className="w-full bg-emerald-500 hover:bg-emerald-600"
              >
                <Send className="w-4 h-4 mr-2" />
                Envoyer
              </Button>
            </form>
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  );
}