import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const CATEGORY_ICONS = {
  style: '🎨',
  technique: '🧵',
  projet: '📋',
  couleur: '🌈',
  niveau: '⭐'
};

export default function CreateGroupModal({ onSubmit, onClose }) {
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    category: 'style',
    icon: '🎨',
    is_private: false
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.description.trim()) {
      return;
    }
    onSubmit(formData);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] bg-black/80 flex items-center justify-center p-4 overflow-y-auto"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.9, y: 20 }}
        onClick={(e) => e.stopPropagation()}
        className="max-w-2xl w-full my-8"
      >
        <Card className="bg-gray-900 border-gray-700">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-white">Créer un groupe</CardTitle>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Name */}
              <div>
                <Label htmlFor="name" className="text-gray-300">Nom du groupe *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Ex: Broderie Floral"
                  className="bg-gray-800 border-gray-700 text-white mt-2"
                  required
                />
              </div>

              {/* Description */}
              <div>
                <Label htmlFor="description" className="text-gray-300">Description *</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Décrivez le thème du groupe..."
                  className="bg-gray-800 border-gray-700 text-white mt-2 h-24"
                  required
                />
              </div>

              {/* Category */}
              <div>
                <Label className="text-gray-300">Catégorie *</Label>
                <Select 
                  value={formData.category}
                  onValueChange={(value) => setFormData({ 
                    ...formData, 
                    category: value,
                    icon: CATEGORY_ICONS[value]
                  })}
                >
                  <SelectTrigger className="bg-gray-800 border-gray-700 text-white mt-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-700">
                    <SelectItem value="style">🎨 Style</SelectItem>
                    <SelectItem value="technique">🧵 Technique</SelectItem>
                    <SelectItem value="projet">📋 Projet</SelectItem>
                    <SelectItem value="couleur">🌈 Couleur</SelectItem>
                    <SelectItem value="niveau">⭐ Niveau</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Private Toggle */}
              <div className="flex items-center gap-3 p-3 bg-gray-800/50 rounded-lg">
                <input
                  type="checkbox"
                  id="private"
                  checked={formData.is_private}
                  onChange={(e) => setFormData({ ...formData, is_private: e.target.checked })}
                  className="w-4 h-4"
                />
                <Label htmlFor="private" className="text-gray-300 flex-1">
                  Groupe privé (invitation uniquement)
                </Label>
              </div>

              {/* Submit */}
              <div className="flex gap-2 pt-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={onClose}
                  className="flex-1 border-gray-700"
                >
                  Annuler
                </Button>
                <Button
                  type="submit"
                  className="flex-1 bg-purple-500 hover:bg-purple-600"
                >
                  Créer le groupe
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  );
}