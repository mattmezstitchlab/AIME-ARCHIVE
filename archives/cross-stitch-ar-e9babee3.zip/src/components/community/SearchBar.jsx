import React, { useState } from 'react';
import { Search, X, ChevronDown } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function SearchBar({ 
  onSearch, 
  allTags = [], 
  allGroups = [],
  onFiltersChange 
}) {
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTags, setSelectedTags] = useState([]);
  const [selectedGroup, setSelectedGroup] = useState('');
  const [sortBy, setSortBy] = useState('recent');

  const handleApplyFilters = () => {
    onFiltersChange({
      search: searchTerm,
      tags: selectedTags,
      group: selectedGroup,
      sort: sortBy
    });
    setShowAdvanced(false);
  };

  const handleClearFilters = () => {
    setSearchTerm('');
    setSelectedTags([]);
    setSelectedGroup('');
    setSortBy('recent');
    onFiltersChange({
      search: '',
      tags: [],
      group: '',
      sort: 'recent'
    });
  };

  const isFiltered = searchTerm || selectedTags.length > 0 || selectedGroup || sortBy !== 'recent';

  return (
    <div className="space-y-3">
      {/* Main Search */}
      <div className="flex gap-2">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
          <Input
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Chercher une création..."
            className="bg-gray-800 border-gray-700 text-white pl-10 py-2"
            onKeyDown={(e) => {
              if (e.key === 'Enter') handleApplyFilters();
            }}
          />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
        <Button
          onClick={() => setShowAdvanced(!showAdvanced)}
          variant="outline"
          className="border-gray-700"
        >
          <ChevronDown className={`w-4 h-4 transition-transform ${showAdvanced ? 'rotate-180' : ''}`} />
        </Button>
      </div>

      {/* Advanced Filters */}
      {showAdvanced && (
        <Card className="bg-gray-800/50 border-gray-700 p-4 space-y-3">
          {/* Group Filter */}
          <div>
            <label className="text-xs text-gray-400 mb-2 block">Groupe</label>
            <Select value={selectedGroup} onValueChange={setSelectedGroup}>
              <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                <SelectValue placeholder="Tous les groupes" />
              </SelectTrigger>
              <SelectContent className="bg-gray-800 border-gray-700">
                <SelectItem value={null}>Tous les groupes</SelectItem>
                {allGroups.map(group => (
                  <SelectItem key={group.id} value={group.id}>
                    {group.icon} {group.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Tags Filter */}
          <div>
            <label className="text-xs text-gray-400 mb-2 block">Tags</label>
            <div className="flex flex-wrap gap-2">
              {allTags.map(tag => (
                <button
                  key={tag}
                  onClick={() => {
                    setSelectedTags(prev =>
                      prev.includes(tag)
                        ? prev.filter(t => t !== tag)
                        : [...prev, tag]
                    );
                  }}
                  className={`px-3 py-1 rounded-full text-sm transition-all ${
                    selectedTags.includes(tag)
                      ? 'bg-emerald-500 text-white'
                      : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                  }`}
                >
                  #{tag}
                </button>
              ))}
            </div>
          </div>

          {/* Sort */}
          <div>
            <label className="text-xs text-gray-400 mb-2 block">Trier par</label>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-gray-800 border-gray-700">
                <SelectItem value="recent">Récent</SelectItem>
                <SelectItem value="popular">Populaire</SelectItem>
                <SelectItem value="featured">Mise en avant</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Actions */}
          <div className="flex gap-2 pt-2">
            <Button
              onClick={handleClearFilters}
              variant="outline"
              size="sm"
              className="flex-1 border-gray-700"
            >
              Réinitialiser
            </Button>
            <Button
              onClick={handleApplyFilters}
              size="sm"
              className="flex-1 bg-emerald-500 hover:bg-emerald-600"
            >
              Appliquer
            </Button>
          </div>
        </Card>
      )}

      {/* Active Filters Display */}
      {isFiltered && (
        <div className="flex flex-wrap gap-2 items-center">
          {searchTerm && (
            <div className="text-xs px-2 py-1 rounded bg-gray-800 text-gray-300">
              Terme: {searchTerm}
            </div>
          )}
          {selectedGroup && (
            <div className="text-xs px-2 py-1 rounded bg-gray-800 text-gray-300">
              Groupe: {allGroups.find(g => g.id === selectedGroup)?.name}
            </div>
          )}
          {selectedTags.map(tag => (
            <div key={tag} className="text-xs px-2 py-1 rounded bg-emerald-500/20 text-emerald-400">
              #{tag}
            </div>
          ))}
          {sortBy !== 'recent' && (
            <div className="text-xs px-2 py-1 rounded bg-gray-800 text-gray-300">
              {sortBy === 'popular' ? 'Populaire' : 'Mise en avant'}
            </div>
          )}
        </div>
      )}
    </div>
  );
}