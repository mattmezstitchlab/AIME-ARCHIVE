import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { BookOpen, Zap, CheckCircle2 } from 'lucide-react';

export default function CourseProgress({ 
  course, 
  completedLessons = 0,
  totalLessons = 0,
  earnedXP = 0
}) {
  const progressPercent = totalLessons > 0 ? Math.round((completedLessons / totalLessons) * 100) : 0;
  const isCompleted = completedLessons === totalLessons && totalLessons > 0;

  return (
    <Card className="bg-gradient-to-br from-gray-800/50 to-gray-900/50 border-gray-700">
      <CardContent className="p-4">
        <div className="space-y-3">
          {/* Header */}
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-white flex items-center gap-2">
              <BookOpen className="w-4 h-4" />
              Progression
            </h3>
            {isCompleted && (
              <div className="flex items-center gap-1 text-emerald-400">
                <CheckCircle2 className="w-4 h-4" />
                <span className="text-xs font-semibold">Complété</span>
              </div>
            )}
          </div>

          {/* Progress bar */}
          <div className="space-y-1">
            <div className="flex items-center justify-between">
              <span className="text-xs text-gray-400">
                {completedLessons}/{totalLessons} leçons
              </span>
              <span className="text-xs text-emerald-400 font-semibold">
                {progressPercent}%
              </span>
            </div>
            <Progress 
              value={progressPercent} 
              className="h-2 bg-gray-700"
            />
          </div>

          {/* XP earned */}
          <div className="flex items-center gap-2 bg-gray-700/30 rounded-lg p-2">
            <Zap className="w-4 h-4 text-yellow-500" />
            <span className="text-xs text-gray-300">
              <span className="font-semibold text-yellow-400">{earnedXP}</span> / {course.total_xp_reward} XP
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}