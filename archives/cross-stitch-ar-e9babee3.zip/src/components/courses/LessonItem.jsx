import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, Circle, PlayCircle, FileText, Zap } from 'lucide-react';

export default function LessonItem({ 
  lesson, 
  isCompleted, 
  isActive,
  onClick 
}) {
  const contentIcon = {
    video: PlayCircle,
    text: FileText,
    mixed: PlayCircle
  };

  const ContentIcon = contentIcon[lesson.content_type];

  return (
    <motion.div
      whileHover={{ x: 4 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className="cursor-pointer"
    >
      <Card className={`
        transition-all
        ${isActive 
          ? 'bg-purple-500/20 border-purple-500/50' 
          : 'bg-gray-800/30 border-gray-700 hover:border-gray-600'
        }
      `}>
        <CardContent className="p-4 flex items-start gap-3">
          {/* Completion status */}
          <div className="flex-shrink-0 mt-0.5">
            {isCompleted ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            ) : (
              <Circle className="w-5 h-5 text-gray-600" />
            )}
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <ContentIcon className="w-4 h-4 text-gray-400 flex-shrink-0" />
              <h4 className={`font-semibold line-clamp-1 ${
                isActive ? 'text-white' : 'text-gray-300'
              }`}>
                {lesson.title}
              </h4>
            </div>

            {lesson.description && (
              <p className="text-xs text-gray-500 line-clamp-1 mb-2">
                {lesson.description}
              </p>
            )}

            {/* Meta */}
            <div className="flex items-center gap-2 text-xs text-gray-500">
              {lesson.duration_minutes && (
                <span>{lesson.duration_minutes} min</span>
              )}
              {lesson.xp_reward && (
                <div className="flex items-center gap-0.5">
                  <Zap className="w-3 h-3 text-yellow-500" />
                  <span>{lesson.xp_reward} XP</span>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}