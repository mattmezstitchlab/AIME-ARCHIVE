import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { PlayCircle, FileText, Zap, Check, ChevronLeft, ChevronRight } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

export default function LessonViewer({
  lesson,
  isCompleted,
  onComplete,
  onPrevious,
  onNext,
  hasPrevious,
  hasNext
}) {
  const [isMarking, setIsMarking] = useState(false);

  const handleComplete = async () => {
    setIsMarking(true);
    try {
      await onComplete();
    } finally {
      setIsMarking(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-4"
    >
      {/* Header */}
      <Card className="bg-gray-800/50 border-gray-700">
        <CardContent className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div>
              <h1 className="text-2xl font-bold text-white mb-2">
                {lesson.title}
              </h1>
              {lesson.description && (
                <p className="text-gray-400">{lesson.description}</p>
              )}
            </div>
            {isCompleted && (
              <div className="flex items-center gap-2 px-3 py-1 bg-emerald-500/20 rounded-full">
                <Check className="w-4 h-4 text-emerald-400" />
                <span className="text-xs text-emerald-400 font-semibold">Complété</span>
              </div>
            )}
          </div>

          {/* Meta */}
          <div className="flex items-center gap-4 text-sm text-gray-400">
            <div className="flex items-center gap-1">
              {lesson.content_type === 'video' && <PlayCircle className="w-4 h-4" />}
              {lesson.content_type === 'text' && <FileText className="w-4 h-4" />}
              <span className="capitalize">
                {lesson.content_type === 'mixed' ? 'Mixte' : lesson.content_type}
              </span>
            </div>
            {lesson.duration_minutes && (
              <span>{lesson.duration_minutes} min</span>
            )}
            {lesson.xp_reward && (
              <div className="flex items-center gap-1">
                <Zap className="w-4 h-4 text-yellow-500" />
                <span>{lesson.xp_reward} XP</span>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Video content */}
      {lesson.video_url && (
        <div className="aspect-video rounded-2xl overflow-hidden bg-black">
          <iframe
            width="100%"
            height="100%"
            src={lesson.video_url}
            title={lesson.title}
            frameBorder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
            className="w-full h-full"
          />
        </div>
      )}

      {/* Text content */}
      {lesson.text_content && (
        <Card className="bg-gray-800/50 border-gray-700">
          <CardContent className="p-6">
            <div className="prose prose-invert max-w-none">
              <ReactMarkdown>
                {lesson.text_content}
              </ReactMarkdown>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Actions */}
      <div className="flex items-center justify-between gap-4 sticky bottom-0">
        <Button
          onClick={onPrevious}
          disabled={!hasPrevious}
          variant="outline"
          className="border-gray-700"
        >
          <ChevronLeft className="w-4 h-4 mr-2" />
          Leçon précédente
        </Button>

        {!isCompleted && (
          <Button
            onClick={handleComplete}
            disabled={isMarking}
            className="bg-emerald-500 hover:bg-emerald-600"
          >
            <Check className="w-4 h-4 mr-2" />
            {isMarking ? 'Marquage...' : 'Marquer comme complétée'}
          </Button>
        )}

        <Button
          onClick={onNext}
          disabled={!hasNext}
          variant="outline"
          className="border-gray-700"
        >
          Leçon suivante
          <ChevronRight className="w-4 h-4 ml-2" />
        </Button>
      </div>
    </motion.div>
  );
}