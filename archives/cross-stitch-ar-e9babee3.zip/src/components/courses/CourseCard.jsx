import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BookOpen, Clock, Zap } from 'lucide-react';

export default function CourseCard({ course, isEnrolled, onClick }) {
  const categoryLabel = {
    debutant: 'Débutant',
    intermediaire: 'Intermédiaire',
    avance: 'Avancé'
  };

  const categoryColor = {
    debutant: 'bg-emerald-500/20 text-emerald-400',
    intermediaire: 'bg-amber-500/20 text-amber-400',
    avance: 'bg-red-500/20 text-red-400'
  };

  return (
    <motion.div
      whileHover={{ y: -4 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className="cursor-pointer"
    >
      <Card className="bg-gray-800/50 border-0 hover:shadow-lg hover:shadow-emerald-500/20 transition-all overflow-hidden h-full">
        {/* Thumbnail */}
        <div className="h-32 bg-gradient-to-br from-gray-700 to-gray-800 overflow-hidden">
          {course.thumbnail_url ? (
            <img 
              src={course.thumbnail_url} 
              alt={course.title}
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <BookOpen className="w-12 h-12 text-gray-600" />
            </div>
          )}
        </div>

        <CardContent className="p-4">
          {/* Header */}
          <div className="flex items-start justify-between mb-2">
            <h3 className="font-semibold text-white line-clamp-2 flex-1">
              {course.title}
            </h3>
            {isEnrolled && (
              <Badge className="bg-emerald-500/20 text-emerald-400 ml-2 flex-shrink-0">
                Inscrit
              </Badge>
            )}
          </div>

          {/* Category */}
          <Badge className={`${categoryColor[course.category]} mb-3`}>
            {categoryLabel[course.category]}
          </Badge>

          {/* Description */}
          <p className="text-xs text-gray-400 line-clamp-2 mb-3">
            {course.description}
          </p>

          {/* Meta info */}
          <div className="flex items-center gap-4 text-xs text-gray-500">
            {course.lesson_count && (
              <div className="flex items-center gap-1">
                <BookOpen className="w-3 h-3" />
                {course.lesson_count} leçons
              </div>
            )}
            {course.estimated_duration_minutes && (
              <div className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                {course.estimated_duration_minutes} min
              </div>
            )}
            {course.total_xp_reward && (
              <div className="flex items-center gap-1">
                <Zap className="w-3 h-3 text-yellow-500" />
                {course.total_xp_reward} XP
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}