import React from 'react';
import { Award, Zap, Trophy } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { 
  getLevelInfo, 
  getNextLevelInfo, 
  calculateProgress,
  BADGES 
} from '@/components/gamification/gamificationConstants';

export default function GamificationSection({ user, sessions }) {
  const userXP = user?.total_xp || 0;
  const unlockedBadges = user?.unlocked_badges || [];
  
  // Calculate stats
  const completedSessions = sessions.filter(s => s.is_completed).length;
  const totalPoints = sessions.reduce((sum, s) => sum + (s.points_completed?.length || 0), 0);
  const avgSpeed = completedSessions > 0
    ? sessions
        .filter(s => s.is_completed)
        .reduce((sum, s) => sum + (s.stitches_per_minute || 0), 0) / completedSessions
    : 0;

  const currentLevel = getLevelInfo(userXP);
  const nextLevel = getNextLevelInfo(userXP);
  const progressPercent = calculateProgress(userXP);
  const xpToNext = nextLevel.minXP - userXP;

  const levelColors = {
    blue: 'from-blue-500 to-blue-600',
    green: 'from-green-500 to-green-600',
    cyan: 'from-cyan-500 to-cyan-600',
    purple: 'from-purple-500 to-purple-600',
    yellow: 'from-yellow-500 to-yellow-600',
    pink: 'from-pink-500 to-pink-600'
  };

  const borderColors = {
    blue: 'border-blue-500',
    green: 'border-green-500',
    cyan: 'border-cyan-500',
    purple: 'border-purple-500',
    yellow: 'border-yellow-500',
    pink: 'border-pink-500'
  };

  return (
    <div className="space-y-6">
      {/* Level Card */}
      <Card className={`bg-gradient-to-br ${levelColors[currentLevel.color]} border-2 ${borderColors[currentLevel.color]}`}>
        <CardContent className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div>
              <p className="text-sm text-white/80 uppercase">Niveau actuel</p>
              <h2 className="text-3xl font-bold text-white">{currentLevel.name}</h2>
            </div>
            <Trophy className="w-12 h-12 text-white/80" />
          </div>
          
          <div className="space-y-3">
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm text-white/90">Expérience</span>
                <span className="text-sm font-semibold text-white">{userXP} XP</span>
              </div>
              <Progress value={progressPercent} className="h-2" />
              <p className="text-xs text-white/70 mt-1">
                {xpToNext > 0 ? `${xpToNext} XP jusqu'au prochain niveau` : 'Niveau maximum!'}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
        <Card className="bg-gray-800/50 border-gray-700">
          <CardContent className="p-4">
            <p className="text-xs text-gray-500 uppercase mb-1">Sessions</p>
            <p className="text-2xl font-bold text-emerald-400">{completedSessions}</p>
          </CardContent>
        </Card>
        <Card className="bg-gray-800/50 border-gray-700">
          <CardContent className="p-4">
            <p className="text-xs text-gray-500 uppercase mb-1">Points</p>
            <p className="text-2xl font-bold text-cyan-400">{totalPoints}</p>
          </CardContent>
        </Card>
        <Card className="bg-gray-800/50 border-gray-700">
          <CardContent className="p-4">
            <p className="text-xs text-gray-500 uppercase mb-1">Vitesse</p>
            <p className="text-2xl font-bold text-purple-400">{avgSpeed.toFixed(1)}</p>
            <p className="text-xs text-gray-400">pts/min</p>
          </CardContent>
        </Card>
        <Card className="bg-gray-800/50 border-gray-700">
          <CardContent className="p-4">
            <p className="text-xs text-gray-500 uppercase mb-1">Badges</p>
            <p className="text-2xl font-bold text-yellow-400">{unlockedBadges.length}</p>
          </CardContent>
        </Card>
      </div>

      {/* Badges */}
      <Card className="bg-gray-800/50 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Award className="w-5 h-5 text-yellow-400" />
            Badges Débloqués
          </CardTitle>
        </CardHeader>
        <CardContent>
          {unlockedBadges.length === 0 ? (
            <p className="text-gray-400 text-center py-4">Continuez à broder pour débloquer des badges!</p>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
              {unlockedBadges.map(badgeId => {
                const badge = BADGES[badgeId];
                return (
                  <div key={badgeId} className="p-3 bg-gray-700/50 rounded-lg text-center hover:bg-gray-700 transition-colors">
                    <p className="text-2xl mb-1">{badge.icon}</p>
                    <p className="text-xs font-medium text-white">{badge.name}</p>
                    <p className="text-xs text-gray-400 mt-1">{badge.description}</p>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Available Badges */}
      {unlockedBadges.length < Object.keys(BADGES).length && (
        <Card className="bg-gray-800/50 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Zap className="w-5 h-5 text-amber-400" />
              Badges À Débloquer
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
              {Object.entries(BADGES).map(([badgeId, badge]) => {
                if (unlockedBadges.includes(badgeId)) return null;
                return (
                  <div key={badgeId} className="p-3 bg-gray-700/20 rounded-lg text-center opacity-50">
                    <p className="text-2xl mb-1 blur-sm">{badge.icon}</p>
                    <p className="text-xs font-medium text-gray-300">{badge.name}</p>
                    <p className="text-xs text-gray-500 mt-1">{badge.description}</p>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}