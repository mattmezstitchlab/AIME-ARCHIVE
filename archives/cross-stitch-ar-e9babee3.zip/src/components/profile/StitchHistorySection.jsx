import React from 'react';
import { formatDistanceToNow } from 'date-fns';
import { fr } from 'date-fns/locale';
import { Clock, CheckCircle2, TrendingUp } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

export default function StitchHistorySection({ sessions = [] }) {
  const completedSessions = sessions.filter(s => s.is_completed);
  const totalStitches = sessions.reduce((sum, s) => sum + (s.points_completed?.length || 0), 0);
  const avgSpeed = completedSessions.length > 0
    ? (completedSessions.reduce((sum, s) => sum + (s.stitches_per_minute || 0), 0) / completedSessions.length).toFixed(1)
    : 0;

  return (
    <div className="space-y-4">
      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <Card className="bg-gray-800/50 border-gray-700">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500 uppercase">Sessions</p>
                <p className="text-2xl font-bold text-white">{completedSessions.length}</p>
              </div>
              <CheckCircle2 className="w-8 h-8 text-emerald-500" />
            </div>
          </CardContent>
        </Card>
        <Card className="bg-gray-800/50 border-gray-700">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500 uppercase">Points</p>
                <p className="text-2xl font-bold text-white">{totalStitches}</p>
              </div>
              <Clock className="w-8 h-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
        <Card className="bg-gray-800/50 border-gray-700">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500 uppercase">Vitesse</p>
                <p className="text-2xl font-bold text-white">{avgSpeed}</p>
                <p className="text-xs text-gray-400">points/min</p>
              </div>
              <TrendingUp className="w-8 h-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Sessions */}
      <Card className="bg-gray-800/50 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">Sessions Récentes</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {completedSessions.length === 0 ? (
            <p className="text-gray-400 text-center py-4">Aucune session terminée</p>
          ) : (
            completedSessions.slice(0, 5).map(session => (
              <div key={session.id} className="p-3 bg-gray-700/50 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-medium text-white">{session.pattern_title}</h4>
                  <Badge className="bg-emerald-500/20 text-emerald-400">
                    {formatDistanceToNow(new Date(session.created_date), { locale: fr })}
                  </Badge>
                </div>
                <div className="grid grid-cols-2 gap-2 text-sm text-gray-400 mb-2">
                  <span>{session.points_completed?.length || 0} points</span>
                  <span>{Math.round(session.session_duration_minutes || 0)} min</span>
                </div>
                <Progress value={100} className="h-1" />
              </div>
            ))
          )}
        </CardContent>
      </Card>
    </div>
  );
}