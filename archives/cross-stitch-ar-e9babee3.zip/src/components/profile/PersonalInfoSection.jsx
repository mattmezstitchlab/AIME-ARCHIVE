import React, { useState } from 'react';
import { Edit2, Save, X } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

export default function PersonalInfoSection({ user, onUpdate }) {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    full_name: user?.full_name || '',
    bio: user?.bio || '',
    experience_level: user?.experience_level || 'intermediate'
  });
  const [isSaving, setIsSaving] = useState(false);

  const handleSave = async () => {
    setIsSaving(true);
    try {
      await onUpdate(formData);
      setIsEditing(false);
      toast.success('Profil mis à jour');
    } catch (error) {
      toast.error('Erreur: ' + error.message);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <Card className="bg-gray-800/50 border-gray-700">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-white">Informations Personnelles</CardTitle>
        {!isEditing ? (
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsEditing(true)}
            className="text-gray-400"
          >
            <Edit2 className="w-4 h-4" />
          </Button>
        ) : null}
      </CardHeader>
      <CardContent className="space-y-4">
        {isEditing ? (
          <>
            <div>
              <Label className="text-gray-300 mb-2 block">Nom complet</Label>
              <Input
                value={formData.full_name}
                onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                className="bg-gray-800 border-gray-700 text-white"
              />
            </div>
            <div>
              <Label className="text-gray-300 mb-2 block">Bio</Label>
              <Input
                value={formData.bio}
                onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                placeholder="Parlez-nous de vous..."
                className="bg-gray-800 border-gray-700 text-white"
              />
            </div>
            <div>
              <Label className="text-gray-300 mb-2 block">Niveau d'expérience</Label>
              <select
                value={formData.experience_level}
                onChange={(e) => setFormData({ ...formData, experience_level: e.target.value })}
                className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-md text-white"
              >
                <option value="beginner">Débutant</option>
                <option value="intermediate">Intermédiaire</option>
                <option value="advanced">Avancé</option>
              </select>
            </div>
            <div className="flex gap-2">
              <Button
                onClick={handleSave}
                disabled={isSaving}
                className="flex-1 bg-emerald-500 hover:bg-emerald-600"
              >
                <Save className="w-4 h-4 mr-2" />
                Enregistrer
              </Button>
              <Button
                onClick={() => setIsEditing(false)}
                variant="outline"
                className="flex-1 border-gray-700"
              >
                <X className="w-4 h-4 mr-2" />
                Annuler
              </Button>
            </div>
          </>
        ) : (
          <div className="space-y-3">
            <div>
              <p className="text-xs text-gray-500 uppercase">Nom</p>
              <p className="text-white">{user?.full_name}</p>
            </div>
            <div>
              <p className="text-xs text-gray-500 uppercase">Email</p>
              <p className="text-white">{user?.email}</p>
            </div>
            {user?.bio && (
              <div>
                <p className="text-xs text-gray-500 uppercase">Bio</p>
                <p className="text-gray-300">{user.bio}</p>
              </div>
            )}
            <div>
              <p className="text-xs text-gray-500 uppercase">Niveau</p>
              <p className="text-white capitalize">{user?.experience_level || 'Non défini'}</p>
            </div>
            <div>
              <p className="text-xs text-gray-500 uppercase">Rôle</p>
              <p className="text-white capitalize">{user?.role}</p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}