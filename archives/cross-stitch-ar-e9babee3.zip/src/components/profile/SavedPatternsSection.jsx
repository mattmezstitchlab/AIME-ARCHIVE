import React from 'react';
import { Grid3X3, Heart } from 'lucide-react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function SavedPatternsSection({ patterns = [], userCollection = [] }) {
  const savedPatternIds = userCollection.map(c => c.pattern_id).filter(Boolean);
  const savedPatterns = patterns.filter(p => savedPatternIds.includes(p.id));

  if (savedPatterns.length === 0) {
    return (
      <Card className="bg-gray-800/50 border-gray-700">
        <CardContent className="p-12 text-center">
          <Heart className="w-12 h-12 text-gray-600 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-white mb-2">Aucun pattern sauvegardé</h3>
          <p className="text-gray-400 mb-4">Découvrez et sauvegardez vos patterns préférés</p>
          <Link to={createPageUrl('ARMode')}>
            <Button className="bg-purple-500 hover:bg-purple-600">
              Explorer les patterns
            </Button>
          </Link>
        </CardContent>
      </Card>
    );
  }

  return (
    <div>
      <h2 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
        <Heart className="w-5 h-5 text-pink-500" />
        Patterns Sauvegardés ({savedPatterns.length})
      </h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {savedPatterns.map(pattern => (
          <Card key={pattern.id} className="bg-gray-800/50 border-gray-700 hover:border-purple-500/50 transition-all">
            <div className="h-24 bg-gradient-to-br from-gray-700 to-gray-800 flex items-center justify-center">
              <Grid3X3 className="w-8 h-8 text-gray-600" />
            </div>
            <CardContent className="p-3">
              <h3 className="font-medium text-white mb-1 line-clamp-1">{pattern.title}</h3>
              <p className="text-xs text-gray-400 mb-2">{pattern.total_stitches} points</p>
              <div className="flex gap-1 mb-3">
                {pattern.dmc_palette?.slice(0, 4).map(p => (
                  <div
                    key={p.dmc_code}
                    className="w-4 h-4 rounded border border-white/20"
                    style={{ backgroundColor: p.color }}
                  />
                ))}
                {pattern.dmc_palette?.length > 4 && (
                  <div className="w-4 h-4 rounded bg-gray-700 flex items-center justify-center text-[8px] text-white">
                    +{pattern.dmc_palette.length - 4}
                  </div>
                )}
              </div>
              <Link to={createPageUrl(`ARMode?patternId=${pattern.id}`)}>
                <Button size="sm" className="w-full bg-emerald-500 hover:bg-emerald-600 text-xs">
                  Broder
                </Button>
              </Link>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}