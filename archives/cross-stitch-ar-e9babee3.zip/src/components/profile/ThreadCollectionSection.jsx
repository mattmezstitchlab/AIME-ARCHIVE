import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Search, Plus, X } from 'lucide-react';

export default function ThreadCollectionSection({ 
  userThreads = [], 
  onAddThread = () => {}
}) {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState('owned');

  const ownedThreads = userThreads.filter(t => t.status === 'owned');
  const wishlistThreads = userThreads.filter(t => t.status === 'wishlist');

  const displayThreads = activeTab === 'owned' ? ownedThreads : wishlistThreads;
  const filteredThreads = displayThreads.filter(t =>
    t.dmc_code?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.notes?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-4">
      {/* Tabs */}
      <div className="flex gap-2">
        {[
          { id: 'owned', label: `Possédés (${ownedThreads.length})` },
          { id: 'wishlist', label: `Wishlist (${wishlistThreads.length})` }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex-1 px-3 py-2 rounded-lg text-xs font-light transition border ${
              activeTab === tab.id
                ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-400'
                : 'bg-gray-800/30 border-gray-700 text-gray-400 hover:border-gray-600'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3 h-3 text-gray-500" />
        <input
          type="text"
          placeholder="Rechercher des filés..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full pl-9 pr-3 py-1.5 bg-gray-800/30 border border-gray-700 rounded-lg text-white text-xs placeholder-gray-600 focus:outline-none focus:border-emerald-500/50"
        />
      </div>

      {/* Threads List */}
      <div className="space-y-2 max-h-80 overflow-y-auto">
        {filteredThreads.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-xs text-gray-500">
              {searchTerm ? 'Aucun fil trouvé' : 'Aucun fil dans cette catégorie'}
            </p>
          </div>
        ) : (
          filteredThreads.map(thread => (
            <motion.div
              key={thread.id}
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex items-center gap-3 p-2 bg-gray-800/20 rounded-lg border border-gray-700/30 hover:border-gray-600/50 transition group"
            >
              <div
                className="w-5 h-5 rounded border border-gray-600 flex-shrink-0"
                style={{ backgroundColor: `#${thread.color_hex?.replace('#', '') || 'ccc'}` }}
              />
              <div className="flex-1 min-w-0">
                <p className="text-xs font-light text-white">{thread.dmc_code}</p>
                {thread.notes && (
                  <p className="text-xs text-gray-500 truncate">{thread.notes}</p>
                )}
              </div>
              {thread.quantity && (
                <span className="text-xs text-gray-400">x{thread.quantity}</span>
              )}
            </motion.div>
          ))
        )}
      </div>

      {/* Add Thread Button */}
      <button
        onClick={onAddThread}
        className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/30 transition text-xs font-light"
      >
        <Plus className="w-3 h-3" />
        Ajouter un fil
      </button>
    </div>
  );
}