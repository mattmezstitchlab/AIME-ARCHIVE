import React, { useState } from 'react';
import { Settings, Save } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { toast } from "sonner";

export default function ARSettingsSection({ arSettings, onSave }) {
  const [settings, setSettings] = useState(arSettings || {
    default_opacity: 0.6,
    show_grid: true,
    show_guide_arrow: true,
    show_symbols: true,
    voice_enabled: true,
    voice_speed: 0.9,
    voice_pitch: 1.05
  });

  const [isSaving, setIsSaving] = useState(false);

  const handleSave = async () => {
    setIsSaving(true);
    try {
      await onSave(settings);
      toast.success('Paramètres AR sauvegardés');
    } catch (error) {
      toast.error('Erreur: ' + error.message);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <Card className="bg-gray-800/50 border-gray-700">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Settings className="w-5 h-5" />
          Paramètres AR
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Opacity */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <Label className="text-gray-300">Opacité du pattern</Label>
            <span className="text-sm text-gray-400">{Math.round(settings.default_opacity * 100)}%</span>
          </div>
          <Slider
            value={[settings.default_opacity]}
            onValueChange={(v) => setSettings({ ...settings, default_opacity: v[0] })}
            min={0.1}
            max={1}
            step={0.1}
            className="w-full"
          />
        </div>

        {/* Grid Toggle */}
        <div className="flex items-center justify-between p-3 bg-gray-700/30 rounded-lg">
          <Label className="text-gray-300">Afficher la grille</Label>
          <input
            type="checkbox"
            checked={settings.show_grid}
            onChange={(e) => setSettings({ ...settings, show_grid: e.target.checked })}
            className="w-4 h-4"
          />
        </div>

        {/* Guide Arrow */}
        <div className="flex items-center justify-between p-3 bg-gray-700/30 rounded-lg">
          <Label className="text-gray-300">Flèche de guidage</Label>
          <input
            type="checkbox"
            checked={settings.show_guide_arrow}
            onChange={(e) => setSettings({ ...settings, show_guide_arrow: e.target.checked })}
            className="w-4 h-4"
          />
        </div>

        {/* Symbols */}
        <div className="flex items-center justify-between p-3 bg-gray-700/30 rounded-lg">
          <Label className="text-gray-300">Symboles de points</Label>
          <input
            type="checkbox"
            checked={settings.show_symbols}
            onChange={(e) => setSettings({ ...settings, show_symbols: e.target.checked })}
            className="w-4 h-4"
          />
        </div>

        {/* Voice Settings */}
        <div className="border-t border-gray-700 pt-4">
          <h3 className="text-sm font-semibold text-white mb-4">Voix Compagnonne</h3>
          
          <div className="flex items-center justify-between p-3 bg-gray-700/30 rounded-lg mb-4">
            <Label className="text-gray-300">Activer la voix</Label>
            <input
              type="checkbox"
              checked={settings.voice_enabled}
              onChange={(e) => setSettings({ ...settings, voice_enabled: e.target.checked })}
              className="w-4 h-4"
            />
          </div>

          {settings.voice_enabled && (
            <>
              <div className="mb-4">
                <div className="flex items-center justify-between mb-2">
                  <Label className="text-gray-300 text-sm">Vitesse</Label>
                  <span className="text-sm text-gray-400">{settings.voice_speed.toFixed(2)}x</span>
                </div>
                <Slider
                  value={[settings.voice_speed]}
                  onValueChange={(v) => setSettings({ ...settings, voice_speed: v[0] })}
                  min={0.75}
                  max={1.2}
                  step={0.05}
                  className="w-full"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-2">
                  <Label className="text-gray-300 text-sm">Ton</Label>
                  <span className="text-sm text-gray-400">{settings.voice_pitch.toFixed(2)}</span>
                </div>
                <Slider
                  value={[settings.voice_pitch]}
                  onValueChange={(v) => setSettings({ ...settings, voice_pitch: v[0] })}
                  min={0.8}
                  max={1.5}
                  step={0.05}
                  className="w-full"
                />
              </div>
            </>
          )}
        </div>

        {/* Save Button */}
        <Button
          onClick={handleSave}
          disabled={isSaving}
          className="w-full bg-emerald-500 hover:bg-emerald-600 mt-4"
        >
          <Save className="w-4 h-4 mr-2" />
          Enregistrer les paramètres
        </Button>
      </CardContent>
    </Card>
  );
}