export const XP_REWARDS = {
  POINT_VALIDATED: 5,
  SESSION_COMPLETED: 100,
  FIRST_SESSION: 50,
  COMMUNITY_POST_LIKED: 10,
  COMMUNITY_POST_CREATED: 25,
  COMMUNITY_COMMENT: 5,
  PATTERN_SHARED: 15,
  MILESTONE_10_SESSIONS: 200,
  MILESTONE_50_SESSIONS: 500
};

export const LEVELS = [
  { level: 1, minXP: 0, name: 'Novice', color: 'blue' },
  { level: 2, minXP: 100, name: 'Apprenti', color: 'green' },
  { level: 3, minXP: 300, name: 'Adepte', color: 'cyan' },
  { level: 4, minXP: 600, name: 'Maître', color: 'purple' },
  { level: 5, minXP: 1000, name: 'Maître Brodeur', color: 'yellow' },
  { level: 6, minXP: 1500, name: 'Légende', color: 'pink' }
];

export const BADGES = {
  FIRST_STITCH: {
    id: 'FIRST_STITCH',
    name: 'Premier Point',
    description: 'Valider votre premier point',
    icon: '🎯',
    condition: (stats) => stats.total_points >= 1
  },
  STITCHER_10: {
    id: 'STITCHER_10',
    name: 'Brodeuse de 10',
    description: 'Compléter 10 sessions',
    icon: '✨',
    condition: (stats) => stats.completed_sessions >= 10
  },
  STITCHER_50: {
    id: 'STITCHER_50',
    name: 'Brodeuse de 50',
    description: 'Compléter 50 sessions',
    icon: '🌟',
    condition: (stats) => stats.completed_sessions >= 50
  },
  SPEED_DEMON: {
    id: 'SPEED_DEMON',
    name: 'Brodeuse Rapide',
    description: 'Atteindre 10 points par minute',
    icon: '⚡',
    condition: (stats) => stats.avg_speed >= 10
  },
  COLOR_MASTER: {
    id: 'COLOR_MASTER',
    name: 'Maître des Couleurs',
    description: 'Utiliser 20+ couleurs DMC différentes',
    icon: '🎨',
    condition: (stats) => stats.unique_colors >= 20
  },
  SOCIAL_BUTTERFLY: {
    id: 'SOCIAL_BUTTERFLY',
    name: 'Papillon Social',
    description: 'Créer 5 posts communautaires',
    icon: '🦋',
    condition: (stats) => stats.community_posts >= 5
  },
  PATTERN_CREATOR: {
    id: 'PATTERN_CREATOR',
    name: 'Créatrice de Patterns',
    description: 'Créer 5 patterns',
    icon: '🎭',
    condition: (stats) => stats.created_patterns >= 5
  },
  CONSISTENCY_KING: {
    id: 'CONSISTENCY_KING',
    name: 'Régulière',
    description: 'Broder 7 jours consécutifs',
    icon: '📅',
    condition: (stats) => stats.streak_days >= 7
  },
  MILESTONE_1000: {
    id: 'MILESTONE_1000',
    name: '1000 Points',
    description: 'Valider 1000 points au total',
    icon: '🏆',
    condition: (stats) => stats.total_points >= 1000
  },
  MARATHON: {
    id: 'MARATHON',
    name: 'Marathonienne',
    description: 'Compléter une session de 100+ points en une seule fois',
    icon: '🏃',
    condition: (stats) => stats.longest_session >= 100
  }
};

export function getLevelInfo(xp) {
  for (let i = LEVELS.length - 1; i >= 0; i--) {
    if (xp >= LEVELS[i].minXP) {
      return LEVELS[i];
    }
  }
  return LEVELS[0];
}

export function getNextLevelInfo(xp) {
  const currentLevel = getLevelInfo(xp);
  const nextIndex = currentLevel.level;
  return nextIndex < LEVELS.length ? LEVELS[nextIndex] : currentLevel;
}

export function getUnlockedBadges(stats) {
  return Object.values(BADGES).filter(badge => badge.condition(stats));
}

export function calculateProgress(xp) {
  const currentLevel = getLevelInfo(xp);
  const nextLevel = getNextLevelInfo(xp);
  
  if (currentLevel.level === nextLevel.level) {
    return 100; // Max level
  }
  
  const xpInCurrentLevel = xp - currentLevel.minXP;
  const xpNeededForNextLevel = nextLevel.minXP - currentLevel.minXP;
  return Math.round((xpInCurrentLevel / xpNeededForNextLevel) * 100);
}