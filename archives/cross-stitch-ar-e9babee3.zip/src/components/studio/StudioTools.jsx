import React from 'react';
import { motion } from 'framer-motion';
import { Plus, Upload, Palette, Users } from 'lucide-react';

const tools = [
  {
    id: 'new-pattern',
    label: 'Créer un pattern',
    description: 'Dessiner ou importer une image',
    icon: Plus,
    action: 'create'
  },
  {
    id: 'import-pattern',
    label: 'Importer',
    description: 'Charger un pattern existant',
    icon: Upload,
    action: 'import'
  },
  {
    id: 'thread-library',
    label: 'Couleurs DMC',
    description: 'Gérer votre collection',
    icon: Palette,
    action: 'threads'
  },
  {
    id: 'community',
    label: 'Communauté',
    description: 'Partager & découvrir',
    icon: Users,
    action: 'community'
  }
];

export default function StudioTools({ onToolClick }) {
  return (
    <div className="space-y-4">
      <div>
        <h3 className="text-sm font-light text-white mb-1">Outils</h3>
        <p className="text-xs text-gray-500">Actions rapides</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {tools.map((tool, idx) => {
          const IconComponent = tool.icon;
          return (
            <motion.button
              key={tool.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: idx * 0.08 }}
              onClick={() => onToolClick(tool.action)}
              className="group relative rounded-xl border border-gray-700/30 bg-gray-800/30 p-4 hover:border-emerald-500/30 hover:bg-gray-800/50 transition space-y-2 text-center"
            >
              <div className="flex justify-center mb-2">
                <IconComponent className="w-5 h-5 text-gray-400 group-hover:text-emerald-400 transition" />
              </div>
              <div>
                <div className="text-xs font-light text-white">{tool.label}</div>
                <div className="text-xs text-gray-500 mt-0.5">{tool.description}</div>
              </div>
            </motion.button>
          );
        })}
      </div>
    </div>
  );
}