import React, { useState } from 'react';
import { ChevronDown, Filter } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function PatternFilters({ 
  onFiltersChange,
  difficulties = ['debutant', 'intermediaire', 'avance'],
  sizes = ['petit', 'moyen', 'grand']
}) {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedDifficulty, setSelectedDifficulty] = useState([]);
  const [selectedSize, setSelectedSize] = useState([]);
  const [selectedTags, setSelectedTags] = useState([]);

  const commonTags = ['nature', 'floral', 'geometric', 'portrait', 'animals', 'abstract'];

  const handleDifficultyToggle = (difficulty) => {
    const updated = selectedDifficulty.includes(difficulty)
      ? selectedDifficulty.filter(d => d !== difficulty)
      : [...selectedDifficulty, difficulty];
    setSelectedDifficulty(updated);
    onFiltersChange({ difficulty: updated, size: selectedSize, tags: selectedTags });
  };

  const handleSizeToggle = (size) => {
    const updated = selectedSize.includes(size)
      ? selectedSize.filter(s => s !== size)
      : [...selectedSize, size];
    setSelectedSize(updated);
    onFiltersChange({ difficulty: selectedDifficulty, size: updated, tags: selectedTags });
  };

  const handleTagToggle = (tag) => {
    const updated = selectedTags.includes(tag)
      ? selectedTags.filter(t => t !== tag)
      : [...selectedTags, tag];
    setSelectedTags(updated);
    onFiltersChange({ difficulty: selectedDifficulty, size: selectedSize, tags: updated });
  };

  const handleReset = () => {
    setSelectedDifficulty([]);
    setSelectedSize([]);
    setSelectedTags([]);
    onFiltersChange({ difficulty: [], size: [], tags: [] });
  };

  const filterCount = selectedDifficulty.length + selectedSize.length + selectedTags.length;

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg border transition-all ${
          filterCount > 0
            ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-400'
            : 'bg-gray-800/30 border-gray-700 text-gray-400 hover:border-gray-600'
        }`}
      >
        <Filter className="w-4 h-4" />
        <span className="text-sm font-medium">Filtres</span>
        {filterCount > 0 && (
          <span className="ml-1 px-2 py-0.5 bg-emerald-500/30 rounded text-xs">{filterCount}</span>
        )}
        <ChevronDown className={`w-3 h-3 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="absolute top-full mt-2 left-0 w-96 bg-gray-900/95 border border-gray-700 rounded-lg shadow-xl z-20 p-4 space-y-4"
          >
            {/* Difficulty */}
            <div className="space-y-2">
              <p className="text-xs uppercase text-gray-400 font-light tracking-wider">Difficulté</p>
              <div className="grid grid-cols-3 gap-2">
                {difficulties.map(diff => (
                  <button
                    key={diff}
                    onClick={() => handleDifficultyToggle(diff)}
                    className={`px-3 py-1.5 rounded-lg border text-xs font-light transition capitalize ${
                      selectedDifficulty.includes(diff)
                        ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-400'
                        : 'bg-gray-800/30 border-gray-700 text-gray-400 hover:border-gray-600'
                    }`}
                  >
                    {diff}
                  </button>
                ))}
              </div>
            </div>

            {/* Size */}
            <div className="space-y-2">
              <p className="text-xs uppercase text-gray-400 font-light tracking-wider">Taille</p>
              <div className="grid grid-cols-3 gap-2">
                {sizes.map(size => (
                  <button
                    key={size}
                    onClick={() => handleSizeToggle(size)}
                    className={`px-3 py-1.5 rounded-lg border text-xs font-light transition capitalize ${
                      selectedSize.includes(size)
                        ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-400'
                        : 'bg-gray-800/30 border-gray-700 text-gray-400 hover:border-gray-600'
                    }`}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>

            {/* Tags */}
            <div className="space-y-2">
              <p className="text-xs uppercase text-gray-400 font-light tracking-wider">Catégories</p>
              <div className="flex flex-wrap gap-2">
                {commonTags.map(tag => (
                  <button
                    key={tag}
                    onClick={() => handleTagToggle(tag)}
                    className={`px-2.5 py-1 rounded-full border text-xs font-light transition capitalize ${
                      selectedTags.includes(tag)
                        ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-400'
                        : 'bg-gray-800/30 border-gray-700 text-gray-400 hover:border-gray-600'
                    }`}
                  >
                    {tag}
                  </button>
                ))}
              </div>
            </div>

            {/* Reset */}
            {filterCount > 0 && (
              <button
                onClick={handleReset}
                className="w-full px-3 py-1.5 rounded-lg bg-gray-800/30 border border-gray-700 text-gray-400 hover:border-red-500/30 hover:text-red-400 transition text-xs font-light"
              >
                Réinitialiser
              </button>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}