import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { CheckCircle2 } from 'lucide-react';

export default function PatternCard({ pattern, completedSession, progressPercentage, onSelect }) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      onClick={() => onSelect(pattern)}
      className="cursor-pointer group"
    >
      <div className="relative rounded-2xl overflow-hidden bg-gray-900/40 backdrop-blur-xl border border-gray-800/50 transition-all duration-300 hover:border-emerald-500/50">
        {/* Visual Preview */}
        <div className="relative h-40 bg-gradient-to-br from-gray-800 to-gray-900 overflow-hidden">
          {/* Grid pattern background */}
          <div className="absolute inset-0 opacity-30">
            <svg className="w-full h-full" viewBox="0 0 100 100">
              <pattern id={`grid-${pattern.id}`} x="10" y="10" width="10" height="10" patternUnits="userSpaceOnUse">
                <circle cx="5" cy="5" r="1" fill="currentColor" className="text-emerald-400" />
              </pattern>
              <rect width="100" height="100" fill={`url(#grid-${pattern.id})`} />
            </svg>
          </div>

          {/* Color Palette Preview */}
          {pattern.dmc_palette?.length > 0 && (
            <div className="absolute inset-0 flex items-center justify-center gap-1 p-4">
              {pattern.dmc_palette.slice(0, 5).map((p, i) => (
                <motion.div
                  key={p.dmc_code}
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: i * 0.05 }}
                  className="w-8 h-8 rounded-lg border border-white/20 shadow-lg"
                  style={{ backgroundColor: p.color }}
                />
              ))}
            </div>
          )}

          {/* Status Badge */}
          {(completedSession || progressPercentage > 0) && (
            <div className="absolute top-3 right-3">
              {completedSession ? (
                <div className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-emerald-500/20 border border-emerald-500/30 backdrop-blur-sm">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-xs font-medium text-emerald-400">Terminé</span>
                </div>
              ) : (
                <div className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-cyan-500/20 border border-cyan-500/30 backdrop-blur-sm">
                  <span className="text-xs font-medium text-cyan-400">{progressPercentage}%</span>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Content */}
        <div className="p-4 space-y-3">
          <div>
            <h3 className="font-semibold text-white group-hover:text-emerald-400 transition-colors">
              {pattern.title}
            </h3>
            <p className="text-xs text-gray-400 mt-1 line-clamp-2">{pattern.description}</p>
          </div>

          {/* Meta Info */}
          <div className="flex items-center gap-2 text-xs text-gray-400">
            <span className="px-2 py-1 rounded bg-gray-800/50 border border-gray-700/50">
              {pattern.grid_width}×{pattern.grid_height}
            </span>
            <span className="px-2 py-1 rounded bg-gray-800/50 border border-gray-700/50">
              {pattern.dmc_palette?.length || 0} couleurs
            </span>
            <span className="px-2 py-1 rounded bg-gray-800/50 border border-gray-700/50">
              {pattern.total_stitches || 0} pts
            </span>
          </div>
        </div>
      </div>
    </motion.div>
  );
}