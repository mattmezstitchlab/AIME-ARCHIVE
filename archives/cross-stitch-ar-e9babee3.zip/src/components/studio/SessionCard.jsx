import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Play, Trash2 } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  AlertDialog,
  AlertDialogTrigger,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogFooter,
  AlertDialogCancel,
  AlertDialogAction,
} from "@/components/ui/alert-dialog";

export default function SessionCard({ session, pattern, onPlay, onDelete }) {
  const [isHovered, setIsHovered] = useState(false);

  if (!pattern) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
    >
      <div className="group relative">
        {/* Blur background on hover */}
        {isHovered && (
          <motion.div
            layoutId={`blur-${session.id}`}
            className="absolute inset-0 bg-gradient-to-br from-emerald-500/10 via-transparent to-transparent rounded-2xl"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          />
        )}

        <div className="relative bg-gray-900/40 backdrop-blur-xl border border-gray-800/50 rounded-2xl p-6 transition-all duration-300 hover:border-emerald-500/50">
          {/* Visual Grid Indicator */}
          <div className="w-full h-20 rounded-xl bg-gradient-to-br from-gray-800 to-gray-900 mb-4 flex items-center justify-center relative overflow-hidden">
            <div className="absolute inset-0 opacity-20">
              <svg className="w-full h-full" viewBox="0 0 100 100">
                <pattern id={`grid-${session.id}`} x="10" y="10" width="10" height="10" patternUnits="userSpaceOnUse">
                  <circle cx="5" cy="5" r="1" fill="currentColor" className="text-emerald-400" />
                </pattern>
                <rect width="100" height="100" fill={`url(#grid-${session.id})`} />
              </svg>
            </div>
            <span className="relative text-xs font-medium text-gray-400">{pattern.grid_width}×{pattern.grid_height}</span>
          </div>

          {/* Content */}
          <div className="space-y-3">
            <div>
              <h3 className="font-semibold text-white text-lg">{pattern.title}</h3>
              <p className="text-xs text-gray-400 mt-1">
                {session.points_completed?.length || 0} / {session.total_stitches} points brodés
              </p>
            </div>

            {/* Progress Bar */}
            <div className="space-y-1">
              <div className="h-1.5 bg-gray-800 rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${session.progress_percentage || 0}%` }}
                  className="h-full bg-gradient-to-r from-emerald-400 to-cyan-400"
                  transition={{ delay: 0.2, duration: 0.6 }}
                />
              </div>
              <span className="text-xs text-emerald-400 font-medium">{session.progress_percentage || 0}% complet</span>
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-2 mt-4 pt-4 border-t border-gray-800/30">
            <Button
              onClick={() => onPlay(session)}
              className="flex-1 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-400 border border-emerald-500/30 rounded-lg text-sm"
              variant="ghost"
            >
              <Play className="w-3 h-3 mr-2" />
              Reprendre
            </Button>

            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-gray-400 hover:text-red-400 hover:bg-red-500/10"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent className="bg-gray-900 border-gray-800">
                <AlertDialogHeader>
                  <AlertDialogTitle className="text-white">Supprimer cette session?</AlertDialogTitle>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel className="bg-gray-800 border-gray-700 text-white">Annuler</AlertDialogCancel>
                  <AlertDialogAction 
                    onClick={() => onDelete(session.id)}
                    className="bg-red-500/20 hover:bg-red-500/30 text-red-400"
                  >
                    Supprimer
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>
      </div>
    </motion.div>
  );
}