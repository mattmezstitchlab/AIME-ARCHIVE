import React from 'react';
import { motion } from 'framer-motion';
import { ChevronRight, Grid3x3, Zap, BookOpen, Settings } from 'lucide-react';

const guides = [
  {
    id: 'getting-started',
    title: 'Démarrer',
    description: 'Créez votre premier pattern',
    icon: Grid3x3,
    color: 'from-emerald-500 to-cyan-500',
    steps: ['Créer un pattern', 'Positionner la grille', 'Lancer le AR']
  },
  {
    id: 'ar-calibration',
    title: 'Calibration AR',
    description: 'Alignez la grille à votre tissu',
    icon: Zap,
    color: 'from-purple-500 to-pink-500',
    steps: ['Mode Adjust', 'Positionner & pivoter', 'Verrouiller']
  },
  {
    id: 'guide-mode',
    title: 'Mode Guidé',
    description: 'Brodez avec une voix calme',
    icon: BookOpen,
    color: 'from-blue-500 to-cyan-500',
    steps: ['Activer la voix', 'Suivre les points', 'Progresser']
  },
  {
    id: 'thread-management',
    title: 'Gestion des fils',
    description: 'Organisez votre collection DMC',
    icon: Settings,
    color: 'from-orange-500 to-red-500',
    steps: ['Ajouter aux souhaits', 'Marquer comme possédé', 'Filtrer']
  }
];

export default function StudioGuides() {
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-sm font-light text-white mb-1">Guides & Tutoriels</h3>
        <p className="text-xs text-gray-500">Apprenez à maîtriser chaque mode</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {guides.map((guide, idx) => {
          const IconComponent = guide.icon;
          return (
            <motion.button
              key={guide.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="group relative overflow-hidden rounded-xl border border-gray-700/30 bg-gray-800/20 p-4 text-left hover:border-gray-600/50 transition"
            >
              {/* Background gradient */}
              <div className={`absolute inset-0 bg-gradient-to-br ${guide.color} opacity-0 group-hover:opacity-5 transition duration-300`} />
              
              {/* Content */}
              <div className="relative z-10 space-y-3">
                <div className="flex items-start justify-between">
                  <div className={`p-2 rounded-lg bg-gradient-to-br ${guide.color} text-white`}>
                    <IconComponent className="w-4 h-4" />
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-600 group-hover:text-gray-400 transition translate-x-0 group-hover:translate-x-1" />
                </div>

                <div>
                  <h4 className="text-sm font-light text-white">{guide.title}</h4>
                  <p className="text-xs text-gray-500 mt-0.5">{guide.description}</p>
                </div>

                <div className="flex gap-1 flex-wrap pt-2">
                  {guide.steps.map((step, i) => (
                    <span key={i} className="text-xs px-2 py-1 rounded bg-gray-700/30 text-gray-400">
                      {step}
                    </span>
                  ))}
                </div>
              </div>
            </motion.button>
          );
        })}
      </div>
    </div>
  );
}