import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, Palette, User, Menu, X } from 'lucide-react';
import { Button } from "@/components/ui/button";

export default function StudioHeader({ onNavigate }) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="fixed top-0 left-0 right-0 z-50 bg-black/30 backdrop-blur-2xl border-b border-gray-800/50"
    >
      <div className="max-w-7xl mx-auto px-4 md:px-8 py-4 flex items-center justify-between">
        {/* Left */}
        <div className="flex items-center gap-3 md:gap-6 flex-1 min-w-0">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => onNavigate('Home')}
            className="text-gray-400 hover:text-white hover:bg-gray-800/30 flex-shrink-0"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="hidden sm:block min-w-0">
            <h1 className="text-lg font-light tracking-tight text-white truncate">Studio Broderie</h1>
            <p className="text-xs text-gray-500">Créez et lancez vos patterns</p>
          </div>
          <h1 className="sm:hidden text-sm font-light text-white">Studio</h1>
        </div>

        {/* Right - Desktop */}
         <div className="hidden md:flex items-center gap-3">
         </div>

        {/* Mobile Menu Button */}
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="md:hidden text-gray-400 hover:text-white hover:bg-gray-800/30 flex-shrink-0"
        >
          {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </Button>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="md:hidden border-t border-gray-800/50 bg-black/50 backdrop-blur-xl"
        >
          <div className="px-4 py-3 space-y-2">
            <p className="text-xs text-gray-500 px-3">Utilisez les outils dans la section Studio</p>
          </div>
        </motion.div>
      )}
    </motion.div>
  );
}