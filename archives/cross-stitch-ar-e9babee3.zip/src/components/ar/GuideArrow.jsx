import React from 'react';
import { motion } from 'framer-motion';

export default function GuideArrow({ 
  targetPosition, 
  isVisible = true,
  corners,
  gridWidth,
  gridHeight,
  arrowSize = 1,
  highlightSize = 1
}) {
  if (!isVisible || !targetPosition || !corners || corners.length !== 4) {
    return null;
  }

  const { x, y } = targetPosition;
  const topLeft = corners[0];
  const topRight = corners[1];
  const bottomLeft = corners[3];

  const cellWidth = (topRight.x - topLeft.x) / gridWidth;
  const cellHeight = (bottomLeft.y - topLeft.y) / gridHeight;

  const centerX = topLeft.x + (x + 0.5) * cellWidth;
  const centerY = topLeft.y + (y + 0.5) * cellHeight;

  const highlightScale = 60 * highlightSize;
  const arrowScale = 40 * arrowSize;

  return (
    <div className="absolute inset-0 z-20 pointer-events-none">
      {/* Enhanced pulsing glow effect */}
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ 
          scale: [1, 1.4, 1],
          opacity: [0.5, 0.8, 0.5]
        }}
        transition={{
          duration: 2,
          repeat: Infinity,
          ease: "easeInOut"
        }}
        style={{
          position: 'absolute',
          left: centerX - (highlightScale + 40) / 2,
          top: centerY - (highlightScale + 40) / 2,
          width: highlightScale + 40,
          height: highlightScale + 40,
        }}
        className="rounded-full"
      >
        <div className="w-full h-full rounded-full bg-gradient-radial from-emerald-500/40 via-emerald-500/20 to-transparent" />
      </motion.div>

      {/* Outer pulsing ring */}
      <motion.div
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.5, 0.8, 0.5],
        }}
        transition={{
          duration: 1.5,
          repeat: Infinity,
          ease: "easeInOut"
        }}
        style={{
          position: 'absolute',
          left: centerX - (highlightScale + 30) / 2,
          top: centerY - (highlightScale + 30) / 2,
          width: highlightScale + 30,
          height: highlightScale + 30,
        }}
        className="border-4 border-emerald-400/50 rounded-full"
      />

      {/* Main target ring with enhanced visibility */}
      <motion.div
        initial={{ scale: 0, opacity: 0 }}
        animate={{ 
          scale: 1, 
          opacity: 1
        }}
        transition={{ type: "spring", stiffness: 200, damping: 10 }}
        style={{
          position: 'absolute',
          left: centerX - highlightScale / 2,
          top: centerY - highlightScale / 2,
          width: highlightScale,
          height: highlightScale,
          boxShadow: '0 0 30px rgba(52, 211, 153, 0.6)',
        }}
        className="border-[6px] border-emerald-400 rounded-full"
      >
        <motion.div
          animate={{
            boxShadow: [
              '0 0 20px rgba(52, 211, 153, 0.5)',
              '0 0 40px rgba(52, 211, 153, 0.8)',
              '0 0 20px rgba(52, 211, 153, 0.5)',
            ]
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="w-full h-full rounded-full"
        />
      </motion.div>

      {/* Inner highlight circle */}
      <motion.div
        animate={{
          scale: [1, 1.15, 1],
        }}
        transition={{
          duration: 1.5,
          repeat: Infinity,
          ease: "easeInOut"
        }}
        style={{
          position: 'absolute',
          left: centerX - (highlightScale * 0.5) / 2,
          top: centerY - (highlightScale * 0.5) / 2,
          width: highlightScale * 0.5,
          height: highlightScale * 0.5,
        }}
        className="bg-emerald-400/30 border-2 border-emerald-300 rounded-full"
      />

      {/* Central dot */}
      <motion.div
        animate={{ 
          scale: [1, 1.3, 1]
        }}
        transition={{
          duration: 1,
          repeat: Infinity,
          ease: "easeInOut"
        }}
        style={{
          position: 'absolute',
          left: centerX - 8,
          top: centerY - 8,
          width: 16,
          height: 16,
        }}
        className="bg-emerald-400 rounded-full shadow-lg"
      />

      {/* Enhanced 3D arrow */}
      <motion.div
        initial={{ y: -20, opacity: 0 }}
        animate={{ 
          y: [-10, 10, -10],
          opacity: 1
        }}
        transition={{
          y: {
            duration: 1.2,
            repeat: Infinity,
            ease: "easeInOut"
          },
          opacity: { duration: 0.3 }
        }}
        style={{
          position: 'absolute',
          left: centerX - (arrowScale * 1.5) / 2,
          top: centerY - 120 * arrowSize,
        }}
      >
        <svg 
          width={arrowScale * 1.5} 
          height={arrowScale * 2.5} 
          viewBox="0 0 60 100" 
          fill="none"
          style={{ filter: 'drop-shadow(0 4px 12px rgba(52, 211, 153, 0.6))' }}
        >
          <defs>
            <linearGradient id="arrowGradient" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#10B981" />
              <stop offset="100%" stopColor="#34D399" />
            </linearGradient>
          </defs>
          
          {/* Main shaft */}
          <rect x="26" y="0" width="8" height="55" fill="url(#arrowGradient)" rx="4" />
          
          {/* Arrow head - 3D effect */}
          <path
            d="M30 50 L10 35 L15 40 L30 55 L45 40 L50 35 Z"
            fill="#10B981"
            opacity="0.7"
          />
          <path
            d="M30 55 L5 30 L30 60 L55 30 Z"
            fill="url(#arrowGradient)"
          />
          
          {/* Tip circle */}
          <circle cx="30" cy="75" r="10" fill="#34D399">
            <animate attributeName="r" values="10;12;10" dur="1.5s" repeatCount="indefinite" />
          </circle>
          <circle cx="30" cy="75" r="6" fill="#10B981" />
        </svg>
      </motion.div>

      {/* Enhanced coordinate label */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ 
          opacity: 1, 
          y: 0
        }}
        transition={{ delay: 0.3 }}
        style={{
          position: 'absolute',
          left: centerX,
          top: centerY + 60 * highlightSize,
          transform: 'translateX(-50%)'
        }}
        className="bg-gradient-to-r from-gray-900 to-gray-800 backdrop-blur-md px-4 py-2 rounded-full border-2 border-emerald-400 shadow-lg"
      >
        <motion.div
          animate={{
            boxShadow: [
              '0 4px 20px rgba(52, 211, 153, 0.3)',
              '0 4px 30px rgba(52, 211, 153, 0.5)',
              '0 4px 20px rgba(52, 211, 153, 0.3)',
            ]
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="flex items-center gap-2"
        >
          <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-base font-mono font-bold text-emerald-300">
            {x + 1}, {y + 1}
          </span>
        </motion.div>
      </motion.div>

      {/* Pointing line from corner */}
      <svg className="absolute inset-0 w-full h-full" style={{ pointerEvents: 'none' }}>
        <motion.line
          x1={topLeft.x}
          y1={topLeft.y}
          x2={centerX}
          y2={centerY}
          stroke="#34D399"
          strokeWidth="2"
          strokeDasharray="5,5"
          opacity="0.3"
          initial={{ pathLength: 0 }}
          animate={{ pathLength: 1 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        />
      </svg>
    </div>
  );
}