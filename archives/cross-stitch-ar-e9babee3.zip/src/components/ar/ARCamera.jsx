import React, { useRef, useEffect, useState } from 'react';
import { Camera, CameraOff, RotateCcw } from 'lucide-react';
import { Button } from "@/components/ui/button";

export default function ARCamera({ onStreamReady, onError, isActive = true }) {
  const videoRef = useRef(null);
  const [hasPermission, setHasPermission] = useState(null);
  const [facingMode, setFacingMode] = useState('environment');
  const streamRef = useRef(null);

  const startCamera = async () => {
    try {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
      }

      const constraints = {
        video: {
          facingMode: facingMode,
          width: { ideal: 1920 },
          height: { ideal: 1080 }
        }
      };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      streamRef.current = stream;
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
        setHasPermission(true);
        onStreamReady?.(videoRef.current, stream);
      }
    } catch (err) {
      console.error('Camera error:', err);
      setHasPermission(false);
      onError?.(err);
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
  };

  const switchCamera = async () => {
    setFacingMode(prev => prev === 'environment' ? 'user' : 'environment');
  };

  useEffect(() => {
    if (isActive) {
      startCamera();
    } else {
      stopCamera();
    }

    return () => stopCamera();
  }, [isActive, facingMode]);

  if (hasPermission === false) {
    return (
      <div className="absolute inset-0 flex flex-col items-center justify-center bg-gray-900 text-white">
        <CameraOff className="w-16 h-16 mb-4 text-gray-500" />
        <p className="text-lg mb-2">Accès caméra refusé</p>
        <p className="text-sm text-gray-400 text-center px-8 mb-4">
          Autorisez l'accès à la caméra dans les paramètres de votre navigateur
        </p>
        <Button onClick={startCamera} variant="outline" className="bg-white/10">
          <Camera className="w-4 h-4 mr-2" />
          Réessayer
        </Button>
      </div>
    );
  }

  return (
    <>
      <video
        ref={videoRef}
        autoPlay
        playsInline
        muted
        className="absolute inset-0 w-full h-full object-cover"
        style={{ transform: facingMode === 'user' ? 'scaleX(-1)' : 'none' }}
      />
      
      <Button
        onClick={switchCamera}
        variant="ghost"
        size="icon"
        className="absolute top-4 right-4 z-20 bg-black/30 hover:bg-black/50 text-white rounded-full w-10 h-10"
      >
        <RotateCcw className="w-5 h-5" />
      </Button>
    </>
  );
}