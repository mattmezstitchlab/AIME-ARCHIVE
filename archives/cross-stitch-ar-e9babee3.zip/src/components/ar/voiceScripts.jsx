/**
 * French voice scripts for Pattern Live AR
 * Natural, expert, calm tone — no repetition, no robotic feel
 */

export const VOICE_SCRIPTS = {
  // CAPTURE PHASE
  scan_intro: {
    text: 'Prenez votre temps. Placez simplement votre motif face à l\'appareil. Quand il est bien visible dans le cadre, vous pouvez capturer.',
    cooldownMs: 60000
  },
  
  capture_done: {
    text: 'Parfait. L\'image est capturée. Nous allons maintenant ajuster le motif pour qu\'il corresponde exactement à la grille.',
    cooldownMs: 60000
  },
  
  // RETAKE
  retake_voice: {
    text: 'D\'accord, recommençons.',
    cooldownMs: 30000
  },

  // MODE SELECTION
  calibration_mode: {
    text: 'Choisissez le mode d\'alignement qui vous convient.',
    cooldownMs: 30000
  },

  // CALIBRATION - FAST (2 points)
  calib_fast_intro: {
    text: 'Touchez d\'abord le coin haut gauche du motif. Puis le coin bas droit. Cela me permettra d\'aligner la grille correctement.',
    cooldownMs: 60000
  },

  calib_point_1: {
    text: 'Point 1 enregistré. Un dernier point.',
    cooldownMs: 15000
  },

  // CALIBRATION - PRECISE (4 points)
  calib_precise_intro: {
    text: 'Nous allons être un peu plus précis. Touchez les quatre coins du motif, dans l\'ordre. Prenez votre temps, je m\'adapte à vous.',
    cooldownMs: 60000
  },

  calib_point_2: {
    text: 'Très bien. Encore un point…',
    cooldownMs: 15000
  },

  calib_point_3: {
    text: 'Parfait. Le dernier.',
    cooldownMs: 15000
  },

  // VALIDATION
  calibration_ok: {
    text: 'C\'est validé. La grille est maintenant parfaitement alignée. Vous pouvez commencer à broder.',
    cooldownMs: 60000
  },

  // ERROR
  camera_permission: {
    text: 'Permission caméra refusée.',
    cooldownMs: 30000
  }
};

/**
 * Helper function to speak a script
 * Usage: speakScript('scan_intro')
 */
export function getSpeechText(scriptKey) {
  const script = VOICE_SCRIPTS[scriptKey];
  return script?.text || '';
}

export function getSpeechOptions(scriptKey) {
  const script = VOICE_SCRIPTS[scriptKey];
  return {
    cooldownMs: script?.cooldownMs || 30000,
    rate: 0.88,
    pitch: 0.95,
    volume: 0.9
  };
}