import React from 'react';
import { motion } from 'framer-motion';
import { AlertCircle, RotateCcw } from 'lucide-react';

export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught:', error, errorInfo);
    this.setState({ error, errorInfo });
  }

  handleRetry = () => {
    this.setState({ hasError: false, error: null, errorInfo: null });
  };

  render() {
    if (this.state.hasError) {
      return (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="fixed inset-0 bg-black flex items-center justify-center z-50 p-4"
        >
          <div className="w-full max-w-md bg-black border border-red-500/30 rounded-lg p-6 text-center space-y-4">
            <div className="flex justify-center">
              <AlertCircle className="w-12 h-12 text-red-500" />
            </div>
            <div>
              <h2 className="text-white text-lg font-semibold">Oups — quelque chose s'est mal chargé</h2>
              <p className="text-gray-400 text-sm mt-2">
                L'app a rencontré une erreur. Réessaye ou contacte le support.
              </p>
            </div>

            {/* Debug info (dev only) */}
            {process.env.NODE_ENV !== 'production' && this.state.error && (
              <div className="bg-red-950/40 rounded p-3 text-left text-xs text-gray-300 max-h-32 overflow-auto border border-red-700/20">
                <p className="font-mono text-red-400">{this.state.error.toString()}</p>
                {this.state.errorInfo?.componentStack && (
                  <pre className="text-gray-400 mt-2 whitespace-pre-wrap break-words">
                    {this.state.errorInfo.componentStack.split('\n').slice(0, 5).join('\n')}
                  </pre>
                )}
              </div>
            )}

            <button
              onClick={this.handleRetry}
              className="w-full py-2 px-4 bg-emerald-500 hover:bg-emerald-600 text-white rounded-lg font-medium transition flex items-center justify-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              Réessayer
            </button>
          </div>
        </motion.div>
      );
    }

    return this.props.children;
  }
}