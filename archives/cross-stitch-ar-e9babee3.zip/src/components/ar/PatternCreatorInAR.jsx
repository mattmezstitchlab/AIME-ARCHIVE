import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useMutation } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Save, X, Pencil, Eraser, Upload, Sparkles } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import GridEditor from '@/components/creator/GridEditor';
import DMCColorManager from '@/components/creator/DMCColorManager';

export default function PatternCreatorInAR({
  onSave,
  onBack
}) {
  // Pattern info
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [gridWidth, setGridWidth] = useState(15);
  const [gridHeight, setGridHeight] = useState(15);

  // Drawing state
  const [gridData, setGridData] = useState({});
  const [palette, setPalette] = useState([]);
  const [selectedColor, setSelectedColor] = useState(null);
  const [isErasing, setIsErasing] = useState(false);
  const [uploadedImage, setUploadedImage] = useState(null);
  const [isUploading, setIsUploading] = useState(false);
  const [showGridEditor, setShowGridEditor] = useState(true);

  const createPatternMutation = useMutation({
    mutationFn: (data) => base44.entities.Pattern.create(data),
    onSuccess: (newPattern) => {
      toast.success('Pattern créé !');
      onSave(newPattern);
    },
    onError: (error) => {
      toast.error('Erreur: ' + error.message);
    }
  });

  const handleImageUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setUploadedImage(file_url);
      
      // Analyze image
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze this cross-stitch pattern image. Extract: grid dimensions, distinct colors with hex codes and closest DMC codes, suitable symbols. Return ONLY valid JSON.`,
        file_urls: [file_url],
        response_json_schema: {
          type: "object",
          properties: {
            grid_width: { type: "number" },
            grid_height: { type: "number" },
            dmc_palette: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  dmc_code: { type: "string" },
                  color: { type: "string" },
                  symbol: { type: "string" },
                  name: { type: "string" }
                }
              }
            },
            grid_data: { type: "object" }
          }
        }
      });

      if (result.grid_width && result.grid_height) {
        setGridWidth(Math.min(50, result.grid_width));
        setGridHeight(Math.min(50, result.grid_height));
      }
      if (result.dmc_palette) setPalette(result.dmc_palette);
      if (result.grid_data) setGridData(result.grid_data);
      
      toast.success('Pattern analysé!');
      setShowGridEditor(true);
    } catch (error) {
      toast.error('Erreur: ' + error.message);
    } finally {
      setIsUploading(false);
    }
  };

  const handleSavePattern = async () => {
    if (!title.trim()) {
      toast.error('Donnez un titre');
      return;
    }
    if (palette.length === 0) {
      toast.error('Ajoutez une couleur');
      return;
    }
    if (Object.keys(gridData).length === 0) {
      toast.error('Dessinez quelque chose!');
      return;
    }

    const patternData = {
      title: title.trim(),
      description: description.trim(),
      grid_width: gridWidth,
      grid_height: gridHeight,
      grid_data: gridData,
      dmc_palette: palette,
      total_stitches: Object.keys(gridData).length,
      difficulty: Object.keys(gridData).length < 50 ? 'debutant' : 
                  Object.keys(gridData).length < 150 ? 'intermediaire' : 'avance'
    };

    await createPatternMutation.mutateAsync(patternData);
  };

  return (
    <div className="fixed inset-0 bg-black/95 z-50 flex flex-col">
      {/* Header */}
      <div className="h-16 flex items-center justify-between px-4 border-b border-gray-800 flex-shrink-0">
        <h2 className="text-white font-light">Créer un pattern</h2>
        <button
          onClick={onBack}
          className="p-2 hover:bg-gray-800/50 rounded transition text-gray-400"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto flex">
        {/* Left panel - controls */}
        <motion.div
          initial={{ x: -300, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          className="w-80 border-r border-gray-800 p-4 space-y-4 flex-shrink-0 bg-black/50"
        >
          {/* Title */}
          <div>
            <label className="text-xs text-gray-400">Titre</label>
            <Input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Mon pattern"
              className="bg-gray-900 border-gray-700 text-white mt-1"
            />
          </div>

          {/* Description */}
          <div>
            <label className="text-xs text-gray-400">Description</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="..."
              rows={3}
              className="w-full mt-1 px-3 py-2 bg-gray-900 border border-gray-700 rounded text-white text-xs"
            />
          </div>

          {/* Grid size */}
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-xs text-gray-400">Largeur</label>
              <Input
                type="number"
                value={gridWidth}
                onChange={(e) => setGridWidth(Math.max(5, Math.min(50, parseInt(e.target.value) || 15)))}
                className="bg-gray-900 border-gray-700 text-white mt-1"
              />
            </div>
            <div>
              <label className="text-xs text-gray-400">Hauteur</label>
              <Input
                type="number"
                value={gridHeight}
                onChange={(e) => setGridHeight(Math.max(5, Math.min(50, parseInt(e.target.value) || 15)))}
                className="bg-gray-900 border-gray-700 text-white mt-1"
              />
            </div>
          </div>

          {/* Stitch count */}
          <div className="text-xs text-gray-400">
            Points: <span className="text-emerald-400">{Object.keys(gridData).length}</span>
          </div>

          {/* Color manager */}
          <DMCColorManager
            palette={palette}
            onPaletteChange={setPalette}
            selectedColor={selectedColor}
            onColorSelect={(color) => {
              setSelectedColor(color);
              setIsErasing(false);
            }}
          />

          {/* Tools */}
          <div className="space-y-2 border-t border-gray-700 pt-4">
            <button
              onClick={() => setIsErasing(false)}
              className={`w-full flex items-center gap-2 px-3 py-2 rounded transition text-sm ${
                !isErasing
                  ? 'bg-emerald-500/20 border border-emerald-500/60 text-emerald-400'
                  : 'bg-gray-800/30 border border-gray-700 text-gray-400'
              }`}
            >
              <Pencil className="w-4 h-4" />
              Dessiner
            </button>
            <button
              onClick={() => setIsErasing(true)}
              className={`w-full flex items-center gap-2 px-3 py-2 rounded transition text-sm ${
                isErasing
                  ? 'bg-emerald-500/20 border border-emerald-500/60 text-emerald-400'
                  : 'bg-gray-800/30 border border-gray-700 text-gray-400'
              }`}
            >
              <Eraser className="w-4 h-4" />
              Gomme
            </button>
          </div>

          {/* Save button */}
          <Button
            onClick={handleSavePattern}
            disabled={createPatternMutation.isPending}
            className="w-full bg-emerald-500 hover:bg-emerald-600 text-white"
          >
            <Save className="w-4 h-4 mr-2" />
            {createPatternMutation.isPending ? 'Saving...' : 'Enregistrer'}
          </Button>
        </motion.div>

        {/* Right panel - canvas/editor */}
        <div className="flex-1 p-4 flex items-center justify-center">
          <AnimatePresence mode="wait">
            {!uploadedImage ? (
              <motion.div
                key="empty"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="text-center space-y-4"
              >
                <Sparkles className="w-12 h-12 text-gray-600 mx-auto" />
                <p className="text-gray-400 text-sm">Dessinez sur la grille ou importez une image</p>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                  id="pattern-image"
                />
                <Button
                  onClick={() => document.getElementById('pattern-image')?.click()}
                  disabled={isUploading}
                  className="bg-gray-800 hover:bg-gray-700 text-gray-200"
                >
                  <Upload className="w-4 h-4 mr-2" />
                  {isUploading ? 'Uploading...' : 'Importer une image'}
                </Button>
              </motion.div>
            ) : (
              <motion.img
                key="uploaded"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                src={uploadedImage}
                alt="Pattern source"
                className="max-w-full max-h-full rounded-lg"
              />
            )}
          </AnimatePresence>

          {showGridEditor && Object.keys(gridData).length > 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="absolute inset-0 flex items-center justify-center"
            >
              <GridEditor
                width={gridWidth}
                height={gridHeight}
                gridData={gridData}
                currentColor={selectedColor}
                onGridDataChange={setGridData}
                isErasing={isErasing}
              />
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
}