import React, { useEffect, useMemo, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Volume2, VolumeX, Mic, MicOff, ChevronDown, ChevronUp } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";

const DEFAULT_SCRIPT = [
  { id: '1', text: 'Bonjour. Je suis là. Tu as le temps.' },
  { id: '2', text: 'On va broder doucement. Un point à la fois.' },
  { id: '3', text: 'Si tu veux que je me taise, dis : pause.' },
  { id: '4', text: 'Si tu veux que je répète, dis : répète.' },
  { id: '5', text: 'Regarde le point lumineux. C\'est ton point de départ.' },
  { id: '6', text: 'Quand tu veux… pique ici.' },
  { id: '7', text: 'Très bien.' },
];

function isBrowser() {
  return typeof window !== 'undefined';
}

function getSpeechRecognitionCtor() {
  if (!isBrowser()) return null;
  const w = window;
  return w.SpeechRecognition || w.webkitSpeechRecognition || null;
}

export default function VoiceCompanion({ 
  title = 'Voix Compagnonne',
  script = DEFAULT_SCRIPT,
  onPointValidated,
  nextPoint,
  mode = 'guide' // 'silence', 'minimal', 'guide'
}) {
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [unlocked, setUnlocked] = useState(false);
  const [voicesReady, setVoicesReady] = useState(false);
  const [selectedVoice, setSelectedVoice] = useState(null);
  const [rate, setRate] = useState(0.9);
  const [pitch, setPitch] = useState(1.05);
  const [lastSpoken, setLastSpoken] = useState('');
  const [collapsed, setCollapsed] = useState(false);

  const [listening, setListening] = useState(false);
  const [typed, setTyped] = useState('');

  const idxRef = useRef(0);
  const lastUtteranceRef = useRef('');
  const recognitionRef = useRef(null);
  const pointCountRef = useRef(0);

  const ttsAvailable = useMemo(() => isBrowser() && 'speechSynthesis' in window, []);
  const sttCtor = useMemo(() => getSpeechRecognitionCtor(), []);
  const sttAvailable = Boolean(sttCtor);

  // Helper: Pick French female voice
  const pickFrenchVoice = () => {
    if (!ttsAvailable) return null;
    const voices = window.speechSynthesis.getVoices();
    if (!voices || !voices.length) return null;

    // Priorité 1: Voix française féminine
    const femaleKeywords = ['female', 'femme', 'amélie', 'audrey', 'marie', 'virginie', 'woman'];
    const femaleFrench = voices.find(v =>
      v.lang === 'fr-FR' && femaleKeywords.some(k => v.name.toLowerCase().includes(k.toLowerCase()))
    );
    if (femaleFrench) return femaleFrench;

    // Priorité 2: Toute voix française
    const frenchVoice = voices.find(v => v.lang === 'fr-FR');
    if (frenchVoice) return frenchVoice;

    // Priorité 3: Voix féminine en général (non-anglaise si possible)
    const nonEnglishFemale = voices.find(v =>
      !/en-/i.test(v.lang) && femaleKeywords.some(k => v.name.toLowerCase().includes(k.toLowerCase()))
    );
    if (nonEnglishFemale) return nonEnglishFemale;

    // Fallback
    return voices[0];
  };

  // Load voices
  useEffect(() => {
    if (!ttsAvailable) return;

    const synth = window.speechSynthesis;

    const load = () => {
      const v = synth.getVoices();
      if (v && v.length > 0) {
        setVoicesReady(true);
        const voice = pickFrenchVoice();
        setSelectedVoice(voice);
      }
    };

    load();
    synth.onvoiceschanged = load;

    return () => {
      synth.onvoiceschanged = null;
    };
  }, [ttsAvailable]);

  // Setup speech recognition
  useEffect(() => {
    if (!sttAvailable) return;

    const Rec = sttCtor;
    const rec = new Rec();
    rec.lang = 'fr-FR';
    rec.interimResults = false;
    rec.maxAlternatives = 1;

    rec.onresult = (e) => {
      const transcript = (e.results?.[0]?.[0]?.transcript ?? '').toString().trim();
      if (transcript) handleUserCommand(transcript);
    };

    rec.onerror = () => setListening(false);
    rec.onend = () => setListening(false);

    recognitionRef.current = rec;

    return () => {
      recognitionRef.current = null;
    };
  }, [sttAvailable, sttCtor]);

  function getCurrentVoice() {
    if (selectedVoice) return selectedVoice;
    return pickFrenchVoice();
  }

  function stopSpeaking() {
    if (!ttsAvailable) return;
    window.speechSynthesis.cancel();
  }

  function speak(text) {
    if (!ttsAvailable) return;
    if (!voiceEnabled) return;
    if (!unlocked) return;
    if (mode === 'silence') return;

    stopSpeaking();

    const utter = new SpeechSynthesisUtterance(text);
    const voice = getCurrentVoice();
    if (voice) {
      utter.voice = voice;
    }
    utter.lang = 'fr-FR';
    utter.rate = rate;
    utter.pitch = pitch;

    lastUtteranceRef.current = text;
    setLastSpoken(text);

    window.speechSynthesis.speak(utter);
  }

  function speakCurrent() {
    const current = script[idxRef.current]?.text;
    if (current) speak(current);
  }

  function next() {
    idxRef.current = Math.min(idxRef.current + 1, script.length - 1);
    speakCurrent();
  }

  function previous() {
    idxRef.current = Math.max(idxRef.current - 1, 0);
    speakCurrent();
  }

  function replay() {
    const t = lastUtteranceRef.current || script[idxRef.current]?.text;
    if (t) speak(t);
  }

  function unlockAudio() {
    setUnlocked(true);
    if (voiceEnabled && ttsAvailable) {
      speak('Bonjour. Je suis là. Tu as le temps.');
    }
  }

  function handleUserCommand(raw) {
    const text = raw.toLowerCase();

    if (text.includes('pause') || text.includes('stop')) {
      stopSpeaking();
      speak('D\'accord. Pause.');
      setTimeout(() => stopSpeaking(), 1500);
      return;
    }
    if (text.includes('rép') || text.includes('rep')) {
      replay();
      return;
    }
    if (text.includes('continue') || text.includes('on y va') || text.includes('vas-y') || text.includes('allez')) {
      speak('D\'accord. On continue.');
      next();
      return;
    }
    if (text.includes('plus lent') || text.includes('ralentis') || text.includes('ralentir')) {
      setRate((r) => Math.max(0.75, r - 0.1));
      speak('D\'accord. Je parle plus lentement.');
      return;
    }
    if (text.includes('plus rapide') || text.includes('accélère') || text.includes('acceler')) {
      setRate((r) => Math.min(1.2, r + 0.1));
      speak('D\'accord. Je parle un peu plus vite.');
      return;
    }
    if (text.includes('perdue') || text.includes('aide') || text.includes('help')) {
      speak('D\'accord. Respire. Regarde le point lumineux. On reprend doucement.');
      return;
    }

    speak('Je t\'ai entendue. On reprend au point lumineux.');
    speakCurrent();
  }

  function toggleListening() {
    if (!sttAvailable) return;
    const rec = recognitionRef.current;
    if (!rec) return;

    if (listening) {
      try {
        rec.stop();
      } catch {}
      setListening(false);
    } else {
      try {
        rec.start();
        setListening(true);
      } catch {
        setListening(false);
      }
    }
  }

  function submitTyped() {
    const t = typed.trim();
    if (!t) return;
    setTyped('');
    handleUserCommand(t);
  }

  // Auto-speak on point validation
  useEffect(() => {
    if (!onPointValidated) return;
    
    pointCountRef.current += 1;
    const count = pointCountRef.current;

    if (mode === 'guide') {
      speak('Très bien.');
    } else if (mode === 'minimal' && count % 5 === 0) {
      speak('Continue comme ça.');
    }
  }, [onPointValidated, mode]);

  // Auto-speak on next point change
  useEffect(() => {
    if (!nextPoint || !unlocked) return;

    if (mode === 'guide') {
      setTimeout(() => {
        speak('Quand tu veux… pique ici.');
      }, 800);
    }
  }, [nextPoint, unlocked, mode]);

  if (!ttsAvailable) {
    return null; // Browser doesn't support TTS
  }

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 20 }}
        className="fixed right-4 bottom-20 z-[60] w-80 max-w-[calc(100vw-32px)]"
      >
        <Card className="bg-gray-900/95 border-gray-700 backdrop-blur-xl">
          <CardContent className="p-4">
            {/* Header */}
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                {voiceEnabled ? (
                  <Volume2 className="w-4 h-4 text-emerald-400" />
                ) : (
                  <VolumeX className="w-4 h-4 text-gray-500" />
                )}
                <span className="text-sm font-semibold text-white">{title}</span>
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setVoiceEnabled(!voiceEnabled)}
                  className={voiceEnabled ? 'text-emerald-400' : 'text-gray-500'}
                >
                  {voiceEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setCollapsed(!collapsed)}
                  className="text-gray-400"
                >
                  {collapsed ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </Button>
              </div>
            </div>

            {!collapsed && (
              <>
                {/* Enable Voice (iOS requirement) */}
                {!unlocked && (
                  <Button
                    onClick={unlockAudio}
                    className="w-full mb-3 bg-emerald-500 hover:bg-emerald-600"
                  >
                    Activer la voix
                  </Button>
                )}

                {/* Controls */}
                <div className="flex flex-wrap gap-2 mb-3">
                  <Button
                    onClick={replay}
                    disabled={!voiceEnabled || !unlocked}
                    variant="outline"
                    size="sm"
                    className="border-gray-700"
                  >
                    Répéter
                  </Button>
                  <Button
                    onClick={stopSpeaking}
                    variant="outline"
                    size="sm"
                    className="border-gray-700"
                  >
                    Pause
                  </Button>
                  <Button
                    onClick={previous}
                    variant="outline"
                    size="sm"
                    className="border-gray-700"
                  >
                    ◀
                  </Button>
                  <Button
                    onClick={next}
                    variant="outline"
                    size="sm"
                    className="border-gray-700"
                  >
                    ▶
                  </Button>
                  {sttAvailable && (
                    <Button
                      onClick={toggleListening}
                      variant="outline"
                      size="sm"
                      className={listening ? 'border-red-500 bg-red-500/10' : 'border-gray-700'}
                    >
                      {listening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                    </Button>
                  )}
                </div>

                {/* Status */}
                <div className="text-xs text-gray-400 mb-3">
                  {voicesReady ? (
                    <>
                      ✓ Voix: {selectedVoice?.name.split('_')[0] || 'Française'}
                    </>
                  ) : (
                    'Chargement voix...'
                  )}
                  {listening && ' • 🎙️ Écoute...'}
                </div>

                {/* Last spoken */}
                <div className="bg-gray-800/50 rounded-lg p-3 mb-3">
                  <div className="text-xs text-gray-500 mb-1">Dernière phrase</div>
                  <div className="text-sm text-white leading-relaxed">
                    {lastSpoken || '…'}
                  </div>
                </div>

                {/* Text input */}
                <div className="flex gap-2 mb-3">
                  <Input
                    value={typed}
                    onChange={(e) => setTyped(e.target.value)}
                    placeholder='pause, répète, on y va...'
                    className="bg-gray-800 border-gray-700 text-white text-sm"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') submitTyped();
                    }}
                  />
                  <Button
                    onClick={submitTyped}
                    variant="outline"
                    size="sm"
                    className="border-gray-700"
                  >
                    →
                  </Button>
                </div>

                {/* Rate & Pitch controls */}
                <div className="space-y-3">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs text-gray-400">
                      <span>Vitesse</span>
                      <span>{rate.toFixed(2)}x</span>
                    </div>
                    <Slider
                      value={[rate]}
                      onValueChange={(v) => setRate(v[0])}
                      min={0.75}
                      max={1.2}
                      step={0.05}
                      className="w-full"
                    />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs text-gray-400">
                      <span>Ton</span>
                      <span>{pitch.toFixed(2)}</span>
                    </div>
                    <Slider
                      value={[pitch]}
                      onValueChange={(v) => setPitch(v[0])}
                      min={0.8}
                      max={1.5}
                      step={0.05}
                      className="w-full"
                    />
                  </div>
                </div>

                {/* Commands hint */}
                <div className="text-xs text-gray-500 mt-3 text-center">
                  pause • répète • on y va • plus lent • plus rapide
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </AnimatePresence>
  );
}