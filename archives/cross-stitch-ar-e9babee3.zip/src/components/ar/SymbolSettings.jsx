import React from 'react';
import { motion } from 'framer-motion';
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";

export default function SymbolSettings({
  symbolDensity = 'normal',
  onDensityChange,
  showSymbols = true,
  onToggleSymbols
}) {
  const densityOptions = [
    { value: 'minimal', label: 'Minimal', desc: 'Point suivant seulement' },
    { value: 'normal', label: 'Normal', desc: 'Symboles standard' },
    { value: 'full', label: 'Complet', desc: 'Tous les symboles' }
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="space-y-3"
    >
      <div>
        <Label className="text-xs text-gray-400 block mb-2">Densité des symboles</Label>
        <div className="space-y-2">
          {densityOptions.map(option => (
            <Button
              key={option.value}
              onClick={() => onDensityChange(option.value)}
              variant={symbolDensity === option.value ? 'default' : 'outline'}
              className={`w-full justify-start text-xs h-8 ${
                symbolDensity === option.value
                  ? 'bg-purple-500 hover:bg-purple-600'
                  : 'border-gray-700'
              }`}
            >
              <div>
                <div>{option.label}</div>
                <div className="text-[10px] opacity-75">{option.desc}</div>
              </div>
            </Button>
          ))}
        </div>
      </div>

      <div className="flex items-center justify-between p-3 bg-gray-700/30 rounded-lg">
        <Label className="text-xs text-gray-300">Afficher symboles</Label>
        <input
          type="checkbox"
          checked={showSymbols}
          onChange={(e) => onToggleSymbols(e.target.checked)}
          className="w-4 h-4 cursor-pointer"
        />
      </div>
    </motion.div>
  );
}