import React from 'react';
import { motion } from 'framer-motion';
import { Play, Trash2, Archive, Clock, Calendar, Grid3X3, Share2, BarChart3 } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';

export default function SessionCard({ session, pattern, onResume, onDelete, onArchive, onShare }) {
  const formatDuration = (minutes) => {
    if (!minutes) return '0 min';
    const hours = Math.floor(minutes / 60);
    const mins = Math.round(minutes % 60);
    if (hours > 0) return `${hours}h ${mins}m`;
    return `${mins} min`;
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, x: -100 }}
    >
      <Card className="bg-gray-800/50 border-gray-700 hover:border-emerald-500/50 transition-all overflow-hidden">
        <CardContent className="p-0">
          <div className="flex flex-col sm:flex-row gap-4">
            {/* Pattern Preview */}
            <div className="sm:w-32 h-32 bg-gradient-to-br from-gray-700 to-gray-800 flex items-center justify-center flex-shrink-0">
              <Grid3X3 className="w-12 h-12 text-gray-500" />
            </div>

            {/* Session Info */}
            <div className="flex-1 p-4 min-w-0">
              <div className="flex items-start justify-between gap-2 mb-2">
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-white truncate">
                    {session.pattern_title || pattern?.title || 'Pattern'}
                  </h3>
                  <div className="flex items-center gap-2 mt-1 flex-wrap">
                    <Badge variant="secondary" className="bg-emerald-500/20 text-emerald-400 text-xs">
                      {session.progress_percentage || 0}%
                    </Badge>
                    {session.is_completed && (
                      <Badge className="bg-purple-500 text-xs">Terminé</Badge>
                    )}
                    {session.is_archived && (
                      <Badge variant="secondary" className="bg-gray-700 text-xs">Archivé</Badge>
                    )}
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <Progress 
                  value={session.progress_percentage || 0} 
                  className="h-2 bg-gray-700" 
                />

                <div className="flex items-center gap-4 text-xs text-gray-400 flex-wrap">
                  <span className="flex items-center gap-1">
                    <Grid3X3 className="w-3 h-3" />
                    {session.points_completed?.length || 0}/{session.total_stitches || pattern?.total_stitches || 0} points
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {formatDuration(session.session_duration_minutes)}
                  </span>
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    {format(new Date(session.updated_date), 'dd MMM yyyy', { locale: fr })}
                  </span>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex sm:flex-col gap-2 p-4 border-t sm:border-t-0 sm:border-l border-gray-700">
              {!session.is_completed ? (
                <Button
                  onClick={() => onResume(session)}
                  className="bg-emerald-500 hover:bg-emerald-600 flex-1 sm:flex-none"
                  size="sm"
                >
                  <Play className="w-4 h-4 sm:mr-2" />
                  <span className="hidden sm:inline">Reprendre</span>
                </Button>
              ) : (
                <Button
                  onClick={() => onShare && onShare(session)}
                  className="bg-purple-500 hover:bg-purple-600 flex-1 sm:flex-none"
                  size="sm"
                >
                  <Share2 className="w-4 h-4 sm:mr-2" />
                  <span className="hidden sm:inline">Partager</span>
                </Button>
              )}

              {!session.is_archived && !session.is_completed && (
                <Button
                  onClick={() => onArchive(session.id)}
                  variant="outline"
                  className="border-gray-700 flex-1 sm:flex-none"
                  size="sm"
                >
                  <Archive className="w-4 h-4 sm:mr-2" />
                  <span className="hidden sm:inline">Archiver</span>
                </Button>
              )}

              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button
                    variant="outline"
                    className="border-gray-700 text-red-400 hover:text-red-300 hover:border-red-500 flex-1 sm:flex-none"
                    size="sm"
                  >
                    <Trash2 className="w-4 h-4 sm:mr-2" />
                    <span className="hidden sm:inline">Supprimer</span>
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent className="bg-gray-900 border-gray-700">
                  <AlertDialogHeader>
                    <AlertDialogTitle className="text-white">
                      Supprimer cette session ?
                    </AlertDialogTitle>
                    <AlertDialogDescription>
                      Cette action est irréversible. Toute votre progression sera perdue définitivement.
                      <div className="mt-3 p-3 bg-gray-800 rounded-lg">
                        <p className="text-sm text-gray-300">
                          <strong>{session.pattern_title}</strong>
                          <br />
                          {session.points_completed?.length || 0} points complétés ({session.progress_percentage || 0}%)
                        </p>
                      </div>
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel className="bg-gray-800 border-gray-700 text-white">
                      Annuler
                    </AlertDialogCancel>
                    <AlertDialogAction 
                      onClick={() => onDelete(session.id)}
                      className="bg-red-500 hover:bg-red-600"
                    >
                      Supprimer définitivement
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}