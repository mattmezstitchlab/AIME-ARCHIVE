import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Zap, CheckCircle2, AlertCircle } from 'lucide-react';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function SmartStitchGuide({
  nextPoint,
  completedPoints = [],
  totalPoints,
  pattern,
  priorityZones = [],
  userProgress = 0
}) {
  const [suggestion, setSuggestion] = useState(null);
  const [efficacy, setEfficacy] = useState(0);

  // Calculate smart suggestion based on AR tracking and progress
  useEffect(() => {
    if (!nextPoint || !pattern) return;

    const suggestion = calculateSmartSuggestion();
    setSuggestion(suggestion);
  }, [nextPoint, completedPoints, pattern]);

  const calculateSmartSuggestion = () => {
    if (!nextPoint || !pattern?.grid_data) return null;

    const key = `${nextPoint.x}-${nextPoint.y}`;
    const pointData = pattern.grid_data[key];

    if (!pointData) return null;

    // Find related points nearby
    const nearbyPoints = getNearbyIncompletePoints(nextPoint.x, nextPoint.y, 2);
    const sameColorPoints = findSameColorPoints(pointData.dmc, nextPoint, 5);

    // Calculate efficiency score (0-100)
    let efficacyScore = 50; // base score

    // Bonus: if point is in priority zone
    if (priorityZones?.length > 0) {
      const inPriority = priorityZones.find(z => z.x === nextPoint.x && z.y === nextPoint.y);
      if (inPriority) {
        efficacyScore += inPriority.importance * 10;
      }
    }

    // Bonus: clustering (points near each other)
    efficacyScore += Math.min(nearbyPoints.length * 5, 20);

    // Bonus: color continuity
    if (sameColorPoints.length > 0) {
      efficacyScore += Math.min(sameColorPoints.length * 2, 15);
    }

    setEfficacy(Math.min(efficacyScore, 100));

    return {
      current: nextPoint,
      color: pointData.dmc,
      nearbyCount: nearbyPoints.length,
      sameColorCount: sameColorPoints.length,
      reason: generateReason(nearbyPoints.length, sameColorPoints.length, priorityZones, nextPoint),
      efficiency: Math.min(efficacyScore, 100)
    };
  };

  const getNearbyIncompletePoints = (x, y, radius) => {
    if (!pattern?.grid_data) return [];
    
    const nearby = [];
    for (let dx = -radius; dx <= radius; dx++) {
      for (let dy = -radius; dy <= radius; dy++) {
        if (dx === 0 && dy === 0) continue;
        const key = `${x + dx}-${y + dy}`;
        if (pattern.grid_data[key] && !completedPoints.includes(key)) {
          nearby.push(key);
        }
      }
    }
    return nearby;
  };

  const findSameColorPoints = (dmcCode, center, radius) => {
    if (!pattern?.grid_data) return [];
    
    const same = [];
    for (let dx = -radius; dx <= radius; dx++) {
      for (let dy = -radius; dy <= radius; dy++) {
        const key = `${center.x + dx}-${center.y + dy}`;
        const point = pattern.grid_data[key];
        if (point?.dmc === dmcCode && !completedPoints.includes(key)) {
          same.push(key);
        }
      }
    }
    return same;
  };

  const generateReason = (nearby, sameColor, priorities, point) => {
    const reasons = [];

    if (priorities?.length > 0 && priorities.some(z => z.x === point.x && z.y === point.y)) {
      reasons.push('Zone prioritaire');
    }

    if (nearby > 3) {
      reasons.push(`${nearby} points à proximité`);
    }

    if (sameColor > 2) {
      reasons.push(`Continuité couleur (${sameColor})`);
    }

    if (reasons.length === 0) {
      reasons.push('Progression logique');
    }

    return reasons.join(' • ');
  };

  if (!suggestion) {
    return null;
  }

  const progressPercent = Math.round((completedPoints.length / totalPoints) * 100);
  const efficiencyColor = efficacy > 70 ? 'emerald' : efficacy > 50 ? 'amber' : 'orange';

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        className="fixed top-20 left-4 z-[55] max-w-xs"
      >
        <Card className={`bg-gradient-to-br from-${efficiencyColor}-900/50 to-${efficiencyColor}-800/30 border-${efficiencyColor}-700/50`}>
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <Zap className={`w-5 h-5 text-${efficiencyColor}-400 flex-shrink-0 mt-0.5`} />
              
              <div className="flex-1 min-w-0">
                <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                  Smart Stitch
                  <Badge className={`bg-${efficiencyColor}-500/30 text-${efficiencyColor}-300 text-xs`}>
                    {efficacy.toFixed(0)}%
                  </Badge>
                </h3>

                <div className="mt-2 space-y-1">
                  <p className="text-xs text-gray-300">
                    <span className="font-medium">Point suivant:</span> ({suggestion.current.x}, {suggestion.current.y})
                  </p>
                  
                  {suggestion.nearbyCount > 0 && (
                    <p className="text-xs text-gray-400">
                      {suggestion.nearbyCount} points proches • {suggestion.sameColorCount} même couleur
                    </p>
                  )}

                  <p className="text-xs text-gray-300 italic mt-2">
                    {suggestion.reason}
                  </p>
                </div>

                {/* Mini progress */}
                <div className="mt-3 space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-gray-400">Progression</span>
                    <span className={`text-${efficiencyColor}-300 font-semibold`}>{progressPercent}%</span>
                  </div>
                  <div className="w-full h-1.5 bg-gray-700 rounded-full overflow-hidden">
                    <div
                      className={`h-full bg-gradient-to-r from-${efficiencyColor}-500 to-${efficiencyColor}-400 transition-all duration-300`}
                      style={{ width: `${progressPercent}%` }}
                    />
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </AnimatePresence>
  );
}