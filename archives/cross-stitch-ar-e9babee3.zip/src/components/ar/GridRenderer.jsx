import React, { useEffect, useRef } from 'react';

export default function GridRenderer({ 
  canvasRef, 
  pattern, 
  corners, 
  gridStyle, 
  opacity, 
  scale, 
  completedPoints, 
  activeColor,
  highlightCell,
  markers = []
}) {
  const canvasContextRef = useRef(null);

  useEffect(() => {
    if (!canvasRef.current || !pattern || corners.length !== 4) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    canvasContextRef.current = ctx;

    // Setup canvas
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    // Clear canvas
    ctx.fillStyle = 'rgba(0, 0, 0, 0)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Calculate grid dimensions
    const [x1, y1] = corners[0];
    const [x2, y2] = corners[1];
    const [x3, y3] = corners[2];
    const [x4, y4] = corners[3];

    const cellWidth = Math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2) / pattern.grid_width * scale;
    const cellHeight = Math.sqrt((x3 - x2) ** 2 + (y3 - y2) ** 2) / pattern.grid_height * scale;

    // Draw grid based on style
    ctx.globalAlpha = opacity;

    switch (gridStyle) {
      case 'solid':
        drawSolidGrid(ctx, corners, pattern, cellWidth, cellHeight, completedPoints, activeColor);
        break;
      case 'dashed':
        drawDashedGrid(ctx, corners, pattern, cellWidth, cellHeight, completedPoints, activeColor);
        break;
      case 'dotted':
        drawDottedGrid(ctx, corners, pattern, cellWidth, cellHeight, completedPoints, activeColor);
        break;
      case 'colored':
        drawColoredGrid(ctx, corners, pattern, cellWidth, cellHeight, completedPoints, activeColor);
        break;
    }

    ctx.globalAlpha = 1.0;

    // Draw highlight cell
    if (highlightCell) {
      drawHighlightCell(ctx, highlightCell, x1, y1, cellWidth, cellHeight);
    }

    // Draw markers
    markers.forEach(marker => {
      if (marker.is_active) {
        drawMarker(ctx, marker, x1, y1, cellWidth, cellHeight);
      }
    });

  }, [canvasRef, pattern, corners, gridStyle, opacity, scale, completedPoints, activeColor, highlightCell, markers]);

  const drawSolidGrid = (ctx, corners, pattern, cellWidth, cellHeight) => {
    ctx.strokeStyle = '#10b981';
    ctx.lineWidth = 1;

    for (let i = 0; i <= pattern.grid_width; i++) {
      ctx.beginPath();
      ctx.moveTo(corners[0][0] + i * cellWidth, corners[0][1]);
      ctx.lineTo(corners[1][0] + i * cellWidth, corners[1][1]);
      ctx.stroke();
    }

    for (let i = 0; i <= pattern.grid_height; i++) {
      ctx.beginPath();
      ctx.moveTo(corners[0][0], corners[0][1] + i * cellHeight);
      ctx.lineTo(corners[3][0], corners[3][1] + i * cellHeight);
      ctx.stroke();
    }
  };

  const drawDashedGrid = (ctx, corners, pattern, cellWidth, cellHeight) => {
    ctx.strokeStyle = '#14b8a6';
    ctx.lineWidth = 1;
    ctx.setLineDash([5, 5]);

    for (let i = 0; i <= pattern.grid_width; i++) {
      ctx.beginPath();
      ctx.moveTo(corners[0][0] + i * cellWidth, corners[0][1]);
      ctx.lineTo(corners[1][0] + i * cellWidth, corners[1][1]);
      ctx.stroke();
    }

    for (let i = 0; i <= pattern.grid_height; i++) {
      ctx.beginPath();
      ctx.moveTo(corners[0][0], corners[0][1] + i * cellHeight);
      ctx.lineTo(corners[3][0], corners[3][1] + i * cellHeight);
      ctx.stroke();
    }

    ctx.setLineDash([]);
  };

  const drawDottedGrid = (ctx, corners, pattern, cellWidth, cellHeight) => {
    ctx.fillStyle = '#10b981';

    for (let i = 0; i < pattern.grid_width; i++) {
      for (let j = 0; j < pattern.grid_height; j++) {
        const x = corners[0][0] + (i + 0.5) * cellWidth;
        const y = corners[0][1] + (j + 0.5) * cellHeight;

        ctx.beginPath();
        ctx.arc(x, y, 2, 0, Math.PI * 2);
        ctx.fill();
      }
    }
  };

  const drawColoredGrid = (ctx, corners, pattern, cellWidth, cellHeight, completedPoints, activeColor) => {
    Object.entries(pattern.grid_data || {}).forEach(([key, data]) => {
      const [x, y] = key.split('-').map(Number);
      const cellX = corners[0][0] + x * cellWidth;
      const cellY = corners[0][1] + y * cellHeight;

      let color = '#64748b';
      if (completedPoints.includes(key)) {
        color = '#10b981';
      } else if (activeColor && data.dmc === activeColor) {
        color = '#06b6d4';
      }

      ctx.fillStyle = color;
      ctx.fillRect(cellX, cellY, cellWidth - 1, cellHeight - 1);
    });
  };

  const drawHighlightCell = (ctx, highlightCell, x1, y1, cellWidth, cellHeight) => {
    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 3;
    ctx.shadowColor = '#f59e0b';
    ctx.shadowBlur = 10;

    const cellX = x1 + highlightCell.x * cellWidth;
    const cellY = y1 + highlightCell.y * cellHeight;

    ctx.strokeRect(cellX, cellY, cellWidth, cellHeight);
    ctx.shadowColor = 'transparent';
  };

  const drawMarker = (ctx, marker, x1, y1, cellWidth, cellHeight) => {
    const markerX = x1 + marker.x * cellWidth + cellWidth / 2;
    const markerY = y1 + marker.y * cellHeight + cellHeight / 2;

    // Draw marker circle
    ctx.fillStyle = marker.color || '#ef4444';
    ctx.beginPath();
    ctx.arc(markerX, markerY, 8, 0, Math.PI * 2);
    ctx.fill();

    // Draw marker border
    ctx.strokeStyle = 'white';
    ctx.lineWidth = 2;
    ctx.stroke();

    // Draw label if exists
    if (marker.label) {
      ctx.fillStyle = 'white';
      ctx.font = 'bold 12px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(marker.label, markerX, markerY - 15);
    }
  };

  return <canvas ref={canvasRef} className="absolute inset-0 w-full h-full pointer-events-auto" />;
}