import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, RotateCcw, Sparkles, Grid3X3, ArrowRight } from 'lucide-react';
import { Button } from "@/components/ui/button";
import PatternCard from '@/components/studio/PatternCard';

export default function PatternSelectionOverlay({
  patterns = [],
  sessions = [],
  onSelectPattern,
  onResumeSession,
  onCreateNew
}) {
  const [tab, setTab] = useState('browse'); // browse | resume | create

  // Filter active sessions (not completed, not archived)
  const activeSessions = sessions.filter(s => !s.is_completed && !s.is_archived);

  // Get pattern info for each session
  const patternMap = new Map(patterns.map(p => [p.id, p]));

  return (
    <div className="fixed inset-0 bg-black flex flex-col items-center justify-center z-50 overflow-auto">
      {/* Soft overlay - dismissible for discovery */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.3 }}
        className="min-h-screen w-full flex items-center justify-center p-4 py-12"
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.4 }}
          className="w-full max-w-2xl space-y-8"
        >
          {/* Header */}
          <div className="text-center space-y-3">
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
            >
              <Sparkles className="w-12 h-12 text-emerald-400 mx-auto mb-4" />
              <h1 className="text-4xl md:text-5xl font-light text-white">Commencer</h1>
              <p className="text-gray-400 text-sm mt-2">Que veux-tu faire ?</p>
            </motion.div>
          </div>

          {/* Tab buttons */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15 }}
            className="flex gap-3 justify-center flex-wrap"
          >
            <button
              onClick={() => setTab('browse')}
              className={`px-6 py-3 rounded-xl font-medium transition-all ${
                tab === 'browse'
                  ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/30'
                  : 'bg-gray-800/50 text-gray-300 hover:bg-gray-800'
              }`}
            >
              <Grid3X3 className="w-4 h-4 inline mr-2" />
              Choisir un pattern
            </button>
            {activeSessions.length > 0 && (
              <button
                onClick={() => setTab('resume')}
                className={`px-6 py-3 rounded-xl font-medium transition-all ${
                  tab === 'resume'
                    ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/30'
                    : 'bg-gray-800/50 text-gray-300 hover:bg-gray-800'
                }`}
              >
                <RotateCcw className="w-4 h-4 inline mr-2" />
                Reprendre ({activeSessions.length})
              </button>
            )}
            <button
              onClick={() => setTab('create')}
              className={`px-6 py-3 rounded-xl font-medium transition-all ${
                tab === 'create'
                  ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/30'
                  : 'bg-gray-800/50 text-gray-300 hover:bg-gray-800'
              }`}
            >
              <Plus className="w-4 h-4 inline mr-2" />
              Créer un pattern
            </button>
          </motion.div>

          {/* Content */}
          <AnimatePresence mode="wait">
            {/* Browse patterns */}
            {tab === 'browse' && (
              <motion.div
                key="browse"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-6"
              >
                {patterns.length === 0 ? (
                  <div className="text-center py-12 text-gray-400">
                    <p className="text-sm">Aucun pattern créé. Commencez par en créer un !</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-h-96 overflow-y-auto">
                    {patterns.map(pattern => (
                      <motion.div
                        key={pattern.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="cursor-pointer"
                        onClick={() => onSelectPattern(pattern)}
                      >
                        <PatternCard
                          pattern={pattern}
                          completedSession={null}
                          progressPercentage={0}
                          onSelect={() => onSelectPattern(pattern)}
                        />
                      </motion.div>
                    ))}
                  </div>
                )}
              </motion.div>
            )}

            {/* Resume sessions */}
            {tab === 'resume' && (
              <motion.div
                key="resume"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-4"
              >
                {activeSessions.length === 0 ? (
                  <div className="text-center py-12 text-gray-400">
                    <p className="text-sm">Aucune broderie en cours</p>
                  </div>
                ) : (
                  <div className="space-y-3 max-h-96 overflow-y-auto">
                    {activeSessions.map(session => {
                      const pattern = patternMap.get(session.pattern_id);
                      if (!pattern) return null;

                      return (
                        <motion.button
                          key={session.id}
                          onClick={() => onResumeSession(session)}
                          initial={{ opacity: 0, x: -10 }}
                          animate={{ opacity: 1, x: 0 }}
                          whileHover={{ x: 5 }}
                          className="w-full text-left p-4 rounded-xl bg-gray-800/30 border border-gray-700 hover:border-emerald-500/50 hover:bg-gray-800/50 transition-all"
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex-1">
                              <h3 className="text-white font-medium">{pattern.title}</h3>
                              <p className="text-sm text-gray-400 mt-1">
                                {session.points_completed?.length || 0} / {session.total_stitches} points
                              </p>
                              <div className="mt-2 w-32 h-2 bg-gray-700 rounded-full overflow-hidden">
                                <div
                                  className="h-full bg-emerald-500 transition-all"
                                  style={{ width: `${session.progress_percentage || 0}%` }}
                                />
                              </div>
                            </div>
                            <ArrowRight className="w-5 h-5 text-gray-400" />
                          </div>
                        </motion.button>
                      );
                    })}
                  </div>
                )}
              </motion.div>
            )}

            {/* Create new */}
            {tab === 'create' && (
              <motion.div
                key="create"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="text-center py-12"
              >
                <div className="space-y-4">
                  <p className="text-gray-400">Créer un nouveau pattern</p>
                  <Button
                    onClick={onCreateNew}
                    className="bg-emerald-500 hover:bg-emerald-600 text-white px-8 py-3 text-base"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Créer maintenant
                  </Button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </motion.div>

      {/* AR visible in background - subtle hint */}
      <motion.div
        animate={{ opacity: [0.1, 0.15, 0.1] }}
        transition={{ duration: 3, repeat: Infinity }}
        className="absolute inset-0 bg-gradient-to-t from-emerald-500/5 to-transparent pointer-events-none"
      />
    </div>
  );
}