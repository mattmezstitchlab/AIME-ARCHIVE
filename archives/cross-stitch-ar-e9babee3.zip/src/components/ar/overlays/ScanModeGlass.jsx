import React, { useRef, useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { ChevronLeft } from 'lucide-react';
import { speakKey, stop as stopVoice } from '../voiceEngine';
import CalibrationFlowV2 from '../calibration/CalibrationFlowV2';

export default function ScanModeGlass({
  onScanComplete,
  onBack
}) {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const prevScanPhaseRef = useRef(null);
  const prevDetectionsRef = useRef({ grid: false, symbols: false, colors: false });
  
  const [stream, setStream] = useState(null);
  const [scanPhase, setScanPhase] = useState('ready'); // ready | capturing | captured
  const [capturedImage, setCapturedImage] = useState(null);

  // Initialize camera
  useEffect(() => {
    const initCamera = async () => {
      try {
        if (!navigator.mediaDevices?.getUserMedia) {
          throw new Error('Camera API not available');
        }
        const mediaStream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment' },
          audio: false
        });
        setStream(mediaStream);
        if (videoRef.current) {
          videoRef.current.srcObject = mediaStream;
          await videoRef.current.play();
        }
        // Welcome voice on camera ready (once)
        prevScanPhaseRef.current = 'ready';
        setTimeout(() => speakKey('scan_intro', 'Prenez votre temps. Placez simplement votre motif face à l\'appareil. Quand il est bien visible dans le cadre, vous pouvez capturer.', { cooldownMs: 60000 }), 800);
      } catch (err) {
        console.error('Camera init failed:', err);
        speakKey('camera_permission', 'Permission caméra refusée.', { cooldownMs: 30000 });
        setTimeout(onBack, 2000);
      }
    };
    initCamera();

    return () => {
      if (stream) {
        stream.getTracks().forEach(t => t.stop());
      }
      stopVoice();
    };
  }, [onBack]);

  // Manual capture
  const handleCapture = () => {
    if (scanPhase !== 'ready') return;
    
    setScanPhase('capturing');
    stopVoice();
    speakKey('capture_done', 'Parfait. L\'image est capturée. Nous allons maintenant ajuster le motif pour qu\'il corresponde exactement à la grille.', { cooldownMs: 60000 });
    
    setTimeout(() => {
      try {
        if (videoRef.current && canvasRef.current) {
          const canvas = canvasRef.current;
          canvas.width = videoRef.current.videoWidth;
          canvas.height = videoRef.current.videoHeight;
          const ctx = canvas.getContext('2d');
          if (!ctx) throw new Error('Canvas context unavailable');
          ctx.drawImage(videoRef.current, 0, 0);
          const imageData = canvas.toDataURL('image/jpeg', 0.95);
          if (!imageData) throw new Error('Failed to capture frame');
          setCapturedImage(imageData);
          setScanPhase('captured');
        }
      } catch (err) {
        console.error('Capture failed:', err);
        setScanPhase('ready');
      }
    }, 1200);
  };



  // Handle calibration completion
  const handleCalibrationComplete = (calibData) => {
    console.log('[SCAN] Calibration complete:', calibData);
    stopVoice();

    // Ensure data is valid before passing up
    if (!calibData.image || !calibData.calibration) {
      console.error('[SCAN] Invalid calibration data:', calibData);
      setScanPhase('captured');
      return;
    }

    onScanComplete(calibData);
  };

  return (
    <div className="fixed inset-0 bg-black z-50">
      {/* Video feed */}
      <video
        ref={videoRef}
        className="absolute inset-0 w-full h-full object-cover"
        playsInline
        muted
        webkit-playsinline="true"
      />

      {/* Top bar */}
      <div className="absolute top-0 left-0 right-0 bg-gradient-to-b from-black/50 to-transparent px-4 py-4 z-20 flex items-center">
        <button onClick={() => { stopVoice(); onBack(); }} className="text-white">
          <ChevronLeft className="w-6 h-6" />
        </button>
      </div>

      {/* Glass frame (ready state) */}
      {scanPhase === 'ready' && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="absolute inset-0 flex items-center justify-center z-10"
        >
          <motion.div className="relative w-80 h-80 border-2 rounded-2xl backdrop-blur-sm border-white/30 bg-white/5">
            <div className="absolute inset-1 rounded-xl border border-emerald-400/40" />
          </motion.div>
        </motion.div>
      )}

      {/* Capture button (ready state) */}
      {scanPhase === 'ready' && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="absolute bottom-8 left-0 right-0 flex flex-col items-center gap-4 z-10 px-4"
        >
          <p className="text-white text-sm text-center">Placez le motif dans le cadre</p>
          <button
            onClick={handleCapture}
            className="px-8 py-3 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white font-medium transition shadow-lg"
          >
            Capturer
          </button>
        </motion.div>
      )}

      {/* Capturing state */}
      {scanPhase === 'capturing' && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="absolute inset-0 flex items-center justify-center z-10 bg-black/40"
        >
          <motion.div
            animate={{ scale: [1, 1.05, 1] }}
            transition={{ duration: 1.5, repeat: Infinity }}
            className="w-16 h-16 rounded-full border-2 border-emerald-400 border-t-transparent"
          />
        </motion.div>
      )}

      {/* Freeze UI (captured with preview) */}
      {scanPhase === 'captured' && capturedImage && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="absolute inset-0 flex flex-col bg-black z-20"
        >
          {/* Frozen image */}
          <div className="flex-1 flex items-center justify-center overflow-hidden">
            <img src={capturedImage} alt="captured" className="w-full h-full object-cover" />
          </div>

          {/* Bottom action bar */}
          <div className="bg-gradient-to-t from-black via-black/80 to-transparent px-4 py-6 flex gap-3">
            <motion.button
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              onClick={() => {
                setCapturedImage(null);
                setScanPhase('ready');
                speakKey('retake_voice', 'D\'accord, recommençons.', { cooldownMs: 30000 });
              }}
              className="flex-1 py-3 px-4 rounded-lg bg-white/10 hover:bg-white/20 text-white text-sm font-medium transition"
            >
              Reprendre la photo
            </motion.button>
            <motion.button
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              onClick={() => setScanPhase('calibrating')}
              className="flex-1 py-3 px-4 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white text-sm font-medium transition"
            >
              Continuer
            </motion.button>
          </div>
        </motion.div>
      )}

      {/* Calibration Flow with Auto-Detection */}
      {scanPhase === 'calibrating' && capturedImage && (
        <CalibrationFlowV2
          capturedImage={capturedImage}
          onComplete={handleCalibrationComplete}
          onRetake={() => {
            setScanPhase('captured');
          }}
        />
      )}

      {/* Hidden canvas */}
      <canvas ref={canvasRef} className="hidden" />
    </div>
  );
}