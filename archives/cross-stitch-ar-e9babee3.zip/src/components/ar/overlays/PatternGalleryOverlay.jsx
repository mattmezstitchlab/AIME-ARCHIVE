import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight, Play, Plus, RotateCcw } from 'lucide-react';
import PatternLiveLogo from '../PatternLiveLogo';

export default function PatternGalleryOverlay({
  patterns = [],
  sessions = [],
  onSelectPattern,
  onResumeSession,
  onCreateNew,
  previewPatternId,
  onPreviewChange
}) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const carouselRef = useRef(null);

  // Build gallery items: resume + browse + create
  const activeSessions = sessions.filter(s => !s.is_completed && !s.is_archived);
  const patternMap = new Map(patterns.map(p => [p.id, p]));

  const galleryItems = [
    // Resume sessions
    ...activeSessions.map(session => ({
      id: `resume-${session.id}`,
      type: 'resume',
      session,
      pattern: patternMap.get(session.pattern_id),
      title: patternMap.get(session.pattern_id)?.title || 'Unknown',
      progress: session.progress_percentage || 0
    })),
    // Browse patterns
    ...patterns.map(pattern => ({
      id: `pattern-${pattern.id}`,
      type: 'pattern',
      pattern,
      title: pattern.title,
      progress: 0
    })),
    // Create new
    { id: 'create', type: 'create', title: 'Créer' }
  ];

  const handlePrev = () => {
    setCurrentIndex(Math.max(0, currentIndex - 1));
  };

  const handleNext = () => {
    setCurrentIndex(Math.min(galleryItems.length - 1, currentIndex + 1));
  };

  const handleItemHover = (item) => {
    if (item.type === 'pattern' || item.type === 'resume') {
      onPreviewChange(item.pattern?.id);
    }
  };

  const handleItemClick = (item) => {
    if (item.type === 'pattern') {
      onSelectPattern(item.pattern);
    } else if (item.type === 'resume') {
      onResumeSession(item.session);
    } else if (item.type === 'create') {
      onCreateNew();
    }
  };

  if (galleryItems.length === 0) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-40"
      >
        <div className="text-center space-y-6">
          <div className="space-y-2">
            <PatternLiveLogo size="medium" />
            <p className="text-gray-400 text-sm">Aucun pattern créé</p>
          </div>
          <button
            onClick={onCreateNew}
            className="px-6 py-3 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white font-medium transition"
          >
            <Plus className="w-4 h-4 inline mr-2" />
            Créer le premier
          </button>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="fixed inset-0 bg-black/40 backdrop-blur-sm flex flex-col items-center justify-center z-40 p-4"
    >
      {/* Logo en haut à gauche */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="absolute top-20 left-6"
      >
        <PatternLiveLogo size="small" />
      </motion.div>

      {/* Carrousel avec perspective */}
      <div className="w-full max-w-6xl perspective">
        <div ref={carouselRef} className="relative h-80 flex items-center justify-center">
          {/* Items avec profondeur */}
          <AnimatePresence mode="popLayout">
            {galleryItems.map((item, idx) => {
              const distance = Math.abs(idx - currentIndex);
              const isCenter = idx === currentIndex;
              const isLeft = idx < currentIndex;

              // Perspective transform
              const scale = isCenter ? 1 : Math.max(0.6, 1 - distance * 0.15);
              const opacity = isCenter ? 1 : Math.max(0.3, 1 - distance * 0.2);
              const x = isCenter ? 0 : (isLeft ? -200 : 200);
              const zIndex = galleryItems.length - distance;

              return (
                <motion.div
                  key={item.id}
                  layout
                  animate={{
                    scale,
                    opacity,
                    x,
                    zIndex
                  }}
                  transition={{
                    type: 'spring',
                    stiffness: 300,
                    damping: 30
                  }}
                  onHoverStart={() => handleItemHover(item)}
                  onClick={() => handleItemClick(item)}
                  className="absolute w-64 cursor-pointer"
                >
                  <GalleryCard item={item} isCenter={isCenter} />
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>

        {/* Navigation arrows */}
        {currentIndex > 0 && (
          <motion.button
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            onClick={handlePrev}
            className="absolute left-0 top-1/2 -translate-y-1/2 p-3 rounded-full bg-white/10 hover:bg-white/20 text-white transition"
          >
            <ChevronLeft className="w-6 h-6" />
          </motion.button>
        )}

        {currentIndex < galleryItems.length - 1 && (
          <motion.button
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            onClick={handleNext}
            className="absolute right-0 top-1/2 -translate-y-1/2 p-3 rounded-full bg-white/10 hover:bg-white/20 text-white transition"
          >
            <ChevronRight className="w-6 h-6" />
          </motion.button>
        )}
      </div>

      {/* Info et boutons */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mt-12 text-center space-y-4 max-w-md"
      >
        <p className="text-gray-400 text-sm">
          {currentIndex + 1} / {galleryItems.length}
        </p>
        <p className="text-white font-light text-lg">
          {galleryItems[currentIndex].title}
        </p>

        {/* Actions basées sur le type */}
        <div className="flex gap-3 justify-center flex-wrap">
          {galleryItems[currentIndex].type === 'pattern' && (
            <button
              onClick={() => onSelectPattern(galleryItems[currentIndex].pattern)}
              className="px-6 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white font-medium transition flex items-center gap-2"
            >
              <Play className="w-4 h-4" />
              Démarrer
            </button>
          )}

          {galleryItems[currentIndex].type === 'resume' && (
            <button
              onClick={() => onResumeSession(galleryItems[currentIndex].session)}
              className="px-6 py-2 rounded-lg bg-blue-500 hover:bg-blue-600 text-white font-medium transition flex items-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              Reprendre
            </button>
          )}

          {galleryItems[currentIndex].type === 'create' && (
            <button
              onClick={onCreateNew}
              className="px-6 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white font-medium transition flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              Créer
            </button>
          )}
        </div>
      </motion.div>

      {/* Indicator dots */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
        className="mt-8 flex gap-2"
      >
        {galleryItems.map((_, idx) => (
          <button
            key={idx}
            onClick={() => setCurrentIndex(idx)}
            className={`h-2 rounded-full transition-all ${
              idx === currentIndex ? 'w-8 bg-emerald-400' : 'w-2 bg-gray-600'
            }`}
          />
        ))}
      </motion.div>
    </motion.div>
  );
}

function GalleryCard({ item, isCenter }) {
  return (
    <motion.div
      whileHover={isCenter ? { y: -5 } : {}}
      className="h-80 rounded-2xl overflow-hidden bg-gradient-to-br from-gray-800 to-gray-900 border border-gray-700 shadow-2xl"
    >
      {/* Thumbnail */}
      {(item.type === 'pattern' || item.type === 'resume') && item.pattern?.thumbnail_url ? (
        <div className="w-full h-48 bg-gray-700 overflow-hidden relative">
          <img
            src={item.pattern.thumbnail_url}
            alt={item.title}
            className="w-full h-full object-cover"
          />
        </div>
      ) : (
        <div className="w-full h-48 bg-gradient-to-b from-emerald-500/20 to-gray-800 flex items-center justify-center">
          <div className="text-center">
            <div className="text-4xl mb-2">
              {item.type === 'create' ? '✨' : '🧵'}
            </div>
            {item.type === 'resume' && (
              <div className="text-xs text-gray-400">Reprendre</div>
            )}
          </div>
        </div>
      )}

      {/* Progress bar (si resume) */}
      {item.type === 'resume' && item.progress > 0 && (
        <div className="h-1 bg-gray-700">
          <div
            className="h-full bg-emerald-500 transition-all"
            style={{ width: `${item.progress}%` }}
          />
        </div>
      )}

      {/* Info */}
      <div className="p-4 space-y-2 bg-gray-900/80">
        <h3 className="text-white font-medium truncate">{item.title}</h3>
        {item.pattern && (
          <p className="text-xs text-gray-400">
            {item.pattern.grid_width}×{item.pattern.grid_height} · {item.pattern.total_stitches} points
          </p>
        )}
        {item.type === 'resume' && item.progress > 0 && (
          <p className="text-xs text-emerald-400">{Math.round(item.progress)}% complété</p>
        )}
      </div>
    </motion.div>
  );
}