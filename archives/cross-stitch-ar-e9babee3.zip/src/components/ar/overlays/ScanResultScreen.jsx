import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { CheckCircle2 } from 'lucide-react';
import { toast } from 'sonner';

export default function ScanResultScreen({
  pattern,
  onStartGuide,
  onAdjust
}) {
  useEffect(() => {
    toast.success('Motif prêt ✓', { duration: 2 });
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="fixed inset-0 bg-black z-50 flex flex-col items-center justify-end"
    >
      {/* Magic grid assembly animation */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="absolute inset-0 flex items-center justify-center"
      >
        <div className="w-64 h-64 bg-gradient-to-b from-emerald-500/20 to-transparent rounded-2xl" />
      </motion.div>

      {/* Bottom action bar */}
      <motion.div
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.3 }}
        className="w-full bg-gradient-to-t from-black via-black/80 to-transparent px-6 py-8 space-y-3 z-10"
      >
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={onStartGuide}
          className="w-full py-4 bg-emerald-500 hover:bg-emerald-600 text-white font-medium rounded-lg transition"
        >
          Commencer
        </motion.button>
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={onAdjust}
          className="w-full py-4 bg-gray-800 hover:bg-gray-700 text-gray-200 font-medium rounded-lg transition"
        >
          Ajuster
        </motion.button>
      </motion.div>
    </motion.div>
  );
}