import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Camera, RotateCcw, X, AlertCircle } from 'lucide-react';
import PatternLiveLogo from '../PatternLiveLogo';
import ScanModeGlass from './ScanModeGlass';

export default function PatternScannerOverlay({
  isOpen = true,
  lastPattern = null,
  onStartScan,
  onResumePattern,
  onClose
}) {
  const [scanStep, setScanStep] = useState('entry'); // entry | scanning
  const [scanError, setScanError] = useState(null);

  const handleScanComplete = ({ image, calibration, pattern, method }) => {
    console.log('[SCANNER] Scan complete:', { method, image: !!image, pattern: !!pattern });

    // Use recognized pattern if available (auto-detect), else create mock
    const finalPattern = pattern || {
      id: `pattern-${Date.now()}`,
      title: 'Mon motif scanné',
      grid_width: 32,
      grid_height: 32,
      grid_data: {},
      dmc_palette: [
        { dmc_code: '310', color: '#000000', symbol: '•', name: 'Black' },
        { dmc_code: '666', color: '#FF0000', symbol: '×', name: 'Red' },
        { dmc_code: '702', color: '#00AA00', symbol: '○', name: 'Green' },
        { dmc_code: '725', color: '#FFAA00', symbol: '+', name: 'Gold' }
      ],
      total_stitches: 256,
      thumbnail_url: image,
      calibration_points: calibration
    };

    onStartScan(finalPattern);
  };

  if (!isOpen) return null;

  // Entry overlay
  if (scanStep === 'entry') {
    return (
      <AnimatePresence>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 backdrop-blur-sm flex flex-col items-center justify-center z-40 p-4"
        >
          {lastPattern && (
            <motion.button
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              onClick={onClose}
              className="absolute top-6 right-6 p-2 rounded-full bg-white/10 hover:bg-white/20 text-gray-400 hover:text-white transition"
            >
              <X className="w-5 h-5" />
            </motion.button>
          )}

          <div className="w-full max-w-md space-y-8 text-center">
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.1 }}
            >
              <PatternLiveLogo size="large" />
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="space-y-2"
            >
              <h1 className="text-2xl font-light text-white">Montrez-moi votre motif</h1>
              <p className="text-sm text-gray-400">Image, écran, PDF ou papier</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="space-y-3"
            >
              <button
                onClick={() => setScanStep('scanning')}
                className="w-full py-3 px-4 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white font-medium transition flex items-center justify-center gap-2"
              >
                <motion.div
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  <Camera className="w-5 h-5" />
                </motion.div>
                Ouvrir la caméra
              </button>

              {lastPattern && (
                <button
                  onClick={() => onResumePattern(lastPattern)}
                  className="w-full py-3 px-4 rounded-lg bg-blue-500/20 hover:bg-blue-500/30 border border-blue-500/50 text-blue-400 font-medium transition flex items-center justify-center gap-2"
                >
                  <RotateCcw className="w-4 h-4" />
                  Reprendre "{lastPattern.title}"
                </button>
              )}
            </motion.div>

            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
              className="text-xs text-gray-600 pt-4"
            >
              Pas de compte requis · Données traitées localement
            </motion.p>
          </div>
        </motion.div>
      </AnimatePresence>
    );
  }

  // Scanning mode (unified glass UI flow)
  if (scanStep === 'scanning') {
    return (
      <ScanModeGlass
        onScanComplete={handleScanComplete}
        onBack={() => setScanStep('entry')}
      />
    );
  }

  return null;
}


// Mock grid data generator for V1
const generateMockGridData = (width, height) => {
  const data = {};
  const colors = ['310', '666', '702', '725'];
  const symbols = ['•', '×', '○', '+'];
  
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const value = Math.floor((x + y) / 8) % colors.length;
      if (Math.random() > 0.3) {
        data[`${x}-${y}`] = {
          dmc: colors[value],
          symbol: symbols[value]
        };
      }
    }
  }
  return data;
};