import React, { useRef, useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Camera, ChevronLeft, Zap } from 'lucide-react';

export default function ScanCameraLive({
  onCapture,
  onBack,
  stream
}) {
  const videoRef = useRef(null);
  const [hasFlash, setHasFlash] = useState(false);
  const [detectionState, setDetectionState] = useState('empty'); // empty | grid-detected | blurry

  useEffect(() => {
    if (stream && videoRef.current) {
      videoRef.current.srcObject = stream;
      videoRef.current.play().catch(console.warn);
      
      // Check for flash support
      navigator.mediaDevices
        .enumerateDevices()
        .then(devices => {
          const hasCamera = devices.some(d => d.kind === 'videoinput');
          setHasFlash(hasCamera);
        })
        .catch(console.warn);
    }
  }, [stream]);

  const handleCapture = () => {
    if (videoRef.current) {
      const canvas = document.createElement('canvas');
      canvas.width = videoRef.current.videoWidth;
      canvas.height = videoRef.current.videoHeight;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(videoRef.current, 0, 0);
      onCapture(canvas.toDataURL('image/jpeg', 0.9));
    }
  };

  const helpTexts = {
    empty: 'Place le motif dans le cadre. Évite les reflets.',
    'grid-detected': 'Grille détectée ✓ garde bien stable…',
    blurry: 'Un peu plus net 🙂 rapproche-toi ou augmente la lumière.'
  };

  return (
    <div className="fixed inset-0 bg-black z-50">
      {/* Video */}
      <video
        ref={videoRef}
        className="absolute inset-0 w-full h-full object-cover"
        playsInline
        muted
        webkit-playsinline="true"
      />

      {/* Top bar */}
      <div className="absolute top-0 left-0 right-0 bg-gradient-to-b from-black/50 to-transparent px-4 py-4 z-10 flex justify-between items-center">
        <button onClick={onBack} className="text-white">
          <ChevronLeft className="w-6 h-6" />
        </button>
        <p className="text-white text-sm font-medium">Scan du motif</p>
        {hasFlash && (
          <button className="text-white p-2 hover:bg-white/20 rounded-lg transition">
            <Zap className="w-5 h-5" />
          </button>
        )}
        {!hasFlash && <div className="w-6" />}
      </div>

      {/* Breathing frame overlay */}
      <motion.div
        animate={{ scale: [1, 1.02, 1] }}
        transition={{ duration: 2, repeat: Infinity }}
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-72 h-72 border-2 border-emerald-400 rounded-2xl z-10"
      />

      {/* Help text - adaptive */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="absolute bottom-32 left-0 right-0 text-center px-6 z-10"
      >
        <p className="text-gray-300 text-sm">{helpTexts[detectionState]}</p>
      </motion.div>

      {/* Capture button */}
      <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black via-black/50 to-transparent px-6 py-6 z-10">
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={handleCapture}
          className="w-full py-4 bg-emerald-500 hover:bg-emerald-600 text-white font-medium rounded-lg flex items-center justify-center gap-2 transition"
        >
          <Camera className="w-5 h-5" />
          Capturer
        </motion.button>
      </div>
    </div>
  );
}