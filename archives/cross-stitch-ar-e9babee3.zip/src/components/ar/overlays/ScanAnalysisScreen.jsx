import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { CheckCircle2, Loader2 } from 'lucide-react';

export default function ScanAnalysisScreen({
  onComplete,
  imageData
}) {
  const [steps, setSteps] = useState([
    { id: 'grid', label: 'Grille', done: false },
    { id: 'symbols', label: 'Symboles', done: false },
    { id: 'colors', label: 'Couleurs', done: false }
  ]);
  const [showReassurance, setShowReassurance] = useState(false);
  const startTime = React.useRef(Date.now());

  useEffect(() => {
    // Simulate progressive analysis
    const timings = [800, 1600, 2400];
    const timeouts = timings.map((delay, idx) =>
      setTimeout(() => {
        setSteps(prev => {
          const next = [...prev];
          next[idx].done = true;
          return next;
        });
        if (idx === 2) {
          setTimeout(() => onComplete({ success: true }), 400);
        }
      }, delay)
    );

    // Show reassurance after 3s
    const reassuranceTimeout = setTimeout(() => setShowReassurance(true), 3000);

    return () => {
      timeouts.forEach(t => clearTimeout(t));
      clearTimeout(reassuranceTimeout);
    };
  }, [onComplete]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex flex-col items-center justify-center px-6"
    >
      <div className="text-center space-y-8 max-w-sm">
        {/* Title */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <h2 className="text-2xl font-light text-white">Analyse en cours…</h2>
          <p className="text-sm text-gray-400 mt-2">
            On repère la grille, les symboles et les couleurs.
          </p>
        </motion.div>

        {/* Progress steps */}
        <div className="space-y-3">
          {steps.map((step, idx) => (
            <motion.div
              key={step.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: idx * 0.2 }}
              className="flex items-center gap-3 text-left"
            >
              <div className="flex-shrink-0">
                {step.done ? (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                  >
                    <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  </motion.div>
                ) : (
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 2, repeat: Infinity }}
                  >
                    <Loader2 className="w-5 h-5 text-gray-400" />
                  </motion.div>
                )}
              </div>
              <span className={step.done ? 'text-gray-300' : 'text-gray-500'}>
                {step.label}
              </span>
            </motion.div>
          ))}
        </div>

        {/* Reassurance text */}
        {showReassurance && (
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-xs text-gray-500 italic"
          >
            C'est normal, certains PDF sont très détaillés.
          </motion.p>
        )}

        {/* Retry option (discrete) */}
        <motion.button
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="text-xs text-gray-500 hover:text-gray-400 transition"
        >
          Reprendre une photo
        </motion.button>
      </div>
    </motion.div>
  );
}