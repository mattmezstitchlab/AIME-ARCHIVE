import React, { useRef, useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { CheckCircle2 } from 'lucide-react';

export default function ScanCalibrationOverlay({
  imageData,
  onDone,
  onBack
}) {
  const canvasRef = useRef(null);
  const [points, setPoints] = useState([]);
  const [mode] = useState('2pt'); // 2pt or 4pt
  const maxPoints = 2;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !imageData) return;

    const img = new Image();
    img.src = imageData;
    img.onload = () => {
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0);
      
      // Draw existing points
      points.forEach((pt, idx) => {
        ctx.fillStyle = idx === points.length - 1 ? '#10b981' : '#6b7280';
        ctx.beginPath();
        ctx.arc(pt.x, pt.y, 12, 0, Math.PI * 2);
        ctx.fill();
      });

      // Draw ghost point if needed
      if (points.length < maxPoints) {
        ctx.fillStyle = 'rgba(16, 185, 129, 0.3)';
        ctx.beginPath();
        ctx.arc(canvas.width * 0.2, canvas.height * 0.2, 12, 0, Math.PI * 2);
        ctx.fill();
      }
    };
  }, [imageData, points]);

  const handleCanvasClick = (e) => {
    const canvas = canvasRef.current;
    if (!canvas || points.length >= maxPoints) return;

    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    
    const x = (e.clientX - rect.left) * scaleX;
    const y = (e.clientY - rect.top) * scaleY;

    setPoints([...points, { x, y }]);
  };

  const isComplete = points.length === maxPoints;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="fixed inset-0 bg-black z-50 flex flex-col"
    >
      {/* Image with calibration overlay */}
      <div className="flex-1 relative">
        <canvas
          ref={canvasRef}
          onClick={handleCanvasClick}
          className="absolute inset-0 w-full h-full object-contain cursor-crosshair"
          style={{ maxHeight: '100vh' }}
        />

        {/* Help text overlay */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="absolute top-0 left-0 right-0 bg-gradient-to-b from-black/60 to-transparent px-6 py-4 text-center z-10"
        >
          <h3 className="text-white font-medium">Aligne la grille</h3>
          <p className="text-sm text-gray-300 mt-1">
            Tapote {maxPoints} coins du carré
          </p>
        </motion.div>

        {/* Progress indicator */}
        <div className="absolute bottom-20 left-0 right-0 flex justify-center gap-2 z-10">
          {[...Array(maxPoints)].map((_, i) => (
            <motion.div
              key={i}
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className={`w-2 h-2 rounded-full ${
                i < points.length ? 'bg-emerald-400' : 'bg-gray-600'
              }`}
            />
          ))}
        </div>
      </div>

      {/* Bottom action */}
      <div className="bg-gradient-to-t from-black via-black/60 to-transparent px-6 py-6">
        <motion.button
          onClick={onDone}
          disabled={!isComplete}
          whileHover={isComplete ? { scale: 1.05 } : {}}
          whileTap={isComplete ? { scale: 0.95 } : {}}
          className={`w-full py-4 rounded-lg font-medium flex items-center justify-center gap-2 transition ${
            isComplete
              ? 'bg-emerald-500 hover:bg-emerald-600 text-white'
              : 'bg-gray-700 text-gray-500 cursor-not-allowed'
          }`}
        >
          {isComplete && <CheckCircle2 className="w-5 h-5" />}
          Valider l'alignement
        </motion.button>
      </div>
    </motion.div>
  );
}