import React, { useRef, useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Camera, X, RefreshCw, AlertTriangle, Code } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function ScannerCamera({
  isOpen = false,
  onCapture,
  onError,
  onClose
}) {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const streamRef = useRef(null);
  const timeoutRef = useRef(null);
  
  const [state, setState] = useState('IDLE'); // IDLE | REQUESTING | READY | NEED_USER_ACTIVATION | CAPTURED | ERROR | PREVIEW_BLOCKED
  const [errorMsg, setErrorMsg] = useState('');
  const [isCaptureDisabled, setIsCaptureDisabled] = useState(false);
  const [showDebug, setShowDebug] = useState(false);
  const [debugInfo, setDebugInfo] = useState({});
  const [lastError, setLastError] = useState(null);

  // Update debug info
  const updateDebugInfo = async () => {
    const info = {
      isSecureContext: window.isSecureContext,
      isIframe: window.top !== window.self,
      timestamp: new Date().toLocaleTimeString()
    };
    
    try {
      const permStatus = await navigator.permissions.query({ name: 'camera' });
      info.cameraPermission = permStatus.state;
    } catch (e) {
      info.cameraPermission = 'N/A';
    }
    
    if (streamRef.current) {
      info.streamTracksCount = streamRef.current.getTracks().length;
      info.audioTracks = streamRef.current.getAudioTracks().length;
      info.videoTracks = streamRef.current.getVideoTracks().length;
    }
    
    if (videoRef.current) {
      info.videoReadyState = videoRef.current.readyState;
      info.videoWidth = videoRef.current.videoWidth;
      info.videoHeight = videoRef.current.videoHeight;
    }
    
    if (lastError) {
      info.lastError = lastError;
    }
    
    setDebugInfo(info);
  };

  // Request camera access
  const requestCamera = async () => {
    console.log('[ScannerCamera] Starting camera request...');
    setState('REQUESTING');
    updateDebugInfo();
    
    // Check if in iframe/preview
    if (window.top !== window.self || !window.isSecureContext) {
      console.warn('[ScannerCamera] Blocked: iframe or insecure context');
      setState('PREVIEW_BLOCKED');
      setErrorMsg(window.top !== window.self ? 'Preview bloquée' : 'Contexte non sécurisé');
      return;
    }
    
    try {
      console.log('[ScannerCamera] Requesting media stream...');
      
      const constraints = {
        video: {
          facingMode: 'environment',
          width: { ideal: 1920 },
          height: { ideal: 1080 }
        },
        audio: false
      };
      
      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      streamRef.current = stream;
      console.log('[ScannerCamera] Stream acquired, attaching to video...');
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        
        // Await loadedmetadata event, then play
        await new Promise((resolve) => {
          const onLoaded = () => {
            console.log('[ScannerCamera] Video metadata loaded');
            videoRef.current?.removeEventListener('loadedmetadata', onLoaded);
            resolve();
          };
          videoRef.current?.addEventListener('loadedmetadata', onLoaded);
        });
        
        // Try to play immediately
        await playVideo();
        
        // iOS fallback: if after 1s videoWidth is still 0, ask for user activation
        timeoutRef.current = setTimeout(() => {
          if (videoRef.current && videoRef.current.videoWidth === 0) {
            console.warn('[ScannerCamera] iOS fallback: videoWidth is 0 after 1s');
            setState('NEED_USER_ACTIVATION');
            setLastError('Nécessite activation utilisateur');
            updateDebugInfo();
          }
        }, 1000);
      }
      
    } catch (err) {
      console.error('[ScannerCamera] Error:', err.name, err.message);
      setLastError(`${err.name}: ${err.message}`);
      setState('ERROR');
      setErrorMsg(
        err.name === 'NotAllowedError'
          ? 'Caméra refusée. Autorise l\'accès dans les paramètres.'
          : err.name === 'NotFoundError'
          ? 'Aucune caméra trouvée.'
          : 'Caméra non disponible. Vérifie ton appareil.'
      );
      onError(err);
      updateDebugInfo();
    }
  };
  
  // Play video (with iOS fallback)
  const playVideo = async () => {
    if (!videoRef.current) return;
    
    try {
      console.log('[ScannerCamera] Playing video...');
      await videoRef.current.play();
      console.log('[ScannerCamera] Play successful, state -> READY');
      setState('READY');
      clearTimeout(timeoutRef.current);
      updateDebugInfo();
    } catch (err) {
      console.warn('[ScannerCamera] Play failed:', err.message);
      setLastError(`Play failed: ${err.message}`);
      // Don't set state here, let timeout handle iOS fallback
    }
  };

  // Capture and process
  const handleCapture = async () => {
    if (state !== 'READY' || !videoRef.current || !canvasRef.current) return;
    
    setIsCaptureDisabled(true);
    setState('CAPTURED');

    try {
      const canvas = canvasRef.current;
      const video = videoRef.current;
      
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      
      const ctx = canvas.getContext('2d');
      ctx.drawImage(video, 0, 0);
      
      // Wait for play to ensure frame is ready
      await videoRef.current.play().catch(() => {});
      await new Promise(r => setTimeout(r, 100));
      
      // Get image data
      const imageData = canvas.toDataURL('image/jpeg', 0.8);
      
      // Stop stream
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
        streamRef.current = null;
      }
      
      // Callback with captured image
      onCapture(imageData);
    } catch (err) {
      setState('ERROR');
      setErrorMsg('Erreur lors de la capture.');
      onError(err);
      setIsCaptureDisabled(false);
    }
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      clearTimeout(timeoutRef.current);
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
      }
    };
  }, []);
  
  // Update debug info periodically
  useEffect(() => {
    if (showDebug) {
      const interval = setInterval(updateDebugInfo, 500);
      return () => clearInterval(interval);
    }
  }, [showDebug, lastError]);

  // Request camera when opened
  useEffect(() => {
    if (isOpen && state === 'IDLE') {
      requestCamera();
    }
  }, [isOpen, state]);

  const handleClose = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setState('IDLE');
    onClose();
  };

  if (!isOpen) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black z-40 flex flex-col"
      style={{ width: '100vw', height: '100vh', overflow: 'hidden' }}
    >
      {/* Video feed - fullscreen (visible on READY or USER_ACTIVATION states) */}
      {(state === 'READY' || state === 'NEED_USER_ACTIVATION') && (
        <video
          ref={videoRef}
          className="absolute inset-0"
          style={{
            width: '100%',
            height: '100%',
            objectFit: 'cover',
            zIndex: 0,
            backgroundColor: '#000'
          }}
          playsInline
          muted
          autoPlay
          disablePictureInPicture
          webkit-playsinline="true"
        />
      )}
      
      {/* Debug panel */}
      {showDebug && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="absolute top-4 left-4 z-50 bg-black/80 text-white text-xs p-3 rounded font-mono max-w-xs"
        >
          <div className="space-y-1">
            {Object.entries(debugInfo).map(([key, val]) => (
              <div key={key}>
                <span className="text-gray-400">{key}:</span> {String(val)}
              </div>
            ))}
          </div>
        </motion.div>
      )}

      {/* Top controls */}
      <div className="absolute top-4 right-4 z-50 flex gap-2">
        <button
          onClick={() => setShowDebug(!showDebug)}
          className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-gray-300 hover:text-white transition"
          title="Toggle debug info"
        >
          <Code className="w-5 h-5" />
        </button>
        <button
          onClick={handleClose}
          className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-gray-300 hover:text-white transition"
        >
          <X className="w-6 h-6" />
        </button>
      </div>

      {/* REQUESTING state */}
      {state === 'REQUESTING' && (
        <div className="absolute inset-0 flex items-center justify-center z-50 bg-black/50">
          <div className="text-center space-y-4">
            <div className="w-12 h-12 rounded-full border-2 border-emerald-500 border-t-transparent animate-spin mx-auto" />
            <p className="text-gray-400 text-sm">Accès à la caméra...</p>
          </div>
        </div>
      )}
      
      {/* NEED_USER_ACTIVATION state (iOS fallback) */}
      {state === 'NEED_USER_ACTIVATION' && (
        <div className="absolute inset-0 flex items-center justify-center z-50 bg-black/50">
          <div className="text-center space-y-6 max-w-sm bg-black/90 p-6 rounded-lg">
            <div className="space-y-2">
              <p className="text-lg font-medium text-white">Activer la caméra</p>
              <p className="text-sm text-gray-400">Appuyez pour lancer la capture</p>
            </div>
            <Button
              onClick={playVideo}
              className="w-full bg-emerald-500 hover:bg-emerald-600 text-white"
            >
              Activer la caméra
            </Button>
          </div>
        </div>
      )}
      
      {/* PREVIEW_BLOCKED state */}
      {state === 'PREVIEW_BLOCKED' && (
        <div className="absolute inset-0 flex items-center justify-center z-50 bg-black">
          <div className="text-center space-y-6 max-w-sm bg-black/90 p-6 rounded-lg">
            <AlertTriangle className="w-12 h-12 text-amber-500 mx-auto" />
            <div className="space-y-2">
              <p className="text-lg font-medium text-white">Caméra bloquée</p>
              <p className="text-sm text-gray-400">
                La caméra n'est pas disponible en Preview. Ouvre l'app dans un nouvel onglet.
              </p>
            </div>
            <a
              href={window.location.href.split('?')[0]}
              target="_blank"
              rel="noopener noreferrer"
              className="block py-3 px-6 bg-emerald-500 hover:bg-emerald-600 text-white font-medium rounded-lg transition"
            >
              Ouvrir dans nouvel onglet
            </a>
          </div>
        </div>
      )}
      


      {/* Error state */}
      {state === 'ERROR' && (
        <div className="absolute inset-0 flex items-center justify-center px-6 z-50 bg-black/50">
          <div className="text-center space-y-6 max-w-sm bg-black/90 p-6 rounded-lg">
            <AlertTriangle className="w-12 h-12 text-red-500 mx-auto" />
            <div className="space-y-2">
              <p className="text-lg font-medium text-white">Caméra non disponible</p>
              <p className="text-sm text-gray-400">{errorMsg}</p>
            </div>
            <div className="flex flex-col gap-3">
              <Button
                onClick={requestCamera}
                className="bg-emerald-500 hover:bg-emerald-600 text-white"
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Réessayer
              </Button>
              <Button
                onClick={handleClose}
                variant="outline"
                className="border-gray-700 text-gray-300 hover:bg-gray-900"
              >
                Fermer
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Captured state (show preview) */}
      {state === 'CAPTURED' && (
        <canvas
          ref={canvasRef}
          className="absolute inset-0"
          style={{
            width: '100%',
            height: '100%',
            objectFit: 'cover',
            zIndex: 0
          }}
        />
      )}

      {/* Hidden canvas for capture */}
      <canvas ref={canvasRef} className="hidden" />

      {/* Bottom controls - overlay on camera (only when READY) */}
      {state === 'READY' && (
        <motion.div
          initial={{ y: 100 }}
          animate={{ y: 0 }}
          className="fixed bottom-0 left-0 right-0 bg-gradient-to-t from-black via-black/50 to-transparent p-6 z-40"
          style={{ height: '120px', pointerEvents: 'auto' }}
        >
          <button
            onClick={handleCapture}
            disabled={isCaptureDisabled}
            className="w-full py-3 px-6 rounded-lg bg-emerald-500 hover:bg-emerald-600 disabled:bg-emerald-500/50 text-white font-medium transition flex items-center justify-center gap-2"
          >
            <Camera className="w-5 h-5" />
            Capturer
          </button>
          <p className="text-xs text-gray-500 text-center mt-2">
            {videoRef.current?.videoWidth ? `${videoRef.current.videoWidth}x${videoRef.current.videoHeight}` : 'Chargement...'}
          </p>
        </motion.div>
      )}
    </motion.div>
  );
}