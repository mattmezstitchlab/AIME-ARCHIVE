import React, { useRef, useEffect, useState } from 'react';
import { motion } from 'framer-motion';

export default function PatternOverlay({ 
  pattern, 
  opacity = 0.6, 
  corners,
  completedPoints = [],
  activeColor = null,
  showSymbols = true,
  showGrid = true,
  highlightCell = null,
  onCellClick
}) {
  const canvasRef = useRef(null);
  const [dimensions, setDimensions] = useState({ width: 0, height: 0 });

  useEffect(() => {
    const updateDimensions = () => {
      setDimensions({
        width: window.innerWidth,
        height: window.innerHeight
      });
    };
    updateDimensions();
    window.addEventListener('resize', updateDimensions);
    return () => window.removeEventListener('resize', updateDimensions);
  }, []);

  useEffect(() => {
    if (!canvasRef.current || !pattern || !corners || corners.length !== 4) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    canvas.width = dimensions.width;
    canvas.height = dimensions.height;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    const { grid_width, grid_height, grid_data, dmc_palette } = pattern;
    
    // Calculate cell dimensions based on corners
    const topLeft = corners[0];
    const topRight = corners[1];
    const bottomRight = corners[2];
    const bottomLeft = corners[3];

    const cellWidth = (topRight.x - topLeft.x) / grid_width;
    const cellHeight = (bottomLeft.y - topLeft.y) / grid_height;

    // Create DMC color map
    const dmcColorMap = {};
    dmc_palette?.forEach(p => {
      dmcColorMap[p.dmc_code] = p;
    });

    // Draw grid and cells
    for (let y = 0; y < grid_height; y++) {
      for (let x = 0; x < grid_width; x++) {
        const key = `${x}-${y}`;
        const cellData = grid_data?.[key];
        const isCompleted = completedPoints.includes(key);
        
        // Calculate cell position with perspective
        const px = topLeft.x + x * cellWidth;
        const py = topLeft.y + y * cellHeight;

        // Skip if filtering by color and doesn't match
        if (activeColor && cellData?.dmc !== activeColor) {
          continue;
        }

        // Draw cell background
        if (cellData) {
          const dmcInfo = dmcColorMap[cellData.dmc];
          if (dmcInfo) {
            ctx.fillStyle = isCompleted 
              ? `${dmcInfo.color}30` 
              : `${dmcInfo.color}${Math.round(opacity * 255).toString(16).padStart(2, '0')}`;
            ctx.fillRect(px, py, cellWidth, cellHeight);

            // Draw symbol
            if (showSymbols && !isCompleted) {
              ctx.fillStyle = '#FFFFFF';
              ctx.font = `bold ${Math.max(10, cellWidth * 0.5)}px Arial`;
              ctx.textAlign = 'center';
              ctx.textBaseline = 'middle';
              ctx.fillText(cellData.symbol, px + cellWidth / 2, py + cellHeight / 2);
            }

            // Draw DMC code (small)
            if (cellWidth > 20 && !isCompleted) {
              ctx.fillStyle = '#FFFFFF80';
              ctx.font = `${Math.max(6, cellWidth * 0.25)}px Arial`;
              ctx.fillText(cellData.dmc, px + cellWidth / 2, py + cellHeight - 4);
            }
          }
        }

        // Draw completed checkmark
        if (isCompleted) {
          ctx.fillStyle = '#10B98180';
          ctx.fillRect(px, py, cellWidth, cellHeight);
          ctx.fillStyle = '#10B981';
          ctx.font = `bold ${cellWidth * 0.6}px Arial`;
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText('✓', px + cellWidth / 2, py + cellHeight / 2);
        }

        // Highlight active cell
        if (highlightCell && highlightCell.x === x && highlightCell.y === y) {
          ctx.strokeStyle = '#10B981';
          ctx.lineWidth = 3;
          ctx.shadowColor = '#10B981';
          ctx.shadowBlur = 10;
          ctx.strokeRect(px + 2, py + 2, cellWidth - 4, cellHeight - 4);
          ctx.shadowBlur = 0;
        }

        // Draw grid
        if (showGrid) {
          ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
          ctx.lineWidth = 0.5;
          ctx.strokeRect(px, py, cellWidth, cellHeight);
        }
      }
    }

    // Draw outer border
    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(topLeft.x, topLeft.y);
    ctx.lineTo(topRight.x, topRight.y);
    ctx.lineTo(bottomRight.x, bottomRight.y);
    ctx.lineTo(bottomLeft.x, bottomLeft.y);
    ctx.closePath();
    ctx.stroke();

  }, [pattern, corners, opacity, completedPoints, activeColor, showSymbols, showGrid, highlightCell, dimensions]);

  const handleCanvasClick = (e) => {
    if (!pattern || !corners || corners.length !== 4 || !onCellClick) return;

    const rect = canvasRef.current.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const clickY = e.clientY - rect.top;

    const { grid_width, grid_height } = pattern;
    const topLeft = corners[0];
    const topRight = corners[1];
    const bottomLeft = corners[3];

    const cellWidth = (topRight.x - topLeft.x) / grid_width;
    const cellHeight = (bottomLeft.y - topLeft.y) / grid_height;

    const cellX = Math.floor((clickX - topLeft.x) / cellWidth);
    const cellY = Math.floor((clickY - topLeft.y) / cellHeight);

    if (cellX >= 0 && cellX < grid_width && cellY >= 0 && cellY < grid_height) {
      onCellClick({ x: cellX, y: cellY });
    }
  };

  return (
    <motion.canvas
      ref={canvasRef}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="absolute inset-0 z-10 touch-none"
      onClick={handleCanvasClick}
      style={{ pointerEvents: onCellClick ? 'auto' : 'none' }}
    />
  );
}