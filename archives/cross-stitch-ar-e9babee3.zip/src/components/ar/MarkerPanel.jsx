import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { motion } from 'framer-motion';
import { Trash2, Plus } from 'lucide-react';

export default function MarkerPanel({ nextPoint, onAddMarker, markers = [], onDeleteMarker }) {
  const [markerType, setMarkerType] = useState('checkpoint');
  const [markerLabel, setMarkerLabel] = useState('');

  const markerTypes = [
    { id: 'checkpoint', name: '🎯 Point clé', color: '#10b981' },
    { id: 'warning', name: '⚠️ Attention', color: '#f59e0b' },
    { id: 'note', name: '📝 Note', color: '#3b82f6' },
    { id: 'helper', name: '💡 Aide', color: '#ec4899' }
  ];

  const handleAddMarker = () => {
    if (!nextPoint) return;

    const type = markerTypes.find(t => t.id === markerType);
    onAddMarker({
      x: nextPoint.x,
      y: nextPoint.y,
      type: markerType,
      label: markerLabel,
      color: type.color
    });

    setMarkerLabel('');
    setMarkerType('checkpoint');
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-4"
    >
      <div className="space-y-3">
        <label className="text-xs font-semibold uppercase tracking-wide text-gray-400">Ajouter un marqueur</label>

        <div className="space-y-2">
          {markerTypes.map(type => (
            <motion.button
              key={type.id}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setMarkerType(type.id)}
              className={`w-full p-2 rounded-lg border text-sm transition text-left ${
                markerType === type.id
                  ? 'border-emerald-400 bg-emerald-400/10'
                  : 'border-gray-700 bg-gray-800/30 hover:border-gray-600'
              }`}
            >
              {type.name}
            </motion.button>
          ))}
        </div>

        <input
          type="text"
          placeholder="Libellé optionnel"
          value={markerLabel}
          onChange={(e) => setMarkerLabel(e.target.value)}
          className="w-full px-3 py-2 rounded-lg bg-gray-800 border border-gray-700 text-white placeholder-gray-500 text-sm focus:outline-none focus:border-emerald-400"
        />

        <Button
          onClick={handleAddMarker}
          disabled={!nextPoint}
          className="w-full bg-emerald-500 hover:bg-emerald-600 disabled:opacity-50 text-white py-2 text-sm"
        >
          <Plus className="w-4 h-4 mr-2" />
          Placer marqueur
        </Button>
      </div>

      {/* List of markers */}
      {markers.length > 0 && (
        <div className="space-y-2">
          <label className="text-xs font-semibold uppercase tracking-wide text-gray-400">
            Marqueurs ({markers.length})
          </label>
          <div className="space-y-2 max-h-48 overflow-y-auto">
            {markers.map(marker => (
              <motion.div
                key={marker.id}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
                className="flex items-center justify-between p-2 rounded-lg bg-gray-800/50 border border-gray-700"
              >
                <div className="flex items-center gap-2 flex-1">
                  <div
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: marker.color }}
                  />
                  <span className="text-xs text-gray-300">
                    {marker.label || `${marker.type}`} ({marker.x}, {marker.y})
                  </span>
                </div>
                <button
                  onClick={() => onDeleteMarker(marker.id)}
                  className="p-1 hover:bg-red-500/20 rounded transition"
                >
                  <Trash2 className="w-3 h-3 text-red-400" />
                </button>
              </motion.div>
            ))}
          </div>
        </div>
      )}
    </motion.div>
  );
}