import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Target, Clock, Check, X } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function SessionGoals({ onSetGoals, onSkip, defaultPoints, defaultMinutes }) {
  const [goalPoints, setGoalPoints] = useState(defaultPoints || '');
  const [goalMinutes, setGoalMinutes] = useState(defaultMinutes || '');

  const handleSubmit = (e) => {
    e.preventDefault();
    onSetGoals({
      goal_points: goalPoints ? parseInt(goalPoints) : null,
      goal_minutes: goalMinutes ? parseInt(goalMinutes) : null
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] bg-black/80 flex items-center justify-center p-4"
    >
      <motion.div
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.9, y: 20 }}
      >
        <Card className="bg-gray-900 border-gray-700 max-w-md w-full">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Target className="w-5 h-5 text-emerald-400" />
              Définir des objectifs
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="goal-points" className="text-gray-300">
                  Nombre de points à broder
                </Label>
                <div className="flex items-center gap-2 mt-2">
                  <Target className="w-4 h-4 text-gray-500" />
                  <Input
                    id="goal-points"
                    type="number"
                    min="1"
                    value={goalPoints}
                    onChange={(e) => setGoalPoints(e.target.value)}
                    placeholder="Ex: 50"
                    className="bg-gray-800 border-gray-700 text-white"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="goal-minutes" className="text-gray-300">
                  Temps disponible (minutes)
                </Label>
                <div className="flex items-center gap-2 mt-2">
                  <Clock className="w-4 h-4 text-gray-500" />
                  <Input
                    id="goal-minutes"
                    type="number"
                    min="1"
                    value={goalMinutes}
                    onChange={(e) => setGoalMinutes(e.target.value)}
                    placeholder="Ex: 30"
                    className="bg-gray-800 border-gray-700 text-white"
                  />
                </div>
              </div>

              <p className="text-sm text-gray-400">
                Laissez vide pour broder sans objectif spécifique
              </p>

              <div className="flex gap-2 pt-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={onSkip}
                  className="flex-1 border-gray-700"
                >
                  <X className="w-4 h-4 mr-2" />
                  Passer
                </Button>
                <Button
                  type="submit"
                  className="flex-1 bg-emerald-500 hover:bg-emerald-600"
                >
                  <Check className="w-4 h-4 mr-2" />
                  Définir
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  );
}