import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Play, Pause, RotateCcw } from 'lucide-react';

export default function VoicePanel({ nextStitch, detailed, onVoiceToggle }) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [subtitle, setSubtitle] = useState('Tap to hear the next instruction...');

  const handlePlayVoice = () => {
    setIsPlaying(true);
    // Simulate voice playback
    setTimeout(() => setIsPlaying(false), 3000);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-3 bg-gray-800/20 rounded-2xl p-4 border border-gray-700/30"
    >
      <div className="text-xs text-gray-500 uppercase tracking-wider">Voice Guide</div>

      {/* Subtitle */}
      <div className="px-3 py-2 rounded-lg bg-gray-900/50 border border-gray-800">
        <p className="text-sm text-gray-300 leading-relaxed">
          {isPlaying ? '🎤 Listening...' : subtitle}
        </p>
      </div>

      {/* Controls */}
      <div className="flex gap-2">
        <button
          onClick={handlePlayVoice}
          disabled={isPlaying}
          className="flex-1 flex items-center justify-center gap-2 px-3 py-2 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/50 text-emerald-400 transition disabled:opacity-50 text-sm"
        >
          {isPlaying ? (
            <Pause className="w-4 h-4" />
          ) : (
            <Play className="w-4 h-4" />
          )}
          {isPlaying ? 'Playing' : 'Play'}
        </button>
        <button
          onClick={() => {
            setIsPlaying(false);
            setSubtitle('Instruction repeated');
          }}
          className="flex items-center justify-center gap-2 px-3 py-2 rounded-lg bg-gray-800/50 hover:bg-gray-800 border border-gray-700 text-gray-400 hover:text-white transition text-sm"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>

      {detailed && (
        <div className="text-xs text-gray-400 space-y-1 pt-2 border-t border-gray-700/30">
          <div>French voice • Calm pace</div>
          <div>Next stitch: X:15, Y:8</div>
        </div>
      )}
    </motion.div>
  );
}