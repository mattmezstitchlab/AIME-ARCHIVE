import React, { useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { Lock, Unlock, RotateCcw, ArrowLeft, Check } from 'lucide-react';

const gridColors = [
  { id: 'emerald', label: 'Emerald', color: 'rgb(34, 197, 94)' },
  { id: 'cyan', label: 'Cyan', color: 'rgb(34, 211, 238)' },
  { id: 'purple', label: 'Purple', color: 'rgb(168, 85, 247)' },
  { id: 'orange', label: 'Orange', color: 'rgb(249, 115, 22)' }
];

const symbolDensity = [
  { id: 'minimal', label: 'Minimal', description: 'Next stitch only' },
  { id: 'normal', label: 'Normal', description: 'All points' },
  { id: 'debug', label: 'Debug', description: 'Grid + details' }
];

export default function AdjustModePanel({
  gridState,
  onUpdatePosition,
  onUpdateScale,
  onUpdateRotation,
  onLock,
  onUnlock,
  onReset,
  onUndo,
  canUndo,
  onDoneClick,
  onBackClick
}) {
  const dragRef = useRef({ active: false, startX: 0, startY: 0 });
  const [gridColor, setGridColor] = useState('emerald');
  const [gridOpacity, setGridOpacity] = useState(100);
  const [showSymbols, setShowSymbols] = useState(true);
  const [symbolMode, setSymbolMode] = useState('normal');

  const handleGridDragStart = (e) => {
    dragRef.current = {
      active: true,
      startX: e.clientX || e.touches?.[0].clientX,
      startY: e.clientY || e.touches?.[0].clientY
    };
  };

  const handleGridDragMove = (e) => {
    if (!dragRef.current.active) return;
    const currentX = e.clientX || e.touches?.[0].clientX;
    const currentY = e.clientY || e.touches?.[0].clientY;
    const deltaX = (currentX - dragRef.current.startX) * 0.5;
    const deltaY = (currentY - dragRef.current.startY) * 0.5;
    onUpdatePosition(deltaX, deltaY);
    dragRef.current.startX = currentX;
    dragRef.current.startY = currentY;
  };

  const handleGridDragEnd = () => {
    dragRef.current.active = false;
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6 pb-6"
    >
      {/* ===== SECTION 1: GRID POSITION ===== */}
      <div className="space-y-3">
        <div>
          <h3 className="text-sm font-light text-white mb-1">Grid Position</h3>
          <p className="text-xs text-gray-500">Align the grid to your fabric</p>
        </div>

        {/* Draggable grid preview */}
        <div
          onMouseDown={handleGridDragStart}
          onMouseMove={handleGridDragMove}
          onMouseUp={handleGridDragEnd}
          onMouseLeave={handleGridDragEnd}
          onTouchStart={handleGridDragStart}
          onTouchMove={handleGridDragMove}
          onTouchEnd={handleGridDragEnd}
          className="relative w-full h-28 bg-gray-900/50 border border-gray-700 rounded-lg cursor-move overflow-hidden"
        >
          <svg
            className="w-full h-full"
            style={{
              transform: `translate(${gridState.offsetX}px, ${gridState.offsetY}px) rotate(${gridState.rotation}deg)`
            }}
          >
            <defs>
              <pattern
                id="grid-preview"
                width={gridState.cellSize}
                height={gridState.cellSize}
                patternUnits="userSpaceOnUse"
              >
                <rect
                  width={gridState.cellSize}
                  height={gridState.cellSize}
                  fill="none"
                  stroke={`${gridColors.find(c => c.id === gridColor)?.color}${Math.round((gridOpacity / 100) * 255).toString(16).padStart(2, '0')}`}
                  strokeWidth="0.5"
                />
              </pattern>
            </defs>
            <rect width="400" height="200" fill="url(#grid-preview)" />
            <circle cx="0" cy="0" r="3" fill={`${gridColors.find(c => c.id === gridColor)?.color}99`} />
            <circle cx="400" cy="0" r="3" fill={`${gridColors.find(c => c.id === gridColor)?.color}99`} />
            <circle cx="0" cy="200" r="3" fill={`${gridColors.find(c => c.id === gridColor)?.color}99`} />
            <circle cx="400" cy="200" r="3" fill={`${gridColors.find(c => c.id === gridColor)?.color}99`} />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <span className="text-xs text-gray-500">Drag to position</span>
          </div>
        </div>

        {/* Position + rotation inline */}
        <div className="grid grid-cols-3 gap-2 text-xs">
          <div className="px-2 py-1.5 rounded bg-gray-800/30 text-gray-400">
            <span className="text-gray-500">X</span> {Math.round(gridState.offsetX)}
          </div>
          <div className="px-2 py-1.5 rounded bg-gray-800/30 text-gray-400">
            <span className="text-gray-500">Y</span> {Math.round(gridState.offsetY)}
          </div>
          <div className="px-2 py-1.5 rounded bg-gray-800/30 text-gray-400">
            <span className="text-gray-500">R</span> {gridState.rotation}°
          </div>
        </div>

        {/* Sliders */}
        <div className="space-y-2">
          <div>
            <div className="flex justify-between mb-1">
              <span className="text-xs text-gray-500">Cell size</span>
              <span className="text-xs text-white font-light">{gridState.cellSize}px</span>
            </div>
            <input
              type="range"
              min="20"
              max="80"
              value={gridState.cellSize}
              onChange={(e) => onUpdateScale(Number(e.target.value))}
              className="w-full h-1 bg-gray-700 rounded-full accent-emerald-500"
            />
          </div>
          <div>
            <div className="flex justify-between mb-1">
              <span className="text-xs text-gray-500">Rotation</span>
              <span className="text-xs text-white font-light">{gridState.rotation}°</span>
            </div>
            <input
              type="range"
              min="0"
              max="360"
              value={gridState.rotation}
              onChange={(e) => onUpdateRotation(Number(e.target.value))}
              className="w-full h-1 bg-gray-700 rounded-full accent-emerald-500"
            />
          </div>
        </div>
      </div>

      {/* ===== SECTION 2: DISPLAY ===== */}
      <div className="space-y-3">
        <div>
          <h3 className="text-sm font-light text-white mb-1">Display</h3>
          <p className="text-xs text-gray-500">How the grid appears</p>
        </div>

        {/* Grid opacity */}
        <div>
          <div className="flex justify-between mb-1">
            <span className="text-xs text-gray-500">Opacity</span>
            <span className="text-xs text-white font-light">{gridOpacity}%</span>
          </div>
          <input
            type="range"
            min="0"
            max="100"
            value={gridOpacity}
            onChange={(e) => setGridOpacity(Number(e.target.value))}
            className="w-full h-1 bg-gray-700 rounded-full accent-emerald-500"
          />
        </div>

        {/* Grid color palette */}
        <div>
          <span className="text-xs text-gray-500 block mb-2">Color</span>
          <div className="grid grid-cols-4 gap-2">
            {gridColors.map(color => (
              <button
                key={color.id}
                onClick={() => setGridColor(color.id)}
                className={`relative px-2 py-2 rounded-lg border transition ${
                  gridColor === color.id
                    ? 'border-white'
                    : 'border-gray-700 hover:border-gray-600'
                }`}
              >
                <div
                  className="w-4 h-4 rounded mx-auto mb-1"
                  style={{ backgroundColor: color.color }}
                />
                <span className="text-xs text-gray-400">{color.label}</span>
                {gridColor === color.id && (
                  <div className="absolute inset-0 rounded border-2 border-white pointer-events-none" />
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Show symbols toggle */}
        <button
          onClick={() => setShowSymbols(!showSymbols)}
          className="w-full flex items-center justify-between px-3 py-2 rounded-lg bg-gray-800/30 hover:bg-gray-800/50 border border-gray-700 transition text-sm text-gray-300"
        >
          <span>Show symbols</span>
          <div className={`w-5 h-5 rounded border transition ${showSymbols ? 'bg-emerald-500/20 border-emerald-500/50' : 'border-gray-600'}`}>
            {showSymbols && <Check className="w-4 h-4 text-emerald-400 mx-auto" />}
          </div>
        </button>

        {/* Symbol density */}
        {showSymbols && (
          <div>
            <span className="text-xs text-gray-500 block mb-2">Density</span>
            <div className="grid grid-cols-3 gap-2">
              {symbolDensity.map(mode => (
                <button
                  key={mode.id}
                  onClick={() => setSymbolMode(mode.id)}
                  className={`p-2 rounded-lg border transition text-center ${
                    symbolMode === mode.id
                      ? 'bg-emerald-500/20 border-emerald-500/50'
                      : 'bg-gray-800/30 border-gray-700 hover:border-gray-600'
                  }`}
                >
                  <div className="text-xs font-light text-white">{mode.label}</div>
                  <div className="text-xs text-gray-500">{mode.description}</div>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* ===== SECTION 3: LOCK & SAFETY ===== */}
      <div className="space-y-3">
        <div>
          <h3 className="text-sm font-light text-white mb-1">Lock & Safety</h3>
          <p className="text-xs text-gray-500">Lock the grid once aligned to avoid mistakes</p>
        </div>

        {/* Lock button */}
        <button
          onClick={gridState.isLocked ? onUnlock : onLock}
          className={`w-full flex items-center justify-between px-3 py-2 rounded-lg border transition text-sm font-light ${
            gridState.isLocked
              ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-400'
              : 'bg-gray-800/30 border-gray-700 text-gray-400 hover:border-emerald-500/30'
          }`}
        >
          <span>{gridState.isLocked ? 'Grid locked' : 'Lock grid'}</span>
          {gridState.isLocked ? (
            <Lock className="w-4 h-4" />
          ) : (
            <Unlock className="w-4 h-4" />
          )}
        </button>

        {/* Undo & Reset */}
        <div className="grid grid-cols-2 gap-2">
          {canUndo && (
            <button
              onClick={onUndo}
              className="flex items-center justify-center gap-2 px-3 py-2 rounded-lg bg-gray-800/30 border border-gray-700 text-gray-400 hover:border-gray-600 transition text-xs font-light"
            >
              <ArrowLeft className="w-3 h-3" />
              Undo
            </button>
          )}
          <button
            onClick={onReset}
            className={`flex items-center justify-center gap-2 px-3 py-2 rounded-lg border transition text-xs font-light ${
              canUndo ? '' : 'col-span-2'
            } bg-gray-800/30 border-gray-700 text-gray-400 hover:border-gray-600`}
          >
            <RotateCcw className="w-3 h-3" />
            Reset
          </button>
        </div>
      </div>

      {/* ===== FOOTER: ACTION CONFIRMATION ===== */}
      <div className="space-y-2 border-t border-gray-700/30 pt-4 mt-6">
        <div className="flex items-center gap-2 text-xs text-gray-400 px-1">
          <Check className="w-3 h-3 text-emerald-400" />
          Grid aligned
        </div>
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={onBackClick}
            className="px-3 py-2 rounded-lg bg-gray-800/50 border border-gray-700 text-gray-400 hover:border-gray-600 transition text-sm font-light"
          >
            Back to Focus
          </button>
          <button
            onClick={onDoneClick}
            className="px-3 py-2 rounded-lg bg-emerald-500/20 border border-emerald-500/50 text-emerald-400 hover:bg-emerald-500/30 transition text-sm font-light"
          >
            Done – Guide mode
          </button>
        </div>
      </div>
    </motion.div>
  );
}