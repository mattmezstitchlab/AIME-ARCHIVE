import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Eye, EyeOff, RotateCcw } from 'lucide-react';

export default function GridControlPanel({ pattern, gridVisible, onGridToggle, detailed }) {
  const [opacity, setOpacity] = useState(100);
  const [scale, setScale] = useState(100);
  const [rotation, setRotation] = useState(0);
  const [offsetX, setOffsetX] = useState(0);
  const [offsetY, setOffsetY] = useState(0);
  const [showSymbols, setShowSymbols] = useState(true);

  const handleReset = () => {
    setOpacity(100);
    setScale(100);
    setRotation(0);
    setOffsetX(0);
    setOffsetY(0);
    setShowSymbols(true);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-4 bg-gray-800/20 rounded-2xl p-4 border border-gray-700/30"
    >
      <div className="flex items-center justify-between">
        <div className="text-xs text-gray-500 uppercase tracking-wider">Grid Controls</div>
        <button
          onClick={handleReset}
          className="p-1 rounded-lg hover:bg-gray-700/30 text-gray-400 hover:text-white transition"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>

      {/* Grid Visibility */}
      <div>
        <button
          onClick={() => onGridToggle(!gridVisible)}
          className="w-full flex items-center justify-between px-3 py-2 rounded-lg bg-gray-700/20 hover:bg-gray-700/30 transition"
        >
          <span className="text-sm text-gray-300">Grid Visible</span>
          {gridVisible ? (
            <Eye className="w-4 h-4 text-emerald-400" />
          ) : (
            <EyeOff className="w-4 h-4 text-gray-600" />
          )}
        </button>
      </div>

      {gridVisible && (
        <>
          {/* Opacity */}
          <div>
            <label className="text-xs text-gray-400 mb-2 block">Opacity: {opacity}%</label>
            <input
              type="range"
              min="0"
              max="100"
              value={opacity}
              onChange={(e) => setOpacity(Number(e.target.value))}
              className="w-full h-1 bg-gray-700 rounded-full accent-emerald-500"
            />
          </div>

          {/* Scale */}
          <div>
            <label className="text-xs text-gray-400 mb-2 block">Cell Size: {scale}%</label>
            <input
              type="range"
              min="50"
              max="200"
              value={scale}
              onChange={(e) => setScale(Number(e.target.value))}
              className="w-full h-1 bg-gray-700 rounded-full accent-emerald-500"
            />
          </div>

          {detailed && (
            <>
              {/* Rotation */}
              <div>
                <label className="text-xs text-gray-400 mb-2 block">Rotation: {rotation}°</label>
                <input
                  type="range"
                  min="-45"
                  max="45"
                  value={rotation}
                  onChange={(e) => setRotation(Number(e.target.value))}
                  className="w-full h-1 bg-gray-700 rounded-full accent-emerald-500"
                />
              </div>

              {/* Offset X */}
              <div>
                <label className="text-xs text-gray-400 mb-2 block">Offset X: {offsetX}px</label>
                <input
                  type="range"
                  min="-50"
                  max="50"
                  value={offsetX}
                  onChange={(e) => setOffsetX(Number(e.target.value))}
                  className="w-full h-1 bg-gray-700 rounded-full accent-emerald-500"
                />
              </div>

              {/* Offset Y */}
              <div>
                <label className="text-xs text-gray-400 mb-2 block">Offset Y: {offsetY}px</label>
                <input
                  type="range"
                  min="-50"
                  max="50"
                  value={offsetY}
                  onChange={(e) => setOffsetY(Number(e.target.value))}
                  className="w-full h-1 bg-gray-700 rounded-full accent-emerald-500"
                />
              </div>

              {/* Show Symbols */}
              <div>
                <button
                  onClick={() => setShowSymbols(!showSymbols)}
                  className="w-full flex items-center justify-between px-3 py-2 rounded-lg bg-gray-700/20 hover:bg-gray-700/30 transition text-sm text-gray-300"
                >
                  Show Symbols
                  <span className={`text-xs ${showSymbols ? 'text-emerald-400' : 'text-gray-600'}`}>
                    {showSymbols ? 'ON' : 'OFF'}
                  </span>
                </button>
              </div>
            </>
          )}
        </>
      )}
    </motion.div>
  );
}