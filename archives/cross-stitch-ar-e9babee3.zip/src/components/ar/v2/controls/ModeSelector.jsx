import React from 'react';
import { motion } from 'framer-motion';

const modes = [
  {
    id: 'focus',
    label: 'Focus',
    description: 'Minimal • Just stitch'
  },
  {
    id: 'guide',
    label: 'Guide',
    description: 'Voice companion'
  },
  {
    id: 'adjust',
    label: 'Adjust',
    description: 'Grid controls'
  }
];

export default function ModeSelector({ value, onChange }) {
  return (
    <div className="space-y-2">
      <div className="text-xs text-gray-500 uppercase tracking-wider">Mode</div>
      <div className="grid grid-cols-3 gap-2">
        {modes.map(mode => (
          <motion.button
            key={mode.id}
            onClick={() => onChange(mode.id)}
            whileTap={{ scale: 0.95 }}
            className={`relative px-3 py-3 rounded-lg text-center transition ${
              value === mode.id
                ? 'bg-emerald-500/20 border border-emerald-500/50'
                : 'bg-gray-800/30 border border-gray-700 hover:border-gray-600'
            }`}
          >
            {value === mode.id && (
              <motion.div
                layoutId="mode-indicator"
                className="absolute inset-0 rounded-lg border-2 border-emerald-400"
                transition={{ type: 'spring', stiffness: 300, damping: 30 }}
              />
            )}
            <div className="relative z-10">
              <div className="text-sm font-light text-white">{mode.label}</div>
              <div className="text-xs text-gray-500">{mode.description}</div>
            </div>
          </motion.button>
        ))}
      </div>
    </div>
  );
}