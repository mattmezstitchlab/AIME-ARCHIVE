import React, { useState, useRef, useEffect } from 'react';
import { Volume2, Mic, RotateCcw, Pause, Play } from 'lucide-react';
import { Slider } from '@/components/ui/slider';

export default function VoiceSettings({ 
  onVolumeChange, 
  onSpeedChange, 
  onVoiceSelect,
  onReplayInstructions,
  onPauseToggle,
  isPaused,
  volume = 70,
  speed = 1,
  selectedVoice = 0
}) {
  const [voices, setVoices] = useState([]);
  const [isListening, setIsListening] = useState(false);
  const recognitionRef = useRef(null);

  useEffect(() => {
    const synth = window.speechSynthesis;
    const updateVoices = () => {
      setVoices(synth.getVoices());
    };
    
    synth.onvoiceschanged = updateVoices;
    updateVoices();
  }, []);

  const startVoiceCommand = () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) return;

    if (!recognitionRef.current) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.lang = 'fr-FR';
      recognitionRef.current.continuous = false;

      recognitionRef.current.onstart = () => setIsListening(true);
      recognitionRef.current.onend = () => setIsListening(false);
      recognitionRef.current.onresult = (event) => {
        const transcript = event.results[0][0].transcript.toLowerCase();
        if (transcript.includes('suivant') || transcript.includes('next')) {
          window.dispatchEvent(new CustomEvent('voiceCommand', { detail: 'next' }));
        } else if (transcript.includes('retour') || transcript.includes('back')) {
          window.dispatchEvent(new CustomEvent('voiceCommand', { detail: 'previous' }));
        }
      };
    }

    recognitionRef.current.start();
  };

  return (
    <div className="space-y-4">
      {/* Volume */}
      <div className="space-y-2">
        <label className="text-xs text-gray-400 uppercase tracking-wider flex items-center gap-2">
          <Volume2 className="w-3.5 h-3.5" />
          Volume
        </label>
        <Slider
          value={[volume]}
          onValueChange={(val) => onVolumeChange(val[0])}
          min={0}
          max={100}
          step={5}
          className="w-full"
        />
        <p className="text-xs text-gray-500">{volume}%</p>
      </div>

      {/* Speed */}
      <div className="space-y-2">
        <label className="text-xs text-gray-400 uppercase tracking-wider">Vitesse</label>
        <Slider
          value={[speed * 10]}
          onValueChange={(val) => onSpeedChange(val[0] / 10)}
          min={5}
          max={20}
          step={1}
          className="w-full"
        />
        <p className="text-xs text-gray-500">{speed.toFixed(1)}x</p>
      </div>

      {/* Voice Selection */}
      {voices.length > 0 && (
        <div className="space-y-2">
          <label className="text-xs text-gray-400 uppercase tracking-wider">Voix</label>
          <select
            onChange={(e) => onVoiceSelect(parseInt(e.target.value))}
            defaultValue={selectedVoice}
            className="w-full bg-gray-800/50 border border-gray-700 rounded text-xs text-white px-2 py-1.5"
          >
            {voices.map((voice, idx) => (
              <option key={idx} value={idx}>
                {voice.name} {voice.lang}
              </option>
            ))}
          </select>
        </div>
      )}

      {/* Controls */}
      <div className="grid grid-cols-3 gap-2 pt-2">
        <button
          onClick={onReplayInstructions}
          className="flex items-center justify-center gap-1.5 px-2 py-2 rounded-lg bg-blue-500/20 border border-blue-500/30 text-blue-400 hover:bg-blue-500/30 transition text-xs"
          title="Rejouer les instructions"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Rejouer</span>
        </button>

        <button
          onClick={onPauseToggle}
          className={`flex items-center justify-center gap-1.5 px-2 py-2 rounded-lg border transition text-xs ${
            isPaused
              ? 'bg-emerald-500/20 border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/30'
              : 'bg-orange-500/20 border-orange-500/30 text-orange-400 hover:bg-orange-500/30'
          }`}
        >
          {isPaused ? <Play className="w-3.5 h-3.5" /> : <Pause className="w-3.5 h-3.5" />}
          <span className="hidden sm:inline">{isPaused ? 'Reprendre' : 'Pause'}</span>
        </button>

        <button
          onClick={startVoiceCommand}
          disabled={isListening}
          className={`flex items-center justify-center gap-1.5 px-2 py-2 rounded-lg border transition text-xs ${
            isListening
              ? 'bg-purple-500/30 border-purple-500/50 text-purple-300'
              : 'bg-purple-500/20 border-purple-500/30 text-purple-400 hover:bg-purple-500/30'
          }`}
          title="Commandes vocales: 'suivant', 'retour'"
        >
          <Mic className={`w-3.5 h-3.5 ${isListening ? 'animate-pulse' : ''}`} />
          <span className="hidden sm:inline">{isListening ? 'Écoute...' : 'Voix'}</span>
        </button>
      </div>
    </div>
  );
}