import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ChevronDown, Palette, Pen, Eraser, Pipette, RotateCcw, Lock, Unlock, ArrowLeft, Check, Volume2, VolumeX } from 'lucide-react';
import ModeSelector from '../controls/ModeSelector';
import AdjustModePanel from '../controls/AdjustModePanel';

export default function LeftPanel({
  dmcPalette,
  selectedColor,
  onColorSelect,
  onToolChange,
  selectedTool,
  mode,
  onModeChange,
  gridCalibration,
  voiceEnabled,
  onVoiceToggle,
  onSessionEnd
}) {
  const [showPalette, setShowPalette] = useState(true);
  const [showControls, setShowControls] = useState(mode === 'adjust');

  const tools = [
    { id: 'pen', icon: Pen, label: 'Draw', color: 'text-emerald-400' },
    { id: 'eraser', icon: Eraser, label: 'Erase', color: 'text-red-400' },
    { id: 'pipette', icon: Pipette, label: 'Pick', color: 'text-blue-400' }
  ];

  return (
    <motion.div
      initial={{ x: -300, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      transition={{ delay: 0.1 }}
      className="fixed left-0 top-16 h-[calc(100vh-64px)] w-72 bg-black/60 backdrop-blur-xl border-r border-gray-700/30 overflow-y-auto z-20"
    >
      {/* Mode Selector */}
      <div className="p-4 border-b border-gray-700/20">
        <ModeSelector value={mode} onChange={onModeChange} />
      </div>

      {/* Adjust Mode Controls */}
      {mode === 'adjust' && (
        <div className="p-4 space-y-4 border-b border-gray-700/20">
          <button
            onClick={() => setShowControls(!showControls)}
            className="w-full flex items-center justify-between text-xs font-light text-gray-400 uppercase tracking-wider hover:text-white transition"
          >
            <span>Grid Controls</span>
            <ChevronDown className={`w-3 h-3 transition ${showControls ? 'rotate-180' : ''}`} />
          </button>
          {showControls && (
            <AdjustModePanel
              gridState={gridCalibration.gridState}
              onUpdatePosition={gridCalibration.updateGridPosition}
              onUpdateScale={gridCalibration.updateGridScale}
              onUpdateRotation={gridCalibration.updateGridRotation}
              onLock={gridCalibration.lockGrid}
              onUnlock={gridCalibration.unlockGrid}
              onReset={gridCalibration.resetGrid}
              onUndo={gridCalibration.undo}
              canUndo={gridCalibration.canUndo}
              onDoneClick={() => {
                gridCalibration.lockGrid();
                onModeChange('guide');
              }}
              onBackClick={() => onModeChange('focus')}
            />
          )}
        </div>
      )}

      {/* Tools Section */}
      <div className="p-4 space-y-3 border-b border-gray-700/20">
        <h3 className="text-xs font-light text-gray-400 uppercase tracking-wider">Tools</h3>
        <div className="grid grid-cols-3 gap-2">
          {tools.map(tool => {
            const IconComponent = tool.icon;
            return (
              <button
                key={tool.id}
                onClick={() => onToolChange(tool.id)}
                className={`flex flex-col items-center gap-1 px-3 py-2 rounded-lg transition ${
                  selectedTool === tool.id
                    ? 'bg-emerald-500/20 border border-emerald-500/50'
                    : 'bg-gray-800/30 border border-gray-700 hover:border-gray-600'
                }`}
                title={tool.label}
              >
                <IconComponent className={`w-4 h-4 ${tool.color}`} />
                <span className="text-xs text-gray-300">{tool.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Color Palette Section */}
      <div className="p-4 space-y-3 border-b border-gray-700/20">
        <button
          onClick={() => setShowPalette(!showPalette)}
          className="flex items-center justify-between w-full"
        >
          <div className="flex items-center gap-2">
            <Palette className="w-4 h-4 text-emerald-400" />
            <h3 className="text-xs font-light text-gray-400 uppercase tracking-wider">DMC Colors</h3>
          </div>
          <ChevronDown className={`w-3 h-3 text-gray-500 transition ${showPalette ? 'rotate-180' : ''}`} />
        </button>

        {showPalette && (
          <div className="space-y-2 max-h-96 overflow-y-auto">
            {dmcPalette?.map(color => (
              <button
                key={color.dmc_code}
                onClick={() => onColorSelect(color)}
                className={`w-full flex items-center gap-3 p-2 rounded-lg border transition ${
                  selectedColor?.dmc_code === color.dmc_code
                    ? 'bg-gray-800/80 border-emerald-500/50'
                    : 'bg-gray-800/30 border-gray-700 hover:border-gray-600'
                }`}
              >
                <div
                  className="w-6 h-6 rounded border border-gray-600"
                  style={{ backgroundColor: color.color_hex }}
                  title={color.name}
                />
                <div className="flex-1 text-left">
                  <div className="text-xs font-light text-white">{color.dmc_code}</div>
                  <div className="text-xs text-gray-500">{color.name?.substring(0, 15)}</div>
                </div>
                {selectedColor?.dmc_code === color.dmc_code && (
                  <div className="w-2 h-2 rounded-full bg-emerald-400" />
                )}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Voice & Session Controls */}
      {mode !== 'adjust' && (
        <div className="p-4 space-y-2 border-t border-gray-700/20">
          <button
            onClick={() => onVoiceToggle(!voiceEnabled)}
            className={`w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg border transition text-xs ${
              voiceEnabled
                ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-300'
                : 'bg-gray-800/30 border-gray-700 text-gray-400 hover:border-gray-600'
            }`}
          >
            {voiceEnabled ? <Volume2 className="w-3 h-3" /> : <VolumeX className="w-3 h-3" />}
            Voice {voiceEnabled ? 'On' : 'Off'}
          </button>
          <button
            onClick={onSessionEnd}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg bg-red-500/20 hover:bg-red-500/30 border border-red-500/30 text-red-400 transition text-xs"
          >
            End Session
          </button>
        </div>
      )}

      {/* Quick Actions */}
      <div className="p-4 space-y-2 border-t border-gray-700/20">
        <button className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg bg-gray-800/30 hover:bg-gray-800/50 border border-gray-700 transition text-xs text-gray-300">
          <RotateCcw className="w-3 h-3" />
          Clear Canvas
        </button>
      </div>
    </motion.div>
  );
}