import React from 'react';
import { motion } from 'framer-motion';
import { Zap, Eye, Volume2 } from 'lucide-react';

export default function MinimalBar({ mode, gridVisible, onGridToggle, voiceEnabled }) {
  const modeLabel = {
    focus: 'Focus',
    guide: 'Guide',
    adjust: 'Adjust'
  }[mode];

  return (
    <motion.div
      initial={{ y: 100 }}
      animate={{ y: 0 }}
      className="fixed bottom-0 left-0 right-0 z-20 bg-gradient-to-t from-black/80 to-black/40 backdrop-blur-md border-t border-gray-700/30 px-6 py-3"
    >
      <div className="flex items-center justify-between max-w-7xl mx-auto text-xs text-gray-300">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Zap className="w-3 h-3 text-emerald-400" />
            <span className="font-light">{modeLabel} Mode</span>
          </div>

          <button
            onClick={() => onGridToggle(!gridVisible)}
            className={`flex items-center gap-1.5 px-2 py-1 rounded transition ${
              gridVisible
                ? 'text-emerald-400 bg-emerald-500/10'
                : 'text-gray-500 hover:text-gray-400'
            }`}
          >
            <Eye className="w-3 h-3" />
            Grid
          </button>

          {voiceEnabled && (
            <div className="flex items-center gap-1.5 text-emerald-400">
              <Volume2 className="w-3 h-3" />
              <span>Voice</span>
            </div>
          )}
        </div>

        <span className="text-gray-500">Drag panel to move • ↑ to minimize</span>
      </div>
    </motion.div>
  );
}