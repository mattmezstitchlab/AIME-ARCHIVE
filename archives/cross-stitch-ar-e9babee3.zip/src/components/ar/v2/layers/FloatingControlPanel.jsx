import React, { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { ChevronUp, X } from 'lucide-react';
import ModeSelector from '../controls/ModeSelector';
import AdjustModePanel from '../controls/AdjustModePanel';
import VoicePanel from '../controls/VoicePanel';

export default function FloatingControlPanel({
  mode,
  onModeChange,
  gridCalibration,
  voiceEnabled,
  onVoiceToggle,
  nextStitch,
  pattern,
  session,
  onSessionEnd
}) {
  const [isMinimized, setIsMinimized] = useState(false);
  const [position, setPosition] = useState({ x: 20, y: 20 });
  const [dragging, setDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const panelRef = useRef(null);

  const handleDragStart = (e) => {
    setDragging(true);
    const rect = panelRef.current?.getBoundingClientRect();
    if (rect) {
      setDragOffset({
        x: e.clientX - rect.left,
        y: e.clientY - rect.top
      });
    }
  };

  const handleDragMove = (e) => {
    if (!dragging) return;
    setPosition({
      x: e.clientX - dragOffset.x,
      y: e.clientY - dragOffset.y
    });
  };

  const handleDragEnd = () => {
    setDragging(false);
  };

  React.useEffect(() => {
    if (dragging) {
      window.addEventListener('mousemove', handleDragMove);
      window.addEventListener('mouseup', handleDragEnd);
      return () => {
        window.removeEventListener('mousemove', handleDragMove);
        window.removeEventListener('mouseup', handleDragEnd);
      };
    }
  }, [dragging, dragOffset]);

  return (
    <motion.div
      ref={panelRef}
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      style={{
        position: 'fixed',
        left: `${position.x}px`,
        top: `${position.y}px`,
        zIndex: 40
      }}
      className="w-80 bg-black/60 backdrop-blur-xl border border-gray-700/40 rounded-xl shadow-2xl overflow-hidden"
    >
      {/* Header */}
      <div
        onMouseDown={handleDragStart}
        className="flex items-center justify-between px-4 py-3 cursor-grab active:cursor-grabbing border-b border-gray-700/30 bg-gradient-to-r from-gray-900/40 to-transparent"
      >
        <div className="flex items-center gap-2">
          <div className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
          <span className="text-xs font-light text-gray-300 uppercase tracking-wide">Controls</span>
        </div>
        <button
          onClick={() => setIsMinimized(!isMinimized)}
          className="p-1 hover:bg-gray-800/50 rounded transition"
        >
          <ChevronUp
            className={`w-4 h-4 text-gray-400 transition-transform ${
              isMinimized ? 'rotate-180' : ''
            }`}
          />
        </button>
      </div>

      {/* Content */}
      {!isMinimized && (
        <div className="px-4 py-4 space-y-4 max-h-96 overflow-y-auto">
          {/* Mode Selector */}
          <ModeSelector value={mode} onChange={onModeChange} />

          {/* Adjust Mode Controls */}
          {mode === 'adjust' && (
            <div className="space-y-3 border-t border-gray-700/20 pt-4">
              <AdjustModePanel
                gridState={gridCalibration.gridState}
                onUpdatePosition={gridCalibration.updateGridPosition}
                onUpdateScale={gridCalibration.updateGridScale}
                onUpdateRotation={gridCalibration.updateGridRotation}
                onLock={gridCalibration.lockGrid}
                onUnlock={gridCalibration.unlockGrid}
                onReset={gridCalibration.resetGrid}
                onUndo={gridCalibration.undo}
                canUndo={gridCalibration.canUndo}
                onDoneClick={() => {
                  gridCalibration.lockGrid();
                  onModeChange('guide');
                }}
                onBackClick={() => onModeChange('focus')}
              />
            </div>
          )}

          {/* Voice Panel */}
          {mode === 'guide' && voiceEnabled && (
            <div className="space-y-3 border-t border-gray-700/20 pt-4">
              <VoicePanel
                nextStitch={nextStitch}
                onVoiceToggle={onVoiceToggle}
              />
            </div>
          )}

          {/* Quick Actions */}
          {mode !== 'adjust' && (
            <div className="grid grid-cols-2 gap-2 border-t border-gray-700/20 pt-4">
              <button
                onClick={() => onVoiceToggle(!voiceEnabled)}
                className="px-3 py-2 rounded-lg bg-gray-800/50 hover:bg-gray-800 border border-gray-700 text-xs text-gray-300 transition"
              >
                Voice {voiceEnabled ? 'On' : 'Off'}
              </button>
              <button
                onClick={onSessionEnd}
                className="px-3 py-2 rounded-lg bg-red-500/20 hover:bg-red-500/30 border border-red-500/30 text-xs text-red-400 transition"
              >
                End
              </button>
            </div>
          )}
        </div>
      )}
    </motion.div>
  );
}