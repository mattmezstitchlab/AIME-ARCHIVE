import React from 'react';
import { motion } from 'framer-motion';

const modeLabels = {
  focus: 'Focus',
  guide: 'Guide',
  adjust: 'Adjust'
};

export default function TopHUD({ mode, progress, stitchesLeft }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex items-center justify-between px-6 pt-4 text-white"
    >
      {/* Left: Mode + tracking */}
      <div className="flex items-center gap-3">
        <div className="text-xs font-light text-gray-300">
          {modeLabels[mode]}
        </div>
        <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
      </div>

      {/* Right: Progress */}
      <div className="text-right">
        <div className="text-xs font-light text-gray-400">
          {Math.round(progress)}% · {stitchesLeft} left
        </div>
        <div className="mt-1 h-0.5 w-32 bg-gray-800 rounded-full overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ type: 'spring', stiffness: 50 }}
            className="h-full bg-emerald-500"
          />
        </div>
      </div>
    </motion.div>
  );
}