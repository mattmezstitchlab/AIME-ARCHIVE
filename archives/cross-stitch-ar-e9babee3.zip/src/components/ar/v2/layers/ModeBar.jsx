import React from 'react';
import { motion } from 'framer-motion';

export default function ModeBar({ mode, onModeChange, progress, totalStitches }) {
  const modes = [
    { id: 'focus', label: 'Focus', description: 'Stitch with precision' },
    { id: 'guide', label: 'Guide', description: 'Guided stitching' },
    { id: 'adjust', label: 'Adjust', description: 'Calibrate grid' }
  ];

  return (
    <motion.div
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="fixed bottom-0 left-0 right-0 z-20 bg-gradient-to-t from-black/80 to-black/40 backdrop-blur-md border-t border-gray-700/30 px-6 py-4"
    >
      <div className="flex items-center justify-between max-w-7xl mx-auto">
        {/* Mode Selector */}
        <div className="flex items-center gap-2">
          {modes.map(m => (
            <button
              key={m.id}
              onClick={() => onModeChange(m.id)}
              className={`flex flex-col gap-0.5 px-4 py-2 rounded-lg border transition ${
                mode === m.id
                  ? 'bg-emerald-500/20 border-emerald-500/50'
                  : 'bg-gray-800/30 border-gray-700 hover:border-gray-600'
              }`}
            >
              <span className="text-xs font-light text-white">{m.label}</span>
              <span className="text-xs text-gray-500 hidden sm:inline">{m.description}</span>
            </button>
          ))}
        </div>

        {/* Progress */}
        <div className="flex items-center gap-4 text-right">
          <div>
            <p className="text-xs text-gray-400">Progress</p>
            <p className="text-sm font-light text-emerald-400">
              {progress || 0} / {totalStitches || 0} stitches
            </p>
          </div>
        </div>
      </div>
    </motion.div>
  );
}