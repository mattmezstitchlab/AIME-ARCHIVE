import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ChevronDown, Grid3x3, Settings2 } from 'lucide-react';

const symbols = ['•', '×', '◉', '○', '▪', '□', '+', '✓', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];

export default function RightPanel({ selectedSymbol, onSymbolSelect, showSymbols, onToggleSymbols }) {
  const [showSymbolPanel, setShowSymbolPanel] = useState(true);

  return (
    <motion.div
      initial={{ x: 300, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      transition={{ delay: 0.1 }}
      className="fixed right-0 top-16 h-[calc(100vh-64px)] w-64 bg-black/60 backdrop-blur-xl border-l border-gray-700/30 overflow-y-auto z-20"
    >
      {/* Symbols Section */}
      <div className="p-4 space-y-3 border-b border-gray-700/20">
        <button
          onClick={() => setShowSymbolPanel(!showSymbolPanel)}
          className="flex items-center justify-between w-full"
        >
          <div className="flex items-center gap-2">
            <Grid3x3 className="w-4 h-4 text-emerald-400" />
            <h3 className="text-xs font-light text-gray-400 uppercase tracking-wider">Symbols</h3>
          </div>
          <ChevronDown className={`w-3 h-3 text-gray-500 transition ${showSymbolPanel ? 'rotate-180' : ''}`} />
        </button>

        {/* Toggle */}
        <button
          onClick={() => onToggleSymbols(!showSymbols)}
          className={`w-full flex items-center justify-between px-3 py-2 rounded-lg border transition text-xs ${
            showSymbols
              ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-300'
              : 'bg-gray-800/30 border-gray-700 text-gray-400 hover:border-gray-600'
          }`}
        >
          {showSymbols ? 'Symbols On' : 'Symbols Off'}
        </button>

        {showSymbolPanel && (
          <div className="grid grid-cols-4 gap-2">
            {symbols.map((symbol, idx) => (
              <button
                key={idx}
                onClick={() => onSymbolSelect(symbol)}
                className={`w-12 h-12 rounded-lg border transition flex items-center justify-center text-lg ${
                  selectedSymbol === symbol
                    ? 'bg-emerald-500/20 border-emerald-500/50'
                    : 'bg-gray-800/30 border-gray-700 hover:border-gray-600'
                }`}
              >
                {symbol}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Settings */}
      <div className="p-4 space-y-3">
        <div className="flex items-center gap-2 mb-2">
          <Settings2 className="w-4 h-4 text-emerald-400" />
          <h3 className="text-xs font-light text-gray-400 uppercase tracking-wider">Display</h3>
        </div>

        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-xs text-gray-400">Symbol Size</span>
            <input
              type="range"
              min="8"
              max="24"
              defaultValue="12"
              className="w-20 h-1 bg-gray-700 rounded-full accent-emerald-500"
            />
          </div>
          <div className="flex justify-between items-center">
            <span className="text-xs text-gray-400">Opacity</span>
            <input
              type="range"
              min="0"
              max="100"
              defaultValue="100"
              className="w-20 h-1 bg-gray-700 rounded-full accent-emerald-500"
            />
          </div>
        </div>
      </div>
    </motion.div>
  );
}