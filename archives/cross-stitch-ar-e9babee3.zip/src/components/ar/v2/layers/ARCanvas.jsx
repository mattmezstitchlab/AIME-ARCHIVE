import React, { useRef, useEffect } from 'react';

export default function ARCanvas({
  pattern,
  session,
  gridVisible,
  highlightNextStitch,
  gridState,
  showAdjustHandles,
  onStitchTap
}) {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);

  useEffect(() => {
    // Initialize camera feed
    const startCamera = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment' }
        });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      } catch (err) {
        console.error('Camera error:', err);
      }
    };
    
    startCamera();
  }, []);

  useEffect(() => {
    if (!canvasRef.current || !pattern) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    
    // Draw AR grid overlay
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    if (gridVisible) {
      drawGrid(ctx, canvas, pattern, gridState);
    }

    if (highlightNextStitch && session?.last_position) {
      highlightStitch(ctx, canvas, session.last_position, pattern, gridState);
    }

    if (showAdjustHandles) {
      drawAdjustHandles(ctx, canvas, gridState);
    }
  }, [pattern, session, gridVisible, highlightNextStitch, gridState, showAdjustHandles]);

  const drawGrid = (ctx, canvas, pattern, gridState) => {
    const cellSize = gridState.cellSize;
    const offsetX = gridState.offsetX;
    const offsetY = gridState.offsetY;
    const rotation = gridState.rotation;

    ctx.save();
    ctx.translate(offsetX, offsetY);
    ctx.rotate((rotation * Math.PI) / 180);

    ctx.strokeStyle = 'rgba(34, 197, 94, 0.3)';
    ctx.lineWidth = 1;

    for (let x = 0; x <= pattern.grid_width; x++) {
      ctx.beginPath();
      ctx.moveTo(x * cellSize, 0);
      ctx.lineTo(x * cellSize, pattern.grid_height * cellSize);
      ctx.stroke();
    }

    for (let y = 0; y <= pattern.grid_height; y++) {
      ctx.beginPath();
      ctx.moveTo(0, y * cellSize);
      ctx.lineTo(pattern.grid_width * cellSize, y * cellSize);
      ctx.stroke();
    }

    ctx.restore();
  };

  const highlightStitch = (ctx, canvas, position, pattern, gridState) => {
    const cellSize = gridState.cellSize;
    const offsetX = gridState.offsetX;
    const offsetY = gridState.offsetY;
    const rotation = gridState.rotation;

    const x = position.x * cellSize;
    const y = position.y * cellSize;

    ctx.save();
    ctx.translate(offsetX, offsetY);
    ctx.rotate((rotation * Math.PI) / 180);

    ctx.fillStyle = 'rgba(34, 197, 94, 0.3)';
    ctx.fillRect(x, y, cellSize, cellSize);

    ctx.strokeStyle = 'rgba(34, 197, 94, 0.8)';
    ctx.lineWidth = 2;
    ctx.strokeRect(x, y, cellSize, cellSize);

    ctx.restore();
  };

  const drawAdjustHandles = (ctx, canvas, gridState) => {
    const cellSize = gridState.cellSize;
    const offsetX = gridState.offsetX;
    const offsetY = gridState.offsetY;
    const rotation = gridState.rotation;
    const gridWidth = cellSize * 10;
    const gridHeight = cellSize * 10;

    ctx.save();
    ctx.translate(offsetX, offsetY);
    ctx.rotate((rotation * Math.PI) / 180);

    // Corner handles
    const corners = [
      { x: 0, y: 0 },
      { x: gridWidth, y: 0 },
      { x: 0, y: gridHeight },
      { x: gridWidth, y: gridHeight }
    ];

    corners.forEach(corner => {
      ctx.fillStyle = 'rgba(34, 197, 94, 0.8)';
      ctx.fillRect(corner.x - 4, corner.y - 4, 8, 8);
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.5)';
      ctx.lineWidth = 1;
      ctx.strokeRect(corner.x - 4, corner.y - 4, 8, 8);
    });

    ctx.restore();
  };

  return (
    <>
      <video
        ref={videoRef}
        autoPlay
        playsInline
        className="w-full h-full object-cover"
      />
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full"
        width={typeof window !== 'undefined' ? window.innerWidth : 400}
        height={typeof window !== 'undefined' ? window.innerHeight : 800}
      />
    </>
  );
}