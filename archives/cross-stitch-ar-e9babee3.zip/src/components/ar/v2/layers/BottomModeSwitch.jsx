import React from 'react';
import { motion } from 'framer-motion';
import { Target, Mic, Wrench, Edit3 } from 'lucide-react';

export default function BottomModeSwitch({
  currentMode,
  onModeChange,
  progress,
  totalStitches
}) {
  const modes = [
    { id: 'focus', label: 'Focus', icon: Target, description: 'Stitch' },
    { id: 'guide', label: 'Guide', icon: Mic, description: 'Voice' },
    { id: 'adjust', label: 'Adjust', icon: Wrench, description: 'Calibrate' },
    { id: 'create', label: 'Create', icon: Edit3, description: 'Draw' }
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="fixed bottom-0 left-0 right-0 z-40 bg-black/60 backdrop-blur-xl border-t border-gray-800/50 safe-bottom"
    >
      <div className="h-20 px-2 flex items-center justify-between gap-2">
        {/* Progress indicator (Focus/Guide/Create modes) */}
        {(currentMode === 'focus' || currentMode === 'guide' || currentMode === 'create') && totalStitches && (
          <div className="flex-1 min-w-0 flex items-center gap-2 px-2 text-xs text-gray-400">
            <div className="flex-1">
              <div className="h-1 bg-gray-700 rounded-full overflow-hidden">
                <div
                  className="h-full bg-emerald-500 transition-all"
                  style={{ width: `${progress || 0}%` }}
                />
              </div>
            </div>
            <span className="flex-shrink-0 text-xs text-gray-500">
              {Math.round(progress || 0)}%
            </span>
          </div>
        )}

        {/* Mode buttons */}
        <div className="flex gap-1">
          {modes.map(m => {
            const Icon = m.icon;
            const isActive = currentMode === m.id;
            return (
              <button
                key={m.id}
                onClick={() => onModeChange(m.id)}
                className={`flex flex-col items-center justify-center gap-1 px-3 py-2 rounded-lg transition-all flex-1 ${
                  isActive
                    ? 'bg-emerald-500/30 border border-emerald-500/60 text-emerald-400'
                    : 'bg-gray-800/30 border border-gray-700/30 text-gray-500 hover:text-gray-400 hover:border-gray-600'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span className="text-xs font-light">{m.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </motion.div>
  );
}