import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, Plus, BookOpen, Library, Zap, ArrowLeft } from 'lucide-react';

export default function StudioMenu({ 
  patterns, 
  sessions, 
  onCreatePattern, 
  onPatternSelect, 
  onSessionSelect,
  onBackToStudio 
}) {
  const [isOpen, setIsOpen] = useState(false);

  const stats = {
    active: sessions.filter(s => !s.is_completed && !s.is_archived).length,
    completed: sessions.filter(s => s.is_completed).length,
    patterns: patterns.length
  };

  const menuSections = [
    {
      id: 'sessions',
      label: 'Mes Sessions',
      icon: Zap,
      items: sessions.slice(0, 3).map(s => ({
        id: s.id,
        label: s.pattern_title,
        status: s.is_completed ? 'done' : 'active',
        progress: s.progress_percentage
      })),
      action: () => {}
    },
    {
      id: 'patterns',
      label: 'Patterns',
      icon: Library,
      count: patterns.length,
      action: () => setIsOpen(false)
    },
    {
      id: 'tools',
      label: 'Outils',
      icon: Plus,
      items: [
        { id: 'create', label: 'Créer Pattern', action: onCreatePattern },
        { id: 'guides', label: 'Guides', action: () => {} }
      ]
    }
  ];

  return (
    <>
      {/* Menu Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-1.5 px-2.5 py-1.5 rounded hover:bg-gray-800/50 transition text-xs text-gray-300 hover:text-white"
        title="Menu"
      >
        <Menu className="w-4 h-4 text-gray-400" />
        <span className="hidden sm:inline font-light">Menu</span>
      </button>

      {/* Dropdown Menu */}
      <AnimatePresence>
        {isOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOpen(false)}
              className="fixed inset-0 z-40"
            />

            <motion.div
              initial={{ opacity: 0, y: -10, x: -20 }}
              animate={{ opacity: 1, y: 0, x: 0 }}
              exit={{ opacity: 0, y: -10, x: -20 }}
              className="fixed top-16 left-6 w-72 max-h-[calc(100vh-120px)] bg-gray-900/95 border border-gray-700/30 rounded-xl overflow-hidden z-50 shadow-2xl"
            >
              {/* Header */}
              <div className="sticky top-0 bg-gray-900/80 backdrop-blur-sm border-b border-gray-700/20 px-4 py-3 flex items-center justify-between">
                <h3 className="text-sm font-light text-white">Studio Broderie</h3>
                <button
                  onClick={() => setIsOpen(false)}
                  className="p-1 hover:bg-gray-800/50 rounded text-gray-400 transition"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Content */}
              <div className="overflow-y-auto space-y-1 p-2">
                {/* Sessions Section */}
                {sessions.length > 0 && (
                  <div className="space-y-2">
                    <p className="text-xs text-gray-500 uppercase tracking-wider px-2 font-light">
                      Sessions ({stats.active})
                    </p>
                    {sessions.slice(0, 3).map(session => (
                      <button
                        key={session.id}
                        onClick={() => {
                          onSessionSelect(session);
                          setIsOpen(false);
                        }}
                        className="w-full text-left px-3 py-2 rounded-lg bg-gray-800/30 hover:bg-gray-800/60 transition space-y-1"
                      >
                        <p className="text-xs text-white font-light">{session.pattern_title}</p>
                        <div className="flex items-center gap-2">
                          <div className="flex-1 h-1 bg-gray-700 rounded-full overflow-hidden">
                            <div
                              className="h-full bg-emerald-500"
                              style={{ width: `${session.progress_percentage}%` }}
                            />
                          </div>
                          <p className="text-xs text-gray-400">{session.progress_percentage}%</p>
                        </div>
                      </button>
                    ))}
                  </div>
                )}

                {/* Patterns Section */}
                {patterns.length > 0 && (
                  <div className="space-y-2">
                    <p className="text-xs text-gray-500 uppercase tracking-wider px-2 font-light">
                      Patterns ({patterns.length})
                    </p>
                    {patterns.slice(0, 4).map(pattern => (
                      <button
                        key={pattern.id}
                        onClick={() => {
                          onPatternSelect(pattern);
                          setIsOpen(false);
                        }}
                        className="w-full text-left px-3 py-2 rounded-lg bg-gray-800/30 hover:bg-gray-800/60 transition"
                      >
                        <p className="text-xs text-white font-light">{pattern.title}</p>
                        <p className="text-xs text-gray-500">{pattern.grid_width}×{pattern.grid_height}</p>
                      </button>
                    ))}
                  </div>
                )}

                {/* Tools Section */}
                <div className="border-t border-gray-700/20 pt-2 space-y-2">
                  <p className="text-xs text-gray-500 uppercase tracking-wider px-2 font-light">
                    Outils
                  </p>
                  <button
                    onClick={() => {
                      onCreatePattern();
                      setIsOpen(false);
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 rounded-lg bg-emerald-500/20 border border-emerald-500/30 hover:bg-emerald-500/30 transition text-emerald-400 text-xs"
                  >
                    <Plus className="w-4 h-4" />
                    Créer Pattern
                  </button>
                </div>

                {/* Back to Studio */}
                <div className="border-t border-gray-700/20 pt-2">
                  <button
                    onClick={() => {
                      onBackToStudio();
                      setIsOpen(false);
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-gray-800/50 transition text-gray-400 text-xs"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    Retour Studio
                  </button>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}