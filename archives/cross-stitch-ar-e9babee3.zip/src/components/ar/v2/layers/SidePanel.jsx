import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, User, Library, Palette, Grid3x3, Settings, LogOut, Palette as PaletteIcon, Layers } from 'lucide-react';
import VoiceSettings from '../controls/VoiceSettings';
import ThreadCollectionSection from '@/components/profile/ThreadCollectionSection';

export default function SidePanel({
  isOpen,
  onClose,
  activeTab,
  user,
  patterns,
  dmcPalette,
  selectedColor,
  onColorSelect,
  selectedSymbol,
  onSymbolSelect,
  onPatternSelect,
  showSymbols,
  onToggleSymbols,
  onLogout,
  userThreads = []
}) {
  const [expandedColor, setExpandedColor] = useState(null);

  const tabs = [
    { id: 'profile', label: 'Profile', icon: User },
    { id: 'patterns', label: 'Patterns', icon: Library },
    { id: 'threads', label: 'Mes Filés', icon: Layers },
    { id: 'colors', label: 'Colors', icon: PaletteIcon },
    { id: 'symbols', label: 'Symbols', icon: Grid3x3 },
    { id: 'settings', label: 'Settings', icon: Settings }
  ];

  const symbols = ['•', '×', '◉', '○', '▪', '□', '+', '✓', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/50 z-30"
          />

          {/* Panel */}
          <motion.div
            initial={{ x: 400, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: 400, opacity: 0 }}
            transition={{ type: 'spring', damping: 20 }}
            className="fixed right-0 top-0 h-screen w-96 bg-black border-l border-gray-700/30 overflow-y-auto z-40"
          >
            {/* Header */}
            <div className="sticky top-0 bg-black/80 backdrop-blur-sm border-b border-gray-700/30 px-6 py-4 flex items-center justify-between">
              <h2 className="text-lg font-light text-white capitalize">{activeTab}</h2>
              <button
                onClick={onClose}
                className="p-1.5 rounded hover:bg-gray-800/50 transition text-gray-400"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content */}
            <div className="p-6 space-y-6">
              {/* PROFILE TAB */}
              {activeTab === 'profile' && (
                <div className="space-y-4">
                  <div className="bg-gray-900/40 rounded-lg p-4 space-y-3 border border-gray-700/30">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-full bg-emerald-500/20 border border-emerald-500/50 flex items-center justify-center">
                        <User className="w-6 h-6 text-emerald-400" />
                      </div>
                      <div>
                        <p className="text-sm font-light text-white">{user?.full_name || 'User'}</p>
                        <p className="text-xs text-gray-500">{user?.email}</p>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <p className="text-xs font-light text-gray-400 uppercase tracking-wider">Statistics</p>
                    <div className="grid grid-cols-2 gap-3">
                      {[
                        { label: 'Patterns', value: patterns?.length || 0 },
                        { label: 'Sessions', value: '12' },
                        { label: 'Stitches', value: '4.2K' },
                        { label: 'Hours', value: '23.5' }
                      ].map((stat, idx) => (
                        <div key={idx} className="bg-gray-900/40 rounded-lg p-3 border border-gray-700/20 text-center">
                          <p className="text-2xl font-light text-white">{stat.value}</p>
                          <p className="text-xs text-gray-500">{stat.label}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  <button
                    onClick={onLogout}
                    className="w-full flex items-center justify-center gap-2 px-4 py-2 rounded-lg bg-red-500/20 border border-red-500/30 text-red-400 hover:bg-red-500/30 transition text-sm"
                  >
                    <LogOut className="w-4 h-4" />
                    Logout
                  </button>
                </div>
              )}

              {/* PATTERNS TAB */}
              {activeTab === 'patterns' && (
                <div className="space-y-3">
                  <p className="text-xs font-light text-gray-400 uppercase tracking-wider">Available Patterns</p>
                  {patterns?.map(pattern => (
                    <button
                      key={pattern.id}
                      onClick={() => onPatternSelect(pattern)}
                      className="w-full text-left bg-gray-900/40 rounded-lg p-3 border border-gray-700/30 hover:border-emerald-500/50 transition space-y-1"
                    >
                      <p className="text-sm font-light text-white">{pattern.title}</p>
                      <p className="text-xs text-gray-500">{pattern.grid_width} × {pattern.grid_height}</p>
                    </button>
                  ))}
                </div>
              )}

              {/* THREADS TAB */}
              {activeTab === 'threads' && (
                <ThreadCollectionSection 
                  userThreads={userThreads}
                  onAddThread={() => {}}
                />
              )}

              {/* THREADS TAB */}
              {activeTab === 'threads' && (
                <ThreadCollectionSection 
                  userThreads={userThreads}
                  onAddThread={() => {}}
                />
              )}

              {/* COLORS TAB */}
              {activeTab === 'colors' && (
                <div className="space-y-3">
                  <p className="text-xs font-light text-gray-400 uppercase tracking-wider">DMC Palette</p>
                  <div className="space-y-2 max-h-96 overflow-y-auto">
                    {dmcPalette?.map(color => (
                      <button
                        key={color.dmc_code}
                        onClick={() => onColorSelect(color)}
                        className={`w-full flex items-center gap-3 p-2.5 rounded-lg border transition ${
                          selectedColor?.dmc_code === color.dmc_code
                            ? 'bg-gray-800/80 border-emerald-500/50'
                            : 'bg-gray-900/40 border-gray-700/30 hover:border-gray-600'
                        }`}
                      >
                        <div
                          className="w-6 h-6 rounded border border-gray-600 flex-shrink-0"
                          style={{ backgroundColor: color.color_hex }}
                        />
                        <div className="flex-1 text-left min-w-0">
                          <p className="text-xs font-light text-white">{color.dmc_code}</p>
                          <p className="text-xs text-gray-500 truncate">{color.name}</p>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* SYMBOLS TAB */}
              {activeTab === 'symbols' && (
                <div className="space-y-4">
                  <button
                    onClick={() => onToggleSymbols(!showSymbols)}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-lg border transition text-sm ${
                      showSymbols
                        ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-300'
                        : 'bg-gray-900/40 border-gray-700/30 text-gray-400 hover:border-gray-600'
                    }`}
                  >
                    {showSymbols ? 'Symbols: On' : 'Symbols: Off'}
                  </button>

                  <p className="text-xs font-light text-gray-400 uppercase tracking-wider">Symbol Set</p>
                  <div className="grid grid-cols-4 gap-2">
                    {symbols.map((symbol, idx) => (
                      <button
                        key={idx}
                        onClick={() => onSymbolSelect(symbol)}
                        className={`w-12 h-12 rounded-lg border transition flex items-center justify-center text-lg font-light ${
                          selectedSymbol === symbol
                            ? 'bg-emerald-500/20 border-emerald-500/50'
                            : 'bg-gray-900/40 border-gray-700/30 hover:border-gray-600'
                        }`}
                      >
                        {symbol}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* SETTINGS TAB */}
              {activeTab === 'settings' && (
                <div className="space-y-6">
                  <div>
                    <p className="text-xs font-light text-gray-400 uppercase tracking-wider mb-3">Voix Guidée</p>
                    <VoiceSettings 
                      onVolumeChange={() => {}}
                      onSpeedChange={() => {}}
                      onVoiceSelect={() => {}}
                      onReplayInstructions={() => {}}
                      onPauseToggle={() => {}}
                      isPaused={false}
                    />
                  </div>

                  <div className="border-t border-gray-700/20 pt-4">
                    <p className="text-xs font-light text-gray-400 uppercase tracking-wider mb-3">Interface</p>
                    <div className="space-y-3">
                      {[
                        { label: 'Grid Opacity', value: 75 },
                        { label: 'Symbol Size', value: 50 },
                        { label: 'Highlight Intensity', value: 100 }
                      ].map((setting, idx) => (
                        <div key={idx} className="space-y-1">
                          <label className="text-xs text-gray-400">{setting.label}</label>
                          <input
                            type="range"
                            min="0"
                            max="100"
                            defaultValue={setting.value}
                            className="w-full h-1 bg-gray-700 rounded-full accent-emerald-500"
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}