import React from 'react';
import { motion } from 'framer-motion';
import { Menu, Palette, Grid3X3, Share2, Settings } from 'lucide-react';
import PatternLiveLogo from '@/components/ar/PatternLiveLogo';

export default function TopBar({
  mode,
  onMenuOpen,
  onColorsOpen,
  onSymbolsOpen,
  onShareOpen,
  onSettingsOpen
}) {
  const modeLabels = {
    focus: 'Focus',
    guide: 'Guide',
    adjust: 'Adjust',
    create: 'Create'
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      className="fixed top-0 left-0 right-0 z-40 bg-black/60 backdrop-blur-xl border-b border-gray-800/50 h-16 safe-top"
    >
      <div className="h-full px-4 flex items-center justify-between">
        {/* Left: Logo */}
        <PatternLiveLogo size="small" />

        {/* Center: Mode label */}
        <div className="text-xs text-gray-500 uppercase tracking-wider">
          {modeLabels[mode]}
        </div>

        {/* Right: Controls */}
        <div className="flex items-center gap-1">
          {mode !== 'adjust' && (
            <>
              <button
                onClick={onColorsOpen}
                className="p-2.5 rounded-lg hover:bg-gray-800/50 text-gray-400 hover:text-white transition"
                title="Colors"
                aria-label="Colors"
              >
                <Palette className="w-4 h-4" />
              </button>
              <button
                onClick={onSymbolsOpen}
                className="p-2.5 rounded-lg hover:bg-gray-800/50 text-gray-400 hover:text-white transition"
                title="Symbols"
                aria-label="Symbols"
              >
                <Grid3X3 className="w-4 h-4" />
              </button>
            </>
          )}
          <button
            onClick={onShareOpen}
            className="p-2.5 rounded-lg hover:bg-gray-800/50 text-gray-400 hover:text-white transition"
            title="Share Live"
            aria-label="Share"
          >
            <Share2 className="w-4 h-4" />
          </button>
          <button
            onClick={onSettingsOpen}
            className="p-2.5 rounded-lg hover:bg-gray-800/50 text-gray-400 hover:text-white transition"
            title="Settings"
            aria-label="Settings"
          >
            <Settings className="w-4 h-4" />
          </button>
          <button
            onClick={onMenuOpen}
            className="p-2.5 rounded-lg hover:bg-gray-800/50 text-gray-400 hover:text-white transition"
            title="Menu"
            aria-label="Menu"
          >
            <Menu className="w-4 h-4" />
          </button>
        </div>
      </div>
    </motion.div>
  );
}