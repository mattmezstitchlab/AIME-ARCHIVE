import React, { useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { ChevronUp, Grid3x3, Volume2, VolumeX, RotateCcw } from 'lucide-react';
import ModeSelector from '../controls/ModeSelector';
import GridControlPanel from '../controls/GridControlPanel';
import VoicePanel from '../controls/VoicePanel';
import AdjustModePanel from '../controls/AdjustModePanel';

const snapHeights = {
  collapsed: 120,
  medium: 350,
  expanded: 700
};

export default function BottomSheet({
  snapPoint,
  onSnapChange,
  mode,
  onModeChange,
  pattern,
  session,
  gridVisible,
  onGridToggle,
  voiceEnabled,
  onVoiceToggle,
  nextStitch,
  onSessionEnd,
  gridCalibration
}) {
  const sheetRef = useRef(null);
  const [dragStart, setDragStart] = useState(0);

  const handleDragStart = (e) => {
    setDragStart(e.clientY || e.touches?.[0].clientY);
  };

  const handleDragEnd = (e) => {
    const dragEnd = e.clientY || e.changedTouches?.[0].clientY;
    const delta = dragEnd - dragStart;

    if (Math.abs(delta) > 50) {
      if (delta > 0) {
        // Dragged down
        if (snapPoint === 'expanded') onSnapChange('medium');
        else if (snapPoint === 'medium') onSnapChange('collapsed');
      } else {
        // Dragged up
        if (snapPoint === 'collapsed') onSnapChange('medium');
        else if (snapPoint === 'medium') onSnapChange('expanded');
      }
    }
  };

  const currentHeight = snapHeights[snapPoint];

  return (
    <motion.div
      ref={sheetRef}
      drag="y"
      dragElastic={0.1}
      dragConstraints={{ top: 0, bottom: 0 }}
      onDragStart={handleDragStart}
      onDragEnd={handleDragEnd}
      animate={{ height: currentHeight, y: 0 }}
      transition={{ type: 'spring', stiffness: 200, damping: 30 }}
      className="bg-gradient-to-t from-gray-950 via-gray-900/90 to-gray-800/80 backdrop-blur-2xl border-t border-gray-800/50 rounded-t-3xl shadow-2xl"
    >
      {/* Drag handle */}
      <div className="flex justify-center pt-3 pb-4 cursor-grab active:cursor-grabbing">
        <div className="w-12 h-1 rounded-full bg-gray-700/40" />
      </div>

      {/* Collapsed view */}
      {snapPoint === 'collapsed' && (
        <div className="px-6 space-y-3">
          <ModeSelector value={mode} onChange={onModeChange} />
          <div className="flex items-center gap-2 text-xs text-gray-400">
            <ChevronUp className="w-3 h-3" />
            Slide up for controls
          </div>
        </div>
      )}

      {/* Medium view */}
      {snapPoint === 'medium' && (
        <div className="px-6 space-y-6 overflow-y-auto max-h-[calc(100%-60px)]">
          <ModeSelector value={mode} onChange={onModeChange} />

          {mode === 'adjust' && (
            <AdjustModePanel
              gridState={gridCalibration.gridState}
              onUpdatePosition={gridCalibration.updateGridPosition}
              onUpdateScale={gridCalibration.updateGridScale}
              onUpdateRotation={gridCalibration.updateGridRotation}
              onLock={gridCalibration.lockGrid}
              onUnlock={gridCalibration.unlockGrid}
              onReset={gridCalibration.resetGrid}
              onUndo={gridCalibration.undo}
              canUndo={gridCalibration.canUndo}
              onDoneClick={() => {
                gridCalibration.lockGrid();
                onModeChange('guide');
              }}
              onBackClick={() => onModeChange('focus')}
            />
          )}

          {mode === 'guide' && voiceEnabled && (
            <VoicePanel
              nextStitch={nextStitch}
              onVoiceToggle={onVoiceToggle}
            />
          )}

          {mode !== 'adjust' && (
            <div className="flex gap-2 pb-4">
              <button
                onClick={() => onVoiceToggle(!voiceEnabled)}
                className="flex-1 flex items-center justify-center gap-2 px-4 py-2 rounded-lg bg-gray-800/50 hover:bg-gray-800 border border-gray-700 text-gray-300 hover:text-white transition text-sm font-light"
              >
                {voiceEnabled ? (
                  <Volume2 className="w-4 h-4" />
                ) : (
                  <VolumeX className="w-4 h-4" />
                )}
                Voice {voiceEnabled ? 'On' : 'Off'}
              </button>
              <button
                onClick={() => onSessionEnd()}
                className="flex-1 px-4 py-2 rounded-lg bg-red-500/20 hover:bg-red-500/30 border border-red-500/30 text-red-400 transition text-sm font-light"
              >
                End Session
              </button>
            </div>
          )}
        </div>
      )}

      {/* Expanded view */}
      {snapPoint === 'expanded' && (
        <div className="px-6 space-y-6 overflow-y-auto max-h-[calc(100%-60px)]">
          <ModeSelector value={mode} onChange={onModeChange} />

          {mode === 'adjust' && (
            <AdjustModePanel
              gridState={gridCalibration.gridState}
              onUpdatePosition={gridCalibration.updateGridPosition}
              onUpdateScale={gridCalibration.updateGridScale}
              onUpdateRotation={gridCalibration.updateGridRotation}
              onLock={gridCalibration.lockGrid}
              onUnlock={gridCalibration.unlockGrid}
              onReset={gridCalibration.resetGrid}
              onUndo={gridCalibration.undo}
              canUndo={gridCalibration.canUndo}
              onDoneClick={() => {
                gridCalibration.lockGrid();
                onModeChange('guide');
              }}
              onBackClick={() => onModeChange('focus')}
            />
          )}

          {mode === 'guide' && (
            <>
              <VoicePanel
                nextStitch={nextStitch}
                detailed
                onVoiceToggle={onVoiceToggle}
              />
              <SessionStats session={session} pattern={pattern} />
            </>
          )}

          <div className="grid grid-cols-2 gap-2 pb-4">
            <button
              onClick={() => onVoiceToggle(!voiceEnabled)}
              className="flex items-center justify-center gap-2 px-4 py-3 rounded-lg bg-gray-800/50 hover:bg-gray-800 border border-gray-700 text-gray-300 hover:text-white transition text-sm"
            >
              {voiceEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
              Voice
            </button>
            <button
              onClick={() => onSessionEnd()}
              className="px-4 py-3 rounded-lg bg-red-500/20 hover:bg-red-500/30 border border-red-500/30 text-red-400 transition text-sm font-light"
            >
              End Session
            </button>
          </div>
        </div>
      )}
    </motion.div>
  );
}

function SessionStats({ session, pattern }) {
  return (
    <div className="space-y-2 text-xs text-gray-400">
      <div className="flex justify-between">
        <span>Duration</span>
        <span className="text-white">{session?.session_duration_minutes || 0} min</span>
      </div>
      <div className="flex justify-between">
        <span>Pace</span>
        <span className="text-white">{session?.stitches_per_minute?.toFixed(1) || '—'} stitches/min</span>
      </div>
    </div>
  );
}