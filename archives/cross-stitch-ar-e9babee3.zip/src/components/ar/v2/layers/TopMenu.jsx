import React from 'react';
import { motion } from 'framer-motion';
import { Palette, Grid3x3, Share2, HelpCircle, Settings } from 'lucide-react';
import StudioMenu from './StudioMenu';

export default function TopMenu({ 
  onPanelOpen,
  patterns = [],
  sessions = [],
  onCreatePattern = () => {},
  onPatternSelect = () => {},
  onSessionSelect = () => {},
  onBackToStudio = () => {}
}) {
  const menuItems = [
    { id: 'colors', icon: Palette, label: 'Colors', color: 'text-emerald-400' },
    { id: 'symbols', icon: Grid3x3, label: 'Symbols', color: 'text-blue-400' },
    { id: 'share', icon: Share2, label: 'Share', color: 'text-pink-400' },
    { id: 'settings', icon: Settings, label: 'Settings', color: 'text-gray-400' },
    { id: 'help', icon: HelpCircle, label: 'Help', color: 'text-yellow-400' }
  ];

  return (
    <motion.div
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="fixed top-0 left-0 right-0 z-30 bg-gradient-to-b from-black/80 to-black/40 backdrop-blur-md border-b border-gray-700/30 px-6 py-4"
    >
      <div className="flex items-center justify-between max-w-7xl mx-auto">
        {/* Logo */}
        <div className="flex items-center gap-2">
          <Grid3x3 className="w-5 h-5 text-emerald-400" />
          <span className="text-sm font-light text-white tracking-wide">SmartStitch</span>
        </div>

        {/* Menu Items */}
         <div className="flex items-center gap-2 bg-gray-900/40 border border-gray-700/30 rounded-lg p-1">
           <StudioMenu
             patterns={patterns}
             sessions={sessions}
             onCreatePattern={onCreatePattern}
             onPatternSelect={onPatternSelect}
             onSessionSelect={onSessionSelect}
             onBackToStudio={onBackToStudio}
           />

           {menuItems.map(item => {
             const IconComponent = item.icon;
             return (
               <button
                 key={item.id}
                 onClick={() => onPanelOpen(item.id)}
                 className="flex items-center gap-1.5 px-2.5 py-1.5 rounded hover:bg-gray-800/50 transition text-xs text-gray-300 hover:text-white group"
                 title={item.label}
               >
                 <IconComponent className={`w-4 h-4 ${item.color}`} />
                 <span className="hidden sm:inline font-light">{item.label}</span>
               </button>
             );
           })}
         </div>

        {/* Right spacer */}
        <div className="w-32" />
      </div>
    </motion.div>
  );
}