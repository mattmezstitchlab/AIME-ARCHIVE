import React from 'react';
import { motion } from 'framer-motion';
import { Library, ZoomIn, ZoomOut, Undo2, Redo2, Eye, EyeOff, Grid3x3 } from 'lucide-react';

export default function TopToolbar({
  zoom,
  onZoomIn,
  onZoomOut,
  onResetZoom,
  canUndo,
  canRedo,
  onUndo,
  onRedo,
  gridVisible,
  onGridToggle,
  onOpenLibrary
}) {
  return (
    <motion.div
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="fixed top-0 left-0 right-0 z-30 bg-gradient-to-b from-black/80 to-black/40 backdrop-blur-md border-b border-gray-700/30 px-6 py-3"
    >
      <div className="flex items-center justify-between max-w-7xl mx-auto">
        {/* Left: Branding */}
        <div className="flex items-center gap-3">
          <Grid3x3 className="w-5 h-5 text-emerald-400" />
          <span className="text-sm font-light text-white tracking-wide">SmartStitch Studio</span>
        </div>

        {/* Center: Tools */}
        <div className="flex items-center gap-1 bg-gray-900/40 border border-gray-700/30 rounded-lg p-1">
          {/* Library */}
          <button
            onClick={onOpenLibrary}
            className="flex items-center gap-2 px-3 py-1.5 rounded hover:bg-gray-800/50 transition text-xs text-gray-300 hover:text-white"
            title="Pattern Library"
          >
            <Library className="w-4 h-4" />
            Library
          </button>

          <div className="w-px h-5 bg-gray-700/30 mx-1" />

          {/* Zoom Tools */}
          <button
            onClick={onZoomOut}
            className="p-1.5 rounded hover:bg-gray-800/50 transition text-gray-400 hover:text-white"
            title="Zoom Out"
          >
            <ZoomOut className="w-4 h-4" />
          </button>

          <div className="text-xs text-gray-400 px-2 min-w-12 text-center font-light">
            {Math.round(zoom * 100)}%
          </div>

          <button
            onClick={onZoomIn}
            className="p-1.5 rounded hover:bg-gray-800/50 transition text-gray-400 hover:text-white"
            title="Zoom In"
          >
            <ZoomIn className="w-4 h-4" />
          </button>

          <button
            onClick={onResetZoom}
            className="px-2 py-1 rounded text-xs font-light text-gray-400 hover:text-white hover:bg-gray-800/50 transition"
            title="Reset Zoom"
          >
            1:1
          </button>

          <div className="w-px h-5 bg-gray-700/30 mx-1" />

          {/* History */}
          <button
            onClick={onUndo}
            disabled={!canUndo}
            className="p-1.5 rounded hover:bg-gray-800/50 transition text-gray-400 hover:text-white disabled:opacity-40 disabled:cursor-not-allowed"
            title="Undo"
          >
            <Undo2 className="w-4 h-4" />
          </button>

          <button
            onClick={onRedo}
            disabled={!canRedo}
            className="p-1.5 rounded hover:bg-gray-800/50 transition text-gray-400 hover:text-white disabled:opacity-40 disabled:cursor-not-allowed"
            title="Redo"
          >
            <Redo2 className="w-4 h-4" />
          </button>

          <div className="w-px h-5 bg-gray-700/30 mx-1" />

          {/* Grid Toggle */}
          <button
            onClick={() => onGridToggle(!gridVisible)}
            className={`p-1.5 rounded transition ${
              gridVisible
                ? 'bg-emerald-500/20 text-emerald-400'
                : 'text-gray-400 hover:text-white hover:bg-gray-800/50'
            }`}
            title="Toggle Grid"
          >
            {gridVisible ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
          </button>
        </div>

        {/* Right: Empty for balance */}
        <div className="w-32" />
      </div>
    </motion.div>
  );
}