import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { useGridCalibration } from './hooks/useGridCalibration';
import { useCalibration } from '../hooks/useCalibration';
import ARCanvas from './layers/ARCanvas';
import TopHUD from './layers/TopHUD';
import TopBar from './layers/TopBar';
import BottomModeSwitch from './layers/BottomModeSwitch';
import SidePanel from './layers/SidePanel';
import AdjustModePanel from './controls/AdjustModePanel';
import CalibrationOverlay from '../calibration/CalibrationOverlay';
import ARInitializer from '../ARInitializer';
import ARFallbackView from '../ARFallbackView';

export default function ARViewerLayout({ 
  pattern, 
  session,
  mode = 'focus',
  onModeChange,
  onChangePattern,
  onSessionUpdate,
  previewPatternId = null
}) {
  const [activeSidePanel, setActiveSidePanel] = useState(null);
  const [nextStitch, setNextStitch] = useState(null);
  const [selectedColor, setSelectedColor] = useState(pattern?.dmc_palette?.[0]);
  const [selectedSymbol, setSelectedSymbol] = useState('•');
  const [showSymbols, setShowSymbols] = useState(true);
  const [user, setUser] = useState(null);
  const [showCalibration, setShowCalibration] = useState(false);
  const [arState, setArState] = useState('initializing'); // initializing | ready | fallback
  const [capturedImage, setCapturedImage] = useState(null);
  const [calibrationData, setCalibrationData] = useState(null);

  const gridCalibration = useGridCalibration(pattern);
  const calibration = useCalibration(pattern?.grid_width || 32, pattern?.grid_height || 32);

  // Load user
  React.useEffect(() => {
    const loadUser = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);
      } catch (error) {
        console.error('Failed to load user:', error);
      }
    };
    loadUser();
  }, []);

  const handleModeChange = (newMode) => {
    onModeChange(newMode);
  };

  // Auto-enter calibration after pattern is selected
  React.useEffect(() => {
    if (mode === 'focus' && !session?.calibration_corners && !calibration.isLocked) {
      setShowCalibration(true);
    }
  }, [session, calibration.isLocked, mode]);

  // Handle AR initialization after calibration
  React.useEffect(() => {
    if (arState === 'ready') {
      console.log('[AR_VIEWER] AR ready, setting up canvas');
    }
  }, [arState]);

  const handleCalibrationDone = () => {
    // Save calibration to session
    if (calibration.transform && session) {
      base44.entities.ARSession.update(session.id, {
        calibration_corners: calibration.points
      });
    }
    setShowCalibration(false);
  };

  // Fallback mode
  if (arState === 'fallback') {
    return (
      <ARFallbackView
        capturedImage={capturedImage}
        pattern={pattern}
        calibrationPoints={calibrationData?.calibration}
        onRetryAR={() => setArState('initializing')}
        onChangePattern={onChangePattern}
      />
    );
  }

  // AR initialization
  if (arState === 'initializing') {
    return (
      <ARInitializer
        onSuccess={() => {
          console.log('[AR_VIEWER] AR initialization success');
          setArState('ready');
        }}
        onFallback={(err) => {
          console.warn('[AR_VIEWER] AR initialization fallback:', err.message);
          setArState('fallback');
        }}
        onError={(err) => {
          console.error('[AR_VIEWER] AR initialization error:', err);
          setArState('fallback');
        }}
      />
    );
  }

  return (
          <div className="fixed inset-0 bg-black overflow-hidden" style={{ width: '100vw', height: '100vh' }}>
            {/* LAYER A: AR CANVAS (always visible, center) */}
            <div className="absolute inset-0 top-16 bottom-20 z-0" style={{ overflow: 'hidden' }}>
            <ARCanvas 
              pattern={pattern}
              session={session}
              gridVisible={true}
              highlightNextStitch={mode === 'guide'}
              gridState={gridCalibration.gridState}
              showAdjustHandles={mode === 'adjust'}
              onStitchTap={setNextStitch}
            />
          </div>

      {/* LAYER B: FIXED TOP BAR */}
      <TopBar
        mode={mode}
        onMenuOpen={() => setActiveSidePanel('menu')}
        onColorsOpen={() => setActiveSidePanel('colors')}
        onSymbolsOpen={() => setActiveSidePanel('symbols')}
        onShareOpen={() => setActiveSidePanel('share')}
        onSettingsOpen={() => setActiveSidePanel('settings')}
      />

      {/* LAYER C: TOP HUD (MINIMAL - only in focus/guide/create) */}
      {mode !== 'adjust' && (
        <div className="absolute top-16 left-0 right-0 z-20 pointer-events-none">
          <TopHUD 
            mode={mode}
            progress={session?.progress_percentage || 0}
            stitchesLeft={session ? session.total_stitches - session.points_completed.length : 0}
          />
        </div>
      )}

      {/* LAYER D: ADJUST MODE PANEL (left side when adjust mode) */}
      <AnimatePresence>
        {mode === 'adjust' && (
          <motion.div
            initial={{ x: -400, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: -400, opacity: 0 }}
            className="fixed left-0 top-16 h-[calc(100vh-128px)] w-80 bg-black/80 backdrop-blur-xl border-r border-gray-700/30 overflow-y-auto z-30 p-4"
          >
            <AdjustModePanel
              gridState={gridCalibration.gridState}
              onUpdatePosition={gridCalibration.updateGridPosition}
              onUpdateScale={gridCalibration.updateGridScale}
              onUpdateRotation={gridCalibration.updateGridRotation}
              onLock={gridCalibration.lockGrid}
              onUnlock={gridCalibration.unlockGrid}
              onReset={gridCalibration.resetGrid}
              onUndo={gridCalibration.undo}
              canUndo={gridCalibration.canUndo}
              onDoneClick={() => {
                gridCalibration.lockGrid();
                handleModeChange('focus');
              }}
              onBackClick={() => handleModeChange('focus')}
            />
          </motion.div>
        )}
      </AnimatePresence>

      {/* LAYER E: BOTTOM MODE SWITCH */}
      <BottomModeSwitch
        currentMode={mode}
        onModeChange={handleModeChange}
        progress={session?.progress_percentage || 0}
        totalStitches={session?.total_stitches || 0}
      />

      {/* LAYER F: SIDE PANELS (slide over) */}
      <SidePanel
        isOpen={activeSidePanel !== null}
        onClose={() => setActiveSidePanel(null)}
        activeTab={activeSidePanel || 'profile'}
        user={user}
        patterns={[]}
        dmcPalette={pattern?.dmc_palette}
        selectedColor={selectedColor}
        onColorSelect={setSelectedColor}
        selectedSymbol={selectedSymbol}
        onSymbolSelect={setSelectedSymbol}
        onPatternSelect={() => {
          setActiveSidePanel(null);
          onChangePattern();
        }}
        showSymbols={showSymbols}
        onToggleSymbols={setShowSymbols}
        onLogout={() => base44.auth.logout()}
      />

      {/* Calibration overlay */}
      <CalibrationOverlay
        isActive={showCalibration}
        mode={calibration.calibrationMode}
        points={calibration.points}
        progress={calibration.progress}
        isLocked={calibration.isLocked}
        onAddPoint={calibration.addPoint}
        onReset={calibration.resetPoints}
        onLock={calibration.lockCalibration}
        onSwitchMode={calibration.switchMode}
        onDone={handleCalibrationDone}
      />
    </div>
  );
}