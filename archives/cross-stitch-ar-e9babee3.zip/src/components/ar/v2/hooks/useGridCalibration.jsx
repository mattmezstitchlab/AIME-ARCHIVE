import { useState, useCallback } from 'react';

export const useGridCalibration = (pattern) => {
  const [gridState, setGridState] = useState({
    // Position
    offsetX: 50,
    offsetY: 150,
    // Scale
    cellSize: 40,
    // Rotation
    rotation: 0,
    // Perspective (4-corner points relative to canvas)
    perspective: {
      topLeft: { x: 0, y: 0 },
      topRight: { x: pattern?.grid_width * 40, y: 0 },
      bottomLeft: { x: 0, y: pattern?.grid_height * 40 },
      bottomRight: { x: pattern?.grid_width * 40, y: pattern?.grid_height * 40 }
    },
    // Lock state
    isLocked: false,
    // History for undo
    history: []
  });

  const updateGridPosition = useCallback((deltaX, deltaY) => {
    if (gridState.isLocked) return;
    setGridState(prev => {
      const newState = {
        ...prev,
        offsetX: prev.offsetX + deltaX,
        offsetY: prev.offsetY + deltaY
      };
      return {
        ...newState,
        history: [...prev.history, prev]
      };
    });
  }, [gridState.isLocked]);

  const updateGridScale = useCallback((scale) => {
    if (gridState.isLocked) return;
    setGridState(prev => {
      const newState = {
        ...prev,
        cellSize: Math.max(20, Math.min(80, scale))
      };
      return {
        ...newState,
        history: [...prev.history, prev]
      };
    });
  }, [gridState.isLocked]);

  const updateGridRotation = useCallback((angle) => {
    if (gridState.isLocked) return;
    setGridState(prev => {
      const newState = {
        ...prev,
        rotation: ((angle % 360) + 360) % 360
      };
      return {
        ...newState,
        history: [...prev.history, prev]
      };
    });
  }, [gridState.isLocked]);

  const updatePerspectiveCorner = useCallback((corner, x, y) => {
    if (gridState.isLocked) return;
    setGridState(prev => {
      const newState = {
        ...prev,
        perspective: {
          ...prev.perspective,
          [corner]: { x, y }
        }
      };
      return {
        ...newState,
        history: [...prev.history, prev]
      };
    });
  }, [gridState.isLocked]);

  const lockGrid = useCallback(() => {
    setGridState(prev => ({
      ...prev,
      isLocked: true
    }));
  }, []);

  const unlockGrid = useCallback(() => {
    setGridState(prev => ({
      ...prev,
      isLocked: false
    }));
  }, []);

  const resetGrid = useCallback(() => {
    setGridState({
      offsetX: 50,
      offsetY: 150,
      cellSize: 40,
      rotation: 0,
      perspective: {
        topLeft: { x: 0, y: 0 },
        topRight: { x: pattern?.grid_width * 40, y: 0 },
        bottomLeft: { x: 0, y: pattern?.grid_height * 40 },
        bottomRight: { x: pattern?.grid_width * 40, y: pattern?.grid_height * 40 }
      },
      isLocked: false,
      history: []
    });
  }, [pattern]);

  const undo = useCallback(() => {
    if (gridState.history.length === 0) return;
    setGridState(prev => {
      const newHistory = [...prev.history];
      const previousState = newHistory.pop();
      return {
        ...previousState,
        history: newHistory
      };
    });
  }, []);

  return {
    gridState,
    updateGridPosition,
    updateGridScale,
    updateGridRotation,
    updatePerspectiveCorner,
    lockGrid,
    unlockGrid,
    resetGrid,
    undo,
    canUndo: gridState.history.length > 0
  };
};