import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';

export default function ARInitializer({
  onSuccess,
  onFallback,
  onError
}) {
  const [status, setStatus] = useState('initializing');

  useEffect(() => {
    const initAR = async () => {
      try {
        // Timeout: 4 seconds max
        const promise = new Promise((resolve, reject) => {
          // Check WebXR availability
          if (!navigator.xr) {
            console.error('[AR_INIT] WebXR not available');
            return reject(new Error('WebXR not available'));
          }

          // Try to detect XR session
          navigator.xr
            .isSessionSupported('immersive-ar')
            .then((supported) => {
              console.log('[AR_INIT] WebXR supported:', supported);
              if (supported) {
                resolve({ supported: true });
              } else {
                reject(new Error('Immersive AR not supported'));
              }
            })
            .catch((err) => {
              console.error('[AR_INIT] WebXR check failed:', err);
              reject(err);
            });
        });

        // Race with timeout
        const result = await Promise.race([
          promise,
          new Promise((_, reject) =>
            setTimeout(
              () => reject(new Error('AR init timeout (4s)')),
              4000
            )
          )
        ]);

        console.log('[AR_INIT] Success:', result);
        setStatus('ready');
        onSuccess(result);
      } catch (err) {
        console.error('[AR_INIT] Error:', err.message);
        setStatus('fallback');
        onFallback(err);
      }
    };

    initAR();
  }, [onSuccess, onFallback, onError]);

  return (
    <div className="fixed inset-0 bg-black flex items-center justify-center z-50">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="text-center space-y-4"
      >
        <motion.div
          animate={{ scale: [1, 1.08, 1] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="w-12 h-12 rounded-full border-2 border-emerald-400 border-t-transparent mx-auto"
        />
        <p className="text-white text-sm">
          {status === 'initializing' && 'Initialisation AR…'}
          {status === 'ready' && 'AR prêt'}
          {status === 'fallback' && 'Mode aperçu'}
        </p>
      </motion.div>
    </div>
  );
}