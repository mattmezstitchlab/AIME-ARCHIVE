// voiceEngine.js - Professional French voice synthesis with anti-robot features

// Guard against SSR and unavailable APIs
const canSpeak = () => typeof window !== 'undefined' && window.speechSynthesis;

let enabled = true;
let selectedVoiceName = null;
let lastSpokenAtByKey = new Map();
let currentQueue = [];
let speaking = false;

export function setVoiceEnabled(v) {
  enabled = v;
  stop();
}

export function setSelectedVoiceName(name) {
  selectedVoiceName = name;
}

export function stop() {
  if (!canSpeak()) return;
  try {
    window.speechSynthesis.cancel();
  } catch {}
  currentQueue = [];
  speaking = false;
}

function pickVoice() {
  if (!canSpeak()) return null;
  
  try {
    const voices = window.speechSynthesis.getVoices() || [];
    
    // Prefer user-selected voice
    if (selectedVoiceName) {
      const exact = voices.find(v => v.name === selectedVoiceName);
      if (exact) return exact;
    }
    
    // Prefer fr-FR natural voices
    const fr = voices.filter(v => (v.lang || "").toLowerCase().startsWith("fr"));
    const preferred =
      fr.find(v => /am[eé]lie|audrey|thomas|marie|julie/i.test(v.name)) ||
      fr[0] ||
      voices[0] ||
      null;
    
    return preferred;
  } catch {
    return null;
  }
}

function chunkText(text) {
  // Keep it short + breathable
  // Split on strong punctuation first
  const raw = text
    .replace(/\s+/g, " ")
    .trim()
    .split(/(?<=[.!?…])\s+/);

  // Further split long chunks
  const out = [];
  for (const part of raw) {
    if (part.length <= 90) {
      out.push(part);
    } else {
      // split by comma / semicolon
      const sub = part.split(/,\s+|;\s+/);
      for (const s of sub) {
        out.push(s.trim());
      }
    }
  }
  return out.filter(Boolean);
}

export async function speakKey(key, text, opts = {}) {
  if (!canSpeak()) return;
  if (!enabled) return;
  if (!text) return;

  try {
    // Anti-repeat (default 25s)
    const now = Date.now();
    const cooldownMs = opts.cooldownMs ?? 25000;
    const last = lastSpokenAtByKey.get(key) || 0;
    if (now - last < cooldownMs) return;
    lastSpokenAtByKey.set(key, now);

    // If user is actively interacting, you can choose to skip
    if (opts.skipIfBusy && opts.isBusy?.()) return;

    stop(); // interrupt previous speech immediately (feels "smart")

    const pieces = chunkText(text);
    currentQueue = pieces;
    speaking = true;

    const voice = pickVoice();

  const speakOne = (t) =>
    new Promise((resolve) => {
      const u = new SpeechSynthesisUtterance(t);
      u.lang = "fr-FR";
      u.rate = opts.rate ?? 0.88;
      u.pitch = opts.pitch ?? 0.95;
      u.volume = opts.volume ?? 0.9;
      if (voice) u.voice = voice;

      u.onend = () => resolve();
      u.onerror = () => resolve();

      // iOS sometimes needs a tiny delay after cancel()
      setTimeout(() => {
        try {
          window.speechSynthesis.speak(u);
        } catch {
          resolve();
        }
      }, opts.delayBeforeSpeakMs ?? 120);
    });

    for (let i = 0; i < currentQueue.length; i++) {
      if (!speaking) break;
      await speakOne(currentQueue[i]);
      // micro pause between chunks (breathing)
      await new Promise((r) =>
        setTimeout(r, opts.pauseBetweenChunksMs ?? 220)
      );
    }

    speaking = false;
  } catch (error) {
    console.error('voiceEngine error:', error);
    speaking = false;
  }
}