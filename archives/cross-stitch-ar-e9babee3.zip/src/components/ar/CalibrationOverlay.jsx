import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Target, Check, RotateCcw } from 'lucide-react';
import { Button } from "@/components/ui/button";

const CORNER_LABELS = [
  'Haut-Gauche',
  'Haut-Droite',
  'Bas-Droite',
  'Bas-Gauche'
];

export default function CalibrationOverlay({
  isActive,
  corners = [],
  currentCorner = 0,
  onCornerPlace,
  onReset,
  onComplete
}) {
  if (!isActive) return null;

  const handleCanvasClick = (e) => {
    if (currentCorner >= 4) return;
    
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    onCornerPlace?.({ x, y });
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="absolute inset-0 z-40"
      onClick={handleCanvasClick}
    >
      {/* Semi-transparent overlay */}
      <div className="absolute inset-0 bg-black/40" />

      {/* Instructions */}
      <motion.div
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="absolute top-20 left-4 right-4 z-50"
      >
        <div className="bg-gray-900/95 backdrop-blur-lg rounded-2xl p-4 border border-amber-500/50">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-full bg-amber-500/20 flex items-center justify-center">
              <Target className="w-5 h-5 text-amber-400" />
            </div>
            <div>
              <h3 className="text-white font-semibold">Calibration de la toile</h3>
              <p className="text-gray-400 text-sm">
                {currentCorner < 4 
                  ? `Touchez le coin ${CORNER_LABELS[currentCorner]} (${currentCorner + 1}/4)`
                  : 'Calibration terminée !'}
              </p>
            </div>
          </div>

          {/* Progress dots */}
          <div className="flex items-center justify-center gap-2">
            {[0, 1, 2, 3].map(i => (
              <div
                key={i}
                className={`w-3 h-3 rounded-full transition-all ${
                  i < currentCorner 
                    ? 'bg-emerald-500' 
                    : i === currentCorner 
                      ? 'bg-amber-500 animate-pulse' 
                      : 'bg-gray-600'
                }`}
              />
            ))}
          </div>
        </div>
      </motion.div>

      {/* Placed corners */}
      <AnimatePresence>
        {corners.map((corner, idx) => (
          <motion.div
            key={idx}
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            exit={{ scale: 0 }}
            style={{
              position: 'absolute',
              left: corner.x - 15,
              top: corner.y - 15,
            }}
            className="z-50"
          >
            <div className="w-8 h-8 rounded-full bg-emerald-500 border-2 border-white flex items-center justify-center shadow-lg">
              <span className="text-white text-sm font-bold">{idx + 1}</span>
            </div>
          </motion.div>
        ))}
      </AnimatePresence>

      {/* Connect corners with lines */}
      {corners.length >= 2 && (
        <svg className="absolute inset-0 z-45 pointer-events-none">
          <defs>
            <linearGradient id="lineGradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#10B981" />
              <stop offset="100%" stopColor="#F59E0B" />
            </linearGradient>
          </defs>
          {corners.slice(0, -1).map((corner, idx) => (
            <motion.line
              key={idx}
              initial={{ pathLength: 0 }}
              animate={{ pathLength: 1 }}
              x1={corner.x}
              y1={corner.y}
              x2={corners[idx + 1].x}
              y2={corners[idx + 1].y}
              stroke="url(#lineGradient)"
              strokeWidth="2"
              strokeDasharray="5,5"
            />
          ))}
          {corners.length === 4 && (
            <motion.line
              initial={{ pathLength: 0 }}
              animate={{ pathLength: 1 }}
              x1={corners[3].x}
              y1={corners[3].y}
              x2={corners[0].x}
              y2={corners[0].y}
              stroke="url(#lineGradient)"
              strokeWidth="2"
              strokeDasharray="5,5"
            />
          )}
        </svg>
      )}

      {/* Action buttons */}
      <motion.div
        initial={{ y: 50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="absolute bottom-32 left-4 right-4 z-50 flex justify-center gap-3"
      >
        <Button
          variant="outline"
          onClick={onReset}
          className="bg-gray-900/80 border-gray-700 text-white"
        >
          <RotateCcw className="w-4 h-4 mr-2" />
          Recommencer
        </Button>

        {currentCorner >= 4 && (
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
          >
            <Button
              onClick={onComplete}
              className="bg-emerald-500 hover:bg-emerald-600 text-white"
            >
              <Check className="w-4 h-4 mr-2" />
              Valider
            </Button>
          </motion.div>
        )}
      </motion.div>

      {/* Corner position hint */}
      {currentCorner < 4 && (
        <motion.div
          key={currentCorner}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="absolute z-45 pointer-events-none"
          style={{
            left: currentCorner === 0 || currentCorner === 3 ? '15%' : '85%',
            top: currentCorner < 2 ? '30%' : '70%',
            transform: 'translate(-50%, -50%)'
          }}
        >
          <motion.div
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ duration: 1.5, repeat: Infinity }}
            className="w-16 h-16 rounded-full border-4 border-dashed border-amber-400/50 flex items-center justify-center"
          >
            <Target className="w-8 h-8 text-amber-400/70" />
          </motion.div>
        </motion.div>
      )}
    </motion.div>
  );
}