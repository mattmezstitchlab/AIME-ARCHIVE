// voice.fr.js - Professional French voice scripts

export const VOICE_FR = {
  // Scan phase
  scan_intro: "Place le motif dans le cadre… doucement.",
  scan_hold: "Oui. Je le vois. Ne bouge plus.",
  
  // Detection phase
  scan_ok_grid: "Grille nette. Parfait.",
  scan_ok_symbols: "Les symboles sont lisibles.",
  scan_ok_colors: "Couleurs repérées.",
  
  // Calibration phase
  align_intro: "On aligne la grille.",
  align_2pts: "Deux coins opposés… c'est tout.",
  align_ok: "Voilà. C'est en place.",
  
  // Entry to embroidery
  enter_focus: "Tu peux commencer.",
  
  // Reassurance
  reassure: "Prends ton temps. Je suis là.",
  
  // Errors
  scan_failed_soft: "Je n'ai pas tout reconnu. Essayons encore.",
  camera_permission_needed: "J'ai besoin de l'accès à la caméra."
};