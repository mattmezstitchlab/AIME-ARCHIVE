import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronUp, ChevronDown } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const SNAP_POINTS = [0.3, 0.6, 1];

export default function BottomSheet({
  children,
  isOpen = true,
  snapPoint = 0.6
}) {
  const [localSnapPoint, setLocalSnapPoint] = useState(snapPoint);
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState(0);

  const handleDragStart = (e) => {
    setIsDragging(true);
    setDragStart(e.clientY || e.touches?.[0]?.clientY);
  };

  const handleDragEnd = () => {
    setIsDragging(false);
  };

  const handleDragMove = (e) => {
    if (!isDragging) return;
    const currentY = e.clientY || e.touches?.[0]?.clientY;
    const delta = dragStart - currentY;
    
    // Find nearest snap point
    const screenHeight = window.innerHeight;
    let newSnapPoint = localSnapPoint + (delta / screenHeight) * 0.5;
    newSnapPoint = Math.max(SNAP_POINTS[0], Math.min(SNAP_POINTS[2], newSnapPoint));
    
    const nearest = SNAP_POINTS.reduce((prev, curr) =>
      Math.abs(curr - newSnapPoint) < Math.abs(prev - newSnapPoint) ? curr : prev
    );
    setLocalSnapPoint(nearest);
  };

  if (!isOpen) return null;

  const heightPercent = localSnapPoint * 100;

  return (
    <motion.div
      initial={{ y: '100%' }}
      animate={{ y: 0 }}
      exit={{ y: '100%' }}
      onMouseMove={handleDragMove}
      onMouseUp={handleDragEnd}
      onTouchMove={handleDragMove}
      onTouchEnd={handleDragEnd}
      className="fixed bottom-0 left-0 right-0 z-30 bg-gradient-to-t from-gray-900 to-gray-900 rounded-t-3xl border-t border-gray-800 pb-safe"
      style={{ height: `${heightPercent}vh` }}
    >
      {/* Drag handle */}
      <motion.div
        onMouseDown={handleDragStart}
        onTouchStart={handleDragStart}
        className="flex items-center justify-center h-5 cursor-grab active:cursor-grabbing bg-gray-800/50 rounded-t-3xl"
      >
        <div className="w-10 h-1 rounded-full bg-gray-700" />
      </motion.div>

      {/* Content */}
      <div className="overflow-y-auto h-full px-4 py-4 max-w-2xl mx-auto">
        {children}
      </div>
    </motion.div>
  );
}