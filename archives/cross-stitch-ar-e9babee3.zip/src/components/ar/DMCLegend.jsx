import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronUp, ChevronDown, Filter, X } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

export default function DMCLegend({ 
  palette = [], 
  gridData = {},
  completedPoints = [],
  activeColor,
  onColorSelect,
  onClearFilter
}) {
  const [isExpanded, setIsExpanded] = useState(false);

  // Calculate counts per color
  const colorCounts = palette.map(p => {
    const total = Object.values(gridData).filter(c => c.dmc === p.dmc_code).length;
    const completed = completedPoints.filter(key => gridData[key]?.dmc === p.dmc_code).length;
    return {
      ...p,
      total,
      completed,
      remaining: total - completed,
      percentage: total > 0 ? Math.round((completed / total) * 100) : 0
    };
  }).sort((a, b) => b.remaining - a.remaining);

  return (
    <motion.div
      initial={{ y: 100 }}
      animate={{ y: 0 }}
      className="absolute bottom-0 left-0 right-0 z-30"
    >
      {/* Collapsed Bar */}
      <div 
        className="bg-gray-900/90 backdrop-blur-lg rounded-t-2xl border-t border-gray-700 cursor-pointer"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-gray-400" />
            <span className="text-sm text-white font-medium">Palette DMC</span>
            <Badge variant="secondary" className="bg-gray-800 text-gray-300">
              {palette.length} couleurs
            </Badge>
          </div>
          
          <div className="flex items-center gap-3">
            {activeColor && (
              <Button
                variant="ghost"
                size="sm"
                onClick={(e) => {
                  e.stopPropagation();
                  onClearFilter?.();
                }}
                className="h-7 px-2 text-emerald-400 hover:text-emerald-300"
              >
                <X className="w-4 h-4 mr-1" />
                Filtre actif
              </Button>
            )}
            
            <div className="flex gap-1.5">
              {palette.slice(0, 6).map(p => (
                <div
                  key={p.dmc_code}
                  className="w-5 h-5 rounded-full border-2 border-white/20"
                  style={{ backgroundColor: p.color }}
                />
              ))}
              {palette.length > 6 && (
                <div className="w-5 h-5 rounded-full bg-gray-700 flex items-center justify-center text-[10px] text-white">
                  +{palette.length - 6}
                </div>
              )}
            </div>
            
            {isExpanded ? (
              <ChevronDown className="w-5 h-5 text-gray-400" />
            ) : (
              <ChevronUp className="w-5 h-5 text-gray-400" />
            )}
          </div>
        </div>
      </div>

      {/* Expanded Panel */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="bg-gray-900/95 backdrop-blur-lg overflow-hidden"
          >
            <div className="max-h-64 overflow-y-auto p-4 space-y-2">
              {colorCounts.map(color => (
                <motion.div
                  key={color.dmc_code}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => onColorSelect?.(color.dmc_code === activeColor ? null : color.dmc_code)}
                  className={`
                    flex items-center gap-3 p-3 rounded-xl cursor-pointer transition-all
                    ${color.dmc_code === activeColor 
                      ? 'bg-emerald-500/20 border border-emerald-500/50' 
                      : 'bg-gray-800/50 hover:bg-gray-800 border border-transparent'}
                  `}
                >
                  {/* Color Swatch */}
                  <div className="relative">
                    <div
                      className="w-10 h-10 rounded-lg border-2 border-white/20 flex items-center justify-center text-lg font-bold"
                      style={{ backgroundColor: color.color }}
                    >
                      {color.symbol}
                    </div>
                    {color.dmc_code === activeColor && (
                      <div className="absolute -top-1 -right-1 w-4 h-4 bg-emerald-500 rounded-full flex items-center justify-center">
                        <Filter className="w-2.5 h-2.5 text-white" />
                      </div>
                    )}
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-white font-mono font-bold">DMC {color.dmc_code}</span>
                      <span className="text-gray-400 text-sm truncate">{color.name}</span>
                    </div>
                    <div className="flex items-center gap-2 mt-1">
                      <Progress value={color.percentage} className="h-1.5 flex-1 bg-gray-700" />
                      <span className="text-xs text-gray-400 whitespace-nowrap">
                        {color.completed}/{color.total}
                      </span>
                    </div>
                  </div>

                  {/* Remaining Badge */}
                  <Badge 
                    variant={color.remaining === 0 ? "default" : "secondary"}
                    className={color.remaining === 0 ? "bg-emerald-500" : "bg-gray-700"}
                  >
                    {color.remaining === 0 ? '✓' : `${color.remaining} restants`}
                  </Badge>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}