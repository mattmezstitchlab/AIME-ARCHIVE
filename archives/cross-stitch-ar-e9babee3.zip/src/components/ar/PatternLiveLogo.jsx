import React from 'react';

export default function PatternLiveLogo({ size = 'medium' }) {
  const sizes = {
    small: { container: 'w-6 h-6', grid: 8, stroke: 0.5 },
    medium: { container: 'w-12 h-12', grid: 12, stroke: 1 },
    large: { container: 'w-20 h-20', grid: 16, stroke: 1.5 }
  };

  const config = sizes[size];

  return (
    <div className="flex items-center gap-2">
      {/* Grid icon */}
      <svg
        className={config.container}
        viewBox="0 0 32 32"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* 2x2 grid in perspective */}
        <g opacity="0.9">
          {/* Top-left */}
          <rect
            x="4"
            y="6"
            width="10"
            height="10"
            fill="none"
            stroke="rgb(34, 197, 94)"
            strokeWidth={config.stroke}
          />
          {/* Top-right */}
          <rect
            x="18"
            y="4"
            width="10"
            height="10"
            fill="none"
            stroke="rgb(34, 197, 94)"
            strokeWidth={config.stroke}
            opacity="0.8"
          />
          {/* Bottom-left */}
          <rect
            x="2"
            y="18"
            width="10"
            height="10"
            fill="none"
            stroke="rgb(34, 197, 94)"
            strokeWidth={config.stroke}
            opacity="0.8"
          />
          {/* Bottom-right */}
          <rect
            x="16"
            y="16"
            width="10"
            height="10"
            fill="none"
            stroke="rgb(34, 197, 94)"
            strokeWidth={config.stroke}
            opacity="0.6"
          />
        </g>
      </svg>

      {/* Text - only show on medium/large */}
      {(size === 'medium' || size === 'large') && (
        <div className={size === 'large' ? 'space-y-0.5' : 'space-y-0'}>
          <div className={`font-bold tracking-tight text-white ${size === 'large' ? 'text-lg' : 'text-sm'}`}>
            PATTERN
          </div>
          <div className={`text-emerald-400 font-light tracking-wider ${size === 'large' ? 'text-sm' : 'text-xs'}`}>
            LIVE
          </div>
        </div>
      )}
    </div>
  );
}