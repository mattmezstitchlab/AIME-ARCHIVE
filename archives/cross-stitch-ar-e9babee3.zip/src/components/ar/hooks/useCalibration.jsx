import { useState, useCallback } from 'react';

export function useCalibration(patternWidth, patternHeight) {
  const [calibrationMode, setCalibrationMode] = useState('4pt'); // '2pt' | '4pt'
  const [points, setPoints] = useState([]);
  const [isLocked, setIsLocked] = useState(false);
  const [transform, setTransform] = useState(null);

  // Add a calibration point
  const addPoint = useCallback((x, y) => {
    if (isLocked) return;

    const maxPoints = calibrationMode === '4pt' ? 4 : 2;
    if (points.length >= maxPoints) return;

    const newPoints = [...points, { x, y, id: Date.now() }];
    setPoints(newPoints);

    // Auto-compute transform if we have enough points
    if (newPoints.length === maxPoints) {
      const matrix = computeTransform(newPoints, calibrationMode, patternWidth, patternHeight);
      setTransform(matrix);
    }
  }, [points, isLocked, calibrationMode, patternWidth, patternHeight]);

  // Reset points
  const resetPoints = useCallback(() => {
    setPoints([]);
    setTransform(null);
  }, []);

  // Lock calibration
  const lockCalibration = useCallback(() => {
    if (points.length >= (calibrationMode === '4pt' ? 4 : 2) && transform) {
      setIsLocked(true);
    }
  }, [points, transform, calibrationMode]);

  // Switch mode (only if not started)
  const switchMode = useCallback((newMode) => {
    if (points.length === 0) {
      setCalibrationMode(newMode);
    }
  }, [points]);

  // Unlock for re-calibration
  const unlock = useCallback(() => {
    setIsLocked(false);
    resetPoints();
  }, [resetPoints]);

  return {
    calibrationMode,
    points,
    isLocked,
    transform,
    addPoint,
    resetPoints,
    lockCalibration,
    switchMode,
    unlock,
    progress: points.length / (calibrationMode === '4pt' ? 4 : 2)
  };
}

/**
 * Compute transform matrix based on calibration points
 * For 4pt: use perspective/homography
 * For 2pt: use simple scale + rotation
 */
function computeTransform(points, mode, patternWidth, patternHeight) {
  if (mode === '4pt' && points.length === 4) {
    // Simple 4-point perspective transform
    // Maps pattern grid corners to user-tapped points
    return {
      mode: '4pt',
      sourceCorners: [
        { x: 0, y: 0 },
        { x: patternWidth, y: 0 },
        { x: patternWidth, y: patternHeight },
        { x: 0, y: patternHeight }
      ],
      destCorners: points.map(p => ({ x: p.x, y: p.y })),
      matrix: buildPerspectiveMatrix(
        [
          { x: 0, y: 0 },
          { x: patternWidth, y: 0 },
          { x: patternWidth, y: patternHeight },
          { x: 0, y: patternHeight }
        ],
        points.map(p => ({ x: p.x, y: p.y }))
      )
    };
  } else if (mode === '2pt' && points.length === 2) {
    // 2-point calibration: scale + rotation
    const p0 = points[0];
    const p1 = points[1];
    
    const dx = p1.x - p0.x;
    const dy = p1.y - p0.y;
    const distance = Math.sqrt(dx * dx + dy * dy);
    const angle = Math.atan2(dy, dx);
    
    // Assume p0 = origin, p1 = point at (width, 0)
    const scale = distance / patternWidth;
    
    return {
      mode: '2pt',
      origin: p0,
      scale,
      angle,
      matrix: build2ptMatrix(p0, scale, angle)
    };
  }

  return null;
}

/**
 * Build a 3x3 perspective transformation matrix
 * Using simple homography approximation
 */
function buildPerspectiveMatrix(src, dst) {
  // Simple implementation: return matrix params for CSS transform or Canvas
  // In production, use a proper homography solver (e.g., cv.js or custom)
  return {
    type: 'perspective',
    src,
    dst
  };
}

/**
 * Build 2D transform matrix for 2-point calibration
 */
function build2ptMatrix(origin, scale, angle) {
  return {
    type: '2d',
    translateX: origin.x,
    translateY: origin.y,
    scale,
    angle
  };
}