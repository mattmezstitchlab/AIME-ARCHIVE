import React from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Zap, Users, Grid3X3 } from 'lucide-react';
import PatternLiveLogo from './PatternLiveLogo';

export default function ManifestoScreen({ onEnter }) {
  return (
    <div className="fixed inset-0 bg-black overflow-hidden flex flex-col">
      {/* Subtle background grid */}
      <div className="absolute inset-0 opacity-5">
        <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="bg-grid" width="40" height="40" patternUnits="userSpaceOnUse">
              <circle cx="20" cy="20" r="1" fill="rgb(34, 197, 94)" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#bg-grid)" />
        </svg>
      </div>

      {/* Content */}
      <div className="relative z-10 flex-1 flex flex-col items-center justify-center px-6 text-center space-y-8 max-w-md mx-auto">
        
        {/* Logo */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
        >
          <PatternLiveLogo size="large" />
        </motion.div>

        {/* Tagline */}
        <motion.p
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="text-sm text-gray-400"
        >
          Un atelier AR pour broder sans être seul(e)
        </motion.p>

        {/* Features */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="space-y-4 w-full"
        >
          {[
            { icon: Grid3X3, text: 'Une grille vivante sur ton tissu' },
            { icon: Zap, text: 'Une voix douce pour t\'accompagner' },
            { icon: Users, text: 'Une présence humaine quand tu le souhaites' }
          ].map((item, idx) => {
            const Icon = item.icon;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.4 + idx * 0.1 }}
                className="flex items-center gap-3 text-left text-gray-300"
              >
                <Icon className="w-5 h-5 text-emerald-400 flex-shrink-0" />
                <span className="text-sm">{item.text}</span>
              </motion.div>
            );
          })}
        </motion.div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.7 }}
          className="w-full pt-4"
        >
          <Button
            onClick={onEnter}
            className="w-full bg-emerald-500 hover:bg-emerald-600 text-white font-light"
          >
            Entrer
          </Button>
        </motion.div>
      </div>

      {/* Footer text */}
      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.8 }}
        className="relative z-10 text-center text-xs text-gray-600 pb-6 px-4"
      >
        Il n'y a rien à réussir. Seulement à continuer.
      </motion.p>
    </div>
  );
}