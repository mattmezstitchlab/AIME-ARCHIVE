import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Upload, Image as ImageIcon, Eye, Loader2 } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";
import { base44 } from '@/api/base44Client';

export default function ARPatternPreview({ onClose, onPatternLoaded, patternId }) {
  const [imageFile, setImageFile] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [arOverlay, setArOverlay] = useState(null);
  const videoRef = useRef(null);
  const canvasRef = useRef(null);

  const handleImageUpload = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setImageFile(file);
    const reader = new FileReader();
    reader.onloadend = () => {
      setImagePreview(reader.result);
    };
    reader.readAsDataURL(file);
  };

  const analyzePatternImage = async () => {
    if (!imageFile) {
      toast.error('Sélectionnez une image');
      return;
    }

    setIsAnalyzing(true);
    try {
      // Upload image
      const { file_url } = await base44.integrations.Core.UploadFile({ file: imageFile });

      // Analyze with AI to extract pattern data
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyser cette image de pattern de broderie et extraire les informations:
1. Dimensions approximatives (largeur x hauteur en points)
2. Nombre de couleurs uniques
3. Niveau de complexité (simple/moyen/avancé)
4. Points clés (zones importantes du pattern)
Retourner au format JSON structuré.`,
        add_context_from_internet: false,
        file_urls: [file_url],
        response_json_schema: {
          type: 'object',
          properties: {
            width: { type: 'number' },
            height: { type: 'number' },
            colors_count: { type: 'number' },
            complexity: { type: 'string' },
            key_points: { type: 'array', items: { type: 'object' } }
          }
        }
      });

      setArOverlay({
        imageUrl: file_url,
        analysis: response
      });

      toast.success('Pattern analysé !');
    } catch (error) {
      toast.error('Erreur: ' + error.message);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const startARPreview = async () => {
    if (!videoRef.current || !canvasRef.current) return;

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' }
      });

      videoRef.current.srcObject = stream;
      videoRef.current.play();

      // Draw overlay on canvas
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      
      const drawFrame = () => {
        ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
        
        // Draw pattern overlay semi-transparent
        if (arOverlay?.imageUrl) {
          const img = new Image();
          img.onload = () => {
            ctx.globalAlpha = 0.4;
            ctx.drawImage(img, 50, 50, 300, 300);
            ctx.globalAlpha = 1.0;
          };
          img.src = arOverlay.imageUrl;
        }

        // Draw info
        ctx.fillStyle = 'rgba(255,255,255,0.9)';
        ctx.font = '14px Arial';
        ctx.fillText(`${arOverlay?.analysis?.width || '?'}x${arOverlay?.analysis?.height || '?'} points`, 10, 30);
        ctx.fillText(`${arOverlay?.analysis?.colors_count || '?'} couleurs`, 10, 50);

        requestAnimationFrame(drawFrame);
      };

      drawFrame();
    } catch (error) {
      toast.error('Erreur caméra: ' + error.message);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] bg-black/80 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.9, y: 20 }}
        onClick={(e) => e.stopPropagation()}
        className="max-w-2xl w-full space-y-4"
      >
        <Card className="bg-gray-900 border-gray-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold text-white">Aperçu AR du Pattern</h2>
              <Button variant="ghost" size="icon" onClick={onClose}>
                <X className="w-4 h-4" />
              </Button>
            </div>

            {!imagePreview && !arOverlay ? (
              <div className="space-y-4">
                <label className="flex flex-col items-center justify-center h-40 border-2 border-dashed border-gray-700 rounded-lg cursor-pointer hover:border-gray-600 transition-colors">
                  <ImageIcon className="w-12 h-12 text-gray-600 mb-2" />
                  <span className="text-sm text-gray-400">Cliquez pour uploader une image de pattern</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                </label>
              </div>
            ) : !arOverlay ? (
              <div className="space-y-4">
                <img 
                  src={imagePreview} 
                  alt="Preview" 
                  className="w-full h-48 object-cover rounded-lg"
                />
                <Button
                  onClick={analyzePatternImage}
                  disabled={isAnalyzing}
                  className="w-full bg-emerald-500 hover:bg-emerald-600"
                >
                  {isAnalyzing ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Analyse en cours...
                    </>
                  ) : (
                    'Analyser le pattern'
                  )}
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="bg-gray-800/50 rounded-lg p-4 space-y-2">
                  <h3 className="text-sm font-semibold text-white">Analyse du pattern</h3>
                  <div className="grid grid-cols-2 gap-2 text-sm text-gray-300">
                    <div>Dimensions: {arOverlay.analysis?.width}x{arOverlay.analysis?.height}</div>
                    <div>Couleurs: {arOverlay.analysis?.colors_count}</div>
                    <div>Complexité: {arOverlay.analysis?.complexity}</div>
                    <div>Points clés: {arOverlay.analysis?.key_points?.length || 0}</div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Button
                    onClick={startARPreview}
                    className="w-full bg-purple-500 hover:bg-purple-600"
                  >
                    <Eye className="w-4 h-4 mr-2" />
                    Aperçu AR
                  </Button>
                </div>

                {/* Hidden canvas for AR */}
                <canvas ref={canvasRef} className="hidden" width={640} height={480} />
                <video ref={videoRef} className="hidden" />

                <Button
                  onClick={onClose}
                  variant="outline"
                  className="w-full border-gray-700"
                >
                  Fermer
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  );
}