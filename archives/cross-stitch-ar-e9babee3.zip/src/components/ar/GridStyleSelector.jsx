import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { motion } from 'framer-motion';
import { Grid3X3, Minus } from 'lucide-react';

export default function GridStyleSelector({ gridStyle, onGridStyleChange, opacity, onOpacityChange, scale, onScaleChange }) {
  const styles = [
    { id: 'solid', name: 'Solide', icon: '⬜' },
    { id: 'dashed', name: 'Pointillé', icon: '⬚' },
    { id: 'dotted', name: 'Points', icon: '•' },
    { id: 'colored', name: 'Colorée', icon: '🎨' }
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-4"
    >
      {/* Grid Styles */}
      <div className="space-y-3">
        <label className="text-xs font-semibold uppercase tracking-wide text-gray-400">Style de grille</label>
        <div className="grid grid-cols-2 gap-2">
          {styles.map(style => (
            <motion.button
              key={style.id}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => onGridStyleChange(style.id)}
              className={`p-3 rounded-lg border transition flex flex-col items-center gap-2 ${
                gridStyle === style.id
                  ? 'border-emerald-400 bg-emerald-400/10'
                  : 'border-gray-700 bg-gray-800/30 hover:border-gray-600'
              }`}
            >
              <span className="text-2xl">{style.icon}</span>
              <span className="text-xs font-medium">{style.name}</span>
            </motion.button>
          ))}
        </div>
      </div>

      {/* Opacity Slider */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <label className="text-xs font-semibold uppercase tracking-wide text-gray-400">Opacité</label>
          <span className="text-sm text-emerald-400 font-semibold">{Math.round(opacity * 100)}%</span>
        </div>
        <input
          type="range"
          min="0"
          max="100"
          value={Math.round(opacity * 100)}
          onChange={(e) => onOpacityChange(e.target.value / 100)}
          className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-emerald-400"
        />
      </div>

      {/* Scale Slider */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <label className="text-xs font-semibold uppercase tracking-wide text-gray-400">Taille</label>
          <span className="text-sm text-emerald-400 font-semibold">{Math.round(scale * 100)}%</span>
        </div>
        <input
          type="range"
          min="50"
          max="200"
          value={Math.round(scale * 100)}
          onChange={(e) => onScaleChange(e.target.value / 100)}
          className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-emerald-400"
        />
      </div>
    </motion.div>
  );
}