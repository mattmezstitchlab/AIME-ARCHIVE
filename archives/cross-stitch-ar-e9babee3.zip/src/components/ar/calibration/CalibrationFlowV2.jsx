import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { speakKey, stop as stopVoice } from '../voiceEngine';
import PatternRecognition from './PatternRecognition';
import CalibrationModeSelector from './CalibrationModeSelector';
import CalibrationCanvas from './CalibrationCanvas';
import CalibrationSuccess from './CalibrationSuccess';

export default function CalibrationFlowV2({
  capturedImage,
  onComplete,
  onRetake
}) {
  const [stage, setStage] = useState('autoDetect'); // autoDetect | modeSelect | calibrating | success
  const [calibrationMode, setCalibrationMode] = useState(null);
  const [calibrationPoints, setCalibrationPoints] = useState([]);
  const [autoDetectError, setAutoDetectError] = useState(false);

  const expectedPoints = calibrationMode === 'fast' ? 2 : 4;

  const handleAutoDetectComplete = (recognitionData) => {
    // If auto-detect succeeded, skip to success
    if (recognitionData.autoDetected) {
      const pattern = recognitionData.pattern;
      
      // Convert pattern to calibration format
      setCalibrationPoints([
        { x: 0, y: 0 },
        { x: 1, y: 1 }
      ]);
      
      stopVoice();
      speakKey('auto_ok', 'C\'est validé. La grille est maintenant parfaitement alignée. Vous pouvez commencer à broder.', { cooldownMs: 60000 });
      setStage('success');

      // Complete with pattern - NO TIMEOUT, let parent handle transition
      onComplete({
        image: capturedImage,
        calibration: [
          { x: 0, y: 0 },
          { x: 1, y: 1 }
        ],
        pattern: pattern,
        method: 'autoDetected'
      });
      return;
    }
  };

  const handleAutoDetectError = () => {
    setAutoDetectError(true);
    setStage('modeSelect');
  };

  const handleModeSelect = (mode) => {
    setCalibrationMode(mode);
    setCalibrationPoints([]);
    setStage('calibrating');

    const modeText = mode === 'fast'
      ? 'Touchez d\'abord le coin haut gauche du motif. Puis le coin bas droit. Cela me permettra d\'aligner la grille correctement.'
      : 'Nous allons être un peu plus précis. Touchez les quatre coins du motif, dans l\'ordre. Prenez votre temps, je m\'adapte à vous.';
    speakKey('calibration_mode', modeText, { cooldownMs: 60000 });
  };

  const handlePointAdded = (points) => {
    setCalibrationPoints(points);

    if (points.length === 1) {
      speakKey('calib_point_1', 'Point 1 enregistré. Un dernier point.', { cooldownMs: 15000 });
    } else if (points.length === 2 && expectedPoints === 4) {
      speakKey('calib_point_2', 'Très bien. Encore un point…', { cooldownMs: 15000 });
    } else if (points.length === 3) {
      speakKey('calib_point_3', 'Parfait. Le dernier.', { cooldownMs: 15000 });
    }
  };

  const handleValidate = () => {
    if (calibrationPoints.length === expectedPoints) {
      stopVoice();
      speakKey('calibration_ok', 'C\'est validé. La grille est maintenant parfaitement alignée. Vous pouvez commencer à broder.', { cooldownMs: 60000 });
      setStage('success');
    }
  };

  const handleRetakePhoto = () => {
    stopVoice();
    setCalibrationMode(null);
    setCalibrationPoints([]);
    setAutoDetectError(false);
    setStage('autoDetect');
    onRetake();
  };

  return (
    <div className="fixed inset-0 bg-black z-50">
      <AnimatePresence mode="wait">
        {/* Auto-detection stage */}
        {stage === 'autoDetect' && (
          <motion.div key="autoDetect" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <PatternRecognition
              capturedImage={capturedImage}
              onComplete={handleAutoDetectComplete}
              onError={handleAutoDetectError}
              onManualCalibration={() => {
                setAutoDetectError(true);
                setStage('modeSelect');
              }}
            />
          </motion.div>
        )}

        {/* Mode selection (if auto-detect fails) */}
        {stage === 'modeSelect' && (
          <motion.div
            key="modeSelect"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 flex flex-col items-center justify-center p-4"
          >
            {autoDetectError && (
              <motion.p
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="absolute top-20 text-sm text-gray-400 text-center"
              >
                Reconnaissance automatique non disponible. Mode manuel.
              </motion.p>
            )}
            <CalibrationModeSelector onSelect={handleModeSelect} />
          </motion.div>
        )}

        {/* Manual calibration */}
        {stage === 'calibrating' && (
          <motion.div
            key="calibrating"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 flex flex-col"
          >
            <CalibrationCanvas
              image={capturedImage}
              mode={calibrationMode}
              points={calibrationPoints}
              onPointAdded={handlePointAdded}
              onValidate={handleValidate}
              onRetake={handleRetakePhoto}
            />
          </motion.div>
        )}

        {/* Success */}
        {stage === 'success' && (
          <motion.div
            key="success"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="absolute inset-0 flex items-center justify-center"
          >
            <CalibrationSuccess
              onContinue={() => {
                stopVoice();
                onComplete({
                  image: capturedImage,
                  calibration: calibrationPoints,
                  method: 'manual'
                });
              }}
              onRetry={handleRetakePhoto}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}