import React, { useRef, useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { RotateCcw, Check } from 'lucide-react';
import { speakKey, stop as stopVoice } from '../voiceEngine';

export default function CalibrationCanvas({
  image,
  mode,
  points,
  onPointAdded,
  onValidate,
  onRetake
}) {
  const canvasRef = useRef(null);
  const containerRef = useRef(null);
  const [magnifierPos, setMagnifierPos] = useState(null);
  const expectedPoints = mode === 'fast' ? 2 : 4;

  const getPointLabel = (index) => {
    if (mode === 'fast') {
      return index === 0 ? 'Haut-gauche' : 'Bas-droit';
    } else {
      const labels = ['Haut-gauche', 'Haut-droit', 'Bas-droit', 'Bas-gauche'];
      return labels[index];
    }
  };

  const handleCanvasClick = (e) => {
    if (points.length >= expectedPoints) return;

    stopVoice();
    
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    const x = (e.clientX - rect.left) * scaleX;
    const y = (e.clientY - rect.top) * scaleY;

    const newPoints = [...points, { x, y }];
    onPointAdded(newPoints);
  };

  const handleMouseMove = (e) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const rect = canvas.getBoundingClientRect();
    setMagnifierPos({
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
      canvasX: e.clientX - rect.left,
      canvasY: e.clientY - rect.top
    });
  };

  // Draw guide grid on canvas overlay
  useEffect(() => {
    if (!canvasRef.current || !image) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    
    const img = new Image();
    img.onload = () => {
      canvas.width = img.width;
      canvas.height = img.height;
      ctx.drawImage(img, 0, 0);

      // Draw guide frame (green dashed)
      const margin = Math.min(canvas.width, canvas.height) * 0.1;
      ctx.strokeStyle = 'rgba(52, 211, 153, 0.6)';
      ctx.lineWidth = 3;
      ctx.setLineDash([10, 10]);
      ctx.strokeRect(margin, margin, canvas.width - margin * 2, canvas.height - margin * 2);
      ctx.setLineDash([]);

      // Draw corner reference markers (subtle)
      const cornerSize = 32;
      ctx.strokeStyle = 'rgba(52, 211, 153, 0.4)';
      ctx.lineWidth = 1.5;
      const corners = [
        [margin, margin],
        [canvas.width - margin, margin],
        [canvas.width - margin, canvas.height - margin],
        [margin, canvas.height - margin]
      ];
      corners.forEach((corner) => {
        ctx.strokeRect(corner[0] - cornerSize / 2, corner[1] - cornerSize / 2, cornerSize, cornerSize);
      });

      // Draw placed points (large, clear)
      points.forEach((pt, idx) => {
        // Outer ring
        ctx.strokeStyle = 'rgba(52, 211, 153, 0.9)';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(pt.x, pt.y, 16, 0, Math.PI * 2);
        ctx.stroke();

        // Fill
        ctx.fillStyle = 'rgba(52, 211, 153, 0.7)';
        ctx.beginPath();
        ctx.arc(pt.x, pt.y, 14, 0, Math.PI * 2);
        ctx.fill();

        // Number
        ctx.fillStyle = 'white';
        ctx.font = 'bold 16px sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(idx + 1, pt.x, pt.y);
      });
    };
    img.src = image;
  }, [image, points]);

  return (
    <div className="absolute inset-0 flex flex-col bg-black">
      {/* Header */}
      <div className="bg-gradient-to-b from-black/60 to-transparent px-4 py-4 z-20">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-white font-medium">
              Alignez le motif — {mode === 'fast' ? '2 points' : '4 points'}
            </h3>
            <p className="text-xs text-gray-400 mt-1">
              Tap: {points.length}/{expectedPoints} — {getPointLabel(points.length)}
            </p>
          </div>
        </div>
      </div>

      {/* Canvas */}
      <div className="flex-1 flex items-center justify-center overflow-hidden p-4">
        <canvas
          ref={canvasRef}
          onClick={handleCanvasClick}
          onMouseMove={handleMouseMove}
          className="max-w-full max-h-full cursor-crosshair rounded-lg shadow-2xl"
          style={{ display: 'block' }}
        />

        {/* Magnifier (zoomed view) */}
        {magnifierPos && points.length < expectedPoints && (
          <motion.div
            className="fixed w-24 h-24 border-2 border-emerald-400 rounded-full bg-black pointer-events-none overflow-hidden shadow-xl"
            style={{
              left: magnifierPos.x + 32,
              top: magnifierPos.y + 32
            }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            <canvas
              ref={canvasRef}
              style={{
                position: 'absolute',
                width: '100%',
                height: '100%',
                objectFit: 'cover',
                transform: `scale(2.5) translate(-${(magnifierPos.canvasX / 2.5) - 48}px, -${(magnifierPos.canvasY / 2.5) - 48}px)`
              }}
            />
          </motion.div>
        )}
      </div>

      {/* Progress indicator */}
      <div className="bg-gradient-to-t from-black/60 to-transparent px-4 py-4 z-20">
        <div className="flex items-center justify-between mb-3">
          <span className="text-white text-sm font-medium">
            Progression: {points.length}/{expectedPoints}
          </span>
          {points.length === expectedPoints && (
            <motion.span
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className="text-emerald-400 text-sm font-medium flex items-center gap-1"
            >
              <Check className="w-4 h-4" /> Prêt à valider
            </motion.span>
          )}
        </div>

        {/* Progress bar */}
        <div className="w-full h-1 bg-white/10 rounded-full overflow-hidden">
          <motion.div
            className="h-full bg-emerald-500"
            initial={{ width: 0 }}
            animate={{ width: `${(points.length / expectedPoints) * 100}%` }}
            transition={{ duration: 0.3 }}
          />
        </div>
      </div>

      {/* Bottom buttons */}
      <div className="absolute bottom-4 left-4 right-4 flex gap-3 z-20">
        <button
          onClick={onRetake}
          className="flex-1 py-2 px-3 rounded-lg bg-white/10 hover:bg-white/20 text-white text-sm font-medium transition flex items-center justify-center gap-2"
        >
          <RotateCcw className="w-4 h-4" /> Reprendre
        </button>

        <button
          onClick={onValidate}
          disabled={points.length !== expectedPoints}
          className="flex-1 py-2 px-3 rounded-lg bg-emerald-500 hover:bg-emerald-600 disabled:opacity-50 disabled:cursor-not-allowed text-white text-sm font-medium transition flex items-center justify-center gap-2"
        >
          <Check className="w-4 h-4" /> Valider
        </button>
      </div>
    </div>
  );
}