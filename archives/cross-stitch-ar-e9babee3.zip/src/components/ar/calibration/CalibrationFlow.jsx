import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { RotateCcw, Check } from 'lucide-react';
import { speakKey, stop as stopVoice } from '../voiceEngine';
import CalibrationModeSelector from './CalibrationModeSelector';
import CalibrationCanvas from './CalibrationCanvas';
import CalibrationSuccess from './CalibrationSuccess';

export default function CalibrationFlow({
  capturedImage,
  onComplete,
  onRetake
}) {
  const [stage, setStage] = useState('modeSelect'); // modeSelect | calibrating | success
  const [calibrationMode, setCalibrationMode] = useState(null); // 'fast' | 'precise'
  const [calibrationPoints, setCalibrationPoints] = useState([]);
  const expectedPoints = calibrationMode === 'fast' ? 2 : 4;

  const handleModeSelect = (mode) => {
    setCalibrationMode(mode);
    setCalibrationPoints([]);
    setStage('calibrating');
    
    const modeText = mode === 'fast' 
      ? 'Touchez d\'abord le coin haut gauche du motif. Puis le coin bas droit. Cela me permettra d\'aligner la grille correctement.'
      : 'Nous allons être un peu plus précis. Touchez les quatre coins du motif, dans l\'ordre. Prenez votre temps, je m\'adapte à vous.';
    speakKey('calibration_mode', modeText, { cooldownMs: 60000 });
  };

  const handlePointAdded = (points) => {
    setCalibrationPoints(points);
    
    // Natural voice feedback on each point
    if (points.length === 1) {
      speakKey('calib_point_1', 'Point 1 enregistré. Un dernier point.', { cooldownMs: 15000 });
    } else if (points.length === 2 && expectedPoints === 4) {
      speakKey('calib_point_2', 'Très bien. Encore un point…', { cooldownMs: 15000 });
    } else if (points.length === 3) {
      speakKey('calib_point_3', 'Parfait. Le dernier.', { cooldownMs: 15000 });
    }
  };

  const handleValidate = () => {
    if (calibrationPoints.length === expectedPoints) {
      stopVoice();
      speakKey('calibration_ok', 'C\'est validé. La grille est maintenant parfaitement alignée. Vous pouvez commencer à broder.', { cooldownMs: 60000 });
      setStage('success');
    }
  };

  const handleRetakePhoto = () => {
    stopVoice();
    setCalibrationMode(null);
    setCalibrationPoints([]);
    setStage('modeSelect');
    onRetake();
  };

  return (
    <div className="fixed inset-0 bg-black z-50">
      <AnimatePresence mode="wait">
        {/* Mode Selection */}
        {stage === 'modeSelect' && (
          <motion.div
            key="modeSelect"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 flex flex-col items-center justify-center p-4"
          >
            <CalibrationModeSelector onSelect={handleModeSelect} />
          </motion.div>
        )}

        {/* Calibration Canvas */}
        {stage === 'calibrating' && (
          <motion.div
            key="calibrating"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 flex flex-col"
          >
            <CalibrationCanvas
              image={capturedImage}
              mode={calibrationMode}
              points={calibrationPoints}
              onPointAdded={handlePointAdded}
              onValidate={handleValidate}
              onRetake={handleRetakePhoto}
            />
          </motion.div>
        )}

        {/* Success State */}
        {stage === 'success' && (
          <motion.div
            key="success"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="absolute inset-0 flex items-center justify-center"
          >
            <CalibrationSuccess
              onContinue={() => {
                onComplete({
                  image: capturedImage,
                  calibration: calibrationPoints,
                  mode: calibrationMode
                });
              }}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}