import React from 'react';
import { motion } from 'framer-motion';
import { Zap, Crosshair } from 'lucide-react';

export default function CalibrationModeSelector({ onSelect }) {
  return (
    <div className="w-full max-w-md space-y-6">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center space-y-2"
      >
        <h2 className="text-2xl font-light text-white">Photo capturée</h2>
        <p className="text-sm text-gray-400">Choisissez le mode d'alignement</p>
      </motion.div>

      <div className="space-y-3">
        {/* Fast Mode - Default */}
        <motion.button
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.1 }}
          onClick={() => onSelect('fast')}
          className="w-full p-4 rounded-lg border-2 border-emerald-500/50 bg-emerald-500/10 hover:bg-emerald-500/20 text-left transition group ring-2 ring-emerald-500/30"
        >
          <div className="flex items-start gap-3">
            <Zap className="w-5 h-5 text-emerald-400 mt-1 flex-shrink-0" />
            <div>
              <div className="flex items-center gap-2">
                <p className="text-white font-medium">Rapide (2 points)</p>
                <span className="text-xs bg-emerald-500/30 text-emerald-300 px-2 py-0.5 rounded">Recommandé</span>
              </div>
              <p className="text-xs text-gray-400 mt-1">
                Tape deux coins opposés du motif
                <br />
                Idéal pour un motif bien face caméra
              </p>
            </div>
          </div>
        </motion.button>

        {/* Precise Mode */}
        <motion.button
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          onClick={() => onSelect('precise')}
          className="w-full p-4 rounded-lg border-2 border-blue-500/30 bg-blue-500/5 hover:bg-blue-500/15 text-left transition group"
        >
          <div className="flex items-start gap-3">
            <Crosshair className="w-5 h-5 text-blue-400 mt-1 flex-shrink-0" />
            <div>
              <p className="text-white font-medium">Précis (4 points)</p>
              <p className="text-xs text-gray-400 mt-1">
                Tape les quatre coins du motif
                <br />
                Corrige la perspective si image inclinée ou en angle
              </p>
            </div>
          </div>
        </motion.button>
      </div>

      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
        className="text-xs text-center text-gray-500"
      >
        Le mode rapide est suffisant pour la plupart des cas
      </motion.p>
    </div>
  );
}