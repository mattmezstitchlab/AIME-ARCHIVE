import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { speakKey, stop as stopVoice } from '../voiceEngine';

export default function PatternRecognition({
  capturedImage,
  onComplete,
  onError,
  onManualCalibration
}) {
  const [recognitionStep, setRecognitionStep] = useState('analyzing'); // analyzing | preview | ready
  const [recognizedPattern, setRecognizedPattern] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    const analyzeImage = async () => {
      try {
        console.log('[RECOGNITION] Starting analysis...');

        // Start voice during analysis
        speakKey('analysis_start', 'Je reconnais la grille et les symboles. Je fais de mon mieux pour comprendre le motif. Vous pourrez ajuster ensuite, tranquillement.', { cooldownMs: 60000 });

        // If capturedImage is a dataURL, convert to File for upload
        let imageUrl = capturedImage;
        if (capturedImage.startsWith('data:')) {
          console.log('[RECOGNITION] Uploading dataURL...');
          const blob = await (await fetch(capturedImage)).blob();
          const uploadRes = await base44.integrations.Core.UploadFile({
            file: blob
          });

          if (!uploadRes?.file_url) throw new Error('Upload failed');
          imageUrl = uploadRes.file_url;
          console.log('[RECOGNITION] Upload OK:', imageUrl);
        }

        // Call recognition function
        console.log('[RECOGNITION] Calling recognizePattern with:', imageUrl);
        const recognitionRes = await base44.functions.invoke('recognizePattern', {
          imageUrl
        });

        console.log('[RECOGNITION] Response:', recognitionRes);

        if (!recognitionRes?.data?.success) {
          throw new Error(recognitionRes?.data?.error || 'Recognition failed');
        }

        const pattern = recognitionRes.data.pattern;
        console.log('[RECOGNITION] Pattern recognized:', pattern.grid_width, 'x', pattern.grid_height);
        
        setRecognizedPattern(pattern);
        setRecognitionStep('preview');

        // Voice feedback
        setTimeout(() => {
          speakKey('analysis_done', 'Le motif est prêt. Nous pouvons maintenant travailler dessus ensemble.', { cooldownMs: 60000 });
        }, 500);
      } catch (err) {
        console.error('[RECOGNITION] Error:', err.message);
        setError(err.message);
        setRecognitionStep('error');
        stopVoice();
        onError(err);
      }
    };

    analyzeImage();

    return () => stopVoice();
  }, [capturedImage, onError]);

  if (recognitionStep === 'analyzing') {
    return (
      <div className="absolute inset-0 flex flex-col items-center justify-center bg-black z-50">
        <motion.div
          animate={{ scale: [1, 1.05, 1] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="w-16 h-16 rounded-full border-3 border-emerald-400 border-t-transparent"
        />
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="text-white mt-6 text-sm"
        >
          Reconnaissance en cours…
        </motion.p>
      </div>
    );
  }

  if (recognitionStep === 'error') {
    return (
      <div className="absolute inset-0 flex flex-col items-center justify-center bg-black z-50 p-4">
        <div className="text-center space-y-4">
          <p className="text-red-400 text-sm">Reconnaissance échouée</p>
          <p className="text-gray-400 text-xs">{error}</p>
          <button
            onClick={() => onManualCalibration()}
            className="px-6 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white text-sm transition"
          >
            Calibration manuelle
          </button>
        </div>
      </div>
    );
  }

  if (recognitionStep === 'preview' && recognizedPattern) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="absolute inset-0 flex flex-col bg-black z-50"
      >
        {/* Image preview with grid overlay */}
        <div className="flex-1 flex items-center justify-center overflow-hidden p-4 bg-black/80">
          <div className="relative max-w-full max-h-full">
            <img
              src={capturedImage}
              alt="recognized"
              className="max-w-full max-h-full rounded-lg"
            />
            <svg
              className="absolute inset-0 w-full h-full rounded-lg pointer-events-none"
              style={{ mixBlendMode: 'screen' }}
            >
              <defs>
                <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
                  <path d="M 20 0 L 0 0 0 20" fill="none" stroke="rgba(52, 211, 153, 0.2)" strokeWidth="1" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#grid)" />
            </svg>
          </div>
        </div>

        {/* Info panel */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="bg-gradient-to-t from-black via-black/80 to-transparent px-4 py-6 space-y-4"
        >
          <div className="space-y-2">
            <p className="text-white font-medium">Grille détectée</p>
            <p className="text-sm text-gray-400">
              {recognizedPattern.grid_width} × {recognizedPattern.grid_height} points
              <br />
              Confiance : {Math.round(recognizedPattern.confidence * 100)}%
            </p>
            {recognizedPattern.notes && (
              <p className="text-xs text-gray-500 italic">{recognizedPattern.notes}</p>
            )}
          </div>

          {/* Action buttons */}
          <div className="flex gap-3">
            <button
              onClick={() => onManualCalibration()}
              className="flex-1 py-3 px-4 rounded-lg bg-white/10 hover:bg-white/20 text-white text-sm font-medium transition"
            >
              Ajuster manuellement
            </button>
            <button
              onClick={() => {
                stopVoice();
                onComplete({
                  image: capturedImage,
                  pattern: recognizedPattern,
                  autoDetected: true
                });
              }}
              className="flex-1 py-3 px-4 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white text-sm font-medium transition"
            >
              Utiliser ce pattern
            </button>
          </div>
        </motion.div>
      </motion.div>
    );
  }

  return null;
}