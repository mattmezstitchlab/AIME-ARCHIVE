import React, { useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { RotateCcw, Check, ArrowRight } from 'lucide-react';

export default function CalibrationOverlay({
  isActive = false,
  mode = '4pt', // '2pt' | '4pt'
  points = [],
  progress = 0,
  isLocked = false,
  onAddPoint,
  onReset,
  onLock,
  onSwitchMode,
  onDone
}) {
  const canvasRef = useRef(null);

  // Draw calibration points and guides on canvas overlay
  useEffect(() => {
    if (!canvasRef.current || !isActive) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const rect = canvas.getBoundingClientRect();
    
    // Set canvas size
    canvas.width = rect.width;
    canvas.height = rect.height;

    // Clear
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw points
    points.forEach((point, idx) => {
      const letter = String.fromCharCode(65 + idx); // A, B, C, D
      
      // Point circle
      ctx.fillStyle = '#22c55e';
      ctx.beginPath();
      ctx.arc(point.x, point.y, 12, 0, Math.PI * 2);
      ctx.fill();

      // Label
      ctx.fillStyle = '#000';
      ctx.font = 'bold 12px system-ui';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(letter, point.x, point.y);

      // Crosshair
      ctx.strokeStyle = 'rgba(34, 197, 94, 0.3)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(point.x - 20, point.y);
      ctx.lineTo(point.x + 20, point.y);
      ctx.moveTo(point.x, point.y - 20);
      ctx.lineTo(point.x, point.y + 20);
      ctx.stroke();
    });

    // Draw connecting lines (quad)
    if (points.length >= 2) {
      ctx.strokeStyle = 'rgba(34, 197, 94, 0.5)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(points[0].x, points[0].y);
      for (let i = 1; i < points.length; i++) {
        ctx.lineTo(points[i].x, points[i].y);
      }
      if (points.length === 4 || mode === '4pt') {
        ctx.lineTo(points[0].x, points[0].y); // Close quad
      }
      ctx.stroke();
    }
  }, [points, isActive, mode]);

  // Handle canvas tap
  const handleCanvasTap = (e) => {
    if (!isActive || isLocked) return;

    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    onAddPoint(x, y);
  };

  const maxPoints = mode === '4pt' ? 4 : 2;
  const canProgress = points.length === maxPoints;

  if (!isActive) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50"
    >
      {/* Full-screen canvas for tap interactions */}
      <canvas
        ref={canvasRef}
        onClick={handleCanvasTap}
        className="absolute inset-0 w-full h-full cursor-crosshair"
      />

      {/* Instruction overlay */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="absolute top-24 left-0 right-0 flex justify-center pointer-events-none"
      >
        <div className="bg-black/60 backdrop-blur-sm px-6 py-3 rounded-lg border border-gray-700/50 text-center">
          {!isLocked ? (
            <div className="space-y-1">
              <p className="text-emerald-400 font-medium text-sm">
                Tap {points.length + 1} of {maxPoints}
              </p>
              <p className="text-gray-300 text-xs">
                {mode === '4pt'
                  ? 'Tap the 4 corners of the pattern area'
                  : 'Tap 2 reference points'}
              </p>
            </div>
          ) : (
            <div className="space-y-1">
              <p className="text-green-400 font-medium text-sm flex items-center justify-center gap-2">
                <Check className="w-4 h-4" />
                Calibration locked
              </p>
            </div>
          )}
        </div>
      </motion.div>

      {/* Progress bar */}
      <div className="absolute bottom-32 left-6 right-6 h-1 bg-gray-700/50 rounded-full overflow-hidden">
        <motion.div
          className="h-full bg-emerald-500"
          initial={{ width: '0%' }}
          animate={{ width: `${progress * 100}%` }}
          transition={{ type: 'spring', stiffness: 100 }}
        />
      </div>

      {/* Bottom controls */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="absolute bottom-6 left-6 right-6 flex gap-3"
      >
        {/* Mode selector (if no points yet) */}
        {points.length === 0 && !isLocked && (
          <div className="flex gap-2 flex-1">
            <button
              onClick={() => onSwitchMode('4pt')}
              className={`flex-1 py-2 px-3 rounded-lg text-xs font-medium transition ${
                mode === '4pt'
                  ? 'bg-emerald-500 text-white'
                  : 'bg-gray-700/50 text-gray-300 hover:bg-gray-700'
              }`}
            >
              4-Point
            </button>
            <button
              onClick={() => onSwitchMode('2pt')}
              className={`flex-1 py-2 px-3 rounded-lg text-xs font-medium transition ${
                mode === '2pt'
                  ? 'bg-emerald-500 text-white'
                  : 'bg-gray-700/50 text-gray-300 hover:bg-gray-700'
              }`}
            >
              2-Point Quick
            </button>
          </div>
        )}

        {/* Action buttons */}
        <AnimatePresence mode="wait">
          {points.length > 0 && !isLocked && (
            <motion.button
              key="reset"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              onClick={onReset}
              className="px-4 py-2 rounded-lg bg-gray-700/50 hover:bg-gray-700 text-gray-300 text-sm font-medium transition flex items-center gap-2 pointer-events-auto"
            >
              <RotateCcw className="w-4 h-4" />
              Reset
            </motion.button>
          )}

          {canProgress && !isLocked && (
            <motion.button
              key="lock"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              onClick={onLock}
              className="flex-1 px-6 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white font-medium transition flex items-center justify-center gap-2 pointer-events-auto"
            >
              <Check className="w-4 h-4" />
              Confirm
            </motion.button>
          )}

          {isLocked && (
            <motion.button
              key="done"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              onClick={onDone}
              className="flex-1 px-6 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white font-medium transition flex items-center justify-center gap-2 pointer-events-auto"
            >
              <ArrowRight className="w-4 h-4" />
              Done
            </motion.button>
          )}
        </AnimatePresence>
      </motion.div>
    </motion.div>
  );
}