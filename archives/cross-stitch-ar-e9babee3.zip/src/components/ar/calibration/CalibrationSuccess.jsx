import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Check } from 'lucide-react';

export default function CalibrationSuccess({ onContinue, onRetry }) {
  const [autoTransition, setAutoTransition] = useState(true);

  useEffect(() => {
    if (!autoTransition) return;
    const timer = setTimeout(onContinue, 2500);
    return () => clearTimeout(timer);
  }, [onContinue, autoTransition]);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ type: 'spring', stiffness: 200 }}
      className="flex flex-col items-center gap-6 px-4"
    >
      <motion.div
        animate={{ scale: [1, 1.1, 1] }}
        transition={{ duration: 2, repeat: Infinity }}
        className="w-20 h-20 rounded-full bg-emerald-500/20 border-2 border-emerald-400 flex items-center justify-center"
      >
        <Check className="w-10 h-10 text-emerald-400" />
      </motion.div>

      <div className="text-center space-y-2">
        <h2 className="text-2xl font-light text-white">Calibration réussie ✓</h2>
        <p className="text-sm text-gray-400">Passage à la vue AR…</p>
      </div>

      <motion.div
        initial={{ scaleX: 0 }}
        animate={{ scaleX: 1 }}
        transition={{ duration: 2 }}
        className="w-32 h-1 bg-emerald-500 rounded-full origin-left"
      />

      {/* Emergency buttons */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1 }}
        className="flex gap-2 w-full max-w-sm"
      >
        <button
          onClick={() => {
            setAutoTransition(false);
            onContinue();
          }}
          className="flex-1 py-2 px-3 rounded text-xs bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 transition"
        >
          Passer maintenant
        </button>
        <button
          onClick={() => {
            setAutoTransition(false);
            onRetry();
          }}
          className="flex-1 py-2 px-3 rounded text-xs bg-white/10 hover:bg-white/20 text-gray-300 transition"
        >
          Réessayer
        </button>
      </motion.div>
    </motion.div>
  );
}