import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { Grid3X3, Wand2 } from 'lucide-react';

import GridControls from './GridControls';
import SymbolSettings from './SymbolSettings';

export default function SmartStitchPanel({
  nextPoint,
  completedPoints = [],
  totalPoints = 0,
  // Grid controls
  gridOpacity = 0.6,
  onGridOpacityChange,
  gridScale = 1,
  onGridScaleChange,
  gridRotation = 0,
  onGridRotationChange,
  isGridLocked = false,
  onToggleGridLock,
  onResetGridAlignment,
  // Symbol settings
  symbolDensity = 'normal',
  onSymbolDensityChange,
  showSymbols = true,
  onToggleSymbols
}) {
  const progressPercent = totalPoints > 0 ? Math.round((completedPoints.length / totalPoints) * 100) : 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-4"
    >
      {/* Header with progress */}
      <Card className="bg-gray-800/30 border-gray-700">
        <CardContent className="p-3">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-white">SmartStitch</h3>
              <span className="text-xs text-emerald-400">{progressPercent}%</span>
            </div>
            {nextPoint && (
              <p className="text-xs text-gray-400">
                Suivant: ({nextPoint.x}, {nextPoint.y})
              </p>
            )}
            <div className="h-1 bg-gray-700 rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-gradient-to-r from-emerald-500 to-teal-400"
                initial={{ width: 0 }}
                animate={{ width: `${progressPercent}%` }}
                transition={{ duration: 0.3 }}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tabs */}
      <Tabs defaultValue="guide" className="w-full">
        <TabsList className="grid w-full grid-cols-2 bg-gray-700/50">
          <TabsTrigger value="guide" className="text-xs">
            <Wand2 className="w-3 h-3 mr-1" />
            Guide
          </TabsTrigger>
          <TabsTrigger value="grid" className="text-xs">
            <Grid3X3 className="w-3 h-3 mr-1" />
            Grille
          </TabsTrigger>
        </TabsList>

        <TabsContent value="guide" className="mt-3">
          <SymbolSettings
            symbolDensity={symbolDensity}
            onDensityChange={onSymbolDensityChange}
            showSymbols={showSymbols}
            onToggleSymbols={onToggleSymbols}
          />
        </TabsContent>

        <TabsContent value="grid" className="mt-3">
          <GridControls
            opacity={gridOpacity}
            onOpacityChange={onGridOpacityChange}
            scale={gridScale}
            onScaleChange={onGridScaleChange}
            rotation={gridRotation}
            onRotationChange={onGridRotationChange}
            isGridLocked={isGridLocked}
            onToggleLock={onToggleGridLock}
            onResetAlignment={onResetGridAlignment}
          />
        </TabsContent>
      </Tabs>
    </motion.div>
  );
}