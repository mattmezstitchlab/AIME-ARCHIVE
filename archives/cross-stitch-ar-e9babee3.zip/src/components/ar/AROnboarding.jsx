import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Volume2, Camera, ChevronRight, ArrowLeft } from 'lucide-react';
import { Button } from "@/components/ui/button";
import PatternLiveLogo from './PatternLiveLogo';

export default function AROnboarding({ onComplete }) {
  const [step, setStep] = useState(0);

  const steps = [
    {
      icon: Camera,
      title: 'Caméra',
      description: 'Nous avons besoin d\'accéder à votre caméra pour la broderie en AR',
      bgColor: 'from-blue-500 to-blue-600'
    },
    {
      icon: Volume2,
      title: 'Voix Compagnonne',
      description: 'Activez la voix pour des conseils doux en temps réel (optionnel)',
      bgColor: 'from-emerald-500 to-teal-600'
    }
  ];

  const currentStep = steps[step];
  const Icon = currentStep.icon;

  const handleNext = () => {
    if (step < steps.length - 1) {
      setStep(step + 1);
    } else {
      onComplete();
    }
  };

  const handlePrev = () => {
    if (step > 0) {
      setStep(step - 1);
    }
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[100] bg-black flex items-center justify-center p-4"
      >
        <motion.div
          initial={{ scale: 0.95, y: 20 }}
          animate={{ scale: 1, y: 0 }}
          exit={{ scale: 0.95, y: 20 }}
          className="text-center max-w-sm space-y-8"
        >
            {/* Logo */}
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0 }}
            >
              <PatternLiveLogo size="medium" />
            </motion.div>

            {/* Icon */}
          <motion.div
            key={`icon-${step}`}
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            className={`w-20 h-20 rounded-3xl bg-gradient-to-br ${currentStep.bgColor} flex items-center justify-center mx-auto`}
          >
            <Icon className="w-10 h-10 text-white" />
          </motion.div>

          {/* Text */}
          <motion.div
            key={`text-${step}`}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-3"
          >
            <h2 className="text-3xl font-light text-white">
              {currentStep.title}
            </h2>
            <p className="text-gray-400 text-sm leading-relaxed">
              {currentStep.description}
            </p>
          </motion.div>

          {/* Buttons */}
          <div className="flex gap-3 pt-4">
            {step > 0 ? (
                <Button
                  onClick={handlePrev}
                  className="flex-1 bg-gray-800 hover:bg-gray-700 text-white font-light flex items-center justify-center gap-2"
                >
                  <ArrowLeft className="w-4 h-4" />
                  Précédent
                </Button>
              ) : null}
            <Button
              onClick={handleNext}
              className={`${step > 0 ? 'flex-1' : 'w-full'} bg-emerald-500 hover:bg-emerald-600 text-white font-light flex items-center justify-center gap-2`}
            >
              {step === steps.length - 1 ? 'Commencer' : 'Suivant'}
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>

          {/* Progress */}
          <div className="flex gap-1 justify-center">
            {steps.map((_, idx) => (
              <motion.div
                key={idx}
                initial={false}
                animate={{ width: idx <= step ? 24 : 4 }}
                className={`h-1 rounded-full transition-all ${
                  idx <= step ? 'bg-emerald-500' : 'bg-gray-700'
                }`}
              />
            ))}
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}