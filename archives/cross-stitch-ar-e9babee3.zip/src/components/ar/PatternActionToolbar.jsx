import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronUp, Play, X, Info, Zap, Grid3X3 } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";

export default function PatternActionToolbar({ pattern, onClose, onStartAR }) {
  const [isExpanded, setIsExpanded] = useState(false);

  if (!pattern) return null;

  const stitchCount = pattern.total_stitches || Object.keys(pattern.grid_data || {}).length;
  const colorCount = pattern.dmc_palette?.length || 0;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 100, opacity: 0 }}
        transition={{ type: 'spring', damping: 25, stiffness: 300 }}
        className="fixed bottom-0 left-0 right-0 z-50 px-4 pb-4"
      >
        {/* Gradient backdrop */}
        <div className="absolute inset-0 bg-gradient-to-t from-gray-950 via-gray-950/80 to-transparent" />

        <div className="relative max-w-4xl mx-auto">
          <Card className={`bg-gray-900/95 border-emerald-500/30 backdrop-blur-xl transition-all ${isExpanded ? 'shadow-2xl shadow-emerald-500/20' : 'shadow-lg'}`}>
            {/* Collapsed View - Toolbar */}
            <CardContent className={`p-4 transition-all ${isExpanded ? 'pb-2' : ''}`}>
              <div className="flex items-center justify-between">
                {/* Left: Pattern Info */}
                <div className="flex items-center gap-3 min-w-0 flex-1">
                  <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-gray-700 to-gray-800 flex items-center justify-center flex-shrink-0">
                    <Grid3X3 className="w-6 h-6 text-emerald-400" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <h3 className="font-semibold text-white truncate">{pattern.title}</h3>
                    <p className="text-xs text-gray-400">{stitchCount} points • {colorCount} couleurs</p>
                  </div>
                </div>

                {/* Right: Actions */}
                <div className="flex items-center gap-2 flex-shrink-0 ml-4">
                  <Collapsible open={isExpanded} onOpenChange={setIsExpanded}>
                    <CollapsibleTrigger asChild>
                      <Button
                        size="icon"
                        variant="ghost"
                        className="text-gray-400 hover:text-emerald-400 hover:bg-gray-800/50"
                        title={isExpanded ? 'Fermer' : 'Détails'}
                      >
                        <motion.div
                          animate={{ rotate: isExpanded ? 180 : 0 }}
                          transition={{ duration: 0.3 }}
                        >
                          <ChevronUp className="w-5 h-5" />
                        </motion.div>
                      </Button>
                    </CollapsibleTrigger>

                    {/* Expanded Content */}
                    <CollapsibleContent className="mt-4 space-y-4 pb-4 border-t border-gray-700/50 pt-4">
                      {/* Stats Grid */}
                      <div className="grid grid-cols-3 gap-3">
                        <div className="bg-gray-800/50 rounded-lg p-3 text-center">
                          <div className="text-xs text-gray-400 mb-1">Grille</div>
                          <div className="text-sm font-semibold text-emerald-400">
                            {pattern.grid_width}×{pattern.grid_height}
                          </div>
                        </div>
                        <div className="bg-gray-800/50 rounded-lg p-3 text-center">
                          <div className="text-xs text-gray-400 mb-1">Couleurs</div>
                          <div className="text-sm font-semibold text-emerald-400">{colorCount}</div>
                        </div>
                        <div className="bg-gray-800/50 rounded-lg p-3 text-center">
                          <div className="text-xs text-gray-400 mb-1">Difficulté</div>
                          <Badge variant="secondary" className="text-xs">
                            {pattern.difficulty}
                          </Badge>
                        </div>
                      </div>

                      {/* Palette Preview */}
                      {pattern.dmc_palette?.length > 0 && (
                        <div>
                          <p className="text-xs text-gray-400 mb-2">Palette DMC</p>
                          <div className="flex gap-2 flex-wrap">
                            {pattern.dmc_palette.map(p => (
                              <div
                                key={p.dmc_code}
                                className="flex items-center gap-1 px-2 py-1 rounded bg-gray-800/50 border border-gray-700"
                                title={p.name}
                              >
                                <div
                                  className="w-3 h-3 rounded-full border border-white/20"
                                  style={{ backgroundColor: p.color }}
                                />
                                <span className="text-xs text-gray-300">{p.dmc_code}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Description */}
                      {pattern.description && (
                        <div>
                          <p className="text-xs text-gray-400 mb-1">Description</p>
                          <p className="text-sm text-gray-300">{pattern.description}</p>
                        </div>
                      )}
                    </CollapsibleContent>
                  </Collapsible>

                  <Button
                    onClick={() => onStartAR(pattern)}
                    className="bg-emerald-500 hover:bg-emerald-600 text-white whitespace-nowrap"
                    size="sm"
                  >
                    <Play className="w-4 h-4 mr-2" />
                    Lancer AR
                  </Button>

                  <Button
                    onClick={onClose}
                    variant="ghost"
                    size="icon"
                    className="text-gray-400 hover:text-red-400 hover:bg-red-500/10"
                  >
                    <X className="w-5 h-5" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}