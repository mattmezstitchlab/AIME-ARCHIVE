import React, { useRef, useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { AlertCircle, RotateCcw } from 'lucide-react';
import { speakKey } from './voiceEngine';

export default function ARFallbackView({
  capturedImage,
  pattern,
  calibrationPoints,
  onRetryAR,
  onChangePattern
}) {
  const canvasRef = useRef(null);
  const [gridOverlay, setGridOverlay] = useState(false);

  useEffect(() => {
    if (!canvasRef.current || !capturedImage) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const img = new Image();

    img.onload = () => {
      canvas.width = img.width;
      canvas.height = img.height;
      ctx.drawImage(img, 0, 0);

      // Draw grid overlay if enabled
      if (gridOverlay && pattern) {
        const cellWidth = canvas.width / pattern.grid_width;
        const cellHeight = canvas.height / pattern.grid_height;

        ctx.strokeStyle = 'rgba(52, 211, 153, 0.3)';
        ctx.lineWidth = 1;

        // Vertical lines
        for (let x = 0; x <= pattern.grid_width; x++) {
          ctx.beginPath();
          ctx.moveTo(x * cellWidth, 0);
          ctx.lineTo(x * cellWidth, canvas.height);
          ctx.stroke();
        }

        // Horizontal lines
        for (let y = 0; y <= pattern.grid_height; y++) {
          ctx.beginPath();
          ctx.moveTo(0, y * cellHeight);
          ctx.lineTo(canvas.width, y * cellHeight);
          ctx.stroke();
        }

        // Draw calibration points if available
        if (calibrationPoints && calibrationPoints.length > 0) {
          ctx.fillStyle = 'rgba(52, 211, 153, 0.6)';
          calibrationPoints.forEach((point, idx) => {
            ctx.beginPath();
            ctx.arc(point.x, point.y, 8, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = 'white';
            ctx.font = '12px sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(idx + 1, point.x, point.y);
            ctx.fillStyle = 'rgba(52, 211, 153, 0.6)';
          });
        }
      }
    };

    img.src = capturedImage;
  }, [capturedImage, gridOverlay, pattern, calibrationPoints]);

  return (
    <div className="fixed inset-0 bg-black z-50 flex flex-col">
      {/* Header */}
      <div className="bg-gradient-to-b from-black/50 to-transparent px-4 py-4 flex items-center gap-2">
        <AlertCircle className="w-5 h-5 text-amber-400" />
        <p className="text-sm text-gray-300">Mode aperçu (AR non disponible)</p>
      </div>

      {/* Canvas area */}
      <div className="flex-1 flex items-center justify-center overflow-auto p-4">
        <canvas
          ref={canvasRef}
          className="max-w-full max-h-full rounded-lg border border-gray-700/50"
        />
      </div>

      {/* Controls */}
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="bg-gradient-to-t from-black via-black/80 to-transparent px-4 py-6 space-y-4"
      >
        {/* Toggle grid */}
        <label className="flex items-center gap-3 cursor-pointer">
          <input
            type="checkbox"
            checked={gridOverlay}
            onChange={(e) => setGridOverlay(e.target.checked)}
            className="w-4 h-4 rounded cursor-pointer"
          />
          <span className="text-sm text-gray-300">Afficher la grille</span>
        </label>

        {/* Actions */}
        <div className="flex gap-3">
          <button
            onClick={() => {
              speakKey('retry_ar', 'Nouvelle tentative AR.', { cooldownMs: 30000 });
              onRetryAR();
            }}
            className="flex-1 py-3 px-4 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white text-sm font-medium transition flex items-center justify-center gap-2"
          >
            <RotateCcw className="w-4 h-4" />
            Réessayer AR
          </button>
          <button
            onClick={onChangePattern}
            className="flex-1 py-3 px-4 rounded-lg bg-white/10 hover:bg-white/20 text-white text-sm font-medium transition"
          >
            Retour motifs
          </button>
        </div>

        <p className="text-xs text-gray-500 text-center">
          WebXR non disponible sur cet appareil. Continuez en aperçu ou changez de navigateur/appareil.
        </p>
      </motion.div>
    </div>
  );
}