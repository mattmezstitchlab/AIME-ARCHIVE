import React from 'react';
import { motion } from 'framer-motion';
import { RotateCw, Lock, RefreshCw } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";

export default function GridControls({
  opacity = 0.6,
  onOpacityChange,
  scale = 1,
  onScaleChange,
  rotation = 0,
  onRotationChange,
  isGridLocked = false,
  onToggleLock,
  onResetAlignment
}) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="space-y-3"
    >
      {/* Opacity */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <Label className="text-xs text-gray-400">Opacité</Label>
          <span className="text-xs text-gray-500">{Math.round(opacity * 100)}%</span>
        </div>
        <Slider
          value={[opacity]}
          onValueChange={(v) => onOpacityChange(v[0])}
          min={0.1}
          max={1}
          step={0.05}
          className="w-full"
        />
      </div>

      {/* Scale */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <Label className="text-xs text-gray-400">Échelle</Label>
          <span className="text-xs text-gray-500">{scale.toFixed(2)}x</span>
        </div>
        <Slider
          value={[scale]}
          onValueChange={(v) => onScaleChange(v[0])}
          min={0.5}
          max={2}
          step={0.1}
          className="w-full"
        />
      </div>

      {/* Rotation */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <Label className="text-xs text-gray-400">Rotation</Label>
          <span className="text-xs text-gray-500">{rotation}°</span>
        </div>
        <div className="flex gap-1">
          <Button
            onClick={() => onRotationChange((rotation - 5) % 360)}
            variant="outline"
            size="sm"
            className="flex-1 border-gray-700 h-8 text-xs"
          >
            -5°
          </Button>
          <Slider
            value={[rotation]}
            onValueChange={(v) => onRotationChange(v[0])}
            min={0}
            max={360}
            step={1}
            className="flex-1"
          />
          <Button
            onClick={() => onRotationChange((rotation + 5) % 360)}
            variant="outline"
            size="sm"
            className="flex-1 border-gray-700 h-8 text-xs"
          >
            +5°
          </Button>
        </div>
      </div>

      {/* Lock & Reset */}
      <div className="flex gap-2">
        <Button
          onClick={onToggleLock}
          variant={isGridLocked ? 'default' : 'outline'}
          size="sm"
          className={`flex-1 text-xs ${isGridLocked ? 'bg-emerald-500 hover:bg-emerald-600' : 'border-gray-700'}`}
        >
          <Lock className="w-3 h-3 mr-1" />
          {isGridLocked ? 'Verrouillé' : 'Verrouiller'}
        </Button>
        <Button
          onClick={onResetAlignment}
          variant="outline"
          size="sm"
          className="flex-1 border-gray-700 text-xs"
        >
          <RefreshCw className="w-3 h-3 mr-1" />
          Réinitialiser
        </Button>
      </div>
    </motion.div>
  );
}