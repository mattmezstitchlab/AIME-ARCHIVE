import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Share2, Facebook, Twitter, Link2, Download, X, CheckCircle2 } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import html2canvas from 'html2canvas';

export default function ShareModal({ session, pattern, onClose }) {
  const [isGenerating, setIsGenerating] = useState(false);

  const shareText = `Je viens de terminer "${session.pattern_title}" ! ${session.points_completed?.length || 0} points brodés en ${Math.round(session.session_duration_minutes || 0)} minutes 🧵✨`;

  const handleShareTwitter = () => {
    const url = `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}`;
    window.open(url, '_blank');
  };

  const handleShareFacebook = () => {
    const url = `https://www.facebook.com/sharer/sharer.php?quote=${encodeURIComponent(shareText)}`;
    window.open(url, '_blank');
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareText);
    toast.success('Texte copié !');
  };

  const handleDownloadStats = async () => {
    setIsGenerating(true);
    try {
      const statsElement = document.getElementById('session-stats-card');
      if (!statsElement) return;

      const canvas = await html2canvas(statsElement, {
        backgroundColor: '#111827',
        scale: 2
      });

      const link = document.createElement('a');
      link.download = `broderie-${session.pattern_title}-stats.png`;
      link.href = canvas.toDataURL();
      link.click();

      toast.success('Image téléchargée !');
    } catch (error) {
      toast.error('Erreur lors de la génération');
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] bg-black/80 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.9, y: 20 }}
        onClick={(e) => e.stopPropagation()}
        className="max-w-lg w-full"
      >
        <Card className="bg-gray-900 border-gray-700">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-white flex items-center gap-2">
              <Share2 className="w-5 h-5 text-emerald-400" />
              Partager ma réussite
            </CardTitle>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Stats Card Preview */}
            <div id="session-stats-card" className="bg-gradient-to-br from-emerald-600 to-teal-700 rounded-xl p-6 text-white">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-bold text-lg">Pattern terminé !</h3>
                  <p className="text-emerald-100 text-sm">{session.pattern_title}</p>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div className="bg-white/10 rounded-lg p-3 backdrop-blur-sm">
                  <p className="text-emerald-100 text-xs">Points</p>
                  <p className="font-bold text-xl">{session.points_completed?.length || 0}</p>
                </div>
                <div className="bg-white/10 rounded-lg p-3 backdrop-blur-sm">
                  <p className="text-emerald-100 text-xs">Temps</p>
                  <p className="font-bold text-xl">{Math.round(session.session_duration_minutes || 0)}m</p>
                </div>
                <div className="bg-white/10 rounded-lg p-3 backdrop-blur-sm">
                  <p className="text-emerald-100 text-xs">Vitesse</p>
                  <p className="font-bold text-xl">{session.stitches_per_minute?.toFixed(1) || '0'}</p>
                </div>
              </div>
            </div>

            {/* Share Options */}
            <div className="space-y-2">
              <Button
                onClick={handleDownloadStats}
                disabled={isGenerating}
                className="w-full bg-emerald-500 hover:bg-emerald-600"
              >
                <Download className="w-4 h-4 mr-2" />
                {isGenerating ? 'Génération...' : 'Télécharger l\'image'}
              </Button>

              <div className="grid grid-cols-3 gap-2">
                <Button
                  onClick={handleShareTwitter}
                  variant="outline"
                  className="border-gray-700"
                >
                  <Twitter className="w-4 h-4" />
                </Button>
                <Button
                  onClick={handleShareFacebook}
                  variant="outline"
                  className="border-gray-700"
                >
                  <Facebook className="w-4 h-4" />
                </Button>
                <Button
                  onClick={handleCopyLink}
                  variant="outline"
                  className="border-gray-700"
                >
                  <Link2 className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  );
}