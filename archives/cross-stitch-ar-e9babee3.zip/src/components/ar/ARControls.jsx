import React from 'react';
import { motion } from 'framer-motion';
import { 
  Eye, EyeOff, Grid3X3, Navigation, Check, Undo2, 
  ZoomIn, ZoomOut, Settings, Crosshair, ArrowUp, Target
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

export default function ARControls({
  opacity,
  onOpacityChange,
  showGrid,
  onToggleGrid,
  showGuide,
  onToggleGuide,
  showSymbols,
  onToggleSymbols,
  progress = { completed: 0, total: 0 },
  sessionTime = 0,
  onValidatePoint,
  onUndoPoint,
  canUndo = false,
  isCalibrating = false,
  onStartCalibration,
  arrowSize = 1,
  onArrowSizeChange,
  highlightSize = 1,
  onHighlightSizeChange
}) {
  const percentage = progress.total > 0 
    ? Math.round((progress.completed / progress.total) * 100) 
    : 0;

  const formatTime = (minutes) => {
    const hrs = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return hrs > 0 ? `${hrs}h ${mins}m` : `${mins}m`;
  };

  return (
    <>
      {/* Top Stats Bar */}
      <motion.div
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="absolute top-16 left-4 right-4 z-20"
      >
        <div className="bg-gray-900/80 backdrop-blur-lg rounded-2xl p-4 border border-gray-700">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="border-emerald-500 text-emerald-400">
                {progress.completed}/{progress.total} points
              </Badge>
              <Badge variant="secondary" className="bg-gray-800 text-gray-300">
                {formatTime(sessionTime)}
              </Badge>
            </div>
            <span className="text-2xl font-bold text-white">{percentage}%</span>
          </div>
          <Progress value={percentage} className="h-2 bg-gray-700" />
        </div>
      </motion.div>

      {/* Left Side Controls */}
      <motion.div
        initial={{ x: -50, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        className="absolute left-4 top-1/2 -translate-y-1/2 z-20 space-y-2"
      >
        <div className="bg-gray-900/80 backdrop-blur-lg rounded-2xl p-2 border border-gray-700 space-y-1">
          <Button
            variant="ghost"
            size="icon"
            onClick={onToggleGrid}
            className={`w-10 h-10 rounded-xl ${showGrid ? 'bg-emerald-500/20 text-emerald-400' : 'text-gray-400 hover:text-white'}`}
          >
            <Grid3X3 className="w-5 h-5" />
          </Button>
          
          <Button
            variant="ghost"
            size="icon"
            onClick={onToggleGuide}
            className={`w-10 h-10 rounded-xl ${showGuide ? 'bg-emerald-500/20 text-emerald-400' : 'text-gray-400 hover:text-white'}`}
          >
            <Navigation className="w-5 h-5" />
          </Button>
          
          <Button
            variant="ghost"
            size="icon"
            onClick={onToggleSymbols}
            className={`w-10 h-10 rounded-xl ${showSymbols ? 'bg-emerald-500/20 text-emerald-400' : 'text-gray-400 hover:text-white'}`}
          >
            {showSymbols ? <Eye className="w-5 h-5" /> : <EyeOff className="w-5 h-5" />}
          </Button>

          <Button
            variant="ghost"
            size="icon"
            onClick={onStartCalibration}
            className={`w-10 h-10 rounded-xl ${isCalibrating ? 'bg-amber-500/20 text-amber-400' : 'text-gray-400 hover:text-white'}`}
          >
            <Crosshair className="w-5 h-5" />
          </Button>
        </div>

        {/* Opacity Slider */}
        <div className="bg-gray-900/80 backdrop-blur-lg rounded-2xl p-3 border border-gray-700">
          <div className="flex items-center gap-2 mb-2">
            <Eye className="w-4 h-4 text-gray-400" />
            <span className="text-xs text-gray-400">{Math.round(opacity * 100)}%</span>
          </div>
          <div className="h-32">
            <Slider
              orientation="vertical"
              value={[opacity * 100]}
              onValueChange={([v]) => onOpacityChange(v / 100)}
              max={100}
              min={10}
              step={5}
              className="h-full"
            />
          </div>
        </div>

        {/* Arrow Size Slider */}
        <div className="bg-gray-900/80 backdrop-blur-lg rounded-2xl p-3 border border-gray-700">
          <div className="flex items-center gap-2 mb-2">
            <ArrowUp className="w-4 h-4 text-emerald-400" />
            <span className="text-xs text-gray-400">{arrowSize.toFixed(1)}x</span>
          </div>
          <div className="h-32">
            <Slider
              orientation="vertical"
              value={[arrowSize * 10]}
              onValueChange={([v]) => onArrowSizeChange(v / 10)}
              max={20}
              min={5}
              step={1}
              className="h-full"
            />
          </div>
        </div>

        {/* Highlight Size Slider */}
        <div className="bg-gray-900/80 backdrop-blur-lg rounded-2xl p-3 border border-gray-700">
          <div className="flex items-center gap-2 mb-2">
            <Target className="w-4 h-4 text-emerald-400" />
            <span className="text-xs text-gray-400">{highlightSize.toFixed(1)}x</span>
          </div>
          <div className="h-32">
            <Slider
              orientation="vertical"
              value={[highlightSize * 10]}
              onValueChange={([v]) => onHighlightSizeChange(v / 10)}
              max={20}
              min={5}
              step={1}
              className="h-full"
            />
          </div>
        </div>
      </motion.div>

      {/* Bottom Action Buttons */}
      <motion.div
        initial={{ y: 50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="absolute bottom-32 left-1/2 -translate-x-1/2 z-20 flex items-center gap-3"
      >
        <Button
          variant="outline"
          size="icon"
          onClick={onUndoPoint}
          disabled={!canUndo}
          className="w-14 h-14 rounded-full bg-gray-900/80 border-gray-700 disabled:opacity-30"
        >
          <Undo2 className="w-6 h-6" />
        </Button>

        <motion.div
          whileTap={{ scale: 0.95 }}
        >
          <Button
            onClick={onValidatePoint}
            className="w-20 h-20 rounded-full bg-emerald-500 hover:bg-emerald-600 shadow-lg shadow-emerald-500/30"
          >
            <Check className="w-10 h-10" />
          </Button>
        </motion.div>

        <div className="w-14 h-14" /> {/* Spacer for symmetry */}
      </motion.div>
    </>
  );
}