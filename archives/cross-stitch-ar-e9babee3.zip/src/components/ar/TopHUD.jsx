import React from 'react';
import { motion } from 'framer-motion';
import { Focus, Eye } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";

export default function TopHUD({
  progress = 0,
  focusMode = false,
  onToggleFocus,
  sessionTime = 0,
  isCalibrating = false
}) {
  const minutes = Math.floor(sessionTime / 60);
  const seconds = Math.floor(sessionTime % 60);

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      className="fixed top-0 left-0 right-0 z-40 bg-gradient-to-b from-black/60 to-transparent pt-safe px-4 py-3"
    >
      <div className="max-w-6xl mx-auto">
        {!focusMode ? (
          <div className="space-y-2">
            {/* Header row */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="text-xs font-semibold text-gray-300 uppercase tracking-wider">
                  SmartStitch
                </div>
                {!isCalibrating && (
                  <div className="text-xs text-emerald-400">
                    {progress}% • {minutes}:{seconds.toString().padStart(2, '0')}
                  </div>
                )}
              </div>
              <Button
                onClick={onToggleFocus}
                variant="ghost"
                size="icon"
                className="text-gray-400 hover:text-white w-8 h-8"
              >
                <Focus className="w-4 h-4" />
              </Button>
            </div>

            {/* Progress bar */}
            {!isCalibrating && (
              <div className="h-1 bg-gray-800/50 rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-gradient-to-r from-emerald-500 to-teal-400"
                  initial={{ width: 0 }}
                  animate={{ width: `${progress}%` }}
                  transition={{ duration: 0.3 }}
                />
              </div>
            )}
          </div>
        ) : (
          <div className="flex items-center justify-between">
            <div className="text-xs text-gray-400">
              {progress}% • {minutes}:{seconds.toString().padStart(2, '0')}
            </div>
            <Button
              onClick={onToggleFocus}
              variant="ghost"
              size="icon"
              className="text-emerald-400 hover:text-emerald-300 w-8 h-8"
            >
              <Eye className="w-4 h-4" />
            </Button>
          </div>
        )}
      </div>
    </motion.div>
  );
}