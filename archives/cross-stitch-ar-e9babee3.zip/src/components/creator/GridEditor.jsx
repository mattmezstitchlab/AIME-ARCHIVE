import React, { useRef, useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { ZoomIn, ZoomOut, Eraser, Paintbrush } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";

export default function GridEditor({ 
  width, 
  height, 
  gridData = {}, 
  currentColor,
  onGridDataChange,
  isErasing = false
}) {
  const canvasRef = useRef(null);
  const [zoom, setZoom] = useState(1);
  const [isPainting, setIsPainting] = useState(false);

  const cellSize = 30 * zoom;

  useEffect(() => {
    drawGrid();
  }, [width, height, gridData, zoom, currentColor]);

  const drawGrid = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    canvas.width = width * cellSize;
    canvas.height = height * cellSize;

    // Clear canvas
    ctx.fillStyle = '#1F2937';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Draw cells
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const key = `${x}-${y}`;
        const cell = gridData[key];

        // Draw cell background
        if (cell) {
          ctx.fillStyle = cell.color;
          ctx.fillRect(x * cellSize, y * cellSize, cellSize, cellSize);

          // Draw symbol
          ctx.fillStyle = '#FFFFFF';
          ctx.font = `bold ${cellSize * 0.5}px Arial`;
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(
            cell.symbol, 
            x * cellSize + cellSize / 2, 
            y * cellSize + cellSize / 2
          );
        }

        // Draw grid lines
        ctx.strokeStyle = '#374151';
        ctx.lineWidth = 1;
        ctx.strokeRect(x * cellSize, y * cellSize, cellSize, cellSize);
      }
    }
  };

  const handleCanvasInteraction = (e) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = Math.floor((e.clientX - rect.left) / cellSize);
    const y = Math.floor((e.clientY - rect.top) / cellSize);

    if (x >= 0 && x < width && y >= 0 && y < height) {
      const key = `${x}-${y}`;
      const newGridData = { ...gridData };

      if (isErasing) {
        delete newGridData[key];
      } else if (currentColor) {
        newGridData[key] = {
          dmc: currentColor.dmc_code,
          symbol: currentColor.symbol,
          color: currentColor.color
        };
      }

      onGridDataChange(newGridData);
    }
  };

  const handleMouseDown = (e) => {
    setIsPainting(true);
    handleCanvasInteraction(e);
  };

  const handleMouseMove = (e) => {
    if (isPainting) {
      handleCanvasInteraction(e);
    }
  };

  const handleMouseUp = () => {
    setIsPainting(false);
  };

  return (
    <div className="space-y-4">
      {/* Zoom controls */}
      <div className="flex items-center gap-4 bg-gray-800/50 rounded-xl p-3">
        <ZoomOut className="w-4 h-4 text-gray-400" />
        <Slider
          value={[zoom * 100]}
          onValueChange={([v]) => setZoom(v / 100)}
          min={50}
          max={200}
          step={10}
          className="flex-1"
        />
        <ZoomIn className="w-4 h-4 text-gray-400" />
        <span className="text-sm text-gray-400 w-12">{Math.round(zoom * 100)}%</span>
      </div>

      {/* Canvas */}
      <div className="relative overflow-auto bg-gray-900 rounded-xl border border-gray-700 p-4" style={{ maxHeight: '60vh' }}>
        <canvas
          ref={canvasRef}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
          className="cursor-crosshair"
          style={{ imageRendering: 'pixelated' }}
        />
      </div>

      {/* Info */}
      <div className="text-sm text-gray-400 text-center">
        {isErasing ? (
          <span className="flex items-center justify-center gap-2">
            <Eraser className="w-4 h-4" />
            Mode gomme - Cliquez pour effacer
          </span>
        ) : currentColor ? (
          <span className="flex items-center justify-center gap-2">
            <Paintbrush className="w-4 h-4" />
            Dessinez avec DMC {currentColor.dmc_code}
          </span>
        ) : (
          <span>Sélectionnez une couleur pour commencer</span>
        )}
      </div>
    </div>
  );
}