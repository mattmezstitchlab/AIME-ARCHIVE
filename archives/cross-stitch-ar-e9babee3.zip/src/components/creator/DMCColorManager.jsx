import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Trash2, Check } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const COMMON_SYMBOLS = ['●', '■', '▲', '★', '◆', '♥', '✖', '▼', '◀', '▶', '✚'];

export default function DMCColorManager({ 
  palette = [], 
  onPaletteChange,
  selectedColor,
  onColorSelect 
}) {
  const [showAddForm, setShowAddForm] = useState(false);
  const [newColor, setNewColor] = useState({
    dmc_code: '',
    color: '#000000',
    symbol: '●',
    name: ''
  });

  const handleAddColor = () => {
    if (!newColor.dmc_code || !newColor.symbol) return;

    onPaletteChange([...palette, newColor]);
    setNewColor({ dmc_code: '', color: '#000000', symbol: '●', name: '' });
    setShowAddForm(false);
  };

  const handleRemoveColor = (dmcCode) => {
    onPaletteChange(palette.filter(c => c.dmc_code !== dmcCode));
    if (selectedColor?.dmc_code === dmcCode) {
      onColorSelect(null);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-white">Palette DMC</h3>
        <Button
          onClick={() => setShowAddForm(!showAddForm)}
          size="sm"
          variant={showAddForm ? "outline" : "default"}
          className={!showAddForm ? "bg-emerald-500 hover:bg-emerald-600" : ""}
        >
          <Plus className="w-4 h-4 mr-2" />
          Ajouter couleur
        </Button>
      </div>

      {/* Add color form */}
      <AnimatePresence>
        {showAddForm && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
          >
            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-4 space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label className="text-gray-300">Code DMC</Label>
                    <Input
                      value={newColor.dmc_code}
                      onChange={(e) => setNewColor({ ...newColor, dmc_code: e.target.value })}
                      placeholder="310"
                      className="bg-gray-900 border-gray-700 text-white"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">Nom (optionnel)</Label>
                    <Input
                      value={newColor.name}
                      onChange={(e) => setNewColor({ ...newColor, name: e.target.value })}
                      placeholder="Noir"
                      className="bg-gray-900 border-gray-700 text-white"
                    />
                  </div>
                </div>

                <div>
                  <Label className="text-gray-300">Couleur</Label>
                  <div className="flex items-center gap-3">
                    <input
                      type="color"
                      value={newColor.color}
                      onChange={(e) => setNewColor({ ...newColor, color: e.target.value })}
                      className="w-20 h-10 rounded cursor-pointer"
                    />
                    <Input
                      value={newColor.color}
                      onChange={(e) => setNewColor({ ...newColor, color: e.target.value })}
                      className="bg-gray-900 border-gray-700 text-white flex-1"
                    />
                  </div>
                </div>

                <div>
                  <Label className="text-gray-300 mb-2 block">Symbole</Label>
                  <div className="flex flex-wrap gap-2">
                    {COMMON_SYMBOLS.map(symbol => (
                      <Button
                        key={symbol}
                        variant={newColor.symbol === symbol ? "default" : "outline"}
                        size="sm"
                        onClick={() => setNewColor({ ...newColor, symbol })}
                        className={newColor.symbol === symbol ? "bg-emerald-500" : "border-gray-700"}
                      >
                        {symbol}
                      </Button>
                    ))}
                  </div>
                </div>

                <Button
                  onClick={handleAddColor}
                  className="w-full bg-emerald-500 hover:bg-emerald-600"
                  disabled={!newColor.dmc_code || !newColor.symbol}
                >
                  <Check className="w-4 h-4 mr-2" />
                  Ajouter à la palette
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Color list */}
      <div className="space-y-2 max-h-80 overflow-y-auto">
        {palette.length === 0 ? (
          <Card className="bg-gray-800/30 border-gray-700 border-dashed">
            <CardContent className="p-8 text-center">
              <p className="text-gray-400">Ajoutez des couleurs DMC à votre palette</p>
            </CardContent>
          </Card>
        ) : (
          palette.map((color) => (
            <motion.div
              key={color.dmc_code}
              whileTap={{ scale: 0.98 }}
              onClick={() => onColorSelect(color)}
              className={`
                flex items-center gap-3 p-3 rounded-xl cursor-pointer transition-all
                ${selectedColor?.dmc_code === color.dmc_code
                  ? 'bg-emerald-500/20 border-2 border-emerald-500'
                  : 'bg-gray-800 border-2 border-transparent hover:border-gray-700'}
              `}
            >
              <div
                className="w-12 h-12 rounded-lg flex items-center justify-center text-white text-xl font-bold shadow-lg"
                style={{ backgroundColor: color.color }}
              >
                {color.symbol}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-white font-mono font-bold">DMC {color.dmc_code}</span>
                  {color.name && (
                    <span className="text-gray-400 text-sm truncate">{color.name}</span>
                  )}
                </div>
                <div className="text-xs text-gray-500 font-mono">{color.color}</div>
              </div>

              {selectedColor?.dmc_code === color.dmc_code && (
                <Badge className="bg-emerald-500">Sélectionné</Badge>
              )}

              <Button
                variant="ghost"
                size="icon"
                onClick={(e) => {
                  e.stopPropagation();
                  handleRemoveColor(color.dmc_code);
                }}
                className="text-gray-400 hover:text-red-400"
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </motion.div>
          ))
        )}
      </div>
    </div>
  );
}