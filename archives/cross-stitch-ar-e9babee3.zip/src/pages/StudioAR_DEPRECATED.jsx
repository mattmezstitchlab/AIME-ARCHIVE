import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

// ⚠️ DEPRECATED: StudioAR has been merged into ARViewer
export default function StudioARDeprecated() {
  const navigate = useNavigate();
  useEffect(() => {
    navigate(createPageUrl('ARViewer'));
  }, [navigate]);
  return null;
}