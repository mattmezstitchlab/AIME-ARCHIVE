import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { createPageUrl } from '@/utils';
import { motion, AnimatePresence } from 'framer-motion';
import { Clock, History, Sparkles, Check } from 'lucide-react';
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PatternActionToolbar from '@/components/ar/PatternActionToolbar';
import StudioHeader from '@/components/studio/StudioHeader';
import SessionCard from '@/components/studio/SessionCard';
import PatternCard from '@/components/studio/PatternCard';
import StudioGuides from '@/components/studio/StudioGuides';
import StudioTools from '@/components/studio/StudioTools';
import PatternSearchBar from '@/components/studio/PatternSearchBar';
import PatternFilters from '@/components/studio/PatternFilters';

export default function StudioAR() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const [selectedPattern, setSelectedPattern] = useState(null);
  const [showOnlyOwnedThreads, setShowOnlyOwnedThreads] = useState(false);
  const [sessionTab, setSessionTab] = useState('active');
  const [searchTerm, setSearchTerm] = useState('');
  const [filters, setFilters] = useState({ difficulty: [], size: [], tags: [] });

  // Fetch all data
  const { data: patterns = [], isLoading: patternsLoading } = useQuery({
    queryKey: ['patterns'],
    queryFn: () => base44.entities.Pattern.list()
  });

  const { data: userDMCCollection = [] } = useQuery({
    queryKey: ['user-dmc-collection'],
    queryFn: () => base44.entities.UserDMCCollection.list()
  });

  const { data: sessions = [], refetch: refetchSessions } = useQuery({
    queryKey: ['sessions'],
    queryFn: () => base44.entities.ARSession.list('-updated_date')
  });

  const deleteSessionMutation = useMutation({
    mutationFn: (id) => base44.entities.ARSession.delete(id),
    onSuccess: () => refetchSessions()
  });

  // Filter patterns with all criteria
  const filteredPatterns = patterns.filter(pattern => {
    // Owned threads filter
    if (showOnlyOwnedThreads) {
      const ownedDMCCodes = userDMCCollection.filter(c => c.status === 'owned').map(c => c.dmc_code);
      const patternDMCCodes = pattern.dmc_palette?.map(p => p.dmc_code) || [];
      if (!patternDMCCodes.every(code => ownedDMCCodes.includes(code))) return false;
    }

    // Search filter
    if (searchTerm && !pattern.title?.toLowerCase().includes(searchTerm.toLowerCase())) {
      return false;
    }

    // Difficulty filter
    if (filters.difficulty.length > 0 && !filters.difficulty.includes(pattern.difficulty)) {
      return false;
    }

    // Size filter - based on grid dimensions
    if (filters.size.length > 0) {
      const gridSize = (pattern.grid_width * pattern.grid_height);
      const size = gridSize < 1000 ? 'petit' : gridSize < 5000 ? 'moyen' : 'grand';
      if (!filters.size.includes(size)) return false;
    }

    return true;
  });

  // Filter sessions
  const filteredSessions = sessions.filter(session => {
    if (sessionTab === 'active') return !session.is_completed && !session.is_archived;
    if (sessionTab === 'completed') return session.is_completed;
    if (sessionTab === 'archived') return session.is_archived;
    return true;
  });

  const stats = {
    active: sessions.filter(s => !s.is_completed && !s.is_archived).length,
    completed: sessions.filter(s => s.is_completed).length,
    archived: sessions.filter(s => s.is_archived).length
  };

  const getPatternSession = (patternId) => sessions.find(s => s.pattern_id === patternId && !s.is_completed);

  const handleStartAR = (pattern, existingSession = null) => {
    const params = new URLSearchParams({ patternId: pattern.id });
    if (existingSession) params.append('sessionId', existingSession.id);
    navigate(createPageUrl(`ARViewer?${params.toString()}`));
  };

  const handleToolClick = (action) => {
    switch (action) {
      case 'create':
        navigate(createPageUrl('PatternCreator'));
        break;
      case 'import':
        navigate(createPageUrl('PatternGallery'));
        break;
      case 'threads':
        navigate(createPageUrl('DMCLibrary'));
        break;
      case 'community':
        navigate(createPageUrl('Community'));
        break;
      default:
        break;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-950 via-black to-gray-950">
      <StudioHeader onNavigate={(page) => navigate(createPageUrl(page))} />

      <div className="max-w-7xl mx-auto px-8 pt-24 pb-32 space-y-16">
        {/* Studio Tools & Guides */}
        <section className="space-y-12">
          <StudioTools onToolClick={handleToolClick} />
          <StudioGuides />
        </section>

        {/* Sessions Section */}
        {sessions.length > 0 && (
          <section className="space-y-8">
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-4"
            >
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <h2 className="text-3xl font-light tracking-tight text-white flex items-center gap-3">
                    <History className="w-6 h-6 text-emerald-400" />
                    Mes Sessions
                  </h2>
                  <p className="text-sm text-gray-500">{stats.active} en cours • {stats.completed} terminées</p>
                </div>
              </div>

              <Tabs value={sessionTab} onValueChange={setSessionTab}>
                <TabsList className="bg-gray-800/50 border border-gray-800">
                  <TabsTrigger value="active">En cours ({stats.active})</TabsTrigger>
                  <TabsTrigger value="completed">Terminées ({stats.completed})</TabsTrigger>
                  <TabsTrigger value="archived">Archivées ({stats.archived})</TabsTrigger>
                </TabsList>
              </Tabs>
            </motion.div>

            {filteredSessions.length === 0 ? (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center py-16 text-gray-400"
              >
                <p className="text-sm">Aucune session dans cette catégorie</p>
              </motion.div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <AnimatePresence>
                  {filteredSessions.map((session) => {
                    const pattern = patterns.find(p => p.id === session.pattern_id);
                    if (!pattern) return null;

                    return (
                      <SessionCard
                        key={session.id}
                        session={session}
                        pattern={pattern}
                        onPlay={(s) => handleStartAR(pattern, s)}
                        onDelete={(id) => deleteSessionMutation.mutate(id)}
                      />
                    );
                  })}
                </AnimatePresence>
              </div>
            )}
          </section>
        )}

        {/* Patterns Library */}
        <section className="space-y-8">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-4"
          >
            <h2 className="text-3xl font-light tracking-tight text-white">Bibliothèque</h2>

            {/* Search & Filters */}
            <div className="space-y-3">
              <PatternSearchBar 
                value={searchTerm}
                onChange={setSearchTerm}
                onClear={() => setSearchTerm('')}
              />
              <div className="flex flex-wrap items-center gap-3">
                <PatternFilters onFiltersChange={setFilters} />
                <button
                  onClick={() => setShowOnlyOwnedThreads(!showOnlyOwnedThreads)}
                  className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg border transition-all ${
                    showOnlyOwnedThreads
                      ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-400'
                      : 'bg-gray-800/30 border-gray-700 text-gray-400 hover:border-emerald-500/30'
                  }`}
                >
                  <Check className="w-4 h-4" />
                  <span className="text-sm font-medium">Fils possédés</span>
                </button>
              </div>
            </div>
          </motion.div>

          {patternsLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3].map(i => (
                <div key={i} className="h-64 bg-gray-800/20 rounded-2xl animate-pulse" />
              ))}
            </div>
          ) : patterns.length === 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-20 space-y-4"
            >
              <Sparkles className="w-16 h-16 text-gray-600 mx-auto" />
              <div>
                <h3 className="text-xl font-light text-white mb-1">Aucun pattern créé</h3>
                <p className="text-gray-400">Commencez par créer votre premier pattern</p>
              </div>
            </motion.div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <AnimatePresence>
                {filteredPatterns.map((pattern) => {
                  const existingSession = getPatternSession(pattern.id);
                  const completedSession = sessions.find(s => s.pattern_id === pattern.id && s.is_completed);

                  return (
                    <PatternCard
                      key={pattern.id}
                      pattern={pattern}
                      completedSession={completedSession}
                      progressPercentage={existingSession?.progress_percentage || 0}
                      onSelect={() => setSelectedPattern(pattern)}
                    />
                  );
                })}
              </AnimatePresence>
            </div>
          )}
        </section>

        {/* Selected Pattern Action - New Toolbar */}
        <AnimatePresence>
          {selectedPattern && (
            <PatternActionToolbar 
              pattern={selectedPattern}
              onClose={() => setSelectedPattern(null)}
              onStartAR={(pattern) => handleStartAR(pattern, getPatternSession(pattern.id))}
            />
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}