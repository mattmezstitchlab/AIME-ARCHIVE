import React, { useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { 
  ArrowLeft, TrendingUp, Clock, Target, Palette, 
  Award, Calendar, Zap, Loader2, Trophy
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';

export default function SessionHistory() {
  const navigate = useNavigate();

  const { data: sessions = [], isLoading } = useQuery({
    queryKey: ['all-sessions'],
    queryFn: () => base44.entities.ARSession.list('-updated_date')
  });

  const statistics = useMemo(() => {
    const completedSessions = sessions.filter(s => s.is_completed);
    
    const totalPoints = completedSessions.reduce((sum, s) => sum + (s.points_completed?.length || 0), 0);
    const totalMinutes = completedSessions.reduce((sum, s) => sum + (s.session_duration_minutes || 0), 0);
    const avgSpeed = totalMinutes > 0 ? totalPoints / totalMinutes : 0;

    // Color usage across all sessions
    const colorUsage = {};
    completedSessions.forEach(session => {
      if (session.color_usage) {
        Object.entries(session.color_usage).forEach(([color, count]) => {
          colorUsage[color] = (colorUsage[color] || 0) + count;
        });
      }
    });

    const topColors = Object.entries(colorUsage)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 5);

    // Goals achievement
    const goalsAchieved = completedSessions.filter(s => {
      if (!s.goal_points && !s.goal_minutes) return false;
      const pointsAchieved = !s.goal_points || (s.points_completed?.length || 0) >= s.goal_points;
      const timeAchieved = !s.goal_minutes || (s.session_duration_minutes || 0) <= s.goal_minutes;
      return pointsAchieved && timeAchieved;
    }).length;

    return {
      totalSessions: completedSessions.length,
      totalPoints,
      totalMinutes,
      avgSpeed,
      topColors,
      goalsAchieved,
      sessionsWithGoals: completedSessions.filter(s => s.goal_points || s.goal_minutes).length
    };
  }, [sessions]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950 flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-emerald-500 animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-gray-950/80 backdrop-blur-xl border-b border-gray-800">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate(createPageUrl('ARSessions'))}
              className="text-gray-400 hover:text-white"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-xl font-bold text-white">Historique & Statistiques</h1>
              <p className="text-sm text-gray-400">Vos performances de broderie</p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-6 space-y-6">
        {/* Global Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="bg-gray-800/50 border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Award className="w-4 h-4 text-amber-400" />
                <span className="text-xs text-gray-400">Sessions</span>
              </div>
              <p className="text-2xl font-bold text-white">{statistics.totalSessions}</p>
            </CardContent>
          </Card>

          <Card className="bg-gray-800/50 border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Target className="w-4 h-4 text-emerald-400" />
                <span className="text-xs text-gray-400">Points totaux</span>
              </div>
              <p className="text-2xl font-bold text-white">{statistics.totalPoints}</p>
            </CardContent>
          </Card>

          <Card className="bg-gray-800/50 border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Clock className="w-4 h-4 text-purple-400" />
                <span className="text-xs text-gray-400">Temps total</span>
              </div>
              <p className="text-2xl font-bold text-white">{Math.round(statistics.totalMinutes)}m</p>
            </CardContent>
          </Card>

          <Card className="bg-gray-800/50 border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Zap className="w-4 h-4 text-yellow-400" />
                <span className="text-xs text-gray-400">Vitesse moy.</span>
              </div>
              <p className="text-2xl font-bold text-white">{statistics.avgSpeed.toFixed(1)}<span className="text-sm text-gray-400">/min</span></p>
            </CardContent>
          </Card>
        </div>

        {/* Goals Achievement */}
        {statistics.sessionsWithGoals > 0 && (
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Trophy className="w-5 h-5 text-amber-400" />
                Objectifs atteints
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4">
                <div className="flex-1">
                  <Progress 
                    value={(statistics.goalsAchieved / statistics.sessionsWithGoals) * 100} 
                    className="h-3 bg-gray-700"
                  />
                </div>
                <span className="text-lg font-bold text-white">
                  {statistics.goalsAchieved}/{statistics.sessionsWithGoals}
                </span>
              </div>
              <p className="text-sm text-gray-400 mt-2">
                {Math.round((statistics.goalsAchieved / statistics.sessionsWithGoals) * 100)}% de vos objectifs atteints
              </p>
            </CardContent>
          </Card>
        )}

        {/* Top Colors */}
        {statistics.topColors.length > 0 && (
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Palette className="w-5 h-5 text-purple-400" />
                Couleurs les plus utilisées
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {statistics.topColors.map(([color, count], index) => (
                  <div key={color} className="flex items-center gap-3">
                    <Badge className="bg-gray-700 text-white min-w-[24px] justify-center">
                      {index + 1}
                    </Badge>
                    <div className="w-8 h-8 rounded-lg border-2 border-gray-600" style={{ backgroundColor: color }} />
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm text-white font-mono">DMC {color}</span>
                        <span className="text-sm text-gray-400">{count} points</span>
                      </div>
                      <Progress 
                        value={(count / statistics.topColors[0][1]) * 100} 
                        className="h-1.5 bg-gray-700"
                      />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Recent Sessions */}
        <Card className="bg-gray-800/50 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Calendar className="w-5 h-5 text-teal-400" />
              Sessions récentes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {sessions.filter(s => s.is_completed).slice(0, 10).map((session) => (
                <motion.div
                  key={session.id}
                  whileHover={{ x: 4 }}
                  className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg border border-gray-700"
                >
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-white truncate">{session.pattern_title}</p>
                    <div className="flex items-center gap-3 mt-1 text-xs text-gray-400">
                      <span>{session.points_completed?.length || 0} points</span>
                      <span>•</span>
                      <span>{Math.round(session.session_duration_minutes || 0)} min</span>
                      <span>•</span>
                      <span>{format(new Date(session.updated_date), 'dd MMM', { locale: fr })}</span>
                    </div>
                  </div>
                  {session.stitches_per_minute && (
                    <Badge variant="secondary" className="bg-emerald-500/20 text-emerald-400">
                      {session.stitches_per_minute.toFixed(1)}/min
                    </Badge>
                  )}
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}