import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { createPageUrl } from '@/utils';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ArrowLeft, Save, Pencil, Upload, Eraser, Sparkles,
  Grid3X3, Image as ImageIcon
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { toast } from "sonner";

import GridEditor from '@/components/creator/GridEditor';
import DMCColorManager from '@/components/creator/DMCColorManager';

export default function PatternCreator() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  // Pattern info
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [gridWidth, setGridWidth] = useState(15);
  const [gridHeight, setGridHeight] = useState(15);

  // Drawing state
  const [gridData, setGridData] = useState({});
  const [palette, setPalette] = useState([]);
  const [selectedColor, setSelectedColor] = useState(null);
  const [isErasing, setIsErasing] = useState(false);
  const [mode, setMode] = useState('draw'); // 'draw' or 'image'

  // Image upload
  const [uploadedImage, setUploadedImage] = useState(null);
  const [isUploading, setIsUploading] = useState(false);

  const createPatternMutation = useMutation({
    mutationFn: (data) => base44.entities.Pattern.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['patterns']);
      toast.success('Pattern créé avec succès !');
      navigate(createPageUrl('ARMode'));
    },
    onError: (error) => {
      toast.error('Erreur: ' + error.message);
    }
  });

  const handleImageUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setUploadedImage(file_url);
      toast.success('Image uploadée ! Analyse en cours...');
      
      // Analyze image with AI
      await analyzePatternImage(file_url);
    } catch (error) {
      toast.error('Erreur upload: ' + error.message);
    } finally {
      setIsUploading(false);
    }
  };

  const analyzePatternImage = async (imageUrl) => {
    try {
      const prompt = `Analyze this cross-stitch pattern image and extract the following information:

1. Grid dimensions (width x height in stitches)
2. All distinct colors present in the pattern
3. For each color, provide:
   - A hex color code
   - The closest DMC thread color code (standard DMC numbers like 310, 666, 321, etc.)
   - A suitable symbol (choose from: ●, ■, ▲, ★, ◆, ♥, ✖, ▼, ◀, ▶, ✚)
   - A descriptive name

4. The complete grid data mapping each cell position (x-y format) to its DMC code and symbol

Important:
- Only include cells that contain stitches (skip empty cells)
- Use standard DMC color codes
- Ensure each color has a unique symbol
- Grid coordinates start at 0-0 (top-left)
- Be precise with color detection

Return ONLY valid JSON with no markdown formatting.`;

      const result = await base44.integrations.Core.InvokeLLM({
        prompt,
        file_urls: [imageUrl],
        add_context_from_internet: false,
        response_json_schema: {
          type: "object",
          properties: {
            grid_width: { type: "number" },
            grid_height: { type: "number" },
            dmc_palette: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  dmc_code: { type: "string" },
                  color: { type: "string" },
                  symbol: { type: "string" },
                  name: { type: "string" }
                }
              }
            },
            grid_data: {
              type: "object"
            }
          }
        }
      });

      // Apply the analyzed data
      if (result.grid_width && result.grid_height) {
        setGridWidth(Math.min(50, result.grid_width));
        setGridHeight(Math.min(50, result.grid_height));
      }

      if (result.dmc_palette && Array.isArray(result.dmc_palette)) {
        setPalette(result.dmc_palette);
      }

      if (result.grid_data && typeof result.grid_data === 'object') {
        // Transform grid_data to include color info
        const enrichedGridData = {};
        Object.entries(result.grid_data).forEach(([key, value]) => {
          const colorInfo = result.dmc_palette.find(p => p.dmc_code === value.dmc);
          if (colorInfo) {
            enrichedGridData[key] = {
              dmc: value.dmc,
              symbol: value.symbol || colorInfo.symbol,
              color: colorInfo.color
            };
          }
        });
        setGridData(enrichedGridData);
      }

      toast.success('Pattern analysé avec succès !', {
        description: `${Object.keys(result.grid_data || {}).length} points détectés`
      });
      
      // Switch to draw mode to show result
      setMode('draw');
    } catch (error) {
      toast.error('Erreur analyse IA: ' + error.message);
      console.error('Analysis error:', error);
    }
  };

  const handleSavePattern = async () => {
    if (!title.trim()) {
      toast.error('Veuillez donner un titre au pattern');
      return;
    }

    if (palette.length === 0) {
      toast.error('Ajoutez au moins une couleur DMC');
      return;
    }

    if (Object.keys(gridData).length === 0) {
      toast.error('Votre pattern est vide, dessinez quelque chose !');
      return;
    }

    const patternData = {
      title: title.trim(),
      description: description.trim(),
      grid_width: gridWidth,
      grid_height: gridHeight,
      grid_data: gridData,
      dmc_palette: palette,
      total_stitches: Object.keys(gridData).length,
      difficulty: Object.keys(gridData).length < 50 ? 'debutant' : 
                  Object.keys(gridData).length < 150 ? 'intermediaire' : 'avance'
    };

    await createPatternMutation.mutateAsync(patternData);
  };

  const handleClearGrid = () => {
    if (confirm('Effacer toute la grille ?')) {
      setGridData({});
    }
  };

  const handleDimensionChange = (newWidth, newHeight) => {
    setGridWidth(Math.max(5, Math.min(50, newWidth)));
    setGridHeight(Math.max(5, Math.min(50, newHeight)));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-gray-950/80 backdrop-blur-xl border-b border-gray-800">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => navigate(createPageUrl('ARMode'))}
                className="text-gray-400 hover:text-white"
              >
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div>
                <h1 className="text-xl font-bold text-white">Créer un Pattern</h1>
                <p className="text-sm text-gray-400">Dessinez ou importez votre motif</p>
              </div>
            </div>

            <Button
              onClick={handleSavePattern}
              disabled={createPatternMutation.isPending}
              className="bg-emerald-500 hover:bg-emerald-600"
            >
              <Save className="w-4 h-4 mr-2" />
              Enregistrer
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Panel - Settings */}
          <div className="lg:col-span-1 space-y-6">
            {/* Pattern Info */}
            <Card className="bg-gray-800/50 border-0">
              <CardContent className="p-4 space-y-4">
                <div>
                  <Label className="text-gray-300">Titre du pattern</Label>
                  <Input
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="Mon super pattern"
                    className="bg-gray-900 border-gray-700 text-white"
                  />
                </div>

                <div>
                  <Label className="text-gray-300">Description</Label>
                  <Textarea
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Une belle description..."
                    rows={3}
                    className="bg-gray-900 border-gray-700 text-white"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label className="text-gray-300">Largeur</Label>
                    <Input
                      type="number"
                      value={gridWidth}
                      onChange={(e) => handleDimensionChange(parseInt(e.target.value) || 15, gridHeight)}
                      min={5}
                      max={50}
                      className="bg-gray-900 border-gray-700 text-white"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">Hauteur</Label>
                    <Input
                      type="number"
                      value={gridHeight}
                      onChange={(e) => handleDimensionChange(gridWidth, parseInt(e.target.value) || 15)}
                      min={5}
                      max={50}
                      className="bg-gray-900 border-gray-700 text-white"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-400">Points dessinés:</span>
                  <span className="text-emerald-400 font-bold">{Object.keys(gridData).length}</span>
                </div>
              </CardContent>
            </Card>

            {/* Color Manager */}
            <Card className="bg-gray-800/50 border-0">
              <CardContent className="p-4">
                <DMCColorManager
                  palette={palette}
                  onPaletteChange={setPalette}
                  selectedColor={selectedColor}
                  onColorSelect={(color) => {
                    setSelectedColor(color);
                    setIsErasing(false);
                  }}
                />
              </CardContent>
            </Card>
          </div>

          {/* Right Panel - Canvas */}
          <div className="lg:col-span-2">
            <Card className="bg-gray-800/50 border-0">
              <CardContent className="p-4">
                <Tabs value={mode} onValueChange={setMode} className="w-full">
                  <TabsList className="grid w-full grid-cols-2 bg-gray-900">
                    <TabsTrigger value="draw" className="data-[state=active]:bg-emerald-500 data-[state=active]:text-white">
                      <Pencil className="w-4 h-4 mr-2" />
                      Dessiner
                    </TabsTrigger>
                    <TabsTrigger value="image" className="data-[state=active]:bg-emerald-500 data-[state=active]:text-white">
                      <ImageIcon className="w-4 h-4 mr-2" />
                      Importer
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="draw" className="space-y-4 mt-4">
                    {/* Drawing tools */}
                    <div className="flex items-center gap-2">
                      <Button
                        variant={!isErasing ? "default" : "outline"}
                        onClick={() => setIsErasing(false)}
                        disabled={!selectedColor && palette.length === 0}
                        className={!isErasing ? "bg-emerald-500 hover:bg-emerald-600 text-white" : "border-gray-700"}
                      >
                        <Pencil className="w-4 h-4 mr-2" />
                        Dessiner
                      </Button>

                      <Button
                        variant={isErasing ? "default" : "outline"}
                        onClick={() => setIsErasing(true)}
                        className={isErasing ? "bg-emerald-500 hover:bg-emerald-600 text-white" : "border-gray-700"}
                      >
                        <Eraser className="w-4 h-4 mr-2" />
                        Gomme
                      </Button>

                      <div className="flex-1" />

                      <Button
                        variant="outline"
                        onClick={handleClearGrid}
                        className="border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/20"
                      >
                        Tout effacer
                      </Button>
                    </div>

                    <GridEditor
                      width={gridWidth}
                      height={gridHeight}
                      gridData={gridData}
                      currentColor={selectedColor}
                      onGridDataChange={setGridData}
                      isErasing={isErasing}
                    />
                  </TabsContent>

                  <TabsContent value="image" className="space-y-4 mt-4">
                   {/* Show palette when image is uploaded */}
                   {uploadedImage && palette.length > 0 && (
                     <div className="bg-gray-900/50 rounded-lg p-4 mb-4">
                       <p className="text-sm text-gray-400 mb-2">Couleurs détectées :</p>
                       <div className="flex gap-2 flex-wrap">
                         {palette.map(color => (
                           <div
                             key={color.dmc_code}
                             className="flex items-center gap-2 px-3 py-2 rounded-lg bg-gray-800 border border-gray-700"
                           >
                             <div
                               className="w-4 h-4 rounded border border-white/30"
                               style={{ backgroundColor: color.color }}
                             />
                             <span className="text-xs text-gray-300">{color.dmc_code}</span>
                           </div>
                         ))}
                       </div>
                     </div>
                   )}

                   {!uploadedImage ? (
                      <div className="text-center py-12">
                        <div className="w-16 h-16 rounded-2xl bg-purple-500/20 flex items-center justify-center mx-auto mb-4">
                          <Sparkles className="w-8 h-8 text-purple-400" />
                        </div>
                        <h3 className="text-lg font-semibold text-white mb-2">
                          Convertir une image en pattern
                        </h3>
                        <p className="text-gray-400 mb-6 max-w-md mx-auto">
                          L'IA analysera automatiquement votre image pour détecter la grille, 
                          les couleurs DMC et générer le pattern
                        </p>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleImageUpload}
                          className="hidden"
                                 id="image-upload"
                               />
                               <Button
                                 onClick={() => document.getElementById('image-upload')?.click()}
                                 disabled={isUploading}
                                 className="bg-emerald-500 hover:bg-emerald-600 text-white"
                               >
                          {isUploading ? (
                            <>
                              <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2" />
                              Analyse en cours...
                            </>
                          ) : (
                            <>
                              <Upload className="w-4 h-4 mr-2" />
                              Choisir une image
                            </>
                          )}
                        </Button>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <div className="relative">
                          <img 
                            src={uploadedImage} 
                            alt="Pattern source" 
                            className="w-full rounded-lg border border-gray-700"
                          />
                          <Button
                            onClick={() => {
                              setUploadedImage(null);
                              setGridData({});
                              setPalette([]);
                            }}
                            variant="outline"
                            size="sm"
                            className="absolute top-2 right-2 bg-gray-900/80 border-gray-700"
                          >
                            Changer d'image
                          </Button>
                        </div>

                        {Object.keys(gridData).length > 0 && (
                          <Card className="bg-emerald-500/10 border-0">
                            <CardContent className="p-4">
                              <div className="flex items-start gap-3">
                                <Sparkles className="w-5 h-5 text-emerald-400 mt-0.5" />
                                <div className="flex-1">
                                  <h4 className="font-semibold text-white mb-1">Pattern converti !</h4>
                                  <p className="text-sm text-gray-300 mb-2">
                                    {Object.keys(gridData).length} points détectés avec {palette.length} couleurs DMC
                                  </p>
                                  <Button
                                    onClick={() => setMode('draw')}
                                    size="sm"
                                    className="bg-emerald-500 hover:bg-emerald-600 text-white"
                                  >
                                    Voir et éditer le pattern
                                  </Button>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        )}
                      </div>
                    )}
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}