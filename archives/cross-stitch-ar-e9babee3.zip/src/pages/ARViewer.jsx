import React, { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { createPageUrl } from '@/utils';
import ErrorBoundary from '@/components/ar/ErrorBoundary';
import ARViewerLayout from '@/components/ar/v2/ARViewerLayout';
import ManifestoScreen from '@/components/ar/ManifestoScreen';
import AROnboarding from '@/components/ar/AROnboarding';
import PatternScannerOverlay from '@/components/ar/overlays/PatternScannerOverlay';
import PatternCreatorInAR from '@/components/ar/PatternCreatorInAR';

export default function ARViewer() {
      const navigate = useNavigate();
      const queryClient = useQueryClient();
      const [searchParams, setSearchParams] = useSearchParams();
      const [showManifesto, setShowManifesto] = useState(false);
      const [showOnboarding, setShowOnboarding] = useState(false);
      const [previewPatternId, setPreviewPatternId] = useState(null);
      const [patternLoadError, setPatternLoadError] = useState(false);

  // Read patternId from URL, fallback to localStorage
  const urlPatternId = searchParams.get('patternId');
  const storedPatternId = localStorage.getItem('ar-last-pattern-id');
  const patternId = urlPatternId || storedPatternId;

  const sessionId = searchParams.get('sessionId');
  const mode = searchParams.get('mode') || 'focus'; // focus | guide | adjust | create

  // Fetch all patterns for selection
  const { data: allPatterns = [] } = useQuery({
    queryKey: ['patterns'],
    queryFn: () => base44.entities.Pattern.list()
  });

  // Fetch all sessions for resume
  const { data: allSessions = [] } = useQuery({
    queryKey: ['sessions'],
    queryFn: () => base44.entities.ARSession.list('-updated_date')
  });

  // Fetch current pattern
  const { data: pattern, isLoading: patternLoading, error: patternError } = useQuery({
    queryKey: ['pattern', patternId],
    queryFn: () => patternId ? base44.entities.Pattern.get(patternId) : null,
    enabled: !!patternId,
    retry: 1
  });

  // If pattern not found, clear stored ID and show overlay
  React.useEffect(() => {
    if (patternError || (patternId && !patternLoading && !pattern)) {
      localStorage.removeItem('ar-last-pattern-id');
      setPatternLoadError(true);
    }
  }, [patternError, pattern, patternLoading, patternId]);

  // Fetch or create session
  const { data: session, isLoading: sessionLoading, refetch: refetchSession } = useQuery({
    queryKey: ['session', sessionId, patternId],
    queryFn: async () => {
      if (sessionId) {
        return base44.entities.ARSession.get(sessionId);
      } else if (patternId) {
        const newSession = await base44.entities.ARSession.create({
          pattern_id: patternId,
          pattern_title: pattern?.title || 'Untitled',
          points_completed: [],
          current_color: pattern?.dmc_palette?.[0]?.dmc_code,
          progress_percentage: 0,
          total_stitches: pattern?.total_stitches || 0
        });
        return newSession;
      }
      return null;
    },
    enabled: !!patternId
  });

  // Check first-time manifesto + onboarding
  useEffect(() => {
    const hasSeenManifesto = localStorage.getItem('ar-manifesto-seen');
    const hasSeenOnboarding = localStorage.getItem('ar-onboarding-seen');
    
    if (!hasSeenManifesto) {
      setShowManifesto(true);
    } else if (!hasSeenOnboarding) {
      setShowOnboarding(true);
    }
  }, []);



  const handleManifestoEnter = () => {
    setShowManifesto(false);
    setShowOnboarding(true);
    localStorage.setItem('ar-manifesto-seen', 'true');
  };

  const handleOnboardingComplete = () => {
    setShowOnboarding(false);
    localStorage.setItem('ar-onboarding-seen', 'true');
  };

  const handlePatternSelect = (selectedPattern) => {
    localStorage.setItem('ar-last-pattern-id', selectedPattern.id);
    const params = new URLSearchParams({ patternId: selectedPattern.id });
    setSearchParams(params);
    setPatternLoadError(false);
  };

  const handleResumeSession = (resumeSession) => {
    localStorage.setItem('ar-last-pattern-id', resumeSession.pattern_id);
    const params = new URLSearchParams({ 
      patternId: resumeSession.pattern_id,
      sessionId: resumeSession.id
    });
    setSearchParams(params);
    setPatternLoadError(false);
  };

  const handleChangePattern = () => {
    localStorage.removeItem('ar-last-pattern-id');
    const params = new URLSearchParams();
    setSearchParams(params);
    setPatternLoadError(false);
  };

  const handleModeChange = (newMode) => {
    const params = new URLSearchParams({ patternId, mode: newMode });
    if (sessionId) params.append('sessionId', sessionId);
    setSearchParams(params);
  };

  const handleCreateMode = () => {
    const params = new URLSearchParams({ mode: 'create' });
    setSearchParams(params);
  };

  const handleBackFromCreate = () => {
    const params = new URLSearchParams();
    setSearchParams(params);
  };

  if (showManifesto) {
    return <ManifestoScreen onEnter={handleManifestoEnter} />;
  }

  if (showOnboarding) {
    return <AROnboarding onComplete={handleOnboardingComplete} />;
  }

  // No pattern or error: show selection overlay
  if (!patternId || patternLoadError || (patternId && !patternLoading && !pattern)) {
    return (
          <ErrorBoundary>
            <div className="fixed inset-0 bg-black">
              <PatternScannerOverlay
                isOpen={true}
                lastPattern={allSessions?.[0]?.pattern_id ? allPatterns.find(p => p.id === allSessions[0].pattern_id) : null}
                onStartScan={(newPattern) => {
                  queryClient.invalidateQueries({ queryKey: ['patterns'] });
                  handlePatternSelect(newPattern);
                }}
                onResumePattern={handleResumeSession}
                onClose={() => {}}
              />
            </div>
          </ErrorBoundary>
        );
  }

  if (patternLoading || sessionLoading) {
    return (
      <div className="fixed inset-0 bg-black flex items-center justify-center">
        <div className="text-white text-center space-y-4">
          <div className="w-12 h-12 rounded-full border-2 border-emerald-500 border-t-transparent animate-spin mx-auto" />
          <p className="text-sm text-gray-400">Initializing AR...</p>
        </div>
      </div>
    );
  }

  // Handle Create mode
  if (mode === 'create') {
    return (
      <PatternCreatorInAR
        onSave={(newPattern) => {
          queryClient.invalidateQueries(['patterns']);
          handlePatternSelect(newPattern);
        }}
        onBack={handleBackFromCreate}
      />
    );
  }



  return (
    <ErrorBoundary>
      {/* AR Viewer Layout */}
      <ARViewerLayout
        pattern={pattern}
        session={session}
        mode={mode}
        onModeChange={handleModeChange}
        onChangePattern={handleChangePattern}
        onSessionUpdate={() => refetchSession()}
        previewPatternId={previewPatternId}
      />
    </ErrorBoundary>
  );
  }