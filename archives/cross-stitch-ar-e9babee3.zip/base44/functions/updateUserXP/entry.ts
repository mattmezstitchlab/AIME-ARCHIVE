import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

const XP_REWARDS = {
  POINT_VALIDATED: 5,
  SESSION_COMPLETED: 100,
  FIRST_SESSION: 50,
  COMMUNITY_POST_LIKED: 10,
  COMMUNITY_POST_CREATED: 25,
  COMMUNITY_COMMENT: 5,
  PATTERN_SHARED: 15
};

const BADGES = {
  FIRST_STITCH: { id: 'FIRST_STITCH', condition: 'total_points >= 1' },
  STITCHER_10: { id: 'STITCHER_10', condition: 'completed_sessions >= 10' },
  STITCHER_50: { id: 'STITCHER_50', condition: 'completed_sessions >= 50' },
  SPEED_DEMON: { id: 'SPEED_DEMON', condition: 'avg_speed >= 10' },
  COLOR_MASTER: { id: 'COLOR_MASTER', condition: 'unique_colors >= 20' },
  SOCIAL_BUTTERFLY: { id: 'SOCIAL_BUTTERFLY', condition: 'community_posts >= 5' },
  PATTERN_CREATOR: { id: 'PATTERN_CREATOR', condition: 'created_patterns >= 5' },
  CONSISTENCY_KING: { id: 'CONSISTENCY_KING', condition: 'streak_days >= 7' },
  MILESTONE_1000: { id: 'MILESTONE_1000', condition: 'total_points >= 1000' },
  MARATHON: { id: 'MARATHON', condition: 'longest_session >= 100' }
};

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { action, amount, sessionId } = await req.json();

    if (!action || !amount) {
      return Response.json({ error: 'Missing action or amount' }, { status: 400 });
    }

    const xpReward = XP_REWARDS[action] || amount;
    const currentXP = user.total_xp || 0;
    const newXP = currentXP + xpReward;

    // Fetch user sessions for stats calculation
    const sessions = await base44.entities.ARSession.list();
    const completedSessions = sessions.filter(s => s.is_completed).length;
    const totalPoints = sessions.reduce((sum, s) => sum + (s.points_completed?.length || 0), 0);

    // Check for new badges
    const newBadges = [];
    
    if (totalPoints >= 1 && !user.unlocked_badges?.includes('FIRST_STITCH')) {
      newBadges.push('FIRST_STITCH');
    }
    if (completedSessions >= 10 && !user.unlocked_badges?.includes('STITCHER_10')) {
      newBadges.push('STITCHER_10');
    }
    if (completedSessions >= 50 && !user.unlocked_badges?.includes('STITCHER_50')) {
      newBadges.push('STITCHER_50');
    }
    if (sessionId) {
      const session = sessions.find(s => s.id === sessionId);
      if (session?.points_completed?.length >= 100 && !user.unlocked_badges?.includes('MARATHON')) {
        newBadges.push('MARATHON');
      }
    }

    const unlockedBadges = [...(user.unlocked_badges || []), ...newBadges];

    // Update user
    await base44.auth.updateMe({
      total_xp: newXP,
      unlocked_badges: [...new Set(unlockedBadges)]
    });

    return Response.json({
      success: true,
      newXP,
      xpGained: xpReward,
      newBadges,
      action
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});