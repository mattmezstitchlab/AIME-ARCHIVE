import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { imageUrl } = await req.json();
    if (!imageUrl) {
      return Response.json({ error: 'Missing imageUrl' }, { status: 400 });
    }

    // Use LLM with vision to analyze the grid pattern
    const analysisResult = await base44.integrations.Core.InvokeLLM({
      prompt: `You are an expert in cross-stitch and embroidery pattern recognition with advanced computer vision capabilities.

Analyze this embroidery pattern image with these requirements:

GRID DETECTION:
- Detect the grid rectangle even if slightly rotated (0-15°) or perspective-distorted
- Estimate rotation angle and apply mental correction
- Count actual grid cells, accounting for merged or partial cells
- Handle grids of any size (8x8 to 64x64+)

CELL ANALYSIS:
For each cell, identify:
1. Dominant color using sophisticated color analysis:
   - Account for lighting variations (shadows, highlights)
   - Sample multiple pixels in cell, use median/mode for robustness
   - Return normalized hex color (#RRGGBB)
   - If cell appears white/empty, mark as "empty"

2. Symbol detection even in low-contrast areas:
   - Primary symbols: . (dot), x (cross), + (plus), / (slash), \\ (backslash), o (circle)
   - Look for symbol shape regardless of contrast level
   - Empty cell = no symbol
   - If symbol unclear, choose closest match

3. Quality confidence per cell (0.0-1.0):
   - 1.0: clear color, clear symbol or empty
   - 0.7-0.9: color confident, symbol slightly blurry
   - 0.4-0.7: low contrast, symbol barely visible
   - <0.4: too dark/light/blurry to reliably detect

RETURN FORMAT:
{
  "grid_width": <number of columns>,
  "grid_height": <number of rows>,
  "rotation_angle": <degrees, -15 to 15>,
  "cells": [
    {
      "x": <0-based column>,
      "y": <0-based row>,
      "color": <hex color or "empty">,
      "symbol": <symbol or null>,
      "filled": <boolean>,
      "quality": <0.0-1.0 confidence>,
      "notes": <optional: why quality is low>
    },
    ...
  ],
  "dmc_palette": [
    {
      "color": <hex>,
      "name": <color name>,
      "symbol": <primary symbol>
    },
    ...
  ],
  "overall_confidence": <0.0-1.0>,
  "grid_quality_issues": <string or null, e.g. "slight rotation" or "very uneven lighting">
}

QUALITY RULES:
- If image too blurry overall: confidence ~0.5
- If lighting uneven: note it, but still extract colors
- If grid slightly warped: use best-guess interpolation
- Prioritize extracting usable pattern over perfect accuracy

Return valid JSON only.`,
      add_context_from_internet: false,
      response_json_schema: {
        type: 'object',
        properties: {
          grid_width: { type: 'number' },
          grid_height: { type: 'number' },
          rotation_angle: { type: 'number' },
          cells: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                x: { type: 'number' },
                y: { type: 'number' },
                color: { type: 'string' },
                symbol: { type: ['string', 'null'] },
                filled: { type: 'boolean' },
                quality: { type: 'number' },
                notes: { type: 'string' }
              }
            }
          },
          dmc_palette: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                color: { type: 'string' },
                name: { type: 'string' },
                symbol: { type: 'string' }
              }
            }
          },
          overall_confidence: { type: 'number' },
          grid_quality_issues: { type: ['string', 'null'] }
        }
      },
      file_urls: [imageUrl]
    });

    // Transform analysis into grid_data format for Pattern entity
    const gridData = {};
    const cellQuality = {};
    
    analysisResult.cells?.forEach(cell => {
      const key = `${cell.x}-${cell.y}`;
      if (cell.filled && cell.color !== 'empty') {
        gridData[key] = {
          dmc: cell.color || '#000000',
          symbol: cell.symbol || '•'
        };
      }
      // Store per-cell quality for frontend inspection
      cellQuality[key] = {
        quality: cell.quality || 0.7,
        notes: cell.notes
      };
    });

    // Normalize DMC palette with fallback
    const dmcPalette = (analysisResult.dmc_palette || []).map((item, idx) => ({
      dmc_code: item.dmc_code || `custom_${idx}`,
      color: item.color || '#000000',
      symbol: item.symbol || '•',
      name: item.name || `Color ${idx + 1}`
    }));

    // Calculate average cell quality
    const qualities = Object.values(cellQuality).map(c => c.quality);
    const avgCellQuality = qualities.length > 0 
      ? qualities.reduce((a, b) => a + b) / qualities.length 
      : 0.7;

    return Response.json({
      success: true,
      pattern: {
        grid_width: analysisResult.grid_width || 16,
        grid_height: analysisResult.grid_height || 16,
        grid_data: gridData,
        dmc_palette: dmcPalette,
        confidence: analysisResult.overall_confidence || 0.7,
        notes: analysisResult.grid_quality_issues || analysisResult.notes || '',
        rotation_angle: analysisResult.rotation_angle || 0,
        cell_quality: cellQuality,
        average_cell_quality: avgCellQuality
      }
    });
  } catch (error) {
    console.error('Pattern recognition failed:', error);
    return Response.json({
      success: false,
      error: error.message,
      pattern: null
    }, { status: 500 });
  }
});