import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const images = {};

    // 1. Hero image - calm embroiderer with AR
    const heroPrompt = `A serene embroiderer's hands stitching on cream linen fabric, viewed from above. Soft natural light. 
    A subtle AR grid overlay (light emerald green) is barely visible on the fabric, showing one illuminated point. 
    Warm, calm, peaceful atmosphere. Minimalist composition. Photography style, shallow depth of field.
    No UI elements, no text. Focus on hands, needle, and fabric. Very calm and meditative mood.`;

    // 2. Problem section - dense paper grid vs clear AR
    const problemPrompt = `Split image: Left side shows a dense, confusing embroidery grid pattern on paper (small, hard to read, many lines).
    Right side shows the same pattern but as a clean AR projection on fabric (clear, glowing edges, one point highlighted).
    Soft shadows, warm lighting. Minimalist design. Clearly shows the contrast without text.`;

    // 3. Single point with halo
    const pointPrompt = `Close-up of an embroidery hoop with light cream fabric. One single needle point is highlighted with a soft, glowing emerald-green halo.
    The rest of the fabric is softly blurred. Warm, gentle lighting. Very meditative and focused atmosphere.
    No grid, no other points - just one luminous needle. Studio photography style.`;

    // 4. Voice guidance visual
    const voicePrompt = `A calm feminine silhouette against a soft gradient background (light to warm tones). 
    Gentle sound waves in soft indigo/blue emanate from the figure. 
    A needle and thread float nearby. Serene, gentle, approachable. 
    Illustration style, soft edges, no text. Represents calm, supportive guidance.`;

    // 5. Shared presence - two embroiderers connected
    const communityPrompt = `Two hands from different angles, both stitching on separate hoops but with the same shared AR grid visible (emerald green).
    They're positioned side by side, suggesting connection without contact. 
    Soft warm lighting, peaceful atmosphere. Studio photography.
    Shows quiet companionship and transmission of knowledge. No UI, no text.`;

    // Generate all images in parallel
    const [hero, problem, point, voice, community] = await Promise.all([
      base44.integrations.Core.GenerateImage({ prompt: heroPrompt }),
      base44.integrations.Core.GenerateImage({ prompt: problemPrompt }),
      base44.integrations.Core.GenerateImage({ prompt: pointPrompt }),
      base44.integrations.Core.GenerateImage({ prompt: voicePrompt }),
      base44.integrations.Core.GenerateImage({ prompt: communityPrompt })
    ]);

    images.hero = hero.url;
    images.problem = problem.url;
    images.point = point.url;
    images.voice = voice.url;
    images.community = community.url;

    return Response.json({ 
      success: true, 
      images,
      message: 'Home page images generated successfully'
    });
  } catch (error) {
    console.error('Error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});