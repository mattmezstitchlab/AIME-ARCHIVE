import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { patternId, simplificationLevel } = await req.json();

    if (!patternId) {
      return Response.json({ error: 'patternId required' }, { status: 400 });
    }

    // Fetch pattern
    const pattern = await base44.entities.Pattern.filter({ id: patternId });
    if (!pattern?.length) {
      return Response.json({ error: 'Pattern not found' }, { status: 404 });
    }

    const originalPattern = pattern[0];

    // Use AI to simplify pattern
    const prompt = `Tu es un expert en broderie AR. Simplifie ce pattern pour faciliter la broderie avec un guide AR.
    
Niveau de simplification: ${simplificationLevel || 'medium'} (low/medium/high)

Pattern original:
- Grille: ${originalPattern.grid_width}x${originalPattern.grid_height}
- Couleurs: ${originalPattern.dmc_palette?.length || 0}
- Total points: ${originalPattern.total_stitches || 0}

Instructions de simplification:
1. Si HIGH: réduis le nombre de couleurs de 50%, regroupe les petites zones
2. Si MEDIUM: réduis le nombre de couleurs de 30%, simplifie les zones fines
3. Si LOW: réduis légèrement (10-20% de couleurs)
4. Garde les zones visuellement importantes
5. Suggère les zones à broder en priorité pour la progression optimale

Retourner un objet JSON avec:
- recommended_colors: nombre de couleurs recommandées
- priority_zones: array des zones à broder en priorité {x, y, importance}
- simplified_grid_data: objet simplifié avec moins de points
- estimated_time_minutes: temps estimé de broderie
- difficulty_reduction: "facile" | "moyen" | "avancé"`;

    const response = await base44.integrations.Core.InvokeLLM({
      prompt,
      add_context_from_internet: false,
      response_json_schema: {
        type: 'object',
        properties: {
          recommended_colors: { type: 'number' },
          priority_zones: { 
            type: 'array',
            items: {
              type: 'object',
              properties: {
                x: { type: 'number' },
                y: { type: 'number' },
                importance: { type: 'number' }
              }
            }
          },
          simplified_grid_data: { type: 'object' },
          estimated_time_minutes: { type: 'number' },
          difficulty_reduction: { type: 'string' }
        }
      }
    });

    return Response.json({
      success: true,
      original: {
        colors: originalPattern.dmc_palette?.length || 0,
        stitches: originalPattern.total_stitches || 0,
        dimensions: `${originalPattern.grid_width}x${originalPattern.grid_height}`
      },
      simplified: response
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});