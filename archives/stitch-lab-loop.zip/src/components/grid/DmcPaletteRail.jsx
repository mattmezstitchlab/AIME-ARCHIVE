import React from 'react';
import { Palette, Route } from 'lucide-react';
import { DMC_PALETTE } from '@/lib/dmcPalette';

export default function DmcPaletteRail({ activeColor, onSelect }) {
  const ordered = DMC_PALETTE.slice(0, 18);

  return (
    <div className="rounded-3xl border border-slate-200/70 bg-white p-3 text-slate-900 shadow-sm">
      <div className="mb-3 flex items-center justify-between gap-3">
        <div>
          <p className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.24em] text-slate-500"><Palette className="h-3.5 w-3.5" /> Palette DMC</p>
          <p className="mt-1 text-xs text-slate-500">Ordre Smart Pathing · zones couleur groupées</p>
        </div>
        <Route className="h-4 w-4 text-primary" />
      </div>
      <div className="grid max-h-[220px] grid-cols-2 gap-2 overflow-auto pr-1 md:grid-cols-3 xl:grid-cols-2">
        {ordered.map((thread, index) => {
          const isActive = activeColor?.code === thread.code;
          return (
            <button
              key={thread.code}
              onClick={() => onSelect(thread)}
              className={`flex items-center gap-2 rounded-2xl border p-2 text-left transition ${isActive ? 'border-primary bg-primary/10' : 'border-slate-200 bg-slate-50 hover:border-primary/50'}`}
            >
              <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl border border-slate-300 text-[10px] font-bold text-slate-900" style={{ backgroundColor: thread.hex }}>
                {index + 1}
              </span>
              <span className="min-w-0">
                <span className="block text-xs font-semibold">DMC {thread.code}</span>
                <span className="block truncate text-[11px] text-slate-500">{thread.name}</span>
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}