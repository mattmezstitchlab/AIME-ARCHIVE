import React, { useState } from 'react';
import { Compass, LocateFixed, MapPinned, Navigation } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

const landmarks = [
  { label: 'Origine', x: 0, y: 0 },
  { label: 'Atelier Nord', x: -240, y: -180 },
  { label: 'Place centrale', x: 320, y: 120 },
  { label: 'Archipel SAL', x: 880, y: -420 }
];

export default function GridTeleportPanel({ origin, onTeleport }) {
  const [x, setX] = useState(origin.x);
  const [y, setY] = useState(origin.y);

  const jump = () => onTeleport({ x: Number(x) || 0, y: Number(y) || 0 });

  return (
    <div className="rounded-3xl border border-slate-200/70 bg-white p-3 text-slate-900 shadow-sm">
      <p className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.24em] text-slate-500"><Compass className="h-3.5 w-3.5" /> Téléportation</p>
      <div className="mt-3 grid grid-cols-2 gap-2">
        <Input value={x} onChange={(e) => setX(e.target.value)} className="h-9 rounded-xl border-slate-200 bg-slate-50 text-slate-900" />
        <Input value={y} onChange={(e) => setY(e.target.value)} className="h-9 rounded-xl border-slate-200 bg-slate-50 text-slate-900" />
      </div>
      <Button onClick={jump} className="mt-2 w-full rounded-xl"><LocateFixed className="h-4 w-4" /> Aller aux coordonnées</Button>
      <div className="mt-3 grid gap-2">
        {landmarks.map((point) => (
          <button key={point.label} onClick={() => onTeleport({ x: point.x, y: point.y })} className="flex items-center justify-between rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs hover:border-primary/50">
            <span className="flex items-center gap-2"><MapPinned className="h-3.5 w-3.5 text-primary" /> {point.label}</span>
            <span className="flex items-center gap-1 text-slate-500"><Navigation className="h-3 w-3" /> {point.x}:{point.y}</span>
          </button>
        ))}
      </div>
    </div>
  );
}