import React from 'react';
import { Bot, Sparkles } from 'lucide-react';

export default function GridMessagePanel({ cursors = [] }) {
  const friends = cursors.slice(0, 7);

  return (
    <aside className="absolute bottom-24 left-4 top-4 z-30 w-20 rounded-[2rem] border border-slate-200 bg-white/92 p-3 text-slate-950 shadow-2xl backdrop-blur-xl">
      <div className="flex h-full flex-col items-center gap-3">
        <div className="flex h-11 w-11 items-center justify-center rounded-full bg-slate-950 text-white">
          <Bot className="h-5 w-5" />
        </div>
        <div className="h-px w-8 bg-slate-200" />
        {friends.map((friend, index) => (
          <div key={friend.id || friend.user_email} className="relative">
            <div className="flex h-11 w-11 items-center justify-center rounded-full border border-slate-200 bg-slate-100 text-sm font-black" style={{ color: friend.color || '#111827' }}>
              {(friend.display_name || friend.user_email || '?').slice(0, 1).toUpperCase()}
            </div>
            {index === 0 && <span className="absolute -right-0.5 -top-0.5 h-3 w-3 rounded-full border-2 border-white bg-primary" />}
          </div>
        ))}
        <div className="mt-auto rounded-2xl bg-primary/15 p-2 text-primary">
          <Sparkles className="h-4 w-4" />
        </div>
      </div>
    </aside>
  );
}