import React, { useMemo, useState } from 'react';
import { Grid3X3, HeartHandshake, Search, Sparkles } from 'lucide-react';
import { DMC_PALETTE } from '@/lib/dmcPalette';

export default function GridMagicSearchPanel({ cursors = [], patterns = [] }) {
  const [query, setQuery] = useState('');
  const needle = query.trim().toLowerCase();

  const results = useMemo(() => {
    if (!needle) return [];
    const threads = DMC_PALETTE.filter((thread) => `${thread.code} ${thread.name}`.toLowerCase().includes(needle)).slice(0, 4).map((thread) => ({ type: 'dmc', label: `DMC ${thread.code}`, detail: thread.name, color: thread.hex }));
    const friends = cursors.filter((cursor) => `${cursor.display_name || ''} ${cursor.user_email || ''}`.toLowerCase().includes(needle)).slice(0, 4).map((cursor) => ({ type: 'friend', label: cursor.display_name || cursor.user_email, detail: 'Amie en ligne', color: cursor.color }));
    const motifs = patterns.filter((pattern) => `${pattern.title || ''} ${pattern.description || ''}`.toLowerCase().includes(needle)).slice(0, 4).map((pattern) => ({ type: 'pattern', label: pattern.title, detail: `${pattern.width || 0}×${pattern.height || 0} pts`, color: '#111827' }));
    return [...threads, ...friends, ...motifs];
  }, [needle, cursors, patterns]);

  return (
    <div className="absolute left-1/2 top-6 z-30 w-[min(92vw,34rem)] -translate-x-1/2 rounded-[2rem] border border-slate-200 bg-white/94 p-3 text-slate-950 shadow-2xl backdrop-blur-2xl">
      <div className="flex items-center gap-3 rounded-full bg-slate-100 px-4 py-3">
        <Search className="h-5 w-5 text-slate-500" />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          autoFocus
          placeholder="DMC, amie, motif..."
          className="min-w-0 flex-1 bg-transparent text-sm font-semibold outline-none placeholder:text-slate-400"
        />
        <Sparkles className="h-5 w-5 text-primary" />
      </div>

      <div className="mt-3 grid gap-2 sm:grid-cols-3">
        <SearchChip icon={Grid3X3} label="DMC" />
        <SearchChip icon={HeartHandshake} label="Amies" />
        <SearchChip icon={Sparkles} label="Motifs" />
      </div>

      {results.length > 0 && (
        <div className="mt-3 space-y-2">
          {results.map((item, index) => (
            <div key={`${item.type}-${index}`} className="flex items-center gap-3 rounded-2xl bg-slate-50 p-2">
              <span className="h-9 w-9 rounded-full shadow-sm" style={{ backgroundColor: item.color || '#e5e7eb' }} />
              <div className="min-w-0">
                <p className="truncate text-sm font-black">{item.label}</p>
                <p className="truncate text-xs text-slate-500">{item.detail}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function SearchChip({ icon: Icon, label }) {
  return (
    <div className="flex items-center justify-center gap-2 rounded-full border border-slate-200 bg-white px-3 py-2 text-xs font-bold text-slate-600">
      <Icon className="h-4 w-4" /> {label}
    </div>
  );
}