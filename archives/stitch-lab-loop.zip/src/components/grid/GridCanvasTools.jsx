import React, { useState } from 'react';
import { Compass, LocateFixed, Palette, X } from 'lucide-react';
import { DMC_PALETTE } from '@/lib/dmcPalette';

const LANDMARKS = [
  { label: 'Origine', x: 0, y: 0 },
  { label: 'Nord', x: -240, y: -180 },
  { label: 'Place', x: 320, y: 120 },
  { label: 'SAL', x: 880, y: -420 }
];

export default function GridCanvasTools({ activeThread, onThreadSelect, onTeleport }) {
  const [openTool, setOpenTool] = useState(null);
  const [coords, setCoords] = useState({ x: 0, y: 0 });

  const toggleTool = (tool) => setOpenTool((current) => current === tool ? null : tool);

  return (
    <div className="border-b border-slate-200 bg-slate-50/90">
      <div className="flex items-center gap-2 px-4 py-2">
        <ToolButton active={openTool === 'palette'} title="Palette DMC" onClick={() => toggleTool('palette')} icon={Palette} />
        <ToolButton active={openTool === 'teleport'} title="Téléportation" onClick={() => toggleTool('teleport')} icon={Compass} />

        {openTool === 'palette' && (
          <div className="flex min-w-0 flex-1 gap-1.5 overflow-x-auto pl-2">
            {DMC_PALETTE.map((thread) => (
              <button
                key={thread.code}
                onClick={() => onThreadSelect(thread)}
                className={`flex min-w-fit items-center gap-2 rounded-full border px-2 py-1 text-[10px] font-semibold transition ${activeThread.code === thread.code ? 'border-slate-900 bg-white text-slate-950 shadow-sm' : 'border-slate-200 bg-white/60 text-slate-600 hover:bg-white'}`}
                title={`DMC ${thread.code} · ${thread.name}`}
              >
                <span className="flex h-8 w-8 items-center justify-center rounded-full text-xs font-black text-black/75 shadow-sm" style={{ backgroundColor: thread.hex }}>{thread.symbol}</span>
                <span>{thread.code}</span>
              </button>
            ))}
          </div>
        )}

        <div className="ml-auto flex shrink-0 items-center gap-2 rounded-full bg-white px-2.5 py-1 text-[10px] shadow-sm">
          <span className="h-8 w-8 rounded-full border border-slate-300 shadow-sm" style={{ backgroundColor: activeThread.hex }} />
          <span className="font-semibold">DMC {activeThread.code}</span>
        </div>
      </div>


      {openTool === 'teleport' && (
        <div className="flex flex-wrap items-center gap-2 border-t border-slate-200 px-4 py-3">
          <input value={coords.x} onChange={(e) => setCoords({ ...coords, x: Number(e.target.value) })} type="number" className="h-9 w-24 rounded-full border border-slate-200 bg-white px-3 text-sm" aria-label="Coordonnée X" />
          <input value={coords.y} onChange={(e) => setCoords({ ...coords, y: Number(e.target.value) })} type="number" className="h-9 w-24 rounded-full border border-slate-200 bg-white px-3 text-sm" aria-label="Coordonnée Y" />
          <button onClick={() => onTeleport(coords)} className="flex h-9 items-center gap-2 rounded-full bg-primary px-4 text-sm font-semibold text-primary-foreground"><LocateFixed className="h-4 w-4" /> Go</button>
          <div className="flex min-w-0 flex-1 gap-2 overflow-x-auto">
            {LANDMARKS.map((spot) => (
              <button key={spot.label} onClick={() => onTeleport({ x: spot.x, y: spot.y })} className="min-w-fit rounded-full border border-slate-200 bg-white px-3 py-2 text-xs hover:bg-slate-100">
                {spot.label} · {spot.x}:{spot.y}
              </button>
            ))}
          </div>
          <button onClick={() => setOpenTool(null)} className="rounded-full border border-slate-200 bg-white p-2 hover:bg-slate-100"><X className="h-4 w-4" /></button>
        </div>
      )}
    </div>
  );
}

function ToolButton({ icon: Icon, active, title, onClick }) {
  return (
    <button
      onClick={onClick}
      title={title}
      className={`flex h-10 w-10 items-center justify-center rounded-full border transition ${active ? 'border-slate-900 bg-slate-900 text-white shadow-lg' : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-100'}`}
    >
      <Icon className="h-4 w-4" />
    </button>
  );
}