import React from 'react';

export default function GridCompactThreadBadge({ thread }) {
  return (
    <div className="ml-auto flex shrink-0 items-center gap-2 rounded-full bg-white px-2.5 py-1 text-[10px] shadow-sm">
      <span className="h-8 w-8 rounded-full border border-slate-300 shadow-sm" style={{ backgroundColor: thread.hex }} />
      <span className="font-semibold">DMC {thread.code}</span>
    </div>
  );
}