import React from 'react';
import { Activity, Grid3X3, Layers } from 'lucide-react';

export default function GridProgressStats({ stitches }) {
  const total = stitches.length;
  const byPattern = stitches.reduce((acc, stitch) => {
    const key = stitch.pattern_id || 'Monde libre';
    acc[key] = (acc[key] || 0) + 1;
    return acc;
  }, {});

  const topPatterns = Object.entries(byPattern)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3);

  return (
    <section className="flex flex-wrap items-center gap-3 rounded-3xl border border-border bg-card/70 px-4 py-3 shadow-sm">
      <div className="flex min-w-[170px] items-center gap-3 rounded-2xl bg-primary/12 px-3 py-2 text-primary">
        <Activity className="h-4 w-4" />
        <div>
          <p className="text-[10px] uppercase tracking-[0.22em] opacity-75">Progression</p>
          <p className="text-xl font-black leading-none">{total.toLocaleString('fr-FR')} <span className="text-xs font-medium">pts</span></p>
        </div>
      </div>

      <div className="flex min-w-0 flex-1 items-center gap-3 overflow-hidden">
        <p className="hidden items-center gap-2 text-[10px] uppercase tracking-[0.22em] text-muted-foreground sm:flex"><Layers className="h-3.5 w-3.5" /> Patrons actifs</p>
        <div className="flex min-w-0 flex-1 gap-2 overflow-x-auto pb-1">
          {topPatterns.map(([pattern, count]) => {
            const percent = total ? Math.max(8, Math.round((count / total) * 100)) : 0;
            return (
              <div key={pattern} className="min-w-[170px] rounded-2xl border border-border bg-secondary/50 px-3 py-2">
                <div className="mb-1 flex items-center justify-between gap-2 text-xs">
                  <span className="flex min-w-0 items-center gap-1.5 truncate"><Grid3X3 className="h-3.5 w-3.5 text-primary" /> {pattern}</span>
                  <span className="shrink-0 text-muted-foreground">{count} pts</span>
                </div>
                <div className="h-1.5 overflow-hidden rounded-full bg-background">
                  <div className="h-full rounded-full bg-accent" style={{ width: `${percent}%` }} />
                </div>
              </div>
            );
          })}
          {topPatterns.length === 0 && <p className="text-sm text-muted-foreground">Aucun point posé pour le moment.</p>}
        </div>
      </div>
    </section>
  );
}