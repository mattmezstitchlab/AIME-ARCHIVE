import React, { useMemo, useState } from 'react';
import { Crosshair, Maximize2, Minimize2, Minus, Move, Plus } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { DMC_PALETTE } from '@/lib/dmcPalette';
import GridCanvasTools from '@/components/grid/GridCanvasTools';
import GridCanvasCell from '@/components/grid/GridCanvasCell';
import GridFloatingToolbar from '@/components/grid/GridFloatingToolbar';
import GridImmersiveHint from '@/components/grid/GridImmersiveHint';
import GridMagicSearchPanel from '@/components/grid/GridMagicSearchPanel';
import GridMessagePanel from '@/components/grid/GridMessagePanel';
import GridProfilePanel from '@/components/grid/GridProfilePanel';
import GridSalPanel from '@/components/grid/GridSalPanel';
import GridThreadOrderPanel from '@/components/grid/GridThreadOrderPanel';

const GRID_SIZE = 32;
const STEP_BY_ZOOM = { 1: 18, 2: 24, 3: 32, 4: 44 };

export default function GridCanvas({ stitches, cursors, user, isPro, patterns = [], salGroups = [], salMembers = [] }) {
  const [activeThread, setActiveThread] = useState(DMC_PALETTE[2]);
  const [origin, setOrigin] = useState({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(2);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isImmersive, setIsImmersive] = useState(false);
  const [activePanel, setActivePanel] = useState(null);
  const cellSize = STEP_BY_ZOOM[zoom];

  const map = useMemo(() => new Map(stitches.map((s) => [`${s.x}:${s.y}`, s])), [stitches]);

  const place = async (dx, dy) => {
    if (!isPro) return;
    const x = origin.x + dx;
    const y = origin.y + dy;
    await base44.entities.GridStitch.create({
      x,
      y,
      color: activeThread.hex,
      symbol: activeThread.symbol,
      region: `${Math.floor(x / 100)}:${Math.floor(y / 100)}`,
      pattern_id: `DMC-${activeThread.code}`
    });
  };

  const movePresence = async (dx, dy) => {
    if (!user) return;
    await base44.entities.CursorPresence.create({
      user_email: user.email,
      display_name: user.full_name,
      x: origin.x + dx,
      y: origin.y + dy,
      color: activeThread.hex,
      last_seen: new Date().toISOString()
    });
  };

  const pan = (x, y) => setOrigin((current) => ({ x: current.x + x, y: current.y + y }));
  const visibleRange = `${origin.x}:${origin.y} → ${origin.x + GRID_SIZE - 1}:${origin.y + GRID_SIZE - 1}`;
  const shellClass = isFullscreen || isImmersive ? 'fixed inset-0 z-[80] overflow-hidden bg-slate-950 p-0' : 'relative';

  return (
    <div className={shellClass}>
      <div className={`${isImmersive ? 'h-full rounded-none border-0 bg-white' : 'overflow-hidden rounded-[2rem] border border-slate-200 bg-white text-slate-950 shadow-2xl'}`}>
        {!isImmersive && (
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 bg-slate-50 px-4 py-3">
            <div>
              <p className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.28em] text-slate-500"><Crosshair className="h-3.5 w-3.5" /> Grille universelle</p>
              <h2 className="mt-1 text-2xl font-semibold">Map mondiale magnétique</h2>
              <p className="text-xs text-slate-500">Fenêtre {visibleRange} · région {Math.floor(origin.x / 100)}:{Math.floor(origin.y / 100)}</p>
            </div>
            <div className="flex items-center gap-2 opacity-60 transition hover:opacity-100">
              <button onClick={() => setIsFullscreen((value) => !value)} className="rounded-full border border-slate-200 bg-white p-2 hover:bg-slate-100" title="Mode plein écran">
                {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
              </button>
              <button onClick={() => setZoom((value) => Math.max(1, value - 1))} className="rounded-full border border-slate-200 bg-white p-2 hover:bg-slate-100"><Minus className="h-4 w-4" /></button>
              <span className="rounded-full bg-slate-900 px-3 py-1 text-xs font-semibold text-white">Zoom {zoom}</span>
              <button onClick={() => setZoom((value) => Math.min(4, value + 1))} className="rounded-full border border-slate-200 bg-white p-2 hover:bg-slate-100"><Plus className="h-4 w-4" /></button>
            </div>
          </div>
        )}

        {!isImmersive && <GridCanvasTools activeThread={activeThread} onThreadSelect={setActiveThread} onTeleport={setOrigin} />}

        <div className={`${isImmersive ? 'relative h-full overflow-auto bg-white p-8' : 'relative overflow-auto bg-white p-4'}`}>
          {isImmersive && <GridImmersiveHint />}
          <div
            className="grid border-l border-t border-slate-200/70 bg-white shadow-inner"
            style={{ gridTemplateColumns: `repeat(${GRID_SIZE}, ${cellSize}px)`, width: GRID_SIZE * cellSize }}
          >
            {Array.from({ length: GRID_SIZE * GRID_SIZE }).map((_, i) => {
              const dx = i % GRID_SIZE;
              const dy = Math.floor(i / GRID_SIZE);
              const x = origin.x + dx;
              const y = origin.y + dy;
              const stitch = map.get(`${x}:${y}`);
              const isAxis = x === 0 || y === 0;

              return (
                <GridCanvasCell
                  key={`${x}:${y}`}
                  x={x}
                  y={y}
                  size={cellSize}
                  stitch={stitch}
                  isAxis={isAxis}
                  zoom={zoom}
                  onHover={() => movePresence(dx, dy)}
                  onPlace={() => place(dx, dy)}
                />
              );
            })}
          </div>

          {activePanel === 'messages' && <GridMessagePanel cursors={cursors} />}
          {activePanel === 'search' && <GridMagicSearchPanel cursors={cursors} patterns={patterns} />}
          {activePanel === 'order' && <GridThreadOrderPanel activeThread={activeThread} user={user} />}
          {activePanel === 'sal' && <GridSalPanel salGroups={salGroups} salMembers={salMembers} />}
          {activePanel === 'profile' && <GridProfilePanel user={user} stitches={stitches} />}
          <GridFloatingToolbar activePanel={activePanel} onOpenPanel={setActivePanel} immersive={isImmersive} onToggleImmersive={() => setIsImmersive((value) => !value)} />
        </div>

        {!isImmersive && (
          <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-200 bg-slate-50 px-4 py-3 text-xs text-slate-500">
            <span className="flex items-center gap-2"><Move className="h-3.5 w-3.5" /> Déplacement par blocs magnétiques de {GRID_SIZE} points</span>
            <div className="flex gap-2">
              <button onClick={() => pan(-GRID_SIZE, 0)} className="rounded-full bg-white px-3 py-1.5 shadow-sm">← Ouest</button>
              <button onClick={() => pan(GRID_SIZE, 0)} className="rounded-full bg-white px-3 py-1.5 shadow-sm">Est →</button>
              <button onClick={() => pan(0, -GRID_SIZE)} className="rounded-full bg-white px-3 py-1.5 shadow-sm">Nord</button>
              <button onClick={() => pan(0, GRID_SIZE)} className="rounded-full bg-white px-3 py-1.5 shadow-sm">Sud</button>
            </div>
          </div>
        )}
      </div>

      {!isImmersive && (
        <div className="mt-3 rounded-3xl border border-slate-200/70 bg-white p-3 text-slate-900 shadow-sm">
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-slate-500">Présences</p>
          <div className="mt-3 flex flex-wrap gap-2">
            {cursors.slice(0, 6).map((cursor) => <span key={cursor.id} className="rounded-full bg-slate-100 px-3 py-1 text-xs">{cursor.display_name || cursor.user_email}</span>)}
            {!cursors.length && <span className="text-xs text-slate-500">Aucune brodeuse visible ici.</span>}
          </div>
        </div>
      )}
    </div>
  );
}