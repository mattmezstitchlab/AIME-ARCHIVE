import React from 'react';
import { Eye } from 'lucide-react';

export default function GridImmersiveHint() {
  return (
    <div className="pointer-events-none absolute left-4 top-4 z-20 flex items-center gap-2 rounded-full bg-slate-950/70 px-3 py-2 text-xs font-bold text-white shadow-xl backdrop-blur-xl">
      <Eye className="h-4 w-4 text-primary" /> Immersif
    </div>
  );
}