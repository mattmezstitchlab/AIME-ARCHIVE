import React from 'react';
import { Barcode, FileText, Printer } from 'lucide-react';

export default function GridThreadOrderPanel({ activeThread, user }) {
  const sender = user?.full_name || 'Brodeuse StitchLab';
  const reference = `SL-${activeThread.code}-${new Date().getFullYear()}`;

  const printTemplate = () => window.print();

  return (
    <div className="absolute inset-x-4 top-6 z-30 mx-auto max-w-md rounded-[2rem] border border-slate-200 bg-white/95 p-5 text-slate-950 shadow-2xl backdrop-blur-2xl">
      <div className="flex items-center justify-between gap-3">
        <div>
          <p className="text-xs font-bold uppercase tracking-[0.24em] text-slate-500">Envoi intelligent</p>
          <h3 className="mt-1 text-2xl font-black">Fil DMC {activeThread.code}</h3>
        </div>
        <span className="h-12 w-12 rounded-full shadow-sm" style={{ backgroundColor: activeThread.hex }} />
      </div>

      <div className="mt-4 rounded-3xl border border-slate-200 bg-slate-50 p-4">
        <div className="mb-4 flex items-center gap-2 text-sm font-bold"><FileText className="h-4 w-4" /> Lettre prête à imprimer</div>
        <p className="text-sm leading-6 text-slate-600">Bonjour, voici le fil demandé pour compléter ta broderie collaborative StitchLab.</p>
        <div className="mt-4 grid grid-cols-[1fr_auto] items-end gap-3 rounded-2xl bg-white p-3">
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-slate-400">Référence</p>
            <p className="font-black">{reference}</p>
            <p className="text-xs text-slate-500">Expéditeur · {sender}</p>
          </div>
          <Barcode className="h-12 w-20 text-slate-900" />
        </div>
      </div>

      <button onClick={printTemplate} className="mt-4 flex w-full items-center justify-center gap-2 rounded-full bg-slate-950 px-5 py-3 text-sm font-black text-white">
        <Printer className="h-4 w-4" /> Imprimer le template
      </button>
    </div>
  );
}