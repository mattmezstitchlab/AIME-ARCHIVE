import React from 'react';
import { CalendarDays, Maximize2, MessageCircle, Package, Search, UserCircle } from 'lucide-react';

const ACTIONS = [
  { key: 'messages', icon: MessageCircle, label: 'Messages' },
  { key: 'search', icon: Search, label: 'Recherche' },
  { key: 'order', icon: Package, label: 'Envoi fil' },
  { key: 'sal', icon: CalendarDays, label: 'SAL' },
  { key: 'profile', icon: UserCircle, label: 'Profil' }
];

export default function GridFloatingToolbar({ activePanel, onOpenPanel, immersive, onToggleImmersive }) {
  return (
    <div className="pointer-events-none absolute inset-x-0 bottom-5 z-40 flex justify-center px-4">
      <div className="pointer-events-auto flex items-center gap-1.5 rounded-full border border-slate-200/70 bg-slate-950/82 p-2 shadow-2xl backdrop-blur-2xl">
        <button
          onClick={onToggleImmersive}
          className={`flex h-12 w-12 items-center justify-center rounded-full transition ${immersive ? 'bg-primary text-primary-foreground' : 'text-white/75 hover:bg-white/10 hover:text-white'}`}
          title="Mode immersif"
        >
          <Maximize2 className="h-5 w-5" />
        </button>
        <div className="h-8 w-px bg-white/15" />
        {ACTIONS.map((action) => (
          <button
            key={action.key}
            onClick={() => onOpenPanel(activePanel === action.key ? null : action.key)}
            className={`flex h-12 w-12 items-center justify-center rounded-full transition ${activePanel === action.key ? 'bg-primary text-primary-foreground shadow-lg' : 'text-white/75 hover:bg-white/10 hover:text-white'}`}
            title={action.label}
          >
            <action.icon className="h-5 w-5" />
          </button>
        ))}
      </div>
    </div>
  );
}