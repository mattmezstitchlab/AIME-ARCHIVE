import React from 'react';
import { CalendarDays, Gauge, Users } from 'lucide-react';

export default function GridSalPanel({ salGroups = [], salMembers = [] }) {
  const active = salGroups[0];
  const members = salMembers.filter((member) => !active || member.sal_group_id === active.id).slice(0, 6);
  const progress = Math.min(100, Math.max(18, (members.length || active?.member_count || 1) * 12));

  return (
    <aside className="absolute bottom-24 right-4 top-4 z-30 w-72 rounded-[2rem] border border-slate-200 bg-white/94 p-4 text-slate-950 shadow-2xl backdrop-blur-2xl">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-xs font-bold uppercase tracking-[0.24em] text-slate-500">SAL</p>
          <h3 className="mt-1 text-xl font-black">{active?.title || 'Groupe actif'}</h3>
        </div>
        <CalendarDays className="h-6 w-6 text-primary" />
      </div>

      <div className="mt-5 grid grid-cols-3 gap-2">
        <Metric icon={Gauge} value={`${progress}%`} />
        <Metric icon={Users} value={String(members.length || active?.member_count || 1)} />
        <Metric icon={CalendarDays} value={active?.start_date ? new Date(active.start_date).toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit' }) : '—'} />
      </div>

      <div className="mt-5 rounded-3xl bg-slate-100 p-3">
        <div className="h-2 overflow-hidden rounded-full bg-white">
          <div className="h-full rounded-full bg-primary" style={{ width: `${progress}%` }} />
        </div>
      </div>

      <div className="mt-5 space-y-2">
        {(members.length ? members : [{ member_name: 'Créatrice' }, { member_name: 'Brodeuse' }, { member_name: 'IA' }]).map((member, index) => (
          <div key={member.id || index} className="flex items-center gap-3 rounded-2xl bg-slate-50 p-2">
            <span className="flex h-9 w-9 items-center justify-center rounded-full bg-slate-950 text-xs font-black text-white">{(member.member_name || '?').slice(0, 1)}</span>
            <span className="text-sm font-bold">{member.member_name}</span>
          </div>
        ))}
      </div>
    </aside>
  );
}

function Metric({ icon: Icon, value }) {
  return (
    <div className="flex flex-col items-center gap-2 rounded-2xl bg-slate-100 p-3">
      <Icon className="h-4 w-4 text-slate-500" />
      <span className="text-sm font-black">{value}</span>
    </div>
  );
}