import React from 'react';

export default function GridCanvasCell({ x, y, size, stitch, isAxis, zoom, onHover, onPlace }) {
  return (
    <button
      onMouseEnter={onHover}
      onClick={onPlace}
      className={`group relative flex items-center justify-center border-b border-r text-[10px] font-bold transition ${isAxis ? 'border-primary/40 bg-primary/5' : 'border-slate-200/55 hover:bg-slate-100/70'}`}
      style={{ width: size, height: size, backgroundColor: stitch?.color || undefined }}
      title={`x ${x} · y ${y}`}
    >
      {stitch?.symbol && <span className="text-black/75 mix-blend-multiply">{stitch.symbol}</span>}
      {zoom >= 4 && !stitch && x % 8 === 0 && y % 8 === 0 && <span className="absolute left-1 top-1 text-[8px] font-normal text-slate-400/80">{x}:{y}</span>}
    </button>
  );
}