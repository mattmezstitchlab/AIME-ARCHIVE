import React from 'react';
import { Crown, UserCircle } from 'lucide-react';

export default function GridProfilePanel({ user, stitches = [] }) {
  return (
    <aside className="absolute bottom-24 right-4 top-4 z-30 w-64 rounded-[2rem] border border-slate-200 bg-white/94 p-4 text-slate-950 shadow-2xl backdrop-blur-2xl">
      <UserCircle className="h-10 w-10 text-slate-400" />
      <h3 className="mt-4 text-xl font-black">{user?.full_name || 'Espace perso'}</h3>
      <p className="text-sm text-slate-500">{user?.email || 'Profil StitchLab'}</p>
      <div className="mt-5 rounded-3xl bg-slate-100 p-4">
        <p className="text-xs font-bold uppercase tracking-[0.2em] text-slate-500">Mes points</p>
        <p className="mt-2 text-3xl font-black">{stitches.length}</p>
      </div>
      <div className="mt-3 flex items-center gap-2 rounded-full bg-primary/15 px-4 py-3 text-sm font-black text-slate-950">
        <Crown className="h-4 w-4 text-primary" /> Mode créatif
      </div>
    </aside>
  );
}