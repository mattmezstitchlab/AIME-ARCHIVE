import React from 'react';
import { Heart, MessageCircle, Sparkles } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

const labels = { progress: 'Avancée', pattern: 'Patron', sal: 'SAL', question: 'Question' };

export default function PostCard({ post }) {
  return (
    <article className="rounded-[2rem] border border-border bg-card p-6 shadow-sm transition-all hover:shadow-lg">
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-secondary"><Sparkles className="h-4 w-4" /></div>
          <div>
            <p className="font-medium">{post.author_name || 'Communauté StitchLab'}</p>
            <p className="text-sm text-muted-foreground">{new Date(post.created_date || Date.now()).toLocaleDateString('fr-FR')}</p>
          </div>
        </div>
        <div className="flex flex-wrap justify-end gap-2">
          {post.post_type === 'pattern' && <Badge className="rounded-full" variant="outline">{post.difficulty}</Badge>}
          {post.post_type === 'pattern' && <Badge className="rounded-full" variant="outline">{post.technique}</Badge>}
          <Badge className="rounded-full" variant="secondary">{labels[post.post_type] || 'Post'}</Badge>
        </div>
      </div>
      <p className="mt-5 whitespace-pre-line leading-8 text-foreground/90">{post.content}</p>
      {post.image_url && <img src={post.image_url} alt="Post" className="mt-5 rounded-3xl border border-border" />}
      <div className="mt-6 flex items-center gap-2">
        <Button variant="ghost" size="sm" className="rounded-full"><Heart className="mr-2 h-4 w-4" /> {post.likes || 0}</Button>
        <Button variant="ghost" size="sm" className="rounded-full"><MessageCircle className="mr-2 h-4 w-4" /> Commenter</Button>
      </div>
    </article>
  );
}