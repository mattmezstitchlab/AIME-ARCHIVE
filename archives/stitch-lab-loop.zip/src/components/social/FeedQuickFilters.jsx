import React from 'react';
import { Filter } from 'lucide-react';

const difficulties = ['tous', 'débutant', 'intermédiaire', 'avancé'];
const techniques = ['toutes', 'point de croix', 'blackwork', 'broderie traditionnelle', 'sashiko', 'perles'];

export default function FeedQuickFilters({ filters, onChange }) {
  return (
    <div className="rounded-md border border-border bg-card p-4 shadow-sm">
      <div className="mb-4 flex items-center gap-2 text-sm uppercase tracking-[0.28em] text-muted-foreground">
        <Filter className="h-4 w-4" /> Filtres patrons
      </div>
      <div className="space-y-3">
        <div className="flex flex-wrap gap-2">
          {difficulties.map((difficulty) => (
            <button
              key={difficulty}
              onClick={() => onChange({ ...filters, difficulty })}
              className={`rounded-full px-3 py-1 text-sm transition-all ${filters.difficulty === difficulty ? 'bg-primary text-primary-foreground' : 'bg-secondary text-muted-foreground hover:text-foreground'}`}
            >
              {difficulty}
            </button>
          ))}
        </div>
        <div className="flex flex-wrap gap-2">
          {techniques.map((technique) => (
            <button
              key={technique}
              onClick={() => onChange({ ...filters, technique })}
              className={`rounded-full px-3 py-1 text-sm transition-all ${filters.technique === technique ? 'bg-accent text-accent-foreground' : 'bg-secondary text-muted-foreground hover:text-foreground'}`}
            >
              {technique}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}