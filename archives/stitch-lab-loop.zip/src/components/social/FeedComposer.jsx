import React, { useState } from 'react';
import { Send } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export default function FeedComposer({ user, onCreated }) {
  const [content, setContent] = useState('');
  const [postType, setPostType] = useState('progress');
  const [difficulty, setDifficulty] = useState('débutant');
  const [technique, setTechnique] = useState('point de croix');

  const submit = async () => {
    if (!content.trim()) return;
    await base44.entities.SocialPost.create({
      content,
      post_type: postType,
      difficulty: postType === 'pattern' ? difficulty : undefined,
      technique: postType === 'pattern' ? technique : undefined,
      author_name: user?.full_name || 'Brodeur·se anonyme',
      likes: 0,
      tags: ['stitchlab']
    });
    setContent('');
    onCreated?.();
  };

  return (
    <div className="rounded-[2rem] border border-border bg-card p-5 shadow-sm">
      <Textarea value={content} onChange={(e) => setContent(e.target.value)} placeholder="Partage ton avancée, une question ou une palette..." className="min-h-28 resize-none border-0 bg-secondary/60 text-base shadow-none focus-visible:ring-0" />
      <div className="mt-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <Select value={postType} onValueChange={setPostType}>
          <SelectTrigger className="rounded-full sm:w-48"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="progress">Avancée</SelectItem>
            <SelectItem value="pattern">Patron</SelectItem>
            <SelectItem value="sal">SAL</SelectItem>
            <SelectItem value="question">Question</SelectItem>
          </SelectContent>
        </Select>
        {postType === 'pattern' && (
          <div className="flex flex-col gap-3 sm:flex-row">
            <Select value={difficulty} onValueChange={setDifficulty}>
              <SelectTrigger className="rounded-full sm:w-44"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="débutant">Débutant</SelectItem>
                <SelectItem value="intermédiaire">Intermédiaire</SelectItem>
                <SelectItem value="avancé">Avancé</SelectItem>
              </SelectContent>
            </Select>
            <Select value={technique} onValueChange={setTechnique}>
              <SelectTrigger className="rounded-full sm:w-56"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="point de croix">Point de croix</SelectItem>
                <SelectItem value="blackwork">Blackwork</SelectItem>
                <SelectItem value="broderie traditionnelle">Broderie traditionnelle</SelectItem>
                <SelectItem value="sashiko">Sashiko</SelectItem>
                <SelectItem value="perles">Perles</SelectItem>
              </SelectContent>
            </Select>
          </div>
        )}
        <Button onClick={submit} className="rounded-full"><Send className="mr-2 h-4 w-4" /> Publier</Button>
      </div>
    </div>
  );
}