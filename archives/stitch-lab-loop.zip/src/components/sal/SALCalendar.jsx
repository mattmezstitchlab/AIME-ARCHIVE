import React from 'react';
import { CalendarDays } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

export default function SALCalendar({ groups }) {
  const upcoming = groups
    .filter((group) => group.start_date)
    .sort((a, b) => new Date(a.start_date) - new Date(b.start_date))
    .slice(0, 6);

  return (
    <section className="rounded-md border border-border bg-card p-6 shadow-sm">
      <div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-center">
        <div>
          <p className="text-sm uppercase tracking-[0.3em] text-muted-foreground">Calendrier SAL</p>
          <h2 className="mt-2 font-serif text-3xl font-black uppercase tracking-tight">Départs à venir</h2>
        </div>
        <CalendarDays className="h-8 w-8 text-primary" />
      </div>
      <div className="mt-6 grid gap-3 md:grid-cols-2 lg:grid-cols-3">
        {upcoming.map((group) => {
          const date = new Date(group.start_date);
          return (
            <article key={group.id} className="rounded-md bg-secondary p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="text-center">
                  <p className="text-xs uppercase text-muted-foreground">{date.toLocaleDateString('fr-FR', { month: 'short' })}</p>
                  <p className="font-serif text-3xl font-black">{date.getDate()}</p>
                </div>
                <Badge variant="secondary" className="rounded-full bg-primary text-primary-foreground">{group.status}</Badge>
              </div>
              <h3 className="mt-4 font-medium">{group.title}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{group.city} · {group.theme}</p>
            </article>
          );
        })}
        {upcoming.length === 0 && <p className="text-sm text-muted-foreground">Aucune date de départ renseignée pour le moment.</p>}
      </div>
    </section>
  );
}