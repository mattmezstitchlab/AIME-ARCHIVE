import React from 'react';
import { MapPin } from 'lucide-react';

export default function SALMap({ groups }) {
  return (
    <div className="relative min-h-[420px] overflow-hidden rounded-md border border-border bg-secondary shadow-sm">
      <div className="absolute inset-0 opacity-80 bg-[radial-gradient(circle_at_30%_25%,#F15156_0,transparent_22%),radial-gradient(circle_at_70%_60%,#17BEBB_0,transparent_24%),radial-gradient(circle_at_45%_80%,#F2CC8F_0,transparent_18%)]" />
      <div className="absolute inset-6 rounded-[1.5rem] border border-background/70" />
      {groups.map((group, index) => {
        const left = `${20 + ((group.longitude || index * 18) + 180) % 60}%`;
        const top = `${18 + ((90 - (group.latitude || index * 12)) % 55)}%`;
        return (
          <div key={group.id} className="absolute -translate-x-1/2 -translate-y-1/2" style={{ left, top }}>
            <div className="group relative flex h-12 w-12 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-2xl">
              <MapPin className="h-5 w-5" />
              <div className="absolute bottom-14 hidden w-48 rounded-2xl bg-card p-3 text-sm text-foreground shadow-xl group-hover:block">
                <p className="font-medium">{group.title}</p>
                <p className="text-muted-foreground">{group.city}, {group.country}</p>
              </div>
            </div>
          </div>
        );
      })}
      <div className="absolute bottom-5 left-5 rounded-2xl bg-card/90 p-4 text-sm shadow-xl backdrop-blur-xl">
        <p className="font-medium">Carte SAL Sync</p>
        <p className="text-muted-foreground">Groupes géolocalisés de la communauté</p>
      </div>
    </div>
  );
}