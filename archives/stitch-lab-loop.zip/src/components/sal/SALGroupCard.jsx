import React from 'react';
import { MapPin, Palette, Users } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

export default function SALGroupCard({ group }) {
  return (
    <article className="overflow-hidden rounded-md border border-border bg-card shadow-sm transition-all duration-300 hover:-translate-y-1 hover:bg-muted">
      <div className="relative h-28 bg-secondary">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_25%_35%,#17BEBB_0,transparent_24%),radial-gradient(circle_at_75%_25%,#F15156_0,transparent_20%),radial-gradient(circle_at_50%_85%,#F2CC8F_0,transparent_26%)] opacity-80" />
        <div className="absolute inset-4 rounded-md border border-background/60" />
        <div className="absolute bottom-4 left-4 flex items-center gap-2 rounded-full bg-card/90 px-3 py-1 text-sm backdrop-blur-xl">
          <MapPin className="h-4 w-4 text-primary" /> {group.city}, {group.country}
        </div>
      </div>
      <div className="p-6">
        <div className="flex items-center justify-between gap-3">
          <Badge variant="secondary" className="rounded-full">{group.status}</Badge>
          <span className="text-sm text-muted-foreground"><Users className="mr-1 inline h-4 w-4" /> {group.member_count || 1}</span>
        </div>
        <h3 className="mt-5 font-serif text-2xl font-black uppercase tracking-tight">{group.title}</h3>
        <div className="mt-3 flex items-center gap-2 text-sm text-muted-foreground">
          <Palette className="h-4 w-4 text-accent" /> Thème : {group.theme || 'Libre'}
        </div>
        <p className="mt-4 line-clamp-3 leading-7 text-foreground/80">{group.description}</p>
      </div>
    </article>
  );
}