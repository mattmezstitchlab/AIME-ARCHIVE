import React, { useState } from 'react';
import { Plus } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';

export default function SALForm({ isPro, onCreated }) {
  const [form, setForm] = useState({ title: '', city: '', country: 'France', description: '', theme: 'Floral', latitude: 48.86, longitude: 2.35 });

  const submit = async () => {
    if (!isPro || !form.title || !form.city) return;
    await base44.entities.SALGroup.create(form);
    setForm({ title: '', city: '', country: 'France', description: '', theme: 'Floral', latitude: 48.86, longitude: 2.35 });
    onCreated?.();
  };

  return (
    <div className="rounded-[2rem] border border-border bg-card p-6 shadow-sm">
      <h2 className="font-serif text-3xl">Créer un SAL</h2>
      {!isPro && <p className="mt-3 rounded-2xl bg-secondary p-4 text-sm text-muted-foreground">La création de SAL est réservée aux membres Pro.</p>}
      <div className="mt-5 space-y-3 opacity-100">
        <Input disabled={!isPro} value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Titre du SAL" className="rounded-2xl" />
        <div className="grid gap-3 sm:grid-cols-2">
          <Input disabled={!isPro} value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} placeholder="Ville" className="rounded-2xl" />
          <Input disabled={!isPro} value={form.country} onChange={(e) => setForm({ ...form, country: e.target.value })} placeholder="Pays" className="rounded-2xl" />
        </div>
        <Textarea disabled={!isPro} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Description" className="rounded-2xl" />
        <Button disabled={!isPro} onClick={submit} className="w-full rounded-full"><Plus className="mr-2 h-4 w-4" /> Créer le groupe</Button>
      </div>
    </div>
  );
}