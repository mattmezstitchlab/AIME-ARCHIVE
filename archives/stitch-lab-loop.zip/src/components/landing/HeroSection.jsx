import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowRight, Grid3X3, MapPin, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { DMC_PALETTE } from '@/lib/dmcPalette';

export default function HeroSection() {
  return (
    <section className="relative overflow-hidden px-4 py-24 sm:px-6 lg:px-8">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_20%,hsl(var(--accent))_0,transparent_30%),radial-gradient(circle_at_80%_0%,hsl(var(--secondary))_0,transparent_28%)]" />
      <div className="relative mx-auto grid max-w-7xl items-center gap-16 lg:grid-cols-[1.05fr_0.95fr]">
        <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7 }}>
          <div className="mb-8 inline-flex items-center gap-2 rounded-full border border-border bg-card/70 px-4 py-2 text-sm text-muted-foreground shadow-sm backdrop-blur-xl">
            <Sparkles className="h-4 w-4 text-primary" /> Le monde social de la broderie moderne
          </div>
          <h1 className="font-serif text-5xl font-black uppercase leading-[0.92] tracking-tight text-foreground sm:text-7xl lg:text-8xl">
            Brodez seule, créez ensemble.
          </h1>
          <p className="mt-8 max-w-2xl text-lg leading-8 text-muted-foreground sm:text-xl">
            Transformez vos images en patrons, placez vos points sur un canvas mondial et rejoignez des stitch-alongs près de chez vous.
          </p>
          <div className="mt-10 flex flex-col gap-3 sm:flex-row">
            <Button asChild size="lg" className="rounded-full px-7 py-6 text-base">
              <Link to="/feed">Entrer dans StitchLab <ArrowRight className="ml-2 h-4 w-4" /></Link>
            </Button>
            <Button asChild variant="outline" size="lg" className="rounded-full px-7 py-6 text-base">
              <Link to="/patterns">Créer un patron</Link>
            </Button>
          </div>
        </motion.div>

        <motion.div initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.8, delay: 0.1 }} className="relative">
          <div className="rounded-[2.5rem] border border-border/80 bg-card/80 p-5 shadow-2xl backdrop-blur-2xl">
            <div className="rounded-[2rem] bg-secondary/80 p-5">
              <div className="mb-4 flex items-center gap-3 text-xs font-semibold uppercase tracking-[0.24em] text-muted-foreground">
                <Sparkles className="h-4 w-4 text-primary" /> Nuancier DMC réel
              </div>
              <div className="flex flex-wrap gap-2.5">
                {DMC_PALETTE.slice(0, 30).map((thread) => (
                  <div key={thread.code} className="flex items-center gap-2 rounded-full bg-background/60 px-2 py-1.5">
                    <span className="flex h-9 w-9 items-center justify-center rounded-full text-xs font-black text-black/75 shadow-sm" style={{ backgroundColor: thread.hex }}>{thread.symbol}</span>
                    <span className="text-[10px] font-bold text-foreground/80">{thread.code}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <div className="absolute -bottom-8 -left-6 rounded-3xl border border-border bg-card p-5 shadow-xl">
            <Grid3X3 className="mb-3 h-5 w-5" />
            <p className="font-medium">Canvas collaboratif</p>
            <p className="text-sm text-muted-foreground">10k × 50k points</p>
          </div>
          <div className="absolute -right-4 top-10 rounded-3xl border border-border bg-card p-5 shadow-xl">
            <MapPin className="mb-3 h-5 w-5" />
            <p className="font-medium">SAL près de vous</p>
            <p className="text-sm text-muted-foreground">Groupes géolocalisés</p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}