import React from 'react';
import { Grid3X3, Image, MapPin, MessageCircle } from 'lucide-react';

const features = [
  { icon: Image, title: 'Pattern Generator', text: 'Convertissez vos images en grilles point de croix avec palette, symboles et estimation de temps.' },
  { icon: Grid3X3, title: 'Grid World', text: 'Un monde brodé collaboratif où chaque point posé devient une trace visible de la communauté.' },
  { icon: MapPin, title: 'SAL Sync', text: 'Trouvez ou lancez des stitch-alongs localisés, avec groupes, dates et thèmes partagés.' },
  { icon: MessageCircle, title: 'Feed social', text: 'Partagez vos avancées, questions, palettes et patrons avec une communauté ouverte.' }
];

export default function FeatureGrid() {
  return (
    <section className="px-4 py-20 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <div className="mb-12 max-w-2xl">
          <p className="text-sm uppercase tracking-[0.35em] text-muted-foreground">Les piliers</p>
          <h2 className="mt-4 font-serif text-4xl tracking-tight sm:text-5xl">Une plateforme pensée comme un atelier vivant.</h2>
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {features.map((feature) => (
            <div key={feature.title} className="group rounded-md border border-border bg-card p-7 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:bg-muted">
              <div className="mb-8 flex h-12 w-12 items-center justify-center rounded-2xl bg-secondary text-foreground transition-all group-hover:bg-primary group-hover:text-primary-foreground">
                <feature.icon className="h-5 w-5" />
              </div>
              <h3 className="font-serif text-2xl font-black uppercase tracking-tight">{feature.title}</h3>
              <p className="mt-4 leading-7 text-muted-foreground">{feature.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}