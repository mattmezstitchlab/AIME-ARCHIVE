import React from 'react';
import { Crown, Lock, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function PricingRoadmap() {
  return (
    <section className="px-4 py-20 sm:px-6 lg:px-8">
      <div className="mx-auto grid max-w-7xl gap-8 lg:grid-cols-[0.9fr_1.1fr]">
        <div className="rounded-[2.5rem] bg-primary p-8 text-primary-foreground shadow-2xl sm:p-10">
          <Crown className="h-8 w-8" />
          <h2 className="mt-8 font-serif text-4xl tracking-tight">Pro — 9,99€/mois</h2>
          <p className="mt-4 text-primary-foreground/75">Le feed social reste gratuit. Le Pro débloque la création de SAL et le placement de points dans le Grid World.</p>
          <div className="mt-8 space-y-4 text-sm">
            {['Créer des SAL localisés', 'Poser des points sur le Grid World', 'Accès aux futurs outils IA avancés'].map((item) => (
              <div key={item} className="flex items-center gap-3"><Sparkles className="h-4 w-4" /> {item}</div>
            ))}
          </div>
          <Button variant="secondary" className="mt-8 rounded-full">Rejoindre la liste Pro</Button>
        </div>
        <div className="rounded-[2.5rem] border border-border bg-card p-8 shadow-sm sm:p-10">
          <div className="flex items-center gap-3 text-muted-foreground"><Lock className="h-4 w-4" /> Roadmap MVP</div>
          <div className="mt-8 grid gap-4 sm:grid-cols-2">
            {['Semaine 1–2 : Feed, profils, base sociale', 'Semaine 3–4 : Générateur de patrons', 'Semaine 5–7 : Grid World temps réel', 'Semaine 8–10 : SAL Sync + carte', 'Semaine 11 : Paiement Pro', 'Semaine 12 : polish, mobile, lancement'].map((step) => (
              <div key={step} className="rounded-3xl bg-secondary/70 p-5 text-sm leading-6">{step}</div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}