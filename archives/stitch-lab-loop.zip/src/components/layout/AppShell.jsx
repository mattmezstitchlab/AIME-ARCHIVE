import React from 'react';
import { Link, NavLink, Outlet } from 'react-router-dom';
import { Grid3X3, MessageCircle, MapPin, Image, Crown } from 'lucide-react';
import StitchLabLogoMark from '@/components/brand/StitchLabLogoMark';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';

const navItems = [
  { to: '/feed', label: 'Feed', icon: MessageCircle },
  { to: '/patterns', label: 'Patrons', icon: Image },
  { to: '/grid-world', label: 'Grid World', icon: Grid3X3 },
  { to: '/sal-sync', label: 'SAL Sync', icon: MapPin }
];

export default function AppShell() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur-2xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 sm:px-6 lg:px-8">
          <Link to="/" className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center text-foreground">
              <StitchLabLogoMark className="h-11 w-11" />
            </div>
            <div>
              <p className="font-serif text-xl font-black uppercase tracking-tight">StitchLab</p>
              <p className="text-xs uppercase tracking-[0.28em] text-muted-foreground">World</p>
            </div>
          </Link>

          <nav className="hidden items-center gap-2 md:flex">
            {navItems.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) =>
                  `flex items-center gap-2 rounded-full px-4 py-2 text-sm transition-all ${isActive ? 'bg-secondary text-foreground shadow-sm' : 'text-muted-foreground hover:bg-secondary/70 hover:text-foreground'}`
                }
              >
                <item.icon className="h-4 w-4" />
                <span className="sr-only">{item.label}</span>
              </NavLink>
            ))}
          </nav>

          <Button onClick={() => base44.auth.redirectToLogin('/feed')} className="hidden rounded-full md:inline-flex">
            <Crown className="mr-2 h-4 w-4" /> Passer Pro
          </Button>
        </div>
      </header>

      <main>
        <Outlet />
      </main>

      <nav className="fixed bottom-4 left-1/2 z-50 flex -translate-x-1/2 rounded-full border border-border/70 bg-card/90 p-2 shadow-2xl backdrop-blur-2xl md:hidden">
        {navItems.map((item) => (
          <NavLink key={item.to} to={item.to} className={({ isActive }) => `rounded-full p-3 ${isActive ? 'bg-primary text-primary-foreground' : 'text-muted-foreground'}`}>
            <item.icon className="h-5 w-5" />
          </NavLink>
        ))}
      </nav>
    </div>
  );
}