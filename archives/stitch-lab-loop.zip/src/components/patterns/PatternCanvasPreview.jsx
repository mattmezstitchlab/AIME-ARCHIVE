import React from 'react';
import { Palette } from 'lucide-react';

export default function PatternCanvasPreview({ sourceImageUrl, cells, width, height, maxColors, estimatedHours, difficulty }) {
  return (
    <div className="rounded-[2rem] border border-border bg-card p-4 shadow-sm">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3 text-sm text-muted-foreground">
        <span className="flex items-center gap-2"><Palette className="h-4 w-4" /> {maxColors} couleurs DMC · {width * height} points · {estimatedHours}h</span>
        <span>{difficulty}</span>
      </div>
      {sourceImageUrl && <img src={sourceImageUrl} alt="Source du patron" className="mb-4 max-h-56 w-full rounded-3xl border border-border object-cover" />}
      {cells.length > 0 ? (
        <div className="grid overflow-hidden rounded-3xl border border-border bg-[linear-gradient(45deg,hsl(var(--secondary))_25%,transparent_25%),linear-gradient(-45deg,hsl(var(--secondary))_25%,transparent_25%)]" style={{ gridTemplateColumns: `repeat(${width}, minmax(0, 1fr))` }}>
          {cells.map((cell, i) => <div key={i} className="flex aspect-square items-center justify-center text-[8px] text-white/75" style={{ backgroundColor: cell.color }}>{cell.symbol}</div>)}
        </div>
      ) : (
        <div className="flex min-h-[420px] items-center justify-center rounded-3xl border border-dashed border-border bg-secondary/50 p-8 text-center text-muted-foreground">
          Génère un prompt ou importe une image pour créer la grille DMC.
        </div>
      )}
    </div>
  );
}