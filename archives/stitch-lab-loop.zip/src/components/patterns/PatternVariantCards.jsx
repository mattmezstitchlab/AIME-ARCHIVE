import React from 'react';
import { Gem, Leaf, Zap } from 'lucide-react';

const variants = [
  { label: 'Version facile', icon: Leaf, width: 36, height: 36, colors: 10, text: 'Peu de couleurs, zones lisibles, parfaite débutante.' },
  { label: 'Version détaillée', icon: Zap, width: 56, height: 56, colors: 16, text: 'Bon équilibre entre rendu visuel et plaisir de broder.' },
  { label: 'Version premium', icon: Gem, width: 72, height: 72, colors: 22, text: 'Rendu riche, plus proche illustration et marketplace.' }
];

export default function PatternVariantCards({ onSelect }) {
  return (
    <div className="grid gap-3 md:grid-cols-3">
      {variants.map((variant) => {
        const Icon = variant.icon;
        return (
          <button key={variant.label} onClick={() => onSelect(variant)} className="rounded-3xl border border-border bg-card/80 p-4 text-left transition hover:-translate-y-0.5 hover:border-primary/60 hover:shadow-xl">
            <Icon className="mb-3 h-5 w-5 text-primary" />
            <p className="font-medium">{variant.label}</p>
            <p className="mt-1 text-xs leading-5 text-muted-foreground">{variant.text}</p>
            <p className="mt-3 text-xs text-primary">{variant.width}×{variant.height} · {variant.colors} DMC</p>
          </button>
        );
      })}
    </div>
  );
}