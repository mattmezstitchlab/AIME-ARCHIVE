import React, { useMemo, useRef, useState } from 'react';
import { Download, Image, Loader2, Palette, Wand2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { buildPatternFromCanvas, imageFileToCanvas, imageUrlToCanvas } from '@/lib/patternImageEngine';
import { analyzePattern, cleanConfetti, getThreadStats, simplifyPatternPalette } from '@/lib/patternIntelligence';
import PatternCanvasPreview from '@/components/patterns/PatternCanvasPreview';
import PatternIntelligencePanel from '@/components/patterns/PatternIntelligencePanel';
import PatternPalettePanel from '@/components/patterns/PatternPalettePanel';
import PatternVariantCards from '@/components/patterns/PatternVariantCards';
import PatternBeforeAfterCompare from '@/components/patterns/PatternBeforeAfterCompare';
import SmartPathingPanel from '@/components/patterns/SmartPathingPanel';

export default function PatternGenerator({ onSaved }) {
  const [title, setTitle] = useState('Patron IA StitchLab');
  const [description, setDescription] = useState('');
  const [prompt, setPrompt] = useState('renard mystique style folk art, fleurs, palette douce, illustration claire');
  const [width, setWidth] = useState(48);
  const [height, setHeight] = useState(48);
  const [maxColors, setMaxColors] = useState(16);
  const [sourceImageUrl, setSourceImageUrl] = useState('');
  const [sourceType, setSourceType] = useState('prompt');
  const [cells, setCells] = useState([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const sourceCanvasRef = useRef(null);

  const analysis = useMemo(() => analyzePattern(cells, width, height), [cells, width, height]);
  const dmcColors = analysis.threadStats.map((thread) => ({ code: thread.code, name: thread.name, hex: thread.hex, symbol: thread.symbol }));
  const estimatedHours = Math.max(1, Math.round((width * height + analysis.pathChanges * 0.25) / 70));
  const difficulty = analysis.score && analysis.score < 70 ? 'avancé' : width * height > 2200 ? 'intermédiaire' : 'débutant';

  const convertCanvasToPattern = (canvas, options = {}) => {
    const nextWidth = options.width || width;
    const nextHeight = options.height || height;
    const nextMaxColors = options.maxColors || maxColors;
    const pattern = buildPatternFromCanvas(canvas, nextWidth, nextHeight, nextMaxColors);
    setCells(pattern.cells);
  };

  const generateFromPrompt = async () => {
    if (!prompt.trim()) return;
    setIsGenerating(true);
    const result = await base44.integrations.Core.GenerateImage({
      prompt: `${prompt}. Cross stitch pattern source image, clean centered composition, high contrast, simple readable shapes, limited color palette, no text, no watermark.`
    });
    setSourceImageUrl(result.url);
    setSourceType('prompt');
    const canvas = await imageUrlToCanvas(result.url);
    sourceCanvasRef.current = canvas;
    convertCanvasToPattern(canvas);
    setIsGenerating(false);
  };

  const generateFromImage = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    setIsGenerating(true);
    const upload = await base44.integrations.Core.UploadFile({ file });
    setSourceImageUrl(upload.file_url);
    setSourceType('image');
    const canvas = await imageFileToCanvas(file);
    sourceCanvasRef.current = canvas;
    convertCanvasToPattern(canvas);
    setIsGenerating(false);
  };

  const selectVariant = (variant) => {
    setWidth(variant.width);
    setHeight(variant.height);
    setMaxColors(variant.colors);
    if (sourceCanvasRef.current) {
      convertCanvasToPattern(sourceCanvasRef.current, { width: variant.width, height: variant.height, maxColors: variant.colors });
    }
  };

  const handleCleanConfetti = () => {
    setCells((current) => cleanConfetti(current, width, height));
  };

  const handleSimplifyPalette = () => {
    const target = Math.max(6, Math.min(12, maxColors - 4));
    setMaxColors(target);
    setCells((current) => simplifyPatternPalette(current, target));
  };

  const save = async () => {
    if (!cells.length) return;
    await base44.entities.Pattern.create({
      title,
      description,
      source_image_url: sourceImageUrl,
      source_prompt: sourceType === 'prompt' ? prompt : '',
      source_type: sourceType,
      width,
      height,
      colors: dmcColors.map((color) => `${color.code} ${color.hex}`),
      grid_data: cells,
      visibility: 'private',
      difficulty,
      estimated_hours: estimatedHours
    });
    onSaved?.();
  };

  const exportTxt = () => {
    const palette = analysis.threadStats.map((color) => `${color.symbol} DMC ${color.code} — ${color.name} — ${color.stitches} points`).join('\n');
    const content = `${title}\n${width} × ${height} points\nBrodabilité ${analysis.score}/100 · ${difficulty} · ${estimatedHours}h estimées\n\nPalette DMC:\n${palette}`;
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${title}.txt`;
    link.click();
  };

  return (
    <div className="space-y-6">
      <div className="grid gap-6 xl:grid-cols-[0.36fr_0.64fr]">
        <div className="space-y-4 rounded-[2rem] border border-border bg-card p-6 shadow-sm">
          <Palette className="h-6 w-6 text-primary" />
          <div>
            <h2 className="font-serif text-3xl tracking-tight">Atelier IA intelligent</h2>
            <p className="mt-3 text-sm leading-6 text-muted-foreground">Crée, juge et optimise automatiquement un patron vraiment brodable avec DMC, score qualité et corrections magiques.</p>
          </div>

          <Input value={title} onChange={(e) => setTitle(e.target.value)} className="rounded-2xl" placeholder="Nom du patron" />
          <Textarea value={prompt} onChange={(e) => setPrompt(e.target.value)} placeholder="Décris le patron à générer..." className="min-h-24 rounded-2xl" />
          <Textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Notes du patron..." className="rounded-2xl" />

          <div className="grid gap-3 sm:grid-cols-3">
            <Input type="number" min="16" max="120" value={width} onChange={(e) => setWidth(Number(e.target.value))} className="rounded-2xl" placeholder="Largeur" />
            <Input type="number" min="16" max="120" value={height} onChange={(e) => setHeight(Number(e.target.value))} className="rounded-2xl" placeholder="Hauteur" />
            <Input type="number" min="4" max="30" value={maxColors} onChange={(e) => setMaxColors(Number(e.target.value))} className="rounded-2xl" placeholder="Couleurs" />
          </div>

          <div className="grid gap-3 sm:grid-cols-2">
            <Button onClick={generateFromPrompt} disabled={isGenerating} className="rounded-full">
              {isGenerating ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Wand2 className="mr-2 h-4 w-4" />}
              Générer magique
            </Button>
            <label className="inline-flex h-9 cursor-pointer items-center justify-center rounded-full border border-input bg-transparent px-4 py-2 text-sm font-medium shadow-sm hover:bg-accent hover:text-accent-foreground">
              <Image className="mr-2 h-4 w-4" /> Importer image
              <input type="file" accept="image/*" onChange={generateFromImage} className="hidden" />
            </label>
          </div>

          <div className="flex gap-3">
            <Button onClick={save} disabled={!cells.length} className="flex-1 rounded-full">Enregistrer le patron</Button>
            <Button onClick={exportTxt} disabled={!cells.length} variant="outline" className="rounded-full"><Download className="h-4 w-4" /></Button>
          </div>
        </div>

        <div className="space-y-4">
          <PatternCanvasPreview
            sourceImageUrl={sourceImageUrl}
            cells={cells}
            width={width}
            height={height}
            maxColors={analysis.threadStats.length || maxColors}
            estimatedHours={estimatedHours}
            difficulty={difficulty}
          />
          <PatternVariantCards onSelect={selectVariant} />
        </div>
      </div>

      <PatternBeforeAfterCompare sourceImageUrl={sourceImageUrl} cells={cells} width={width} height={height} />

      <div className="grid gap-4 lg:grid-cols-[0.42fr_0.58fr]">
        <PatternIntelligencePanel analysis={analysis} onClean={handleCleanConfetti} onSimplify={handleSimplifyPalette} />
        <PatternPalettePanel threads={analysis.threadStats} />
      </div>

      <SmartPathingPanel cells={cells} />
    </div>
  );
}