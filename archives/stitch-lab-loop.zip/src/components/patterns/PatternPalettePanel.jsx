import React from 'react';
import { Layers, Route, ShoppingBag } from 'lucide-react';

export default function PatternPalettePanel({ threads }) {
  if (!threads.length) return null;

  return (
    <div className="rounded-3xl border border-border bg-secondary/40 p-4">
      <div className="mb-3 flex items-center justify-between gap-3">
        <div>
          <p className="flex items-center gap-2 text-xs uppercase tracking-[0.25em] text-muted-foreground"><Layers className="h-3.5 w-3.5" /> Palette professionnelle</p>
          <h3 className="mt-1 font-serif text-2xl">DMC dans l’ordre de travail</h3>
        </div>
        <span className="flex items-center gap-1 rounded-full bg-primary/10 px-3 py-1 text-xs text-primary"><ShoppingBag className="h-3.5 w-3.5" /> inventaire</span>
      </div>

      <div className="max-h-80 space-y-2 overflow-auto pr-1">
        {threads.map((thread, index) => (
          <div key={thread.code} className="grid grid-cols-[auto_1fr_auto] items-center gap-3 rounded-2xl bg-card/70 p-3 text-sm">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl border border-border text-xs font-bold text-black" style={{ backgroundColor: thread.hex }}>{index + 1}</span>
            <div className="min-w-0">
              <p className="font-medium">DMC {thread.code} · {thread.name}</p>
              <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-secondary">
                <div className="h-full rounded-full bg-primary" style={{ width: `${Math.max(8, Math.min(100, thread.stitches / threads[0].stitches * 100))}%` }} />
              </div>
              <p className="mt-1 flex items-center gap-1 text-xs text-muted-foreground"><Route className="h-3 w-3" /> À broder étape {index + 1}, en zones continues</p>
            </div>
            <p className="text-right text-xs text-muted-foreground"><span className="block font-semibold text-foreground">{thread.stitches}</span> points</p>
          </div>
        ))}
      </div>
    </div>
  );
}