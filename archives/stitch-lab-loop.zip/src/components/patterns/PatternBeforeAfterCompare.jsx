import React, { useState } from 'react';
import { ChevronsLeftRight, Image, Grid3X3 } from 'lucide-react';

export default function PatternBeforeAfterCompare({ sourceImageUrl, cells, width, height }) {
  const [position, setPosition] = useState(50);
  if (!sourceImageUrl || !cells.length) return null;

  return (
    <div className="overflow-hidden rounded-[2rem] border border-border bg-card shadow-2xl">
      <div className="flex items-center justify-between gap-3 border-b border-border bg-secondary/50 px-4 py-3">
        <div>
          <p className="text-xs uppercase tracking-[0.28em] text-muted-foreground">Comparaison IA</p>
          <h3 className="font-serif text-2xl">Image source → grille brodable</h3>
        </div>
        <ChevronsLeftRight className="h-5 w-5 text-primary" />
      </div>

      <div className="relative aspect-[16/10] select-none overflow-hidden bg-secondary">
        <div className="absolute inset-0">
          <img src={sourceImageUrl} alt="Image source" className="h-full w-full object-cover" />
          <div className="absolute left-4 top-4 rounded-full bg-black/55 px-3 py-1 text-xs text-white backdrop-blur"><Image className="mr-1 inline h-3 w-3" /> Avant</div>
        </div>

        <div className="absolute inset-0 overflow-hidden" style={{ clipPath: `inset(0 0 0 ${position}%)` }}>
          <GeneratedGrid cells={cells} width={width} height={height} />
          <div className="absolute right-4 top-4 rounded-full bg-primary px-3 py-1 text-xs text-primary-foreground shadow-xl"><Grid3X3 className="mr-1 inline h-3 w-3" /> Après IA</div>
        </div>

        <div className="absolute inset-y-0 z-20 w-0.5 bg-white shadow-[0_0_24px_rgba(255,255,255,0.8)]" style={{ left: `${position}%` }}>
          <div className="absolute left-1/2 top-1/2 flex h-12 w-12 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full border border-white/70 bg-black/55 text-white backdrop-blur-xl">
            <ChevronsLeftRight className="h-5 w-5" />
          </div>
        </div>

        <input
          type="range"
          min="8"
          max="92"
          value={position}
          onChange={(event) => setPosition(Number(event.target.value))}
          className="absolute inset-0 z-30 h-full w-full cursor-ew-resize opacity-0"
          aria-label="Comparer avant après"
        />
      </div>
    </div>
  );
}

function GeneratedGrid({ cells, width, height }) {
  return (
    <div className="flex h-full w-full items-center justify-center bg-white p-6">
      <div className="grid max-h-full max-w-full overflow-hidden rounded-2xl border border-slate-300 shadow-2xl" style={{ gridTemplateColumns: `repeat(${width}, minmax(0, 1fr))`, aspectRatio: `${width}/${height}` }}>
        {cells.map((cell, index) => (
          <div key={index} className="flex items-center justify-center border border-white/20 text-[7px] font-bold text-black/70" style={{ backgroundColor: cell.color }}>
            {cell.symbol}
          </div>
        ))}
      </div>
    </div>
  );
}