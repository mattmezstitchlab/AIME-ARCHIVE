import React from 'react';
import { Gauge, Palette, Wand2, Route, Scissors } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function PatternIntelligencePanel({ analysis, onClean, onSimplify }) {
  const hasPattern = analysis.score > 0;

  return (
    <div className="rounded-3xl border border-border bg-secondary/40 p-4">
      <div className="flex items-center justify-between gap-4">
        <div>
          <p className="flex items-center gap-2 text-xs uppercase tracking-[0.25em] text-muted-foreground"><Gauge className="h-3.5 w-3.5" /> Brodabilité</p>
          <h3 className="mt-2 font-serif text-4xl">{hasPattern ? `${analysis.score}/100` : '—'}</h3>
          <p className="text-sm text-muted-foreground">{analysis.verdict}</p>
        </div>
        <div className="flex h-20 w-20 items-center justify-center rounded-full border border-primary/40 bg-primary/10 text-primary shadow-inner">
          <Palette className="h-8 w-8" />
        </div>
      </div>

      <div className="mt-4 grid gap-2 text-sm sm:grid-cols-3">
        <SmartMetric icon={Scissors} label="Confetti" value={hasPattern ? analysis.confettiCount : '—'} />
        <SmartMetric icon={Route} label="Changements" value={hasPattern ? analysis.pathChanges : '—'} />
        <SmartMetric icon={Wand2} label="Fils" value={hasPattern ? analysis.threadStats.length : '—'} />
      </div>

      <div className="mt-4 grid gap-2 sm:grid-cols-2">
        <Button onClick={onClean} disabled={!hasPattern} variant="outline" className="rounded-full">Nettoyer confetti</Button>
        <Button onClick={onSimplify} disabled={!hasPattern} variant="outline" className="rounded-full">Simplifier palette</Button>
      </div>
    </div>
  );
}

function SmartMetric({ icon: Icon, label, value }) {
  return (
    <div className="rounded-2xl bg-card/70 p-3">
      <Icon className="mb-2 h-4 w-4 text-primary" />
      <p className="text-lg font-semibold">{value}</p>
      <p className="text-xs text-muted-foreground">{label}</p>
    </div>
  );
}