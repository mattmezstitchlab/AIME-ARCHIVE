import React, { useMemo } from 'react';
import { Route, Scissors, Footprints, ArrowRight } from 'lucide-react';

export default function SmartPathingPanel({ cells }) {
  const path = useMemo(() => buildSmartPath(cells), [cells]);
  if (!cells.length) return null;

  return (
    <div className="rounded-3xl border border-border bg-secondary/40 p-4">
      <div className="mb-4 flex items-center justify-between gap-3">
        <div>
          <p className="flex items-center gap-2 text-xs uppercase tracking-[0.25em] text-muted-foreground"><Route className="h-3.5 w-3.5" /> Smart Pathing</p>
          <h3 className="mt-1 font-serif text-2xl">Chemin optimal de broderie</h3>
        </div>
        <div className="rounded-2xl bg-primary/10 px-3 py-2 text-right text-primary">
          <p className="text-xl font-semibold">-{path.cutReduction}%</p>
          <p className="text-[10px] uppercase tracking-widest">coupures</p>
        </div>
      </div>

      <div className="grid gap-2 sm:grid-cols-3">
        <Metric icon={Footprints} label="Points guidés" value={cells.length} />
        <Metric icon={Route} label="Séquences" value={path.groups.length} />
        <Metric icon={Scissors} label="Coupures estimées" value={path.estimatedCuts} />
      </div>

      <div className="mt-4 max-h-64 space-y-2 overflow-auto pr-1">
        {path.groups.slice(0, 10).map((group, index) => (
          <div key={group.key} className="grid grid-cols-[auto_1fr_auto] items-center gap-3 rounded-2xl bg-card/70 p-3 text-sm">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl border border-border text-xs font-bold text-black" style={{ backgroundColor: group.hex }}>{index + 1}</span>
            <div>
              <p className="font-medium">DMC {group.code} · {group.name}</p>
              <p className="text-xs text-muted-foreground">Démarrer en {group.start.x}:{group.start.y}, suivre la zone continue</p>
            </div>
            <span className="flex items-center gap-1 text-xs text-muted-foreground">{group.count} pts <ArrowRight className="h-3 w-3" /></span>
          </div>
        ))}
      </div>
    </div>
  );
}

function Metric({ icon: Icon, label, value }) {
  return (
    <div className="rounded-2xl bg-card/70 p-3">
      <Icon className="mb-2 h-4 w-4 text-primary" />
      <p className="text-lg font-semibold">{value}</p>
      <p className="text-xs text-muted-foreground">{label}</p>
    </div>
  );
}

function buildSmartPath(cells) {
  const groupsMap = new Map();
  cells.forEach((cell) => {
    const key = cell.dmc_code || cell.color;
    const group = groupsMap.get(key) || {
      key,
      code: cell.dmc_code || key,
      name: cell.dmc_name || 'Couleur personnalisée',
      hex: cell.color,
      cells: []
    };
    group.cells.push(cell);
    groupsMap.set(key, group);
  });

  const groups = [...groupsMap.values()]
    .map((group) => {
      const ordered = [...group.cells].sort((a, b) => a.y - b.y || a.x - b.x);
      return { ...group, count: ordered.length, start: ordered[0] || { x: 0, y: 0 } };
    })
    .sort((a, b) => b.count - a.count);

  const naiveCuts = cells.length;
  const estimatedCuts = Math.max(1, groups.length + Math.round(groups.length * 0.35));
  const cutReduction = Math.max(0, Math.round(((naiveCuts - estimatedCuts) / naiveCuts) * 100));

  return { groups, estimatedCuts, cutReduction };
}