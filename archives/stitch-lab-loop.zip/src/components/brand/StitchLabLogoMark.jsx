import React from 'react';

export default function StitchLabLogoMark({ className = '' }) {
  return (
    <svg viewBox="0 0 64 64" className={className} aria-hidden="true" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="32" cy="32" r="22" stroke="currentColor" strokeWidth="3.5" />
      <path d="M10 32H54M32 10V54M17 20C24 24 40 24 47 20M17 44C24 40 40 40 47 44" stroke="currentColor" strokeWidth="2.8" strokeLinecap="round" />
      <path d="M20 28L28 36M28 28L20 36M38 18L46 26M46 18L38 26M38 40L46 48M46 40L38 48" stroke="currentColor" strokeWidth="3.2" strokeLinecap="round" />
      <circle cx="32" cy="32" r="2.8" fill="currentColor" />
    </svg>
  );
}