import React, { useEffect, useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import FeedComposer from '@/components/social/FeedComposer';
import PostCard from '@/components/social/PostCard';
import FeedQuickFilters from '@/components/social/FeedQuickFilters';

export default function Feed() {
  const [user, setUser] = useState(null);
  const [filters, setFilters] = useState({ difficulty: 'tous', technique: 'toutes' });
  const queryClient = useQueryClient();
  const { data: posts = [] } = useQuery({ queryKey: ['posts'], queryFn: () => base44.entities.SocialPost.list('-created_date', 30) });

  const filteredPosts = posts.filter((post) => {
    if (post.post_type !== 'pattern') return true;
    const difficultyMatch = filters.difficulty === 'tous' || post.difficulty === filters.difficulty;
    const techniqueMatch = filters.technique === 'toutes' || post.technique === filters.technique;
    return difficultyMatch && techniqueMatch;
  });

  useEffect(() => {
    base44.auth.isAuthenticated().then(async (ok) => {
      if (ok) setUser(await base44.auth.me());
    });
    const unsubscribe = base44.entities.SocialPost.subscribe(() => queryClient.invalidateQueries({ queryKey: ['posts'] }));
    return unsubscribe;
  }, [queryClient]);

  return (
    <div className="px-4 py-10 pb-28 sm:px-6 lg:px-8">
      <div className="mx-auto grid max-w-7xl gap-8 lg:grid-cols-[0.7fr_0.3fr]">
        <section className="space-y-6">
          <div>
            <p className="text-sm uppercase tracking-[0.35em] text-muted-foreground">Communauté</p>
            <h1 className="mt-3 font-serif text-5xl tracking-tight">Feed social</h1>
          </div>
          <FeedComposer user={user} onCreated={() => queryClient.invalidateQueries({ queryKey: ['posts'] })} />
          <FeedQuickFilters filters={filters} onChange={setFilters} />
          <div className="space-y-4">
            {filteredPosts.map((post) => <PostCard key={post.id} post={post} />)}
            {filteredPosts.length === 0 && <div className="rounded-[2rem] border border-dashed border-border p-10 text-center text-muted-foreground">Aucun patron ne correspond à ces filtres.</div>}
          </div>
        </section>
        <aside className="space-y-4 lg:sticky lg:top-24 lg:self-start">
          <div className="rounded-[2rem] bg-primary p-6 text-primary-foreground">
            <h2 className="font-serif text-2xl">Gratuit pour tout le monde</h2>
            <p className="mt-3 text-sm leading-6 text-primary-foreground/75">Le feed reste ouvert : partage, commentaires et inspiration communautaire.</p>
          </div>
          <div className="rounded-[2rem] border border-border bg-card p-6">
            <h3 className="font-medium">Tendances</h3>
            <div className="mt-4 flex flex-wrap gap-2 text-sm text-muted-foreground"><span>#floral</span><span>#sal</span><span>#palette</span><span>#gridworld</span></div>
          </div>
        </aside>
      </div>
    </div>
  );
}