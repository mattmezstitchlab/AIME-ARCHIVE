import React from 'react';
import { Link } from 'react-router-dom';
import { Sparkles } from 'lucide-react';
import HeroSection from '@/components/landing/HeroSection';
import FeatureGrid from '@/components/landing/FeatureGrid';
import PricingRoadmap from '@/components/landing/PricingRoadmap';

export default function Landing() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur-2xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 sm:px-6 lg:px-8">
          <Link to="/" className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-primary text-primary-foreground"><Sparkles className="h-5 w-5" /></div>
            <span className="font-serif text-xl font-black uppercase tracking-tight">StitchLab World</span>
          </Link>
          <nav className="hidden items-center gap-6 text-sm text-muted-foreground md:flex">
            <a href="#features" className="hover:text-foreground">Fonctions</a>
            <a href="#pricing" className="hover:text-foreground">Pro</a>
            <Link to="/feed" className="rounded-full bg-primary px-5 py-2.5 text-primary-foreground">Entrer</Link>
          </nav>
        </div>
      </header>
      <HeroSection />
      <div id="features"><FeatureGrid /></div>
      <div id="pricing"><PricingRoadmap /></div>
    </div>
  );
}