import React, { useEffect, useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Crown, Lock } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import GridCanvas from '@/components/grid/GridCanvas';
import GridProgressStats from '@/components/grid/GridProgressStats';

export default function GridWorld() {
  const [user, setUser] = useState(null);
  const queryClient = useQueryClient();
  const { data: stitches = [] } = useQuery({ queryKey: ['stitches'], queryFn: () => base44.entities.GridStitch.list('-created_date', 800) });
  const { data: cursors = [] } = useQuery({ queryKey: ['cursors'], queryFn: () => base44.entities.CursorPresence.list('-created_date', 20) });
  const { data: patterns = [] } = useQuery({ queryKey: ['patterns-search'], queryFn: () => base44.entities.Pattern.list('-updated_date', 40) });
  const { data: salGroups = [] } = useQuery({ queryKey: ['sal-groups-panel'], queryFn: () => base44.entities.SALGroup.list('-start_date', 8) });
  const { data: salMembers = [] } = useQuery({ queryKey: ['sal-members-panel'], queryFn: () => base44.entities.SALMembership.list('-created_date', 50) });
  const isPro = user?.subscription_tier === 'pro' || user?.role === 'admin';

  useEffect(() => {
    base44.auth.isAuthenticated().then(async (ok) => ok && setUser(await base44.auth.me()));
    const unsubA = base44.entities.GridStitch.subscribe(() => queryClient.invalidateQueries({ queryKey: ['stitches'] }));
    const unsubB = base44.entities.CursorPresence.subscribe(() => queryClient.invalidateQueries({ queryKey: ['cursors'] }));
    return () => { unsubA(); unsubB(); };
  }, [queryClient]);

  return (
    <div className="px-4 py-10 pb-28 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl space-y-6">
        <div className="flex flex-col justify-between gap-4 md:flex-row md:items-end">
          <div>
            <p className="text-sm uppercase tracking-[0.35em] text-muted-foreground">Canvas collaboratif</p>
            <h1 className="mt-3 font-serif text-5xl tracking-tight">Grid World</h1>
          </div>
          {!isPro && <div className="rounded-full border border-border bg-card px-4 py-2 text-sm text-muted-foreground"><Lock className="mr-2 inline h-4 w-4" /> Placement réservé au Pro</div>}
        </div>
        <GridProgressStats stitches={stitches} />
        <GridCanvas stitches={stitches} cursors={cursors} user={user} isPro={isPro} patterns={patterns} salGroups={salGroups} salMembers={salMembers} />
        {!isPro && (
          <div className="rounded-[2rem] bg-primary p-6 text-primary-foreground sm:flex sm:items-center sm:justify-between">
            <div><h2 className="font-serif text-2xl">Débloquer le placement de points</h2><p className="mt-2 text-primary-foreground/70">Le mode Pro permet de laisser ta trace sur le canvas mondial.</p></div>
            <Button variant="secondary" className="mt-4 rounded-full sm:mt-0"><Crown className="mr-2 h-4 w-4" /> Passer Pro</Button>
          </div>
        )}
      </div>
    </div>
  );
}