import React, { useEffect } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import PatternGenerator from '@/components/patterns/PatternGenerator';

export default function Patterns() {
  const queryClient = useQueryClient();
  const { data: patterns = [] } = useQuery({ queryKey: ['patterns'], queryFn: () => base44.entities.Pattern.list('-created_date', 20) });

  useEffect(() => {
    const unsubscribe = base44.entities.Pattern.subscribe(() => queryClient.invalidateQueries({ queryKey: ['patterns'] }));
    return unsubscribe;
  }, [queryClient]);

  return (
    <div className="px-4 py-10 pb-28 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl space-y-8">
        <div>
          <p className="text-sm uppercase tracking-[0.35em] text-muted-foreground">Atelier</p>
          <h1 className="mt-3 font-serif text-5xl tracking-tight">Pattern Generator</h1>
        </div>
        <PatternGenerator onSaved={() => queryClient.invalidateQueries({ queryKey: ['patterns'] })} />
        <section className="grid gap-4 md:grid-cols-3">
          {patterns.map((pattern) => (
            <div key={pattern.id} className="rounded-[2rem] border border-border bg-card p-6 shadow-sm">
              <h3 className="font-serif text-2xl">{pattern.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{pattern.width}×{pattern.height} · {pattern.difficulty} · {pattern.estimated_hours}h</p>
            </div>
          ))}
        </section>
      </div>
    </div>
  );
}