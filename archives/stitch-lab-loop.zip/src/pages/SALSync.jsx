import React, { useEffect, useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import SALMap from '@/components/sal/SALMap';
import SALForm from '@/components/sal/SALForm';
import SALCalendar from '@/components/sal/SALCalendar';
import SALGroupCard from '@/components/sal/SALGroupCard';

export default function SALSync() {
  const [user, setUser] = useState(null);
  const queryClient = useQueryClient();
  const { data: groups = [] } = useQuery({ queryKey: ['salGroups'], queryFn: () => base44.entities.SALGroup.list('-created_date', 30) });
  const isPro = user?.subscription_tier === 'pro' || user?.role === 'admin';

  useEffect(() => {
    base44.auth.isAuthenticated().then(async (ok) => ok && setUser(await base44.auth.me()));
    const unsubscribe = base44.entities.SALGroup.subscribe(() => queryClient.invalidateQueries({ queryKey: ['salGroups'] }));
    return unsubscribe;
  }, [queryClient]);

  return (
    <div className="px-4 py-10 pb-28 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl space-y-8">
        <div>
          <p className="text-sm uppercase tracking-[0.35em] text-muted-foreground">Groupes localisés</p>
          <h1 className="mt-3 font-serif text-5xl tracking-tight">SAL Sync</h1>
        </div>
        <div className="grid gap-6 lg:grid-cols-[0.62fr_0.38fr]">
          <SALMap groups={groups} />
          <SALForm isPro={isPro} onCreated={() => queryClient.invalidateQueries({ queryKey: ['salGroups'] })} />
        </div>
        <SALCalendar groups={groups} />
        <section className="grid gap-4 md:grid-cols-3">
          {groups.map((group) => <SALGroupCard key={group.id} group={group} />)}
        </section>
      </div>
    </div>
  );
}