import LandingHero from '@/components/rebond/landing/LandingHero';
import LandingProblem from '@/components/rebond/landing/LandingProblem';
import LandingProcess from '@/components/rebond/landing/LandingProcess';
import LandingCausalDemo from '@/components/rebond/landing/LandingCausalDemo';
import LandingModes from '@/components/rebond/landing/LandingModes';
import LandingPrinciples from '@/components/rebond/landing/LandingPrinciples';
import LandingFinalCTA from '@/components/rebond/landing/LandingFinalCTA';

export default function Landing(){return <div className="overflow-hidden"><LandingHero/><LandingProblem/><LandingProcess/><LandingCausalDemo/><LandingModes/><LandingPrinciples/><LandingFinalCTA/></div>}