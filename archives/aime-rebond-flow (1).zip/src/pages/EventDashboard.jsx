import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import EventHero from '@/components/rebond/EventHero';
import EventTimeline from '@/components/rebond/EventTimeline';
import OperationalPanel from '@/components/rebond/OperationalPanel';
import RebondDial from '@/components/rebond/RebondDial';
import IncidentSheet from '@/components/rebond/IncidentSheet';
import RippleResult from '@/components/rebond/RippleResult';

export default function EventDashboard() {
  const { id } = useParams();
  const [data,setData] = useState(null), [sheet,setSheet] = useState(false), [result,setResult] = useState(null);
  const [busy,setBusy] = useState(false), [expanded,setExpanded] = useState(false), [selectedId,setSelectedId] = useState(null);
  const load = async () => {
    const [event,moments,roles] = await Promise.all([base44.entities.RebondEvent.get(id),base44.entities.RebondMoment.filter({event_id:id},'planned_start'),base44.entities.RebondRole.filter({event_id:id})]);
    setData({event,moments,roles});
    setSelectedId(current=>current||event.current_moment_id||moments[0]?.id);
  };
  useEffect(()=>{load()},[id]);
  const ripple = async form => {
    setBusy(true);
    const preferred = data.roles.find(role=>role.role_type==='DJ');
    const response = await base44.functions.invoke('createSignalAndComputeRipple',{event_id:id,...form,affected_moment_id:form.affected_moment_id||selectedId,affected_role_id:form.affected_role_id||preferred?.id});
    setResult(response.data); setSheet(false); setBusy(false);
  };
  const approve = async option => {
    setBusy(true);
    await base44.functions.invoke('approveRepairPlan',{event_id:id,repair_option_id:option.id,reason:`Plan validé : ${option.title}`});
    setResult(null); await load(); setBusy(false);
  };
  if (!data) return <div className="loader"/>;
  const selected = data.moments.find(moment=>moment.id===selectedId)||data.moments[0];
  return <main className="w-full"><EventHero event={data.event} moments={data.moments} onSignal={()=>setSheet(true)}/><div className="mx-auto w-full max-w-6xl px-4 pb-8 sm:px-6"><div className="mt-8 grid items-start gap-8 lg:grid-cols-[1.08fr_.92fr]"><EventTimeline moments={data.moments} selectedId={selected?.id} onSelect={setSelectedId} expanded={expanded} onToggle={()=>setExpanded(!expanded)}/><aside className="space-y-5 lg:sticky lg:top-24"><RebondDial moments={data.moments} roles={data.roles} rippling={!!result}/>{result?<RippleResult result={result} onApprove={approve} busy={busy}/>:<OperationalPanel moment={selected} onSignal={()=>setSheet(true)}/>}</aside></div></div><IncidentSheet open={sheet} onClose={()=>setSheet(false)} onSubmit={ripple} roles={data.roles} moments={data.moments} busy={busy}/></main>;
}