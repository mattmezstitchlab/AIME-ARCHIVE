import { Check, Clock3, Eye } from 'lucide-react';

const statuses = { todo:'À prendre en charge', seen:'Vu', acknowledged:'Compris', completed:'Terminé', cancelled:'Annulé' };
const priorities = { low:'Faible', medium:'Normale', high:'Haute', critical:'Critique' };

export default function ActionCard({ action, busy, onAcknowledge, onComplete }) {
  const due = action.due_at && new Date(action.due_at);
  return <article className="panel"><div className="flex flex-wrap items-center gap-2"><span className="rounded-full bg-zinc-800 px-2.5 py-1 text-xs font-bold text-white">{statuses[action.status]||action.status}</span>{action.priority&&<span className="rounded-full bg-zinc-800 px-2.5 py-1 text-xs font-semibold text-white">Priorité {priorities[action.priority]||action.priority}</span>}</div><h2 className="mt-3 text-lg font-semibold text-white">{action.title}</h2><p className="mt-2 leading-relaxed text-slate-300">{action.instruction}</p>{due&&<p className="mt-3 flex items-center gap-2 text-sm font-medium text-slate-400"><Clock3 size={16}/>À faire avant {due.toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'})}</p>}<div className="mt-5 flex flex-wrap gap-2">{action.status==='todo'&&<button disabled={busy} className="secondary-cta" onClick={onAcknowledge}><Eye size={17}/>Vu et compris</button>}{!['completed','cancelled'].includes(action.status)&&<button disabled={busy} className="primary-cta" onClick={onComplete}><Check size={17}/>{busy?'Mise à jour…':'Terminer'}</button>}</div></article>;
}