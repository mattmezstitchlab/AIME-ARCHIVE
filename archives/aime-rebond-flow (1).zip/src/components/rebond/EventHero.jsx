import { FileText, History, MapPin, Plus, Settings2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Image } from '@/components/ui/image';
import StatusPill from './StatusPill';

const images = {
  wedding: 'https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=1800&q=85',
  live_performance: 'https://images.unsplash.com/photo-1501386761578-eac5c94b800a?auto=format&fit=crop&w=1800&q=85'
};

export default function EventHero({ event, moments, onSignal }) {
  const active = moments.find(moment=>moment.status==='active');
  const status = moments.some(moment=>moment.status==='delayed') ? 'attention' : 'stable';
  return <section className="noise-hero relative left-1/2 min-h-[430px] w-screen -translate-x-1/2 overflow-hidden bg-black text-white shadow-2xl"><Image src={images[event.event_type]||images.wedding} alt={`Lieu de ${event.title}`} className="absolute inset-0 h-full w-full opacity-80"/><div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/50 to-transparent"/><div className="relative mx-auto flex min-h-[430px] w-full max-w-6xl flex-col justify-between px-4 py-8 sm:px-6 sm:py-10"><div className="flex items-center justify-between gap-3"><StatusPill status={status}/><div className="flex gap-1"><Link className="nav-icon text-white hover:bg-white/15" to={`/events/${event.id}/setup`} aria-label="Configurer"><Settings2/></Link><Link className="nav-icon text-white hover:bg-white/15" to={`/events/${event.id}/history`} aria-label="Historique"><History/></Link><Link className="nav-icon text-white hover:bg-white/15" to={`/events/${event.id}/report`} aria-label="Rapport"><FileText/></Link></div></div><div><p className="text-xs font-bold uppercase tracking-[.2em] text-white/70">Événement en direct · Version {event.current_version}</p><h1 className="mt-3 max-w-xl text-4xl font-semibold tracking-tight sm:text-6xl">{event.title}</h1><p className="mt-4 flex items-center gap-2 text-white/75"><MapPin size={17}/>{event.location}</p><p className="mt-5 max-w-lg text-lg leading-relaxed text-white/90">{active?`${active.title} est en cours. La coordination reste alignée.`:'Tout est aligné. Le prochain moment est prêt.'}</p><button onClick={onSignal} className="mt-6 inline-flex min-h-12 items-center gap-2 rounded-full bg-coral px-6 font-semibold text-white shadow-lg"><Plus/>Signaler un changement</button></div></div></section>;
}