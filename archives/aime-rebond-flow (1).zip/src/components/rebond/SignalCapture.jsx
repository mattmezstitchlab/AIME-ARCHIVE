import { useState } from 'react';
import { Mic, MicOff } from 'lucide-react';

const suggestions = ['Un intervenant est en retard', 'Un équipement ne fonctionne plus', 'La météo change le programme'];

export default function SignalCapture({ id, value, onChange }) {
  const [listening, setListening] = useState(false);
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  const dictate = () => {
    if (!SpeechRecognition) return;
    const recognition = new SpeechRecognition();
    recognition.lang = 'fr-FR';
    recognition.interimResults = false;
    recognition.onstart = () => setListening(true);
    recognition.onend = () => setListening(false);
    recognition.onresult = event => onChange(event.results[0][0].transcript);
    recognition.start();
  };
  return <div><div className="relative"><textarea id={id} className="field-input min-h-24 resize-none pr-14" value={value} onChange={e=>onChange(e.target.value)} placeholder="Décrivez le fait en une phrase…" required/><button type="button" onClick={dictate} disabled={!SpeechRecognition} className="absolute bottom-3 right-3 grid h-10 w-10 place-items-center rounded-full bg-indigo-600 text-white disabled:bg-slate-300" aria-label={listening?'Arrêter la dictée':'Dicter le signalement'} title={SpeechRecognition?'Dicter le signalement':'Dictée non disponible sur ce navigateur'}>{listening?<MicOff size={18}/>:<Mic size={18}/>}</button></div><div className="mt-2 flex gap-2 overflow-x-auto pb-1">{suggestions.map(text=><button type="button" key={text} onClick={()=>onChange(text)} className="shrink-0 rounded-full bg-indigo-50 px-3 py-2 text-xs font-medium text-indigo-900">{text}</button>)}</div></div>;
}