import { BellRing, History, UserCheck } from 'lucide-react';

const principles=[{icon:UserCheck,title:'Décision humaine',text:'Le moteur propose. Le coordinateur tranche.'},{icon:BellRing,title:'Notifications ciblées',text:'Chacun reçoit l’action utile, sans bruit.'},{icon:History,title:'Historique réversible',text:'Chaque changement est versionné et explicable.'}];

export default function LandingPrinciples(){return <section className="bg-black/45 px-5 py-20"><div className="mx-auto grid max-w-6xl gap-10 md:grid-cols-3">{principles.map(({icon:Icon,title,text})=><article key={title}><Icon className="text-white"/><h3 className="mt-5 text-lg font-semibold text-white">{title}</h3><p className="mt-2 leading-relaxed text-slate-400">{text}</p></article>)}</div></section>}