import { Orbit } from 'lucide-react';
import { Image } from '@/components/ui/image';

const roles = [
  ['DJ','https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=160&q=80'],
  ['PH','https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=160&q=80'],
  ['TR','https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=160&q=80'],
  ['CO','https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=160&q=80'],
  ['LI','https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=160&q=80']
];

export default function LandingDial(){return <div className="relative mx-auto aspect-square w-full max-w-md" aria-label="Aperçu du cadran opérationnel"><div className="landing-dial-track absolute inset-0 rounded-full"/><div className="absolute inset-[18%] grid place-items-center rounded-full bg-black/90 text-center text-white shadow-2xl backdrop-blur"><div><Orbit className="mx-auto mb-3 text-white" size={36}/><p className="font-mono text-4xl">18:42</p><p className="mt-2 text-slate-300">Cocktail · stable</p></div></div>{roles.map(([role,photo],index)=><span key={role} className="absolute h-12 w-12 overflow-hidden rounded-full border-4 border-black shadow-lg" style={{left:`calc(50% + ${Math.cos(index*1.256)*46}% - 24px)`,top:`calc(50% + ${Math.sin(index*1.256)*46}% - 24px)`}}><Image src={photo} alt={role} className="h-full w-full rounded-full"/></span>)}</div>}