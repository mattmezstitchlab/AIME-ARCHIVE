import { useEffect, useState } from 'react';
import { Image } from '@/components/ui/image';
import StatusPill from './StatusPill';

const portraitFallbacks = [
  'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=160&q=80',
  'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=160&q=80',
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=160&q=80',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=160&q=80',
  'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=160&q=80'
];

export default function RebondDial({moments,roles,rippling}) {
  const [now,setNow]=useState(new Date());
  useEffect(()=>{const timer=setInterval(()=>setNow(new Date()),30000);return()=>clearInterval(timer)},[]);
  const active=moments.find(moment=>moment.status==='active')||moments[0];
  const next=moments.find(moment=>moment.status==='pending');
  const delta=active?.actual_start?Math.round((new Date(active.actual_start)-new Date(active.planned_start))/60000):0;
  return <section className="dial-stage" aria-label="Cadran opérationnel">
    <div className="flex items-center justify-between"><div><p className="eyebrow">Cadran Rebond</p><p className="mt-1 text-sm text-slate-400">État opérationnel en direct</p></div><StatusPill status={rippling?'attention':'stable'}/></div>
    <div className={`relative mx-auto mt-4 aspect-square w-full max-w-[430px] ${rippling?'rebond-pulse':''}`}>
      <div className="dial-aura"/><div className="dial-track"/><div className="dial-ring dial-ring-outer"/><div className="dial-ring dial-ring-inner"/>
      <div className="dial-core"><p className="text-[10px] font-bold uppercase tracking-[.24em] text-white">Maintenant</p><time className="mt-2 font-mono text-5xl font-medium tabular-nums text-white">{now.toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'})}</time><p className="mt-4 text-sm text-slate-400">En cours</p><p className="mt-1 max-w-44 text-center text-lg font-semibold text-white">{active?.title||'Aucun moment actif'}</p><div className="mt-5 h-px w-12 bg-white/20"/><p className="mt-4 text-xs text-slate-400">Puis · {next?.title||'Fin de l’événement'}</p><p className="mt-1 text-xs font-semibold text-white">Écart réel · {delta>0?'+':''}{delta} min</p></div>
      {roles.slice(0,8).map((role,index)=>{const angle=(index/Math.min(roles.length,8))*Math.PI*2-Math.PI/2;return <div key={role.id} className="dial-person" title={`${role.display_name} — ${role.role_type}`} style={{left:`calc(50% + ${Math.cos(angle)*45}% - 24px)`,top:`calc(50% + ${Math.sin(angle)*45}% - 24px)`}}><Image src={role.avatar||portraitFallbacks[index%portraitFallbacks.length]} alt={role.display_name} className="h-full w-full rounded-full"/></div>})}
    </div>
  </section>;
}