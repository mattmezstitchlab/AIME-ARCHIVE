export async function requireEventAccess(base44, user, eventId, coordinatorOnly = false) {
  if (!user) throw new Error("UNAUTHORIZED");
  const event = await base44.asServiceRole.entities.RebondEvent.get(eventId);
  if (!event) throw new Error("EVENT_NOT_FOUND");
  const roles = await base44.asServiceRole.entities.RebondRole.filter({ event_id: eventId, user_id: user.id });
  const role = roles[0];
  const isCoordinator = user.role === "admin" || event.owner_id === user.id || role?.permission_level === "coordinator";
  if (event.owner_id !== user.id && user.role !== "admin" && !role) throw new Error("FORBIDDEN");
  if (coordinatorOnly && !isCoordinator) throw new Error("COORDINATOR_REQUIRED");
  return { event, role, isCoordinator };
}

export function errorResponse(error) {
  const codes = { UNAUTHORIZED: 401, FORBIDDEN: 403, COORDINATOR_REQUIRED: 403, EVENT_NOT_FOUND: 404 };
  return Response.json({ error: error.message }, { status: codes[error.message] || 500 });
}

export async function audit(base44, user, eventId, action, entityType, entityId, beforeState, afterState, explanation) {
  return await base44.asServiceRole.entities.RebondAuditEntry.create({ event_id: eventId, user_id: user.id, action, entity_type: entityType, entity_id: entityId, before_state: beforeState || {}, after_state: afterState || {}, explanation, created_at: new Date().toISOString() });
}