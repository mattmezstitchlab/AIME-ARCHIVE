import { createClientFromRequest } from 'npm:@base44/sdk@0.8.38';
import { requireEventAccess, errorResponse, audit } from '../../shared/rebondAuth.ts';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req); const user = await base44.auth.me();
    const input = await req.json(); const { event } = await requireEventAccess(base44, user, input.event_id);
    const signal = await base44.asServiceRole.entities.RebondSignal.create({ ...input, created_by: user.id, occurred_at: input.occurred_at || new Date().toISOString(), status: 'analysing' });
    const dependencies = await base44.asServiceRole.entities.RebondDependency.filter({ event_id: event.id, is_active: true });
    const moments = await base44.asServiceRole.entities.RebondMoment.filter({ event_id: event.id });
    const roles = await base44.asServiceRole.entities.RebondRole.filter({ event_id: event.id });
    const delay = Number(input.delay_minutes || (input.signal_type === 'delay' ? 15 : 0));
    const queue = [input.affected_moment_id || input.affected_role_id].filter(Boolean); const visited = new Set(queue); const impacts = [];
    while (queue.length && impacts.length < 20) { const source = queue.shift(); for (const dep of dependencies.filter(d => d.source_id === source)) { if (visited.has(dep.target_id)) continue; visited.add(dep.target_id); queue.push(dep.target_id); impacts.push({ signal_id: signal.id, event_id: event.id, target_type: dep.target_type, target_id: dep.target_id, impact_type: input.signal_type, time_delta_minutes: delay, explanation: dep.explanation || `Dépend de ${source}`, confidence: dep.is_hard_constraint ? 0.95 : 0.78, direct_or_indirect: impacts.length ? 'indirect' : 'direct', status: 'calculated' }); } }
    if (!impacts.length) for (const moment of moments.filter(m => m.id !== input.affected_moment_id).slice(0, 3)) impacts.push({ signal_id: signal.id, event_id: event.id, target_type: 'moment', target_id: moment.id, impact_type: input.signal_type, time_delta_minutes: Math.min(delay, moment.flexibility_minutes || delay), explanation: `${moment.title} dispose d’une marge mobilisable.`, confidence: 0.72, direct_or_indirect: 'indirect', status: 'calculated' });
    if (impacts.length) await base44.asServiceRole.entities.RebondImpact.bulkCreate(impacts);
    const affectedMoments = [...new Set(impacts.filter(i => i.target_type === 'moment').map(i => i.target_id))];
    const affectedRoles = [...new Set(dependencies.filter(d => visited.has(d.source_id) && d.target_type === 'role').map(d => d.target_id))];
    if (!affectedRoles.length) affectedRoles.push(...roles.filter(r => r.permission_level === 'coordinator' || r.is_critical_actor).slice(0, 4).map(r => r.id));
    const flexible = moments.filter(m => affectedMoments.includes(m.id) && (m.flexibility_minutes || 0) > 0).sort((a,b) => b.flexibility_minutes-a.flexibility_minutes);
    const names = affectedMoments.map(id => moments.find(m => m.id === id)?.title).filter(Boolean);
    const options = [
      { title:'Absorber avec la marge', description:`Utiliser ${Math.min(delay || 15, flexible[0]?.flexibility_minutes || 15)} min de souplesse avant de toucher aux contraintes dures.`, estimated_effect:`${Math.max(0, delay-(flexible[0]?.flexibility_minutes || 15))} min résiduelles`, advantages:['Changement limité','Contraintes dures préservées'], risks:['Marge restante réduite'] },
      { title:'Déplacer un moment flexible', description:`Décaler ${names[0] || 'le moment flexible'} pour préserver la suite prioritaire.`, estimated_effect:`${delay || 15} min réorganisées`, advantages:['Priorités maintenues'], risks:['Coordination ciblée nécessaire'] },
      { title:'Activer le plan B', description:'Contourner la dépendance principale et distribuer des actions alternatives.', estimated_effect:'Continuité opérationnelle', advantages:['Réduit le risque de cascade'], risks:['Plus d’acteurs mobilisés'] }
    ].slice(0, input.severity === 'attention' ? 2 : 3).map(o => ({ ...o, signal_id: signal.id, event_id: event.id, affected_moments: affectedMoments, affected_roles: affectedRoles, created_by_engine: true, status:'proposed' }));
    const createdOptions = await base44.asServiceRole.entities.RebondRepairOption.bulkCreate(options);
    await base44.asServiceRole.entities.RebondSignal.update(signal.id, { status:'proposed' });
    await audit(base44, user, event.id, 'signal.computed', 'RebondSignal', signal.id, {}, { impacts: impacts.length, options: createdOptions.length }, 'Fait enregistré, conséquences calculées, aucune modification appliquée.');
    const causal = `SI ${input.title.toLowerCase()}, ALORS ${names.length ? names.join(', ') : 'la séquence concernée'} peut être ajustée, PARCE QUE ces éléments dépendent les uns des autres.`;
    return Response.json({ signal: { ...signal, status:'proposed' }, impacts, options: createdOptions, causal_explanation: causal });
  } catch (error) { return errorResponse(error); }
});