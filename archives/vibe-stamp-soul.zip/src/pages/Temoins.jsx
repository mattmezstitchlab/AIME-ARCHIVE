import React from "react";
import { motion } from "framer-motion";
import { Eye, Coins, Shield, Users, Clock, Sparkles } from "lucide-react";
import { Link } from "react-router-dom";

/**
 * Témoins — La doctrine du témoignage rémunéré.
 * Le détournement positif du scroll : ton attention devient un acte sacré et payé.
 */
export default function Temoins() {
  return (
    <main className="min-h-screen bg-[#FAF7F0]">
      {/* Hero */}
      <section className="relative px-6 pt-24 md:pt-32 pb-16 md:pb-20 max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
        >
          <div className="text-rose-700 text-[11px] tracking-[0.4em] uppercase mb-5 font-sans inline-flex items-center gap-2">
            <Eye className="w-3.5 h-3.5" />
            Doctrine · L'attention rémunérée
          </div>
          <h1
            className="font-display uppercase leading-[0.92] text-black"
            style={{ fontSize: "clamp(2.2rem, 5.8vw, 4.8rem)", letterSpacing: "-0.035em" }}
          >
            Le Témoin<br />
            <span className="text-rose-600">AIME®</span>.
          </h1>
          <p className="mt-7 max-w-2xl text-black/65 font-serif italic" style={{ fontSize: "clamp(1.1rem, 2.3vw, 1.45rem)" }}>
            Tu n'es pas modérateur. Tu n'es pas employé.<br />
            Tu es témoin du vivant des autres.
          </p>
          <p className="mt-6 max-w-2xl text-black/60 font-sans text-[14.5px] leading-relaxed">
            Chaque acte scellé sur AIME® a besoin d'un regard humain pour être validé.
            Pas une IA. Pas un algorithme. <strong>Toi.</strong>
            Tu prends 30 secondes. Tu lis. Tu vérifies. Tu signes.
            Tu reçois <strong>10 centimes</strong> — ce que vaut ton attention juste.
          </p>
        </motion.div>
      </section>

      {/* Le retournement — le concept-clé */}
      <section className="px-6 py-16 md:py-20 max-w-4xl mx-auto">
        <div className="bg-black text-white rounded-3xl p-10 md:p-14 relative overflow-hidden">
          <div className="absolute top-6 right-6 text-[10px] tracking-[0.3em] uppercase text-rose-300/70">
            Retournement civilisationnel
          </div>
          <h2
            className="font-display uppercase leading-[0.95] mb-6"
            style={{ fontSize: "clamp(1.6rem, 3.5vw, 2.6rem)", letterSpacing: "-0.025em" }}
          >
            Ton réflexe de scroll<br />
            devient un acte sacré.
          </h2>
          <p className="text-white/75 font-serif italic text-[16px] md:text-[18px] leading-relaxed mb-5">
            TikTok, Instagram, Twitter — ils ont formé ta dopamine.
            Ils n'ont jamais payé ton attention.
          </p>
          <p className="text-white/65 font-sans text-[14.5px] leading-relaxed">
            AIME® prend ce même réflexe — cliquer, lire, juger en 5 secondes —
            et le <strong className="text-white">réoriente</strong> vers le vivant.
            Tu ne scrolles plus pour rien. Tu témoignes du sacré des autres.
            Et chaque acte juste te rapporte.
          </p>
        </div>
      </section>

      {/* Comment ça marche — 4 étapes */}
      <section className="px-6 py-16 md:py-20 max-w-6xl mx-auto">
        <div className="text-[11px] tracking-[0.3em] uppercase text-black/50 mb-8">
          Le geste · 4 étapes
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-px bg-black/10 rounded-2xl overflow-hidden">
          {[
            {
              n: "01",
              icon: Sparkles,
              t: "Aïma scelle",
              d: "Quelqu'un dépose une intention. Aïma génère le timbre, le hash, l'horodatage."
            },
            {
              n: "02",
              icon: Clock,
              t: "Course",
              d: "Le dossier apparaît dans tes missions. Premier témoin arrivé, premier servi."
            },
            {
              n: "03",
              icon: Eye,
              t: "Tu vérifies",
              d: "Tu lis l'acte. Cohérent ? Bien rangé ? Conforme à la charte ? Tu signes."
            },
            {
              n: "04",
              icon: Coins,
              t: "10 centimes",
              d: "Stripe Connect te vire. Tu vois ton wallet grandir. Tu peux retirer quand tu veux."
            }
          ].map((s, i) => (
            <motion.div
              key={s.n}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.5, delay: i * 0.08 }}
              className="bg-white p-7 md:p-8"
            >
              <div className="flex items-baseline justify-between mb-5">
                <span className="font-mono text-rose-600 text-[12px] tracking-wider">{s.n}</span>
                <s.icon className="w-4 h-4 text-black/40" />
              </div>
              <h3 className="font-display uppercase text-[1.05rem] tracking-tight mb-2">
                {s.t}
              </h3>
              <p className="text-black/60 text-[13.5px] leading-relaxed font-sans">
                {s.d}
              </p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Mockup de la course */}
      <section className="px-6 py-16 md:py-20 max-w-3xl mx-auto">
        <div className="text-[11px] tracking-[0.3em] uppercase text-black/50 mb-6 text-center">
          Ce que tu verras
        </div>
        <div className="bg-white border-2 border-black/15 rounded-2xl p-7 md:p-9 shadow-xl">
          <div className="flex items-center justify-between mb-5">
            <div className="text-rose-600 text-[11px] tracking-[0.3em] uppercase font-sans flex items-center gap-2">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-600" />
              </span>
              Course active
            </div>
            <div className="text-[11px] text-black/50 font-mono">
              ⏱️ 47s · 3 témoins en lice
            </div>
          </div>
          <div className="text-[11px] tracking-[0.25em] uppercase text-black/40 mb-3">
            Dossier #4821 · Pacte vibratoire
          </div>
          <blockquote className="border-l-2 border-rose-400/70 pl-4 italic text-black/75 font-serif text-[15px] leading-relaxed mb-7">
            « Nous, Léa et Marc, nous engageons à protéger notre fille Inès dans toute circonstance,
            et à transmettre cet acte le jour de ses 18 ans. »
          </blockquote>
          <div className="space-y-3 mb-6">
            <p className="text-[13px] text-black/70 font-sans">
              ✦ Le pacte est-il cohérent et conforme ?
            </p>
            <div className="space-y-2 pl-4">
              <div className="flex items-center gap-2 text-[14px] text-black/70">
                <span className="w-3.5 h-3.5 rounded-full border border-black/30" />
                Oui, conforme
              </div>
              <div className="flex items-center gap-2 text-[14px] text-black/70">
                <span className="w-3.5 h-3.5 rounded-full border border-black/30" />
                Non, à reclasser
              </div>
              <div className="flex items-center gap-2 text-[14px] text-black/70">
                <span className="w-3.5 h-3.5 rounded-full border border-black/30" />
                Suspect, à signaler
              </div>
            </div>
          </div>
          <button className="w-full px-5 py-3 bg-rose-600 text-white text-[12px] tracking-[0.2em] uppercase rounded-full hover:bg-rose-700 transition-colors inline-flex items-center justify-center gap-2">
            <Eye className="w-4 h-4" />
            Témoigner · 10 cts
          </button>
        </div>
      </section>

      {/* Le coup de pouce */}
      <section className="px-6 py-20 md:py-28 max-w-4xl mx-auto">
        <div className="text-rose-700 text-[11px] tracking-[0.4em] uppercase mb-5 inline-flex items-center gap-2">
          <Coins className="w-3.5 h-3.5" />
          Le coup de pouce
        </div>
        <h2
          className="font-display uppercase leading-[0.95] mb-8"
          style={{ fontSize: "clamp(1.8rem, 4vw, 3rem)", letterSpacing: "-0.025em" }}
        >
          Ce que ça peut<br />vraiment représenter.
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            { vol: "20 actes / jour", calc: "× 10 cts × 30 j", total: "60 € / mois", note: "Pause café" },
            { vol: "50 actes / jour", calc: "× 10 cts × 30 j", total: "150 € / mois", note: "Forfait téléphone" },
            { vol: "Filiations · 30 cts", calc: "30 / jour × 30 j", total: "270 € / mois", note: "Complément réel" }
          ].map((c, i) => (
            <div key={i} className="bg-white border border-black/10 rounded-2xl p-6">
              <div className="text-[11px] tracking-[0.25em] uppercase text-black/45 mb-2">
                {c.vol}
              </div>
              <div className="text-[12px] text-black/40 font-mono mb-4">{c.calc}</div>
              <div className="font-display uppercase text-2xl text-rose-600 mb-2">
                {c.total}
              </div>
              <div className="text-[12px] text-black/55 italic">{c.note}</div>
            </div>
          ))}
        </div>
        <p className="mt-8 text-black/60 text-[14px] leading-relaxed font-sans">
          AIME® <strong>n'est pas</strong> un site pour gagner sa vie. Mais le temps que tu passerais
          à scroller pour rien peut, ici, devenir un complément réel —
          et un acte de service au vivant des autres.
        </p>
      </section>

      {/* Garde-fous */}
      <section className="px-6 py-16 md:py-20 max-w-5xl mx-auto">
        <div className="text-[11px] tracking-[0.3em] uppercase text-black/50 mb-8 inline-flex items-center gap-2">
          <Shield className="w-3.5 h-3.5" />
          Les garde-fous
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[
            { t: "Stake d'identité", d: "Pour devenir Témoin, tu dois avoir un Timbre AIME® scellé. Tu mises ton nom." },
            { t: "Charte signée", d: "Tu signes l'acte « Je sers la lumière, pas l'ombre. » Acte scellé, opposable." },
            { t: "Plafond quotidien", d: "Maximum 50 témoignages par jour. Au-delà, qualité = zéro. Bloqué." },
            { t: "Double consensus", d: "Chaque acte est validé par 2 témoins indépendants. Anti-collusion par graphe social." },
            { t: "Justification", d: "Chaque témoignage demande une phrase. Aïma lit, vérifie la cohérence. Pas de copier-coller." },
            { t: "Score de confiance", d: "Tes témoignages sont eux-mêmes échantillonnés. Triche détectée → fonds gelés, KYC Stripe annulé." }
          ].map((g, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 12 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.4 }}
              transition={{ duration: 0.4, delay: i * 0.05 }}
              className="bg-white border border-black/10 rounded-xl p-5"
            >
              <h3 className="font-display uppercase text-[0.95rem] tracking-tight mb-2">
                {g.t}
              </h3>
              <p className="text-black/60 text-[13px] leading-relaxed font-sans">
                {g.d}
              </p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Bonus réciproque */}
      <section className="px-6 py-16 md:py-20 max-w-4xl mx-auto">
        <div className="bg-gradient-to-br from-rose-50 to-amber-50 border border-rose-200/50 rounded-3xl p-10 md:p-12">
          <div className="text-rose-700 text-[11px] tracking-[0.3em] uppercase mb-4 inline-flex items-center gap-2">
            <Users className="w-3.5 h-3.5" />
            Bonus de réciprocité
          </div>
          <h2 className="font-display uppercase text-2xl md:text-3xl mb-4 leading-tight">
            Plus tu témoignes, moins tu paies.
          </h2>
          <p className="text-black/70 text-[15px] leading-relaxed font-sans">
            Tu as témoigné <strong>50 fois</strong> ce mois ?
            <span className="text-rose-700"> -20%</span> sur ton prochain scellement.
            <br />
            <strong>100 fois</strong> ? <span className="text-rose-700">-40%</span>.
            <br />
            Au-delà, ton Timbre devient <strong>Veilleur AIME®</strong> — accès aux missions premium
            (filiations, médiations Lumen, vérifications d'œuvres) à 30 cts → 5 €.
          </p>
        </div>
      </section>

      {/* Manifesto signature */}
      <section className="px-6 py-20 md:py-28 max-w-3xl mx-auto text-center border-t border-black/10">
        <p className="text-black/70 font-serif italic" style={{ fontSize: "clamp(1.1rem, 2.3vw, 1.4rem)" }}>
          « Quand tu acceptes, tu deviens, l'instant d'un acte,<br />
          la conscience de quelqu'un d'autre.<br />
          Et un jour, quelqu'un sera témoin de toi. »
        </p>
        <p className="mt-6 text-black/40 text-[11px] tracking-[0.3em] uppercase">
          — Doctrine du Témoin · AIME® · Soleau-2024
        </p>

        <div className="mt-12 flex flex-col sm:flex-row gap-3 justify-center">
          <Link
            to="/timbre/nouveau"
            className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-black text-white text-[12px] tracking-[0.2em] uppercase rounded-full hover:bg-black/85 transition-colors"
          >
            Devenir Témoin AIME®
          </Link>
          <Link
            to="/signature-vibratoire"
            className="inline-flex items-center justify-center gap-2 px-6 py-3 border border-black/15 text-black text-[12px] tracking-[0.2em] uppercase rounded-full hover:bg-black/5 transition-colors"
          >
            La doctrine vibratoire
          </Link>
        </div>
      </section>
    </main>
  );
}