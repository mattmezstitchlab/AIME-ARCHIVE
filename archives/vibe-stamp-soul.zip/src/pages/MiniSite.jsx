import React, { useEffect, useState, useCallback } from "react";
import { useParams, useNavigate, useLocation } from "react-router-dom";
import { motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { getAnonymousId } from "@/lib/aimaSession";
import EditableField from "@/components/minisite/EditableField";
import EditableImage from "@/components/minisite/EditableImage";
import MiniSiteSection from "@/components/minisite/MiniSiteSection";

const DEFAULT_ACCENT = "#D4A574";

const SECTION_TEMPLATES = [
  { kind: "text", title: "Notre histoire", body: "Écris ici…" },
  { kind: "quote", title: "— vous deux", body: "Une phrase qui vous ressemble." },
  { kind: "image", title: "", media_url: "" },
  { kind: "info", title: "Le jour J · infos pratiques", body: "Lieu · horaires · dress code · parking…" },
  { kind: "playlist", title: "", body: "" },
  { kind: "guestbook", title: "", body: "" }
];

const newId = () => Math.random().toString(36).slice(2, 10);

/**
 * MiniSite — page-cadeau privée du couple.
 * Route /u/:slug         → vue lecture (publique si published=true)
 * Route /u/:slug/edit    → mode édition clique-modifie (terrain de jeu libre)
 *
 * Auto-save toutes les 1.5s après modification. Bouton "Publier" → page paiement (à venir).
 */
export default function MiniSite() {
  const { slug } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  const editing = location.pathname.endsWith("/edit");

  const [site, setSite] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [savedAt, setSavedAt] = useState(null);
  const [showAddMenu, setShowAddMenu] = useState(false);

  // Charge le site existant ou en crée un nouveau si on est en mode édition
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const rows = await base44.entities.MiniSite.filter({ slug });
        if (cancelled) return;
        if (rows && rows[0]) {
          setSite(rows[0]);
        } else if (editing) {
          // Création à la volée en mode édition
          const fresh = await base44.entities.MiniSite.create({
            slug,
            anonymous_id: getAnonymousId(),
            couple_names: "Vous deux",
            intro_title: "Vous deux,",
            intro_italic: "et tout ce qui le tient ensemble.",
            intro_text: "Bienvenue. Ce mini-site est notre cadeau — un lieu pour vous, à notre rythme.",
            accent_color: DEFAULT_ACCENT,
            sections: [
              { id: newId(), kind: "text", title: "Notre histoire", body: "Écris ici l'histoire qui vous a menés jusqu'à ce jour." }
            ],
            published: false
          });
          setSite(fresh);
        } else {
          setSite(null);
        }
      } catch (_) { /* silent */ }
      setLoading(false);
    })();
    return () => { cancelled = true; };
  }, [slug, editing]);

  // Sauvegarde différée (debounce 1.5s)
  const persist = useCallback(async (next) => {
    if (!next?.id) return;
    setSaving(true);
    try {
      const { id, created_date, updated_date, created_by, ...patch } = next;
      await base44.entities.MiniSite.update(id, patch);
      setSavedAt(new Date());
    } catch (_) {}
    setSaving(false);
  }, []);

  useEffect(() => {
    if (!editing || !site?.id) return;
    const t = setTimeout(() => persist(site), 1200);
    return () => clearTimeout(t);
  }, [site, editing, persist]);

  const update = (patch) => setSite((s) => ({ ...s, ...patch }));
  const updateSection = (id, next) => {
    setSite((s) => ({
      ...s,
      sections: (s.sections || []).map((sec) => (sec.id === id ? next : sec))
    }));
  };
  const removeSection = (id) => {
    setSite((s) => ({ ...s, sections: (s.sections || []).filter((sec) => sec.id !== id) }));
  };
  const addSection = (kind) => {
    const tpl = SECTION_TEMPLATES.find((t) => t.kind === kind) || SECTION_TEMPLATES[0];
    setSite((s) => ({
      ...s,
      sections: [...(s.sections || []), { ...tpl, id: newId() }]
    }));
    setShowAddMenu(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0A0A0B] flex items-center justify-center">
        <div className="w-6 h-6 border-2 border-white/20 border-t-white/80 rounded-full animate-spin" />
      </div>
    );
  }

  if (!site) {
    return (
      <div className="min-h-screen bg-[#0A0A0B] text-center pt-32 px-6">
        <div className="font-serif italic text-white/80 text-2xl mb-4">Ce mini-site n'existe pas.</div>
        <button
          onClick={() => navigate(`/u/${slug}/edit`)}
          className="px-6 py-2.5 rounded-full bg-white text-stone-900 text-[12px] tracking-[0.2em] uppercase font-medium"
        >
          Le créer
        </button>
      </div>
    );
  }

  // Site existant mais non publié, et on n'est pas en mode édition → bloc verrouillé
  if (!site.published && !editing) {
    return (
      <div className="min-h-screen bg-[#0A0A0B] text-center pt-32 px-6">
        <div className="font-sans text-[10px] tracking-[0.3em] uppercase mb-4" style={{ color: site.accent_color || DEFAULT_ACCENT }}>
          Brouillon · pas encore publié
        </div>
        <div className="font-serif italic text-white/85 text-2xl md:text-3xl mb-6">
          Ce mini-site n'est pas encore ouvert.
        </div>
        <button
          onClick={() => navigate(`/u/${slug}/edit`)}
          className="px-6 py-2.5 rounded-full bg-white text-stone-900 text-[12px] tracking-[0.2em] uppercase font-medium"
        >
          Le modifier
        </button>
      </div>
    );
  }

  const accent = site.accent_color || DEFAULT_ACCENT;

  return (
    <div className="min-h-screen bg-[#0A0A0B]">
      {/* Toolbar édition */}
      {editing && (
        <div className="sticky top-0 z-40 bg-black/85 backdrop-blur-xl border-b border-white/10">
          <div className="max-w-6xl mx-auto px-4 py-2.5 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2 text-white/70 text-[11px] tracking-[0.15em] uppercase">
              <span className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ backgroundColor: accent }} />
              Édition · /u/{slug}
            </div>
            <div className="flex items-center gap-2 text-[11px] text-white/50">
              {saving ? "Enregistrement…" : savedAt ? "Enregistré" : ""}
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => navigate(`/u/${slug}`)}
                className="px-3 py-1.5 rounded-full bg-white/[0.06] hover:bg-white/[0.12] border border-white/15 text-white/80 text-[11px] tracking-[0.15em] uppercase"
              >
                Aperçu
              </button>
              <button
                onClick={() => alert("Publier — paiement requis. Cette étape arrive bientôt.")}
                className="px-4 py-1.5 rounded-full text-[11px] tracking-[0.15em] uppercase font-medium"
                style={{ backgroundColor: accent, color: "#1A1208" }}
              >
                Publier
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Couverture */}
      <section className="relative w-full h-[70vh] overflow-hidden">
        <EditableImage
          editing={editing}
          src={site.cover_url || "https://res.cloudinary.com/divou1vcx/image/upload/v1777698965/pexels-rothemba-vele-1414849-18041569_pps4us.jpg"}
          onChange={(cover_url) => update({ cover_url })}
          accent={accent}
          className="absolute inset-0"
        />
        <div
          className="absolute inset-0 pointer-events-none"
          style={{ background: "linear-gradient(180deg, rgba(0,0,0,0.35) 0%, rgba(0,0,0,0) 50%, rgba(10,10,11,0.85) 100%)" }}
        />
        <div className="relative h-full flex flex-col items-center justify-center text-center px-6 max-w-3xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="font-sans text-[10px] tracking-[0.35em] uppercase mb-4" style={{ color: accent }}>
              <EditableField
                editing={editing}
                value={site.couple_names}
                onChange={(couple_names) => update({ couple_names })}
                placeholder="Léa & Marc"
                accent={accent}
              />
            </div>
            <h1 className="apple-headline text-white text-4xl md:text-6xl">
              <EditableField
                editing={editing}
                value={site.intro_title}
                onChange={(intro_title) => update({ intro_title })}
                placeholder="Vous deux,"
                accent={accent}
              />
              <br />
              <span className="text-white/75">
                <EditableField
                  editing={editing}
                  value={site.intro_italic}
                  onChange={(intro_italic) => update({ intro_italic })}
                  placeholder="et tout ce qui le tient ensemble."
                  accent={accent}
                />
              </span>
            </h1>
            <p className="mt-6 font-sans text-white/75 text-[15px] max-w-xl mx-auto leading-relaxed">
              <EditableField
                editing={editing}
                value={site.intro_text}
                onChange={(intro_text) => update({ intro_text })}
                placeholder="Mot d'accueil aux invités…"
                multiline
                accent={accent}
              />
            </p>
          </motion.div>
        </div>
      </section>

      {/* Sections composables */}
      <div className="py-8 md:py-12 space-y-2">
        {(site.sections || []).map((sec) => (
          <MiniSiteSection
            key={sec.id}
            section={sec}
            editing={editing}
            accent={accent}
            onUpdate={(next) => updateSection(sec.id, next)}
            onRemove={() => removeSection(sec.id)}
          />
        ))}

        {/* Ajouter une section */}
        {editing && (
          <div className="max-w-3xl mx-auto px-6 py-8">
            <div className="relative">
              <button
                onClick={() => setShowAddMenu((o) => !o)}
                className="w-full py-4 rounded-2xl border-2 border-dashed border-white/15 hover:border-white/30 text-white/60 hover:text-white/90 transition-colors text-[13px] tracking-[0.15em] uppercase"
              >
                + Ajouter un bloc
              </button>
              {showAddMenu && (
                <div className="absolute left-0 right-0 top-full mt-2 rounded-2xl bg-[#15151a] border border-white/15 shadow-2xl p-2 z-30 grid grid-cols-2 sm:grid-cols-3 gap-1">
                  {[
                    { k: "text", l: "Texte" },
                    { k: "image", l: "Image" },
                    { k: "quote", l: "Citation" },
                    { k: "info", l: "Infos pratiques" },
                    { k: "playlist", l: "Playlist" },
                    { k: "guestbook", l: "Livre d'or" }
                  ].map((b) => (
                    <button
                      key={b.k}
                      onClick={() => addSection(b.k)}
                      className="px-3 py-2 rounded-lg text-[12.5px] text-white/80 hover:text-white hover:bg-white/[0.07] transition-colors"
                    >
                      {b.l}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Footer */}
      <footer className="border-t border-white/5 px-6 py-10 text-center">
        <div className="font-sans text-[10px] tracking-[0.3em] uppercase text-white/30">
          Mini-site AIME® · {site.couple_names}
        </div>
      </footer>
    </div>
  );
}