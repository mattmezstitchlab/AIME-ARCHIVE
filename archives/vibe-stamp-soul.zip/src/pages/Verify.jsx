import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import VerifyCard from "@/components/stamp/VerifyCard";
import { ArrowLeft } from "lucide-react";

/**
 * Verify — page publique de vérification d'un timbre par son code.
 * Affiche : intention, hash, horodatage, signature vibratoire, filiation Soleau.
 */
export default function Verify() {
  const { code } = useParams();
  const [stamp, setStamp] = useState(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    let alive = true;
    (async () => {
      setLoading(true);
      const decoded = decodeURIComponent(code || "");
      const matches = await base44.entities.Stamp.filter({ code: decoded });
      if (!alive) return;
      if (matches && matches.length > 0) {
        setStamp(matches[0]);
      } else {
        setNotFound(true);
      }
      setLoading(false);
    })();
    return () => {
      alive = false;
    };
  }, [code]);

  return (
    <main className="min-h-screen bg-[#FAF7F0] py-16 md:py-24 px-6">
      <div className="max-w-3xl mx-auto mb-8">
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-[12px] tracking-[0.18em] uppercase text-black/60 hover:text-black transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Retour
        </Link>
      </div>

      {loading && (
        <div className="max-w-3xl mx-auto bg-white border border-black/10 rounded-2xl p-12 text-center">
          <div className="w-8 h-8 border-4 border-black/10 border-t-black rounded-full animate-spin mx-auto mb-4" />
          <p className="text-black/55 text-sm">Vérification du timbre…</p>
        </div>
      )}

      {!loading && notFound && (
        <div className="max-w-3xl mx-auto bg-white border border-black/10 rounded-2xl p-12 text-center">
          <h2 className="font-display uppercase text-2xl mb-3">Timbre introuvable</h2>
          <p className="text-black/55 text-[14px]">
            Aucun timbre AIME® ne correspond au code <code className="font-mono">{decodeURIComponent(code || "")}</code>.
          </p>
        </div>
      )}

      {!loading && stamp && <VerifyCard stamp={stamp} />}
    </main>
  );
}