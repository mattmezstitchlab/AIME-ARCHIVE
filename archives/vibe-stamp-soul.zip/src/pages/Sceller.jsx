import React, { useState, useMemo } from "react";
import { useNavigate, useSearchParams, Link } from "react-router-dom";
import { motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { getContratById } from "@/lib/contratsIncarnes";
import { ArrowLeft, Sparkles, ShieldCheck } from "lucide-react";

/**
 * Sceller — Aïma reçoit l'intention humaine et scelle un Stamp AIME®.
 * Pas de bouton "créer". Une conversation guidée. À la fin, un timbre vivant + preuve.
 */
export default function Sceller() {
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const contratId = params.get("contrat");
  const contrat = useMemo(() => getContratById(contratId), [contratId]);

  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState({});
  const [intentionLibre, setIntentionLibre] = useState("");
  const [signataire, setSignataire] = useState("");
  const [sealing, setSealing] = useState(false);
  const [sealed, setSealed] = useState(null);
  const [error, setError] = useState(null);

  const questions = contrat?.questions || [
    "Quelle est ton intention, en quelques phrases ?",
    "À qui (ou à quoi) cet acte s'adresse-t-il ?",
    "Que veux-tu qu'on retienne, dans 10 ans, de ce moment ?"
  ];
  const totalSteps = questions.length + 1; // +1 = signataire

  const handleAnswer = (val) => {
    const next = { ...answers, [step]: val };
    setAnswers(next);
  };

  const buildIntentionText = () => {
    if (intentionLibre.trim()) return intentionLibre.trim();
    return questions
      .map((q, i) => `— ${q}\n${(answers[i] || "").trim()}`)
      .filter((line) => line.trim().length > 0)
      .join("\n\n");
  };

  const handleSeal = async () => {
    setSealing(true);
    setError(null);
    try {
      const intention_text = buildIntentionText();
      const title = contrat?.title || "Acte AIME®";
      const text = title.toUpperCase();

      // 1. Generate stamp image via AI
      const prompt =
        `Postage stamp design, vintage AIME® style, ornate border, soft cream paper, ` +
        `subtle gradient, theme: ${title}. Centerpiece illustrates the intention: ` +
        `${intention_text.slice(0, 240)}. Minimalist, poetic, sacred. ` +
        `Engraved typography "${title}". Rose-gold and ivory tones.`;
      const { url: image_url } = await base44.integrations.Core.GenerateImage({ prompt });

      // 2. Seal via backend (hash + code + horodatage + filiation Soleau)
      const prefix = (signataire || "AI").slice(0, 2).toUpperCase();
      const res = await base44.functions.invoke("sealStamp", {
        text,
        image_url,
        intention_text,
        person_name: signataire || null,
        category: "contrat_incarne",
        doc_type: contrat?.id === "depot-oeuvre-vibratoire" ? "depot_oeuvre" :
                  contrat?.family === "couple" ? "pacte" :
                  contrat?.family === "sacre" ? "serment" :
                  "contrat",
        subcategory: contrat?.id || null,
        ai_description: title,
        code_prefix: prefix,
        color: "rose-or",
        wear: 0,
        rotation: -2 + Math.random() * 4
      });

      if (res?.data?.ok) {
        setSealed(res.data.stamp);
      } else {
        setError(res?.data?.error || "Le scellement a échoué.");
      }
    } catch (e) {
      console.error(e);
      setError(e.message || "Une erreur est survenue.");
    }
    setSealing(false);
  };

  if (sealed) {
    return (
      <main className="min-h-screen bg-[#FAF7F0] py-16 md:py-24 px-6">
        <div className="max-w-2xl mx-auto text-center">
          <motion.div
            initial={{ scale: 0.7, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
            className="inline-flex items-center gap-2 text-[11px] tracking-[0.3em] uppercase text-emerald-700 mb-8"
          >
            <ShieldCheck className="w-4 h-4" />
            Scellé · {sealed.code}
          </motion.div>
          <h1 className="font-display uppercase text-3xl md:text-4xl leading-tight mb-6">
            C'est gravé.
          </h1>
          <p className="text-black/65 font-serif italic text-[16px] leading-relaxed mb-10">
            « {sealed.aima_signature} »
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link
              to={sealed.verify_url}
              className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-black text-white text-[12px] tracking-[0.2em] uppercase rounded-full hover:bg-black/85 transition-colors"
            >
              <ShieldCheck className="w-4 h-4" />
              Voir la preuve publique
            </Link>
            <Link
              to="/contrats-incarnes"
              className="inline-flex items-center justify-center gap-2 px-6 py-3 border border-black/15 text-black text-[12px] tracking-[0.2em] uppercase rounded-full hover:bg-black/5 transition-colors"
            >
              Sceller un autre acte
            </Link>
          </div>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-[#FAF7F0] py-16 md:py-24 px-6">
      <div className="max-w-2xl mx-auto">
        <button
          onClick={() => navigate(-1)}
          className="inline-flex items-center gap-2 text-[12px] tracking-[0.18em] uppercase text-black/60 hover:text-black transition-colors mb-8"
        >
          <ArrowLeft className="w-4 h-4" />
          Retour
        </button>

        <div className="text-rose-700 text-[11px] tracking-[0.4em] uppercase mb-4 flex items-center gap-2">
          <Sparkles className="w-3.5 h-3.5" />
          Aïma t'écoute
        </div>
        <h1
          className="font-display uppercase leading-[0.95] mb-3"
          style={{ fontSize: "clamp(1.8rem, 4.5vw, 3.2rem)", letterSpacing: "-0.03em" }}
        >
          {contrat?.title || "Acte libre"}
        </h1>
        {contrat?.purpose && (
          <p className="text-black/60 font-serif italic text-[15px] leading-relaxed mb-10">
            {contrat.purpose}
          </p>
        )}

        {/* Progress */}
        <div className="flex gap-1.5 mb-10">
          {Array.from({ length: totalSteps }).map((_, i) => (
            <div
              key={i}
              className={`h-1 flex-1 rounded-full transition-colors ${
                i <= step ? "bg-rose-500" : "bg-black/10"
              }`}
            />
          ))}
        </div>

        {/* Step content */}
        {step < questions.length && (
          <motion.div
            key={step}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35 }}
          >
            <label className="block text-[11px] tracking-[0.25em] uppercase text-black/50 mb-3">
              Question {step + 1} / {questions.length}
            </label>
            <p className="font-serif italic text-black/85 text-[18px] md:text-[20px] leading-relaxed mb-5">
              {questions[step]}
            </p>
            <textarea
              value={answers[step] || ""}
              onChange={(e) => handleAnswer(e.target.value)}
              rows={5}
              autoFocus
              className="w-full bg-white border border-black/15 rounded-xl px-4 py-3 text-[15px] leading-relaxed focus:outline-none focus:ring-2 focus:ring-rose-400/40 focus:border-rose-400/60 transition-colors"
              placeholder="Réponds avec tes mots, sans filtre."
            />
            <div className="mt-6 flex justify-between items-center">
              <button
                onClick={() => setStep(Math.max(0, step - 1))}
                disabled={step === 0}
                className="text-[12px] tracking-[0.18em] uppercase text-black/50 hover:text-black disabled:opacity-30 transition-colors"
              >
                Précédent
              </button>
              <button
                onClick={() => setStep(step + 1)}
                disabled={!(answers[step] || "").trim()}
                className="px-5 py-2.5 bg-black text-white text-[12px] tracking-[0.2em] uppercase rounded-full hover:bg-black/85 disabled:opacity-40 transition-colors"
              >
                Suivant →
              </button>
            </div>
          </motion.div>
        )}

        {step === questions.length && (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35 }}
          >
            <label className="block text-[11px] tracking-[0.25em] uppercase text-black/50 mb-3">
              Signataire
            </label>
            <p className="font-serif italic text-black/85 text-[18px] leading-relaxed mb-5">
              Sous quel nom (ou quelles initiales) veux-tu sceller cet acte ?
            </p>
            <input
              type="text"
              value={signataire}
              onChange={(e) => setSignataire(e.target.value)}
              autoFocus
              className="w-full bg-white border border-black/15 rounded-xl px-4 py-3 text-[16px] focus:outline-none focus:ring-2 focus:ring-rose-400/40 focus:border-rose-400/60 transition-colors mb-6"
              placeholder="Ex : Mikaël · Léa & Marc · Initiales libres"
            />

            <details className="mb-6">
              <summary className="text-[12px] tracking-[0.18em] uppercase text-black/50 cursor-pointer hover:text-black transition-colors">
                Préférer une intention libre (remplace les réponses)
              </summary>
              <textarea
                value={intentionLibre}
                onChange={(e) => setIntentionLibre(e.target.value)}
                rows={4}
                className="mt-3 w-full bg-white border border-black/15 rounded-xl px-4 py-3 text-[14px] focus:outline-none focus:ring-2 focus:ring-rose-400/40 focus:border-rose-400/60 transition-colors"
                placeholder="Une seule phrase, ton intention pure."
              />
            </details>

            {error && (
              <div className="mb-5 p-3 rounded-lg bg-red-50 border border-red-200 text-red-700 text-[13px]">
                {error}
              </div>
            )}

            <div className="flex justify-between items-center">
              <button
                onClick={() => setStep(step - 1)}
                disabled={sealing}
                className="text-[12px] tracking-[0.18em] uppercase text-black/50 hover:text-black transition-colors"
              >
                Précédent
              </button>
              <button
                onClick={handleSeal}
                disabled={sealing}
                className="px-6 py-3 bg-rose-600 text-white text-[12px] tracking-[0.2em] uppercase rounded-full hover:bg-rose-700 disabled:opacity-50 transition-colors inline-flex items-center gap-2"
              >
                {sealing ? (
                  <>
                    <span className="w-3 h-3 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                    Aïma scelle…
                  </>
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4" />
                    Sceller maintenant
                  </>
                )}
              </button>
            </div>
            <p className="mt-6 text-[11px] text-black/40 leading-relaxed">
              En scellant, tu autorises Aïma à graver cette intention dans le registre AIME®
              avec horodatage à la microseconde, hash SHA-256, code AIME-XXX-XXX, et filiation Soleau-2024.
              Cet acte ne remplace pas un acte notarié.
            </p>
          </motion.div>
        )}
      </div>
    </main>
  );
}