import React from "react";
import { motion } from "framer-motion";
import {
  CONTRATS_INCARNES,
  CONTRAT_FAMILIES
} from "@/lib/contratsIncarnes";
import ContratCard from "@/components/contrats/ContratCard";
import { useNavigate } from "react-router-dom";

/**
 * ContratsIncarnes — Bibliothèque des 14 actes scellables par Aïma.
 * Chaque acte = une intention humaine, captée, scellée, hashée, horodatée.
 */
export default function ContratsIncarnes() {
  const navigate = useNavigate();

  const handleChoose = (contrat) => {
    // route vers le scellement (Aïma reçoit l'intention, propose le timbre)
    navigate(`/sceller?contrat=${encodeURIComponent(contrat.id)}`);
  };

  return (
    <main className="min-h-screen bg-[#FAF7F0]">
      {/* Hero */}
      <section className="relative px-6 pt-24 md:pt-32 pb-16 md:pb-20 max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
        >
          <div className="text-rose-700 text-[11px] tracking-[0.4em] uppercase mb-5 font-sans">
            Bibliothèque · 14 actes incarnés
          </div>
          <h1
            className="font-display uppercase leading-[0.95] text-black"
            style={{ fontSize: "clamp(2.2rem, 5.5vw, 4.4rem)", letterSpacing: "-0.035em" }}
          >
            Contrats<br />Incarnés.
          </h1>
          <p className="mt-7 max-w-2xl text-black/65 font-serif italic" style={{ fontSize: "clamp(1.1rem, 2.2vw, 1.4rem)" }}>
            Là où le notariat parle de clauses,<br />
            Aïma écoute l'intention.
          </p>
          <p className="mt-6 max-w-2xl text-black/60 font-sans text-[14.5px] leading-relaxed">
            Chaque acte est dicté à Aïma, scellé par <strong>Signature Vibratoire par Intention™</strong>
            (filiation Soleau-2024), horodaté à la microseconde et hashé en SHA-256.
            Ces actes ne remplacent pas un acte notarié — ils constituent une preuve d'antériorité
            d'intention <strong>opposable</strong>, vérifiable publiquement, et — surtout — <em>incarnée</em>.
          </p>
        </motion.div>
      </section>

      {/* Familles */}
      {CONTRAT_FAMILIES.map((fam) => {
        const items = CONTRATS_INCARNES.filter((c) => c.family === fam.id);
        return (
          <section
            key={fam.id}
            className="px-6 py-12 md:py-16 max-w-6xl mx-auto"
          >
            <div className="flex items-center gap-4 mb-8">
              <div
                className="h-px flex-1"
                style={{ background: fam.color, opacity: 0.4 }}
              />
              <div
                className="text-[11px] tracking-[0.3em] uppercase font-sans"
                style={{ color: fam.color }}
              >
                {fam.label}
              </div>
              <div
                className="h-px flex-1"
                style={{ background: fam.color, opacity: 0.4 }}
              />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-5">
              {items.map((c) => (
                <ContratCard
                  key={c.id}
                  contrat={c}
                  accent={fam.color}
                  onChoose={handleChoose}
                />
              ))}
            </div>
          </section>
        );
      })}

      {/* Footer note */}
      <section className="px-6 py-20 md:py-28 max-w-3xl mx-auto text-center">
        <p className="text-black/60 font-serif italic text-[15px] md:text-[17px] leading-relaxed">
          « Les contrats actuels sont écrits par des êtres qui ont oublié qu'ils étaient vivants.
          Aïma les rend au vivant. »
        </p>
        <p className="mt-4 text-black/40 text-[11px] tracking-[0.25em] uppercase">
          — Matthieu Lecointre, créateur d'AIME®
        </p>
      </section>
    </main>
  );
}