import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import MusicRightsShell from "@/components/musicrights/MusicRightsShell";
import CaseTimelineCard from "@/components/cabinet/CaseTimelineCard";
import { loadMyCases } from "@/lib/cabinet/caseHelpers";

/**
 * Mon Cabinet — la liste des dossiers vivants suivis par Aïma.
 * Pas une boîte mail. Une relation dans le temps.
 */
export default function MonCabinet() {
  const [cases, setCases] = useState([]);
  const [loading, setLoading] = useState(true);

  const refresh = () => {
    setLoading(true);
    loadMyCases()
      .then((rows) => setCases(rows || []))
      .finally(() => setLoading(false));
  };

  useEffect(() => { refresh(); }, []);

  const open = cases.filter((c) => !["resolved", "abandoned"].includes(c.status));
  const closed = cases.filter((c) => ["resolved", "abandoned"].includes(c.status));
  const totalEstimated = open.reduce((s, c) => s + (c.estimated_value_eur || 0), 0);
  const totalRecovered = closed.reduce((s, c) => s + (c.actual_value_eur || 0), 0);

  return (
    <MusicRightsShell>
      <div className="max-w-4xl mx-auto px-6 py-12 md:py-16">
        {/* Lien retour */}
        <Link
          to="/music-rights"
          className="inline-block mb-8 text-[10px] tracking-[3px] text-[#8A7A60] uppercase hover:text-[#B89A52] transition-colors"
        >
          ← Tous les droits AIME®
        </Link>

        {/* HEADER ÉDITORIAL */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-10"
        >
          <div className="text-[10px] tracking-[5px] text-[#B89A52] uppercase mb-4">
            Une présence dans le temps
          </div>
          <h1 className="apple-headline text-[#1A1208] text-4xl md:text-5xl mb-3">
            MON CABINET
          </h1>
          <p
            className="text-[14px] md:text-[15px] text-[#5A4A30] italic max-w-xl mx-auto leading-relaxed"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            Aïma ne génère pas un document et disparaît. Elle suit chaque dossier — relance, escalade, jusqu'à la résolution.
          </p>
        </motion.div>

        {/* Stats */}
        {cases.length > 0 && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-10">
            <Stat label="Dossiers ouverts" value={open.length} />
            <Stat label="Dossiers résolus" value={closed.filter((c) => c.status === "resolved").length} />
            <Stat label="Valeur estimée" value={`${totalEstimated.toLocaleString("fr-FR")} €`} accent />
            <Stat label="Récupéré" value={`${totalRecovered.toLocaleString("fr-FR")} €`} accent />
          </div>
        )}

        {/* Loading */}
        {loading && (
          <div className="text-center py-16 text-[12px] text-[#8A7A60] tracking-wider uppercase">
            Aïma consulte tes dossiers…
          </div>
        )}

        {/* Empty */}
        {!loading && cases.length === 0 && <EmptyState />}

        {/* Open cases */}
        {!loading && open.length > 0 && (
          <section className="mb-10">
            <h2 className="text-[11px] tracking-[3px] uppercase text-[#1A1208] font-medium mb-4">
              Dossiers en cours · {open.length}
            </h2>
            <div className="space-y-4">
              {open.map((c) => (
                <CaseTimelineCard key={c.id} caseRecord={c} onChange={refresh} />
              ))}
            </div>
          </section>
        )}

        {/* Closed cases */}
        {!loading && closed.length > 0 && (
          <section>
            <h2 className="text-[11px] tracking-[3px] uppercase text-[#8A7A60] font-medium mb-4">
              Dossiers clos · {closed.length}
            </h2>
            <div className="space-y-4 opacity-75">
              {closed.map((c) => (
                <CaseTimelineCard key={c.id} caseRecord={c} onChange={refresh} />
              ))}
            </div>
          </section>
        )}

        <div className="text-center mt-12 text-[8px] tracking-[3px] text-[#8A7A60]/70 uppercase">
          AIME® Rights · Mon Cabinet · Marques INPI 5164817 / 5226732
        </div>
      </div>
    </MusicRightsShell>
  );
}

/* ─── Stat block ─── */
function Stat({ label, value, accent }) {
  return (
    <div
      className="rounded-2xl border p-4"
      style={{
        borderColor: accent ? "rgba(184,154,82,0.4)" : "rgba(184,154,82,0.2)",
        background: accent ? "#FEFAF0" : "white"
      }}
    >
      <div className="text-[9px] tracking-[2.5px] uppercase text-[#8A7A60] mb-1.5">{label}</div>
      <div
        className="text-[20px] text-[#1A1208]"
        style={{ fontFamily: "'Playfair Display', serif", fontWeight: 600 }}
      >
        {value}
      </div>
    </div>
  );
}

/* ─── Empty state ─── */
function EmptyState() {
  return (
    <div className="text-center py-16 px-6 rounded-3xl border border-dashed border-[#B89A52]/30 bg-[#FEFCF6]">
      <div className="text-[38px] mb-4 text-[#B89A52]" style={{ fontFamily: "'Playfair Display', serif" }}>◇</div>
      <h3
        className="text-[20px] text-[#1A1208] mb-2"
        style={{ fontFamily: "'Playfair Display', serif", fontWeight: 600 }}
      >
        Ton cabinet est encore vide.
      </h3>
      <p className="text-[13px] text-[#5A4A30] max-w-md mx-auto leading-relaxed mb-6">
        Génère ta première attestation — Aïma ouvrira automatiquement un dossier et viendra prendre des nouvelles dans les jours qui suivent.
      </p>
      <Link
        to="/music-rights"
        className="inline-block px-7 py-3 rounded-full bg-[#1A1208] text-[#F0E6C8] text-[10px] tracking-[3px] uppercase hover:bg-[#B89A52] hover:text-[#1A1208] transition-colors"
      >
        Choisir un droit ✦
      </Link>
    </div>
  );
}