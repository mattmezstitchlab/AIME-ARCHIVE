import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { NICE_CLASSES } from "@/lib/actesFondateurs";
import { Sparkles, ShieldCheck, Hash } from "lucide-react";
import LivingStamp from "@/components/stamp/LivingStamp";

/**
 * InpiToutesClasses — Attestation humoristique-mais-sérieuse :
 * AIME® s'incarne dans les 45 classes de la classification de Nice.
 */
export default function InpiToutesClasses() {
  const [stamp, setStamp] = useState(null);

  useEffect(() => {
    let alive = true;
    (async () => {
      const matches = await base44.entities.Stamp.filter({
        category: "acte_fondateur",
        subcategory: "acte-aime-toutes-classes-inpi"
      });
      if (alive && matches?.[0]) setStamp(matches[0]);
    })();
    return () => {
      alive = false;
    };
  }, []);

  return (
    <main className="min-h-screen bg-[#FAF7F0]">
      {/* Hero */}
      <section className="px-6 pt-24 md:pt-32 pb-16 max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
        >
          <div className="text-rose-700 text-[11px] tracking-[0.4em] uppercase mb-5 inline-flex items-center gap-2">
            <Sparkles className="w-3.5 h-3.5" />
            Acte fondateur · clin d'œil INPI
          </div>
          <h1
            className="font-display uppercase leading-[0.92] text-black"
            style={{ fontSize: "clamp(2.2rem, 5.5vw, 4.6rem)", letterSpacing: "-0.035em" }}
          >
            AIME® s'incarne<br />
            dans les <span className="text-rose-600">45 classes</span><br />
            de Nice. <span className="text-black/40">Mdrrr.</span>
          </h1>
          <p className="mt-7 max-w-2xl text-black/65 font-serif italic" style={{ fontSize: "clamp(1.1rem, 2.2vw, 1.4rem)" }}>
            Parce qu'AIME® n'est pas une marque qui choisit son rayon —<br />
            c'est une architecture qui traverse tous les rayons.
          </p>
        </motion.div>
      </section>

      {/* Le timbre fondateur (s'il existe) */}
      {stamp && (
        <section className="px-6 py-12 max-w-3xl mx-auto">
          <div className="bg-white border border-black/10 rounded-2xl p-8 md:p-10 flex flex-col md:flex-row gap-8 items-start">
            <LivingStamp stamp={stamp} size={200} />
            <div className="flex-1">
              <div className="text-emerald-700 text-[11px] tracking-[0.3em] uppercase mb-3 inline-flex items-center gap-2">
                <ShieldCheck className="w-3.5 h-3.5" />
                Acte scellé · {stamp.code}
              </div>
              <h2 className="font-display uppercase text-2xl mb-3 leading-tight">
                Attestation INPI Toutes Classes
              </h2>
              <blockquote className="border-l-2 border-rose-400/70 pl-4 italic text-black/70 font-serif text-[14.5px] leading-relaxed">
                « {stamp.intention_text} »
              </blockquote>
              {stamp.hash && (
                <div className="mt-5 flex items-center gap-2 text-[11px] text-black/50 font-mono">
                  <Hash className="w-3 h-3" />
                  {stamp.hash.slice(0, 24)}…
                </div>
              )}
            </div>
          </div>
        </section>
      )}

      {/* Les 45 classes */}
      <section className="px-6 py-16 md:py-20 max-w-6xl mx-auto">
        <div className="text-[11px] tracking-[0.3em] uppercase text-black/50 mb-6">
          La classification de Nice · 45 classes
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-2">
          {NICE_CLASSES.map((c) => (
            <motion.div
              key={c.n}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.3, delay: c.n * 0.012 }}
              className="bg-white border border-black/10 rounded-lg px-3 py-2.5 text-[12px] flex items-center gap-2 hover:border-rose-300 transition-colors"
            >
              <span className="font-mono text-rose-600 font-bold flex-shrink-0">
                {String(c.n).padStart(2, "0")}
              </span>
              <span className="text-black/70 truncate">{c.label}</span>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Mention humoristique */}
      <section className="px-6 py-20 md:py-28 max-w-3xl mx-auto text-center border-t border-black/10">
        <p className="text-black/65 font-serif italic" style={{ fontSize: "clamp(1.1rem, 2.4vw, 1.5rem)" }}>
          « Si l'INPI demande, on dit que oui, on est partout. Avec amour. »
        </p>
        <p className="mt-6 text-black/40 text-[11px] tracking-[0.3em] uppercase">
          — Matthieu Lecointre, créateur d'AIME®
        </p>
      </section>
    </main>
  );
}