import React from "react";
import ManifestoHero from "@/components/manifesto/ManifestoHero";
import ManifestoAcronym from "@/components/manifesto/ManifestoAcronym";
import ManifestoTrilogy from "@/components/manifesto/ManifestoTrilogy";
import ManifestoAnswers from "@/components/manifesto/ManifestoAnswers";
import ManifestoGameChanger from "@/components/manifesto/ManifestoGameChanger";
import ManifestoVerticals from "@/components/manifesto/ManifestoVerticals";
import ManifestoBorderless from "@/components/manifesto/ManifestoBorderless";
import ManifestoThoughts from "@/components/manifesto/ManifestoThoughts";
import ManifestoJoin from "@/components/manifesto/ManifestoJoin";
import ManifestoFooterMark from "@/components/manifesto/ManifestoFooterMark";

/**
 * Manifesto — La grande landing AIME®.
 * Style Game Changers Capital, mood sombre, mosaïque dense, typographie display.
 * Trilogie centrale : Passé · Présent · Futur.
 */
export default function Manifesto() {
  return (
    <main className="bg-black text-white">
      <ManifestoHero />
      <ManifestoAcronym />
      <ManifestoTrilogy />
      <ManifestoAnswers />
      <ManifestoGameChanger />
      <ManifestoVerticals />
      <ManifestoBorderless />
      <ManifestoThoughts />
      <ManifestoJoin />
      <ManifestoFooterMark />
    </main>
  );
}