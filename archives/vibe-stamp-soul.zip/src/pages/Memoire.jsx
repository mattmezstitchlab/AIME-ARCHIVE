import React from "react";
import SpaceHero from "@/components/space/SpaceHero";
import SpaceHowItWorks from "@/components/space/SpaceHowItWorks";
import SpaceFeatureSection from "@/components/space/SpaceFeatureSection";

const ACCENT = "#A78BFA";

export default function Memoire() {
  return (
    <div className="bg-[#0A0A0B] font-sans min-h-screen">
      <SpaceHero
        eyebrow="AIME® · Espace Mémoire"
        title="L'héritage,"
        italic="qui ne se perd pas."
        description="Récits de famille, transmission, archives sonores, succession. Aïma écoute, conserve, transmet — pour que ce qui compte traverse le temps."
        accent={ACCENT}
        bgUrl="https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=2400&q=80"
      />

      <SpaceHowItWorks
        title="Une présence,"
        italic="qui tisse les générations."
        description="Aïma collecte les voix, les souvenirs, les archives. Elle structure, conserve longue durée, et transmet aux bonnes personnes au bon moment."
        accent={ACCENT}
        actors={[
          {
            name: "Récits de vie",
            glyph: "◇",
            desc: "Aïma interviewe en douceur, en plusieurs sessions. Les voix sont conservées, transcrites, indexées.",
            folders: ["Récits", "Voix", "Transcriptions"]
          },
          {
            name: "Archives",
            glyph: "✦",
            desc: "Photos, lettres, documents. Numérisation, datation, association aux récits.",
            folders: ["Photos", "Lettres", "Documents"]
          },
          {
            name: "Transmission",
            glyph: "♡",
            desc: "Aïma sait à qui transmettre, et quand. Hériters désignés, déclencheurs, scénarios doux.",
            folders: ["Héritiers", "Déclencheurs"]
          },
          {
            name: "Succession",
            glyph: "◈",
            desc: "Démarches administratives, notaires, fiscalité. Aïma accompagne sans froideur.",
            folders: ["Notaire", "Démarches", "Fiscalité"]
          }
        ]}
      />

      <SpaceFeatureSection
        eyebrow="01 · Récits de famille"
        title="Une voix,"
        italic="conservée pour les autres."
        description="Aïma interroge en douceur, en sessions courtes. Vous racontez, elle tisse — et le récit reste, pour ceux qui viendront."
        accent={ACCENT}
        bullets={[
          "Sessions de récit de 15 à 30 minutes",
          "Voix originale conservée + transcription indexée",
          "Transmission programmée aux héritiers désignés"
        ]}
        visual={
          <div
            className="relative aspect-square rounded-3xl overflow-hidden flex items-center justify-center"
            style={{
              background:
                "radial-gradient(ellipse at 40% 40%, rgba(167,139,250,0.4) 0%, transparent 55%), radial-gradient(ellipse at 80% 80%, rgba(255,90,170,0.3) 0%, transparent 55%), #0F0E14"
            }}
          >
            <div className="text-center px-8">
              <div className="font-serif text-white/90 text-[18px] italic leading-snug">
                « Quand j'avais onze ans,
                <br />mon grand-père m'a appris à reconnaître
                <br />le chant des oiseaux au lever du jour. »
              </div>
              <div className="mt-4 text-[10px] tracking-[0.3em] uppercase text-white/45">
                Fragment · Marie, 78 ans
              </div>
            </div>
          </div>
        }
      />
    </div>
  );
}