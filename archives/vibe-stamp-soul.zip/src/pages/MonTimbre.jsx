import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import TimbreOnboardingShell from "@/components/timbre/TimbreOnboardingShell";
import TimbreCard from "@/components/timbre/TimbreCard";
import { getAnonymousId } from "@/lib/aimaSession";

export default function MonTimbre() {
  const navigate = useNavigate();
  const [timbre, setTimbre] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        let user = null;
        try { user = await base44.auth.me(); } catch (_) {}
        const filter = user?.email
          ? { owner_email: user.email }
          : { anonymous_id: getAnonymousId() };
        const list = await base44.entities.Timbre.filter(filter, "-issued_at", 1);
        if (!cancelled) {
          setTimbre(list?.[0] || null);
          setLoading(false);
        }
      } catch (e) {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, []);

  if (loading) {
    return (
      <TimbreOnboardingShell>
        <div className="text-center text-[#8A7A60] text-sm tracking-wider">Lecture du registre…</div>
      </TimbreOnboardingShell>
    );
  }

  if (!timbre) {
    return (
      <TimbreOnboardingShell>
        <div className="text-center">
          <h1 className="apple-headline text-[#1A1208] text-3xl md:text-4xl mb-3">
            Vous n'avez pas encore<br /><span className="text-[#B8963E]">de Timbre.</span>
          </h1>
          <p className="text-[12px] text-[#8A7A60] mb-8 tracking-wide">
            Créez votre identité dans le registre AIME® en 6 étapes.
          </p>
          <button
            onClick={() => navigate("/timbre/nouveau")}
            className="px-8 py-3.5 rounded-full bg-[#1A1208] text-[#F0E6C8] text-[10px] tracking-[3px] uppercase hover:bg-[#B8963E] hover:text-[#1A1208] transition-colors"
          >
            Créer mon Timbre
          </button>
        </div>
      </TimbreOnboardingShell>
    );
  }

  return (
    <TimbreOnboardingShell>
      <div className="text-center">
        <div className="text-[11px] tracking-[5px] text-[#B8963E] uppercase mb-3">
          Mon Timbre
        </div>
        <h1 className="apple-headline text-[#1A1208] text-3xl md:text-4xl mb-8">
          Bienvenue, <span className="text-[#B8963E]">{timbre.first_name}</span>.
        </h1>
        <div className="flex justify-center mb-8">
          <TimbreCard timbre={timbre} size="lg" />
        </div>
        <div className="space-y-2 text-[12px] text-[#4A3C28] mb-8 max-w-sm mx-auto">
          <div>
            Code : <span className="font-mono tracking-[0.3em] text-[#B8963E]">{timbre.code}</span>
          </div>
          <div>
            Registre : <strong className="text-[#B8963E]">#{String(timbre.registry_n).padStart(6, "0")}</strong>
          </div>
          <div className="text-[10px] text-[#8A7A60] tracking-wider uppercase">
            Visibilité : {timbre.visibility === "public" ? "Public" : "Privé"}
          </div>
        </div>
        <div className="flex justify-center gap-3">
          <button
            onClick={() => navigate("/registre")}
            className="px-7 py-3 rounded-full border border-[#D4B483] text-[#4A3C28] text-[10px] tracking-[3px] uppercase hover:bg-[#D4B483]/10 transition-colors"
          >
            Le Registre
          </button>
          <button
            onClick={() => navigate("/")}
            className="px-7 py-3 rounded-full bg-[#1A1208] text-[#F0E6C8] text-[10px] tracking-[3px] uppercase hover:bg-[#B8963E] hover:text-[#1A1208] transition-colors"
          >
            Retour à Aïma
          </button>
        </div>
      </div>
    </TimbreOnboardingShell>
  );
}