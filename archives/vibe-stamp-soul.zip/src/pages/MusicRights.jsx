import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import MusicRightsShell from "@/components/musicrights/MusicRightsShell";
import TimbreRightCard from "@/components/rights/TimbreRightCard";
import { RIGHTS_REGISTRY } from "@/lib/rights/registry";
import { loadMyCases } from "@/lib/cabinet/caseHelpers";

/**
 * MusicRights — hub central AIME® Rights.
 * Header éditorial · manifeste · grille des 12 droits-timbres · compteur live d'attestations.
 */
export default function MusicRights() {
  const [count, setCount] = useState(247);
  const [myCases, setMyCases] = useState([]);

  useEffect(() => {
    base44.entities.MusicRight.list("-registry_n", 1)
      .then((rows) => {
        if (rows?.[0]?.registry_n) setCount(Math.max(247, rows[0].registry_n));
      })
      .catch(() => {});
    loadMyCases().then((rows) => setMyCases(rows || [])).catch(() => {});
  }, []);

  const openCases = myCases.filter((c) => !["resolved", "abandoned"].includes(c.status));

  return (
    <MusicRightsShell>
      {/* HERO ÉDITORIAL */}
      <div className="max-w-5xl mx-auto px-6 pt-14 md:pt-20 pb-10">
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center"
        >
          <div className="text-[10px] tracking-[5px] text-[#B89A52] uppercase mb-5">
            Une innovation AIME®
          </div>
          <h1 className="apple-headline text-[#1A1208] text-4xl md:text-5xl lg:text-6xl mb-2">
            VOS DROITS
          </h1>
          <h1 className="apple-headline text-[#B89A52] text-4xl md:text-5xl lg:text-6xl mb-7">
            MÉRITENT D'ÊTRE TIMBRÉS.
          </h1>
          <p className="text-[15px] md:text-[16px] text-[#4A3C28] max-w-xl mx-auto leading-relaxed">
            Ce qui vous dérange a un nom. Et maintenant un document. Naïma vous guide, cas par cas, vers votre attestation personnalisée — juridique, scientifique, signable.
          </p>

          {/* Pills */}
          <div className="flex flex-wrap justify-center gap-2 mt-7">
            {["Juridique", "Scientifique", "Personnalisé", "PDF prêt à signer", "100 % gratuit"].map((t) => (
              <span
                key={t}
                className="px-3 py-1 rounded-full border border-[#B89A52]/30 text-[10px] tracking-[2px] uppercase text-[#8A7A60]"
              >
                {t}
              </span>
            ))}
          </div>

          {/* Compteur live */}
          <div className="mt-6 inline-flex items-center gap-2 text-[10px] tracking-[3px] text-[#8A7A60] uppercase">
            <span className="inline-block w-1.5 h-1.5 rounded-full bg-[#849E65] animate-pulse" />
            <span className="text-[#1A1208] font-mono font-semibold tabular-nums">
              #{String(count).padStart(6, "0")}
            </span>
            <span>attestations générées</span>
          </div>
        </motion.div>

        {/* Manifeste — Moi · Univers · Sacré · Inaliénable · Conscient */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="text-center mt-12 md:mt-14"
        >
          <div className="flex flex-wrap justify-center items-center gap-2 mb-3">
            {["Moi", "Univers", "Sacré", "Inaliénable", "Conscient"].map((w, i) => (
              <React.Fragment key={w}>
                <span
                  className="text-[11px] md:text-[12px] tracking-[4px] uppercase text-[#1A1208] font-medium"
                  style={{ fontFamily: "'Playfair Display', serif" }}
                >
                  {w}
                </span>
                {i < 4 && <span className="text-[#B89A52]">·</span>}
              </React.Fragment>
            ))}
          </div>
          <p
            className="text-[13px] md:text-[14px] text-[#5A4A30] italic max-w-xl mx-auto leading-relaxed"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            MUSIC — parce que vos droits, comme la musique, appartiennent à tout le monde.
          </p>
        </motion.div>
      </div>

      {/* MON CABINET — bannière d'accès si dossiers existants */}
      {openCases.length > 0 && (
        <div className="max-w-6xl mx-auto px-6 mb-8">
          <Link
            to="/mon-cabinet"
            className="block rounded-3xl border border-[#B89A52]/30 bg-gradient-to-br from-[#FEFAF0] to-[#FBF6E8] p-5 md:p-6 hover:border-[#B89A52]/60 transition-colors group"
          >
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-4 min-w-0">
                <div className="w-11 h-11 rounded-full bg-[#B89A52] text-[#1A1208] flex items-center justify-center text-[16px] font-serif flex-shrink-0">
                  N
                </div>
                <div className="min-w-0">
                  <div className="text-[9px] tracking-[3px] uppercase text-[#B89A52] mb-1 font-medium">
                    Mon Cabinet · suivi par Aïma
                  </div>
                  <div className="text-[15px] md:text-[16px] text-[#1A1208] font-medium">
                    {openCases.length} dossier{openCases.length > 1 ? "s" : ""} en cours
                  </div>
                  <div className="text-[12px] text-[#5A4A30] italic" style={{ fontFamily: "'Playfair Display', serif" }}>
                    Aïma suit chacun jusqu'à résolution.
                  </div>
                </div>
              </div>
              <div className="text-[10px] tracking-[3px] uppercase text-[#B89A52] group-hover:text-[#1A1208] transition-colors whitespace-nowrap">
                Ouvrir →
              </div>
            </div>
          </Link>
        </div>
      )}

      {/* GRILLE DE TIMBRES */}
      <div className="max-w-6xl mx-auto px-6 pb-16">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-5 gap-y-7 md:gap-x-6 md:gap-y-9">
          {RIGHTS_REGISTRY.map((r, i) => (
            <TimbreRightCard key={r.slug} right={r} delay={i * 0.04} />
          ))}
        </div>
      </div>

      {/* FOOTER ÉDITORIAL */}
      <div className="max-w-3xl mx-auto px-6 pb-16 text-center space-y-2">
        <p className="text-[10px] tracking-[3px] text-[#1A1208] uppercase font-medium">
          AIME® Rights · Premier cabinet citoyen automatisé · Marques INPI 5164817 / 5226732
        </p>
        <p className="text-[11px] text-[#8A7A60] italic max-w-md mx-auto leading-relaxed">
          Ces attestations sont des outils d'information citoyenne. Pour toute situation complexe, consultez un avocat spécialisé.
        </p>
      </div>
    </MusicRightsShell>
  );
}