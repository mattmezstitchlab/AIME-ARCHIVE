import React from "react";
import SpaceHero from "@/components/space/SpaceHero";
import SpaceHowItWorks from "@/components/space/SpaceHowItWorks";
import SpaceFeatureSection from "@/components/space/SpaceFeatureSection";

const ACCENT = "#C77DFF";

export default function Intermittents() {
  return (
    <div className="bg-[#0A0A0B] font-sans min-h-screen">
      <SpaceHero
        eyebrow="AIME® · Espace Intermittents"
        title="L'art,"
        italic="pas la paperasse."
        description="Annexes 8 & 10, AEM, CDDU, 507h, Audiens, Pôle Emploi spectacle. Aïma absorbe la complexité administrative pour que vous restiez sur le geste."
        accent={ACCENT}
        bgUrl="https://res.cloudinary.com/divou1vcx/image/upload/v1772843090/mainpiano_mjh543.jpg"
      />

      <SpaceHowItWorks
        title="Une présence,"
        italic="qui suit vos cachets."
        description="Aïma compte vos heures, surveille votre seuil 507h, prépare vos AEM, archive vos CDDU. Vous facturez, elle structure."
        accent={ACCENT}
        actors={[
          {
            name: "Compteur 507h",
            glyph: "◇",
            desc: "Suivi temps réel de vos heures sur 12 mois glissants. Aïma alerte à 400h, 480h, 507h.",
            folders: ["Heures", "Cachets", "Annexe 8", "Annexe 10"]
          },
          {
            name: "Documents",
            glyph: "✦",
            desc: "AEM, CDDU, feuilles de paie, attestations. Tout archivé, daté, retrouvable d'un mot.",
            folders: ["AEM", "CDDU", "Paie", "Attestations"]
          },
          {
            name: "Organismes",
            glyph: "◈",
            desc: "Audiens, Pôle Emploi spectacle, AFDAS. Aïma traduit, prépare les démarches, anticipe les renouvellements.",
            folders: ["Audiens", "Pôle Emploi", "AFDAS"]
          },
          {
            name: "Devis & contrats",
            glyph: "♪",
            desc: "Devis pré-rédigés à votre voix, contrats CDDU conformes, négociation cadrée par les conventions.",
            folders: ["Devis", "Contrats", "Tarifs"]
          }
        ]}
      />

      <SpaceFeatureSection
        eyebrow="01 · Le seuil 507"
        title="507 heures,"
        italic="surveillées en continu."
        description="Aïma additionne, déduit les exclusions, projette à 12 mois. Plus de panique en juin : vous savez exactement où vous en êtes."
        accent={ACCENT}
        bullets={[
          "Compteur live des heures et cachets",
          "Alertes à 400h, 480h, 507h — anticipées",
          "Projection sur 12 mois glissants avec scénarios"
        ]}
        visual={
          <div
            className="relative aspect-square rounded-3xl overflow-hidden flex items-center justify-center"
            style={{
              background:
                "radial-gradient(ellipse at 50% 30%, rgba(199,125,255,0.45) 0%, transparent 60%), #0F0E14"
            }}
          >
            <div className="text-center">
              <div className="text-[11px] tracking-[0.3em] uppercase text-white/55 mb-3">Compteur 507h</div>
              <div className="font-serif text-white/95 text-[72px] leading-none">482</div>
              <div className="text-[12px] text-white/50 mt-2">heures · 25 restantes</div>
              <div className="mt-5 mx-auto h-1 w-48 rounded-full bg-white/10 overflow-hidden">
                <div className="h-full rounded-full" style={{ width: "95%", background: ACCENT }} />
              </div>
            </div>
          </div>
        }
      />
    </div>
  );
}