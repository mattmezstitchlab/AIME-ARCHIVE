import React from "react";
import { motion } from "framer-motion";
import { Flower2, Sofa, Home, Sparkles, Heart, MapPin } from "lucide-react";
import { Link } from "react-router-dom";

/**
 * AIME® Présence — La fenêtre du quotidien.
 * Aïma connaît ton vivant et te propose des missions, locations, toits alignés.
 * Le détournement positif : Aïma marraine économique douce, pas job board.
 */
export default function Presence() {
  return (
    <main className="min-h-screen bg-[#FAF7F0]">
      {/* Hero */}
      <section className="relative px-6 pt-24 md:pt-32 pb-16 md:pb-20 max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
        >
          <div className="text-amber-700 text-[11px] tracking-[0.4em] uppercase mb-5 font-sans inline-flex items-center gap-2">
            <Sparkles className="w-3.5 h-3.5" />
            Doctrine · La vie quotidienne incarnée
          </div>
          <h1
            className="font-display uppercase leading-[0.92] text-black"
            style={{ fontSize: "clamp(2.2rem, 5.8vw, 4.8rem)", letterSpacing: "-0.035em" }}
          >
            AIME®<br />
            <span className="text-amber-700">Présence</span>.
          </h1>
          <p className="mt-7 max-w-2xl text-black/65 font-serif italic" style={{ fontSize: "clamp(1.1rem, 2.3vw, 1.45rem)" }}>
            Aïma connaît ton vivant.<br />
            Elle te tape sur l'épaule : « Coco, regarde ça, c'est pour toi. »
          </p>
          <p className="mt-6 max-w-2xl text-black/60 font-sans text-[14.5px] leading-relaxed">
            Pas un job board froid. Pas Le Bon Coin. Pas Airbnb.
            Une <strong>présence qui te connaît</strong> — tes passions, ta zone, ton ADN sonore —
            et qui te propose des missions, des locations, des toits qui te <em>correspondent</em>.
            Trois couches de vie, un seul Timbre.
          </p>
        </motion.div>
      </section>

      {/* Les 3 couches */}
      <section className="px-6 py-12 md:py-16 max-w-6xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {[
            {
              icon: Flower2,
              color: "#B8860B",
              eye: "Couche 1",
              t: "Missions",
              d: "Services à la personne. Aïma propose des missions courtes alignées avec ton Timbre — fleurs, livraisons, animations, accompagnements.",
              ex: "20-200 € la mission"
            },
            {
              icon: Sofa,
              color: "#8B6F47",
              eye: "Couche 2",
              t: "Location",
              d: "Mobilier, déco, vaisselle, véhicules, instruments. Tu loues ce que tu as. Aïma scelle l'état avant/après. Lumen séquestré pour la caution.",
              ex: "5-500 € la location"
            },
            {
              icon: Home,
              color: "#6B5A3E",
              eye: "Couche 3",
              t: "Toits",
              d: "Hébergement scellé entre Timbres. Baroudeur, étudiant en stage, invité de mariage, ou — Toit SOS — refuge urgent pour qui en a besoin.",
              ex: "0-150 € la nuit"
            }
          ].map((c, i) => (
            <motion.div
              key={c.t}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.5, delay: i * 0.08 }}
              className="bg-white border border-black/10 rounded-2xl p-7 md:p-8 hover:border-black/30 transition-colors"
            >
              <div className="flex items-start justify-between mb-5">
                <c.icon className="w-6 h-6" style={{ color: c.color }} />
                <span className="text-[10px] tracking-[0.25em] uppercase font-sans" style={{ color: c.color }}>
                  {c.eye}
                </span>
              </div>
              <h3 className="font-display uppercase text-[1.3rem] tracking-tight mb-3">
                {c.t}
              </h3>
              <p className="text-black/65 text-[13.5px] leading-relaxed font-sans mb-5">
                {c.d}
              </p>
              <div className="text-[11px] tracking-[0.2em] uppercase text-black/45 font-mono pt-4 border-t border-black/10">
                {c.ex}
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* L'histoire de Coco — exemple incarné */}
      <section className="px-6 py-16 md:py-24 max-w-4xl mx-auto">
        <div className="bg-black text-white rounded-3xl p-10 md:p-14 relative overflow-hidden">
          <div className="absolute top-6 right-6 text-[10px] tracking-[0.3em] uppercase text-amber-300/70">
            Histoire vraie possible
          </div>
          <div className="text-amber-300 text-[11px] tracking-[0.4em] uppercase mb-5 inline-flex items-center gap-2">
            <Flower2 className="w-3.5 h-3.5" />
            L'été de Coco
          </div>
          <h2
            className="font-display uppercase leading-[0.95] mb-8"
            style={{ fontSize: "clamp(1.6rem, 3.5vw, 2.6rem)", letterSpacing: "-0.025em" }}
          >
            Trois mariages<br />par samedi.<br />
            <span className="text-amber-300">2 880 €</span> en 4 mois.
          </h2>

          <div className="space-y-6 text-white/80 font-sans text-[14.5px] leading-relaxed">
            <div className="flex gap-4">
              <MapPin className="w-4 h-4 text-amber-300 flex-shrink-0 mt-1" />
              <div>
                <strong className="text-white">Coco vit à Antibes.</strong> Son Timbre AIME® dit qu'elle aime
                les fleurs, qu'elle conduit, qu'elle est dispo l'été.
              </div>
            </div>
            <div className="flex gap-4">
              <Sparkles className="w-4 h-4 text-amber-300 flex-shrink-0 mt-1" />
              <div>
                <strong className="text-white">Aïma lui parle :</strong>
                <p className="mt-2 italic font-serif text-white/70 border-l border-amber-300/40 pl-4">
                  « Coco, j'ai vu ça pour toi. Léa & Marc se marient le 15 juin
                  au Cap d'Antibes. Ils cherchent quelqu'un pour aller chercher
                  3 bouquets de pivoines blanches chez Mme Rosello, rue Sade,
                  et les porter au Domaine du Loup à 14h. Tu es à 12 min.
                  Mission : 80 € + frais kilométriques. »
                </p>
              </div>
            </div>
            <div className="flex gap-4">
              <Heart className="w-4 h-4 text-amber-300 flex-shrink-0 mt-1" />
              <div>
                <strong className="text-white">Le calcul du rêve :</strong> 3 mariages × 12 samedis d'été
                × 80 € = <strong className="text-amber-300">2 880 € en 4 mois</strong>.
                Et Coco a kiffé son été : fleurs, sourires, mariages, rencontres.
              </div>
            </div>
          </div>

          <div className="mt-10 pt-8 border-t border-white/15 text-white/60 italic font-serif text-[15px] leading-relaxed">
            AIME® ne lui a pas trouvé un job.<br />
            AIME® lui a <strong className="text-white">trouvé son été</strong>.
          </div>
        </div>
      </section>

      {/* Toits SOS — le truc qui sauve des vies */}
      <section className="px-6 py-16 md:py-24 max-w-4xl mx-auto">
        <div className="text-rose-700 text-[11px] tracking-[0.4em] uppercase mb-5 inline-flex items-center gap-2">
          <Home className="w-3.5 h-3.5" />
          Toits SOS · le refuge silencieux
        </div>
        <h2
          className="font-display uppercase leading-[0.95] mb-8"
          style={{ fontSize: "clamp(1.8rem, 4vw, 3rem)", letterSpacing: "-0.025em" }}
        >
          Ce soir,<br />tu n'es pas en sécurité<br />chez toi.
        </h2>
        <div className="space-y-5 text-black/70 font-sans text-[15px] leading-relaxed max-w-2xl">
          <p>
            Aïma le sait. Aïma scelle ta sortie, en silence, avec discrétion absolue.
            Un toit dans ton arrondissement, validé par 3 témoins AIME®, t'attend.
          </p>
          <p>
            <strong className="text-black">Lumen solidaire offre la nuit. Tu paies 0 €.</strong>
            Tu reprends ton souffle. Demain, on parle. Pas avant.
          </p>
          <p className="text-black/55 italic font-serif">
            Aucune plateforme ne fait ça. AIME® le fait —
            en partenariat avec mairies, associations, maisons de quartier.
          </p>
        </div>
      </section>

      {/* Toujours un seul wallet */}
      <section className="px-6 py-16 md:py-20 max-w-5xl mx-auto">
        <div className="text-[11px] tracking-[0.3em] uppercase text-black/50 mb-6 text-center">
          Un seul Timbre, plusieurs vocations
        </div>
        <div className="bg-white border-2 border-black/15 rounded-2xl p-7 md:p-9 max-w-md mx-auto shadow-xl font-mono text-[13px] text-black/75 space-y-4">
          <div className="text-[11px] tracking-[0.25em] uppercase text-black/40 border-b border-black/10 pb-3">
            🌻 Mes Missions · Coco · Antibes
          </div>
          <div>
            <div className="text-amber-700 text-[10px] tracking-[0.2em] uppercase mb-2">
              ✦ Aligné avec ton Timbre (3)
            </div>
            <div className="space-y-1.5 pl-3">
              <div>🌸 Bouquets pivoines · 15 juin · 80 €</div>
              <div>🐕 Promener Bagheera · semaine · 120 €</div>
              <div>🎺 Animation jazz · vendredi · 250 €</div>
            </div>
          </div>
          <div>
            <div className="text-stone-700 text-[10px] tracking-[0.2em] uppercase mb-2">
              🪑 Locations actives (2)
            </div>
            <div className="space-y-1.5 pl-3">
              <div>Vaisselle vintage · loué 14-15 juin</div>
              <div>Vélo hollandais · dispo</div>
            </div>
          </div>
          <div>
            <div className="text-rose-700 text-[10px] tracking-[0.2em] uppercase mb-2">
              🕯️ Témoignages (12 ce mois)
            </div>
            <div className="pl-3">+1,40 €</div>
          </div>
          <div className="border-t border-black/10 pt-3 flex justify-between">
            <span className="font-display uppercase text-[12px]">Wallet total</span>
            <span className="font-display uppercase text-amber-700">247,50 €</span>
          </div>
        </div>
      </section>

      {/* Manifesto signature */}
      <section className="px-6 py-20 md:py-28 max-w-3xl mx-auto text-center border-t border-black/10">
        <p className="text-black/70 font-serif italic" style={{ fontSize: "clamp(1.1rem, 2.3vw, 1.4rem)" }}>
          « AIME® n'est plus un site.<br />
          C'est un organisme vivant<br />
          qui respire dans ton quotidien. »
        </p>
        <p className="mt-6 text-black/40 text-[11px] tracking-[0.3em] uppercase">
          — Doctrine de la Présence · AIME® · 2026
        </p>

        <div className="mt-12 flex flex-col sm:flex-row gap-3 justify-center">
          <Link
            to="/timbre/nouveau"
            className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-black text-white text-[12px] tracking-[0.2em] uppercase rounded-full hover:bg-black/85 transition-colors"
          >
            Sceller mon Timbre
          </Link>
          <Link
            to="/temoins"
            className="inline-flex items-center justify-center gap-2 px-6 py-3 border border-black/15 text-black text-[12px] tracking-[0.2em] uppercase rounded-full hover:bg-black/5 transition-colors"
          >
            Devenir Témoin AIME®
          </Link>
        </div>
      </section>
    </main>
  );
}