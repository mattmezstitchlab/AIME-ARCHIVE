import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Loader2, KeyRound } from "lucide-react";
import { base44 } from "@/api/base44Client";
import AIStamp from "@/components/aimemachine/AIStamp";

/**
 * Carte — Page publique pour lire une carte postale avec son code privé.
 * URL : /carte (saisie manuelle) ou /carte?code=PC-XXXX-XXXX
 */
export default function Carte() {
  const params = new URLSearchParams(window.location.search);
  const initialCode = params.get("code") || "";

  const [code, setCode] = useState(initialCode);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [postcard, setPostcard] = useState(null);

  const handleLookup = async () => {
    setError(null);
    setLoading(true);
    try {
      const list = await base44.entities.Postcard.filter({ code: code.trim().toUpperCase() });
      if (!list || list.length === 0) {
        setError("Aucune carte avec ce code.");
        setPostcard(null);
      } else {
        setPostcard(list[0]);
      }
    } catch (e) {
      setError(e.message || "Erreur");
    } finally {
      setLoading(false);
    }
  };

  // Auto-lookup si code dans l'URL
  useEffect(() => {
    if (initialCode) handleLookup();
    // eslint-disable-next-line
  }, []);

  const pos = postcard?.stamp_position || { x: 85, y: 18, rotation: -8 };

  return (
    <main className="min-h-screen w-full bg-black px-5 py-20 flex flex-col items-center">
      <div className="text-white/50 text-[11px] tracking-[0.4em] uppercase mb-4 font-sans">
        AIME® · Carte privée
      </div>

      {!postcard ? (
        <div className="w-full max-w-md flex flex-col items-center gap-5">
          <h1
            className="text-white font-display uppercase text-center leading-tight"
            style={{ fontSize: "clamp(2rem, 6vw, 3.5rem)", letterSpacing: "-0.03em" }}
          >
            Une carte<br />t'attend
          </h1>
          <p className="text-white/50 text-center text-[13px] font-sans max-w-xs">
            Saisis le code privé que tu as reçu pour lire la carte qui t'est adressée.
          </p>
          <div className="w-full flex flex-col gap-3 mt-4">
            <input
              type="text"
              value={code}
              onChange={(e) => setCode(e.target.value.toUpperCase())}
              placeholder="PC-XXXX-XXXX"
              className="w-full bg-white/5 border border-white/15 rounded-full px-5 py-3.5 text-white text-center text-[16px] font-mono tracking-[0.2em] placeholder-white/25 focus:outline-none focus:border-white/50 focus:bg-white/10 transition-colors"
            />
            <button
              onClick={handleLookup}
              disabled={code.trim().length < 4 || loading}
              className="rounded-full px-7 py-3.5 flex items-center justify-center gap-2 text-[12px] tracking-[0.25em] uppercase font-sans transition-all disabled:opacity-40 bg-white text-black hover:bg-white/90"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" /> Lecture…
                </>
              ) : (
                <>
                  <KeyRound className="w-4 h-4" /> Ouvrir la carte
                </>
              )}
            </button>
            {error && <div className="text-rose-400 text-[12px] font-sans text-center">{error}</div>}
          </div>
        </div>
      ) : (
        <motion.div
          initial={{ opacity: 0, y: 20, rotateY: -10 }}
          animate={{ opacity: 1, y: 0, rotateY: 0 }}
          transition={{ duration: 0.9 }}
          className="w-full max-w-2xl"
        >
          <div
            className="relative w-full bg-[#FBF6E9] rounded-lg shadow-2xl overflow-hidden"
            style={{ aspectRatio: "3 / 2" }}
          >
            <img
              src={postcard.card_image_url}
              alt="carte"
              className="absolute inset-0 w-full h-1/2 object-cover"
            />
            <div className="absolute bottom-0 inset-x-0 h-1/2 p-6 overflow-hidden">
              <p
                className="text-[#2a1a08] leading-snug"
                style={{ fontFamily: "'Caveat', 'Brush Script MT', cursive", fontSize: 22 }}
              >
                {postcard.message_handwritten}
              </p>
            </div>
            <div
              className="absolute"
              style={{
                left: `${pos.x}%`,
                top: `${pos.y}%`,
                transform: `translate(-50%, -50%) rotate(${pos.rotation}deg)`
              }}
            >
              <AIStamp imageUrl={postcard.stamp_image_url} code={null} size={130} />
            </div>
            <div
              className="absolute"
              style={{
                left: `${Math.max(10, pos.x - 18)}%`,
                top: `${Math.min(40, pos.y + 8)}%`,
                transform: `rotate(${pos.rotation - 12}deg)`,
                opacity: 0.7
              }}
            >
              <div
                className="rounded-full border-[3px] border-[#1a1a4a] px-4 py-2.5 text-center"
                style={{ borderStyle: "double" }}
              >
                <div className="text-[#1a1a4a] font-display uppercase text-[10px] leading-tight">
                  {postcard.tampon_city}
                </div>
                <div className="text-[#1a1a4a] text-[8px] leading-tight font-mono mt-0.5">
                  {new Date(postcard.tampon_date || Date.now()).toLocaleDateString("fr-FR")}
                </div>
              </div>
            </div>
          </div>

          <div className="text-center mt-6 text-white/40 text-[11px] font-mono tracking-[0.2em]">
            {postcard.code}
          </div>
        </motion.div>
      )}
    </main>
  );
}