import React from "react";
import SpaceHero from "@/components/space/SpaceHero";
import SpaceHowItWorks from "@/components/space/SpaceHowItWorks";
import SpaceFeatureSection from "@/components/space/SpaceFeatureSection";

const ACCENT = "#B89A52";

/**
 * Noyau — Page dédiée à l'outil NOYAU.
 * Architecturée comme les autres pages dynamiques :
 * SpaceHero · SpaceHowItWorks · SpaceFeatureSection.
 * Pour les personnes atteintes de SLA — et tous ceux qui veulent transmettre.
 */
export default function Noyau() {
  return (
    <div className="bg-[#0A0A0B] font-sans min-h-screen">
      {/* 1. HERO */}
      <SpaceHero
        eyebrow="AIME® · Noyau"
        title="Ce que tu es,"
        italic="ne peut pas être effacé."
        description="Capturer la voix, les histoires, les valeurs d'une personne — avant que la maladie ne progresse. Aïma garde le Noyau. Pour toujours."
        accent={ACCENT}
        bgUrl="https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=1600&q=85"
      />

      {/* 2. COMMENT ÇA MARCHE — les 4 phases */}
      <SpaceHowItWorks
        eyebrow="Le chemin du Noyau"
        title="Quatre phases,"
        italic="une seule mémoire."
        description="Aïma t'accompagne pas à pas. Tu n'as rien à organiser — elle écoute, elle classe, elle garde. À ton rythme, sans pression."
        accent={ACCENT}
        actors={[
          {
            name: "Capture",
            glyph: "◇",
            desc: "Aïma pose des questions douces, à ton rythme. Chaque réponse est gardée en voix et en texte.",
            folders: ["Souvenirs", "Histoires", "Valeurs", "Conseils"]
          },
          {
            name: "Voix",
            glyph: "♪",
            desc: "Plus tu enregistres, plus le clone vocal s'affine. Au-delà de 80%, Aïma peut prêter ta voix.",
            folders: ["Modèle vocal", "Qualité", "Consentement"]
          },
          {
            name: "Mémoire",
            glyph: "❋",
            desc: "Ta bibliothèque vivante. Aïma classe, propose des liens entre les souvenirs.",
            folders: ["Privé", "Cercle proche", "Futur"]
          },
          {
            name: "Transmission",
            glyph: "✉",
            desc: "Messages déclenchés par des événements futurs. Aïma garde et délivre le moment venu.",
            folders: ["À l'enfant", "Au jour J", "Au doute"]
          }
        ]}
      />

      {/* 3. FEATURE — Aïma, présence et non outil médical */}
      <SpaceFeatureSection
        eyebrow="01 · Une présence, pas un outil"
        title="Aïma écoute."
        italic="Sans pression, sans diagnostic."
        description="NOYAU n'est pas un service médical. C'est une présence. Aïma garde ce que tu confies — ta voix, tes histoires, ce que tu veux transmettre. À ton rythme. Confidentiel. Chiffré. Stocké en Europe."
        accent={ACCENT}
        bullets={[
          "Gratuit pour les personnes atteintes de SLA et leurs familles",
          "Confidentialité absolue · données chiffrées · jamais commercial",
          "Conçu avec des familles SLA · ARSLA et associations partenaires"
        ]}
        visual={
          <div
            className="relative aspect-square rounded-3xl overflow-hidden"
            style={{
              background:
                "radial-gradient(ellipse at 40% 30%, rgba(184,154,82,0.4) 0%, transparent 55%), radial-gradient(ellipse at 80% 80%, rgba(212,180,131,0.25) 0%, transparent 55%), #0F0E0A"
            }}
          >
            <div className="absolute inset-0 flex items-center justify-center px-10">
              <div className="text-center space-y-4">
                <div className="text-[10px] tracking-[0.35em] uppercase text-[#D4B483]">
                  Aïma · Noyau
                </div>
                <div className="font-serif italic text-white/90 text-[18px] md:text-[20px] leading-snug">
                  « Je ne suis pas un outil médical.<br />
                  Je suis une présence. »
                </div>
                <div className="text-white/45 text-[11.5px] font-sans">
                  — Dis-moi juste ton prénom.
                </div>
              </div>
            </div>
          </div>
        }
      />

      {/* 4. FEATURE — Le legs Yourcenar */}
      <SpaceFeatureSection
        eyebrow="02 · L'héritage"
        title="Charcot prend le corps."
        italic="NOYAU garde l'âme."
        description="Au-delà de la maladie, le Noyau devient page mémoire vivante — tes mots arrivent à ceux que tu aimes, au moment juste. Une transmission qui ne s'éteint pas avec le souffle."
        accent={ACCENT}
        reverse
        bullets={[
          "Messages programmés par événements de vie (naissance, mariage, doute)",
          "Voix synthétisée le jour J — si tu l'as consenti",
          "Page mémoire conservée longue durée · partage privé"
        ]}
        visual={
          <div
            className="relative aspect-square rounded-3xl overflow-hidden border border-[#B89A52]/20"
            style={{
              background:
                "linear-gradient(180deg, #1A1208 0%, #0A0806 100%)"
            }}
          >
            <div className="absolute inset-0 flex items-center justify-center px-10">
              <div className="text-center space-y-3">
                <div className="text-[10px] tracking-[0.35em] uppercase text-[#B89A52]/80">
                  Point Zéro des Vivants
                </div>
                <div className="font-serif italic text-white/90 text-[17px] md:text-[19px] leading-snug">
                  « Ce qui se transmet<br />a un poids.<br />
                  Le poids appelle le geste. »
                </div>
                <div className="text-white/35 text-[10.5px] font-sans tracking-[0.15em] uppercase mt-4">
                  AIME® Noyau
                </div>
              </div>
            </div>
          </div>
        }
      />
    </div>
  );
}