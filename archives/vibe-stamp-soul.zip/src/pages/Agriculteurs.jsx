import React from "react";
import SpaceHero from "@/components/space/SpaceHero";
import SpaceHowItWorks from "@/components/space/SpaceHowItWorks";
import SpaceFeatureSection from "@/components/space/SpaceFeatureSection";

const ACCENT = "#B89A52";

/**
 * Agriculteurs — Espace AIME® dédié à celles et ceux qui nourrissent le monde.
 * Mêmes blocs narratifs que /mariage : hero + how-it-works + sections feature.
 * Aucune grille de dossiers ni drawer — la page reste cohérente avec le reste du site.
 */
export default function Agriculteurs() {
  return (
    <div className="bg-[#0A0A0B] font-sans min-h-screen">
      {/* 1. HERO */}
      <SpaceHero
        eyebrow="AIME® · Espace Agriculteurs"
        title="La terre,"
        italic="mérite mieux que la paperasse."
        description="PAC, MSA, aléas climatiques, transmission, équilibre humain — Aïma écoute, traduit, protège, et alerte en amont. Pour ceux qui nourrissent le monde."
        accent={ACCENT}
        bgUrl="https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=2400&q=80"
      />

      {/* 2. COMMENT ÇA MARCHE — la voix d'Aïma au service de l'agriculteur */}
      <SpaceHowItWorks
        title="Une présence,"
        italic="qui veille avec vous."
        description="Aïma circule entre vos déclarations, vos cotisations, vos aléas, vos droits — et alerte avant que la machine administrative ne se referme. Vous gardez la main, elle absorbe la paperasse."
        accent={ACCENT}
        actors={[
          {
            name: "Déclarations",
            glyph: "◇",
            desc: "PAC, DPB, MAEC, télédéclaration. Aïma prépare, vérifie, rappelle les délais DDT — vous validez, elle dépose.",
            folders: ["PAC", "DPB", "MAEC", "Délais DDT"]
          },
          {
            name: "Cotisations & droits",
            glyph: "✦",
            desc: "MSA, retraite, accidents du travail, congés, contrôles DDT. Aïma comprend la situation et défend vos droits non activés.",
            folders: ["MSA", "Retraite", "AT", "Droits"]
          },
          {
            name: "Aléas & économie",
            glyph: "⚠",
            desc: "Gel, grêle, sécheresse, inondation. Alertes 6h avant l'événement, déclaration de sinistre pré-rédigée, marges et rentabilité.",
            folders: ["Aléas", "Sinistres", "Marges", "Vente directe"]
          },
          {
            name: "Équilibre humain",
            glyph: "♡",
            desc: "Transmission, fiscalité, transition bio, et un dossier confidentiel pour parler de ce qui pèse — Agri'Écoute en un clic.",
            folders: ["Transmission", "Transition", "Mon équilibre"]
          }
        ]}
      />

      {/* 3. ALERTES PRÉVENTIVES */}
      <SpaceFeatureSection
        eyebrow="01 · Alertes communautaires"
        title="6 heures d'avance,"
        italic="sur la machine."
        description="Aïma scrute les bulletins météo, les calendriers DDT, les fenêtres MSA. Elle alerte uniquement les agriculteurs concernés, et propose déjà la déclaration prête à signer."
        accent={ACCENT}
        bullets={[
          "Alertes météo géolocalisées : gel, grêle, sécheresse — 6h avant",
          "Déclaration de sinistre pré-rédigée, vérifiée à votre couverture",
          "Rappels personnalisés : délais PAC, contrôles DDT, fenêtres MSA"
        ]}
        visual={
          <div
            className="relative aspect-square rounded-3xl overflow-hidden"
            style={{
              background:
                "radial-gradient(ellipse at 30% 30%, rgba(184,154,82,0.4) 0%, transparent 60%), radial-gradient(ellipse at 80% 70%, rgba(92,52,37,0.5) 0%, transparent 60%), #0F1410"
            }}
          >
            <div className="absolute inset-0 flex items-center justify-center px-10">
              <div className="text-center space-y-3">
                <div className="text-[10px] tracking-[0.35em] uppercase text-white/55">
                  Alerte AIME®
                </div>
                <div className="font-serif italic text-white/90 text-[17px] md:text-[19px] leading-snug">
                  « Épisode de gel prévu cette nuit sur le 63. Veux-tu que je prépare ta déclaration de sinistre&nbsp;? »
                </div>
                <div className="text-white/45 text-[11.5px] font-sans">
                  — 6h avant l'événement
                </div>
              </div>
            </div>
          </div>
        }
      />

      {/* 4. AGRI'ÉCOUTE — équilibre humain */}
      <SpaceFeatureSection
        eyebrow="02 · Tu n'es pas seul·e"
        title="Tu nourris les autres."
        italic="Qui prend soin de toi ?"
        description="Le dossier Mon équilibre est confidentiel — aucune donnée enregistrée. En un clic, Aïma te connecte à Agri'Écoute (09 69 39 29 19), 7j/7, gratuit, anonyme."
        accent="#5C3425"
        reverse
        bullets={[
          "Dossier Mon équilibre · confidentiel, sans trace",
          "Lien direct Agri'Écoute · 09 69 39 29 19 · 7j/7",
          "Veille communautaire : tu n'es jamais seul face à un coup dur"
        ]}
        visual={
          <div
            className="relative aspect-square rounded-3xl overflow-hidden"
            style={{
              background:
                "radial-gradient(ellipse at 40% 30%, rgba(212,180,131,0.45) 0%, transparent 55%), radial-gradient(ellipse at 80% 80%, rgba(92,52,37,0.5) 0%, transparent 55%), #0F0E0A"
            }}
          >
            <div className="absolute inset-0 flex items-center justify-center px-10">
              <div className="text-center space-y-3">
                <div className="text-[10px] tracking-[0.35em] uppercase text-white/55">
                  Agri'Écoute
                </div>
                <div className="font-serif text-white/90 text-[26px] md:text-[30px]">
                  09 69 39 29 19
                </div>
                <div className="text-white/55 text-[11.5px] font-sans">
                  7j/7 · gratuit · anonyme
                </div>
              </div>
            </div>
          </div>
        }
      />
    </div>
  );
}