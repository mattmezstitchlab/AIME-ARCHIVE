import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Sparkles, RefreshCw, ShieldCheck, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import MachineFrame from "@/components/stampmachine/MachineFrame";
import StampMachineForm from "@/components/stampmachine/StampMachineForm";
import RoundStamp from "@/components/stampmachine/RoundStamp";
import { CONTRATS_INCARNES } from "@/lib/contratsIncarnes";

/**
 * StampMachine — La page atelier.
 * Une vraie machine noire avec LEDs arc-en-ciel.
 * On saisit une intention + on choisit un acte → la machine "imprime"
 * un timbre rond doré qui sort de la fente avec un code AIME-XXX-XXXX unique.
 *
 * 100% indépendante d'Aïma. Utilise sealStamp tel quel pour le code unique,
 * le hash et l'horodatage côté serveur.
 */

export default function StampMachine() {
  const [intention, setIntention] = useState("");
  const [contratId, setContratId] = useState("");
  const [city, setCity] = useState("Paris");
  const [status, setStatus] = useState("idle"); // idle | working | ready
  const [stamp, setStamp] = useState(null);
  const [error, setError] = useState(null);

  const canSubmit = intention.trim().length >= 4 && !!contratId && status !== "working";

  const handleGenerate = async () => {
    if (!canSubmit) return;
    setError(null);
    setStamp(null);
    setStatus("working");

    const contrat = CONTRATS_INCARNES.find((c) => c.id === contratId);
    const text = contrat ? contrat.title : "Acte AIME®";

    try {
      // sealStamp exige image_url — on lui fournit un placeholder simple
      // (le rendu visuel se fait avec RoundStamp côté client)
      const res = await base44.functions.invoke("sealStamp", {
        text,
        image_url: "round-stamp:client-svg", // placeholder, le visuel est SVG
        intention_text: intention.trim(),
        category: "contrat_incarne",
        subcategory: contratId,
        issued_city: city || "Paris"
      });

      const data = res?.data;
      if (!data?.ok || !data?.stamp) {
        throw new Error(data?.error || "Émission échouée");
      }
      setStamp(data.stamp);
      setStatus("ready");
    } catch (e) {
      setError(e.message || "Erreur lors de l'émission");
      setStatus("idle");
    }
  };

  const handleReset = () => {
    setIntention("");
    setContratId("");
    setCity("Paris");
    setStamp(null);
    setStatus("idle");
    setError(null);
  };

  return (
    <main
      className="min-h-screen relative overflow-hidden"
      style={{ background: "radial-gradient(ellipse at top, #0c0a0e 0%, #000 70%)" }}
    >
      {/* Halo arrière atmosphérique */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            "radial-gradient(ellipse at 50% 30%, rgba(212,175,55,0.08) 0%, transparent 60%)"
        }}
      />

      <section className="relative z-10 px-5 pt-20 md:pt-28 pb-10 max-w-3xl mx-auto text-center">
        <motion.div
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="text-amber-400/80 text-[10px] tracking-[0.4em] uppercase font-sans mb-4">
            Atelier · StampMachine
          </div>
          <h1
            className="font-display uppercase text-white leading-[0.95]"
            style={{ fontSize: "clamp(2rem, 5vw, 3.6rem)", letterSpacing: "-0.03em" }}
          >
            Une intention.<br />Un code. Un sceau.
          </h1>
          <p className="mt-5 text-white/55 font-serif italic max-w-xl mx-auto" style={{ fontSize: "clamp(1rem, 1.8vw, 1.2rem)" }}>
            Tu dictes. La machine écoute. Le timbre sort — frappé, horodaté, signé.
          </p>
        </motion.div>
      </section>

      <section className="relative z-10 px-5 pb-20 md:pb-28 flex justify-center">
        <div style={{ width: "min(100%, 720px)" }}>
          <MachineFrame
            status={status}
            slotChild={
              <AnimatePresence>
                {stamp && (
                  <motion.div
                    initial={{ y: -180, opacity: 0, scale: 0.85 }}
                    animate={{ y: 0, opacity: 1, scale: 1 }}
                    exit={{ y: -40, opacity: 0 }}
                    transition={{
                      duration: 1.8,
                      ease: [0.22, 1, 0.36, 1],
                      delay: 0.3
                    }}
                    className="relative"
                  >
                    <RoundStamp
                      code={stamp.code}
                      topText={(CONTRATS_INCARNES.find((c) => c.id === contratId)?.title || "ACTE AIME®").toUpperCase()}
                      bottomText={`${(stamp.issued_city || "PARIS").toUpperCase()} · ${new Date(stamp.issued_at).toLocaleDateString("fr-FR", { month: "long", year: "numeric" }).toUpperCase()}`}
                      size={300}
                    />
                  </motion.div>
                )}
              </AnimatePresence>
            }
          >
            {/* Contenu de l'écran */}
            {!stamp ? (
              <>
                <StampMachineForm
                  intention={intention}
                  setIntention={setIntention}
                  contratId={contratId}
                  setContratId={setContratId}
                  city={city}
                  setCity={setCity}
                  disabled={status === "working"}
                />

                {error && (
                  <div className="mt-4 text-rose-400 text-[12px] font-sans">{error}</div>
                )}

                <button
                  onClick={handleGenerate}
                  disabled={!canSubmit}
                  className="mt-6 w-full py-3.5 rounded-lg flex items-center justify-center gap-2 text-[12px] tracking-[0.25em] uppercase font-sans transition-all disabled:opacity-40 disabled:cursor-not-allowed"
                  style={{
                    background:
                      "linear-gradient(180deg, #D4AF37 0%, #8B6914 100%)",
                    color: "#1a1208",
                    boxShadow:
                      "0 0 20px rgba(212,175,55,0.35), inset 0 1px 0 rgba(255,255,255,0.3)"
                  }}
                >
                  {status === "working" ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" /> Frappe en cours…
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" /> Frapper le timbre
                    </>
                  )}
                </button>

                <div className="mt-5 pt-5 border-t border-amber-500/10 grid grid-cols-3 gap-2 text-center">
                  <div>
                    <div className="text-[9px] tracking-[0.2em] uppercase text-white/35 font-sans mb-1">Code</div>
                    <div className="text-amber-300/80 text-[11px] font-mono">AIME-XXX-XXXX</div>
                  </div>
                  <div>
                    <div className="text-[9px] tracking-[0.2em] uppercase text-white/35 font-sans mb-1">Hash</div>
                    <div className="text-amber-300/80 text-[11px] font-mono">SHA-256</div>
                  </div>
                  <div>
                    <div className="text-[9px] tracking-[0.2em] uppercase text-white/35 font-sans mb-1">Filiation</div>
                    <div className="text-amber-300/80 text-[11px] font-mono">Soleau-2024</div>
                  </div>
                </div>
              </>
            ) : (
              <div className="text-center space-y-4 py-8">
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.6 }}
                >
                  <div className="text-amber-300/80 text-[10px] tracking-[0.35em] uppercase font-sans mb-3">
                    Timbre frappé
                  </div>
                  <div className="text-white font-display uppercase text-[20px] tracking-tight">
                    AIME® · #{String(stamp.registry_n || 0).padStart(6, "0")}
                  </div>
                  <div className="text-amber-300 text-[14px] font-mono mt-2">{stamp.code}</div>

                  <div className="mt-6 text-white/55 text-[11px] font-mono break-all px-2">
                    {stamp.hash?.slice(0, 32)}…
                  </div>
                  <div className="mt-1 text-white/40 text-[10px] tracking-[0.2em] uppercase font-sans">
                    SHA-256 · {new Date(stamp.issued_at).toLocaleString("fr-FR")}
                  </div>

                  <div className="mt-7 flex items-center justify-center gap-3">
                    <a
                      href={stamp.verify_url}
                      className="inline-flex items-center gap-1.5 px-4 py-2 border border-amber-400/40 text-amber-300 text-[10px] tracking-[0.25em] uppercase rounded-full hover:bg-amber-400/10 transition-colors"
                    >
                      <ShieldCheck className="w-3.5 h-3.5" /> Vérifier
                    </a>
                    <button
                      onClick={handleReset}
                      className="inline-flex items-center gap-1.5 px-4 py-2 border border-white/15 text-white/70 text-[10px] tracking-[0.25em] uppercase rounded-full hover:bg-white/5 transition-colors"
                    >
                      <RefreshCw className="w-3.5 h-3.5" /> Nouveau timbre
                    </button>
                  </div>
                </motion.div>
              </div>
            )}
          </MachineFrame>
        </div>
      </section>

      {/* Footer manifesto */}
      <section className="relative z-10 px-6 pb-20 max-w-2xl mx-auto text-center">
        <p className="text-white/40 font-serif italic text-[14px] leading-relaxed">
          « Une signature qui n'est pas une croix au stylo,<br />mais une vibration émise par une intention humaine. »
        </p>
        <p className="mt-3 text-white/25 text-[10px] tracking-[0.3em] uppercase">
          Soleau-2024 · INPI · Signature Vibratoire par Intention™
        </p>
      </section>
    </main>
  );
}