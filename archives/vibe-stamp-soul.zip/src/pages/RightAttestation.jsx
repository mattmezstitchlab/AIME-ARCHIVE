import React from "react";
import { useParams, Navigate } from "react-router-dom";
import { getRightConfig } from "@/lib/rights/configs";
import { getRightBySlug } from "@/lib/rights/registry";
import RightAttestationFlow from "@/components/rights/RightAttestationFlow";

/**
 * RightAttestation — page dynamique /music-rights/:slug
 * Charge la config du droit demandé et lance le flow générique.
 * Le greeting Naïma vient du registre central.
 */
export default function RightAttestation() {
  const { slug } = useParams();
  const config = getRightConfig(slug);
  const meta = getRightBySlug(slug);

  if (!config || !meta || meta.status === "soon") {
    return <Navigate to="/music-rights" replace />;
  }

  // Injection du greeting Naïma depuis le registre central
  const enrichedConfig = {
    ...config,
    naimaGreeting: meta.naimaGreeting,
    rightLabel: meta.label
  };

  return <RightAttestationFlow config={enrichedConfig} />;
}