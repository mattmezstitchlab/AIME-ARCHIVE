import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import SpaceHero from "@/components/space/SpaceHero";
import SpaceHowItWorks from "@/components/space/SpaceHowItWorks";
import SpaceFeatureSection from "@/components/space/SpaceFeatureSection";
import NoyauIcon from "@/components/noyau/NoyauIcon";

const ACCENT = "#F5D49B";

export default function Inclusive() {
  return (
    <div className="bg-[#0A0A0B] font-sans min-h-screen">
      <SpaceHero
        eyebrow="AIME® · Espace Inclusive"
        title="La dignité,"
        italic="ne demande pas la permission."
        description="Précarité, neurodivergence, handicap, isolement, parcours de soin. Aïma écoute sans juger, accompagne sans étiqueter, protège la confidentialité."
        accent={ACCENT}
        bgUrl="https://images.unsplash.com/photo-1517022812141-23620dba5c23?w=2400&q=80"
      />

      <SpaceHowItWorks
        title="Une présence,"
        italic="qui ne te lâche pas."
        description="Aïma comprend la situation, traduit les démarches administratives, repère les droits non activés, et te connecte aux bonnes ressources humaines."
        accent={ACCENT}
        actors={[
          {
            name: "Droits non activés",
            glyph: "◇",
            desc: "RSA, AAH, CMU-C, prime d'activité, aides logement. Aïma calcule, explique, prépare le dossier.",
            folders: ["RSA", "AAH", "CMU-C", "APL"]
          },
          {
            name: "Confidentiel",
            glyph: "✦",
            desc: "Dossier sans trace, données chiffrées, droit à l'oubli intégral. Tu pars, rien ne reste.",
            folders: ["Mes données", "Effacement"]
          },
          {
            name: "Ressources humaines",
            glyph: "♡",
            desc: "Lien vers les associations, écoutes, urgences sociales. Aïma sait à qui te confier.",
            folders: ["Écoutes", "Associations", "Urgences"]
          },
          {
            name: "Accompagnement",
            glyph: "◈",
            desc: "Rendez-vous CAF, MDPH, France Travail. Préparation, simulations, lettres types.",
            folders: ["CAF", "MDPH", "France Travail"]
          }
        ]}
      />

      {/* Lien dédié vers NOYAU — accent or sur fond très sombre */}
      <section className="px-6 py-16 md:py-20 border-t border-white/5">
        <div className="max-w-4xl mx-auto">
          <Link to="/noyau" className="block group">
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.6 }}
              className="rounded-3xl border border-[#B89A52]/30 hover:border-[#B89A52]/70 transition-colors p-8 md:p-10 flex flex-col md:flex-row items-center md:items-start gap-7 md:gap-9"
              style={{ backgroundColor: "#0A0806" }}
            >
              <div className="flex-shrink-0">
                <NoyauIcon size={64} color="#B89A52" />
              </div>
              <div className="flex-1 text-center md:text-left">
                <div className="text-[10px] tracking-[0.35em] uppercase text-[#B89A52] mb-3">
                  AIME® Noyau · Inclusive
                </div>
                <h3 className="apple-headline text-white text-3xl md:text-4xl mb-3">
                  CAPTURER CE QUE TU ES.
                  <br />
                  <span className="text-white/60">Pour toujours.</span>
                </h3>
                <p
                  className="text-white/65 text-[14px] md:text-[15px] italic leading-relaxed mb-5"
                  style={{ fontFamily: "'Playfair Display', serif" }}
                >
                  « Pour les proches atteints de SLA — et tous ceux qui veulent transmettre. »
                </p>
                <div className="inline-flex items-center gap-2 text-[10px] tracking-[0.3em] uppercase text-[#B89A52] group-hover:text-[#D4B66E] transition-colors">
                  Découvrir Noyau <span>→</span>
                </div>
              </div>
            </motion.div>
          </Link>
        </div>
      </section>

      <SpaceFeatureSection
        eyebrow="01 · Confidentialité absolue"
        title="Tu pars,"
        italic="rien ne reste."
        description="Le dossier Inclusive est chiffré, sans trace par défaut. Tu choisis ce que tu veux garder, ce que tu veux effacer, et quand."
        accent={ACCENT}
        bullets={[
          "Données chiffrées de bout en bout",
          "Droit à l'oubli intégral en un clic",
          "Aucune transmission sans ton accord explicite"
        ]}
        visual={
          <div
            className="relative aspect-square rounded-3xl overflow-hidden flex items-center justify-center"
            style={{
              background:
                "radial-gradient(ellipse at 40% 40%, rgba(245,212,155,0.35) 0%, transparent 60%), #0E0D10"
            }}
          >
            <div className="text-center px-8">
              <div className="font-serif text-white/90 text-[20px] italic leading-snug">
                « Tu n'as pas à mériter ta dignité.
                <br />Elle est déjà là. »
              </div>
              <div className="mt-4 text-[10px] tracking-[0.3em] uppercase text-white/45">
                AIME® Inclusive
              </div>
            </div>
          </div>
        }
      />
    </div>
  );
}