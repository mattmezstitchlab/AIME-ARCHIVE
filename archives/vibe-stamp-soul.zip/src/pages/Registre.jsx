import React, { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import TimbreCard from "@/components/timbre/TimbreCard";
import MyTimbreBanner from "@/components/registre/MyTimbreBanner";
import { AIME_SECTORS } from "@/lib/aimeBrand";

/**
 * Registre — La planche des Timbres AIME®.
 * Refonte fidèle à la maquette : fond crème #F5F0E8, header centré Playfair,
 * tabs noir/crème, filtres pill, grille 5 colonnes, vraie dentelure de timbre.
 */
export default function Registre() {
  const navigate = useNavigate();
  const [timbres, setTimbres] = useState([]);
  const [loading, setLoading] = useState(true);
  const [mode, setMode] = useState("planche");
  const [filterSector, setFilterSector] = useState("all");
  const [filterCity, setFilterCity] = useState("");
  const [search, setSearch] = useState("");

  useEffect(() => {
    base44.entities.Timbre.list("-issued_at", 100)
      .then((list) => setTimbres(list || []))
      .finally(() => setLoading(false));
  }, []);

  const totalCount = timbres.length;
  const publicCount = timbres.filter((t) => t.consent_public_registry).length;

  const filtered = useMemo(() => {
    return timbres.filter((t) => {
      if (filterSector !== "all" && t.sector !== filterSector) return false;
      if (filterCity && !(t.issued_city || "").toLowerCase().includes(filterCity.toLowerCase())) return false;
      if (search) {
        const hay = `${t.code || ""} ${t.craft || ""} ${(t.music_dna || []).join(" ")}`.toLowerCase();
        if (!hay.includes(search.toLowerCase())) return false;
      }
      return true;
    });
  }, [timbres, filterSector, filterCity, search]);

  return (
    <div
      className="min-h-screen"
      style={{
        background: "#FFFFFF",
        fontFamily: "'DM Sans', sans-serif",
        color: "#1a1208"
      }}
    >
      <div className="max-w-6xl mx-auto px-6 py-12 md:py-16">
        {/* Mon Timbre — bandeau d'entrée du registre */}
        <MyTimbreBanner />

        {/* Header */}
        <div className="text-center mb-10">
          <div
            style={{
              fontSize: 10,
              letterSpacing: "0.28em",
              color: "#B89A52",
              textTransform: "uppercase",
              marginBottom: 10,
              fontWeight: 500
            }}
          >
            Registre universel
          </div>
          <h1
            className="apple-headline"
            style={{
              fontSize: "clamp(36px, 5vw, 52px)",
              color: "#1a1208"
            }}
          >
            La planche des
            <br />
            <span style={{ color: "#B89A52" }}>Timbres AIME®.</span>
          </h1>
          <p
            style={{
              fontSize: 12,
              color: "#9A8B70",
              marginTop: 14,
              letterSpacing: "0.06em"
            }}
          >
            <strong style={{ color: "#B89A52" }}>
              #{String(totalCount).padStart(6, "0")}
            </strong>{" "}
            Timbres émis · {publicCount} publics
          </p>
        </div>

        {/* Tabs */}
        <div className="flex justify-center gap-1 mb-6">
          {[
            { id: "planche", label: "Planche" },
            { id: "map", label: "Carte" },
            { id: "resonance", label: "Résonance" }
          ].map((m) => {
            const active = mode === m.id;
            return (
              <button
                key={m.id}
                onClick={() => setMode(m.id)}
                style={{
                  padding: "8px 22px",
                  borderRadius: 99,
                  fontSize: 12,
                  letterSpacing: "0.08em",
                  textTransform: "uppercase",
                  fontWeight: 500,
                  cursor: "pointer",
                  border: active ? "1px solid #1a1208" : "1px solid rgba(184,154,82,0.3)",
                  color: active ? "#F5F0E8" : "#9A8B70",
                  background: active ? "#1a1208" : "transparent",
                  transition: "all 0.2s"
                }}
              >
                {m.label}
              </button>
            );
          })}
        </div>

        {/* Filtres */}
        {mode === "planche" && (
          <div className="flex flex-wrap justify-center items-center gap-2 mb-8">
            <input
              placeholder="Code, métier, artiste…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              style={{
                border: "1px solid rgba(184,154,82,0.25)",
                background: "rgba(255,255,255,0.6)",
                borderRadius: 99,
                padding: "7px 16px",
                fontSize: 12,
                color: "#3a2e1a",
                outline: "none",
                width: 200
              }}
            />
            <input
              placeholder="Ville"
              value={filterCity}
              onChange={(e) => setFilterCity(e.target.value)}
              style={{
                border: "1px solid rgba(184,154,82,0.25)",
                background: "rgba(255,255,255,0.6)",
                borderRadius: 99,
                padding: "7px 16px",
                fontSize: 12,
                color: "#3a2e1a",
                outline: "none",
                width: 140
              }}
            />
            <select
              value={filterSector}
              onChange={(e) => setFilterSector(e.target.value)}
              style={{
                border: "1px solid rgba(184,154,82,0.25)",
                background: "rgba(255,255,255,0.6)",
                borderRadius: 99,
                padding: "7px 16px",
                fontSize: 12,
                color: "#3a2e1a",
                outline: "none"
              }}
            >
              <option value="all">Tous secteurs</option>
              {AIME_SECTORS.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.label}
                </option>
              ))}
            </select>
          </div>
        )}

        {/* Content */}
        {loading ? (
          <div className="text-center py-20" style={{ color: "#9A8B70", fontSize: 13 }}>
            Lecture du registre…
          </div>
        ) : mode === "planche" ? (
          filtered.length === 0 ? (
            <EmptyState onCreate={() => navigate("/timbre/nouveau")} />
          ) : (
            <div
              className="grid gap-4"
              style={{
                gridTemplateColumns: "repeat(auto-fill, minmax(180px, 1fr))",
                justifyItems: "center"
              }}
            >
              {filtered.map((t) => (
                <TimbreCard
                  key={t.id}
                  timbre={t}
                  size="sm"
                  anonymous={!t.consent_public_registry}
                />
              ))}
              <PlaceholderSlot onClick={() => navigate("/timbre/nouveau")} />
            </div>
          )
        ) : (
          <ComingSoon mode={mode} />
        )}

        {/* CTAs */}
        <div className="flex justify-center gap-3 mt-14">
          <button
            onClick={() => navigate("/timbre/nouveau")}
            style={{
              padding: "12px 28px",
              borderRadius: 99,
              background: "#B89A52",
              color: "#1a1208",
              fontSize: 11,
              letterSpacing: "0.2em",
              textTransform: "uppercase",
              fontWeight: 500,
              border: "none",
              cursor: "pointer"
            }}
            onMouseEnter={(e) => (e.currentTarget.style.background = "#D4B483")}
            onMouseLeave={(e) => (e.currentTarget.style.background = "#B89A52")}
          >
            Créer mon Timbre
          </button>
          <button
            onClick={() => navigate("/")}
            style={{
              padding: "12px 28px",
              borderRadius: 99,
              background: "transparent",
              color: "#4A3C28",
              fontSize: 11,
              letterSpacing: "0.2em",
              textTransform: "uppercase",
              fontWeight: 500,
              border: "1px solid rgba(184,154,82,0.4)",
              cursor: "pointer"
            }}
          >
            Retour à Aïma
          </button>
        </div>

        <div
          className="text-center mt-10"
          style={{
            fontSize: 9,
            letterSpacing: "0.25em",
            color: "rgba(154,139,112,0.6)",
            textTransform: "uppercase"
          }}
        >
          AIME® · Stockage UE · Conforme RGPD · Marques INPI 5164817 / 5226732
        </div>
      </div>
    </div>
  );
}

/* ─── Slot vide "Votre timbre" ─── */
function PlaceholderSlot({ onClick }) {
  return (
    <button
      onClick={onClick}
      style={{
        width: 180,
        height: 280,
        opacity: 0.4,
        background: "transparent",
        border: "none",
        padding: 0,
        cursor: "pointer"
      }}
    >
      <div
        style={{
          width: "100%",
          height: "100%",
          background: "rgba(245,240,232,0.5)",
          border: "1px dashed rgba(184,154,82,0.3)",
          padding: 14,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          gap: 8
        }}
      >
        <div
          style={{
            width: 40,
            height: 40,
            borderRadius: "50%",
            border: "1px dashed rgba(184,154,82,0.5)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: 22,
            color: "rgba(184,154,82,0.6)"
          }}
        >
          +
        </div>
        <div
          style={{
            fontSize: 9,
            letterSpacing: "0.2em",
            color: "rgba(184,154,82,0.6)",
            textTransform: "uppercase"
          }}
        >
          Votre timbre
        </div>
      </div>
    </button>
  );
}

/* ─── Empty / Coming soon ─── */
function EmptyState({ onCreate }) {
  return (
    <div className="text-center py-16">
      <p
        style={{
          fontSize: 14,
          color: "#9A8B70",
          marginBottom: 16,
          fontFamily: "'DM Sans', sans-serif"
        }}
      >
        Aucun Timbre ne correspond à votre recherche.
      </p>
      <button
        onClick={onCreate}
        style={{
          padding: "12px 28px",
          borderRadius: 99,
          background: "#1a1208",
          color: "#F5F0E8",
          fontSize: 10,
          letterSpacing: "0.25em",
          textTransform: "uppercase",
          fontWeight: 500,
          border: "none",
          cursor: "pointer"
        }}
      >
        Émettre le premier
      </button>
    </div>
  );
}

function ComingSoon({ mode }) {
  return (
    <div
      className="text-center py-20"
      style={{
        border: "1px dashed rgba(184,154,82,0.4)",
        borderRadius: 16,
        background: "rgba(255,255,255,0.3)"
      }}
    >
      <p
        style={{
          fontFamily: "'DM Sans', sans-serif",
          fontSize: 14,
          color: "#9A8B70",
          lineHeight: 1.6
        }}
      >
        Mode {mode === "map" ? "Carte" : "Résonance"} · à venir
        <br />
        {mode === "map"
          ? "Une cartographie nocturne dorée des Timbres affranchis."
          : "Aïma calculera vos affinités musicales et humaines avec chaque Timbre du registre."}
      </p>
    </div>
  );
}