import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { base44 } from "@/api/base44Client";
import TimbreOnboardingShell from "@/components/timbre/TimbreOnboardingShell";
import {
  StepIdentity, StepBirth, StepPortrait, StepCraft, StepMusicDNA, StepIntention
} from "@/components/timbre/TimbreOnboardingSteps";
import TimbreCharter from "@/components/timbre/TimbreCharter";
import TimbreCard from "@/components/timbre/TimbreCard";
import { getAnonymousId } from "@/lib/aimaSession";

const TOTAL = 6;

export default function TimbreNouveau() {
  const navigate = useNavigate();
  const [step, setStep] = useState(1); // 1..6 onboarding, 7 charter, 8 mint, 9 confirmation
  const [data, setData] = useState({
    music_dna: ["", "", ""],
    passions: []
  });
  const [consents, setConsents] = useState({
    consent_data_processing: false,
    consent_public_registry: false,
    consent_matching: true,
    consent_communications: false
  });
  const [uploading, setUploading] = useState(false);
  const [minting, setMinting] = useState(false);
  const [error, setError] = useState(null);
  const [issuedTimbre, setIssuedTimbre] = useState(null);

  const set = (patch) => setData((d) => ({ ...d, ...patch }));

  const validate = () => {
    if (step === 1) return data.first_name?.trim() && data.last_name?.trim();
    if (step === 2) return data.birth_date && data.birth_city?.trim();
    if (step === 3) return !!data.portrait_url;
    if (step === 4) return data.craft?.trim();
    if (step === 5) return (data.music_dna || []).some((m) => m?.trim());
    if (step === 6) return data.intention?.trim();
    return true;
  };

  const next = () => {
    setError(null);
    if (!validate()) {
      setError("Merci de compléter cette étape pour continuer.");
      return;
    }
    setStep((s) => s + 1);
  };
  const prev = () => setStep((s) => Math.max(1, s - 1));

  const handleUpload = async (file) => {
    setUploading(true);
    setError(null);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      set({ portrait_url: file_url });
    } catch (e) {
      setError("L'envoi du portrait a échoué. Réessayez.");
    } finally {
      setUploading(false);
    }
  };

  const mintTimbre = async () => {
    setMinting(true);
    setError(null);
    try {
      const payload = {
        first_name: data.first_name,
        last_name: data.last_name,
        birth_date: data.birth_date,
        birth_city: data.birth_city,
        issued_city: data.birth_city,
        portrait_url: data.portrait_url,
        craft: data.craft,
        sector: data.sector,
        music_dna: (data.music_dna || []).filter((x) => x?.trim()),
        passions: data.passions || [],
        intention: data.intention,
        anonymous_id: getAnonymousId(),
        ...consents
      };
      const res = await base44.functions.invoke("mintTimbre", payload);
      const timbre = res?.data?.timbre;
      if (!timbre) throw new Error("Émission échouée");
      setIssuedTimbre(timbre);
      setStep(9);
    } catch (e) {
      setError("L'émission du Timbre a échoué : " + (e.message || ""));
    } finally {
      setMinting(false);
    }
  };

  const renderStep = () => {
    if (step === 1) return <StepIdentity data={data} set={set} />;
    if (step === 2) return <StepBirth data={data} set={set} />;
    if (step === 3) return <StepPortrait data={data} set={set} onUpload={handleUpload} uploading={uploading} />;
    if (step === 4) return <StepCraft data={data} set={set} />;
    if (step === 5) return <StepMusicDNA data={data} set={set} />;
    if (step === 6) return <StepIntention data={data} set={set} />;
    if (step === 7) return <TimbreCharter consents={consents} setConsents={setConsents} />;
    return null;
  };

  // Confirmation screen
  if (step === 9 && issuedTimbre) {
    return (
      <TimbreOnboardingShell>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center"
        >
          <div className="text-[11px] tracking-[5px] text-[#B8963E] uppercase mb-4">
            Timbre émis
          </div>
          <h1 className="apple-headline text-[#1A1208] text-3xl md:text-4xl mb-6">
            Bienvenue dans<br />
            le <span className="text-[#B8963E]">registre</span>.
          </h1>
          <div className="flex justify-center my-8">
            <TimbreCard timbre={issuedTimbre} size="lg" />
          </div>
          <p className="text-[12px] text-[#8A7A60] tracking-wide max-w-sm mx-auto leading-relaxed mb-8">
            Votre Timbre est désormais inscrit au registre AIME®<br />
            sous le n° <strong className="text-[#B8963E]">#{String(issuedTimbre.registry_n).padStart(6, "0")}</strong>.
            <br /><br />
            Conservez précieusement votre code :<br />
            <span className="font-mono tracking-[0.3em] text-[#B8963E] text-[14px] mt-2 inline-block">
              {issuedTimbre.code}
            </span>
          </p>
          <div className="flex justify-center gap-3">
            <button
              onClick={() => navigate("/timbre")}
              className="px-8 py-3.5 rounded-full bg-[#1A1208] text-[#F0E6C8] text-[10px] tracking-[3px] uppercase hover:bg-[#B8963E] hover:text-[#1A1208] transition-colors"
            >
              Voir mon Timbre
            </button>
            <button
              onClick={() => navigate("/registre")}
              className="px-8 py-3.5 rounded-full border border-[#D4B483] text-[#4A3C28] text-[10px] tracking-[3px] uppercase hover:bg-[#D4B483]/10 transition-colors"
            >
              Le Registre
            </button>
          </div>
        </motion.div>
      </TimbreOnboardingShell>
    );
  }

  // Onboarding card
  const isCharter = step === 7;
  const showStep = step <= 7;
  const canMint = isCharter && consents.consent_data_processing;

  return (
    <TimbreOnboardingShell>
      <div className="p-2 md:p-4">
        {showStep && (
          <>
            {/* Progress */}
            <div className="flex items-center gap-3 mb-10">
              <div className="flex-1 h-[2px] bg-[#D4B483]/20 rounded overflow-hidden">
                <motion.div
                  className="h-full"
                  style={{ background: "linear-gradient(90deg, #D4B483, #B8963E)" }}
                  initial={{ width: 0 }}
                  animate={{ width: `${((step - 1) / TOTAL) * 100}%` }}
                  transition={{ duration: 0.5 }}
                />
              </div>
              <div className="text-[9px] tracking-[3px] text-[#8A7A60] uppercase whitespace-nowrap">
                {isCharter ? "Charte" : `${step} / ${TOTAL}`}
              </div>
            </div>

            <AnimatePresence mode="wait">
              <motion.div
                key={step}
                initial={{ opacity: 0, x: 16 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -16 }}
                transition={{ duration: 0.3 }}
              >
                {renderStep()}
              </motion.div>
            </AnimatePresence>

            {error && (
              <p className="text-[11px] text-[#c0392b] mt-3">{error}</p>
            )}

            <div className="flex items-center justify-between mt-9">
              <button
                onClick={prev}
                className={`text-[10px] tracking-[3px] text-[#8A7A60] uppercase hover:text-[#1A1208] transition-colors ${
                  step <= 1 ? "invisible" : ""
                }`}
              >
                ← Retour
              </button>
              {!isCharter ? (
                <button
                  onClick={next}
                  className="px-9 py-3.5 rounded-full bg-[#1A1208] text-[#F0E6C8] text-[9px] tracking-[3px] uppercase hover:bg-[#B8963E] hover:text-[#1A1208] transition-colors"
                >
                  {step === TOTAL ? "Voir la Charte →" : "Continuer →"}
                </button>
              ) : (
                <button
                  disabled={!canMint || minting}
                  onClick={mintTimbre}
                  className={`px-9 py-3.5 rounded-full text-[9px] tracking-[3px] uppercase transition-colors ${
                    canMint && !minting
                      ? "bg-[#1A1208] text-[#F0E6C8] hover:bg-[#B8963E] hover:text-[#1A1208]"
                      : "bg-[#D4B483]/30 text-[#8A7A60] cursor-not-allowed"
                  }`}
                >
                  {minting ? "Émission…" : "Obtenir mon Timbre ✦"}
                </button>
              )}
            </div>
          </>
        )}
      </div>

      {/* Footer mention */}
      <div className="text-center mt-6 text-[8px] tracking-[3px] text-[#8A7A60]/70 uppercase">
        AIME® · Marque déposée INPI · 5164817 / 5226732
      </div>
    </TimbreOnboardingShell>
  );
}