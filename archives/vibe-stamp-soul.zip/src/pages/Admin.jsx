import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { isAdmin } from "@/lib/adminAuth";
import AdminLogin from "@/components/admin/AdminLogin";
import AdminSidebar from "@/components/admin/AdminSidebar";
import DashboardPanel from "@/components/admin/panels/DashboardPanel";
import MediaPanel from "@/components/admin/panels/MediaPanel";
import TextsPanel from "@/components/admin/panels/TextsPanel";
import AimaPanel from "@/components/admin/panels/AimaPanel";
import BrandPanel from "@/components/admin/panels/BrandPanel";
import RegistryPanel from "@/components/admin/panels/RegistryPanel";
import LegalPanel from "@/components/admin/panels/LegalPanel";
import SpacesPanel from "@/components/admin/panels/SpacesPanel";
import PagesPanel from "@/components/admin/panels/PagesPanel";
import ColorsPanel from "@/components/admin/panels/ColorsPanel";
import CtaLinksPanel from "@/components/admin/panels/CtaLinksPanel";
import VisualEditorPanel from "@/components/admin/panels/VisualEditorPanel";
import MiniSitesPanel from "@/components/admin/panels/MiniSitesPanel";

export default function Admin() {
  const [authed, setAuthed] = useState(isAdmin());
  const [tab, setTab] = useState("dashboard");
  const [settings, setSettings] = useState([]);

  const reload = async () => {
    const all = await base44.entities.AdminSettings.list("-updated_date", 200).catch(() => []);
    setSettings(all || []);
  };

  useEffect(() => { if (authed) reload(); }, [authed]);

  if (!authed) return <AdminLogin onSuccess={() => setAuthed(true)} />;

  return (
    <div className="min-h-screen bg-[#0A0A0B] text-white flex" style={{ fontFamily: "'Inter', sans-serif" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;1,300;1,400&display=swap');
      `}</style>
      <AdminSidebar active={tab} onChange={setTab} />
      <main className="flex-1 p-8 md:p-12 overflow-y-auto">
        <div className="max-w-4xl">
          {tab === "dashboard" && <DashboardPanel onNavigate={setTab} />}
          {tab === "pages" && <PagesPanel />}
          {tab === "editor" && <VisualEditorPanel />}
          {tab === "spaces" && <SpacesPanel />}
          {tab === "minisites" && <MiniSitesPanel />}
          {tab === "media" && <MediaPanel settings={settings} onReload={reload} />}
          {tab === "texts" && <TextsPanel settings={settings} onReload={reload} />}
          {tab === "cta" && <CtaLinksPanel settings={settings} onReload={reload} />}
          {tab === "aima" && <AimaPanel settings={settings} onReload={reload} />}
          {tab === "colors" && <ColorsPanel settings={settings} onReload={reload} />}
          {tab === "brand" && <BrandPanel />}
          {tab === "registry" && <RegistryPanel />}
          {tab === "legal" && <LegalPanel settings={settings} onReload={reload} />}
        </div>
      </main>
    </div>
  );
}