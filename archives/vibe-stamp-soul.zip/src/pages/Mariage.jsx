import React from "react";
import SpaceHero from "@/components/space/SpaceHero";
import SpaceHowItWorks from "@/components/space/SpaceHowItWorks";
import SpaceFeatureSection from "@/components/space/SpaceFeatureSection";
import PlaylistMomentsColumns from "@/components/space/PlaylistMomentsColumns";
import MariageMiniSiteSection from "@/components/space/MariageMiniSiteSection";

const ACCENT = "#D4A574";

/**
 * Mariage — Page unique de l'espace Mariage.
 * Englobe les quatre rôles : Couples · Invités · Prestataires · Lieux.
 * Chaque rôle est présenté comme une fenêtre/dossier dans SpaceHowItWorks.
 */
export default function Mariage() {
  return (
    <div className="bg-[#0A0A0B] font-sans min-h-screen">
      {/* 1. HERO */}
      <SpaceHero
        eyebrow="AIME® · l'univers de l'union"
        title="Le cœur battant,"
        italic="de votre union."
        description="Une présence qui vous écoute, relie les acteurs du jour J, compose la mémoire — et laisse résonner l'écho longtemps après."
        accent={ACCENT}
        bgUrl="https://res.cloudinary.com/divou1vcx/image/upload/v1777698965/pexels-rothemba-vele-1414849-18041569_pps4us.jpg"
      />

      {/* 2. COMMENT ÇA MARCHE — les 4 fenêtres mariage */}
      <SpaceHowItWorks
        title="Quatre fenêtres,"
        italic="une seule présence."
        description="Mariés, invités, prestataires, lieux : chacun a sa fenêtre AIME® avec ses dossiers vivants. Aïma circule entre toutes, traduit, protège, relie."
        accent={ACCENT}
        actors={[
          {
            name: "Futurs mariés",
            glyph: "♡",
            desc: "Vous lui parlez. Aïma compose le carnet, choisit les bons prestataires, protège la cohérence — vous restez sur l'émotion.",
            folders: ["Le carnet", "Prestataires", "Invités", "Sceau"]
          },
          {
            name: "Invités",
            glyph: "✉",
            desc: "Un code, et la porte s'ouvre. Tu réponds à Aïma, déposes ta chanson, ton mot, ton souvenir — sans formulaire, sans application.",
            folders: ["RSVP", "Ma chanson", "Livre d'or", "Infos jour J"]
          },
          {
            name: "Prestataires",
            glyph: "♪",
            desc: "DJ, photo, traiteur, intermittents. Aïma parle pour vous, qualifie, négocie, et prend en charge la paperasse française.",
            folders: ["Agenda", "Demandes", "Devis", "Intermittent"]
          },
          {
            name: "Lieux",
            glyph: "▭",
            desc: "Vos murs respirent à votre rythme. Aïma remplit les creux, protège les saisons, briefe les prestataires partenaires.",
            folders: ["Calendrier", "Réservations", "Partenaires", "ERP"]
          }
        ]}
      />

      {/* 3. PLAYLIST — colonnes par moment du jour J */}
      <section className="relative bg-[#0A0A0B] py-24 md:py-32 px-6 border-t border-white/5">
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <div className="font-sans text-[11px] tracking-[0.3em] uppercase mb-4" style={{ color: "#2DBE94" }}>
              01 · Playlist Mondiale
            </div>
            <h2 className="apple-headline text-white text-4xl md:text-5xl">
              Une mémoire sonore,<br />
              <span className="text-white/70">universelle.</span>
            </h2>
            <p className="mt-5 font-sans text-white/65 text-[15px] md:text-[16px] leading-relaxed">
              Toutes les chansons déposées par les invités, alignées par moment du jour J. Faites défiler chaque colonne — c'est la pulsation de toutes les unions.
            </p>
          </div>
          <PlaylistMomentsColumns accent="#2DBE94" />
        </div>
      </section>

      {/* 4. MINI-SITE — page-cadeau privée du couple */}
      <MariageMiniSiteSection />

      {/* 5. L'ÉCHO — mini-site mémoire d'union, vivant et co-écrit */}
      <SpaceFeatureSection
        eyebrow="02 · L'Écho · mémoire d'union"
        title="Le jour d'après,"
        italic="devient un lieu."
        description="Le mini-site de votre union ne s'arrête pas le soir du mariage. Aïma et vos invités continuent d'y déposer mots, photos, fragments — il devient la page mémoire vivante de votre union."
        accent="#A78BFA"
        reverse
        bullets={[
          "Mini-site privé enrichi en continu par Aïma et les invités",
          "Récit du lendemain composé automatiquement · chansons, mots, photos, toasts",
          "Page mémoire d'union conservée longue durée · partage privé"
        ]}
        visual={
          <div
            className="relative aspect-square rounded-3xl overflow-hidden"
            style={{
              background:
                "radial-gradient(ellipse at 40% 30%, rgba(167,139,250,0.5) 0%, transparent 55%), radial-gradient(ellipse at 80% 80%, rgba(255,90,170,0.4) 0%, transparent 55%), #0F0E14"
            }}
          >
            <div className="absolute inset-0 flex items-center justify-center px-10">
              <div className="text-center space-y-3">
                <div className="text-[10px] tracking-[0.35em] uppercase text-white/55">
                  Fragment
                </div>
                <div className="font-serif italic text-white/90 text-[18px] md:text-[20px] leading-snug">
                  « Je vous ai rarement vus aussi rayonnants. »
                </div>
                <div className="text-white/45 text-[11.5px] font-sans">
                  — livre d'or, Antoine
                </div>
              </div>
            </div>
          </div>
        }
      />
    </div>
  );
}