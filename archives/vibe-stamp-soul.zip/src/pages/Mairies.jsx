import React from "react";
import SpaceHero from "@/components/space/SpaceHero";
import SpaceHowItWorks from "@/components/space/SpaceHowItWorks";
import SpaceFeatureSection from "@/components/space/SpaceFeatureSection";

const ACCENT = "#9DA8C9";

export default function Mairies() {
  return (
    <div className="bg-[#0A0A0B] font-sans min-h-screen">
      <SpaceHero
        eyebrow="AIME® · Espace Mairies"
        title="La commune,"
        italic="à l'écoute de ses habitants."
        description="État civil, urbanisme, vie associative, mariages civils. Aïma traduit la complexité administrative pour les agents, et humanise la relation pour les administrés."
        accent={ACCENT}
        bgUrl="https://images.unsplash.com/photo-1590073242678-70ee3fc28e8e?w=2400&q=80"
      />

      <SpaceHowItWorks
        title="Une présence,"
        italic="entre commune et citoyens."
        description="Aïma assiste les agents pour gagner du temps, répond aux administrés en dehors des horaires, et alimente le territoire en données utiles."
        accent={ACCENT}
        actors={[
          {
            name: "État civil",
            glyph: "◇",
            desc: "Naissance, mariage, décès, livret de famille. Préparation des dossiers, vérification des pièces.",
            folders: ["Naissances", "Mariages", "Décès", "Livret"]
          },
          {
            name: "Urbanisme",
            glyph: "✦",
            desc: "Permis de construire, déclarations préalables, PLU. Aïma vulgarise pour les administrés.",
            folders: ["Permis", "Déclarations", "PLU"]
          },
          {
            name: "Vie associative",
            glyph: "♡",
            desc: "Subventions, occupation des salles, événements. Aïma met en lien associations et habitants.",
            folders: ["Subventions", "Salles", "Agenda"]
          },
          {
            name: "Mariages civils",
            glyph: "◈",
            desc: "Préparation du dossier, témoins, livret. Lien direct vers AIME® Wedding pour les couples.",
            folders: ["Dossier", "Témoins", "Cérémonie"]
          }
        ]}
      />

      <SpaceFeatureSection
        eyebrow="01 · Mariages civils"
        title="Le passage,"
        italic="entre l'administration et l'union."
        description="Pour les couples qui se marient à la mairie, Aïma fait le pont entre le dossier administratif et l'expérience humaine du jour J — sans rupture."
        accent={ACCENT}
        bullets={[
          "Dossier mariage civil préparé en conversation",
          "Lien direct avec AIME® Wedding pour le jour J",
          "Témoins, livret, audition : tout est anticipé"
        ]}
        visual={
          <div
            className="relative aspect-square rounded-3xl overflow-hidden flex items-center justify-center"
            style={{
              background:
                "radial-gradient(ellipse at 50% 40%, rgba(157,168,201,0.4) 0%, transparent 60%), #0E0F14"
            }}
          >
            <div className="text-center">
              <div className="font-serif text-white/90 text-[60px] leading-none">⚭</div>
              <div className="mt-4 text-[10px] tracking-[0.3em] uppercase text-white/55">
                Mariage civil
              </div>
              <div className="mt-2 text-white/70 text-[13px]">
                Mairie · AIME® Wedding
              </div>
            </div>
          </div>
        }
      />
    </div>
  );
}