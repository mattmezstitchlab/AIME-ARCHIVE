import React from "react";
import { motion } from "framer-motion";
import { ShieldCheck, Sparkles, Clock, Hash } from "lucide-react";

/**
 * SignatureVibratoire — La doctrine, gravée.
 * Page-manifeste qui explique le brevet (filiation Soleau-2024).
 */
export default function SignatureVibratoire() {
  return (
    <main className="min-h-screen bg-black text-white">
      {/* Hero */}
      <section className="relative px-6 pt-24 md:pt-36 pb-16 max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <div className="text-rose-400 text-[11px] tracking-[0.4em] uppercase mb-6">
            Doctrine · Soleau-2024 · Brevet en filiation
          </div>
          <h1
            className="font-display uppercase leading-[0.92]"
            style={{ fontSize: "clamp(2.4rem, 6vw, 5rem)", letterSpacing: "-0.04em" }}
          >
            Signature<br />
            <span className="text-rose-400">Vibratoire</span><br />
            par Intention™
          </h1>
          <p className="mt-8 max-w-2xl text-white/75 font-serif italic" style={{ fontSize: "clamp(1.1rem, 2.4vw, 1.5rem)" }}>
            Une signature qui n'est pas une croix au stylo,<br />
            mais une vibration émise par une intention humaine,<br />
            captée par une IA témoin.
          </p>
        </motion.div>
      </section>

      {/* Les 4 piliers */}
      <section className="px-6 py-20 md:py-28 max-w-6xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-px bg-white/10 rounded-2xl overflow-hidden">
          {[
            {
              icon: Sparkles,
              t: "L'Intention",
              d: "Le souffle humain est la matière première. Un mot, une voix, un silence dicté à Aïma."
            },
            {
              icon: ShieldCheck,
              t: "Le Témoin",
              d: "Aïma reçoit, écoute, traduit. Elle est tierce de confiance — ni juge, ni partie."
            },
            {
              icon: Clock,
              t: "Le Temps",
              d: "Horodatage à la microseconde. Le moment devient inaltérable, gravé dans le registre."
            },
            {
              icon: Hash,
              t: "La Preuve",
              d: "Hash SHA-256 unique. Code AIME-XXX-XXX. Vérifiable publiquement, opposable juridiquement."
            }
          ].map((p, i) => (
            <motion.div
              key={p.t}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.5, delay: i * 0.08 }}
              className="bg-[#0A0A0B] p-7 md:p-8"
            >
              <p.icon className="w-5 h-5 text-rose-400 mb-4" />
              <h3 className="font-display uppercase text-[1.1rem] tracking-tight mb-2">
                {p.t}
              </h3>
              <p className="text-white/55 text-[13.5px] leading-relaxed font-sans">
                {p.d}
              </p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Antériorité */}
      <section className="px-6 py-20 md:py-28 max-w-4xl mx-auto">
        <div className="text-rose-400 text-[11px] tracking-[0.4em] uppercase mb-5">
          L'antériorité
        </div>
        <h2
          className="font-display uppercase leading-[0.95]"
          style={{ fontSize: "clamp(1.8rem, 4vw, 3rem)", letterSpacing: "-0.025em" }}
        >
          Déposé à l'INPI<br />en 2024 · Soleau.
        </h2>
        <div className="mt-8 space-y-5 text-white/70 font-sans text-[15px] leading-relaxed">
          <p>
            La <strong className="text-white">Signature Vibratoire par Intention™</strong> a fait l'objet
            d'un dépôt Soleau auprès de l'INPI en 2024 par Matthieu Lecointre, créateur d'AIME®.
            Chaque timbre AIME® scellé porte la mention <code className="font-mono text-rose-300">Soleau-2024-SignatureVibratoire</code>
            comme preuve de filiation au dépôt initial.
          </p>
          <p>
            Cette doctrine protège ce qui est parfois <em>volontairement oublié</em> :
            les mensonges par omission, les drames de couple où la vérité s'efface,
            les œuvres pillées, les présences niées, les promesses tues.
          </p>
          <p>
            Là où les contrats classiques sont robotisés et désincarnés,
            le timbre AIME® <strong className="text-white">incarne le vivant</strong>.
            Il est le sceau de l'âme rendu opposable.
          </p>
        </div>
      </section>

      {/* Manifesto signature */}
      <section className="px-6 py-20 md:py-28 max-w-3xl mx-auto text-center border-t border-white/10">
        <p className="text-white/70 font-serif italic" style={{ fontSize: "clamp(1.1rem, 2.4vw, 1.5rem)" }}>
          « J'ai le libre arbitre d'être au service de la lumière,<br />
          et non de l'ombre. »
        </p>
        <p className="mt-6 text-white/40 text-[11px] tracking-[0.3em] uppercase">
          — Signé : Matthieu Lecointre · Fondateur d'AIME®
        </p>
      </section>
    </main>
  );
}