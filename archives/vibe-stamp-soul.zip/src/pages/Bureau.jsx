import React, { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { DESK_FOLDERS } from "@/lib/deskFolders";
import FolderIcon from "@/components/design-system/FolderIcons";
import AimaIcon from "@/components/design-system/AimaIcons";
import { getAnonymousId, getConversationId, setConversationId } from "@/lib/aimaSession";

/**
 * Bureau — interface plein écran style "desktop".
 * - Visuel mariage en background fullbleed
 * - Champ Aïma central façon Spotlight (pas de bloc, juste flottant)
 * - Dossiers du deskFolders répartis en grille en bas
 * - Une fois qu'Aïma répond, la conversation s'affiche au-dessus du champ
 */

const BG_URL =
  "https://res.cloudinary.com/divou1vcx/image/upload/v1777700210/pexels-jwfotografia-12103484_cdnpdw.jpg";

export default function Bureau() {
  const navigate = useNavigate();
  const [draft, setDraft] = useState("");
  const [messages, setMessages] = useState([]);
  const [typing, setTyping] = useState(false);
  const [conversationId, setConvId] = useState(null);
  const inputRef = useRef(null);
  const scrollerRef = useRef(null);

  // Restore prior conversation
  useEffect(() => {
    const existingId = getConversationId();
    if (!existingId) return;
    base44.entities.Conversation.filter({ id: existingId })
      .then((rows) => {
        const conv = rows?.[0];
        if (conv && Array.isArray(conv.messages) && conv.messages.length > 0) {
          setMessages(conv.messages);
          setConvId(conv.id);
        }
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    const el = scrollerRef.current;
    if (el) el.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
  }, [messages, typing]);

  const persist = async (allMessages, currentId) => {
    const toSave = allMessages.map((m) => ({
      role: m.role,
      text: m.text,
      ts: new Date().toISOString()
    }));
    const last_at = new Date().toISOString();
    try {
      if (currentId) {
        await base44.entities.Conversation.update(currentId, { messages: toSave, last_at });
        return currentId;
      }
      const created = await base44.entities.Conversation.create({
        anonymous_id: getAnonymousId(),
        space: "discover",
        messages: toSave,
        last_at
      });
      setConvId(created.id);
      setConversationId(created.id);
      return created.id;
    } catch {
      return currentId;
    }
  };

  const send = async (text) => {
    const value = (text ?? draft).trim();
    if (!value) return;
    const newUserMsg = { role: "user", text: value };
    const nextMessages = [...messages, newUserMsg];
    setMessages(nextMessages);
    setDraft("");
    setTyping(true);
    try {
      const apiMessages = nextMessages.map((m) => ({
        role: m.role === "user" ? "user" : "assistant",
        content: m.text
      }));
      const response = await base44.functions.invoke("aimaChat", { messages: apiMessages });
      const reply = response?.data?.reply || "Je tisse en silence. Dis-moi un mot de plus.";
      const finalMessages = [...nextMessages, { role: "aima", text: reply }];
      setMessages(finalMessages);
      await persist(finalMessages, conversationId);
    } catch {
      setMessages((m) => [
        ...m,
        { role: "aima", text: "Un instant — je reprends mon souffle. Réessaie." }
      ]);
    } finally {
      setTyping(false);
    }
  };

  const handleFolderClick = (folder) => {
    // Ouvre l'espace correspondant si défini
    const routes = {
      mariage: "/mariage",
      noyau: "/noyau",
      memoire: "/memoire",
      "music-rights": "/music-rights",
      cabinet: "/mon-cabinet",
      registre: "/registre",
      intermittents: "/intermittents",
      agriculteurs: "/agriculteurs",
      inclusive: "/inclusive",
      mairies: "/mairies"
    };
    const path = routes[folder.id] || routes[folder.space];
    if (path) {
      navigate(path);
    } else {
      // sinon, envoie le nom du dossier comme intention à Aïma
      send(`Je veux explorer : ${folder.name}`);
      inputRef.current?.focus();
    }
  };

  const hasConversation = messages.length > 0;

  return (
    <main className="fixed inset-0 overflow-hidden">
      {/* Background mariage plein écran */}
      <div
        className="absolute inset-0"
        style={{
          backgroundImage: `url(${BG_URL})`,
          backgroundSize: "cover",
          backgroundPosition: "center"
        }}
      />
      {/* Voile foncé pour lisibilité */}
      <div className="absolute inset-0 bg-black/40" />
      <div
        className="absolute inset-0"
        style={{
          background:
            "linear-gradient(180deg, rgba(0,0,0,0.55) 0%, rgba(0,0,0,0.15) 35%, rgba(0,0,0,0.65) 100%)"
        }}
      />

      {/* Contenu */}
      <div className="relative z-10 w-full h-full flex flex-col overflow-y-auto">
        {/* Top — Eyebrow */}
        <div className="px-6 pt-8 md:pt-12 text-center">
          <div className="text-white/70 text-[10px] tracking-[0.4em] uppercase font-sans">
            AIME® · Le Bureau
          </div>
          <h1
            className="mt-3 text-white font-display uppercase leading-[0.95]"
            style={{ fontSize: "clamp(2rem, 5vw, 3.5rem)", letterSpacing: "-0.03em" }}
          >
            Que cherches-tu<br />aujourd'hui ?
          </h1>
        </div>

        {/* Conversation flottante (au-dessus du champ) */}
        <div className="flex-1 flex flex-col justify-end px-4 md:px-8 pb-4">
          {hasConversation && (
            <div
              ref={scrollerRef}
              className="max-w-2xl mx-auto w-full max-h-[40vh] overflow-y-auto space-y-4 mb-6 px-2"
              style={{ scrollbarWidth: "thin" }}
            >
              <AnimatePresence initial={false}>
                {messages.map((m, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3 }}
                    className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}
                  >
                    <div
                      className={`max-w-[85%] text-[14px] leading-relaxed whitespace-pre-line font-sans ${
                        m.role === "user"
                          ? "text-white font-medium"
                          : "text-white/85"
                      }`}
                      style={{
                        textShadow: "0 2px 8px rgba(0,0,0,0.6)",
                        letterSpacing: "0.01em"
                      }}
                    >
                      {m.role === "aima" && (
                        <span className="text-white/45 text-[10px] tracking-[0.3em] uppercase mr-2">
                          Aïma ·
                        </span>
                      )}
                      {m.text}
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
              {typing && (
                <div className="flex justify-start gap-1.5 px-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-white/70 animate-bounce" />
                  <span
                    className="w-1.5 h-1.5 rounded-full bg-white/70 animate-bounce"
                    style={{ animationDelay: "150ms" }}
                  />
                  <span
                    className="w-1.5 h-1.5 rounded-full bg-white/70 animate-bounce"
                    style={{ animationDelay: "300ms" }}
                  />
                </div>
              )}
            </div>
          )}

          {/* Champ Aïma central — Spotlight, sans bloc */}
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="max-w-2xl w-full mx-auto"
          >
            <div className="relative rounded-full bg-white/10 backdrop-blur-xl border border-white/25 shadow-[0_20px_60px_rgba(0,0,0,0.5)] overflow-hidden">
              <div className="flex items-center gap-3 px-5 py-4">
                <div className="w-9 h-9 rounded-full bg-white/95 text-stone-900 flex items-center justify-center font-serif text-[15px] flex-shrink-0">
                  ◇
                </div>
                <input
                  ref={inputRef}
                  value={draft}
                  onChange={(e) => setDraft(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && send()}
                  placeholder="Demande à Aïma…"
                  className="flex-1 bg-transparent outline-none text-white text-[16px] placeholder:text-white/50 font-sans"
                  style={{ letterSpacing: "-0.012em" }}
                />
                <button
                  onClick={() => send()}
                  disabled={!draft.trim()}
                  className="w-10 h-10 rounded-full bg-white hover:bg-white/90 disabled:bg-white/30 disabled:cursor-not-allowed text-stone-900 flex items-center justify-center transition-colors flex-shrink-0"
                  aria-label="Envoyer"
                >
                  <AimaIcon name="arrow" size={16} strokeWidth={2.2} />
                </button>
              </div>
            </div>
            <div className="text-center mt-3 text-white/55 text-[10px] tracking-[0.3em] uppercase font-sans">
              ⌘K · Aïma t'écoute
            </div>
          </motion.div>
        </div>

        {/* Dossiers — grille flottante */}
        <div className="px-4 md:px-8 pb-10">
          <div className="text-center mb-5">
            <div className="text-white/55 text-[9px] tracking-[0.4em] uppercase font-sans">
              Tes dossiers
            </div>
          </div>
          <div className="max-w-5xl mx-auto grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 lg:grid-cols-10 gap-3 md:gap-4">
            {DESK_FOLDERS.map((f, i) => (
              <FolderTile key={f.id} folder={f} index={i} onClick={() => handleFolderClick(f)} />
            ))}
          </div>
        </div>
      </div>
    </main>
  );
}

function FolderTile({ folder, index, onClick }) {
  return (
    <motion.button
      type="button"
      onClick={onClick}
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: 0.05 + index * 0.015 }}
      whileHover={{ scale: 1.08, y: -2 }}
      whileTap={{ scale: 0.95 }}
      className="group flex flex-col items-center gap-1.5 p-2"
      title={folder.description}
    >
      <div
        className="w-12 h-12 md:w-14 md:h-14 rounded-2xl bg-white/15 backdrop-blur-md border border-white/25 flex items-center justify-center text-white shadow-[0_6px_20px_rgba(0,0,0,0.4)] group-hover:bg-white/25 group-hover:border-white/45 transition-all"
      >
        <FolderIcon name={folder.icon} size={22} strokeWidth={1.6} />
      </div>
      <div
        className="text-white text-[9px] md:text-[10px] tracking-[0.05em] font-sans text-center leading-tight"
        style={{ textShadow: "0 1px 4px rgba(0,0,0,0.7)" }}
      >
        {folder.name}
      </div>
    </motion.button>
  );
}