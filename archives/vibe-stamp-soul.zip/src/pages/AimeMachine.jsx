import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { base44 } from "@/api/base44Client";
import StampForLoveLogo from "@/components/aimemachine/StampForLoveLogo";
import PostcardStepper from "@/components/aimemachine/PostcardStepper";
import StepStamp from "@/components/aimemachine/StepStamp";
import StepPostcard from "@/components/aimemachine/StepPostcard";
import StepCollage from "@/components/aimemachine/StepCollage";
import StepPacte from "@/components/aimemachine/StepPacte";
import StepTampon from "@/components/aimemachine/StepTampon";
import PostcardSealed from "@/components/aimemachine/PostcardSealed";
import PostcardParallaxColumns from "@/components/aimemachine/PostcardParallaxColumns";

/**
 * AimeMachine — "Stamp for Love"
 * Workflow 4 étapes : timbre → carte → collage → tampon → scellé.
 * Le résultat = une carte postale lisible avec un code privé.
 */

function genPostcardCode() {
  const A = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const seg = (n) =>
    Array.from({ length: n }, () => A[Math.floor(Math.random() * A.length)]).join("");
  return `PC-${seg(4)}-${seg(4)}`;
}

export default function AimeMachine() {
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Étape 1 — timbre
  const [stampPrompt, setStampPrompt] = useState("");
  const [photoUrl, setPhotoUrl] = useState("");
  const [stamp, setStamp] = useState(null);

  // Étape 2 — carte
  const [cardPrompt, setCardPrompt] = useState("");
  const [messageRaw, setMessageRaw] = useState("");
  const [cardImageUrl, setCardImageUrl] = useState("");
  const [messageHandwritten, setMessageHandwritten] = useState("");

  // Étape 3 — collage
  const [stampPosition, setStampPosition] = useState({ x: 85, y: 18, rotation: -8 });

  // Étape 4 — pacte
  const [signatureName, setSignatureName] = useState("");
  const [consentTruth, setConsentTruth] = useState(false);
  const [consentRespect, setConsentRespect] = useState(false);
  const [consentShare, setConsentShare] = useState(false);

  // Étape 5 — tampon
  const [tamponCity, setTamponCity] = useState("");
  const [tamponText, setTamponText] = useState("");

  // Final
  const [postcard, setPostcard] = useState(null);

  // === ÉTAPE 1 — Génère le timbre ===
  const handleGenerateStamp = async () => {
    setError(null);
    setLoading(true);
    try {
      const intentionShort = stampPrompt.trim().slice(0, 200);
      const imgPrompt = `A LARGE vintage postage stamp on a PURE BLACK background (#000000), the stamp filling 90-95% of the canvas, with PERFECT regular white perforated dentelure (toothed edges) on all four sides — the dentelure stands out crisp white against the black background.

The stamp itself:
- Cream-ivory aged paper texture inside the perforated frame.
- At the top, in pink-magenta ink (#E11D48): "AIME®" in elegant serif capitals, slightly arched.
- Below "AIME®", a thin horizontal line and small text "RÉPUBLIQUE DES PRÉSENCES" in light grey.
- Center: a delicate engraved illustration in pink-magenta ink (fine line work, cross-hatching, vintage stamp style) of: "${intentionShort}".
- At the bottom, a city name in pink-magenta capitals: "PARIS".
- In the top-right corner, a faded grey circular cancellation mark (oblitération) with three small stars and the date "MAI 2026", lightly tilted.
- Subtle paper grain and very slight aging.

CRUCIAL: the background MUST be solid pure black (#000000), NOT white. The stamp is centered, large, with its white perforated dentelure popping against the black void. Square aspect ratio.

AVOID: white background, grey background, small stamp on big background, photography, modern flat design, illegible text, irregular jagged edges, no perforations.`;

      const imgRes = await base44.integrations.Core.GenerateImage({
        prompt: imgPrompt,
        existing_image_urls: photoUrl ? [photoUrl] : undefined
      });
      const generatedImageUrl = imgRes?.url || "";

      const res = await base44.functions.invoke("sealStamp", {
        text: intentionShort.slice(0, 60),
        image_url: generatedImageUrl || "stamp:fallback",
        intention_text: stampPrompt.trim(),
        person_photo_url: photoUrl || undefined,
        category: "personnel",
        issued_city: "Paris"
      });
      const data = res?.data;
      if (!data?.ok || !data?.stamp) throw new Error(data?.error || "Émission échouée");
      setStamp({ ...data.stamp, image_url: generatedImageUrl || data.stamp.image_url });
    } catch (e) {
      setError(e.message || "Erreur");
    } finally {
      setLoading(false);
    }
  };

  // === ÉTAPE 2 — Génère carte + reformule message ===
  const handleGenerateCard = async () => {
    setError(null);
    setLoading(true);
    try {
      const cardImgPrompt = `A beautiful vintage-style postcard front image, painterly illustration: ${cardPrompt.trim()}. Soft warm light, romantic atmosphere, watercolor or oil painting feel. NO text, NO writing on the image. Wide landscape composition.`;

      const [imgRes, llmRes] = await Promise.all([
        base44.integrations.Core.GenerateImage({ prompt: cardImgPrompt }),
        base44.integrations.Core.InvokeLLM({
          prompt: `Tu es Aïma, voix d'AIME®. Reformule ce message en français avec une belle formule chaleureuse et poétique, comme une carte postale écrite à la main. Garde l'intention intacte mais embellis. Maximum 3 phrases courtes. Ne signe pas. Réponds uniquement avec le texte reformulé, sans guillemets ni préambule.

Message brut : "${messageRaw.trim()}"`
        })
      ]);

      setCardImageUrl(imgRes?.url || "");
      const handwritten =
        typeof llmRes === "string" ? llmRes.trim() : llmRes?.toString?.() || messageRaw;
      setMessageHandwritten(handwritten.replace(/^["«»"]+|["«»"]+$/g, "").trim());
    } catch (e) {
      setError(e.message || "Erreur");
    } finally {
      setLoading(false);
    }
  };

  // === ÉTAPE 4 — Scelle la carte ===
  const handleSealPostcard = async () => {
    setError(null);
    setLoading(true);
    try {
      const code = genPostcardCode();
      const created = await base44.entities.Postcard.create({
        code,
        is_public: true,
        likes_count: 0,
        value_eur: 0,
        for_sale: false,
        stamp_id: stamp?.id,
        stamp_code: stamp?.code,
        stamp_image_url: stamp?.image_url,
        card_image_url: cardImageUrl,
        card_image_prompt: cardPrompt,
        message_raw: messageRaw,
        message_handwritten: messageHandwritten,
        stamp_position: stampPosition,
        tampon_text: tamponText,
        tampon_city: tamponCity,
        tampon_date: new Date().toISOString(),
        recipient_hint: signatureName
          ? `Signé par ${signatureName.trim()}`
          : null
      });
      setPostcard(created);
      setStep(6);
    } catch (e) {
      setError(e.message || "Erreur");
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setStep(1);
    setStampPrompt("");
    setPhotoUrl("");
    setStamp(null);
    setCardPrompt("");
    setMessageRaw("");
    setCardImageUrl("");
    setMessageHandwritten("");
    setStampPosition({ x: 85, y: 18, rotation: -8 });
    setSignatureName("");
    setConsentTruth(false);
    setConsentRespect(false);
    setConsentShare(false);
    setTamponCity("");
    setTamponText("");
    setPostcard(null);
    setError(null);
  };

  return (
    <main className="min-h-screen w-full bg-black relative overflow-hidden">
      {/* Halo léger derrière le titre */}
      <div
        className="absolute top-0 left-1/2 -translate-x-1/2 pointer-events-none"
        style={{
          width: 900,
          height: 600,
          background:
            "radial-gradient(ellipse at center, rgba(225,29,72,0.08) 0%, transparent 70%)",
          filter: "blur(40px)"
        }}
      />

      {/* HERO */}
      <section className="relative w-full px-5 pt-20 md:pt-28 pb-10 flex flex-col items-center text-center">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-white/50 text-[11px] tracking-[0.4em] uppercase mb-6 font-sans"
        >
          AIME® · Le Registre Universel
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.1 }}
        >
          <StampForLoveLogo />
        </motion.div>
      </section>

      {/* WORKFLOW */}
      <section className="relative w-full px-5 pb-20 flex flex-col items-center">
        {step <= 5 && <PostcardStepper current={step} />}

        <AnimatePresence mode="wait">
          <motion.div
            key={step}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.4 }}
            className="w-full flex justify-center"
          >
            {step === 1 && (
              <StepStamp
                prompt={stampPrompt}
                setPrompt={setStampPrompt}
                loading={loading}
                onGenerate={handleGenerateStamp}
                generatedStamp={stamp}
                onNext={() => setStep(2)}
              />
            )}
            {step === 2 && (
              <StepPostcard
                cardPrompt={cardPrompt}
                setCardPrompt={setCardPrompt}
                messageRaw={messageRaw}
                setMessageRaw={setMessageRaw}
                loading={loading}
                onGenerate={handleGenerateCard}
                cardImageUrl={cardImageUrl}
                messageHandwritten={messageHandwritten}
                onNext={() => setStep(3)}
              />
            )}
            {step === 3 && (
              <StepCollage
                cardImageUrl={cardImageUrl}
                messageHandwritten={messageHandwritten}
                stampImageUrl={stamp?.image_url}
                stampCode={stamp?.code}
                stampPosition={stampPosition}
                setStampPosition={setStampPosition}
                onNext={() => setStep(4)}
              />
            )}
            {step === 4 && (
              <StepPacte
                signatureName={signatureName}
                setSignatureName={setSignatureName}
                consentTruth={consentTruth}
                setConsentTruth={setConsentTruth}
                consentRespect={consentRespect}
                setConsentRespect={setConsentRespect}
                consentShare={consentShare}
                setConsentShare={setConsentShare}
                onNext={() => setStep(5)}
              />
            )}
            {step === 5 && (
              <StepTampon
                tamponCity={tamponCity}
                setTamponCity={setTamponCity}
                tamponText={tamponText}
                setTamponText={setTamponText}
                loading={loading}
                onSeal={handleSealPostcard}
              />
            )}
            {step === 6 && postcard && (
              <PostcardSealed postcard={postcard} onReset={handleReset} />
            )}
          </motion.div>
        </AnimatePresence>

        {error && (
          <div className="text-rose-400 text-[12px] font-sans mt-4">{error}</div>
        )}
      </section>

      {/* GALERIE PUBLIQUE — les doubles que les internautes peuvent aimer */}
      <PostcardParallaxColumns />

      {/* Footer */}
      <section className="relative z-10 px-6 py-20 max-w-2xl mx-auto text-center">
        <p
          className="text-white/40 font-serif italic"
          style={{ fontSize: 14, lineHeight: 1.7 }}
        >
          « Vos intentions, notre système, votre histoire. »
        </p>
        <p className="mt-2 text-white/25 text-[10px] tracking-[0.3em] uppercase font-sans">
          Soleau-2024 · INPI · Signature Vibratoire par Intention™
        </p>
      </section>
    </main>
  );
}