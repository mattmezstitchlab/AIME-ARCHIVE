import React, { useState, useEffect, useRef } from "react";

/**
 * EditableField — champ texte clique-modifie pour le mini-site.
 * Si editing=true → contour pointillé doré, clic = mode édition inline.
 * Si editing=false → simple affichage du texte.
 */
export default function EditableField({
  value,
  onChange,
  editing = false,
  multiline = false,
  placeholder = "",
  as: Tag = "span",
  className = "",
  style = {},
  accent = "#D4A574"
}) {
  const [active, setActive] = useState(false);
  const [draft, setDraft] = useState(value || "");
  const ref = useRef(null);

  useEffect(() => { setDraft(value || ""); }, [value]);

  useEffect(() => {
    if (active && ref.current) {
      ref.current.focus();
      // Place cursor at end
      const len = ref.current.value.length;
      try { ref.current.setSelectionRange(len, len); } catch (_) {}
    }
  }, [active]);

  if (!editing) {
    return (
      <Tag className={className} style={style}>
        {value || placeholder}
      </Tag>
    );
  }

  if (active) {
    const Cmp = multiline ? "textarea" : "input";
    return (
      <Cmp
        ref={ref}
        value={draft}
        onChange={(e) => setDraft(e.target.value)}
        onBlur={() => {
          setActive(false);
          if (draft !== value) onChange?.(draft);
        }}
        onKeyDown={(e) => {
          if (!multiline && e.key === "Enter") { e.preventDefault(); ref.current?.blur(); }
          if (e.key === "Escape") { setDraft(value || ""); setActive(false); }
        }}
        rows={multiline ? 4 : undefined}
        placeholder={placeholder}
        className={`${className} bg-transparent outline-none border-b-2 w-full resize-none`}
        style={{ ...style, borderColor: accent, caretColor: accent }}
      />
    );
  }

  return (
    <Tag
      onClick={(e) => { e.stopPropagation(); setActive(true); }}
      className={`${className} cursor-text hover:bg-white/5 outline-dashed outline-1 outline-offset-2 rounded transition-colors`}
      style={{ ...style, outlineColor: `${accent}66` }}
      title="Cliquer pour modifier"
    >
      {value || <span className="opacity-40">{placeholder}</span>}
    </Tag>
  );
}