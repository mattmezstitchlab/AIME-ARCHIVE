import React from "react";
import EditableField from "./EditableField";
import EditableImage from "./EditableImage";

/**
 * MiniSiteSection — bloc composable du mini-site.
 * 6 types : text · image · quote · info · playlist · guestbook (placeholder).
 * En mode édition, chaque champ est cliquable.
 */
export default function MiniSiteSection({ section, editing, accent, onUpdate, onRemove }) {
  const update = (patch) => onUpdate?.({ ...section, ...patch });

  const wrapper = "relative max-w-3xl mx-auto px-6 py-12 md:py-16";

  if (section.kind === "text") {
    return (
      <div className={wrapper}>
        {editing && <RemoveBtn onRemove={onRemove} />}
        <EditableField
          editing={editing}
          value={section.title}
          onChange={(title) => update({ title })}
          placeholder="Titre de la section"
          as="h2"
          className="apple-headline text-white text-2xl md:text-3xl mb-4"
          accent={accent}
        />
        <EditableField
          editing={editing}
          value={section.body}
          onChange={(body) => update({ body })}
          placeholder="Écris ici…"
          multiline
          as="p"
          className="font-sans text-white/75 text-[15px] leading-relaxed whitespace-pre-line"
          accent={accent}
        />
      </div>
    );
  }

  if (section.kind === "quote") {
    return (
      <div className={`${wrapper} text-center`}>
        {editing && <RemoveBtn onRemove={onRemove} />}
        <EditableField
          editing={editing}
          value={section.body}
          onChange={(body) => update({ body })}
          placeholder="Une phrase qui vous ressemble…"
          multiline
          as="blockquote"
          className="font-serif italic text-white/90 text-xl md:text-2xl leading-snug"
          accent={accent}
        />
        <div className="mt-4">
          <EditableField
            editing={editing}
            value={section.title}
            onChange={(title) => update({ title })}
            placeholder="— signature"
            as="div"
            className="font-sans text-white/45 text-[12px] tracking-wider uppercase"
            accent={accent}
          />
        </div>
      </div>
    );
  }

  if (section.kind === "image") {
    return (
      <div className={wrapper}>
        {editing && <RemoveBtn onRemove={onRemove} />}
        <div className="rounded-2xl overflow-hidden aspect-[16/10] bg-white/5">
          <EditableImage
            editing={editing}
            src={section.media_url}
            onChange={(media_url) => update({ media_url })}
            accent={accent}
            alt={section.title || ""}
            className="w-full h-full"
          />
        </div>
        <EditableField
          editing={editing}
          value={section.title}
          onChange={(title) => update({ title })}
          placeholder="Légende (optionnel)"
          as="div"
          className="mt-3 text-center text-white/55 text-[13px] font-sans italic"
          accent={accent}
        />
      </div>
    );
  }

  if (section.kind === "info") {
    return (
      <div className={wrapper}>
        {editing && <RemoveBtn onRemove={onRemove} />}
        <div className="rounded-2xl border border-white/10 p-6 md:p-8 bg-white/[0.02]">
          <EditableField
            editing={editing}
            value={section.title}
            onChange={(title) => update({ title })}
            placeholder="Infos pratiques · Lieu · Horaires…"
            as="div"
            className="font-sans text-[10px] tracking-[0.3em] uppercase mb-3"
            style={{ color: accent }}
            accent={accent}
          />
          <EditableField
            editing={editing}
            value={section.body}
            onChange={(body) => update({ body })}
            placeholder="Adresse, horaires, dress code, parking…"
            multiline
            as="div"
            className="font-sans text-white/80 text-[15px] leading-relaxed whitespace-pre-line"
            accent={accent}
          />
        </div>
      </div>
    );
  }

  if (section.kind === "playlist") {
    return (
      <div className={wrapper}>
        {editing && <RemoveBtn onRemove={onRemove} />}
        <div className="rounded-2xl border border-white/10 p-6 md:p-8 bg-white/[0.02] text-center">
          <div className="font-sans text-[10px] tracking-[0.3em] uppercase mb-3" style={{ color: accent }}>
            Playlist collaborative
          </div>
          <div className="font-serif italic text-white/85 text-lg">
            Chaque invité dépose une chanson.
          </div>
          <div className="mt-3 text-white/50 text-[13px] font-sans">
            Disponible une fois le mini-site publié.
          </div>
        </div>
      </div>
    );
  }

  if (section.kind === "guestbook") {
    return (
      <div className={wrapper}>
        {editing && <RemoveBtn onRemove={onRemove} />}
        <div className="rounded-2xl border border-white/10 p-6 md:p-8 bg-white/[0.02] text-center">
          <div className="font-sans text-[10px] tracking-[0.3em] uppercase mb-3" style={{ color: accent }}>
            Livre d'or
          </div>
          <div className="font-serif italic text-white/85 text-lg">
            Un mot, une vidéo, un souvenir.
          </div>
          <div className="mt-3 text-white/50 text-[13px] font-sans">
            Disponible une fois le mini-site publié.
          </div>
        </div>
      </div>
    );
  }

  return null;
}

function RemoveBtn({ onRemove }) {
  return (
    <button
      type="button"
      onClick={onRemove}
      title="Supprimer ce bloc"
      className="absolute top-3 right-3 w-7 h-7 rounded-full bg-red-500/20 hover:bg-red-500/40 border border-red-400/30 text-red-300 flex items-center justify-center text-[13px] z-10"
    >
      ×
    </button>
  );
}