import React, { useRef, useState } from "react";
import { base44 } from "@/api/base44Client";

/**
 * EditableImage — image clique-modifie. En mode editing, affiche un overlay
 * "remplacer cette image". Upload via base44.integrations.Core.UploadFile.
 */
export default function EditableImage({
  src,
  onChange,
  editing = false,
  className = "",
  alt = "",
  accent = "#D4A574"
}) {
  const inputRef = useRef(null);
  const [uploading, setUploading] = useState(false);

  const handleFile = async (file) => {
    if (!file) return;
    setUploading(true);
    try {
      const res = await base44.integrations.Core.UploadFile({ file });
      if (res?.file_url) onChange?.(res.file_url);
    } catch (_) {}
    setUploading(false);
  };

  return (
    <div className={`relative group ${className}`}>
      {src ? (
        <img src={src} alt={alt} className="w-full h-full object-cover" />
      ) : (
        <div className="w-full h-full bg-white/5 flex items-center justify-center text-white/40 text-sm">
          {editing ? "Cliquer pour ajouter une image" : ""}
        </div>
      )}

      {editing && (
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          className="absolute inset-0 flex items-center justify-center bg-black/40 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity"
          style={{ outline: `2px dashed ${accent}` }}
        >
          <div className="px-4 py-2 rounded-full bg-white/95 text-stone-900 text-[11px] tracking-[0.2em] uppercase font-medium">
            {uploading ? "Envoi…" : src ? "Remplacer" : "Ajouter"}
          </div>
        </button>
      )}

      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => handleFile(e.target.files?.[0])}
      />
    </div>
  );
}