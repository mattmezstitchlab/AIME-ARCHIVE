import React from "react";
import { motion } from "framer-motion";

/**
 * AgriFolderCard — un dossier de la fenêtre Agriculteurs.
 * Couleur sombre dédiée par dossier, liseré doré pour "Mon équilibre".
 */
export default function AgriFolderCard({ folder, count = 0, onClick, delay = 0 }) {
  const isEquilibre = folder.id === "equilibre";

  return (
    <motion.button
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.5 }}
      whileHover={{ y: -3 }}
      onClick={onClick}
      className="text-left rounded-2xl p-5 relative overflow-hidden group transition-shadow hover:shadow-2xl"
      style={{
        background: folder.color,
        border: isEquilibre
          ? `1px solid ${folder.accentBorder || "#B89A52"}`
          : "1px solid rgba(255,255,255,0.06)",
        boxShadow: isEquilibre
          ? "0 0 0 1px rgba(184,154,82,0.3) inset, 0 8px 32px rgba(0,0,0,0.3)"
          : "0 4px 16px rgba(0,0,0,0.2)",
        minHeight: 160
      }}
    >
      {/* Liseré doré pour Équilibre */}
      {isEquilibre && (
        <div
          className="absolute inset-0 pointer-events-none rounded-2xl"
          style={{
            background:
              "linear-gradient(135deg, rgba(184,154,82,0.08) 0%, transparent 50%, rgba(184,154,82,0.04) 100%)"
          }}
        />
      )}

      <div className="relative">
        <div className="flex items-start justify-between mb-3">
          <div
            className="text-[15px] font-medium text-white"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            {folder.name}
          </div>
          {!folder.counterHidden && count > 0 && (
            <span className="px-2 py-0.5 rounded-full bg-white/15 text-white text-[10px] font-medium">
              {count}
            </span>
          )}
        </div>
        <p className="text-[12px] text-white/65 leading-snug mb-3 line-clamp-2">
          {folder.desc}
        </p>
        {!folder.counterHidden && (
          <div className="text-[9px] tracking-[2px] uppercase text-white/40">
            {folder.counterLabel}
          </div>
        )}
        {folder.confidential && (
          <div
            className="text-[9px] tracking-[2px] uppercase mt-1"
            style={{ color: "#B89A52" }}
          >
            ✦ Confidentiel · aucune donnée enregistrée
          </div>
        )}
      </div>
    </motion.button>
  );
}