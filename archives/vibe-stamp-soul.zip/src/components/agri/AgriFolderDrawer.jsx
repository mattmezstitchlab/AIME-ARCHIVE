import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { AGRI_HELP, AGRI_DISCLAIMER, detectDistress } from "@/lib/agriBrand";

/**
 * AgriFolderDrawer — modal qui s'ouvre quand on clique un dossier agricole.
 * Aïma pose ses questions une par une. Pour "Mon équilibre" : zone confidentielle,
 * Agri'Écoute affiché dès l'ouverture, détection de mots de détresse → 3114.
 */
export default function AgriFolderDrawer({ folder, onClose }) {
  const [step, setStep] = useState(0);
  const [draft, setDraft] = useState("");
  const [showDistress, setShowDistress] = useState(false);

  const isEquilibre = folder.id === "equilibre";
  const isFinished = step >= folder.questions.length;

  const handleSend = () => {
    if (!draft.trim()) return;
    if (isEquilibre && detectDistress(draft)) {
      setShowDistress(true);
    }
    setDraft("");
    setStep((s) => s + 1);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.96, y: 16 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.96, y: 16 }}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-xl rounded-3xl overflow-hidden relative"
        style={{
          background: folder.color,
          border: isEquilibre
            ? "1px solid rgba(184,154,82,0.4)"
            : "1px solid rgba(255,255,255,0.1)",
          boxShadow: "0 30px 80px rgba(0,0,0,0.5)"
        }}
      >
        {/* Header */}
        <div className="px-7 pt-6 pb-4 border-b border-white/10 flex items-start justify-between">
          <div>
            <div
              className="text-[10px] tracking-[3px] uppercase mb-1"
              style={{ color: isEquilibre ? "#B89A52" : "rgba(255,255,255,0.5)" }}
            >
              Aïma · {folder.name}
            </div>
            <h2
              className="text-2xl font-light text-white"
              style={{ fontFamily: "'Playfair Display', serif" }}
            >
              {isEquilibre ? folder.openingMessage : folder.desc}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="text-white/50 hover:text-white text-[20px] flex-shrink-0"
            aria-label="Fermer"
          >
            ×
          </button>
        </div>

        {/* Confidentialité — Mon équilibre */}
        {isEquilibre && (
          <div
            className="mx-7 mt-4 mb-2 rounded-xl p-3 text-[11px] leading-relaxed border"
            style={{
              background: "rgba(184,154,82,0.06)",
              borderColor: "rgba(184,154,82,0.2)",
              color: "rgba(255,255,255,0.75)"
            }}
          >
            <div className="font-medium text-[#D4B483] mb-1">Confidentialité totale</div>
            Cette conversation n'est pas enregistrée. Aïma écoute, mais ne garde rien.
            <div className="mt-2 pt-2 border-t border-[#B89A52]/15">
              <span className="font-medium text-white/90">{AGRI_HELP.agriEcoute.name}</span>
              {" — "}
              <a
                href={`tel:${AGRI_HELP.agriEcoute.phone.replace(/\s/g, "")}`}
                className="text-[#D4B483] underline hover:text-white transition-colors"
              >
                {AGRI_HELP.agriEcoute.phone}
              </a>
              <span className="text-white/55"> · {AGRI_HELP.agriEcoute.desc}</span>
            </div>
          </div>
        )}

        {/* Body */}
        <div className="px-7 py-6 max-h-[55vh] overflow-y-auto">
          <AnimatePresence mode="wait">
            {!isFinished ? (
              <motion.div
                key={step}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.25 }}
              >
                <div className="text-[10px] tracking-[2px] uppercase text-white/35 mb-2">
                  Question {step + 1} / {folder.questions.length}
                </div>
                <div
                  className="text-[18px] text-white leading-relaxed mb-4 font-serif italic"
                  style={{ fontFamily: "'Playfair Display', serif" }}
                >
                  {folder.questions[step]}
                </div>
                <textarea
                  value={draft}
                  onChange={(e) => setDraft(e.target.value)}
                  rows={3}
                  placeholder="Réponds simplement, comme tu parles…"
                  className="w-full bg-black/30 border border-white/10 rounded-xl p-3 text-[14px] text-white outline-none focus:border-[#B89A52] resize-none placeholder:text-white/30"
                />
              </motion.div>
            ) : (
              <motion.div
                key="capabilities"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.4 }}
              >
                <div className="text-[10px] tracking-[3px] uppercase text-[#D4B483] mb-3">
                  Aïma peut maintenant
                </div>
                <ul className="space-y-2.5 mb-4">
                  {folder.capabilities.map((c) => (
                    <li
                      key={c}
                      className="flex items-start gap-2.5 text-[13.5px] text-white/85 leading-snug"
                    >
                      <span className="text-[#B89A52] mt-0.5 flex-shrink-0">✦</span>
                      <span>{c}</span>
                    </li>
                  ))}
                </ul>
                {!isEquilibre && (
                  <div className="mt-5 pt-4 border-t border-white/10 text-[10.5px] text-white/45 italic leading-relaxed">
                    {AGRI_DISCLAIMER}
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>

          {/* Détresse → 3114 */}
          {showDistress && (
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-5 rounded-xl p-4"
              style={{
                background: "rgba(184,154,82,0.1)",
                border: "1px solid rgba(184,154,82,0.4)"
              }}
            >
              <div
                className="text-[16px] mb-2 text-white"
                style={{ fontFamily: "'Playfair Display', serif", fontStyle: "italic" }}
              >
                Je suis là. Tu n'es pas seul.
              </div>
              <div className="text-[12px] text-white/75 leading-relaxed">
                Si tu veux parler à quelqu'un tout de suite, le{" "}
                <a
                  href="tel:3114"
                  className="text-[#D4B483] underline font-medium hover:text-white"
                >
                  3114
                </a>{" "}
                est là — gratuit, 24h/24, confidentiel. C'est le numéro national de prévention du suicide.
              </div>
            </motion.div>
          )}
        </div>

        {/* Footer */}
        <div className="px-7 py-4 border-t border-white/10 flex justify-between items-center">
          <button
            onClick={() => step > 0 && setStep((s) => s - 1)}
            className={`text-[10px] tracking-[3px] uppercase transition-colors ${
              step === 0 || isFinished
                ? "invisible"
                : "text-white/40 hover:text-white"
            }`}
          >
            ← Retour
          </button>
          {!isFinished ? (
            <button
              onClick={handleSend}
              disabled={!draft.trim()}
              className="px-7 py-2.5 rounded-full text-[10px] tracking-[3px] uppercase transition-colors disabled:opacity-30"
              style={{
                background: "#B89A52",
                color: folder.color
              }}
            >
              {step === folder.questions.length - 1 ? "Terminer ✦" : "Continuer →"}
            </button>
          ) : (
            <button
              onClick={onClose}
              className="px-7 py-2.5 rounded-full text-[10px] tracking-[3px] uppercase bg-white/10 text-white/80 hover:bg-white/20 transition-colors"
            >
              Fermer
            </button>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
}