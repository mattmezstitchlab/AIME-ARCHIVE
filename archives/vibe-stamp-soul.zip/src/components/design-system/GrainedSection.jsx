import React from "react";

// SVG noise filter for the grainy texture (Framer-style)
export function GrainSVG() {
  return (
    <svg className="absolute inset-0 w-full h-full opacity-[0.08] mix-blend-overlay pointer-events-none" aria-hidden="true">
      <filter id="grain-noise">
        <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" stitchTiles="stitch" />
        <feColorMatrix values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 0.45 0" />
      </filter>
      <rect width="100%" height="100%" filter="url(#grain-noise)" />
    </svg>
  );
}

// Dark cinematic section with optional colored grainy gradient
export default function GrainedSection({ children, gradient, className = "" }) {
  const defaultGradient = "radial-gradient(ellipse at 70% 30%, rgba(255,107,53,0.5) 0%, transparent 55%), radial-gradient(ellipse at 20% 70%, rgba(76,82,255,0.4) 0%, transparent 55%)";
  return (
    <section className={`relative overflow-hidden bg-[#0A0A0B] text-white ${className}`}>
      <div className="absolute inset-0 opacity-90" style={{ background: gradient || defaultGradient }} />
      <GrainSVG />
      <div className="relative z-10">{children}</div>
    </section>
  );
}