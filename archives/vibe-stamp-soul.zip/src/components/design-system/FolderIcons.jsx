import React from "react";

/**
 * FolderIcons — pictos monoline pour chaque dossier de l'écosystème AIME®.
 * Tous en viewBox 24x24, stroke-based, cohérents avec AimaIcons.
 * Un picto par dossier-type — pas d'emoji, pas de Lucide générique.
 */

const ICONS = {
  // 🤍 MARIAGE
  "prestataires": ( // étoile à 4 branches (sceau d'artisan)
    <g>
      <path d="M12 3 L13.5 10.5 L21 12 L13.5 13.5 L12 21 L10.5 13.5 L3 12 L10.5 10.5 Z" />
    </g>
  ),
  "invites": ( // silhouettes liées (cercle de présences)
    <g>
      <circle cx="9" cy="9" r="2.5" />
      <circle cx="15" cy="9" r="2.5" />
      <path d="M5 19c0-2.8 1.8-5 4-5s4 2.2 4 5" />
      <path d="M11 19c0-2.8 1.8-5 4-5s4 2.2 4 5" />
    </g>
  ),
  "contrats": ( // plume (signature)
    <g>
      <path d="M5 19 L19 5" />
      <path d="M19 5 L17 11 L13 13 L11 11 L13 7 Z" />
      <path d="M5 19 L8 16" />
    </g>
  ),
  "photos": ( // cadre + soleil (témoin lumineux)
    <g>
      <rect x="3" y="6" width="18" height="14" rx="1.5" />
      <circle cx="12" cy="13" r="3" />
      <circle cx="17" cy="9.5" r="0.6" fill="currentColor" stroke="none" />
    </g>
  ),
  "lieux": ( // arche
    <g>
      <path d="M4 20 V11 a8 8 0 0 1 16 0 V20" />
      <path d="M4 20 H20" />
      <path d="M9 20 V14" />
      <path d="M15 20 V14" />
    </g>
  ),
  "sceaux": ( // cire fondue (l'unique)
    <g>
      <circle cx="12" cy="10" r="5" />
      <path d="M9 14 L8 21 L12 18 L16 21 L15 14" />
      <path d="M10 10 L14 10" />
    </g>
  ),

  // ⚖ MON CABINET
  "cabinet": ( // balance fine (droit, équilibre)
    <g>
      <path d="M12 4 V20" />
      <path d="M6 20 H18" />
      <path d="M5 9 H10 L7.5 14 Z" />
      <path d="M14 9 H19 L16.5 14 Z" />
      <path d="M5 9 L19 9" />
    </g>
  ),

  // 📜 LE REGISTRE
  "registre": ( // livre ouvert avec timbre
    <g>
      <path d="M3 6 H11 V19 H3 Z" />
      <path d="M13 6 H21 V19 H13 Z" />
      <path d="M3 6 Q7 4 11 6" />
      <path d="M13 6 Q17 4 21 6" />
      <circle cx="17" cy="13" r="1.6" />
    </g>
  ),

  // 🎭 INTERMITTENTS
  "cachets": ( // ticket dentelé
    <g>
      <path d="M3 9 V8 a1 1 0 0 1 1-1 H20 a1 1 0 0 1 1 1 V9 a2 2 0 0 0 0 4 V14 a1 1 0 0 1-1 1 H4 a1 1 0 0 1-1-1 V13 a2 2 0 0 0 0-4 Z" />
      <path d="M9 8 V14" strokeDasharray="1 1.5" />
    </g>
  ),
  "aem": ( // calendrier tamponné
    <g>
      <rect x="4" y="5" width="16" height="15" rx="1.5" />
      <path d="M4 9 H20" />
      <path d="M9 3 V7" />
      <path d="M15 3 V7" />
      <circle cx="15" cy="14" r="2.2" />
    </g>
  ),
  "audiens": ( // bouclier souple
    <g>
      <path d="M12 3 L20 6 V12 c0 4.5-3.5 7.5-8 9-4.5-1.5-8-4.5-8-9 V6 Z" />
      <path d="M9 12 L11 14 L15 10" />
    </g>
  ),
  "pole-emploi": ( // lettre cachetée
    <g>
      <rect x="3" y="6" width="18" height="13" rx="1.5" />
      <path d="M3 7 L12 13 L21 7" />
      <circle cx="18" cy="17" r="1.6" />
    </g>
  ),
  "fiscal": ( // pourcent encadré
    <g>
      <rect x="4" y="4" width="16" height="16" rx="1.5" />
      <circle cx="9" cy="10" r="1.5" />
      <circle cx="15" cy="14" r="1.5" />
      <path d="M16 9 L8 16" />
    </g>
  ),

  // 🌾 AGRICULTEURS
  "msa": ( // épi de blé
    <g>
      <path d="M12 4 V20" />
      <path d="M12 8 L8 6" />
      <path d="M12 8 L16 6" />
      <path d="M12 12 L8 10" />
      <path d="M12 12 L16 10" />
      <path d="M12 16 L8 14" />
      <path d="M12 16 L16 14" />
    </g>
  ),
  "bail": ( // parchemin
    <g>
      <path d="M5 4 H19 V18 a2 2 0 0 1-2 2 H7 a2 2 0 0 1-2-2 Z" />
      <path d="M8 8 H16" />
      <path d="M8 12 H16" />
      <path d="M8 16 H13" />
    </g>
  ),
  "aides": ( // main qui donne
    <g>
      <path d="M4 14 L8 10 L11 13 L15 9 L20 14" />
      <path d="M4 14 V19 H20 V14" />
      <path d="M12 4 V8" />
      <path d="M10 6 H14" />
    </g>
  ),

  // ♿ INCLUSIVE
  "mdph": ( // main ouverte
    <g>
      <path d="M9 11 V5 a1.5 1.5 0 0 1 3 0 V11" />
      <path d="M12 11 V4 a1.5 1.5 0 0 1 3 0 V11" />
      <path d="M15 11 V5 a1.5 1.5 0 0 1 3 0 V13" />
      <path d="M9 11 V8 a1.5 1.5 0 0 0-3 0 V15 c0 3 2 5 5 5 h2 c3 0 5-2 5-5" />
    </g>
  ),
  "lettres-rh": ( // courrier officiel
    <g>
      <rect x="4" y="5" width="16" height="14" rx="1" />
      <path d="M7 9 H17" />
      <path d="M7 12 H17" />
      <path d="M7 15 H13" />
    </g>
  ),

  // 🏛 MAIRIES
  "officialisation": ( // fronton à 3 colonnes
    <g>
      <path d="M3 8 L12 3 L21 8" />
      <path d="M5 8 V18" />
      <path d="M12 8 V18" />
      <path d="M19 8 V18" />
      <path d="M3 18 H21" />
      <path d="M3 20 H21" />
    </g>
  ),
  "ceremonie": ( // anneaux liés
    <g>
      <circle cx="9" cy="13" r="5" />
      <circle cx="15" cy="13" r="5" />
    </g>
  ),

  // 🌿 NOYAU
  "noyau": ( // goutte centrée
    <g>
      <path d="M12 3 C8 9 6 13 6 16 a6 6 0 0 0 12 0 c0-3-2-7-6-13 Z" />
      <circle cx="12" cy="15" r="1.5" />
    </g>
  ),

  // 🎵 MUSIC RIGHTS
  "music-rights": ( // note + sceau
    <g>
      <circle cx="9" cy="17" r="2.5" />
      <path d="M11.5 17 V6 L19 4 V15" />
      <circle cx="16.5" cy="15" r="2.5" />
    </g>
  ),

  // Fallback
  "default": (
    <g>
      <rect x="4" y="6" width="16" height="14" rx="1.5" />
      <path d="M4 10 H20" />
    </g>
  )
};

/**
 * FolderIcon — affiche le picto correspondant au dossier.
 * Props: name (clé), size, strokeWidth, className
 */
export default function FolderIcon({ name, size = 22, strokeWidth = 1.6, className = "" }) {
  const content = ICONS[name] || ICONS.default;
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      {content}
    </svg>
  );
}

export const FOLDER_ICON_NAMES = Object.keys(ICONS);