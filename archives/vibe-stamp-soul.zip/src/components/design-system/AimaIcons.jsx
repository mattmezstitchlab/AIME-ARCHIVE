import React from "react";

/**
 * AimaIcons — Custom monoline SVG icon set for AIME.
 * Stroke-based, 24x24 viewBox, configurable size & className.
 * Designed to feel modern, identitaire, non-kitsch (no stars, no flowers).
 *
 * Usage:
 *   <AimaIcon name="bond" size={18} className="text-white/80" />
 */

const ICONS = {
  // Two interlinked circles — symbol of the bond / couple
  bond: (
    <>
      <circle cx="9" cy="12" r="5" />
      <circle cx="15" cy="12" r="5" />
    </>
  ),
  // Sound wave / vibration — Aïma's voice
  voice: (
    <>
      <path d="M4 12h1.5" />
      <path d="M8 9v6" />
      <path d="M11 6v12" />
      <path d="M14 9v6" />
      <path d="M17 11v2" />
      <path d="M20 12h0" />
    </>
  ),
  // Soft note — music
  note: (
    <>
      <path d="M9 18V6l11-2v12" />
      <circle cx="6" cy="18" r="3" />
      <circle cx="17" cy="16" r="3" />
    </>
  ),
  // Calendar minimal
  calendar: (
    <>
      <rect x="4" y="5" width="16" height="16" rx="2" />
      <path d="M4 10h16" />
      <path d="M9 3v4" />
      <path d="M15 3v4" />
    </>
  ),
  // Speech bubble
  bubble: (
    <path d="M5 6h14a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-8l-4 3v-3H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2Z" />
  ),
  // Send arrow (modern, not paper plane)
  arrow: (
    <>
      <path d="M5 12h14" />
      <path d="m13 6 6 6-6 6" />
    </>
  ),
  // Plus
  plus: (
    <>
      <path d="M12 5v14" />
      <path d="M5 12h14" />
    </>
  ),
  // Attach (no clip kitsh)
  attach: (
    <path d="M12 4v12a4 4 0 0 1-8 0V8a3 3 0 0 1 6 0v8a2 2 0 0 1-4 0V8" />
  ),
  // Image
  image: (
    <>
      <rect x="3" y="5" width="18" height="14" rx="2" />
      <circle cx="9" cy="10" r="1.5" />
      <path d="m4 17 5-5 4 4 3-3 4 4" />
    </>
  ),
  // Microphone
  mic: (
    <>
      <rect x="9" y="3" width="6" height="11" rx="3" />
      <path d="M5 11a7 7 0 0 0 14 0" />
      <path d="M12 18v3" />
    </>
  ),
  // Sparkle (modern, replaces ✦) — small 4-point star
  spark: (
    <path d="M12 4l1.6 5.4L19 11l-5.4 1.6L12 18l-1.6-5.4L5 11l5.4-1.6Z" />
  ),
  // Compose / wand
  compose: (
    <>
      <path d="M4 20 18 6" />
      <path d="m15 3 3 3" />
      <path d="M9 5h0" />
      <path d="M5 9h0" />
      <path d="M19 13h0" />
    </>
  ),
  // Heart (minimal, not bombée)
  heart: (
    <path d="M12 19s-7-4.5-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 9c0 5.5-7 10-7 10Z" />
  ),
  // Memory / archive
  memory: (
    <>
      <rect x="3" y="4" width="18" height="6" rx="1.5" />
      <rect x="5" y="10" width="14" height="10" rx="1.5" />
      <path d="M10 14h4" />
    </>
  ),
  // Stamp / seal
  seal: (
    <>
      <circle cx="12" cy="10" r="6" />
      <path d="M5 21h14" />
      <path d="M9 16h6" />
    </>
  ),
  // Close
  close: (
    <>
      <path d="M6 6 18 18" />
      <path d="M18 6 6 18" />
    </>
  ),
  // Search / cmd-k
  search: (
    <>
      <circle cx="11" cy="11" r="6" />
      <path d="m20 20-4-4" />
    </>
  ),
  // Back arrow
  back: (
    <>
      <path d="M19 12H5" />
      <path d="m11 6-6 6 6 6" />
    </>
  ),
  // "Aïma peut" — cercle pulsé avec point central (présence, intelligence)
  sparkles: (
    <>
      <circle cx="12" cy="12" r="3" />
      <path d="M12 5v2" />
      <path d="M12 17v2" />
      <path d="M5 12h2" />
      <path d="M17 12h2" />
      <path d="m7 7 1.4 1.4" />
      <path d="m15.6 15.6 1.4 1.4" />
      <path d="m7 17 1.4-1.4" />
      <path d="m15.6 8.4 1.4-1.4" />
    </>
  ),
  // Folder stack — pile de dossiers (pour "Tes dossiers")
  folderStack: (
    <>
      <path d="M3 8a1.5 1.5 0 0 1 1.5-1.5h4l1.5 2h9A1.5 1.5 0 0 1 20.5 10v7A1.5 1.5 0 0 1 19 18.5H5A1.5 1.5 0 0 1 3.5 17V8Z" />
      <path d="M6 6.5V5A1.5 1.5 0 0 1 7.5 3.5h3l1.5 2h6" />
    </>
  ),
  // Magic wand — prestataires/recommandations
  wand: (
    <>
      <path d="M5 19 17 7" />
      <path d="m14 4 2 2" />
      <path d="m18 8 2 2" />
      <path d="M4 9h2" />
      <path d="M9 4v2" />
      <path d="M20 14h2" />
    </>
  ),
  // Picture mountains — photos plus défini
  picture: (
    <>
      <rect x="3" y="5" width="18" height="14" rx="2" />
      <circle cx="8.5" cy="10" r="1.4" />
      <path d="m3 17 5-5 4 4 3-3 6 6" />
    </>
  ),
  // Paperclip — attache plus précise
  paperclip: (
    <path d="M19 11 11 19a4 4 0 0 1-5.7-5.7L13 5.6a2.5 2.5 0 0 1 3.6 3.6l-7 7a1.2 1.2 0 0 1-1.7-1.7L14 8.5" />
  ),
  // Waveform — voix qualitative
  waveform: (
    <>
      <path d="M3 12h2" />
      <path d="M7 8v8" />
      <path d="M11 5v14" />
      <path d="M15 9v6" />
      <path d="M19 11v2" />
      <path d="M22 12h0" />
    </>
  ),
  // Expand — passer en plein écran
  expand: (
    <>
      <path d="M4 9V4h5" />
      <path d="M20 9V4h-5" />
      <path d="M4 15v5h5" />
      <path d="M20 15v5h-5" />
    </>
  ),
  // Collapse — sortir du plein écran
  collapse: (
    <>
      <path d="M9 4v5H4" />
      <path d="M15 4v5h5" />
      <path d="M9 20v-5H4" />
      <path d="M15 20v-5h5" />
    </>
  )
};

export default function AimaIcon({ name, size = 18, className = "", strokeWidth = 1.5 }) {
  const path = ICONS[name];
  if (!path) return null;
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      {path}
    </svg>
  );
}

export const AIMA_ICON_NAMES = Object.keys(ICONS);