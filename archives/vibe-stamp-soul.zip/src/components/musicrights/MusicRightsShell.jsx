import React from "react";

/**
 * MusicRightsShell — fond blanc/ivoire raffiné, ambiance musicale intime et sophistiquée.
 * Pas de cinématique. Typo DM Sans + Playfair pour les italiques et titres.
 */
export default function MusicRightsShell({ children }) {
  return (
    <div
      className="min-h-screen relative overflow-hidden"
      style={{
        background: "#FFFFFF",
        fontFamily: "'DM Sans', sans-serif",
        color: "#1A1208"
      }}
    >
      {/* Veines musicales très discrètes */}
      <div
        className="absolute inset-0 pointer-events-none opacity-[0.5]"
        style={{
          background:
            "repeating-linear-gradient(0deg, transparent 0 119px, rgba(184,154,82,0.04) 119px 120px)"
        }}
      />
      <div className="relative z-10">{children}</div>
    </div>
  );
}