import React from "react";
import { motion } from "framer-motion";

export default function MusicRightsProgress({ step, total }) {
  const pct = ((step - 1) / total) * 100;
  return (
    <div className="flex items-center gap-3 mb-10">
      <div className="flex-1 h-[2px] bg-[#B89A52]/15 rounded overflow-hidden">
        <motion.div
          className="h-full"
          style={{ background: "linear-gradient(90deg, #D4B483, #B89A52)" }}
          initial={{ width: 0 }}
          animate={{ width: `${pct}%` }}
          transition={{ duration: 0.5 }}
        />
      </div>
      <div className="text-[9px] tracking-[3px] text-[#8A7A60] uppercase whitespace-nowrap">
        {step} / {total}
      </div>
    </div>
  );
}