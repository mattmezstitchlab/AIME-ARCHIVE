import React from "react";
import { Link } from "react-router-dom";
import AimeLogoIcon from "@/components/universal/AimeLogoIcon";

/**
 * Header AIME® Music Rights — fin, blanc, avec accès Stamp et miniature Timbre.
 */
export default function MusicRightsHeader({ timbre }) {
  return (
    <header className="border-b border-[#B89A52]/15 bg-white/60 backdrop-blur-xl sticky top-0 z-40">
      <div className="max-w-5xl mx-auto px-6 py-4 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2.5 group">
          <AimeLogoIcon size={18} color="#1A1208" />
          <div className="leading-tight">
            <div className="text-[14px] font-semibold tracking-tight text-[#1A1208]">
              AIME<sup className="text-[8px] font-normal text-[#8A7A60] ml-0.5">®</sup>
              <span className="font-serif italic font-normal text-[#8A7A60] ml-1.5">Music Rights</span>
            </div>
            <div className="text-[10px] tracking-[0.18em] text-[#B89A52] uppercase">
              Le Droit à la Bulle
            </div>
          </div>
        </Link>

        <div className="flex items-center gap-3">
          <Link
            to="/registre"
            className="hidden sm:inline-flex text-[11px] tracking-[0.2em] uppercase text-[#4A3C28] hover:text-[#1A1208] transition-colors"
          >
            ← AIME Stamp
          </Link>
          {timbre && (
            <Link
              to="/timbre"
              title={`Timbre ${timbre.code}`}
              className="flex items-center gap-2 px-3 py-1.5 rounded-full border border-[#B89A52]/30 bg-[#FEFCF6] hover:bg-[#FAF6E8] transition-colors"
            >
              {timbre.portrait_url ? (
                <img
                  src={timbre.portrait_url}
                  alt=""
                  className="w-5 h-5 rounded-full object-cover border border-[#B89A52]/40"
                />
              ) : (
                <span className="w-5 h-5 rounded-full bg-[#F0E4C0] text-[#B89A52] flex items-center justify-center text-[9px] font-serif font-bold">
                  {(timbre.first_name?.[0] || "") + (timbre.last_name?.[0] || "")}
                </span>
              )}
              <span className="text-[10px] tracking-[0.15em] text-[#B89A52] font-medium">
                #{String(timbre.registry_n || 0).padStart(6, "0")}
              </span>
            </Link>
          )}
        </div>
      </div>
    </header>
  );
}