import React, { useState, useMemo } from "react";
import {
  COUNTRIES, SECTORS, POST_NATURES, ENVIRONMENTS, NEEDS, EQUIPMENTS, SITUATIONS
} from "@/lib/musicRightsData";

/* ─── UI helpers ─── */
const Question = ({ eyebrow, title, children }) => (
  <div>
    <div className="text-[10px] tracking-[4px] text-[#B89A52] uppercase mb-3">{eyebrow}</div>
    <h2 className="apple-headline text-[#1A1208] text-2xl md:text-3xl mb-7">
      {title}
    </h2>
    {children}
  </div>
);

const Choice = ({ active, onClick, label, desc }) => (
  <button
    type="button"
    onClick={onClick}
    className={`w-full text-left p-4 rounded-2xl border transition-all ${
      active
        ? "border-[#B89A52] bg-[#FEFAF0] shadow-[0_2px_8px_rgba(184,154,82,0.12)]"
        : "border-[#B89A52]/20 bg-white hover:border-[#B89A52]/50 hover:bg-[#FEFCF6]"
    }`}
  >
    <div className={`text-[14px] font-medium ${active ? "text-[#1A1208]" : "text-[#3A2E1A]"}`}>
      {label}
    </div>
    {desc && (
      <div className="text-[12px] text-[#8A7A60] mt-1 leading-relaxed">{desc}</div>
    )}
  </button>
);

/* ─── Étape 1 — Pays ─── */
export function Step1Country({ data, set }) {
  const [search, setSearch] = useState("");
  const filtered = useMemo(() => {
    const s = search.toLowerCase().trim();
    if (!s) return COUNTRIES;
    return COUNTRIES.filter((c) =>
      c.label.toLowerCase().includes(s) || c.code.toLowerCase().includes(s)
    );
  }, [search]);

  return (
    <Question eyebrow="Étape 1 / 7" title="Depuis quel pays travailles-tu ?">
      <input
        type="text"
        placeholder="Rechercher un pays…"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="w-full mb-3 px-4 py-3 rounded-xl border border-[#B89A52]/25 bg-white text-[14px] outline-none focus:border-[#B89A52]"
      />
      <div className="max-h-[280px] overflow-y-auto pr-1 space-y-1.5">
        {filtered.map((c) => (
          <button
            key={c.code}
            type="button"
            onClick={() => set({ country: c.code, country_label: c.label })}
            className={`w-full text-left flex items-center justify-between px-4 py-2.5 rounded-lg border transition-colors ${
              data.country === c.code
                ? "border-[#B89A52] bg-[#FEFAF0]"
                : "border-[#B89A52]/15 bg-white hover:bg-[#FEFCF6]"
            }`}
          >
            <span className="text-[13.5px] text-[#1A1208]">{c.label}</span>
            <span className="text-[10px] tracking-widest text-[#B89A52]">{c.code}</span>
          </button>
        ))}
      </div>
    </Question>
  );
}

/* ─── Étape 2 — Secteur ─── */
export function Step2Sector({ data, set }) {
  return (
    <Question eyebrow="Étape 2 / 7" title="Dans quel secteur travailles-tu ?">
      <div className="space-y-2">
        {SECTORS.map((s) => (
          <Choice
            key={s.id}
            label={s.label}
            desc={s.desc}
            active={data.sector === s.id}
            onClick={() => set({ sector: s.id })}
          />
        ))}
      </div>
    </Question>
  );
}

/* ─── Étape 3 — Poste ─── */
export function Step3Post({ data, set }) {
  return (
    <Question eyebrow="Étape 3 / 7" title="Quelle est la nature principale de ton poste ?">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
        {POST_NATURES.map((p) => (
          <Choice
            key={p.id}
            label={p.label}
            desc={p.desc}
            active={data.post_nature === p.id}
            onClick={() => set({ post_nature: p.id })}
          />
        ))}
      </div>
    </Question>
  );
}

/* ─── Étape 4 — Environnement ─── */
export function Step4Environment({ data, set }) {
  return (
    <Question eyebrow="Étape 4 / 7" title="Dans quel environnement travailles-tu ?">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
        {ENVIRONMENTS.map((e) => (
          <Choice
            key={e.id}
            label={e.label}
            desc={e.desc}
            active={data.environment === e.id}
            onClick={() => set({ environment: e.id })}
          />
        ))}
      </div>
    </Question>
  );
}

/* ─── Étape 5 — Besoins (multi) ─── */
export function Step5Needs({ data, set }) {
  const toggle = (id) => {
    const cur = data.needs || [];
    set({ needs: cur.includes(id) ? cur.filter((x) => x !== id) : [...cur, id] });
  };
  return (
    <Question eyebrow="Étape 5 / 7" title="Pourquoi la musique est-elle importante pour toi au travail ?">
      <p className="text-[12px] text-[#8A7A60] mb-4 -mt-4">Plusieurs choix possibles.</p>
      <div className="space-y-2">
        {NEEDS.map((n) => {
          const active = (data.needs || []).includes(n.id);
          return (
            <button
              key={n.id}
              type="button"
              onClick={() => toggle(n.id)}
              className={`w-full text-left p-4 rounded-2xl border transition-all flex items-start gap-3 ${
                active
                  ? "border-[#B89A52] bg-[#FEFAF0]"
                  : "border-[#B89A52]/20 bg-white hover:border-[#B89A52]/50 hover:bg-[#FEFCF6]"
              }`}
            >
              <div
                className={`mt-0.5 w-4 h-4 rounded border flex-shrink-0 flex items-center justify-center ${
                  active ? "bg-[#B89A52] border-[#B89A52]" : "border-[#B89A52]/40 bg-white"
                }`}
              >
                {active && (
                  <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="20 6 9 17 4 12" />
                  </svg>
                )}
              </div>
              <div>
                <div className="text-[14px] font-medium text-[#1A1208]">{n.label}</div>
                {n.desc && <div className="text-[12px] text-[#8A7A60] mt-0.5">{n.desc}</div>}
              </div>
            </button>
          );
        })}
      </div>
    </Question>
  );
}

/* ─── Étape 6 — Équipement ─── */
export function Step6Equipment({ data, set }) {
  return (
    <Question eyebrow="Étape 6 / 7" title="Quel équipement utilises-tu ou es-tu prêt·e à utiliser ?">
      <div className="space-y-2">
        {EQUIPMENTS.map((e) => (
          <Choice
            key={e.id}
            label={e.label}
            desc={e.desc}
            active={data.equipment === e.id}
            onClick={() => set({ equipment: e.id })}
          />
        ))}
      </div>
    </Question>
  );
}

/* ─── Étape 7 — Situation ─── */
export function Step7Situation({ data, set }) {
  return (
    <Question eyebrow="Étape 7 / 7" title="Quelle est ta situation aujourd'hui ?">
      <div className="space-y-2">
        {SITUATIONS.map((s) => (
          <Choice
            key={s.id}
            label={s.label}
            active={data.situation === s.id}
            onClick={() => set({ situation: s.id })}
          />
        ))}
      </div>
    </Question>
  );
}