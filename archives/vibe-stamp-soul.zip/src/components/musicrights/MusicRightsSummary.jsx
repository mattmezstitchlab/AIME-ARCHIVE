import React from "react";
import { motion } from "framer-motion";
import {
  labelFor, labelForCountry, SECTORS, POST_NATURES, ENVIRONMENTS, NEEDS, EQUIPMENTS, SITUATIONS
} from "@/lib/musicRightsData";

const ICONS = {
  country: "🌐",
  sector: "◇",
  post: "✦",
  env: "◈",
  needs: "♪",
  equipment: "◐",
  situation: "✧"
};

const Cell = ({ icon, label, value }) => (
  <div className="rounded-2xl border border-[#B89A52]/20 bg-white p-4">
    <div className="text-[18px] mb-1.5 text-[#B89A52]" style={{ fontFamily: "'Playfair Display', serif" }}>
      {icon}
    </div>
    <div className="text-[9px] tracking-[2.5px] text-[#8A7A60] uppercase mb-1">{label}</div>
    <div className="text-[13px] text-[#1A1208] leading-tight">{value}</div>
  </div>
);

export default function MusicRightsSummary({ data, onGenerate, onShare, generating }) {
  const needsLabels = (data.needs || []).map((id) => labelFor(NEEDS, id)).join(" · ") || "—";

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <div className="text-center mb-8">
        <div className="text-[10px] tracking-[5px] text-[#B89A52] uppercase mb-3">
          Synthèse de ton profil
        </div>
        <h1 className="apple-headline text-[#1A1208] text-3xl md:text-4xl mb-3">
          Votre <span className="text-[#B89A52]">Droit à la Bulle</span>
          <br />
          est prêt.
        </h1>
        <p className="text-[13px] text-[#4A3C28] max-w-md mx-auto leading-relaxed">
          Une attestation officielle, juridiquement argumentée, scientifiquement étayée — tissée à partir de vos réponses.
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-8">
        <Cell icon={ICONS.country} label="Pays" value={labelForCountry(data.country)} />
        <Cell icon={ICONS.sector} label="Secteur" value={labelFor(SECTORS, data.sector)} />
        <Cell icon={ICONS.post} label="Poste" value={labelFor(POST_NATURES, data.post_nature)} />
        <Cell icon={ICONS.env} label="Environnement" value={labelFor(ENVIRONMENTS, data.environment)} />
        <Cell icon={ICONS.equipment} label="Équipement" value={labelFor(EQUIPMENTS, data.equipment)} />
        <Cell icon={ICONS.situation} label="Situation" value={labelFor(SITUATIONS, data.situation)} />
      </div>

      <div className="rounded-2xl bg-[#FEFAF0] border border-[#B89A52]/25 p-4 mb-8">
        <div className="flex items-start gap-2.5">
          <span className="text-[#B89A52] text-[16px] mt-0.5">♪</span>
          <div>
            <div className="text-[10px] tracking-[2.5px] text-[#8A7A60] uppercase mb-1">Tes besoins</div>
            <div className="text-[13px] text-[#1A1208] leading-relaxed">{needsLabels}</div>
          </div>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-3 justify-center">
        <button
          onClick={onGenerate}
          disabled={generating}
          className="px-9 py-4 rounded-full bg-[#1A1208] text-[#F0E6C8] text-[10px] tracking-[3px] uppercase hover:bg-[#B89A52] hover:text-[#1A1208] transition-colors disabled:opacity-50"
        >
          {generating ? "Génération…" : "Générer mon attestation PDF ✦"}
        </button>
        <button
          onClick={onShare}
          className="px-9 py-4 rounded-full border border-[#B89A52]/40 text-[#4A3C28] text-[10px] tracking-[3px] uppercase hover:bg-[#FEFAF0] transition-colors"
        >
          Partager mon profil musical
        </button>
      </div>
    </motion.div>
  );
}