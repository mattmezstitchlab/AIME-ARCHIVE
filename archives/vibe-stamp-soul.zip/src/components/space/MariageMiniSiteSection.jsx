import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { getAnonymousId } from "@/lib/aimaSession";
import EditableText from "@/components/edit/EditableText";

const ACCENT = "#D4A574";

/**
 * MariageMiniSiteSection — section dédiée au mini-site du couple,
 * insérée dans la page Union (Mariage). Présente le concept et permet
 * de créer un mini-site (terrain de jeu libre) ou de voir l'exemple.
 */
export default function MariageMiniSiteSection() {
  const navigate = useNavigate();
  const [creating, setCreating] = useState(false);

  const handleCreate = async () => {
    setCreating(true);
    // génère un slug court et unique
    const slug = "essai-" + Math.random().toString(36).slice(2, 8);
    try {
      await base44.entities.MiniSite.create({
        slug,
        anonymous_id: getAnonymousId(),
        couple_names: "Vous deux",
        intro_title: "Vous deux,",
        intro_italic: "et tout ce qui le tient ensemble.",
        intro_text: "Bienvenue. Ce mini-site est notre cadeau — un lieu pour vous, à notre rythme.",
        accent_color: ACCENT,
        sections: [
          { id: Math.random().toString(36).slice(2, 10), kind: "text", title: "Notre histoire", body: "Écris ici l'histoire qui vous a menés jusqu'à ce jour." },
          { id: Math.random().toString(36).slice(2, 10), kind: "info", title: "Le jour J · infos pratiques", body: "Lieu, horaires, dress code, parking…" }
        ],
        published: false
      });
      navigate(`/u/${slug}/edit`);
    } catch (_) {
      navigate(`/u/${slug}/edit`);
    }
  };

  return (
    <section className="relative bg-[#0A0A0B] py-24 md:py-32 px-6 border-t border-white/5">
      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Mockup */}
          <motion.div
            initial={{ opacity: 0, scale: 0.96 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.7 }}
            className="relative"
          >
            <div className="relative aspect-[4/5] rounded-3xl overflow-hidden border border-white/10 shadow-[0_30px_80px_rgba(0,0,0,0.6)]">
              <img
                src="https://res.cloudinary.com/divou1vcx/image/upload/v1777698965/pexels-rothemba-vele-1414849-18041569_pps4us.jpg"
                alt=""
                className="absolute inset-0 w-full h-full object-cover"
              />
              <div
                className="absolute inset-0"
                style={{
                  background:
                    "linear-gradient(180deg, rgba(0,0,0,0.35) 0%, rgba(0,0,0,0) 45%, rgba(10,10,11,0.92) 100%)"
                }}
              />
              <div className="absolute inset-0 flex flex-col justify-end p-8 md:p-10">
                <div className="font-sans text-[10px] tracking-[0.35em] uppercase mb-3" style={{ color: ACCENT }}>
                  Léa & Marc
                </div>
                <h3 className="apple-headline text-white text-2xl md:text-3xl">
                  Vous deux,<br />
                  <span className="text-white/75">et tout ce qui le tient ensemble.</span>
                </h3>
                <div className="mt-4 font-serif italic text-white/70 text-[14px] leading-snug">
                  « Bienvenue. Ce mini-site est notre cadeau. »
                </div>
              </div>
            </div>
            <div className="mt-3 text-center text-white/40 text-[11px] tracking-[0.2em] uppercase font-sans">
              Aperçu · /u/lea-marc
            </div>
          </motion.div>

          {/* Texte */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.6, delay: 0.1 }}
          >
            <div className="font-sans text-[11px] tracking-[0.3em] uppercase mb-4" style={{ color: ACCENT }}>
              <EditableText slug="mariage.minisite.eyebrow" label="Mini-site — eyebrow" page="/mariage" as="span" defaultValue="03 · Le mini-site" />
            </div>
            <h3 className="apple-headline text-white text-3xl md:text-4xl">
              <EditableText slug="mariage.minisite.title" label="Mini-site — titre" page="/mariage" as="span" defaultValue="Une page-cadeau," />
              <br />
              <span className="text-white/70">
                <EditableText slug="mariage.minisite.italic" label="Mini-site — italique" page="/mariage" as="span" defaultValue="rien qu'à vous." />
              </span>
            </h3>
            <p className="mt-5 font-sans text-white/65 text-[15px] leading-relaxed">
              <EditableText
                slug="mariage.minisite.description"
                label="Mini-site — description"
                page="/mariage"
                as="span"
                defaultValue="Un lieu privé pour les invités. Vous le composez librement — texte, photos, citations, infos jour J, playlist, livre d'or. Personnalisable à l'infini, sauvegardé automatiquement. Vous payez seulement quand vous décidez de l'ouvrir aux invités."
              />
            </p>

            <ul className="mt-6 space-y-3">
              {[
                "Création immédiate · pas de compte requis",
                "Cliquez sur n'importe quel élément pour le modifier",
                "Auto-save · vous reprenez quand vous voulez",
                "Paiement uniquement à la publication"
              ].map((b, i) => (
                <li key={b} className="flex items-start gap-3 text-white/75 text-[14px] font-sans leading-relaxed">
                  <span className="mt-2 w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ backgroundColor: ACCENT }} />
                  <EditableText slug={`mariage.minisite.bullet.${i}`} label={`Mini-site — point ${i + 1}`} page="/mariage" as="span" defaultValue={b} />
                </li>
              ))}
            </ul>

            <div className="mt-9 flex flex-wrap items-center gap-3">
              <button
                onClick={handleCreate}
                disabled={creating}
                className="px-7 py-3 rounded-full text-[11px] tracking-[0.25em] uppercase font-medium transition-all hover:scale-[1.02] disabled:opacity-50"
                style={{ background: ACCENT, color: "#1A1208" }}
              >
                {creating ? "Création…" : "Créer mon mini-site"}
              </button>
              <Link
                to="/u/lea-marc/edit"
                className="px-6 py-3 rounded-full border text-[11px] tracking-[0.25em] uppercase text-white/65 hover:text-white border-white/20 hover:border-white/40 transition-colors"
              >
                Voir un exemple
              </Link>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}