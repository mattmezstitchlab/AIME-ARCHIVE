import React from "react";
import { motion } from "framer-motion";
import { useLocation } from "react-router-dom";
import EditableText from "@/components/edit/EditableText";

/**
 * SpaceFeatureSection — Section sobre pour présenter une fonctionnalité.
 * Tous les textes sont éditables via le drawer admin (slug auto-dérivé).
 */
export default function SpaceFeatureSection({
  eyebrow,
  title,
  italic,
  description,
  accent = "#D4A574",
  reverse = false,
  visual,
  bullets = [],
  slugBase
}) {
  const location = useLocation();
  // slug stable : route + eyebrow normalisé (ex: mariage.feature.01_l_echo)
  const ebSlug = (eyebrow || title || "feature")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/(^_|_$)/g, "")
    .slice(0, 40);
  const base =
    slugBase ||
    `${(location.pathname.replace(/^\//, "").replace(/\//g, ".") || "home")}.feature.${ebSlug}`;
  return (
    <section className="relative py-20 md:py-24 px-6 border-t border-white/5">
      <div className="max-w-6xl mx-auto">
        <div
          className={`grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center ${
            reverse ? "lg:[&>*:first-child]:order-2" : ""
          }`}
        >
          {/* Visuel */}
          <motion.div
            initial={{ opacity: 0, scale: 0.96 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.6 }}
          >
            {visual}
          </motion.div>

          {/* Texte */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.6, delay: 0.1 }}
          >
            {eyebrow && (
              <div
                className="font-sans text-[11px] tracking-[0.3em] uppercase mb-4"
                style={{ color: accent }}
              >
                <EditableText slug={`${base}.eyebrow`} label="Feature — eyebrow" page={location.pathname} as="span" defaultValue={eyebrow} />
              </div>
            )}
            <h3 className="apple-headline text-white text-3xl md:text-4xl">
              <EditableText slug={`${base}.title`} label="Feature — titre" page={location.pathname} as="span" defaultValue={title} />
              <br />
              <span className="text-white/70">
                <EditableText slug={`${base}.italic`} label="Feature — italique" page={location.pathname} as="span" defaultValue={italic} />
              </span>
            </h3>
            {description && (
              <p className="mt-5 font-sans text-white/65 text-[15px] leading-relaxed">
                <EditableText slug={`${base}.description`} label="Feature — description" page={location.pathname} as="span" defaultValue={description} />
              </p>
            )}
            {bullets.length > 0 && (
              <ul className="mt-6 space-y-3">
                {bullets.map((b, i) => (
                  <li
                    key={b}
                    className="flex items-start gap-3 text-white/75 text-[14px] font-sans leading-relaxed"
                  >
                    <span
                      className="mt-2 w-1.5 h-1.5 rounded-full flex-shrink-0"
                      style={{ backgroundColor: accent }}
                    />
                    <span>
                      <EditableText slug={`${base}.bullet.${i}`} label={`Feature — point ${i + 1}`} page={location.pathname} as="span" defaultValue={b} />
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </motion.div>
        </div>
      </div>
    </section>
  );
}