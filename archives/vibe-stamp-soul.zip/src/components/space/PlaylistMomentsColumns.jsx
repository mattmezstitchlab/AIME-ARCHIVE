import React from "react";
import { motion } from "framer-motion";

/**
 * PlaylistMomentsColumns — Colonnes par moment du jour J avec scroll vertical.
 * Affiche le top des titres déposés par les invités sur AIME®, alignés par moment :
 * arrivée, cérémonie, cocktail, dîner, ouverture, bal, nuit.
 */

const MOMENTS = [
  {
    moment: "Arrivée",
    icon: "✦",
    songs: [
      { t: "Here Comes The Sun", a: "The Beatles", count: 1284 },
      { t: "La Vie en Rose", a: "Édith Piaf", count: 982 },
      { t: "Cornelia Street", a: "Taylor Swift", count: 651 },
      { t: "Lovely Day", a: "Bill Withers", count: 542 },
      { t: "Banana Pancakes", a: "Jack Johnson", count: 487 },
      { t: "Three Little Birds", a: "Bob Marley", count: 412 },
      { t: "Better Together", a: "Jack Johnson", count: 378 },
      { t: "I Will", a: "The Beatles", count: 301 }
    ]
  },
  {
    moment: "Cérémonie",
    icon: "◇",
    songs: [
      { t: "All of Me", a: "John Legend", count: 2104 },
      { t: "A Thousand Years", a: "Christina Perri", count: 1792 },
      { t: "Mariage d'Amour", a: "Paul de Senneville", count: 1118 },
      { t: "Marry You", a: "Bruno Mars", count: 902 },
      { t: "Canon in D", a: "Pachelbel", count: 854 },
      { t: "La Vie en Rose", a: "Louis Armstrong", count: 721 },
      { t: "Make You Feel My Love", a: "Adele", count: 658 },
      { t: "Hallelujah", a: "Jeff Buckley", count: 612 }
    ]
  },
  {
    moment: "Cocktail",
    icon: "♪",
    songs: [
      { t: "Cheek to Cheek", a: "Ella Fitzgerald", count: 894 },
      { t: "L'Été Indien", a: "Joe Dassin", count: 712 },
      { t: "Sway", a: "Michael Bublé", count: 603 },
      { t: "Fly Me to the Moon", a: "Frank Sinatra", count: 581 },
      { t: "La Bohème", a: "Charles Aznavour", count: 498 },
      { t: "What a Wonderful World", a: "Louis Armstrong", count: 467 },
      { t: "Beyond the Sea", a: "Bobby Darin", count: 392 },
      { t: "Volare", a: "Dean Martin", count: 354 }
    ]
  },
  {
    moment: "Dîner",
    icon: "◈",
    songs: [
      { t: "Comptine d'un autre été", a: "Yann Tiersen", count: 982 },
      { t: "Clair de Lune", a: "Debussy", count: 821 },
      { t: "Gymnopédie n°1", a: "Erik Satie", count: 745 },
      { t: "River Flows in You", a: "Yiruma", count: 698 },
      { t: "The Scientist", a: "Coldplay", count: 612 },
      { t: "Skinny Love", a: "Bon Iver", count: 558 },
      { t: "Yesterday", a: "The Beatles", count: 489 },
      { t: "Hometown Glory", a: "Adele", count: 421 }
    ]
  },
  {
    moment: "Ouverture",
    icon: "✧",
    songs: [
      { t: "Perfect", a: "Ed Sheeran", count: 3201 },
      { t: "At Last", a: "Etta James", count: 1456 },
      { t: "Can't Help Falling in Love", a: "Elvis Presley", count: 1289 },
      { t: "Thinking Out Loud", a: "Ed Sheeran", count: 1102 },
      { t: "All My Life", a: "K-Ci & JoJo", count: 894 },
      { t: "I Don't Want to Miss a Thing", a: "Aerosmith", count: 782 },
      { t: "From This Moment On", a: "Shania Twain", count: 654 },
      { t: "Truly Madly Deeply", a: "Savage Garden", count: 521 }
    ]
  },
  {
    moment: "Bal",
    icon: "◐",
    songs: [
      { t: "Uptown Funk", a: "Bruno Mars", count: 2845 },
      { t: "I Wanna Dance with Somebody", a: "Whitney Houston", count: 2412 },
      { t: "September", a: "Earth, Wind & Fire", count: 2189 },
      { t: "I Will Survive", a: "Gloria Gaynor", count: 1987 },
      { t: "Y.M.C.A.", a: "Village People", count: 1854 },
      { t: "Dancing in the Moonlight", a: "Toploader", count: 1612 },
      { t: "Don't Stop Believin'", a: "Journey", count: 1534 },
      { t: "Footloose", a: "Kenny Loggins", count: 1298 }
    ]
  },
  {
    moment: "Nuit",
    icon: "☾",
    songs: [
      { t: "Don't Stop Me Now", a: "Queen", count: 4012 },
      { t: "Mr. Brightside", a: "The Killers", count: 2891 },
      { t: "Dancing Queen", a: "ABBA", count: 2734 },
      { t: "Sweet Caroline", a: "Neil Diamond", count: 2456 },
      { t: "Bohemian Rhapsody", a: "Queen", count: 2189 },
      { t: "Living on a Prayer", a: "Bon Jovi", count: 1987 },
      { t: "Wonderwall", a: "Oasis", count: 1854 },
      { t: "Africa", a: "Toto", count: 1721 }
    ]
  }
];

export default function PlaylistMomentsColumns({ accent = "#2DBE94" }) {
  const max = Math.max(...MOMENTS.flatMap((m) => m.songs.map((s) => s.count)));

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
      {MOMENTS.map((m, i) => (
        <motion.div
          key={m.moment}
          initial={{ opacity: 0, y: 10 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.05 + i * 0.05 }}
          className="rounded-2xl bg-white/[0.03] border border-white/10 p-4 flex flex-col"
          style={{ height: 360 }}
        >
          {/* En-tête colonne */}
          <div className="flex items-center gap-2 mb-3 pb-3 border-b border-white/10 flex-shrink-0">
            <div
              className="w-7 h-7 rounded-lg flex items-center justify-center text-[14px] font-serif"
              style={{ backgroundColor: `${accent}22`, color: accent }}
            >
              {m.icon}
            </div>
            <div className="text-white/90 text-[12px] font-medium">{m.moment}</div>
          </div>

          {/* Liste scrollable */}
          <div
            className="flex-1 overflow-y-auto space-y-3 pr-1 -mr-1 custom-scrollbar"
            style={{ scrollbarWidth: "thin", scrollbarColor: `${accent}55 transparent` }}
          >
            {m.songs.map((s, k) => (
              <div key={s.t}>
                <div className="flex items-baseline justify-between gap-1.5 mb-1">
                  <div className="text-white/85 text-[11.5px] font-medium truncate leading-tight">
                    {s.t}
                  </div>
                  <div
                    className="text-[9.5px] flex-shrink-0 font-medium"
                    style={{ color: accent }}
                  >
                    {s.count.toLocaleString("fr-FR")}
                  </div>
                </div>
                <div className="text-white/45 text-[10px] truncate mb-1">{s.a}</div>
                <div className="h-0.5 rounded-full bg-white/10 overflow-hidden">
                  <div
                    className="h-full rounded-full"
                    style={{
                      width: `${(s.count / max) * 100}%`,
                      backgroundColor: accent,
                      opacity: 0.6 + (1 - k / m.songs.length) * 0.4
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      ))}
    </div>
  );
}