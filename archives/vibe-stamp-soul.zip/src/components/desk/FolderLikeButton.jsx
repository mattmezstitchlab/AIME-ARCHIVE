import React from "react";
import { motion } from "framer-motion";

/**
 * FolderLikeButton — Petit cœur blanc en haut à droite d'un dossier.
 * Au clic : pulse + arrête la propagation (le clic ne déplie pas le dossier).
 * Le parent reçoit `onLike(e)` et déclenche son propre swipe Tinder-like.
 */
export default function FolderLikeButton({ liked = false, onLike, size = "sm" }) {
  const dim = size === "xs" ? 22 : size === "lg" ? 36 : 30;
  const offset = size === "xs" ? 5 : size === "lg" ? 10 : 7;

  const handleClick = (e) => {
    e.stopPropagation();
    e.preventDefault();
    onLike?.(e);
  };

  return (
    <motion.button
      type="button"
      onClick={handleClick}
      whileTap={{ scale: 0.85 }}
      whileHover={{ scale: 1.15 }}
      className="absolute z-20 flex items-center justify-center rounded-full"
      style={{
        top: offset,
        right: offset,
        width: dim,
        height: dim,
        background: liked ? "rgba(239,68,68,0.95)" : "rgba(255,255,255,0.95)",
        boxShadow: "0 1px 3px rgba(0,0,0,0.25), 0 0 0 1px rgba(0,0,0,0.06)",
        backdropFilter: "blur(4px)"
      }}
      aria-label={liked ? "Retiré du panier Aïma" : "Envoyer à Aïma"}
    >
      <svg
        width={dim * 0.6}
        height={dim * 0.6}
        viewBox="0 0 24 24"
        fill={liked ? "white" : "none"}
        stroke={liked ? "white" : "#ef4444"}
        strokeWidth="2.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M12 19s-7-4.5-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 9c0 5.5-7 10-7 10Z" />
      </svg>
    </motion.button>
  );
}