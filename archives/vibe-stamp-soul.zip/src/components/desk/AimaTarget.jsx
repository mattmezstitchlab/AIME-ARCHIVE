import React from "react";
import { motion } from "framer-motion";

/**
 * AimaTarget — La cible centrale du bureau.
 * Cercle avec un "+" qui pulse pour indiquer la zone d'ajout.
 * Quand un dossier est dragué dessus, l'anneau s'épaissit et le + grandit.
 */
export default function AimaTarget({ active = false, count = 0 }) {
  return (
    <motion.div
      initial={{ scale: 0.9, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      className="relative flex items-center justify-center"
      style={{ width: 200, height: 200 }}
    >
      {/* Anneaux pulsants concentriques */}
      {[0, 1, 2].map((i) => (
        <motion.div
          key={i}
          className="absolute rounded-full pointer-events-none"
          style={{
            width: 140,
            height: 140,
            border: "1px solid rgba(212,180,131,0.45)"
          }}
          animate={{
            scale: active ? [1, 1.6, 2.0] : [1, 1.35, 1.7],
            opacity: [0.6, 0.2, 0]
          }}
          transition={{
            duration: active ? 1.2 : 2.4,
            repeat: Infinity,
            delay: i * (active ? 0.4 : 0.8),
            ease: "easeOut"
          }}
        />
      ))}

      {/* Halo arc-en-ciel doux */}
      <motion.div
        className="absolute rounded-full pointer-events-none"
        style={{
          width: 180,
          height: 180,
          background:
            "conic-gradient(from 0deg, rgba(232,93,93,0.20), rgba(232,201,93,0.20), rgba(157,201,93,0.20), rgba(93,201,180,0.20), rgba(93,157,201,0.20), rgba(157,93,201,0.20), rgba(201,93,157,0.20), rgba(232,93,93,0.20))",
          filter: "blur(24px)"
        }}
        animate={{ rotate: 360 }}
        transition={{ duration: 24, repeat: Infinity, ease: "linear" }}
      />

      {/* Cercle central — la cible */}
      <motion.div
        animate={{
          scale: active ? [1, 1.12, 1] : [1, 1.04, 1],
          boxShadow: active
            ? [
                "0 0 0 0 rgba(212,180,131,0.45)",
                "0 0 0 24px rgba(212,180,131,0)",
                "0 0 0 0 rgba(212,180,131,0)"
              ]
            : [
                "0 0 0 0 rgba(212,180,131,0.25)",
                "0 0 0 14px rgba(212,180,131,0)",
                "0 0 0 0 rgba(212,180,131,0)"
              ]
        }}
        transition={{ duration: active ? 0.9 : 2.2, repeat: Infinity, ease: "easeOut" }}
        className="relative rounded-full flex items-center justify-center backdrop-blur-md"
        style={{
          width: active ? 110 : 100,
          height: active ? 110 : 100,
          background: "radial-gradient(circle at 35% 30%, rgba(255,255,255,0.10), rgba(0,0,0,0.35))",
          border: `${active ? 2 : 1.5}px solid ${active ? "#E7D5A8" : "rgba(212,180,131,0.65)"}`,
          color: active ? "#FFE9B8" : "rgba(231,213,168,0.90)"
        }}
      >
        {/* Anneau intérieur */}
        <span
          className="absolute rounded-full pointer-events-none"
          style={{ inset: 8, border: "0.5px solid rgba(212,180,131,0.40)" }}
        />

        {/* Icône + */}
        <motion.svg
          width={active ? 44 : 38}
          height={active ? 44 : 38}
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth={1.6}
          strokeLinecap="round"
        >
          <line x1="12" y1="5" x2="12" y2="19" />
          <line x1="5" y1="12" x2="19" y2="12" />
        </motion.svg>

        {/* Pastille count */}
        {count > 0 && (
          <motion.span
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className="absolute -top-1 -right-1 min-w-[24px] h-6 px-2 rounded-full flex items-center justify-center text-[12px] font-medium font-sans"
            style={{
              background: "#E85D5D",
              color: "white",
              border: "2px solid #0A0A0B",
              boxShadow: "0 4px 12px rgba(232,93,93,0.45)"
            }}
          >
            {count}
          </motion.span>
        )}
      </motion.div>

      {/* Étiquette "Aïma" en arc */}
      <svg
        className="absolute pointer-events-none"
        width="200"
        height="200"
        viewBox="0 0 200 200"
        aria-hidden="true"
      >
        <defs>
          <path id="aima-target-arc" d="M 30 100 A 70 70 0 0 1 170 100" fill="none" />
        </defs>
        <text
          fill="rgba(212,180,131,0.65)"
          style={{ fontSize: 9, letterSpacing: "0.5em", fontFamily: "var(--font-sans)", fontWeight: 500 }}
        >
          <textPath href="#aima-target-arc" startOffset="50%" textAnchor="middle">
            AÏMA · POSE TES DOSSIERS
          </textPath>
        </text>
      </svg>
    </motion.div>
  );
}