import React from "react";

/**
 * RainbowBackground — Fond blanc lumineux aéré, façon landing Apple/Coffee.
 * Une lumière qui contient toutes les nuances, mais en très doux pastel sur blanc.
 */
export default function RainbowBackground() {
  return (
    <div className="fixed inset-0 -z-10 overflow-hidden pointer-events-none">
      {/* Blanc-crème lumineux */}
      <div className="absolute inset-0 bg-[#FAFAF7]" />

      {/* Pastels arc-en-ciel très doux qui flottent */}
      <div
        className="absolute -inset-32 opacity-[0.45]"
        style={{
          background: `
            radial-gradient(ellipse 50% 40% at 15% 20%, rgba(255,180,180,0.35) 0%, transparent 65%),
            radial-gradient(ellipse 45% 35% at 85% 25%, rgba(200,230,180,0.30) 0%, transparent 65%),
            radial-gradient(ellipse 40% 40% at 85% 80%, rgba(210,190,235,0.32) 0%, transparent 65%),
            radial-gradient(ellipse 50% 35% at 18% 82%, rgba(180,210,235,0.30) 0%, transparent 65%),
            radial-gradient(ellipse 60% 50% at 50% 50%, rgba(255,235,200,0.25) 0%, transparent 75%)
          `,
          animation: "rainbow-drift 32s ease-in-out infinite alternate",
          filter: "blur(70px)"
        }}
      />

      {/* Voile blanc pour garder la respiration */}
      <div className="absolute inset-0 bg-white/30" />

      <style>{`
        @keyframes rainbow-drift {
          0%   { transform: translate(0, 0) rotate(0deg); }
          50%  { transform: translate(-3%, 2%) rotate(2deg); }
          100% { transform: translate(2%, -2%) rotate(-2deg); }
        }
      `}</style>
    </div>
  );
}