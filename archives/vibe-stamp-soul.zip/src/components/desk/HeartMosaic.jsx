import React, { useState, useMemo } from "react";
import { motion } from "framer-motion";
import FolderWithFan from "./FolderWithFan";
import { DESK_FOLDERS } from "@/lib/deskFolders";
import { buildHeartForCount } from "@/lib/heartLayout";
import { getDocsFor } from "@/lib/folderDocs";

/**
 * HeartMosaic — Les 25 dossiers disposés en cœur.
 * Chaque dossier en taille sm. Clic → s'agrandit + fait sortir
 * de petits documents en éventail (titre par doc).
 */
export default function HeartMosaic() {
  const [expandedId, setExpandedId] = useState(null);

  const layout = useMemo(() => {
    const cells = buildHeartForCount(DESK_FOLDERS.length);
    return DESK_FOLDERS.map((f, i) => ({
      folder: f,
      cell: cells[i] || { col: 0, row: 0 }
    }));
  }, []);

  // Recadrer aux cellules réellement utilisées (la grille théorique peut avoir
  // des colonnes/lignes vides à gauche ou en haut → on shift pour coller à 0)
  const minCol = Math.min(...layout.map((l) => l.cell.col));
  const minRow = Math.min(...layout.map((l) => l.cell.row));
  const maxCol = Math.max(...layout.map((l) => l.cell.col));
  const maxRow = Math.max(...layout.map((l) => l.cell.row));
  const cols = maxCol - minCol + 1;
  const rows = maxRow - minRow + 1;

  // Cellule en pixels — sm folder = ~130px, on prévoit 145 par cellule
  const cellW = 145;
  const cellH = 130;

  return (
    <div className="relative w-full flex justify-center">
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
        className="relative mx-auto"
        style={{
          width: cols * cellW,
          height: rows * cellH,
          maxWidth: "100%"
        }}
      >
        {layout.map(({ folder, cell }) => {
          const isExpanded = expandedId === folder.id;
          return (
            <div
              key={folder.id}
              className="absolute flex items-center justify-center"
              style={{
                left: (cell.col - minCol) * cellW,
                top: (cell.row - minRow) * cellH,
                width: cellW,
                height: cellH,
                zIndex: isExpanded ? 30 : 1
              }}
            >
              <FolderWithFan
                folder={folder}
                docs={getDocsFor(folder.id)}
                expanded={isExpanded}
                onToggle={() =>
                  setExpandedId((cur) => (cur === folder.id ? null : folder.id))
                }
              />
            </div>
          );
        })}
      </motion.div>
    </div>
  );
}