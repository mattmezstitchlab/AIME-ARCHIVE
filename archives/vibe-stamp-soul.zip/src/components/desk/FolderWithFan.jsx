import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import FolderCard from "@/components/universal/FolderCard";
import FolderLikeButton from "./FolderLikeButton";
import { addToBasket, readBasket } from "@/lib/deskBasket";

/**
 * FolderWithFan — Un dossier qui s'agrandit au clic et fait sortir
 * des petits documents en éventail, chacun avec un titre.
 *
 * Props :
 *   folder    : { id, name, palette, count }
 *   docs      : [{ id, title }] — petits documents qui sortent
 *   expanded  : boolean — contrôlé par parent
 *   onToggle  : () => void
 */
export default function FolderWithFan({ folder, docs = [], expanded, onToggle }) {
  const fanCount = Math.min(docs.length, 6);
  const [liked, setLiked] = useState(() => readBasket().includes(folder.id));
  const [swiping, setSwiping] = useState(false);

  const handleLike = () => {
    if (liked || swiping) return;
    setSwiping(true);
    setLiked(true);
    addToBasket(folder.id);
    // Après l'animation de swipe, on revient en place (le dossier reste cœur rouge)
    setTimeout(() => setSwiping(false), 650);
  };

  return (
    <motion.div
      className="relative inline-flex items-center justify-center"
      animate={
        swiping
          ? { x: 220, y: -40, rotate: 18, opacity: 0 }
          : { x: 0, y: 0, rotate: 0, opacity: 1 }
      }
      transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
      onAnimationComplete={() => {
        // Reset visuel après le swipe pour que le dossier reste en place
        if (!swiping && liked) {
          // rien — le state est déjà ok
        }
      }}
    >
      {/* Éventail de documents — sort de derrière le dossier */}
      <AnimatePresence>
        {expanded &&
          docs.slice(0, fanCount).map((doc, i) => {
            // Angle réparti de -55° à +55°
            const angle = -55 + (110 / Math.max(fanCount - 1, 1)) * i;
            const distance = 110;
            return (
              <motion.div
                key={doc.id}
                initial={{ opacity: 0, scale: 0.4, x: 0, y: 0, rotate: 0 }}
                animate={{
                  opacity: 1,
                  scale: 1,
                  x: Math.sin((angle * Math.PI) / 180) * distance,
                  y: -Math.cos((angle * Math.PI) / 180) * distance + 20,
                  rotate: angle * 0.5
                }}
                exit={{ opacity: 0, scale: 0.4, x: 0, y: 0, rotate: 0 }}
                transition={{
                  delay: i * 0.05,
                  duration: 0.45,
                  ease: [0.22, 1, 0.36, 1]
                }}
                className="absolute z-0"
                style={{ pointerEvents: "none" }}
              >
                <DocumentCard title={doc.title} />
              </motion.div>
            );
          })}
      </AnimatePresence>

      {/* Le dossier lui-même — taille md quand expanded, sm sinon */}
      <motion.button
        type="button"
        onClick={onToggle}
        layout
        className="relative z-10 cursor-pointer"
        whileHover={{ y: -2 }}
        transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
      >
        <FolderCard
          name={folder.name}
          count={folder.count}
          palette={folder.palette}
          icon={folder.icon}
          size={expanded ? "md" : "sm"}
          likeSlot={
            <FolderLikeButton
              liked={liked}
              onLike={handleLike}
              size={expanded ? "md" : "sm"}
            />
          }
        />
      </motion.button>
    </motion.div>
  );
}

/* Petit document papier — feuille blanche cornée avec titre */
function DocumentCard({ title }) {
  return (
    <div
      className="relative bg-white shadow-[0_8px_24px_-8px_rgba(0,0,0,0.35),0_2px_6px_rgba(0,0,0,0.18)]"
      style={{
        width: 76,
        height: 96,
        borderRadius: 3,
        border: "1px solid rgba(0,0,0,0.08)"
      }}
    >
      {/* Titre en haut de la feuille */}
      <div
        className="absolute inset-x-1.5 top-2 text-center text-stone-800 leading-tight"
        style={{
          fontFamily: "var(--font-serif)",
          fontStyle: "italic",
          fontSize: 9,
          letterSpacing: "-0.01em"
        }}
      >
        {title}
      </div>
      {/* Lignes simulant du texte sous le titre */}
      <div className="absolute inset-x-2 bottom-3 space-y-1.5">
        <div className="h-[2px] bg-stone-200 rounded-full w-5/6" />
        <div className="h-[2px] bg-stone-200 rounded-full w-2/3" />
        <div className="h-[2px] bg-stone-200 rounded-full w-3/4" />
      </div>
      {/* Coin replié */}
      <svg
        className="absolute top-0 right-0"
        width="10"
        height="10"
        viewBox="0 0 10 10"
      >
        <polygon points="10,0 10,10 0,0" fill="#F3F1EC" />
        <line x1="10" y1="0" x2="0" y2="0" stroke="rgba(0,0,0,0.12)" strokeWidth="0.5" />
        <line x1="10" y1="0" x2="10" y2="10" stroke="rgba(0,0,0,0.12)" strokeWidth="0.5" />
      </svg>
    </div>
  );
}