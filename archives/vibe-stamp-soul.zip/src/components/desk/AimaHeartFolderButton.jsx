import React, { useEffect, useState, forwardRef } from "react";
import { motion } from "framer-motion";

/**
 * AimaHeartFolderButton — Le dossier rouge avec cœur blanc parfaitement centré.
 * Sert à la fois de bouton (clic → ouvre Aïma) ET de zone de drop pour les dossiers.
 *
 * Props :
 *   - count : nb de dossiers déposés
 *   - onClick : ouvre la conversation
 *   - shakeKey : change → secoue le dossier
 *   - active : surbrillance pendant un drag-over
 *   - innerRef + dropProps : passés par Droppable de hello-pangea
 */
const AimaHeartFolderButton = forwardRef(function AimaHeartFolderButton(
  { count = 0, onClick, shakeKey = 0, active = false, dropProps = {}, label = "Glisse tes dossiers ici" },
  ref
) {
  const [shake, setShake] = useState(false);

  useEffect(() => {
    if (shakeKey === 0) return;
    setShake(true);
    const t = setTimeout(() => setShake(false), 700);
    return () => clearTimeout(t);
  }, [shakeKey]);

  // Taille standardisée = même que FolderStamp size="md" (≈ 88px)
  const SIZE = 88;

  return (
    <motion.div
      ref={ref}
      {...dropProps}
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.2, duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      className="fixed bottom-8 md:bottom-10 left-0 right-0 z-50 flex flex-col items-center pointer-events-none"
    >
      <motion.button
        onClick={onClick}
        whileHover={{ scale: 1.06, y: -3 }}
        whileTap={{ scale: 0.95 }}
        animate={
          shake
            ? { x: [0, -7, 7, -5, 5, -3, 3, 0], rotate: [0, -5, 5, -3, 3, -2, 2, 0] }
            : active
            ? { scale: 1.12 }
            : {}
        }
        transition={shake ? { duration: 0.6, ease: "easeInOut" } : { duration: 0.3 }}
        className="relative pointer-events-auto group"
        style={{ width: SIZE, height: SIZE }}
        aria-label={`Ouvrir Aïma${count > 0 ? ` (${count} dossiers)` : ""}`}
      >
        {/* Halo rouge pulsant — plus intense quand actif (drag-over) */}
        <motion.div
          className="absolute inset-0 rounded-full pointer-events-none"
          animate={{
            boxShadow: active
              ? [
                  "0 0 0 0 rgba(232,93,93,0.65)",
                  "0 0 0 28px rgba(232,93,93,0)"
                ]
              : [
                  "0 0 0 0 rgba(232,93,93,0.45)",
                  "0 0 0 18px rgba(232,93,93,0)"
                ]
          }}
          transition={{ duration: active ? 1.2 : 2.4, repeat: Infinity, ease: "easeOut" }}
        />

        {/* Le dossier rouge — SVG carré, parfaitement centré */}
        <div
          className="absolute inset-0 flex items-center justify-center"
          style={{
            filter: "drop-shadow(0 10px 24px rgba(232,93,93,0.45)) drop-shadow(0 3px 8px rgba(0,0,0,0.18))"
          }}
        >
          <svg width={SIZE} height={SIZE} viewBox="0 0 88 88" fill="none" aria-hidden="true">
            {/* Onglet du dossier */}
            <path
              d="M10 18 Q10 14 14 14 H32 L38 20 H74 Q78 20 78 24 V28 H10 Z"
              fill="#C9434A"
            />
            {/* Corps */}
            <path
              d="M8 26 H80 Q84 26 84 30 V74 Q84 78 80 78 H8 Q4 78 4 74 V30 Q4 26 8 26 Z"
              fill="url(#heart-folder-grad)"
            />
            {/* Highlight haut */}
            <path
              d="M8 26 H80 Q84 26 84 30 V34 H4 V30 Q4 26 8 26 Z"
              fill="rgba(255,255,255,0.18)"
            />
            <defs>
              <linearGradient id="heart-folder-grad" x1="44" y1="26" x2="44" y2="78" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#E85D5D" />
                <stop offset="100%" stopColor="#B83A40" />
              </linearGradient>
            </defs>
          </svg>
        </div>

        {/* Cœur blanc — centré sur le CORPS du dossier (entre y=26 et y=78, donc center y=52 → 59% du SVG) */}
        <motion.svg
          className="absolute pointer-events-none"
          style={{
            left: "50%",
            top: "59%",
            transform: "translate(-50%, -50%)"
          }}
          width="32"
          height="32"
          viewBox="0 0 24 24"
          fill="white"
          stroke="white"
          strokeWidth="1.2"
          strokeLinejoin="round"
          animate={{ scale: [1, 1.12, 1] }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
        >
          <path d="M12 19s-7-4.5-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 9c0 5.5-7 10-7 10Z" />
        </motion.svg>

        {/* Pastille count */}
        {count > 0 && (
          <motion.span
            key={count}
            initial={{ scale: 0, y: -4 }}
            animate={{ scale: 1, y: 0 }}
            transition={{ type: "spring", stiffness: 400, damping: 18 }}
            className="absolute -top-2 -right-2 min-w-[24px] h-[24px] px-1.5 rounded-full flex items-center justify-center text-[12px] font-semibold font-sans"
            style={{
              background: "#FFE9B8",
              color: "#7A2E3C",
              border: "2px solid #FFFFFF",
              boxShadow: "0 4px 12px rgba(0,0,0,0.18)"
            }}
          >
            {count}
          </motion.span>
        )}
      </motion.button>

      {/* Label sous le dossier — toujours visible, accentué quand actif */}
      <div
        className="mt-3 text-[11px] tracking-[0.22em] uppercase font-medium font-sans transition-colors duration-300"
        style={{ color: active ? "#C9434A" : "rgba(50,40,40,0.55)" }}
      >
        {active ? "Lâche ici, Aïma s'en occupe" : label}
      </div>
    </motion.div>
  );
});

export default AimaHeartFolderButton;