import React, { useState, useEffect, useMemo } from "react";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import { motion } from "framer-motion";
import FolderCard from "@/components/universal/FolderCard";
import AimaHeartFolderButton from "./AimaHeartFolderButton";
import { DESK_FOLDERS } from "@/lib/deskFolders";
import { readBasket, writeBasket, subscribeBasket } from "@/lib/deskBasket";

/**
 * DeskMosaic — Le bureau-mosaïque.
 * Tous les dossiers de même taille. La cible = le dossier rouge en bas.
 * On glisse en bas, zéro friction.
 *
 * Props :
 *   onAdded(folderId) — callback quand un dossier rejoint Aïma
 *   onOpenAima() — clic sur le dossier rouge
 *   basketCount, shakeKey — passés au bouton-cœur
 */
export default function DeskMosaic({ onAdded, onOpenAima, basketCount = 0, shakeKey = 0 }) {
  const [basket, setBasket] = useState([]);
  const [overTarget, setOverTarget] = useState(false);

  useEffect(() => {
    setBasket(readBasket());
    const unsub = subscribeBasket((ids) => setBasket(ids));
    return unsub;
  }, []);

  const mosaicFolders = useMemo(
    () => DESK_FOLDERS.filter((f) => !basket.includes(f.id)),
    [basket]
  );

  const handleDragUpdate = (update) => {
    setOverTarget(update.destination?.droppableId === "aima-heart");
  };

  const handleDragEnd = (result) => {
    setOverTarget(false);
    if (!result.destination) return;
    if (result.destination.droppableId === "aima-heart") {
      const id = result.draggableId;
      const next = [...readBasket(), id];
      writeBasket(next);
      onAdded?.(id);
    }
  };

  return (
    <DragDropContext
      onDragUpdate={handleDragUpdate}
      onDragEnd={handleDragEnd}
    >
      {/* Mosaïque — tous dossiers de même taille (md) */}
      <Droppable droppableId="desk-mosaic" direction="horizontal" isDropDisabled>
        {(provided) => (
          <div
            ref={provided.innerRef}
            {...provided.droppableProps}
            className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-y-10 gap-x-6 justify-items-center max-w-6xl mx-auto px-4"
          >
            {mosaicFolders.map((f, idx) => (
              <Draggable key={f.id} draggableId={f.id} index={idx}>
                {(prov, snap) => (
                  <motion.div
                    ref={prov.innerRef}
                    {...prov.draggableProps}
                    {...prov.dragHandleProps}
                    initial={{ opacity: 0, scale: 0.85 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.03 * (idx % 16), duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
                    style={{
                      ...prov.draggableProps.style,
                      zIndex: snap.isDragging ? 50 : 1
                    }}
                  >
                    <FolderCard
                      name={f.name}
                      count={f.count}
                      palette={f.palette}
                      size="md"
                    />
                  </motion.div>
                )}
              </Draggable>
            ))}
            <div style={{ display: "none" }}>{provided.placeholder}</div>
          </div>
        )}
      </Droppable>

      {/* Dossier rouge en bas = la cible */}
      <Droppable droppableId="aima-heart">
        {(provided, snapshot) => (
          <AimaHeartFolderButton
            ref={provided.innerRef}
            dropProps={provided.droppableProps}
            count={basketCount}
            shakeKey={shakeKey}
            onClick={onOpenAima}
            active={snapshot.isDraggingOver || overTarget}
          />
        )}
      </Droppable>
    </DragDropContext>
  );
}