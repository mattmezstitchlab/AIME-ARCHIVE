import React from "react";
import { motion } from "framer-motion";
import {
  ArrowRight,
  Heart,
  Flower,
  Feather,
  Baby,
  Flame,
  Sparkles,
  Unlock,
  CircleDot,
  Music,
  Handshake,
  Shield,
  HandHeart,
  Scale,
  Sunrise
} from "lucide-react";

// Mapping id → icône Lucide moderne et fine
const ICON_MAP = {
  "pacte-intention-amoureuse": Heart,
  "charte-promesses": Flower,
  "attestation-bonne-foi": Feather,
  "pacte-parental-incarnation": Baby,
  "testament-vibratoire": Flame,
  "serment-ame": Sparkles,
  "decharge-karmique": Unlock,
  "attestation-incarnation": CircleDot,
  "depot-oeuvre-vibratoire": Music,
  "contrat-mission-incarnee": Handshake,
  "charte-ethique-ia": Shield,
  "attestation-presence-proche": HandHeart,
  "plainte-vibratoire": Scale,
  "acte-reparation": Sunrise
};

export default function ContratCard({ contrat, accent, onChoose }) {
  const Icon = ICON_MAP[contrat.id] || Sparkles;
  return (
    <motion.button
      type="button"
      onClick={() => onChoose?.(contrat)}
      whileHover={{ y: -4 }}
      transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
      className="group relative text-left bg-white border border-black/10 rounded-2xl p-7 md:p-8 hover:border-black/30 transition-colors h-full flex flex-col"
    >
      <div className="flex items-start justify-between mb-5">
        <div
          className="w-10 h-10 rounded-full flex items-center justify-center"
          style={{ background: `${accent}14`, color: accent }}
        >
          <Icon className="w-[18px] h-[18px]" strokeWidth={1.5} />
        </div>
        <div
          className="text-[10px] tracking-[0.25em] uppercase font-sans"
          style={{ color: accent }}
        >
          {contrat.id.split("-")[0]}
        </div>
      </div>
      <h3 className="font-display uppercase text-[1.15rem] md:text-[1.3rem] leading-tight mb-3 tracking-tight">
        {contrat.title}
      </h3>
      <p className="text-[13.5px] text-black/65 leading-relaxed font-sans flex-1">
        {contrat.purpose}
      </p>
      <div className="mt-5 pt-4 border-t border-black/10 text-[11px] text-black/45 leading-relaxed font-sans">
        {contrat.legal}
      </div>
      <div
        className="mt-5 inline-flex items-center gap-1.5 text-[12px] tracking-[0.18em] uppercase font-sans group-hover:gap-2.5 transition-all"
        style={{ color: accent }}
      >
        Sceller cet acte
        <ArrowRight className="w-3.5 h-3.5" />
      </div>
    </motion.button>
  );
}