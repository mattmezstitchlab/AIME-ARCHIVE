import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

/**
 * RotatingHeadline — fait défiler plusieurs phrases au-dessus du bloc conversation.
 * Chaque phrase = { line1, italic, sub }
 */

const PHRASES = [
  {
    line1: "Une présence,",
    italic: "déjà là.",
    sub: "Tu parles. Aïma écoute, relie, compose."
  },
  {
    line1: "Votre mariage,",
    italic: "orchestré par Aïma.",
    sub: "Pas de menus. Pas de pages. Une seule fenêtre."
  },
  {
    line1: "Vos invités,",
    italic: "réunis en silence.",
    sub: "Un code, une chanson, un mot. Aïma tisse la nuit."
  },
  {
    line1: "Vos prestataires,",
    italic: "libérés du papier.",
    sub: "Aïma parle pour eux. Cachets, AEM, contrats — elle gère."
  },
  {
    line1: "Vos lieux,",
    italic: "remplis au bon tempo.",
    sub: "Aïma protège les saisons, briefe les artistes, accueille."
  },
  {
    line1: "Une mémoire,",
    italic: "qui reste.",
    sub: "Le sceau, le livre d'or, l'écho du jour d'après."
  }
];

export default function RotatingHeadline() {
  const [i, setI] = useState(0);

  useEffect(() => {
    const t = setInterval(() => setI((v) => (v + 1) % PHRASES.length), 5500);
    return () => clearInterval(t);
  }, []);

  const p = PHRASES[i];

  return (
    <div className="flex flex-col items-center min-h-[180px] md:min-h-[210px]">
      <AnimatePresence mode="wait">
        <motion.div
          key={i}
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
          className="flex flex-col items-center"
        >
          <h1 className="apple-headline text-white text-center text-4xl sm:text-5xl md:text-6xl lg:text-7xl max-w-3xl">
            {p.line1}<br />
            <span className="font-serif italic font-normal text-white/85">{p.italic}</span>
          </h1>
          <p
            className="mt-5 font-sans text-white/70 text-base md:text-lg max-w-md text-center leading-snug"
            style={{ letterSpacing: "-0.015em" }}
          >
            {p.sub}
          </p>
        </motion.div>
      </AnimatePresence>

      {/* dots */}
      <div className="mt-5 flex gap-1.5">
        {PHRASES.map((_, k) => (
          <button
            key={k}
            onClick={() => setI(k)}
            className="h-1 rounded-full transition-all duration-300"
            style={{
              width: i === k ? 20 : 5,
              backgroundColor: i === k ? "rgba(255,255,255,0.85)" : "rgba(255,255,255,0.25)"
            }}
            aria-label={`Phrase ${k + 1}`}
          />
        ))}
      </div>
    </div>
  );
}