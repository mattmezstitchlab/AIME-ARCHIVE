import React from "react";
import { motion } from "framer-motion";

/**
 * AimaSuggestions — Chips de relance qu'Aïma propose au visiteur.
 * Affichées sous le dernier message, cliquables, envoyées comme nouveau message user.
 */
export default function AimaSuggestions({ suggestions = [], onPick, accent }) {
  if (!suggestions || suggestions.length === 0) return null;

  const tint = accent || "#E11D74";

  return (
    <div className="flex flex-wrap gap-2 mt-3">
      {suggestions.map((s, i) => (
        <motion.button
          key={`${s}-${i}`}
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.35, delay: 0.05 * i, ease: [0.22, 1, 0.36, 1] }}
          onClick={() => onPick?.(s)}
          className="px-3.5 py-1.5 rounded-full text-[12px] font-sans transition-colors border"
          style={{
            color: tint,
            borderColor: `${tint}40`,
            background: `${tint}08`
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.background = `${tint}18`;
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.background = `${tint}08`;
          }}
        >
          {s}
        </motion.button>
      ))}
    </div>
  );
}