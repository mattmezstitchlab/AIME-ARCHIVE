import React from "react";
import { motion } from "framer-motion";
import FolderIcon from "@/components/design-system/FolderIcons";

/**
 * FolderCard — un vrai dossier physique (chemise / suspendu).
 * - Onglet replié en haut (tab) avec étiquette manuscrite (Instrument Serif)
 * - Texture papier (grain SVG)
 * - Coin replié bas-droite (corner fold)
 * - Hover : se soulève, montre l'épaisseur
 *
 * Props:
 *   name: string (ex. "Invités")
 *   count: number (ex. 84) — affiché sur l'étiquette
 *   palette: "kraft" | "moss" | "navy" | "wine" | "plum" | "ink"
 *   icon: optional ReactNode (un petit pictogramme dans l'onglet)
 *   delay: animation delay (s)
 */

// Palettes "icônes Apple" — chaque dossier = un mood unique
// base/deep = gradient du dossier, edge = couleur du picto/titre, tab = onglet, paper = badge count
const PALETTES = {
  // — Apple cloud blanc/gris (texte sombre)
  cloud:    { base: "#FFFFFF", deep: "#E8EAEE", edge: "#3A4A6A", tab: "#F2F4F8", paper: "#E0E4EA" },
  // — Noir profond avec picto coloré (vert néon comme Activity)
  midnight: { base: "#1C1C1E", deep: "#000000", edge: "#34D399", tab: "#0A0A0B", paper: "#2A2A2C" },
  // — Rouge Apple Music
  scarlet:  { base: "#FF5A6E", deep: "#E1183A", edge: "#FFE4E8", tab: "#D81234", paper: "#FFD9DF" },
  // — Orange Game/Arcade
  ember:    { base: "#FF8A65", deep: "#E64A19", edge: "#FFE0D2", tab: "#D84315", paper: "#FFE4D6" },
  // — Bleu iCloud
  azure:    { base: "#5DA9FF", deep: "#1F6DD9", edge: "#E1EEFF", tab: "#1665C1", paper: "#DCE9FA" },
  // — Vert Forest/Health
  forest:   { base: "#5BC893", deep: "#1F8A56", edge: "#DEF6E8", tab: "#168552", paper: "#D8F0E2" },
  // — Teal profond (remplace iris) — complémentaire chaud/froid
  iris:     { base: "#5EEAD4", deep: "#0F766E", edge: "#CCFBF1", tab: "#14B8A6", paper: "#D5F5EC" },
  // — Cyan Notes/Mail
  ocean:    { base: "#67D5DB", deep: "#0E8A9B", edge: "#E0F8FA", tab: "#0F7C8C", paper: "#D6F1F4" },
  // — Jaune solaire
  sunshine: { base: "#FACC15", deep: "#B45309", edge: "#FEF3C7", tab: "#D97706", paper: "#FEF1CE" },
  // — Rose poudré
  rose:     { base: "#F8A4B8", deep: "#C2185B", edge: "#FFE0E9", tab: "#AD1457", paper: "#FBD9E2" },
  // — Sauge / olive doux
  sage:     { base: "#A8C49A", deep: "#5A7A4C", edge: "#E5F0DC", tab: "#6E8F5C", paper: "#E0EBD4" },
  // — Terracotta chaud
  terracotta: { base: "#D88468", deep: "#9C4221", edge: "#F8DCC8", tab: "#B5532A", paper: "#F2D6C2" },
  // — Indigo profond Calendar
  indigo:   { base: "#6366F1", deep: "#312E81", edge: "#E0E1FB", tab: "#4338CA", paper: "#D8DAFA" },
  // — Charbon/graphite (texte clair)
  graphite: { base: "#52525B", deep: "#27272A", edge: "#E4E4E7", tab: "#3F3F46", paper: "#52525B" },
  // — Or champagne
  champagne: { base: "#E8D4A0", deep: "#B89968", edge: "#5A4520", tab: "#C9AE7C", paper: "#F5E8C8" },
  // — Anthracite + accent menthe
  slate:    { base: "#374151", deep: "#111827", edge: "#6EE7B7", tab: "#1F2937", paper: "#374151" },
  // — Crème/ivoire
  ivory:    { base: "#FFF8E7", deep: "#F0E4C8", edge: "#8B6914", tab: "#F5EAD0", paper: "#EBDDB8" },
  // — Sable doré (remplace lavender) — chaud doux
  lavender: { base: "#FDE68A", deep: "#A16207", edge: "#FEF9C3", tab: "#CA8A04", paper: "#FEF3C7" },
  // — Corail/saumon (remplace magenta) — chaleureux et harmonique
  magenta:  { base: "#FB923C", deep: "#9A3412", edge: "#FFEDD5", tab: "#C2410C", paper: "#FDDFC0" },
  // — Acier bleu-gris
  steel:    { base: "#94A3B8", deep: "#475569", edge: "#F1F5F9", tab: "#64748B", paper: "#E2E8F0" },
  // — Mint frais
  mint:     { base: "#86EFAC", deep: "#15803D", edge: "#E6FCE8", tab: "#22C55E", paper: "#DCF7DF" },
  // — Pêche douce
  peach:    { base: "#FED7AA", deep: "#C2410C", edge: "#5A2810", tab: "#EA580C", paper: "#FCE2C7" },
  // — Bordeaux profond
  bordeaux: { base: "#9F1239", deep: "#4C0519", edge: "#FECDD3", tab: "#7A0F2C", paper: "#F8C8D2" },
  // — Bleu nuit + accent or
  night:    { base: "#1E3A8A", deep: "#0F1A3D", edge: "#FCD34D", tab: "#1E40AF", paper: "#1E3A8A" },
  // — Coquille (blanc cassé)
  shell:    { base: "#FAFAF7", deep: "#E8E2D5", edge: "#7C5C20", tab: "#F0EAD8", paper: "#E8E0CE" }
};

export default function FolderCard({
  name,
  count,
  palette = "kraft",
  size = "md",
  delay = 0,
  icon = null,
  likeSlot = null
}) {
  const c = PALETTES[palette] || PALETTES.cloud;
  const dims = size === "xs"
    ? { w: 100, h: 78, tabW: 44, tabH: 13 }
    : size === "sm"
    ? { w: 130, h: 100, tabW: 56, tabH: 16 }
    : size === "lg"
    ? { w: 220, h: 170, tabW: 96, tabH: 24 }
    : { w: 180, h: 140, tabW: 78, tabH: 20 };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
      whileHover={{ y: -4 }}
      className="relative inline-flex flex-col items-center cursor-default group"
      style={{ width: dims.w }}
    >
      {/* Folder body wrapper — provides the stacked depth illusion */}
      <div
        className="relative"
        style={{ width: dims.w, height: dims.h }}
      >
        {/* Back papers (peek behind) */}
        <div
          className="absolute rounded-[3px]"
          style={{
            top: dims.tabH + 4,
            left: 6,
            right: 6,
            bottom: -2,
            background: c.paper,
            opacity: 0.55,
            transform: "rotate(-1deg)"
          }}
        />
        <div
          className="absolute rounded-[3px]"
          style={{
            top: dims.tabH + 6,
            left: 3,
            right: 3,
            bottom: -1,
            background: c.paper,
            opacity: 0.85,
            transform: "rotate(0.6deg)"
          }}
        />

        {/* The tab — vide, pour respirer */}
        <div
          className="absolute"
          style={{
            top: 0,
            left: 14,
            width: dims.tabW,
            height: dims.tabH + 6,
            background: c.tab,
            borderTopLeftRadius: 4,
            borderTopRightRadius: 4,
            boxShadow: "inset 0 1px 0 rgba(255,255,255,0.08)"
          }}
        />

        {/* Folder front face */}
        <div
          className="absolute overflow-hidden"
          style={{
            top: dims.tabH,
            left: 0,
            right: 0,
            bottom: 0,
            background: `linear-gradient(180deg, ${c.base} 0%, ${c.deep} 100%)`,
            borderRadius: "4px 6px 4px 4px",
            boxShadow: `0 1px 0 ${c.edge} inset, 0 -2px 4px rgba(0,0,0,0.25) inset, 0 6px 18px -8px rgba(0,0,0,0.6), 0 1px 2px rgba(0,0,0,0.4)`
          }}
        >
          {/* Paper grain */}
          <svg className="absolute inset-0 w-full h-full opacity-[0.18] mix-blend-overlay pointer-events-none">
            <filter id={`folder-grain-${palette}-${name}`}>
              <feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves="2" stitchTiles="stitch" />
              <feColorMatrix values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 0.6 0" />
            </filter>
            <rect width="100%" height="100%" filter={`url(#folder-grain-${palette}-${name})`} />
          </svg>

          {/* Top edge highlight */}
          <div
            className="absolute top-0 left-0 right-0 h-px"
            style={{ background: `linear-gradient(90deg, transparent, ${c.edge}, transparent)`, opacity: 0.7 }}
          />

          {/* Picto + titre, empilés au centre du dossier */}
          <div
            className="absolute inset-0 flex flex-col items-center justify-center gap-1 pointer-events-none px-2"
            style={{ paddingTop: dims.tabH * 0.3 }}
          >
            {icon && (
              <div style={{ color: c.edge, opacity: 0.85 }}>
                <FolderIcon
                  name={icon}
                  size={size === "xs" ? 22 : size === "sm" ? 28 : size === "lg" ? 46 : 38}
                  strokeWidth={1.5}
                />
              </div>
            )}
            <div
              className="text-center leading-tight uppercase"
              style={{
                fontFamily: "var(--font-display)",
                fontWeight: 900,
                fontSize: size === "xs" ? 12 : size === "sm" ? 14 : size === "lg" ? 20 : 16,
                color: c.edge,
                opacity: 1,
                letterSpacing: "0.025em"
              }}
            >
              {name}
            </div>
          </div>

          {/* Count badge — paper sticker */}
          {count !== undefined && (
            <div
              className="absolute"
              style={{
                bottom: size === "xs" ? 7 : size === "sm" ? 10 : 14,
                left: size === "xs" ? 7 : size === "sm" ? 10 : 14,
                background: c.paper,
                color: c.deep,
                fontFamily: "var(--font-serif)",
                fontStyle: "italic",
                fontSize: size === "xs" ? 9 : size === "sm" ? 11 : size === "lg" ? 16 : 13,
                padding: size === "xs" ? "1.5px 6px" : size === "sm" ? "2px 8px" : "3px 10px",
                borderRadius: 999,
                boxShadow: "0 1px 0 rgba(255,255,255,0.5) inset, 0 1px 2px rgba(0,0,0,0.2)",
                lineHeight: 1
              }}
            >
              {count}
            </div>
          )}

          {/* Corner fold (bottom-right) */}
          <svg
            className="absolute bottom-0 right-0 pointer-events-none"
            width={size === "xs" ? 11 : size === "sm" ? 14 : size === "lg" ? 22 : 18}
            height={size === "xs" ? 11 : size === "sm" ? 14 : size === "lg" ? 22 : 18}
            viewBox="0 0 20 20"
          >
            <polygon
              points="20,20 0,20 20,0"
              fill={c.deep}
            />
            <polygon
              points="20,20 6,20 20,6"
              fill={c.paper}
              opacity="0.9"
            />
            <line x1="20" y1="6" x2="6" y2="20" stroke={c.deep} strokeWidth="0.5" opacity="0.4" />
          </svg>
        </div>

        {/* Slot pour bouton Like (cœur Tinder) — ancré au coin haut-droit du body */}
        {likeSlot}
      </div>

    </motion.div>
  );
}