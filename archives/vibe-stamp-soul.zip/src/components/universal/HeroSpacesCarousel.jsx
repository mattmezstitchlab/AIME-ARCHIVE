import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { base44 } from "@/api/base44Client";

/**
 * HeroSpacesCarousel — Affiche toutes les fenêtres AIME® (entité Space)
 * en défilement automatique dans le hero.
 * Image plein cadre + titre + sous-titre + spécificité.
 * Auto-advance toutes les 5s, contrôles dots en bas.
 */

const FALLBACK = [
  {
    slug: "mariage",
    label: "Mariage",
    title: "Le mariage,",
    italic: "et tout ce qui le tient ensemble.",
    desc: "Aïma orchestre les quatre rôles : Couples · Invités · Prestataires · Lieux.",
    bg_url: "https://res.cloudinary.com/divou1vcx/image/upload/v1777698965/pexels-rothemba-vele-1414849-18041569_pps4us.jpg",
    accent_color: "#D4A574"
  }
];

export default function HeroSpacesCarousel() {
  const [spaces, setSpaces] = useState(FALLBACK);
  const [active, setActive] = useState(0);
  const [paused, setPaused] = useState(false);

  useEffect(() => {
    base44.entities.Space.list("order_index", 20)
      .then((rows) => {
        if (rows?.length) {
          const order = { live: 0, soon: 1, lab: 2 };
          const sorted = [...rows].sort((a, b) => {
            const pa = order[a.phase || "live"] ?? 0;
            const pb = order[b.phase || "live"] ?? 0;
            if (pa !== pb) return pa - pb;
            return (a.order_index || 0) - (b.order_index || 0);
          });
          setSpaces(sorted);
        }
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    if (paused || spaces.length <= 1) return;
    const t = setInterval(() => {
      setActive((a) => (a + 1) % spaces.length);
    }, 5500);
    return () => clearInterval(t);
  }, [paused, spaces.length]);

  const current = spaces[active] || spaces[0];
  if (!current) return null;

  const phaseLabel = current.phase === "soon" ? "Bientôt" : current.phase === "lab" ? "Laboratoire" : null;

  return (
    <div
      className="relative w-full h-full"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
    >
      {/* Background images crossfade */}
      <AnimatePresence mode="wait">
        <motion.div
          key={current.slug + "-bg"}
          initial={{ opacity: 0, scale: 1.05 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
          className="absolute inset-0"
        >
          <img
            src={current.bg_url}
            alt=""
            className="absolute inset-0 w-full h-full object-cover"
          />
          <div
            className="absolute inset-0"
            style={{
              background:
                "linear-gradient(180deg, rgba(10,10,11,0.55) 0%, rgba(10,10,11,0.4) 40%, rgba(10,10,11,0.85) 100%)"
            }}
          />
        </motion.div>
      </AnimatePresence>

      {/* Content overlay */}
      <div className="relative z-10 h-full flex flex-col justify-end px-6 md:px-12 pb-32 md:pb-36">
        <AnimatePresence mode="wait">
          <motion.div
            key={current.slug}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl"
          >
            {/* Eyebrow + phase */}
            <div className="flex items-center gap-3 mb-4">
              <span
                className="w-1.5 h-1.5 rounded-full animate-pulse"
                style={{ backgroundColor: current.accent_color || "#fff" }}
              />
              <span className="font-sans text-[11px] tracking-[0.3em] uppercase text-white/60">
                {current.eyebrow || `Espace ${current.label}`}
              </span>
              {phaseLabel && (
                <span
                  className="px-2 py-0.5 rounded-full text-[9px] tracking-[0.2em] uppercase font-medium border"
                  style={{
                    backgroundColor: "rgba(255,255,255,0.08)",
                    borderColor: "rgba(255,255,255,0.2)",
                    color: "rgba(255,255,255,0.75)"
                  }}
                >
                  {phaseLabel}
                </span>
              )}
            </div>

            {/* Title */}
            <h2 className="apple-headline text-white text-3xl md:text-5xl lg:text-6xl">
              {current.title || current.label}
              {current.italic && (
                <>
                  <br />
                  <span className="font-serif italic font-normal text-white/75">
                    {current.italic}
                  </span>
                </>
              )}
            </h2>

            {/* Description */}
            {current.description && (
              <p className="mt-4 font-sans text-white/70 text-[14px] md:text-[16px] leading-relaxed max-w-xl">
                {current.description}
              </p>
            )}
          </motion.div>
        </AnimatePresence>

        {/* Dots */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex gap-1.5">
          {spaces.map((s, i) => (
            <button
              key={s.id || s.slug}
              onClick={() => setActive(i)}
              className="h-1 rounded-full transition-all duration-500"
              style={{
                width: active === i ? 28 : 8,
                backgroundColor: active === i ? (current.accent_color || "#fff") : "rgba(255,255,255,0.3)"
              }}
              aria-label={`Voir ${s.label}`}
            />
          ))}
        </div>
      </div>
    </div>
  );
}