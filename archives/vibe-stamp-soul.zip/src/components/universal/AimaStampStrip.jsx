import React, { useMemo } from "react";
import { motion } from "framer-motion";
import WorldStamp from "@/components/manifesto/WorldStamp";

/**
 * AimaStampStrip — Un défilé silencieux de Timbres AIME® en bandeau.
 * Pose une présence visuelle de la "force" d'Aïma : tous les actes
 * deviennent des timbres. Pas de boutons, pas de texte, juste la planche
 * vivante qui glisse lentement.
 */
const SAMPLES = [
  { city: "PARIS", date: "MAI 2026", rot: -6 },
  { city: "LYON", date: "MAI 2026", rot: 4 },
  { city: "MARSEILLE", date: "AVR 2026", rot: -3 },
  { city: "ANTIBES", date: "MAI 2026", rot: 7 },
  { city: "BORDEAUX", date: "MAR 2026", rot: -5 },
  { city: "NANTES", date: "AVR 2026", rot: 2 },
  { city: "TOULOUSE", date: "MAI 2026", rot: -8 },
  { city: "STRASBOURG", date: "FEV 2026", rot: 5 },
  { city: "RENNES", date: "MAI 2026", rot: -2 },
  { city: "MONTPELLIER", date: "AVR 2026", rot: 6 }
];

export default function AimaStampStrip() {
  // On duplique pour boucle infinie fluide
  const loop = useMemo(() => [...SAMPLES, ...SAMPLES], []);
  return (
    <div
      className="relative w-full overflow-hidden py-3"
      style={{
        maskImage:
          "linear-gradient(to right, transparent 0%, black 8%, black 92%, transparent 100%)",
        WebkitMaskImage:
          "linear-gradient(to right, transparent 0%, black 8%, black 92%, transparent 100%)"
      }}
    >
      <motion.div
        className="flex gap-8 items-center"
        animate={{ x: ["0%", "-50%"] }}
        transition={{
          duration: 90,
          ease: "linear",
          repeat: Infinity
        }}
        style={{ width: "max-content" }}
      >
        {loop.map((s, i) => (
          <div key={i} className="flex-shrink-0">
            <WorldStamp city={s.city} date={s.date} rotate={s.rot} scale={0.55} />
          </div>
        ))}
      </motion.div>
    </div>
  );
}