import React from "react";
import AimaCanvas from "./AimaCanvas";

/**
 * AimaModal — Wrapper qui rend l'expérience plein écran AimaCanvas.
 * Le mode "plein écran avec réduction" remplace les anciens modes min/mid/full.
 * - onMinimize : referme l'overlay (le cœur flottant reste accessible).
 * - onClose : alias (même comportement, kept for compatibility).
 */
export default function AimaModal({ open, onClose, accent = null, intent = null, space = null }) {
  return (
    <AimaCanvas
      open={open}
      accent={accent}
      intent={intent}
      space={space}
      onMinimize={onClose}
      onClose={onClose}
    />
  );
}