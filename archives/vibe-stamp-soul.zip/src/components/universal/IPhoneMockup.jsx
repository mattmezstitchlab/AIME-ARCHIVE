import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { base44 } from "@/api/base44Client";

/**
 * IPhoneMockup — Maquette iPhone réaliste qui défile les 9 fenêtres AIME®.
 * Frame métal noir, écran arrondi, dynamic island, image plein cadre + overlay
 * titre/sous-titre. Auto-advance 4.5s, dots en bas.
 */

const FALLBACK = [
  {
    slug: "couples",
    label: "Couples",
    title: "Vous deux,",
    italic: "et tout le reste suit.",
    bg_url: "https://res.cloudinary.com/divou1vcx/image/upload/v1777698965/pexels-rothemba-vele-1414849-18041569_pps4us.jpg",
    accent_color: "#D4A574"
  }
];

export default function IPhoneMockup() {
  const [spaces, setSpaces] = useState(FALLBACK);
  const [active, setActive] = useState(0);

  useEffect(() => {
    base44.entities.Space.list("order_index", 20)
      .then((rows) => {
        if (rows?.length) {
          const order = { live: 0, soon: 1, lab: 2 };
          const sorted = [...rows].sort((a, b) => {
            const pa = order[a.phase || "live"] ?? 0;
            const pb = order[b.phase || "live"] ?? 0;
            if (pa !== pb) return pa - pb;
            return (a.order_index || 0) - (b.order_index || 0);
          });
          setSpaces(sorted);
        }
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    if (spaces.length <= 1) return;
    const t = setInterval(() => {
      setActive((a) => (a + 1) % spaces.length);
    }, 4500);
    return () => clearInterval(t);
  }, [spaces.length]);

  const current = spaces[active] || spaces[0];
  if (!current) return null;

  const phaseLabel = current.phase === "soon" ? "Bientôt" : current.phase === "lab" ? "Labo" : null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 30, rotateY: -8 }}
      animate={{ opacity: 1, y: 0, rotateY: 0 }}
      transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
      className="relative mx-auto"
      style={{
        width: 290,
        height: 588,
        perspective: 1200,
      }}
    >
      {/* Glow lumineux derrière */}
      <div
        className="absolute -inset-8 rounded-[60px] opacity-40 blur-3xl pointer-events-none transition-colors duration-1000"
        style={{ backgroundColor: current.accent_color || "#fff" }}
      />

      {/* Frame iPhone — métal noir avec gradient subtil */}
      <div
        className="relative w-full h-full rounded-[52px] p-[10px]"
        style={{
          background: "linear-gradient(145deg, #2a2a2c 0%, #0a0a0b 50%, #1a1a1c 100%)",
          boxShadow: "0 30px 80px rgba(0,0,0,0.5), 0 10px 30px rgba(0,0,0,0.3), inset 0 0 0 1.5px rgba(255,255,255,0.08)"
        }}
      >
        {/* Boutons latéraux */}
        <div className="absolute -left-[2px] top-[110px] w-[3px] h-[28px] rounded-l bg-stone-700" />
        <div className="absolute -left-[2px] top-[160px] w-[3px] h-[50px] rounded-l bg-stone-700" />
        <div className="absolute -left-[2px] top-[220px] w-[3px] h-[50px] rounded-l bg-stone-700" />
        <div className="absolute -right-[2px] top-[180px] w-[3px] h-[80px] rounded-r bg-stone-700" />

        {/* Écran */}
        <div className="relative w-full h-full rounded-[42px] overflow-hidden bg-black">
          {/* Dynamic island */}
          <div className="absolute top-2 left-1/2 -translate-x-1/2 z-20 w-[100px] h-[28px] rounded-full bg-black" />

          {/* Status bar — heure & icônes */}
          <div className="absolute top-0 inset-x-0 z-10 flex items-center justify-between px-7 pt-3 text-white text-[11px] font-semibold">
            <span>9:41</span>
            <span className="flex items-center gap-1">
              <span className="text-[10px]">●●●●</span>
              <span>100%</span>
            </span>
          </div>

          {/* Slides — image plein cadre + overlay */}
          <AnimatePresence mode="wait">
            <motion.div
              key={current.slug}
              initial={{ opacity: 0, scale: 1.04 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
              className="absolute inset-0"
            >
              <img
                src={current.bg_url}
                alt=""
                className="absolute inset-0 w-full h-full object-cover"
              />
              {/* Gradient overlay */}
              <div
                className="absolute inset-0"
                style={{
                  background:
                    "linear-gradient(180deg, rgba(0,0,0,0.45) 0%, rgba(0,0,0,0.15) 35%, rgba(0,0,0,0.85) 100%)"
                }}
              />

              {/* Content overlay */}
              <div className="absolute inset-0 flex flex-col justify-end px-5 pb-12">
                {/* Eyebrow + phase */}
                <div className="flex items-center gap-2 mb-2.5">
                  <span
                    className="w-1 h-1 rounded-full"
                    style={{ backgroundColor: current.accent_color || "#fff" }}
                  />
                  <span className="text-[8.5px] tracking-[0.25em] uppercase text-white/75 font-medium">
                    {current.eyebrow || `Espace ${current.label}`}
                  </span>
                  {phaseLabel && (
                    <span
                      className="px-1.5 py-0.5 rounded-full text-[7.5px] tracking-[0.15em] uppercase font-medium border border-white/25 text-white/75 bg-white/10"
                    >
                      {phaseLabel}
                    </span>
                  )}
                </div>

                {/* Title */}
                <h3 className="font-serif text-white text-[22px] leading-[1.1] mb-1">
                  {current.title || current.label}
                </h3>
                {current.italic && (
                  <h3 className="font-serif italic text-white/85 text-[19px] leading-[1.1]">
                    {current.italic}
                  </h3>
                )}

                {/* Description courte */}
                {current.description && (
                  <p className="mt-2 text-white/70 text-[10.5px] leading-snug line-clamp-2 max-w-[230px]">
                    {current.description}
                  </p>
                )}
              </div>

              {/* Bouton bas style "Parler à Aïma" */}
              <div className="absolute bottom-3 left-1/2 -translate-x-1/2 px-5 py-2 rounded-full bg-white/95 backdrop-blur text-stone-900 text-[9px] tracking-[0.2em] uppercase font-medium flex items-center gap-1.5 shadow-lg">
                <span>✦</span> Parler à Aïma
              </div>
            </motion.div>
          </AnimatePresence>

          {/* Dots */}
          <div className="absolute bottom-1 left-1/2 -translate-x-1/2 z-20 flex gap-1">
            {spaces.map((s, i) => (
              <div
                key={s.id || s.slug}
                className="h-[2px] rounded-full transition-all duration-500"
                style={{
                  width: active === i ? 14 : 4,
                  backgroundColor: active === i ? "rgba(255,255,255,0.95)" : "rgba(255,255,255,0.3)"
                }}
              />
            ))}
          </div>
        </div>
      </div>
    </motion.div>
  );
}