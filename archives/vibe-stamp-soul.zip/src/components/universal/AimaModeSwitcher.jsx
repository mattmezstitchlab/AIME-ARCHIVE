import React from "react";

/**
 * AimaModeSwitcher — Switcher 3 modes d'affichage en haut de la fenêtre Aïma.
 * Inclusif par design : minimal (lecture rapide) · intermédiaire (par défaut) · plein écran (confort, accessibilité, preuve légale).
 * Utilisable par tous — utile pour Charcot/SLA, malvoyants, captures écran juridiques, présentations.
 */

const MODES = [
  {
    id: "min",
    label: "Minimal",
    title: "Mode minimal — fenêtre compacte",
    icon: (
      <>
        <rect x="6" y="9" width="12" height="6" rx="1.5" />
      </>
    )
  },
  {
    id: "mid",
    label: "Confort",
    title: "Mode confort — taille intermédiaire",
    icon: (
      <>
        <rect x="4" y="6" width="16" height="12" rx="2" />
      </>
    )
  },
  {
    id: "full",
    label: "Plein",
    title: "Mode plein écran — accessibilité & preuve légale",
    icon: (
      <>
        <rect x="3" y="4" width="18" height="16" rx="2" />
        <path d="M7 8h4M7 12h10M7 16h7" />
      </>
    )
  }
];

export default function AimaModeSwitcher({ mode, onChange }) {
  return (
    <div className="flex items-center gap-1 p-1 rounded-full bg-white/[0.06] border border-white/10">
      {MODES.map((m) => {
        const active = mode === m.id;
        return (
          <button
            key={m.id}
            type="button"
            onClick={() => onChange(m.id)}
            title={m.title}
            aria-label={m.title}
            aria-pressed={active}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-full text-[10.5px] tracking-[0.08em] uppercase transition-colors ${
              active
                ? "bg-white text-stone-900 font-medium"
                : "text-white/55 hover:text-white/85"
            }`}
          >
            <svg
              width="13"
              height="13"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.7"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              {m.icon}
            </svg>
            <span className="hidden md:inline whitespace-nowrap">{m.label}</span>
          </button>
        );
      })}
    </div>
  );
}

/* Tailles utilisées par AimaModal pour adapter le wrapper */
export const MODE_SIZES = {
  min: "max-w-md",        // ~448px — fenêtre étroite
  mid: "max-w-2xl",       // ~672px — défaut actuel
  full: "max-w-[100vw]"   // pleine largeur, géré par AimaModal
};

export const MODE_HEIGHTS = {
  min: { min: 140, max: 220 },
  mid: { min: 220, max: 340 },
  full: { min: 320, max: 720 }
};