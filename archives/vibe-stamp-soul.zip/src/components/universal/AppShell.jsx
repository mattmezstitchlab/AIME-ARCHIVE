import React from "react";
import { useLocation } from "react-router-dom";
import GlobalHeader from "./GlobalHeader";
import SiteFooter from "./SiteFooter";
import AimaFloatingButton from "./AimaFloatingButton";
import AimaModal from "./AimaModal";
import { AimaModalProvider, useAimaModal, SPACE_ACCENTS, SPACE_TO_PROFILE } from "@/lib/AimaModalContext";
import { EditModeProvider } from "@/lib/EditModeContext";
import EditDrawer from "@/components/edit/EditDrawer";
import EditModeBar from "@/components/edit/EditModeBar";

/**
 * AppShell — Wrapper global de l'app.
 * - Header persistant (transparent sur la home, solide ailleurs)
 * - Bouton flottant Aïma (toujours visible, sauf admin)
 * - Modal Aïma (s'ouvre via context : useAimaModal().openAima())
 */
// Détection automatique de l'espace en fonction de la route active
function getRouteSpace(pathname) {
  if (pathname.startsWith("/mariage")) return "mariage";
  if (pathname.startsWith("/intermittents")) return "intermittents";
  if (pathname.startsWith("/inclusive")) return "inclusive";
  if (pathname.startsWith("/mairies")) return "mairies";
  if (pathname.startsWith("/memoire")) return "memoire";
  if (pathname.startsWith("/noyau")) return "noyau";
  if (pathname.startsWith("/agriculteurs")) return "agriculteurs";
  if (pathname.startsWith("/music-rights")) return "music_rights";
  return null;
}
function getRouteAccent(pathname) {
  const sp = getRouteSpace(pathname);
  return sp ? SPACE_ACCENTS[sp] : null;
}
function getRouteProfile(pathname) {
  const sp = getRouteSpace(pathname);
  return sp ? SPACE_TO_PROFILE[sp] : null;
}

function ShellInner({ children }) {
  const location = useLocation();
  const { open, accent, space: modalSpace, initialProfile, intent, startMode, openAima, closeAima } = useAimaModal();

  const isAdmin = location.pathname.startsWith("/admin");
  const isHome = location.pathname === "/";
  const routeSpace = getRouteSpace(location.pathname);
  const routeAccent = getRouteAccent(location.pathname);
  const routeProfile = getRouteProfile(location.pathname);
  // Si la modal a été ouverte avec un accent explicite, on le garde, sinon on prend la route
  const activeAccent = accent || routeAccent;
  const activeProfile = initialProfile || routeProfile;
  // Home désormais blanche → header solide partout (sauf admin déjà géré)
  const headerVariant = "solid";
  const headerWrapperClass = isHome ? "absolute top-0 inset-x-0 z-30 bg-transparent" : "relative";

  // Admin : header global affiché, mais pas le bouton flottant Aïma
  if (isAdmin) {
    return (
      <>
        <GlobalHeader variant="solid" />
        {children}
        <EditDrawer />
      </>
    );
  }

  return (
    <>
      <div className={headerWrapperClass}>
        <GlobalHeader variant={headerVariant} />
      </div>
      {children}
      <SiteFooter />
      {/* Sur la home, le bouton flottant standard est remplacé par le dossier-cœur du bureau-mosaïque */}
      {!isHome && (
        <AimaFloatingButton onClick={() => openAima({ space: routeSpace })} hidden={open} accent={routeAccent} />
      )}
      <AimaModal open={open} onClose={closeAima} accent={activeAccent} intent={intent} space={modalSpace || routeSpace} />
      <EditModeBar />
      <EditDrawer />
    </>
  );
}

export default function AppShell({ children }) {
  return (
    <EditModeProvider>
      <AimaModalProvider>
        <ShellInner>{children}</ShellInner>
      </AimaModalProvider>
    </EditModeProvider>
  );
}