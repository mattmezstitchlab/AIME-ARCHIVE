import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { ArrowRight, Quote, ShieldCheck, Sparkles } from "lucide-react";
import WorldStamp from "@/components/manifesto/WorldStamp";

/**
 * AimaArtifact — Carte visuelle qu'Aïma fait apparaître dans la conversation.
 *
 * Doctrine : on privilégie le TIMBRE comme illustration vivante.
 * Un timbre n'est rendu que s'il est COMPLET (ville ET date présentes).
 * Sinon, on n'affiche rien — on ne charge pas la fenêtre avec du faux.
 */
export default function AimaArtifact({ artifact, onClose }) {
  if (!artifact || !artifact.kind) return null;

  const baseAnim = {
    initial: { opacity: 0, y: 12, scale: 0.96 },
    animate: { opacity: 1, y: 0, scale: 1 },
    transition: { duration: 0.5, ease: [0.22, 1, 0.36, 1] }
  };

  // ─── TIMBRE en direct ───────────────────────────────────────
  // On exige city ET date pour qu'il ressemble à un VRAI timbre.
  if (artifact.kind === "stamp") {
    const city = (artifact.city || "").trim();
    const date = (artifact.date || "").trim();
    if (!city || !date) return null;
    return (
      <motion.div {...baseAnim} className="my-3 flex justify-center py-4">
        <WorldStamp city={city} date={date} rotate={-4} scale={0.95} />
      </motion.div>
    );
  }

  // ─── CONTRAT scellable ──────────────────────────────────────
  if (artifact.kind === "contrat") {
    return (
      <motion.div {...baseAnim} className="my-3">
        <Link
          to={`/sceller?contrat=${encodeURIComponent(artifact.id || "")}`}
          onClick={() => onClose?.()}
          className="group block bg-white border border-rose-200/70 rounded-2xl p-5 hover:border-rose-400 transition-colors"
        >
          <div className="flex items-start justify-between gap-3 mb-2">
            <div className="text-[10px] tracking-[0.25em] uppercase text-rose-600 font-sans">
              Acte incarné
            </div>
            <Sparkles className="w-3.5 h-3.5 text-rose-400" strokeWidth={1.5} />
          </div>
          <div className="font-display uppercase text-[15px] tracking-tight text-black mb-2 leading-tight">
            {artifact.title}
          </div>
          {artifact.purpose && (
            <p className="text-[13px] text-black/65 leading-relaxed font-sans mb-3">
              {artifact.purpose}
            </p>
          )}
          <div className="inline-flex items-center gap-1.5 text-[11px] tracking-[0.18em] uppercase text-rose-600 group-hover:gap-2.5 transition-all">
            Sceller cet acte
            <ArrowRight className="w-3 h-3" />
          </div>
        </Link>
      </motion.div>
    );
  }

  // ─── DOCTRINE / citation ────────────────────────────────────
  if (artifact.kind === "doctrine") {
    return (
      <motion.div {...baseAnim} className="my-3">
        <div className="bg-black text-white rounded-2xl p-5 relative overflow-hidden">
          <Quote className="w-5 h-5 text-rose-400 mb-3" strokeWidth={1.5} />
          {artifact.title && (
            <div className="text-[10px] tracking-[0.3em] uppercase text-rose-400 mb-2 font-sans">
              {artifact.title}
            </div>
          )}
          <blockquote className="font-serif italic text-[15px] leading-relaxed text-white/90">
            « {artifact.quote} »
          </blockquote>
          {artifact.source && (
            <div className="mt-3 text-[10px] tracking-[0.2em] uppercase text-white/40 font-sans">
              — {artifact.source}
            </div>
          )}
        </div>
      </motion.div>
    );
  }

  // ─── CTA bouton vers une page ───────────────────────────────
  if (artifact.kind === "cta" && artifact.href) {
    return (
      <motion.div {...baseAnim} className="my-2">
        <Link
          to={artifact.href}
          onClick={() => onClose?.()}
          className="inline-flex items-center gap-2 px-5 py-2.5 bg-black text-white text-[11px] tracking-[0.2em] uppercase rounded-full hover:bg-black/85 transition-colors"
        >
          <ShieldCheck className="w-3.5 h-3.5" />
          {artifact.label || "Y aller"}
          <ArrowRight className="w-3 h-3" />
        </Link>
      </motion.div>
    );
  }

  return null;
}