import React, { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Send, Minus, X, Sparkles } from "lucide-react";
import { base44 } from "@/api/base44Client";
import AimaArtifact from "./AimaArtifact";
import AimaSuggestions from "./AimaSuggestions";
import AimaStampStrip from "./AimaStampStrip";

/**
 * AimaCanvas — Expérience plein écran de conversation avec Aïma.
 *
 * Doctrine : Aïma est l'héroïne. La fenêtre n'est PAS chargée de boutons.
 * - Un défilé silencieux de Timbres en bandeau dit sa force.
 * - Une intro courte, mystérieuse, sans menu.
 * - Des suggestions très discrètes et minimales.
 * - Aïma illustre par des timbres uniquement quand ils sont VRAIS (générés bien).
 */

const INTRO = {
  reply:
    "Je suis là. Dis-moi simplement ce qui t'amène — je sais faire bien plus que tu n'imagines."
};

export default function AimaCanvas({ open, onMinimize, onClose, accent = null, intent = null, space = null }) {
  const tint = accent || "#E11D74";
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [suggestions, setSuggestions] = useState([]);
  const scrollerRef = useRef(null);
  const inputRef = useRef(null);

  // Init / reset à l'ouverture
  useEffect(() => {
    if (!open) return;
    setMessages([
      { role: "assistant", content: INTRO.reply, artifacts: [] }
    ]);
    setSuggestions([]);
    setInput("");

    // Si une intention initiale est fournie, on l'envoie automatiquement
    if (intent) {
      setTimeout(() => sendMessage(intent), 250);
    }

    // Focus input
    setTimeout(() => inputRef.current?.focus(), 200);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  // ESC pour minimiser
  useEffect(() => {
    if (!open) return;
    const onKey = (e) => {
      if (e.key === "Escape") onMinimize?.();
    };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open, onMinimize]);

  // Auto-scroll
  useEffect(() => {
    if (!scrollerRef.current) return;
    scrollerRef.current.scrollTo({
      top: scrollerRef.current.scrollHeight,
      behavior: "smooth"
    });
  }, [messages, loading]);

  const sendMessage = async (text) => {
    const trimmed = (text || "").trim();
    if (!trimmed || loading) return;

    const userMsg = { role: "user", content: trimmed };
    const nextMessages = [...messages, userMsg];
    setMessages(nextMessages);
    setInput("");
    setSuggestions([]);
    setLoading(true);

    try {
      const res = await base44.functions.invoke("aimaChat", {
        messages: nextMessages.map((m) => ({ role: m.role, content: m.content })),
        context: { space }
      });
      const data = res?.data || {};
      const reply = (data.reply || "").trim() || "Je note.";
      const artifacts = Array.isArray(data.artifacts) ? data.artifacts : [];
      const suggs = Array.isArray(data.suggestions) ? data.suggestions.slice(0, 3) : [];
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: reply, artifacts }
      ]);
      setSuggestions(suggs);
    } catch (e) {
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: "Le silence un instant. Réessaie.",
          artifacts: []
        }
      ]);
    }
    setLoading(false);
    setTimeout(() => inputRef.current?.focus(), 50);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    sendMessage(input);
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
          className="fixed inset-0 z-[60]"
        >
          {/* Backdrop teinté */}
          <div
            className="absolute inset-0 backdrop-blur-md"
            style={{
              backgroundColor: "rgba(8,4,12,0.92)",
              backgroundImage: `radial-gradient(ellipse at 50% 30%, ${tint}28 0%, transparent 65%)`
            }}
          />

          {/* Header */}
          <motion.header
            initial={{ y: -20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.1, duration: 0.4 }}
            className="absolute top-0 left-0 right-0 z-10 px-5 md:px-8 py-4 flex items-center justify-between"
          >
            <div className="flex items-center gap-3">
              <motion.div
                animate={{ scale: [1, 1.08, 1] }}
                transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
                className="w-9 h-9 rounded-full bg-white flex items-center justify-center"
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={tint} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M12 19s-7-4.5-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 9c0 5.5-7 10-7 10Z" />
                </svg>
              </motion.div>
              <div>
                <div className="text-white font-display uppercase text-[14px] tracking-tight leading-none">
                  Aïma
                </div>
                <div className="text-white/50 text-[10px] tracking-[0.25em] uppercase mt-1 font-sans">
                  Présence AIME®
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={onMinimize}
                className="w-9 h-9 rounded-full border border-white/15 flex items-center justify-center text-white/70 hover:text-white hover:border-white/40 transition-colors"
                title="Réduire (revenir au cœur)"
                aria-label="Réduire"
              >
                <Minus className="w-4 h-4" />
              </button>
              <button
                onClick={onClose}
                className="w-9 h-9 rounded-full border border-white/15 flex items-center justify-center text-white/70 hover:text-white hover:border-white/40 transition-colors"
                title="Fermer"
                aria-label="Fermer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </motion.header>

          {/* Bandeau silencieux de Timbres défilants — la force d'Aïma sans mots */}
          <div className="absolute top-[68px] left-0 right-0 z-[5] pointer-events-none opacity-60">
            <AimaStampStrip />
          </div>

          {/* Conversation scroll area */}
          <div
            ref={scrollerRef}
            className="absolute inset-0 overflow-y-auto pt-44 pb-44"
          >
            <div className="max-w-2xl mx-auto px-5 md:px-6 py-6 md:py-10 space-y-5">
              {messages.map((m, i) => (
                <MessageBlock
                  key={i}
                  message={m}
                  tint={tint}
                  onCloseAima={onClose}
                />
              ))}

              {loading && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex items-center gap-2 text-white/50 text-[13px] font-serif italic"
                >
                  <Sparkles className="w-3.5 h-3.5" style={{ color: tint }} />
                  Aïma tisse…
                </motion.div>
              )}

              {!loading && suggestions.length > 0 && (
                <AimaSuggestions
                  suggestions={suggestions}
                  accent={tint}
                  onPick={(s) => sendMessage(s)}
                />
              )}
            </div>
          </div>

          {/* Composer en bas */}
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.15, duration: 0.4 }}
            className="absolute bottom-0 left-0 right-0 px-4 md:px-6 pb-6 md:pb-8"
          >
            <div className="max-w-2xl mx-auto">
              <form
                onSubmit={handleSubmit}
                className="flex items-center gap-2 bg-white/8 backdrop-blur-md border border-white/15 rounded-full pl-5 pr-2 py-2"
                style={{ boxShadow: `0 8px 32px ${tint}25` }}
              >
                <input
                  ref={inputRef}
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Parle à Aïma…"
                  disabled={loading}
                  className="flex-1 bg-transparent text-white placeholder-white/40 text-[15px] font-sans focus:outline-none py-2"
                />
                <button
                  type="submit"
                  disabled={!input.trim() || loading}
                  className="w-10 h-10 rounded-full flex items-center justify-center transition-all disabled:opacity-30"
                  style={{ background: tint, color: "white" }}
                  aria-label="Envoyer"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>
              <div className="text-center mt-3 text-white/35 text-[10px] tracking-[0.2em] uppercase font-sans">
                Échap pour réduire · Aïma se souvient de cette conversation
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

/* ─────────────────────────────────────────────────────────── */
/* Bloc message individuel (texte + artefacts)                */
/* ─────────────────────────────────────────────────────────── */
function MessageBlock({ message, tint, onCloseAima }) {
  const isAima = message.role === "assistant";
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
    >
      {isAima ? (
        <div className="flex gap-3">
          <div
            className="w-7 h-7 rounded-full flex-shrink-0 flex items-center justify-center mt-0.5"
            style={{ background: `${tint}20` }}
          >
            <div
              className="w-1.5 h-1.5 rounded-full"
              style={{ background: tint }}
            />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-white/90 text-[15.5px] leading-relaxed font-serif italic">
              {message.content}
            </p>
            {message.artifacts?.map((a, i) => (
              <AimaArtifact key={i} artifact={a} onClose={onCloseAima} />
            ))}
          </div>
        </div>
      ) : (
        <div className="flex justify-end">
          <div
            className="max-w-[80%] rounded-2xl px-4 py-2.5 text-white text-[14.5px] font-sans"
            style={{
              background: `${tint}25`,
              border: `1px solid ${tint}50`
            }}
          >
            {message.content}
          </div>
        </div>
      )}
    </motion.div>
  );
}