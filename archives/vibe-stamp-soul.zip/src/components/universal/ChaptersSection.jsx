import React, { useState } from "react";
import { Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowRight } from "lucide-react";
import AimaIcon from "@/components/design-system/AimaIcons";

/**
 * Le Cœur battant — menu horizontal :
 *  · Playlist Mondiale (statistiques sonores universelles, fusionne avec Mémoire Mondiale)
 *  · Le Sceau (personnel ET d'union — AI+ME)
 *  · L'Écho (jour d'après)
 */

const CHAPTERS = [
  {
    id: "playlist",
    label: "Playlist Mondiale",
    n: "01",
    title: "Une synthèse",
    italic: "musicale, universelle.",
    desc:
      "Toutes les chansons déposées par les invités, anonymisées, alignées par moment. Une mémoire sonore mondiale — la pulsation de toutes les unions.",
    cta: "Explorer la mémoire",
    accent: "#2DBE94",
    gradient:
      "radial-gradient(ellipse at 70% 30%, rgba(45,190,148,0.55) 0%, transparent 55%), radial-gradient(ellipse at 20% 80%, rgba(20,140,100,0.45) 0%, transparent 55%)"
  },
  {
    id: "timbre",
    label: "Le Timbre",
    n: "02",
    title: "Votre identité,",
    italic: "timbrée et inscrite.",
    desc:
      "Le Timbre AIME® est votre signature dans le registre universel. Code unique, horodaté, géolocalisé, signé par charte. Chaque rencontre s'affranchit. AI + ME.",
    cta: "Créer mon Timbre",
    ctaHref: "/timbre/nouveau",
    accent: "#B8963E",
    gradient:
      "radial-gradient(ellipse at 60% 40%, rgba(184,150,62,0.55) 0%, transparent 55%), radial-gradient(ellipse at 20% 80%, rgba(220,180,120,0.5) 0%, transparent 55%)"
  },
  {
    id: "echo",
    label: "L'Écho",
    n: "03",
    title: "Le jour d'après,",
    italic: "tissé en récit.",
    desc:
      "Aïma rassemble les chansons, les souvenirs, les mots du livre d'or — et compose le récit du lendemain. L'écho continue à vibrer après la fin.",
    cta: "Lire l'écho",
    accent: "#A78BFA",
    gradient:
      "radial-gradient(ellipse at 40% 30%, rgba(140,120,255,0.5) 0%, transparent 55%), radial-gradient(ellipse at 80% 80%, rgba(255,90,170,0.5) 0%, transparent 55%)"
  }
];

// Mock data — statistiques musicales universelles (fictives en attendant les vraies)
const PLAYLIST_MOMENTS = [
  {
    moment: "Arrivée",
    icon: "spark",
    songs: [
      { t: "Here Comes The Sun", a: "The Beatles", count: 1284 },
      { t: "La Vie en Rose", a: "Édith Piaf", count: 982 },
      { t: "Cornelia Street", a: "Taylor Swift", count: 651 }
    ]
  },
  {
    moment: "Cérémonie",
    icon: "seal",
    songs: [
      { t: "All of Me", a: "John Legend", count: 2104 },
      { t: "A Thousand Years", a: "Christina Perri", count: 1792 },
      { t: "Mariage d'Amour", a: "Paul de Senneville", count: 1118 }
    ]
  },
  {
    moment: "Cocktail",
    icon: "note",
    songs: [
      { t: "Cheek to Cheek", a: "Ella Fitzgerald", count: 894 },
      { t: "L'Été Indien", a: "Joe Dassin", count: 712 },
      { t: "Sway", a: "Michael Bublé", count: 603 }
    ]
  },
  {
    moment: "Ouverture du bal",
    icon: "voice",
    songs: [
      { t: "Perfect", a: "Ed Sheeran", count: 3201 },
      { t: "At Last", a: "Etta James", count: 1456 },
      { t: "Can't Help Falling in Love", a: "Elvis Presley", count: 1289 }
    ]
  },
  {
    moment: "Nuit",
    icon: "memory",
    songs: [
      { t: "Don't Stop Me Now", a: "Queen", count: 4012 },
      { t: "Mr. Brightside", a: "The Killers", count: 2891 },
      { t: "Dancing Queen", a: "ABBA", count: 2734 }
    ]
  }
];

export default function ChaptersSection() {
  const [active, setActive] = useState("playlist");
  const chapter = CHAPTERS.find((c) => c.id === active);

  return (
    <section className="relative bg-[#0A0A0B] py-24 md:py-32 px-6 border-t border-white/5 overflow-hidden">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="font-sans text-[11px] tracking-[0.3em] uppercase text-orange-300 mb-4">
            Le cœur battant · AI + ME
          </div>
          <h2 className="apple-headline text-white text-4xl md:text-5xl lg:text-6xl">
            Trois chapitres,<br />
            <span className="font-serif italic font-normal text-white/70">une seule vibration.</span>
          </h2>
          <p className="mt-5 font-sans text-white/55 text-base max-w-xl mx-auto leading-snug">
            En arrivant ici, tu commences une union — d'abord avec toi-même, puis avec Aïma, puis avec les autres. Tout se relie.
          </p>
        </div>

        {/* Menu horizontal */}
        <div className="flex flex-wrap justify-center gap-2 mb-12">
          {CHAPTERS.map((c) => (
            <button
              key={c.id}
              onClick={() => setActive(c.id)}
              className={`px-5 py-2.5 rounded-full text-[13px] font-medium transition-all ${
                active === c.id
                  ? "bg-white text-stone-900 shadow-lg"
                  : "bg-white/[0.06] text-white/60 hover:bg-white/[0.12] hover:text-white/90 border border-white/10"
              }`}
            >
              {c.label}
            </button>
          ))}
        </div>

        {/* Stage */}
        <AnimatePresence mode="wait">
          <motion.div
            key={chapter.id}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.45 }}
            className="relative"
          >
            {/* Header chapitre */}
            <div className="text-center mb-10">
              <div className="font-sans text-[12px] text-white/40 mb-2">{chapter.n}</div>
              <h3 className="apple-headline text-white text-3xl md:text-4xl lg:text-5xl">
                {chapter.title}<br />
                <span className="font-serif italic font-normal text-white/75">{chapter.italic}</span>
              </h3>
              <p className="mt-5 font-sans text-white/65 text-[15px] md:text-[16px] max-w-xl mx-auto leading-relaxed">
                {chapter.desc}
              </p>
              {chapter.ctaHref ? (
                <Link
                  to={chapter.ctaHref}
                  className="mt-6 inline-flex items-center gap-1.5 text-[13px] font-medium hover:opacity-80 transition-opacity"
                  style={{ color: chapter.accent }}
                >
                  {chapter.cta} <ArrowRight className="w-4 h-4" />
                </Link>
              ) : (
                <div
                  className="mt-6 inline-flex items-center gap-1.5 text-[13px] font-medium"
                  style={{ color: chapter.accent }}
                >
                  {chapter.cta} <ArrowRight className="w-4 h-4" />
                </div>
              )}
            </div>

            {/* Contenu spécifique au chapitre */}
            {chapter.id === "playlist" && <PlaylistMondialeView accent={chapter.accent} />}
            {chapter.id === "timbre" && <TimbreView accent={chapter.accent} />}
            {chapter.id === "echo" && <EchoView accent={chapter.accent} />}
          </motion.div>
        </AnimatePresence>
      </div>
    </section>
  );
}

/* ─── Playlist Mondiale : vraies "stats" par moment ─── */
function PlaylistMondialeView({ accent }) {
  return (
    <div className="grid md:grid-cols-5 gap-3">
      {PLAYLIST_MOMENTS.map((m, i) => (
        <motion.div
          key={m.moment}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 + i * 0.06 }}
          className="rounded-2xl bg-white/[0.03] border border-white/10 p-5"
        >
          <div className="flex items-center gap-2 mb-4">
            <div
              className="w-7 h-7 rounded-lg flex items-center justify-center"
              style={{ backgroundColor: `${accent}20`, color: accent }}
            >
              <AimaIcon name={m.icon} size={14} />
            </div>
            <div className="text-white/90 text-[13px] font-medium font-sans">{m.moment}</div>
          </div>
          <div className="space-y-3">
            {m.songs.map((s, k) => (
              <div key={s.t}>
                <div className="flex items-baseline justify-between gap-2 mb-1">
                  <div className="text-white/85 text-[12.5px] font-medium font-sans truncate">{s.t}</div>
                  <div
                    className="text-[10.5px] font-sans flex-shrink-0"
                    style={{ color: accent }}
                  >
                    {s.count.toLocaleString("fr-FR")}
                  </div>
                </div>
                <div className="text-white/45 text-[11px] font-sans truncate mb-1.5">{s.a}</div>
                <div className="h-0.5 rounded-full bg-white/10 overflow-hidden">
                  <div
                    className="h-full rounded-full"
                    style={{
                      width: `${100 - k * 28}%`,
                      backgroundColor: accent
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      ))}
    </div>
  );
}

/* ─── Timbre : présentation du système d'identité AIME® ─── */
function TimbreView({ accent }) {
  const features = [
    {
      title: "Code unique horodaté",
      sub: "LM·X4K·9P2N",
      desc: "Format propriétaire AIME® · alphabet sans ambiguïté · empreinte cryptographique."
    },
    {
      title: "Charte signée",
      sub: "Engagement sur l'honneur",
      desc: "5 engagements à respecter pour entrer au registre. Consentements RGPD granulaires."
    },
    {
      title: "Registre universel",
      sub: "#000847",
      desc: "Numérotation continue mondiale. Mosaïque publique opt-in. Stockage UE conforme RGPD."
    }
  ];

  return (
    <div
      className="relative rounded-3xl overflow-hidden p-10 md:p-12"
      style={{ background: "radial-gradient(ellipse at 50% 50%, rgba(184,150,62,0.12), transparent 60%)" }}
    >
      <div className="grid md:grid-cols-3 gap-6">
        {features.map((s, i) => (
          <motion.div
            key={s.title}
            initial={{ opacity: 0, scale: 0.92 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.15 + i * 0.1 }}
            className="text-center"
          >
            <div
              className="mx-auto mb-5 rounded-2xl flex items-center justify-center border-2"
              style={{
                width: 96,
                height: 120,
                borderColor: `${accent}66`,
                color: accent,
                boxShadow: `0 0 0 4px ${accent}10, 0 0 40px ${accent}30`,
                background: "rgba(184,150,62,0.05)"
              }}
            >
              <div className="text-center">
                <div className="text-[8px] tracking-[3px] mb-1">AIME®</div>
                <div className="font-serif text-3xl">◈</div>
                <div className="text-[7px] tracking-[2px] mt-1 opacity-70">CERTIFIÉ</div>
              </div>
            </div>
            <div className="text-white/95 text-[15px] font-medium font-sans">{s.title}</div>
            <div
              className="text-[11px] font-mono tracking-widest mt-1 mb-3"
              style={{ color: accent }}
            >
              {s.sub}
            </div>
            <div className="text-white/60 text-[13px] font-sans leading-relaxed max-w-[260px] mx-auto">
              {s.desc}
            </div>
          </motion.div>
        ))}
      </div>
      <div className="text-center mt-10 flex flex-wrap justify-center gap-3">
        <Link
          to="/timbre/nouveau"
          className="px-7 py-3 rounded-full text-[11px] tracking-[3px] uppercase font-medium transition-colors"
          style={{ background: accent, color: "#1A1208" }}
        >
          Créer mon Timbre ✦
        </Link>
        <Link
          to="/registre"
          className="px-7 py-3 rounded-full border text-[11px] tracking-[3px] uppercase transition-colors"
          style={{ borderColor: `${accent}66`, color: accent }}
        >
          Voir le Registre
        </Link>
      </div>
    </div>
  );
}

/* ─── Écho : jour d'après ─── */
function EchoView({ accent }) {
  const fragments = [
    { kind: "Chanson", text: "Perfect — Ed Sheeran", source: "déposée par Camille" },
    { kind: "Mot", text: "« Je vous ai rarement vus aussi rayonnants. »", source: "livre d'or, Antoine" },
    { kind: "Photo", text: "L'instant du premier baiser", source: "captée par Léa" },
    { kind: "Toast", text: "« À ceux qui dansent jusqu'à l'aube. »", source: "discours du témoin" }
  ];

  return (
    <div className="max-w-3xl mx-auto space-y-3">
      {fragments.map((f, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, x: -8 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.15 + i * 0.08 }}
          className="flex items-start gap-4 p-5 rounded-2xl bg-white/[0.025] border border-white/10"
        >
          <div
            className="px-2.5 py-0.5 rounded-full text-[10px] font-medium font-sans flex-shrink-0 mt-1"
            style={{ backgroundColor: `${accent}20`, color: accent }}
          >
            {f.kind}
          </div>
          <div className="flex-1">
            <div className="text-white/90 text-[15px] font-serif italic leading-snug">{f.text}</div>
            <div className="text-white/40 text-[11.5px] font-sans mt-1">— {f.source}</div>
          </div>
        </motion.div>
      ))}
      <div className="pt-4 text-center">
        <div className="font-serif italic text-white/55 text-[14px]">
          Aïma tisse, raconte, conserve. L'écho continue.
        </div>
      </div>
    </div>
  );
}