import React from "react";
import EditableText from "@/components/edit/EditableText";

/**
 * SiteFooter — bandeau légal global, affiché tout en bas de chaque page.
 * Volontairement compact et sobre, pour ne jamais écraser un visuel.
 */
export default function SiteFooter() {
  return (
    <footer className="bg-[#050507] border-t border-white/10">
      <div className="max-w-7xl mx-auto px-6 md:px-10 py-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-white/40 font-sans text-[11px]">
        <EditableText
          slug="footer.copyright"
          label="Footer — copyright"
          page="/"
          as="div"
          defaultValue="© AIME® · 2026 · www.aime-wedding.com"
        />
        <div className="flex gap-5">
          <span>Charte</span>
          <span>Mentions légales</span>
          <span>Contact</span>
        </div>
      </div>
      <div className="px-6 pb-4 text-center text-[9px] tracking-[2px] text-white/25 uppercase">
        AIME® · Marque française déposée à l'INPI · n° 5164817 · n° 5226732 · Brevet en cours
      </div>
    </footer>
  );
}