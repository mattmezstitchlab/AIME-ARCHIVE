import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import FolderStamp from "./FolderStamp";

// Mapping nom de dossier → clé picto FolderIcons. Tout dossier inconnu retombe sur "default".
const FOLDER_ICON_MAP = {
  "Couples": "invites",
  "Invités": "invites",
  "Prestataires": "prestataires",
  "Lieux": "lieux",
  "Photos": "photos",
  "Contrats": "contrats",
  "Sceaux": "sceaux",
  "Mon Cabinet": "cabinet",
  "Cabinet": "cabinet",
  "Registre": "registre",
  "Le Registre": "registre",
  "Cachets": "cachets",
  "AEM": "aem",
  "Audiens": "audiens",
  "Pôle Emploi": "pole-emploi",
  "Fiscal": "fiscal",
  "MSA": "msa",
  "Bail": "bail",
  "Aides": "aides",
  "MDPH": "mdph",
  "Lettres RH": "lettres-rh",
  "Officialisation": "officialisation",
  "Cérémonie": "ceremonie",
  "Noyau": "noyau",
  "Music Rights": "music-rights"
};
const iconKey = (n) => FOLDER_ICON_MAP[n] || "default";

// Pages dédiées par slug — quand un Space ouvre sur sa propre page complète
const SPACE_PAGES = {
  mariage: { path: "/mariage", label: "Entrer dans la fenêtre Mariage →" },
  agriculteurs: { path: "/agriculteurs", label: "Entrer dans la fenêtre Agriculteurs →" },
  intermittents: { path: "/intermittents", label: "Entrer dans la fenêtre Intermittents →" },
  inclusive: { path: "/inclusive", label: "Entrer dans la fenêtre Inclusive →" },
  mairies: { path: "/mairies", label: "Entrer dans la fenêtre Mairies →" },
  memoire: { path: "/memoire", label: "Entrer dans la fenêtre Mémoire →" },
  noyau: { path: "/noyau", label: "Entrer dans le Noyau →" }
};

/**
 * FourSpacesSection — Fenêtres dynamiques chargées depuis l'entité Space.
 * Visibilité, ordre, contenu pilotés depuis l'admin (/admin → Fenêtres · espaces).
 */

// Fallback minimal utilisé seulement si la BDD ne répond pas.
// Les vraies données viennent de l'entité Space (pilotée depuis /admin → Fenêtres).
const FALLBACK_SPACES = [
  {
    id: "mariage",
    label: "Mariage",
    eyebrow: "Espace Mariage",
    title: "Le mariage,",
    italic: "et tout ce qui le tient ensemble.",
    desc: "Aïma orchestre les quatre rôles : Couples · Invités · Prestataires · Lieux. Une seule présence, quatre fenêtres, le même fil rouge.",
    bg: "https://res.cloudinary.com/divou1vcx/image/upload/v1777698965/pexels-rothemba-vele-1414849-18041569_pps4us.jpg",
    accent: "#D4A574",
    folders: [
      { name: "Couples", count: 1, palette: "kraft" },
      { name: "Invités", count: 84, palette: "moss" },
      { name: "Prestataires", count: 7, palette: "wine" },
      { name: "Lieux", count: 1, palette: "ink" }
    ],
    modules: []
  }
];

// Map DB Space → shape utilisée par la section
const fromDb = (s) => ({
  id: s.slug,
  label: s.label,
  eyebrow: s.eyebrow,
  title: s.title,
  italic: s.italic,
  desc: s.description,
  bg: s.bg_url,
  accent: s.accent_color,
  badge: s.badge,
  phase: s.phase || "live",
  folders: s.folders || [],
  modules: s.modules || []
});

export default function FourSpacesSection() {
  const [active, setActive] = useState(0);
  const [paused, setPaused] = useState(false);
  const [spaces, setSpaces] = useState(FALLBACK_SPACES);

  // Charge TOUTES les fenêtres (live + soon + lab) — l'admin contrôle is_visible
  // mais on les affiche toutes pour donner un aperçu de l'écosystème complet.
  useEffect(() => {
    base44.entities.Space.list("order_index", 20)
      .then((rows) => {
        if (rows && rows.length) {
          // visibles d'abord, puis bientôt, puis lab
          const order = { live: 0, soon: 1, lab: 2 };
          const sorted = [...rows].sort((a, b) => {
            const pa = order[a.phase || "live"] ?? 0;
            const pb = order[b.phase || "live"] ?? 0;
            if (pa !== pb) return pa - pb;
            return (a.order_index || 0) - (b.order_index || 0);
          });
          setSpaces(sorted.map(fromDb));
        }
      })
      .catch(() => { /* fallback en place */ });
  }, []);

  const space = spaces[active] || spaces[0];
  const liveCount = spaces.filter((s) => s.phase === "live" || !s.phase).length;

  // Auto-advance entre les fenêtres LIVE uniquement
  useEffect(() => {
    if (paused || liveCount <= 1) return;
    const t = setInterval(() => setActive((a) => ((a + 1) % liveCount)), 7000);
    return () => clearInterval(t);
  }, [paused, liveCount]);

  // Reset si l'index courant dépasse la nouvelle liste
  useEffect(() => {
    if (active >= spaces.length) setActive(0);
  }, [spaces.length, active]);

  if (!space) return null;

  return (
    <section
      className="relative bg-[#0A0A0B] overflow-hidden pt-20 md:pt-24"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
    >
      {/* FULL-BLEED background image — sort à gauche et à droite jusqu'aux extrémités */}
      <AnimatePresence mode="wait">
        <motion.div
          key={space.id + "-bg"}
          initial={{ opacity: 0, scale: 1.05 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
          className="absolute inset-0"
        >
          <img
            src={space.bg}
            alt=""
            className="absolute inset-0 w-full h-full object-cover"
            aria-hidden="true"
          />
          <div
            className="absolute inset-0"
            style={{
              background:
                "linear-gradient(180deg, rgba(10,10,11,0.75) 0%, rgba(10,10,11,0.55) 35%, rgba(10,10,11,0.7) 70%, rgba(10,10,11,0.95) 100%)"
            }}
          />
          <svg className="absolute inset-0 w-full h-full opacity-[0.05] mix-blend-overlay pointer-events-none">
            <filter id={`fs-grain-${space.id}`}>
              <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" stitchTiles="stitch" />
              <feColorMatrix values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 0.5 0" />
            </filter>
            <rect width="100%" height="100%" filter={`url(#fs-grain-${space.id})`} />
          </svg>
        </motion.div>
      </AnimatePresence>

      <div className="relative max-w-6xl mx-auto py-8 md:py-8 px-5 md:px-6 pb-32 md:pb-8">
        {/* STAGE — content only. pb-32 sur mobile pour laisser de la place au bouton flottant Aïma. */}
        <div className="relative min-h-[auto] md:min-h-[440px]">
          <div className="relative z-10">
            <AnimatePresence mode="wait">
              <motion.div
                key={space.id}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.45 }}
                className="text-center flex flex-col items-center"
              >
                {/* Eyebrow — uniquement le nom de l'espace, sans badges */}
                <div className="flex items-center justify-center gap-3 mb-4">
                  <span
                    className="inline-block w-1.5 h-1.5 rounded-full animate-pulse"
                    style={{ backgroundColor: space.accent }}
                  />
                  <span className="font-sans text-[11px] tracking-[0.25em] uppercase text-white/55">
                    {space.eyebrow}
                  </span>
                </div>

                {/* Title */}
                <h3 className="apple-headline text-white text-3xl md:text-5xl lg:text-6xl max-w-3xl mx-auto px-2">
                  {space.title}<br />
                  <span className="text-white/75">{space.italic}</span>
                </h3>

                {/* Folders strip — descendus pour ne pas cacher les visages des visuels */}
                <div className="mt-32 md:mt-48 w-full">
                  <div className="font-sans text-[10px] tracking-[0.3em] uppercase text-white/40 mb-3 text-center">
                    Tes dossiers
                  </div>
                  <div className="flex flex-wrap gap-4 md:gap-5 justify-center">
                    {space.folders.map((f) => (
                      <FolderStamp
                        key={f.name}
                        name={f.name}
                        icon={iconKey(f.name)}
                        palette={f.palette}
                        count={f.count}
                        size="sm"
                      />
                    ))}
                  </div>
                </div>

              </motion.div>
            </AnimatePresence>
          </div>
        </div>

        {/* Navigation 9 fenêtres — en bas, horizontale, avec point coloré accent */}
        <div className="mt-10 flex flex-wrap gap-1.5 justify-center">
          {spaces.map((s, i) => {
            const isLive = !s.phase || s.phase === "live";
            const phaseLabel = s.phase === "soon" ? "bientôt" : s.phase === "lab" ? "labo" : null;
            const HOVER_TOOLTIPS = {
              agriculteurs: "Pour ceux qui nourrissent le monde."
            };
            const isActive = active === i;
            return (
              <button
                key={s.id}
                onClick={() => setActive(i)}
                title={HOVER_TOOLTIPS[s.slug] || ""}
                className={`group px-3 py-1.5 rounded-full text-[11.5px] font-medium transition-all flex items-center gap-2 border ${
                  isActive
                    ? "shadow-lg"
                    : isLive
                    ? "bg-white/[0.06] text-white/60 hover:bg-white/[0.12] hover:text-white/90 border-white/10"
                    : "bg-white/[0.02] text-white/40 hover:bg-white/[0.06] hover:text-white/60 border-white/5"
                }`}
                style={
                  isActive
                    ? {
                        backgroundColor: `${s.accent || s.accent_color || "#fff"}18`,
                        borderColor: `${s.accent || s.accent_color || "#fff"}55`,
                        color: s.accent || s.accent_color || "#fff"
                      }
                    : undefined
                }
              >
                {/* Point coloré accent — toujours pleine intensité */}
                <span
                  className="w-1.5 h-1.5 rounded-full flex-shrink-0"
                  style={{
                    backgroundColor: s.accent || s.accent_color || "rgba(255,255,255,0.4)"
                  }}
                />
                {s.label}
                {phaseLabel && (
                  <span
                    className="text-[8px] tracking-wider uppercase px-1 py-0.5 rounded-full"
                    style={{
                      backgroundColor: "rgba(255,255,255,0.08)",
                      color: "rgba(255,255,255,0.5)"
                    }}
                  >
                    {phaseLabel}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
}