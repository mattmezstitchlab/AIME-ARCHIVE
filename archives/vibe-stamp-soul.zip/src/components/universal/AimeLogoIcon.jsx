import React from "react";
import { motion } from "framer-motion";

/**
 * AimeLogoIcon — Forme animée qui boucle entre cœur, cercle, carré, triangle.
 * Toutes les formes sont définies en polygon() à 12 points pour permettre
 * à framer-motion d'interpoler fluide entre elles.
 */

const HEART =
  "polygon(50% 25%, 63% 14%, 80% 14%, 93% 28%, 93% 47%, 76% 65%, 50% 88%, 24% 65%, 7% 47%, 7% 28%, 20% 14%, 37% 14%)";

const CIRCLE =
  "polygon(50% 0%, 75% 7%, 93% 25%, 100% 50%, 93% 75%, 75% 93%, 50% 100%, 25% 93%, 7% 75%, 0% 50%, 7% 25%, 25% 7%)";

const SQUARE =
  "polygon(0% 0%, 33% 0%, 67% 0%, 100% 0%, 100% 33%, 100% 67%, 100% 100%, 67% 100%, 33% 100%, 0% 100%, 0% 67%, 0% 33%)";

const TRIANGLE =
  "polygon(50% 0%, 63% 25%, 75% 50%, 88% 75%, 100% 100%, 75% 100%, 50% 100%, 25% 100%, 0% 100%, 13% 75%, 25% 50%, 38% 25%)";

const SEQUENCE = [HEART, CIRCLE, SQUARE, TRIANGLE, HEART];

export default function AimeLogoIcon({ size = 16, color = "white" }) {
  return (
    <motion.div
      aria-hidden
      animate={{ clipPath: SEQUENCE }}
      whileHover={{ scale: 1.14, opacity: 1 }}
      transition={{
        clipPath: {
          duration: 8,
          ease: "easeInOut",
          times: [0, 0.25, 0.5, 0.75, 1],
          repeat: Infinity,
          repeatType: "loop"
        },
        scale: { duration: 0.28, ease: [0.25, 0.46, 0.45, 0.94] },
        opacity: { duration: 0.2 }
      }}
      style={{
        width: size,
        height: size,
        backgroundColor: color,
        opacity: 0.9,
        flexShrink: 0
      }}
    />
  );
}