import React, { useState, useEffect, useRef } from "react";
import { Link, useLocation } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { base44 } from "@/api/base44Client";
import AimeLogoIcon from "./AimeLogoIcon";

/**
 * GlobalHeader — Navigation persistante sur toutes les pages.
 * Logo · Espaces ▾ (mega-menu — Mariage + autres fenêtres AIME®) · Mon Cabinet · Le Registre
 * Variante "transparent" sur la home (over video), "solid" sur les pages internes.
 */

// Pages dédiées par slug — étendre quand de nouvelles pages sont créées
const SPACE_PAGES = {
  agriculteurs: "/agriculteurs",
  intermittents: "/intermittents",
  inclusive: "/inclusive",
  mairies: "/mairies",
  memoire: "/memoire",
  noyau: "/noyau"
};

// Slugs Space fusionnés dans l'entrée hardcodée "Mariage" → /mariage
// "mariage" est aussi inclus pour éviter le doublon avec l'entrée Space en base
const MARIAGE_SLUGS = ["mariage", "couples", "guests", "pros", "venues"];

// Slugs Space cachés du menu (doublons traités via une page dédiée)
const HIDDEN_SLUGS = ["agriculteurs"];

// Liens additionnels (non-Space) à intégrer dans le menu Espaces
const EXTRA_LINKS = [
  {
    id: "agriculteurs",
    label: "Agriculteurs",
    eyebrow: "Pour ceux qui nourrissent le monde",
    path: "/agriculteurs",
    accent: "#B89A52"
  },
  {
    id: "music-rights",
    label: "Music Rights",
    eyebrow: "Vos droits méritent d'être timbrés",
    path: "/music-rights",
    accent: "#B89A52"
  }
];

export default function GlobalHeader({ variant = "solid" }) {
  const location = useLocation();
  const [openMenu, setOpenMenu] = useState(false);
  const [spaces, setSpaces] = useState([]);
  const menuRef = useRef(null);

  useEffect(() => {
    base44.entities.Space.list("order_index", 20)
      .then((rows) => {
        if (rows?.length) {
          const order = { live: 0, soon: 1, lab: 2 };
          const sorted = [...rows].sort((a, b) => {
            const pa = order[a.phase || "live"] ?? 0;
            const pb = order[b.phase || "live"] ?? 0;
            if (pa !== pb) return pa - pb;
            return (a.order_index || 0) - (b.order_index || 0);
          });
          setSpaces(sorted);
        }
      })
      .catch(() => {});
  }, []);

  // Close menu on route change
  useEffect(() => { setOpenMenu(false); }, [location.pathname]);

  // Close on outside click
  useEffect(() => {
    const onClick = (e) => {
      if (menuRef.current && !menuRef.current.contains(e.target)) setOpenMenu(false);
    };
    if (openMenu) document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, [openMenu]);

  const isTransparent = variant === "transparent";
  const textColor = isTransparent ? "text-white/85" : "text-stone-800";
  const textHover = isTransparent ? "hover:text-white" : "hover:text-stone-950";
  const bgClass = isTransparent
    ? "bg-transparent"
    : "bg-white/85 backdrop-blur-xl border-b border-stone-200/70";

  return (
    <header className={`relative z-30 ${bgClass}`}>
      <div className="max-w-7xl mx-auto px-6 md:px-10 py-4 flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2.5 flex-shrink-0">
          <AimeLogoIcon size={20} color={isTransparent ? "white" : "#1a1208"} />
          <div className={`text-[15px] font-semibold tracking-tight ${isTransparent ? "text-white" : "text-stone-900"}`}>
            AIME<sup className="text-[9px] font-normal opacity-70 ml-0.5">®</sup>
            <span className={`font-normal ml-1 ${isTransparent ? "text-white/70" : "text-stone-500"}`}>
              Wedding
            </span>
          </div>
        </Link>

        {/* Nav */}
        <nav className="flex items-center gap-1 md:gap-2">
          {/* Fenêtres ▾ */}
          <div ref={menuRef} className="relative">
            <button
              onClick={() => setOpenMenu((o) => !o)}
              className={`flex items-center gap-1.5 px-3 md:px-4 py-2 rounded-full text-[12px] tracking-[0.1em] uppercase font-medium transition-colors ${textColor} ${textHover} ${
                openMenu
                  ? isTransparent ? "bg-white/10" : "bg-stone-100"
                  : ""
              }`}
            >
              Espaces
              <svg width="10" height="10" viewBox="0 0 12 12" fill="none" className={`transition-transform ${openMenu ? "rotate-180" : ""}`}>
                <path d="M2 4l4 4 4-4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </button>

            <AnimatePresence>
              {openMenu && (
                <motion.div
                  initial={{ opacity: 0, y: -8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.18 }}
                  className="absolute top-full mt-2 right-0 md:right-auto md:left-0 w-[min(92vw,320px)] rounded-2xl bg-white border border-stone-200 shadow-[0_24px_64px_rgba(0,0,0,0.18)] overflow-hidden"
                >
                  <div className="px-4 py-3 border-b border-stone-100 bg-stone-50">
                    <div className="text-[10px] tracking-[0.25em] uppercase text-stone-500 font-medium">
                      Les espaces AIME®
                    </div>
                  </div>
                  <div className="max-h-[70vh] overflow-y-auto p-2 grid grid-cols-1 gap-1">
                    {/* Entrée fusionnée Union (couples + invités + pros + lieux + mémoire d'union) */}
                    <Link
                      to="/mariage"
                      onClick={() => setOpenMenu(false)}
                      className="flex items-start gap-3 px-3 py-2.5 rounded-lg hover:bg-stone-50 transition-colors group"
                    >
                      <div
                        className="w-2 h-2 rounded-full mt-1.5 flex-shrink-0"
                        style={{ backgroundColor: "#D4A574" }}
                      />
                      <div className="flex-1 min-w-0">
                        <span className="text-[13px] font-medium text-stone-900 group-hover:text-stone-950">
                          Union
                        </span>
                        <div className="text-[11px] text-stone-500 truncate">
                          Couples · Invités · Prestataires · Lieux · Mémoire
                        </div>
                      </div>
                    </Link>

                    {/* Autres espaces — on filtre les 4 fenêtres déjà incluses dans Mariage et les doublons cachés */}
                    {spaces
                      .filter((s) => !MARIAGE_SLUGS.includes(s.slug) && !HIDDEN_SLUGS.includes(s.slug))
                      .map((s) => {
                        const path = SPACE_PAGES[s.slug] || `/#${s.slug}`;
                        const phaseLabel = s.phase === "soon" ? "bientôt" : s.phase === "lab" ? "labo" : null;
                        return (
                          <Link
                            key={s.id}
                            to={path}
                            onClick={() => setOpenMenu(false)}
                            className="flex items-start gap-3 px-3 py-2.5 rounded-lg hover:bg-stone-50 transition-colors group"
                          >
                            <div
                              className="w-2 h-2 rounded-full mt-1.5 flex-shrink-0"
                              style={{ backgroundColor: s.accent_color || "#999" }}
                            />
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-1.5">
                                <span className="text-[13px] font-medium text-stone-900 group-hover:text-stone-950">
                                  {s.label}
                                </span>
                                {phaseLabel && (
                                  <span className="text-[8px] tracking-wider uppercase px-1.5 py-0.5 rounded-full bg-stone-100 text-stone-500">
                                    {phaseLabel}
                                  </span>
                                )}
                              </div>
                              {s.eyebrow && (
                                <div className="text-[11px] text-stone-500 truncate">{s.eyebrow}</div>
                              )}
                            </div>
                          </Link>
                        );
                      })}

                    {/* Liens additionnels (Music Rights, etc.) */}
                    {EXTRA_LINKS.length > 0 && (
                      <div className="mt-1 pt-2 border-t border-stone-100">
                        {EXTRA_LINKS.map((l) => (
                          <Link
                            key={l.id}
                            to={l.path}
                            onClick={() => setOpenMenu(false)}
                            className="flex items-start gap-3 px-3 py-2.5 rounded-lg hover:bg-stone-50 transition-colors group"
                          >
                            <div
                              className="w-2 h-2 rounded-full mt-1.5 flex-shrink-0"
                              style={{ backgroundColor: l.accent }}
                            />
                            <div className="flex-1 min-w-0">
                              <span className="text-[13px] font-medium text-stone-900 group-hover:text-stone-950">
                                {l.label}
                              </span>
                              {l.eyebrow && (
                                <div className="text-[11px] text-stone-500 truncate">{l.eyebrow}</div>
                              )}
                            </div>
                          </Link>
                        ))}
                      </div>
                    )}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

        </nav>
      </div>
    </header>
  );
}