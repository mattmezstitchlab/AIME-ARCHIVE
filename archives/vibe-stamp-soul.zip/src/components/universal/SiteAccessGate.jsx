import React, { useEffect, useState } from "react";
import { useLocation, Navigate } from "react-router-dom";
import { loadAccessConfig, evaluateAccess } from "@/lib/siteAccess";

/**
 * SiteAccessGate — vérifie le mode d'accès global et le statut de la page courante.
 * Si bloquée → redirige vers /noyau (countdown Yourcenar).
 * Si maintenance → écran de maintenance sobre.
 * Sinon → laisse passer.
 */
export default function SiteAccessGate({ children }) {
  const location = useLocation();
  const [config, setConfig] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    loadAccessConfig().then((c) => {
      if (mounted) {
        setConfig(c);
        setLoading(false);
      }
    });
    return () => { mounted = true; };
  }, [location.pathname]);

  if (loading) return null;

  const { allowed, redirect, reason } = evaluateAccess(location.pathname, config);

  if (!allowed && redirect) {
    return <Navigate to={redirect} replace />;
  }

  if (!allowed && reason === "maintenance") {
    return <MaintenanceScreen />;
  }

  return children;
}

function MaintenanceScreen() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-[#07060A] text-white px-8 text-center">
      <div>
        <div className="text-[10px] tracking-[0.3em] uppercase text-white/30 mb-6">
          AIME® · Maintenance
        </div>
        <p
          className="font-light italic text-white/70 leading-relaxed max-w-md mx-auto"
          style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(18px, 2.5vw, 24px)" }}
        >
          Cette page est en maintenance.
          <br />
          Aïma s'occupe de la remettre en ordre.
        </p>
        <a
          href="/"
          className="inline-block mt-10 px-6 py-2.5 rounded-full border border-white/20 text-[10px] tracking-[0.18em] uppercase text-white/70 hover:border-white/45 hover:text-white transition-all"
        >
          ← Retour
        </a>
      </div>
    </div>
  );
}