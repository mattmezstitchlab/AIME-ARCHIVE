import React from "react";
import { motion } from "framer-motion";
import FolderIcon from "@/components/design-system/FolderIcons";

/**
 * FolderStamp — un petit bijou.
 * Cercle-tampon doré, picto monoline centré, halo couleur palette,
 * filigrane AIME® minuscule en bas, animation de sceau au hover/clic.
 *
 * Props :
 *   name         : libellé visible (ex. "Prestataires")
 *   icon         : clé du picto FolderIcons (ex. "prestataires")
 *   palette      : kraft | moss | navy | wine | plum | ink | gold
 *   count        : nombre de docs (optionnel) — point coloré + chiffre
 *   active       : boolean — état ouvert
 *   empty        : boolean — pas encore de contenu (point gris)
 *   size         : "sm" | "md"
 *   onClick
 */

const PALETTES = {
  kraft: { halo: "#A56A3E", glow: "rgba(217,163,106,0.35)" },
  moss:  { halo: "#3F5E48", glow: "rgba(122,153,133,0.32)" },
  navy:  { halo: "#2E4566", glow: "rgba(107,131,166,0.32)" },
  wine:  { halo: "#7A2E3C", glow: "rgba(176,112,125,0.32)" },
  plum:  { halo: "#4A2E5C", glow: "rgba(126,94,148,0.32)" },
  ink:   { halo: "#2A2A2E", glow: "rgba(120,120,128,0.30)" },
  gold:  { halo: "#B89A52", glow: "rgba(212,180,131,0.42)" }
};

const RING = "#D4B483"; // doré tampon

export default function FolderStamp({
  name,
  icon = "default",
  palette = "gold",
  count,
  active = false,
  empty = false,
  size = "md",
  onClick
}) {
  const c = PALETTES[palette] || PALETTES.gold;
  const dim = size === "sm" ? 64 : 76;
  const iconSize = size === "sm" ? 22 : 26;

  return (
    <motion.button
      type="button"
      onClick={onClick}
      initial={{ opacity: 0, scale: 0.92 }}
      animate={{ opacity: 1, scale: 1 }}
      whileHover={{ y: -2 }}
      whileTap={{ scale: 0.96, rotate: -8 }}
      transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
      className="group relative inline-flex flex-col items-center gap-1.5 cursor-pointer focus:outline-none"
      style={{ width: dim + 28 }}
      title={name}
    >
      {/* Halo couleur palette derrière le tampon */}
      <span
        className="absolute top-0 left-1/2 -translate-x-1/2 rounded-full pointer-events-none transition-opacity duration-300"
        style={{
          width: dim + 16,
          height: dim + 16,
          background: `radial-gradient(circle, ${c.glow} 0%, transparent 70%)`,
          opacity: active ? 1 : 0.55,
          filter: "blur(2px)"
        }}
      />

      {/* Le tampon — cercle doré avec picto centré */}
      <motion.div
        animate={active ? { rotate: 6 } : { rotate: 0 }}
        transition={{ duration: 0.4 }}
        className="relative rounded-full flex items-center justify-center"
        style={{
          width: dim,
          height: dim,
          background: `radial-gradient(circle at 35% 30%, rgba(255,255,255,0.06), rgba(0,0,0,0.25))`,
          border: `1.5px solid ${active ? RING : "rgba(212,180,131,0.55)"}`,
          boxShadow: active
            ? `0 0 0 3px ${c.glow}, 0 8px 24px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.06)`
            : `0 4px 14px rgba(0,0,0,0.45), inset 0 1px 0 rgba(255,255,255,0.05)`,
          color: active ? RING : "rgba(231,213,168,0.92)"
        }}
      >
        {/* Anneau intérieur fin (effet sceau) */}
        <span
          className="absolute rounded-full pointer-events-none"
          style={{
            top: 5, left: 5, right: 5, bottom: 5,
            border: `0.5px solid ${active ? "rgba(212,180,131,0.55)" : "rgba(212,180,131,0.30)"}`
          }}
        />

        {/* Picto */}
        <FolderIcon name={icon} size={iconSize} strokeWidth={1.6} />

        {/* Pastille count en haut-droite */}
        {count !== undefined && count > 0 && (
          <span
            className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full flex items-center justify-center text-[10px] font-medium font-sans"
            style={{
              background: c.halo,
              color: "white",
              border: "1.5px solid #0A0A0B",
              lineHeight: 1
            }}
          >
            {count}
          </span>
        )}

        {/* Point état "vide" (gris discret en bas) */}
        {empty && (
          <span
            className="absolute bottom-2 w-1 h-1 rounded-full"
            style={{ background: "rgba(255,255,255,0.25)" }}
          />
        )}

        {/* Filigrane AIME® minuscule en arc bas — signature */}
        <svg
          className="absolute inset-0 w-full h-full pointer-events-none"
          viewBox="0 0 100 100"
          aria-hidden="true"
        >
          <defs>
            <path id={`stamp-arc-${name}`} d="M 18 60 A 32 32 0 0 0 82 60" fill="none" />
          </defs>
          <text
            fill={active ? "rgba(212,180,131,0.55)" : "rgba(212,180,131,0.30)"}
            style={{ fontSize: 6.5, letterSpacing: "0.25em", fontFamily: "var(--font-sans)", fontWeight: 500 }}
          >
            <textPath href={`#stamp-arc-${name}`} startOffset="50%" textAnchor="middle">
              AIME®
            </textPath>
          </text>
        </svg>
      </motion.div>

      {/* Libellé sous le tampon */}
      <div
        className={`text-[10.5px] font-sans tracking-[0.08em] text-center leading-tight transition-colors ${
          active ? "text-white" : "text-white/70 group-hover:text-white/95"
        }`}
        style={{ maxWidth: dim + 20 }}
      >
        {name}
      </div>
    </motion.button>
  );
}