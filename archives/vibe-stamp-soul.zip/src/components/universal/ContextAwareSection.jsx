import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import AimaIcon from "@/components/design-system/AimaIcons";
import FolderStamp from "./FolderStamp";

const CTX_ICON_MAP = {
  "Prestataires": "prestataires",
  "Invités": "invites",
  "Contrats": "contrats",
  "Photos": "photos",
  "Sceaux": "sceaux"
};

/**
 * ContextAwareSection — inspirée de Perplexity Comet "Context aware".
 * Démontre que la barre Aïma est le seul espace : sous chaque picto,
 * un tiroir s'ouvre (apps, dossiers, photos, fichiers, joindre, voix).
 *
 * 4 démos qui défilent automatiquement, ou cliquables manuellement.
 */

const DEMOS = [
  {
    id: "apps",
    icon: "spark",
    eyebrow: "Aïma sait ce qui se passe",
    title: "Espaces vivants.",
    italic: "ouverts au bon moment.",
    desc: "Aïma comprend ce que tu cherches et ouvre le bon espace. Tu ne navigues pas — elle navigue pour toi.",
    placeholder: "Cherche-moi un photographe…",
    drawer: "tools",
    tools: [
      { icon: "compose", label: "Trouver un prestataire" },
      { icon: "bubble", label: "Voir les invités" },
      { icon: "note", label: "Composer la playlist" },
      { icon: "seal", label: "Préparer le sceau" },
      { icon: "memory", label: "Lire la mémoire" }
    ]
  },
  {
    id: "folders",
    icon: "memory",
    eyebrow: "Tes dossiers, déjà classés",
    title: "Dossiers,",
    italic: "rangés par Aïma.",
    desc: "Prestataires, invités, devis, contrats, photos. Aïma archive en silence — quand tu demandes, elle ouvre.",
    placeholder: "Montre-moi les prestataires retenus…",
    drawer: "folders",
    folders: [
      { name: "Prestataires", count: 7, palette: "kraft" },
      { name: "Invités", count: 84, palette: "moss" },
      { name: "Contrats", count: 3, palette: "navy" },
      { name: "Photos", count: 26, palette: "wine" },
      { name: "Sceaux", count: 1, palette: "plum" }
    ]
  },
  {
    id: "vendors",
    icon: "compose",
    eyebrow: "Cartes vivantes",
    title: "Prestataires,",
    italic: "présentés par Aïma.",
    desc: "Pas de listings froids. Aïma te présente trois options qu'elle juge pertinentes, avec photo, sceau, et un mot.",
    placeholder: "Photographe, style intime, Sud-Ouest…",
    drawer: "vendors",
    vendors: [
      {
        name: "Léa Marquez",
        craft: "Photographe",
        location: "Bordeaux",
        photo: "https://images.unsplash.com/photo-1554080353-a576cf803bda?w=400&q=80",
        sigil: "◇",
        note: "Lumière douce, lien intime",
        match: 96
      },
      {
        name: "Théo Noyer",
        craft: "DJ · vinyles",
        location: "Lyon",
        photo: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400&q=80",
        sigil: "✦",
        note: "Soul, slow disco, rare grooves",
        match: 91
      },
      {
        name: "Atelier Salines",
        craft: "Traiteur",
        location: "Arcachon",
        photo: "https://images.unsplash.com/photo-1555244162-803834f70033?w=400&q=80",
        sigil: "◈",
        note: "Cuisine du marché, table d'hôtes",
        match: 88
      }
    ]
  },
  {
    id: "files",
    icon: "attach",
    eyebrow: "Pièces jointes",
    title: "Documents,",
    italic: "lus et compris.",
    desc: "Glisse un contrat, une liste d'invités, une photo de décor — Aïma lit, retient, intègre. Sans formulaire.",
    placeholder: "Voici le devis du fleuriste…",
    drawer: "files",
    files: [
      { name: "Devis_Fleuriste.pdf", kind: "PDF", size: "248 Ko" },
      { name: "Liste_invités.csv", kind: "CSV", size: "12 Ko" },
      { name: "Inspirations.jpg", kind: "Image", size: "1.4 Mo" }
    ]
  }
];

export default function ContextAwareSection() {
  const [active, setActive] = useState(0);

  // auto-advance every 5s
  useEffect(() => {
    const t = setInterval(() => setActive((a) => (a + 1) % DEMOS.length), 5000);
    return () => clearInterval(t);
  }, []);

  const demo = DEMOS[active];

  return (
    <section className="relative bg-[#0A0A0B] py-20 md:py-32 px-5 md:px-6 overflow-hidden">
      {/* ambient gradient */}
      <div
        className="absolute inset-0 pointer-events-none opacity-60"
        style={{
          background:
            "radial-gradient(ellipse at 20% 30%, rgba(60,120,90,0.25) 0%, transparent 50%), radial-gradient(ellipse at 80% 70%, rgba(120,80,180,0.2) 0%, transparent 55%)"
        }}
      />
      {/* grain */}
      <svg className="absolute inset-0 w-full h-full opacity-[0.04] mix-blend-overlay pointer-events-none" aria-hidden="true">
        <filter id="ctx-grain">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" stitchTiles="stitch" />
          <feColorMatrix values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 0.5 0" />
        </filter>
        <rect width="100%" height="100%" filter="url(#ctx-grain)" />
      </svg>

      <div className="relative max-w-6xl mx-auto">
        {/* Eyebrow + headline */}
        <div className="text-center mb-14">
          <div className="font-sans text-[11px] tracking-[0.3em] uppercase text-emerald-400/80 mb-4">
            Un seul espace · tout passe par Aïma
          </div>
          <h2 className="apple-headline text-white text-4xl md:text-5xl lg:text-6xl">
            Ton compte,<br />
            <span className="text-white/70">c'est cette fenêtre.</span>
          </h2>
          <p className="mt-5 font-sans text-white/55 text-base md:text-lg max-w-xl mx-auto leading-snug">
            Pas de menus, pas de pages. Sous chaque picto, Aïma ouvre exactement ce qu'il faut — un dossier, une carte, un fichier — pile au bon moment.
          </p>
        </div>

        {/* DEMO STAGE — sans encadré, plus aéré */}
        <div className="relative flex flex-col">
          {/* Tab switcher */}
          <div className="flex flex-wrap gap-1.5 md:gap-2 mb-8 md:mb-10 justify-center">
            {DEMOS.map((d, i) => (
              <button
                key={d.id}
                onClick={() => setActive(i)}
                className={`px-3 md:px-4 py-1.5 md:py-2 rounded-full text-[11px] md:text-[12px] font-medium transition-all flex items-center gap-1.5 md:gap-2 ${
                  active === i
                    ? "bg-white text-stone-900"
                    : "bg-white/[0.06] text-white/60 hover:bg-white/[0.12] hover:text-white/90 border border-white/10"
                }`}
              >
                <AimaIcon name={d.icon} size={13} />
                {d.eyebrow.split(",")[0]}
              </button>
            ))}
          </div>

          {/* Stage content */}
          <div className="flex-1 grid grid-cols-1 md:grid-cols-[1fr_1.3fr] gap-8 md:gap-10 items-center">
            {/* LEFT — narrative */}
            <AnimatePresence mode="wait">
              <motion.div
                key={demo.id}
                initial={{ opacity: 0, x: -16 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 16 }}
                transition={{ duration: 0.4 }}
              >
                <div className="font-sans text-[11px] tracking-[0.25em] uppercase text-white/40 mb-3">
                  {demo.eyebrow}
                </div>
                <h3 className="apple-headline text-white text-2xl md:text-4xl">
                  {demo.title}<br />
                  <span className="text-white/65">{demo.italic}</span>
                </h3>
                <p className="mt-4 md:mt-5 font-sans text-white/60 text-[14px] md:text-[15px] leading-relaxed max-w-md">
                  {demo.desc}
                </p>
              </motion.div>
            </AnimatePresence>

            {/* RIGHT — interactive bar mockup */}
            <div className="relative">
              <BarMockup demo={demo} />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ─── BAR MOCKUP ─── (the bar + drawer that opens above) */
function BarMockup({ demo }) {
  return (
    <div className="relative">
      <AnimatePresence mode="wait">
        {/* Drawer that opens above the bar */}
        <motion.div
          key={demo.id + "-drawer"}
          initial={{ opacity: 0, y: 12, scale: 0.97 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -8, scale: 0.97 }}
          transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
          className="mb-3"
        >
          <Drawer demo={demo} />
        </motion.div>
      </AnimatePresence>

      {/* The bar itself */}
      <div className="rounded-[20px] md:rounded-[22px] bg-white shadow-[0_2px_4px_rgba(0,0,0,0.06),0_8px_32px_rgba(0,0,0,0.4),0_24px_64px_rgba(0,0,0,0.35)] backdrop-blur-xl">
        <div className="flex items-center gap-2 px-3 md:px-4 py-3 md:py-3.5">
          <div className="w-6 h-6 md:w-7 md:h-7 rounded-lg bg-stone-100 flex items-center justify-center text-stone-600 font-serif text-[11px] md:text-[12px] flex-shrink-0">
            ◇
          </div>
          <div className="flex-1 text-stone-400 text-[12px] md:text-[14px] font-sans truncate min-w-0">
            {demo.placeholder}
          </div>
          <button className="w-7 h-7 rounded-md bg-stone-100 hover:bg-stone-200 text-stone-500 flex items-center justify-center text-[16px] transition-colors">
            +
          </button>
        </div>
        <div className="flex items-center justify-center gap-1 px-3 pb-2.5">
          {[
            { icon: "spark", id: "apps" },
            { icon: "memory", id: "folders" },
            { icon: "compose", id: "vendors" },
            { icon: "image", id: "files" },
            { icon: "attach", id: "files" },
            { icon: "voice", id: "voice" }
          ].map((b, i) => {
            const isActive = b.id === demo.id;
            return (
              <div key={i} className="flex items-center">
                {i === 5 && <div className="w-px h-4 bg-stone-200 mx-1" />}
                <div
                  className={`w-8 h-8 rounded-lg flex items-center justify-center transition-colors ${
                    isActive ? "bg-emerald-50 text-emerald-700" : "text-stone-400"
                  }`}
                >
                  <AimaIcon name={b.icon} size={15} />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

/* ─── DRAWER VARIANTS ─── */
function Drawer({ demo }) {
  if (demo.drawer === "tools") return <ToolsDrawer tools={demo.tools} />;
  if (demo.drawer === "folders") return <FoldersDrawer folders={demo.folders} />;
  if (demo.drawer === "vendors") return <VendorsDrawer vendors={demo.vendors} />;
  if (demo.drawer === "files") return <FilesDrawer files={demo.files} />;
  return null;
}

function ToolsDrawer({ tools }) {
  return (
    <div className="ml-auto w-fit rounded-2xl bg-white/95 backdrop-blur-xl border border-white/40 shadow-2xl p-3 mr-4">
      <div className="text-[11px] text-stone-400 px-2 pb-1.5 font-sans">Aïma peut…</div>
      {tools.map((t, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, x: -4 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.05 + i * 0.06 }}
          className="flex items-center gap-2.5 px-3 py-1.5 rounded-lg hover:bg-stone-100 cursor-default"
        >
          <AimaIcon name={t.icon} size={15} className="text-stone-600" />
          <span className="text-[13px] text-stone-700 font-sans">{t.label}</span>
        </motion.div>
      ))}
    </div>
  );
}

function FoldersDrawer({ folders }) {
  return (
    <div className="rounded-2xl bg-black/40 backdrop-blur-xl border border-white/10 p-5">
      <div className="font-sans text-[10px] tracking-[0.3em] uppercase text-white/40 mb-4 px-1">
        Tes dossiers
      </div>
      <div className="flex flex-wrap gap-4 justify-center">
        {folders.map((f) => (
          <FolderStamp
            key={f.name}
            name={f.name}
            icon={CTX_ICON_MAP[f.name] || "default"}
            palette={f.palette}
            count={f.count}
            size="sm"
          />
        ))}
      </div>
    </div>
  );
}

function VendorsDrawer({ vendors }) {
  return (
    <div className="rounded-2xl bg-white/[0.04] backdrop-blur-xl border border-white/10 p-3 md:p-4">
      <div className="text-[10px] md:text-[11px] text-emerald-400/80 px-2 pb-2 font-sans tracking-wider uppercase">
        Aïma propose 3 prestataires
      </div>
      <div className="grid grid-cols-3 gap-2 md:gap-3">
        {vendors.map((v, i) => (
          <motion.div
            key={v.name}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.08 + i * 0.08 }}
            className="rounded-xl bg-white/[0.05] border border-white/10 overflow-hidden hover:bg-white/[0.08] transition-colors"
          >
            <div className="relative aspect-[4/3] overflow-hidden">
              <img
                src={v.photo}
                alt={v.name}
                className="absolute inset-0 w-full h-full object-cover opacity-90"
              />
              <div className="absolute top-2 right-2 w-7 h-7 rounded-full bg-black/50 backdrop-blur flex items-center justify-center text-white/90 font-serif">
                {v.sigil}
              </div>
              <div className="absolute bottom-2 left-2 px-2 py-0.5 rounded-full bg-emerald-500/90 text-white text-[10px] font-medium font-sans">
                {v.match}% match
              </div>
            </div>
            <div className="p-2.5">
              <div className="text-[12.5px] text-white font-medium font-sans leading-tight">{v.name}</div>
              <div className="text-[10.5px] text-white/55 font-sans">{v.craft} · {v.location}</div>
              <div className="mt-1.5 text-[10.5px] text-white/70 font-serif italic leading-snug line-clamp-2">
                « {v.note} »
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

function FilesDrawer({ files }) {
  return (
    <div className="rounded-2xl bg-white/[0.04] backdrop-blur-xl border border-white/10 p-4">
      <div className="space-y-2">
        {files.map((f, i) => (
          <motion.div
            key={f.name}
            initial={{ opacity: 0, x: -6 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.05 + i * 0.07 }}
            className="flex items-center gap-3 px-3 py-2.5 rounded-lg bg-white/[0.04] border border-white/10"
          >
            <div className="w-9 h-11 rounded-md bg-gradient-to-b from-white/15 to-white/5 border border-white/10 flex items-center justify-center text-[10px] text-white/70 font-mono">
              {f.kind}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-[12.5px] text-white/90 font-medium truncate">{f.name}</div>
              <div className="text-[10.5px] text-white/45 font-sans">{f.size}</div>
            </div>
            <span className="px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 text-[10px] font-sans">
              Lu par Aïma
            </span>
          </motion.div>
        ))}
      </div>
    </div>
  );
}