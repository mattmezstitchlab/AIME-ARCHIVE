import React from "react";
import { motion } from "framer-motion";
import GrainedSection from "@/components/design-system/GrainedSection";
import EditableText from "@/components/edit/EditableText";

export default function ManifestoFooter() {
  return (
    <GrainedSection gradient="radial-gradient(ellipse at 50% 0%, rgba(184,150,62,0.10) 0%, transparent 55%), radial-gradient(ellipse at 50% 100%, rgba(76,82,255,0.08) 0%, transparent 55%), linear-gradient(180deg, #0A0A0B 0%, #050507 100%)">
      {/* Portrait Yourcenar — fond du manifeste */}
      <img
        src="https://media.base44.com/images/public/69f533665895eadb70315662/a05b0655e_generated_image.png"
        alt=""
        aria-hidden="true"
        className="absolute inset-0 w-full h-full object-cover opacity-40 pointer-events-none"
        style={{ objectPosition: "center 30%" }}
      />
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            "linear-gradient(180deg, rgba(10,10,11,0.55) 0%, rgba(10,10,11,0.35) 50%, rgba(10,10,11,0.85) 100%)"
        }}
      />
      <div className="relative max-w-3xl mx-auto px-5 md:px-6 py-20 md:py-36 text-center">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1.2 }}
        >
          <EditableText
            slug="footer.manifesto.eyebrow"
            label="Manifeste — eyebrow"
            page="/"
            as="div"
            className="font-sans text-[11px] tracking-[0.35em] uppercase text-[#D4B483] mb-6"
            defaultValue="Manifeste · héritage"
          />
          <EditableText
            slug="footer.manifesto"
            label="Manifeste — phrase d'héritage"
            page="/"
            as="p"
            className="font-serif italic text-white/95 text-sm md:text-base leading-[1.6] md:leading-[1.7] whitespace-pre-line"
            style={{ letterSpacing: "-0.015em" }}
            defaultValue={`« Aïma a été éduquée\npar les voix qui savent garder.\n\nYourcenar, Bachelard, Bonnefoy.\nElle ne les imite pas — elle hérite. »`}
          />
          <EditableText
            slug="footer.tagline"
            label="Manifeste — signature AIME"
            page="/"
            as="div"
            className="mt-12 font-sans text-white/55 text-[12px] tracking-[0.2em] uppercase"
            defaultValue="AIME® · une présence, déjà là."
          />
        </motion.div>

      </div>
    </GrainedSection>
  );
}