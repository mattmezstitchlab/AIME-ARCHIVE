import React from "react";
import { motion } from "framer-motion";
import IPhoneMockup from "./IPhoneMockup";

/**
 * UniversalHero — Hero refondu en split layout.
 * Gauche : eyebrow + headline réduit + sous-titre. Pas de CTA (le bouton flottant suffit).
 * Droite : mockup iPhone qui défile les 9 fenêtres.
 * Fond sombre uni avec gradient subtil — pas d'image qui parasite la lecture.
 */
export default function UniversalHero() {
  return (
    <section className="relative w-full min-h-screen overflow-hidden bg-[#0A0A0B] text-white pt-24 md:pt-28">
      {/* Gradient ambiance subtil — pas d'image plein cadre */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            "radial-gradient(ellipse 60% 40% at 80% 20%, rgba(212,165,116,0.12), transparent 60%), radial-gradient(ellipse 50% 60% at 20% 80%, rgba(93,201,180,0.08), transparent 60%), linear-gradient(180deg, #0A0A0B 0%, #0F0F11 100%)"
        }}
      />

      {/* Grain overlay très subtil */}
      <svg className="absolute inset-0 w-full h-full opacity-[0.04] mix-blend-overlay pointer-events-none" aria-hidden="true">
        <filter id="hero-grain-v3">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" stitchTiles="stitch" />
          <feColorMatrix values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 0.5 0" />
        </filter>
        <rect width="100%" height="100%" filter="url(#hero-grain-v3)" />
      </svg>

      {/* Container */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 md:px-10 py-12 md:py-20">
        <div className="grid grid-cols-1 lg:grid-cols-[1.1fr_1fr] gap-12 lg:gap-16 items-center">
          {/* COLONNE GAUCHE — Texte */}
          <div>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6 }}
              className="inline-flex items-center gap-2 text-white/75 text-[11px] tracking-[0.25em] uppercase font-medium mb-6"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              Aïma · votre présence
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
              className="apple-headline text-white text-4xl md:text-5xl lg:text-[64px] leading-[1.05]"
            >
              Une présence,
              <br />
              <span className="font-serif italic font-normal text-white/75">
                pour chacun de vous.
              </span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5, duration: 0.8 }}
              className="mt-6 font-sans text-white/65 text-[15px] md:text-[17px] leading-relaxed max-w-md"
            >
              Neuf fenêtres. Une seule présence. Aïma vous écoute, compose, protège — vous restez sur l'essentiel.
            </motion.p>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.9, duration: 0.6 }}
              className="mt-8 flex items-center gap-3 text-[10px] tracking-[0.3em] uppercase text-white/45"
            >
              <span className="w-8 h-px bg-white/30" />
              Découvrir l'écosystème ↓
            </motion.div>
          </div>

          {/* COLONNE DROITE — Mockup iPhone */}
          <div className="flex justify-center lg:justify-end">
            <IPhoneMockup />
          </div>
        </div>
      </div>
    </section>
  );
}