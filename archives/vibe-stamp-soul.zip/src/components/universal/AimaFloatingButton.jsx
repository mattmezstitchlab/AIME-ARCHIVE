import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";

/**
 * AimaFloatingButton — Bouton flottant rond noir, bottom-center, persistant.
 * Cœur AIME animé qui passe par l'arc-en-ciel doucement (8s par cycle).
 * Au clic → ouvre la conversation Aïma en modal.
 */

// Palette arc-en-ciel douce (pas saturée, esthétique AIME)
const RAINBOW = [
  "#E85D5D", // rouge tendre
  "#E8965D", // orange chaud
  "#E8C95D", // or
  "#9DC95D", // vert moss
  "#5DC9B4", // turquoise
  "#5D9DC9", // bleu doux
  "#9D5DC9", // violet
  "#C95D9D", // rose magenta
  "#E85D5D"  // retour rouge (boucle)
];

export default function AimaFloatingButton({ onClick, hidden = false, accent = null }) {
  const [colorIndex, setColorIndex] = useState(0);

  // Cycle doux : 8s par couleur (uniquement si pas d'accent contextuel)
  useEffect(() => {
    if (accent) return;
    const t = setInterval(() => {
      setColorIndex((i) => (i + 1) % RAINBOW.length);
    }, 8000);
    return () => clearInterval(t);
  }, [accent]);

  if (hidden) return null;

  // Si on est dans un espace (route avec accent), couleur figée. Sinon arc-en-ciel.
  const currentColor = accent || RAINBOW[colorIndex];

  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3, duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      className="fixed bottom-5 md:bottom-6 left-0 right-0 z-50 flex justify-center"
      style={{ pointerEvents: "none" }}
    >
      <div className="relative" style={{ pointerEvents: "auto" }}>
      {/* Halo pulsant doux */}
      <motion.div
        className="absolute inset-0 rounded-full"
        animate={{
          boxShadow: [
            `0 0 0 0 ${currentColor}40`,
            `0 0 0 16px ${currentColor}00`
          ]
        }}
        transition={{ duration: 2.5, repeat: Infinity, ease: "easeOut" }}
      />

      <motion.button
        onClick={onClick}
        whileHover={{ scale: 1.08 }}
        whileTap={{ scale: 0.96 }}
        className="relative w-16 h-16 rounded-full bg-white flex items-center justify-center shadow-[0_8px_32px_rgba(0,0,0,0.18),0_2px_8px_rgba(0,0,0,0.12)] border border-stone-200 group"
        aria-label="Parler à Aïma"
        title="Parler à Aïma"
      >
        {/* Cœur AIME qui change de couleur en transition douce */}
        <motion.svg
          width="26"
          height="26"
          viewBox="0 0 24 24"
          fill="none"
          stroke={currentColor}
          strokeWidth="1.8"
          strokeLinecap="round"
          strokeLinejoin="round"
          animate={{
            stroke: currentColor,
            scale: [1, 1.08, 1]
          }}
          transition={{
            stroke: { duration: 8, ease: "easeInOut" },
            scale: { duration: 2.5, repeat: Infinity, ease: "easeInOut" }
          }}
        >
          <path d="M12 19s-7-4.5-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 9c0 5.5-7 10-7 10Z" />
        </motion.svg>

        {/* Tooltip apparaît au hover */}
        <span className="absolute bottom-full mb-3 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap px-3 py-1.5 rounded-full bg-stone-900/95 backdrop-blur text-white text-[11px] tracking-[0.15em] uppercase font-sans">
          Parler à Aïma
        </span>
      </motion.button>
      </div>
    </motion.div>
  );
}