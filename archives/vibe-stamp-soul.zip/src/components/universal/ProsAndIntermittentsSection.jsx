import React from "react";
import { motion } from "framer-motion";
import AimaIcon from "@/components/design-system/AimaIcons";

/**
 * Une seule section qui réunit prestataires, artistes & intermittents.
 * Mise en avant : la particularité française des intermittents du spectacle.
 */
export default function ProsAndIntermittentsSection() {
  return (
    <section className="relative bg-[#0A0A0B] py-24 md:py-32 px-6 overflow-hidden border-t border-white/5">
      {/* gradient */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            "radial-gradient(ellipse at 80% 20%, rgba(255,107,53,0.18) 0%, transparent 55%), radial-gradient(ellipse at 15% 90%, rgba(76,82,255,0.18) 0%, transparent 55%)"
        }}
      />
      {/* grain */}
      <svg className="absolute inset-0 w-full h-full opacity-[0.05] mix-blend-overlay pointer-events-none" aria-hidden="true">
        <filter id="pi-grain">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" stitchTiles="stitch" />
          <feColorMatrix values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 0.5 0" />
        </filter>
        <rect width="100%" height="100%" filter="url(#pi-grain)" />
      </svg>

      <div className="relative max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-orange-500/10 border border-orange-500/30 text-orange-300 text-[11px] font-medium tracking-wider uppercase mb-5"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-orange-400 animate-pulse" />
            Une première en France
          </motion.div>
          <h2 className="apple-headline text-white text-4xl md:text-5xl lg:text-6xl">
            Prestataires, artistes,<br />
            <span className="font-serif italic font-normal text-white/70">intermittents du spectacle.</span>
          </h2>
          <p className="mt-5 font-sans text-white/60 text-base md:text-lg max-w-2xl mx-auto leading-snug">
            DJ, photographes, traiteurs, musiciens, comédiens, scénographes — Aïma parle pour vous, qualifie chaque demande, et prend en charge la paperasse française qu'aucune autre plateforme ne touche.
          </p>
        </div>

        {/* Grid */}
        <div className="grid md:grid-cols-[1.1fr_1fr] gap-6">
          {/* LEFT — what Aima does for pros */}
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="rounded-3xl border border-white/10 bg-white/[0.025] p-8 md:p-10"
          >
            <div className="text-[11px] tracking-[0.25em] uppercase text-white/40 mb-4 font-sans">
              Section · prestataires
            </div>
            <h3 className="font-display text-white text-2xl md:text-3xl mb-3">
              Aïma parle <span className="font-serif italic text-white/60">à votre place.</span>
            </h3>
            <p className="text-white/60 text-[14.5px] leading-relaxed mb-7 max-w-md">
              Sept questions, et c'est tout. Aïma devient votre voix : elle qualifie, négocie, écarte ce qui ne vous correspond pas. Vous restez à votre art.
            </p>

            <div className="space-y-3">
              {[
                { icon: "bubble", t: "Onboarding conversationnel", d: "Sept échanges. Aïma vous connaît." },
                { icon: "spark", t: "Filtrage intelligent", d: "Les demandes mal alignées n'arrivent pas." },
                { icon: "compose", t: "Devis pré-rédigés", d: "À votre voix, à votre tarif." },
                { icon: "calendar", t: "Calendrier protégé", d: "Pas de double-booking. Pas de stress." }
              ].map((f) => (
                <div key={f.t} className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-lg bg-white/[0.06] border border-white/10 flex items-center justify-center text-white/70 flex-shrink-0">
                    <AimaIcon name={f.icon} size={15} />
                  </div>
                  <div>
                    <div className="text-white/90 text-[13.5px] font-medium font-sans">{f.t}</div>
                    <div className="text-white/45 text-[12.5px] font-sans">{f.d}</div>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

          {/* RIGHT — Intermittents (the differentiator) */}
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="rounded-3xl border border-orange-500/30 bg-gradient-to-b from-orange-500/[0.06] to-transparent p-8 md:p-10 relative overflow-hidden"
          >
            <div className="absolute -top-20 -right-20 w-60 h-60 rounded-full bg-orange-500/15 blur-3xl pointer-events-none" />

            <div className="relative">
              <div className="text-[11px] tracking-[0.25em] uppercase text-orange-300 mb-4 font-sans flex items-center gap-2">
                <AimaIcon name="spark" size={12} /> Section · intermittents
              </div>
              <h3 className="font-display text-white text-2xl md:text-3xl mb-3">
                Le geste, <span className="font-serif italic text-white/60">pas la paperasse.</span>
              </h3>
              <p className="text-white/65 text-[14.5px] leading-relaxed mb-6 max-w-md">
                Première plateforme de mariage en France à intégrer la réalité des intermittents du spectacle. Aïma s'occupe de l'invisible administratif, vous restez sur scène.
              </p>

              <div className="grid grid-cols-2 gap-2.5">
                {[
                  { t: "Cachets", d: "Édition automatique" },
                  { t: "AEM", d: "Pôle Emploi pré-remplie" },
                  { t: "Contrats", d: "CDDU à la signature" },
                  { t: "Audiens", d: "Cotisations centralisées" },
                  { t: "507h", d: "Suivi en temps réel" },
                  { t: "Annexes 8/10", d: "Statut sécurisé" }
                ].map((b) => (
                  <div
                    key={b.t}
                    className="rounded-xl bg-black/30 border border-white/10 px-3 py-2.5"
                  >
                    <div className="text-white text-[12.5px] font-medium font-sans">{b.t}</div>
                    <div className="text-white/50 text-[11px] font-sans">{b.d}</div>
                  </div>
                ))}
              </div>

              <div className="mt-6 pt-5 border-t border-white/10">
                <p className="font-serif italic text-white/70 text-[14px] leading-relaxed">
                  « Avant Aïma, j'avais un mariage par mois et trois soirées par semaine à éditer mes feuilles de paie.
                  Maintenant, je joue. »
                </p>
                <div className="mt-2 text-[11px] text-white/40 font-sans">
                  — Marc, DJ, intermittent depuis 2018
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}