import React, { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import FolderCard from "./FolderCard";
import FolderLikeButton from "@/components/desk/FolderLikeButton";
import { DESK_FOLDERS } from "@/lib/deskFolders";
import { readBasket, writeBasket } from "@/lib/deskBasket";
import AimaIcon from "@/components/design-system/AimaIcons";

/**
 * AimaFoldersDrawer — Drawer "Tes dossiers" dans la fenêtre de discussion.
 * - Défilement horizontal lent automatique (marquee) + scroll manuel possible
 * - Chaque dossier a un cœur cliquable pour le sélectionner
 * - Bouton "Valider" en bas à droite garde les dossiers likés dans le panier
 *
 * Props:
 *   onValidate(ids[]) : callback à la validation
 *   onClose()         : ferme le drawer
 */
export default function AimaFoldersDrawer({ onValidate, onClose }) {
  const [liked, setLiked] = useState(() => new Set(readBasket()));
  const [paused, setPaused] = useState(false);
  const trackRef = useRef(null);

  // On duplique la liste pour faire un défilement infini fluide
  const items = [...DESK_FOLDERS, ...DESK_FOLDERS];

  // Animation lente en boucle — pause sur hover/scroll
  useEffect(() => {
    const el = trackRef.current;
    if (!el || paused) return;
    let raf;
    let last = performance.now();
    const tick = (now) => {
      const dt = now - last;
      last = now;
      // 18 px/s — bien lent
      el.scrollLeft += (dt / 1000) * 18;
      // boucle : quand on dépasse la moitié, on revient au début
      const half = el.scrollWidth / 2;
      if (el.scrollLeft >= half) el.scrollLeft -= half;
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [paused]);

  const toggle = (id) => {
    setLiked((cur) => {
      const next = new Set(cur);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleValidate = () => {
    const ids = Array.from(liked);
    writeBasket(ids);
    onValidate?.(ids);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 8 }}
      transition={{ duration: 0.25, ease: [0.22, 1, 0.36, 1] }}
      className="px-3 pb-3"
    >
      <div className="px-1 pt-3.5 pb-1">
        <div className="flex items-center justify-between mb-3">
          <div className="text-[10.5px] tracking-[0.2em] uppercase text-white/50 font-sans">
            Tes dossiers — clique sur le cœur pour les garder
          </div>
          <button
            onClick={onClose}
            className="w-6 h-6 rounded-md hover:bg-white/10 text-white/50 hover:text-white/90 flex items-center justify-center transition-colors"
            aria-label="Fermer"
          >
            <AimaIcon name="close" size={12} />
          </button>
        </div>

        {/* Marquee horizontale lente */}
        <div
          ref={trackRef}
          onMouseEnter={() => setPaused(true)}
          onMouseLeave={() => setPaused(false)}
          onTouchStart={() => setPaused(true)}
          onTouchEnd={() => setPaused(false)}
          className="overflow-x-auto py-3"
          style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
        >
          <style>{`.aima-folders-track::-webkit-scrollbar { display: none; }`}</style>
          <div className="aima-folders-track flex items-end gap-4 px-2" style={{ width: "max-content" }}>
            {items.map((f, i) => (
              <div key={`${f.id}-${i}`} className="flex-shrink-0">
                <FolderCard
                  name={f.name}
                  palette={f.palette}
                  icon={f.icon}
                  size="sm"
                  likeSlot={
                    <FolderLikeButton
                      liked={liked.has(f.id)}
                      onLike={() => toggle(f.id)}
                      size="sm"
                    />
                  }
                />
              </div>
            ))}
          </div>
        </div>

        {/* Footer — compteur + bouton valider à droite */}
        <div className="flex items-center justify-between mt-3 pt-2 border-t border-white/10">
          <div className="text-[11px] text-white/55 font-sans">
            {liked.size > 0
              ? `${liked.size} dossier${liked.size > 1 ? "s" : ""} sélectionné${liked.size > 1 ? "s" : ""}`
              : "Aucun dossier sélectionné"}
          </div>
          <button
            onClick={handleValidate}
            disabled={liked.size === 0}
            className="px-4 py-1.5 rounded-full bg-white text-stone-900 disabled:bg-white/20 disabled:text-white/40 disabled:cursor-not-allowed text-[12px] font-sans font-medium hover:bg-white/90 transition-colors"
          >
            Valider
          </button>
        </div>
      </div>
    </motion.div>
  );
}