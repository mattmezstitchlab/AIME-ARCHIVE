import React, { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";

/**
 * AimaProfileSwitcher — sélecteur de "casquette" (rôle/profil) à gauche
 * des 3 modes d'affichage. Permet de basculer instantanément entre tous
 * les rôles : Futurs mariés, Invité·e, Prestataire, Lieu, Intermittent·e,
 * Agriculteur·rice, Mairie, Inclusive, Noyau, Mémoire, Je découvre.
 *
 * Une seule personne peut être tout cela à la fois — le switcher reflète
 * la multiplicité réelle des rôles humains.
 */

// Palette unifiée : 2 couleurs seulement.
// AIME_GREEN = vert menthe moderne (état neutre/découverte/écoute)
// AIME_FUCHSIA = fuchsia (état engagé / rôle actif)
export const AIME_GREEN = "#34D399";
export const AIME_FUCHSIA = "#E11D74";

// Tous les profils utilisent le vert menthe par défaut.
// Le fuchsia est gardé en réserve pour un état engagé spécifique.
export const AIMA_PROFILES = [
  { id: "default", label: "Je découvre", color: AIME_GREEN },
  { id: "couple", label: "Futurs mariés", color: AIME_GREEN },
  { id: "guest", label: "Invité·e", color: AIME_GREEN },
  { id: "pro", label: "Prestataire", color: AIME_GREEN },
  { id: "venue", label: "Lieu", color: AIME_GREEN },
  { id: "intermittent", label: "Intermittent·e", color: AIME_GREEN },
  { id: "agri", label: "Agriculteur·rice", color: AIME_GREEN },
  { id: "mairie", label: "Mairie", color: AIME_GREEN },
  { id: "inclusive", label: "Inclusive", color: AIME_GREEN },
  { id: "noyau", label: "Noyau", color: AIME_GREEN },
  { id: "memory", label: "Mémoire", color: AIME_GREEN }
];

export function getProfile(id) {
  return AIMA_PROFILES.find((p) => p.id === id) || AIMA_PROFILES[0];
}

export default function AimaProfileSwitcher({ profileId = "default", onChange }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  const current = getProfile(profileId);

  useEffect(() => {
    const onClick = (e) => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    if (open) document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, [open]);

  return (
    <div ref={ref} className="relative">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className={`flex items-center gap-2 px-2.5 py-1.5 rounded-full bg-white/[0.06] border border-white/10 text-[10.5px] tracking-[0.08em] uppercase transition-colors ${
          open ? "text-white" : "text-white/75 hover:text-white"
        }`}
        aria-label="Changer de rôle"
      >
        <span
          className="w-1.5 h-1.5 rounded-full flex-shrink-0"
          style={{ backgroundColor: current.color }}
        />
        <span className="hidden md:inline truncate max-w-[110px]">{current.label}</span>
        <svg width="9" height="9" viewBox="0 0 12 12" fill="none" className={`transition-transform ${open ? "rotate-180" : ""}`}>
          <path d="M2 4l4 4 4-4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.18 }}
            className="absolute top-full mt-2 left-0 z-50 w-56 rounded-2xl bg-[#1a1a1c] border border-white/15 shadow-[0_24px_64px_rgba(0,0,0,0.5)] overflow-hidden"
          >
            <div className="px-3 py-2 border-b border-white/10">
              <div className="text-[9px] tracking-[0.25em] uppercase text-white/45 font-medium">
                Tes casquettes
              </div>
            </div>
            <div className="max-h-[60vh] overflow-y-auto p-1">
              {AIMA_PROFILES.map((p) => {
                const active = p.id === profileId;
                return (
                  <button
                    key={p.id}
                    onClick={() => {
                      onChange?.(p.id);
                      setOpen(false);
                    }}
                    className={`w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-left transition-colors ${
                      active ? "bg-white/[0.08]" : "hover:bg-white/[0.05]"
                    }`}
                  >
                    <span
                      className="w-2 h-2 rounded-full flex-shrink-0"
                      style={{ backgroundColor: p.color }}
                    />
                    <span className={`text-[12.5px] flex-1 ${active ? "text-white font-medium" : "text-white/80"}`}>
                      {p.label}
                    </span>
                    {active && (
                      <span className="text-[9px] tracking-[0.18em] uppercase text-white/45">actif</span>
                    )}
                  </button>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}