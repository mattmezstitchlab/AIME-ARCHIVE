import React from "react";
import { motion } from "framer-motion";
import AimaIcon from "@/components/design-system/AimaIcons";
import FolderCard from "./FolderCard";
import { AIMA_CONTEXTS } from "@/lib/aimaContextActions";

/**
 * AimaToolDrawer — tiroirs réels qui s'ouvrent depuis la barre blanche
 * du AimaConversation. Cliquer sur un picto → ouvre le bon drawer.
 *
 * Props :
 *   - kind : "tools" | "folders" | "vendors" | "files" | "voice"
 *   - context : "default" | "couple" | "guest" | "pro" | "venue" |
 *               "intermittent" | "inclusive" | "mairie" | "memory"
 *   - onPick(item) : remonte un message à coller dans la conversation.
 */

const VENDORS = [
  {
    name: "Léa Marquez",
    craft: "Photographe",
    location: "Bordeaux",
    photo: "https://images.unsplash.com/photo-1554080353-a576cf803bda?w=400&q=80",
    sigil: "◇",
    note: "Lumière douce, lien intime",
    match: 96
  },
  {
    name: "Théo Noyer",
    craft: "DJ · vinyles",
    location: "Lyon",
    photo: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400&q=80",
    sigil: "✦",
    note: "Soul, slow disco, rare grooves",
    match: 91
  },
  {
    name: "Atelier Salines",
    craft: "Traiteur",
    location: "Arcachon",
    photo: "https://images.unsplash.com/photo-1555244162-803834f70033?w=400&q=80",
    sigil: "◈",
    note: "Cuisine du marché, table d'hôtes",
    match: 88
  }
];

const FOLDERS = [
  { name: "Prestataires", count: 7, palette: "kraft" },
  { name: "Invités", count: 84, palette: "moss" },
  { name: "Contrats", count: 3, palette: "navy" },
  { name: "Photos", count: 26, palette: "wine" },
  { name: "Sceaux", count: 1, palette: "plum" }
];

const FILES = [
  { name: "Devis_Fleuriste.pdf", kind: "PDF", size: "248 Ko" },
  { name: "Liste_invités.csv", kind: "CSV", size: "12 Ko" },
  { name: "Inspirations.jpg", kind: "Image", size: "1.4 Mo" }
];

export default function AimaToolDrawer({ kind, onPick, onClose, context = "default" }) {
  const ctx = AIMA_CONTEXTS[context] || AIMA_CONTEXTS.default;
  return (
    <motion.div
      initial={{ opacity: 0, y: 8, scale: 0.97 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: 8, scale: 0.97 }}
      transition={{ duration: 0.25, ease: [0.22, 1, 0.36, 1] }}
      className="px-3 pb-3"
    >
      <div className="px-1 pt-3.5 pb-1">
        <div className="flex items-center justify-between mb-2.5">
          <div className="text-[10.5px] tracking-[0.2em] uppercase text-white/50 font-sans">
            {kind === "tools" && ctx.label}
            {kind === "folders" && "Tes dossiers"}
            {kind === "vendors" && "Aïma propose 3 prestataires"}
            {kind === "files" && "Pièces jointes"}
            {kind === "voice" && "Dis-le à Aïma"}
          </div>
          <button
            onClick={onClose}
            className="w-6 h-6 rounded-md hover:bg-white/10 text-white/50 hover:text-white/90 flex items-center justify-center transition-colors"
            aria-label="Fermer"
          >
            <AimaIcon name="close" size={12} />
          </button>
        </div>

        {kind === "tools" && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
            {ctx.actions.map((t, i) => (
              <motion.button
                key={t.label}
                initial={{ opacity: 0, x: -4 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.04 + i * 0.04 }}
                onClick={() => onPick?.({ type: "prompt", text: t.prompt })}
                className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-left hover:bg-white/[0.08] transition-colors group min-w-0"
              >
                <div className="w-9 h-9 rounded-xl bg-white/[0.06] group-hover:bg-white/[0.12] flex items-center justify-center transition-colors flex-shrink-0">
                  <AimaIcon name={t.icon} size={18} className="text-white/85" />
                </div>
                <span className="text-[13px] text-white/90 font-sans truncate">{t.label}</span>
              </motion.button>
            ))}
          </div>
        )}

        {kind === "folders" && (
          <div className="flex flex-wrap gap-3 justify-center py-1">
            {FOLDERS.map((f, i) => (
              <button
                key={f.name}
                onClick={() => onPick?.({ type: "prompt", text: `Ouvre le dossier ${f.name}` })}
                className="hover:scale-[1.04] transition-transform"
              >
                <FolderCard
                  name={f.name}
                  count={f.count}
                  palette={f.palette}
                  size="sm"
                  delay={0.04 + i * 0.05}
                />
              </button>
            ))}
          </div>
        )}

        {kind === "vendors" && (
          <div className="grid grid-cols-3 gap-2">
            {VENDORS.map((v, i) => (
              <motion.button
                key={v.name}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.05 + i * 0.06 }}
                onClick={() => onPick?.({ type: "prompt", text: `J'aime bien ${v.name}` })}
                className="rounded-lg bg-white/[0.04] border border-white/10 overflow-hidden hover:bg-white/[0.08] transition-colors text-left"
              >
                <div className="relative aspect-[4/3] overflow-hidden">
                  <img src={v.photo} alt={v.name} className="absolute inset-0 w-full h-full object-cover opacity-90" />
                  <div className="absolute top-1.5 right-1.5 w-5 h-5 rounded-full bg-black/55 backdrop-blur flex items-center justify-center text-white/90 font-serif text-[10px]">
                    {v.sigil}
                  </div>
                  <div className="absolute bottom-1.5 left-1.5 px-1.5 py-0.5 rounded-full bg-emerald-500/90 text-white text-[9px] font-medium font-sans">
                    {v.match}%
                  </div>
                </div>
                <div className="p-2">
                  <div className="text-[11.5px] text-white font-medium font-sans leading-tight truncate">{v.name}</div>
                  <div className="text-[9.5px] text-white/55 font-sans truncate">{v.craft} · {v.location}</div>
                  <div className="mt-1 text-[9.5px] text-white/65 font-serif italic leading-snug line-clamp-2">
                    « {v.note} »
                  </div>
                </div>
              </motion.button>
            ))}
          </div>
        )}

        {kind === "files" && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
            {FILES.map((f, i) => (
              <motion.div
                key={f.name}
                initial={{ opacity: 0, x: -4 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.04 + i * 0.05 }}
                className="flex items-center gap-2.5 px-2.5 py-2 rounded-lg bg-white/[0.04] border border-white/10 min-w-0"
              >
                <div className="w-7 h-9 rounded-md bg-gradient-to-b from-white/15 to-white/5 border border-white/10 flex items-center justify-center text-[9px] text-white/70 font-mono flex-shrink-0">
                  {f.kind}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-[12px] text-white/90 font-medium truncate">{f.name}</div>
                  <div className="text-[10px] text-white/45 font-sans">{f.size}</div>
                </div>
                <span className="px-1.5 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 text-[9.5px] font-sans flex-shrink-0">
                  Lu
                </span>
              </motion.div>
            ))}
            <button className="sm:col-span-2 w-full px-3 py-1.5 rounded-lg border border-dashed border-white/15 text-white/50 hover:text-white/80 hover:border-white/30 text-[11.5px] font-sans transition-colors">
              + Glisser un nouveau fichier
            </button>
          </div>
        )}

        {kind === "voice" && (
          <div className="flex flex-col items-center py-4">
            <div className="relative w-14 h-14 rounded-full bg-gradient-to-br from-orange-400/30 to-pink-500/30 border border-white/20 flex items-center justify-center text-white">
              <AimaIcon name="voice" size={22} />
              <span className="absolute inset-0 rounded-full border-2 border-orange-300/50 animate-ping" />
            </div>
            <div className="mt-3 font-serif italic text-white/70 text-[13px]">
              Aïma écoute…
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
}