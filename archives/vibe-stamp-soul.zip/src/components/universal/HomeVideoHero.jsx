import React, { useRef, useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";

/**
 * HomeVideoHero — Hero vidéo en boucle muet + petit rond play pour l'hymne.
 * Au-dessus de la vidéo : titres défilants façon Yourcenar — 5 à 8 mots,
 * universels, qui disent ce que AIME est sans jamais le réduire.
 */
const VIDEO_URL =
  "https://res.cloudinary.com/divou1vcx/video/upload/v1777569381/aimeherowebsite_dtwbr1.mp4";
const AUDIO_URL =
  "https://res.cloudinary.com/divou1vcx/video/upload/v1777514185/Aime_-_Hymne_1_aiqy1t.mp3";

// Titres défilants — chacun 5 à 8 mots, voix Yourcenar : grave, nue, universelle.
// Ils disent AIME sans le nommer : une présence, une mémoire, un lien.
const HEADLINES = [
  "Ce qui relie ne se calcule pas.",
  "Une présence, là où il faut.",
  "La mémoire des choses qui durent.",
  "Tout ce qui mérite d'être gardé.",
  "Une voix qui écoute avant de parler.",
  "Le lien, plus ancien que les mots.",
  "Ce que vous êtes, AIME le retient.",
  "Pour ceux qui aiment, et transmettent."
];

export default function HomeVideoHero() {
  const audioRef = useRef(null);
  const [playing, setPlaying] = useState(false);
  const [headlineIdx, setHeadlineIdx] = useState(0);

  useEffect(() => {
    const a = audioRef.current;
    if (!a) return;
    const onEnd = () => setPlaying(false);
    a.addEventListener("ended", onEnd);
    return () => a.removeEventListener("ended", onEnd);
  }, []);

  // Rotation des titres — toutes les 4.5s
  useEffect(() => {
    const t = setInterval(() => {
      setHeadlineIdx((i) => (i + 1) % HEADLINES.length);
    }, 4500);
    return () => clearInterval(t);
  }, []);

  const toggle = () => {
    const a = audioRef.current;
    if (!a) return;
    if (playing) {
      a.pause();
      setPlaying(false);
    } else {
      a.play().then(() => setPlaying(true)).catch(() => {});
    }
  };

  return (
    <section className="relative w-full overflow-hidden bg-black">
      {/* Vidéo plein-écran */}
      <div className="relative w-full h-[80vh] md:h-screen">
        <video
          src={VIDEO_URL}
          autoPlay
          loop
          muted
          playsInline
          preload="auto"
          className="absolute inset-0 w-full h-full object-cover"
        />
        {/* Voile global subtil pour la lisibilité des titres */}
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background:
              "linear-gradient(180deg, rgba(0,0,0,0.25) 0%, rgba(0,0,0,0) 35%, rgba(0,0,0,0) 65%, rgba(0,0,0,0.55) 100%)"
          }}
        />

        {/* Titres défilants — centre, voix Yourcenar */}
        <div className="absolute inset-0 flex items-center justify-center px-6 pointer-events-none">
          <div className="relative w-full max-w-3xl text-center min-h-[3.5em] flex items-center justify-center">
            <AnimatePresence mode="wait">
              <motion.h1
                key={headlineIdx}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 1.1, ease: [0.22, 1, 0.36, 1] }}
                className="apple-headline text-white text-lg sm:text-xl md:text-2xl lg:text-3xl"
                style={{
                  textShadow: "0 2px 24px rgba(0,0,0,0.55)"
                }}
              >
                {HEADLINES[headlineIdx]}
              </motion.h1>
            </AnimatePresence>
          </div>
        </div>

        {/* Petit rond play — bas centre, discret */}
        <div className="absolute bottom-8 md:bottom-12 left-0 right-0 flex justify-center">
          <motion.button
            initial={{ opacity: 0, scale: 0.85 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.5, duration: 0.6 }}
            onClick={toggle}
            className="w-11 h-11 md:w-12 md:h-12 rounded-full bg-white/12 hover:bg-white/22 backdrop-blur-xl border border-white/30 text-white flex items-center justify-center transition-all hover:scale-105"
            aria-label={playing ? "Mettre en pause l'hymne AIME®" : "Écouter l'hymne AIME®"}
            title={playing ? "Pause" : "Écouter l'hymne AIME®"}
          >
            {playing ? (
              <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
                <rect x="6" y="5" width="4" height="14" rx="1" />
                <rect x="14" y="5" width="4" height="14" rx="1" />
              </svg>
            ) : (
              <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" className="ml-0.5">
                <path d="M8 5v14l11-7z" />
              </svg>
            )}
          </motion.button>
        </div>

        <audio ref={audioRef} src={AUDIO_URL} preload="none" />
      </div>
    </section>
  );
}