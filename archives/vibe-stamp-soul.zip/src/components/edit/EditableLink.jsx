import React from "react";
import { useEditMode } from "@/lib/EditModeContext";

/**
 * EditableLink — bouton/lien éditable (texte + URL).
 * En mode édition : contour bleu, click ouvre le drawer.
 * Hors mode édition : agit comme un <a>.
 */
export default function EditableLink({
  slug,
  defaultLabel = "",
  defaultHref = "#",
  label,
  className = "",
  page = "/",
  onClick
}) {
  const { editing, getValue, configs, openSlot } = useEditMode();
  const { value: text } = getValue(`${slug}.label`, defaultLabel);
  const hrefConfig = configs[`${slug}.href`];
  const href = hrefConfig?.value || defaultHref;

  if (!editing) {
    if (onClick) {
      return (
        <button onClick={onClick} className={className}>{text}</button>
      );
    }
    return (
      <a href={href} className={className}>{text}</a>
    );
  }

  return (
    <span
      className={`${className} relative cursor-pointer outline outline-1 outline-blue-400/40 outline-offset-2 hover:outline-blue-400 hover:outline-2 transition-all inline-block`}
      onClick={(e) => {
        e.preventDefault();
        e.stopPropagation();
        openSlot({
          slug,
          label: label || slug,
          type: "link",
          page,
          currentValue: text,
          currentHref: href,
          hasLink: true
        });
      }}
      title={`Cliquer pour éditer · ${label || slug}`}
    >
      {text}
    </span>
  );
}