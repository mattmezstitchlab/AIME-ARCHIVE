import React from "react";
import { useEditMode } from "@/lib/EditModeContext";
import { Pencil, Eye, Settings } from "lucide-react";
import { Link } from "react-router-dom";

/**
 * EditModeBar — barre flottante en bas qui indique que le mode édition est actif.
 * Visible uniquement quand admin connecté + mode édition ON.
 */
export default function EditModeBar() {
  const { editing, toggleEdit, adminConnected } = useEditMode();

  if (!adminConnected || !editing) return null;

  return (
    <div
      className="fixed bottom-4 left-1/2 -translate-x-1/2 z-[9998] bg-[#0A0A0B] border border-[#B8963E]/40 rounded-full shadow-2xl px-4 py-2 flex items-center gap-2"
      style={{ fontFamily: "'Inter', sans-serif" }}
    >
      <div className="flex items-center gap-2 px-2 text-[#B8963E]">
        <Pencil size={12} />
        <span className="text-[11px] font-medium tracking-wide">Mode édition</span>
      </div>
      <div className="w-px h-4 bg-white/10" />
      <button
        onClick={toggleEdit}
        className="flex items-center gap-1.5 px-3 py-1 rounded-full text-white/70 hover:text-white hover:bg-white/[0.06] text-[11px] transition-colors"
        title="Désactiver le mode édition"
      >
        <Eye size={12} />
        Aperçu
      </button>
      <Link
        to="/admin"
        className="flex items-center gap-1.5 px-3 py-1 rounded-full text-white/70 hover:text-white hover:bg-white/[0.06] text-[11px] transition-colors"
      >
        <Settings size={12} />
        Admin
      </Link>
    </div>
  );
}