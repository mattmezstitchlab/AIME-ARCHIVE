import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useEditMode } from "@/lib/EditModeContext";
import { X, Save, Trash2 } from "lucide-react";

/**
 * EditDrawer — panneau latéral droit qui s'ouvre quand un slot est sélectionné.
 * Permet d'éditer texte, taille, couleur, lien.
 */
const SIZES = [
  { id: "sm", label: "S" },
  { id: "md", label: "M" },
  { id: "lg", label: "L" },
  { id: "xl", label: "XL" }
];

export default function EditDrawer() {
  const { activeSlot, closeSlot, saveSlot, configs } = useEditMode();
  const [draft, setDraft] = useState({ value: "", size: undefined, color: "", href: "" });
  const [saving, setSaving] = useState(false);
  const [savedAt, setSavedAt] = useState(null);

  useEffect(() => {
    if (activeSlot) {
      setDraft({
        value: activeSlot.currentValue || "",
        size: activeSlot.currentSize,
        color: activeSlot.currentColor || "",
        href: activeSlot.currentHref || ""
      });
      setSavedAt(null);
    }
  }, [activeSlot]);

  if (!activeSlot) return <AnimatePresence />;

  const isLink = activeSlot.type === "link";

  const handleSave = async () => {
    setSaving(true);
    try {
      if (isLink) {
        // sauve label + href en deux SiteConfig liés
        await saveSlot(`${activeSlot.slug}.label`, {
          slug: `${activeSlot.slug}.label`,
          type: "text",
          value: draft.value,
          page_path: activeSlot.page,
          label: `${activeSlot.label} — texte`
        });
        await saveSlot(`${activeSlot.slug}.href`, {
          slug: `${activeSlot.slug}.href`,
          type: "link",
          value: draft.href,
          page_path: activeSlot.page,
          label: `${activeSlot.label} — URL`
        });
      } else {
        await saveSlot(activeSlot.slug, {
          slug: activeSlot.slug,
          type: "text",
          value: draft.value,
          size: draft.size || undefined,
          color: draft.color || undefined,
          page_path: activeSlot.page,
          label: activeSlot.label
        });
      }
      setSavedAt(Date.now());
      setTimeout(() => setSavedAt(null), 1500);
    } finally {
      setSaving(false);
    }
  };

  const handleReset = async () => {
    if (!confirm("Réinitialiser ce slot à sa valeur par défaut ?")) return;
    setSaving(true);
    try {
      if (isLink) {
        const labelCfg = configs[`${activeSlot.slug}.label`];
        const hrefCfg = configs[`${activeSlot.slug}.href`];
        if (labelCfg?.id) await saveSlot(`${activeSlot.slug}.label`, { value: "" });
        if (hrefCfg?.id) await saveSlot(`${activeSlot.slug}.href`, { value: "" });
      } else {
        await saveSlot(activeSlot.slug, { value: "", size: undefined, color: undefined });
      }
      closeSlot();
    } finally {
      setSaving(false);
    }
  };

  return (
    <AnimatePresence>
      <motion.div
        key="edit-drawer"
        initial={{ x: 380, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        exit={{ x: 380, opacity: 0 }}
        transition={{ type: "spring", damping: 28, stiffness: 240 }}
        className="fixed top-0 right-0 h-screen w-[380px] z-[9999] bg-[#0A0A0B] border-l border-[#B8963E]/30 shadow-2xl flex flex-col"
        style={{ fontFamily: "'Inter', sans-serif" }}
      >
        {/* Header */}
        <div className="px-5 py-4 border-b border-white/10 flex items-center justify-between">
          <div>
            <div className="text-[9px] tracking-[3px] uppercase text-[#B8963E] mb-0.5">
              Éditeur visuel
            </div>
            <div className="text-white text-[14px] font-medium truncate">
              {activeSlot.label}
            </div>
            <code className="text-[10px] text-white/30 font-mono">{activeSlot.slug}</code>
          </div>
          <button
            onClick={closeSlot}
            className="w-8 h-8 rounded-lg hover:bg-white/[0.06] text-white/60 hover:text-white flex items-center justify-center"
          >
            <X size={16} />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto px-5 py-5 space-y-5">
          {/* Texte */}
          <div>
            <label className="block text-[11px] text-white/60 mb-1.5">
              {isLink ? "Texte du bouton" : "Contenu"}
            </label>
            <textarea
              value={draft.value}
              onChange={(e) => setDraft((d) => ({ ...d, value: e.target.value }))}
              rows={4}
              className="w-full bg-[#1A1A1B] border border-white/10 rounded-lg px-3 py-2 text-white text-[13px] outline-none focus:border-[#B8963E]/50"
              placeholder="Saisis le contenu…"
            />
          </div>

          {/* URL si lien */}
          {isLink && (
            <div>
              <label className="block text-[11px] text-white/60 mb-1.5">
                Lien (URL ou route)
              </label>
              <input
                type="text"
                value={draft.href}
                onChange={(e) => setDraft((d) => ({ ...d, href: e.target.value }))}
                className="w-full bg-[#1A1A1B] border border-white/10 rounded-lg px-3 py-2 text-white text-[13px] outline-none focus:border-[#B8963E]/50 font-mono"
                placeholder="/noyau ou https://…"
              />
            </div>
          )}

          {/* Taille */}
          {activeSlot.hasSize && (
            <div>
              <label className="block text-[11px] text-white/60 mb-1.5">Taille</label>
              <div className="flex gap-1.5">
                {SIZES.map((s) => (
                  <button
                    key={s.id}
                    onClick={() => setDraft((d) => ({ ...d, size: d.size === s.id ? undefined : s.id }))}
                    className={`flex-1 py-2 rounded-lg text-[12px] font-medium transition-colors ${
                      draft.size === s.id
                        ? "bg-[#B8963E]/20 border border-[#B8963E] text-[#D4B483]"
                        : "bg-white/[0.04] border border-white/10 text-white/60 hover:bg-white/[0.08]"
                    }`}
                  >
                    {s.label}
                  </button>
                ))}
              </div>
              <p className="text-[10px] text-white/30 mt-1">Vide = taille par défaut du composant</p>
            </div>
          )}

          {/* Couleur */}
          {activeSlot.hasColor && !isLink && (
            <div>
              <label className="block text-[11px] text-white/60 mb-1.5">Couleur du texte</label>
              <div className="flex gap-2 items-center">
                <input
                  type="color"
                  value={draft.color || "#FFFFFF"}
                  onChange={(e) => setDraft((d) => ({ ...d, color: e.target.value }))}
                  className="w-10 h-10 rounded-lg bg-transparent border border-white/10 cursor-pointer"
                />
                <input
                  type="text"
                  value={draft.color}
                  onChange={(e) => setDraft((d) => ({ ...d, color: e.target.value }))}
                  placeholder="#FFFFFF ou vide"
                  className="flex-1 bg-[#1A1A1B] border border-white/10 rounded-lg px-3 py-2 text-white text-[12px] outline-none focus:border-[#B8963E]/50 font-mono"
                />
                {draft.color && (
                  <button
                    onClick={() => setDraft((d) => ({ ...d, color: "" }))}
                    className="px-2 py-2 rounded-lg text-white/50 hover:text-white text-[11px]"
                  >
                    ×
                  </button>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Footer actions */}
        <div className="px-5 py-4 border-t border-white/10 space-y-2">
          <button
            onClick={handleSave}
            disabled={saving}
            className="w-full py-2.5 rounded-lg bg-[#B8963E] hover:bg-[#D4B483] disabled:opacity-50 text-black text-[13px] font-medium flex items-center justify-center gap-2 transition-colors"
          >
            <Save size={14} />
            {saving ? "Enregistrement…" : savedAt ? "✓ Publié" : "Publier"}
          </button>
          <button
            onClick={handleReset}
            disabled={saving}
            className="w-full py-2 rounded-lg bg-transparent border border-white/10 hover:border-red-500/40 hover:text-red-300 text-white/50 text-[12px] flex items-center justify-center gap-2 transition-colors"
          >
            <Trash2 size={12} />
            Réinitialiser
          </button>
          <p className="text-[10px] text-white/30 text-center">
            Les modifications sont visibles instantanément par tous les visiteurs.
          </p>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}