import React, { useEffect } from "react";
import { useEditMode } from "@/lib/EditModeContext";

/**
 * EditableText — affiche un texte qui peut être édité depuis l'admin.
 * Si mode édition actif → contour bleu au survol + click ouvre le drawer.
 *
 * Props :
 *  - slug : identifiant unique stable (ex: "home.hero.title")
 *  - defaultValue : valeur affichée si rien en DB
 *  - label : nom lisible pour l'admin (ex: "Titre principal Home")
 *  - as : tag HTML ("span" par défaut, "h1", "p"...)
 *  - className : classes Tailwind
 *  - style : inline style
 *  - sizeMap : { sm, md, lg, xl } → classes appliquées selon la size DB
 *  - page : route où ce slot apparaît
 */
export default function EditableText({
  slug,
  defaultValue = "",
  label,
  as: Tag = "span",
  className = "",
  style = {},
  sizeMap = null,
  page = "/",
  children
}) {
  const { editing, getValue, openSlot, registerSlot } = useEditMode();
  const { value, size, color } = getValue(slug, defaultValue);

  // Auto-enregistrement : la première fois qu'un slug est rendu côté admin,
  // on le déclare en base avec sa valeur par défaut, son label et sa page.
  // Ainsi le cockpit "Visual Editor" voit TOUS les textes du site automatiquement.
  useEffect(() => {
    if (registerSlot && slug) {
      registerSlot({ slug, label: label || slug, page, defaultValue, type: "text" });
    }
  }, [slug, label, page, defaultValue, registerSlot]);

  const sizeClass = sizeMap && size && sizeMap[size] ? sizeMap[size] : "";
  const finalStyle = { ...style, ...(color ? { color } : {}) };

  if (!editing) {
    return (
      <Tag className={`${className} ${sizeClass}`.trim()} style={finalStyle}>
        {value || children}
      </Tag>
    );
  }

  return (
    <Tag
      className={`${className} ${sizeClass} relative cursor-pointer outline outline-1 outline-blue-400/30 outline-offset-2 hover:outline-blue-400 hover:outline-2 transition-all`.trim()}
      style={finalStyle}
      onClick={(e) => {
        e.preventDefault();
        e.stopPropagation();
        openSlot({
          slug,
          label: label || slug,
          type: "text",
          page,
          currentValue: value,
          currentSize: size,
          currentColor: color,
          hasSize: !!sizeMap,
          hasColor: true
        });
      }}
      title={`Cliquer pour éditer · ${label || slug}`}
    >
      {value || children}
    </Tag>
  );
}