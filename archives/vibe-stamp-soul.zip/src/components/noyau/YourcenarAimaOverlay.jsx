import React, { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";

/**
 * YourcenarAimaOverlay — fenêtre Aïma qui s'ouvre depuis le bas après le 8 juin.
 * Phrase d'accueil inspirée de Yourcenar (sans la simuler) + 4 choix.
 * Le choix « Je suis atteint de SLA » oriente vers /noyau.
 */

const RESPONSES = {
  vie: "Par où commence la vôtre ? Un souvenir, un prénom, une date — dites-moi simplement ce qui vient.",
  transmettre: "À qui voulez-vous transmettre ? Un enfant, un proche, quelqu'un qui n'est pas encore né ?",
  noyau: "NOYAU garde ce que vous êtes — voix, histoires, valeurs. Tout commence par une question simple : quel est le souvenir qui vous fait encore sourire ?",
  sla: "Je vous entends. Nous allons avancer ensemble, à votre rythme, sans pression. Commençons par votre prénom."
};

const CHOICES = [
  { label: "Raconter ma vie", value: "Je veux raconter ma vie", key: "vie" },
  { label: "Transmettre", value: "Je veux transmettre quelque chose", key: "transmettre" },
  { label: "Découvrir NOYAU", value: "Je découvre NOYAU", key: "noyau" },
  { label: "Je suis atteint de SLA", value: "Je suis atteint de SLA", key: "sla", redirect: "/noyau" }
];

export default function YourcenarAimaOverlay({ open, onClose }) {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const navigate = useNavigate();
  const msgsRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    if (open) setTimeout(() => inputRef.current?.focus(), 100);
  }, [open]);

  useEffect(() => {
    if (msgsRef.current) msgsRef.current.scrollTop = msgsRef.current.scrollHeight;
  }, [messages]);

  const reply = (text) => {
    const lower = text.toLowerCase();
    for (const [key, resp] of Object.entries(RESPONSES)) {
      if (lower.includes(key) || lower.includes(key === "sla" ? "sla" : "")) return resp;
    }
    return "Je retiens chaque mot. Continuez — qu'est-ce qui vous tient le plus à cœur ?";
  };

  const send = (text) => {
    const val = (text ?? input).trim();
    if (!val) return;
    setInput("");
    setMessages((m) => [...m, { role: "user", text: val }]);
    setTimeout(() => {
      setMessages((m) => [...m, { role: "aima", text: reply(val) }]);
    }, 700);
  };

  const onChoice = (c) => {
    setMessages((m) => [...m, { role: "user", text: c.value }, { role: "aima", text: RESPONSES[c.key] }]);
    if (c.redirect) {
      setTimeout(() => navigate(c.redirect), 1400);
    }
  };

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-[100] flex items-end justify-center p-6"
      style={{ background: "rgba(0,0,0,0.75)", backdropFilter: "blur(6px)" }}
      onClick={onClose}
    >
      <div
        className="w-full max-w-[580px] overflow-hidden"
        style={{
          background: "#0d0b09",
          border: "0.5px solid rgba(255,255,255,0.1)",
          borderRadius: "20px 20px 0 0"
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div
          className="flex items-center gap-2.5 px-5 py-4"
          style={{ borderBottom: "0.5px solid rgba(255,255,255,0.07)" }}
        >
          <div
            className="w-[30px] h-[30px] rounded-full flex items-center justify-center flex-shrink-0"
            style={{
              background: "rgba(184,154,82,0.9)",
              fontFamily: "'Playfair Display', serif",
              fontSize: 13,
              color: "#0a0806"
            }}
          >
            A
          </div>
          <div>
            <div className="text-[13px] font-medium text-white/90">Aïma · NOYAU</div>
            <div className="text-[11px] text-white/35 mt-px">Inspirée de Marguerite Yourcenar</div>
          </div>
          <button
            onClick={onClose}
            className="ml-auto text-white/35 hover:text-white/70 text-xl leading-none p-1"
            aria-label="Fermer"
          >
            ×
          </button>
        </div>

        {/* Messages */}
        <div
          ref={msgsRef}
          className="px-5 py-5 flex flex-col gap-3 overflow-y-auto"
          style={{ minHeight: 180, maxHeight: 320 }}
        >
          <div
            className="italic text-white/80 leading-[1.7] max-w-[88%]"
            style={{ fontFamily: "'Playfair Display', serif", fontSize: 14 }}
          >
            Bonjour. Je suis Aïma.
            <br />
            <br />
            Marguerite Yourcenar disait que ne pas raconter sa vie est le plus grand dommage qu'on puisse lui faire.
            <br />
            <br />
            Je suis là pour garder ce que vous êtes — votre voix, vos histoires, ce que vous voulez transmettre.
            {messages.length === 0 && (
              <div className="flex flex-wrap gap-1.5 mt-3 not-italic font-sans">
                {CHOICES.map((c) => (
                  <button
                    key={c.key}
                    onClick={() => onChoice(c)}
                    className="px-3.5 py-1.5 rounded-full border text-[12px] transition-all"
                    style={{
                      borderColor: "rgba(255,255,255,0.12)",
                      color: "rgba(255,255,255,0.65)",
                      background: "transparent",
                      fontFamily: "'DM Sans', sans-serif"
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.borderColor = "rgba(184,154,82,0.5)";
                      e.currentTarget.style.color = "rgba(184,154,82,0.9)";
                      e.currentTarget.style.background = "rgba(184,154,82,0.06)";
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.borderColor = "rgba(255,255,255,0.12)";
                      e.currentTarget.style.color = "rgba(255,255,255,0.65)";
                      e.currentTarget.style.background = "transparent";
                    }}
                  >
                    {c.label}
                  </button>
                ))}
              </div>
            )}
          </div>

          {messages.map((m, i) =>
            m.role === "user" ? (
              <div
                key={i}
                className="self-end px-3.5 py-2 text-[13px] text-white/85 max-w-[80%]"
                style={{
                  background: "rgba(184,154,82,0.15)",
                  borderRadius: "12px 4px 12px 12px"
                }}
              >
                {m.text}
              </div>
            ) : (
              <div
                key={i}
                className="italic text-white/80 leading-[1.7] max-w-[88%]"
                style={{ fontFamily: "'Playfair Display', serif", fontSize: 14 }}
              >
                {m.text}
              </div>
            )
          )}
        </div>

        {/* Input */}
        <div
          className="flex gap-2 items-center px-4 py-3"
          style={{
            borderTop: "0.5px solid rgba(255,255,255,0.07)",
            background: "rgba(255,255,255,0.95)"
          }}
        >
          <input
            ref={inputRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && send()}
            placeholder="Répondre à Aïma…"
            className="flex-1 outline-none bg-transparent text-[13px] text-stone-900 placeholder:text-stone-400"
            style={{ fontFamily: "'DM Sans', sans-serif" }}
          />
          <button
            onClick={() => send()}
            className="w-[30px] h-[30px] rounded-full bg-[#0a0806] text-white flex items-center justify-center flex-shrink-0 text-sm hover:bg-black"
            aria-label="Envoyer"
          >
            →
          </button>
        </div>
      </div>
    </div>
  );
}