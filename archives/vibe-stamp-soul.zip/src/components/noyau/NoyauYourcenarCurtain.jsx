import React, { useEffect, useRef, useState } from "react";
import YourcenarAimaOverlay from "./YourcenarAimaOverlay";
import EditableText from "@/components/edit/EditableText";

/**
 * NoyauYourcenarCurtain — rideau d'ouverture de la page NOYAU.
 * Hommage à Marguerite Yourcenar (Mont Noir, 8 juin 1903).
 * Effet glitch entre "Yourcenar" et "Crayencour" + countdown jusqu'au 8 juin 2026.
 * Adapté du HTML statique yourcenar-8juin.html.
 */

const YOURCENAR = "Yourcenar";
const CRAYENCOUR = "Crayencour";
const TARGET = new Date("2026-06-08T00:00:00").getTime();

const pad = (n) => String(n).padStart(2, "0");

export default function NoyauYourcenarCurtain({ onEnter }) {
  const nameRef = useRef(null);
  const labelRef = useRef(null);
  const [current, setCurrent] = useState(YOURCENAR);
  const [now, setNow] = useState(Date.now());
  const [aimaOpen, setAimaOpen] = useState(false);
  const animatingRef = useRef(false);

  // Countdown tick
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);

  // Glitch cycle
  useEffect(() => {
    let timeoutId;
    const scheduleCycle = () => {
      const wait = Math.random() * 7000 + 6000;
      timeoutId = setTimeout(() => {
        setCurrent((cur) => {
          const next = cur === YOURCENAR ? CRAYENCOUR : YOURCENAR;
          glitchTransition(next);
          return next;
        });
        scheduleCycle();
      }, wait);
    };
    timeoutId = setTimeout(scheduleCycle, 3500);
    return () => clearTimeout(timeoutId);
  }, []);

  const glitchTransition = (to) => {
    if (!nameRef.current || animatingRef.current) return;
    animatingRef.current = true;
    const letters = nameRef.current.querySelectorAll(".letter");
    letters.forEach((l, i) => {
      setTimeout(() => l.classList.add("glitch"), i * 38);
    });
    setTimeout(() => {
      if (labelRef.current) {
        labelRef.current.style.opacity = "1";
        labelRef.current.textContent =
          to === YOURCENAR
            ? "de naissance : Cleenewerck de Crayencour"
            : "anagramme : Yourcenar";
        setTimeout(() => {
          if (labelRef.current) {
            labelRef.current.style.opacity = "0";
            setTimeout(() => {
              if (labelRef.current) labelRef.current.textContent = "";
              animatingRef.current = false;
            }, 400);
          }
        }, 2200);
      }
    }, letters.length * 38 + 180);
  };

  const diff = Math.max(0, TARGET - now);
  const j = Math.floor(diff / 86400000);
  const h = Math.floor((diff % 86400000) / 3600000);
  const m = Math.floor((diff % 3600000) / 60000);
  const s = Math.floor((diff % 60000) / 1000);
  const isOpen = diff <= 0;

  return (
    <section
      className="relative min-h-screen flex flex-col items-center justify-center px-8 py-16 text-center overflow-hidden"
      style={{ backgroundColor: "#07060A", color: "rgba(255,255,255,0.85)" }}
    >
      <style>{`
        @keyframes nyc-glitch {
          0%   { opacity: 1;   transform: none; }
          20%  { opacity: 0.2; transform: translateX(1px); }
          40%  { opacity: 0.8; transform: translateX(-1px); }
          60%  { opacity: 0.3; transform: none; }
          80%  { opacity: 0.9; }
          100% { opacity: 1;   transform: none; }
        }
        .nyc-letter { display: inline-block; position: relative; transition: opacity 0.08s; }
        .nyc-letter.glitch { animation: nyc-glitch 0.12s ease forwards; }
      `}</style>

      <div className="text-[10px] tracking-[0.28em] uppercase text-white/25 mb-10">
        Mont Noir · Hauts-de-France
      </div>

      <div className="mb-2 min-h-[110px] flex flex-col items-center justify-center">
        <div
          ref={nameRef}
          className="font-light leading-[0.95] text-white flex flex-wrap justify-center"
          style={{
            fontFamily: "'Playfair Display', serif",
            fontSize: "clamp(38px, 7vw, 82px)",
            letterSpacing: "-0.02em"
          }}
        >
          {current.split("").map((ch, i) => (
            <span key={i} className="nyc-letter letter">
              {ch}
            </span>
          ))}
        </div>
        <div
          ref={labelRef}
          className="mt-2 text-[10px] tracking-[0.18em] uppercase text-white/20 italic min-h-[16px] transition-opacity duration-500"
          style={{ opacity: 0 }}
        />
      </div>

      <div
        className="font-light italic text-white/30 mb-10"
        style={{
          fontFamily: "'Playfair Display', serif",
          fontSize: "clamp(13px, 1.5vw, 16px)",
          letterSpacing: "0.15em"
        }}
      >
        1903 &nbsp;·&nbsp; 1987
      </div>

      <div className="w-9 h-px bg-white/10 mx-auto mb-10" />

      <blockquote
        className="font-light italic text-white/55 leading-[1.8] max-w-[500px] mb-3"
        style={{
          fontFamily: "'Playfair Display', serif",
          fontSize: "clamp(14px, 1.8vw, 19px)"
        }}
      >
        « Le plus grand dommage que puisse faire un homme
        <br />à sa propre vie est de ne pas la raconter. »
      </blockquote>
      <div className="text-[10px] tracking-[0.14em] uppercase text-white/20 mb-10">
        Mémoires d'Hadrien
      </div>

      {!isOpen && (
        <>
          <div className="text-[10px] tracking-[0.22em] uppercase text-white/25 mb-5">
            La mémoire s'ouvre dans
          </div>
          <div className="flex gap-7 justify-center mb-12">
            <CdUnit num={pad(j)} label="Jours" />
            <CdSep />
            <CdUnit num={pad(h)} label="Heures" />
            <CdSep />
            <CdUnit num={pad(m)} label="Minutes" />
            <CdSep />
            <CdUnit num={pad(s)} label="Secondes" />
          </div>
        </>
      )}

      {isOpen && (
        <>
          <EditableText
            slug="noyau.opening.text"
            label="NOYAU — texte d'ouverture (jour J)"
            page="/noyau"
            as="p"
            className="font-light italic text-white/65 leading-[1.75] max-w-[460px] mx-auto mb-8 whitespace-pre-line"
            style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: "clamp(15px, 2.2vw, 20px)"
            }}
            defaultValue={`Le 8 juin 1903 naissait Marguerite Yourcenar au Mont Noir.\nAujourd'hui NOYAU s'ouvre —\npour que chaque vie puisse être racontée.`}
          />
          <button
            onClick={() => setAimaOpen(true)}
            className="px-8 py-3.5 rounded-full border border-white/20 text-[11px] tracking-[0.14em] uppercase text-white/60 hover:border-white/45 hover:text-white transition-all"
          >
            <EditableText
              slug="noyau.cta.label"
              label="NOYAU — bouton CTA (jour J)"
              page="/noyau"
              as="span"
              defaultValue="Parler à Aïma →"
            />
          </button>
        </>
      )}

      <div className="mt-12 text-[9px] tracking-[0.18em] uppercase text-white/10">
        AIME® · Point Zéro des Vivants
      </div>

      <YourcenarAimaOverlay open={aimaOpen} onClose={() => setAimaOpen(false)} />
    </section>
  );
}

function CdUnit({ num, label }) {
  return (
    <div className="flex flex-col items-center gap-2">
      <div
        className="font-light text-white leading-none min-w-[62px]"
        style={{
          fontFamily: "'Playfair Display', serif",
          fontSize: "clamp(32px, 5.5vw, 60px)"
        }}
      >
        {num}
      </div>
      <div className="text-[9px] tracking-[0.18em] uppercase text-white/20">{label}</div>
    </div>
  );
}

function CdSep() {
  return (
    <div
      className="font-light text-white/15 self-start pt-1"
      style={{
        fontFamily: "'Playfair Display', serif",
        fontSize: "clamp(24px, 4vw, 44px)"
      }}
    >
      ·
    </div>
  );
}