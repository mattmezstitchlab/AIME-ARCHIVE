import React from "react";
import { motion } from "framer-motion";

/**
 * NoyauPhaseCard — Carte phase NOYAU alignée sur la référence.
 * Numéro géant fantôme · tag Phase · titre serif · italique · description · bullets dorées.
 */
export default function NoyauPhaseCard({ n, title, italic, description, bullets = [], delay = 0 }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.5, delay }}
      className="rounded-2xl border border-white/[0.07] bg-white/[0.02] p-6 md:p-7 hover:border-[#B89A52]/25 transition-colors"
    >
      <div
        className="font-light leading-none mb-2 text-white/[0.06]"
        style={{ fontFamily: "'Playfair Display', serif", fontSize: "40px" }}
      >
        {n}
      </div>
      <div className="text-[9px] tracking-[0.2em] uppercase text-[#B89A52] mb-2">Phase</div>
      <h3
        className="text-white mb-2"
        style={{ fontFamily: "'Playfair Display', serif", fontSize: "20px", fontWeight: 400 }}
      >
        {title}
      </h3>
      <p
        className="italic text-white/45 mb-3 leading-snug"
        style={{ fontFamily: "'Playfair Display', serif", fontSize: "13px" }}
      >
        {italic}
      </p>
      <p className="text-white/40 text-[12px] leading-[1.6] mb-3">{description}</p>
      {bullets.length > 0 && (
        <div className="flex flex-col gap-1.5">
          {bullets.map((b) => (
            <div
              key={b}
              className="text-[11px] text-white/35 leading-[1.45] pl-3 relative"
            >
              <span className="absolute left-0 text-[#B89A52]">·</span>
              {b}
            </div>
          ))}
        </div>
      )}
    </motion.div>
  );
}