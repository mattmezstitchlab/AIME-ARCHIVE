import React from "react";

/**
 * NoyauIcon — gravure dorée fine du noyau cellulaire / atomique.
 * Cercle central avec point, entouré de 3 orbites elliptiques fines.
 * À la fois cellule, atome, soleil avec planètes. Ce qui rayonne après.
 */
export default function NoyauIcon({ size = 48, color = "#B89A52", strokeWidth = 1 }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      stroke={color}
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {/* Noyau central */}
      <circle cx="32" cy="32" r="6" />
      <circle cx="32" cy="32" r="1.4" fill={color} stroke="none" />

      {/* Orbites — 3 ellipses tournées */}
      <ellipse cx="32" cy="32" rx="22" ry="9" />
      <ellipse cx="32" cy="32" rx="22" ry="9" transform="rotate(60 32 32)" />
      <ellipse cx="32" cy="32" rx="22" ry="9" transform="rotate(120 32 32)" />

      {/* Planètes/électrons */}
      <circle cx="54" cy="32" r="1.2" fill={color} stroke="none" />
      <circle cx="21" cy="13" r="1.2" fill={color} stroke="none" />
      <circle cx="21" cy="51" r="1.2" fill={color} stroke="none" />
    </svg>
  );
}