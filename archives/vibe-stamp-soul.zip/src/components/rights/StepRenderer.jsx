import React, { useState, useMemo } from "react";
import { COUNTRIES } from "@/lib/musicRightsData";

/**
 * StepRenderer — moteur d'affichage générique pour une étape AIME® Rights.
 * Gère 4 kinds : "country", "single", "multi", "form".
 */

const Question = ({ eyebrow, title, children, hint }) => (
  <div>
    <div className="text-[10px] tracking-[4px] text-[#B89A52] uppercase mb-3">{eyebrow}</div>
    <h2 className="apple-headline text-[#1A1208] text-2xl md:text-3xl mb-7">{title}</h2>
    {hint && <p className="text-[12px] text-[#8A7A60] mb-4 -mt-4">{hint}</p>}
    {children}
  </div>
);

const Choice = ({ active, onClick, label, desc }) => (
  <button
    type="button"
    onClick={onClick}
    className={`w-full text-left p-4 rounded-2xl border transition-all ${
      active
        ? "border-[#B89A52] bg-[#FEFAF0] shadow-[0_2px_8px_rgba(184,154,82,0.12)]"
        : "border-[#B89A52]/20 bg-white hover:border-[#B89A52]/50 hover:bg-[#FEFCF6]"
    }`}
  >
    <div className={`text-[14px] font-medium ${active ? "text-[#1A1208]" : "text-[#3A2E1A]"}`}>{label}</div>
    {desc && <div className="text-[12px] text-[#8A7A60] mt-1 leading-relaxed">{desc}</div>}
  </button>
);

export default function StepRenderer({ step, stepIndex, total, data, set }) {
  const eyebrow = `Étape ${stepIndex + 1} / ${total}`;

  if (step.kind === "country") {
    return <CountryStep eyebrow={eyebrow} data={data} set={set} />;
  }

  if (step.kind === "single") {
    const cols = step.columns === 2 ? "grid grid-cols-1 sm:grid-cols-2 gap-2" : "space-y-2";
    return (
      <Question eyebrow={eyebrow} title={step.title}>
        <div className={cols}>
          {step.options.map((o) => (
            <Choice
              key={o.id}
              label={o.label}
              desc={o.desc}
              active={data[step.id] === o.id}
              onClick={() => set({ [step.id]: o.id })}
            />
          ))}
        </div>
      </Question>
    );
  }

  if (step.kind === "multi") {
    const current = data[step.id] || [];
    const toggle = (id) => {
      const next = current.includes(id) ? current.filter((x) => x !== id) : [...current, id];
      set({ [step.id]: next });
    };
    return (
      <Question eyebrow={eyebrow} title={step.title} hint="Plusieurs choix possibles.">
        <div className="space-y-2">
          {step.options.map((o) => {
            const active = current.includes(o.id);
            return (
              <button
                key={o.id}
                type="button"
                onClick={() => toggle(o.id)}
                className={`w-full text-left p-4 rounded-2xl border transition-all flex items-start gap-3 ${
                  active
                    ? "border-[#B89A52] bg-[#FEFAF0]"
                    : "border-[#B89A52]/20 bg-white hover:border-[#B89A52]/50 hover:bg-[#FEFCF6]"
                }`}
              >
                <div
                  className={`mt-0.5 w-4 h-4 rounded border flex-shrink-0 flex items-center justify-center ${
                    active ? "bg-[#B89A52] border-[#B89A52]" : "border-[#B89A52]/40 bg-white"
                  }`}
                >
                  {active && (
                    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                      <polyline points="20 6 9 17 4 12" />
                    </svg>
                  )}
                </div>
                <div>
                  <div className="text-[14px] font-medium text-[#1A1208]">{o.label}</div>
                  {o.desc && <div className="text-[12px] text-[#8A7A60] mt-0.5">{o.desc}</div>}
                </div>
              </button>
            );
          })}
        </div>
      </Question>
    );
  }

  if (step.kind === "form") {
    return (
      <Question eyebrow={eyebrow} title={step.title}>
        <div className="space-y-3">
          {step.fields.map((f) => (
            <div key={f.id}>
              <label className="block text-[11px] tracking-[2px] uppercase text-[#8A7A60] mb-1.5">{f.label}</label>
              {f.type === "select" ? (
                <select
                  value={data[f.id] || ""}
                  onChange={(e) => set({ [f.id]: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl border border-[#B89A52]/25 bg-white text-[14px] outline-none focus:border-[#B89A52]"
                >
                  <option value="">— sélectionner —</option>
                  {f.options.map((o) => (
                    <option key={o.id} value={o.id}>{o.label}</option>
                  ))}
                </select>
              ) : (
                <input
                  type={f.type || "text"}
                  step={f.step}
                  placeholder={f.placeholder}
                  value={data[f.id] || ""}
                  onChange={(e) => set({ [f.id]: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl border border-[#B89A52]/25 bg-white text-[14px] outline-none focus:border-[#B89A52]"
                />
              )}
            </div>
          ))}
        </div>
      </Question>
    );
  }

  return null;
}

function CountryStep({ eyebrow, data, set }) {
  const [search, setSearch] = useState("");
  const filtered = useMemo(() => {
    const s = search.toLowerCase().trim();
    if (!s) return COUNTRIES;
    return COUNTRIES.filter((c) => c.label.toLowerCase().includes(s) || c.code.toLowerCase().includes(s));
  }, [search]);

  return (
    <Question eyebrow={eyebrow} title="Depuis quel pays travailles-tu ?">
      <input
        type="text"
        placeholder="Rechercher un pays…"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="w-full mb-3 px-4 py-3 rounded-xl border border-[#B89A52]/25 bg-white text-[14px] outline-none focus:border-[#B89A52]"
      />
      <div className="max-h-[280px] overflow-y-auto pr-1 space-y-1.5">
        {filtered.map((c) => (
          <button
            key={c.code}
            type="button"
            onClick={() => set({ country: c.code, country_label: c.label })}
            className={`w-full text-left flex items-center justify-between px-4 py-2.5 rounded-lg border transition-colors ${
              data.country === c.code
                ? "border-[#B89A52] bg-[#FEFAF0]"
                : "border-[#B89A52]/15 bg-white hover:bg-[#FEFCF6]"
            }`}
          >
            <span className="text-[13.5px] text-[#1A1208]">{c.label}</span>
            <span className="text-[10px] tracking-widest text-[#B89A52]">{c.code}</span>
          </button>
        ))}
      </div>
    </Question>
  );
}