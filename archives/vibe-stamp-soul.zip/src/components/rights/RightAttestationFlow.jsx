import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { getAnonymousId } from "@/lib/aimaSession";
import { generateTimbreCode } from "@/lib/timbreCode";
import { generateRightPdf } from "@/lib/rights/genericPdf";
import { createCaseFromGeneration } from "@/lib/cabinet/caseHelpers";

import MusicRightsShell from "@/components/musicrights/MusicRightsShell";
import MusicRightsProgress from "@/components/musicrights/MusicRightsProgress";
import StepRenderer from "@/components/rights/StepRenderer";

/**
 * RightAttestationFlow — moteur générique du flow d'attestation AIME® Rights.
 * Reçoit une config (slug, steps, buildAttestation, profileFields, highlight…)
 * et exécute : intro → étapes → synthèse → génération PDF.
 */
export default function RightAttestationFlow({ config }) {
  const TOTAL = config.steps.length;
  const [step, setStep] = useState(0); // 0=intro, 1..TOTAL=étapes, TOTAL+1=synthèse
  const [data, setData] = useState({ needs: [] });
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        let user = null;
        try { user = await base44.auth.me(); } catch (_) {}
        const filter = user?.email
          ? { owner_email: user.email }
          : { anonymous_id: getAnonymousId() };
        const list = await base44.entities.Timbre.filter(filter, "-issued_at", 1);
        if (!cancelled && list?.[0]) {
          setData((d) => ({
            ...d,
            first_name: list[0].first_name,
            last_name: list[0].last_name,
            timbre_id: list[0].id
          }));
        }
      } catch (_) {}
    })();
    return () => { cancelled = true; };
  }, []);

  const set = (patch) => setData((d) => ({ ...d, ...patch }));

  const validateStep = (s) => {
    const stepDef = config.steps[s - 1];
    if (!stepDef) return true;
    if (stepDef.kind === "country") return !!data.country;
    if (stepDef.kind === "single") return !!data[stepDef.id];
    if (stepDef.kind === "multi") return (data[stepDef.id] || []).length > 0;
    if (stepDef.kind === "form") return stepDef.fields.every((f) => data[f.id] !== undefined && data[f.id] !== "");
    return true;
  };

  const next = () => {
    setError(null);
    if (step >= 1 && step <= TOTAL && !validateStep(step)) {
      setError("Merci de répondre à cette question pour continuer.");
      return;
    }
    setStep((s) => s + 1);
  };
  const prev = () => setStep((s) => Math.max(0, s - 1));

  const generate = async () => {
    setGenerating(true);
    setError(null);
    try {
      const code = data.code || `MR·${generateTimbreCode("M", "R").split("·").slice(1).join("·")}`;
      const all = await base44.entities.MusicRight.list("-registry_n", 1).catch(() => []);
      const registry_n = (all?.[0]?.registry_n || 0) + 1;
      const issued_at = new Date().toISOString();

      let user = null;
      try { user = await base44.auth.me(); } catch (_) {}

      // Persistance minimale dans MusicRight (entité existante) — on stocke le slug en plus
      const record = {
        code,
        registry_n,
        issued_at,
        country: data.country,
        country_label: data.country_label,
        first_name: data.first_name,
        last_name: data.last_name,
        timbre_id: data.timbre_id,
        owner_email: user?.email,
        anonymous_id: user?.email ? undefined : getAnonymousId()
      };
      try { await base44.entities.MusicRight.create(record); } catch (_) {}

      const pdf = generateRightPdf(config, { ...data, ...record });
      pdf.save(`${config.pdfFilenamePrefix}-${code.replace(/·/g, "-")}.pdf`);

      // Mon Cabinet — création du dossier vivant suivi par Aïma
      const estimated = config.highlight ? config.highlight({ ...data, ...record }) : null;
      const estimatedAmount = estimated?.value?.match?.(/(\d[\d\s]*)\s*€/)?.[1]
        ?.replace(/\s/g, "") || 0;
      try {
        await createCaseFromGeneration({
          right_slug: config.slug,
          right_label: config.rightLabel || config.pdfTitle,
          code,
          registry_n,
          country: data.country,
          first_name: data.first_name,
          last_name: data.last_name,
          estimated_value_eur: parseInt(estimatedAmount, 10) || 0
        });
      } catch (_) {}

      setData((d) => ({ ...d, code, registry_n, issued_at }));
    } catch (e) {
      setError("Erreur de génération : " + (e.message || ""));
    } finally {
      setGenerating(false);
    }
  };

  const share = () => {
    const text = config.shareText || `J'ai obtenu mon attestation AIME® Rights.`;
    const url = window.location.href;
    if (navigator.share) {
      navigator.share({ title: "AIME® Rights", text, url }).catch(() => {});
    } else {
      const linkedin = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}&summary=${encodeURIComponent(text)}`;
      window.open(linkedin, "_blank");
    }
  };

  return (
    <MusicRightsShell>
      <div className="max-w-2xl mx-auto px-6 py-12 md:py-16">
        {/* Lien retour */}
        <Link
          to="/music-rights"
          className="inline-block mb-8 text-[10px] tracking-[3px] text-[#8A7A60] uppercase hover:text-[#B89A52] transition-colors"
        >
          ← Tous les droits AIME®
        </Link>

        {/* INTRO */}
        {step === 0 && (
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center"
          >
            <div className="text-[10px] tracking-[5px] text-[#B89A52] uppercase mb-4">
              Une innovation AIME®
            </div>
            <h1 className="apple-headline text-[#1A1208] text-4xl md:text-5xl mb-5">
              {config.title}
              <br />
              <span className="text-[#B89A52]">{config.italic}</span>
            </h1>
            <p className="text-[15px] text-[#4A3C28] max-w-md mx-auto leading-relaxed mb-7">
              {config.intro}
            </p>

            {/* Mot d'accueil contextualisé d'Aïma */}
            {config.naimaGreeting && (
              <div className="max-w-md mx-auto mb-8 rounded-2xl bg-[#F0E6C8]/40 border border-[#B89A52]/25 px-5 py-4 text-left">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-[#B89A52] text-[#1A1208] flex items-center justify-center font-serif text-[14px] flex-shrink-0">
                    A
                  </div>
                  <div className="flex-1">
                    <div className="text-[10px] tracking-[2.5px] uppercase text-[#B89A52] mb-1.5 font-medium">
                      Aïma
                    </div>
                    <p className="text-[13px] text-[#1A1208] leading-relaxed font-serif italic">
                      {config.naimaGreeting}
                    </p>
                  </div>
                </div>
              </div>
            )}
            <div className="flex justify-center gap-2 mb-10 flex-wrap">
              {["Juridique", "Scientifique", "Personnalisé", "PDF prêt à signer"].map((t) => (
                <span
                  key={t}
                  className="px-3 py-1 rounded-full border border-[#B89A52]/30 text-[10px] tracking-[2px] uppercase text-[#8A7A60]"
                >
                  {t}
                </span>
              ))}
            </div>
            <button
              onClick={() => setStep(1)}
              className="px-10 py-4 rounded-full bg-[#1A1208] text-[#F0E6C8] text-[10px] tracking-[3px] uppercase hover:bg-[#B89A52] hover:text-[#1A1208] transition-colors"
            >
              {config.ctaLabel} ✦
            </button>
            <p className="text-[10px] text-[#8A7A60] mt-5 tracking-wider">
              ≈ 3 minutes · 100 % gratuit · attestation immédiate
            </p>
          </motion.div>
        )}

        {/* STEPS */}
        {step >= 1 && step <= TOTAL && (
          <div
            className="rounded-3xl p-7 md:p-10 backdrop-blur-md border bg-white/85"
            style={{
              borderColor: "rgba(184,154,82,0.25)",
              boxShadow: "0 24px 80px rgba(26,18,8,0.06), 0 4px 16px rgba(26,18,8,0.03)"
            }}
          >
            <MusicRightsProgress step={step} total={TOTAL} />
            <AnimatePresence mode="wait">
              <motion.div
                key={step}
                initial={{ opacity: 0, x: 16 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -16 }}
                transition={{ duration: 0.3 }}
              >
                <StepRenderer
                  step={config.steps[step - 1]}
                  stepIndex={step - 1}
                  total={TOTAL}
                  data={data}
                  set={set}
                />
              </motion.div>
            </AnimatePresence>

            {error && <p className="text-[11px] text-[#c0392b] mt-3">{error}</p>}

            <div className="flex items-center justify-between mt-9">
              <button
                onClick={prev}
                className={`text-[10px] tracking-[3px] text-[#8A7A60] uppercase hover:text-[#1A1208] transition-colors ${
                  step <= 1 ? "invisible" : ""
                }`}
              >
                ← Retour
              </button>
              <button
                onClick={next}
                className="px-9 py-3.5 rounded-full bg-[#1A1208] text-[#F0E6C8] text-[9px] tracking-[3px] uppercase hover:bg-[#B89A52] hover:text-[#1A1208] transition-colors"
              >
                {step === TOTAL ? "Voir la synthèse →" : "Suivant →"}
              </button>
            </div>
          </div>
        )}

        {/* SYNTHÈSE */}
        {step === TOTAL + 1 && (
          <RightSummary
            config={config}
            data={data}
            onGenerate={generate}
            onShare={share}
            generating={generating}
          />
        )}

        {error && step === TOTAL + 1 && <p className="text-[11px] text-[#c0392b] mt-3 text-center">{error}</p>}

        <div className="text-center mt-10 text-[8px] tracking-[3px] text-[#8A7A60]/70 uppercase">
          AIME® Rights · Marques INPI 5164817 / 5226732
        </div>
      </div>
    </MusicRightsShell>
  );
}

/* ─── Synthèse générique ─── */
function RightSummary({ config, data, onGenerate, onShare, generating }) {
  const fields = config.profileFields(data);
  const highlight = config.highlight ? config.highlight(data) : null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <div className="text-center mb-8">
        <div className="text-[10px] tracking-[5px] text-[#B89A52] uppercase mb-3">
          Synthèse de ton profil
        </div>
        <h1 className="apple-headline text-[#1A1208] text-3xl md:text-4xl mb-3">
          Votre <span className="text-[#B89A52]">{config.italic.replace(/\.$/, "")}</span>
          <br />
          est prêt.
        </h1>
        <p className="text-[13px] text-[#4A3C28] max-w-md mx-auto leading-relaxed">
          Une attestation officielle, juridiquement argumentée — tissée à partir de vos réponses.
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-6">
        {fields.map((f) => (
          <div key={f.label} className="rounded-2xl border border-[#B89A52]/20 bg-white p-4">
            <div className="text-[18px] mb-1.5 text-[#B89A52]" style={{ fontFamily: "'Playfair Display', serif" }}>◇</div>
            <div className="text-[9px] tracking-[2.5px] text-[#8A7A60] uppercase mb-1">{f.label}</div>
            <div className="text-[13px] text-[#1A1208] leading-tight">{f.value || "—"}</div>
          </div>
        ))}
      </div>

      {highlight && (
        <div className="rounded-2xl bg-[#FEFAF0] border border-[#B89A52]/25 p-4 mb-8">
          <div className="flex items-start gap-2.5">
            <span className="text-[#B89A52] text-[16px] mt-0.5">✦</span>
            <div>
              <div className="text-[10px] tracking-[2.5px] text-[#8A7A60] uppercase mb-1">{highlight.label}</div>
              <div className="text-[13px] text-[#1A1208] leading-relaxed">{highlight.value}</div>
            </div>
          </div>
        </div>
      )}

      <div className="flex flex-col sm:flex-row gap-3 justify-center">
        <button
          onClick={onGenerate}
          disabled={generating}
          className="px-9 py-4 rounded-full bg-[#1A1208] text-[#F0E6C8] text-[10px] tracking-[3px] uppercase hover:bg-[#B89A52] hover:text-[#1A1208] transition-colors disabled:opacity-50"
        >
          {generating ? "Génération…" : "Générer mon attestation PDF ✦"}
        </button>
        <button
          onClick={onShare}
          className="px-9 py-4 rounded-full border border-[#B89A52]/40 text-[#4A3C28] text-[10px] tracking-[3px] uppercase hover:bg-[#FEFAF0] transition-colors"
        >
          Partager
        </button>
      </div>
    </motion.div>
  );
}