import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import RightIcon from "./RightIcons";

/**
 * TimbreRightCard — vrai timbre AIME® Rights dentelé.
 * Reprend la dentelure CSS du TimbreCard (4 côtés masks),
 * cadre doré intérieur, icône gravée, slogan, badge DISPONIBLE / BIENTÔT.
 */
export default function TimbreRightCard({ right, delay = 0 }) {
  const available = right.status !== "soon";
  const Wrapper = available ? Link : "div";
  const wrapperProps = available
    ? { to: `/music-rights/${right.slug}` }
    : { onClick: (e) => e.preventDefault() };

  // Mask dentelure 4 côtés (identique TimbreCard)
  const mask = `
    radial-gradient(circle at 50% -1px, transparent 5px, #000 5.5px) 0 0 / 13px 100% repeat-x,
    radial-gradient(circle at 50% calc(100% + 1px), transparent 5px, #000 5.5px) 0 100% / 13px 100% repeat-x,
    radial-gradient(circle at -1px 50%, transparent 5px, #000 5.5px) 0 0 / 100% 13px repeat-y,
    radial-gradient(circle at calc(100% + 1px) 50%, transparent 5px, #000 5.5px) 100% 0 / 100% 13px repeat-y
  `;

  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ delay, duration: 0.5 }}
      whileHover={available ? { y: -4 } : {}}
      style={{ filter: "drop-shadow(0 4px 14px rgba(26,18,8,0.10)) drop-shadow(0 1px 3px rgba(26,18,8,0.06))" }}
    >
      <Wrapper
        {...wrapperProps}
        className={`block ${available ? "cursor-pointer" : "cursor-default"}`}
      >
        {/* Corps du timbre avec dentelure */}
        <div
          style={{
            background: "#FEFCF8",
            padding: "22px 18px 18px",
            WebkitMask: mask,
            mask
          }}
        >
          {/* Cadre doré interne */}
          <div
            className="relative"
            style={{
              border: "1px solid rgba(184,154,82,0.32)",
              padding: "20px 16px 18px",
              minHeight: 200,
              display: "flex",
              flexDirection: "column"
            }}
          >
            {/* Cadre intérieur très fin */}
            <div
              className="absolute pointer-events-none"
              style={{ inset: 4, border: "0.5px solid rgba(184,154,82,0.15)" }}
            />

            {/* Top — n° + AIME® */}
            <div className="flex justify-between items-center mb-3">
              <div
                style={{
                  fontFamily: "'Playfair Display', serif",
                  fontSize: 11,
                  fontWeight: 700,
                  letterSpacing: "0.18em",
                  color: "#B89A52"
                }}
              >
                AIME<span style={{ fontSize: "0.55em", verticalAlign: "super" }}>®</span> RIGHTS
              </div>
              <div style={{ fontSize: 9, color: "#B89A52", fontWeight: 500, letterSpacing: "0.1em" }}>
                #{right.n}
              </div>
            </div>

            {/* Icône gravée centrée */}
            <div className="flex items-center justify-center my-3">
              <div
                className="rounded-full flex items-center justify-center"
                style={{
                  width: 64,
                  height: 64,
                  border: "1px solid rgba(184,154,82,0.4)",
                  background: "linear-gradient(135deg, #FBF6E8, #F5ECCF)"
                }}
              >
                <RightIcon name={right.iconName || right.slug} size={28} />
              </div>
            </div>

            {/* Eyebrow */}
            <div
              className="text-center"
              style={{
                fontSize: 8.5,
                letterSpacing: "0.22em",
                color: "#B89A52",
                textTransform: "uppercase",
                marginBottom: 4,
                fontWeight: 500
              }}
            >
              {right.eyebrow}
            </div>

            {/* Titre */}
            <div
              className="text-center"
              style={{
                fontFamily: "'Playfair Display', serif",
                fontSize: 16,
                fontWeight: 600,
                color: "#1A1208",
                lineHeight: 1.2,
                marginBottom: 8,
                padding: "0 4px"
              }}
            >
              {right.label}
            </div>

            {/* Slogan */}
            <div
              className="text-center flex-1 flex items-center justify-center"
              style={{
                fontSize: 12,
                color: "#5A4A30",
                fontStyle: "italic",
                fontFamily: "'Playfair Display', serif",
                lineHeight: 1.45,
                marginBottom: 12,
                padding: "0 6px"
              }}
            >
              « {right.pitch} »
            </div>

            {/* Badge */}
            <div className="flex justify-center mt-auto">
              <span
                style={{
                  fontSize: 8.5,
                  letterSpacing: "0.22em",
                  textTransform: "uppercase",
                  fontWeight: 600,
                  padding: "4px 10px",
                  borderRadius: 99,
                  background: available ? "rgba(132,158,101,0.12)" : "rgba(217,168,80,0.14)",
                  color: available ? "#5C7A45" : "#B07F2B",
                  border: `1px solid ${available ? "rgba(132,158,101,0.3)" : "rgba(217,168,80,0.3)"}`
                }}
              >
                {available ? "Disponible" : "Bientôt"}
              </span>
            </div>
          </div>
        </div>
      </Wrapper>
    </motion.div>
  );
}