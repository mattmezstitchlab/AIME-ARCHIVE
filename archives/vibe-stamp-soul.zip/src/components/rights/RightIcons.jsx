import React from "react";

/**
 * Icônes monolignes "gravure" pour les timbres AIME® Rights.
 * 24×24, stroke #B89A52, esthétique trait fin.
 */
const ICONS = {
  bulle: (
    <>
      <path d="M9 18V6l11-2v12" />
      <circle cx="6" cy="18" r="2.5" />
      <circle cx="17" cy="16" r="2.5" />
    </>
  ),
  silence: (
    <>
      <path d="M5 4h4l2 5-2 1.5a11 11 0 0 0 4 4l1.5-2 5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2Z" />
      <path d="M3 3l18 18" />
    </>
  ),
  thermique: (
    <>
      <path d="M12 3v11" />
      <circle cx="12" cy="17" r="3.5" />
      <path d="M12 14V6a2 2 0 0 1 4 0v8" opacity="0.4" />
    </>
  ),
  teletravail: (
    <>
      <path d="M3 11l9-7 9 7" />
      <path d="M5 10v9h14v-9" />
      <path d="M10 19v-5h4v5" />
    </>
  ),
  pause: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7v5l3 2" />
    </>
  ),
  mobilite: (
    <>
      <path d="M5 16h14l-2-6H7Z" />
      <circle cx="8" cy="17" r="1.5" />
      <circle cx="16" cy="17" r="1.5" />
      <path d="M5 13h14" />
    </>
  ),
  formation: (
    <>
      <path d="M2 9l10-4 10 4-10 4Z" />
      <path d="M6 11v4a6 6 0 0 0 12 0v-4" />
      <path d="M22 9v4" />
    </>
  ),
  dignite: (
    <>
      <rect x="6" y="3" width="12" height="18" rx="1" />
      <circle cx="15" cy="12" r="0.7" fill="currentColor" />
    </>
  ),
  allaitement: (
    <>
      <path d="M12 19s-7-4.5-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 9c0 5.5-7 10-7 10Z" />
      <circle cx="12" cy="11" r="1.5" opacity="0.4" />
    </>
  ),
  lumiere: (
    <>
      <circle cx="12" cy="12" r="4" />
      <path d="M12 3v2M12 19v2M3 12h2M19 12h2M5.6 5.6l1.4 1.4M17 17l1.4 1.4M5.6 18.4 7 17M17 7l1.4-1.4" />
    </>
  ),
  decodeur: (
    <>
      <rect x="4" y="3" width="13" height="18" rx="1" />
      <path d="M7 7h7M7 11h7M7 15h4" />
      <circle cx="17" cy="17" r="3" />
      <path d="m19.5 19.5 2 2" />
    </>
  ),
  fiscal: (
    <>
      <path d="M12 2v20" />
      <path d="M17 6H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" />
    </>
  ),
  heritier: (
    <>
      <rect x="4" y="9" width="16" height="11" rx="1" />
      <path d="M8 9V7a4 4 0 0 1 8 0v2" />
      <circle cx="12" cy="14" r="1.3" />
      <path d="M12 15v2" />
    </>
  )
};

export default function RightIcon({ name, size = 28, color = "#B89A52", strokeWidth = 1.2 }) {
  const path = ICONS[name];
  if (!path) return null;
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke={color}
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {path}
    </svg>
  );
}