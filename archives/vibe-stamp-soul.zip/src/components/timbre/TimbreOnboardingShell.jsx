import React from "react";

/**
 * TimbreOnboardingShell — fond marbré + or, layout commun à tout le flow d'onboarding.
 */
export default function TimbreOnboardingShell({ children }) {
  return (
    <div
      className="min-h-screen relative flex items-center justify-center px-4 py-10"
      style={{
        background: "#FFFFFF",
        fontFamily: "'DM Sans', sans-serif",
        color: "#1A1208"
      }}
    >
      <div className="relative z-10 w-full max-w-xl">{children}</div>
    </div>
  );
}