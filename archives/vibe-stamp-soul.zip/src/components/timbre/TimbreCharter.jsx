import React from "react";
import { AIME_CHARTER } from "@/lib/aimeBrand";

/**
 * TimbreCharter — La charte AIME® avec consentements RGPD granulaires.
 * 4 cases distinctes : data processing, public registry, matching, communications.
 */
export default function TimbreCharter({ consents, setConsents }) {
  const items = [
    {
      key: "consent_data_processing",
      label: "Je consens au traitement de mes données",
      desc: "Conformément au RGPD, dans le strict cadre du registre AIME® (stockage UE).",
      required: true
    },
    {
      key: "consent_public_registry",
      label: "Apparaître dans le Registre public",
      desc: "Mon Timbre devient visible dans la mosaïque universelle (réversible à tout moment).",
      required: false
    },
    {
      key: "consent_matching",
      label: "Autoriser le calcul de résonance",
      desc: "Aïma peut calculer mes affinités avec d'autres Timbres pour suggérer des rencontres.",
      required: false
    },
    {
      key: "consent_communications",
      label: "Recevoir des nouvelles d'AIME®",
      desc: "Évolutions du registre, événements, lettres rares (max 1×/mois).",
      required: false
    }
  ];

  const toggle = (k) => setConsents({ ...consents, [k]: !consents[k] });

  return (
    <div>
      <h2
        className="text-[26px] font-light text-center text-[#1A1208] mb-2"
        style={{ fontFamily: "'Cormorant Garamond', serif" }}
      >
        La <em className="italic text-[#B8963E]">Charte</em> AIME®
      </h2>
      <p className="text-center text-[10px] tracking-[2px] text-[#8A7A60] uppercase mb-6">
        Version {AIME_CHARTER.version} · Engagement sur l'honneur
      </p>

      {/* Charter body */}
      <div
        className="rounded-xl p-5 mb-6 border border-[#D4B483]/30"
        style={{ background: "rgba(212,180,131,0.08)" }}
      >
        <div
          className="text-[#4A3C28] leading-relaxed text-center"
          style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 14, lineHeight: 1.9 }}
        >
          {AIME_CHARTER.body.map((line, i) => (
            <div key={i} className="mb-1">
              {line}
            </div>
          ))}
        </div>
      </div>

      {/* Consent checkboxes */}
      <div className="space-y-3">
        {items.map((it) => {
          const on = !!consents[it.key];
          return (
            <button
              key={it.key}
              onClick={() => toggle(it.key)}
              className="w-full flex items-start gap-3 p-3 rounded-lg hover:bg-[#D4B483]/10 transition-colors text-left"
            >
              <div
                className="w-5 h-5 rounded border flex-shrink-0 flex items-center justify-center mt-0.5 transition-all"
                style={{
                  background: on ? "#1A1208" : "transparent",
                  borderColor: on ? "#1A1208" : "rgba(212,180,131,0.5)"
                }}
              >
                {on && (
                  <svg width="12" height="10" viewBox="0 0 12 10" fill="none">
                    <path
                      d="M1 5l3.5 3.5L11 1"
                      stroke="#D4B483"
                      strokeWidth="1.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                )}
              </div>
              <div className="flex-1">
                <div className="text-[12px] tracking-wide text-[#1A1208] font-medium">
                  {it.label}
                  {it.required && (
                    <span className="ml-1 text-[10px] text-[#B8963E]">· requis</span>
                  )}
                </div>
                <div className="text-[11px] text-[#8A7A60] leading-relaxed mt-0.5">
                  {it.desc}
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}