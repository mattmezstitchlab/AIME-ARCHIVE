import React from "react";
import { AIME_SECTORS, AIME_PASSIONS } from "@/lib/aimeBrand";

/**
 * Composants d'étapes — chacun reçoit { data, set } (état contrôlé).
 * Esthétique marbre/or — Cormorant Garamond pour les questions, Montserrat pour le reste.
 */

const fieldClass =
  "w-full bg-transparent border-0 border-b border-[#D4B483]/40 py-3 text-lg outline-none transition-colors focus:border-[#B8963E] placeholder:text-[#8A7A60]/40 placeholder:italic";
const fieldStyle = { fontFamily: "'Cormorant Garamond', serif", letterSpacing: "0.5px" };

function Q({ children }) {
  return (
    <h2 className="apple-headline text-[#1A1208] text-3xl md:text-4xl mb-3">
      {children}
    </h2>
  );
}

function Hint({ children }) {
  return (
    <p className="text-[10px] tracking-[2px] text-[#8A7A60] uppercase mb-8">{children}</p>
  );
}

export function StepIdentity({ data, set }) {
  return (
    <div>
      <Q>
        Comment vous<br />
        <em className="text-[#B8963E] italic">appelez-vous ?</em>
      </Q>
      <Hint>Votre prénom et nom</Hint>
      <div className="grid grid-cols-2 gap-4">
        <input
          className={fieldClass}
          style={fieldStyle}
          placeholder="Prénom"
          value={data.first_name || ""}
          onChange={(e) => set({ first_name: e.target.value })}
        />
        <input
          className={fieldClass}
          style={fieldStyle}
          placeholder="Nom"
          value={data.last_name || ""}
          onChange={(e) => set({ last_name: e.target.value })}
        />
      </div>
    </div>
  );
}

export function StepBirth({ data, set }) {
  return (
    <div>
      <Q>
        Quand et où<br />
        êtes-vous <em className="text-[#B8963E] italic">né(e) ?</em>
      </Q>
      <Hint>Date de naissance · Ville</Hint>
      <input
        type="date"
        className={fieldClass}
        style={{ fontFamily: "'Montserrat', sans-serif", fontSize: 14 }}
        value={data.birth_date || ""}
        onChange={(e) => set({ birth_date: e.target.value })}
      />
      <input
        className={`${fieldClass} mt-5`}
        style={fieldStyle}
        placeholder="Paris, Lyon, Bordeaux…"
        value={data.birth_city || ""}
        onChange={(e) => set({ birth_city: e.target.value })}
      />
    </div>
  );
}

export function StepPortrait({ data, set, onUpload, uploading }) {
  return (
    <div>
      <Q>
        Votre <em className="text-[#B8963E] italic">portrait</em>,<br />
        votre timbre.
      </Q>
      <Hint>Il sera gravé sur votre Timbre AIME®</Hint>
      <div className="flex flex-col items-center gap-3">
        <label
          className="w-36 h-36 rounded-full border-[1.5px] border-dashed border-[#D4B483]/60 flex flex-col items-center justify-center cursor-pointer overflow-hidden bg-[#F0E6C8]/10 hover:border-[#B8963E] hover:bg-[#D4B483]/10 transition-all"
        >
          {data.portrait_url ? (
            <img src={data.portrait_url} alt="Portrait" className="w-full h-full object-cover" />
          ) : uploading ? (
            <div className="text-[#8A7A60] text-xs tracking-wider">Émission…</div>
          ) : (
            <>
              <div className="text-3xl text-[#D4B483] mb-2">◎</div>
              <div className="text-[9px] tracking-[2px] text-[#8A7A60] uppercase text-center">
                Choisir<br />une photo
              </div>
            </>
          )}
          <input
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => e.target.files?.[0] && onUpload(e.target.files[0])}
          />
        </label>
        <p className="text-[9px] tracking-[2px] text-[#8A7A60] uppercase">
          Portrait · Souriant · Lumineux
        </p>
      </div>
    </div>
  );
}

export function StepCraft({ data, set }) {
  return (
    <div>
      <Q>
        Quel est votre<br />
        <em className="text-[#B8963E] italic">univers professionnel ?</em>
      </Q>
      <Hint>Métier · Ce que vous créez dans le monde</Hint>
      <input
        className={fieldClass}
        style={fieldStyle}
        placeholder="Architecte, médecin, artiste, entrepreneur…"
        value={data.craft || ""}
        onChange={(e) => set({ craft: e.target.value })}
      />
      <div className="flex flex-wrap gap-2 mt-6">
        {AIME_SECTORS.map((s) => {
          const on = data.sector === s.id;
          return (
            <button
              key={s.id}
              onClick={() => set({ sector: s.id })}
              className={`px-4 py-1.5 rounded-full border text-[11px] tracking-wider transition-colors ${
                on
                  ? "bg-[#1A1208] border-[#1A1208] text-[#F0E6C8]"
                  : "border-[#D4B483]/40 text-[#4A3C28] hover:border-[#D4B483] hover:text-[#B8963E]"
              }`}
            >
              {s.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}

export function StepMusicDNA({ data, set }) {
  const m = data.music_dna || ["", "", ""];
  const upd = (i, v) => {
    const next = [...m];
    next[i] = v;
    set({ music_dna: next });
  };
  return (
    <div>
      <Q>
        Vos trois <em className="text-[#B8963E] italic">artistes</em><br />
        qui vous définissent.
      </Q>
      <Hint>Ceux qui racontent votre âme</Hint>
      {[0, 1, 2].map((i) => (
        <div
          key={i}
          className="flex items-center gap-3 border-b border-[#D4B483]/30 py-2.5"
        >
          <span
            className="text-xl text-[#D4B483] w-6"
            style={{ fontFamily: "'Cormorant Garamond', serif" }}
          >
            {["I", "II", "III"][i]}
          </span>
          <input
            className="flex-1 bg-transparent outline-none text-[17px] py-1 text-[#1A1208] placeholder:text-[#8A7A60]/40 placeholder:italic"
            style={fieldStyle}
            placeholder={`${["Premier", "Deuxième", "Troisième"][i]} artiste…`}
            value={m[i] || ""}
            onChange={(e) => upd(i, e.target.value)}
          />
        </div>
      ))}
    </div>
  );
}

export function StepIntention({ data, set }) {
  const togglePassion = (p) => {
    const cur = data.passions || [];
    const next = cur.includes(p) ? cur.filter((x) => x !== p) : [...cur, p];
    set({ passions: next });
  };
  return (
    <div>
      <Q>
        Ce qui vous <em className="text-[#B8963E] italic">anime</em><br />
        et ce que vous cherchez.
      </Q>
      <Hint>Passions · Sélectionnez ce qui vous ressemble</Hint>
      <div className="flex flex-wrap gap-2 mb-6">
        {AIME_PASSIONS.map((p) => {
          const on = (data.passions || []).includes(p);
          return (
            <button
              key={p}
              onClick={() => togglePassion(p)}
              className={`px-4 py-1.5 rounded-full border text-[11px] tracking-wider transition-colors ${
                on
                  ? "bg-[#1A1208] border-[#1A1208] text-[#F0E6C8]"
                  : "border-[#D4B483]/40 text-[#4A3C28] hover:border-[#D4B483] hover:text-[#B8963E]"
              }`}
            >
              {p}
            </button>
          );
        })}
      </div>
      <textarea
        rows={3}
        placeholder="Ce que je viens chercher ici…"
        className="w-full bg-transparent border border-[#D4B483]/30 rounded-xl p-4 text-base outline-none focus:border-[#B8963E] resize-none placeholder:italic placeholder:text-[#8A7A60]/40"
        style={{ ...fieldStyle, fontSize: 16, lineHeight: 1.7 }}
        value={data.intention || ""}
        onChange={(e) => set({ intention: e.target.value })}
      />
    </div>
  );
}