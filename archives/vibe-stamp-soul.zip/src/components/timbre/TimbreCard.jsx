import React from "react";
import { motion } from "framer-motion";

/**
 * TimbreCard — Vrai timbre postal AIME®.
 * Dentelures CSS via masks (4 côtés) + cadre doré interne + tampon "ÉMIS".
 * Esthétique : crème (#FEFCF6) sur fond beige (#F5F0E8), or chaud #B89A52.
 */

const formatDate = (iso) => {
  if (!iso) return "—";
  const d = new Date(iso);
  return d.toLocaleDateString("fr-FR", { day: "2-digit", month: "2-digit", year: "numeric" });
};

const SIZES = {
  sm: { w: 180, name: 11, brand: 9, n: 8, reg: 7, job: 7, music: 7, code: 7, date: 6, portrait: 56, portraitFs: 16 },
  md: { w: 240, name: 14, brand: 11, n: 10, reg: 8, job: 8, music: 8, code: 8, date: 7, portrait: 76, portraitFs: 22 },
  lg: { w: 320, name: 18, brand: 13, n: 12, reg: 10, job: 9, music: 9, code: 10, date: 8, portrait: 100, portraitFs: 30 }
};

export default function TimbreCard({
  timbre,
  size = "sm",
  anonymous = false,
  founder = false,
  className = ""
}) {
  if (!timbre) return null;
  const d = SIZES[size] || SIZES.sm;
  const showFace = !anonymous && timbre.consent_public_registry !== false;
  const initials = `${timbre.first_name?.[0] || ""}${timbre.last_name?.[0] || ""}`.toUpperCase();

  // Masque dentelure — 4 côtés
  const mask = `
    radial-gradient(circle at 50% -1px, transparent 5px, #000 5.5px) 0 0 / 13px 100% repeat-x,
    radial-gradient(circle at 50% calc(100% + 1px), transparent 5px, #000 5.5px) 0 100% / 13px 100% repeat-x,
    radial-gradient(circle at -1px 50%, transparent 5px, #000 5.5px) 0 0 / 100% 13px repeat-y,
    radial-gradient(circle at calc(100% + 1px) 50%, transparent 5px, #000 5.5px) 100% 0 / 100% 13px repeat-y
  `;

  return (
    <motion.div
      whileHover={{ y: -4 }}
      transition={{ type: "spring", stiffness: 300, damping: 22 }}
      className={`relative ${className}`}
      style={{ width: d.w, fontFamily: "'DM Sans', sans-serif" }}
    >
      {/* Drop-shadow wrapper (le mask interdit les box-shadow) */}
      <div style={{ filter: "drop-shadow(0 3px 12px rgba(26,18,8,0.15)) drop-shadow(0 1px 3px rgba(26,18,8,0.08))" }}>
        {/* Corps du timbre avec dentelure */}
        <div
          style={{
            background: founder ? "#FEFAF0" : "#FEFCF6",
            padding: "14px 12px 12px",
            WebkitMask: mask,
            mask: mask
          }}
        >
          {/* Cadre doré interne */}
          <div
            className="relative"
            style={{
              border: `1px solid ${founder ? "rgba(184,154,82,0.5)" : "rgba(184,154,82,0.3)"}`,
              padding: "10px 8px 8px"
            }}
          >
            {/* Cadre intérieur très fin */}
            <div
              className="absolute pointer-events-none"
              style={{
                inset: 3,
                border: "0.5px solid rgba(184,154,82,0.15)"
              }}
            />

            {/* Top — AIME® / N° */}
            <div className="flex justify-between items-center mb-2">
              <div
                style={{
                  fontFamily: "'Playfair Display', serif",
                  fontSize: d.brand,
                  fontWeight: 700,
                  letterSpacing: "0.15em",
                  color: founder ? "#9A7830" : "#B89A52"
                }}
              >
                AIME<span style={{ fontSize: "0.55em", verticalAlign: "super" }}>®</span>
              </div>
              <div
                style={{
                  fontSize: d.n,
                  color: founder ? "#9A7830" : "#B89A52",
                  fontWeight: 500
                }}
              >
                #{String(timbre.registry_n || 0).padStart(6, "0")}
              </div>
            </div>

            {/* Eyebrow */}
            <div
              style={{
                fontSize: d.reg,
                letterSpacing: "0.12em",
                color: founder ? "#B89A52" : "#C8B99A",
                textTransform: "uppercase",
                fontWeight: founder ? 500 : 400
              }}
            >
              {founder ? "Fondateur" : "Registre Universel"}
            </div>

            {/* Portrait */}
            <div
              className="mx-auto rounded-full overflow-hidden flex items-center justify-center relative"
              style={{
                width: d.portrait,
                height: d.portrait,
                marginTop: 8,
                marginBottom: 8,
                border: `${founder ? "2px" : "1.5px"}px solid ${founder ? "#B89A52" : "#D4C4A0"}`,
                background: anonymous
                  ? "linear-gradient(135deg, #E8E0D0, #D8D0C0)"
                  : founder
                  ? "linear-gradient(135deg, #F0E4C0, #E0D090)"
                  : "linear-gradient(135deg, #F0E8D5, #E8DCC4)"
              }}
            >
              {showFace && timbre.portrait_url ? (
                <img src={timbre.portrait_url} alt="" className="w-full h-full object-cover" />
              ) : anonymous ? (
                <svg width={d.portrait * 0.4} height={d.portrait * 0.4} viewBox="0 0 24 24" fill="none" stroke="#B89A52" strokeWidth="1.5">
                  <circle cx="12" cy="8" r="4" />
                  <path d="M4 20c0-4 3.6-7 8-7s8 3 8 7" />
                </svg>
              ) : (
                <span
                  style={{
                    fontFamily: "'Playfair Display', serif",
                    fontSize: d.portraitFs,
                    fontWeight: 700,
                    color: "#B89A52"
                  }}
                >
                  {initials || "··"}
                </span>
              )}
              {/* Pattern hachuré anonyme */}
              {anonymous && (
                <div
                  className="absolute inset-0 pointer-events-none"
                  style={{
                    background:
                      "repeating-linear-gradient(45deg, transparent, transparent 3px, rgba(184,154,82,0.08) 3px, rgba(184,154,82,0.08) 4px)"
                  }}
                />
              )}
            </div>

            {/* Nom */}
            <div
              className="text-center"
              style={{
                fontFamily: "'Playfair Display', serif",
                fontSize: d.name,
                fontWeight: 600,
                color: "#1a1208",
                lineHeight: 1.2,
                marginBottom: 2
              }}
            >
              {showFace ? `${timbre.first_name || ""} ${timbre.last_name || ""}`.trim() : "— anonyme"}
            </div>

            {/* Métier */}
            {timbre.craft && (
              <div
                className="text-center"
                style={{
                  fontSize: d.job,
                  letterSpacing: "0.12em",
                  color: founder ? "#B89A52" : "#9A8B70",
                  textTransform: "uppercase",
                  marginBottom: 8
                }}
              >
                {timbre.craft}
              </div>
            )}

            {/* ADN sonore */}
            {timbre.music_dna?.length > 0 && (
              <div
                style={{
                  marginTop: 6,
                  borderTop: "0.5px solid rgba(184,154,82,0.2)",
                  paddingTop: 6
                }}
              >
                {timbre.music_dna.slice(0, 3).map((a, i) => (
                  <div
                    key={i}
                    style={{
                      fontSize: d.music,
                      color: "#9A8B70",
                      display: "flex",
                      alignItems: "center",
                      gap: 4,
                      marginBottom: 2
                    }}
                  >
                    <span style={{ color: "#B89A52", flexShrink: 0 }}>♪</span>
                    <span className="truncate">{a}</span>
                  </div>
                ))}
              </div>
            )}

            {/* Bottom — code + date */}
            <div className="flex justify-between items-end" style={{ marginTop: 8 }}>
              <div
                style={{
                  fontFamily: "'DM Sans', monospace",
                  fontSize: d.code,
                  color: founder ? "#9A7830" : "#B89A52",
                  letterSpacing: "0.08em",
                  fontWeight: founder ? 600 : 500
                }}
              >
                {showFace ? timbre.code : "··· privé ···"}
              </div>
              <div style={{ fontSize: d.date, color: "#C8B99A", letterSpacing: "0.04em" }}>
                {formatDate(timbre.issued_at)}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Tampon oblitéré "ÉMIS" */}
      {timbre.hash && (
        <div
          className="absolute flex flex-col items-center justify-center"
          style={{
            top: 10,
            right: 10,
            width: 36,
            height: 36,
            border: `2px solid ${founder ? "rgba(184,154,82,0.6)" : "rgba(184,154,82,0.35)"}`,
            borderRadius: "50%",
            transform: "rotate(-15deg)",
            opacity: founder ? 0.8 : 0.55
          }}
        >
          <div
            style={{
              fontSize: 5,
              letterSpacing: "0.1em",
              color: "#B89A52",
              textTransform: "uppercase",
              fontWeight: 600,
              lineHeight: 1
            }}
          >
            ÉMIS
          </div>
        </div>
      )}
    </motion.div>
  );
}