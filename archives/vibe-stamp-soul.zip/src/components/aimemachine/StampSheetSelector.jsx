import React from "react";

/**
 * StampSheetSelector — Photomaton : choix de la planche (1, 4, 8 ou 12 timbres).
 * Style minimal Framer, pills sombres, sélection blanche.
 */

const SHEETS = [
  { id: 1, label: "1", price: "2€" },
  { id: 4, label: "4", price: "7€" },
  { id: 8, label: "8", price: "13€" },
  { id: 12, label: "12", price: "18€" }
];

export default function StampSheetSelector({ value, onChange }) {
  return (
    <div className="flex flex-col items-center gap-3">
      <div className="text-white/40 text-[10px] tracking-[0.3em] uppercase font-sans">
        Choisis ta planche
      </div>
      <div className="flex gap-2 flex-wrap justify-center">
        {SHEETS.map((s) => {
          const active = value === s.id;
          return (
            <button
              key={s.id}
              type="button"
              onClick={() => onChange(s.id)}
              className="px-5 py-2.5 rounded-full border transition-all flex items-baseline gap-2 font-sans"
              style={{
                background: active ? "#fff" : "transparent",
                color: active ? "#000" : "rgba(255,255,255,0.7)",
                borderColor: active ? "#fff" : "rgba(255,255,255,0.18)"
              }}
            >
              <span className="text-[15px] font-semibold">{s.label}</span>
              <span
                className="text-[10px] tracking-[0.15em] uppercase"
                style={{ opacity: active ? 0.6 : 0.5 }}
              >
                {s.id === 1 ? "timbre" : "timbres"} · {s.price}
              </span>
            </button>
          );
        })}
      </div>
      <div className="text-white/30 text-[9px] tracking-[0.25em] uppercase font-sans mt-1">
        20% reversés · Précarité · Amour · Paix
      </div>
    </div>
  );
}