import React, { useEffect, useState, useRef } from "react";
import { base44 } from "@/api/base44Client";
import PostcardLikeButton from "./PostcardLikeButton";

/**
 * PostcardParallaxColumns — Galerie publique des cartes scellées.
 * Chaque carte = un double partagé. Les internautes peuvent l'aimer (1♥ = 1€).
 */

const COLUMN_COUNT = 5;
const PARALLAX_SPEEDS = [0.15, 0.35, 0.22, 0.45, 0.28];

const PLACEHOLDER = { isPlaceholder: true };

export default function PostcardParallaxColumns() {
  const [postcards, setPostcards] = useState([]);
  const [scrollY, setScrollY] = useState(0);
  const containerRef = useRef(null);

  useEffect(() => {
    base44.entities.Postcard.filter({ is_public: true }, "-created_date", 60).then((list) => {
      setPostcards(list || []);
    }).catch(() => {
      // fallback : toutes les postcards si filter échoue
      base44.entities.Postcard.list("-created_date", 60).then((list) => {
        setPostcards(list || []);
      });
    });
  }, []);

  useEffect(() => {
    let raf;
    const onScroll = () => {
      if (raf) cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        if (!containerRef.current) return;
        const rect = containerRef.current.getBoundingClientRect();
        setScrollY(-rect.top);
      });
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => {
      window.removeEventListener("scroll", onScroll);
      if (raf) cancelAnimationFrame(raf);
    };
  }, []);

  const columns = Array.from({ length: COLUMN_COUNT }, () => []);
  postcards.forEach((p, i) => columns[i % COLUMN_COUNT].push(p));
  columns.forEach((col) => {
    while (col.length < 6) col.push(PLACEHOLDER);
  });
  columns.forEach((col, i) => {
    columns[i] = [...col, ...col];
  });

  return (
    <div ref={containerRef} className="relative w-full overflow-hidden" style={{ minHeight: "120vh" }}>
      <div className="text-center px-5 pt-12 pb-6">
        <div className="text-white/40 text-[10px] tracking-[0.3em] uppercase font-sans mb-2">
          La galerie
        </div>
        <h2 className="text-white font-display uppercase text-[24px] md:text-[32px] tracking-tight">
          1 ♥ = 1 €
        </h2>
        <p className="text-white/45 text-[12px] mt-2 font-sans max-w-md mx-auto">
          Chaque double rejoint la galerie. Les internautes peuvent l'aimer — chaque cœur fait monter sa valeur.
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-5 gap-3 md:gap-5 px-4 md:px-8 py-8">
        {columns.map((col, colIdx) => {
          const offset = scrollY * PARALLAX_SPEEDS[colIdx % COLUMN_COUNT];
          const initialOffset = colIdx % 2 === 0 ? 0 : -80;
          return (
            <div
              key={colIdx}
              className={colIdx >= 2 ? "hidden md:flex flex-col gap-4" : "flex flex-col gap-4"}
              style={{
                transform: `translate3d(0, ${initialOffset - offset}px, 0)`,
                willChange: "transform"
              }}
            >
              {col.map((p, i) => (
                <PostcardThumb key={`${colIdx}-${i}`} postcard={p} />
              ))}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function PostcardThumb({ postcard }) {
  if (postcard?.isPlaceholder) {
    return (
      <div
        className="rounded-lg w-full"
        style={{
          aspectRatio: "3 / 4",
          background:
            "linear-gradient(135deg, rgba(255,255,255,0.03) 0%, rgba(255,255,255,0.06) 50%, rgba(255,255,255,0.03) 100%)",
          border: "1px solid rgba(255,255,255,0.05)"
        }}
      />
    );
  }

  const pos = postcard?.stamp_position || { x: 80, y: 22, rotation: -8 };
  const hasCardImg =
    postcard?.card_image_url && postcard.card_image_url.startsWith("http");
  const hasStampImg =
    postcard?.stamp_image_url && postcard.stamp_image_url.startsWith("http");

  return (
    <div
      className="rounded-lg overflow-hidden relative group bg-[#FBF6E9]"
      style={{
        aspectRatio: "3 / 4",
        boxShadow: "0 4px 16px rgba(0,0,0,0.4)"
      }}
    >
      {/* Recto (haut) */}
      {hasCardImg ? (
        <img
          src={postcard.card_image_url}
          alt={postcard.code}
          className="absolute inset-x-0 top-0 w-full h-1/2 object-cover"
          loading="lazy"
        />
      ) : (
        <div className="absolute inset-x-0 top-0 w-full h-1/2 bg-amber-100/30" />
      )}

      {/* Message manuscrit (bas) */}
      <div className="absolute bottom-0 inset-x-0 h-1/2 p-2 overflow-hidden">
        <p
          className="text-[#2a1a08] leading-tight line-clamp-4"
          style={{ fontFamily: "'Caveat', cursive", fontSize: 11 }}
        >
          {postcard?.message_handwritten}
        </p>
      </div>

      {/* Mini timbre */}
      {hasStampImg && (
        <img
          src={postcard.stamp_image_url}
          alt=""
          className="absolute"
          style={{
            left: `${pos.x}%`,
            top: `${pos.y}%`,
            transform: `translate(-50%, -50%) rotate(${pos.rotation}deg)`,
            width: "30%",
            height: "auto"
          }}
        />
      )}

      {/* Footer overlay : code + like */}
      <div
        className="absolute bottom-0 inset-x-0 px-2 py-1.5 flex items-center justify-between"
        style={{ background: "linear-gradient(180deg, transparent 0%, rgba(0,0,0,0.85) 100%)" }}
      >
        <div className="text-white/80 font-mono text-[8px] tracking-wider truncate">
          {postcard?.code}
        </div>
        <PostcardLikeButton postcard={postcard} compact />
      </div>
    </div>
  );
}