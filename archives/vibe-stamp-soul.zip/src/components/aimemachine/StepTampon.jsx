import React from "react";
import { Loader2, Stamp } from "lucide-react";

/**
 * StepTampon — Étape 4 : décrire le tampon (lieu, date, intention).
 * Au submit, la carte est créée et rejoint les colonnes en bas.
 */
export default function StepTampon({
  tamponCity,
  setTamponCity,
  tamponText,
  setTamponText,
  loading,
  onSeal
}) {
  return (
    <div className="w-full max-w-xl flex flex-col items-center gap-5">
      <div className="text-center">
        <div className="text-white/40 text-[10px] tracking-[0.3em] uppercase font-sans mb-2">
          Étape 4 · Le tampon
        </div>
        <h2 className="text-white font-display uppercase text-[20px] tracking-tight">
          Tamponne ta carte
        </h2>
      </div>

      <div className="w-full">
        <label className="block text-[10px] tracking-[0.25em] uppercase text-white/50 font-sans mb-2">
          Lieu d'envoi
        </label>
        <input
          type="text"
          value={tamponCity}
          onChange={(e) => setTamponCity(e.target.value)}
          disabled={loading}
          placeholder="Lisbonne, Paris, Marrakech…"
          className="w-full bg-white/5 border border-white/15 rounded-full px-5 py-3 text-white text-[14px] font-sans placeholder-white/30 focus:outline-none focus:border-white/50 focus:bg-white/10 transition-colors"
        />
      </div>

      <div className="w-full">
        <label className="block text-[10px] tracking-[0.25em] uppercase text-white/50 font-sans mb-2">
          Inscription du tampon (intention, dédicace…)
        </label>
        <textarea
          value={tamponText}
          onChange={(e) => setTamponText(e.target.value)}
          disabled={loading}
          placeholder="Pour toi, mon amour · Souviens-toi · 3 mai 2026"
          rows={2}
          maxLength={120}
          className="w-full bg-white/5 border border-white/15 rounded-2xl px-5 py-3 text-white text-[14px] font-sans placeholder-white/30 focus:outline-none focus:border-white/50 focus:bg-white/10 transition-colors resize-none"
        />
      </div>

      <button
        type="button"
        onClick={onSeal}
        disabled={tamponCity.trim().length < 2 || tamponText.trim().length < 2 || loading}
        className="rounded-full px-7 py-3.5 flex items-center gap-2 text-[12px] tracking-[0.25em] uppercase font-sans transition-all disabled:opacity-40 disabled:cursor-not-allowed bg-white text-black hover:bg-white/90"
      >
        {loading ? (
          <>
            <Loader2 className="w-4 h-4 animate-spin" /> Scellement…
          </>
        ) : (
          <>
            <Stamp className="w-4 h-4" /> Sceller la carte
          </>
        )}
      </button>
    </div>
  );
}