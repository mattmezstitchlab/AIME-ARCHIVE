import React, { useState } from "react";
import { motion } from "framer-motion";
import { Loader2, Sparkles, Upload, X } from "lucide-react";
import { base44 } from "@/api/base44Client";
import StampSheetSelector from "./StampSheetSelector";

/**
 * StampGenerationForm — Le formulaire central : un prompt libre + upload photo
 * + choix de la planche. Simple, efficace, photomaton.
 */

export default function StampGenerationForm({
  prompt,
  setPrompt,
  photoUrl,
  setPhotoUrl,
  sheetSize,
  setSheetSize,
  onSubmit,
  loading
}) {
  const [uploading, setUploading] = useState(false);

  const handleUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const res = await base44.integrations.Core.UploadFile({ file });
      setPhotoUrl(res?.file_url || "");
    } catch (err) {
      console.error(err);
    } finally {
      setUploading(false);
    }
  };

  return (
    <motion.form
      initial={{ opacity: 0, y: 18 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7, delay: 0.5 }}
      onSubmit={(e) => {
        e.preventDefault();
        if (prompt.trim().length >= 4 && !loading) onSubmit();
      }}
      className="w-full max-w-xl flex flex-col gap-5"
    >
      {/* Prompt */}
      <div>
        <textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          disabled={loading}
          placeholder="Décris ton timbre — un mariage, un serment, un visage, une scène…"
          rows={3}
          maxLength={300}
          className="w-full bg-white/5 border border-white/15 rounded-2xl px-5 py-4 text-white text-[15px] font-sans placeholder-white/30 focus:outline-none focus:border-white/50 focus:bg-white/10 transition-colors resize-none"
        />
        <div className="mt-1 px-2 flex justify-between text-[10px] text-white/30 font-sans">
          <span>Sois précis · l'IA grave ce que tu décris</span>
          <span>{prompt.length}/300</span>
        </div>
      </div>

      {/* Upload photo */}
      <div className="flex items-center justify-center">
        {photoUrl ? (
          <div className="relative">
            <img
              src={photoUrl}
              alt="référence"
              className="w-24 h-24 object-cover rounded-xl border border-white/20"
            />
            <button
              type="button"
              onClick={() => setPhotoUrl("")}
              className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-white text-black flex items-center justify-center"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        ) : (
          <label
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full border border-white/15 text-white/60 text-[11px] tracking-[0.2em] uppercase font-sans cursor-pointer hover:bg-white/5 transition-colors"
          >
            {uploading ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin" /> Téléversement…
              </>
            ) : (
              <>
                <Upload className="w-3.5 h-3.5" /> Ajouter une photo (optionnel)
              </>
            )}
            <input
              type="file"
              accept="image/*"
              onChange={handleUpload}
              disabled={uploading || loading}
              className="hidden"
            />
          </label>
        )}
      </div>

      {/* Sélecteur de planche */}
      <StampSheetSelector value={sheetSize} onChange={setSheetSize} />

      {/* Bouton frappe */}
      <button
        type="submit"
        disabled={prompt.trim().length < 4 || loading}
        className="mt-2 rounded-full px-7 py-4 flex items-center justify-center gap-2 text-[12px] tracking-[0.25em] uppercase font-sans transition-all disabled:opacity-40 disabled:cursor-not-allowed bg-white text-black hover:bg-white/90 self-center"
      >
        {loading ? (
          <>
            <Loader2 className="w-4 h-4 animate-spin" /> Frappe en cours…
          </>
        ) : (
          <>
            <Sparkles className="w-4 h-4" /> Frapper{" "}
            {sheetSize === 1 ? "mon timbre" : `ma planche de ${sheetSize}`}
          </>
        )}
      </button>
    </motion.form>
  );
}