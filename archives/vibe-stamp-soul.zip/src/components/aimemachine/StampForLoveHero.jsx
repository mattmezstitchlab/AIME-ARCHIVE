import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import StampForLoveLogo from "./StampForLoveLogo";
import StampGenerationForm from "./StampGenerationForm";

/**
 * StampForLoveHero — Hero noir minimaliste, style Framer.
 * Titre "STAMP / for LOVE" sur 2 lignes (le O = timbre rond + cœur rouge).
 * Sous-titre + formulaire photomaton (prompt + photo + planche).
 * Le timbre/planche sort par-dessus le titre quand généré.
 */

export default function StampForLoveHero({
  prompt,
  setPrompt,
  photoUrl,
  setPhotoUrl,
  sheetSize,
  setSheetSize,
  onSubmit,
  loading,
  stampSlot
}) {
  return (
    <section className="relative w-full px-5 pt-20 md:pt-28 pb-20 md:pb-28 flex flex-col items-center text-center">
      {/* Eyebrow */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-white/50 text-[11px] tracking-[0.4em] uppercase mb-6 font-sans"
      >
        AIME® · Le Registre Universel
      </motion.div>

      {/* Titre géant + le timbre qui sort par-dessus */}
      <div className="relative">
        <motion.div
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.1 }}
        >
          <StampForLoveLogo />
        </motion.div>

        {/* Le timbre/planche descend depuis le titre */}
        <div className="absolute inset-x-0 top-1/2 flex justify-center pointer-events-none" style={{ zIndex: 5 }}>
          <AnimatePresence>{stampSlot}</AnimatePresence>
        </div>
      </div>

      {/* Sous-titre */}
      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.6, delay: 0.4 }}
        className="mt-8 text-white/55 max-w-xl mx-auto font-sans"
        style={{ fontSize: "clamp(1rem, 1.6vw, 1.15rem)", lineHeight: 1.55 }}
      >
        Une intention. Un timbre frappé pour la vie.<br />
        Comme La Poste — en mieux : 20% pour la précarité, l'amour, la paix.
      </motion.p>

      {/* Formulaire photomaton */}
      <div className="mt-10 w-full flex justify-center">
        <StampGenerationForm
          prompt={prompt}
          setPrompt={setPrompt}
          photoUrl={photoUrl}
          setPhotoUrl={setPhotoUrl}
          sheetSize={sheetSize}
          setSheetSize={setSheetSize}
          onSubmit={onSubmit}
          loading={loading}
        />
      </div>

      {/* Hint sous le form */}
      <div className="mt-5 text-white/30 text-[10px] tracking-[0.25em] uppercase font-sans">
        SHA-256 · Soleau-2024 · Horodaté à la seconde
      </div>
    </section>
  );
}