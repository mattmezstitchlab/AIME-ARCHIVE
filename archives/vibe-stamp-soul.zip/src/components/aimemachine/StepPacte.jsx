import React from "react";
import { Check } from "lucide-react";

/**
 * StepPacte — Avant le scellement final, l'utilisateur signe une charte
 * (consentement + nom) qui transforme la carte en fiche d'intention scellée.
 */
export default function StepPacte({
  signatureName,
  setSignatureName,
  consentTruth,
  setConsentTruth,
  consentRespect,
  setConsentRespect,
  consentShare,
  setConsentShare,
  onNext
}) {
  const allOk =
    signatureName.trim().length >= 2 &&
    consentTruth &&
    consentRespect &&
    consentShare;

  return (
    <div className="w-full max-w-xl flex flex-col items-center gap-5">
      <div className="text-center">
        <div className="text-white/40 text-[10px] tracking-[0.3em] uppercase font-sans mb-2">
          Le Pacte
        </div>
        <h2 className="text-white font-display uppercase text-[20px] tracking-tight">
          Signe ta charte
        </h2>
        <p className="text-white/45 text-[12px] mt-2 font-sans max-w-md">
          Cette carte n'est pas une publicité. C'est un acte. En la scellant, tu
          t'engages — librement.
        </p>
      </div>

      <div className="w-full flex flex-col gap-3">
        <Consent
          checked={consentTruth}
          onChange={setConsentTruth}
          label="Je certifie sur l'honneur la véracité de mon intention."
        />
        <Consent
          checked={consentRespect}
          onChange={setConsentRespect}
          label="Je m'engage au respect de la personne qui recevra ce code."
        />
        <Consent
          checked={consentShare}
          onChange={setConsentShare}
          label="J'accepte qu'une part du prix soit reversée — précarité, amour, paix."
        />
      </div>

      <div className="w-full">
        <label className="block text-[10px] tracking-[0.25em] uppercase text-white/50 font-sans mb-2">
          Signature (ton prénom et nom)
        </label>
        <input
          type="text"
          value={signatureName}
          onChange={(e) => setSignatureName(e.target.value)}
          placeholder="Marie Dupont"
          className="w-full bg-white/5 border border-white/15 rounded-full px-5 py-3 text-white text-[15px] focus:outline-none focus:border-white/50 focus:bg-white/10 transition-colors"
          style={{ fontFamily: "'Caveat', cursive", fontSize: 22 }}
        />
      </div>

      <button
        type="button"
        onClick={onNext}
        disabled={!allOk}
        className="rounded-full px-7 py-3.5 text-[12px] tracking-[0.25em] uppercase font-sans bg-white text-black hover:bg-white/90 transition-all disabled:opacity-40 disabled:cursor-not-allowed"
      >
        Passer au tampon →
      </button>
    </div>
  );
}

function Consent({ checked, onChange, label }) {
  return (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      className="w-full flex items-start gap-3 text-left rounded-2xl px-4 py-3 border transition-colors"
      style={{
        background: checked ? "rgba(225,29,72,0.08)" : "rgba(255,255,255,0.03)",
        borderColor: checked ? "rgba(225,29,72,0.5)" : "rgba(255,255,255,0.12)"
      }}
    >
      <div
        className="mt-0.5 w-5 h-5 rounded-md flex items-center justify-center flex-shrink-0 transition-all"
        style={{
          background: checked ? "#E11D48" : "transparent",
          border: `1.5px solid ${checked ? "#E11D48" : "rgba(255,255,255,0.3)"}`
        }}
      >
        {checked && <Check className="w-3.5 h-3.5 text-white" strokeWidth={3} />}
      </div>
      <span className="text-white/80 text-[13px] font-sans leading-snug">{label}</span>
    </button>
  );
}