import React from "react";

/**
 * FloralStamp — Le timbre rectangulaire fleuri du mariage AIME®.
 * Style : papier ivoire dentelé, cadre or fin, fleur or au centre,
 * "AIME" en serif, date verticale à gauche, lettre dans un cercle à droite,
 * intention douce en bas. Inspiration Yourcenar/baroque/timbre de collection.
 */
export default function FloralStamp({
  day = "22",
  month = "MAI",
  coupleNames = "L & M",
  intention = "SOYEZ PRÉSENTS DANS VOS MOMENTS",
  initial = "A",
  size = 220,
  imageUrl = null
}) {
  const W = size;
  const H = size * 1.32; // ratio timbre rectangulaire vertical
  const STEP = 11;
  const R = 4;
  const cols = Math.floor(W / STEP);
  const rows = Math.floor(H / STEP);
  const offsetX = (W - cols * STEP) / 2 + STEP / 2;
  const offsetY = (H - rows * STEP) / 2 + STEP / 2;

  // Construction de la dentelure (mêmes règles que WorldStamp)
  let d = `M 0 0`;
  for (let i = 0; i < cols; i++) {
    const cx = offsetX + i * STEP;
    d += ` L ${cx - R} 0`;
    d += ` A ${R} ${R} 0 0 0 ${cx + R} 0`;
  }
  d += ` L ${W} 0`;
  for (let i = 0; i < rows; i++) {
    const cy = offsetY + i * STEP;
    d += ` L ${W} ${cy - R}`;
    d += ` A ${R} ${R} 0 0 0 ${W} ${cy + R}`;
  }
  d += ` L ${W} ${H}`;
  for (let i = cols - 1; i >= 0; i--) {
    const cx = offsetX + i * STEP;
    d += ` L ${cx + R} ${H}`;
    d += ` A ${R} ${R} 0 0 0 ${cx - R} ${H}`;
  }
  d += ` L 0 ${H}`;
  for (let i = rows - 1; i >= 0; i--) {
    const cy = offsetY + i * STEP;
    d += ` L 0 ${cy + R}`;
    d += ` A ${R} ${R} 0 0 0 0 ${cy - R}`;
  }
  d += ` Z`;

  return (
    <div
      className="relative inline-block select-none"
      style={{
        filter:
          "drop-shadow(0 18px 36px rgba(0,0,0,0.25)) drop-shadow(0 4px 12px rgba(180,140,60,0.2))"
      }}
    >
      <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{ display: "block" }}>
        <defs>
          <linearGradient id="ivory" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#FBF6E9" />
            <stop offset="100%" stopColor="#F2E9D2" />
          </linearGradient>
          <linearGradient id="goldThread" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#E6C76A" />
            <stop offset="50%" stopColor="#B8860B" />
            <stop offset="100%" stopColor="#8B6914" />
          </linearGradient>
        </defs>

        {/* Papier ivoire dentelé */}
        <path d={d} fill="url(#ivory)" />

        {/* Cadre or intérieur double */}
        <rect
          x="10"
          y="10"
          width={W - 20}
          height={H - 20}
          fill="none"
          stroke="url(#goldThread)"
          strokeWidth="1.2"
          opacity="0.85"
        />
        <rect
          x="14"
          y="14"
          width={W - 28}
          height={H - 28}
          fill="none"
          stroke="url(#goldThread)"
          strokeWidth="0.5"
          opacity="0.5"
        />

        {/* AIME en serif italique en haut */}
        <text
          x={W / 2}
          y={H * 0.13}
          textAnchor="middle"
          fontFamily="Playfair Display, serif"
          fontSize={W * 0.13}
          fill="#8B6914"
          fontStyle="italic"
          letterSpacing="2"
        >
          AIME
        </text>

        {/* Date verticale à gauche */}
        <g transform={`translate(${W * 0.11}, ${H * 0.62}) rotate(-90)`}>
          <text
            textAnchor="middle"
            fontFamily="Playfair Display, serif"
            fontSize={W * 0.085}
            fill="#8B6914"
            letterSpacing="1.5"
          >
            {day} {month}
          </text>
        </g>

        {/* Lettre initiale dans un cercle à droite */}
        <g transform={`translate(${W * 0.86}, ${H * 0.88})`}>
          <circle r={W * 0.055} fill="none" stroke="#8B6914" strokeWidth="1" />
          <text
            textAnchor="middle"
            y={W * 0.025}
            fontFamily="Playfair Display, serif"
            fontSize={W * 0.075}
            fill="#8B6914"
          >
            {initial}
          </text>
        </g>

        {/* Fleur au centre : image IA générée si fournie, sinon bouquet SVG */}
        {imageUrl ? (
          <image
            href={imageUrl}
            x={W * 0.22}
            y={H * 0.22}
            width={W * 0.56}
            height={H * 0.42}
            preserveAspectRatio="xMidYMid meet"
            style={{ filter: "sepia(0.15) saturate(0.85)" }}
          />
        ) : (
          <g transform={`translate(${W / 2}, ${H * 0.45})`}>
            <FloralBouquet size={W * 0.55} />
          </g>
        )}

        {/* Prénoms du couple sous la fleur */}
        <text
          x={W / 2}
          y={H * 0.78}
          textAnchor="middle"
          fontFamily="Playfair Display, serif"
          fontStyle="italic"
          fontSize={W * 0.058}
          fill="#8B6914"
        >
          {coupleNames}
        </text>

        {/* Intention en bas */}
        <text
          x={W / 2}
          y={H * 0.91}
          textAnchor="middle"
          fontFamily="DM Sans, sans-serif"
          fontSize={W * 0.038}
          fill="#8B6914"
          letterSpacing="1.2"
          opacity="0.85"
        >
          {intention}
        </text>
      </svg>
    </div>
  );
}

/* ─── Bouquet floral stylisé (or, traits fins) ─── */
function FloralBouquet({ size = 100 }) {
  const s = size / 2;
  return (
    <g stroke="#B8860B" fill="none" strokeWidth="1.1" strokeLinecap="round">
      {/* Fleur centrale (5 pétales) */}
      {[0, 72, 144, 216, 288].map((angle, i) => (
        <ellipse
          key={i}
          cx="0"
          cy={-s * 0.22}
          rx={s * 0.13}
          ry={s * 0.22}
          fill="#E6C76A"
          fillOpacity="0.4"
          stroke="#8B6914"
          strokeWidth="0.8"
          transform={`rotate(${angle})`}
        />
      ))}
      {/* Cœur de la fleur */}
      <circle cx="0" cy="0" r={s * 0.08} fill="#B8860B" stroke="none" />
      <circle cx="0" cy="0" r={s * 0.04} fill="#FBF6E9" stroke="none" />

      {/* Tiges + petites fleurs latérales */}
      <path d={`M 0 ${s * 0.15} Q ${-s * 0.4} ${s * 0.4} ${-s * 0.55} ${s * 0.55}`} />
      <path d={`M 0 ${s * 0.15} Q ${s * 0.4} ${s * 0.4} ${s * 0.55} ${s * 0.55}`} />
      <path d={`M 0 ${s * 0.15} Q ${-s * 0.15} ${s * 0.5} 0 ${s * 0.7}`} />

      {/* Petites fleurs au bout des tiges */}
      {[
        [-s * 0.55, s * 0.55],
        [s * 0.55, s * 0.55],
        [0, s * 0.7]
      ].map(([x, y], i) => (
        <g key={i} transform={`translate(${x}, ${y})`}>
          {[0, 90, 180, 270].map((a, j) => (
            <circle
              key={j}
              cx={Math.cos((a * Math.PI) / 180) * s * 0.05}
              cy={Math.sin((a * Math.PI) / 180) * s * 0.05}
              r={s * 0.04}
              fill="#E6C76A"
              fillOpacity="0.5"
              stroke="#8B6914"
              strokeWidth="0.6"
            />
          ))}
          <circle cx="0" cy="0" r={s * 0.025} fill="#B8860B" stroke="none" />
        </g>
      ))}

      {/* Feuilles fines */}
      <path d={`M ${-s * 0.25} ${s * 0.3} Q ${-s * 0.45} ${s * 0.25} ${-s * 0.4} ${s * 0.45}`} />
      <path d={`M ${s * 0.25} ${s * 0.3} Q ${s * 0.45} ${s * 0.25} ${s * 0.4} ${s * 0.45}`} />
    </g>
  );
}