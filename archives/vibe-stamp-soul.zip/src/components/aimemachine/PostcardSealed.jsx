import React, { useState } from "react";
import { motion } from "framer-motion";
import { Copy, RefreshCw, Check } from "lucide-react";
import AIStamp from "./AIStamp";

/**
 * PostcardSealed — Affichage final : carte scellée + code de lecture privé à partager.
 */
export default function PostcardSealed({ postcard, onReset }) {
  const [copied, setCopied] = useState(false);

  if (!postcard) return null;

  const copyCode = () => {
    navigator.clipboard.writeText(postcard.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const pos = postcard.stamp_position || { x: 85, y: 18, rotation: -8 };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7 }}
      className="w-full max-w-xl flex flex-col items-center gap-5"
    >
      <div className="text-center">
        <div className="text-emerald-400/80 text-[10px] tracking-[0.3em] uppercase font-sans mb-2">
          ✓ Carte scellée
        </div>
        <h2 className="text-white font-display uppercase text-[24px] tracking-tight">
          Ta carte voyage
        </h2>
      </div>

      {/* Aperçu carte finale */}
      <div
        className="relative w-full bg-[#FBF6E9] rounded-lg shadow-2xl overflow-hidden"
        style={{ aspectRatio: "3 / 2" }}
      >
        <img
          src={postcard.card_image_url}
          alt="carte"
          className="absolute inset-0 w-full h-1/2 object-cover"
        />
        <div className="absolute bottom-0 inset-x-0 h-1/2 p-4 overflow-hidden">
          <p
            className="text-[#2a1a08] leading-snug"
            style={{ fontFamily: "'Caveat', 'Brush Script MT', cursive", fontSize: 14 }}
          >
            {postcard.message_handwritten}
          </p>
        </div>
        <div
          className="absolute"
          style={{
            left: `${pos.x}%`,
            top: `${pos.y}%`,
            transform: `translate(-50%, -50%) rotate(${pos.rotation}deg)`
          }}
        >
          <AIStamp imageUrl={postcard.stamp_image_url} code={null} size={90} />
        </div>
        {/* Tampon */}
        <div
          className="absolute"
          style={{
            left: `${Math.max(10, pos.x - 18)}%`,
            top: `${Math.min(40, pos.y + 8)}%`,
            transform: `rotate(${pos.rotation - 12}deg)`,
            opacity: 0.7
          }}
        >
          <div
            className="rounded-full border-[2.5px] border-[#1a1a4a] px-3 py-2 text-center"
            style={{ borderStyle: "double" }}
          >
            <div className="text-[#1a1a4a] font-display uppercase text-[8px] leading-tight">
              {postcard.tampon_city}
            </div>
            <div className="text-[#1a1a4a] text-[7px] leading-tight font-mono">
              {new Date(postcard.tampon_date || Date.now()).toLocaleDateString("fr-FR")}
            </div>
          </div>
        </div>
      </div>

      {/* Code de lecture */}
      <div className="w-full bg-white/5 border border-white/15 rounded-2xl p-5 text-center">
        <div className="text-white/50 text-[10px] tracking-[0.3em] uppercase font-sans mb-2">
          Code de lecture privé
        </div>
        <div className="text-white font-mono text-[20px] tracking-[0.2em] mb-3">
          {postcard.code}
        </div>
        <button
          onClick={copyCode}
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full border border-white/20 text-white/80 text-[10px] tracking-[0.25em] uppercase hover:bg-white/10 transition-colors font-sans"
        >
          {copied ? (
            <>
              <Check className="w-3.5 h-3.5" /> Copié
            </>
          ) : (
            <>
              <Copy className="w-3.5 h-3.5" /> Copier le code
            </>
          )}
        </button>
        <div className="mt-3 text-white/40 text-[11px] font-sans">
          Partage ce code à la personne. Elle pourra lire ta carte sur /carte.
        </div>
      </div>

      {/* Double dans la galerie · likes · partage de revente */}
      <div className="w-full bg-white/[0.03] border border-white/10 rounded-2xl p-5">
        <div className="text-white/50 text-[10px] tracking-[0.3em] uppercase font-sans mb-3 text-center">
          Un double rejoint la galerie
        </div>
        <div className="text-white/70 text-[12px] font-sans leading-relaxed text-center mb-4">
          Ton timbre devient visible publiquement. Chaque <span className="text-rose-400">♥</span> reçu = <strong className="text-white">1 €</strong> de valeur.
          Tu pourras le mettre en vente quand tu voudras.
        </div>
        <div className="grid grid-cols-3 gap-2 text-center">
          <div className="rounded-lg bg-white/5 py-2.5">
            <div className="text-white font-display text-[16px]">70%</div>
            <div className="text-white/45 text-[9px] tracking-[0.15em] uppercase mt-0.5">Créateur</div>
          </div>
          <div className="rounded-lg bg-white/5 py-2.5">
            <div className="text-white font-display text-[16px]">20%</div>
            <div className="text-white/45 text-[9px] tracking-[0.15em] uppercase mt-0.5">AIME®</div>
          </div>
          <div className="rounded-lg bg-white/5 py-2.5">
            <div className="text-white font-display text-[16px]">10%</div>
            <div className="text-white/45 text-[9px] tracking-[0.15em] uppercase mt-0.5">Cause</div>
          </div>
        </div>
        <div className="mt-3 text-white/35 text-[10px] font-sans text-center leading-relaxed">
          Bientôt · Achat de likes (1 € = 1 ♥) · Reçu fiscal 66 % déductible
        </div>
      </div>

      <button
        onClick={onReset}
        className="inline-flex items-center gap-1.5 px-5 py-2.5 rounded-full border border-white/15 text-white/60 text-[10px] tracking-[0.25em] uppercase hover:bg-white/5 transition-colors font-sans"
      >
        <RefreshCw className="w-3.5 h-3.5" /> Envoyer une autre carte
      </button>
    </motion.div>
  );
}