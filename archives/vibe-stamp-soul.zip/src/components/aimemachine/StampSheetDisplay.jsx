import React from "react";
import { motion } from "framer-motion";
import AIStamp from "./AIStamp";

/**
 * StampSheetDisplay — Affiche la planche de timbres générée (1, 4, 8 ou 12).
 * Un seul timbre image, dupliqué visuellement comme une vraie planche.
 */

export default function StampSheetDisplay({ imageUrl, code, sheetSize = 1 }) {
  if (!imageUrl) return null;

  // Layout selon la taille
  const layouts = {
    1: { cols: 1, rows: 1 },
    4: { cols: 2, rows: 2 },
    8: { cols: 4, rows: 2 },
    12: { cols: 4, rows: 3 }
  };
  const { cols, rows } = layouts[sheetSize] || layouts[1];
  const total = cols * rows;
  const stampSize = sheetSize === 1 ? 240 : sheetSize === 4 ? 150 : 110;

  return (
    <motion.div
      initial={{ y: -180, opacity: 0, scale: 0.7 }}
      animate={{ y: 40, opacity: 1, scale: 1 }}
      exit={{ y: -40, opacity: 0 }}
      transition={{ duration: 1.6, ease: [0.22, 1, 0.36, 1], delay: 0.3 }}
      className="absolute"
    >
      <div
        className="grid"
        style={{
          gridTemplateColumns: `repeat(${cols}, 1fr)`,
          gap: sheetSize === 1 ? 0 : 4,
          padding: sheetSize === 1 ? 0 : 14,
          background: sheetSize === 1 ? "transparent" : "#fff",
          borderRadius: sheetSize === 1 ? 0 : 8,
          boxShadow:
            sheetSize === 1 ? "none" : "0 20px 60px rgba(0,0,0,0.5), 0 0 0 1px rgba(0,0,0,0.05)"
        }}
      >
        {Array.from({ length: total }).map((_, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, scale: 0.85 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.4, delay: 0.6 + i * 0.05 }}
            className="flex items-center justify-center"
          >
            <AIStamp imageUrl={imageUrl} code={i === 0 ? code : null} size={stampSize} />
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}