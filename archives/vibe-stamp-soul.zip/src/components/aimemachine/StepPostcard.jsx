import React from "react";
import { motion } from "framer-motion";
import { Loader2, Sparkles } from "lucide-react";

/**
 * StepPostcard — Étape 2 : décrire la carte postale + le message.
 * L'IA génère un visuel paysage et reformule le message en encre manuscrite.
 */
export default function StepPostcard({
  cardPrompt,
  setCardPrompt,
  messageRaw,
  setMessageRaw,
  loading,
  onGenerate,
  cardImageUrl,
  messageHandwritten,
  onNext
}) {
  const generated = !!cardImageUrl && !!messageHandwritten;

  return (
    <div className="w-full max-w-xl flex flex-col items-center gap-5">
      <div className="text-center">
        <div className="text-white/40 text-[10px] tracking-[0.3em] uppercase font-sans mb-2">
          Étape 2 · La carte postale
        </div>
        <h2 className="text-white font-display uppercase text-[20px] tracking-tight">
          Décris ta carte et ton message
        </h2>
      </div>

      <div className="w-full">
        <label className="block text-[10px] tracking-[0.25em] uppercase text-white/50 font-sans mb-2">
          Le visuel de la carte (recto)
        </label>
        <textarea
          value={cardPrompt}
          onChange={(e) => setCardPrompt(e.target.value)}
          disabled={loading || generated}
          placeholder="Une vue de Lisbonne au crépuscule depuis l'Alfama…"
          rows={2}
          maxLength={250}
          className="w-full bg-white/5 border border-white/15 rounded-2xl px-5 py-3.5 text-white text-[14px] font-sans placeholder-white/30 focus:outline-none focus:border-white/50 focus:bg-white/10 transition-colors resize-none"
        />
      </div>

      <div className="w-full">
        <label className="block text-[10px] tracking-[0.25em] uppercase text-white/50 font-sans mb-2">
          Ton message (l'IA le reformulera avec une belle formule)
        </label>
        <textarea
          value={messageRaw}
          onChange={(e) => setMessageRaw(e.target.value)}
          disabled={loading || generated}
          placeholder="Je pense à toi, j'aimerais que tu sois là…"
          rows={3}
          maxLength={400}
          className="w-full bg-white/5 border border-white/15 rounded-2xl px-5 py-3.5 text-white text-[14px] font-sans placeholder-white/30 focus:outline-none focus:border-white/50 focus:bg-white/10 transition-colors resize-none"
        />
      </div>

      {/* Aperçu */}
      {generated && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="w-full bg-[#FBF6E9] rounded-lg p-4 shadow-2xl"
        >
          <img
            src={cardImageUrl}
            alt="carte"
            className="w-full h-40 object-cover rounded-md mb-3"
          />
          <p
            className="text-[#2a1a08] text-[14px] leading-relaxed"
            style={{ fontFamily: "'Caveat', 'Brush Script MT', cursive", fontSize: 18 }}
          >
            {messageHandwritten}
          </p>
        </motion.div>
      )}

      {!generated ? (
        <button
          type="button"
          onClick={onGenerate}
          disabled={cardPrompt.trim().length < 4 || messageRaw.trim().length < 4 || loading}
          className="rounded-full px-7 py-3.5 flex items-center gap-2 text-[12px] tracking-[0.25em] uppercase font-sans transition-all disabled:opacity-40 disabled:cursor-not-allowed bg-white text-black hover:bg-white/90"
        >
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" /> Aïma écrit…
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4" /> Générer la carte
            </>
          )}
        </button>
      ) : (
        <button
          type="button"
          onClick={onNext}
          className="rounded-full px-7 py-3.5 text-[12px] tracking-[0.25em] uppercase font-sans bg-white text-black hover:bg-white/90 transition-all"
        >
          Coller le timbre →
        </button>
      )}
    </div>
  );
}