import React from "react";
import { motion } from "framer-motion";
import { Stamp, ListTodo, Share2, FlowerIcon } from "lucide-react";

/**
 * BaroqueMachine — La sphère marbre/or fleurie dédiée au mariage.
 * Style baroque/Yourcenar : marbre ivoire, fils d'or, fleurs tressées,
 * écran rond noir avec question douce, 4 boutons latéraux à gauche
 * (CRÉER · ORGANISER · PARTAGER · RÉCOLTER), fiole de "présence" à droite,
 * fente d'impression en bas où sort le timbre.
 *
 * Props :
 * - status: "idle" | "working" | "ready"
 * - slotChild: ReactNode (timbre qui sort)
 * - children: contenu de l'écran rond
 */

const SIDE_BUTTONS = [
  { icon: Stamp, label: "CRÉER" },
  { icon: ListTodo, label: "ORGANISER" },
  { icon: Share2, label: "PARTAGER" },
  { icon: FlowerIcon, label: "RÉCOLTER" }
];

export default function BaroqueMachine({ status = "idle", slotChild = null, children }) {
  return (
    <div className="relative inline-block">
      {/* Branches florales décoratives en arrière-plan */}
      <FloralBranch className="absolute -top-12 -left-16 w-48 opacity-80" rotate={-20} />
      <FloralBranch className="absolute -top-8 -right-20 w-52 opacity-80" rotate={25} flip />
      <FloralBranch className="absolute -bottom-6 -left-24 w-56 opacity-70" rotate={-160} />
      <FloralBranch className="absolute -bottom-10 -right-16 w-48 opacity-70" rotate={160} flip />

      {/* La sphère */}
      <div
        className="relative"
        style={{
          width: 560,
          maxWidth: "100%"
        }}
      >
        {/* Cercle marbre principal */}
        <div
          className="relative rounded-full mx-auto"
          style={{
            width: "100%",
            aspectRatio: "1 / 1",
            background:
              "radial-gradient(circle at 30% 25%, #FBF6E9 0%, #F2E9D2 35%, #E8DCB8 70%, #D4C28E 100%)",
            boxShadow:
              "inset 0 0 80px rgba(180,140,60,0.18), inset 0 -20px 40px rgba(120,80,30,0.15), 0 30px 80px rgba(0,0,0,0.25)"
          }}
        >
          {/* Veines de marbre (filigranes or) */}
          <svg
            className="absolute inset-0 w-full h-full pointer-events-none"
            viewBox="0 0 100 100"
            preserveAspectRatio="none"
          >
            <defs>
              <linearGradient id="goldVein" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="#E6C76A" stopOpacity="0.5" />
                <stop offset="100%" stopColor="#8B6914" stopOpacity="0.3" />
              </linearGradient>
            </defs>
            {/* Quelques courbes douces */}
            <path d="M 5 20 Q 30 30 60 15 T 95 25" stroke="url(#goldVein)" strokeWidth="0.3" fill="none" />
            <path d="M 10 70 Q 40 60 60 80 T 95 65" stroke="url(#goldVein)" strokeWidth="0.25" fill="none" />
            <path d="M 50 5 Q 55 40 45 70 T 50 95" stroke="url(#goldVein)" strokeWidth="0.2" fill="none" />
          </svg>

          {/* Plaquette AIME en haut */}
          <div
            className="absolute left-1/2 -translate-x-1/2"
            style={{ top: "8%" }}
          >
            <div
              className="px-6 py-1.5 rounded-md"
              style={{
                background:
                  "linear-gradient(180deg, #FBF6E9 0%, #E8DCB8 100%)",
                boxShadow:
                  "inset 0 1px 0 rgba(255,255,255,0.6), 0 2px 6px rgba(120,80,30,0.25)",
                border: "1px solid rgba(139,105,20,0.4)"
              }}
            >
              <span
                className="text-[#8B6914] font-serif italic"
                style={{ fontSize: 16, letterSpacing: 3 }}
              >
                AIME
              </span>
            </div>
          </div>

          {/* Bouton décoratif en haut à gauche (lumière) */}
          <motion.div
            className="absolute rounded-full"
            style={{
              top: "18%",
              left: "20%",
              width: 46,
              height: 46,
              background:
                "radial-gradient(circle, #FFE9A8 0%, #E6C76A 60%, #8B6914 100%)",
              boxShadow:
                "inset 0 1px 4px rgba(255,255,255,0.8), 0 0 16px rgba(255,200,80,0.6)"
            }}
            animate={{
              opacity: status === "working" ? [0.7, 1, 0.7] : [0.85, 1, 0.85]
            }}
            transition={{
              duration: status === "working" ? 0.8 : 2.5,
              repeat: Infinity
            }}
          />

          {/* Bouton décoratif en haut à droite (sceau-fleur) */}
          <div
            className="absolute rounded-full flex items-center justify-center"
            style={{
              top: "16%",
              right: "16%",
              width: 56,
              height: 56,
              background:
                "radial-gradient(circle, #1a1208 0%, #2a1c0a 100%)",
              boxShadow:
                "inset 0 0 0 2px #B8860B, 0 0 12px rgba(0,0,0,0.4)"
            }}
          >
            <FlowerIcon className="w-6 h-6 text-amber-300" strokeWidth={1.2} />
          </div>

          {/* Fiole de "présence" à droite */}
          <Fiole status={status} />

          {/* Boutons latéraux gauche */}
          <div
            className="absolute flex flex-col gap-3"
            style={{ left: "6%", top: "32%" }}
          >
            {SIDE_BUTTONS.map((b, i) => (
              <SideButton key={i} icon={b.icon} label={b.label} />
            ))}
          </div>

          {/* Écran rond noir au centre */}
          <div
            className="absolute rounded-full overflow-hidden flex items-center justify-center"
            style={{
              left: "30%",
              top: "26%",
              width: "44%",
              aspectRatio: "1 / 1",
              background:
                "radial-gradient(circle, #0a0604 0%, #000 100%)",
              boxShadow:
                "inset 0 0 0 3px rgba(184,134,11,0.7), inset 0 0 30px rgba(0,0,0,0.95), 0 0 24px rgba(184,134,11,0.3)"
            }}
          >
            <div className="w-full h-full p-6 md:p-7 flex items-center justify-center">
              {children}
            </div>
          </div>

          {/* Fente d'impression en bas */}
          <div
            className="absolute left-1/2 -translate-x-1/2 rounded-md"
            style={{
              bottom: "8%",
              width: "48%",
              height: 22,
              background:
                "linear-gradient(180deg, #1a1208 0%, #2a1c0a 100%)",
              boxShadow:
                "inset 0 4px 8px rgba(0,0,0,0.9), inset 0 -1px 0 rgba(212,175,55,0.3), 0 2px 6px rgba(120,80,30,0.4)",
              border: "1px solid rgba(139,105,20,0.5)"
            }}
          >
            <motion.div
              className="absolute inset-x-0 -top-1 -bottom-1 pointer-events-none"
              animate={
                status === "ready"
                  ? { opacity: [0.4, 0.95, 0.4] }
                  : status === "working"
                  ? { opacity: [0.2, 0.6, 0.2] }
                  : { opacity: 0.15 }
              }
              transition={{ duration: 1.6, repeat: Infinity }}
              style={{
                background:
                  "radial-gradient(ellipse at center, rgba(255,200,80,0.7) 0%, transparent 70%)",
                filter: "blur(6px)"
              }}
            />
          </div>
        </div>

        {/* Le socle marbre + inscription */}
        <div
          className="relative mx-auto rounded-full"
          style={{
            marginTop: -20,
            width: "78%",
            height: 30,
            background:
              "linear-gradient(180deg, #E8DCB8 0%, #C9B584 100%)",
            boxShadow:
              "inset 0 1px 0 rgba(255,255,255,0.5), 0 6px 14px rgba(0,0,0,0.2)"
          }}
        >
          <div className="absolute inset-0 flex items-center justify-center">
            <span
              className="text-[#8B6914]/80 font-serif italic"
              style={{ fontSize: 9, letterSpacing: 2 }}
            >
              AIME MACHINE · VOS INTENTIONS, NOTRE SYSTÈME, VOTRE HISTOIRE
            </span>
          </div>
        </div>

        {/* Sortie : timbre qui descend de la fente */}
        {slotChild && (
          <div
            className="absolute left-1/2 -translate-x-1/2"
            style={{ top: "calc(100% - 80px)", zIndex: 10 }}
          >
            {slotChild}
          </div>
        )}
      </div>
    </div>
  );
}

/* ─── Bouton latéral (rond ivoire avec icône or) ─── */
function SideButton({ icon: Icon, label }) {
  return (
    <div className="flex items-center gap-2">
      <div
        className="rounded-full flex items-center justify-center"
        style={{
          width: 38,
          height: 38,
          background:
            "radial-gradient(circle at 30% 25%, #FBF6E9 0%, #E8DCB8 100%)",
          boxShadow:
            "inset 0 1px 2px rgba(255,255,255,0.7), 0 2px 5px rgba(120,80,30,0.25)",
          border: "1px solid rgba(139,105,20,0.5)"
        }}
      >
        <Icon className="w-4 h-4 text-[#8B6914]" strokeWidth={1.4} />
      </div>
      <span
        className="text-[#8B6914]/90 font-serif"
        style={{ fontSize: 9, letterSpacing: 1.5 }}
      >
        {label}
      </span>
    </div>
  );
}

/* ─── Fiole de "présence" (verre + lumière dorée pulsante) ─── */
function Fiole({ status }) {
  return (
    <div
      className="absolute"
      style={{ right: "5%", top: "30%", width: 60, height: 130 }}
    >
      {/* Tube en verre */}
      <div
        className="absolute inset-x-2 top-2 bottom-6 rounded-full overflow-hidden"
        style={{
          background:
            "linear-gradient(180deg, rgba(255,255,255,0.5) 0%, rgba(255,235,180,0.3) 50%, rgba(255,200,80,0.4) 100%)",
          border: "1px solid rgba(139,105,20,0.4)",
          boxShadow:
            "inset 0 0 12px rgba(255,200,80,0.4), 0 2px 8px rgba(0,0,0,0.15)"
        }}
      >
        {/* Particules dorées */}
        {[20, 50, 75, 92].map((y, i) => (
          <motion.div
            key={i}
            className="absolute rounded-full"
            style={{
              left: `${20 + (i % 2) * 30}%`,
              top: `${y}%`,
              width: 4,
              height: 4,
              background: "#FFD68A",
              boxShadow: "0 0 6px #FFD68A"
            }}
            animate={{
              y: status === "working" ? [-4, 4, -4] : [-2, 2, -2],
              opacity: [0.5, 1, 0.5]
            }}
            transition={{
              duration: status === "working" ? 1 : 2.5,
              repeat: Infinity,
              delay: i * 0.3
            }}
          />
        ))}
      </div>

      {/* Bouchons or haut/bas */}
      <div
        className="absolute inset-x-0 top-0 h-3 rounded-full"
        style={{
          background:
            "linear-gradient(180deg, #E6C76A 0%, #8B6914 100%)",
          boxShadow: "inset 0 1px 0 rgba(255,255,255,0.5)"
        }}
      />
      <div
        className="absolute inset-x-0 bottom-2 h-3 rounded-full"
        style={{
          background:
            "linear-gradient(180deg, #B8860B 0%, #6B4F0E 100%)",
          boxShadow: "inset 0 -1px 0 rgba(255,255,255,0.3)"
        }}
      />
    </div>
  );
}

/* ─── Branche florale décorative SVG ─── */
function FloralBranch({ className = "", rotate = 0, flip = false }) {
  return (
    <svg
      viewBox="0 0 200 120"
      className={className}
      style={{ transform: `rotate(${rotate}deg) ${flip ? "scaleX(-1)" : ""}` }}
    >
      <g stroke="#B8860B" strokeWidth="1.2" fill="none" strokeLinecap="round">
        {/* Branche principale */}
        <path d="M 10 100 Q 60 60 100 50 T 190 30" />
        {/* Tiges secondaires */}
        <path d="M 50 75 Q 60 60 70 45" />
        <path d="M 90 55 Q 100 40 105 25" />
        <path d="M 130 42 Q 140 25 145 10" />
        <path d="M 160 35 Q 170 50 175 65" />

        {/* Fleurs */}
        {[
          [70, 45, 8],
          [105, 25, 7],
          [145, 10, 8],
          [175, 65, 7],
          [120, 60, 6]
        ].map(([cx, cy, r], i) => (
          <g key={i} transform={`translate(${cx}, ${cy})`}>
            {[0, 72, 144, 216, 288].map((a, j) => (
              <ellipse
                key={j}
                cx="0"
                cy={-r * 0.6}
                rx={r * 0.4}
                ry={r * 0.6}
                fill="#FBF6E9"
                fillOpacity="0.85"
                stroke="#B8860B"
                strokeWidth="0.6"
                transform={`rotate(${a})`}
              />
            ))}
            <circle r={r * 0.25} fill="#E6C76A" stroke="none" />
          </g>
        ))}

        {/* Feuilles */}
        <path d="M 40 90 Q 30 80 35 70" stroke="#8B6914" />
        <path d="M 80 65 Q 75 55 85 50" stroke="#8B6914" />
        <path d="M 155 25 Q 165 20 168 30" stroke="#8B6914" />
      </g>
    </svg>
  );
}