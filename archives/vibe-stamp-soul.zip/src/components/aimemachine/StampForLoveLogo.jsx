import React from "react";

/**
 * StampForLoveLogo — "STAMP / for L♥VE" sur 2 lignes.
 * Le O de LOVE = un grand cœur rouge centré, posé derrière les lettres L et V
 * qui se rapprochent et projettent leur ombre sur lui (effet timbre/sceau).
 */

function StampWithHeart({ size = 200 }) {
  // Timbre rond dentelé blanc + cœur rouge centré (taille du cœur conservée)
  const cx = 50;
  const cy = 50;
  const stampR = 46; // rayon du timbre
  const teeth = 28; // nombre de dents
  const toothR = 2.4; // taille de chaque dent
  const teethArr = Array.from({ length: teeth }, (_, i) => {
    const a = (i / teeth) * Math.PI * 2;
    return { x: cx + Math.cos(a) * stampR, y: cy + Math.sin(a) * stampR };
  });

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      style={{
        display: "block",
        filter:
          "drop-shadow(0 10px 28px rgba(0,0,0,0.55)) drop-shadow(0 4px 10px rgba(225,29,72,0.35))"
      }}
    >
      {/* Disque blanc */}
      <circle cx={cx} cy={cy} r={stampR} fill="#fff" />
      {/* Dentelure : petites encoches noires sur le bord */}
      {teethArr.map((p, i) => (
        <circle key={i} cx={p.x} cy={p.y} r={toothR} fill="#000" />
      ))}
      {/* Anneau intérieur fin */}
      <circle
        cx={cx}
        cy={cy}
        r={stampR - 5}
        fill="none"
        stroke="#000"
        strokeOpacity="0.12"
        strokeWidth="0.6"
      />
      {/* Cœur rouge centré (taille conservée) */}
      <path
        d="M50 76 C 26 60, 16 44, 24 30 C 31 19, 44 21, 50 33 C 56 21, 69 19, 76 30 C 84 44, 74 60, 50 76 Z"
        fill="#E11D48"
        stroke="#fff"
        strokeWidth="1.2"
      />
    </svg>
  );
}

export default function StampForLoveLogo() {
  return (
    <h1
      className="text-white font-display uppercase leading-[0.88] text-center select-none"
      style={{
        fontSize: "clamp(3.5rem, 12vw, 9.5rem)",
        letterSpacing: "-0.045em"
      }}
    >
      <div>STAMP</div>
      <div
        className="flex items-center justify-center relative"
        style={{ marginTop: "0.05em" }}
      >
        <span
          className="font-serif italic lowercase font-normal"
          style={{ letterSpacing: "-0.02em", marginRight: "0.18em" }}
        >
          for
        </span>

        {/* Le bloc L♥VE — le L et le V se rapprochent du cœur central */}
        <span className="relative inline-flex items-center">
          {/* L — décalé vers la droite pour se rapprocher du cœur, ombre projetée vers la droite */}
          <span
            className="relative z-20"
            style={{
              marginRight: "-0.18em",
              filter: "drop-shadow(6px 4px 0 rgba(0,0,0,0.55))"
            }}
          >
            L
          </span>

          {/* Le timbre rond dentelé + cœur rouge au centre, derrière les lettres */}
          <span
            className="relative z-10 inline-flex items-center justify-center"
            style={{
              width: "clamp(3.6rem, 12vw, 10rem)",
              height: "clamp(3.6rem, 12vw, 10rem)",
              margin: "0 -0.05em"
            }}
          >
            <StampWithHeart size={220} />
          </span>

          {/* V — décalé vers la gauche, ombre projetée vers la gauche */}
          <span
            className="relative z-20"
            style={{
              marginLeft: "-0.18em",
              filter: "drop-shadow(-6px 4px 0 rgba(0,0,0,0.55))"
            }}
          >
            V
          </span>
          <span className="relative z-20">E</span>
        </span>
      </div>
    </h1>
  );
}