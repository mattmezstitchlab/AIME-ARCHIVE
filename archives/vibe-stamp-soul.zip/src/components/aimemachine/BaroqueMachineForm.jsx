import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowRight, Loader2 } from "lucide-react";

/**
 * BaroqueMachineForm — Conversation douce dans l'écran rond.
 * Une question à la fois, façon Yourcenar : minimal, sans presse.
 * Les questions sont passées en prop (mode mariage).
 */

export default function BaroqueMachineForm({
  step,
  totalSteps,
  question,
  placeholder,
  type = "text",
  value,
  onChange,
  onNext,
  loading
}) {
  const handleSubmit = (e) => {
    e.preventDefault();
    if (value.trim()) onNext();
  };

  return (
    <div className="w-full text-center">
      {/* Petit label en haut */}
      <div
        className="text-amber-300/60 mb-3"
        style={{ fontSize: 8, letterSpacing: 3, fontFamily: "DM Sans, sans-serif" }}
      >
        AIME STAMP MACHINE
      </div>

      {/* Question (animée à chaque step) */}
      <AnimatePresence mode="wait">
        <motion.div
          key={loading ? "loading" : step}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          transition={{ duration: 0.4 }}
        >
          {loading ? (
            <p
              className="text-white/90 mb-5"
              style={{
                fontFamily: "Playfair Display, serif",
                fontStyle: "italic",
                fontSize: 16,
                lineHeight: 1.4
              }}
            >
              Je tisse votre bouquet,<br />en silence…
            </p>
          ) : (
            <p
              className="text-white/90 mb-5"
              style={{
                fontFamily: "Playfair Display, serif",
                fontStyle: "italic",
                fontSize: 17,
                lineHeight: 1.3
              }}
            >
              {question}
            </p>
          )}

          <form onSubmit={handleSubmit} className="flex items-center gap-2 max-w-[260px] mx-auto">
            <input
              type={type}
              value={value}
              onChange={(e) => onChange(e.target.value)}
              disabled={loading}
              placeholder={placeholder}
              autoFocus
              className="flex-1 bg-black/60 border border-amber-500/30 rounded-md px-3 py-2 text-white text-[13px] font-sans placeholder-white/30 focus:outline-none focus:border-amber-300/70 transition-colors text-center"
            />
            <button
              type="submit"
              disabled={!value.trim() || loading}
              className="rounded-md flex items-center justify-center transition-all disabled:opacity-40"
              style={{
                width: 36,
                height: 36,
                background:
                  "linear-gradient(180deg, #FFE9A8 0%, #E6C76A 100%)",
                color: "#1a1208",
                boxShadow: "0 0 8px rgba(255,200,80,0.5)"
              }}
            >
              {loading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <ArrowRight className="w-4 h-4" />
              )}
            </button>
          </form>
        </motion.div>
      </AnimatePresence>

      {/* Pied : ligne baseline */}
      <div
        className="mt-5 text-amber-300/50"
        style={{ fontSize: 7, letterSpacing: 2.5, fontFamily: "DM Sans, sans-serif" }}
      >
        CRÉEZ · STRUCTUREZ · TRANSFORMEZ
        <br />
        VOS MOMENTS EN SOUVENIRS
      </div>

      {/* Indicateur de progression */}
      <div className="mt-4 flex justify-center gap-1.5">
        {Array.from({ length: totalSteps }).map((_, i) => (
          <div
            key={i}
            className="rounded-full transition-all"
            style={{
              width: i === step ? 16 : 5,
              height: 5,
              background: i <= step ? "#E6C76A" : "rgba(230,199,106,0.25)"
            }}
          />
        ))}
      </div>
    </div>
  );
}