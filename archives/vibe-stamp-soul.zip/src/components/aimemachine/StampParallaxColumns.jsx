import React, { useEffect, useState, useRef } from "react";
import { base44 } from "@/api/base44Client";

/**
 * StampParallaxColumns — Colonnes de timbres qui défilent au scroll,
 * chacune à une vitesse différente (parallax). Style Framer.
 *
 * Charge les vrais timbres du registre. Si moins de 12, complète avec
 * des placeholders élégants pour ne jamais avoir de colonne vide.
 */

const COLUMN_COUNT = 5;
const PARALLAX_SPEEDS = [0.15, 0.35, 0.22, 0.45, 0.28]; // vitesse par colonne

// Placeholders silencieux (papier crème, pas d'image bidon)
const PLACEHOLDER = {
  isPlaceholder: true
};

export default function StampParallaxColumns({ filter = "all" }) {
  const [stamps, setStamps] = useState([]);
  const [scrollY, setScrollY] = useState(0);
  const containerRef = useRef(null);

  useEffect(() => {
    base44.entities.Stamp.list("-created_date", 60).then((list) => {
      setStamps(list || []);
    });
  }, []);

  useEffect(() => {
    let raf;
    const onScroll = () => {
      if (raf) cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        if (!containerRef.current) return;
        const rect = containerRef.current.getBoundingClientRect();
        // scrollY relatif à l'entrée du composant dans le viewport
        const y = -rect.top;
        setScrollY(y);
      });
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => {
      window.removeEventListener("scroll", onScroll);
      if (raf) cancelAnimationFrame(raf);
    };
  }, []);

  // Filtrage
  const filtered =
    filter === "all"
      ? stamps
      : stamps.filter((s) => s.category === filter);

  // Distribution en colonnes (round-robin) avec padding placeholders
  const columns = Array.from({ length: COLUMN_COUNT }, () => []);
  filtered.forEach((s, i) => columns[i % COLUMN_COUNT].push(s));
  // Padding minimum 5 timbres / colonne
  columns.forEach((col) => {
    while (col.length < 6) col.push(PLACEHOLDER);
  });
  // Et on duplique chaque colonne 2x pour que ça défile longtemps
  columns.forEach((col, i) => {
    columns[i] = [...col, ...col];
  });

  return (
    <div
      ref={containerRef}
      className="relative w-full overflow-hidden"
      style={{ minHeight: "120vh" }}
    >
      <div className="grid grid-cols-3 md:grid-cols-5 gap-3 md:gap-5 px-4 md:px-8 py-12">
        {columns.map((col, colIdx) => {
          const offset = scrollY * PARALLAX_SPEEDS[colIdx % COLUMN_COUNT];
          // Décalage initial alterné pour casser l'alignement
          const initialOffset = colIdx % 2 === 0 ? 0 : -80;
          return (
            <div
              key={colIdx}
              className={colIdx >= 3 ? "hidden md:flex flex-col gap-4" : "flex flex-col gap-4"}
              style={{
                transform: `translate3d(0, ${initialOffset - offset}px, 0)`,
                willChange: "transform"
              }}
            >
              {col.map((s, i) => (
                <ColumnStamp key={`${colIdx}-${i}`} stamp={s} />
              ))}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function ColumnStamp({ stamp }) {
  if (stamp?.isPlaceholder) {
    return (
      <div
        className="rounded-lg w-full"
        style={{
          aspectRatio: "3 / 4",
          background:
            "linear-gradient(135deg, rgba(255,255,255,0.03) 0%, rgba(255,255,255,0.06) 50%, rgba(255,255,255,0.03) 100%)",
          border: "1px solid rgba(255,255,255,0.05)"
        }}
      />
    );
  }

  const hasRealImage =
    stamp?.image_url &&
    typeof stamp.image_url === "string" &&
    stamp.image_url.startsWith("http");

  return (
    <a
      href={stamp.verify_url || `/verify/${encodeURIComponent(stamp.code)}`}
      className="block rounded-lg overflow-hidden relative group"
      style={{
        aspectRatio: "3 / 4",
        background: "#1a1208",
        boxShadow:
          "0 4px 16px rgba(0,0,0,0.5), inset 0 0 0 1px rgba(212,175,55,0.15)"
      }}
    >
      {hasRealImage ? (
        <img
          src={stamp.image_url}
          alt={stamp.text || "Stamp"}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
          loading="lazy"
        />
      ) : (
        // Carte stylisée minimaliste si pas d'image réelle
        <div
          className="w-full h-full flex flex-col items-center justify-center p-3 text-center"
          style={{
            background:
              "radial-gradient(circle at 30% 20%, #2a1c0a 0%, #0a0604 100%)"
          }}
        >
          <div
            className="text-amber-300/80 mb-2"
            style={{
              fontFamily: "Playfair Display, serif",
              fontStyle: "italic",
              fontSize: "0.75rem",
              lineHeight: 1.2
            }}
          >
            {stamp.text || "AIME®"}
          </div>
          <div
            className="text-amber-400/60 font-mono"
            style={{ fontSize: "0.55rem" }}
          >
            {stamp.code}
          </div>
        </div>
      )}

      {/* Overlay code en bas */}
      <div
        className="absolute bottom-0 inset-x-0 px-2 py-1.5"
        style={{
          background:
            "linear-gradient(180deg, transparent 0%, rgba(0,0,0,0.85) 100%)"
        }}
      >
        <div className="text-amber-300/90 font-mono text-[9px] tracking-wider truncate">
          {stamp.code}
        </div>
      </div>
    </a>
  );
}