import React from "react";

/**
 * AIStamp — Affichage 100% IA : l'image générée par l'IA contient déjà
 * la dentelure, le papier crème, AIME®, la ville et l'oblitération.
 * Aucune superposition PNG. La forme du timbre vient de l'IA elle-même.
 */
export default function AIStamp({ imageUrl, code, size = 260 }) {
  const hasRealImage =
    imageUrl &&
    typeof imageUrl === "string" &&
    (imageUrl.startsWith("http") || imageUrl.startsWith("data:"));

  if (!hasRealImage) return null;

  return (
    <div
      className="relative inline-block select-none"
      style={{
        width: size,
        height: size,
        filter: "drop-shadow(0 2px 6px rgba(0,0,0,0.18))"
      }}
    >
      <img
        src={imageUrl}
        alt={code || "AIME stamp"}
        style={{
          width: "100%",
          height: "100%",
          objectFit: "contain",
          display: "block"
        }}
      />

      {code && (
        <div
          className="absolute left-0 right-0 text-center"
          style={{
            bottom: -22,
            fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace",
            fontSize: 10,
            letterSpacing: 1.5,
            color: "#8B6914"
          }}
        >
          {code}
        </div>
      )}
    </div>
  );
}