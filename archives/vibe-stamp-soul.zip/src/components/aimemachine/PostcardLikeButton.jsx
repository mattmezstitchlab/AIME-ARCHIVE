import React, { useState, useEffect } from "react";
import { Heart } from "lucide-react";
import { base44 } from "@/api/base44Client";

/**
 * PostcardLikeButton — Un like = 1 €.
 * 1 like par visiteur (mémorisé en localStorage), incrémente likes_count + value_eur.
 */
export default function PostcardLikeButton({ postcard, compact = false }) {
  const [count, setCount] = useState(postcard?.likes_count || 0);
  const [liked, setLiked] = useState(false);
  const [loading, setLoading] = useState(false);

  const storageKey = `pc_liked_${postcard?.id}`;

  useEffect(() => {
    if (postcard?.id && localStorage.getItem(storageKey) === "1") {
      setLiked(true);
    }
  }, [postcard?.id, storageKey]);

  const handleLike = async (e) => {
    e?.preventDefault?.();
    e?.stopPropagation?.();
    if (liked || loading || !postcard?.id) return;
    setLoading(true);
    const next = count + 1;
    setCount(next);
    setLiked(true);
    localStorage.setItem(storageKey, "1");
    try {
      await base44.entities.Postcard.update(postcard.id, {
        likes_count: next,
        value_eur: next
      });
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  if (compact) {
    return (
      <button
        onClick={handleLike}
        disabled={liked || loading}
        className="inline-flex items-center gap-1 text-[11px] font-mono"
        style={{ color: liked ? "#E11D48" : "rgba(255,255,255,0.7)" }}
      >
        <Heart className="w-3 h-3" fill={liked ? "#E11D48" : "none"} />
        {count} €
      </button>
    );
  }

  return (
    <button
      onClick={handleLike}
      disabled={liked || loading}
      className="inline-flex items-center gap-2 px-4 py-2 rounded-full border transition-all font-sans"
      style={{
        borderColor: liked ? "rgba(225,29,72,0.5)" : "rgba(255,255,255,0.2)",
        background: liked ? "rgba(225,29,72,0.1)" : "transparent",
        color: liked ? "#E11D48" : "rgba(255,255,255,0.85)"
      }}
    >
      <Heart className="w-4 h-4" fill={liked ? "#E11D48" : "none"} />
      <span className="text-[12px] tracking-[0.15em] uppercase">
        {liked ? "Aimé" : "J'aime"}
      </span>
      <span className="text-[11px] font-mono opacity-70">· {count} €</span>
    </button>
  );
}