import React, { useRef, useState } from "react";
import { motion } from "framer-motion";
import AIStamp from "./AIStamp";

/**
 * StepCollage — Étape 3 : drag & drop du timbre sur la carte postale.
 * L'utilisateur fait glisser le timbre où il veut. Position en %.
 */
export default function StepCollage({
  cardImageUrl,
  messageHandwritten,
  stampImageUrl,
  stampCode,
  stampPosition,
  setStampPosition,
  onNext
}) {
  const cardRef = useRef(null);
  const [dragging, setDragging] = useState(false);

  const handlePointerDown = (e) => {
    setDragging(true);
    e.currentTarget.setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e) => {
    if (!dragging || !cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    setStampPosition({
      x: Math.max(5, Math.min(95, x)),
      y: Math.max(5, Math.min(95, y)),
      rotation: stampPosition.rotation
    });
  };

  const handlePointerUp = (e) => {
    setDragging(false);
    e.currentTarget.releasePointerCapture(e.pointerId);
  };

  return (
    <div className="w-full max-w-xl flex flex-col items-center gap-5">
      <div className="text-center">
        <div className="text-white/40 text-[10px] tracking-[0.3em] uppercase font-sans mb-2">
          Étape 3 · Le collage
        </div>
        <h2 className="text-white font-display uppercase text-[20px] tracking-tight">
          Fais glisser le timbre sur la carte
        </h2>
        <p className="text-white/40 text-[11px] mt-1 font-sans">
          Touche le timbre et déplace-le où tu veux le coller
        </p>
      </div>

      {/* Carte postale */}
      <div
        ref={cardRef}
        className="relative w-full bg-[#FBF6E9] rounded-lg shadow-2xl overflow-hidden touch-none"
        style={{ aspectRatio: "3 / 2" }}
      >
        <img
          src={cardImageUrl}
          alt="carte"
          className="absolute inset-0 w-full h-1/2 object-cover"
          draggable={false}
        />
        <div className="absolute bottom-0 inset-x-0 h-1/2 p-4 overflow-hidden">
          <p
            className="text-[#2a1a08] leading-snug"
            style={{ fontFamily: "'Caveat', 'Brush Script MT', cursive", fontSize: 14 }}
          >
            {messageHandwritten}
          </p>
        </div>

        {/* Le timbre draggable */}
        <motion.div
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          className="absolute cursor-grab active:cursor-grabbing"
          style={{
            left: `${stampPosition.x}%`,
            top: `${stampPosition.y}%`,
            transform: `translate(-50%, -50%) rotate(${stampPosition.rotation}deg)`,
            touchAction: "none",
            zIndex: 10
          }}
          animate={{ scale: dragging ? 1.08 : 1 }}
          transition={{ duration: 0.2 }}
        >
          <AIStamp imageUrl={stampImageUrl} code={null} size={90} />
        </motion.div>
      </div>

      {/* Rotation slider */}
      <div className="w-full max-w-xs flex items-center gap-3">
        <span className="text-white/40 text-[10px] tracking-[0.2em] uppercase font-sans">Inclinaison</span>
        <input
          type="range"
          min={-25}
          max={25}
          value={stampPosition.rotation}
          onChange={(e) =>
            setStampPosition({ ...stampPosition, rotation: parseInt(e.target.value, 10) })
          }
          className="flex-1 accent-white"
        />
        <span className="text-white/50 text-[11px] font-mono w-8 text-right">
          {stampPosition.rotation}°
        </span>
      </div>

      <button
        type="button"
        onClick={onNext}
        className="rounded-full px-7 py-3.5 text-[12px] tracking-[0.25em] uppercase font-sans bg-white text-black hover:bg-white/90 transition-all"
      >
        Tamponner →
      </button>
    </div>
  );
}