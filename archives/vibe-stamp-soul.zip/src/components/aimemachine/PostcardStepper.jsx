import React from "react";

const STEPS = [
  { id: 1, label: "Le timbre" },
  { id: 2, label: "La carte" },
  { id: 3, label: "Le collage" },
  { id: 4, label: "Le pacte" },
  { id: 5, label: "Le tampon" }
];

export default function PostcardStepper({ current }) {
  return (
    <div className="w-full max-w-xl mx-auto flex items-center justify-between gap-2 mb-8">
      {STEPS.map((s, i) => {
        const active = current === s.id;
        const done = current > s.id;
        return (
          <React.Fragment key={s.id}>
            <div className="flex flex-col items-center gap-1.5 flex-1">
              <div
                className="w-7 h-7 rounded-full flex items-center justify-center text-[11px] font-semibold transition-all"
                style={{
                  background: done ? "#E11D48" : active ? "#fff" : "transparent",
                  color: done || active ? (done ? "#fff" : "#000") : "rgba(255,255,255,0.4)",
                  border: `1px solid ${done ? "#E11D48" : active ? "#fff" : "rgba(255,255,255,0.2)"}`
                }}
              >
                {done ? "✓" : s.id}
              </div>
              <div
                className="text-[9px] tracking-[0.2em] uppercase font-sans"
                style={{ color: active ? "#fff" : "rgba(255,255,255,0.4)" }}
              >
                {s.label}
              </div>
            </div>
            {i < STEPS.length - 1 && (
              <div
                className="h-px flex-1 mb-5"
                style={{ background: done ? "#E11D48" : "rgba(255,255,255,0.15)" }}
              />
            )}
          </React.Fragment>
        );
      })}
    </div>
  );
}