import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Loader2, Sparkles, X, Maximize2 } from "lucide-react";
import AIStamp from "./AIStamp";

/**
 * StepStamp — Étape 1 : créer le timbre (prompt seul, IA 100%).
 * Le timbre généré est affiché en grand et cliquable pour zoom plein écran.
 */
export default function StepStamp({
  prompt,
  setPrompt,
  loading,
  onGenerate,
  generatedStamp,
  onNext
}) {
  const [zoomed, setZoomed] = useState(false);

  return (
    <div className="w-full max-w-xl flex flex-col items-center gap-5">
      <div className="text-center">
        <div className="text-white/40 text-[10px] tracking-[0.3em] uppercase font-sans mb-2">
          Étape 1 · Le timbre
        </div>
        <h2 className="text-white font-display uppercase text-[20px] tracking-tight">
          Décris le timbre que tu veux frapper
        </h2>
      </div>

      <textarea
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
        disabled={loading || !!generatedStamp}
        placeholder="Un couple sur une plage au coucher du soleil, deux mains qui se serrent…"
        rows={3}
        maxLength={300}
        className="w-full bg-white/5 border border-white/15 rounded-2xl px-5 py-4 text-white text-[15px] font-sans placeholder-white/30 focus:outline-none focus:border-white/50 focus:bg-white/10 transition-colors resize-none"
      />

      {/* Aperçu du timbre généré — grand format, cliquable */}
      {generatedStamp?.image_url && (
        <motion.button
          type="button"
          onClick={() => setZoomed(true)}
          initial={{ opacity: 0, scale: 0.85 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6 }}
          className="my-4 relative group cursor-zoom-in"
          aria-label="Agrandir le timbre"
        >
          <AIStamp imageUrl={generatedStamp.image_url} code={generatedStamp.code} size={340} />
          <div className="absolute top-2 right-2 w-9 h-9 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
            <Maximize2 className="w-4 h-4 text-white" />
          </div>
        </motion.button>
      )}

      {/* Action */}
      {!generatedStamp ? (
        <button
          type="button"
          onClick={onGenerate}
          disabled={prompt.trim().length < 4 || loading}
          className="rounded-full px-7 py-3.5 flex items-center gap-2 text-[12px] tracking-[0.25em] uppercase font-sans transition-all disabled:opacity-40 disabled:cursor-not-allowed bg-white text-black hover:bg-white/90"
        >
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" /> Frappe…
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4" /> Frapper le timbre
            </>
          )}
        </button>
      ) : (
        <button
          type="button"
          onClick={onNext}
          className="rounded-full px-7 py-3.5 text-[12px] tracking-[0.25em] uppercase font-sans bg-white text-black hover:bg-white/90 transition-all"
        >
          Écrire la carte →
        </button>
      )}

      {/* Lightbox plein écran */}
      <AnimatePresence>
        {zoomed && generatedStamp?.image_url && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="fixed inset-0 z-[120] bg-black/95 flex items-center justify-center p-6"
            onClick={() => setZoomed(false)}
          >
            <button
              type="button"
              onClick={() => setZoomed(false)}
              className="absolute top-6 right-6 w-11 h-11 rounded-full bg-white/10 hover:bg-white/20 backdrop-blur-sm flex items-center justify-center transition-colors"
              aria-label="Fermer"
            >
              <X className="w-5 h-5 text-white" />
            </button>
            <motion.div
              initial={{ scale: 0.85, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ duration: 0.35, ease: "easeOut" }}
              className="max-w-[90vw] max-h-[90vh] flex items-center justify-center"
              onClick={(e) => e.stopPropagation()}
            >
              <img
                src={generatedStamp.image_url}
                alt={generatedStamp.code}
                className="max-w-full max-h-[90vh] object-contain"
                style={{ filter: "drop-shadow(0 4px 24px rgba(0,0,0,0.5))" }}
              />
            </motion.div>
            {generatedStamp.code && (
              <div className="absolute bottom-6 left-0 right-0 text-center text-white/60 font-mono text-[11px] tracking-[0.3em]">
                {generatedStamp.code}
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}