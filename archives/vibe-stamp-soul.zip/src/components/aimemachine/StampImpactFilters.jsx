import React from "react";

/**
 * StampImpactFilters — Filtres "Impact" sur les colonnes de timbres,
 * style Framer (pills sombres avec hover blanc).
 */

const FILTERS = [
  { id: "all", label: "Tous" },
  { id: "mariage", label: "Amour" },
  { id: "contrat_incarne", label: "Engagement" },
  { id: "acte_fondateur", label: "Fondateur" },
  { id: "personnel", label: "Personnel" },
  { id: "evenement", label: "Événement" }
];

export default function StampImpactFilters({ value, onChange }) {
  return (
    <div className="w-full px-5 py-8 flex flex-col items-center text-center gap-4">
      <div className="text-white/40 text-[10px] tracking-[0.4em] uppercase font-sans">
        — Le Registre Vivant —
      </div>
      <div className="flex flex-wrap justify-center gap-2">
        {FILTERS.map((f) => {
          const active = value === f.id;
          return (
            <button
              key={f.id}
              onClick={() => onChange(f.id)}
              className="px-4 py-2 rounded-full text-[11px] tracking-[0.15em] uppercase font-sans transition-all border"
              style={{
                background: active ? "#fff" : "transparent",
                color: active ? "#000" : "rgba(255,255,255,0.7)",
                borderColor: active ? "#fff" : "rgba(255,255,255,0.15)"
              }}
            >
              {f.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}