import React from "react";
import { AIME_BRAND } from "@/lib/aimeBrand";

/**
 * BrandPanel — affiche l'état des marques INPI déposées et le statut brevet.
 * Vue de présentation pour Marie-Lyx Canu Bernad et toute personne externe.
 */
export default function BrandPanel() {
  const trademarks = [
    {
      n: "5164817",
      name: "Aime",
      date: "16 juillet 2025",
      classes: [16, 41],
      classesDesc: [
        "16 — Imprimerie, papeterie, photographies, albums, cartes, livres, calendriers",
        "41 — Éducation, formation, divertissement, services culturels, organisation d'événements"
      ],
      status: "Marque verbale française · INPI",
      statusColor: "#2DBE94"
    },
    {
      n: "5226732",
      name: "AIME",
      date: "11 février 2026",
      classes: [23, 26, 35, 42],
      classesDesc: [
        "23 — Fils textiles",
        "26 — Mercerie, dentelles, broderies, rubans, boutons",
        "35 — Publicité, gestion d'affaires, marketing, services en ligne",
        "42 — Logiciels, SaaS, hébergement, conception, authentification, plateforme cloud"
      ],
      status: "Marque verbale française · INPI",
      statusColor: "#2DBE94"
    }
  ];

  const planned = [
    { class: 9, desc: "Logiciels téléchargeables, applications mobiles, supports d'enregistrement" },
    { class: 38, desc: "Télécommunications, messagerie, réseaux sociaux" },
    { class: 45, desc: "Services personnels, services de rencontres, services juridiques" }
  ];

  return (
    <div className="space-y-8">
      <div>
        <h2
          className="text-3xl font-light text-white mb-2"
          style={{ fontFamily: "'Cormorant Garamond', serif" }}
        >
          Marque & Brevets
        </h2>
        <p className="text-white/50 text-[13px] max-w-2xl">
          État de la propriété intellectuelle d'AIME® — déposée auprès de l'INPI.
        </p>
      </div>

      {/* Identité juridique */}
      <div className="rounded-2xl border border-[#B8963E]/30 bg-gradient-to-br from-[#B8963E]/10 to-transparent p-6">
        <div className="text-[10px] tracking-[3px] uppercase text-[#B8963E] mb-2">
          Identité juridique
        </div>
        <div className="grid sm:grid-cols-2 gap-4 text-[13px]">
          <div>
            <div className="text-white/50 text-[11px]">Déposant</div>
            <div className="text-white font-medium">{AIME_BRAND.founder}</div>
            <div className="text-white/60">{AIME_BRAND.founderCity}</div>
          </div>
          <div>
            <div className="text-white/50 text-[11px]">Domaine principal</div>
            <div className="text-white font-medium">www.{AIME_BRAND.domain}</div>
            <div className="text-white/40 text-[11px]">{AIME_BRAND.parentDomain}</div>
          </div>
        </div>
      </div>

      {/* Marques déposées */}
      <div>
        <h3 className="text-white/80 text-[13px] tracking-wider uppercase mb-4">
          Marques verbales déposées · INPI
        </h3>
        <div className="space-y-4">
          {trademarks.map((tm) => (
            <div key={tm.n} className="rounded-2xl border border-white/10 bg-white/[0.02] p-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <div className="flex items-center gap-3 mb-1">
                    <div
                      className="text-2xl text-[#D4B483] font-light"
                      style={{ fontFamily: "'Cormorant Garamond', serif", letterSpacing: "0.15em" }}
                    >
                      {tm.name}<span className="text-[10px] align-super">®</span>
                    </div>
                    <span
                      className="px-2 py-0.5 rounded-full text-[9px] tracking-wider uppercase"
                      style={{
                        background: `${tm.statusColor}20`,
                        color: tm.statusColor,
                        border: `1px solid ${tm.statusColor}50`
                      }}
                    >
                      Active
                    </span>
                  </div>
                  <div className="text-white/50 text-[12px]">N° {tm.n} · Déposée le {tm.date}</div>
                </div>
                <div className="text-right">
                  <div className="text-[10px] text-white/40 uppercase tracking-wider">Classes</div>
                  <div className="text-[#B8963E] font-mono text-[14px]">
                    {tm.classes.join(" · ")}
                  </div>
                </div>
              </div>
              <div className="text-white/60 text-[11.5px] space-y-1">
                {tm.classesDesc.map((c, i) => (
                  <div key={i}>{c}</div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Brevet en cours */}
      <div className="rounded-2xl border border-[#B8963E]/40 bg-gradient-to-br from-[#B8963E]/10 to-transparent p-6">
        <div className="flex items-start justify-between mb-3">
          <div>
            <div className="text-[10px] tracking-[3px] uppercase text-[#B8963E] mb-1">
              Brevet d'invention · en préparation
            </div>
            <div
              className="text-xl text-white font-light"
              style={{ fontFamily: "'Cormorant Garamond', serif" }}
            >
              {AIME_BRAND.patent}
            </div>
          </div>
          <span
            className="px-3 py-1 rounded-full text-[10px] tracking-wider uppercase border border-[#B8963E]/50 text-[#B8963E]"
          >
            En cours
          </span>
        </div>
        <p className="text-white/55 text-[12px] leading-relaxed">
          Algorithme propriétaire de calcul de résonance entre Timbres AIME® combinant ADN sonore,
          passions, intention déclarée, géolocalisation et horodatage cryptographique. Estimation INPI : 3 000-5 000 €.
        </p>
      </div>

      {/* Extensions à prévoir */}
      <div>
        <h3 className="text-white/80 text-[13px] tracking-wider uppercase mb-4">
          Extensions recommandées
        </h3>
        <div className="space-y-2">
          {planned.map((p) => (
            <div
              key={p.class}
              className="flex items-start gap-4 rounded-xl border border-dashed border-white/15 p-4"
            >
              <div className="text-[#D4B483] font-mono text-lg w-12">{p.class}</div>
              <div className="text-white/60 text-[12px] flex-1">{p.desc}</div>
              <span className="text-[9px] text-white/40 tracking-wider uppercase whitespace-nowrap">
                À déposer
              </span>
            </div>
          ))}
        </div>
        <p className="text-white/40 text-[11px] mt-3 italic">
          Recommandation : extension EUIPO + WIPO Madrid avant lancement public international.
        </p>
      </div>

      {/* Conseil juridique */}
      <div className="rounded-2xl bg-[#0A0A0B] border border-white/10 p-6">
        <div className="text-[10px] tracking-[3px] uppercase text-white/40 mb-2">
          Conseil juridique
        </div>
        <div className="text-white text-[14px]">
          Maître <strong>Marie-Lyx Canu Bernad</strong>
        </div>
        <div className="text-white/50 text-[11px] mt-1">
          Avocate · Propriété intellectuelle · Protection de la marque AIME®
        </div>
      </div>
    </div>
  );
}