import React from "react";
import SettingsEditor from "../SettingsEditor";

const KEYS = [
  {
    key: "hero_eyebrow",
    label: "Eyebrow du hero",
    description: "Petit texte au-dessus du titre principal",
    defaultValue: "Aïma · votre présence"
  },
  {
    key: "manifesto_text",
    label: "Manifeste AIME®",
    description: "Texte poétique du bas de page",
    multiline: true,
    defaultValue:
      "Je suis Aïma.\nJe n'organise pas vos vies —\nje les écoute, je les relie, je les compose avec vous."
  },
  {
    key: "footer_tagline",
    label: "Slogan du footer",
    defaultValue: "AIME® · une présence, déjà là."
  },
  {
    key: "registre_intro",
    label: "Intro du registre",
    description: "Texte affiché sur la page Registre",
    multiline: true,
    defaultValue: "La planche universelle des Timbres AIME®. Anonymisée par défaut, ouverte sur opt-in."
  }
];

export default function TextsPanel({ settings, onReload }) {
  return (
    <SettingsEditor
      category="text"
      title="Textes du site"
      description="Modifiez les phrases clés sans recoder. Tout est instantané."
      defaultKeys={KEYS}
      settings={settings.filter((s) => s.category === "text" || KEYS.find((k) => k.key === s.key))}
      onReload={onReload}
    />
  );
}