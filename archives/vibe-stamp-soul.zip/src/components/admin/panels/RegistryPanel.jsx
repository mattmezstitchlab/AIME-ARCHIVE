import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";

export default function RegistryPanel() {
  const [timbres, setTimbres] = useState([]);
  const [encounters, setEncounters] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const [t, e] = await Promise.all([
        base44.entities.Timbre.list("-issued_at", 200).catch(() => []),
        base44.entities.Encounter.list("-affranchi_at", 200).catch(() => [])
      ]);
      setTimbres(t || []);
      setEncounters(e || []);
      setLoading(false);
    })();
  }, []);

  const publicCount = timbres.filter((t) => t.consent_public_registry).length;
  const matchingCount = timbres.filter((t) => t.consent_matching).length;

  return (
    <div className="space-y-6">
      <div>
        <h2
          className="text-3xl font-light text-white mb-2"
          style={{ fontFamily: "'Cormorant Garamond', serif" }}
        >
          Registre des Timbres
        </h2>
        <p className="text-white/50 text-[13px]">
          Vue d'ensemble des Timbres émis et des affranchissements.
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: "Timbres émis", value: timbres.length, color: "#B8963E" },
          { label: "Publics", value: publicCount, color: "#2DBE94" },
          { label: "Avec matching", value: matchingCount, color: "#A78BFA" },
          { label: "Affranchissements", value: encounters.length, color: "#D4B483" }
        ].map((s) => (
          <div key={s.label} className="rounded-2xl border border-white/10 bg-white/[0.02] p-5">
            <div className="text-[10px] tracking-[2px] uppercase text-white/40 mb-2">{s.label}</div>
            <div className="text-3xl font-light" style={{ color: s.color, fontFamily: "'Cormorant Garamond', serif" }}>
              {s.value}
            </div>
          </div>
        ))}
      </div>

      {loading ? (
        <div className="text-white/50 text-sm py-10 text-center">Chargement…</div>
      ) : timbres.length === 0 ? (
        <div className="text-center py-12 border border-dashed border-white/10 rounded-2xl">
          <p className="text-white/50 italic" style={{ fontFamily: "'Cormorant Garamond', serif" }}>
            Aucun Timbre émis pour l'instant. Le registre est encore vierge.
          </p>
        </div>
      ) : (
        <div className="rounded-2xl border border-white/10 overflow-hidden">
          <table className="w-full text-[12px]">
            <thead className="bg-white/[0.04]">
              <tr className="text-white/50 text-[10px] tracking-[2px] uppercase">
                <th className="text-left p-3">N°</th>
                <th className="text-left p-3">Code</th>
                <th className="text-left p-3">Nom</th>
                <th className="text-left p-3">Métier</th>
                <th className="text-left p-3">Ville</th>
                <th className="text-left p-3">Émis</th>
                <th className="text-left p-3">Public</th>
              </tr>
            </thead>
            <tbody>
              {timbres.slice(0, 50).map((t) => (
                <tr key={t.id} className="border-t border-white/5 text-white/80 hover:bg-white/[0.02]">
                  <td className="p-3 font-mono text-[#B8963E]">#{String(t.registry_n || 0).padStart(6, "0")}</td>
                  <td className="p-3 font-mono">{t.code}</td>
                  <td className="p-3">{t.first_name} {t.last_name}</td>
                  <td className="p-3 text-white/60">{t.craft || "—"}</td>
                  <td className="p-3 text-white/60">{t.issued_city || "—"}</td>
                  <td className="p-3 text-white/40 text-[11px]">
                    {new Date(t.issued_at).toLocaleDateString("fr-FR")}
                  </td>
                  <td className="p-3">
                    {t.consent_public_registry ? (
                      <span className="text-emerald-400">✓</span>
                    ) : (
                      <span className="text-white/30">—</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}