import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";

/**
 * MiniSitesPanel — administration des mini-sites créés par les couples.
 * Liste · statut publié/brouillon · accès rapide à l'éditeur et l'aperçu.
 */
export default function MiniSitesPanel() {
  const [sites, setSites] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    try {
      const rows = await base44.entities.MiniSite.list("-updated_date", 100);
      setSites(rows || []);
    } catch (_) { setSites([]); }
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const togglePublish = async (s) => {
    try {
      await base44.entities.MiniSite.update(s.id, {
        published: !s.published,
        published_at: !s.published ? new Date().toISOString() : null
      });
      load();
    } catch (_) {}
  };

  const remove = async (s) => {
    if (!window.confirm(`Supprimer le mini-site /u/${s.slug} ?`)) return;
    try { await base44.entities.MiniSite.delete(s.id); load(); } catch (_) {}
  };

  const published = sites.filter((s) => s.published).length;
  const drafts = sites.length - published;

  return (
    <div>
      <div className="mb-8">
        <div className="text-[10px] tracking-[0.3em] uppercase text-[#B89A52] mb-2">
          Pilotage · contenu
        </div>
        <h1 className="text-3xl font-light mb-2" style={{ fontFamily: "'Cormorant Garamond', serif" }}>
          Mini-sites
        </h1>
        <p className="text-white/55 text-[13px]">
          Les pages-cadeau privées des couples. Brouillons gratuits, publication payante.
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3 mb-8">
        <Stat label="Total" value={sites.length} />
        <Stat label="Publiés" value={published} accent="#2DBE94" />
        <Stat label="Brouillons" value={drafts} accent="#B89A52" />
      </div>

      {/* Liste */}
      {loading ? (
        <div className="text-white/40 text-sm">Chargement…</div>
      ) : sites.length === 0 ? (
        <div className="rounded-2xl border border-white/10 p-10 text-center text-white/50">
          Aucun mini-site créé pour l'instant.
        </div>
      ) : (
        <div className="space-y-2">
          {sites.map((s) => (
            <div
              key={s.id}
              className="rounded-xl bg-white/[0.03] border border-white/10 p-4 flex items-center justify-between gap-4 hover:bg-white/[0.05] transition-colors"
            >
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2.5 mb-1">
                  <span
                    className={`text-[9px] tracking-[0.2em] uppercase px-2 py-0.5 rounded-full ${
                      s.published
                        ? "bg-emerald-500/15 text-emerald-300 border border-emerald-400/30"
                        : "bg-amber-500/15 text-amber-300 border border-amber-400/30"
                    }`}
                  >
                    {s.published ? "Publié" : "Brouillon"}
                  </span>
                  <span className="text-white/90 text-[14px] font-medium">/u/{s.slug}</span>
                  {s.couple_names && (
                    <span className="text-white/50 text-[12px]">· {s.couple_names}</span>
                  )}
                </div>
                <div className="text-white/40 text-[11px]">
                  {(s.sections?.length || 0)} bloc{(s.sections?.length || 0) > 1 ? "s" : ""}
                  {s.wedding_date && ` · ${s.wedding_date}`}
                  {s.location && ` · ${s.location}`}
                </div>
              </div>

              <div className="flex items-center gap-1.5 flex-shrink-0">
                <Link
                  to={`/u/${s.slug}/edit`}
                  className="px-3 py-1.5 rounded-full bg-white/[0.06] hover:bg-white/[0.12] border border-white/15 text-white/80 text-[10.5px] tracking-[0.15em] uppercase"
                >
                  Éditer
                </Link>
                <Link
                  to={`/u/${s.slug}`}
                  className="px-3 py-1.5 rounded-full bg-white/[0.06] hover:bg-white/[0.12] border border-white/15 text-white/80 text-[10.5px] tracking-[0.15em] uppercase"
                >
                  Voir
                </Link>
                <button
                  onClick={() => togglePublish(s)}
                  className={`px-3 py-1.5 rounded-full text-[10.5px] tracking-[0.15em] uppercase ${
                    s.published
                      ? "bg-amber-500/20 hover:bg-amber-500/30 text-amber-200"
                      : "bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-200"
                  }`}
                  title={s.published ? "Repasser en brouillon" : "Publier (force)"}
                >
                  {s.published ? "Dépublier" : "Publier"}
                </button>
                <button
                  onClick={() => remove(s)}
                  className="px-2 py-1.5 rounded-full bg-red-500/15 hover:bg-red-500/25 text-red-300 text-[12px]"
                  title="Supprimer"
                >
                  ×
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="mt-8 rounded-xl border border-[#B89A52]/20 bg-[#B89A52]/5 p-4 text-[12.5px] text-white/65 leading-relaxed">
        <span className="text-[#B89A52] font-medium">Modèle économique : </span>
        L'édition est libre (terrain de jeu). Le paiement n'arrive qu'au moment de la publication
        (ouverture aux invités, RSVP, playlist live, livre d'or persistant). À configurer côté Stripe.
      </div>
    </div>
  );
}

function Stat({ label, value, accent = "#FFFFFF" }) {
  return (
    <div className="rounded-xl border border-white/10 bg-white/[0.02] p-4">
      <div className="text-[10px] tracking-[0.25em] uppercase text-white/40">{label}</div>
      <div className="text-2xl mt-1 font-light" style={{ color: accent, fontFamily: "'Cormorant Garamond', serif" }}>
        {value}
      </div>
    </div>
  );
}