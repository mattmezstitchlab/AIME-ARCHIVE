import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import { SITE_PAGES_DEFAULTS, clearAccessCache } from "@/lib/siteAccess";

/**
 * PagesPanel — Cockpit de toutes les pages du site.
 * - Mode global (off · countdown · per_page) avec switch maître.
 * - Arborescence par catégorie : core, space, tool.
 * - Pour chaque page : statut public/blocked/maintenance + lien preview.
 */

const STATUS_STYLES = {
  public: { bg: "bg-emerald-500/15", text: "text-emerald-300", label: "Public", dot: "#34D399" },
  blocked: { bg: "bg-red-500/15", text: "text-red-300", label: "Bloquée", dot: "#F87171" },
  maintenance: { bg: "bg-amber-500/15", text: "text-amber-300", label: "Maintenance", dot: "#FBBF24" }
};

const CATEGORY_LABELS = {
  core: "Pages racines",
  space: "Espaces / Fenêtres",
  tool: "Outils & registres"
};

export default function PagesPanel() {
  const [pages, setPages] = useState([]);
  const [mode, setMode] = useState("off");
  const [loading, setLoading] = useState(true);
  const [savingMode, setSavingMode] = useState(false);

  const load = async () => {
    setLoading(true);
    const [existing, settings] = await Promise.all([
      base44.entities.PageAccess.list("order_index", 100).catch(() => []),
      base44.entities.AdminSettings.filter({ key: "site_lockdown_mode" }).catch(() => [])
    ]);

    // Auto-seed pages manquantes
    const existingPaths = new Set((existing || []).map((p) => p.path));
    const missing = SITE_PAGES_DEFAULTS.filter((d) => !existingPaths.has(d.path));
    if (missing.length > 0) {
      await base44.entities.PageAccess.bulkCreate(
        missing.map((m) => ({ ...m, status: "public" }))
      ).catch(() => {});
      const refreshed = await base44.entities.PageAccess.list("order_index", 100).catch(() => []);
      setPages(refreshed || []);
    } else {
      setPages(existing || []);
    }

    setMode(settings?.[0]?.value || "off");
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const saveMode = async (newMode) => {
    setSavingMode(true);
    try {
      const existing = await base44.entities.AdminSettings.filter({ key: "site_lockdown_mode" }).catch(() => []);
      if (existing?.[0]) {
        await base44.entities.AdminSettings.update(existing[0].id, { value: newMode });
      } else {
        await base44.entities.AdminSettings.create({
          key: "site_lockdown_mode",
          category: "feature_flag",
          label: "Mode de verrouillage du site",
          value: newMode
        });
      }
      setMode(newMode);
      clearAccessCache();
    } finally {
      setSavingMode(false);
    }
  };

  const updatePageStatus = async (page, newStatus) => {
    await base44.entities.PageAccess.update(page.id, { status: newStatus });
    setPages((ps) => ps.map((p) => (p.id === page.id ? { ...p, status: newStatus } : p)));
    clearAccessCache();
  };

  const grouped = pages.reduce((acc, p) => {
    const cat = p.category || "space";
    if (!acc[cat]) acc[cat] = [];
    acc[cat].push(p);
    return acc;
  }, {});

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h2 className="text-3xl font-light text-white mb-2" style={{ fontFamily: "'Cormorant Garamond', serif" }}>
          Arborescence du site
        </h2>
        <p className="text-white/50 text-[13px] max-w-2xl">
          Vue globale de toutes les pages. Tu contrôles ce qui est visible publiquement, ce qui est bloqué (redirige vers le countdown Yourcenar), et ce qui est en maintenance.
        </p>
      </div>

      {/* MODE MAÎTRE */}
      <div className="rounded-2xl border border-[#B8963E]/30 bg-gradient-to-br from-[#B8963E]/10 to-transparent p-6">
        <div className="text-[10px] tracking-[3px] uppercase text-[#B8963E] mb-3">
          Mode de verrouillage du site · global
        </div>
        <div className="grid sm:grid-cols-3 gap-2">
          {[
            { id: "off", label: "Site ouvert", desc: "Toutes les pages publiques", color: "#34D399" },
            { id: "countdown", label: "Countdown only", desc: "Tout redirige vers /noyau", color: "#FBBF24" },
            { id: "per_page", label: "Page par page", desc: "Statut individuel ci-dessous", color: "#A78BFA" }
          ].map((m) => (
            <button
              key={m.id}
              onClick={() => saveMode(m.id)}
              disabled={savingMode}
              className={`text-left rounded-xl border p-4 transition-all ${
                mode === m.id
                  ? "border-[#B8963E] bg-[#B8963E]/15"
                  : "border-white/10 bg-white/[0.02] hover:bg-white/[0.05]"
              }`}
            >
              <div className="flex items-center gap-2 mb-1.5">
                <span className="w-2 h-2 rounded-full" style={{ backgroundColor: m.color }} />
                <div className="text-white text-[13px] font-medium">{m.label}</div>
              </div>
              <div className="text-white/50 text-[11px]">{m.desc}</div>
            </button>
          ))}
        </div>
        {mode === "countdown" && (
          <div className="mt-4 p-3 rounded-lg bg-amber-500/10 border border-amber-500/30 text-[12px] text-amber-200/90">
            ⚠️ <strong>Mode countdown actif</strong> — Toutes les pages publiques redirigent vers <code className="font-mono">/noyau</code>. Tu peux partager le lien sans dévoiler le reste du site. Seul <code className="font-mono">/admin</code> reste accessible.
          </div>
        )}
      </div>

      {/* ARBORESCENCE */}
      {loading ? (
        <div className="text-white/40 text-sm">Chargement…</div>
      ) : (
        <div className="space-y-6">
          {["core", "space", "tool"].map((cat) => {
            const list = grouped[cat] || [];
            if (list.length === 0) return null;
            return (
              <div key={cat}>
                <div className="text-[10px] tracking-[3px] uppercase text-[#B8963E] mb-3">
                  {CATEGORY_LABELS[cat]} · {list.length}
                </div>
                <div className="space-y-2">
                  {list.map((p) => {
                    const style = STATUS_STYLES[p.status] || STATUS_STYLES.public;
                    return (
                      <div
                        key={p.id}
                        className="rounded-xl border border-white/10 bg-white/[0.02] p-4 hover:bg-white/[0.04] transition-colors"
                      >
                        <div className="flex items-center justify-between gap-3 flex-wrap">
                          <div className="flex items-center gap-3 min-w-0">
                            <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ backgroundColor: style.dot }} />
                            <div className="min-w-0">
                              <div className="flex items-center gap-2 flex-wrap">
                                <div className="text-white text-[14px] font-medium">{p.label}</div>
                                <code className="text-[11px] text-[#B8963E] font-mono">{p.path}</code>
                              </div>
                              {p.description && (
                                <div className="text-white/45 text-[11.5px] mt-0.5">{p.description}</div>
                              )}
                            </div>
                          </div>
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className={`px-2 py-0.5 rounded-full text-[10px] ${style.bg} ${style.text}`}>
                              {style.label}
                            </span>
                            <select
                              value={p.status || "public"}
                              onChange={(e) => updatePageStatus(p, e.target.value)}
                              className="bg-[#0F0E10] border border-white/10 text-white/80 text-[12px] rounded-lg px-3 py-1.5 outline-none"
                            >
                              <option value="public">Public</option>
                              <option value="blocked">Bloquée</option>
                              <option value="maintenance">Maintenance</option>
                            </select>
                            <Link
                              to={p.path}
                              target="_blank"
                              className="px-3 py-1.5 rounded-lg text-[11px] text-white/60 hover:text-white hover:bg-white/[0.06] border border-white/10"
                            >
                              Aperçu ↗
                            </Link>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      )}

      <div className="rounded-2xl border border-white/10 bg-white/[0.01] p-5 text-[11.5px] text-white/50 leading-relaxed">
        <strong className="text-white/70">Note importante.</strong> Le mode "Page par page" n'est appliqué que si le mode global est sur cette option. En mode "Countdown only", toutes les pages sauf <code className="font-mono">/noyau</code> et <code className="font-mono">/admin</code> sont automatiquement redirigées.
      </div>
    </div>
  );
}