import React from "react";
import SettingsEditor from "../SettingsEditor";

const KEYS = [
  {
    key: "legal_company_name",
    label: "Raison sociale",
    defaultValue: "AIME® · Matthieu Lecointre"
  },
  {
    key: "legal_address",
    label: "Adresse postale",
    multiline: true,
    defaultValue: "Pl. des Combattants\n59236 Frelinghien\nFrance"
  },
  {
    key: "legal_email",
    label: "Email de contact",
    defaultValue: "contact@aime-wedding.com"
  },
  {
    key: "legal_dpo_email",
    label: "DPO (Délégué Protection des Données)",
    defaultValue: "dpo@aime-wedding.com"
  },
  {
    key: "legal_hosting",
    label: "Hébergement",
    defaultValue: "Base44 · Frankfurt (UE) · Stockage conforme RGPD"
  },
  {
    key: "legal_charter_text",
    label: "Charte AIME® complète",
    multiline: true,
    defaultValue:
      "Je m'engage à être authentique sur ce registre.\nJe respecte chaque profil comme une œuvre.\nJe n'utiliserai jamais AIME® pour nuire, tromper ou blesser.\nJe consens au traitement de mes données dans le cadre strict de cette plateforme.\nJe peux à tout moment retirer mon Timbre du registre."
  }
];

export default function LegalPanel({ settings, onReload }) {
  return (
    <SettingsEditor
      category="legal"
      title="Mentions légales"
      description="Informations affichées en pied de site et dans les pages /confidentialite et /mentions."
      defaultKeys={KEYS}
      settings={settings.filter((s) => s.category === "legal" || KEYS.find((k) => k.key === s.key))}
      onReload={onReload}
    />
  );
}