import React from "react";
import SettingsEditor from "../SettingsEditor";

const KEYS = [
  {
    key: "color_bg_main",
    label: "Couleur de fond principale",
    description: "Fond des pages sombres (Home, espaces). Format hex.",
    defaultValue: "#0A0A0B"
  },
  {
    key: "color_accent_gold",
    label: "Doré accent (AIME®)",
    description: "La couleur dorée signature utilisée sur Music Rights, Cabinet, Admin.",
    defaultValue: "#B8963E"
  },
  {
    key: "color_accent_gold_light",
    label: "Doré clair",
    description: "Variante claire pour hover, badges.",
    defaultValue: "#D4B483"
  },
  {
    key: "color_noyau_gold",
    label: "Doré NOYAU",
    description: "Doré spécifique de la page NOYAU (légèrement différent).",
    defaultValue: "#B89A52"
  },
  {
    key: "color_noyau_bg",
    label: "Fond NOYAU",
    description: "Fond noir profond de la page NOYAU.",
    defaultValue: "#0A0806"
  },
  {
    key: "color_yourcenar_bg",
    label: "Fond Yourcenar (countdown)",
    description: "Fond du rideau countdown 8 juin.",
    defaultValue: "#07060A"
  }
];

export default function ColorsPanel({ settings, onReload }) {
  return (
    <SettingsEditor
      category="brand"
      title="Couleurs & palette"
      description="Modifie les couleurs signatures du site. Astuce : utilise un format hex (#RRGGBB). Les changements seront appliqués via les variables CSS globales."
      defaultKeys={KEYS}
      settings={settings.filter((s) => s.category === "brand" || KEYS.find((k) => k.key === s.key))}
      onReload={onReload}
    />
  );
}