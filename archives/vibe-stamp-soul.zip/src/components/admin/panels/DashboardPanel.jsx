import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";

export default function DashboardPanel({ onNavigate }) {
  const [stats, setStats] = useState({ timbres: 0, encounters: 0, conversations: 0 });

  useEffect(() => {
    (async () => {
      const [t, e, c] = await Promise.all([
        base44.entities.Timbre.list("-created_date", 1000).catch(() => []),
        base44.entities.Encounter.list("-created_date", 1000).catch(() => []),
        base44.entities.Conversation.list("-created_date", 1000).catch(() => [])
      ]);
      setStats({ timbres: t?.length || 0, encounters: e?.length || 0, conversations: c?.length || 0 });
    })();
  }, []);

  return (
    <div className="space-y-8">
      <div>
        <div className="text-[10px] tracking-[5px] text-[#B8963E] uppercase mb-2">
          AIME® · Tableau de bord
        </div>
        <h2
          className="text-4xl font-light text-white"
          style={{ fontFamily: "'Cormorant Garamond', serif" }}
        >
          Bienvenue dans le <em className="italic text-[#B8963E]">registre privé</em>.
        </h2>
        <p className="text-white/50 text-[13px] mt-2 max-w-2xl">
          Pilotez tout le site sans recoder : visuels, textes, paramètres d'Aïma, suivi juridique et registre des Timbres.
        </p>
      </div>

      {/* KPIs */}
      <div className="grid md:grid-cols-3 gap-4">
        {[
          { label: "Timbres émis", value: stats.timbres, color: "#B8963E", to: "registry" },
          { label: "Affranchissements", value: stats.encounters, color: "#D4B483", to: "registry" },
          { label: "Conversations Aïma", value: stats.conversations, color: "#A78BFA", to: "aima" }
        ].map((k) => (
          <button
            key={k.label}
            onClick={() => onNavigate(k.to)}
            className="text-left rounded-2xl border border-white/10 bg-white/[0.02] p-6 hover:bg-white/[0.04] transition-colors"
          >
            <div className="text-[10px] tracking-[2px] uppercase text-white/40 mb-3">{k.label}</div>
            <div
              className="text-5xl font-light"
              style={{ color: k.color, fontFamily: "'Cormorant Garamond', serif" }}
            >
              {k.value}
            </div>
          </button>
        ))}
      </div>

      {/* Quick actions */}
      <div>
        <h3 className="text-white/80 text-[13px] tracking-wider uppercase mb-4">
          Actions rapides
        </h3>
        <div className="grid sm:grid-cols-2 gap-3">
          {[
            { id: "media", label: "Mettre à jour les visuels", desc: "Vidéo hero, fonds, portraits" },
            { id: "texts", label: "Modifier les textes", desc: "Manifeste, eyebrow, slogans" },
            { id: "aima", label: "Régler Aïma", desc: "Persona, modèle LLM, message d'accueil" },
            { id: "brand", label: "Marque & Brevets", desc: "Présenter à Marie-Lyx Canu Bernad" }
          ].map((a) => (
            <button
              key={a.id}
              onClick={() => onNavigate(a.id)}
              className="text-left rounded-xl border border-white/10 bg-white/[0.02] p-4 hover:bg-white/[0.04] hover:border-[#B8963E]/40 transition-colors"
            >
              <div className="text-white text-[14px] font-medium">{a.label}</div>
              <div className="text-white/40 text-[11.5px] mt-0.5">{a.desc}</div>
            </button>
          ))}
        </div>
      </div>

      <div className="rounded-2xl border border-white/10 bg-white/[0.01] p-5 text-[11.5px] text-white/50 leading-relaxed">
        <strong className="text-white/70">À propos de cet espace.</strong> Cet espace administrateur est conçu pour présenter
        AIME® à des partenaires (avocats, investisseurs, équipes) et piloter le site sans coder. Les modifications sont
        instantanées et stockées de manière sécurisée. Pour tout suivi juridique, contactez Maître Marie-Lyx Canu Bernad.
      </div>
    </div>
  );
}