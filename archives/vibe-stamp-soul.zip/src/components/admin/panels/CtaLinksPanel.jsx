import React from "react";
import SettingsEditor from "../SettingsEditor";

const KEYS = [
  {
    key: "cta_hero_primary_label",
    label: "Bouton principal Home — texte",
    defaultValue: "Parler à Aïma"
  },
  {
    key: "cta_hero_primary_action",
    label: "Bouton principal Home — action",
    description: "open_aima · /noyau · /mariage · /timbre/nouveau · ou toute URL",
    defaultValue: "open_aima"
  },
  {
    key: "cta_hero_secondary_label",
    label: "Bouton secondaire Home — texte",
    defaultValue: "Découvrir l'écosystème"
  },
  {
    key: "cta_hero_secondary_action",
    label: "Bouton secondaire Home — action",
    defaultValue: "/registre"
  },
  {
    key: "cta_noyau_label",
    label: "Bouton NOYAU (jour J) — texte",
    defaultValue: "Parler à Aïma →"
  },
  {
    key: "cta_footer_contact_email",
    label: "Email contact (footer)",
    defaultValue: "contact@aime-wedding.com"
  }
];

export default function CtaLinksPanel({ settings, onReload }) {
  return (
    <SettingsEditor
      category="text"
      title="Boutons & liens CTA"
      description="Édite les libellés et destinations des boutons d'appel à l'action partout sur le site."
      defaultKeys={KEYS}
      settings={settings.filter((s) => KEYS.find((k) => k.key === s.key))}
      onReload={onReload}
    />
  );
}