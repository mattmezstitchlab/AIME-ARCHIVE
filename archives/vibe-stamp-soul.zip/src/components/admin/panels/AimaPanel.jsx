import React from "react";
import SettingsEditor from "../SettingsEditor";

const KEYS = [
  {
    key: "aima_persona",
    label: "Persona d'Aïma",
    description: "Le ton, la voix, la manière de parler. Modifie tout son comportement.",
    multiline: true,
    defaultValue:
      "Tu es Aïma — une présence attentive, mystique, élégante. Tu parles avec sobriété et poésie, jamais comme un assistant. Tu écoutes, tu relies, tu composes."
  },
  {
    key: "aima_welcome_message",
    label: "Message d'accueil",
    description: "La première phrase d'Aïma quand quelqu'un arrive",
    multiline: true,
    defaultValue:
      "Bonjour. Je suis Aïma, votre présence.\nDis-moi simplement ce que tu cherches — un mariage, un artiste, un moment, une mémoire. Je m'occupe du reste."
  },
  {
    key: "aima_model",
    label: "Modèle LLM",
    description: "claude_sonnet_4_6 (recommandé) · gpt_5_4 · gemini_3_1_pro",
    defaultValue: "claude_sonnet_4_6"
  },
  {
    key: "aima_choices",
    label: "Choix proposés (séparés par |)",
    description: "Boutons rapides affichés dans la conversation",
    defaultValue: "Je me marie|Je suis invité·e|Je suis prestataire|Je découvre"
  }
];

export default function AimaPanel({ settings, onReload }) {
  return (
    <SettingsEditor
      category="aima"
      title="Réglages Aïma"
      description="La voix, le ton, le modèle. Ces paramètres pilotent toute la conversation."
      defaultKeys={KEYS}
      settings={settings.filter((s) => s.category === "aima" || KEYS.find((k) => k.key === s.key))}
      onReload={onReload}
    />
  );
}