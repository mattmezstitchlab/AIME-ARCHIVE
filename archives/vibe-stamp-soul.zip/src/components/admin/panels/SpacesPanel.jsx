import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";

const PHASE_COLORS = {
  live: { bg: "bg-emerald-500/15", text: "text-emerald-300", label: "En ligne" },
  soon: { bg: "bg-amber-500/15", text: "text-amber-300", label: "Bientôt" },
  lab: { bg: "bg-purple-500/15", text: "text-purple-300", label: "Laboratoire" }
};

export default function SpacesPanel() {
  const [spaces, setSpaces] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null);
  const [bgDraft, setBgDraft] = useState({});
  const [savingBg, setSavingBg] = useState(null);

  const load = async () => {
    setLoading(true);
    const all = await base44.entities.Space.list("order_index", 50).catch(() => []);
    setSpaces(all || []);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const toggleVisible = async (s) => {
    await base44.entities.Space.update(s.id, { is_visible: !s.is_visible });
    load();
  };

  const setPhase = async (s, phase) => {
    await base44.entities.Space.update(s.id, { phase });
    load();
  };

  const saveBg = async (s) => {
    const url = bgDraft[s.id];
    if (!url || url === s.bg_url) return;
    setSavingBg(s.id);
    try {
      await base44.entities.Space.update(s.id, { bg_url: url });
      setBgDraft((d) => ({ ...d, [s.id]: undefined }));
      await load();
    } finally {
      setSavingBg(null);
    }
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-light text-white mb-2" style={{ fontFamily: "'Cormorant Garamond', serif" }}>
          Fenêtres · espaces
        </h1>
        <p className="text-white/55 text-[14px]">
          Active, masque, programme l'apparition de chaque espace AIME®. Le contrôle des fenêtres est ici, à tout moment.
        </p>
      </div>

      {loading ? (
        <div className="text-white/40 text-sm">Chargement…</div>
      ) : (
        <div className="space-y-3">
          {spaces.map((s) => {
            const phaseStyle = PHASE_COLORS[s.phase] || PHASE_COLORS.live;
            return (
              <div
                key={s.id}
                className={`rounded-2xl border p-5 transition-all ${
                  s.is_visible
                    ? "border-[#B8963E]/30 bg-[#B8963E]/[0.04]"
                    : "border-white/10 bg-white/[0.02]"
                }`}
              >
                <div className="flex items-start justify-between gap-4 flex-wrap">
                  <div className="flex items-center gap-4 min-w-0">
                    <div
                      className="w-14 h-14 rounded-xl flex items-center justify-center flex-shrink-0 border"
                      style={{
                        backgroundColor: `${s.accent_color}22`,
                        borderColor: `${s.accent_color}55`,
                        color: s.accent_color
                      }}
                    >
                      <span className="font-serif text-2xl">◇</span>
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <div className="text-white text-[15px] font-medium">{s.label}</div>
                        <span className={`text-[10px] px-2 py-0.5 rounded-full ${phaseStyle.bg} ${phaseStyle.text}`}>
                          {phaseStyle.label}
                        </span>
                        {s.badge && (
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-white/10 text-white/60">
                            ✦ {s.badge}
                          </span>
                        )}
                      </div>
                      <div className="text-white/50 text-[12px] mt-1 truncate max-w-md">
                        /{s.slug} · {s.eyebrow}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 flex-wrap">
                    <select
                      value={s.phase || "live"}
                      onChange={(e) => setPhase(s, e.target.value)}
                      className="bg-[#0F0E10] border border-white/10 text-white/80 text-[12px] rounded-lg px-3 py-2 outline-none"
                    >
                      <option value="live">En ligne</option>
                      <option value="soon">Bientôt</option>
                      <option value="lab">Laboratoire</option>
                    </select>

                    <button
                      onClick={() => toggleVisible(s)}
                      className={`px-4 py-2 rounded-lg text-[12px] font-medium transition-colors ${
                        s.is_visible
                          ? "bg-[#B8963E] text-[#1A1208] hover:bg-[#D4B483]"
                          : "bg-white/10 text-white/60 hover:bg-white/20"
                      }`}
                    >
                      {s.is_visible ? "✓ Visible" : "Masquée"}
                    </button>

                    <button
                      onClick={() => setEditing(editing === s.id ? null : s.id)}
                      className="px-4 py-2 rounded-lg text-[12px] text-white/70 hover:text-white hover:bg-white/[0.06] border border-white/10"
                    >
                      {editing === s.id ? "Fermer" : "Détails"}
                    </button>
                  </div>
                </div>

                {editing === s.id && (
                  <div className="mt-5 pt-5 border-t border-white/10 space-y-5 text-[13px]">

                    {/* IMAGE DE FOND — éditable en direct */}
                    <div className="bg-black/20 rounded-xl p-4 border border-white/10">
                      <div className="flex items-center justify-between mb-3">
                        <div className="text-[10px] tracking-widest text-[#B8963E] uppercase">
                          Image de fond (bg_url)
                        </div>
                        <span className="text-[10px] text-white/30">Visible sur la landing</span>
                      </div>
                      <div className="flex gap-3 items-start">
                        {s.bg_url && (
                          <img
                            src={s.bg_url}
                            alt=""
                            className="w-32 h-20 object-cover rounded-lg border border-white/10 flex-shrink-0"
                          />
                        )}
                        <div className="flex-1 space-y-2">
                          <input
                            type="text"
                            value={bgDraft[s.id] ?? s.bg_url ?? ""}
                            onChange={(e) => setBgDraft((d) => ({ ...d, [s.id]: e.target.value }))}
                            placeholder="https://res.cloudinary.com/…"
                            className="w-full bg-black/40 border border-white/10 rounded-lg p-2.5 text-[12px] text-white outline-none focus:border-[#B8963E] font-mono"
                          />
                          <div className="flex justify-end">
                            <button
                              onClick={() => saveBg(s)}
                              disabled={
                                savingBg === s.id ||
                                !bgDraft[s.id] ||
                                bgDraft[s.id] === s.bg_url
                              }
                              className={`px-4 py-1.5 rounded-full text-[10px] tracking-[2px] uppercase transition-colors ${
                                bgDraft[s.id] && bgDraft[s.id] !== s.bg_url
                                  ? "bg-[#B8963E] text-[#1A1208] hover:bg-[#D4B483]"
                                  : "bg-white/5 text-white/30 cursor-not-allowed"
                              }`}
                            >
                              {savingBg === s.id ? "Sauvegarde…" : "Mettre à jour l'image"}
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-5">
                      <div>
                        <div className="text-[10px] tracking-widest text-white/40 uppercase mb-2">Titre</div>
                        <div className="text-white/85">{s.title} <span className="italic text-white/60">{s.italic}</span></div>
                      </div>
                      <div>
                        <div className="text-[10px] tracking-widest text-white/40 uppercase mb-2">Description</div>
                        <div className="text-white/70 leading-relaxed">{s.description}</div>
                      </div>
                      <div>
                        <div className="text-[10px] tracking-widest text-white/40 uppercase mb-2">
                          Dossiers ({s.folders?.length || 0})
                        </div>
                        <div className="flex flex-wrap gap-1.5">
                          {(s.folders || []).map((f) => (
                            <span key={f.name} className="px-2 py-1 rounded bg-white/[0.06] text-white/70 text-[11px]">
                              {f.name} {f.count ? `· ${f.count}` : ""}
                            </span>
                          ))}
                        </div>
                      </div>
                      <div>
                        <div className="text-[10px] tracking-widest text-white/40 uppercase mb-2">
                          Modules ({s.modules?.length || 0})
                        </div>
                        <div className="space-y-1">
                          {(s.modules || []).map((m) => (
                            <div key={m.t} className="text-white/70 text-[12px]">
                              <span className="text-white/90">{m.t}</span> — <span className="text-white/50">{m.d}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      <div className="mt-10 p-5 rounded-2xl bg-white/[0.02] border border-white/10 text-white/55 text-[12.5px] leading-relaxed">
        <div className="text-[10px] tracking-widest text-[#B8963E] uppercase mb-2">Roadmap des fenêtres</div>
        Phase 1 (now) — Mariage (Couples · Invités · Prestataires · Lieux)<br />
        Phase 2 — + Intermittents (extension naturelle des prestataires)<br />
        Phase 3 — + Mairies (entrée institutionnelle)<br />
        Phase 4 — + Inclusive · Agriculteurs · Mémoire · Noyau (manifeste vivant)
      </div>
    </div>
  );
}