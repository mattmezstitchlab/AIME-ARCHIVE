import React from "react";
import SettingsEditor from "../SettingsEditor";

const KEYS = [
  {
    key: "hero_video_url",
    label: "Vidéo du hero (Aïma)",
    description: "URL de la vidéo en arrière-plan de l'écran d'accueil",
    defaultValue: "https://res.cloudinary.com/divou1vcx/video/upload/v1777569381/aimeherowebsite_dtwbr1.mp4"
  },
  {
    key: "hero_audio_url",
    label: "Audio ambient",
    description: "URL du morceau ambient déclenché à la première interaction",
    defaultValue: "https://res.cloudinary.com/divou1vcx/video/upload/v1777569102/Aime_-_Hymne_3_bz5wlf.mp3"
  },
  {
    key: "manifesto_image_url",
    label: "Portrait du manifeste",
    description: "Image en fond de la section manifeste/footer",
    defaultValue: "https://res.cloudinary.com/divou1vcx/image/upload/v1777316714/pexels-josue-velasquez-282193995-16791483_z8qo8m.jpg"
  },
  {
    key: "space_couples_bg",
    label: "Fond espace Couples",
    defaultValue: "https://res.cloudinary.com/divou1vcx/image/upload/v1777698965/pexels-rothemba-vele-1414849-18041569_pps4us.jpg"
  },
  {
    key: "space_guests_bg",
    label: "Fond espace Invités",
    defaultValue: "https://res.cloudinary.com/divou1vcx/image/upload/v1777698965/pexels-soner-gorkem-9756539-6119578_tbwgba.jpg"
  },
  {
    key: "space_pros_bg",
    label: "Fond espace Pros",
    defaultValue: "https://res.cloudinary.com/divou1vcx/image/upload/v1772843090/mainpiano_mjh543.jpg"
  },
  {
    key: "space_venues_bg",
    label: "Fond espace Lieux",
    defaultValue: "https://res.cloudinary.com/divou1vcx/image/upload/v1777700210/pexels-jwfotografia-12103484_cdnpdw.jpg"
  }
];

export default function MediaPanel({ settings, onReload }) {
  return (
    <SettingsEditor
      category="media"
      title="Médias & visuels"
      description="Mettez à jour les images et vidéos clés du site sans toucher au code. Collez une URL Cloudinary ou autre CDN."
      defaultKeys={KEYS}
      settings={settings.filter((s) => s.category === "media" || KEYS.find((k) => k.key === s.key))}
      onReload={onReload}
    />
  );
}