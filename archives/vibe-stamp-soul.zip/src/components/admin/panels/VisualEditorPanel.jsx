import React, { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { useEditMode } from "@/lib/EditModeContext";
import { Pencil, ExternalLink, Sparkles, Search } from "lucide-react";

/**
 * VisualEditorPanel — onglet admin, vue dynamique de tous les slots éditables.
 * Les slots sont auto-enregistrés en base par <EditableText> au fil de la navigation
 * en mode admin. Ce panel les liste tous, regroupés par page.
 */

export default function VisualEditorPanel() {
  const { editing, toggleEdit, configs } = useEditMode();
  const [query, setQuery] = useState("");

  // Tous les slots de la base, triés par page puis slug
  const allSlots = useMemo(() => {
    const list = Object.values(configs || {});
    return list.sort((a, b) => {
      const pa = a.page_path || "/";
      const pb = b.page_path || "/";
      if (pa !== pb) return pa.localeCompare(pb);
      return (a.slug || "").localeCompare(b.slug || "");
    });
  }, [configs]);

  // Filtre recherche
  const filtered = useMemo(() => {
    if (!query.trim()) return allSlots;
    const q = query.toLowerCase();
    return allSlots.filter((s) =>
      [s.slug, s.label, s.value, s.page_path]
        .filter(Boolean)
        .some((v) => String(v).toLowerCase().includes(q))
    );
  }, [allSlots, query]);

  // Regroupement par page
  const byPage = useMemo(() => {
    const map = {};
    filtered.forEach((s) => {
      const p = s.page_path || "/(autre)";
      if (!map[p]) map[p] = [];
      map[p].push(s);
    });
    return map;
  }, [filtered]);

  const overrideCount = allSlots.filter((s) => s.value).length;

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-light text-white mb-2" style={{ fontFamily: "'Cormorant Garamond', serif" }}>
          Éditeur visuel
        </h2>
        <p className="text-white/50 text-[13px] max-w-2xl">
          Active le mode édition, navigue sur le site, et clique sur n'importe quel élément éditable pour modifier son contenu, sa taille ou sa couleur. Les changements sont publiés instantanément. Tous les textes sont automatiquement listés ici dès que tu visites les pages en mode admin.
        </p>
      </div>

      {/* Toggle mode édition */}
      <div className="rounded-2xl border border-[#B8963E]/30 bg-gradient-to-br from-[#B8963E]/10 to-transparent p-6">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#B8963E]/20 flex items-center justify-center">
              <Pencil size={16} className="text-[#B8963E]" />
            </div>
            <div>
              <div className="text-white text-[14px] font-medium mb-0.5">
                Mode édition {editing ? "actif" : "inactif"}
              </div>
              <div className="text-white/50 text-[11.5px]">
                {editing
                  ? "Les éléments éditables sont entourés en bleu sur le site."
                  : "Active-le pour pouvoir cliquer sur les éléments du site."}
              </div>
            </div>
          </div>
          <div className="flex gap-2">
            <button
              onClick={toggleEdit}
              className={`px-4 py-2 rounded-lg text-[12px] font-medium transition-colors ${
                editing
                  ? "bg-emerald-500/15 border border-emerald-500/40 text-emerald-300"
                  : "bg-[#B8963E] hover:bg-[#D4B483] text-black"
              }`}
            >
              {editing ? "✓ Activé" : "Activer le mode édition"}
            </button>
            <Link
              to="/"
              target="_blank"
              className="px-4 py-2 rounded-lg text-[12px] font-medium bg-white/[0.06] hover:bg-white/[0.12] border border-white/10 text-white flex items-center gap-1.5"
            >
              Voir le site <ExternalLink size={12} />
            </Link>
          </div>
        </div>
      </div>

      {/* KPI + recherche */}
      <div className="flex items-center gap-4 flex-wrap">
        <div className="flex items-center gap-2">
          <div className="text-[10px] tracking-[3px] uppercase text-[#B8963E]">Slots</div>
          <div className="text-white text-[14px] font-medium">{allSlots.length}</div>
        </div>
        <div className="flex items-center gap-2">
          <div className="text-[10px] tracking-[3px] uppercase text-emerald-300/80">Modifiés</div>
          <div className="text-white text-[14px] font-medium">{overrideCount}</div>
        </div>
        <div className="flex-1 min-w-[200px] flex items-center gap-2 rounded-lg bg-white/[0.04] border border-white/10 px-3 py-2">
          <Search size={13} className="text-white/40" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Rechercher (slug, page, texte…)"
            className="flex-1 bg-transparent outline-none text-white text-[12.5px] placeholder:text-white/35"
          />
        </div>
      </div>

      {/* Liste regroupée par page */}
      {allSlots.length === 0 ? (
        <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-8 text-center text-white/55 text-[13px]">
          Aucun slot enregistré pour le moment. Active le mode édition puis visite les pages du site —
          chaque texte éditable s'inscrira ici automatiquement.
        </div>
      ) : (
        <div className="space-y-6">
          {Object.keys(byPage).sort().map((page) => (
            <div key={page}>
              <div className="flex items-center gap-2 mb-2">
                <div className="text-[10px] tracking-[3px] uppercase text-[#B8963E]">
                  {page} · {byPage[page].length}
                </div>
                <Link
                  to={page === "/(autre)" ? "/" : page}
                  target="_blank"
                  className="text-[10px] text-white/40 hover:text-white/80 flex items-center gap-1"
                >
                  ouvrir <ExternalLink size={9} />
                </Link>
              </div>
              <div className="space-y-1.5">
                {byPage[page].map((s) => {
                  const hasOverride = !!s.value;
                  return (
                    <div
                      key={s.slug}
                      className="rounded-lg border border-white/10 bg-white/[0.02] p-3 flex items-start justify-between gap-3 hover:bg-white/[0.04] transition-colors"
                    >
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <div className="text-white text-[12.5px] font-medium">
                            {s.label || s.slug}
                          </div>
                          {hasOverride && (
                            <span className="px-1.5 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 text-[9px]">
                              ✓ modifié
                            </span>
                          )}
                          {s.size && (
                            <span className="px-1.5 py-0.5 rounded-full bg-white/[0.06] text-white/60 text-[9px]">
                              {s.size}
                            </span>
                          )}
                        </div>
                        <code className="text-[10px] text-white/30 font-mono">{s.slug}</code>
                        {hasOverride && (
                          <div className="text-white/55 text-[11.5px] mt-1 italic line-clamp-2">
                            « {s.value} »
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="rounded-2xl border border-white/10 bg-white/[0.01] p-5 text-[11.5px] text-white/50 leading-relaxed">
        <div className="flex items-start gap-2">
          <Sparkles size={14} className="text-[#B8963E] flex-shrink-0 mt-0.5" />
          <div>
            <strong className="text-white/70">Comment ça marche.</strong> Chaque texte du site est entouré d'un composant <code className="font-mono">{"<EditableText>"}</code> avec un identifiant stable (slug). Au premier passage en mode admin, le slug est inscrit en base avec son label et la page d'apparition. Tu peux ensuite cliquer dessus sur le site pour modifier sa valeur, sa taille ou sa couleur — sans rechargement.
          </div>
        </div>
      </div>
    </div>
  );
}