import React, { useState } from "react";
import { motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { setAdmin, getAdminPassword } from "@/lib/adminAuth";

export default function AdminLogin({ onSuccess }) {
  const [pwd, setPwd] = useState("");
  const [err, setErr] = useState(null);
  const [loading, setLoading] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setErr(null);
    try {
      const settings = await base44.entities.AdminSettings.list();
      const expected = getAdminPassword(settings);
      if (pwd === expected) {
        setAdmin(true);
        onSuccess?.();
      } else {
        setErr("Mot de passe incorrect.");
      }
    } catch (e) {
      setErr("Erreur de connexion. Réessayez.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 bg-[#0A0A0B] text-white">
      <motion.form
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        onSubmit={submit}
        className="w-full max-w-sm rounded-3xl bg-white/[0.03] backdrop-blur-md border border-white/10 p-8"
      >
        <div className="text-[11px] tracking-[5px] text-[#B8963E] uppercase mb-2 text-center">
          AIME® · Espace administrateur
        </div>
        <h1
          className="text-2xl font-light text-center mb-6"
          style={{ fontFamily: "'Cormorant Garamond', serif" }}
        >
          Le <em className="italic text-[#B8963E]">registre privé</em>.
        </h1>
        <input
          type="password"
          value={pwd}
          onChange={(e) => setPwd(e.target.value)}
          placeholder="Mot de passe"
          className="w-full bg-white/[0.04] border border-white/10 rounded-xl px-4 py-3 text-[14px] outline-none focus:border-[#B8963E] mb-3"
        />
        {err && <p className="text-[11px] text-red-400 mb-3">{err}</p>}
        <button
          type="submit"
          disabled={loading}
          className="w-full px-6 py-3 rounded-full bg-[#B8963E] text-[#1A1208] text-[10px] tracking-[3px] uppercase hover:bg-[#D4B483] transition-colors disabled:opacity-50"
        >
          {loading ? "Vérification…" : "Entrer"}
        </button>
        <p className="text-[10px] text-white/40 text-center mt-4">
          Espace réservé · Présentation marque · Suivi juridique
        </p>
      </motion.form>
    </div>
  );
}