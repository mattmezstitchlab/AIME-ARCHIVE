import React, { useState } from "react";
import { base44 } from "@/api/base44Client";

/**
 * SettingsEditor — affiche/édite un set de réglages d'une catégorie.
 * Reçoit la liste filtrée + permet de créer si vide.
 */
export default function SettingsEditor({
  category,
  title,
  description,
  defaultKeys = [], // [{key, label, description, defaultValue, multiline}]
  settings,
  onReload
}) {
  const [editing, setEditing] = useState({});
  const [saving, setSaving] = useState(null);

  const findSetting = (key) => settings.find((s) => s.key === key);

  const handleSave = async (key, def) => {
    setSaving(key);
    try {
      const existing = findSetting(key);
      const value = editing[key] ?? existing?.value ?? def.defaultValue ?? "";
      if (existing) {
        await base44.entities.AdminSettings.update(existing.id, { value });
      } else {
        await base44.entities.AdminSettings.create({
          key,
          category,
          label: def.label,
          description: def.description,
          value
        });
      }
      setEditing((e) => ({ ...e, [key]: undefined }));
      await onReload();
    } finally {
      setSaving(null);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2
          className="text-3xl font-light text-white mb-2"
          style={{ fontFamily: "'Cormorant Garamond', serif" }}
        >
          {title}
        </h2>
        {description && (
          <p className="text-white/50 text-[13px] max-w-2xl">{description}</p>
        )}
      </div>

      {defaultKeys.map((def) => {
        const existing = findSetting(def.key);
        const currentValue = editing[def.key] ?? existing?.value ?? def.defaultValue ?? "";
        const dirty = editing[def.key] !== undefined && editing[def.key] !== existing?.value;
        return (
          <div
            key={def.key}
            className="bg-white/[0.02] border border-white/10 rounded-2xl p-5"
          >
            <div className="flex items-baseline justify-between mb-2">
              <div>
                <div className="text-[14px] text-white font-medium">{def.label}</div>
                {def.description && (
                  <div className="text-[11px] text-white/40 mt-0.5">{def.description}</div>
                )}
              </div>
              <div className="text-[10px] text-white/30 font-mono">{def.key}</div>
            </div>
            {def.multiline ? (
              <textarea
                rows={4}
                value={currentValue}
                onChange={(e) => setEditing((ed) => ({ ...ed, [def.key]: e.target.value }))}
                className="w-full bg-black/30 border border-white/10 rounded-lg p-3 text-[13px] text-white outline-none focus:border-[#B8963E] resize-none"
              />
            ) : (
              <input
                value={currentValue}
                onChange={(e) => setEditing((ed) => ({ ...ed, [def.key]: e.target.value }))}
                className="w-full bg-black/30 border border-white/10 rounded-lg p-3 text-[13px] text-white outline-none focus:border-[#B8963E] font-mono"
              />
            )}
            <div className="flex justify-between items-center mt-3">
              <div className="text-[10px] text-white/40">
                {existing
                  ? `Mis à jour ${new Date(existing.updated_date).toLocaleDateString("fr-FR")}`
                  : "Non défini · valeur par défaut"}
              </div>
              <button
                disabled={!dirty || saving === def.key}
                onClick={() => handleSave(def.key, def)}
                className={`px-5 py-2 rounded-full text-[10px] tracking-[2px] uppercase transition-colors ${
                  dirty
                    ? "bg-[#B8963E] text-[#1A1208] hover:bg-[#D4B483]"
                    : "bg-white/5 text-white/30 cursor-not-allowed"
                }`}
              >
                {saving === def.key ? "Sauvegarde…" : "Enregistrer"}
              </button>
            </div>
          </div>
        );
      })}
    </div>
  );
}