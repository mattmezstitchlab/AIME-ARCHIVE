import React from "react";
import { setAdmin } from "@/lib/adminAuth";
import { useNavigate } from "react-router-dom";

const TABS = [
  { id: "dashboard", label: "Tableau de bord", group: "pilotage" },
  { id: "pages", label: "Arborescence · pages", group: "pilotage" },
  { id: "editor", label: "Éditeur visuel", group: "pilotage" },
  { id: "spaces", label: "Fenêtres · espaces", group: "pilotage" },
  { id: "minisites", label: "Mini-sites", group: "pilotage" },
  { id: "media", label: "Médias & visuels", group: "contenu" },
  { id: "texts", label: "Textes du site", group: "contenu" },
  { id: "cta", label: "Boutons & liens", group: "contenu" },
  { id: "colors", label: "Couleurs & palette", group: "contenu" },
  { id: "aima", label: "Réglages Aïma", group: "ia" },
  { id: "brand", label: "Marque & Brevets", group: "legal" },
  { id: "registry", label: "Registre des Timbres", group: "legal" },
  { id: "legal", label: "Mentions légales", group: "legal" }
];

const GROUP_LABELS = {
  pilotage: "Pilotage",
  contenu: "Contenu & visuel",
  ia: "Intelligence",
  legal: "Juridique & registre"
};

export default function AdminSidebar({ active, onChange }) {
  const navigate = useNavigate();
  const logout = () => {
    setAdmin(false);
    navigate("/");
  };
  return (
    <aside className="w-64 min-h-screen bg-[#0F0E10] border-r border-white/5 p-6 flex flex-col">
      <div className="mb-8">
        <div className="text-[10px] tracking-[5px] text-[#B8963E] uppercase mb-1">
          AIME®
        </div>
        <div
          className="text-xl font-light text-white"
          style={{ fontFamily: "'Cormorant Garamond', serif" }}
        >
          Administration
        </div>
        <div className="text-[10px] text-white/40 tracking-wider mt-1">aime-wedding.com</div>
      </div>

      <nav className="space-y-4 flex-1 overflow-y-auto">
        {Object.keys(GROUP_LABELS).map((group) => (
          <div key={group}>
            <div className="text-[9px] tracking-[0.25em] uppercase text-white/30 mb-1.5 px-4">
              {GROUP_LABELS[group]}
            </div>
            <div className="space-y-0.5">
              {TABS.filter((t) => t.group === group).map((t) => (
                <button
                  key={t.id}
                  onClick={() => onChange(t.id)}
                  className={`w-full text-left px-4 py-2 rounded-lg text-[13px] transition-colors ${
                    active === t.id
                      ? "bg-[#B8963E]/15 text-[#D4B483] border-l-2 border-[#B8963E]"
                      : "text-white/60 hover:text-white hover:bg-white/[0.04]"
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>
          </div>
        ))}
      </nav>

      <div className="space-y-2 pt-6 border-t border-white/5">
        <button
          onClick={() => navigate("/")}
          className="w-full text-left text-[11px] text-white/50 hover:text-white px-4 py-2 rounded-lg hover:bg-white/[0.04]"
        >
          ← Voir le site
        </button>
        <button
          onClick={logout}
          className="w-full text-left text-[11px] text-white/40 hover:text-red-400 px-4 py-2 rounded-lg hover:bg-white/[0.04]"
        >
          Déconnexion
        </button>
      </div>
    </aside>
  );
}