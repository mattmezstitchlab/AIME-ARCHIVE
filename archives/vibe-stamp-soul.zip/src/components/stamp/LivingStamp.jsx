import React, { useState, useRef } from "react";
import { motion } from "framer-motion";
import { Play, Pause, Volume2 } from "lucide-react";

/**
 * LivingStamp — un timbre vivant.
 * Image + voix + musique + animation. Comme Robin Williams dans la peinture.
 * Quand la personne n'est plus là, son timbre continue de parler.
 */
export default function LivingStamp({ stamp, size = 220 }) {
  const [playing, setPlaying] = useState(false);
  const audioRef = useRef(null);

  const togglePlay = () => {
    if (!stamp?.voice_url || !audioRef.current) return;
    if (playing) {
      audioRef.current.pause();
    } else {
      audioRef.current.play();
    }
    setPlaying(!playing);
  };

  return (
    <div className="inline-flex flex-col items-center gap-3">
      <motion.div
        animate={
          playing
            ? { scale: [1, 1.015, 1], rotate: [stamp?.rotation || 0, (stamp?.rotation || 0) + 0.5, stamp?.rotation || 0] }
            : { rotate: stamp?.rotation || 0 }
        }
        transition={
          playing
            ? { duration: 1.6, repeat: Infinity, ease: "easeInOut" }
            : { duration: 0.6, ease: [0.22, 1, 0.36, 1] }
        }
        className="relative rounded-md overflow-hidden bg-white"
        style={{
          width: size,
          height: size * 1.18,
          boxShadow:
            "0 12px 28px -10px rgba(0,0,0,0.35), 0 2px 6px rgba(0,0,0,0.12)",
          mask:
            "radial-gradient(circle at 5px 5px, transparent 3px, black 3.5px) 0 0/10px 10px",
          WebkitMask:
            "radial-gradient(circle at 5px 5px, transparent 3px, black 3.5px) 0 0/10px 10px"
        }}
      >
        {stamp?.animation_url ? (
          <video
            src={stamp.animation_url}
            autoPlay
            loop
            muted={!playing}
            playsInline
            className="absolute inset-0 w-full h-full object-cover"
          />
        ) : (
          <img
            src={stamp?.image_url}
            alt={stamp?.text || "Timbre vivant"}
            className="absolute inset-0 w-full h-full object-cover"
          />
        )}

        {/* Halo vibratoire quand ça parle */}
        {playing && (
          <motion.div
            aria-hidden
            initial={{ opacity: 0 }}
            animate={{ opacity: [0, 0.4, 0] }}
            transition={{ duration: 1.6, repeat: Infinity }}
            className="absolute inset-0 pointer-events-none"
            style={{
              boxShadow: "inset 0 0 60px 10px rgba(225,29,116,0.45)"
            }}
          />
        )}

        {/* Bouton play */}
        {stamp?.voice_url && (
          <button
            type="button"
            onClick={togglePlay}
            className="absolute inset-0 flex items-center justify-center group bg-black/0 hover:bg-black/15 transition-colors"
            aria-label={playing ? "Pause" : "Écouter le timbre vivant"}
          >
            <div className="w-14 h-14 rounded-full bg-white/85 backdrop-blur flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
              {playing ? (
                <Pause className="w-6 h-6 text-black" />
              ) : (
                <Play className="w-6 h-6 text-black ml-0.5" />
              )}
            </div>
          </button>
        )}

        {/* Code en bas */}
        {stamp?.code && (
          <div className="absolute bottom-1.5 left-0 right-0 text-center">
            <span className="text-[9px] tracking-[0.18em] text-black/60 font-mono">
              {stamp.code}
            </span>
          </div>
        )}
      </motion.div>

      {/* Audio element */}
      {stamp?.voice_url && (
        <audio
          ref={audioRef}
          src={stamp.voice_url}
          onEnded={() => setPlaying(false)}
          preload="none"
        />
      )}

      {/* Indicateur vibration */}
      {stamp?.vibration_signature && (
        <div className="flex items-center gap-1.5 text-[10px] tracking-[0.18em] uppercase text-black/45 font-mono">
          <Volume2 className="w-3 h-3" />
          {stamp.vibration_signature}
        </div>
      )}
    </div>
  );
}