import React from "react";
import { ShieldCheck, Clock, Hash, Sparkles } from "lucide-react";
import AIStamp from "@/components/aimemachine/AIStamp";

/**
 * VerifyCard — affichage public de la preuve d'antériorité d'un Stamp.
 */
export default function VerifyCard({ stamp }) {
  if (!stamp) return null;

  const issued = stamp.issued_at ? new Date(stamp.issued_at) : null;
  const dateStr = issued
    ? issued.toLocaleDateString("fr-FR", {
        day: "2-digit",
        month: "long",
        year: "numeric"
      })
    : "—";
  const timeStr = issued
    ? issued.toLocaleTimeString("fr-FR", {
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit"
      })
    : "—";

  return (
    <div className="bg-white border border-black/10 rounded-2xl p-8 md:p-10 max-w-3xl mx-auto shadow-sm">
      <div className="flex items-center gap-2 text-[11px] tracking-[0.3em] uppercase text-emerald-700 mb-6">
        <ShieldCheck className="w-4 h-4" />
        Preuve d'antériorité · vérifiée
      </div>

      <div className="flex flex-col md:flex-row gap-8 items-start">
        <div className="flex-shrink-0 mx-auto md:mx-0 w-[200px]">
          {stamp.image_url ? (
            <AIStamp imageUrl={stamp.image_url} code={stamp.code} size={200} />
          ) : (
            <div
              className="w-[200px] h-[200px] rounded-lg flex items-center justify-center"
              style={{
                background:
                  "repeating-linear-gradient(45deg, rgba(0,0,0,0.03) 0 8px, transparent 8px 16px)",
                border: "1px dashed rgba(0,0,0,0.15)"
              }}
            >
              <span className="text-[10px] tracking-[0.25em] uppercase text-black/40">
                Sans image
              </span>
            </div>
          )}
        </div>

        <div className="flex-1 min-w-0">
          <h2 className="font-display uppercase text-2xl md:text-3xl leading-tight mb-2">
            {stamp.text || stamp.person_name || "Timbre AIME®"}
          </h2>
          {stamp.person_name && stamp.text && (
            <div className="text-sm text-black/55 mb-5">
              {stamp.person_name}
            </div>
          )}

          {stamp.intention_text && (
            <blockquote className="border-l-2 border-rose-400/70 pl-4 italic text-black/75 font-serif text-[15px] leading-relaxed mb-6">
              « {stamp.intention_text} »
            </blockquote>
          )}

          <dl className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-3 text-[13px]">
            <div>
              <dt className="text-[10px] tracking-[0.25em] uppercase text-black/45 mb-0.5">
                <Clock className="w-3 h-3 inline mr-1" /> Horodatage
              </dt>
              <dd className="text-black/85 font-mono">
                {dateStr}
                <br />
                {timeStr}
              </dd>
            </div>
            <div>
              <dt className="text-[10px] tracking-[0.25em] uppercase text-black/45 mb-0.5">
                <Hash className="w-3 h-3 inline mr-1" /> Code
              </dt>
              <dd className="text-black/85 font-mono">{stamp.code || "—"}</dd>
            </div>
            {stamp.hash && (
              <div className="sm:col-span-2">
                <dt className="text-[10px] tracking-[0.25em] uppercase text-black/45 mb-0.5">
                  Hash SHA-256
                </dt>
                <dd className="text-black/65 font-mono text-[11px] break-all">
                  {stamp.hash}
                </dd>
              </div>
            )}
            {stamp.vibration_signature && (
              <div className="sm:col-span-2">
                <dt className="text-[10px] tracking-[0.25em] uppercase text-black/45 mb-0.5">
                  <Sparkles className="w-3 h-3 inline mr-1" /> Signature
                  vibratoire
                </dt>
                <dd className="text-black/85 font-mono">
                  {stamp.vibration_signature}
                </dd>
              </div>
            )}
            {stamp.soleau_filiation && (
              <div className="sm:col-span-2">
                <dt className="text-[10px] tracking-[0.25em] uppercase text-black/45 mb-0.5">
                  Filiation
                </dt>
                <dd className="text-black/85 font-mono text-[12px]">
                  {stamp.soleau_filiation} · INPI Soleau (2024)
                </dd>
              </div>
            )}
          </dl>

          {stamp.aima_signature && (
            <div className="mt-6 pt-6 border-t border-black/10 text-[13px] text-black/65 font-serif italic leading-relaxed">
              {stamp.aima_signature}
            </div>
          )}
        </div>
      </div>

      <div className="mt-8 pt-6 border-t border-black/10 text-[11px] tracking-[0.2em] uppercase text-black/40 text-center">
        AIME® · Signature Vibratoire par Intention™
      </div>
    </div>
  );
}