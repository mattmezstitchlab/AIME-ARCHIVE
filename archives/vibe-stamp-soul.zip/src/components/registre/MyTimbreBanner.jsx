import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import TimbreCard from "@/components/timbre/TimbreCard";
import { getAnonymousId } from "@/lib/aimaSession";

/**
 * MyTimbreBanner — Affiché en tête du Registre.
 * Si l'utilisateur a un Timbre : carte + infos + lien.
 * Sinon : invitation à le créer (passage obligé pour entrer dans le registre).
 */
export default function MyTimbreBanner() {
  const navigate = useNavigate();
  const [timbre, setTimbre] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        let user = null;
        try { user = await base44.auth.me(); } catch (_) {}
        const filter = user?.email
          ? { owner_email: user.email }
          : { anonymous_id: getAnonymousId() };
        const list = await base44.entities.Timbre.filter(filter, "-issued_at", 1);
        if (!cancelled) {
          setTimbre(list?.[0] || null);
          setLoading(false);
        }
      } catch (_) {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, []);

  if (loading) return null;

  if (!timbre) {
    return (
      <div
        className="mb-10 rounded-2xl px-6 py-7 text-center"
        style={{
          background: "#FAF7F0",
          border: "1px dashed rgba(184,154,82,0.4)"
        }}
      >
        <div
          style={{
            fontSize: 10,
            letterSpacing: "0.28em",
            color: "#B89A52",
            textTransform: "uppercase",
            marginBottom: 8,
            fontWeight: 500
          }}
        >
          Pour entrer dans le registre
        </div>
        <h2
          className="apple-headline"
          style={{
            fontSize: 22,
            color: "#1a1208",
            marginBottom: 10
          }}
        >
          Créez d'abord <span style={{ color: "#B89A52" }}>votre Timbre.</span>
        </h2>
        <p style={{ fontSize: 12, color: "#9A8B70", marginBottom: 16 }}>
          Le registre n'existe que parce que des Timbres l'habitent. Le vôtre vous attend.
        </p>
        <button
          onClick={() => navigate("/timbre/nouveau")}
          style={{
            padding: "11px 26px",
            borderRadius: 99,
            background: "#B89A52",
            color: "#1a1208",
            fontSize: 11,
            letterSpacing: "0.2em",
            textTransform: "uppercase",
            fontWeight: 500,
            border: "none",
            cursor: "pointer"
          }}
        >
          Créer mon Timbre
        </button>
      </div>
    );
  }

  return (
    <div
      className="mb-10 rounded-2xl px-6 py-6 flex flex-col sm:flex-row items-center gap-6"
      style={{
        background: "#FAF7F0",
        border: "1px solid rgba(184,154,82,0.25)"
      }}
    >
      <div className="flex-shrink-0">
        <TimbreCard timbre={timbre} size="sm" />
      </div>
      <div className="flex-1 text-center sm:text-left">
        <div
          style={{
            fontSize: 10,
            letterSpacing: "0.28em",
            color: "#B89A52",
            textTransform: "uppercase",
            marginBottom: 6,
            fontWeight: 500
          }}
        >
          Mon Timbre
        </div>
        <h2
          className="apple-headline"
          style={{
            fontSize: 20,
            color: "#1a1208",
            marginBottom: 8
          }}
        >
          Bienvenue, <span style={{ color: "#B89A52" }}>{timbre.first_name}</span>.
        </h2>
        <div style={{ fontSize: 12, color: "#4A3C28", lineHeight: 1.7 }}>
          Code <span style={{ fontFamily: "monospace", letterSpacing: "0.2em", color: "#B89A52" }}>{timbre.code}</span>
          {" · "}
          Registre <strong style={{ color: "#B89A52" }}>#{String(timbre.registry_n || 0).padStart(6, "0")}</strong>
          {" · "}
          {timbre.visibility === "public" ? "Public" : "Privé"}
        </div>
      </div>
    </div>
  );
}