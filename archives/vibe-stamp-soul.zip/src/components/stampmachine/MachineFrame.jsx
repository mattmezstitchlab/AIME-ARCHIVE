import React from "react";
import { motion } from "framer-motion";

/**
 * MachineFrame — L'écran de la StampMachine, sans boîtier.
 *
 * Plus de coque grise : l'écran noir respire dans le fond noir de la page.
 * La FENTE est en HAUT — c'est de là que descend le timbre, comme un
 * ticket qui tombe doucement depuis une imprimante invisible au plafond.
 *
 * Deux colonnes de LEDs arc-en-ciel pulsent sur les flancs de l'écran.
 *
 * Props :
 * - status: "idle" | "working" | "ready"
 * - slotChild: ReactNode  → le timbre qui descend de la fente
 * - children: contenu de l'écran
 */

const RAINBOW = [
  "#FF3B3B",
  "#FF9F1C",
  "#FFD60A",
  "#5DDD8A",
  "#3FA9F5",
  "#5B5BFF",
  "#B95BFF"
];

function LedColumn({ status }) {
  return (
    <div className="flex flex-col gap-3 py-2">
      {RAINBOW.map((c, i) => (
        <motion.div
          key={i}
          className="rounded-full"
          style={{
            width: 12,
            height: 12,
            background: c,
            boxShadow: `0 0 12px ${c}, 0 0 24px ${c}80`
          }}
          animate={
            status === "working"
              ? { opacity: [0.35, 1, 0.35], scale: [0.9, 1.15, 0.9] }
              : status === "ready"
              ? { opacity: [0.7, 1, 0.7] }
              : { opacity: [0.55, 0.9, 0.55] }
          }
          transition={{
            duration: status === "working" ? 0.9 : 2.4,
            repeat: Infinity,
            delay: i * 0.12,
            ease: "easeInOut"
          }}
        />
      ))}
    </div>
  );
}

export default function MachineFrame({ status = "idle", slotChild = null, children }) {
  return (
    <div className="relative inline-block w-full">
      {/* Bandeau "Moteur d'impression" + fente — EN HAUT */}
      <div className="mb-4">
        <div className="flex items-center justify-center mb-2">
          <span
            className="text-white/30 text-[9px] tracking-[0.4em] uppercase"
            style={{ fontFamily: "DM Sans, sans-serif" }}
          >
            — Moteur d'impression —
          </span>
        </div>

        {/* La fente (rectangle creux) */}
        <div
          className="relative rounded-md mx-auto overflow-visible"
          style={{
            width: "70%",
            height: 22,
            background:
              "linear-gradient(180deg, #000 0%, #1a1208 50%, #000 100%)",
            boxShadow:
              "inset 0 4px 8px rgba(0,0,0,0.95), inset 0 1px 0 rgba(212,175,55,0.15)"
          }}
        >
          {/* Lueur or pulsante */}
          <motion.div
            className="absolute inset-x-0 -top-1 -bottom-1 pointer-events-none"
            animate={
              status === "ready"
                ? { opacity: [0.4, 0.95, 0.4] }
                : status === "working"
                ? { opacity: [0.2, 0.5, 0.2] }
                : { opacity: 0.15 }
            }
            transition={{ duration: 1.6, repeat: Infinity, ease: "easeInOut" }}
            style={{
              background:
                "radial-gradient(ellipse at center, rgba(212,175,55,0.55) 0%, transparent 70%)",
              filter: "blur(6px)"
            }}
          />
        </div>
      </div>

      {/* La sortie : timbre qui descend doucement depuis la fente */}
      {slotChild && (
        <div className="relative w-full flex justify-center" style={{ marginTop: -10, marginBottom: 30, zIndex: 5 }}>
          {slotChild}
        </div>
      )}

      {/* Bloc écran + LEDs (sans coque) */}
      <div className="flex items-stretch gap-4 md:gap-6 justify-center">
        <LedColumn status={status} />

        {/* Écran central — flotte dans le noir, plus de boîtier */}
        <div
          className="flex-1 max-w-xl rounded-2xl p-5 md:p-7 min-h-[420px]"
          style={{
            background:
              "linear-gradient(180deg, #0d0d10 0%, #050507 100%)",
            boxShadow:
              "inset 0 0 40px rgba(0,0,0,0.85), inset 0 0 0 1px rgba(212,175,55,0.12), 0 0 60px rgba(212,175,55,0.05)"
          }}
        >
          {children}
        </div>

        <LedColumn status={status} />
      </div>
    </div>
  );
}