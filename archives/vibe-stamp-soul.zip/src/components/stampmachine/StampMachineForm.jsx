import React from "react";
import { CONTRATS_INCARNES } from "@/lib/contratsIncarnes";

/**
 * StampMachineForm — Le formulaire à l'intérieur de l'écran de la machine.
 * Saisie d'intention + sélection d'un acte parmi les 14.
 * Style sombre, gravé, doré.
 */
export default function StampMachineForm({
  intention,
  setIntention,
  contratId,
  setContratId,
  city,
  setCity,
  disabled
}) {
  return (
    <div className="space-y-5">
      <div>
        <h2
          className="text-white font-display uppercase text-[15px] tracking-tight mb-1"
        >
          Créer un Timbre AIME®
        </h2>
        <p className="text-white/45 text-[11px] tracking-[0.2em] uppercase font-sans">
          Une intention. Un code. Un sceau pour toujours.
        </p>
      </div>

      {/* Intention */}
      <div>
        <label className="block text-[10px] tracking-[0.25em] uppercase text-amber-400/70 font-sans mb-2">
          Intention
        </label>
        <textarea
          value={intention}
          onChange={(e) => setIntention(e.target.value)}
          disabled={disabled}
          rows={3}
          placeholder="Dis ce que tu veux sceller…"
          className="w-full bg-black/60 border border-amber-500/20 rounded-lg px-3 py-2.5 text-white text-[14px] font-serif italic placeholder-white/25 focus:outline-none focus:border-amber-400/60 transition-colors resize-none"
        />
        <div className="mt-1 text-right text-[10px] text-white/30 font-sans">
          {intention.length} / 280
        </div>
      </div>

      {/* Acte */}
      <div>
        <label className="block text-[10px] tracking-[0.25em] uppercase text-amber-400/70 font-sans mb-2">
          Acte incarné
        </label>
        <select
          value={contratId}
          onChange={(e) => setContratId(e.target.value)}
          disabled={disabled}
          className="w-full bg-black/60 border border-amber-500/20 rounded-lg px-3 py-2.5 text-white text-[13px] font-sans focus:outline-none focus:border-amber-400/60 transition-colors"
        >
          <option value="">— Choisir un acte parmi les 14 —</option>
          {CONTRATS_INCARNES.map((c) => (
            <option key={c.id} value={c.id} className="bg-black">
              {c.title}
            </option>
          ))}
        </select>
      </div>

      {/* Ville */}
      <div>
        <label className="block text-[10px] tracking-[0.25em] uppercase text-amber-400/70 font-sans mb-2">
          Ville d'émission
        </label>
        <input
          type="text"
          value={city}
          onChange={(e) => setCity(e.target.value)}
          disabled={disabled}
          placeholder="Paris"
          className="w-full bg-black/60 border border-amber-500/20 rounded-lg px-3 py-2.5 text-white text-[13px] font-sans placeholder-white/25 focus:outline-none focus:border-amber-400/60 transition-colors"
        />
      </div>
    </div>
  );
}