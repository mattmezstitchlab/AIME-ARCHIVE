import React from "react";

/**
 * RoundStamp — Timbre rond doré sur noir, gravé.
 * Style "pièce frappée" : couronne dentelée extérieure, anneau de texte
 * circulaire ("IDENTITÉ HUMAINE UNIVERSELLE · VALEUR · CONTRIBUTION · CONNEXION"),
 * silhouette/symbole au centre, code unique AIME-XXX-XXXX en bas.
 *
 * Tout en SVG, pas d'image bitmap. Or profond, fond noir, texture gravée.
 */
export default function RoundStamp({
  code = "AIME-XXX-XXXX",
  topText = "IDENTITÉ HUMAINE UNIVERSELLE",
  bottomText = "VALEUR · CONTRIBUTION · CONNEXION",
  size = 320,
  glow = true
}) {
  const S = size;
  const C = S / 2;
  const OUTER = C - 4;       // rayon couronne dentelée
  const INNER = OUTER - 18;  // rayon cercle intérieur
  const TEXT_R = INNER - 14; // rayon des textes circulaires

  // Couronne dentelée : on calcule les pointes
  const teeth = 64;
  const toothInner = OUTER - 6;
  const teethPath = (() => {
    let d = "";
    for (let i = 0; i < teeth; i++) {
      const a1 = (i / teeth) * Math.PI * 2;
      const a2 = ((i + 0.5) / teeth) * Math.PI * 2;
      const a3 = ((i + 1) / teeth) * Math.PI * 2;
      const x1 = C + Math.cos(a1) * OUTER;
      const y1 = C + Math.sin(a1) * OUTER;
      const x2 = C + Math.cos(a2) * toothInner;
      const y2 = C + Math.sin(a2) * toothInner;
      const x3 = C + Math.cos(a3) * OUTER;
      const y3 = C + Math.sin(a3) * OUTER;
      d += i === 0 ? `M ${x1} ${y1}` : ` L ${x1} ${y1}`;
      d += ` L ${x2} ${y2} L ${x3} ${y3}`;
    }
    d += " Z";
    return d;
  })();

  // Path circulaire pour le texte du HAUT (de gauche vers droite, en haut)
  // On dessine un demi-cercle qui passe par le HAUT du disque.
  const topArcId = "stampTopArc";
  const bottomArcId = "stampBottomArc";

  return (
    <div
      className="relative inline-block select-none"
      style={{
        filter: glow
          ? "drop-shadow(0 0 30px rgba(212,175,55,0.35)) drop-shadow(0 12px 40px rgba(0,0,0,0.6))"
          : "drop-shadow(0 8px 24px rgba(0,0,0,0.6))"
      }}
    >
      <svg width={S} height={S} viewBox={`0 0 ${S} ${S}`}>
        <defs>
          {/* Or radial : centre lumineux, bord plus sombre */}
          <radialGradient id="goldRadial" cx="50%" cy="40%" r="60%">
            <stop offset="0%" stopColor="#F4D78A" />
            <stop offset="50%" stopColor="#D4AF37" />
            <stop offset="100%" stopColor="#8B6914" />
          </radialGradient>
          {/* Or pour la couronne dentelée — plus sombre */}
          <radialGradient id="goldRim" cx="50%" cy="50%" r="55%">
            <stop offset="0%" stopColor="#C9A227" />
            <stop offset="100%" stopColor="#6B4F0E" />
          </radialGradient>
          {/* Texture grain noir du centre */}
          <radialGradient id="centerDark" cx="50%" cy="50%" r="55%">
            <stop offset="0%" stopColor="#1a1208" />
            <stop offset="100%" stopColor="#0a0604" />
          </radialGradient>

          {/* Arc supérieur pour textPath (de droite-haut vers gauche-haut, sens horaire dessus) */}
          <path
            id={topArcId}
            d={`M ${C - TEXT_R} ${C} A ${TEXT_R} ${TEXT_R} 0 0 1 ${C + TEXT_R} ${C}`}
            fill="none"
          />
          {/* Arc inférieur (sens horaire mais en bas, donc le texte se lit normalement) */}
          <path
            id={bottomArcId}
            d={`M ${C - TEXT_R} ${C} A ${TEXT_R} ${TEXT_R} 0 0 0 ${C + TEXT_R} ${C}`}
            fill="none"
          />
        </defs>

        {/* Couronne dentelée extérieure */}
        <path d={teethPath} fill="url(#goldRim)" />

        {/* Disque intérieur or */}
        <circle cx={C} cy={C} r={INNER} fill="url(#goldRadial)" />

        {/* Anneau gravé extérieur (ligne fine) */}
        <circle cx={C} cy={C} r={INNER - 4} fill="none" stroke="#5a3f0a" strokeWidth="0.7" opacity="0.7" />
        <circle cx={C} cy={C} r={INNER - 22} fill="none" stroke="#5a3f0a" strokeWidth="0.7" opacity="0.5" />

        {/* Centre sombre (médaillon) */}
        <circle cx={C} cy={C} r={INNER - 30} fill="url(#centerDark)" />
        <circle cx={C} cy={C} r={INNER - 30} fill="none" stroke="#D4AF37" strokeWidth="1" opacity="0.6" />

        {/* Texte circulaire HAUT */}
        <text
          fontFamily="Archivo Black, sans-serif"
          fontSize={INNER * 0.085}
          fill="#3a2807"
          letterSpacing="2"
        >
          <textPath href={`#${topArcId}`} startOffset="50%" textAnchor="middle">
            {topText}
          </textPath>
        </text>

        {/* Texte circulaire BAS */}
        <text
          fontFamily="Archivo Black, sans-serif"
          fontSize={INNER * 0.075}
          fill="#3a2807"
          letterSpacing="2.5"
        >
          <textPath href={`#${bottomArcId}`} startOffset="50%" textAnchor="middle">
            {bottomText}
          </textPath>
        </text>

        {/* Étoiles séparatrices à gauche/droite */}
        <text
          x={C - TEXT_R - 2}
          y={C + 5}
          fontSize={INNER * 0.1}
          fill="#3a2807"
          textAnchor="middle"
        >
          ✦
        </text>
        <text
          x={C + TEXT_R + 2}
          y={C + 5}
          fontSize={INNER * 0.1}
          fill="#3a2807"
          textAnchor="middle"
        >
          ✦
        </text>

        {/* Silhouette humaine au centre (figure simple gravée or) */}
        <g
          transform={`translate(${C}, ${C - 8})`}
          fill="none"
          stroke="#E6C76A"
          strokeWidth="1.4"
          strokeLinecap="round"
          strokeLinejoin="round"
          opacity="0.95"
        >
          {/* Tête */}
          <circle cx="0" cy={-INNER * 0.18} r={INNER * 0.05} fill="#E6C76A" stroke="none" />
          {/* Corps */}
          <line x1="0" y1={-INNER * 0.13} x2="0" y2={INNER * 0.05} />
          {/* Bras ouverts (bénédiction) */}
          <line x1="0" y1={-INNER * 0.06} x2={-INNER * 0.13} y2={-INNER * 0.02} />
          <line x1="0" y1={-INNER * 0.06} x2={INNER * 0.13} y2={-INNER * 0.02} />
          {/* Jambes */}
          <line x1="0" y1={INNER * 0.05} x2={-INNER * 0.07} y2={INNER * 0.18} />
          <line x1="0" y1={INNER * 0.05} x2={INNER * 0.07} y2={INNER * 0.18} />
          {/* Sol arrondi (planète) */}
          <path
            d={`M ${-INNER * 0.22} ${INNER * 0.18} Q 0 ${INNER * 0.26} ${INNER * 0.22} ${INNER * 0.18}`}
            stroke="#E6C76A"
            strokeWidth="1"
            opacity="0.7"
          />
          {/* Étoiles autour */}
          {[
            [-INNER * 0.28, -INNER * 0.18],
            [INNER * 0.26, -INNER * 0.2],
            [-INNER * 0.22, -INNER * 0.05],
            [INNER * 0.22, -INNER * 0.06]
          ].map(([x, y], i) => (
            <text
              key={i}
              x={x}
              y={y}
              fontSize={INNER * 0.05}
              fill="#E6C76A"
              stroke="none"
              textAnchor="middle"
            >
              ✦
            </text>
          ))}
        </g>

        {/* Cartouche du code en bas */}
        <g transform={`translate(${C}, ${C + INNER * 0.42})`}>
          <rect
            x={-INNER * 0.42}
            y={-INNER * 0.07}
            width={INNER * 0.84}
            height={INNER * 0.14}
            rx={INNER * 0.07}
            fill="#0a0604"
            stroke="#D4AF37"
            strokeWidth="0.8"
            opacity="0.95"
          />
          <text
            x="0"
            y={INNER * 0.025}
            textAnchor="middle"
            fontFamily="ui-monospace, SFMono-Regular, Menlo, monospace"
            fontSize={INNER * 0.085}
            fill="#E6C76A"
            letterSpacing="1.5"
          >
            {code}
          </text>
        </g>
      </svg>
    </div>
  );
}