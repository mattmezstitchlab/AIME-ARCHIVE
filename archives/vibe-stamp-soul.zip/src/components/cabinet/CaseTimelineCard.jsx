import React, { useState } from "react";
import { motion } from "framer-motion";
import { STATUS_LABELS, STATUS_COLORS, fmtDate, daysSince, appendEvent } from "@/lib/cabinet/caseHelpers";

/**
 * CaseTimelineCard — une carte par dossier dans Mon Cabinet.
 * Affiche : le timbre du droit, le statut, la timeline, les actions Aïma.
 */
export default function CaseTimelineCard({ caseRecord, onChange }) {
  const [busy, setBusy] = useState(false);
  const [open, setOpen] = useState(false);
  const status = caseRecord.status || "generated";
  const color = STATUS_COLORS[status];
  const lastEvent = (caseRecord.events || []).slice(-1)[0];
  const sinceLast = daysSince(lastEvent?.ts);

  const act = async (type, note) => {
    setBusy(true);
    try {
      await appendEvent(caseRecord, { type, note, actor: "user" });
      onChange?.();
    } finally {
      setBusy(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-2xl border border-[#B89A52]/25 bg-white p-5 md:p-6"
      style={{ boxShadow: "0 2px 12px rgba(26,18,8,0.04)" }}
    >
      {/* Header */}
      <div className="flex items-start justify-between gap-4 mb-4">
        <div className="min-w-0 flex-1">
          <div className="text-[9px] tracking-[3px] uppercase text-[#B89A52] mb-1.5 font-medium">
            Dossier · {caseRecord.code}
          </div>
          <h3
            className="text-[18px] md:text-[20px] text-[#1A1208] leading-tight"
            style={{ fontFamily: "'Playfair Display', serif", fontWeight: 600 }}
          >
            {caseRecord.right_label}
          </h3>
          {caseRecord.estimated_value_eur > 0 && (
            <div className="text-[12px] text-[#5A4A30] mt-1">
              Valeur estimée :{" "}
              <span className="font-semibold text-[#1A1208]">
                {caseRecord.estimated_value_eur.toLocaleString("fr-FR")} €
              </span>
            </div>
          )}
        </div>
        <span
          className="px-3 py-1 rounded-full text-[9px] tracking-[2px] uppercase font-medium whitespace-nowrap"
          style={{
            background: `${color}18`,
            color: color,
            border: `1px solid ${color}40`
          }}
        >
          {STATUS_LABELS[status]}
        </span>
      </div>

      {/* Aïma summary */}
      {caseRecord.naima_summary && (
        <div className="rounded-xl bg-[#F0E6C8]/30 border border-[#B89A52]/20 px-4 py-3 mb-4">
          <div className="flex items-start gap-2.5">
            <div className="w-6 h-6 rounded-full bg-[#B89A52] text-[#1A1208] flex items-center justify-center text-[11px] font-serif flex-shrink-0">
              A
            </div>
            <p className="text-[12.5px] text-[#1A1208] italic leading-relaxed" style={{ fontFamily: "'Playfair Display', serif" }}>
              {caseRecord.naima_summary}
            </p>
          </div>
        </div>
      )}

      {/* Last event */}
      {lastEvent && (
        <div className="text-[11px] text-[#8A7A60] mb-4">
          Dernière activité · {fmtDate(lastEvent.ts)}
          {sinceLast !== null && sinceLast > 0 && (
            <span className="ml-1">· il y a {sinceLast} jour{sinceLast > 1 ? "s" : ""}</span>
          )}
        </div>
      )}

      {/* Actions selon statut */}
      <div className="flex flex-wrap gap-2 mb-3">
        {status === "generated" && (
          <button
            onClick={() => act("sent", "Attestation transmise au destinataire.")}
            disabled={busy}
            className="px-4 py-2 rounded-full bg-[#1A1208] text-[#F0E6C8] text-[10px] tracking-[2px] uppercase hover:bg-[#B89A52] hover:text-[#1A1208] transition-colors disabled:opacity-50"
          >
            J'ai transmis le document
          </button>
        )}
        {(status === "sent" || status === "awaiting_response") && (
          <>
            <button
              onClick={() => act("response_received", "Réponse reçue du destinataire.")}
              disabled={busy}
              className="px-4 py-2 rounded-full bg-[#1A1208] text-[#F0E6C8] text-[10px] tracking-[2px] uppercase hover:bg-[#B89A52] hover:text-[#1A1208] transition-colors disabled:opacity-50"
            >
              J'ai reçu une réponse
            </button>
            <button
              onClick={() => act("escalated", "Pas de réponse — dossier escaladé.")}
              disabled={busy}
              className="px-4 py-2 rounded-full border border-[#C75A3A]/40 text-[#C75A3A] text-[10px] tracking-[2px] uppercase hover:bg-[#C75A3A]/5 transition-colors disabled:opacity-50"
            >
              Pas de réponse — escalader
            </button>
          </>
        )}
        {status === "responded" && (
          <>
            <button
              onClick={() => act("resolved", "Dossier résolu favorablement.")}
              disabled={busy}
              className="px-4 py-2 rounded-full bg-[#3A8A4A] text-white text-[10px] tracking-[2px] uppercase hover:bg-[#2D6E38] transition-colors disabled:opacity-50"
            >
              ✓ Résolu
            </button>
            <button
              onClick={() => act("escalated", "Réponse insuffisante — escalade.")}
              disabled={busy}
              className="px-4 py-2 rounded-full border border-[#C75A3A]/40 text-[#C75A3A] text-[10px] tracking-[2px] uppercase hover:bg-[#C75A3A]/5 transition-colors disabled:opacity-50"
            >
              Réponse insuffisante
            </button>
          </>
        )}
      </div>

      {/* Toggle timeline */}
      <button
        onClick={() => setOpen((o) => !o)}
        className="text-[10px] tracking-[2px] uppercase text-[#8A7A60] hover:text-[#B89A52] transition-colors"
      >
        {open ? "− Masquer la timeline" : `+ Voir la timeline (${(caseRecord.events || []).length})`}
      </button>

      {open && (
        <div className="mt-4 pt-4 border-t border-[#B89A52]/15 space-y-2.5">
          {(caseRecord.events || []).slice().reverse().map((e, i) => (
            <div key={i} className="flex items-start gap-3 text-[12px]">
              <div
                className="w-2 h-2 rounded-full mt-1.5 flex-shrink-0"
                style={{ background: STATUS_COLORS[e.type] || "#B89A52" }}
              />
              <div className="flex-1">
                <div className="text-[#1A1208]">{e.note || e.type}</div>
                <div className="text-[10px] text-[#8A7A60] mt-0.5">{fmtDate(e.ts)} · {e.actor}</div>
              </div>
            </div>
          ))}
        </div>
      )}
    </motion.div>
  );
}