import React from "react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";

/**
 * ManifestoJoin — CTA final : rejoindre l'écosystème AIME® (émettre son Timbre).
 * Style Game Changers "Join the GCV ecosystem" : grosse carte centrale claire sur fond mosaïque.
 */
export default function ManifestoJoin() {
  const navigate = useNavigate();

  const tiles = [
    "#E11D74", "#34D399", "#FF5A6E", "#5DA9FF", "#FACC15", "#FB923C",
    "#A8C49A", "#67D5DB", "#9F1239", "#5BC893", "#6366F1", "#F8A4B8"
  ];

  return (
    <section className="relative w-full py-24 md:py-32 px-6 overflow-hidden bg-black border-t border-white/5">
      {/* Mosaïque background */}
      <div className="absolute inset-0 grid grid-cols-6 md:grid-cols-10 gap-1 p-1 opacity-50">
        {Array.from({ length: 60 }).map((_, i) => (
          <div
            key={i}
            className="aspect-square rounded-sm"
            style={{ background: i % 3 === 0 ? "#0A0A0B" : tiles[i % tiles.length] }}
          />
        ))}
      </div>
      <div className="absolute inset-0 bg-black/70" />

      {/* Center card */}
      <div className="relative max-w-2xl mx-auto z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.4 }}
          transition={{ duration: 0.7 }}
          className="rounded-2xl bg-white p-10 md:p-14 text-center"
          style={{ boxShadow: "0 30px 80px -20px rgba(0,0,0,0.7)" }}
        >
          <div className="text-stone-500 text-[11px] tracking-[0.3em] uppercase mb-6 font-sans">
            Rejoindre l'écosystème
          </div>
          <h2
            className="font-display text-stone-900 uppercase leading-[0.95]"
            style={{ fontSize: "clamp(1.8rem, 4vw, 3rem)", letterSpacing: "-0.03em" }}
          >
            Émettre<br />ton Timbre.
          </h2>
          <p className="mt-6 text-stone-600 text-[15px] leading-relaxed font-sans">
            Ton identité souveraine, horodatée, signée par charte.
            Cinq minutes. Pour la vie.
          </p>
          <button
            onClick={() => navigate("/timbre/nouveau")}
            className="mt-9 inline-flex items-center gap-2 px-8 py-3.5 rounded-full bg-stone-900 hover:bg-black text-white text-[12px] tracking-[0.2em] uppercase transition-colors font-sans"
          >
            Sceller mon Timbre <span aria-hidden>→</span>
          </button>
        </motion.div>
      </div>
    </section>
  );
}