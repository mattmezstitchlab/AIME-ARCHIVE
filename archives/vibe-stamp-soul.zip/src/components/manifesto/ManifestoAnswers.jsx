import React from "react";
import { motion } from "framer-motion";

/**
 * ManifestoAnswers — Section "Ce qu'AIME® apporte à la France".
 * 6 réponses au mal français contemporain.
 * Layout : grille 2x3 dense, fond noir, accents colorés par carte.
 */

const ANSWERS = [
  {
    n: "01",
    title: "Aux voix qui s'effacent",
    label: "SLA · Charcot · Grand âge",
    body:
      "Le Noyau capture ta voix avant qu'elle ne parte. Elle revient parler à tes enfants, à 18 ans, le jour de leur mariage, à la naissance de leurs petits-enfants. Un slam d'outre-souffle.",
    accent: "#34D399"
  },
  {
    n: "02",
    title: "À la précarité administrative",
    label: "Sans-papiers · Inclusive · 115",
    body:
      "Aïma traduit les courriers, archive tes papiers, demande tes actes pour toi. Plus jamais venir signer en personne quand on est à 8000 km. Le Timbre fait foi.",
    accent: "#5DA9FF"
  },
  {
    n: "03",
    title: "À l'isolement rural",
    label: "Agriculteurs · MSA · PAC",
    body:
      "Compteur de marges, alerte météo, transmission d'exploitation, et surtout — un endroit où parler en confidence. Aïma écoute autant qu'elle calcule.",
    accent: "#A8C49A"
  },
  {
    n: "04",
    title: "Aux intermittents oubliés",
    label: "Annexe 8 · 10 · Audiens",
    body:
      "Compteur 507 heures en temps réel, archivage des AEM, pré-rédaction de CDDU. La spécificité française qu'aucune plateforme américaine ne touche.",
    accent: "#FACC15"
  },
  {
    n: "05",
    title: "Aux morts ordinaires",
    label: "Mémoire · Sceau · Transmission",
    body:
      "Pas seulement les célébrités. Chaque vie mérite son archive. Le Sceau d'union, le livre d'or vivant, l'écho du jour d'après. Une République des mémoires.",
    accent: "#E11D74"
  },
  {
    n: "06",
    title: "À la lourdeur de l'État civil",
    label: "Mairies · Consulats · SCEC",
    body:
      "Le Timbre AIME® comme identité pré-signée. Aïma compose le courrier, joint les justificatifs, suit la demande, archive la réponse. La mairie reste — l'attente disparaît.",
    accent: "#FB923C"
  }
];

export default function ManifestoAnswers() {
  return (
    <section className="relative w-full bg-black py-24 md:py-36 px-6 border-t border-white/5">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="max-w-3xl mb-16 md:mb-20">
          <div className="text-white/50 text-[11px] tracking-[0.4em] uppercase mb-5 font-sans">
            Six réponses au mal français
          </div>
          <h2
            className="font-display text-white uppercase leading-[0.95]"
            style={{ fontSize: "clamp(2.2rem, 5.5vw, 4.8rem)", letterSpacing: "-0.035em" }}
          >
            Ce qu'AIME®<br />répare.
          </h2>
        </div>

        {/* Grid 2 cols × 3 rows */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-5">
          {ANSWERS.map((a, i) => (
            <motion.article
              key={a.n}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{ duration: 0.6, delay: (i % 2) * 0.08, ease: [0.22, 1, 0.36, 1] }}
              className="relative rounded-2xl bg-[#0E0E11] border border-white/8 p-8 md:p-10 hover:border-white/20 transition-colors"
            >
              <div className="flex items-start justify-between gap-4 mb-6">
                <div
                  className="text-[11px] tracking-[0.25em] uppercase font-sans"
                  style={{ color: a.accent }}
                >
                  {a.label}
                </div>
                <div
                  className="font-display text-[14px] opacity-50"
                  style={{ color: a.accent }}
                >
                  {a.n}
                </div>
              </div>

              <h3
                className="font-display text-white uppercase leading-[1.05]"
                style={{
                  fontSize: "clamp(1.4rem, 2.5vw, 2rem)",
                  letterSpacing: "-0.02em"
                }}
              >
                {a.title}
              </h3>

              <p className="mt-5 text-white/65 text-[14.5px] leading-relaxed font-sans">
                {a.body}
              </p>

              <div
                className="absolute bottom-0 left-0 h-[2px] w-12"
                style={{ background: a.accent }}
              />
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}