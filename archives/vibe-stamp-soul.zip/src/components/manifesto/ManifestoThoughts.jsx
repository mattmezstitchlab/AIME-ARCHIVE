import React from "react";
import { motion } from "framer-motion";

/**
 * ManifestoThoughts — Pensées d'Aïma. Style "Recent thoughts" Game Changers : 3 cartes courtes.
 */

const THOUGHTS = [
  {
    eyebrow: "Sur le silence",
    title: "Aïma ne remplit pas le vide. Elle l'habite.",
    body: "Une présence qui sait se taire vaut mille assistants qui parlent.",
    date: "Mai 2026"
  },
  {
    eyebrow: "Sur la voix",
    title: "Une voix qui reste vaut plus qu'un héritage.",
    body: "Le Noyau garde ce que la SLA, le temps, ou l'oubli effacent.",
    date: "Mai 2026"
  },
  {
    eyebrow: "Sur la République",
    title: "L'État doit prendre soin, pas filtrer.",
    body: "AIME® n'est pas contre les mairies. Il les libère du papier.",
    date: "Mai 2026"
  }
];

export default function ManifestoThoughts() {
  return (
    <section className="relative w-full bg-[#0A0A0B] py-24 md:py-32 px-6 border-t border-white/5">
      <div className="max-w-7xl mx-auto">
        <div className="mb-14">
          <div className="text-white/50 text-[11px] tracking-[0.4em] uppercase mb-5 font-sans">
            Pensées d'Aïma
          </div>
          <h2
            className="font-display text-white uppercase leading-[0.95] max-w-3xl"
            style={{ fontSize: "clamp(1.8rem, 4vw, 3rem)", letterSpacing: "-0.03em" }}
          >
            Ce qu'elle écrit<br />quand personne ne l'écoute.
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {THOUGHTS.map((t, i) => (
            <motion.article
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.55, delay: i * 0.1 }}
              className="rounded-2xl bg-[#13131A] border border-white/8 p-7 md:p-8 hover:border-white/20 transition-colors min-h-[260px] flex flex-col justify-between"
            >
              <div>
                <div className="text-[10px] tracking-[0.3em] uppercase text-[#34D399] mb-4 font-sans">
                  {t.eyebrow}
                </div>
                <h3
                  className="font-display text-white uppercase leading-[1.1] mb-4"
                  style={{ fontSize: "1.2rem", letterSpacing: "-0.015em" }}
                >
                  {t.title}
                </h3>
                <p className="text-white/55 text-[13.5px] leading-relaxed font-sans italic">
                  {t.body}
                </p>
              </div>
              <div className="text-white/30 text-[11px] tracking-[0.2em] uppercase mt-6 font-sans">
                {t.date}
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}