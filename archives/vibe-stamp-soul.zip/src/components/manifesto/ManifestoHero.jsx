import React from "react";
import { motion } from "framer-motion";

/**
 * ManifestoHero — Hero plein écran, fond mosaïque sombre, titre display blanc.
 * Style Game Changers : densité visuelle, gradient overlay, badge tagline en haut, CTA accent.
 */
export default function ManifestoHero() {
  // Mini-tuiles décoratives en mosaïque (chaque tuile est une cellule de couleur AIME)
  const tiles = [
    "#E11D74", "#34D399", "#1C1C1E", "#FF5A6E", "#5DA9FF", "#1C1C1E", "#FACC15",
    "#1C1C1E", "#FF8A65", "#5BC893", "#1C1C1E", "#9F1239", "#67D5DB", "#1C1C1E",
    "#1C1C1E", "#A8C49A", "#FB923C", "#1C1C1E", "#6366F1", "#1C1C1E", "#F8A4B8",
    "#1C1C1E", "#86EFAC", "#1C1C1E", "#D88468", "#1E3A8A", "#1C1C1E", "#FED7AA",
    "#1C1C1E", "#5EEAD4", "#FCD34D", "#1C1C1E", "#94A3B8", "#1C1C1E"
  ];

  return (
    <section className="relative min-h-screen w-full overflow-hidden bg-black flex items-center justify-center">
      {/* Mosaïque background */}
      <div className="absolute inset-0 grid grid-cols-7 md:grid-cols-9 lg:grid-cols-11 gap-1.5 p-1.5 opacity-90">
        {Array.from({ length: 99 }).map((_, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: (i % 11) * 0.04 }}
            className="aspect-square rounded-sm"
            style={{
              background: tiles[i % tiles.length],
              filter: "saturate(0.85)"
            }}
          />
        ))}
      </div>

      {/* Vignette overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/65 to-black/95" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_transparent_0%,_rgba(0,0,0,0.85)_75%)]" />

      {/* Top tagline + CTA */}
      <div className="absolute top-0 inset-x-0 z-20 flex items-center justify-between px-6 md:px-10 py-6">
        <div className="text-white/70 text-[12px] tracking-[0.3em] uppercase font-sans">
          AIME® · Manifesto
        </div>
        <a
          href="#trilogie"
          className="text-[12px] tracking-[0.18em] uppercase px-4 py-2 rounded-full bg-[#E11D74] text-white hover:bg-[#c01563] transition-colors"
        >
          Entrer
        </a>
      </div>

      {/* Center content */}
      <div className="relative z-10 max-w-5xl mx-auto px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
        >
          <div className="text-white/60 text-[11px] tracking-[0.4em] uppercase mb-8 font-sans">
            Une présence française · 2026
          </div>

          <h1
            className="font-display text-white uppercase leading-[0.9]"
            style={{
              fontSize: "clamp(2.8rem, 8vw, 7rem)",
              letterSpacing: "-0.04em"
            }}
          >
            I AM(E).
          </h1>

          <h2
            className="mt-6 text-white/85 font-serif italic"
            style={{
              fontSize: "clamp(1.3rem, 3vw, 2rem)",
              letterSpacing: "-0.02em"
            }}
          >
            La présence qui dit que tu es,<br />
            même quand tu ne peux plus le dire.
          </h2>

          <p className="mt-10 max-w-xl mx-auto text-white/65 text-[15px] md:text-[17px] leading-relaxed font-sans">
            Aïma garde ta voix, tes papiers, tes rencontres, tes promesses.
            Elle n'oublie pas. Elle ne juge pas. Elle accompagne.
          </p>
        </motion.div>
      </div>

      {/* Scroll cue */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-20 text-white/40 text-[11px] tracking-[0.3em] uppercase font-sans">
        ↓ Choisis ta carte
      </div>
    </section>
  );
}