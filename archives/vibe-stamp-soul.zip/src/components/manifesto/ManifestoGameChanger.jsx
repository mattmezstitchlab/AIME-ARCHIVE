import React from "react";
import { motion } from "framer-motion";

/**
 * ManifestoGameChanger — Section "Pourquoi c'est un changement de paradigme".
 * Style Game Changers : grand pavé central, image / typographie immense, citation.
 */

const POINTS = [
  {
    k: "Le Timbre",
    v: "Identité souveraine, pré-signée, horodatée. Tu n'as plus à re-prouver qui tu es."
  },
  {
    k: "Aïma",
    v: "Délégataire de confiance. Elle écrit, archive, relance, suit. Tu respires."
  },
  {
    k: "Géographie abolie",
    v: "Buenos Aires, Cantal, EHPAD, sans adresse fixe — même accès, même dignité."
  },
  {
    k: "Tiers de confiance",
    v: "Construit pour eIDAS, RGPD, FranceConnect. On prouve l'usage, on demande la reconnaissance."
  }
];

export default function ManifestoGameChanger() {
  return (
    <section className="relative w-full bg-[#0A0A0B] py-24 md:py-40 px-6 border-t border-white/5 overflow-hidden">
      {/* Background type */}
      <div
        aria-hidden
        className="absolute inset-0 flex items-center justify-center pointer-events-none select-none"
      >
        <div
          className="font-display uppercase text-white/[0.025] whitespace-nowrap"
          style={{ fontSize: "clamp(8rem, 22vw, 22rem)", letterSpacing: "-0.05em" }}
        >
          GAME CHANGER
        </div>
      </div>

      <div className="relative max-w-6xl mx-auto z-10">
        {/* Quote */}
        <motion.blockquote
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl"
        >
          <div className="text-[#E11D74] text-[11px] tracking-[0.4em] uppercase mb-6 font-sans">
            Le paradigme
          </div>
          <p
            className="font-serif italic text-white leading-[1.1]"
            style={{ fontSize: "clamp(1.8rem, 4.5vw, 3.6rem)", letterSpacing: "-0.02em" }}
          >
            « AIME® transforme<br />
            <span className="text-white/60">le </span>
            <span className="not-italic font-display uppercase text-[#34D399]" style={{ fontSize: "0.9em" }}>il faut venir signer</span>
            <span className="text-white/60"> en </span><br />
            <span className="not-italic font-display uppercase" style={{ fontSize: "0.9em" }}>vous avez déjà signé une fois,</span><br />
            <span className="not-italic font-display uppercase" style={{ fontSize: "0.9em" }}>pour la vie, par votre Timbre.</span> »
          </p>
        </motion.blockquote>

        {/* 4 points */}
        <div className="mt-20 md:mt-28 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-px bg-white/10 rounded-2xl overflow-hidden">
          {POINTS.map((p, i) => (
            <motion.div
              key={p.k}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.4 }}
              transition={{ duration: 0.5, delay: i * 0.08 }}
              className="bg-[#0A0A0B] p-7 md:p-8"
            >
              <div className="text-[10px] tracking-[0.3em] uppercase text-[#34D399] mb-3 font-sans">
                0{i + 1}
              </div>
              <h3
                className="font-display text-white uppercase leading-tight mb-3"
                style={{ fontSize: "1.25rem", letterSpacing: "-0.015em" }}
              >
                {p.k}
              </h3>
              <p className="text-white/55 text-[13.5px] leading-relaxed font-sans">
                {p.v}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}