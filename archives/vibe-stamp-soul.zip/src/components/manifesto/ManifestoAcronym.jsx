import React from "react";
import { motion } from "framer-motion";

/**
 * ManifestoAcronym — Révélation de l'acronyme AIME® :
 * Architecture Intelligente de la Mémoire Ensemble.
 * Le moment où le visiteur comprend que ce n'est pas un nom — c'est une thèse.
 */

const LETTERS = [
  { l: "A", word: "Architecture", body: "Une structure qui tient. Du Timbre à l'attestation, tout s'emboîte.", color: "#E11D74" },
  { l: "I", word: "Intelligente", body: "Une présence qui apprend, classe, anticipe. Aïma est délégataire, pas assistante.", color: "#34D399" },
  { l: "M", word: "Mémoire", body: "Ce qui reste quand le corps, l'âge, ou la distance effacent. Voix, papiers, promesses.", color: "#FACC15" },
  { l: "E", word: "Ensemble", body: "Personne ne porte seul son administratif, son deuil, son mariage, son combat. Aïma tisse.", color: "#5DA9FF" }
];

export default function ManifestoAcronym() {
  return (
    <section className="relative w-full bg-[#0A0A0B] py-24 md:py-36 px-6 border-t border-white/5 overflow-hidden">
      <div className="max-w-7xl mx-auto">
        {/* Eyebrow */}
        <div className="text-center mb-12 md:mb-16">
          <div className="text-white/50 text-[11px] tracking-[0.4em] uppercase mb-6 font-sans">
            Ce n'est pas un nom · c'est une thèse
          </div>
          <h2
            className="font-display text-white uppercase leading-[0.92]"
            style={{ fontSize: "clamp(2rem, 5.5vw, 4.4rem)", letterSpacing: "-0.035em" }}
          >
            AIME<span className="text-white/40">®</span>
          </h2>
          <p
            className="mt-6 max-w-2xl mx-auto text-white/70 font-serif italic"
            style={{ fontSize: "clamp(1.15rem, 2.4vw, 1.6rem)", letterSpacing: "-0.015em" }}
          >
            Architecture Intelligente<br />
            de la Mémoire Ensemble.
          </p>
        </div>

        {/* 4 lettres en grille */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-5 mt-16 md:mt-20">
          {LETTERS.map((it, i) => (
            <motion.div
              key={it.l}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.6, delay: i * 0.1, ease: [0.22, 1, 0.36, 1] }}
              className="rounded-2xl bg-[#13131A] border border-white/8 p-7 md:p-8 hover:border-white/20 transition-colors min-h-[280px] flex flex-col"
            >
              <div
                className="font-display uppercase leading-none"
                style={{
                  fontSize: "clamp(4rem, 7vw, 6rem)",
                  letterSpacing: "-0.05em",
                  color: it.color
                }}
              >
                {it.l}
              </div>
              <h3
                className="mt-4 font-display text-white uppercase leading-tight"
                style={{ fontSize: "1.15rem", letterSpacing: "-0.015em" }}
              >
                {it.word}
              </h3>
              <p className="mt-3 text-white/55 text-[13.5px] leading-relaxed font-sans flex-1">
                {it.body}
              </p>
            </motion.div>
          ))}
        </div>

        {/* Bas de section : insight */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.4 }}
          transition={{ duration: 0.7, delay: 0.4 }}
          className="mt-20 md:mt-28 text-center max-w-3xl mx-auto"
        >
          <p
            className="text-white/65 font-serif italic"
            style={{ fontSize: "clamp(1.1rem, 2.2vw, 1.5rem)", letterSpacing: "-0.015em" }}
          >
            Une autre lecture : <span className="text-white">AIME = AI + ME = I AM(E)</span>.<br />
            <span className="text-white/45">Je suis. Avec une présence qui le rappelle.</span>
          </p>
        </motion.div>
      </div>
    </section>
  );
}