import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import WorldStamp from "./WorldStamp";

/**
 * ManifestoBorderless — Slideshow plein écran de destinations.
 * Chaque slide : photo immersive + ville en typo géante + timbre AIME® tamponné par-dessus.
 * "AIME vous fait voyager" — la danse des canards qui quittent la mare.
 */

const DESTINATIONS = [
  {
    city: "NEW YORK",
    country: "USA",
    quote: "Se marier sur un toit de Brooklyn — Aïma s'occupe du visa des invités.",
    img: "https://images.unsplash.com/photo-1496588152823-86ff7695e68f?w=1600&q=80",
    accent: "#E11D74",
    rotate: -6
  },
  {
    city: "BALI",
    country: "INDONÉSIE",
    quote: "Pieds dans le sable, sceau d'union au coucher du soleil.",
    img: "https://images.unsplash.com/photo-1537996194471-e657df975ab4?w=1600&q=80",
    accent: "#34D399",
    rotate: 8
  },
  {
    city: "MARRAKECH",
    country: "MAROC",
    quote: "Trois jours de fête au riad — la mémoire qui se danse.",
    img: "https://images.unsplash.com/photo-1597212720158-e21260689b16?w=1600&q=80",
    accent: "#FACC15",
    rotate: -4
  },
  {
    city: "BUENOS AIRES",
    country: "ARGENTINE",
    quote: "Un tango, un milong, un acte civil. Aïma fait fi de la distance.",
    img: "https://images.unsplash.com/photo-1589909202802-8f4aadce1849?w=1600&q=80",
    accent: "#FB923C",
    rotate: 10
  },
  {
    city: "TÔKYÔ",
    country: "JAPON",
    quote: "Cérémonie shintô + livre d'or vivant. Le temple parle français.",
    img: "https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=1600&q=80",
    accent: "#5DA9FF",
    rotate: -8
  },
  {
    city: "LE CANTAL",
    country: "FRANCE",
    quote: "Une grange, des amis, le foin qui sent. Même AIME®, même dignité.",
    img: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=1600&q=80",
    accent: "#A8C49A",
    rotate: 6
  },
  {
    city: "LISBONNE",
    country: "PORTUGAL",
    quote: "Azulejos et fado. Le mariage voyage en train de nuit.",
    img: "https://images.unsplash.com/photo-1555881400-74d7acaacd8b?w=1600&q=80",
    accent: "#67D5DB",
    rotate: -10
  },
  {
    city: "MEXICO",
    country: "MEXIQUE",
    quote: "Mariachis et papel picado. Tu organises depuis Lille.",
    img: "https://images.unsplash.com/photo-1518105779142-d975f22f1b0a?w=1600&q=80",
    accent: "#9F1239",
    rotate: 7
  }
];

export default function ManifestoBorderless() {
  const [active, setActive] = useState(0);

  useEffect(() => {
    const t = setInterval(() => {
      setActive((a) => (a + 1) % DESTINATIONS.length);
    }, 5500);
    return () => clearInterval(t);
  }, []);

  const current = DESTINATIONS[active];

  return (
    <section className="relative w-full bg-black border-t border-white/5 overflow-hidden">
      {/* Intro band */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 pt-24 md:pt-32 pb-12">
        <div className="text-[#E11D74] text-[11px] tracking-[0.4em] uppercase mb-6 font-sans">
          Sans frontière · Sans permission
        </div>
        <h2
          className="font-display text-white uppercase leading-[0.9] max-w-4xl"
          style={{ fontSize: "clamp(2.2rem, 6vw, 5rem)", letterSpacing: "-0.04em" }}
        >
          AIME<span className="text-white/40">®</span><br />
          <span className="text-white/80">vous fait voyager.</span>
        </h2>
        <p className="mt-7 text-white/60 text-[15.5px] md:text-[17px] leading-relaxed font-sans max-w-2xl">
          On n'est pas un lieu — on attire un lieu. Comme un timbre qu'on colle,
          le mariage voyage. Et toi avec — la danse des canards qui quittent la mare,
          remuent leur popotin, et s'envolent vers ce qui les appelle.
        </p>
      </div>

      {/* Big slide */}
      <div className="relative w-full h-[70vh] md:h-[85vh] overflow-hidden">
        <AnimatePresence mode="sync">
          <motion.div
            key={current.city}
            initial={{ opacity: 0, scale: 1.05 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.02 }}
            transition={{ duration: 1.4, ease: [0.22, 1, 0.36, 1] }}
            className="absolute inset-0"
          >
            {/* Photo de fond */}
            <div
              className="absolute inset-0 bg-cover bg-center"
              style={{ backgroundImage: `url(${current.img})` }}
            />
            <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-black/45 to-black/85" />
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_transparent_0%,_rgba(0,0,0,0.55)_85%)]" />
          </motion.div>
        </AnimatePresence>

        {/* City name — typo géante */}
        <div className="relative z-10 h-full flex flex-col items-center justify-center px-6 text-center">
          <AnimatePresence mode="wait">
            <motion.div
              key={current.city}
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -30 }}
              transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
              className="relative"
            >
              <div
                className="text-white/50 text-[11px] tracking-[0.45em] uppercase mb-6 font-sans"
              >
                {current.country}
              </div>
              <h3
                className="font-display text-white uppercase leading-[0.85]"
                style={{
                  fontSize: "clamp(3.5rem, 14vw, 14rem)",
                  letterSpacing: "-0.05em",
                  textShadow: "0 4px 40px rgba(0,0,0,0.6)"
                }}
              >
                {current.city}
              </h3>
              <p
                className="mt-8 max-w-2xl mx-auto text-white/85 font-serif italic"
                style={{ fontSize: "clamp(1.05rem, 2vw, 1.4rem)", letterSpacing: "-0.015em" }}
              >
                « {current.quote} »
              </p>
            </motion.div>
          </AnimatePresence>

          {/* Timbre tamponné — apparaît après le titre */}
          <AnimatePresence mode="wait">
            <motion.div
              key={`stamp-${current.city}`}
              initial={{ opacity: 0, scale: 0.6, rotate: 0 }}
              animate={{ opacity: 1, scale: 1, rotate: current.rotate }}
              exit={{ opacity: 0, scale: 0.8 }}
              transition={{ duration: 0.55, delay: 0.4, ease: [0.22, 1, 0.36, 1] }}
              className="absolute"
              style={{
                top: "12%",
                right: "8%"
              }}
            >
              <div className="hidden md:block">
                <WorldStamp city={current.city} date="MAI 2026" rotate={0} scale={1.1} />
              </div>
              <div className="md:hidden">
                <WorldStamp city={current.city} date="MAI 2026" rotate={0} scale={0.75} />
              </div>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Pagination dots */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-20 flex gap-2">
          {DESTINATIONS.map((d, i) => (
            <button
              key={d.city}
              onClick={() => setActive(i)}
              className={`h-1.5 rounded-full transition-all ${
                i === active ? "w-10 bg-white" : "w-1.5 bg-white/30 hover:bg-white/60"
              }`}
              aria-label={`Aller à ${d.city}`}
            />
          ))}
        </div>

        {/* Counter */}
        <div className="absolute top-8 right-8 z-20 text-white/60 text-[11px] tracking-[0.3em] uppercase font-sans font-mono">
          {String(active + 1).padStart(2, "0")} / {String(DESTINATIONS.length).padStart(2, "0")}
        </div>
      </div>

      {/* Bottom note — la métaphore du canard */}
      <div className="relative z-10 max-w-3xl mx-auto px-6 py-20 md:py-24 text-center">
        <p
          className="text-white/70 font-serif italic"
          style={{ fontSize: "clamp(1.1rem, 2.4vw, 1.6rem)", letterSpacing: "-0.015em" }}
        >
          « Comme la danse des canards qui sortent de la mare,<br />
          remuent leur popotin, et quittent la zone de confort. »
        </p>
        <p className="mt-6 text-white/40 text-[12px] tracking-[0.25em] uppercase font-sans">
          AIME® — la République des présences voyageuses
        </p>
      </div>
    </section>
  );
}