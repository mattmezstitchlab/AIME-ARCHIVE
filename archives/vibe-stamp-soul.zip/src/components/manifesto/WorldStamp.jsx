import React from "react";

/**
 * WorldStamp — Un timbre AIME® tamponné, façon poste.
 * Vraie dentelure dessinée en SVG (path avec arcs sur les 4 bords).
 * AIME® en Archivo Black, ville dessous, cachet circulaire oblitération.
 */
export default function WorldStamp({ city = "PARIS", date = "MAI 2026", rotate = -8, scale = 1 }) {
  // Géométrie du timbre
  const W = 240;
  const H = 150;
  const STEP = 14; // espacement entre les dents
  const R = 5;     // rayon des dents
  const cols = Math.floor(W / STEP);
  const rows = Math.floor(H / STEP);
  const offsetX = (W - cols * STEP) / 2 + STEP / 2;
  const offsetY = (H - rows * STEP) / 2 + STEP / 2;

  // Construction du path : on part du coin haut-gauche, on dessine le contour
  // en faisant un demi-cercle (arc) creusé vers l'intérieur à chaque dent.
  let d = `M 0 0`;
  // Bord haut (gauche → droite) — arcs vers le BAS (creux)
  for (let i = 0; i < cols; i++) {
    const cx = offsetX + i * STEP;
    d += ` L ${cx - R} 0`;
    d += ` A ${R} ${R} 0 0 0 ${cx + R} 0`;
  }
  d += ` L ${W} 0`;
  // Bord droit (haut → bas) — arcs vers la GAUCHE (creux)
  for (let i = 0; i < rows; i++) {
    const cy = offsetY + i * STEP;
    d += ` L ${W} ${cy - R}`;
    d += ` A ${R} ${R} 0 0 0 ${W} ${cy + R}`;
  }
  d += ` L ${W} ${H}`;
  // Bord bas (droite → gauche) — arcs vers le HAUT (creux)
  for (let i = cols - 1; i >= 0; i--) {
    const cx = offsetX + i * STEP;
    d += ` L ${cx + R} ${H}`;
    d += ` A ${R} ${R} 0 0 0 ${cx - R} ${H}`;
  }
  d += ` L 0 ${H}`;
  // Bord gauche (bas → haut) — arcs vers la DROITE (creux)
  for (let i = rows - 1; i >= 0; i--) {
    const cy = offsetY + i * STEP;
    d += ` L 0 ${cy + R}`;
    d += ` A ${R} ${R} 0 0 0 0 ${cy - R}`;
  }
  d += ` Z`;

  return (
    <div
      className="relative inline-block select-none"
      style={{ transform: `rotate(${rotate}deg) scale(${scale})` }}
    >
      {/* SVG : timbre dentelé + contenu */}
      <svg
        width={W}
        height={H}
        viewBox={`0 0 ${W} ${H}`}
        style={{
          filter:
            "drop-shadow(0 8px 24px rgba(0,0,0,0.4)) drop-shadow(0 2px 6px rgba(0,0,0,0.3))",
          display: "block"
        }}
      >
        {/* Le papier crème dentelé */}
        <path d={d} fill="#FAF7F0" />

        {/* Cadre intérieur */}
        <rect
          x="14"
          y="14"
          width={W - 28}
          height={H - 28}
          fill="none"
          stroke="rgba(28,28,30,0.3)"
          strokeWidth="1"
        />

        {/* AIME® */}
        <text
          x={W / 2}
          y={H / 2 - 14}
          textAnchor="middle"
          fontFamily="Archivo Black, sans-serif"
          fontSize="32"
          fill="#E11D74"
          letterSpacing="-0.5"
        >
          AIME
          <tspan fill="#1C1C1E" fontSize="18" dy="-8">®</tspan>
        </text>

        {/* République des présences */}
        <text
          x={W / 2}
          y={H / 2 + 8}
          textAnchor="middle"
          fontFamily="DM Sans, sans-serif"
          fontSize="9"
          fill="#1C1C1E"
          letterSpacing="2"
          style={{ textTransform: "uppercase" }}
        >
          RÉPUBLIQUE DES PRÉSENCES
        </text>

        {/* Ligne séparatrice */}
        <line
          x1="32"
          y1={H / 2 + 18}
          x2={W - 32}
          y2={H / 2 + 18}
          stroke="rgba(28,28,30,0.2)"
          strokeWidth="1"
        />

        {/* Ville */}
        <text
          x={W / 2}
          y={H / 2 + 36}
          textAnchor="middle"
          fontFamily="Archivo Black, sans-serif"
          fontSize="13"
          fill="#1C1C1E"
          letterSpacing="1"
        >
          {city.toUpperCase()}
        </text>
      </svg>

      {/* Cachet circulaire oblitération — superposé en HTML */}
      <div
        className="absolute -top-2 -right-3 w-16 h-16 rounded-full border-2 border-[#1C1C1E]/70 flex items-center justify-center pointer-events-none"
        style={{
          transform: "rotate(12deg)",
          background:
            "repeating-linear-gradient(45deg, transparent, transparent 4px, rgba(28,28,30,0.08) 4px, rgba(28,28,30,0.08) 5px)"
        }}
      >
        <div className="text-center">
          <div
            className="font-display uppercase text-[#1C1C1E]/80 leading-none"
            style={{ fontSize: 8, letterSpacing: "0.1em" }}
          >
            OBLITÉRÉ
          </div>
          <div
            className="mt-0.5 font-sans text-[#1C1C1E]/70"
            style={{ fontSize: 7, letterSpacing: "0.08em" }}
          >
            {date}
          </div>
          <div
            className="mt-0.5 font-display text-[#1C1C1E]/70"
            style={{ fontSize: 7 }}
          >
            ★ ★ ★
          </div>
        </div>
      </div>
    </div>
  );
}