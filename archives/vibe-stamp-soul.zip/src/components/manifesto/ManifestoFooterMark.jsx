import React from "react";

/**
 * ManifestoFooterMark — Signature finale : "AIME®" en immense Archivo Black, fond noir.
 * Style Game Changers "Game Changers®" en bas de page.
 */
export default function ManifestoFooterMark() {
  return (
    <section className="relative w-full bg-black pt-12 pb-8 md:pt-16 md:pb-10 px-6 border-t border-white/5">
      <div className="max-w-[1600px] mx-auto">
        <div className="flex items-end justify-between gap-6 mb-6">
          <div className="text-white/40 text-[11px] tracking-[0.3em] uppercase font-sans">
            I AM(E) · 2026 · France
          </div>
          <div className="text-white/40 text-[11px] tracking-[0.3em] uppercase font-sans hidden md:block">
            Une présence, pas un outil
          </div>
        </div>
        <div
          className="font-display text-[#E11D74] uppercase leading-[0.85] select-none"
          style={{
            fontSize: "clamp(4rem, 18vw, 18rem)",
            letterSpacing: "-0.045em"
          }}
        >
          AIME<span className="text-white/80">®</span>
        </div>
      </div>
    </section>
  );
}