import React from "react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";

/**
 * ManifestoTrilogy — 3 cartes du mariage : Invité (Passé) · Prestataire (Présent) · Futurs Mariés (Futur).
 * Chaque rôle habite un temps différent — c'est la grille temporelle du mariage selon AIME®.
 */

const CARDS = [
  {
    id: "past",
    eyebrow: "01 · Passé · Invité·e",
    title: "Voyager dans la mémoire",
    body:
      "L'invité·e vient célébrer ce qui a été tissé. Il apporte ses souvenirs, son livre d'or, sa chanson déposée — la mémoire qui rend la fête possible.",
    cta: "Entrer comme invité·e",
    href: "/mariage",
    bg: "#FAF7F0",
    fg: "#1C1C1E",
    accent: "#8B6914",
    eyebrowColor: "rgba(28,28,30,0.55)"
  },
  {
    id: "present",
    eyebrow: "02 · Présent · Prestataire",
    title: "L'instant qu'on réserve",
    body:
      "Le prestataire vit le présent fragile du « je vous tiens cette date ». Un présent qu'on espère pour le futur — mais jamais garanti, jusqu'au sceau.",
    cta: "Entrer comme prestataire",
    href: "/mariage",
    bg: "#34D399",
    fg: "#0A1F18",
    accent: "#0A1F18",
    eyebrowColor: "rgba(10,31,24,0.7)"
  },
  {
    id: "future",
    eyebrow: "03 · Futur · Futurs mariés",
    title: "Écrire ce qui n'existe pas",
    body:
      "Les mariés projettent, s'engagent, scellent. Ils tracent un futur qui n'a pas encore eu lieu — et Aïma garde la trace, la voix, la promesse.",
    cta: "Entrer comme futurs mariés",
    href: "/mariage",
    bg: "#0A0F1E",
    fg: "#FFFFFF",
    accent: "#E11D74",
    eyebrowColor: "rgba(255,255,255,0.55)"
  }
];

export default function ManifestoTrilogy() {
  const navigate = useNavigate();

  return (
    <section id="trilogie" className="relative w-full bg-black py-24 md:py-36 px-6">
      {/* Section header */}
      <div className="max-w-6xl mx-auto text-center mb-16 md:mb-20">
        <div className="text-white/50 text-[11px] tracking-[0.4em] uppercase mb-5 font-sans">
          Au mariage · chacun habite un temps
        </div>
        <h2
          className="font-display text-white uppercase leading-[0.95]"
          style={{ fontSize: "clamp(2rem, 5vw, 4rem)", letterSpacing: "-0.03em" }}
        >
          Choisis ta carte.
        </h2>
        <p className="mt-6 max-w-2xl mx-auto text-white/60 text-[15px] md:text-[17px] leading-relaxed font-sans">
          L'invité·e habite le passé qu'il célèbre. Le prestataire tient le présent fragile.
          Les mariés écrivent un futur qui n'existe pas encore. Aïma tisse les trois temps.
        </p>
      </div>

      {/* 3 cards */}
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6">
        {CARDS.map((c, i) => (
          <motion.button
            key={c.id}
            type="button"
            onClick={() => navigate(c.href)}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.7, delay: i * 0.12, ease: [0.22, 1, 0.36, 1] }}
            whileHover={{ y: -6 }}
            className="group relative text-left rounded-2xl overflow-hidden p-8 md:p-10 min-h-[440px] md:min-h-[520px] flex flex-col justify-between transition-shadow"
            style={{
              background: c.bg,
              color: c.fg,
              boxShadow: "0 20px 60px -20px rgba(0,0,0,0.6)"
            }}
          >
            {/* Eyebrow */}
            <div
              className="text-[11px] tracking-[0.3em] uppercase font-sans"
              style={{ color: c.eyebrowColor }}
            >
              {c.eyebrow}
            </div>

            {/* Title + body */}
            <div className="mt-6 md:mt-10">
              <h3
                className="font-display uppercase leading-[1.02]"
                style={{
                  fontSize: "clamp(1.6rem, 3vw, 2.4rem)",
                  letterSpacing: "-0.025em"
                }}
              >
                {c.title}
              </h3>
              <p
                className="mt-5 text-[14.5px] md:text-[15.5px] leading-relaxed font-sans"
                style={{ color: c.fg, opacity: 0.78 }}
              >
                {c.body}
              </p>
            </div>

            {/* CTA */}
            <div
              className="mt-10 inline-flex items-center gap-2 text-[12px] tracking-[0.2em] uppercase font-sans group-hover:gap-3 transition-all"
              style={{ color: c.accent }}
            >
              <span>{c.cta}</span>
              <span aria-hidden>→</span>
            </div>
          </motion.button>
        ))}
      </div>
    </section>
  );
}