import React from "react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";

/**
 * ManifestoVerticals — Mosaïque sombre des verticales AIME® (Mariage, Inclusive, etc.)
 * Style Game Changers "Recent Projects" : 4 cards grandes, visuelles, hover lumineux.
 */

const VERTICALS = [
  {
    slug: "mariage",
    eyebrow: "Vous deux",
    label: "Mariage",
    body: "Trouve, organise, scelle. Aïma tisse votre jour J — du premier prestataire au sceau d'union.",
    bg: "#E11D74",
    fg: "#FFFFFF"
  },
  {
    slug: "inclusive",
    eyebrow: "Inclusive",
    label: "À tous, pour tous",
    body: "Traduire un courrier, ranger ses papiers, dicter son histoire. AIME® pour celles et ceux que l'État oublie.",
    bg: "#5DA9FF",
    fg: "#0A0F1E"
  },
  {
    slug: "intermittents",
    eyebrow: "Intermittents",
    label: "Annexe 8 · 10",
    body: "507h, AEM, CDDU, Audiens, AFDAS. La spécificité française enfin tenue à la main.",
    bg: "#FACC15",
    fg: "#1C1C1E"
  },
  {
    slug: "agriculteurs",
    eyebrow: "Agriculteurs",
    label: "MSA · PAC · Terre",
    body: "Marges, transmission, météo, droits méconnus. Aïma écoute autant qu'elle calcule.",
    bg: "#A8C49A",
    fg: "#1C1C1E"
  },
  {
    slug: "mairies",
    eyebrow: "Mairies",
    label: "Pour les communes",
    body: "Mariages civils, registres territoriaux, prestataires locaux, heatmap des Timbres.",
    bg: "#0A0F1E",
    fg: "#FFFFFF"
  },
  {
    slug: "noyau",
    eyebrow: "Noyau · SLÂME",
    label: "La voix qui reste",
    body: "Capturer la voix avant qu'elle ne parte. Programmer ce qui doit te survivre.",
    bg: "#1C1C1E",
    fg: "#34D399"
  }
];

export default function ManifestoVerticals() {
  const navigate = useNavigate();

  return (
    <section className="relative w-full bg-black py-24 md:py-36 px-6 border-t border-white/5">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-14 md:mb-20">
          <div>
            <div className="text-white/50 text-[11px] tracking-[0.4em] uppercase mb-5 font-sans">
              Les fenêtres
            </div>
            <h2
              className="font-display text-white uppercase leading-[0.95]"
              style={{ fontSize: "clamp(2rem, 5vw, 4rem)", letterSpacing: "-0.035em" }}
            >
              Une présence, plusieurs portes.
            </h2>
          </div>
          <p className="md:max-w-md text-white/55 text-[14.5px] leading-relaxed font-sans">
            Chaque verticale est une fenêtre dans la même maison.
            Aïma se souvient de toi d'une pièce à l'autre.
          </p>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-5">
          {VERTICALS.map((v, i) => (
            <motion.button
              key={v.slug}
              type="button"
              onClick={() => navigate(`/${v.slug}`)}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{ duration: 0.6, delay: (i % 3) * 0.08, ease: [0.22, 1, 0.36, 1] }}
              whileHover={{ y: -4 }}
              className="group relative text-left rounded-2xl overflow-hidden p-7 md:p-8 min-h-[300px] flex flex-col justify-between transition-shadow"
              style={{
                background: v.bg,
                color: v.fg,
                boxShadow: "0 20px 50px -20px rgba(0,0,0,0.55)"
              }}
            >
              <div>
                <div
                  className="text-[10px] tracking-[0.3em] uppercase font-sans opacity-70"
                  style={{ color: v.fg }}
                >
                  {v.eyebrow}
                </div>
                <h3
                  className="mt-4 font-display uppercase leading-tight"
                  style={{
                    fontSize: "clamp(1.5rem, 2.4vw, 2rem)",
                    letterSpacing: "-0.02em",
                    color: v.fg
                  }}
                >
                  {v.label}
                </h3>
              </div>
              <div>
                <p
                  className="text-[14px] leading-relaxed font-sans mb-6"
                  style={{ color: v.fg, opacity: 0.78 }}
                >
                  {v.body}
                </p>
                <div
                  className="inline-flex items-center gap-2 text-[11px] tracking-[0.25em] uppercase font-sans group-hover:gap-3 transition-all"
                  style={{ color: v.fg }}
                >
                  Entrer <span aria-hidden>→</span>
                </div>
              </div>
            </motion.button>
          ))}
        </div>
      </div>
    </section>
  );
}