import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

/**
 * mintTimbre — émet un Timbre AIME® dans le registre.
 * Génère : code unique, hash SHA-256, n° de registre, horodatage.
 * Vérifie l'unicité du code (ré-essaie en cas de collision).
 */

const ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

function seg(n) {
  let out = "";
  for (let i = 0; i < n; i++) out += ALPHABET[Math.floor(Math.random() * ALPHABET.length)];
  return out;
}

function genCode(first = "A", last = "M") {
  const initials = ((first[0] || "A") + (last[0] || "M")).toUpperCase();
  return `${initials}·${seg(3)}·${seg(4)}`;
}

async function sha256(text) {
  const enc = new TextEncoder().encode(text);
  const buf = await crypto.subtle.digest("SHA-256", enc);
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();

    // Generate unique code (max 5 retries)
    let code;
    for (let i = 0; i < 5; i++) {
      const candidate = genCode(body.first_name, body.last_name);
      const exists = await base44.asServiceRole.entities.Timbre.filter({ code: candidate });
      if (!exists || exists.length === 0) {
        code = candidate;
        break;
      }
    }
    if (!code) {
      return Response.json({ error: "Could not generate unique code" }, { status: 500 });
    }

    // Compute registry number
    const allTimbres = await base44.asServiceRole.entities.Timbre.list("-registry_n", 1);
    const nextN = (allTimbres?.[0]?.registry_n || 0) + 1;

    const issued_at = new Date().toISOString();
    const hashInput = JSON.stringify({
      code,
      name: `${body.first_name} ${body.last_name}`,
      birth_date: body.birth_date,
      issued_at,
      registry_n: nextN
    });
    const hash = await sha256(hashInput);

    // Create timbre with privacy-first defaults
    const timbreData = {
      code,
      registry_n: nextN,
      issued_at,
      issued_city: body.issued_city || "France",
      issued_country: "FR",
      issued_lat: body.issued_lat || null,
      issued_lng: body.issued_lng || null,
      hash,
      portrait_url: body.portrait_url || null,
      first_name: body.first_name,
      last_name: body.last_name,
      birth_date: body.birth_date,
      birth_city: body.birth_city,
      craft: body.craft,
      sector: body.sector,
      music_dna: body.music_dna || [],
      passions: body.passions || [],
      intention: body.intention,
      charter_signed_at: issued_at,
      charter_version: "AIME-2026.1",
      consent_data_processing: !!body.consent_data_processing,
      consent_public_registry: !!body.consent_public_registry,
      consent_matching: !!body.consent_matching,
      consent_communications: !!body.consent_communications,
      visibility: body.consent_public_registry ? "public" : "private",
      anonymous_id: body.anonymous_id || null
    };

    // Try to attach to authenticated user if any
    try {
      const user = await base44.auth.me();
      if (user?.email) timbreData.owner_email = user.email;
    } catch (_) { /* anonymous flow */ }

    const timbre = await base44.asServiceRole.entities.Timbre.create(timbreData);

    return Response.json({
      ok: true,
      timbre,
      message: `Timbre ${code} émis · #${String(nextN).padStart(6, "0")}`
    });
  } catch (error) {
    console.error("mintTimbre error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});