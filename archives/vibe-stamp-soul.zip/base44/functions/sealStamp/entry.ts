import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

/**
 * sealStamp — scelle un Stamp AIME® avec preuve cryptographique.
 *
 * Doctrine : un timbre = une intention humaine, captée par Aïma,
 * scellée dans le temps avec un hash et un code unique.
 * Filiation Soleau-2024 (Signature Vibratoire par Intention™).
 */

const ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

function seg(n) {
  let out = "";
  for (let i = 0; i < n; i++) out += ALPHABET[Math.floor(Math.random() * ALPHABET.length)];
  return out;
}

function genCode(prefix = "AI") {
  const p = (prefix || "AI").slice(0, 2).toUpperCase().padEnd(2, "M");
  return `${p}·${seg(3)}·${seg(4)}`;
}

async function sha256(text) {
  const enc = new TextEncoder().encode(text);
  const buf = await crypto.subtle.digest("SHA-256", enc);
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

function aimaWitnessLine(intention, iso) {
  const d = new Date(iso || Date.now());
  const date = d.toLocaleDateString("fr-FR", { day: "2-digit", month: "long", year: "numeric" });
  const time = d.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
  const trimmed = (intention || "").trim().slice(0, 120);
  return `Le ${date} à ${time}, j'ai reçu cette intention — « ${trimmed} » — et je l'ai scellée dans la lumière. — Aïma`;
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();

    if (!body?.text || !body?.image_url) {
      return Response.json({ error: "text and image_url are required" }, { status: 400 });
    }

    // Generate unique code (max 5 retries)
    const prefix = body.code_prefix || "AI";
    let code;
    for (let i = 0; i < 5; i++) {
      const candidate = genCode(prefix);
      const exists = await base44.asServiceRole.entities.Stamp.filter({ code: candidate });
      if (!exists || exists.length === 0) {
        code = candidate;
        break;
      }
    }
    if (!code) {
      return Response.json({ error: "Could not generate unique code" }, { status: 500 });
    }

    // Compute next registry number
    const lastStamps = await base44.asServiceRole.entities.Stamp.list("-registry_n", 1);
    const nextN = (lastStamps?.[0]?.registry_n || 0) + 1;

    const issued_at = new Date().toISOString();
    const hashInput = JSON.stringify({
      code,
      registry_n: nextN,
      intention_text: body.intention_text || "",
      text: body.text,
      image_url: body.image_url,
      issued_at
    });
    const hash = await sha256(hashInput);

    // Vibration signature (short readable form)
    const vibSeed = JSON.stringify({
      intention: (body.intention_text || "").trim(),
      voice: !!body.voice_url,
      tracks: (body.playlist || []).map((t) => `${t.title}|${t.artist}`).join(";"),
      moment: issued_at.slice(0, 16)
    });
    const vibFull = await sha256(vibSeed);
    const vibration_signature = vibFull.slice(0, 16).match(/.{4}/g).join("·").toUpperCase();

    // Attach to user if authenticated
    let owner_email = null;
    try {
      const user = await base44.auth.me();
      if (user?.email) owner_email = user.email;
    } catch (_) { /* anonymous flow */ }

    const stampData = {
      code,
      registry_n: nextN,
      issued_at,
      issued_city: body.issued_city || "France",
      hash,
      verify_url: `/verify/${encodeURIComponent(code)}`,
      vibration_signature,
      soleau_filiation: "Soleau-2024-SignatureVibratoire",
      aima_signature: aimaWitnessLine(body.intention_text, issued_at),

      text: body.text,
      image_url: body.image_url,
      intention_text: body.intention_text || "",
      ai_description: body.ai_description || body.intention_text || "",
      color: body.color || "encre",
      wear: body.wear ?? 0,
      rotation: body.rotation ?? 0,

      category: body.category || "personnel",
      subcategory: body.subcategory || null,
      doc_type: body.doc_type || "aucun",
      doc_amount: body.doc_amount ?? null,
      doc_reference: body.doc_reference || null,

      person_name: body.person_name || null,
      person_photo_url: body.person_photo_url || null,
      extra_photo_urls: body.extra_photo_urls || [],
      event_name: body.event_name || null,

      voice_url: body.voice_url || null,
      animation_url: body.animation_url || null,
      playlist: body.playlist || [],

      capsule_unlock_date: body.capsule_unlock_date || null,
      capsule_message: body.capsule_message || null,

      founder_acte: !!body.founder_acte,
      owner_email,
      anonymous_id: body.anonymous_id || null
    };

    const stamp = await base44.asServiceRole.entities.Stamp.create(stampData);

    return Response.json({
      ok: true,
      stamp,
      message: `Timbre ${code} scellé · #${String(nextN).padStart(6, "0")}`
    });
  } catch (error) {
    console.error("sealStamp error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});