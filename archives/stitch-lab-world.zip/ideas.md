# StitchLab — Idées de Design

## Approche choisie : "Tissu Numérique Sombre"

**Design Movement :** Neumorphisme Digital Artisanal — mode sombre, inspiré des outils de design professionnels (Figma, Framer, Linear).

**Core Principles :**
1. Sombre et profond — fond #0d0d10 avec des couches de profondeur subtiles
2. Accent violet/teal — gradient signature `violet #8b5cf6 → teal #14b8a6`
3. Typographie mixte — Playfair Display pour les titres, Inter pour le corps
4. Interactivité narrative — chaque section est une étape du voyage

**Color Philosophy :** Noir profond comme toile de fond, violet comme fil conducteur (littéralement), teal comme accent de fraîcheur. L'or (#f59e0b) pour les moments de conversion.

**Layout Paradigm :** Sections pleine hauteur en scroll vertical, alternance gauche/droite pour les démos interactives, grille pixel en fond animée sur le Hero.

**Signature Elements :**
- Grille pixel animée en fond (Hero)
- Barre de progression au scroll
- Dots pulsants sur la carte SAL mondiale

**Interaction Philosophy :** Chaque section révèle une fonctionnalité interactive — scan simulé, génération de patron, slider confetti, canvas pathing, heatmap SAL.

**Animation :** fade-in au scroll (opacity + translateY), pulse sur les dots SAL, scan line animée sur le téléphone, canvas pathing progressif.

**Typography System :** Playfair Display 900 pour H1/H2, Inter 600-800 pour les badges et stats, Inter 400 pour le corps.
