/**
 * StitchLab — ONE PAGE step-by-step vers le SAL Sync mondial
 * Design: Tissu Numérique Sombre — Playfair Display + Inter — Violet/Teal/Or
 */
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import HeroSection from "@/components/sections/HeroSection";
import ScanSection from "@/components/sections/ScanSection";
import AtelierSection from "@/components/sections/AtelierSection";
import PathingSection from "@/components/sections/PathingSection";
import SALSection from "@/components/sections/SALSection";
import FeedSection from "@/components/sections/FeedSection";
import PricingSection from "@/components/sections/PricingSection";

export default function Home() {
  return (
    <div className="min-h-screen" style={{ background: "oklch(0.085 0.005 285)" }}>
      <Navbar />
      <HeroSection />
      <ScanSection />
      <AtelierSection />
      <PathingSection />
      <SALSection />
      <FeedSection />
      <PricingSection />
      <Footer />
    </div>
  );
}
