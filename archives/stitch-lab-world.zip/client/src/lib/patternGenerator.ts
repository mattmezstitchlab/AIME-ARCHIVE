/**
 * Pattern Generator — Real pixel templates for the Atelier IA
 * Each theme/subject has a hand-drawn pixel template that produces recognizable shapes
 * Ported from ThreadFlow concept with proper pixel art templates
 */

import { DMC_FULL_PALETTE, type DmcColor } from './dmcColors';

export interface GeneratedPattern {
  id: string;
  name: string;
  grid: (string | null)[][];
  palette: { dmc: string; hex: string; name: string; count: number; orderIndex: number }[];
  width: number;
  height: number;
  stitchCount: number;
  difficulty: 'facile' | 'intermédiaire' | 'expert';
}

// ─── Pixel Templates (16x16 or 20x20) ─────────────────────────────────────────
// Each template is a 2D array where numbers map to palette indices (0 = empty)

const TEMPLATES: Record<string, { grid: number[][]; name: string }> = {
  rose: {
    name: 'Rose classique',
    grid: [
      [0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0],
      [0,0,0,0,0,1,2,2,1,0,0,0,0,0,0,0],
      [0,0,0,0,1,2,1,1,2,1,0,0,0,0,0,0],
      [0,0,0,1,2,1,2,2,1,2,1,0,0,0,0,0],
      [0,0,1,2,2,2,2,2,2,2,2,1,0,0,0,0],
      [0,0,1,1,2,2,2,2,2,1,1,0,0,0,0,0],
      [0,0,0,1,1,2,2,2,1,1,0,0,0,0,0,0],
      [0,0,0,0,1,1,2,1,1,0,0,0,0,0,0,0],
      [0,0,0,0,0,1,3,1,0,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,3,0,0,0,0,0,0,0,0,0],
      [0,0,0,0,4,0,3,0,4,0,0,0,0,0,0,0],
      [0,0,0,4,4,0,3,0,4,4,0,0,0,0,0,0],
      [0,0,0,0,4,4,3,4,4,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,3,0,0,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,3,0,0,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,3,0,0,0,0,0,0,0,0,0],
    ],
  },
  chat: {
    name: 'Chat assis',
    grid: [
      [0,0,0,1,0,0,0,0,0,0,1,0,0,0,0,0],
      [0,0,1,1,1,0,0,0,0,1,1,1,0,0,0,0],
      [0,0,1,2,1,1,1,1,1,1,2,1,0,0,0,0],
      [0,0,1,1,1,1,1,1,1,1,1,1,0,0,0,0],
      [0,0,1,1,3,1,1,1,3,1,1,1,0,0,0,0],
      [0,0,1,1,1,1,4,1,1,1,1,1,0,0,0,0],
      [0,0,0,1,1,1,1,1,1,1,1,0,0,0,0,0],
      [0,0,0,0,1,1,1,1,1,1,0,0,0,0,0,0],
      [0,0,0,1,1,1,1,1,1,1,1,0,0,0,0,0],
      [0,0,1,1,1,1,1,1,1,1,1,1,0,0,0,0],
      [0,0,1,1,1,1,1,1,1,1,1,1,0,0,0,0],
      [0,0,1,1,1,1,1,1,1,1,1,1,0,0,0,0],
      [0,0,1,1,1,1,1,1,1,1,1,1,0,0,0,0],
      [0,0,1,1,0,0,0,0,0,0,1,1,0,0,0,0],
      [0,0,1,1,0,0,0,0,0,0,1,1,0,0,0,0],
      [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    ],
  },
  papillon: {
    name: 'Papillon',
    grid: [
      [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
      [0,0,1,1,0,0,0,0,0,0,0,1,1,0,0,0],
      [0,1,2,2,1,0,0,0,0,0,1,2,2,1,0,0],
      [1,2,2,3,2,1,0,0,0,1,2,3,2,2,1,0],
      [1,2,3,3,3,2,1,0,1,2,3,3,3,2,1,0],
      [1,2,2,3,2,2,1,4,1,2,2,3,2,2,1,0],
      [0,1,2,2,2,1,0,4,0,1,2,2,2,1,0,0],
      [0,0,1,1,1,0,0,4,0,0,1,1,1,0,0,0],
      [0,0,0,0,0,0,0,4,0,0,0,0,0,0,0,0],
      [0,0,1,1,1,0,0,4,0,0,1,1,1,0,0,0],
      [0,1,2,2,2,1,0,4,0,1,2,2,2,1,0,0],
      [1,2,2,3,2,2,1,4,1,2,2,3,2,2,1,0],
      [1,2,3,3,3,2,1,0,1,2,3,3,3,2,1,0],
      [1,2,2,3,2,1,0,0,0,1,2,3,2,2,1,0],
      [0,1,2,2,1,0,0,0,0,0,1,2,2,1,0,0],
      [0,0,1,1,0,0,0,0,0,0,0,1,1,0,0,0],
    ],
  },
  coeur: {
    name: 'Cœur',
    grid: [
      [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
      [0,0,1,1,1,0,0,0,0,1,1,1,0,0,0,0],
      [0,1,2,2,2,1,0,0,1,2,2,2,1,0,0,0],
      [1,2,2,3,2,2,1,1,2,2,3,2,2,1,0,0],
      [1,2,2,2,2,2,2,2,2,2,2,2,2,1,0,0],
      [1,2,2,2,2,2,2,2,2,2,2,2,2,1,0,0],
      [0,1,2,2,2,2,2,2,2,2,2,2,1,0,0,0],
      [0,0,1,2,2,2,2,2,2,2,2,1,0,0,0,0],
      [0,0,0,1,2,2,2,2,2,2,1,0,0,0,0,0],
      [0,0,0,0,1,2,2,2,2,1,0,0,0,0,0,0],
      [0,0,0,0,0,1,2,2,1,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    ],
  },
  etoile: {
    name: 'Étoile',
    grid: [
      [0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,1,2,1,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,1,2,1,0,0,0,0,0,0,0],
      [0,0,0,0,0,1,2,2,2,1,0,0,0,0,0,0],
      [1,1,1,1,1,2,2,3,2,2,1,1,1,1,1,0],
      [0,1,2,2,2,2,3,3,3,2,2,2,2,1,0,0],
      [0,0,1,2,2,2,2,3,2,2,2,2,1,0,0,0],
      [0,0,0,1,2,2,2,2,2,2,2,1,0,0,0,0],
      [0,0,1,2,2,2,2,3,2,2,2,2,1,0,0,0],
      [0,1,2,2,2,2,3,3,3,2,2,2,2,1,0,0],
      [1,1,1,1,1,2,2,3,2,2,1,1,1,1,1,0],
      [0,0,0,0,0,1,2,2,2,1,0,0,0,0,0,0],
      [0,0,0,0,0,0,1,2,1,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,1,2,1,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0],
    ],
  },
  arbre: {
    name: 'Sapin',
    grid: [
      [0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,1,2,1,0,0,0,0,0,0,0],
      [0,0,0,0,0,1,2,2,2,1,0,0,0,0,0,0],
      [0,0,0,0,1,2,2,2,2,2,1,0,0,0,0,0],
      [0,0,0,0,0,1,2,2,2,1,0,0,0,0,0,0],
      [0,0,0,0,1,2,2,2,2,2,1,0,0,0,0,0],
      [0,0,0,1,2,2,2,2,2,2,2,1,0,0,0,0],
      [0,0,1,2,2,2,2,2,2,2,2,2,1,0,0,0],
      [0,0,0,0,1,2,2,2,2,2,1,0,0,0,0,0],
      [0,0,0,1,2,2,2,2,2,2,2,1,0,0,0,0],
      [0,0,1,2,2,2,2,2,2,2,2,2,1,0,0,0],
      [0,1,2,2,2,2,2,2,2,2,2,2,2,1,0,0],
      [1,2,2,2,2,2,2,2,2,2,2,2,2,2,1,0],
      [0,0,0,0,0,0,3,3,3,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,3,3,3,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,3,3,3,0,0,0,0,0,0,0],
    ],
  },
  maison: {
    name: 'Maison',
    grid: [
      [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0],
      [0,0,0,0,0,1,1,1,1,1,0,0,0,0,0,0],
      [0,0,0,0,1,1,1,1,1,1,1,0,0,0,0,0],
      [0,0,0,1,1,1,1,1,1,1,1,1,0,0,0,0],
      [0,0,1,1,1,1,1,1,1,1,1,1,1,0,0,0],
      [0,0,2,2,2,2,2,2,2,2,2,2,2,0,0,0],
      [0,0,2,2,2,3,3,2,2,2,2,2,2,0,0,0],
      [0,0,2,2,2,3,3,2,2,4,4,2,2,0,0,0],
      [0,0,2,2,2,3,3,2,2,4,4,2,2,0,0,0],
      [0,0,2,2,2,3,3,2,2,4,4,2,2,0,0,0],
      [0,0,2,2,2,3,3,2,2,2,2,2,2,0,0,0],
      [0,0,2,2,2,2,2,2,2,2,2,2,2,0,0,0],
      [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    ],
  },
  ancre: {
    name: 'Ancre marine',
    grid: [
      [0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,1,2,1,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0],
      [0,0,0,0,0,1,1,1,1,1,0,0,0,0,0,0],
      [0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0],
      [0,0,3,0,0,0,0,1,0,0,0,0,3,0,0,0],
      [0,3,0,0,0,0,0,1,0,0,0,0,0,3,0,0],
      [0,3,0,0,0,0,1,1,1,0,0,0,0,3,0,0],
      [0,0,3,0,0,1,1,1,1,1,0,0,3,0,0,0],
      [0,0,0,3,3,0,0,0,0,0,3,3,0,0,0,0],
      [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    ],
  },
  montagne: {
    name: 'Montagne',
    grid: [
      [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,1,3,1,0,0,0,0,0,0,0],
      [0,0,0,0,0,1,3,3,3,1,0,0,0,0,0,0],
      [0,0,0,0,1,2,3,3,2,2,1,0,0,0,0,0],
      [0,0,0,1,2,2,2,2,2,2,2,1,0,0,0,0],
      [0,0,1,2,2,2,2,2,2,2,2,2,1,0,0,0],
      [0,1,2,2,2,2,2,2,2,2,2,2,2,1,0,0],
      [1,2,2,2,2,2,2,2,2,2,2,2,2,2,1,0],
      [4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,0],
      [4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,0],
      [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    ],
  },
  flocon: {
    name: 'Flocon de neige',
    grid: [
      [0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,2,1,2,0,0,0,0,0,0,0],
      [0,0,2,0,0,0,0,1,0,0,0,0,2,0,0,0],
      [0,0,0,2,0,0,2,1,2,0,0,2,0,0,0,0],
      [0,0,0,0,2,0,0,1,0,0,2,0,0,0,0,0],
      [0,0,0,0,0,2,2,1,2,2,0,0,0,0,0,0],
      [0,2,0,2,0,2,1,1,1,2,0,2,0,2,0,0],
      [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0],
      [0,2,0,2,0,2,1,1,1,2,0,2,0,2,0,0],
      [0,0,0,0,0,2,2,1,2,2,0,0,0,0,0,0],
      [0,0,0,0,2,0,0,1,0,0,2,0,0,0,0,0],
      [0,0,0,2,0,0,2,1,2,0,0,2,0,0,0,0],
      [0,0,2,0,0,0,0,1,0,0,0,0,2,0,0,0],
      [0,0,0,0,0,0,2,1,2,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    ],
  },
  soleil: {
    name: 'Soleil',
    grid: [
      [0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0],
      [0,0,0,1,0,0,0,1,0,0,0,1,0,0,0,0],
      [0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0],
      [0,0,0,0,0,2,2,2,2,2,0,0,0,0,0,0],
      [0,0,0,0,2,3,3,3,3,3,2,0,0,0,0,0],
      [0,0,0,2,3,3,3,3,3,3,3,2,0,0,0,0],
      [0,0,0,2,3,3,3,3,3,3,3,2,0,0,0,0],
      [1,1,0,2,3,3,3,3,3,3,3,2,0,1,1,0],
      [0,0,0,2,3,3,3,3,3,3,3,2,0,0,0,0],
      [0,0,0,2,3,3,3,3,3,3,3,2,0,0,0,0],
      [0,0,0,0,2,3,3,3,3,3,2,0,0,0,0,0],
      [0,0,0,0,0,2,2,2,2,2,0,0,0,0,0,0],
      [0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0],
      [0,0,0,1,0,0,0,1,0,0,0,1,0,0,0,0],
      [0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    ],
  },
  oiseau: {
    name: 'Oiseau',
    grid: [
      [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
      [0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0],
      [0,0,0,0,1,2,2,2,1,0,0,0,0,0,0,0],
      [0,0,0,1,2,2,3,2,2,1,0,0,0,0,0,0],
      [4,4,1,2,2,2,2,2,2,2,1,0,0,0,0,0],
      [0,4,4,1,2,2,2,2,2,2,2,1,1,1,0,0],
      [0,0,4,4,1,2,2,2,2,2,2,2,2,1,0,0],
      [0,0,0,4,4,1,2,2,2,2,2,2,1,0,0,0],
      [0,0,0,0,4,4,1,2,2,2,2,1,0,0,0,0],
      [0,0,0,0,0,0,0,1,1,1,1,0,0,0,0,0],
      [0,0,0,0,0,0,0,0,5,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,0,5,5,5,0,0,0,0,0,0],
      [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
      [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    ],
  },
};

// ─── Color Palettes per Theme ──────────────────────────────────────────────────

interface ThemePalette {
  colors: { dmc: string; hex: string; name: string }[];
}

const THEME_PALETTES: Record<string, ThemePalette> = {
  rose: {
    colors: [
      { dmc: '321', hex: '#CC2222', name: 'Rouge cerise' },
      { dmc: '309', hex: '#C03050', name: 'Rose foncé' },
      { dmc: '3345', hex: '#2D5A27', name: 'Vert chasseur foncé' },
      { dmc: '700', hex: '#2A7828', name: 'Vert brillant' },
    ],
  },
  chat: {
    colors: [
      { dmc: '434', hex: '#8B5030', name: 'Marron clair' },
      { dmc: '437', hex: '#D8A870', name: 'Tan clair' },
      { dmc: '310', hex: '#1A1A1A', name: 'Noir' },
      { dmc: '353', hex: '#F8B0A0', name: 'Pêche' },
    ],
  },
  papillon: {
    colors: [
      { dmc: '550', hex: '#4B0082', name: 'Violet très foncé' },
      { dmc: '553', hex: '#9B5AB8', name: 'Violet' },
      { dmc: '211', hex: '#D8B0E8', name: 'Lavande pâle' },
      { dmc: '310', hex: '#1A1A1A', name: 'Noir' },
    ],
  },
  coeur: {
    colors: [
      { dmc: '321', hex: '#CC2222', name: 'Rouge cerise' },
      { dmc: '666', hex: '#E82020', name: 'Rouge vif' },
      { dmc: 'blanc', hex: '#FFFFFF', name: 'Blanc' },
    ],
  },
  etoile: {
    colors: [
      { dmc: '725', hex: '#F8C040', name: 'Topaze moyen' },
      { dmc: '728', hex: '#E8A840', name: 'Topaze' },
      { dmc: '444', hex: '#F8C800', name: 'Citron foncé' },
    ],
  },
  arbre: {
    colors: [
      { dmc: '699', hex: '#1A6020', name: 'Vert foncé' },
      { dmc: '700', hex: '#2A7828', name: 'Vert brillant' },
      { dmc: '433', hex: '#6B3E26', name: 'Marron moyen' },
    ],
  },
  maison: {
    colors: [
      { dmc: '349', hex: '#C82828', name: 'Corail foncé' },
      { dmc: '436', hex: '#C08050', name: 'Tan' },
      { dmc: '311', hex: '#1A3060', name: 'Bleu marine moyen' },
      { dmc: '725', hex: '#F8C040', name: 'Topaze moyen' },
    ],
  },
  ancre: {
    colors: [
      { dmc: '336', hex: '#1A2858', name: 'Bleu marine' },
      { dmc: '666', hex: '#E82020', name: 'Rouge vif' },
      { dmc: '415', hex: '#C8C8C8', name: 'Perle gris' },
    ],
  },
  montagne: {
    colors: [
      { dmc: '413', hex: '#585858', name: 'Étain foncé' },
      { dmc: '317', hex: '#707070', name: 'Étain' },
      { dmc: 'blanc', hex: '#FFFFFF', name: 'Blanc' },
      { dmc: '700', hex: '#2A7828', name: 'Vert brillant' },
    ],
  },
  flocon: {
    colors: [
      { dmc: 'blanc', hex: '#FFFFFF', name: 'Blanc' },
      { dmc: '519', hex: '#70B0D0', name: 'Bleu ciel' },
    ],
  },
  soleil: {
    colors: [
      { dmc: '444', hex: '#F8C800', name: 'Citron foncé' },
      { dmc: '725', hex: '#F8C040', name: 'Topaze moyen' },
      { dmc: '727', hex: '#FFF0A0', name: 'Topaze très clair' },
    ],
  },
  oiseau: {
    colors: [
      { dmc: '336', hex: '#1A2858', name: 'Bleu marine' },
      { dmc: '519', hex: '#70B0D0', name: 'Bleu ciel' },
      { dmc: '310', hex: '#1A1A1A', name: 'Noir' },
      { dmc: '608', hex: '#F06020', name: 'Orange vif' },
      { dmc: '434', hex: '#8B5030', name: 'Marron clair' },
    ],
  },
};

// ─── Theme to Template Mapping ─────────────────────────────────────────────────

const THEME_TEMPLATES: Record<string, string[]> = {
  'Fleurs & Botanique': ['rose', 'arbre'],
  'Animaux & Faune': ['chat', 'papillon', 'oiseau'],
  'Paysages & Nature': ['montagne', 'arbre', 'soleil'],
  'Géométrie & Motifs': ['etoile', 'flocon', 'coeur'],
  'Saisons & Fêtes': ['flocon', 'coeur', 'etoile'],
  'Océan & Maritime': ['ancre'],
  'Nuit & Cosmos': ['etoile', 'flocon'],
};

// ─── Generator Function ────────────────────────────────────────────────────────

export function generatePattern(
  theme: string,
  subTheme?: string,
  style?: string,
): GeneratedPattern {
  // Pick template based on theme
  const templateKeys = THEME_TEMPLATES[theme] || Object.keys(TEMPLATES);
  const templateKey = templateKeys[Math.floor(Math.random() * templateKeys.length)];
  const template = TEMPLATES[templateKey];
  const palette = THEME_PALETTES[templateKey];

  if (!template || !palette) {
    // Fallback to rose
    return generatePattern('Fleurs & Botanique');
  }

  // Build grid with DMC codes
  const grid: (string | null)[][] = [];
  let stitchCount = 0;
  const colorCounts = new Map<string, number>();

  for (let y = 0; y < template.grid.length; y++) {
    const row: (string | null)[] = [];
    for (let x = 0; x < template.grid[y].length; x++) {
      const val = template.grid[y][x];
      if (val === 0) {
        row.push(null);
      } else {
        const colorIdx = Math.min(val - 1, palette.colors.length - 1);
        const color = palette.colors[colorIdx];
        row.push(color.dmc);
        stitchCount++;
        colorCounts.set(color.dmc, (colorCounts.get(color.dmc) || 0) + 1);
      }
    }
    grid.push(row);
  }

  // Build palette with counts and order
  const paletteWithCounts = palette.colors
    .filter(c => colorCounts.has(c.dmc))
    .map((c, idx) => ({
      dmc: c.dmc,
      hex: c.hex,
      name: c.name,
      count: colorCounts.get(c.dmc) || 0,
      orderIndex: idx + 1,
    }))
    .sort((a, b) => b.count - a.count);

  // Determine difficulty
  const difficulty: GeneratedPattern['difficulty'] = 
    paletteWithCounts.length <= 3 ? 'facile' :
    paletteWithCounts.length <= 5 ? 'intermédiaire' : 'expert';

  return {
    id: `pattern-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    name: template.name + (style ? ` — ${style}` : ''),
    grid,
    palette: paletteWithCounts,
    width: template.grid[0]?.length || 16,
    height: template.grid.length,
    stitchCount,
    difficulty,
  };
}

/**
 * Find closest DMC color to a given hex
 */
export function findClosestDMC(hex: string): DmcColor {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);

  let closest = DMC_FULL_PALETTE[0];
  let minDist = Infinity;

  DMC_FULL_PALETTE.forEach((dmc) => {
    const dr = parseInt(dmc.hex.slice(1, 3), 16) - r;
    const dg = parseInt(dmc.hex.slice(3, 5), 16) - g;
    const db = parseInt(dmc.hex.slice(5, 7), 16) - b;
    const dist = dr * dr + dg * dg + db * db;
    if (dist < minDist) {
      minDist = dist;
      closest = dmc;
    }
  });

  return closest;
}
