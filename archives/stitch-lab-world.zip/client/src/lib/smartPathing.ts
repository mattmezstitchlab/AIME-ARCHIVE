/**
 * Smart Pathing™ — Optimal stitch order algorithm
 * Ported from ThreadFlow — nearest-neighbor traversal by color group
 */

export type StitchType =
  | "full"
  | "half_fwd"
  | "half_bwd"
  | "quarter_tl"
  | "quarter_tr"
  | "quarter_bl"
  | "quarter_br"
  | "three_quarter_tl" | "three_quarter_tr" | "three_quarter_bl" | "three_quarter_br"
  | "backstitch_h" | "backstitch_v" | "backstitch_d1" | "backstitch_d2"
  | "french_knot";

export type StitchGroup = "fill" | "three_quarter" | "backstitch" | "french_knot";

export function getStitchGroup(type: StitchType): StitchGroup {
  if (type.startsWith("three_quarter")) return "three_quarter";
  if (type.startsWith("backstitch")) return "backstitch";
  if (type === "french_knot") return "french_knot";
  return "fill";
}

export interface GridCell {
  dmc: string | null;
  hex: string | null;
  done?: boolean;
  stitchType?: StitchType;
}

/**
 * Compute Smart Path order for a single DMC color
 * Uses nearest-neighbor algorithm (Manhattan distance) per stitch group
 */
export function computeSmartPathOrdered(cells: GridCell[][], targetDmc: string): {
  fillPath: [number, number][];
  threeQuarterPath: [number, number][];
  backstitchPath: [number, number][];
  frenchKnotPath: [number, number][];
} {
  const fill: [number, number][] = [];
  const threeQ: [number, number][] = [];
  const bs: [number, number][] = [];
  const fk: [number, number][] = [];

  for (let r = 0; r < cells.length; r++) {
    for (let c = 0; c < (cells[r]?.length ?? 0); c++) {
      const cell = cells[r]?.[c];
      if (!cell || cell.dmc !== targetDmc || cell.done) continue;
      const group = getStitchGroup(cell.stitchType ?? "full");
      if (group === "fill") fill.push([r, c]);
      else if (group === "three_quarter") threeQ.push([r, c]);
      else if (group === "backstitch") bs.push([r, c]);
      else fk.push([r, c]);
    }
  }

  // Nearest-neighbor sort for each group
  const nnSort = (pts: [number, number][]): [number, number][] => {
    if (pts.length === 0) return [];
    const path: [number, number][] = [pts[0]!];
    const remaining = pts.slice(1);
    while (remaining.length > 0) {
      const last = path[path.length - 1]!;
      let minDist = Infinity, minIdx = 0;
      remaining.forEach(([r, c], i) => {
        const dist = Math.abs(r - last[0]) + Math.abs(c - last[1]);
        if (dist < minDist) { minDist = dist; minIdx = i; }
      });
      path.push(remaining[minIdx]!);
      remaining.splice(minIdx, 1);
    }
    return path;
  };

  return {
    fillPath: nnSort(fill),
    threeQuarterPath: nnSort(threeQ),
    backstitchPath: nnSort(bs),
    frenchKnotPath: nnSort(fk),
  };
}

/**
 * Compute full Smart Pathing for all colors in a grid
 * Returns colors sorted by area (largest first) with their optimal paths
 */
export function computeFullSmartPath(cells: GridCell[][]): {
  colorOrder: { dmc: string; hex: string; count: number; orderIndex: number }[];
  paths: Map<string, [number, number][]>;
  stats: { totalStitches: number; colorChanges: number; estimatedSavings: number };
} {
  // Count stitches per color
  const colorCounts = new Map<string, { hex: string; count: number }>();
  
  for (let r = 0; r < cells.length; r++) {
    for (let c = 0; c < (cells[r]?.length ?? 0); c++) {
      const cell = cells[r]?.[c];
      if (!cell || !cell.dmc || cell.done) continue;
      const existing = colorCounts.get(cell.dmc);
      if (existing) {
        existing.count++;
      } else {
        colorCounts.set(cell.dmc, { hex: cell.hex || '#888', count: 1 });
      }
    }
  }

  // Sort colors by count (largest areas first = fewer thread changes)
  const sorted = Array.from(colorCounts.entries())
    .sort((a, b) => b[1].count - a[1].count)
    .map(([dmc, data], idx) => ({
      dmc,
      hex: data.hex,
      count: data.count,
      orderIndex: idx + 1,
    }));

  // Compute path for each color
  const paths = new Map<string, [number, number][]>();
  let totalStitches = 0;

  sorted.forEach(({ dmc }) => {
    const result = computeSmartPathOrdered(cells, dmc);
    const fullPath = [...result.fillPath, ...result.threeQuarterPath, ...result.backstitchPath, ...result.frenchKnotPath];
    paths.set(dmc, fullPath);
    totalStitches += fullPath.length;
  });

  // Estimate savings vs random order
  const colorChanges = sorted.length;
  const randomColorChanges = Math.round(totalStitches * 0.15); // ~15% of stitches would be color changes in random
  const estimatedSavings = Math.round(((randomColorChanges - colorChanges) / randomColorChanges) * 100);

  return {
    colorOrder: sorted,
    paths,
    stats: {
      totalStitches,
      colorChanges,
      estimatedSavings: Math.max(0, estimatedSavings),
    },
  };
}

/**
 * Generate demo data for Smart Pathing visualization
 * Creates a small pattern with multiple colors and computes optimal order
 */
export function generateSmartPathDemoData(): {
  grid: GridCell[][];
  colorOrder: { dmc: string; hex: string; name: string; count: number; orderIndex: number }[];
  totalStitches: number;
  randomDistance: number;
  optimizedDistance: number;
  savings: string;
} {
  const size = 16;
  const grid: GridCell[][] = Array(size).fill(null).map(() => 
    Array(size).fill(null).map(() => ({ dmc: null, hex: null }))
  );

  // Define a small flower pattern
  const colors = [
    { dmc: '321', hex: '#CC2222', name: 'Rouge cerise' },
    { dmc: '700', hex: '#2A7828', name: 'Vert brillant' },
    { dmc: '725', hex: '#F8C040', name: 'Topaze moyen' },
    { dmc: '550', hex: '#4B0082', name: 'Violet très foncé' },
    { dmc: 'blanc', hex: '#FFFFFF', name: 'Blanc' },
  ];

  // Flower petals (red)
  const petals = [
    [5,7],[5,8],[6,6],[6,7],[6,8],[6,9],[7,5],[7,6],[7,9],[7,10],
    [8,5],[8,6],[8,9],[8,10],[9,6],[9,7],[9,8],[9,9],[10,7],[10,8],
  ];
  petals.forEach(([r,c]) => { grid[r][c] = { dmc: '321', hex: '#CC2222' }; });

  // Center (yellow)
  const center = [[7,7],[7,8],[8,7],[8,8]];
  center.forEach(([r,c]) => { grid[r][c] = { dmc: '725', hex: '#F8C040' }; });

  // Stem (green)
  const stem = [[11,7],[11,8],[12,7],[12,8],[13,7],[13,8],[14,7]];
  stem.forEach(([r,c]) => { grid[r][c] = { dmc: '700', hex: '#2A7828' }; });

  // Leaves (green)
  const leaves = [[11,5],[11,6],[12,5],[11,9],[11,10],[12,10]];
  leaves.forEach(([r,c]) => { grid[r][c] = { dmc: '700', hex: '#2A7828' }; });

  // Small dots (violet)
  const dots = [[4,7],[4,8],[5,5],[5,10],[10,5],[10,10]];
  dots.forEach(([r,c]) => { grid[r][c] = { dmc: '550', hex: '#4B0082' }; });

  // Compute smart path
  const result = computeFullSmartPath(grid);

  // Calculate random vs optimized distance
  let optimizedDist = 0;
  result.paths.forEach((path) => {
    for (let i = 1; i < path.length; i++) {
      optimizedDist += Math.abs(path[i][0] - path[i-1][0]) + Math.abs(path[i][1] - path[i-1][1]);
    }
  });

  // Random distance estimate (avg Manhattan distance in a 16x16 grid)
  const randomDist = Math.round(optimizedDist * 2.6);
  const savings = `-${Math.round(((randomDist - optimizedDist) / randomDist) * 100)}%`;

  return {
    grid,
    colorOrder: result.colorOrder.map(c => ({
      ...c,
      name: colors.find(col => col.dmc === c.dmc)?.name || c.dmc,
    })),
    totalStitches: result.stats.totalStitches,
    randomDistance: randomDist,
    optimizedDistance: optimizedDist,
    savings,
  };
}
