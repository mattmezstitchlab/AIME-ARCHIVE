/**
 * StitchLab Pattern Engine
 * Génère de vraies grilles pixel brodables avec des formes reconnaissables.
 * Chaque "template" est une forme dessinée pixel par pixel, puis colorisée
 * avec la palette DMC choisie et adaptée à la taille de grille.
 */

export type PatternCell = { colorIdx: number; isEmpty: boolean };
export type PatternGrid = PatternCell[][];

// ─── Formes de base (normalisées 0..1) ────────────────────────
// Chaque forme retourne une valeur 0..N (index de "couche/couleur")
// pour chaque cellule (x,y) normalisée dans [0,1]

type ShapeFn = (x: number, y: number, seed: number) => number;

// ── Fleur à 6 pétales ──
const flowerShape: ShapeFn = (x, y, seed) => {
  const cx = x - 0.5, cy = y - 0.5;
  const r = Math.sqrt(cx * cx + cy * cy);
  const angle = Math.atan2(cy, cx);
  const petals = 6;
  const petalR = 0.28 + 0.05 * Math.sin(petals * angle + seed * 0.1);
  if (r < 0.08) return 3; // cœur
  if (r < petalR) return 2; // pétale
  if (r < petalR + 0.06) return 1; // contour pétale
  // tige
  if (Math.abs(cx) < 0.04 && cy > 0.1) return 4;
  // feuilles
  const leafAngle = Math.abs(Math.sin(angle * 2));
  if (r > 0.3 && r < 0.42 && leafAngle > 0.7) return 5;
  return 0; // fond
};

// ── Rose (5 pétales asymétriques) ──
const roseShape: ShapeFn = (x, y, seed) => {
  const cx = x - 0.5, cy = y - 0.5;
  const r = Math.sqrt(cx * cx + cy * cy);
  const angle = Math.atan2(cy, cx);
  const roseR = 0.35 * Math.abs(Math.cos(2.5 * angle + seed * 0.05));
  if (r < 0.07) return 3;
  if (r < roseR * 0.6) return 2;
  if (r < roseR) return 1;
  if (r < roseR + 0.04) return 4;
  if (Math.abs(cx) < 0.04 && cy > 0.15) return 5;
  return 0;
};

// ── Papillon ──
const butterflyShape: ShapeFn = (x, y, _seed) => {
  const cx = x - 0.5, cy = y - 0.5;
  // Aile gauche
  const lx = cx + 0.18, ly = cy + 0.05;
  const lr = Math.sqrt(lx * lx + ly * ly * 1.6);
  // Aile droite
  const rx = cx - 0.18, ry = cy + 0.05;
  const rr = Math.sqrt(rx * rx + ry * ry * 1.6);
  // Corps
  const body = Math.sqrt(cx * cx * 6 + cy * cy * 0.8);
  if (body < 0.12) return 4;
  if (lr < 0.22) return lr < 0.14 ? 2 : 1;
  if (rr < 0.22) return rr < 0.14 ? 3 : 1;
  // Antennes
  if (Math.abs(cx - cy * 0.4) < 0.025 && cy < -0.2) return 4;
  if (Math.abs(cx + cy * 0.4) < 0.025 && cy < -0.2) return 4;
  return 0;
};

// ── Mandala géométrique ──
const mandalaShape: ShapeFn = (x, y, seed) => {
  const cx = x - 0.5, cy = y - 0.5;
  const r = Math.sqrt(cx * cx + cy * cy);
  const angle = Math.atan2(cy, cx);
  const sym = 8;
  const wave = Math.abs(Math.sin(sym * angle + seed * 0.2));
  if (r < 0.06) return 4;
  if (r < 0.12) return 3;
  if (r < 0.20 && wave > 0.5) return 2;
  if (r < 0.28) return wave > 0.6 ? 1 : 0;
  if (r < 0.36 && wave > 0.4) return 3;
  if (r < 0.44 && wave > 0.7) return 2;
  return 0;
};

// ── Renard (silhouette stylisée) ──
const foxShape: ShapeFn = (x, y, _seed) => {
  const cx = x - 0.5, cy = y - 0.5;
  // Corps
  const bodyR = Math.sqrt(cx * cx * 1.2 + (cy - 0.1) * (cy - 0.1) * 2);
  // Tête
  const headR = Math.sqrt(cx * cx + (cy + 0.2) * (cy + 0.2));
  // Oreilles
  const earL = Math.sqrt((cx + 0.18) * (cx + 0.18) * 2 + (cy + 0.38) * (cy + 0.38) * 3);
  const earR = Math.sqrt((cx - 0.18) * (cx - 0.18) * 2 + (cy + 0.38) * (cy + 0.38) * 3);
  // Queue
  const tailX = cx - 0.3, tailY = cy - 0.05;
  const tailR = Math.sqrt(tailX * tailX * 0.8 + tailY * tailY * 1.5);
  // Museau
  const snoutR = Math.sqrt(cx * cx * 3 + (cy + 0.35) * (cy + 0.35) * 4);
  // Yeux
  const eyeL = Math.sqrt((cx + 0.12) * (cx + 0.12) * 8 + (cy + 0.18) * (cy + 0.18) * 8);
  const eyeR = Math.sqrt((cx - 0.12) * (cx - 0.12) * 8 + (cy + 0.18) * (cy + 0.18) * 8);

  if (eyeL < 0.06 || eyeR < 0.06) return 5; // yeux
  if (snoutR < 0.12) return 3; // museau blanc
  if (earL < 0.14 || earR < 0.14) return 2; // oreilles
  if (headR < 0.22) return 1; // tête
  if (bodyR < 0.28) return 1; // corps
  if (tailR < 0.18) return 4; // queue
  return 0;
};

// ── Chat ──
const catShape: ShapeFn = (x, y, _seed) => {
  const cx = x - 0.5, cy = y - 0.5;
  const headR = Math.sqrt(cx * cx + (cy + 0.1) * (cy + 0.1));
  const bodyR = Math.sqrt(cx * cx * 0.8 + (cy - 0.22) * (cy - 0.22) * 1.5);
  const earL = Math.sqrt((cx + 0.2) * (cx + 0.2) * 3 + (cy + 0.35) * (cy + 0.35) * 4);
  const earR = Math.sqrt((cx - 0.2) * (cx - 0.2) * 3 + (cy + 0.35) * (cy + 0.35) * 4);
  const eyeL = Math.sqrt((cx + 0.13) * (cx + 0.13) * 10 + (cy + 0.08) * (cy + 0.08) * 10);
  const eyeR = Math.sqrt((cx - 0.13) * (cx - 0.13) * 10 + (cy + 0.08) * (cy + 0.08) * 10);
  const nose = Math.sqrt(cx * cx * 20 + (cy + 0.22) * (cy + 0.22) * 20);
  // Queue
  const tailAngle = Math.atan2(cy - 0.3, cx - 0.35);
  const tailDist = Math.sqrt((cx - 0.35) * (cx - 0.35) + (cy - 0.3) * (cy - 0.3));
  const onTail = tailDist < 0.22 && tailDist > 0.08 && Math.abs(tailAngle) < 1.2;

  if (nose < 0.06) return 4;
  if (eyeL < 0.07 || eyeR < 0.07) return 5;
  if (earL < 0.13 || earR < 0.13) return 2;
  if (headR < 0.26) return 1;
  if (bodyR < 0.22) return 1;
  if (onTail) return 3;
  return 0;
};

// ── Oiseau ──
const birdShape: ShapeFn = (x, y, _seed) => {
  const cx = x - 0.5, cy = y - 0.5;
  // Corps
  const bodyR = Math.sqrt(cx * cx * 1.8 + (cy + 0.05) * (cy + 0.05) * 2.5);
  // Tête
  const headR = Math.sqrt((cx - 0.2) * (cx - 0.2) + (cy + 0.18) * (cy + 0.18));
  // Aile
  const wingR = Math.sqrt(cx * cx * 0.7 + (cy - 0.05) * (cy - 0.05) * 3);
  // Bec
  const beak = Math.sqrt((cx - 0.38) * (cx - 0.38) * 5 + (cy + 0.18) * (cy + 0.18) * 8);
  // Œil
  const eye = Math.sqrt((cx - 0.22) * (cx - 0.22) * 15 + (cy + 0.22) * (cy + 0.22) * 15);
  // Queue
  const tailR = Math.sqrt((cx + 0.3) * (cx + 0.3) * 2 + cy * cy * 0.8);

  if (eye < 0.05) return 5;
  if (beak < 0.09) return 4;
  if (headR < 0.14) return 1;
  if (bodyR < 0.18) return 1;
  if (wingR < 0.22) return 2;
  if (tailR < 0.16) return 3;
  return 0;
};

// ── Paysage montagne ──
const mountainShape: ShapeFn = (x, y, seed) => {
  // Ciel
  if (y < 0.35) {
    // Soleil
    const sx = 0.75, sy = 0.18;
    const sr = Math.sqrt((x - sx) * (x - sx) + (y - sy) * (y - sy));
    if (sr < 0.07) return 4;
    if (sr < 0.10) return 3;
    return 0; // ciel
  }
  // Montagnes
  const m1 = Math.abs(x - 0.3) * 1.8;
  const m2 = Math.abs(x - 0.65) * 1.5;
  const m3 = Math.abs(x - 0.5) * 2.2;
  const mountainLine = Math.min(m1, m2, m3) * 0.6 + 0.35;
  if (y < mountainLine) {
    // Neige
    if (y < mountainLine - 0.08) return 5;
    return 2; // roche
  }
  // Forêt
  const treeH = 0.55 + 0.05 * Math.sin(x * 20 + seed);
  if (y < treeH) return 1;
  // Sol
  return 6;
};

// ── Géométrie (losanges) ──
const geoShape: ShapeFn = (x, y, seed) => {
  const gx = (x * 8 + seed * 0.3) % 1;
  const gy = (y * 8 + seed * 0.2) % 1;
  const d = Math.abs(gx - 0.5) + Math.abs(gy - 0.5);
  if (d < 0.15) return 3;
  if (d < 0.25) return 2;
  if (d < 0.38) return 1;
  return 0;
};

// ── Étoile de mer / Mandala marin ──
const seaShape: ShapeFn = (x, y, seed) => {
  const cx = x - 0.5, cy = y - 0.5;
  const r = Math.sqrt(cx * cx + cy * cy);
  const angle = Math.atan2(cy, cx);
  const arms = 5;
  const star = 0.3 * (0.5 + 0.5 * Math.cos(arms * angle + seed * 0.1));
  if (r < 0.06) return 4;
  if (r < star * 0.7) return 2;
  if (r < star) return 1;
  // Vagues de fond
  const wave = Math.sin(x * 12 + seed) * 0.03;
  if (Math.abs(y - 0.7 + wave) < 0.04) return 3;
  if (Math.abs(y - 0.8 + wave * 0.5) < 0.03) return 3;
  return 0;
};

// ─── Registre des formes par mot-clé ──────────────────────────
const SHAPE_REGISTRY: { keywords: string[]; fn: ShapeFn; name: string }[] = [
  { keywords: ["fleur", "floral", "botanique", "flower", "rose", "tulipe", "marguerite", "pivoine"], fn: flowerShape, name: "Fleur" },
  { keywords: ["rose", "pivoine", "pétal"], fn: roseShape, name: "Rose" },
  { keywords: ["papillon", "butterfly", "insecte"], fn: butterflyShape, name: "Papillon" },
  { keywords: ["mandala", "géo", "géométrique", "symétrique", "cercle", "geometric"], fn: mandalaShape, name: "Mandala" },
  { keywords: ["renard", "fox", "animal", "folk"], fn: foxShape, name: "Renard" },
  { keywords: ["chat", "cat", "chaton", "félin"], fn: catShape, name: "Chat" },
  { keywords: ["oiseau", "bird", "colibri", "moineau", "hirondelle"], fn: birdShape, name: "Oiseau" },
  { keywords: ["montagne", "paysage", "forêt", "nature", "landscape", "alpes", "neige"], fn: mountainShape, name: "Paysage" },
  { keywords: ["losange", "diamant", "pattern", "motif", "carreaux", "géo"], fn: geoShape, name: "Géométrie" },
  { keywords: ["mer", "marin", "océan", "étoile", "poisson", "vague", "sea"], fn: seaShape, name: "Marin" },
];

function detectShape(prompt: string, seed: number): { fn: ShapeFn; name: string } {
  const lower = prompt.toLowerCase();
  for (const entry of SHAPE_REGISTRY) {
    if (entry.keywords.some((k) => lower.includes(k))) {
      return { fn: entry.fn, name: entry.name };
    }
  }
  // Fallback basé sur le seed
  const idx = Math.floor(seed * 13) % SHAPE_REGISTRY.length;
  return SHAPE_REGISTRY[idx];
}

// ─── Palette DMC par thème ────────────────────────────────────
const THEME_PALETTES: Record<string, { hex: string; code: string; name: string; points: number }[]> = {
  floral: [
    { hex: "#1a1a2e", code: "fond",  name: "Fond",      points: 0 },
    { hex: "#C62D42", code: "321",   name: "Rouge",     points: 0 },
    { hex: "#E8475F", code: "350",   name: "Corail",    points: 0 },
    { hex: "#F4A7B9", code: "3716",  name: "Rose pâle", points: 0 },
    { hex: "#F5C518", code: "726",   name: "Or",        points: 0 },
    { hex: "#3CB371", code: "911",   name: "Vert",      points: 0 },
    { hex: "#F0EAD6", code: "blanc", name: "Blanc",     points: 0 },
  ],
  nature: [
    { hex: "#1a2e1a", code: "fond",  name: "Fond",        points: 0 },
    { hex: "#228B22", code: "895",   name: "Vert foncé",  points: 0 },
    { hex: "#3CB371", code: "911",   name: "Vert",        points: 0 },
    { hex: "#7FC97F", code: "913",   name: "Vert clair",  points: 0 },
    { hex: "#8B4513", code: "433",   name: "Brun",        points: 0 },
    { hex: "#F5C518", code: "726",   name: "Or",          points: 0 },
    { hex: "#6699CC", code: "517",   name: "Bleu ciel",   points: 0 },
    { hex: "#F0EAD6", code: "blanc", name: "Blanc",       points: 0 },
  ],
  animal: [
    { hex: "#1a1a1a", code: "fond",  name: "Fond",  points: 0 },
    { hex: "#C62D42", code: "321",   name: "Roux",  points: 0 },
    { hex: "#D4956A", code: "402",   name: "Pêche", points: 0 },
    { hex: "#F0EAD6", code: "blanc", name: "Blanc", points: 0 },
    { hex: "#5C4033", code: "433",   name: "Brun",  points: 0 },
    { hex: "#1a1a1a", code: "3799",  name: "Noir",  points: 0 },
  ],
  geo: [
    { hex: "#0d0d1a", code: "fond",  name: "Fond",   points: 0 },
    { hex: "#8B5CF6", code: "553",   name: "Violet", points: 0 },
    { hex: "#14B8A6", code: "3844",  name: "Teal",   points: 0 },
    { hex: "#F5C518", code: "726",   name: "Or",     points: 0 },
    { hex: "#F0EAD6", code: "blanc", name: "Blanc",  points: 0 },
  ],
  sea: [
    { hex: "#0a1628", code: "fond",  name: "Fond",        points: 0 },
    { hex: "#1B6B7B", code: "3765",  name: "Teal foncé",  points: 0 },
    { hex: "#14B8A6", code: "3844",  name: "Turquoise",   points: 0 },
    { hex: "#C0E8F0", code: "747",   name: "Bleu pâle",   points: 0 },
    { hex: "#F5C518", code: "726",   name: "Or",          points: 0 },
    { hex: "#F0EAD6", code: "blanc", name: "Blanc",       points: 0 },
  ],
};

function detectPalette(prompt: string, shapeName: string) {
  const lower = (prompt + " " + shapeName).toLowerCase();
  if (/mer|marin|océan|sea|vague|poisson/.test(lower)) return THEME_PALETTES.sea;
  if (/géo|mandala|losange|symétrique|geo/.test(lower)) return THEME_PALETTES.geo;
  if (/renard|chat|oiseau|papillon|animal|fox|cat|bird/.test(lower)) return THEME_PALETTES.animal;
  if (/montagne|forêt|paysage|nature|landscape/.test(lower)) return THEME_PALETTES.nature;
  return THEME_PALETTES.floral;
};

// ─── Générateur principal ─────────────────────────────────────
export interface GeneratedPattern {
  grid: number[][];       // index de couleur (0 = fond)
  palette: { hex: string; code: string; name: string; points: number }[];
  shapeName: string;
  size: number;
  confetti: number;
  changes: number;
  score: number;
}

export function generatePattern(
  prompt: string,
  size: number,
  seed: number
): GeneratedPattern {
  const { fn: shapeFn, name: shapeName } = detectShape(prompt, seed);
  const palette = detectPalette(prompt, shapeName);

  const grid: number[][] = [];
  let confetti = 0;
  let changes = 0;
  let prev = -1;

  for (let r = 0; r < size; r++) {
    grid[r] = [];
    for (let c = 0; c < size; c++) {
      const nx = c / (size - 1);
      const ny = r / (size - 1);
      // Légère variation de seed par position pour éviter la symétrie parfaite
      const localSeed = seed + nx * 0.1 + ny * 0.07;
      const raw = shapeFn(nx, ny, localSeed);
      const colorIdx = Math.min(Math.round(raw), palette.length - 1);
      grid[r][c] = colorIdx;

      // Compter confetti (pixel isolé différent de ses voisins)
      if (r > 0 && c > 0) {
        const top = grid[r - 1][c];
        const left = grid[r][c - 1];
        if (colorIdx !== top && colorIdx !== left && colorIdx !== 0) confetti++;
        if (colorIdx !== prev) changes++;
      }
      prev = colorIdx;
    }
  }

  // Score brodabilité : pénalise les confetti et les changements excessifs
  const totalCells = size * size;
  const confettiRatio = confetti / totalCells;
  const changeRatio = changes / totalCells;
  const score = Math.max(30, Math.min(98, Math.round(100 - confettiRatio * 80 - changeRatio * 30)));
  // Calculer les points par couleur
  const pointsCount = new Array(palette.length).fill(0);
  for (let r = 0; r < size; r++)
    for (let c = 0; c < size; c++)
      pointsCount[grid[r][c]]++;
  const paletteWithPoints = palette.map((col, i) => ({ ...col, points: pointsCount[i] ?? 0 }));
  return { grid, palette: paletteWithPoints, shapeName, size, confetti, changes, score };;
}

// ─── Rendu canvas ─────────────────────────────────────────────
export function renderPatternToCanvas(
  canvas: HTMLCanvasElement,
  grid: number[][],
  palette: { hex: string }[],
  size: number,
  showGrid = true,
  revealPct = 1.0  // 0..1 pour timelapse
) {
  const ctx = canvas.getContext("2d")!;
  const W = canvas.width;
  const H = canvas.height;
  const CELL = W / size;
  ctx.clearRect(0, 0, W, H);

  // Fond Aida
  ctx.fillStyle = "#1a1a2e";
  ctx.fillRect(0, 0, W, H);

  // Grille Aida subtile
  if (showGrid) {
    ctx.strokeStyle = "rgba(255,255,255,0.06)";
    ctx.lineWidth = 0.5;
    for (let i = 0; i <= size; i++) {
      ctx.beginPath(); ctx.moveTo(i * CELL, 0); ctx.lineTo(i * CELL, H); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(0, i * CELL); ctx.lineTo(W, i * CELL); ctx.stroke();
    }
  }

  const totalCells = size * size;
  const revealCount = Math.floor(totalCells * revealPct);
  let drawn = 0;

  for (let r = 0; r < size; r++) {
    for (let c = 0; c < size; c++) {
      if (drawn >= revealCount) break;
      const colorIdx = grid[r][c];
      if (colorIdx === 0) { drawn++; continue; } // fond transparent
      const color = palette[colorIdx]?.hex || "#888";
      ctx.fillStyle = color;
      ctx.globalAlpha = 0.90;
      // Effet texture broderie : léger arrondi
      const x = c * CELL + 1;
      const y = r * CELL + 1;
      const w = CELL - 2;
      const h = CELL - 2;
      ctx.beginPath();
      ctx.roundRect(x, y, w, h, Math.max(0.5, CELL * 0.15));
      ctx.fill();
      drawn++;
    }
    if (drawn >= revealCount) break;
  }
  ctx.globalAlpha = 1;
}

// ─── Keyword Taxonomy (cascade thème → sous-thème → style) ───────────────
export interface KeywordNode {
  label: string;
  emoji: string;
  palette: string;
  children: Record<string, {
    label: string;
    emoji: string;
    styles: string[];
    keywords: string[];
  }>;
}

export const KEYWORD_TREE: Record<string, KeywordNode> = {
  fleurs: {
    label: "Fleurs & Botanique",
    emoji: "🌸",
    palette: "floral",
    children: {
      rose:      { label: "Rose",            emoji: "🌹", styles: ["Réaliste", "Folk Art", "Minimaliste", "Aquarelle pixel", "Art Nouveau"], keywords: ["rose", "roses"] },
      pivoine:   { label: "Pivoine",          emoji: "🌺", styles: ["Pleine floraison", "Bouton", "Japonais", "Romantique", "Vintage"], keywords: ["pivoine", "pivoines"] },
      marguerite:{ label: "Marguerite",       emoji: "🌼", styles: ["Champêtre", "Géométrique", "Scandinave", "Vintage", "Minimaliste"], keywords: ["marguerite", "marguerites", "daisy"] },
      tulipe:    { label: "Tulipe",           emoji: "🌷", styles: ["Hollandais", "Moderne", "Stylisé", "Printanier", "Folk"], keywords: ["tulipe", "tulipes"] },
      lavande:   { label: "Lavande",          emoji: "💜", styles: ["Provençal", "Bouquet", "Champ", "Aquarelle", "Minimaliste"], keywords: ["lavande", "lavender"] },
      cerisier:  { label: "Cerisier Sakura",  emoji: "🌸", styles: ["Japonais", "Branche", "Pétales tombants", "Zen", "Aquarelle"], keywords: ["cerisier", "sakura", "cherry"] },
      tournesol: { label: "Tournesol",        emoji: "🌻", styles: ["Réaliste", "Folk Art", "Géométrique", "Vintage", "Moderne"], keywords: ["tournesol", "sunflower"] },
      coquelicot:{ label: "Coquelicot",       emoji: "🌹", styles: ["Champêtre", "Réaliste", "Minimaliste", "Vintage", "Folk"], keywords: ["coquelicot", "poppy"] },
    },
  },
  animaux: {
    label: "Animaux & Faune",
    emoji: "🦊",
    palette: "animal",
    children: {
      chat:      { label: "Chat",             emoji: "🐱", styles: ["Mignon chibi", "Réaliste", "Folk Art", "Géométrique", "Japonais"], keywords: ["chat", "chaton", "cat", "kitten"] },
      renard:    { label: "Renard",           emoji: "🦊", styles: ["Folk Art", "Forêt", "Minimaliste", "Japonais", "Géométrique"], keywords: ["renard", "fox"] },
      papillon:  { label: "Papillon",         emoji: "🦋", styles: ["Réaliste", "Symétrique", "Aquarelle", "Géométrique", "Folk"], keywords: ["papillon", "butterfly"] },
      oiseau:    { label: "Oiseau",           emoji: "🐦", styles: ["Colibri", "Mésange", "Perroquet", "Silhouette", "Folk Art"], keywords: ["oiseau", "bird", "colibri", "mésange"] },
      lapin:     { label: "Lapin",            emoji: "🐰", styles: ["Mignon", "Folk Art", "Forêt", "Pastel", "Géométrique"], keywords: ["lapin", "rabbit", "bunny"] },
      cerf:      { label: "Cerf",             emoji: "🦌", styles: ["Silhouette", "Forêt", "Scandinave", "Géométrique", "Folk"], keywords: ["cerf", "deer"] },
      hibou:     { label: "Hibou / Chouette", emoji: "🦉", styles: ["Folk Art", "Géométrique", "Mignon", "Scandinave", "Réaliste"], keywords: ["hibou", "chouette", "owl"] },
      abeille:   { label: "Abeille",          emoji: "🐝", styles: ["Folk Art", "Réaliste", "Géométrique", "Vintage", "Mignon"], keywords: ["abeille", "bee", "honey"] },
    },
  },
  paysages: {
    label: "Paysages & Nature",
    emoji: "🏔️",
    palette: "nature",
    children: {
      montagne:  { label: "Montagne",         emoji: "🏔️", styles: ["Japonais", "Minimaliste", "Coucher soleil", "Hiver", "Scandinave"], keywords: ["montagne", "mountain", "alpes", "sommet"] },
      foret:     { label: "Forêt",            emoji: "🌲", styles: ["Enchantée", "Automne", "Scandinave", "Nuit", "Printanière"], keywords: ["forêt", "forest", "arbres", "bois"] },
      ocean:     { label: "Océan & Mer",      emoji: "🌊", styles: ["Vagues", "Coucher soleil", "Tropical", "Minimaliste", "Japonais"], keywords: ["océan", "mer", "vagues", "sea", "ocean"] },
      jardin:    { label: "Jardin secret",    emoji: "🌿", styles: ["Anglais", "Japonais", "Provençal", "Féerique", "Cottage"], keywords: ["jardin", "garden"] },
      campagne:  { label: "Campagne",         emoji: "🌾", styles: ["Française", "Cottage", "Printanière", "Automne", "Vintage"], keywords: ["campagne", "countryside", "champs"] },
      cascade:   { label: "Cascade & Rivière",emoji: "💧", styles: ["Japonais", "Zen", "Minimaliste", "Réaliste", "Folk"], keywords: ["cascade", "rivière", "waterfall", "river"] },
    },
  },
  geometrie: {
    label: "Géométrie & Motifs",
    emoji: "◆",
    palette: "geo",
    children: {
      mandala:   { label: "Mandala",          emoji: "◉", styles: ["Symétrique", "Floral", "Celtique", "Moderne", "Indien"], keywords: ["mandala"] },
      chevron:   { label: "Chevron & Zigzag", emoji: "〈〉", styles: ["Classique", "Coloré", "Monochrome", "Art déco", "Scandinave"], keywords: ["chevron", "zigzag"] },
      losange:   { label: "Losanges",         emoji: "◇", styles: ["Scandinave", "Aztèque", "Folk", "Géométrique", "Vintage"], keywords: ["losange", "diamond", "argyle"] },
      hexagone:  { label: "Hexagones",        emoji: "⬡", styles: ["Nid d'abeille", "Coloré", "Monochrome", "Moderne", "Nature"], keywords: ["hexagone", "honeycomb"] },
      etoile:    { label: "Étoiles",          emoji: "★", styles: ["Noël", "Nuit", "Folk Art", "Géométrique", "Scandinave"], keywords: ["étoile", "star"] },
      celtic:    { label: "Nœud celtique",    emoji: "☘", styles: ["Traditionnel", "Moderne", "Entrelacs", "Irlandais", "Minimaliste"], keywords: ["celtique", "celtic", "nœud"] },
    },
  },
  saisons: {
    label: "Saisons & Fêtes",
    emoji: "🍂",
    palette: "floral",
    children: {
      noel:      { label: "Noël",             emoji: "🎄", styles: ["Traditionnel", "Scandinave", "Moderne", "Vintage", "Mignon"], keywords: ["noël", "christmas", "noel"] },
      halloween: { label: "Halloween",        emoji: "🎃", styles: ["Citrouille", "Fantôme", "Sorcière", "Mignon", "Vintage"], keywords: ["halloween", "citrouille", "sorcière"] },
      printemps: { label: "Printemps",        emoji: "🌱", styles: ["Floral", "Pastel", "Pâques", "Renouveau", "Folk"], keywords: ["printemps", "spring", "pâques"] },
      hiver:     { label: "Hiver & Neige",    emoji: "❄️", styles: ["Flocon", "Scandinave", "Polaire", "Minimaliste", "Folk"], keywords: ["hiver", "neige", "winter", "snow"] },
      automne:   { label: "Automne",          emoji: "🍁", styles: ["Feuilles", "Citrouille", "Forêt", "Chaud", "Folk"], keywords: ["automne", "autumn", "fall"] },
      ete:       { label: "Été & Soleil",     emoji: "☀️", styles: ["Tropical", "Plage", "Coloré", "Folk", "Minimaliste"], keywords: ["été", "summer", "soleil", "plage"] },
    },
  },
  ocean_theme: {
    label: "Océan & Maritime",
    emoji: "🌊",
    palette: "sea",
    children: {
      baleine:   { label: "Baleine",          emoji: "🐋", styles: ["Minimaliste", "Folk Art", "Géométrique", "Vintage", "Mignon"], keywords: ["baleine", "whale"] },
      pieuvre:   { label: "Pieuvre",          emoji: "🐙", styles: ["Réaliste", "Stylisé", "Art Nouveau", "Mignon", "Folk"], keywords: ["pieuvre", "octopus"] },
      coquillage:{ label: "Coquillage",       emoji: "🐚", styles: ["Réaliste", "Géométrique", "Vintage", "Aquarelle", "Folk"], keywords: ["coquillage", "shell"] },
      phare:     { label: "Phare",            emoji: "🗼", styles: ["Classique", "Minimaliste", "Coucher soleil", "Vintage", "Folk"], keywords: ["phare", "lighthouse"] },
      ancre:     { label: "Ancre",            emoji: "⚓", styles: ["Nautique", "Vintage", "Minimaliste", "Folk", "Moderne"], keywords: ["ancre", "anchor"] },
      dauphin:   { label: "Dauphin",          emoji: "🐬", styles: ["Réaliste", "Stylisé", "Mignon", "Folk", "Géométrique"], keywords: ["dauphin", "dolphin"] },
    },
  },
  nuit: {
    label: "Nuit & Cosmos",
    emoji: "🌙",
    palette: "geo",
    children: {
      lune:      { label: "Lune",             emoji: "🌙", styles: ["Croissant", "Pleine lune", "Céleste", "Mystique", "Minimaliste"], keywords: ["lune", "moon"] },
      etoiles:   { label: "Étoiles & Galaxie",emoji: "✨", styles: ["Voie lactée", "Constellation", "Nébuleuse", "Minimaliste", "Folk"], keywords: ["étoiles", "galaxie", "stars", "galaxy"] },
      chat_nuit: { label: "Chat sous la lune",emoji: "🐱", styles: ["Silhouette", "Mignon", "Mystique", "Japonais", "Folk"], keywords: ["chat nuit", "cat moon"] },
      sorciere:  { label: "Sorcière",         emoji: "🧙", styles: ["Halloween", "Mystique", "Mignon", "Vintage", "Folk"], keywords: ["sorcière", "witch"] },
      cosmos:    { label: "Cosmos & Planètes",emoji: "🪐", styles: ["Scientifique", "Minimaliste", "Coloré", "Folk", "Moderne"], keywords: ["cosmos", "planète", "planet", "espace"] },
    },
  },
};

// ─── Aida formats ──────────────────────────────────────────────────────────
export interface AidaFormat {
  label: string;
  count: number;
  widthCm: number;
  heightCm: number;
}

export function getAidaFormats(size: number): AidaFormat[] {
  return [
    { label: `Aida 14ct`, count: 14, widthCm: parseFloat((size / 14 * 2.54).toFixed(1)), heightCm: parseFloat((size / 14 * 2.54).toFixed(1)) },
    { label: `Aida 16ct`, count: 16, widthCm: parseFloat((size / 16 * 2.54).toFixed(1)), heightCm: parseFloat((size / 16 * 2.54).toFixed(1)) },
    { label: `Aida 18ct`, count: 18, widthCm: parseFloat((size / 18 * 2.54).toFixed(1)), heightCm: parseFloat((size / 18 * 2.54).toFixed(1)) },
    { label: `Aida 28ct`, count: 28, widthCm: parseFloat((size / 28 * 2.54).toFixed(1)), heightCm: parseFloat((size / 28 * 2.54).toFixed(1)) },
  ];
}

// ─── Harmonious DMC palettes by theme name ────────────────────────────────
export const HARMONIOUS_PALETTES: Record<string, { hex: string; code: string; name: string }[]> = {
  floral: [
    { hex: "#0a0a0b", code: "fond",  name: "Fond" },
    { hex: "#F4C2C2", code: "3713",  name: "Rose pâle" },
    { hex: "#E8899A", code: "3716",  name: "Rose moyen" },
    { hex: "#C62D42", code: "321",   name: "Rouge vif" },
    { hex: "#8B2252", code: "3803",  name: "Rose foncé" },
    { hex: "#F5C518", code: "726",   name: "Jaune or" },
    { hex: "#A8C97F", code: "472",   name: "Vert clair" },
    { hex: "#3CB371", code: "911",   name: "Émeraude" },
    { hex: "#1A5C38", code: "895",   name: "Vert foncé" },
    { hex: "#F0EAD6", code: "blanc", name: "Blanc" },
  ],
  nature: [
    { hex: "#0a0a0b", code: "fond",  name: "Fond" },
    { hex: "#FFF8DC", code: "3823",  name: "Crème" },
    { hex: "#A8C97F", code: "472",   name: "Vert lime" },
    { hex: "#6B9E5E", code: "3347",  name: "Vert moyen" },
    { hex: "#1A5C38", code: "895",   name: "Vert foncé" },
    { hex: "#8B5E3C", code: "433",   name: "Brun moyen" },
    { hex: "#5C3317", code: "801",   name: "Brun foncé" },
    { hex: "#F5C518", code: "726",   name: "Or" },
    { hex: "#C8C8C8", code: "762",   name: "Gris perle" },
    { hex: "#F0EAD6", code: "blanc", name: "Blanc" },
  ],
  animal: [
    { hex: "#0a0a0b", code: "fond",  name: "Fond" },
    { hex: "#F0EAD6", code: "blanc", name: "Blanc" },
    { hex: "#D4956A", code: "402",   name: "Pêche" },
    { hex: "#C84B14", code: "900",   name: "Roux" },
    { hex: "#8B5E3C", code: "433",   name: "Brun moyen" },
    { hex: "#2C1810", code: "3371",  name: "Brun noir" },
    { hex: "#4A4A4A", code: "3799",  name: "Gris foncé" },
    { hex: "#F5C518", code: "726",   name: "Or" },
    { hex: "#3CB371", code: "911",   name: "Vert" },
    { hex: "#14B8A6", code: "3844",  name: "Turquoise" },
  ],
  geo: [
    { hex: "#0a0a0b", code: "fond",  name: "Fond" },
    { hex: "#F0EAD6", code: "blanc", name: "Blanc" },
    { hex: "#8B5CF6", code: "553",   name: "Violet" },
    { hex: "#4C1D95", code: "550",   name: "Violet foncé" },
    { hex: "#14B8A6", code: "3844",  name: "Turquoise" },
    { hex: "#F5C518", code: "726",   name: "Or" },
    { hex: "#C62D42", code: "321",   name: "Rouge" },
    { hex: "#4A4A4A", code: "3799",  name: "Gris" },
    { hex: "#1A3A5C", code: "311",   name: "Bleu marine" },
    { hex: "#B8D4E8", code: "3753",  name: "Bleu ciel" },
  ],
  sea: [
    { hex: "#0a0a0b", code: "fond",  name: "Fond" },
    { hex: "#F0EAD6", code: "blanc", name: "Blanc" },
    { hex: "#B8D4E8", code: "3753",  name: "Bleu glacier" },
    { hex: "#14B8A6", code: "3844",  name: "Turquoise" },
    { hex: "#1B8A9A", code: "3765",  name: "Teal moyen" },
    { hex: "#1A3A5C", code: "311",   name: "Bleu marine" },
    { hex: "#0D2240", code: "336",   name: "Bleu nuit" },
    { hex: "#FFF8DC", code: "3823",  name: "Crème sable" },
    { hex: "#C4A265", code: "437",   name: "Sable doré" },
    { hex: "#4A4A4A", code: "3799",  name: "Gris foncé" },
  ],
};

// Helper: get palette name for a theme
export function getPaletteForTheme(themeKey: string): string {
  return KEYWORD_TREE[themeKey]?.palette || "floral";
}

// Helper: get top themes sorted by Etsy popularity
export const ETSY_TOP_THEMES = [
  "fleurs", "animaux", "paysages", "geometrie", "saisons", "ocean_theme", "nuit",
];
