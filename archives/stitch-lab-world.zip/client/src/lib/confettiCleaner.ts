/**
 * Confetti Detection & Removal Algorithm
 * Ported from ThreadFlow — identifies and removes isolated pixels from cross-stitch grids
 */

export interface GridPixel {
  x: number;
  y: number;
  color: string;
}

export interface ConfettiAnalysis {
  totalPixels: number;
  confettiPixels: number;
  cleanedPixels: number;
  reductionPercentage: number;
}

/**
 * Detects isolated pixels (confetti) based on neighbor count
 * A pixel is considered confetti if it has fewer than minNeighbors of the same color
 */
export function detectConfetti(
  grid: GridPixel[],
  minNeighbors: number = 2,
  sensitivity: number = 50
): GridPixel[] {
  const confettiPixels: GridPixel[] = [];
  const pixelMap = new Map<string, GridPixel>();

  // Build pixel map for O(1) lookup
  grid.forEach((pixel) => {
    pixelMap.set(`${pixel.x},${pixel.y}`, pixel);
  });

  // Calculate sensitivity threshold (0-100 scale)
  const threshold = Math.max(0, minNeighbors - Math.floor((sensitivity / 100) * 2));

  grid.forEach((pixel) => {
    const neighbors = getNeighbors(pixel, pixelMap);
    const sameColorNeighbors = neighbors.filter((n) => n.color === pixel.color).length;

    if (sameColorNeighbors < threshold) {
      confettiPixels.push(pixel);
    }
  });

  return confettiPixels;
}

/**
 * Gets all 8 neighbors of a pixel (including diagonals)
 */
function getNeighbors(pixel: GridPixel, pixelMap: Map<string, GridPixel>): GridPixel[] {
  const neighbors: GridPixel[] = [];
  const directions = [
    [-1, -1], [-1, 0], [-1, 1],
    [0, -1],           [0, 1],
    [1, -1],  [1, 0],  [1, 1],
  ];

  directions.forEach(([dx, dy]) => {
    const key = `${pixel.x + dx!},${pixel.y + dy!}`;
    const neighbor = pixelMap.get(key);
    if (neighbor) {
      neighbors.push(neighbor);
    }
  });

  return neighbors;
}

/**
 * Removes confetti pixels from grid
 */
export function removeConfetti(
  grid: GridPixel[],
  confettiPixels: GridPixel[]
): GridPixel[] {
  const confettiSet = new Set(confettiPixels.map((p) => `${p.x},${p.y}`));
  return grid.filter((pixel) => !confettiSet.has(`${pixel.x},${pixel.y}`));
}

/**
 * Analyzes confetti in grid and returns statistics
 */
export function analyzeConfetti(
  originalGrid: GridPixel[],
  sensitivity: number = 50
): ConfettiAnalysis {
  const confettiPixels = detectConfetti(originalGrid, 2, sensitivity);
  const cleanedGrid = removeConfetti(originalGrid, confettiPixels);

  return {
    totalPixels: originalGrid.length,
    confettiPixels: confettiPixels.length,
    cleanedPixels: cleanedGrid.length,
    reductionPercentage: originalGrid.length > 0
      ? Math.round((confettiPixels.length / originalGrid.length) * 100)
      : 0,
  };
}

/**
 * Cleans grid by removing confetti based on sensitivity
 */
export function cleanGrid(grid: GridPixel[], sensitivity: number = 50): GridPixel[] {
  const confettiPixels = detectConfetti(grid, 2, sensitivity);
  return removeConfetti(grid, confettiPixels);
}

/**
 * Generates sample grid data for the BeforeAfter slider demo
 * Creates a realistic pattern with intentional confetti pixels
 */
export function generateConfettiDemoData(sensitivity: number = 50): {
  beforePixels: GridPixel[];
  afterPixels: GridPixel[];
  stats: ConfettiAnalysis;
} {
  const pixels: GridPixel[] = [];
  const colors = ['#CC2222', '#2A7828', '#4B0082', '#C89030', '#1A3060'];

  // Main pattern: a heart shape
  const heartPattern = [
    [0,0,1,1,0,0,0,1,1,0,0,0,0,0,0,0],
    [0,1,1,1,1,0,1,1,1,1,0,0,0,0,0,0],
    [1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0],
    [1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0],
    [0,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0],
    [0,0,1,1,1,1,1,1,1,0,0,0,0,0,0,0],
    [0,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0],
    [0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0],
  ];

  // Place heart pattern with main color
  for (let y = 0; y < heartPattern.length; y++) {
    for (let x = 0; x < heartPattern[y].length; x++) {
      if (heartPattern[y][x] === 1) {
        pixels.push({ x: x + 2, y: y + 3, color: colors[0] });
      }
    }
  }

  // Add some structured border in green
  for (let x = 1; x <= 14; x++) {
    pixels.push({ x, y: 1, color: colors[1] });
    pixels.push({ x, y: 14, color: colors[1] });
  }
  for (let y = 1; y <= 14; y++) {
    pixels.push({ x: 1, y, color: colors[1] });
    pixels.push({ x: 14, y, color: colors[1] });
  }

  // Add confetti: isolated random pixels scattered around
  const confettiPositions = [
    { x: 5, y: 0, color: colors[2] },
    { x: 12, y: 2, color: colors[3] },
    { x: 0, y: 7, color: colors[4] },
    { x: 15, y: 5, color: colors[0] },
    { x: 3, y: 14, color: colors[2] },
    { x: 13, y: 13, color: colors[3] },
    { x: 8, y: 15, color: colors[4] },
    { x: 0, y: 12, color: colors[0] },
    { x: 15, y: 10, color: colors[2] },
    { x: 7, y: 0, color: colors[3] },
    { x: 11, y: 15, color: colors[1] },
    { x: 15, y: 0, color: colors[4] },
  ];

  const allPixels = [...pixels, ...confettiPositions];

  // Apply confetti detection
  const detected = detectConfetti(allPixels, 2, sensitivity);
  const cleaned = removeConfetti(allPixels, detected);

  return {
    beforePixels: allPixels,
    afterPixels: cleaned,
    stats: {
      totalPixels: allPixels.length,
      confettiPixels: detected.length,
      cleanedPixels: cleaned.length,
      reductionPercentage: allPixels.length > 0
        ? Math.round((detected.length / allPixels.length) * 100)
        : 0,
    },
  };
}
