/**
 * StitchLab — Moteur de patrons pixel ultra-réalistes
 * 12+ motifs détaillés, style Etsy premium
 * Chaque motif est une vraie illustration brodable
 */

export interface RealisticPattern {
  id: string;
  name: string;
  category: string;
  difficulty: "Facile" | "Intermédiaire" | "Expert";
  width: number;
  height: number;
  grid: number[][];
  palette: { dmc: string; name: string; hex: string; count: number }[];
  price: number;
  rating: number;
  sales: number;
  tags: string[];
  description: string;
}

// ─── PALETTE DMC COMPLÈTE ────────────────────────────────────────────────────
const DMC: Record<string, { name: string; hex: string }> = {
  "blanc":  { name: "Blanc",         hex: "#FFFFFF" },
  "ecru":   { name: "Écru",          hex: "#F5F0E8" },
  "310":    { name: "Noir",          hex: "#1A1A1A" },
  "318":    { name: "Gris acier",    hex: "#8B8B8B" },
  "415":    { name: "Gris perle",    hex: "#C8C8C8" },
  "321":    { name: "Rouge vif",     hex: "#C62D42" },
  "347":    { name: "Rouge saumon",  hex: "#C0392B" },
  "351":    { name: "Corail",        hex: "#E8475F" },
  "352":    { name: "Pêche",         hex: "#F4A7B9" },
  "353":    { name: "Pêche clair",   hex: "#FFD5C8" },
  "400":    { name: "Marron foncé",  hex: "#8B4513" },
  "402":    { name: "Acajou clair",  hex: "#C4622D" },
  "434":    { name: "Brun",          hex: "#A0522D" },
  "435":    { name: "Brun clair",    hex: "#C07A3A" },
  "436":    { name: "Caramel",       hex: "#D4924A" },
  "437":    { name: "Caramel clair", hex: "#E8B87A" },
  "469":    { name: "Avocat",        hex: "#6B7C3A" },
  "470":    { name: "Vert avocat",   hex: "#7A8C42" },
  "471":    { name: "Vert pâle",     hex: "#A8B86A" },
  "472":    { name: "Vert citron",   hex: "#C8D882" },
  "500":    { name: "Vert foncé",    hex: "#1A4A2A" },
  "501":    { name: "Vert forêt",    hex: "#2A6040" },
  "502":    { name: "Vert sauge",    hex: "#4A8060" },
  "503":    { name: "Sauge clair",   hex: "#7AB090" },
  "550":    { name: "Violet foncé",  hex: "#4A0A6A" },
  "552":    { name: "Violet",        hex: "#6A2A8A" },
  "553":    { name: "Violet moyen",  hex: "#8A4AAA" },
  "554":    { name: "Violet clair",  hex: "#C090D0" },
  "600":    { name: "Rose foncé",    hex: "#C02060" },
  "602":    { name: "Rose vif",      hex: "#D83070" },
  "604":    { name: "Rose",          hex: "#E870A0" },
  "605":    { name: "Rose clair",    hex: "#F8B0D0" },
  "700":    { name: "Vert vif",      hex: "#1A8A2A" },
  "702":    { name: "Vert kelly",    hex: "#2AAA3A" },
  "704":    { name: "Vert chartreuse",hex: "#5AC84A" },
  "720":    { name: "Orange foncé",  hex: "#C84A10" },
  "721":    { name: "Orange moyen",  hex: "#E06020" },
  "722":    { name: "Orange clair",  hex: "#F08040" },
  "725":    { name: "Jaune topaze",  hex: "#F5C518" },
  "726":    { name: "Jaune clair",   hex: "#F8D840" },
  "727":    { name: "Jaune très clair",hex: "#FFF0A0" },
  "740":    { name: "Mandarine",     hex: "#FF7800" },
  "741":    { name: "Mandarine moyen",hex: "#FFA020" },
  "742":    { name: "Mandarine clair",hex: "#FFC060" },
  "743":    { name: "Jaune moyen",   hex: "#FFD880" },
  "744":    { name: "Jaune pâle",    hex: "#FFE8A0" },
  "762":    { name: "Gris très clair",hex: "#E8E8E8" },
  "796":    { name: "Bleu royal foncé",hex: "#1A3A8A" },
  "797":    { name: "Bleu royal",    hex: "#2A4AAA" },
  "798":    { name: "Bleu foncé",    hex: "#3A5ABA" },
  "799":    { name: "Bleu moyen",    hex: "#5A7ACA" },
  "800":    { name: "Bleu pâle",     hex: "#A0B8E0" },
  "809":    { name: "Bleu délicat",  hex: "#C0D0F0" },
  "815":    { name: "Grenat moyen",  hex: "#8A1A2A" },
  "816":    { name: "Grenat",        hex: "#A02030" },
  "817":    { name: "Rouge corail foncé",hex: "#C03040" },
  "819":    { name: "Rose bébé clair",hex: "#FFE0E8" },
  "838":    { name: "Beige brun foncé",hex: "#5A3A1A" },
  "839":    { name: "Beige brun",    hex: "#7A5A3A" },
  "840":    { name: "Beige brun moyen",hex: "#9A7A5A" },
  "841":    { name: "Beige brun clair",hex: "#BAA07A" },
  "842":    { name: "Beige brun très clair",hex: "#D4C0A0" },
  "890":    { name: "Pistache foncé",hex: "#2A4A1A" },
  "891":    { name: "Carnation foncé",hex: "#E04060" },
  "892":    { name: "Carnation moyen",hex: "#E86080" },
  "893":    { name: "Carnation clair",hex: "#F090A8" },
  "894":    { name: "Carnation très clair",hex: "#F8C0D0" },
  "895":    { name: "Hunter vert foncé",hex: "#1A3A10" },
  "898":    { name: "Café brun foncé",hex: "#3A1A0A" },
  "900":    { name: "Brûlé orange foncé",hex: "#C04010" },
  "902":    { name: "Grenat foncé",  hex: "#6A0A1A" },
  "907":    { name: "Perroquet vert clair",hex: "#90D040" },
  "910":    { name: "Émeraude foncé",hex: "#0A6A2A" },
  "911":    { name: "Émeraude moyen",hex: "#0A8A3A" },
  "912":    { name: "Émeraude clair",hex: "#20AA5A" },
  "913":    { name: "Nil moyen",     hex: "#60C080" },
  "3031":   { name: "Brun moka foncé",hex: "#3A2A10" },
  "3033":   { name: "Sable mocha",   hex: "#D0B890" },
  "3045":   { name: "Jaune beige foncé",hex: "#C0A060" },
  "3046":   { name: "Jaune beige moyen",hex: "#D4B878" },
  "3047":   { name: "Jaune beige clair",hex: "#E8D0A0" },
  "3078":   { name: "Jaune d'or très clair",hex: "#FFF8C0" },
  "3325":   { name: "Bleu bébé clair",hex: "#B0D0F0" },
  "3326":   { name: "Rose saumon clair",hex: "#F8A0B0" },
  "3345":   { name: "Hunter vert foncé",hex: "#1A5020" },
  "3346":   { name: "Hunter vert",   hex: "#2A6830" },
  "3347":   { name: "Hunter vert moyen",hex: "#4A8848" },
  "3348":   { name: "Hunter vert clair",hex: "#90C080" },
  "3371":   { name: "Brun noir",     hex: "#1A0A00" },
  "3607":   { name: "Prune clair",   hex: "#C040A0" },
  "3608":   { name: "Prune très clair",hex: "#E080C0" },
  "3609":   { name: "Prune ultra clair",hex: "#F0B0D8" },
  "3685":   { name: "Mauve foncé",   hex: "#8A1040" },
  "3687":   { name: "Mauve",         hex: "#C05080" },
  "3688":   { name: "Mauve moyen",   hex: "#D880A0" },
  "3689":   { name: "Mauve clair",   hex: "#F0B0C8" },
  "3705":   { name: "Melon foncé",   hex: "#FF6080" },
  "3706":   { name: "Melon moyen",   hex: "#FF90A8" },
  "3708":   { name: "Melon clair",   hex: "#FFB8CC" },
  "3716":   { name: "Rose très clair",hex: "#FFD0DC" },
  "3740":   { name: "Antique violet foncé",hex: "#5A3060" },
  "3743":   { name: "Antique violet très clair",hex: "#D0C0D8" },
  "3750":   { name: "Bleu antique foncé",hex: "#1A2A5A" },
  "3752":   { name: "Bleu antique très clair",hex: "#C0D0E8" },
  "3753":   { name: "Bleu antique ultra clair",hex: "#D8E8F8" },
  "3755":   { name: "Bleu bébé",     hex: "#80B0E0" },
  "3760":   { name: "Wedgwood moyen",hex: "#3A6A9A" },
  "3761":   { name: "Ciel clair",    hex: "#A0C8E8" },
  "3765":   { name: "Paon foncé",    hex: "#1A6A7A" },
  "3766":   { name: "Paon clair",    hex: "#60A8B8" },
  "3770":   { name: "Tawny clair",   hex: "#FFE8D0" },
  "3771":   { name: "Terra cotta ultra clair",hex: "#F0C0A0" },
  "3772":   { name: "Desert sable moyen",hex: "#C09060" },
  "3774":   { name: "Desert sable très clair",hex: "#F0D8C0" },
  "3776":   { name: "Acajou clair",  hex: "#D07040" },
  "3778":   { name: "Terra cotta clair",hex: "#E09070" },
  "3779":   { name: "Terra cotta ultra clair",hex: "#F8C0A8" },
  "3781":   { name: "Moka brun foncé",hex: "#5A3A20" },
  "3782":   { name: "Moka brun clair",hex: "#C0A080" },
  "3787":   { name: "Brun gris foncé",hex: "#5A5040" },
  "3790":   { name: "Beige gris ultra foncé",hex: "#6A5A40" },
  "3799":   { name: "Étain très foncé",hex: "#3A3A3A" },
  "3801":   { name: "Melon très foncé",hex: "#E03050" },
  "3820":   { name: "Paille foncé",  hex: "#D4A030" },
  "3821":   { name: "Paille",        hex: "#E8C050" },
  "3822":   { name: "Paille clair",  hex: "#F0D880" },
  "3823":   { name: "Jaune ultra pâle",hex: "#FFFCE0" },
  "3824":   { name: "Abricot clair", hex: "#FFD0B0" },
  "3825":   { name: "Potiron pâle",  hex: "#FFB880" },
  "3826":   { name: "Or",            hex: "#C88030" },
  "3827":   { name: "Paille pâle",   hex: "#F8D090" },
  "3828":   { name: "Noisette",      hex: "#B08040" },
  "3829":   { name: "Or très foncé", hex: "#9A6010" },
  "3830":   { name: "Terra cotta",   hex: "#C06040" },
  "3831":   { name: "Framboise foncé",hex: "#A02040" },
  "3832":   { name: "Framboise moyen",hex: "#C04060" },
  "3833":   { name: "Framboise clair",hex: "#E07090" },
  "3834":   { name: "Raisin foncé",  hex: "#6A1060" },
  "3835":   { name: "Raisin moyen",  hex: "#8A3080" },
  "3836":   { name: "Raisin clair",  hex: "#C070B0" },
  "3837":   { name: "Lavande ultra foncé",hex: "#5A1080" },
  "3838":   { name: "Bleu lavande foncé",hex: "#3A4A9A" },
  "3839":   { name: "Bleu lavande moyen",hex: "#6070B8" },
  "3840":   { name: "Bleu lavande clair",hex: "#A0B0D8" },
  "3841":   { name: "Bleu bébé pâle",hex: "#D0E0F8" },
  "3842":   { name: "Wedgwood foncé",hex: "#1A4A7A" },
  "3843":   { name: "Bleu électrique",hex: "#1A70C8" },
  "3844":   { name: "Turquoise vif foncé",hex: "#0A90A0" },
  "3845":   { name: "Turquoise vif moyen",hex: "#20B0C0" },
  "3846":   { name: "Turquoise vif clair",hex: "#50D0D8" },
  "3847":   { name: "Teal vert foncé",hex: "#1A6060" },
  "3848":   { name: "Teal vert moyen",hex: "#2A8080" },
  "3849":   { name: "Teal vert clair",hex: "#50A8A0" },
  "3850":   { name: "Vert vif foncé",hex: "#1A7040" },
  "3851":   { name: "Vert vif clair",hex: "#40A060" },
  "3852":   { name: "Paille très foncé",hex: "#C09020" },
  "3853":   { name: "Automne or foncé",hex: "#E08020" },
  "3854":   { name: "Automne or moyen",hex: "#F0A040" },
  "3855":   { name: "Automne or clair",hex: "#F8C880" },
  "3856":   { name: "Acajou ultra clair",hex: "#FFD8B8" },
  "3857":   { name: "Rosewood foncé",hex: "#6A1010" },
  "3858":   { name: "Rosewood moyen",hex: "#A03030" },
  "3859":   { name: "Rosewood clair",hex: "#D07060" },
  "3860":   { name: "Cacao",         hex: "#5A3030" },
  "3861":   { name: "Cacao clair",   hex: "#8A6060" },
  "3862":   { name: "Moka beige foncé",hex: "#7A5A30" },
  "3863":   { name: "Moka beige moyen",hex: "#9A7A50" },
  "3864":   { name: "Moka beige clair",hex: "#C0A880" },
  "3865":   { name: "Blanc hiver",   hex: "#F8F8F0" },
  "3866":   { name: "Blanc mousseline",hex: "#F8F0E8" },
};

// ─── HELPER : compter les pixels par couleur ─────────────────────────────────
function buildPalette(grid: number[][], colorMap: string[]): RealisticPattern["palette"] {
  const counts: Record<number, number> = {};
  for (const row of grid) {
    for (const cell of row) {
      if (cell > 0) counts[cell] = (counts[cell] || 0) + 1;
    }
  }
  return Object.entries(counts)
    .sort((a, b) => b[1] - a[1])
    .map(([idx, count]) => {
      const dmcCode = colorMap[parseInt(idx)];
      const info = DMC[dmcCode] || { name: dmcCode, hex: "#888888" };
      return { dmc: dmcCode, name: info.name, hex: info.hex, count };
    });
}

// ─── MOTIF 1 : RENARD DANS UNE TASSE (32×32) ────────────────────────────────
// Inspiré du style Etsy "Fox in a teacup" — très populaire
const FOX_COLORS = ["", "ecru", "blanc", "310", "400", "402", "435", "436", "437", "721", "722", "741", "742", "743", "469", "470", "502", "503", "840", "841", "415", "318", "3799", "3826", "3827"];
// 0=fond, 1=écru, 2=blanc, 3=noir, 4=brun foncé, 5=acajou, 6=brun, 7=caramel, 8=caramel clair, 9=orange foncé, 10=orange clair, 11=mandarine, 12=mandarine clair, 13=jaune, 14=avocat, 15=vert avocat, 16=sauge, 17=sauge clair, 18=beige brun, 19=beige clair, 20=gris perle, 21=gris acier, 22=étain, 23=or, 24=paille

const FOX_GRID: number[][] = [
  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
  [0,0,0,0,0,0,0,0,0,0,3,3,0,0,0,0,0,0,0,0,3,3,0,0,0,0,0,0,0,0,0,0],
  [0,0,0,0,0,0,0,0,0,3,9,9,3,0,0,0,0,0,0,3,9,9,3,0,0,0,0,0,0,0,0,0],
  [0,0,0,0,0,0,0,0,3,9,10,10,9,3,0,0,0,0,3,9,10,10,9,3,0,0,0,0,0,0,0,0],
  [0,0,0,0,0,0,0,3,9,10,11,11,10,9,3,0,3,9,10,11,11,10,9,3,0,0,0,0,0,0,0,0],
  [0,0,0,0,0,0,3,9,10,11,12,12,11,10,9,3,9,10,11,12,12,11,10,9,3,0,0,0,0,0,0,0],
  [0,0,0,0,0,3,9,10,11,12,13,13,12,11,10,11,10,11,12,13,13,12,11,10,9,3,0,0,0,0,0,0],
  [0,0,0,0,3,9,10,11,12,13,2,2,13,12,11,12,11,12,13,2,2,13,12,11,10,9,3,0,0,0,0,0],
  [0,0,0,3,9,10,11,12,13,2,2,2,2,13,12,13,12,13,2,2,2,2,13,12,11,10,9,3,0,0,0,0],
  [0,0,3,9,10,11,12,13,2,3,2,2,3,2,13,2,13,2,3,2,2,3,2,13,12,11,10,9,3,0,0,0],
  [0,3,9,10,11,12,13,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,13,12,11,10,9,3,0,0],
  [3,9,10,11,12,13,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,13,12,11,10,9,3,0],
  [3,9,10,11,12,13,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,13,12,11,10,9,3,0],
  [3,9,10,11,12,13,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,13,12,11,10,9,3,0],
  [0,3,9,10,11,12,13,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,13,12,11,10,9,3,0,0],
  [0,0,3,9,10,11,12,13,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,13,12,11,10,9,3,0,0,0],
  [0,0,0,3,9,10,11,12,13,2,2,2,2,2,2,2,2,2,2,2,2,2,13,12,11,10,9,3,0,0,0,0],
  [0,0,0,0,3,9,10,11,12,13,13,13,13,13,13,13,13,13,13,13,13,13,12,11,10,9,3,0,0,0,0,0],
  [0,0,0,0,0,3,9,10,11,12,12,12,12,12,12,12,12,12,12,12,12,12,11,10,9,3,0,0,0,0,0,0],
  [0,0,0,0,0,0,3,9,10,11,11,11,11,11,11,11,11,11,11,11,11,11,10,9,3,0,0,0,0,0,0,0],
  [0,0,0,0,0,0,0,3,9,10,10,10,10,10,10,10,10,10,10,10,10,10,9,3,0,0,0,0,0,0,0,0],
  // Tasse
  [0,0,0,0,0,0,0,0,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,0,0,0,0,0,0,0,0],
  [0,0,0,0,0,0,0,16,17,17,17,17,17,17,17,17,17,17,17,17,17,17,17,17,16,0,0,0,0,0,0,0],
  [0,0,0,0,0,0,16,17,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,17,16,0,0,0,0,0,0],
  [0,0,0,0,0,0,16,17,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,17,16,0,0,0,0,0,0],
  [0,0,0,0,0,0,16,17,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,17,16,0,0,0,0,0,0],
  [0,0,0,0,0,0,0,16,17,17,17,17,17,17,17,17,17,17,17,17,17,17,17,17,16,0,0,0,0,0,0,0],
  [0,0,0,0,0,0,0,0,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,0,0,0,0,0,0,0,0],
  // Soucoupe
  [0,0,0,0,0,0,0,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,0,0,0,0,0,0,0],
  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
];

// ─── MOTIF 2 : CHAT SAKURA (28×28) ──────────────────────────────────────────
const CAT_COLORS = ["", "ecru", "blanc", "310", "415", "318", "762", "3799", "604", "605", "3716", "819", "600", "602", "3345", "3346", "3347", "3348", "3326", "353", "352", "351", "3371", "840", "841"];
// 0=fond, 1=écru, 2=blanc, 3=noir, 4=gris perle, 5=gris acier, 6=gris très clair, 7=étain, 8=rose, 9=rose clair, 10=rose très clair, 11=rose bébé, 12=rose foncé, 13=rose vif, 14=vert foncé, 15=vert, 16=vert moyen, 17=vert clair, 18=rose saumon, 19=pêche clair, 20=pêche, 21=corail, 22=brun noir, 23=beige brun, 24=beige clair

const CAT_GRID: number[][] = [
  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
  [0,0,0,8,9,10,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,8,9,10,0,0,0,0],
  [0,0,8,9,10,11,8,0,0,0,0,0,0,0,0,0,0,0,0,0,8,9,10,11,8,0,0,0],
  [0,8,9,10,11,11,9,8,0,0,0,0,0,0,0,0,0,0,0,8,9,10,11,11,9,8,0,0],
  [0,3,4,4,5,5,4,4,3,0,0,0,0,0,0,0,0,0,0,3,4,4,5,5,4,4,3,0],
  [3,4,5,6,6,6,6,5,4,3,0,0,0,0,0,0,0,0,3,4,5,6,6,6,6,5,4,3],
  [3,4,5,6,2,2,2,6,5,4,3,0,0,0,0,0,0,3,4,5,6,2,2,2,6,5,4,3],
  [3,4,5,6,2,2,2,6,5,4,4,3,0,0,0,0,3,4,4,5,6,2,2,2,6,5,4,3],
  [0,3,4,5,6,2,2,6,5,4,4,4,3,0,0,3,4,4,4,5,6,2,2,6,5,4,3,0],
  [0,0,3,4,5,6,6,5,4,4,4,4,4,3,3,4,4,4,4,5,6,6,5,4,3,0,0,0],
  [0,0,0,3,4,5,5,4,4,4,4,4,4,4,4,4,4,4,4,5,5,4,3,0,0,0,0,0],
  [0,0,0,0,3,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,3,0,0,0,0,0,0],
  [0,0,0,0,0,3,4,4,4,4,4,4,4,4,4,4,4,4,4,4,3,0,0,0,0,0,0,0],
  [0,0,0,0,0,3,4,4,4,4,4,4,4,4,4,4,4,4,4,4,3,0,0,0,0,0,0,0],
  [0,0,0,0,0,3,4,4,4,3,3,4,4,4,4,4,4,3,3,4,4,3,0,0,0,0,0,0],
  [0,0,0,0,0,3,4,4,3,7,7,3,4,4,4,4,3,7,7,3,4,4,3,0,0,0,0,0],
  [0,0,0,0,0,3,4,4,3,7,7,3,4,4,4,4,3,7,7,3,4,4,3,0,0,0,0,0],
  [0,0,0,0,0,3,4,4,4,3,3,4,4,4,4,4,4,3,3,4,4,3,0,0,0,0,0,0],
  [0,0,0,0,0,3,4,4,4,4,4,4,4,4,4,4,4,4,4,4,3,0,0,0,0,0,0,0],
  [0,0,0,0,0,3,4,4,4,4,4,4,4,4,4,4,4,4,4,4,3,0,0,0,0,0,0,0],
  [0,0,0,0,3,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,3,0,0,0,0,0,0],
  [0,0,0,3,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,3,0,0,0,0,0],
  [0,0,3,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,3,0,0,0,0],
  [0,3,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,3,0,0,0],
  // Fleurs sakura autour
  [8,9,10,11,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,8,9,10],
  [0,8,9,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,8,9],
  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
];

// ─── MOTIF 3 : MANDALA NORDIQUE (30×30) ─────────────────────────────────────
const MANDALA_COLORS = ["", "ecru", "blanc", "796", "798", "799", "800", "809", "3325", "3752", "3753", "3841", "725", "726", "727", "3078", "3821", "3822", "3823", "3750", "3838", "3839", "3840"];
// Palette bleu/or nordique

function buildMandala(): number[][] {
  const size = 30;
  const grid: number[][] = Array.from({ length: size }, () => Array(size).fill(0));
  const cx = 14.5, cy = 14.5;

  for (let r = 0; r < size; r++) {
    for (let c = 0; c < size; c++) {
      const dx = c - cx, dy = r - cy;
      const dist = Math.sqrt(dx * dx + dy * dy);
      const angle = Math.atan2(dy, dx);
      const sectors = 8;
      const sectorAngle = (((angle + Math.PI) / (2 * Math.PI)) * sectors) % 1;

      if (dist < 2) {
        grid[r][c] = 2; // blanc centre
      } else if (dist < 3.5) {
        grid[r][c] = 13; // or
      } else if (dist < 5) {
        grid[r][c] = 1; // écru
      } else if (dist < 6.5) {
        grid[r][c] = sectorAngle < 0.5 ? 4 : 7; // bleu alternant
      } else if (dist < 7.5) {
        grid[r][c] = 14; // jaune clair
      } else if (dist < 9) {
        grid[r][c] = sectorAngle < 0.25 || (sectorAngle > 0.5 && sectorAngle < 0.75) ? 3 : 8; // bleu foncé / bleu clair
      } else if (dist < 10) {
        grid[r][c] = 15; // jaune très clair
      } else if (dist < 11.5) {
        const petal = Math.sin(angle * 8) > 0.3;
        grid[r][c] = petal ? 5 : 9; // bleu moyen / clair
      } else if (dist < 12.5) {
        grid[r][c] = 16; // paille
      } else if (dist < 14) {
        const star = Math.sin(angle * 8) > 0.6;
        grid[r][c] = star ? 3 : 6; // bleu foncé / pâle
      }
    }
  }
  return grid;
}

// ─── MOTIF 4 : CERF DES NEIGES (32×32) ──────────────────────────────────────
const DEER_COLORS = ["", "ecru", "blanc", "310", "318", "415", "762", "3799", "840", "841", "842", "3033", "3046", "3047", "3078", "3823", "3752", "3753", "3841", "3325", "800", "809", "3345", "3346", "3347", "3348", "3826", "3827", "436", "437"];

function buildDeer(): number[][] {
  const size = 32;
  const g: number[][] = Array.from({ length: size }, () => Array(size).fill(0));

  // Bois (ramifications)
  const antlerPoints = [[4,8],[3,7],[2,6],[2,5],[3,4],[4,4],[5,5],[5,6],[6,6],[6,5],[7,4],[8,4],[8,5],[7,6],[7,7],[8,8],[9,8],[10,7],[10,6],[11,5],[12,5],[12,6],[11,7],[11,8],
    [22,8],[23,7],[24,6],[24,5],[23,4],[22,4],[21,5],[21,6],[20,6],[20,5],[19,4],[18,4],[18,5],[19,6],[19,7],[18,8],[17,8],[16,7],[16,6],[15,5],[14,5],[14,6],[15,7],[15,8]];
  for (const [r, c] of antlerPoints) {
    if (r >= 0 && r < size && c >= 0 && c < size) g[r][c] = 8; // beige brun
  }

  // Tête
  for (let r = 9; r < 16; r++) {
    for (let c = 11; c < 21; c++) {
      const dx = c - 15.5, dy = r - 12;
      if (dx * dx / 16 + dy * dy / 9 < 1) g[r][c] = 10; // beige clair
    }
  }

  // Museau
  for (let r = 13; r < 16; r++) {
    for (let c = 13; c < 19; c++) {
      const dx = c - 15.5, dy = r - 14;
      if (dx * dx / 9 + dy * dy / 4 < 1) g[r][c] = 11; // sable
    }
  }

  // Nez
  g[14][15] = 3; g[14][16] = 3;

  // Yeux
  g[11][13] = 3; g[11][18] = 3;

  // Corps
  for (let r = 16; r < 26; r++) {
    for (let c = 9; c < 23; c++) {
      const dx = c - 15.5, dy = r - 21;
      if (dx * dx / 25 + dy * dy / 16 < 1) g[r][c] = 9; // beige
    }
  }

  // Pattes
  for (let r = 25; r < 32; r++) {
    for (const c of [11, 12, 14, 15, 17, 18, 20, 21]) {
      if (c < size) g[r][c] = 8;
    }
  }

  // Neige (fond)
  for (let r = 28; r < 32; r++) {
    for (let c = 0; c < size; c++) {
      if (g[r][c] === 0) g[r][c] = 2; // blanc neige
    }
  }

  // Flocons
  const flakes = [[2,2],[2,28],[5,5],[5,25],[8,1],[8,29],[3,15],[6,10],[6,20]];
  for (const [r, c] of flakes) {
    if (r < size && c < size) g[r][c] = 16; // bleu très clair
  }

  return g;
}

// ─── MOTIF 5 : PAPILLON BOTANIQUE (30×30) ───────────────────────────────────
const BUTTERFLY_COLORS = ["", "ecru", "blanc", "310", "550", "552", "553", "554", "3607", "3608", "3609", "3740", "3743", "725", "726", "727", "3078", "3823", "895", "500", "501", "502", "503", "3345", "3346", "3347", "3348"];

function buildButterfly(): number[][] {
  const size = 30;
  const g: number[][] = Array.from({ length: size }, () => Array(size).fill(0));

  // Aile supérieure gauche
  for (let r = 4; r < 18; r++) {
    for (let c = 2; c < 14; c++) {
      const dx = c - 13, dy = r - 11;
      if (dx * dx / 100 + dy * dy / 64 < 1 && c < 13) {
        const ring = Math.sqrt(dx * dx / 100 + dy * dy / 64);
        if (ring < 0.3) g[r][c] = 13; // or centre
        else if (ring < 0.5) g[r][c] = 5; // violet
        else if (ring < 0.7) g[r][c] = 6; // violet moyen
        else if (ring < 0.85) g[r][c] = 7; // violet clair
        else g[r][c] = 8; // prune clair
      }
    }
  }

  // Aile supérieure droite (symétrie)
  for (let r = 4; r < 18; r++) {
    for (let c = 16; c < 28; c++) {
      const dx = c - 16, dy = r - 11;
      if (dx * dx / 100 + dy * dy / 64 < 1 && c > 16) {
        const ring = Math.sqrt(dx * dx / 100 + dy * dy / 64);
        if (ring < 0.3) g[r][c] = 13;
        else if (ring < 0.5) g[r][c] = 5;
        else if (ring < 0.7) g[r][c] = 6;
        else if (ring < 0.85) g[r][c] = 7;
        else g[r][c] = 8;
      }
    }
  }

  // Aile inférieure gauche
  for (let r = 14; r < 26; r++) {
    for (let c = 4; c < 14; c++) {
      const dx = c - 13, dy = r - 19;
      if (dx * dx / 64 + dy * dy / 36 < 1 && c < 13) {
        g[r][c] = g[r][c] === 0 ? 9 : g[r][c]; // prune très clair
      }
    }
  }

  // Aile inférieure droite
  for (let r = 14; r < 26; r++) {
    for (let c = 16; c < 26; c++) {
      const dx = c - 16, dy = r - 19;
      if (dx * dx / 64 + dy * dy / 36 < 1 && c > 16) {
        g[r][c] = g[r][c] === 0 ? 9 : g[r][c];
      }
    }
  }

  // Corps central
  for (let r = 6; r < 24; r++) {
    g[r][13] = 3;
    g[r][14] = 3;
    g[r][15] = 3;
  }

  // Antennes
  for (let i = 0; i < 5; i++) {
    if (4 - i >= 0) {
      g[4 - i][13 - i] = 3;
      g[4 - i][16 + i] = 3;
    }
  }

  // Taches décoratives sur les ailes
  const spots = [[7,6],[7,7],[8,6],[9,8],[10,5],[11,9],[13,7],[7,21],[7,22],[8,23],[9,20],[10,24],[11,19],[13,22]];
  for (const [r, c] of spots) {
    if (r < size && c < size && g[r][c] !== 0) g[r][c] = 14; // or
  }

  return g;
}

// ─── MOTIF 6 : HIBOU FORÊT (28×32) ──────────────────────────────────────────
const OWL_COLORS = ["", "ecru", "blanc", "310", "3371", "838", "839", "840", "841", "842", "3033", "725", "726", "727", "3078", "3823", "469", "470", "471", "472", "895", "500", "501", "502", "503", "3345", "3346", "3347", "3348", "3826", "3827", "436", "437"];

function buildOwl(): number[][] {
  const size = 32;
  const g: number[][] = Array.from({ length: size }, () => Array(size).fill(0));
  const W = 28;

  // Corps ovale
  for (let r = 8; r < 28; r++) {
    for (let c = 4; c < W - 4; c++) {
      const dx = c - (W / 2 - 0.5), dy = r - 18;
      if (dx * dx / 100 + dy * dy / 100 < 1) {
        const ring = Math.sqrt(dx * dx / 100 + dy * dy / 100);
        if (ring < 0.3) g[r][c] = 10; // sable clair
        else if (ring < 0.6) g[r][c] = 8; // beige brun moyen
        else g[r][c] = 6; // brun
      }
    }
  }

  // Tête ronde
  for (let r = 2; r < 12; r++) {
    for (let c = 6; c < W - 6; c++) {
      const dx = c - (W / 2 - 0.5), dy = r - 7;
      if (dx * dx / 36 + dy * dy / 25 < 1) {
        g[r][c] = 7; // caramel
      }
    }
  }

  // Oreilles (touffes)
  for (let r = 1; r < 5; r++) {
    g[r][7] = 5; g[r][8] = 5;
    g[r][W - 9] = 5; g[r][W - 8] = 5;
  }

  // Yeux (grands cercles)
  for (let r = 4; r < 10; r++) {
    for (let c = 7; c < 13; c++) {
      const dx = c - 9.5, dy = r - 6.5;
      if (dx * dx + dy * dy < 9) {
        g[r][c] = dx * dx + dy * dy < 4 ? 3 : 2; // noir / blanc
      }
    }
  }
  for (let r = 4; r < 10; r++) {
    for (let c = W - 13; c < W - 7; c++) {
      const dx = c - (W - 10.5), dy = r - 6.5;
      if (dx * dx + dy * dy < 9) {
        g[r][c] = dx * dx + dy * dy < 4 ? 3 : 2;
      }
    }
  }

  // Bec
  g[8][12] = 11; g[8][13] = 11; g[8][14] = 11;
  g[9][13] = 11;

  // Ailes
  for (let r = 12; r < 26; r++) {
    g[r][4] = 5; g[r][5] = 6;
    g[r][W - 6] = 6; g[r][W - 5] = 5;
  }

  // Branche
  for (let c = 0; c < W; c++) {
    g[28][c] = 4; g[29][c] = 4; g[30][c] = 5;
  }

  // Serres
  g[28][10] = 3; g[28][11] = 3; g[28][16] = 3; g[28][17] = 3;

  return g;
}

// ─── MOTIF 7 : BALEINE GALAXIE (32×24) ──────────────────────────────────────
const WHALE_COLORS = ["", "3750", "3838", "3839", "3840", "3841", "800", "809", "3325", "3752", "3753", "blanc", "725", "726", "727", "3078", "3823", "550", "552", "553", "554", "3609", "3743", "3799", "318", "415", "762"];

function buildWhale(): number[][] {
  const size_r = 24, size_c = 32;
  const g: number[][] = Array.from({ length: size_r }, () => Array(size_c).fill(0));

  // Corps de la baleine
  for (let r = 4; r < 20; r++) {
    for (let c = 2; c < 26; c++) {
      const dx = c - 13, dy = r - 12;
      if (dx * dx / 144 + dy * dy / 64 < 1) {
        const ring = Math.sqrt(dx * dx / 144 + dy * dy / 64);
        if (ring < 0.2) g[r][c] = 3; // bleu lavande moyen
        else if (ring < 0.4) g[r][c] = 2; // bleu lavande foncé
        else if (ring < 0.6) g[r][c] = 1; // bleu antique foncé
        else if (ring < 0.8) g[r][c] = 2;
        else g[r][c] = 1;
      }
    }
  }

  // Queue
  for (let r = 8; r < 16; r++) {
    for (let c = 24; c < 32; c++) {
      const dx = c - 27, dy = r - 12;
      if (Math.abs(dx) + Math.abs(dy) < 5) g[r][c] = 1;
    }
  }

  // Ventre (plus clair)
  for (let r = 12; r < 18; r++) {
    for (let c = 5; c < 20; c++) {
      const dx = c - 12, dy = r - 15;
      if (dx * dx / 64 + dy * dy / 9 < 1) g[r][c] = 5; // bleu clair
    }
  }

  // Œil
  g[9][9] = 11; g[9][10] = 11;
  g[10][9] = 11; g[10][10] = 24; // blanc avec pupille

  // Étoiles galaxie
  const stars = [[1,1],[1,5],[1,10],[1,18],[1,25],[1,30],[2,15],[3,3],[3,8],[3,20],[3,28],[0,12],[0,22],[2,30]];
  for (const [r, c] of stars) {
    if (r < size_r && c < size_c) g[r][c] = 12; // or
  }

  // Bulles
  const bubbles = [[5,16],[4,18],[3,20],[6,19],[5,21]];
  for (const [r, c] of bubbles) {
    if (r < size_r && c < size_c) g[r][c] = 11; // blanc
  }

  return g;
}

// ─── MOTIF 8 : ROSE ANGLAISE (28×28) ────────────────────────────────────────
const ROSE_COLORS = ["", "ecru", "blanc", "310", "815", "816", "817", "321", "347", "351", "352", "353", "819", "3716", "895", "500", "501", "502", "503", "3345", "3346", "3347", "3348", "3685", "3687", "3688", "3689", "3326", "604", "605"];

function buildRose(): number[][] {
  const size = 28;
  const g: number[][] = Array.from({ length: size }, () => Array(size).fill(0));

  // Pétales extérieurs (4 grands)
  const outerPetals = [
    { cx: 14, cy: 6, rx: 5, ry: 7 },
    { cx: 22, cy: 14, rx: 5, ry: 7 },
    { cx: 14, cy: 22, rx: 5, ry: 7 },
    { cx: 6, cy: 14, rx: 5, ry: 7 },
  ];
  for (const p of outerPetals) {
    for (let r = 0; r < size; r++) {
      for (let c = 0; c < size; c++) {
        const dx = c - p.cx, dy = r - p.cy;
        if (dx * dx / (p.rx * p.rx) + dy * dy / (p.ry * p.ry) < 1) {
          const ring = Math.sqrt(dx * dx / (p.rx * p.rx) + dy * dy / (p.ry * p.ry));
          if (g[r][c] === 0) {
            g[r][c] = ring < 0.4 ? 10 : ring < 0.7 ? 9 : 8; // rose dégradé
          }
        }
      }
    }
  }

  // Pétales intermédiaires (4)
  const midPetals = [
    { cx: 10, cy: 10, rx: 4, ry: 5 },
    { cx: 18, cy: 10, rx: 4, ry: 5 },
    { cx: 18, cy: 18, rx: 4, ry: 5 },
    { cx: 10, cy: 18, rx: 4, ry: 5 },
  ];
  for (const p of midPetals) {
    for (let r = 0; r < size; r++) {
      for (let c = 0; c < size; c++) {
        const dx = c - p.cx, dy = r - p.cy;
        if (dx * dx / (p.rx * p.rx) + dy * dy / (p.ry * p.ry) < 1) {
          const ring = Math.sqrt(dx * dx / (p.rx * p.rx) + dy * dy / (p.ry * p.ry));
          g[r][c] = ring < 0.4 ? 11 : ring < 0.7 ? 10 : 9;
        }
      }
    }
  }

  // Cœur central
  for (let r = 10; r < 18; r++) {
    for (let c = 10; c < 18; c++) {
      const dx = c - 13.5, dy = r - 13.5;
      if (dx * dx + dy * dy < 16) {
        const ring = Math.sqrt(dx * dx + dy * dy) / 4;
        g[r][c] = ring < 0.3 ? 12 : ring < 0.6 ? 11 : 10;
      }
    }
  }

  // Feuilles
  const leaves = [
    { cx: 4, cy: 20, rx: 3, ry: 5, color: 18 },
    { cx: 24, cy: 8, rx: 3, ry: 5, color: 17 },
    { cx: 4, cy: 8, rx: 3, ry: 4, color: 19 },
    { cx: 24, cy: 20, rx: 3, ry: 4, color: 18 },
  ];
  for (const l of leaves) {
    for (let r = 0; r < size; r++) {
      for (let c = 0; c < size; c++) {
        const dx = c - l.cx, dy = r - l.cy;
        if (dx * dx / (l.rx * l.rx) + dy * dy / (l.ry * l.ry) < 1 && g[r][c] === 0) {
          g[r][c] = l.color;
        }
      }
    }
  }

  // Tige
  for (let r = 22; r < 28; r++) {
    g[r][13] = 15; g[r][14] = 15;
  }

  return g;
}

// ─── MOTIF 9 : LAPIN PÂQUES (24×28) ─────────────────────────────────────────
const RABBIT_COLORS = ["", "ecru", "blanc", "310", "415", "318", "762", "3799", "604", "605", "3716", "819", "600", "352", "353", "819", "3689", "3688", "3687", "3345", "3346", "3347", "3348", "3826", "3827"];

function buildRabbit(): number[][] {
  const size_r = 28, size_c = 24;
  const g: number[][] = Array.from({ length: size_r }, () => Array(size_c).fill(0));

  // Oreilles
  for (let r = 0; r < 10; r++) {
    for (const [cx, rx] of [[8, 2.5], [15, 2.5]] as [number, number][]) {
      const dy = r - 5;
      const dx_range = rx * Math.sqrt(1 - Math.min(1, (dy * dy) / 25));
      for (let c = Math.ceil(cx - dx_range); c <= Math.floor(cx + dx_range); c++) {
        if (c >= 0 && c < size_c) g[r][c] = 2; // blanc
      }
    }
  }
  // Intérieur oreilles rose
  for (let r = 1; r < 8; r++) {
    for (const [cx] of [[8], [15]] as [number][]) {
      g[r][cx] = 9; // rose clair
    }
  }

  // Tête
  for (let r = 7; r < 16; r++) {
    for (let c = 5; c < 19; c++) {
      const dx = c - 11.5, dy = r - 11.5;
      if (dx * dx / 36 + dy * dy / 25 < 1) g[r][c] = 2;
    }
  }

  // Yeux
  g[10][8] = 3; g[10][15] = 3;

  // Nez
  g[12][11] = 9; g[12][12] = 9;

  // Moustaches
  g[13][6] = 3; g[13][7] = 3; g[13][16] = 3; g[13][17] = 3;

  // Corps
  for (let r = 15; r < 26; r++) {
    for (let c = 4; c < 20; c++) {
      const dx = c - 11.5, dy = r - 20;
      if (dx * dx / 49 + dy * dy / 36 < 1) g[r][c] = 2;
    }
  }

  // Pattes
  for (let r = 23; r < 28; r++) {
    for (const cx of [7, 16]) {
      for (let c = cx - 2; c <= cx + 2; c++) {
        if (c >= 0 && c < size_c) g[r][c] = 2;
      }
    }
  }

  // Œufs de Pâques autour
  const eggs = [[2, 2], [2, 20], [24, 2], [24, 20]];
  for (const [er, ec] of eggs) {
    for (let r = er; r < er + 4; r++) {
      for (let c = ec; c < ec + 3; c++) {
        if (r < size_r && c < size_c) {
          const color = ((er + ec) / 2) % 3 === 0 ? 8 : ((er + ec) / 2) % 3 === 1 ? 16 : 17;
          g[r][c] = color;
        }
      }
    }
  }

  return g;
}

// ─── MOTIF 10 : PHARE CÔTIER (28×32) ────────────────────────────────────────
const LIGHTHOUSE_COLORS = ["", "ecru", "blanc", "310", "796", "798", "799", "800", "809", "3325", "3752", "3753", "3841", "321", "347", "351", "725", "726", "727", "3078", "3823", "3345", "3346", "3347", "3348", "840", "841", "842", "3033"];

function buildLighthouse(): number[][] {
  const size_r = 32, size_c = 28;
  const g: number[][] = Array.from({ length: size_r }, () => Array(size_c).fill(0));

  // Ciel dégradé
  for (let r = 0; r < 20; r++) {
    for (let c = 0; c < size_c; c++) {
      const t = r / 20;
      if (t < 0.3) g[r][c] = 4; // bleu foncé
      else if (t < 0.6) g[r][c] = 5; // bleu
      else g[r][c] = 6; // bleu moyen
    }
  }

  // Mer
  for (let r = 20; r < 32; r++) {
    for (let c = 0; c < size_c; c++) {
      const wave = Math.sin(c * 0.5 + r * 0.3) > 0;
      g[r][c] = wave ? 7 : 8; // bleu clair alternant
    }
  }

  // Tour du phare
  for (let r = 6; r < 28; r++) {
    const width = Math.max(2, 4 - Math.floor((r - 6) / 6));
    const cx = 13;
    for (let c = cx - width; c <= cx + width; c++) {
      if (c >= 0 && c < size_c) {
        const stripe = Math.floor(r / 3) % 2 === 0;
        g[r][c] = stripe ? 2 : 13; // blanc / rouge
      }
    }
  }

  // Lanterne (sommet)
  for (let r = 3; r < 7; r++) {
    for (let c = 10; c < 17; c++) {
      g[r][c] = r === 3 || r === 6 || c === 10 || c === 16 ? 3 : 17; // cadre noir / jaune
    }
  }

  // Lumière rayonnante
  g[4][13] = 16; g[4][14] = 16; g[5][13] = 16; g[5][14] = 16;

  // Rochers
  for (let c = 0; c < 8; c++) {
    g[26][c] = 25; g[27][c] = 25;
  }
  for (let c = 20; c < size_c; c++) {
    g[26][c] = 25; g[27][c] = 25;
  }

  return g;
}

// ─── MOTIF 11 : PAON (30×32) ────────────────────────────────────────────────
const PEACOCK_COLORS = ["", "ecru", "blanc", "310", "3844", "3845", "3846", "3847", "3848", "3849", "3843", "3760", "3765", "3766", "3761", "800", "809", "3325", "725", "726", "727", "3078", "700", "702", "704", "907", "469", "470", "471", "472", "550", "552", "553", "554"];

function buildPeacock(): number[][] {
  const size_r = 32, size_c = 30;
  const g: number[][] = Array.from({ length: size_r }, () => Array(size_c).fill(0));

  // Queue en éventail (plumes)
  for (let r = 8; r < 28; r++) {
    for (let c = 2; c < 28; c++) {
      const dx = c - 14.5, dy = r - 26;
      const dist = Math.sqrt(dx * dx + dy * dy);
      const angle = Math.atan2(-dy, dx);
      if (dist > 4 && dist < 20 && Math.abs(angle) < Math.PI * 0.7) {
        const sector = Math.floor(((angle + Math.PI * 0.7) / (Math.PI * 1.4)) * 7);
        const colors = [4, 5, 6, 7, 8, 9, 10];
        const ring = dist / 20;
        if (ring < 0.3) g[r][c] = 18; // or
        else if (ring > 0.7 && ring < 0.9) {
          // Ocelles
          const ocelle = Math.sin(angle * 7) > 0.8;
          g[r][c] = ocelle ? 11 : colors[sector % 7];
        } else {
          g[r][c] = colors[sector % 7];
        }
      }
    }
  }

  // Corps
  for (let r = 18; r < 30; r++) {
    for (let c = 11; c < 19; c++) {
      const dx = c - 14.5, dy = r - 24;
      if (dx * dx / 16 + dy * dy / 36 < 1) g[r][c] = 4; // turquoise
    }
  }

  // Tête et cou
  for (let r = 6; r < 20; r++) {
    for (let c = 12; c < 17; c++) {
      const dx = c - 14, dy = r - 13;
      if (dx * dx + dy * dy < 9 || (Math.abs(dx) < 2 && r > 10 && r < 20)) {
        g[r][c] = 5; // turquoise moyen
      }
    }
  }

  // Crête
  for (let i = 0; i < 5; i++) {
    if (5 - i >= 0) {
      g[5 - i][13 + (i % 2)] = 18; // or
      g[5 - i][15 - (i % 2)] = 18;
    }
  }

  // Œil
  g[8][14] = 3; g[8][15] = 2;

  // Bec
  g[9][15] = 18; g[9][16] = 18;

  return g;
}

// ─── MOTIF 12 : FORÊT ENCHANTÉE (32×28) ─────────────────────────────────────
const FOREST_COLORS = ["", "ecru", "blanc", "310", "895", "500", "501", "502", "503", "3345", "3346", "3347", "3348", "469", "470", "471", "472", "3371", "838", "839", "840", "841", "725", "726", "727", "3078", "3823", "550", "552", "553", "554", "3609", "3743"];

function buildForest(): number[][] {
  const size_r = 28, size_c = 32;
  const g: number[][] = Array.from({ length: size_r }, () => Array(size_c).fill(0));

  // Ciel nocturne
  for (let r = 0; r < 14; r++) {
    for (let c = 0; c < size_c; c++) {
      g[r][c] = 27; // violet foncé
    }
  }

  // Lune
  for (let r = 1; r < 7; r++) {
    for (let c = 24; c < 30; c++) {
      const dx = c - 26.5, dy = r - 3.5;
      if (dx * dx + dy * dy < 9) g[r][c] = 2; // blanc
    }
  }

  // Étoiles
  const stars = [[2,4],[1,10],[3,16],[2,20],[4,8],[1,28],[3,30]];
  for (const [r, c] of stars) {
    if (r < size_r && c < size_c) g[r][c] = 23; // jaune
  }

  // Sol
  for (let r = 22; r < size_r; r++) {
    for (let c = 0; c < size_c; c++) {
      g[r][c] = r < 24 ? 9 : 8; // vert foncé / moyen
    }
  }

  // Arbres (sapins)
  const trees = [
    { cx: 5, base: 22, height: 14, color: 4 },
    { cx: 13, base: 22, height: 16, color: 5 },
    { cx: 21, base: 22, height: 12, color: 6 },
    { cx: 28, base: 22, height: 15, color: 4 },
  ];

  for (const tree of trees) {
    for (let r = tree.base - tree.height; r < tree.base; r++) {
      const progress = (r - (tree.base - tree.height)) / tree.height;
      const halfWidth = Math.max(1, Math.floor(progress * 5));
      for (let c = tree.cx - halfWidth; c <= tree.cx + halfWidth; c++) {
        if (c >= 0 && c < size_c && r >= 0 && r < size_r) {
          const shade = progress < 0.3 ? tree.color : progress < 0.6 ? tree.color + 1 : tree.color + 2;
          g[r][c] = Math.min(shade, 16);
        }
      }
    }
    // Tronc
    for (let r = tree.base; r < Math.min(tree.base + 3, size_r); r++) {
      g[r][tree.cx] = 17; // brun foncé
    }
  }

  // Champignons
  const mushrooms = [[23, 9], [23, 18], [23, 25]];
  for (const [mr, mc] of mushrooms) {
    if (mr < size_r && mc < size_c) {
      g[mr][mc] = 2; g[mr][mc + 1] = 2;
      g[mr - 1][mc - 1] = 28; g[mr - 1][mc] = 28; g[mr - 1][mc + 1] = 28; g[mr - 1][mc + 2] = 28;
    }
  }

  return g;
}

// ─── ASSEMBLAGE DES PATRONS ───────────────────────────────────────────────────
export const REALISTIC_PATTERNS: RealisticPattern[] = [
  {
    id: "fox-teacup",
    name: "Renard dans une tasse",
    category: "Animaux",
    difficulty: "Intermédiaire",
    width: 32, height: 32,
    grid: FOX_GRID,
    palette: buildPalette(FOX_GRID, FOX_COLORS),
    price: 4.50,
    rating: 4.9,
    sales: 2847,
    tags: ["renard", "tasse", "kawaii", "automne"],
    description: "Un adorable renard roux niché dans une tasse de thé vert. Parfait pour les débutants avancés.",
  },
  {
    id: "cat-sakura",
    name: "Chat Sakura",
    category: "Animaux",
    difficulty: "Facile",
    width: 28, height: 28,
    grid: CAT_GRID,
    palette: buildPalette(CAT_GRID, CAT_COLORS),
    price: 3.90,
    rating: 4.8,
    sales: 3241,
    tags: ["chat", "sakura", "japon", "printemps"],
    description: "Un chat gris aux yeux expressifs entouré de fleurs de cerisier roses.",
  },
  {
    id: "mandala-nordic",
    name: "Mandala Nordique",
    category: "Géométrique",
    difficulty: "Expert",
    width: 30, height: 30,
    grid: buildMandala(),
    palette: buildPalette(buildMandala(), MANDALA_COLORS),
    price: 6.90,
    rating: 5.0,
    sales: 1203,
    tags: ["mandala", "nordique", "bleu", "or", "géométrique"],
    description: "Mandala symétrique à 8 branches en palette bleu royal et or. Pièce maîtresse.",
  },
  {
    id: "deer-snow",
    name: "Cerf des Neiges",
    category: "Nature",
    difficulty: "Intermédiaire",
    width: 32, height: 32,
    grid: buildDeer(),
    palette: buildPalette(buildDeer(), DEER_COLORS),
    price: 5.50,
    rating: 4.9,
    sales: 1876,
    tags: ["cerf", "neige", "hiver", "forêt", "noel"],
    description: "Un cerf majestueux dans la neige avec flocons. Idéal pour les décorations d'hiver.",
  },
  {
    id: "butterfly-botanical",
    name: "Papillon Botanique",
    category: "Nature",
    difficulty: "Intermédiaire",
    width: 30, height: 30,
    grid: buildButterfly(),
    palette: buildPalette(buildButterfly(), BUTTERFLY_COLORS),
    price: 4.90,
    rating: 4.7,
    sales: 2156,
    tags: ["papillon", "violet", "botanique", "printemps"],
    description: "Papillon aux ailes violettes avec taches dorées. Palette prune et or.",
  },
  {
    id: "owl-forest",
    name: "Hibou de la Forêt",
    category: "Animaux",
    difficulty: "Intermédiaire",
    width: 28, height: 32,
    grid: buildOwl(),
    palette: buildPalette(buildOwl(), OWL_COLORS),
    price: 5.20,
    rating: 4.8,
    sales: 1654,
    tags: ["hibou", "forêt", "nuit", "automne", "brun"],
    description: "Un grand hibou aux yeux expressifs perché sur une branche. Tons chauds d'automne.",
  },
  {
    id: "whale-galaxy",
    name: "Baleine Galaxie",
    category: "Fantaisie",
    difficulty: "Facile",
    width: 32, height: 24,
    grid: buildWhale(),
    palette: buildPalette(buildWhale(), WHALE_COLORS),
    price: 3.50,
    rating: 4.9,
    sales: 4102,
    tags: ["baleine", "galaxie", "espace", "bleu", "étoiles"],
    description: "Une baleine bleue nageant dans les étoiles. Le patron le plus populaire de la plateforme.",
  },
  {
    id: "rose-english",
    name: "Rose Anglaise",
    category: "Fleurs",
    difficulty: "Intermédiaire",
    width: 28, height: 28,
    grid: buildRose(),
    palette: buildPalette(buildRose(), ROSE_COLORS),
    price: 4.20,
    rating: 4.6,
    sales: 2987,
    tags: ["rose", "fleur", "anglais", "romantique", "rouge"],
    description: "Rose anglaise aux pétales dégradés du rouge profond au rose pâle. Classique intemporel.",
  },
  {
    id: "rabbit-easter",
    name: "Lapin de Pâques",
    category: "Animaux",
    difficulty: "Facile",
    width: 24, height: 28,
    grid: buildRabbit(),
    palette: buildPalette(buildRabbit(), RABBIT_COLORS),
    price: 2.90,
    rating: 4.7,
    sales: 3456,
    tags: ["lapin", "pâques", "blanc", "œufs", "printemps"],
    description: "Adorable lapin blanc avec œufs de Pâques colorés. Parfait pour les débutants.",
  },
  {
    id: "lighthouse-coastal",
    name: "Phare Côtier",
    category: "Paysages",
    difficulty: "Intermédiaire",
    width: 28, height: 32,
    grid: buildLighthouse(),
    palette: buildPalette(buildLighthouse(), LIGHTHOUSE_COLORS),
    price: 5.80,
    rating: 4.8,
    sales: 1432,
    tags: ["phare", "mer", "côte", "bleu", "rouge", "blanc"],
    description: "Phare rouge et blanc sur fond de mer bleue. Ambiance maritime et lumineuse.",
  },
  {
    id: "peacock-royal",
    name: "Paon Royal",
    category: "Animaux",
    difficulty: "Expert",
    width: 30, height: 32,
    grid: buildPeacock(),
    palette: buildPalette(buildPeacock(), PEACOCK_COLORS),
    price: 7.90,
    rating: 5.0,
    sales: 892,
    tags: ["paon", "turquoise", "or", "royal", "plumes"],
    description: "Paon déployant sa queue irisée en turquoise et or. Chef-d'œuvre de la collection.",
  },
  {
    id: "forest-enchanted",
    name: "Forêt Enchantée",
    category: "Paysages",
    difficulty: "Intermédiaire",
    width: 32, height: 28,
    grid: buildForest(),
    palette: buildPalette(buildForest(), FOREST_COLORS),
    price: 5.50,
    rating: 4.9,
    sales: 2103,
    tags: ["forêt", "nuit", "lune", "étoiles", "violet", "vert"],
    description: "Forêt de sapins sous une lune pleine. Palette nocturne violet et vert profond.",
  },
];


