/**
 * StitchLab ScanSection — Étape 01 — style Framer/Linear
 * Sobre, monochrome, accent blanc uniquement
 */
import { useEffect, useRef, useState } from "react";

const DMC_SWATCHES = [
  { code: "321",  hex: "#C62D42" }, { code: "726",  hex: "#F5C518" },
  { code: "911",  hex: "#3CB371" }, { code: "517",  hex: "#2E6DA4" },
  { code: "553",  hex: "#8B5CF6" }, { code: "3810", hex: "#14B8A6" },
  { code: "783",  hex: "#D4A017" }, { code: "blanc", hex: "#F0EAD6" },
  { code: "310",  hex: "#2A2A2A" }, { code: "3031", hex: "#5C4033" },
  { code: "666",  hex: "#CC3333" }, { code: "3765", hex: "#1B6B7B" },
  { code: "472",  hex: "#9ACD32" }, { code: "3607", hex: "#C080C0" },
  { code: "402",  hex: "#D4956A" }, { code: "3750", hex: "#1B2A4A" },
  { code: "3819", hex: "#C8D96B" }, { code: "3687", hex: "#C06080" },
  { code: "504",  hex: "#A8C8A8" }, { code: "3862", hex: "#7A5C3A" },
];

export default function ScanSection() {
  const [scanned, setScanned] = useState<boolean[]>(new Array(20).fill(false));
  const [count, setCount] = useState(0);
  const [scanning, setScanning] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => entries.forEach((e) => {
        if (e.isIntersecting) e.target.querySelectorAll(".fade-up").forEach((el) => el.classList.add("visible"));
      }),
      { threshold: 0.1 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  const startScan = () => {
    if (scanning) return;
    setScanning(true);
    setScanned(new Array(20).fill(false));
    setCount(0);
    let i = 0;
    let c = 0;
    const total = Math.floor(Math.random() * 60) + 110;
    intervalRef.current = setInterval(() => {
      if (i >= 20) {
        clearInterval(intervalRef.current!);
        setCount(total);
        setScanning(false);
        return;
      }
      setScanned((prev) => { const n = [...prev]; n[i] = true; return n; });
      i++;
      c += Math.floor(Math.random() * 7) + 4;
      setCount(Math.min(c, total - 5));
    }, 160);
  };

  return (
    <section
      id="scan"
      ref={sectionRef}
      style={{
        minHeight: "100vh", display: "flex", alignItems: "center",
        background: "var(--bg-base)", padding: "clamp(60px,10vw,80px) 20px",
        position: "relative", overflow: "hidden",
      }}
    >
      <div style={{ position: "absolute", top: 0, left: "10%", right: "10%", height: 1, background: "var(--border-subtle)" }} />

      <div style={{ maxWidth: 1100, margin: "0 auto", width: "100%", display: "grid", gridTemplateColumns: "min(100%, 480px) 1fr", gap: "clamp(40px,6vw,80px)", alignItems: "center" }}
        className="scan-grid"
      >

        {/* Left: Text */}
        <div>
          <div className="fade-up" style={{ marginBottom: 12 }}>
            <span className="section-label">01 — Scan Magique</span>
          </div>
          <h2
            className="fade-up d1"
            style={{
              fontFamily: "'Geist', 'Inter', sans-serif",
              fontWeight: 700, fontSize: "clamp(2rem, 4vw, 3rem)",
              lineHeight: 1.1, letterSpacing: "-0.03em",
              color: "rgba(255,255,255,0.88)", marginBottom: 20,
            }}
          >
            Montrez-moi<br />
            <span style={{ color: "rgba(255,255,255,0.30)" }}>vos fils.</span>
          </h2>
          <p className="fade-up d2" style={{ fontSize: "0.88rem", lineHeight: 1.75, color: "rgba(255,255,255,0.38)", maxWidth: 380, marginBottom: 32 }}>
            Pointez votre smartphone vers votre boîte DMC. L'IA de reconnaissance visuelle identifie chaque couleur en 45 secondes et construit votre inventaire numérique complet.
          </p>

          <div className="fade-up d2" style={{ display: "flex", flexDirection: "column", gap: 12, marginBottom: 32 }}>
            {[
              "Reconnaissance visuelle en temps réel",
              "500+ couleurs DMC dans la base",
              "Inventaire prédictif après 6 mois",
            ].map((text) => (
              <div key={text} style={{ display: "flex", alignItems: "center", gap: 12 }}>
                <div style={{ width: 3, height: 3, borderRadius: "50%", background: "rgba(255,255,255,0.28)", flexShrink: 0 }} />
                <span style={{ fontSize: "0.82rem", color: "rgba(255,255,255,0.40)" }}>{text}</span>
              </div>
            ))}
          </div>

          <div className="fade-up d3" style={{ padding: "14px 18px", borderRadius: 10, background: "var(--bg-surface)", border: "1px solid var(--border-subtle)", marginBottom: 28, maxWidth: 380 }}>
            <div style={{ fontSize: "0.65rem", color: "rgba(255,255,255,0.22)", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.08em" }}>Message pivot</div>
            <div style={{ fontSize: "0.83rem", color: "rgba(255,255,255,0.60)", fontStyle: "italic" }}>
              "Votre atelier est prêt. {count || 147} couleurs enregistrées."
            </div>
          </div>

          <div className="fade-up d3" style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <button className="sl-btn-primary" onClick={startScan} disabled={scanning}>
              {scanning ? "Scan en cours…" : "Simuler le scan"}
            </button>
            {count > 0 && !scanning && (
              <span style={{ fontSize: "0.75rem", color: "rgba(255,255,255,0.28)" }}>
                {count} couleurs détectées
              </span>
            )}
          </div>
        </div>

        {/* Right: Phone mockup */}
        <div className="fade-up d1" style={{ display: "flex", justifyContent: "center" }}>
          <div>
            <div style={{
              width: 210, height: 370, borderRadius: 32,
              background: "var(--bg-surface)",
              border: "1px solid var(--border-default)",
              boxShadow: "0 40px 80px rgba(0,0,0,0.5)",
              overflow: "hidden", position: "relative",
              display: "flex", flexDirection: "column",
            }}>
              {/* Status bar */}
              <div style={{ height: 28, display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 16px", flexShrink: 0 }}>
                <span style={{ fontSize: "0.58rem", color: "rgba(255,255,255,0.30)" }}>9:41</span>
                <span style={{ fontSize: "0.58rem", color: "rgba(255,255,255,0.30)", letterSpacing: "0.06em", textTransform: "uppercase" }}>
                  {scanning ? "Scan…" : count > 0 ? `${count} fils` : "Prêt"}
                </span>
              </div>

              {/* Scan line */}
              {scanning && (
                <div style={{
                  position: "absolute", left: 0, right: 0, height: 1, zIndex: 10,
                  background: "rgba(255,255,255,0.50)",
                  animation: "scan-line 1.6s ease-in-out infinite",
                }} />
              )}

              {/* Grid */}
              <div style={{ flex: 1, display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 3, padding: "8px 12px" }}>
                {DMC_SWATCHES.map((s, i) => (
                  <div key={s.code} style={{
                    aspectRatio: "1", borderRadius: 5,
                    background: s.hex,
                    opacity: scanned[i] ? 1 : 0.15,
                    transition: "opacity 0.25s",
                    position: "relative",
                  }}>
                    {scanned[i] && (
                      <div style={{
                        position: "absolute", inset: 0, display: "flex",
                        alignItems: "center", justifyContent: "center",
                        fontSize: "0.55rem", color: "white",
                        textShadow: "0 0 4px rgba(0,0,0,0.9)", fontWeight: 700,
                      }}>✓</div>
                    )}
                  </div>
                ))}
              </div>

              {/* Counter */}
              <div style={{ height: 48, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
                <div style={{ fontFamily: "'Geist','Inter',sans-serif", fontWeight: 700, fontSize: "1.3rem", color: "rgba(255,255,255,0.82)" }}>{count}</div>
                <div style={{ fontSize: "0.58rem", color: "rgba(255,255,255,0.25)", textTransform: "uppercase", letterSpacing: "0.08em" }}>couleurs</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes scan-line {
          0% { top: 10%; }
          50% { top: 85%; }
          100% { top: 10%; }
        }
      `}</style>
    </section>
  );
}
