/**
 * StitchLab SALSection — Étape 04
 * Design: Framer/Linear sobre
 *
 * Fonctionnalités :
 * - Recherche Magique intelligente (DMC / Amies / Motifs / SAL)
 * - Résultats contextuels avec connexions SAL suggérées
 * - Carte mondiale SVG avec dots animés
 * - Heatmap communautaire
 * - Panneau de détail SAL avec stats + membres + progression
 */
import { useEffect, useRef, useState } from "react";

// ─── Data ──────────────────────────────────────────────────────
const SALS = [
  { id: 1, name: "SAL Botanique de Paris",   city: "Paris",    country: "FR", lat: 48.8, lng: 2.3,   members: 18, progress: 100, color: "#14B8A6", theme: "Floral", dmc: ["3844","321","726"] },
  { id: 2, name: "SAL Sakura Tokyo",          city: "Tokyo",    country: "JP", lat: 35.6, lng: 139.7, members: 34, progress: 67,  color: "#F4A7B9", theme: "Floral", dmc: ["3716","893","blanc"] },
  { id: 3, name: "SAL Nordic Winter",         city: "Oslo",     country: "NO", lat: 59.9, lng: 10.7,  members: 12, progress: 42,  color: "#6699CC", theme: "Géo",    dmc: ["517","3750","blanc"] },
  { id: 4, name: "SAL Mandala Montréal",      city: "Montréal", country: "CA", lat: 45.5, lng: -73.6, members: 27, progress: 85,  color: "#8B5CF6", theme: "Géo",    dmc: ["553","554","3837"] },
  { id: 5, name: "SAL Forêt Enchantée",       city: "Berlin",   country: "DE", lat: 52.5, lng: 13.4,  members: 21, progress: 31,  color: "#3CB371", theme: "Nature", dmc: ["911","904","895"] },
  { id: 6, name: "SAL Broderie Libre Lyon",   city: "Lyon",     country: "FR", lat: 45.7, lng: 4.8,   members: 9,  progress: 58,  color: "#D4A017", theme: "Libre",  dmc: ["783","676","3820"] },
];

const MAGIC_SUGGESTIONS = [
  { type: "dmc",   icon: "◼", label: "DMC 321 · Rouge",        sub: "3 SALs utilisent cette couleur" },
  { type: "dmc",   icon: "◼", label: "DMC 3844 · Turquoise",   sub: "5 SALs utilisent cette couleur" },
  { type: "amie",  icon: "◎", label: "Sophie M. — Paris",      sub: "Brode SAL Botanique · 78% avancement" },
  { type: "amie",  icon: "◎", label: "Yuki T. — Tokyo",        sub: "Brode SAL Sakura · 67% avancement" },
  { type: "motif", icon: "◈", label: "Motif Floral #247",      sub: "Utilisé dans 4 SALs actifs" },
  { type: "motif", icon: "◈", label: "Mandala Géométrique",    sub: "Populaire cette semaine · +12 brodeuses" },
  { type: "sal",   icon: "◉", label: "SAL Botanique de Paris", sub: "18 membres · 100% terminé" },
  { type: "sal",   icon: "◉", label: "SAL Sakura Tokyo",       sub: "34 membres · 67% en cours" },
];

const HEATMAP_SIZE = 12;
function buildHeatmap() {
  return Array.from({ length: HEATMAP_SIZE }, (_, r) =>
    Array.from({ length: HEATMAP_SIZE }, (_, c) => {
      const cx = c - HEATMAP_SIZE / 2, cy = r - HEATMAP_SIZE / 2;
      const v = Math.sin(cx * 0.6 + cy * 0.4) * Math.cos(cy * 0.5 - cx * 0.3);
      return Math.max(0, Math.min(1, (v + 1) / 2));
    })
  );
}

// ─── WorldMap SVG ─────────────────────────────────────────────
function WorldMap({ activeSalId, onSelect }: { activeSalId: number | null; onSelect: (id: number) => void }) {
  // Projection simple : lat/lng → x/y dans un SVG 600×300
  const project = (lat: number, lng: number) => ({
    x: ((lng + 180) / 360) * 600,
    y: ((90 - lat) / 180) * 300,
  });

  return (
    <div style={{ position: "relative", borderRadius: 12, overflow: "hidden", border: "1px solid var(--border-subtle)", background: "var(--bg-surface)" }}>
      <svg viewBox="0 0 600 300" style={{ width: "100%", display: "block" }}>
        {/* Fond océan */}
        <rect width="600" height="300" fill="rgba(255,255,255,0.02)" />
        {/* Grille légère */}
        {[0,60,120,180,240,300].map((y) => (
          <line key={y} x1="0" y1={y} x2="600" y2={y} stroke="rgba(255,255,255,0.04)" strokeWidth="0.5" />
        ))}
        {[0,100,200,300,400,500,600].map((x) => (
          <line key={x} x1={x} y1="0" x2={x} y2="300" stroke="rgba(255,255,255,0.04)" strokeWidth="0.5" />
        ))}
        {/* Continents simplifiés — silhouettes */}
        <path d="M80,60 Q120,40 160,55 Q200,70 220,90 Q200,110 170,120 Q130,130 100,110 Q70,90 80,60Z" fill="rgba(255,255,255,0.06)" />
        <path d="M220,50 Q280,30 340,45 Q380,60 400,80 Q420,100 410,130 Q390,160 350,170 Q300,180 260,160 Q220,140 210,110 Q200,80 220,50Z" fill="rgba(255,255,255,0.06)" />
        <path d="M250,180 Q290,170 320,185 Q340,200 330,230 Q310,250 280,245 Q255,235 245,210 Q240,195 250,180Z" fill="rgba(255,255,255,0.06)" />
        <path d="M400,60 Q450,40 500,55 Q540,70 550,100 Q545,130 510,145 Q470,155 430,140 Q395,120 390,90 Q385,70 400,60Z" fill="rgba(255,255,255,0.06)" />
        <path d="M420,160 Q450,150 480,165 Q500,180 495,210 Q475,230 450,225 Q425,215 415,190 Q410,172 420,160Z" fill="rgba(255,255,255,0.06)" />

        {/* Dots SAL */}
        {SALS.map((sal) => {
          const { x, y } = project(sal.lat, sal.lng);
          const isActive = activeSalId === sal.id;
          return (
            <g key={sal.id} style={{ cursor: "pointer" }} onClick={() => onSelect(sal.id)}>
              {/* Halo pulsé */}
              <circle cx={x} cy={y} r={isActive ? 14 : 10} fill={sal.color} opacity={0.08}>
                <animate attributeName="r" values={isActive ? "10;16;10" : "8;12;8"} dur="2.5s" repeatCount="indefinite" />
                <animate attributeName="opacity" values="0.08;0.15;0.08" dur="2.5s" repeatCount="indefinite" />
              </circle>
              {/* Dot principal */}
              <circle cx={x} cy={y} r={isActive ? 6 : 4} fill={sal.color} opacity={isActive ? 1 : 0.75} />
              {/* Label */}
              {isActive && (
                <text x={x + 9} y={y + 4} fontSize="7" fill="rgba(255,255,255,0.70)" fontFamily="Inter,sans-serif">{sal.city}</text>
              )}
            </g>
          );
        })}
      </svg>
    </div>
  );
}

// ─── HeatmapGrid ──────────────────────────────────────────────
function HeatmapGrid() {
  const [heat] = useState(buildHeatmap);
  const [tick, setTick] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setTick((t) => t + 1), 1800);
    return () => clearInterval(id);
  }, []);

  return (
    <div>
      <div style={{ fontSize: "0.62rem", fontWeight: 500, textTransform: "uppercase", letterSpacing: "0.10em", color: "rgba(255,255,255,0.28)", marginBottom: 10 }}>
        Activité mondiale · temps réel
      </div>
      <div style={{ display: "grid", gridTemplateColumns: `repeat(${HEATMAP_SIZE}, 1fr)`, gap: 2 }}>
        {heat.map((row, r) =>
          row.map((v, c) => {
            const pulse = (r + c + tick) % 7 === 0;
            return (
              <div
                key={`${r}-${c}`}
                style={{
                  aspectRatio: "1", borderRadius: 2,
                  background: `rgba(255,255,255,${pulse ? Math.min(v + 0.25, 0.85) : v * 0.55})`,
                  transition: "background 0.6s ease",
                }}
              />
            );
          })
        )}
      </div>
      <div style={{ marginTop: 8, fontSize: "0.60rem", color: "rgba(255,255,255,0.20)" }}>
        {SALS.reduce((a, s) => a + s.members, 0)} brodeuses actives en ce moment
      </div>
    </div>
  );
}

// ─── SAL Detail Panel ─────────────────────────────────────────
function SALDetail({ sal, onClose }: { sal: typeof SALS[0]; onClose: () => void }) {
  return (
    <div className="sl-card" style={{ padding: 20, position: "relative" }}>
      <button onClick={onClose} style={{ position: "absolute", top: 14, right: 14, background: "none", border: "none", color: "rgba(255,255,255,0.30)", cursor: "pointer", fontSize: "0.85rem", lineHeight: 1 }}>✕</button>

      <div style={{ fontSize: "0.60rem", fontWeight: 500, textTransform: "uppercase", letterSpacing: "0.10em", color: "rgba(255,255,255,0.28)", marginBottom: 6 }}>SAL</div>
      <div style={{ fontFamily: "'Geist','Inter',sans-serif", fontWeight: 700, fontSize: "1.15rem", color: "rgba(255,255,255,0.88)", marginBottom: 4, letterSpacing: "-0.02em" }}>{sal.name}</div>
      <div style={{ fontSize: "0.72rem", color: "rgba(255,255,255,0.32)", marginBottom: 16 }}>{sal.city}, {sal.country} · Thème : {sal.theme}</div>

      {/* Stats */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, marginBottom: 16 }}>
        {[
          { icon: "◎", label: "Avancement", value: `${sal.progress}%` },
          { icon: "◉", label: "Membres",    value: sal.members },
          { icon: "◈", label: "Couleurs",   value: sal.dmc.length },
        ].map((s) => (
          <div key={s.label} style={{ padding: "10px 8px", borderRadius: 8, background: "var(--bg-raised)", border: "1px solid var(--border-subtle)", textAlign: "center" }}>
            <div style={{ fontSize: "0.70rem", color: "rgba(255,255,255,0.28)", marginBottom: 3 }}>{s.icon}</div>
            <div style={{ fontWeight: 700, fontSize: "1.05rem", color: "rgba(255,255,255,0.80)", letterSpacing: "-0.02em" }}>{s.value}</div>
            <div style={{ fontSize: "0.58rem", color: "rgba(255,255,255,0.22)", textTransform: "uppercase", letterSpacing: "0.06em", marginTop: 2 }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Barre de progression */}
      <div style={{ marginBottom: 14 }}>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 5 }}>
          <span style={{ fontSize: "0.65rem", color: "rgba(255,255,255,0.28)" }}>Progression collective</span>
          <span style={{ fontSize: "0.65rem", color: "rgba(255,255,255,0.50)", fontWeight: 600 }}>{sal.progress}%</span>
        </div>
        <div style={{ height: 3, borderRadius: 9999, background: "var(--bg-raised)", overflow: "hidden" }}>
          <div style={{ height: "100%", width: `${sal.progress}%`, background: sal.color, borderRadius: 9999, opacity: 0.80, transition: "width 1s cubic-bezier(0.23,1,0.32,1)" }} />
        </div>
      </div>

      {/* Palette DMC */}
      <div style={{ marginBottom: 16 }}>
        <div style={{ fontSize: "0.60rem", fontWeight: 500, textTransform: "uppercase", letterSpacing: "0.10em", color: "rgba(255,255,255,0.22)", marginBottom: 8 }}>Fils DMC</div>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
          {sal.dmc.map((code) => (
            <div key={code} style={{ padding: "3px 10px", borderRadius: 6, background: "var(--bg-raised)", border: "1px solid var(--border-subtle)", fontSize: "0.68rem", color: "rgba(255,255,255,0.45)" }}>
              DMC {code}
            </div>
          ))}
        </div>
      </div>

      {/* Membres */}
      <div style={{ marginBottom: 16 }}>
        <div style={{ fontSize: "0.60rem", fontWeight: 500, textTransform: "uppercase", letterSpacing: "0.10em", color: "rgba(255,255,255,0.22)", marginBottom: 8 }}>Membres</div>
        <div style={{ display: "flex", gap: -4 }}>
          {Array.from({ length: Math.min(8, sal.members) }).map((_, i) => (
            <div key={i} style={{ width: 26, height: 26, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.58rem", fontWeight: 700, background: "var(--bg-raised)", border: "2px solid var(--bg-base)", color: "rgba(255,255,255,0.45)", marginLeft: i > 0 ? -8 : 0 }}>
              {String.fromCharCode(65 + i)}
            </div>
          ))}
          {sal.members > 8 && (
            <div style={{ width: 26, height: 26, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.55rem", background: "var(--bg-raised)", border: "2px solid var(--bg-base)", color: "rgba(255,255,255,0.30)", marginLeft: -8 }}>
              +{sal.members - 8}
            </div>
          )}
        </div>
      </div>

      <button className="sl-btn-primary" style={{ width: "100%", justifyContent: "center", fontSize: "0.82rem", padding: "10px 16px" }}>
        Rejoindre ce SAL
      </button>
    </div>
  );
}

// ─── Main component ───────────────────────────────────────────
export default function SALSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchFocused, setSearchFocused] = useState(false);
  const [activeTab, setActiveTab] = useState<"all" | "dmc" | "amies" | "motifs" | "sal">("all");
  const [activeSalId, setActiveSalId] = useState<number | null>(null);
  const [selectedSal, setSelectedSal] = useState<typeof SALS[0] | null>(null);

  useEffect(() => {
    const obs = new IntersectionObserver(
      (entries) => entries.forEach((e) => {
        if (e.isIntersecting) e.target.querySelectorAll(".fade-up").forEach((el) => el.classList.add("visible"));
      }),
      { threshold: 0.08 }
    );
    if (sectionRef.current) obs.observe(sectionRef.current);
    return () => obs.disconnect();
  }, []);

  const filteredSuggestions = MAGIC_SUGGESTIONS.filter((s) => {
    if (activeTab !== "all" && s.type !== activeTab) return false;
    if (searchQuery && !s.label.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    return true;
  });

  const handleSelectSal = (id: number) => {
    setActiveSalId(id);
    setSelectedSal(SALS.find((s) => s.id === id) || null);
  };

  const TABS = [
    { id: "all",    label: "Tout" },
    { id: "dmc",    label: "DMC" },
    { id: "amies",  label: "Amies" },
    { id: "motifs", label: "Motifs" },
    { id: "sal",    label: "SAL" },
  ] as const;

  return (
    <section
      id="sal"
      ref={sectionRef}
      style={{ background: "var(--bg-base)", padding: "clamp(60px,10vw,80px) 20px", position: "relative", overflow: "hidden" }}
    >
      <div style={{ position: "absolute", top: 0, left: "10%", right: "10%", height: 1, background: "var(--border-subtle)" }} />

      <div style={{ maxWidth: 1100, margin: "0 auto" }}>
        {/* Header */}
        <div style={{ marginBottom: 40 }}>
          <div className="fade-up" style={{ marginBottom: 10 }}>
            <span className="section-label">04 — SAL Sync™</span>
          </div>
          <h2 className="fade-up d1" style={{ fontFamily: "'Geist','Inter',sans-serif", fontWeight: 700, fontSize: "clamp(2rem,4vw,3rem)", lineHeight: 1.1, letterSpacing: "-0.03em", color: "rgba(255,255,255,0.88)", marginBottom: 12 }}>
            Brodez ensemble.<br />
            <span style={{ color: "rgba(255,255,255,0.28)" }}>Partout dans le monde.</span>
          </h2>
          <p className="fade-up d2" style={{ fontSize: "0.88rem", lineHeight: 1.75, color: "rgba(255,255,255,0.38)", maxWidth: 520 }}>
            Rejoignez un Stitch-Along synchronisé. La Recherche Magique connecte les brodeuses par couleur DMC, motif ou affinité — en temps réel.
          </p>
        </div>

        {/* Recherche Magique */}
        <div className="fade-up d1" style={{ marginBottom: 32 }}>
          <div style={{ position: "relative", maxWidth: 560 }}>
            <div style={{ position: "absolute", left: 14, top: "50%", transform: "translateY(-50%)", fontSize: "0.85rem", color: "rgba(255,255,255,0.28)", pointerEvents: "none" }}>◎</div>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onFocus={() => setSearchFocused(true)}
              onBlur={() => setTimeout(() => setSearchFocused(false), 200)}
              placeholder="Recherche magique : DMC, amie, motif, SAL…"
              style={{
                width: "100%", padding: "12px 44px 12px 38px", borderRadius: 10,
                background: "var(--bg-surface)", border: `1px solid ${searchFocused ? "var(--border-default)" : "var(--border-subtle)"}`,
                color: "rgba(255,255,255,0.75)", fontSize: "0.88rem", outline: "none",
                fontFamily: "'Inter',sans-serif", boxSizing: "border-box", transition: "border-color 0.15s",
              }}
            />
            <div style={{ position: "absolute", right: 14, top: "50%", transform: "translateY(-50%)", fontSize: "0.75rem", color: "rgba(255,255,255,0.25)", pointerEvents: "none" }}>✦</div>
          </div>

          {/* Tabs de filtre */}
          <div style={{ display: "flex", gap: 6, marginTop: 10, flexWrap: "wrap" }}>
            {TABS.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                style={{
                  padding: "4px 12px", borderRadius: 20, fontSize: "0.72rem", fontWeight: 500,
                  background: activeTab === tab.id ? "var(--bg-raised)" : "transparent",
                  border: `1px solid ${activeTab === tab.id ? "var(--border-default)" : "var(--border-subtle)"}`,
                  color: activeTab === tab.id ? "rgba(255,255,255,0.75)" : "rgba(255,255,255,0.32)",
                  cursor: "pointer", transition: "all 0.15s",
                }}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Résultats de recherche */}
          {(searchFocused || searchQuery) && (
            <div className="sl-card" style={{ marginTop: 8, padding: "8px 0", maxHeight: 240, overflowY: "auto" }}>
              {filteredSuggestions.length === 0 ? (
                <div style={{ padding: "12px 16px", fontSize: "0.78rem", color: "rgba(255,255,255,0.25)" }}>Aucun résultat</div>
              ) : filteredSuggestions.map((s, i) => (
                <div
                  key={i}
                  style={{ display: "flex", alignItems: "center", gap: 12, padding: "10px 16px", cursor: "pointer", transition: "background 0.12s" }}
                  onMouseEnter={(e) => (e.currentTarget as HTMLElement).style.background = "var(--bg-raised)"}
                  onMouseLeave={(e) => (e.currentTarget as HTMLElement).style.background = "transparent"}
                  onClick={() => {
                    if (s.type === "sal") {
                      const found = SALS.find((sal) => sal.name === s.label);
                      if (found) handleSelectSal(found.id);
                    }
                  }}
                >
                  <div style={{ width: 28, height: 28, borderRadius: 7, display: "flex", alignItems: "center", justifyContent: "center", background: "var(--bg-raised)", border: "1px solid var(--border-subtle)", fontSize: "0.75rem", color: "rgba(255,255,255,0.45)", flexShrink: 0 }}>
                    {s.icon}
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: "0.80rem", fontWeight: 500, color: "rgba(255,255,255,0.72)" }}>{s.label}</div>
                    <div style={{ fontSize: "0.65rem", color: "rgba(255,255,255,0.28)", marginTop: 1 }}>{s.sub}</div>
                  </div>
                  <div style={{ fontSize: "0.60rem", padding: "2px 7px", borderRadius: 10, background: "var(--bg-raised)", border: "1px solid var(--border-subtle)", color: "rgba(255,255,255,0.28)", textTransform: "uppercase", letterSpacing: "0.06em", flexShrink: 0 }}>
                    {s.type}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Carte mondiale */}
        <div className="fade-up d2" style={{ marginBottom: 24 }}>
          <WorldMap activeSalId={activeSalId} onSelect={handleSelectSal} />
        </div>

        {/* Grille : Heatmap + SAL Cards + Détail */}
        <div className="sal-bottom-grid" style={{ display: "grid", gridTemplateColumns: selectedSal ? "1fr 1fr 1fr" : "1fr 2fr", gap: 16 }}>

          {/* Heatmap */}
          <div className="fade-up d2 sl-card" style={{ padding: 18 }}>
            <HeatmapGrid />
          </div>

          {/* Liste SALs */}
          <div className="fade-up d3" style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            <div style={{ fontSize: "0.62rem", fontWeight: 500, textTransform: "uppercase", letterSpacing: "0.10em", color: "rgba(255,255,255,0.28)", marginBottom: 2 }}>SALs en cours</div>
            {SALS.map((sal) => (
              <div
                key={sal.id}
                className="sl-card"
                onClick={() => handleSelectSal(sal.id)}
                style={{ padding: "12px 14px", cursor: "pointer", transition: "all 0.18s", borderColor: activeSalId === sal.id ? "var(--border-default)" : "var(--border-subtle)" }}
                onMouseEnter={(e) => (e.currentTarget as HTMLElement).style.borderColor = "var(--border-default)"}
                onMouseLeave={(e) => (e.currentTarget as HTMLElement).style.borderColor = activeSalId === sal.id ? "var(--border-default)" : "var(--border-subtle)"}
              >
                <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 8 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <div style={{ width: 7, height: 7, borderRadius: "50%", background: sal.color, flexShrink: 0 }} />
                    <div>
                      <div style={{ fontSize: "0.78rem", fontWeight: 600, color: "rgba(255,255,255,0.75)" }}>{sal.name}</div>
                      <div style={{ fontSize: "0.62rem", color: "rgba(255,255,255,0.26)" }}>{sal.city}, {sal.country}</div>
                    </div>
                  </div>
                  <div style={{ fontSize: "0.62rem", padding: "2px 8px", borderRadius: 10, background: "var(--bg-raised)", border: "1px solid var(--border-subtle)", color: "rgba(255,255,255,0.35)", flexShrink: 0 }}>
                    {sal.members} membres
                  </div>
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <div style={{ flex: 1, height: 2, borderRadius: 9999, overflow: "hidden", background: "var(--bg-raised)" }}>
                    <div style={{ height: "100%", width: `${sal.progress}%`, background: sal.color, borderRadius: 9999, opacity: 0.75, transition: "width 1s ease" }} />
                  </div>
                  <span style={{ fontSize: "0.62rem", color: "rgba(255,255,255,0.32)", flexShrink: 0 }}>{sal.progress}%</span>
                </div>
              </div>
            ))}
          </div>

          {/* Panneau détail SAL */}
          {selectedSal && (
            <div className="fade-up">
              <SALDetail sal={selectedSal} onClose={() => { setSelectedSal(null); setActiveSalId(null); }} />
            </div>
          )}
        </div>
      </div>

      <style>{`
        @media (max-width: 900px) {
          .sal-bottom-grid { grid-template-columns: 1fr !important; }
        }
      `}</style>
    </section>
  );
}
