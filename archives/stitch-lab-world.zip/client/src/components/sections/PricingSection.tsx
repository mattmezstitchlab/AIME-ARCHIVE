/**
 * StitchLab PricingSection + WaitlistSection — style Framer/Linear sobre
 * Fond sombre, typographie sobre, accents blanc uniquement
 */
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";

const PLANS = [
  {
    name: "Free",
    price: "0 €",
    period: "Pour toujours",
    sub: null,
    features: [
      { ok: true,  text: "5 patrons" },
      { ok: true,  text: "Inventaire manuel" },
      { ok: true,  text: "Feed social" },
      { ok: true,  text: "Grid World (lecture)" },
      { ok: false, text: "Scan IA" },
      { ok: false, text: "SAL Sync" },
    ],
    cta: "Commencer gratuitement",
    highlight: false,
  },
  {
    name: "Pro",
    price: "4,99 €",
    period: "/mois",
    sub: "ou 44,99 €/an — économisez 25%",
    features: [
      { ok: true, text: "Patrons illimités" },
      { ok: true, text: "Scan IA des fils" },
      { ok: true, text: "Smart Pathing™" },
      { ok: true, text: "Confetti Cleaner™" },
      { ok: true, text: "SAL Sync™" },
      { ok: true, text: "Stitch Diary vidéo" },
      { ok: true, text: "Sync multi-appareils" },
    ],
    cta: "Essai gratuit 30 jours",
    highlight: true,
  },
  {
    name: "Studio",
    price: "14,99 €",
    period: "/mois",
    sub: "Pour les créatrices et designers",
    features: [
      { ok: true, text: "Tout Pro inclus" },
      { ok: true, text: "Création de SAL" },
      { ok: true, text: "Export professionnel" },
      { ok: true, text: "Vente de patrons" },
      { ok: true, text: "Analytics vendeur" },
      { ok: true, text: "Badge Designer Officiel" },
    ],
    cta: "Contacter l'équipe",
    highlight: false,
  },
];

export default function PricingSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [email, setEmail] = useState("");
  const [joined, setJoined] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => entries.forEach((e) => {
        if (e.isIntersecting) e.target.querySelectorAll(".fade-up").forEach((el) => el.classList.add("visible"));
      }),
      { threshold: 0.08 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  const handleJoin = () => {
    if (!email.includes("@")) { toast.error("Adresse email invalide"); return; }
    setJoined(true);
    toast.success("Vous êtes sur la liste — badge Golden Needle réservé.", { duration: 5000 });
  };

  return (
    <section
      id="pricing"
      ref={sectionRef}
      style={{ background: "var(--bg-base)", paddingTop: 80, paddingBottom: 100, position: "relative", overflow: "hidden" }}
    >
      <div style={{ position: "absolute", top: 0, left: "10%", right: "10%", height: 1, background: "var(--border-subtle)" }} />

      <div style={{ maxWidth: 1100, margin: "0 auto", padding: "0 24px" }}>
        {/* Header */}
        <div style={{ marginBottom: 48 }}>
          <div className="fade-up" style={{ marginBottom: 10 }}>
            <span className="section-label">Tarifs</span>
          </div>
          <h2
            className="fade-up d1"
            style={{ fontFamily: "'Geist','Inter',sans-serif", fontWeight: 700, fontSize: "clamp(2rem,4vw,3rem)", lineHeight: 1.1, letterSpacing: "-0.03em", color: "rgba(255,255,255,0.88)", marginBottom: 12 }}
          >
            Le prix de{" "}
            <span style={{ color: "rgba(255,255,255,0.30)" }}>3 échevettes.</span>
          </h2>
          <p className="fade-up d2" style={{ fontSize: "0.88rem", color: "rgba(255,255,255,0.38)", maxWidth: 480 }}>
            Une échevette DMC coûte 1,50 €. L'abonnement Pro coûte 4,99 €/mois — soit le prix de 3 échevettes.
          </p>
        </div>

        {/* Plans */}
        <div className="pricing-grid" style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16, marginBottom: 48 }}>
          {PLANS.map((plan, i) => (
            <div
              key={plan.name}
              className={`fade-up d${i + 1} sl-card`}
              style={{
                padding: 24, display: "flex", flexDirection: "column", position: "relative",
                borderColor: plan.highlight ? "var(--border-default)" : "var(--border-subtle)",
                transform: plan.highlight ? "scale(1.02)" : "scale(1)",
                background: plan.highlight ? "var(--bg-surface)" : "var(--bg-base)",
              }}
            >
              {plan.highlight && (
                <div style={{ position: "absolute", top: -11, left: "50%", transform: "translateX(-50%)", padding: "3px 12px", borderRadius: 20, background: "rgba(255,255,255,0.90)", color: "#0a0a0c", fontSize: "0.62rem", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.08em", whiteSpace: "nowrap" }}>
                  Recommandé
                </div>
              )}

              <div style={{ marginBottom: 20 }}>
                <div style={{ fontSize: "0.68rem", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.10em", color: "rgba(255,255,255,0.35)", marginBottom: 8 }}>{plan.name}</div>
                <div style={{ display: "flex", alignItems: "flex-end", gap: 4 }}>
                  <span style={{ fontWeight: 700, fontSize: "2rem", color: "rgba(255,255,255,0.88)", letterSpacing: "-0.03em" }}>{plan.price}</span>
                  <span style={{ fontSize: "0.78rem", color: "rgba(255,255,255,0.30)", marginBottom: 4 }}>{plan.period}</span>
                </div>
                {plan.sub && <div style={{ fontSize: "0.68rem", color: "rgba(255,255,255,0.25)", marginTop: 4 }}>{plan.sub}</div>}
              </div>

              <div style={{ display: "flex", flexDirection: "column", gap: 8, flex: 1, marginBottom: 20 }}>
                {plan.features.map(({ ok, text }: { ok: boolean; text: string }) => (
                  <div key={text} style={{ display: "flex", alignItems: "center", gap: 10, fontSize: "0.80rem" }}>
                    <div style={{ width: 14, height: 14, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.55rem", flexShrink: 0, background: ok ? "rgba(255,255,255,0.10)" : "transparent", color: ok ? "rgba(255,255,255,0.70)" : "rgba(255,255,255,0.18)", border: ok ? "none" : "1px solid rgba(255,255,255,0.10)" }}>
                      {ok ? "✓" : "–"}
                    </div>
                    <span style={{ color: ok ? "rgba(255,255,255,0.65)" : "rgba(255,255,255,0.22)" }}>{text}</span>
                  </div>
                ))}
              </div>

              <button
                className={plan.highlight ? "sl-btn-primary" : "sl-btn-outline"}
                style={{ width: "100%", justifyContent: "center", fontSize: "0.82rem" }}
                onClick={() => toast.info("Lancement imminent — rejoignez la liste d'attente !")}
              >
                {plan.cta}
              </button>
            </div>
          ))}
        </div>

        <div className="fade-up" style={{ textAlign: "center", fontSize: "0.78rem", color: "rgba(255,255,255,0.25)", marginBottom: 64 }}>
          Essai Pro sans carte bancaire. <strong style={{ color: "rgba(255,255,255,0.50)" }}>30 jours offerts.</strong> Annulation en 1 clic.
        </div>

        {/* Waitlist */}
        <div className="fade-up sl-card" style={{ padding: 48, textAlign: "center" }}>
          <div style={{ fontSize: "0.68rem", fontWeight: 500, textTransform: "uppercase", letterSpacing: "0.10em", color: "rgba(255,255,255,0.28)", marginBottom: 16 }}>
            Lancement imminent
          </div>
          <h3 style={{ fontFamily: "'Geist','Inter',sans-serif", fontWeight: 700, fontSize: "clamp(1.5rem,3vw,2rem)", letterSpacing: "-0.02em", color: "rgba(255,255,255,0.88)", marginBottom: 12 }}>
            Rejoignez la liste d'attente.
          </h3>
          <p style={{ fontSize: "0.88rem", color: "rgba(255,255,255,0.38)", maxWidth: 440, margin: "0 auto 32px" }}>
            Les 1 000 premières inscrites reçoivent le badge <strong style={{ color: "rgba(255,255,255,0.65)" }}>Golden Needle</strong> et 3 mois Pro offerts.
          </p>

          {joined ? (
            <div style={{ display: "inline-flex", alignItems: "center", gap: 12, padding: "16px 24px", borderRadius: 12, background: "var(--bg-raised)", border: "1px solid var(--border-default)" }}>
              <div style={{ fontSize: "0.88rem", fontWeight: 600, color: "rgba(255,255,255,0.80)" }}>Vous êtes sur la liste</div>
              <div style={{ fontSize: "0.75rem", color: "rgba(255,255,255,0.35)" }}>Badge Golden Needle réservé</div>
            </div>
          ) : (
            <div style={{ display: "flex", gap: 8, maxWidth: 420, margin: "0 auto" }}>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="votre@email.com"
                style={{ flex: 1, borderRadius: 8, padding: "10px 14px", fontSize: "0.83rem", outline: "none", background: "var(--bg-raised)", border: "1px solid var(--border-subtle)", color: "rgba(255,255,255,0.75)" }}
                onFocus={(e) => (e.target.style.borderColor = "var(--border-default)")}
                onBlur={(e) => (e.target.style.borderColor = "var(--border-subtle)")}
                onKeyDown={(e) => e.key === "Enter" && handleJoin()}
              />
              <button className="sl-btn-primary" onClick={handleJoin} style={{ fontSize: "0.82rem" }}>
                Rejoindre
              </button>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
