/**
 * StitchLab FeedSection — Étape 05
 * Design: Framer/Linear sobre
 *
 * Fil d'actualité communautaire :
 * - WIP cards avec progression, miniature grille pixel, réactions DMC
 * - Stagger d'entrée au scroll
 * - Filtre par type (Tout / WIP / Terminé / SAL)
 */
import { useEffect, useRef, useState } from "react";

// ─── Data ──────────────────────────────────────────────────────
const FEED_ITEMS = [
  {
    id: 1,
    user: "Sophie M.",
    avatar: "S",
    city: "Paris, FR",
    time: "il y a 12 min",
    type: "wip",
    title: "Renard Folk Art",
    sal: "SAL Botanique de Paris",
    progress: 78,
    colors: ["#C62D42", "#F5C518", "#3CB371", "#14B8A6"],
    reactions: [{ dmc: "321", count: 14 }, { dmc: "726", count: 9 }, { dmc: "3844", count: 6 }],
    comment: "J'adore comment les couleurs se fondent sur cette section ! Le DMC 321 est parfait ici.",
    gridSeed: 12,
    gridSize: 14,
  },
  {
    id: 2,
    user: "Yuki T.",
    avatar: "Y",
    city: "Tokyo, JP",
    time: "il y a 28 min",
    type: "done",
    title: "Sakura en fleurs",
    sal: "SAL Sakura Tokyo",
    progress: 100,
    colors: ["#F4A7B9", "#FFDDE1", "#C62D42", "#F0EAD6"],
    reactions: [{ dmc: "893", count: 31 }, { dmc: "blanc", count: 18 }, { dmc: "321", count: 12 }],
    comment: "Terminé après 3 semaines ! Merci à tout le groupe SAL Sakura 🌸",
    gridSeed: 47,
    gridSize: 14,
  },
  {
    id: 3,
    user: "Ingrid L.",
    avatar: "I",
    city: "Oslo, NO",
    time: "il y a 1h",
    type: "wip",
    title: "Nordic Winter Pattern",
    sal: "SAL Nordic Winter",
    progress: 42,
    colors: ["#6699CC", "#3750A0", "#F0EAD6", "#4A4A4A"],
    reactions: [{ dmc: "517", count: 8 }, { dmc: "blanc", count: 22 }, { dmc: "3750", count: 5 }],
    comment: "La section neige est vraiment technique — les confetti sont nombreux mais le résultat en vaut la peine.",
    gridSeed: 83,
    gridSize: 14,
  },
  {
    id: 4,
    user: "Marie C.",
    avatar: "M",
    city: "Montréal, CA",
    time: "il y a 2h",
    type: "sal",
    title: "Mandala Géométrique",
    sal: "SAL Mandala Montréal",
    progress: 85,
    colors: ["#8B5CF6", "#553C9A", "#D4956A", "#F0EAD6"],
    reactions: [{ dmc: "553", count: 19 }, { dmc: "554", count: 11 }, { dmc: "3837", count: 7 }],
    comment: "On cherche encore 3 membres pour finir le SAL avant le 30 ! Rejoignez-nous.",
    gridSeed: 29,
    gridSize: 14,
  },
];

type FilterType = "all" | "wip" | "done" | "sal";

// ─── Mini grid pixel ──────────────────────────────────────────
function MiniGrid({ seed, size, colors }: { seed: number; size: number; colors: string[] }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d")!;
    const CELL = canvas.width / size;
    for (let r = 0; r < size; r++) {
      for (let c = 0; c < size; c++) {
        const v = Math.sin(r * 0.5 + c * 0.4 + seed) * Math.cos(c * 0.6 - r * 0.3 + seed * 0.5);
        const idx = Math.abs(Math.floor((v + 1) * colors.length / 2)) % colors.length;
        ctx.globalAlpha = 0.85;
        ctx.fillStyle = colors[idx];
        ctx.fillRect(c * CELL + 0.3, r * CELL + 0.3, CELL - 0.6, CELL - 0.6);
      }
    }
  }, [seed, size, colors]);
  return (
    <canvas ref={ref} width={140} height={140}
      style={{ display: "block", width: 70, height: 70, borderRadius: 6, flexShrink: 0 }} />
  );
}

// ─── WIP Card ─────────────────────────────────────────────────
function WIPCard({ item, delay }: { item: typeof FEED_ITEMS[0]; delay: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const [liked, setLiked] = useState<string | null>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { el.style.opacity = "1"; el.style.transform = "translateY(0)"; } },
      { threshold: 0.15 }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  const typeLabel = item.type === "wip" ? "En cours" : item.type === "done" ? "Terminé" : "SAL";
  const typeColor = item.type === "done" ? "rgba(255,255,255,0.55)" : "rgba(255,255,255,0.28)";

  return (
    <div
      ref={ref}
      className="sl-card"
      style={{
        padding: 18, opacity: 0,
        transform: `translateY(${16 + delay * 4}px)`,
        transition: `opacity 0.5s cubic-bezier(0.23,1,0.32,1) ${delay * 60}ms, transform 0.5s cubic-bezier(0.23,1,0.32,1) ${delay * 60}ms`,
      }}
    >
      {/* Header */}
      <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 12 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ width: 32, height: 32, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", background: "var(--bg-raised)", border: "1px solid var(--border-subtle)", fontSize: "0.72rem", fontWeight: 700, color: "rgba(255,255,255,0.55)", flexShrink: 0 }}>
            {item.avatar}
          </div>
          <div>
            <div style={{ fontSize: "0.78rem", fontWeight: 600, color: "rgba(255,255,255,0.75)" }}>{item.user}</div>
            <div style={{ fontSize: "0.62rem", color: "rgba(255,255,255,0.26)" }}>{item.city} · {item.time}</div>
          </div>
        </div>
        <div style={{ fontSize: "0.60rem", padding: "2px 8px", borderRadius: 10, background: "var(--bg-raised)", border: "1px solid var(--border-subtle)", color: typeColor, letterSpacing: "0.04em" }}>
          {typeLabel}
        </div>
      </div>

      {/* Contenu */}
      <div style={{ display: "flex", gap: 12, marginBottom: 12 }}>
        <MiniGrid seed={item.gridSeed} size={item.gridSize} colors={item.colors} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontWeight: 600, fontSize: "0.88rem", color: "rgba(255,255,255,0.80)", marginBottom: 3 }}>{item.title}</div>
          <div style={{ fontSize: "0.65rem", color: "rgba(255,255,255,0.28)", marginBottom: 8 }}>{item.sal}</div>
          <div style={{ marginBottom: 6 }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
              <span style={{ fontSize: "0.60rem", color: "rgba(255,255,255,0.25)" }}>Avancement</span>
              <span style={{ fontSize: "0.60rem", color: "rgba(255,255,255,0.40)", fontWeight: 600 }}>{item.progress}%</span>
            </div>
            <div style={{ height: 2, borderRadius: 9999, background: "var(--bg-raised)", overflow: "hidden" }}>
              <div style={{ height: "100%", width: `${item.progress}%`, background: item.colors[0], borderRadius: 9999, opacity: 0.75, transition: "width 1s ease" }} />
            </div>
          </div>
          <p style={{ fontSize: "0.72rem", color: "rgba(255,255,255,0.38)", lineHeight: 1.55, margin: 0 }}>{item.comment}</p>
        </div>
      </div>

      {/* Réactions DMC */}
      <div style={{ display: "flex", gap: 6, flexWrap: "wrap", paddingTop: 10, borderTop: "1px solid var(--border-subtle)" }}>
        {item.reactions.map((r) => (
          <button
            key={r.dmc}
            onClick={() => setLiked(liked === r.dmc ? null : r.dmc)}
            style={{
              display: "flex", alignItems: "center", gap: 5, padding: "3px 10px", borderRadius: 20,
              background: liked === r.dmc ? "var(--bg-raised)" : "transparent",
              border: `1px solid ${liked === r.dmc ? "var(--border-default)" : "var(--border-subtle)"}`,
              cursor: "pointer", transition: "all 0.15s",
            }}
          >
            <div style={{ width: 7, height: 7, borderRadius: "50%", background: item.colors[item.reactions.indexOf(r) % item.colors.length] }} />
            <span style={{ fontSize: "0.65rem", color: "rgba(255,255,255,0.45)", fontWeight: 500 }}>DMC {r.dmc}</span>
            <span style={{ fontSize: "0.62rem", color: "rgba(255,255,255,0.28)" }}>{r.count + (liked === r.dmc ? 1 : 0)}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

// ─── Main component ───────────────────────────────────────────
export default function FeedSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [filter, setFilter] = useState<FilterType>("all");

  useEffect(() => {
    const obs = new IntersectionObserver(
      (entries) => entries.forEach((e) => {
        if (e.isIntersecting) e.target.querySelectorAll(".fade-up").forEach((el) => el.classList.add("visible"));
      }),
      { threshold: 0.08 }
    );
    if (sectionRef.current) obs.observe(sectionRef.current);
    return () => obs.disconnect();
  }, []);

  const filtered = FEED_ITEMS.filter((item) => filter === "all" || item.type === filter);

  const FILTERS: { id: FilterType; label: string }[] = [
    { id: "all",  label: "Tout" },
    { id: "wip",  label: "En cours" },
    { id: "done", label: "Terminé" },
    { id: "sal",  label: "SAL" },
  ];

  return (
    <section
      id="feed"
      ref={sectionRef}
      style={{ background: "var(--bg-base)", padding: "clamp(60px,10vw,80px) 20px", position: "relative", overflow: "hidden" }}
    >
      <div style={{ position: "absolute", top: 0, left: "10%", right: "10%", height: 1, background: "var(--border-subtle)" }} />

      <div style={{ maxWidth: 1100, margin: "0 auto" }}>
        {/* Header */}
        <div style={{ marginBottom: 36 }}>
          <div className="fade-up" style={{ marginBottom: 10 }}>
            <span className="section-label">05 — Communauté</span>
          </div>
          <h2 className="fade-up d1" style={{ fontFamily: "'Geist','Inter',sans-serif", fontWeight: 700, fontSize: "clamp(2rem,4vw,3rem)", lineHeight: 1.1, letterSpacing: "-0.03em", color: "rgba(255,255,255,0.88)", marginBottom: 12 }}>
            Partagez chaque point.<br />
            <span style={{ color: "rgba(255,255,255,0.28)" }}>Réagissez en DMC.</span>
          </h2>
          <p className="fade-up d2" style={{ fontSize: "0.88rem", lineHeight: 1.75, color: "rgba(255,255,255,0.38)", maxWidth: 500 }}>
            Le premier réseau social où les réactions sont des couleurs DMC. Suivez les WIP de la communauté, rejoignez des SALs, partagez votre avancement.
          </p>
        </div>

        {/* Filtres */}
        <div className="fade-up d1" style={{ display: "flex", gap: 6, marginBottom: 24, flexWrap: "wrap" }}>
          {FILTERS.map((f) => (
            <button
              key={f.id}
              onClick={() => setFilter(f.id)}
              style={{
                padding: "5px 14px", borderRadius: 20, fontSize: "0.75rem", fontWeight: 500,
                background: filter === f.id ? "var(--bg-raised)" : "transparent",
                border: `1px solid ${filter === f.id ? "var(--border-default)" : "var(--border-subtle)"}`,
                color: filter === f.id ? "rgba(255,255,255,0.75)" : "rgba(255,255,255,0.32)",
                cursor: "pointer", transition: "all 0.15s",
              }}
            >
              {f.label}
            </button>
          ))}
          <div style={{ marginLeft: "auto", fontSize: "0.68rem", color: "rgba(255,255,255,0.22)", display: "flex", alignItems: "center", gap: 5 }}>
            <div style={{ width: 5, height: 5, borderRadius: "50%", background: "#14B8A6" }} />
            {filtered.length} publications
          </div>
        </div>

        {/* Grille de cards */}
        <div className="feed-grid" style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 14 }}>
          {filtered.map((item, i) => (
            <WIPCard key={item.id} item={item} delay={i} />
          ))}
        </div>

        {/* CTA */}
        <div className="fade-up d3" style={{ marginTop: 28, textAlign: "center" }}>
          <button className="sl-btn-outline" style={{ fontSize: "0.82rem" }}>
            Voir tout le fil communautaire
          </button>
        </div>
      </div>

      <style>{`
        @media (max-width: 768px) { .feed-grid { grid-template-columns: 1fr !important; } }
      `}</style>
    </section>
  );
}
