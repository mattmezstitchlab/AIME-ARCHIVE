/**
 * StitchLab AtelierSection — Étape 02
 * Design: Framer/Linear sobre — fond sombre, accents blanc uniquement
 *
 * Fonctionnalités :
 * - Système de mots-clés en cascade (thème → sous-thème → style)
 * - 3 niveaux de difficulté (Facile / Détaillée / Premium)
 * - Formats Aida avec dimensions en cm
 * - Palettes DMC harmonieuses par thème
 * - Curseur drag Avant/Après sur la grille pixel réaliste
 * - Score brodabilité avec stats confetti/changements/fils
 * - Palette DMC dans l'ordre de travail
 */
import { useCallback, useEffect, useRef, useState } from "react";
import {
  Flower2, Rabbit, Mountain, Sparkles, Leaf, Waves, Moon,
  Scissors, Repeat2, Palette, Zap, Grid3x3, ChevronRight,
} from "lucide-react";
import {
  KEYWORD_TREE,
  HARMONIOUS_PALETTES,
  ETSY_TOP_THEMES,
  getAidaFormats,
  generatePattern,
  renderPatternToCanvas,
  type GeneratedPattern,
} from "@/lib/patternEngine";

// Mapping thème → icône Lucide
const THEME_ICONS: Record<string, React.ReactNode> = {
  fleurs:       <Flower2 style={{ width: 13, height: 13 }} />,
  animaux:      <Rabbit  style={{ width: 13, height: 13 }} />,
  paysages:     <Mountain style={{ width: 13, height: 13 }} />,
  geometrie:    <Grid3x3 style={{ width: 13, height: 13 }} />,
  saisons:      <Leaf    style={{ width: 13, height: 13 }} />,
  ocean_theme:  <Waves   style={{ width: 13, height: 13 }} />,
  nuit:         <Moon    style={{ width: 13, height: 13 }} />,
};

// Icône de sous-thème générique par catégorie parente
const SUB_ICONS: Record<string, React.ReactNode> = {
  fleurs:       <Flower2 style={{ width: 14, height: 14 }} />,
  animaux:      <Rabbit  style={{ width: 14, height: 14 }} />,
  paysages:     <Mountain style={{ width: 14, height: 14 }} />,
  geometrie:    <Sparkles style={{ width: 14, height: 14 }} />,
  saisons:      <Leaf    style={{ width: 14, height: 14 }} />,
  ocean_theme:  <Waves   style={{ width: 14, height: 14 }} />,
  nuit:         <Moon    style={{ width: 14, height: 14 }} />,
};

// ─── Difficulty levels ────────────────────────────────────────────────────
const DIFFICULTY_LEVELS = [
  { id: "easy",     icon: "◈", label: "Facile",    desc: "Peu de couleurs, zones lisibles, parfaite débutante.", size: 24, maxColors: 5,  spec: "36×36 · 5 DMC" },
  { id: "detailed", icon: "◇", label: "Détaillée", desc: "Bon équilibre entre rendu visuel et plaisir de broder.", size: 32, maxColors: 8,  spec: "56×56 · 8 DMC" },
  { id: "premium",  icon: "◆", label: "Premium",   desc: "Rendu riche, plus proche illustration et marketplace.", size: 40, maxColors: 10, spec: "72×72 · 10 DMC" },
] as const;
type DifficultyId = "easy" | "detailed" | "premium";

// ─── GridCanvas ───────────────────────────────────────────────────────────
function PatternCanvas({ pattern, withNoise = false }: { pattern: GeneratedPattern; withNoise?: boolean }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const c = ref.current;
    if (!c || !pattern) return;
    c.width = 320; c.height = 320;
    renderPatternToCanvas(c, pattern.grid, pattern.palette, pattern.size, true, 1.0);
    if (withNoise) {
      const ctx = c.getContext("2d")!;
      const CELL = 320 / pattern.size;
      ctx.globalAlpha = 0.20;
      for (let n = 0; n < pattern.confetti * 4; n++) {
        const rx = Math.floor(Math.random() * pattern.size);
        const ry = Math.floor(Math.random() * pattern.size);
        const colorIdx = Math.floor(Math.random() * (pattern.palette.length - 1)) + 1;
        ctx.fillStyle = pattern.palette[colorIdx]?.hex || "#888";
        ctx.fillRect(rx * CELL + 1, ry * CELL + 1, CELL - 2, CELL - 2);
      }
      ctx.globalAlpha = 1;
    }
  }, [pattern, withNoise]);
  return (
    <canvas
      ref={ref}
      style={{ display: "block", width: "100%", height: "auto", imageRendering: "pixelated" }}
    />
  );
}

// ─── BeforeAfterSlider ────────────────────────────────────────────────────
function BeforeAfterSlider({ pattern }: { pattern: GeneratedPattern }) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [pct, setPct] = useState(50);
  const dragging = useRef(false);

  const update = (clientX: number) => {
    const rect = containerRef.current?.getBoundingClientRect();
    if (!rect) return;
    setPct(Math.max(2, Math.min(98, ((clientX - rect.left) / rect.width) * 100)));
  };

  return (
    <div
      ref={containerRef}
      onMouseDown={(e) => { dragging.current = true; update(e.clientX); }}
      onMouseMove={(e) => { if (dragging.current) update(e.clientX); }}
      onMouseUp={() => { dragging.current = false; }}
      onMouseLeave={() => { dragging.current = false; }}
      onTouchStart={(e) => { e.preventDefault(); update(e.touches[0].clientX); }}
      onTouchMove={(e) => { e.preventDefault(); update(e.touches[0].clientX); }}
      style={{ position: "relative", borderRadius: 10, overflow: "hidden", cursor: "col-resize", userSelect: "none", aspectRatio: "1", border: "1px solid var(--border-subtle)", background: "#0a0a0b" }}
    >
      {/* Après IA — fond complet */}
      <div style={{ position: "absolute", inset: 0 }}>
        <PatternCanvas pattern={pattern} withNoise={false} />
      </div>
      {/* Avant — clipé à gauche (avec bruit confetti) */}
      <div style={{ position: "absolute", inset: 0, clipPath: `inset(0 ${100 - pct}% 0 0)` }}>
        <PatternCanvas pattern={pattern} withNoise={true} />
        <div style={{ position: "absolute", inset: 0, background: "rgba(10,10,11,0.28)" }} />
      </div>
      {/* Séparateur */}
      <div style={{ position: "absolute", top: 0, bottom: 0, left: `${pct}%`, transform: "translateX(-50%)", width: 2, background: "rgba(255,255,255,0.85)", pointerEvents: "none" }}>
        <div style={{ position: "absolute", top: "50%", left: "50%", transform: "translate(-50%,-50%)", width: 28, height: 28, borderRadius: "50%", background: "rgba(255,255,255,0.95)", display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "0 2px 12px rgba(0,0,0,0.5)", fontSize: "0.60rem", color: "#0a0a0b", fontWeight: 800 }}>⟨⟩</div>
      </div>
      <div style={{ position: "absolute", top: 8, left: 8, padding: "2px 7px", borderRadius: 5, background: "rgba(10,10,11,0.72)", fontSize: "0.56rem", fontWeight: 600, color: "rgba(255,255,255,0.45)", letterSpacing: "0.08em", textTransform: "uppercase" }}>Avant</div>
      <div style={{ position: "absolute", top: 8, right: 8, padding: "2px 7px", borderRadius: 5, background: "rgba(255,255,255,0.10)", fontSize: "0.56rem", fontWeight: 600, color: "rgba(255,255,255,0.80)", letterSpacing: "0.08em", textTransform: "uppercase" }}>Après IA</div>
      <div style={{ position: "absolute", bottom: 8, left: "50%", transform: "translateX(-50%)", fontSize: "0.56rem", color: "rgba(255,255,255,0.20)", whiteSpace: "nowrap", pointerEvents: "none" }}>← Glissez pour comparer →</div>
    </div>
  );
}

// ─── Main component ───────────────────────────────────────────────────────
export default function AtelierSection() {
  const sectionRef = useRef<HTMLDivElement>(null);

  // Cascade state
  const [selectedTheme, setSelectedTheme] = useState<string>("fleurs");
  const [selectedSub, setSelectedSub] = useState<string>("rose");
  const [selectedStyle, setSelectedStyle] = useState<string>("Réaliste");
  const [selectedAida, setSelectedAida] = useState<number>(0); // index dans getAidaFormats
  const [difficulty, setDifficulty] = useState<DifficultyId>("detailed");

  // Generation state
  const [pattern, setPattern] = useState<GeneratedPattern | null>(null);
  const [generating, setGenerating] = useState(false);
  const [showResult, setShowResult] = useState(false);

  const level = DIFFICULTY_LEVELS.find((d) => d.id === difficulty)!;
  const themeNode = KEYWORD_TREE[selectedTheme];
  const subNode = themeNode?.children[selectedSub];
  const styles = subNode?.styles || [];
  const aidaFormats = getAidaFormats(level.size);

  // When theme changes, reset sub to first child
  useEffect(() => {
    const firstSub = Object.keys(KEYWORD_TREE[selectedTheme]?.children || {})[0];
    if (firstSub) {
      setSelectedSub(firstSub);
      const firstStyle = KEYWORD_TREE[selectedTheme]?.children[firstSub]?.styles[0];
      if (firstStyle) setSelectedStyle(firstStyle);
    }
  }, [selectedTheme]);

  // When sub changes, reset style
  useEffect(() => {
    const firstStyle = subNode?.styles[0];
    if (firstStyle) setSelectedStyle(firstStyle);
  }, [selectedSub]);

  // Fade-in observer
  useEffect(() => {
    const obs = new IntersectionObserver(
      (entries) => entries.forEach((e) => {
        if (e.isIntersecting) e.target.querySelectorAll(".fade-up").forEach((el) => el.classList.add("visible"));
      }),
      { threshold: 0.06 }
    );
    if (sectionRef.current) obs.observe(sectionRef.current);
    return () => obs.disconnect();
  }, []);

  const handleGenerate = useCallback(() => {
    if (generating) return;
    setGenerating(true);
    setShowResult(false);
    const seed = Math.random();
    const prompt = `${subNode?.label || selectedSub} ${selectedStyle}`;
    setTimeout(() => {
      const result = generatePattern(prompt, level.size, seed);
      setPattern(result);
      setGenerating(false);
      setTimeout(() => setShowResult(true), 200);
    }, 800);
  }, [generating, selectedSub, selectedStyle, level.size, subNode]);

  const maxPts = pattern?.palette[0]?.points || 1;

  return (
    <section
      id="atelier"
      ref={sectionRef}
      style={{ background: "var(--bg-base)", padding: "clamp(60px,10vw,80px) 20px", position: "relative", overflow: "hidden" }}
    >
      <div style={{ position: "absolute", top: 0, left: "10%", right: "10%", height: 1, background: "var(--border-subtle)" }} />

      <div style={{ maxWidth: 1100, margin: "0 auto" }}>
        {/* Header */}
        <div style={{ marginBottom: 36 }}>
          <div className="fade-up" style={{ marginBottom: 10 }}>
            <span className="section-label">02 — Atelier IA</span>
          </div>
          <h2 className="fade-up d1" style={{ fontFamily: "'Geist','Inter',sans-serif", fontWeight: 700, fontSize: "clamp(2rem,4vw,3rem)", lineHeight: 1.1, letterSpacing: "-0.03em", color: "rgba(255,255,255,0.88)", marginBottom: 10 }}>
            Générez. Comparez.<br />
            <span style={{ color: "rgba(255,255,255,0.28)" }}>Brodez.</span>
          </h2>
          <p className="fade-up d2" style={{ fontSize: "0.86rem", lineHeight: 1.75, color: "rgba(255,255,255,0.38)", maxWidth: 520 }}>
            Choisissez un thème, un motif, un style — l'IA génère un patron 100% brodable en quelques secondes. Glissez le curseur pour comparer Avant / Après nettoyage IA.
          </p>
        </div>

        <div className="atelier-grid" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "clamp(24px,4vw,48px)", alignItems: "start" }}>

          {/* ── Colonne gauche : Configurateur ── */}
          <div className="fade-up d1" style={{ display: "flex", flexDirection: "column", gap: 16 }}>

            {/* ÉTAPE 1 — Thème principal */}
            <div className="sl-card" style={{ padding: 18 }}>
              <div style={{ fontSize: "0.60rem", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.12em", color: "rgba(255,255,255,0.25)", marginBottom: 10 }}>
                Thème principal
              </div>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                {ETSY_TOP_THEMES.map((key) => {
                  const node = KEYWORD_TREE[key];
                  const active = selectedTheme === key;
                  return (
                    <button
                      key={key}
                      onClick={() => setSelectedTheme(key)}
                      style={{
                        display: "flex", alignItems: "center", gap: 6,
                        padding: "5px 11px", borderRadius: 20, fontSize: "0.72rem", fontWeight: active ? 600 : 400,
                        background: active ? "rgba(255,255,255,0.10)" : "var(--bg-raised)",
                        border: `1px solid ${active ? "rgba(255,255,255,0.30)" : "var(--border-subtle)"}`,
                        color: active ? "rgba(255,255,255,0.88)" : "rgba(255,255,255,0.38)",
                        cursor: "pointer", transition: "all 0.15s",
                      }}
                    >
                      <span style={{ opacity: active ? 1 : 0.55, display: "flex", alignItems: "center" }}>{THEME_ICONS[key] || <Sparkles style={{ width: 13, height: 13 }} />}</span>
                      <span>{node.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* ÉTAPE 2 — Sous-thème */}
            {themeNode && (
              <div className="sl-card" style={{ padding: 18 }}>
                <div style={{ fontSize: "0.60rem", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.12em", color: "rgba(255,255,255,0.25)", marginBottom: 10 }}>
                  Motif
                </div>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(110px, 1fr))", gap: 6 }}>
                  {Object.entries(themeNode.children).map(([key, child]) => {
                    const active = selectedSub === key;
                    return (
                      <button
                        key={key}
                        onClick={() => setSelectedSub(key)}
                        style={{
                          padding: "8px 10px", borderRadius: 8, textAlign: "left",
                          background: active ? "rgba(255,255,255,0.08)" : "var(--bg-raised)",
                          border: `1px solid ${active ? "rgba(255,255,255,0.25)" : "var(--border-subtle)"}`,
                          cursor: "pointer", transition: "all 0.15s",
                        }}
                      >
                        <div style={{ marginBottom: 5, color: active ? "rgba(255,255,255,0.70)" : "rgba(255,255,255,0.22)", display: "flex" }}>
                          {SUB_ICONS[selectedTheme] || <Sparkles style={{ width: 14, height: 14 }} />}
                        </div>
                        <div style={{ fontSize: "0.68rem", fontWeight: active ? 600 : 400, color: active ? "rgba(255,255,255,0.85)" : "rgba(255,255,255,0.40)", lineHeight: 1.3 }}>{child.label}</div>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* ÉTAPE 3 — Style */}
            {styles.length > 0 && (
              <div className="sl-card" style={{ padding: 18 }}>
                <div style={{ fontSize: "0.60rem", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.12em", color: "rgba(255,255,255,0.25)", marginBottom: 10 }}>
                  Style
                </div>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 5 }}>
                  {styles.map((s) => {
                    const active = selectedStyle === s;
                    return (
                      <button
                        key={s}
                        onClick={() => setSelectedStyle(s)}
                        style={{
                          padding: "4px 11px", borderRadius: 20, fontSize: "0.70rem",
                          background: active ? "rgba(255,255,255,0.10)" : "var(--bg-raised)",
                          border: `1px solid ${active ? "rgba(255,255,255,0.28)" : "var(--border-subtle)"}`,
                          color: active ? "rgba(255,255,255,0.85)" : "rgba(255,255,255,0.35)",
                          cursor: "pointer", transition: "all 0.15s",
                        }}
                      >{s}</button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* ÉTAPE 4 — Niveau + Format Aida */}
            <div className="sl-card" style={{ padding: 18 }}>
              <div style={{ fontSize: "0.60rem", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.12em", color: "rgba(255,255,255,0.25)", marginBottom: 10 }}>
                Niveau de difficulté
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 5, marginBottom: 14 }}>
                {DIFFICULTY_LEVELS.map((lvl) => {
                  const active = difficulty === lvl.id;
                  return (
                    <button
                      key={lvl.id}
                      onClick={() => { setDifficulty(lvl.id); setShowResult(false); setPattern(null); }}
                      style={{ display: "flex", alignItems: "center", gap: 12, padding: "10px 14px", borderRadius: 8, textAlign: "left", background: active ? "rgba(255,255,255,0.07)" : "var(--bg-raised)", border: `1px solid ${active ? "rgba(255,255,255,0.22)" : "var(--border-subtle)"}`, cursor: "pointer", transition: "all 0.15s" }}
                    >
                      <span style={{ fontSize: "0.95rem", color: active ? "rgba(255,255,255,0.75)" : "rgba(255,255,255,0.20)" }}>{lvl.icon}</span>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: "0.76rem", fontWeight: 600, color: active ? "rgba(255,255,255,0.82)" : "rgba(255,255,255,0.38)" }}>{lvl.label}</div>
                        <div style={{ fontSize: "0.65rem", color: "rgba(255,255,255,0.22)", marginTop: 1 }}>{lvl.desc}</div>
                      </div>
                      <span style={{ fontSize: "0.60rem", color: active ? "rgba(255,255,255,0.45)" : "rgba(255,255,255,0.15)", letterSpacing: "0.04em" }}>{lvl.spec}</span>
                    </button>
                  );
                })}
              </div>

              {/* Format Aida */}
              <div style={{ fontSize: "0.60rem", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.12em", color: "rgba(255,255,255,0.25)", marginBottom: 8 }}>
                Format tissu Aida
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 5 }}>
                {aidaFormats.map((fmt, i) => {
                  const active = selectedAida === i;
                  return (
                    <button
                      key={fmt.label}
                      onClick={() => setSelectedAida(i)}
                      style={{ padding: "7px 10px", borderRadius: 7, textAlign: "left", background: active ? "rgba(255,255,255,0.07)" : "var(--bg-raised)", border: `1px solid ${active ? "rgba(255,255,255,0.22)" : "var(--border-subtle)"}`, cursor: "pointer", transition: "all 0.15s" }}
                    >
                      <div style={{ fontSize: "0.68rem", fontWeight: 600, color: active ? "rgba(255,255,255,0.80)" : "rgba(255,255,255,0.38)" }}>{fmt.label}</div>
                      <div style={{ fontSize: "0.60rem", color: "rgba(255,255,255,0.22)", marginTop: 1 }}>{fmt.widthCm} × {fmt.heightCm} cm</div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Bouton générer */}
            <button
              className="sl-btn-primary"
              onClick={handleGenerate}
              disabled={generating}
              style={{ width: "100%", justifyContent: "center", fontSize: "0.86rem", padding: "13px 20px" }}
            >
              {generating ? (
                <span style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <span style={{ display: "inline-block", width: 14, height: 14, border: "2px solid rgba(255,255,255,0.3)", borderTopColor: "rgba(255,255,255,0.85)", borderRadius: "50%", animation: "spin 0.8s linear infinite" }} />
                  Génération en cours…
                </span>
              ) : (
                `Générer — ${subNode?.label || selectedSub} · ${selectedStyle}`
              )}
            </button>
          </div>

          {/* ── Colonne droite : Résultat ── */}
          <div className="fade-up d2" style={{ display: "flex", flexDirection: "column", gap: 14 }}>

            {!pattern ? (
              <div className="sl-card" style={{ padding: 24, aspectRatio: "1", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 14 }}>
                <div style={{ fontSize: "2.8rem", opacity: 0.08 }}>◈</div>
                <div style={{ fontSize: "0.73rem", color: "rgba(255,255,255,0.18)", textAlign: "center", lineHeight: 1.6 }}>
                  Sélectionnez un thème, un motif<br />et un style, puis générez
                </div>
              </div>
            ) : showResult ? (
              <>
                {/* Comparaison Avant/Après */}
                <div>
                  <div style={{ fontSize: "0.60rem", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.12em", color: "rgba(255,255,255,0.25)", marginBottom: 8 }}>
                    Glissez le curseur — Avant confetti / Après IA
                  </div>
                  <BeforeAfterSlider pattern={pattern} />
                </div>

                {/* Score brodabilité */}
                <div className="sl-card" style={{ padding: 16 }}>
                  <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 12 }}>
                    <div>
                      <div style={{ fontSize: "0.58rem", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.12em", color: "rgba(255,255,255,0.25)", marginBottom: 3 }}>Brodabilité</div>
                      <div style={{ fontFamily: "'Geist','Inter',sans-serif", fontWeight: 700, fontSize: "2.0rem", letterSpacing: "-0.04em", color: "rgba(255,255,255,0.88)", lineHeight: 1 }}>
                        {pattern.score}<span style={{ fontSize: "0.85rem", color: "rgba(255,255,255,0.25)" }}>/100</span>
                      </div>
                      <div style={{ fontSize: "0.66rem", color: "rgba(255,255,255,0.30)", marginTop: 3 }}>
                        {pattern.score >= 85 ? "Excellent — parfait débutante" : pattern.score >= 70 ? "Très bon, quelques optimisations" : "Complexe — niveau confirmé"}
                      </div>
                    </div>
                    <svg width="44" height="44" viewBox="0 0 44 44" style={{ transform: "rotate(-90deg)", flexShrink: 0 }}>
                      <circle cx="22" cy="22" r="18" fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="3" />
                      <circle cx="22" cy="22" r="18" fill="none" stroke="rgba(255,255,255,0.55)" strokeWidth="3"
                        strokeDasharray={`${(pattern.score / 100) * 113.1} 113.1`} strokeLinecap="round" />
                    </svg>
                  </div>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 7 }}>
                    {[
                      { label: "Confetti", value: pattern.confetti, icon: <Scissors style={{ width: 11, height: 11 }} /> },
                      { label: "Changements", value: pattern.changes, icon: <Repeat2 style={{ width: 11, height: 11 }} /> },
                      { label: "Couleurs", value: pattern.palette.filter(p => p.points > 0).length, icon: <Palette style={{ width: 11, height: 11 }} /> },
                    ].map((s) => (
                      <div key={s.label} style={{ padding: "9px 7px", borderRadius: 7, background: "var(--bg-raised)", border: "1px solid var(--border-subtle)", textAlign: "center" }}>
                        <div style={{ fontSize: "0.70rem", color: "rgba(255,255,255,0.28)", marginBottom: 2 }}>{s.icon}</div>
                        <div style={{ fontWeight: 700, fontSize: "0.95rem", color: "rgba(255,255,255,0.75)", letterSpacing: "-0.02em" }}>{s.value}</div>
                        <div style={{ fontSize: "0.55rem", color: "rgba(255,255,255,0.20)", textTransform: "uppercase", letterSpacing: "0.06em", marginTop: 1 }}>{s.label}</div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Dimensions Aida */}
                <div className="sl-card" style={{ padding: 14, display: "flex", alignItems: "center", gap: 12 }}>
                  <div style={{ fontSize: "0.60rem", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.10em", color: "rgba(255,255,255,0.25)", flexShrink: 0 }}>Format</div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: "0.78rem", fontWeight: 600, color: "rgba(255,255,255,0.72)" }}>
                      {aidaFormats[selectedAida]?.label} — {aidaFormats[selectedAida]?.widthCm} × {aidaFormats[selectedAida]?.heightCm} cm
                    </div>
                    <div style={{ fontSize: "0.62rem", color: "rgba(255,255,255,0.22)", marginTop: 2 }}>
                      {level.size} × {level.size} points · {aidaFormats[selectedAida]?.count} fils/cm
                    </div>
                  </div>
                </div>

                {/* Palette DMC dans l'ordre de travail */}
                <div className="sl-card" style={{ padding: 16 }}>
                  <div style={{ fontSize: "0.60rem", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.12em", color: "rgba(255,255,255,0.25)", marginBottom: 10 }}>
                    Palette DMC — ordre de travail
                  </div>
                  <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                    {pattern.palette.filter(d => d.points > 0).slice(0, 8).map((dmc, i) => (
                      <div key={dmc.code} style={{ display: "flex", alignItems: "center", gap: 9 }}>
                        <div style={{ width: 20, height: 20, borderRadius: 5, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.58rem", fontWeight: 700, flexShrink: 0, background: dmc.hex + "22", color: dmc.hex, border: `1px solid ${dmc.hex}44` }}>
                          {i + 1}
                        </div>
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <div style={{ fontSize: "0.70rem", fontWeight: 500, color: "rgba(255,255,255,0.55)", marginBottom: 2 }}>
                            DMC {dmc.code} · {dmc.name}
                          </div>
                          <div style={{ height: 2, borderRadius: 9999, background: "var(--bg-raised)", overflow: "hidden" }}>
                            <div style={{ height: "100%", width: `${(dmc.points / maxPts) * 100}%`, background: dmc.hex, borderRadius: 9999, opacity: 0.65, transition: "width 0.8s cubic-bezier(0.23,1,0.32,1)" }} />
                          </div>
                        </div>
                        <div style={{ fontSize: "0.58rem", color: "rgba(255,255,255,0.22)", flexShrink: 0, fontVariantNumeric: "tabular-nums" }}>{dmc.points}</div>
                      </div>
                    ))}
                  </div>
                  <div style={{ marginTop: 8, fontSize: "0.60rem", color: "rgba(255,255,255,0.16)", fontStyle: "italic" }}>
                    À broder dans l'ordre — zones continues en premier
                  </div>
                </div>
              </>
            ) : (
              <div className="sl-card" style={{ padding: 24, aspectRatio: "1", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 10 }}>
                <div style={{ width: 32, height: 32, border: "2px solid rgba(255,255,255,0.15)", borderTopColor: "rgba(255,255,255,0.65)", borderRadius: "50%", animation: "spin 0.8s linear infinite" }} />
                <div style={{ fontSize: "0.70rem", color: "rgba(255,255,255,0.25)" }}>Génération du patron…</div>
              </div>
            )}
          </div>
        </div>
      </div>

      <style>{`
        @media (max-width: 768px) { .atelier-grid { grid-template-columns: 1fr !important; } }
        @keyframes spin { to { transform: rotate(360deg); } }
      `}</style>
    </section>
  );
}
