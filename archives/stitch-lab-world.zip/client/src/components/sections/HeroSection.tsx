/**
 * HeroSection — "Clique et Brode"
 * Style Framer/Linear — fond très sombre, typographie légère
 * Flow complet : Galerie → Grille → SAL Sync → Confetti Cleaner → Smart Pathing → Preuve
 */

import { useEffect, useRef, useState, useCallback } from "react";
import { Star, Users, Zap, Award, ChevronRight, X, Play, SkipForward, Check } from "lucide-react";
import { REALISTIC_PATTERNS, type RealisticPattern } from "@/lib/realisticPatterns";

// ─── CANVAS FOND QUI RESPIRE EN BOUCLE ──────────────────────────────────────────────
// Pixels de 8px — grille serrée type tissu Aida
const PIXEL_SIZE = 8; // taille d'un pixel en px
const BREATH_COLORS = [
  "#8b5cf6", "#14b8a6", "#f59e0b", "#10b981", "#f15156",
  "#3b82f6", "#ec4899", "#84cc16", "#f97316", "#06b6d4",
];

function BreathingCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rafRef = useRef<number>(0);
  // Grille générée une seule fois
  const cellsRef = useRef<{ colorIdx: number; phase: number; speed: number; baseAlpha: number }[][]>([]);

  const buildCells = useCallback((cols: number, rows: number) => {
    cellsRef.current = Array.from({ length: rows }, (_, r) =>
      Array.from({ length: cols }, (_, c) => ({
        colorIdx: Math.abs(Math.floor(Math.sin(r * 0.7 + c * 0.5) * BREATH_COLORS.length)) % BREATH_COLORS.length,
        phase: (r * cols + c) * 0.37 + Math.sin(r + c) * 2.1,
        speed: 0.3 + ((r * 13 + c * 7) % 10) * 0.05,
        baseAlpha: 0.10 + ((r * 7 + c * 3) % 8) * 0.015,
      }))
    );
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let t = 0;
    let cols = 0, rows = 0;

    const resize = () => {
      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
      cols = Math.ceil(canvas.width / PIXEL_SIZE) + 1;
      rows = Math.ceil(canvas.height / PIXEL_SIZE) + 1;
      buildCells(cols, rows);
    };

    resize();
    window.addEventListener("resize", resize);

    const draw = () => {
      const W = canvas.width;
      const H = canvas.height;
      ctx.clearRect(0, 0, W, H);

      const cells = cellsRef.current;
      for (let r = 0; r < rows; r++) {
        if (!cells[r]) continue;
        for (let c = 0; c < cols; c++) {
          const cell = cells[r][c];
          if (!cell) continue;
          // Respiration douce : chaque pixel a sa propre phase
          const alpha = cell.baseAlpha + Math.sin(t * cell.speed + cell.phase) * 0.07;
          ctx.globalAlpha = Math.max(0.02, Math.min(0.28, alpha));
          ctx.fillStyle = BREATH_COLORS[cell.colorIdx];
          // Pixel carré avec 1px de gap (comme un vrai tissu Aida)
          ctx.fillRect(c * PIXEL_SIZE + 1, r * PIXEL_SIZE + 1, PIXEL_SIZE - 2, PIXEL_SIZE - 2);
        }
      }
      ctx.globalAlpha = 1;
      t += 0.015;
      rafRef.current = requestAnimationFrame(draw);
    };

    draw();
    return () => {
      cancelAnimationFrame(rafRef.current);
      window.removeEventListener("resize", resize);
    };
  }, [buildCells]);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full"
      style={{ imageRendering: "pixelated", pointerEvents: "none" }}
    />
  );
}

// ─── TYPES ────────────────────────────────────────────────────────────────────
type FlowStep = "gallery" | "grid" | "sal" | "confetti" | "pathing" | "proof";

interface SALBroideuse {
  name: string;
  country: string;
  flag: string;
  color: string;
  progress: number;
}

interface ConfettiParticle {
  x: number;
  y: number;
  color: string;
  vx: number;
  vy: number;
  life: number;
  size: number;
  rotation: number;
}

// ─── CANVAS PATRON MINIATURE ──────────────────────────────────────────────────
function PatternCanvas({ pattern, size = 120 }: { pattern: RealisticPattern; size?: number }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const { grid, width, height, palette } = pattern;
    const colorMap: Record<number, string> = {};
    palette.forEach((p, i) => { colorMap[i + 1] = p.hex; });
    const cw = size / width, ch = size / height;
    ctx.fillStyle = "#f8f5f0";
    ctx.fillRect(0, 0, size, size);
    for (let r = 0; r < height; r++) {
      for (let c = 0; c < width; c++) {
        const v = grid[r]?.[c];
        if (v && v > 0 && colorMap[v]) {
          ctx.fillStyle = colorMap[v];
          ctx.fillRect(c * cw, r * ch, cw, ch);
        }
      }
    }
  }, [pattern, size]);

  return <canvas ref={canvasRef} width={size} height={size} style={{ imageRendering: "pixelated", display: "block" }} />;
}

// ─── CANVAS PATRON INTERACTIF (grand) ────────────────────────────────────────
function InteractiveCanvas({
  pattern, revealedCells, pathPoints, showSlider, sliderX,
}: {
  pattern: RealisticPattern;
  revealedCells: Set<string>;
  pathPoints: [number, number][];
  showSlider: boolean;
  sliderX: number;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const CELL = 13;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const { grid, width, height, palette } = pattern;
    const colorMap: Record<number, string> = {};
    palette.forEach((p, i) => { colorMap[i + 1] = p.hex; });
    const W = width * CELL, H = height * CELL;
    canvas.width = W; canvas.height = H;

    // Fond
    ctx.fillStyle = "#f8f5f0";
    ctx.fillRect(0, 0, W, H);

    // Grille légère
    ctx.strokeStyle = "rgba(0,0,0,0.05)";
    ctx.lineWidth = 0.5;
    for (let r = 0; r <= height; r++) {
      ctx.beginPath(); ctx.moveTo(0, r * CELL); ctx.lineTo(W, r * CELL); ctx.stroke();
    }
    for (let c = 0; c <= width; c++) {
      ctx.beginPath(); ctx.moveTo(c * CELL, 0); ctx.lineTo(c * CELL, H); ctx.stroke();
    }

    // Pixels
    for (let r = 0; r < height; r++) {
      for (let c = 0; c < width; c++) {
        const v = grid[r]?.[c];
        if (!v || v === 0) continue;
        const hex = colorMap[v];
        if (!hex) continue;
        const key = `${r},${c}`;
        const px = c * CELL, py = r * CELL;

        if (showSlider) {
          if (px < sliderX) {
            // Zone propre
            ctx.fillStyle = hex;
            ctx.fillRect(px + 0.5, py + 0.5, CELL - 1, CELL - 1);
          } else {
            // Zone brouillon avec confettis
            ctx.fillStyle = hex;
            ctx.globalAlpha = 0.25;
            ctx.fillRect(px + 0.5, py + 0.5, CELL - 1, CELL - 1);
            ctx.globalAlpha = 1;
            const seed = r * 97 + c * 53;
            const confColors = ["#FF6B6B", "#FFE66D", "#4ECDC4", "#A8E6CF", "#FF8B94", "#C084FC"];
            for (let i = 0; i < 4; i++) {
              ctx.fillStyle = confColors[(seed + i * 7) % confColors.length];
              ctx.fillRect(
                px + ((seed * (i + 1) * 37) % (CELL - 2)),
                py + ((seed * (i + 1) * 53) % (CELL - 2)),
                2, 2
              );
            }
          }
        } else if (revealedCells.has(key)) {
          ctx.fillStyle = hex;
          ctx.fillRect(px + 0.5, py + 0.5, CELL - 1, CELL - 1);
        } else {
          ctx.fillStyle = "rgba(180,170,160,0.25)";
          ctx.fillRect(px + 0.5, py + 0.5, CELL - 1, CELL - 1);
          ctx.fillStyle = "rgba(100,90,80,0.2)";
          ctx.font = `${CELL * 0.45}px monospace`;
          ctx.textAlign = "center";
          ctx.textBaseline = "middle";
          ctx.fillText("×", px + CELL / 2, py + CELL / 2);
        }
      }
    }

    // Ligne de séparation slider
    if (showSlider && sliderX > 0 && sliderX < W) {
      ctx.strokeStyle = "rgba(255,255,255,0.8)";
      ctx.lineWidth = 2;
      ctx.shadowColor = "rgba(255,255,255,0.5)";
      ctx.shadowBlur = 6;
      ctx.beginPath();
      ctx.moveTo(sliderX, 0);
      ctx.lineTo(sliderX, H);
      ctx.stroke();
      ctx.shadowBlur = 0;
    }

    // Smart Pathing
    if (pathPoints.length > 1) {
      ctx.strokeStyle = "rgba(255,255,255,0.9)";
      ctx.lineWidth = 2;
      ctx.shadowColor = "#ffffff";
      ctx.shadowBlur = 8;
      ctx.setLineDash([3, 3]);
      ctx.beginPath();
      const [r0, c0] = pathPoints[0];
      ctx.moveTo(c0 * CELL + CELL / 2, r0 * CELL + CELL / 2);
      for (let i = 1; i < pathPoints.length; i++) {
        const [ri, ci] = pathPoints[i];
        ctx.lineTo(ci * CELL + CELL / 2, ri * CELL + CELL / 2);
      }
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.shadowBlur = 0;

      // Points de départ / arrivée
      const [rs, cs] = pathPoints[0];
      ctx.fillStyle = "#FFD700";
      ctx.shadowColor = "#FFD700";
      ctx.shadowBlur = 8;
      ctx.beginPath();
      ctx.arc(cs * CELL + CELL / 2, rs * CELL + CELL / 2, 4, 0, Math.PI * 2);
      ctx.fill();

      const [re, ce] = pathPoints[pathPoints.length - 1];
      ctx.fillStyle = "#00FF88";
      ctx.shadowColor = "#00FF88";
      ctx.beginPath();
      ctx.arc(ce * CELL + CELL / 2, re * CELL + CELL / 2, 4, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;
    }
  }, [pattern, revealedCells, pathPoints, showSlider, sliderX]);

  return (
    <canvas
      ref={canvasRef}
      style={{ imageRendering: "pixelated", maxWidth: "100%", maxHeight: "100%", display: "block" }}
    />
  );
}

// ─── COMPOSANT PRINCIPAL ──────────────────────────────────────────────────────
export default function HeroSection() {
  const [step, setStep] = useState<FlowStep>("gallery");
  const [selectedPattern, setSelectedPattern] = useState<RealisticPattern | null>(null);
  const [revealedCells, setRevealedCells] = useState<Set<string>>(new Set());
  const [salBroideuses, setSalBroideuses] = useState<SALBroideuse[]>([]);
  const [salProgress, setSalProgress] = useState(0);
  const [sliderX, setSliderX] = useState(0);
  const [showSlider, setShowSlider] = useState(false);
  const [pathPoints, setPathPoints] = useState<[number, number][]>([]);
  const [pathProgress, setPathProgress] = useState(0);
  const [confettiParticles, setConfettiParticles] = useState<ConfettiParticle[]>([]);
  const [galleryFilter, setGalleryFilter] = useState("Tous");
  const [hoveredId, setHoveredId] = useState<string | null>(null);

  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const animRef = useRef<number>(0);

  const BROIDEUSES: SALBroideuse[] = [
    { name: "Marie-Claire", country: "France", flag: "🇫🇷", color: "#E8475F", progress: 0 },
    { name: "Yuki", country: "Japon", flag: "🇯🇵", color: "#4ECDC4", progress: 0 },
    { name: "Sofia", country: "Espagne", flag: "🇪🇸", color: "#FFD700", progress: 0 },
    { name: "Emma", country: "UK", flag: "🇬🇧", color: "#A8E6CF", progress: 0 },
    { name: "Ingrid", country: "Suède", flag: "🇸🇪", color: "#FF8B94", progress: 0 },
  ];

  const CATEGORIES = ["Tous", "Animaux", "Géométrique", "Nature", "Fantaisie", "Fleurs", "Paysages"];
  const filtered = galleryFilter === "Tous" ? REALISTIC_PATTERNS : REALISTIC_PATTERNS.filter(p => p.category === galleryFilter);

  const clearTimers = useCallback(() => {
    if (timerRef.current) clearTimeout(timerRef.current);
    if (intervalRef.current) clearInterval(intervalRef.current);
    cancelAnimationFrame(animRef.current);
  }, []);

  // ─── DÉMARRER L'EXPÉRIENCE ──────────────────────────────────────────────────
  const startExperience = useCallback((pattern: RealisticPattern) => {
    clearTimers();
    setSelectedPattern(pattern);
    setRevealedCells(new Set());
    setSalBroideuses(BROIDEUSES.map(b => ({ ...b, progress: 0 })));
    setSalProgress(0);
    setSliderX(0);
    setShowSlider(false);
    setPathPoints([]);
    setPathProgress(0);
    setConfettiParticles([]);
    setStep("grid");
  }, [clearTimers]);

  // ─── ÉTAPE 1 : RÉVÉLATION GRILLE ────────────────────────────────────────────
  useEffect(() => {
    if (step !== "grid" || !selectedPattern) return;
    const { grid, width, height } = selectedPattern;
    const allCells: [number, number][] = [];
    for (let r = 0; r < height; r++)
      for (let c = 0; c < width; c++)
        if ((grid[r]?.[c] ?? 0) > 0) allCells.push([r, c]);

    // Mélange Fisher-Yates
    for (let i = allCells.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [allCells[i], allCells[j]] = [allCells[j], allCells[i]];
    }

    let idx = 0;
    const batch = Math.max(1, Math.ceil(allCells.length / 35));
    intervalRef.current = setInterval(() => {
      setRevealedCells(prev => {
        const next = new Set(prev);
        for (let i = 0; i < batch && idx < allCells.length; i++, idx++)
          next.add(`${allCells[idx][0]},${allCells[idx][1]}`);
        return next;
      });
      if (idx >= allCells.length) {
        clearInterval(intervalRef.current!);
        timerRef.current = setTimeout(() => setStep("sal"), 900);
      }
    }, 45);

    return () => clearTimers();
  }, [step, selectedPattern]);

  // ─── ÉTAPE 2 : SAL SYNC ─────────────────────────────────────────────────────
  useEffect(() => {
    if (step !== "sal") return;
    let prog = 0;
    intervalRef.current = setInterval(() => {
      prog = Math.min(100, prog + 2.5);
      setSalProgress(prog);
      setSalBroideuses(prev => prev.map((b, i) => ({
        ...b,
        progress: Math.min(100, prog + (i % 3 === 0 ? 5 : i % 3 === 1 ? -3 : 2)),
      })));
      if (prog >= 100) {
        clearInterval(intervalRef.current!);
        timerRef.current = setTimeout(() => {
          setShowSlider(true);
          setStep("confetti");
        }, 700);
      }
    }, 70);
    return () => clearTimers();
  }, [step]);

  // ─── ÉTAPE 3 : CONFETTI CLEANER ─────────────────────────────────────────────
  useEffect(() => {
    if (step !== "confetti" || !selectedPattern) return;
    const maxX = selectedPattern.width * 13;
    setSliderX(maxX);
    let x = maxX;
    intervalRef.current = setInterval(() => {
      x = Math.max(0, x - 10);
      setSliderX(x);
      if (x <= 0) {
        clearInterval(intervalRef.current!);
        timerRef.current = setTimeout(() => {
          setShowSlider(false);
          setStep("pathing");
        }, 600);
      }
    }, 25);
    return () => clearTimers();
  }, [step, selectedPattern]);

  // ─── ÉTAPE 4 : SMART PATHING ────────────────────────────────────────────────
  useEffect(() => {
    if (step !== "pathing" || !selectedPattern) return;
    const { grid, width, height, palette } = selectedPattern;

    // Grouper par couleur
    const groups: Record<number, [number, number][]> = {};
    for (let r = 0; r < height; r++)
      for (let c = 0; c < width; c++) {
        const v = grid[r]?.[c] ?? 0;
        if (v > 0) { if (!groups[v]) groups[v] = []; groups[v].push([r, c]); }
      }

    // Top 4 couleurs → chemin nearest-neighbor
    const fullPath: [number, number][] = [];
    const topColors = Object.entries(groups)
      .sort((a, b) => b[1].length - a[1].length)
      .slice(0, 4)
      .map(([k]) => Number(k));

    for (const colorIdx of topColors) {
      const cells = [...(groups[colorIdx] || [])];
      if (!cells.length) continue;
      let cur = cells[0];
      const rem = new Set(cells.map(([r, c]) => `${r},${c}`));
      fullPath.push(cur);
      rem.delete(`${cur[0]},${cur[1]}`);
      let safety = 0;
      while (rem.size > 0 && safety++ < 300) {
        let best: [number, number] | null = null, minD = Infinity;
        for (const key of Array.from(rem)) {
          const [r, c] = key.split(",").map(Number) as [number, number];
          const d = Math.abs(r - cur[0]) + Math.abs(c - cur[1]);
          if (d < minD) { minD = d; best = [r, c]; }
          if (minD <= 1) break;
        }
        if (!best) break;
        cur = best;
        fullPath.push(cur);
        rem.delete(`${cur[0]},${cur[1]}`);
      }
    }

    let idx = 0;
    intervalRef.current = setInterval(() => {
      idx = Math.min(idx + 4, fullPath.length);
      setPathPoints(fullPath.slice(0, idx));
      setPathProgress(Math.round((idx / fullPath.length) * 100));
      if (idx >= fullPath.length) {
        clearInterval(intervalRef.current!);
        timerRef.current = setTimeout(() => {
          setStep("proof");
          launchConfetti();
        }, 500);
      }
    }, 25);

    return () => clearTimers();
  }, [step, selectedPattern]);

  // ─── CONFETTIS DE CÉLÉBRATION ────────────────────────────────────────────────
  const launchConfetti = useCallback(() => {
    const particles: ConfettiParticle[] = Array.from({ length: 80 }, (_, i) => ({
      x: 30 + Math.random() * 40,
      y: 20 + Math.random() * 30,
      color: ["#FFD700", "#FF6B6B", "#4ECDC4", "#A8E6CF", "#FF8B94", "#C0C0C0", "#E8475F"][i % 7],
      vx: (Math.random() - 0.5) * 2,
      vy: Math.random() * 2 + 0.5,
      life: 1,
      size: 4 + Math.random() * 4,
      rotation: Math.random() * 360,
    }));
    setConfettiParticles(particles);

    let frame = 0;
    const animate = () => {
      frame++;
      setConfettiParticles(prev =>
        prev.map(p => ({ ...p, x: p.x + p.vx, y: p.y + p.vy, life: p.life - 0.008, rotation: p.rotation + 3 }))
            .filter(p => p.life > 0)
      );
      if (frame < 150) animRef.current = requestAnimationFrame(animate);
    };
    animRef.current = requestAnimationFrame(animate);
  }, []);

  // ─── SKIP ────────────────────────────────────────────────────────────────────
  const skip = useCallback(() => {
    clearTimers();
    if (step === "grid" && selectedPattern) {
      const { grid, width, height } = selectedPattern;
      const all = new Set<string>();
      for (let r = 0; r < height; r++)
        for (let c = 0; c < width; c++)
          if ((grid[r]?.[c] ?? 0) > 0) all.add(`${r},${c}`);
      setRevealedCells(all);
      setStep("sal");
    } else if (step === "sal") {
      setSalProgress(100);
      setSalBroideuses(prev => prev.map(b => ({ ...b, progress: 100 })));
      setShowSlider(true);
      setStep("confetti");
    } else if (step === "confetti") {
      setShowSlider(false);
      setStep("pathing");
    } else if (step === "pathing") {
      setStep("proof");
      launchConfetti();
    }
  }, [step, selectedPattern, clearTimers, launchConfetti]);

  const closeExperience = useCallback(() => {
    clearTimers();
    setStep("gallery");
    setSelectedPattern(null);
  }, [clearTimers]);

  useEffect(() => () => clearTimers(), [clearTimers]);

  const STEP_LABELS: Record<FlowStep, string> = {
    gallery: "", grid: "Découverte", sal: "SAL Sync", confetti: "Confetti Cleaner", pathing: "Smart Pathing", proof: "Preuve débloquée",
  };
  const STEP_ORDER: FlowStep[] = ["grid", "sal", "confetti", "pathing", "proof"];

  // ════════════════════════════════════════════════════════════════════════════
  // RENDER — GALERIE
  // ════════════════════════════════════════════════════════════════════════════
  if (step === "gallery") {
    return (
      <section id="hero" className="relative min-h-screen bg-[#080808] overflow-hidden">
        {/* Animation fond canvas pixels qui respirent */}
        <BreathingCanvas />
        {/* Vignette pour assombrir les bords et garder le texte lisible */}
        <div className="absolute inset-0 pointer-events-none" style={{
          background: "radial-gradient(ellipse 80% 70% at 50% 50%, transparent 20%, rgba(8,8,8,0.7) 70%, rgba(8,8,8,0.95) 100%)",
        }} />

        {/* Hero text */}
        <div className="relative z-10 pt-28 pb-8 px-6 text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-white/10 bg-white/[0.03] mb-8">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-[11px] text-white/40 tracking-[0.15em] uppercase">12 patrons · Broderie point de croix</span>
          </div>

          <h1 className="font-light text-white tracking-tight leading-[0.95] mb-5" style={{ fontSize: "clamp(3rem,8vw,6.5rem)" }}>
            Clique.
            <br /><span style={{ color: "rgba(255,255,255,0.35)" }}>Brode.</span>
            <br /><span style={{ color: "rgba(255,255,255,0.15)" }}>Prouve.</span>
          </h1>

          <p className="text-white/35 font-light max-w-sm mx-auto leading-relaxed" style={{ fontSize: "clamp(0.9rem,2vw,1.05rem)" }}>
            Choisis un patron. Vis l'expérience complète — SAL Sync, Confetti Cleaner, Smart Pathing — en moins d'une minute.
          </p>

          <div className="mt-6 flex justify-center">
            <div className="flex flex-col items-center gap-1.5 text-white/20">
              <span className="text-[10px] tracking-[0.2em] uppercase">Choisir un patron</span>
              <ChevronRight className="w-3.5 h-3.5 rotate-90 animate-bounce" />
            </div>
          </div>
        </div>

        {/* Filtres */}
        <div className="relative z-10 flex gap-2 px-6 pb-6 overflow-x-auto justify-center flex-wrap">
          {CATEGORIES.map(cat => (
            <button
              key={cat}
              onClick={() => setGalleryFilter(cat)}
              className="px-3 py-1.5 rounded-full text-[11px] tracking-wide transition-all duration-200 whitespace-nowrap"
              style={{
                background: galleryFilter === cat ? "white" : "transparent",
                color: galleryFilter === cat ? "black" : "rgba(255,255,255,0.35)",
                border: galleryFilter === cat ? "1px solid white" : "1px solid rgba(255,255,255,0.1)",
                fontWeight: galleryFilter === cat ? 500 : 400,
              }}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Grille patrons */}
        <div className="relative z-10 px-4 pb-16">
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3 max-w-7xl mx-auto">
            {filtered.map(pattern => (
              <PatternCard
                key={pattern.id}
                pattern={pattern}
                isHovered={hoveredId === pattern.id}
                onHover={setHoveredId}
                onSelect={startExperience}
              />
            ))}
          </div>
        </div>

        {/* Stats */}
        <div className="relative z-10 border-t border-white/[0.04] py-6 px-6">
          <div className="flex justify-center gap-10 sm:gap-16">
            {[["12", "Patrons"], ["4 281", "Brodeuses actives"], ["847", "SAL en cours"]].map(([v, l]) => (
              <div key={l} className="text-center">
                <div className="text-white font-light" style={{ fontSize: "clamp(1.2rem,3vw,1.8rem)" }}>{v}</div>
                <div className="text-white/25 text-[10px] tracking-wide mt-1 uppercase">{l}</div>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  // ════════════════════════════════════════════════════════════════════════════
  // RENDER — EXPÉRIENCE INTERACTIVE
  // ════════════════════════════════════════════════════════════════════════════
  const currentStepIdx = STEP_ORDER.indexOf(step);

  return (
    <section id="hero" className="relative min-h-screen bg-[#080808] flex flex-col overflow-hidden">
      {/* Confettis — scopés dans la section, pas fixed */}
      {confettiParticles.map((p, i) => (
        <div key={i} className="absolute pointer-events-none z-50" style={{
          left: `${p.x}%`, top: `${p.y}%`,
          width: p.size, height: p.size,
          backgroundColor: p.color,
          opacity: p.life,
          transform: `rotate(${p.rotation}deg)`,
          borderRadius: i % 3 === 0 ? "50%" : "2px",
        }} />
      ))}

      {/* Barre de navigation étapes */}
      <div className="relative z-20 pt-20 px-4 sm:px-6 pb-3">
        <div className="max-w-5xl mx-auto">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2.5">
              <button onClick={closeExperience} className="p-1.5 rounded-full border border-white/10 text-white/30 hover:text-white/70 hover:border-white/25 transition-all">
                <X className="w-3.5 h-3.5" />
              </button>
              <span className="text-white/50 text-sm font-light truncate max-w-[160px] sm:max-w-none">{selectedPattern?.name}</span>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-white/25 text-xs hidden sm:block">{STEP_LABELS[step]}</span>
              {step !== "proof" && (
                <button onClick={skip} className="flex items-center gap-1 px-2 py-1 rounded text-[11px] text-white/25 hover:text-white/55 transition-all">
                  <SkipForward className="w-3 h-3" />
                  Passer
                </button>
              )}
            </div>
          </div>

          {/* Barre de progression */}
          <div className="flex items-center gap-1.5">
            {STEP_ORDER.map((s, i) => (
              <div key={s} className="flex-1 flex items-center gap-1.5">
                <div className="flex-1 h-0.5 rounded-full overflow-hidden" style={{ background: "rgba(255,255,255,0.06)" }}>
                  <div className="h-full rounded-full transition-all duration-700" style={{
                    width: i < currentStepIdx ? "100%" : i === currentStepIdx ? "60%" : "0%",
                    background: i < currentStepIdx ? "white" : "rgba(255,255,255,0.5)",
                  }} />
                </div>
                <div className="w-1.5 h-1.5 rounded-full flex-shrink-0 transition-all duration-300" style={{
                  background: i < currentStepIdx ? "white" : "rgba(255,255,255,0.1)",
                }} />
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Contenu */}
      <div className="flex-1 flex flex-col lg:flex-row gap-3 px-4 pb-4 max-w-5xl mx-auto w-full">
        {/* Canvas */}
        <div className="flex-1 flex items-center justify-center rounded-2xl border border-white/[0.04] overflow-hidden relative min-h-[360px]" style={{ background: "#0d0d0d" }}>
          {selectedPattern && (
            <div className="overflow-auto p-3 flex items-center justify-center w-full h-full">
              <InteractiveCanvas
                pattern={selectedPattern}
                revealedCells={revealedCells}
                pathPoints={pathPoints}
                showSlider={showSlider}
                sliderX={sliderX}
              />
            </div>
          )}

          {/* Overlay étape en cours */}
          {step === "grid" && (
            <div className="absolute bottom-3 left-3 right-3 flex items-center gap-2.5 rounded-xl px-3.5 py-2.5 border border-white/[0.06]" style={{ background: "rgba(0,0,0,0.7)", backdropFilter: "blur(8px)" }}>
              <div className="flex gap-0.5">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="w-0.5 rounded-full bg-white/30" style={{
                    height: 8 + Math.abs(Math.sin(Date.now() / 300 + i * 0.8)) * 8,
                    transition: "height 0.15s ease",
                  }} />
                ))}
              </div>
              <span className="text-white/50 text-xs">Révélation du patron…</span>
            </div>
          )}

          {step === "confetti" && (
            <div className="absolute top-3 left-3 right-3 flex items-center justify-between rounded-xl px-3.5 py-2.5 border border-white/[0.06]" style={{ background: "rgba(0,0,0,0.7)", backdropFilter: "blur(8px)" }}>
              <span className="text-white/50 text-xs">Confetti Cleaner</span>
              <div className="flex items-center gap-2">
                <span className="text-white/25 text-[10px]">Brouillon</span>
                <div className="w-20 h-1 rounded-full overflow-hidden" style={{ background: "rgba(255,255,255,0.08)" }}>
                  <div className="h-full bg-white rounded-full transition-all" style={{
                    width: `${100 - (sliderX / ((selectedPattern?.width || 1) * 13)) * 100}%`,
                  }} />
                </div>
                <span className="text-white/50 text-[10px]">Propre</span>
              </div>
            </div>
          )}

          {step === "pathing" && (
            <div className="absolute bottom-3 left-3 right-3 rounded-xl px-3.5 py-2.5 border border-white/[0.06]" style={{ background: "rgba(0,0,0,0.7)", backdropFilter: "blur(8px)" }}>
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-white/50 text-xs">Smart Pathing</span>
                <span className="text-white/30 text-[10px]">{pathProgress}%</span>
              </div>
              <div className="w-full h-0.5 rounded-full overflow-hidden" style={{ background: "rgba(255,255,255,0.08)" }}>
                <div className="h-full rounded-full transition-all" style={{
                  width: `${pathProgress}%`,
                  background: "linear-gradient(90deg, #FFD700, #00FF88)",
                }} />
              </div>
            </div>
          )}
        </div>

        {/* Panneau latéral */}
        <div className="lg:w-64 flex flex-col gap-2.5">
          {/* Info patron */}
          {selectedPattern && (
            <div className="rounded-2xl border border-white/[0.04] p-4" style={{ background: "#0d0d0d" }}>
              <div className="flex items-start justify-between mb-2">
                <div>
                  <h3 className="text-white/80 font-light text-sm leading-tight">{selectedPattern.name}</h3>
                  <p className="text-white/30 text-[11px] mt-0.5">{selectedPattern.category} · {selectedPattern.difficulty}</p>
                </div>
                <div className="text-right flex-shrink-0 ml-2">
                  <div className="text-white/70 font-light text-sm">{selectedPattern.price.toFixed(2)}€</div>
                  <div className="flex items-center gap-0.5 mt-0.5 justify-end">
                    <Star className="w-2.5 h-2.5 text-yellow-400 fill-yellow-400" />
                    <span className="text-white/30 text-[10px]">{selectedPattern.rating}</span>
                  </div>
                </div>
              </div>
              <div className="flex gap-1 flex-wrap">
                {selectedPattern.palette.slice(0, 10).map(p => (
                  <div key={p.dmc} className="w-3.5 h-3.5 rounded-sm border border-white/10" style={{ backgroundColor: p.hex }} title={`DMC ${p.dmc}`} />
                ))}
                {selectedPattern.palette.length > 10 && (
                  <div className="w-3.5 h-3.5 rounded-sm border border-white/10 flex items-center justify-center" style={{ background: "rgba(255,255,255,0.04)" }}>
                    <span className="text-white/25" style={{ fontSize: 7 }}>+{selectedPattern.palette.length - 10}</span>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* SAL Sync */}
          {(step === "sal" || step === "confetti" || step === "pathing" || step === "proof") && (
            <div className="rounded-2xl border border-white/[0.04] p-4" style={{ background: "#0d0d0d" }}>
              <div className="flex items-center gap-2 mb-3">
                <Users className="w-3.5 h-3.5 text-white/30" />
                <span className="text-white/50 text-xs">SAL Sync</span>
                <div className="ml-auto flex items-center gap-1">
                  <span className="w-1 h-1 rounded-full bg-emerald-400 animate-pulse" />
                  <span className="text-emerald-400 text-[10px]">En direct</span>
                </div>
              </div>
              <div className="space-y-2">
                {salBroideuses.map((b, i) => (
                  <div key={b.name} className="flex items-center gap-2" style={{
                    opacity: Math.min(1, Math.max(0, (salProgress - i * 18) / 18)),
                    transform: `translateX(${Math.max(0, 8 - (salProgress - i * 18) / 2)}px)`,
                    transition: "all 0.3s ease-out",
                  }}>
                    <div className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-medium flex-shrink-0" style={{
                      background: b.color + "20", color: b.color, border: `1px solid ${b.color}30`,
                    }}>
                      {b.name[0]}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <span className="text-white/60 text-[11px] truncate">{b.name}</span>
                        <span className="text-white/20 text-[10px] ml-1">{b.flag}</span>
                      </div>
                      <div className="w-full h-0.5 rounded-full mt-1 overflow-hidden" style={{ background: "rgba(255,255,255,0.05)" }}>
                        <div className="h-full rounded-full transition-all duration-300" style={{ width: `${b.progress}%`, backgroundColor: b.color }} />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              {step === "sal" && (
                <div className="mt-3 pt-3 border-t border-white/[0.04]">
                  <div className="flex justify-between text-[10px] mb-1">
                    <span className="text-white/25">Synchronisation</span>
                    <span className="text-white/45">{Math.round(salProgress)}%</span>
                  </div>
                  <div className="w-full h-0.5 rounded-full overflow-hidden" style={{ background: "rgba(255,255,255,0.06)" }}>
                    <div className="h-full bg-emerald-400 rounded-full transition-all duration-100" style={{ width: `${salProgress}%` }} />
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Smart Pathing détail */}
          {(step === "pathing" || step === "proof") && selectedPattern && (
            <div className="rounded-2xl border border-white/[0.04] p-4" style={{ background: "#0d0d0d" }}>
              <div className="flex items-center gap-2 mb-3">
                <Zap className="w-3.5 h-3.5 text-white/30" />
                <span className="text-white/50 text-xs">Chemin optimal</span>
              </div>
              <div className="space-y-1.5">
                {selectedPattern.palette.slice(0, 5).map((p, i) => (
                  <div key={p.dmc} className="flex items-center gap-2">
                    <div className="w-2.5 h-2.5 rounded-sm flex-shrink-0" style={{ backgroundColor: p.hex }} />
                    <span className="text-white/35 text-[10px] flex-1">DMC {p.dmc}</span>
                    <div className="w-12 h-0.5 rounded-full overflow-hidden" style={{ background: "rgba(255,255,255,0.06)" }}>
                      <div className="h-full rounded-full transition-all duration-500" style={{
                        width: step === "proof" ? "100%" : `${Math.max(0, pathProgress - i * 18)}%`,
                        backgroundColor: p.hex,
                      }} />
                    </div>
                    {(step === "proof" || pathProgress > (i + 1) * 18) && (
                      <Check className="w-2.5 h-2.5 text-emerald-400 flex-shrink-0" />
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Preuve débloquée */}
          {step === "proof" && selectedPattern && (
            <div className="rounded-2xl p-4 relative overflow-hidden" style={{
              background: "#0d0d0d",
              border: "1px solid rgba(255,215,0,0.15)",
            }}>
              <div className="absolute inset-0" style={{
                background: "radial-gradient(ellipse at 50% 0%, rgba(255,215,0,0.06) 0%, transparent 70%)",
              }} />
              <div className="relative">
                <div className="flex items-center gap-2 mb-3">
                  <Award className="w-4 h-4 text-yellow-400" />
                  <span className="text-yellow-400/80 text-xs">Preuve de broderie</span>
                </div>
                <div className="text-center py-3">
                  <div className="w-14 h-14 rounded-full mx-auto mb-3 flex items-center justify-center" style={{
                    background: "radial-gradient(circle, rgba(255,215,0,0.15) 0%, rgba(255,215,0,0.03) 100%)",
                    border: "1.5px solid rgba(255,215,0,0.4)",
                    boxShadow: "0 0 24px rgba(255,215,0,0.15)",
                  }}>
                    <Award className="w-7 h-7 text-yellow-400" />
                  </div>
                  <div className="text-white/70 font-light text-sm">{selectedPattern.name}</div>
                  <div className="text-white/25 text-[10px] mt-1">Complété avec SAL Sync</div>
                  <div className="text-white/15 text-[10px] mt-0.5">
                    {new Date().toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" })}
                  </div>
                </div>
                <div className="flex gap-2">
                  <button onClick={closeExperience} className="flex-1 py-2 rounded-xl text-[11px] text-white/35 hover:text-white/60 transition-all" style={{ border: "1px solid rgba(255,255,255,0.08)" }}>
                    Retour
                  </button>
                  <button className="flex-1 py-2 rounded-xl text-[11px] text-yellow-400/80 hover:text-yellow-400 transition-all" style={{ border: "1px solid rgba(255,215,0,0.2)", background: "rgba(255,215,0,0.05)" }}>
                    Partager
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

// ─── CARTE PATRON ─────────────────────────────────────────────────────────────
function PatternCard({
  pattern, isHovered, onHover, onSelect,
}: {
  pattern: RealisticPattern;
  isHovered: boolean;
  onHover: (id: string | null) => void;
  onSelect: (p: RealisticPattern) => void;
}) {
  const diffColor = { Facile: "#4ECDC4", Intermédiaire: "#FFD700", Expert: "#FF6B6B" }[pattern.difficulty];

  return (
    <div
      className="cursor-pointer"
      onMouseEnter={() => onHover(pattern.id)}
      onMouseLeave={() => onHover(null)}
      onClick={() => onSelect(pattern)}
    >
      <div className="relative rounded-xl overflow-hidden transition-all duration-250" style={{
        border: `1px solid ${isHovered ? "rgba(255,255,255,0.12)" : "rgba(255,255,255,0.04)"}`,
        transform: isHovered ? "translateY(-4px) scale(1.01)" : "none",
        boxShadow: isHovered ? "0 16px 48px rgba(0,0,0,0.7)" : "none",
      }}>
        {/* Canvas */}
        <div className="aspect-square flex items-center justify-center p-1.5" style={{ background: "#f8f5f0" }}>
          <PatternCanvas pattern={pattern} size={100} />
        </div>

        {/* Overlay hover */}
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-1.5 transition-all duration-200" style={{
          background: "rgba(0,0,0,0.72)",
          opacity: isHovered ? 1 : 0,
        }}>
          <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: "rgba(255,255,255,0.1)", border: "1px solid rgba(255,255,255,0.25)" }}>
            <Play className="w-3.5 h-3.5 text-white fill-white" />
          </div>
          <span className="text-white text-[11px] font-medium">Clique et brode</span>
        </div>

        {/* Badge difficulté */}
        <div className="absolute top-1.5 right-1.5 px-1.5 py-0.5 rounded text-[9px] font-medium" style={{
          background: diffColor + "18",
          color: diffColor,
          border: `1px solid ${diffColor}30`,
        }}>
          {pattern.difficulty}
        </div>
      </div>

      {/* Infos */}
      <div className="mt-1.5 px-0.5">
        <div className="text-white/60 text-[11px] font-light truncate leading-tight">{pattern.name}</div>
        <div className="flex items-center justify-between mt-0.5">
          <div className="flex items-center gap-0.5">
            <Star className="w-2.5 h-2.5 text-yellow-400 fill-yellow-400" />
            <span className="text-white/25 text-[9px]">{pattern.rating}</span>
          </div>
          <span className="text-white/40 text-[9px]">{pattern.price.toFixed(2)}€</span>
        </div>
      </div>
    </div>
  );
}
