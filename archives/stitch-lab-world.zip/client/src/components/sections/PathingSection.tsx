/**
 * StitchLab PathingSection — Étape 03
 * Smart Pathing avec numéros de repère sur chaque pixel (1, 2, 3...)
 * Palette triée par ordre de travail — comme un vrai patron broderie
 */
import { useEffect, useRef, useState } from "react";
import { RotateCcw, Play, Pause, Scissors, ArrowRight, Layers } from "lucide-react";

const COLORS = [
  { hex: "#8b5cf6", name: "Lavande",  code: "3837", num: 1 },
  { hex: "#14b8a6", name: "Teal",     code: "3810", num: 2 },
  { hex: "#f59e0b", name: "Or",       code: "726",  num: 3 },
  { hex: "#10b981", name: "Émeraude", code: "911",  num: 4 },
  { hex: "#f15156", name: "Corail",   code: "666",  num: 5 },
];

const SIZE = 16;
const CANVAS_SIZE = 320;
const CELL = CANVAS_SIZE / SIZE;

function buildGrid() {
  const grid: { colorIdx: number }[][] = [];
  for (let r = 0; r < SIZE; r++) {
    grid[r] = [];
    for (let c = 0; c < SIZE; c++) {
      const wave = Math.sin(r * 0.5 + c * 0.3) * Math.cos(c * 0.4 - r * 0.2);
      const idx = Math.abs(Math.floor((wave + 1) * COLORS.length / 2)) % COLORS.length;
      grid[r][c] = { colorIdx: idx };
    }
  }
  return grid;
}

const STATIC_GRID = buildGrid();

// Compte les pixels par couleur
function countByColor() {
  const counts = new Array(COLORS.length).fill(0);
  for (let r = 0; r < SIZE; r++)
    for (let c = 0; c < SIZE; c++)
      counts[STATIC_GRID[r][c].colorIdx]++;
  return counts;
}
const COLOR_COUNTS = countByColor();

function buildPath(ci: number): [number, number][] {
  const cells: [number, number][] = [];
  for (let r = 0; r < SIZE; r++)
    for (let c = 0; c < SIZE; c++)
      if (STATIC_GRID[r][c].colorIdx === ci) cells.push([r, c]);
  const visited = new Set<number>();
  const result: [number, number][] = [];
  if (!cells.length) return result;
  let cur = cells[0];
  while (result.length < cells.length) {
    const key = cur[0] * SIZE + cur[1];
    if (!visited.has(key)) { visited.add(key); result.push(cur); }
    let best: [number, number] | null = null, bestD = Infinity;
    for (const cell of cells) {
      const k = cell[0] * SIZE + cell[1];
      if (visited.has(k)) continue;
      const d = Math.abs(cell[0] - cur[0]) + Math.abs(cell[1] - cur[1]);
      if (d < bestD) { bestD = d; best = cell; }
    }
    if (!best) break;
    cur = best;
  }
  return result;
}

// ─── Dessin de la grille avec numéros de repère ───────────────────────────────
function drawGrid(
  ctx: CanvasRenderingContext2D,
  activeColorIdx: number | null,
  visitedCells: Set<string>,
  pathSoFar: [number, number][],
  headPos: [number, number] | null,
  idle: boolean
) {
  ctx.clearRect(0, 0, CANVAS_SIZE, CANVAS_SIZE);

  // Fond sombre type tissu Aida
  ctx.fillStyle = "#0f0f14";
  ctx.fillRect(0, 0, CANVAS_SIZE, CANVAS_SIZE);

  // Grille subtile
  ctx.strokeStyle = "rgba(255,255,255,0.04)";
  ctx.lineWidth = 0.5;
  for (let i = 0; i <= SIZE; i++) {
    ctx.beginPath(); ctx.moveTo(i * CELL, 0); ctx.lineTo(i * CELL, CANVAS_SIZE); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(0, i * CELL); ctx.lineTo(CANVAS_SIZE, i * CELL); ctx.stroke();
  }

  // Pixels avec numéros de repère
  for (let r = 0; r < SIZE; r++) {
    for (let c = 0; c < SIZE; c++) {
      const ci = STATIC_GRID[r][c].colorIdx;
      const color = COLORS[ci];
      const key = `${r},${c}`;
      const isActive = activeColorIdx === ci;
      const isVisited = visitedCells.has(key);
      const px = c * CELL, py = r * CELL;

      if (idle) {
        // Mode idle : tous les pixels avec numéro, légèrement transparents
        ctx.globalAlpha = 0.55;
        ctx.fillStyle = color.hex;
        ctx.fillRect(px + 1, py + 1, CELL - 2, CELL - 2);
        ctx.globalAlpha = 1;
        // Numéro de repère
        ctx.fillStyle = "rgba(255,255,255,0.7)";
        ctx.font = `bold ${Math.floor(CELL * 0.42)}px 'Geist', monospace`;
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(String(color.num), px + CELL / 2, py + CELL / 2);
      } else {
        if (isVisited) {
          // Pixel brodé : couleur pleine + numéro
          ctx.globalAlpha = 1;
          ctx.fillStyle = color.hex;
          ctx.fillRect(px + 1, py + 1, CELL - 2, CELL - 2);
          ctx.fillStyle = "rgba(255,255,255,0.85)";
          ctx.font = `bold ${Math.floor(CELL * 0.42)}px 'Geist', monospace`;
          ctx.textAlign = "center";
          ctx.textBaseline = "middle";
          ctx.fillText(String(color.num), px + CELL / 2, py + CELL / 2);
        } else if (isActive) {
          // Couleur active non encore brodée : contour + numéro estompé
          ctx.globalAlpha = 0.18;
          ctx.fillStyle = color.hex;
          ctx.fillRect(px + 1, py + 1, CELL - 2, CELL - 2);
          ctx.globalAlpha = 1;
          ctx.strokeStyle = color.hex + "60";
          ctx.lineWidth = 0.5;
          ctx.strokeRect(px + 1, py + 1, CELL - 2, CELL - 2);
          ctx.fillStyle = color.hex + "55";
          ctx.font = `bold ${Math.floor(CELL * 0.42)}px 'Geist', monospace`;
          ctx.textAlign = "center";
          ctx.textBaseline = "middle";
          ctx.fillText(String(color.num), px + CELL / 2, py + CELL / 2);
        } else {
          // Autre couleur : très estompée avec numéro
          ctx.globalAlpha = 0.12;
          ctx.fillStyle = color.hex;
          ctx.fillRect(px + 1, py + 1, CELL - 2, CELL - 2);
          ctx.globalAlpha = 1;
          ctx.fillStyle = "rgba(255,255,255,0.12)";
          ctx.font = `bold ${Math.floor(CELL * 0.38)}px 'Geist', monospace`;
          ctx.textAlign = "center";
          ctx.textBaseline = "middle";
          ctx.fillText(String(color.num), px + CELL / 2, py + CELL / 2);
        }
      }
    }
  }

  // Ligne de chemin
  if (pathSoFar.length > 1) {
    ctx.strokeStyle = "rgba(255,255,255,0.75)";
    ctx.lineWidth = 1.5;
    ctx.setLineDash([2, 2]);
    ctx.beginPath();
    const [r0, c0] = pathSoFar[0];
    ctx.moveTo(c0 * CELL + CELL / 2, r0 * CELL + CELL / 2);
    for (let i = 1; i < pathSoFar.length; i++) {
      const [ri, ci] = pathSoFar[i];
      ctx.lineTo(ci * CELL + CELL / 2, ri * CELL + CELL / 2);
    }
    ctx.stroke();
    ctx.setLineDash([]);
  }

  // Tête animée (point blanc)
  if (headPos) {
    const [hr, hc] = headPos;
    ctx.fillStyle = "white";
    ctx.shadowColor = "white";
    ctx.shadowBlur = 6;
    ctx.beginPath();
    ctx.arc(hc * CELL + CELL / 2, hr * CELL + CELL / 2, 3.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;
  }

  ctx.globalAlpha = 1;
}

export default function PathingSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [running, setRunning] = useState(false);
  const [activeColorIdx, setActiveColorIdx] = useState<number | null>(null);
  const [savings, setSavings] = useState<number | null>(null);
  const [completedColors, setCompletedColors] = useState<Set<number>>(new Set());
  const animRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const visitedRef = useRef<Set<string>>(new Set());
  const pathRef = useRef<[number, number][]>([]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => entries.forEach((e) => {
        if (e.isIntersecting) e.target.querySelectorAll(".fade-up").forEach((el) => el.classList.add("visible"));
      }),
      { threshold: 0.1 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d")!;
    drawGrid(ctx, null, new Set(), [], null, true);
  }, []);

  const runAnimation = () => {
    if (running) return;
    setRunning(true);
    setSavings(null);
    setCompletedColors(new Set());
    visitedRef.current = new Set();
    pathRef.current = [];

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d")!;

    let colorIdx = 0;
    let stepIdx = 0;
    let path = buildPath(colorIdx);
    pathRef.current = [];
    setActiveColorIdx(colorIdx);

    const nextStep = () => {
      if (stepIdx < path.length) {
        const [r, c] = path[stepIdx];
        visitedRef.current.add(`${r},${c}`);
        pathRef.current.push([r, c]);
        stepIdx++;
        const head = path[stepIdx - 1] ?? null;
        drawGrid(ctx, colorIdx, visitedRef.current, pathRef.current, head, false);
        animRef.current = setTimeout(nextStep, 55);
      } else {
        // Couleur terminée
        setCompletedColors(prev => new Set(Array.from(prev).concat(colorIdx)));
        colorIdx++;
        if (colorIdx < COLORS.length) {
          path = buildPath(colorIdx);
          pathRef.current = [];
          stepIdx = 0;
          setActiveColorIdx(colorIdx);
          animRef.current = setTimeout(nextStep, 350);
        } else {
          // Tout terminé
          setSavings(Math.round((Math.random() * 1.5 + 2.5) * 10) / 10);
          setRunning(false);
          setActiveColorIdx(null);
          drawGrid(ctx, null, visitedRef.current, [], null, false);
        }
      }
    };

    animRef.current = setTimeout(nextStep, 200);
  };

  const reset = () => {
    if (animRef.current) clearTimeout(animRef.current);
    setRunning(false);
    setActiveColorIdx(null);
    setSavings(null);
    setCompletedColors(new Set());
    visitedRef.current = new Set();
    pathRef.current = [];
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d")!;
    drawGrid(ctx, null, new Set(), [], null, true);
  };

  useEffect(() => () => { if (animRef.current) clearTimeout(animRef.current); }, []);

  return (
    <section
      id="pathing"
      ref={sectionRef}
      style={{ minHeight: "100vh", display: "flex", alignItems: "center", background: "var(--bg-base)", padding: "clamp(60px,10vw,80px) 20px", position: "relative", overflow: "hidden" }}
    >
      <div style={{ position: "absolute", top: 0, left: "10%", right: "10%", height: 1, background: "var(--border-subtle)" }} />

      <div className="pathing-grid" style={{ maxWidth: 1100, margin: "0 auto", width: "100%", display: "grid", gridTemplateColumns: "1fr 1fr", gap: "clamp(40px,6vw,80px)", alignItems: "center" }}>

        {/* ── Gauche : Canvas + palette ── */}
        <div className="fade-up" style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          <canvas
            ref={canvasRef}
            width={CANVAS_SIZE} height={CANVAS_SIZE}
            style={{ borderRadius: 12, border: "1px solid var(--border-subtle)", background: "#0f0f14", boxShadow: "0 24px 48px rgba(0,0,0,0.5)", display: "block", imageRendering: "pixelated" }}
          />

          {/* Palette triée par numéro d'ordre */}
          <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
            <div style={{ fontSize: "0.58rem", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.12em", color: "rgba(255,255,255,0.20)", marginBottom: 4 }}>
              Ordre de travail
            </div>
            {COLORS.map((c, i) => {
              const isDone = completedColors.has(i);
              const isActive = activeColorIdx === i && running;
              const isPending = !isDone && !isActive;
              return (
                <div
                  key={c.code}
                  style={{
                    display: "flex", alignItems: "center", gap: 8,
                    padding: "6px 10px", borderRadius: 7,
                    background: isActive ? "rgba(255,255,255,0.06)" : "transparent",
                    border: `1px solid ${isActive ? "rgba(255,255,255,0.18)" : isDone ? "rgba(255,255,255,0.06)" : "var(--border-subtle)"}`,
                    opacity: isPending && running ? 0.4 : 1,
                    transition: "all 0.25s ease",
                  }}
                >
                  {/* Numéro de repère */}
                  <div style={{
                    width: 22, height: 22, borderRadius: 5, flexShrink: 0,
                    display: "flex", alignItems: "center", justifyContent: "center",
                    background: isDone ? c.hex + "30" : isActive ? c.hex + "25" : "rgba(255,255,255,0.04)",
                    border: `1px solid ${isDone ? c.hex + "60" : isActive ? c.hex + "50" : "rgba(255,255,255,0.08)"}`,
                    fontSize: "0.65rem", fontWeight: 700,
                    color: isDone ? c.hex : isActive ? c.hex : "rgba(255,255,255,0.25)",
                    fontFamily: "'Geist', monospace",
                  }}>
                    {c.num}
                  </div>
                  {/* Swatch couleur */}
                  <div style={{ width: 10, height: 10, borderRadius: 3, background: c.hex, flexShrink: 0, opacity: isDone || isActive ? 1 : 0.35 }} />
                  {/* Infos */}
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: "0.70rem", fontWeight: isActive ? 600 : 400, color: isActive ? "rgba(255,255,255,0.80)" : isDone ? "rgba(255,255,255,0.45)" : "rgba(255,255,255,0.30)" }}>
                      DMC {c.code} · {c.name}
                    </div>
                    <div style={{ fontSize: "0.58rem", color: "rgba(255,255,255,0.18)", marginTop: 1 }}>
                      {COLOR_COUNTS[i]} points
                    </div>
                  </div>
                  {/* Statut */}
                  <div style={{ flexShrink: 0 }}>
                    {isDone ? (
                      <div style={{ width: 16, height: 16, borderRadius: "50%", background: "rgba(16,185,129,0.15)", border: "1px solid rgba(16,185,129,0.4)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                        <svg width="8" height="8" viewBox="0 0 8 8"><polyline points="1,4 3,6 7,2" stroke="#10b981" strokeWidth="1.5" fill="none" strokeLinecap="round"/></svg>
                      </div>
                    ) : isActive ? (
                      <div style={{ width: 6, height: 6, borderRadius: "50%", background: c.hex, animation: "pulse 1s ease-in-out infinite" }} />
                    ) : (
                      <div style={{ width: 6, height: 6, borderRadius: "50%", background: "rgba(255,255,255,0.08)" }} />
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Boutons */}
          <div style={{ display: "flex", gap: 8 }}>
            <button
              className="sl-btn-primary"
              onClick={runAnimation}
              disabled={running}
              style={{ fontSize: "0.82rem", display: "flex", alignItems: "center", gap: 6 }}
            >
              {running ? (
                <><Pause style={{ width: 13, height: 13 }} />Optimisation…</>
              ) : (
                <><Play style={{ width: 13, height: 13 }} />Lancer le pathing</>
              )}
            </button>
            <button
              className="sl-btn-outline"
              onClick={reset}
              style={{ fontSize: "0.82rem", display: "flex", alignItems: "center", gap: 6, padding: "0 12px" }}
            >
              <RotateCcw style={{ width: 13, height: 13 }} />
            </button>
          </div>

          {savings !== null && (
            <div style={{ padding: "12px 16px", borderRadius: 8, background: "var(--bg-surface)", border: "1px solid rgba(16,185,129,0.2)" }}>
              <div style={{ fontSize: "0.60rem", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.10em", color: "rgba(255,255,255,0.25)", marginBottom: 4 }}>Résultat</div>
              <div style={{ fontSize: "0.83rem", color: "rgba(255,255,255,0.65)" }}>
                Économie estimée : <strong style={{ color: "rgba(255,255,255,0.88)" }}>{savings} m de fil</strong> sur ce patron
              </div>
            </div>
          )}
        </div>

        {/* ── Droite : Texte ── */}
        <div>
          <div className="fade-up" style={{ marginBottom: 12 }}>
            <span className="section-label">03 — Smart Pathing™</span>
          </div>
          <h2
            className="fade-up d1"
            style={{ fontFamily: "'Geist','Inter',sans-serif", fontWeight: 700, fontSize: "clamp(2rem,4vw,3rem)", lineHeight: 1.1, letterSpacing: "-0.03em", color: "rgba(255,255,255,0.88)", marginBottom: 20 }}
          >
            Brodez<br />
            <span style={{ color: "rgba(255,255,255,0.30)" }}>sans gaspiller.</span>
          </h2>
          <p className="fade-up d2" style={{ fontSize: "0.88rem", lineHeight: 1.75, color: "rgba(255,255,255,0.38)", maxWidth: 380, marginBottom: 32 }}>
            Chaque couleur porte son numéro de repère — <strong style={{ color: "rgba(255,255,255,0.55)" }}>1, 2, 3…</strong> — comme sur un vrai patron. L'algorithme calcule le chemin optimal couleur par couleur, dans l'ordre. Moins de nœuds, moins de fil gaspillé au dos.
          </p>
          <div className="fade-up d2" style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {[
              { icon: <Layers style={{ width: 13, height: 13 }} />, text: "Numéros de repère 1→N sur chaque pixel" },
              { icon: <ArrowRight style={{ width: 13, height: 13 }} />, text: "Ordre de travail optimisé couleur par couleur" },
              { icon: <Scissors style={{ width: 13, height: 13 }} />, text: "Réduction moyenne de 30% du fil au dos" },
            ].map(({ icon, text }) => (
              <div key={text} style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <div style={{ color: "rgba(255,255,255,0.25)", flexShrink: 0 }}>{icon}</div>
                <span style={{ fontSize: "0.82rem", color: "rgba(255,255,255,0.40)" }}>{text}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
