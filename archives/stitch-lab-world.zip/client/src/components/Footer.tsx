/**
 * StitchLab Footer
 */
export default function Footer() {
  return (
    <footer
      className="text-center py-8 px-6"
      style={{ background: "oklch(0.085 0.005 285)", borderTop: "1px solid oklch(1 0 0 / 6%)" }}
    >
      <div className="font-display font-black text-lg gradient-text mb-1">StitchLab</div>
      <div className="text-xs" style={{ color: "oklch(0.35 0.01 285)" }}>
        Pour l'amour du point. © 2026 StitchLab — Tous droits réservés.
      </div>
    </footer>
  );
}
