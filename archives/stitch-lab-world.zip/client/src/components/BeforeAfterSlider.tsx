import React, { useState, useRef, useEffect } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import type { GridPixel } from '@/lib/confettiCleaner';

/**
 * BeforeAfterSlider — Ported from ThreadFlow
 * SVG-based before/after comparison slider for confetti cleaning and smart pathing
 */

interface BeforeAfterSliderProps {
  beforePixels: GridPixel[];
  afterPixels: GridPixel[];
  gridSize?: number;
  cellSize?: number;
  beforeLabel?: string;
  afterLabel?: string;
  showNumbers?: boolean;
  numberMap?: Map<string, number>;
}

export default function BeforeAfterSlider({
  beforePixels,
  afterPixels,
  gridSize = 16,
  cellSize = 20,
  beforeLabel = 'Avant — avec confettis',
  afterLabel = 'Après — grille nettoyée',
  showNumbers = false,
  numberMap,
}: BeforeAfterSliderProps) {
  const [sliderPosition, setSliderPosition] = useState(50);
  const [isDragging, setIsDragging] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const canvasWidth = gridSize * cellSize;
  const canvasHeight = gridSize * cellSize;

  const renderGrid = (pixels: GridPixel[], isAfter: boolean) => {
    const elements: React.ReactNode[] = [];

    // Background
    elements.push(
      <rect key="bg" width={canvasWidth} height={canvasHeight} fill="#141418" />
    );

    // Grid lines (subtle)
    for (let i = 0; i <= gridSize; i++) {
      elements.push(
        <line key={`vl-${i}`} x1={i * cellSize} y1={0} x2={i * cellSize} y2={canvasHeight} stroke="rgba(255,255,255,0.04)" strokeWidth="0.5" />
      );
      elements.push(
        <line key={`hl-${i}`} x1={0} y1={i * cellSize} x2={canvasWidth} y2={i * cellSize} stroke="rgba(255,255,255,0.04)" strokeWidth="0.5" />
      );
    }

    // Pixels
    pixels.forEach((pixel, idx) => {
      const x = pixel.x * cellSize + 1;
      const y = pixel.y * cellSize + 1;
      const size = cellSize - 2;

      elements.push(
        <rect
          key={`px-${idx}`}
          x={x}
          y={y}
          width={size}
          height={size}
          fill={pixel.color}
          rx="1"
        />
      );

      // Show numbers if enabled
      if (showNumbers && numberMap) {
        const num = numberMap.get(`${pixel.x},${pixel.y}`);
        if (num !== undefined) {
          elements.push(
            <text
              key={`num-${idx}`}
              x={pixel.x * cellSize + cellSize / 2}
              y={pixel.y * cellSize + cellSize / 2}
              textAnchor="middle"
              dominantBaseline="middle"
              fontSize={cellSize * 0.45}
              fill="#fff"
              fontWeight="bold"
              style={{ pointerEvents: 'none' }}
            >
              {num}
            </text>
          );
        }
      }
    });

    return elements;
  };

  const handlePointerDown = () => setIsDragging(true);
  const handlePointerUp = () => setIsDragging(false);

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isDragging || !containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const newPosition = Math.max(0, Math.min(100, (x / rect.width) * 100));
    setSliderPosition(newPosition);
  };

  useEffect(() => {
    if (!isDragging) return;
    const handleGlobalPointerUp = () => setIsDragging(false);
    window.addEventListener('pointerup', handleGlobalPointerUp);
    return () => window.removeEventListener('pointerup', handleGlobalPointerUp);
  }, [isDragging]);

  return (
    <div className="w-full">
      {/* Labels */}
      <div className="flex justify-between items-center mb-3">
        <span className="text-xs font-semibold uppercase tracking-wider text-white/60">{beforeLabel}</span>
        <span className="text-xs font-semibold uppercase tracking-wider text-emerald-400/80">{afterLabel}</span>
      </div>

      {/* Slider Container */}
      <div
        ref={containerRef}
        className="relative overflow-hidden rounded-xl border border-white/10 cursor-col-resize mx-auto"
        style={{
          width: '100%',
          maxWidth: `${canvasWidth}px`,
          aspectRatio: `1 / 1`,
        }}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerLeave={handlePointerUp}
      >
        {/* Before Grid (Full) */}
        <svg
          viewBox={`0 0 ${canvasWidth} ${canvasHeight}`}
          className="absolute inset-0 w-full h-full"
          style={{ pointerEvents: 'none' }}
        >
          {renderGrid(beforePixels, false)}
        </svg>

        {/* After Grid (Clipped) */}
        <svg
          viewBox={`0 0 ${canvasWidth} ${canvasHeight}`}
          className="absolute inset-0 w-full h-full"
          style={{
            clipPath: `inset(0 0 0 ${sliderPosition}%)`,
            pointerEvents: 'none',
          }}
        >
          {renderGrid(afterPixels, true)}
        </svg>

        {/* Slider Handle */}
        <div
          className="absolute top-0 bottom-0 flex items-center justify-center"
          style={{
            left: `${sliderPosition}%`,
            transform: 'translateX(-50%)',
            pointerEvents: 'none',
          }}
        >
          {/* Vertical Line */}
          <div className="absolute inset-y-0 w-0.5 bg-white/80 shadow-lg" />

          {/* Handle Circle */}
          <div className="absolute w-8 h-8 bg-white/90 rounded-full shadow-lg flex items-center justify-center border border-white/20 pointer-events-auto backdrop-blur-sm">
            <ChevronLeft size={12} className="text-gray-800" />
            <ChevronRight size={12} className="text-gray-800" />
          </div>
        </div>
      </div>

      {/* Microcopy */}
      <p className="text-xs text-white/40 mt-3 text-center">
        Glissez pour comparer avant / après
      </p>
    </div>
  );
}
