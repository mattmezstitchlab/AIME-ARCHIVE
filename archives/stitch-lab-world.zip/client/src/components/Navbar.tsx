/**
 * StitchLab Navbar — style Framer/Linear
 * Quasi-transparent, typographie légère, un seul accent blanc
 */
import { useEffect, useState } from "react";

const NAV_ITEMS = [
  { id: "hero",    label: "Accueil" },
  { id: "scan",    label: "Scan" },
  { id: "atelier", label: "Atelier IA" },
  { id: "pathing", label: "Smart Path" },
  { id: "sal",     label: "SAL Sync" },
  { id: "feed",    label: "Communauté" },
  { id: "pricing", label: "Tarifs" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [active, setActive] = useState("hero");
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const onScroll = () => {
      const s = window.scrollY;
      const h = document.documentElement.scrollHeight - window.innerHeight;
      setScrolled(s > 40);
      setProgress(h > 0 ? (s / h) * 100 : 0);
      for (let i = NAV_ITEMS.length - 1; i >= 0; i--) {
        const el = document.getElementById(NAV_ITEMS[i].id);
        if (el && el.getBoundingClientRect().top <= 100) {
          setActive(NAV_ITEMS[i].id);
          break;
        }
      }
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const scrollTo = (id: string) =>
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });

  return (
    <>
      {/* Scroll progress */}
      <div style={{
        position: "fixed", top: 0, left: 0, zIndex: 9999,
        height: "1px", width: `${progress}%`,
        background: "rgba(255,255,255,0.20)",
        transition: "width 0.1s linear",
        pointerEvents: "none",
      }} />

      <nav style={{
        position: "fixed", top: 0, left: 0, right: 0, zIndex: 100,
        height: 52,
        display: "flex", alignItems: "center", justifyContent: "space-between",
        padding: "0 28px",
        background: scrolled ? "rgba(10,10,11,0.82)" : "transparent",
        backdropFilter: scrolled ? "blur(16px) saturate(180%)" : "none",
        borderBottom: scrolled ? "1px solid rgba(255,255,255,0.06)" : "1px solid transparent",
        transition: "background 0.3s, border-color 0.3s",
      }}>
        {/* Logo */}
        <button
          onClick={() => scrollTo("hero")}
          style={{
            fontFamily: "'Geist', 'Inter', sans-serif",
            fontWeight: 600, fontSize: "0.9rem", letterSpacing: "-0.02em",
            color: "rgba(255,255,255,0.90)", background: "none", border: "none",
            cursor: "pointer",
          }}
        >
          StitchLab
        </button>

        {/* Nav links */}
        <div className="nav-links" style={{ display: "flex", alignItems: "center", gap: 2 }}>
          {NAV_ITEMS.map(({ id, label }) => {
            const isActive = active === id;
            return (
              <button
                key={id}
                onClick={() => scrollTo(id)}
                style={{
                  padding: "5px 11px", borderRadius: 6, border: "none",
                  fontSize: "0.78rem", fontWeight: 450, letterSpacing: "-0.005em",
                  color: isActive ? "rgba(255,255,255,0.90)" : "rgba(255,255,255,0.35)",
                  background: isActive ? "rgba(255,255,255,0.07)" : "transparent",
                  cursor: "pointer",
                  transition: "color 0.15s, background 0.15s",
                }}
                onMouseEnter={(e) => {
                  if (!isActive) (e.currentTarget as HTMLElement).style.color = "rgba(255,255,255,0.60)";
                }}
                onMouseLeave={(e) => {
                  if (!isActive) (e.currentTarget as HTMLElement).style.color = "rgba(255,255,255,0.35)";
                }}
              >
                {label}
              </button>
            );
          })}
        </div>

        {/* CTA */}
        <button
          onClick={() => scrollTo("pricing")}
          className="sl-btn-primary"
          style={{ padding: "6px 14px", fontSize: "0.78rem", borderRadius: 7 }}
        >
          Rejoindre
        </button>
      </nav>
    </>
  );
}
