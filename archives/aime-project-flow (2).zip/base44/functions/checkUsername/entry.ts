import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';

export default async function(req) {
  try {
    const body = await req.json().catch(() => ({}));
    const { username, excludePageId } = body;
    if (!username) return Response.json({ error: 'Username required' }, { status: 400 });

    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const pages = await base44.asServiceRole.entities.PersonalPublicPage.filter({ username });
    const conflict = pages.find(p => p.id !== excludePageId);

    return Response.json({ available: !conflict });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}