import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const url = body.url;
    if (!url || typeof url !== 'string') {
      return Response.json({ error: 'URL required' }, { status: 400 });
    }

    let normalizedUrl = url.trim();
    if (!normalizedUrl.match(/^https?:\/\//)) {
      normalizedUrl = 'https://' + normalizedUrl;
    }

    const response = await fetch(normalizedUrl, {
      headers: { 'User-Agent': 'AIME-Sense/1.0 (compatible; Memory Core V1.1)' },
      redirect: 'follow',
      signal: AbortSignal.timeout(15000),
    });

    if (!response.ok) {
      return Response.json({ error: `Fetch failed: ${response.status}` }, { status: 502 });
    }

    const html = await response.text();
    const finalUrl = response.url || normalizedUrl;

    const titleMatch = html.match(/<title[^>]*>([^<]+)<\/title>/i);
    const title = titleMatch ? titleMatch[1].trim() : finalUrl;

    const descMatch = html.match(/<meta[^>]+(?:name|property)=["'](?:description|og:description)["'][^>]+content=["']([^"']+)["']/i);
    const description = descMatch ? descMatch[1].trim() : '';

    const headings = [];
    const headingRegex = /<h([1-6])[^>]*>([\s\S]*?)<\/h\1>/gi;
    let match;
    while ((match = headingRegex.exec(html)) !== null && headings.length < 30) {
      const text = match[2].replace(/<[^>]+>/g, '').trim();
      if (text) headings.push({ level: parseInt(match[1]), text });
    }

    const links = [];
    const linkRegex = /<a[^>]+href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi;
    while ((match = linkRegex.exec(html)) !== null && links.length < 50) {
      const text = match[2].replace(/<[^>]+>/g, '').trim();
      const href = match[1];
      if (href && !href.startsWith('#') && !href.startsWith('mailto:') && !href.startsWith('tel:')) {
        links.push({ href, text });
      }
    }

    const images = [];
    const imgRegex = /<img[^>]+src=["']([^"']+)["']/gi;
    while ((match = imgRegex.exec(html)) !== null && images.length < 50) {
      images.push(match[1]);
    }

    const colors = new Set();
    const colorRegex = /(?:color|background|background-color|border-color|fill|stroke)\s*:\s*(#[0-9a-fA-F]{3,8}|rgb[a]?\([^)]+\))/g;
    while ((match = colorRegex.exec(html)) !== null) {
      colors.add(match[1]);
    }

    const fonts = new Set();
    const fontRegex = /font-family\s*:\s*([^;}"']+)/g;
    while ((match = fontRegex.exec(html)) !== null) {
      const font = match[1].trim().replace(/['"]/g, '').split(',')[0].trim();
      if (font) fonts.add(font);
    }

    const items = [];

    items.push({
      path: finalUrl,
      name: title,
      ext: 'html',
      type: 'document',
      size: html.length,
      mime_type: 'text/html',
    });

    images.forEach((src, i) => {
      let name = src.split('/').pop()?.split('?')[0] || `image-${i}`;
      if (!name.includes('.')) name += '.jpg';
      items.push({
        path: src,
        name,
        ext: name.includes('.') ? name.split('.').pop().toLowerCase() : 'jpg',
        type: 'image',
        size: 0,
        mime_type: 'image/jpeg',
      });
    });

    headings.forEach((h) => {
      items.push({
        path: `${finalUrl}#h${h.level}`,
        name: h.text,
        ext: 'txt',
        type: 'document',
        size: h.text.length,
        mime_type: 'text/plain',
      });
    });

    links.forEach((link) => {
      if (link.href.startsWith('http')) {
        items.push({
          path: link.href,
          name: link.text || link.href,
          ext: 'url',
          type: 'url',
          size: 0,
          mime_type: 'text/html',
        });
      }
    });

    return Response.json({
      url: finalUrl,
      title,
      description,
      headings,
      links,
      images,
      items,
      itemCount: items.length,
      directoryCount: 0,
      totalSize: html.length,
      design: {
        colors: Array.from(colors).slice(0, 20),
        fonts: Array.from(fonts).slice(0, 10),
        layout: headings.length > 10 ? 'structured' : 'simple',
        style: colors.size > 5 ? 'rich' : 'minimal',
      },
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}