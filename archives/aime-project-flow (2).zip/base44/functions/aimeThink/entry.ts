import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const { project_id, question } = body;
    if (!project_id || !question || typeof question !== 'string') {
      return Response.json({ error: 'project_id and question required' }, { status: 400 });
    }
    if (question.length > 2000) {
      return Response.json({ error: 'Question too long (max 2000 chars)' }, { status: 400 });
    }

    // Load full project context + recent ThinkSessions (conversational memory)
    const [projectList, dnaList, memoryItems, futurePaths, versions, recentSessions] = await Promise.all([
      base44.entities.AimeProject.filter({ id: project_id, owner_id: user.id }),
      base44.entities.ProjectDNA.filter({ project_id, owner_id: user.id }),
      base44.entities.MemoryItem.filter({ project_id, owner_id: user.id }, '-created_date', 100),
      base44.entities.FuturePath.filter({ project_id, owner_id: user.id }),
      base44.entities.MemoryVersion.filter({ project_id, owner_id: user.id }, '-version', 20),
      base44.entities.ThinkSession.filter({ project_id, owner_id: user.id }, '-created_date', 5),
    ]);

    const project = projectList[0];
    const dna = dnaList[0];
    if (!dna) return Response.json({ error: 'No DNA found for this project' }, { status: 404 });

    // Normalisation progressive des champs (V1.3)
    const intentions = dna.intentions || dna.intelligence || {};
    const persons = dna.persons || dna.humans || [];
    const validationState = dna.validation_state || dna.validation || {};
    const archetype = dna.archetype || 'inconnu';
    const archetypeConfidence = dna.archetype_confidence || 0;

    // V1.4: détection des gaps pour la boucle THINK → CREATE
    const gaps = [];
    if (!project?.studio_page_id) gaps.push('studio');
    const designDna = dna.design_dna || {};
    if (!designDna.colors?.length && !designDna.fonts?.length) gaps.push('design');
    if (persons.length === 0) gaps.push('persons');
    if (memoryItems.length < 5) gaps.push('resources');
    if (validationState.status === 'pending') gaps.push('validation');
    if (archetype === 'inconnu' || archetypeConfidence < 50) gaps.push('archetype');

    // V1.5: THINK → ACTION — créer des ProjectActions depuis les gaps détectés
    try {
      const existingActions = await base44.entities.ProjectAction.filter({ project_id, owner_id: user.id }, 'order', 50);
      const existingKeys = new Set(existingActions.map((a) => a.action_key).filter(Boolean));

      const gapToAction = {
        studio: { type: 'creation', action_key: 'create_studio', title: 'Créer l\'espace Studio AIME', description: 'Le projet est compris mais n\'a pas encore d\'espace public.', priority: 'high' },
        design: { type: 'creation', action_key: 'add_design', title: 'Définir la direction visuelle', description: 'Aucune couleur ou police détectée dans le Design DNA.', priority: 'medium' },
        persons: { type: 'organization', action_key: 'add_persons', title: 'Identifier les personnes clés', description: 'Aucune personne n\'a été détectée dans le projet.', priority: 'medium' },
        resources: { type: 'missing_information', action_key: 'add_resources', title: 'Enrichir la mémoire du projet', description: 'Peu d\'éléments en mémoire. Importez plus de documents.', priority: 'medium' },
        validation: { type: 'validation', action_key: 'validate_dna', title: 'Valider la compréhension du projet', description: 'AIME a analysé le projet. Validez ou corrigez son analyse.', priority: 'high' },
        archetype: { type: 'missing_information', action_key: 'clarify_archetype', title: 'Préciser l\'identité du projet', description: 'L\'archetype n\'est pas encore confirmé avec confiance.', priority: 'medium' },
      };

      const actionsToCreate = [];
      for (const gap of gaps) {
        const rule = gapToAction[gap];
        if (rule && !existingKeys.has(rule.action_key)) {
          actionsToCreate.push({
            project_id,
            owner_id: user.id,
            type: rule.type,
            title: rule.title,
            description: rule.description,
            priority: rule.priority,
            status: 'proposed',
            source: 'think',
            action_key: rule.action_key,
            target_route: `/aime/project/${project_id}/control`,
            order: 10,
          });
        }
      }

      if (actionsToCreate.length > 0) {
        await base44.entities.ProjectAction.bulkCreate(actionsToCreate);
      }
    } catch (e) {
      console.error('Action creation failed:', e.message);
    }

    // Build compact context
    const context = {
      identite: dna.identity,
      archetype,
      archetype_confidence: archetypeConfidence,
      etat: dna.state,
      intentions,
      design_dna: dna.design_dna,
      timeline: dna.timeline,
      personnes: persons,
      confiance: dna.confidence,
      validation: validationState,
      gaps_detectes: gaps,
      elements_memoire: memoryItems.slice(0, 40).map(m => ({
        nom: m.name,
        type: m.type,
        source: m.source,
        contenu: m.content_text ? m.content_text.slice(0, 150) : undefined,
      })),
      futurs_possibles: futurePaths.map(fp => ({
        scenario: fp.scenario,
        statut: fp.status,
        probabilite: fp.probability,
        avantages: fp.advantages,
        risques: fp.risks,
      })),
      evolution: versions.map(v => ({
        version: v.version,
        raison: v.reason,
        type: v.entity_type,
      })),
      // Mémoire conversationnelle — dernières réflexions
      dernieres_reflexions: recentSessions.slice(0, 3).map(s => ({
        question: s.question,
        reponse: s.response ? s.response.slice(0, 200) : '',
        date: s.created_date,
      })),
    };

    const prompt = `Tu es AIME THINK™, un compagnon intelligent de réflexion sur des projets humains.
Tu n'es pas un chatbot générique. Tu es le cerveau contextuel de CE projet spécifique.

Voici le contexte complet du projet :

${JSON.stringify(context, null, 2)}

L'utilisateur te pose la question suivante :
"${question}"

Ta mission :
1. Réponds avec une réflexion contextuelle profonde, ancrée dans le contexte réel du projet.
2. Apporte une compréhension nouvelle — ne te contente pas de répéter les données.
3. Identifie ce qui manque, ce qui est cohérent, ce qui est risqué.
4. Propose des actions concrètes si pertinent — notamment en lien avec les gaps détectés.
5. Si des réflexions précédentes existent, montre que tu te souviens du fil de la conversation.
6. Reste concis mais substantiel (2-4 paragraphes max).

BOUCLE THINK → CREATE (V1.4) :
Si le projet manque d'un élément critique (gap), propose l'action correspondante :
- gap "studio" → suggère action type "studio" avec label "Créer mon espace Studio AIME"
- gap "design" → suggère action type "studio" avec label "Créer un Design Studio"
- gap "persons" → suggère action type "memory_item" avec label "Ajouter une personne clé"
- gap "resources" → suggère action type "memory_item" avec label "Ajouter des documents"
- gap "validation" → suggère action type "dna_update" avec label "Valider l'analyse"
- gap "archetype" → suggère action type "dna_update" avec label "Préciser l'identité du projet"

Ne propose ces actions que si elles sont pertinentes par rapport à la question posée ou si la question porte sur la direction du projet.

Réponds en JSON avec ce format exact :
{
  "response": "ta réflexion textuelle",
  "suggested_actions": [
    {
      "type": "memory_item",
      "label": "Ajouter une information",
      "data": { "content": "...", "type": "event" }
    },
    {
      "type": "future_path",
      "label": "Explorer cette direction",
      "data": { "scenario": "...", "advantages": ["..."], "risks": ["..."] }
    },
    {
      "type": "studio",
      "label": "Créer mon espace Studio AIME",
      "data": {}
    },
    {
      "type": "dna_update",
      "label": "Modifier le DNA",
      "data": { "field": "identity.purpose", "value": "..." }
    }
  ]
}

Les suggested_actions sont optionnelles — ne les propose que si elles sont vraiment pertinentes pour la question posée. Maximum 3 actions suggérées.`;

    const llmResponse = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: 'object',
        properties: {
          response: { type: 'string', description: 'La réflexion textuelle de AIME THINK' },
          suggested_actions: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                type: { type: 'string', enum: ['memory_item', 'future_path', 'studio', 'dna_update'] },
                label: { type: 'string' },
                data: { type: 'object' },
              },
              required: ['type', 'label'],
            },
          },
        },
        required: ['response'],
      },
    });

    // Persister la session de réflexion (mémoire conversationnelle)
    try {
      await base44.entities.ThinkSession.create({
        project_id,
        owner_id: user.id,
        question,
        response: llmResponse.response || '',
        suggested_actions: llmResponse.suggested_actions || [],
        context_summary: `Identité: ${dna.identity?.name || 'N/A'} | Éléments: ${memoryItems.length} | Versions: ${versions.length}`,
      });
    } catch (e) {
      // La persistance échouée ne doit pas casser la réponse
      console.error('ThinkSession persist failed:', e.message);
    }

    return Response.json(llmResponse);
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}