import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';

export default async function(req) {
  try {
    const body = await req.json().catch(() => ({}));
    const username = body.username || new URL(req.url).searchParams.get('username');
    if (!username) return Response.json({ error: 'Username required' }, { status: 400 });

    const base44 = createClientFromRequest(req);
    const admin = base44.asServiceRole;

    const pages = await admin.entities.PersonalPublicPage.filter({ username });
    if (!pages || pages.length === 0) {
      return Response.json({ error: 'Page not found' }, { status: 404 });
    }
    const page = pages[0];

    if (page.status !== 'publie') {
      return Response.json({ error: 'Page not published' }, { status: 404 });
    }

    const sections = await admin.entities.PublicPageSection.filter({ pageId: page.id });
    sections.sort((a, b) => (a.position || 0) - (b.position || 0));
    const visibleSections = sections.filter(s => s.visibility === 'public' && !s.hidden);

    return Response.json({ page, sections: visibleSections });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}