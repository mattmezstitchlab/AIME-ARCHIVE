import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';
import { filterDocumentsForParticipant } from '../../shared/documentAccessPolicy.ts';

// Portail prestataire sécurisé : accessible sans compte utilisateur (lien d'invitation).
// La sécurité ne repose pas sur les règles RLS côté client (le prestataire n'est pas
// authentifié comme le propriétaire du projet) mais sur une validation backend du
// participant lui-même : existence, statut de révocation, expiration.
// Seul un sous-ensemble sûr de champs est renvoyé — jamais les autres participants,
// les invités, ni les données privées du projet.
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const { participant_id, action = 'get', status, arrival_time } = body;

    if (!participant_id || typeof participant_id !== 'string') {
      return Response.json({ error: 'participant_id required' }, { status: 400 });
    }

    const admin = base44.asServiceRole;

    let participant = null;
    try {
      participant = (await admin.entities.WeddingParticipant.filter({ id: participant_id }))[0] || null;
    } catch (e) {
      participant = null;
    }
    if (!participant) {
      try {
        const byToken = await admin.entities.WeddingParticipant.filter({ invite_token: participant_id });
        participant = byToken[0] || null;
      } catch (e) {
        participant = null;
      }
    }
    if (!participant) {
      return Response.json({ error: 'not_found' }, { status: 404 });
    }
    if (participant.token_revoked) {
      return Response.json({ error: 'revoked' }, { status: 403 });
    }
    if (participant.token_expires_at && new Date(participant.token_expires_at).getTime() < Date.now()) {
      return Response.json({ error: 'expired' }, { status: 403 });
    }

    if (action === 'update_status') {
      if (status !== 'accepted' && status !== 'declined') {
        return Response.json({ error: 'invalid_status' }, { status: 400 });
      }
      const now = new Date().toISOString();
      const patch = { status, confirmed_at: status === 'accepted' ? now : (participant.confirmed_at || null) };
      await admin.entities.WeddingParticipant.update(participant.id, patch);
      participant = { ...participant, ...patch };
    } else if (action === 'update_arrival') {
      if (typeof arrival_time !== 'string') {
        return Response.json({ error: 'invalid_arrival_time' }, { status: 400 });
      }
      await admin.entities.WeddingParticipant.update(participant.id, { arrival_time });
      participant = { ...participant, arrival_time };
    } else {
      // 'get' — journalise l'ouverture, sans écraser un statut déjà avancé
      const now = new Date().toISOString();
      const patch = { last_accessed_at: now };
      if (['invited', 'sent', 'draft'].includes(participant.status)) patch.status = 'viewed';
      await admin.entities.WeddingParticipant.update(participant.id, patch);
      participant = { ...participant, ...patch };
    }

    const [projects, timelineItems, documents] = await Promise.all([
      admin.entities.AimeProject.filter({ id: participant.project_id }),
      admin.entities.WeddingTimelineItem.filter({ project_id: participant.project_id, owner_id: participant.owner_id }, 'position', 200),
      admin.entities.ProjectDocument.filter({ project_id: participant.project_id, owner_id: participant.owner_id }),
    ]);

    const myTimeline = timelineItems.filter((t) => (t.participant_ids || []).includes(participant.id));
    const myDocuments = filterDocumentsForParticipant(documents, participant.id);

    const safeParticipant = {
      id: participant.id,
      display_name: participant.display_name,
      category: participant.category,
      role: participant.role,
      status: participant.status,
      responsibilities: participant.responsibilities,
      arrival_time: participant.arrival_time,
      setup_time: participant.setup_time,
      service_start_time: participant.service_start_time,
      service_end_time: participant.service_end_time,
      departure_time: participant.departure_time,
      contact_email: participant.contact_email,
      contact_phone: participant.contact_phone,
      confirmed_at: participant.confirmed_at,
    };

    return Response.json({
      participant: safeParticipant,
      project: { name: projects[0]?.name || 'Mariage' },
      timeline: myTimeline.map((t) => ({
        id: t.id, title: t.title, start_time: t.start_time,
        duration_minutes: t.duration_minutes, location: t.location, notes: t.notes,
      })),
      documents: myDocuments.map((d) => ({ id: d.id, title: d.title, category: d.category, file_url: d.file_url })),
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}