import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';

// Generic "Import Intelligence" engine — turns an external source (URL, free text,
// image, or PDF) into a structured AIME object, and scores its compatibility with
// the current project's DNA. Not tied to weddings: target_entity_type widens the
// prompt framing so the same engine serves WeddingParticipant today and other
// entities (CompanySupplier, ArtistContract, AssociationPartner...) later.

const ALLOWED_TARGET_TYPES = ['WeddingParticipant', 'CompanySupplier', 'ArtistContract', 'AssociationPartner'];
const ALLOWED_SOURCE_TYPES = ['url', 'text', 'image', 'pdf'];

const RESPONSE_SCHEMA = {
  type: 'object',
  properties: {
    extracted_data: {
      type: 'object',
      properties: {
        name: { type: 'string' },
        category: { type: 'string' },
        description: { type: 'string' },
        estimated_budget: { type: 'number' },
        style: { type: 'string' },
        location: { type: 'string' },
        capacity: { type: 'string' },
        contact_email: { type: 'string' },
        contact_phone: { type: 'string' },
        website: { type: 'string' },
      },
      required: ['name'],
    },
    compatibility: {
      type: 'object',
      properties: {
        score: { type: 'number' },
        explanation: { type: 'string' },
        points_to_check: { type: 'array', items: { type: 'string' } },
      },
      required: ['score', 'explanation'],
    },
  },
  required: ['extracted_data', 'compatibility'],
};

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const { source_type, source_value, file_url, target_entity_type, project_id } = body;

    if (!ALLOWED_SOURCE_TYPES.includes(source_type)) {
      return Response.json({ error: 'Invalid source_type' }, { status: 400 });
    }
    if (!ALLOWED_TARGET_TYPES.includes(target_entity_type)) {
      return Response.json({ error: 'Invalid target_entity_type' }, { status: 400 });
    }
    if (!project_id || typeof project_id !== 'string') {
      return Response.json({ error: 'project_id required' }, { status: 400 });
    }

    // Project context (DNA) for the compatibility comparison — user-scoped, respects RLS.
    let dnaContext = '';
    try {
      const dnas = await base44.entities.ProjectDNA.filter({ project_id });
      const dna = dnas[0];
      if (dna) {
        dnaContext = JSON.stringify({
          name: dna.identity?.name,
          archetype: dna.archetype,
          timeline: dna.timeline,
          design_dna: dna.design_dna,
        }).slice(0, 2000);
      }
    } catch {
      // no DNA yet — comparison will just be looser
    }

    let sourceContent = '';
    let sourceUrl = '';

    if (source_type === 'url') {
      if (!source_value || typeof source_value !== 'string') {
        return Response.json({ error: 'source_value (URL) required' }, { status: 400 });
      }
      sourceUrl = source_value;
      const scan = await base44.functions.invoke('scanUrl', { url: source_value });
      const data = scan.data;
      if (!data || data.error) {
        return Response.json({ error: `Impossible d'analyser cette URL: ${data?.error || 'échec'}` }, { status: 502 });
      }
      sourceContent = JSON.stringify({
        title: data.title,
        description: data.description,
        headings: (data.headings || []).map((h) => h.text).slice(0, 20),
      }).slice(0, 4000);
    } else if (source_type === 'text') {
      if (!source_value || typeof source_value !== 'string') {
        return Response.json({ error: 'source_value (texte) required' }, { status: 400 });
      }
      sourceContent = source_value.slice(0, 4000);
    } else if ((source_type === 'image' || source_type === 'pdf') && (!file_url || typeof file_url !== 'string')) {
      return Response.json({ error: 'file_url required' }, { status: 400 });
    }

    const prompt = `Tu es l'assistant AIME "Import Intelligence". Transforme la source ci-dessous en fiche structurée pour un projet (type cible : ${target_entity_type}).

ADN du projet : ${dnaContext || 'aucun contexte disponible'}

Source à analyser (${source_type}) :
${sourceContent || '(voir fichier joint)'}

Extrais les informations disponibles (n'invente rien, laisse vide si absent). Puis évalue la compatibilité de cette source avec le projet (style, budget, localisation, capacité, date si pertinent) : donne un score 0-100, une explication commençant par "Compatible car..." ou "Peu compatible car...", et une liste de points à vérifier.`;

    const llmParams = { prompt, response_json_schema: RESPONSE_SCHEMA };
    if (source_type === 'image' || source_type === 'pdf') {
      llmParams.file_urls = [file_url];
    }

    const result = await base44.asServiceRole.integrations.Core.InvokeLLM(llmParams);

    return Response.json({
      extracted_data: result.extracted_data,
      compatibility: result.compatibility,
      source_type,
      source_url: sourceUrl,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}