// Politique d'accès aux documents de projet, partagée entre les fonctions backend.
// Un document est visible pour un prestataire/participant si :
// - il est marqué "tous_prestataires" ou "public"
// - ou "prestataires_concernes" ET que ce participant est explicitement autorisé
export function filterDocumentsForParticipant(documents, participantId) {
  return (documents || []).filter((d) =>
    d.visibility === 'tous_prestataires' ||
    d.visibility === 'public' ||
    (d.visibility === 'prestataires_concernes' && (d.authorized_participant_ids || []).includes(participantId))
  );
}