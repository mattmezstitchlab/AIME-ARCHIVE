import { createContext, useContext, useState, useEffect } from "react";

const Ctx = createContext(null);
export function useAI() { return useContext(Ctx); }

export function AIProvider({ children }) {
  const [enabled, setEnabled] = useState(() => {
    try { return localStorage.getItem("aime_ai_enabled") === "true"; } catch { return false; }
  });

  useEffect(() => {
    try { localStorage.setItem("aime_ai_enabled", String(enabled)); } catch {}
  }, [enabled]);

  return (
    <Ctx.Provider value={{ aiEnabled: enabled, toggleAI: () => setEnabled(e => !e), setAIEnabled: setEnabled }}>
      {children}
    </Ctx.Provider>
  );
}