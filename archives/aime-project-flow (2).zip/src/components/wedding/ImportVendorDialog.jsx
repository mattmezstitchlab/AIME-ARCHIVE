import { useState } from 'react';
import { X, Link2, Camera, Type, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useToast } from '@/components/ui/use-toast';
import ImportResultPreview from './ImportResultPreview';

const TABS = [
  { id: 'url', label: 'URL', icon: Link2 },
  { id: 'image', label: 'Capture', icon: Camera },
  { id: 'text', label: 'Texte', icon: Type },
];

export default function ImportVendorDialog({ projectId, onClose, onImported }) {
  const { toast } = useToast();
  const [tab, setTab] = useState('url');
  const [urlValue, setUrlValue] = useState('');
  const [textValue, setTextValue] = useState('');
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [sourceMeta, setSourceMeta] = useState(null);

  async function handleAnalyze() {
    setLoading(true);
    try {
      let payload = { target_entity_type: 'WeddingParticipant', project_id: projectId, source_type: tab };
      if (tab === 'url') {
        if (!urlValue.trim()) { setLoading(false); return; }
        payload.source_value = urlValue.trim();
      } else if (tab === 'text') {
        if (!textValue.trim()) { setLoading(false); return; }
        payload.source_value = textValue.trim();
      } else if (tab === 'image') {
        if (!file) { setLoading(false); return; }
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        payload.file_url = file_url;
      }
      const res = await base44.functions.invoke('importEntityFromSource', payload);
      setResult(res.data);
      setSourceMeta({ imported_from: tab, source_url: tab === 'url' ? urlValue.trim() : '' });
    } catch (e) {
      toast({ title: "Analyse impossible", description: e.message, variant: 'destructive' });
    }
    setLoading(false);
  }

  function handleConfirm() {
    onImported(result, sourceMeta);
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40" onClick={onClose}>
      <div className="w-full max-w-lg bg-card rounded-2xl border border-border p-6 m-4 max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-display font-semibold text-lg">Importer un prestataire</h3>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-accent"><X className="w-4 h-4" /></button>
        </div>

        {!result && (
          <>
            <div className="flex gap-1 mb-4 p-1 rounded-lg bg-muted/50">
              {TABS.map(t => {
                const Icon = t.icon;
                return (
                  <button
                    key={t.id}
                    onClick={() => setTab(t.id)}
                    className={`flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-md text-xs font-medium transition-colors ${tab === t.id ? 'bg-foreground text-background' : 'text-muted-foreground hover:bg-accent'}`}
                  >
                    <Icon className="w-3.5 h-3.5" /> {t.label}
                  </button>
                );
              })}
            </div>

            {tab === 'url' && (
              <input
                value={urlValue}
                onChange={e => setUrlValue(e.target.value)}
                placeholder="https://exemple.com/lieu-de-reception"
                className="w-full px-3 py-2 rounded-lg border border-border text-sm mb-4"
              />
            )}
            {tab === 'text' && (
              <textarea
                value={textValue}
                onChange={e => setTextValue(e.target.value)}
                rows={5}
                placeholder="Collez ici la description du prestataire, un email, un devis..."
                className="w-full px-3 py-2 rounded-lg border border-border text-sm mb-4"
              />
            )}
            {tab === 'image' && (
              <label className="flex flex-col items-center justify-center gap-2 px-4 py-8 rounded-lg border border-dashed border-border cursor-pointer hover:bg-accent transition-colors text-sm text-muted-foreground mb-4">
                <Camera className="w-5 h-5" />
                {file ? file.name : 'Choisir une capture d\'écran ou un PDF'}
                <input type="file" accept="image/*,.pdf" className="hidden" onChange={e => setFile(e.target.files?.[0] || null)} />
              </label>
            )}

            <div className="flex justify-end gap-2">
              <button onClick={onClose} className="px-4 py-2 rounded-lg text-sm hover:bg-accent transition-colors">Annuler</button>
              <button
                onClick={handleAnalyze}
                disabled={loading}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-foreground text-background text-sm font-medium hover:opacity-90 transition-opacity disabled:opacity-60"
              >
                {loading && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                {loading ? 'Analyse en cours...' : 'Analyser'}
              </button>
            </div>
          </>
        )}

        {result && (
          <ImportResultPreview result={result} onConfirm={handleConfirm} onCancel={onClose} />
        )}
      </div>
    </div>
  );
}