import { useState } from 'react';
import { Plus, X, FileText, Trash2, Upload, Eye, Lock, Globe, Users } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useToast } from '@/components/ui/use-toast';

const CATEGORY_LABELS = {
  contrat: 'Contrat', devis: 'Devis', facture: 'Facture', recu: 'Reçu',
  planning: 'Planning', deroule: 'Déroulé', plan_salle: 'Plan de salle',
  menu: 'Menu', liste_invites: 'Liste invités', fiche_prestataire: 'Fiche prestataire',
  document_technique: 'Document technique', document_administratif: 'Document administratif',
  inspiration: 'Inspiration', autre: 'Autre',
};

const STATUS_LABELS = {
  brouillon: 'Brouillon', a_verifier: 'À vérifier', envoye: 'Envoyé',
  signe: 'Signé', valide: 'Validé', archive: 'Archivé',
};

const STATUS_COLORS = {
  brouillon: 'bg-muted text-muted-foreground', a_verifier: 'bg-amber-100 text-amber-700',
  envoye: 'bg-blue-100 text-blue-700', signe: 'bg-emerald-100 text-emerald-700',
  valide: 'bg-emerald-600 text-white', archive: 'bg-slate-200 text-slate-700',
};

const VISIBILITY_LABELS = {
  prive_maries: 'Privé mariés', coordinateur: 'Coordinateur',
  prestataires_concernes: 'Prestataires concernés', tous_prestataires: 'Tous les prestataires',
  public: 'Public',
};

const VISIBILITY_ICONS = {
  prive_maries: Lock, coordinateur: Lock,
  prestataires_concernes: Users, tous_prestataires: Users,
  public: Globe,
};

export default function DocumentsModule({ projectId, documents, setDocuments, participants }) {
  const { toast } = useToast();
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [form, setForm] = useState({
    title: '', category: 'autre', file_url: '', external_url: '',
    status: 'brouillon', visibility: 'prive_maries',
    authorized_participant_ids: [], notes: '',
  });

  async function handleUpload(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setForm(f => ({ ...f, file_url }));
      toast({ title: 'Fichier téléversé' });
    } catch (err) {
      toast({ title: 'Erreur téléversement', description: err.message, variant: 'destructive' });
    }
    setUploading(false);
  }

  async function handleSave() {
    if (!form.title.trim()) return;
    try {
      if (editing) {
        await base44.entities.ProjectDocument.update(editing.id, form);
        setDocuments(documents.map(d => d.id === editing.id ? { ...editing, ...form } : d));
        toast({ title: 'Document mis à jour' });
      } else {
        const me = await base44.auth.me();
        const created = await base44.entities.ProjectDocument.create({
          ...form,
          project_id: projectId,
          owner_id: me.id,
        });
        setDocuments([created, ...documents]);
        toast({ title: 'Document ajouté' });
      }
      setShowForm(false);
      setEditing(null);
      setForm({ title: '', category: 'autre', file_url: '', external_url: '', status: 'brouillon', visibility: 'prive_maries', authorized_participant_ids: [], notes: '' });
    } catch (e) {
      toast({ title: 'Erreur', description: e.message, variant: 'destructive' });
    }
  }

  async function handleDelete(doc) {
    try {
      await base44.entities.ProjectDocument.delete(doc.id);
      setDocuments(documents.filter(d => d.id !== doc.id));
      toast({ title: 'Document supprimé' });
    } catch (e) {
      toast({ title: 'Erreur', description: e.message, variant: 'destructive' });
    }
  }

  function openEdit(doc) {
    setEditing(doc);
    setForm({
      title: doc.title || '', category: doc.category || 'autre',
      file_url: doc.file_url || '', external_url: doc.external_url || '',
      status: doc.status || 'brouillon', visibility: doc.visibility || 'prive_maries',
      authorized_participant_ids: doc.authorized_participant_ids || [],
      notes: doc.notes || '',
    });
    setShowForm(true);
  }

  const sorted = [...documents].sort((a, b) => (b.created_date || '').localeCompare(a.created_date || ''));

  return (
    <div className="max-w-4xl mx-auto px-8 py-10">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-display font-bold mb-1">Documents</h1>
          <p className="text-sm text-muted-foreground">{documents.length} document(s) — Gestion par visibilité</p>
        </div>
        <button
          onClick={() => { setEditing(null); setForm({ title: '', category: 'autre', file_url: '', external_url: '', status: 'brouillon', visibility: 'prive_maries', authorized_participant_ids: [], notes: '' }); setShowForm(true); }}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full bg-foreground text-background text-sm font-medium hover:opacity-90 transition-opacity"
        >
          <Plus className="w-4 h-4" /> Ajouter
        </button>
      </div>

      {sorted.length === 0 ? (
        <div className="text-center py-16">
          <FileText className="w-10 h-10 mx-auto text-muted-foreground/40 mb-3" />
          <p className="text-sm text-muted-foreground">Aucun document pour le moment</p>
          <p className="text-xs text-muted-foreground mt-1">Contrats, devis, planning, déroulé, plan de salle...</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {sorted.map(doc => {
            const VisIcon = VISIBILITY_ICONS[doc.visibility] || Lock;
            return (
              <div key={doc.id} className="p-4 rounded-xl border border-border/60 bg-card group">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-start gap-2 flex-1 min-w-0">
                    <FileText className="w-4 h-4 text-muted-foreground shrink-0 mt-0.5" />
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{doc.title}</p>
                      <p className="text-xs text-muted-foreground">{CATEGORY_LABELS[doc.category] || doc.category}</p>
                    </div>
                  </div>
                  <span className={`px-2.5 py-1 rounded-full text-xs font-medium shrink-0 ${STATUS_COLORS[doc.status] || STATUS_COLORS.brouillon}`}>
                    {STATUS_LABELS[doc.status] || doc.status}
                  </span>
                </div>
                <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-muted">
                    <VisIcon className="w-3 h-3" />{VISIBILITY_LABELS[doc.visibility] || doc.visibility}
                  </span>
                </div>
                {doc.notes && <p className="text-xs text-muted-foreground mt-2">{doc.notes}</p>}
                <div className="flex items-center gap-1 mt-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  {doc.file_url && (
                    <a href={doc.file_url} target="_blank" rel="noopener noreferrer" className="p-1.5 rounded-lg hover:bg-accent text-muted-foreground" title="Ouvrir">
                      <Eye className="w-3.5 h-3.5" />
                    </a>
                  )}
                  <button onClick={() => openEdit(doc)} className="px-3 py-1.5 rounded-lg text-xs hover:bg-accent transition-colors">Modifier</button>
                  <button onClick={() => handleDelete(doc)} className="p-1.5 rounded-lg hover:bg-red-50 text-muted-foreground hover:text-red-500 transition-colors">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40" onClick={() => setShowForm(false)}>
          <div className="w-full max-w-lg bg-card rounded-2xl border border-border p-6 m-4 max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display font-semibold text-lg">{editing ? 'Modifier le document' : 'Nouveau document'}</h3>
              <button onClick={() => setShowForm(false)} className="p-1.5 rounded-lg hover:bg-accent"><X className="w-4 h-4" /></button>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2">
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Titre *</label>
                <input value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-border text-sm" placeholder="Ex: Contrat traiteur" />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Catégorie</label>
                <select value={form.category} onChange={e => setForm({ ...form, category: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-border text-sm">
                  {Object.entries(CATEGORY_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                </select>
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Statut</label>
                <select value={form.status} onChange={e => setForm({ ...form, status: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-border text-sm">
                  {Object.entries(STATUS_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                </select>
              </div>
              <div className="col-span-2">
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Visibilité</label>
                <select value={form.visibility} onChange={e => setForm({ ...form, visibility: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-border text-sm">
                  {Object.entries(VISIBILITY_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                </select>
              </div>
              <div className="col-span-2">
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Fichier</label>
                {form.file_url ? (
                  <div className="flex items-center gap-2 p-2 rounded-lg border border-border bg-muted/30">
                    <FileText className="w-4 h-4 text-muted-foreground" />
                    <span className="text-xs flex-1 truncate">Fichier téléversé</span>
                    <button onClick={() => setForm({ ...form, file_url: '' })} className="text-xs text-red-500">Retirer</button>
                  </div>
                ) : (
                  <label className="flex items-center justify-center gap-2 p-3 rounded-lg border border-dashed border-border cursor-pointer hover:bg-accent transition-colors">
                    <Upload className="w-4 h-4 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">{uploading ? 'Téléversement...' : 'Téléverser un fichier'}</span>
                    <input type="file" className="hidden" onChange={handleUpload} disabled={uploading} />
                  </label>
                )}
              </div>
              <div className="col-span-2">
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Ou URL externe</label>
                <input value={form.external_url} onChange={e => setForm({ ...form, external_url: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-border text-sm" placeholder="https://..." />
              </div>
              {form.visibility === 'prestataires_concernes' && (
                <div className="col-span-2">
                  <label className="text-xs font-medium text-muted-foreground mb-1 block">Prestataires autorisés</label>
                  <div className="flex flex-wrap gap-2">
                    {participants.filter(p => p.role === 'prestataire').map(p => {
                      const checked = (form.authorized_participant_ids || []).includes(p.id);
                      return (
                        <button
                          key={p.id}
                          type="button"
                          onClick={() => setForm({
                            ...form,
                            authorized_participant_ids: checked
                              ? (form.authorized_participant_ids || []).filter(id => id !== p.id)
                              : [...(form.authorized_participant_ids || []), p.id]
                          })}
                          className={`px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${
                            checked ? 'bg-foreground text-background' : 'bg-muted text-muted-foreground hover:bg-accent'
                          }`}
                        >
                          {p.display_name}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
              <div className="col-span-2">
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Notes</label>
                <textarea value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} rows={2} className="w-full px-3 py-2 rounded-lg border border-border text-sm" />
              </div>
            </div>
            <div className="flex justify-end gap-2 mt-5">
              <button onClick={() => setShowForm(false)} className="px-4 py-2 rounded-lg text-sm hover:bg-accent transition-colors">Annuler</button>
              <button onClick={handleSave} className="px-4 py-2 rounded-lg bg-foreground text-background text-sm font-medium hover:opacity-90 transition-opacity">
                {editing ? 'Mettre à jour' : 'Ajouter'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}