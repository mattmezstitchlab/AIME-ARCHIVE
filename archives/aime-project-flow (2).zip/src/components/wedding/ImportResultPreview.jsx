import { Check, X, AlertTriangle } from 'lucide-react';

function scoreColor(score) {
  if (score >= 70) return 'text-emerald-600 bg-emerald-50';
  if (score >= 40) return 'text-amber-600 bg-amber-50';
  return 'text-red-600 bg-red-50';
}

export default function ImportResultPreview({ result, onConfirm, onCancel }) {
  const { extracted_data: d, compatibility: c } = result;
  return (
    <div className="space-y-4">
      <div>
        <p className="font-display font-semibold text-lg">{d.name || 'Fiche sans nom'}</p>
        <p className="text-xs text-muted-foreground">{d.category || 'Catégorie non détectée'}{d.location ? ` · ${d.location}` : ''}</p>
      </div>

      {d.description && <p className="text-sm text-foreground">{d.description}</p>}

      <div className="grid grid-cols-2 gap-2 text-xs text-muted-foreground">
        {d.estimated_budget > 0 && <span>Budget estimé : <span className="font-medium text-foreground">{d.estimated_budget.toLocaleString('fr-FR')} €</span></span>}
        {d.style && <span>Style : <span className="font-medium text-foreground">{d.style}</span></span>}
        {d.capacity && <span>Capacité : <span className="font-medium text-foreground">{d.capacity}</span></span>}
        {d.contact_email && <span>Email : <span className="font-medium text-foreground">{d.contact_email}</span></span>}
        {d.contact_phone && <span>Téléphone : <span className="font-medium text-foreground">{d.contact_phone}</span></span>}
        {d.website && <span>Site : <span className="font-medium text-foreground">{d.website}</span></span>}
      </div>

      <div className="rounded-xl border border-border/60 p-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Compatibilité projet</span>
          <span className={`px-2.5 py-1 rounded-full text-xs font-semibold ${scoreColor(c.score || 0)}`}>{Math.round(c.score || 0)}%</span>
        </div>
        <p className="text-sm text-foreground">{c.explanation}</p>
        {(c.points_to_check || []).length > 0 && (
          <ul className="mt-2 space-y-1">
            {c.points_to_check.map((pt, i) => (
              <li key={i} className="flex items-start gap-1.5 text-xs text-amber-700">
                <AlertTriangle className="w-3 h-3 mt-0.5 shrink-0" /> {pt}
              </li>
            ))}
          </ul>
        )}
      </div>

      <div className="flex justify-end gap-2">
        <button onClick={onCancel} className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm hover:bg-accent transition-colors">
          <X className="w-3.5 h-3.5" /> Annuler
        </button>
        <button onClick={onConfirm} className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-foreground text-background text-sm font-medium hover:opacity-90 transition-opacity">
          <Check className="w-3.5 h-3.5" /> Ajouter au projet
        </button>
      </div>
    </div>
  );
}