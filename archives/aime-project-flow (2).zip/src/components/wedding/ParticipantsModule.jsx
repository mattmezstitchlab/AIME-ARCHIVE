import { useState, useMemo } from 'react';
import { Plus, X, Mail, Phone, Clock, CheckCircle, AlertCircle, Trash2, Copy, Users, Upload, FileText, Euro, Search, Sparkles, ShieldOff, ShieldCheck } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useToast } from '@/components/ui/use-toast';
import { Image } from '@/components/ui/image';
import ImportVendorDialog from './ImportVendorDialog';

const CATEGORY_LABELS = {
  lieu: 'Lieu', traiteur: 'Traiteur', photographe: 'Photographe', videaste: 'Vidéaste',
  dj: 'DJ', musicien: 'Musicien', fleuriste: 'Fleuriste', decorateur: 'Décorateur',
  officiant: 'Officiant', wedding_planner: 'Wedding Planner', transport: 'Transport',
  patisserie: 'Pâtisserie', maquillage: 'Maquillage', coiffure: 'Coiffure',
  animation: 'Animation', technique: 'Technique', autre: 'Autre',
};

const ROLE_LABELS = {
  marie: 'Marié(e)', co_organisateur: 'Co-organisateur', wedding_planner: 'Wedding Planner',
  temoin: 'Témoin', prestataire: 'Prestataire', invite: 'Invité', visiteur: 'Visiteur',
};

// Cycle d'invitation : draft -> invited (créée) -> sent (envoyée) -> viewed (ouverte) -> accepted -> active
const STATUS_LABELS = {
  draft: 'Brouillon', invited: 'Invitation créée', sent: 'Invitation envoyée', pending: 'En attente',
  viewed: 'Invitation ouverte', accepted: 'Acceptée', declined: 'Refusée', active: 'Actif dans le mariage',
  completed: 'Terminé', cancelled: 'Annulé',
};

const STATUS_COLORS = {
  draft: 'bg-muted text-muted-foreground', invited: 'bg-blue-100 text-blue-700', sent: 'bg-indigo-100 text-indigo-700',
  pending: 'bg-muted text-muted-foreground', viewed: 'bg-purple-100 text-purple-700', accepted: 'bg-emerald-100 text-emerald-700',
  declined: 'bg-red-100 text-red-700', active: 'bg-emerald-600 text-white',
  completed: 'bg-slate-200 text-slate-700', cancelled: 'bg-red-50 text-red-600',
};

const PERMISSION_OPTIONS = [
  { key: 'view_timeline', label: 'Voir le déroulé' },
  { key: 'view_contacts', label: 'Voir les contacts' },
  { key: 'view_documents', label: 'Voir les documents' },
  { key: 'edit_timeline', label: 'Modifier le déroulé' },
  { key: 'manage_guests', label: 'Gérer les invités' },
  { key: 'manage_vendors', label: 'Gérer les prestataires' },
  { key: 'manage_documents', label: 'Gérer les documents' },
  { key: 'view_budget', label: 'Voir le budget' },
];

const EMPTY_FORM = {
  display_name: '', organization_name: '', role: 'prestataire', category: 'autre',
  photo_url: '', contact_email: '', contact_phone: '', responsibilities: '',
  arrival_time: '', setup_time: '', service_start_time: '', service_end_time: '', departure_time: '',
  budget_estimated: 0, budget_actual: 0,
  permissions: ['view_timeline'], notes: '',
};

function documentsForParticipant(documents, participantId) {
  return (documents || []).filter((d) =>
    d.visibility === 'tous_prestataires' ||
    d.visibility === 'public' ||
    (d.visibility === 'prestataires_concernes' && (d.authorized_participant_ids || []).includes(participantId))
  );
}

export default function ParticipantsModule({ projectId, participants, setParticipants, documents = [], onReload }) {
  const { toast } = useToast();
  const [showForm, setShowForm] = useState(false);
  const [showImport, setShowImport] = useState(false);
  const [editing, setEditing] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [form, setForm] = useState(EMPTY_FORM);
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');

  async function handleSave() {
    if (!form.display_name.trim()) return;
    try {
      if (editing) {
        await base44.entities.WeddingParticipant.update(editing.id, form);
        setParticipants(participants.map(p => p.id === editing.id ? { ...editing, ...form } : p));
        toast({ title: 'Participant mis à jour' });
      } else {
        const me = await base44.auth.me();
        const created = await base44.entities.WeddingParticipant.create({
          ...form,
          project_id: projectId,
          owner_id: me.id,
          status: 'invited',
        });
        setParticipants([...participants, created]);
        toast({ title: 'Prestataire ajouté', description: 'Invitation créée — pensez à envoyer le lien' });
      }
      setShowForm(false);
      setEditing(null);
      setForm(EMPTY_FORM);
    } catch (e) {
      toast({ title: 'Erreur', description: e.message, variant: 'destructive' });
    }
  }

  const CATEGORY_KEYWORDS = {
    lieu: ['lieu', 'château', 'domaine', 'salle', 'manoir', 'venue'],
    traiteur: ['traiteur', 'catering', 'menu'],
    photographe: ['photographe', 'photo'],
    videaste: ['vidéaste', 'video'],
    dj: ['dj', 'disc jockey'],
    musicien: ['musicien', 'groupe', 'orchestre'],
    fleuriste: ['fleuriste', 'fleur'],
    decorateur: ['décorateur', 'décoration'],
    officiant: ['officiant', 'célébrant'],
    wedding_planner: ['wedding planner', 'organisateur'],
    transport: ['transport', 'voiture', 'limousine'],
    patisserie: ['pâtisserie', 'gâteau'],
    maquillage: ['maquillage', 'makeup'],
    coiffure: ['coiffure', 'coiffeur'],
    animation: ['animation', 'animateur'],
    technique: ['technique', 'son', 'lumière'],
  };

  function matchCategory(text) {
    const t = (text || '').toLowerCase();
    return Object.keys(CATEGORY_KEYWORDS).find((k) => CATEGORY_KEYWORDS[k].some((kw) => t.includes(kw))) || 'autre';
  }

  async function handleImportConfirm(result, sourceMeta) {
    try {
      const me = await base44.auth.me();
      const d = result.extracted_data || {};
      const created = await base44.entities.WeddingParticipant.create({
        display_name: d.name || 'Prestataire importé',
        organization_name: d.name || '',
        role: 'prestataire',
        category: matchCategory(d.category),
        contact_email: d.contact_email || '',
        contact_phone: d.contact_phone || '',
        responsibilities: d.description || '',
        budget_estimated: d.estimated_budget || 0,
        notes: d.website ? `Site : ${d.website}` : '',
        project_id: projectId,
        owner_id: me.id,
        status: 'draft',
        imported_from: sourceMeta.imported_from,
        source_url: sourceMeta.source_url || '',
        ai_summary: result.compatibility?.explanation || '',
        compatibility_score: result.compatibility?.score ?? null,
        extracted_data: d,
      });
      setParticipants([...participants, created]);
      setShowImport(false);
      toast({ title: 'Fiche importée', description: `${created.display_name} ajouté en brouillon` });
    } catch (e) {
      toast({ title: 'Erreur', description: e.message, variant: 'destructive' });
    }
  }

  async function handlePhotoUpload(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setForm(f => ({ ...f, photo_url: file_url }));
    } catch (err) {
      toast({ title: 'Erreur téléversement', description: err.message, variant: 'destructive' });
    }
    setUploading(false);
  }

  async function handleDelete(participant) {
    try {
      await base44.entities.WeddingParticipant.delete(participant.id);
      setParticipants(participants.filter(p => p.id !== participant.id));
      toast({ title: 'Participant supprimé' });
    } catch (e) {
      toast({ title: 'Erreur', description: e.message, variant: 'destructive' });
    }
  }

  function openEdit(p) {
    setEditing(p);
    setForm({
      display_name: p.display_name || '', organization_name: p.organization_name || '',
      role: p.role || 'prestataire', category: p.category || 'autre', photo_url: p.photo_url || '',
      contact_email: p.contact_email || '', contact_phone: p.contact_phone || '',
      responsibilities: p.responsibilities || '',
      arrival_time: p.arrival_time || '', setup_time: p.setup_time || '',
      service_start_time: p.service_start_time || '', service_end_time: p.service_end_time || '',
      departure_time: p.departure_time || '',
      budget_estimated: p.budget_estimated || 0, budget_actual: p.budget_actual || 0,
      permissions: p.permissions || ['view_timeline'], notes: p.notes || '',
    });
    setShowForm(true);
  }

  async function markInvitationSent(p) {
    const url = `${window.location.origin}/vendor/${p.id}`;
    navigator.clipboard.writeText(url);
    try {
      const now = new Date().toISOString();
      await base44.entities.WeddingParticipant.update(p.id, { status: 'sent', invited_at: now });
      setParticipants(participants.map(x => x.id === p.id ? { ...x, status: 'sent', invited_at: now } : x));
      toast({ title: 'Lien copié', description: `Invitation marquée comme envoyée à ${p.display_name}` });
    } catch (e) {
      toast({ title: 'Erreur', description: e.message, variant: 'destructive' });
    }
  }

  function copyInviteLink(p) {
    const url = `${window.location.origin}/vendor/${p.id}`;
    navigator.clipboard.writeText(url);
    toast({ title: 'Lien copié' });
  }

  async function toggleRevoke(p) {
    try {
      const next = !p.token_revoked;
      await base44.entities.WeddingParticipant.update(p.id, { token_revoked: next });
      setParticipants(participants.map(x => x.id === p.id ? { ...x, token_revoked: next } : x));
      toast({ title: next ? 'Accès révoqué' : 'Accès réactivé' });
    } catch (e) {
      toast({ title: 'Erreur', description: e.message, variant: 'destructive' });
    }
  }

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return participants.filter((p) => {
      if (q && !(p.display_name || '').toLowerCase().includes(q) && !(p.organization_name || '').toLowerCase().includes(q)) return false;
      if (categoryFilter !== 'all' && p.category !== categoryFilter) return false;
      if (statusFilter !== 'all' && p.status !== statusFilter) return false;
      return true;
    });
  }, [participants, search, categoryFilter, statusFilter]);

  const vendors = filtered.filter(p => p.role === 'prestataire');
  const team = filtered.filter(p => p.role !== 'prestataire');
  const usedCategories = useMemo(() => [...new Set(participants.filter(p => p.role === 'prestataire').map(p => p.category))], [participants]);

  function ParticipantCard({ p, isVendor }) {
    const docCount = documentsForParticipant(documents, p.id).length;
    return (
      <div className="p-4 rounded-xl border border-border/60 bg-card group">
        <div className="flex items-start gap-3 mb-2">
          <div className="w-11 h-11 rounded-full overflow-hidden bg-muted shrink-0 flex items-center justify-center">
            {p.photo_url ? (
              <Image src={p.photo_url} alt={p.display_name} className="w-11 h-11" />
            ) : (
              <span className="text-sm font-semibold text-muted-foreground">{(p.display_name || '?').charAt(0).toUpperCase()}</span>
            )}
          </div>
          <div className="flex-1 min-w-0">
            <p className="font-medium truncate">{p.display_name}</p>
            <p className="text-xs text-muted-foreground">{isVendor ? (CATEGORY_LABELS[p.category] || p.category) : (ROLE_LABELS[p.role] || p.role)}</p>
            {p.organization_name && <p className="text-xs text-muted-foreground">{p.organization_name}</p>}
          </div>
          <span className={`px-2.5 py-1 rounded-full text-xs font-medium shrink-0 ${STATUS_COLORS[p.status] || STATUS_COLORS.invited}`}>
            {STATUS_LABELS[p.status] || p.status}
          </span>
        </div>
        {p.responsibilities && <p className="text-xs text-foreground mt-2 mb-2">{p.responsibilities}</p>}
        <div className="flex flex-col gap-1 text-xs text-muted-foreground">
          {p.contact_email && <span className="flex items-center gap-1"><Mail className="w-3 h-3" />{p.contact_email}</span>}
          {p.contact_phone && <span className="flex items-center gap-1"><Phone className="w-3 h-3" />{p.contact_phone}</span>}
          {p.arrival_time && <span className="flex items-center gap-1"><Clock className="w-3 h-3" />Arrivée Jour J : {p.arrival_time}</span>}
        </div>
        {(isVendor && (p.budget_estimated > 0 || p.budget_actual > 0)) && (
          <div className="flex gap-4 mt-3 pt-3 border-t border-border/40 text-xs text-muted-foreground">
            {p.budget_estimated > 0 && <span className="flex items-center gap-1"><Euro className="w-3 h-3" />Estimé: <span className="font-medium text-foreground">{p.budget_estimated.toLocaleString('fr-FR')} €</span></span>}
            {p.budget_actual > 0 && <span className="flex items-center gap-1"><Euro className="w-3 h-3" />Réel: <span className="font-medium text-foreground">{p.budget_actual.toLocaleString('fr-FR')} €</span></span>}
          </div>
        )}
        <div className="flex items-center gap-1 mt-2 text-xs text-muted-foreground">
          <FileText className="w-3 h-3" /> {docCount} document{docCount > 1 ? 's' : ''} partagé{docCount > 1 ? 's' : ''}
        </div>
        {typeof p.compatibility_score === 'number' && (
          <div className="flex items-center gap-1 mt-2 text-xs">
            <Sparkles className="w-3 h-3 text-muted-foreground" />
            <span className="text-muted-foreground">Compatibilité IA :</span>
            <span className={`font-semibold ${p.compatibility_score >= 70 ? 'text-emerald-600' : p.compatibility_score >= 40 ? 'text-amber-600' : 'text-red-600'}`}>{Math.round(p.compatibility_score)}%</span>
          </div>
        )}
        {!p.arrival_time && p.status === 'accepted' && (
          <div className="flex items-center gap-1 mt-2 text-xs text-amber-600">
            <AlertCircle className="w-3 h-3" /> Heure d'arrivée non renseignée
          </div>
        )}
        <div className="flex justify-end gap-1 mt-2 opacity-0 group-hover:opacity-100 transition-opacity">
          {isVendor && (p.status === 'invited' || p.status === 'draft') && (
            <button onClick={() => markInvitationSent(p)} className="p-1.5 rounded-lg hover:bg-accent text-muted-foreground" title="Copier le lien et marquer envoyée">
              <Copy className="w-3.5 h-3.5" />
            </button>
          )}
          {isVendor && p.status !== 'invited' && p.status !== 'draft' && (
            <button onClick={() => copyInviteLink(p)} className="p-1.5 rounded-lg hover:bg-accent text-muted-foreground" title="Copier le lien prestataire">
              <Copy className="w-3.5 h-3.5" />
            </button>
          )}
          {isVendor && (
            <button
              onClick={() => toggleRevoke(p)}
              className={`p-1.5 rounded-lg hover:bg-accent ${p.token_revoked ? 'text-red-500' : 'text-muted-foreground'}`}
              title={p.token_revoked ? "Réactiver l'accès au portail" : "Révoquer l'accès au portail"}
            >
              {p.token_revoked ? <ShieldOff className="w-3.5 h-3.5" /> : <ShieldCheck className="w-3.5 h-3.5" />}
            </button>
          )}
          <button onClick={() => openEdit(p)} className="px-3 py-1.5 rounded-lg text-xs hover:bg-accent transition-colors">Modifier</button>
          <button onClick={() => handleDelete(p)} className="p-1.5 rounded-lg hover:bg-red-50 text-muted-foreground hover:text-red-500 transition-colors">
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-8 py-10">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-display font-bold mb-1">Équipe & Prestataires</h1>
          <p className="text-sm text-muted-foreground">{participants.length} participant(s) — {vendors.length} prestataire(s)</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowImport(true)}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full border border-border bg-card text-sm font-medium hover:bg-accent transition-colors"
          >
            <Sparkles className="w-4 h-4" /> Importer un prestataire
          </button>
          <button
            onClick={() => { setEditing(null); setForm(EMPTY_FORM); setShowForm(true); }}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full bg-foreground text-background text-sm font-medium hover:opacity-90 transition-opacity"
          >
            <Plus className="w-4 h-4" /> Ajouter
          </button>
        </div>
      </div>

      {showImport && (
        <ImportVendorDialog projectId={projectId} onClose={() => setShowImport(false)} onImported={handleImportConfirm} />
      )}

      <div className="flex flex-col sm:flex-row gap-2 mb-6">
        <div className="relative flex-1">
          <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Rechercher un prestataire..."
            className="w-full pl-8 pr-3 py-2 rounded-lg border border-border text-sm bg-card"
          />
        </div>
        <select value={categoryFilter} onChange={(e) => setCategoryFilter(e.target.value)} className="px-3 py-2 rounded-lg border border-border text-sm bg-card">
          <option value="all">Toutes les catégories</option>
          {usedCategories.map((c) => <option key={c} value={c}>{CATEGORY_LABELS[c] || c}</option>)}
        </select>
        <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="px-3 py-2 rounded-lg border border-border text-sm bg-card">
          <option value="all">Tous les statuts</option>
          {Object.entries(STATUS_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
        </select>
      </div>

      {participants.length > 0 && vendors.length === 0 && team.length === 0 && (
        <div className="text-center py-10">
          <p className="text-sm text-muted-foreground">Aucun participant ne correspond à ces filtres</p>
        </div>
      )}

      {vendors.length > 0 && (
        <div className="mb-8">
          <h2 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">Prestataires</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {vendors.map(v => <ParticipantCard key={v.id} p={v} isVendor />)}
          </div>
        </div>
      )}

      {team.length > 0 && (
        <div className="mb-8">
          <h2 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">Équipe</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {team.map(p => <ParticipantCard key={p.id} p={p} isVendor={false} />)}
          </div>
        </div>
      )}

      {participants.length === 0 && (
        <div className="text-center py-16">
          <Users className="w-10 h-10 mx-auto text-muted-foreground/40 mb-3" />
          <p className="text-sm text-muted-foreground">Aucun participant pour le moment</p>
          <p className="text-xs text-muted-foreground mt-1">Ajoutez votre lieu, traiteur, photographe, DJ...</p>
        </div>
      )}

      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40" onClick={() => setShowForm(false)}>
          <div className="w-full max-w-2xl bg-card rounded-2xl border border-border p-6 m-4 max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display font-semibold text-lg">{editing ? 'Modifier le participant' : 'Nouveau participant'}</h3>
              <button onClick={() => setShowForm(false)} className="p-1.5 rounded-lg hover:bg-accent"><X className="w-4 h-4" /></button>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2 flex items-center gap-3">
                <div className="w-14 h-14 rounded-full overflow-hidden bg-muted shrink-0 flex items-center justify-center">
                  {form.photo_url ? <Image src={form.photo_url} alt="" className="w-14 h-14" /> : <Users className="w-5 h-5 text-muted-foreground" />}
                </div>
                <label className="flex items-center gap-2 px-3 py-2 rounded-lg border border-dashed border-border cursor-pointer hover:bg-accent transition-colors text-xs text-muted-foreground">
                  <Upload className="w-3.5 h-3.5" /> {uploading ? 'Téléversement...' : 'Photo / logo'}
                  <input type="file" accept="image/*" className="hidden" onChange={handlePhotoUpload} disabled={uploading} />
                </label>
              </div>
              <div className="col-span-2">
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Nom / Affichage *</label>
                <input value={form.display_name} onChange={e => setForm({ ...form, display_name: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-border text-sm" placeholder="Nom du prestataire ou de la personne" />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Rôle</label>
                <select value={form.role} onChange={e => setForm({ ...form, role: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-border text-sm">
                  {Object.entries(ROLE_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                </select>
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Catégorie</label>
                <select value={form.category} onChange={e => setForm({ ...form, category: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-border text-sm">
                  {Object.entries(CATEGORY_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                </select>
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Organisation</label>
                <input value={form.organization_name} onChange={e => setForm({ ...form, organization_name: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-border text-sm" placeholder="Nom de l'entreprise" />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Email</label>
                <input value={form.contact_email} onChange={e => setForm({ ...form, contact_email: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-border text-sm" placeholder="contact@email.com" />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Téléphone</label>
                <input value={form.contact_phone} onChange={e => setForm({ ...form, contact_phone: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-border text-sm" placeholder="06 12 34 56 78" />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Budget estimé (€)</label>
                <input type="number" value={form.budget_estimated} onChange={e => setForm({ ...form, budget_estimated: Number(e.target.value) })} className="w-full px-3 py-2 rounded-lg border border-border text-sm" />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Budget réel (€)</label>
                <input type="number" value={form.budget_actual} onChange={e => setForm({ ...form, budget_actual: Number(e.target.value) })} className="w-full px-3 py-2 rounded-lg border border-border text-sm" />
              </div>
              <div className="col-span-2">
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Mission / Responsabilités</label>
                <textarea value={form.responsibilities} onChange={e => setForm({ ...form, responsibilities: e.target.value })} rows={2} className="w-full px-3 py-2 rounded-lg border border-border text-sm" placeholder="Ex: Photographie de la cérémonie et du cocktail" />
              </div>
              <div className="col-span-2">
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Horaires d'intervention (Jour J)</label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  <div><input value={form.arrival_time} onChange={e => setForm({ ...form, arrival_time: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-border text-sm" placeholder="Arrivée HH:MM" /></div>
                  <div><input value={form.setup_time} onChange={e => setForm({ ...form, setup_time: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-border text-sm" placeholder="Setup HH:MM" /></div>
                  <div><input value={form.service_start_time} onChange={e => setForm({ ...form, service_start_time: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-border text-sm" placeholder="Début HH:MM" /></div>
                  <div><input value={form.service_end_time} onChange={e => setForm({ ...form, service_end_time: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-border text-sm" placeholder="Fin HH:MM" /></div>
                  <div><input value={form.departure_time} onChange={e => setForm({ ...form, departure_time: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-border text-sm" placeholder="Départ HH:MM" /></div>
                </div>
              </div>
              <div className="col-span-2">
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Permissions</label>
                <div className="flex flex-wrap gap-2">
                  {PERMISSION_OPTIONS.map(opt => {
                    const checked = (form.permissions || []).includes(opt.key);
                    return (
                      <button
                        key={opt.key}
                        type="button"
                        onClick={() => setForm({
                          ...form,
                          permissions: checked
                            ? (form.permissions || []).filter(p => p !== opt.key)
                            : [...(form.permissions || []), opt.key]
                        })}
                        className={`px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${
                          checked ? 'bg-foreground text-background' : 'bg-muted text-muted-foreground hover:bg-accent'
                        }`}
                      >
                        {opt.label}
                      </button>
                    );
                  })}
                </div>
              </div>
              <div className="col-span-2">
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Notes</label>
                <textarea value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} rows={2} className="w-full px-3 py-2 rounded-lg border border-border text-sm" placeholder="Notes internes" />
              </div>
            </div>
            <div className="flex justify-end gap-2 mt-5">
              <button onClick={() => setShowForm(false)} className="px-4 py-2 rounded-lg text-sm hover:bg-accent transition-colors">Annuler</button>
              <button onClick={handleSave} className="px-4 py-2 rounded-lg bg-foreground text-background text-sm font-medium hover:opacity-90 transition-opacity">
                {editing ? 'Mettre à jour' : 'Ajouter'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}