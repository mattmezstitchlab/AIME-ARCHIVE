import { useState } from 'react';
import { Plus, X, Clock, MapPin, User, Trash2, AlertCircle } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useToast } from '@/components/ui/use-toast';

const STATUS_LABELS = {
  a_venir: 'À venir', en_preparation: 'En préparation', pret: 'Prêt',
  en_cours: 'En cours', termine: 'Terminé', retard: 'En retard',
  bloque: 'Bloqué', annule: 'Annulé',
};

const STATUS_COLORS = {
  a_venir: 'bg-muted text-muted-foreground', en_preparation: 'bg-blue-100 text-blue-700',
  pret: 'bg-purple-100 text-purple-700', en_cours: 'bg-amber-100 text-amber-700',
  termine: 'bg-emerald-100 text-emerald-700', retard: 'bg-orange-100 text-orange-700',
  bloque: 'bg-red-100 text-red-700', annule: 'bg-red-50 text-red-600',
};

const DEFAULT_TIMELINE = [
  { title: 'Accès au lieu', start_time: '08:00', duration_minutes: 30, position: 0 },
  { title: 'Installation technique', start_time: '08:30', duration_minutes: 30, position: 1 },
  { title: 'Arrivée fleuriste', start_time: '09:00', duration_minutes: 60, position: 2 },
  { title: 'Mise en place décoration', start_time: '10:00', duration_minutes: 60, position: 3 },
  { title: 'Préparation des mariés', start_time: '11:00', duration_minutes: 150, position: 4 },
  { title: 'Arrivée photographe', start_time: '13:30', duration_minutes: 30, position: 5 },
  { title: 'Accueil invités', start_time: '14:00', duration_minutes: 60, position: 6 },
  { title: 'Cérémonie', start_time: '15:00', duration_minutes: 60, position: 7 },
  { title: 'Photos', start_time: '16:00', duration_minutes: 120, position: 8 },
  { title: 'Cocktail', start_time: '18:00', duration_minutes: 120, position: 9 },
  { title: 'Dîner', start_time: '20:00', duration_minutes: 150, position: 10 },
  { title: 'Ouverture de bal', start_time: '22:30', duration_minutes: 90, position: 11 },
  { title: 'Fin de prestation musicale', start_time: '01:00', duration_minutes: 60, position: 12 },
  { title: 'Fin de soirée', start_time: '02:00', duration_minutes: 0, position: 13 },
];

export default function TimelineModule({ projectId, timelineItems, setTimelineItems, participants }) {
  const { toast } = useToast();
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({
    title: '', description: '', start_time: '', duration_minutes: 60,
    location: '', zone: '', responsible_name: '', participant_ids: [],
    notes: '', status: 'a_venir',
  });

  async function handleSave() {
    if (!form.title.trim() || !form.start_time.trim()) return;
    try {
      if (editing) {
        await base44.entities.WeddingTimelineItem.update(editing.id, form);
        setTimelineItems(timelineItems.map(t => t.id === editing.id ? { ...editing, ...form } : t));
        toast({ title: 'Étape mise à jour' });
      } else {
        const me = await base44.auth.me();
        const created = await base44.entities.WeddingTimelineItem.create({
          ...form,
          project_id: projectId,
          owner_id: me.id,
          position: timelineItems.length,
        });
        setTimelineItems([...timelineItems, created]);
        toast({ title: 'Étape ajoutée' });
      }
      setShowForm(false);
      setEditing(null);
      setForm({ title: '', description: '', start_time: '', duration_minutes: 60, location: '', zone: '', responsible_name: '', participant_ids: [], notes: '', status: 'a_venir' });
    } catch (e) {
      toast({ title: 'Erreur', description: e.message, variant: 'destructive' });
    }
  }

  async function handleDelete(item) {
    try {
      await base44.entities.WeddingTimelineItem.delete(item.id);
      setTimelineItems(timelineItems.filter(t => t.id !== item.id));
      toast({ title: 'Étape supprimée' });
    } catch (e) {
      toast({ title: 'Erreur', description: e.message, variant: 'destructive' });
    }
  }

  async function updateStatus(item, status) {
    try {
      await base44.entities.WeddingTimelineItem.update(item.id, { status });
      setTimelineItems(timelineItems.map(t => t.id === item.id ? { ...t, status } : t));
    } catch (e) {
      toast({ title: 'Erreur', description: e.message, variant: 'destructive' });
    }
  }

  async function loadDefaultTimeline() {
    try {
      const me = await base44.auth.me();
      const created = await base44.entities.WeddingTimelineItem.bulkCreate(
        DEFAULT_TIMELINE.map(t => ({ ...t, project_id: projectId, owner_id: me.id }))
      );
      setTimelineItems([...timelineItems, ...created]);
      toast({ title: 'Déroulé type chargé', description: `${created.length} étapes ajoutées` });
    } catch (e) {
      toast({ title: 'Erreur', description: e.message, variant: 'destructive' });
    }
  }

  function openEdit(item) {
    setEditing(item);
    setForm({
      title: item.title || '', description: item.description || '',
      start_time: item.start_time || '', duration_minutes: item.duration_minutes || 60,
      location: item.location || '', zone: item.zone || '',
      responsible_name: item.responsible_name || '',
      participant_ids: item.participant_ids || [],
      notes: item.notes || '', status: item.status || 'a_venir',
    });
    setShowForm(true);
  }

  const sorted = [...timelineItems].sort((a, b) => (a.position || 0) - (b.position || 0));
  const now = new Date();
  const currentHours = now.getHours() * 60 + now.getMinutes();

  return (
    <div className="max-w-3xl mx-auto px-8 py-10">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-display font-bold mb-1">Jour J — AIME LIVE™</h1>
          <p className="text-sm text-muted-foreground">{timelineItems.length} étape(s) — Déroulé chronologique</p>
        </div>
        <div className="flex gap-2">
          {timelineItems.length === 0 && (
            <button onClick={loadDefaultTimeline} className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full border border-border bg-card text-sm font-medium hover:bg-accent transition-colors">
              <Clock className="w-4 h-4" /> Charger déroulé type
            </button>
          )}
          <button
            onClick={() => { setEditing(null); setForm({ title: '', description: '', start_time: '', duration_minutes: 60, location: '', zone: '', responsible_name: '', participant_ids: [], notes: '', status: 'a_venir' }); setShowForm(true); }}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full bg-foreground text-background text-sm font-medium hover:opacity-90 transition-opacity"
          >
            <Plus className="w-4 h-4" /> Ajouter
          </button>
        </div>
      </div>

      {sorted.length === 0 ? (
        <div className="text-center py-16">
          <Clock className="w-10 h-10 mx-auto text-muted-foreground/40 mb-3" />
          <p className="text-sm text-muted-foreground">Aucune étape pour le moment</p>
          <p className="text-xs text-muted-foreground mt-1">Chargez le déroulé type ou créez vos étapes</p>
        </div>
      ) : (
        <div className="space-y-2">
          {sorted.map((item, i) => {
            const [h, m] = (item.start_time || '').split(':').map(Number);
            const itemMinutes = (h || 0) * 60 + (m || 0);
            const isCurrent = item.status === 'en_cours';
            const isPast = item.status === 'termine';
            const linkedParticipants = (item.participant_ids || []).map(pid => participants.find(p => p.id === pid)).filter(Boolean);

            return (
              <div key={item.id} className={`p-4 rounded-xl border bg-card transition-colors group ${
                isCurrent ? 'border-amber-300 bg-amber-50' : isPast ? 'border-border/40 opacity-60' : 'border-border/60'
              }`}>
                <div className="flex items-start gap-4">
                  <div className="flex flex-col items-center shrink-0">
                    <span className="text-lg font-display font-bold">{item.start_time}</span>
                    {item.duration_minutes > 0 && <span className="text-xs text-muted-foreground">{item.duration_minutes}min</span>}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1">
                        <p className={`font-medium ${isPast ? 'line-through text-muted-foreground' : ''}`}>{item.title}</p>
                        {item.description && <p className="text-xs text-muted-foreground mt-0.5">{item.description}</p>}
                      </div>
                      <span className={`px-2.5 py-1 rounded-full text-xs font-medium shrink-0 ${STATUS_COLORS[item.status] || STATUS_COLORS.a_venir}`}>
                        {STATUS_LABELS[item.status] || item.status}
                      </span>
                    </div>
                    <div className="flex flex-wrap gap-3 mt-2 text-xs text-muted-foreground">
                      {item.location && <span className="flex items-center gap-1"><MapPin className="w-3 h-3" />{item.location}</span>}
                      {item.responsible_name && <span className="flex items-center gap-1"><User className="w-3 h-3" />{item.responsible_name}</span>}
                      {linkedParticipants.length > 0 && (
                        <span className="flex items-center gap-1"><User className="w-3 h-3" />{linkedParticipants.map(p => p.display_name).join(', ')}</span>
                      )}
                    </div>
                    <div className="flex items-center gap-1 mt-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <select
                        value={item.status}
                        onChange={e => updateStatus(item, e.target.value)}
                        className="text-xs px-2 py-1 rounded-md border border-border bg-background"
                      >
                        {Object.entries(STATUS_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                      </select>
                      <button onClick={() => openEdit(item)} className="px-2 py-1 rounded-md text-xs hover:bg-accent transition-colors">Modifier</button>
                      <button onClick={() => handleDelete(item)} className="p-1 rounded-md hover:bg-red-50 text-muted-foreground hover:text-red-500 transition-colors">
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40" onClick={() => setShowForm(false)}>
          <div className="w-full max-w-lg bg-card rounded-2xl border border-border p-6 m-4 max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display font-semibold text-lg">{editing ? 'Modifier l\'étape' : 'Nouvelle étape'}</h3>
              <button onClick={() => setShowForm(false)} className="p-1.5 rounded-lg hover:bg-accent"><X className="w-4 h-4" /></button>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2">
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Titre *</label>
                <input value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-border text-sm" placeholder="Ex: Cérémonie" />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Heure *</label>
                <input type="time" value={form.start_time} onChange={e => setForm({ ...form, start_time: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-border text-sm" />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Durée (min)</label>
                <input type="number" value={form.duration_minutes} onChange={e => setForm({ ...form, duration_minutes: Number(e.target.value) })} className="w-full px-3 py-2 rounded-lg border border-border text-sm" />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Lieu</label>
                <input value={form.location} onChange={e => setForm({ ...form, location: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-border text-sm" placeholder="Ex: Salle principale" />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Zone</label>
                <input value={form.zone} onChange={e => setForm({ ...form, zone: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-border text-sm" placeholder="Ex: Extérieur" />
              </div>
              <div className="col-span-2">
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Responsable</label>
                <input value={form.responsible_name} onChange={e => setForm({ ...form, responsible_name: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-border text-sm" placeholder="Nom du responsable" />
              </div>
              <div className="col-span-2">
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Prestataires associés</label>
                <div className="flex flex-wrap gap-2">
                  {participants.filter(p => p.role === 'prestataire').map(p => {
                    const checked = (form.participant_ids || []).includes(p.id);
                    return (
                      <button
                        key={p.id}
                        type="button"
                        onClick={() => setForm({
                          ...form,
                          participant_ids: checked
                            ? (form.participant_ids || []).filter(id => id !== p.id)
                            : [...(form.participant_ids || []), p.id]
                        })}
                        className={`px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${
                          checked ? 'bg-foreground text-background' : 'bg-muted text-muted-foreground hover:bg-accent'
                        }`}
                      >
                        {p.display_name}
                      </button>
                    );
                  })}
                </div>
              </div>
              <div className="col-span-2">
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Statut</label>
                <select value={form.status} onChange={e => setForm({ ...form, status: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-border text-sm">
                  {Object.entries(STATUS_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                </select>
              </div>
              <div className="col-span-2">
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Notes</label>
                <textarea value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} rows={2} className="w-full px-3 py-2 rounded-lg border border-border text-sm" />
              </div>
            </div>
            <div className="flex justify-end gap-2 mt-5">
              <button onClick={() => setShowForm(false)} className="px-4 py-2 rounded-lg text-sm hover:bg-accent transition-colors">Annuler</button>
              <button onClick={handleSave} className="px-4 py-2 rounded-lg bg-foreground text-background text-sm font-medium hover:opacity-90 transition-opacity">
                {editing ? 'Mettre à jour' : 'Ajouter'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}