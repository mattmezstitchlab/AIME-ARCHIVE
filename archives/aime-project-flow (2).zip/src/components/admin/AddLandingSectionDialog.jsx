import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

const layouts = [["editorial", "Éditorial", "Lecture centrée"], ["cards", "Cartes", "Contenu segmenté"], ["split", "Partagé", "Deux colonnes"]];

export default function AddLandingSectionDialog({ open, onClose, onCreate }) {
  const [form, setForm] = useState({ type: "content", layout: "editorial", title: "", text: "" });
  const create = () => { if (!form.title.trim()) return; onCreate({ ...form, id: crypto.randomUUID() }); setForm({ type: "content", layout: "editorial", title: "", text: "" }); onClose(); };
  return <Dialog open={open} onOpenChange={value => !value && onClose()}><DialogContent className="sm:max-w-2xl"><DialogHeader><DialogTitle>Ajouter une section</DialogTitle></DialogHeader>
    <div className="grid gap-3 sm:grid-cols-3">{layouts.map(([id, label, text]) => <button key={id} onClick={() => setForm({ ...form, layout: id })} className={`rounded-md border p-4 text-left ${form.layout === id ? "border-foreground bg-muted" : "border-border"}`}><strong className="block text-sm">{label}</strong><span className="text-xs text-muted-foreground">{text}</span></button>)}</div>
    <select value={form.type} onChange={e => setForm({ ...form, type: e.target.value })} className="brand-select"><option value="content">Contenu</option><option value="features">Fonctionnalités</option><option value="statement">Déclaration</option></select>
    <Input value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} placeholder="Titre de la section" /><Textarea rows={4} value={form.text} onChange={e => setForm({ ...form, text: e.target.value })} placeholder="Texte de la section" />
    <div className="flex justify-end"><button onClick={create} disabled={!form.title.trim()} className="brand-secondary-btn disabled:opacity-40">Créer la section</button></div>
  </DialogContent></Dialog>;
}