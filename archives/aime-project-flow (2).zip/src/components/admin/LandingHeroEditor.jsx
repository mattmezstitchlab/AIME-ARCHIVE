import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

const visuals = [["shader", "Shader vivant"], ["minimal", "Minimal sombre"], ["split", "Éditorial partagé"]];

export default function LandingHeroEditor({ value, onChange }) {
  const set = (key, next) => onChange({ ...value, [key]: next });
  return <section className="rounded-lg border border-border bg-card p-6 shadow-sm">
    <div className="mb-6"><span className="brand-badge">Hero</span><h2 className="mt-3 text-xl font-semibold">Direction visuelle</h2></div>
    <div className="mb-6 grid gap-3 sm:grid-cols-3">{visuals.map(([id, label]) => <button key={id} onClick={() => set("heroStyle", id)} className={`rounded-md border p-4 text-left text-sm font-medium ${value.heroStyle === id ? "border-foreground bg-muted" : "border-border bg-background"}`}><div className="relative mb-3 h-16 overflow-hidden rounded-sm bg-secondary">{id === "shader" && <span className="absolute -right-4 -top-6 h-20 w-28 rounded-full bg-accent/70 blur-2xl" />}{id === "split" && <span className="absolute inset-y-0 right-0 w-1/2 bg-muted" />}</div>{label}</button>)}</div>
    <div className="space-y-4"><div><Label htmlFor="landing-eyebrow">Signature</Label><Input id="landing-eyebrow" className="mt-2" value={value.eyebrow} onChange={e => set("eyebrow", e.target.value)} /></div><div><Label htmlFor="landing-title">Titre</Label><Input id="landing-title" className="mt-2" value={value.title} onChange={e => set("title", e.target.value)} /></div><div><Label htmlFor="landing-subtitle">Texte</Label><Textarea id="landing-subtitle" className="mt-2" rows={3} value={value.subtitle} onChange={e => set("subtitle", e.target.value)} /></div><div><Label htmlFor="landing-cta">Libellé du bouton</Label><Input id="landing-cta" className="mt-2" value={value.ctaLabel} onChange={e => set("ctaLabel", e.target.value)} /></div></div>
  </section>;
}