import { useState } from "react";
import { Plus } from "lucide-react";
import LandingSectionEditor from "./LandingSectionEditor";
import AddLandingSectionDialog from "./AddLandingSectionDialog";

export default function LandingSectionsEditor({ sections, onChange }) {
  const [adding, setAdding] = useState(false);
  const update = next => onChange(next.map((item, position) => ({ ...item, position })));
  return <section className="rounded-lg border border-border bg-card p-6 shadow-sm">
    <div className="mb-6 flex items-center justify-between"><div><span className="brand-badge">Structure</span><h2 className="mt-3 text-xl font-semibold">Sections de la landing</h2></div><button onClick={() => setAdding(true)} className="brand-outline-btn"><Plus className="h-4 w-4" />Ajouter</button></div>
    <div className="space-y-4">{sections.length ? sections.map((section, index) => <LandingSectionEditor key={section.id} section={section} onChange={next => update(sections.map((item, i) => i === index ? next : item))} onDelete={() => update(sections.filter((_, i) => i !== index))} />) : <p className="rounded-md border border-dashed border-border p-8 text-center text-sm text-muted-foreground">Aucune section personnalisée.</p>}</div>
    <AddLandingSectionDialog open={adding} onClose={() => setAdding(false)} onCreate={section => update([...sections, section])} />
  </section>;
}