import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Loader2, LayoutDashboard, Globe, FileText, Sparkles } from 'lucide-react';
import BrandMark from '@/components/BrandMark';

// Uniquement des destinations réellement routées — aucun lien mort.
const ADMIN_NAV = [
  { group: 'SITE', items: [
    { to: '/admin', label: 'Vue d\'ensemble', icon: LayoutDashboard, end: true },
    { to: '/admin/landing', label: 'Landing', icon: Globe },
    { to: '/studio/page', label: 'Pages publiques', icon: FileText },
  ]},
];

export default function AdminShell({ children }) {
  const [allowed, setAllowed] = useState(null);
  const location = useLocation();

  useEffect(() => {
    base44.auth.me().then((me) => setAllowed(me.role === 'admin')).catch(() => setAllowed(false));
  }, []);

  if (allowed === null) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!allowed) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <p className="text-sm font-medium mb-2">Accès administrateur requis</p>
          <Link to="/" className="brand-outline-btn text-xs">Retour à l'accueil</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex">
      <aside className="w-64 border-r border-border bg-card flex flex-col fixed inset-y-0 left-0 z-40">
        <div className="px-5 pt-5 pb-4 border-b border-border">
          <Link to="/admin"><BrandMark /></Link>
          <p className="text-[10px] uppercase tracking-wider text-muted-foreground mt-2">Studio éditorial</p>
        </div>
        <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-4">
          {ADMIN_NAV.map((group) => (
            <div key={group.group}>
              <p className="px-1.5 mb-1.5 text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">{group.group}</p>
              <div className="space-y-0.5">
                {group.items.map((item) => {
                  const Icon = item.icon;
                  const isActive = item.end ? location.pathname === item.to : location.pathname.startsWith(item.to);
                  return (
                    <Link
                      key={item.to}
                      to={item.to}
                      end={item.end}
                      className={`flex items-center gap-2.5 rounded-md px-2.5 py-2 text-[13px] transition ${
                        isActive ? 'bg-foreground text-background font-medium' : 'text-muted-foreground hover:text-foreground hover:bg-black/[0.03]'
                      }`}
                    >
                      <Icon className="w-4 h-4 shrink-0" strokeWidth={1.6} />
                      <span className="truncate">{item.label}</span>
                    </Link>
                  );
                })}
              </div>
            </div>
          ))}
        </nav>
        <div className="px-3 py-3 border-t border-border">
          <Link to="/" className="flex items-center gap-2 text-xs text-muted-foreground hover:text-foreground transition">
            <Sparkles className="w-3.5 h-3.5" /> Retour à l'app
          </Link>
        </div>
      </aside>

      <div className="flex-1 pl-64">
        <main className="min-h-screen p-8">{children}</main>
      </div>
    </div>
  );
}