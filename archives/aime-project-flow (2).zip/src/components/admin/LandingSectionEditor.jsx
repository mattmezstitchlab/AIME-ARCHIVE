import { Trash2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

export default function LandingSectionEditor({ section, onChange, onDelete }) {
  const set = (key, value) => onChange({ ...section, [key]: value });
  return <article className="rounded-lg border border-border bg-background p-5">
    <div className="mb-4 flex items-center justify-between"><span className="brand-badge">{section.layout}</span><button onClick={onDelete} className="brand-icon-btn" aria-label="Supprimer la section"><Trash2 className="h-4 w-4" /></button></div>
    <div className="grid gap-3 sm:grid-cols-2"><select value={section.type} onChange={e => set("type", e.target.value)} className="brand-select"><option value="content">Contenu</option><option value="features">Fonctionnalités</option><option value="statement">Déclaration</option></select><select value={section.layout} onChange={e => set("layout", e.target.value)} className="brand-select"><option value="editorial">Éditorial</option><option value="cards">Cartes</option><option value="split">Partagé</option></select></div>
    <Input className="mt-3" value={section.title} onChange={e => set("title", e.target.value)} placeholder="Titre" />
    <Textarea className="mt-3" rows={3} value={section.text} onChange={e => set("text", e.target.value)} placeholder="Texte" />
  </article>;
}