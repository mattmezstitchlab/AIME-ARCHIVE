import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { useMemo, useState } from "react";
import {
  Home, FolderKanban, ShieldCheck, Users, Handshake, Bot, CalendarDays, CalendarClock,
  ChevronDown, Search, MessageCircle, Globe, Settings, FileStack, Dna
} from "lucide-react";
import BrandMark from "./BrandMark";
import { useAssociation } from "@/components/AssociationProvider";
import { useAI } from "@/components/AIProvider";
import { useProjectNav, ProjectNavProvider } from "@/components/ProjectNavContext";
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";

const NAV = [
  { group: "Vue d'ensemble", items: [
    { to: "/", label: "Tableau de bord", icon: Home, end: true },
    { to: "/studio/page", label: "Ma Page AIME", icon: Globe },
    { to: "/admin/landing", label: "Landing", icon: Settings }
  ]},
  { group: "Projets & dossiers", items: [
    { to: "/projects", label: "Projets", icon: FolderKanban },
    { to: "/documents", label: "Documents", icon: FileStack },
    { to: "/evenements", label: "Événements", icon: CalendarClock },
    { to: "/reunions", label: "Réunions", icon: CalendarDays },
    { to: "/vigilance", label: "Vigilance", icon: ShieldCheck }
  ]},
  { group: "Organisation", items: [
    { to: "/membres", label: "Membres", icon: Users },
    { to: "/partenaires", label: "Partenaires", icon: Handshake },
    { to: "/association/parametres", label: "Paramètres", icon: Settings }
  ]},
  { group: "AIME CORE", items: [{ to: "/aime", label: "Memory Core", icon: Dna }] },
  { group: "Intelligence", items: [{ to: "/agent", label: "Agent AIME", icon: Bot }] }
];

// Entrées réservées au propriétaire/administrateur AIME
const ADMIN_ONLY = ["/admin/landing", "/studio/page"];
const isAdminOnly = (to) => ADMIN_ONLY.includes(to);

const accentStyle = { backgroundColor: "hsl(var(--success))" };

function NavItem({ item }) {
  const Icon = item.icon;
  return (
    <NavLink to={item.to} end={item.end}
      className={({ isActive }) =>
        "group relative flex items-center gap-2.5 rounded-md px-2.5 py-2 text-[13px] transition " +
        (isActive ? "bg-black/[0.04] text-foreground font-semibold" : "text-muted-foreground hover:text-foreground hover:bg-black/[0.03]")
      }>
      {({ isActive }) => (
        <>
          {isActive && <span className="absolute left-0 top-1.5 bottom-1.5 w-[3px] rounded-full" style={accentStyle} />}
          <Icon className="w-4 h-4 shrink-0" strokeWidth={1.6} />
          <span className="truncate">{item.label}</span>
        </>
      )}
    </NavLink>
  );
}

function LayoutInner() {
  const navigate = useNavigate();
  const { associations, activeAssociationId, switchAssociation, me } = useAssociation();
  const { aiEnabled, toggleAI } = useAI();
  const { nav, active, setActive } = useProjectNav();
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(() => Object.fromEntries(NAV.map((g, i) => [i, true])));

  const filtered = useMemo(() => {
    const t = q.trim().toLowerCase();
    return NAV.map((g, i) => ({
      ...g, _i: i,
      items: g.items.filter((it) => (!isAdminOnly(it.to) || me?.role === "admin") && (!t || it.label.toLowerCase().includes(t) || g.group.toLowerCase().includes(t)))
    })).filter((g) => g.items.length > 0);
  }, [q, me?.role]);
  const mobileItems = useMemo(() => NAV.flatMap((group) => group.items).filter((item) => !isAdminOnly(item.to) || me?.role === "admin"), [me?.role]);

  return (
    <div className="min-h-screen bg-background">
      <aside className="hidden lg:flex flex-col fixed inset-y-0 left-0 w-64 bg-sidebar text-sidebar-foreground border-r border-sidebar-border z-40">
        <div className="px-5 pt-5 pb-3">
          <button onClick={() => navigate("/")} className="text-left"><BrandMark onDark={false} /></button>
        </div>
        <div className="px-3 pb-2">
          <Select value={activeAssociationId || ""} onValueChange={switchAssociation}>
            <SelectTrigger className="h-9 text-[13px] font-medium"><SelectValue placeholder="Choisir une association" /></SelectTrigger>
            <SelectContent>
              {associations.map((a) => <SelectItem key={a.id} value={a.id}>{a.name}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div className="px-3 pb-3">
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Rechercher…"
              className="w-full h-9 pl-8 pr-12 rounded-md border border-border bg-background text-[13px] placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring" />
            <span className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[10px] text-muted-foreground border border-border rounded px-1.5 py-0.5 select-none">⌘1</span>
          </div>
        </div>
        <nav className="flex-1 overflow-y-auto px-3 pb-3 space-y-3">
          {filtered.map((g) => (
            <div key={g._i}>
              <button onClick={() => setOpen((o) => ({ ...o, [g._i]: !o[g._i] }))}
                className="w-full flex items-center justify-between px-1.5 py-1 text-[11px] uppercase tracking-wider text-muted-foreground hover:text-foreground transition">
                <span>{g.group}</span>
                <ChevronDown className={"w-3.5 h-3.5 transition " + (open[g._i] ? "" : "-rotate-90")} />
              </button>
              {open[g._i] && (
                <div className="mt-1 space-y-0.5">
                  {g.items.map((it) => (
                    <div key={it.to}>
                      <NavItem item={it} />
                      {it.to === "/projects" && nav && (
                        <div className="ml-4 mt-1 space-y-0.5 border-l border-border pl-2">
                          {nav.sections.map((s) => {
                            const SIcon = s.icon;
                            return (
                              <button key={s.id} onClick={() => setActive(s.id)}
                                className={"w-full flex items-center gap-2 rounded-md px-2 py-1.5 text-[12px] transition " +
                                  (active === s.id ? "bg-black/[0.04] text-foreground font-medium" : "text-muted-foreground hover:text-foreground hover:bg-black/[0.03]")}>
                                <SIcon className="w-3.5 h-3.5 shrink-0" strokeWidth={1.6} />
                                <span className="truncate">{s.label}</span>
                              </button>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </nav>
        <div className="px-3 pt-3 pb-4 border-t border-sidebar-border space-y-3">
          <div className="flex items-center justify-between px-1.5">
            <span className="text-[11px] uppercase tracking-wider text-muted-foreground">Agent IA</span>
            <Switch checked={aiEnabled} onCheckedChange={toggleAI} />
          </div>
          {aiEnabled && (
            <button onClick={() => navigate("/agent")}
              className="w-full flex items-center justify-center gap-2 px-3 py-2.5 rounded-md bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition">
              <MessageCircle className="w-4 h-4" /> Parler à AIME
            </button>
          )}
          <p className="text-[10px] text-muted-foreground px-1 leading-relaxed">
            L'intelligence qui transforme une intention en projet, un projet en action, une action en mémoire.
          </p>
        </div>
      </aside>

      <div className="lg:pl-64">
        <main className="min-h-screen pb-24 lg:pb-10">
          <Outlet />
        </main>
      </div>

      <nav className="lg:hidden fixed bottom-0 inset-x-0 bg-card border-t border-border flex justify-around px-1 py-1.5 z-50">
        {mobileItems.slice(0, 6).map((item) => {
          const Icon = item.icon;
          return (
            <NavLink key={item.to} to={item.to} end={item.end}
              className={({ isActive }) =>
                "flex flex-col items-center gap-0.5 px-2 py-1 text-[10px] transition " +
                (isActive ? "text-success font-medium" : "text-muted-foreground")
              }>
              <Icon className="w-5 h-5" strokeWidth={1.6} />
              {item.label}
            </NavLink>
          );
        })}
      </nav>

      {aiEnabled && (
        <button onClick={() => navigate("/agent")} aria-label="Parler à AIME"
          className="lg:hidden fixed bottom-20 right-4 z-50 w-14 h-14 rounded-full shadow-lg flex items-center justify-center active:scale-95 transition"
          style={{ backgroundColor: "hsl(var(--success))", color: "hsl(var(--success-foreground))" }}>
          <MessageCircle className="w-6 h-6" />
        </button>
      )}
    </div>
  );
}

export default function Layout() {
  return (
    <ProjectNavProvider>
      <LayoutInner />
    </ProjectNavProvider>
  );
}