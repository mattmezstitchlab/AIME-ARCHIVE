import React, { useState, useEffect } from "react";
import { Plus, Trash2, ArrowUp, ArrowDown, X, Eye } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import WeddingBlockRenderer from "./WeddingBlockRenderer";
import { getContext, getDefaultBlocks } from "@/lib/projectContexts";

const WEDDING_BLOCK_TYPES = [
  { type: "hero_wedding", label: "Hero mariage" },
  { type: "our_story", label: "Notre histoire" },
  { type: "practical_info", label: "Informations pratiques" },
  { type: "program", label: "Programme" },
  { type: "gallery", label: "Galerie" },
  { type: "rsvp", label: "RSVP" },
  { type: "guestbook", label: "Livre d'or" },
  { type: "contribution", label: "Contribution" },
];

export default function PublicCanvas({ page, isEditing, onToggleEdit }) {
  const { toast } = useToast();
  const [sections, setSections] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState(null);
  const [showAddBlock, setShowAddBlock] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const data = await base44.entities.PublicPageSection.filter({ pageId: page.id });
        data.sort((a, b) => (a.position || 0) - (b.position || 0));
        setSections(data);
        // If no sections, create default blocks from context
        if (data.length === 0 && page.projectType) {
          const defaults = getDefaultBlocks(page.projectType);
          for (const block of defaults) {
            const created = await base44.entities.PublicPageSection.create({
              ...block,
              pageId: page.id,
              userId: page.userId,
            });
            setSections((prev) => [...prev, created]);
          }
        }
      } catch (e) {
        // ignore
      }
      setLoading(false);
    })();
  }, [page.id]);

  async function updateSection(id, data) {
    try {
      await base44.entities.PublicPageSection.update(id, data);
      setSections(sections.map((s) => (s.id === id ? { ...s, ...data } : s)));
    } catch (e) {
      toast({ title: "Erreur", description: e.message, variant: "destructive" });
    }
  }

  async function deleteSection(id) {
    try {
      await base44.entities.PublicPageSection.delete(id);
      setSections(sections.filter((s) => s.id !== id));
      setSelected(null);
      toast({ title: "Bloc supprimé" });
    } catch (e) {
      toast({ title: "Erreur", description: e.message, variant: "destructive" });
    }
  }

  async function moveSection(id, direction) {
    const index = sections.findIndex((s) => s.id === id);
    if (index === -1) return;
    const targetIndex = direction === "up" ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= sections.length) return;
    const newSections = [...sections];
    [newSections[index], newSections[targetIndex]] = [newSections[targetIndex], newSections[index]];
    // Update positions
    for (let i = 0; i < newSections.length; i++) {
      newSections[i] = { ...newSections[i], position: i };
    }
    setSections(newSections);
    // Persist positions
    for (const s of newSections) {
      await base44.entities.PublicPageSection.update(s.id, { position: s.position });
    }
  }

  async function addBlock(type) {
    const blockDef = WEDDING_BLOCK_TYPES.find((b) => b.type === type);
    const newSection = {
      type,
      content: {},
      style: { background: "none", padding: "normal", align: "center", width: "normal" },
      position: sections.length,
      visibility: "public",
      hidden: false,
      pageId: page.id,
      userId: page.userId,
    };
    try {
      const created = await base44.entities.PublicPageSection.create(newSection);
      setSections([...sections, created]);
      setShowAddBlock(false);
      setSelected(created.id);
      toast({ title: "Bloc ajouté" });
    } catch (e) {
      toast({ title: "Erreur", description: e.message, variant: "destructive" });
    }
  }

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="w-6 h-6 border-2 border-border border-t-foreground rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto bg-background">
      {/* Edit toolbar */}
      {isEditing && (
        <div className="sticky top-0 z-30 bg-card/80 backdrop-blur-md border-b border-border/60 px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <span className="w-2 h-2 rounded-full bg-amber-400" />
            Mode édition — cliquez sur un bloc pour le modifier
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowAddBlock(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-foreground text-background text-xs font-medium hover:opacity-90"
            >
              <Plus className="w-3.5 h-3.5" /> Ajouter un bloc
            </button>
            <button
              onClick={onToggleEdit}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-border text-xs font-medium hover:bg-accent"
            >
              <Eye className="w-3.5 h-3.5" /> Aperçu
            </button>
          </div>
        </div>
      )}

      {/* Canvas */}
      <div className="min-h-full">
        {sections.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-32 gap-4">
            <p className="text-sm text-muted-foreground">Aucun bloc sur cette page</p>
            {isEditing && (
              <button
                onClick={() => setShowAddBlock(true)}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full bg-foreground text-background text-sm font-medium"
              >
                <Plus className="w-4 h-4" /> Ajouter le premier bloc
              </button>
            )}
          </div>
        ) : (
          sections.map((section) => (
            <div key={section.id} className="relative group">
              <WeddingBlockRenderer
                section={section}
                isEditing={isEditing}
                onUpdate={(data) => updateSection(section.id, data)}
                selected={selected === section.id}
                onSelect={() => setSelected(section.id)}
              />
              {isEditing && selected === section.id && (
                <div className="absolute top-2 right-2 z-20 flex items-center gap-1 bg-card border border-border rounded-lg shadow-lg p-1">
                  <button onClick={() => moveSection(section.id, "up")} disabled={sections.findIndex(s => s.id === section.id) === 0} className="p-1.5 rounded hover:bg-accent disabled:opacity-30"><ArrowUp className="w-3.5 h-3.5" /></button>
                  <button onClick={() => moveSection(section.id, "down")} disabled={sections.findIndex(s => s.id === section.id) === sections.length - 1} className="p-1.5 rounded hover:bg-accent disabled:opacity-30"><ArrowDown className="w-3.5 h-3.5" /></button>
                  <button onClick={() => deleteSection(section.id)} className="p-1.5 rounded hover:bg-red-50 text-red-500"><Trash2 className="w-3.5 h-3.5" /></button>
                </div>
              )}
            </div>
          ))
        )}
      </div>

      {/* Add block dialog */}
      {showAddBlock && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40" onClick={() => setShowAddBlock(false)}>
          <div className="w-full max-w-md bg-card rounded-2xl border border-border p-6 m-4" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display font-semibold text-lg">Ajouter un bloc</h3>
              <button onClick={() => setShowAddBlock(false)} className="p-1.5 rounded-lg hover:bg-accent"><X className="w-4 h-4" /></button>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {WEDDING_BLOCK_TYPES.map((b) => (
                <button
                  key={b.type}
                  onClick={() => addBlock(b.type)}
                  className="p-3 rounded-xl border border-border/60 hover:border-foreground/30 hover:bg-accent text-left text-sm transition-colors"
                >
                  {b.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}