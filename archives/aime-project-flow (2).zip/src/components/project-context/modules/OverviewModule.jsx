import React from "react";
import { Users, Briefcase, Wallet, CheckSquare, MessageCircle, Calendar, TrendingUp, Clock } from "lucide-react";

export default function OverviewModule({ page, guests, vendors, budgetItems, messages, tasks }) {
  const config = page?.projectConfig || {};
  const confirmed = guests.filter((g) => g.status === "confirme").length;
  const pending = guests.filter((g) => g.status === "invite" || g.status === "en_attente").length;
  const declined = guests.filter((g) => g.status === "decline").length;
  const totalGuests = guests.length;
  const budgetEstimated = budgetItems.reduce((s, b) => s + (b.amount_estimated || 0), 0);
  const budgetActual = budgetItems.reduce((s, b) => s + (b.amount_actual || 0), 0);
  const vendorsReserved = vendors.filter((v) => v.status === "reserve" || v.status === "paye").length;
  const daysLeft = config.date ? Math.max(0, Math.ceil((new Date(config.date) - new Date()) / (1000 * 60 * 60 * 24))) : null;

  const stats = [
    { label: "Invités confirmés", value: confirmed, total: totalGuests, icon: Users, color: "text-emerald-600" },
    { label: "En attente", value: pending, total: totalGuests, icon: Clock, color: "text-amber-600" },
    { label: "Prestataires réservés", value: vendorsReserved, total: vendors.length, icon: Briefcase, color: "text-blue-600" },
    { label: "Messages reçus", value: messages.length, icon: MessageCircle, color: "text-purple-600" },
  ];

  return (
    <div className="max-w-4xl mx-auto px-8 py-10">
      <div className="mb-8">
        <h1 className="text-3xl font-display font-bold mb-1">Vue générale</h1>
        <p className="text-sm text-muted-foreground">Synthèse de votre projet</p>
      </div>

      {/* Countdown */}
      {daysLeft !== null && (
        <div className="mb-8 p-6 rounded-2xl bg-foreground text-background">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs uppercase tracking-widest opacity-60 mb-1">Compte à rebours</p>
              <p className="text-4xl font-display font-bold">{daysLeft} jours</p>
              <p className="text-sm opacity-70 mt-1">avant le mariage</p>
            </div>
            <Calendar className="w-12 h-12 opacity-30" />
          </div>
        </div>
      )}

      {/* Stats grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {stats.map((stat, i) => {
          const Icon = stat.icon;
          return (
            <div key={i} className="p-5 rounded-xl border border-border/60 bg-card">
              <Icon className={`w-5 h-5 mb-3 ${stat.color}`} />
              <p className="text-2xl font-display font-bold">
                {stat.value}{stat.total !== undefined && <span className="text-base text-muted-foreground">/{stat.total}</span>}
              </p>
              <p className="text-xs text-muted-foreground mt-0.5">{stat.label}</p>
            </div>
          );
        })}
      </div>

      {/* Budget summary */}
      <div className="p-6 rounded-xl border border-border/60 bg-card mb-6">
        <div className="flex items-center gap-2 mb-4">
          <Wallet className="w-5 h-5" />
          <h3 className="font-display font-semibold">Budget</h3>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Estimé</p>
            <p className="text-2xl font-display font-bold">{budgetEstimated.toLocaleString("fr-FR")} €</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Dépensé</p>
            <p className="text-2xl font-display font-bold">{budgetActual.toLocaleString("fr-FR")} €</p>
          </div>
        </div>
        <div className="mt-4">
          <div className="h-2 rounded-full bg-muted overflow-hidden">
            <div
              className="h-full bg-foreground rounded-full transition-all"
              style={{ width: `${budgetEstimated > 0 ? Math.min(100, (budgetActual / budgetEstimated) * 100) : 0}%` }}
            />
          </div>
        </div>
      </div>

      {/* Quick info */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="p-5 rounded-xl border border-border/60 bg-card">
          <div className="flex items-center gap-2 mb-3">
            <Users className="w-4 h-4" />
            <h4 className="font-medium text-sm">Réponses RSVP</h4>
          </div>
          <div className="flex flex-col gap-2 text-sm">
            <div className="flex justify-between"><span className="text-muted-foreground">Confirmés</span><span className="font-medium text-emerald-600">{confirmed}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">En attente</span><span className="font-medium text-amber-600">{pending}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Déclinés</span><span className="font-medium text-red-500">{declined}</span></div>
          </div>
        </div>
        <div className="p-5 rounded-xl border border-border/60 bg-card">
          <div className="flex items-center gap-2 mb-3">
            <Briefcase className="w-4 h-4" />
            <h4 className="font-medium text-sm">Prestataires</h4>
          </div>
          <div className="flex flex-col gap-2 text-sm">
            <div className="flex justify-between"><span className="text-muted-foreground">Total</span><span className="font-medium">{vendors.length}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Réservés</span><span className="font-medium text-emerald-600">{vendorsReserved}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">À trouver</span><span className="font-medium text-amber-600">{vendors.length - vendorsReserved}</span></div>
          </div>
        </div>
      </div>
    </div>
  );
}