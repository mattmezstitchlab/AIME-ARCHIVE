import React, { useState } from "react";
import { Users, Plus, Search, Mail, Phone, MoreVertical, Trash2, X } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";

const STATUS_LABELS = {
  invite: "Invité",
  confirme: "Confirmé",
  decline: "Décliné",
  en_attente: "En attente",
};
const STATUS_COLORS = {
  invite: "bg-muted text-muted-foreground",
  confirme: "bg-emerald-100 text-emerald-700",
  decline: "bg-red-100 text-red-700",
  en_attente: "bg-amber-100 text-amber-700",
};

export default function GuestsModule({ page, guests, setGuests }) {
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ name: "", email: "", phone: "", category: "amis", status: "invite", plus_one: false, plus_one_name: "", dietary: "", notes: "" });

  const filtered = guests.filter((g) => g.name?.toLowerCase().includes(search.toLowerCase()));

  async function handleSave() {
    if (!form.name.trim()) return;
    try {
      if (editing) {
        await base44.entities.ProjectGuest.update(editing.id, form);
        setGuests(guests.map((g) => (g.id === editing.id ? { ...editing, ...form } : g)));
        toast({ title: "Invité mis à jour" });
      } else {
        const created = await base44.entities.ProjectGuest.create({ ...form, pageId: page.id, userId: page.userId });
        setGuests([...guests, created]);
        toast({ title: "Invité ajouté" });
      }
      setShowForm(false);
      setEditing(null);
      setForm({ name: "", email: "", phone: "", category: "amis", status: "invite", plus_one: false, plus_one_name: "", dietary: "", notes: "" });
    } catch (e) {
      toast({ title: "Erreur", description: e.message, variant: "destructive" });
    }
  }

  async function handleDelete(guest) {
    try {
      await base44.entities.ProjectGuest.delete(guest.id);
      setGuests(guests.filter((g) => g.id !== guest.id));
      toast({ title: "Invité supprimé" });
    } catch (e) {
      toast({ title: "Erreur", description: e.message, variant: "destructive" });
    }
  }

  function openEdit(guest) {
    setEditing(guest);
    setForm({ name: guest.name, email: guest.email || "", phone: guest.phone || "", category: guest.category || "amis", status: guest.status || "invite", plus_one: guest.plus_one || false, plus_one_name: guest.plus_one_name || "", dietary: guest.dietary || "", notes: guest.notes || "" });
    setShowForm(true);
  }

  return (
    <div className="max-w-4xl mx-auto px-8 py-10">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-display font-bold mb-1">Invités</h1>
          <p className="text-sm text-muted-foreground">{guests.length} invité{guests.length > 1 ? "s" : ""}</p>
        </div>
        <button
          onClick={() => { setEditing(null); setForm({ name: "", email: "", phone: "", category: "amis", status: "invite", plus_one: false, plus_one_name: "", dietary: "", notes: "" }); setShowForm(true); }}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full bg-foreground text-background text-sm font-medium hover:opacity-90 transition-opacity"
        >
          <Plus className="w-4 h-4" /> Ajouter
        </button>
      </div>

      <div className="relative mb-6">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <input
          type="text"
          placeholder="Rechercher un invité..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full pl-10 pr-4 py-2.5 rounded-lg border border-border bg-card text-sm"
        />
      </div>

      {filtered.length === 0 ? (
        <div className="text-center py-16">
          <Users className="w-10 h-10 mx-auto text-muted-foreground/40 mb-3" />
          <p className="text-sm text-muted-foreground">Aucun invité pour le moment</p>
        </div>
      ) : (
        <div className="flex flex-col gap-2">
          {filtered.map((guest) => (
            <div key={guest.id} className="flex items-center gap-4 p-4 rounded-xl border border-border/60 bg-card hover:border-border transition-colors group">
              <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center text-sm font-medium shrink-0">
                {guest.name?.charAt(0)?.toUpperCase()}
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium truncate">{guest.name}</p>
                <div className="flex items-center gap-3 text-xs text-muted-foreground">
                  {guest.email && <span className="flex items-center gap-1"><Mail className="w-3 h-3" />{guest.email}</span>}
                  {guest.phone && <span className="flex items-center gap-1"><Phone className="w-3 h-3" />{guest.phone}</span>}
                  {guest.plus_one && <span>+1 {guest.plus_one_name}</span>}
                </div>
              </div>
              <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${STATUS_COLORS[guest.status] || STATUS_COLORS.invite}`}>
                {STATUS_LABELS[guest.status] || guest.status}
              </span>
              <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <button onClick={() => openEdit(guest)} className="p-2 rounded-lg hover:bg-accent text-muted-foreground hover:text-foreground transition-colors">
                  <MoreVertical className="w-4 h-4" />
                </button>
                <button onClick={() => handleDelete(guest)} className="p-2 rounded-lg hover:bg-red-50 text-muted-foreground hover:text-red-500 transition-colors">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Form dialog */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40" onClick={() => setShowForm(false)}>
          <div className="w-full max-w-lg bg-card rounded-2xl border border-border p-6 m-4" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display font-semibold text-lg">{editing ? "Modifier l'invité" : "Nouvel invité"}</h3>
              <button onClick={() => setShowForm(false)} className="p-1.5 rounded-lg hover:bg-accent"><X className="w-4 h-4" /></button>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2">
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Nom complet *</label>
                <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-border text-sm" placeholder="Jean Dupont" />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Email</label>
                <input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-border text-sm" placeholder="jean@email.com" />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Téléphone</label>
                <input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-border text-sm" placeholder="06 12 34 56 78" />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Catégorie</label>
                <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-border text-sm">
                  <option value="famille">Famille</option>
                  <option value="amis">Amis</option>
                  <option value="collegues">Collègues</option>
                  <option value="autre">Autre</option>
                </select>
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Statut</label>
                <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-border text-sm">
                  <option value="invite">Invité</option>
                  <option value="confirme">Confirmé</option>
                  <option value="decline">Décliné</option>
                  <option value="en_attente">En attente</option>
                </select>
              </div>
              <div className="col-span-2 flex items-center gap-2">
                <input type="checkbox" id="plus_one" checked={form.plus_one} onChange={(e) => setForm({ ...form, plus_one: e.target.checked })} className="rounded" />
                <label htmlFor="plus_one" className="text-sm">Accompagnant (+1)</label>
                {form.plus_one && <input value={form.plus_one_name} onChange={(e) => setForm({ ...form, plus_one_name: e.target.value })} className="flex-1 px-3 py-2 rounded-lg border border-border text-sm" placeholder="Nom de l'accompagnant" />}
              </div>
              <div className="col-span-2">
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Restrictions alimentaires</label>
                <input value={form.dietary} onChange={(e) => setForm({ ...form, dietary: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-border text-sm" placeholder="Végétarien, allergies..." />
              </div>
            </div>
            <div className="flex justify-end gap-2 mt-5">
              <button onClick={() => setShowForm(false)} className="px-4 py-2 rounded-lg text-sm hover:bg-accent transition-colors">Annuler</button>
              <button onClick={handleSave} className="px-4 py-2 rounded-lg bg-foreground text-background text-sm font-medium hover:opacity-90 transition-opacity">{editing ? "Mettre à jour" : "Ajouter"}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}