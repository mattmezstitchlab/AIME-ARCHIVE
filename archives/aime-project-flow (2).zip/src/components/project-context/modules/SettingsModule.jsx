import React, { useState } from "react";
import { Settings, Heart, Eye, Globe, X } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { getContext } from "@/lib/projectContexts";

export default function SettingsModule({ page, setPage, sections }) {
  const { toast } = useToast();
  const ctx = getContext(page?.projectType) || {};
  const [config, setConfig] = useState(page?.projectConfig || {});
  const [saving, setSaving] = useState(false);

  async function handleSave() {
    setSaving(true);
    try {
      const updated = await base44.entities.PersonalPublicPage.update(page.id, { projectConfig: config });
      setPage({ ...page, projectConfig: config });
      toast({ title: "Paramètres enregistrés" });
    } catch (e) {
      toast({ title: "Erreur", description: e.message, variant: "destructive" });
    }
    setSaving(false);
  }

  async function togglePublish() {
    try {
      const newStatus = page.status === "publie" ? "brouillon" : "publie";
      await base44.entities.PersonalPublicPage.update(page.id, { status: newStatus, publishedAt: newStatus === "publie" ? new Date().toISOString() : null });
      setPage({ ...page, status: newStatus });
      toast({ title: newStatus === "publie" ? "Page publiée" : "Page dépubliée" });
    } catch (e) {
      toast({ title: "Erreur", description: e.message, variant: "destructive" });
    }
  }

  const identityFields = ctx.identity?.fields || [];

  return (
    <div className="max-w-2xl mx-auto px-8 py-10">
      <div className="mb-6">
        <h1 className="text-3xl font-display font-bold mb-1">Paramètres</h1>
        <p className="text-sm text-muted-foreground">Configuration de votre page</p>
      </div>

      {/* Publication */}
      <div className="p-5 rounded-xl border border-border/60 bg-card mb-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Globe className="w-5 h-5" />
            <div>
              <p className="font-medium text-sm">Page publique</p>
              <p className="text-xs text-muted-foreground">{page.status === "publie" ? "Visible par tous" : "Brouillon — non visible"}</p>
            </div>
          </div>
          <button
            onClick={togglePublish}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
              page.status === "publie" ? "bg-foreground text-background" : "border border-border hover:bg-accent"
            }`}
          >
            {page.status === "publie" ? "Dépublier" : "Publier"}
          </button>
        </div>
        {page.status === "publie" && page.username && (
          <div className="mt-3 pt-3 border-t border-border/40">
            <p className="text-xs text-muted-foreground mb-1">Lien public</p>
            <a href={`/@${page.username}`} target="_blank" rel="noopener noreferrer" className="text-sm text-primary underline flex items-center gap-1">
              <Eye className="w-3.5 h-3.5" /> le-monde-aime.app/@{page.username}
            </a>
          </div>
        )}
      </div>

      {/* Identity fields */}
      <div className="p-5 rounded-xl border border-border/60 bg-card mb-6">
        <h3 className="font-medium text-sm mb-4 flex items-center gap-2">
          <Heart className="w-4 h-4" /> Informations du projet
        </h3>
        <div className="grid grid-cols-2 gap-3">
          {identityFields.map((field) => (
            <div key={field.key} className={field.type === "date" ? "col-span-2" : "col-span-1"}>
              <label className="text-xs font-medium text-muted-foreground mb-1 block">{field.label}</label>
              <input
                type={field.type || "text"}
                value={config[field.key] || ""}
                onChange={(e) => setConfig({ ...config, [field.key]: e.target.value })}
                placeholder={field.placeholder}
                className="w-full px-3 py-2 rounded-lg border border-border text-sm"
              />
            </div>
          ))}
        </div>
      </div>

      {/* Page info */}
      <div className="p-5 rounded-xl border border-border/60 bg-card mb-6">
        <h3 className="font-medium text-sm mb-4">Informations générales</h3>
        <div className="flex flex-col gap-3">
          <div>
            <label className="text-xs font-medium text-muted-foreground mb-1 block">Titre de la page</label>
            <input value={page.title || ""} onChange={(e) => setPage({ ...page, title: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-border text-sm" />
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground mb-1 block">Description</label>
            <textarea value={page.description || ""} onChange={(e) => setPage({ ...page, description: e.target.value })} rows={2} className="w-full px-3 py-2 rounded-lg border border-border text-sm" />
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground mb-1 block">Nom d'utilisateur (URL)</label>
            <input value={page.username || ""} disabled className="w-full px-3 py-2 rounded-lg border border-border text-sm bg-muted/50" />
          </div>
        </div>
      </div>

      <div className="flex justify-end">
        <button
          onClick={handleSave}
          disabled={saving}
          className="px-6 py-2.5 rounded-full bg-foreground text-background text-sm font-medium hover:opacity-90 transition-opacity disabled:opacity-50"
        >
          {saving ? "Enregistrement..." : "Enregistrer"}
        </button>
      </div>
    </div>
  );
}