import React, { useState } from "react";
import { Grid3x3, Plus, Trash2, X, Users } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";

export default function SeatingModule({ page, tables, setTables, guests, setGuests }) {
  const { toast } = useToast();
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: "", capacity: 8 });
  const [draggedGuest, setDraggedGuest] = useState(null);

  const unseated = guests.filter((g) => !tables.some((t) => (t.guest_ids || []).includes(g.id)) && g.status !== "decline");

  async function addTable() {
    if (!form.name.trim()) return;
    try {
      const created = await base44.entities.ProjectSeatingTable.create({ ...form, pageId: page.id, userId: page.userId, guest_ids: [], position: tables.length });
      setTables([...tables, created]);
      setShowForm(false);
      setForm({ name: "", capacity: 8 });
      toast({ title: "Table créée" });
    } catch (e) {
      toast({ title: "Erreur", description: e.message, variant: "destructive" });
    }
  }

  async function deleteTable(table) {
    try {
      await base44.entities.ProjectSeatingTable.delete(table.id);
      setTables(tables.filter((t) => t.id !== table.id));
      toast({ title: "Table supprimée" });
    } catch (e) {
      toast({ title: "Erreur", description: e.message, variant: "destructive" });
    }
  }

  async function assignGuest(tableId, guestId) {
    const table = tables.find((t) => t.id === tableId);
    if (!table) return;
    const newGuestIds = [...(table.guest_ids || []), guestId];
    await base44.entities.ProjectSeatingTable.update(tableId, { guest_ids: newGuestIds });
    setTables(tables.map((t) => (t.id === tableId ? { ...t, guest_ids: newGuestIds } : t)));
  }

  async function removeGuest(tableId, guestId) {
    const table = tables.find((t) => t.id === tableId);
    if (!table) return;
    const newGuestIds = (table.guest_ids || []).filter((id) => id !== guestId);
    await base44.entities.ProjectSeatingTable.update(tableId, { guest_ids: newGuestIds });
    setTables(tables.map((t) => (t.id === tableId ? { ...t, guest_ids: newGuestIds } : t)));
  }

  function onDrop(e, tableId) {
    e.preventDefault();
    if (draggedGuest) {
      assignGuest(tableId, draggedGuest);
      setDraggedGuest(null);
    }
  }

  return (
    <div className="max-w-5xl mx-auto px-8 py-10">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-display font-bold mb-1">Plan de table</h1>
          <p className="text-sm text-muted-foreground">{tables.length} table{tables.length > 1 ? "s" : ""} · {guests.filter(g => g.status !== "decline").length - unseated.length} invité{guests.length > 1 ? "s" : ""} placé{guests.length > 1 ? "s" : ""}</p>
        </div>
        <button
          onClick={() => setShowForm(true)}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full bg-foreground text-background text-sm font-medium hover:opacity-90 transition-opacity"
        >
          <Plus className="w-4 h-4" /> Ajouter une table
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Unseated guests */}
        <div className="lg:col-span-1">
          <h3 className="text-sm font-medium mb-3 flex items-center gap-2">
            <Users className="w-4 h-4" /> À placer ({unseated.length})
          </h3>
          <div className="flex flex-col gap-1.5 max-h-[60vh] overflow-y-auto">
            {unseated.length === 0 ? (
              <p className="text-xs text-muted-foreground py-4 text-center">Tous les invités sont placés</p>
            ) : (
              unseated.map((guest) => (
                <div
                  key={guest.id}
                  draggable
                  onDragStart={() => setDraggedGuest(guest.id)}
                  onDragEnd={() => setDraggedGuest(null)}
                  className="p-2.5 rounded-lg border border-border/60 bg-card text-sm cursor-move hover:border-foreground/30 transition-colors"
                >
                  {guest.name}
                  {guest.plus_one && <span className="text-xs text-muted-foreground ml-1">+1</span>}
                </div>
              ))
            )}
          </div>
        </div>

        {/* Tables */}
        <div className="lg:col-span-2">
          {tables.length === 0 ? (
            <div className="text-center py-16">
              <Grid3x3 className="w-10 h-10 mx-auto text-muted-foreground/40 mb-3" />
              <p className="text-sm text-muted-foreground">Aucune table pour le moment</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {tables.map((table) => {
                const seated = (table.guest_ids || []).map((id) => guests.find((g) => g.id === id)).filter(Boolean);
                return (
                  <div
                    key={table.id}
                    onDragOver={(e) => e.preventDefault()}
                    onDrop={(e) => onDrop(e, table.id)}
                    className="p-4 rounded-xl border border-border/60 bg-card min-h-[160px]"
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <p className="font-medium">{table.name}</p>
                        <p className="text-xs text-muted-foreground">{seated.length}/{table.capacity} places</p>
                      </div>
                      <button onClick={() => deleteTable(table)} className="p-1.5 rounded-lg hover:bg-red-50 text-muted-foreground hover:text-red-500"><Trash2 className="w-3.5 h-3.5" /></button>
                    </div>
                    <div className="flex flex-col gap-1">
                      {seated.map((guest) => (
                        <div key={guest.id} className="flex items-center justify-between px-2.5 py-1.5 rounded-lg bg-muted/50 text-sm group">
                          <span>{guest.name}{guest.plus_one && <span className="text-xs text-muted-foreground ml-1">+1</span>}</span>
                          <button onClick={() => removeGuest(table.id, guest.id)} className="opacity-0 group-hover:opacity-100 text-xs text-muted-foreground hover:text-red-500 transition-all">Retirer</button>
                        </div>
                      ))}
                      {seated.length === 0 && <p className="text-xs text-muted-foreground text-center py-4">Glissez des invités ici</p>}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40" onClick={() => setShowForm(false)}>
          <div className="w-full max-w-sm bg-card rounded-2xl border border-border p-6 m-4" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display font-semibold text-lg">Nouvelle table</h3>
              <button onClick={() => setShowForm(false)} className="p-1.5 rounded-lg hover:bg-accent"><X className="w-4 h-4" /></button>
            </div>
            <div className="flex flex-col gap-3">
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Nom de la table *</label>
                <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-border text-sm" placeholder="Ex. Table 1" />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Capacité</label>
                <input type="number" value={form.capacity} onChange={(e) => setForm({ ...form, capacity: Number(e.target.value) })} className="w-full px-3 py-2 rounded-lg border border-border text-sm" min={1} max={20} />
              </div>
            </div>
            <div className="flex justify-end gap-2 mt-5">
              <button onClick={() => setShowForm(false)} className="px-4 py-2 rounded-lg text-sm hover:bg-accent transition-colors">Annuler</button>
              <button onClick={addTable} className="px-4 py-2 rounded-lg bg-foreground text-background text-sm font-medium hover:opacity-90 transition-opacity">Créer</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}