import React, { useState, useEffect } from "react";
import { MessageCircle, Trash2, Heart } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";

export default function MessagesModule({ page }) {
  const { toast } = useToast();
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const data = await base44.entities.ProjectMessage.filter({ pageId: page.id });
        setMessages(data.sort((a, b) => new Date(b.created_date) - new Date(a.created_date)));
      } catch (e) {
        // ignore
      }
      setLoading(false);
    })();
  }, [page.id]);

  async function handleDelete(msg) {
    try {
      await base44.entities.ProjectMessage.delete(msg.id);
      setMessages(messages.filter((m) => m.id !== msg.id));
      toast({ title: "Message supprimé" });
    } catch (e) {
      toast({ title: "Erreur", description: e.message, variant: "destructive" });
    }
  }

  async function toggleApprove(msg) {
    try {
      await base44.entities.ProjectMessage.update(msg.id, { approved: !msg.approved });
      setMessages(messages.map((m) => (m.id === msg.id ? { ...m, approved: !m.approved } : m)));
    } catch (e) {
      toast({ title: "Erreur", description: e.message, variant: "destructive" });
    }
  }

  return (
    <div className="max-w-3xl mx-auto px-8 py-10">
      <div className="mb-6">
        <h1 className="text-3xl font-display font-bold mb-1">Messages</h1>
        <p className="text-sm text-muted-foreground">Livre d'or — {messages.length} message{messages.length > 1 ? "s" : ""}</p>
      </div>

      {loading ? (
        <div className="text-center py-16"><div className="w-6 h-6 border-2 border-border border-t-foreground rounded-full animate-spin mx-auto" /></div>
      ) : messages.length === 0 ? (
        <div className="text-center py-16">
          <MessageCircle className="w-10 h-10 mx-auto text-muted-foreground/40 mb-3" />
          <p className="text-sm text-muted-foreground">Aucun message pour le moment</p>
          <p className="text-xs text-muted-foreground mt-1">Les messages apparaîtront quand vos invités écriront sur votre page publique</p>
        </div>
      ) : (
        <div className="flex flex-col gap-3">
          {messages.map((msg) => (
            <div key={msg.id} className={`p-5 rounded-xl border bg-card ${msg.approved ? "border-border/60" : "border-amber-300/60 bg-amber-50/30"}`}>
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center text-sm font-medium">
                    {msg.author?.charAt(0)?.toUpperCase()}
                  </div>
                  <div>
                    <p className="font-medium text-sm">{msg.author}</p>
                    <p className="text-xs text-muted-foreground">{new Date(msg.created_date).toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" })}</p>
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  {!msg.approved && (
                    <button onClick={() => toggleApprove(msg)} className="px-2.5 py-1 rounded-lg text-xs bg-foreground text-background font-medium hover:opacity-90">Approuver</button>
                  )}
                  <button onClick={() => handleDelete(msg)} className="p-1.5 rounded-lg hover:bg-red-50 text-muted-foreground hover:text-red-500"><Trash2 className="w-3.5 h-3.5" /></button>
                </div>
              </div>
              <p className="text-sm text-muted-foreground leading-relaxed">{msg.message}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}