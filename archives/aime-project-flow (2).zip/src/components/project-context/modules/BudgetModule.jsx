import React, { useState } from "react";
import { Wallet, Plus, Trash2, X, TrendingUp } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";

const CATEGORY_LABELS = {
  lieu: "Lieu", traiteur: "Traiteur", decoration: "Décoration", photo_video: "Photo / Vidéo",
  musique: "Musique", fleurs: "Fleurs", tenues: "Tenues", papeterie: "Papeterie",
  animation: "Animation", transport: "Transport", logement: "Logement", autres: "Autres",
};

export default function BudgetModule({ page, budgetItems, setBudgetItems }) {
  const { toast } = useToast();
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ category: "autres", label: "", amount_estimated: 0, amount_actual: 0, paid: false });

  const totalEstimated = budgetItems.reduce((s, b) => s + (b.amount_estimated || 0), 0);
  const totalActual = budgetItems.reduce((s, b) => s + (b.amount_actual || 0), 0);
  const totalPaid = budgetItems.filter((b) => b.paid).reduce((s, b) => s + (b.amount_actual || 0), 0);

  const byCategory = Object.keys(CATEGORY_LABELS).map((cat) => {
    const items = budgetItems.filter((b) => b.category === cat);
    const estimated = items.reduce((s, b) => s + (b.amount_estimated || 0), 0);
    const actual = items.reduce((s, b) => s + (b.amount_actual || 0), 0);
    return { category: cat, label: CATEGORY_LABELS[cat], count: items.length, estimated, actual, items };
  }).filter((c) => c.count > 0);

  async function handleSave() {
    if (!form.label.trim()) return;
    try {
      if (editing) {
        await base44.entities.ProjectBudgetItem.update(editing.id, form);
        setBudgetItems(budgetItems.map((b) => (b.id === editing.id ? { ...editing, ...form } : b)));
        toast({ title: "Ligne mise à jour" });
      } else {
        const created = await base44.entities.ProjectBudgetItem.create({ ...form, pageId: page.id, userId: page.userId });
        setBudgetItems([...budgetItems, created]);
        toast({ title: "Ligne ajoutée" });
      }
      setShowForm(false);
      setEditing(null);
      setForm({ category: "autres", label: "", amount_estimated: 0, amount_actual: 0, paid: false });
    } catch (e) {
      toast({ title: "Erreur", description: e.message, variant: "destructive" });
    }
  }

  async function handleDelete(item) {
    try {
      await base44.entities.ProjectBudgetItem.delete(item.id);
      setBudgetItems(budgetItems.filter((b) => b.id !== item.id));
      toast({ title: "Ligne supprimée" });
    } catch (e) {
      toast({ title: "Erreur", description: e.message, variant: "destructive" });
    }
  }

  function openEdit(item) {
    setEditing(item);
    setForm({ category: item.category || "autres", label: item.label, amount_estimated: item.amount_estimated || 0, amount_actual: item.amount_actual || 0, paid: item.paid || false });
    setShowForm(true);
  }

  return (
    <div className="max-w-4xl mx-auto px-8 py-10">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-display font-bold mb-1">Budget</h1>
          <p className="text-sm text-muted-foreground">{budgetItems.length} ligne{budgetItems.length > 1 ? "s" : ""}</p>
        </div>
        <button
          onClick={() => { setEditing(null); setForm({ category: "autres", label: "", amount_estimated: 0, amount_actual: 0, paid: false }); setShowForm(true); }}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full bg-foreground text-background text-sm font-medium hover:opacity-90 transition-opacity"
        >
          <Plus className="w-4 h-4" /> Ajouter
        </button>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-3 gap-4 mb-8">
        <div className="p-5 rounded-xl border border-border/60 bg-card">
          <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Estimé</p>
          <p className="text-2xl font-display font-bold">{totalEstimated.toLocaleString("fr-FR")} €</p>
        </div>
        <div className="p-5 rounded-xl border border-border/60 bg-card">
          <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Dépensé</p>
          <p className="text-2xl font-display font-bold">{totalActual.toLocaleString("fr-FR")} €</p>
        </div>
        <div className="p-5 rounded-xl border border-border/60 bg-card">
          <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Payé</p>
          <p className="text-2xl font-display font-bold">{totalPaid.toLocaleString("fr-FR")} €</p>
        </div>
      </div>

      {/* Progress bar */}
      {totalEstimated > 0 && (
        <div className="mb-8">
          <div className="flex justify-between text-xs text-muted-foreground mb-2">
            <span>{Math.round((totalActual / totalEstimated) * 100)}% du budget utilisé</span>
            <span>{(totalEstimated - totalActual).toLocaleString("fr-FR")} € restants</span>
          </div>
          <div className="h-2 rounded-full bg-muted overflow-hidden">
            <div className="h-full bg-foreground rounded-full transition-all" style={{ width: `${Math.min(100, (totalActual / totalEstimated) * 100)}%` }} />
          </div>
        </div>
      )}

      {/* By category */}
      {byCategory.length === 0 ? (
        <div className="text-center py-16">
          <Wallet className="w-10 h-10 mx-auto text-muted-foreground/40 mb-3" />
          <p className="text-sm text-muted-foreground">Aucune ligne budgétaire pour le moment</p>
        </div>
      ) : (
        <div className="flex flex-col gap-6">
          {byCategory.map((cat) => (
            <div key={cat.category}>
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-medium text-sm">{cat.label}</h3>
                <span className="text-xs text-muted-foreground">{cat.estimated.toLocaleString("fr-FR")} € estimé</span>
              </div>
              <div className="flex flex-col gap-1.5">
                {cat.items.map((item) => (
                  <div key={item.id} className="flex items-center gap-3 p-3 rounded-lg border border-border/40 bg-card group">
                    <div className={`w-2 h-2 rounded-full ${item.paid ? "bg-emerald-500" : "bg-amber-400"}`} />
                    <span className="flex-1 text-sm">{item.label}</span>
                    <span className="text-sm text-muted-foreground">{item.amount_estimated.toLocaleString("fr-FR")} €</span>
                    {item.amount_actual > 0 && <span className="text-sm font-medium">{item.amount_actual.toLocaleString("fr-FR")} €</span>}
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button onClick={() => openEdit(item)} className="px-2 py-1 rounded text-xs hover:bg-accent">Modifier</button>
                      <button onClick={() => handleDelete(item)} className="p-1 rounded hover:bg-red-50 text-muted-foreground hover:text-red-500"><Trash2 className="w-3.5 h-3.5" /></button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40" onClick={() => setShowForm(false)}>
          <div className="w-full max-w-md bg-card rounded-2xl border border-border p-6 m-4" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display font-semibold text-lg">{editing ? "Modifier la ligne" : "Nouvelle ligne"}</h3>
              <button onClick={() => setShowForm(false)} className="p-1.5 rounded-lg hover:bg-accent"><X className="w-4 h-4" /></button>
            </div>
            <div className="flex flex-col gap-3">
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Catégorie</label>
                <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-border text-sm">
                  {Object.entries(CATEGORY_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                </select>
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Libellé *</label>
                <input value={form.label} onChange={(e) => setForm({ ...form, label: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-border text-sm" placeholder="Ex. Location salle" />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Montant estimé (€)</label>
                <input type="number" value={form.amount_estimated} onChange={(e) => setForm({ ...form, amount_estimated: Number(e.target.value) })} className="w-full px-3 py-2 rounded-lg border border-border text-sm" />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Montant réel (€)</label>
                <input type="number" value={form.amount_actual} onChange={(e) => setForm({ ...form, amount_actual: Number(e.target.value) })} className="w-full px-3 py-2 rounded-lg border border-border text-sm" />
              </div>
              <div className="flex items-center gap-2">
                <input type="checkbox" id="paid" checked={form.paid} onChange={(e) => setForm({ ...form, paid: e.target.checked })} className="rounded" />
                <label htmlFor="paid" className="text-sm">Payé</label>
              </div>
            </div>
            <div className="flex justify-end gap-2 mt-5">
              <button onClick={() => setShowForm(false)} className="px-4 py-2 rounded-lg text-sm hover:bg-accent transition-colors">Annuler</button>
              <button onClick={handleSave} className="px-4 py-2 rounded-lg bg-foreground text-background text-sm font-medium hover:opacity-90 transition-opacity">{editing ? "Mettre à jour" : "Ajouter"}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}