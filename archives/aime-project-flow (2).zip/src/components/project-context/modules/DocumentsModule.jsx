import React from "react";
import { FileText, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";

export default function DocumentsModule({ page }) {
  return (
    <div className="max-w-3xl mx-auto px-8 py-10">
      <div className="mb-6">
        <h1 className="text-3xl font-display font-bold mb-1">Documents</h1>
        <p className="text-sm text-muted-foreground">Contrats, devis et documents liés au mariage</p>
      </div>

      <div className="p-6 rounded-xl border border-border/60 bg-card text-center">
        <FileText className="w-10 h-10 mx-auto text-muted-foreground/40 mb-3" />
        <p className="text-sm text-muted-foreground mb-4">Vos documents de mariage sont gérés dans le centre documentaire de votre association.</p>
        <Link
          to="/documents"
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full bg-foreground text-background text-sm font-medium hover:opacity-90 transition-opacity"
        >
          Aller au centre documentaire <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
    </div>
  );
}