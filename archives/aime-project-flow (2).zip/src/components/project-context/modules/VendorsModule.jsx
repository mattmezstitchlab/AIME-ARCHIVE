import React, { useState } from "react";
import { Briefcase, Plus, Search, Mail, Phone, Trash2, X } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";

const CATEGORY_LABELS = {
  lieu: "Lieu", traiteur: "Traiteur", photographe: "Photographe", videaste: "Vidéaste",
  fleuriste: "Fleuriste", musique: "Musique", decoration: "Décoration", patisserie: "Pâtisserie",
  location: "Location", beaute: "Beauté", autre: "Autre",
};
const STATUS_LABELS = {
  recherche: "Recherche", contacte: "Contacté", devis_recu: "Devis reçu",
  reserve: "Réservé", paye: "Payé", annule: "Annulé",
};
const STATUS_COLORS = {
  recherche: "bg-muted text-muted-foreground", contacte: "bg-blue-100 text-blue-700",
  devis_recu: "bg-amber-100 text-amber-700", reserve: "bg-emerald-100 text-emerald-700",
  paye: "bg-emerald-600 text-white", annule: "bg-red-100 text-red-700",
};

export default function VendorsModule({ page, vendors, setVendors }) {
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ name: "", category: "autre", contact_name: "", email: "", phone: "", price_estimated: 0, price_actual: 0, status: "recherche", deadline: "", notes: "" });

  const filtered = vendors.filter((v) => v.name?.toLowerCase().includes(search.toLowerCase()) || CATEGORY_LABELS[v.category]?.toLowerCase().includes(search.toLowerCase()));

  async function handleSave() {
    if (!form.name.trim()) return;
    try {
      if (editing) {
        await base44.entities.ProjectVendor.update(editing.id, form);
        setVendors(vendors.map((v) => (v.id === editing.id ? { ...editing, ...form } : v)));
        toast({ title: "Prestataire mis à jour" });
      } else {
        const created = await base44.entities.ProjectVendor.create({ ...form, pageId: page.id, userId: page.userId });
        setVendors([...vendors, created]);
        toast({ title: "Prestataire ajouté" });
      }
      setShowForm(false);
      setEditing(null);
      setForm({ name: "", category: "autre", contact_name: "", email: "", phone: "", price_estimated: 0, price_actual: 0, status: "recherche", deadline: "", notes: "" });
    } catch (e) {
      toast({ title: "Erreur", description: e.message, variant: "destructive" });
    }
  }

  async function handleDelete(vendor) {
    try {
      await base44.entities.ProjectVendor.delete(vendor.id);
      setVendors(vendors.filter((v) => v.id !== vendor.id));
      toast({ title: "Prestataire supprimé" });
    } catch (e) {
      toast({ title: "Erreur", description: e.message, variant: "destructive" });
    }
  }

  function openEdit(vendor) {
    setEditing(vendor);
    setForm({ name: vendor.name, category: vendor.category || "autre", contact_name: vendor.contact_name || "", email: vendor.email || "", phone: vendor.phone || "", price_estimated: vendor.price_estimated || 0, price_actual: vendor.price_actual || 0, status: vendor.status || "recherche", deadline: vendor.deadline || "", notes: vendor.notes || "" });
    setShowForm(true);
  }

  return (
    <div className="max-w-4xl mx-auto px-8 py-10">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-display font-bold mb-1">Prestataires</h1>
          <p className="text-sm text-muted-foreground">{vendors.length} prestataire{vendors.length > 1 ? "s" : ""}</p>
        </div>
        <button
          onClick={() => { setEditing(null); setForm({ name: "", category: "autre", contact_name: "", email: "", phone: "", price_estimated: 0, price_actual: 0, status: "recherche", deadline: "", notes: "" }); setShowForm(true); }}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full bg-foreground text-background text-sm font-medium hover:opacity-90 transition-opacity"
        >
          <Plus className="w-4 h-4" /> Ajouter
        </button>
      </div>

      <div className="relative mb-6">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <input type="text" placeholder="Rechercher..." value={search} onChange={(e) => setSearch(e.target.value)} className="w-full pl-10 pr-4 py-2.5 rounded-lg border border-border bg-card text-sm" />
      </div>

      {filtered.length === 0 ? (
        <div className="text-center py-16">
          <Briefcase className="w-10 h-10 mx-auto text-muted-foreground/40 mb-3" />
          <p className="text-sm text-muted-foreground">Aucun prestataire pour le moment</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {filtered.map((vendor) => (
            <div key={vendor.id} className="p-4 rounded-xl border border-border/60 bg-card hover:border-border transition-colors group">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <p className="font-medium">{vendor.name}</p>
                  <p className="text-xs text-muted-foreground">{CATEGORY_LABELS[vendor.category] || vendor.category}</p>
                </div>
                <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${STATUS_COLORS[vendor.status] || STATUS_COLORS.recherche}`}>
                  {STATUS_LABELS[vendor.status] || vendor.status}
                </span>
              </div>
              {(vendor.contact_name || vendor.email || vendor.phone) && (
                <div className="flex flex-col gap-1 text-xs text-muted-foreground mt-2">
                  {vendor.contact_name && <span>{vendor.contact_name}</span>}
                  {vendor.email && <span className="flex items-center gap-1"><Mail className="w-3 h-3" />{vendor.email}</span>}
                  {vendor.phone && <span className="flex items-center gap-1"><Phone className="w-3 h-3" />{vendor.phone}</span>}
                </div>
              )}
              {(vendor.price_estimated > 0 || vendor.price_actual > 0) && (
                <div className="flex gap-4 mt-3 pt-3 border-t border-border/40">
                  {vendor.price_estimated > 0 && <span className="text-xs text-muted-foreground">Estimé: <span className="font-medium text-foreground">{vendor.price_estimated.toLocaleString("fr-FR")} €</span></span>}
                  {vendor.price_actual > 0 && <span className="text-xs text-muted-foreground">Réel: <span className="font-medium text-foreground">{vendor.price_actual.toLocaleString("fr-FR")} €</span></span>}
                </div>
              )}
              <div className="flex justify-end gap-1 mt-2 opacity-0 group-hover:opacity-100 transition-opacity">
                <button onClick={() => openEdit(vendor)} className="px-3 py-1.5 rounded-lg text-xs hover:bg-accent transition-colors">Modifier</button>
                <button onClick={() => handleDelete(vendor)} className="p-1.5 rounded-lg hover:bg-red-50 text-muted-foreground hover:text-red-500 transition-colors"><Trash2 className="w-3.5 h-3.5" /></button>
              </div>
            </div>
          ))}
        </div>
      )}

      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40" onClick={() => setShowForm(false)}>
          <div className="w-full max-w-lg bg-card rounded-2xl border border-border p-6 m-4 max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display font-semibold text-lg">{editing ? "Modifier le prestataire" : "Nouveau prestataire"}</h3>
              <button onClick={() => setShowForm(false)} className="p-1.5 rounded-lg hover:bg-accent"><X className="w-4 h-4" /></button>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2">
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Nom *</label>
                <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-border text-sm" placeholder="Nom du prestataire" />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Catégorie</label>
                <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-border text-sm">
                  {Object.entries(CATEGORY_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                </select>
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Statut</label>
                <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-border text-sm">
                  {Object.entries(STATUS_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                </select>
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Contact</label>
                <input value={form.contact_name} onChange={(e) => setForm({ ...form, contact_name: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-border text-sm" placeholder="Nom du contact" />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Téléphone</label>
                <input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-border text-sm" placeholder="06 12 34 56 78" />
              </div>
              <div className="col-span-2">
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Email</label>
                <input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-border text-sm" placeholder="contact@email.com" />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Prix estimé (€)</label>
                <input type="number" value={form.price_estimated} onChange={(e) => setForm({ ...form, price_estimated: Number(e.target.value) })} className="w-full px-3 py-2 rounded-lg border border-border text-sm" />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Prix réel (€)</label>
                <input type="number" value={form.price_actual} onChange={(e) => setForm({ ...form, price_actual: Number(e.target.value) })} className="w-full px-3 py-2 rounded-lg border border-border text-sm" />
              </div>
            </div>
            <div className="flex justify-end gap-2 mt-5">
              <button onClick={() => setShowForm(false)} className="px-4 py-2 rounded-lg text-sm hover:bg-accent transition-colors">Annuler</button>
              <button onClick={handleSave} className="px-4 py-2 rounded-lg bg-foreground text-background text-sm font-medium hover:opacity-90 transition-opacity">{editing ? "Mettre à jour" : "Ajouter"}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}