import React, { useState, useEffect } from "react";
import { Images, Plus, Trash2, X, Upload } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { Image as UIImage } from "@/components/ui/image";

export default function GalleryModule({ page }) {
  const { toast } = useToast();
  const [sections, setSections] = useState([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const data = await base44.entities.PublicPageSection.filter({ pageId: page.id, type: "gallery" });
        setSections(data);
      } catch (e) {}
      setLoading(false);
    })();
  }, [page.id]);

  async function handleUpload(e) {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;
    setUploading(true);
    try {
      let gallery = sections[0];
      if (!gallery) {
        gallery = await base44.entities.PublicPageSection.create({
          type: "gallery",
          content: { title: "Galerie", items: [] },
          style: { background: "none", padding: "normal", align: "center", width: "wide" },
          pageId: page.id,
          userId: page.userId,
          position: 99,
          visibility: "public",
          hidden: false,
        });
        setSections([gallery]);
      }
      const items = [...(gallery.content?.items || [])];
      for (const file of files) {
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        items.push({ image: file_url, caption: "" });
      }
      await base44.entities.PublicPageSection.update(gallery.id, { content: { ...gallery.content, items } });
      setSections([{ ...gallery, content: { ...gallery.content, items } }]);
      toast({ title: `${files.length} photo(s) ajoutée(s)` });
    } catch (e) {
      toast({ title: "Erreur", description: e.message, variant: "destructive" });
    }
    setUploading(false);
  }

  async function removeImage(sectionId, index) {
    const section = sections.find((s) => s.id === sectionId);
    if (!section) return;
    const items = (section.content?.items || []).filter((_, i) => i !== index);
    await base44.entities.PublicPageSection.update(sectionId, { content: { ...section.content, items } });
    setSections(sections.map((s) => (s.id === sectionId ? { ...s, content: { ...s.content, items } } : s)));
  }

  const allItems = sections.flatMap((s) => s.content?.items || []);

  return (
    <div className="max-w-4xl mx-auto px-8 py-10">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-display font-bold mb-1">Galerie</h1>
          <p className="text-sm text-muted-foreground">{allItems.length} photo{allItems.length > 1 ? "s" : ""}</p>
        </div>
        <label className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-full bg-foreground text-background text-sm font-medium hover:opacity-90 transition-opacity cursor-pointer ${uploading ? "opacity-50 pointer-events-none" : ""}`}>
          <Upload className="w-4 h-4" /> {uploading ? "Upload..." : "Ajouter des photos"}
          <input type="file" accept="image/*" multiple className="hidden" onChange={handleUpload} />
        </label>
      </div>

      {loading ? (
        <div className="text-center py-16"><div className="w-6 h-6 border-2 border-border border-t-foreground rounded-full animate-spin mx-auto" /></div>
      ) : allItems.length === 0 ? (
        <div className="text-center py-16">
          <Images className="w-10 h-10 mx-auto text-muted-foreground/40 mb-3" />
          <p className="text-sm text-muted-foreground">Aucune photo pour le moment</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {allItems.map((item, i) => (
            <div key={i} className="relative group aspect-square rounded-xl overflow-hidden border border-border/60">
              <UIImage src={item.image} className="w-full h-full" fittingType="fill" />
              <button
                onClick={() => removeImage(sections[0]?.id, i)}
                className="absolute top-2 right-2 p-1.5 rounded-lg bg-black/60 text-white opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}