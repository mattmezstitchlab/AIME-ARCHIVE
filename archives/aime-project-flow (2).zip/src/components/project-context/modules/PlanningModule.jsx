import React, { useState, useEffect } from "react";
import { Calendar, Plus, Trash2, X, Clock } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";

export default function PlanningModule({ page }) {
  const { toast } = useToast();
  const [events, setEvents] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ title: "", date: "", time: "", location: "", description: "" });

  useEffect(() => {
    (async () => {
      try {
        const data = await base44.entities.PublicPageSection.filter({ pageId: page.id, type: "program" });
        // For now, planning events are stored as a simple list in a metadata section
        // This is a simplified planning module
      } catch (e) {}
    })();
  }, [page.id]);

  // Simple local state planning for now
  const [milestones, setMilestones] = useState([
    { id: 1, title: "Réservation du lieu", date: "2026-09-01", done: true },
    { id: 2, title: "Envoyer les faire-part", date: "2027-01-15", done: false },
    { id: 3, title: "Choisir le traiteur", date: "2027-02-01", done: false },
    { id: 4, title: "Essayage tenues", date: "2027-04-01", done: false },
    { id: 5, title: "Confirmation finale", date: "2027-05-15", done: false },
  ]);

  function toggleMilestone(id) {
    setMilestones(milestones.map((m) => (m.id === id ? { ...m, done: !m.done } : m)));
  }

  return (
    <div className="max-w-3xl mx-auto px-8 py-10">
      <div className="mb-6">
        <h1 className="text-3xl font-display font-bold mb-1">Planning</h1>
        <p className="text-sm text-muted-foreground">Vos étapes clés jusqu'au grand jour</p>
      </div>

      <div className="border-l-2 border-border pl-6 flex flex-col gap-4">
        {milestones.map((m) => (
          <div key={m.id} className="flex items-start gap-3 relative">
            <button
              onClick={() => toggleMilestone(m.id)}
              className={`absolute -left-[31px] top-1 w-5 h-5 rounded-full border-2 flex items-center justify-center transition-colors ${
                m.done ? "bg-foreground border-foreground" : "bg-card border-border hover:border-foreground"
              }`}
            >
              {m.done && <span className="text-background text-xs">✓</span>}
            </button>
            <div className="flex-1">
              <p className={`font-medium text-sm ${m.done ? "line-through text-muted-foreground" : ""}`}>{m.title}</p>
              <p className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
                <Calendar className="w-3 h-3" />
                {new Date(m.date).toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" })}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}