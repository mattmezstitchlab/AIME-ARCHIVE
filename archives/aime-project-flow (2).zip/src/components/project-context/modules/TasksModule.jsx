import React, { useState } from "react";
import { CheckSquare, Plus, Trash2, X } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

export default function TasksModule({ page }) {
  const { toast } = useToast();
  const [tasks, setTasks] = useState([
    { id: 1, title: "Faire la liste des invités", priority: "haute", done: false },
    { id: 2, title: "Choisir le photographe", priority: "haute", done: false },
    { id: 3, title: "Réserver le traiteur", priority: "haute", done: true },
    { id: 4, title: "Acheter les alliances", priority: "moyenne", done: false },
    { id: 5, title: "Préparer la cérémonie", priority: "moyenne", done: false },
    { id: 6, title: "Confirmer la décoration", priority: "basse", done: false },
  ]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ title: "", priority: "moyenne" });

  function addTask() {
    if (!form.title.trim()) return;
    setTasks([...tasks, { id: Date.now(), ...form, done: false }]);
    setForm({ title: "", priority: "moyenne" });
    setShowForm(false);
  }

  function toggleTask(id) {
    setTasks(tasks.map((t) => (t.id === id ? { ...t, done: !t.done } : t)));
  }

  function deleteTask(id) {
    setTasks(tasks.filter((t) => t.id !== id));
  }

  const priorityColors = {
    haute: "bg-red-100 text-red-700",
    moyenne: "bg-amber-100 text-amber-700",
    basse: "bg-muted text-muted-foreground",
  };

  const done = tasks.filter((t) => t.done).length;

  return (
    <div className="max-w-3xl mx-auto px-8 py-10">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-display font-bold mb-1">Tâches</h1>
          <p className="text-sm text-muted-foreground">{done}/{tasks.length} complétées</p>
        </div>
        <button
          onClick={() => setShowForm(true)}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full bg-foreground text-background text-sm font-medium hover:opacity-90 transition-opacity"
        >
          <Plus className="w-4 h-4" /> Ajouter
        </button>
      </div>

      <div className="flex flex-col gap-2">
        {tasks.map((task) => (
          <div key={task.id} className="flex items-center gap-3 p-3 rounded-xl border border-border/60 bg-card group">
            <button
              onClick={() => toggleTask(task.id)}
              className={`w-5 h-5 rounded-md border-2 flex items-center justify-center shrink-0 transition-colors ${
                task.done ? "bg-foreground border-foreground" : "border-border hover:border-foreground"
              }`}
            >
              {task.done && <span className="text-background text-xs">✓</span>}
            </button>
            <span className={`flex-1 text-sm ${task.done ? "line-through text-muted-foreground" : ""}`}>{task.title}</span>
            <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${priorityColors[task.priority]}`}>{task.priority}</span>
            <button onClick={() => deleteTask(task.id)} className="p-1 rounded opacity-0 group-hover:opacity-100 hover:bg-red-50 text-muted-foreground hover:text-red-500 transition-all"><Trash2 className="w-3.5 h-3.5" /></button>
          </div>
        ))}
      </div>

      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40" onClick={() => setShowForm(false)}>
          <div className="w-full max-w-sm bg-card rounded-2xl border border-border p-6 m-4" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display font-semibold text-lg">Nouvelle tâche</h3>
              <button onClick={() => setShowForm(false)} className="p-1.5 rounded-lg hover:bg-accent"><X className="w-4 h-4" /></button>
            </div>
            <div className="flex flex-col gap-3">
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Titre *</label>
                <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-border text-sm" placeholder="Ex. Réserver le photographe" />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Priorité</label>
                <select value={form.priority} onChange={(e) => setForm({ ...form, priority: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-border text-sm">
                  <option value="haute">Haute</option>
                  <option value="moyenne">Moyenne</option>
                  <option value="basse">Basse</option>
                </select>
              </div>
            </div>
            <div className="flex justify-end gap-2 mt-5">
              <button onClick={() => setShowForm(false)} className="px-4 py-2 rounded-lg text-sm hover:bg-accent transition-colors">Annuler</button>
              <button onClick={addTask} className="px-4 py-2 rounded-lg bg-foreground text-background text-sm font-medium hover:opacity-90 transition-opacity">Ajouter</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}