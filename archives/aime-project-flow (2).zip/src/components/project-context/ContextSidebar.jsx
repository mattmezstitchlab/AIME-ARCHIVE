import React from "react";
import { Link } from "react-router-dom";
import { Heart, LayoutDashboard, Calendar, CheckSquare, Users, Briefcase, Wallet, FileText, Grid3x3, Images, MessageCircle, Settings, Eye, ChevronLeft } from "lucide-react";
import { getContextModules, getIdentityTitle } from "@/lib/projectContexts";

const ICON_MAP = {
  Heart, LayoutDashboard, Calendar, CheckSquare, Users, Briefcase, Wallet, FileText, Grid3x3, Images, MessageCircle, Settings,
};

export default function ContextSidebar({ page, activeModule, onModuleChange, onTogglePreview, previewMode }) {
  const projectType = page?.projectType || "wedding";
  const modules = getContextModules(projectType, "private");
  const config = page?.projectConfig || {};
  const title = getIdentityTitle(projectType, config) || page?.title || "Mon projet";

  return (
    <aside className="w-[280px] shrink-0 h-screen sticky top-0 border-r border-border/60 bg-card flex flex-col">
      {/* Logo */}
      <div className="px-5 pt-5 pb-3">
        <Link to="/" className="flex items-center gap-2 text-xs font-display font-bold tracking-widest text-muted-foreground hover:text-foreground transition-colors">
          <Heart className="w-3.5 h-3.5" />
          LE MONDE AIME
        </Link>
      </div>

      {/* Profile */}
      <div className="px-5 pb-4">
        <div className="p-3 rounded-xl border border-border/60 bg-muted/30">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">{projectType === "wedding" ? "Mariage" : "Projet"}</span>
          </div>
          <h2 className="font-display font-semibold text-base truncate">{title}</h2>
          {config.date && (
            <p className="text-xs text-muted-foreground mt-0.5">{new Date(config.date).toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" })}</p>
          )}
          {config.location && (
            <p className="text-xs text-muted-foreground truncate">{config.location}</p>
          )}
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto px-3 pb-4">
        <div className="flex flex-col gap-0.5">
          {modules.map((mod) => {
            const Icon = ICON_MAP[mod.icon] || LayoutDashboard;
            const isActive = activeModule === mod.id;
            return (
              <button
                key={mod.id}
                onClick={() => onModuleChange(mod.id)}
                className={`flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors text-left ${
                  isActive
                    ? "bg-foreground text-background font-medium"
                    : "text-muted-foreground hover:text-foreground hover:bg-accent"
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span className="truncate">{mod.label}</span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Footer */}
      <div className="px-3 py-3 border-t border-border/60">
        <button
          onClick={onTogglePreview}
          className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors ${
            previewMode
              ? "bg-foreground text-background font-medium"
              : "text-muted-foreground hover:text-foreground hover:bg-accent"
          }`}
        >
          <Eye className="w-4 h-4 shrink-0" />
          <span>{previewMode ? "Mode édition" : "Aperçu public"}</span>
        </button>
        <Link
          to="/"
          className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-muted-foreground hover:text-foreground hover:bg-accent transition-colors mt-0.5"
        >
          <ChevronLeft className="w-4 h-4 shrink-0" />
          <span>Retour à l'accueil</span>
        </Link>
      </div>
    </aside>
  );
}