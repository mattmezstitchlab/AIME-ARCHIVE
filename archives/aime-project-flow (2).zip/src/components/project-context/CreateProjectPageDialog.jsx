import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { X, Heart, ArrowRight, Calendar, MapPin } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { PROJECT_CONTEXTS, getDefaultBlocks } from "@/lib/projectContexts";

export default function CreateProjectPageDialog({ open, onClose, userId, username }) {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [step, setStep] = useState(1);
  const [projectType, setProjectType] = useState("wedding");
  const [config, setConfig] = useState({ partner1: "", partner2: "", date: "", location: "", city: "" });
  const [creating, setCreating] = useState(false);

  if (!open) return null;

  const ctx = PROJECT_CONTEXTS[projectType];

  async function handleCreate() {
    setCreating(true);
    try {
      // Generate username if not provided
      let pageUsername = username;
      if (!pageUsername) {
        const base = `${(config.partner1 || "page").toLowerCase().replace(/[^a-z0-9]/g, "")}-${(config.partner2 || "projet").toLowerCase().replace(/[^a-z0-9]/g, "")}`;
        pageUsername = base + Math.floor(Math.random() * 1000);
      }

      // Create the page
      const page = await base44.entities.PersonalPublicPage.create({
        userId: userId,
        username: pageUsername,
        title: config.partner1 && config.partner2 ? `${config.partner1} & ${config.partner2}` : "Mon projet",
        description: "",
        status: "brouillon",
        template: "project",
        pageType: "project",
        projectType: projectType,
        projectConfig: config,
      });

      // Create default blocks
      const defaults = getDefaultBlocks(projectType);
      for (const block of defaults) {
        await base44.entities.PublicPageSection.create({
          ...block,
          pageId: page.id,
          userId,
        });
      }

      toast({ title: "Page projet créée" });
      onClose();
      navigate(`/project/${page.id}`);
    } catch (e) {
      toast({ title: "Erreur", description: e.message, variant: "destructive" });
    }
    setCreating(false);
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40" onClick={onClose}>
      <div className="w-full max-w-lg bg-card rounded-2xl border border-border p-6 m-4" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-5">
          <h3 className="font-display font-semibold text-lg">Créer une page projet</h3>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-accent"><X className="w-4 h-4" /></button>
        </div>

        {step === 1 && (
          <div className="flex flex-col gap-3">
            <p className="text-sm text-muted-foreground mb-2">Choisissez un type de projet</p>
            {Object.entries(PROJECT_CONTEXTS).map(([key, c]) => {
              const Icon = c.icon === "Heart" ? Heart : null;
              return (
                <button
                  key={key}
                  onClick={() => { setProjectType(key); setStep(2); }}
                  className={`flex items-center gap-4 p-4 rounded-xl border text-left transition-colors ${
                    projectType === key ? "border-foreground bg-accent" : "border-border/60 hover:border-foreground/30"
                  }`}
                >
                  {Icon && <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center"><Icon className="w-5 h-5" /></div>}
                  <div className="flex-1">
                    <p className="font-medium">{c.label}</p>
                    <p className="text-xs text-muted-foreground">{c.description}</p>
                  </div>
                  <ArrowRight className="w-4 h-4 text-muted-foreground" />
                </button>
              );
            })}
          </div>
        )}

        {step === 2 && (
          <div className="flex flex-col gap-4">
            <div className="flex items-center gap-2 mb-1">
              <Heart className="w-4 h-4" />
              <p className="text-sm font-medium">{ctx.label} — Informations</p>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Prénom 1</label>
                <input value={config.partner1} onChange={(e) => setConfig({ ...config, partner1: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-border text-sm" placeholder="Sophie" />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Prénom 2</label>
                <input value={config.partner2} onChange={(e) => setConfig({ ...config, partner2: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-border text-sm" placeholder="Thomas" />
              </div>
              <div className="col-span-2">
                <label className="text-xs font-medium text-muted-foreground mb-1 block flex items-center gap-1"><Calendar className="w-3 h-3" /> Date</label>
                <input type="date" value={config.date} onChange={(e) => setConfig({ ...config, date: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-border text-sm" />
              </div>
              <div className="col-span-2">
                <label className="text-xs font-medium text-muted-foreground mb-1 block flex items-center gap-1"><MapPin className="w-3 h-3" /> Lieu</label>
                <input value={config.location} onChange={(e) => setConfig({ ...config, location: e.target.value })} className="w-full px-3 py-2 rounded-lg border border-border text-sm" placeholder="Château de Versailles" />
              </div>
            </div>
            <div className="flex justify-between mt-2">
              <button onClick={() => setStep(1)} className="px-4 py-2 rounded-lg text-sm hover:bg-accent transition-colors">Retour</button>
              <button
                onClick={handleCreate}
                disabled={creating || (!config.partner1 && !config.partner2)}
                className="px-5 py-2 rounded-lg bg-foreground text-background text-sm font-medium hover:opacity-90 transition-opacity disabled:opacity-50"
              >
                {creating ? "Création..." : "Créer la page"}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}