import React from "react";
import { Image } from "@/components/ui/image";
import { Heart, MapPin, Navigation, Car, BedDouble, Bus, Clock, Gift, MessageCircle, Check } from "lucide-react";

const BG = {
  none: "",
  ivory: "bg-amber-50/40",
  dark: "bg-foreground text-background",
  sage: "bg-emerald-50/50",
  sand: "bg-stone-100",
};
const ALIGN = { left: "text-left items-start", center: "text-center items-center", right: "text-right items-end" };
const PAD = { compact: "py-8", normal: "py-14", spacious: "py-24" };
const WIDTH = { narrow: "max-w-2xl", normal: "max-w-4xl", wide: "max-w-6xl", full: "max-w-full" };

const INFO_ICONS = { MapPin, Navigation, Car, BedDouble, Bus, Clock, Gift, Heart, MessageCircle };

function Container({ style, children, className }) {
  const s = style || {};
  return (
    <div className={`w-full ${BG[s.background || "none"]} ${PAD[s.padding || "normal"]}`}>
      <div className={`mx-auto px-6 ${WIDTH[s.width || "normal"]} flex flex-col ${ALIGN[s.align || "center"]} gap-4 ${className || ""}`}>
        {children}
      </div>
    </div>
  );
}

function Img({ src, alt, className }) {
  if (!src) return <div className={`bg-muted/40 border border-dashed border-border/60 flex items-center justify-center text-muted-foreground/60 text-xs ${className || ""}`}>Image</div>;
  return <Image src={src} alt={alt || ""} className={className} fittingType="fill" />;
}

export default function WeddingBlockRenderer({ section, isEditing, onUpdate, selected, onSelect }) {
  const { type, content: c, style: s } = section;
  const sc = s || {};
  const edit = isEditing && onUpdate;
  const set = (key, val) => edit({ content: { ...c, [key]: val } });

  const Editable = ({ field, className, as: Tag = "div", placeholder }) => {
    const val = c[field] || "";
    if (!edit) return val ? <Tag className={className}>{val}</Tag> : null;
    return (
      <Tag
        contentEditable
        suppressContentEditableWarning
        onBlur={(e) => set(field, e.target.innerText)}
        className={`${className} outline-none focus:ring-2 focus:ring-ring/30 rounded px-1 -mx-1`}
        data-placeholder={placeholder}
      >{val}</Tag>
    );
  };

  const renderBlock = () => {
    switch (type) {
      case "hero_wedding": {
        return (
          <div className="flex flex-col items-center gap-6 py-12">
            {c.coverImage && <Img src={c.coverImage} className="aspect-[21/9] w-full rounded-2xl" />}
            <div className="flex flex-col items-center gap-3">
              <Editable field="title" as="h1" className="text-5xl md:text-6xl font-display font-bold tracking-tight" placeholder="Sophie & Thomas" />
              <div className="flex items-center gap-3 text-lg text-muted-foreground">
                <Heart className="w-4 h-4" />
                <Editable field="date" as="span" className="font-medium" placeholder="14 juin 2027" />
              </div>
              <Editable field="location" as="span" className="text-base text-muted-foreground" placeholder="Château de Versailles" />
              {c.button && (
                <span className="mt-4 inline-block px-8 py-3.5 rounded-full bg-foreground text-background text-sm font-medium tracking-wide">
                  {c.button}
                </span>
              )}
            </div>
          </div>
        );
      }
      case "our_story": {
        return (
          <>
            <Editable field="title" as="h2" className="text-3xl font-display font-semibold" placeholder="Notre histoire" />
            <Editable field="text" as="p" className="text-base text-muted-foreground leading-relaxed max-w-xl" placeholder="Racontez votre histoire" />
            <div className="w-full border-l-2 border-border pl-6 flex flex-col gap-6 mt-4">
              {(c.items || []).map((item, i) => (
                <div key={i} className="flex flex-col gap-1 relative">
                  <span className="absolute -left-[31px] top-1 w-3 h-3 rounded-full bg-foreground ring-4 ring-background" />
                  <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">{item.date}</span>
                  <span className="font-display font-medium text-lg">{item.title}</span>
                  <span className="text-sm text-muted-foreground leading-relaxed">{item.description}</span>
                </div>
              ))}
              {(!c.items || c.items.length === 0) && <span className="text-sm text-muted-foreground">Ajoutez des moments</span>}
            </div>
          </>
        );
      }
      case "practical_info": {
        return (
          <>
            <Editable field="title" as="h2" className="text-3xl font-display font-semibold" placeholder="Informations pratiques" />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full mt-2">
              {(c.items || []).map((item, i) => {
                const Icon = INFO_ICONS[item.icon] || MapPin;
                return (
                  <div key={i} className="flex items-start gap-3 p-4 rounded-xl border border-border/60 bg-card">
                    <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center shrink-0">
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="flex flex-col gap-0.5 text-left">
                      <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">{item.label}</span>
                      <span className="text-sm font-medium">{item.value}</span>
                    </div>
                  </div>
                );
              })}
              {(!c.items || c.items.length === 0) && <span className="text-sm text-muted-foreground">Ajoutez des informations</span>}
            </div>
          </>
        );
      }
      case "program": {
        return (
          <>
            <Editable field="title" as="h2" className="text-3xl font-display font-semibold" placeholder="Programme" />
            <div className="w-full border-l-2 border-border pl-6 flex flex-col gap-5 mt-4">
              {(c.items || []).map((item, i) => (
                <div key={i} className="flex flex-col gap-0.5 relative">
                  <span className="absolute -left-[31px] top-1.5 w-3 h-3 rounded-full bg-foreground ring-4 ring-background" />
                  <span className="text-sm font-display font-bold">{item.time}</span>
                  <span className="font-medium text-lg">{item.title}</span>
                  <span className="text-sm text-muted-foreground">{item.description}</span>
                </div>
              ))}
              {(!c.items || c.items.length === 0) && <span className="text-sm text-muted-foreground">Ajoutez des étapes</span>}
            </div>
          </>
        );
      }
      case "rsvp": {
        return (
          <div className="flex flex-col items-center gap-4 py-8">
            <Editable field="title" as="h2" className="text-3xl font-display font-semibold" placeholder="Confirmer ma présence" />
            <Editable field="text" as="p" className="text-base text-muted-foreground" placeholder="Répondez avant le 1er mai" />
            {!edit && (
              <div className="flex gap-3 mt-2">
                <button className="px-6 py-3 rounded-full bg-foreground text-background text-sm font-medium hover:opacity-90 transition-opacity">
                  Je serai présent
                </button>
                <button className="px-6 py-3 rounded-full border border-border text-sm font-medium hover:bg-accent transition-colors">
                  Je ne pourrai pas
                </button>
              </div>
            )}
            {edit && (
              <div className="flex gap-3 mt-2">
                <span className="px-6 py-3 rounded-full bg-foreground text-background text-sm font-medium">Je serai présent</span>
                <span className="px-6 py-3 rounded-full border border-border text-sm font-medium">Je ne pourrai pas</span>
              </div>
            )}
          </div>
        );
      }
      case "guestbook": {
        return (
          <>
            <Editable field="title" as="h2" className="text-3xl font-display font-semibold" placeholder="Livre d'or" />
            <Editable field="text" as="p" className="text-base text-muted-foreground" placeholder="Laissez un message aux mariés" />
            {!edit && (
              <div className="w-full max-w-md mx-auto mt-4 flex flex-col gap-3">
                <input type="text" placeholder="Votre nom" className="w-full px-4 py-2.5 rounded-lg border border-border bg-card text-sm" />
                <textarea placeholder="Votre message" rows={3} className="w-full px-4 py-2.5 rounded-lg border border-border bg-card text-sm" />
                <button className="self-end px-5 py-2.5 rounded-full bg-foreground text-background text-sm font-medium">
                  Envoyer
                </button>
              </div>
            )}
            <div className="w-full flex flex-col gap-3 mt-6">
              {(c.messages || []).map((msg, i) => (
                <div key={i} className="p-4 rounded-xl border border-border/60 bg-card text-left">
                  <span className="font-medium text-sm">{msg.author}</span>
                  <p className="text-sm text-muted-foreground mt-1">{msg.message}</p>
                </div>
              ))}
            </div>
          </>
        );
      }
      case "contribution": {
        return (
          <>
            <Editable field="title" as="h2" className="text-3xl font-display font-semibold" placeholder="Contribution" />
            <Editable field="text" as="p" className="text-base text-muted-foreground" placeholder="Pour ceux qui souhaitent participer" />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full mt-4">
              {(c.options || []).map((opt, i) => (
                <div key={i} className="flex flex-col gap-2 p-5 rounded-xl border border-border/60 bg-card text-left">
                  <Gift className="w-5 h-5" />
                  <span className="font-display font-medium">{opt.label}</span>
                  <span className="text-sm text-muted-foreground">{opt.description}</span>
                </div>
              ))}
              {(!c.options || c.options.length === 0) && <span className="text-sm text-muted-foreground">Ajoutez des options</span>}
            </div>
          </>
        );
      }
      default:
        return <div className="text-sm text-muted-foreground">Bloc: {type}</div>;
    }
  };

  return (
    <div
      onClick={edit ? (e) => { e.stopPropagation(); onSelect(); } : undefined}
      className={`relative ${edit ? "cursor-pointer" : ""} ${selected ? "ring-2 ring-ring" : ""}`}
    >
      <Container style={sc}>{renderBlock()}</Container>
    </div>
  );
}