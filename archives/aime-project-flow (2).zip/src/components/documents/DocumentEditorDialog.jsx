import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { DOC_TYPES } from "@/lib/aimeFormats";
import { createDocument, createDocumentVersion, generateDocumentContent, validateDocumentData, gatherContext, resolveDocumentVariables } from "@/lib/documentEngine";
import { logAction } from "@/lib/aimeAgent";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem
} from "@/components/ui/select";
import { useToast } from "@/components/ui/use-toast";
import { X, Loader2, Wand2, Save, AlertCircle, AlertTriangle, Info } from "lucide-react";

export default function DocumentEditorDialog({ mode, doc, associationId, projects, aiEnabled, onClose, onSaved }) {
  const { toast } = useToast();
  const [form, setForm] = useState({ title: "", type: "fiche_projet", content: "", project_id: "" });
  const [saving, setSaving] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [validation, setValidation] = useState(null);
  const [reason, setReason] = useState("");

  useEffect(() => {
    if (mode === "edit" && doc) {
      setForm({ title: doc.title || "", type: doc.type || "fiche_projet", content: doc.content || "", project_id: doc.project_id || "" });
    }
  }, [mode, doc]);

  // Validation en temps réel
  useEffect(() => {
    (async () => {
      const tempDoc = { ...form, association_id: associationId, project_id: form.project_id || null };
      const ctx = await gatherContext(tempDoc);
      setValidation(validateDocumentData(tempDoc, ctx));
    })();
  }, [form.title, form.type, form.content, form.project_id]);

  async function handleGenerate() {
    setGenerating(true);
    try {
      const tempDoc = { ...form, association_id: associationId, project_id: form.project_id || null };
      const ctx = await gatherContext(tempDoc);
      const res = await generateDocumentContent(tempDoc, ctx);
      if (res.title) setForm((f) => ({ ...f, title: res.title }));
      if (res.content) setForm((f) => ({ ...f, content: res.content }));
      toast({ title: "Contenu généré par AIME" });
    } catch (e) {
      toast({ title: "Erreur de génération", variant: "destructive" });
    }
    setGenerating(false);
  }

  async function handleSave() {
    if (!form.title.trim()) { toast({ title: "Titre requis", variant: "destructive" }); return; }
    setSaving(true);
    try {
      if (mode === "create") {
        const newDoc = await createDocument({
          type: form.type,
          title: form.title,
          content: form.content,
          projectId: form.project_id || null,
          associationId
        });
        toast({ title: "Document créé" });
      } else {
        await createDocumentVersion(doc.id, { content: form.content, reason: reason || "Modification", author: "Utilisateur" });
        if (form.title !== doc.title) {
          await base44.entities.Document.update(doc.id, { title: form.title });
        }
        toast({ title: "Version " + ((doc.version || 1) + 1) + " créée" });
      }
      onSaved();
    } catch (e) {
      toast({ title: e.message || "Erreur", variant: "destructive" });
    }
    setSaving(false);
  }

  const canSave = form.title.trim().length > 0;

  return (
    <div className="fixed inset-0 bg-navy/40 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-card rounded-2xl max-w-3xl w-full max-h-[88vh] overflow-y-auto soft-shadow" onClick={(e) => e.stopPropagation()}>
        {/* Header */}
        <div className="sticky top-0 bg-card border-b border-border px-6 py-4 flex items-center justify-between z-10">
          <h2 className="font-display text-lg font-semibold">{mode === "create" ? "Nouveau document" : "Modifier le document"}</h2>
          <button onClick={onClose} className="p-1.5 rounded-md hover:bg-accent text-muted-foreground"><X className="w-5 h-5" /></button>
        </div>

        <div className="p-6 space-y-4">
          {/* Titre */}
          <div>
            <Label className="text-xs">Titre</Label>
            <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Ex. Convention de partenariat" className="mt-1" />
          </div>

          {/* Type + Projet */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Type de document</Label>
              <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v })}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(DOC_TYPES).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Projet associé (optionnel)</Label>
              <Select value={form.project_id || "none"} onValueChange={(v) => setForm({ ...form, project_id: v === "none" ? "" : v })}>
                <SelectTrigger className="mt-1"><SelectValue placeholder="Aucun" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Aucun</SelectItem>
                  {projects.map((p) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Génération IA */}
          {aiEnabled && (
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={handleGenerate} disabled={generating} className="gap-1.5">
                {generating ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Wand2 className="w-3.5 h-3.5" />}
                Générer avec AIME
              </Button>
              <span className="text-xs text-muted-foreground">Pré-remplit avec les données du projet et de l'association</span>
            </div>
          )}

          {/* Contenu */}
          <div>
            <Label className="text-xs">Contenu</Label>
            <Textarea value={form.content} onChange={(e) => setForm({ ...form, content: e.target.value })} rows={12}
              placeholder={"Rédigez le contenu du document…\n\nVariables disponibles :\n{{association.name}} {{association.address}} {{association.legal_info}}\n{{project.name}} {{project.description}} {{project.location}}\n\nFormat :\n## Titre de section\n- Liste à puces\n| Col1 | Col2 | pour les tableaux"}
              className="mt-1 font-mono text-sm" />
          </div>

          {/* Motif de modification (edit mode) */}
          {mode === "edit" && (
            <div>
              <Label className="text-xs">Motif de la modification (optionnel)</Label>
              <Input value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Ex. Correction des coordonnées" className="mt-1" />
            </div>
          )}

          {/* Contrôle de cohérence */}
          {validation && (validation.bloquant.length > 0 || validation.a_verifier.length > 0 || validation.information.length > 0) && (
            <div className="rounded-xl border border-border bg-muted/30 p-4 space-y-2">
              <p className="text-sm font-medium">Contrôle du document</p>
              {validation.bloquant.map((m, i) => (
                <div key={"b" + i} className="flex items-start gap-2 text-sm text-red-700"><AlertCircle className="w-4 h-4 shrink-0 mt-0.5" /><span>{m}</span></div>
              ))}
              {validation.a_verifier.map((m, i) => (
                <div key={"v" + i} className="flex items-start gap-2 text-sm text-amber-700"><AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" /><span>{m}</span></div>
              ))}
              {validation.information.map((m, i) => (
                <div key={"i" + i} className="flex items-start gap-2 text-sm text-muted-foreground"><Info className="w-4 h-4 shrink-0 mt-0.5" /><span>{m}</span></div>
              ))}
            </div>
          )}

          <p className="text-xs text-muted-foreground italic">
            Modèle à vérifier et à adapter selon la situation, la convention applicable et les obligations en vigueur.
          </p>
        </div>

        {/* Footer */}
        <div className="sticky bottom-0 bg-card border-t border-border px-6 py-3 flex items-center justify-end gap-2">
          <Button variant="ghost" size="sm" onClick={onClose}>Annuler</Button>
          <Button size="sm" onClick={handleSave} disabled={!canSave || saving} className="gap-1.5">
            {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
            {mode === "create" ? "Créer" : "Enregistrer (v" + ((doc?.version || 1) + 1) + ")"}
          </Button>
        </div>
      </div>
    </div>
  );
}