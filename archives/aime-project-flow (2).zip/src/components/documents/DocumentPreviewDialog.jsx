import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { DOC_TYPES, formatDate } from "@/lib/aimeFormats";
import { DOC_STATUS, gatherContext, validateDocumentData, resolveDocumentVariables, exportDocumentPDF, archiveDocument } from "@/lib/documentEngine";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Download, X, Archive, Pencil, AlertCircle, AlertTriangle, Info, History } from "lucide-react";

export default function DocumentPreviewDialog({ doc, context, onClose, onEdit, onArchived }) {
  const [fullContext, setFullContext] = useState(null);
  const [validation, setValidation] = useState(null);
  const [resolved, setResolved] = useState(null);
  const [showHistory, setShowHistory] = useState(false);

  useEffect(() => {
    (async () => {
      const ctx = await gatherContext({ ...doc, ...context });
      setFullContext(ctx);
      setValidation(validateDocumentData(doc, ctx));
      const r = resolveDocumentVariables(doc.content || "", ctx);
      setResolved(r);
    })();
  }, [doc.id]);

  if (!fullContext) return null;

  const st = DOC_STATUS[doc.status] || DOC_STATUS.brouillon;

  async function handlePDF() {
    const pdfDoc = await exportDocumentPDF(doc, fullContext);
    const safe = (doc.title || "document").replace(/[^a-zA-Z0-9-_ ]/g, "").trim().replace(/\s+/g, "-").toLowerCase();
    pdfDoc.save(safe + "-v" + (doc.version || 1) + ".pdf");
  }

  async function handleArchive() {
    await archiveDocument(doc.id);
    onArchived();
    onClose();
  }

  return (
    <div className="fixed inset-0 bg-navy/40 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-card rounded-2xl max-w-3xl w-full max-h-[88vh] overflow-y-auto soft-shadow" onClick={(e) => e.stopPropagation()}>
        {/* Header */}
        <div className="sticky top-0 bg-card border-b border-border px-6 py-4 flex items-start justify-between gap-3 z-10">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <Badge variant="outline" className="font-normal">{DOC_TYPES[doc.type] || doc.type}</Badge>
              <Badge className={st.cls + " border-0 font-normal"}>{st.label}</Badge>
              <span className="text-xs text-muted-foreground">v{doc.version}</span>
            </div>
            <h2 className="font-display text-xl font-semibold truncate">{doc.title}</h2>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-md hover:bg-accent text-muted-foreground"><X className="w-5 h-5" /></button>
        </div>

        <div className="p-6 space-y-4">
          {/* Contrôle de cohérence */}
          {validation && (validation.bloquant.length > 0 || validation.a_verifier.length > 0 || validation.information.length > 0) && (
            <div className="rounded-xl border border-border bg-muted/30 p-4 space-y-2">
              <p className="text-sm font-medium">Contrôle du document</p>
              {validation.bloquant.length > 0 && (
                <div className="space-y-1">
                  {validation.bloquant.map((m, i) => (
                    <div key={i} className="flex items-start gap-2 text-sm text-red-700">
                      <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" /><span>{m}</span>
                    </div>
                  ))}
                </div>
              )}
              {validation.a_verifier.length > 0 && (
                <div className="space-y-1">
                  {validation.a_verifier.map((m, i) => (
                    <div key={i} className="flex items-start gap-2 text-sm text-amber-700">
                      <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" /><span>{m}</span>
                    </div>
                  ))}
                </div>
              )}
              {validation.information.length > 0 && (
                <div className="space-y-1">
                  {validation.information.map((m, i) => (
                    <div key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                      <Info className="w-4 h-4 shrink-0 mt-0.5" /><span>{m}</span>
                    </div>
                  ))}
                </div>
              )}
              <p className="text-xs text-muted-foreground pt-1 border-t border-border">
                {validation.bloquant.length} bloquant(s) · {validation.a_verifier.length} à vérifier · {validation.information.length} information(s)
              </p>
            </div>
          )}

          {/* Variables non résolues */}
          {resolved?.missing?.length > 0 && (
            <div className="rounded-lg bg-amber-50 border border-amber-200 p-3 text-sm text-amber-800">
              <p className="font-medium mb-1">Variables non résolues :</p>
              <p className="text-xs">{resolved.missing.join(", ")}</p>
            </div>
          )}

          {/* Contenu */}
          <div className="rounded-xl border border-border p-5 bg-white">
            <div className="whitespace-pre-wrap text-sm leading-relaxed text-foreground/90 font-body">
              {resolved?.resolvedContent || doc.content || "—"}
            </div>
          </div>

          {/* Historique des versions */}
          {doc.version_history?.length > 0 && (
            <div>
              <button onClick={() => setShowHistory(!showHistory)} className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground">
                <History className="w-4 h-4" /> Historique des versions ({doc.version_history.length})
              </button>
              {showHistory && (
                <div className="mt-2 space-y-2 pl-5 border-l-2 border-border">
                  {doc.version_history.map((v, i) => (
                    <div key={i} className="text-sm">
                      <p className="font-medium">v{v.version} — {DOC_STATUS[v.status]?.label || v.status}</p>
                      <p className="text-xs text-muted-foreground">{v.author} · {formatDate(v.date)} {v.reason ? "· " + v.reason : ""}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Mention légale */}
          <p className="text-xs text-muted-foreground italic">
            Modèle à vérifier et à adapter selon la situation, la convention applicable et les obligations en vigueur.
          </p>
        </div>

        {/* Footer */}
        <div className="sticky bottom-0 bg-card border-t border-border px-6 py-3 flex items-center justify-between gap-2">
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={handlePDF} className="gap-1.5"><Download className="w-3.5 h-3.5" /> PDF</Button>
            {doc.status !== "archive" && (
              <Button variant="ghost" size="sm" onClick={handleArchive} className="gap-1.5 text-muted-foreground hover:text-destructive"><Archive className="w-3.5 h-3.5" /> Archiver</Button>
            )}
          </div>
          <div className="flex gap-2">
            <Button variant="ghost" size="sm" onClick={onClose}>Fermer</Button>
            <Button size="sm" onClick={() => onEdit(doc)} className="gap-1.5"><Pencil className="w-3.5 h-3.5" /> Modifier</Button>
          </div>
        </div>
      </div>
    </div>
  );
}