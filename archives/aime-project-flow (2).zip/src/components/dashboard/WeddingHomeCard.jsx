import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Heart, Users, FileText, Clock, Target, Globe, Compass, ArrowRight } from 'lucide-react';

function extractDate(dna) {
  const line = (dna?.timeline?.present || []).find((l) => l.startsWith('Mariage le '));
  return line ? line.replace('Mariage le ', '') : null;
}
function extractLocation(dna) {
  const line = (dna?.timeline?.present || []).find((l) => l.startsWith('Lieu : '));
  return line ? line.replace('Lieu : ', '') : null;
}

const NAV = [
  { key: 'dna', label: 'Vision', icon: Compass, path: (id) => `/aime/project/${id}/dna` },
  { key: 'participants', label: 'Prestataires', icon: Users, path: (id) => `/aime/project/${id}/wedding?module=participants` },
  { key: 'documents', label: 'Documents', icon: FileText, path: (id) => `/aime/project/${id}/wedding?module=documents` },
  { key: 'timeline', label: 'Planning', icon: Clock, path: (id) => `/aime/project/${id}/wedding?module=timeline` },
  { key: 'day', label: 'Jour J', icon: Target, path: (id) => `/aime/project/${id}/day` },
];

export default function WeddingHomeCard() {
  const [loading, setLoading] = useState(true);
  const [project, setProject] = useState(null);
  const [dna, setDna] = useState(null);
  const [participants, setParticipants] = useState([]);

  useEffect(() => {
    (async () => {
      try {
        const me = await base44.auth.me();
        const projects = await base44.entities.AimeProject.filter({ owner_id: me.id, category: 'wedding' }, '-created_date', 1);
        if (projects[0]) {
          const p = projects[0];
          setProject(p);
          const [dnaList, parts] = await Promise.all([
            base44.entities.ProjectDNA.filter({ project_id: p.id, owner_id: me.id }),
            base44.entities.WeddingParticipant.filter({ project_id: p.id, owner_id: me.id }),
          ]);
          setDna(dnaList[0] || null);
          setParticipants(parts);
        }
      } catch (e) {}
      setLoading(false);
    })();
  }, []);

  if (loading || !project) return null;

  const coupleName = dna?.identity?.name || project.name;
  const date = extractDate(dna);
  const location = extractLocation(dna);
  const confirmed = participants.filter((p) => p.status === 'accepted' || p.status === 'active').length;

  return (
    <div className="rounded-2xl border border-border bg-card soft-shadow p-6 mb-8">
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <span className="brand-badge inline-flex items-center gap-1.5"><Heart className="w-3 h-3" /> Mon mariage</span>
          <h2 className="font-display text-2xl sm:text-3xl font-semibold mt-3">{coupleName}</h2>
          <p className="text-sm text-muted-foreground mt-1">
            {date || 'Date à définir'} · {location || 'Lieu à définir'}
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            {confirmed}/{participants.length} prestataire(s) confirmé(s)
          </p>
        </div>
        <Link
          to={`/aime/project/${project.id}/wedding`}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full bg-foreground text-background text-sm font-medium hover:opacity-90 transition-opacity shrink-0"
        >
          Ouvrir mon mariage <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
      <div className="flex flex-wrap gap-2 mt-5">
        {NAV.map((n) => {
          const Icon = n.icon;
          return (
            <Link
              key={n.key}
              to={n.path(project.id)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-full border border-border bg-background text-xs font-medium hover:bg-accent transition-colors"
            >
              <Icon className="w-3.5 h-3.5" /> {n.label}
            </Link>
          );
        })}
        {project.studio_page_id && (
          <Link
            to={`/project/${project.studio_page_id}`}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-full border border-border bg-background text-xs font-medium hover:bg-accent transition-colors"
          >
            <Globe className="w-3.5 h-3.5" /> Site mariage
          </Link>
        )}
      </div>
    </div>
  );
}