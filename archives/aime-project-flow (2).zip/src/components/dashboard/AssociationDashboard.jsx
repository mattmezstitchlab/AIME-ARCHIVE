import { useEffect, useMemo, useRef, useState } from "react";
import { base44 } from "@/api/base44Client";
import "./associationDashboard.css";

const MONTH_ABBR = ["JAN", "FÉV", "MAR", "AVR", "MAI", "JUN", "JUL", "AOÛ", "SEP", "OCT", "NOV", "DÉC"];
const MONTH_FULL = ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"];
const SLICE_CLASS = ["s-rent", "s-food", "s-transport", "s-fun", "s-other"];
const SLICE_COLOR = ["#785578", "#C5C058", "#3B6AB4", "#565650", "#3f3f39"];

const eur = (n) => Math.round(n || 0).toLocaleString("fr-FR");
const eurFmt = (n) => `${eur(n)} €`;

// Catmull-Rom interpolation for the ridgeline curve
function crm(p0, p1, p2, p3, t) {
  const t2 = t * t, t3 = t2 * t;
  return 0.5 * ((2 * p1) + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t2 + (-p0 + 3 * p1 - 3 * p2 + p3) * t3);
}

function useCountUp(target, duration = 900) {
  const [val, setVal] = useState(0);
  const ref = useRef(0);
  useEffect(() => {
    const start = performance.now();
    const from = ref.current;
    let raf;
    const tick = (now) => {
      const p = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - p, 3);
      setVal(from + (target - from) * eased);
      if (p < 1) raf = requestAnimationFrame(tick);
      else ref.current = target;
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, duration]);
  return val;
}

export default function AssociationDashboard() {
  const [data, setData] = useState(null);
  const [sel, setSel] = useState(-1);
  const [hi, setHi] = useState(-1);
  const ridgeRef = useRef(null);

  useEffect(() => {
    (async () => {
      try {
        const [depenses, budgets, projets, journal] = await Promise.all([
          base44.entities.Depense.list(),
          base44.entities.Budget.list(),
          base44.entities.Projet.list(),
          base44.entities.JournalEntree.list()
        ]);
        const projMap = Object.fromEntries(projets.map((p) => [p.id, p.name || "Projet"]));

        // Last 12 months ending this month
        const now = new Date();
        const months = [];
        for (let i = 11; i >= 0; i--) {
          const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
          months.push({
            y: d.getFullYear(),
            m: d.getMonth(),
            label: `${MONTH_ABBR[d.getMonth()]} ${String(d.getFullYear()).slice(2)}`,
            full: `${MONTH_FULL[d.getMonth()]} ${d.getFullYear()}`,
            short: MONTH_ABBR[d.getMonth()],
            spend: 0,
            byProject: {}
          });
        }
        const keyOf = (y, m) => `${y}-${m}`;
        const index = {};
        months.forEach((mo, i) => { index[keyOf(mo.y, mo.m)] = i; });

        (depenses || []).forEach((dp) => {
          if (!dp.date || typeof dp.montant !== "number") return;
          const [yy, mm] = dp.date.split("-").map(Number);
          const idx = index[keyOf(yy, mm - 1)];
          if (idx == null) return;
          months[idx].spend += dp.montant;
          const k = dp.project_id || "_sans";
          months[idx].byProject[k] = (months[idx].byProject[k] || 0) + dp.montant;
        });

        const totalDepense = (depenses || []).reduce((s, d) => s + (typeof d.montant === "number" ? d.montant : 0), 0);
        const prevuParProjet = {};
        let prevu = 0, realise = 0;
        (budgets || []).forEach((b) => {
          prevu += b.total_prevu || 0;
          realise += b.total_realise || 0;
          if (b.project_id) prevuParProjet[b.project_id] = (prevuParProjet[b.project_id] || 0) + (b.total_prevu || 0);
        });

        const recents = (journal || [])
          .slice()
          .sort((a, b) => (b.created_date || "").localeCompare(a.created_date || ""))
          .slice(0, 5)
          .map((e) => ({ text: e.details || e.action || "action", date: e.created_date, auteur: e.auteur }));

        setData({ months, projMap, prevu, realise, totalDepense, prevuParProjet, recents });
        setSel(months.length - 1);
      } catch (e) {
        setData({ months: [], error: true });
      }
    })();
  }, []);

  // Slices for the selected month (top projects + Other)
  const slices = useMemo(() => {
    if (!data || sel < 0) return [];
    const m = data.months[sel];
    const entries = Object.entries(m.byProject).filter(([, v]) => v > 0).sort((a, b) => b[1] - a[1]);
    const top = entries.slice(0, 4).map(([pid, val], i) => ({
      name: data.projMap[pid] || "Sans projet", val, color: SLICE_COLOR[i], cls: SLICE_CLASS[i], pct: 0,
      barPct: data.prevuParProjet[pid] ? Math.min(100, Math.round(val / data.prevuParProjet[pid] * 100)) : (val > 0 ? 100 : 0)
    }));
    const otherVal = entries.slice(4).reduce((s, [, v]) => s + v, 0);
    if (otherVal > 0) top.push({ name: "Autres projets", val: otherVal, color: SLICE_COLOR[4], cls: SLICE_CLASS[4], pct: 0, barPct: 100 });
    const total = m.spend || 1;
    top.forEach((s) => { s.pct = Math.round((s.val / total) * 100); });
    return top;
  }, [data, sel]);

  // Ridgeline geometry
  const ridge = useMemo(() => {
    if (!data || data.months.length === 0) return null;
    const raw = data.months.map((m) => m.spend);
    const min = Math.min(...raw, 0), max = Math.max(...raw, 1);
    const yOf = (v) => { const n = max === min ? 0.5 : (v - min) / (max - min); return 100 - (0.16 + n * 0.72) * 100; };
    const L = raw.length;
    const sample = (pos) => {
      let i = Math.floor(pos); if (i > L - 2) i = L - 2; if (i < 0) i = 0;
      return crm(raw[Math.max(0, i - 1)], raw[i], raw[i + 1], raw[Math.min(L - 1, i + 2)], pos - i);
    };
    const N = 97;
    const lines = [];
    for (let s = 0; s < N; s++) {
      const x = (s / (N - 1)) * 100;
      const y = yOf(sample((s / (N - 1)) * (L - 1)));
      lines.push({ x, y });
    }
    const pts = raw.map((v, i) => ({ x: (i / (L - 1)) * 100, y: yOf(v) }));
    return { lines, pts, raw };
  }, [data]);

  // Count-ups for the KPIs (global figures)
  const cPrevu = useCountUp(data ? data.prevu : 0);
  const cDep = useCountUp(data ? data.totalDepense : 0);
  const taux = data && data.prevu > 0 ? Math.round((data.totalDepense / data.prevu) * 100) : 0;
  const cTaux = useCountUp(taux);

  if (!data) {
    return (
      <section className="smd-section">
        <div className="smd-sheet">
          <p style={{ fontFamily: "'Geist Mono', monospace", color: "var(--smd-ink-soft)", padding: "32px 0", textAlign: "center" }}>
            chargement du tableau de bord…
          </p>
        </div>
      </section>
    );
  }

  const m = data.months[sel] || data.months[data.months.length - 1] || { label: "—", full: "—", short: "—", spend: 0 };
  const prev = sel > 0 ? data.months[sel - 1].spend : 0;
  const delta = prev > 0 ? Math.round(((m.spend - prev) / prev) * 100) : null;
  const reste = data.prevu - data.totalDepense;
  const centerCat = hi >= 0 ? slices[hi] : null;
  const donutTotal = m.spend;

  // Donut segments — always render at least one grey ring so the shape stays
  const segs = slices.length ? slices : [{ val: 0, cls: "s-other", pct: 100 }];
  let cum = 0;

  return (
    <section className="smd-section">
      <div className="smd-sheet" data-smd>
        <header className="smd-head">
          <p className="smd-eyebrow">association os</p>
          <div className="smd-head-row">
            <h2 className="smd-code">{m.short} {String(m.full).split(" ")[1] || ""}</h2>
            <div className="smd-head-right">TABLEAU DE BORD</div>
          </div>
        </header>

        <div className="smd-frame">
          <div className="smd-serial">
            <div className="smd-serial-field">
              <span className="smd-serial-label">PÉRIODE</span>
              <span className="smd-serial-value">{m.full}</span>
            </div>
            <div className="smd-serial-field">
              <span className="smd-serial-label">ASSOCIATION</span>
              <span className="smd-serial-value">LE MONDE AIME</span>
            </div>
            <div className="smd-serial-field">
              <span className="smd-serial-label">M.A.J</span>
              <span className="smd-serial-value">en direct</span>
            </div>
          </div>

          <div className="smd-timeline">
            <div className="smd-timeline-head">
              <div className="smd-timeline-readout" aria-live="polite">
                <span className="smd-ro-month">{m.label}</span>
                <span className="smd-ro-value">{eurFmt(m.spend)}</span>
                {delta != null && (
                  <span className={"smd-ro-delta " + (delta >= 0 ? "is-up" : "is-down")}>
                    {delta >= 0 ? "▲" : "▼"} {Math.abs(delta)}%
                  </span>
                )}
                <span className="smd-ro-note">dépenses du mois</span>
              </div>
            </div>
            <div className="smd-axis" role="tablist" aria-label="Dépenses par mois, cliquer pour charger">
              {data.months.map((mo, i) => (
                <button
                  key={i}
                  className={"smd-node" + (i === sel ? " is-selected" : "")}
                  type="button"
                  style={{ "--i": i }}
                  role="tab"
                  aria-selected={i === sel}
                  onClick={() => setSel(i)}
                >
                  <span className="smd-dot" />
                  <span className="smd-node-label">{mo.short}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="smd-grid">
            <div className="smd-col smd-col--main">
              <div className="smd-kpis">
                <div className="smd-kpi smd-kpi--nw">
                  <p className="smd-kpi-label">Budget prévu</p>
                  <div className="smd-kpi-value">{eurFmt(cPrevu)}</div>
                  <p className="smd-kpi-delta">ressources mobilisables</p>
                </div>
                <div className="smd-kpi smd-kpi--spend">
                  <p className="smd-kpi-label">Dépensé (cumul)</p>
                  <div className="smd-kpi-value">{eurFmt(cDep)}</div>
                  <p className="smd-kpi-delta">toutes dépenses enregistrées</p>
                </div>
                <div className="smd-kpi smd-kpi--save">
                  <p className="smd-kpi-label">Taux d'exécution</p>
                  <div className="smd-kpi-value">{Math.round(cTaux)}%</div>
                  <p className="smd-kpi-delta">du budget prévu</p>
                </div>
              </div>

              <div className="smd-panel smd-panel--spend">
                <p className="smd-panel-title">DÉPENSES PAR PROJET <span>{eurFmt(donutTotal)}</span></p>
                <div className="smd-donut-wrap">
                  <div className={"smd-donut" + (hi >= 0 ? " is-active" : "")}>
                    <svg className="smd-donut-svg" viewBox="0 0 42 42" role="img" aria-label="Dépenses par projet">
                      <circle className="smd-ring" cx="21" cy="21" r="15.915" />
                      {segs.map((s, i) => {
                        const off = -cum; cum += s.pct;
                        return (
                          <circle
                            key={i}
                            className={"smd-seg " + s.cls + (i === hi ? " is-hi" : "")}
                            cx="21" cy="21" r="15.915"
                            strokeDasharray={`${s.pct} ${100 - s.pct}`}
                            strokeDashoffset={String(off)}
                            onMouseEnter={() => setHi(i)}
                            onMouseLeave={() => setHi(-1)}
                          />
                        );
                      })}
                    </svg>
                    <div className="smd-donut-center" aria-hidden="true">
                      <b>{centerCat ? eurFmt(centerCat.val) : eurFmt(donutTotal)}</b>
                      <small>{centerCat ? (centerCat.name || "").toUpperCase() : "DÉPENSES DU MOIS"}</small>
                    </div>
                  </div>
                  {slices.length > 0 ? (
                    <ul className="smd-legend">
                      {slices.map((s, i) => (
                        <li
                          key={i}
                          className={i === hi ? "is-hi" : ""}
                          onMouseEnter={() => setHi(i)}
                          onMouseLeave={() => setHi(-1)}
                        >
                          <span className="smd-swatch" style={{ background: s.color }} />
                          <span className="smd-leg-name" title={s.name}>{s.name}</span>
                          <span className="smd-bar"><span className="smd-bar-fill" style={{ background: s.color, width: s.barPct + "%" }} /></span>
                          <span className="smd-leg-amt">{eurFmt(s.val)}</span>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p style={{ fontSize: 12, color: "var(--smd-ink-soft)", alignSelf: "center" }}>
                      Aucune dépense ce mois-ci. Les dépenses saisies apparaîtront ici.
                    </p>
                  )}
                </div>
              </div>

              <div className="smd-panel smd-panel--flow">
                <p className="smd-panel-title">ÉVOLUTION DES DÉPENSES <span>{ridge ? eurFmt(ridge.raw[sel] || 0) : "—"}</span></p>
                <div className="smd-ridge">
                  <div className="smd-ridge-chart">
                    {ridge && (
                      <svg className="smd-ridge-svg" viewBox="0 0 100 100" preserveAspectRatio="none">
                        {ridge.lines.map((l, i) => (
                          <line key={i} className="smd-ridge-line" x1={l.x} x2={l.x} y1={100} y2={l.y} />
                        ))}
                        {ridge.pts[sel] && (
                          <line className="smd-ridge-accent" x1={ridge.pts[sel].x} x2={ridge.pts[sel].x} y1={100} y2={ridge.pts[sel].y} />
                        )}
                      </svg>
                    )}
                    {ridge && ridge.pts[sel] && (
                      <span className="smd-ridge-dot" style={{ left: ridge.pts[sel].x + "%", top: ridge.pts[sel].y + "%" }} />
                    )}
                  </div>
                  <div className="smd-ridge-labels">
                    {data.months.map((mo, i) => (
                      <span key={i} className={i === sel ? "is-selected" : ""} onClick={() => setSel(i)}>{mo.short}</span>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <div className="smd-col smd-col--side">
              <div className="smd-panel smd-recent">
                <p className="smd-panel-title">ACTIVITÉ RÉCENTE <span>{String(data.recents.length).padStart(2, "0")}</span></p>
                <ul>
                  {data.recents.length === 0 ? (
                    <li style={{ border: "none", color: "var(--smd-ink-soft)" }}>Le journal est vide pour l'instant.</li>
                  ) : data.recents.map((r, i) => (
                    <li key={i}>
                      <span className="smd-recent-name">{r.text}</span>
                      <span className="smd-recent-date">{r.date ? new Date(r.date).toLocaleDateString("fr-FR", { day: "2-digit", month: "short" }) : "—"}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="smd-panel smd-accounts">
                <p className="smd-panel-title">BUDGETS PROJETS <span>{eurFmt(data.prevu)}</span></p>
                <ul>
                  {Object.keys(data.prevuParProjet).length === 0 ? (
                    <li style={{ border: "none", color: "var(--smd-ink-soft)" }}>Aucun budget défini.</li>
                  ) : Object.entries(data.prevuParProjet).sort((a, b) => b[1] - a[1]).map(([pid, v], i) => (
                    <li key={pid}>
                      <span className="smd-acct-name">{data.projMap[pid] || "Projet"}</span>
                      <span className="smd-acct-bal">{eurFmt(v)}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="smd-footer">
                <div className="smd-table-wrap">
                  <table className="smd-table">
                    <tbody>
                      <tr><th>BUDGET PRÉVU</th><td>{eurFmt(data.prevu)}</td></tr>
                      <tr><th>DÉPENSÉ</th><td>{eurFmt(data.totalDepense)}</td></tr>
                      <tr><th>PÉRIODE</th><td>{m.label} · 12 mois</td></tr>
                    </tbody>
                  </table>
                </div>
                <div className="smd-stamp">
                  <span className="smd-stamp-title">RESTE À MOBILISER · {m.short}</span>
                  <div className="smd-stamp-body">
                    <span className="smd-stamp-big" style={{ color: reste >= 0 ? "var(--smd-blue)" : "var(--smd-red)" }}>
                      {reste >= 0 ? "" : "−"}{eurFmt(Math.abs(reste))}
                    </span>
                    <span className="smd-stamp-num">{taux}%</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}