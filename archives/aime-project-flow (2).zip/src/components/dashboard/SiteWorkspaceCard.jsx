import { Link } from "react-router-dom";
import { ArrowRight, Globe, Layers3, PanelTop } from "lucide-react";

export default function SiteWorkspaceCard() {
  return <section className="mb-8 rounded-lg border border-border bg-card p-6 shadow-sm"><div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between"><div><span className="brand-badge">Espace public</span><h2 className="mt-4 text-2xl font-semibold">AIME Studio</h2><p className="mt-2 text-sm text-muted-foreground">Landing, pages publiques et publication depuis un seul espace.</p></div><div className="flex flex-wrap gap-2"><Link to="/studio/page" className="brand-secondary-btn"><Layers3 className="h-4 w-4" />Modifier le site</Link><Link to="/landing" className="brand-outline-btn"><Globe className="h-4 w-4" />Voir la landing</Link><Link to="/admin/landing" className="brand-outline-btn"><PanelTop className="h-4 w-4" />Administrer<ArrowRight className="h-4 w-4" /></Link></div></div></section>;
}