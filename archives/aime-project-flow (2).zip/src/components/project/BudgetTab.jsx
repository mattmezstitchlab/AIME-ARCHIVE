import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { euro } from "@/lib/aimeFormats";
import { logAction } from "@/lib/aimeAgent";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Wallet, Plus, TrendingUp, TrendingDown, Loader2, Receipt } from "lucide-react";
import { useAssociation } from "@/components/AssociationProvider";
import { useToast } from "@/components/ui/use-toast";

export default function BudgetTab({ projectId }) {
  const [budget, setBudget] = useState(null);
  const [lignes, setLignes] = useState([]);
  const [depenses, setDepenses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [addLine, setAddLine] = useState(false);
  const [form, setForm] = useState({ label: "", category: "depense", montant: "" });
  const { toast } = useToast();
  const navigate = useNavigate();
  const { activeAssociationId } = useAssociation();

  async function load() {
    setLoading(true);
    try {
      let budgets = await base44.entities.Budget.filter({ project_id: projectId });
      let b = budgets[0];
      if (!b) b = await base44.entities.Budget.create({ project_id: projectId, name: "Budget projet", association_id: activeAssociationId });
      setBudget(b);
      const ls = await base44.entities.LigneBudgetaire.filter({ budget_id: b.id });
      setLignes(ls);
      const dp = await base44.entities.Depense.filter({ project_id: projectId });
      setDepenses(dp);
    } catch (e) {
      console.error(e);
    }
    setLoading(false);
  }
  useEffect(() => { load(); }, [projectId]);

  async function saveLine() {
    if (!form.label.trim() || !form.montant) return;
    await base44.entities.LigneBudgetaire.create({
      budget_id: budget.id,
      project_id: projectId,
      association_id: activeAssociationId,
      label: form.label,
      category: form.category,
      montant_prevu: Number(form.montant),
      montant_realise: 0
    });
    setForm({ label: "", category: "depense", montant: "" });
    setAddLine(false);
    load();
  }

  async function deleteDepense(d) {
    await base44.entities.Depense.delete(d.id);
    load();
  }

  if (loading) {
    return <div className="flex justify-center py-12"><Loader2 className="w-5 h-5 animate-spin text-muted-foreground" /></div>;
  }

  const recettes = lignes.filter((l) => l.category === "recette");
  const depensesL = lignes.filter((l) => l.category !== "recette");
  const totalPrevu = lignes.reduce((s, l) => s + (l.category === "recette" ? Number(l.montant_prevu) : -Number(l.montant_prevu)), 0);
  const totalRealise = lignes.reduce((s, l) => s + (l.category === "recette" ? Number(l.montant_realise) : -Number(l.montant_realise)), 0);
  const totalDepenses = depenses.reduce((s, d) => s + Number(d.montant), 0);

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <Card className="soft-shadow">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-xs text-muted-foreground"><TrendingUp className="w-3.5 h-3.5 text-sage" />Recettes prévues</div>
            <p className="font-display text-2xl font-semibold mt-1 text-sage">{euro(recettes.reduce((s, l) => s + Number(l.montant_prevu), 0))}</p>
          </CardContent>
        </Card>
        <Card className="soft-shadow">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-xs text-muted-foreground"><TrendingDown className="w-3.5 h-3.5 text-primary" />Dépenses prévues</div>
            <p className="font-display text-2xl font-semibold mt-1 text-primary">{euro(depensesL.reduce((s, l) => s + Number(l.montant_prevu), 0))}</p>
          </CardContent>
        </Card>
        <Card className="soft-shadow">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-xs text-muted-foreground"><Wallet className="w-3.5 h-3.5" />Solde prévu</div>
            <p className="font-display text-2xl font-semibold mt-1 text-foreground">{euro(totalPrevu)}</p>
            <p className="text-xs text-muted-foreground mt-0.5">Réalisé : {euro(totalRealise)}</p>
          </CardContent>
        </Card>
      </div>

      {totalDepenses > 0 && (
        <Button variant="outline" size="sm" onClick={() => navigate("/scan?project=" + projectId)} className="gap-2">
          <Receipt className="w-4 h-4" /> Associer un justificatif
        </Button>
      )}

      <div>
        <div className="flex items-center justify-between mb-3">
          <h4 className="font-display text-base font-medium">Postes budgétaires</h4>
          <Button variant="ghost" size="sm" onClick={() => setAddLine(!addLine)} className="gap-1.5">
            <Plus className="w-4 h-4" /> Ajouter
          </Button>
        </div>

        {addLine && (
          <Card className="soft-shadow mb-3">
            <CardContent className="p-4 space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-1">
                  <Label className="text-xs">Libellé</Label>
                  <Input value={form.label} onChange={(e) => setForm({ ...form, label: e.target.value })} placeholder="Ex. Location salle" />
                </div>
                <div>
                  <Label className="text-xs">Type</Label>
                  <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="depense">Dépense</SelectItem>
                      <SelectItem value="recette">Recette</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs">Montant prévu (€)</Label>
                  <Input type="number" value={form.montant} onChange={(e) => setForm({ ...form, montant: e.target.value })} placeholder="0" />
                </div>
              </div>
              <div className="flex gap-2">
                <Button size="sm" onClick={saveLine}>Enregistrer</Button>
                <Button size="sm" variant="ghost" onClick={() => setAddLine(false)}>Annuler</Button>
              </div>
            </CardContent>
          </Card>
        )}

        {lignes.length === 0 ? (
          <p className="text-sm text-muted-foreground py-6 text-center">Aucun poste budgétaire pour le moment.</p>
        ) : (
          <div className="space-y-2">
            {recettes.map((l) => (
              <BudgetLine key={l.id} line={l} onChange={load} />
            ))}
            {recettes.length > 0 && depensesL.length > 0 && <div className="border-t border-border my-2" />}
            {depensesL.map((l) => (
              <BudgetLine key={l.id} line={l} onChange={load} />
            ))}
          </div>
        )}
      </div>

      {depenses.length > 0 && (
        <div>
          <h4 className="font-display text-base font-medium mb-3 flex items-center gap-2"><Receipt className="w-4 h-4 text-primary" /> Dépenses engagées</h4>
          <div className="space-y-2">
            {depenses.map((d) => (
              <div key={d.id} className="flex items-center justify-between rounded-lg border border-border bg-card px-4 py-2.5">
                <div>
                  <p className="text-sm font-medium">{d.description}</p>
                  <p className="text-xs text-muted-foreground">{d.emetteur || "—"} · {d.date ? new Date(d.date).toLocaleDateString("fr-FR") : ""}</p>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-medium text-sm">{euro(d.montant)}</span>
                  <Badge variant={d.justificatif_id ? "default" : "outline"} className={d.justificatif_id ? "bg-sage text-sage-foreground" : ""}>
                    {d.justificatif_id ? "Justifié" : "À justifier"}
                  </Badge>
                  <button onClick={() => deleteDepense(d)} className="text-muted-foreground/40 hover:text-destructive text-xs">supprimer</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function BudgetLine({ line, onChange }) {
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({ label: line.label, montant_prevu: line.montant_prevu });

  async function save() {
    await base44.entities.LigneBudgetaire.update(line.id, {
      label: form.label,
      montant_prevu: Number(form.montant_prevu) || 0
    });
    setEditing(false);
    onChange();
  }

  async function remove() {
    await base44.entities.LigneBudgetaire.delete(line.id);
    onChange();
  }
  const isRecette = line.category === "recette";
  if (editing) {
    return (
      <div className="flex items-center gap-2 rounded-lg bg-card border border-primary/30 px-3 py-2">
        <span className={"w-2 h-8 rounded-full shrink-0 " + (isRecette ? "bg-sage" : "bg-primary")} />
        <Input value={form.label} onChange={(e) => setForm({ ...form, label: e.target.value })} className="flex-1 h-8" />
        <Input type="number" value={form.montant_prevu} onChange={(e) => setForm({ ...form, montant_prevu: e.target.value })} className="w-28 h-8" />
        <Button size="sm" onClick={save} className="h-8">OK</Button>
        <Button size="sm" variant="ghost" onClick={() => setEditing(false)} className="h-8">Annuler</Button>
      </div>
    );
  }
  return (
    <div className="flex items-center justify-between rounded-lg bg-card border border-border px-4 py-2.5 hover:border-primary/30 transition">
      <div className="flex items-center gap-3">
        <span className={"w-2 h-8 rounded-full " + (isRecette ? "bg-sage" : "bg-primary")} />
        <div>
          <p className="text-sm font-medium">{line.label}</p>
          <p className="text-[11px] uppercase tracking-wide text-muted-foreground">{isRecette ? "Recette" : "Dépense"}</p>
        </div>
      </div>
      <div className="flex items-center gap-4">
        <div className="text-right">
          <p className="text-sm font-semibold">{euro(Number(line.montant_prevu))}</p>
          {Number(line.montant_realise) > 0 && (
            <p className="text-[11px] text-muted-foreground">réel : {euro(Number(line.montant_realise))}</p>
          )}
        </div>
        <button onClick={() => setEditing(true)} className="text-muted-foreground/50 hover:text-primary text-xs">modifier</button>
        <button onClick={remove} className="text-muted-foreground/50 hover:text-destructive text-xs">retirer</button>
      </div>
    </div>
  );
}