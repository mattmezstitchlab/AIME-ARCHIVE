import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { logAction } from "@/lib/aimeAgent";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem
} from "@/components/ui/select";
import { useToast } from "@/components/ui/use-toast";
import { useAssociation } from "@/components/AssociationProvider";
import { Megaphone, Plus, Trash2, Loader2 } from "lucide-react";

export default function CommunicationTab({ project }) {
  const { toast } = useToast();
  const { activeAssociationId } = useAssociation();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ channel: "Affiche", title: "", content: "", date: "" });

  async function load() {
    const docs = await base44.entities.Document.filter({ project_id: project.id });
    setItems(docs.filter((d) => d.type === "presentation" || d.metadata?.comm === true));
  }
  useEffect(() => { load(); }, []);

  async function create() {
    if (!form.title.trim()) return;
    setLoading(true);
    try {
      await base44.entities.Document.create({
        project_id: project.id,
        association_id: activeAssociationId,
        type: "presentation",
        title: form.title,
        content: form.content,
        status: "brouillon",
        metadata: { comm: true, channel: form.channel, date: form.date }
      });
      await logAction("creation_communication", "Document", null, project.id, "Support de communication « " + form.title + " » créé.");
      setForm({ channel: "Affiche", title: "", content: "", date: "" });
      setOpen(false);
      toast({ title: "Support créé" });
      load();
    } catch { toast({ title: "Erreur", variant: "destructive" }); }
    setLoading(false);
  }

  async function remove(id) {
    await base44.entities.Document.delete(id);
    toast({ title: "Support supprimé" });
    load();
  }

  const channels = ["Affiche", "Communiqué de presse", "Réseaux sociaux", "Newsletter", "Invitation", "Flyer"];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">Supports de communication liés au projet.</p>
        <Button size="sm" variant="outline" onClick={() => setOpen(!open)} className="gap-1.5">
          <Plus className="w-4 h-4" /> Nouveau support
        </Button>
      </div>

      {open && (
        <Card className="soft-shadow animate-float-up">
          <CardContent className="p-4 space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <Label className="text-xs">Canal</Label>
                <Select value={form.channel} onValueChange={(v) => setForm({ ...form, channel: v })}>
                  <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {channels.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs">Date de diffusion</Label>
                <Input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} className="mt-1" />
              </div>
            </div>
            <div>
              <Label className="text-xs">Titre</Label>
              <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Ex. Concert solidaire — 15 juin" className="mt-1" />
            </div>
            <div>
              <Label className="text-xs">Message</Label>
              <Textarea value={form.content} onChange={(e) => setForm({ ...form, content: e.target.value })} rows={5}
                placeholder={"Pré-rempli avec les données du projet :\n\n" + project.name + "\n" + (project.description || "") + "\nPublic : " + (project.target_audience || "—") + "\nLieu : " + (project.location || "—")}
                className="mt-1" />
            </div>
            <div className="flex gap-2">
              <Button size="sm" onClick={create} disabled={loading || !form.title.trim()}>
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Enregistrer"}
              </Button>
              <Button size="sm" variant="ghost" onClick={() => setOpen(false)}>Annuler</Button>
            </div>
          </CardContent>
        </Card>
      )}

      {items.length === 0 ? (
        <Card className="soft-shadow">
          <CardContent className="p-8 text-center">
            <Megaphone className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
            <p className="text-sm font-medium">Aucun support de communication</p>
            <p className="text-xs text-muted-foreground mt-1">Créez affiches, communiqués et invitations liés à ce projet.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-2">
          {items.map((d) => (
            <div key={d.id} className="flex items-center justify-between rounded-lg border border-border bg-card px-4 py-3">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <p className="text-sm font-medium">{d.title}</p>
                  <Badge variant="outline" className="font-normal">{d.metadata?.channel || "Support"}</Badge>
                </div>
                <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">{d.content}</p>
              </div>
              <button onClick={() => remove(d.id)} className="p-1.5 rounded-md hover:bg-destructive/10 text-muted-foreground hover:text-destructive">
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}