import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { euro, formatDateShort } from "@/lib/aimeFormats";
import { logAction } from "@/lib/aimeAgent";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Image } from "@/components/ui/image";
import { ScanLine, Plus, Loader2, FileCheck, AlertCircle } from "lucide-react";

const STATUS = {
  en_analyse: { label: "En analyse", cls: "bg-amber-100 text-amber-700" },
  a_confirmer: { label: "À confirmer", cls: "bg-primary/10 text-primary" },
  valide: { label: "Validé", cls: "bg-sage text-sage-foreground" },
  rejete: { label: "Rejeté", cls: "bg-destructive/10 text-destructive" }
};

export default function JustificatifsTab({ projectId }) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  async function load() {
    setLoading(true);
    try {
      const data = await base44.entities.Justificatif.filter({ project_id: projectId });
      data.sort((a, b) => (b.created_date || "").localeCompare(a.created_date || ""));
      setItems(data);
    } catch (e) { console.error(e); }
    setLoading(false);
  }
  useEffect(() => { load(); }, [projectId]);

  async function validate(item) {
    await base44.entities.Justificatif.update(item.id, { status: "valide" });
    await logAction("validation_justificatif", "Justificatif", item.id, projectId, "Justificatif validé.");
    load();
  }

  if (loading) return <div className="flex justify-center py-12"><Loader2 className="w-5 h-5 animate-spin text-muted-foreground" /></div>;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">{items.length} justificatif{items.length > 1 ? "s" : ""}</p>
        <Button size="sm" onClick={() => navigate("/scan?project=" + projectId)} className="gap-1.5">
          <Plus className="w-4 h-4" /> Ajouter
        </Button>
      </div>

      {items.length === 0 ? (
        <div className="rounded-xl border border-dashed border-border py-12 text-center">
          <ScanLine className="w-8 h-8 text-muted-foreground/40 mx-auto mb-3" />
          <p className="text-sm text-muted-foreground">Aucun justificatif pour l'instant.<br />Photographiez une facture et AIME la classera.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {items.map((item) => {
            const st = STATUS[item.status] || STATUS.a_confirmer;
            return (
              <Card key={item.id} className="soft-shadow overflow-hidden">
                <div className="flex">
                  <div className="w-24 h-24 bg-muted shrink-0">
                    <Image src={item.file_url} alt={item.file_name} className="w-full h-full object-cover" />
                  </div>
                  <CardContent className="p-3 flex-1">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <p className="text-sm font-medium truncate">{item.file_name || "Document"}</p>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          {item.document_type} · {formatDateShort(item.date_document)}
                        </p>
                      </div>
                      <Badge className={st.cls}>{st.label}</Badge>
                    </div>
                    <div className="mt-2 flex items-center justify-between">
                      <span className="text-sm font-semibold">{euro(item.montant)}</span>
                      {item.status !== "valide" && (
                        <Button size="sm" variant="outline" onClick={() => validate(item)} className="h-7 gap-1">
                          <FileCheck className="w-3.5 h-3.5" /> Valider
                        </Button>
                      )}
                    </div>
                    {item.emetteur && <p className="text-xs text-muted-foreground mt-1">{item.emetteur}</p>}
                  </CardContent>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}