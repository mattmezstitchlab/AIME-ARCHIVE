import { createContext, useContext, useState, useCallback } from "react";

const Ctx = createContext(null);
export function useProjectNav() { return useContext(Ctx); }

export function ProjectNavProvider({ children }) {
  const [nav, setNav] = useState(null);
  const [active, setActive] = useState("vision");

  const register = useCallback((projectName, sections, defaultActive) => {
    setNav({ projectName, sections });
    setActive(defaultActive || "vision");
  }, []);

  const clear = useCallback(() => {
    setNav(null);
    setActive("vision");
  }, []);

  return (
    <Ctx.Provider value={{ nav, active, setActive, register, clear }}>
      {children}
    </Ctx.Provider>
  );
}