import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function AddDetailsStep({ value, onChange }) {
  const set = (key, next) => onChange({ ...value, [key]: next });
  return (
    <div className="space-y-3">
      <p className="text-sm font-medium">Paramètres avant création</p>
      <div><Label className="text-xs">Titre</Label><Input value={value.title} onChange={e => set("title", e.target.value)} placeholder="Titre de la section" /></div>
      <div><Label className="text-xs">Texte</Label><Textarea value={value.text} onChange={e => set("text", e.target.value)} placeholder="Contenu principal" /></div>
      <div><Label className="text-xs">Image</Label><Input value={value.image} onChange={e => set("image", e.target.value)} placeholder="URL de l’image (optionnel)" /></div>
      <div><Label className="text-xs">Style</Label><Select value={value.background} onValueChange={next => set("background", next)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="none">Neutre</SelectItem><SelectItem value="ivory">Ivoire</SelectItem><SelectItem value="dark">Sombre</SelectItem><SelectItem value="sage">Sauge</SelectItem></SelectContent></Select></div>
    </div>
  );
}