import React, { useState } from "react";
import { Search, Plus } from "lucide-react";
import { BLOCK_CATEGORIES, BLOCK_TYPES } from "@/lib/studioBlocks";
import { ICONS } from "./studioIcons";

export default function BlockLibrary({ onAdd }) {
  const [query, setQuery] = useState("");

  const filtered = Object.entries(BLOCK_TYPES).filter(([, def]) =>
    !query || def.label.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="w-64 border-r border-border bg-card flex flex-col h-full">
      <div className="p-4 border-b border-border">
        <h3 className="text-sm font-semibold mb-3">Ajouter une section</h3>
        <div className="relative">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Rechercher un bloc"
            className="w-full pl-8 pr-3 py-1.5 text-sm rounded-md border border-input bg-transparent"
          />
        </div>
      </div>
      <div className="flex-1 overflow-y-auto p-3 space-y-4">
        {BLOCK_CATEGORIES.map((cat) => {
          const blocks = filtered.filter(([, def]) => def.category === cat.id);
          if (blocks.length === 0) return null;
          return (
            <div key={cat.id}>
              <h4 className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-2 px-1">{cat.label}</h4>
              <div className="space-y-1">
                {blocks.map(([type, def]) => {
                  const Icon = ICONS[def.icon] || ICONS.FileText;
                  return (
                    <button
                      key={type}
                      onClick={() => onAdd(type)}
                      className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-md hover:bg-accent text-sm text-left transition-colors group"
                    >
                      <Icon className="w-4 h-4 text-muted-foreground group-hover:text-foreground" />
                      <span>{def.label}</span>
                      <Plus className="w-3.5 h-3.5 ml-auto text-muted-foreground opacity-0 group-hover:opacity-100" />
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}