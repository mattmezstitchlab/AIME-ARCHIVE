import React from "react";
import { TEMPLATES } from "@/lib/studioBlocks";

export default function TemplateSelector({ onSelect, onSkip }) {
  return (
    <div className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-card border border-border rounded-2xl shadow-lg max-w-3xl w-full p-8">
        <h2 className="text-2xl font-display font-semibold mb-1">Choisissez un modèle</h2>
        <p className="text-sm text-muted-foreground mb-6">Vous pourrez tout modifier ensuite.</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {Object.entries(TEMPLATES).map(([id, tpl]) => (
            <button
              key={id}
              onClick={() => onSelect(id)}
              className="text-left p-5 rounded-xl border border-border hover:border-foreground/30 hover:bg-accent transition-all"
            >
              <h3 className="font-display font-semibold text-lg mb-1">{tpl.label}</h3>
              <p className="text-sm text-muted-foreground">{tpl.description}</p>
              <div className="mt-3 flex flex-wrap gap-1">
                {tpl.sections.map((s, i) => (
                  <span key={i} className="text-xs px-2 py-0.5 rounded-full bg-muted">{s.type}</span>
                ))}
              </div>
            </button>
          ))}
        </div>
        <button onClick={onSkip} className="mt-6 text-sm text-muted-foreground hover:text-foreground">
          Commencer avec une page vide
        </button>
      </div>
    </div>
  );
}