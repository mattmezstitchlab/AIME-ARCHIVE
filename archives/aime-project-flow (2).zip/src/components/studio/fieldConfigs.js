// Field configurations for the PropertiesPanel

export const CONTENT_FIELDS = {
  hero: [
    { key: "title", label: "Nom", type: "text" },
    { key: "text", label: "Phrase personnelle", type: "text" },
    { key: "button", label: "Texte du bouton", type: "text" },
    { key: "image", label: "Image de fond", type: "image" },
  ],
  profile_photo: [{ key: "image", label: "Photo", type: "image" }],
  name: [{ key: "title", label: "Nom", type: "text" }],
  personal_phrase: [{ key: "text", label: "Phrase", type: "text" }],
  presentation: [
    { key: "title", label: "Titre", type: "text" },
    { key: "text", label: "Texte", type: "textarea" },
  ],
  story: [
    { key: "title", label: "Titre", type: "text" },
    { key: "text", label: "Texte", type: "textarea" },
  ],
  memory: [
    { key: "title", label: "Titre", type: "text" },
    { key: "text", label: "Texte", type: "textarea" },
  ],
  testimony: [
    { key: "title", label: "Titre", type: "text" },
    { key: "text", label: "Texte", type: "textarea" },
  ],
  timeline: [
    { key: "title", label: "Titre", type: "text" },
    { key: "items", label: "Événements", type: "list", itemFields: [
      { key: "date", label: "Date", type: "text" },
      { key: "title", label: "Titre", type: "text" },
      { key: "description", label: "Description", type: "textarea" },
    ]},
  ],
  quote: [
    { key: "text", label: "Citation", type: "textarea" },
    { key: "author", label: "Auteur", type: "text" },
  ],
  skills: [
    { key: "title", label: "Titre", type: "text" },
    { key: "items", label: "Compétences", type: "list", itemFields: [
      { key: "label", label: "Nom", type: "text" },
    ]},
  ],
  transmission: [
    { key: "title", label: "Titre", type: "text" },
    { key: "items", label: "Éléments", type: "list", itemFields: [
      { key: "label", label: "Nom", type: "text" },
      { key: "description", label: "Description", type: "text" },
    ]},
  ],
  passions: [
    { key: "title", label: "Titre", type: "text" },
    { key: "items", label: "Passions", type: "list", itemFields: [
      { key: "label", label: "Nom", type: "text" },
    ]},
  ],
  experiences: [
    { key: "title", label: "Titre", type: "text" },
    { key: "items", label: "Expériences", type: "list", itemFields: [
      { key: "role", label: "Rôle", type: "text" },
      { key: "organization", label: "Organisation", type: "text" },
      { key: "period", label: "Période", type: "text" },
      { key: "description", label: "Description", type: "textarea" },
    ]},
  ],
  project: [
    { key: "title", label: "Titre", type: "text" },
    { key: "text", label: "Description", type: "textarea" },
    { key: "image", label: "Image", type: "image" },
    { key: "link", label: "Lien", type: "text" },
  ],
  gallery: [
    { key: "title", label: "Titre", type: "text" },
    { key: "items", label: "Images", type: "list", itemFields: [
      { key: "image", label: "Image", type: "image" },
      { key: "caption", label: "Légende", type: "text" },
    ]},
  ],
  image: [
    { key: "image", label: "Image", type: "image" },
    { key: "caption", label: "Légende", type: "text" },
  ],
  video: [
    { key: "title", label: "Titre", type: "text" },
    { key: "url", label: "URL (YouTube, Vimeo ou directe)", type: "text" },
  ],
  audio: [
    { key: "title", label: "Titre", type: "text" },
    { key: "url", label: "URL audio", type: "text" },
  ],
  document: [
    { key: "url", label: "URL du document", type: "text" },
    { key: "label", label: "Libellé", type: "text" },
  ],
  links: [
    { key: "title", label: "Titre", type: "text" },
    { key: "items", label: "Liens", type: "list", itemFields: [
      { key: "label", label: "Libellé", type: "text" },
      { key: "url", label: "URL", type: "text" },
    ]},
  ],
  social: [
    { key: "items", label: "Réseaux", type: "list", itemFields: [
      { key: "platform", label: "Plateforme", type: "text" },
      { key: "url", label: "URL", type: "text" },
    ]},
  ],
  contact: [
    { key: "title", label: "Titre", type: "text" },
    { key: "text", label: "Texte", type: "textarea" },
    { key: "email", label: "Email", type: "text" },
    { key: "phone", label: "Téléphone", type: "text" },
  ],
  custom_button: [
    { key: "label", label: "Texte du bouton", type: "text" },
    { key: "link", label: "Lien", type: "text" },
  ],
  associations_supported: [
    { key: "title", label: "Titre", type: "text" },
    { key: "items", label: "Associations", type: "list", itemFields: [
      { key: "label", label: "Nom", type: "text" },
      { key: "description", label: "Description", type: "text" },
    ]},
  ],
  engagements: [
    { key: "title", label: "Titre", type: "text" },
    { key: "items", label: "Engagements", type: "list", itemFields: [
      { key: "label", label: "Nom", type: "text" },
      { key: "description", label: "Description", type: "text" },
    ]},
  ],
  events: [
    { key: "title", label: "Titre", type: "text" },
    { key: "items", label: "Événements", type: "list", itemFields: [
      { key: "label", label: "Nom", type: "text" },
      { key: "date", label: "Date", type: "text" },
      { key: "location", label: "Lieu", type: "text" },
    ]},
  ],
  contributions: [
    { key: "title", label: "Titre", type: "text" },
    { key: "items", label: "Contributions", type: "list", itemFields: [
      { key: "label", label: "Nom", type: "text" },
      { key: "description", label: "Description", type: "text" },
    ]},
  ],
  hero_wedding: [
    { key: "title", label: "Titre", type: "text" }, { key: "text", label: "Sous-titre", type: "text" },
    { key: "button", label: "Bouton", type: "text" }, { key: "image", label: "Image", type: "image" },
  ],
  our_story: [{ key: "title", label: "Titre", type: "text" }, { key: "text", label: "Histoire", type: "textarea" }],
  practical_info: [{ key: "title", label: "Titre", type: "text" }, { key: "text", label: "Introduction", type: "textarea" }, { key: "items", label: "Informations", type: "list", itemFields: [{ key: "label", label: "Nom", type: "text" }, { key: "value", label: "Détail", type: "text" }] }],
  program: [{ key: "title", label: "Titre", type: "text" }, { key: "text", label: "Introduction", type: "textarea" }, { key: "items", label: "Étapes", type: "list", itemFields: [{ key: "time", label: "Heure", type: "text" }, { key: "title", label: "Moment", type: "text" }] }],
  rsvp: [{ key: "title", label: "Titre", type: "text" }, { key: "text", label: "Texte", type: "textarea" }],
  guestbook: [{ key: "title", label: "Titre", type: "text" }, { key: "text", label: "Texte", type: "textarea" }],
  contribution: [{ key: "title", label: "Titre", type: "text" }, { key: "text", label: "Texte", type: "textarea" }],
};

export const STYLE_FIELDS = [
  { key: "width", label: "Largeur", type: "select", options: [
    { value: "narrow", label: "Étroite" },
    { value: "normal", label: "Normale" },
    { value: "wide", label: "Large" },
    { value: "full", label: "Plein écran" },
  ]},
  { key: "align", label: "Alignement", type: "select", options: [
    { value: "left", label: "Gauche" },
    { value: "center", label: "Centre" },
    { value: "right", label: "Droite" },
  ]},
  { key: "padding", label: "Espacement", type: "select", options: [
    { value: "compact", label: "Compact" },
    { value: "normal", label: "Normal" },
    { value: "spacious", label: "Spacieux" },
  ]},
  { key: "background", label: "Fond", type: "select", options: [
    { value: "none", label: "Aucun" },
    { value: "ivory", label: "Ivoire" },
    { value: "dark", label: "Sombre" },
    { value: "sage", label: "Sauge" },
    { value: "sand", label: "Sable" },
  ]},
];

export const HERO_LAYOUT_FIELD = {
  key: "layout", label: "Mise en page", type: "select", options: [
    { value: "fullscreen", label: "Plein écran" },
    { value: "image_left", label: "Image à gauche" },
    { value: "image_right", label: "Image à droite" },
    { value: "minimal", label: "Minimal" },
  ],
};