import { BLOCK_TYPES } from "@/lib/studioBlocks";
import { ICONS } from "./studioIcons";

export default function AddTypeStep({ types, value, onChange }) {
  return (
    <div className="space-y-3">
      <div><p className="text-sm font-medium">Vous pourriez ajouter</p><p className="text-xs text-muted-foreground">Suggestions selon votre projet, la position et la structure existante.</p></div>
      <div className="grid grid-cols-2 gap-2">
        {types.map(type => {
          const def = BLOCK_TYPES[type];
          const Icon = ICONS[def?.icon] || ICONS.FileText;
          return <button key={type} onClick={() => onChange(type)} className={`flex items-center gap-2 p-3 rounded-xl border text-sm text-left ${value === type ? "border-primary bg-accent" : "border-border hover:bg-accent"}`}><Icon className="w-4 h-4" />{def?.label || type}</button>;
        })}
      </div>
    </div>
  );
}