import React from "react";
import { Image } from "@/components/ui/image";
import { ICONS } from "./studioIcons";

const BG = {
  none: "", ivory: "bg-amber-50/40", dark: "bg-foreground text-background",
  sage: "bg-emerald-50/50", sand: "bg-stone-100",
};
const ALIGN = { left: "text-left items-start", center: "text-center items-center", right: "text-right items-end" };
const PAD = { compact: "py-8", normal: "py-14", spacious: "py-24" };
const WIDTH = { narrow: "max-w-2xl", normal: "max-w-4xl", wide: "max-w-6xl", full: "max-w-full" };
const FONT = { editorial: "font-serif", modern: "font-heading", luxury: "font-serif", creative: "font-display", minimal: "font-body" };

function Container({ style, children, className }) {
  const s = style || {};
  const theme = s.paletteColors ? { backgroundColor: s.paletteColors.background, color: s.paletteColors.text, "--section-accent": s.paletteColors.accent, "--section-card": s.paletteColors.card } : undefined;
  return (
    <div style={theme} className={`w-full ${BG[s.background || "none"]} ${PAD[s.padding || "normal"]} ${FONT[s.typography] || "font-body"}`}>
      <div className={`mx-auto px-6 ${WIDTH[s.width || "normal"]} flex flex-col ${ALIGN[s.align || "left"]} gap-4 ${className || ""}`}>
        {children}
      </div>
    </div>
  );
}

function Img({ src, alt, className, rounded, style, fittingType = "fit" }) {
  if (!src) return <div className={`bg-muted border border-dashed border-border flex items-center justify-center text-muted-foreground text-xs ${className || ""} ${rounded || ""}`}>Image</div>;
  return <Image src={src} alt={alt || ""} className={className} fittingType={fittingType} style={style} />;
}

export default function BlockRenderer({ section, isEditing, onUpdate, selected, onSelect }) {
  const { type, content: c, style: s } = section;
  const sc = s || {};
  const edit = isEditing && onUpdate;
  const set = (key, val) => edit({ content: { ...c, [key]: val } });
  const setStyle = (key, val) => edit({ style: { ...sc, [key]: val } });
  const imagePosition = sc.imageX !== undefined ? `${sc.imageX}% ${sc.imageY ?? 50}%` : (sc.imagePosition || "center");
  const imageCss = {
    objectPosition: imagePosition,
    filter: `brightness(${sc.brightness ?? 100}%) contrast(${sc.contrast ?? 100}%) saturate(${sc.saturation ?? 100}%) blur(${sc.blur ?? 0}px)`,
    opacity: (sc.opacity ?? 100) / 100,
    transform: `scale(${(sc.imageZoom ?? 100) / 100})`,
  };

  const Editable = ({ field, className, as: Tag = "div", placeholder }) => {
    const val = c[field] || "";
    if (!edit) return val ? <Tag className={className}>{val}</Tag> : null;
    return (
      <Tag
        contentEditable
        suppressContentEditableWarning
        onBlur={(e) => set(field, e.target.innerText)}
        className={`${className} outline-none focus:ring-2 focus:ring-ring/30 rounded px-1 -mx-1`}
        data-placeholder={placeholder}
      >{val}</Tag>
    );
  };

  const renderBlock = () => {
    switch (type) {
      case "hero_wedding":
      case "hero": {
        const layout = sc.layout || "fullscreen";
        if (layout === "image_left" || layout === "image_right") {
          return (
            <div className={`flex ${layout === "image_right" ? "flex-row-reverse" : ""} gap-8 items-center flex-wrap`}>
              <div className="flex-1 min-w-[200px] flex flex-col gap-3">
                <Editable field="title" as="h1" className="text-4xl font-display font-bold" placeholder="Votre nom" />
                <Editable field="text" as="p" className="text-lg text-muted-foreground" placeholder="Votre phrase" />
                {c.button && <span className="inline-block mt-2 px-5 py-2.5 rounded-full bg-foreground text-background text-sm font-medium">{c.button}</span>}
              </div>
              <div className="flex-1 min-w-[200px]"><Img src={c.image} className="aspect-[4/3] w-full rounded-xl" /></div>
            </div>
          );
        }
        const backgroundMode = c.image && ["background", "hero_background"].includes(sc.imageMode);
        return (
          <div className={`relative flex flex-col gap-4 py-8 overflow-hidden ${sc.imageMode === "hero_background" ? "min-h-screen justify-center" : ""}`} style={backgroundMode ? { backgroundImage: `url(${c.image})`, backgroundSize: `${sc.imageZoom ?? 100}%`, backgroundPosition: imagePosition, backgroundRepeat: "no-repeat" } : undefined}>
            {backgroundMode && <div className="absolute inset-0" style={{ backgroundColor: sc.overlayColor || "#000000", opacity: 0.45 }} />}
            {!backgroundMode && c.image && <Img src={c.image} className={`w-full mb-2 overflow-hidden ${sc.imageMode === "mask" ? "aspect-square rounded-full max-w-md" : sc.imageMode === "floating" ? "aspect-[4/3] rounded-3xl max-w-lg shadow-xl" : "aspect-[16/9] rounded-2xl"}`} style={imageCss} fittingType={sc.imageMode === "full_width" ? "fill" : "fit"} />}
            <Editable field="title" as="h1" className={`relative text-5xl font-display font-bold ${backgroundMode ? "text-white" : ""}`} placeholder="Votre nom" />
            <Editable field="text" as="p" className={`relative text-xl ${backgroundMode ? "text-white/80" : "text-muted-foreground"}`} placeholder="Votre phrase personnelle" />
            {c.button && <span className="relative inline-block mt-2 px-6 py-3 rounded-full bg-foreground text-background text-sm font-medium">{c.button}</span>}
          </div>
        );
      }
      case "profile_photo":
        return <Img src={c.image} className="w-32 h-32 rounded-full mx-auto" rounded="rounded-full" />;
      case "name":
        return <Editable field="title" as="h1" className="text-4xl font-display font-bold" placeholder="Votre nom" />;
      case "personal_phrase":
        return <Editable field="text" as="p" className="text-xl italic text-muted-foreground" placeholder="Votre phrase" />;
      case "presentation":
      case "story":
      case "our_story":
      case "memory":
      case "testimony":
      case "rsvp":
      case "guestbook":
      case "contribution":
        return (
          <>
            <Editable field="title" as="h2" className="text-2xl font-display font-semibold" placeholder="Titre" />
            <Editable field="text" as="p" className="text-base text-muted-foreground leading-relaxed" placeholder="Votre texte" />
          </>
        );
      case "timeline":
        return (
          <>
            <Editable field="title" as="h2" className="text-2xl font-display font-semibold" placeholder="Timeline" />
            <div className="w-full border-l-2 border-border pl-4 flex flex-col gap-4">
              {(c.items || []).map((item, i) => (
                <div key={i} className="flex flex-col gap-1">
                  <span className="text-xs text-muted-foreground">{item.date}</span>
                  <span className="font-medium">{item.title}</span>
                  <span className="text-sm text-muted-foreground">{item.description}</span>
                </div>
              ))}
              {(!c.items || c.items.length === 0) && <span className="text-sm text-muted-foreground">Ajoutez des événements</span>}
            </div>
          </>
        );
      case "quote":
        return (
          <div className="flex flex-col gap-2">
            <Editable field="text" as="blockquote" className="text-2xl italic font-display" placeholder="Votre citation" />
            <Editable field="author" as="cite" className="text-sm text-muted-foreground not-italic" placeholder="Auteur" />
          </div>
        );
      case "skills":
      case "transmission":
      case "passions":
        return (
          <>
            <Editable field="title" as="h2" className="text-2xl font-display font-semibold" placeholder="Titre" />
            <div className="flex flex-wrap gap-2">
              {(c.items || []).map((item, i) => (
                <span key={i} className="px-3 py-1.5 rounded-full bg-muted text-sm">{item.label}</span>
              ))}
              {(!c.items || c.items.length === 0) && <span className="text-sm text-muted-foreground">Ajoutez des éléments</span>}
            </div>
          </>
        );
      case "experiences":
        return (
          <>
            <Editable field="title" as="h2" className="text-2xl font-display font-semibold" placeholder="Titre" />
            <div className="w-full flex flex-col gap-4">
              {(c.items || []).map((item, i) => (
                <div key={i} className="flex flex-col gap-0.5">
                  <span className="font-medium">{item.role}</span>
                  <span className="text-sm text-muted-foreground">{item.organization} {item.period ? `· ${item.period}` : ""}</span>
                  {item.description && <span className="text-sm text-muted-foreground">{item.description}</span>}
                </div>
              ))}
              {(!c.items || c.items.length === 0) && <span className="text-sm text-muted-foreground">Ajoutez des expériences</span>}
            </div>
          </>
        );
      case "project":
        return (
          <div className="flex flex-col gap-3">
            <Editable field="title" as="h2" className="text-2xl font-display font-semibold" placeholder="Titre du projet" />
            {c.image && <Img src={c.image} className="aspect-video w-full rounded-xl" />}
            <Editable field="text" as="p" className="text-muted-foreground" placeholder="Description" />
            {c.link && <span className="text-sm text-primary underline">{c.link}</span>}
          </div>
        );
      case "gallery": {
        const galleryClass = sc.variant === "slider" ? "flex overflow-x-auto snap-x" : sc.variant === "masonry" ? "columns-2 md:columns-3" : "grid grid-cols-2 md:grid-cols-3";
        return (
          <>
            <Editable field="title" as="h2" className="text-2xl font-display font-semibold" placeholder="Galerie" />
            <div className={`${galleryClass} gap-3 w-full`}>
              {(c.items || []).map((item, i) => (
                <div key={i} className="flex flex-col gap-1">
                  <Img src={item.image} className="aspect-square w-full rounded-lg" />
                  {item.caption && <span className="text-xs text-muted-foreground text-center">{item.caption}</span>}
                </div>
              ))}
              {(!c.items || c.items.length === 0) && <span className="text-sm text-muted-foreground">Ajoutez des images</span>}
            </div>
          </>
        );
      }
      case "image":
        return (
          <div className={`w-full flex flex-col gap-2 overflow-hidden ${sc.imageMode === "floating" ? "max-w-lg mx-auto shadow-xl rounded-3xl" : ""}`}>
            <Img src={c.image} className={`w-full ${sc.imageMode === "mask" ? "aspect-square rounded-full" : "aspect-video rounded-xl"}`} style={imageCss} fittingType={sc.imageMode === "full_width" ? "fill" : "fit"} />
            {c.caption && <span className="text-sm text-muted-foreground text-center">{c.caption}</span>}
          </div>
        );
      case "video":
        return (
          <div className="w-full flex flex-col gap-2">
            <Editable field="title" as="h2" className="text-2xl font-display font-semibold" placeholder="Titre" />
            {c.url ? (
              <div className="aspect-video w-full rounded-xl overflow-hidden bg-black">
                {c.url.includes("youtube") || c.url.includes("vimeo") ? (
                  <iframe src={c.url} className="w-full h-full" allowFullScreen />
                ) : (
                  <video src={c.url} controls className="w-full h-full" />
                )}
              </div>
            ) : (
              <div className="aspect-video w-full rounded-xl bg-muted flex items-center justify-center text-muted-foreground text-sm">Vidéo</div>
            )}
          </div>
        );
      case "audio":
        return (
          <div className="w-full flex flex-col gap-2">
            <Editable field="title" as="h2" className="text-2xl font-display font-semibold" placeholder="Titre" />
            {c.url ? <audio src={c.url} controls className="w-full" /> : <div className="p-4 rounded-lg bg-muted text-sm text-muted-foreground text-center">Audio</div>}
          </div>
        );
      case "document":
        return (
          <a href={c.url} className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg border border-border hover:bg-accent text-sm">
            <ICONS.FileText className="w-4 h-4" />
            {c.label || "Document"}
          </a>
        );
      case "links":
        return (
          <>
            <Editable field="title" as="h2" className="text-2xl font-display font-semibold" placeholder="Liens" />
            <div className="flex flex-col gap-2 w-full">
              {(c.items || []).map((item, i) => (
                <a key={i} href={item.url} className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg border border-border hover:bg-accent text-sm">
                  <ICONS.Link className="w-4 h-4" /> {item.label}
                </a>
              ))}
              {(!c.items || c.items.length === 0) && <span className="text-sm text-muted-foreground">Ajoutez des liens</span>}
            </div>
          </>
        );
      case "social":
        return (
          <div className="flex gap-3">
            {(c.items || []).map((item, i) => (
              <a key={i} href={item.url} className="w-10 h-10 rounded-full bg-muted flex items-center justify-center hover:bg-accent">
                <ICONS.Share2 className="w-4 h-4" />
              </a>
            ))}
            {(!c.items || c.items.length === 0) && <span className="text-sm text-muted-foreground">Ajoutez vos réseaux</span>}
          </div>
        );
      case "contact":
        return (
          <div className="flex flex-col gap-2 w-full">
            <Editable field="title" as="h2" className="text-2xl font-display font-semibold" placeholder="Contact" />
            <Editable field="text" as="p" className="text-muted-foreground" placeholder="Texte" />
            {c.email && <a href={`mailto:${c.email}`} className="text-sm text-primary underline">{c.email}</a>}
            {c.phone && <span className="text-sm">{c.phone}</span>}
          </div>
        );
      case "custom_button":
        return (
          <span className="inline-block px-6 py-3 rounded-full bg-foreground text-background text-sm font-medium">
            {c.label || "Bouton"}
          </span>
        );
      case "associations_supported":
      case "engagements":
      case "contributions":
        return (
          <>
            <Editable field="title" as="h2" className="text-2xl font-display font-semibold" placeholder="Titre" />
            <div className="w-full flex flex-col gap-3">
              {(c.items || []).map((item, i) => (
                <div key={i} className="flex flex-col gap-0.5">
                  <span className="font-medium">{item.label}</span>
                  {item.description && <span className="text-sm text-muted-foreground">{item.description}</span>}
                </div>
              ))}
              {(!c.items || c.items.length === 0) && <span className="text-sm text-muted-foreground">Ajoutez des éléments</span>}
            </div>
          </>
        );
      case "practical_info":
      case "program":
        return (
          <>
            <Editable field="title" as="h2" className="text-2xl font-display font-semibold" placeholder="Titre" />
            <Editable field="text" as="p" className="text-muted-foreground" placeholder="Introduction" />
            <div className="grid w-full gap-3 md:grid-cols-2">{(c.items || []).map((item, i) => <div key={i} className="rounded-xl border border-border p-4"><p className="font-medium">{item.time || item.label}</p><p className="text-sm text-muted-foreground">{item.title || item.value || item.description}</p></div>)}{(!c.items || c.items.length === 0) && <span className="text-sm text-muted-foreground">Ajoutez des informations</span>}</div>
          </>
        );
      case "events":
        return (
          <>
            <Editable field="title" as="h2" className="text-2xl font-display font-semibold" placeholder="Événements" />
            <div className="w-full flex flex-col gap-3">
              {(c.items || []).map((item, i) => (
                <div key={i} className="flex flex-col gap-0.5">
                  <span className="font-medium">{item.label}</span>
                  <span className="text-sm text-muted-foreground">{item.date} {item.location ? `· ${item.location}` : ""}</span>
                </div>
              ))}
              {(!c.items || c.items.length === 0) && <span className="text-sm text-muted-foreground">Ajoutez des événements</span>}
            </div>
          </>
        );
      default:
        return <div className="text-sm text-muted-foreground">Bloc: {type}</div>;
    }
  };

  return (
    <div
      onClick={edit ? (e) => { e.stopPropagation(); onSelect(); } : undefined}
      className={`relative cursor-${edit ? "pointer" : "default"} ${selected ? "ring-2 ring-ring" : ""}`}
    >
      <Container style={sc}>{renderBlock()}</Container>
    </div>
  );
}