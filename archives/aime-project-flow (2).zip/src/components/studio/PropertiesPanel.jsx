import React, { useState } from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { Plus, Trash2, Upload, Eye, EyeOff } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { BLOCK_TYPES } from "@/lib/studioBlocks";
import { Image } from "@/components/ui/image";
import ImageSettings from "./ImageSettings";
import { CONTENT_FIELDS, STYLE_FIELDS, HERO_LAYOUT_FIELD } from "./fieldConfigs";

function ImageField({ value, onChange }) {
  const [uploading, setUploading] = useState(false);
  const handleUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      onChange(file_url);
    } catch (err) {
      console.error(err);
    }
    setUploading(false);
  };
  return (
    <div className="space-y-1.5">
      {value && <Image src={value} alt="Aperçu" className="w-full h-20 rounded-md border border-border" fittingType="fit" />}
      <div className="flex gap-1.5">
        <Input value={value || ""} onChange={(e) => onChange(e.target.value)} placeholder="URL ou importer" className="text-xs h-8" />
        <Label className="shrink-0 cursor-pointer">
          <div className="h-8 px-2.5 flex items-center gap-1 rounded-md border border-input text-xs hover:bg-accent">
            {uploading ? "..." : <><Upload className="w-3 h-3" /> Importer</>}
          </div>
          <input type="file" accept="image/*" className="hidden" onChange={handleUpload} disabled={uploading} />
        </Label>
      </div>
    </div>
  );
}

function ListEditor({ items, itemFields, onChange }) {
  const update = (i, key, val) => {
    const next = [...(items || [])];
    next[i] = { ...next[i], [key]: val };
    onChange(next);
  };
  const add = () => onChange([...(items || []), {}]);
  const remove = (i) => onChange((items || []).filter((_, idx) => idx !== i));

  return (
    <div className="space-y-2">
      {(items || []).map((item, i) => (
        <div key={i} className="p-2 rounded-md border border-border space-y-1.5 bg-muted/30">
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground">#{i + 1}</span>
            <button onClick={() => remove(i)} className="text-muted-foreground hover:text-destructive">
              <Trash2 className="w-3 h-3" />
            </button>
          </div>
          {itemFields.map((f) => (
            <div key={f.key}>
              <Label className="text-xs mb-0.5 block">{f.label}</Label>
              {f.type === "textarea" ? (
                <Textarea value={item[f.key] || ""} onChange={(e) => update(i, f.key, e.target.value)} className="text-xs min-h-[40px]" />
              ) : f.type === "image" ? (
                <ImageField value={item[f.key]} onChange={(v) => update(i, f.key, v)} />
              ) : (
                <Input value={item[f.key] || ""} onChange={(e) => update(i, f.key, e.target.value)} className="text-xs h-8" />
              )}
            </div>
          ))}
        </div>
      ))}
      <Button variant="outline" size="sm" onClick={add} className="w-full text-xs h-8">
        <Plus className="w-3 h-3" /> Ajouter
      </Button>
    </div>
  );
}

function FieldInput({ field, value, onChange }) {
  if (field.type === "text") {
    return <Input value={value || ""} onChange={(e) => onChange(e.target.value)} className="text-sm h-9" />;
  }
  if (field.type === "textarea") {
    return <Textarea value={value || ""} onChange={(e) => onChange(e.target.value)} className="text-sm min-h-[80px]" />;
  }
  if (field.type === "image") {
    return <ImageField value={value} onChange={onChange} />;
  }
  if (field.type === "select") {
    return (
      <Select value={value || ""} onValueChange={onChange}>
        <SelectTrigger className="h-9 text-sm"><SelectValue placeholder="Choisir" /></SelectTrigger>
        <SelectContent>
          {field.options.map((opt) => (
            <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
          ))}
        </SelectContent>
      </Select>
    );
  }
  if (field.type === "list") {
    return <ListEditor items={value || []} itemFields={field.itemFields} onChange={onChange} />;
  }
  return null;
}

function Group({ title, children }) {
  return (
    <div className="space-y-3">
      <h4 className="text-xs font-medium text-muted-foreground uppercase tracking-wide">{title}</h4>
      {children}
    </div>
  );
}

export default function PropertiesPanel({ section, onUpdate, onDelete }) {
  if (!section) {
    return (
      <div className="hidden lg:flex w-72 border-l border-border bg-card items-center justify-center p-6 text-center">
        <p className="text-sm text-muted-foreground">Sélectionnez une section pour la modifier.</p>
      </div>
    );
  }

  const def = BLOCK_TYPES[section.type] || {};
  const contentFields = CONTENT_FIELDS[section.type] || [];
  const styleFields = ["hero", "hero_wedding"].includes(section.type) ? [HERO_LAYOUT_FIELD, ...STYLE_FIELDS] : STYLE_FIELDS;
  const c = section.content || {};
  const s = section.style || {};

  const setContent = (key, val) => onUpdate({ content: { ...c, [key]: val } });
  const setStyle = (key, val) => onUpdate({ style: { ...s, [key]: val } });

  return (
    <div className="hidden lg:flex w-72 border-l border-border bg-card flex-col h-full">
      <div className="p-4 border-b border-border">
        <h3 className="text-sm font-semibold">{def.label || section.type}</h3>
      </div>
      <div className="flex-1 overflow-y-auto p-4 space-y-5">
        <Group title="Contenu">
          {contentFields.map((field) => (
            <div key={field.key}>
              <Label className="text-xs mb-1 block">{field.label}</Label>
              <FieldInput field={field} value={c[field.key]} onChange={(v) => setContent(field.key, v)} />
            </div>
          ))}
          {contentFields.length === 0 && <p className="text-xs text-muted-foreground">Aucun champ de contenu.</p>}
        </Group>
        {contentFields.some(field => field.type === "image") && (
          <Group title="Image Settings">
            <ImageSettings style={s} onChange={(nextStyle) => onUpdate({ style: nextStyle })} />
          </Group>
        )}
        <Group title="Mise en page">
          {styleFields.map((field) => (
            <div key={field.key}>
              <Label className="text-xs mb-1 block">{field.label}</Label>
              <FieldInput field={field} value={s[field.key]} onChange={(v) => setStyle(field.key, v)} />
            </div>
          ))}
        </Group>
        <Group title="Visibilité">
          <div>
            <Label className="text-xs mb-1 block">Accès</Label>
            <Select value={section.visibility || "public"} onValueChange={(v) => onUpdate({ visibility: v })}>
              <SelectTrigger className="h-9 text-sm"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="public">Public</SelectItem>
                <SelectItem value="members">Membres AIME</SelectItem>
                <SelectItem value="private">Privé</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-center justify-between">
            <Label className="text-xs">{section.hidden ? "Masqué" : "Visible"}</Label>
            <Button variant="outline" size="sm" onClick={() => onUpdate({ hidden: !section.hidden })} className="h-8 text-xs gap-1.5">
              {section.hidden ? <><Eye className="w-3 h-3" /> Afficher</> : <><EyeOff className="w-3 h-3" /> Masquer</>}
            </Button>
          </div>
        </Group>
      </div>
      <div className="p-4 border-t border-border">
        <Button variant="destructive" size="sm" onClick={onDelete} className="w-full">
          <Trash2 className="w-3.5 h-3.5" /> Supprimer la section
        </Button>
      </div>
    </div>
  );
}