import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Check, X, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function PageSettingsDialog({ page, open, onClose, onSave }) {
  const [form, setForm] = useState({});
  const [checking, setChecking] = useState(false);
  const [available, setAvailable] = useState(null);

  useEffect(() => {
    if (page) setForm({ username: page.username || "", title: page.title || "", description: page.description || "", seoTitle: page.seoTitle || "", seoDescription: page.seoDescription || "", socialImage: page.socialImage || "" });
  }, [page]);

  useEffect(() => {
    if (!form.username || form.username === page?.username) { setAvailable(null); return; }
    setChecking(true);
    const t = setTimeout(async () => {
      try {
        const res = await base44.functions.invoke("checkUsername", { username: form.username, excludePageId: page?.id });
        setAvailable(res.data.available);
      } catch { setAvailable(null); }
      setChecking(false);
    }, 500);
    return () => clearTimeout(t);
  }, [form.username, page]);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSave = () => {
    onSave(form);
    onClose();
  };

  const slug = (form.username || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9-]/g, "");

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Paramètres de la page</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 max-h-[60vh] overflow-y-auto">
          <div>
            <Label className="text-sm mb-1 block">Identifiant public (URL)</Label>
            <div className="flex items-center gap-2">
              <div className="flex items-center flex-1 rounded-md border border-input overflow-hidden">
                <span className="px-2.5 py-2 text-sm text-muted-foreground bg-muted">aime.world/@</span>
                <input value={form.username || ""} onChange={(e) => set("username", e.target.value)} className="flex-1 px-2.5 py-2 text-sm bg-transparent outline-none" placeholder="prenom-nom" />
              </div>
              {checking ? <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" /> :
                available === true ? <Check className="w-4 h-4 text-emerald-500" /> :
                available === false ? <X className="w-4 h-4 text-destructive" /> : null}
            </div>
            {available === false && <p className="text-xs text-destructive mt-1">Cet identifiant est déjà pris.</p>}
            {slug !== (form.username || "") && <p className="text-xs text-muted-foreground mt-1">Sera normalisé: {slug || "..."}</p>}
          </div>
          <div>
            <Label className="text-sm mb-1 block">Titre de la page</Label>
            <Input value={form.title || ""} onChange={(e) => set("title", e.target.value)} placeholder="Marie Dupont" />
          </div>
          <div>
            <Label className="text-sm mb-1 block">Description courte</Label>
            <Textarea value={form.description || ""} onChange={(e) => set("description", e.target.value)} placeholder="Transmettre ce que la vie m'a appris." className="min-h-[60px]" />
          </div>
          <div className="pt-2 border-t border-border">
            <h4 className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-3">Référencement (SEO)</h4>
            <div className="space-y-3">
              <div>
                <Label className="text-sm mb-1 block">Titre SEO</Label>
                <Input value={form.seoTitle || ""} onChange={(e) => set("seoTitle", e.target.value)} placeholder="Titre pour les moteurs de recherche" />
              </div>
              <div>
                <Label className="text-sm mb-1 block">Description SEO</Label>
                <Textarea value={form.seoDescription || ""} onChange={(e) => set("seoDescription", e.target.value)} className="min-h-[60px]" />
              </div>
              <div>
                <Label className="text-sm mb-1 block">Image de partage</Label>
                <Input value={form.socialImage || ""} onChange={(e) => set("socialImage", e.target.value)} placeholder="URL de l'image" />
              </div>
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Annuler</Button>
          <Button onClick={handleSave} disabled={available === false}>Enregistrer</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}