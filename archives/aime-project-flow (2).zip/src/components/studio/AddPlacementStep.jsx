import { BLOCK_TYPES } from "@/lib/studioBlocks";

export default function AddPlacementStep({ sections, value, onChange }) {
  const name = section => BLOCK_TYPES[section.type]?.label || section.type;
  const options = [{ index: 0, label: sections.length ? `Avant ${name(sections[0])}` : "Première section" }];
  sections.forEach((section, index) => options.push({ index: index + 1, label: index === sections.length - 1 ? "Dernière section" : `Après ${name(section)}` }));
  return (
    <div className="space-y-3">
      <p className="text-sm font-medium">Où souhaitez-vous placer cette section ?</p>
      <div className="rounded-xl border border-border p-2 space-y-1 max-h-64 overflow-y-auto">
        {options.map(option => <button key={`${option.index}-${option.label}`} onClick={() => onChange(option.index)} className={`w-full px-3 py-2 rounded-lg text-sm text-left ${value === option.index ? "bg-primary text-primary-foreground" : "hover:bg-accent"}`}>{option.label}</button>)}
      </div>
    </div>
  );
}