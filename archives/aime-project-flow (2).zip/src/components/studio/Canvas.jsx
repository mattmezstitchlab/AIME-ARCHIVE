import React from "react";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import { GripVertical, Copy, Eye, EyeOff, Trash2, Plus } from "lucide-react";
import BlockRenderer from "./BlockRenderer";
import { BLOCK_TYPES, BLOCK_CATEGORIES, createSection } from "@/lib/studioBlocks";
import { ICONS } from "./studioIcons";

const DEVICE_WIDTH = {
  desktop: "w-full max-w-4xl",
  tablet: "w-[768px] max-w-full",
  mobile: "w-[375px] max-w-full",
};

function SectionCard({ section, index, selected, onSelect, onDuplicate, onDelete, onToggleHidden }) {
  const def = BLOCK_TYPES[section.type] || {};
  const Icon = ICONS[def.icon] || ICONS.FileText;
  return (
    <Draggable draggableId={section.id} index={index}>
      {(provided) => (
        <div ref={provided.innerRef} {...provided.draggableProps}>
          <div className={`group relative border-2 transition-colors ${selected ? "border-foreground" : "border-transparent hover:border-border"}`}>
            {/* Toolbar */}
            <div className={`absolute top-0 left-0 right-0 z-10 flex items-center justify-between px-2 py-1 bg-foreground text-background text-xs rounded-t-md transition-opacity ${selected ? "opacity-100" : "opacity-0 group-hover:opacity-100"}`}>
              <div className="flex items-center gap-1.5">
                <button {...provided.dragHandleProps} className="cursor-grab active:cursor-grabbing p-0.5 hover:bg-white/10 rounded">
                  <GripVertical className="w-3.5 h-3.5" />
                </button>
                <Icon className="w-3.5 h-3.5" />
                <span>{def.label || section.type}</span>
              </div>
              <div className="flex items-center gap-0.5">
                <button onClick={(e) => { e.stopPropagation(); onDuplicate(); }} className="p-1 hover:bg-white/10 rounded" title="Dupliquer">
                  <Copy className="w-3.5 h-3.5" />
                </button>
                <button onClick={(e) => { e.stopPropagation(); onToggleHidden(); }} className="p-1 hover:bg-white/10 rounded" title={section.hidden ? "Afficher" : "Masquer"}>
                  {section.hidden ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
                <button onClick={(e) => { e.stopPropagation(); onDelete(); }} className="p-1 hover:bg-white/10 rounded" title="Supprimer">
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
            {/* Content */}
            <div onClick={(e) => { e.stopPropagation(); onSelect(); }} className={`cursor-pointer ${section.hidden ? "opacity-30" : ""} pt-8`}>
              <BlockRenderer section={section} isEditing={false} selected={selected} onSelect={onSelect} />
            </div>
          </div>
        </div>
      )}
    </Draggable>
  );
}

function AddButton({ onClick }) {
  return (
    <div className="flex justify-center py-1">
      <button onClick={onClick} className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground px-3 py-1 rounded-full border border-dashed border-border hover:border-foreground/30 transition-colors">
        <Plus className="w-3 h-3" /> Ajouter
      </button>
    </div>
  );
}

export default function Canvas({ sections, selectedId, onSelect, onReorder, onDuplicate, onDelete, onToggleHidden, onAddAt, device }) {
  const handleDragEnd = (result) => {
    if (!result.destination) return;
    onReorder(result.source.index, result.destination.index);
  };

  return (
    <div className="flex-1 overflow-y-auto bg-muted/30 p-4 lg:p-8">
      <div className={`mx-auto bg-card shadow-sm transition-all duration-300 ${DEVICE_WIDTH[device] || DEVICE_WIDTH.desktop} min-h-[400px]`}>
        {sections.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <p className="text-2xl font-display font-semibold mb-2">Commencez par créer votre univers.</p>
            <p className="text-sm text-muted-foreground">Ajoutez votre première section depuis l’explorateur.</p>
            <button onClick={() => onAddAt(0)} className="mt-6 flex items-center gap-2 rounded-full border border-border px-4 py-2 text-sm hover:bg-accent"><Plus className="w-4 h-4" /> Ajouter une section</button>
          </div>
        ) : (
          <DragDropContext onDragEnd={handleDragEnd}>
            <Droppable droppableId="sections">
              {(provided) => (
                <div ref={provided.innerRef} {...provided.droppableProps}>
                  <AddButton onClick={() => onAddAt(0)} />
                  {sections.map((section, index) => (
                    <React.Fragment key={section.id}>
                      <SectionCard
                        section={section}
                        index={index}
                        selected={selectedId === section.id}
                        onSelect={() => onSelect(section.id)}
                        onDuplicate={() => onDuplicate(section.id)}
                        onDelete={() => onDelete(section.id)}
                        onToggleHidden={() => onToggleHidden(section.id)}
                      />
                      <AddButton onClick={() => onAddAt(index + 1)} />
                    </React.Fragment>
                  ))}
                  {provided.placeholder}
                </div>
              )}
            </Droppable>
          </DragDropContext>
        )}
      </div>
    </div>
  );
}