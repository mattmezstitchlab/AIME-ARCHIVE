import {
  User, Image as ImageIcon, Type, Quote, FileText, BookOpen, GitBranch,
  Heart, MessageCircle, Award, Gift, Briefcase, FolderKanban, Images,
  Video, Music, Link, Share2, Mail, MousePointerClick, Handshake,
  Calendar, Users, Building2
} from "lucide-react";

export const ICONS = {
  User, ImageIcon, Type, Quote, FileText, BookOpen, GitBranch,
  Heart, MessageCircle, Award, Gift, Briefcase, FolderKanban, Images,
  Video, Music, Link, Share2, Mail, MousePointerClick, Handshake,
  Calendar, Users, Building2
};