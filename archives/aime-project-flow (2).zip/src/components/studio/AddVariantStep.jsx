import { Check } from "lucide-react";
import { getSectionVariants } from "@/lib/studioCreation";

export default function AddVariantStep({ type, value, onChange }) {
  return <div className="space-y-3"><div><p className="text-sm font-medium">Choisissez une mise en page</p><p className="text-xs text-muted-foreground">Trois directions adaptées à cette section.</p></div><div className="grid grid-cols-3 gap-2">{getSectionVariants(type).map(option => <button key={option.id} onClick={() => onChange(option.id)} className={`relative rounded-xl border p-3 text-left ${value === option.id ? "border-primary bg-accent" : "border-border hover:bg-accent"}`}><div className="mb-3 h-14 rounded-lg bg-muted"><span className="block h-full w-2/3 border-r border-border" /></div><p className="text-xs font-medium">{option.label}</p><p className="mt-1 text-[10px] text-muted-foreground">{option.note}</p>{value === option.id && <Check className="absolute right-2 top-2 w-3 h-3" />}</button>)}</div></div>;
}