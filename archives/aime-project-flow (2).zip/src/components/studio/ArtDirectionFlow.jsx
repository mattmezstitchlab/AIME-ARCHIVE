import { useState } from "react";
import { ArrowLeft, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import VisualChoiceGrid from "./VisualChoiceGrid";
import { ART_MOODS, ART_PALETTES, HERO_OPTIONS, TYPOGRAPHY_OPTIONS } from "@/lib/studioCreation";

const STEPS = [
  { title: "Choisissez une ambiance", text: "La sensation générale de votre univers.", key: "mood", options: ART_MOODS, kind: "mood" },
  { title: "Choisissez une palette", text: "Elle guide les fonds, textes, boutons et cartes.", key: "palette", options: ART_PALETTES, kind: "palette" },
  { title: "Choisissez votre Hero", text: "La première impression de votre page.", key: "hero", options: HERO_OPTIONS, kind: "layout" },
  { title: "Choisissez une typographie", text: "Le rythme et la voix de votre projet.", key: "typography", options: TYPOGRAPHY_OPTIONS, kind: "type" },
];

export default function ArtDirectionFlow({ draft, onBack, onComplete }) {
  const [step, setStep] = useState(0);
  const [design, setDesign] = useState({ mood: "elegant", palette: "ivory", hero: "fullscreen", typography: "editorial" });
  const current = STEPS[step];
  return (
    <div className="min-h-screen overflow-y-auto bg-background p-5 lg:p-10"><div className="mx-auto max-w-5xl">
      <div className="flex items-center justify-between"><button onClick={step ? () => setStep(step - 1) : onBack} className="flex items-center gap-2 text-sm text-muted-foreground"><ArrowLeft className="w-4 h-4" /> Retour</button><span className="text-xs text-muted-foreground">Direction artistique · {step + 1}/4</span></div>
      <div className="my-8 flex gap-2">{STEPS.map((_, index) => <div key={index} className={`h-1 flex-1 rounded-full ${index <= step ? "bg-foreground" : "bg-muted"}`} />)}</div>
      <p className="text-xs uppercase tracking-wider text-muted-foreground">{draft.title}</p><h1 className="mt-2 text-4xl font-display font-semibold">{current.title}</h1><p className="mb-8 mt-2 text-muted-foreground">{current.text}</p>
      <VisualChoiceGrid options={current.options} value={design[current.key]} onChange={value => setDesign({ ...design, [current.key]: value })} kind={current.kind} />
      <div className="mt-8 flex justify-end"><Button onClick={() => step === 3 ? onComplete(design) : setStep(step + 1)}>{step === 3 ? "Construire mon univers" : "Continuer"}<ArrowRight className="w-4 h-4" /></Button></div>
    </div></div>
  );
}