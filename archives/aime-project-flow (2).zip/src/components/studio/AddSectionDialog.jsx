import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { getRecommendedSections } from "@/lib/sectionRecommendations";
import AddPlacementStep from "./AddPlacementStep";
import AddTypeStep from "./AddTypeStep";
import AddDetailsStep from "./AddDetailsStep";
import AddVariantStep from "./AddVariantStep";
import { getSectionVariants } from "@/lib/studioCreation";

export default function AddSectionDialog({ open, onClose, page, sections, initialIndex, onCreate }) {
  const [step, setStep] = useState(1);
  const [position, setPosition] = useState(0);
  const [type, setType] = useState("");
  const [variant, setVariant] = useState("classic");
  const [details, setDetails] = useState({ title: "", text: "", image: "", background: "none" });
  const types = getRecommendedSections(page, sections, position);
  useEffect(() => { if (open) { const nextType = types[0] || "presentation"; setStep(1); setPosition(initialIndex ?? sections.length); setType(nextType); setVariant(getSectionVariants(nextType)[0].id); setDetails({ title: "", text: "", image: "", background: "none" }); } }, [open, initialIndex]);
  const chooseType = nextType => { setType(nextType); setVariant(getSectionVariants(nextType)[0].id); };
  const create = () => { onCreate(type, position, { title: details.title, text: details.text, image: details.image }, { background: details.background, variant }); onClose(); };
  return (
    <Dialog open={open} onOpenChange={value => !value && onClose()}>
      <DialogContent className="max-w-lg"><DialogHeader><DialogTitle>Ajouter une section</DialogTitle></DialogHeader>
        <div className="text-xs text-muted-foreground">Étape {step} sur 4</div>
        {step === 1 && <AddPlacementStep sections={sections} value={position} onChange={setPosition} />}
        {step === 2 && <AddTypeStep types={types} value={type} onChange={chooseType} />}
        {step === 3 && <AddVariantStep type={type} value={variant} onChange={setVariant} />}
        {step === 4 && <AddDetailsStep value={details} onChange={setDetails} />}
        <DialogFooter><Button variant="outline" onClick={step === 1 ? onClose : () => setStep(step - 1)}>{step === 1 ? "Annuler" : "Retour"}</Button><Button onClick={step === 4 ? create : () => setStep(step + 1)}>{step === 4 ? "Créer la section" : "Continuer"}</Button></DialogFooter>
      </DialogContent>
    </Dialog>
  );
}