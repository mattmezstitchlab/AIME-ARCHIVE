import { Check } from "lucide-react";

export default function VisualChoiceGrid({ options, value, onChange, kind }) {
  return (
    <div className="grid grid-cols-2 gap-3 lg:grid-cols-3">
      {options.map(option => (
        <button key={option.id} onClick={() => onChange(option.id)} className={`relative overflow-hidden rounded-2xl border p-4 text-left transition ${value === option.id ? "border-foreground ring-1 ring-foreground" : "border-border hover:border-foreground/30"}`}>
          {kind === "palette" ? <div className="mb-5 flex h-16 overflow-hidden rounded-xl">{Object.values(option.colors).map(color => <span key={color} className="flex-1" style={{ backgroundColor: color }} />)}</div> : <div className="mb-5 h-16 rounded-xl" style={{ background: option.tone || "linear-gradient(135deg, hsl(var(--muted)), hsl(var(--card)))" }} />}
          <p className="text-sm font-medium">{option.label}</p><p className="mt-1 text-xs text-muted-foreground">{option.note}</p>
          {value === option.id && <span className="absolute right-3 top-3 flex h-5 w-5 items-center justify-center rounded-full bg-foreground text-background"><Check className="w-3 h-3" /></span>}
        </button>
      ))}
    </div>
  );
}