import { useState } from "react";
import { ArrowRight, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";

const EXAMPLES = ["Créer mon site artiste", "Créer mon mariage", "Créer une association", "Créer une page professionnelle"];

export default function AimePrompt({ onSubmit }) {
  const [value, setValue] = useState("");
  return (
    <div className="rounded-3xl border border-border bg-card p-6 lg:p-8 shadow-sm">
      <div className="flex items-center gap-2 text-sm font-medium"><Sparkles className="w-4 h-4 text-sage" /> Créer avec AIME</div>
      <h2 className="mt-6 text-2xl font-display font-semibold">Quel projet souhaitez-vous créer ?</h2>
      <textarea value={value} onChange={event => setValue(event.target.value)} placeholder="Décrivez votre intention, votre univers, les personnes concernées…" className="mt-4 min-h-28 w-full resize-none rounded-2xl border border-input bg-background p-4 text-sm outline-none focus:ring-2 focus:ring-ring/20" />
      <div className="mt-3 flex flex-wrap gap-2">
        {EXAMPLES.map(example => <button key={example} onClick={() => setValue(example)} className="rounded-full border border-border px-3 py-1.5 text-xs text-muted-foreground hover:bg-accent">{example}</button>)}
      </div>
      <Button onClick={() => value.trim() && onSubmit(value.trim())} disabled={!value.trim()} className="mt-6 w-full rounded-full">Générer mon espace <ArrowRight className="w-4 h-4" /></Button>
    </div>
  );
}