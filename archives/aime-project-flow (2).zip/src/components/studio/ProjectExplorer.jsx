import { useEffect, useState } from "react";
import { Boxes, Copy, Eye, EyeOff, FileText, FolderOpen, GripVertical, Images, Layers3, Palette, Plus } from "lucide-react";
import { BLOCK_TYPES } from "@/lib/studioBlocks";
import ExplorerGroup from "./ExplorerGroup";

export default function ProjectExplorer({ page, sections, selectedId, onSelect, onReorder, onAdd, onSettings, onDuplicate, onToggleHidden }) {
  const [open, setOpen] = useState(() => { try { return JSON.parse(localStorage.getItem("aime-studio-groups")) || { project: true, structure: true, sections: true, components: false, media: false, styles: false, documents: false }; } catch { return { project: true, structure: true, sections: true, components: false, media: false, styles: false, documents: false }; } });
  const [dragIndex, setDragIndex] = useState(null);
  useEffect(() => { localStorage.setItem("aime-studio-groups", JSON.stringify(open)); }, [open]);
  const toggle = key => setOpen(value => ({ ...value, [key]: !value[key] }));
  return <aside className="hidden lg:flex w-64 border-r border-border bg-card flex-col h-full">
    <div className="border-b border-border p-4"><p className="text-[10px] uppercase tracking-wider text-muted-foreground">AIME Studio</p><h2 className="mt-1 truncate text-sm font-semibold">{page?.title || "Nouvel univers"}</h2></div>
    <div className="flex-1 space-y-1 overflow-y-auto p-2">
      <ExplorerGroup icon={FolderOpen} label="Projet" open={open.project} onToggle={() => toggle("project")}><button onClick={onSettings} className="w-full px-2 py-1.5 text-left text-xs text-muted-foreground hover:text-foreground">Identité du projet</button>{(page?.projectConfig?.views || ["Page publique"]).map(view => <p key={view} className="px-2 py-1 text-[11px] text-muted-foreground">{view}</p>)}</ExplorerGroup>
      <ExplorerGroup icon={Layers3} label="Structure" open={open.structure} onToggle={() => toggle("structure")}>
        {sections.map((section, index) => <button key={section.id} draggable onDragStart={() => setDragIndex(index)} onDragOver={event => event.preventDefault()} onDrop={() => { if (dragIndex !== null && dragIndex !== index) onReorder(dragIndex, index); setDragIndex(null); }} onClick={() => onSelect(section.id)} className={`group w-full flex items-center gap-1 px-2 py-1.5 rounded-md text-xs text-left ${selectedId === section.id ? "bg-muted text-foreground" : "text-muted-foreground hover:bg-muted/70 hover:text-foreground"}`}><GripVertical className="w-3 h-3 cursor-grab" /><span className="min-w-0 flex-1 truncate">{BLOCK_TYPES[section.type]?.label || section.type}</span><span onClick={event => { event.stopPropagation(); onToggleHidden(section.id); }} title={section.hidden ? "Afficher" : "Masquer"}>{section.hidden ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3 opacity-0 group-hover:opacity-100" />}</span><span onClick={event => { event.stopPropagation(); onDuplicate(section.id); }} title="Dupliquer"><Copy className="w-3 h-3 opacity-0 group-hover:opacity-100" /></span></button>)}
      </ExplorerGroup>
      <ExplorerGroup icon={Plus} label="Sections" open={open.sections} onToggle={() => toggle("sections")}><button onClick={onAdd} className="flex w-full items-center gap-1.5 px-2 py-1.5 text-xs text-muted-foreground hover:text-foreground"><Plus className="w-3 h-3" /> Ajouter intelligemment</button></ExplorerGroup>
      <ExplorerGroup icon={Boxes} label="Composants" open={open.components} onToggle={() => toggle("components")}><p className="px-2 py-1 text-[11px] text-muted-foreground">Éléments réutilisables du projet</p></ExplorerGroup>
      <ExplorerGroup icon={Images} label="Médias" open={open.media} onToggle={() => toggle("media")}><p className="px-2 py-1 text-[11px] text-muted-foreground">Images et vidéos des sections</p></ExplorerGroup>
      <ExplorerGroup icon={Palette} label="Styles" open={open.styles} onToggle={() => toggle("styles")}><button onClick={onSettings} className="w-full px-2 py-1.5 text-left text-xs text-muted-foreground hover:text-foreground">Identité visuelle</button></ExplorerGroup>
      <ExplorerGroup icon={FileText} label="Documents" open={open.documents} onToggle={() => toggle("documents")}><p className="px-2 py-1 text-[11px] text-muted-foreground">Documents liés au projet</p></ExplorerGroup>
    </div>
  </aside>;
}