import { Layers3, Plus, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import AimePrompt from "./AimePrompt";

export default function StudioStart({ hasExisting, onResume, onBlank, onAime }) {
  return (
    <div className="min-h-screen overflow-y-auto bg-background px-5 py-10 lg:px-10">
      <div className="mx-auto max-w-6xl">
        <div className="flex items-center justify-between"><div><p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">AIME Studio</p><h1 className="mt-2 text-4xl font-display font-semibold">Donnez une identité à votre projet.</h1></div>{hasExisting && <Button variant="outline" onClick={onResume}>Reprendre mon projet <ArrowRight className="w-4 h-4" /></Button>}</div>
        <p className="mt-3 max-w-xl text-muted-foreground">Commencez librement ou laissez AIME construire un socle adapté à votre intention.</p>
        <div className="mt-10 grid gap-5 lg:grid-cols-2">
          <button onClick={onBlank} className="group min-h-[390px] rounded-3xl border border-border bg-card p-8 text-left shadow-sm hover:border-foreground/30">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-muted"><Plus className="w-5 h-5" /></div>
            <div className="mt-24"><p className="text-sm font-medium">Créer depuis zéro</p><h2 className="mt-2 text-2xl font-display font-semibold">Commencez par créer votre univers.</h2><p className="mt-3 text-sm text-muted-foreground">Un canvas vide, un explorateur clair et toute la liberté de composer.</p></div>
            <div className="mt-8 flex items-center gap-2 text-sm font-medium">Ouvrir un espace vide <Layers3 className="w-4 h-4 transition-transform group-hover:translate-x-1" /></div>
          </button>
          <AimePrompt onSubmit={onAime} />
        </div>
      </div>
    </div>
  );
}