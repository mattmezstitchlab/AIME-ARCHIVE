import { ChevronDown, ChevronRight } from "lucide-react";

export default function ExplorerGroup({ icon: Icon, label, open, onToggle, children }) {
  return (
    <div>
      <button onClick={onToggle} className="w-full flex items-center gap-2 rounded-md px-2 py-1.5 text-xs font-medium transition-colors hover:bg-muted">
        {open ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
        <Icon className="w-3.5 h-3.5 text-muted-foreground" />
        <span>{label}</span>
      </button>
      {open && <div className="ml-4 mt-1 space-y-0.5">{children}</div>}
    </div>
  );
}