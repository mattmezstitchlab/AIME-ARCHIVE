import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const MODES = [["normal","Image normale"],["full_width","Pleine largeur"],["background","Fond de section"],["hero_background","Fond Hero plein écran"],["floating","Image flottante"],["mask","Image avec masque"]];
const POSITIONS = [["center","Centre"],["top","Haut"],["bottom","Bas"],["left","Gauche"],["right","Droite"]];
const SLIDERS = [["brightness","Luminosité",0,200,100],["contrast","Contraste",0,200,100],["saturation","Saturation",0,200,100],["blur","Flou",0,20,0],["opacity","Opacité",0,100,100],["imageZoom","Zoom",0,200,100]];

export default function ImageSettings({ style, onChange }) {
  const set = (key, value) => onChange({ ...style, [key]: value });
  return (
    <div className="space-y-3">
      <div><Label className="text-xs">Mode d’affichage</Label><Select value={style.imageMode || "normal"} onValueChange={v => set("imageMode", v)}><SelectTrigger className="h-9"><SelectValue /></SelectTrigger><SelectContent>{MODES.map(([v,l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}</SelectContent></Select></div>
      <div><Label className="text-xs">Position</Label><Select value={style.imagePosition || "center"} onValueChange={v => set("imagePosition", v)}><SelectTrigger className="h-9"><SelectValue /></SelectTrigger><SelectContent>{POSITIONS.map(([v,l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}</SelectContent></Select></div>
      <div className="grid grid-cols-2 gap-2"><div><Label className="text-xs">Position X</Label><Input type="number" value={style.imageX ?? 50} onChange={e => set("imageX", Number(e.target.value))} /></div><div><Label className="text-xs">Position Y</Label><Input type="number" value={style.imageY ?? 50} onChange={e => set("imageY", Number(e.target.value))} /></div></div>
      {SLIDERS.map(([key,label,min,max,fallback]) => <div key={key}><div className="flex justify-between"><Label className="text-xs">{label}</Label><span className="text-[10px] text-muted-foreground">{style[key] ?? fallback}</span></div><input className="w-full accent-foreground" type="range" min={min} max={max} value={style[key] ?? fallback} onChange={e => set(key, Number(e.target.value))} /></div>)}
      <div><Label className="text-xs">Overlay couleur</Label><Input type="color" value={style.overlayColor || "#000000"} onChange={e => set("overlayColor", e.target.value)} /></div>
    </div>
  );
}