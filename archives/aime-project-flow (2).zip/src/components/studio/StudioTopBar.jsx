import React from "react";
import { Link } from "react-router-dom";
import { Monitor, Tablet, Smartphone, Eye, Settings, Globe, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import WorkspaceMenu from "@/components/navigation/WorkspaceMenu";

export default function StudioTopBar({ page, dirty, device, setDevice, onPreview, onSettings, onPublish, onUnpublish, publishing, previewMode, onExitPreview }) {
  const statusLabel = !page ? "Nouveau" : page.status === "brouillon" ? "Brouillon" : dirty ? "Modifications non publiées" : "Publiée";
  const statusClass = !page || page.status === "brouillon" ? "bg-muted text-muted-foreground" : dirty ? "bg-amber-100 text-amber-700" : "bg-emerald-100 text-emerald-700";

  const devices = [
    { id: "desktop", icon: Monitor },
    { id: "tablet", icon: Tablet },
    { id: "mobile", icon: Smartphone },
  ];

  return (
    <div className="h-14 border-b border-border bg-card flex items-center justify-between px-4 shrink-0">
      <div className="flex items-center gap-3">
        <span className="hidden sm:inline font-display font-semibold text-sm">Ma Page AIME</span>
        <span className={`hidden md:inline text-xs px-2 py-0.5 rounded-full ${statusClass}`}>{statusLabel}</span>
      </div>
      <div className="flex items-center gap-2">
        {previewMode ? (
          <Button variant="outline" size="sm" onClick={onExitPreview} className="gap-1.5">
            <Eye className="w-3.5 h-3.5" /> Quitter l'aperçu
          </Button>
        ) : (
          <>
            <div className="hidden sm:flex items-center gap-0.5 p-0.5 rounded-md bg-muted">
              {devices.map(({ id, icon: Icon }) => (
                <button key={id} onClick={() => setDevice(id)} className={`p-1.5 rounded ${device === id ? "bg-card shadow-sm" : "text-muted-foreground hover:text-foreground"}`}>
                  <Icon className="w-3.5 h-3.5" />
                </button>
              ))}
            </div>
            <Button variant="outline" size="sm" onClick={onPreview} className="gap-1.5">
              <Eye className="w-3.5 h-3.5" /> <span className="hidden lg:inline">Prévisualiser</span>
            </Button>
            <Button variant="outline" size="sm" onClick={onSettings} className="gap-1.5">
              <Settings className="w-3.5 h-3.5" /> <span className="hidden lg:inline">Paramètres</span>
            </Button>
            {page?.status === "publie" && (
              <>
                <Button variant="outline" size="sm" asChild className="gap-1.5">
                  <Link to={`/@${page.username}`} target="_blank"><Globe className="w-3.5 h-3.5" /> <span className="hidden xl:inline">Voir ma page</span></Link>
                </Button>
                <Button variant="outline" size="sm" onClick={onUnpublish} disabled={publishing} className="gap-1.5">
                  <Upload className="w-3.5 h-3.5 rotate-180" /> <span className="hidden lg:inline">Dépublier</span>
                </Button>
              </>
            )}
            <Button size="sm" onClick={onPublish} disabled={publishing || !page} className="gap-1.5">
              <Upload className="w-3.5 h-3.5" /> <span className="hidden sm:inline">{page?.status === "publie" ? "Mettre à jour" : "Publier"}</span>
            </Button>
          </>
        )}
        <WorkspaceMenu />
      </div>
    </div>
  );
}