import { useEffect, useState } from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Loader2 } from 'lucide-react';

/**
 * Garde de rôle réelle pour les espaces propriétaire/administrateur AIME.
 * Un utilisateur non-admin qui saisit une URL admin est redirigé vers son dashboard.
 */
export default function AdminRoute() {
  const [allowed, setAllowed] = useState(null);

  useEffect(() => {
    base44.auth.me()
      .then((me) => setAllowed(me?.role === 'admin'))
      .catch(() => setAllowed(false));
  }, []);

  if (allowed === null) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!allowed) return <Navigate to="/" replace />;

  return <Outlet />;
}