import { createContext, useContext, useCallback, useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Building2, Plus } from "lucide-react";
import { setTenant } from "@/lib/activeTenant";

const Ctx = createContext(null);
export function useAssociation() { return useContext(Ctx); }

export function AssociationProvider({ children }) {
  const [me, setMe] = useState(null);
  const [associations, setAssociations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [dismissed, setDismissed] = useState(false);
  const [name, setName] = useState("");
  const [desc, setDesc] = useState("");
  const [creating, setCreating] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const u = await base44.auth.me();
      // Lier les fiches Membre à ce utilisateur par email
      if (u?.email) {
        try {
          const membres = await base44.entities.Membre.filter({ email: u.email });
          const unlinked = membres.filter((m) => !m.user_id);
          if (unlinked.length) {
            await Promise.all(unlinked.map((m) => base44.entities.Membre.update(m.id, { user_id: u.id, status: "actif" })));
          }
          // Associer l'utilisateur à l'association si pas déjà fait
          const memberAssocIds = membres.map((m) => m.association_id).filter(Boolean);
          if (memberAssocIds.length && !u.association_id) {
            const allIds = Array.from(new Set([...(u.associations || []), ...memberAssocIds]));
            await base44.auth.updateMe({ association_id: memberAssocIds[0], associations: allIds });
            u.association_id = memberAssocIds[0];
            u.associations = allIds;
          }
        } catch (e) { /* ignore */ }
      }
      setMe(u);
      const ids = Array.isArray(u?.associations) ? u.associations : (u?.association_id ? [u.association_id] : []);
      let recs = [];
      if (ids.length) {
        const all = await base44.entities.Association.list();
        recs = all.filter((a) => ids.includes(a.id));
      }
      setAssociations(recs);
    } catch (e) { /* silently ignore */ }
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const activeAssociationId = me?.association_id || null;
  useEffect(() => { setTenant(activeAssociationId); }, [activeAssociationId]);
  const activeAssoc = associations.find((a) => a.id === activeAssociationId) || null;
  const isAdmin = me?.role === "admin";

  async function switchAssociation(id) {
    if (!id || id === activeAssociationId) return;
    await base44.auth.updateMe({ association_id: id });
    setMe((prev) => (prev ? { ...prev, association_id: id } : prev));
  }

  async function createAssociation() {
    if (!name.trim()) return;
    setCreating(true);
    try {
      const u = me || await base44.auth.me();
      const a = await base44.entities.Association.create({
        name: name.trim(),
        description: desc,
        color: "#1F2937",
        members: [u.id],
        admin_ids: [u.id]
      });
      const ids = Array.from(new Set([...(u.associations || []), a.id]));
      await base44.auth.updateMe({ association_id: a.id, associations: ids });
      setName(""); setDesc(""); setDismissed(false);
      await load();
    } catch (e) { /* ignore */ }
    setCreating(false);
  }

  const needOnboarding = me && !activeAssociationId && !loading && !dismissed;

  return (
    <Ctx.Provider value={{ me, activeAssociationId, activeAssoc, associations, loading, isAdmin, switchAssociation, createAssociation, refresh: load }}>
      {children}
      <Dialog open={needOnboarding} onOpenChange={() => {}}>
        <DialogContent className="sm:max-w-md" onOpenAutoFocus={(e) => e.preventDefault()}>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><Building2 className="w-4 h-4 text-primary" /> Votre association</DialogTitle>
          </DialogHeader>
          <p className="text-sm text-muted-foreground">
            Pour structurer des projets et isoler vos données, créez votre première association. Vous pourrez en gérer plusieurs et changer à tout moment.
          </p>
          <div className="space-y-3 py-2">
            <div>
              <Label>Nom de l'association</Label>
              <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Ex. Les Ateliers du Cœur" autoFocus />
            </div>
            <div>
              <Label>Description (optionnel)</Label>
              <Textarea value={desc} onChange={(e) => setDesc(e.target.value)} rows={2} placeholder="Mission, secteur…" />
            </div>
          </div>
          <DialogFooter className="sm:justify-between">
            {isAdmin && (
              <Button variant="ghost" size="sm" onClick={() => setDismissed(true)}>Plus tard</Button>
            )}
            <Button onClick={createAssociation} disabled={creating || !name.trim()} className="gap-1.5 ml-auto">
              {creating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
              Créer l'association
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Ctx.Provider>
  );
}