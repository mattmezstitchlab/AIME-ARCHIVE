import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { logAction } from "@/lib/aimeAgent";
import { formatDate } from "@/lib/aimeFormats";
import { getAimePersona } from "@/lib/aime/aiPersona";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { useToast } from "@/components/ui/use-toast";
import {
  Check, X, Sparkles, Loader2, ClipboardList, FileText, UserCheck
} from "lucide-react";

const PRESENCE_OPTS = [
  { key: "present", label: "Présent",  active: "bg-sage text-sage-foreground" },
  { key: "absent",  label: "Absent",   active: "bg-destructive/15 text-destructive" },
  { key: "excuse",  label: "Excusé",   active: "bg-muted text-muted-foreground" }
];

export default function ReunionPanel({ reunion, project, onChange }) {
  const { toast } = useToast();
  const [tab, setTab] = useState("odj");
  const [info, setInfo] = useState({
    title: reunion.title || "",
    date: reunion.date || "",
    location: reunion.location || "",
    ordre_du_jour: reunion.ordre_du_jour || ""
  });
  const [cr, setCr] = useState(reunion.compte_rendu || "");
  const [presence, setPresence] = useState(
    reunion.presence?.length
      ? reunion.presence
      : (reunion.participants || []).map((n) => ({ name: n, status: "present" }))
  );
  const [saving, setSaving] = useState(false);
  const [gening, setGening] = useState(false);

  async function saveInfo() {
    setSaving(true);
    try {
      await base44.entities.Reunion.update(reunion.id, {
        title: info.title, date: info.date, location: info.location, ordre_du_jour: info.ordre_du_jour
      });
      toast({ title: "Réunion mise à jour" });
      onChange();
    } catch { toast({ title: "Erreur", variant: "destructive" }); }
    setSaving(false);
  }

  function setStatus(name, status) {
    setPresence((prev) => prev.map((p) => (p.name === name ? { ...p, status } : p)));
  }

  async function savePresence() {
    setSaving(true);
    try {
      await base44.entities.Reunion.update(reunion.id, {
        presence,
        participants: presence.map((p) => p.name)
      });
      await logAction("presence_saisie", "Reunion", reunion.id, reunion.project_id, "Feuille de présence enregistrée.");
      toast({ title: "Présence enregistrée" });
      onChange();
    } catch { toast({ title: "Erreur", variant: "destructive" }); }
    setSaving(false);
  }

  async function generateCR() {
    setGening(true);
    try {
      const present = presence.filter((p) => p.status === "present").map((p) => p.name);
      const absent = presence
        .filter((p) => p.status !== "present")
        .map((p) => `${p.name} (${p.status === "excuse" ? "excusé" : "absent"})`);
      const prompt = `Tu es AIME, ${getAimePersona(project?.category)}. Rédige un compte rendu de réunion en français, structuré et factuel, au format texte simple (pas de markdown).
Projet : ${project?.name || "—"}
Vision : ${project?.vision || "—"}
Date : ${formatDate(reunion.date)} — Lieu : ${reunion.location || "à définir"}

Ordre du jour :
${(reunion.ordre_du_jour || "Non précisé").split("\n").filter(Boolean).map((l) => "- " + l).join("\n")}

Présents : ${present.join(", ") || "—"}
Absents : ${absent.join(", ") || "—"}

Rédige : 1) Ouverture, 2) un point développé par item de l'ordre du jour, 3) Décisions prises, 4) Actions à mener avec responsables et échéances, 5) Clôture. Reste concis et professionnel.`;
      const res = await base44.integrations.Core.InvokeLLM({ prompt });
      const text = typeof res === "string" ? res : res?.content || res?.response || "";
      setCr(text);
      await base44.entities.Reunion.update(reunion.id, { compte_rendu: text, status: "realise" });
      await logAction("compte_rendu_genere", "Reunion", reunion.id, reunion.project_id, "Compte rendu rédigé par AIME.");
      toast({ title: "Compte rendu rédigé par AIME" });
      onChange();
    } catch { toast({ title: "Erreur de génération", variant: "destructive" }); }
    setGening(false);
  }

  async function saveCR() {
    setSaving(true);
    try {
      await base44.entities.Reunion.update(reunion.id, { compte_rendu: cr });
      toast({ title: "Compte rendu enregistré" });
      onChange();
    } catch { toast({ title: "Erreur", variant: "destructive" }); }
    setSaving(false);
  }

  return (
    <div className="border-t border-border mt-3 pt-4">
      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="bg-card border border-border h-auto p-1">
          <TabsTrigger value="odj" className="text-xs gap-1.5 rounded-md"><ClipboardList className="w-3.5 h-3.5" /> Ordre du jour</TabsTrigger>
          <TabsTrigger value="presence" className="text-xs gap-1.5 rounded-md"><UserCheck className="w-3.5 h-3.5" /> Présence</TabsTrigger>
          <TabsTrigger value="cr" className="text-xs gap-1.5 rounded-md"><FileText className="w-3.5 h-3.5" /> Compte rendu</TabsTrigger>
        </TabsList>

        <TabsContent value="odj" className="mt-4 space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <Label className="text-xs text-muted-foreground">Titre</Label>
              <Input value={info.title} onChange={(e) => setInfo({ ...info, title: e.target.value })} />
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">Date</Label>
              <Input type="date" value={info.date} onChange={(e) => setInfo({ ...info, date: e.target.value })} />
            </div>
          </div>
          <div>
            <Label className="text-xs text-muted-foreground">Lieu</Label>
            <Input value={info.location} onChange={(e) => setInfo({ ...info, location: e.target.value })} placeholder="Salle, adresse ou en ligne" />
          </div>
          <div>
            <Label className="text-xs text-muted-foreground">Ordre du jour — un point par ligne</Label>
            <Textarea rows={5} value={info.ordre_du_jour} onChange={(e) => setInfo({ ...info, ordre_du_jour: e.target.value })} placeholder={"Validation du budget\nPoint sur le bénévolat\nActions de communication"} />
          </div>
          <Button size="sm" onClick={saveInfo} disabled={saving} className="gap-1.5">
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />} Enregistrer
          </Button>
        </TabsContent>

        <TabsContent value="presence" className="mt-4 space-y-3">
          {presence.length === 0 ? (
            <p className="text-sm text-muted-foreground">Aucun participant invité. Ajoutez des membres lors de la création de la réunion.</p>
          ) : (
            <>
              <div className="flex items-center justify-between">
                <p className="text-xs text-muted-foreground">
                  {presence.filter((p) => p.status === "present").length} présent(s) · {presence.length} invité(s)
                </p>
                <Button size="sm" variant="outline" onClick={() => setPresence(presence.map((p) => ({ ...p, status: "present" })))}>
                  Tous présents
                </Button>
              </div>
              <div className="space-y-2">
                {presence.map((p, i) => (
                  <div key={i} className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 rounded-lg border border-border bg-card px-3 py-2">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-full bg-navy/10 text-navy flex items-center justify-center text-xs font-semibold">
                        {p.name?.[0]?.toUpperCase()}
                      </div>
                      <span className="text-sm font-medium">{p.name}</span>
                    </div>
                    <div className="flex gap-1.5">
                      {PRESENCE_OPTS.map((o) => (
                        <button
                          key={o.key}
                          type="button"
                          onClick={() => setStatus(p.name, o.key)}
                          className={"text-xs px-2.5 py-1 rounded-md border transition " +
                            (p.status === o.key ? o.active + " border-0" : "border-border text-muted-foreground hover:bg-muted")}
                        >
                          {o.label}
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
              <Button size="sm" onClick={savePresence} disabled={saving} className="gap-1.5">
                {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />} Enregistrer la présence
              </Button>
            </>
          )}
        </TabsContent>

        <TabsContent value="cr" className="mt-4 space-y-3">
          <div className="rounded-xl bg-sky/15 border border-sky/30 p-3 flex items-start gap-2.5">
            <Sparkles className="w-4 h-4 text-primary shrink-0 mt-0.5" />
            <p className="text-sm text-foreground/80">AIME rédige le compte rendu à partir de l'ordre du jour, de la feuille de présence et du contexte du projet. Vous pouvez ensuite le corriger.</p>
          </div>
          <div className="flex flex-col sm:flex-row gap-2">
            <Button onClick={generateCR} disabled={gening} className="gap-1.5 flex-1">
              {gening ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />} AIME rédige le compte rendu
            </Button>
            <Button variant="outline" onClick={saveCR} disabled={saving} className="gap-1.5">
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />} Enregistrer
            </Button>
          </div>
          <Textarea rows={12} value={cr} onChange={(e) => setCr(e.target.value)} placeholder="Le compte rendu apparaîtra ici, modifiable." className="font-mono text-xs" />
        </TabsContent>
      </Tabs>
    </div>
  );
}