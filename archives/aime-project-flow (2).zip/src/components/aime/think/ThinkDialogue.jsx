import { useState, useRef, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Bot, Send, Loader2, Sparkles, ArrowRight, History } from 'lucide-react';

const NATIVE_QUESTIONS = [
  'Pourquoi ce projet existe ?',
  'Que manque-t-il à mon projet ?',
  'Quelle est la prochaine étape logique ?',
  'Quelle direction semble la plus cohérente ?',
  'Quelle émotion doit transmettre ce projet ?',
  'Quelle personne doit-il aider ?',
];

export default function ThinkDialogue({ project, dna, onSuggestedAction }) {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [lastSessions, setLastSessions] = useState([]);
  const [searchParams, setSearchParams] = useSearchParams();
  const scrollRef = useRef(null);
  const initialQuestionSent = useRef(false);

  // Charger l'historique conversationnel (mémoire AIME)
  useEffect(() => {
    if (!project?.id) return;
    (async () => {
      try {
        const me = await base44.auth.me();
        const sessions = await base44.entities.ThinkSession.filter(
          { project_id: project.id, owner_id: me.id },
          '-created_date',
          3
        );
        setLastSessions(sessions);
      } catch (e) { /* ignore */ }
    })();
  }, [project?.id]);

  // Question initiale via paramètre URL (depuis Partition Vivante)
  useEffect(() => {
    if (project?.id && !initialQuestionSent.current) {
      const q = searchParams.get('q');
      if (q) {
        initialQuestionSent.current = true;
        ask(q);
      }
    }
  }, [project?.id, searchParams]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, loading]);

  const ask = async (question) => {
    if (!question.trim() || loading || !project?.id) return;
    setInput('');
    const userMsg = { role: 'user', content: question };
    setMessages((prev) => [...prev, userMsg]);
    setLoading(true);
    // Nettoyer le paramètre q après envoi (en préservant project)
    if (searchParams.get('q')) {
      const p = searchParams.get('project');
      setSearchParams(p ? { project: p } : {}, { replace: true });
    }
    try {
      const response = await base44.functions.invoke('aimeThink', {
        project_id: project.id,
        question,
      });
      const data = response.data;
      if (data?.error) throw new Error(data.error);
      const aiMsg = {
        role: 'ai',
        content: data.response || 'Aucune réponse reçue.',
        suggested_actions: data.suggested_actions || [],
      };
      setMessages((prev) => [...prev, aiMsg]);
      // Rafraîchir l'historique
      try {
        const me = await base44.auth.me();
        const sessions = await base44.entities.ThinkSession.filter(
          { project_id: project.id, owner_id: me.id },
          '-created_date',
          3
        );
        setLastSessions(sessions);
      } catch (e) { /* ignore */ }
    } catch (e) {
      setMessages((prev) => [...prev, { role: 'ai', content: `Erreur : ${e.message}`, error: true }]);
    }
    setLoading(false);
  };

  return (
    <div className="border border-border rounded-lg overflow-hidden flex flex-col" style={{ minHeight: '400px' }}>
      {/* Header */}
      <div className="bg-secondary text-secondary-foreground px-4 py-3 flex items-center gap-2">
        <Bot className="w-4 h-4 opacity-70" strokeWidth={1.5} />
        <span className="text-xs font-semibold uppercase tracking-wider opacity-80">Dialogue contextuel</span>
      </div>

      {/* Messages */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4 bg-muted/20" style={{ maxHeight: '500px' }}>
        {messages.length === 0 && !loading && (
          <div className="py-6">
            {lastSessions.length > 0 ? (
              <div className="mb-4">
                <div className="flex items-center gap-2 mb-2">
                  <History className="w-3.5 h-3.5 text-muted-foreground" strokeWidth={1.5} />
                  <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                    AIME se souvient
                  </span>
                </div>
                <div className="space-y-1.5">
                  {lastSessions.map((s) => (
                    <button
                      key={s.id}
                      onClick={() => ask(s.question)}
                      className="w-full text-left flex items-center gap-2 px-3 py-2 rounded-md border border-border hover:bg-muted/50 transition text-xs"
                    >
                      <span className="text-muted-foreground flex-1 truncate">{s.question}</span>
                      <ArrowRight className="w-3 h-3 text-muted-foreground shrink-0" strokeWidth={1.5} />
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <div className="text-center">
                <Sparkles className="w-8 h-8 mx-auto mb-3 text-muted-foreground" strokeWidth={1.5} />
                <p className="text-sm text-muted-foreground mb-1">Posez votre question au projet</p>
                <p className="text-xs text-muted-foreground">AIME THINK répond avec le contexte complet de votre projet</p>
              </div>
            )}
          </div>
        )}

        {messages.map((msg, i) => (
          <div key={i} className={msg.role === 'user' ? 'flex justify-end' : 'flex justify-start'}>
            <div className={msg.role === 'user' ? 'max-w-[80%]' : 'max-w-[85%]'}>
              <div
                className={
                  msg.role === 'user'
                    ? 'bg-secondary text-secondary-foreground rounded-2xl rounded-br-sm px-4 py-2.5 text-sm'
                    : msg.error
                    ? 'bg-destructive/10 text-destructive rounded-2xl rounded-bl-sm px-4 py-2.5 text-sm'
                    : 'bg-background border border-border rounded-2xl rounded-bl-sm px-4 py-2.5 text-sm'
                }
              >
                <p className="whitespace-pre-wrap leading-relaxed">{msg.content}</p>
              </div>
              {msg.suggested_actions?.length > 0 && (
                <div className="mt-2 space-y-1.5">
                  {msg.suggested_actions.map((action, j) => (
                    <button
                      key={j}
                      onClick={() => onSuggestedAction?.(action)}
                      className="w-full text-left flex items-center gap-2 px-3 py-2 rounded-lg border border-border bg-background hover:bg-muted/50 transition text-xs"
                    >
                      <ArrowRight className="w-3.5 h-3.5 text-muted-foreground shrink-0" strokeWidth={1.5} />
                      <span className="font-medium">{action.label}</span>
                      <span className="text-muted-foreground ml-auto capitalize">{action.type.replace('_', ' ')}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        ))}

        {loading && (
          <div className="flex justify-start">
            <div className="bg-background border border-border rounded-2xl rounded-bl-sm px-4 py-3 flex items-center gap-2">
              <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
              <span className="text-xs text-muted-foreground">AIME THINK réfléchit…</span>
            </div>
          </div>
        )}
      </div>

      {/* Native questions */}
      {messages.length === 0 && (
        <div className="px-4 py-3 border-t border-border bg-background">
          <p className="text-xs text-muted-foreground mb-2">Questions natives</p>
          <div className="flex flex-wrap gap-1.5">
            {NATIVE_QUESTIONS.map((q, i) => (
              <button
                key={i}
                onClick={() => ask(q)}
                disabled={loading}
                className="px-3 py-1.5 rounded-full border border-border bg-background hover:bg-muted/50 transition text-xs text-foreground disabled:opacity-50"
              >
                {q}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Input */}
      <div className="px-4 py-3 border-t border-border bg-background">
        <div className="flex gap-2">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && (e.preventDefault(), ask(input))}
            placeholder="Posez votre question…"
            disabled={loading}
            className="flex-1 h-10 px-4 rounded-full border border-input bg-background text-sm outline-none focus:ring-1 focus:ring-ring disabled:opacity-50"
          />
          <button
            onClick={() => ask(input)}
            disabled={loading || !input.trim()}
            className="brand-secondary-btn disabled:opacity-50 shrink-0"
          >
            <Send className="w-4 h-4" strokeWidth={1.5} />
          </button>
        </div>
      </div>
    </div>
  );
}