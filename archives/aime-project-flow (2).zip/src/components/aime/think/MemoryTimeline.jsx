import { GitCommit, Clock } from 'lucide-react';

const ENTITY_LABELS = {
  ProjectDNA: 'ADN du projet',
  MemoryItem: 'Élément mémoire',
  FuturePath: 'Futur possible',
};

export default function MemoryTimeline({ versions = [] }) {
  if (versions.length === 0) {
    return (
      <div className="border border-border rounded-lg p-4">
        <div className="flex items-center gap-2 mb-2">
          <Clock className="w-4 h-4 text-muted-foreground" strokeWidth={1.5} />
          <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Évolution de la compréhension
          </h3>
        </div>
        <p className="text-xs text-muted-foreground italic">Aucune version enregistrée. L'historique se construit au fil des analyses et validations.</p>
      </div>
    );
  }

  return (
    <div className="border border-border rounded-lg p-4">
      <div className="flex items-center gap-2 mb-4">
        <Clock className="w-4 h-4 text-muted-foreground" strokeWidth={1.5} />
        <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          Évolution de la compréhension
        </h3>
      </div>
      <div className="relative pl-6">
        <div className="absolute left-0 top-1 bottom-1 w-px bg-border" />
        <div className="space-y-4">
          {versions.map((v, i) => (
            <div key={v.id || i} className="relative">
              <div className="absolute -left-[27px] top-1 w-3 h-3 rounded-full border-2 border-border bg-background flex items-center justify-center">
                <GitCommit className="w-2 h-2 text-muted-foreground" strokeWidth={2} />
              </div>
              <div className="flex items-center gap-2 mb-0.5">
                <span className="text-xs font-medium text-foreground">V{v.version}</span>
                <span className="brand-badge">{ENTITY_LABELS[v.entity_type] || v.entity_type}</span>
              </div>
              <p className="text-xs text-muted-foreground leading-relaxed">{v.reason || 'Modification enregistrée'}</p>
              {v.created_date && (
                <p className="text-xs text-muted-foreground mt-0.5">
                  {new Date(v.created_date).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                </p>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}