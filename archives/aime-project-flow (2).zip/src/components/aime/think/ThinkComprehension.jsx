import { Dna, Target, TrendingUp, Sparkles, AlertTriangle, Compass } from 'lucide-react';
import ConfidenceBadge from '../ConfidenceBadge';

export default function ThinkComprehension({ dna, project }) {
  const identity = dna?.identity || {};
  const state = dna?.state || {};
  const intelligence = dna?.intelligence || {};
  const confidence = dna?.confidence || {};
  const futurePaths = dna?.timeline?.futureGraph || [];

  const forces = [
    ...(intelligence.patterns || []),
    ...(state.opportunities || []),
  ].slice(0, 5);

  const faiblesses = (state.risks || []).slice(0, 5);
  const opportunites = futurePaths.slice(0, 4);

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2 mb-1">
        <Dna className="w-4 h-4 text-muted-foreground" strokeWidth={1.5} />
        <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          Voici ce que je comprends aujourd'hui
        </h3>
      </div>

      {/* Identité + Intention */}
      <div className="border border-border rounded-lg p-4">
        <div className="flex items-start justify-between mb-2">
          <div className="flex items-center gap-2">
            <Dna className="w-3.5 h-3.5 text-muted-foreground" strokeWidth={1.5} />
            <span className="text-xs text-muted-foreground">Identité</span>
          </div>
          <ConfidenceBadge score={confidence.identity} />
        </div>
        <h4 className="font-heading text-lg font-medium mb-1">{identity.name || project?.name || 'Projet'}</h4>
        <div className="flex items-start gap-2 mt-2">
          <Target className="w-3.5 h-3.5 text-muted-foreground mt-0.5 shrink-0" strokeWidth={1.5} />
          <div>
            <p className="text-xs text-muted-foreground mb-0.5">Intention</p>
            <p className="text-sm text-foreground">{identity.purpose || 'Non définie'}</p>
          </div>
        </div>
      </div>

      {/* État */}
      <div className="border border-border rounded-lg p-4">
        <div className="flex items-center gap-2 mb-2">
          <TrendingUp className="w-3.5 h-3.5 text-muted-foreground" strokeWidth={1.5} />
          <span className="text-xs text-muted-foreground">État</span>
        </div>
        <p className="text-sm font-medium mb-3">{state.maturity || 'Non évalué'}</p>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <div className="flex items-center gap-1.5 mb-1.5">
              <Sparkles className="w-3 h-3 text-success" strokeWidth={1.5} />
              <span className="text-xs text-muted-foreground">Forces</span>
            </div>
            {forces.length > 0 ? (
              <ul className="space-y-1">
                {forces.map((f, i) => (
                  <li key={i} className="text-xs text-foreground leading-relaxed">{f}</li>
                ))}
              </ul>
            ) : (
              <p className="text-xs text-muted-foreground italic">Non détecté</p>
            )}
          </div>
          <div>
            <div className="flex items-center gap-1.5 mb-1.5">
              <AlertTriangle className="w-3 h-3 text-destructive" strokeWidth={1.5} />
              <span className="text-xs text-muted-foreground">Faiblesses</span>
            </div>
            {faiblesses.length > 0 ? (
              <ul className="space-y-1">
                {faiblesses.map((f, i) => (
                  <li key={i} className="text-xs text-foreground leading-relaxed">{f}</li>
                ))}
              </ul>
            ) : (
              <p className="text-xs text-muted-foreground italic">Non détecté</p>
            )}
          </div>
        </div>
      </div>

      {/* Opportunités */}
      {opportunites.length > 0 && (
        <div className="border border-border rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <Compass className="w-3.5 h-3.5 text-muted-foreground" strokeWidth={1.5} />
            <span className="text-xs text-muted-foreground">Opportunités</span>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {opportunites.map((o, i) => (
              <span key={i} className="brand-badge">{o}</span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}