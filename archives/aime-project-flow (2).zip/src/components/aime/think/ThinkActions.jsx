import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Plus, Compass, Palette, Pencil, X, Loader2, Check } from 'lucide-react';
import { createMemoryVersion } from '@/lib/aime/memoryVersioning';

export default function ThinkActions({ project, dna, onDnaUpdated, onMemoryItemCreated, onFuturePathCreated }) {
  const [activeAction, setActiveAction] = useState(null);
  const [busy, setBusy] = useState(false);
  const navigate = useNavigate();

  // MemoryItem form
  const [miContent, setMiContent] = useState('');
  const [miType, setMiType] = useState('event');

  // FuturePath form
  const [fpScenario, setFpScenario] = useState('');
  const [fpAdvantages, setFpAdvantages] = useState('');
  const [fpRisks, setFpRisks] = useState('');

  // DNA edit form
  const [dnaPurpose, setDnaPurpose] = useState(dna?.identity?.purpose || '');

  const handleCreateMemoryItem = async () => {
    if (!miContent.trim() || !project?.id) return;
    setBusy(true);
    try {
      const me = await base44.auth.me();
      await base44.entities.MemoryItem.create({
        project_id: project.id,
        owner_id: me.id,
        type: miType,
        name: miContent.trim().slice(0, 80),
        title: miContent.trim().slice(0, 80),
        source: 'manual',
        status: 'active',
        content_text: miContent.trim(),
        category: 'manual',
      });
      onMemoryItemCreated?.();
      setMiContent('');
      setActiveAction(null);
    } catch (e) {
      console.error(e);
    }
    setBusy(false);
  };

  const handleCreateFuturePath = async () => {
    if (!fpScenario.trim() || !project?.id) return;
    setBusy(true);
    try {
      const me = await base44.auth.me();
      await base44.entities.FuturePath.create({
        project_id: project.id,
        owner_id: me.id,
        scenario: fpScenario.trim(),
        probability: 50,
        advantages: fpAdvantages.split(',').map(s => s.trim()).filter(Boolean),
        risks: fpRisks.split(',').map(s => s.trim()).filter(Boolean),
        status: 'proposed',
      });
      onFuturePathCreated?.();
      setFpScenario('');
      setFpAdvantages('');
      setFpRisks('');
      setActiveAction(null);
    } catch (e) {
      console.error(e);
    }
    setBusy(false);
  };

  const handleUpdateDna = async () => {
    if (!dnaPurpose.trim() || !dna?.id || !project?.id) return;
    setBusy(true);
    try {
      await createMemoryVersion(project.id, 'ProjectDNA', dna.id, dna, 'Avant modification intention');
      const updated = await base44.entities.ProjectDNA.update(dna.id, {
        identity: { ...dna.identity, purpose: dnaPurpose.trim() },
      });
      onDnaUpdated?.(updated);
      setActiveAction(null);
    } catch (e) {
      console.error(e);
    }
    setBusy(false);
  };

  const handleOpenStudio = () => {
    if (project?.studio_page_id) {
      navigate(`/project/${project.studio_page_id}`);
    } else {
      navigate('/studio/page');
    }
  };

  const actions = [
    { id: 'memory_item', label: 'Créer une information', icon: Plus, desc: 'Ajouter un MemoryItem' },
    { id: 'future_path', label: 'Créer une décision', icon: Compass, desc: 'Explorer un futur possible' },
    { id: 'studio', label: 'Créer un contenu', icon: Palette, desc: 'Ouvrir le Studio AIME' },
    { id: 'dna_update', label: 'Modifier le DNA', icon: Pencil, desc: 'Changer l\'intention du projet' },
  ];

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2 mb-1">
        <Plus className="w-4 h-4 text-muted-foreground" strokeWidth={1.5} />
        <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          Transformer la réflexion en action
        </h3>
      </div>

      {/* Action buttons */}
      {!activeAction && (
        <div className="grid grid-cols-2 gap-2">
          {actions.map((a) => {
            const Icon = a.icon;
            return (
              <button
                key={a.id}
                onClick={() => a.id === 'studio' ? handleOpenStudio() : setActiveAction(a.id)}
                className="text-left border border-border rounded-lg p-3 hover:bg-muted/30 transition group"
              >
                <Icon className="w-4 h-4 text-muted-foreground group-hover:text-foreground transition mb-1.5" strokeWidth={1.5} />
                <p className="text-xs font-medium text-foreground">{a.label}</p>
                <p className="text-xs text-muted-foreground">{a.desc}</p>
              </button>
            );
          })}
        </div>
      )}

      {/* MemoryItem form */}
      {activeAction === 'memory_item' && (
        <div className="border border-border rounded-lg p-4 space-y-3">
          <div className="flex items-center justify-between">
            <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Nouvelle information</p>
            <button onClick={() => setActiveAction(null)} className="text-muted-foreground hover:text-foreground"><X className="w-4 h-4" /></button>
          </div>
          <textarea
            value={miContent}
            onChange={(e) => setMiContent(e.target.value)}
            autoFocus
            rows={3}
            placeholder="Ex. Le projet concerne un événement en septembre 2026…"
            className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm outline-none focus:ring-1 focus:ring-ring"
          />
          <select
            value={miType}
            onChange={(e) => setMiType(e.target.value)}
            className="w-full h-9 px-3 rounded-md border border-input bg-background text-sm outline-none"
          >
            <option value="event">Événement</option>
            <option value="person">Personne</option>
            <option value="place">Lieu</option>
            <option value="document">Document</option>
            <option value="url">Lien</option>
          </select>
          <div className="flex justify-end gap-2">
            <button onClick={() => setActiveAction(null)} className="brand-outline-btn text-xs">Annuler</button>
            <button onClick={handleCreateMemoryItem} disabled={busy || !miContent.trim()} className="brand-secondary-btn text-xs">
              {busy ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
              Créer
            </button>
          </div>
        </div>
      )}

      {/* FuturePath form */}
      {activeAction === 'future_path' && (
        <div className="border border-border rounded-lg p-4 space-y-3">
          <div className="flex items-center justify-between">
            <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Nouvelle direction</p>
            <button onClick={() => setActiveAction(null)} className="text-muted-foreground hover:text-foreground"><X className="w-4 h-4" /></button>
          </div>
          <input
            value={fpScenario}
            onChange={(e) => setFpScenario(e.target.value)}
            autoFocus
            placeholder="Nom du scénario (ex. Lancer une campagne crowdfunding)"
            className="w-full h-9 px-3 rounded-md border border-input bg-background text-sm outline-none focus:ring-1 focus:ring-ring"
          />
          <input
            value={fpAdvantages}
            onChange={(e) => setFpAdvantages(e.target.value)}
            placeholder="Avantages (séparés par virgules)"
            className="w-full h-9 px-3 rounded-md border border-input bg-background text-sm outline-none focus:ring-1 focus:ring-ring"
          />
          <input
            value={fpRisks}
            onChange={(e) => setFpRisks(e.target.value)}
            placeholder="Risques (séparés par virgules)"
            className="w-full h-9 px-3 rounded-md border border-input bg-background text-sm outline-none focus:ring-1 focus:ring-ring"
          />
          <div className="flex justify-end gap-2">
            <button onClick={() => setActiveAction(null)} className="brand-outline-btn text-xs">Annuler</button>
            <button onClick={handleCreateFuturePath} disabled={busy || !fpScenario.trim()} className="brand-secondary-btn text-xs">
              {busy ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
              Créer
            </button>
          </div>
        </div>
      )}

      {/* DNA edit form */}
      {activeAction === 'dna_update' && (
        <div className="border border-border rounded-lg p-4 space-y-3">
          <div className="flex items-center justify-between">
            <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Modifier l'intention</p>
            <button onClick={() => setActiveAction(null)} className="text-muted-foreground hover:text-foreground"><X className="w-4 h-4" /></button>
          </div>
          <textarea
            value={dnaPurpose}
            onChange={(e) => setDnaPurpose(e.target.value)}
            autoFocus
            rows={3}
            placeholder="Nouvelle intention du projet…"
            className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm outline-none focus:ring-1 focus:ring-ring"
          />
          <p className="text-xs text-muted-foreground">Un snapshot de version sera créé avant la modification.</p>
          <div className="flex justify-end gap-2">
            <button onClick={() => setActiveAction(null)} className="brand-outline-btn text-xs">Annuler</button>
            <button onClick={handleUpdateDna} disabled={busy || !dnaPurpose.trim()} className="brand-secondary-btn text-xs">
              {busy ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
              Enregistrer
            </button>
          </div>
        </div>
      )}
    </div>
  );
}