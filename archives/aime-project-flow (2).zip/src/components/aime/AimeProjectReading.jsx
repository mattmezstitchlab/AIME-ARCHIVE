import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Dna, FileText, Image, Code, Video, Music, File, AlertTriangle, Sparkles, Clock, TrendingUp, Users, Palette, LayoutGrid } from 'lucide-react';
import { buildNarrative } from '@/lib/aime/projectDnaBuilder';
import ConfidenceBadge from './ConfidenceBadge';
import ValidationBar from './ValidationBar';
import FuturePathCard from './FuturePathCard';
import StudioGenerationCard from './StudioGenerationCard';
import ThinkTransition from './ThinkTransition';
import DesignDnaVisual from './DesignDnaVisual';
import ArchetypeBadge from './ArchetypeBadge';
import ReadinessIndicator from './ReadinessIndicator';
import BlueprintPreview from './BlueprintPreview';
import { calculateReadiness } from '@/lib/aime/readinessScore';

const TYPE_ICONS = {
  image: Image,
  document: FileText,
  code: Code,
  video: Video,
  audio: Music,
  file: File,
  url: File,
};

const CATEGORY_LABELS = {
  wedding: 'Mariage',
  music: 'Musique',
  association: 'Association',
  business: 'Business',
  education: 'Éducation',
  community: 'Communauté',
  personal: 'Personnel',
  other: 'Non identifié',
};

const ORIGIN_LABELS = {
  zip: 'ZIP',
  url: 'Site web',
  folder: 'Dossier',
  github: 'GitHub',
  manual: 'Manuel',
};

function Section({ title, icon: Icon, children, empty, confidence }) {
  return (
    <div className="border border-border rounded-lg p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Icon className="w-4 h-4 text-muted-foreground" strokeWidth={1.5} />
          <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{title}</h4>
        </div>
        {confidence !== undefined && <ConfidenceBadge score={confidence} />}
      </div>
      {empty ? (
        <p className="text-xs text-muted-foreground italic">Non détecté pour le moment.</p>
      ) : children}
    </div>
  );
}

export default function AimeProjectReading({ dna, scanResult, futurePaths = [], project, onRerun, onDnaUpdated }) {
  const [localDna, setLocalDna] = useState(dna);
  const [localProject, setLocalProject] = useState(project);
  const navigate = useNavigate();
  const identity = localDna.identity || {};
  const resources = localDna.resources || [];
  const state = localDna.state || {};
  const intelligence = localDna.intentions || localDna.intelligence || {};
  const timeline = localDna.timeline || {};
  const humans = localDna.persons || localDna.humans || [];
  const designDna = localDna.design_dna || {};
  const confidence = localDna.confidence || {};
  const archetype = localDna.archetype || 'inconnu';
  const archetypeConfidence = localDna.archetype_confidence || 0;
  const archetypeSignals = localDna.archetype_signals || [];
  const readiness = calculateReadiness({ dna: localDna, archetype });

  const fallbackScan = {
    itemCount: localProject?.item_count || 0,
    directoryCount: 0,
    totalSize: 0,
  };
  const scan = scanResult || fallbackScan;
  const narrative = buildNarrative(localDna, scan);

  const handleDnaUpdated = (updated) => {
    setLocalDna(updated);
    onDnaUpdated?.(updated);
  };

  const handleStudioCreated = (page) => {
    setLocalProject({ ...localProject, studio_page_id: page.id });
  };

  return (
    <div className="space-y-4">
      {/* Narrative header */}
      <div className="bg-secondary text-secondary-foreground rounded-lg p-5">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 opacity-70" strokeWidth={1.5} />
            <span className="text-xs font-semibold uppercase tracking-wider opacity-70">Voici ce que j'ai compris</span>
          </div>
          <ConfidenceBadge score={confidence.identity} label="Identité" />
        </div>
        <p className="text-sm leading-relaxed opacity-90 mb-4">{narrative}</p>
        <div className="flex items-center gap-2 flex-wrap">
          <ArchetypeBadge archetype={archetype} confidence={archetypeConfidence} signals={archetypeSignals} />
          <span className="brand-badge-dark">{CATEGORY_LABELS[identity.category] || identity.category}</span>
          <span className="brand-badge-dark">Origine : {ORIGIN_LABELS[identity.origin] || identity.origin}</span>
        </div>
      </div>

      {/* Readiness V1.4 */}
      <ReadinessIndicator readiness={readiness} />

      {/* Identity */}
      <div className="border border-border rounded-lg p-4">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <Dna className="w-4 h-4 text-muted-foreground" strokeWidth={1.5} />
            <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Identité</h4>
          </div>
          <ConfidenceBadge score={confidence.identity} />
        </div>
        <h3 className="font-heading text-xl font-medium mb-1">{identity.name || localProject?.name || 'Projet'}</h3>
        <p className="text-sm text-muted-foreground">{identity.purpose}</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        <div className="border border-border rounded-lg p-3 text-center">
          <p className="text-2xl font-heading font-medium">{scan.itemCount}</p>
          <p className="text-xs text-muted-foreground">Éléments</p>
        </div>
        <div className="border border-border rounded-lg p-3 text-center">
          <p className="text-2xl font-heading font-medium">{scan.directoryCount}</p>
          <p className="text-xs text-muted-foreground">Dossiers</p>
        </div>
        <div className="border border-border rounded-lg p-3 text-center">
          <p className="text-2xl font-heading font-medium">
            {scan.totalSize > 1024 * 1024
              ? `${(scan.totalSize / 1024 / 1024).toFixed(1)} Mo`
              : `${(scan.totalSize / 1024).toFixed(0)} Ko`}
          </p>
          <p className="text-xs text-muted-foreground">Volume</p>
        </div>
      </div>

      {/* Resources */}
      <Section title="Ressources" icon={File} confidence={confidence.resources}>
        <div className="space-y-2">
          {resources.map((r, i) => {
            const Icon = TYPE_ICONS[r.type] || File;
            return (
              <div key={i} className="flex items-center gap-2 text-sm">
                <Icon className="w-4 h-4 text-muted-foreground" strokeWidth={1.5} />
                <span className="capitalize flex-1">{r.type}</span>
                <span className="font-medium">{r.count}</span>
              </div>
            );
          })}
        </div>
      </Section>

      {/* Humans */}
      <Section title="Personnes" icon={Users} empty={humans.length === 0} confidence={confidence.humans}>
        <div className="space-y-2">
          {humans.map((h, i) => (
            <div key={i} className="flex items-center gap-2 text-sm">
              <Users className="w-4 h-4 text-muted-foreground" strokeWidth={1.5} />
              <span className="flex-1">{h.name}</span>
              <span className="text-xs text-muted-foreground">{h.role}</span>
            </div>
          ))}
        </div>
      </Section>

      {/* Timeline */}
      <Section title="Timeline" icon={Clock} empty={!timeline.present?.length && !timeline.past?.length} confidence={confidence.timeline}>
        <div className="space-y-3">
          {timeline.past?.length > 0 && (
            <div>
              <p className="text-xs text-muted-foreground mb-1">Passé</p>
              <div className="flex flex-wrap gap-1.5">
                {timeline.past.map((t, i) => (
                  <span key={i} className="brand-badge">{t}</span>
                ))}
              </div>
            </div>
          )}
          {timeline.present?.length > 0 && (
            <div>
              <p className="text-xs text-muted-foreground mb-1">Présent</p>
              <div className="flex flex-wrap gap-1.5">
                {timeline.present.slice(0, 8).map((t, i) => (
                  <span key={i} className="brand-badge">{t}</span>
                ))}
              </div>
            </div>
          )}
          {timeline.futureGraph?.length > 0 && (
            <div>
              <p className="text-xs text-muted-foreground mb-1">Futurs possibles</p>
              <div className="flex flex-wrap gap-1.5">
                {timeline.futureGraph.map((t, i) => (
                  <span key={i} className="brand-badge">{t}</span>
                ))}
              </div>
            </div>
          )}
        </div>
      </Section>

      {/* State */}
      <Section title="État" icon={TrendingUp} confidence={confidence.state}>
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-sm">
            <span className="text-muted-foreground">Maturité :</span>
            <span className="font-medium">{state.maturity}</span>
          </div>
          {state.risks?.length > 0 && (
            <div className="space-y-1">
              {state.risks.map((r, i) => (
                <div key={i} className="flex items-start gap-2 text-xs text-muted-foreground">
                  <AlertTriangle className="w-3.5 h-3.5 mt-0.5 shrink-0" strokeWidth={1.5} />
                  <span>{r}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </Section>

      {/* Patterns */}
      {intelligence.patterns?.length > 0 && (
        <Section title="Patterns détectés" icon={Sparkles} confidence={confidence.patterns}>
          <div className="flex flex-wrap gap-2">
            {intelligence.patterns.map((p, i) => (
              <span key={i} className="brand-badge">{p}</span>
            ))}
          </div>
        </Section>
      )}

      {/* Design DNA */}
      {(designDna.colors?.length > 0 || designDna.fonts?.length > 0 || designDna.layout) && (
        <>
        <Section title="Design DNA" icon={Palette} confidence={confidence.design_dna}>
          <div className="space-y-3">
            {designDna.colors?.length > 0 && (
              <div>
                <p className="text-xs text-muted-foreground mb-1.5">Couleurs</p>
                <div className="flex flex-wrap gap-1.5">
                  {designDna.colors.map((c, i) => (
                    <div key={i} className="flex items-center gap-1.5">
                      <div className="w-5 h-5 rounded border border-border" style={{ background: c }} />
                      <span className="text-xs text-muted-foreground font-mono">{c}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
            {designDna.fonts?.length > 0 && (
              <div>
                <p className="text-xs text-muted-foreground mb-1.5">Polices</p>
                <div className="flex flex-wrap gap-1.5">
                  {designDna.fonts.map((f, i) => (
                    <span key={i} className="brand-badge">{f}</span>
                  ))}
                </div>
              </div>
            )}
            {designDna.layout && (
              <div className="flex items-center gap-2 text-sm">
                <span className="text-muted-foreground">Layout :</span>
                <span className="font-medium capitalize">{designDna.layout}</span>
                {designDna.style && (
                  <>
                    <span className="text-muted-foreground">·</span>
                    <span className="font-medium capitalize">{designDna.style}</span>
                  </>
                )}
              </div>
            )}
          </div>
        </Section>
        <DesignDnaVisual designDna={designDna} projectName={identity.name} />
        </>
      )}

      {/* Future paths */}
      {futurePaths.length > 0 && (
        <Section title="Futurs possibles" icon={Clock} confidence={confidence.intentions}>
          <div className="space-y-2">
            {futurePaths.map((fp, i) => (
              <FuturePathCard
                key={fp.id || i}
                futurePath={fp}
                dna={localDna}
                project={localProject}
                onLaunched={(page) => handleStudioCreated(page)}
              />
            ))}
          </div>
        </Section>
      )}

      {/* Studio AIME generation — V1.4 Blueprint */}
      <BlueprintPreview
        dna={localDna}
        project={localProject}
        archetype={archetype}
        onCreated={handleStudioCreated}
      />

      {/* Partition Vivante — cockpit central du projet */}
      {localProject?.id && (
        <button
          onClick={() => navigate(`/aime/project/${localProject.id}/dna`)}
          className="w-full text-left border border-border rounded-lg p-4 hover:bg-muted/30 transition group"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-foreground text-background flex items-center justify-center shrink-0">
              <LayoutGrid className="w-5 h-5" strokeWidth={1.5} />
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium text-foreground">Partition Vivante™</p>
              <p className="text-xs text-muted-foreground">Le cockpit global de votre projet — identité, mémoire, temps, création, futurs</p>
            </div>
            <span className="brand-badge-dark">V1.3</span>
          </div>
        </button>
      )}

      {/* AIME THINK transition */}
      <ThinkTransition project={localProject} />

      {/* Validation AI + ME */}
      <ValidationBar
        dna={localDna}
        projectId={localProject?.id}
        onUpdated={handleDnaUpdated}
        onRerun={onRerun}
      />
    </div>
  );
}