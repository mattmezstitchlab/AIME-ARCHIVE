import { Bot, Plus, Check, Clock } from 'lucide-react';

/**
 * Visualisation de la boucle AI + ME.
 * AI : Analyse → + Enrichissement → ME : Validation → Mémoire évolutive
 */
export default function AiMeLoop({ validationState, versionCount }) {
  const steps = [
    { icon: Bot, label: 'AI', sublabel: 'Analyse', active: true },
    { icon: Plus, label: '+', sublabel: 'Enrichissement', active: true },
    { icon: Check, label: 'ME', sublabel: 'Validation', active: validationState?.status === 'validated' },
    { icon: Clock, label: '⟳', sublabel: 'Mémoire évolutive', active: versionCount > 0 },
  ];

  return (
    <div className="border border-border rounded-lg p-5 bg-background">
      <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-4">
        La boucle AI + ME
      </h3>
      <div className="flex items-center justify-between gap-2">
        {steps.map((step, i) => {
          const Icon = step.icon;
          return (
            <div key={i} className="flex items-center gap-2 flex-1">
              <div className="flex flex-col items-center gap-1.5 flex-1">
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center border transition ${
                    step.active
                      ? 'bg-foreground text-background border-foreground'
                      : 'bg-muted text-muted-foreground border-border'
                  }`}
                >
                  <Icon className="w-4 h-4" strokeWidth={1.5} />
                </div>
                <span className="text-xs font-medium text-foreground">{step.label}</span>
                <span className="text-[10px] text-muted-foreground text-center">{step.sublabel}</span>
              </div>
              {i < steps.length - 1 && (
                <div className={`h-px flex-1 ${step.active ? 'bg-foreground/30' : 'bg-border'}`} />
              )}
            </div>
          );
        })}
      </div>
      <p className="text-xs text-muted-foreground mt-4 text-center italic">
        L'IA analyse et enrichit. Vous validez. La mémoire évolue.
      </p>
    </div>
  );
}