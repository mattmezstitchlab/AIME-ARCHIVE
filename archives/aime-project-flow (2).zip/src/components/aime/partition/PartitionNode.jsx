import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Dna, FileText, Clock, Palette, Users, Compass, ChevronRight, X, Loader2 } from 'lucide-react';
import { createStudioForProject } from '@/lib/aime/studioGenerator';

const BRANCH_ICONS = {
  IDENTITÉ: Dna,
  MÉMOIRE: FileText,
  TEMPS: Clock,
  CRÉATION: Palette,
  RELATIONS: Users,
  FUTURS: Compass,
};

/**
 * Un nœud de la Partition Vivante — une branche avec ses sous-éléments cliquables.
 * Chaque sous-élément déclenche une action : ouvrir THINK, lister des données, ouvrir le Studio.
 */
export default function PartitionNode({ title, items, project, dna, onOpenDetail }) {
  const [hovered, setHovered] = useState(null);
  const [creatingStudio, setCreatingStudio] = useState(false);
  const navigate = useNavigate();
  const Icon = BRANCH_ICONS[title] || Dna;

  const handleClick = async (item) => {
    const action = item.action;
    if (!action) return;

    if (action.type === 'think') {
      // Ouvre THINK avec une question contextuelle
      navigate(`/aime/think?project=${project.id}&q=${encodeURIComponent(action.question)}`);
    } else if (action.type === 'detail') {
      // Ovre un panneau de détail dans la page
      onOpenDetail?.({ branch: title, item: item.label, kind: action.kind });
    } else if (action.type === 'studio') {
      if (project.studio_page_id) {
        navigate(`/studio/page/${project.studio_page_id}`);
      } else {
        // Créer le Studio avec le contexte du projet (DNA, archetype, design)
        setCreatingStudio(true);
        try {
          const page = await createStudioForProject(dna, project);
          navigate(`/studio/page/${page.id}`);
        } catch (e) {
          console.error('Studio creation failed:', e);
        }
        setCreatingStudio(false);
      }
    }
  };

  return (
    <div className="border border-border rounded-lg p-4 bg-background hover:border-foreground/20 transition group">
      <div className="flex items-center gap-2 mb-3">
        <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center">
          <Icon className="w-4 h-4 text-foreground" strokeWidth={1.5} />
        </div>
        <h3 className="text-xs font-semibold uppercase tracking-wider text-foreground">{title}</h3>
      </div>
      <div className="space-y-1">
        {items.map((item, i) => (
          <button
            key={i}
            onClick={() => handleClick(item)}
            onMouseEnter={() => setHovered(i)}
            onMouseLeave={() => setHovered(null)}
            className="w-full text-left flex items-center gap-2 px-2 py-1.5 rounded-md hover:bg-muted/50 transition text-sm"
          >
            <span className="text-muted-foreground flex-1">{item.label}</span>
            <ChevronRight
              className={`w-3.5 h-3.5 text-muted-foreground transition ${hovered === i ? 'translate-x-0.5' : ''}`}
              strokeWidth={1.5}
            />
          </button>
        ))}
      </div>
    </div>
  );
}