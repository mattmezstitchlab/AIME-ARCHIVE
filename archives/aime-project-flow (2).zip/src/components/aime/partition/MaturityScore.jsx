import { TrendingUp } from 'lucide-react';

/**
 * Score de maturité global du projet.
 * Affiche une barre de progression et le breakdown par composante.
 */
export default function MaturityScore({ maturity }) {
  if (!maturity) return null;
  const { score, level, breakdown } = maturity;
  const bars = [
    { label: 'Compréhension', value: breakdown.comprehension },
    { label: 'Ressources', value: breakdown.resources },
    { label: 'Identité', value: breakdown.identity },
    { label: 'Création', value: breakdown.creation },
    { label: 'Décision', value: breakdown.decision },
  ];

  return (
    <div className="border border-border rounded-lg p-5 bg-background">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-muted-foreground" strokeWidth={1.5} />
          <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Maturité du projet
          </h3>
        </div>
        <span className="brand-badge">{level}</span>
      </div>

      {/* Score global */}
      <div className="mb-4">
        <div className="flex items-baseline gap-2 mb-2">
          <span className="font-heading text-3xl font-medium tracking-tight">{score}</span>
          <span className="text-sm text-muted-foreground">/ 100</span>
        </div>
        <div className="h-2 rounded-full bg-muted overflow-hidden">
          <div
            className="h-full bg-foreground rounded-full transition-all duration-700"
            style={{ width: `${score}%` }}
          />
        </div>
      </div>

      {/* Breakdown par composante */}
      <div className="space-y-2">
        {bars.map((b) => (
          <div key={b.label} className="flex items-center gap-3">
            <span className="text-xs text-muted-foreground w-28 shrink-0">{b.label}</span>
            <div className="flex-1 h-1.5 rounded-full bg-muted overflow-hidden">
              <div
                className="h-full bg-foreground/60 rounded-full transition-all duration-500"
                style={{ width: `${b.value}%` }}
              />
            </div>
            <span className="text-xs font-medium text-muted-foreground w-8 text-right">{b.value}</span>
          </div>
        ))}
      </div>
    </div>
  );
}