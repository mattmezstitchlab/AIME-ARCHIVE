import { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Check, Pencil, Plus, RotateCcw, X, Loader2 } from 'lucide-react';
import { createMemoryVersion } from '@/lib/aime/memoryVersioning';

const CATEGORY_OPTIONS = [
  { value: 'wedding', label: 'Mariage' },
  { value: 'music', label: 'Musique' },
  { value: 'association', label: 'Association' },
  { value: 'business', label: 'Business' },
  { value: 'education', label: 'Éducation' },
  { value: 'community', label: 'Communauté' },
  { value: 'personal', label: 'Personnel' },
  { value: 'other', label: 'Autre' },
];

export default function ValidationBar({ dna, projectId, onUpdated, onRerun }) {
  const [mode, setMode] = useState('idle'); // idle | editing | adding
  const [busy, setBusy] = useState(false);
  const [name, setName] = useState(dna.identity?.name || '');
  const [purpose, setPurpose] = useState(dna.identity?.purpose || '');
  const [category, setCategory] = useState(dna.identity?.category || 'other');
  const [note, setNote] = useState('');
  const validation = dna.validation || { status: 'pending' };
  const isValidated = validation.status === 'validated';

  const updateDna = async (patch, reason) => {
    setBusy(true);
    try {
      if (projectId && reason) {
        await createMemoryVersion(projectId, 'ProjectDNA', dna.id, dna, reason);
      }
      const updated = await base44.entities.ProjectDNA.update(dna.id, patch);
      onUpdated?.(updated);
    } catch (e) {
      console.error(e);
    }
    setBusy(false);
  };

  const handleValidate = () => {
    updateDna(
      { validation: { status: 'validated', validated_at: new Date().toISOString() } },
      'Avant validation humaine'
    );
  };

  const handleSaveEdit = () => {
    updateDna(
      { identity: { ...dna.identity, name, purpose, category } },
      'Avant modification identité'
    );
    setMode('idle');
  };

  const handleSaveNote = async () => {
    if (!note.trim()) { setMode('idle'); return; }
    setBusy(true);
    try {
      const me = await base44.auth.me();
      if (projectId) {
        await base44.entities.MemoryItem.create({
          project_id: projectId,
          owner_id: me.id,
          type: 'event',
          name: note.trim().slice(0, 80),
          title: note.trim().slice(0, 80),
          source: 'manual',
          status: 'active',
          content_text: note.trim(),
          category: 'manual',
        });
      }
      const notes = [...(validation.notes || []), { text: note.trim(), at: new Date().toISOString() }];
      const updated = await base44.entities.ProjectDNA.update(dna.id, {
        validation: { ...validation, notes },
      });
      onUpdated?.(updated);
    } catch (e) {
      console.error(e);
    }
    setBusy(false);
    setNote('');
    setMode('idle');
  };

  if (mode === 'editing') {
    return (
      <div className="border border-border rounded-lg p-4 space-y-3">
        <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Modifier l'identité</p>
        <div>
          <label className="text-xs text-muted-foreground mb-1 block">Nom du projet</label>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full h-9 px-3 rounded-md border border-input bg-background text-sm outline-none focus:ring-1 focus:ring-ring"
          />
        </div>
        <div>
          <label className="text-xs text-muted-foreground mb-1 block">Intention</label>
          <textarea
            value={purpose}
            onChange={(e) => setPurpose(e.target.value)}
            rows={2}
            className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm outline-none focus:ring-1 focus:ring-ring"
          />
        </div>
        <div>
          <label className="text-xs text-muted-foreground mb-1 block">Catégorie</label>
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="w-full h-9 px-3 rounded-md border border-input bg-background text-sm outline-none"
          >
            {CATEGORY_OPTIONS.map((o) => (
              <option key={o.value} value={o.value}>{o.label}</option>
            ))}
          </select>
        </div>
        <div className="flex justify-end gap-2">
          <button onClick={() => setMode('idle')} className="brand-outline-btn text-xs">
            <X className="w-3.5 h-3.5" /> Annuler
          </button>
          <button onClick={handleSaveEdit} disabled={busy} className="brand-secondary-btn text-xs">
            {busy ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
            Enregistrer
          </button>
        </div>
      </div>
    );
  }

  if (mode === 'adding') {
    return (
      <div className="border border-border rounded-lg p-4 space-y-3">
        <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Ajouter une information</p>
        <textarea
          value={note}
          onChange={(e) => setNote(e.target.value)}
          autoFocus
          rows={3}
          placeholder="Ex. Le projet concerne un événement en septembre 2026…"
          className="w-full px-3 py-2 rounded-md border border-input bg-background text-sm outline-none focus:ring-1 focus:ring-ring"
        />
        <div className="flex justify-end gap-2">
          <button onClick={() => setMode('idle')} className="brand-outline-btn text-xs">
            <X className="w-3.5 h-3.5" /> Annuler
          </button>
          <button onClick={handleSaveNote} disabled={busy} className="brand-secondary-btn text-xs">
            {busy ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Plus className="w-3.5 h-3.5" />}
            Ajouter
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="border border-border rounded-lg p-4">
      <div className="flex items-center justify-between mb-3">
        <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          Validation {isValidated ? '' : '— AI + ME'}
        </p>
        {isValidated && (
          <span className="inline-flex items-center gap-1 text-xs text-success font-medium">
            <Check className="w-3.5 h-3.5" /> Validé par vous
          </span>
        )}
      </div>
      <div className="flex flex-wrap gap-2">
        {!isValidated && (
          <button onClick={handleValidate} disabled={busy} className="brand-secondary-btn text-xs">
            {busy ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
            C'est correct
          </button>
        )}
        <button onClick={() => setMode('editing')} className="brand-outline-btn text-xs">
          <Pencil className="w-3.5 h-3.5" /> Modifier
        </button>
        <button onClick={() => setMode('adding')} className="brand-outline-btn text-xs">
          <Plus className="w-3.5 h-3.5" /> Ajouter une information
        </button>
        {onRerun && (
          <button onClick={onRerun} disabled={busy} className="brand-outline-btn text-xs">
            <RotateCcw className="w-3.5 h-3.5" /> Relancer l'analyse
          </button>
        )}
      </div>
      {validation.notes?.length > 0 && (
        <div className="mt-3 pt-3 border-t border-border space-y-1.5">
          {validation.notes.map((n, i) => (
            <div key={i} className="flex items-start gap-2 text-xs">
              <Plus className="w-3 h-3 mt-0.5 shrink-0 text-muted-foreground" />
              <span className="text-muted-foreground">{n.text}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}