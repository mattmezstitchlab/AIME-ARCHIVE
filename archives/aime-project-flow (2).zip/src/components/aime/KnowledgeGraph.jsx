import { Sparkles, Users, FileText, Compass, Clock, Palette, TrendingUp, Bot } from 'lucide-react';
import { getGraphStats } from '@/lib/aime/knowledgeGraph';

const NODE_ICONS = {
  project: Sparkles,
  person: Users,
  resource: FileText,
  decision: Compass,
  moments: Clock,
  creation: Palette,
  opportunities: TrendingUp,
  reflections: Bot,
};

const NODE_COLORS = {
  project: 'bg-foreground text-background',
  person: 'bg-muted text-foreground',
  resource: 'bg-muted text-foreground',
  decision: 'bg-muted text-foreground',
  moments: 'bg-muted text-foreground',
  creation: 'bg-muted text-foreground',
  opportunities: 'bg-muted text-foreground',
  reflections: 'bg-muted text-foreground',
};

/**
 * Knowledge Graph — visualisation relationnelle du projet.
 * Affiche le nœud Projet au centre avec ses branches.
 */
export default function KnowledgeGraph({ graph }) {
  if (!graph || graph.nodes.length <= 1) {
    return (
      <div className="border border-border rounded-lg p-6 text-center">
        <p className="text-xs text-muted-foreground italic">
          Le graphe de connaissances se construit à mesure que le projet est enrichi.
        </p>
      </div>
    );
  }

  const stats = getGraphStats(graph);
  const projectNode = graph.nodes.find((n) => n.type === 'project');
  const childNodes = graph.nodes.filter((n) => n.type !== 'project');

  return (
    <div className="border border-border rounded-lg p-5 bg-background">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-muted-foreground" strokeWidth={1.5} />
          <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Knowledge Graph
          </h4>
        </div>
        <span className="text-xs text-muted-foreground font-mono">
          {stats.totalNodes} nœuds · {stats.totalEdges} liens
        </span>
      </div>

      {/* Graphe — layout radial simple */}
      <div className="flex flex-col items-center">
        {/* Nœud central */}
        <div className="flex flex-col items-center mb-4">
          <div className="w-14 h-14 rounded-full bg-foreground text-background flex items-center justify-center">
            <Sparkles className="w-5 h-5" strokeWidth={1.5} />
          </div>
          <span className="text-xs font-semibold uppercase tracking-wider text-foreground mt-1.5 text-center max-w-[160px] truncate">
            {projectNode?.label}
          </span>
        </div>

        {/* Ligne de connexion */}
        <div className="h-4 w-px bg-border mb-2" />

        {/* Nœuds enfants en grille */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-2 w-full">
          {childNodes.map((node) => {
            const Icon = NODE_ICONS[node.type] || FileText;
            return (
              <div
                key={node.id}
                className="border border-border rounded-md p-2.5 hover:bg-muted/30 transition"
              >
                <div className="flex items-start gap-2">
                  <div className="w-7 h-7 rounded-full bg-muted flex items-center justify-center shrink-0">
                    <Icon className="w-3.5 h-3.5 text-foreground" strokeWidth={1.5} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-foreground truncate">{node.label}</p>
                    {node.sublabel && (
                      <p className="text-[10px] text-muted-foreground truncate">{node.sublabel}</p>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Légende des types */}
      <div className="flex flex-wrap gap-2 mt-4 pt-3 border-t border-border">
        {Object.entries(stats.typeCounts).filter(([t]) => t !== 'project').map(([type, count]) => (
          <span key={type} className="brand-badge capitalize">
            {type} · {count}
          </span>
        ))}
      </div>
    </div>
  );
}