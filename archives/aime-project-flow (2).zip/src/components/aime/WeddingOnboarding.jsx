import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Heart, Loader2, ArrowRight, Calendar, MapPin, Users, Sparkles } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

const AMBIANCES = [
  { id: 'intimiste', label: 'Intimiste', note: 'Peu d\'invités, chaleureux' },
  { id: 'classique', label: 'Classique', note: 'Élégant et traditionnel' },
  { id: 'nature', label: 'Nature', note: 'En plein air, organique' },
  { id: 'destination', label: 'Destination', note: 'Voyage et découverte' },
  { id: 'festif', label: 'Festif', note: 'Ambiance et danse' },
  { id: 'spirituel', label: 'Spirituel', note: 'Cérémoniel et sens' },
];

const AVANCEMENTS = [
  { id: 'debut', label: 'On commence', note: 'Rien n\'est fixé' },
  { id: 'idees', label: 'On a des idées', note: 'Direction claire, détails à préciser' },
  { id: 'organise', label: 'On organise', note: 'Date et lieu en cours' },
  { id: 'avance', label: 'C\'est avancé', note: 'Prestataires en cours' },
  { id: 'pret', label: 'Presque prêt', note: 'Finalisation' },
];

const MONTHS = ['janvier', 'février', 'fevrier', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'aout', 'septembre', 'octobre', 'novembre', 'décembre', 'decembre'];

function parseIntro(text) {
  const result = { date: '', location: '', guestCount: '' };
  if (!text) return result;
  const guestMatch = text.match(/(\d+)\s*invit/i);
  if (guestMatch) result.guestCount = guestMatch[1];
  const dateRegex = new RegExp(`(${MONTHS.join('|')})\\s+(\\d{4})`, 'i');
  const dateMatch = text.match(dateRegex);
  if (dateMatch) {
    const idx = MONTHS.findIndex((m) => m.toLowerCase() === dateMatch[1].toLowerCase()) % 12;
    result.date = `${dateMatch[2]}-${String(idx + 1).padStart(2, '0')}-01`;
  }
  const locMatch = text.match(/(?:dans un|dans une|dans|à|au)\s+([a-zàâäéèêëïîôöùûüç' -]{3,40})/i);
  if (locMatch) result.location = locMatch[1].trim().replace(/[.,;].*$/, '');
  return result;
}

export default function WeddingOnboarding({ open, onClose, onComplete, initialDescription = '' }) {
  const navigate = useNavigate();
  const parsed = parseIntro(initialDescription);
  const [step, setStep] = useState(0);
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState({
    partner1: '',
    partner2: '',
    date: parsed.date,
    location: parsed.location,
    ambiance: '',
    guestCount: parsed.guestCount,
    avancement: '',
  });

  const update = (key, val) => setForm((f) => ({ ...f, [key]: val }));

  const canNext = step === 0
    ? (form.partner1.trim() || form.partner2.trim())
    : step === 1
    ? true
    : step === 2
    ? true
    : true;

  const handleCreate = async () => {
    setCreating(true);
    try {
      const me = await base44.auth.me();
      const p1 = form.partner1.trim() || 'Prénom 1';
      const p2 = form.partner2.trim() || 'Prénom 2';
      const coupleName = `${p1} & ${p2}`;
      const hasDate = !!form.date;
      const hasLocation = !!form.location.trim();
      const hasGuests = !!form.guestCount;
      const hasAmbiance = !!form.ambiance;

      // Build initial DNA from onboarding data
      const purpose = `Notre mariage${hasAmbiance ? ` — ${AMBIANCES.find(a => a.id === form.ambiance)?.label || ''}` : ''}`;
      const timelinePresent = [];
      if (hasDate) timelinePresent.push(`Mariage le ${form.date}`);
      if (hasLocation) timelinePresent.push(`Lieu : ${form.location}`);
      if (!hasDate && !hasLocation) timelinePresent.push('Date et lieu à définir');

      const project = await base44.entities.AimeProject.create({
        name: coupleName,
        category: 'wedding',
        status: 'active',
        owner_id: me.id,
        source_type: 'manual',
        item_count: 0,
      });

      const dna = await base44.entities.ProjectDNA.create({
        project_id: project.id,
        owner_id: me.id,
        identity: {
          name: coupleName,
          purpose,
          category: 'wedding',
          origin: 'Onboarding mariage',
        },
        archetype: 'mariage',
        archetype_confidence: 100,
        archetype_signals: ['Onboarding explicite', 'Catégorie wedding', 'Couple renseigné'],
        humans: [
          { name: p1, role: 'époux(se)', type: 'person' },
          { name: p2, role: 'époux(se)', type: 'person' },
        ],
        persons: [
          { name: p1, role: 'époux(se)', type: 'person' },
          { name: p2, role: 'époux(se)', type: 'person' },
        ],
        resources: [],
        timeline: {
          past: [],
          present: timelinePresent,
          futureGraph: hasDate ? ['Cérémonie', 'Réception', 'Voyage de noces'] : ['Définir la date', 'Réserver le lieu', 'Cérémonie', 'Réception'],
        },
        state: {
          maturity: form.avancement || 'debut',
          risks: !hasDate ? ['Date non définie'] : [],
          opportunities: hasAmbiance ? [`${AMBIANCES.find(a => a.id === form.ambiance)?.label}`] : [],
        },
        intelligence: { patterns: [], risks: [], opportunities: [], scenarios: [] },
        intentions: {
          patterns: hasAmbiance ? [form.ambiance] : [],
          risks: [],
          opportunities: [],
          scenarios: [],
        },
        design_dna: {
          colors: [],
          fonts: [],
          layout: '',
          style: form.ambiance || '',
          visual_references: [],
          emotional_style: form.ambiance || '',
          visual_patterns: [],
          composition_rules: [],
        },
        confidence: {
          identity: 85,
          resources: 10,
          humans: 90,
          timeline: hasDate ? 75 : 25,
          state: 40,
          patterns: 30,
          design_dna: hasAmbiance ? 50 : 15,
          intentions: 40,
        },
        validation: { status: 'pending', notes: [] },
        validation_state: { status: 'pending', notes: [] },
      });

      toast({ title: 'Projet mariage créé', description: `${coupleName} est en mémoire AIME.` });
      onComplete?.(project, dna);
      navigate(`/aime/project/${project.id}/dna`);
    } catch (e) {
      console.error(e);
      toast({ title: 'Création impossible', description: e.message, variant: 'destructive' });
    }
    setCreating(false);
  };

  const handleClose = () => {
    setStep(0);
    setForm({ partner1: '', partner2: '', date: '', location: '', ambiance: '', guestCount: '', avancement: '' });
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && handleClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <div className="flex items-center gap-2 mb-1">
            <Heart className="w-5 h-5 text-foreground" strokeWidth={1.5} />
            <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">AIME Mariage</span>
          </div>
          <DialogTitle className="font-heading text-2xl">Commencer votre mariage</DialogTitle>
          <DialogDescription className="text-sm">
            {initialDescription
              ? "AIME a lu votre message et pré-rempli ce qu'il a compris — vérifiez et complétez."
              : "Quelques informations. Tout peut rester vide — AIME s'adaptera."}
          </DialogDescription>
        </DialogHeader>

        {step === 0 && (
          <div className="space-y-4 py-2">
            <div>
              <Label className="text-xs text-muted-foreground mb-1.5 block">Vous êtes</Label>
              <div className="grid grid-cols-2 gap-3">
                <Input
                  value={form.partner1}
                  onChange={(e) => update('partner1', e.target.value)}
                  placeholder="Prénom 1"
                  className="h-11"
                />
                <Input
                  value={form.partner2}
                  onChange={(e) => update('partner2', e.target.value)}
                  placeholder="Prénom 2"
                  className="h-11"
                />
              </div>
            </div>
            <div className="flex justify-end pt-2">
              <Button onClick={() => setStep(1)} disabled={!canNext} className="gap-2">
                Continuer <ArrowRight className="w-4 h-4" />
              </Button>
            </div>
          </div>
        )}

        {step === 1 && (
          <div className="space-y-4 py-2">
            <div>
              <Label className="text-xs text-muted-foreground mb-1.5 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5" /> Date du mariage <span className="text-muted-foreground/60">(si connue)</span>
              </Label>
              <Input
                type="date"
                value={form.date}
                onChange={(e) => update('date', e.target.value)}
                className="h-11"
              />
            </div>
            <div>
              <Label className="text-xs text-muted-foreground mb-1.5 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5" /> Lieu <span className="text-muted-foreground/60">(si connu)</span>
              </Label>
              <Input
                value={form.location}
                onChange={(e) => update('location', e.target.value)}
                placeholder="Ville, région ou type de lieu"
                className="h-11"
              />
            </div>
            <div>
              <Label className="text-xs text-muted-foreground mb-1.5 flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5" /> Invités environ <span className="text-muted-foreground/60">(si estimé)</span>
              </Label>
              <Input
                type="number"
                value={form.guestCount}
                onChange={(e) => update('guestCount', e.target.value)}
                placeholder="45"
                className="h-11"
              />
            </div>
            <div className="flex justify-between pt-2">
              <Button variant="outline" onClick={() => setStep(0)}>Retour</Button>
              <Button onClick={() => setStep(2)} className="gap-2">
                Continuer <ArrowRight className="w-4 h-4" />
              </Button>
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-4 py-2">
            <div>
              <Label className="text-xs text-muted-foreground mb-2 block">Ambiance souhaitée</Label>
              <div className="grid grid-cols-2 gap-2">
                {AMBIANCES.map((a) => (
                  <button
                    key={a.id}
                    onClick={() => update('ambiance', a.id)}
                    className={`text-left p-3 rounded-lg border transition ${form.ambiance === a.id ? 'border-foreground bg-muted' : 'border-border hover:bg-muted/50'}`}
                  >
                    <p className="text-sm font-medium">{a.label}</p>
                    <p className="text-xs text-muted-foreground">{a.note}</p>
                  </button>
                ))}
              </div>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground mb-2 block">Où en êtes-vous ?</Label>
              <div className="grid grid-cols-1 gap-2">
                {AVANCEMENTS.map((a) => (
                  <button
                    key={a.id}
                    onClick={() => update('avancement', a.id)}
                    className={`text-left p-3 rounded-lg border transition flex items-center justify-between ${form.avancement === a.id ? 'border-foreground bg-muted' : 'border-border hover:bg-muted/50'}`}
                  >
                    <div>
                      <p className="text-sm font-medium">{a.label}</p>
                      <p className="text-xs text-muted-foreground">{a.note}</p>
                    </div>
                    {form.avancement === a.id && <Sparkles className="w-4 h-4" strokeWidth={1.5} />}
                  </button>
                ))}
              </div>
            </div>
            <div className="flex justify-between pt-2">
              <Button variant="outline" onClick={() => setStep(1)}>Retour</Button>
              <Button onClick={handleCreate} disabled={creating} className="gap-2">
                {creating ? <><Loader2 className="w-4 h-4 animate-spin" /> Création…</> : <><Heart className="w-4 h-4" /> Créer notre mariage</>}
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}