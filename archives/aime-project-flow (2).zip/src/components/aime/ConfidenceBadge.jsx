export default function ConfidenceBadge({ score, label }) {
  const value = Math.round(score || 0);
  const color =
    value >= 80 ? 'text-success' :
    value >= 60 ? 'text-foreground' :
    'text-muted-foreground';
  const ring =
    value >= 80 ? 'border-success/40 bg-success/5' :
    value >= 60 ? 'border-border bg-muted/50' :
    'border-border bg-background';

  return (
    <div className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full border ${ring}`}>
      <span className={`text-xs font-heading font-semibold ${color}`}>{value}%</span>
      {label && <span className="text-[10px] text-muted-foreground uppercase tracking-wider">{label}</span>}
    </div>
  );
}