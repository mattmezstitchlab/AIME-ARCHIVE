import { useNavigate } from 'react-router-dom';
import { Bot, ArrowRight } from 'lucide-react';

export default function ThinkTransition({ project }) {
  const navigate = useNavigate();
  return (
    <div className="border border-border rounded-lg p-4 bg-muted/30">
      <div className="flex items-center gap-2 mb-2">
        <Bot className="w-4 h-4 text-muted-foreground" strokeWidth={1.5} />
        <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Vers AIME THINK™</h4>
      </div>
      <p className="text-sm text-muted-foreground mb-3">
        Votre projet est maintenant compris. Vous pouvez continuer à réfléchir, créer ou construire.
      </p>
      <button
        onClick={() => navigate('/aime/think?project=' + (project?.id || ''))}
        className="brand-secondary-btn text-xs inline-flex"
      >
        <Bot className="w-3.5 h-3.5" strokeWidth={1.5} />
        Parler avec AIME
        <ArrowRight className="w-3.5 h-3.5" strokeWidth={1.5} />
      </button>
    </div>
  );
}