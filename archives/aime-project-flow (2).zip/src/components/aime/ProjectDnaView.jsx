import { Dna, FileText, Image, Code, Video, Music, File, AlertTriangle, Sparkles, Clock, TrendingUp } from 'lucide-react';

const TYPE_ICONS = {
  image: Image,
  document: FileText,
  code: Code,
  video: Video,
  audio: Music,
  file: File,
};

const CATEGORY_LABELS = {
  wedding: 'Mariage',
  music: 'Musique',
  association: 'Association',
  business: 'Business',
  education: 'Éducation',
  community: 'Communauté',
  personal: 'Personnel',
  other: 'Non identifié',
};

function Section({ title, icon: Icon, children }) {
  return (
    <div className="border border-border rounded-lg p-4">
      <div className="flex items-center gap-2 mb-3">
        <Icon className="w-4 h-4 text-muted-foreground" strokeWidth={1.5} />
        <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{title}</h4>
      </div>
      {children}
    </div>
  );
}

export default function ProjectDnaView({ dna, scanResult, futurePaths = [] }) {
  const identity = dna.identity || {};
  const resources = dna.resources || [];
  const state = dna.state || {};
  const intelligence = dna.intelligence || {};
  const timeline = dna.timeline || {};

  return (
    <div className="space-y-4">
      <div className="bg-secondary text-secondary-foreground rounded-lg p-5">
        <div className="flex items-center gap-2 mb-2">
          <Dna className="w-5 h-5" strokeWidth={1.5} />
          <span className="text-xs font-semibold uppercase tracking-wider opacity-70">Project DNA</span>
        </div>
        <h3 className="font-heading text-2xl font-medium mb-1">{identity.name || 'Projet'}</h3>
        <p className="text-sm opacity-60">{identity.purpose}</p>
        <div className="flex items-center gap-2 mt-3">
          <span className="brand-badge-dark">{CATEGORY_LABELS[identity.category] || identity.category}</span>
          <span className="brand-badge-dark">Origine : {identity.origin}</span>
        </div>
      </div>

      {scanResult && (
        <div className="grid grid-cols-3 gap-3">
          <div className="border border-border rounded-lg p-3 text-center">
            <p className="text-2xl font-heading font-medium">{scanResult.itemCount}</p>
            <p className="text-xs text-muted-foreground">Éléments</p>
          </div>
          <div className="border border-border rounded-lg p-3 text-center">
            <p className="text-2xl font-heading font-medium">{scanResult.directoryCount}</p>
            <p className="text-xs text-muted-foreground">Dossiers</p>
          </div>
          <div className="border border-border rounded-lg p-3 text-center">
            <p className="text-2xl font-heading font-medium">
              {scanResult.totalSize > 1024 * 1024
                ? `${(scanResult.totalSize / 1024 / 1024).toFixed(1)} Mo`
                : `${(scanResult.totalSize / 1024).toFixed(0)} Ko`}
            </p>
            <p className="text-xs text-muted-foreground">Volume</p>
          </div>
        </div>
      )}

      <Section title="Ressources" icon={File}>
        <div className="space-y-2">
          {resources.map((r, i) => {
            const Icon = TYPE_ICONS[r.type] || File;
            return (
              <div key={i} className="flex items-center gap-2 text-sm">
                <Icon className="w-4 h-4 text-muted-foreground" strokeWidth={1.5} />
                <span className="capitalize flex-1">{r.type}</span>
                <span className="font-medium">{r.count}</span>
              </div>
            );
          })}
        </div>
      </Section>

      <Section title="État" icon={TrendingUp}>
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-sm">
            <span className="text-muted-foreground">Maturité :</span>
            <span className="font-medium">{state.maturity}</span>
          </div>
          {state.risks?.length > 0 && (
            <div className="space-y-1">
              {state.risks.map((r, i) => (
                <div key={i} className="flex items-start gap-2 text-xs text-muted-foreground">
                  <AlertTriangle className="w-3.5 h-3.5 mt-0.5 shrink-0" strokeWidth={1.5} />
                  <span>{r}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </Section>

      {intelligence.patterns?.length > 0 && (
        <Section title="Patterns détectés" icon={Sparkles}>
          <div className="flex flex-wrap gap-2">
            {intelligence.patterns.map((p, i) => (
              <span key={i} className="brand-badge">{p}</span>
            ))}
          </div>
        </Section>
      )}

      {futurePaths.length > 0 && (
        <Section title="Futurs possibles" icon={Clock}>
          <div className="space-y-2">
            {futurePaths.map((fp, i) => (
              <div key={i} className="border border-border rounded-md p-3">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-medium">{fp.scenario}</span>
                  <span className="text-xs text-muted-foreground">{fp.probability}%</span>
                </div>
                <div className="flex gap-4 text-xs">
                  <div className="flex-1">
                    <p className="text-muted-foreground mb-0.5">Avantages</p>
                    <p className="text-foreground">{fp.advantages.join(', ')}</p>
                  </div>
                  <div className="flex-1">
                    <p className="text-muted-foreground mb-0.5">Risques</p>
                    <p className="text-foreground">{fp.risks.join(', ')}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Section>
      )}
    </div>
  );
}