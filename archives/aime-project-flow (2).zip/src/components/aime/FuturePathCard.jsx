import { useState } from 'react';
import { ArrowRight, Loader2 } from 'lucide-react';
import { createStudioForProject } from '@/lib/aime/studioGenerator';

export default function FuturePathCard({ futurePath, dna, project, onLaunched }) {
  const [launching, setLaunching] = useState(false);

  const handleLaunch = async () => {
    setLaunching(true);
    try {
      if (futurePath.id) {
        const { base44 } = await import('@/api/base44Client');
        await base44.entities.FuturePath.update(futurePath.id, { status: 'selected' });
      }
      const page = await createStudioForProject(dna, project);
      onLaunched?.(page);
    } catch (e) {
      console.error(e);
    }
    setLaunching(false);
  };

  return (
    <div className="border border-border rounded-md p-3">
      <div className="flex items-center justify-between mb-1">
        <span className="text-sm font-medium">{futurePath.scenario}</span>
        <span className="text-xs text-muted-foreground">{futurePath.probability}%</span>
      </div>
      <div className="flex gap-4 text-xs mb-3">
        <div className="flex-1">
          <p className="text-muted-foreground mb-0.5">Avantages</p>
          <p className="text-foreground">{futurePath.advantages?.join(', ')}</p>
        </div>
        <div className="flex-1">
          <p className="text-muted-foreground mb-0.5">Risques</p>
          <p className="text-foreground">{futurePath.risks?.join(', ')}</p>
        </div>
      </div>
      <button
        onClick={handleLaunch}
        disabled={launching}
        className="brand-outline-btn text-xs w-full"
      >
        {launching ? (
          <Loader2 className="w-3.5 h-3.5 animate-spin" />
        ) : (
          <ArrowRight className="w-3.5 h-3.5" />
        )}
        Lancer ce chemin
      </button>
    </div>
  );
}