import { useState } from 'react';
import { LayoutGrid, ChevronRight, Loader2, Sparkles, ArrowRight, Check, HelpCircle } from 'lucide-react';
import { buildStudioBlueprint, evaluateBlueprintReadiness } from '@/lib/aime/studioBlueprint';
import { createStudioForProject } from '@/lib/aime/studioGenerator';

/**
 * Blueprint Preview — affiche la structure Studio qui sera générée
 * (sections, modules, questions) et permet la création.
 */
export default function BlueprintPreview({ dna, project, archetype, onCreated }) {
  const [expanded, setExpanded] = useState(false);
  const [creating, setCreating] = useState(false);
  const [createdPageId, setCreatedPageId] = useState(project?.studio_page_id || null);

  const blueprint = buildStudioBlueprint(dna, archetype);
  const readiness = evaluateBlueprintReadiness(dna, archetype);
  const hasStudio = !!createdPageId;

  const handleCreate = async () => {
    setCreating(true);
    try {
      const page = await createStudioForProject(dna, project, archetype);
      setCreatedPageId(page.id);
      onCreated?.(page);
    } catch (e) {
      console.error(e);
    }
    setCreating(false);
  };

  const handleOpen = () => {
    window.location.href = '/studio/page';
  };

  return (
    <div className="border border-border rounded-lg p-4 bg-background">
      {/* Header */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <LayoutGrid className="w-4 h-4 text-muted-foreground" strokeWidth={1.5} />
          <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Studio Blueprint — {blueprint.label}
          </h4>
        </div>
        <span className="brand-badge">{blueprint.sections.length} sections</span>
      </div>

      <p className="text-sm text-muted-foreground mb-3">{blueprint.description}</p>

      {/* Sections preview — toujours visible */}
      <div className="space-y-1 mb-3">
        {blueprint.sections.slice(0, expanded ? undefined : 5).map((s, i) => (
          <div key={s.id} className="flex items-center gap-2 text-sm py-1">
            <span className="text-xs text-muted-foreground font-mono w-5">{String(i + 1).padStart(2, '0')}</span>
            <span className="flex-1">{s.label}</span>
            {s.required ? (
              <span className="brand-badge">Requis</span>
            ) : (
              <span className="text-xs text-muted-foreground">Optionnel</span>
            )}
          </div>
        ))}
        {!expanded && blueprint.sections.length > 5 && (
          <button
            onClick={() => setExpanded(true)}
            className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition mt-1"
          >
            <ChevronRight className="w-3 h-3" strokeWidth={1.5} />
            Voir {blueprint.sections.length - 5} sections de plus
          </button>
        )}
      </div>

      {/* Modules + Widgets */}
      {expanded && (
        <div className="space-y-3 border-t border-border pt-3 mb-3">
          <div>
            <p className="text-xs text-muted-foreground mb-1.5">Modules actifs</p>
            <div className="flex flex-wrap gap-1.5">
              {blueprint.modules.map((m, i) => (
                <span key={i} className="brand-badge">{m}</span>
              ))}
            </div>
          </div>
          <div>
            <p className="text-xs text-muted-foreground mb-1.5">Widgets</p>
            <div className="flex flex-wrap gap-1.5">
              {blueprint.widgets.map((w, i) => (
                <span key={i} className="brand-badge">{w}</span>
              ))}
            </div>
          </div>
          <div>
            <p className="text-xs text-muted-foreground mb-1.5">Direction design</p>
            <p className="text-sm">
              <span className="font-medium capitalize">{blueprint.design.mood}</span>
              <span className="text-muted-foreground"> · {blueprint.design.palette_hint}</span>
            </p>
          </div>
        </div>
      )}

      {/* Questions importantes */}
      {expanded && blueprint.questions.length > 0 && (
        <div className="border-t border-border pt-3 mb-3">
          <div className="flex items-center gap-1.5 mb-2">
            <HelpCircle className="w-3.5 h-3.5 text-muted-foreground" strokeWidth={1.5} />
            <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Questions importantes
            </p>
          </div>
          <div className="space-y-1">
            {blueprint.questions.map((q, i) => (
              <p key={i} className="text-xs text-muted-foreground italic">— {q}</p>
            ))}
          </div>
        </div>
      )}

      {/* Readiness */}
      <div className="flex items-center gap-2 mb-3 text-xs">
        <span className="text-muted-foreground">Données présentes :</span>
        <div className="flex-1 h-1.5 rounded-full bg-muted overflow-hidden">
          <div className="h-full bg-foreground/60" style={{ width: `${readiness.ratio}%` }} />
        </div>
        <span className="font-mono text-muted-foreground">{readiness.ratio}%</span>
      </div>

      {/* Action */}
      {hasStudio ? (
        <button onClick={handleOpen} className="brand-secondary-btn text-xs w-full">
          <ArrowRight className="w-3.5 h-3.5" /> Ouvrir le Studio
        </button>
      ) : (
        <button onClick={handleCreate} disabled={creating} className="brand-secondary-btn text-xs w-full">
          {creating ? (
            <Loader2 className="w-3.5 h-3.5 animate-spin" />
          ) : (
            <Sparkles className="w-3.5 h-3.5" />
          )}
          Créer mon espace Studio AIME
        </button>
      )}
    </div>
  );
}