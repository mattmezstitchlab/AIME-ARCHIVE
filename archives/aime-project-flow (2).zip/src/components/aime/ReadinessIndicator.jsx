import { Check, AlertCircle, Loader2 } from 'lucide-react';

/**
 * Indicateur "Prêt pour Studio" — affiche le score de readiness
 * et les données manquantes.
 */
export default function ReadinessIndicator({ readiness }) {
  if (!readiness) return null;
  const { score, ready, level, threshold, breakdown, missing } = readiness;
  const Icon = ready ? Check : score >= 40 ? AlertCircle : Loader2;

  return (
    <div className={`border rounded-lg p-4 ${ready ? 'border-foreground/20 bg-foreground/5' : 'border-border'}`}>
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Icon
            className={`w-4 h-4 ${ready ? 'text-foreground' : 'text-muted-foreground'} ${!ready && score < 40 ? 'animate-spin' : ''}`}
            strokeWidth={1.5}
          />
          <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Prêt pour Studio
          </h4>
        </div>
        <div className="flex items-baseline gap-1">
          <span className="font-heading text-2xl font-medium">{score}</span>
          <span className="text-xs text-muted-foreground">/ 100</span>
        </div>
      </div>

      {/* Barre de progression */}
      <div className="h-1.5 rounded-full bg-muted overflow-hidden mb-3">
        <div
          className={`h-full transition-all ${ready ? 'bg-foreground' : 'bg-muted-foreground/40'}`}
          style={{ width: `${score}%` }}
        />
      </div>

      {/* Statut */}
      <div className="flex items-center gap-2 mb-3">
        {ready ? (
          <span className="brand-badge-dark">PRÊT — {level}</span>
        ) : (
          <span className="brand-badge">{level} — seuil {threshold}</span>
        )}
      </div>

      {/* Breakdown */}
      <div className="space-y-1.5 mb-3">
        {Object.entries(breakdown).map(([key, val]) => (
          <div key={key} className="flex items-center gap-2 text-xs">
            <span className="text-muted-foreground flex-1 capitalize">{key.replace(/_/g, ' ')}</span>
            <div className="w-20 h-1 rounded-full bg-muted overflow-hidden">
              <div className="h-full bg-foreground/60" style={{ width: `${val}%` }} />
            </div>
            <span className="font-mono text-muted-foreground w-8 text-right">{val}</span>
          </div>
        ))}
      </div>

      {/* Données manquantes */}
      {missing.length > 0 && (
        <div className="border-t border-border pt-3">
          <p className="text-xs text-muted-foreground mb-1.5">Données suggérées :</p>
          <div className="flex flex-wrap gap-1.5">
            {missing.map((m, i) => (
              <span key={i} className="brand-badge">{m}</span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}