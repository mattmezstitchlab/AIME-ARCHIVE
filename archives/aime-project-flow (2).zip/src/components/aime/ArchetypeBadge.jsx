import { Sparkles } from 'lucide-react';
import { ARCHETYPE_LABELS } from '@/lib/aime/archetypeDetector';

/**
 * Badge visuel affichant l'archetype détecté + score de confiance.
 */
export default function ArchetypeBadge({ archetype, confidence, signals = [], size = 'default' }) {
  const label = ARCHETYPE_LABELS[archetype] || 'INCONNU';
  const isUnknown = archetype === 'inconnu' || !archetype;
  const sizeClasses = size === 'sm' ? 'text-[10px] px-2 py-1' : 'text-xs px-3 py-1.5';

  return (
    <div className="inline-flex items-center gap-2">
      <div
        className={`inline-flex items-center gap-1.5 rounded-full font-semibold uppercase tracking-wider ${sizeClasses} ${
          isUnknown
            ? 'bg-muted text-muted-foreground'
            : 'bg-foreground text-background'
        }`}
      >
        <Sparkles className={size === 'sm' ? 'w-3 h-3' : 'w-3.5 h-3.5'} strokeWidth={1.5} />
        {label}
      </div>
      {!isUnknown && confidence > 0 && (
        <span className="text-xs text-muted-foreground font-mono">
          {confidence}%
        </span>
      )}
      {signals.length > 0 && size !== 'sm' && (
        <span className="text-xs text-muted-foreground italic hidden md:inline">
          {signals.slice(0, 3).join(' · ')}
        </span>
      )}
    </div>
  );
}