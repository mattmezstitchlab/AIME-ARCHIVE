import { useState, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Upload, Loader2, CheckCircle2, AlertCircle, FileArchive, FolderOpen, Globe, ArrowRight, Github } from 'lucide-react';
import { scanZip, scanFolder } from '@/lib/aime/senseScanner';
import { buildProjectDna, buildFuturePaths } from '@/lib/aime/projectDnaBuilder';
import { rerunAnalysis } from '@/lib/aime/reanalysis';
import AimeProjectReading from './AimeProjectReading';

const STEPS = {
  IDLE: 'idle',
  SCANNING: 'scanning',
  SAVING: 'saving',
  DONE: 'done',
  ERROR: 'error',
};

const MODES = [
  { id: 'zip', label: 'Fichier ZIP', icon: FileArchive },
  { id: 'folder', label: 'Dossier', icon: FolderOpen },
  { id: 'url', label: 'Site web', icon: Globe },
  { id: 'github', label: 'GitHub', icon: Github },
];

export default function ImportDialog({ open, onClose, onComplete }) {
  const [step, setStep] = useState(STEPS.IDLE);
  const [mode, setMode] = useState('zip');
  const [progress, setProgress] = useState('');
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');
  const [urlInput, setUrlInput] = useState('');
  const fileInputRef = useRef(null);
  const folderInputRef = useRef(null);

  const reset = () => {
    setStep(STEPS.IDLE);
    setProgress('');
    setResult(null);
    setError('');
    setUrlInput('');
  };

  const handleClose = () => {
    reset();
    onClose();
  };

  const handleScanResult = async (scanResult, sourceType) => {
    setStep(STEPS.SAVING);
    setProgress('Création du projet en mémoire…');

    const dna = buildProjectDna(scanResult, sourceType);
    const futurePaths = buildFuturePaths(scanResult);

    const me = await base44.auth.me();

    const project = await base44.entities.AimeProject.create({
      name: dna.identity.name,
      category: dna.identity.category,
      status: 'active',
      owner_id: me.id,
      source_type: sourceType,
      source_url: sourceType === 'url' ? scanResult.url : undefined,
      item_count: scanResult.itemCount,
    });

    setProgress('Enregistrement des éléments mémoire…');

    const memoryItems = scanResult.items.map((item) => ({
      project_id: project.id,
      owner_id: me.id,
      type: item.type,
      name: item.name,
      title: item.name.replace(/\.[^.]+$/, ''),
      path: item.path,
      source: sourceType,
      status: 'active',
      mime_type: item.mime_type,
      size: item.size,
      category: item.ext,
    }));

    const batchSize = 100;
    for (let i = 0; i < memoryItems.length; i += batchSize) {
      await base44.entities.MemoryItem.bulkCreate(memoryItems.slice(i, i + batchSize));
    }

    setProgress("Création de l'ADN du projet…");

    const projectDna = await base44.entities.ProjectDNA.create({
      project_id: project.id,
      owner_id: me.id,
      identity: dna.identity,
      archetype: dna.archetype,
      archetype_confidence: dna.archetype_confidence,
      archetype_signals: dna.archetype_signals,
      humans: dna.humans,
      persons: dna.persons,
      resources: dna.resources,
      timeline: dna.timeline,
      state: dna.state,
      intelligence: dna.intelligence,
      intentions: dna.intentions,
      design_dna: dna.design_dna,
      confidence: dna.confidence,
      validation: dna.validation,
      validation_state: dna.validation_state,
    });

    setProgress('Exploration des futurs possibles…');

    for (const fp of futurePaths) {
      await base44.entities.FuturePath.create({
        project_id: project.id,
        owner_id: me.id,
        ...fp,
      });
    }

    setResult({ project, dna: projectDna, scanResult, futurePaths });
    setStep(STEPS.DONE);
  };

  const handleFile = async (file) => {
    if (!file) return;
    if (!file.name.toLowerCase().endsWith('.zip')) {
      setError('Veuillez sélectionner un fichier ZIP.');
      setStep(STEPS.ERROR);
      return;
    }

    try {
      setStep(STEPS.SCANNING);
      setProgress('Analyse locale du contenu…');
      const scanResult = await scanZip(file);
      setProgress(`${scanResult.itemCount} éléments détectés. Construction de l'ADN…`);
      await handleScanResult(scanResult, 'zip');
    } catch (e) {
      console.error(e);
      setError(e.message || 'Erreur lors de l\'import.');
      setStep(STEPS.ERROR);
    }
  };

  const handleFolder = async (fileList) => {
    if (!fileList || fileList.length === 0) return;

    try {
      setStep(STEPS.SCANNING);
      setProgress('Analyse locale du dossier…');
      const scanResult = await scanFolder(fileList);
      setProgress(`${scanResult.itemCount} éléments détectés. Construction de l'ADN…`);
      await handleScanResult(scanResult, 'folder');
    } catch (e) {
      console.error(e);
      setError(e.message || 'Erreur lors de l\'import.');
      setStep(STEPS.ERROR);
    }
  };

  const handleUrl = async () => {
    const url = urlInput.trim();
    if (!url) {
      setError('Veuillez saisir une URL.');
      setStep(STEPS.ERROR);
      return;
    }

    try {
      setStep(STEPS.SCANNING);
      setProgress('Capture de la structure du site…');
      const response = await base44.functions.invoke('scanUrl', { url });
      if (response.data?.error) throw new Error(response.data.error);
      const scanResult = response.data;
      setProgress(`${scanResult.itemCount} éléments détectés. Extraction du Design DNA…`);
      await handleScanResult(scanResult, 'url');
    } catch (e) {
      console.error(e);
      setError(e.message || 'Erreur lors de la capture du site.');
      setStep(STEPS.ERROR);
    }
  };

  const handleComplete = () => {
    if (result) {
      onComplete(result.project, result.dna);
    }
    reset();
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && handleClose()}>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="font-heading text-xl">Importer dans AIME</DialogTitle>
        </DialogHeader>

        {step === STEPS.IDLE && (
          <div className="py-4">
            {/* Mode selector */}
            <div className="flex gap-2 mb-6">
              {MODES.map((m) => {
                const Icon = m.icon;
                return (
                  <button
                    key={m.id}
                    onClick={() => setMode(m.id)}
                    className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition border ${
                      mode === m.id
                        ? 'bg-secondary text-secondary-foreground border-secondary'
                        : 'bg-background text-foreground border-border hover:bg-muted'
                    }`}
                  >
                    <Icon className="w-4 h-4" strokeWidth={1.5} />
                    {m.label}
                  </button>
                );
              })}
            </div>

            {/* ZIP mode */}
            {mode === 'zip' && (
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-border rounded-lg p-12 text-center cursor-pointer hover:bg-muted/50 transition"
              >
                <FileArchive className="w-12 h-12 mx-auto mb-4 text-muted-foreground" strokeWidth={1.5} />
                <p className="text-sm font-medium text-foreground mb-1">
                  Déposez un fichier ZIP ou cliquez pour sélectionner
                </p>
                <p className="text-xs text-muted-foreground">
                  AIME analyse le contenu localement. Aucune donnée envoyée sans autorisation.
                </p>
              </div>
            )}
            <input
              ref={fileInputRef}
              type="file"
              accept=".zip"
              className="hidden"
              onChange={(e) => handleFile(e.target.files?.[0])}
            />

            {/* Folder mode */}
            {mode === 'folder' && (
              <div
                onClick={() => folderInputRef.current?.click()}
                className="border-2 border-dashed border-border rounded-lg p-12 text-center cursor-pointer hover:bg-muted/50 transition"
              >
                <FolderOpen className="w-12 h-12 mx-auto mb-4 text-muted-foreground" strokeWidth={1.5} />
                <p className="text-sm font-medium text-foreground mb-1">
                  Sélectionnez un dossier projet
                </p>
                <p className="text-xs text-muted-foreground">
                  AIME analysera toute l'arborescence localement.
                </p>
              </div>
            )}
            <input
              ref={folderInputRef}
              type="file"
              webkitdirectory=""
              directory=""
              multiple
              className="hidden"
              onChange={(e) => handleFolder(e.target.files)}
            />

            {/* GitHub mode */}
            {mode === 'github' && (
              <div className="border-2 border-dashed border-border rounded-lg p-12 text-center">
                <Github className="w-12 h-12 mx-auto mb-4 text-muted-foreground" strokeWidth={1.5} />
                <p className="text-sm font-medium text-foreground mb-1">
                  Importer un dépôt GitHub
                </p>
                <p className="text-xs text-muted-foreground mb-4 max-w-md mx-auto">
                  AIME analysera le code, l'architecture, la documentation, le design system et les assets du dépôt pour les transformer en mémoire projet.
                </p>
                <span className="brand-badge">Fonctionnalité en préparation — V1.2</span>
              </div>
            )}

            {/* URL mode */}
            {mode === 'url' && (
              <div className="space-y-4">
                <div
                  onClick={() => {}}
                  className="border-2 border-dashed border-border rounded-lg p-12 text-center"
                >
                  <Globe className="w-12 h-12 mx-auto mb-4 text-muted-foreground" strokeWidth={1.5} />
                  <p className="text-sm font-medium text-foreground mb-1">
                    Capturez la structure d'un site existant
                  </p>
                  <p className="text-xs text-muted-foreground mb-4">
                    AIME extrait l'architecture, les contenus et le Design DNA.
                  </p>
                </div>
                <div className="flex gap-2">
                  <input
                    type="url"
                    value={urlInput}
                    onChange={(e) => setUrlInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleUrl()}
                    placeholder="https://mon-site.com"
                    className="flex-1 h-10 px-4 rounded-full border border-border bg-background text-sm outline-none focus:ring-1 focus:ring-ring"
                  />
                  <button
                    onClick={handleUrl}
                    disabled={!urlInput.trim()}
                    className="brand-secondary-btn disabled:opacity-50"
                  >
                    Analyser
                    <ArrowRight className="w-4 h-4" strokeWidth={2} />
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {(step === STEPS.SCANNING || step === STEPS.SAVING) && (
          <div className="py-12 text-center">
            <Loader2 className="w-10 h-10 mx-auto mb-4 animate-spin text-foreground" />
            <p className="text-sm font-medium text-foreground mb-1">{progress}</p>
            <p className="text-xs text-muted-foreground">SENSE — analyse en cours…</p>
          </div>
        )}

        {step === STEPS.DONE && result && (
          <div className="py-4">
            <div className="flex items-center gap-2 mb-4 text-success">
              <CheckCircle2 className="w-5 h-5" />
              <span className="text-sm font-medium">Projet importé en mémoire</span>
            </div>
            <AimeProjectReading
              dna={result.dna}
              scanResult={result.scanResult}
              futurePaths={result.futurePaths}
              project={result.project}
              onRerun={async () => {
                const updated = await rerunAnalysis(result.project, result.dna.id);
                setResult({ ...result, dna: updated });
              }}
              onDnaUpdated={(updated) => setResult({ ...result, dna: updated })}
            />
            <div className="flex justify-end gap-2 mt-6">
              <Button variant="outline" onClick={handleClose}>
                Fermer
              </Button>
              <Button onClick={handleComplete}>
                Voir le projet
              </Button>
            </div>
          </div>
        )}

        {step === STEPS.ERROR && (
          <div className="py-8 text-center">
            <AlertCircle className="w-10 h-10 mx-auto mb-4 text-destructive" />
            <p className="text-sm font-medium text-foreground mb-1">Échec de l'import</p>
            <p className="text-xs text-muted-foreground mb-4">{error}</p>
            <Button variant="outline" onClick={reset}>
              Réessayer
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}