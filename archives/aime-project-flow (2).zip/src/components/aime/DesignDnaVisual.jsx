import { Palette, Type, Layout, Sparkles, Image, Heart, Grid3x3, Ruler } from 'lucide-react';

export default function DesignDnaVisual({ designDna, projectName }) {
  const {
    colors = [], fonts = [], layout, style,
    visual_references = [], emotional_style, visual_patterns = [], composition_rules = [],
  } = designDna;

  const branches = [
    {
      icon: Palette,
      label: 'Couleurs',
      values: colors,
      render: (v) => (
        <div className="flex items-center gap-1.5">
          <div className="w-4 h-4 rounded border border-border" style={{ background: v }} />
          <span className="text-xs font-mono text-muted-foreground">{v}</span>
        </div>
      ),
    },
    {
      icon: Type,
      label: 'Typographies',
      values: fonts,
      render: (v) => <span className="brand-badge">{v}</span>,
    },
    {
      icon: Layout,
      label: 'Composition',
      values: layout ? [layout] : [],
      render: (v) => <span className="text-sm capitalize">{v}</span>,
    },
    {
      icon: Sparkles,
      label: 'Ambiance',
      values: style ? [style] : [],
      render: (v) => <span className="text-sm capitalize">{v}</span>,
    },
    {
      icon: Image,
      label: 'Références',
      values: visual_references,
      render: (v) => <span className="text-xs text-muted-foreground truncate max-w-[200px]">{v}</span>,
    },
    {
      icon: Heart,
      label: 'Signature émotionnelle',
      values: emotional_style ? [emotional_style] : [],
      render: (v) => <span className="text-sm capitalize">{v}</span>,
    },
    {
      icon: Grid3x3,
      label: 'Patterns visuels',
      values: visual_patterns,
      render: (v) => <span className="brand-badge">{v}</span>,
    },
    {
      icon: Ruler,
      label: 'Règles de composition',
      values: composition_rules,
      render: (v) => <span className="text-xs">{v}</span>,
    },
  ];

  return (
    <div className="border border-border rounded-lg p-4 bg-muted/20">
      <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-4">
        Code génétique visuel
      </p>
      <div className="relative pl-6">
        <div className="absolute left-0 top-1 bottom-0 w-px bg-border" />
        <div className="relative mb-4">
          <div className="absolute -left-[27px] top-1 w-3 h-3 rounded-full bg-foreground" />
          <p className="text-sm font-heading font-medium">{projectName || 'Projet'}</p>
        </div>
        <div className="space-y-3">
          {branches.map((b, i) => {
            const Icon = b.icon;
            const hasValues = b.values.length > 0;
            return (
              <div key={i} className="relative">
                <div className="absolute -left-[27px] top-1 w-3 h-3 rounded-full border-2 border-border bg-background" />
                <div className="flex items-center gap-2 mb-1">
                  <Icon className="w-3.5 h-3.5 text-muted-foreground" strokeWidth={1.5} />
                  <span className="text-xs text-muted-foreground">{b.label}</span>
                </div>
                {hasValues ? (
                  <div className="flex flex-wrap gap-1.5 ml-5">
                    {b.values.map((v, j) => (
                      <div key={j}>{b.render(v)}</div>
                    ))}
                  </div>
                ) : (
                  <p className="text-xs text-muted-foreground italic ml-5">Non détecté</p>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}