import { useState } from 'react';
import { Sparkles, Loader2, ArrowRight, Check } from 'lucide-react';
import { createStudioForProject, getStudioContext } from '@/lib/aime/studioGenerator';

const CATEGORY_LABELS = {
  wedding: 'Mariage', music: 'Musique', association: 'Association',
  business: 'Entreprise', education: 'Éducation', community: 'Communauté',
  personal: 'Personnel', other: 'Projet',
};

export default function StudioGenerationCard({ dna, project, onCreated }) {
  const [creating, setCreating] = useState(false);
  const [createdPageId, setCreatedPageId] = useState(project?.studio_page_id || null);
  const category = dna.identity?.category || 'other';
  const studioType = getStudioContext(category);
  const hasStudio = !!createdPageId;

  const handleCreate = async () => {
    setCreating(true);
    try {
      const page = await createStudioForProject(dna, project);
      setCreatedPageId(page.id);
      onCreated?.(page);
    } catch (e) {
      console.error(e);
    }
    setCreating(false);
  };

  const handleOpen = () => {
    window.location.href = '/studio/page';
  };

  return (
    <div className="border border-border rounded-lg p-4 bg-muted/30">
      <div className="flex items-center gap-2 mb-2">
        <Sparkles className="w-4 h-4 text-muted-foreground" strokeWidth={1.5} />
        <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          Studio AIME
        </h4>
      </div>
      <p className="text-sm text-muted-foreground mb-3">
        {hasStudio
          ? 'Votre espace Studio est prêt. AIME a préparé une page adaptée à votre projet.'
          : `AIME peut créer automatiquement un espace Studio pour : ${studioType.label}. Page, design et sections de base générés.`}
      </p>
      {hasStudio ? (
        <button onClick={handleOpen} className="brand-secondary-btn text-xs">
          <ArrowRight className="w-3.5 h-3.5" /> Ouvrir le Studio
        </button>
      ) : (
        <button onClick={handleCreate} disabled={creating} className="brand-secondary-btn text-xs">
          {creating ? (
            <Loader2 className="w-3.5 h-3.5 animate-spin" />
          ) : (
            <Sparkles className="w-3.5 h-3.5" />
          )}
          Créer mon espace Studio AIME
        </button>
      )}
    </div>
  );
}