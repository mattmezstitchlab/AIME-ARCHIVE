import { Check, Circle, Clock, ArrowRight, Calendar } from 'lucide-react';

/**
 * Timeline Intelligente — V1.5
 *
 * Pas seulement l'historique, mais "ce qui doit arriver ensuite".
 *
 *   ✓ Passé (fait)
 *   ○ Présent (en cours)
 *   ○ Futur (à faire)
 */

const PHASE_STYLES = {
  past: { icon: Check, iconClass: 'bg-foreground text-background', label: 'Passé', labelClass: 'text-muted-foreground' },
  present: { icon: Circle, iconClass: 'bg-foreground text-background', label: 'Présent', labelClass: 'text-foreground' },
  future: { icon: Clock, iconClass: 'bg-muted text-muted-foreground', label: 'À faire', labelClass: 'text-muted-foreground' },
};

export default function IntelligentTimeline({ dna, actions, project, futurePaths }) {
  const timeline = dna?.timeline || {};
  const validationState = dna?.validation_state || dna?.validation || {};
  const hasStudio = !!project?.studio_page_id;

  // Construire les étapes depuis le DNA + actions + état du projet
  const steps = [];

  // 1. Passé — ce qui est déjà fait
  (timeline.past || []).forEach((moment, i) => {
    steps.push({
      phase: 'past',
      label: moment,
      detail: 'Moment identifié',
      done: true,
    });
  });

  // 2. Présent — état actuel
  if (validationState.status === 'validated') {
    steps.push({ phase: 'present', label: 'Compréhension validée', detail: 'AIME a compris le projet', done: true });
  } else if (validationState.status === 'pending') {
    steps.push({ phase: 'present', label: 'Valider la compréhension', detail: 'AIME attend votre validation', done: false });
  }

  // 3. Futur — actions à faire (depuis l'Action Engine)
  const proposedActions = (actions || [])
    .filter((a) => a.status === 'proposed' || a.status === 'active')
    .sort((a, b) => (a.order || 0) - (b.order || 0))
    .slice(0, 6);

  proposedActions.forEach((action) => {
    steps.push({
      phase: 'future',
      label: action.title,
      detail: action.description,
      done: false,
      actionId: action.id,
    });
  });

  // 4. Étapes clés du futur (depuis le blueprint)
  if (hasStudio) {
    steps.push({ phase: 'past', label: 'Studio créé', detail: 'Espace public en ligne', done: true });
    steps.push({ phase: 'future', label: 'Publier le site', detail: 'Partager au public', done: false });
  }

  // 5. FuturePaths sélectionnés
  const selectedPath = (futurePaths || []).find((fp) => fp.status === 'selected');
  if (selectedPath) {
    steps.push({ phase: 'future', label: selectedPath.scenario, detail: 'Direction choisie', done: false });
  }

  // Grouper par phase
  const phases = ['past', 'present', 'future'];
  const grouped = phases.map((phase) => ({
    phase,
    items: steps.filter((s) => s.phase === phase),
  })).filter((g) => g.items.length > 0);

  if (steps.length === 0) {
    return (
      <div className="border border-border rounded-lg p-5">
        <div className="flex items-center gap-2 mb-4">
          <Calendar className="w-4 h-4 text-muted-foreground" strokeWidth={1.5} />
          <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Timeline intelligente
          </h3>
        </div>
        <p className="text-xs text-muted-foreground italic text-center py-6">
          La timeline se construit au fil des actions du projet.
        </p>
      </div>
    );
  }

  return (
    <div className="border border-border rounded-lg p-5">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Calendar className="w-4 h-4 text-muted-foreground" strokeWidth={1.5} />
          <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Timeline intelligente
          </h3>
        </div>
        <span className="brand-badge">Ce qui doit arriver ensuite</span>
      </div>

      <div className="space-y-5">
        {grouped.map((group) => {
          const style = PHASE_STYLES[group.phase];
          const Icon = style.icon;
          return (
            <div key={group.phase}>
              <div className="flex items-center gap-2 mb-2">
                <span className={`text-xs font-semibold uppercase tracking-wider ${style.labelClass}`}>
                  {style.label}
                </span>
                <div className="flex-1 h-px bg-border" />
              </div>
              <div className="space-y-2">
                {group.items.map((item, i) => {
                  const isDone = item.done;
                  return (
                    <div key={i} className="flex items-start gap-3">
                      <div className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 mt-0.5 ${isDone ? 'bg-foreground text-background' : 'bg-muted text-muted-foreground border border-border'}`}>
                        {isDone ? (
                          <Check className="w-3.5 h-3.5" strokeWidth={2} />
                        ) : (
                          <Circle className="w-3 h-3" strokeWidth={1.5} />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className={`text-sm ${isDone ? 'text-muted-foreground line-through' : 'text-foreground font-medium'}`}>
                          {item.label}
                        </p>
                        {item.detail && (
                          <p className="text-xs text-muted-foreground">{item.detail}</p>
                        )}
                      </div>
                      {!isDone && group.phase === 'future' && (
                        <ArrowRight className="w-3.5 h-3.5 text-muted-foreground shrink-0 mt-1" strokeWidth={1.5} />
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}