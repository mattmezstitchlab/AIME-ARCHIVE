import { Loader2 } from 'lucide-react';

/**
 * Affiche l'état actuel du projet sous forme de métriques.
 * V1.5 — Project Command Center
 */
export default function ProjectStateCard({ state, loading }) {
  if (loading || !state) {
    return (
      <div className="border border-border rounded-lg p-5">
        <div className="flex items-center gap-2 mb-4">
          <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
          <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            État du projet
          </h3>
        </div>
        <div className="h-32 flex items-center justify-center">
          <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
        </div>
      </div>
    );
  }

  const metrics = [
    { key: 'comprehension', label: 'Compréhension', value: state.comprehension, hint: 'Confiance DNA' },
    { key: 'identity', label: 'Identité', value: state.identity, hint: 'Validation humaine' },
    { key: 'resources', label: 'Ressources', value: state.resources, hint: 'Richesse mémoire' },
    { key: 'organization', label: 'Organisation', value: state.organization, hint: 'Personnes + décisions' },
    { key: 'creation', label: 'Création', value: state.creation, hint: state.creation === 100 ? 'Studio créé' : 'Studio en attente' },
  ];

  return (
    <div className="border border-border rounded-lg p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          État actuel
        </h3>
        <span className="brand-badge">{state.completion}% complété</span>
      </div>

      <div className="space-y-3">
        {metrics.map((m) => (
          <div key={m.key}>
            <div className="flex items-center justify-between mb-1">
              <span className="text-sm text-foreground">{m.label}</span>
              <span className="text-sm font-mono font-medium text-foreground">{m.value}%</span>
            </div>
            <div className="h-1.5 rounded-full bg-muted overflow-hidden">
              <div
                className={`h-full transition-all duration-500 ${
                  m.value >= 80 ? 'bg-foreground' : m.value >= 50 ? 'bg-foreground/60' : 'bg-muted-foreground/40'
                }`}
                style={{ width: `${m.value}%` }}
              />
            </div>
            <p className="text-xs text-muted-foreground mt-0.5">{m.hint}</p>
          </div>
        ))}
      </div>

      {/* Statut global */}
      <div className="mt-4 pt-4 border-t border-border">
        <div className="flex items-center justify-between">
          <span className="text-xs text-muted-foreground">Actions</span>
          <div className="flex items-center gap-2">
            <span className="brand-badge-dark">{state.doneActionCount} done</span>
            <span className="brand-badge">{state.activeActionCount} actives</span>
          </div>
        </div>
      </div>
    </div>
  );
}