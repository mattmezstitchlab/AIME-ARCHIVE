import { Loader2, Check, X, Zap, Info, Compass, Palette, Shield, Users, Mail, ChevronRight } from 'lucide-react';

const TYPE_ICONS = {
  missing_information: Info,
  decision: Compass,
  creation: Palette,
  validation: Shield,
  organization: Users,
  communication: Mail,
};

const PRIORITY_STYLES = {
  critical: { label: 'Critique', class: 'bg-red-50 text-red-700 border-red-200' },
  high: { label: 'Haute', class: 'bg-amber-50 text-amber-700 border-amber-200' },
  medium: { label: 'Moyenne', class: 'bg-muted text-muted-foreground border-border' },
  low: { label: 'Basse', class: 'bg-muted/50 text-muted-foreground border-border' },
};

const STATUS_STYLES = {
  proposed: { label: 'À faire', class: 'brand-badge' },
  active: { label: 'En cours', class: 'brand-badge-dark' },
  done: { label: 'Fait', class: 'bg-green-100 text-green-700 border border-green-200 text-xs font-semibold uppercase tracking-wider px-2.5 py-1 rounded' },
  skipped: { label: 'Ignoré', class: 'brand-badge opacity-50' },
};

/**
 * Liste des actions recommandées pour le projet.
 * V1.5 — Action Engine
 */
export default function ActionList({ actions, loading, onAction, onToggleStatus }) {
  if (loading) {
    return (
      <div className="border border-border rounded-lg p-5">
        <div className="flex items-center gap-2 mb-4">
          <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
          <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Prochaines actions recommandées
          </h3>
        </div>
        <div className="h-40 flex items-center justify-center">
          <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
        </div>
      </div>
    );
  }

  if (!actions || actions.length === 0) {
    return (
      <div className="border border-border rounded-lg p-5">
        <div className="flex items-center gap-2 mb-4">
          <Zap className="w-4 h-4 text-muted-foreground" strokeWidth={1.5} />
          <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Prochaines actions recommandées
          </h3>
        </div>
        <div className="text-center py-8">
          <Check className="w-8 h-8 mx-auto mb-2 text-green-600" strokeWidth={1.5} />
          <p className="text-sm font-medium text-foreground">Toutes les actions sont complétées</p>
          <p className="text-xs text-muted-foreground mt-1">Votre projet est piloté. Continuez ainsi.</p>
        </div>
      </div>
    );
  }

  // Trier : proposed/active d'abord, puis done/skipped
  const sorted = [...actions].sort((a, b) => {
    const statusOrder = { proposed: 0, active: 1, done: 2, skipped: 3 };
    if (statusOrder[a.status] !== statusOrder[b.status]) return statusOrder[a.status] - statusOrder[b.status];
    return (a.order || 0) - (b.order || 0);
  });

  return (
    <div className="border border-border rounded-lg p-5">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Zap className="w-4 h-4 text-muted-foreground" strokeWidth={1.5} />
          <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Prochaines actions recommandées
          </h3>
        </div>
        <span className="brand-badge">{sorted.filter((a) => a.status === 'proposed' || a.status === 'active').length} à faire</span>
      </div>

      <div className="space-y-2">
        {sorted.map((action, index) => {
          const Icon = TYPE_ICONS[action.type] || Zap;
          const priority = PRIORITY_STYLES[action.priority] || PRIORITY_STYLES.medium;
          const status = STATUS_STYLES[action.status] || STATUS_STYLES.proposed;
          const isDone = action.status === 'done';
          const isSkipped = action.status === 'skipped';

          return (
            <div
              key={action.id}
              className={`border rounded-lg p-3 transition ${
                isDone ? 'bg-muted/30 border-border opacity-60' : isSkipped ? 'bg-muted/20 border-border opacity-40' : 'bg-background border-border hover:border-foreground/20'
              }`}
            >
              <div className="flex items-start gap-3">
                {/* Numéro / icône */}
                <div className="shrink-0 mt-0.5">
                  {!isDone && !isSkipped && (
                    <div className="w-7 h-7 rounded-full bg-foreground text-background flex items-center justify-center text-xs font-mono font-medium">
                      {index + 1}
                    </div>
                  )}
                  {isDone && (
                    <div className="w-7 h-7 rounded-full bg-green-100 text-green-700 flex items-center justify-center">
                      <Check className="w-4 h-4" strokeWidth={2} />
                    </div>
                  )}
                  {isSkipped && (
                    <div className="w-7 h-7 rounded-full bg-muted text-muted-foreground flex items-center justify-center">
                      <X className="w-4 h-4" strokeWidth={2} />
                    </div>
                  )}
                </div>

                {/* Contenu */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <div className="flex items-center gap-2">
                      <Icon className="w-3.5 h-3.5 text-muted-foreground shrink-0" strokeWidth={1.5} />
                      <p className={`text-sm font-medium text-foreground ${isDone || isSkipped ? 'line-through' : ''}`}>
                        {action.title}
                      </p>
                    </div>
                    <span className={`text-xs font-semibold uppercase tracking-wider px-2 py-0.5 rounded border ${priority.class} shrink-0`}>
                      {priority.label}
                    </span>
                  </div>
                  {action.description && (
                    <p className="text-xs text-muted-foreground mb-2 ml-5.5">{action.description}</p>
                  )}
                  <div className="flex items-center gap-2 ml-5.5">
                    <span className={status.class}>{status.label}</span>
                    <span className="text-xs text-muted-foreground capitalize">· {action.type.replace(/_/g, ' ')}</span>
                    {action.source === 'think' && (
                      <span className="text-xs text-muted-foreground">· Détecté par AIME</span>
                    )}
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-1 shrink-0">
                  {!isDone && !isSkipped && action.target_route && (
                    <button
                      onClick={() => onAction?.(action)}
                      className="brand-secondary-btn text-xs"
                    >
                      Agir
                      <ChevronRight className="w-3.5 h-3.5" strokeWidth={2} />
                    </button>
                  )}
                  {!isDone && (
                    <button
                      onClick={() => onToggleStatus?.(action, 'done')}
                      className="brand-icon-btn"
                      title="Marquer comme fait"
                    >
                      <Check className="w-4 h-4" strokeWidth={1.5} />
                    </button>
                  )}
                  {!isSkipped && !isDone && (
                    <button
                      onClick={() => onToggleStatus?.(action, 'skipped')}
                      className="brand-icon-btn"
                      title="Ignorer"
                    >
                      <X className="w-4 h-4" strokeWidth={1.5} />
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}