import { Image } from "@/components/ui/image";

const WAVE_URL =
  "https://media.base44.com/images/public/6a6e080d1aca70178ff1340c/9ebb591dc_generated_image.png";

// Brand mark of LE MONDE AIME — sky disc with a four-petal green flower,
// faithfully preserved from the About-9 mockup and recoloured to the app tokens.
function AimMark({ className = "" }) {
  return (
    <svg className={className} viewBox="0 0 45 45" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <circle cx="22.5" cy="22.5" r="22.5" fill="hsl(var(--sky))" />
      <path d="M22.5 22.3815C22.4995 22.3815 22.4991 22.3812 22.4991 22.3807C22.5002 19.7967 27.1782 16.2869 27.1782 12.8592C27.1782 10.2752 25.0849 8.18188 22.5009 8.18188H22.4759C19.9026 8.19616 17.8236 10.2841 17.8236 12.8592C17.8236 16.1392 22.1083 19.4959 22.4759 22.0443C22.4919 22.1582 22.5009 22.2703 22.5009 22.3807C22.5009 22.3811 22.5005 22.3815 22.5 22.3815Z" fill="hsl(var(--navy))" />
      <path d="M22.4745 22.9558C22.1069 25.5024 17.8222 28.8591 17.8222 32.1409C17.8222 34.716 19.9012 36.8057 22.4745 36.8182H22.5013C25.0853 36.8182 27.1786 34.7231 27.1786 32.1409C27.1786 28.7128 22.5013 25.2008 22.4995 22.6185C22.4995 22.7292 22.4906 22.8416 22.4745 22.9558Z" fill="hsl(var(--navy))" />
      <path d="M32.1409 17.8222C28.8609 17.8222 25.5041 22.1069 22.9558 22.4745C22.8416 22.4924 22.7292 22.4995 22.6185 22.4995C25.2026 22.4995 28.7145 27.1786 32.1409 27.1786C34.7249 27.1786 36.8182 25.0853 36.8182 22.4995V22.4745C36.8039 19.9012 34.716 17.8222 32.1409 17.8222Z" fill="hsl(var(--navy))" />
      <path d="M22.0452 22.4745C22.0446 22.4745 22.044 22.4745 22.0434 22.4744C19.4969 22.1059 16.1388 17.8222 12.8592 17.8222C10.2841 17.8222 8.19616 19.903 8.18188 22.4745V22.4995C8.18188 25.0835 10.2769 27.1768 12.8592 27.1768C16.2873 27.1768 19.7993 22.4995 22.3833 22.4995C22.2712 22.4995 22.1591 22.4906 22.0469 22.4746C22.0463 22.4745 22.0458 22.4745 22.0452 22.4745Z" fill="hsl(var(--navy))" />
    </svg>
  );
}

export default function AboutSection() {
  return (
    <section className="relative w-full overflow-hidden rounded-3xl my-10" style={{ padding: "88px 24px" }}>
      {/* Full-bleed ribbon wave background, drifting slowly */}
      <Image
        src={WAVE_URL}
        alt=""
        fittingType="fill"
        className="absolute inset-0 w-full h-full pointer-events-none animate-ab9-float"
      />

      {/* Frosted glass info card, centred over the background */}
      <div
        className="relative z-10 mx-auto w-[min(345px,100%)] rounded-[19px] border border-white/60 bg-white/30 backdrop-blur-[12px] p-5 sm:px-5 animate-ab9-drop-in"
        style={{
          boxShadow: "0px 14px 14px 0px rgba(0, 0, 0, 0.06)",
          animationDelay: "0.5s",
          display: "flex",
          flexDirection: "column",
          gap: "44px"
        }}
      >
        <div className="animate-ab9-drop-in" style={{ animationDelay: "0.9s" }}>
          <AimMark className="w-[45px] h-[45px] shrink-0" />
        </div>

        <h2
          className="animate-ab9-drop-in m-0 text-foreground font-medium"
          style={{ fontSize: "40px", lineHeight: 1.2, letterSpacing: "-0.04em", maxWidth: "171px", animationDelay: "1.15s" }}
        >
          Mission & Vision
        </h2>

        <p
          className="animate-ab9-drop-in m-0 text-foreground"
          style={{ fontSize: "16px", lineHeight: 1.3, letterSpacing: "-0.01em", animationDelay: "1.4s" }}
        >
          LE MONDE AIME transforme une intention en projet. AIME Association OS accompagne les associations de l'idée au bilan : une information saisie une seule fois, réutilisée partout. L'humain apporte l'intention, AIME organise la complexité.
        </p>
      </div>
    </section>
  );
}