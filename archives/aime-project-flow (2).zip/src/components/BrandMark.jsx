import AimeLogo from "@/components/AimeLogo";

export default function BrandMark({ className = "" }) {
  return (
    <div className={`flex items-center gap-3 ${className}`}>
      <div>
        <AimeLogo size="sm" />
        <span className="block text-[10px] uppercase text-muted-foreground tracking-wide mt-0.5">Association OS</span>
      </div>
    </div>
  );
}