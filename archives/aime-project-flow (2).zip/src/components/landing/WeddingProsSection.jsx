import { motion } from "framer-motion";
import { Users, Heart } from "lucide-react";

const CARDS = [
  {
    icon: Heart,
    role: "Wedding planners",
    text: "Un espace par mariage, une vue d'ensemble sur tous vos dossiers. Le couple garde ses décisions, vous gardez la coordination.",
    points: ["Plusieurs mariages en parallèle", "Droits délégués par le couple", "Déroulé et prestataires centralisés"]
  },
  {
    icon: Users,
    role: "Prestataires",
    text: "Un lien, pas un compte. Vous voyez votre horaire, vos documents et ce qui vous concerne — rien d'autre.",
    points: ["Accès sans création de compte", "Vos horaires et votre mission", "Vos devis et contrats au même endroit"]
  }
];

export default function WeddingProsSection() {
  return (
    <section className="py-24 md:py-32 px-6" style={{ backgroundColor: "var(--brand-surface)" }}>
      <div className="max-w-5xl mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="brand-badge">Prestataires &amp; planners</span>
          <h2 className="mt-5 text-4xl md:text-5xl">Vous ne travaillez pas seul sur ce mariage.</h2>
          <p className="mt-5 text-muted-foreground">
            AIME est fait pour le couple, mais aussi pour ceux qui l'accompagnent.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {CARDS.map((c, i) => {
            const Icon = c.icon;
            return (
              <motion.article key={c.role}
                initial={{ opacity: 0, y: 14 }} whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }} transition={{ delay: i * 0.12 }}
                className="rounded-xl border border-border bg-background p-8">
                <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center mb-5">
                  <Icon className="w-5 h-5" strokeWidth={1.5} />
                </div>
                <h3 className="text-xl">{c.role}</h3>
                <p className="mt-2.5 text-sm text-muted-foreground">{c.text}</p>
                <ul className="mt-5 space-y-2">
                  {c.points.map((p) => (
                    <li key={p} className="text-sm text-muted-foreground flex gap-2">
                      <span className="text-foreground">·</span>{p}
                    </li>
                  ))}
                </ul>
              </motion.article>
            );
          })}
        </div>
      </div>
    </section>
  );
}