import { motion } from "framer-motion";
import { Image } from "@/components/ui/image";

export default function WeddingPhotoBand({ src, alt, quote, caption, focalPointX = 0.5, focalPointY = 0.5 }) {
  return (
    <section className="px-6 pb-4 bg-background">
      <motion.figure
        initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }} transition={{ duration: 0.6 }}
        className="max-w-6xl mx-auto">
        <div className="relative overflow-hidden rounded-2xl">
          <Image src={src} alt={alt} focalPointX={focalPointX} focalPointY={focalPointY}
            className="w-full h-[320px] md:h-[460px]" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent" />
          <figcaption className="absolute bottom-0 left-0 right-0 p-7 md:p-10">
            <p className="text-xl md:text-3xl max-w-2xl font-heading text-white">{quote}</p>
            {caption && <p className="mt-2.5 text-xs md:text-sm text-white/70">{caption}</p>}
          </figcaption>
        </div>
      </motion.figure>
    </section>
  );
}