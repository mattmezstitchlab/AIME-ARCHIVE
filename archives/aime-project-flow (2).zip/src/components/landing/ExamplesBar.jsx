const EXAMPLES = [
  'Créer un mariage avec gestion invités',
  'Créer une association culturelle',
  'Créer mon espace artiste',
  'Créer mon entreprise',
];

export default function ExamplesBar({ onSelect }) {
  return (
    <div className="flex flex-wrap gap-2 justify-center mt-4">
      {EXAMPLES.map((ex) => (
        <button
          key={ex}
          onClick={() => onSelect(ex)}
          className="rounded-full border border-white/10 bg-white/5 hover:bg-white/10 px-4 py-1.5 text-xs text-white/60 hover:text-white transition"
        >
          {ex}
        </button>
      ))}
    </div>
  );
}