import { Check } from 'lucide-react';

const PERMISSIONS = [
  { data: 'Budget', couple: true, planner: true, vendor: false, guest: false },
  { data: 'Documents privés', couple: true, planner: 'Selon droit', vendor: false, guest: false },
  { data: 'Planning général', couple: true, planner: true, vendor: true, guest: 'Selon droit' },
  { data: 'Missions personnelles', couple: true, planner: true, vendor: true, guest: false },
  { data: 'Coordonnées privées', couple: true, planner: true, vendor: 'Limité', guest: false },
  { data: 'Site public', couple: true, planner: true, vendor: true, guest: true },
];

export default function WeddingPermissionsSection() {
  return (
    <section className="py-24 px-6 bg-card">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-16">
          <span className="brand-badge mb-4">Permissions</span>
          <h2 className="font-heading text-3xl md:text-5xl font-medium mb-4">
            Les bonnes informations pour chaque personne.
          </h2>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Chaque rôle voit uniquement ce qu'il doit voir. Votre budget et vos documents privés ne sortent jamais de votre espace.
          </p>
        </div>

        <div className="overflow-x-auto rounded-lg border border-border bg-background">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-card border-b border-border">
                <th className="text-left px-4 py-3 font-heading font-medium">Donnée</th>
                <th className="text-center px-4 py-3 font-heading font-medium">Couple</th>
                <th className="text-center px-4 py-3 font-heading font-medium">Planner</th>
                <th className="text-center px-4 py-3 font-heading font-medium">Prestataire</th>
                <th className="text-center px-4 py-3 font-heading font-medium">Invité</th>
              </tr>
            </thead>
            <tbody>
              {PERMISSIONS.map((row, i) => (
                <tr key={row.data} className={i % 2 === 0 ? '' : 'bg-card/50'}>
                  <td className="px-4 py-3 font-medium">{row.data}</td>
                  {[row.couple, row.planner, row.vendor, row.guest].map((val, j) => (
                    <td key={j} className="text-center px-4 py-3">
                      {val === true ? (
                        <Check className="w-4 h-4 text-foreground mx-auto" strokeWidth={2} />
                      ) : val === false ? (
                        <span className="text-muted-foreground/30">—</span>
                      ) : (
                        <span className="text-xs text-muted-foreground">{val}</span>
                      )}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
}