import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Loader2 } from 'lucide-react';

const STEPS = [
  'Analyse en cours...',
  'Extraction des informations...',
  'Organisation du projet...',
];

export default function DocumentAnalysis() {
  const [step, setStep] = useState(0);

  useEffect(() => {
    if (step < STEPS.length - 1) {
      const t = setTimeout(() => setStep(s => s + 1), 800);
      return () => clearTimeout(t);
    }
  }, [step]);

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-center gap-2 text-white/60 text-sm mt-3 justify-center">
      <Loader2 className="w-4 h-4 animate-spin" />
      <AnimatePresence mode="wait">
        <motion.span key={step} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.3 }}>
          {STEPS[step]}
        </motion.span>
      </AnimatePresence>
    </motion.div>
  );
}