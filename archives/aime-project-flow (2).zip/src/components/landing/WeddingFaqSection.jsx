import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

const FAQ = [
  {
    q: "Mes prestataires doivent-ils créer un compte ?",
    a: "Non. Chaque prestataire reçoit un lien privé qui ouvre son propre espace : ses horaires, sa mission et ses documents. Vous pouvez révoquer ce lien à tout moment."
  },
  {
    q: "Qui peut voir mon budget ?",
    a: "Vous, et les personnes à qui vous donnez explicitement le droit — un co-organisateur ou votre wedding planner. Les prestataires et les invités n'y ont jamais accès."
  },
  {
    q: "Je suis déjà organisé sur un tableur et par mail, je dois tout recommencer ?",
    a: "Non. Vous collez un lien, un devis PDF ou une capture, AIME en extrait les informations et vous propose une fiche. Vous validez avant l'enregistrement."
  },
  {
    q: "Est-ce que l'intelligence décide à ma place ?",
    a: "Jamais. AIME propose : une structure, un budget, un déroulé, ce qui manque. Chaque proposition passe par votre accord avant d'être appliquée."
  },
  {
    q: "Que devient mon mariage après le jour J ?",
    a: "Votre espace reste accessible : documents, factures, contacts et déroulé sont conservés, avec la galerie et le livre d'or de votre page publique."
  }
];

export default function WeddingFaqSection() {
  return (
    <section className="py-24 md:py-32 px-6" style={{ backgroundColor: "var(--brand-surface)" }}>
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-12">
          <span className="brand-badge">Questions</span>
          <h2 className="mt-5 text-4xl md:text-5xl">Ce qu'on nous demande le plus.</h2>
        </div>
        <Accordion type="single" collapsible className="rounded-xl border border-border bg-background px-2">
          {FAQ.map((f, i) => (
            <AccordionItem key={i} value={"q" + i} className="border-border last:border-0">
              <AccordionTrigger className="text-left px-4 hover:no-underline">{f.q}</AccordionTrigger>
              <AccordionContent className="px-4 text-muted-foreground">{f.a}</AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  );
}