import { motion } from 'framer-motion';

export default function AiMeSection() {
  return (
    <section className="py-24 md:py-32 px-6 bg-card">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="brand-badge mb-4">04 — AI + ME</span>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-6 md:gap-8 mb-12">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.5 }}
            className="bg-foreground text-background rounded-lg p-8 md:p-10"
          >
            <h3 className="font-heading text-5xl md:text-6xl font-semibold tracking-tight mb-4">AI</h3>
            <p className="text-sm text-white/60 leading-relaxed">Comprendre et analyser</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="bg-background border border-border rounded-lg p-8 md:p-10"
          >
            <h3 className="font-heading text-5xl md:text-6xl font-semibold tracking-tight mb-4">ME</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">Choisir, corriger et décider</p>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="text-center"
        >
          <p className="text-lg md:text-xl font-heading font-medium tracking-tight max-w-2xl mx-auto leading-relaxed">
            AIME ne décide pas à votre place. Il vous aide à voir plus clairement ce qui existe, ce qui manque et ce qui peut venir ensuite.
          </p>
        </motion.div>
      </div>
    </section>
  );
}