import { Link, useNavigate } from 'react-router-dom';
import { useState } from 'react';
import { motion } from 'framer-motion';
import { ChevronDown } from 'lucide-react';
import { base44 } from '@/api/base44Client';

const HERO_IMAGE = "https://media.base44.com/images/public/6a6e080d1aca70178ff1340c/e6ca45b8a_generated_image.png";

export default function WeddingHero({ content = {} }) {
  const navigate = useNavigate();
  const [intro, setIntro] = useState('');
  const [starting, setStarting] = useState(false);

  const handleStart = async () => {
    setStarting(true);
    if (intro.trim()) sessionStorage.setItem('aime_wedding_intro', intro.trim());
    const authed = await base44.auth.isAuthenticated().catch(() => false);
    navigate(authed ? '/' : '/register');
  };

  return (
    <section className="relative min-h-[85vh] md:min-h-screen flex items-center justify-center overflow-hidden pt-16">
      <div className="absolute inset-0">
        <img
          src={HERO_IMAGE}
          alt=""
          className="w-full h-full object-cover object-[50%_50%] md:object-[50%_22%]"
        />
        <div className="absolute inset-0 bg-black/55" />
      </div>

      <div className="relative z-10 text-center px-6 max-w-3xl">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7 }}>
          <p className="mb-6 text-xs uppercase tracking-[0.2em] text-white/50 font-medium">
            {content.eyebrow || 'LE GRAND JOUR®'}
          </p>
          <h1 className="font-heading text-4xl md:text-6xl font-semibold text-white mb-6">
            {content.title || 'Tout votre mariage,\nau même endroit.'}
          </h1>
          <p className="text-base md:text-lg text-white/70 mb-10 max-w-2xl mx-auto">
            {content.subtitle || 'Budget, prestataires, invités, déroulé du jour J. Décrivez votre mariage — AIME crée le projet, invite vos prestataires et orchestre chaque détail.'}
          </p>

          <div className="mx-auto max-w-xl bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-3 mb-5">
            <textarea
              value={intro}
              onChange={(e) => setIntro(e.target.value)}
              placeholder="Ex : Nous nous marions en juin 2027, 120 invités"
              rows={2}
              className="w-full resize-none bg-transparent px-3 pt-2 pb-1 text-sm text-white placeholder:text-white/50 focus:outline-none"
            />
            <div className="flex justify-end px-2 pb-1">
              <button
                onClick={handleStart}
                disabled={starting}
                className="px-6 py-3 bg-white text-black rounded-full text-sm font-semibold hover:bg-white/90 transition-all disabled:opacity-60"
              >
                {content.ctaLabel || 'Créer mon mariage'}
              </button>
            </div>
          </div>

          <Link to="/comment-ca-marche" className="text-sm text-white/70 hover:text-white underline underline-offset-4">
            Découvrir comment fonctionne AIME
          </Link>
        </motion.div>
      </div>

      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10">
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
          className="flex flex-col items-center gap-1 text-white/40"
        >
          <span className="text-[10px] uppercase tracking-wider">Défiler</span>
          <ChevronDown className="w-4 h-4" />
        </motion.div>
      </div>
    </section>
  );
}