import { Heatmap } from "@paper-design/shaders-react";

export default function HeroBackdrop({ style = "shader" }) {
  if (style === "minimal") return <div className="absolute inset-0 bg-secondary" />;
  if (style === "split") return <div className="absolute inset-0 bg-[linear-gradient(90deg,#0C0C0C_0%,#0C0C0C_58%,#5E5E5E_58%,#121212_100%)]" />;
  return <div className="absolute inset-0 bg-secondary"><Heatmap speed={0.45} contour={0.256} angle={-132} noise={0} innerGlow={0.35} outerGlow={0.2} scale={0.79} colors={["#121212", "#5e5e5e", "#E5E3DC", "#0C0C0C"]} colorBack="#00000000" image="https://shaders.paper.design/images/logos/diamond.svg" style={{ width: "100%", height: "100%" }} /></div>;
}