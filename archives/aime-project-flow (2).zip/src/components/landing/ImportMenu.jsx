import { FileText, Image as ImageIcon, MessageSquare, Link as LinkIcon, Folder } from 'lucide-react';

const OPTIONS = [
  { label: 'Ajouter un document', sub: 'PDF, Word, Excel', icon: FileText },
  { label: 'Ajouter une image', sub: 'Capture écran, Photo, Maquette', icon: ImageIcon },
  { label: 'Ajouter une conversation', sub: 'SMS, Email, WhatsApp export', icon: MessageSquare },
  { label: 'Ajouter une URL', sub: 'Site internet, Référence', icon: LinkIcon },
  { label: 'Ajouter un dossier projet', sub: 'Dossier complet', icon: Folder },
];

export default function ImportMenu({ onAdd }) {
  return (
    <div className="absolute bottom-full left-0 mb-2 w-64 rounded-xl border border-white/10 bg-black/85 backdrop-blur-xl shadow-2xl p-2 z-50">
      {OPTIONS.map((opt) => (
        <button
          key={opt.label}
          onClick={() => onAdd(opt.label)}
          className="w-full flex items-center gap-3 rounded-xl px-3 py-2.5 hover:bg-white/10 transition text-left"
        >
          <div className="w-9 h-9 rounded-lg bg-white/10 flex items-center justify-center flex-shrink-0">
            <opt.icon className="w-4 h-4 text-white" />
          </div>
          <div>
            <p className="text-sm text-white font-medium">{opt.label}</p>
            <p className="text-xs text-white/40">{opt.sub}</p>
          </div>
        </button>
      ))}
    </div>
  );
}