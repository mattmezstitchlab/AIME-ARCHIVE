import { motion } from 'framer-motion';
import { Eye, Database, Brain, Sparkles, Palette, Share2 } from 'lucide-react';

const STEPS = [
  { label: 'SENSE', desc: 'Vous importez vos fichiers, liens et documents.', icon: Eye },
  { label: 'MEMORY', desc: 'AIME observe et structure ce que vous avez déposé.', icon: Database },
  { label: 'THINK', desc: 'AIME comprend les intentions et révèle les patterns.', icon: Brain },
  { label: 'CREATE', desc: 'AIME propose les prochaines étapes cohérentes.', icon: Sparkles },
  { label: 'STUDIO', desc: 'Votre projet prend forme visuellement.', icon: Palette },
  { label: 'SHARE', desc: 'Vous partagez la version publique de votre projet.', icon: Share2 },
];

export default function HowItWorksSection() {
  return (
    <section className="py-24 md:py-32 px-6 bg-secondary text-white">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-16">
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-white/40 font-medium mb-4">02 — Comment AIME comprend</span>
          <h2 className="font-heading text-3xl md:text-5xl font-medium tracking-tight">
            De l'import à la décision.
          </h2>
        </div>

        <div className="space-y-0">
          {STEPS.map((step, i) => {
            const Icon = step.icon;
            return (
              <motion.div
                key={step.label}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, margin: '-80px' }}
                transition={{ duration: 0.5, delay: i * 0.08 }}
                className="flex items-center gap-6 md:gap-8 group"
              >
                <div className="flex flex-col items-center">
                  <div className="w-14 h-14 rounded-full border border-white/15 bg-white/5 flex items-center justify-center shrink-0 group-hover:bg-white/10 transition-colors">
                    <Icon className="w-5 h-5 text-white/70" strokeWidth={1.5} />
                  </div>
                  {i < STEPS.length - 1 && <div className="w-px h-16 md:h-20 bg-white/10 mt-2" />}
                </div>
                <div className="pb-8 flex-1">
                  <div className="flex items-baseline gap-3 mb-1">
                    <span className="text-[10px] text-white/30 font-mono">0{i + 1}</span>
                    <h3 className="font-heading text-xl font-medium tracking-tight">{step.label}</h3>
                  </div>
                  <p className="text-sm text-white/50 leading-relaxed max-w-md">{step.desc}</p>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}