import { Heart, Calendar, Music, Users, BriefcaseBusiness, Globe, FileText, Sparkles } from "lucide-react";

const CONTEXTS = [
  { label: "Mariage", icon: Heart }, { label: "Événement", icon: Calendar },
  { label: "Artiste", icon: Music }, { label: "Association", icon: Users },
  { label: "Entreprise", icon: BriefcaseBusiness }, { label: "Site internet", icon: Globe },
  { label: "Document professionnel", icon: FileText }, { label: "Projet libre", icon: Sparkles },
];

export default function ContextSelector({ onSelect }) {
  return (
    <div className="absolute bottom-full right-0 mb-2 w-64 rounded-xl border border-white/10 bg-black/85 backdrop-blur-xl shadow-2xl p-2 z-50">
      <p className="text-xs text-white/40 uppercase tracking-wider px-3 py-2">Que voulez-vous créer ?</p>
      {CONTEXTS.map((ctx) => {
        const Icon = ctx.icon;
        return <button key={ctx.label} onClick={() => onSelect(ctx)} className="w-full flex items-center gap-3 rounded-lg px-3 py-2 hover:bg-white/10 transition text-left"><Icon className="h-4 w-4 text-white/70" /><span className="text-sm text-white">{ctx.label}</span></button>;
      })}
    </div>
  );
}