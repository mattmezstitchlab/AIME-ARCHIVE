import { FileText, MessageSquare, StickyNote, Receipt, CheckCircle2, Files, Globe, Wrench } from 'lucide-react';

const AVANT = [
  { label: 'Documents dispersés', icon: FileText },
  { label: 'Messages', icon: MessageSquare },
  { label: 'Notes', icon: StickyNote },
  { label: 'Devis', icon: Receipt },
];

const APRES = [
  { label: 'Projet structuré', icon: CheckCircle2 },
  { label: 'Documents générés', icon: Files },
  { label: 'Pages créées', icon: Globe },
  { label: 'Outils activés', icon: Wrench },
];

export default function PromiseSection() {
  return (
    <section id="solutions" className="bg-black py-32 px-6">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-3xl md:text-4xl font-semibold text-white tracking-tight text-center mb-16">
          Un seul espace pour créer,<br />organiser et faire évoluer vos projets.
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="rounded-3xl border border-white/10 bg-white/5 p-8">
            <p className="text-white/40 text-sm uppercase tracking-wider mb-6">Avant</p>
            <div className="space-y-4">
              {AVANT.map((item) => (
                <div key={item.label} className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center">
                    <item.icon className="w-5 h-5 text-white/40" />
                  </div>
                  <span className="text-white/50">{item.label}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="rounded-3xl border border-white/20 bg-gradient-to-br from-violet-500/10 to-fuchsia-500/5 p-8">
            <p className="text-white/60 text-sm uppercase tracking-wider mb-6">Après</p>
            <div className="space-y-4">
              {APRES.map((item) => (
                <div key={item.label} className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center">
                    <item.icon className="w-5 h-5 text-white" />
                  </div>
                  <span className="text-white font-medium">{item.label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}