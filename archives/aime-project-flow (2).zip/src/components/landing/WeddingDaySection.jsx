import { motion } from "framer-motion";

const SLOTS = [
  { time: "08:30", title: "Livraison des fleurs", who: "Atelier Camélia", state: "ok" },
  { time: "10:00", title: "Installation du chapiteau", who: "Technique · 4 personnes", state: "ok" },
  { time: "12:15", title: "Arrivée du traiteur", who: "Maison Bréval", state: "warn" },
  { time: "15:00", title: "Cérémonie", who: "Officiant · témoins", state: "ok" },
  { time: "19:30", title: "Ouverture du bal", who: "DJ Nova", state: "ok" }
];

const DOT = { ok: "#4ade80", warn: "#facc15" };
const STATE_LABEL = { ok: "Confirmé", warn: "En attente de confirmation" };

export default function WeddingDaySection() {
  return (
    <section className="py-24 md:py-32 px-6" style={{ backgroundColor: "var(--brand-secondary)" }}>
      <div className="max-w-4xl mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="brand-badge-dark" style={{ background: "rgba(255,255,255,.1)", color: "rgba(255,255,255,.7)" }}>
            Le jour J
          </span>
          <h2 className="mt-5 text-4xl md:text-5xl" style={{ color: "var(--brand-on-primary)" }}>
            Le jour J se déroule sans vous au téléphone.
          </h2>
          <p className="mt-5" style={{ color: "rgba(255,255,255,.6)" }}>
            Un seul déroulé, partagé avec tous ceux qui travaillent ce jour-là. Chacun voit son horaire,
            son rôle et son lieu. Un changement se propage immédiatement.
          </p>
        </div>

        <div className="rounded-2xl overflow-hidden" style={{ background: "rgba(0,0,0,.85)", border: "1px solid rgba(255,255,255,.1)" }}>
          <div className="px-6 py-4 flex items-center justify-between" style={{ borderBottom: "1px solid rgba(255,255,255,.1)" }}>
            <span className="text-xs font-semibold tracking-wide" style={{ color: "rgba(255,255,255,.9)" }}>
              Samedi 12 juin · Déroulé partagé
            </span>
            <span className="text-[10px] font-semibold tracking-widest px-2 py-0.5 rounded-full"
              style={{ background: "rgba(255,255,255,.1)", color: "rgba(255,255,255,.7)" }}>● LIVE</span>
          </div>
          <div className="p-4 space-y-1.5">
            {SLOTS.map((s, i) => (
              <motion.div key={s.time}
                initial={{ opacity: 0, y: 8 }} whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }} transition={{ delay: i * 0.08 }}
                className="flex items-center gap-4 px-4 py-3 rounded-md"
                style={{ background: "rgba(255,255,255,.05)" }}>
                <span className="text-xs font-semibold tabular-nums w-11" style={{ color: "rgba(255,255,255,.9)" }}>{s.time}</span>
                <span className="flex-1 min-w-0">
                  <span className="block text-sm truncate" style={{ color: "rgba(255,255,255,.9)" }}>{s.title}</span>
                  <span className="block text-xs truncate" style={{ color: "rgba(255,255,255,.5)" }}>{s.who}</span>
                </span>
                <span className="w-2 h-2 rounded-full shrink-0" title={STATE_LABEL[s.state]} style={{ backgroundColor: DOT[s.state] }} />
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}