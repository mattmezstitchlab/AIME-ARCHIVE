import { Link } from 'react-router-dom';
import { Image } from '@/components/ui/image';

const LOGO = "https://media.base44.com/images/public/6a6e07af173a51d175106ce3/6943a2b0a_generated_70bc7922.png";

export default function FloatingNav() {
  return (
    <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 w-full max-w-3xl px-4">
      <div className="flex items-center justify-between rounded-full border border-white/10 bg-black/40 backdrop-blur-xl px-5 py-2.5 shadow-2xl">
        <Link to="/landing" className="flex items-center gap-2 text-white font-semibold"><Image src={LOGO} alt="AIME Logo" className="h-8 w-8 rounded-full bg-white" fittingType="fit" /><span>AIME</span></Link>
        <nav className="hidden md:flex items-center gap-7 text-sm text-white/60">
          <a href="#creer" className="hover:text-white transition">Créer</a>
          <a href="#solutions" className="hover:text-white transition">Solutions</a>
          <a href="#studios" className="hover:text-white transition">Studios</a>
          <a href="#communautes" className="hover:text-white transition">Communautés</a>
          <a href="#tarifs" className="hover:text-white transition">Tarifs</a>
        </nav>
        <Link to="/register" className="rounded-full bg-white text-black text-sm font-medium px-5 py-2 hover:bg-white/90 transition">
          Commencer
        </Link>
      </div>
    </div>
  );
}