import { useState } from 'react';
import HeroBackdrop from './HeroBackdrop';
import { motion, AnimatePresence } from 'framer-motion';
import ProjectBox from './ProjectBox';
import ExamplesBar from './ExamplesBar';
import GenerationAnimation from './GenerationAnimation';

export default function HeroSection({ content }) {
  const [input, setInput] = useState('');
  const [generating, setGenerating] = useState(false);

  return (
    <section id="creer" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <HeroBackdrop style={content.heroStyle} />
      <div className="absolute inset-0 bg-black/40" />

      <div className="relative z-10 w-full max-w-3xl mx-auto px-6 text-center pt-20">
        <AnimatePresence mode="wait">
          {!generating ? (
            <motion.div key="input" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0, y: -20 }} transition={{ duration: 0.5 }}>
              <p className="mb-4 text-xs uppercase text-white/60">{content.eyebrow}</p>
              <h1 className="mb-6 text-4xl font-semibold text-white md:text-6xl">{content.title}</h1>
              <p className="mx-auto mb-10 max-w-xl text-base text-white/60 md:text-lg">{content.subtitle}</p>

              <ProjectBox input={input} setInput={setInput} onGenerate={() => setGenerating(true)} ctaLabel={content.ctaLabel} />
              <ExamplesBar onSelect={(ex) => setInput(ex)} />
            </motion.div>
          ) : (
            <motion.div key="anim" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.5 }}>
              <GenerationAnimation />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
}