import { motion } from "framer-motion";
import { Image } from "@/components/ui/image";

export default function PageHero({ image, badge, title, subtitle, focalPointX = 0.5, focalPointY = 0.5 }) {
  return (
    <section className="relative pt-16">
      <div className="relative h-[46vh] min-h-[340px] md:h-[52vh] overflow-hidden">
        <Image
          src={image}
          alt=""
          focalPointX={focalPointX}
          focalPointY={focalPointY}
          className="absolute inset-0 w-full h-full"
        />
        <div className="absolute inset-0 bg-black/60" />
        <div className="relative h-full flex items-center justify-center px-6">
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center max-w-3xl"
          >
            {badge && (
              <p className="mb-5 text-[11px] uppercase tracking-[0.18em] font-semibold text-white/60">
                {badge}
              </p>
            )}
            <h1 className="font-heading text-3xl md:text-5xl font-medium text-white">{title}</h1>
            {subtitle && (
              <p className="mt-5 text-sm md:text-base text-white/75 max-w-2xl mx-auto leading-relaxed">
                {subtitle}
              </p>
            )}
          </motion.div>
        </div>
      </div>
    </section>
  );
}