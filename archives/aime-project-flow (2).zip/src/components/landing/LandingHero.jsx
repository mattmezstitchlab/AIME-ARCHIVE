import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowRight, ChevronDown } from 'lucide-react';
import HeroBackdrop from './HeroBackdrop';

export default function LandingHero({ content }) {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <HeroBackdrop style={content.heroStyle || 'shader'} />
      <div className="absolute inset-0 bg-black/45" />

      <div className="relative z-10 w-full max-w-4xl mx-auto px-6 text-center pt-20">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        >
          <p className="mb-6 text-xs uppercase tracking-[0.2em] text-white/50 font-medium">
            {content.eyebrow || 'AI + ME'}
          </p>
          <h1 className="mb-8 text-4xl font-heading font-semibold text-white md:text-6xl lg:text-7xl leading-[1.05] tracking-tight">
            {content.title || 'AIME comprend votre projet.\nVous gardez la décision.'}
          </h1>
          <p className="mx-auto mb-12 max-w-2xl text-base text-white/60 md:text-lg leading-relaxed">
            {content.subtitle || 'Importez ce que vous avez déjà. AIME organise les informations, comprend les intentions, révèle les prochaines étapes et vous aide à transformer une idée en projet vivant.'}
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              to="/register"
              className="inline-flex items-center gap-2 px-8 py-4 bg-white text-black rounded-full text-sm font-semibold hover:bg-white/90 transition-all hover:scale-[1.02] active:scale-95"
            >
              {content.ctaLabel || 'Créer mon projet'}
              <ArrowRight className="w-4 h-4" />
            </Link>
            <Link
              to="/comment-ca-marche"
              className="inline-flex items-center gap-2 px-8 py-4 border border-white/20 text-white rounded-full text-sm font-medium hover:bg-white/10 transition-all"
            >
              Découvrir comment AIME fonctionne
            </Link>
          </div>
        </motion.div>
      </div>

      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10">
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
          className="flex flex-col items-center gap-1 text-white/40"
        >
          <span className="text-[10px] uppercase tracking-wider">Défiler</span>
          <ChevronDown className="w-4 h-4" />
        </motion.div>
      </div>
    </section>
  );
}