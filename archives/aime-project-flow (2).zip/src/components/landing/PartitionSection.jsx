import { motion } from 'framer-motion';
import { Image } from '@/components/ui/image';

export default function PartitionSection({ content }) {
  const c = content || {};
  return (
    <section className="py-24 md:py-32 px-6 bg-background">
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="brand-badge mb-4">03 — La Partition Vivante™</span>
          <h2 className="font-heading text-3xl md:text-5xl font-medium tracking-tight mb-6">
            {c.title || 'Votre projet devient lisible.'}
          </h2>
          <p className="max-w-2xl mx-auto text-base md:text-lg text-muted-foreground leading-relaxed">
            {c.text || 'Identité, mémoire, temps, relations, création et futurs possibles sont réunis dans une même vision.'}
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.7 }}
          className="relative max-w-2xl mx-auto py-12"
        >
          {/* Arbre de la partition */}
          <div className="flex flex-col items-center">
            <div className="w-20 h-20 rounded-full bg-foreground text-background flex items-center justify-center mb-2">
              <span className="text-xs font-semibold uppercase tracking-wider">Projet</span>
            </div>
            <div className="h-8 w-px bg-border" />
            <div className="grid grid-cols-3 gap-4 md:gap-8 w-full max-w-md">
              {['IDENTITÉ', 'MÉMOIRE', 'TEMPS'].map((label) => (
                <div key={label} className="flex flex-col items-center">
                  <div className="px-4 py-2 rounded-full border border-border bg-card text-xs font-semibold uppercase tracking-wider">{label}</div>
                </div>
              ))}
            </div>
            <div className="h-8 w-px bg-border" />
            <div className="grid grid-cols-3 gap-4 md:gap-8 w-full max-w-md">
              {['CRÉATION', 'RELATIONS', 'FUTURS'].map((label) => (
                <div key={label} className="flex flex-col items-center">
                  <div className="px-4 py-2 rounded-full border border-border bg-card text-xs font-semibold uppercase tracking-wider">{label}</div>
                </div>
              ))}
            </div>
          </div>
        </motion.div>

        {c.image && (
          <div className="mt-12 max-w-3xl mx-auto aspect-video rounded-lg overflow-hidden border border-border">
            <Image src={c.image} alt="Partition Vivante" className="w-full h-full" fittingType="fill" />
          </div>
        )}
      </div>
    </section>
  );
}