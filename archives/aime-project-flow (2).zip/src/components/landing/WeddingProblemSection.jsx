import { motion } from 'framer-motion';

const PROBLEMS = [
  { before: 'Un tableur pour le budget', after: 'Un budget vivant, relié à chaque prestataire' },
  { before: 'Des devis perdus dans les mails', after: 'Tous les documents au même endroit' },
  { before: 'Trois groupes WhatsApp', after: 'Un espace par prestataire, sans bruit' },
  { before: 'Un déroulé imprimé la veille', after: 'Une timeline partagée, à jour en direct' },
  { before: 'Des prestataires qui ne savent rien', after: 'Chacun voit ce qui le concerne' },
];

export default function WeddingProblemSection() {
  return (
    <section className="py-24 px-6 bg-background">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-16">
          <span className="brand-badge mb-4">Le problème</span>
          <h2 className="font-heading text-3xl md:text-5xl font-medium mb-4">
            Organiser un mariage, ce n'est pas une seule tâche.
          </h2>
          <p className="text-muted-foreground max-w-xl mx-auto">
            C'est un budget, des dizaines de prestataires, des centaines d'invités et une journée qui doit se dérouler à la minute. Aujourd'hui, tout cela vit dans des outils qui ne se parlent pas.
          </p>
        </div>

        <div className="rounded-lg border border-border overflow-hidden">
          {PROBLEMS.map((row, i) => (
            <motion.div
              key={row.before}
              initial={{ opacity: 0, y: 12 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.4, delay: i * 0.06 }}
              className={`grid md:grid-cols-2 ${i > 0 ? 'border-t border-border' : ''}`}
            >
              <div className="px-6 py-5 bg-card">
                <p className="text-sm text-muted-foreground line-through decoration-muted-foreground/40">
                  {row.before}
                </p>
              </div>
              <div className="px-6 py-5 border-t md:border-t-0 md:border-l border-border">
                <p className="text-sm font-medium">{row.after}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}