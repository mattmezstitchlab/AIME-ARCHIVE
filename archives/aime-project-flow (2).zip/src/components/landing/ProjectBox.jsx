import { useState, useEffect } from 'react';
import { Paperclip, WandSparkles, FileText, X } from 'lucide-react';
import ImportMenu from './ImportMenu';
import ContextSelector from './ContextSelector';
import DocumentAnalysis from './DocumentAnalysis';

const PLACEHOLDERS = [
  'Créer mon mariage...',
  'Créer mon association...',
  'Créer mon studio artiste...',
  'Créer mon entreprise...',
  'Organiser mon événement...',
];

export default function ProjectBox({ input, setInput, onGenerate, ctaLabel = "Créer" }) {
  const [phIdx, setPhIdx] = useState(0);
  const [showImport, setShowImport] = useState(false);
  const [showContext, setShowContext] = useState(false);
  const [context, setContext] = useState(null);
  const [files, setFiles] = useState([]);
  const [analyzing, setAnalyzing] = useState(false);

  useEffect(() => {
    if (input) return;
    const interval = setInterval(() => setPhIdx(i => (i + 1) % PLACEHOLDERS.length), 3000);
    return () => clearInterval(interval);
  }, [input]);

  const handleAddFile = (fileLabel) => {
    setShowImport(false);
    setAnalyzing(true);
    setTimeout(() => {
      setFiles(prev => [...prev, fileLabel]);
      setAnalyzing(false);
    }, 2600);
  };

  const handleSelectContext = (ctx) => {
    setContext(ctx);
    setShowContext(false);
    if (input.trim() || files.length > 0) onGenerate();
  };

  const handleGenerate = () => {
    if (!input.trim() && files.length === 0) return;
    onGenerate();
  };

  return (
    <div className="w-full max-w-[700px] mx-auto">
      {files.length > 0 && (
        <div className="flex flex-wrap gap-2 mb-3 justify-center">
          {files.map((f, i) => (
            <div key={i} className="flex items-center gap-1.5 rounded-full bg-white/10 border border-white/15 px-3 py-1 text-xs text-white/80">
              <FileText className="w-3 h-3" />
              {f}
              <button onClick={() => setFiles(prev => prev.filter((_, idx) => idx !== i))} className="ml-1 text-white/40 hover:text-white">
                <X className="w-3 h-3" />
              </button>
            </div>
          ))}
        </div>
      )}

      <div className="relative flex items-center gap-2 rounded-2xl bg-white/8 backdrop-blur-xl border border-white/15 shadow-2xl px-3 h-[90px]">
        <div className="relative flex-shrink-0">
          <button
            onClick={() => { setShowImport(!showImport); setShowContext(false); }}
            className="w-11 h-11 rounded-full bg-white/10 hover:bg-white/20 border border-white/15 flex items-center justify-center transition"
          >
            <Paperclip className="w-5 h-5 text-white" />
          </button>
          {showImport && (
            <>
              <div className="fixed inset-0 z-40" onClick={() => setShowImport(false)} />
              <ImportMenu onAdd={handleAddFile} />
            </>
          )}
        </div>

        <div className="flex-1 relative h-full flex items-center">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleGenerate(); } }}
            placeholder={PLACEHOLDERS[phIdx]}
            className="w-full bg-transparent text-white resize-none outline-none text-base placeholder-white/40"
            style={{ height: '56px' }}
          />
        </div>

        <div className="relative flex-shrink-0">
          <button onClick={() => { setShowContext(!showContext); setShowImport(false); }} disabled={!input.trim() && files.length === 0} className="flex items-center gap-1.5 rounded-full bg-white text-black text-sm font-medium px-4 py-2.5 hover:bg-white/90 transition disabled:opacity-30 disabled:cursor-not-allowed">
            <WandSparkles className="w-4 h-4" /> {ctaLabel}
          </button>
          {showContext && <><div className="fixed inset-0 z-40" onClick={() => setShowContext(false)} /><ContextSelector onSelect={handleSelectContext} /></>}
        </div>
      </div>

      {context && (
        <div className="mt-2 text-center text-sm text-white/50">
          Type : {context.label}
        </div>
      )}

      {analyzing && <DocumentAnalysis />}
    </div>
  );
}