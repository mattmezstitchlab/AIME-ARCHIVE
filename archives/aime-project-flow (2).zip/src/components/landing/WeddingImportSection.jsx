import { motion } from "framer-motion";
import { Link2, FileText, Image, ArrowRight, Check } from "lucide-react";

const SOURCES = [
  { icon: Link2, label: "Le site du traiteur" },
  { icon: FileText, label: "Un devis PDF" },
  { icon: Image, label: "Une capture d'écran" }
];

const FIELDS = [
  ["Prestataire", "Domaine des Oliviers"],
  ["Catégorie", "Lieu de réception"],
  ["Budget estimé", "8 400 €"],
  ["Contact", "contact@domaine-oliviers.fr"],
  ["Document", "Devis · v1 · à vérifier"]
];

export default function WeddingImportSection() {
  return (
    <section className="py-24 md:py-32 px-6 bg-background">
      <div className="max-w-5xl mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="brand-badge">L'import</span>
          <h2 className="mt-5 text-4xl md:text-5xl">
            Un lien, un devis, une capture. Rien à ressaisir.
          </h2>
          <p className="mt-5 text-muted-foreground">
            Collez ce que vous avez déjà. AIME lit la source, en extrait le prestataire, son budget et
            ses coordonnées, et vous montre le résultat avant de l'enregistrer.
          </p>
        </div>

        <div className="grid md:grid-cols-[1fr_auto_1.2fr] gap-8 md:gap-6 items-center">
          <div className="space-y-3">
            {SOURCES.map((s, i) => {
              const Icon = s.icon;
              return (
                <motion.div key={s.label}
                  initial={{ opacity: 0, x: -12 }} whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }} transition={{ delay: i * 0.1 }}
                  className="flex items-center gap-3 px-4 py-3.5 rounded-xl border border-border bg-card">
                  <Icon className="w-4 h-4 text-muted-foreground" strokeWidth={1.5} />
                  <span className="text-sm">{s.label}</span>
                </motion.div>
              );
            })}
          </div>

          <ArrowRight className="hidden md:block w-6 h-6 text-muted-foreground mx-auto" strokeWidth={1.5} />

          <motion.div
            initial={{ opacity: 0, y: 12 }} whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }} transition={{ delay: 0.3 }}
            className="rounded-2xl border border-border bg-background overflow-hidden">
            <div className="px-5 py-3 border-b border-border flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Fiche proposée
              </span>
              <span className="brand-badge">à valider</span>
            </div>
            <dl className="divide-y divide-border">
              {FIELDS.map(([k, v]) => (
                <div key={k} className="px-5 py-3 flex items-baseline justify-between gap-4">
                  <dt className="text-xs text-muted-foreground shrink-0">{k}</dt>
                  <dd className="text-sm text-right">{v}</dd>
                </div>
              ))}
            </dl>
            <div className="px-5 py-3.5 border-t border-border flex items-center gap-2 text-sm">
              <Check className="w-4 h-4" strokeWidth={2} />
              Vous validez, la fiche entre dans le projet
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}