import { motion } from 'framer-motion';

const PILLARS = [
  {
    label: 'AI',
    title: 'AIME propose',
    text: 'Elle lit vos documents, comprend votre mariage, structure le budget, repère ce qui manque et prépare le déroulé.',
  },
  {
    label: 'ME',
    title: 'Vous décidez',
    text: 'Rien n\'est validé sans vous. Chaque proposition passe par votre accord. C\'est votre mariage, pas celui d\'un algorithme.',
  },
];

export default function WeddingAiMeSection() {
  return (
    <section className="py-24 px-6 bg-foreground text-background">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-16">
          <span className="brand-badge-dark mb-4" style={{ background: 'rgba(255,255,255,0.1)', color: 'rgba(255,255,255,0.7)' }}>
            AI + ME
          </span>
          <h2 className="font-heading text-3xl md:text-5xl font-medium mb-4">
            L'intelligence organise. Vous gardez la décision.
          </h2>
          <p className="text-white/50 max-w-xl mx-auto">
            Un mariage est fait de choix personnels. AIME ne les fait jamais à votre place — elle vous enlève tout le reste.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {PILLARS.map((p, i) => (
            <motion.div
              key={p.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-80px' }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="rounded-lg p-8"
              style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}
            >
              <span className="font-heading text-5xl font-semibold text-white/20">{p.label}</span>
              <h3 className="font-heading text-xl font-medium mt-6 mb-3">{p.title}</h3>
              <p className="text-sm text-white/50">{p.text}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}