import { motion } from 'framer-motion';
import { Image } from '@/components/ui/image';

export default function ProblemSection({ content }) {
  const c = content || {};
  return (
    <section className="py-24 md:py-32 px-6 bg-background">
      <div className="max-w-5xl mx-auto">
        <div className="grid md:grid-cols-2 gap-12 md:gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.6 }}
          >
            <span className="brand-badge mb-4">01 — Le problème</span>
            <h2 className="font-heading text-3xl md:text-5xl font-medium tracking-tight mb-6 leading-[1.1]">
              {c.title || 'Un projet commence rarement avec un plan parfait.'}
            </h2>
            <p className="text-base md:text-lg text-muted-foreground leading-relaxed">
              {c.text || 'Il existe déjà dans des idées, des photos, des documents, des messages, des liens, des fichiers et des souvenirs. AIME rassemble ces fragments et leur donne une forme.'}
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.96 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.6, delay: 0.15 }}
            className="relative aspect-[4/3] rounded-lg overflow-hidden border border-border"
          >
            {c.image ? (
              <Image src={c.image} alt="" className="w-full h-full" fittingType="fill" />
            ) : (
              <div className="w-full h-full bg-gradient-to-br from-muted to-card flex items-center justify-center">
                <div className="grid grid-cols-3 gap-3 p-8 opacity-40">
                  {[...Array(9)].map((_, i) => (
                    <div key={i} className="aspect-square rounded border border-border bg-background" />
                  ))}
                </div>
              </div>
            )}
          </motion.div>
        </div>
      </div>
    </section>
  );
}