import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Check } from "lucide-react";

const PLANS = [
  {
    name: "Découverte",
    price: "0 €",
    note: "Pour commencer aujourd'hui",
    features: ["1 mariage", "Budget et prestataires", "3 prestataires invités", "Documents essentiels"],
    cta: "Créer mon mariage",
    dark: false
  },
  {
    name: "Le Grand Jour",
    price: "89 €",
    note: "Une fois, jusqu'au jour J",
    features: [
      "Prestataires et invités illimités",
      "Déroulé du jour J partagé",
      "Import de devis, liens et PDF",
      "Site public du mariage et RSVP",
      "Espace dédié pour chaque prestataire"
    ],
    cta: "Créer mon mariage",
    dark: true
  },
  {
    name: "Planner",
    price: "Sur devis",
    note: "Pour les professionnels",
    features: ["Plusieurs mariages", "Vue d'ensemble des dossiers", "Rôles et droits délégués", "Accompagnement à la mise en route"],
    cta: "Nous écrire",
    to: "/contact",
    dark: false
  }
];

export default function WeddingPricingSection() {
  return (
    <section className="py-24 md:py-32 px-6 bg-background">
      <div className="max-w-6xl mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="brand-badge">Tarifs</span>
          <h2 className="mt-5 text-4xl md:text-5xl">Un prix pour un mariage, pas un abonnement à vie.</h2>
          <p className="mt-5 text-muted-foreground">
            Vous organisez un mariage une fois. Vous payez une fois.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 items-start">
          {PLANS.map((p, i) => (
            <motion.article key={p.name}
              initial={{ opacity: 0, y: 14 }} whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }} transition={{ delay: i * 0.1 }}
              className={"rounded-2xl p-8 border " + (p.dark ? "border-transparent" : "border-border bg-card")}
              style={p.dark ? { backgroundColor: "var(--brand-secondary)" } : undefined}>
              <h3 className="text-lg" style={p.dark ? { color: "var(--brand-on-primary)" } : undefined}>{p.name}</h3>
              <p className="mt-4 text-4xl" style={p.dark ? { color: "var(--brand-on-primary)" } : undefined}>{p.price}</p>
              <p className="mt-1.5 text-xs" style={{ color: p.dark ? "rgba(255,255,255,.5)" : "hsl(var(--muted-foreground))" }}>
                {p.note}
              </p>
              <ul className="mt-6 space-y-2.5">
                {p.features.map((f) => (
                  <li key={f} className="flex gap-2.5 text-sm"
                    style={{ color: p.dark ? "rgba(255,255,255,.8)" : "hsl(var(--muted-foreground))" }}>
                    <Check className="w-4 h-4 shrink-0 mt-0.5" strokeWidth={1.8} />
                    {f}
                  </li>
                ))}
              </ul>
              <Link to={p.to || "/login"}
                className={"mt-8 w-full " + (p.dark ? "brand-outline-btn" : "brand-secondary-btn")}>
                {p.cta}
              </Link>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}