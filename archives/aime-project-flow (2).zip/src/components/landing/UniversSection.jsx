import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { UNIVERS } from '@/lib/universConfig';

/**
 * Version compacte pour la landing universelle.
 * Présente le concept puis renvoie vers la page /univers dédiée.
 */
export default function UniversSection() {
  return (
    <section className="py-24 md:py-32 px-6 bg-background">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <span className="brand-badge mb-4">05 — Les univers AIME</span>
          <h2 className="font-heading text-3xl md:text-5xl font-medium tracking-tight mb-4">
            Un même moteur, des mondes différents.
          </h2>
          <p className="text-muted-foreground max-w-xl mx-auto leading-relaxed">
            AIME s'adapte à votre contexte. Le moteur reste le même.
          </p>
        </motion.div>

        <div className="grid sm:grid-cols-2 gap-3 mb-10">
          {UNIVERS.map((uni, i) => {
            const Icon = uni.icon;
            const available = uni.status === 'available';
            const inner = (
              <>
                <div className="w-9 h-9 rounded-full bg-muted flex items-center justify-center shrink-0">
                  <Icon className="w-4 h-4 text-foreground" strokeWidth={1.5} />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="font-heading text-sm font-medium tracking-tight">{uni.name}</p>
                  <p className="text-xs text-muted-foreground truncate">{uni.tagline}</p>
                </div>
                <span className={'text-[10px] uppercase tracking-wider font-semibold px-2.5 py-1 rounded-full shrink-0 ' + (available ? 'bg-foreground text-background' : 'bg-muted text-muted-foreground')}>
                  {available ? 'Disponible' : 'Bientôt'}
                </span>
              </>
            );
            return (
              <motion.div
                key={uni.slug}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-60px' }}
                transition={{ duration: 0.4, delay: i * 0.06 }}
              >
                {available ? (
                  <Link to={uni.to} className="flex items-center gap-3 rounded-lg border border-border bg-card px-4 py-3.5 hover:shadow-sm transition-all">
                    {inner}
                  </Link>
                ) : (
                  <div className="flex items-center gap-3 rounded-lg border border-border bg-card px-4 py-3.5 opacity-70">
                    {inner}
                  </div>
                )}
              </motion.div>
            );
          })}
        </div>

        <div className="text-center">
          <Link to="/univers" className="inline-flex items-center gap-2 text-sm font-medium hover:gap-3 transition-all">
            Découvrir les univers AIME <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </div>
    </section>
  );
}