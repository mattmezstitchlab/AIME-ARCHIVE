import { motion } from 'framer-motion';
import { Calendar, Users, Zap, Share2, Check } from 'lucide-react';

const MODULES = [
  {
    title: 'Organiser',
    icon: Calendar,
    text: 'Tout ce que contient un mariage, structuré dès le premier jour.',
    items: ['Budget', 'Tâches', 'Planning', 'Invités', 'RSVP', 'Lieux', 'Prestataires', 'Documents', 'Inspiration', 'Programme'],
  },
  {
    title: 'Collaborer',
    icon: Users,
    text: 'Chaque personne impliquée a sa place, avec les bons droits.',
    items: ['Invitation des prestataires', 'Rôles & permissions', 'Accès limité', 'Échanges liés au mariage', 'Documents partagés', 'Disponibilité'],
  },
  {
    title: 'Orchestrer',
    icon: Zap,
    text: 'Le jour J se joue à la minute. AIME tient la partition.',
    items: ['Timeline du jour J', 'Déroulé minute par minute', 'Responsables', 'Horaires', 'Contacts', 'Alertes', 'Changements en direct', 'Plan B'],
  },
  {
    title: 'Partager',
    icon: Share2,
    text: 'Une page publique générée depuis votre projet, jamais saisie deux fois.',
    items: ['Site public', 'Faire-part', 'RSVP', 'Galerie', 'Livre d\'or', 'Informations pratiques', 'Programme'],
  },
];

export default function WeddingModulesSection() {
  return (
    <section className="py-24 px-6 bg-background">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <span className="brand-badge mb-4">Ce que vous pouvez faire</span>
          <h2 className="font-heading text-3xl md:text-5xl font-medium">
            Quatre dimensions, un seul projet.
          </h2>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {MODULES.map((mod, i) => {
            const Icon = mod.icon;
            return (
              <motion.div
                key={mod.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-80px' }}
                transition={{ duration: 0.5, delay: i * 0.08 }}
                className="bg-card border border-border rounded-lg p-8"
              >
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 rounded-full bg-foreground text-background flex items-center justify-center">
                    <Icon className="w-4 h-4" strokeWidth={1.5} />
                  </div>
                  <h3 className="font-heading text-xl font-medium">{mod.title}</h3>
                </div>
                <p className="text-sm text-muted-foreground mb-6">{mod.text}</p>
                <div className="flex flex-wrap gap-x-3 gap-y-1.5">
                  {mod.items.map((item) => (
                    <span key={item} className="inline-flex items-center gap-1.5 text-sm text-muted-foreground">
                      <Check className="w-3 h-3" strokeWidth={2} />
                      {item}
                    </span>
                  ))}
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}