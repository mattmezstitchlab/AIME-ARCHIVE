import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import AimeLogo from '@/components/AimeLogo';

const NAV_LINKS = [
  { to: '/comment-ca-marche', label: 'Comment ça marche' },
  { to: '/a-propos', label: 'À propos' },
];

export default function LandingNav() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => { setMobileOpen(false); }, [location.pathname]);

  return (
    <>
      <header
        className="fixed top-0 inset-x-0 z-50 transition-all duration-300"
        style={{
          background: scrolled ? 'rgba(255,255,255,0.92)' : 'rgba(255,255,255,0.7)',
          backdropFilter: 'blur(16px)',
          borderBottom: '1px solid var(--brand-border)',
        }}
      >
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center">
            <AimeLogo size="md" />
          </Link>

          <nav className="hidden md:flex items-center gap-8">
            {NAV_LINKS.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                className="text-sm font-medium transition-colors"
                style={{ color: 'var(--brand-muted-foreground)' }}
              >
                {link.label}
              </Link>
            ))}
          </nav>

          <div className="hidden md:flex items-center gap-3">
            <Link
              to="/login"
              className="text-sm font-medium transition-colors"
              style={{ color: 'var(--brand-text)' }}
            >
              Connexion
            </Link>
            <Link
              to="/register"
              className="brand-secondary-btn text-sm"
            >
              Créer mon mariage
            </Link>
          </div>

          <button
            className="md:hidden brand-icon-btn"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label="Menu"
          >
            {mobileOpen ? <X className="w-4 h-4" style={{ color: 'var(--brand-text)' }} /> : <Menu className="w-4 h-4" style={{ color: 'var(--brand-text)' }} />}
          </button>
        </div>
      </header>

      {mobileOpen && (
        <div className="fixed inset-0 z-40 md:hidden bg-background pt-16 px-6 pb-8 flex flex-col">
          <nav className="flex flex-col gap-1 mt-6">
            {NAV_LINKS.map((link) => (
              <Link key={link.to} to={link.to} className="py-3 text-lg font-heading font-medium border-b border-border">
                {link.label}
              </Link>
            ))}
          </nav>
          <div className="mt-auto space-y-3">
            <Link to="/login" className="block py-3 text-center text-sm font-medium border border-border rounded-full">Connexion</Link>
            <Link to="/register" className="block py-3 text-center text-sm font-medium bg-foreground text-background rounded-full">Créer mon mariage</Link>
          </div>
        </div>
      )}
    </>
  );
}