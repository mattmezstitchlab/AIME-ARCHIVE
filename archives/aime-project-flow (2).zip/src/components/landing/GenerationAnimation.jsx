import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Search, LayoutGrid, Boxes, CheckCircle2, Check, ArrowRight } from 'lucide-react';

const STEPS = [
  { label: 'Compréhension', icon: Search },
  { label: 'Architecture', icon: LayoutGrid },
  { label: 'Modules', icon: Boxes },
  { label: 'Workspace', icon: CheckCircle2 },
];

export default function GenerationAnimation() {
  const [step, setStep] = useState(0);
  const [done, setDone] = useState(false);

  useEffect(() => {
    if (step < STEPS.length) {
      const t = setTimeout(() => setStep(s => s + 1), 700);
      return () => clearTimeout(t);
    }
    const t = setTimeout(() => setDone(true), 600);
    return () => clearTimeout(t);
  }, [step]);

  if (done) {
    return (
      <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="py-12">
        <h2 className="text-4xl md:text-5xl font-semibold text-white tracking-tight mb-8">Votre projet prend vie.</h2>
        <Link to="/register" className="inline-flex items-center gap-2 rounded-full bg-white text-black px-8 py-3 font-medium hover:bg-white/90 transition">
          Commencer <ArrowRight className="w-4 h-4" />
        </Link>
      </motion.div>
    );
  }

  return (
    <div className="py-12 max-w-md mx-auto text-left">
      {STEPS.map((s, i) => {
        const completed = i < step;
        const current = i === step;
        return (
          <motion.div
            key={i}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: i <= step ? 1 : 0.3, x: 0 }}
            transition={{ duration: 0.4 }}
            className="flex items-center gap-4 py-3"
          >
            <div className={`w-10 h-10 rounded-full flex items-center justify-center border transition ${completed ? 'bg-white text-black border-white' : current ? 'border-white/40 text-white' : 'border-white/10 text-white/20'}`}>
              {completed ? <Check className="w-5 h-5" /> : <s.icon className="w-5 h-5" />}
            </div>
            <span className={`text-lg transition ${completed ? 'text-white' : current ? 'text-white/80' : 'text-white/30'}`}>{s.label}</span>
          </motion.div>
        );
      })}
    </div>
  );
}