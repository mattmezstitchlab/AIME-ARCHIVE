import { Link } from 'react-router-dom';
import AimeLogo from '@/components/AimeLogo';

const FOOTER_SECTIONS = [
  {
    title: 'Produit',
    links: [
      { to: '/comment-ca-marche', label: 'Comment ça marche' },
      { to: '/landing', label: 'Le mariage' },
    ],
  },
  {
    title: 'Entreprise',
    links: [
      { to: '/a-propos', label: 'À propos' },
      { to: '/univers', label: 'Notre vision' },
      { to: '/contact', label: 'Contact' },
    ],
  },
  {
    title: 'Ressources',
    links: [
      { to: '/faq', label: 'FAQ' },
    ],
  },
  {
    title: 'Légal',
    links: [
      { to: '/privacy', label: 'Confidentialité' },
      { to: '/terms', label: 'Conditions' },
    ],
  },
];

export default function LandingFooter() {
  return (
    <footer className="bg-foreground text-background">
      <div className="max-w-7xl mx-auto px-6 py-16">
        <div className="grid grid-cols-2 md:grid-cols-6 gap-8 mb-12">
          <div className="col-span-2">
            <Link to="/" className="inline-flex items-center mb-4">
              <AimeLogo size="lg" dark />
            </Link>
            <p className="text-sm text-white/40 max-w-xs leading-relaxed">
              L'intelligence qui organise votre mariage — de la première idée au jour J.
            </p>
          </div>

          {FOOTER_SECTIONS.map((section) => (
            <div key={section.title}>
              <h4 className="text-xs uppercase tracking-wider text-white/40 font-semibold mb-4">{section.title}</h4>
              <ul className="space-y-2.5">
                {section.links.map((link) => (
                  <li key={link.to}>
                    <Link to={link.to} className="text-sm text-white/60 hover:text-white transition-colors">
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="pt-8 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-xs text-white/30">© 2026 AIME — LE MONDE AIME</p>
          <p className="text-xs text-white/30">AI + ME™ — Partition Vivante™</p>
        </div>
      </div>
    </footer>
  );
}