import { motion } from 'framer-motion';
import { MessageCircle, Users, Calendar, Heart } from 'lucide-react';

const STEPS = [
  {
    icon: MessageCircle,
    title: 'Vous décrivez votre mariage',
    text: 'Une phrase suffit. La date, le lieu, le nombre d\'invités. AIME comprend et crée le projet complet — budget, tâches, modules — sans formulaire à remplir.',
  },
  {
    icon: Users,
    title: 'Vos prestataires rejoignent le projet',
    text: 'Traiteur, photographe, lieu, DJ. Chacun reçoit un lien vers son propre espace, sans créer de compte, et n\'accède qu\'à ce qui le concerne.',
  },
  {
    icon: Calendar,
    title: 'Le déroulé se construit tout seul',
    text: 'Les horaires d\'arrivée, les temps d\'installation et les missions de chacun alimentent une timeline unique du jour J, à jour en permanence.',
  },
  {
    icon: Heart,
    title: 'Le jour J est orchestré',
    text: 'Tout le monde suit le même déroulé, minute par minute. Vous n\'avez plus à répondre au téléphone pendant votre propre mariage.',
  },
];

export default function WeddingParcoursSection() {
  return (
    <section className="py-24 px-6 bg-card">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-16">
          <span className="brand-badge mb-4">Le parcours</span>
          <h2 className="font-heading text-3xl md:text-5xl font-medium">
            De l'idée au jour J, en quatre temps.
          </h2>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {STEPS.map((step, i) => {
            const Icon = step.icon;
            return (
              <motion.div
                key={step.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-80px' }}
                transition={{ duration: 0.5, delay: i * 0.08 }}
                className="bg-background border border-border rounded-lg p-8"
              >
                <div className="flex items-center justify-between mb-6">
                  <div className="w-10 h-10 rounded-full bg-foreground text-background flex items-center justify-center">
                    <Icon className="w-4 h-4" strokeWidth={1.5} />
                  </div>
                  <span className="font-heading text-3xl font-semibold text-muted-foreground/25">
                    0{i + 1}
                  </span>
                </div>
                <h3 className="font-heading text-xl font-medium mb-3">{step.title}</h3>
                <p className="text-sm text-muted-foreground">{step.text}</p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}