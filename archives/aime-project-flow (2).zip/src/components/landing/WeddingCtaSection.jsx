import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

export default function WeddingCtaSection() {
  return (
    <section className="py-24 px-6 bg-background">
      <div className="max-w-2xl mx-auto text-center">
        <h2 className="font-heading text-3xl md:text-5xl font-medium mb-6">
          Prêt à organiser votre mariage ?
        </h2>
        <p className="text-muted-foreground mb-10">
          Un couple, des invités, plusieurs prestataires, des documents, un planning et un jour unique — réunis dans un même projet.
        </p>
        <Link
          to="/register"
          className="inline-flex items-center gap-2 px-8 py-4 bg-foreground text-background rounded-full text-sm font-semibold hover:opacity-90 transition-all"
        >
          Créer mon mariage <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
    </section>
  );
}