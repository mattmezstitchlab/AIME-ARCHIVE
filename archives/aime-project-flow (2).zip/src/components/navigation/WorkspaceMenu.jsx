import { Link } from "react-router-dom";
import { LayoutDashboard, Globe, Layers3, Settings, PanelTop } from "lucide-react";
import { Image } from "@/components/ui/image";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { useAssociation } from "@/components/AssociationProvider";

const LOGO = "https://media.base44.com/images/public/6a6e07af173a51d175106ce3/6943a2b0a_generated_70bc7922.png";
const destinations = [
  ["Tableau de bord", "/", LayoutDashboard],
  ["Landing", "/landing", Globe],
  ["Studio", "/studio/page", Layers3],
  ["Administration landing", "/admin/landing", PanelTop],
  ["Paramètres", "/association/parametres", Settings],
];

export default function WorkspaceMenu() {
  const { me } = useAssociation();
  const visibleDestinations = destinations.filter(([, to]) => to !== "/admin/landing" || me?.role === "admin");
  return <DropdownMenu>
    <DropdownMenuTrigger asChild><button className="brand-icon-btn overflow-hidden" aria-label="Ouvrir les espaces AIME"><Image src={LOGO} alt="AIME Logo" className="h-7 w-7" fittingType="fit" /></button></DropdownMenuTrigger>
    <DropdownMenuContent align="end" className="w-64 rounded-xl border-border bg-popover p-2 shadow-lg">
      <DropdownMenuLabel className="px-3 py-2 text-xs uppercase text-muted-foreground">Espaces AIME</DropdownMenuLabel><DropdownMenuSeparator />
      {visibleDestinations.map(([label, to, Icon]) => <DropdownMenuItem key={to} asChild><Link to={to} className="flex cursor-pointer items-center gap-3 rounded-lg px-3 py-2.5"><Icon className="h-4 w-4" />{label}</Link></DropdownMenuItem>)}
    </DropdownMenuContent>
  </DropdownMenu>;
}