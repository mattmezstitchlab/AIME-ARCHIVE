import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { createProjectFromAI, createProjectManual } from "@/lib/projectEngine";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Wand2, Loader2, ArrowRight, FileText, Building2 } from "lucide-react";
import { useAssociation } from "@/components/AssociationProvider";
import { useAI } from "@/components/AIProvider";

export default function ProjectComposer({ placeholder = "Ex. : Je veux organiser un atelier musical pour des enfants et des seniors du quartier…" }) {
  const [mode, setMode] = useState("manuel");
  const [value, setValue] = useState("");
  const [loading, setLoading] = useState(false);
  const [stage, setStage] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();
  const { activeAssociationId } = useAssociation();
  const { aiEnabled } = useAI();

  useEffect(() => { if (!aiEnabled) setMode("manuel"); }, [aiEnabled]);

  const [form, setForm] = useState({ name: "", description: "", vision: "", target_audience: "", location: "" });

  async function handleCreateIA() {
    if (!value.trim()) return;
    setLoading(true);
    setError("");
    setStage("AIME écoute votre intention…");
    try {
      setStage("AIME structure le projet, le calendrier et le budget…");
      const projectId = await createProjectFromAI(value.trim(), activeAssociationId);
      navigate("/projects/" + projectId);
    } catch (e) {
      setError("Une erreur est survenue pendant la structuration. Réessayez.");
      setLoading(false);
      setStage("");
    }
  }

  async function handleCreateManual() {
    if (!form.name.trim()) return;
    setLoading(true);
    setError("");
    try {
      const projectId = await createProjectManual(form, activeAssociationId);
      navigate("/projects/" + projectId);
    } catch (e) {
      setError("Erreur lors de la création. Réessayez.");
      setLoading(false);
    }
  }

  if (!activeAssociationId) {
    return (
      <div className="rounded-2xl border border-border bg-card p-6 soft-shadow text-center">
        <Building2 className="w-8 h-8 text-muted-foreground mx-auto mb-3" />
        <p className="text-sm font-medium">Créez d'abord votre association</p>
        <p className="text-xs text-muted-foreground mt-1">Vous devez avoir une association active pour créer un projet. Une boîte de dialogue devrait s'afficher pour vous guider.</p>
      </div>
    );
  }

  if (loading && mode === "ia") {
    return (
      <div className="rounded-2xl border border-border bg-card p-6 soft-shadow animate-float-up">
        <div className="flex items-center gap-3 text-primary">
          <Wand2 className="w-5 h-5 animate-pulse" />
          <span className="font-medium">{stage}</span>
        </div>
        <div className="mt-5 space-y-3">
          <div className="h-3 w-2/3 rounded bg-muted animate-pulse" />
          <div className="h-3 w-1/2 rounded bg-muted animate-pulse" />
          <div className="h-3 w-3/5 rounded bg-muted animate-pulse" />
        </div>
        <div className="flex items-center gap-2 mt-5 text-xs text-muted-foreground">
          <Loader2 className="w-3.5 h-3.5 animate-spin" />
          AIME relie les informations et prépare votre dossier…
        </div>
      </div>
    );
  }

  return (
    <div className="rounded-2xl border border-border bg-card soft-shadow overflow-hidden">
      <div className="flex border-b border-border">
        <button onClick={() => setMode("manuel")}
          className={"flex-1 flex items-center justify-center gap-1.5 px-4 py-2.5 text-sm font-medium transition " + (mode === "manuel" ? "bg-card text-foreground" : "text-muted-foreground hover:text-foreground")}>
          <FileText className="w-4 h-4" /> Création manuelle
        </button>
        {aiEnabled && (
          <button onClick={() => setMode("ia")}
            className={"flex-1 flex items-center justify-center gap-1.5 px-4 py-2.5 text-sm font-medium transition border-l border-border " + (mode === "ia" ? "bg-card text-foreground" : "text-muted-foreground hover:text-foreground")}>
            <Wand2 className="w-4 h-4" /> Avec AIME (IA)
          </button>
        )}
      </div>

      {mode === "manuel" ? (
        <div className="p-4 space-y-3">
          <div>
            <Label className="text-xs">Nom du projet</Label>
            <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Ex. Atelier musical intergénérationnel" className="mt-1" />
          </div>
          <div>
            <Label className="text-xs">Description</Label>
            <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={2} placeholder="En quelques phrases…" className="mt-1" />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Public visé</Label>
              <Input value={form.target_audience} onChange={(e) => setForm({ ...form, target_audience: e.target.value })} placeholder="Ex. Enfants et seniors" className="mt-1" />
            </div>
            <div>
              <Label className="text-xs">Lieu</Label>
              <Input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} placeholder="Ex. Centre social Sud" className="mt-1" />
            </div>
          </div>
          <div>
            <Label className="text-xs">Vision (optionnel)</Label>
            <Textarea value={form.vision} onChange={(e) => setForm({ ...form, vision: e.target.value })} rows={2} placeholder="L'intention profonde du projet…" className="mt-1" />
          </div>
          <div className="flex items-center justify-between pt-1">
            <p className="text-xs text-muted-foreground hidden sm:block">Vous compléterez budget et tâches dans le projet.</p>
            <Button onClick={handleCreateManual} disabled={loading || !form.name.trim()} className="ml-auto gap-2">
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <ArrowRight className="w-4 h-4" />}
              Créer le projet
            </Button>
          </div>
          {error && <p className="text-sm text-destructive">{error}</p>}
        </div>
      ) : (
        <div className="p-2">
          <textarea value={value} onChange={(e) => setValue(e.target.value)} placeholder={placeholder} rows={3}
            className="w-full resize-none bg-transparent px-4 pt-3 pb-2 text-[15px] leading-relaxed text-foreground placeholder:text-muted-foreground/70 focus:outline-none" />
          <div className="flex items-center justify-between px-3 pb-3 pt-1">
            <p className="text-xs text-muted-foreground hidden sm:block">Décrivez librement — AIME se charge de la structure.</p>
            <Button onClick={handleCreateIA} disabled={!value.trim()} className="ml-auto rounded-xl gap-2">
              <Wand2 className="w-4 h-4" /> Lancer le projet <ArrowRight className="w-4 h-4" />
            </Button>
          </div>
          {error && <p className="px-4 pb-3 text-sm text-destructive">{error}</p>}
        </div>
      )}
    </div>
  );
}