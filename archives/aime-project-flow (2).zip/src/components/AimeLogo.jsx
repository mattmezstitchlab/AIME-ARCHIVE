// Clean typographic wordmark — replaces the low-legibility circular image logo.
export default function AimeLogo({ className = "", dark = false, size = "md" }) {
  const sizes = {
    sm: "text-base",
    md: "text-xl",
    lg: "text-2xl",
  };
  return (
    <span
      className={`font-heading font-extrabold tracking-tight leading-none select-none ${sizes[size]} ${className}`}
      style={{ color: dark ? "#fff" : "var(--brand-text)" }}
    >
      AI<span style={{ color: "var(--brand-accent)" }}>·</span>ME
    </span>
  );
}