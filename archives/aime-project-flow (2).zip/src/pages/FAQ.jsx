import { useState } from 'react';
import LandingNav from '@/components/landing/LandingNav';
import LandingFooter from '@/components/landing/LandingFooter';
import PageHero from '@/components/landing/PageHero';
import { motion } from 'framer-motion';
import { ChevronDown } from 'lucide-react';

const FAQ_ITEMS = [
  { q: 'Qu\'est-ce qu\'AIME ?', a: 'AIME est un système qui comprend vos projets humains. Vous importez ce que vous avez (fichiers, liens, documents), AIME organise, comprend les intentions et vous aide à transformer une idée en projet vivant.' },
  { q: 'AIME prend-il des décisions à ma place ?', a: 'Non. C\'est le principe AI + ME : l\'IA comprend et organise, vous choisissez et décidez. AIME propose, vous disposez.' },
  { q: 'Mes données sont-elles privées ?', a: 'Oui. Vos données appartiennent à votre projet. Les informations privées ne sont jamais exposées sur la page publique sans votre décision explicite.' },
  { q: 'Puis-je inviter d\'autres personnes ?', a: 'Oui. Pour un mariage, par exemple, vous pouvez inviter des prestataires qui accèdent à un espace dédié avec uniquement les informations qui les concernent.' },
  { q: 'Qu\'est-ce que la Partition Vivante™ ?', a: 'C\'est le cockpit de votre projet. Identité, mémoire, temps, relations, création et futurs possibles sont réunis dans une même vision lisible.' },
  { q: 'AIME fonctionne-t-il pour autre chose que des mariages ?', a: 'Oui. AIME s\'adapte à plusieurs univers : mariage, artiste, association, entreprise. Le moteur reste le même, le contexte change.' },
  { q: 'Ai-je besoin de connaissances techniques ?', a: 'Non. AIME est conçu pour des humains. Déposez ce que vous avez, décrivez ce que vous voulez, AIME organise le reste.' },
];

export default function FAQ() {
  const [open, setOpen] = useState(null);
  return (
    <div className="min-h-screen bg-background">
      <LandingNav />
      <PageHero
        image="https://media.base44.com/images/public/6a6e080d1aca70178ff1340c/429bd94f5_generated_image.png"
        badge="FAQ"
        title="Questions fréquentes"
        subtitle="Tout ce qu'on nous demande avant de commencer."
        focalPointY={0.5}
      />
      <section className="pt-20 pb-24 px-6">
        <div className="max-w-3xl mx-auto">
          <div className="space-y-2">
            {FAQ_ITEMS.map((item, i) => (
              <div key={i} className="border border-border rounded-lg overflow-hidden bg-card">
                <button
                  onClick={() => setOpen(open === i ? null : i)}
                  className="w-full flex items-center justify-between px-5 py-4 text-left"
                >
                  <span className="text-sm font-medium">{item.q}</span>
                  <ChevronDown className={`w-4 h-4 text-muted-foreground shrink-0 transition-transform ${open === i ? 'rotate-180' : ''}`} />
                </button>
                {open === i && (
                  <div className="px-5 pb-4 text-sm text-muted-foreground leading-relaxed">
                    {item.a}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>
      <LandingFooter />
    </div>
  );
}