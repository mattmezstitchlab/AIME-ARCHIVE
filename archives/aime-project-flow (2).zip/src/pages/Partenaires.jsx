import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import EmptyState from "@/components/EmptyState";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogContent, AlertDialogHeader, AlertDialogTitle,
  AlertDialogAction, AlertDialogCancel, AlertDialogFooter, AlertDialogDescription
} from "@/components/ui/alert-dialog";
import { useToast } from "@/components/ui/use-toast";
import { Handshake, Plus, Loader2, Mail, Phone, Trash2, Pencil } from "lucide-react";
import { useAssociation } from "@/components/AssociationProvider";

const TYPE_LABELS = {
  financeur: "Financeur", institutionnel: "Institutionnel", prive: "Privé", asso: "Association", commune: "Commune", autre: "Autre"
};

export default function Partenaires() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [editTarget, setEditTarget] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [form, setForm] = useState({ name: "", type: "prive", contact_name: "", email: "", phone: "", notes: "" });
  const [editForm, setEditForm] = useState({ name: "", type: "prive", contact_name: "", email: "", phone: "", notes: "" });
  const { toast } = useToast();
  const { activeAssociationId } = useAssociation();

  async function load() {
    setLoading(true);
    try { setItems(await base44.entities.Partenaire.list()); } catch (e) {}
    setLoading(false);
  }
  useEffect(() => { load(); }, []);

  async function add() {
    if (!form.name.trim()) return;
    try {
      await base44.entities.Partenaire.create({ ...form, association_id: activeAssociationId });
      setForm({ name: "", type: "prive", contact_name: "", email: "", phone: "", notes: "" });
      setOpen(false);
      toast({ title: "Partenaire ajouté" });
      load();
    } catch (e) { toast({ title: "Erreur", variant: "destructive" }); }
  }

  function startEdit(p) {
    setEditTarget(p);
    setEditForm({
      name: p.name || "", type: p.type || "prive", contact_name: p.contact_name || "",
      email: p.email || "", phone: p.phone || "", notes: p.notes || ""
    });
  }

  async function saveEdit() {
    if (!editTarget) return;
    try {
      await base44.entities.Partenaire.update(editTarget.id, editForm);
      setEditTarget(null);
      toast({ title: "Partenaire mis à jour" });
      load();
    } catch (e) { toast({ title: "Erreur", variant: "destructive" }); }
  }

  async function remove() {
    if (!deleteTarget) return;
    try {
      await base44.entities.Partenaire.delete(deleteTarget.id);
      setDeleteTarget(null);
      toast({ title: "Partenaire supprimé" });
      load();
    } catch (e) { toast({ title: "Erreur", variant: "destructive" }); }
  }

  const colors = {
    financeur: "bg-sage text-sage-foreground",
    institutionnel: "bg-navy text-white",
    prive: "bg-primary text-primary-foreground",
    asso: "bg-blue-100 text-blue-700",
    commune: "bg-amber-100 text-amber-700",
    autre: "bg-muted text-foreground"
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-10 pt-8 lg:pt-12">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-semibold">Partenaires</h1>
          <p className="text-sm text-muted-foreground mt-1">Financeurs, institutions et soutiens de vos projets.</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button className="gap-1.5"><Plus className="w-4 h-4" /> Ajouter</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Nouveau partenaire</DialogTitle></DialogHeader>
            <div className="space-y-3 py-2">
              <div>
                <Label>Nom</Label>
                <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Ex. Mairie de Lyon" />
              </div>
              <div>
                <Label>Type</Label>
                <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {Object.entries(TYPE_LABELS).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div><Label>Contact</Label><Input value={form.contact_name} onChange={(e) => setForm({ ...form, contact_name: e.target.value })} placeholder="Nom du contact" /></div>
              <div><Label>Email</Label><Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
              <div><Label>Téléphone</Label><Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
              <div><Label>Notes</Label><Input value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} placeholder="Informations complémentaires" /></div>
            </div>
            <DialogFooter>
              <Button variant="ghost" onClick={() => setOpen(false)}>Annuler</Button>
              <Button onClick={add}>Ajouter</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {loading ? (
        <div className="flex justify-center pt-10"><Loader2 className="w-5 h-5 animate-spin text-muted-foreground" /></div>
      ) : items.length === 0 ? (
        <EmptyState icon={Handshake} title="Aucun partenaire" description="Ajoutez vos financeurs et soutiens pour les relier à vos projets." />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {items.map((p) => (
            <Card key={p.id} className="soft-shadow">
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="text-sm font-medium">{p.name}</p>
                    {p.contact_name && <p className="text-xs text-muted-foreground mt-0.5">{p.contact_name}</p>}
                  </div>
                  <Badge className={(colors[p.type] || "bg-muted") + " border-0 font-normal"}>{TYPE_LABELS[p.type] || p.type}</Badge>
                </div>
                <div className="flex flex-col gap-1 mt-3 text-xs text-muted-foreground">
                  {p.email && <span className="flex items-center gap-1.5"><Mail className="w-3.5 h-3.5" /> {p.email}</span>}
                  {p.phone && <span className="flex items-center gap-1.5"><Phone className="w-3.5 h-3.5" /> {p.phone}</span>}
                  {p.notes && <p className="mt-1 text-foreground/70">{p.notes}</p>}
                </div>
                <div className="flex gap-1 mt-3 pt-2 border-t border-border">
                  <Button size="sm" variant="ghost" onClick={() => startEdit(p)} className="gap-1.5 h-7"><Pencil className="w-3.5 h-3.5" /> Modifier</Button>
                  <Button size="sm" variant="ghost" onClick={() => setDeleteTarget(p)} className="gap-1.5 h-7 text-destructive hover:text-destructive"><Trash2 className="w-3.5 h-3.5" /> Supprimer</Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Edit dialog */}
      <Dialog open={!!editTarget} onOpenChange={(o) => !o && setEditTarget(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Modifier le partenaire</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <div><Label>Nom</Label><Input value={editForm.name} onChange={(e) => setEditForm({ ...editForm, name: e.target.value })} /></div>
            <div>
              <Label>Type</Label>
              <Select value={editForm.type} onValueChange={(v) => setEditForm({ ...editForm, type: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(TYPE_LABELS).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div><Label>Contact</Label><Input value={editForm.contact_name} onChange={(e) => setEditForm({ ...editForm, contact_name: e.target.value })} /></div>
            <div><Label>Email</Label><Input type="email" value={editForm.email} onChange={(e) => setEditForm({ ...editForm, email: e.target.value })} /></div>
            <div><Label>Téléphone</Label><Input value={editForm.phone} onChange={(e) => setEditForm({ ...editForm, phone: e.target.value })} /></div>
            <div><Label>Notes</Label><Input value={editForm.notes} onChange={(e) => setEditForm({ ...editForm, notes: e.target.value })} /></div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setEditTarget(null)}>Annuler</Button>
            <Button onClick={saveEdit}>Enregistrer</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete confirmation */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Supprimer ce partenaire ?</AlertDialogTitle>
            <AlertDialogDescription>
              {deleteTarget?.name} sera supprimé définitivement.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annuler</AlertDialogCancel>
            <AlertDialogAction onClick={remove} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Supprimer
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}