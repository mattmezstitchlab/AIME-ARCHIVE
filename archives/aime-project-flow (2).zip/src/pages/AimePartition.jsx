import { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { ArrowLeft, Loader2, Bot, Dna, FileText, Clock, Palette, Users, Compass, X, Sparkles, ArrowRight, Check, Zap } from 'lucide-react';
import PartitionNode from '@/components/aime/partition/PartitionNode';
import MaturityScore from '@/components/aime/partition/MaturityScore';
import AiMeLoop from '@/components/aime/partition/AiMeLoop';
import ArchetypeBadge from '@/components/aime/ArchetypeBadge';
import ReadinessIndicator from '@/components/aime/ReadinessIndicator';
import KnowledgeGraph from '@/components/aime/KnowledgeGraph';
import { calculateMaturity } from '@/lib/aime/maturityCalculator';
import { calculateReadiness } from '@/lib/aime/readinessScore';
import { buildKnowledgeGraph } from '@/lib/aime/knowledgeGraph';
import { normalizeDna } from '@/lib/aime/dnaNormalize';
import { loadProjectVersions } from '@/lib/aime/memoryVersioning';
import { createStudioForProject } from '@/lib/aime/studioGenerator';

const CATEGORY_LABELS = {
  wedding: 'Mariage', music: 'Musique', association: 'Association',
  business: 'Business', education: 'Éducation', community: 'Communauté',
  personal: 'Personnel', other: 'Projet',
};

export default function AimePartition() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [project, setProject] = useState(null);
  const [dna, setDna] = useState(null);
  const [memoryItems, setMemoryItems] = useState([]);
  const [futurePaths, setFuturePaths] = useState([]);
  const [versions, setVersions] = useState([]);
  const [thinkSessions, setThinkSessions] = useState([]);
  const [detail, setDetail] = useState(null);
  const [creatingStudio, setCreatingStudio] = useState(false);

  const handleCreateStudio = async () => {
    if (!nd || !project) return;
    setCreatingStudio(true);
    try {
      const page = await createStudioForProject(nd, project);
      setProject({ ...project, studio_page_id: page.id });
      navigate(`/studio/page/${page.id}`);
    } catch (e) {
      console.error('Studio creation failed:', e);
    }
    setCreatingStudio(false);
  };

  const loadAll = useCallback(async () => {
    if (!id) return;
    setLoading(true);
    try {
      const me = await base44.auth.me();
      const [projectList, dnaList, items, fps, vers, sessions] = await Promise.all([
        base44.entities.AimeProject.filter({ id, owner_id: me.id }),
        base44.entities.ProjectDNA.filter({ project_id: id, owner_id: me.id }),
        base44.entities.MemoryItem.filter({ project_id: id, owner_id: me.id }, '-created_date', 200),
        base44.entities.FuturePath.filter({ project_id: id, owner_id: me.id }),
        loadProjectVersions(id),
        base44.entities.ThinkSession.filter({ project_id: id, owner_id: me.id }, '-created_date', 5),
      ]);
      setProject(projectList[0]);
      setDna(dnaList[0] || null);
      setMemoryItems(items);
      setFuturePaths(fps);
      setVersions(vers);
      setThinkSessions(sessions);
    } catch (e) {
      console.error(e);
    }
    setLoading(false);
  }, [id]);

  useEffect(() => { loadAll(); }, [loadAll]);

  const nd = dna ? normalizeDna(dna) : null;
  const maturity = nd ? calculateMaturity({ dna: nd, memoryItems, futurePaths, project }) : null;
  const archetype = nd?.archetype || 'inconnu';
  const archetypeConfidence = nd?.archetype_confidence || 0;
  const archetypeSignals = nd?.archetype_signals || [];
  const readiness = nd ? calculateReadiness({ dna: nd, memoryItems, futurePaths, archetype }) : null;
  const knowledgeGraph = nd ? buildKnowledgeGraph({ dna: nd, memoryItems, futurePaths, thinkSessions, versions }) : null;

  // Définition des branches de la partition
  const branches = nd ? [
    {
      title: 'IDENTITÉ',
      items: [
        { label: 'Intention', action: { type: 'think', question: 'Voici ce que je comprends de l\'identité actuelle. Peux-tu la reformuler ?' } },
        { label: 'Valeurs', action: { type: 'think', question: 'Quelles valeurs ce projet porte-il ?' } },
        { label: 'Émotion', action: { type: 'think', question: 'Quelle émotion doit transmettre ce projet ?' } },
      ],
    },
    {
      title: 'MÉMOIRE',
      items: [
        { label: 'Sources', action: { type: 'detail', kind: 'sources' } },
        { label: 'Médias', action: { type: 'detail', kind: 'medias' } },
        { label: 'Documents', action: { type: 'detail', kind: 'documents' } },
      ],
    },
    {
      title: 'TEMPS',
      items: [
        { label: 'Timeline', action: { type: 'detail', kind: 'timeline' } },
        { label: 'Versions', action: { type: 'detail', kind: 'versions' } },
        { label: 'Évolution', action: { type: 'detail', kind: 'evolution' } },
      ],
    },
    {
      title: 'CRÉATION',
      items: [
        { label: 'Studio', action: { type: 'studio' } },
        { label: 'Design', action: { type: 'think', question: 'Quelle direction visuelle est la plus cohérente pour ce projet ?' } },
        { label: 'DNA', action: { type: 'detail', kind: 'design_dna' } },
      ],
    },
    {
      title: 'RELATIONS',
      items: [
        { label: 'Personnes', action: { type: 'detail', kind: 'persons' } },
        { label: 'Liens', action: { type: 'detail', kind: 'relations' } },
      ],
    },
    {
      title: 'FUTURS',
      items: [
        { label: 'Paths', action: { type: 'detail', kind: 'future_paths' } },
        { label: 'Possibilités', action: { type: 'think', question: 'Quelle direction semble la plus cohérente ?' } },
      ],
    },
  ] : [];

  const handleOpenDetail = (d) => setDetail(d);

  // Rendu du panneau de détail
  const renderDetail = () => {
    if (!detail) return null;
    const { kind } = detail;

    const Section = ({ title, children }) => (
      <div>
        <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">{title}</h4>
        {children}
      </div>
    );

    let content = null;
    if (kind === 'sources' || kind === 'medias' || kind === 'documents') {
      const filtered = kind === 'medias'
        ? memoryItems.filter(m => ['image', 'video', 'audio'].includes(m.type))
        : kind === 'documents'
        ? memoryItems.filter(m => ['document', 'code'].includes(m.type))
        : memoryItems;
      content = (
        <Section title={`${filtered.length} élément(s)`}>
          <div className="space-y-1.5 max-h-96 overflow-y-auto">
            {filtered.length === 0 ? (
              <p className="text-xs text-muted-foreground italic">Aucun élément.</p>
            ) : filtered.map(m => (
              <div key={m.id} className="flex items-center gap-2 px-2 py-1.5 rounded-md border border-border text-sm">
                <FileText className="w-3.5 h-3.5 text-muted-foreground shrink-0" strokeWidth={1.5} />
                <span className="flex-1 truncate">{m.name}</span>
                <span className="text-xs text-muted-foreground capitalize">{m.type}</span>
              </div>
            ))}
          </div>
        </Section>
      );
    } else if (kind === 'timeline') {
      const tl = nd?.timeline || {};
      content = (
        <Section title="Timeline">
          <div className="space-y-3">
            {tl.past?.length > 0 && (
              <div><p className="text-xs text-muted-foreground mb-1">Passé</p><div className="flex flex-wrap gap-1.5">{tl.past.map((t, i) => <span key={i} className="brand-badge">{t}</span>)}</div></div>
            )}
            {tl.present?.length > 0 && (
              <div><p className="text-xs text-muted-foreground mb-1">Présent</p><div className="flex flex-wrap gap-1.5">{tl.present.slice(0, 12).map((t, i) => <span key={i} className="brand-badge">{t}</span>)}</div></div>
            )}
            {tl.futureGraph?.length > 0 && (
              <div><p className="text-xs text-muted-foreground mb-1">Futurs</p><div className="flex flex-wrap gap-1.5">{tl.futureGraph.map((t, i) => <span key={i} className="brand-badge">{t}</span>)}</div></div>
            )}
          </div>
        </Section>
      );
    } else if (kind === 'versions' || kind === 'evolution') {
      content = (
        <Section title={`${versions.length} version(s)`}>
          <div className="space-y-2 max-h-96 overflow-y-auto">
            {versions.length === 0 ? (
              <p className="text-xs text-muted-foreground italic">Aucune version enregistrée.</p>
            ) : versions.map(v => (
              <div key={v.id} className="border border-border rounded-md p-2.5">
                <div className="flex items-center gap-2 mb-1">
                  <span className="brand-badge-dark">V{v.version}</span>
                  <span className="text-xs text-muted-foreground">{v.entity_type}</span>
                </div>
                <p className="text-xs text-foreground">{v.reason}</p>
              </div>
            ))}
          </div>
        </Section>
      );
    } else if (kind === 'design_dna') {
      const dd = nd?.design_dna || {};
      content = (
        <Section title="Design DNA">
          <div className="space-y-3">
            {dd.colors?.length > 0 && (
              <div><p className="text-xs text-muted-foreground mb-1.5">Couleurs</p><div className="flex flex-wrap gap-1.5">{dd.colors.map((c, i) => <div key={i} className="flex items-center gap-1.5"><div className="w-5 h-5 rounded border border-border" style={{ background: c }} /><span className="text-xs font-mono text-muted-foreground">{c}</span></div>)}</div></div>
            )}
            {dd.fonts?.length > 0 && (
              <div><p className="text-xs text-muted-foreground mb-1.5">Polices</p><div className="flex flex-wrap gap-1.5">{dd.fonts.map((f, i) => <span key={i} className="brand-badge">{f}</span>)}</div></div>
            )}
            {dd.emotional_style && <p className="text-sm"><span className="text-muted-foreground">Émotion : </span><span className="font-medium">{dd.emotional_style}</span></p>}
            {dd.composition_rules?.length > 0 && (
              <div><p className="text-xs text-muted-foreground mb-1.5">Composition</p><div className="flex flex-wrap gap-1.5">{dd.composition_rules.map((r, i) => <span key={i} className="brand-badge">{r}</span>)}</div></div>
            )}
          </div>
        </Section>
      );
    } else if (kind === 'persons') {
      const persons = nd?.persons || [];
      content = (
        <Section title={`${persons.length} personne(s)`}>
          <div className="space-y-1.5">
            {persons.length === 0 ? (
              <p className="text-xs text-muted-foreground italic">Aucune personne identifiée.</p>
            ) : persons.map((p, i) => (
              <div key={i} className="flex items-center gap-2 px-2 py-1.5 rounded-md border border-border text-sm">
                <Users className="w-3.5 h-3.5 text-muted-foreground" strokeWidth={1.5} />
                <span className="flex-1">{p.name}</span>
                <span className="text-xs text-muted-foreground">{p.role}</span>
              </div>
            ))}
          </div>
        </Section>
      );
    } else if (kind === 'relations') {
      content = (
        <Section title="Relations">
          <p className="text-xs text-muted-foreground italic">Les relations entre éléments mémoire apparaîtront ici.</p>
        </Section>
      );
    } else if (kind === 'future_paths') {
      content = (
        <Section title={`${futurePaths.length} futur(s) possible(s)`}>
          <div className="space-y-2 max-h-96 overflow-y-auto">
            {futurePaths.length === 0 ? (
              <p className="text-xs text-muted-foreground italic">Aucun futur exploré.</p>
            ) : futurePaths.map(fp => (
              <div key={fp.id} className="border border-border rounded-md p-3">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-medium">{fp.scenario}</span>
                  <span className="brand-badge capitalize">{fp.status}</span>
                </div>
                {fp.advantages?.length > 0 && <p className="text-xs text-muted-foreground">+ {fp.advantages.join(', ')}</p>}
                {fp.risks?.length > 0 && <p className="text-xs text-muted-foreground">− {fp.risks.join(', ')}</p>}
              </div>
            ))}
          </div>
        </Section>
      );
    }

    return (
      <div className="fixed inset-0 z-50 flex justify-end">
        <div className="absolute inset-0 bg-black/30" onClick={() => setDetail(null)} />
        <div className="relative w-full max-w-md bg-background border-l border-border h-full overflow-y-auto p-6 animate-float-up">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-heading text-lg font-medium">{detail.branch} · {detail.item}</h3>
            <button onClick={() => setDetail(null)} className="text-muted-foreground hover:text-foreground">
              <X className="w-4 h-4" />
            </button>
          </div>
          {content}
        </div>
      </div>
    );
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!project) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-sm font-medium text-foreground mb-1">Projet introuvable</p>
          <Link to="/aime" className="brand-outline-btn text-xs">Retour aux projets</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-6xl mx-auto px-6 py-8">
        {/* Header */}
        <div className="mb-6">
          <button onClick={() => navigate('/aime')} className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition mb-3">
            <ArrowLeft className="w-3.5 h-3.5" strokeWidth={1.5} />
            Retour aux projets
          </button>
          <div className="flex items-center gap-2 mb-1">
            <Dna className="w-5 h-5 text-foreground" strokeWidth={1.5} />
            <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Partition Vivante™ — V1.4</span>
          </div>
          <h1 className="font-heading text-3xl font-medium tracking-tight mb-1">{project.name}</h1>
          <div className="flex items-center gap-3 flex-wrap mb-1">
            <ArchetypeBadge archetype={archetype} confidence={archetypeConfidence} signals={archetypeSignals} />
            <span className="text-sm text-muted-foreground">
              {CATEGORY_LABELS[project.category] || project.category} · {memoryItems.length} éléments en mémoire
            </span>
          </div>
        </div>

        {!nd ? (
          <div className="border border-dashed border-border rounded-lg p-12 text-center">
            <p className="text-sm font-medium text-foreground mb-1">Aucun ADN trouvé pour ce projet</p>
            <p className="text-xs text-muted-foreground mb-4">Importez d'abord ce projet dans AIME.</p>
            <Link to="/aime" className="brand-outline-btn text-xs">Importer</Link>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Maturité + Readiness V1.4 */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <MaturityScore maturity={maturity} />
              <ReadinessIndicator readiness={readiness} />
            </div>

            {/* Boucle AI+ME */}
            <AiMeLoop validationState={nd.validation_state} versionCount={versions.length} />

            {/* Arbre de la Partition Vivante */}
            <div className="border border-border rounded-lg p-6 bg-background">
              {/* PROJET — nœud central */}
              <div className="flex flex-col items-center mb-6">
                <div className="w-16 h-16 rounded-full bg-foreground text-background flex items-center justify-center mb-2">
                  <Sparkles className="w-6 h-6" strokeWidth={1.5} />
                </div>
                <span className="text-xs font-semibold uppercase tracking-wider text-foreground">PROJET</span>
                <span className="text-xs text-muted-foreground">{nd.identity?.purpose}</span>
              </div>

              {/* Ligne de connexion */}
              <div className="h-6 w-px bg-border mx-auto mb-2" />

              {/* 6 branches en grille 3×2 */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {branches.map((branch) => (
                  <PartitionNode
                    key={branch.title}
                    title={branch.title}
                    items={branch.items}
                    project={project}
                    dna={nd}
                    onOpenDetail={handleOpenDetail}
                  />
                ))}
              </div>
            </div>

            {/* Knowledge Graph V1.4 */}
            <KnowledgeGraph graph={knowledgeGraph} />

            {/* Mémoire conversationnelle — dernières réflexions */}
            {thinkSessions.length > 0 && (
              <div className="border border-border rounded-lg p-5 bg-background">
                <div className="flex items-center gap-2 mb-3">
                  <Bot className="w-4 h-4 text-muted-foreground" strokeWidth={1.5} />
                  <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                    AIME se souvient — dernières réflexions
                  </h3>
                </div>
                <div className="space-y-2">
                  {thinkSessions.slice(0, 3).map((s) => (
                    <button
                      key={s.id}
                      onClick={() => navigate(`/aime/think?project=${project.id}`)}
                      className="w-full text-left flex items-start gap-3 p-3 rounded-md border border-border hover:bg-muted/30 transition"
                    >
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-foreground truncate">{s.question}</p>
                        <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5">
                          {s.response?.slice(0, 150) || '…'}
                        </p>
                      </div>
                      <ArrowRight className="w-4 h-4 text-muted-foreground shrink-0 mt-0.5" strokeWidth={1.5} />
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Actions rapides */}
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => navigate(`/aime/project/${project.id}/control`)}
                className="brand-secondary-btn text-xs"
              >
                <Zap className="w-3.5 h-3.5" strokeWidth={1.5} />
                Project Command Center
              </button>
              <button
                onClick={() => navigate(`/aime/think?project=${project.id}`)}
                className="brand-outline-btn text-xs"
              >
                <Bot className="w-3.5 h-3.5" strokeWidth={1.5} />
                Dialoguer avec AIME THINK
              </button>
              {project.studio_page_id ? (
                <button
                  onClick={() => navigate(`/studio/page/${project.studio_page_id}`)}
                  className="brand-outline-btn text-xs"
                >
                  <Palette className="w-3.5 h-3.5" strokeWidth={1.5} />
                  Ouvrir le Studio
                </button>
              ) : (
                <button
                  onClick={handleCreateStudio}
                  disabled={creatingStudio}
                  className="brand-secondary-btn text-xs"
                >
                  {creatingStudio ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Palette className="w-3.5 h-3.5" strokeWidth={1.5} />}
                  Créer le Studio
                </button>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Panneau de détail */}
      {renderDetail()}
    </div>
  );
}