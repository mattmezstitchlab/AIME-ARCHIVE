import { Link, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { structureProject } from "@/lib/aimeAgent";
import ProjectComposer from "@/components/ProjectComposer";
import AboutSection from "@/components/AboutSection";
import AssociationDashboard from "@/components/dashboard/AssociationDashboard";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Plus, FileText, ScanLine, CalendarPlus, FolderKanban, ShieldAlert, MessageCircle, ArrowRight, Bot, Heart
} from "lucide-react";
import { useAI } from "@/components/AIProvider";
import CreateProjectPageDialog from "@/components/project-context/CreateProjectPageDialog";
import WeddingHomeCard from "@/components/dashboard/WeddingHomeCard";
import WeddingOnboarding from "@/components/aime/WeddingOnboarding";

export default function Home() {
  const navigate = useNavigate();
  const [stats, setStats] = useState({ projects: 0, alerts: 0 });
  const [showProjectDialog, setShowProjectDialog] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [weddingIntro, setWeddingIntro] = useState(null);
  const { aiEnabled } = useAI();

  useEffect(() => {
    (async () => {
      try {
        const projects = await base44.entities.Projet.list();
        const justifs = await base44.entities.Justificatif.list();
        const alerts = justifs.filter((j) => j.status === "a_confirmer" || j.status === "en_analyse").length;
        setStats({ projects: projects.length, alerts });
        const me = await base44.auth.me();
        setCurrentUser(me);
      } catch (e) {}
    })();
    const pendingIntro = sessionStorage.getItem("aime_wedding_intro");
    if (pendingIntro) {
      setWeddingIntro(pendingIntro);
      sessionStorage.removeItem("aime_wedding_intro");
    }
  }, []);

  const actions = [
    { label: "Raconter un projet", icon: Plus, desc: "AIME structure votre idée", target: "#composer", accent: "primary" },
    ...(aiEnabled ? [{ label: "Parler à AIME", icon: Bot, desc: "Conversez avec l'agent", target: "/agent", accent: "navy" }] : []),
    { label: "Ajouter un document", icon: ScanLine, desc: "Facture, reçu, justificatif", target: "/scan", accent: "primary" },
    { label: "Voir mes projets", icon: FolderKanban, desc: "Tous vos dossiers", target: "/projects", accent: "navy" },
    { label: "Créer un événement", icon: CalendarPlus, desc: "Ajouter une date", target: "/evenements", accent: "sage" },
    { label: "Générer un document", icon: FileText, desc: "Fiche, bilan, convention", target: "/projects", accent: "navy" },
    { label: "Voir ce qui manque", icon: ShieldAlert, desc: "Tableau de vigilance", target: "/vigilance", accent: "primary" },
    { label: "Voir les membres", icon: MessageCircle, desc: "Équipe & bénévoles", target: "/membres", accent: "navy" },
    { label: "Page mariage", icon: Heart, desc: "Créer un site de mariage", target: "__project_dialog__", accent: "primary" }
  ];

  const accentMap = {
    primary: "bg-primary/10 text-primary",
    navy: "bg-navy/10 text-navy",
    sage: "bg-sage/15 text-sage"
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-10 pt-8 lg:pt-14">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4 mb-8">
        <div>
          <span className="brand-badge">Tableau de bord</span>
          <h1 className="font-display text-3xl sm:text-4xl font-semibold mt-4">Bienvenue dans votre espace AIME.</h1>
        </div>
        <div className="flex gap-2">
          <div className="rounded-xl bg-card border border-border px-4 py-2 text-center soft-shadow">
            <p className="font-display text-xl font-semibold text-navy">{stats.projects}</p>
            <p className="text-[10px] uppercase tracking-wide text-muted-foreground">projets</p>
          </div>
          <div className="rounded-xl bg-card border border-border px-4 py-2 text-center soft-shadow">
            <p className={"font-display text-xl font-semibold " + (stats.alerts > 0 ? "text-primary" : "text-navy")}>{stats.alerts}</p>
            <p className="text-[10px] uppercase tracking-wide text-muted-foreground">alertes</p>
          </div>
        </div>
      </div>

      <WeddingHomeCard />

      {/* Composer */}
      <div id="composer" className="mb-8 scroll-mt-4">
        <div className="flex items-center gap-2 mb-3 text-sm text-muted-foreground">
          <Plus className="w-4 h-4 text-primary" />
          <span>Racontez votre projet</span>
        </div>
        <ProjectComposer />
      </div>

      {/* Quick actions */}
      <div>
        <p className="text-xs uppercase tracking-[0.18em] text-muted-foreground mb-3">Actions rapides</p>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {actions.map((a) => {
            const isAnchor = String(a.target).startsWith("#");
            const Icon = a.icon;
            const inner = (
              <Card className="soft-shadow hover:soft-shadow hover:-translate-y-0.5 transition cursor-pointer h-full">
                <CardContent className="p-4 flex flex-col gap-3 h-full">
                  <div className={"w-9 h-9 rounded-xl flex items-center justify-center " + accentMap[a.accent]}>
                    <Icon className="w-5 h-5" strokeWidth={1.6} />
                  </div>
                  <div>
                    <p className="text-sm font-medium leading-tight">{a.label}</p>
                    <p className="text-xs text-muted-foreground mt-1">{a.desc}</p>
                  </div>
                </CardContent>
              </Card>
            );
            if (a.target === "__project_dialog__") {
              return (
                <button key={a.label} onClick={() => setShowProjectDialog(true)} className="text-left">
                  {inner}
                </button>
              );
            }
            return isAnchor ? (
              <a key={a.label} href={a.target}>{inner}</a>
            ) : (
              <Link key={a.label} to={a.target}>{inner}</Link>
            );
          })}
        </div>
      </div>

      <CreateProjectPageDialog
        open={showProjectDialog}
        onClose={() => setShowProjectDialog(false)}
        userId={currentUser?.id}
        username={currentUser?.email?.split("@")[0]}
      />

      <WeddingOnboarding
        open={!!weddingIntro}
        onClose={() => setWeddingIntro(null)}
        initialDescription={weddingIntro || ""}
      />

      {/* Tableau de bord associatif — esthétique « specimen », données réelles */}
      <div className="mt-10">
        <AssociationDashboard />
      </div>

      {/* Signature — composant About-9, design appliqué à l'ensemble du site */}
      <AboutSection />
    </div>
  );
}