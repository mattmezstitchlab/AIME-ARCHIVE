import { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { DOC_TYPES, formatDate } from "@/lib/aimeFormats";
import { DOC_STATUS, archiveDocument, duplicateDocument, gatherContext, exportDocumentPDF } from "@/lib/documentEngine";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem
} from "@/components/ui/select";
import { useToast } from "@/components/ui/use-toast";
import { useAssociation } from "@/components/AssociationProvider";
import { useAI } from "@/components/AIProvider";
import EmptyState from "@/components/EmptyState";
import {
  FileText, Plus, Search, Download, Archive, Copy, Eye, Pencil, Loader2, FileStack
} from "lucide-react";
import DocumentEditorDialog from "@/components/documents/DocumentEditorDialog";
import DocumentPreviewDialog from "@/components/documents/DocumentPreviewDialog";

const TABS = [
  { id: "tous", label: "Tous" },
  { id: "brouillon", label: "Brouillons" },
  { id: "a_completer", label: "À compléter" },
  { id: "a_verifier", label: "À vérifier" },
  { id: "valide", label: "Validés" },
  { id: "exporte", label: "Exportés" },
  { id: "archive", label: "Archivés" }
];

export default function Documents() {
  const { toast } = useToast();
  const { activeAssociationId } = useAssociation();
  const { aiEnabled } = useAI();
  const [docs, setDocs] = useState([]);
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState("tous");
  const [typeFilter, setTypeFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [previewDoc, setPreviewDoc] = useState(null);
  const [editorState, setEditorState] = useState(null);

  async function load() {
    setLoading(true);
    try {
      const [allDocs, allProjects] = await Promise.all([
        base44.entities.Document.filter({ association_id: activeAssociationId }),
        base44.entities.Projet.filter({ association_id: activeAssociationId })
      ]);
      allDocs.sort((a, b) => (b.updated_date || "").localeCompare(a.updated_date || ""));
      setDocs(allDocs);
      setProjects(allProjects);
    } catch (e) { console.error(e); }
    setLoading(false);
  }
  useEffect(() => { load(); }, [activeAssociationId]);

  const filtered = useMemo(() => {
    return docs.filter((d) => {
      if (tab !== "tous" && d.status !== tab) return false;
      if (typeFilter !== "all" && d.type !== typeFilter) return false;
      if (search && !d.title?.toLowerCase().includes(search.toLowerCase())) return false;
      return true;
    });
  }, [docs, tab, typeFilter, search]);

  const projectMap = useMemo(() => {
    const m = {};
    projects.forEach((p) => { m[p.id] = p.name; });
    return m;
  }, [projects]);

  async function handleArchive(doc) {
    await archiveDocument(doc.id);
    toast({ title: "Document archivé" });
    load();
  }

  async function handleDuplicate(doc) {
    await duplicateDocument(doc.id);
    toast({ title: "Document dupliqué" });
    load();
  }

  async function handlePDF(doc) {
    const context = await gatherContext(doc);
    const pdfDoc = await exportDocumentPDF(doc, context);
    const safe = (doc.title || "document").replace(/[^a-zA-Z0-9-_ ]/g, "").trim().replace(/\s+/g, "-").toLowerCase();
    pdfDoc.save(safe + "-v" + (doc.version || 1) + ".pdf");
    toast({ title: "PDF téléchargé" });
    load();
  }

  function openPreview(doc) { setPreviewDoc(doc); }
  function openEditor(doc) { setEditorState({ mode: doc ? "edit" : "create", doc }); }
  function openCreate() { setEditorState({ mode: "create", doc: null }); }

  function onEditorClose() { setEditorState(null); }
  function onEditorSaved() { setEditorState(null); load(); }
  function onPreviewClose() { setPreviewDoc(null); }
  function onPreviewEdit(doc) { setPreviewDoc(null); setEditorState({ mode: "edit", doc }); }

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-10 pt-8 lg:pt-10 pb-12">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center"><FileStack className="w-5 h-5 text-primary" /></div>
          <div>
            <h1 className="font-display text-2xl sm:text-3xl font-semibold">Documents</h1>
            <p className="text-sm text-muted-foreground mt-0.5">Centre documentaire — tous vos documents contrôlés et traçables.</p>
          </div>
        </div>
        <Button onClick={openCreate} className="gap-1.5"><Plus className="w-4 h-4" /> Nouveau</Button>
      </div>

      {/* Onglets statut */}
      <div className="flex gap-1 mb-4 overflow-x-auto pb-1">
        {TABS.map((t) => {
          const count = t.id === "tous" ? docs.length : docs.filter((d) => d.status === t.id).length;
          const active = tab === t.id;
          return (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={"px-3 py-1.5 rounded-lg text-sm font-medium whitespace-nowrap transition " +
                (active ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-accent hover:text-accent-foreground")}>
              {t.label} <span className={"ml-1 text-xs " + (active ? "opacity-70" : "opacity-50")}>{count}</span>
            </button>
          );
        })}
      </div>

      {/* Filtres */}
      <div className="flex flex-col sm:flex-row gap-2 mb-4">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-muted-foreground absolute left-3 top-1/2 -translate-y-1/2" />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Rechercher par titre…" className="pl-9" />
        </div>
        <Select value={typeFilter} onValueChange={setTypeFilter}>
          <SelectTrigger className="sm:w-56"><SelectValue placeholder="Tous les types" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tous les types</SelectItem>
            {Object.entries(DOC_TYPES).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      {/* Liste */}
      {loading ? (
        <div className="flex justify-center py-16"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
      ) : filtered.length === 0 ? (
        <EmptyState icon={FileText} title="Aucun document" description="Créez un document ou générez-le depuis un projet." action={<Button onClick={openCreate} variant="outline" size="sm" className="gap-1.5"><Plus className="w-4 h-4" /> Créer un document</Button>} />
      ) : (
        <div className="space-y-2">
          {filtered.map((doc) => {
            const st = DOC_STATUS[doc.status] || DOC_STATUS.brouillon;
            return (
              <div key={doc.id} className="flex items-center gap-3 rounded-lg border border-border bg-card px-4 py-3 hover:border-primary/30 transition group">
                <FileText className="w-4 h-4 text-primary shrink-0" />
                <div className="flex-1 min-w-0 cursor-pointer" onClick={() => openPreview(doc)}>
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-medium truncate">{doc.title}</p>
                    <Badge variant="outline" className="font-normal shrink-0">{DOC_TYPES[doc.type] || doc.type}</Badge>
                  </div>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    v{doc.version} {doc.project_id && projectMap[doc.project_id] ? "· " + projectMap[doc.project_id] : ""} · {formatDate(doc.updated_date || doc.created_date)}
                  </p>
                </div>
                <Badge className={st.cls + " border-0 font-normal shrink-0"}>{st.label}</Badge>
                <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition">
                  <button onClick={() => openPreview(doc)} className="p-1.5 rounded-md hover:bg-accent text-muted-foreground" title="Aperçu"><Eye className="w-4 h-4" /></button>
                  <button onClick={() => openEditor(doc)} className="p-1.5 rounded-md hover:bg-accent text-muted-foreground" title="Modifier"><Pencil className="w-4 h-4" /></button>
                  <button onClick={() => handlePDF(doc)} className="p-1.5 rounded-md hover:bg-accent text-muted-foreground" title="PDF"><Download className="w-4 h-4" /></button>
                  <button onClick={() => handleDuplicate(doc)} className="p-1.5 rounded-md hover:bg-accent text-muted-foreground" title="Dupliquer"><Copy className="w-4 h-4" /></button>
                  {doc.status !== "archive" && (
                    <button onClick={() => handleArchive(doc)} className="p-1.5 rounded-md hover:bg-destructive/10 text-muted-foreground hover:text-destructive" title="Archiver"><Archive className="w-4 h-4" /></button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {previewDoc && (
        <DocumentPreviewDialog
          doc={previewDoc}
          context={{ association_id: activeAssociationId, project_id: previewDoc.project_id, event_id: previewDoc.event_id }}
          onClose={onPreviewClose}
          onEdit={onPreviewEdit}
          onArchived={load}
        />
      )}

      {editorState && (
        <DocumentEditorDialog
          mode={editorState.mode}
          doc={editorState.doc}
          associationId={activeAssociationId}
          projects={projects}
          aiEnabled={aiEnabled}
          onClose={onEditorClose}
          onSaved={onEditorSaved}
        />
      )}
    </div>
  );
}