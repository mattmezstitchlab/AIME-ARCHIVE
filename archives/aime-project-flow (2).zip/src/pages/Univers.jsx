import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import { Image } from '@/components/ui/image';
import LandingNav from '@/components/landing/LandingNav';
import LandingFooter from '@/components/landing/LandingFooter';
import { UNIVERS } from '@/lib/universConfig';

export default function Univers() {
  return (
    <div className="min-h-screen bg-background">
      <LandingNav />
      <section className="pt-32 pb-24 px-6">
        <div className="max-w-6xl mx-auto">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="text-center mb-16">
            <span className="brand-badge mb-4">Univers</span>
            <h1 className="font-heading text-4xl md:text-6xl font-medium tracking-tight mb-6">
              Un même moteur, des mondes différents.
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed">
              AIME s'adapte à votre contexte. Quel que soit votre projet, le moteur reste le même.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-6">
            {UNIVERS.map((uni, i) => {
              const Icon = uni.icon;
              const available = uni.status === 'available';
              const CardInner = (
                <>
                  <div className="relative aspect-[16/9] overflow-hidden">
                    <Image src={uni.image} alt={uni.name} className="w-full h-full" fittingType="fill" />
                    <div className={'absolute inset-0 transition-colors ' + (available ? 'bg-black/30 group-hover:bg-black/20' : 'bg-black/50')} />
                    <div className="absolute top-4 left-4 w-10 h-10 rounded-full bg-white/15 backdrop-blur-md flex items-center justify-center">
                      <Icon className="w-4 h-4 text-white" strokeWidth={1.5} />
                    </div>
                    <div className="absolute top-4 right-4">
                      <span className={'text-[10px] uppercase tracking-wider font-semibold px-2.5 py-1 rounded-full backdrop-blur-md ' + (available ? 'bg-white/90 text-black' : 'bg-white/15 text-white border border-white/30')}>
                        {available ? 'Disponible' : 'Bientôt disponible'}
                      </span>
                    </div>
                  </div>
                  <div className="p-6 md:p-8">
                    <p className="text-xs uppercase tracking-wider text-muted-foreground mb-1">{uni.tagline}</p>
                    <h3 className="font-heading text-2xl font-medium tracking-tight mb-2">{uni.name}</h3>
                    <p className="text-sm text-muted-foreground mb-4">{uni.description}</p>
                    <div className="flex flex-wrap gap-2 mb-4">
                      {uni.features.map((f) => (
                        <span key={f} className="brand-badge">{f}</span>
                      ))}
                    </div>
                    {available && (
                      <span className="inline-flex items-center gap-1.5 text-sm font-medium group-hover:gap-2.5 transition-all">
                        Découvrir <ArrowRight className="w-3.5 h-3.5" />
                      </span>
                    )}
                  </div>
                </>
              );
              return (
                <motion.div
                  key={uni.slug}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: '-80px' }}
                  transition={{ duration: 0.5, delay: i * 0.08 }}
                >
                  {available ? (
                    <Link to={uni.to} className="group block rounded-lg overflow-hidden border border-border bg-background hover:shadow-lg transition-all">
                      {CardInner}
                    </Link>
                  ) : (
                    <div className="block rounded-lg overflow-hidden border border-border bg-background opacity-90 cursor-default">
                      {CardInner}
                    </div>
                  )}
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>
      <LandingFooter />
    </div>
  );
}