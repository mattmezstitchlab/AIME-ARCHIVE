import { useState, useEffect, useCallback } from 'react';
import { useSearchParams, useNavigate, Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Bot, ArrowLeft, Loader2, FolderKanban, Dna } from 'lucide-react';
import ThinkComprehension from '@/components/aime/think/ThinkComprehension';
import ThinkDialogue from '@/components/aime/think/ThinkDialogue';
import ThinkActions from '@/components/aime/think/ThinkActions';
import MemoryTimeline from '@/components/aime/think/MemoryTimeline';
import { loadProjectVersions, createMemoryVersion } from '@/lib/aime/memoryVersioning';

const CATEGORY_LABELS = {
  wedding: 'Mariage', music: 'Musique', association: 'Association',
  business: 'Business', education: 'Éducation', community: 'Communauté',
  personal: 'Personnel', other: 'Projet',
};

export default function AimeThink() {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const projectId = searchParams.get('project');

  const [projects, setProjects] = useState([]);
  const [loadingProjects, setLoadingProjects] = useState(true);
  const [context, setContext] = useState(null);
  const [loadingContext, setLoadingContext] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const me = await base44.auth.me();
        const list = await base44.entities.AimeProject.filter({ owner_id: me.id }, '-created_date', 50);
        setProjects(list);
      } catch (e) { console.error(e); }
      setLoadingProjects(false);
    })();
  }, []);

  const loadContext = useCallback(async (pid) => {
    setLoadingContext(true);
    try {
      const me = await base44.auth.me();
      const [projectList, dnaList, futurePaths, memoryItems, versions] = await Promise.all([
        base44.entities.AimeProject.filter({ id: pid, owner_id: me.id }),
        base44.entities.ProjectDNA.filter({ project_id: pid, owner_id: me.id }),
        base44.entities.FuturePath.filter({ project_id: pid, owner_id: me.id }),
        base44.entities.MemoryItem.filter({ project_id: pid, owner_id: me.id }, '-created_date', 100),
        loadProjectVersions(pid),
      ]);
      setContext({ project: projectList[0], dna: dnaList[0], futurePaths, memoryItems, versions });
    } catch (e) { console.error(e); }
    setLoadingContext(false);
  }, []);

  useEffect(() => {
    if (projectId) loadContext(projectId);
  }, [projectId, loadContext]);

  const handleSelectProject = (pid) => setSearchParams({ project: pid });

  const handleSuggestedAction = async (action) => {
    if (!context?.project || !context?.dna) return;
    const me = await base44.auth.me();
    try {
      if (action.type === 'memory_item' && action.data?.content) {
        await base44.entities.MemoryItem.create({
          project_id: context.project.id,
          owner_id: me.id,
          type: action.data.type || 'event',
          name: action.data.content.slice(0, 80),
          title: action.data.content.slice(0, 80),
          source: 'manual',
          status: 'active',
          content_text: action.data.content,
          category: 'manual',
        });
        loadContext(context.project.id);
      } else if (action.type === 'future_path' && action.data?.scenario) {
        await base44.entities.FuturePath.create({
          project_id: context.project.id,
          owner_id: me.id,
          scenario: action.data.scenario,
          probability: 50,
          advantages: action.data.advantages || [],
          risks: action.data.risks || [],
          status: 'proposed',
        });
        loadContext(context.project.id);
      } else if (action.type === 'studio') {
        navigate(context.project.studio_page_id ? `/project/${context.project.studio_page_id}` : '/studio/page');
      } else if (action.type === 'dna_update' && action.data?.field && action.data?.value) {
        const [section, key] = action.data.field.split('.');
        if (context.dna[section]) {
          await createMemoryVersion(context.project.id, 'ProjectDNA', context.dna.id, context.dna, 'Suggestion AIME THINK');
          const updatedSection = { ...context.dna[section], [key]: action.data.value };
          const updated = await base44.entities.ProjectDNA.update(context.dna.id, { [section]: updatedSection });
          setContext({ ...context, dna: updated });
        }
      }
    } catch (e) { console.error(e); }
  };

  const handleDnaUpdated = (updated) => {
    setContext((prev) => (prev ? { ...prev, dna: updated } : prev));
    if (projectId) loadContext(projectId);
  };

  // No project selected — show selector
  if (!projectId) {
    return (
      <div className="min-h-screen bg-background">
        <div className="max-w-3xl mx-auto px-6 py-10">
          <div className="mb-10">
            <div className="flex items-center gap-2 mb-2">
              <Bot className="w-5 h-5 text-foreground" strokeWidth={1.5} />
              <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">AIME THINK™ — V1.2</span>
            </div>
            <h1 className="font-heading text-4xl font-medium tracking-tight mb-2">Dialoguer avec votre projet</h1>
            <p className="text-sm text-muted-foreground max-w-lg">
              AIME THINK est l'espace où vous dialoguez avec votre projet : pourquoi il existe, quelle direction choisir, ce qui manque.
            </p>
          </div>

          {loadingProjects ? (
            <div className="flex justify-center py-12"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
          ) : projects.length === 0 ? (
            <div className="border border-dashed border-border rounded-lg p-12 text-center">
              <FolderKanban className="w-10 h-10 mx-auto mb-4 text-muted-foreground" strokeWidth={1.5} />
              <p className="text-sm font-medium text-foreground mb-1">Aucun projet en mémoire</p>
              <p className="text-xs text-muted-foreground mb-4">Importez un projet pour activer AIME THINK.</p>
              <Link to="/aime" className="brand-outline-btn text-xs">Importer un projet</Link>
            </div>
          ) : (
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">Sélectionnez un projet</p>
              <div className="space-y-2">
                {projects.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => handleSelectProject(p.id)}
                    className="w-full text-left border border-border rounded-lg p-4 hover:bg-muted/30 transition flex items-center justify-between"
                  >
                    <div className="flex items-center gap-3">
                      <Dna className="w-5 h-5 text-muted-foreground" strokeWidth={1.5} />
                      <div>
                        <p className="text-sm font-medium">{p.name}</p>
                        <p className="text-xs text-muted-foreground">{CATEGORY_LABELS[p.category] || p.category} · {p.item_count || 0} éléments</p>
                      </div>
                    </div>
                    <Bot className="w-4 h-4 text-muted-foreground" strokeWidth={1.5} />
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  // Project selected — show THINK interface
  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-6xl mx-auto px-6 py-8">
        {/* Header */}
        <div className="mb-6">
          <button onClick={() => setSearchParams({})} className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition mb-3">
            <ArrowLeft className="w-3.5 h-3.5" strokeWidth={1.5} />
            Retour aux projets
          </button>
          <div className="flex items-center gap-2 mb-1">
            <Bot className="w-5 h-5 text-foreground" strokeWidth={1.5} />
            <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">AIME THINK™ — V1.2</span>
          </div>
          <h1 className="font-heading text-3xl font-medium tracking-tight">
            {loadingContext ? 'Chargement…' : context?.project?.name || 'Projet'}
          </h1>
        </div>

        {loadingContext ? (
          <div className="flex justify-center py-20"><Loader2 className="w-8 h-8 animate-spin text-muted-foreground" /></div>
        ) : !context?.dna ? (
          <div className="border border-dashed border-border rounded-lg p-12 text-center">
            <p className="text-sm font-medium text-foreground mb-1">Aucun ADN trouvé pour ce projet</p>
            <p className="text-xs text-muted-foreground mb-4">Importez d'abord ce projet dans AIME.</p>
            <Link to="/aime" className="brand-outline-btn text-xs">Importer</Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left column — Comprehension + Timeline */}
            <div className="space-y-4">
              <ThinkComprehension dna={context.dna} project={context.project} />
              <MemoryTimeline versions={context.versions} />
            </div>

            {/* Right column — Dialogue + Actions */}
            <div className="lg:col-span-2 space-y-4">
              <ThinkDialogue
                project={context.project}
                dna={context.dna}
                onSuggestedAction={handleSuggestedAction}
              />
              <ThinkActions
                project={context.project}
                dna={context.dna}
                onDnaUpdated={handleDnaUpdated}
                onMemoryItemCreated={() => loadContext(projectId)}
                onFuturePathCreated={() => loadContext(projectId)}
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}