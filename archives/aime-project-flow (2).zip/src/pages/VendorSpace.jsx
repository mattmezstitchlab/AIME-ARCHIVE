import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Heart, MapPin, Mail, Phone, FileText, CheckCircle, AlertCircle, Loader2 } from 'lucide-react';

const CATEGORY_LABELS = {
  lieu: 'Lieu', traiteur: 'Traiteur', photographe: 'Photographe', videaste: 'Vidéaste',
  dj: 'DJ', musicien: 'Musicien', fleuriste: 'Fleuriste', decorateur: 'Décorateur',
  officiant: 'Officiant', wedding_planner: 'Wedding Planner', transport: 'Transport',
  patisserie: 'Pâtisserie', maquillage: 'Maquillage', coiffure: 'Coiffure',
  animation: 'Animation', technique: 'Technique', autre: 'Autre',
};

const STATUS_LABELS = {
  draft: 'Brouillon', invited: 'Invité', sent: 'Invité', pending: 'En attente', viewed: 'Vu', accepted: 'Accepté',
  declined: 'Refusé', active: 'Actif', completed: 'Terminé', cancelled: 'Annulé',
};

// Portail prestataire — accessible sans compte AIME. Toute la lecture/écriture
// passe par la fonction backend "vendorPortal" (validée par le token/id du
// participant, avec contrôle de révocation et d'expiration), jamais par un
// accès direct aux entités depuis le client.
export default function VendorSpace() {
  const { participantId } = useParams();
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [participant, setParticipant] = useState(null);
  const [projectName, setProjectName] = useState('Mariage');
  const [timeline, setTimeline] = useState([]);
  const [documents, setDocuments] = useState([]);
  const [updating, setUpdating] = useState(false);

  async function call(action, extra = {}) {
    const res = await base44.functions.invoke('vendorPortal', { participant_id: participantId, action, ...extra });
    return res.data;
  }

  useEffect(() => {
    (async () => {
      try {
        const data = await call('get');
        if (data?.error || !data?.participant) { setNotFound(true); setLoading(false); return; }
        setParticipant(data.participant);
        setProjectName(data.project?.name || 'Mariage');
        setTimeline(data.timeline || []);
        setDocuments(data.documents || []);
      } catch (e) {
        setNotFound(true);
      }
      setLoading(false);
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [participantId]);

  async function updateStatus(newStatus) {
    setUpdating(true);
    try {
      const data = await call('update_status', { status: newStatus });
      if (data?.participant) setParticipant(data.participant);
    } catch (e) { /* noop */ }
    setUpdating(false);
  }

  async function updateArrivalTime(time) {
    try {
      const data = await call('update_arrival', { arrival_time: time });
      if (data?.participant) setParticipant(data.participant);
    } catch (e) { /* noop */ }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (notFound || !participant) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center gap-4 p-6 text-center">
        <h1 className="text-2xl font-display font-semibold">Espace introuvable</h1>
        <p className="text-sm text-muted-foreground">Ce lien n'est plus valide, a expiré ou a été révoqué.</p>
        <Link to="/" className="text-sm text-primary underline">Retour à l'accueil</Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="border-b border-border bg-card">
        <div className="max-w-3xl mx-auto px-6 py-5">
          <Link to="/" className="flex items-center gap-2 text-xs font-display font-bold tracking-widest text-muted-foreground hover:text-foreground transition-colors mb-3">
            <Heart className="w-3.5 h-3.5" />
            AIME
          </Link>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Espace prestataire</span>
          </div>
          <h1 className="font-display text-2xl font-medium">{projectName}</h1>
          <p className="text-sm text-muted-foreground mt-1">
            {participant.display_name} — {CATEGORY_LABELS[participant.category] || participant.category}
          </p>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-6 py-8 space-y-6">
        <div className="rounded-xl border border-border bg-card p-5">
          <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground mb-4">Mon statut</h2>
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-lg font-medium">{STATUS_LABELS[participant.status] || participant.status}</p>
              {participant.confirmed_at && (
                <p className="text-xs text-muted-foreground">Confirmé le {new Date(participant.confirmed_at).toLocaleDateString('fr-FR')}</p>
              )}
            </div>
            <div className="flex gap-2">
              {participant.status !== 'accepted' && participant.status !== 'active' && (
                <button
                  onClick={() => updateStatus('accepted')}
                  disabled={updating}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-foreground text-background text-sm font-medium hover:opacity-90 transition-opacity disabled:opacity-50"
                >
                  <CheckCircle className="w-4 h-4" /> Accepter
                </button>
              )}
              {participant.status !== 'declined' && (
                <button
                  onClick={() => updateStatus('declined')}
                  disabled={updating}
                  className="px-4 py-2 rounded-full border border-border text-sm font-medium hover:bg-accent transition-colors disabled:opacity-50"
                >
                  Décliner
                </button>
              )}
            </div>
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground mb-1 block">Mon heure d'arrivée</label>
            <input
              type="time"
              value={participant.arrival_time || ''}
              onChange={e => updateArrivalTime(e.target.value)}
              className="px-3 py-2 rounded-lg border border-border text-sm"
            />
          </div>
        </div>

        <div className="rounded-xl border border-border bg-card p-5">
          <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground mb-4">Mon intervention</h2>
          {participant.responsibilities && (
            <div className="mb-4">
              <p className="text-xs text-muted-foreground mb-1">Mission</p>
              <p className="text-sm">{participant.responsibilities}</p>
            </div>
          )}
          <div className="grid grid-cols-2 gap-3 text-sm">
            {participant.service_start_time && (
              <div><p className="text-xs text-muted-foreground">Début de service</p><p className="font-medium">{participant.service_start_time}</p></div>
            )}
            {participant.service_end_time && (
              <div><p className="text-xs text-muted-foreground">Fin de service</p><p className="font-medium">{participant.service_end_time}</p></div>
            )}
            {participant.setup_time && (
              <div><p className="text-xs text-muted-foreground">Installation</p><p className="font-medium">{participant.setup_time}</p></div>
            )}
            {participant.departure_time && (
              <div><p className="text-xs text-muted-foreground">Départ</p><p className="font-medium">{participant.departure_time}</p></div>
            )}
          </div>
          {(participant.contact_email || participant.contact_phone) && (
            <div className="mt-4 pt-4 border-t border-border/60">
              <p className="text-xs text-muted-foreground mb-2">Contact</p>
              <div className="flex flex-col gap-1 text-sm">
                {participant.contact_email && <span className="flex items-center gap-2"><Mail className="w-3.5 h-3.5 text-muted-foreground" />{participant.contact_email}</span>}
                {participant.contact_phone && <span className="flex items-center gap-2"><Phone className="w-3.5 h-3.5 text-muted-foreground" />{participant.contact_phone}</span>}
              </div>
            </div>
          )}
        </div>

        {timeline.length > 0 && (
          <div className="rounded-xl border border-border bg-card p-5">
            <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground mb-4">Déroulé de mon intervention</h2>
            <div className="space-y-2">
              {timeline.map(item => (
                <div key={item.id} className="flex items-start gap-3 p-3 rounded-lg border border-border/60">
                  <div className="flex flex-col items-center shrink-0">
                    <span className="text-sm font-bold">{item.start_time}</span>
                    {item.duration_minutes > 0 && <span className="text-xs text-muted-foreground">{item.duration_minutes}min</span>}
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-sm">{item.title}</p>
                    {item.location && <p className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5"><MapPin className="w-3 h-3" />{item.location}</p>}
                    {item.notes && <p className="text-xs text-muted-foreground mt-1">{item.notes}</p>}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {documents.length > 0 && (
          <div className="rounded-xl border border-border bg-card p-5">
            <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground mb-4">Mes documents</h2>
            <div className="space-y-2">
              {documents.map(doc => (
                <div key={doc.id} className="flex items-center gap-3 p-3 rounded-lg border border-border/60">
                  <FileText className="w-4 h-4 text-muted-foreground shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{doc.title}</p>
                    <p className="text-xs text-muted-foreground">{doc.category}</p>
                  </div>
                  {doc.file_url && (
                    <a href={doc.file_url} target="_blank" rel="noopener noreferrer" className="text-xs text-primary underline">Ouvrir</a>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="rounded-xl border border-border/40 bg-muted/20 p-4">
          <div className="flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-muted-foreground shrink-0 mt-0.5" />
            <p className="text-xs text-muted-foreground">
              Cet espace est privé et réservé à votre intervention. Vous ne voyez que les informations nécessaires à votre mission. Les données personnelles des invités et les informations privées des mariés ne sont pas accessibles.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}