import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import AdminShell from '@/components/admin/AdminShell';
import SiteWorkspaceCard from '@/components/dashboard/SiteWorkspaceCard';
import { Heart, FolderKanban, Users, FileText, Globe, Loader2 } from 'lucide-react';

export default function AdminDashboard() {
  const [stats, setStats] = useState(null);

  useEffect(() => {
    (async () => {
      try {
        const [projects, weddings, participants, documents, pages] = await Promise.all([
          base44.entities.AimeProject.list(),
          base44.entities.AimeProject.filter({ category: 'wedding' }),
          base44.entities.WeddingParticipant.list(),
          base44.entities.ProjectDocument.list(),
          base44.entities.PersonalPublicPage.list(),
        ]);
        setStats({
          projects: projects.length,
          weddings: weddings.length,
          participants: participants.length,
          documents: documents.length,
          pages: pages.length,
        });
      } catch (e) {
        console.error(e);
        setStats({ projects: 0, weddings: 0, participants: 0, documents: 0, pages: 0 });
      }
    })();
  }, []);

  return (
    <AdminShell>
      <div className="max-w-5xl">
        <div className="mb-8">
          <span className="brand-badge mb-3">Administration</span>
          <h1 className="font-heading text-4xl font-medium tracking-tight mb-2">Studio éditorial AIME</h1>
          <p className="text-sm text-muted-foreground">Pilotez le site, le contenu, les univers et les projets.</p>
        </div>

        {!stats ? (
          <div className="flex items-center justify-center py-20"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {[
              { label: 'Projets', value: stats.projects, icon: FolderKanban },
              { label: 'Mariages', value: stats.weddings, icon: Heart },
              { label: 'Prestataires', value: stats.participants, icon: Users },
              { label: 'Documents', value: stats.documents, icon: FileText },
              { label: 'Pages publiques', value: stats.pages, icon: Globe },
            ].map((stat) => {
              const Icon = stat.icon;
              return (
                <div key={stat.label} className="border border-border rounded-lg p-5 bg-card">
                  <Icon className="w-5 h-5 text-muted-foreground mb-3" strokeWidth={1.5} />
                  <p className="font-heading text-3xl font-medium mb-1">{stat.value}</p>
                  <p className="text-xs text-muted-foreground uppercase tracking-wider">{stat.label}</p>
                </div>
              );
            })}
          </div>
        )}

        <div className="mt-12">
          <SiteWorkspaceCard />
        </div>

        <div className="grid md:grid-cols-2 gap-4">
          <Link to="/admin/landing" className="border border-border rounded-lg p-6 hover:shadow-sm transition bg-card">
            <Globe className="w-5 h-5 text-muted-foreground mb-3" strokeWidth={1.5} />
            <h3 className="font-heading text-lg font-medium mb-1">Éditer la landing</h3>
            <p className="text-sm text-muted-foreground">Modifiez le hero, les textes et les sections.</p>
          </Link>
          <Link to="/studio/page" className="border border-border rounded-lg p-6 hover:shadow-sm transition bg-card">
            <FileText className="w-5 h-5 text-muted-foreground mb-3" strokeWidth={1.5} />
            <h3 className="font-heading text-lg font-medium mb-1">Pages publiques</h3>
            <p className="text-sm text-muted-foreground">Créez et publiez les pages du site AIME.</p>
          </Link>
        </div>
      </div>
    </AdminShell>
  );
}