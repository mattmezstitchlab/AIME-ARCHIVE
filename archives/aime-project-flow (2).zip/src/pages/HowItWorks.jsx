import LandingNav from '@/components/landing/LandingNav';
import LandingFooter from '@/components/landing/LandingFooter';
import PageHero from '@/components/landing/PageHero';
import { motion } from 'framer-motion';
import { Eye, Database, Brain, Sparkles, Palette, Share2 } from 'lucide-react';

const STEPS = [
  { label: 'SENSE', desc: 'Vous importez vos fichiers, liens et documents. AIME les observe sans juger.', icon: Eye },
  { label: 'MEMORY', desc: 'AIME structure ce que vous avez déposé en mémoire organisée.', icon: Database },
  { label: 'THINK', desc: 'AIME comprend les intentions, révèle les patterns et propose des pistes.', icon: Brain },
  { label: 'CREATE', desc: 'AIME génère les prochaines étapes cohérentes avec votre projet.', icon: Sparkles },
  { label: 'STUDIO', desc: 'Votre projet prend forme visuellement dans un espace éditable.', icon: Palette },
  { label: 'SHARE', desc: 'Vous partagez la version publique de votre projet quand vous le décidez.', icon: Share2 },
];

export default function HowItWorks() {
  return (
    <div className="min-h-screen bg-background">
      <LandingNav />
      <PageHero
        image="https://media.base44.com/images/public/6a6e080d1aca70178ff1340c/097ecfa45_generated_image.png"
        badge="Comment ça marche"
        title="AIME comprend votre mariage."
        subtitle="Vous gardez la décision. AIME s'occupe de comprendre, d'organiser et de révéler ce qui peut venir ensuite."
        focalPointY={0.45}
      />
      <section className="pt-20 pb-24 px-6">
        <div className="max-w-4xl mx-auto">
          <div className="space-y-0">
            {STEPS.map((step, i) => {
              const Icon = step.icon;
              return (
                <motion.div
                  key={step.label}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true, margin: '-80px' }}
                  transition={{ duration: 0.5, delay: i * 0.08 }}
                  className="flex items-start gap-6 md:gap-8"
                >
                  <div className="flex flex-col items-center">
                    <div className="w-14 h-14 rounded-full border border-border bg-card flex items-center justify-center shrink-0">
                      <Icon className="w-5 h-5 text-foreground" strokeWidth={1.5} />
                    </div>
                    {i < STEPS.length - 1 && <div className="w-px h-16 md:h-24 bg-border mt-2" />}
                  </div>
                  <div className="pb-12 flex-1">
                    <div className="flex items-baseline gap-3 mb-2">
                      <span className="text-[10px] text-muted-foreground font-mono">0{i + 1}</span>
                      <h3 className="font-heading text-2xl font-medium tracking-tight">{step.label}</h3>
                    </div>
                    <p className="text-base text-muted-foreground leading-relaxed max-w-lg">{step.desc}</p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>
      <LandingFooter />
    </div>
  );
}