import { useEffect, useState } from "react";
import { Save, Eye, Loader2 } from "lucide-react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { toast } from "@/components/ui/use-toast";
import { LANDING_DEFAULTS } from "@/lib/landingDefaults";
import LandingHeroEditor from "@/components/admin/LandingHeroEditor";
import LandingSectionsEditor from "@/components/admin/LandingSectionsEditor";

export default function AdminLanding() {
  const [record, setRecord] = useState(null); const [form, setForm] = useState(LANDING_DEFAULTS); const [allowed, setAllowed] = useState(null); const [saving, setSaving] = useState(false);
  useEffect(() => { (async () => { const me = await base44.auth.me(); setAllowed(me.role === "admin"); if (me.role === "admin") { const rows = await base44.entities.LandingPage.filter({ key: "main" }); if (rows[0]) { setRecord(rows[0]); setForm({ ...LANDING_DEFAULTS, ...rows[0], sections: rows[0].sections || [] }); } } })(); }, []);
  const save = async () => { setSaving(true); try { const payload = { key: "main", heroStyle: form.heroStyle, eyebrow: form.eyebrow, title: form.title, subtitle: form.subtitle, ctaLabel: form.ctaLabel, sections: form.sections }; const next = record ? await base44.entities.LandingPage.update(record.id, payload) : await base44.entities.LandingPage.create(payload); setRecord(next); toast({ title: "Landing mise à jour" }); } catch (error) { toast({ title: "Mise à jour impossible", description: error.message, variant: "destructive" }); } setSaving(false); };
  if (allowed === null) return <div className="flex min-h-[50vh] items-center justify-center"><Loader2 className="h-6 w-6 animate-spin" /></div>;
  if (!allowed) return <div className="mx-auto max-w-xl p-12 text-center"><h1 className="text-3xl font-semibold">Accès administrateur requis</h1></div>;
  return <div className="mx-auto max-w-5xl px-4 py-10 sm:px-8"><header className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between"><div><span className="brand-badge">Administration</span><h1 className="mt-4 text-4xl font-semibold">Landing AIME</h1><p className="mt-3 text-sm text-muted-foreground">Pilotez le hero, les textes et la structure publique.</p></div><div className="flex gap-2"><Link to="/landing" className="brand-outline-btn"><Eye className="h-4 w-4" />Voir</Link><button onClick={save} disabled={saving} className="brand-secondary-btn">{saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}Enregistrer</button></div></header><div className="space-y-6"><LandingHeroEditor value={form} onChange={setForm} /><LandingSectionsEditor sections={form.sections} onChange={sections => setForm({ ...form, sections })} /></div></div>;
}