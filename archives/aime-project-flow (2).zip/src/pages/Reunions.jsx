import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { formatDate } from "@/lib/aimeFormats";
import { logAction } from "@/lib/aimeAgent";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter
} from "@/components/ui/dialog";
import EmptyState from "@/components/EmptyState";
import ReunionPanel from "@/components/reunions/ReunionPanel";
import { useToast } from "@/components/ui/use-toast";
import {
  CalendarDays, Plus, Loader2, MapPin, ChevronDown, CheckCircle2, XCircle, RotateCcw, Trash2
} from "lucide-react";
import { useAssociation } from "@/components/AssociationProvider";

const STATUS = {
  planifie: { label: "Planifiée", cls: "bg-sky/20 text-sky-foreground border-sky/30" },
  realise: { label: "Réalisée", cls: "bg-sage/20 text-sage-foreground border-sage/30" },
  annule:  { label: "Annulée",  cls: "bg-muted text-muted-foreground" }
};

export default function Reunions() {
  const { toast } = useToast();
  const { activeAssociationId } = useAssociation();
  const [reunions, setReunions] = useState([]);
  const [projects, setProjects] = useState([]);
  const [membres, setMembres] = useState([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [expanded, setExpanded] = useState(null);
  const [form, setForm] = useState({ project_id: "", title: "", date: "", location: "" });
  const [invited, setInvited] = useState([]);

  async function load() {
    setLoading(true);
    try {
      const [r, p, m] = await Promise.all([
        base44.entities.Reunion.list(),
        base44.entities.Projet.list(),
        base44.entities.Membre.list()
      ]);
      setReunions(r);
      setProjects(p);
      setMembres(m);
    } catch { /* bubble */ }
    setLoading(false);
  }
  useEffect(() => { load(); }, []);

  const projectMap = useMemo(
    () => Object.fromEntries(projects.map((p) => [p.id, p])),
    [projects]
  );

  const groups = useMemo(() => {
    const map = {};
    for (const r of reunions) {
      const key = r.project_id || "_none";
      (map[key] = map[key] || []).push(r);
    }
    return Object.entries(map).sort((a, b) => {
      const na = projectMap[a[0]]?.name || "ZZZ";
      const nb = projectMap[b[0]]?.name || "ZZZ";
      return na.localeCompare(nb);
    });
  }, [reunions, projectMap]);

  function sorted(list) {
    return [...list].sort((a, b) => (b.date || "").localeCompare(a.date || ""));
  }

  async function create() {
    if (!form.project_id || !form.title.trim()) return;
    const names = invited.map((id) => membres.find((m) => m.id === id)).filter(Boolean).map((m) => m.full_name);
    const presence = names.map((n) => ({ name: n, status: "present" }));
    await base44.entities.Reunion.create({
      project_id: form.project_id,
      association_id: activeAssociationId,
      title: form.title,
      date: form.date || null,
      location: form.location,
      participants: names,
      presence,
      status: "planifie"
    });
    await logAction("creation_reunion", "Reunion", null, form.project_id, "Réunion « " + form.title + " » créée.");
    setForm({ project_id: "", title: "", date: "", location: "" });
    setInvited([]);
    setOpen(false);
    toast({ title: "Réunion créée" });
    load();
  }

  async function quickStatus(r, status) {
    await base44.entities.Reunion.update(r.id, { status });
    load();
  }

  async function remove(r) {
    await base44.entities.Reunion.delete(r.id);
    toast({ title: "Réunion supprimée" });
    load();
  }

  function toggleInvited(id) {
    setInvited((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  }

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-10 pt-8 lg:pt-12">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-semibold flex items-center gap-2">
            <CalendarDays className="w-6 h-6 text-primary" /> Réunions
          </h1>
          <p className="text-sm text-muted-foreground mt-1">Ordres du jour, feuilles de présence et comptes rendus — AIME peut rédiger le compte rendu.</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="gap-1.5"><Plus className="w-4 h-4" /> Nouvelle réunion</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Planifier une réunion</DialogTitle></DialogHeader>
            <div className="space-y-3 py-2">
              <div>
                <Label>Projet</Label>
                <Select value={form.project_id} onValueChange={(v) => setForm({ ...form, project_id: v })}>
                  <SelectTrigger><SelectValue placeholder="Choisir un projet" /></SelectTrigger>
                  <SelectContent>
                    {projects.map((p) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Titre</Label>
                <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Ex. Réunion de pilotage" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>Date</Label>
                  <Input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} />
                </div>
                <div>
                  <Label>Lieu</Label>
                  <Input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} placeholder="Salle, en ligne…" />
                </div>
              </div>
              <div>
                <Label>Participants invités</Label>
                <div className="max-h-44 overflow-y-auto rounded-lg border border-border p-2 space-y-2">
                  {membres.length === 0 ? (
                    <p className="text-xs text-muted-foreground px-2 py-1">Aucun membre. Ajoutez-en depuis l'espace Membres.</p>
                  ) : membres.map((m) => (
                    <label key={m.id} className="flex items-center gap-2.5 px-1 py-1 cursor-pointer">
                      <Checkbox checked={invited.includes(m.id)} onCheckedChange={() => toggleInvited(m.id)} />
                      <span className="text-sm">{m.full_name}</span>
                      <span className="text-xs text-muted-foreground ml-auto">{m.role}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="ghost" onClick={() => setOpen(false)}>Annuler</Button>
              <Button onClick={create} disabled={!form.project_id || !form.title.trim()}>Créer</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {loading ? (
        <div className="flex justify-center pt-10"><Loader2 className="w-5 h-5 animate-spin text-muted-foreground" /></div>
      ) : reunions.length === 0 ? (
        <EmptyState
          icon={CalendarDays}
          title="Aucune réunion"
          description="Planifiez une réunion, son ordre du jour et invitez les membres. La présence et le compte rendu se remplissent ensuite."
        />
      ) : (
        <div className="space-y-6">
          {groups.map(([pid, list]) => {
            const proj = projectMap[pid];
            return (
              <div key={pid}>
                <div className="flex items-center gap-2 mb-3">
                  <h2 className="font-display text-base font-medium">{proj?.name || "Sans projet"}</h2>
                  {proj && <Link to={"/projects/" + proj.id} className="text-xs text-muted-foreground hover:text-primary">ouvrir le projet →</Link>}
                </div>
                <div className="space-y-3">
                  {sorted(list).map((r) => {
                    const st = STATUS[r.status] || STATUS.planifie;
                    const isOpen = expanded === r.id;
                    return (
                      <Card key={r.id} className="soft-shadow">
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between gap-3">
                            <button onClick={() => setExpanded(isOpen ? null : r.id)} className="text-left flex-1 min-w-0">
                              <div className="flex items-center gap-2 flex-wrap">
                                <p className="text-sm font-medium">{r.title}</p>
                                <Badge variant="outline" className={"font-normal border-0 " + st.cls}>{st.label}</Badge>
                              </div>
                              <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground flex-wrap">
                                <span className="flex items-center gap-1"><CalendarDays className="w-3.5 h-3.5" /> {formatDate(r.date) || "à planifier"}</span>
                                {r.location && <span className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5" /> {r.location}</span>}
                                <span>{r.participants?.length || r.presence?.length || 0} participant(s)</span>
                              </div>
                            </button>
                            <div className="flex items-center gap-1 shrink-0">
                              {r.status === "planifie" && (
                                <>
                                  <button onClick={() => quickStatus(r, "realise")} title="Marquer réalisée" className="p-1.5 rounded-md hover:bg-sage/15 text-sage"><CheckCircle2 className="w-4 h-4" /></button>
                                  <button onClick={() => quickStatus(r, "annule")} title="Annuler" className="p-1.5 rounded-md hover:bg-destructive/10 text-destructive"><XCircle className="w-4 h-4" /></button>
                                </>
                              )}
                              {r.status === "annule" && (
                                <button onClick={() => quickStatus(r, "planifie")} title="Rouvrir" className="p-1.5 rounded-md hover:bg-muted"><RotateCcw className="w-4 h-4" /></button>
                              )}
                              <button onClick={() => remove(r)} title="Supprimer" className="p-1.5 rounded-md hover:bg-destructive/10 text-muted-foreground hover:text-destructive"><Trash2 className="w-4 h-4" /></button>
                              <button onClick={() => setExpanded(isOpen ? null : r.id)} className="p-1.5 rounded-md hover:bg-muted text-muted-foreground">
                                <ChevronDown className={"w-4 h-4 transition " + (isOpen ? "rotate-180" : "")} />
                              </button>
                            </div>
                          </div>

                          {isOpen && <ReunionPanel reunion={r} project={proj} onChange={load} />}
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}