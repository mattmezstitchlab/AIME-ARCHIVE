import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/components/ui/use-toast";
import { Loader2, Save, Building2 } from "lucide-react";
import { useAssociation } from "@/components/AssociationProvider";

export default function AssociationSettings() {
  const { activeAssoc, activeAssociationId, refresh, me } = useAssociation();
  const { toast } = useToast();
  const [form, setForm] = useState(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (activeAssoc) {
      setForm({
        name: activeAssoc.name || "",
        slogan: activeAssoc.slogan || "",
        description: activeAssoc.description || "",
        color: activeAssoc.color || "#1F2937",
        logo: activeAssoc.logo || "",
        address: activeAssoc.address || "",
        email: activeAssoc.email || "",
        phone: activeAssoc.phone || "",
        website: activeAssoc.website || "",
        legal_info: activeAssoc.legal_info || ""
      });
    }
  }, [activeAssoc?.id]);

  if (!form) {
    return (
      <div className="max-w-2xl mx-auto px-4 pt-20 flex justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  async function save() {
    setSaving(true);
    try {
      await base44.entities.Association.update(activeAssociationId, form);
      await refresh();
      toast({ title: "Paramètres enregistrés" });
    } catch (e) {
      toast({ title: "Erreur lors de l'enregistrement", variant: "destructive" });
    }
    setSaving(false);
  }

  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-10 pt-8 lg:pt-12 pb-12">
      <div className="flex items-center gap-2 mb-6">
        <div className="w-9 h-9 rounded-xl bg-navy/10 flex items-center justify-center"><Building2 className="w-5 h-5 text-navy" /></div>
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-semibold">Paramètres</h1>
          <p className="text-sm text-muted-foreground mt-1">Identité et informations de votre association.</p>
        </div>
      </div>

      <div className="space-y-5">
        <Card className="soft-shadow">
          <CardContent className="p-5 space-y-4">
            <h3 className="font-display text-base font-medium">Identité</h3>
            <div>
              <Label>Nom</Label>
              <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="mt-1" />
            </div>
            <div>
              <Label>Slogan</Label>
              <Input value={form.slogan} onChange={(e) => setForm({ ...form, slogan: e.target.value })} placeholder="Ex. Agir ensemble pour demain" className="mt-1" />
            </div>
            <div>
              <Label>Description</Label>
              <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={3} className="mt-1" />
            </div>
            <div>
              <Label>Couleur principale</Label>
              <div className="flex items-center gap-3 mt-1">
                <input type="color" value={form.color} onChange={(e) => setForm({ ...form, color: e.target.value })} className="w-10 h-10 rounded-lg border border-border cursor-pointer" />
                <Input value={form.color} onChange={(e) => setForm({ ...form, color: e.target.value })} className="max-w-32" />
              </div>
            </div>
            <div>
              <Label>Logo (URL)</Label>
              <Input value={form.logo} onChange={(e) => setForm({ ...form, logo: e.target.value })} placeholder="https://…" className="mt-1" />
            </div>
          </CardContent>
        </Card>

        <Card className="soft-shadow">
          <CardContent className="p-5 space-y-4">
            <h3 className="font-display text-base font-medium">Coordonnées</h3>
            <div>
              <Label>Adresse</Label>
              <Input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} placeholder="12 rue de la Paix, 75001 Paris" className="mt-1" />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <Label>Email</Label>
                <Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="mt-1" />
              </div>
              <div>
                <Label>Téléphone</Label>
                <Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="mt-1" />
              </div>
            </div>
            <div>
              <Label>Site web</Label>
              <Input value={form.website} onChange={(e) => setForm({ ...form, website: e.target.value })} placeholder="https://…" className="mt-1" />
            </div>
          </CardContent>
        </Card>

        <Card className="soft-shadow">
          <CardContent className="p-5 space-y-4">
            <h3 className="font-display text-base font-medium">Informations légales</h3>
            <div>
              <Label>Statut juridique, RNA, SIRET, siège social…</Label>
              <Textarea value={form.legal_info} onChange={(e) => setForm({ ...form, legal_info: e.target.value })} rows={3} className="mt-1" />
            </div>
          </CardContent>
        </Card>

        <div className="flex justify-end">
          <Button onClick={save} disabled={saving} className="gap-2">
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            Enregistrer
          </Button>
        </div>
      </div>
    </div>
  );
}