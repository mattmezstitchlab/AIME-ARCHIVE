import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { euro } from "@/lib/aimeFormats";
import EmptyState from "@/components/EmptyState";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ShieldCheck, AlertTriangle, Receipt, Wallet, FileQuestion, CalendarClock, FolderKanban, Loader2, ArrowRight } from "lucide-react";

export default function Vigilance() {
  const [loading, setLoading] = useState(true);
  const [alerts, setAlerts] = useState([]);
  const [health, setHealth] = useState(0);

  useEffect(() => {
    (async () => {
      try {
        const [projects, justifs, depenses, lignes, taches] = await Promise.all([
          base44.entities.Projet.list(),
          base44.entities.Justificatif.list(),
          base44.entities.Depense.list(),
          base44.entities.LigneBudgetaire.list(),
          base44.entities.Tache.list()
        ]);
        const list = [];
        projects.forEach((p) => {
          (p.missing_fields || []).forEach((m) => list.push({ type: "info", icon: FileQuestion, title: "Information manquante", desc: m, project: p }));
        });
        justifs.forEach((j) => {
          if (j.status === "a_confirmer" || j.status === "en_analyse") {
            const p = projects.find((x) => x.id === j.project_id);
            list.push({ type: "warn", icon: Receipt, title: "Justificatif à confirmer", desc: "AIME a analysé un document, à valider.", project: p });
          }
        });
        depenses.forEach((d) => {
          if (!d.justificatif_id) {
            const p = projects.find((x) => x.id === d.project_id);
            list.push({ type: "danger", icon: Wallet, title: "Dépense sans preuve", desc: euro(d.montant) + " — " + d.description, project: p });
          }
        });
        lignes.forEach((l) => {
          if (Number(l.montant_realise) > Number(l.montant_prevu) && Number(l.montant_prevu) > 0) {
            const over = ((l.montant_realise - l.montant_prevu) / l.montant_prevu) * 100;
            const p = projects.find((x) => x.id === l.project_id);
            list.push({ type: "danger", icon: Wallet, title: "Budget dépassé", desc: "« " + l.label + " » dépasse la prévision de " + Math.round(over) + "%.", project: p });
          }
        });
        taches.forEach((t) => {
          if (t.due_date && t.status !== "fait" && new Date(t.due_date) < new Date()) {
            const p = projects.find((x) => x.id === t.project_id);
            list.push({ type: "warn", icon: CalendarClock, title: "Échéance dépassée", desc: t.title, project: p });
          }
        });
        setAlerts(list);
        const avg = projects.length ? Math.round(projects.reduce((s, p) => s + (p.completion_pct || 0), 0) / projects.length) : 0;
        setHealth(avg);
      } catch (e) {}
      setLoading(false);
    })();
  }, []);

  if (loading) return <div className="flex justify-center pt-20"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>;

  const colorMap = {
    info: "border-blue-200 bg-blue-50 text-blue-700",
    warn: "border-amber-200 bg-amber-50 text-amber-700",
    danger: "border-red-200 bg-red-50 text-red-700"
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-10 pt-8 lg:pt-12">
      <div className="flex items-center gap-2 mb-2">
        <div className="w-9 h-9 rounded-xl bg-navy/10 flex items-center justify-center"><ShieldCheck className="w-5 h-5 text-navy" /></div>
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-semibold">Vigilance</h1>
          <p className="text-sm text-muted-foreground">Ce qui manque, ce qui attend validation, ce qui bloque.</p>
        </div>
      </div>

      <div className="mt-5 rounded-2xl bg-navy text-white p-5 soft-shadow flex items-center gap-5">
        <div className="relative w-16 h-16 shrink-0">
          <svg className="w-16 h-16 -rotate-90" viewBox="0 0 36 36">
            <circle cx="18" cy="18" r="15.5" fill="none" stroke="rgba(255,255,255,0.15)" strokeWidth="3" />
            <circle cx="18" cy="18" r="15.5" fill="none" stroke="hsl(var(--primary))" strokeWidth="3" strokeDasharray={2 * Math.PI * 15.5} strokeDashoffset={2 * Math.PI * 15.5 * (1 - health / 100)} strokeLinecap="round" />
          </svg>
          <span className="absolute inset-0 flex items-center justify-center font-display text-lg font-semibold">{health}%</span>
        </div>
        <div>
          <p className="font-medium">Santé globale de l'association</p>
          <p className="text-sm text-white/70">
            {alerts.length === 0 ? "Aucune alerte. Tout est à jour." : alerts.length + " point" + (alerts.length > 1 ? "s" : "") + " d'attention."}
          </p>
        </div>
      </div>

      {alerts.length === 0 ? (
        <div className="mt-6">
          <EmptyState icon={ShieldCheck} title="Tout est sous contrôle" description="Aucune information manquante, aucun justificatif en attente, aucune dépense sans preuve." />
        </div>
      ) : (
        <div className="mt-6 space-y-3">
          {alerts.map((a, i) => (
            <Card key={i} className="soft-shadow overflow-hidden">
              <CardContent className="p-0">
                <div className="flex items-stretch">
                  <div className={"w-1.5 " + (a.type === "danger" ? "bg-destructive" : a.type === "warn" ? "bg-primary" : "bg-blue-400")} />
                  <div className="flex-1 p-4 flex items-start gap-3">
                    <div className={"w-9 h-9 rounded-lg border flex items-center justify-center shrink-0 " + colorMap[a.type]}>
                      <a.icon className="w-4 h-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium">{a.title}</p>
                      <p className="text-sm text-muted-foreground mt-0.5">{a.desc}</p>
                      {a.project && (
                        <Link to={"/projects/" + a.project.id} className="inline-flex items-center gap-1 text-xs text-primary mt-2 hover:underline">
                          {a.project.name} <ArrowRight className="w-3 h-3" />
                        </Link>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}