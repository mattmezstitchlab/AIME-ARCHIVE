import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { ROLE_LABELS, MEMBER_STATUS } from "@/lib/aimeFormats";
import EmptyState from "@/components/EmptyState";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogContent, AlertDialogHeader, AlertDialogTitle,
  AlertDialogAction, AlertDialogCancel, AlertDialogFooter, AlertDialogDescription
} from "@/components/ui/alert-dialog";
import { useToast } from "@/components/ui/use-toast";
import { Users, Plus, Loader2, Mail, Trash2, Pencil, UserPlus, Ban, Check } from "lucide-react";
import { useAssociation } from "@/components/AssociationProvider";

const ROLE_PERMS = {
  administrateur: "Accès total · gestion rôles & association",
  responsable: "Gestion des projets & des membres",
  membre: "Lecture & saisie sur les projets",
  benevole: "Lecture & saisie sur les projets assignés",
  lecteur: "Lecture seule globale"
};

const NEW_ROLES = ["administrateur", "responsable", "membre", "benevole", "lecteur"];

export default function Membres() {
  const [membres, setMembres] = useState([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [editTarget, setEditTarget] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [form, setForm] = useState({ full_name: "", email: "", role: "benevole", phone: "" });
  const [editForm, setEditForm] = useState({ full_name: "", email: "", role: "benevole", phone: "", status: "actif" });
  const [inviting, setInviting] = useState(false);
  const { toast } = useToast();
  const { activeAssociationId, me } = useAssociation();

  async function load() {
    setLoading(true);
    try { setMembres(await base44.entities.Membre.list()); } catch (e) {}
    setLoading(false);
  }
  useEffect(() => { load(); }, []);

  const roleColors = {
    administrateur: "bg-navy text-white",
    responsable: "bg-primary text-primary-foreground",
    membre: "bg-blue-100 text-blue-700",
    benevole: "bg-muted text-foreground",
    lecteur: "bg-muted text-muted-foreground"
  };

  async function invite() {
    if (!form.full_name.trim() || !form.email.trim()) return;
    setInviting(true);
    try {
      const m = await base44.entities.Membre.create({
        full_name: form.full_name.trim(),
        email: form.email.trim(),
        phone: form.phone,
        role: form.role,
        association_id: activeAssociationId,
        status: "invite",
        invited_at: new Date().toISOString()
      });
      try {
        await base44.users.inviteUser(form.email.trim(), "user");
      } catch (inviteErr) {
        // L'invitation app peut échouer si l'utilisateur existe déjà — le membre reste créé
      }
      await logInviteAction(m.id);
      setForm({ full_name: "", email: "", role: "benevole", phone: "" });
      setOpen(false);
      toast({ title: "Invitation envoyée", description: form.email });
      load();
    } catch (e) {
      toast({ title: "Erreur lors de l'invitation", variant: "destructive" });
    }
    setInviting(false);
  }

  async function logInviteAction(membreId) {
    try {
      await base44.entities.JournalEntree.create({
        action: "invitation_membre",
        entity_type: "Membre",
        entity_id: membreId,
        details: "Membre invité par email.",
        association_id: activeAssociationId
      });
    } catch (e) {}
  }

  function startEdit(m) {
    setEditTarget(m);
    setEditForm({
      full_name: m.full_name || "",
      email: m.email || "",
      role: NEW_ROLES.includes(m.role) ? m.role : "benevole",
      phone: m.phone || "",
      status: m.status || "actif"
    });
  }

  async function saveEdit() {
    if (!editTarget) return;
    try {
      await base44.entities.Membre.update(editTarget.id, {
        full_name: editForm.full_name,
        email: editForm.email,
        role: editForm.role,
        phone: editForm.phone,
        status: editForm.status
      });
      setEditTarget(null);
      toast({ title: "Membre mis à jour" });
      load();
    } catch (e) {
      toast({ title: "Erreur", variant: "destructive" });
    }
  }

  async function changeStatus(m, status) {
    try {
      await base44.entities.Membre.update(m.id, { status });
      toast({ title: status === "actif" ? "Membre réactivé" : status === "suspendu" ? "Membre suspendu" : "Statut mis à jour" });
      load();
    } catch (e) { toast({ title: "Erreur", variant: "destructive" }); }
  }

  async function remove() {
    if (!deleteTarget) return;
    try {
      await base44.entities.Membre.delete(deleteTarget.id);
      setDeleteTarget(null);
      toast({ title: "Membre supprimé" });
      load();
    } catch (e) { toast({ title: "Erreur", variant: "destructive" }); }
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-10 pt-8 lg:pt-12">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-semibold">Membres & rôles</h1>
          <p className="text-sm text-muted-foreground mt-1">L'équipe de l'association, avec ses permissions.</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button className="gap-1.5"><UserPlus className="w-4 h-4" /> Inviter</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Inviter un membre</DialogTitle></DialogHeader>
            <div className="space-y-3 py-2">
              <div>
                <Label>Nom complet</Label>
                <Input value={form.full_name} onChange={(e) => setForm({ ...form, full_name: e.target.value })} placeholder="Ex. Camille Durand" />
              </div>
              <div>
                <Label>Email</Label>
                <Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="camille@asso.fr" />
                <p className="text-xs text-muted-foreground mt-1">Un email d'invitation sera envoyé pour créer le compte.</p>
              </div>
              <div>
                <Label>Téléphone (optionnel)</Label>
                <Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="06 12 34 56 78" />
              </div>
              <div>
                <Label>Rôle</Label>
                <Select value={form.role} onValueChange={(v) => setForm({ ...form, role: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {NEW_ROLES.map((r) => <SelectItem key={r} value={r}>{ROLE_LABELS[r]}</SelectItem>)}
                  </SelectContent>
                </Select>
                <p className="text-xs text-muted-foreground mt-1">{ROLE_PERMS[form.role]}</p>
              </div>
            </div>
            <DialogFooter>
              <Button variant="ghost" onClick={() => setOpen(false)}>Annuler</Button>
              <Button onClick={invite} disabled={inviting || !form.full_name.trim() || !form.email.trim()} className="gap-1.5">
                {inviting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Mail className="w-4 h-4" />}
                Envoyer l'invitation
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {loading ? (
        <div className="flex justify-center pt-10"><Loader2 className="w-5 h-5 animate-spin text-muted-foreground" /></div>
      ) : membres.length === 0 ? (
        <EmptyState icon={Users} title="Aucun membre" description="Invitez les bénévoles et responsables de votre association. Chaque rôle a ses propres permissions." />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {membres.map((m) => {
            const st = MEMBER_STATUS[m.status] || MEMBER_STATUS.actif;
            return (
              <Card key={m.id} className="soft-shadow">
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <div className="w-11 h-11 rounded-full bg-navy/10 text-navy flex items-center justify-center font-display font-semibold shrink-0">
                      {m.full_name?.[0]?.toUpperCase()}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="text-sm font-medium truncate">{m.full_name}</p>
                        <Badge className={(roleColors[m.role] || "bg-muted") + " border-0 font-normal"}>{ROLE_LABELS[m.role] || m.role}</Badge>
                      </div>
                      <p className="text-xs text-muted-foreground truncate mt-0.5">{m.email || "—"}</p>
                      {m.phone && <p className="text-xs text-muted-foreground">{m.phone}</p>}
                      <Badge variant="outline" className={"font-normal border-0 mt-1 " + st.cls}>{st.label}</Badge>
                    </div>
                    <div className="flex flex-col gap-1 shrink-0">
                      <button onClick={() => startEdit(m)} title="Modifier" className="p-1.5 rounded-md hover:bg-accent text-muted-foreground hover:text-foreground">
                        <Pencil className="w-3.5 h-3.5" />
                      </button>
                      {m.status === "suspendu" ? (
                        <button onClick={() => changeStatus(m, "actif")} title="Réactiver" className="p-1.5 rounded-md hover:bg-sage/10 text-muted-foreground hover:text-sage">
                          <Check className="w-3.5 h-3.5" />
                        </button>
                      ) : m.status === "actif" ? (
                        <button onClick={() => changeStatus(m, "suspendu")} title="Suspendre" className="p-1.5 rounded-md hover:bg-destructive/10 text-muted-foreground hover:text-destructive">
                          <Ban className="w-3.5 h-3.5" />
                        </button>
                      ) : null}
                      <button onClick={() => setDeleteTarget(m)} title="Supprimer" className="p-1.5 rounded-md hover:bg-destructive/10 text-muted-foreground hover:text-destructive">
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Edit dialog */}
      <Dialog open={!!editTarget} onOpenChange={(o) => !o && setEditTarget(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Modifier le membre</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <div>
              <Label>Nom complet</Label>
              <Input value={editForm.full_name} onChange={(e) => setEditForm({ ...editForm, full_name: e.target.value })} />
            </div>
            <div>
              <Label>Email</Label>
              <Input type="email" value={editForm.email} onChange={(e) => setEditForm({ ...editForm, email: e.target.value })} />
            </div>
            <div>
              <Label>Téléphone</Label>
              <Input value={editForm.phone} onChange={(e) => setEditForm({ ...editForm, phone: e.target.value })} />
            </div>
            <div>
              <Label>Rôle</Label>
              <Select value={editForm.role} onValueChange={(v) => setEditForm({ ...editForm, role: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {NEW_ROLES.map((r) => <SelectItem key={r} value={r}>{ROLE_LABELS[r]}</SelectItem>)}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground mt-1">{ROLE_PERMS[editForm.role]}</p>
            </div>
            <div>
              <Label>Statut</Label>
              <Select value={editForm.status} onValueChange={(v) => setEditForm({ ...editForm, status: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="invite">Invité</SelectItem>
                  <SelectItem value="actif">Actif</SelectItem>
                  <SelectItem value="suspendu">Suspendu</SelectItem>
                  <SelectItem value="inactif">Inactif</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setEditTarget(null)}>Annuler</Button>
            <Button onClick={saveEdit}>Enregistrer</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete confirmation */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Supprimer ce membre ?</AlertDialogTitle>
            <AlertDialogDescription>
              {deleteTarget?.full_name} sera retiré de l'association. Cette action est définitive.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annuler</AlertDialogCancel>
            <AlertDialogAction onClick={remove} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Supprimer
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}