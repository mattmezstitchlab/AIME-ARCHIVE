import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import ContextSidebar from "@/components/project-context/ContextSidebar";
import PublicCanvas from "@/components/project-context/PublicCanvas";
import OverviewModule from "@/components/project-context/modules/OverviewModule";
import PlanningModule from "@/components/project-context/modules/PlanningModule";
import TasksModule from "@/components/project-context/modules/TasksModule";
import GuestsModule from "@/components/project-context/modules/GuestsModule";
import VendorsModule from "@/components/project-context/modules/VendorsModule";
import BudgetModule from "@/components/project-context/modules/BudgetModule";
import SeatingModule from "@/components/project-context/modules/SeatingModule";
import MessagesModule from "@/components/project-context/modules/MessagesModule";
import SettingsModule from "@/components/project-context/modules/SettingsModule";
import GalleryModule from "@/components/project-context/modules/GalleryModule";
import DocumentsModule from "@/components/project-context/modules/DocumentsModule";

export default function ProjectPage() {
  const { pageId } = useParams();
  const [page, setPage] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeModule, setActiveModule] = useState("overview");
  const [previewMode, setPreviewMode] = useState(false);

  // Project data
  const [guests, setGuests] = useState([]);
  const [vendors, setVendors] = useState([]);
  const [budgetItems, setBudgetItems] = useState([]);
  const [tables, setTables] = useState([]);
  const [messages, setMessages] = useState([]);
  const [tasks, setTasks] = useState([]);

  useEffect(() => {
    (async () => {
      try {
        const pageData = await base44.entities.PersonalPublicPage.get(pageId);
        setPage(pageData);
        if (pageData.userId) {
          const [g, v, b, t] = await Promise.all([
            base44.entities.ProjectGuest.filter({ pageId }).catch(() => []),
            base44.entities.ProjectVendor.filter({ pageId }).catch(() => []),
            base44.entities.ProjectBudgetItem.filter({ pageId }).catch(() => []),
            base44.entities.ProjectSeatingTable.filter({ pageId }).catch(() => []),
          ]);
          setGuests(g);
          setVendors(v);
          setBudgetItems(b);
          setTables(t.sort((a, b) => (a.position || 0) - (b.position || 0)));
        }
      } catch (e) {
        setError(e.message || "Page introuvable");
      }
      setLoading(false);
    })();
  }, [pageId]);

  if (loading) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin" />
      </div>
    );
  }

  if (error || !page) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-4 p-6 text-center">
        <h1 className="text-2xl font-display font-semibold">Page introuvable</h1>
        <p className="text-sm text-muted-foreground">{error || "Cette page n'existe pas."}</p>
        <a href="/" className="text-sm text-primary underline">Retour à l'accueil</a>
      </div>
    );
  }

  const renderModule = () => {
    if (previewMode) {
      return <PublicCanvas page={page} isEditing={false} onToggleEdit={() => setPreviewMode(false)} />;
    }
    switch (activeModule) {
      case "overview":
        return <OverviewModule page={page} guests={guests} vendors={vendors} budgetItems={budgetItems} messages={messages} tasks={tasks} />;
      case "planning":
        return <PlanningModule page={page} />;
      case "tasks":
        return <TasksModule page={page} />;
      case "guests":
        return <GuestsModule page={page} guests={guests} setGuests={setGuests} />;
      case "vendors":
        return <VendorsModule page={page} vendors={vendors} setVendors={setVendors} />;
      case "budget":
        return <BudgetModule page={page} budgetItems={budgetItems} setBudgetItems={setBudgetItems} />;
      case "seating":
        return <SeatingModule page={page} tables={tables} setTables={setTables} guests={guests} setGuests={setGuests} />;
      case "gallery":
        return <GalleryModule page={page} />;
      case "messages":
        return <MessagesModule page={page} />;
      case "documents":
        return <DocumentsModule page={page} />;
      case "settings":
        return <SettingsModule page={page} setPage={setPage} />;
      default:
        return <OverviewModule page={page} guests={guests} vendors={vendors} budgetItems={budgetItems} messages={messages} tasks={tasks} />;
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <ContextSidebar
        page={page}
        activeModule={activeModule}
        onModuleChange={(m) => { setActiveModule(m); setPreviewMode(false); }}
        onTogglePreview={() => setPreviewMode(!previewMode)}
        previewMode={previewMode}
      />
      <div className="flex-1 overflow-y-auto">
        {previewMode ? (
          <PublicCanvas page={page} isEditing={false} onToggleEdit={() => setPreviewMode(false)} />
        ) : activeModule === "gallery" ? (
          <PublicCanvas page={page} isEditing={true} onToggleEdit={() => setPreviewMode(true)} />
        ) : (
          renderModule()
        )}
      </div>
    </div>
  );
}