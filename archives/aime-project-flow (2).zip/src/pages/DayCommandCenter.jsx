import { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { ArrowLeft, Loader2, Clock, AlertTriangle, CheckCircle, Users, FileText, Radio, Phone, Zap } from 'lucide-react';
import { normalizeDna } from '@/lib/aime/dnaNormalize';

const STATUS_COLORS = {
  a_venir: 'text-muted-foreground',
  en_preparation: 'text-blue-500',
  pret: 'text-green-500',
  en_cours: 'text-amber-500',
  termine: 'text-green-600',
  retard: 'text-red-500',
  bloque: 'text-red-600',
  annule: 'text-muted-foreground line-through',
};

const STATUS_LABELS = {
  a_venir: 'À venir',
  en_preparation: 'En préparation',
  pret: 'Prêt',
  en_cours: 'En cours',
  termine: 'Terminé',
  retard: 'En retard',
  bloque: 'Bloqué',
  annule: 'Annulé',
};

export default function DayCommandCenter() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [project, setProject] = useState(null);
  const [dna, setDna] = useState(null);
  const [timeline, setTimeline] = useState([]);
  const [participants, setParticipants] = useState([]);
  const [documents, setDocuments] = useState([]);
  const [now, setNow] = useState(new Date());

  const loadAll = useCallback(async () => {
    if (!id) return;
    setLoading(true);
    try {
      const me = await base44.auth.me();
      const [projectList, dnaList, tl, parts, docs] = await Promise.all([
        base44.entities.AimeProject.filter({ id, owner_id: me.id }),
        base44.entities.ProjectDNA.filter({ project_id: id, owner_id: me.id }),
        base44.entities.WeddingTimelineItem.filter({ project_id: id, owner_id: me.id }, 'position', 100),
        base44.entities.WeddingParticipant.filter({ project_id: id, owner_id: me.id }),
        base44.entities.ProjectDocument.filter({ project_id: id, owner_id: me.id }),
      ]);
      setProject(projectList[0]);
      setDna(dnaList[0] || null);
      setTimeline(tl.sort((a, b) => (a.position || 0) - (b.position || 0)));
      setParticipants(parts);
      setDocuments(docs);
    } catch (e) {
      console.error(e);
    }
    setLoading(false);
  }, [id]);

  useEffect(() => { loadAll(); }, [loadAll]);
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  const nd = dna ? normalizeDna(dna) : null;
  const projectName = project?.name || nd?.identity?.name || 'Mariage';

  // Determine current and next steps
  const sortedTimeline = [...timeline].sort((a, b) => {
    const ta = a.start_time || '99:99';
    const tb = b.start_time || '99:99';
    return ta.localeCompare(tb);
  });

  const currentStep = sortedTimeline.find((s) => s.status === 'en_cours') || null;
  const nextStep = sortedTimeline.find((s) => s.status === 'a_venir' || s.status === 'pret') || null;
  const blockedSteps = sortedTimeline.filter((s) => s.status === 'bloque' || s.status === 'retard');
  const completedSteps = sortedTimeline.filter((s) => s.status === 'termine');

  // Global state level
  const globalLevel = blockedSteps.length > 0 ? 'urgent' : currentStep ? 'attention' : 'control';
  const levelConfig = {
    control: { label: 'Tout est sous contrôle', color: 'text-green-600', bg: 'bg-green-50', icon: CheckCircle },
    attention: { label: 'Attention nécessaire', color: 'text-amber-600', bg: 'bg-amber-50', icon: AlertTriangle },
    urgent: { label: 'Action urgente', color: 'text-red-600', bg: 'bg-red-50', icon: AlertTriangle },
  };
  const level = levelConfig[globalLevel];
  const LevelIcon = level.icon;

  // Countdown to next step
  const [countdown, setCountdown] = useState('');
  useEffect(() => {
    if (!nextStep?.start_time) { setCountdown('—'); return; }
    const [h, m] = nextStep.start_time.split(':').map(Number);
    const target = new Date();
    target.setHours(h, m, 0, 0);
    const diff = target - now;
    if (diff <= 0) { setCountdown('Maintenant'); return; }
    const hours = Math.floor(diff / 3600000);
    const mins = Math.floor((diff % 3600000) / 60000);
    const secs = Math.floor((diff % 60000) / 1000);
    setCountdown(`${hours > 0 ? hours + 'h ' : ''}${mins}m ${secs}s`);
  }, [now, nextStep]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!project) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-sm font-medium mb-2">Projet introuvable</p>
          <Link to="/aime" className="brand-outline-btn text-xs">Retour</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button onClick={() => navigate(`/aime/project/${id}/wedding`)} className="text-muted-foreground hover:text-foreground transition">
              <ArrowLeft className="w-4 h-4" />
            </button>
            <div>
              <div className="flex items-center gap-2 mb-0.5">
                <Radio className="w-3.5 h-3.5 text-red-500 animate-pulse" />
                <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">JOUR J — Command Center</span>
              </div>
              <h1 className="font-heading text-lg font-medium">{projectName}</h1>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="text-xs text-muted-foreground">Heure actuelle</p>
              <p className="font-heading text-lg font-medium tabular-nums">
                {now.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-6 space-y-6">
        {/* Global state */}
        <div className={`rounded-lg border p-6 ${level.bg} border-border`}>
          <div className="flex items-center gap-4">
            <LevelIcon className={`w-8 h-8 ${level.color}`} strokeWidth={1.5} />
            <div>
              <p className="text-xs uppercase tracking-wider text-muted-foreground mb-1">État global</p>
              <p className={`font-heading text-2xl font-medium ${level.color}`}>{level.label}</p>
            </div>
            <div className="ml-auto flex gap-6 text-sm">
              <div className="text-center">
                <p className="font-heading text-2xl font-medium">{completedSteps.length}</p>
                <p className="text-xs text-muted-foreground">Terminées</p>
              </div>
              <div className="text-center">
                <p className="font-heading text-2xl font-medium">{timeline.length - completedSteps.length}</p>
                <p className="text-xs text-muted-foreground">Restantes</p>
              </div>
              <div className="text-center">
                <p className="font-heading text-2xl font-medium text-red-500">{blockedSteps.length}</p>
                <p className="text-xs text-muted-foreground">Bloquées</p>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Next step + countdown */}
          <div className="lg:col-span-2 space-y-6">
            {/* Next step */}
            <div className="rounded-lg border border-border bg-card p-6">
              <div className="flex items-center gap-2 mb-4">
                <Clock className="w-4 h-4 text-muted-foreground" strokeWidth={1.5} />
                <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Prochaine étape</h3>
              </div>
              {nextStep ? (
                <div>
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h4 className="font-heading text-xl font-medium mb-1">{nextStep.title}</h4>
                      {nextStep.location && <p className="text-sm text-muted-foreground">{nextStep.location}</p>}
                    </div>
                    <div className="text-right">
                      <p className="font-heading text-2xl font-medium tabular-nums">{nextStep.start_time}</p>
                      <p className="text-xs text-muted-foreground">{nextStep.duration_minutes} min</p>
                    </div>
                  </div>
                  <div className="mt-4 pt-4 border-t border-border flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">Compte à rebours</span>
                    <span className="font-heading text-lg font-medium tabular-nums">{countdown}</span>
                  </div>
                  {nextStep.responsible_name && (
                    <div className="mt-3 flex items-center gap-2 text-sm">
                      <Users className="w-3.5 h-3.5 text-muted-foreground" />
                      <span className="text-muted-foreground">Responsable : <span className="font-medium text-foreground">{nextStep.responsible_name}</span></span>
                    </div>
                  )}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground italic">Toutes les étapes sont terminées.</p>
              )}
            </div>

            {/* Timeline */}
            <div className="rounded-lg border border-border bg-background p-6">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-4">Timeline du jour J</h3>
              <div className="space-y-0">
                {sortedTimeline.map((step, i) => (
                  <div key={step.id} className="flex items-start gap-4 group">
                    <div className="flex flex-col items-center">
                      <div className={`w-3 h-3 rounded-full border-2 ${step.status === 'termine' ? 'bg-green-500 border-green-500' : step.status === 'en_cours' ? 'bg-amber-500 border-amber-500' : step.status === 'bloque' || step.status === 'retard' ? 'bg-red-500 border-red-500' : 'border-border'} transition`} />
                      {i < sortedTimeline.length - 1 && <div className="w-px h-10 bg-border" />}
                    </div>
                    <div className="pb-8 flex-1">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className={`text-sm font-medium ${STATUS_COLORS[step.status] || ''}`}>{step.title}</p>
                          {step.responsible_name && <p className="text-xs text-muted-foreground mt-0.5">{step.responsible_name}</p>}
                        </div>
                        <div className="text-right">
                          <p className="text-sm font-heading tabular-nums">{step.start_time}</p>
                          <span className={`text-xs ${STATUS_COLORS[step.status] || 'text-muted-foreground'}`}>{STATUS_LABELS[step.status]}</span>
                        </div>
                      </div>
                      {step.location && <p className="text-xs text-muted-foreground mt-1">{step.location}</p>}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Current step */}
            {currentStep && (
              <div className="rounded-lg border border-amber-200 bg-amber-50 p-5">
                <div className="flex items-center gap-2 mb-3">
                  <Zap className="w-4 h-4 text-amber-600" strokeWidth={1.5} />
                  <h3 className="text-xs font-semibold uppercase tracking-wider text-amber-700">En cours maintenant</h3>
                </div>
                <p className="font-heading text-lg font-medium mb-1">{currentStep.title}</p>
                <p className="text-sm text-amber-700/70">{currentStep.start_time} — {currentStep.duration_minutes} min</p>
              </div>
            )}

            {/* Alerts */}
            {blockedSteps.length > 0 && (
              <div className="rounded-lg border border-red-200 bg-red-50 p-5">
                <div className="flex items-center gap-2 mb-3">
                  <AlertTriangle className="w-4 h-4 text-red-600" strokeWidth={1.5} />
                  <h3 className="text-xs font-semibold uppercase tracking-wider text-red-700">Alertes ({blockedSteps.length})</h3>
                </div>
                <div className="space-y-2">
                  {blockedSteps.map((s) => (
                    <div key={s.id} className="text-sm">
                      <p className="font-medium text-red-700">{s.title}</p>
                      <p className="text-xs text-red-600/70">{STATUS_LABELS[s.status]} — {s.start_time}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Quick contacts */}
            <div className="rounded-lg border border-border bg-card p-5">
              <div className="flex items-center gap-2 mb-3">
                <Phone className="w-4 h-4 text-muted-foreground" strokeWidth={1.5} />
                <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Contacts rapides</h3>
              </div>
              <div className="space-y-2">
                {participants.filter((p) => p.contact_phone).slice(0, 5).map((p) => (
                  <div key={p.id} className="flex items-center justify-between text-sm">
                    <div>
                      <p className="font-medium">{p.display_name}</p>
                      <p className="text-xs text-muted-foreground capitalize">{p.category}</p>
                    </div>
                    <a href={`tel:${p.contact_phone}`} className="text-xs font-mono text-foreground hover:underline">{p.contact_phone}</a>
                  </div>
                ))}
                {participants.filter((p) => p.contact_phone).length === 0 && (
                  <p className="text-xs text-muted-foreground italic">Aucun contact téléphonique.</p>
                )}
              </div>
            </div>

            {/* Documents */}
            <div className="rounded-lg border border-border bg-card p-5">
              <div className="flex items-center gap-2 mb-3">
                <FileText className="w-4 h-4 text-muted-foreground" strokeWidth={1.5} />
                <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Documents ({documents.length})</h3>
              </div>
              <div className="space-y-1.5">
                {documents.slice(0, 5).map((d) => (
                  <div key={d.id} className="flex items-center gap-2 text-sm">
                    <FileText className="w-3 h-3 text-muted-foreground shrink-0" />
                    <span className="truncate flex-1">{d.title}</span>
                    <span className="text-xs text-muted-foreground capitalize">{d.category}</span>
                  </div>
                ))}
                {documents.length === 0 && <p className="text-xs text-muted-foreground italic">Aucun document.</p>}
              </div>
            </div>

            {/* Present vendors */}
            <div className="rounded-lg border border-border bg-card p-5">
              <div className="flex items-center gap-2 mb-3">
                <Users className="w-4 h-4 text-muted-foreground" strokeWidth={1.5} />
                <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Prestataires ({participants.length})</h3>
              </div>
              <div className="space-y-1.5">
                {participants.map((p) => (
                  <div key={p.id} className="flex items-center justify-between text-sm">
                    <span className="truncate">{p.display_name}</span>
                    <span className={`text-xs ${p.status === 'accepted' || p.status === 'active' ? 'text-green-600' : 'text-muted-foreground'}`}>
                      {p.status === 'accepted' ? 'Présent' : p.status === 'active' ? 'Actif' : p.status === 'sent' ? 'Envoyée' : p.status === 'viewed' ? 'Vue' : p.status === 'draft' ? 'Brouillon' : p.status === 'invited' ? 'Invité' : p.status}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}