import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { chatAIME } from "@/lib/aimeAgent";
import { createProjectFromAI } from "@/lib/projectEngine";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Bot, Send, Loader2, ArrowRight, Plus } from "lucide-react";
import { useAI } from "@/components/AIProvider";
import { useAssociation } from "@/components/AssociationProvider";

const SUGGESTIONS = [
  "Je veux organiser un atelier musical pour des enfants et des seniors",
  "Quels documents dois-je préparer pour une demande de financement ?",
  "Aide-moi à structurer la kermesse de l'école"
];

export default function Agent() {
  const [messages, setMessages] = useState([
    { role: "aime", content: "Bonjour, je suis AIME. Décrivez ce que vous voulez mettre en place, et je structure le projet, le calendrier, le budget et les documents avec vous." }
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef(null);
  const navigate = useNavigate();
  const { activeAssociationId } = useAssociation();
  const { aiEnabled } = useAI();

  useEffect(() => {
    scrollRef.current?.scrollTo(0, scrollRef.current.scrollHeight);
  }, [messages, loading]);

  async function send(text) {
    const content = (text || input).trim();
    if (!content || loading) return;
    setInput("");
    const next = [...messages, { role: "user", content }];
    setMessages(next);
    setLoading(true);
    try {
      const reply = await chatAIME(next);
      setMessages([...next, { role: "aime", content: reply }]);
    } catch (e) {
      setMessages([...next, { role: "aime", content: "Désolé, je n'ai pas pu répondre pour le moment. Réessayez." }]);
    }
    setLoading(false);
  }

  async function turnIntoProject(text) {
    setLoading(true);
    try {
      const projectId = await createProjectFromAI(text, activeAssociationId);
      navigate("/projects/" + projectId);
    } catch (e) {
      setMessages((m) => [...m, { role: "aime", content: "Une erreur est survenue. Réessayez." }]);
    }
    setLoading(false);
  }

  const lastUser = [...messages].reverse().find((m) => m.role === "user");

  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 pt-6 lg:pt-10 h-[calc(100vh-7rem)] lg:h-[calc(100vh-5rem)] flex flex-col">
      <div className="flex items-center gap-2 mb-4 shrink-0">
        <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center"><Bot className="w-5 h-5 text-primary" /></div>
        <div>
          <h1 className="font-display text-xl font-semibold">AIME</h1>
          <p className="text-xs text-muted-foreground">Votre intelligence associative</p>
        </div>
      </div>

      {!aiEnabled ? (
        <div className="flex-1 flex flex-col items-center justify-center text-center gap-3">
          <Bot className="w-12 h-12 text-muted-foreground/40" />
          <p className="text-sm text-muted-foreground max-w-xs">L'agent IA est désactivé. Activez l'IA depuis la barre latérale pour converser avec AIME.</p>
        </div>
      ) : (
        <>
          <div ref={scrollRef} className="flex-1 overflow-y-auto space-y-4 pr-1">
        {messages.map((m, i) => (
          <div key={i} className={"flex " + (m.role === "user" ? "justify-end" : "justify-start")}>
            <div className={"max-w-[85%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed " + (m.role === "user" ? "bg-navy text-white/95 rounded-br-sm" : "bg-card border border-border soft-shadow rounded-bl-sm")}>
              {m.content}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="bg-card border border-border soft-shadow rounded-2xl rounded-bl-sm px-4 py-3 flex items-center gap-2 text-muted-foreground">
              <Loader2 className="w-4 h-4 animate-spin" /> AIME réfléchit…
            </div>
          </div>
        )}
        {lastUser && !loading && (
          <div className="flex justify-end">
            <Button size="sm" variant="outline" onClick={() => turnIntoProject(lastUser.content)} className="gap-1.5 rounded-full">
              <Plus className="w-3.5 h-3.5" /> Transformer en projet <ArrowRight className="w-3.5 h-3.5" />
            </Button>
          </div>
        )}
      </div>

      {messages.length <= 1 && (
        <div className="flex flex-wrap gap-2 mb-3 shrink-0">
          {SUGGESTIONS.map((s, i) => (
            <button key={i} onClick={() => send(s)} className="text-xs px-3 py-1.5 rounded-full bg-card border border-border hover:border-primary/40 text-foreground/80 transition">
              {s}
            </button>
          ))}
        </div>
      )}

      <div className="shrink-0 rounded-2xl border border-border bg-card p-2 flex items-end gap-2 soft-shadow">
        <Textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
          placeholder="Parlez à AIME…"
          rows={1}
          className="resize-none bg-transparent border-0 focus-visible:ring-0 min-h-9 max-h-32"
        />
            <Button onClick={() => send()} disabled={!input.trim() || loading} size="icon" className="rounded-xl shrink-0">
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </>
      )}
    </div>
  );
}