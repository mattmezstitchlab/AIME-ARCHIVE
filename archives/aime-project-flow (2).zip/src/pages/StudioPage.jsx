import React, { useEffect, useRef, useState } from "react";
import { useParams } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { BLOCK_TYPES } from "@/lib/studioBlocks";
import { analyzeStudioPrompt, buildStudioFoundation } from "@/lib/studioCreation";
import { toast } from "@/components/ui/use-toast";
import StudioStart from "@/components/studio/StudioStart";
import ArtDirectionFlow from "@/components/studio/ArtDirectionFlow";
import GenerationScreen from "@/components/studio/GenerationScreen";
import ProjectExplorer from "@/components/studio/ProjectExplorer";
import AddSectionDialog from "@/components/studio/AddSectionDialog";
import Canvas from "@/components/studio/Canvas";
import PropertiesPanel from "@/components/studio/PropertiesPanel";
import StudioTopBar from "@/components/studio/StudioTopBar";
import PageSettingsDialog from "@/components/studio/PageSettingsDialog";
import BlockRenderer from "@/components/studio/BlockRenderer";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

export default function StudioPage() {
  const { pageId: urlPageId } = useParams();
  const [user, setUser] = useState(null);
  const [page, setPage] = useState(null);
  const [sections, setSections] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const [phase, setPhase] = useState("start");
  const [draft, setDraft] = useState(null);
  const [device, setDevice] = useState("desktop");
  const [loading, setLoading] = useState(true);
  const [showSettings, setShowSettings] = useState(false);
  const [previewMode, setPreviewMode] = useState(false);
  const [publishing, setPublishing] = useState(false);
  const [dirty, setDirty] = useState(false);
  const [insertAt, setInsertAt] = useState(null);
  const [showAddSection, setShowAddSection] = useState(false);
  const [showPublishConfirm, setShowPublishConfirm] = useState(false);
  const sectionsRef = useRef([]);
  const saveTimers = useRef({});
  const saveAllTimer = useRef(null);

  useEffect(() => { sectionsRef.current = sections; }, [sections]);
  useEffect(() => { (async () => {
    try {
      const me = await base44.auth.me();
      setUser(me);
      // If a pageId is in the URL, load that specific page; otherwise load the most recent
      const filter = urlPageId ? { id: urlPageId, userId: me.id } : { userId: me.id };
      const pages = await base44.entities.PersonalPublicPage.filter(filter, "-updated_date", 1);
      if (pages.length) {
        setPage(pages[0]);
        const items = await base44.entities.PublicPageSection.filter({ pageId: pages[0].id });
        setSections(items.sort((a, b) => (a.position || 0) - (b.position || 0)));
        setPhase("studio");
      }
    } catch (error) { console.error(error); }
    setLoading(false);
  })(); }, [urlPageId]);

  const slugify = value => value.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9-]+/g, "-").replace(/^-+|-+$/g, "");
  const createUniverse = async (projectDraft, design, foundation = []) => {
    const me = user || await base44.auth.me();
    const context = projectDraft?.context || "blank";
    const title = projectDraft?.title || "Nouvel univers";
    const payload = { userId: me.id, username: `${slugify(title)}-${Date.now().toString(36).slice(-5)}`, title, status: "brouillon", template: "vide", pageType: context === "association" ? "association" : context === "artist" ? "person" : "project", projectConfig: { context, prompt: projectDraft?.prompt || "", pageMode: projectDraft?.pageMode || "one", views: projectDraft?.views || ["Page publique"], design: design || {} } };
    if (context === "wedding") payload.projectType = "wedding";
    const createdPage = await base44.entities.PersonalPublicPage.create(payload);
    const records = foundation.length ? await base44.entities.PublicPageSection.bulkCreate(foundation.map(section => ({ ...section, pageId: createdPage.id, userId: me.id }))) : [];
    setPage(createdPage); setSections(records); setSelectedId(records[0]?.id || null); setDirty(false); setPhase("studio");
  };
  const createBlank = async () => {
    setPhase("generating");
    try { await createUniverse({ title: "Nouvel univers", context: "blank", views: ["Page publique"] }, null, []); }
    catch (error) { setPhase("start"); toast({ title: "Création impossible", description: error.message }); }
  };
  const generateUniverse = async design => {
    setPhase("generating");
    try { await createUniverse(draft, design, buildStudioFoundation(draft, design)); }
    catch (error) { setPhase("art"); toast({ title: "Génération impossible", description: error.message }); }
  };

  const saveAllPositions = secs => {
    clearTimeout(saveAllTimer.current);
    saveAllTimer.current = setTimeout(() => base44.entities.PublicPageSection.bulkUpdate(secs.map(section => ({ id: section.id, position: section.position }))), 500);
  };
  const addBlock = async (type, requestedIndex, content = {}, style = {}) => {
    if (!page) return;
    const index = requestedIndex ?? insertAt ?? sections.length;
    const created = await base44.entities.PublicPageSection.create({ pageId: page.id, userId: user.id, type, position: index, content: { ...(BLOCK_TYPES[type]?.defaultProps || {}), ...content }, style, visibility: "public", hidden: false });
    const next = [...sections]; next.splice(index, 0, created); next.forEach((section, position) => { section.position = position; });
    setSections(next); setSelectedId(created.id); setInsertAt(null); setDirty(true); saveAllPositions(next);
  };
  const updateSection = (id, updates) => {
    setSections(previous => previous.map(section => section.id === id ? { ...section, ...updates } : section)); setDirty(true);
    clearTimeout(saveTimers.current[id]);
    saveTimers.current[id] = setTimeout(async () => { const section = sectionsRef.current.find(item => item.id === id); if (section) await base44.entities.PublicPageSection.update(id, { content: section.content, style: section.style, position: section.position, visibility: section.visibility, hidden: section.hidden }); }, 800);
  };
  const deleteSection = async id => {
    await base44.entities.PublicPageSection.delete(id);
    const next = sections.filter(section => section.id !== id); next.forEach((section, position) => { section.position = position; }); setSections(next); if (selectedId === id) setSelectedId(null); setDirty(true); saveAllPositions(next);
  };
  const duplicateSection = async id => {
    const source = sections.find(section => section.id === id); if (!source) return;
    const index = sections.findIndex(section => section.id === id) + 1;
    const created = await base44.entities.PublicPageSection.create({ pageId: page.id, userId: user.id, type: source.type, position: index, content: { ...source.content }, style: { ...source.style }, visibility: source.visibility, hidden: source.hidden });
    const next = [...sections]; next.splice(index, 0, created); next.forEach((section, position) => { section.position = position; }); setSections(next); setSelectedId(created.id); setDirty(true); saveAllPositions(next);
  };
  const toggleHidden = id => { const section = sections.find(item => item.id === id); if (section) updateSection(id, { hidden: !section.hidden }); };
  const reorder = (sourceIndex, destinationIndex) => { const next = [...sections]; const [moved] = next.splice(sourceIndex, 1); next.splice(destinationIndex, 0, moved); next.forEach((section, position) => { section.position = position; }); setSections(next); setDirty(true); saveAllPositions(next); };
  const savePageSettings = async data => { const updated = await base44.entities.PersonalPublicPage.update(page.id, { ...data, username: slugify(data.username || "") }); setPage(updated); };
  const publishPage = async () => {
    setShowPublishConfirm(false);
    setPublishing(true);
    try { Object.values(saveTimers.current).forEach(clearTimeout); await base44.entities.PublicPageSection.bulkUpdate(sectionsRef.current.map(section => ({ id: section.id, content: section.content, style: section.style, position: section.position, visibility: section.visibility, hidden: section.hidden }))); const updated = await base44.entities.PersonalPublicPage.update(page.id, { status: "publie", publishedAt: new Date().toISOString() }); setPage(updated); setDirty(false); toast({ title: "Page publiée", description: `Accessible sur /@${page.username}` }); }
    catch (error) { toast({ title: "Publication impossible", description: error.message }); }
    setPublishing(false);
  };
  const unpublishPage = async () => {
    setPublishing(true);
    try { const updated = await base44.entities.PersonalPublicPage.update(page.id, { status: "brouillon" }); setPage(updated); toast({ title: "Page dépubliée", description: "La page n'est plus accessible publiquement." }); }
    catch (error) { toast({ title: "Dépublication impossible", description: error.message }); }
    setPublishing(false);
  };

  if (loading) return <div className="fixed inset-0 flex items-center justify-center"><div className="h-8 w-8 animate-spin rounded-full border-4 border-muted border-t-foreground" /></div>;
  if (phase === "start") return <StudioStart hasExisting={!!page} onResume={() => setPhase("studio")} onBlank={createBlank} onAime={prompt => { setDraft(analyzeStudioPrompt(prompt)); setPhase("art"); }} />;
  if (phase === "art") return <ArtDirectionFlow draft={draft} onBack={() => setPhase("start")} onComplete={generateUniverse} />;
  if (phase === "generating") return <GenerationScreen label={draft ? "AIME construit votre univers" : "Préparation de votre canvas"} />;
  const selectedSection = sections.find(section => section.id === selectedId);

  return <div className="fixed inset-0 flex flex-col bg-background">
    <StudioTopBar page={page} dirty={dirty} device={device} setDevice={setDevice} onPreview={() => setPreviewMode(true)} onExitPreview={() => setPreviewMode(false)} onSettings={() => setShowSettings(true)} onPublish={() => setShowPublishConfirm(true)} onUnpublish={unpublishPage} publishing={publishing} previewMode={previewMode} />
    {previewMode ? <div className="flex-1 overflow-y-auto bg-muted/30 p-4 lg:p-8"><div className="mx-auto max-w-4xl bg-card shadow-sm">{sections.filter(section => !section.hidden && section.visibility !== "private").map(section => <BlockRenderer key={section.id} section={section} isEditing={false} />)}</div></div> : <div className="flex flex-1 overflow-hidden">
      <ProjectExplorer page={page} sections={sections} selectedId={selectedId} onSelect={setSelectedId} onReorder={reorder} onDuplicate={duplicateSection} onToggleHidden={toggleHidden} onAdd={() => { setInsertAt(sections.length); setShowAddSection(true); }} onSettings={() => setShowSettings(true)} />
      <Canvas sections={sections} selectedId={selectedId} onSelect={setSelectedId} onReorder={reorder} onDuplicate={duplicateSection} onDelete={deleteSection} onToggleHidden={toggleHidden} onAddAt={index => { setInsertAt(index); setShowAddSection(true); }} device={device} />
      <PropertiesPanel section={selectedSection} onUpdate={updates => updateSection(selectedId, updates)} onDelete={() => deleteSection(selectedId)} />
    </div>}
    <AddSectionDialog open={showAddSection} onClose={() => setShowAddSection(false)} page={page} sections={sections} initialIndex={insertAt} onCreate={addBlock} />
    <PageSettingsDialog page={page} open={showSettings} onClose={() => setShowSettings(false)} onSave={savePageSettings} />
    <Dialog open={showPublishConfirm} onOpenChange={setShowPublishConfirm}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle>Publier la page</DialogTitle>
          <DialogDescription>
            Votre page sera accessible publiquement sur <span className="font-medium">/@{page?.username}</span>.
            Vous pourrez la dépublier à tout moment.
          </DialogDescription>
        </DialogHeader>
        <DialogFooter>
          <Button variant="outline" onClick={() => setShowPublishConfirm(false)}>Annuler</Button>
          <Button onClick={publishPage} disabled={publishing}>{publishing ? "Publication..." : "Publier"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  </div>;
}