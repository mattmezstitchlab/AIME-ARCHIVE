import LandingNav from '@/components/landing/LandingNav';
import LandingFooter from '@/components/landing/LandingFooter';
import PageHero from '@/components/landing/PageHero';
import { motion } from 'framer-motion';

export default function About() {
  return (
    <div className="min-h-screen bg-background">
      <LandingNav />
      <PageHero
        image="https://media.base44.com/images/public/6a6e080d1aca70178ff1340c/97fda9c52_generated_image.png"
        badge="À propos"
        title="Déposez ce que vous avez. AIME organise le reste."
        subtitle="L'IA comprend et organise, vous choisissez et décidez."
        focalPointY={0.5}
      />
      <section className="pt-20 pb-24 px-6">
        <div className="max-w-3xl mx-auto">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <div className="prose prose-lg max-w-none space-y-6 text-muted-foreground leading-relaxed">
              <p>
                AIME est né d'une conviction simple : un projet humain existe déjà avant d'être organisé. Il vit dans des idées, des photos, des documents, des messages et des souvenirs.
              </p>
              <p>
                Plutôt que de demander aux gens de remplir des formulaires, AIME part de ce qu'ils ont déjà. L'intelligence observe, structure et révèle ce qui peut venir ensuite. La décision reste humaine.
              </p>
              <p>
                Cette philosophie s'appelle <strong>AI + ME</strong> : l'IA comprend et organise, l'humain choisit et décide.
              </p>
              <p>
                AIME est un produit de <strong>LE MONDE AIME</strong>.
              </p>
            </div>
          </motion.div>
        </div>
      </section>
      <LandingFooter />
    </div>
  );
}