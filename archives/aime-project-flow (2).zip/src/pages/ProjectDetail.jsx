import { useEffect, useState } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { STATUS_PROJET, ROLE_LABELS, DOC_TYPES, formatDate, euro } from "@/lib/aimeFormats";
import { logAction, generateDocument } from "@/lib/aimeAgent";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem
} from "@/components/ui/select";

import { useToast } from "@/components/ui/use-toast";
import BudgetTab from "@/components/project/BudgetTab";
import JustificatifsTab from "@/components/project/JustificatifsTab";
import CommunicationTab from "@/components/project/CommunicationTab";
import { exportDocumentPDF } from "@/lib/pdfExport";
import { createDocument, generateDocumentContent, gatherContext, downloadDocumentPDF } from "@/lib/documentEngine";
import EmptyState from "@/components/EmptyState";
import {
  Compass, Users, CalendarClock, Wallet, Handshake, FileText, Megaphone,
  ScanLine, ClipboardCheck, Archive, Loader2, Plus, Check, ArrowLeft, AlertCircle,
  History, Wand2, Download, Trash2
} from "lucide-react";
import { useAssociation } from "@/components/AssociationProvider";
import { useProjectNav } from "@/components/ProjectNavContext";
import { useAI } from "@/components/AIProvider";
import {
  AlertDialog, AlertDialogContent, AlertDialogHeader, AlertDialogTitle,
  AlertDialogAction, AlertDialogCancel, AlertDialogFooter, AlertDialogDescription
} from "@/components/ui/alert-dialog";
import { countProjectRelations, archiveProject, deleteProject } from "@/lib/projectEngine";

const SECTIONS = [
  { id: "vision", label: "01 — Vision", icon: Compass },
  { id: "equipe", label: "02 — Équipe", icon: Users },
  { id: "planning", label: "03 — Planning", icon: CalendarClock },
  { id: "budget", label: "04 — Budget", icon: Wallet },
  { id: "partenaires", label: "05 — Partenaires", icon: Handshake },
  { id: "documents", label: "06 — Documents", icon: FileText },
  { id: "communication", label: "07 — Communication", icon: Megaphone },
  { id: "justificatifs", label: "08 — Justificatifs", icon: ScanLine },
  { id: "bilan", label: "09 — Bilan", icon: ClipboardCheck },
  { id: "archives", label: "10 — Archives", icon: Archive }
];

export default function ProjectDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [project, setProject] = useState(null);
  const [loading, setLoading] = useState(true);
  const [tasks, setTasks] = useState([]);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [relations, setRelations] = useState(null);
  const [deleteMode, setDeleteMode] = useState(null);
  const [deleting, setDeleting] = useState(false);
  const { register, clear, active, setActive } = useProjectNav();

  async function load() {
    setLoading(true);
    try {
      const p = await base44.entities.Projet.get(id);
      const t = await base44.entities.Tache.filter({ project_id: id });
      setTasks(t);
      const done = t.filter((task) => task.status === "fait").length;
      const pct = t.length > 0 ? Math.round((done / t.length) * 100) : 0;
      if (p.completion_pct !== pct) {
        await base44.entities.Projet.update(id, { completion_pct: pct });
        p.completion_pct = pct;
      }
      setProject(p);
    } catch (e) { console.error(e); }
    setLoading(false);
  }
  useEffect(() => { load(); }, [id]);

  async function openDeleteDialog() {
    const counts = await countProjectRelations(id);
    setRelations(counts);
    setDeleteMode("archive");
    setDeleteOpen(true);
  }

  async function confirmDelete() {
    setDeleting(true);
    try {
      if (deleteMode === "archive") {
        await archiveProject(id);
        toast({ title: "Projet archivé" });
      } else {
        await deleteProject(id);
        toast({ title: "Projet supprimé" });
      }
      setDeleteOpen(false);
      navigate("/projects");
    } catch (e) { toast({ title: "Erreur", variant: "destructive" }); }
    setDeleting(false);
  }
  useEffect(() => {
    if (project) register(project.name, SECTIONS, "vision");
    return () => clear();
  }, [project?.id]);

  if (loading) return <div className="flex justify-center pt-24"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>;
  if (!project) return (
    <div className="max-w-3xl mx-auto px-6 pt-20">
      <EmptyState icon={AlertCircle} title="Projet introuvable" description="Ce projet n'existe pas ou a été supprimé." action={<Button asChild><Link to="/projects">Retour aux projets</Link></Button>} />
    </div>
  );

  const status = STATUS_PROJET[project.status] || STATUS_PROJET.idee;

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-10 pt-8 lg:pt-10">
      <button onClick={() => navigate(-1)} className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground mb-4">
        <ArrowLeft className="w-4 h-4" /> Retour
      </button>

      <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3 mb-1">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="w-3 h-3 rounded-full" style={{ backgroundColor: project.color || "#1A2744" }} />
            <Badge className={status.color + " border-0 font-normal"}>{status.label}</Badge>
          </div>
          <h1 className="font-display text-2xl sm:text-3xl font-semibold">{project.name}</h1>
          {project.description && <p className="text-muted-foreground mt-2 max-w-2xl">{project.description}</p>}
        </div>
        <div className="flex flex-col gap-2 items-end">
          <div className="bg-card border border-border rounded-xl px-4 py-3 soft-shadow text-center min-w-32">
            <p className="font-display text-2xl font-semibold text-navy">{project.completion_pct || 0}%</p>
            <p className="text-[10px] uppercase tracking-wide text-muted-foreground">avancement</p>
            <Progress value={project.completion_pct || 0} className="h-1.5 mt-2" />
          </div>
          <Button variant="ghost" size="sm" onClick={openDeleteDialog} className="text-muted-foreground hover:text-destructive gap-1.5 text-xs">
            <Trash2 className="w-3.5 h-3.5" /> Supprimer ou archiver
          </Button>
        </div>
      </div>

      {project.missing_fields?.length > 0 && (
        <div className="mt-4 rounded-xl bg-primary/8 border border-primary/20 p-4 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-primary shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-medium text-primary">AIME a besoin de quelques précisions</p>
            <ul className="text-sm text-foreground/80 mt-1.5 list-disc ml-5 space-y-0.5">
              {project.missing_fields.map((m, i) => <li key={i}>{m}</li>)}
            </ul>
          </div>
        </div>
      )}

      <div className="lg:hidden mt-4">
        <Select value={active} onValueChange={setActive}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>
            {SECTIONS.map((s) => <SelectItem key={s.id} value={s.id}>{s.label}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <div className="mt-6">
        {active === "vision" && <VisionTab project={project} onChange={load} />}
        {active === "equipe" && <EquipeTab project={project} />}
        {active === "planning" && <PlanningTab project={project} tasks={tasks} onChange={load} />}
        {active === "budget" && <BudgetTab projectId={id} />}
        {active === "partenaires" && <PartenairesTab project={project} />}
        {active === "documents" && <DocumentsTab project={project} />}
        {active === "communication" && <CommunicationTab project={project} />}
        {active === "justificatifs" && <JustificatifsTab projectId={id} />}
        {active === "bilan" && <BilanTab project={project} />}
        {active === "archives" && <ArchivesTab projectId={id} />}
      </div>

      <AlertDialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{deleteMode === "archive" ? "Archiver le projet" : "Supprimer définitivement"}</AlertDialogTitle>
            <AlertDialogDescription>
              {deleteMode === "archive"
                ? "Le projet sera archivé et pourra être restauré à tout moment."
                : "Cette action est définitive. Toutes les données liées seront supprimées."}
            </AlertDialogDescription>
          </AlertDialogHeader>
          {relations && (
            <div className="rounded-lg border border-border bg-muted/30 p-3 text-sm space-y-1">
              <p className="font-medium">Données liées à ce projet :</p>
              <ul className="text-muted-foreground space-y-0.5">
                {relations.tasks > 0 && <li>{relations.tasks} tâche(s)</li>}
                {relations.budgetLines > 0 && <li>{relations.budgetLines} ligne(s) budgétaire(s)</li>}
                {relations.depenses > 0 && <li>{relations.depenses} dépense(s)</li>}
                {relations.documents > 0 && <li>{relations.documents} document(s)</li>}
                {relations.justificatifs > 0 && <li>{relations.justificatifs} justificatif(s)</li>}
                {relations.evenements > 0 && <li>{relations.evenements} événement(s)</li>}
                {relations.bilans > 0 && <li>{relations.bilans} bilan(s)</li>}
                {relations.reunions > 0 && <li>{relations.reunions} réunion(s)</li>}
                {relations.tasks + relations.budgetLines + relations.depenses + relations.documents + relations.justificatifs + relations.evenements + relations.bilans + relations.reunions === 0 && <li>Aucune donnée liée</li>}
              </ul>
            </div>
          )}
          <div className="flex gap-2">
            <Button size="sm" variant={deleteMode === "archive" ? "default" : "outline"} onClick={() => setDeleteMode("archive")} className="gap-1.5">
              <Archive className="w-3.5 h-3.5" /> Archiver (recommandé)
            </Button>
            <Button size="sm" variant={deleteMode === "delete" ? "destructive" : "outline"} onClick={() => setDeleteMode("delete")} className="gap-1.5">
              <Trash2 className="w-3.5 h-3.5" /> Supprimer définitivement
            </Button>
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel>Annuler</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              disabled={deleting}
              className={deleteMode === "delete" ? "bg-destructive text-destructive-foreground hover:bg-destructive/90" : ""}
            >
              {deleting ? <Loader2 className="w-4 h-4 animate-spin" /> : deleteMode === "archive" ? "Archiver" : "Supprimer définitivement"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function VisionTab({ project, onChange }) {
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({ vision: project.vision || "", target_audience: project.target_audience || "", location: project.location || "", start_date: project.start_date || "", end_date: project.end_date || "" });
  const { toast } = useToast();

  async function save() {
    await base44.entities.Projet.update(project.id, form);
    setEditing(false);
    toast({ title: "Vision mise à jour" });
    onChange();
  }

  const objectives = project.metadata?.objectives || [];

  return (
    <div className="space-y-5">
      <Card className="soft-shadow">
        <CardContent className="p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-display text-lg font-medium flex items-center gap-2"><Compass className="w-4 h-4 text-primary" /> Vision</h3>
            <Button variant="ghost" size="sm" onClick={() => setEditing(!editing)}>{editing ? "Annuler" : "Modifier"}</Button>
          </div>
          {editing ? (
            <Textarea value={form.vision} onChange={(e) => setForm({ ...form, vision: e.target.value })} rows={3} />
          ) : (
            <p className="text-foreground/90 leading-relaxed">{project.vision || "La vision n'est pas encore définie. Cliquez sur Modifier pour l'ajouter."}</p>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
            {[
              { k: "target_audience", label: "Public visé" },
              { k: "location", label: "Lieu" },
              { k: "start_date", label: "Début", date: true }
            ].map((f) => (
              <div key={f.k}>
                <Label className="text-xs text-muted-foreground">{f.label}</Label>
                {editing && f.k !== "start_date" ? (
                  <Input value={form[f.k]} onChange={(e) => setForm({ ...form, [f.k]: e.target.value })} />
                ) : editing ? (
                  <Input type="date" value={form[f.k]} onChange={(e) => setForm({ ...form, [f.k]: e.target.value })} />
                ) : (
                  <p className="text-sm font-medium">{f.date ? formatDate(project[f.k]) : (project[f.k] || "—")}</p>
                )}
              </div>
            ))}
          </div>
          {editing && <Button size="sm" onClick={save}>Enregistrer</Button>}
        </CardContent>
      </Card>

      {objectives.length > 0 && (
        <Card className="soft-shadow">
          <CardContent className="p-5">
            <h3 className="font-display text-base font-medium mb-3">Objectifs proposés par AIME</h3>
            <ul className="space-y-2">
              {objectives.map((o, i) => (
                <li key={i} className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-sage/15 text-sage flex items-center justify-center text-xs font-semibold shrink-0 mt-0.5">{i + 1}</span>
                  <span className="text-sm">{o}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}

      {(project.metadata?.next_actions || []).length > 0 && (
        <Card className="soft-shadow border-l-4 border-l-sage">
          <CardContent className="p-5">
            <h3 className="font-display text-base font-medium mb-3">Prochaines actions suggérées</h3>
            <ul className="space-y-2">
              {project.metadata.next_actions.map((a, i) => (
                <li key={i} className="text-sm flex items-start gap-2"><span className="text-sage mt-0.5">→</span>{a}</li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function EquipeTab({ project }) {
  const [membres, setMembres] = useState([]);
  const [adding, setAdding] = useState(false);
  const { toast } = useToast();

  async function load() {
    const all = await base44.entities.Membre.list();
    setMembres(all);
  }
  useEffect(() => { load(); }, []);

  const projectMembers = membres.filter((m) => (m.project_ids || []).includes(project.id));
  const availableMembers = membres.filter((m) => !(m.project_ids || []).includes(project.id));

  async function addToProject(m) {
    const ids = [...(m.project_ids || []), project.id];
    await base44.entities.Membre.update(m.id, { project_ids: ids });
    load();
    toast({ title: "Membre ajouté au projet" });
  }

  async function removeFromProject(m) {
    const ids = (m.project_ids || []).filter((pid) => pid !== project.id);
    await base44.entities.Membre.update(m.id, { project_ids: ids });
    load();
    toast({ title: "Membre retiré du projet" });
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <p className="text-sm text-muted-foreground">{projectMembers.length} membre(s) sur ce projet</p>
        <Button size="sm" variant="outline" onClick={() => setAdding(!adding)} className="gap-1.5"><Plus className="w-4 h-4" /> Ajouter</Button>
      </div>

      {adding && availableMembers.length > 0 && (
        <Card className="soft-shadow mb-3">
          <CardContent className="p-3 space-y-2">
            <p className="text-xs text-muted-foreground">Membres disponibles</p>
            {availableMembers.map((m) => (
              <div key={m.id} className="flex items-center justify-between rounded-lg border border-border px-3 py-2">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-full bg-navy/10 text-navy flex items-center justify-center text-xs font-semibold">{m.full_name?.[0]?.toUpperCase()}</div>
                  <div>
                    <p className="text-sm font-medium">{m.full_name}</p>
                    <p className="text-xs text-muted-foreground">{ROLE_LABELS[m.role] || m.role}</p>
                  </div>
                </div>
                <Button size="sm" variant="ghost" onClick={() => addToProject(m)}>Ajouter</Button>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {projectMembers.length === 0 ? (
        <EmptyState icon={Users} title="Équipe non définie" description="Ajoutez des membres de l'association à ce projet." />
      ) : (
        <div className="space-y-2">
          {projectMembers.map((m) => (
            <div key={m.id} className="flex items-center gap-3 rounded-lg border border-border bg-card px-4 py-3">
              <div className="w-9 h-9 rounded-full bg-navy/10 text-navy flex items-center justify-center font-semibold text-sm">
                {m.full_name?.[0]?.toUpperCase()}
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium">{m.full_name}</p>
                <p className="text-xs text-muted-foreground">{m.email}</p>
              </div>
              <Badge variant="outline" className="font-normal">{ROLE_LABELS[m.role] || m.role}</Badge>
              <button onClick={() => removeFromProject(m)} className="text-muted-foreground/40 hover:text-destructive text-xs">retirer</button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function PlanningTab({ project, tasks, onChange }) {
  const [adding, setAdding] = useState(false);
  const [form, setForm] = useState({ title: "", priority: "moyenne" });
  const { toast } = useToast();
  const { activeAssociationId } = useAssociation();
  const order = { a_faire: 0, en_cours: 1, bloque: 3, fait: 4 };

  async function addTask() {
    if (!form.title.trim()) return;
    await base44.entities.Tache.create({ project_id: project.id, association_id: activeAssociationId, title: form.title, priority: form.priority, status: "a_faire" });
    setForm({ title: "", priority: "moyenne" });
    setAdding(false);
    toast({ title: "Tâche ajoutée" });
    onChange();
  }

  async function toggle(task) {
    const next = task.status === "fait" ? "a_faire" : "fait";
    await base44.entities.Tache.update(task.id, { status: next });
    onChange();
  }

  async function remove(task) {
    await base44.entities.Tache.delete(task.id);
    onChange();
  }

  const sorted = [...tasks].sort((a, b) => (order[a.status] ?? 2) - (order[b.status] ?? 2));

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <p className="text-sm text-muted-foreground">{tasks.length} tâche{tasks.length > 1 ? "s" : ""}</p>
        <Button size="sm" variant="outline" onClick={() => setAdding(!adding)} className="gap-1.5"><Plus className="w-4 h-4" /> Ajouter</Button>
      </div>

      {adding && (
        <Card className="soft-shadow mb-3">
          <CardContent className="p-4 space-y-3">
            <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Titre de la tâche" />
            <div className="flex gap-2 items-center">
              <Select value={form.priority} onValueChange={(v) => setForm({ ...form, priority: v })}>
                <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="basse">Priorité basse</SelectItem>
                  <SelectItem value="moyenne">Priorité moyenne</SelectItem>
                  <SelectItem value="haute">Priorité haute</SelectItem>
                </SelectContent>
              </Select>
              <Button size="sm" onClick={addTask}>Ajouter</Button>
              <Button size="sm" variant="ghost" onClick={() => setAdding(false)}>Annuler</Button>
            </div>
          </CardContent>
        </Card>
      )}

      {tasks.length === 0 ? (
        <EmptyState icon={CalendarClock} title="Planning à construire" description="AIME a suggéré des tâches lors de la création, ou ajoutez les vôtres." />
      ) : (
        <div className="space-y-2">
          {sorted.map((t) => (
            <div key={t.id} className="flex items-center gap-3 rounded-lg border border-border bg-card px-4 py-3 hover:border-primary/30 transition">
              <button
                onClick={() => toggle(t)}
                className={"w-5 h-5 rounded-md border-2 flex items-center justify-center shrink-0 transition " + (t.status === "fait" ? "bg-sage border-sage text-sage-foreground" : "border-border")}
              >
                {t.status === "fait" && <Check className="w-3 h-3" />}
              </button>
              <div className="flex-1 min-w-0">
                <p className={"text-sm " + (t.status === "fait" ? "line-through text-muted-foreground" : "")}>{t.title}</p>
                {t.due_date && <p className="text-xs text-muted-foreground">Échéance : {formatDate(t.due_date)}</p>}
              </div>
              {t.priority === "haute" && <Badge className="bg-primary/10 text-primary border-0">Haute</Badge>}
              <button onClick={() => remove(t)} className="text-muted-foreground/40 hover:text-destructive text-xs">retirer</button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function PartenairesTab({ project }) {
  const [partenaires, setPartenaires] = useState([]);
  const [adding, setAdding] = useState(false);
  const { toast } = useToast();

  async function load() {
    base44.entities.Partenaire.list().then(setPartenaires).catch(() => {});
  }
  useEffect(() => { load(); }, []);

  const projectPartners = partenaires.filter((p) => (p.project_ids || []).includes(project.id));
  const availablePartners = partenaires.filter((p) => !(p.project_ids || []).includes(project.id));
  const types = project.metadata?.potential_partners || [];

  async function addToProject(p) {
    const ids = [...(p.project_ids || []), project.id];
    await base44.entities.Partenaire.update(p.id, { project_ids: ids });
    load();
    toast({ title: "Partenaire ajouté au projet" });
  }

  async function removeFromProject(p) {
    const ids = (p.project_ids || []).filter((pid) => pid !== project.id);
    await base44.entities.Partenaire.update(p.id, { project_ids: ids });
    load();
    toast({ title: "Partenaire retiré du projet" });
  }

  return (
    <div className="space-y-4">
      {types.length > 0 && (
        <Card className="soft-shadow border-l-4 border-l-navy">
          <CardContent className="p-4">
            <p className="text-xs text-muted-foreground uppercase tracking-wide mb-2">Suggestions AIME</p>
            <div className="flex flex-wrap gap-2">
              {types.map((t, i) => <Badge key={i} variant="outline" className="font-normal">{t}</Badge>)}
            </div>
          </CardContent>
        </Card>
      )}

      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">{projectPartners.length} partenaire(s) sur ce projet</p>
        <Button size="sm" variant="outline" onClick={() => setAdding(!adding)} className="gap-1.5"><Plus className="w-4 h-4" /> Ajouter</Button>
      </div>

      {adding && availablePartners.length > 0 && (
        <Card className="soft-shadow">
          <CardContent className="p-3 space-y-2">
            <p className="text-xs text-muted-foreground">Partenaires disponibles</p>
            {availablePartners.map((p) => (
              <div key={p.id} className="flex items-center justify-between rounded-lg border border-border px-3 py-2">
                <div>
                  <p className="text-sm font-medium">{p.name}</p>
                  <p className="text-xs text-muted-foreground">{p.contact_name || p.email || "—"}</p>
                </div>
                <Button size="sm" variant="ghost" onClick={() => addToProject(p)}>Ajouter</Button>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {projectPartners.length === 0 ? (
        <EmptyState icon={Handshake} title="Aucun partenaire" description="Ajoutez vos financeurs et partenaires depuis l'espace dédié." action={<Button asChild variant="outline" size="sm"><Link to="/partenaires">Gérer les partenaires</Link></Button>} />
      ) : (
        <div className="space-y-2">
          {projectPartners.map((p) => (
            <div key={p.id} className="flex items-center justify-between rounded-lg border border-border bg-card px-4 py-3">
              <div><p className="text-sm font-medium">{p.name}</p><p className="text-xs text-muted-foreground">{p.contact_name || p.email || "—"}</p></div>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="font-normal capitalize">{p.type}</Badge>
                <button onClick={() => removeFromProject(p)} className="text-muted-foreground/40 hover:text-destructive text-xs">retirer</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function DocumentsTab({ project }) {
  const [docs, setDocs] = useState([]);
  const [loading, setLoading] = useState(false);
  const [genType, setGenType] = useState("fiche_projet");
  const [viewDoc, setViewDoc] = useState(null);
  const [manualOpen, setManualOpen] = useState(false);
  const [manual, setManual] = useState({ title: "", content: "", type: "fiche_projet" });
  const { toast } = useToast();
  const { activeAssociationId } = useAssociation();
  const { aiEnabled } = useAI();

  async function load() { setDocs(await base44.entities.Document.filter({ project_id: project.id })); }
  useEffect(() => { load(); }, [project.id]);

  async function createManual() {
    if (!manual.title.trim()) return;
    try {
      await createDocument({ type: manual.type, title: manual.title, content: manual.content, projectId: project.id, associationId: activeAssociationId });
      setManual({ title: "", content: "", type: "fiche_projet" });
      setManualOpen(false);
      toast({ title: "Document créé" });
      load();
    } catch (e) { toast({ title: "Erreur", variant: "destructive" }); }
  }

  async function generate() {
    setLoading(true);
    try {
      const tempDoc = { type: genType, title: DOC_TYPES[genType], association_id: activeAssociationId, project_id: project.id };
      const context = await gatherContext(tempDoc);
      const res = await generateDocumentContent(tempDoc, context);
      await createDocument({ type: genType, title: res.title || DOC_TYPES[genType], content: res.content || "", projectId: project.id, associationId: activeAssociationId });
      toast({ title: "Document généré" });
      load();
    } catch (e) { toast({ title: "Erreur de génération", variant: "destructive" }); }
    setLoading(false);
  }

  return (
    <div className="space-y-4">
      {aiEnabled && (
        <div className="rounded-xl bg-primary/8 border border-primary/20 p-4 flex items-start gap-3">
          <Wand2 className="w-5 h-5 text-primary shrink-0 mt-0.5" />
          <p className="text-sm">Document généré avec AIME. Vérifiez et validez les informations avant utilisation.</p>
        </div>
      )}

      <Card className="soft-shadow">
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-3">
            <p className="text-sm font-medium">{aiEnabled ? "Générer un document" : "Créer un document"}</p>
            <Button size="sm" variant="outline" onClick={() => setManualOpen(!manualOpen)} className="gap-1.5"><FileText className="w-3.5 h-3.5" /> Créer manuellement</Button>
          </div>
          {aiEnabled && (
            <div className="flex flex-col sm:flex-row gap-2">
              <Select value={genType} onValueChange={setGenType}>
                <SelectTrigger className="flex-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(DOC_TYPES).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
                </SelectContent>
              </Select>
              <Button onClick={generate} disabled={loading} className="gap-2">
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Wand2 className="w-4 h-4" />}
                Générer avec AIME
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {manualOpen && (
        <Card className="soft-shadow animate-float-up">
          <CardContent className="p-4 space-y-3">
            <p className="text-sm font-medium">Nouveau document</p>
            <div>
              <Label className="text-xs">Titre</Label>
              <Input value={manual.title} onChange={(e) => setManual({ ...manual, title: e.target.value })} placeholder="Ex. Convention de partenariat" className="mt-1" />
            </div>
            <div>
              <Label className="text-xs">Type</Label>
              <Select value={manual.type} onValueChange={(v) => setManual({ ...manual, type: v })}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(DOC_TYPES).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Contenu</Label>
              <Textarea value={manual.content} onChange={(e) => setManual({ ...manual, content: e.target.value })} rows={8} placeholder="Rédigez le contenu du document…" className="mt-1" />
            </div>
            <div className="flex gap-2">
              <Button size="sm" onClick={createManual} disabled={!manual.title.trim()}>Enregistrer</Button>
              <Button size="sm" variant="ghost" onClick={() => setManualOpen(false)}>Annuler</Button>
            </div>
          </CardContent>
        </Card>
      )}

      {docs.length === 0 ? (
        <EmptyState icon={FileText} title="Aucun document" description={aiEnabled ? "Choisissez un type ci-dessus, AIME le pré-remplit avec les données du projet." : "Cliquez sur « Créer manuellement » pour rédiger un document."} />
      ) : (
        <div className="space-y-2">
          {docs.map((d) => (
            <button key={d.id} onClick={() => setViewDoc(d)} className="w-full text-left flex items-center gap-3 rounded-lg border border-border bg-card px-4 py-3 hover:border-primary/30 transition">
              <FileText className="w-4 h-4 text-primary" />
              <div className="flex-1">
                <p className="text-sm font-medium">{d.title}</p>
                <p className="text-xs text-muted-foreground">v{d.version} · {DOC_TYPES[d.type]}</p>
              </div>
              <Badge variant="outline" className="font-normal">{d.status}</Badge>
            </button>
          ))}
        </div>
      )}

      {viewDoc && (
        <div className="fixed inset-0 bg-navy/40 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={() => setViewDoc(null)}>
          <div className="bg-card rounded-2xl max-w-2xl w-full max-h-[80vh] overflow-y-auto soft-shadow p-6" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display text-xl font-medium">{viewDoc.title}</h3>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={async () => { const ctx = await gatherContext({ ...viewDoc, association_id: activeAssociationId, project_id: project.id }); downloadDocumentPDF(viewDoc, ctx); load(); }} className="gap-1.5">
                  <Download className="w-3.5 h-3.5" /> PDF
                </Button>
                <Button variant="ghost" size="sm" onClick={() => setViewDoc(null)}>Fermer</Button>
              </div>
            </div>
            <div className="whitespace-pre-wrap text-sm leading-relaxed text-foreground/90">{viewDoc.content}</div>
          </div>
        </div>
      )}
    </div>
  );
}

function BilanTab({ project }) {
  const [bilan, setBilan] = useState(null);
  const [loading, setLoading] = useState(false);
  const [manualOpen, setManualOpen] = useState(false);
  const [manualContent, setManualContent] = useState("");
  const { toast } = useToast();
  const { activeAssociationId } = useAssociation();
  const { aiEnabled } = useAI();

  async function load() {
    const b = await base44.entities.Bilan.filter({ project_id: project.id });
    setBilan(b[0] || null);
  }
  useEffect(() => { load(); }, [project.id]);

  async function generate() {
    setLoading(true);
    try {
      const res = await generateDocument(project, "bilan_activite");
      await base44.entities.Bilan.create({ project_id: project.id, association_id: activeAssociationId, type: "activite", content: res.content || "", status: "brouillon" });
      await logAction("generation_bilan", "Bilan", null, project.id, "Bilan généré par AIME.");
      toast({ title: "Bilan généré" });
      load();
    } catch (e) { toast({ title: "Erreur", variant: "destructive" }); }
    setLoading(false);
  }

  async function createManualBilan() {
    if (!manualContent.trim()) return;
    setLoading(true);
    try {
      await base44.entities.Bilan.create({ project_id: project.id, association_id: activeAssociationId, type: "activite", content: manualContent, status: "brouillon" });
      await logAction("creation_bilan", "Bilan", null, project.id, "Bilan rédigé manuellement.");
      setManualContent("");
      setManualOpen(false);
      toast({ title: "Bilan créé" });
      load();
    } catch (e) { toast({ title: "Erreur", variant: "destructive" }); }
    setLoading(false);
  }

  return (
    <div className="space-y-4">
      {!bilan ? (
        <>
          <EmptyState
            icon={ClipboardCheck}
            title="Bilan non encore rédigé"
            description="Rédigez le bilan d'activité à la fin du projet, manuellement ou avec AIME."
            action={
              <div className="flex flex-wrap gap-2 justify-center">
                <Button onClick={() => setManualOpen(!manualOpen)} variant="outline" className="gap-2"><FileText className="w-4 h-4" /> Rédiger manuellement</Button>
                {aiEnabled && <Button onClick={generate} disabled={loading} className="gap-2">{loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Wand2 className="w-4 h-4" />} Générer avec AIME</Button>}
              </div>
            }
          />
          {manualOpen && (
            <Card className="soft-shadow animate-float-up">
              <CardContent className="p-4 space-y-3">
                <p className="text-sm font-medium">Rédiger le bilan</p>
                <Textarea value={manualContent} onChange={(e) => setManualContent(e.target.value)} rows={10} placeholder="Décrivez le déroulement, les résultats, les points forts et axes d'amélioration…" />
                <div className="flex gap-2">
                  <Button size="sm" onClick={createManualBilan} disabled={loading || !manualContent.trim()}>{loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Enregistrer"}</Button>
                  <Button size="sm" variant="ghost" onClick={() => setManualOpen(false)}>Annuler</Button>
                </div>
              </CardContent>
            </Card>
          )}
        </>
      ) : (
        <Card className="soft-shadow">
          <CardContent className="p-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-display text-lg font-medium">Bilan d'activité</h3>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" onClick={() => exportDocumentPDF("Bilan — " + project.name, bilan.content, { subtitle: "Bilan d'activité", association: project.name })} className="gap-1.5">
                  <Download className="w-3.5 h-3.5" /> PDF
                </Button>
                <Badge variant="outline" className="font-normal">{bilan.status}</Badge>
              </div>
            </div>
            <div className="whitespace-pre-wrap text-sm leading-relaxed text-foreground/90">{bilan.content}</div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function ArchivesTab({ projectId }) {
  const [entries, setEntries] = useState([]);
  useEffect(() => {
    base44.entities.JournalEntree.filter({ project_id: projectId }).then((e) => {
      e.sort((a, b) => (b.created_date || "").localeCompare(a.created_date || ""));
      setEntries(e);
    }).catch(() => {});
  }, [projectId]);
  return (
    <div>
      <p className="text-sm text-muted-foreground mb-4">Journal d'activité du projet — chaque action d'AIME est enregistrée.</p>
      {entries.length === 0 ? (
        <EmptyState icon={History} title="Journal vide" description="Les actions menées sur ce projet apparaîtront ici." />
      ) : (
        <div className="space-y-3 relative before:absolute before:left-[7px] before:top-2 before:bottom-2 before:w-px before:bg-border">
          {entries.map((e) => (
            <div key={e.id} className="flex gap-3 relative">
              <span className="w-3.5 h-3.5 rounded-full bg-primary mt-1.5 shrink-0 z-10 ring-4 ring-background" />
              <div className="flex-1 pb-1">
                <p className="text-sm">{e.details || e.action}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{e.auteur || "AIME"} · {formatDate(e.created_date)}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}