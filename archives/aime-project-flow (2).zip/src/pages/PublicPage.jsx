import React, { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import BlockRenderer from "@/components/studio/BlockRenderer";
import { Heart } from "lucide-react";

export default function PublicPage() {
  const params = useParams();
  const pathUsername = (params["*"] || params.username || "").replace(/^@/, "");
  const username = pathUsername || window.location.pathname.replace(/^\/@\/?/, "");
  const [page, setPage] = useState(null);
  const [sections, setSections] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    (async () => {
      try {
        const res = await base44.functions.invoke("getPublicPage", { username });
        if (res.data?.error) { setError(res.data.error); }
        else { setPage(res.data.page); setSections(res.data.sections || []); }
      } catch (err) {
        setError(err.message || "Page introuvable");
      }
      setLoading(false);
    })();
  }, [username]);

  if (loading) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-4 p-6 text-center">
        <h1 className="text-2xl font-display font-semibold">Page introuvable</h1>
        <p className="text-sm text-muted-foreground">La page @{username} n'existe pas ou n'est pas publiée.</p>
        <Link to="/" className="text-sm text-primary underline">Retour à l'accueil</Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {sections.map(s => (
        <BlockRenderer key={s.id} section={s} isEditing={false} />
      ))}

      {/* Rejoindre LE MONDE AIME */}
      <div className="border-t border-border py-12 px-6">
        <div className="max-w-2xl mx-auto text-center space-y-4">
          <div className="inline-flex items-center gap-2 text-sm text-muted-foreground">
            <Heart className="w-4 h-4" />
            <span>LE MONDE AIME</span>
          </div>
          <p className="text-lg font-display">Envie de créer votre propre page ?</p>
          <Link to="/register" className="inline-block px-6 py-3 rounded-full bg-foreground text-background text-sm font-medium hover:opacity-90 transition-opacity">
            Rejoindre LE MONDE AIME
          </Link>
        </div>
      </div>
    </div>
  );
}