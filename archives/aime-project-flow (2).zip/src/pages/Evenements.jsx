import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { formatDate } from "@/lib/aimeFormats";
import { logAction } from "@/lib/aimeAgent";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter
} from "@/components/ui/dialog";
import EmptyState from "@/components/EmptyState";
import { useToast } from "@/components/ui/use-toast";
import { useAssociation } from "@/components/AssociationProvider";
import { CalendarDays, Plus, Loader2, MapPin, Clock, Users, Trash2 } from "lucide-react";

const STATUS = {
  planifie: { label: "Planifié", cls: "bg-sky/20 text-sky-foreground border-sky/30" },
  confirme: { label: "Confirmé", cls: "bg-primary/10 text-primary border-primary/20" },
  realise: { label: "Réalisé", cls: "bg-sage/20 text-sage-foreground border-sage/30" },
  annule:  { label: "Annulé",  cls: "bg-muted text-muted-foreground" }
};

export default function Evenements() {
  const { toast } = useToast();
  const { activeAssociationId } = useAssociation();
  const [evenements, setEvenements] = useState([]);
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ project_id: "", name: "", description: "", date: "", time: "", location: "", expected_attendees: "" });

  async function load() {
    setLoading(true);
    try {
      const [e, p] = await Promise.all([
        base44.entities.Evenement.list(),
        base44.entities.Projet.list()
      ]);
      setEvenements(e);
      setProjects(p);
    } catch { /* bubble */ }
    setLoading(false);
  }
  useEffect(() => { load(); }, []);

  const projectMap = Object.fromEntries(projects.map((p) => [p.id, p]));
  const sorted = [...evenements].sort((a, b) => (b.date || "").localeCompare(a.date || ""));

  async function create() {
    if (!form.project_id || !form.name.trim()) return;
    await base44.entities.Evenement.create({
      project_id: form.project_id,
      association_id: activeAssociationId,
      name: form.name,
      description: form.description,
      date: form.date || null,
      time: form.time,
      location: form.location,
      expected_attendees: Number(form.expected_attendees) || 0,
      status: "planifie"
    });
    await logAction("creation_evenement", "Evenement", null, form.project_id, "Événement « " + form.name + " » créé.");
    setForm({ project_id: "", name: "", description: "", date: "", time: "", location: "", expected_attendees: "" });
    setOpen(false);
    toast({ title: "Événement créé" });
    load();
  }

  async function quickStatus(e, status) {
    await base44.entities.Evenement.update(e.id, { status });
    load();
  }

  async function remove(e) {
    await base44.entities.Evenement.delete(e.id);
    toast({ title: "Événement supprimé" });
    load();
  }

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-10 pt-8 lg:pt-12">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-semibold flex items-center gap-2">
            <CalendarDays className="w-6 h-6 text-primary" /> Événements
          </h1>
          <p className="text-sm text-muted-foreground mt-1">Dates clés, manifestations et rendez-vous publics de vos projets.</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="gap-1.5"><Plus className="w-4 h-4" /> Nouvel événement</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Créer un événement</DialogTitle></DialogHeader>
            <div className="space-y-3 py-2">
              <div>
                <Label>Projet</Label>
                <Select value={form.project_id} onValueChange={(v) => setForm({ ...form, project_id: v })}>
                  <SelectTrigger><SelectValue placeholder="Choisir un projet" /></SelectTrigger>
                  <SelectContent>
                    {projects.map((p) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Nom de l'événement</Label>
                <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Ex. Concert de fin d'année" />
              </div>
              <div>
                <Label>Description</Label>
                <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={2} placeholder="En quelques phrases…" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>Date</Label>
                  <Input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} />
                </div>
                <div>
                  <Label>Heure</Label>
                  <Input type="time" value={form.time} onChange={(e) => setForm({ ...form, time: e.target.value })} />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>Lieu</Label>
                  <Input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} placeholder="Salle, en ligne…" />
                </div>
                <div>
                  <Label>Participants attendus</Label>
                  <Input type="number" value={form.expected_attendees} onChange={(e) => setForm({ ...form, expected_attendees: e.target.value })} placeholder="0" />
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="ghost" onClick={() => setOpen(false)}>Annuler</Button>
              <Button onClick={create} disabled={!form.project_id || !form.name.trim()}>Créer</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {loading ? (
        <div className="flex justify-center pt-10"><Loader2 className="w-5 h-5 animate-spin text-muted-foreground" /></div>
      ) : evenements.length === 0 ? (
        <EmptyState
          icon={CalendarDays}
          title="Aucun événement"
          description="Ajoutez les dates clés de vos projets : manifestations, rendez-vous, temps forts."
        />
      ) : (
        <div className="space-y-3">
          {sorted.map((e) => {
            const st = STATUS[e.status] || STATUS.planifie;
            const proj = projectMap[e.project_id];
            return (
              <Card key={e.id} className="soft-shadow">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="text-sm font-medium">{e.name}</p>
                        <Badge variant="outline" className={"font-normal border-0 " + st.cls}>{st.label}</Badge>
                      </div>
                      {e.description && <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{e.description}</p>}
                      <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground flex-wrap">
                        <span className="flex items-center gap-1"><CalendarDays className="w-3.5 h-3.5" /> {formatDate(e.date)}</span>
                        {e.time && <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" /> {e.time}</span>}
                        {e.location && <span className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5" /> {e.location}</span>}
                        {e.expected_attendees > 0 && <span className="flex items-center gap-1"><Users className="w-3.5 h-3.5" /> {e.expected_attendees} attendus</span>}
                      </div>
                      {proj && (
                        <Link to={"/projects/" + proj.id} className="inline-flex items-center gap-1 text-xs text-primary mt-2 hover:underline">
                          {proj.name}
                        </Link>
                      )}
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      {e.status === "planifie" && (
                        <Button size="sm" variant="ghost" onClick={() => quickStatus(e, "confirme")}>Confirmer</Button>
                      )}
                      {e.status === "confirme" && (
                        <Button size="sm" variant="ghost" onClick={() => quickStatus(e, "realise")}>Marquer réalisé</Button>
                      )}
                      <button onClick={() => remove(e)} title="Supprimer" className="p-1.5 rounded-md hover:bg-destructive/10 text-muted-foreground hover:text-destructive">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}