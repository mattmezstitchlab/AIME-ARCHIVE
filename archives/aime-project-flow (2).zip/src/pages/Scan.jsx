import { useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { euro } from "@/lib/aimeFormats";
import { analyzeJustificatif, logAction } from "@/lib/aimeAgent";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem
} from "@/components/ui/select";
import { Image } from "@/components/ui/image";
import { useToast } from "@/components/ui/use-toast";
import { ScanLine, Upload, Loader2, FileText, Check, AlertCircle, Wand2, Pencil } from "lucide-react";
import { useAssociation } from "@/components/AssociationProvider";
import { useAI } from "@/components/AIProvider";

const DOC_TYPES = [
  { value: "facture", label: "Facture" },
  { value: "recu", label: "Reçu" },
  { value: "ticket", label: "Ticket" },
  { value: "contrat", label: "Contrat" },
  { value: "attestation", label: "Attestation" },
  { value: "autre", label: "Autre" }
];

export default function Scan() {
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { activeAssociationId } = useAssociation();
  const { aiEnabled } = useAI();
  const [projects, setProjects] = useState([]);
  const [file, setFile] = useState(null);
  const [fileUrl, setFileUrl] = useState("");
  const [uploading, setUploading] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [mode, setMode] = useState("manuel");
  const [extracted, setExtracted] = useState(null);
  const [projectId, setProjectId] = useState("");
  const [confirming, setConfirming] = useState(false);

  useEffect(() => {
    base44.entities.Projet.list().then((p) => { setProjects(p); setProjectId(params.get("project") || (p[0]?.id || "")); }).catch(() => {});
  }, []);

  async function onFile(e) {
    const f = e.target.files?.[0];
    if (!f) return;
    setFile(f);
    setUploading(true);
    setExtracted(null);
    try {
      const up = await base44.integrations.Core.UploadFile({ file: f });
      setFileUrl(up.file_url);
      setUploading(false);
      if (mode === "ia") {
        setAnalyzing(true);
        const res = await analyzeJustificatif(up.file_url);
        setExtracted(res);
        setAnalyzing(false);
      } else {
        setExtracted({ document_type: "facture", date_document: new Date().toISOString().slice(0, 10), montant: 0, emetteur: "", reference: "", summary: "" });
      }
    } catch (err) {
      toast({ title: "Erreur lors du téléversement", variant: "destructive" });
    }
    setAnalyzing(false);
  }

  function reset() { setFile(null); setFileUrl(""); setExtracted(null); }

  async function confirm() {
    if (!extracted || !projectId) return;
    setConfirming(true);
    try {
      const just = await base44.entities.Justificatif.create({
        project_id: projectId, association_id: activeAssociationId, file_url: fileUrl,
        file_name: file?.name || "document", file_type: file?.type || "",
        document_type: extracted.document_type || "facture", date_document: extracted.date_document || "",
        montant: Number(extracted.montant) || 0, emetteur: extracted.emetteur || "",
        reference: extracted.reference || "", extracted_data: extracted, status: "valide"
      });
      const dep = await base44.entities.Depense.create({
        project_id: projectId, association_id: activeAssociationId,
        description: extracted.emetteur ? "Achat " + extracted.emetteur : (file?.name || "Dépense"),
        montant: Number(extracted.montant) || 0, date: extracted.date_document || new Date().toISOString().slice(0, 10),
        emetteur: extracted.emetteur || "", justificatif_id: just.id, status: "valide"
      });
      await logAction("scan_justificatif", "Justificatif", just.id, projectId, "Justificatif importé et validé : " + euro(Number(extracted.montant) || 0) + " — " + (extracted.emetteur || ""));
      toast({ title: "Justificatif classé", description: euro(Number(extracted.montant) || 0) + " relié au projet et au budget." });
      navigate("/projects/" + projectId);
    } catch (e) {
      toast({ title: "Erreur lors de l'enregistrement", variant: "destructive" });
    }
    setConfirming(false);
  }

  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-10 pt-8 lg:pt-12">
      <div className="flex items-center gap-2 mb-2">
        <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center"><ScanLine className="w-5 h-5 text-primary" /></div>
        <div>
          <h1 className="font-display text-2xl font-semibold">AIME Scan</h1>
          <p className="text-sm text-muted-foreground">Importez un justificatif et renseignez ses informations.</p>
        </div>
      </div>

      {!file && (
        <Card className="soft-shadow mt-6">
          <div className="flex border-b border-border">
            <button onClick={() => setMode("manuel")}
              className={"flex-1 flex items-center justify-center gap-1.5 px-4 py-2.5 text-sm font-medium transition " + (mode === "manuel" ? "bg-card text-foreground" : "text-muted-foreground hover:text-foreground")}>
              <Pencil className="w-4 h-4" /> Saisie manuelle
            </button>
            {aiEnabled && (
              <button onClick={() => setMode("ia")}
                className={"flex-1 flex items-center justify-center gap-1.5 px-4 py-2.5 text-sm font-medium transition border-l border-border " + (mode === "ia" ? "bg-card text-foreground" : "text-muted-foreground hover:text-foreground")}>
                <Wand2 className="w-4 h-4" /> Analyse auto (IA)
              </button>
            )}
          </div>
          <label className="block cursor-pointer">
            <CardContent className="p-8 flex flex-col items-center text-center border-2 border-dashed border-border rounded-xl m-1 hover:border-primary/40 transition">
              <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mb-4">
                <Upload className="w-6 h-6 text-primary" />
              </div>
              <p className="font-medium">Prendre une photo ou importer un fichier</p>
              <p className="text-sm text-muted-foreground mt-1">Facture, reçu, ticket, PDF — {mode === "ia" ? "AIME lit le document." : "vous renseignez les champs."}</p>
              <input type="file" accept="image/*,application/pdf" className="hidden" onChange={onFile} />
            </CardContent>
          </label>
        </Card>
      )}

      {file && (
        <Card className="soft-shadow mt-6 overflow-hidden">
          <div className="flex gap-4 p-4">
            <div className="w-32 h-32 rounded-lg bg-muted overflow-hidden shrink-0 flex items-center justify-center">
              {file.type.startsWith("image/") ? <Image src={fileUrl} alt="apercu" className="w-full h-full object-cover" /> : <FileText className="w-10 h-10 text-muted-foreground" />}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{file.name}</p>
              <Badge variant="outline" className="mt-1 font-normal">{uploading ? "Téléversement…" : analyzing ? "AIME analyse…" : mode === "ia" ? "Analysé" : "Prêt à renseigner"}</Badge>
              {fileUrl && <p className="text-xs text-sage mt-2 flex items-center gap-1"><Check className="w-3.5 h-3.5" /> Original conservé</p>}
            </div>
            <Button variant="ghost" size="sm" onClick={reset}>Changer</Button>
          </div>

          {(uploading || analyzing) && (
            <div className="px-4 pb-4 space-y-2">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Loader2 className="w-4 h-4 animate-spin" />
                {uploading ? "Téléversement du fichier…" : "AIME lit le document et extrait les informations…"}
              </div>
              <div className="h-2 w-2/3 rounded bg-muted animate-pulse" />
              <div className="h-2 w-1/2 rounded bg-muted animate-pulse" />
            </div>
          )}

          {extracted && (
            <div className="px-4 pb-4 space-y-4 animate-float-up">
              <div className="rounded-xl bg-primary/8 border border-primary/20 p-4 flex items-start gap-3">
                {mode === "ia" ? <Wand2 className="w-5 h-5 text-primary shrink-0 mt-0.5" /> : <Pencil className="w-5 h-5 text-primary shrink-0 mt-0.5" />}
                <div>
                  <p className="text-sm font-medium">{mode === "ia" ? "AIME a extrait ces informations" : "Renseignez les informations"}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">Vérifiez et corrigez avant de valider.</p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs">Type</Label>
                  <Select value={extracted.document_type} onValueChange={(v) => setExtracted({ ...extracted, document_type: v })}>
                    <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {DOC_TYPES.map((t) => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs">Date</Label>
                  <Input type="date" value={extracted.date_document || ""} onChange={(e) => setExtracted({ ...extracted, date_document: e.target.value })} className="mt-1" />
                </div>
                <div>
                  <Label className="text-xs">Montant (€)</Label>
                  <Input type="number" value={extracted.montant || 0} onChange={(e) => setExtracted({ ...extracted, montant: Number(e.target.value) })} className="mt-1" />
                </div>
                <div>
                  <Label className="text-xs">Émetteur</Label>
                  <Input value={extracted.emetteur || ""} onChange={(e) => setExtracted({ ...extracted, emetteur: e.target.value })} placeholder="Nom du fournisseur" className="mt-1" />
                </div>
                <div>
                  <Label className="text-xs">Référence</Label>
                  <Input value={extracted.reference || ""} onChange={(e) => setExtracted({ ...extracted, reference: e.target.value })} placeholder="N° de facture" className="mt-1" />
                </div>
              </div>

              <div>
                <Label className="text-xs">Relier au projet</Label>
                <Select value={projectId} onValueChange={setProjectId}>
                  <SelectTrigger className="mt-1"><SelectValue placeholder="Choisir un projet" /></SelectTrigger>
                  <SelectContent>
                    {projects.map((p) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex gap-2">
                <Button onClick={confirm} disabled={confirming || !projectId} className="gap-2 flex-1">
                  {confirming ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                  Confirmer et classer
                </Button>
                <Button variant="ghost" onClick={reset}>Annuler</Button>
              </div>
            </div>
          )}
        </Card>
      )}

      {projects.length === 0 && (
        <div className="mt-4 rounded-xl bg-amber-50 border border-amber-200 p-4 flex items-center gap-2 text-sm text-amber-800">
          <AlertCircle className="w-4 h-4" /> Créez d'abord un projet pour pouvoir classer un justificatif.
        </div>
      )}
    </div>
  );
}