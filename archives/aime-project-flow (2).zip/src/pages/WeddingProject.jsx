import { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Heart, LayoutDashboard, Users, Clock, FileText, Palette, ChevronLeft, Eye, AlertCircle, Zap } from 'lucide-react';
import ParticipantsModule from '@/components/wedding/ParticipantsModule';
import TimelineModule from '@/components/wedding/TimelineModule';
import DocumentsModule from '@/components/wedding/DocumentsModule';
import { detectWeddingIssues } from '@/lib/weddingDetection';

const MODULES = [
  { id: 'overview', label: 'Vue d\'ensemble', icon: LayoutDashboard },
  { id: 'participants', label: 'Équipe & Prestataires', icon: Users },
  { id: 'timeline', label: 'Jour J — AIME LIVE™', icon: Clock },
  { id: 'documents', label: 'Documents', icon: FileText },
];

const VALID_MODULES = ['overview', 'participants', 'timeline', 'documents'];

export default function WeddingProject() {
  const { id } = useParams();
  const navigate = useNavigate();
  const urlModule = new URLSearchParams(window.location.search).get('module');
  const [loading, setLoading] = useState(true);
  const [project, setProject] = useState(null);
  const [dna, setDna] = useState(null);
  const [participants, setParticipants] = useState([]);
  const [timelineItems, setTimelineItems] = useState([]);
  const [documents, setDocuments] = useState([]);
  const [activeModule, setActiveModule] = useState(VALID_MODULES.includes(urlModule) ? urlModule : 'overview');
  const [issues, setIssues] = useState([]);

  const loadAll = useCallback(async () => {
    if (!id) return;
    setLoading(true);
    try {
      const me = await base44.auth.me();
      const [projectList, dnaList, parts, timeline, docs] = await Promise.all([
        base44.entities.AimeProject.filter({ id, owner_id: me.id }),
        base44.entities.ProjectDNA.filter({ project_id: id, owner_id: me.id }),
        base44.entities.WeddingParticipant.filter({ project_id: id, owner_id: me.id }, '-created_date', 200),
        base44.entities.WeddingTimelineItem.filter({ project_id: id, owner_id: me.id }, 'position', 200),
        base44.entities.ProjectDocument.filter({ project_id: id, owner_id: me.id }, '-created_date', 200),
      ]);
      setProject(projectList[0]);
      setDna(dnaList[0] || null);
      setParticipants(parts);
      setTimelineItems(timeline);
      setDocuments(docs);
      setIssues(detectWeddingIssues({ dna: dnaList[0], project: projectList[0], participants: parts, timeline, documents: docs }));
    } catch (e) {
      console.error(e);
    }
    setLoading(false);
  }, [id]);

  useEffect(() => { loadAll(); }, [loadAll]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin" />
      </div>
    );
  }

  if (!project) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-sm font-medium text-foreground mb-1">Projet introuvable</p>
          <Link to="/aime" className="text-sm text-primary underline">Retour aux projets</Link>
        </div>
      </div>
    );
  }

  const config = project.studio_page_id ? {} : {};
  const projectTitle = dna?.identity?.name || project.name;

  const renderModule = () => {
    switch (activeModule) {
      case 'participants':
        return <ParticipantsModule projectId={id} participants={participants} setParticipants={setParticipants} documents={documents} onReload={loadAll} />;
      case 'timeline':
        return <TimelineModule projectId={id} timelineItems={timelineItems} setTimelineItems={setTimelineItems} participants={participants} />;
      case 'documents':
        return <DocumentsModule projectId={id} documents={documents} setDocuments={setDocuments} participants={participants} />;
      case 'overview':
      default:
        return (
          <div className="max-w-4xl mx-auto px-8 py-10 space-y-6">
            <div>
              <h1 className="text-3xl font-display font-bold mb-1">{projectTitle}</h1>
              <p className="text-sm text-muted-foreground">Espace collaboratif de mariage</p>
            </div>

            {/* État global */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <div className="p-4 rounded-xl border border-border/60 bg-card">
                <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Prestataires</p>
                <p className="text-2xl font-display font-bold">{participants.filter(p => p.role === 'prestataire').length}</p>
              </div>
              <div className="p-4 rounded-xl border border-border/60 bg-card">
                <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Confirmés</p>
                <p className="text-2xl font-display font-bold">{participants.filter(p => p.status === 'accepted' || p.status === 'active').length}</p>
              </div>
              <div className="p-4 rounded-xl border border-border/60 bg-card">
                <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Étapes Jour J</p>
                <p className="text-2xl font-display font-bold">{timelineItems.length}</p>
              </div>
              <div className="p-4 rounded-xl border border-border/60 bg-card">
                <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Documents</p>
                <p className="text-2xl font-display font-bold">{documents.length}</p>
              </div>
            </div>

            {/* Alertes AIME */}
            {issues.length > 0 && (
              <div className="rounded-xl border border-amber-200 bg-amber-50 p-5">
                <div className="flex items-center gap-2 mb-3">
                  <AlertCircle className="w-4 h-4 text-amber-600" />
                  <h3 className="text-sm font-semibold text-amber-900">Alertes AIME — {issues.length} point(s) d'attention</h3>
                </div>
                <div className="space-y-2">
                  {issues.map((issue, i) => (
                    <div key={i} className="flex items-start gap-2 text-sm text-amber-800">
                      <span className="text-amber-500 mt-0.5">•</span>
                      <div className="flex-1">
                        <p>{issue.message}</p>
                        {issue.action && <p className="text-xs text-amber-600 mt-0.5">→ {issue.action}</p>}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Actions rapides */}
            <div className="flex flex-wrap gap-2">
              <button onClick={() => setActiveModule('participants')} className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full bg-foreground text-background text-sm font-medium hover:opacity-90 transition-opacity">
                <Users className="w-4 h-4" /> Ajouter un prestataire
              </button>
              <button onClick={() => setActiveModule('timeline')} className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full border border-border bg-card text-sm font-medium hover:bg-accent transition-colors">
                <Clock className="w-4 h-4" /> Préparer le Jour J
              </button>
              {project.studio_page_id ? (
                <Link to={`/studio/page/${project.studio_page_id}`} className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full border border-border bg-card text-sm font-medium hover:bg-accent transition-colors">
                  <Palette className="w-4 h-4" /> Ouvrir le Studio
                </Link>
              ) : (
                <Link to={`/aime/project/${project.id}/dna`} className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full border border-border bg-card text-sm font-medium hover:bg-accent transition-colors">
                  <Palette className="w-4 h-4" /> Créer le Studio
                </Link>
              )}
              <Link to={`/aime/project/${project.id}/control`} className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full border border-border bg-card text-sm font-medium hover:bg-accent transition-colors">
                <Zap className="w-4 h-4" /> Command Center
              </Link>
              <Link to={`/aime/project/${project.id}/day`} className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full bg-foreground text-background text-sm font-medium hover:opacity-90 transition-opacity">
                <Clock className="w-4 h-4" /> Jour J — Live
              </Link>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      {/* Sidebar */}
      <aside className="w-[280px] shrink-0 h-screen sticky top-0 border-r border-border/60 bg-card flex flex-col">
        <div className="px-5 pt-5 pb-3">
          <Link to="/aime" className="flex items-center gap-2 text-xs font-display font-bold tracking-widest text-muted-foreground hover:text-foreground transition-colors">
            <Heart className="w-3.5 h-3.5" />
            LE MONDE AIME
          </Link>
        </div>
        <div className="px-5 pb-4">
          <div className="p-3 rounded-xl border border-border/60 bg-muted/30">
            <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Mariage</span>
            <h2 className="font-display font-semibold text-base truncate">{projectTitle}</h2>
          </div>
        </div>
        <nav className="flex-1 overflow-y-auto px-3 pb-4">
          <div className="flex flex-col gap-0.5">
            {MODULES.map((mod) => {
              const Icon = mod.icon;
              const isActive = activeModule === mod.id;
              return (
                <button
                  key={mod.id}
                  onClick={() => setActiveModule(mod.id)}
                  className={`flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors text-left ${
                    isActive ? 'bg-foreground text-background font-medium' : 'text-muted-foreground hover:text-foreground hover:bg-accent'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span className="truncate">{mod.label}</span>
                </button>
              );
            })}
          </div>
        </nav>
        <div className="px-3 py-3 border-t border-border/60">
          {project.studio_page_id && (
            <Link
              to={`/project/${project.studio_page_id}`}
              className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
            >
              <Eye className="w-4 h-4 shrink-0" />
              <span>Espace invités</span>
            </Link>
          )}
          <Link
            to="/aime"
            className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-muted-foreground hover:text-foreground hover:bg-accent transition-colors mt-0.5"
          >
            <ChevronLeft className="w-4 h-4 shrink-0" />
            <span>Retour aux projets</span>
          </Link>
        </div>
      </aside>

      {/* Content */}
      <div className="flex-1 overflow-y-auto">
        {renderModule()}
      </div>
    </div>
  );
}