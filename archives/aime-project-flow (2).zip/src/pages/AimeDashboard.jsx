import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Plus, FolderKanban, Loader2, Dna, Heart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import ImportDialog from '@/components/aime/ImportDialog';
import WeddingOnboarding from '@/components/aime/WeddingOnboarding';
import AimeProjectReading from '@/components/aime/AimeProjectReading';
import { rerunAnalysis } from '@/lib/aime/reanalysis';

const CATEGORY_LABELS = {
  wedding: 'Mariage', music: 'Musique', association: 'Association',
  business: 'Business', education: 'Éducation', community: 'Communauté',
  personal: 'Personnel', other: 'Projet',
};

export default function AimeDashboard() {
  const navigate = useNavigate();
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [importOpen, setImportOpen] = useState(false);
  const [weddingOpen, setWeddingOpen] = useState(false);
  const [selectedDna, setSelectedDna] = useState(null);
  const [dnaLoading, setDnaLoading] = useState(false);

  const loadProjects = useCallback(async () => {
    try {
      const me = await base44.auth.me();
      const list = await base44.entities.AimeProject.filter({ owner_id: me.id }, '-created_date', 50);
      setProjects(list);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadProjects();
  }, [loadProjects]);

  const handleOpenDna = async (project) => {
    setDnaLoading(true);
    try {
      const me = await base44.auth.me();
      const dnaList = await base44.entities.ProjectDNA.filter({
        project_id: project.id,
        owner_id: me.id,
      });
      const futurePaths = await base44.entities.FuturePath.filter({
        project_id: project.id,
        owner_id: me.id,
      });
      const memoryItems = await base44.entities.MemoryItem.filter({
        project_id: project.id,
        owner_id: me.id,
      }, '-created_date', 200);
      const scanResult = {
        itemCount: project.item_count || 0,
        directoryCount: 0,
        totalSize: memoryItems.reduce((s, i) => s + (i.size || 0), 0),
        items: memoryItems,
      };
      setSelectedDna({ project, dna: dnaList[0], scanResult, futurePaths });
    } catch (e) {
      console.error(e);
    } finally {
      setDnaLoading(false);
    }
  };

  const handleImportComplete = () => {
    setImportOpen(false);
    loadProjects();
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-5xl mx-auto px-6 py-10">
        <div className="mb-10">
          <div className="flex items-center gap-2 mb-2">
            <Dna className="w-5 h-5 text-foreground" strokeWidth={1.5} />
            <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              AIME CORE — Memory Core V1
            </span>
          </div>
          <h1 className="font-heading text-4xl font-medium tracking-tight mb-2">Mes projets</h1>
          <p className="text-sm text-muted-foreground max-w-lg">
            AIME ne gère pas des fichiers. AIME comprend des projets humains.
            Importez un projet, AIME construit sa mémoire.
          </p>
        </div>

        <div className="mb-8 flex flex-wrap gap-3">
          <button
            onClick={() => setWeddingOpen(true)}
            className="brand-secondary-btn"
          >
            <Heart className="w-4 h-4" strokeWidth={2} />
            Commencer un mariage
          </button>
          <button
            onClick={() => setImportOpen(true)}
            className="brand-outline-btn"
          >
            <Plus className="w-4 h-4" strokeWidth={2} />
            Importer un projet
          </button>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
          </div>
        ) : projects.length === 0 ? (
          <div className="border border-dashed border-border rounded-lg p-16 text-center">
            <FolderKanban className="w-10 h-10 mx-auto mb-4 text-muted-foreground" strokeWidth={1.5} />
            <p className="text-sm font-medium text-foreground mb-1">Aucun projet en mémoire</p>
            <p className="text-xs text-muted-foreground mb-4">
              Importez un premier projet pour qu'AIME commence à comprendre.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {projects.map((project) => (
              <button
                key={project.id}
                onClick={() => handleOpenDna(project)}
                className="text-left border border-border rounded-lg overflow-hidden hover:border-foreground/20 transition group"
              >
                <div
                  className="h-28 flex items-center justify-center"
                  style={{
                    background: `linear-gradient(135deg, ${project.color || '#E5E3DC'}, #F8F8F6)`,
                  }}
                >
                  <Dna className="w-7 h-7 text-muted-foreground group-hover:text-foreground transition" strokeWidth={1.5} />
                </div>
                <div className="p-4">
                  <span className="brand-badge mb-2 inline-block">
                    {CATEGORY_LABELS[project.category] || project.category}
                  </span>
                  <h3 className="font-heading text-base font-medium mb-1 truncate">{project.name}</h3>
                  <p className="text-xs text-muted-foreground">{project.item_count || 0} éléments en mémoire</p>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>

      <ImportDialog
        open={importOpen}
        onClose={() => setImportOpen(false)}
        onComplete={handleImportComplete}
      />

      <WeddingOnboarding
        open={weddingOpen}
        onClose={() => setWeddingOpen(false)}
        onComplete={() => { setWeddingOpen(false); loadProjects(); }}
      />

      <Dialog open={!!selectedDna} onOpenChange={(o) => !o && setSelectedDna(null)}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-heading text-xl flex items-center gap-2">
              <Dna className="w-5 h-5" strokeWidth={1.5} />
              {selectedDna?.project?.name}
            </DialogTitle>
          </DialogHeader>
          {dnaLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
            </div>
          ) : selectedDna?.dna ? (
            <AimeProjectReading
              dna={selectedDna.dna}
              scanResult={selectedDna.scanResult}
              futurePaths={selectedDna.futurePaths}
              project={selectedDna.project}
              onRerun={async () => {
                const updated = await rerunAnalysis(selectedDna.project, selectedDna.dna.id);
                setSelectedDna({ ...selectedDna, dna: updated });
              }}
              onDnaUpdated={(updated) => setSelectedDna({ ...selectedDna, dna: updated })}
            />
          ) : (
            <p className="text-sm text-muted-foreground py-8 text-center">Aucun ADN trouvé pour ce projet.</p>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}