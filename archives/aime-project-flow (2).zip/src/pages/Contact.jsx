import { useState } from 'react';
import LandingNav from '@/components/landing/LandingNav';
import LandingFooter from '@/components/landing/LandingFooter';
import PageHero from '@/components/landing/PageHero';
import { motion } from 'framer-motion';
import { Mail, MessageCircle } from 'lucide-react';

export default function Contact() {
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({ name: '', email: '', message: '' });

  const handleSubmit = (e) => {
    e.preventDefault();
    setSent(true);
  };

  return (
    <div className="min-h-screen bg-background">
      <LandingNav />
      <PageHero
        image="https://media.base44.com/images/public/6a6e080d1aca70178ff1340c/111cd3411_generated_image.png"
        badge="Contact"
        title="Parlons-nous"
        subtitle="Une question, une idée, un mariage à organiser ? Écrivez-nous."
        focalPointY={0.5}
      />
      <section className="pt-20 pb-24 px-6">
        <div className="max-w-2xl mx-auto">
          {sent ? (
            <div className="text-center py-16 border border-border rounded-lg bg-card">
              <div className="w-12 h-12 rounded-full bg-foreground text-background flex items-center justify-center mx-auto mb-4">
                <MessageCircle className="w-5 h-5" />
              </div>
              <p className="font-heading text-xl font-medium mb-2">Message envoyé</p>
              <p className="text-sm text-muted-foreground">Nous vous répondrons rapidement.</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs uppercase tracking-wider text-muted-foreground mb-2">Nom</label>
                <input
                  required
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="w-full h-12 px-4 rounded-full border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                />
              </div>
              <div>
                <label className="block text-xs uppercase tracking-wider text-muted-foreground mb-2">Email</label>
                <input
                  required
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  className="w-full h-12 px-4 rounded-full border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                />
              </div>
              <div>
                <label className="block text-xs uppercase tracking-wider text-muted-foreground mb-2">Message</label>
                <textarea
                  required
                  rows={5}
                  value={form.message}
                  onChange={(e) => setForm({ ...form, message: e.target.value })}
                  className="w-full px-4 py-3 rounded-lg border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring resize-none"
                />
              </div>
              <button type="submit" className="brand-secondary-btn w-full">
                <Mail className="w-4 h-4" /> Envoyer
              </button>
            </form>
          )}
        </div>
      </section>
      <LandingFooter />
    </div>
  );
}