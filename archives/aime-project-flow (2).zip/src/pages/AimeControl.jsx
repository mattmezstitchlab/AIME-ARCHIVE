import { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { ArrowLeft, Loader2, Zap, LayoutGrid, Dna, Sparkles, RefreshCw, Users } from 'lucide-react';
import ArchetypeBadge from '@/components/aime/ArchetypeBadge';
import ProjectStateCard from '@/components/aime/control/ProjectStateCard';
import ActionList from '@/components/aime/control/ActionList';
import IntelligentTimeline from '@/components/aime/control/IntelligentTimeline';
import { calculateReadiness } from '@/lib/aime/readinessScore';
import { calculateMaturity } from '@/lib/aime/maturityCalculator';
import { normalizeDna } from '@/lib/aime/dnaNormalize';
import { syncProjectActions, computeProjectState } from '@/lib/aime/actionEngine';
import { buildAdaptiveBlueprint, describeFactors } from '@/lib/aime/adaptiveBlueprint';

const CATEGORY_LABELS = {
  wedding: 'Mariage', music: 'Musique', association: 'Association',
  business: 'Business', education: 'Éducation', community: 'Communauté',
  personal: 'Personnel', other: 'Projet',
};

export default function AimeControl() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [project, setProject] = useState(null);
  const [dna, setDna] = useState(null);
  const [memoryItems, setMemoryItems] = useState([]);
  const [futurePaths, setFuturePaths] = useState([]);
  const [actions, setActions] = useState([]);

  const loadAll = useCallback(async () => {
    if (!id) return;
    setLoading(true);
    try {
      const me = await base44.auth.me();
      const [projectList, dnaList, items, fps, existingActions] = await Promise.all([
        base44.entities.AimeProject.filter({ id, owner_id: me.id }),
        base44.entities.ProjectDNA.filter({ project_id: id, owner_id: me.id }),
        base44.entities.MemoryItem.filter({ project_id: id, owner_id: me.id }, '-created_date', 200),
        base44.entities.FuturePath.filter({ project_id: id, owner_id: me.id }),
        base44.entities.ProjectAction.filter({ project_id: id, owner_id: me.id }, 'order', 50),
      ]);
      setProject(projectList[0]);
      setDna(dnaList[0] || null);
      setMemoryItems(items);
      setFuturePaths(fps);
      setActions(existingActions);

      // Sync actions (create new ones from gaps)
      if (projectList[0] && dnaList[0]) {
        const nd = normalizeDna(dnaList[0]);
        const readiness = calculateReadiness({ dna: nd, memoryItems: items, futurePaths: fps, archetype: nd.archetype });
        // Fetch page status for contextual actions (publish/share)
        let pageStatus = undefined;
        if (projectList[0].studio_page_id) {
          try {
            const pages = await base44.entities.PersonalPublicPage.filter({ id: projectList[0].studio_page_id });
            pageStatus = pages[0]?.status;
          } catch (e) { /* non-blocking */ }
        }
        setSyncing(true);
        try {
          const created = await syncProjectActions(id, nd, projectList[0], readiness, existingActions, fps, pageStatus);
          if (created && created.length > 0) {
            const refreshed = await base44.entities.ProjectAction.filter({ project_id: id, owner_id: me.id }, 'order', 50);
            setActions(refreshed);
          }
        } catch (e) {
          console.error('Action sync failed:', e);
        }
        setSyncing(false);
      }
    } catch (e) {
      console.error(e);
    }
    setLoading(false);
  }, [id]);

  useEffect(() => { loadAll(); }, [loadAll]);

  const nd = dna ? normalizeDna(dna) : null;
  const archetype = nd?.archetype || 'inconnu';
  const archetypeConfidence = nd?.archetype_confidence || 0;
  const archetypeSignals = nd?.archetype_signals || [];
  const readiness = nd ? calculateReadiness({ dna: nd, memoryItems, futurePaths, archetype }) : null;
  const maturity = nd ? calculateMaturity({ dna: nd, memoryItems, futurePaths, project }) : null;
  const projectState = nd ? computeProjectState({ dna: nd, readiness, memoryItems, futurePaths, project, actions }) : null;
  const adaptiveBlueprint = nd ? buildAdaptiveBlueprint(nd, archetype, memoryItems) : null;

  const handleAction = (action) => {
    if (action.target_route) {
      navigate(action.target_route);
    }
  };

  const handleToggleStatus = async (action, newStatus) => {
    try {
      const updated = await base44.entities.ProjectAction.update(action.id, {
        status: newStatus,
        completed_at: newStatus === 'done' ? new Date().toISOString() : null,
      });
      setActions((prev) => prev.map((a) => (a.id === action.id ? updated : a)));
    } catch (e) {
      console.error(e);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!project) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-sm font-medium text-foreground mb-1">Projet introuvable</p>
          <Link to="/aime" className="brand-outline-btn text-xs">Retour aux projets</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-6xl mx-auto px-6 py-8">
        {/* Header */}
        <div className="mb-6">
          <button onClick={() => navigate(`/aime/project/${id}/dna`)} className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition mb-3">
            <ArrowLeft className="w-3.5 h-3.5" strokeWidth={1.5} />
            Retour à la Partition Vivante
          </button>
          <div className="flex items-center gap-2 mb-1">
            <Zap className="w-5 h-5 text-foreground" strokeWidth={1.5} />
            <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Project Command Center — V1.5</span>
            {syncing && <Loader2 className="w-3.5 h-3.5 animate-spin text-muted-foreground" />}
          </div>
          <h1 className="font-heading text-3xl font-medium tracking-tight mb-1">{project.name}</h1>
          <div className="flex items-center gap-3 flex-wrap mb-1">
            <ArchetypeBadge archetype={archetype} confidence={archetypeConfidence} signals={archetypeSignals} />
            {readiness?.weddingLevel && (
              <span className="brand-badge-dark">{readiness.weddingLevel}</span>
            )}
            <span className="text-sm text-muted-foreground">
              {CATEGORY_LABELS[project.category] || project.category} · {memoryItems.length} éléments · {actions.length} actions
            </span>
          </div>
        </div>

        {!nd ? (
          <div className="border border-dashed border-border rounded-lg p-12 text-center">
            <p className="text-sm font-medium text-foreground mb-1">Aucun ADN trouvé pour ce projet</p>
            <p className="text-xs text-muted-foreground mb-4">Importez d'abord ce projet dans AIME.</p>
            <Link to="/aime" className="brand-outline-btn text-xs">Importer</Link>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Ligne 1 : État + Actions */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <ProjectStateCard state={projectState} loading={false} />
              <ActionList
                actions={actions}
                loading={false}
                onAction={handleAction}
                onToggleStatus={handleToggleStatus}
              />
            </div>

            {/* Ligne 2 : Timeline intelligente */}
            <IntelligentTimeline
              dna={nd}
              actions={actions}
              project={project}
              futurePaths={futurePaths}
            />

            {/* Ligne 3 : Blueprint adaptatif V2 */}
            {adaptiveBlueprint && (
              <div className="border border-border rounded-lg p-5">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <LayoutGrid className="w-4 h-4 text-muted-foreground" strokeWidth={1.5} />
                    <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                      Studio Blueprint V2 — Adaptatif
                    </h3>
                  </div>
                  {adaptiveBlueprint.isAdaptive && (
                    <span className="brand-badge-dark">Personnalisé</span>
                  )}
                </div>

                {/* Facteurs détectés */}
                <div className="flex items-center gap-2 mb-4 flex-wrap">
                  <span className="text-xs text-muted-foreground">Facteurs :</span>
                  {describeFactors(adaptiveBlueprint.factors).split(' · ').map((f, i) => (
                    <span key={i} className="brand-badge">{f}</span>
                  ))}
                </div>

                {/* Notes adaptatives */}
                {adaptiveBlueprint.adaptiveNotes.length > 0 && (
                  <div className="space-y-1 mb-4">
                    {adaptiveBlueprint.adaptiveNotes.map((note, i) => (
                      <div key={i} className="flex items-start gap-2 text-xs text-muted-foreground">
                        <Sparkles className="w-3.5 h-3.5 mt-0.5 shrink-0" strokeWidth={1.5} />
                        <span>{note}</span>
                      </div>
                    ))}
                  </div>
                )}

                {/* Sections */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {adaptiveBlueprint.sections.map((s, i) => (
                    <div key={s.id} className="flex items-center gap-2 text-sm py-1.5 px-2 rounded border border-border">
                      <span className="text-xs text-muted-foreground font-mono w-5">{String(i + 1).padStart(2, '0')}</span>
                      <span className="flex-1">{s.label}</span>
                      {s.required ? (
                        <span className="brand-badge">Requis</span>
                      ) : (
                        <span className="text-xs text-muted-foreground">Opt.</span>
                      )}
                    </div>
                  ))}
                </div>

                {/* Design direction */}
                <div className="mt-4 pt-4 border-t border-border">
                  <p className="text-xs text-muted-foreground mb-1.5">Direction design</p>
                  <p className="text-sm">
                    <span className="font-medium capitalize">{adaptiveBlueprint.design.mood}</span>
                    <span className="text-muted-foreground"> · {adaptiveBlueprint.design.palette_hint}</span>
                  </p>
                </div>
              </div>
            )}

            {/* Ligne 4 : Navigation rapide */}
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => navigate(`/aime/project/${id}/dna`)}
                className="brand-outline-btn text-xs"
              >
                <Dna className="w-3.5 h-3.5" strokeWidth={1.5} />
                Partition Vivante
              </button>
              <button
                onClick={() => navigate(`/aime/think?project=${id}`)}
                className="brand-outline-btn text-xs"
              >
                <Sparkles className="w-3.5 h-3.5" strokeWidth={1.5} />
                Dialoguer avec AIME THINK
              </button>
              <button
                onClick={loadAll}
                className="brand-outline-btn text-xs"
              >
                <RefreshCw className="w-3.5 h-3.5" strokeWidth={1.5} />
                Recalculer les actions
              </button>
              <button
                onClick={() => navigate(`/aime/project/${id}/wedding`)}
                className="brand-secondary-btn text-xs"
              >
                <Users className="w-3.5 h-3.5" strokeWidth={1.5} />
                Espace collaboratif mariage
              </button>
              {project.studio_page_id && (
                <button
                  onClick={() => navigate(`/studio/page/${project.studio_page_id}`)}
                  className="brand-outline-btn text-xs"
                >
                  <LayoutGrid className="w-3.5 h-3.5" strokeWidth={1.5} />
                  Ouvrir le Studio
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}