import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import LandingNav from "@/components/landing/LandingNav";
import WeddingHero from "@/components/landing/WeddingHero";
import WeddingProblemSection from "@/components/landing/WeddingProblemSection";
import WeddingParcoursSection from "@/components/landing/WeddingParcoursSection";
import WeddingModulesSection from "@/components/landing/WeddingModulesSection";
import WeddingPermissionsSection from "@/components/landing/WeddingPermissionsSection";
import WeddingAiMeSection from "@/components/landing/WeddingAiMeSection";
import WeddingPhotoBand from "@/components/landing/WeddingPhotoBand";
import WeddingImportSection from "@/components/landing/WeddingImportSection";
import WeddingDaySection from "@/components/landing/WeddingDaySection";
import WeddingProsSection from "@/components/landing/WeddingProsSection";
import WeddingPricingSection from "@/components/landing/WeddingPricingSection";
import WeddingFaqSection from "@/components/landing/WeddingFaqSection";
import WeddingCtaSection from "@/components/landing/WeddingCtaSection";
import LandingFooter from "@/components/landing/LandingFooter";
import { LANDING_DEFAULTS } from "@/lib/landingDefaults";

export default function Landing() {
  const [content, setContent] = useState(LANDING_DEFAULTS);

  useEffect(() => {
    base44.entities.LandingPage.filter({ key: "main" }).then((rows) => {
      if (rows[0]) setContent({ ...LANDING_DEFAULTS, ...rows[0] });
    }).catch(() => {});
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <LandingNav />
      <WeddingHero content={content} />
      <WeddingProblemSection />
      <WeddingParcoursSection />
      <WeddingPhotoBand
        src="https://media.base44.com/images/public/6a6e080d1aca70178ff1340c/38afa8347_generated_image.png"
        alt="Un couple qui organise son mariage ensemble"
        quote="Vous décidez ensemble. AIME retient tout."
        caption="Une seule saisie : le budget, les prestataires et le déroulé se mettent à jour partout."
        focalPointY={0.4}
      />
      <WeddingModulesSection />
      <WeddingPermissionsSection />
      <WeddingDaySection />
      <WeddingPhotoBand
        src="https://media.base44.com/images/public/6a6e080d1aca70178ff1340c/d2c1daa9b_generated_image.png"
        alt="Des prestataires au travail le jour du mariage"
        quote="Le jour J, chacun sait quoi faire et quand."
        caption="Fleuriste, traiteur, technique, DJ : un espace par prestataire, alimenté par votre déroulé."
        focalPointY={0.45}
      />
      <WeddingProsSection />
      <WeddingAiMeSection />
      <WeddingPricingSection />
      <WeddingFaqSection />
      <WeddingCtaSection />
      <LandingFooter />
    </div>
  );
}