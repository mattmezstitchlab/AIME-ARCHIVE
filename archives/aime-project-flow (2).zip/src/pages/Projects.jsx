import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { STATUS_PROJET } from "@/lib/aimeFormats";
import EmptyState from "@/components/EmptyState";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { FolderKanban, Plus, Loader2, ArrowRight } from "lucide-react";

export default function Projects() {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        setProjects(await base44.entities.Projet.list("-created_date"));
      } catch (e) {}
      setLoading(false);
    })();
  }, []);

  if (loading) return <div className="flex justify-center pt-20"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>;

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-10 pt-8 lg:pt-12">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-semibold">Mes projets</h1>
          <p className="text-sm text-muted-foreground mt-1">Tous vos dossiers, structurés par AIME.</p>
        </div>
        <Button asChild className="gap-1.5">
          <a href="/#composer"><Plus className="w-4 h-4" /> Nouveau projet</a>
        </Button>
      </div>

      {projects.length === 0 ? (
        <EmptyState
          icon={FolderKanban}
          title="Aucun projet pour l'instant"
          description="Racontez simplement ce que vous voulez organiser. AIME crée la structure, le calendrier et le budget pour vous."
          action={<Button asChild><a href="/#composer">Raconter un projet</a></Button>}
        />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {projects.map((p) => {
            const st = STATUS_PROJET[p.status] || STATUS_PROJET.idee;
            return (
              <Link key={p.id} to={"/projects/" + p.id} className="block animate-float-up">
                <Card className="soft-shadow hover:-translate-y-0.5 transition h-full overflow-hidden">
                  <div className="h-1.5" style={{ backgroundColor: p.color || "#1A2744" }} />
                  <CardContent className="p-5">
                    <div className="flex items-start justify-between gap-3">
                      <h3 className="font-display text-lg font-medium leading-tight">{p.name}</h3>
                      <Badge className={st.color + " border-0 font-normal"}>{st.label}</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mt-2 line-clamp-2">{p.description || p.vision || "—"}</p>
                    <div className="mt-4">
                      <div className="flex items-center justify-between text-xs text-muted-foreground mb-1.5">
                        <span>Avancement</span>
                        <span className="font-medium text-foreground">{p.completion_pct || 0}%</span>
                      </div>
                      <Progress value={p.completion_pct || 0} className="h-1.5" />
                    </div>
                    <div className="flex items-center justify-between mt-4 pt-3 border-t border-border">
                      <p className="text-xs text-muted-foreground">
                        {p.missing_fields?.length ? p.missing_fields.length + " info(s) manquante(s)" : "Complet"}
                      </p>
                      <ArrowRight className="w-4 h-4 text-muted-foreground" />
                    </div>
                  </CardContent>
                </Card>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}