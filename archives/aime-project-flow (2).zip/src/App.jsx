import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, useLocation, Navigate } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ScrollToTop from './components/ScrollToTop';
import Layout from '@/components/Layout';
import Home from '@/pages/Home';
import Projects from '@/pages/Projects';
import ProjectDetail from '@/pages/ProjectDetail';
import Agent from '@/pages/Agent';
import Scan from '@/pages/Scan';
import Vigilance from '@/pages/Vigilance';
import Membres from '@/pages/Membres';
import Partenaires from '@/pages/Partenaires';
import Reunions from '@/pages/Reunions';
import Evenements from '@/pages/Evenements';
import AssociationSettings from '@/pages/AssociationSettings';
import StudioPage from '@/pages/StudioPage';
import PublicPage from '@/pages/PublicPage';
import Documents from '@/pages/Documents';
import ProjectPage from '@/pages/ProjectPage';
import Landing from '@/pages/Landing';
import Login from '@/pages/Login';
import Register from '@/pages/Register';
import ForgotPassword from '@/pages/ForgotPassword';
import ResetPassword from '@/pages/ResetPassword';
import AdminLanding from '@/pages/AdminLanding';
import AimeDashboard from '@/pages/AimeDashboard';
import AimeThink from '@/pages/AimeThink';
import AimePartition from '@/pages/AimePartition';
import AimeControl from '@/pages/AimeControl';
import WeddingProject from '@/pages/WeddingProject';
import VendorSpace from '@/pages/VendorSpace';
import DayCommandCenter from '@/pages/DayCommandCenter';
import HowItWorks from '@/pages/HowItWorks';
import Univers from '@/pages/Univers';
import About from '@/pages/About';
import Contact from '@/pages/Contact';
import FAQ from '@/pages/FAQ';
import AdminDashboard from '@/pages/AdminDashboard';
import AdminRoute from '@/components/AdminRoute';
import { AssociationProvider } from '@/components/AssociationProvider';
import { AIProvider } from '@/components/AIProvider';

const AuthenticatedApp = () => {
  const location = useLocation();
  const publicRoutes = ["/login", "/register", "/forgot-password", "/reset-password", "/landing", "/comment-ca-marche", "/univers", "/aime/mariage", "/aime/artiste", "/aime/association", "/aime/entreprise", "/studios", "/a-propos", "/contact", "/faq", "/privacy", "/terms"];
  const isPublicPage = location.pathname.startsWith("/@") || location.pathname.startsWith("/vendor/") || publicRoutes.includes(location.pathname);
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  if (isPublicPage) {
    return (
      <Routes>
        <Route path="/vendor/:participantId" element={<VendorSpace />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/reset-password" element={<ResetPassword />} />
        <Route path="/*" element={<PublicPage />} />
        <Route path="/landing" element={<Landing />} />
        <Route path="/comment-ca-marche" element={<HowItWorks />} />
        <Route path="/univers" element={<Univers />} />
        <Route path="/aime/mariage" element={<Navigate to="/landing" replace />} />
        <Route path="/aime/artiste" element={<Navigate to="/univers" replace />} />
        <Route path="/aime/association" element={<Navigate to="/univers" replace />} />
        <Route path="/aime/entreprise" element={<Navigate to="/univers" replace />} />
        <Route path="/studios" element={<Navigate to="/univers" replace />} />
        <Route path="/a-propos" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/faq" element={<FAQ />} />
        <Route path="/privacy" element={<About />} />
        <Route path="/terms" element={<About />} />
      </Routes>
    );
  }

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Les visiteurs non connectés atterrissent sur la landing plutôt que sur le login
      if (location.pathname === '/') return <Landing />;
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  return (
    <AssociationProvider>
    <AIProvider>
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Home />} />
        <Route path="/projects" element={<Projects />} />
        <Route path="/projects/:id" element={<ProjectDetail />} />
        <Route path="/agent" element={<Agent />} />
        <Route path="/scan" element={<Scan />} />
        <Route path="/vigilance" element={<Vigilance />} />
        <Route path="/membres" element={<Membres />} />
        <Route path="/partenaires" element={<Partenaires />} />
        <Route path="/reunions" element={<Reunions />} />
        <Route path="/evenements" element={<Evenements />} />
        <Route path="/association/parametres" element={<AssociationSettings />} />
        <Route path="/documents" element={<Documents />} />
        <Route element={<AdminRoute />}>
          <Route path="/admin/landing" element={<AdminLanding />} />
        </Route>
        <Route path="/aime" element={<AimeDashboard />} />
        <Route path="/aime/think" element={<AimeThink />} />
        <Route path="/aime/project/:id/dna" element={<AimePartition />} />
        <Route path="/aime/project/:id/control" element={<AimeControl />} />
        <Route path="/aime/project/:id/wedding" element={<WeddingProject />} />
        <Route path="/aime/project/:id/day" element={<DayCommandCenter />} />
      </Route>
      <Route element={<AdminRoute />}>
        <Route path="/studio/page" element={<StudioPage />} />
        <Route path="/studio/page/:pageId" element={<StudioPage />} />
        <Route path="/admin" element={<AdminDashboard />} />
      </Route>
      <Route path="/project/:pageId" element={<ProjectPage />} />
      <Route path="*" element={<PageNotFound />} />
    </Routes>
    </AIProvider>
    </AssociationProvider>
  );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <ScrollToTop />
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App