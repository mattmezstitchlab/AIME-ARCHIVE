# AIME — Vision produit fondamentale

> **Document de référence principal — Source de vérité produit**
>
> Ce document guide toutes les décisions UX, UI, techniques, fonctionnelles et stratégiques d'AIME.
>
> En cas de doute, de contradiction ou d'arbitrage, cette vision prévaut sur les choix ponctuels, les maquettes, les composants existants et les idées de fonctionnalités isolées.

---

# 1. AIME en une phrase

> **AIME transforme des informations, documents et idées dispersés en un projet organisé, opérationnel et visible.**

---

# 2. Ce qu'est AIME

AIME n'est pas uniquement :

* un créateur de sites ;
* un outil pour associations ;
* un logiciel de gestion ;
* un tableau de bord ;
* un Studio de pages ;
* un gestionnaire de documents ;
* un assistant IA ;
* un agent autonome.

Ces fonctions peuvent exister dans AIME, mais aucune ne définit seule le produit.

**AIME est un système universel d'organisation, de compréhension et d'automatisation des projets humains.**

AIME permet à une personne, une association, une entreprise, un artiste, un collectif ou un organisateur de transformer un ensemble d'informations dispersées en un espace cohérent, structuré et immédiatement utilisable.

---

# 3. Le problème universel

Tous les projets rencontrent un problème commun.

Les informations sont dispersées entre :

* emails ;
* SMS ;
* WhatsApp ;
* notes ;
* documents PDF ;
* devis ;
* factures ;
* contrats ;
* images ;
* vidéos ;
* dossiers ;
* tableurs ;
* calendriers ;
* sites internet ;
* outils administratifs ;
* applications spécialisées.

L'utilisateur doit ensuite :

* comprendre ce qu'il possède ;
* créer des dossiers ;
* classer les fichiers ;
* recopier des informations ;
* construire des tableaux ;
* choisir des logiciels ;
* relier les données ;
* rechercher les documents ;
* vérifier les échéances ;
* déterminer ce qu'il doit faire ensuite.

Aujourd'hui, l'utilisateur porte la charge d'organisation.

**AIME doit transférer cette charge vers le système.**

---

# 4. La promesse fondamentale

> **« Déposez ce que vous avez. Décrivez ce que vous voulez. AIME organise le reste. »**

AIME ne demande pas :

> « Quels outils souhaitez-vous utiliser ? »

AIME demande :

> **« Quel est votre projet ? »**

Puis il prépare automatiquement l'environnement nécessaire.

---

# 5. Le principe central

## L'utilisateur apporte

* une idée ;
* une intention ;
* un nom ;
* une description ;
* des documents ;
* des messages ;
* des fichiers ;
* des images ;
* des liens ;
* des informations déjà existantes.

## AIME comprend

* le type de projet ;
* son objectif ;
* ses besoins ;
* les informations importantes ;
* les personnes concernées ;
* les documents présents ;
* les données manquantes ;
* les actions nécessaires.

## AIME organise

* les informations ;
* les documents ;
* les catégories ;
* les relations ;
* les tâches ;
* les échéances ;
* les accès ;
* les outils utiles.

## AIME prépare

* le Dashboard ;
* les modules nécessaires ;
* les documents adaptés ;
* les automatisations ;
* la structure du projet ;
* la présence publique.

---

# 6. Le parcours universel AIME

## Étape 1 — Décrire ou importer

L'utilisateur peut :

* décrire son projet ;
* indiquer un nom ;
* choisir un contexte ;
* importer un PDF ;
* importer un devis ;
* importer une facture ;
* importer un contrat ;
* ajouter une capture d'écran ;
* ajouter une conversation ;
* ajouter une image ;
* ajouter un lien ;
* importer plusieurs fichiers.

Il peut commencer avec une seule phrase ou avec un ensemble de documents déjà existants.

---

## Étape 2 — Comprendre

AIME analyse :

* l'intention ;
* le contexte ;
* les contenus ;
* les documents ;
* les informations extraites ;
* les personnes ;
* les dates ;
* les montants ;
* les événements ;
* les besoins potentiels.

---

## Étape 3 — Structurer

AIME :

* crée le projet ;
* prépare le Dashboard ;
* crée les catégories utiles ;
* classe les informations ;
* relie les données ;
* active les outils adaptés ;
* prépare les documents nécessaires ;
* identifie les informations manquantes.

---

## Étape 4 — Rendre opérationnel

L'utilisateur arrive dans un espace déjà préparé.

Il ne doit pas avoir à :

* créer les dossiers ;
* choisir les tableaux ;
* chercher les modules ;
* construire l'organisation ;
* imaginer la structure technique.

AIME fournit un socle cohérent dès le départ.

---

## Étape 5 — Rendre visible

AIME peut générer une présence publique à partir :

* de l'identité ;
* du contexte ;
* des contenus ;
* des informations du projet ;
* de la direction artistique choisie.

La page publique devient la vitrine vivante du projet.

---

## Étape 6 — Accompagner

L'utilisateur peut continuer seul ou activer un Agent AIME.

L'agent devient une couche d'assistance et d'automatisation avancée.

---

# 7. Architecture produit cible

## AIME OS™ — Système d'exploitation cognitif pour projets humains

```text
                         AIME OS™


                           ME
                       (Humain)


                           ↓


                      AIME CORE™
              Cognitive Operating System


                           ↓


 ┌─────────────────────────────────────────┐
 │              MEMORY CORE™               │
 │       La mémoire vivante d'AIME         │
 │                                         │
 │       Memory Graph                       │
 │       Project DNA                        │
 │       History                            │
 │       Relations                          │
 │       Future Graph                        │
 └─────────────────────────────────────────┘


 ┌─────────────────────────────────────────┐
 │           REASONING ENGINE™             │
 │       L'intelligence d'analyse          │
 │                                         │
 │       SENSE — Percevoir                  │
 │       THINK — Comprendre                 │
 │       Strategic Intelligence             │
 └─────────────────────────────────────────┘


 ┌─────────────────────────────────────────┐
 │             ACTION ENGINE™              │
 │       La transformation                 │
 │                                         │
 │       ACT — Transformer                  │
 │       Build · Repair · Organize · Create │
 └─────────────────────────────────────────┘


                           ↓


                    AIME PROJECTS


 Wedding · Music · Association · Business
 Education · Community · Personal
```

## Définitions officielles

- **AIME OS™** — le système entier, vu par l'humain (ME).
- **AIME CORE™** — le cerveau complet. Un système d'exploitation cognitif pour projets humains.
- **AIME MEMORY ENGINE™** — la mémoire vivante d'AIME CORE™, capable de transformer les traces numériques en connaissance relationnelle, contextuelle et évolutive.
- **MEMORY GRAPH** — le système nerveux d'AIME CORE.
- **PROJECT DNA** — l'ADN des organismes projets.
- **FUTURE GRAPH** — l'imagination structurée du futur, propriété native de Project DNA.

## Les 3 intelligences fondamentales

```
SENSE  — Percevoir.
THINK  — Comprendre.
ACT    — Transformer.
```

## Le socle opérationnel — Dashboard universel

Sous AIME CORE, chaque projet dispose d'un Dashboard universel (cœur opérationnel commun) :

```text
Projet
 │
 └── Dashboard universel
     │
     ├── Vue générale
     ├── Documents
     ├── Budget
     ├── Devis
     ├── Factures
     ├── Contrats
     ├── Messages
     ├── Contacts
     ├── Tâches
     ├── Calendrier
     ├── Événements
     ├── Équipe
     ├── Accès et permissions
     ├── Médias
     ├── Activité
     └── Automatisations
 │
 ├── Contexte intelligent
 ├── Outils spécialisés
 ├── Présence publique
 └── Agent AIME — option avancée
```

## La vraie innovation AIME

Les autres IA :

```text
Question → Réponse
```

Les agents IA :

```text
Objectif → Action
```

AIME :

```text
Traces humaines
 ↓
Mémoire relationnelle
 ↓
Compréhension du contexte
 ↓
Futurs possibles
 ↓
Décision humaine
 ↓
Transformation
```

> **AIME n'est pas un outil qui utilise l'intelligence artificielle.**
>
> **AIME est une architecture qui donne une mémoire, une compréhension et une capacité d'évolution aux projets humains.**

---

# 8. Le Dashboard universel

Le Dashboard est le **cœur opérationnel d'AIME**.

Il doit être commun à tous les projets.

Les informations peuvent être présentées différemment selon le contexte, mais le socle reste cohérent.

Le Dashboard doit permettre de comprendre immédiatement :

* où en est le projet ;
* ce qui est important ;
* ce qui manque ;
* ce qui est à faire ;
* ce qui arrive ;
* quels documents existent ;
* quelles actions nécessitent une attention ;
* quelles automatisations sont actives.

Le Dashboard ne doit pas être une simple collection de widgets.

Il doit être une **vue intelligente de l'état réel du projet**.

---

# 9. Le contexte intelligent

Le contexte ne crée pas une application séparée.

Il configure le même système AIME.

Le contexte peut :

* activer des outils ;
* proposer des catégories ;
* générer des documents ;
* adapter les recommandations ;
* modifier les informations du Dashboard ;
* proposer une structure publique adaptée ;
* activer des automatisations spécifiques.

## Exemples

### Association

AIME peut activer :

* administration ;
* statuts ;
* gouvernance ;
* membres ;
* adhérents ;
* bénévoles ;
* intervenants ;
* actions ;
* événements ;
* financements ;
* budget ;
* documents administratifs.

### Mariage

AIME peut activer :

* invités ;
* RSVP ;
* prestataires ;
* budget ;
* planning ;
* programme ;
* documents ;
* hébergements ;
* transports ;
* galerie ;
* liste de mariage.

### Entreprise

AIME peut activer :

* clients ;
* projets ;
* devis ;
* factures ;
* contrats ;
* équipe ;
* prestations ;
* suivi commercial ;
* documents professionnels.

### Artiste

AIME peut activer :

* prestations ;
* dates ;
* événements ;
* médias ;
* portfolio ;
* contrats ;
* devis ;
* factures ;
* contacts professionnels.

### Événement

AIME peut activer :

* programme ;
* intervenants ;
* bénévoles ;
* prestataires ;
* planning ;
* budget ;
* documents ;
* partenaires ;
* communication.

---

# 10. Les outils spécialisés

Les outils spécialisés doivent être :

* activés automatiquement lorsque le contexte le justifie ;
* proposés lorsque le besoin est détecté ;
* accessibles sans complexifier l'interface ;
* reliés au Dashboard universel.

Un outil spécialisé ne doit jamais devenir un produit isolé.

Exemple :

Un événement créé dans une association doit pouvoir utiliser :

* les membres existants ;
* les bénévoles ;
* les documents ;
* le budget ;
* les contacts ;
* les médias ;
* les accès.

Le système doit éviter la duplication des données.

---

# 11. Les documents intelligents

AIME doit pouvoir :

* importer ;
* lire ;
* analyser ;
* extraire ;
* classer ;
* relier ;
* retrouver ;
* résumer ;
* préparer ;
* générer.

Les documents peuvent être :

* devis ;
* factures ;
* contrats ;
* statuts ;
* comptes rendus ;
* convocations ;
* formulaires ;
* courriers ;
* documents administratifs ;
* documents événementiels.

Lorsqu'une information est déjà connue dans le projet, elle doit pouvoir être réutilisée pour préremplir les documents.

Exemples :

* nom du projet ;
* identité ;
* adresse ;
* contacts ;
* responsables ;
* dates ;
* montants ;
* coordonnées ;
* informations organisationnelles.

L'utilisateur ne doit pas ressaisir plusieurs fois la même information.

---

# 12. Sources de vérité

Lorsqu'AIME utilise des informations externes, le système doit distinguer :

* les informations fournies par l'utilisateur ;
* les informations extraites de documents ;
* les informations issues de sources externes ;
* les informations générées ou proposées par l'IA.

Les données importantes doivent pouvoir être :

* vérifiées ;
* corrigées ;
* validées ;
* tracées.

AIME ne doit pas présenter une information générée comme un fait confirmé.

---

# 13. La présence publique

La présence publique est une valeur ajoutée commune à tous les projets.

Elle peut exister pour :

* une personne ;
* une association ;
* une entreprise ;
* un artiste ;
* un mariage ;
* un événement ;
* un collectif ;
* un projet personnel.

La page publique est générée à partir :

* de l'identité ;
* du contexte ;
* des informations du projet ;
* des contenus disponibles ;
* de la direction artistique ;
* des choix de publication.

Elle n'est pas un produit séparé.

Elle n'est pas le cœur du produit.

Elle est la **vitrine vivante du projet**.

---

# 14. Le Studio AIME

Le Studio est l'espace de création et de personnalisation de la présence publique.

Le Studio ne doit pas être confondu avec :

* le Dashboard ;
* les outils administratifs ;
* le gestionnaire de projet ;
* les modules métier.

Le Studio permet de :

* choisir une direction artistique ;
* définir une palette ;
* choisir des typographies ;
* choisir des mises en page ;
* modifier les sections ;
* importer des médias ;
* régler les visuels ;
* organiser la structure ;
* prévisualiser la page ;
* publier.

---

## Démarrage du Studio

Le Studio ne doit pas toujours ouvrir une page générique déjà remplie.

Deux entrées sont possibles :

### Créer depuis zéro

* page blanche ;
* structure vide ;
* choix manuel des sections ;
* personnalisation progressive.

### Créer avec AIME

* description du projet ;
* analyse du contexte ;
* choix artistique ;
* génération du socle ;
* création d'une structure adaptée.

---

## Principe de page

Par défaut :

> **Un projet → une présence publique → une page principale**

Les pages supplémentaires ne doivent être activées que lorsqu'un contexte les justifie.

Exemple mariage :

* page publique des invités ;
* espace privé du couple ;
* espace de coordination autorisé.

Ces espaces peuvent être des niveaux d'accès différents et ne doivent pas nécessairement être traités comme plusieurs sites indépendants.

---

# 15. Le système d'ajout intelligent

Le bouton **Ajouter** ne doit pas être une simple bibliothèque de composants.

Il doit analyser :

* le contexte ;
* la page ;
* la position ;
* les sections existantes ;
* les contenus disponibles ;
* l'objectif de la page.

AIME doit proposer les ajouts pertinents.

Exemple :

Pour un mariage, après le programme :

* hébergements ;
* transports ;
* galerie ;
* informations pratiques ;
* liste de mariage ;
* livre d'or.

L'utilisateur choisit ensuite :

1. l'emplacement ;
2. le type de section ;
3. une variante de mise en page ;
4. les contenus ;
5. les réglages.

Une section ne doit pas être automatiquement ajoutée tout en bas sans validation.

---

# 16. L'identité visuelle

AIME doit proposer un onboarding artistique comprenant :

* ambiance ;
* style ;
* palette ;
* typographie ;
* composition ;
* type de Hero ;
* traitement des images ;
* niveau d'animation.

Exemples de styles :

* minimal ;
* éditorial ;
* élégant ;
* premium ;
* artistique ;
* naturel ;
* moderne ;
* institutionnel.

Chaque contexte peut proposer des directions adaptées sans limiter la créativité.

---

# 17. Les médias

Les médias doivent respecter leurs proportions d'origine.

AIME ne doit jamais déformer une image.

Modes possibles :

* image naturelle ;
* image contenue ;
* image pleine largeur ;
* image de fond ;
* Hero plein écran ;
* image recadrée ;
* image avec masque.

Les réglages peuvent inclure :

* position ;
* centrage ;
* zoom ;
* recadrage ;
* luminosité ;
* contraste ;
* saturation ;
* température ;
* flou ;
* opacité ;
* filtre ;
* superposition ;
* dégradé.

Pour un Hero en fond :

* l'image couvre la section ;
* le texte reste lisible ;
* un overlay peut être appliqué ;
* la position du sujet peut être ajustée.

---

# 18. L'Agent AIME

L'Agent AIME est une option avancée.

Il n'est jamais obligatoire.

AIME doit rester utile sans agent permanent.

L'agent peut :

* organiser les nouveaux éléments ;
* analyser les documents ;
* proposer des actions ;
* détecter les informations manquantes ;
* préparer des documents ;
* suivre les échéances ;
* créer des rappels ;
* rechercher des informations ;
* coordonner certaines tâches ;
* accompagner le projet dans le temps.

L'agent doit être :

* transparent ;
* contrôlable ;
* configurable ;
* réversible ;
* soumis aux autorisations définies.

L'utilisateur doit savoir :

* ce que l'agent fait ;
* quelles données il utilise ;
* quelles actions sont proposées ;
* quelles actions nécessitent une validation.

---

# 19. Intelligence économique

AIME doit utiliser le niveau d'intelligence nécessaire, pas systématiquement le niveau le plus coûteux.

## Par défaut

Utiliser autant que possible :

* règles locales ;
* modèles de structure ;
* bibliothèques de composants ;
* logique contextuelle ;
* classification légère ;
* données déjà présentes ;
* automatisations déterministes.

## Utiliser l'IA lorsque cela apporte une valeur réelle

Exemples :

* analyser un document complexe ;
* extraire des informations ;
* résumer des messages ;
* comprendre une intention libre ;
* générer un texte ;
* créer un visuel ;
* effectuer une recherche externe ;
* produire une recommandation complexe.

## Agent avancé

Utiliser des capacités plus autonomes uniquement lorsque l'utilisateur active cette option ou lorsque le niveau d'automatisation le justifie.

---

# 20. La landing AIME

La landing doit présenter le produit dans le bon ordre.

Elle doit montrer :

1. une idée ou des informations dispersées ;
2. un champ de description ;
3. l'import de documents et de fichiers ;
4. la compréhension du projet ;
5. l'organisation automatique ;
6. la création du Dashboard ;
7. l'activation des outils adaptés ;
8. la génération de la présence publique ;
9. l'Agent AIME comme option avancée.

La landing ne doit pas faire croire qu'AIME est seulement :

* un générateur de sites ;
* un outil d'association ;
* un éditeur de pages ;
* un chatbot.

---

# 21. Architecture de navigation

La navigation principale doit rester claire.

```text
AIME

├── Accueil
│   └── Projets et activité
│
├── Projet
│   └── Dashboard et informations
│
├── Studio
│   └── Présence publique
│
├── Publication
│   └── Visibilité, domaine et diffusion
│
└── Agent AIME
    └── Assistance et automatisations
```

Chaque espace doit répondre à une question.

| Espace      | Question                                       |
| ----------- | ---------------------------------------------- |
| Accueil     | Sur quel projet voulez-vous travailler ?       |
| Projet      | Que contient votre projet ?                    |
| Dashboard   | Que se passe-t-il et que faut-il faire ?       |
| Studio      | À quoi ressemble votre présence publique ?     |
| Publication | Comment souhaitez-vous diffuser votre projet ? |
| Agent       | Que souhaitez-vous déléguer ou automatiser ?   |

---

# 22. Règles de gouvernance

Avant toute évolution :

1. Auditer l'existant.
2. Identifier les fonctionnalités déjà disponibles.
3. Vérifier les composants réutilisables.
4. Éviter les doublons.
5. Vérifier la cohérence avec cette vision.
6. Préserver les données et fonctionnalités utiles.
7. Modifier avant de reconstruire.
8. Réutiliser avant de créer.
9. Simplifier avant d'ajouter.

---

# 23. Règles de développement

Ne pas :

* reconstruire l'application entièrement sans nécessité ;
* créer un nouveau module si une fonction équivalente existe ;
* dupliquer les données ;
* créer des parcours parallèles ;
* multiplier les dashboards ;
* créer une application différente pour chaque contexte ;
* ajouter une fonction uniquement parce qu'elle existe chez un concurrent ;
* exposer une complexité technique inutile à l'utilisateur.

Toujours :

* réutiliser les fondations existantes ;
* centraliser les données ;
* garder un socle universel ;
* adapter les outils au contexte ;
* réduire les décisions ;
* privilégier les automatismes contrôlables ;
* conserver une expérience cohérente.

---

# 24. Critère de validation d'une fonctionnalité

Avant d'ajouter une fonction, répondre :

1. Quel problème utilisateur résout-elle ?
2. Est-elle déjà présente ?
3. Peut-elle être intégrée au socle existant ?
4. Est-elle universelle ou contextuelle ?
5. Doit-elle être automatique ?
6. Doit-elle être visible dès le départ ?
7. Réduit-elle réellement la charge de l'utilisateur ?
8. Évite-t-elle une nouvelle duplication ?
9. Renforce-t-elle le parcours AIME ?

Si la fonctionnalité augmente la complexité sans réduire une difficulté réelle, elle ne doit pas être prioritaire.

---

# 25. La formule produit définitive

> **Un projet.**
>
> **Un espace.**
>
> **Une organisation automatique.**
>
> **Des outils adaptés.**
>
> **Une présence publique.**
>
> **Une intelligence qui accompagne.**

---

# 26. Promesse finale

> **Déposez ce que vous avez.**
>
> **Décrivez ce que vous voulez.**
>
> **AIME comprend, organise et prépare le reste.**

---

*Ce document est la référence unique pour toutes les prochaines évolutions d'AIME.*