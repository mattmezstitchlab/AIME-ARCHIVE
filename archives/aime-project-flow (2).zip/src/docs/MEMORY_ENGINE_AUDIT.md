# AIME CORE™ — Architecture du système d'exploitation cognitif pour projets humains

> Document stratégique définitif — Source de vérité pour la construction d'AIME CORE™.
> Principe directeur : **local-first, cloud à la demande**.
> Date : 2026-08-04
> Référence : `docs/PRODUCT_VISION.md` (charte produit)

---

## Positionnement définitif

> **AIME ne gère pas des fichiers.**
>
> **AIME comprend des projets humains.**
>
> **Il transforme les traces numériques en organismes vivants, compréhensibles et évolutifs.**
>
> **Un système d'exploitation cognitif qui combine mémoire relationnelle, compréhension contextuelle et exploration des futurs possibles.**

> **AIME n'est pas un outil qui utilise l'intelligence artificielle.**
>
> **AIME est une architecture qui donne une mémoire, une compréhension et une capacité d'évolution aux projets humains.**

---

## Hiérarchie des noms officielle

```
                         AIME OS™


                           ME
                       (Humain)


                           ↓


                      AIME CORE™
              Cognitive Operating System


                           ↓


       ┌───────────────────┼───────────────────┐

       MEMORY CORE™     REASONING ENGINE™    ACTION ENGINE™

       Mémoire           Intelligence         Transformation


                           ↓


                    AIME PROJECTS
```

## Définitions officielles

- **AIME OS™** — le système entier, vu par l'humain (ME).
- **AIME CORE™** — le cerveau complet. Un système d'exploitation cognitif pour projets humains. Comparable à macOS, Android, Windows — un OS cognitif.
- **AIME MEMORY ENGINE™** — la mémoire vivante d'AIME CORE™, capable de transformer les traces numériques en connaissance relationnelle, contextuelle et évolutive.
- **MEMORY GRAPH** — le système nerveux d'AIME CORE.
- **PROJECT DNA** — l'ADN des organismes projets.
- **FUTURE GRAPH** — l'imagination structurée du futur, propriété native de Project DNA.
- **STRATEGIC INTELLIGENCE™** — l'interface décisionnelle qui explore les futurs possibles.

Un OS possède plusieurs couches : mémoire, raisonnement, action, interface, sécurité, orchestration. AIME CORE les possède toutes.

---

## Architecture finale officielle

```
                         AIME OS™


                           ME
                       (Humain)


                           ↓


                      AIME CORE™


        Cognitive Operating System


                           ↓


 ┌─────────────────────────────────────────┐
 │              MEMORY CORE™               │
 │       La mémoire vivante d'AIME         │
 │                                         │
 │       Memory Graph                       │
 │       Project DNA                        │
 │       History                            │
 │       Relations                          │
 │       Future Graph                        │
 └─────────────────────────────────────────┘


 ┌─────────────────────────────────────────┐
 │           REASONING ENGINE™             │
 │       L'intelligence d'analyse          │
 │                                         │
 │       SENSE — Percevoir                  │
 │       THINK — Comprendre                 │
 │       Strategic Intelligence             │
 └─────────────────────────────────────────┘


 ┌─────────────────────────────────────────┐
 │             ACTION ENGINE™              │
 │       La transformation                 │
 │                                         │
 │       ACT — Transformer                  │
 │       Build · Repair · Organize · Create │
 └─────────────────────────────────────────┘


                           ↓


                    AIME PROJECTS


 Wedding
 Music
 Association
 Business
 Education
 Community
 Personal
```

---

## Les 3 intelligences fondamentales

> AIME repose sur trois intelligences fondamentales :

```
SENSE  — Percevoir.
THINK  — Comprendre.
ACT    — Transformer.
```

C'est le modèle mental universel d'AIME.

Comme :

- Google : Search
- Apple : Think Different
- **AIME : Sense → Think → Act**

---

## La vraie innovation AIME

Les autres IA :

```
Question → Réponse
```

Les agents IA :

```
Objectif → Action
```

AIME :

```
Traces humaines
 ↓
Mémoire relationnelle
 ↓
Compréhension du contexte
 ↓
Futurs possibles
 ↓
Décision humaine
 ↓
Transformation
```

---

# 1. MEMORY CORE™ — La mémoire vivante

## Le Memory Graph — Système nerveux d'AIME CORE

Le Memory Graph n'est pas le cœur. **C'est le système nerveux.**

Un cerveau humain n'est pas seulement une mémoire. C'est :

* mémoire ;
* connexions ;
* contexte ;
* apprentissage ;
* anticipation.

```
MEMORY CORE


        Memory Graph
             |
             |
    -------------------
    |        |        |
 Projet   Personne  Ressource
    |        |        |
 Temps   Emotion   Historique
```

## Rupture majeure

Le fichier disparaît. Il devient :

```
Objet numérique
        ↓
   Contexte
        ↓
  Relation
        ↓
 Signification
```

C'est la rupture avec Dropbox, Finder, Drive. AIME ne range pas des fichiers — il relie des significations.

## Architecture hybride (local + Base44)

```
AIME Memory Graph
  │
  ├── Couche relationnelle (Base44 entities)
  │     ├── MemoryItem       (un fichier / projet / document / personne importé)
  │     ├── MemoryRelation   (appartient, référence, version_de, dérive_de)
  │     ├── MemoryVersion    (historique des versions)
  │     ├── MemoryContext    (préférences, patterns utilisateur)
  │     └── ProjectDNA       (l'empreinte vivante de chaque projet)
  │
  ├── Couche sémantique (embeddings locaux)
  │     ├── Vector index (sqlite-vec WASM dans le navigateur)
  │     └── Recherche "trouve-moi tous les visuels hero de projets mariage"
  │
  └── Couche raisonnement (LLM, à la demande)
        ├── Résumé d'un projet
        ├── Détection d'incohérences
        └── Exploration des futurs possibles
```

**Pourquoi hybride** : les relations sont déterministes → entités Base44. La recherche sémantique → embeddings WASM local. Aucune base externe (pas de Neo4j, pas de Pinecone).

---

# 2. AIME PROJECT DNA™ — Entité fondamentale

Un projet n'est pas un dossier. **Un projet est un organisme vivant.**

Project DNA n'est pas une fonctionnalité. **C'est une entité fondamentale d'AIME CORE.**

## Structure de l'entité ProjectDNA

```json
ProjectDNA {

  identity: {
    name,
    purpose,
    category,
    origin
  },

  humans: [
    people,
    teams,
    clients
  ],

  resources: [
    files,
    media,
    documents
  ],

  timeline: {
    past: [],
    present: [],
    futureGraph: []
  },

  state: {
    maturity,
    risks,
    opportunities
  },

  intelligence: {
    patterns: [],
    risks: [],
    opportunities: [],
    scenarios: []
  }

}
```

## La rupture

AIME ne mémorise pas seulement le passé. **Il mémorise aussi ce que ce projet pourrait devenir.**

C'est là que le concept devient beaucoup plus fort que Notion ou Drive.

---

# 3. Future Graph — Propriété native de Project DNA

Le Memory Graph classique regarde :

```
PASSÉ → PRÉSENT
```

AIME ajoute la dimension des futurs possibles :

```
                 PROJECT DNA


                      |
                      |

                MEMORY GRAPH

                      |

 ┌────────────┬────────────┬────────────┐

 PASSÉ      PRÉSENT      FUTURS


 Archive     Etat       Possibilités

 Versions    Risques    Scénarios

 Histoire    Actions    Opportunités
```

Le Future Graph est une **propriété native de Project DNA**, pas une extension.

## Exemple mariage

```
Projet mariage

Aujourd'hui :
- faire-part terminé
- lieu confirmé
- musique choisie

Futur possible :

Option A :
simple cérémonie

Option B :
transformer en expérience immersive

Option C :
créer un album souvenir permanent
```

Le Future Graph transforme AIME d'un outil de mémoire en un **système d'exploration des possibles**.

---

# 4. AIME STRATEGIC INTELLIGENCE™ — L'interface décisionnelle

Le rapport n'est pas un PDF. **C'est une interface décisionnelle vivante.**

Un PDF est un résultat. Une intelligence est un système vivant.

## Système complet

```
THINK

 ↓

AIME STRATEGIC INTELLIGENCE™

 ↓

Future Paths

 ↓

Decision

 ↓

ACT
```

Le Strategic Report devient simplement **une vue** dans Strategic Intelligence.

## Format du Strategic Report (vue)

```
## Analyse terminée

J'ai identifié :

* 1 application web
* 3 versions du design
* 2 bases de données
* 15 documents associés

## Ma compréhension :

Probabilité :

Application événementielle : 91%
Association : 6%
Portfolio : 3%

## Plusieurs chemins possibles :

### Option A — Continuer le projet actuel
Avantage : rapide
Risque : architecture ancienne

### Option B — Fusionner avec projet X
Avantage : meilleure base technique

### Option C — Transformer en nouveau produit AIME
Avantage : potentiel commercial
```

## La différence avec Manus

Manus répond. **AIME explore.**

AIME ne dit pas « voici la solution ». AIME dit « voici les chemins possibles, avec leurs avantages et leurs risques ». L'utilisateur choisit le chemin. AIME exécute après validation.

---

# 5. Architecture agentique définitive — Les 3 intelligences

```
             AIME CORE


                SENSE

       Percevoir le monde


                ↓


               THINK

       Comprendre le sens


                ↓


                ACT

       Transformer le réel
```

## SENSE — Capte

* fichiers
* images
* vidéos
* URL
* GitHub
* Figma
* documents

Agents internes :

```
SENSE
 ├ Scanner
 ├ Reader
 ├ Vision
 └ Classifier
```

## THINK — Comprend

* contexte
* intention
* architecture
* risques
* opportunités

Agents internes :

```
THINK
 ├ Memory Analyst
 ├ Context Engine
 ├ Architecture Analyst
 └ Strategic Intelligence
```

## ACT — Transforme

* créer
* réparer
* organiser
* publier
* automatiser

Agents internes :

```
ACT
 ├ Creator
 ├ Organizer
 ├ Repair
 └ Rebuild
```

## Tableau des capacités

| Intelligence | Agent | Rôle | Local | Coût/appel |
|---|---|---|---|---|
| SENSE | Scanner | Parcourt le contenu, identifie la structure | ✅ | 0 |
| SENSE | Reader | PDF/Word/Excel, extraction texte | ✅ | 0 |
| SENSE | Vision | EXIF, thumbnails, OCR images | ✅ | 0 |
| SENSE | Classifier | Catégorisation par embeddings | ✅ | 0 |
| THINK | Memory Analyst | Rôle sémantique de chaque élément | Local `llama3.2` / cloud | 0–0,002€ |
| THINK | Context Engine | Type de projet, Project DNA | Hybride | 0–0,005€ |
| THINK | Architecture Analyst | Cohérence technique, problèmes | Local `qwen2.5-coder` / cloud | 0–0,05€ |
| THINK | Strategic Intelligence | Future Paths, chemins possibles | Cloud `gemini-3-flash` | 0,005–0,02€ |
| ACT | Creator | README, rapports, fiches mémoire | Cloud `gemini-3-flash` | 0,005–0,02€ |
| ACT | Organizer | Range, classe, fusionne, archive | Local | 0 |
| ACT | Repair | Corrige fichiers manquants, imports | Cloud `claude-sonnet` | 0,05–0,20€ |
| ACT | Rebuild | Reconstruit une architecture | Cloud `claude-sonnet` | 0,05–0,20€ |

**Règles** :
- SENSE est 100% local, 0€, déterministe ou embeddings.
- THINK est local par défaut, cloud sur demande.
- ACT n'agit jamais sans validation explicite. AIME propose, l'utilisateur décide.

## ORCHESTRATOR (local, déterministe)

Machine à états qui coordonne SENSE → THINK → ACT, gère le budget de crédits, décide quelle intelligence appeler et quand. 0€, code pur.

---

# 6. AIME MEMORY DESKTOP™ — Le futur OS utilisateur

Ce n'est pas une fonctionnalité. **C'est la conséquence logique d'AIME CORE.**

## Vision

Aujourd'hui :

```
Finder

Documents
Images
Downloads
Desktop
```

Demain :

```
AIME MEMORY DESKTOP


Mes projets

❤️ Mariage Sophie
🎷 Carrière musicale
🏡 Maison
🚐 Nomad Life
🌍 Association


Chaque projet possède :

- mémoire
- histoire
- documents
- relations
- futurs possibles
```

AIME devient un **explorateur de sens** — pas un explorateur de fichiers.

## Implémentation progressive

- **V1** : import manuel (ZIP, dossier, URL, GitHub). Pas d'accès disque.
- **V2** : synchronisation d'un dossier watché (File System Access API navigateur, avec permission).
- **V3** : AIME MEMORY DESKTOP complet — cartographie du patrimoine, détection de doublons, propositions de fusion, explorateur de projets vivants.

## Différence avec Dropbox / Finder

AIME MEMORY DESKTOP ne montre pas des dossiers — il montre des organismes vivants, leurs relations, leur état, leur potentiel, leurs futurs possibles.

**Règle de privacy** : l'accès disque n'est jamais silencieux. L'utilisateur autorise explicitement un dossier. AIME ne lit que ce dossier.

---

# 7. Choix des modèles IA

## Solutions locales (gratuites)

| Modèle | Usage | Taille | Confidentialité |
|---|---|---|---|
| `nomic-embed-text` (Ollama) | Embeddings SENSE | 274 Mo | ✅ Totale |
| `bge-m3` (transformers.js) | Embeddings navigateur | 1,2 Go | ✅ Totale |
| `llama3.2:3b` (Ollama) | THINK léger | 2 Go | ✅ Totale |
| `qwen2.5-coder:7b` (Ollama) | THINK code | 4,7 Go | ✅ Totale |
| `llama3.2-vision:11b` (Ollama) | SENSE multimodal | 6 Go | ✅ Totale |

**Recommandation locale** : `nomic-embed-text` + `qwen2.5-coder:7b` + `llama3.2:3b`. ~7 Go, tourne sur MacBook M1+.

## Solutions API (payantes, à la demande)

| Modèle | Usage | Coût/1M tokens | Qualité | Multimodal | Web search |
|---|---|---|---|---|---|
| `gemini-3-flash` | THINK économique, Strategic Intelligence, Creator | ~0,10€ | Bonne | ✅ | ✅ |
| `claude-sonnet-4-6` | THINK code, ACT repair/rebuild | ~3€ | Excellente | ✅ | ❌ |
| `gpt-5-4` | THINK code, ACT | ~2€ | Excellente | ✅ | ❌ |
| `claude-opus-4-8` | ACT reconstruction complexe | ~15€ | Maximale | ✅ | ❌ |

## Tableau de décision

| Usage | Modèle conseillé | Gratuit/Payant | Pourquoi |
|---|---|---|---|
| Scanner structure | Aucun (code JS) | Gratuit | Déterministe |
| Classification SENSE | `nomic-embed-text` local | Gratuit | Privacy totale |
| Compréhension THINK | `llama3.2:3b` local | Gratuit | Local |
| Analyse image SENSE | `llama3.2-vision` local | Gratuit | Multimodal local |
| Audit architecture THINK | `qwen2.5-coder:7b` local | Gratuit | Code local |
| Strategic Intelligence | `gemini-3-flash` | Payant | Économique, web search |
| Audit complexe THINK | `claude-sonnet-4-6` | Payant | Qualité max |
| Reconstruction ACT | `claude-sonnet-4-6` | Payant | Génération fiable |
| Documentation ACT | `gemini-3-flash` | Payant | Économique |

**Règle d'or** : local par défaut, cloud sur validation explicite, modèle le moins cher suffisant.

---

# 8. Logique d'orchestration — SENSE → THINK → ACT

## Flow : utilisateur importe un ZIP

```
Import ZIP
  ↓
[SENSE] Scanner + Reader + Vision (local, ~1s)
    → structure, types, technologies, métadonnées
  ↓
[SENSE] Classifier (embeddings locaux, ~2s)
    → catégories, étiquettes, score de confiance
  ↓
  ┌─ Si confiance < 70% ─→ [THINK] Memory Analyst (local LLM)
  │                       → rôle sémantique des éléments ambigus
  └─ Si confiance ≥ 70% ─→ skip (économie)
  ↓
[THINK] Context Engine
    → calcule le Project DNA (identité, humains, ressources, timeline, état)
  ↓
[THINK] Architecture Analyst
    → détecte les problèmes, évalue la maturité
  ↓
[THINK] Strategic Intelligence
    → produit Future Paths + Strategic Report (vue)
  ↓
[Présentation] Strategic Intelligence affiché à l'utilisateur
    → compréhension, probabilités, chemins possibles
    → AUCUNE modification. AIME montre, ne touche pas.
  ↓
  L'utilisateur choisit un chemin :
  ├─ Option A Continuer    → [ACT] Organizer (re-range)
  ├─ Option B Fusionner    → [ACT] Organizer + Repair (cloud)
  ├─ Option C Transformer  → [ACT] Creator + Rebuild (cloud)
  └─ Option D Archiver     → [ACT] Creator (fiche mémoire)
  ↓
[ACT] Validation explicite avant toute écriture
  ↓
[MEMORY CORE] Graph + Project DNA + Future Graph mis à jour (Base44 entities)
```

**Principe absolu** : aucune action de modification sans validation explicite. AIME propose, l'utilisateur décide.

---

# 9. Technologies backend

## Contrainte AIME

AIME est construit sur **Base44**. Le backend d'AIME CORE s'appuie sur :

- **Base44 entities** pour le Memory Graph (mémoire persistante) ;
- **Base44 backend functions** (`base44/functions/`) pour l'orchestration cloud et les appels LLM via `InvokeLLM` ;
- **Base44 UploadFile / UploadPrivateFile** pour le stockage des fichiers importés ;
- **Navigateur** pour tout ce qui est local (SENSE, embeddings, classification).

## Stack recommandée

| Besoin | Technologie | Local/Cloud |
|---|---|---|
| Stockage fichiers importés | Base44 UploadPrivateFile | Cloud (privé) |
| Memory Graph (relations) | Base44 entities | Cloud |
| Vector index (sémantique) | sqlite-vec WASM | Local |
| SENSE (scanner, readers, vision) | Web Workers JS | Local |
| Embeddings | transformers.js (`bge-m3`) ou Ollama | Local |
| LLM local (optionnel) | Ollama (sidecar) | Local |
| LLM cloud | Base44 `InvokeLLM` | Cloud |
| Extraction PDF | `pdf.js` | Local |
| Extraction Word/Excel | `mammoth.js` / `sheetjs` | Local |
| OCR images | `tesseract.js` | Local |
| Décompression ZIP | `fflate` WASM | Local |
| Import GitHub | connecteur Base44 `github` | Cloud (API) |
| Import Figma | API Figma REST | Cloud (API) |

## Pourquoi pas Supabase / Firebase / PostgreSQL externe ?

AIME est déjà sur Base44. Ajouter une base externe créerait un doublon de stockage (violation charte §23), une complexité d'ops inutile, et un risque de divergence des sources de vérité (violation charte §12).

**Décision** : rester sur Base44. Le Memory Graph est une couche d'entités au-dessus du stockage Base44 existant, pas une base séparée.

---

# 10. Import universel — Technologies

| Source | Technologie | Local | Coût |
|---|---|---|---|
| ZIP/RAR/7Z | `fflate` WASM | ✅ | 0 |
| Code JS/TS | `acorn` / `tree-sitter` | ✅ | 0 |
| PDF | `pdf.js` | ✅ | 0 |
| Word | `mammoth.js` | ✅ | 0 |
| Excel | `sheetjs` | ✅ | 0 |
| Image | `exifr` + embeddings | ✅ | 0 |
| OCR image | `tesseract.js` | ✅ | 0 |
| Vidéo meta | `ffmpeg.wasm` | ✅ | 0 |
| Figma | API Figma REST | ❌ (API) | 0 (quota) |
| GitHub | connecteur Base44 `github` | ❌ (API) | 0 (quota) |
| URL site | `fetch` + `DOMParser` | ❌ | 0 |

**Verdict** : l'import universel est réalisable à 100% en local navigateur, sauf Figma/GitHub qui nécessitent un token API (gratuit, quota).

---

# 11. Roadmap économique

## Phase 0 — Prototype gratuit (0€)

**Objectif** : prouver la valeur. Import ZIP → SENSE → classification → rapport déterministe.

- SENSE : Web Workers JS pur.
- Classification : `bge-m3` via transformers.js (navigateur).
- Rapport : généré localement, affiché dans l'UI.
- Stockage : Base44 entities (inclus dans le plan).
- LLM : aucun. Rapport déterministe.

**Budget** : 0€. Tout dans le navigateur + Base44.

## Phase 1 — Premier produit utilisable (0–20€/mois)

**Objectif** : THINK (compréhension + Project DNA + Strategic Intelligence).

- Memory Analyst / Context Engine : `llama3.2:3b` local OU `gemini-3-flash` cloud (~0,10€/1M tokens).
- Architecture Analyst : `qwen2.5-coder:7b` local OU `claude-sonnet` cloud sur validation.
- Strategic Intelligence : `gemini-3-flash`.
- Budget cloud estimé : 5–20€/mois (10–50 audits/mois).

**Budget max recommandé** : 20€/mois.

## Phase 2 — Version professionnelle (50–200€/mois)

**Objectif** : ACT (reconstruction, documentation auto), Memory Graph complet, Memory Desktop V2.

- Repair / Rebuild : `claude-sonnet-4-6` sur validation.
- Creator : `gemini-3-flash`.
- Memory Graph : entités Base44 + index vectoriel WASM.
- File System Access API pour watch dossier.
- Budget cloud estimé : 50–200€/mois selon volume.

## Phase 3 — Architecture entreprise (500€+/mois)

**Objectif** : AIME MEMORY DESKTOP complet, agents autonomes, GPU dédiés.

- Ollama sur serveur GPU dédié pour LLM lourds.
- Base44 scale-up.
- Cartographie du patrimoine numérique complet.
- Budget : 500€+/mois.

## Règle de progression

> Ne jamais passer à la phase suivante tant que la précédente n'est pas utilisée et validée par de vrais utilisateurs. Chaque phase doit être rentable ou gratuite avant d'investir dans la suivante.

---

# 12. Comparaison avec les outils existants

| Outil | Ce qu'il fait | Limite vs AIME CORE |
|---|---|---|
| **Notion AI** | Notes + IA générative | Pas de Memory Graph relationnel, pas d'import universel, pas de futurs possibles |
| **Manus** | Agent autonome généraliste | Pas de mémoire persistante, pas d'import local, tout au cloud, n'explore pas les chemins |
| **ChatGPT Projects** | Contexte de projet | Pas de mémoire structurelle, pas d'import universel, fermé |
| **Claude (Projects)** | Contexte de projet | Pas d'analyse de structure technique, pas de Memory Graph |
| **Cursor** | Éditeur de code IA | Limité au code, pas de documents/médias, pas de mémoire cross-projets |
| **Bolt** | Génération d'app depuis prompt | Pas d'import, pas de mémoire, pas d'audit |
| **Lovable** | Génération d'app | Idem Bolt, pas d'analyse de l'existant |
| **Base44** | Builder d'app + BaaS | Pas de AIME CORE, pas d'import universel, pas de Memory Graph |
| **Dropbox / Drive / Finder** | Stockage fichiers | Range des fichiers, ne comprend pas des projets |

## Ce qu'AIME CORE fait différemment

1. **Importer l'existant** — pas seulement générer du nouveau. AIME part de ce que l'utilisateur a déjà.
2. **Memory Graph relationnel** — pas seulement du contexte temporaire. Les relations persistent et traversent le temps.
3. **Project DNA** — un projet est un organisme vivant avec une identité, des humains, des ressources, une timeline, un état, et des futurs possibles.
4. **Future Graph** — AIME ne mémorise pas seulement le passé, il mémorise ce que le projet pourrait devenir.
5. **Strategic Intelligence** — AIME ne donne pas une solution, il explore les chemins possibles. C'est la différence avec Manus.
6. **Local-first** — pas tout au cloud. Privacy + coût maîtrisé.
7. **Comprendre avant d'agir** — jamais de modification sans Strategic Intelligence affiché et validé.
8. **Multi-format** — code + documents + médias + design, pas seulement du code.
9. **Mémoire cross-projets** — un fichier peut appartenir à plusieurs projets, une relation peut traverser le temps.
10. **Memory Desktop** — pas un explorateur de fichiers, un explorateur de projets vivants.

---

# 13. Décision finale — Recommandation AIME V1

## Technologies retenues

| Couche | Technologie | Local/Cloud |
|---|---|---|
| UI / SENSE | React + Web Workers | Local |
| Embeddings | `bge-m3` (transformers.js) | Local |
| Vector index | sqlite-vec WASM | Local |
| LLM local (optionnel) | Ollama `llama3.2` + `qwen2.5-coder` | Local |
| LLM cloud | Base44 `InvokeLLM` (`gemini-3-flash` défaut, `claude-sonnet` si besoin) | Cloud |
| Stockage fichiers | Base44 `UploadPrivateFile` | Cloud |
| Memory Graph | Base44 entities (`MemoryItem`, `MemoryRelation`, `MemoryVersion`, `MemoryContext`, `ProjectDNA`) | Cloud |
| Import ZIP | `fflate` WASM | Local |
| Import PDF | `pdf.js` | Local |
| Import GitHub | connecteur Base44 `github` | Cloud (API) |

## Capacités prioritaires (ordre de construction)

1. **SENSE — Scanner + Reader + Vision** (local, 0€) — fondation, sans IA.
2. **SENSE — Classifier** (local embeddings, 0€) — catégorisation automatique.
3. **ORCHESTRATOR** (local, 0€) — machine à états.
4. **THINK — Memory Analyst + Context Engine** (local LLM, 0€) — compréhension + Project DNA.
5. **THINK — Strategic Intelligence** (cloud `gemini-3-flash`, ~0,01€) — Future Paths, le raisonnement façon Manus.
6. **ACT — Creator** (cloud `gemini-3-flash`, ~0,01€) — rapports et fiches mémoire.
7. **THINK — Architecture Analyst** (cloud `claude-sonnet`, ~0,03€) — audit technique.
8. **ACT — Repair / Rebuild** (cloud `claude-sonnet`, ~0,10€) — reconstruction sur validation.

## Coûts estimés V1

- **Phase 0 (prototype)** : 0€/mois. 100% local.
- **Phase 1 (MVP)** : 0–20€/mois. Local + `gemini-3-flash` ponctuel.
- **Phase 2 (pro)** : 50–200€/mois. `claude-sonnet` sur validation.

## Ordre de construction

1. Entités Base44 Memory Graph (`MemoryItem`, `MemoryRelation`, `MemoryVersion`, `ProjectDNA`).
2. Import ZIP navigateur (`fflate`) + SENSE Scanner (Web Worker).
3. SENSE Classifier (`bge-m3` embeddings locaux).
4. UI : bouton « + Importer dans AIME », Strategic Intelligence visuel.
5. THINK Memory Analyst + Context Engine (Ollama local ou `InvokeLLM` cloud).
6. THINK Strategic Intelligence (rapport avec Future Paths).
7. ACT Creator (rapports, fiches mémoire).
8. THINK Architecture Analyst + ACT Repair (sur validation explicite).
9. Memory Graph complet (relations + recherche sémantique + Future Graph).

## Risques

- **Performance navigateur** : gros ZIP / gros embeddings peuvent bloquer l'UI. Mitigation : Web Workers + traitement par lots.
- **Modèles locaux lourds** : `bge-m3` = 1,2 Go à télécharger. Mitigation : lazy-load, cache IndexedDB.
- **Ollama non installé** : la majorité des utilisateurs n'aura pas Ollama. Mitigation : fallback cloud `InvokeLLM` transparent.
- **Coût cloud non maîtrisé** : un utilisateur peut lancer 100 audits. Mitigation : quota par utilisateur + validation explicite avant chaque appel cloud.
- **Privacy des fichiers importés** : un ZIP peut contenir des données sensibles. Mitigation : local-first par défaut, cloud uniquement sur validation.

## Limites V1

- Pas de sync multi-appareils (phase 2).
- Pas d'agents autonomes en arrière-plan (phase 3).
- Pas de reconstruction automatique (toujours validé).
- Pas de Memory Desktop (phase 2–3).
- Pas de connecteur Figma natif (API REST manuelle en V1).

## Prochaines étapes

1. Valider cet audit.
2. Créer les entités Base44 Memory Graph.
3. Construire SENSE (Scanner + import ZIP).
4. Construire SENSE Classifier + embeddings locaux.
5. Construire l'UI d'import et le Strategic Intelligence.
6. Brancher THINK (cloud `gemini-3-flash` par défaut).
7. Itérer avec de vrais imports utilisateurs.

---

## Verdict architecture

Avec ces corrections, AIME passe d'un :

**« outil IA qui analyse des fichiers »**

à :

**« système cognitif capable de comprendre l'évolution des projets humains. »**

La vraie innovation n'est plus l'IA.

La vraie innovation est :

**la mémoire relationnelle + la compréhension du contexte + l'exploration des futurs possibles.**

C'est cette combinaison qui différencie AIME de Notion AI, Manus, Cursor, Bolt, Lovable ou ChatGPT Projects.

---

## Le top du top pour ce concept

**La combinaison gagnante** :

1. **AIME CORE™ comme OS cognitif complet** — Memory Engine devient la couche mémoire, pas le produit entier.
2. **Local-first absolu** : SENSE + embeddings tournent dans le navigateur. 0€, privacy totale.
3. **Base44 comme socle** : pas de base externe. Le Memory Graph est une couche d'entités au-dessus du stockage existant.
4. **LLM hybride intelligent** : `gemini-3-flash` (économique) pour 80% des tâches THINK, `claude-sonnet` (qualité) pour les 20% difficiles et ACT, local `qwen2.5-coder` pour les utilisateurs équipés.
5. **Memory Graph hybride** : relations en entités Base44 (déterministe) + embeddings en index WASM local (sémantique). Pas de Neo4j, pas de Pinecone.
6. **Project DNA** — un projet est un organisme vivant, pas un dossier. Chaque projet a une empreinte avec ses futurs possibles.
7. **Future Graph** — propriété native de Project DNA. AIME ne mémorise pas seulement le passé, il mémorise ce que le projet pourrait devenir.
8. **Strategic Intelligence™** — AIME ne donne pas une solution, il explore les chemins possibles. C'est la différence avec Manus.
9. **SENSE / THINK / ACT** — le modèle mental universel d'AIME, aussi mémorisable que « Search » pour Google ou « Think Different » pour Apple.
10. **Validation avant action** : AIME ne touche jamais sans accord. SENSE observe, THINK propose, ACT exécute après validation.
11. **Progressif** : Phase 0 gratuite → Phase 1 à 20€ → Phase 2 à 200€ → Phase 3 Memory Desktop. Chaque phase rentable avant la suivante.

## Formulation définitive à figer dans la charte AIME

> **AIME ne gère pas des fichiers.**
>
> **AIME comprend des projets humains.**
>
> **AIME CORE™ est un système d'exploitation cognitif qui transforme les traces numériques des humains en projets vivants, compréhensibles et évolutifs.**
>
> **AIME MEMORY ENGINE™ est la mémoire vivante d'AIME CORE™, capable de transformer les traces numériques en connaissance relationnelle, contextuelle et évolutive.**

---

## Verdict final

✅ **AIME CORE™ = OS cognitif complet**
✅ **Memory Engine = couche mémoire**
✅ **Memory Graph = système nerveux**
✅ **Project DNA = ADN des projets vivants**
✅ **Future Graph = imagination structurée du futur**
✅ **Strategic Intelligence™ = interface décisionnelle**
✅ **SENSE / THINK / ACT = modèle mental universel**
✅ **Memory Desktop™ = conséquence future naturelle**

> **AIME n'est pas un outil qui utilise l'intelligence artificielle.**
>
> **AIME est une architecture qui donne une mémoire, une compréhension et une capacité d'évolution aux projets humains.**

---

*Document stratégique définitif — AIME CORE™ Architecture V1 définitive — référence pour la construction.*