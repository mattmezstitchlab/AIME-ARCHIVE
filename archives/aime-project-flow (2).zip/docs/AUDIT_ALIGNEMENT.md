# AIME — Audit d'alignement avec la vision produit

> Référence : `docs/PRODUCT_VISION.md`
> Date : 2026-08-04
> Objectif : identifier ce qui est conforme, à corriger, à déplacer/renommer, redondant, manquant, et les priorités.

## 1. Ce qui est déjà conforme à la vision

### Socle universel — Dashboard
- `src/pages/Home.jsx` agit comme Tableau de bord / Cockpit. ✅ Conforme : c'est le cœur opérationnel.
- `src/components/dashboard/AssociationDashboard.jsx` affiche données réelles (projets, alertes, documents). ✅
- `src/components/Layout.jsx` — navigation latérale regroupée par section (Vue d'ensemble, Projets & dossiers, Organisation, Intelligence). ✅ Structure cohérente.

### Outils universels présents
- **Documents** : `src/pages/Documents.jsx` + entité `Document` + `DocumentTemplate` + `documentEngine.js`. ✅
- **Budget** : entités `Budget`, `LigneBudgetaire`, `ProjectBudgetItem`, `Depense`. ✅
- **Tâches** : entité `Tache`. ✅
- **Calendrier / Événements** : `src/pages/Evenements.jsx` + entité `Evenement`. ✅
- **Réunions** : `src/pages/Reunions.jsx` + entité `Reunion`. ✅
- **Équipe / Membres** : `src/pages/Membres.jsx` + entité `Membre`. ✅
- **Contacts / Partenaires** : `src/pages/Partenaires.jsx` + entité `Partenaire`. ✅
- **Médias** : entité `PublicPageMedia`. ✅ (mais non intégré au Dashboard — voir §4)
- **Justificatifs / Scan** : `src/pages/Scan.jsx` + entité `Justificatif`. ✅ Correspond à « déposez ce que vous avez ».
- **Vigilance** : `src/pages/Vigilance.jsx`. ✅ Correspond à « AIME identifie ce qui manque ».

### Contexte intelligent
- `src/lib/projectContexts.js` définit les contextes (mariage, artiste, association, business). ✅
- `src/components/project-context/` — modules spécialisés (Budget, Guests, Vendors, Seating, Tasks, Planning, Gallery, Documents, Messages, Overview, Settings). ✅ Correspond à « le contexte active des outils spécialisés ».
- `src/lib/sectionRecommendations.js` — recommandations de sections par contexte. ✅

### Présence publique
- `src/pages/PublicPage.jsx` + entité `PersonalPublicPage` + `PublicPageSection`. ✅
- `src/pages/ProjectPage.jsx` — page projet contextuelle. ✅
- `src/pages/StudioPage.jsx` — Studio de création de page publique. ✅ (mais positionnement à corriger — voir §2)

### Agent AIME
- `src/pages/Agent.jsx` + `src/lib/aimeAgent.js`. ✅ Option avancée, toggle dans la sidebar. ✅ Conforme : c'est optionnel.

### Import & analyse
- `src/components/landing/ImportMenu.jsx` — import documents, images, conversations, URL, dossier. ✅ Correspond à « déposez ce que vous avez ».
- `src/components/landing/DocumentAnalysis.jsx` — animation d'analyse. ✅ Correspond à « AIME analyse et classe ».
- `src/pages/Scan.jsx` — scan de justificatifs avec extraction. ✅

### Architecture technique
- Isolation multi-tenant via `association_id` + RLS sur toutes les entités associatives. ✅
- Design system unifié (Inter/Manrope, neutre blanc/gris, accents verts). ✅

---

## 2. Ce qui doit être corrigé

### Landing — promesse hors-sujet
- **`src/lib/landingDefaults.js`** : titre actuel « Transformez une idée en projet vivant » + sous-titre « Décrivez votre besoin, ajoutez vos fichiers… ». ❌ Trop orienté « création ». La promesse doit être : **« Déposez ce que vous avez. Décrivez ce que vous voulez. AIME organise le reste. »**
- **`src/components/landing/HeroSection.jsx`** : le hero ne met pas en avant l'import de documents existants comme action première. Le `ProjectBox` privilégie la saisie texte. ❌ L'import doit être aussi visible que la description.
- **`src/components/landing/PromiseSection.jsx`** : utilise un dégradé `violet-500/fuchsia-500` dans le bloc « Après ». ❌ Incohérent avec le design system neutre (dead-end déjà identifié : teintes violettes à proscrire).
- **`src/components/landing/ExamplesBar.jsx`** : exemples orientés « Créer un X ». ❌ Devraient illustrer l'import + l'organisation, pas seulement la création.
- **`src/components/landing/ContextSelector.jsx`** : propose « Site internet » et « Document professionnel » comme contextes. ❌ La page publique n'est pas un contexte, c'est une valeur ajoutée. À repositionner.

### Studio — positionnement à clarifier
- **`src/pages/StudioPage.jsx`** est présenté comme point d'entrée principal (« Donnez une identité à votre projet »). ❌ Selon la vision, le Studio est l'espace de **personnalisation de la présence publique**, pas le cœur du produit. Le Dashboard doit être l'entrée principale.
- **`src/components/Layout.jsx`** : « Ma Page AIME » (`/studio/page`) est placé dans « Vue d'ensemble », au même niveau que le Tableau de bord. ❌ La page publique est une valeur ajoutée, pas le produit principal. À déplacer ou repositionner hiérarchiquement.

### Dashboard — centralisation incomplète
- **`src/pages/Home.jsx`** affiche des « Actions rapides » (Raconter un projet, Parler à AIME, Ajouter un document, etc.) mais ne centralise pas visuellement l'ensemble des outils universels (messages, contacts, calendrier, équipe) comme un vrai cockpit unifié. ❌ Le Dashboard doit être le point d'entrée unique vers tous les outils, pas une liste d'actions rapides + un composer.
- **Médias** non intégrés au Dashboard. ❌ L'entité `PublicPageMedia` existe mais n'est pas accessible depuis le Dashboard.

---

## 3. Ce qui doit être déplacé ou renommé

| Élément actuel | Problème | Action recommandée |
|---|---|---|
| `/studio/page` dans « Vue d'ensemble » | La page publique est une valeur ajoutée, pas le cœur | Déplacer dans un groupe « Présence publique » ou sous « Projets & dossiers » |
| `ContextSelector` — option « Site internet » | La page publique n'est pas un contexte | Retirer ; la page publique se génère depuis le projet |
| `ExamplesBar` — « Créer mon entreprise » etc. | Orientés création pure | Reformuler en exemples d'import/organisation |
| `PromiseSection` bloc « Après » | Dégradé violet/fuchsia | Remplacer par accent neutre conforme au design system |

---

## 4. Ce qui est redondant

- **`ProjectComposer` (Home) vs `StudioStart`/`AimePrompt` (Studio)** : deux parcours de création de projet coexistent. Le composer du Dashboard et le Studio font double emploi sur la création. → Unifier : le Dashboard crée le projet (socle), le Studio personnalise la présence publique.
- **`CreateProjectPageDialog` (Home) vs `StudioPage`** : la création de page publique est accessible depuis deux endroits. → Le Studio doit être l'unique entrée de personnalisation publique.
- **`ContextSelector` (landing) vs `projectContexts.js`** : deux listes de contextes. → Une seule source de vérité dans `projectContexts.js`.
- **`ImportMenu` (landing) vs `Scan.jsx`** : l'import de documents existe côté landing (décoratif) et côté Dashboard (fonctionnel via Scan). → L'import réel doit vivre dans le Dashboard ; la landing n'a qu'un rôle démonstratif.

---

## 5. Ce qui manque réellement

### Manquant pour le Dashboard universel
- **Vue Messages** : aucune entité/section « messages » centralisée dans le Dashboard (les `ProjectMessage` existent mais sont liés au projet mariage uniquement). → Entité `Message` universelle ou section agrégée.
- **Vue Contacts** : aucune entité « contacts » générique (les `Partenaire` et `ProjectGuest` sont spécialisés). → Entité `Contact` universelle ou vue agrégée.
- **Vue Calendrier unifié** : `Evenement` + `Reunion` + `Tache.due_date` existent mais ne sont pas agrégés en un calendrier unique. → Vue calendrier agrégée dans le Dashboard.
- **Vue Équipe** : `Membre` existe mais n'est pas présenté comme « équipe » dans le Dashboard universel (orienté association). → Repositionner en « Équipe & accès ».

### Manquant pour le parcours « déposez ce que vous avez »
- **Import multi-fichiers réel** : `ImportMenu` est décoratif sur la landing. Le Dashboard n'a pas d'import en masse (seul `Scan.jsx` importe un justificatif à la fois). → Import multi-documents dans le Dashboard avec analyse + classement automatique.
- **Analyse & classement automatique** : `aimeAgent.js` structure un projet depuis un prompt, mais il n'existe pas de flow « importe tes documents → AIME crée le projet + classe les fichiers ». → Backend function d'analyse multi-fichiers.

### Manquant pour la landing
- **Section « Comment ça marche »** : les étapes (Importer → Analyser → Dashboard → Outils auto → Page publique) ne sont pas explicitement présentées. → Section process.
- **Mise en avant de l'Agent AIME** comme option avancée. → Actuellement absent de la landing.

---

## 6. Priorités de mise en œuvre

### Priorité 1 — Aligner la landing (cohérence message)
1. Réécrire `landingDefaults.js` : promesse « Déposez ce que vous avez. Décrivez ce que vous voulez. AIME organise le reste. »
2. Refondre `HeroSection` : import de documents aussi visible que la description textuelle.
3. Corriger `PromiseSection` : retirer le dégradé violet/fuchsia, utiliser l'accent neutre.
4. Reformuler `ExamplesBar` : exemples d'import/organisation, pas seulement de création.
5. Ajouter une section « Comment ça marche » (Importer → Analyser → Dashboard → Outils auto → Page publique → Agent optionnel).
6. Retirer « Site internet » du `ContextSelector`.

### Priorité 2 — Repositionner Dashboard & Studio
1. Faire du Dashboard (`/`) l'entrée principale incontestée : centraliser l'accès à tous les outils universels.
2. Repositionner le Studio (`/studio/page`) comme espace de personnalisation de la présence publique, pas comme point d'entrée produit.
3. Déplacer « Ma Page AIME » dans la navigation (groupe « Présence publique » ou sous « Projets & dossiers »).
4. Dédoubler la création de projet : le Dashboard crée le socle, le Studio personnalise la page publique.

### Priorité 3 — Compléter le Dashboard universel
1. Vue Messages agrégée.
2. Vue Contacts universelle.
3. Calendrier unifié (événements + réunions + tâches).
4. Import multi-documents avec analyse automatique.
5. Intégration des Médias au Dashboard.

### Priorité 4 — Parcours « déposez ce que vous avez »
1. Backend function d'analyse multi-fichiers (import → contexte → socle + classement).
2. Flow Dashboard : importer → AIME propose le contexte et active les outils.

---

## 7. Synthèse

L'architecture technique existante est **largement conforme** à la vision : entités universelles, contexte intelligent, page publique, Agent optionnel, RLS multi-tenant, design system unifié.

Les écarts principaux sont **de positionnement et de message** :
- La landing parle encore de « création » au lieu de « organisation ».
- Le Studio est présenté comme le cœur du produit au lieu du Dashboard.
- Le Dashboard n'est pas encore le cockpit unifié complet.

Aucune reconstruction nécessaire. Les corrections sont des **repositionnements** et des **complétions** — pas des refontes.

**L'objectif : une architecture cohérente autour de**
`AIME → Projet → Dashboard universel → Contexte intelligent → Outils spécialisés automatiques → Présence publique → Agent AIME optionnel