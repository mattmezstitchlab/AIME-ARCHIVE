# Plan de compatibilité vers AI·ME Core Universel

Ce document décrit uniquement une trajectoire progressive. Aucune entité existante
n'est supprimée ou migrée par ce plan — il prépare les futures abstractions sans
casser le module Mariage (produit pilote).

## Principe

Chaque entité "Wedding*" ou associative actuelle deviendra, à terme, une
spécialisation d'une entité Core générique. La transition se fait par
**ajout de champs de liaison optionnels**, jamais par suppression.

## Correspondances prévues (non actives)

| Entité actuelle       | Future entité Core         | Stratégie de liaison |
|-----------------------|-----------------------------|------------------------|
| Association           | Workspace                   | `workspace_id` optionnel ajouté à Association, alias en lecture |
| AimeProject            | Project                     | AimeProject devient la table Project ; `category`/`archetype` déjà génériques |
| WeddingParticipant     | ProjectParticipant           | Ajouter `participant_kind` générique ; garder les champs mariage (role, category) tant que le module pilote les utilise |
| WeddingTimelineItem    | ProjectTimelineItem           | Structure déjà générique (title/start_time/duration) — renommage d'affichage uniquement |
| ProjectDocument (déjà générique) | (inchangé)          | Sert déjà de base commune |
| (à créer plus tard)   | ProjectBudgetLine, ProjectResource | Nouvelles entités additives, sans impact sur l'existant |

## Étapes futures (non exécutées maintenant)

1. Introduire les entités Core comme **vues additives** (pas de migration de données).
2. Faire pointer les nouveaux archétypes (artiste, entreprise) vers les entités Core directement.
3. Le module Mariage continue d'utiliser WeddingParticipant/WeddingTimelineItem sans changement.
4. Une fois un second archétype pleinement opérationnel sur le Core, envisager une
   migration progressive et réversible du Mariage, projet par projet, avec double-écriture
   temporaire — jamais un remplacement en masse.

## Risques identifiés

- Toute tentative de fusion prématurée casserait le produit pilote (Mariage).
- Le portail prestataire et les documents dépendent aujourd'hui directement de
  `WeddingParticipant`/`ProjectDocument` — une migration doit garder ces chemins fonctionnels.