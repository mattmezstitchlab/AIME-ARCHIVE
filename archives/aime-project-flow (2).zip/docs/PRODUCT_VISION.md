# AIME — Vision produit fondamentale

> Document de référence principal. Source de vérité pour toute décision UX, UI, technique et fonctionnelle.

## Ce qu'est AIME

AIME n'est pas un créateur de sites.
AIME n'est pas un outil d'association.
AIME n'est pas un Studio de pages.

**AIME est un système universel d'organisation et d'automatisation des projets humains.**

Chaque personne, association, entreprise, artiste ou organisateur possède des informations dispersées :
documents, devis, factures, contrats, messages, fichiers, images, budgets, contacts, tâches et événements.

Aujourd'hui, ces informations sont réparties entre de nombreux outils :
emails, messageries, dossiers, tableurs, calendriers, logiciels administratifs et sites internet.

**AIME rassemble ces éléments dans un seul espace.**

## Le parcours universel

1. L'utilisateur décrit son projet **ou** importe ses documents existants.
2. AIME analyse le contexte, identifie les informations, classe les fichiers, crée les catégories nécessaires, relie les données et prépare automatiquement les outils utiles.
3. L'utilisateur ne construit pas son organisation. AIME prépare le socle adapté au projet.

AIME ne demande pas : « Quels outils souhaitez-vous utiliser ? »
AIME demande : « Quel est votre projet ? » — puis il prépare ce qui est nécessaire.

## Architecture cible

```
AIME
  └─ Projet
       ├─ Dashboard universel (cœur opérationnel commun)
       │    ├─ Documents
       │    ├─ Budget
       │    ├─ Devis / Factures / Contrats
       │    ├─ Messages
       │    ├─ Contacts
       │    ├─ Tâches
       │    ├─ Calendrier / Événements
       │    ├─ Équipe
       │    ├─ Accès & permissions
       │    ├─ Médias
       │    └─ Automatisations
       │
       ├─ Contexte intelligent (active les outils spécialisés)
       │    ├─ Association → admin, finances, membres, bénévoles, actions, événements
       │    ├─ Mariage → invités, prestataires, budget, planning, documents
       │    ├─ Entreprise → clients, projets, devis, factures, contrats, équipe
       │    └─ Artiste → prestations, dates, médias, documents, relations pro
       │
       ├─ Présence publique (valeur ajoutée commune, générée depuis le projet)
       │    └─ Association · Entreprise · Artiste · Mariage · Événement · Collectif · Personnel
       │
       └─ Agent AIME (option avancée — accompagne et automatise)
```

## Principes directeurs

- **Socle universel** : un Dashboard commun à tous les projets, quel que soit le contexte.
- **Contexte intelligent** : le type de projet active automatiquement les outils spécialisés pertinents.
- **Organisation sans effort** : l'utilisateur ne choisit pas les dossiers, tableaux ou modules. AIME prépare le socle.
- **Page publique = vitrine vivante du projet** : générée à partir de l'identité, du contexte et des informations. Ce n'est pas un produit séparé ni le produit principal.
- **Agent AIME = option avancée** : accompagne et automatise, mais n'est jamais obligatoire pour utiliser AIME.
- **Réduction des décisions techniques** : AIME demande « Quel est votre projet ? », jamais « Quels outils voulez-vous ? ».

## Promesse principale

> **« Déposez ce que vous avez. Décrivez ce que vous voulez. AIME organise le reste. »**

## Ce que la landing doit mettre en avant

1. L'import de documents, devis, factures, contrats, messages, images et fichiers.
2. L'analyse et le classement automatique.
3. La création du Dashboard et des outils adaptés.
4. L'activation automatique des fonctions selon le contexte.
5. La génération d'une page publique personnalisée.
6. L'Agent AIME comme option avancée pour accompagner et automatiser le projet.

## Règles de gouvernance des évolutions

- Ne pas reconstruire l'application entièrement.
- Ne pas ajouter de nouvelles fonctionnalités sans vérifier si une fonctionnalité équivalente existe déjà.
- Conserver et réutiliser les fonctionnalités existantes lorsqu'elles sont cohérentes avec la vision.
- Ne pas créer de doublons ni de nouveaux modules avant d'avoir identifié ce qui existe déjà.
- Toute évolution doit servir l'architecture : AIME → Projet → Dashboard universel → Contexte intelligent → Outils spécialisés automatiques → Présence publique → Agent AIME optionnel.

---

*Ce document guide toutes les prochaines évolutions. Il est la référence unique pour trancher les arbitrages produit.*