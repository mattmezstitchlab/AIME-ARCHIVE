import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import {
  getAllLearningPaths,
  getLearningPathBySlug,
  getCoursesByPathId,
  getCourseBySlug,
  getLessonsByCourseId,
  getLessonBySlug,
  getUserProgress,
  getUserCourseProgress,
  getAllBadges,
  getUserBadges,
  getAllGlossaryTerms,
  getGlossaryTermBySlug,
  getAllProjects,
  getFeaturedProjects,
  getProjectBySlug,
  getAllForumPosts,
  getForumPostBySlug,
  getForumRepliesByPostId,
  getAllEvents,
  getFeaturedEvents,
  getEventBySlug,
  getAllExperts,
  getExpertBySlug,
  getAllAnnouncements,
  getFeaturedAnnouncements,
  getDb,
  getUserByOpenId,
} from "./db";
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import {
  learningPaths,
  courses,
  lessons,
  userProgress,
  forumPosts,
  forumReplies,
} from "../drizzle/schema";
import { eq, and } from "drizzle-orm";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Learning paths
  learningPaths: router({
    list: publicProcedure.query(async () => {
      return getAllLearningPaths();
    }),

    getBySlug: publicProcedure
      .input(z.object({ slug: z.string() }))
      .query(async ({ input }) => {
        const path = await getLearningPathBySlug(input.slug);
        if (!path) {
          throw new TRPCError({ code: "NOT_FOUND" });
        }
        return path;
      }),

    getWithCourses: publicProcedure
      .input(z.object({ slug: z.string() }))
      .query(async ({ input }) => {
        const path = await getLearningPathBySlug(input.slug);
        if (!path) {
          throw new TRPCError({ code: "NOT_FOUND" });
        }
        const pathCourses = await getCoursesByPathId(path.id);
        return { ...path, courses: pathCourses };
      }),
  }),

  // Courses
  courses: router({
    getBySlug: publicProcedure
      .input(z.object({ slug: z.string() }))
      .query(async ({ input }) => {
        const course = await getCourseBySlug(input.slug);
        if (!course) {
          throw new TRPCError({ code: "NOT_FOUND" });
        }
        return course;
      }),

    getWithLessons: publicProcedure
      .input(z.object({ slug: z.string() }))
      .query(async ({ input }) => {
        const course = await getCourseBySlug(input.slug);
        if (!course) {
          throw new TRPCError({ code: "NOT_FOUND" });
        }
        const courseLessons = await getLessonsByCourseId(course.id);
        return { ...course, lessons: courseLessons };
      }),
  }),

  // Lessons
  lessons: router({
    getBySlug: publicProcedure
      .input(z.object({ slug: z.string() }))
      .query(async ({ input }) => {
        const lesson = await getLessonBySlug(input.slug);
        if (!lesson) {
          throw new TRPCError({ code: "NOT_FOUND" });
        }
        return lesson;
      }),
  }),

  // User progress
  progress: router({
    getUserProgress: protectedProcedure
      .input(z.object({ courseId: z.number() }))
      .query(async ({ ctx, input }) => {
        return getUserProgress(ctx.user.id, input.courseId);
      }),

    getAllUserProgress: protectedProcedure.query(async ({ ctx }) => {
      return getUserCourseProgress(ctx.user.id);
    }),

    markLessonComplete: protectedProcedure
      .input(z.object({ lessonId: z.number(), courseId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) {
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        }

        const existing = await getUserByOpenId(ctx.user.openId);
        if (!existing) {
          throw new TRPCError({ code: "UNAUTHORIZED" });
        }

        const result = await db
          .insert(userProgress)
          .values({
            userId: existing.id,
            courseId: input.courseId,
            lessonId: input.lessonId,
            completed: true,
            completedAt: new Date(),
            score: 100,
          })
          .onDuplicateKeyUpdate({
            set: {
              completed: true,
              completedAt: new Date(),
              score: 100,
            },
          });

        return { success: true };
      }),
  }),

  // Badges
  badges: router({
    list: publicProcedure.query(async () => {
      return getAllBadges();
    }),

    getUserBadges: protectedProcedure.query(async ({ ctx }) => {
      const existing = await getUserByOpenId(ctx.user.openId);
      if (!existing) {
        throw new TRPCError({ code: "UNAUTHORIZED" });
      }
      return getUserBadges(existing.id);
    }),
  }),

  // Glossary
  glossary: router({
    list: publicProcedure.query(async () => {
      return getAllGlossaryTerms();
    }),

    getBySlug: publicProcedure
      .input(z.object({ slug: z.string() }))
      .query(async ({ input }) => {
        const term = await getGlossaryTermBySlug(input.slug);
        if (!term) {
          throw new TRPCError({ code: "NOT_FOUND" });
        }
        return term;
      }),
  }),

  // Projects
  projects: router({
    list: publicProcedure.query(async () => {
      return getAllProjects();
    }),

    featured: publicProcedure.query(async () => {
      return getFeaturedProjects();
    }),

    getBySlug: publicProcedure
      .input(z.object({ slug: z.string() }))
      .query(async ({ input }) => {
        const project = await getProjectBySlug(input.slug);
        if (!project) {
          throw new TRPCError({ code: "NOT_FOUND" });
        }
        return project;
      }),
  }),

  // Forum
  forum: router({
    posts: router({
      list: publicProcedure.query(async () => {
        return getAllForumPosts();
      }),

      getBySlug: publicProcedure
        .input(z.object({ slug: z.string() }))
        .query(async ({ input }) => {
          const post = await getForumPostBySlug(input.slug);
          if (!post) {
            throw new TRPCError({ code: "NOT_FOUND" });
          }
          return post;
        }),

      create: protectedProcedure
        .input(
          z.object({
            title: z.string().min(5),
            content: z.string().min(10),
            tags: z.array(z.string()).optional(),
          })
        )
        .mutation(async ({ ctx, input }) => {
          const db = await getDb();
          if (!db) {
            throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
          }

          const existing = await getUserByOpenId(ctx.user.openId);
          if (!existing) {
            throw new TRPCError({ code: "UNAUTHORIZED" });
          }

          const slug = input.title
            .toLowerCase()
            .replace(/[^a-z0-9]+/g, "-")
            .replace(/^-+|-+$/g, "");

          const result = await db.insert(forumPosts).values({
            userId: existing.id,
            title: input.title,
            content: input.content,
            tags: input.tags ? JSON.stringify(input.tags) : null,
            slug,
          });

          return { success: true, id: result[0] };
        }),
    }),

    replies: router({
      getByPostId: publicProcedure
        .input(z.object({ postId: z.number() }))
        .query(async ({ input }) => {
          return getForumRepliesByPostId(input.postId);
        }),

      create: protectedProcedure
        .input(
          z.object({
            postId: z.number(),
            content: z.string().min(5),
          })
        )
        .mutation(async ({ ctx, input }) => {
          const db = await getDb();
          if (!db) {
            throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
          }

          const existing = await getUserByOpenId(ctx.user.openId);
          if (!existing) {
            throw new TRPCError({ code: "UNAUTHORIZED" });
          }

          await db.insert(forumReplies).values({
            postId: input.postId,
            userId: existing.id,
            content: input.content,
          });

          return { success: true };
        }),
    }),
  }),

  // Events
  events: router({
    list: publicProcedure.query(async () => {
      return getAllEvents();
    }),

    featured: publicProcedure.query(async () => {
      return getFeaturedEvents();
    }),

    getBySlug: publicProcedure
      .input(z.object({ slug: z.string() }))
      .query(async ({ input }) => {
        const event = await getEventBySlug(input.slug);
        if (!event) {
          throw new TRPCError({ code: "NOT_FOUND" });
        }
        return event;
      }),
  }),

  // Experts
  experts: router({
    list: publicProcedure.query(async () => {
      return getAllExperts();
    }),

    getBySlug: publicProcedure
      .input(z.object({ slug: z.string() }))
      .query(async ({ input }) => {
        const expert = await getExpertBySlug(input.slug);
        if (!expert) {
          throw new TRPCError({ code: "NOT_FOUND" });
        }
        return expert;
      }),
  }),

  // Announcements
  announcements: router({
    list: publicProcedure.query(async () => {
      return getAllAnnouncements();
    }),

    featured: publicProcedure.query(async () => {
      return getFeaturedAnnouncements();
    }),
  }),
});

export type AppRouter = typeof appRouter;
