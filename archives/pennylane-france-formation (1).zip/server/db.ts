import { eq, desc, and, isNull } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  users,
  learningPaths,
  courses,
  lessons,
  userProgress,
  badges,
  userBadges,
  glossaryTerms,
  projects,
  forumPosts,
  forumReplies,
  events,
  experts,
  announcements,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod", "bio", "avatar"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db
    .select()
    .from(users)
    .where(eq(users.openId, openId))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Learning paths queries
export async function getAllLearningPaths() {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(learningPaths).orderBy(learningPaths.order);
}

export async function getLearningPathBySlug(slug: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(learningPaths)
    .where(eq(learningPaths.slug, slug))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Courses queries
export async function getCoursesByPathId(pathId: number) {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(courses)
    .where(eq(courses.learningPathId, pathId))
    .orderBy(courses.order);
}

export async function getCourseBySlug(slug: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(courses)
    .where(eq(courses.slug, slug))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Lessons queries
export async function getLessonsByCourseId(courseId: number) {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(lessons)
    .where(eq(lessons.courseId, courseId))
    .orderBy(lessons.order);
}

export async function getLessonBySlug(slug: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(lessons)
    .where(eq(lessons.slug, slug))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// User progress queries
export async function getUserProgress(userId: number, courseId: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(userProgress)
    .where(and(eq(userProgress.userId, userId), eq(userProgress.courseId, courseId)))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getUserProgressByLesson(userId: number, lessonId: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(userProgress)
    .where(and(eq(userProgress.userId, userId), eq(userProgress.lessonId, lessonId)))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getUserCourseProgress(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(userProgress).where(eq(userProgress.userId, userId));
}

// Badges queries
export async function getAllBadges() {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(badges);
}

export async function getUserBadges(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(userBadges)
    .where(eq(userBadges.userId, userId));
}

// Glossary queries
export async function getAllGlossaryTerms() {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(glossaryTerms).orderBy(glossaryTerms.term);
}

export async function getGlossaryTermBySlug(slug: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(glossaryTerms)
    .where(eq(glossaryTerms.slug, slug))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Projects queries
export async function getAllProjects() {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(projects).orderBy(projects.order);
}

export async function getFeaturedProjects() {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(projects)
    .where(eq(projects.featured, true))
    .orderBy(projects.order);
}

export async function getProjectBySlug(slug: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(projects)
    .where(eq(projects.slug, slug))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Forum queries
export async function getAllForumPosts() {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(forumPosts).orderBy(desc(forumPosts.createdAt));
}

export async function getForumPostBySlug(slug: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(forumPosts)
    .where(eq(forumPosts.slug, slug))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getForumRepliesByPostId(postId: number) {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(forumReplies)
    .where(eq(forumReplies.postId, postId))
    .orderBy(desc(forumReplies.createdAt));
}

// Events queries
export async function getAllEvents() {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(events).orderBy(desc(events.startDate));
}

export async function getFeaturedEvents() {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(events)
    .where(eq(events.featured, true))
    .orderBy(desc(events.startDate));
}

export async function getEventBySlug(slug: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(events)
    .where(eq(events.slug, slug))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Experts queries
export async function getAllExperts() {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(experts).orderBy(experts.name);
}

export async function getExpertBySlug(slug: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(experts)
    .where(eq(experts.slug, slug))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Announcements queries
export async function getAllAnnouncements() {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(announcements).orderBy(desc(announcements.publishedAt));
}

export async function getFeaturedAnnouncements() {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(announcements)
    .where(eq(announcements.featured, true))
    .orderBy(desc(announcements.publishedAt));
}
