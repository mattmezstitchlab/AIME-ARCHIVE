import { drizzle } from "drizzle-orm/mysql2";
import mysql from "mysql2/promise";
import {
  learningPaths,
  courses,
  lessons,
  badges,
  glossaryTerms,
  projects,
  events,
  experts,
  announcements,
} from "../drizzle/schema.ts";

const DATABASE_URL = process.env.DATABASE_URL;

async function seed() {
  if (!DATABASE_URL) {
    throw new Error("DATABASE_URL not set");
  }

  const connection = await mysql.createConnection(DATABASE_URL);
  const db = drizzle(connection);

  console.log("🌱 Seeding database...");

  // Learning paths
  const pathsData = [
    {
      slug: "fondamentaux",
      title: "Fondamentaux du Calcul Quantique",
      description: "Découvrez les concepts essentiels du calcul quantique et apprenez à utiliser PennyLane.",
      level: "débutant",
      order: 1,
      icon: "Zap",
      color: "#7c3aed",
    },
    {
      slug: "qml",
      title: "Apprentissage Automatique Quantique",
      description: "Explorez les algorithmes QML et leurs applications pratiques avec PennyLane.",
      level: "intermédiaire",
      order: 2,
      icon: "Brain",
      color: "#0891b2",
    },
    {
      slug: "optimisation",
      title: "Optimisation et Applications Industrielles",
      description: "Résolvez des problèmes d'optimisation réels avec les algorithmes quantiques.",
      level: "avancé",
      order: 3,
      icon: "Cpu",
      color: "#06b6d4",
    },
  ];

  for (const path of pathsData) {
    await db.insert(learningPaths).values(path);
  }

  console.log("✅ Learning paths seeded");

  // Courses
  const coursesData = [
    {
      slug: "intro-qubits",
      learningPathId: 1,
      title: "Introduction aux Qubits",
      description: "Comprendre les qubits, les portes quantiques et les circuits simples.",
      order: 1,
      duration: 120,
    },
    {
      slug: "pennylane-basics",
      learningPathId: 1,
      title: "Débuter avec PennyLane",
      description: "Installer PennyLane et créer vos premiers circuits quantiques.",
      order: 2,
      duration: 90,
    },
    {
      slug: "qml-algorithms",
      learningPathId: 2,
      title: "Algorithmes QML Fondamentaux",
      description: "Variational Quantum Eigensolver (VQE) et autres algorithmes clés.",
      order: 1,
      duration: 180,
    },
    {
      slug: "optimization-problems",
      learningPathId: 3,
      title: "Résolution de Problèmes d'Optimisation",
      description: "QAOA et autres approches pour résoudre des problèmes industriels.",
      order: 1,
      duration: 240,
    },
  ];

  for (const course of coursesData) {
    await db.insert(courses).values(course);
  }

  console.log("✅ Courses seeded");

  // Lessons
  const lessonsData = [
    {
      slug: "qubit-basics",
      courseId: 1,
      title: "Qu'est-ce qu'un Qubit ?",
      type: "théorie",
      order: 1,
      content: "# Les Qubits : Fondamentaux du Calcul Quantique\n\nUn qubit (quantum bit) est l'unité fondamentale de l'information quantique. Contrairement à un bit classique qui peut être 0 ou 1, un qubit peut exister dans une superposition de ces deux états.\n\n## Propriétés Clés\n\n- **Superposition** : Un qubit peut être 0, 1, ou une combinaison linéaire des deux\n- **Intrication** : Plusieurs qubits peuvent être corrélés de manière non-classique\n- **Mesure** : La mesure d'un qubit le force à prendre une valeur définie (0 ou 1)",
      codeExample: null,
      resources: JSON.stringify([
        { title: "Documentation PennyLane", url: "https://pennylane.ai" },
        { title: "Quantum Computing Basics", url: "https://quantum-computing.ibm.com" }
      ]),
    },
    {
      slug: "pennylane-install",
      courseId: 2,
      title: "Installation et Configuration",
      type: "tutoriel",
      order: 1,
      content: "# Installation de PennyLane\n\nPennyLane est une bibliothèque Python pour le calcul quantique. Suivez ces étapes pour l'installer.",
      codeExample: "pip install pennylane\npip install pennylane-qiskit\n\nimport pennylane as qml\nfrom pennylane import numpy as np",
      resources: JSON.stringify([]),
    },
  ];

  for (const lesson of lessonsData) {
    await db.insert(lessons).values(lesson);
  }

  console.log("✅ Lessons seeded");

  // Badges
  const badgesData = [
    {
      slug: "first-circuit",
      title: "Premier Circuit",
      description: "Créez votre premier circuit quantique avec PennyLane.",
      icon: "⚡",
      condition: "complete_lesson_1",
    },
    {
      slug: "qml-master",
      title: "Maître du QML",
      description: "Complétez tous les modules d'apprentissage automatique quantique.",
      icon: "🧠",
      condition: "complete_course_3",
    },
    {
      slug: "community-contributor",
      title: "Contributeur Communautaire",
      description: "Partagez 5 projets avec la communauté.",
      icon: "👥",
      condition: "share_5_projects",
    },
  ];

  for (const badge of badgesData) {
    await db.insert(badges).values(badge);
  }

  console.log("✅ Badges seeded");

  // Glossary terms
  const glossaryData = [
    {
      slug: "qubit",
      term: "Qubit",
      definition: "Unité fondamentale de l'information quantique, pouvant exister en superposition de 0 et 1.",
      category: "Concepts de base",
      relatedTerms: JSON.stringify([2, 3]),
    },
    {
      slug: "superposition",
      term: "Superposition",
      definition: "État quantique où un système existe simultanément dans plusieurs états possibles.",
      category: "Concepts de base",
      relatedTerms: JSON.stringify([1]),
    },
    {
      slug: "intrication",
      term: "Intrication",
      definition: "Phénomène où deux ou plusieurs qubits sont corrélés de manière non-classique.",
      category: "Concepts de base",
      relatedTerms: JSON.stringify([1]),
    },
    {
      slug: "vqe",
      term: "VQE",
      definition: "Variational Quantum Eigensolver : algorithme hybride classique-quantique pour trouver l'état propre de plus basse énergie.",
      category: "Algorithmes",
      relatedTerms: JSON.stringify([]),
    },
  ];

  for (const term of glossaryData) {
    await db.insert(glossaryTerms).values(term);
  }

  console.log("✅ Glossary terms seeded");

  // Projects
  const projectsData = [
    {
      slug: "pasqal-optimization",
      title: "Optimisation avec Pasqal",
      description: "Résolution d'un problème d'optimisation combinatoire avec les atomes neutres de Pasqal.",
      company: "Pasqal",
      industry: "Optimisation",
      problem: "Trouver la meilleure configuration pour minimiser les coûts énergétiques.",
      solution: "Utilisation de QAOA sur le simulateur Pasqal via PennyLane.",
      codeUrl: "https://github.com/example/pasqal-optimization",
      results: "Résultats prometteurs avec une amélioration de 15% par rapport aux méthodes classiques.",
      featured: true,
      order: 1,
    },
    {
      slug: "quandela-photonic",
      title: "Photonique avec Quandela",
      description: "Exploration des avantages de l'informatique quantique photonique.",
      company: "Quandela",
      industry: "Photonique",
      problem: "Simuler des systèmes quantiques complexes avec des photons.",
      solution: "Implémentation d'algorithmes QML avec les processeurs photoniques de Quandela.",
      codeUrl: "https://github.com/example/quandela-photonic",
      results: "Démonstration réussie de l'avantage quantique pour une classe de problèmes.",
      featured: true,
      order: 2,
    },
  ];

  for (const project of projectsData) {
    await db.insert(projects).values(project);
  }

  console.log("✅ Projects seeded");

  // Events
  const eventsData = [
    {
      slug: "webinaire-qml-juin",
      title: "Webinaire : QML en Production",
      description: "Découvrez comment déployer des modèles QML en production avec PennyLane.",
      type: "webinaire",
      startDate: new Date("2026-06-15T18:00:00Z"),
      endDate: new Date("2026-06-15T19:30:00Z"),
      location: "En ligne",
      registrationUrl: "https://example.com/register",
      featured: true,
    },
    {
      slug: "hackathon-quantique-2026",
      title: "Hackathon Quantique France 2026",
      description: "Compétition annuelle pour développer les meilleures applications quantiques.",
      type: "hackathon",
      startDate: new Date("2026-07-01T09:00:00Z"),
      endDate: new Date("2026-07-03T18:00:00Z"),
      location: "Paris",
      registrationUrl: "https://example.com/hackathon",
      featured: true,
    },
  ];

  for (const event of eventsData) {
    await db.insert(events).values(event);
  }

  console.log("✅ Events seeded");

  // Experts
  const expertsData = [
    {
      slug: "marie-dupont",
      name: "Marie Dupont",
      title: "Chercheuse en Informatique Quantique",
      organization: "CNRS",
      bio: "Spécialiste des algorithmes quantiques et de leurs applications industrielles.",
      expertise: JSON.stringify(["QML", "Optimisation", "Algorithmes"]),
      website: "https://example.com",
      twitter: "@mariedupont",
      linkedin: "marie-dupont",
    },
    {
      slug: "jean-martin",
      name: "Jean Martin",
      title: "Ingénieur Quantique",
      organization: "Pasqal",
      bio: "Expert en implémentation d'algorithmes quantiques sur atomes neutres.",
      expertise: JSON.stringify(["Atomes neutres", "PennyLane", "Optimisation"]),
      website: "https://example.com",
      twitter: "@jeanmartin",
      linkedin: "jean-martin",
    },
  ];

  for (const expert of expertsData) {
    await db.insert(experts).values(expert);
  }

  console.log("✅ Experts seeded");

  // Announcements
  const announcementsData = [
    {
      slug: "france-2030-quantique",
      title: "France 2030 : Nouvelle Stratégie Quantique",
      content: "Le gouvernement français annonce un investissement de 72 millions d'euros pour développer l'écosystème quantique français.",
      category: "Actualités",
      featured: true,
      publishedAt: new Date("2026-06-01T10:00:00Z"),
    },
    {
      slug: "pasqal-levee-fonds",
      title: "Pasqal lève 100 millions d'euros",
      content: "La startup française Pasqal annonce une levée de fonds pour accélérer le développement de ses processeurs quantiques.",
      category: "Entreprises",
      featured: true,
      publishedAt: new Date("2026-05-28T14:30:00Z"),
    },
  ];

  for (const announcement of announcementsData) {
    await db.insert(announcements).values(announcement);
  }

  console.log("✅ Announcements seeded");

  console.log("🎉 Database seeded successfully!");
  await connection.end();
}

seed().catch((error) => {
  console.error("❌ Seeding failed:", error);
  process.exit(1);
});
