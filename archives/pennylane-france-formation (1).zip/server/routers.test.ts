import { describe, it, expect, beforeAll } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Mock context
function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

function createAuthContext(userId: number = 1): TrpcContext {
  return {
    user: {
      id: userId,
      openId: "test-user-123",
      email: "test@example.com",
      name: "Test User",
      loginMethod: "test",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("tRPC Routers", () => {
  describe("learningPaths", () => {
    it("should list all learning paths", async () => {
      const caller = appRouter.createCaller(createPublicContext());
      const paths = await caller.learningPaths.list();

      expect(Array.isArray(paths)).toBe(true);
      expect(paths.length).toBeGreaterThan(0);
      expect(paths[0]).toHaveProperty("title");
      expect(paths[0]).toHaveProperty("level");
      expect(paths[0]).toHaveProperty("slug");
    });

    it("should get a learning path by slug", async () => {
      const caller = appRouter.createCaller(createPublicContext());
      const path = await caller.learningPaths.getBySlug({ slug: "fondamentaux" });

      expect(path).toBeDefined();
      expect(path.title).toBe("Fondamentaux du Calcul Quantique");
      expect(path.level).toBe("débutant");
    });

    it("should get learning path with courses", async () => {
      const caller = appRouter.createCaller(createPublicContext());
      const path = await caller.learningPaths.getWithCourses({ slug: "fondamentaux" });

      expect(path).toBeDefined();
      expect(path.courses).toBeDefined();
      expect(Array.isArray(path.courses)).toBe(true);
    });
  });

  describe("courses", () => {
    it("should get a course by slug", async () => {
      const caller = appRouter.createCaller(createPublicContext());
      const course = await caller.courses.getBySlug({ slug: "intro-qubits" });

      expect(course).toBeDefined();
      expect(course.title).toBe("Introduction aux Qubits");
    });

    it("should get course with lessons", async () => {
      const caller = appRouter.createCaller(createPublicContext());
      const course = await caller.courses.getWithLessons({ slug: "intro-qubits" });

      expect(course).toBeDefined();
      expect(course.lessons).toBeDefined();
      expect(Array.isArray(course.lessons)).toBe(true);
    });
  });

  describe("glossary", () => {
    it("should list all glossary terms", async () => {
      const caller = appRouter.createCaller(createPublicContext());
      const terms = await caller.glossary.list();

      expect(Array.isArray(terms)).toBe(true);
      expect(terms.length).toBeGreaterThan(0);
      expect(terms[0]).toHaveProperty("term");
      expect(terms[0]).toHaveProperty("definition");
    });

    it("should get a glossary term by slug", async () => {
      const caller = appRouter.createCaller(createPublicContext());
      const term = await caller.glossary.getBySlug({ slug: "qubit" });

      expect(term).toBeDefined();
      expect(term.term).toBe("Qubit");
    });
  });

  describe("projects", () => {
    it("should list all projects", async () => {
      const caller = appRouter.createCaller(createPublicContext());
      const projects = await caller.projects.list();

      expect(Array.isArray(projects)).toBe(true);
      expect(projects.length).toBeGreaterThan(0);
    });

    it("should get featured projects", async () => {
      const caller = appRouter.createCaller(createPublicContext());
      const projects = await caller.projects.featured();

      expect(Array.isArray(projects)).toBe(true);
      expect(projects.every((p) => p.featured === true)).toBe(true);
    });
  });

  describe("badges", () => {
    it("should list all badges", async () => {
      const caller = appRouter.createCaller(createPublicContext());
      const badges = await caller.badges.list();

      expect(Array.isArray(badges)).toBe(true);
      expect(badges.length).toBeGreaterThan(0);
      expect(badges[0]).toHaveProperty("title");
      expect(badges[0]).toHaveProperty("condition");
    });
  });

  describe("events", () => {
    it("should list all events", async () => {
      const caller = appRouter.createCaller(createPublicContext());
      const events = await caller.events.list();

      expect(Array.isArray(events)).toBe(true);
      expect(events.length).toBeGreaterThan(0);
    });

    it("should get featured events", async () => {
      const caller = appRouter.createCaller(createPublicContext());
      const events = await caller.events.featured();

      expect(Array.isArray(events)).toBe(true);
      expect(events.every((e) => e.featured === true)).toBe(true);
    });
  });

  describe("experts", () => {
    it("should list all experts", async () => {
      const caller = appRouter.createCaller(createPublicContext());
      const experts = await caller.experts.list();

      expect(Array.isArray(experts)).toBe(true);
      expect(experts.length).toBeGreaterThan(0);
      expect(experts[0]).toHaveProperty("name");
      expect(experts[0]).toHaveProperty("organization");
    });
  });

  describe("announcements", () => {
    it("should list all announcements", async () => {
      const caller = appRouter.createCaller(createPublicContext());
      const announcements = await caller.announcements.list();

      expect(Array.isArray(announcements)).toBe(true);
      expect(announcements.length).toBeGreaterThan(0);
    });

    it("should get featured announcements", async () => {
      const caller = appRouter.createCaller(createPublicContext());
      const announcements = await caller.announcements.featured();

      expect(Array.isArray(announcements)).toBe(true);
      expect(announcements.every((a) => a.featured === true)).toBe(true);
    });
  });

  describe("auth", () => {
    it("should return current user info", async () => {
      const caller = appRouter.createCaller(createAuthContext());
      const user = await caller.auth.me();

      expect(user).toBeDefined();
      expect(user?.id).toBe(1);
      expect(user?.name).toBe("Test User");
    });

    it("should return null for unauthenticated users", async () => {
      const caller = appRouter.createCaller(createPublicContext());
      const user = await caller.auth.me();

      expect(user).toBeNull();
    });
  });
});
