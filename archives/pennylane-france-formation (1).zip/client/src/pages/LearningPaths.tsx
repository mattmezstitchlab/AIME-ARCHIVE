import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowRight, BookOpen } from "lucide-react";
import { Link } from "wouter";

export default function LearningPaths() {
  const { data: paths, isLoading } = trpc.learningPaths.list.useQuery();

  const groupedByLevel = {
    débutant: paths?.filter((p) => p.level === "débutant") || [],
    intermédiaire: paths?.filter((p) => p.level === "intermédiaire") || [],
    avancé: paths?.filter((p) => p.level === "avancé") || [],
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border bg-gradient-to-r from-accent/5 to-secondary/5 py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Parcours d'Apprentissage</h1>
            <p className="text-lg text-muted-foreground">
              Choisissez votre niveau et progressez à votre rythme avec nos modules interactifs couvrant tous les aspects du calcul quantique avec PennyLane.
            </p>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 py-16">
        {isLoading ? (
          <div className="space-y-12">
            {[1, 2, 3].map((i) => (
              <div key={i}>
                <Skeleton className="h-8 w-48 mb-6" />
                <div className="grid md:grid-cols-2 gap-6">
                  {[1, 2].map((j) => (
                    <Skeleton key={j} className="h-64" />
                  ))}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="space-y-16">
            {/* Débutant */}
            <section>
              <div className="mb-8">
                <div className="inline-block px-4 py-2 bg-accent/10 text-accent rounded-full text-sm font-semibold mb-3">
                  Niveau 1
                </div>
                <h2 className="text-3xl font-bold mb-2">Débutant</h2>
                <p className="text-muted-foreground">
                  Commencez votre voyage dans le calcul quantique. Parfait pour ceux qui découvrent le domaine pour la première fois.
                </p>
              </div>
              <div className="grid md:grid-cols-2 gap-6">
                {groupedByLevel.débutant.map((path) => (
                  <Link key={path.id} href={`/parcours/${path.slug}`}>
                    <Card className="p-8 h-full hover:shadow-lg transition-all hover:-translate-y-1 cursor-pointer group">
                      <h3 className="text-xl font-bold mb-3 group-hover:text-accent transition-colors">
                        {path.title}
                      </h3>
                      <p className="text-muted-foreground mb-6">{path.description}</p>
                      <div className="flex items-center text-accent font-semibold gap-2">
                        Découvrir <ArrowRight className="w-4 h-4" />
                      </div>
                    </Card>
                  </Link>
                ))}
              </div>
            </section>

            {/* Intermédiaire */}
            <section>
              <div className="mb-8">
                <div className="inline-block px-4 py-2 bg-secondary/10 text-secondary rounded-full text-sm font-semibold mb-3">
                  Niveau 2
                </div>
                <h2 className="text-3xl font-bold mb-2">Intermédiaire</h2>
                <p className="text-muted-foreground">
                  Approfondissez vos connaissances avec des algorithmes plus complexes et des applications pratiques.
                </p>
              </div>
              <div className="grid md:grid-cols-2 gap-6">
                {groupedByLevel.intermédiaire.map((path) => (
                  <Link key={path.id} href={`/parcours/${path.slug}`}>
                    <Card className="p-8 h-full hover:shadow-lg transition-all hover:-translate-y-1 cursor-pointer group">
                      <h3 className="text-xl font-bold mb-3 group-hover:text-secondary transition-colors">
                        {path.title}
                      </h3>
                      <p className="text-muted-foreground mb-6">{path.description}</p>
                      <div className="flex items-center text-secondary font-semibold gap-2">
                        Découvrir <ArrowRight className="w-4 h-4" />
                      </div>
                    </Card>
                  </Link>
                ))}
              </div>
            </section>

            {/* Avancé */}
            <section>
              <div className="mb-8">
                <div className="inline-block px-4 py-2 bg-accent/10 text-accent rounded-full text-sm font-semibold mb-3">
                  Niveau 3
                </div>
                <h2 className="text-3xl font-bold mb-2">Avancé</h2>
                <p className="text-muted-foreground">
                  Maîtrisez les techniques avancées et résolvez des problèmes industriels réels avec le calcul quantique.
                </p>
              </div>
              <div className="grid md:grid-cols-2 gap-6">
                {groupedByLevel.avancé.map((path) => (
                  <Link key={path.id} href={`/parcours/${path.slug}`}>
                    <Card className="p-8 h-full hover:shadow-lg transition-all hover:-translate-y-1 cursor-pointer group">
                      <h3 className="text-xl font-bold mb-3 group-hover:text-accent transition-colors">
                        {path.title}
                      </h3>
                      <p className="text-muted-foreground mb-6">{path.description}</p>
                      <div className="flex items-center text-accent font-semibold gap-2">
                        Découvrir <ArrowRight className="w-4 h-4" />
                      </div>
                    </Card>
                  </Link>
                ))}
              </div>
            </section>
          </div>
        )}
      </div>

      {/* CTA */}
      <section className="border-t border-border py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto text-center space-y-6">
            <h2 className="text-3xl font-bold">Besoin d'aide pour choisir ?</h2>
            <p className="text-muted-foreground">
              Consultez notre glossaire ou explorez les projets industriels pour mieux comprendre les applications du calcul quantique.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/glossaire">
                <Button variant="outline" className="gap-2">
                  <BookOpen className="w-4 h-4" />
                  Glossaire Quantique
                </Button>
              </Link>
              <Link href="/projets">
                <Button className="gap-2">
                  Voir les Projets <ArrowRight className="w-4 h-4" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
