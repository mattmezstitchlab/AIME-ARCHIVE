import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowRight, Zap, Users, BookOpen, Award, Sparkles } from "lucide-react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { Skeleton } from "@/components/ui/skeleton";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const { data: paths, isLoading: pathsLoading } = trpc.learningPaths.list.useQuery();
  const { data: announcements } = trpc.announcements.featured.useQuery();
  const { data: events } = trpc.events.featured.useQuery();

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-8 h-8 text-accent" />
            <span className="text-xl font-bold text-foreground">PennyLane France</span>
          </div>
          <div className="flex items-center gap-4">
            {isAuthenticated ? (
              <div className="flex items-center gap-4">
                <span className="text-sm text-muted-foreground">Bienvenue, {user?.name}</span>
                <Link href="/dashboard">
                  <Button variant="outline" size="sm">
                    Tableau de bord
                  </Button>
                </Link>
              </div>
            ) : (
              <Link href="/login">
                <Button size="sm">Se connecter</Button>
              </Link>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative py-20 md:py-32 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-accent/10 via-transparent to-secondary/10 pointer-events-none" />
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl mx-auto text-center space-y-8">
            <h1 className="text-5xl md:text-6xl font-bold text-foreground leading-tight">
              Maîtrisez le Quantique par la Pratique
            </h1>
            <p className="text-xl text-muted-foreground leading-relaxed">
              Découvrez la formation complète sur PennyLane adaptée à l'écosystème quantique français. 
              De la théorie aux applications industrielles, apprenez avec les meilleures pratiques.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
              <Link href="/parcours">
                <Button size="lg" className="gap-2">
                  Découvrir les parcours <ArrowRight className="w-4 h-4" />
                </Button>
              </Link>
              <Link href="/glossaire">
                <Button size="lg" variant="outline">
                  Consulter le glossaire
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 md:py-24 border-t border-border">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="p-8 hover:shadow-lg transition-shadow">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-accent/10 rounded-lg">
                  <BookOpen className="w-6 h-6 text-accent" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold mb-2">Parcours Structurés</h3>
                  <p className="text-muted-foreground">
                    Trois niveaux de formation : débutant, intermédiaire et avancé, avec modules complets et projets pratiques.
                  </p>
                </div>
              </div>
            </Card>

            <Card className="p-8 hover:shadow-lg transition-shadow">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-secondary/10 rounded-lg">
                  <Zap className="w-6 h-6 text-secondary" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold mb-2">Cas d'Usage Réels</h3>
                  <p className="text-muted-foreground">
                    Explorez des projets industriels français avec Pasqal, Quandela et Alice & Bob.
                  </p>
                </div>
              </div>
            </Card>

            <Card className="p-8 hover:shadow-lg transition-shadow">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-accent/10 rounded-lg">
                  <Users className="w-6 h-6 text-accent" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold mb-2">Communauté Active</h3>
                  <p className="text-muted-foreground">
                    Posez vos questions, partagez vos projets et connectez-vous avec des experts français.
                  </p>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Learning Paths Preview */}
      <section className="py-16 md:py-24 border-t border-border bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Parcours d'Apprentissage</h2>
            <p className="text-muted-foreground">
              Choisissez votre niveau et progressez à votre rythme avec nos modules interactifs.
            </p>
          </div>

          {pathsLoading ? (
            <div className="grid md:grid-cols-3 gap-6">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-64 rounded-lg" />
              ))}
            </div>
          ) : (
            <div className="grid md:grid-cols-3 gap-6">
              {paths?.map((path) => (
                <Link key={path.id} href={`/parcours/${path.slug}`}>
                  <Card className="p-8 h-full hover:shadow-lg transition-all hover:-translate-y-1 cursor-pointer group">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <span className="inline-block px-3 py-1 bg-accent/10 text-accent text-xs font-semibold rounded-full mb-3">
                          {path.level}
                        </span>
                        <h3 className="text-xl font-bold group-hover:text-accent transition-colors">
                          {path.title}
                        </h3>
                      </div>
                    </div>
                    <p className="text-muted-foreground mb-6">{path.description}</p>
                    <div className="flex items-center text-accent font-semibold gap-2">
                      Découvrir <ArrowRight className="w-4 h-4" />
                    </div>
                  </Card>
                </Link>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Announcements */}
      {announcements && announcements.length > 0 && (
        <section className="py-16 md:py-24 border-t border-border">
          <div className="container mx-auto px-4">
            <div className="max-w-2xl mx-auto text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Actualités de l'Écosystème</h2>
              <p className="text-muted-foreground">
                Restez informé des dernières nouvelles du quantique en France.
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
              {announcements.slice(0, 2).map((announcement) => (
                <Card key={announcement.id} className="p-6 hover:shadow-lg transition-shadow">
                  <div className="flex items-start gap-4">
                    <div className="p-2 bg-accent/10 rounded-lg flex-shrink-0">
                      <Sparkles className="w-5 h-5 text-accent" />
                    </div>
                    <div>
                      <h3 className="font-semibold mb-2">{announcement.title}</h3>
                      <p className="text-sm text-muted-foreground line-clamp-2">
                        {announcement.content}
                      </p>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Events */}
      {events && events.length > 0 && (
        <section className="py-16 md:py-24 border-t border-border bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="max-w-2xl mx-auto text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Événements à Venir</h2>
              <p className="text-muted-foreground">
                Webinaires, hackathons et ateliers pour progresser ensemble.
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
              {events.slice(0, 2).map((event) => (
                <Card key={event.id} className="p-6 hover:shadow-lg transition-shadow">
                  <div className="flex items-start justify-between mb-4">
                    <span className="inline-block px-3 py-1 bg-secondary/10 text-secondary text-xs font-semibold rounded-full">
                      {event.type}
                    </span>
                  </div>
                  <h3 className="font-semibold mb-2">{event.title}</h3>
                  <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                    {event.description}
                  </p>
                  <div className="text-xs text-muted-foreground">
                    {new Date(event.startDate).toLocaleDateString('fr-FR', {
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric'
                    })}
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* CTA Section */}
      <section className="py-16 md:py-24 border-t border-border bg-gradient-to-r from-accent/5 to-secondary/5">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto text-center space-y-6">
            <h2 className="text-3xl md:text-4xl font-bold">
              Prêt à explorer le calcul quantique ?
            </h2>
            <p className="text-muted-foreground">
              Rejoignez des centaines d'apprenants français qui maîtrisent PennyLane et découvrent les applications du quantique.
            </p>
            <Link href="/parcours">
              <Button size="lg" className="gap-2">
                Commencer maintenant <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-12 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-semibold mb-4">PennyLane France</h4>
              <p className="text-sm text-muted-foreground">
                Formation complète sur le calcul quantique avec PennyLane, adaptée à l'écosystème français.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Ressources</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link href="/parcours">Parcours</Link></li>
                <li><Link href="/projets">Projets</Link></li>
                <li><Link href="/glossaire">Glossaire</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Communauté</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link href="/forum">Forum</Link></li>
                <li><Link href="/evenements">Événements</Link></li>
                <li><Link href="/experts">Experts</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Partenaires</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>Pasqal</li>
                <li>Quandela</li>
                <li>Alice & Bob</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border pt-8 text-center text-sm text-muted-foreground">
            <p>© 2026 PennyLane France. Tous droits réservés. Créé avec ❤️ pour la communauté quantique française.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
