import { useRoute } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowRight, Clock, BookOpen } from "lucide-react";
import { Link } from "wouter";

export default function LearningPathDetail() {
  const [, params] = useRoute("/parcours/:slug");
  const slug = params?.slug as string;

  const { data: path, isLoading } = trpc.learningPaths.getWithCourses.useQuery(
    { slug },
    { enabled: !!slug }
  );

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="border-b border-border py-12">
          <div className="container mx-auto px-4">
            <Skeleton className="h-10 w-64 mb-4" />
            <Skeleton className="h-20 w-full" />
          </div>
        </div>
        <div className="container mx-auto px-4 py-16">
          <div className="space-y-6">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-32" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!path) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-2">Parcours non trouvé</h1>
          <p className="text-muted-foreground mb-6">Le parcours que vous cherchez n'existe pas.</p>
          <Link href="/parcours">
            <Button>Retour aux parcours</Button>
          </Link>
        </div>
      </div>
    );
  }

  const levelColors = {
    débutant: "bg-accent/10 text-accent",
    intermédiaire: "bg-secondary/10 text-secondary",
    avancé: "bg-accent/10 text-accent",
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border bg-gradient-to-r from-accent/5 to-secondary/5 py-12">
        <div className="container mx-auto px-4">
          <Link href="/parcours" className="text-accent hover:underline text-sm mb-4 inline-block">
            ← Retour aux parcours
          </Link>
          <div className="max-w-3xl">
            <div className={`inline-block px-4 py-2 ${levelColors[path.level as keyof typeof levelColors]} rounded-full text-sm font-semibold mb-4`}>
              {path.level}
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-4">{path.title}</h1>
            <p className="text-lg text-muted-foreground">{path.description}</p>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-4xl">
          <h2 className="text-2xl font-bold mb-8">Modules du Parcours</h2>

          {path.courses && path.courses.length > 0 ? (
            <div className="space-y-4">
              {path.courses.map((course, index) => (
                <Link key={course.id} href={`/modules/${course.slug}`}>
                  <Card className="p-6 hover:shadow-lg transition-all hover:-translate-y-1 cursor-pointer group border-l-4 border-l-accent">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <span className="inline-block w-8 h-8 bg-accent/10 text-accent rounded-full flex items-center justify-center text-sm font-bold">
                            {index + 1}
                          </span>
                          <h3 className="text-xl font-bold group-hover:text-accent transition-colors">
                            {course.title}
                          </h3>
                        </div>
                        <p className="text-muted-foreground mb-4">{course.description}</p>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          {course.duration && (
                            <div className="flex items-center gap-1">
                              <Clock className="w-4 h-4" />
                              {course.duration} min
                            </div>
                          )}
                          <div className="flex items-center gap-1">
                            <BookOpen className="w-4 h-4" />
                            Module complet
                          </div>
                        </div>
                      </div>
                      <div className="flex-shrink-0">
                        <ArrowRight className="w-5 h-5 text-accent opacity-0 group-hover:opacity-100 transition-opacity" />
                      </div>
                    </div>
                  </Card>
                </Link>
              ))}
            </div>
          ) : (
            <Card className="p-8 text-center">
              <p className="text-muted-foreground">Aucun module disponible pour ce parcours pour le moment.</p>
            </Card>
          )}
        </div>
      </div>

      {/* Info Section */}
      <section className="border-t border-border py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8 max-w-4xl">
            <div>
              <h3 className="font-semibold mb-2">Durée totale</h3>
              <p className="text-muted-foreground">
                {path.courses?.reduce((acc, c) => acc + (c.duration || 0), 0) || 0} minutes
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Niveau</h3>
              <p className="text-muted-foreground capitalize">{path.level}</p>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Modules</h3>
              <p className="text-muted-foreground">{path.courses?.length || 0} modules</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
