import { useEffect } from "react";
import { useLocation } from "react-router-dom";

// Fait défiler en douceur vers la section dont l'id correspond au hash de l'URL
// (ex. /mariage/jour-j#plan-de-table). `ready` permet d'attendre le chargement
// des données avant de tenter le scroll (sinon la cible n'existe pas encore).
export default function useScrollToHash(ready = true) {
  const { hash } = useLocation();

  useEffect(() => {
    if (!ready || !hash) return;
    const id = hash.replace("#", "");
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }, [hash, ready]);
}