import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";

const INITIAL = { needs: [], pairs: [], legs: [], incidents: [], passports: [] };

export default function useReseauOverview() {
  const [data, setData] = useState(INITIAL);
  const [loading, setLoading] = useState(true);
  const [anonymous, setAnonymous] = useState(false);
  const [me, setMe] = useState(null);

  useEffect(() => {
    (async () => {
      let me;
      try { me = await base44.auth.me(); setMe(me); } catch { setAnonymous(true); setLoading(false); return; }
      const [needs, pairs, legs, incidents, passports] = await Promise.all([
        base44.entities.ShoeNeed.filter({ status: "ouvert" }, "-created_date", 20),
        base44.entities.ShoePair.list("-created_date", 50),
        base44.entities.RelayLeg.list("-created_date", 30),
        base44.entities.LogisticsIncident.filter({ status: "ouvert" }, "-created_date", 20),
        base44.entities.PairPassport.list("-updated_date", 30),
      ]);
      setData({ needs, pairs: pairs.filter((p) => !["remise", "recycle"].includes(p.status)), legs: legs.filter((l) => l.status !== "termine"), incidents, passports });
      setLoading(false);
    })();
  }, []);

  return { data, loading, anonymous, me };
}