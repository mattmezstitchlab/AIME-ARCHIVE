import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import Login from './pages/Login';
import Register from './pages/Register';
import ForgotPassword from './pages/ForgotPassword';
import ResetPassword from './pages/ResetPassword';
import PassportOnboarding from './pages/PassportOnboarding';
import PassportPreview from './pages/PassportPreview';
import Landing from './pages/Landing';
import About from './pages/About';
import Contact from './pages/Contact';
import Layout from './components/Layout';
import CarteDuReseau from './pages/CarteDuReseau';
import ParcoursRedirect from './components/reseau/ParcoursRedirect';

import Collectes from './pages/Collectes';
import MurDesChaines from './pages/MurDesChaines';
import Association from './pages/Association';
import Evenements from './pages/Evenements';

import EmbedChat from './pages/EmbedChat';
import SitePublic from './pages/SitePublic';
import SitePlusPublic from './pages/SitePlusPublic';


// ── LES ANCIENNES ADRESSES, REGROUPÉES ─────────────────────────────────────
// Chaque héritage (pages supprimées, ères précédentes) redirige vers sa
// destination vivante — une seule liste au lieu de 40 routes éparpillées.
const REDIRECTIONS = [
  ["/", [
    "/commencer", "/commencer/parcours", "/plus", "/profil", "/compte/creer",
    "/startup", "/embarquement", "/registre/carte/:id", "/registre/:slug",
    "/design-system", "/design-system/proposition", "/design-system/miroir",
    "/decouvrir", "/innovations", "/tarifs",
    "/couple", "/officiant", "/temoin", "/cortege", "/famille", "/invites",
    "/coordinateur", "/prestataires", "/lieu",
    "/recherche", "/categories", "/plan-du-site", "/reservation/confirmation",
    "/infos", "/comment-ca-marche", "/mecanisme", "/aide",
    "/legal", "/cgu", "/confidentialite", "/cookies", "/accessibilite",
    "/artiste/:id", "/m/:id", "/v/:slug", "/vc/:slug",
    "/magazine", "/blog", "/blog/:slug", "/site-en-direct",
    "/guide", "/mode-emploi", "/memoire",
    "/causal-event-os", "/event-os-v2", "/embarquement-pro",
    "/aime-wedding", "/wedding-os", "/inscription/:role", "/jour-j", "/programme", "/programme-du-jour-j",
  ]],
  ["/bureau", [
    "/bureau/vitrine", "/bureau/vitrine-humaine", "/absorbeur", "/studio",
    "/atelier-mariage", "/entrer", "/atelier", "/pro", "/galerie-visuels", "/sante",
    "/mon-compte", "/mon-compte/plans", "/mon-compte/plans/:id", "/mon-compte/plans/:id/:module",
    "/mon-compte/projets", "/mon-compte/favoris", "/mon-compte/profil",
  ]],
  ["/#clavier", ["/device"]],
  ["/reseau?world=1", ["/monde"]],
];

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-muted border-t-foreground rounded-full animate-spin" />
      </div>
    );
  }

  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      navigateToLogin();
      return null;
    }
  }

  return (
    <Routes>
      <Route element={<Layout />}>
        {/* L'ACCUEIL PUBLIC — l'entrée AI+ME, compréhensible sans connaître AIME. */}
        <Route path="/" element={<Landing />} />
        <Route path="/passeport/:code" element={<PassportPreview />} />
        <Route path="/Landing" element={<Navigate to="/" replace />} />
        <Route path="/a-propos" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        {/* LE BUREAU — l'entrée unique : projets, Studio Canevas, Pipeline EAA. */}
        <Route path="/bureau" element={<Navigate to="/reseau?panel=settings" replace />} />
        <Route path="/parcours" element={<ParcoursRedirect />} />
        <Route path="/reseau" element={<CarteDuReseau />} />
        <Route path="/carte" element={<Navigate to="/reseau" replace />} />
        <Route path="/don-paire" element={<Navigate to="/reseau?mode=donner" replace />} />
        <Route path="/besoin-paire" element={<Navigate to="/reseau?mode=recevoir" replace />} />
        <Route path="/relais" element={<Navigate to="/reseau?mode=relayer" replace />} />
        <Route path="/suivi" element={<Navigate to="/reseau?panel=passeports" replace />} />
        <Route path="/cockpit" element={<Navigate to="/bureau#alertes" replace />} />
        <Route path="/collectes" element={<Collectes />} />
        <Route path="/chaines" element={<MurDesChaines />} />
        <Route path="/association" element={<Association />} />
        <Route path="/evenements" element={<Evenements />} />
        <Route path="/compte" element={<Navigate to="/reseau?panel=settings" replace />} />
        <Route path="/soul" element={<Navigate to="/reseau" replace />} />
        <Route path="/Login" element={<Login />} />
        <Route path="/ResetPassword" element={<ResetPassword />} />

        {/* Les anciennes adresses → destinations vivantes. */}
        {REDIRECTIONS.map(([cible, chemins]) =>
          chemins.map((c) => <Route key={c} path={c} element={<Navigate to={cible} replace />} />)
        )}
      </Route>

      {/* Authentification et création du passeport personnel, hors layout. */}
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />
      <Route path="/onboarding" element={<PassportOnboarding />} />

      {/* Widget de chat embarquable (hors layout). */}
      <Route path="/embed/chat" element={<EmbedChat />} />

      {/* LE MINI-SITE GÉNÉRÉ — public, reprise possible à petit prix. */}
      <Route path="/site/:id" element={<SitePublic />} />

      {/* LE PROTOCOLE « + » — chaque site publié vit sur son adresse +nom. */}
      <Route path="/:adresse" element={<SitePlusPublic />} />
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};

function App() {
  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App