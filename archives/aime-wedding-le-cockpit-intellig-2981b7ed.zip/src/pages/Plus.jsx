import { Link } from "react-router-dom";
import { Users, Heart, ArrowRight } from "lucide-react";
import { useSeo } from "@/lib/seo/useSeo";
import AimePlusLogo from "@/components/nav/AimePlusLogo";

// LE + — la page des accès du système : une tuile par grande porte.
// (Radio On Air et la Frise des vérités : supprimées — grand nettoyage.)
const ACCES = [
  { to: "/registre", icon: Users, titre: "Le Registre", texte: "Toutes les cartes profils — filtrables, reliées, vivantes.", color: "#c084fc" },
  { to: "/aime-wedding", icon: Heart, titre: "AIME Wedding", texte: "Créez votre mariage ou rejoignez-en un par son code d'invitation.", color: "#F2A7C3" },
];

export default function Plus() {
  useSeo({
    title: "+ — Les accès AIME®",
    description: "Le Registre et AIME Wedding : les portes du système AIME®.",
  });

  return (
    <div className="mx-auto max-w-3xl px-6 pt-8 pb-20 text-white">
      <header className="mb-8 text-center">
        <div className="flex justify-center"><AimePlusLogo /></div>
        <h1 className="mt-4 font-heading text-3xl font-light tracking-[-0.02em] sm:text-4xl">
          Les accès du système.
        </h1>
        <p className="mt-2 text-[14px] leading-6 text-white/50">
          Une porte par grand outil — le reste vit dans le Bureau (AI) et votre profil (ME).
        </p>
      </header>

      <div className="grid gap-3 sm:grid-cols-2">
        {ACCES.map((a) => (
          <Link
            key={a.to}
            to={a.to}
            className="group rounded-2xl border border-white/12 bg-white/[0.02] p-5 transition-colors hover:border-white/25 hover:bg-white/[0.05]"
          >
            <a.icon className="h-5 w-5" style={{ color: a.color }} strokeWidth={1.6} />
            <p className="mt-3 font-heading text-[17px] font-medium">{a.titre}</p>
            <p className="mt-1 text-[12.5px] leading-5 text-white/50">{a.texte}</p>
            <span className="mt-3 inline-flex items-center gap-1 font-mono text-[10px] font-semibold uppercase tracking-[0.18em] text-white/40 transition-colors group-hover:text-white">
              Ouvrir <ArrowRight className="h-3 w-3 transition-transform group-hover:translate-x-0.5" />
            </span>
          </Link>
        ))}
      </div>
    </div>
  );
}