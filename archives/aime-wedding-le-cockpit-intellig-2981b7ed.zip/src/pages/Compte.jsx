import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import MoiNav from "@/components/comptepas/MoiNav";
import MoiSections from "@/components/comptepas/MoiSections";
import { useSeo } from "@/lib/seo/useSeo";

// MON COMPTE — le profil minimal du réseau : pseudo, photo, zone, et mes activités.
export default function Compte() {
  useSeo({ title: "Moi — Les Pas d'AIME", description: "Votre cockpit personnel : actions à traiter, passeports, activité et profil." });
  const [me, setMe] = useState(null);
  const [anonyme, setAnonyme] = useState(false);

  useEffect(() => {
    base44.auth.me().then(setMe).catch(() => setAnonyme(true));
  }, []);

  return (
    <div className="mx-auto max-w-3xl px-4 pb-24">
      <header className="pt-8">
        <p className="font-mono text-[11px] font-bold uppercase tracking-[0.25em] text-[#F2B90D]">Moi</p>
        <h1 className="mt-2 text-[clamp(1.6rem,4vw,2.4rem)] font-extrabold leading-tight">Votre place dans le réseau.</h1>
        <p className="mt-3 max-w-xl text-[14px] leading-relaxed text-white/60">
          Vos actions à traiter, vos passeports, votre activité et votre profil réunis au même endroit.
        </p>
      </header>

      {anonyme ? (
        <div className="mt-8 rounded-2xl border border-white/15 bg-[#141414] p-6 text-center">
          <p className="text-[14px] font-bold">Connectez-vous pour retrouver vos dons, relais et dossards.</p>
          <button onClick={() => base44.auth.redirectToLogin("/compte")}
            className="mt-4 inline-flex min-h-[42px] items-center rounded-full bg-[#F2B90D] px-6 text-[13px] font-bold text-black transition hover:opacity-85">
            Se connecter
          </button>
        </div>
      ) : me === null ? (
        <p className="mt-8 text-[13px] text-white/50">Chargement de votre compte…</p>
      ) : (
        <>
          <MoiNav />
          <MoiSections me={me} />
        </>
      )}
    </div>
  );
}