import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Footprints, MapPin } from "lucide-react";
import { getCategorie } from "@/lib/pas/categories";

export default function Suivi() {
  const [pairs, setPairs] = useState([]);
  const [passports, setPassports] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const me = await base44.auth.me();
        const myPairs = await base44.entities.ShoePair.filter({ created_by_id: me.id }, "-created_date", 100);
        setPairs(myPairs);
        const ownedPassports = await Promise.all(myPairs.map(async (pair) => {
          if (pair.passport_id) return base44.entities.PairPassport.get(pair.passport_id).catch(() => null);
          const found = await base44.entities.PairPassport.filter({ pair_id: pair.id }, "-created_date", 1);
          return found[0] || null;
        }));
        setPassports(ownedPassports.filter(Boolean));
      } catch {}
      setLoading(false);
    })();
  }, []);

  const getPassport = (pairId) => passports.find((p) => p.pair_id === pairId);

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#0D0D0D]">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-white/20 border-t-[#F2B90D]" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0D0D0D] px-6 py-24 text-[#F5F1E8]">
      <div className="mx-auto max-w-3xl">
        <Link to="/" className="text-[13px] text-white/50 hover:text-[#F5F1E8]">← Accueil</Link>
        <div className="mt-4 flex items-center gap-2">
          <Footprints className="h-5 w-5 text-[#F2B90D]" />
          <span className="label-aime text-white/60">Passeports personnels</span>
        </div>
        <h1 className="mt-3 font-heading text-[clamp(2rem,6vw,3.5rem)] font-extrabold uppercase leading-none tracking-[-0.03em]">
          Mes passeports
        </h1>
        <p className="mt-3 text-[16px] leading-7 text-white/70">
          Suivez la circulation de chaque objet que vous avez confié. Vous voyez le chemin, jamais la personne.
        </p>

        {pairs.length === 0 ? (
          <div className="mt-12 rounded-2xl border border-dashed border-white/20 p-12 text-center">
            <Footprints className="mx-auto h-8 w-8 text-white/50" />
            <p className="mt-4 text-[16px] text-white/70">Vous n'avez pas encore confié d'objet au réseau.</p>
            <Link to="/parcours#donner" className="mt-4 inline-flex min-h-[44px] items-center rounded-full bg-[#F2B90D] px-6 text-[13px] font-bold text-black">
              Donner un objet
            </Link>
          </div>
        ) : (
          <div className="mt-8 space-y-6">
            {pairs.map((pair) => {
              const passport = getPassport(pair.id);
              const categorie = getCategorie(pair.category || "chaussures");
              return (
                <div key={pair.id} className="rounded-2xl border border-white/15 bg-[#141414] p-6">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <p className="font-mono text-[16px] font-bold text-[#F2B90D]">{passport?.reference || "—"}</p>
                      <div className="mt-2 flex flex-wrap gap-2 text-[12px]">
                        <span className="rounded-full bg-white/10 px-3 py-1">{categorie.label}</span>
                        {(pair.shoe_size || pair.size_label) && <span className="rounded-full bg-white/10 px-3 py-1">Taille {pair.shoe_size || pair.size_label}</span>}
                        <span className="rounded-full bg-white/10 px-3 py-1">{pair.city_zone}</span>
                      </div>
                    </div>
                    <span className={`rounded-full px-3 py-1 text-[11px] font-bold ${
                      pair.status === 'remise' ? 'bg-[#F2B90D]/20 text-[#F2B90D]' :
                      pair.status === 'en_relais' ? 'bg-[#F2B90D]/20 text-[#F2B90D]' :
                      pair.status === 'disponible' ? 'bg-[#F2B90D]/20 text-[#F2B90D]' :
                      'bg-white/10 text-white/50'
                    }`}>{pair.status}</span>
                  </div>

                  {/* Ligne de vie */}
                  {passport?.history && passport.history.length > 0 && (
                    <div className="mt-4 space-y-2">
                      <p className="text-[12px] font-bold text-white/50">Ligne de vie</p>
                      {passport.history.map((h, i) => (
                        <div key={i} className="flex items-center gap-2 text-[12px]">
                          <span className="flex h-6 w-6 items-center justify-center rounded-full bg-white/10 text-[10px] font-bold">{i + 1}</span>
                          <span className="font-semibold capitalize">{h.step}</span>
                          <MapPin className="h-3 w-3 text-white/50" />
                          <span className="text-white/50">{h.zone}</span>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Impact */}
                  {passport?.impact_summary && (
                    <div className="mt-4 rounded-xl bg-[#F2B90D]/5 p-3 text-[12px] text-white/80">
                      {passport.impact_summary}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}