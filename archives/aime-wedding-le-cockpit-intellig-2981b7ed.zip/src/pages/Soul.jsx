import { useEffect, useRef, useState } from "react";
import { useSeo } from "@/lib/seo/useSeo";
import SoulMolecule from "@/components/soul/SoulMolecule";
import SoulDirect from "@/components/soul/SoulDirect";
import SoulApparence from "@/components/soul/SoulApparence";
import SoulReseau from "@/components/soul/SoulReseau";

// L'ÉCRAN SOUL — la molécule vivante : mode Apparence (couleur) et mode Direct
// (cadran causal du Jour J). Le même objet, deux lectures.
export default function Soul() {
  useSeo({ title: "Soul — La molécule du Jour J", description: "La molécule vivante : réglez son apparence, puis regardez-la recalculer le Jour J en direct." });
  const [mode, setMode] = useState("direct");
  const [accent, setAccent] = useState("#F2B90D");
  const [scenario, setScenario] = useState(null);
  const [revele, setRevele] = useState(0);
  const timer = useRef(null);

  const choisir = (s) => {
    clearInterval(timer.current);
    setScenario(s);
    setRevele(0);
    timer.current = setInterval(() => {
      setRevele((r) => {
        if (r >= s.effets.length) { clearInterval(timer.current); return r; }
        return r + 1;
      });
    }, 900);
  };
  useEffect(() => () => clearInterval(timer.current), []);

  const impactes = mode === "direct" && scenario ? scenario.effets.slice(0, revele).map((e) => e.atome) : [];
  const source = mode === "direct" && scenario ? scenario.source : null;

  return (
    <div className="mx-auto max-w-6xl px-4 pb-24">
      <header className="pt-8">
        <p className="font-mono text-[11px] font-bold uppercase tracking-[0.25em]" style={{ color: accent }}>Soul</p>
        <h1 className="mt-2 text-[clamp(1.6rem,4vw,2.4rem)] font-extrabold leading-tight">
          La molécule du Jour J.
        </h1>
        <p className="mt-3 max-w-2xl text-[14px] leading-relaxed text-white/60">
          Chaque atome est un moment ou un acteur, chaque liaison une dépendance.
          Un imprévu frappe un atome — et l'onde se propage, toujours justifiée.
        </p>
      </header>

      {/* La bascule : un seul objet, deux lectures. */}
      <div className="mt-6 inline-flex rounded-full border border-white/15 bg-[#141414] p-1">
        {[["direct", "Direct · Jour J"], ["reseau", "Réseau · En direct"], ["apparence", "Apparence"]].map(([m, l]) => (
          <button key={m} onClick={() => setMode(m)}
            className={`flex min-h-[38px] items-center rounded-full px-5 font-mono text-[11px] font-bold uppercase tracking-[0.1em] transition ${
              mode === m ? "text-black" : "text-white/60 hover:text-white"
            }`}
            style={mode === m ? { background: accent } : {}}>
            {l}
          </button>
        ))}
      </div>

      {mode === "reseau" ? (
        <SoulReseau accent={accent} />
      ) : (
        <div className="mt-6 grid gap-6 lg:grid-cols-[1.4fr_1fr]">
          <div className="aspect-square rounded-2xl border border-white/15 bg-[#0F0F0F] p-4 sm:aspect-[4/3]">
            <SoulMolecule accent={accent} source={source} impactes={impactes} />
          </div>
          <div className="rounded-2xl border border-white/15 bg-[#141414] p-5">
            {mode === "direct"
              ? <SoulDirect scenario={scenario} revele={revele} onSelect={choisir} accent={accent} />
              : <SoulApparence accent={accent} onChange={setAccent} />}
          </div>
        </div>
      )}
    </div>
  );
}