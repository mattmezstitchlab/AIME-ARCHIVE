import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Plus } from "lucide-react";
import CollecteCarte from "@/components/collectes/CollecteCarte";
import CollecteForm from "@/components/collectes/CollecteForm";
import { useSeo } from "@/lib/seo/useSeo";

// LES COLLECTES FLASH — des points de collecte éphémères avec compteur public.
export default function Collectes() {
  useSeo({ title: "Collectes flash — Les Pas d'AIME", description: "Points de collecte éphémères avec compteur public en direct." });
  const [drives, setDrives] = useState(null);
  const [creer, setCreer] = useState(false);

  const charger = async () => {
    const all = await base44.entities.DonationDrive.list("-created_date", 100);
    setDrives(all.filter((d) => d.status !== "completed"));
  };
  useEffect(() => { charger(); }, []);

  return (
    <div className="mx-auto max-w-4xl px-4 pb-24">
      <header className="pt-8">
        <div>
          <p className="font-mono text-[11px] font-bold uppercase tracking-[0.25em] text-[#F2B90D]">Collectes flash</p>
          <h1 className="mt-2 text-[clamp(1.6rem,4vw,2.4rem)] font-extrabold leading-tight">
            Un point de collecte, quelques jours, un compteur en direct.
          </h1>
          <p className="mt-3 max-w-2xl text-[14px] leading-relaxed text-white/80">
            Un commerce, une école ou une mairie déclare une collecte flash. Chacun promet ce qu'il apportera —
            le compteur monte en direct et crée l'émulation locale.
          </p>
          <button onClick={() => setCreer((v) => !v)}
            className="mt-5 flex min-h-[46px] items-center gap-2 rounded-full bg-[#F2B90D] px-6 text-[13px] font-bold text-black transition hover:opacity-85">
            <Plus className="h-4 w-4" aria-hidden="true" /> Lancer une collecte flash
          </button>
        </div>
      </header>

      {creer && (
        <div className="mt-6">
          <CollecteForm onCreated={() => { setCreer(false); charger(); }} />
        </div>
      )}

      <div className="mt-8">
        {drives === null ? (
          <p className="text-[13px] text-white/50">Chargement des collectes…</p>
        ) : drives.length === 0 ? (
          <p className="rounded-2xl border border-white/10 bg-[#141414] p-6 text-[13px] text-white/50">
            Aucune collecte ouverte pour l'instant — lancez la première.
          </p>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2">
            {drives.map((d) => <CollecteCarte key={d.id} drive={d} onUpdate={charger} />)}
          </div>
        )}
      </div>
    </div>
  );
}