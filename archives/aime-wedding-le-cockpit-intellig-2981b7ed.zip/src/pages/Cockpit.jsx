import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Footprints, Users, AlertTriangle, Activity, MapPin } from "lucide-react";
import CockpitDetail from "@/components/cockpit/CockpitDetail";

// Les grandes statistiques : chacune s'ouvre sur le détail des enregistrements.
const STATS = [
  { key: "pairs", icon: Footprints, champ: "total_pairs", label: "Paires enregistrées" },
  { key: "needs", icon: Users, champ: "open_needs", label: "Besoins ouverts" },
  { key: "resolved", icon: Footprints, champ: "resolved_needs", label: "Besoins résolus" },
  { key: "incidents", icon: AlertTriangle, champ: "open_incidents", label: "Incidents ouverts" },
];

export default function Cockpit() {
  const [stats, setStats] = useState(null);
  const [detail, setDetail] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const res = await base44.functions.invoke("pasEngine", { action: "stats" });
        setStats(res.data);
      } catch {}
      setLoading(false);
    })();
  }, []);

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#0D0D0D]">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-white/20 border-t-[#F2B90D]" />
      </div>
    );
  }

  const s = stats || {};

  return (
    <div className="min-h-screen bg-[#0D0D0D] px-6 py-24 text-[#F5F1E8]">
      <div className="mx-auto max-w-5xl">
        <Link to="/" className="text-[13px] text-white/50 hover:text-[#F5F1E8]">← Accueil</Link>
        <div className="mt-4 flex items-center gap-2">
          <Activity className="h-5 w-5 text-[#F2B90D]" />
          <span className="label-aime text-white/50">Cockpit coordinateur</span>
        </div>
        <h1 className="mt-3 font-heading text-[clamp(2rem,6vw,3.5rem)] font-extrabold uppercase leading-none tracking-[-0.03em]">
          Cockpit
        </h1>

        {/* Stats principales — cliquables : le détail s'ouvre en dessous. */}
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {STATS.map((st) => {
            const actif = detail === st.key;
            return (
              <button key={st.key} onClick={() => setDetail(actif ? null : st.key)}
                className={`rounded-2xl border p-6 text-left transition ${actif ? "border-[#F2B90D] bg-[#F2B90D]/10" : "border-white/15 bg-[#141414] hover:border-white/40"}`}>
                <st.icon className="h-5 w-5 text-[#F2B90D]" />
                <p className="mt-4 font-heading text-[28px] font-extrabold leading-none">{s[st.champ] || 0}</p>
                <p className="mt-1 text-[12px] text-white/50">{st.label}</p>
                <p className="mt-2 text-[10px] font-bold uppercase tracking-[0.15em] text-[#F2B90D]/70">{actif ? "Fermer" : "Voir le détail"}</p>
              </button>
            );
          })}
        </div>
        {detail && <CockpitDetail type={detail} />}

        {/* Stock par statut */}
        <div className="mt-8">
          <h2 className="font-heading text-[18px] font-extrabold">Stock par statut</h2>
          <div className="mt-4 flex flex-wrap gap-2">
            {Object.entries(s.by_status || {}).map(([status, count]) => (
              <div key={status} className="rounded-xl border border-white/15 bg-[#141414] px-4 py-3">
                <p className="text-[12px] font-bold capitalize">{status}</p>
                <p className="font-heading text-[22px] font-extrabold">{count}</p>
              </div>
            ))}
            {Object.keys(s.by_status || {}).length === 0 && (
              <p className="text-[13px] text-white/50">Aucune paire pour le moment.</p>
            )}
          </div>
        </div>

        {/* Stock par pointure */}
        <div className="mt-8">
          <h2 className="font-heading text-[18px] font-extrabold">Stock par pointure</h2>
          <div className="mt-4 flex flex-wrap gap-2">
            {Object.entries(s.by_size || {}).sort((a, b) => Number(a[0]) - Number(b[0])).map(([size, count]) => (
              <div key={size} className="rounded-xl border border-white/15 bg-[#141414] px-4 py-3">
                <p className="text-[12px] text-white/50">Pointure {size}</p>
                <p className="font-heading text-[22px] font-extrabold">{count}</p>
              </div>
            ))}
            {Object.keys(s.by_size || {}).length === 0 && (
              <p className="text-[13px] text-white/50">Aucune paire pour le moment.</p>
            )}
          </div>
        </div>

        {/* Passeports récents */}
        <div className="mt-8">
          <h2 className="font-heading text-[18px] font-extrabold">Passeports récents</h2>
          <div className="mt-4 space-y-2">
            {(s.recent_passports || []).slice().reverse().map((p) => (
              <div key={p.id} className="flex items-center justify-between rounded-xl border border-white/15 bg-[#141414] p-4">
                <div>
                  <p className="font-mono text-[13px] font-bold text-[#F2B90D]">{p.reference}</p>
                  <p className="text-[11px] text-white/50">Étape actuelle : {p.current_step}</p>
                </div>
                <MapPin className="h-4 w-4 text-white/50" />
              </div>
            ))}
            {(s.recent_passports || []).length === 0 && (
              <p className="text-[13px] text-white/50">Aucun passeport émis pour le moment.</p>
            )}
          </div>
        </div>

        <div className="mt-8">
          <Link to="/don-paire" className="mr-3 inline-flex min-h-[44px] items-center rounded-full bg-[#F2B90D] px-6 text-[13px] font-bold text-black">Donner une paire</Link>
          <Link to="/besoin-paire" className="mr-3 inline-flex min-h-[44px] items-center rounded-full border border-white/30 px-6 text-[13px] font-bold">Besoin d'une paire</Link>
          <Link to="/relais" className="inline-flex min-h-[44px] items-center rounded-full border border-white/30 px-6 text-[13px] font-bold">Faire un relais</Link>
        </div>
      </div>
    </div>
  );
}