import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import PersonalPassportEditor from "@/components/comptepas/PersonalPassportEditor";
import usePassportHub from "@/components/comptepas/usePassportHub";
import { landingBackgroundFor } from "@/lib/landing/richPassportSections";
function OnboardingEditor({ me }) {
  const { data, createIdentity } = usePassportHub(me); const [identity, setIdentity] = useState(null); const creating = useRef(false); const navigate = useNavigate();
  useEffect(() => { if (!data || creating.current) return; if (data.identity) setIdentity(data.identity); else { creating.current = true; createIdentity().then(setIdentity); } }, [data, createIdentity]);
  if (!identity) return <p className="text-sm text-white/70">Création de votre passeport…</p>;
  return <div className="w-full max-w-lg rounded-[30px] bg-card/95 p-6 text-card-foreground shadow-2xl backdrop-blur-xl"><p className="text-[9px] font-bold uppercase tracking-[.22em] text-muted-foreground">Votre passeport personnel</p><h1 className="mt-2 text-3xl font-black">Présentez-vous simplement.</h1><p className="mb-6 mt-2 text-sm text-muted-foreground">Aucun document officiel n'est demandé. Vous choisissez ce qui est visible.</p><PersonalPassportEditor identity={identity} onCancel={() => navigate("/reseau")} onSaved={() => navigate("/reseau")} /></div>;
}
export default function PassportOnboarding() {
  const [me, setMe] = useState(null); const story = new URLSearchParams(window.location.search).get("story") || "commencer"; const background = landingBackgroundFor(story);
  useEffect(() => { base44.auth.me().then(setMe).catch(() => { window.location.href = `/register?story=${story}&next=${encodeURIComponent(`/onboarding?story=${story}`)}`; }); }, [story]);
  return <main className="relative flex min-h-screen items-center justify-center overflow-hidden px-4 py-24"><img src={background} alt="" className="absolute inset-0 h-full w-full object-cover" /><div className="absolute inset-0 bg-black/65" /><div className="relative">{me ? <OnboardingEditor me={me} /> : <p className="text-sm text-white/70">Ouverture…</p>}</div></main>;
}