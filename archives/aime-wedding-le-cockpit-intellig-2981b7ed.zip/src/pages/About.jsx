import { Link } from "react-router-dom";
import { useSeo } from "@/lib/seo/useSeo";

export default function About() {
  useSeo({ title: "À propos — Les Pas d’AIME", description: "Découvrez Les Pas d’AIME, le réseau solidaire qui coordonne les dons, les besoins et les relais grâce à une carte vivante et causale." });
  return <article className="mx-auto max-w-3xl px-6 py-16 text-[#F5F1E8]">
    <p className="font-mono text-[10px] font-bold uppercase tracking-[0.24em] text-accent">À propos</p>
    <h1 className="mt-4 text-4xl font-extrabold sm:text-6xl">Faire avancer chaque don, jusqu’à la bonne personne.</h1>
    <div className="mt-10 space-y-6 text-[16px] leading-8 text-white/70">
      <p>Les Pas d’AIME est une application de coordination solidaire conçue pour relier des dons disponibles, des besoins concrets et des personnes capables d’assurer un relais. Sa carte vivante rend visibles les objets qui peuvent circuler, les demandes encore ouvertes, les trajets proposés, les points partenaires et les événements locaux. Plutôt que d’afficher une simple liste, le moteur explique chaque recommandation selon une logique claire : SI une situation existe, ALORS une action devient utile, PARCE QUE cette action débloque une étape réelle du parcours.</p>
      <p>L’application s’adresse aux particuliers qui souhaitent donner, aux personnes ou accompagnateurs qui expriment un besoin, aux bénévoles qui peuvent transporter un objet, ainsi qu’aux associations, commerces, collectivités et organisateurs d’événements qui structurent la solidarité locale. La confidentialité guide le service : les zones restent approximatives, les bénéficiaires demeurent anonymes et aucun portrait personnel n’est nécessaire pour recevoir de l’aide.</p>
      <p>Les Pas d’AIME est construit par AIME®, un studio qui imagine des outils numériques capables de transformer des informations dispersées en actions compréhensibles et coordonnées. L’équipe réunit conception produit, design, technologie et réflexion sur l’impact social. Elle développe la plateforme avec les acteurs du terrain afin que chaque fonctionnalité reste simple, digne et directement utile. L’objectif n’est pas de remplacer les relations humaines, mais de leur donner un chemin lisible, traçable et rassurant.</p>
    </div>
    <Link to="/contact" className="mt-10 inline-flex min-h-[44px] items-center rounded-full bg-accent px-6 text-sm font-bold text-accent-foreground">Nous contacter</Link>
  </article>;
}