import { useSeo } from "@/lib/seo/useSeo";
import EditoHero from "@/components/landing/pas/EditoHero";
import RichPassportSection from "@/components/landing/rich/RichPassportSection";
import { PUBLIC_LANDING_SECTIONS } from "@/lib/landing/richPassportSections";
import FFooterSignature from "@/components/landing/formula/FFooterSignature";

export default function Landing() {
  useSeo({ title: "LES PAS D'AIME — Donner. Relayer. Recevoir.", description: "Donner un objet, relayer son trajet ou recevoir dignement. Le réseau vivant relie chaque geste et le passeport en garde la trace." });
  return <div className="relative overflow-hidden bg-[#090a09] text-[#f3eddd]">
    <EditoHero />
    {PUBLIC_LANDING_SECTIONS.map((section, index) => <RichPassportSection key={section.id} section={section} index={index} />)}
    <FFooterSignature />
  </div>;
}