import { Bot } from "lucide-react";
import DeviceAgentChat from "@/components/aimedevice/DeviceAgentChat";

// ─────────────────────────────────────────────────────────────────────────
// /embed/chat — le widget de chat (Mira) embarquable en iframe.
// Corrige le lien mort connu : la route n'existait pas et renvoyait 404.
// ─────────────────────────────────────────────────────────────────────────
export default function EmbedChat() {
  return (
    <div className="dark flex min-h-screen flex-col bg-[#0C0C0C] text-white">
      <header className="flex items-center gap-2 border-b border-white/10 px-4 py-3">
        <Bot className="h-4 w-4 text-accent" />
        <p className="font-mono text-[10px] font-semibold uppercase tracking-[0.25em] text-white/60">
          AIME® · Mira — agent de bord
        </p>
      </header>
      <div className="mx-auto w-full max-w-xl flex-1 px-2 py-3">
        <DeviceAgentChat />
      </div>
    </div>
  );
}