import { useSeo } from "@/lib/seo/useSeo";
import ReseauWorkspace from "@/components/reseau/ReseauWorkspace";

// LA CARTE VIVANTE — tout ce qui circule dans le réseau, en direct :
// dons, besoins et relais, avec filtres, alertes et traçabilité.
export default function CarteDuReseau() {
  useSeo({
    title: "Le réseau vivant — LES PAS D'AIME",
    description: "Dons, besoins, relais et incidents : observez la circulation sur la carte ou par ses liens de causalité.",
  });

  return (
    <div className="relative h-[calc(100dvh-4rem)] min-h-[560px] overflow-hidden bg-muted">
      <h1 className="sr-only">Le réseau vivant</h1>
      <ReseauWorkspace />
    </div>
  );
}