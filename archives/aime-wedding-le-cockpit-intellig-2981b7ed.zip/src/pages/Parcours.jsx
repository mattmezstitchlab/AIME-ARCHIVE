import { useEffect } from "react";
import { useLocation, Link } from "react-router-dom";
import { Footprints, Truck, Heart } from "lucide-react";
import { useSeo } from "@/lib/seo/useSeo";
import DonnerForm from "@/components/parcours/DonnerForm";
import RelaisForm from "@/components/parcours/RelaisForm";
import BesoinForm from "@/components/parcours/BesoinForm";

// LE PARCOURS — les trois gestes enchaînés sur une seule page :
// Donner → Relais → Besoin, reliés par la ligne du grand schéma.
const SECTIONS = [
  { id: "donner", icon: Footprints, color: "#F2B90D", kicker: "01 — Donner", titre: "Je donne", texte: "Chaussures, vêtements, couchage, hygiène, instruments : quelques informations et votre don entre dans le réseau, avec sa référence unique.", Form: DonnerForm },
  { id: "relais", icon: Truck, color: "#F2B90D", kicker: "02 — Relais", titre: "Je fais un relais", texte: "Un petit segment de votre propre trajet, jamais toute la chaîne.", Form: RelaisForm },
  { id: "besoin", icon: Heart, color: "#F2B90D", kicker: "03 — Besoin", titre: "J'ai besoin", texte: "Seul le nécessaire est demandé. Jamais de photo, jamais d'adresse précise.", Form: BesoinForm },
];

export default function Parcours() {
  useSeo({
    title: "Le parcours — LES PAS D'AIME",
    description: "Donner une paire, faire un relais, exprimer un besoin : les trois gestes du réseau sur une seule page.",
  });
  const location = useLocation();

  useEffect(() => {
    const id = location.hash?.replace("#", "");
    if (!id) { window.scrollTo(0, 0); return; }
    const el = document.getElementById(id);
    if (el) setTimeout(() => el.scrollIntoView({ behavior: "smooth", block: "start" }), 50);
  }, [location.hash]);

  return (
    <div className="min-h-screen bg-[#0D0D0D] px-6 py-28 text-[#F5F1E8]">
      <div className="mx-auto max-w-3xl">
        <Link to="/" className="text-[13px] text-white/50 hover:text-white">← Retour à l'accueil</Link>
        <p className="mt-6 font-mono text-[11px] font-bold uppercase tracking-[0.3em] text-[#F2B90D]">Le parcours</p>
        <h1 className="mt-3 font-heading text-[clamp(2.2rem,7vw,4.5rem)] font-extrabold uppercase leading-[0.95] tracking-[-0.04em]">
          <span style={{ color: "#F2B90D" }}>Donner.</span>{" "}
          <span className="text-[#F5F1E8]">Relayer.</span>{" "}
          <span style={{ color: "#F2B90D" }}>Recevoir.</span>
        </h1>
        <p className="mt-4 max-w-lg text-[15px] leading-7 text-white/60">
          Trois gestes, un seul chemin. Choisissez le vôtre — la ligne fait le reste.
        </p>

        <div className="mt-16">
          {SECTIONS.map((s, i) => (
            <ParcoursSection key={s.id} section={s} isLast={i === SECTIONS.length - 1} />
          ))}
        </div>
      </div>
    </div>
  );
}

function ParcoursSection({ section, isLast }) {
  const { id, icon: Icon, color, kicker, titre, texte, Form } = section;
  return (
    <section id={id} className="relative flex scroll-mt-24 gap-5 md:gap-10">
      {/* Nœud + ligne pointillée */}
      <div className="flex flex-col items-center">
        <div className="relative z-10 flex h-16 w-16 shrink-0 items-center justify-center rounded-full md:h-24 md:w-24" style={{ backgroundColor: color }}>
          <Icon className="h-7 w-7 text-black md:h-10 md:w-10" aria-hidden="true" />
        </div>
        {!isLast && (
          <div className="relative w-px flex-1 min-h-[60px]">
            <div className="absolute inset-0 border-l-2 border-dashed border-white/15" />
          </div>
        )}
      </div>

      {/* Contenu */}
      <div className={`min-w-0 flex-1 ${isLast ? "" : "pb-20 md:pb-28"}`}>
        <p className="font-mono text-[11px] font-bold uppercase tracking-[0.24em]" style={{ color }}>{kicker}</p>
        <h2 className="mt-2 font-heading text-[clamp(1.5rem,4vw,2.6rem)] font-extrabold uppercase leading-[1.02] tracking-[-0.03em]">{titre}</h2>
        <p className="mt-3 max-w-xl text-[14px] leading-7 text-white/60">{texte}</p>
        <div className="mt-8">
          <Form color={color} />
        </div>
      </div>
    </section>
  );
}