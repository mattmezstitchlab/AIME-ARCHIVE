import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import AssoBesoins from "@/components/association/AssoBesoins";
import AssoEvenements from "@/components/association/AssoEvenements";
import AssoEnApproche from "@/components/association/AssoEnApproche";
import { useSeo } from "@/lib/seo/useSeo";

// LE TABLEAU ASSOCIATION — besoins ouverts, dons en approche et remises, en un seul écran.
export default function Association() {
  useSeo({ title: "Tableau association — Les Pas d'AIME", description: "La vue de terrain : besoins ouverts, dons en approche, remises à confirmer." });
  const [data, setData] = useState(null);

  useEffect(() => {
    (async () => {
      const [needs, matches, pairs] = await Promise.all([
        base44.entities.ShoeNeed.list("-created_date", 200),
        base44.entities.ShoeMatch.filter({ status: "accepte" }, "-created_date", 100),
        base44.entities.ShoePair.list("-created_date", 200),
      ]);
      const ouverts = needs.filter((n) => ["ouvert", "propositions", "en_cours"].includes(n.status));
      const approches = matches
        .map((m) => ({
          match: m,
          pair: pairs.find((p) => p.id === m.pair_id),
          need: needs.find((n) => n.id === m.need_id),
        }))
        .filter(({ pair }) => pair && ["associee", "en_relais", "arrivee"].includes(pair.status));
      setData({ ouverts, approches });
    })();
  }, []);

  return (
    <div className="mx-auto max-w-4xl px-4 pb-24">
      <header className="pt-8">
        <p className="font-mono text-[11px] font-bold uppercase tracking-[0.25em] text-[#F2B90D]">Tableau association</p>
        <h1 className="mt-2 text-[clamp(1.6rem,4vw,2.4rem)] font-extrabold leading-tight">
          Le terrain, en un seul écran.
        </h1>
        <p className="mt-3 max-w-2xl text-[14px] leading-relaxed text-white/60">
          Vos besoins ouverts, les dons en approche vers votre zone, et l'accès aux confirmations de remise.
        </p>
      </header>

      {data === null ? (
        <p className="mt-8 text-[13px] text-white/50">Chargement du tableau…</p>
      ) : (
        <>
          <section className="mt-8">
            <h2 className="text-[15px] font-extrabold">Vos événements — inscriptions, paiements, documents</h2>
            <div className="mt-3"><AssoEvenements /></div>
          </section>

          <section className="mt-8">
            <h2 className="text-[15px] font-extrabold">
              Besoins ouverts <span className="ml-1 rounded-full bg-[#E03A21] px-2.5 py-0.5 text-[11px] font-bold text-white">{data.ouverts.length}</span>
            </h2>
            <div className="mt-3"><AssoBesoins needs={data.ouverts} /></div>
          </section>

          <section className="mt-8">
            <h2 className="text-[15px] font-extrabold">
              Dons en approche <span className="ml-1 rounded-full bg-[#F2B90D] px-2.5 py-0.5 text-[11px] font-bold text-black">{data.approches.length}</span>
            </h2>
            <div className="mt-3"><AssoEnApproche approches={data.approches} /></div>
          </section>

          <section className="mt-8 rounded-2xl border border-white/10 bg-[#141414] p-5">
            <h2 className="text-[15px] font-extrabold">Remises à confirmer</h2>
            <p className="mt-1 text-[13px] text-white/60">
              Les confirmations de remise (jeton sécurisé) se font depuis le cockpit du réseau.
            </p>
            <Link to="/cockpit" className="mt-3 inline-flex min-h-[42px] items-center rounded-full border border-white/30 px-5 text-[12px] font-bold transition hover:border-white">
              Ouvrir le cockpit
            </Link>
          </section>
        </>
      )}
    </div>
  );
}