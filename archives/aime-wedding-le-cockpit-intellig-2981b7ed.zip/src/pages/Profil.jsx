import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Loader2 } from "lucide-react";
import { useSeo } from "@/lib/seo/useSeo";
import { base44 } from "@/api/base44Client";
import CreerProfilForm from "@/components/profil/CreerProfilForm";

// MON PROFIL — l'entrée unique : si ma carte existe déjà, j'atterris sur SA
// page profil (celle du Registre) ; sinon, je la crée ici, proprement.
export default function Profil() {
  useSeo({
    title: "AIME® — Mon profil",
    description: "Créez votre carte profil : elle devient votre page au Registre AIME®, avec vos mini-sites rattachés.",
  });

  const navigate = useNavigate();
  const [pret, setPret] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const me = await base44.auth.me();
        const cards = await base44.entities.PersonCard.list("-updated_date", 200);
        const mine = cards.find((c) => c.created_by_id === me.id);
        if (mine) {
          navigate(`/registre/carte/${mine.id}`, { replace: true });
          return;
        }
      } catch {
        // pas connecté·e : on montre quand même la création.
      }
      setPret(true);
    })();
  }, [navigate]);

  if (!pret) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#0C0C0C] text-white/50">
        <Loader2 className="mr-2 h-5 w-5 animate-spin" aria-hidden="true" />
        <p className="text-[13px]">Ouverture de votre profil…</p>
      </div>
    );
  }

  return (
    <div className="dot-grid-dark min-h-screen bg-[#0C0C0C] pt-10 pb-20 text-white">
      <div className="mx-auto max-w-xl px-6">
        <p className="font-mono text-[10px] font-semibold uppercase tracking-[0.26em] text-white/40">
          AIME® · Mon profil
        </p>
        <h1 className="mt-2 font-heading text-[clamp(1.7rem,4vw,2.4rem)] font-extrabold leading-[1.1] tracking-[-0.03em]">
          Une personne, une carte<span className="text-[#C9A96E]">.</span>
        </h1>
        <p className="mt-2 text-[13.5px] leading-6 text-white/50">
          Votre carte est votre identité sur AIME® : elle vit au Registre, se branche
          aux mariages, et rassemble vos mini-sites publiés.
        </p>

        <div className="mt-7">
          <CreerProfilForm onCree={(card) => navigate(`/registre/carte/${card.id}`, { replace: true })} />
        </div>
      </div>
    </div>
  );
}