import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import BureauPromise from "@/components/bureau-reseau/BureauPromise";
import BureauProfilePanel from "@/components/bureau-reseau/BureauProfilePanel";
import { useSeo } from "@/lib/seo/useSeo";

export default function ReseauBureau() {
  useSeo({ title: "Mon profil — Les Pas d’AIME", description: "Votre profil global, vos passeports, dons, relais et dossards." });
  const [me, setMe] = useState(null);
  const [anonymous, setAnonymous] = useState(false);
  useEffect(() => { base44.auth.me().then(setMe).catch(() => setAnonymous(true)); }, []);
  if (anonymous) return <div className="mx-auto max-w-lg px-4 py-24 text-center"><h1 className="text-3xl font-extrabold">Votre profil en un écran.</h1><p className="mt-4 text-white/65">Connectez-vous pour retrouver vos passeports, dons, relais et dossards.</p><button onClick={() => base44.auth.redirectToLogin("/bureau")} className="mt-6 min-h-[44px] rounded-full bg-[#F2B90D] px-6 text-sm font-bold text-black">Se connecter</button></div>;
  if (!me) return <div className="flex min-h-[60vh] items-center justify-center"><div className="h-8 w-8 animate-spin rounded-full border-2 border-white/20 border-t-[#F2B90D]" aria-label="Chargement…" /></div>;
  return (
    <div className="mx-auto max-w-[1100px] px-4 py-5 sm:px-6">
      <BureauPromise />
      <BureauProfilePanel me={me} />
    </div>
  );
}