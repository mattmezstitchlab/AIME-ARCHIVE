import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import SitePlusRender from "@/components/weddingos/SitePlusRender";
import SiteStudioRender from "@/components/sitepublic/SiteStudioRender";
import ProfilPlusPublic from "@/components/profilplus/ProfilPlusPublic";
import PageNotFound from "@/lib/PageNotFound";

// LE PROTOCOLE « + » — /+nom résout l'adresse d'un mini-site publié.
// Tout chemin qui ne commence pas par + reste un 404 classique.
export default function SitePlusPublic() {
  const { adresse } = useParams();
  const estPlus = adresse?.startsWith("+");
  const [etat, setEtat] = useState("chargement");
  const [rec, setRec] = useState(null);
  const [profil, setProfil] = useState(null);

  useEffect(() => {
    if (!estPlus) return;
    (async () => {
      const [r] = await base44.entities.PublishedSite.filter({ slug: adresse.slice(1), published: true });
      if (r) { setRec(r); setEtat("ok"); return; }
      // L'adresse « + » peut aussi être une page profil : tout le monde a la sienne.
      const [p] = await base44.entities.ProfilPlus.filter({ plus_adresse: adresse.slice(1) });
      if (p) { setProfil(p); setEtat("profil"); return; }
      setEtat("absent");
    })();
  }, [adresse, estPlus]);

  if (!estPlus) return <PageNotFound />;

  if (etat === "chargement") {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#0C0C0C] text-white/50">
        <Loader2 className="mr-2 h-5 w-5 animate-spin" aria-hidden="true" />
        <p className="text-[13px]">Résolution de l'adresse {adresse}…</p>
      </div>
    );
  }

  if (etat === "absent") {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-3 bg-[#0C0C0C] px-6 text-center text-white">
        <p className="font-mono text-[12px] font-bold" style={{ color: "#C9A96E" }}>{adresse}</p>
        <p className="text-[14px] text-white/60">Aucun site publié à cette adresse pour l'instant.</p>
        <Link to="/" className="text-[12px] text-white/45 underline underline-offset-4 hover:text-white">
          Retour à l'accueil LE MONDE AIME
        </Link>
      </div>
    );
  }

  // Les pages profil « + » — le concept +me : chaque personne sur son adresse.
  if (etat === "profil") return <ProfilPlusPublic profil={profil} />;

  // Les sites composés au Studio AI+ME ont leur propre rendu public.
  if (rec.site?.type === "studio") return <SiteStudioRender site={rec.site} adresse={`+${rec.slug}`} />;
  return <SitePlusRender site={rec.site} adresse={`+${rec.slug}`} />;
}