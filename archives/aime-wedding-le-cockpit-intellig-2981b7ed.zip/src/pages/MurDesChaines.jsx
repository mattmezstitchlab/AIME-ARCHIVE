import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import ChaineCarte from "@/components/chaines/ChaineCarte";
import { useSeo } from "@/lib/seo/useSeo";

// LE MUR DES CHAÎNES — les trajets terminés, rejoués publiquement, sans aucune donnée personnelle.
export default function MurDesChaines() {
  useSeo({ title: "Le mur des chaînes — Les Pas d'AIME", description: "Chaque don remis rejoue son trajet : la preuve vivante que ça marche." });
  const [chaines, setChaines] = useState(null);

  useEffect(() => {
    (async () => {
      const passports = await base44.entities.PairPassport.list("-updated_date", 100);
      setChaines(passports.filter((p) => p.current_step === "remise"));
    })();
  }, []);

  return (
    <div className="mx-auto max-w-4xl px-4 pb-24">
      <header className="pt-8">
        <p className="font-mono text-[11px] font-bold uppercase tracking-[0.25em] text-[#F2B90D]">Le mur des chaînes</p>
        <h1 className="mt-2 text-[clamp(1.6rem,4vw,2.4rem)] font-extrabold leading-tight">
          Chaque don remis raconte son voyage.
        </h1>
        <p className="mt-3 max-w-2xl text-[14px] leading-relaxed text-white/60">
          Ici, les chaînes terminées se rejouent — donateur, contrôle, relais, remise anonyme.
          Aucune donnée personnelle : juste la preuve vivante que le réseau marche.
        </p>
      </header>

      {chaines === null ? (
        <p className="mt-8 text-[13px] text-white/50">Chargement des chaînes…</p>
      ) : chaines.length === 0 ? (
        <p className="mt-8 rounded-2xl border border-white/10 bg-[#141414] p-6 text-[13px] text-white/50">
          Aucune chaîne terminée pour l'instant — la première remise apparaîtra ici.
        </p>
      ) : (
        <div className="mt-8 grid gap-4 sm:grid-cols-2">
          {chaines.map((pp) => <ChaineCarte key={pp.id} passport={pp} />)}
        </div>
      )}
    </div>
  );
}