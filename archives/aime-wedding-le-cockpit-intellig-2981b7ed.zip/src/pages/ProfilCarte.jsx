import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { ArrowLeft, Loader2 } from "lucide-react";
import { useSeo } from "@/lib/seo/useSeo";
import { base44 } from "@/api/base44Client";
import PersonneCarte from "@/components/registre/carte/PersonneCarte";
import AdressePlusCarte from "@/components/registre/sites/AdressePlusCarte";
import SiteCarte from "@/components/registre/sites/SiteCarte";

// LA PAGE PROFIL D'UNE CARTE — la carte profil à gauche (retournable),
// et à droite tous les mini-sites créés par la personne : les adresses « + »
// publiées depuis le Wedding OS et les mini-sites du Bureau.
export default function ProfilCarte() {
  const { id } = useParams();
  const [card, setCard] = useState(null);
  const [charge, setCharge] = useState(true);
  const [me, setMe] = useState(null);
  const [flipped, setFlipped] = useState(false);
  const [plusSites, setPlusSites] = useState([]);
  const [sites, setSites] = useState([]);

  useSeo({
    title: `AIME® — ${card?.display_name || "Profil"}`,
    description: card ? `${card.display_name} — sa carte profil et ses mini-sites au Registre AIME®.` : "Page profil du Registre AIME®.",
  });

  useEffect(() => {
    base44.entities.PersonCard.filter({ id }).then(([c]) => { setCard(c || null); setCharge(false); });
    base44.auth.me().then(setMe).catch(() => {});
  }, [id]);

  useEffect(() => {
    if (!card?.created_by_id) return;
    base44.entities.PublishedSite.filter({ published: true }).then((ss) =>
      setPlusSites(ss.filter((s) => s.created_by_id === card.created_by_id))
    );
    base44.entities.AimeProject.list("-updated_date", 100).then((ps) =>
      setSites(ps.filter((p) => p.minisite && p.status !== "archived" && p.created_by_id === card.created_by_id))
    );
  }, [card]);

  const isOwn = !!(me && card && card.created_by_id === me.id);
  const rsvp = (weddingName, status) => {
    const data = { rsvp: { ...(card.rsvp || {}), [weddingName]: status } };
    setCard((c) => ({ ...c, ...data }));
    base44.entities.PersonCard.update(card.id, data);
  };

  if (charge) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#0C0C0C] text-white/50">
        <Loader2 className="mr-2 h-5 w-5 animate-spin" aria-hidden="true" />
        <p className="text-[13px]">Ouverture du profil…</p>
      </div>
    );
  }

  if (!card) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-[#0C0C0C] text-white">
        <p className="text-white/60">Cette carte n'existe pas dans le Registre.</p>
        <Link to="/registre" className="mt-4 text-[13px] text-[#c9a96e] underline underline-offset-4">
          ← Revenir au Registre
        </Link>
      </div>
    );
  }

  const totalSites = plusSites.length + sites.length;

  return (
    <div className="dot-grid-dark min-h-screen bg-[#0C0C0C] pt-24 pb-20 text-white">
      <div className="mx-auto max-w-6xl px-6">
        <Link to="/registre" className="inline-flex items-center gap-1.5 text-[12px] text-white/45 transition hover:text-white">
          <ArrowLeft className="h-3.5 w-3.5" aria-hidden="true" /> Le Registre
        </Link>

        <div className="mt-6 grid items-start gap-8 lg:grid-cols-[340px_1fr]">
          {/* LA CARTE PROFIL — retournable ici. */}
          <div>
            <PersonneCarte
              card={card}
              isOwn={isOwn}
              myWeddingName={null}
              flipped={flipped}
              onToggle={() => setFlipped((f) => !f)}
              onRsvp={isOwn ? rsvp : undefined}
            />
          </div>

          {/* LES MINI-SITES CRÉÉS — adresses « + » et sites du Bureau. */}
          <div>
            <p className="font-mono text-[10px] font-semibold uppercase tracking-[0.26em] text-white/40">
              AIME® · Page profil
            </p>
            <h1 className="mt-2 font-heading text-3xl font-semibold tracking-[-0.03em]">{card.display_name}</h1>
            {card.essence && <p className="mt-1.5 max-w-xl text-[13.5px] leading-6 text-white/50">{card.essence}</p>}

            <section aria-label="Les mini-sites créés" className="mt-8">
              <p className="mb-3 font-mono text-[9px] font-semibold uppercase tracking-[0.26em] text-white/40">
                {isOwn ? "Mes mini-sites" : "Ses mini-sites"} · {totalSites}
              </p>
              {totalSites === 0 ? (
                <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-8 text-center">
                  <p className="text-[13px] text-white/50">
                    Aucun mini-site publié pour l'instant.
                    {isOwn && (
                      <>
                        {" "}
                        <Link to="/wedding-os" className="font-semibold text-white underline underline-offset-4">
                          Ouvrez le Wedding OS
                        </Link>{" "}
                        et publiez le vôtre.
                      </>
                    )}
                  </p>
                </div>
              ) : (
                <div className="grid gap-4 sm:grid-cols-2">
                  {plusSites.map((s) => (
                    <AdressePlusCarte key={s.id} site={s} />
                  ))}
                  {sites.map((p) => (
                    <SiteCarte key={p.id} project={p} />
                  ))}
                </div>
              )}
            </section>
          </div>
        </div>
      </div>
    </div>
  );
}