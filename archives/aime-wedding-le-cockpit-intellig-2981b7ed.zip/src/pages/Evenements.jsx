import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Plus } from "lucide-react";
import EvenementCarte from "@/components/evenements/EvenementCarte";
import EvenementForm from "@/components/evenements/EvenementForm";
import { useSeo } from "@/lib/seo/useSeo";

// LES ÉVÉNEMENTS SOLIDAIRES — marches, courses, randos : inscription et dossard automatique.
export default function Evenements() {
  useSeo({ title: "Événements solidaires — Les Pas d'AIME", description: "Marches nordiques, courses et randos solidaires : inscrivez-vous, recevez votre dossard." });
  const [events, setEvents] = useState(null);
  const [creer, setCreer] = useState(false);

  const charger = async () => {
    const all = await base44.entities.SolidarityEvent.list("-created_date", 100);
    setEvents(all.filter((e) => !["done", "cancelled"].includes(e.status)));
  };
  useEffect(() => { charger(); }, []);

  return (
    <div className="mx-auto max-w-4xl px-4 pb-24">
      <header className="pt-8">
        <p className="font-mono text-[11px] font-bold uppercase tracking-[0.25em] text-[#F2B90D]">Événements solidaires</p>
        <h1 className="mt-2 text-[clamp(1.6rem,4vw,2.4rem)] font-extrabold leading-tight">
          Marchez, courez — chaque pas porte un don.
        </h1>
        <p className="mt-3 max-w-2xl text-[14px] leading-relaxed text-white/60">
          Marche nordique, course, rando : créez un événement, ouvrez les inscriptions —
          chaque inscrit reçoit son dossard numéroté et peut promettre des dons pour la cause.
        </p>
        <button onClick={() => setCreer((v) => !v)}
          className="mt-5 flex min-h-[46px] items-center gap-2 rounded-full bg-[#F2B90D] px-6 text-[13px] font-bold text-black transition hover:opacity-85">
          <Plus className="h-4 w-4" aria-hidden="true" /> Créer un événement
        </button>
      </header>

      {creer && (
        <div className="mt-6">
          <EvenementForm onCreated={() => { setCreer(false); charger(); }} />
        </div>
      )}

      <div className="mt-8">
        {events === null ? (
          <p className="text-[13px] text-white/50">Chargement des événements…</p>
        ) : events.length === 0 ? (
          <p className="rounded-2xl border border-white/10 bg-[#141414] p-6 text-[13px] text-white/50">
            Aucun événement à venir — créez le premier.
          </p>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2">
            {events.map((ev) => <EvenementCarte key={ev.id} event={ev} onUpdate={charger} />)}
          </div>
        )}
      </div>
    </div>
  );
}