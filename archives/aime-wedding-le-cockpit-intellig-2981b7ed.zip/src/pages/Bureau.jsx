import { useState, useEffect, useRef } from "react";
import EnregistrerExemple from "@/components/bureau/enregistrer/EnregistrerExemple";
import { useSeo } from "@/lib/seo/useSeo";
import BureauAppWindow from "@/components/bureau/apps/BureauAppWindow";
import PointZeroConversation from "@/components/bureau/pointzero/PointZeroConversation";
import ProjectHeaderBar from "@/components/bureau/ripple/ProjectHeaderBar";
import ProjectFacetSection from "@/components/bureau/ripple/ProjectFacetSection";
import ProjectCanvasButton from "@/components/bureau/ripple/ProjectCanvasButton";
import MiniSite from "@/components/bureau/minisite/MiniSite";
import MiniSiteFlow from "@/components/bureau/minisite/flow/MiniSiteFlow";
import ProjectDirectionStrip from "@/components/bureau/ripple/ProjectDirectionStrip";
import CapsuleAime from "@/components/bureau/CapsuleAime";
import { base44 } from "@/api/base44Client";

// ─────────────────────────────────────────────────────────────────────────
// LE BUREAU — canevas noir à points :
// · GAUCHE — l'arborescence des dossiers, FIXE (ne scrolle pas avec la page).
// · CENTRE — le Point Zéro affiché directement, ou le projet ouvert.
// Plus de panneau de questions : tout se règle au verso des cartes,
// avec l'agent IA spécialiste de chaque carte.
// ─────────────────────────────────────────────────────────────────────────

export default function Bureau() {
  useSeo({
    title: "AIME® — Mon Bureau",
    description: "Le Grand Canevas : le Point Zéro et vos dossiers de projet.",
  });

  const [openApp, setOpenApp] = useState(null);
  const [projects, setProjects] = useState([]);
  const [activeId, setActiveId] = useState(null);
  const [miniSite, setMiniSite] = useState(false);
  const [flowMiniSite, setFlowMiniSite] = useState(false);
  const active = projects.find((p) => p.id === activeId);

  // Mode EXEMPLE « S'enregistrer » — la page d'enregistrement est le Bureau.
  const urlParams = new URLSearchParams(window.location.search);
  const exempleEnregistrer = urlParams.get("exemple") === "senregistrer";

  useEffect(() => {
    const ha = (e) => setOpenApp(e.detail.app);
    const hp = (e) => { handleGenerated(e.detail); setOpenApp(null); };
    window.addEventListener("aime-bureau-app", ha);
    window.addEventListener("aime-eaa-projet", hp);
    return () => {
      window.removeEventListener("aime-bureau-app", ha);
      window.removeEventListener("aime-eaa-projet", hp);
    };
  }, []);

  useEffect(() => {
    base44.entities.AimeProject.list("-updated_date", 50).then(setProjects);
  }, []);

  const handleGenerated = async (ob) => {
    const created = await base44.entities.AimeProject.create({
      intent: ob.intent,
      complexity: ob.complexity,
      project_title: ob.project_title || ob.intent,
      project_type: ob.project_type || "",
      intro: ob.intro || "",
      direction: ob.direction || null,
      visuals: ob.visuals || [],
      questions: ob.questions || [],
      answers: {},
    });
    setProjects((ps) => [created, ...ps]);
    setActiveId(created.id);
  };

  const handleFacetsGenerated = (facets) => {
    if (!active) return;
    const projId = active.id;
    setProjects((ps) => ps.map((p) => (p.id === projId ? { ...p, facets } : p)));
    base44.entities.AimeProject.update(projId, { facets });
  };

  const facetTimer = useRef(null);
  const handleFacetValue = (facetKey, itemId, v) => {
    if (!active) return;
    const projId = active.id;
    const facet_values = {
      ...(active.facet_values || {}),
      [facetKey]: { ...(active.facet_values?.[facetKey] || {}), [itemId]: v },
    };
    setProjects((ps) => ps.map((p) => (p.id === projId ? { ...p, facet_values } : p)));
    clearTimeout(facetTimer.current);
    facetTimer.current = setTimeout(() => base44.entities.AimeProject.update(projId, { facet_values }), 600);
  };

  return (
    /* LE BUREAU FAÇON OS — le fond du Wedding OS, le canevas au centre
       (les cartes sur une timeline horizontale), l'agent à droite (Framer). */
    <div className="dot-grid-dark min-h-screen bg-[#0A0A0B] pt-24 pb-10 text-white">
      <div className="mx-auto flex max-w-[1500px] items-start gap-4 px-4 lg:px-6">
        <h1 className="sr-only">AIME® — Mon Bureau : le Grand Canevas</h1>

        {/* CENTRE — le canevas : le projet ouvert, ou le dossier Cartes. */}
        <main className="min-w-0 flex-1">
          {flowMiniSite ? (
            <MiniSiteFlow onClose={() => setFlowMiniSite(false)} />
          ) : exempleEnregistrer ? (
            <EnregistrerExemple />
          ) : openApp ? (
            <BureauAppWindow appId={openApp} onClose={() => setOpenApp(null)} />
          ) : active ? (
            miniSite ? (
              <MiniSite
                project={active}
                onClose={() => setMiniSite(false)}
                onSaved={(ms) => setProjects((ps) => ps.map((p) => (p.id === active.id ? { ...p, minisite: ms } : p)))}
              />
            ) : (
              <div className="space-y-3">
                <ProjectHeaderBar project={active} onClose={() => { setActiveId(null); setMiniSite(false); }} />
                <ProjectDirectionStrip direction={active.direction} />
                <ProjectFacetSection
                  project={active}
                  onFacetsGenerated={handleFacetsGenerated}
                  onSaveValue={handleFacetValue}
                />
                <ProjectCanvasButton project={active} onOpen={() => setMiniSite(true)} />
              </div>
            )
          ) : (
            /* LE BIJOU UNIQUE — rien d'autre que la capsule AI+ME au centre :
               le Pipeline EAA vit dans le panneau du bouton +. */
            <div className="flex min-h-[70vh] flex-col items-center justify-center">
              <CapsuleAime />
            </div>
          )}
        </main>

        {/* DROITE — l'agent, comme dans Framer : toujours là, il crée les
            cartes qui apparaissent au centre. */}
        <aside className={`sticky top-24 w-[380px] shrink-0 ${flowMiniSite || (!openApp && !active && !exempleEnregistrer) ? "hidden" : "hidden lg:block"}`} aria-label="L'agent Point Zéro">
          <div className="rounded-2xl border border-white/10 bg-[#0e0e11] p-4 shadow-xl">
            <div className="mb-3 flex items-center gap-2.5">
              <span className="flex h-8 w-8 items-center justify-center rounded-full bg-[conic-gradient(from_0deg,#ff5f6d,#ffc371,#c9f76f,#38bdf8,#c084fc,#ff5f6d)] text-sm font-bold text-black">
                +
              </span>
              <div>
                <p className="text-[12px] font-semibold text-white">Point Zéro</p>
                <p className="font-mono text-[8px] font-semibold uppercase tracking-[0.22em] text-white/35">
                  L'agent crée vos cartes
                </p>
              </div>
            </div>
            <PointZeroConversation onGenerated={handleGenerated} onOpenApp={setOpenApp} onMiniSite={() => setFlowMiniSite(true)} />
          </div>
        </aside>
      </div>
    </div>
  );
}