import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { Loader2, Sparkles } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useSeo } from "@/lib/seo/useSeo";
import MiniSiteRender from "@/components/bureau/minisite/MiniSiteRender";
import RepriseDialog from "@/components/registre/sites/RepriseDialog";
import ValeurBadge from "@/components/registre/sites/ValeurBadge";
import SignalementsPanel from "@/components/registre/sites/SignalementsPanel";
import { estimerValeur } from "@/lib/registre/siteValeur";

// LE SITE PUBLIC — le mini-site généré, visitable depuis sa carte du
// Registre. En bas : la barre de reprise — n'importe qui peut régénérer
// ce site pour lui, à petit prix, en rectifiant juste ses infos.
export default function SitePublic() {
  const { id } = useParams();
  const [project, setProject] = useState(null);
  const [manque, setManque] = useState(false);
  const [busy, setBusy] = useState(false);
  const [reprise, setReprise] = useState(false);
  const [valuation, setValuation] = useState(null);
  const [me, setMe] = useState(null);
  useSeo({ title: project ? `${project.project_title || project.intent} — Mini-site AIME®` : "Mini-site AIME®" });

  useEffect(() => {
    base44.entities.AimeProject.get(id).then(setProject).catch(() => setManque(true));
    base44.auth.me().then(setMe).catch(() => {});
  }, [id]);

  // LE PRIX VIVANT — estimé et justifié par l'IA à la première visite,
  // puis il évolue à la hausse avec la configuration et les corrections.
  useEffect(() => {
    if (!project?.minisite || valuation) return;
    if (project.valuation?.prix) setValuation(project.valuation);
    else estimerValeur(project, null).then(setValuation);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [project]);

  // Retour de paiement : on vérifie la session, puis on ouvre la rectification.
  useEffect(() => {
    const sessionId = new URLSearchParams(window.location.search).get("reuse_session");
    if (!sessionId) return;
    base44.functions.invoke("siteReuseCheckout", { action: "verify", sessionId }).then((r) => {
      if (r.data?.paid) setReprise(true);
      window.history.replaceState({}, "", `/site/${id}`);
    });
  }, [id]);

  const payer = async () => {
    if (busy) return;
    setBusy(true);
    try {
      const r = await base44.functions.invoke("siteReuseCheckout", {
        action: "create",
        projectId: id,
        originUrl: window.location.origin,
      });
      if (r.data?.url) window.location.href = r.data.url;
      else setBusy(false);
    } catch {
      setBusy(false);
    }
  };

  if (manque) {
    return (
      <div className="grid min-h-screen place-items-center bg-[#0A0A0B] text-white/50">
        <p className="text-[13px]">Ce mini-site n'existe plus. <Link to="/registre" className="text-white underline underline-offset-4">Retour au Registre</Link></p>
      </div>
    );
  }
  if (!project) {
    return (
      <div className="grid min-h-screen place-items-center bg-[#0A0A0B]">
        <Loader2 className="h-5 w-5 animate-spin text-white/40" aria-hidden="true" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0A0A0B] px-4 pb-28 pt-6 text-white">
      <div className="mx-auto max-w-4xl">
        <div className="mb-4 flex items-center justify-between">
          <Link to="/registre" className="font-mono text-[9px] font-semibold uppercase tracking-[0.24em] text-white/40 transition hover:text-white">
            ← Le Registre
          </Link>
          <span className="font-mono text-[9px] font-semibold uppercase tracking-[0.24em] text-white/40">Mini-site AIME®</span>
        </div>
        <MiniSiteRender project={project} site={project.minisite || {}} />
        <SignalementsPanel
          project={project}
          valuation={valuation}
          isOwn={me ? project.created_by_id === me.id : false}
          onMaj={setValuation}
        />
      </div>

      {/* LA BARRE DE REPRISE — flottante, en bas. */}
      <div className="fixed inset-x-0 bottom-4 z-40 px-4">
        <div className="mx-auto flex max-w-xl items-center justify-between gap-3 rounded-2xl border border-white/12 bg-black/75 px-5 py-3 backdrop-blur-xl">
          <div className="min-w-0">
            <p className="text-[12px] leading-snug text-white/70">
              <span className="font-semibold text-white">Ce site vous plaît ?</span> Reprenez-le — vous n'aurez qu'à rectifier vos infos.
            </p>
            <ValeurBadge valuation={valuation} />
          </div>
          <button
            type="button"
            onClick={payer}
            disabled={busy}
            className="inline-flex shrink-0 items-center gap-1.5 rounded-full bg-white px-4 py-2 text-[12px] font-bold text-black transition hover:bg-white/85 disabled:opacity-50"
          >
            {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Sparkles className="h-3.5 w-3.5" />}
            Reprendre — {valuation?.prix ?? "…"} €
          </button>
        </div>
      </div>

      {reprise && <RepriseDialog project={project} onClose={() => setReprise(false)} />}
    </div>
  );
}