import { useSeo } from "@/lib/seo/useSeo";

export default function Contact() {
  useSeo({ title: "Contact — Les Pas d’AIME", description: "Contactez l’équipe Les Pas d’AIME pour une question, un partenariat ou un accompagnement sur le réseau solidaire." });
  return <section className="mx-auto max-w-3xl px-6 py-16 text-[#F5F1E8]">
    <p className="font-mono text-[10px] font-bold uppercase tracking-[0.24em] text-accent">Contact</p>
    <h1 className="mt-4 text-4xl font-extrabold sm:text-6xl">Parlons de votre prochain pas.</h1>
    <p className="mt-8 max-w-2xl text-[16px] leading-8 text-white/70">Une question sur un don, un relais, un besoin ou un partenariat local ? Écrivez à l’équipe Les Pas d’AIME. Nous vous répondrons avec les informations utiles pour avancer.</p>
    <a href="mailto:bonjour@aime-wedding.app" className="mt-10 inline-flex min-h-[48px] items-center rounded-full bg-accent px-6 text-sm font-bold text-accent-foreground">bonjour@aime-wedding.app</a>
  </section>;
}