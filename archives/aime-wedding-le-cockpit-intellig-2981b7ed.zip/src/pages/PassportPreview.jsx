import { useCallback, useEffect, useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { ALL_LANDING_PASSPORTS, findLandingPassport, passportSignupLink } from "@/lib/landing/richPassportSections";
import PassportVisualRail from "@/components/passport/public/PassportVisualRail";
import PassportCenterCard from "@/components/passport/public/PassportCenterCard";
import PassportProcess from "@/components/passport/public/PassportProcess";
import PassportTimeline from "@/components/passport/public/PassportTimeline";
import PassportAgent from "@/components/passport/public/PassportAgent";
import PassportSettingsOverlay from "@/components/passport/public/PassportSettingsOverlay";
import PassportEventButton from "@/components/passport/public/PassportEventButton";

export default function PassportPreview() {
  const { code } = useParams(); const passport = findLandingPassport(decodeURIComponent(code)); const [progress, setProgress] = useState(0);
  const related = useMemo(() => passport ? [passport, ...ALL_LANDING_PASSPORTS.filter((item) => item.code !== passport.code)].slice(0, 6) : [], [passport]);
  const updateProgress = useCallback((value) => setProgress(value), []);
  useEffect(() => setProgress(0), [passport?.code]);
  if (!passport) return <main className="flex min-h-[70vh] items-center justify-center px-5 text-center"><div><h1 className="text-4xl font-black">Passeport introuvable</h1><Link to="/" className="mt-6 inline-block rounded-full bg-foreground px-6 py-3 text-background">Retour à l’accueil</Link></div></main>;
  return <div className="bg-background text-foreground"><PassportVisualRail passport={passport} related={related} /><PassportCenterCard passport={passport} /><PassportProcess key={passport.code} progress={progress} /><PassportAgent key={passport.code} passport={passport} onProgress={updateProgress} /><PassportTimeline passports={related} /><div className="py-20 text-center"><Link to={passportSignupLink(passport.id)} className="inline-flex rounded-full bg-foreground px-8 py-4 text-sm font-bold text-background">Créer mon vrai passeport</Link><p className="mt-4 text-xs text-muted-foreground">L’inscription intervient seulement pour l’enregistrer.</p></div><PassportSettingsOverlay key={passport.code} passport={passport} /><PassportEventButton passport={passport} /></div>;
}