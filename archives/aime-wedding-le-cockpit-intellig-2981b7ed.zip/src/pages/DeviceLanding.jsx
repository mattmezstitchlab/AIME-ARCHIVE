import { useSeo } from "@/lib/seo/useSeo";
import CausalKeyboardPro from "@/components/devicelanding/CausalKeyboardPro";
import EditionsHero, { HERO_IMG } from "@/components/devicelanding/EditionsHero";
import EditionsChapters from "@/components/devicelanding/EditionsChapters";

// ─────────────────────────────────────────────────────────────────────────
// LA PAGE DU CLAVIER CAUSAL — direction artistique « Éditions » : œuvre
// picturale plein écran + carte-index à chapitres, puis le clavier en
// chapitre I et les chapitres éditoriaux (Bureau, Rôles, Accessibilité).
// ─────────────────────────────────────────────────────────────────────────
export default function DeviceLanding() {
  useSeo({
    title: "AIME® — L'Édition Renaissance du Mariage",
    description:
      "Un seul clavier pour les dix rôles du mariage. F1–F12 règlent l'accessibilité EAA, les chiffres changent de rôle, les lettres déclenchent des gestes — et l'onde causale traverse le clavier avant de s'écrire dans la mémoire.",
  });

  return (
    <div className="relative min-h-screen overflow-hidden bg-[#0B0B0D] pb-28 text-white">
      {/* HERO ÉDITIONS — plein écran, carte-index à chapitres */}
      <EditionsHero />

      {/* CHAPITRE I — LE CLAVIER : touches nues posées sur le visuel */}
      <section id="le-clavier" className="relative scroll-mt-24 overflow-hidden">
        <img
          src={HERO_IMG}
          alt=""
          aria-hidden="true"
          className="absolute inset-0 h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-black/50" aria-hidden="true" />
        <div className="relative z-10 mx-auto max-w-5xl px-6 pb-16 pt-20">
          <header className="mb-10 border-t border-white/25 pt-8">
            <p className="font-mono text-[10px] font-semibold uppercase tracking-[0.3em] text-[#C9B88F]">
              chapitre <span className="font-serif text-[13px] normal-case italic">I</span>
            </p>
            <h2 className="mt-3 text-3xl font-semibold tracking-[-0.03em] sm:text-4xl">Le Clavier</h2>
            <p className="mt-3 max-w-xl text-[15px] leading-7 text-white/70">
              Pressez un chiffre pour incarner un rôle, une lettre pour poser un
              geste — l'onde traverse le clavier et s'écrit dans la mémoire.
              Essayez, même au clavier physique.
            </p>
          </header>
          <CausalKeyboardPro naked />
        </div>
      </section>

      {/* CHAPITRES II · III · IV */}
      <EditionsChapters />
    </div>
  );
}