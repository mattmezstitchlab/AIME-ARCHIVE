export const artistryImagePrompts = {
  homepageHero: "Photo réaliste premium : couple de mariés flottant au-dessus des nuages, main dans la main, robe fluide en mouvement, costume clair, plumes autour, grande plume floue au premier plan, lumière dorée naturelle, ambiance surréaliste mais crédible, cadrage moderne éditorial, émotion réelle, inclusivité subtile, rendu haut de gamme sans cliché.",
  avant: "Photo réaliste éditoriale : future mariée en préparation, bouquet posé, moodboard, tissus, détails de robe, lumière naturelle calme, gestes vrais, présence subtile d’une plume blanche, cadrage moderne, texture vivante, premium.",
  jourJ: "Photo réaliste premium : grande table de mariage vivante, verres, fleurs, lumière chaude, mouvement d’invités flous en arrière-plan, sensation de décision et d’action, cadrage éditorial, détails réels, plume discrète dans la composition.",
  apres: "Photo réaliste éditoriale : album ouvert, tirages photo, lettre manuscrite, plume, lumière douce de fin de journée, émotion intime, mains qui rangent les souvenirs, cadrage moderne et premium.",
  jeSuis: "Série de portraits réalistes sensibles selon les rôles du mariage : couple, témoin, invité, artiste, prestataire, lieu, photographe, traiteur, fleuriste, DJ, musicien, hébergement, transport ; lumière naturelle, émotion vraie, fond vivant, aucun cliché publicitaire.",
  momentsDeVie: [
    "Enfant avec chocolat autour de la bouche, langue sortie, rire spontané, mariage en arrière-plan flou, photo réaliste premium.",
    "Grand-mère qui fait croquer un petit four au grand-père, tendresse et humour, réception élégante, lumière chaude.",
    "Deux femmes mariées qui s’embrassent avec naturel, robe et costume élégants, émotion réelle, cadrage moderne.",
    "Deux hommes mariés qui rient ensemble, invités flous derrière, lumière dorée, photo réaliste éditoriale.",
    "Trois personnes en tenue de mariage, composition décalée mais élégante, énergie joyeuse, cadrage mode documentaire.",
    "Invités qui dansent, mouvement, flou artistique maîtrisé, lumière chaude, détails vivants.",
    "Enfant qui dort pendant la soirée sur deux chaises, veste posée, fête floue derrière, émotion tendre.",
    "Témoin ému pendant un discours, papier froissé, rire et larmes, invités attentifs.",
    "Mariés allongés sur une grande plume qui tombe du ciel, surréaliste mais photo réaliste, lumière douce.",
    "Couple sous une lune claire, référence subtile à Au clair de la lune, ambiance poétique premium.",
    "Robe qui flotte comme une plume, mouvement aérien, lumière naturelle, cadrage éditorial.",
    "Invités lançant le marié en l’air, joie réelle, ciel clair, photo documentaire haut de gamme.",
    "Bouquet suspendu en plein mouvement, pétales, mains floues, lumière chaude, détail vivant."
  ]
};

export default artistryImagePrompts;