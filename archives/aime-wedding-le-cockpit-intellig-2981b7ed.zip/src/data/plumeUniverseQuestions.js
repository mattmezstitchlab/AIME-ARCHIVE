// Questions contextuelles que La Plume peut poser selon l'univers actif.
// Utilisées pour enrichir les suggestions et relances dans le drawer.

export const PLUME_UNIVERSE_QUESTIONS = {
  "boheme-solaire": [
    "Voulez-vous un cocktail pieds dans l'herbe ?",
    "Souhaitez-vous des guirlandes lumineuses pour le soir ?",
    "Faut-il prévoir de l'ombre pour la cérémonie ?",
    "Avez-vous pensé à un coin hamac pour les invités ?",
    "Musique acoustique ou playlist douce ?",
  ],
  "chic-essentiel": [
    "Souhaitez-vous un plan de table formel ?",
    "Service à l'assiette ou buffet raffiné ?",
    "Préférez-vous une ouverture de bal classique ?",
    "Avez-vous prévu un coordinateur jour J ?",
    "Dress code strict ou flexible ?",
  ],
  "rock-n-roll": [
    "Voulez-vous un groupe live pour la cérémonie aussi ?",
    "Food truck ou dîner assis ?",
    "Feux d'artifice : possible sur le lieu ?",
    "Avez-vous vérifié les limites sonores ?",
    "Bouchons d'oreilles pour les enfants ?",
  ],
  "champetre": [
    "Y a-t-il un espace couvert en cas de pluie ?",
    "Voulez-vous un jeu de kermesse pour les enfants ?",
    "Vin d'honneur local ou champagne classique ?",
    "Avez-vous prévu l'éclairage extérieur ?",
    "Voulez-vous un feu de camp en fin de soirée ?",
  ],
  "garden-party": [
    "Voulez-vous un afternoon tea ou un cocktail classique ?",
    "Croquet, badminton ou pétanque ?",
    "Fin de soirée douce ou fête prolongée ?",
    "Avez-vous prévu un barnum en cas de pluie ?",
    "Chapeaux obligatoires ou optionnels ?",
  ],
  "festival-amour": [
    "Combien de scènes musicales voulez-vous ?",
    "Food trucks : quel type de cuisine ?",
    "Y a-t-il un camping pour les invités ?",
    "Bracelets ou invitations papier ?",
    "Voulez-vous un coin tattoo éphémère ?",
  ],
  "sans-prise-de-tete": [
    "Pizza, tacos ou barbecue ?",
    "DJ ou playlist Spotify ?",
    "Discours : oui ou non ?",
    "Voulez-vous un photobooth simple ?",
    "Fin de soirée : heure approximative ?",
  ],
  "mariage-musical": [
    "Quel genre musical pour la cérémonie ?",
    "Combien de formations live ?",
    "Première danse : quelle chanson ?",
    "Voulez-vous un moment acoustique pendant le repas ?",
    "DJ pour l'after ou fin avec le live ?",
  ],
  "mariage-deguise": [
    "Quel thème avez-vous choisi ?",
    "Photobooth avec accessoires ?",
    "Voulez-vous une entrée des mariés mise en scène ?",
    "Concours de costumes : oui ou non ?",
    "Avez-vous des accessoires pour les non-déguisés ?",
  ],
  "fermier-terroir": [
    "Voulez-vous inclure une dégustation de vins ?",
    "Fromage local ou plateau classique ?",
    "Feu de camp ou veillée contée ?",
    "Avez-vous un producteur local pour le repas ?",
    "Voulez-vous une visite du domaine ?",
  ],
  "lune-blanche": [
    "Cérémonie au coucher du soleil ou à la nuit tombée ?",
    "Voulez-vous un lâcher de lanternes ?",
    "Musique acoustique ou électronique douce ?",
    "Avez-vous pensé à des plaids pour les invités ?",
    "Voulez-vous des bougies partout ou un éclairage mixte ?",
  ],
  "city-wedding": [
    "Rooftop ou loft ?",
    "Cocktail dînatoire ou dîner assis ?",
    "Voulez-vous un after dans un bar ?",
    "DJ set au coucher du soleil ?",
    "Avez-vous vérifié les contraintes de bruit en ville ?",
  ],
};

export function getUniverseQuestions(slug) {
  return PLUME_UNIVERSE_QUESTIONS[slug] || [];
}