// Règles de classification sémantique pour La Plume.
// Chaque règle contient des mots-clés déclencheurs, la cible de rangement,
// et un template de confirmation adapté par univers.

export const CLASSIFICATION_RULES = [
  {
    id: "timeline_provider",
    triggers: ["arrive", "arriver", "commence", "commencer", "installation", "mise en place"],
    providerTriggers: ["traiteur", "photographe", "dj", "musicien", "fleuriste", "officiant", "vidéaste", "coiffeur", "maquilleur"],
    target: "timeline",
    section: "Jour J → Timeline → Prestataires attendus",
    confirmTemplates: {
      default: "Je propose de classer dans : Jour J → Timeline. {moment} à {time}. Confirmer ?",
      "garden-party": "Je l'ajoute dans votre déroulé Garden Party : Jour J → {moment} → {time}. Confirmer ?",
      "rock-n-roll": "Je l'ajoute dans votre moment d'ouverture festive : Jour J → {moment} → {time}. Confirmer ?",
      "sans-prise-de-tete": "Je note simplement : Jour J → {moment} → {time}. Confirmer ?",
      "boheme-solaire": "Je range ça dans votre journée solaire : {moment} à {time}. Confirmer ?",
      "chic-essentiel": "Je l'inscris précisément : {moment}, {time}. Confirmer ?",
      "lune-blanche": "Je l'ajoute sous les étoiles : {moment} à {time}. Confirmer ?",
      "city-wedding": "Je le note dans votre planning urbain : {moment} à {time}. Confirmer ?",
      "festival-amour": "Je l'ajoute à votre line-up : {moment} à {time}. Confirmer ?",
      "mariage-musical": "Je l'inscris dans la partition : {moment} à {time}. Confirmer ?",
    },
  },
  {
    id: "guest_rsvp",
    triggers: ["invité", "tante", "oncle", "cousin", "vient", "viennent", "rsvp", "présent", "absent"],
    target: "guests",
    section: "Avant → Invités / RSVP",
    confirmTemplates: {
      default: "{name} ajouté aux invités. Confirmer ?",
    },
  },
  {
    id: "music_playlist",
    triggers: ["chanson", "morceau", "titre", "playlist", "musique", "jouer", "passer"],
    target: "must_play",
    section: "Avant → Playlist",
    confirmTemplates: {
      default: "« {track} » ajouté à la playlist pour {moment}. Confirmer ?",
      "mariage-musical": "Je l'inscris dans la partition musicale : « {track} » pour {moment}. Confirmer ?",
      "rock-n-roll": "« {track} » envoyé dans le set {moment}. Confirmer ?",
      "festival-amour": "« {track} » ajouté au line-up {moment}. Confirmer ?",
    },
  },
  {
    id: "music_blacklist",
    triggers: ["pas", "jamais", "interdit", "surtout pas", "blacklist"],
    target: "do_not_play",
    section: "Avant → Playlist → Blacklist",
    confirmTemplates: {
      default: "« {track} » blacklisté. Confirmer ?",
    },
  },
  {
    id: "contact",
    triggers: ["contact", "téléphone", "numéro", "appeler", "joindre", "témoin"],
    target: "useful_contacts",
    section: "Jour J → Contacts utiles",
    confirmTemplates: {
      default: "{name} ajouté aux contacts. Confirmer ?",
    },
  },
  {
    id: "emergency",
    triggers: ["pluie", "parapluie", "plan b", "urgence", "retard", "panne"],
    target: "checklist_items",
    section: "Jour J → Urgences / Plans B",
    confirmTemplates: {
      default: "Ajouté aux plans B : « {label} ». Confirmer ?",
      "boheme-solaire": "Point de vigilance noté pour votre journée en plein air : « {label} ». Confirmer ?",
      "lune-blanche": "Précaution nocturne notée : « {label} ». Confirmer ?",
    },
  },
  {
    id: "lodging",
    triggers: ["hôtel", "dort", "dormir", "hébergement", "gîte", "chambre"],
    target: "lodging",
    section: "Jour J → Infos invités → Hébergement",
    confirmTemplates: {
      default: "Info hébergement enregistrée. Confirmer ?",
    },
  },
  {
    id: "carpooling",
    triggers: ["covoiturage", "trajet", "voiture", "conduire"],
    target: "carpooling",
    section: "Jour J → Infos invités → Covoiturage",
    confirmTemplates: {
      default: "Covoiturage noté. Confirmer ?",
    },
  },
];

// Trouve la règle de classification la plus pertinente pour un texte donné
export function findClassificationRule(text) {
  const t = text.toLowerCase();
  for (const rule of CLASSIFICATION_RULES) {
    const hasTrigger = rule.triggers.some((w) => t.includes(w));
    if (hasTrigger) {
      if (rule.providerTriggers) {
        const hasProvider = rule.providerTriggers.some((w) => t.includes(w));
        if (hasProvider) return rule;
      } else {
        return rule;
      }
    }
  }
  return null;
}

// Génère le template de confirmation adapté à l'univers
export function getConfirmTemplate(rule, universeSlug, vars = {}) {
  if (!rule) return null;
  const template = rule.confirmTemplates[universeSlug] || rule.confirmTemplates.default;
  return template.replace(/\{(\w+)\}/g, (_, key) => vars[key] || key);
}