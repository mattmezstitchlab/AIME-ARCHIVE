// Prompts de génération d'images pour chaque univers.
// Structure prête pour 5 variations (cover + 4 phases).
// Seul le cover est utilisé pour l'instant.

export const UNIVERSE_IMAGE_PROMPTS = {
  "boheme-solaire": {
    cover: "Dreamy bohemian outdoor wedding at golden hour, wildflowers, linen drapes, warm sunlight filtering through olive trees, barefoot couple, editorial style",
    matin: "Morning wedding preparations in a sunlit tent with linen curtains, wildflowers on a wooden table, bohemian editorial style",
    journee: "Bohemian outdoor wedding ceremony under a flower arch, golden sunlight, barefoot guests, editorial style",
    soiree: "Bohemian evening dinner under string lights and olive trees, long wooden table, candles, warm glow, editorial style",
    nuit: "Late night bohemian fire pit gathering, starry sky, fairy lights, intimate atmosphere, editorial style",
  },
  "chic-essentiel": {
    cover: "Minimalist elegant wedding venue, white marble, crystal chandelier, long white table with single white rose, editorial luxury style",
    matin: "Elegant bridal suite preparations, marble bathroom, white orchids, morning light, editorial luxury style",
    journee: "Classic white wedding ceremony in a grand hall, crystal chandeliers, white roses, editorial luxury style",
    soiree: "Sophisticated dinner party, fine dining, candelabras, white and gold, editorial luxury style",
    nuit: "Late night elegant lounge bar at wedding, dim amber lighting, champagne tower, editorial luxury style",
  },
  "rock-n-roll": {
    cover: "Rock and roll wedding, electric guitar on stage, leather jacket bride, industrial venue with Edison bulbs, moody editorial style",
    matin: "Rock bride getting ready, leather jacket, dark makeup, industrial loft, editorial style",
    journee: "Rock wedding ceremony with acoustic guitar, industrial venue, Edison bulbs, editorial style",
    soiree: "Rock concert at wedding, band on stage, crowd dancing, dramatic lighting, editorial style",
    nuit: "Late night after party, neon signs, cocktails, rock atmosphere, editorial style",
  },
  "champetre": {
    cover: "Rustic countryside wedding in a beautiful barn, hay bales, string lights, wildflower centerpieces, warm golden hour, editorial style",
    matin: "Morning preparations in a countryside farmhouse, rustic wooden furniture, wildflowers, editorial style",
    journee: "Country wedding ceremony in a sunlit field, hay bales seating, wildflowers, editorial style",
    soiree: "Rustic barn dinner with long tables, candles, string lights, warm atmosphere, editorial style",
    nuit: "Country bonfire gathering under stars, blankets, lanterns, intimate night, editorial style",
  },
  "garden-party": {
    cover: "Elegant garden party wedding, manicured lawn, pastel floral arrangements, white marquee, afternoon tea setting, bright natural light, editorial style",
    matin: "Morning garden preparations, pastel flowers being arranged, dewy lawn, bright light, editorial style",
    journee: "Garden ceremony under a rose arch, pastel colors, guests in sun hats, editorial style",
    soiree: "Evening garden dinner under a white tent, fairy lights, pastel table settings, editorial style",
    nuit: "Night garden with lanterns and fairy lights, quiet romantic atmosphere, editorial style",
  },
  "festival-amour": {
    cover: "Festival-style outdoor wedding, colorful bunting, multiple food trucks, small stage with band, fairy lights, editorial style",
    matin: "Festival morning setup, colorful tents and bunting, early morning light, editorial style",
    journee: "Festival wedding with live band on stage, dancing crowd, colorful decorations, editorial style",
    soiree: "Festival evening with food trucks lit up, fairy lights, live music, editorial style",
    nuit: "Late night festival DJ set, colored lights, dancing crowd, starry sky, editorial style",
  },
  "sans-prise-de-tete": {
    cover: "Casual relaxed wedding, pizza party, simple white decor, laughing couple, outdoor terrace, warm natural light, editorial style",
    matin: "Relaxed morning getting ready, casual atmosphere, coffee and smiles, editorial style",
    journee: "Simple outdoor ceremony, minimal decor, genuine emotions, editorial style",
    soiree: "Casual evening pizza party, outdoor terrace, fairy lights, editorial style",
    nuit: "Chill late night with friends, simple drinks, warm atmosphere, editorial style",
  },
  "mariage-musical": {
    cover: "Musical wedding, jazz band performing at elegant venue, saxophone player, warm amber lighting, guests dancing, editorial style",
    matin: "Musicians preparing instruments in an elegant venue, morning light, editorial style",
    journee: "String quartet performing at wedding ceremony, elegant setting, editorial style",
    soiree: "Jazz band performing at elegant dinner, amber lighting, guests dining, editorial style",
    nuit: "Late night piano bar at wedding, intimate atmosphere, dim lighting, editorial style",
  },
  "mariage-deguise": {
    cover: "Themed costume wedding party, Great Gatsby 1920s style, guests in period costumes, dramatic lighting, confetti, editorial style",
    matin: "Getting ready in costumes, makeup and accessories, dramatic mirror reflections, editorial style",
    journee: "Themed ceremony with costumed guests, dramatic staging, editorial style",
    soiree: "Costume party dinner, dramatic lighting, themed decorations, confetti, editorial style",
    nuit: "Late night costume dance party, dramatic lights, masks and glitter, editorial style",
  },
  "fermier-terroir": {
    cover: "Farm-to-table wedding, long wooden table in a vineyard, local cheese and wine, rustic decor, warm sunset light, editorial style",
    matin: "Farm morning preparations, fresh produce on wooden table, rustic kitchen, editorial style",
    journee: "Vineyard ceremony, rustic arch with herbs, warm sunlight, editorial style",
    soiree: "Farm-to-table dinner, long table with local food, wine barrels, candles, editorial style",
    nuit: "Farm bonfire with wine, cheese board, starry country sky, editorial style",
  },
  "lune-blanche": {
    cover: "Nighttime moonlit wedding, hundreds of candles, starry sky, intimate dinner under fairy lights, mysterious romantic atmosphere, editorial style",
    matin: "Late afternoon preparations, golden hour light, dramatic makeup, editorial style",
    journee: "Sunset ceremony preparation, golden to blue sky transition, candles being lit, editorial style",
    soiree: "Moonlit dinner with hundreds of candles, intimate atmosphere, editorial style",
    nuit: "Midnight ceremony under stars, lanterns floating, mysterious romantic mood, editorial style",
  },
  "city-wedding": {
    cover: "Modern city rooftop wedding, skyline view at sunset, minimalist white decor, craft cocktails, contemporary urban elegance, editorial style",
    matin: "Urban loft getting ready, city skyline through windows, modern minimal, editorial style",
    journee: "Rooftop ceremony with city skyline, modern minimalist arch, editorial style",
    soiree: "Rooftop dinner at sunset, skyline view, craft cocktails, modern decor, editorial style",
    nuit: "Late night rooftop lounge, city lights below, modern cocktails, editorial style",
  },
};