import { useState, useRef, useEffect } from "react";
import { Send, Loader2, Bot, MapPin, Star } from "lucide-react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";

// AGENTS — le super-agent de bord. Depuis ce seul écran, il utilise tout
// l'AI+ME : il répond, GÉNÈRE des images, et AFFICHE des cartes prestataires
// — tout au même endroit, dans la conversation.
export default function DeviceAgentChat({ url, scan, vision }) {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const endRef = useRef(null);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  const send = async (e) => {
    e.preventDefault();
    const q = input.trim();
    if (!q || busy) return;
    setInput("");
    setMessages((m) => [...m, { role: "user", text: q }]);
    setBusy(true);
    try {
      const context = [
        url ? `Site projeté à l'écran : ${url}` : "Aucun site projeté.",
        scan?.data ? `Scan WCAG AA : score ${scan.data.score}/100, ${scan.data.counts.faults} failles (${scan.data.counts.blocking} bloquantes).` : "",
        vision?.data ? `Audit visuel : ${Math.round(vision.data.visual_score)}/100.` : "",
      ].filter(Boolean).join("\n");

      const data = await base44.integrations.Core.InvokeLLM({
        prompt:
          `Tu es le super-agent de bord de l'appareil AIME® AI+ME (OS causal d'accessibilité, mariage & prestataires). ` +
          `Contexte écran :\n${context}\n\n` +
          `Demande de l'utilisateur : "${q}"\n\n` +
          `Réponds en français, court (2-4 phrases), concret et bienveillant. En plus de ta réponse, choisis UNE action :\n` +
          `- "image" si l'utilisateur veut voir/créer un visuel (déco, moodboard, robe, lieu, logo…) → remplis image_prompt (prompt détaillé en anglais).\n` +
          `- "prestataires" si l'utilisateur cherche un prestataire (photographe, DJ, traiteur, fleuriste, musicien…) → remplis search_terms (2-4 mots-clés français : métier, ville, style).\n` +
          `- "none" sinon.`,
        response_json_schema: {
          type: "object",
          properties: {
            reply: { type: "string" },
            action: { type: "string", enum: ["none", "image", "prestataires"] },
            image_prompt: { type: "string" },
            search_terms: { type: "string" },
          },
          required: ["reply", "action"],
        },
      });

      setMessages((m) => [...m, { role: "agent", text: data.reply }]);

      if (data.action === "image" && data.image_prompt) {
        setMessages((m) => [...m, { role: "agent", pending: "Génération de l'image…" }]);
        const img = await base44.integrations.Core.GenerateImage({ prompt: data.image_prompt });
        setMessages((m) => [...m.filter((x) => !x.pending), { role: "agent", image: img.url }]);
      }

      if (data.action === "prestataires") {
        const all = await base44.entities.Artist.list("-rating", 100);
        const terms = (data.search_terms || q).toLowerCase().split(/[\s,]+/).filter((t) => t.length > 2);
        const scored = all
          .map((a) => {
            const hay = `${a.name} ${a.specialty} ${a.category} ${a.location} ${a.wedding_role} ${(a.styles || []).join(" ")}`.toLowerCase();
            return { a, hits: terms.filter((t) => hay.includes(t)).length };
          })
          .filter((x) => x.hits > 0)
          .sort((x, y) => y.hits - x.hits)
          .slice(0, 4)
          .map((x) => x.a);
        const picks = scored.length ? scored : all.slice(0, 3);
        setMessages((m) => [...m, { role: "agent", artists: picks }]);
      }
    } catch {
      setMessages((m) => [...m.filter((x) => !x.pending), { role: "agent", text: "Je n'ai pas réussi à répondre — réessaie." }]);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex h-[300px] flex-col p-3">
      <div className="flex-1 space-y-2 overflow-y-auto scrollbar-hide pr-1">
        {messages.length === 0 && (
          <p className="flex items-start gap-2 text-[12px] leading-relaxed text-white/45">
            <Bot className="mt-0.5 h-4 w-4 shrink-0 text-accent" />
            Je suis le super-agent de bord. Demande-moi tout : « génère-moi une déco bohème »,
            « trouve-moi un photographe à Lyon », ou une question sur l'écran — je réponds,
            je génère les images et j'affiche les cartes ici même.
          </p>
        )}
        {messages.map((m, i) => {
          if (m.pending) {
            return (
              <p key={i} className="flex items-center gap-2 text-[11px] text-white/40">
                <Loader2 className="h-3.5 w-3.5 animate-spin text-accent" /> {m.pending}
              </p>
            );
          }
          if (m.image) {
            return (
              <img key={i} src={m.image} alt="Visuel généré par l'agent"
                className="max-w-[75%] rounded-2xl border border-white/10" />
            );
          }
          if (m.artists) {
            return (
              <div key={i} className="grid max-w-[95%] grid-cols-2 gap-2">
                {m.artists.map((a) => (
                  <Link key={a.id} to={`/artiste/${a.id}`}
                    className="flex gap-2.5 rounded-xl border border-white/10 bg-white/[0.04] p-2 transition hover:border-accent/50">
                    {a.image_url && <img src={a.image_url} alt="" className="h-12 w-12 shrink-0 rounded-lg object-cover" />}
                    <span className="min-w-0">
                      <span className="block truncate text-[11.5px] font-semibold text-white">{a.name}</span>
                      <span className="block truncate text-[10px] text-white/50">{a.specialty || a.category}</span>
                      <span className="flex items-center gap-1.5 text-[9.5px] text-white/40">
                        {a.location && <span className="inline-flex items-center gap-0.5"><MapPin className="h-2.5 w-2.5" />{a.location}</span>}
                        {a.rating != null && <span className="inline-flex items-center gap-0.5 text-accent"><Star className="h-2.5 w-2.5 fill-accent" />{a.rating}</span>}
                      </span>
                    </span>
                  </Link>
                ))}
              </div>
            );
          }
          return (
            <div key={i} className={`max-w-[85%] rounded-2xl px-3.5 py-2 text-[12.5px] leading-relaxed ${
              m.role === "user" ? "ml-auto bg-white text-black" : "bg-white/[0.06] text-white/80"
            }`}>
              {m.text}
            </div>
          );
        })}
        {busy && <p className="flex items-center gap-2 text-[11px] text-white/40"><Loader2 className="h-3.5 w-3.5 animate-spin text-accent" /> L'agent réfléchit…</p>}
        <div ref={endRef} />
      </div>
      <form onSubmit={send} className="mt-2 flex gap-2">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Demande tout : image, prestataire, aide…"
          aria-label="Message à l'agent"
          className="flex-1 rounded-xl border border-white/12 bg-white/[0.04] px-3 py-2 text-[12.5px] text-white placeholder:text-white/30 transition focus:outline-none focus-visible:!shadow-none focus-visible:border-accent/60"
        />
        <button type="submit" disabled={busy} aria-label="Envoyer" className="rounded-xl bg-accent px-3.5 text-black transition hover:brightness-110 disabled:opacity-40">
          <Send className="h-4 w-4" />
        </button>
      </form>
    </div>
  );
}