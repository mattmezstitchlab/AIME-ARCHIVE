import { useState, useEffect } from "react";
import AimeDeviceOverlay from "@/components/aimedevice/AimeDeviceOverlay";

// Bouton flottant bas-droite : la plaque AIME® AI+ME pliée. Clic = déplier l'appareil.
// Écoute aussi l'événement global "aime:open-device" (bijoux cliquables de la landing).
export default function AimeDeviceButton() {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const h = () => setOpen(true);
    window.addEventListener("aime:open-device", h);
    return () => window.removeEventListener("aime:open-device", h);
  }, []);
  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        aria-label="Ouvrir le clavier universel AIME AI+ME"
        className="fixed bottom-20 right-4 z-[90] rounded-2xl border border-white/15 bg-gradient-to-b from-[#1c1c1c] to-[#0e0e0e] px-4 py-3 shadow-2xl transition hover:scale-105 hover:border-accent/50 md:bottom-6 md:right-6"
      >
        <span className="block font-heading text-[13px] font-bold tracking-[0.08em] text-white/85">AIME®</span>
        <span className="block font-mono text-[8px] uppercase tracking-[0.34em] text-accent/80">AI+ME</span>
      </button>
      {open && <AimeDeviceOverlay onClose={() => setOpen(false)} />}
    </>
  );
}