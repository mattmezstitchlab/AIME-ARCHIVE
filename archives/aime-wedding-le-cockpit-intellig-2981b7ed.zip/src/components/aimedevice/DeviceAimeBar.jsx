import { Plus } from "lucide-react";

// LA BARRE AI + ME — signature de l'appareil : AI à gauche (le super-agent),
// + au centre (la collection de devices), ME à droite (votre identité).
export default function DeviceAimeBar({ panel, onAi, onPlus, onMe, accent = "#C9B88F" }) {
  const side = (active) =>
    `rounded-full px-5 py-2 font-mono text-[11px] font-bold uppercase tracking-[0.3em] transition ${
      active ? "bg-white text-black" : "text-white/55 hover:text-white"
    }`;
  return (
    <div className="flex items-center justify-center gap-3 border-t border-white/[0.07] bg-black/40 px-4 py-2.5 backdrop-blur">
      <button type="button" onClick={onAi} aria-label="AI — le super-agent" className={side(panel === "ai")}>
        AI
      </button>
      <button
        type="button"
        onClick={onPlus}
        aria-label="Mes devices — en ajouter, en changer"
        className="grid h-11 w-11 place-items-center rounded-full border-2 text-black shadow-lg transition hover:scale-110"
        style={{ backgroundColor: accent, borderColor: "rgba(255,255,255,0.25)" }}
      >
        <Plus className="h-5 w-5" strokeWidth={2.4} />
      </button>
      <button type="button" onClick={onMe} aria-label="ME — mon identité AI+ME" className={side(panel === "me")}>
        ME
      </button>
    </div>
  );
}