import { useEffect, useState } from "react";
import { FolderOpen, Package, ImageIcon, Link2 } from "lucide-react";
import { base44 } from "@/api/base44Client";

// LE RANGEMENT — ce que POINT ZERO a reconnu et rangé : les dossiers créés
// par l'IA (timbres) et les archives/templates, visibles ici et sur le Bureau.
export default function DeviceRangement({ refreshKey = 0 }) {
  const [stamps, setStamps] = useState([]);
  const [archives, setArchives] = useState([]);

  useEffect(() => {
    base44.entities.RippleStamp.list("-created_date", 100).then(setStamps).catch(() => {});
    base44.entities.SavedArchive.list("-created_date", 50).then(setArchives).catch(() => {});
  }, [refreshKey]);

  const folders = stamps.reduce((acc, s) => {
    const f = s.folder || "Divers";
    (acc[f] = acc[f] || []).push(s);
    return acc;
  }, {});
  const archivesByPath = archives.reduce((acc, a) => {
    const p = a.path || "Templates";
    (acc[p] = acc[p] || []).push(a);
    return acc;
  }, {});

  if (!stamps.length && !archives.length) {
    return <p className="mt-3 text-center text-[11px] text-white/35">Rien de rangé encore — déposez des fichiers ci-dessus.</p>;
  }

  return (
    <div className="mt-4 space-y-3">
      <p className="font-mono text-[9px] uppercase tracking-[0.26em] text-white/35">
        le rangement · {Object.keys(folders).length + Object.keys(archivesByPath).length} dossiers
      </p>

      {/* Archives / templates (zips) */}
      {Object.entries(archivesByPath).map(([path, items]) => (
        <div key={`a-${path}`} className="rounded-xl border border-white/10 bg-white/[0.03] p-3">
          <p className="flex items-center gap-1.5 text-[11px] font-semibold text-accent">
            <Package className="h-3.5 w-3.5" /> {path} <span className="text-white/30">· {items.length}</span>
          </p>
          <div className="mt-1.5 space-y-1">
            {items.map((a) => (
              <a key={a.id} href={a.file_url} target="_blank" rel="noreferrer"
                className="flex items-center justify-between gap-2 rounded-lg px-2 py-1 text-[11px] text-white/65 transition hover:bg-white/[0.06] hover:text-white">
                <span className="truncate">{a.label}</span>
                <span className="shrink-0 font-mono text-[8.5px] text-white/30">{a.file_count || 0} fichiers</span>
              </a>
            ))}
          </div>
        </div>
      ))}

      {/* Dossiers de timbres (photos, captures, docs) */}
      {Object.entries(folders).map(([folder, items]) => (
        <div key={`f-${folder}`} className="rounded-xl border border-white/10 bg-white/[0.03] p-3">
          <p className="flex items-center gap-1.5 text-[11px] font-semibold text-white/80">
            <FolderOpen className="h-3.5 w-3.5 text-accent" /> {folder} <span className="text-white/30">· {items.length}</span>
          </p>
          <div className="mt-1.5 grid grid-cols-5 gap-1.5">
            {items.slice(0, 10).map((s) =>
              s.image_url ? (
                <a key={s.id} href={s.image_url} target="_blank" rel="noreferrer" className="block overflow-hidden rounded-md border border-white/10">
                  <img src={s.image_url} alt={s.label || "Fichier rangé"} className="aspect-square w-full object-cover" />
                </a>
              ) : (
                <a key={s.id} href={s.content || "#"} target="_blank" rel="noreferrer"
                  className="flex aspect-square items-center justify-center rounded-md border border-white/10 bg-white/[0.04]" title={s.label}>
                  {s.stamp_type === "image" ? <ImageIcon className="h-4 w-4 text-white/40" /> : <Link2 className="h-4 w-4 text-white/40" />}
                </a>
              )
            )}
          </div>
        </div>
      ))}

      <p className="text-center font-mono text-[8.5px] uppercase tracking-[0.18em] text-white/25">
        tout est aussi visible sur votre bureau
      </p>
    </div>
  );
}