import { useState } from "react";
import { Loader2, Upload, FolderOpen, Package, CheckCircle2, AlertTriangle } from "lucide-react";
import JSZip from "jszip";
import { base44 } from "@/api/base44Client";

// ─────────────────────────────────────────────────────────────────────────
// POINT ZERO — l'importeur universel : on dépose N'IMPORTE QUEL fichier
// (zip/template Manus·Base44·Figma, photos, captures d'écran, docs…),
// l'IA reconnaît, nomme et RANGE tout en créant les dossiers qu'il faut.
// Zips → SavedArchive (templates retravaillables) · le reste → timbres RippleStamp.
// ─────────────────────────────────────────────────────────────────────────
export default function PointZeroImport() {
  const [items, setItems] = useState([]); // { name, status, folder, error }
  const [busy, setBusy] = useState(false);

  const setItem = (name, patch) =>
    setItems((list) => list.map((it) => (it.name === name ? { ...it, ...patch } : it)));

  const processFile = async (file) => {
    try {
      const isZip = /\.zip$/i.test(file.name);
      const isImage = /^image\//.test(file.type);

      if (isZip) {
        // Template : on liste le contenu réel du zip pour que l'IA sache quoi c'est.
        const zip = await JSZip.loadAsync(file);
        const names = Object.keys(zip.files).slice(0, 60);
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        const verdict = await base44.integrations.Core.InvokeLLM({
          prompt:
            `Archive importée dans AI+ME : "${file.name}". Contenu : ${names.join(", ")}. ` +
            `Devine sa provenance/nature (template Base44, export Manus, Figma, site, photos…) et propose ` +
            `un chemin de rangement court (ex. "Templates › Base44", "Visuels › Captures").`,
          response_json_schema: {
            type: "object",
            properties: { path: { type: "string" }, label: { type: "string" } },
            required: ["path", "label"],
          },
        });
        await base44.entities.SavedArchive.create({
          label: verdict.label || file.name,
          file_url,
          path: verdict.path || "Templates",
          file_count: names.length,
          size_kb: Math.round(file.size / 1024),
        });
        setItem(file.name, { status: "done", folder: verdict.path || "Templates" });
        return;
      }

      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      const verdict = await base44.integrations.Core.InvokeLLM({
        prompt:
          `Fichier importé dans AI+ME : "${file.name}" (type ${file.type || "inconnu"}). ` +
          (isImage ? `Regarde l'image jointe : photo, capture d'écran, logo, maquette… ` : "") +
          `Donne un label court et le dossier où le ranger (crée le nom de dossier qui convient : ` +
          `Visuels, Captures d'écran, Documents, Logos, Maquettes, Photos de famille…).`,
        ...(isImage ? { file_urls: [file_url] } : {}),
        response_json_schema: {
          type: "object",
          properties: { folder: { type: "string" }, label: { type: "string" } },
          required: ["folder", "label"],
        },
      });
      await base44.entities.RippleStamp.create({
        label: verdict.label || file.name,
        stamp_type: isImage ? "image" : "link",
        content: file_url,
        image_url: isImage ? file_url : "",
        folder: verdict.folder || "Divers",
      });
      setItem(file.name, { status: "done", folder: verdict.folder || "Divers" });
    } catch (err) {
      setItem(file.name, { status: "error", error: err?.message || "Import impossible" });
    }
  };

  const onFiles = async (fileList) => {
    const files = Array.from(fileList || []);
    if (!files.length) return;
    setBusy(true);
    setItems((prev) => [...files.map((f) => ({ name: f.name, status: "processing" })), ...prev]);
    for (const f of files) await processFile(f);
    setBusy(false);
  };

  // Regroupement par dossier créé/choisi par l'IA.
  const folders = items.filter((i) => i.status === "done").reduce((acc, i) => {
    (acc[i.folder] = acc[i.folder] || []).push(i);
    return acc;
  }, {});

  return (
    <div className="rounded-2xl border border-accent/25 bg-[#121212] p-4">
      <label className="flex cursor-pointer flex-col items-center gap-2 rounded-xl border border-dashed border-white/20 p-5 text-center transition hover:border-accent/50 hover:bg-white/[0.03]">
        {busy ? <Loader2 className="h-6 w-6 animate-spin text-accent" /> : <Upload className="h-6 w-6 text-accent" />}
        <span className="text-[12.5px] font-semibold text-white">
          {busy ? "L'IA reconnaît et range vos fichiers…" : "Déposer des fichiers — tout est reconnu"}
        </span>
        <span className="text-[10px] text-white/40">zip · templates Manus, Base44, Figma · photos · captures · docs</span>
        <input type="file" multiple className="hidden" onChange={(e) => onFiles(e.target.files)} />
      </label>

      {items.length > 0 && (
        <div className="mt-3 space-y-1.5">
          {items.map((it) => (
            <div key={it.name} className="flex items-center gap-2 rounded-lg bg-white/[0.04] px-3 py-2 text-[11.5px]">
              {it.status === "processing" && <Loader2 className="h-3.5 w-3.5 shrink-0 animate-spin text-accent" />}
              {it.status === "done" && <CheckCircle2 className="h-3.5 w-3.5 shrink-0 text-emerald-400" />}
              {it.status === "error" && <AlertTriangle className="h-3.5 w-3.5 shrink-0 text-amber-300" />}
              <span className="min-w-0 flex-1 truncate text-white/75">{it.name}</span>
              {it.folder && (
                <span className="inline-flex shrink-0 items-center gap-1 font-mono text-[8.5px] uppercase tracking-[0.12em] text-accent">
                  <FolderOpen className="h-3 w-3" /> {it.folder}
                </span>
              )}
              {it.error && <span className="shrink-0 text-[9.5px] text-amber-300">{it.error}</span>}
            </div>
          ))}
        </div>
      )}

      {Object.keys(folders).length > 0 && (
        <p className="mt-3 flex items-center gap-1.5 font-mono text-[9px] uppercase tracking-[0.2em] text-white/35">
          <Package className="h-3 w-3 text-accent" />
          {Object.keys(folders).length} dossier{Object.keys(folders).length > 1 ? "s" : ""} créé{Object.keys(folders).length > 1 ? "s" : ""} : {Object.keys(folders).join(" · ")}
        </p>
      )}
    </div>
  );
}