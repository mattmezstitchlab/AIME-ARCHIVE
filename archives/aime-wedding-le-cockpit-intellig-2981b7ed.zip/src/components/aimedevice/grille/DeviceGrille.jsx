import { useState } from "react";
import PointZeroImport from "@/components/aimedevice/grille/PointZeroImport";
import DeviceRangement from "@/components/aimedevice/grille/DeviceRangement";

// ─────────────────────────────────────────────────────────────────────────
// LE DOS DU DEVICE — épuré : un seul bouton, POINT ZERO, au centre.
// Un toucher et l'importeur universel s'ouvre, avec le rangement dessous.
// ─────────────────────────────────────────────────────────────────────────
export default function DeviceGrille() {
  const [zeroOpen, setZeroOpen] = useState(false);

  return (
    <div>
      <p className="mb-4 text-center font-mono text-[9px] uppercase tracking-[0.3em] text-white/35">
        point zero · l'importeur universel
      </p>

      {!zeroOpen ? (
        <div className="flex flex-col items-center py-8">
          <button
            type="button"
            onClick={() => setZeroOpen(true)}
            aria-label="Ouvrir Point Zéro — importer tous vos fichiers"
            className="relative flex h-36 w-36 items-center justify-center rounded-2xl border-2 border-white/20 bg-black transition hover:scale-105 hover:border-accent/60"
          >
            <span className="text-center font-mono text-[13px] font-bold uppercase leading-relaxed tracking-[0.2em] text-white">
              POINT<br />ZERO
            </span>
            <span className="absolute inset-0 animate-pulse rounded-2xl ring-2 ring-accent/50" />
          </button>
          <p className="mt-5 max-w-xs text-center text-[11.5px] leading-relaxed text-white/40">
            Touchez POINT ZERO : déposez n'importe quel fichier (zip, photo, capture, doc) —
            l'IA le reconnaît, crée les dossiers et range tout.
          </p>
        </div>
      ) : (
        <div>
          <PointZeroImport />
          <DeviceRangement />
          <button
            type="button"
            onClick={() => setZeroOpen(false)}
            className="mt-3 w-full text-center font-mono text-[9px] uppercase tracking-[0.24em] text-white/35 transition hover:text-white"
          >
            refermer point zero
          </button>
        </div>
      )}
    </div>
  );
}