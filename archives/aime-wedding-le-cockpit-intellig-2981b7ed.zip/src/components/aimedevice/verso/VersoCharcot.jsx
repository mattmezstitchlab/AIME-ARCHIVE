import { useState, useEffect, useRef } from "react";
import { Play, Pause, Delete } from "lucide-react";

const LETTERS = "ESARINTULOMDPCFBVHGJQZYXKW".split("").concat(["␣"]);

// Mode CHARCOT / SLA — communication par balayage : les lettres défilent
// (fréquence ESARIN), un seul grand bouton suffit pour sélectionner.
// + OUI / NON immédiats, énormes.
export default function VersoCharcot({ onAppend, onBackspace }) {
  const [scanning, setScanning] = useState(false);
  const [idx, setIdx] = useState(0);
  const timer = useRef();

  useEffect(() => {
    if (!scanning) return;
    timer.current = setInterval(() => setIdx((i) => (i + 1) % LETTERS.length), 900);
    return () => clearInterval(timer.current);
  }, [scanning]);

  const select = () => {
    const l = LETTERS[idx];
    onAppend(l === "␣" ? " " : l.toLowerCase());
  };

  return (
    <div>
      {/* OUI / NON — un seul geste */}
      <div className="grid grid-cols-2 gap-2">
        <button type="button" onClick={() => onAppend("Oui. ")}
          className="rounded-2xl bg-emerald-500/20 py-6 font-heading text-2xl font-bold text-emerald-300 transition hover:bg-emerald-500/30">
          OUI
        </button>
        <button type="button" onClick={() => onAppend("Non. ")}
          className="rounded-2xl bg-red-500/15 py-6 font-heading text-2xl font-bold text-red-300 transition hover:bg-red-500/25">
          NON
        </button>
      </div>

      {/* Balayage des lettres */}
      <div className="mt-3 rounded-2xl border border-white/10 bg-[#121212] p-3">
        <div className="flex flex-wrap justify-center gap-1" aria-hidden="true">
          {LETTERS.map((l, i) => (
            <span key={l} className={`grid h-8 w-8 place-items-center rounded-lg text-[13px] font-semibold transition ${
              scanning && i === idx ? "scale-110 bg-accent text-black" : "bg-white/[0.05] text-white/45"
            }`}>
              {l}
            </span>
          ))}
        </div>
        <div className="mt-3 flex gap-2">
          <button type="button" onClick={() => setScanning((s) => !s)}
            className="inline-flex flex-1 items-center justify-center gap-2 rounded-xl border border-white/15 py-3 text-[13px] font-semibold text-white/75 transition hover:text-white">
            {scanning ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
            {scanning ? "Pause balayage" : "Lancer le balayage"}
          </button>
          <button type="button" onClick={select} disabled={!scanning}
            className="flex-[2] rounded-xl bg-accent py-3 font-heading text-lg font-bold text-black transition hover:brightness-110 disabled:opacity-35">
            SÉLECTIONNER · {LETTERS[idx]}
          </button>
          <button type="button" onClick={onBackspace} aria-label="Effacer la dernière lettre"
            className="rounded-xl border border-white/15 px-4 text-white/60 transition hover:text-white">
            <Delete className="h-4 w-4" />
          </button>
        </div>
        <p className="mt-2 text-center font-mono text-[9px] uppercase tracking-[0.22em] text-white/30">
          lettres classées par fréquence (esarin) · un seul bouton suffit
        </p>
      </div>
    </div>
  );
}