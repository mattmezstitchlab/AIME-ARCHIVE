import { useState, useRef } from "react";
import { Mic, MicOff } from "lucide-react";

// Mode VOCAL — la vraie voix : reconnaissance vocale du navigateur (fr-FR),
// ce qui est dit s'écrit dans la phrase, qui peut être relue à voix haute.
export default function VersoVocal({ onAppend }) {
  const [listening, setListening] = useState(false);
  const [supported] = useState(() => "webkitSpeechRecognition" in window || "SpeechRecognition" in window);
  const recRef = useRef(null);

  const toggle = () => {
    if (listening) {
      recRef.current?.stop();
      setListening(false);
      return;
    }
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    const rec = new SR();
    rec.lang = "fr-FR";
    rec.continuous = true;
    rec.interimResults = false;
    rec.onresult = (e) => {
      for (let i = e.resultIndex; i < e.results.length; i++) {
        if (e.results[i].isFinal) onAppend(e.results[i][0].transcript + " ");
      }
    };
    rec.onend = () => setListening(false);
    recRef.current = rec;
    rec.start();
    setListening(true);
  };

  if (!supported) {
    return (
      <p className="rounded-2xl border border-white/10 bg-[#121212] p-5 text-center text-[12.5px] text-white/50">
        La reconnaissance vocale n'est pas disponible dans ce navigateur —
        essayez Chrome ou Safari. La lecture à voix haute (bouton haut-parleur) fonctionne partout.
      </p>
    );
  }

  return (
    <div className="rounded-2xl border border-white/10 bg-[#121212] p-6 text-center">
      <button
        type="button"
        onClick={toggle}
        aria-pressed={listening}
        className={`grid h-24 w-24 place-items-center rounded-full transition ${
          listening ? "animate-pulse bg-fire text-black shadow-2xl" : "bg-white/[0.07] text-white/70 hover:bg-white/[0.14]"
        }`}
        aria-label={listening ? "Arrêter l'écoute" : "Parler"}
      >
        {listening ? <MicOff className="h-9 w-9" /> : <Mic className="h-9 w-9" />}
      </button>
      <p className="mt-4 text-[13px] font-semibold text-white">
        {listening ? "Je vous écoute — parlez naturellement." : "Touchez pour parler"}
      </p>
      <p className="mt-1 font-mono text-[9px] uppercase tracking-[0.22em] text-white/30">
        vraie voix · ce que vous dites s'écrit, la phrase peut être relue à voix haute
      </p>
    </div>
  );
}