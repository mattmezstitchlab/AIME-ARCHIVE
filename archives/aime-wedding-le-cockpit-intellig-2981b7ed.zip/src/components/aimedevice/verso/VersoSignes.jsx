import { Delete } from "lucide-react";

const ROWS = ["ABCDEFG", "HIJKLMN", "OPQRSTU", "VWXYZ"];

// Configuration de main approchée pour chaque lettre de l'alphabet
// dactylologique — chaque touche montre une main différente.
const HANDS = {
  A: "✊", B: "🖐️", C: "🤏", D: "☝️", E: "🤛", F: "👌", G: "👉",
  H: "✌️", I: "🤙", J: "🤙", K: "🖖", L: "🫰", M: "🤜", N: "👊",
  O: "👌", P: "👇", Q: "🫳", R: "🤞", S: "✊", T: "👍", U: "✌️",
  V: "✌️", W: "🤟", X: "☝️", Y: "🤙", Z: "👆",
};

// Mode SIGNES — alphabet dactylologique : grandes touches lettre + main,
// pour épeler à la main ce que l'appareil écrit et lit.
export default function VersoSignes({ onAppend, onBackspace }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-[#121212] p-3">
      <div className="space-y-1.5">
        {ROWS.map((row) => (
          <div key={row} className="flex justify-center gap-1.5">
            {row.split("").map((l) => (
              <button
                key={l}
                type="button"
                onClick={() => onAppend(l.toLowerCase())}
                aria-label={`Lettre ${l} en dactylologie`}
                className="flex h-14 w-11 flex-col items-center justify-center rounded-xl bg-white/[0.05] transition hover:bg-accent hover:text-black"
              >
                <span className="text-[17px] font-bold">{l}</span>
                <span className="text-[15px]" aria-hidden="true">{HANDS[l]}</span>
              </button>
            ))}
          </div>
        ))}
      </div>
      <div className="mt-2 flex justify-center gap-1.5">
        <button type="button" onClick={() => onAppend(" ")}
          className="h-10 flex-1 rounded-xl bg-white/[0.05] text-[11px] font-semibold text-white/60 transition hover:bg-white/10">
          espace
        </button>
        <button type="button" onClick={onBackspace} aria-label="Effacer"
          className="grid h-10 w-14 place-items-center rounded-xl border border-white/15 text-white/60 transition hover:text-white">
          <Delete className="h-4 w-4" />
        </button>
      </div>
      <p className="mt-2 text-center font-mono text-[9px] uppercase tracking-[0.22em] text-white/30">
        alphabet dactylologique · chaque lettre s'épelle à la main
      </p>
    </div>
  );
}