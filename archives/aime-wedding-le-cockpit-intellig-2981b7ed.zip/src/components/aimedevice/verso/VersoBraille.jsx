import { useState } from "react";
import { Delete, Plus } from "lucide-react";

// Cellule braille standard : points 1-6 → lettre.
const BRAILLE = {
  "1": "a", "12": "b", "14": "c", "145": "d", "15": "e", "124": "f", "1245": "g",
  "125": "h", "24": "i", "245": "j", "13": "k", "123": "l", "134": "m", "1345": "n",
  "135": "o", "1234": "p", "12345": "q", "1235": "r", "234": "s", "2345": "t",
  "136": "u", "1236": "v", "2456": "w", "1346": "x", "13456": "y", "1356": "z",
};

// Mode BRAILLE — la cellule à 6 points : on allume les points, la lettre
// détectée s'affiche, on l'ajoute à la phrase.
export default function VersoBraille({ onAppend, onBackspace }) {
  const [dots, setDots] = useState([]); // ex. [1,4,5]

  const toggle = (d) =>
    setDots((prev) => (prev.includes(d) ? prev.filter((x) => x !== d) : [...prev, d].sort()));

  const letter = BRAILLE[dots.join("")] || null;

  const add = () => {
    if (!letter) return;
    onAppend(letter);
    setDots([]);
  };

  return (
    <div className="rounded-2xl border border-white/10 bg-[#121212] p-4">
      <div className="flex items-center justify-center gap-8">
        {/* La cellule : 2 colonnes × 3 points (1-2-3 / 4-5-6) */}
        <div className="flex gap-3">
          {[[1, 2, 3], [4, 5, 6]].map((col, ci) => (
            <div key={ci} className="flex flex-col gap-3">
              {col.map((d) => (
                <button
                  key={d}
                  type="button"
                  onClick={() => toggle(d)}
                  aria-pressed={dots.includes(d)}
                  aria-label={`Point braille ${d}`}
                  className={`h-12 w-12 rounded-full transition ${
                    dots.includes(d) ? "scale-105 bg-accent shadow-lg" : "bg-white/[0.07] hover:bg-white/[0.14]"
                  }`}
                />
              ))}
            </div>
          ))}
        </div>
        {/* La lettre détectée */}
        <div className="text-center">
          <p className="font-mono text-[9px] uppercase tracking-[0.24em] text-white/35">lettre</p>
          <p className="font-heading text-6xl font-bold text-white">{letter ? letter.toUpperCase() : "·"}</p>
        </div>
      </div>
      <div className="mt-4 flex gap-2">
        <button type="button" onClick={add} disabled={!letter}
          className="inline-flex flex-1 items-center justify-center gap-2 rounded-xl bg-accent py-3 text-[14px] font-bold text-black transition hover:brightness-110 disabled:opacity-35">
          <Plus className="h-4 w-4" /> Ajouter la lettre
        </button>
        <button type="button" onClick={() => onAppend(" ")}
          className="rounded-xl border border-white/15 px-5 text-[12px] font-semibold text-white/60 transition hover:text-white">
          espace
        </button>
        <button type="button" onClick={onBackspace} aria-label="Effacer"
          className="grid w-14 place-items-center rounded-xl border border-white/15 text-white/60 transition hover:text-white">
          <Delete className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}