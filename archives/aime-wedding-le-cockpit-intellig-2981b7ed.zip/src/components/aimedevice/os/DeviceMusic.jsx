import { useEffect, useRef, useState } from "react";
import { Music } from "lucide-react";

// MODE MUSIQUE — les touches du clavier deviennent des notes (Web Audio).
// Pensé pour la thérapie et le handicap : grandes touches, un doigt suffit,
// on peut jouer ensemble sur le même tempo.
const NOTES = [
  { key: "Q", label: "Do", freq: 261.63 },
  { key: "S", label: "Ré", freq: 293.66 },
  { key: "D", label: "Mi", freq: 329.63 },
  { key: "F", label: "Fa", freq: 349.23 },
  { key: "G", label: "Sol", freq: 392.0 },
  { key: "H", label: "La", freq: 440.0 },
  { key: "J", label: "Si", freq: 493.88 },
  { key: "K", label: "Do·", freq: 523.25 },
];

export default function DeviceMusic() {
  const ctxRef = useRef(null);
  const [active, setActive] = useState(null);

  const play = (note) => {
    if (!ctxRef.current) ctxRef.current = new (window.AudioContext || window.webkitAudioContext)();
    const ctx = ctxRef.current;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sine";
    osc.frequency.value = note.freq;
    gain.gain.setValueAtTime(0.35, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.9);
    osc.connect(gain).connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.95);
    setActive(note.key);
    setTimeout(() => setActive(null), 250);
  };

  // Le vrai clavier physique joue aussi.
  useEffect(() => {
    const onKey = (e) => {
      const note = NOTES.find((n) => n.key === e.key.toUpperCase());
      if (note && !e.repeat) play(note);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <div className="rounded-2xl border border-white/10 bg-[#121212] p-4">
      <p className="flex items-center gap-2 font-mono text-[9px] uppercase tracking-[0.26em] text-white/35">
        <Music className="h-3.5 w-3.5 text-accent" /> les touches sont des notes · un doigt suffit
      </p>
      <div className="mt-3 grid grid-cols-8 gap-1.5">
        {NOTES.map((n) => (
          <button
            key={n.key}
            type="button"
            onClick={() => play(n)}
            aria-label={`Jouer la note ${n.label}`}
            className={`flex h-24 flex-col items-center justify-end gap-1 rounded-xl pb-2 transition ${
              active === n.key ? "scale-95 bg-accent text-black" : "bg-white/[0.06] text-white/70 hover:bg-white/[0.12]"
            }`}
          >
            <span className="text-[13px] font-bold">{n.label}</span>
            <span className="font-mono text-[9px] opacity-50">{n.key}</span>
          </button>
        ))}
      </div>
      <p className="mt-3 text-center font-mono text-[8.5px] uppercase tracking-[0.2em] text-white/25">
        jouez avec les touches q s d f g h j k · l'orchestre mondial sur tempo arrive
      </p>
    </div>
  );
}