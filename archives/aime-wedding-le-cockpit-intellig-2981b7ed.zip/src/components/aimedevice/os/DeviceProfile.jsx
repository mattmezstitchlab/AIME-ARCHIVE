import { useState, useEffect } from "react";
import { Loader2, Fingerprint, ShieldCheck, Sparkles } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { loadProfile } from "@/lib/onboarding/profileStore";
import { loadEtreProfile } from "@/lib/onboarding/proProfileStore";

// PROFIL AI+ME — la fiche n'existe QUE dans cet écran : elle est rendue par la
// fonction serveur aimeIdentity, jamais par une page du site.
export default function DeviceProfile() {
  const [state, setState] = useState({ loading: true });

  const load = async () => {
    try {
      const { data } = await base44.functions.invoke("aimeIdentity", { action: "get" });
      setState({ identity: data.identity });
    } catch {
      setState({ error: "Connectez-vous pour accéder à votre fiche AI+ME." });
    }
  };

  useEffect(() => { load(); }, []);

  const generate = async () => {
    setState({ loading: true });
    // Le code embarque l'onboarding local (rôle, essence) au moment de la création.
    const profile = loadProfile();
    const etre = loadEtreProfile();
    const { data } = await base44.functions.invoke("aimeIdentity", {
      action: "generate",
      role: profile?.roleLabel || "",
      universe: profile?.role === "couple" ? "Mariage" : "Universel",
      essence: etre?.essence || "",
      answers: { ...(etre?.now || {}) },
    });
    setState({ identity: data.identity, justCreated: data.created });
  };

  if (state.loading) return <p className="flex items-center gap-2 text-[12px] text-white/50"><Loader2 className="h-4 w-4 animate-spin text-accent" /> Ouverture du coffre…</p>;
  if (state.error) return <p className="text-[12px] text-amber-300">{state.error}</p>;

  if (!state.identity) {
    return (
      <div className="rounded-2xl border border-white/10 bg-[#121212] p-6 text-center">
        <Fingerprint className="mx-auto h-10 w-10 text-accent" strokeWidth={1.4} />
        <p className="mt-3 text-[13.5px] font-semibold text-white">Vous n'avez pas encore de code AI+ME.</p>
        <p className="mx-auto mt-1 max-w-xs text-[11.5px] leading-relaxed text-white/45">
          Généré une seule fois, côté serveur, aléatoire cryptographique — votre identité causale,
          lisible uniquement dans cet appareil.
        </p>
        <button type="button" onClick={generate}
          className="mt-4 inline-flex items-center gap-2 rounded-xl bg-accent px-5 py-2.5 text-[13px] font-bold text-black transition hover:brightness-110">
          <Sparkles className="h-4 w-4" /> Générer mon code AI+ME
        </button>
      </div>
    );
  }

  const id = state.identity;
  return (
    <div className="rounded-2xl border border-accent/25 bg-gradient-to-b from-[#161616] to-[#0e0e0e] p-5">
      <div className="flex items-center justify-between">
        <p className="font-mono text-[9px] uppercase tracking-[0.3em] text-white/35">carte d'identité causale</p>
        <span className="inline-flex items-center gap-1 font-mono text-[8.5px] uppercase tracking-[0.18em] text-emerald-400">
          <ShieldCheck className="h-3 w-3" /> device-only
        </span>
      </div>
      <p className="mt-4 font-mono text-3xl font-semibold tracking-[0.08em] text-accent">{id.code}</p>
      <p className="mt-3 font-heading text-xl font-semibold text-white">{id.display_name || "—"}</p>
      {id.role && <p className="text-[12px] text-white/55">{id.role}{id.universe ? ` · ${id.universe}` : ""}</p>}
      {id.essence && <p className="mt-3 border-l-2 border-accent/40 pl-3 text-[12px] italic leading-relaxed text-white/60">{id.essence}</p>}
      <p className="mt-4 font-mono text-[8.5px] uppercase tracking-[0.2em] text-white/25">
        cette fiche n'est rendue que dans l'écran ai+me · jamais sur une page du site
      </p>
      {state.justCreated && (
        <p className="mt-2 text-[11px] text-emerald-400">✓ Code créé — il est unique et à vous pour toujours.</p>
      )}
    </div>
  );
}