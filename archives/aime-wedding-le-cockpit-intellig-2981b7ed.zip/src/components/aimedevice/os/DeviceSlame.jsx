import { useState } from "react";
import { Loader2, Mic2, Play } from "lucide-react";
import { base44 } from "@/api/base44Client";

const VOICES = [
  { id: "river", label: "Rivière", desc: "calme" },
  { id: "honey", label: "Miel", desc: "douce" },
  { id: "sunny", label: "Soleil", desc: "joyeuse" },
  { id: "storm", label: "Orage", desc: "posée" },
  { id: "spark", label: "Étincelle", desc: "vive" },
];

// SLÂME — écrire un texte (conte, chanson, slam) et l'entendre dit à voix haute.
export default function DeviceSlame() {
  const [text, setText] = useState("");
  const [voice, setVoice] = useState("river");
  const [audio, setAudio] = useState(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const speak = async () => {
    setBusy(true);
    setError("");
    try {
      const res = await base44.integrations.Core.GenerateSpeech({ text: text.slice(0, 1500), voice });
      setAudio(res.url);
    } catch (e) {
      setError(e?.response?.data?.error || e?.message || "La voix n'a pas pu être générée.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div>
      <p className="mb-3 flex items-center gap-2 font-mono text-[9px] uppercase tracking-[0.26em] text-white/35">
        <Mic2 className="h-3.5 w-3.5 text-accent" /> slâme · contes, chansons, slam à voix haute
      </p>
      <textarea value={text} onChange={(e) => setText(e.target.value)} rows={4}
        placeholder="Écrivez votre texte : un conte pour ce soir, un couplet, un slam…"
        className="w-full rounded-xl border border-white/12 bg-white/[0.04] px-3 py-2.5 text-[12.5px] text-white placeholder:text-white/30 focus:border-accent/50 focus:outline-none" />
      <div className="mt-2 flex flex-wrap gap-1.5">
        {VOICES.map((v) => (
          <button key={v.id} type="button" onClick={() => setVoice(v.id)}
            className={`rounded-full px-3 py-1.5 text-[10.5px] font-semibold transition ${voice === v.id ? "bg-accent text-black" : "border border-white/12 text-white/60 hover:text-white"}`}>
            {v.label} <span className="opacity-50">· {v.desc}</span>
          </button>
        ))}
      </div>
      {error && <p className="mt-2 text-[10.5px] text-amber-300">{error}</p>}
      <button type="button" onClick={speak} disabled={busy || !text.trim()}
        className="mt-3 inline-flex w-full items-center justify-center gap-1.5 rounded-xl bg-accent px-3 py-2.5 text-[12px] font-bold text-black transition hover:brightness-110 disabled:opacity-45">
        {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4" />}
        {busy ? "La voix se prépare…" : "Dire à voix haute"}
      </button>
      {audio && <audio controls src={audio} className="mt-3 w-full" aria-label="Écouter votre texte" />}
      <p className="mt-2 text-center font-mono text-[8.5px] uppercase tracking-[0.18em] text-white/25">
        le clonage de votre propre voix arrive dans une prochaine version
      </p>
    </div>
  );
}