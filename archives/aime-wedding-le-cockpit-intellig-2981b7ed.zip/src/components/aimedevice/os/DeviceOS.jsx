import { useState } from "react";
import { ArrowLeft, Fingerprint, Music, Palette, Grid3x3, Mic2, AudioWaveform, Disc3, Languages, ListMusic, LayoutTemplate, Stamp, HeartHandshake, Inbox, Heart, Globe2, Footprints } from "lucide-react";
import DeviceProfile from "@/components/aimedevice/os/DeviceProfile";
import DeviceMusic from "@/components/aimedevice/os/DeviceMusic";
import DeviceBuilder from "@/components/aimedevice/os/DeviceBuilder";
import DeviceStamp from "@/components/aimedevice/os/DeviceStamp";
import DeviceContracts from "@/components/aimedevice/os/DeviceContracts";
import DeviceDons from "@/components/aimedevice/os/DeviceDons";
import DeviceGridArt from "@/components/aimedevice/os/DeviceGridArt";
import DeviceSlame from "@/components/aimedevice/os/DeviceSlame";
import DeviceTraduction from "@/components/aimedevice/os/DeviceTraduction";
import DeviceMessagerie from "@/components/aimedevice/os/DeviceMessagerie";

// LA GRILLE UNIVERSELLE — le cœur de l'OS AGENTS : chaque tuile est un mode
// de l'appareil. Certains sont vivants, les autres arrivent (gravés "à venir").
const MODES = [
  { id: "profil", icon: Fingerprint, label: "Profil AI+ME", desc: "Votre code causal · visible ici uniquement", live: true },
  { id: "musique", icon: Music, label: "Musique", desc: "Jouer avec les touches · thérapie & orchestre", live: true },
  { id: "builder", icon: LayoutTemplate, label: "Builder", desc: "Les blocs de site · génération directe", live: true },
  { id: "stamp", icon: Stamp, label: "Stamp", desc: "Timbre dentelé · charte & tampon horodaté", live: true },
  { id: "contrats", icon: HeartHandshake, label: "Contrats", desc: "Union & séparation AI+ME · alignement", live: true },
  { id: "dons", icon: Footprints, label: "Dons", desc: "Circuit mondial · chaussures & tous dons", live: true },
  { id: "messagerie", icon: Inbox, label: "Messagerie IA", desc: "Classe, répond, chiffre, négocie", live: true },
  { id: "coloriage", icon: Palette, label: "Coloriage", desc: "Grille à remplir · un doigt suffit", live: true },
  { id: "broderie", icon: Grid3x3, label: "Broderie DMC", desc: "Point de croix · grille magnétique", live: true },
  { id: "slame", icon: Mic2, label: "Slâme", desc: "Contes, chansons, slam à voix haute", live: true },
  { id: "langues", icon: Languages, label: "Traduction", desc: "Clavier & écran en toute langue", live: true },
  { id: "rencontre", icon: Heart, label: "Rencontre", desc: "Se rencontrer par alignement causal" },
  { id: "carte", icon: Globe2, label: "Carte mondiale", desc: "Retournez le device : la grille universelle" },
  { id: "studio", icon: AudioWaveform, label: "Studio stems", desc: "Séparer un MP3 en pistes" },
  { id: "mix", icon: Disc3, label: "Mix DJ", desc: "Mixer branché aux mariés & invités" },
  { id: "accord", icon: ListMusic, label: "Accord", desc: "La playlist mondiale" },
];

export default function DeviceOS() {
  const [mode, setMode] = useState(null);

  if (mode) {
    return (
      <div className="p-3">
        <button
          type="button"
          onClick={() => setMode(null)}
          className="mb-3 inline-flex items-center gap-1.5 font-mono text-[9.5px] font-semibold uppercase tracking-[0.22em] text-white/45 transition hover:text-white"
        >
          <ArrowLeft className="h-3.5 w-3.5" /> Grille universelle
        </button>
        {mode === "profil" && <DeviceProfile />}
        {mode === "musique" && <DeviceMusic />}
        {mode === "builder" && <DeviceBuilder />}
        {mode === "stamp" && <DeviceStamp />}
        {mode === "contrats" && <DeviceContracts />}
        {mode === "dons" && <DeviceDons />}
        {mode === "messagerie" && <DeviceMessagerie />}
        {mode === "coloriage" && <DeviceGridArt variant="coloriage" />}
        {mode === "broderie" && <DeviceGridArt variant="broderie" />}
        {mode === "slame" && <DeviceSlame />}
        {mode === "langues" && <DeviceTraduction />}
      </div>
    );
  }

  // LE BUREAU — fond d'écran + icônes d'applis, comme un vrai desktop.
  return (
    <div
      className="relative overflow-hidden rounded-2xl border border-white/10 bg-cover bg-center p-4"
      style={{ backgroundImage: "url(https://media.base44.com/images/public/6a4121ee87663bd9b9c98ef7/78662cee3_generated_image.png)" }}
    >
      <p className="mb-4 font-mono text-[9px] uppercase tracking-[0.3em] text-white/45">
        bureau ai+me · {MODES.filter((m) => m.live).length} applis actives
      </p>
      <div className="grid grid-cols-4 gap-x-2 gap-y-4 sm:grid-cols-5">
        {MODES.map((m) => (
          <button
            key={m.id}
            type="button"
            onClick={() => m.live && setMode(m.id)}
            disabled={!m.live}
            title={m.desc}
            className={`group flex flex-col items-center gap-1.5 text-center ${m.live ? "" : "opacity-45"}`}
          >
            <span className={`grid h-14 w-14 place-items-center rounded-2xl border backdrop-blur-md transition ${
              m.live
                ? "border-white/15 bg-black/40 shadow-lg group-hover:scale-110 group-hover:border-accent/60"
                : "border-white/[0.08] bg-black/25"
            }`}>
              <m.icon className={`h-6 w-6 ${m.live ? "text-accent" : "text-white/35"}`} strokeWidth={1.6} />
            </span>
            <span className="max-w-[4.6rem] truncate text-[10px] font-semibold text-white drop-shadow">{m.label}</span>
            {!m.live && (
              <span className="font-mono text-[7px] uppercase tracking-[0.18em] text-fire/80">à venir</span>
            )}
          </button>
        ))}
      </div>
    </div>
  );
}