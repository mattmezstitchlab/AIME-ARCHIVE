import { useState } from "react";
import { Loader2, Languages, ArrowRight } from "lucide-react";
import { base44 } from "@/api/base44Client";

const LANGS = ["Anglais", "Espagnol", "Arabe", "Allemand", "Italien", "Portugais", "Chinois", "Japonais", "Ukrainien", "Français"];

// TRADUCTION — l'écran et le clavier dans toutes les langues : on écrit, ça traduit.
export default function DeviceTraduction() {
  const [text, setText] = useState("");
  const [lang, setLang] = useState("Anglais");
  const [result, setResult] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const translate = async () => {
    setBusy(true);
    setError("");
    try {
      const out = await base44.integrations.Core.InvokeLLM({
        prompt: `Traduis fidèlement ce texte en ${lang}, en gardant le ton et le niveau de langue. Réponds UNIQUEMENT avec la traduction :\n\n${text}`,
      });
      setResult(out);
    } catch (e) {
      setError(e?.response?.data?.error || e?.message || "Traduction impossible — réessayez.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div>
      <p className="mb-3 flex items-center gap-2 font-mono text-[9px] uppercase tracking-[0.26em] text-white/35">
        <Languages className="h-3.5 w-3.5 text-accent" /> traduction · toutes les langues
      </p>
      <textarea value={text} onChange={(e) => setText(e.target.value)} rows={3}
        placeholder="Écrivez dans votre langue…"
        className="w-full rounded-xl border border-white/12 bg-white/[0.04] px-3 py-2.5 text-[12.5px] text-white placeholder:text-white/30 focus:border-accent/50 focus:outline-none" />
      <div className="mt-2 flex flex-wrap gap-1.5">
        {LANGS.map((l) => (
          <button key={l} type="button" onClick={() => setLang(l)}
            className={`rounded-full px-2.5 py-1 text-[10px] font-semibold transition ${lang === l ? "bg-accent text-black" : "border border-white/12 text-white/60 hover:text-white"}`}>
            {l}
          </button>
        ))}
      </div>
      {error && <p className="mt-2 text-[10.5px] text-amber-300">{error}</p>}
      <button type="button" onClick={translate} disabled={busy || !text.trim()}
        className="mt-3 inline-flex w-full items-center justify-center gap-1.5 rounded-xl bg-accent px-3 py-2.5 text-[12px] font-bold text-black transition hover:brightness-110 disabled:opacity-45">
        {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <ArrowRight className="h-4 w-4" />}
        Traduire en {lang.toLowerCase()}
      </button>
      {result && (
        <div className="mt-3 rounded-xl border border-accent/25 bg-[#121212] p-3.5 text-[13px] leading-relaxed text-white" dir="auto">
          {result}
        </div>
      )}
    </div>
  );
}