import { useEffect, useState } from "react";
import { Loader2, Stamp, Upload, Sparkles, ShieldCheck } from "lucide-react";
import { base44 } from "@/api/base44Client";

const CHARTE =
  "Je certifie que ce timbre me représente, que je l'utilise en mon nom propre, dans la vérité, " +
  "la bienveillance et le respect de l'autre. Tout acte scellé par ce timbre engage ma parole.";

// MODE STAMP — le vrai timbre dentelé : photo ou prompt → visuel de timbre,
// charte à signer, tampon horodaté côté serveur, registre des timbres.
export default function DeviceStamp() {
  const [stamps, setStamps] = useState(null);
  const [prompt, setPrompt] = useState("");
  const [label, setLabel] = useState("");
  const [signName, setSignName] = useState("");
  const [preview, setPreview] = useState(null); // url générée en attente de charte
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    base44.entities.AimeStamp.list("-created_date", 20).then(setStamps).catch(() => setStamps([]));
  }, []);

  const generateFromPrompt = async () => {
    setBusy(true);
    setError("");
    try {
      const res = await base44.integrations.Core.GenerateImage({
        prompt: `Illustration de timbre postal de collection, cadre intérieur fin, style gravure élégante : ${prompt}. Composition centrée, riche en détails, digne d'un vrai timbre officiel.`,
      });
      setPreview(res.url);
    } catch (e) {
      setError(e?.response?.data?.error || e?.message || "La génération a échoué — réessayez.");
    } finally {
      setBusy(false);
    }
  };

  const generateFromPhoto = async (file) => {
    if (!file) return;
    setBusy(true);
    setError("");
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      const res = await base44.integrations.Core.GenerateImage({
        prompt: "Transformer ce portrait en timbre postal officiel de collection : style gravure fine, cadre intérieur, fond uni élégant, digne et respectueux de la personne.",
        existing_image_urls: [file_url],
      });
      setPreview(res.url);
    } catch (e) {
      setError(e?.response?.data?.error || e?.message || "La génération a échoué — réessayez.");
    } finally {
      setBusy(false);
    }
  };

  // Signature de la charte + tampon : l'horodatage est celui du serveur (created_date).
  const seal = async () => {
    setBusy(true);
    const created = await base44.entities.AimeStamp.create({
      label: label || `Timbre de ${signName}`,
      image_url: preview,
      charte_signed: true,
      signature_name: signName,
      stamped_at: new Date().toISOString(),
    });
    setStamps((s) => [created, ...(s || [])]);
    setPreview(null);
    setPrompt("");
    setLabel("");
    setSignName("");
    setBusy(false);
  };

  return (
    <div className="space-y-4">
      <p className="flex items-center gap-2 font-mono text-[9px] uppercase tracking-[0.26em] text-white/35">
        <Stamp className="h-3.5 w-3.5 text-accent" /> stamp · timbre dentelé · registre horodaté
      </p>

      {/* Création */}
      {!preview ? (
        <div className="rounded-2xl border border-white/10 bg-[#121212] p-4 space-y-2.5">
          <input
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Décrivez votre timbre (ex. saxophoniste sous les étoiles)…"
            className="w-full rounded-xl border border-white/12 bg-white/[0.04] px-3 py-2.5 text-[12.5px] text-white placeholder:text-white/30 focus:border-accent/50 focus:outline-none"
          />
          <div className="flex gap-2">
            <button type="button" onClick={generateFromPrompt} disabled={busy || !prompt.trim()}
              className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-accent px-3 py-2.5 text-[12px] font-bold text-black transition hover:brightness-110 disabled:opacity-45">
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />} Générer
            </button>
            <label className="inline-flex flex-1 cursor-pointer items-center justify-center gap-1.5 rounded-xl border border-white/15 px-3 py-2.5 text-[12px] font-semibold text-white/80 transition hover:bg-white/[0.06]">
              <Upload className="h-4 w-4" /> Ma photo
              <input type="file" accept="image/*" className="hidden" onChange={(e) => generateFromPhoto(e.target.files?.[0])} />
            </label>
          </div>
          {busy && <p className="text-center text-[11px] text-white/40">Gravure du timbre en cours…</p>}
          {error && <p className="text-center text-[11px] text-amber-300">{error}</p>}
        </div>
      ) : (
        /* Charte + tampon */
        <div className="rounded-2xl border border-accent/25 bg-[#121212] p-4">
          <div className="mx-auto w-36 stamp-card relative p-2">
            <img src={preview} alt="Votre timbre AI+ME" className="w-full rounded-sm" />
            <div className="stamp-teeth absolute inset-0" />
          </div>
          <input value={label} onChange={(e) => setLabel(e.target.value)} placeholder="Nom du timbre"
            className="mt-3 w-full rounded-xl border border-white/12 bg-white/[0.04] px-3 py-2 text-[12px] text-white placeholder:text-white/30 focus:border-accent/50 focus:outline-none" />
          <p className="mt-3 rounded-xl border border-white/10 bg-white/[0.03] p-3 text-[11px] italic leading-relaxed text-white/55">
            {CHARTE}
          </p>
          <input value={signName} onChange={(e) => setSignName(e.target.value)} placeholder="Signez de votre nom pour accepter la charte"
            className="mt-2 w-full rounded-xl border border-white/12 bg-white/[0.04] px-3 py-2 font-signature text-lg text-accent placeholder:font-body placeholder:text-[12px] placeholder:text-white/30 focus:border-accent/50 focus:outline-none" />
          <div className="mt-3 flex gap-2">
            <button type="button" onClick={() => setPreview(null)} className="rounded-xl border border-white/15 px-3 py-2.5 text-[12px] text-white/60 transition hover:bg-white/[0.06]">
              Refaire
            </button>
            <button type="button" onClick={seal} disabled={busy || !signName.trim()}
              className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-accent px-3 py-2.5 text-[12px] font-bold text-black transition hover:brightness-110 disabled:opacity-45">
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Stamp className="h-4 w-4" />} Signer & tamponner
            </button>
          </div>
        </div>
      )}

      {/* Registre */}
      <div>
        <p className="mb-2 font-mono text-[9px] uppercase tracking-[0.26em] text-white/35">registre</p>
        {stamps === null ? (
          <p className="text-[11px] text-white/40">Ouverture du registre…</p>
        ) : stamps.length === 0 ? (
          <p className="text-[11px] text-white/40">Aucun timbre encore — le vôtre sera le premier du registre.</p>
        ) : (
          <div className="grid grid-cols-3 gap-2">
            {stamps.map((s) => (
              <div key={s.id} className="stamp-card relative p-1.5">
                <img src={s.image_url} alt={s.label || "Timbre AI+ME"} className="w-full rounded-sm" />
                <div className="stamp-teeth absolute inset-0" />
                <p className="mt-1 truncate text-center text-[9px] text-white/60">{s.label}</p>
                <p className="flex items-center justify-center gap-1 font-mono text-[7.5px] text-emerald-400">
                  <ShieldCheck className="h-2.5 w-2.5" />
                  {new Date(s.stamped_at || s.created_date).toLocaleString("fr-FR")}
                </p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}