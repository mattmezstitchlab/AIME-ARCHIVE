import { useEffect, useState } from "react";
import { Loader2, Footprints, HandHeart, CalendarDays, MapPin, Plus } from "lucide-react";
import { base44 } from "@/api/base44Client";

// MODE DONS — le circuit mondial : des points de collecte (associations,
// particuliers, mairies…) reliés autour d'une DATE J où tout se met en action.
// Chaussures d'abord, mais peu importe la nature des dons.
export default function DeviceDons() {
  const [drives, setDrives] = useState(null);
  const [creating, setCreating] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [form, setForm] = useState({ title: "", donation_type: "chaussures", city: "", organizer_name: "", action_date: "", target_quantity: "" });
  const [pledge, setPledge] = useState({}); // driveId → { name, quantity }

  useEffect(() => {
    base44.entities.DonationDrive.list("-created_date", 30).then(setDrives).catch(() => setDrives([]));
  }, []);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const create = async () => {
    setBusy(true);
    setError("");
    try {
      const created = await base44.entities.DonationDrive.create({
        ...form,
        target_quantity: Number(form.target_quantity) || 0,
        pledges: [],
      });
      setDrives((d) => [created, ...(d || [])]);
      setCreating(false);
      setForm({ title: "", donation_type: "chaussures", city: "", organizer_name: "", action_date: "", target_quantity: "" });
    } catch (e) {
      setError(e?.message || "Création impossible");
    }
    setBusy(false);
  };

  const promettre = async (drive) => {
    const p = pledge[drive.id];
    if (!p?.name || !p?.quantity) return;
    const pledges = [...(drive.pledges || []), { name: p.name, quantity: Number(p.quantity), note: "" }];
    const collected = (drive.collected_quantity || 0) + Number(p.quantity);
    const updated = await base44.entities.DonationDrive.update(drive.id, { pledges, collected_quantity: collected });
    setDrives((list) => list.map((d) => (d.id === drive.id ? updated : d)));
    setPledge((s) => ({ ...s, [drive.id]: { name: "", quantity: "" } }));
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <p className="flex items-center gap-2 font-mono text-[9px] uppercase tracking-[0.26em] text-white/35">
          <Footprints className="h-3.5 w-3.5 text-accent" /> circuit mondial des dons
        </p>
        <button type="button" onClick={() => setCreating((c) => !c)}
          className="inline-flex items-center gap-1 rounded-full bg-accent/15 px-2.5 py-1 font-mono text-[9px] font-semibold uppercase tracking-[0.14em] text-accent transition hover:bg-accent/25">
          <Plus className="h-3 w-3" /> Point de collecte
        </button>
      </div>

      {creating && (
        <div className="rounded-2xl border border-white/10 bg-[#121212] p-3.5 space-y-2">
          <input value={form.title} onChange={(e) => set("title", e.target.value)} placeholder="Nom de la collecte (ex. Chaussures pour tous)"
            className="w-full rounded-xl border border-white/12 bg-white/[0.04] px-3 py-2 text-[12px] text-white placeholder:text-white/30 focus:border-accent/50 focus:outline-none" />
          <div className="grid grid-cols-2 gap-2">
            <input value={form.donation_type} onChange={(e) => set("donation_type", e.target.value)} placeholder="Nature du don (chaussures…)"
              className="rounded-xl border border-white/12 bg-white/[0.04] px-3 py-2 text-[12px] text-white placeholder:text-white/30 focus:border-accent/50 focus:outline-none" />
            <input value={form.city} onChange={(e) => set("city", e.target.value)} placeholder="Ville"
              className="rounded-xl border border-white/12 bg-white/[0.04] px-3 py-2 text-[12px] text-white placeholder:text-white/30 focus:border-accent/50 focus:outline-none" />
            <input value={form.organizer_name} onChange={(e) => set("organizer_name", e.target.value)} placeholder="Association / porteur"
              className="rounded-xl border border-white/12 bg-white/[0.04] px-3 py-2 text-[12px] text-white placeholder:text-white/30 focus:border-accent/50 focus:outline-none" />
            <input type="number" value={form.target_quantity} onChange={(e) => set("target_quantity", e.target.value)} placeholder="Objectif (ex. 500)"
              className="rounded-xl border border-white/12 bg-white/[0.04] px-3 py-2 text-[12px] text-white placeholder:text-white/30 focus:border-accent/50 focus:outline-none" />
          </div>
          <label className="block text-[10px] text-white/40">
            La date J — tout le circuit s'active ce jour-là
            <input type="date" value={form.action_date} onChange={(e) => set("action_date", e.target.value)}
              className="mt-1 w-full rounded-xl border border-white/12 bg-white/[0.04] px-3 py-2 text-[12px] text-white focus:border-accent/50 focus:outline-none" />
          </label>
          {error && <p className="text-[10.5px] text-amber-300">{error}</p>}
          <button type="button" onClick={create} disabled={busy || !form.title.trim()}
            className="inline-flex w-full items-center justify-center gap-1.5 rounded-xl bg-accent px-3 py-2.5 text-[12px] font-bold text-black transition hover:brightness-110 disabled:opacity-45">
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <HandHeart className="h-4 w-4" />} Créer le point de collecte
          </button>
        </div>
      )}

      {drives === null ? (
        <p className="text-[11px] text-white/40">Chargement du circuit…</p>
      ) : drives.length === 0 ? (
        <p className="rounded-xl border border-white/10 bg-white/[0.03] p-4 text-[11.5px] text-white/45">
          Le circuit est vide — créez le premier point de collecte : les associations, écoles et
          particuliers s'y brancheront, et à la date J les agents IA orchestrent tout.
        </p>
      ) : (
        drives.map((d) => {
          const pct = d.target_quantity ? Math.min(100, Math.round(((d.collected_quantity || 0) / d.target_quantity) * 100)) : 0;
          const p = pledge[d.id] || { name: "", quantity: "" };
          return (
            <div key={d.id} className="rounded-xl border border-white/10 bg-white/[0.03] p-3.5">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="text-[13px] font-semibold text-white">{d.title}</p>
                  <p className="mt-0.5 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-[10.5px] text-white/45">
                    <span className="capitalize">{d.donation_type}</span>
                    {d.city && <span className="inline-flex items-center gap-1"><MapPin className="h-3 w-3" />{d.city}</span>}
                    {d.action_date && <span className="inline-flex items-center gap-1 text-fire"><CalendarDays className="h-3 w-3" />Jour J : {new Date(d.action_date).toLocaleDateString("fr-FR")}</span>}
                    {d.organizer_name && <span>· {d.organizer_name}</span>}
                  </p>
                </div>
                <span className="shrink-0 font-mono text-[10px] font-bold text-accent">{d.collected_quantity || 0}{d.target_quantity ? `/${d.target_quantity}` : ""}</span>
              </div>
              {d.target_quantity > 0 && (
                <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white/[0.08]">
                  <div className="h-full rounded-full bg-accent transition-all" style={{ width: `${pct}%` }} />
                </div>
              )}
              <div className="mt-2.5 flex gap-1.5">
                <input value={p.name} onChange={(e) => setPledge((s) => ({ ...s, [d.id]: { ...p, name: e.target.value } }))} placeholder="Votre nom"
                  className="min-w-0 flex-1 rounded-lg border border-white/12 bg-white/[0.04] px-2.5 py-1.5 text-[11px] text-white placeholder:text-white/30 focus:border-accent/50 focus:outline-none" />
                <input type="number" value={p.quantity} onChange={(e) => setPledge((s) => ({ ...s, [d.id]: { ...p, quantity: e.target.value } }))} placeholder="Qté"
                  className="w-16 rounded-lg border border-white/12 bg-white/[0.04] px-2.5 py-1.5 text-[11px] text-white placeholder:text-white/30 focus:border-accent/50 focus:outline-none" />
                <button type="button" onClick={() => promettre(d)}
                  className="shrink-0 rounded-lg bg-accent/15 px-3 py-1.5 text-[10.5px] font-bold text-accent transition hover:bg-accent/25">
                  Promettre
                </button>
              </div>
            </div>
          );
        })
      )}
    </div>
  );
}