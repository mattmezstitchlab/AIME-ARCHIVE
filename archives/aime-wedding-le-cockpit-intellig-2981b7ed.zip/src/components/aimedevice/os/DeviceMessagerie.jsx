import { useState } from "react";
import { Loader2, Inbox, Sparkles } from "lucide-react";
import ReactMarkdown from "react-markdown";
import { base44 } from "@/api/base44Client";

const URGENCE = { haute: "bg-fire/15 text-fire", moyenne: "bg-amber-400/15 text-amber-300", basse: "bg-white/[0.06] text-white/50" };

// MESSAGERIE IA — collez un message client : l'IA le classe (importance,
// catégorie), répond, génère devis / facture / contrat et négocie le prix.
export default function DeviceMessagerie() {
  const [message, setMessage] = useState("");
  const [context, setContext] = useState("");
  const [result, setResult] = useState(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const treat = async () => {
    setBusy(true);
    setError("");
    try {
      const data = await base44.integrations.Core.InvokeLLM({
        prompt:
          `Tu es l'agent messagerie d'un prestataire (contexte métier/tarifs : ${context || "prestataire événementiel, tarifs habituels du marché"}). ` +
          `Voici un message client reçu :\n"""${message}"""\n\n` +
          `1. Classe-le : importance (haute/moyenne/basse), catégorie (demande de devis, réservation, négociation prix, réclamation, question, autre). ` +
          `2. Rédige la réponse à envoyer au client : chaleureuse, professionnelle, en français. ` +
          `Si le client négocie le prix : négocie intelligemment (contre-proposition raisonnable, valeur mise en avant, jamais brader). ` +
          `3. Si pertinent, génère le document associé (devis structuré avec lignes et total, facture, ou trame de contrat) en markdown. ` +
          `4. Donne la prochaine action (ex. demander acompte, envoyer lien de paiement).`,
        response_json_schema: {
          type: "object",
          properties: {
            importance: { type: "string" },
            categorie: { type: "string" },
            reponse: { type: "string" },
            document: { type: "string" },
            prochaine_action: { type: "string" },
          },
          required: ["importance", "categorie", "reponse"],
        },
      });
      setResult(data);
    } catch (e) {
      setError(e?.response?.data?.error || e?.message || "Traitement impossible — réessayez.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div>
      <p className="mb-3 flex items-center gap-2 font-mono text-[9px] uppercase tracking-[0.26em] text-white/35">
        <Inbox className="h-3.5 w-3.5 text-accent" /> messagerie ia · classe, répond, chiffre, négocie
      </p>
      <input value={context} onChange={(e) => setContext(e.target.value)}
        placeholder="Votre métier & tarifs (ex. saxophoniste, mariage 800 €, cocktail 450 €)"
        className="w-full rounded-xl border border-white/12 bg-white/[0.04] px-3 py-2 text-[12px] text-white placeholder:text-white/30 focus:border-accent/50 focus:outline-none" />
      <textarea value={message} onChange={(e) => setMessage(e.target.value)} rows={3}
        placeholder="Collez le message du client reçu (mail, WhatsApp, Instagram…)"
        className="mt-2 w-full rounded-xl border border-white/12 bg-white/[0.04] px-3 py-2.5 text-[12.5px] text-white placeholder:text-white/30 focus:border-accent/50 focus:outline-none" />
      {error && <p className="mt-2 text-[10.5px] text-amber-300">{error}</p>}
      <button type="button" onClick={treat} disabled={busy || !message.trim()}
        className="mt-2 inline-flex w-full items-center justify-center gap-1.5 rounded-xl bg-accent px-3 py-2.5 text-[12px] font-bold text-black transition hover:brightness-110 disabled:opacity-45">
        {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
        {busy ? "L'agent traite le message…" : "Traiter le message"}
      </button>

      {result && (
        <div className="mt-3 space-y-2.5">
          <div className="flex flex-wrap gap-1.5">
            <span className={`rounded-full px-2.5 py-1 font-mono text-[9px] font-semibold uppercase tracking-[0.14em] ${URGENCE[result.importance?.toLowerCase()] || URGENCE.moyenne}`}>
              importance {result.importance}
            </span>
            <span className="rounded-full bg-white/[0.06] px-2.5 py-1 font-mono text-[9px] uppercase tracking-[0.14em] text-white/55">
              {result.categorie}
            </span>
          </div>
          <div className="rounded-xl border border-accent/25 bg-[#121212] p-3.5">
            <p className="mb-1.5 font-mono text-[8.5px] uppercase tracking-[0.2em] text-accent">réponse à envoyer</p>
            <p className="whitespace-pre-wrap text-[12.5px] leading-relaxed text-white/85">{result.reponse}</p>
          </div>
          {result.document && (
            <div className="rounded-xl border border-white/10 bg-[#121212] p-3.5">
              <p className="mb-1.5 font-mono text-[8.5px] uppercase tracking-[0.2em] text-white/40">document généré</p>
              <ReactMarkdown className="prose prose-invert prose-sm max-w-none text-[12px]">{result.document}</ReactMarkdown>
            </div>
          )}
          {result.prochaine_action && (
            <p className="text-[11px] text-white/50">→ Prochaine action : <span className="text-white">{result.prochaine_action}</span></p>
          )}
        </div>
      )}
    </div>
  );
}