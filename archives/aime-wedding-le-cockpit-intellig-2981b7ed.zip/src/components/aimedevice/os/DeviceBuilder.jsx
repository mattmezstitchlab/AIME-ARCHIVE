import { useState } from "react";
import { Loader2, Sparkles, LayoutTemplate } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { BUILDER_BLOCKS } from "@/lib/gallery/builderBlocks";

// MODE BUILDER — les blocs universels de la Galerie des visuels, embarqués
// dans l'écran de l'appareil : on génère chaque bloc directement ici.
export default function DeviceBuilder() {
  const [generated, setGenerated] = useState({});
  const [busy, setBusy] = useState(null);
  const [error, setError] = useState("");

  const generate = async (block) => {
    setBusy(block.key);
    setError("");
    try {
      const res = await base44.integrations.Core.GenerateImage({
        prompt:
          `Bloc « ${block.title} » d'une landing page de mariage premium. ${block.generation.prompt} ` +
          `Direction artistique élégante et cohérente, haute qualité.`,
      });
      setGenerated((p) => ({ ...p, [block.key]: res.url }));
    } catch (e) {
      setError(e?.response?.data?.error || e?.message || "La génération a échoué — réessayez.");
    } finally {
      setBusy(null);
    }
  };

  return (
    <div>
      <p className="mb-3 flex items-center gap-2 font-mono text-[9px] uppercase tracking-[0.26em] text-white/35">
        <LayoutTemplate className="h-3.5 w-3.5 text-accent" /> builder · les blocs dans l'ordre d'une landing
      </p>
      {error && <p className="mb-2 text-[11px] text-amber-300">{error}</p>}
      <div className="max-h-[360px] space-y-2 overflow-y-auto scrollbar-hide pr-1">
        {BUILDER_BLOCKS.map((b, i) => (
          <div key={b.key} className="rounded-xl border border-white/10 bg-white/[0.03] p-3">
            <div className="flex items-center justify-between gap-3">
              <p className="text-[12.5px] font-semibold text-white">
                <span className="mr-2 font-mono text-[9px] text-white/30">{String(i + 1).padStart(2, "0")}</span>
                {b.title}
              </p>
              <button
                type="button"
                onClick={() => generate(b)}
                disabled={busy === b.key}
                className="inline-flex shrink-0 items-center gap-1.5 rounded-full bg-accent/15 px-3 py-1.5 font-mono text-[9px] font-semibold uppercase tracking-[0.14em] text-accent transition hover:bg-accent/25 disabled:opacity-45"
              >
                {busy === b.key ? <Loader2 className="h-3 w-3 animate-spin" /> : <Sparkles className="h-3 w-3" />}
                Générer
              </button>
            </div>
            {generated[b.key] && (
              <img src={generated[b.key]} alt={`Visuel généré pour le bloc ${b.title}`} className="mt-2 w-full rounded-lg" />
            )}
          </div>
        ))}
      </div>
    </div>
  );
}