import { useEffect, useState } from "react";
import { Loader2, HeartHandshake, FileSignature, Stamp } from "lucide-react";
import ReactMarkdown from "react-markdown";
import { base44 } from "@/api/base44Client";

const TYPES = [
  { id: "union", label: "Union AI+ME", desc: "Se marier dans l'alignement" },
  { id: "separation", label: "Séparation bienveillante", desc: "Se quitter sans dégâts" },
  { id: "transmission", label: "Transmission", desc: "Pour la génération future" },
  { id: "travail", label: "Contrat de travail", desc: "Petit boulot · embauche claire" },
  { id: "travail_etranger", label: "Travail à l'étranger", desc: "L'agent guide chaque étape" },
];

const WORK_GUIDANCE = {
  travail:
    "C'est un accord de travail humain (petit boulot, mission, embauche) : préciser la mission réelle, " +
    "les horaires, la rémunération convenue, les conditions dignes, ce que chacun apporte et attend, " +
    "et rappeler en clair les démarches légales françaises à faire à côté (déclaration URSSAF/CESU si applicable).",
  travail_etranger:
    "C'est un accord de travail à l'étranger : inclure une section « L'agent vous guide » listant pas à pas " +
    "les vérifications nécessaires (visa/permis de travail, sécurité sociale, fiscalité, contrat local, assurance, " +
    "rapatriement) avec qui doit s'en occuper — employeur, travailleur ou partenaire local.",
};

// CONTRATS D'ALIGNEMENT — hors contrat civil : l'accord entre deux personnes,
// écrit dans la bienveillance, scellé par le timbre AI+ME horodaté.
export default function DeviceContracts() {
  const [contracts, setContracts] = useState([]);
  const [stamps, setStamps] = useState([]);
  const [form, setForm] = useState({ contract_type: "union", party_a_name: "", party_b_name: "", intentions: "" });
  const [busy, setBusy] = useState(false);
  const [open, setOpen] = useState(null); // contrat déplié

  useEffect(() => {
    base44.entities.AimeContract.list("-created_date", 20).then(setContracts).catch(() => {});
    base44.entities.AimeStamp.list("-created_date", 1).then(setStamps).catch(() => {});
  }, []);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));
  const typeMeta = TYPES.find((t) => t.id === form.contract_type);

  const [error, setError] = useState("");

  const generate = async () => {
    setBusy(true);
    setError("");
    try {
      const text = await base44.integrations.Core.InvokeLLM({
        prompt:
          `Rédige un « Contrat d'alignement AI+ME » de type ${typeMeta.label} entre ${form.party_a_name} et ${form.party_b_name}. ` +
          `Ce n'est PAS un contrat civil : c'est un accord d'alignement entre deux personnes, fondé sur la bienveillance, ` +
          `l'amour inconditionnel, la transparence totale (rien par omission), la justice réciproque et la meilleure transmission ` +
          `pour la génération future. ${WORK_GUIDANCE[form.contract_type] || ""} ` +
          `Intentions exprimées par les deux personnes : ${form.intentions || "non précisées — rester universel"}. ` +
          `Structure en markdown : préambule, articles courts et humains (engagements réciproques, parole, transmission, ` +
          `résolution des désaccords dans la douceur, clause de séparation digne), et une clause finale de scellement par timbre AI+ME horodaté. ` +
          `Ton digne, chaleureux, précis — jamais juridique à l'ancienne ni impersonnel. En français.`,
      });
      const created = await base44.entities.AimeContract.create({
        ...form,
        contract_text: text,
        stamp_id: stamps[0]?.id || "",
        sealed_at: new Date().toISOString(),
      });
      setContracts((c) => [created, ...c]);
      setForm({ contract_type: "union", party_a_name: "", party_b_name: "", intentions: "" });
      setOpen(created.id);
    } catch (e) {
      setError(e?.response?.data?.error || e?.message || "La génération a échoué — réessayez.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-4">
      <p className="flex items-center gap-2 font-mono text-[9px] uppercase tracking-[0.26em] text-white/35">
        <HeartHandshake className="h-3.5 w-3.5 text-accent" /> contrats d'alignement · scellés par timbre
      </p>

      <div className="rounded-2xl border border-white/10 bg-[#121212] p-4 space-y-2.5">
        <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-3">
          {TYPES.map((t) => (
            <button key={t.id} type="button" onClick={() => set("contract_type", t.id)}
              className={`rounded-xl p-2 text-left transition ${form.contract_type === t.id ? "bg-accent text-black" : "border border-white/12 bg-white/[0.03] text-white/70 hover:bg-white/[0.07]"}`}>
              <span className="block text-[10.5px] font-bold leading-tight">{t.label}</span>
              <span className={`block text-[8.5px] leading-tight ${form.contract_type === t.id ? "text-black/60" : "text-white/35"}`}>{t.desc}</span>
            </button>
          ))}
        </div>
        <div className="grid grid-cols-2 gap-2">
          <input value={form.party_a_name} onChange={(e) => set("party_a_name", e.target.value)} placeholder="Première personne"
            className="rounded-xl border border-white/12 bg-white/[0.04] px-3 py-2 text-[12px] text-white placeholder:text-white/30 focus:border-accent/50 focus:outline-none" />
          <input value={form.party_b_name} onChange={(e) => set("party_b_name", e.target.value)} placeholder="Deuxième personne"
            className="rounded-xl border border-white/12 bg-white/[0.04] px-3 py-2 text-[12px] text-white placeholder:text-white/30 focus:border-accent/50 focus:outline-none" />
        </div>
        <textarea value={form.intentions} onChange={(e) => set("intentions", e.target.value)} rows={2}
          placeholder="Vos intentions et accords à deux (facultatif)…"
          className="w-full rounded-xl border border-white/12 bg-white/[0.04] px-3 py-2 text-[12px] text-white placeholder:text-white/30 focus:border-accent/50 focus:outline-none" />
        {stamps.length === 0 && (
          <p className="text-[10.5px] text-amber-300">Créez d'abord votre timbre (mode Stamp) : c'est lui qui scelle le contrat.</p>
        )}
        {error && <p className="text-[10.5px] text-amber-300">{error}</p>}
        <button type="button" onClick={generate} disabled={busy || !form.party_a_name.trim() || !form.party_b_name.trim()}
          className="inline-flex w-full items-center justify-center gap-1.5 rounded-xl bg-accent px-3 py-2.5 text-[12px] font-bold text-black transition hover:brightness-110 disabled:opacity-45">
          {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <FileSignature className="h-4 w-4" />}
          {busy ? "Écriture du contrat…" : "Générer le contrat d'alignement"}
        </button>
      </div>

      {contracts.length > 0 && (
        <div className="space-y-2">
          {contracts.map((c) => (
            <div key={c.id} className="rounded-xl border border-white/10 bg-white/[0.03]">
              <button type="button" onClick={() => setOpen(open === c.id ? null : c.id)}
                className="flex w-full items-center justify-between gap-2 p-3 text-left">
                <span>
                  <span className="block text-[12px] font-semibold text-white">
                    {TYPES.find((t) => t.id === c.contract_type)?.label || c.contract_type} — {c.party_a_name} & {c.party_b_name}
                  </span>
                  <span className="flex items-center gap-1 font-mono text-[8.5px] text-emerald-400">
                    <Stamp className="h-2.5 w-2.5" /> scellé le {new Date(c.sealed_at || c.created_date).toLocaleString("fr-FR")}
                  </span>
                </span>
                <span className="text-white/40">{open === c.id ? "−" : "+"}</span>
              </button>
              {open === c.id && (
                <div className="border-t border-white/08 p-3">
                  <ReactMarkdown className="prose prose-invert prose-sm max-w-none text-[12px] leading-relaxed">
                    {c.contract_text || ""}
                  </ReactMarkdown>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}