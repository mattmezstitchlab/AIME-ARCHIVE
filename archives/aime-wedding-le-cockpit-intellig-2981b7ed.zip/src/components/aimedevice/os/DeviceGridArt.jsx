import { useState } from "react";
import { Eraser, Palette, Grid3x3 } from "lucide-react";

// COLORIAGE & BRODERIE — le même moteur de grille magnétique : on choisit une
// couleur, on remplit case par case. Un doigt suffit. À plusieurs, chacun sa zone.
const PALETTES = {
  coloriage: {
    icon: Palette,
    title: "coloriage · un doigt suffit · à plusieurs",
    colors: ["#F04FA0", "#F2E640", "#37D93B", "#2FA3E0", "#9C7BE0", "#E0632F", "#111111", "#FFFFFF"],
    labels: null,
  },
  broderie: {
    icon: Grid3x3,
    title: "broderie point de croix · fils DMC",
    colors: ["#B71C3A", "#1E4FA3", "#2E7D4F", "#E8C547", "#8C5A3C", "#E9E4DA", "#3A3A3A", "#D98BB6"],
    labels: ["DMC 321", "DMC 797", "DMC 367", "DMC 726", "DMC 433", "DMC 3865", "DMC 413", "DMC 3733"],
  },
};

const SIZE = 14;

export default function DeviceGridArt({ variant = "coloriage" }) {
  const conf = PALETTES[variant];
  const [color, setColor] = useState(conf.colors[0]);
  const [cells, setCells] = useState({}); // index → color
  const Icon = conf.icon;

  const paint = (i) => setCells((c) => ({ ...c, [i]: c[i] === color ? undefined : color }));

  return (
    <div>
      <p className="mb-3 flex items-center gap-2 font-mono text-[9px] uppercase tracking-[0.26em] text-white/35">
        <Icon className="h-3.5 w-3.5 text-accent" /> {conf.title}
      </p>

      {/* Palette */}
      <div className="mb-3 flex flex-wrap items-center gap-1.5">
        {conf.colors.map((c, k) => (
          <button key={c} type="button" onClick={() => setColor(c)}
            aria-label={conf.labels ? conf.labels[k] : `Couleur ${k + 1}`}
            title={conf.labels ? conf.labels[k] : undefined}
            className={`h-8 w-8 rounded-lg border-2 transition ${color === c ? "scale-110 border-accent" : "border-white/15"}`}
            style={{ backgroundColor: c }} />
        ))}
        <button type="button" onClick={() => setCells({})}
          className="ml-1 inline-flex h-8 items-center gap-1 rounded-lg border border-white/15 px-2.5 text-[10px] text-white/60 transition hover:bg-white/[0.08]">
          <Eraser className="h-3.5 w-3.5" /> Effacer
        </button>
      </div>
      {conf.labels && (
        <p className="mb-2 font-mono text-[8.5px] uppercase tracking-[0.14em] text-white/30">
          fil sélectionné : {conf.labels[conf.colors.indexOf(color)]}
        </p>
      )}

      {/* La grille magnétique */}
      <div className="grid gap-[2px] rounded-xl bg-white/10 p-[2px]" style={{ gridTemplateColumns: `repeat(${SIZE}, 1fr)` }}>
        {Array.from({ length: SIZE * SIZE }, (_, i) => (
          <button key={i} type="button" onClick={() => paint(i)}
            aria-label={`Case ${i + 1}`}
            className="aspect-square rounded-[2px] transition hover:opacity-80"
            style={{ backgroundColor: cells[i] || "#191919" }} />
        ))}
      </div>

      <p className="mt-2 text-center font-mono text-[8.5px] uppercase tracking-[0.18em] text-white/25">
        {variant === "broderie" ? "chaque case = un point de croix · le patron s'exporte bientôt" : "touchez une case pour la remplir · retouchez pour l'effacer"}
      </p>
    </div>
  );
}