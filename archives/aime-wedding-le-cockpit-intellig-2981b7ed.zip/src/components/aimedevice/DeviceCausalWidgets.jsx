// ─────────────────────────────────────────────────────────────────────────
// LES WIDGETS CAUSAUX — reproduction exacte du design de référence :
// cartes noires arrondies flottant sur le fond floral, points colorés,
// gros chiffres, barres segmentées et répartition. Contenu causal AIME.
// ─────────────────────────────────────────────────────────────────────────

const ACTIVITY = [
  { dot: "#22C55E", text: <>Scan AA <span className="text-emerald-400">réussi</span> sur la vitrine</>, time: "il y a 2 min" },
  { dot: "#3B82F6", text: <>Carte Traiteur reliée à <span className="rounded bg-white/10 px-1.5 py-0.5 font-mono text-[11px]">budget</span></>, time: "il y a 8 min" },
  { dot: "#F59E0B", text: <>Onde en attente — <span className="text-amber-400">invités</span></>, time: "il y a 12 min" },
  { dot: "#8B5CF6", text: <>Nouvelle réponse sur <span className="text-violet-400">Jour J</span></>, time: "il y a 25 min" },
];

export function WidgetActivity() {
  return (
    <div className="rounded-3xl bg-[#0B0B0C] p-6 shadow-2xl ring-1 ring-white/[0.06]">
      <div className="flex items-center justify-between">
        <p className="text-[15px] font-bold text-white">Activité causale</p>
        <p className="text-[13px] text-white/40">Live</p>
      </div>
      <ul className="mt-5 space-y-4">
        {ACTIVITY.map((a, i) => (
          <li key={i} className="flex items-start gap-3">
            <span className="mt-0.5 grid h-7 w-7 shrink-0 place-items-center rounded-full bg-white/[0.06]">
              <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: a.dot }} />
            </span>
            <div>
              <p className="text-[14px] leading-5 text-white">{a.text}</p>
              <p className="mt-1 text-[12px] text-white/35">{a.time}</p>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

export function WidgetHealth({ score = 96.4 }) {
  const segs = Array.from({ length: 13 }, (_, i) => (i === 6 ? "#F59E0B" : "#10B981"));
  return (
    <div className="rounded-3xl bg-[#0B0B0C] p-6 shadow-2xl ring-1 ring-white/[0.06]">
      <div className="flex items-center justify-between">
        <p className="text-[15px] font-bold text-white">Alignement</p>
        <span className="rounded-full bg-emerald-500/10 px-3 py-1 text-[12px] font-semibold text-emerald-400">Sain</span>
      </div>
      <p className="mt-4 font-heading text-5xl font-bold tracking-tight text-white">
        {score}<span className="text-2xl text-white/40">%</span>
      </p>
      <p className="mt-2 text-[13px] text-white/40">90 derniers jours</p>
      <div className="mt-4 flex gap-1">
        {segs.map((c, i) => (
          <span key={i} className="h-8 flex-1 rounded-md" style={{ backgroundColor: c }} />
        ))}
      </div>
      <div className="mt-4 grid grid-cols-3 gap-2">
        {[["42ms", "Propagation"], ["128", "Liens causals"], ["0", "Ruptures"]].map(([v, l]) => (
          <div key={l} className="rounded-2xl bg-white/[0.05] px-3 py-3 text-center">
            <p className="text-[15px] font-bold text-white">{v}</p>
            <p className="mt-0.5 text-[11px] text-white/40">{l}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

const SPEND = [
  { c: "#FFFFFF", label: "Traiteur", value: "1 926 €", pct: 45 },
  { c: "#9CA3AF", label: "Lieu", value: "1 198 €", pct: 28 },
  { c: "#6B7280", label: "Photo", value: "728 €", pct: 17 },
  { c: "#4B5563", label: "Autres", value: "428 €", pct: 10 },
];

export function WidgetSpend() {
  return (
    <div className="rounded-3xl bg-[#0B0B0C] p-6 shadow-2xl ring-1 ring-white/[0.06]">
      <div className="flex items-center justify-between">
        <p className="text-[15px] font-bold text-white">Dépenses du mois</p>
        <p className="text-[13px] text-white/40">Juil 2026</p>
      </div>
      <p className="mt-3 font-heading text-4xl font-bold tracking-tight text-white">
        4 280 € <span className="text-[14px] font-semibold text-emerald-400">-12%</span>
      </p>
      <div className="mt-5 flex h-3 overflow-hidden rounded-full bg-white/[0.08]">
        {SPEND.map((s) => (
          <span key={s.label} style={{ width: `${s.pct}%`, backgroundColor: s.c }} />
        ))}
      </div>
      <ul className="mt-5 space-y-3.5">
        {SPEND.map((s) => (
          <li key={s.label} className="flex items-center justify-between">
            <span className="flex items-center gap-2.5 text-[14px] text-white/60">
              <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: s.c }} />
              {s.label}
            </span>
            <span className="text-[14px] font-bold text-white">{s.value}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}