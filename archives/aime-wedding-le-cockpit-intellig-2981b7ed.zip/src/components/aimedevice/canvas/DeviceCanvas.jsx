import { useState, useRef, useEffect } from "react";
import { ZoomIn, ZoomOut, Maximize2 } from "lucide-react";
import DeviceDossiers from "@/components/aimedevice/DeviceDossiers";
import DeviceAgentChat from "@/components/aimedevice/DeviceAgentChat";
import DeviceOS from "@/components/aimedevice/os/DeviceOS";
import { SiteCard, ScanCard, OeilCard } from "@/components/aimedevice/canvas/CanvasCards";

// ─────────────────────────────────────────────────────────────────────────
// LE CANEVAS ZOOM INFINI — l'écran du device n'a plus d'onglets : tous les
// workspaces vivent sur une surface continue. On glisse pour se déplacer,
// on zoome à la molette, et la barre d'outils VOLE vers le bon workspace.
// ─────────────────────────────────────────────────────────────────────────
const CARDS = [
  { id: "site", label: "workspace 01 · projection", x: 40, y: 40, w: 520 },
  { id: "scan", label: "workspace 02 · scan wcag aa", x: 620, y: 40, w: 380 },
  { id: "oeil", label: "workspace 03 · l'œil", x: 620, y: 430, w: 380 },
  { id: "dossiers", label: "workspace 04 · dossiers absorbés", x: 40, y: 480, w: 520 },
  { id: "agents", label: "workspace 05 · super-agent", x: 1060, y: 40, w: 440 },
  { id: "os", label: "workspace 06 · bureau ai+me", x: 1060, y: 480, w: 520 },
];

const VIEW_H = 380;

export default function DeviceCanvas({ url, scan, absorbed, vision, focus }) {
  const wrapRef = useRef(null);
  const drag = useRef(null);
  const [view, setView] = useState({ x: 20, y: 20, k: 0.55 });
  const [smooth, setSmooth] = useState(false);

  // La barre d'outils pilote le vol vers un workspace.
  useEffect(() => {
    if (!focus) return;
    const card = CARDS.find((c) => c.id === focus);
    if (!card || !wrapRef.current) return;
    const vw = wrapRef.current.clientWidth;
    const k = Math.min(1, (vw - 60) / card.w);
    setSmooth(true);
    setView({ k, x: vw / 2 - (card.x + card.w / 2) * k, y: 24 - card.y * k });
    const t = setTimeout(() => setSmooth(false), 650);
    return () => clearTimeout(t);
  }, [focus]);

  // Zoom molette, centré sur le curseur (listener non-passif requis).
  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const onWheel = (e) => {
      e.preventDefault();
      const rect = el.getBoundingClientRect();
      const mx = e.clientX - rect.left, my = e.clientY - rect.top;
      setView((v) => {
        const k = Math.min(2.2, Math.max(0.2, v.k * (e.deltaY > 0 ? 0.92 : 1.08)));
        return { k, x: mx - ((mx - v.x) / v.k) * k, y: my - ((my - v.y) / v.k) * k };
      });
    };
    el.addEventListener("wheel", onWheel, { passive: false });
    return () => el.removeEventListener("wheel", onWheel);
  }, []);

  const onPointerDown = (e) => {
    drag.current = { sx: e.clientX, sy: e.clientY, ox: view.x, oy: view.y };
    e.currentTarget.setPointerCapture(e.pointerId);
  };
  const onPointerMove = (e) => {
    if (!drag.current) return;
    setView((v) => ({ ...v, x: drag.current.ox + e.clientX - drag.current.sx, y: drag.current.oy + e.clientY - drag.current.sy }));
  };
  const onPointerUp = () => { drag.current = null; };

  const zoomBtn = (f) => setView((v) => {
    const vw = wrapRef.current?.clientWidth || 600;
    const k = Math.min(2.2, Math.max(0.2, v.k * f));
    return { k, x: vw / 2 - ((vw / 2 - v.x) / v.k) * k, y: VIEW_H / 2 - ((VIEW_H / 2 - v.y) / v.k) * k };
  });
  const fitAll = () => {
    setSmooth(true);
    setView({ x: 20, y: 20, k: 0.34 });
    setTimeout(() => setSmooth(false), 650);
  };

  return (
    <div
      ref={wrapRef}
      className="relative mt-3 cursor-grab touch-none overflow-hidden rounded-2xl border border-white/10 bg-[#101010] dot-grid-dark active:cursor-grabbing"
      style={{ height: VIEW_H }}
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
    >
      {/* La surface infinie */}
      <div
        className="absolute left-0 top-0 origin-top-left"
        style={{ transform: `translate(${view.x}px, ${view.y}px) scale(${view.k})`, transition: smooth ? "transform 0.6s cubic-bezier(0.22,1,0.36,1)" : "none" }}
      >
        {CARDS.map((c) => (
          <div key={c.id} className="absolute" style={{ left: c.x, top: c.y, width: c.w }}>
            <p className="mb-1.5 inline-block rounded-md bg-black/60 px-2 py-1 font-mono text-[9px] uppercase tracking-[0.22em] text-white/50 backdrop-blur">
              {c.label}
            </p>
            <div
              className={`overflow-hidden rounded-2xl border bg-[#141414] shadow-2xl ${focus === c.id ? "border-accent/60" : "border-white/10"}`}
              onPointerDown={(e) => e.stopPropagation()}
            >
              {c.id === "site" && <SiteCard url={url} />}
              {c.id === "scan" && <ScanCard scan={scan} />}
              {c.id === "oeil" && <OeilCard vision={vision} />}
              {c.id === "dossiers" && <DeviceDossiers absorbed={absorbed} />}
              {c.id === "agents" && <DeviceAgentChat url={url} scan={scan} vision={vision} />}
              {c.id === "os" && <DeviceOS />}
            </div>
          </div>
        ))}
      </div>

      {/* Commandes de zoom — sobres, en bas à droite */}
      <div className="absolute bottom-2.5 right-2.5 flex gap-1" onPointerDown={(e) => e.stopPropagation()}>
        <button type="button" onClick={() => zoomBtn(1.25)} aria-label="Zoomer"
          className="grid h-8 w-8 place-items-center rounded-lg border border-white/15 bg-black/60 text-white/70 backdrop-blur transition hover:text-white">
          <ZoomIn className="h-4 w-4" />
        </button>
        <button type="button" onClick={() => zoomBtn(0.8)} aria-label="Dézoomer"
          className="grid h-8 w-8 place-items-center rounded-lg border border-white/15 bg-black/60 text-white/70 backdrop-blur transition hover:text-white">
          <ZoomOut className="h-4 w-4" />
        </button>
        <button type="button" onClick={fitAll} aria-label="Vue d'ensemble"
          className="grid h-8 w-8 place-items-center rounded-lg border border-white/15 bg-black/60 text-white/70 backdrop-blur transition hover:text-white">
          <Maximize2 className="h-4 w-4" />
        </button>
      </div>

      <p className="pointer-events-none absolute bottom-3 left-3 font-mono text-[8px] uppercase tracking-[0.24em] text-white/25">
        canevas · glisser pour naviguer · molette pour zoomer
      </p>
    </div>
  );
}