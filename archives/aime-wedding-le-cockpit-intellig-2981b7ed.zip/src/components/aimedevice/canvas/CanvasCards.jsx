import { Loader2, AlertTriangle } from "lucide-react";

const SEV = { critique: "text-red-300", attention: "text-amber-300", ok: "text-emerald-300" };

// Les contenus des workspaces du canevas — projection, scan, œil.
export function SiteCard({ url }) {
  if (!url) {
    return (
      <p className="p-6 text-center font-mono text-[10px] uppercase tracking-[0.26em] text-white/30">
        écran en veille · collez une url
      </p>
    );
  }
  return (
    <div className="relative max-h-[340px] overflow-y-auto scrollbar-hide">
      <img
        src={`https://image.thum.io/get/width/1000/fullpage/${url}`}
        alt={`Projection complète du site ${url} — faites défiler`}
        className="w-full"
      />
    </div>
  );
}

export function ScanCard({ scan }) {
  return (
    <div className="p-4">
      {scan?.loading && <p className="flex items-center gap-2 text-[12px] text-white/50"><Loader2 className="h-4 w-4 animate-spin text-accent" /> Scan WCAG AA en cours…</p>}
      {scan?.error && <p className="flex items-center gap-2 text-[12px] text-amber-300"><AlertTriangle className="h-4 w-4" /> {scan.error}</p>}
      {scan?.data && (
        <>
          <p className="font-heading text-2xl font-semibold text-white">
            <span className={scan.data.score >= 80 ? "text-emerald-400" : scan.data.score >= 50 ? "text-amber-400" : "text-red-400"}>{scan.data.score}</span>
            <span className="text-white/35">/100</span>
          </p>
          <p className="mt-1 font-mono text-[9.5px] uppercase tracking-[0.2em] text-white/40">
            {scan.data.counts.blocks} zones · {scan.data.counts.faults} failles · {scan.data.counts.blocking} bloquantes
          </p>
          <ul className="mt-3 space-y-1.5">
            {scan.data.blocks.filter((b) => b.status !== "ok").slice(0, 5).map((b) => (
              <li key={b.id} className="rounded-lg bg-white/[0.04] px-3 py-2 text-[11.5px] text-white/65">
                <span className="font-semibold text-white">{b.label}</span> · {b.faults.length} faille{b.faults.length > 1 ? "s" : ""}
              </li>
            ))}
          </ul>
        </>
      )}
      {!scan && <p className="text-[12px] text-white/40">Ouvrez un site pour lancer le scan.</p>}
    </div>
  );
}

export function OeilCard({ vision }) {
  return (
    <div className="p-4">
      {vision?.loading && <p className="flex items-center gap-2 text-[12px] text-white/50"><Loader2 className="h-4 w-4 animate-spin text-accent" /> L'œil regarde la page…</p>}
      {vision?.error && <p className="text-[12px] text-amber-300">{vision.error}</p>}
      {vision?.data && (
        <>
          <p className="font-heading text-2xl font-semibold text-white">
            <span className="text-accent">{Math.round(vision.data.visual_score)}</span><span className="text-white/35">/100 visuel</span>
          </p>
          <ul className="mt-3 space-y-2">
            {(vision.data.observations || []).map((o, i) => (
              <li key={i} className="text-[11.5px] leading-snug text-white/65">
                <span className={`font-mono text-[9px] uppercase tracking-[0.14em] ${SEV[o.severity] || SEV.attention}`}>{o.theme}</span>
                {" — "}{o.verdict}
              </li>
            ))}
          </ul>
        </>
      )}
      {!vision && <p className="text-[12px] text-white/40">Lancez l'œil sur un site ouvert.</p>}
    </div>
  );
}