import { Accessibility, Heart, Landmark, HandHeart, Gem, Camera, UtensilsCrossed, Users, CalendarClock, Hand, Music, UsersRound, Castle } from "lucide-react";

// ─────────────────────────────────────────────────────────────────────────
// LA COLLECTION DE DEVICES — un device par RÔLE du mariage (même design,
// mémoire causale partagée), et plus bas les DEVICES SPÉCIAUX :
// Access (European Accessibility Act), LSA (Signes & Braille),
// Précarité (solidarité), Administratif.
// ─────────────────────────────────────────────────────────────────────────
export const DEVICE_THEMES = [
  // ── LES RÔLES DU MARIAGE ────────────────────────────────────────────
  { id: "couple", kind: "role", role: "Marié·e", label: "AI+ME Couple", cat: "Rôle · Les mariés", tagline: "Tout le mariage sous vos doigts — chaque geste ondule chez les autres", icon: Gem, accent: "#D4A5B5" },
  { id: "temoin", kind: "role", role: "Témoin", label: "AI+ME Témoin", cat: "Rôle · Témoin", tagline: "Coordonner, surprendre, épauler — en direct avec tous les rôles", icon: Heart, accent: "#C9B88F" },
  { id: "photographe", kind: "role", role: "Photographe", label: "AI+ME Photo", cat: "Rôle · Photographe", tagline: "Repérages, golden hour, livrables — branchés au planning vivant", icon: Camera, accent: "#8FA5B8" },
  { id: "traiteur", kind: "role", role: "Traiteur", label: "AI+ME Traiteur", cat: "Rôle · Traiteur", tagline: "Un invité change ? Menus et quantités se réalignent à la seconde", icon: UtensilsCrossed, accent: "#E2725B" },
  { id: "dj", kind: "role", role: "DJ", label: "AI+ME DJ", cat: "Rôle · DJ", tagline: "Moments musicaux et BPM branchés à l'orchestration du Jour J", icon: Music, accent: "#B48FE2" },
  { id: "coordinateur", kind: "role", role: "Coordinateur", label: "AI+ME Coordo", cat: "Rôle · Coordination", tagline: "La tour de contrôle : chaque onde des autres rôles passe par vous", icon: CalendarClock, accent: "#E2B65B" },
  { id: "invite", kind: "role", role: "Invité·e", label: "AI+ME Invité", cat: "Rôle · Invité", tagline: "Répondre, covoiturer, offrir — sans jamais déranger personne", icon: Users, accent: "#9CB89C" },
  { id: "famille", kind: "role", role: "Famille", label: "AI+ME Famille", cat: "Rôle · Famille", tagline: "Un rôle formalisé — fini les doublons et les infos contradictoires", icon: UsersRound, accent: "#C4A5D4" },
  { id: "lieu", kind: "role", role: "Lieu", label: "AI+ME Lieu", cat: "Rôle · Le lieu", tagline: "Capacité, accès, couvre-feu — la contrainte physique parle en direct", icon: Castle, accent: "#B8A98F" },

  // ── LES DEVICES SPÉCIAUX ────────────────────────────────────────────
  {
    id: "access",
    kind: "special",
    label: "AI+ME Access",
    cat: "Spécial · European Accessibility Act",
    tagline: "URL, builder, Scan WCAG AA, l'œil, réparation bloc par bloc — la réforme qui claque",
    icon: Accessibility,
    accent: "#C9B88F",
    apps: null,
  },
  {
    id: "lsa",
    kind: "special",
    label: "AI+ME LSA",
    cat: "Spécial · Signes & Braille",
    tagline: "Charcot, Langue des Signes, Braille, Vocal — un device qu'on enrichit sans fin",
    icon: Hand,
    accent: "#7FB8B0",
    apps: [],
  },
  {
    id: "precarite",
    kind: "special",
    label: "AI+ME Précarité",
    cat: "Spécial · Solidarité",
    tagline: "Circuits de dons, entraide et messagerie — orchestrés pour ceux qui en ont besoin",
    icon: HandHeart,
    accent: "#9CB89C",
    apps: ["dons", "messagerie"],
  },
  {
    id: "admin",
    kind: "special",
    label: "AI+ME Administratif",
    cat: "Spécial · Administratif",
    tagline: "Contrats alignés, timbres horodatés, messagerie IA, traduction",
    icon: Landmark,
    accent: "#8FA5B8",
    apps: ["contrats", "stamp", "messagerie", "langues"],
  },
];

const ACTIVE_KEY = "aime-device-active-theme";
const OWNED_KEY = "aime-device-owned-themes";

export function loadActiveTheme() {
  const id = localStorage.getItem(ACTIVE_KEY);
  return DEVICE_THEMES.find((t) => t.id === id) || DEVICE_THEMES[0];
}
export function saveActiveTheme(id) {
  localStorage.setItem(ACTIVE_KEY, id);
}
export function loadOwnedThemes() {
  try {
    const arr = JSON.parse(localStorage.getItem(OWNED_KEY));
    return Array.isArray(arr) && arr.length ? arr : ["couple", "access"];
  } catch {
    return ["couple", "access"];
  }
}
export function saveOwnedThemes(ids) {
  localStorage.setItem(OWNED_KEY, JSON.stringify(ids));
}