import { useState } from "react";
import { Globe, ShieldCheck, Eye, FolderOpen, Bot, Sparkles, Keyboard as KeyboardIcon, MonitorPlay, Settings } from "lucide-react";
import SmartKeyboard from "@/components/ripple/studio/SmartKeyboard";
import DeviceCanvas from "@/components/aimedevice/canvas/DeviceCanvas";

const TOOLS = [
  { id: "site", icon: MonitorPlay, label: "Projeter" },
  { id: "scan", icon: ShieldCheck, label: "Scan AA" },
  { id: "oeil", icon: Eye, label: "Œil" },
  { id: "dossiers", icon: FolderOpen, label: "Dossiers" },
  { id: "agents", icon: Bot, label: "Agents" },
  { id: "os", icon: Settings, label: "Paramètres" },
];

// RECTO — l'OS : champ URL en haut, écran pliable qui projette le site,
// barre d'outils directe, clavier d'accessibilité en dessous.
export default function DeviceRecto({ url, onLaunch, scan, absorbed, vision, onAbsorb, onOeil, tab, setTab }) {
  const [input, setInput] = useState(url);
  const [kbOpen, setKbOpen] = useState(false);

  const go = (e) => {
    e.preventDefault();
    if (input.trim()) onLaunch(input.trim());
  };

  return (
    <div>
      {/* Champ URL — ouvrir un site dans l'appareil */}
      <form onSubmit={go} className="flex gap-2">
        <div className="flex flex-1 items-center gap-2 rounded-xl border border-white/12 bg-white/[0.04] px-3 transition focus-within:border-accent/60">
          <Globe className="h-4 w-4 shrink-0 text-white/35" />
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Coller une URL — le site s'ouvre dans l'appareil"
            aria-label="URL du site à projeter"
            className="w-full bg-transparent py-2.5 text-[13px] text-white placeholder:text-white/30 focus:outline-none focus-visible:!shadow-none"
          />
        </div>
        <button type="submit" className="rounded-xl bg-white px-4 py-2 text-[12.5px] font-semibold text-black transition hover:bg-white/90">
          Ouvrir
        </button>
      </form>

      {/* Barre d'outils directe */}
      <div className="mt-3 flex flex-wrap gap-1.5">
        {TOOLS.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => {
              if (t.id === "oeil" && url && !vision) onOeil();
              else if (t.id === "dossiers" && url && !absorbed) onAbsorb();
              setTab(t.id);
            }}
            disabled={!url && t.id !== "agents" && t.id !== "os"}
            className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 font-mono text-[9.5px] font-semibold uppercase tracking-[0.16em] transition disabled:opacity-35 ${
              tab === t.id ? "bg-accent text-black" : "border border-white/12 text-white/60 hover:border-white/35 hover:text-white"
            }`}
          >
            <t.icon className="h-3.5 w-3.5" /> {t.label}
          </button>
        ))}
        {url && !absorbed && (
          <button type="button" onClick={onAbsorb}
            className="inline-flex items-center gap-1.5 rounded-full bg-fire/15 px-3 py-1.5 font-mono text-[9.5px] font-semibold uppercase tracking-[0.16em] text-fire transition hover:bg-fire/25">
            <Sparkles className="h-3.5 w-3.5" /> Absorber
          </button>
        )}
      </div>

      {/* L'écran-canevas zoom infini — tous les workspaces sur une surface continue */}
      <DeviceCanvas focus={tab} url={url} scan={scan} absorbed={absorbed} vision={vision} />

      {/* Le clavier physique */}
      <button
        type="button"
        onClick={() => setKbOpen((o) => !o)}
        className="mt-4 inline-flex items-center gap-2 font-mono text-[9.5px] font-semibold uppercase tracking-[0.24em] text-white/45 transition hover:text-white"
      >
        <KeyboardIcon className="h-4 w-4 text-accent" /> Clavier d'accessibilité {kbOpen ? "· replier" : "· déplier"}
      </button>
      {kbOpen && (
        <div className="mt-2">
          <SmartKeyboard onAction={() => {}} />
        </div>
      )}
    </div>
  );
}