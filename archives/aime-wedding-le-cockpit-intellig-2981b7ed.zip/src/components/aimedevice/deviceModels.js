// LES MODÈLES DE L'APPAREIL AI+ME — comme des coloris de hardware :
// le châssis change, l'écran reste noir studio. Choix mémorisé localement.
export const DEVICE_MODELS = [
  {
    id: "noir",
    label: "Noir Studio",
    frame: "#0E0E0E",
    edge: "rgba(255,255,255,0.14)",
    plaque: "linear-gradient(to bottom, #1e1e1e, #121212, #0a0a0a)",
    plaqueText: "rgba(255,255,255,0.8)",
    dot: "#1f1f1f",
  },
  {
    id: "ivoire",
    label: "Ivoire",
    frame: "#191713",
    edge: "rgba(201,184,143,0.5)",
    plaque: "linear-gradient(to bottom, #f3efe6, #e3dcc9, #c2b698)",
    plaqueText: "#161310",
    dot: "#E8E2D2",
  },
  {
    id: "cuivre",
    label: "Cuivre",
    frame: "#170f09",
    edge: "rgba(224,140,80,0.45)",
    plaque: "linear-gradient(to bottom, #8a5a34, #5d3a20, #2e1c10)",
    plaqueText: "rgba(255,240,225,0.9)",
    dot: "#B06A3B",
  },
  {
    id: "ocean",
    label: "Océan",
    frame: "#0a0e18",
    edge: "rgba(90,130,220,0.45)",
    plaque: "linear-gradient(to bottom, #1b2a4a, #101a30, #080d18)",
    plaqueText: "rgba(220,232,255,0.85)",
    dot: "#2C4A8A",
  },
];

const KEY = "aime-device-model";

export function loadDeviceModel() {
  const id = localStorage.getItem(KEY);
  return DEVICE_MODELS.find((m) => m.id === id) || DEVICE_MODELS[0];
}

export function saveDeviceModel(id) {
  localStorage.setItem(KEY, id);
}