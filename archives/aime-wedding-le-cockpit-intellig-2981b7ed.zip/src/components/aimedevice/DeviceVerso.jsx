import { useState } from "react";
import { Volume2, Trash2, Accessibility, Hand, CircleDot, Mic } from "lucide-react";
import VersoCharcot from "@/components/aimedevice/verso/VersoCharcot";
import VersoSignes from "@/components/aimedevice/verso/VersoSignes";
import VersoBraille from "@/components/aimedevice/verso/VersoBraille";
import VersoVocal from "@/components/aimedevice/verso/VersoVocal";

const MODES = [
  { id: "charcot", icon: Accessibility, label: "Charcot / SLA" },
  { id: "signes", icon: Hand, label: "Signes" },
  { id: "braille", icon: CircleDot, label: "Braille" },
  { id: "vocal", icon: Mic, label: "Vocal" },
];

// VERSO — les 4 modes de communication. Chacun compose la même phrase,
// qu'on peut faire lire à voix haute (vraie voix du navigateur).
export default function DeviceVerso() {
  const [mode, setMode] = useState("charcot");
  const [text, setText] = useState("");

  const append = (s) => setText((t) => t + s);
  const backspace = () => setText((t) => t.slice(0, -1));
  const speak = () => {
    if (!text) return;
    const u = new SpeechSynthesisUtterance(text);
    u.lang = "fr-FR";
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(u);
  };

  return (
    <div>
      {/* Sélecteur de mode */}
      <div className="flex flex-wrap gap-1.5" role="tablist" aria-label="Modes de communication">
        {MODES.map((m) => (
          <button
            key={m.id}
            type="button"
            role="tab"
            aria-selected={mode === m.id}
            onClick={() => setMode(m.id)}
            className={`inline-flex items-center gap-1.5 rounded-full px-3.5 py-2 font-mono text-[9.5px] font-semibold uppercase tracking-[0.16em] transition ${
              mode === m.id ? "bg-accent text-black" : "border border-white/12 text-white/60 hover:border-white/35 hover:text-white"
            }`}
          >
            <m.icon className="h-3.5 w-3.5" /> {m.label}
          </button>
        ))}
      </div>

      {/* La phrase composée — commune à tous les modes */}
      <div className="mt-3 flex items-center gap-2 rounded-2xl border border-white/12 bg-white/[0.04] p-3">
        <p className="min-h-[28px] flex-1 text-[16px] leading-snug text-white" aria-live="polite">
          {text || <span className="text-white/30">La phrase composée apparaît ici…</span>}
        </p>
        <button type="button" onClick={speak} disabled={!text} aria-label="Lire la phrase à voix haute"
          className="rounded-xl bg-accent p-2.5 text-black transition hover:brightness-110 disabled:opacity-35">
          <Volume2 className="h-4 w-4" />
        </button>
        <button type="button" onClick={() => setText("")} disabled={!text} aria-label="Effacer la phrase"
          className="rounded-xl border border-white/15 p-2.5 text-white/60 transition hover:text-white disabled:opacity-35">
          <Trash2 className="h-4 w-4" />
        </button>
      </div>

      <div className="mt-3">
        {mode === "charcot" && <VersoCharcot onAppend={append} onBackspace={backspace} />}
        {mode === "signes" && <VersoSignes onAppend={append} onBackspace={backspace} />}
        {mode === "braille" && <VersoBraille onAppend={append} onBackspace={backspace} />}
        {mode === "vocal" && <VersoVocal onAppend={append} />}
      </div>
    </div>
  );
}