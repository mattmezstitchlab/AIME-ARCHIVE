import { useState } from "react";
import { X, RefreshCcw, ChevronsDownUp } from "lucide-react";
import { base44 } from "@/api/base44Client";
import DeviceRecto from "@/components/aimedevice/DeviceRecto";
import DeviceVerso from "@/components/aimedevice/DeviceVerso";
import DeviceGrille from "@/components/aimedevice/grille/DeviceGrille";
import DeviceThemeApps from "@/components/aimedevice/DeviceThemeApps";
import DeviceRoleScreen from "@/components/aimedevice/role/DeviceRoleScreen";
import DeviceAimeBar from "@/components/aimedevice/DeviceAimeBar";
import DeviceSwitcher from "@/components/aimedevice/DeviceSwitcher";
import DeviceAgentChat from "@/components/aimedevice/DeviceAgentChat";
import DeviceProfile from "@/components/aimedevice/os/DeviceProfile";
import { DEVICE_MODELS, loadDeviceModel, saveDeviceModel } from "@/components/aimedevice/deviceModels";
import { DEVICE_THEMES, loadActiveTheme, saveActiveTheme, loadOwnedThemes, saveOwnedThemes } from "@/components/aimedevice/deviceThemes";

const FACES = ["recto", "verso", "grille"];
const FACE_LABELS = { recto: "OS causal", verso: "Communication", grille: "Grille universelle" };

// ═══════════════════════════════════════════════════════════════════════════
// AIME® AI+ME — l'appareil embarquable universel, désormais en COLLECTION :
// chaque device est spécialisé (Access, Music, Wedding, Admin, Caritatif).
// En bas, la barre signature : AI (super-agent) · + (mes devices) · ME (moi).
// ═══════════════════════════════════════════════════════════════════════════
export default function AimeDeviceOverlay({ onClose }) {
  const [folded, setFolded] = useState(true);
  const [face, setFace] = useState("recto");
  const [model, setModel] = useState(loadDeviceModel);
  const [theme, setTheme] = useState(loadActiveTheme);
  const [owned, setOwned] = useState(loadOwnedThemes);
  const [panel, setPanel] = useState(null); // null | "ai" | "me"
  const [switcherOpen, setSwitcherOpen] = useState(false);
  const pickModel = (m) => { setModel(m); saveDeviceModel(m.id); };

  const pickTheme = (id) => {
    const t = DEVICE_THEMES.find((x) => x.id === id);
    if (!t) return;
    setTheme(t); saveActiveTheme(id);
    setPanel(null); setFace("recto"); setSwitcherOpen(false);
  };
  const acquireTheme = (id) => {
    const next = [...new Set([...owned, id])];
    setOwned(next); saveOwnedThemes(next);
    pickTheme(id);
  };

  // État partagé du recto Access (le site projeté)
  const [url, setUrl] = useState("");
  const [scan, setScan] = useState(null);
  const [absorbed, setAbsorbed] = useState(null);
  const [vision, setVision] = useState(null);
  const [tab, setTab] = useState("site");

  const launch = async (u) => {
    setUrl(u);
    setScan({ loading: true });
    setAbsorbed(null);
    setVision(null);
    setTab("site");
    try {
      const { data } = await base44.functions.invoke("scanA11yFaults", { url: u });
      setScan(data?.error ? { error: data.error } : { data });
    } catch {
      setScan({ error: "Scan impossible sur ce site." });
    }
  };

  const absorb = async () => {
    setAbsorbed({ loading: true });
    setTab("dossiers");
    try {
      const [c, k] = await Promise.all([
        base44.functions.invoke("extractSiteContent", { url }),
        base44.functions.invoke("extractSiteColors", { url }),
      ]);
      if (c.data?.error) setAbsorbed({ error: c.data.error });
      else setAbsorbed({ content: c.data, colors: k.data?.colors || [] });
    } catch {
      setAbsorbed({ error: "Absorption impossible." });
    }
  };

  const oeil = async () => {
    setVision({ loading: true });
    setTab("oeil");
    try {
      const data = await base44.integrations.Core.InvokeLLM({
        prompt: `Expert en design accessible (WCAG AA) : audite visuellement cette capture de ${url} — hiérarchie, contrastes perçus, densité, cibles tactiles. Score sur 100 + 4-5 observations courtes en français (severity: ok | attention | critique).`,
        file_urls: [`https://image.thum.io/get/width/900/crop/1200/${url}`],
        response_json_schema: {
          type: "object",
          properties: {
            visual_score: { type: "number" },
            observations: { type: "array", items: { type: "object", properties: { theme: { type: "string" }, verdict: { type: "string" }, severity: { type: "string" } } } },
          },
          required: ["visual_score", "observations"],
        },
      });
      setVision({ data });
    } catch {
      setVision({ error: "L'œil n'a pas pu regarder cette page." });
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-end justify-center bg-black/70 p-3 backdrop-blur-sm sm:items-center" onClick={onClose}>
      {/* Mode PLIÉ — la plaque gravée */}
      {folded ? (
        <button
          type="button"
          onClick={(e) => { e.stopPropagation(); setFolded(false); }}
          className="rounded-[2rem] border px-16 py-14 shadow-2xl transition hover:scale-[1.02]"
          style={{ background: model.plaque, borderColor: model.edge }}
          aria-label="Déplier l'appareil AIME"
        >
          <span className="block text-center font-heading text-4xl font-bold tracking-[0.06em]" style={{ color: model.plaqueText, textShadow: "0 1px 0 rgba(255,255,255,0.08), 0 -1px 2px rgba(0,0,0,0.4)" }}>
            AIME®
          </span>
          <span className="mt-2 block text-center font-mono text-[11px] uppercase tracking-[0.5em]" style={{ color: theme.accent }}>
            {theme.label.replace("AI+ME", "AI+ME ·")}
          </span>
          <span className="mt-5 block text-center font-mono text-[9px] uppercase tracking-[0.3em]" style={{ color: model.plaqueText, opacity: 0.45 }}>toucher pour déplier</span>
        </button>
      ) : (
        <div
          className="relative flex max-h-[92vh] w-full max-w-3xl flex-col overflow-hidden rounded-[1.6rem] border shadow-2xl"
          style={{ backgroundColor: model.frame, borderColor: model.edge, boxShadow: `0 0 0 3px ${model.edge}, 0 25px 60px rgba(0,0,0,0.6)` }}
          onClick={(e) => e.stopPropagation()}
        >
          {/* Tranche de l'appareil */}
          <div className="flex items-center justify-between border-b border-white/[0.07] px-4 py-2.5">
            <p className="font-mono text-[9.5px] uppercase tracking-[0.34em] text-white/45">
              <span style={{ color: theme.accent }}>{theme.label}</span> · {panel === "ai" ? "Super-agent" : panel === "me" ? "Identité" : FACE_LABELS[face]}
            </p>
            <div className="flex items-center gap-1.5">
              {/* Choix du modèle — les coloris du châssis */}
              <span className="mr-1 flex items-center gap-1" role="radiogroup" aria-label="Modèle de l'appareil">
                {DEVICE_MODELS.map((m) => (
                  <button key={m.id} type="button" role="radio" aria-checked={model.id === m.id}
                    aria-label={`Modèle ${m.label}`} title={m.label}
                    onClick={() => pickModel(m)}
                    className={`h-4 w-4 rounded-full border transition ${model.id === m.id ? "scale-125 border-accent" : "border-white/25 hover:scale-110"}`}
                    style={{ backgroundColor: m.dot }} />
                ))}
              </span>
              <button type="button" onClick={() => { setPanel(null); setFace(FACES[(FACES.indexOf(face) + 1) % FACES.length]); }}
                className="inline-flex items-center gap-1.5 rounded-full border border-accent/40 bg-accent/10 px-3 py-1.5 font-mono text-[9.5px] font-semibold uppercase tracking-[0.18em] text-accent transition hover:bg-accent/20">
                <RefreshCcw className="h-3 w-3" /> Retourner
              </button>
              <button type="button" onClick={() => setFolded(true)} aria-label="Replier"
                className="rounded-full p-2 text-white/45 transition hover:bg-white/10 hover:text-white">
                <ChevronsDownUp className="h-4 w-4" />
              </button>
              <button type="button" onClick={onClose} aria-label="Fermer"
                className="rounded-full p-2 text-white/45 transition hover:bg-white/10 hover:text-white">
                <X className="h-4 w-4" />
              </button>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto scrollbar-hide bg-[#0E0E0E] p-4">
            {panel === "ai" ? (
              <DeviceAgentChat url={url} scan={scan} vision={vision} />
            ) : panel === "me" ? (
              <DeviceProfile />
            ) : face === "recto" ? (
              theme.kind === "role" ? (
                <DeviceRoleScreen theme={theme} />
              ) : theme.id === "lsa" ? (
                <DeviceVerso />
              ) : theme.apps === null ? (
                <DeviceRecto
                  url={url} onLaunch={launch}
                  scan={scan} absorbed={absorbed} vision={vision}
                  onAbsorb={absorb} onOeil={oeil}
                  tab={tab} setTab={setTab}
                />
              ) : (
                <DeviceThemeApps theme={theme} />
              )
            ) : face === "verso" ? (
              <DeviceVerso />
            ) : (
              <DeviceGrille />
            )}
          </div>

          {/* La barre signature : AI + ME */}
          <DeviceAimeBar
            panel={panel}
            accent={theme.accent}
            onAi={() => setPanel(panel === "ai" ? null : "ai")}
            onMe={() => setPanel(panel === "me" ? null : "me")}
            onPlus={() => setSwitcherOpen(true)}
          />

          {/* Le catalogue de devices — style landing */}
          {switcherOpen && (
            <DeviceSwitcher
              owned={owned}
              activeId={theme.id}
              onPick={pickTheme}
              onAcquire={acquireTheme}
              onClose={() => setSwitcherOpen(false)}
            />
          )}
        </div>
      )}
    </div>
  );
}