import { X, Check, Plus } from "lucide-react";
import { DEVICE_THEMES } from "@/components/aimedevice/deviceThemes";

// LE CATALOGUE DE DEVICES — le "+" central. Style landing : fond clair,
// trame de points, labels mono. On active un device possédé, on se
// procure les autres par thématique.
export default function DeviceSwitcher({ owned, activeId, onPick, onAcquire, onClose }) {
  return (
    <div className="absolute inset-0 z-20 overflow-y-auto scrollbar-hide bg-[#F7F6F2] dot-grid-light p-5 text-[#111]">
      <div className="mb-5 flex items-start justify-between">
        <div>
          <p className="font-mono text-[9px] font-semibold uppercase tracking-[0.3em] text-black/40">
            ai <span className="text-black">+</span> me · mes devices
          </p>
          <h3 className="mt-1 font-heading text-2xl font-semibold tracking-[-0.01em]">
            Un device par univers.
          </h3>
          <p className="mt-1 text-[12.5px] text-black/50">
            Procurez-vous des devices par thématique — chacun embarque ses applis, prêt à l'emploi.
          </p>
        </div>
        <button type="button" onClick={onClose} aria-label="Fermer le catalogue"
          className="rounded-full p-2 text-black/45 transition hover:bg-black/5 hover:text-black">
          <X className="h-4 w-4" />
        </button>
      </div>

      {[
        ["Rôles du mariage — le même mariage, un device chacun", DEVICE_THEMES.filter((t) => t.kind === "role")],
        ["Devices spéciaux — Access, LSA, Précarité, Administratif", DEVICE_THEMES.filter((t) => t.kind !== "role")],
      ].map(([section, themes]) => (
        <div key={section} className="mb-6">
          <p className="mb-2.5 font-mono text-[9px] font-semibold uppercase tracking-[0.26em] text-black/40">{section}</p>
          <div className="grid gap-3 sm:grid-cols-2">
            {themes.map((t) => {
          const isOwned = owned.includes(t.id);
          const isActive = t.id === activeId;
          return (
            <div key={t.id}
              className={`rounded-2xl border bg-white p-4 transition ${isActive ? "border-black shadow-md" : "border-black/10 hover:border-black/30"}`}>
              <div className="flex items-center gap-3">
                <span className="grid h-10 w-10 place-items-center rounded-xl" style={{ backgroundColor: `${t.accent}33` }}>
                  <t.icon className="h-5 w-5" style={{ color: t.accent }} strokeWidth={1.8} />
                </span>
                <div className="min-w-0">
                  <p className="font-mono text-[8.5px] font-semibold uppercase tracking-[0.24em] text-black/40">{t.cat}</p>
                  <p className="truncate font-heading text-[15px] font-semibold">{t.label}</p>
                </div>
              </div>
              <p className="mt-2.5 text-[12px] leading-5 text-black/55">{t.tagline}</p>
              <div className="mt-3">
                {isActive ? (
                  <span className="inline-flex items-center gap-1.5 rounded-full bg-black px-3 py-1.5 font-mono text-[9px] font-semibold uppercase tracking-[0.2em] text-white">
                    <Check className="h-3 w-3" /> Actif
                  </span>
                ) : isOwned ? (
                  <button type="button" onClick={() => onPick(t.id)}
                    className="rounded-full border border-black/20 px-3 py-1.5 font-mono text-[9px] font-semibold uppercase tracking-[0.2em] text-black transition hover:bg-black hover:text-white">
                    Basculer
                  </button>
                ) : (
                  <button type="button" onClick={() => onAcquire(t.id)}
                    className="inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 font-mono text-[9px] font-semibold uppercase tracking-[0.2em] text-black transition hover:opacity-80"
                    style={{ backgroundColor: t.accent }}>
                    <Plus className="h-3 w-3" /> Me le procurer
                  </button>
                )}
              </div>
            </div>
          );
            })}
          </div>
        </div>
      ))}
    </div>
  );
}