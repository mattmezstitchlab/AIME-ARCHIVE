import { useState } from "react";
import { PICTO_KEYS, JOURJ_KEYS } from "@/components/aimedevice/role/roleKeys";

// LE CLAVIER PHYSIQUE À PICTOS — des vraies touches, comme le clavier
// d'accessibilité. Mode Jour J : les touches deviennent des horaires.
export default function DeviceRoleKeyboard({ accent, onKey, jourj, setJourj }) {
  const [pressed, setPressed] = useState(null);
  const keys = jourj ? JOURJ_KEYS : PICTO_KEYS;

  const press = (k) => {
    setPressed(k.id);
    setTimeout(() => setPressed(null), 220);
    onKey(k);
  };

  return (
    <div className="rounded-2xl border border-white/10 bg-[#141414] p-3 shadow-2xl">
      <div className="mb-2.5 flex items-center justify-between">
        <p className="font-mono text-[8.5px] uppercase tracking-[0.28em] text-white/40">
          clavier {jourj ? "· orchestration jour j" : "· dossiers du rôle"}
        </p>
        <button
          type="button"
          onClick={() => setJourj(!jourj)}
          className={`rounded-full px-3 py-1 font-mono text-[8.5px] font-semibold uppercase tracking-[0.2em] transition ${
            jourj ? "text-black" : "border border-white/15 text-white/55 hover:text-white"
          }`}
          style={jourj ? { backgroundColor: accent } : undefined}
        >
          Jour J
        </button>
      </div>

      <div className={`grid gap-1.5 ${jourj ? "grid-cols-4" : "grid-cols-4 sm:grid-cols-6"}`}>
        {keys.map((k) => (
          <button
            key={k.id}
            type="button"
            onClick={() => press(k)}
            aria-label={jourj ? `${k.time} — ${k.label}` : k.label}
            className={`flex flex-col items-center justify-center gap-1 rounded-lg border border-white/[0.08] bg-gradient-to-b from-white/[0.09] to-white/[0.03] px-1 py-2.5 shadow-[0_3px_0_rgba(0,0,0,0.5)] transition active:translate-y-[2px] active:shadow-none ${
              pressed === k.id ? "translate-y-[2px] shadow-none" : ""
            }`}
            style={pressed === k.id ? { borderColor: accent } : undefined}
          >
            {jourj ? (
              <>
                <span className="font-mono text-[13px] font-bold tracking-tight" style={{ color: accent }}>{k.time}</span>
                <span className="max-w-full truncate text-[9px] font-semibold text-white/75">{k.label}</span>
              </>
            ) : (
              <>
                <k.icon className="h-5 w-5" style={{ color: accent }} strokeWidth={1.7} />
                <span className="max-w-full truncate text-[9px] font-semibold text-white/75">{k.label}</span>
              </>
            )}
          </button>
        ))}
      </div>
    </div>
  );
}