import { useState, useEffect } from "react";
import { X } from "lucide-react";
import { base44 } from "@/api/base44Client";
import DeviceRoleKeyboard from "@/components/aimedevice/role/DeviceRoleKeyboard";

const FLORAL_BG = "https://media.base44.com/images/public/6a4121ee87663bd9b9c98ef7/78662cee3_generated_image.png";

function timeAgo(d) {
  const m = Math.max(0, Math.round((Date.now() - new Date(d).getTime()) / 60000));
  if (m < 1) return "à l'instant";
  if (m < 60) return `il y a ${m} min`;
  return `il y a ${Math.round(m / 60)} h`;
}

// ─────────────────────────────────────────────────────────────────────────
// L'ÉCRAN D'UN DEVICE DE RÔLE — au centre, l'activité causale PARTAGÉE du
// mariage : n'importe quel rôle qui agit, ça ondule en direct chez tous les
// autres. En dessous, le clavier à pictos (ou horaires le Jour J).
// ─────────────────────────────────────────────────────────────────────────
export default function DeviceRoleScreen({ theme }) {
  const [activity, setActivity] = useState([]);
  const [detail, setDetail] = useState(null);
  const [jourj, setJourj] = useState(false);

  useEffect(() => {
    base44.entities.DeviceActivity.list("-created_date", 8).then(setActivity).catch(() => {});
    const unsubscribe = base44.entities.DeviceActivity.subscribe((event) => {
      if (event.type === "create" && event.data) {
        setActivity((prev) => [event.data, ...prev].slice(0, 8));
      }
    });
    return unsubscribe;
  }, []);

  // Appuyer sur une touche : détail à l'écran + onde causale vers les autres.
  const onKey = (k) => {
    setDetail(k);
    base44.entities.DeviceActivity.create({
      actor_role: theme.role,
      action: jourj ? `consulte ${k.time} — ${k.label}` : `a ouvert ${k.label}`,
      target: jourj ? `Jour J ${k.time}` : k.label,
      color: theme.accent,
    }).catch(() => {});
  };

  return (
    <div
      className="overflow-hidden rounded-2xl border border-white/10 bg-cover bg-center p-4"
      style={{ backgroundImage: `url(${FLORAL_BG})` }}
    >
      <p className="font-mono text-[9px] uppercase tracking-[0.3em] drop-shadow" style={{ color: theme.accent }}>
        {theme.cat}
      </p>
      <p className="mt-1 text-[13px] text-white/90 drop-shadow">{theme.tagline}</p>

      {/* LE CENTRE CAUSAL — l'activité partagée du mariage, en direct */}
      <div className="mt-4 rounded-3xl bg-[#0B0B0C] p-5 shadow-2xl ring-1 ring-white/[0.06]">
        <div className="flex items-center justify-between">
          <p className="text-[15px] font-bold text-white">Le mariage, en causal</p>
          <p className="flex items-center gap-1.5 text-[12px] text-white/40">
            <span className="h-2 w-2 animate-pulse rounded-full bg-emerald-400" /> Live
          </p>
        </div>
        <ul className="mt-4 space-y-3.5">
          {activity.length === 0 && (
            <li className="text-[12.5px] text-white/35">
              Aucune onde pour l'instant — appuyez sur une touche du clavier, tous les autres rôles la verront.
            </li>
          )}
          {activity.map((a) => (
            <li key={a.id} className="flex items-start gap-3">
              <span className="mt-0.5 grid h-7 w-7 shrink-0 place-items-center rounded-full bg-white/[0.06]">
                <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: a.color || "#C9B88F" }} />
              </span>
              <div>
                <p className="text-[13.5px] leading-5 text-white">
                  <span className="font-bold">{a.actor_role}</span> {a.action}
                </p>
                <p className="mt-0.5 text-[11.5px] text-white/35">{timeAgo(a.created_date)}</p>
              </div>
            </li>
          ))}
        </ul>
      </div>

      {/* LE DÉTAIL — ce que la touche pressée projette à l'écran */}
      {detail && (
        <div className="mt-3 rounded-3xl bg-[#0B0B0C] p-5 shadow-2xl ring-1" style={{ "--tw-ring-color": `${theme.accent}66` }}>
          <div className="flex items-start justify-between gap-3">
            <p className="text-[15px] font-bold text-white">
              {detail.time ? (
                <><span style={{ color: theme.accent }}>{detail.time}</span> · {detail.label}</>
              ) : detail.label}
            </p>
            <button type="button" onClick={() => setDetail(null)} aria-label="Fermer le détail"
              className="rounded-full p-1.5 text-white/40 transition hover:bg-white/10 hover:text-white">
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
          <p className="mt-2 text-[13px] leading-6 text-white/60">{detail.detail}</p>
        </div>
      )}

      {/* LE CLAVIER PHYSIQUE À PICTOS / HORAIRES */}
      <div className="mt-3">
        <DeviceRoleKeyboard accent={theme.accent} onKey={onKey} jourj={jourj} setJourj={setJourj} />
      </div>
    </div>
  );
}