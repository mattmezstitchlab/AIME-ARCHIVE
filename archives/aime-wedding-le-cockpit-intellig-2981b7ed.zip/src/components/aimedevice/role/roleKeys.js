import { FolderOpen, Camera, FileText, Receipt, Video, UtensilsCrossed, PiggyBank, CreditCard, Users, MapPin, Music, CalendarClock, Sparkles, Car, Cake, PartyPopper } from "lucide-react";

// ─────────────────────────────────────────────────────────────────────────
// LE CLAVIER À PICTOS — chaque touche est un dossier du mariage. Le Jour J,
// les touches se transforment en horaires : on appuie, le détail s'affiche
// à l'écran, et l'action se propage causalement aux autres devices.
// ─────────────────────────────────────────────────────────────────────────
export const PICTO_KEYS = [
  { id: "dossier", icon: FolderOpen, label: "Dossier", detail: "Le dossier complet du mariage : documents, contrats, notes partagées. Tout ce que votre rôle doit voir, rien de plus." },
  { id: "photo", icon: Camera, label: "Photo", detail: "Les galeries du mariage : repérages, essais, inspirations. Chaque photo ajoutée apparaît chez les rôles concernés." },
  { id: "devis", icon: FileText, label: "Devis", detail: "Les devis en cours : chaque validation se répercute immédiatement sur le budget de tous." },
  { id: "facture", icon: Receipt, label: "Facture", detail: "Les factures reçues et réglées, reliées causalement aux devis et au budget." },
  { id: "video", icon: Video, label: "Vidéo", detail: "Les vidéos : teaser, cérémonie, souvenirs. Le vidéaste dépose, tout le monde voit." },
  { id: "traiteur", icon: UtensilsCrossed, label: "Traiteur", detail: "Menu, régimes, quantités. Un invité de plus ? Le traiteur le sait à la seconde." },
  { id: "budget", icon: PiggyBank, label: "Budget", detail: "Le budget vivant : chaque mouvement d'un rôle ajuste la répartition de tous." },
  { id: "payer", icon: CreditCard, label: "Payer", detail: "Régler un acompte ou une facture — le paiement horodaté se propage au dossier et au budget." },
  { id: "invites", icon: Users, label: "Invités", detail: "La liste vivante : réponses, régimes, tables. Chaque changement ondule vers le traiteur et le plan de salle." },
  { id: "lieu", icon: MapPin, label: "Lieu", detail: "Le lieu, ses accès, ses horaires, ses contraintes techniques pour chaque prestataire." },
  { id: "musique", icon: Music, label: "Musique", detail: "Playlist, moments musicaux, BPM du Jour J — reliés au DJ et au planning." },
  { id: "planning", icon: CalendarClock, label: "Planning", detail: "Le rétroplanning causal : une date bouge, toutes les échéances liées se réalignent." },
];

// LE JOUR J — les touches deviennent des horaires. Appuyer = le détail à l'écran.
export const JOURJ_KEYS = [
  { id: "j1", time: "14:00", icon: Sparkles, label: "Préparatifs", detail: "Coiffure, maquillage, habillage. Photographe présent dès 14h30 pour les instants volés." },
  { id: "j2", time: "15:30", icon: Car, label: "Départ cortège", detail: "Le cortège part du domaine. Coordinateur : vérifier les véhicules et les boutonnières." },
  { id: "j3", time: "16:00", icon: PartyPopper, label: "Cérémonie", detail: "Cérémonie laïque dans le parc. Musique d'entrée lancée par le DJ, officiants prêts à 15h50." },
  { id: "j4", time: "17:00", icon: Camera, label: "Photos", detail: "Séance photos de groupe puis couple à la golden hour. Témoins : rassembler les familles." },
  { id: "j5", time: "18:00", icon: UtensilsCrossed, label: "Cocktail", detail: "Cocktail au bord de la terrasse. Traiteur : 6 pièces/personne, bar ouvert." },
  { id: "j6", time: "20:00", icon: Cake, label: "Dîner", detail: "Entrée du dîner, discours des témoins entre les plats. Régies son et lumière calées." },
  { id: "j7", time: "22:30", icon: Music, label: "Ouverture bal", detail: "Première danse puis ouverture de la piste. DJ : montée BPM progressive." },
  { id: "j8", time: "00:00", icon: Sparkles, label: "Surprise", detail: "Le moment surprise des témoins — personne d'autre ne connaît le détail. Chut." },
];