import { useState } from "react";
import { ArrowLeft, Music, Mic2, LayoutTemplate, HeartHandshake, Inbox, Stamp, Languages, Footprints } from "lucide-react";
import DeviceMusic from "@/components/aimedevice/os/DeviceMusic";
import DeviceSlame from "@/components/aimedevice/os/DeviceSlame";
import DeviceBuilder from "@/components/aimedevice/os/DeviceBuilder";
import DeviceContracts from "@/components/aimedevice/os/DeviceContracts";
import DeviceMessagerie from "@/components/aimedevice/os/DeviceMessagerie";
import DeviceStamp from "@/components/aimedevice/os/DeviceStamp";
import DeviceTraduction from "@/components/aimedevice/os/DeviceTraduction";
import DeviceDons from "@/components/aimedevice/os/DeviceDons";
import { WidgetActivity, WidgetHealth, WidgetSpend } from "@/components/aimedevice/DeviceCausalWidgets";

const FLORAL_BG = "https://media.base44.com/images/public/6a4121ee87663bd9b9c98ef7/78662cee3_generated_image.png";

// Registre des applis embarquables dans les devices thématiques.
const APPS = {
  musique: { icon: Music, label: "Musique", Component: DeviceMusic },
  slame: { icon: Mic2, label: "Slâme", Component: DeviceSlame },
  builder: { icon: LayoutTemplate, label: "Builder", Component: DeviceBuilder },
  contrats: { icon: HeartHandshake, label: "Contrats", Component: DeviceContracts },
  messagerie: { icon: Inbox, label: "Messagerie IA", Component: DeviceMessagerie },
  stamp: { icon: Stamp, label: "Stamp", Component: DeviceStamp },
  langues: { icon: Languages, label: "Traduction", Component: DeviceTraduction },
  dons: { icon: Footprints, label: "Dons", Component: DeviceDons },
};

// L'ÉCRAN d'un device thématique : ses applis, directement — pas de bureau.
export default function DeviceThemeApps({ theme }) {
  const [open, setOpen] = useState(null);

  if (open && APPS[open]) {
    const { Component } = APPS[open];
    return (
      <div>
        <button
          type="button"
          onClick={() => setOpen(null)}
          className="mb-3 inline-flex items-center gap-1.5 font-mono text-[9.5px] font-semibold uppercase tracking-[0.22em] text-white/45 transition hover:text-white"
        >
          <ArrowLeft className="h-3.5 w-3.5" /> {theme.label}
        </button>
        <Component />
      </div>
    );
  }

  return (
    <div
      className="overflow-hidden rounded-2xl border border-white/10 bg-cover bg-center p-5"
      style={{ backgroundImage: `url(${FLORAL_BG})` }}
    >
      <p className="font-mono text-[9px] uppercase tracking-[0.3em] text-white drop-shadow" style={{ color: theme.accent }}>
        {theme.cat}
      </p>
      <p className="mt-1 text-[13px] text-white/90 drop-shadow">{theme.tagline}</p>

      {/* Les widgets causaux — cartes noires flottant sur le floral */}
      <div className="mt-5 grid gap-4 lg:grid-cols-3">
        <WidgetActivity />
        <WidgetHealth />
        <WidgetSpend />
      </div>

      <div className="mt-6 grid grid-cols-4 gap-x-2 gap-y-4 rounded-2xl bg-black/35 p-4 backdrop-blur-md sm:grid-cols-5">
        {(theme.apps || []).map((id) => {
          const app = APPS[id];
          if (!app) return null;
          return (
            <button key={id} type="button" onClick={() => setOpen(id)} className="group flex flex-col items-center gap-1.5 text-center">
              <span className="grid h-14 w-14 place-items-center rounded-2xl border border-white/15 bg-black/50 shadow-lg backdrop-blur-md transition group-hover:scale-110" style={{ borderColor: undefined }}>
                <app.icon className="h-6 w-6" style={{ color: theme.accent }} strokeWidth={1.6} />
              </span>
              <span className="max-w-[4.6rem] truncate text-[10px] font-semibold text-white">{app.label}</span>
            </button>
          );
        })}
        {(theme.coming || []).map((label) => (
          <div key={label} className="flex flex-col items-center gap-1.5 text-center opacity-45">
            <span className="grid h-14 w-14 place-items-center rounded-2xl border border-dashed border-white/15 bg-black/25">
              <span className="font-mono text-[8px] uppercase tracking-[0.14em] text-white/40">à venir</span>
            </span>
            <span className="max-w-[4.6rem] text-[10px] font-semibold text-white/60">{label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}