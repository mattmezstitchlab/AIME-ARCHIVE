import { useState } from "react";
import { Folder, Loader2, Palette } from "lucide-react";

// DOSSIERS — le site absorbé est rangé automatiquement : chaque famille de
// contenu devient un dossier navigable directement dans le clavier.
export default function DeviceDossiers({ absorbed }) {
  const [open, setOpen] = useState(null);

  if (!absorbed) return <p className="p-4 text-[12px] text-white/40">Absorbez un site pour remplir les dossiers.</p>;
  if (absorbed.loading) return <p className="flex items-center gap-2 p-4 text-[12px] text-white/50"><Loader2 className="h-4 w-4 animate-spin text-accent" /> Absorption & rangement…</p>;
  if (absorbed.error) return <p className="p-4 text-[12px] text-amber-300">{absorbed.error}</p>;

  // Rangement générique : chaque tableau du contenu extrait devient un dossier.
  const folders = Object.entries(absorbed.content || {})
    .filter(([, v]) => Array.isArray(v) && v.length > 0)
    .map(([key, items]) => ({ key, items }));

  const label = (it) => {
    if (typeof it === "string") return it;
    return it.title || it.label || it.text || it.name || it.alt || it.url || it.src || JSON.stringify(it).slice(0, 80);
  };

  return (
    <div className="p-4">
      <div className="flex flex-wrap gap-2">
        {folders.map((f) => (
          <button
            key={f.key}
            type="button"
            onClick={() => setOpen(open === f.key ? null : f.key)}
            className={`inline-flex items-center gap-1.5 rounded-xl px-3 py-2 text-[11.5px] font-medium capitalize transition ${
              open === f.key ? "bg-accent text-black" : "bg-white/[0.05] text-white/70 hover:bg-white/10"
            }`}
          >
            <Folder className="h-3.5 w-3.5" /> {f.key} <span className="opacity-60">· {f.items.length}</span>
          </button>
        ))}
        {absorbed.colors?.length > 0 && (
          <button
            type="button"
            onClick={() => setOpen(open === "__colors" ? null : "__colors")}
            className={`inline-flex items-center gap-1.5 rounded-xl px-3 py-2 text-[11.5px] font-medium transition ${
              open === "__colors" ? "bg-accent text-black" : "bg-white/[0.05] text-white/70 hover:bg-white/10"
            }`}
          >
            <Palette className="h-3.5 w-3.5" /> Couleurs <span className="opacity-60">· {absorbed.colors.length}</span>
          </button>
        )}
      </div>

      {open === "__colors" && (
        <div className="mt-3 flex flex-wrap gap-2">
          {absorbed.colors.map((c, i) => (
            <span key={i} className="flex items-center gap-1.5 rounded-full bg-white/[0.05] py-1 pl-1 pr-2.5 font-mono text-[10px] text-white/60">
              <span className="h-5 w-5 rounded-full border border-white/20" style={{ backgroundColor: c.hex || c }} />
              {c.hex || c}
            </span>
          ))}
        </div>
      )}

      {open && open !== "__colors" && (
        <ul className="mt-3 max-h-48 space-y-1 overflow-y-auto scrollbar-hide">
          {folders.find((f) => f.key === open)?.items.slice(0, 40).map((it, i) => (
            <li key={i} className="truncate rounded-lg bg-white/[0.04] px-3 py-1.5 text-[11.5px] text-white/60">
              {label(it)}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}