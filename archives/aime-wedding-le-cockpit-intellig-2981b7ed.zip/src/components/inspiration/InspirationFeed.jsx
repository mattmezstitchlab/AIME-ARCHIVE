import { useState } from "react";
import { Compass, Loader2, RefreshCw } from "lucide-react";
import { chercherInspiration } from "@/lib/inspiration/inspirationEngine";
import { loadPins, togglePin, isPinned } from "@/lib/inspiration/inspirationStore";
import InspirationCard from "./InspirationCard";

// LE FLUX D'INSPIRATION CURATÉE (façon Muzli) — branché sur le contexte
// causal : le style en cours de réglage (Miroir) ou la direction artistique
// du site en re-création (pipeline EAA). Les épingles nourrissent le Canevas.
export default function InspirationFeed({ contexte, colonnes = 2 }) {
  const [refs, setRefs] = useState([]);
  const [pins, setPins] = useState(loadPins);
  const [loading, setLoading] = useState(false);
  const [cherche, setCherche] = useState(false);

  const chercher = async () => {
    setLoading(true);
    setCherche(true);
    try {
      setRefs(await chercherInspiration(contexte));
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="rounded-2xl border border-white/12 bg-[#0f0f12] p-4">
      <div className="flex items-center justify-between gap-2">
        <p className="inline-flex items-center gap-2 font-mono text-[9.5px] font-bold uppercase tracking-[0.2em] text-white/50">
          <Compass className="h-3.5 w-3.5 text-[#c9a96e]" /> Inspiration curatée
        </p>
        {cherche && !loading && (
          <button
            type="button"
            onClick={chercher}
            aria-label="Actualiser les références"
            className="rounded-full p-1.5 text-white/40 transition hover:bg-white/10 hover:text-white"
          >
            <RefreshCw className="h-3.5 w-3.5" />
          </button>
        )}
      </div>

      {!cherche && (
        <>
          <p className="mt-2 text-[11.5px] leading-relaxed text-white/45">
            Des références design réelles (Awwwards, Behance, Dribbble…) triées pour votre
            langage visuel du moment. Épinglez : elles resserviront dans le Canevas.
          </p>
          <button
            type="button"
            onClick={chercher}
            className="mt-3 inline-flex items-center gap-2 rounded-lg border border-[#c9a96e]/50 px-3.5 py-2 text-[12px] font-semibold text-[#e6cf9f] transition hover:bg-[#c9a96e]/15"
          >
            <Compass className="h-3.5 w-3.5" /> Chercher l'inspiration
          </button>
        </>
      )}

      {loading && (
        <p className="mt-4 flex items-center gap-2 text-[12px] text-white/50">
          <Loader2 className="h-4 w-4 animate-spin text-[#c9a96e]" /> Le curateur parcourt le web design…
        </p>
      )}

      {!loading && refs.length > 0 && (
        <div className={`mt-4 grid gap-3 ${colonnes === 2 ? "sm:grid-cols-2" : ""}`}>
          {refs.map((r) => (
            <InspirationCard
              key={r.url}
              reference={r}
              pinned={isPinned(pins, r)}
              onPin={() => setPins(togglePin(r))}
            />
          ))}
        </div>
      )}

      {pins.length > 0 && (
        <p className="mt-3 font-mono text-[9px] uppercase tracking-[0.16em] text-white/30">
          {pins.length} référence{pins.length > 1 ? "s" : ""} épinglée{pins.length > 1 ? "s" : ""} — prête{pins.length > 1 ? "s" : ""} pour le Canevas
        </p>
      )}
    </section>
  );
}