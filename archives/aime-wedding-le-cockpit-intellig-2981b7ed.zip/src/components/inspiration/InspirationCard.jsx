import { Pin, ExternalLink } from "lucide-react";

// UNE RÉFÉRENCE CURATÉE — titre, source, tags de style, et le « pourquoi »
// pédagogique. Épinglable : elle rejoint le moodboard pour le Canevas.
export default function InspirationCard({ reference, pinned, onPin }) {
  return (
    <article className="rounded-xl border border-white/12 bg-white/[0.03] p-3.5">
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <h4 className="truncate text-[13px] font-semibold text-white/90">{reference.titre}</h4>
          <p className="font-mono text-[9px] uppercase tracking-[0.16em] text-white/35">{reference.source}</p>
        </div>
        <button
          type="button"
          onClick={onPin}
          aria-pressed={pinned}
          aria-label={pinned ? "Retirer du moodboard" : "Épingler au moodboard"}
          className={`shrink-0 rounded-full p-1.5 transition ${
            pinned ? "bg-[#c9a96e]/25 text-[#c9a96e]" : "text-white/35 hover:bg-white/10 hover:text-white"
          }`}
        >
          <Pin className="h-3.5 w-3.5" fill={pinned ? "currentColor" : "none"} />
        </button>
      </div>
      <div className="mt-2 flex flex-wrap gap-1">
        {(reference.tags || []).map((t) => (
          <span key={t} className="rounded-full border border-white/15 px-2 py-0.5 text-[9.5px] text-white/55">
            {t}
          </span>
        ))}
      </div>
      <p className="mt-2 text-[11.5px] leading-relaxed text-white/55">{reference.description}</p>
      {reference.pourquoi && (
        <p className="mt-1.5 text-[11px] italic leading-relaxed text-[#e6cf9f]/80">→ {reference.pourquoi}</p>
      )}
      <a
        href={reference.url}
        target="_blank"
        rel="noopener noreferrer"
        className="mt-2 inline-flex items-center gap-1 text-[10.5px] font-medium text-[#38bdf8] hover:underline"
      >
        Voir la référence <ExternalLink className="h-3 w-3" />
      </a>
    </article>
  );
}