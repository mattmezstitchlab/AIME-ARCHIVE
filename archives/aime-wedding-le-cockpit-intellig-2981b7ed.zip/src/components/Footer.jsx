import { Link } from "react-router-dom";
import { Waves } from "lucide-react";
import { AIME_NAV } from "@/lib/aimeWeddingSite";

// Colonnes de navigation, alignées sur le menu burger (source unique).
const INFO_LINKS = [
  { label: "À propos", to: "/a-propos" },
  { label: "Blog", to: "/blog" },
  { label: "Aide", to: "/infos?tab=aide" },
  { label: "Contact", to: "/infos?tab=contact" },
  { label: "Plan du site", to: "/plan-du-site" },
  { label: "Santé du site", to: "/sante" },
];

const LEGAL_LINKS = [
  { label: "Mentions légales", to: "/legal?tab=cgu" },
  { label: "Confidentialité", to: "/legal?tab=confidentialite" },
  { label: "Cookies", to: "/legal?tab=cookies" },
  { label: "Accessibilité", to: "/legal?tab=accessibilite" },
];

function Column({ title, links }) {
  return (
    <div>
      <p className="font-heading text-[11px] font-semibold uppercase tracking-[0.22em] text-primary-foreground">{title}</p>
      <ul className="mt-4 space-y-2.5">
        {links.map((link) => (
          <li key={link.to}>
            <Link
              to={link.to}
              className="font-heading text-[11px] uppercase tracking-[0.16em] text-primary-foreground/55 transition-colors hover:text-primary-foreground"
            >
              {link.label}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default function Footer() {
  return (
    <footer className="bg-foreground text-primary-foreground">
      <div className="mx-auto max-w-7xl px-6 py-16">
        <div className="grid gap-12 md:grid-cols-4">
          {/* Brand + Ripple UI */}
          <div className="md:col-span-1">
            <Link to="/" aria-label="AIME Wedding — accueil" className="font-heading text-base font-semibold uppercase tracking-[0.22em] text-primary-foreground">
              AIME Wedding
            </Link>
            <p className="mt-3 max-w-xs text-[12px] leading-relaxed text-primary-foreground/50">
              L'application de coordination de mariage causal — préparez l'avant, pilotez le Jour J, gardez les souvenirs après.
            </p>
            <Link
              to="/mecanisme"
              className="mt-5 inline-flex items-center gap-2 font-heading text-[11px] uppercase tracking-[0.16em] text-primary-foreground/70 transition-colors hover:text-primary-foreground"
            >
              <Waves className="h-4 w-4" /> Le mécanisme causal
            </Link>
          </div>

          <Column title="Les verticales" links={AIME_NAV.map((n) => ({ label: n.label, to: n.path }))} />
          <Column title="Infos" links={INFO_LINKS} />
          <Column title="Mentions légales" links={LEGAL_LINKS} />
        </div>

        <hr className="my-10 border-primary-foreground/10" />

        <p className="text-center text-[10px] uppercase tracking-[0.16em] text-primary-foreground/40">
          © {new Date().getFullYear()} AIME Wedding. Tous droits réservés.
        </p>
      </div>
    </footer>
  );
}