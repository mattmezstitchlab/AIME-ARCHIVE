import { useState } from "react";

// LE RENDU PUBLIC D'UN SITE STUDIO — la version vivante, propre et accessible
// du site composé dans le canevas : navigation par pages, sections, design.
export default function SiteStudioRender({ site, adresse }) {
  const pages = site?.pages || {};
  const noms = Object.keys(pages);
  const [active, setActive] = useState(noms[0] || null);
  const accent = site?.design?.accent || site?.style?.palette?.[0] || "#111111";
  const sections = (pages[active] || []).filter((s) => s.status === "ok" || s.heading);

  return (
    <div className="min-h-screen bg-white text-[#111]">
      {/* En-tête du site publié */}
      <header className="border-b border-black/10 px-6 py-4">
        <div className="mx-auto flex max-w-4xl flex-wrap items-center justify-between gap-3">
          <p className="font-heading text-[17px] font-extrabold tracking-[-0.02em]">{site?.siteName || adresse}</p>
          {noms.length > 1 && (
            <nav aria-label="Pages du site" className="flex flex-wrap gap-1">
              {noms.map((n) => (
                <button key={n} type="button" onClick={() => setActive(n)} aria-current={active === n ? "page" : undefined}
                  className={`min-h-[36px] rounded-full px-4 text-[13px] font-semibold capitalize transition ${active === n ? "text-white" : "text-black/60 hover:bg-black/5"}`}
                  style={active === n ? { background: accent } : undefined}>
                  {n.replace(/-/g, " ")}
                </button>
              ))}
            </nav>
          )}
        </div>
      </header>

      {/* Les sections composées au Studio */}
      <main className="mx-auto max-w-4xl px-6 pb-24">
        {sections.length === 0 && (
          <p className="py-24 text-center text-[14px] text-black/50">Cette page n'a pas encore de sections publiées.</p>
        )}
        {sections.map((s, i) => (
          <section key={s.id || i} className="border-b border-black/5 py-14 last:border-0">
            {i === 0 ? (
              <h1 className="font-heading text-[clamp(2rem,5vw,3.2rem)] font-extrabold leading-[1.02] tracking-[-0.03em]">{s.heading}</h1>
            ) : (
              <h2 className="font-heading text-[clamp(1.4rem,3vw,2rem)] font-extrabold leading-[1.05] tracking-[-0.02em]">{s.heading}</h2>
            )}
            {s.image_url && (
              <img src={s.image_url} alt={s.label || s.heading || ""} className="mt-6 w-full rounded-2xl object-cover" />
            )}
            {s.body && <p className="mt-4 max-w-2xl whitespace-pre-line text-[15px] leading-7 text-black/70">{s.body}</p>}
            {s.cta && (
              <p className="mt-6">
                <span className="inline-flex min-h-[44px] items-center rounded-full px-6 text-[14px] font-bold text-white" style={{ background: accent }}>
                  {s.cta}
                </span>
              </p>
            )}
          </section>
        ))}
      </main>

      <footer className="border-t border-black/10 px-6 py-8 text-center">
        <p className="font-mono text-[11px] font-semibold uppercase tracking-[0.22em] text-black/40">
          {adresse} · publié avec AIME® OS
        </p>
      </footer>
    </div>
  );
}