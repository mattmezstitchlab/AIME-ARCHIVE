import { useMemo } from "react";
import { Link } from "react-router-dom";
import { Clock, Phone, LifeBuoy, MapPin, CalendarClock, ArrowRight } from "lucide-react";

// Cockpit du Jour J — une seule page forte : programme minute par minute,
// « en cours / prochain », contacts utiles et urgences. Lit le dossier (plan).
function nowMinutes() {
  const d = new Date();
  return d.getHours() * 60 + d.getMinutes();
}
function toMin(t) {
  const [h, m] = String(t || "").split(":").map(Number);
  return Number.isFinite(h) ? h * 60 + (m || 0) : -1;
}

export default function JourJCockpit({ plan }) {
  const timeline = useMemo(
    () => [...(plan?.timeline || [])].sort((a, b) => (a.time || "").localeCompare(b.time || "")),
    [plan]
  );
  const contacts = plan?.useful_contacts || [];

  const { current, next } = useMemo(() => {
    const nm = nowMinutes();
    let cur = null;
    let nxt = null;
    for (let i = 0; i < timeline.length; i++) {
      const s = toMin(timeline[i].time);
      if (s < 0) continue;
      if (s <= nm) cur = timeline[i];
      else { nxt = timeline[i]; break; }
    }
    return { current: cur, next: nxt };
  }, [timeline]);

  return (
    <div className="mx-auto max-w-4xl px-5 py-10 sm:py-14">
      <header className="mb-8">
        <p className="label-aime text-muted-foreground">Jour J · Piloter</p>
        <h1 className="mt-3 font-heading text-3xl font-semibold tracking-[-0.02em] text-foreground sm:text-4xl">
          Le cockpit de votre grand jour.
        </h1>
        <p className="mt-3 max-w-xl text-[15px] leading-relaxed text-muted-foreground">
          Le déroulé minute par minute, les contacts clés et les urgences — tout ce qu'il faut avoir sous la main, le jour même.
        </p>
      </header>

      {/* Bandeau « en cours / prochain » */}
      <div className="mb-8 grid gap-3 sm:grid-cols-2">
        <div className="rounded-2xl border border-foreground bg-foreground p-5 text-background">
          <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-background/50">En ce moment</p>
          {current ? (
            <>
              <p className="mt-2 font-heading text-xl font-semibold">{current.time} · {current.label}</p>
              {current.place && <p className="mt-1 text-[13px] text-background/70">{current.place}</p>}
            </>
          ) : (
            <p className="mt-2 text-[14px] text-background/70">Le programme n'a pas encore commencé.</p>
          )}
        </div>
        <div className="rounded-2xl border border-border bg-card p-5">
          <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-muted-foreground">Juste après</p>
          {next ? (
            <>
              <p className="mt-2 font-heading text-xl font-semibold text-foreground">{next.time} · {next.label}</p>
              {next.place && <p className="mt-1 text-[13px] text-muted-foreground">{next.place}</p>}
            </>
          ) : (
            <p className="mt-2 text-[14px] text-muted-foreground">Plus rien de prévu ensuite.</p>
          )}
        </div>
      </div>

      {/* Programme minute par minute */}
      <section className="mb-8">
        <div className="mb-3 flex items-center gap-2">
          <Clock className="h-4 w-4 text-foreground" strokeWidth={1.5} />
          <h2 className="font-heading text-sm font-semibold uppercase tracking-[0.14em] text-foreground">Programme</h2>
        </div>

        {timeline.length === 0 ? (
          <Link
            to="/couple?focus=/jour-j"
            className="flex items-center justify-between rounded-2xl border border-dashed border-border bg-muted/40 p-5 text-[14px] text-muted-foreground transition-colors hover:border-foreground/30"
          >
            <span className="flex items-center gap-2"><CalendarClock className="h-4 w-4" /> Composez votre déroulé du Jour J</span>
            <ArrowRight className="h-4 w-4" />
          </Link>
        ) : (
          <ol className="relative border-l border-border pl-6">
            {timeline.map((t) => {
              const active = current && t.time === current.time && t.label === current.label;
              return (
                <li key={t.id || `${t.time}-${t.label}`} className="relative pb-5 last:pb-0">
                  <span className={`absolute -left-[27px] top-1 h-3 w-3 rounded-full border-2 ${active ? "border-foreground bg-foreground" : "border-border bg-background"}`} />
                  <div className="flex items-baseline gap-3">
                    <span className="w-12 shrink-0 font-heading text-[13px] font-semibold tabular-nums text-foreground">{t.time}</span>
                    <div>
                      <p className={`text-[15px] ${active ? "font-semibold text-foreground" : "text-foreground"}`}>{t.label}</p>
                      {(t.place || t.provider) && (
                        <p className="text-[12px] text-muted-foreground">{[t.place, t.provider].filter(Boolean).join(" · ")}</p>
                      )}
                    </div>
                  </div>
                </li>
              );
            })}
          </ol>
        )}
      </section>

      {/* Contacts utiles & urgences */}
      <section className="grid gap-3 sm:grid-cols-2">
        <div className="rounded-2xl border border-border bg-card p-5">
          <div className="mb-3 flex items-center gap-2">
            <Phone className="h-4 w-4 text-foreground" strokeWidth={1.5} />
            <h2 className="font-heading text-sm font-semibold uppercase tracking-[0.14em] text-foreground">Contacts utiles</h2>
          </div>
          {contacts.length === 0 ? (
            <Link to="/couple?focus=/contacts-utiles" className="text-[13px] text-muted-foreground underline underline-offset-2 hover:text-foreground">
              Ajouter les numéros clés
            </Link>
          ) : (
            <ul className="space-y-2.5">
              {contacts.map((c, i) => (
                <li key={i} className="flex items-center justify-between text-[14px]">
                  <span className="text-foreground">{c.name || c.role}</span>
                  {c.phone && <a href={`tel:${c.phone}`} className="font-medium text-foreground underline underline-offset-2">{c.phone}</a>}
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="rounded-2xl border border-border bg-card p-5">
          <div className="mb-3 flex items-center gap-2">
            <LifeBuoy className="h-4 w-4 text-foreground" strokeWidth={1.5} />
            <h2 className="font-heading text-sm font-semibold uppercase tracking-[0.14em] text-foreground">Urgences & plan B</h2>
          </div>
          <ul className="space-y-2.5 text-[14px]">
            <li className="flex items-center justify-between">
              <span className="text-foreground">Urgences</span>
              <a href="tel:112" className="font-medium text-foreground underline underline-offset-2">112</a>
            </li>
            <li className="flex items-center gap-2 text-muted-foreground">
              <MapPin className="h-4 w-4" strokeWidth={1.5} />
              <Link to="/couple?focus=/jour-j" className="underline underline-offset-2 hover:text-foreground">Plan d'accès & repli météo</Link>
            </li>
          </ul>
        </div>
      </section>
    </div>
  );
}