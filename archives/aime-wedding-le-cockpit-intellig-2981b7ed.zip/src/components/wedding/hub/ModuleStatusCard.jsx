import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { STATUS_META, moduleStatus } from "@/lib/wedding/moduleStatus";

// Carte claire d'un module : picto, nom, sous-titre, pastille de statut.
// Cliquable → ouvre le module dans le dossier du couple.
export default function ModuleStatusCard({ module, plan, to }) {
  const Icon = module.icon;
  const status = moduleStatus(module.key, plan);
  const meta = STATUS_META[status];

  return (
    <Link
      to={to}
      className="group flex items-center gap-4 rounded-2xl border border-white/12 bg-white/[0.03] p-5 transition-all hover:border-white/30 hover:bg-white/[0.06]"
    >
      <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-white/10 text-white">
        <Icon className="h-5 w-5" strokeWidth={1.5} />
      </span>

      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <h3 className="truncate font-heading text-[15px] font-semibold text-white">{module.label}</h3>
          <span className={`inline-flex items-center gap-1.5 rounded-full bg-white/10 px-2 py-0.5 text-[10px] font-medium ${meta.text}`}>
            <span className={`h-1.5 w-1.5 rounded-full ${meta.dot}`} />
            {meta.label}
          </span>
        </div>
        <p className="mt-0.5 truncate text-[13px] text-white/55">{module.subtitle}</p>
      </div>

      <ArrowRight className="h-4 w-4 shrink-0 text-white/45 transition-transform group-hover:translate-x-0.5 group-hover:text-white" />
    </Link>
  );
}