import { Link } from "react-router-dom";
import { MapPin, CalendarDays, Wallet, Users, CalendarClock, Palette, ArrowRight } from "lucide-react";

// Aperçu de la base de mariage préremplie depuis l'intention.
function Stat({ icon: Icon, label, value }) {
  if (!value) return null;
  return (
    <div className="flex items-center gap-3 rounded-xl border border-white/12 bg-white/[0.03] p-4">
      <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-white/10 text-white">
        <Icon className="h-4 w-4" strokeWidth={1.5} />
      </span>
      <div className="min-w-0">
        <p className="text-[10px] font-semibold uppercase tracking-[0.14em] text-white/45">{label}</p>
        <p className="truncate text-[14px] font-medium text-white">{value}</p>
      </div>
    </div>
  );
}

export default function ComposerResult({ plan, summary }) {
  if (!plan) return null;

  const dateLabel = plan.event_date
    ? new Date(plan.event_date).toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" })
    : null;
  const budget = plan.budget_max ? `${Number(plan.budget_max).toLocaleString("fr-FR")} €` : null;
  const guests = plan.guests_count ? `${plan.guests_count} invités` : null;
  const timeline = (plan.timeline || []).length ? `${plan.timeline.length} moments` : null;
  const palette = (plan.color_palette || []).length ? `${plan.color_palette.length} couleurs` : null;
  const venue = plan.public_site?.venue || plan.city;

  return (
    <div className="mt-8">
      {summary && (
        <p className="mb-4 rounded-xl border border-emerald-400/25 bg-emerald-400/10 px-4 py-3 text-[14px] text-emerald-300">{summary}</p>
      )}
      <p className="mb-3 text-[11px] font-semibold uppercase tracking-[0.24em] text-white/45">Votre base de mariage</p>
      <div className="grid gap-3 sm:grid-cols-2">
        <Stat icon={MapPin} label="Lieu / ville" value={venue} />
        <Stat icon={CalendarDays} label="Date" value={dateLabel} />
        <Stat icon={Wallet} label="Budget" value={budget} />
        <Stat icon={Users} label="Invités" value={guests} />
        <Stat icon={CalendarClock} label="Programme" value={timeline} />
        <Stat icon={Palette} label="Palette" value={palette} />
      </div>

      <div className="mt-6 flex flex-wrap gap-3">
        <Link to="/avant" className="inline-flex items-center gap-2 rounded-full bg-white px-5 py-2.5 text-[14px] font-semibold text-black transition-opacity hover:opacity-90">
          Continuer dans « Avant » <ArrowRight className="h-4 w-4" />
        </Link>
        <Link to="/jour-j" className="inline-flex items-center gap-2 rounded-full border border-white/25 px-5 py-2.5 text-[14px] font-medium text-white transition-colors hover:bg-white/10">
          Voir le Jour J
        </Link>
      </div>
    </div>
  );
}