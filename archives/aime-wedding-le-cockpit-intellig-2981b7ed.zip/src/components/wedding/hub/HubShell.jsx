import { Waves } from "lucide-react";
import ModuleStatusCard from "./ModuleStatusCard";
import { nextTodoLabel } from "@/lib/wedding/moduleStatus";

// Coquille commune des 3 hubs (Avant / Jour J / Après) :
//   - un titre clair
//   - une phrase d'intention
//   - une action principale (le prochain « à faire »)
//   - la grille de modules à statut
//   - le rappel de l'innovation AIME / Ripple
export default function HubShell({ eyebrow, title, intention, modules, plan, moduleTo }) {
  const nextLabel = nextTodoLabel(modules, plan);

  return (
    <div className="min-h-screen bg-black text-white">
      <div className="mx-auto max-w-3xl px-5 pb-28 pt-28 sm:pt-32">
        <header className="mb-10">
          <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-white/45">{eyebrow}</p>
          <h1 className="mt-3 font-heading text-4xl font-semibold leading-[1.05] tracking-[-0.03em] sm:text-5xl">
            {title}
          </h1>
          <p className="mt-4 max-w-xl text-[15px] leading-7 text-white/65">{intention}</p>

          {nextLabel && (
            <div className="mt-5 inline-flex items-center gap-2 rounded-full bg-white px-4 py-2 text-[13px] font-medium text-black">
              <span className="opacity-50">Prochaine étape :</span> {nextLabel}
            </div>
          )}
        </header>

        <div className="grid gap-3">
          {modules.map((m) => (
            <ModuleStatusCard key={m.key + m.label} module={m} plan={plan} to={moduleTo(m.key, m)} />
          ))}
        </div>

        <div className="mt-10 flex items-start gap-3 rounded-2xl border border-white/12 bg-white/[0.03] p-5">
          <Waves className="mt-0.5 h-5 w-5 shrink-0" strokeWidth={1.5} style={{ color: "#c9a96e" }} />
          <p className="text-[13px] leading-7 text-white/65">
            <span className="font-medium text-white">Chaque choix révèle ses conséquences.</span>{" "}
            Quand une information change ici, AIME met à jour les autres modules — un nombre
            d'invités modifié se répercute sur le budget, le menu, le plan de table et l'hébergement.
          </p>
        </div>
      </div>
    </div>
  );
}