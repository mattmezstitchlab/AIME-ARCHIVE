import { useRef } from "react";
import { Link } from "react-router-dom";
import { ArrowRight, ChevronLeft, ChevronRight } from "lucide-react";

const MODULES = [
  { title: "Album photos", to: "/album-photos", description: "Photos du mariage réunies", image: "https://media.base44.com/images/public/6a4121ee87663bd9b9c98ef7/86bbc7b89_generated_image.png" },
  { title: "Livre d'or", to: "/livre-or", description: "Les mots des invités", image: "https://media.base44.com/images/public/6a4121ee87663bd9b9c98ef7/77073c08c_generated_image.png" },
  { title: "Remerciements", to: "/remerciements", description: "Un mot simple et juste", image: "https://media.base44.com/images/public/6a4121ee87663bd9b9c98ef7/be62d78ee_generated_image.png" },
  { title: "Factures / solde", to: "/apres/factures-solde", description: "Derniers règlements", image: "https://media.base44.com/images/public/6a4121ee87663bd9b9c98ef7/2655fc667_generated_image.png" },
];

function Tile({ mod }) {
  return (
    <Link
      to={mod.to}
      className="group relative flex aspect-square w-full shrink-0 snap-center flex-col justify-end overflow-hidden"
    >
      <img src={mod.image} alt="" className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" loading="lazy" />
      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
      <div className="relative px-4 pb-4">
        <h3 className="text-sm font-semibold text-white">{mod.title}</h3>
        <p className="mt-0.5 text-[11px] leading-snug text-white/60">{mod.description}</p>
      </div>
      <ArrowRight className="absolute right-3 top-3 h-3.5 w-3.5 text-white/30 transition-transform group-hover:translate-x-0.5" aria-hidden="true" />
    </Link>
  );
}

function NavButton({ direction, onClick }) {
  const isLeft = direction === "left";
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={isLeft ? "Bloc précédent" : "Bloc suivant"}
      className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-border bg-background text-foreground shadow-sm transition-colors hover:bg-muted"
    >
      {isLeft ? <ChevronLeft className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
    </button>
  );
}

export default function ApresModules() {
  const scrollRef = useRef(null);

  const scroll = (dir) => {
    const el = scrollRef.current;
    if (!el) return;
    const tileWidth = el.firstElementChild?.offsetWidth || el.offsetWidth;
    el.scrollBy({ left: dir === "left" ? -tileWidth : tileWidth, behavior: "smooth" });
  };

  return (
    <div className="relative">
      {/* Grid 2×2 desktop — carousel mobile */}
      <div
        ref={scrollRef}
        className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-2 snap-x snap-mandatory max-sm:flex max-sm:overflow-x-auto max-sm:scrollbar-hide"
      >
        {MODULES.map((mod) => (
          <Tile key={mod.title} mod={mod} />
        ))}
      </div>

      {/* Boutons ronds de navigation */}
      <div className="mt-4 flex items-center justify-center gap-3">
        <NavButton direction="left" onClick={() => scroll("left")} />
        <NavButton direction="right" onClick={() => scroll("right")} />
      </div>
    </div>
  );
}