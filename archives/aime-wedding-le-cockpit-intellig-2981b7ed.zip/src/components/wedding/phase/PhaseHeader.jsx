// En-tête sobre d'une page de phase : peu de texte, beaucoup d'espace.
// Avant = préparer · Jour J = guider · Après = mémoriser.
export default function PhaseHeader({ eyebrow, title, subtitle }) {
  return (
    <header className="mb-10 text-center">
      <p className="text-[10px] uppercase tracking-[0.22em] font-semibold text-muted-foreground mb-3">
        {eyebrow}
      </p>
      <h1 className="text-3xl sm:text-4xl font-light tracking-tight text-foreground">{title}</h1>
      {subtitle && (
        <p className="mt-3 text-sm text-foreground/50 max-w-md mx-auto">{subtitle}</p>
      )}
    </header>
  );
}