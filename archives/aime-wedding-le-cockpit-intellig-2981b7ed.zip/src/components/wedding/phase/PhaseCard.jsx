import { Link } from "react-router-dom";
import { ChevronRight } from "lucide-react";

// Carte propre façon Planity : fond blanc, bordure discrète, un titre, une icône.
// Sert d'entrée vers un élément déjà existant du site (lieu, budget, playlist…).
export default function PhaseCard({ to, onClick, icon: Icon, title, hint }) {
  const inner = (
    <div className="group flex items-center gap-4 rounded-xl border border-border bg-card p-5 transition-colors hover:border-foreground/30">
      <div className="flex h-11 w-11 shrink-0 items-center justify-center text-foreground/70 group-hover:text-foreground transition-colors">
        <Icon className="h-5 w-5" aria-hidden="true" />
      </div>
      <div className="min-w-0 flex-1">
        <p className="text-sm font-medium text-foreground">{title}</p>
        {hint && <p className="mt-0.5 text-xs text-foreground/50 truncate">{hint}</p>}
      </div>
      <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground/50 group-hover:text-foreground/60 transition-colors" aria-hidden="true" />
    </div>
  );

  if (onClick) {
    return (
      <button type="button" onClick={onClick} className="block w-full text-left">
        {inner}
      </button>
    );
  }
  return <Link to={to}>{inner}</Link>;
}