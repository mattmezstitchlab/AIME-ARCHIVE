import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import {
  Music, Camera, Sparkles, Home, UtensilsCrossed, ClipboardList,
  Shirt, Palette, Truck, ChevronDown, Check, Search, Loader2, FolderHeart,
} from "lucide-react";
import { PROVIDER_DOMAINS, totalProviderJobs } from "@/lib/providerDomains";
import { Button } from "@/components/ui/button";
import HomeReveal from "@/components/home/HomeReveal";
import { useJourJPlan } from "@/lib/wedding/useJourJPlan";

const ICONS = { Music, Camera, Sparkles, Home, UtensilsCrossed, ClipboardList, Shirt, Palette, Truck };

// Carte d'un domaine, dépliable pour cocher en place les métiers souhaités (sous-menu / sous-sous-menu).
function TeamDomainCard({ domain, open, onToggle, selected, onToggleRole }) {
  const Icon = ICONS[domain.icon] || Sparkles;
  const count = domain.subdomains.reduce((s, sd) => s + sd.items.length, 0);
  const picked = domain.subdomains.reduce((n, sd) => n + sd.items.filter((i) => selected.has(i)).length, 0);

  return (
    <div className="rounded-2xl border border-border bg-background overflow-hidden">
      <button
        type="button"
        onClick={onToggle}
        aria-expanded={open}
        className="w-full flex items-center gap-3 p-4 text-left hover:bg-muted/40 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-inset"
      >
        <span className="w-10 h-10 rounded-xl bg-foreground text-background flex items-center justify-center shrink-0">
          <Icon className="w-5 h-5" aria-hidden="true" />
        </span>
        <span className="flex-1 min-w-0">
          <span className="block font-semibold text-foreground text-sm">{domain.label}</span>
          <span className="block text-xs text-muted-foreground">
            {domain.subdomains.length} familles · {count} métiers{picked > 0 ? ` · ${picked} choisi${picked > 1 ? "s" : ""}` : ""}
          </span>
        </span>
        <ChevronDown className={`w-4 h-4 text-muted-foreground shrink-0 transition-transform ${open ? "rotate-180" : ""}`} aria-hidden="true" />
      </button>

      {open && (
        <div className="px-4 pb-4 pt-1 space-y-4 border-t border-border">
          {domain.subdomains.map((sd) => (
            <div key={sd.label}>
              <p className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground mb-2 mt-3">{sd.label}</p>
              <div className="flex flex-wrap gap-1.5">
                {sd.items.map((item) => {
                  const on = selected.has(item);
                  return (
                    <button
                      key={item}
                      type="button"
                      onClick={() => onToggleRole(item)}
                      aria-pressed={on}
                      className={`inline-flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-full border transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-1 ${
                        on ? "bg-foreground text-background border-foreground" : "bg-muted text-foreground border-transparent hover:bg-muted/70"
                      }`}
                    >
                      <span className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center shrink-0 ${on ? "bg-background border-background" : "border-muted-foreground/40"}`}>
                        {on && <Check className="w-2.5 h-2.5 text-foreground" aria-hidden="true" />}
                      </span>
                      {item}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// L'équipe du jour : cochez directement, en place, les prestataires souhaités.
// Dépliage par domaine → familles → métiers, sans ouvrir de fenêtre.
export default function WeddingTeamSection() {
  const { plan, patchPlan } = useJourJPlan();
  const [openKey, setOpenKey] = useState(PROVIDER_DOMAINS[0]?.key || null);
  const [selected, setSelected] = useState(() => new Set());
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  // Pré-cocher l'équipe déjà enregistrée dans le dossier (source de vérité).
  useEffect(() => {
    const labels = (plan?.linked_services || []).map((s) => s.label);
    if (labels.length) setSelected(new Set(labels));
  }, [plan?.id]);

  const toggleRole = (item) => {
    setSaved(false);
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(item)) next.delete(item); else next.add(item);
      return next;
    });
  };

  const picks = [...selected];

  // Enregistre l'équipe cochée dans le dossier mariage (linked_services).
  const saveTeam = async () => {
    setSaving(true);
    try {
      const services = picks.map((label) => ({ label, category: label, status: "todo" }));
      await patchPlan({ linked_services: services });
      setSaved(true);
    } finally {
      setSaving(false);
    }
  };

  return (
    <HomeReveal>
      <section className="py-16 sm:py-20 bg-background">
        <div className="max-w-6xl mx-auto px-6">
          <div className="mb-10 max-w-2xl">
            <p className="text-[10px] text-muted-foreground uppercase tracking-[0.2em] font-semibold mb-4">
              L'équipe du jour J
            </p>
            <h2 className="text-3xl sm:text-4xl font-light text-foreground tracking-tight mb-3">
              Composez votre équipe en cochant les prestataires
            </h2>
            <p className="text-muted-foreground leading-relaxed">
              Dépliez un domaine, parcourez les familles et cochez directement les métiers qui composent
              votre jour J — {totalProviderJobs()} prestataires possibles, réunis au même endroit.
            </p>
          </div>

          {picks.length > 0 && (
            <div className="mb-6 rounded-2xl border border-foreground/20 bg-muted/30 p-4">
              <div className="flex items-center justify-between mb-2">
                <p className="text-xs font-semibold text-foreground">Votre équipe ({picks.length})</p>
                <button type="button" onClick={() => setSelected(new Set())} className="text-xs text-muted-foreground hover:text-foreground underline">
                  Tout effacer
                </button>
              </div>
              <div className="flex flex-wrap gap-1.5 mb-4">
                {picks.map((item) => (
                  <button
                    key={item}
                    type="button"
                    onClick={() => toggleRole(item)}
                    aria-label={`Retirer ${item}`}
                    className="inline-flex items-center gap-1 text-xs px-2.5 py-1 rounded-full bg-foreground text-background"
                  >
                    <Check className="w-3 h-3" aria-hidden="true" /> {item}
                  </button>
                ))}
              </div>
              <div className="flex flex-wrap items-center gap-3">
                <Button
                  onClick={saveTeam}
                  disabled={saving}
                  className="rounded-full h-9 px-4 text-sm bg-foreground text-background hover:bg-foreground/90"
                >
                  {saving ? (
                    <><Loader2 className="w-4 h-4 mr-1 animate-spin" aria-hidden="true" /> Enregistrement…</>
                  ) : (
                    <><FolderHeart className="w-4 h-4 mr-1" aria-hidden="true" /> Enregistrer dans mon mariage</>
                  )}
                </Button>
                <Link to={`/recherche?q=${encodeURIComponent(picks[0])}`}>
                  <Button variant="outline" className="rounded-full h-9 px-4 text-sm">
                    <Search className="w-4 h-4 mr-1" aria-hidden="true" /> Trouver mon équipe
                  </Button>
                </Link>
                {saved && <span className="text-xs text-muted-foreground inline-flex items-center gap-1"><Check className="w-3.5 h-3.5" aria-hidden="true" /> Enregistré dans le dossier</span>}
              </div>
            </div>
          )}

          <div className="grid sm:grid-cols-2 gap-3">
            {PROVIDER_DOMAINS.map((domain) => (
              <TeamDomainCard
                key={domain.key}
                domain={domain}
                open={openKey === domain.key}
                onToggle={() => setOpenKey((k) => (k === domain.key ? null : domain.key))}
                selected={selected}
                onToggleRole={toggleRole}
              />
            ))}
          </div>
        </div>
      </section>
    </HomeReveal>
  );
}