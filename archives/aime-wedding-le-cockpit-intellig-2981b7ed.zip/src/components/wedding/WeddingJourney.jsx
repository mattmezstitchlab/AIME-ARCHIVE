import { useState } from "react";
import { Calendar, MapPin, FolderHeart, Compass, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useGuide } from "@/lib/guide/GuideContext";
import { CITY_LIST } from "@/lib/categories";
import { WEDDING_STYLES, WEDDING_BUDGETS, WEDDING_GUESTS } from "@/lib/wedding";
import WeddingStartPanel from "@/components/wedding/WeddingStartPanel";

// Chip réutilisable, accessible (aria-pressed), focus visible via tokens.
function Chip({ label, active, onClick }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={`px-3.5 py-2 rounded-full text-sm font-medium border transition-colors min-h-[40px] ${
        active
          ? "bg-foreground text-background border-foreground"
          : "bg-background text-foreground border-border hover:border-foreground"
      }`}
    >
      {active && <Check className="w-3.5 h-3.5 inline mr-1 -mt-0.5" aria-hidden="true" />}
      {label}
    </button>
  );
}

// Parcours interactif court : date, ville, ambiance, budget, invités, priorités.
// Crée un dossier vivant (GuidePlan) connecté, ou local sinon (état clair ensuite).
export default function WeddingJourney() {
  const { openGuide } = useGuide();
  const [date, setDate] = useState("");
  const [city, setCity] = useState("");
  const [style, setStyle] = useState("");
  const [budget, setBudget] = useState(null);
  const [guests, setGuests] = useState(null);
  const [startOpen, setStartOpen] = useState(false);

  // Construit une description lisible à partir des choix rapides — utilisée comme
  // pré-remplissage de l'intention. Aucune création tant que l'utilisateur ne valide pas.
  const buildHint = () => {
    const budgetLabel = WEDDING_BUDGETS.find((b) => b.value === budget)?.label;
    const guestsLabel = WEDDING_GUESTS.find((g) => g.value === guests)?.label;
    const bits = [
      "Préparer mon mariage",
      city ? `à ${city}` : "",
      date ? `le ${date}` : "",
      style ? `ambiance ${style.toLowerCase()}` : "",
      guestsLabel ? `${guestsLabel} invités` : "",
      budgetLabel ? `budget ${budgetLabel}` : "",
    ].filter(Boolean);
    return bits.join(", ") + ".";
  };

  return (
    <div className="rounded-2xl border border-border bg-background p-6 sm:p-8 shadow-sm">
      <h2 className="text-2xl font-light text-foreground tracking-tight mb-1">Commencez en 1 minute</h2>
      <p className="text-sm text-muted-foreground mb-8">
        Quelques choix rapides pour décrire votre projet. Vous validerez votre demande avant qu'un dossier soit créé.
      </p>

      <div className="grid sm:grid-cols-2 gap-6 mb-8">
        {/* Date */}
        <div>
          <label htmlFor="wedding-date" className="block text-sm font-medium text-foreground mb-2">
            <Calendar className="w-4 h-4 inline mr-1.5 -mt-0.5" aria-hidden="true" /> Date (ou à préciser)
          </label>
          <Input
            id="wedding-date"
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            className="rounded-lg"
          />
        </div>

        {/* Ville */}
        <div>
          <label htmlFor="wedding-city" className="block text-sm font-medium text-foreground mb-2">
            <MapPin className="w-4 h-4 inline mr-1.5 -mt-0.5" aria-hidden="true" /> Ville / région
          </label>
          <Input
            id="wedding-city"
            list="wedding-cities"
            value={city}
            onChange={(e) => setCity(e.target.value)}
            placeholder="Ex. Lyon"
            className="rounded-lg"
          />
          <datalist id="wedding-cities">
            {CITY_LIST.map((c) => <option key={c} value={c} />)}
          </datalist>
        </div>
      </div>

      {/* Ambiance */}
      <fieldset className="mb-8">
        <legend className="text-sm font-medium text-foreground mb-3">Ambiance</legend>
        <div className="flex flex-wrap gap-2">
          {WEDDING_STYLES.map((s) => (
            <Chip key={s} label={s} active={style === s} onClick={() => setStyle(style === s ? "" : s)} />
          ))}
        </div>
      </fieldset>

      {/* Budget */}
      <fieldset className="mb-8">
        <legend className="text-sm font-medium text-foreground mb-3">Budget approximatif</legend>
        <div className="flex flex-wrap gap-2">
          {WEDDING_BUDGETS.map((b) => (
            <Chip key={b.value} label={b.label} active={budget === b.value} onClick={() => setBudget(budget === b.value ? null : b.value)} />
          ))}
        </div>
      </fieldset>

      {/* Invités */}
      <fieldset className="mb-8">
        <legend className="text-sm font-medium text-foreground mb-3">Nombre d'invités</legend>
        <div className="flex flex-wrap gap-2">
          {WEDDING_GUESTS.map((g) => (
            <Chip key={g.value} label={g.label} active={guests === g.value} onClick={() => setGuests(guests === g.value ? null : g.value)} />
          ))}
        </div>
      </fieldset>

      <div className="flex flex-col sm:flex-row gap-3 pt-2 border-t border-border">
        <Button onClick={() => setStartOpen(true)} className="rounded-full h-9 px-4 text-sm flex-1 bg-foreground text-background hover:bg-foreground/90">
          <FolderHeart className="w-4 h-4 mr-1" aria-hidden="true" />
          Décrire mon mariage
        </Button>
        <Button
          onClick={() => openGuide(buildHint() + " Aide-moi à organiser les prochaines actions.")}
          className="rounded-full h-9 px-4 text-sm bg-foreground text-background hover:bg-foreground/90"
        >
          <Compass className="w-4 h-4 mr-1" aria-hidden="true" /> Demander au Guide
        </Button>
      </div>
      <p className="text-xs text-muted-foreground mt-3">
        Aucun dossier n'est créé tant que vous n'avez pas validé votre demande. Connecté, il est enregistré dans votre compte.
      </p>

      <WeddingStartPanel open={startOpen} onOpenChange={setStartOpen} contextHint={buildHint()} />
    </div>
  );
}