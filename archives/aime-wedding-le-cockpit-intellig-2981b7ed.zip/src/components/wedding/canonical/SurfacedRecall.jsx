import { Link } from "react-router-dom";
import { MapPin, Users, Heart, ArrowUpRight } from "lucide-react";
import { resolveSurfacedFor, resolveSurfacedForSurface } from "@/lib/wedding/canonical/resolve";

// Icône par domaine canonique.
const ICONS = {
  lieu_reception: MapPin,
  prestataires: Users,
  ceremonies: Heart,
};

// Rappel canonique « saisie unique → réapparition multi-vues ».
// Affiche, en LECTURE SEULE, ce qui a déjà été saisi ailleurs et qui est
// pertinent sur cette route. Un lien discret renvoie vers le propriétaire
// canonique pour compléter. Ne saisit rien ici : pas de double saisie.
//
// Props (route OU surfaceKey — surfaceKey prioritaire) :
//   surfaceKey  clé de surface canonique explicite (ex. "invite.accueil"),
//               pour les surfaces sans route fixe (vue publique invité dynamique)
//   route       route courante (traduite en clé de surface via le registre)
//   plan        dossier mariage (GuidePlan)
//   role        rôle actif (filtre la visibilité)
export default function SurfacedRecall({ surfaceKey, route, plan, role = "couple" }) {
  const surfaced = surfaceKey
    ? resolveSurfacedForSurface(surfaceKey, plan, role)
    : resolveSurfacedFor(route, plan, role);
  if (!surfaced.length) return null;

  return (
    <div className="mb-6 rounded-2xl border border-border bg-muted/40 px-4 py-4 sm:px-5">
      <p className="mb-3 text-[11px] font-semibold uppercase tracking-[0.14em] text-foreground/45">
        Déjà renseigné ailleurs
      </p>
      <ul className="space-y-2.5">
        {surfaced.map((item) => {
          const Icon = ICONS[item.id] || MapPin;
          return (
            <li key={item.id} className="flex items-start gap-3">
              <span className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-background border border-border">
                <Icon className="h-3.5 w-3.5 text-foreground/55" aria-hidden="true" />
              </span>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium text-foreground">
                  {item.label}
                  <span className="ml-2 font-normal text-foreground/45">{item.value}</span>
                </p>
                <RecallDetail item={item} />
              </div>
              <Link
                to={item.owner_route}
                className="shrink-0 inline-flex items-center gap-0.5 text-[11px] text-foreground/40 hover:text-foreground transition-colors"
              >
                Compléter <ArrowUpRight className="h-3 w-3" aria-hidden="true" />
              </Link>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

// Aperçu lecture seule du contenu d'un objet canonique.
function RecallDetail({ item }) {
  if (item.id === "prestataires") {
    return (
      <p className="mt-0.5 truncate text-xs text-foreground/45">
        {item.items.slice(0, 4).map((p) => p.name).join(" · ")}
        {item.items.length > 4 ? ` +${item.items.length - 4}` : ""}
      </p>
    );
  }
  if (item.id === "ceremonies") {
    return (
      <p className="mt-0.5 truncate text-xs text-foreground/45">
        {item.items
          .map((c) => [c.type, c.time, c.place].filter(Boolean).join(" "))
          .filter(Boolean)
          .join(" · ")}
      </p>
    );
  }
  return null;
}