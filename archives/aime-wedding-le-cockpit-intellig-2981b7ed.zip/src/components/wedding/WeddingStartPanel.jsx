import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Loader2, FolderHeart, ArrowRight, Compass } from "lucide-react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { buildWeddingDraft } from "@/lib/guide/templates";
import { extractWeddingContext } from "@/lib/wedding/extract";
import { saveOrEnrichWeddingPlan, findWeddingPlan } from "@/lib/guide/plans";

// Panneau de démarrage mariage NON destructif.
// N'écrit rien tant que l'utilisateur n'a pas envoyé sa demande.
// Si un dossier mariage existe déjà, propose de le continuer (pas de doublon).
export default function WeddingStartPanel({ open, onOpenChange, contextHint = "" }) {
  const navigate = useNavigate();
  const [intent, setIntent] = useState("");
  const [busy, setBusy] = useState(false);
  const [existing, setExisting] = useState(null);
  const [checking, setChecking] = useState(false);
  const [forceNew, setForceNew] = useState(false);

  useEffect(() => {
    if (!open) {
      setIntent("");
      setForceNew(false);
      return;
    }
    if (contextHint) setIntent(contextHint);
    setChecking(true);
    findWeddingPlan()
      .then(setExisting)
      .catch(() => setExisting(null))
      .finally(() => setChecking(false));
  }, [open]);

  const submit = async () => {
    const text = (intent || contextHint || "Préparer mon mariage").trim();
    setBusy(true);
    try {
      const ctx = extractWeddingContext(text);
      const draft = buildWeddingDraft({ intentText: text, ...ctx });
      const { plan, persisted, created } = await saveOrEnrichWeddingPlan({
        draft,
        intentText: text,
        ctx,
        sourceRoute: window.location.pathname,
        reuseExisting: !forceNew,
      });
      onOpenChange(false);
      navigate(`/mon-compte/plans/${plan.id}${persisted ? "" : "?guest=1"}${created ? "?created=1" : ""}`);
    } catch {
      setBusy(false);
    }
  };

  const continueExisting = () => {
    if (!existing) return;
    onOpenChange(false);
    navigate(`/mon-compte/plans/${existing.id}`);
  };

  const showExisting = existing && !forceNew;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-xl font-light">
            {showExisting ? "Continuer votre mariage" : "Décrivez votre mariage"}
          </DialogTitle>
          <DialogDescription>
            {showExisting
              ? "Vous avez déjà un dossier en cours. Continuez-le, ou démarrez-en un nouveau."
              : "Le Guide comprend votre demande et prépare un dossier vivant. Rien n'est créé tant que vous n'avez pas envoyé."}
          </DialogDescription>
        </DialogHeader>

        {checking ? (
          <div className="py-8 flex justify-center">
            <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" aria-hidden="true" />
          </div>
        ) : showExisting ? (
          <div className="space-y-4">
            <div className="rounded-xl border border-border bg-muted/30 p-4">
              <p className="text-sm font-medium text-foreground">{existing.title || "Mariage — à préciser"}</p>
              <p className="text-xs text-muted-foreground mt-1">Dossier en préparation</p>
            </div>
            <div className="flex flex-col sm:flex-row gap-2">
              <Button onClick={continueExisting} className="flex-1 h-9 text-sm rounded-full bg-foreground text-background hover:bg-foreground/90">
                <FolderHeart className="w-4 h-4 mr-1" aria-hidden="true" /> Continuer mon mariage
                <ArrowRight className="w-4 h-4 ml-1" aria-hidden="true" />
              </Button>
              <Button variant="outline" onClick={() => setForceNew(true)} className="h-9 text-sm rounded-full">
                Créer un nouveau dossier
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div>
              <label htmlFor="wedding-intent" className="sr-only">Décrivez votre mariage</label>
              <Textarea
                id="wedding-intent"
                value={intent}
                onChange={(e) => setIntent(e.target.value)}
                placeholder="Décrivez votre mariage : date, ville, ambiance, invités, priorités…"
                rows={4}
                className="resize-none"
                autoFocus
              />
            </div>
            <p className="text-xs text-muted-foreground flex items-center gap-1.5">
              <Compass className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
              Ex. « Mariage à Lyon le 12 septembre 2026, ambiance champêtre, 120 invités, priorité photo et musique. »
            </p>
            <div className="flex flex-col sm:flex-row gap-2 pt-2 border-t border-border">
              <Button
                onClick={submit}
                disabled={busy}
                className="flex-1 h-9 text-sm rounded-full bg-foreground text-background hover:bg-foreground/90"
              >
                {busy ? <Loader2 className="w-4 h-4 mr-1 animate-spin" aria-hidden="true" /> : <FolderHeart className="w-4 h-4 mr-1" aria-hidden="true" />}
                Préparer le dossier
              </Button>
              <Button variant="outline" onClick={() => onOpenChange(false)} disabled={busy} className="h-9 text-sm rounded-full">
                Annuler
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}