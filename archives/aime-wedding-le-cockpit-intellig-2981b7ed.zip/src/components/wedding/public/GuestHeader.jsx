import { Heart, CalendarDays, MapPin } from "lucide-react";
import { formatLongDate } from "@/lib/wedding/publicsite";
import { countdownLabel } from "@/lib/wedding/countdown";

export default function GuestHeader({ info, theme }) {
  const countdown = countdownLabel(info.event_date);
  const headingCls = theme.dark ? "text-white" : "text-foreground";
  const mutedCls = theme.dark ? "text-white/60" : "text-muted-foreground";

  return (
    <header className="text-center pt-10 pb-6 px-6">
      {info.cover_image_url && (
        <div className="relative h-44 sm:h-56 w-full overflow-hidden rounded-2xl mb-6 mx-auto max-w-md">
          <img src={info.cover_image_url} alt="" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent" />
        </div>
      )}

      <Heart className={`w-6 h-6 mx-auto mb-3 ${theme.accentText}`} aria-hidden="true" />
      <h1 className={`text-2xl sm:text-3xl font-light mb-2 ${headingCls}`}>
        {info.title}
      </h1>

      {countdown && (
        <p className={`text-[11px] uppercase tracking-[0.2em] font-semibold mb-2 ${theme.accentText}`}>
          {countdown}
        </p>
      )}

      <div className={`flex flex-wrap items-center justify-center gap-x-4 gap-y-1 text-sm ${mutedCls}`}>
        {info.event_date && (
          <span className="inline-flex items-center gap-1">
            <CalendarDays className="w-3.5 h-3.5" aria-hidden="true" />
            {formatLongDate(info.event_date)}
          </span>
        )}
        {(info.venue || info.city) && (
          <span className="inline-flex items-center gap-1">
            <MapPin className="w-3.5 h-3.5" aria-hidden="true" />
            {[info.venue, info.city].filter(Boolean).join(" · ")}
          </span>
        )}
      </div>

      {info.message && (
        <p className={`text-sm leading-relaxed italic mt-4 px-2 ${theme.dark ? "text-white/80" : "text-foreground/80"}`}>
          « {info.message} »
        </p>
      )}
    </header>
  );
}