import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";

const MODULES = [
  { title: "Prestataires", to: "/avant/prestataires", description: "Shortlist et postes réservés", image: "https://media.base44.com/images/public/6a4121ee87663bd9b9c98ef7/d30a6d8da_generated_image.png" },
  { title: "Style & inspirations", to: "/avant/style-inspirations", description: "Palette, moodboard et fleurs", image: "https://media.base44.com/images/public/6a4121ee87663bd9b9c98ef7/c505d4c34_generated_image.png" },
  { title: "Invités / RSVP", to: "/invites-rsvp", description: "Présences et hébergement", image: "https://media.base44.com/images/public/6a4121ee87663bd9b9c98ef7/1c8c2d741_generated_image.png" },
  { title: "Playlist", to: "/playlist", description: "Titres souhaités et interdits", image: "https://media.base44.com/images/public/6a4121ee87663bd9b9c98ef7/a7e885f67_generated_image.png" },
  { title: "Budget", to: "/mariage/budget", description: "Postes, devis et acomptes", image: "https://media.base44.com/images/public/6a4121ee87663bd9b9c98ef7/ffed54efb_generated_image.png" },
  { title: "Galerie", to: "/galerie", description: "Comparez les photographes", image: "https://media.base44.com/images/public/6a4121ee87663bd9b9c98ef7/b44d6a8d8_generated_image.png" },
];

function Tile({ mod }) {
  return (
    <Link
      to={mod.to}
      className="group relative flex aspect-square flex-col justify-end overflow-hidden"
    >
      <img src={mod.image} alt="" className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" loading="lazy" />
      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
      <div className="relative px-4 pb-4">
        <h3 className="text-sm font-semibold text-white">{mod.title}</h3>
        <p className="mt-0.5 text-[11px] leading-snug text-white/60">{mod.description}</p>
      </div>
      <ArrowRight className="absolute right-3 top-3 h-3.5 w-3.5 text-white/30 transition-transform group-hover:translate-x-0.5" aria-hidden="true" />
    </Link>
  );
}

export default function AvantModules() {
  return (
    <div className="grid grid-cols-2">
      {MODULES.map((mod) => (
        <Tile key={mod.title} mod={mod} />
      ))}
    </div>
  );
}