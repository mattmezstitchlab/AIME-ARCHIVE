import { Link } from "react-router-dom";
import { Heart, Users, Home, Briefcase, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import HomeReveal from "@/components/home/HomeReveal";

// Collaborer — qui peut rejoindre le dossier. Présenté comme préparation,
// sans faux accès à des données privées : les invitations restent des brouillons.
const ROLES = [
  { icon: Heart, label: "Conjoint·e", desc: "Décider à deux", role: "conjoint" },
  { icon: Users, label: "Témoin", desc: "Donner un coup de main", role: "temoin" },
  { icon: Home, label: "Famille", desc: "Avis & coordination", role: "famille" },
  { icon: Briefcase, label: "Wedding planner / prestataire", desc: "Suivre le dossier ensemble", role: "planner" },
];

export default function WeddingCollaborateSection() {
  return (
    <HomeReveal>
      <section className="py-16 sm:py-20 bg-background">
        <div className="max-w-6xl mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-10 lg:gap-16 items-center">
            <div>
              <p className="text-[10px] text-muted-foreground uppercase tracking-[0.2em] font-semibold mb-4">
                Collaborer
              </p>
              <h2 className="text-3xl sm:text-4xl font-light text-foreground tracking-tight mb-4">
                À plusieurs, c'est plus simple
              </h2>
              <p className="text-muted-foreground leading-relaxed mb-6">
                Invitez votre conjoint·e, un témoin, la famille ou un wedding planner à suivre le dossier.
                Les invitations sont préparées en brouillon — aucun e-mail n'est envoyé sans votre accord.
              </p>
              <Link to="/mon-compte/plans">
                <Button className="bg-foreground text-background hover:bg-foreground/90 rounded-full h-9 px-4 text-sm">
                  Voir mon mariage <ArrowRight className="w-4 h-4 ml-1" aria-hidden="true" />
                </Button>
              </Link>
            </div>

            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {ROLES.map((r) => (
                <li key={r.label}>
                  <Link
                    to={`/mon-compte?tab=plans&invite=${r.role}`}
                    aria-label={`Inviter : ${r.label}`}
                    className="group flex items-start gap-3 rounded-xl border border-border bg-background p-4 hover:border-foreground transition-colors"
                  >
                    <span className="flex items-center justify-center w-9 h-9 rounded-full bg-muted text-foreground shrink-0 group-hover:bg-foreground group-hover:text-background transition-colors">
                      <r.icon className="w-4 h-4" aria-hidden="true" />
                    </span>
                    <span className="min-w-0">
                      <span className="block font-semibold text-foreground text-sm group-hover:underline underline-offset-4">{r.label}</span>
                      <span className="block text-xs text-muted-foreground leading-snug mt-0.5">{r.desc}</span>
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>
    </HomeReveal>
  );
}