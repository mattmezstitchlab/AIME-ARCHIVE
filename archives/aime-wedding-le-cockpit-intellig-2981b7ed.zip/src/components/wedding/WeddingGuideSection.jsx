import { MapPin, ListChecks, FolderHeart } from "lucide-react";
import HomeReveal from "@/components/home/HomeReveal";

// « Le Guide prépare le calme » — 3 exemples concrets de ce que fait le Guide.
const EXAMPLES = [
  {
    icon: MapPin,
    tag: "Le Guide complète",
    text: "« Il manque la ville : je vous propose de la préciser pour trouver les bons prestataires. »",
  },
  {
    icon: ListChecks,
    tag: "Le Guide priorise",
    text: "« Trois postes sont prioritaires pour vous : photo, lieu et musique. On commence par ça. »",
  },
  {
    icon: FolderHeart,
    tag: "Le Guide agit",
    text: "« J'ai créé le dossier et la checklist dans votre compte. Voici les prochaines actions. »",
  },
];

export default function WeddingGuideSection() {
  return (
    <HomeReveal>
      <section className="py-16 sm:py-20 bg-muted/40 border-y border-border">
        <div className="max-w-6xl mx-auto px-6">
          <div className="mb-10 max-w-2xl">
            <p className="text-[10px] text-muted-foreground uppercase tracking-[0.2em] font-semibold mb-4">
              Le Guide prépare le calme
            </p>
            <h2 className="text-3xl sm:text-4xl font-light text-foreground tracking-tight mb-3">
              Vous exprimez l'intention, Le Guide structure
            </h2>
            <p className="text-muted-foreground leading-relaxed">
              Pas de tableur, pas de stress. Le Guide complète ce qui manque, hiérarchise les priorités
              et range tout dans un dossier qui avance.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {EXAMPLES.map((e, i) => (
              <HomeReveal key={i} delay={i * 80}>
                <div className="rounded-xl border border-border bg-background p-6 h-full">
                  <span className="flex items-center justify-center w-10 h-10 rounded-full bg-muted text-foreground mb-4">
                    <e.icon className="w-5 h-5" aria-hidden="true" />
                  </span>
                  <p className="text-[10px] uppercase tracking-[0.15em] font-semibold text-muted-foreground mb-2">{e.tag}</p>
                  <p className="text-foreground text-[15px] leading-relaxed">{e.text}</p>
                </div>
              </HomeReveal>
            ))}
          </div>
        </div>
      </section>
    </HomeReveal>
  );
}