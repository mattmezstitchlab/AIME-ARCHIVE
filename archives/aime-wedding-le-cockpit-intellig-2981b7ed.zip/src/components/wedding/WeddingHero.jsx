import { useState } from "react";
import { Link } from "react-router-dom";
import { FolderHeart, Search, Compass } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useGuide } from "@/lib/guide/GuideContext";
import WeddingStartPanel from "@/components/wedding/WeddingStartPanel";

// Hero mariage : grand visuel de fond crédible, texte simple.
// Action principale NON destructive : ouvre un panneau d'intention (aucun dossier créé au clic).
export default function WeddingHero() {
  const { openGuide } = useGuide();
  const [startOpen, setStartOpen] = useState(false);

  return (
    <section className="relative min-h-[70vh] flex items-center overflow-hidden">
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1519225421980-715cb0215aed?w=1600&q=80"
          alt="Couple lors d'une cérémonie de mariage en extérieur"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-foreground/60" aria-hidden="true" />
      </div>

      <div className="relative max-w-6xl mx-auto px-6 py-20 w-full">
        <p className="text-[10px] text-background/70 uppercase tracking-[0.25em] font-semibold mb-5">
          Artistry Wedding
        </p>
        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-light text-background leading-[1.05] tracking-tight mb-5 max-w-3xl">
          Votre mariage devient un dossier qui avance.
        </h1>
        <p className="text-background/80 text-base sm:text-lg leading-relaxed mb-8 max-w-xl">
          Décrivez votre projet : Le Guide comprend votre demande et prépare un dossier vivant —
          photo, lieu, musique, beauté, fleurs et plus encore.
        </p>

        <div className="flex flex-col sm:flex-row flex-wrap gap-3">
          <Button
            onClick={() => setStartOpen(true)}
            className="bg-foreground text-background hover:bg-foreground/90 rounded-full h-9 px-4 text-sm w-full sm:w-auto"
          >
            <FolderHeart className="w-4 h-4 mr-1" aria-hidden="true" /> Commencer mon mariage
          </Button>
          <Link to="/recherche?q=Photographe">
            <Button className="bg-foreground text-background hover:bg-foreground/90 rounded-full h-9 px-4 text-sm w-full sm:w-auto">
              <Search className="w-4 h-4 mr-1" aria-hidden="true" /> Voir les prestataires
            </Button>
          </Link>
          <Button
            onClick={() => openGuide("Je prépare mon mariage. Aide-moi à organiser les prochaines actions.")}
            className="bg-foreground text-background hover:bg-foreground/90 rounded-full h-9 px-4 text-sm w-full sm:w-auto"
          >
            <Compass className="w-4 h-4 mr-1" aria-hidden="true" /> Demander au Guide
          </Button>
        </div>
      </div>

      <WeddingStartPanel open={startOpen} onOpenChange={setStartOpen} />
    </section>
  );
}