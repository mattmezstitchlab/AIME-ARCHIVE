// LA BULLE-LOUPE — la date en arc-en-ciel, puis : ce que l'on croit VS ce
// que l'on ne savait pas, et l'interdit. Le flou devient net.
const ARC = "linear-gradient(90deg, #ff5f6d, #ffc371, #c9f76f, #38bdf8, #c084fc)";

export default function MeLoupeBulle({ event, x }) {
  const left = Math.max(12, Math.min(x - 150, (window.innerWidth || 1200) - 312));
  return (
    <div
      className="pointer-events-none fixed top-[20px] z-[70] w-[300px] rounded-xl border border-white/15 bg-black/95 p-3.5 shadow-2xl backdrop-blur-md"
      style={{ left }}
      role="status"
    >
      <p
        className="font-mono text-[14px] font-bold tracking-wide"
        style={{ backgroundImage: ARC, WebkitBackgroundClip: "text", backgroundClip: "text", color: "transparent" }}
      >
        {event.date}
      </p>
      <p className="mt-0.5 text-[11.5px] font-semibold text-white/90">{event.titre}</p>
      {event.type === "brisure" && (
        <p className="mt-0.5 font-mono text-[9px] uppercase tracking-[0.18em] text-white/50">Non-dit brisé — archivé par l'Académie</p>
      )}
      {event.type === "lignee" && (
        <p className="mt-0.5 font-mono text-[9px] uppercase tracking-[0.18em] text-[#c084fc]">La lignée vivante — instant T</p>
      )}
      {event.annees && (
        <p className="mt-1.5 inline-block rounded-md border border-[#c9a96e]/40 bg-[#c9a96e]/10 px-2 py-0.5 font-mono text-[10px] font-semibold text-[#c9a96e]">
          {event.annees}
        </p>
      )}
      {/* La graduation intermédiaire : la date manquante entre deux repères. */}
      {event.manque && (
        <p className="mt-2 text-[10.5px] leading-4 text-white/50">{event.manque}</p>
      )}
      {event.croit && (
        <p className="mt-2 text-[10.5px] leading-4 text-white/45">
          <span className="font-semibold text-white/60">Ce que l'on croit — </span>{event.croit}
        </p>
      )}
      {event.verite && (
        <p className="mt-1.5 text-[10.5px] leading-4 text-white/65">
          <span className="font-semibold text-[#c9a96e]">Ce que l'on ne savait pas — </span>{event.verite}
        </p>
      )}
      {event.interdit && (
        <p className="mt-1.5 text-[10.5px] italic leading-4 text-red-300/75">
          <span className="font-semibold not-italic">L'interdit — </span>{event.interdit}
        </p>
      )}
    </div>
  );
}