import { useState, useRef, useEffect } from "react";
import { CHRONOLOGIE_VERITES, TICKS, formatAnnee, infoGraduation } from "@/lib/me/chronologieVerites";
import MeLoupeBulle from "./MeLoupeBulle";

// LA GRADUATION ME — la frise temporelle du haut du site.
// · 1024 petites graduations, CHACUNE vivante : entre deux repères, le survol
//   révèle la date manquante (interpolée) — le flou rendu net.
// · Zoomable (boutons − / +) et DÉFILABLE à la souris (glisser) comme une
//   frise, de la création de la Terre à l'horizon +3 ans.
const couleur = (t) => (t === "brisure" ? "rgba(255,255,255,0.85)" : t === "lignee" ? "#c084fc" : "#c9a96e");
const SEUIL = 5; // à moins de 5 graduations d'un repère, c'est le repère qui parle.

export default function MeGraduation({ pulse, filtre = "tous", bulle = true }) {
  const [hover, setHover] = useState(null); // { event, px }
  // Le filtre de l'espace perso : tous / vérités / brisures / lignée.
  const evs = filtre === "tous" ? CHRONOLOGIE_VERITES : CHRONOLOGIE_VERITES.filter((e) => e.type === filtre);
  const [zoom, setZoom] = useState(1); // 1× → 16×
  const scrollRef = useRef(null);
  const stripRef = useRef(null);
  const drag = useRef(null);

  // Le zoom se pilote depuis le header : les boutons − / + autour du « + » central.
  useEffect(() => {
    const h = (e) => setZoom((z) => (e.detail === "in" ? Math.min(16, z * 2) : Math.max(1, z / 2)));
    window.addEventListener("aime-frise-zoom", h);
    return () => window.removeEventListener("aime-frise-zoom", h);
  }, []);

  const onMove = (e) => {
    // Couche personnelle (page-personne) : pas de bulle des vérités historiques.
    if (!bulle) return;
    if (drag.current) {
      scrollRef.current.scrollLeft = drag.current.scroll - (e.clientX - drag.current.x);
      return;
    }
    const rect = stripRef.current.getBoundingClientRect();
    const t = Math.round(((e.clientX - rect.left) / rect.width) * (TICKS - 1));
    let best = evs[0];
    for (const ev of evs) {
      if (Math.abs(ev.tick - t) < Math.abs(best.tick - t)) best = ev;
    }
    if (Math.abs(best.tick - t) <= SEUIL) {
      setHover({ event: best, px: rect.left + (best.tick / (TICKS - 1)) * rect.width });
    } else {
      // La graduation intermédiaire : sa date manquante, interpolée.
      const { annee, avant, apres } = infoGraduation(t);
      setHover({
        px: e.clientX,
        event: {
          type: "graduation",
          date: formatAnnee(annee),
          titre: `Graduation ${t + 1} / ${TICKS}`,
          manque: `Entre « ${avant.titre} » (${avant.date}) et « ${apres.titre} » (${apres.date}). Les vérités et non-dits de cette date restent à graduer — le flou en cours de mise au net.`,
        },
      });
    }
  };

  const startDrag = (e) => {
    if (zoom <= 1) return;
    drag.current = { x: e.clientX, scroll: scrollRef.current.scrollLeft };
  };
  const endDrag = () => { drag.current = null; };

  return (
    <div className="absolute inset-x-0 top-0 z-[5]" onMouseLeave={() => { setHover(null); endDrag(); }}>
      <div ref={scrollRef} className="overflow-x-hidden">
        <div
          ref={stripRef}
          onMouseMove={onMove}
          onMouseDown={startDrag}
          onMouseUp={endDrag}
          className={`relative h-[16px] ${zoom > 1 ? "cursor-grab active:cursor-grabbing" : "cursor-crosshair"}`}
          style={{ width: `${zoom * 100}%` }}
          aria-hidden="true"
        >
          {/* Les 1024 petites graduations — toutes vivantes au survol. */}
          <div
            className="absolute inset-x-0 top-0 h-[8px]"
            style={{
              backgroundImage: "linear-gradient(to right, rgba(255,255,255,0.25) 0px, rgba(255,255,255,0.25) 1px, transparent 1px)",
              backgroundSize: `calc(100% / ${TICKS}) 100%`,
            }}
          />
          {/* Les repères — or / blanc / violet. Le survolé s'allonge. */}
          {evs.map((ev) => {
            const actif = hover?.event.tick === ev.tick;
            return (
              <span
                key={ev.tick}
                className={`absolute top-0 -translate-x-1/2 transition-all duration-150 ${pulse ? "me-blink" : ""}`}
                style={{
                  left: `${(ev.tick / (TICKS - 1)) * 100}%`,
                  width: actif ? 3 : 2,
                  height: actif ? 16 : 10,
                  background: couleur(ev.type),
                  boxShadow: actif ? `0 0 8px 1px ${couleur(ev.type)}` : "none",
                }}
              />
            );
          })}
        </div>
      </div>

      {hover && <MeLoupeBulle event={hover.event} x={hover.px} />}
    </div>
  );
}