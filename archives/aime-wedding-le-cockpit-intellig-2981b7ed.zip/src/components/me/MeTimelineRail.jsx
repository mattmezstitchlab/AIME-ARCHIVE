import { useMemo, useState } from "react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

const N = 56;

// LA LIGNE GRADUÉE — les graduations façon codex : petits traits, plus longs
// tous les 7, qui s'étirent et révèlent leur horodatage au survol. Les repères
// ZÉRO sont des points dorés cliquables.
export default function MeTimelineRail({ echelle, reperes, wave, blink }) {
  const [openId, setOpenId] = useState(null);
  const { start, now, ticks } = useMemo(() => {
    const now = Date.now();
    const start = now - echelle.span;
    return { start, now, ticks: Array.from({ length: N + 1 }, (_, i) => start + (i / N) * echelle.span) };
  }, [echelle]);

  return (
    <div className="relative flex-1 overflow-hidden py-3">
      {/* La ligne verticale — l'onde la parcourt quand un repère est posé. */}
      <span className={`absolute bottom-0 left-[62px] top-0 w-px bg-white/15 ${wave ? "me-onde-line" : ""}`} />

      {ticks.map((ts, i) => {
        const major = i % 7 === 0;
        return (
          <div key={i} className="group absolute left-0 flex w-full items-center gap-2" style={{ top: `${(i / N) * 100}%` }}>
            <span
              className={`w-[52px] text-right font-mono text-[8.5px] transition-colors ${
                major ? "text-white/35" : "text-transparent"
              } group-hover:text-white/75`}
            >
              {format(ts, echelle.fmt, { locale: fr })}
            </span>
            <span
              className={`block bg-white/25 transition-all duration-150 group-hover:bg-white ${
                major ? "h-px w-5" : "h-px w-2.5"
              } group-hover:h-[2px] group-hover:w-8`}
            />
          </div>
        );
      })}

      {/* Les repères ZÉRO dans la fenêtre visible. */}
      {reperes.filter((r) => r.ts >= start && r.ts <= now).map((r) => (
        <div key={r.id} className="absolute left-[55px]" style={{ top: `${((r.ts - start) / echelle.span) * 100}%` }}>
          <button
            type="button"
            onClick={() => setOpenId(openId === r.id ? null : r.id)}
            aria-label={`Repère : ${r.text}`}
            className={`block h-3.5 w-3.5 -translate-y-1/2 rounded-full border-2 border-[#0C0C0C] bg-[#c9a96e] shadow-[0_0_10px_rgba(201,169,110,0.65)] transition-transform hover:scale-125 ${
              blink ? "me-blink" : ""
            }`}
          />
          {openId === r.id && (
            <div className="absolute left-6 top-1/2 z-10 w-52 -translate-y-1/2 rounded-lg border border-white/15 bg-black/95 p-2.5 text-left shadow-xl">
              <p className="font-mono text-[9px] uppercase tracking-[0.14em] text-[#c9a96e]">
                {format(r.ts, "d MMM yyyy · HH:mm:ss", { locale: fr })}
              </p>
              <p className="mt-1 text-[11.5px] leading-4 text-white/85">{r.text}</p>
              <p className="mt-1.5 text-[9.5px] leading-3.5 text-white/40">
                Propagation causale : les personnes liées seront informées et invitées à confirmer.
              </p>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}