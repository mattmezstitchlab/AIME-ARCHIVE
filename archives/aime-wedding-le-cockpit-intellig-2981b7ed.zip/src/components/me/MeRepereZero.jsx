import { useState } from "react";
import { CircleDot } from "lucide-react";

// LE REPÈRE ZÉRO — poser une intention (une anecdote, une décision…) :
// au clic, elle est horodatée à la seconde et l'onde se propage sur la ligne.
export default function MeRepereZero({ onAdd }) {
  const [text, setText] = useState("");

  const poser = () => {
    const t = text.trim();
    if (!t) return;
    onAdd(t);
    setText("");
  };

  return (
    <div className="rounded-xl border border-white/10 bg-white/[0.03] p-2.5">
      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        rows={2}
        placeholder="Une intention, une anecdote… posée ici, horodatée à la seconde."
        className="w-full resize-none rounded-lg border border-white/10 bg-black/40 px-2.5 py-2 text-[12px] text-white/85 placeholder:text-white/30 focus:border-[#c9a96e]/50 focus:outline-none"
      />
      <button
        type="button"
        onClick={poser}
        disabled={!text.trim()}
        className="mt-1.5 inline-flex w-full items-center justify-center gap-1.5 rounded-lg bg-[#c9a96e] px-3 py-1.5 text-[11.5px] font-semibold text-black transition hover:bg-[#d8bc85] disabled:opacity-40"
      >
        <CircleDot className="h-3.5 w-3.5" /> Poser le repère ZÉRO
      </button>
    </div>
  );
}