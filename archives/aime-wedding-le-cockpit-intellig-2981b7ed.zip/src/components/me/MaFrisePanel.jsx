import { useState } from "react";
import { Minus, Plus } from "lucide-react";
import MeGraduation from "./MeGraduation";

// MA FRISE — la graduation des 1024 dans l'espace perso, avec filtres.
// La même frise que le header, mais chez soi : filtrable par famille de repères.
const FILTRES = [
  { id: "tous", label: "Tous les repères" },
  { id: "verite", label: "Vérités graduées", dot: "#c9a96e" },
  { id: "brisure", label: "Non-dits brisés", dot: "rgba(255,255,255,0.85)" },
  { id: "lignee", label: "La lignée vivante", dot: "#c084fc" },
];

export default function MaFrisePanel() {
  const [filtre, setFiltre] = useState("tous");
  const zoomer = (dir) => window.dispatchEvent(new CustomEvent("aime-frise-zoom", { detail: dir }));

  return (
    <div>
      <div className="flex flex-wrap items-center gap-1.5">
        {FILTRES.map((f) => (
          <button
            key={f.id}
            type="button"
            aria-pressed={filtre === f.id}
            onClick={() => setFiltre(f.id)}
            className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1 font-mono text-[10px] font-semibold uppercase tracking-[0.14em] transition ${
              filtre === f.id ? "border-[#c9a96e] bg-[#c9a96e]/15 text-white" : "border-white/15 text-white/50 hover:text-white"
            }`}
          >
            {f.dot && <span className="h-1.5 w-1.5 rounded-full" style={{ background: f.dot }} />}
            {f.label}
          </button>
        ))}
        <span className="ml-auto flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => zoomer("out")}
            aria-label="Dézoomer la frise"
            className="flex h-6 w-6 items-center justify-center rounded-full border border-white/15 text-white/50 hover:bg-white/10 hover:text-white"
          >
            <Minus className="h-3 w-3" />
          </button>
          <button
            type="button"
            onClick={() => zoomer("in")}
            aria-label="Zoomer la frise"
            className="flex h-6 w-6 items-center justify-center rounded-full border border-white/15 text-white/50 hover:bg-white/10 hover:text-white"
          >
            <Plus className="h-3 w-3" />
          </button>
        </span>
      </div>

      {/* La frise elle-même — le même moteur que le header, filtré. */}
      <div className="relative mt-4 h-10 rounded-lg border border-white/10 bg-black/40">
        <MeGraduation filtre={filtre} />
      </div>

      <p className="mt-3 text-[11px] leading-4 text-white/40">
        Survolez une graduation pour révéler sa date — les repères filtrés s'allument selon leur famille.
        Le zoom (jusqu'à ×16) puis le glisser font défiler la frise, de la création de la Terre à l'horizon +3 ans.
      </p>
    </div>
  );
}