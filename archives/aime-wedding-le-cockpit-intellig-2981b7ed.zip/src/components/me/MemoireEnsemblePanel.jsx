import { useState } from "react";
import { Link } from "react-router-dom";
import { X, User, Sparkle } from "lucide-react";
import { loadReperes, addRepere, ECHELLES } from "@/lib/me/repereStore";
import MeRepereZero from "./MeRepereZero";
import MeTimelineRail from "./MeTimelineRail";

// ME — MÉMOIRE ENSEMBLE : le panneau latéral DROIT. La timeline verticale
// sur toute la hauteur, graduée d'année en seconde ; en haut, l'accès à la
// page-personne et aux projets ; le repère ZÉRO horodate chaque intention
// et l'onde se propage en faisant clignoter tout ce qui est en lien.
export default function MemoireEnsemblePanel({ onClose }) {
  const [echelle, setEchelle] = useState(ECHELLES[2]); // Jour par défaut
  const [reperes, setReperes] = useState(loadReperes);
  const [wave, setWave] = useState(false);
  const [blink, setBlink] = useState(false);

  const poserRepere = (text) => {
    const r = addRepere(text);
    setReperes((rs) => [r, ...rs]);
    setWave(true);
    setBlink(true);
    setTimeout(() => setWave(false), 3400);
    setTimeout(() => setBlink(false), 2400);
  };

  return (
    <aside
      className="fixed bottom-0 right-0 top-14 z-[70] flex w-[320px] flex-col border-l border-white/10 bg-[#0C0C0C]/95 backdrop-blur-md"
      aria-label="ME — Mémoire Ensemble"
    >
      <div className="flex items-center justify-between border-b border-white/10 px-4 py-3">
        <p className="font-mono text-[10px] font-semibold uppercase tracking-[0.24em] text-white/40">
          <span className="text-[#c9a96e]">ME</span> · Mémoire Ensemble
        </p>
        <button type="button" onClick={onClose} aria-label="Fermer Mémoire Ensemble" className="rounded-full p-1.5 text-white/40 hover:bg-white/10 hover:text-white">
          <X className="h-4 w-4" />
        </button>
      </div>

      <div className="space-y-2.5 px-4 py-3">
        {/* L'accès haut : ma page-personne et mes projets. */}
        <div className="flex gap-1.5">
          <Link to="/registre" onClick={onClose} className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-lg border border-white/10 bg-white/[0.04] px-2 py-1.5 text-[11px] font-medium text-white/70 transition-colors hover:text-white">
            <User className="h-3 w-3 text-[#c9a96e]" /> Ma page
          </Link>
          <Link to="/bureau" onClick={onClose} className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-lg border border-white/10 bg-white/[0.04] px-2 py-1.5 text-[11px] font-medium text-white/70 transition-colors hover:text-white">
            <Sparkle className="h-3 w-3 text-[#c9a96e]" /> Mes projets
          </Link>
        </div>

        <MeRepereZero onAdd={poserRepere} />

        {/* Les graduations : d'année… jusqu'à la seconde. */}
        <div className="flex flex-wrap gap-1">
          {ECHELLES.map((e) => (
            <button
              key={e.id}
              type="button"
              onClick={() => setEchelle(e)}
              className={`rounded-full px-2 py-0.5 font-mono text-[9px] uppercase tracking-[0.12em] transition-colors ${
                echelle.id === e.id ? "bg-white text-black" : "text-white/45 hover:bg-white/10 hover:text-white"
              }`}
            >
              {e.label}
            </button>
          ))}
        </div>
      </div>

      <MeTimelineRail echelle={echelle} reperes={reperes} wave={wave} blink={blink} />
    </aside>
  );
}