import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { format } from "date-fns";
import { Calendar } from "@/components/ui/calendar";
import { Button } from "@/components/ui/button";
import { Clock, Compass } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useGuide } from "@/lib/guide/GuideContext";
import LiveRegion from "@/components/a11y/LiveRegion";
import { format as formatFr } from "date-fns";
import { fr } from "date-fns/locale";
import {
  dayKeyFromDate,
  generateSlots,
  validAvailabilities,
  DEMO_AVAILABILITIES,
  nextAvailableDate,
} from "@/lib/availability";
import PaymentMethodSelector from "@/components/payment/PaymentMethodSelector";
import { paymentDeclarationPath, CASH_THRESHOLD } from "@/lib/payment";

// Mappe le choix UI vers la valeur d'entité method/payment_method
const METHOD_MAP = {
  cash: "cash_declared_on_site",
  transfer: "bank_transfer",
  later: "a_verifier",
};

export default function BookingWidget({ artist }) {
  const [date, setDate] = useState(null);
  const [time, setTime] = useState("");
  const [availabilities, setAvailabilities] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [paymentChoice, setPaymentChoice] = useState("");
  const [acknowledged, setAcknowledged] = useState(false);
  const navigate = useNavigate();
  const { openGuide } = useGuide();

  useEffect(() => {
    base44.entities.Availability.filter({ artist_id: artist.id })
      .then(setAvailabilities)
      .catch(() => setAvailabilities([]));
    base44.entities.Booking.filter({ artist_id: artist.id })
      .then(setBookings)
      .catch(() => setBookings([]));
  }, [artist.id]);

  // Disponibilités réellement exploitables (ouvertes + horaires valides).
  const realAvails = validAvailabilities(availabilities);
  // Mode démonstration : aucun agenda valide publié → on propose des créneaux indicatifs.
  const isDemo = realAvails.length === 0;
  const activeAvails = isDemo ? DEMO_AVAILABILITIES : realAvails;

  // Jours de la semaine ouverts (clés), pour styliser le calendrier.
  const openDayKeys = new Set(activeAvails.map((a) => a.day_of_week));
  const isDayOpen = (d) => openDayKeys.has(dayKeyFromDate(d));

  const dayAvailability = date
    ? activeAvails.find((a) => a.day_of_week === dayKeyFromDate(date))
    : null;
  const bookedTimes = date
    ? bookings
        .filter((b) => b.booking_date === format(date, "yyyy-MM-dd") && b.status !== "cancelled")
        .map((b) => b.booking_time)
    : [];
  const slots = generateSlots(dayAvailability).filter((s) => !bookedTimes.includes(s));

  // Date sélectionnée mais sans créneau publié (cas dispos réelles uniquement).
  const dayHasNoSlots = !!date && slots.length === 0;

  const handleSelectDate = (d) => {
    setDate(d);
    setTime("");
  };

  const goToNextAvailable = () => {
    const next = nextAvailableDate(activeAvails, date || new Date());
    if (next) {
      setDate(next);
      setTime("");
    }
  };

  const isCash = paymentChoice === "cash";
  const overThreshold = (artist.price_from || 0) > CASH_THRESHOLD;
  // Date + horaire suffisent à confirmer (paiement « à définir » par défaut).
  // Seule l'espèces déclarée exige la case de reconnaissance.
  const canConfirm = !!date && !!time && (!isCash || acknowledged);

  // Date lisible en français pour annonce textuelle.
  const dateLabel = date ? formatFr(date, "EEEE d MMMM yyyy", { locale: fr }) : "";

  // Raison textuelle si le bouton « Confirmer » est désactivé.
  const disabledReason = !date
    ? "Sélectionnez d'abord une date."
    : !time
    ? "Sélectionnez un créneau horaire."
    : isCash && !acknowledged
    ? "Confirmez la mention sur le paiement en espèces déclarées."
    : "";

  // Message poli annoncé aux lecteurs d'écran selon l'avancement.
  const liveMessage = error
    ? error
    : dayHasNoSlots
    ? "Aucun créneau disponible ce jour-là."
    : time && date
    ? `Date sélectionnée : ${dateLabel}. Créneau sélectionné : ${time}.`
    : date
    ? `Date sélectionnée : ${dateLabel}.`
    : "";

  const handleBooking = async () => {
    if (!canConfirm) return;
    setSubmitting(true);
    setError("");
    try {
      const user = await base44.auth.me();
      // Aucun choix explicite → « à définir avec l'artiste ».
      const method = METHOD_MAP[paymentChoice] || METHOD_MAP.later;
      const declarationPath = paymentDeclarationPath(artist.category || artist.specialty);
      const booking = await base44.entities.Booking.create({
        artist_id: artist.id,
        artist_name: artist.name,
        client_name: user.full_name || user.email,
        client_email: user.email,
        service: artist.specialty,
        booking_date: format(date, "yyyy-MM-dd"),
        booking_time: time,
        price: artist.price_from,
        status: "pending",
        payment_method: method,
        payment_status: "pending",
      });

      // Suivi de paiement : indispensable pour conserver une trace. On ne masque pas l'échec.
      try {
        await base44.entities.PaymentRecord.create({
          booking_id: booking.id,
          artist_id: artist.id,
          artist_name: artist.name,
          client_name: user.full_name || user.email,
          amount: artist.price_from,
          method,
          status: "pending",
          declaration_path: declarationPath,
          legal_acknowledgement: isCash ? acknowledged : false,
          source_warning: isCash && overThreshold
            ? "Montant élevé : virement ou facture recommandé."
            : "",
        });
      } catch {
        // La réservation existe déjà ; on informe que le suivi n'a pas pu être préparé.
        setError("La réservation est créée, mais le suivi de paiement n'a pas pu être préparé.");
        setSubmitting(false);
        return;
      }

      navigate(`/reservation/confirmation?id=${booking.id}`);
    } catch (err) {
      setError("Une erreur est survenue. Veuillez réessayer.");
      setSubmitting(false);
    }
  };

  return (
    <div className="bg-background rounded-xl border border-border p-6 sticky top-24">
      <div className="flex items-baseline justify-between mb-4">
        <span className="text-sm text-muted-foreground">À partir de</span>
        <span className="text-2xl font-bold text-foreground">{artist.price_from}€</span>
      </div>

      <LiveRegion message={liveMessage} />

      <div className="flex items-center justify-between mb-2">
        <h3 className="text-sm font-medium text-foreground">Choisir une date</h3>
        <button
          type="button"
          onClick={goToNextAvailable}
          className="text-xs font-medium text-foreground underline underline-offset-4 hover:text-foreground/70 transition-colors rounded focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
        >
          Prochaine disponibilité
        </button>
      </div>
      <Calendar
        mode="single"
        locale={fr}
        selected={date}
        onSelect={handleSelectDate}
        disabled={[{ before: new Date() }, (d) => !isDayOpen(d)]}
        modifiers={{ available: (d) => isDayOpen(d) }}
        modifiersClassNames={{ available: "font-semibold text-foreground" }}
        className="rounded-md border mb-3 mx-auto"
        aria-label="Calendrier de réservation. Les jours non disponibles sont désactivés."
      />

      <p className="text-[11px] text-muted-foreground mb-3 flex items-center gap-1.5">
        <span className="inline-block w-2 h-2 rounded-full bg-foreground" aria-hidden="true" />
        Les jours en gras sont réservables.
      </p>

      {/* Date sélectionnée annoncée textuellement (pas seulement visuellement). */}
      {date && (
        <p className="text-xs font-medium text-foreground mb-4 rounded-md bg-muted px-3 py-2">
          Date sélectionnée : <span className="font-semibold">{dateLabel}</span>
        </p>
      )}

      <h3 className="text-sm font-medium text-foreground mb-2 flex items-center gap-1">
        <Clock className="w-4 h-4" aria-hidden="true" /> Créneaux disponibles
      </h3>
      {isDemo && (
        <p className="text-[11px] text-muted-foreground mb-2">
          Créneaux indicatifs — l'artiste confirmera la mission.
        </p>
      )}
      {!date ? (
        <p className="text-xs text-muted-foreground mb-4">Sélectionnez une date pour voir les créneaux.</p>
      ) : dayHasNoSlots ? (
        <div className="mb-4">
          <p className="text-xs text-muted-foreground mb-2">Aucun créneau publié ce jour-là.</p>
          <div className="flex flex-wrap gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={goToNextAvailable}
              className="h-8 text-xs"
            >
              Voir la prochaine date disponible
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => openGuide(`Je souhaite réserver ${artist.name} (${artist.specialty}) mais aucun créneau n'est publié à la date voulue. Comment faire ?`)}
              className="h-8 text-xs"
            >
              <Compass className="w-3.5 h-3.5 mr-1" aria-hidden="true" /> Demander au Guide
            </Button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-4 gap-2 mb-4" role="group" aria-label="Créneaux horaires disponibles">
          {slots.map((slot) => (
            <button
              key={slot}
              type="button"
              onClick={() => setTime(slot)}
              aria-pressed={time === slot}
              aria-label={time === slot ? `Créneau ${slot} sélectionné` : `Choisir le créneau ${slot}`}
              className={`text-xs font-medium py-2 min-h-[40px] rounded-md border transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background ${
                time === slot
                  ? "bg-foreground text-background border-foreground"
                  : "border-border text-foreground hover:bg-muted"
              }`}
            >
              {slot}
            </button>
          ))}
        </div>
      )}

      {time && (
        <PaymentMethodSelector
          value={paymentChoice}
          onChange={setPaymentChoice}
          acknowledged={acknowledged}
          onAcknowledgeChange={setAcknowledged}
          price={artist.price_from}
          category={artist.category || artist.specialty}
        />
      )}

      {error && (
        <p role="alert" className="text-xs text-destructive mb-3 mt-4 flex items-start gap-1.5">
          <span>{error}</span>
        </p>
      )}

      <Button
        onClick={handleBooking}
        disabled={!canConfirm || submitting}
        aria-describedby={disabledReason ? "confirm-help" : undefined}
        className="w-full bg-foreground text-background hover:bg-foreground/90 h-11 mt-4 whitespace-normal"
      >
        {submitting ? "Envoi en cours…" : "Confirmer la réservation"}
      </Button>
      {/* Explique pourquoi le bouton est désactivé — visible et annoncé. */}
      {disabledReason && (
        <p id="confirm-help" className="text-[11px] text-muted-foreground text-center mt-2">
          {disabledReason}
        </p>
      )}
      <p className="text-[11px] text-muted-foreground text-center mt-3">
        Annulation gratuite jusqu'à 48h avant la mission
      </p>
    </div>
  );
}