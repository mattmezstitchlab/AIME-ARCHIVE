import { useState } from "react";
import { ImageIcon } from "lucide-react";
import { fallbackForCategory } from "@/lib/artist-images";

/**
 * Image d'artiste robuste : si l'URL casse, bascule une seule fois vers une image
 * de secours fiable liée à la catégorie, puis affiche un fond propre si tout échoue.
 * Dimensions stables (object-cover), pas de layout shift, alt en français.
 */
export default function ArtistImage({
  src,
  alt,
  className = "",
  fallbackCategory = "",
  fallbackName = "",
  eager = false,
}) {
  const fallbackSrc = fallbackForCategory(fallbackCategory);
  const initial = src || fallbackSrc;
  const [current, setCurrent] = useState(initial);
  const [failed, setFailed] = useState(false);

  const label =
    alt ||
    (fallbackName ? `Photo de ${fallbackName}` : `Univers ${fallbackCategory || "artistique"}`);

  const handleError = () => {
    // Première erreur : on tente l'image de secours par catégorie.
    if (current !== fallbackSrc) {
      setCurrent(fallbackSrc);
      return;
    }
    // Le secours a aussi échoué : on affiche un visuel propre, jamais d'icône cassée.
    setFailed(true);
  };

  if (failed) {
    return (
      <div
        className={`flex items-center justify-center bg-muted text-muted-foreground ${className}`}
        role="img"
        aria-label={label}
      >
        <ImageIcon className="w-8 h-8 opacity-40" />
      </div>
    );
  }

  return (
    <img
      src={current}
      alt={label}
      loading={eager ? "eager" : "lazy"}
      onError={handleError}
      className={`object-cover ${className}`}
    />
  );
}