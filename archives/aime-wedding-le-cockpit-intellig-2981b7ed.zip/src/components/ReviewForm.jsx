import { useState } from "react";
import { Heart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";

export default function ReviewForm({ onSubmit }) {
  const [rating, setRating] = useState(0);
  const [hover, setHover] = useState(0);
  const [content, setContent] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (rating === 0) {
      setError("Veuillez sélectionner une note.");
      return;
    }
    setError("");
    setSubmitting(true);
    try {
      await onSubmit({ rating, content });
      setRating(0);
      setContent("");
    } catch {
      setError("Une erreur est survenue. Veuillez réessayer.");
    }
    setSubmitting(false);
  };

  return (
    <form onSubmit={handleSubmit} className="bg-muted/30 rounded-lg p-4 mb-6">
      <p className="text-sm font-medium text-foreground mb-2">Laisser un avis</p>
      <div className="flex items-center gap-1 mb-3">
        {[1, 2, 3, 4, 5].map((n) => (
          <button
            key={n}
            type="button"
            onClick={() => setRating(n)}
            onMouseEnter={() => setHover(n)}
            onMouseLeave={() => setHover(0)}
            aria-label={`Noter ${n} sur 5`}
            className="p-0.5"
          >
            <Heart className={`w-6 h-6 transition-colors ${n <= (hover || rating) ? "fill-foreground text-foreground" : "text-muted-foreground/30"}`} />
          </button>
        ))}
      </div>
      <Textarea
        rows={3}
        placeholder="Partagez votre expérience..."
        value={content}
        onChange={(e) => setContent(e.target.value)}
        className="mb-3"
      />
      {error && <p className="text-xs text-destructive mb-3">{error}</p>}
      <Button type="submit" disabled={submitting} className="bg-foreground text-background hover:bg-foreground/90">
        {submitting ? "Publication..." : "Publier mon avis"}
      </Button>
    </form>
  );
}