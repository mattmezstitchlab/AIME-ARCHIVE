import { Heart } from "lucide-react";

export default function ReviewsList({ reviews }) {
  if (!reviews || reviews.length === 0) {
    return (
      <p className="text-sm text-muted-foreground py-4">
        Aucun avis pour le moment. Soyez le premier à partager votre expérience.
      </p>
    );
  }

  return (
    <div className="space-y-4">
      {reviews.map((review) => (
        <div key={review.id} className="border-b border-border pb-4">
          <div className="flex items-center justify-between mb-2">
            <span className="font-medium text-foreground text-sm">{review.author_name || "Client"}</span>
            <div className="flex items-center gap-0.5">
              {[1, 2, 3, 4, 5].map((n) => (
                <Heart
                  key={n}
                  className={`w-3.5 h-3.5 ${n <= review.rating ? "fill-foreground text-foreground" : "text-muted-foreground/30"}`}
                />
              ))}
            </div>
          </div>
          {review.content && (
            <p className="text-sm text-muted-foreground leading-relaxed">{review.content}</p>
          )}
        </div>
      ))}
    </div>
  );
}