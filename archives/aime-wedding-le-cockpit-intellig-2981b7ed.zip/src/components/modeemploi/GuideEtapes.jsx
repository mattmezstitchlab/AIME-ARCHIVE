const ETAPES = [
  { qui: "Les mariés", couleur: "#F2A7C3", titre: "Créer le mariage",
    texte: "Sur AIME Wedding : un nom, une date, un lieu. L'OS génère un code d'invitation à 6 caractères.", os: "Le mariage devient l'espace partagé de tous." },
  { qui: "Les mariés", couleur: "#F2A7C3", titre: "Inviter par code",
    texte: "Le code se partage par message : témoins, famille, traiteur, photographe, lieu…", os: "Chaque personne qui entre rejoint le même mariage, synchronisé." },
  { qui: "Chaque rôle", couleur: "#E8C97F", titre: "Choisir son rôle & s'inscrire",
    texte: "On choisit qui on est (une seule fois) : quelques questions, et la carte profil se crée au Registre.", os: "L'agent du rôle se configure : il ne voit que ce qui concerne ce rôle." },
  { qui: "L'OS", couleur: "#7FC3F0", titre: "Le mini-site est déjà construit",
    texte: "Chaque rôle arrive dans le studio avec son mini-site généré — hero, sections, design.", os: "On parle à l'agent pour tout régler : textes, visuels, couleurs, RSVP." },
  { qui: "Chaque rôle", couleur: "#7FDCB2", titre: "Publier sur +nom",
    texte: "Un clic : le site vit sur son adresse « + » (ex. +lea-tom) et sa carte apparaît au Registre.", os: "Les invités ouvrent l'adresse : programme, venir & dormir, RSVP." },
  { qui: "Tout le monde", couleur: "#C9A2F5", titre: "Jouer le Jour J",
    texte: "Play Jour J : le programme se déroule moment par moment, chacun voit sa partition.", os: "Un imprévu ? L'onde causale prévient les bons rôles, automatiquement." },
];

// LE PROCESSUS SCHÉMATISÉ — la ligne verticale, 6 étapes numérotées :
// qui agit, ce qu'il fait, et ce que l'OS fait tout seul.
export default function GuideEtapes() {
  return (
    <ol className="relative mx-auto max-w-2xl space-y-10">
      <span aria-hidden="true" className="absolute bottom-4 left-[19px] top-4 w-px bg-border" />
      {ETAPES.map((e, i) => (
        <li key={e.titre} className="relative flex gap-5">
          <span className="z-10 flex h-10 w-10 shrink-0 items-center justify-center rounded-full border text-[13px] font-extrabold"
            style={{ borderColor: e.couleur, color: e.couleur, background: "hsl(var(--background))" }}>
            {i + 1}
          </span>
          <div className="min-w-0 pt-0.5">
            <p className="w-fit rounded-full px-2.5 py-0.5 font-mono text-[8.5px] font-bold uppercase tracking-[0.2em]"
              style={{ background: `${e.couleur}22`, color: e.couleur }}>
              {e.qui}
            </p>
            <h3 className="mt-2 text-[17px] font-extrabold tracking-[-0.02em]">{e.titre}</h3>
            <p className="mt-1.5 text-[13px] leading-relaxed text-muted-foreground">{e.texte}</p>
            <p className="mt-2 border-l-2 pl-3 text-[12px] leading-relaxed text-muted-foreground/80" style={{ borderColor: `${e.couleur}66` }}>
              <span className="font-bold text-foreground/70">L'OS&nbsp;:</span> {e.os}
            </p>
          </div>
        </li>
      ))}
    </ol>
  );
}