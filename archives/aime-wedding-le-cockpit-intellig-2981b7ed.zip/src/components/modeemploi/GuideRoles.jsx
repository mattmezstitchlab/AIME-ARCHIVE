import { ROLES } from "@/components/weddingos/osRoles";

// LES RÔLES — la grille complète : chaque rôle, son agent, son terrain de jeu.
export default function GuideRoles() {
  return (
    <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
      {ROLES.map((r) => (
        <article key={r.id} className="rounded-2xl border border-border bg-card p-5">
          <div className="flex items-center gap-2">
            <span className="h-2 w-2 rounded-full" style={{ background: r.color }} aria-hidden="true" />
            <h3 className="text-[13.5px] font-bold">{r.label}</h3>
          </div>
          <p className="mt-1 font-mono text-[8.5px] font-bold uppercase tracking-[0.2em]" style={{ color: r.color }}>
            {r.agent}
          </p>
          <p className="mt-2.5 text-[12px] leading-relaxed text-muted-foreground">{r.focus}</p>
        </article>
      ))}
    </div>
  );
}