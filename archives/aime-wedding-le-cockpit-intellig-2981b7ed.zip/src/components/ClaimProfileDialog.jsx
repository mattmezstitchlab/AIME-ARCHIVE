import { useState } from "react";
import { base44 } from "@/api/base44Client";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { BadgeCheck, Loader2, Check } from "lucide-react";

// Formulaire de revendication d'une fiche exemple par un prestataire.
// Enregistre une demande (ProfileClaim) en attente de validation — ne modifie pas la fiche.
export default function ClaimProfileDialog({ artist, trigger }) {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [role, setRole] = useState(artist.wedding_role || "");
  const [message, setMessage] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || submitting) return;
    setSubmitting(true);
    try {
      await base44.entities.ProfileClaim.create({
        artist_id: artist.id,
        artist_name: artist.name,
        claimant_name: name.trim(),
        claimant_email: email.trim(),
        claimant_phone: phone.trim(),
        wedding_role: role.trim(),
        city: artist.location || "",
        message: message.trim(),
        status: "pending",
      });
      setDone(true);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent className="sm:max-w-md">
        {done ? (
          <div className="py-6 text-center">
            <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center mx-auto mb-4">
              <Check className="w-6 h-6 text-accent" aria-hidden="true" />
            </div>
            <DialogTitle className="text-base mb-1">Demande envoyée</DialogTitle>
            <DialogDescription>
              Merci ! Nous revenons vers vous par e-mail pour valider la reprise de cette fiche.
            </DialogDescription>
          </div>
        ) : (
          <>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <BadgeCheck className="w-5 h-5 text-accent" aria-hidden="true" /> C'est mon profil
              </DialogTitle>
              <DialogDescription>
                Vous êtes ce prestataire ? Revendiquez la fiche « {artist.name} » et indiquez votre rôle pour la rendre vôtre.
              </DialogDescription>
            </DialogHeader>

            <form onSubmit={submit} className="space-y-3 mt-2">
              <div>
                <label htmlFor="claim-name" className="text-xs font-medium text-foreground block mb-1.5">Votre nom *</label>
                <Input id="claim-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Prénom et nom" required />
              </div>
              <div>
                <label htmlFor="claim-role" className="text-xs font-medium text-foreground block mb-1.5">Votre rôle</label>
                <Input id="claim-role" value={role} onChange={(e) => setRole(e.target.value)} placeholder="Photographe, DJ, Fleuriste…" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label htmlFor="claim-email" className="text-xs font-medium text-foreground block mb-1.5">E-mail *</label>
                  <Input id="claim-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="vous@email.com" required />
                </div>
                <div>
                  <label htmlFor="claim-phone" className="text-xs font-medium text-foreground block mb-1.5">Téléphone</label>
                  <Input id="claim-phone" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="06…" />
                </div>
              </div>
              <div>
                <label htmlFor="claim-msg" className="text-xs font-medium text-foreground block mb-1.5">Présentation (optionnel)</label>
                <Textarea id="claim-msg" value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Quelques mots sur vous et vos prestations…" rows={3} />
              </div>
              <Button type="submit" className="w-full rounded-full" disabled={submitting || !name.trim() || !email.trim()}>
                {submitting ? <Loader2 className="w-4 h-4 animate-spin" aria-hidden="true" /> : "Envoyer ma demande"}
              </Button>
            </form>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}