// Système typographique proposé : 3 voix — display, corps, et la nouvelle voix mono.
export default function PropTypo() {
  return (
    <div className="space-y-3">
      <div className="rounded-2xl border border-white/10 bg-[#161616] p-6">
        <p className="font-mono text-[10px] uppercase tracking-[0.28em] text-[#E8642C]">Display · Aeonik (conservée)</p>
        <p className="mt-3 font-heading text-4xl font-semibold leading-[1.05] tracking-tight text-white sm:text-5xl">
          Votre site.
          <br />
          <span className="text-white/40">Vos règles.</span>
        </p>
        <p className="mt-3 text-[12px] text-white/40">
          Grands titres façon Apex : très gros, très serrés, avec une seconde ligne éteinte à 40 %.
        </p>
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        <div className="rounded-2xl border border-white/10 bg-[#161616] p-6">
          <p className="font-mono text-[10px] uppercase tracking-[0.28em] text-[#E8642C]">Corps · Inter (conservée)</p>
          <p className="mt-3 text-[14px] leading-relaxed text-white/70">
            Le texte courant reste en Inter, à 70 % d'opacité sur le noir. Deux niveaux seulement :
            90 % pour l'important, 50 % pour le secondaire — jamais de gris intermédiaires.
          </p>
        </div>
        <div className="rounded-2xl border border-white/10 bg-[#161616] p-6">
          <p className="font-mono text-[10px] uppercase tracking-[0.28em] text-[#E8642C]">Nouvelle voix · Mono</p>
          <p className="mt-3 font-mono text-[11px] uppercase tracking-[0.3em] text-white/55">
            TIER 1 · SCAN WCAG AA
          </p>
          <p className="mt-2 font-mono text-[12px] text-white/70">~2 min restantes · 3 of 4 steps</p>
          <p className="mt-3 text-[12px] text-white/40">
            La voix machine d'Apex : micro-labels, compteurs, états techniques. C'est elle qui donne
            le ton « moteur » aux consoles (Absorbeur, scan, certificat).
          </p>
        </div>
      </div>
    </div>
  );
}