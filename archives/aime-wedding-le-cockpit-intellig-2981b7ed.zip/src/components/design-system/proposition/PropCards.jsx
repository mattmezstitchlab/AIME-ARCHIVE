import { Check, Loader2 } from "lucide-react";

const W1 = "https://media.base44.com/images/public/6a4121ee87663bd9b9c98ef7/b420ee81a_generated_image.png";
const W2 = "https://media.base44.com/images/public/6a4121ee87663bd9b9c98ef7/ed3a70b5d_generated_image.png";

// La signature visuelle : cadre aquarelle ivoire + panneau noir flottant dedans.
export default function PropCards() {
  return (
    <div className="grid gap-4 lg:grid-cols-3">
      {/* Carte tier — aquarelle pleine + panneau sombre centré */}
      {[
        { img: W1, tier: "Tier 1", title: "Vitrine", text: "La carte universelle recto/verso, habillée du cadre aquarelle." },
        { img: W2, tier: "Tier 2", title: "Absorbeur", text: "Les consoles techniques flottent sur le papier peint d'encre." },
      ].map((c) => (
        <div key={c.tier} className="overflow-hidden rounded-3xl">
          <div className="relative flex h-56 items-center justify-center bg-cover bg-center" style={{ backgroundImage: `url(${c.img})` }}>
            <div className="flex h-40 w-40 items-start rounded-2xl bg-[#141414] p-4 shadow-2xl">
              <p className="font-mono text-[9px] uppercase tracking-[0.3em] text-white/40">{c.tier}</p>
            </div>
          </div>
          <div className="bg-[#0C0C0C] px-1 pt-4">
            <p className="font-mono text-[9.5px] uppercase tracking-[0.28em] text-white/35">{c.tier}</p>
            <p className="mt-1 text-[14px] font-semibold text-white">{c.title}</p>
            <p className="mt-1 text-[12px] leading-snug text-white/45">{c.text}</p>
          </div>
        </div>
      ))}

      {/* Console agent — le panneau à étapes façon Apex, avec la voix mono */}
      <div className="overflow-hidden rounded-3xl">
        <div className="relative flex h-56 items-center justify-center bg-cover bg-center p-5" style={{ backgroundImage: `url(${W1})` }}>
          <div className="w-full max-w-[240px] rounded-2xl bg-[#141414] p-4 shadow-2xl">
            <div className="flex items-center justify-between">
              <p className="text-[12px] font-semibold text-white">Nouveau scan</p>
              <span className="rounded-full bg-[#E8642C] px-2 py-0.5 font-mono text-[8.5px] font-bold uppercase text-black">Live</span>
            </div>
            <ul className="mt-3 space-y-2">
              <li className="flex items-center gap-2 text-[11px] text-white/70"><Check className="h-3 w-3 text-emerald-400" /> Pages éclatées</li>
              <li className="flex items-center gap-2 text-[11px] text-white/70"><Check className="h-3 w-3 text-emerald-400" /> Scan WCAG AA</li>
              <li className="flex items-center gap-2 text-[11px] text-white/70"><Loader2 className="h-3 w-3 animate-spin text-[#E8642C]" /> Absorption…</li>
            </ul>
            <div className="mt-3 h-1 overflow-hidden rounded-full bg-white/10">
              <div className="h-full w-2/3 rounded-full bg-[#E8642C]" />
            </div>
          </div>
        </div>
        <div className="bg-[#0C0C0C] px-1 pt-4">
          <p className="font-mono text-[9.5px] uppercase tracking-[0.28em] text-white/35">Console</p>
          <p className="mt-1 text-[14px] font-semibold text-white">Panneau à étapes</p>
          <p className="mt-1 text-[12px] leading-snug text-white/45">
            Chaque process (scan, régénération, import) devient une console vivante : étapes cochées,
            spinner feu, barre de progression.
          </p>
        </div>
      </div>
    </div>
  );
}