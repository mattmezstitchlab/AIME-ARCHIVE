// Palette proposée — noir studio + papier ivoire + feu Apex + sable AIME conservé.
const COLORS = [
  { hex: "#0C0C0C", name: "Noir studio", role: "Fond principal — la scène sombre où tout flotte." },
  { hex: "#161616", name: "Panneau", role: "Cartes et consoles posées sur le noir." },
  { hex: "#F4F1EA", name: "Papier ivoire", role: "Le fond des aquarelles et des inversions claires." },
  { hex: "#E8642C", name: "Feu", role: "L'accent vivant : états actifs, progression, Live." },
  { hex: "#C9B88F", name: "Sable AIME", role: "Conservé — la signature dorée de la marque." },
  { hex: "#2E6E6A", name: "Teal profond", role: "Second accent, venu des aquarelles." },
  { hex: "#7D8B74", name: "Sauge", role: "Micro-accents calmes, états neutres positifs." },
];

export default function PropPalette() {
  return (
    <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
      {COLORS.map((c) => (
        <div key={c.hex} className="overflow-hidden rounded-2xl border border-white/10 bg-[#161616]">
          <div className="h-20" style={{ backgroundColor: c.hex }} />
          <div className="p-3.5">
            <div className="flex items-baseline justify-between gap-2">
              <p className="text-[13px] font-semibold text-white">{c.name}</p>
              <p className="font-mono text-[10px] uppercase text-white/40">{c.hex}</p>
            </div>
            <p className="mt-1 text-[11.5px] leading-snug text-white/45">{c.role}</p>
          </div>
        </div>
      ))}
    </div>
  );
}