import { Check, RotateCcw } from "lucide-react";

// Section de proposition avec verdict : « Je valide » / « À revoir ».
export default function PropSection({ num, title, intro, verdict, onVerdict, children }) {
  return (
    <section className="mt-16">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div className="max-w-2xl">
          <p className="font-mono text-[10px] uppercase tracking-[0.28em] text-white/35">
            Proposition {num}
          </p>
          <h2 className="mt-2 font-heading text-2xl font-semibold tracking-tight text-white sm:text-3xl">
            {title}
          </h2>
          {intro && <p className="mt-2 text-[14px] leading-relaxed text-white/50">{intro}</p>}
        </div>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => onVerdict(verdict === "ok" ? null : "ok")}
            className={`inline-flex items-center gap-1.5 rounded-full px-4 py-2 text-[12px] font-semibold transition ${
              verdict === "ok"
                ? "bg-emerald-500 text-black"
                : "border border-white/15 text-white/60 hover:border-emerald-400/60 hover:text-white"
            }`}
          >
            <Check className="h-3.5 w-3.5" /> Je valide
          </button>
          <button
            type="button"
            onClick={() => onVerdict(verdict === "revoir" ? null : "revoir")}
            className={`inline-flex items-center gap-1.5 rounded-full px-4 py-2 text-[12px] font-semibold transition ${
              verdict === "revoir"
                ? "bg-amber-400 text-black"
                : "border border-white/15 text-white/60 hover:border-amber-400/60 hover:text-white"
            }`}
          >
            <RotateCcw className="h-3.5 w-3.5" /> À revoir
          </button>
        </div>
      </div>
      <div className="mt-6">{children}</div>
    </section>
  );
}