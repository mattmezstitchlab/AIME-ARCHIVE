import { ArrowRight } from "lucide-react";

// Boutons & liens proposés : pilule blanche, ghost, lien-flèche, chip mono.
export default function PropActions() {
  return (
    <div className="rounded-2xl border border-white/10 bg-[#161616] p-6">
      <div className="flex flex-wrap items-center gap-4">
        <button type="button" className="rounded-full bg-white px-5 py-2.5 text-[13px] font-semibold text-black transition hover:bg-white/90">
          Action principale
        </button>
        <button type="button" className="rounded-full border border-white/20 px-5 py-2.5 text-[13px] font-medium text-white/80 transition hover:border-white/50 hover:text-white">
          Secondaire
        </button>
        <button type="button" className="rounded-full bg-[#E8642C] px-5 py-2.5 text-[13px] font-semibold text-black transition hover:brightness-110">
          Action feu
        </button>
        <button type="button" className="group inline-flex items-center gap-1.5 text-[13px] font-medium text-white/80 transition hover:text-white">
          Lien éditorial <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
        </button>
        <span className="rounded-full border border-white/15 px-3 py-1 font-mono text-[9.5px] uppercase tracking-[0.26em] text-white/50">
          Chip mono
        </span>
      </div>
      <p className="mt-4 text-[12px] text-white/40">
        Règle Apex : la pilule blanche est rare (une par écran), le feu est réservé au vivant
        (Live, en cours), tout le reste passe par le lien-flèche et les chips mono.
      </p>
    </div>
  );
}