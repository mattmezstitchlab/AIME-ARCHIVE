import { Check, X } from "lucide-react";
import { PICTO_ICONS } from "@/lib/ripple/pictoIcons";

// Grille générique « garder / supprimer » : chaque élément du site (picto,
// visuel, bouton, forme, carte…) affiche son aperçu + deux boutons de décision.
function ItemPreview({ item }) {
  if (item.kind === "picto") {
    const Icon = PICTO_ICONS[item.sample];
    return Icon ? <Icon className="h-7 w-7 text-white/85" strokeWidth={1.6} /> : null;
  }
  if (item.kind === "image") {
    return <img src={item.sample} alt={item.label} className="h-full w-full object-cover" loading="lazy" />;
  }
  if (item.kind === "button") {
    const styles = {
      "btn-primary": "bg-white text-black",
      "btn-outline": "border border-white/40 text-white",
      "btn-pill": "rounded-full bg-accent text-black",
      "btn-ghost": "text-white/60",
    };
    return <span className={`rounded-md px-3 py-1.5 text-[11px] font-semibold ${styles[item.id] || "bg-white/10 text-white"}`}>{item.sample}</span>;
  }
  if (item.kind === "shape") {
    return (
      <span
        className="h-10 w-16 border border-white/25 bg-white/10 shadow-lg"
        style={{ borderRadius: item.sample?.endsWith("px") ? item.sample : "8px" }}
      />
    );
  }
  // block / video / capture / doc / text…
  return <span className="px-2 text-center text-[10px] leading-tight text-white/50">{item.meta || item.sample || item.label}</span>;
}

export default function DsKeepGrid({ items, decisions, onDecide }) {
  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
      {items.map((item) => {
        const decision = decisions[item.id];
        const removed = decision === "remove";
        const kept = decision === "keep";
        return (
          <div
            key={item.id}
            className={`overflow-hidden rounded-xl border transition ${
              removed
                ? "border-red-500/50 opacity-40"
                : kept
                  ? "border-emerald-500/50"
                  : "border-white/10"
            } bg-white/[0.03]`}
          >
            <div className="flex h-20 items-center justify-center overflow-hidden bg-black/40">
              <ItemPreview item={item} />
            </div>
            <div className="p-2">
              <p className="truncate text-[11px] font-medium text-white/80">{item.label}</p>
              <div className="mt-1.5 flex gap-1">
                <button
                  type="button"
                  onClick={() => onDecide(item.id, kept ? null : "keep")}
                  aria-label={`Garder ${item.label}`}
                  className={`flex h-6 flex-1 items-center justify-center rounded-md text-[10px] font-semibold transition ${
                    kept ? "bg-emerald-500 text-black" : "bg-white/8 text-white/50 hover:bg-white/15"
                  }`}
                >
                  <Check className="h-3.5 w-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => onDecide(item.id, removed ? null : "remove")}
                  aria-label={`Supprimer ${item.label}`}
                  className={`flex h-6 flex-1 items-center justify-center rounded-md text-[10px] font-semibold transition ${
                    removed ? "bg-red-500 text-white" : "bg-white/8 text-white/50 hover:bg-white/15"
                  }`}
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}