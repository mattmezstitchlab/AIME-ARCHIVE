// Section Couleurs — chaque token du site est modifiable au pipette-picker.
const COLOR_LABELS = {
  background: "Fond de page",
  foreground: "Texte principal",
  accent: "Accent · Sable",
  border: "Bordures",
  muted: "Fond discret",
  mutedFg: "Texte secondaire",
  card: "Cartes",
  sand: "Sable",
  sage: "Sauge",
  ivory: "Ivoire",
  paper: "Papier",
  destructive: "Destructif",
};

export default function DsColorsSection({ colors, onChange }) {
  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
      {Object.entries(colors).map(([token, hex]) => (
        <label
          key={token}
          className="flex cursor-pointer items-center gap-3 rounded-xl border border-white/10 bg-white/[0.03] p-3 transition hover:bg-white/[0.06]"
        >
          <span className="relative h-10 w-10 shrink-0 overflow-hidden rounded-lg ring-1 ring-white/15">
            <input
              type="color"
              value={hex}
              onChange={(e) => onChange(token, e.target.value)}
              className="absolute -inset-2 h-14 w-14 cursor-pointer border-0 bg-transparent p-0"
              aria-label={`Couleur ${COLOR_LABELS[token] || token}`}
            />
          </span>
          <span className="min-w-0">
            <span className="block truncate text-[12px] font-semibold text-white/85">{COLOR_LABELS[token] || token}</span>
            <span className="block font-mono text-[10px] uppercase text-white/40">{hex}</span>
          </span>
        </label>
      ))}
    </div>
  );
}