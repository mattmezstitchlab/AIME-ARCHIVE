import { itemKind } from "@/lib/ripple/designSystemInventory";
import { MIROIR_PICTOS } from "./miroirPictos";

// LA COLONNE GAUCHE — l'élément TEL QU'IL EST sur le site aujourd'hui :
// éditorial clair, sable, Aeonik/Inter, rayons discrets.
export default function RenduActuel({ item }) {
  const kind = itemKind(item);

  return (
    <div>
      {kind === "color" && (
        <div className="flex items-center gap-3">
          <span className="h-12 w-12 shrink-0 rounded-md border border-black/10" style={{ background: item.hex }} />
          <span>
            <span className="block text-[13px] font-medium text-black/85">{item.label}</span>
            <span className="block font-mono text-[10px] text-black/45">{item.hex}</span>
          </span>
        </div>
      )}

      {kind === "typo" && (
        <div>
          <p className="text-[22px] leading-tight text-black/90" style={{ fontFamily: item.family }}>
            Aa — Le grand titre
          </p>
          <p className="mt-1 font-mono text-[10px] text-black/45">{item.label} · {item.weight}</p>
        </div>
      )}

      {kind === "size" && (
        <div className="flex items-baseline gap-3">
          <span className="font-heading text-black/90" style={{ fontSize: `min(${item.size}, 40px)` }}>Aa</span>
          <span>
            <span className="block text-[12px] text-black/70">{item.label}</span>
            <span className="block font-mono text-[10px] text-black/45">{item.size}</span>
          </span>
        </div>
      )}

      {kind === "picto" && (() => {
        const Icon = MIROIR_PICTOS[item.picto];
        return (
          <div className="flex items-center gap-3">
            <span className="flex h-12 w-12 items-center justify-center rounded-md border border-black/10 bg-white">
              {Icon && <Icon className="h-5 w-5 text-black/70" strokeWidth={1.7} />}
            </span>
            <span className="text-[12px] text-black/70">{item.label}</span>
          </div>
        );
      })()}

      {kind === "format" && (
        <div className="flex items-center gap-3">
          <span
            className="h-12 w-16 shrink-0 border border-black/15 bg-white"
            style={{
              borderRadius: item.value.includes("px") || item.value.includes("rem") ? item.value : "6px",
              boxShadow: item.value === "shadow-xl" ? "0 12px 30px rgba(0,0,0,0.18)" : item.value === "shadow-sm" ? "0 1px 3px rgba(0,0,0,0.1)" : "none",
            }}
          />
          <span>
            <span className="block text-[12px] text-black/70">{item.label}</span>
            <span className="block font-mono text-[10px] text-black/45">{item.value}</span>
          </span>
        </div>
      )}

      {kind === "card" && (
        <div className="rounded-md border border-black/10 bg-white p-3">
          <p className="text-[13px] font-semibold text-black/85">{item.label}</p>
          <p className="mt-0.5 text-[11px] leading-snug text-black/50">{item.desc}</p>
        </div>
      )}
    </div>
  );
}