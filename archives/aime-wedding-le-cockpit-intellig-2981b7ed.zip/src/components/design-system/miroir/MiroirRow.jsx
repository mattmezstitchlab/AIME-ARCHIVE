import { useState } from "react";
import { Check, X, MessageSquare } from "lucide-react";
import RenduActuel from "./RenduActuel";
import RenduAimePlus from "./RenduAimePlus";

// UNE LIGNE DU MIROIR — gauche : l'élément actuel ; droite : sa version
// AI+ME. Trois gestes : ✓ Adopter la nouvelle, ✕ Supprimer l'ancienne,
// 💬 Commenter (une instruction pour l'agent IA, ramassée au VALIDER).
export default function MiroirRow({ item, decision, commentaire, onDecide, onComment, reglages }) {
  const [noteOuverte, setNoteOuverte] = useState(false);
  const supprime = decision === "supprimer";
  const adopte = decision === "adopter";

  return (
    <div>
      <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 sm:gap-3">
        {/* GAUCHE — l'élément actuel ; barré de rouge s'il est à supprimer. */}
        <div
          className={`relative rounded-xl border p-4 transition ${
            supprime ? "border-dashed border-red-400/60 bg-[#f7f5f0]/60 opacity-50" : "border-black/10 bg-[#f7f5f0]"
          }`}
        >
          <RenduActuel item={item} />
          {supprime && (
            <span className="absolute right-3 top-3 rounded-full bg-red-500/90 px-2 py-0.5 font-mono text-[8.5px] font-bold uppercase tracking-[0.14em] text-white">
              À supprimer
            </span>
          )}
        </div>

        {/* DROITE — la version AI+ME + les trois gestes. */}
        <div
          className={`relative rounded-xl border p-4 transition ${
            adopte ? "border-emerald-400/60 bg-emerald-400/[0.04]" : "border-white/12 bg-[#0f0f12]"
          }`}
        >
          <RenduAimePlus item={item} reglages={reglages} />
          <span className="absolute right-3 top-3 flex items-center gap-1">
            <button
              type="button"
              onClick={() => setNoteOuverte((o) => !o)}
              aria-label={`Commenter ${item.label} pour l'agent`}
              aria-expanded={noteOuverte}
              className={`inline-flex items-center gap-1 rounded-full px-2 py-1 font-mono text-[8.5px] font-bold uppercase tracking-[0.1em] transition ${
                commentaire ? "bg-[#38bdf8]/20 text-[#38bdf8]" : "border border-white/20 text-white/45 hover:border-white/50 hover:text-white"
              }`}
            >
              <MessageSquare className="h-3 w-3" />
              {commentaire ? "1" : ""}
            </button>
            <button
              type="button"
              onClick={() => onDecide(supprime ? null : "supprimer")}
              aria-pressed={supprime}
              aria-label={`Marquer ${item.label} à supprimer`}
              className={`inline-flex items-center gap-1 rounded-full px-2 py-1 font-mono text-[8.5px] font-bold uppercase tracking-[0.1em] transition ${
                supprime ? "bg-red-500/20 text-red-300" : "border border-white/20 text-white/45 hover:border-red-400/60 hover:text-red-300"
              }`}
            >
              <X className="h-3 w-3" />
            </button>
            <button
              type="button"
              onClick={() => onDecide(adopte ? null : "adopter")}
              aria-pressed={adopte}
              aria-label={`Adopter ${item.label} en AI+ME`}
              className={`inline-flex items-center gap-1 rounded-full px-2.5 py-1 font-mono text-[8.5px] font-bold uppercase tracking-[0.12em] transition ${
                adopte ? "bg-emerald-400/20 text-emerald-300" : "border border-white/20 text-white/45 hover:border-white/50 hover:text-white"
              }`}
            >
              <Check className="h-3 w-3" /> {adopte ? "Adopté" : "Adopter"}
            </button>
          </span>
        </div>
      </div>

      {/* LE COMMENTAIRE POUR L'AGENT — l'instruction rattachée à l'élément. */}
      {noteOuverte && (
        <div className="mt-2 rounded-xl border border-[#38bdf8]/40 bg-[#38bdf8]/[0.05] p-3">
          <p className="font-mono text-[8.5px] font-semibold uppercase tracking-[0.18em] text-[#38bdf8]">
            Instruction pour l'agent · {item.label}
          </p>
          <textarea
            value={commentaire || ""}
            onChange={(e) => onComment(e.target.value)}
            placeholder="ex. Remplacer ce bloc par les vraies infos du moteur…"
            rows={2}
            className="mt-2 w-full resize-none rounded-lg border border-white/15 bg-black/40 px-3 py-2 text-[12.5px] text-white placeholder:text-white/30 focus:border-[#38bdf8]/60 focus:outline-none"
          />
        </div>
      )}
      {!noteOuverte && commentaire && (
        <button
          type="button"
          onClick={() => setNoteOuverte(true)}
          className="mt-1.5 block w-full truncate rounded-lg bg-[#38bdf8]/[0.07] px-3 py-1.5 text-left text-[11px] text-[#38bdf8]/80 hover:bg-[#38bdf8]/[0.12]"
        >
          💬 {commentaire}
        </button>
      )}
    </div>
  );
}