import { SPECTRE, rayonMorpho } from "@/lib/aimeplus/langageAimePlus";

// LES RÉGLAGES DU LANGAGE — côté droit : morphologie (cercle↔carré),
// épaisseur du liseré arc-en-ciel, teinte dominante. Chaque geste est
// causal : TOUTE la colonne droite se met à jour en direct.
export default function MiroirReglages({ reglages, onChange }) {
  const set = (k, v) => onChange({ ...reglages, [k]: v });

  return (
    <div className="rounded-2xl border border-white/12 bg-[#0f0f12] p-4">
      <p className="font-mono text-[9.5px] font-semibold uppercase tracking-[0.22em] text-white/45">
        Réglages du langage
      </p>

      <label className="mt-4 block">
        <span className="flex items-center justify-between text-[11.5px] text-white/65">
          Morphologie
          <span className="font-mono text-[9px] uppercase tracking-[0.12em] text-white/35">
            {reglages.morpho < 34 ? "Cercle" : reglages.morpho > 66 ? "Carré" : "Entre-deux"}
          </span>
        </span>
        <input
          type="range" min="0" max="100" value={reglages.morpho}
          onChange={(e) => set("morpho", Number(e.target.value))}
          className="ripple-range mt-1.5 w-full appearance-none rounded-full bg-white/15" style={{ height: 4 }}
        />
      </label>

      <label className="mt-4 block">
        <span className="flex items-center justify-between text-[11.5px] text-white/65">
          Liseré arc-en-ciel
          <span className="font-mono text-[9px] text-white/35">{reglages.liseret}px</span>
        </span>
        <input
          type="range" min="1" max="4" value={reglages.liseret}
          onChange={(e) => set("liseret", Number(e.target.value))}
          className="ripple-range mt-1.5 w-full appearance-none rounded-full bg-white/15" style={{ height: 4 }}
        />
      </label>

      <div className="mt-4">
        <span className="text-[11.5px] text-white/65">Teinte dominante</span>
        <div className="mt-2 flex gap-2">
          {SPECTRE.map((hex, i) => (
            <button
              key={hex}
              type="button"
              onClick={() => set("teinte", i)}
              aria-label={`Teinte ${hex}`}
              aria-pressed={reglages.teinte === i}
              className={`h-7 w-7 transition-all duration-300 ${reglages.teinte === i ? "ring-2 ring-white" : "opacity-60 hover:opacity-100"}`}
              style={{ background: hex, borderRadius: rayonMorpho(reglages.morpho, 28) }}
            />
          ))}
        </div>
      </div>

      <p className="mt-4 border-t border-white/10 pt-3 text-[10.5px] leading-relaxed text-white/40">
        Réglage causal : la colonne AI+ME entière se transforme pendant que vous glissez.
      </p>
    </div>
  );
}