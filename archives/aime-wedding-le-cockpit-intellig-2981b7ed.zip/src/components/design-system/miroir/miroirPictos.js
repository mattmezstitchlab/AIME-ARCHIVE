import {
  Heart, Zap, Globe, Scale, ShieldCheck, Database, Server, Plug,
  Route, Folder, Calendar, MapPin, Music, Camera, Sparkles, Users,
  Check, X, Search, Star, Clock, Mail, Image, FileText,
} from "lucide-react";

// Mapping EXPLICITE des pictos de l'inventaire (jamais d'import étoile).
export const MIROIR_PICTOS = {
  Heart, Zap, Globe, Scale, ShieldCheck, Database, Server, Plug,
  Route, Folder, Calendar, MapPin, Music, Camera, Sparkles, Users,
  Check, X, Search, Star, Clock, Mail, Image, FileText,
};