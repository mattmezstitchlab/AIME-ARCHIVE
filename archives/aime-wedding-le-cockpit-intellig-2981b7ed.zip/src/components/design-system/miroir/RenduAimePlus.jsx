import { itemKind } from "@/lib/ripple/designSystemInventory";
import { SPECTRE, CONIC, LANGAGE, rayonMorpho } from "@/lib/aimeplus/langageAimePlus";
import { MIROIR_PICTOS } from "./miroirPictos";

// L'ANNEAU AI+ME — le liseré arc-en-ciel qui enserre l'élément ; la
// morphologie (cercle↔carré) et l'épaisseur viennent des réglages, en direct.
function Anneau({ reglages, taille = 48, children }) {
  const rayon = rayonMorpho(reglages.morpho, taille);
  return (
    <span
      className="relative inline-flex shrink-0 overflow-hidden transition-all duration-300"
      style={{ width: taille, height: taille, borderRadius: rayon, padding: reglages.liseret, background: CONIC }}
    >
      <span
        className="flex h-full w-full items-center justify-center transition-all duration-300"
        style={{ borderRadius: Math.max(2, rayon - reglages.liseret), background: LANGAGE.neutres.panneau }}
      >
        {children}
      </span>
    </span>
  );
}

// LA COLONNE DROITE — le MÊME élément, traduit dans le langage AI+ME.
export default function RenduAimePlus({ item, reglages }) {
  const kind = itemKind(item);
  const accent = SPECTRE[reglages.teinte];
  const rayon = rayonMorpho(reglages.morpho, 48);

  return (
    <div>
      {kind === "color" && (
        <div className="flex items-center gap-3">
          <Anneau reglages={reglages}>
            <span className="h-6 w-6 rounded-full" style={{ background: item.hex }} />
          </Anneau>
          <span>
            <span className="block text-[13px] font-extrabold tracking-[-0.02em] text-white/90">{item.label}</span>
            <span className="block font-mono text-[9.5px] uppercase tracking-[0.18em]" style={{ color: accent }}>{item.hex}</span>
          </span>
        </div>
      )}

      {kind === "typo" && (
        <div>
          <p className="text-[22px] font-extrabold leading-tight tracking-[-0.03em] text-white">
            AI<span style={{ color: accent }}>+</span>ME — Le titre
          </p>
          <p className="mt-1 font-mono text-[9.5px] font-semibold uppercase tracking-[0.2em] text-white/40">
            Inter 800 · −0.03em
          </p>
        </div>
      )}

      {kind === "size" && (
        <div className="flex items-baseline gap-3">
          <span className="font-extrabold tracking-[-0.03em] text-white" style={{ fontSize: `min(${item.size}, 40px)` }}>Aa</span>
          <span>
            <span className="block text-[12px] text-white/70">{item.label}</span>
            <span className="block font-mono text-[9.5px] uppercase tracking-[0.18em]" style={{ color: accent }}>{item.size}</span>
          </span>
        </div>
      )}

      {kind === "picto" && (() => {
        const Icon = MIROIR_PICTOS[item.picto];
        return (
          <div className="flex items-center gap-3">
            <Anneau reglages={reglages}>
              {Icon && <Icon className="h-5 w-5" style={{ color: accent }} strokeWidth={1.5} />}
            </Anneau>
            <span className="font-mono text-[10px] font-semibold uppercase tracking-[0.18em] text-white/60">{item.label}</span>
          </div>
        );
      })()}

      {kind === "format" && (
        <div className="flex items-center gap-3">
          <span
            className="h-12 w-16 shrink-0 border border-white/15 transition-all duration-300"
            style={{ borderRadius: rayon, background: LANGAGE.neutres.panneau, boxShadow: `0 0 0 ${reglages.liseret}px ${accent}33` }}
          />
          <span>
            <span className="block text-[12px] text-white/70">{item.label}</span>
            <span className="block font-mono text-[9.5px] uppercase tracking-[0.18em]" style={{ color: accent }}>morphologie vivante</span>
          </span>
        </div>
      )}

      {kind === "card" && (
        <div
          className="border border-white/12 p-3 transition-all duration-300"
          style={{ borderRadius: Math.min(rayon, 16), background: LANGAGE.neutres.panneau }}
        >
          <p className="font-mono text-[8.5px] font-semibold uppercase tracking-[0.2em]" style={{ color: accent }}>Module</p>
          <p className="mt-1 text-[13px] font-extrabold tracking-[-0.02em] text-white/95">{item.label}</p>
          <p className="mt-0.5 text-[11px] leading-snug text-white/45">{item.desc}</p>
        </div>
      )}
    </div>
  );
}