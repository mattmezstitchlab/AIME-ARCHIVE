import { useState } from "react";
import { ChevronLeft, ChevronRight, Wand2, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { SPECTRE } from "@/lib/aimeplus/langageAimePlus";

// LE NAVIGATEUR DE STYLES — plusieurs directions du langage AI+ME, gardées
// en mémoire pour comparer sans rien perdre. ◀ ▶ pour naviguer, « Générer »
// pour qu'une nouvelle direction soit proposée et ajoutée à la collection.
const STYLES_SOCLE = [
  { nom: "Signal", morpho: 55, liseret: 2, teinte: 3 },
  { nom: "Orbe", morpho: 10, liseret: 3, teinte: 4 },
  { nom: "Châssis", morpho: 95, liseret: 1, teinte: 0 },
  { nom: "Solaire", morpho: 40, liseret: 2, teinte: 1 },
];

export default function MiroirStyles({ stylesGeneres, onAddStyle, onApply }) {
  const styles = [...STYLES_SOCLE, ...stylesGeneres];
  const [idx, setIdx] = useState(0);
  const [loading, setLoading] = useState(false);
  const courant = styles[idx];

  const naviguer = (dir) => {
    const next = (idx + dir + styles.length) % styles.length;
    setIdx(next);
    onApply(styles[next]);
  };

  const generer = async () => {
    setLoading(true);
    const res = await base44.integrations.Core.InvokeLLM({
      prompt: `Tu es le directeur artistique du design system AI+ME : morphologie cercle→carré (morpho 0=cercle, 100=carré), liseré arc-en-ciel (1 à 4 px), teinte dominante parmi ce spectre : ${SPECTRE.join(", ")} (index 0 à 4). Propose UNE nouvelle direction stylistique différente de celles-ci : ${styles.map((s) => `${s.nom} (morpho ${s.morpho}, liseré ${s.liseret}, teinte ${s.teinte})`).join(" · ")}. Donne un nom court et évocateur en français (un seul mot).`,
      response_json_schema: {
        type: "object",
        properties: {
          nom: { type: "string" },
          morpho: { type: "number" },
          liseret: { type: "number" },
          teinte: { type: "number" },
        },
      },
    });
    const style = {
      nom: res.nom || "Sans nom",
      morpho: Math.min(100, Math.max(0, Math.round(res.morpho ?? 50))),
      liseret: Math.min(4, Math.max(1, Math.round(res.liseret ?? 2))),
      teinte: Math.min(4, Math.max(0, Math.round(res.teinte ?? 2))),
    };
    onAddStyle(style);
    setIdx(styles.length); // le nouveau style devient le courant
    onApply(style);
    setLoading(false);
  };

  return (
    <div className="rounded-2xl border border-white/12 bg-[#0f0f12] p-4">
      <p className="font-mono text-[9.5px] font-semibold uppercase tracking-[0.22em] text-white/45">
        Styles — la collection
      </p>
      <div className="mt-3 flex items-center justify-between">
        <button
          type="button" onClick={() => naviguer(-1)} aria-label="Style précédent"
          className="rounded-lg border border-white/15 p-1.5 text-white/60 hover:text-white"
        >
          <ChevronLeft className="h-3.5 w-3.5" />
        </button>
        <span className="text-center">
          <span className="block text-[14px] font-extrabold tracking-[-0.02em] text-white">{courant.nom}</span>
          <span className="block font-mono text-[8.5px] uppercase tracking-[0.14em] text-white/35">
            {idx + 1} / {styles.length}
          </span>
        </span>
        <button
          type="button" onClick={() => naviguer(1)} aria-label="Style suivant"
          className="rounded-lg border border-white/15 p-1.5 text-white/60 hover:text-white"
        >
          <ChevronRight className="h-3.5 w-3.5" />
        </button>
      </div>
      <button
        type="button"
        onClick={generer}
        disabled={loading}
        className="mt-3 inline-flex w-full items-center justify-center gap-2 rounded-lg border border-[#c084fc]/50 bg-[#c084fc]/10 px-3 py-2 font-mono text-[9.5px] font-bold uppercase tracking-[0.16em] text-[#c084fc] transition hover:bg-[#c084fc]/20 disabled:opacity-50"
      >
        {loading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Wand2 className="h-3.5 w-3.5" />}
        {loading ? "Génération…" : "Générer un style"}
      </button>
    </div>
  );
}