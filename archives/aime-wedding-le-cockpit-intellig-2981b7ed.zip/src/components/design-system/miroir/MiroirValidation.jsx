import { useState } from "react";
import { CheckCheck, Loader2, X } from "lucide-react";
import { base44 } from "@/api/base44Client";

// LA BARRE VALIDER — ramasse toutes les décisions et instructions, les fait
// analyser, enregistre le COMPTE RENDU en base (l'agent IA le lira pour la
// repasse), et l'affiche à l'écran.
export default function MiroirValidation({ items, decisions, commentaires, reglages }) {
  const [loading, setLoading] = useState(false);
  const [rendu, setRendu] = useState(null);

  const annotes = items.filter((it) => decisions[it.id] || commentaires[it.id]);
  const nbAdoptes = items.filter((it) => decisions[it.id] === "adopter").length;
  const nbSupprimes = items.filter((it) => decisions[it.id] === "supprimer").length;
  const nbNotes = items.filter((it) => (commentaires[it.id] || "").trim()).length;

  const valider = async () => {
    setLoading(true);
    const detail = annotes.map((it) => ({
      id: it.id,
      label: it.label,
      category: it.category,
      decision: decisions[it.id] || "",
      commentaire: (commentaires[it.id] || "").trim(),
    }));

    const analyse = await base44.integrations.Core.InvokeLLM({
      prompt: `Tu es l'assistant du design system AI+ME. Voici les décisions prises dans le Miroir (adopter = passer l'élément au nouveau langage AI+ME ; supprimer = retirer l'ancien élément du site) et les instructions laissées par le créateur :\n${detail.map((d) => `- [${d.decision || "note"}] ${d.category} · ${d.label}${d.commentaire ? ` — instruction : « ${d.commentaire} »` : ""}`).join("\n")}\nRédige en français : un résumé clair de 2-3 phrases de ce qui est demandé, puis la liste des actions prioritaires (courtes, actionnables) pour l'agent qui fera la repasse.`,
      response_json_schema: {
        type: "object",
        properties: {
          resume: { type: "string" },
          priorites: { type: "array", items: { type: "string" } },
        },
      },
    });

    const record = await base44.entities.MiroirCompteRendu.create({
      titre: `Validation Miroir — ${new Date().toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" })}`,
      resume: analyse.resume || "",
      priorites: analyse.priorites || [],
      adoptes: nbAdoptes,
      supprimes: nbSupprimes,
      items: detail,
      reglages,
    });
    setRendu(record);
    setLoading(false);
  };

  return (
    <>
      {/* LE COMPTE RENDU — affiché après analyse, enregistré pour l'agent. */}
      {rendu && (
        <div className="fixed inset-x-0 bottom-20 z-50 mx-auto max-w-2xl px-4">
          <div className="rounded-2xl border border-emerald-400/40 bg-[#0c0f0d] p-5 shadow-2xl">
            <div className="flex items-start justify-between gap-3">
              <p className="font-mono text-[9.5px] font-bold uppercase tracking-[0.2em] text-emerald-300">
                Compte rendu — transmis à l'agent
              </p>
              <button type="button" onClick={() => setRendu(null)} aria-label="Fermer le compte rendu" className="text-white/40 hover:text-white">
                <X className="h-4 w-4" />
              </button>
            </div>
            <p className="mt-2 text-[13px] leading-relaxed text-white/80">{rendu.resume}</p>
            {rendu.priorites?.length > 0 && (
              <ul className="mt-3 space-y-1.5">
                {rendu.priorites.map((p, i) => (
                  <li key={i} className="flex gap-2 text-[12px] text-white/60">
                    <span className="font-mono text-[10px] font-bold text-emerald-300">{String(i + 1).padStart(2, "0")}</span>
                    {p}
                  </li>
                ))}
              </ul>
            )}
            <p className="mt-3 border-t border-white/10 pt-2 font-mono text-[9px] uppercase tracking-[0.14em] text-white/35">
              Enregistré — l'agent le lira pour la repasse.
            </p>
          </div>
        </div>
      )}

      {/* LA BARRE FIXE — compteurs + VALIDER. */}
      <div className="fixed inset-x-0 bottom-4 z-40 mx-auto max-w-2xl px-4">
        <div className="flex items-center gap-3 rounded-2xl border border-white/15 bg-[#0a0a0c]/95 px-4 py-3 shadow-2xl backdrop-blur">
          <p className="flex-1 text-[12px] text-white/60">
            <span className="text-emerald-400">{nbAdoptes} adopté{nbAdoptes > 1 ? "s" : ""}</span>
            {" · "}
            <span className="text-red-400">{nbSupprimes} à supprimer</span>
            {" · "}
            <span className="text-[#38bdf8]">{nbNotes} instruction{nbNotes > 1 ? "s" : ""}</span>
          </p>
          <button
            type="button"
            onClick={valider}
            disabled={loading || annotes.length === 0}
            className="inline-flex items-center gap-2 rounded-full bg-white px-5 py-2 text-[13px] font-bold text-black transition hover:bg-white/85 disabled:opacity-40"
          >
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCheck className="h-4 w-4" />}
            {loading ? "Analyse…" : "Valider"}
          </button>
        </div>
      </div>
    </>
  );
}