import { TYPO_FAMILIES } from "@/lib/ripple/designSystemStore";

// Section Typographies — familles (titres / corps) + réglage de chaque taille.
const SIZE_LABELS = {
  "s-6xl": "Titre hero",
  "s-4xl": "Titre section",
  "s-2xl": "Chiffre-clé",
  "s-lg": "Intro",
  "s-sm": "Corps",
  "s-xs": "Légende",
};

export default function DsTypoSection({ typo, sizes, onTypo, onSize }) {
  return (
    <div className="space-y-6">
      <div className="grid gap-3 sm:grid-cols-2">
        {["heading", "body"].map((role) => (
          <div key={role} className="rounded-xl border border-white/10 bg-white/[0.03] p-4">
            <p className="text-[11px] font-semibold uppercase tracking-widest text-white/45">
              {role === "heading" ? "Typo des titres" : "Typo du corps"}
            </p>
            <select
              value={typo[role]}
              onChange={(e) => onTypo(role, e.target.value)}
              className="mt-2 w-full rounded-lg border border-white/15 bg-black px-3 py-2 text-sm text-white"
              aria-label={role === "heading" ? "Famille des titres" : "Famille du corps"}
            >
              {TYPO_FAMILIES.map((f) => (
                <option key={f} value={f}>{f}</option>
              ))}
            </select>
            <p
              className="mt-3 truncate text-2xl text-white"
              style={{ fontFamily: `'${typo[role]}', sans-serif` }}
            >
              Aa Bb Cc — L'onde causale
            </p>
          </div>
        ))}
      </div>

      <div className="space-y-3">
        {Object.entries(sizes).map(([role, px]) => (
          <div key={role} className="flex items-center gap-4 rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3">
            <span className="w-28 shrink-0 text-[12px] text-white/70">{SIZE_LABELS[role] || role}</span>
            <input
              type="range"
              min="9"
              max="96"
              value={px}
              onChange={(e) => onSize(role, Number(e.target.value))}
              className="ripple-range h-1 flex-1 cursor-pointer appearance-none rounded-full bg-white/15"
              aria-label={`Taille ${SIZE_LABELS[role] || role}`}
            />
            <span className="w-12 shrink-0 text-right font-mono text-[11px] text-white/50">{px}px</span>
            <span
              className="hidden w-40 shrink-0 overflow-hidden whitespace-nowrap text-white/85 sm:block"
              style={{ fontSize: Math.min(px, 34), fontFamily: `'${typo.heading}', sans-serif`, lineHeight: 1.1 }}
            >
              Mariage
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}