import { useState } from "react";
import { Check, AlertTriangle, ShieldAlert, ChevronDown, Globe } from "lucide-react";
import {
  getDestination, PASSPORT_ITEMS, readinessForDestination, nextStepsForDestination,
} from "@/lib/international";
import FlagBadge from "@/components/search/FlagBadge";

const TONE = {
  ok: { dot: "bg-foreground", text: "text-foreground", Icon: Check },
  warn: { dot: "bg-amber-500", text: "text-amber-700", Icon: AlertTriangle },
  alert: { dot: "bg-rose-500", text: "text-rose-700", Icon: ShieldAlert },
  muted: { dot: "bg-muted-foreground", text: "text-muted-foreground", Icon: Globe },
};

// Passeport mondial affiché sur une carte prestataire quand une destination est choisie.
// Replié par défaut : badge de préparation + détail dépliable des 5 piliers et prochaines étapes.
export default function PassportBadge({ destinationCode, artist }) {
  const [open, setOpen] = useState(false);
  const destination = getDestination(destinationCode);
  if (!destination) return null;

  const readiness = readinessForDestination(destination, artist);
  const tone = TONE[readiness.tone] || TONE.muted;
  const steps = nextStepsForDestination(destination);

  return (
    <div className="mt-3 pt-3 border-t border-border">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        className="w-full flex items-center gap-2 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 rounded-md"
      >
        <FlagBadge flag={destination.flag} name={destination.name} size="sm" />
        <span className={`w-2 h-2 rounded-full ${tone.dot}`} aria-hidden="true" />
        <span className={`text-xs font-semibold ${tone.text}`}>{readiness.label}</span>
        <span className="text-xs text-muted-foreground">· {destination.name}</span>
        <ChevronDown className={`w-3.5 h-3.5 ml-auto text-muted-foreground transition-transform ${open ? "rotate-180" : ""}`} aria-hidden="true" />
      </button>

      {open && (
        <div className="mt-3 space-y-2">
          {PASSPORT_ITEMS.map((item) => (
            <div key={item.key} className="text-xs">
              <span className="font-medium text-foreground">{item.label} : </span>
              <span className="text-muted-foreground">{destination[item.field]}</span>
            </div>
          ))}
          <div className="pt-2 mt-1 border-t border-border">
            <p className="text-xs font-semibold text-foreground mb-1">Prochaines étapes guidées</p>
            <ul className="space-y-1">
              {steps.map((s, i) => (
                <li key={i} className="text-xs text-muted-foreground flex items-start gap-1.5">
                  <span className="text-foreground mt-0.5" aria-hidden="true">→</span>{s}
                </li>
              ))}
            </ul>
          </div>
          <p className="text-[11px] text-muted-foreground/70 pt-1">
            Informations indicatives — aucune autorisation, visa ou statut n'est garanti automatiquement.
          </p>
        </div>
      )}
    </div>
  );
}