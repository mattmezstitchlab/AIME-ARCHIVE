// Pastille drapeau moderne : l'emoji drapeau dans un cercle net, ombré, taille réglable.
// Plus soigné qu'un emoji nu posé dans le texte.
const SIZES = {
  sm: "w-5 h-5 text-[11px]",
  md: "w-8 h-8 text-base",
  lg: "w-11 h-11 text-xl",
};

export default function FlagBadge({ flag, name, size = "md" }) {
  return (
    <span
      role="img"
      aria-label={name ? `Drapeau ${name}` : "Drapeau"}
      className={`inline-flex items-center justify-center rounded-full bg-background border border-border shadow-sm overflow-hidden leading-none ${SIZES[size] || SIZES.md}`}
    >
      <span aria-hidden="true">{flag}</span>
    </span>
  );
}