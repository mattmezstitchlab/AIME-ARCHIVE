import { Globe, X } from "lucide-react";
import { DESTINATIONS, getDestination } from "@/lib/international";

// Bandeau "international" : choisir un pays de destination pour le mariage / la mission.
// Active l'affichage du passeport mondial sur chaque prestataire.
export default function InternationalBar({ destinationCode, onChange }) {
  const active = getDestination(destinationCode);

  return (
    <div className="rounded-xl border border-border bg-muted/30 p-4 mb-6">
      <div className="flex items-start gap-3">
        <div className="w-9 h-9 rounded-full bg-foreground text-background flex items-center justify-center shrink-0">
          <Globe className="w-4 h-4" aria-hidden="true" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold text-foreground">L'amour dépasse les frontières</p>
          <p className="text-xs text-muted-foreground mb-3">
            Choisissez un pays : chaque prestataire affiche sa préparation mondiale (facturation, visa, sécurité sociale, droits). On vous guide, partout dans le monde.
          </p>
          <div className="flex flex-wrap gap-2" role="group" aria-label="Pays de destination">
            {DESTINATIONS.map((d) => {
              const isActive = destinationCode === d.code;
              return (
                <button
                  key={d.code}
                  type="button"
                  onClick={() => onChange(isActive ? "" : d.code)}
                  aria-pressed={isActive}
                  className={`px-3 py-1.5 min-h-[34px] text-xs font-medium rounded-full border transition-colors flex items-center gap-1.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 ${
                    isActive ? "bg-foreground text-background border-foreground" : "border-border text-foreground bg-background hover:bg-muted"
                  }`}
                >
                  <span aria-hidden="true">{d.flag}</span>
                  {d.name}
                </button>
              );
            })}
          </div>
          {active && (
            <button
              type="button"
              onClick={() => onChange("")}
              className="mt-3 inline-flex items-center gap-1 text-xs font-medium text-muted-foreground hover:text-foreground transition-colors"
            >
              <X className="w-3 h-3" aria-hidden="true" /> Revenir à une recherche en France
            </button>
          )}
        </div>
      </div>
    </div>
  );
}