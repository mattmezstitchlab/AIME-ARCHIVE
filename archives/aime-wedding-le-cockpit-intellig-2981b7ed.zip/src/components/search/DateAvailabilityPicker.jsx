import { useState } from "react";
import { Calendar } from "@/components/ui/calendar";
import { X } from "lucide-react";

// Format local AAAA-MM-JJ (évite le décalage UTC de toISOString).
function toKey(date) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

function fromKey(key) {
  const [y, m, d] = key.split("-").map(Number);
  return new Date(y, m - 1, d);
}

const fmt = new Intl.DateTimeFormat("fr-FR", { day: "numeric", month: "short" });

// Sélecteur de jours précis : le couple choisit une ou plusieurs dates de mariage
// possibles, et la liste se filtre sur les prestataires disponibles ces jours-là.
export default function DateAvailabilityPicker({ dates = [], onChange }) {
  const [open, setOpen] = useState(false);
  const selected = dates.map(fromKey);

  const handleSelect = (days) => {
    const keys = (days || []).map(toKey);
    onChange(keys.sort());
  };

  const removeOne = (key) => onChange(dates.filter((d) => d !== key));

  return (
    <div>
      {dates.length > 0 && (
        <div className="mb-3 flex flex-wrap gap-1.5">
          {dates.map((key) => (
            <span key={key} className="inline-flex items-center gap-1 rounded-full bg-foreground px-2.5 py-1 text-xs font-medium text-background">
              {fmt.format(fromKey(key))}
              <button
                type="button"
                onClick={() => removeOne(key)}
                aria-label={`Retirer le ${fmt.format(fromKey(key))}`}
                className="hover:opacity-70"
              >
                <X className="h-3 w-3" aria-hidden="true" />
              </button>
            </span>
          ))}
          <button
            type="button"
            onClick={() => onChange([])}
            className="text-xs font-medium text-muted-foreground hover:text-foreground underline underline-offset-2"
          >
            Tout effacer
          </button>
        </div>
      )}

      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        className="w-full rounded-lg border border-border bg-background px-3 py-2 text-left text-sm text-foreground hover:bg-muted transition-colors"
      >
        {dates.length > 0
          ? `${dates.length} jour${dates.length > 1 ? "s" : ""} sélectionné${dates.length > 1 ? "s" : ""}`
          : "Choisir des jours précis"}
      </button>

      {open && (
        <div className="mt-2 rounded-lg border border-border bg-background p-2">
          <Calendar
            mode="multiple"
            selected={selected}
            onSelect={handleSelect}
            disabled={{ before: new Date() }}
          />
        </div>
      )}
    </div>
  );
}