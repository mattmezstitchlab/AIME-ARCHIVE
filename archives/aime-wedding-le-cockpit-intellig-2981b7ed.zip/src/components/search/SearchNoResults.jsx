import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Search, MapPin, Grid3x3, Compass, FolderHeart, ArrowRight } from "lucide-react";
import { useGuide } from "@/lib/guide/GuideContext";
import { findWeddingPlan } from "@/lib/guide/plans";

// Catégories proches proposées quand une recherche ne renvoie rien.
const NEARBY = [
  { label: "Photographe", q: "Photographe" },
  { label: "Vidéaste", q: "Vidéaste" },
  { label: "Musicien / DJ", q: "Musicien" },
  { label: "Fleuriste", q: "Fleuriste" },
  { label: "Traiteur", q: "Traiteur" },
  { label: "Décoration", q: "Décorateur" },
  { label: "Maquillage", q: "Maquilleur" },
  { label: "Coiffure", q: "Coiffeur" },
];

// État « aucun résultat » utile : élargir, catégories proches, Guide, dossier mariage.
export default function SearchNoResults({ searchWhat = "", searchWhere = "", onClearWhere }) {
  const { openGuide } = useGuide();
  const [weddingPlan, setWeddingPlan] = useState(null);

  useEffect(() => {
    findWeddingPlan().then(setWeddingPlan).catch(() => setWeddingPlan(null));
  }, []);

  const guideIntent = [searchWhat, searchWhere && `à ${searchWhere}`].filter(Boolean).join(" ").trim();

  return (
    <div className="rounded-xl border border-border bg-muted/20 p-6 sm:p-8">
      <div className="flex items-start gap-3 mb-6">
        <span className="flex items-center justify-center w-10 h-10 rounded-full bg-foreground text-background shrink-0">
          <Search className="w-5 h-5" aria-hidden="true" />
        </span>
        <div>
          <h2 className="text-lg font-medium text-foreground mb-1">
            Aucun prestataire pour cette recherche
          </h2>
          <p className="text-sm text-muted-foreground leading-relaxed">
            Élargissez votre zone, explorez des catégories proches, ou laissez le Guide vous orienter.
          </p>
        </div>
      </div>

      <div className="space-y-5">
        {/* Élargir la ville / le rayon */}
        {searchWhere && (
          <div>
            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2">
              Élargir la zone
            </p>
            <button
              type="button"
              onClick={onClearWhere}
              className="inline-flex items-center gap-1.5 text-sm font-medium text-foreground border border-border rounded-full px-3.5 py-1.5 hover:bg-muted transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
            >
              <MapPin className="w-3.5 h-3.5" aria-hidden="true" />
              Rechercher partout, sans « {searchWhere} »
            </button>
          </div>
        )}

        {/* Catégories proches */}
        <div>
          <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2">
            <Grid3x3 className="w-3.5 h-3.5 inline mr-1 -mt-0.5" aria-hidden="true" />
            Catégories proches
          </p>
          <div className="flex flex-wrap gap-2">
            {NEARBY.map((c) => (
              <Link
                key={c.q}
                to={`/recherche?q=${encodeURIComponent(c.q)}`}
                className="text-sm font-medium text-foreground border border-border rounded-full px-3.5 py-1.5 hover:bg-muted transition-colors"
              >
                {c.label}
              </Link>
            ))}
          </div>
        </div>

        {/* Demander au Guide */}
        <div>
          <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2">
            Besoin d'aide ?
          </p>
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => openGuide(guideIntent ? `Je cherche : ${guideIntent}` : "", { autoAsk: Boolean(guideIntent) })}
              className="inline-flex items-center gap-1.5 text-sm font-medium bg-foreground text-background rounded-full px-4 py-2 hover:bg-foreground/90 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
            >
              <Compass className="w-4 h-4" aria-hidden="true" />
              Demander au Guide
            </button>

            {/* Ajouter ce besoin au dossier mariage existant */}
            {weddingPlan && (
              <Link
                to={`/mon-compte/plans/${weddingPlan.id}`}
                className="inline-flex items-center gap-1.5 text-sm font-medium text-foreground border border-border rounded-full px-4 py-2 hover:bg-muted transition-colors"
              >
                <FolderHeart className="w-4 h-4" aria-hidden="true" />
                Ajouter à mon mariage
                <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
              </Link>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}