import { cn } from "@/lib/utils";

/**
 * Indicateur de chargement accessible : role="status" + aria-live="polite",
 * libellé textuel annoncé aux lecteurs d'écran. Rendu visuel sobre par tokens.
 * `variant` = "spinner" (défaut) ou "skeleton" (passez `children` comme squelette).
 */
export default function AccessibleLoading({
  label = "Chargement en cours…",
  variant = "spinner",
  className = "",
  children,
}) {
  if (variant === "skeleton") {
    return (
      <div role="status" aria-live="polite" className={className}>
        <span className="sr-only">{label}</span>
        <div aria-hidden="true">{children}</div>
      </div>
    );
  }

  return (
    <div
      role="status"
      aria-live="polite"
      className={cn("flex items-center justify-center gap-3 py-8", className)}
    >
      <span
        className="w-6 h-6 border-2 border-muted border-t-foreground rounded-full animate-spin motion-reduce:animate-none"
        aria-hidden="true"
      />
      <span className="text-sm text-muted-foreground">{label}</span>
    </div>
  );
}