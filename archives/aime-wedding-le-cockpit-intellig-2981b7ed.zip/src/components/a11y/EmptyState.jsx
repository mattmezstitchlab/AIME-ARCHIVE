/**
 * État vide accessible et premium : titre, description et action optionnelle.
 * Icône décorative (aria-hidden). Utilise les tokens uniquement.
 */
export default function EmptyState({ icon: Icon, title, description, action }) {
  return (
    <div className="text-center py-12 px-6 rounded-xl border border-border bg-muted/20">
      {Icon && (
        <Icon className="w-8 h-8 text-muted-foreground/60 mx-auto mb-4" aria-hidden="true" />
      )}
      <p className="text-base font-medium text-foreground mb-1.5">{title}</p>
      {description && (
        <p className="text-sm text-muted-foreground max-w-md mx-auto">{description}</p>
      )}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}