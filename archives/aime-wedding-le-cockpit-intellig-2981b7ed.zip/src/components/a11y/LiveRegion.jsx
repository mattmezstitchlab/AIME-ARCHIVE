/**
 * Région live pour annoncer des changements dynamiques aux lecteurs d'écran.
 * Visuellement masquée (sr-only) ; `politeness` = "polite" (défaut) ou "assertive".
 */
export default function LiveRegion({ message, politeness = "polite" }) {
  return (
    <div aria-live={politeness} aria-atomic="true" className="sr-only">
      {message}
    </div>
  );
}