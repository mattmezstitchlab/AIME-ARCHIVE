import { AlertCircle } from "lucide-react";

/**
 * Message d'erreur de champ : texte + icône (jamais la couleur seule),
 * role="alert" pour annonce immédiate. L'`id` doit être référencé par aria-describedby du champ.
 */
export default function FormError({ id, children }) {
  if (!children) return null;
  return (
    <p id={id} role="alert" className="mt-1.5 flex items-start gap-1.5 text-xs text-destructive">
      <AlertCircle className="w-3.5 h-3.5 shrink-0 mt-px" aria-hidden="true" />
      <span>{children}</span>
    </p>
  );
}