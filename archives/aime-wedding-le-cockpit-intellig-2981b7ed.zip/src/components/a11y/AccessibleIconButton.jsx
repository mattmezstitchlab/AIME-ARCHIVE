import { forwardRef } from "react";
import { cn } from "@/lib/utils";

/**
 * Bouton icône-seule accessible : `label` obligatoire (aria-label en français),
 * icône décorative (aria-hidden), focus visible par tokens, cible tactile confortable.
 */
const AccessibleIconButton = forwardRef(function AccessibleIconButton(
  { label, children, className = "", ...props },
  ref
) {
  return (
    <button
      ref={ref}
      type="button"
      aria-label={label}
      title={label}
      className={cn(
        "inline-flex items-center justify-center rounded-full transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:opacity-50 disabled:pointer-events-none",
        className
      )}
      {...props}
    >
      {children}
    </button>
  );
});

export default AccessibleIconButton;