/**
 * Lien d'évitement « Aller au contenu principal ».
 * Invisible jusqu'au focus clavier, puis affiché en haut de page (tokens uniquement).
 */
export default function SkipLink() {
  return (
    <a
      href="#contenu-principal"
      className="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:z-[100] focus:rounded-md focus:bg-foreground focus:text-background focus:px-4 focus:py-2 focus:text-sm focus:font-medium focus:shadow-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
    >
      Aller au contenu principal
    </a>
  );
}