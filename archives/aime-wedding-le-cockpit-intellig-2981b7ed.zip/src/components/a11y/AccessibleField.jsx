import { Label } from "@/components/ui/label";
import FormError from "@/components/a11y/FormError";

/**
 * Champ accessible : label réel lié par htmlFor/id, indication « obligatoire » textuelle
 * (pas seulement un astérisque), description optionnelle, et gestion d'erreur (aria-invalid +
 * aria-describedby). Le `children` reçoit { id, "aria-invalid", "aria-describedby" } à appliquer
 * sur l'input/select/textarea via render-prop.
 */
export default function AccessibleField({
  id,
  label,
  required = false,
  description,
  error,
  children,
}) {
  const descId = description ? `${id}-desc` : undefined;
  const errId = error ? `${id}-error` : undefined;
  const describedBy = [descId, errId].filter(Boolean).join(" ") || undefined;

  return (
    <div>
      <Label htmlFor={id} className="text-sm font-medium text-foreground">
        {label}
        {required && (
          <span className="text-muted-foreground font-normal"> (obligatoire)</span>
        )}
      </Label>
      {description && (
        <p id={descId} className="text-xs text-muted-foreground mt-1">
          {description}
        </p>
      )}
      <div className="mt-1.5">
        {children({
          id,
          required,
          "aria-invalid": error ? true : undefined,
          "aria-describedby": describedBy,
        })}
      </div>
      <FormError id={errId}>{error}</FormError>
    </div>
  );
}