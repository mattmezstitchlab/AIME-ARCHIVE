import { useState, useEffect } from "react";

// Visuels « apesanteur dans l'espace », un par grande famille de rôle.
// En miroir du hero de la home : ici le fond descend du ciel à l'ouverture.
const ROLE_VISUALS = {
  couple: "https://media.base44.com/images/public/6a4121ee87663bd9b9c98ef7/d64d131fb_generated_image.png",
  prestataire: "https://media.base44.com/images/public/6a4121ee87663bd9b9c98ef7/1f528861e_generated_image.png",
  invite: "https://media.base44.com/images/public/6a4121ee87663bd9b9c98ef7/f2226d316_generated_image.png",
};

// Les 7 rôles du parcours ramenés aux 3 visuels disponibles.
const ROLE_TO_VISUAL = {
  couple: "couple",
  coordinateur: "couple",
  lieu: "prestataire",
  prestataire: "prestataire",
  temoin: "invite",
  famille: "invite",
  invite: "invite",
};

// Fond immersif de l'espace personnel : l'image liée au rôle « descend » du haut
// à l'ouverture de la page, puis se fige derrière le contenu (qui passe par-dessus).
export default function AccountSpaceBackdrop({ role = "couple" }) {
  const [descended, setDescended] = useState(false);
  const visualKey = ROLE_TO_VISUAL[role] || "couple";
  const src = ROLE_VISUALS[visualKey];

  // Déclenche la descente au montage (effet inverse du hero qui monte sur la home).
  useEffect(() => {
    const t = requestAnimationFrame(() => setDescended(true));
    return () => cancelAnimationFrame(t);
  }, []);

  return (
    <div className="fixed inset-0 z-0 overflow-hidden bg-black" aria-hidden="true">
      <img
        src={src}
        alt=""
        className={`absolute inset-0 h-full w-full object-cover transition-transform duration-[1100ms] ease-out ${
          descended ? "translate-y-0" : "-translate-y-full"
        }`}
      />
      {/* Voile dégradé pour la lisibilité du contenu posé par-dessus — reste
          sombre jusqu'en bas pour que le visuel couvre tout l'écran au scroll */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-black/50 to-black/70" />
    </div>
  );
}