import { UserPlus, X } from "lucide-react";

// Bannière affichée quand on arrive depuis « Collaborer » avec un rôle à inviter.
// Indicative : guide l'utilisateur à ouvrir un dossier pour préparer l'invitation.
const ROLE_LABELS = {
  conjoint: "votre conjoint·e",
  temoin: "un témoin",
  famille: "un proche / la famille",
  planner: "un wedding planner ou prestataire",
};

export default function InviteBanner({ role, onDismiss }) {
  const who = ROLE_LABELS[role];
  if (!who) return null;

  return (
    <div className="mb-6 rounded-xl border border-foreground/20 bg-muted/40 p-4 flex items-start gap-3">
      <span className="flex items-center justify-center w-9 h-9 rounded-full bg-foreground text-background shrink-0">
        <UserPlus className="w-4 h-4" aria-hidden="true" />
      </span>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-semibold text-foreground">Inviter {who}</p>
        <p className="text-xs text-muted-foreground">
          Ouvrez un dossier ci-dessous, puis ajoutez l'invitation dans l'onglet « Documents » du dossier. L'invitation reste un brouillon — aucun e-mail n'est envoyé sans votre accord.
        </p>
      </div>
      <button
        type="button"
        onClick={onDismiss}
        aria-label="Fermer"
        className="text-muted-foreground hover:text-foreground transition-colors shrink-0"
      >
        <X className="w-4 h-4" aria-hidden="true" />
      </button>
    </div>
  );
}