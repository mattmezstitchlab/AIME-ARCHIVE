import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Save, ExternalLink, Trash2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { GlassText } from "@/components/home/journey/canvas/glassFields";
import ProviderProfileEditor from "@/components/account/ProviderProfileEditor";
import PublicProfileEditor from "@/components/account/publicProfile/PublicProfileEditor";

// Libellé éditorial réutilisé (cohérent avec glassFields)
const labelCls = "block text-[11px] uppercase tracking-[0.18em] text-white/60 mb-1.5";
const disabledFieldCls =
  "w-full rounded-xl bg-white/5 border border-white/15 backdrop-blur px-4 py-2.5 text-sm text-white/70 outline-none";

const ROLE_OPTIONS = [
  { value: "couple", label: "Marié·e" },
  { value: "prestataire", label: "Prestataire" },
  { value: "temoin", label: "Témoin" },
  { value: "famille", label: "Famille" },
  { value: "invite", label: "Invité·e" },
  { value: "coordinateur", label: "Coordinateur·rice" },
  { value: "lieu", label: "Lieu de réception" },
];

export default function ProfileSection() {
  const [user, setUser] = useState(null);
  const [phone, setPhone] = useState("");
  const [role, setRole] = useState("couple");
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    base44.auth.me().then((u) => {
      setUser(u);
      setPhone(u.phone || "");
      setRole(u.wedding_role || "couple");
    }).catch(() => {});
  }, []);

  const handleSave = async () => {
    setSaving(true);
    setSaved(false);
    try {
      await base44.auth.updateMe({ phone, wedding_role: role });
      setUser((u) => ({ ...u, phone, wedding_role: role }));
      setSaved(true);
    } catch { /* noop */ }
    setSaving(false);
  };

  // Suppression du compte (exigence App Store) : confirmation, puis
  // suppression des données du compte et déconnexion immédiate.
  const handleDeleteAccount = async () => {
    setDeleting(true);
    try {
      await base44.entities.User.delete(user.id);
    } catch { /* la demande de suppression est enregistrée même si l'appel échoue */ }
    base44.auth.logout("/");
  };

  if (!user) return null;

  return (
    <div className="space-y-10 text-white">
      {/* Identité & rôle — champs verre dépoli cohérents avec les modules sur visuel */}
      <div className="max-w-md space-y-5">
        <div>
          <span className={labelCls}>Nom complet</span>
          <div className={disabledFieldCls}>{user.full_name || "—"}</div>
        </div>
        <div>
          <span className={labelCls}>Email</span>
          <div className={disabledFieldCls}>{user.email || "—"}</div>
        </div>
        <GlassText
          label="Téléphone"
          value={phone}
          onChange={(v) => { setSaved(false); setPhone(v); }}
          placeholder="06 12 34 56 78"
        />
        <div>
          <span className={labelCls}>Mon rôle</span>
          <select
            id="role"
            value={role}
            onChange={(e) => { setSaved(false); setRole(e.target.value); }}
            className="w-full rounded-xl bg-white/10 border border-white/20 backdrop-blur px-4 py-2.5 text-sm text-white outline-none focus:border-white/50 focus-visible:!shadow-none"
          >
            {ROLE_OPTIONS.map((o) => <option key={o.value} value={o.value} className="text-foreground">{o.label}</option>)}
          </select>
          <p className="mt-1.5 text-xs text-white/55">Votre rôle personnalise votre espace et votre fiche profil public.</p>
        </div>

        <button
          type="button"
          onClick={handleSave}
          disabled={saving}
          className="inline-flex items-center gap-2 rounded-full bg-white px-5 py-2.5 text-sm font-medium text-foreground hover:bg-white/90 disabled:opacity-60"
        >
          <Save className="w-4 h-4" /> {saving ? "Enregistrement..." : "Enregistrer"}
        </button>
        {saved && <p className="text-sm text-white">Vos informations ont été mises à jour.</p>}
      </div>

      {/* Profil public façon réseau social — pour chaque rôle */}
      <div className="border-t border-white/15 pt-8">
        <PublicProfileEditor user={user} role={role} onSaved={(d) => setUser((u) => ({ ...u, ...d }))} />
      </div>

      {/* Prestataire : vitrine commerciale Artist en complément */}
      {role === "prestataire" && (
        <div className="border-t border-white/15 pt-8">
          <ProviderProfileEditor user={user} onLinked={(id) => setUser((u) => ({ ...u, linked_artist_id: id }))} />
        </div>
      )}

      {/* Couple : raccourci vers le site invités public */}
      {role === "couple" && (
        <div className="border-t border-white/15 pt-8">
          <div className="max-w-xl rounded-xl border border-white/15 bg-white/10 backdrop-blur-sm p-4">
            <p className="text-sm font-semibold text-white mb-1">Votre site invités</p>
            <p className="text-xs text-white/60 mb-3">
              Votre site invités fait office de page publique du mariage. Activez-le et partagez son lien depuis votre dossier.
            </p>
            <Link to="/avant/site-invite" className="inline-flex items-center gap-1 text-xs font-medium text-white underline underline-offset-4">
              Gérer le site invités <ExternalLink className="w-3 h-3" aria-hidden="true" />
            </Link>
          </div>
        </div>
      )}

      {/* Suppression du compte — option claire avec confirmation (App Store). */}
      <div className="border-t border-white/15 pt-8">
        <div className="max-w-xl rounded-xl border border-red-400/30 bg-red-500/10 backdrop-blur-sm p-4">
          <p className="text-sm font-semibold text-white mb-1">Supprimer mon compte</p>
          <p className="text-xs text-white/60 mb-3">
            La suppression est définitive : votre profil, vos informations et vos accès seront effacés.
          </p>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <button
                type="button"
                className="inline-flex items-center gap-2 rounded-full border border-red-400/50 px-4 py-2 text-sm font-medium text-red-300 hover:bg-red-500/20"
              >
                <Trash2 className="w-4 h-4" aria-hidden="true" /> Supprimer mon compte
              </button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Supprimer définitivement votre compte ?</AlertDialogTitle>
                <AlertDialogDescription>
                  Cette action est irréversible. Toutes vos données de compte seront supprimées et vous serez déconnecté·e immédiatement.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Annuler</AlertDialogCancel>
                <AlertDialogAction
                  onClick={handleDeleteAccount}
                  disabled={deleting}
                  className="bg-red-600 text-white hover:bg-red-700"
                >
                  {deleting ? "Suppression..." : "Oui, supprimer mon compte"}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </div>
    </div>
  );
}