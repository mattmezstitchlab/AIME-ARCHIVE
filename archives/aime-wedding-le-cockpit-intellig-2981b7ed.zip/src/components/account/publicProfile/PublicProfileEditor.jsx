import { useState } from "react";
import { Switch } from "@/components/ui/switch";
import { Save, Loader2, ImagePlus, UserCircle } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { GlassText } from "@/components/home/journey/canvas/glassFields";
import { getRoleProfile } from "./roleProfiles";
import PublicProfileCard from "./PublicProfileCard";

// Libellé éditorial cohérent avec glassFields (modules sur visuel).
const labelCls = "block text-[11px] uppercase tracking-[0.18em] text-white/60 mb-1.5";
const uploadCls =
  "mt-1 flex h-[42px] cursor-pointer items-center justify-center gap-2 rounded-xl border border-white/20 bg-white/10 backdrop-blur text-xs text-white/70 hover:bg-white/15";

// Éditeur de profil public façon réseau social, commun à tous les rôles.
// Chaque participant (marié, prestataire, invité, témoin…) gère sa propre fiche.
export default function PublicProfileEditor({ user, role, onSaved }) {
  const cfg = getRoleProfile(role);
  const [uploading, setUploading] = useState(null); // 'avatar' | 'cover'
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [form, setForm] = useState({
    public_display_name: user.public_display_name || "",
    public_headline: user.public_headline || "",
    public_bio: user.public_bio || "",
    public_location: user.public_location || "",
    public_link: user.public_link || "",
    public_avatar_url: user.public_avatar_url || "",
    public_cover_url: user.public_cover_url || "",
    public_visible: user.public_visible !== false,
  });

  const set = (k, v) => { setSaved(false); setForm((f) => ({ ...f, [k]: v })); };

  const handleUpload = async (field, file) => {
    if (!file) return;
    setUploading(field === "public_avatar_url" ? "avatar" : "cover");
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      set(field, file_url);
    } catch { /* noop */ }
    setUploading(null);
  };

  const handleSave = async () => {
    setSaving(true);
    setSaved(false);
    try {
      await base44.auth.updateMe(form);
      setSaved(true);
      onSaved?.(form);
    } catch { /* noop */ }
    setSaving(false);
  };

  return (
    <div className="mx-auto grid w-full max-w-5xl grid-cols-1 items-start justify-center gap-6 lg:grid-cols-[minmax(280px,380px)_minmax(340px,460px)] lg:gap-10">
      {/* Aperçu façon réseau social */}
      <div className="mx-auto w-full max-w-[380px] space-y-2 lg:order-1">
        <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-white/45">Aperçu</p>
        <PublicProfileCard role={role} data={form} fullName={user.full_name} />
      </div>

      {/* Formulaire */}
      <div className="mx-auto w-full max-w-[460px] space-y-5 lg:order-2">
        <div>
          <p className="text-sm font-semibold text-white">Ma fiche publique · {cfg.label}</p>
          <p className="text-xs text-white/60">Gérez votre profil comme sur un réseau social — visible par les autres participants.</p>
        </div>

        {/* Photos */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <span className={labelCls}>Photo de profil</span>
            <label className={uploadCls}>
              {uploading === "avatar" ? <Loader2 className="h-4 w-4 animate-spin" /> : <UserCircle className="h-4 w-4" />}
              {form.public_avatar_url ? "Changer" : "Ajouter"}
              <input type="file" accept="image/*" className="hidden" onChange={(e) => handleUpload("public_avatar_url", e.target.files?.[0])} />
            </label>
          </div>
          <div>
            <span className={labelCls}>Couverture</span>
            <label className={uploadCls}>
              {uploading === "cover" ? <Loader2 className="h-4 w-4 animate-spin" /> : <ImagePlus className="h-4 w-4" />}
              {form.public_cover_url ? "Changer" : "Ajouter"}
              <input type="file" accept="image/*" className="hidden" onChange={(e) => handleUpload("public_cover_url", e.target.files?.[0])} />
            </label>
          </div>
        </div>

        <GlassText label="Nom affiché" value={form.public_display_name} onChange={(v) => set("public_display_name", v)} placeholder={user.full_name || "Votre nom"} />
        <GlassText label="Accroche" value={form.public_headline} onChange={(v) => set("public_headline", v)} placeholder={cfg.headlinePlaceholder} />
        <GlassText label="Bio" value={form.public_bio} onChange={(v) => set("public_bio", v)} placeholder={cfg.bioPlaceholder} multiline />
        <div className="grid grid-cols-2 gap-3">
          <GlassText label="Localisation" value={form.public_location} onChange={(v) => set("public_location", v)} placeholder="Paris" />
          <GlassText label="Lien" value={form.public_link} onChange={(v) => set("public_link", v)} placeholder="https://…" />
        </div>

        <div className="flex items-center justify-between rounded-xl border border-white/20 bg-white/10 backdrop-blur px-4 py-3">
          <div>
            <p className="text-sm font-medium text-white">Profil visible</p>
            <p className="text-xs text-white/55">Affiché aux autres participants du mariage.</p>
          </div>
          <Switch checked={form.public_visible} onCheckedChange={(v) => set("public_visible", v)} />
        </div>

        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={handleSave}
            disabled={saving}
            className="inline-flex items-center gap-2 rounded-full bg-white px-5 py-2.5 text-sm font-medium text-foreground hover:bg-white/90 disabled:opacity-60"
          >
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            Enregistrer
          </button>
          {saved && <p className="text-sm text-white">Profil mis à jour.</p>}
        </div>
      </div>
    </div>
  );
}