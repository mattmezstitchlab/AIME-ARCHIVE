import { MapPin, LinkIcon, EyeOff } from "lucide-react";
import { getRoleProfile } from "./roleProfiles";

// Aperçu « comme on me voit » : carte profil façon réseau social, posée sur
// le visuel céleste. Couverture + avatar + nom + accroche + bio + infos.
export default function PublicProfileCard({ role, data, fullName }) {
  const cfg = getRoleProfile(role);
  const Icon = cfg.icon;
  const name = data.public_display_name || fullName || "Votre nom";
  const headline = data.public_headline || cfg.headlinePlaceholder;
  const initials = (name || "?").trim().slice(0, 1).toUpperCase();

  return (
    <div className="max-w-sm overflow-hidden rounded-2xl border border-white/15 bg-white/10 backdrop-blur-md shadow-2xl">
      {/* Couverture */}
      <div className="relative h-28 w-full">
        <div className={`absolute inset-0 bg-gradient-to-br ${cfg.accent}`} />
        {data.public_cover_url && (
          <img src={data.public_cover_url} alt="" className="absolute inset-0 h-full w-full object-cover" />
        )}
        {!data.public_visible && (
          <span className="absolute right-2 top-2 inline-flex items-center gap-1 rounded-full bg-black/60 px-2 py-0.5 text-[10px] font-medium text-white">
            <EyeOff className="h-3 w-3" aria-hidden="true" /> Masqué
          </span>
        )}
      </div>

      {/* Avatar chevauchant */}
      <div className="px-5 pb-5">
        <div className="-mt-9 mb-3 flex items-end justify-between">
          <div className="h-16 w-16 overflow-hidden rounded-full border-2 border-white/30 bg-white/20 backdrop-blur">
            {data.public_avatar_url ? (
              <img src={data.public_avatar_url} alt="" className="h-full w-full object-cover" />
            ) : (
              <div className="flex h-full w-full items-center justify-center font-heading text-xl font-semibold text-white">
                {initials}
              </div>
            )}
          </div>
          <span className="inline-flex items-center gap-1 rounded-full bg-white/15 px-2.5 py-1 text-[11px] font-medium text-white">
            <Icon className="h-3 w-3" aria-hidden="true" /> {cfg.label}
          </span>
        </div>

        <h3 className="font-heading text-lg font-semibold leading-tight text-white">{name}</h3>
        <p className="text-sm text-white/65">{headline}</p>

        {data.public_bio && (
          <p className="mt-3 text-sm leading-relaxed text-white/80">{data.public_bio}</p>
        )}

        <div className="mt-4 flex flex-wrap gap-x-4 gap-y-1.5 text-xs text-white/60">
          {data.public_location && (
            <span className="inline-flex items-center gap-1">
              <MapPin className="h-3 w-3" aria-hidden="true" /> {data.public_location}
            </span>
          )}
          {data.public_link && (
            <a href={data.public_link} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-white/75 underline underline-offset-2 hover:text-white">
              <LinkIcon className="h-3 w-3" aria-hidden="true" /> Mon lien
            </a>
          )}
        </div>
      </div>
    </div>
  );
}