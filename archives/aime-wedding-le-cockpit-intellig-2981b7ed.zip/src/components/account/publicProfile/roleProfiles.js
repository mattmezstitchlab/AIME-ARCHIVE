// Configuration du profil public par rôle, façon réseau social.
// Chaque rôle a sa couleur d'accent, son accroche par défaut et son intitulé.
import { Heart, Camera, Handshake, Users, PartyPopper, ClipboardList, Building2 } from "lucide-react";

export const ROLE_PROFILE = {
  couple: {
    label: "Marié·e",
    icon: Heart,
    headlinePlaceholder: "Les futurs mariés",
    bioPlaceholder: "Notre histoire, notre grand jour, ce qui nous fait vibrer…",
    accent: "from-rose-400/40 to-rose-600/30",
  },
  prestataire: {
    label: "Prestataire",
    icon: Camera,
    headlinePlaceholder: "Photographe de mariage",
    bioPlaceholder: "Présentez votre univers, votre approche, vos prestations…",
    accent: "from-amber-400/40 to-amber-600/30",
  },
  temoin: {
    label: "Témoin",
    icon: Handshake,
    headlinePlaceholder: "Témoin de la mariée",
    bioPlaceholder: "Quelques mots sur votre lien avec les mariés…",
    accent: "from-violet-400/40 to-violet-600/30",
  },
  famille: {
    label: "Famille",
    icon: Users,
    headlinePlaceholder: "Famille des mariés",
    bioPlaceholder: "Votre place dans la famille, un mot pour les mariés…",
    accent: "from-sky-400/40 to-sky-600/30",
  },
  invite: {
    label: "Invité·e",
    icon: PartyPopper,
    headlinePlaceholder: "Invité·e au mariage",
    bioPlaceholder: "Un mot sur votre lien avec les mariés, votre impatience…",
    accent: "from-emerald-400/40 to-emerald-600/30",
  },
  coordinateur: {
    label: "Coordinateur·rice",
    icon: ClipboardList,
    headlinePlaceholder: "Coordinateur·rice du mariage",
    bioPlaceholder: "Votre rôle, votre méthode, votre expérience…",
    accent: "from-indigo-400/40 to-indigo-600/30",
  },
  lieu: {
    label: "Lieu de réception",
    icon: Building2,
    headlinePlaceholder: "Domaine de réception",
    bioPlaceholder: "Présentez votre lieu, sa capacité, son ambiance…",
    accent: "from-teal-400/40 to-teal-600/30",
  },
};

export function getRoleProfile(role) {
  return ROLE_PROFILE[role] || ROLE_PROFILE.couple;
}