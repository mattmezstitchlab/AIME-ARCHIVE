import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Save, ExternalLink, Loader2, Store } from "lucide-react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { CATEGORY_LIST, CITY_LIST } from "@/lib/categories";

// Module d'édition de la fiche publique prestataire (entité Artist).
// Le prestataire remplit/modifie sa vitrine ; un lien partageable renvoie
// vers sa page publique /artiste/:id.
export default function ProviderProfileEditor({ user, onLinked }) {
  const [artist, setArtist] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [form, setForm] = useState({
    name: "", specialty: "", category: "", location: "",
    price_from: "", description: "", image_url: "",
  });

  useEffect(() => {
    if (!user?.linked_artist_id) { setLoading(false); return; }
    base44.entities.Artist.get(user.linked_artist_id)
      .then((a) => {
        setArtist(a);
        setForm({
          name: a.name || "",
          specialty: a.specialty || "",
          category: a.category || "",
          location: a.location || "",
          price_from: a.price_from ?? "",
          description: a.description || "",
          image_url: a.image_url || "",
        });
      })
      .catch(() => setArtist(null))
      .finally(() => setLoading(false));
  }, [user?.linked_artist_id]);

  const set = (k, v) => { setSaved(false); setForm((f) => ({ ...f, [k]: v })); };

  const handleSave = async () => {
    setSaving(true);
    setSaved(false);
    const payload = {
      name: form.name,
      specialty: form.specialty,
      category: form.category,
      location: form.location,
      price_from: form.price_from === "" ? undefined : Number(form.price_from),
      description: form.description,
      image_url: form.image_url,
      wedding_role: form.specialty,
      is_sample: false,
    };
    try {
      if (artist) {
        const updated = await base44.entities.Artist.update(artist.id, payload);
        setArtist(updated);
      } else {
        const created = await base44.entities.Artist.create({ ...payload, available: true });
        setArtist(created);
        await base44.auth.updateMe({ linked_artist_id: created.id });
        onLinked?.(created.id);
      }
      setSaved(true);
    } catch { /* noop */ }
    setSaving(false);
  };

  if (loading) {
    return <div className="flex items-center gap-2 text-sm text-muted-foreground"><Loader2 className="w-4 h-4 animate-spin" /> Chargement de votre fiche…</div>;
  }

  return (
    <div className="max-w-xl space-y-5">
      <div className="flex items-start gap-3 rounded-xl border border-border bg-muted/30 p-4">
        <Store className="w-5 h-5 text-foreground shrink-0 mt-0.5" aria-hidden="true" />
        <div className="flex-1">
          <p className="text-sm font-semibold text-foreground">Ma fiche publique prestataire</p>
          <p className="text-xs text-muted-foreground">Cette vitrine est visible par les couples qui recherchent un prestataire.</p>
        </div>
        {artist && (
          <Link to={`/artiste/${artist.id}`} target="_blank" className="shrink-0 inline-flex items-center gap-1 text-xs font-medium text-foreground underline underline-offset-4">
            Voir <ExternalLink className="w-3 h-3" aria-hidden="true" />
          </Link>
        )}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="p-name">Nom / Studio</Label>
          <Input id="p-name" value={form.name} onChange={(e) => set("name", e.target.value)} placeholder="Studio Lumière" />
        </div>
        <div>
          <Label htmlFor="p-cat">Métier</Label>
          <select
            id="p-cat"
            value={form.category}
            onChange={(e) => set("category", e.target.value)}
            className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            <option value="">Choisir…</option>
            {CATEGORY_LIST.map((c) => <option key={c.slug} value={c.name}>{c.title}</option>)}
          </select>
        </div>
        <div>
          <Label htmlFor="p-spec">Spécialité</Label>
          <Input id="p-spec" value={form.specialty} onChange={(e) => set("specialty", e.target.value)} placeholder="Photographe de mariage" />
        </div>
        <div>
          <Label htmlFor="p-loc">Ville</Label>
          <select
            id="p-loc"
            value={form.location}
            onChange={(e) => set("location", e.target.value)}
            className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            <option value="">Choisir…</option>
            {CITY_LIST.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
        <div>
          <Label htmlFor="p-price">Tarif à partir de (€)</Label>
          <Input id="p-price" type="number" value={form.price_from} onChange={(e) => set("price_from", e.target.value)} placeholder="900" />
        </div>
        <div>
          <Label htmlFor="p-img">Photo (URL)</Label>
          <Input id="p-img" value={form.image_url} onChange={(e) => set("image_url", e.target.value)} placeholder="https://…" />
        </div>
      </div>

      <div>
        <Label htmlFor="p-desc">À propos</Label>
        <Textarea id="p-desc" rows={4} value={form.description} onChange={(e) => set("description", e.target.value)} placeholder="Présentez votre univers, votre approche, vos prestations…" />
      </div>

      <div className="flex items-center gap-3">
        <Button onClick={handleSave} disabled={saving} className="bg-foreground text-background hover:bg-foreground/90 h-9 text-sm">
          {saving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
          {artist ? "Enregistrer" : "Créer ma fiche"}
        </Button>
        {saved && <p className="text-sm text-foreground">Fiche mise à jour.</p>}
      </div>
    </div>
  );
}