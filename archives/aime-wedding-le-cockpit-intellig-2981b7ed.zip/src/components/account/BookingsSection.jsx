import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Calendar, Clock, ChevronRight } from "lucide-react";
import { format, parseISO, isAfter } from "date-fns";
import { fr } from "date-fns/locale";
import { BOOKING_PAYMENT_STATUS_LABELS } from "@/lib/payment";

const statusLabel = {
  pending: { text: "En attente", cls: "bg-muted text-muted-foreground" },
  confirmed: { text: "Confirmé", cls: "bg-foreground text-background" },
  cancelled: { text: "Annulé", cls: "bg-destructive/10 text-destructive" },
  completed: { text: "Terminé", cls: "bg-muted text-foreground" },
};

export default function BookingsSection() {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState("upcoming");
  const [cancellingId, setCancellingId] = useState(null);

  useEffect(() => {
    base44.auth.me()
      .then((user) => base44.entities.Booking.filter({ created_by_id: user.id }, "-booking_date", 50))
      .then(setBookings)
      .catch(() => setBookings([]))
      .finally(() => setLoading(false));
  }, []);

  const cancelBooking = async (booking) => {
    setCancellingId(booking.id);
    try {
      await base44.entities.Booking.update(booking.id, { status: "cancelled" });
      setBookings((prev) => prev.map((b) => (b.id === booking.id ? { ...b, status: "cancelled" } : b)));
    } catch {
      // silencieux
    }
    setCancellingId(null);
  };

  const now = new Date();
  const upcoming = bookings.filter((b) => {
    const d = parseISO(b.booking_date + "T" + b.booking_time);
    return isAfter(d, now) && b.status !== "cancelled";
  });
  const past = bookings.filter((b) => {
    const d = parseISO(b.booking_date + "T" + b.booking_time);
    return !isAfter(d, now) || b.status === "completed";
  });
  const display = tab === "upcoming" ? upcoming : past;

  return (
    <div>
      <div className="flex gap-1 mb-8 border-b border-white/15">
        <button
          onClick={() => setTab("upcoming")}
          className={`px-4 py-3 text-sm font-medium border-b-2 transition-colors ${
            tab === "upcoming" ? "border-white text-white" : "border-transparent text-white/55 hover:text-white"
          }`}
        >
          À venir ({upcoming.length})
        </button>
        <button
          onClick={() => setTab("past")}
          className={`px-4 py-3 text-sm font-medium border-b-2 transition-colors ${
            tab === "past" ? "border-white text-white" : "border-transparent text-white/55 hover:text-white"
          }`}
        >
          Historique ({past.length})
        </button>
      </div>

      {loading ? (
        <div className="space-y-4">
          {[1, 2, 3].map((i) => <div key={i} className="h-24 rounded-lg bg-white/10 animate-pulse" />)}
        </div>
      ) : display.length === 0 ? (
        <div className="text-center py-20">
          <Calendar className="w-12 h-12 text-white/50 mx-auto mb-4" />
          <p className="text-white font-medium mb-2">Aucune réservation {tab === "upcoming" ? "à venir" : "passée"}</p>
          <p className="text-sm text-white/60 mb-6">Découvrez nos artistes et réservez votre premier rendez-vous.</p>
          <Link to="/">
            <Button className="bg-white text-foreground hover:bg-white/90">Découvrir les artistes</Button>
          </Link>
        </div>
      ) : (
        <div className="space-y-3">
          {display.map((booking) => (
            <div key={booking.id} className="border-b border-white/10 py-4 flex items-center justify-between hover:opacity-80 transition-opacity">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <Link to={`/artiste/${booking.artist_id}`} className="font-semibold text-white hover:underline underline-offset-4">
                    {booking.artist_name}
                  </Link>
                  <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${statusLabel[booking.status]?.cls || ""}`}>
                    {statusLabel[booking.status]?.text || booking.status}
                  </span>
                </div>
                <p className="text-sm text-white/60 mb-2">{booking.service}</p>
                <div className="flex items-center gap-4 text-xs text-white/55">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5" />
                    {format(parseISO(booking.booking_date), "d MMMM yyyy", { locale: fr })}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" />{booking.booking_time}
                  </span>
                </div>
                {booking.payment_status && (
                  <div className="flex items-center gap-2 mt-2 text-xs">
                    <span className="text-white/55">Paiement :</span>
                    <span className="font-medium text-white">
                      {BOOKING_PAYMENT_STATUS_LABELS[booking.payment_status] || "À vérifier"}
                    </span>
                  </div>
                )}
                {booking.payment_method === "cash_declared_on_site" && (
                  <p className="text-[11px] text-white/55 mt-1">Trace conservée dans Artistry.</p>
                )}
              </div>
              <div className="text-right">
                <p className="text-lg font-bold text-white">{booking.price}€</p>
                <Link to={`/artiste/${booking.artist_id}`} className="text-xs text-white/55 hover:text-white flex items-center gap-1 justify-end">
                  Détails <ChevronRight className="w-3 h-3" />
                </Link>
                {booking.status !== "cancelled" && booking.status !== "completed" && (
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <button className="text-xs text-white/55 hover:text-destructive mt-2 transition-colors">
                        Annuler
                      </button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Annuler cette réservation ?</AlertDialogTitle>
                        <AlertDialogDescription>
                          Votre rendez-vous avec {booking.artist_name} du{" "}
                          {format(parseISO(booking.booking_date), "d MMMM yyyy", { locale: fr })} à {booking.booking_time} sera annulé.
                          Cette action est définitive.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Retour</AlertDialogCancel>
                        <AlertDialogAction
                          onClick={() => cancelBooking(booking)}
                          disabled={cancellingId === booking.id}
                          className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                        >
                          {cancellingId === booking.id ? "Annulation..." : "Confirmer l'annulation"}
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}