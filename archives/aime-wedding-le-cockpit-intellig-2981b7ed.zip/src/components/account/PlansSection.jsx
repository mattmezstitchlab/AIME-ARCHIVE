import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { ArrowRight, CalendarHeart } from "lucide-react";
import PlanListCard from "@/components/guide/PlanListCard";
import { listPlans } from "@/lib/guide/plans";

export default function PlansSection() {
  const [plans, setPlans] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    listPlans()
      .then((rows) => setPlans(rows || []))
      .catch(() => setPlans([]))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <div className="mb-8">
        <h2 className="text-xl font-semibold text-white">Mon mariage</h2>
        <p className="text-sm text-white/60">Les modules vivent maintenant dans les pages Avant, Jour J et Après.</p>
        <div className="mt-4 grid gap-3 sm:grid-cols-3">
          {[
            { to: "/avant", label: "Avant" },
            { to: "/jour-j", label: "Jour J" },
            { to: "/apres", label: "Après" },
          ].map((item) => (
            <Link key={item.to} to={item.to} className="group flex items-center justify-between rounded-xl border border-white/20 bg-white/5 backdrop-blur px-4 py-3 text-sm font-medium text-white transition-colors hover:border-white/40">
              {item.label}
              <ArrowRight className="h-4 w-4 text-white/50 transition-transform group-hover:translate-x-0.5" aria-hidden="true" />
            </Link>
          ))}
        </div>
      </div>

      {loading ? (
        <div className="space-y-4">
          {[1, 2].map((i) => <div key={i} className="h-28 rounded-lg bg-white/10 animate-pulse" />)}
        </div>
      ) : plans.length === 0 ? (
        <div className="text-center py-20">
          <CalendarHeart className="w-12 h-12 text-white/50 mx-auto mb-4" aria-hidden="true" />
          <p className="text-white font-medium mb-2">Aucun mariage actif pour l'instant</p>
          <p className="text-sm text-white/60 mb-6 max-w-md mx-auto">
            Commencez depuis Avant, puis retrouvez chaque module directement dans sa page de phase.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {plans.map((plan) => <PlanListCard key={plan.id} plan={plan} />)}
        </div>
      )}
    </div>
  );
}