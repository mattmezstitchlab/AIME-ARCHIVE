import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Heart, MapPin, Trash2 } from "lucide-react";

export default function FavoritesSection() {
  const [favorites, setFavorites] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    base44.auth.me()
      .then((user) => base44.entities.Favorite.filter({ created_by_id: user.id }, "-created_date", 50))
      .then(setFavorites)
      .catch(() => setFavorites([]))
      .finally(() => setLoading(false));
  }, []);

  const removeFavorite = async (id) => {
    await base44.entities.Favorite.delete(id);
    setFavorites((prev) => prev.filter((f) => f.id !== id));
  };

  if (loading) {
    return <div className="space-y-3">{[1, 2, 3].map((i) => <div key={i} className="h-24 rounded-lg bg-white/10 animate-pulse" />)}</div>;
  }

  if (favorites.length === 0) {
    return (
      <div className="text-center py-20">
        <Heart className="w-12 h-12 text-white/50 mx-auto mb-4" />
        <p className="text-white font-medium mb-2">Aucun favori pour le moment</p>
        <p className="text-sm text-white/60 mb-6">Enregistrez vos artistes préférés pour les retrouver facilement.</p>
        <Link to="/categories"><Button className="bg-white text-foreground hover:bg-white/90">Découvrir les artistes</Button></Link>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {favorites.map((fav) => (
        <div key={fav.id} className="border-b border-white/10 py-4 flex items-center gap-4 hover:opacity-80 transition-opacity">
          <img src={fav.artist_image_url} alt={fav.artist_name} className="w-16 h-16 rounded-lg object-cover bg-white/10 shrink-0" />
          <div className="flex-1">
            <Link to={`/artiste/${fav.artist_id}`} className="font-semibold text-white hover:underline underline-offset-4">{fav.artist_name}</Link>
            <p className="text-sm text-white/60 flex items-center gap-1 mt-1">
              {fav.artist_specialty} <span className="flex items-center gap-1"><MapPin className="w-3 h-3" />{fav.artist_location}</span>
            </p>
          </div>
          <button onClick={() => removeFavorite(fav.id)} aria-label="Retirer des favoris" className="text-white/50 hover:text-destructive transition-colors p-2">
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      ))}
    </div>
  );
}