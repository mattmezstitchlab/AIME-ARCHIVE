import { useState, useRef, useEffect, useMemo } from "react";
import { Feather, Loader2, Send, Trash2 } from "lucide-react";
import { Sheet, SheetContent } from "@/components/ui/sheet";
import { usePlumeContext } from "@/components/plume/PlumeProvider";
import { getUniverseQuestions } from "@/data/plumeUniverseQuestions";

export default function PlumeDrawer() {
  const { open, setOpen, routeContext, universe, messages, pending, saving, analyze, confirm, cancel, clearMessages } = usePlumeContext();
  const [value, setValue] = useState("");
  const scrollRef = useRef(null);
  const universeSuggestions = useMemo(() => {
    if (!universe) return [];
    return getUniverseQuestions(universe.slug).slice(0, 3);
  }, [universe]);

  // Auto-scroll to bottom on new messages
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages.length]);

  const submit = (text) => {
    const clean = String(text || value).trim();
    if (!clean) return;
    setValue("");
    analyze(clean, { openDrawer: true });
  };

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetContent side="right" className="flex w-full flex-col border-l border-foreground/10 bg-foreground p-0 sm:max-w-[280px] [&>button]:hidden">
        {/* Header */}
        <div className="border-b border-background/10 px-3 py-2.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Feather className="h-3.5 w-3.5 shrink-0 text-background/70" aria-hidden="true" />
              <p className="text-xs font-semibold text-background">La Plume</p>
            </div>
            {messages.length > 0 && (
              <button
                type="button"
                onClick={clearMessages}
                className="rounded-full p-1 text-background/30 hover:text-background/60"
                aria-label="Effacer la conversation"
              >
                <Trash2 className="h-3 w-3" />
              </button>
            )}
          </div>
          {universe && (
            <p className="mt-1 text-[9px] text-background/40">Univers : {universe.name} · {universe.toneOfVoice}</p>
          )}
        </div>

        {/* Messages */}
        <div ref={scrollRef} className="flex-1 space-y-2 overflow-y-auto px-3 py-3 scrollbar-hide">
          {messages.length === 0 && (
            <div className="py-3 text-center">
              <p className="mb-1 text-xs font-medium text-background">{routeContext.title}</p>
              <p className="mx-auto mb-3 text-[10px] leading-relaxed text-background/50">{routeContext.subtitle}</p>
              <div className="flex flex-col gap-1 text-left">
                {(universeSuggestions.length > 0 ? universeSuggestions : routeContext.suggestions).map((s) => (
                  <button key={s} type="button" onClick={() => submit(s)} className="rounded-lg border border-background/15 px-2 py-1.5 text-[11px] leading-tight text-background transition-colors hover:bg-background/10">
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}

          {messages.map((m, i) => (
            <div key={i} className={m.role === "user" ? "flex justify-end" : "flex justify-start"}>
              <div className={`max-w-[92%] rounded-xl px-2.5 py-2 text-[11px] leading-relaxed ${
                m.role === "user"
                  ? "rounded-br-sm bg-background text-foreground"
                  : m.error
                    ? "rounded-bl-sm border border-red-400/30 text-red-300"
                    : "rounded-bl-sm border border-background/15 text-background"
              }`}>
                {m.content}
                {m.saving && (
                  <div className="mt-1.5 flex items-center gap-1 border-t border-background/10 pt-1.5">
                    <Loader2 className="h-2.5 w-2.5 animate-spin text-background/50" />
                    <span className="text-[10px] text-background/50">Enregistrement…</span>
                  </div>
                )}
                {m.done && !m.saving && (
                  <p className="mt-1 text-[10px] text-background/40">✓ Enregistré</p>
                )}
              </div>
            </div>
          ))}

          {pending && (
            <div className="rounded-xl border border-background/15 p-2.5">
              <p className="text-[10px] font-medium uppercase tracking-[0.18em] text-background/50">Classification</p>
              <p className="mt-1.5 text-[11px] text-background">{pending.intent.summary}</p>
              <div className="mt-2 flex flex-wrap gap-1.5">
                <button type="button" onClick={confirm} disabled={saving} className="inline-flex h-7 items-center gap-1.5 rounded-full bg-background px-3 text-[11px] text-foreground disabled:opacity-50">
                  {saving && <Loader2 className="h-3 w-3 animate-spin" aria-hidden="true" />} OK
                </button>
                <button type="button" onClick={cancel} className="inline-flex h-7 items-center rounded-full border border-background/20 px-3 text-[11px] text-background hover:bg-background/10">Non</button>
              </div>
            </div>
          )}
        </div>

        {/* Input */}
        <form onSubmit={(e) => { e.preventDefault(); submit(); }} className="border-t border-background/10 p-2">
          <div className="flex items-center gap-1.5 rounded-full border border-background/15 py-1 pl-3 pr-1">
            <label htmlFor="plume-drawer-input" className="sr-only">Parler à La Plume</label>
            <input
              id="plume-drawer-input"
              value={value}
              onChange={(e) => setValue(e.target.value)}
              placeholder={routeContext.placeholder || "Écrire…"}
              autoComplete="off"
              disabled={saving}
              className="min-w-0 flex-1 bg-transparent text-[11px] text-background outline-none placeholder:text-background/40 disabled:opacity-50"
            />
            <button type="submit" disabled={!value.trim() || saving} aria-label="Envoyer" className="inline-flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-background text-foreground disabled:opacity-40">
              <Send className="h-3 w-3" aria-hidden="true" />
            </button>
          </div>
        </form>
      </SheetContent>
    </Sheet>
  );
}