import { useState } from "react";
import { Feather, X } from "lucide-react";
import { Sheet, SheetContent } from "@/components/ui/sheet";
import PlumePanel from "./PlumePanel";

// Compagnon flottant La Plume — présent sur toutes les pages.
// Bouton fixe en bas à droite ; ouvre un panneau de conversation latéral.
export default function PlumeCompanion() {
  const [open, setOpen] = useState(false);

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        aria-label="Ouvrir La Plume, votre assistante de mariage"
        className="fixed bottom-5 right-5 z-50 inline-flex items-center gap-2 h-12 pl-4 pr-5 rounded-full bg-foreground text-background shadow-xl hover:bg-foreground/90 transition-colors"
      >
        {open ? <X className="w-5 h-5" aria-hidden="true" /> : <Feather className="w-5 h-5" aria-hidden="true" />}
        <span className="text-sm font-medium">La Plume</span>
      </button>

      <Sheet open={open} onOpenChange={setOpen}>
        <SheetContent side="right" className="p-0 w-full sm:max-w-md border-l border-border">
          <PlumePanel onClose={() => setOpen(false)} />
        </SheetContent>
      </Sheet>
    </>
  );
}