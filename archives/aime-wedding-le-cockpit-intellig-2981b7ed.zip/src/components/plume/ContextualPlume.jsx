import PlumeContextBar from "@/components/plume/PlumeContextBar";
import { PLUME_ROUTE_CONTEXTS } from "@/lib/plume/router";

const MAP = {
  day: PLUME_ROUTE_CONTEXTS.day,
  program: PLUME_ROUTE_CONTEXTS.day,
  music: PLUME_ROUTE_CONTEXTS.music,
  rsvp: PLUME_ROUTE_CONTEXTS.rsvp,
  lodging: PLUME_ROUTE_CONTEXTS.logistics,
  contacts: PLUME_ROUTE_CONTEXTS.contacts,
  emergency: PLUME_ROUTE_CONTEXTS.emergency,
  memory: PLUME_ROUTE_CONTEXTS.memory,
  creative: PLUME_ROUTE_CONTEXTS.memory,
  video: PLUME_ROUTE_CONTEXTS.memory,
  thanks: PLUME_ROUTE_CONTEXTS.after,
  capsule: PLUME_ROUTE_CONTEXTS.after,
};

export default function ContextualPlume({ pageType = "day" }) {
  return <PlumeContextBar context={MAP[pageType] || PLUME_ROUTE_CONTEXTS.day} />;
}