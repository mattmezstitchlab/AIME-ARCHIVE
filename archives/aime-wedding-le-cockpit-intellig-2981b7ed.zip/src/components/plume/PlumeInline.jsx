import { useState } from "react";
import { Feather, Loader2, Send } from "lucide-react";
import { usePlumeContext } from "@/components/plume/PlumeProvider";

export default function PlumeInline() {
  const { open, setOpen, routeContext, messages, pending, saving, analyze, confirm, cancel } = usePlumeContext();
  const [value, setValue] = useState("");

  const submit = (text) => {
    const clean = String(text || value).trim();
    if (!clean) return;
    setValue("");
    analyze(clean, { openDrawer: true });
  };

  if (!open) return null;

  return (
    <div className="fixed bottom-20 right-5 z-50 flex w-72 flex-col gap-2">
      {/* Conversation box */}
      <div className="max-h-80 overflow-y-auto rounded-2xl bg-foreground p-3 shadow-xl scrollbar-hide">
        {messages.length === 0 && !pending && (
          <div className="space-y-1.5">
            <div className="flex items-center gap-1.5 pb-1">
              <Feather className="h-3 w-3 text-background/60" aria-hidden="true" />
              <p className="text-[11px] font-semibold text-background">La Plume</p>
            </div>
            <p className="text-[10px] leading-relaxed text-background/50">{routeContext.subtitle}</p>
            <div className="flex flex-wrap gap-1 pt-1">
              {routeContext.suggestions.map((s) => (
                <button key={s} type="button" onClick={() => submit(s)} className="rounded-full border border-background/15 px-2 py-1 text-[10px] leading-tight text-background transition-colors hover:bg-background/10">
                  {s.length > 35 ? s.slice(0, 35) + "…" : s}
                </button>
              ))}
            </div>
          </div>
        )}

        {messages.length > 0 && (
          <div className="space-y-2">
            {messages.map((m, i) => (
              <div key={i} className={m.role === "user" ? "flex justify-end" : "flex justify-start"}>
                <div className={`max-w-[90%] rounded-xl px-2.5 py-1.5 text-[11px] leading-relaxed ${m.role === "user" ? "rounded-br-sm bg-background text-foreground" : "rounded-bl-sm border border-background/15 text-background"}`}>
                  {m.content}
                  {m.done && <p className="mt-1 border-t border-background/15 pt-1 text-[9px] font-medium text-background/60">Enregistré.</p>}
                </div>
              </div>
            ))}
          </div>
        )}

        {pending && (
          <div className="mt-2 rounded-xl border border-background/15 p-2">
            <p className="text-[10px] font-medium uppercase tracking-[0.18em] text-background/50">Classification</p>
            <p className="mt-1 text-[11px] text-background">{pending.intent.summary}</p>
            <div className="mt-1.5 flex gap-1.5">
              <button type="button" onClick={confirm} disabled={saving} className="inline-flex h-6 items-center gap-1 rounded-full bg-background px-2.5 text-[10px] text-foreground disabled:opacity-50">
                {saving && <Loader2 className="h-2.5 w-2.5 animate-spin" aria-hidden="true" />} OK
              </button>
              <button type="button" onClick={cancel} className="inline-flex h-6 items-center rounded-full border border-background/20 px-2.5 text-[10px] text-background hover:bg-background/10">Non</button>
            </div>
          </div>
        )}
      </div>

      {/* Input bar */}
      <form onSubmit={(e) => { e.preventDefault(); submit(); }}>
        <div className="flex items-center gap-1.5 rounded-2xl bg-foreground py-1.5 pl-3.5 pr-1.5 shadow-xl">
          <Feather className="h-3 w-3 shrink-0 text-background/50" aria-hidden="true" />
          <label htmlFor="plume-inline-input" className="sr-only">Parler à La Plume</label>
          <input id="plume-inline-input" value={value} onChange={(e) => setValue(e.target.value)} placeholder="Écrire…" autoComplete="off" className="min-w-0 flex-1 bg-transparent text-[11px] text-background outline-none placeholder:text-background/40" />
          <button type="submit" disabled={!value.trim()} aria-label="Envoyer" className="inline-flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-background text-foreground disabled:opacity-40">
            <Send className="h-3 w-3" aria-hidden="true" />
          </button>
        </div>
      </form>
    </div>
  );
}