import { createContext, useContext, useMemo, useState, useCallback, useRef } from "react";
import { useLocation } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { parsePlume } from "@/lib/plume/parser";
import { plumeContextForPath } from "@/lib/plume/router";
import { useWedding } from "@/lib/wedding/useWedding";
import { getUniverseBySlug } from "@/data/timelineUniverses";
import { getUniverseQuestions } from "@/data/plumeUniverseQuestions";
import { toast } from "@/components/ui/use-toast";

const PlumeContext = createContext(null);

const FOLLOW_UPS = {
  guests: ["Invité ajouté. Un autre à ajouter ?", "Bien reçu. Dictez-moi les suivants."],
  must_play: ["Ajouté à la playlist. Un autre titre ?", "C'est noté ! Continuez."],
  do_not_play: ["Blacklisté. D'autres titres à éviter ?"],
  timeline: ["Moment ajouté au conducteur. Un autre ?", "C'est noté dans le programme."],
  useful_contacts: ["Contact enregistré. Un autre ?"],
  checklist_items: ["Ajouté aux plans B. Autre chose ?"],
  lodging: ["Info hébergement enregistrée."],
  carpooling: ["Covoiturage noté."],
};

const UNIVERSE_TONE_PREFIXES = {
  "boheme-solaire": "☀️ ",
  "rock-n-roll": "🎸 ",
  "chic-essentiel": "",
  "lune-blanche": "🌙 ",
  "festival-amour": "🎪 ",
  "mariage-musical": "🎵 ",
  "city-wedding": "🏙️ ",
  "sans-prise-de-tete": "👌 ",
};

function buildFollowUp(intent, context, universe) {
  const pool = FOLLOW_UPS[intent.type] || ["C'est enregistré. Quoi d'autre ?"];
  let msg = pool[Math.floor(Math.random() * pool.length)];

  // Add universe-specific flavor
  if (universe) {
    const prefix = UNIVERSE_TONE_PREFIXES[universe.slug] || "";
    const questions = getUniverseQuestions(universe.slug);
    if (questions.length > 0 && Math.random() > 0.5) {
      const q = questions[Math.floor(Math.random() * questions.length)];
      msg = `${prefix}${msg}\n\n💡 ${q}`;
    } else if (prefix) {
      msg = prefix + msg;
    }
  }
  return msg;
}

export function PlumeProvider({ children }) {
  const { pathname } = useLocation();
  const routeContext = useMemo(() => plumeContextForPath(pathname), [pathname]);
  const { wedding, patch } = useWedding();
  const universe = useMemo(() => getUniverseBySlug(wedding?.timeline_universe_slug), [wedding?.timeline_universe_slug]);
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([]);
  const [pending, setPending] = useState(null);
  const [saving, setSaving] = useState(false);
  const conversationRef = useRef(null);

  // Persist a message pair to GuideConversation / GuideMessage (fire-and-forget)
  const persistMessage = useCallback(async (userText, plumeText, actionType, confirmed) => {
    try {
      const user = await base44.auth.me().catch(() => null);
      if (!user) return;
      // Reuse or create conversation for this session
      if (!conversationRef.current) {
        conversationRef.current = await base44.entities.GuideConversation.create({
          intent_text: userText.slice(0, 100),
          detected_domain: routeContext?.pageType === "day" ? "jour_j" : routeContext?.pageType === "rsvp" ? "avant" : "mariage",
          source_route: pathname,
          guide_plan_id: wedding?.id || "",
          status: "open",
        });
      }
      const convId = conversationRef.current.id;
      // Save user message
      await base44.entities.GuideMessage.create({ conversation_id: convId, role: "user", content: userText, domain: routeContext?.pageType || "" });
      // Save plume response
      if (plumeText) {
        await base44.entities.GuideMessage.create({ conversation_id: convId, role: "plume", content: plumeText, action_type: actionType || "", action_confirmed: !!confirmed });
      }
    } catch {
      // persistence is best-effort
    }
  }, [pathname, wedding?.id, routeContext]);

  const analyze = async (value, options = {}) => {
    const text = String(value || "").trim();
    if (!text) return null;
    const context = options.context || routeContext;
    const intent = parsePlume(text, context.pageType);

    // Always open the drawer so the user sees the conversation
    setOpen(true);

    if (!intent) {
      const msg = { role: "plume", content: "Je n'ai pas encore compris où ranger cette information. Pouvez-vous préciser ?" };
      setMessages((prev) => [...prev, { role: "user", content: text }, msg]);
      setPending(null);
      return msg;
    }

    if (intent.needsQuestion) {
      const msg = { role: "plume", content: intent.question };
      setMessages((prev) => [...prev, { role: "user", content: text }, msg]);
      setPending(null);
      return msg;
    }

    // Auto-confirm: apply immediately, then follow up
    setMessages((prev) => [
      ...prev,
      { role: "user", content: text },
      { role: "plume", content: intent.summary, saving: true },
    ]);

    setSaving(true);
    try {
      await patch(intent.build(wedding || {}));
      setMessages((prev) => {
        const updated = prev.map((m) =>
          m.saving ? { ...m, saving: false, done: true } : m
        );
        // Follow-up message from La Plume
        const followUp = buildFollowUp(intent, context, universe);
        return [...updated, { role: "plume", content: followUp }];
      });
      // Persist conversation history
      persistMessage(text, intent.summary, intent.type, true);
    } catch {
      setMessages((prev) =>
        prev.map((m) =>
          m.saving ? { ...m, saving: false, error: true, content: "Erreur lors de l'enregistrement. Réessayez." } : m
        )
      );
    } finally {
      setSaving(false);
    }
    setPending(null);
    return { intent };
  };

  const confirm = async () => {
    if (!pending?.intent || saving) return;
    setSaving(true);
    try {
      await patch(pending.intent.build(wedding || {}));
      setMessages((prev) => prev.map((m) => (m.proposalId === pending.id ? { ...m, done: true } : m)));
      // confirmation visible in drawer
      setPending(null);
    } finally {
      setSaving(false);
    }
  };

  const cancel = () => setPending(null);

  const clearMessages = () => {
    setMessages([]);
    // Archive current conversation and start fresh
    if (conversationRef.current) {
      base44.entities.GuideConversation.update(conversationRef.current.id, { status: "archived" }).catch(() => {});
      conversationRef.current = null;
    }
  };

  return (
    <PlumeContext.Provider value={{ open, setOpen, openPlume: () => setOpen(true), closePlume: () => setOpen(false), routeContext, universe, messages, pending, saving, analyze, confirm, cancel, clearMessages }}>
      {children}
    </PlumeContext.Provider>
  );
}

export function usePlumeContext() {
  const ctx = useContext(PlumeContext);
  if (!ctx) throw new Error("usePlumeContext must be used inside PlumeProvider");
  return ctx;
}