import { useNavigate, useLocation } from "react-router-dom";
import JourneyPlumeBar from "@/components/home/JourneyPlumeBar";
import { plumeContextForPath } from "@/lib/plume/router";

// Barre La Plume globale, présente sur tout le site SAUF l'accueil immersif
// (où c'est JourneyImmersive qui monte sa propre barre synchronisée au scroll).
// Hors parcours, La Plume reste pleinement active : elle range les infos dans
// le dossier et navigue vers la bonne page quand elle cible une route.
export default function GlobalPlumeBar() {
  const navigate = useNavigate();
  const { pathname } = useLocation();
  const routeContext = plumeContextForPath(pathname);

  // Sur l'accueil, JourneyImmersive gère la barre lui-même.
  if (pathname === "/") return null;

  const handleFocusRoute = (route, query) => {
    if (!route) return;
    const url = query ? `${route}?q=${encodeURIComponent(query)}` : route;
    navigate(url);
  };

  const pageTitle = routeContext?.title || "Cette page";

  return (
    <JourneyPlumeBar
      activeStep={{ title: pageTitle, phase: routeContext?.key || "avant", links: [] }}
      activeSlide={{ kind: "detail", title: pageTitle, to: pathname }}
      onFocusRoute={handleFocusRoute}
    />
  );
}