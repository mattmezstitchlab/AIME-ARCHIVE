import { useState, useRef, useEffect } from "react";
import { Link } from "react-router-dom";
import { Feather, Send, Loader2, X, ListChecks, ArrowUpRight } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useJourJPlan } from "@/lib/wedding/useJourJPlan";

// Quelques amorces pour montrer ce que La Plume sait ranger.
const SUGGESTIONS = [
  "On se marie le 12 septembre 2026 à Lyon",
  "Budget autour de 25 000 €, 120 invités",
  "On cherche un photographe et un DJ",
];

// Détermine vers quelle page renvoyer selon ce que La Plume vient de ranger,
// pour que la page serve de preuve / de notes éditables à la main.
function destinationForUpdates(updates) {
  if (!updates) return null;
  if (updates.team_add?.length) return { label: "Voir l'équipe", to: "/mon-compte?tab=plans" };
  if (updates.timeline_add?.length) return { label: "Voir le déroulé", to: "/jour-j" };
  if (updates.palette_add?.length) return { label: "Voir les couleurs", to: "/mon-compte?tab=plans" };
  if (updates.budget_max) return { label: "Voir le budget", to: "/mon-compte?tab=plans" };
  if (updates.city || updates.event_date || updates.guests_count) return { label: "Voir le dossier", to: "/mon-compte?tab=plans" };
  return null;
}

// Panneau de conversation flottant de La Plume — disponible sur tout le site.
// Elle discute, pose les questions, et range les infos dans le dossier mariage.
export default function PlumePanel({ onClose }) {
  const { plan, applyUpdates } = useJourJPlan();
  const [intent, setIntent] = useState("");
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);
  const threadRef = useRef(null);

  useEffect(() => {
    threadRef.current?.scrollTo({ top: threadRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, loading]);

  const submit = async (value) => {
    const text = String(value || "").trim();
    if (!text || loading) return;
    setIntent("");
    setMessages((prev) => [...prev, { role: "user", content: text }]);
    setLoading(true);
    try {
      const planContext = {
        city: plan?.city,
        event_date: plan?.event_date,
        budget_max: plan?.budget_max,
        services: (plan?.linked_services || []).map((s) => s.label),
      };
      const history = messages.map((m) => ({ role: m.role === "user" ? "user" : "plume", content: m.content }));
      const { data } = await base44.functions.invoke("jourjGuide", { message: text, history, plan_context: planContext });
      let saved = "";
      let destination = null;
      if (data.updates && Object.keys(data.updates).length) {
        await applyUpdates(data.updates);
        saved = data.saved_summary || "";
        destination = destinationForUpdates(data.updates);
      }
      setMessages((prev) => [...prev, { role: "plume", content: data.reply, saved, destination }]);
    } catch {
      setMessages((prev) => [...prev, { role: "plume", content: "Je n'ai pas pu répondre à l'instant. Pouvez-vous reformuler ?" }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-background">
      {/* En-tête */}
      <div className="flex items-center gap-3 px-4 py-3.5 border-b border-border shrink-0">
        <span className="inline-flex items-center justify-center w-9 h-9 rounded-full bg-foreground text-background">
          <Feather className="w-4 h-4" aria-hidden="true" />
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-sm font-semibold text-foreground leading-tight">La Plume</p>
          <p className="text-[11px] text-muted-foreground leading-tight">Votre assistante de mariage</p>
        </div>
        <button onClick={onClose} aria-label="Fermer La Plume" className="text-muted-foreground hover:text-foreground transition-colors">
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Fil de conversation */}
      <div ref={threadRef} className="flex-1 overflow-y-auto px-4 py-4 space-y-3 scrollbar-hide">
        {messages.length === 0 && !loading && (
          <div className="text-center py-6">
            <Feather className="w-6 h-6 text-muted-foreground mx-auto mb-3" aria-hidden="true" />
            <p className="text-sm text-foreground font-medium mb-1">Dites-moi tout sur votre mariage</p>
            <p className="text-xs text-muted-foreground leading-relaxed mb-4">
              Je pose les questions, on en discute, et je range chaque détail au bon endroit dans votre dossier.
            </p>
            <div className="flex flex-col gap-1.5">
              {SUGGESTIONS.map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => submit(s)}
                  className="text-left text-[13px] rounded-xl border border-border bg-muted/50 hover:bg-muted px-3 py-2 transition-colors"
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}

        {messages.map((m, i) => (
          <div key={i} className={m.role === "user" ? "flex justify-end" : "flex justify-start"}>
            <div className={`max-w-[88%] rounded-2xl px-3.5 py-2.5 text-sm leading-relaxed ${
              m.role === "user" ? "bg-foreground text-background rounded-br-sm" : "bg-muted text-foreground rounded-bl-sm border border-border"
            }`}>
              {m.content}
              {m.saved && (
                <p className="mt-2 pt-2 border-t border-border text-[11px] text-foreground/70 flex items-start gap-1.5">
                  <ListChecks className="w-3.5 h-3.5 mt-0.5 shrink-0" aria-hidden="true" />
                  Rangé dans votre dossier : {m.saved}
                </p>
              )}
              {m.destination && (
                <Link
                  to={m.destination.to}
                  onClick={onClose}
                  className="mt-2 inline-flex items-center gap-1 text-[12px] font-medium underline underline-offset-2 hover:opacity-70"
                >
                  {m.destination.label} <ArrowUpRight className="w-3.5 h-3.5" aria-hidden="true" />
                </Link>
              )}
            </div>
          </div>
        ))}

        {loading && (
          <div className="flex justify-start">
            <div className="bg-muted border border-border rounded-2xl rounded-bl-sm px-3.5 py-2.5 text-sm text-muted-foreground flex items-center gap-2">
              <Loader2 className="w-4 h-4 animate-spin" aria-hidden="true" /> La Plume écrit…
            </div>
          </div>
        )}
      </div>

      {/* Champ de saisie */}
      <form onSubmit={(e) => { e.preventDefault(); submit(intent); }} className="p-3 border-t border-border shrink-0">
        <div className="flex items-center gap-2 bg-muted border border-border rounded-full pl-4 pr-1.5 py-1.5">
          <label htmlFor="plume-global-input" className="sr-only">Parler à La Plume</label>
          <input
            id="plume-global-input"
            value={intent}
            onChange={(e) => setIntent(e.target.value)}
            placeholder={messages.length ? "Continuer avec La Plume…" : "Écrivez à La Plume…"}
            autoComplete="off"
            className="flex-1 bg-transparent outline-none text-sm text-foreground placeholder:text-muted-foreground min-w-0"
          />
          <button type="submit" disabled={loading || !intent.trim()} aria-label="Envoyer" className="shrink-0 inline-flex items-center justify-center w-9 h-9 rounded-full bg-foreground text-background hover:bg-foreground/90 disabled:opacity-40">
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
          </button>
        </div>
      </form>
    </div>
  );
}