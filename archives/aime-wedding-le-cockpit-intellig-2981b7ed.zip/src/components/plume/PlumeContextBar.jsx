import { useState } from "react";
import { Feather, Loader2, Send } from "lucide-react";
import { usePlumeContext } from "@/components/plume/PlumeProvider";

export default function PlumeContextBar({ context, title, subtitle, placeholder }) {
  const plume = usePlumeContext();
  const ctx = context || plume.routeContext;
  const [value, setValue] = useState("");
  const Icon = ctx.icon;

  const submit = (text) => {
    const clean = String(text || value).trim();
    if (!clean) return;
    setValue("");
    plume.analyze(clean, { context: ctx });
  };

  return (
    <section className="relative bg-background">
      <div className="mx-auto max-w-7xl px-6 py-6">
        <div className="rounded-3xl border border-border bg-paper p-4 shadow-sm sm:p-5">
          <div className="grid gap-4 lg:grid-cols-[0.8fr_1.2fr] lg:items-center">
            <div className="flex gap-3">
              <span className="mt-0.5 inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-foreground text-background">
                <Feather className="h-4 w-4" aria-hidden="true" />
              </span>
              <div className="min-w-0">
                <p className="flex items-center gap-2 text-sm font-semibold text-foreground">
                  {title || ctx.title} <Icon className="h-4 w-4 text-foreground/35" aria-hidden="true" />
                </p>
                <p className="mt-1 max-w-xl text-sm leading-relaxed text-muted-foreground">{subtitle || ctx.subtitle}</p>
              </div>
            </div>
            <div>
              <form onSubmit={(e) => { e.preventDefault(); submit(); }}>
                <div className="flex items-center gap-2 rounded-full border border-border bg-background py-1.5 pl-4 pr-1.5">
                  <label htmlFor={`plume-bar-${ctx.key}`} className="sr-only">Parler à La Plume</label>
                  <input id={`plume-bar-${ctx.key}`} value={value} onChange={(e) => setValue(e.target.value)} placeholder={placeholder || ctx.placeholder} autoComplete="off" className="min-w-0 flex-1 bg-transparent text-sm text-foreground outline-none placeholder:text-muted-foreground" />
                  <button type="submit" disabled={!value.trim()} aria-label="Envoyer" className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-foreground text-background disabled:opacity-40">
                    <Send className="h-4 w-4" aria-hidden="true" />
                  </button>
                </div>
              </form>
              <div className="mt-2 flex flex-wrap gap-1.5">
                {ctx.suggestions.slice(0, 6).map((s) => (
                  <button key={s} type="button" onClick={() => submit(s)} className="rounded-full border border-border bg-background px-3 py-1.5 text-xs text-muted-foreground transition-colors hover:border-foreground/30 hover:text-foreground">
                    {s}
                  </button>
                ))}
              </div>
            </div>
          </div>
          {plume.pending && plume.pending.context.key === ctx.key && (
            <div className="mt-4 rounded-2xl border border-border bg-background p-3">
              <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">Classification proposée</p>
              <p className="mt-2 text-sm text-foreground">{plume.pending.intent.summary}</p>
              <div className="mt-3 flex flex-wrap gap-2">
                <button type="button" onClick={plume.confirm} disabled={plume.saving} className="inline-flex h-9 items-center gap-2 rounded-full bg-foreground px-4 text-sm text-background disabled:opacity-50">
                  {plume.saving && <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />} Confirmer
                </button>
                <button type="button" onClick={plume.openPlume} className="inline-flex h-9 items-center rounded-full border border-border px-4 text-sm text-foreground hover:bg-muted">Modifier</button>
                <button type="button" onClick={plume.cancel} className="inline-flex h-9 items-center rounded-full px-4 text-sm text-muted-foreground hover:text-foreground">Annuler</button>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}