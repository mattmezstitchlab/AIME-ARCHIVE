import { Link } from "react-router-dom";
import { Search, CalendarHeart, Palette, ArrowRight } from "lucide-react";

// Section Home : présente les deux mondes (chercher / organiser / artiste).
const PATHS = [
  {
    to: "/recherche",
    icon: Search,
    title: "Je cherche un artiste",
    desc: "Parcourez les profils par métier et par ville, comparez avis et disponibilités.",
    cta: "Explorer les artistes",
  },
  {
    to: "/organisateur",
    icon: CalendarHeart,
    title: "J'organise une mission",
    desc: "Mariage, anniversaire, association, entreprise, mairie, salle ou festival.",
    cta: "Préparer ma mission",
  },
  {
    to: "/pro",
    icon: Palette,
    title: "Je suis artiste",
    desc: "Publiez votre profil, recevez des réservations et préparez chaque mission.",
    cta: "Espace artiste",
  },
];

export default function TwoWorldsSection() {
  return (
    <section className="py-24 bg-background">
      <div className="max-w-6xl mx-auto px-6">
        <div className="mb-12 max-w-2xl">
          <h2 className="text-3xl sm:text-4xl font-light text-foreground tracking-tight mb-3">
            Deux façons d'utiliser Artistry
          </h2>
          <p className="text-muted-foreground">
            Que vous cherchiez, organisiez ou créiez : le cadre est prêt.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {PATHS.map((p) => (
            <Link
              key={p.to}
              to={p.to}
              className="group rounded-xl border border-border p-6 hover:shadow-lg transition-shadow flex flex-col"
            >
              <div className="w-11 h-11 rounded-full bg-foreground text-background flex items-center justify-center mb-4">
                <p.icon className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">{p.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed mb-4 flex-1">{p.desc}</p>
              <span className="text-sm font-medium text-foreground flex items-center gap-1 group-hover:gap-2 transition-all">
                {p.cta} <ArrowRight className="w-4 h-4" />
              </span>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}