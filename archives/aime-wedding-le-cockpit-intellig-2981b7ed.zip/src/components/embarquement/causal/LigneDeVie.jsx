import { useState } from "react";
import { JALONS, TEMPS } from "@/lib/onboarding/causalOnboarding";

// LA LIGNE DE VIE — trois temps commutables (j'étais, je suis, je serai),
// une seule ligne : on pose des jalons, on clique pour retirer.
export default function LigneDeVie({ jalons, onChange }) {
  const [temps, setTemps] = useState("avant");
  const actifs = jalons[temps] || [];
  const t = TEMPS.find((x) => x.id === temps);

  const ajouter = (n, c) => onChange({ ...jalons, [temps]: [...actifs, { n, c }] });
  const retirer = (i) => onChange({ ...jalons, [temps]: actifs.filter((_, j) => j !== i) });

  return (
    <div>
      <div className="mb-6 flex justify-center gap-2">
        {TEMPS.map((x) => (
          <button
            key={x.id}
            type="button"
            onClick={() => setTemps(x.id)}
            aria-pressed={temps === x.id}
            className={`rounded-full border px-5 py-2 text-[13px] transition ${
              temps === x.id ? "border-white bg-white font-semibold text-black" : "border-white/10 text-white/55 hover:text-white"
            }`}
          >
            {x.label}
            {(jalons[x.id]?.length || 0) > 0 && <span className="ml-1.5 font-mono text-[10px] opacity-60">{jalons[x.id].length}</span>}
          </button>
        ))}
      </div>

      {/* LA LIGNE — les jalons posés dessus, cliquer = retirer. */}
      <div className="relative mx-2 mb-6 h-[110px] border-b border-white/10">
        {actifs.length === 0 && (
          <p className="absolute inset-0 flex items-center justify-center text-[13px] italic text-white/30">
            La ligne attend son premier jalon — {t.vide}.
          </p>
        )}
        {actifs.map((j, i) => (
          <button
            key={i}
            type="button"
            onClick={() => retirer(i)}
            title="Cliquer pour retirer"
            className="ripple-wave absolute bottom-[-5px] flex -translate-x-1/2 flex-col items-center gap-2"
            style={{ left: `${8 + i * (84 / Math.max(5, actifs.length))}%` }}
          >
            <span className="max-w-[9ch] truncate text-[11.5px] text-white/60">{j.n}</span>
            <i className="h-[9px] w-[9px] rounded-full" style={{ background: j.c }} />
          </button>
        ))}
      </div>

      <div className="flex flex-wrap justify-center gap-2">
        {JALONS[temps].map(([n, c]) => (
          <button
            key={n}
            type="button"
            onClick={() => ajouter(n, c)}
            className="rounded-full border border-white/10 px-4 py-2 text-[13px] text-white/55 transition hover:border-white/30 hover:text-white"
          >
            + {n}
          </button>
        ))}
      </div>
    </div>
  );
}