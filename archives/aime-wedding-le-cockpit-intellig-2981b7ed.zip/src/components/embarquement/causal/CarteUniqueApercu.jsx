import { RELATIONS, ACCENTS, STATUTS, nomRole, essenceDe, suggestions } from "@/lib/onboarding/causalOnboarding";

// L'APERÇU EN DIRECT — la Carte Unique se construit sous les yeux :
// relation, nom, essence auto, chips de rôles, jalons, points du Registre.
export default function CarteUniqueApercu({ relations, roles, name, jalons, publie }) {
  const relTxt = relations.map((id) => RELATIONS.find((r) => r.id === id)?.gt).filter(Boolean).join(" · ") || "—";
  const principal = roles.find((r) => ACCENTS[r]) || roles[0];
  const accent = ACCENTS[principal] || "#C9A96E";
  const statut = roles.includes("intermittent") ? "intermittent·e" : roles.includes("independant") ? "indépendant·e" : "";
  const chips = roles.filter((r) => !STATUTS.includes(r)).slice(0, 4);
  const totalJ = jalons.avant.length + jalons.maintenant.length + jalons.apres.length;
  const pts = suggestions(roles).points.get("moi");

  return (
    <div>
      <p className="mb-2.5 text-center font-mono text-[9px] font-semibold uppercase tracking-[0.3em] text-white/35">
        Votre Carte Unique · en direct
      </p>
      <div
        className={`relative flex min-h-[380px] flex-col overflow-hidden rounded-2xl border bg-gradient-to-br from-[#17171A] to-[#0D0D0F] px-5 py-6 transition-shadow duration-500 ${
          publie ? "border-[#C9A96E] shadow-[0_24px_70px_-24px_#C9A96E]" : "border-white/10"
        }`}
      >
        <span
          className="absolute -right-16 -top-16 h-48 w-48 rounded-full transition-all duration-500"
          style={{ background: `radial-gradient(circle, ${accent}44, transparent 70%)` }}
          aria-hidden="true"
        />
        {publie && (
          <span className="carte-onde-pub absolute left-1/2 top-1/2 h-5 w-5 rounded-full border border-[#C9A96E]" aria-hidden="true" />
        )}
        <p className="relative font-mono text-[9px] font-semibold uppercase tracking-[0.3em] text-white/40">{relTxt}</p>
        <p className="relative mt-10 min-h-[1.2em] font-heading text-[26px] font-extrabold tracking-[-0.02em] text-white">
          {name.trim() || "Votre nom"}
        </p>
        <p className="relative mt-2 min-h-[2.8em] text-[13px] italic leading-relaxed text-white/50">{essenceDe(roles)}</p>
        <div className="relative mt-3.5 flex flex-wrap gap-1.5">
          {chips.map((r) => (
            <span key={r} className="rounded-full border border-white/10 px-2.5 py-1 text-[11px] text-white/50">
              {nomRole(r)}
            </span>
          ))}
          {statut && (
            <span className="rounded-full border border-dashed border-[#8F7E55] px-2.5 py-1 text-[11px] text-[#C9A96E]">{statut}</span>
          )}
        </div>
        <div className="relative mt-auto flex items-center justify-between border-t border-white/[0.06] pt-4">
          <span className="font-mono text-[9px] font-semibold uppercase tracking-[0.3em] text-white/35">
            {totalJ} jalon{totalJ > 1 ? "s" : ""}
          </span>
          <span className="flex gap-1">
            {pts?.c.map((c, i) => (
              <i key={i} className="h-[7px] w-[7px] rounded-full" style={{ background: c }} />
            ))}
          </span>
        </div>
      </div>
    </div>
  );
}