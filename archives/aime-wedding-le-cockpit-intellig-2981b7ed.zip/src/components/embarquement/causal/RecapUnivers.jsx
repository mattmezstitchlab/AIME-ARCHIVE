import { nomRole, modulesDe } from "@/lib/onboarding/causalOnboarding";

// LE RÉCAP — l'arborescence rangée par le moteur + les modules calibrés.
function Dossier({ titre, items }) {
  return (
    <div className="rounded-xl border border-white/10 bg-[#121214] px-4 py-3.5">
      <p className="flex items-center gap-2 text-[14px] font-bold text-white">
        <span className="text-[11px] text-[#C9A96E]" aria-hidden="true">▣</span> {titre}
      </p>
      <ul className="mt-2 flex flex-wrap gap-1.5">
        {(items.length ? items : ["À poser plus tard"]).map((it, i) => (
          <li key={i} className="rounded-full border border-white/[0.06] px-2.5 py-1 text-[11.5px] text-white/50">
            {it}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default function RecapUnivers({ relations, roles, jalons }) {
  const rolesNoms = roles.map(nomRole).filter(Boolean);
  const mods = modulesDe(roles, relations);

  return (
    <div className="grid gap-5 md:grid-cols-2">
      <div className="flex flex-col gap-3">
        <Dossier titre="Racines & Parcours" items={jalons.avant.map((j) => j.n)} />
        <Dossier titre="Identités & Présent" items={[...rolesNoms, ...jalons.maintenant.map((j) => j.n)]} />
        <Dossier titre="Projets & Vision" items={jalons.apres.map((j) => j.n)} />
      </div>
      <div>
        <div className="rounded-xl border border-white/10 bg-[#121214] px-4 py-3.5">
          <p className="text-[14px] font-bold text-white">Modules calibrés pour vous</p>
          <ul className="mt-2.5 flex flex-wrap gap-2">
            {(mods.length ? mods : ["Le socle AIME"]).map((m) => (
              <li key={m} className="rounded-full border border-[#8F7E55] px-3 py-1.5 text-[12px] text-[#C9A96E]">
                {m}
              </li>
            ))}
          </ul>
        </div>
        <p className="mt-3 text-[12px] text-white/35">Suggérés par vos choix — activables plus tard, jamais imposés.</p>
      </div>
    </div>
  );
}