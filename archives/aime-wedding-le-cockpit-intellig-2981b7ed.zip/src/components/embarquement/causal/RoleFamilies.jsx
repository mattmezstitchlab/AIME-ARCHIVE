import { useState } from "react";
import { FAMILLES } from "@/lib/onboarding/causalOnboarding";

// LES FAMILLES DE RÔLES — 6 familles + l'axe statut. Les trois familles
// secondaires restent repliées derrière « Voir toutes les familles ».
export default function RoleFamilies({ roles, sugg, onToggle }) {
  const [toutes, setToutes] = useState(false);
  const fams = toutes ? FAMILLES : FAMILLES.filter((f) => !f.plus);

  return (
    <div className="mt-7">
      {fams.map((f) => (
        <div key={f.id} className="mb-4">
          <p className="mb-2 flex items-center gap-2 font-mono text-[9px] font-semibold uppercase tracking-[0.26em] text-white/35">
            {f.t}
            <span className="h-px flex-1 bg-white/[0.06]" aria-hidden="true" />
          </p>
          <div className="flex flex-wrap gap-2">
            {f.roles.map(([id, nom]) => {
              const on = roles.includes(id);
              const suggere = sugg.pills.has(id) && !on;
              return (
                <button
                  key={id}
                  type="button"
                  onClick={() => onToggle(id)}
                  aria-pressed={on}
                  className={`rounded-full border px-4 py-2 text-[13px] transition ${
                    on
                      ? "border-[#C9A96E] bg-[#C9A96E] font-semibold text-[#141310]"
                      : suggere
                      ? "border-dashed border-[#8F7E55] text-[#C9A96E]"
                      : "border-white/10 text-white/55 hover:border-white/30 hover:text-white"
                  }`}
                >
                  {nom}
                </button>
              );
            })}
          </div>
        </div>
      ))}
      <button
        type="button"
        onClick={() => setToutes(!toutes)}
        className="text-[12.5px] text-white/35 underline underline-offset-4 transition hover:text-white/60"
      >
        {toutes ? "Réduire les familles" : "Voir toutes les familles de rôles"}
      </button>
    </div>
  );
}