// LE BANDEAU DU MOTEUR — « RIPPLE · pourquoi ces suggestions » : la loi
// causale rendue visible. Chaque règle « si → alors » s'affiche avec sa raison.
export default function MoteurBand({ raisons }) {
  if (!raisons.length) return null;
  return (
    <div className="mt-7 border-t border-dashed border-white/10 pt-4">
      <p className="flex items-center gap-2 font-mono text-[9px] font-semibold uppercase tracking-[0.28em] text-white/35">
        <span className="h-3.5 w-3.5 rounded-full bg-[conic-gradient(from_210deg,#F87171,#FBBF24,#34D399,#38BDF8,#C084FC,#F87171)]" aria-hidden="true" />
        Ripple · Pourquoi ces suggestions
      </p>
      <div className="mt-2.5 space-y-1.5">
        {raisons.map((r) => {
          const [avant, ...reste] = r.split("—");
          return (
            <p key={r} className="flex items-baseline gap-2.5 text-[12.5px] leading-relaxed text-white/55">
              <span className="h-1.5 w-1.5 shrink-0 translate-y-[-1px] rounded-full bg-[#C9A96E]" aria-hidden="true" />
              <span>
                <b className="font-semibold text-white/85">{avant.trim()}</b>
                {reste.length > 0 && <em className="text-white/40"> — {reste.join("—").trim()}</em>}
              </span>
            </p>
          );
        })}
      </div>
    </div>
  );
}