import { RELATIONS } from "@/lib/onboarding/causalOnboarding";

// LES 4 TUILES RELATIONNELLES — MOI · MES CLIENTS · MES ARTISTES · MON ÉQUIPE.
// Sélection multiple ; les suggestions du moteur passent en pointillé doré
// avec leur raison, et les points du Registre apparaissent sous la tuile.
export default function RelationTiles({ selected, sugg, onToggle }) {
  return (
    <div className="grid gap-3.5 sm:grid-cols-2 xl:grid-cols-4">
      {RELATIONS.map((r) => {
        const on = selected.includes(r.id);
        const raison = sugg.rels.get(r.id);
        const pts = sugg.points.get(r.id);
        return (
          <button
            key={r.id}
            type="button"
            onClick={() => onToggle(r.id)}
            aria-pressed={on}
            className={`rounded-2xl border bg-[#121214] px-4 py-5 text-center transition-all hover:-translate-y-0.5 ${
              on
                ? "border-[#C9A96E] shadow-[0_0_0_1px_#C9A96E,0_14px_40px_-18px_#C9A96E]"
                : raison
                ? "border-dashed border-[#8F7E55]"
                : "border-white/10"
            }`}
          >
            <span className={`block font-heading text-[19px] font-extrabold tracking-[0.06em] ${on ? "text-[#C9A96E]" : "text-white"}`}>
              {r.gt}
            </span>
            <span className="mt-2 block min-h-[2.6em] text-[12.5px] leading-relaxed text-white/50">{r.st}</span>
            {raison && (
              <span className="mt-2 block text-[11px] italic leading-relaxed text-white/35">
                Suggéré — {raison.split("—")[1]?.trim() || raison}
              </span>
            )}
            <span className="mt-3 flex min-h-[8px] items-center justify-center gap-1">
              {pts?.c.map((c, i) => (
                <i key={i} className="h-[7px] w-[7px] rounded-full" style={{ background: c }} />
              ))}
              {pts && <span className="ml-1 font-mono text-[8px] tracking-[0.12em] text-white/35">{pts.n}</span>}
            </span>
          </button>
        );
      })}
    </div>
  );
}