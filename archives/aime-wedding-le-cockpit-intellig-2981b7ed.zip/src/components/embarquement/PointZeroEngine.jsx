import { useState, useRef, useEffect, useMemo } from "react";
import { Upload, ArrowRight, Check } from "lucide-react";
import { ROUTES, ENTITIES, FUNCTIONS, INTEGRATIONS, STATUS_META } from "@/lib/health/siteMap";

// ─────────────────────────────────────────────────────────────────────────
// MOTEUR POINT ZÉRO (embarquement) — le moteur radial ÉTEINT, prêt à s'allumer.
// Au départ : nœuds gris, légende visible, noyau doré « POINT ZÉRO » au centre.
// On importe un fichier → analyse → tri → les nœuds s'allument en couleur un à
// un (propagation Ripple) → « Votre compte est prêt » → bouton Suivant → Bureau.
// C'est une version scénarisée et autonome, sans les couches/filtres du moteur
// de la page ENTRER (qui reste inchangé).
// ─────────────────────────────────────────────────────────────────────────

const LAYERS = [
  { key: "routes", label: "Routes", color: "#38bdf8", radius: 320,
    nodes: ROUTES.map((r) => ({ id: r.path, tone: (STATUS_META[r.status] || STATUS_META.live).color })) },
  { key: "entities", label: "Entités", color: "#34d399", radius: 210,
    nodes: ENTITIES.map((e) => ({ id: e.name, tone: "#34d399" })) },
  { key: "functions", label: "Fonctions", color: "#fbbf24", radius: 120,
    nodes: FUNCTIONS.map((f) => ({ id: f.name, tone: "#fbbf24" })) },
  { key: "integrations", label: "Intégrations", color: "#c084fc", radius: 400,
    nodes: INTEGRATIONS.map((i) => ({ id: i.name, tone: "#c084fc" })) },
];

function ringPositions(nodes, radius, phase = 0) {
  const n = nodes.length || 1;
  return nodes.map((node, i) => {
    const angle = phase + (i / n) * Math.PI * 2;
    return { ...node, x: Math.cos(angle) * radius, y: Math.sin(angle) * radius };
  });
}

export default function PointZeroEngine({ onDone }) {
  const fileRef = useRef(null);
  const timers = useRef([]);
  const [phase, setPhase] = useState("idle"); // idle | propagating | done
  const [fileName, setFileName] = useState(null);
  const [litIds, setLitIds] = useState([]);

  useEffect(() => () => timers.current.forEach(clearTimeout), []);

  const placed = useMemo(
    () => LAYERS.map((l, li) => ({ ...l, placedNodes: ringPositions(l.nodes, l.radius, li * 0.6) })),
    []
  );
  const allNodeIds = useMemo(
    () => placed.flatMap((l) => l.placedNodes.map((n) => `${l.key}:${n.id}`)),
    [placed]
  );

  const total = allNodeIds.length;
  const litCount = litIds.length;

  const startPropagation = (file) => {
    if (!file) return;
    setFileName(file.name);
    setPhase("propagating");
    setLitIds([]);
    timers.current.forEach(clearTimeout);
    timers.current = [];
    allNodeIds.forEach((id, i) => {
      const t = setTimeout(() => {
        setLitIds((prev) => [...prev, id]);
        if (i === allNodeIds.length - 1) {
          const done = setTimeout(() => setPhase("done"), 500);
          timers.current.push(done);
        }
      }, 200 + i * 55);
      timers.current.push(t);
    });
  };

  return (
    <div className="relative flex h-full w-full items-center justify-center overflow-hidden bg-black">
      {/* Le plan radial, centré */}
      <div className="pointer-events-none absolute left-1/2 top-1/2 h-0 w-0 -translate-x-1/2 -translate-y-1/2">
        <svg width="1" height="1" className="overflow-visible" aria-hidden="true">
          {/* Anneaux d'orbite */}
          {placed.map((l) => (
            <circle key={`orbit-${l.key}`} cx="0" cy="0" r={l.radius} fill="none"
              stroke={phase === "idle" ? "#ffffff" : l.color}
              strokeOpacity={phase === "idle" ? 0.06 : 0.16} strokeDasharray="3 6" />
          ))}
          {/* Traits causaux, visibles pendant/après la propagation */}
          {phase !== "idle" &&
            placed.flatMap((l) =>
              l.placedNodes.map((node) => {
                const isLit = litIds.includes(`${l.key}:${node.id}`);
                return (
                  <line key={`link-${l.key}-${node.id}`} x1="0" y1="0" x2={node.x} y2={node.y}
                    stroke={l.color} strokeOpacity={isLit ? 0.22 : 0.05} strokeWidth="1" />
                );
              })
            )}
          {/* Nœuds : gris éteints au départ, colorés quand allumés */}
          {placed.flatMap((l) =>
            l.placedNodes.map((node) => {
              const isLit = litIds.includes(`${l.key}:${node.id}`);
              return (
                <g key={`node-${l.key}-${node.id}`} transform={`translate(${node.x}, ${node.y})`}>
                  {isLit && <circle r="14" fill="none" stroke={l.color} strokeOpacity="0.6" className="ripple-wave" />}
                  <circle r={isLit ? 6 : 4} fill={isLit ? node.tone : "#3a3a3a"} className="transition-all duration-300" />
                </g>
              );
            })
          )}
        </svg>
      </div>

      {/* Noyau POINT ZÉRO */}
      <div className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
        <div className={`flex h-24 w-24 flex-col items-center justify-center rounded-full border shadow-2xl backdrop-blur ${
          phase === "idle" ? "border-white/20 bg-white/[0.06]" : "border-accent/60 bg-black/90"
        }`}>
          <span className={`h-3 w-3 rounded-full ${phase === "idle" ? "bg-white/30" : "bg-accent"} ${
            phase === "propagating" ? "animate-ping" : ""
          }`} />
          <span className="mt-2 font-heading text-[9px] font-semibold uppercase tracking-[0.16em] text-white/70">
            Point zéro
          </span>
        </div>
      </div>

      {/* Légende — toujours visible */}
      <div className="pointer-events-none absolute bottom-6 left-1/2 flex -translate-x-1/2 flex-wrap justify-center gap-x-5 gap-y-1.5 rounded-full border border-white/10 bg-black/70 px-5 py-2 backdrop-blur">
        {LAYERS.map((l) => (
          <span key={l.key} className="flex items-center gap-1.5 text-[10px] font-medium text-white/55">
            <span className="h-2 w-2 rounded-full" style={{ backgroundColor: phase === "idle" ? "#3a3a3a" : l.color }} />
            {l.label}
          </span>
        ))}
      </div>

      {/* Overlay d'action — importer, progression, compte prêt */}
      <div className="pointer-events-none absolute inset-x-0 top-24 flex flex-col items-center px-6 text-center">
        {phase === "idle" && (
          <div className="pointer-events-auto max-w-md">
            <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-white/45">Moteur en veille</p>
            <h2 className="mt-3 font-heading text-2xl font-semibold tracking-[-0.02em] text-white sm:text-3xl">
              Importez votre POINT ZÉRO
            </h2>
            <p className="mx-auto mt-3 max-w-sm text-[14px] leading-6 text-white/60">
              Le moteur est éteint. Déposez votre fichier : il l'analyse, le trie,
              et la propagation causale s'allume sous vos yeux.
            </p>
            <input ref={fileRef} type="file" className="hidden" onChange={(e) => startPropagation(e.target.files?.[0])} />
            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              className="mt-6 inline-flex items-center gap-2 rounded-full bg-accent px-7 py-3.5 text-sm font-semibold text-accent-foreground transition-transform hover:scale-[1.02]"
            >
              <Upload className="h-4 w-4" /> Importer le fichier
            </button>
          </div>
        )}

        {phase === "propagating" && (
          <div className="max-w-md">
            <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-accent">Propagation en cours</p>
            <h2 className="mt-3 font-heading text-2xl font-semibold tracking-[-0.02em] text-white">
              Analyse & tri de <span className="text-accent">{fileName}</span>
            </h2>
            <p className="mt-3 text-[13px] tabular-nums text-white/55">
              {litCount}/{total} nœuds propagés
            </p>
          </div>
        )}

        {phase === "done" && (
          <div className="pointer-events-auto max-w-md">
            <span className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-accent text-accent-foreground">
              <Check className="h-6 w-6" strokeWidth={2.5} />
            </span>
            <h2 className="mt-4 font-heading text-2xl font-semibold tracking-[-0.02em] text-white sm:text-3xl">
              Votre compte est prêt
            </h2>
            <p className="mx-auto mt-3 max-w-sm text-[14px] leading-6 text-white/60">
              Votre dossier a bien été créé et rangé. Découvrez-le dans votre Bureau.
            </p>
            <button
              type="button"
              onClick={onDone}
              className="mt-6 inline-flex items-center gap-2 rounded-full bg-white px-7 py-3.5 text-sm font-semibold text-black transition-transform hover:scale-[1.02]"
            >
              Suivant <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}