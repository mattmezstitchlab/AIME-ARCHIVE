import { useState } from "react";
import {
  Plus, X, Baby, School, GraduationCap, BookOpen, Briefcase, Sparkles, Users, MapPin,
} from "lucide-react";
import { MILESTONE_TYPES } from "@/lib/onboarding/etreGrammar";

// AVANT — la timeline de la personne. On empile des jalons (naissance, écoles,
// diplômes, expériences…) qui deviendront les dossiers « Racines & Parcours ».
const ICONS = {
  Baby, School, GraduationCap, BookOpen, Briefcase, Sparkles, Users, MapPin,
};

export default function PastTimeline({ milestones, onChange }) {
  const [type, setType] = useState("naissance");
  const [label, setLabel] = useState("");
  const [year, setYear] = useState("");

  const add = () => {
    if (!label.trim()) return;
    const next = [...milestones, { type, label: label.trim(), year: year.trim() }];
    // Tri chronologique quand l'année est renseignée (les sans-année en fin).
    next.sort((a, b) => (a.year || "9999").localeCompare(b.year || "9999"));
    onChange(next);
    setLabel("");
    setYear("");
  };
  const remove = (i) => onChange(milestones.filter((_, idx) => idx !== i));

  const activeType = MILESTONE_TYPES.find((m) => m.id === type);

  return (
    <div>
      {/* Timeline visuelle des jalons posés */}
      {milestones.length > 0 && (
        <ol className="relative mb-5 ml-3 border-l border-white/15 pl-5">
          {milestones.map((m, i) => {
            const t = MILESTONE_TYPES.find((x) => x.id === m.type);
            const Icon = ICONS[t?.icon] || MapPin;
            return (
              <li key={i} className="relative mb-3 last:mb-0">
                <span className="absolute -left-[27px] grid h-5 w-5 place-items-center rounded-full border border-white/20 bg-black">
                  <Icon className="h-2.5 w-2.5 text-white/70" />
                </span>
                <div className="flex items-center justify-between gap-2 rounded-lg border border-white/10 bg-white/[0.02] px-3 py-2">
                  <div className="min-w-0">
                    <p className="truncate text-[13px] font-medium text-white">{m.label}</p>
                    <p className="text-[10px] uppercase tracking-wide text-white/40">
                      {t?.label}{m.year ? ` · ${m.year}` : ""}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => remove(i)}
                    className="grid h-6 w-6 shrink-0 place-items-center rounded-full text-white/40 transition hover:bg-white/10 hover:text-white"
                    aria-label={`Retirer ${m.label}`}
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                </div>
              </li>
            );
          })}
        </ol>
      )}

      {/* Choix du type de jalon */}
      <div className="mb-3 flex flex-wrap gap-1.5">
        {MILESTONE_TYPES.map((m) => {
          const Icon = ICONS[m.icon] || MapPin;
          const active = type === m.id;
          const already = m.oneOnly && milestones.some((x) => x.type === m.id);
          return (
            <button
              key={m.id}
              type="button"
              disabled={already}
              onClick={() => setType(m.id)}
              className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-[12px] transition disabled:opacity-25 ${
                active ? "border-white bg-white text-black" : "border-white/12 text-white/60 hover:border-white/30"
              }`}
            >
              <Icon className="h-3.5 w-3.5" /> {m.label}
            </button>
          );
        })}
      </div>

      {/* Saisie du jalon */}
      <div className="flex gap-2">
        <input
          value={label}
          onChange={(e) => setLabel(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), add())}
          placeholder={activeType?.placeholder || "Un moment marquant"}
          className="w-full rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2 text-[13px] text-white placeholder:text-white/25 outline-none transition focus:border-white/30"
        />
        <input
          value={year}
          onChange={(e) => setYear(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), add())}
          placeholder="Année"
          inputMode="numeric"
          className="w-20 shrink-0 rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2 text-center text-[13px] text-white placeholder:text-white/25 outline-none transition focus:border-white/30"
        />
        <button
          type="button"
          onClick={add}
          className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-white/10 text-white transition hover:bg-white/20"
          aria-label="Ajouter le jalon"
        >
          <Plus className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}