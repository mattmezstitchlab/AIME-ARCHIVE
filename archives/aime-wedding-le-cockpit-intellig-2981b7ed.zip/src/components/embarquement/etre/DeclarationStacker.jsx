import { useState } from "react";
import {
  Plus, X, Tag, IdCard, Fingerprint, Heart, Wrench, Rocket, TrendingUp, Target,
} from "lucide-react";

// Empileur générique de déclarations pour un temps (MAINTENANT / APRÈS).
// Pour chaque catégorie (identités, passions, projets…), on peut ajouter
// PLUSIEURS entrées — c'est ce qui consolide le bureau unique.
//
// props:
//   categories : liste de catégories (id, label, verb, icon, desc, placeholder, suggestions)
//   values     : { [catId]: [{ label }] }
//   onChange(catId, list)
const ICONS = { IdCard, Fingerprint, Heart, Wrench, Rocket, TrendingUp, Target };

function CategoryBlock({ category, list, onChange }) {
  const [draft, setDraft] = useState("");
  const Icon = ICONS[category.icon] || Tag;

  const add = (label) => {
    const clean = (label ?? draft).trim();
    if (!clean) return;
    if (list.some((d) => d.label.toLowerCase() === clean.toLowerCase())) {
      setDraft("");
      return;
    }
    onChange([...list, { label: clean }]);
    setDraft("");
  };
  const remove = (i) => onChange(list.filter((_, idx) => idx !== i));

  const openSuggestions = (category.suggestions || []).filter(
    (s) => !list.some((d) => d.label.toLowerCase() === s.toLowerCase())
  );

  return (
    <div className="rounded-xl border border-white/10 bg-white/[0.02] p-4">
      <div className="flex items-center gap-2">
        <Icon className="h-4 w-4 text-white/60" />
        <div>
          <p className="font-heading text-[14px] font-semibold leading-none text-white">{category.label}</p>
          <p className="mt-1 text-[11px] text-white/40">
            <span className="text-white/55">{category.verb}</span> {category.desc}
          </p>
        </div>
      </div>

      {/* Entrées empilées */}
      {list.length > 0 && (
        <div className="mt-3 flex flex-wrap gap-1.5">
          {list.map((d, i) => (
            <span
              key={i}
              className="inline-flex items-center gap-1.5 rounded-full bg-white/10 py-1 pl-3 pr-1.5 text-[12px] text-white"
            >
              {d.label}
              <button
                type="button"
                onClick={() => remove(i)}
                className="grid h-4 w-4 place-items-center rounded-full text-white/50 transition hover:bg-white/20 hover:text-white"
                aria-label={`Retirer ${d.label}`}
              >
                <X className="h-3 w-3" />
              </button>
            </span>
          ))}
        </div>
      )}

      {/* Champ d'ajout */}
      <div className="mt-3 flex gap-2">
        <input
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              add();
            }
          }}
          placeholder={category.placeholder}
          className="w-full rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2 text-[13px] text-white placeholder:text-white/25 outline-none transition focus:border-white/30"
        />
        <button
          type="button"
          onClick={() => add()}
          className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-white/10 text-white transition hover:bg-white/20"
          aria-label="Ajouter"
        >
          <Plus className="h-4 w-4" />
        </button>
      </div>

      {/* Suggestions rapides */}
      {openSuggestions.length > 0 && (
        <div className="mt-2.5 flex flex-wrap gap-1.5">
          {openSuggestions.slice(0, 6).map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => add(s)}
              className="rounded-full border border-white/10 px-2.5 py-1 text-[11px] text-white/45 transition hover:border-white/30 hover:text-white"
            >
              + {s}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

export default function DeclarationStacker({ categories, values, onChange }) {
  return (
    <div className="space-y-3">
      {categories.map((c) => (
        <CategoryBlock
          key={c.id}
          category={c}
          list={values[c.id] || []}
          onChange={(list) => onChange(c.id, list)}
        />
      ))}
    </div>
  );
}