import { useEffect, useMemo, useState } from "react";
import { PRONOUNS } from "@/lib/onboarding/etreGrammar";
import { computeSuggestions, registryMatches } from "@/lib/onboarding/pronounCausal";
import PronounCard from "@/components/embarquement/etre/PronounCard";
import { base44 } from "@/api/base44Client";

// ÉTAPE 1 — les pronoms, MULTI-SÉLECTION causale :
// une wedding planner peut être JE + VOUS (elle et le couple accompagné).
// Chaque case cliquée ouvre son verso (choix), chaque choix éclaire le reste
// — pronoms suggérés, statuts suggérés, points du Registre — avec la raison
// en petit texte gris, toujours visible.
export default function PronounPicker({ pronouns, roles, onChange }) {
  const [cards, setCards] = useState([]);

  useEffect(() => {
    base44.entities.PersonCard.list("-updated_date", 50).then(setCards).catch(() => {});
  }, []);

  const suggestions = useMemo(() => computeSuggestions(pronouns, roles), [pronouns, roles]);
  const dots = useMemo(() => registryMatches(roles, cards), [roles, cards]);

  const togglePronoun = (id) => {
    const next = pronouns.includes(id) ? pronouns.filter((x) => x !== id) : [...pronouns, id];
    onChange({ pronouns: next, roles });
  };

  const toggleRole = (pid, rid) => {
    const list = roles[pid] || [];
    const next = list.includes(rid) ? list.filter((x) => x !== rid) : [...list, rid];
    onChange({ pronouns, roles: { ...roles, [pid]: next } });
  };

  return (
    <div className="text-center">
      <p className="text-[10px] font-semibold uppercase tracking-[0.3em] text-white/35">
        Conjuguez votre univers
      </p>
      <h2 className="mt-3 font-heading text-3xl font-semibold tracking-[-0.02em] sm:text-4xl">
        Tout commence par un mot.
      </h2>
      <p className="mx-auto mt-3 max-w-md text-[14px] text-white/50">
        Choisissez un ou plusieurs points de vue — cliquez, précisez, et regardez
        ce que chaque choix éclaire : les suggestions expliquent toujours pourquoi.
      </p>

      <div className="mx-auto mt-9 grid max-w-2xl grid-cols-2 gap-3 sm:grid-cols-3">
        {PRONOUNS.map((p) => (
          <PronounCard
            key={p.id}
            p={p}
            active={pronouns.includes(p.id)}
            suggestion={suggestions.pronouns[p.id]}
            selectedRoles={roles[p.id] || []}
            suggestedRoles={suggestions.roles}
            dots={dots[p.id]}
            onToggle={() => togglePronoun(p.id)}
            onToggleRole={(rid) => toggleRole(p.id, rid)}
          />
        ))}
      </div>
    </div>
  );
}