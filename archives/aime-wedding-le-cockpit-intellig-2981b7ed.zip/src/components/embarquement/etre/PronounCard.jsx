import { PRONOUN_ROLES } from "@/lib/onboarding/pronounCausal";

// UNE CASE-PRONOM — recto : le grand mot + le texte gris. Sélectionnée, elle
// révèle son verso : les choix (rôles/statuts). Suggérée par la causalité,
// elle s'éclaire avec la raison en gris. Les points colorés en bas = les
// cartes du Registre que vos choix pourraient intéresser.
export default function PronounCard({ p, active, suggestion, selectedRoles, suggestedRoles, dots, onToggle, onToggleRole }) {
  const roles = PRONOUN_ROLES[p.id] || [];

  return (
    <div
      className={`flex flex-col rounded-2xl transition ${
        active
          ? "bg-white/[0.07] ring-1 ring-white/40"
          : suggestion
            ? "bg-white/[0.04] ring-1 ring-accent/60"
            : "bg-white/[0.04] hover:bg-white/[0.08]"
      }`}
    >
      <button type="button" onClick={onToggle} className="flex flex-col items-center gap-1.5 px-4 pb-3 pt-6 text-white">
        <span className={`font-heading text-3xl font-bold tracking-[0.04em] ${suggestion && !active ? "text-accent" : ""}`}>
          {p.label}
        </span>
        <span className="text-[11px] leading-snug text-white/40">{p.hint}</span>
        {suggestion && !active && (
          <span className="mt-1 text-[10px] italic leading-snug text-white/45">Suggéré — {suggestion}</span>
        )}
      </button>

      {/* LE VERSO — les choix, révélés au clic. Multi-sélection libre. */}
      {active && (
        <div className="flex flex-wrap justify-center gap-1.5 px-3 pb-3">
          {roles.map((r) => {
            const on = selectedRoles.includes(r.id);
            const reason = suggestedRoles[`${p.id}:${r.id}`];
            return (
              <button
                key={r.id}
                type="button"
                onClick={() => onToggleRole(r.id)}
                title={reason ? `Suggéré — ${reason}` : undefined}
                className={`rounded-full px-2.5 py-1 text-[11px] transition ${
                  on
                    ? "bg-accent font-semibold text-black"
                    : reason
                      ? "border border-dashed border-accent/70 text-accent hover:bg-accent/10"
                      : "border border-white/15 text-white/60 hover:border-white/40 hover:text-white"
                }`}
              >
                {r.label}
              </button>
            );
          })}
          {/* La raison de la 1re suggestion de choix, en clair (rien de caché). */}
          {roles.some((r) => suggestedRoles[`${p.id}:${r.id}`]) && (
            <p className="w-full pt-1 text-center text-[10px] italic text-white/40">
              {suggestedRoles[`${p.id}:${roles.find((r) => suggestedRoles[`${p.id}:${r.id}`]).id}`]}
            </p>
          )}
        </div>
      )}

      {/* LES POINTS DU REGISTRE — ce qu'il ne voit pas encore, mais qui existe. */}
      {dots?.length > 0 && (
        <div className="flex items-center justify-center gap-1 pb-3" title={dots.map((d) => d.name).join(" · ")}>
          {dots.map((d, i) => (
            <span key={i} className="h-1.5 w-1.5 rounded-full" style={{ background: d.color, boxShadow: `0 0 5px ${d.color}` }} />
          ))}
          <span className="ml-1 text-[9px] uppercase tracking-[0.14em] text-white/30">Registre</span>
        </div>
      )}
    </div>
  );
}