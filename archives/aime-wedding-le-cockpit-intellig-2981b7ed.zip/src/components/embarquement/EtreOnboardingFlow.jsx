import { useState } from "react";
import { ArrowRight, ArrowLeft, Check } from "lucide-react";
import RelationTiles from "@/components/embarquement/causal/RelationTiles";
import RoleFamilies from "@/components/embarquement/causal/RoleFamilies";
import MoteurBand from "@/components/embarquement/causal/MoteurBand";
import LigneDeVie from "@/components/embarquement/causal/LigneDeVie";
import RecapUnivers from "@/components/embarquement/causal/RecapUnivers";
import CarteUniqueApercu from "@/components/embarquement/causal/CarteUniqueApercu";
import { suggestions, nomRole, STATUTS, essenceDe, modulesDe } from "@/lib/onboarding/causalOnboarding";
import { buildEtreTree } from "@/lib/onboarding/etreArborescence";

// ─────────────────────────────────────────────────────────────────────────
// L'ONBOARDING CAUSAL — 4 étapes, vocabulaire relationnel :
//   1) QUI ÊTES-VOUS ICI ?  → MOI · MES CLIENTS · MES ARTISTES · MON ÉQUIPE
//      + familles de rôles + moteur « si → alors, parce que » + points Registre
//   2) LE NOM               → le seul champ vraiment requis
//   3) LA LIGNE DE VIE      → j'étais / je suis / je serai, une seule ligne
//   4) RÉCAP                → arborescence + modules calibrés → publication
// La Carte Unique se construit en direct dans la colonne de droite.
// « La grammaire de l'ÊTRE » reste le nom du moteur — plus l'interface.
// ─────────────────────────────────────────────────────────────────────────

const TITRES = [
  { sur: "ÉTAPE 1 / 4 · QUI ÊTES-VOUS ICI ?", h: "Tout commence par vous.", intro: "Choisissez une ou plusieurs situations — en mots simples. Chaque choix éclaire la suite, et le moteur explique toujours pourquoi." },
  { sur: "ÉTAPE 2 / 4 · LE NOM", h: "Comment vous appelle-t-on ?", intro: "Une personne, une marque, un couple, une équipe — c'est le nom de votre carte, le seul champ vraiment requis." },
  { sur: "ÉTAPE 3 / 4 · VOTRE LIGNE DE VIE", h: "Trois temps, une seule ligne.", intro: "J'étais, je suis, je serai — posez quelques jalons, la carte se souviendra. Tout reste modifiable après." },
  { sur: "ÉTAPE 4 / 4 · VOTRE UNIVERS EST PRÊT", h: "Le moteur a tout rangé.", intro: "Une arborescence propre, des modules déjà calibrés — et votre Carte Unique, prête à rejoindre le Registre." },
];

export default function EtreOnboardingFlow({ onComplete }) {
  const [etape, setEtape] = useState(0);
  const [relations, setRelations] = useState([]);
  const [roles, setRoles] = useState([]);
  const [name, setName] = useState("");
  const [jalons, setJalons] = useState({ avant: [], maintenant: [], apres: [] });
  const [publie, setPublie] = useState(false);

  const sugg = suggestions(roles);
  const toggle = (list, set) => (id) => set(list.includes(id) ? list.filter((x) => x !== id) : [...list, id]);

  const canContinue = etape === 0 ? relations.length > 0 : etape === 1 ? name.trim().length > 0 : true;

  const etats = [
    relations.length ? `${roles.length} RÔLE(S) · LE MOTEUR ÉCOUTE` : "1 CLIC SUFFIT — LE RESTE PEUT ATTENDRE",
    "LE SEUL CHAMP VRAIMENT REQUIS",
    "FACULTATIF — LA CARTE VIVRA AUSSI SANS",
    publie ? "UNE PERSONNE, UNE CARTE — PUBLIÉE" : "TOUT RESTE MODIFIABLE DANS VOTRE COMPTE",
  ];

  const publier = () => {
    if (publie) return;
    setPublie(true);
    const rolesNoms = roles.filter((r) => !STATUTS.includes(r)).map(nomRole).filter(Boolean);
    const statuts = roles.filter((r) => STATUTS.includes(r)).map(nomRole).filter(Boolean);
    const milestones = jalons.avant.map((j) => ({ type: "etape", label: j.n, year: "" }));
    const now = { identites: rolesNoms, caracteristiques: [...statuts, ...jalons.maintenant.map((j) => j.n)] };
    const future = { projets: jalons.apres.map((j) => j.n) };
    setTimeout(() => {
      onComplete?.({
        relations,
        roles,
        jalons,
        modules: modulesDe(roles, relations),
        essence: essenceDe(roles),
        pronoun: relations[0] || "moi",
        pronouns: relations,
        grammar_roles: { moi: roles },
        name: name.trim(),
        milestones,
        now,
        future,
        tree: buildEtreTree({ pronoun: "je", milestones, now, future }),
      });
    }, 1400);
  };

  const t = TITRES[etape];

  return (
    <div className="dot-grid-dark min-h-screen bg-[#0A0A0B] px-4 pb-16 pt-8 text-white sm:px-6">
      {/* EN-TÊTE — la marque + le nom du moteur. */}
      <div className="text-center">
        <p className="font-heading text-[17px] font-extrabold tracking-[0.28em]">
          AIME<sup className="text-[9px]">®</sup>
        </p>
        <p className="font-signature -mt-0.5 text-[17px] text-white/55">Wedding</p>
        <p className="mt-3 font-mono text-[11px] font-medium tracking-[0.3em]">AIME® RIPPLE</p>
        <p className="mt-1 font-mono text-[9px] tracking-[0.34em] text-white/35">LA GRAMMAIRE DE VOTRE BUREAU</p>
        <div className="mt-5 mb-7 flex justify-center gap-2" aria-hidden="true">
          {TITRES.map((_, i) => (
            <span key={i} className={`h-[3px] w-11 rounded-full transition-colors ${i === etape ? "bg-white" : i < etape ? "bg-white/40" : "bg-white/10"}`} />
          ))}
        </div>
      </div>

      <div className="mx-auto grid max-w-[1180px] items-start gap-9 lg:grid-cols-[1fr_320px]">
        {/* LE PANNEAU DE L'ÉTAPE */}
        <div className="ripple-wave rounded-3xl border border-white/[0.06] bg-[#121214]/80 px-5 py-9 backdrop-blur sm:px-10" key={etape}>
          <p className="text-center font-mono text-[9.5px] font-semibold uppercase tracking-[0.32em] text-white/40">{t.sur}</p>
          <h2 className="mt-2 text-center font-heading text-[clamp(1.9rem,4vw,2.6rem)] font-extrabold leading-[1.05] tracking-[-0.025em]">{t.h}</h2>
          <p className="mx-auto mb-8 mt-3 max-w-[46ch] text-center text-[14px] leading-relaxed text-white/50">{t.intro}</p>

          {etape === 0 && (
            <>
              <RelationTiles selected={relations} sugg={sugg} onToggle={toggle(relations, setRelations)} />
              {relations.includes("moi") && <RoleFamilies roles={roles} sugg={sugg} onToggle={toggle(roles, setRoles)} />}
              <MoteurBand raisons={sugg.raisons} />
            </>
          )}

          {etape === 1 && (
            <div className="mx-auto max-w-[480px] text-center">
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Votre nom"
                maxLength={40}
                autoComplete="off"
                aria-label="Le nom de votre carte"
                className="w-full border-b border-white/10 bg-transparent pb-3 text-center font-heading text-[2rem] font-bold tracking-[-0.02em] text-white outline-none placeholder:font-medium placeholder:text-white/25 focus:border-[#C9A96E]"
              />
              <p className="mt-4 text-[12.5px] text-white/35">Il apparaîtra en tête de votre Carte Unique, dans le Registre.</p>
              <div className="mt-5 flex flex-wrap justify-center gap-2">
                {(roles.includes("marie") ? ["Léa & Tom", "Camille & Jo"] : relations.includes("equipe") ? ["Studio Lumen", "Collectif Dahlia"] : ["Marie Deval", "Studio M."]).map((n) => (
                  <button key={n} type="button" onClick={() => setName(n)} className="rounded-full border border-white/10 px-4 py-2 text-[13px] text-white/55 transition hover:border-white/30 hover:text-white">
                    {n}
                  </button>
                ))}
              </div>
            </div>
          )}

          {etape === 2 && <LigneDeVie jalons={jalons} onChange={setJalons} />}

          {etape === 3 && <RecapUnivers relations={relations} roles={roles} jalons={jalons} />}
        </div>

        {/* L'APERÇU — la Carte Unique en direct. */}
        <aside className="hidden lg:sticky lg:top-6 lg:block">
          <CarteUniqueApercu relations={relations} roles={roles} name={name} jalons={jalons} publie={publie} />
        </aside>
      </div>

      {/* LE PIED — retour · état · continuer. */}
      <div className="mx-auto mt-8 flex max-w-[1180px] items-center gap-4">
        {etape > 0 ? (
          <button type="button" onClick={() => setEtape(etape - 1)} className="inline-flex items-center gap-1.5 text-[13.5px] text-white/40 transition hover:text-white">
            <ArrowLeft className="h-3.5 w-3.5" /> Retour
          </button>
        ) : (
          <span />
        )}
        <span className="font-mono text-[9px] tracking-[0.22em] text-white/35">{etats[etape]}</span>
        <button
          type="button"
          onClick={() => (etape < 3 ? setEtape(etape + 1) : publier())}
          disabled={!canContinue || publie}
          className="ml-auto inline-flex items-center gap-2 rounded-full bg-white px-7 py-3 text-[14px] font-bold text-black transition hover:scale-[1.03] disabled:pointer-events-none disabled:opacity-35"
        >
          {etape === 3 ? (publie ? "Publication…" : "Publier au Registre") : "Continuer"}
          {etape === 3 ? <Check className="h-4 w-4" /> : <ArrowRight className="h-4 w-4" />}
        </button>
      </div>
    </div>
  );
}