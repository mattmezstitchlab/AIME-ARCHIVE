import { ArrowRight, Lock, Zap, GitBranch } from "lucide-react";
import { ROLE_CAUSALITY } from "@/lib/embarquement/roleCausality";
import { ROLE_LANDINGS } from "@/lib/home/roleLanding";
import { factsForRole, severityLabel } from "@/lib/embarquement/causalKnowledge";

const TONE = {
  high: "text-red-300 bg-red-400/10",
  mid: "text-accent bg-accent/10",
  low: "text-white/60 bg-white/10",
};

// ─────────────────────────────────────────────────────────────────────────
// PANNEAU D'EXPLICATION CAUSALE — apparaît quand un rôle est choisi.
// Montre POURQUOI ce rôle rayonne sur les autres : la liste des rôles impactés
// avec leur raison, puis les rôles à SECRET PRÉSERVÉ (créneau réservé, contenu
// masqué). C'est la démonstration vivante du génie AIME.
// ─────────────────────────────────────────────────────────────────────────

function roleLabel(key) {
  return ROLE_LANDINGS[key]?.label || key;
}

export default function CausalExplainPanel({ role }) {
  const c = role ? ROLE_CAUSALITY[role] : null;
  const facts = role ? factsForRole(role) : [];
  if (!c) return null;

  return (
    <div className="ripple-wave mt-6 rounded-xl border border-white/10 bg-white/[0.03] p-5">
      <div className="flex items-start gap-2.5">
        <span className="mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-full bg-accent/20 text-accent">
          <Zap className="h-3.5 w-3.5" />
        </span>
        <div>
          <p className="font-heading text-[15px] font-semibold leading-tight text-white">
            {c.headline}
          </p>
          <p className="mt-1 text-[12px] leading-5 text-white/50">{c.lead}</p>
        </div>
      </div>

      {/* Rôles impactés : ce que ce rôle voit / pilote, avec la raison */}
      <div className="mt-4 space-y-2">
        {c.impacts.map((imp) => (
          <div key={imp.role} className="flex items-start gap-2 text-[12px] leading-5">
            <ArrowRight className="mt-0.5 h-3.5 w-3.5 shrink-0 text-white/40" />
            <span>
              <span className="font-semibold text-white/90">{roleLabel(imp.role)}</span>
              <span className="text-white/50"> — {imp.why}</span>
            </span>
          </div>
        ))}
      </div>

      {/* Enchaînements terrain : cause → conséquence documentée (savoir métier) */}
      {facts.length > 0 && (
        <div className="mt-4 rounded-lg border border-white/10 bg-black/30 p-3">
          <p className="mb-2.5 flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-[0.16em] text-white/45">
            <GitBranch className="h-3 w-3" /> Ce qui se propage vraiment
          </p>
          <div className="space-y-2.5">
            {facts.map((f) => {
              const sev = severityLabel(f.severity);
              return (
                <div key={f.trigger} className="text-[12px] leading-5">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-white/90">{f.trigger}</span>
                    <span className={`rounded-full px-1.5 py-0.5 text-[9px] font-semibold uppercase tracking-wide ${TONE[sev.tone]}`}>
                      {sev.text}
                    </span>
                  </div>
                  <p className="mt-0.5 text-white/50">{f.chain}</p>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Secret préservé : créneau réservé, contenu masqué */}
      {c.secret.length > 0 && (
        <div className="mt-4 rounded-lg border border-accent/25 bg-accent/[0.06] p-3">
          <p className="mb-2 flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-[0.16em] text-accent">
            <Lock className="h-3 w-3" /> Secret préservé · créneau réservé
          </p>
          {c.secret.map((s) => (
            <div key={s.role} className="flex items-start gap-2 text-[12px] leading-5">
              <Lock className="mt-0.5 h-3 w-3 shrink-0 text-accent/70" />
              <span>
                <span className="font-semibold text-white/90">{roleLabel(s.role)}</span>
                <span className="text-white/50"> — {s.why}</span>
              </span>
            </div>
          ))}
          <p className="mt-2 text-[11px] leading-4 text-white/40">
            Le temps est bloqué dans la timeline pour tous — sans dévoiler le contenu. Fini les
            surprises qui font déraper le Jour J.
          </p>
        </div>
      )}
    </div>
  );
}