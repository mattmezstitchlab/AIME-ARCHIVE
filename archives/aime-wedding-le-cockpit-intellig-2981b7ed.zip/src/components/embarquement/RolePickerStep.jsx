import { ROLE_LANDINGS } from "@/lib/home/roleLanding";
import { litRoles } from "@/lib/embarquement/roleCausality";
import { Check, Lock, Zap } from "lucide-react";

// ─────────────────────────────────────────────────────────────────────────
// ÉTAPE 0 DE L'ONBOARDING — CHOIX DU RÔLE, AVEC PROPAGATION CAUSALE.
// Reprend les cartes de rôle du site (image, label). Au clic sur un rôle, on
// perçoit le causal EN DIRECT : les rôles impactés s'illuminent, les rôles à
// secret préservé prennent un liseré doré + cadenas, et le panneau explique
// pourquoi. C'est le génie AIME rendu visible dès l'entrée.
// ─────────────────────────────────────────────────────────────────────────

// Ordre d'affichage des rôles dans la grille.
const ROLE_ORDER = [
  "couple", "officiant", "temoin", "cortege",
  "famille", "invite", "coordinateur", "prestataire", "lieu",
];

function RoleTile({ roleKey, landing, active, impacted, secret, onSelect }) {
  // Anneau selon l'état causal : sélectionné > secret > impacté > neutre.
  // État causal rendu par un anneau INTÉRIEUR (pas de bordure blanche externe).
  const ring = active
    ? "ring-2 ring-inset ring-white"
    : secret
    ? "ring-2 ring-inset ring-accent/70"
    : impacted
    ? "ring-2 ring-inset ring-white/40"
    : "";

  return (
    <button
      type="button"
      onClick={() => onSelect(roleKey)}
      className={`group relative overflow-hidden text-left transition-all duration-300 ${ring} ${
        impacted || secret ? "mariage-ripple-pulse" : ""
      }`}
    >
      <div className="relative h-32 w-full sm:h-36">
        <img src={landing.image} alt="" className="absolute inset-0 h-full w-full object-cover" />
        <div
          className={`absolute inset-0 transition-colors ${
            active || impacted || secret
              ? "bg-gradient-to-t from-black/85 via-black/30 to-transparent"
              : "bg-gradient-to-t from-black/90 via-black/50 to-black/20"
          }`}
        />

        {/* Badge d'état causal (coin haut-droit) */}
        {active ? (
          <span className="absolute right-2 top-2 grid h-6 w-6 place-items-center rounded-full bg-white text-black">
            <Check className="h-3.5 w-3.5" />
          </span>
        ) : secret ? (
          <span className="absolute right-2 top-2 grid h-6 w-6 place-items-center rounded-full bg-accent text-accent-foreground">
            <Lock className="h-3.5 w-3.5" />
          </span>
        ) : impacted ? (
          <span className="absolute right-2 top-2 grid h-6 w-6 place-items-center rounded-full bg-white/85 text-black">
            <Zap className="h-3.5 w-3.5" />
          </span>
        ) : null}

        <div className="absolute inset-x-0 bottom-0 p-3">
          <p className="font-heading text-[16px] font-semibold leading-tight text-white">
            {landing.label}
          </p>
        </div>
      </div>
    </button>
  );
}

export default function RolePickerStep({ value, onSelect }) {
  const lit = litRoles(value);
  const impactedSet = new Set(lit.impacted);
  const secretSet = new Set(lit.secret);

  return (
    <div>
      {/* Mosaïque bord à bord — pas de gouttière, coins nets, moderne. */}
      <div className="grid grid-cols-2 gap-0 overflow-hidden rounded-xl sm:grid-cols-3">
        {ROLE_ORDER.map((roleKey) => (
          <RoleTile
            key={roleKey}
            roleKey={roleKey}
            landing={ROLE_LANDINGS[roleKey]}
            active={value === roleKey}
            impacted={impactedSet.has(roleKey)}
            secret={secretSet.has(roleKey)}
            onSelect={onSelect}
          />
        ))}
      </div>
    </div>
  );
}