import { useState } from "react";
import { ArrowRight, User, Heart, ChevronDown, Sparkles, History, Compass } from "lucide-react";
import RolePickerStep from "@/components/embarquement/RolePickerStep";
import RippleIntroScreen from "@/components/embarquement/RippleIntroScreen";
import PastTimeline from "@/components/embarquement/etre/PastTimeline";
import DeclarationStacker from "@/components/embarquement/etre/DeclarationStacker";
import { NOW_CATEGORIES, FUTURE_CATEGORIES } from "@/lib/onboarding/etreGrammar";

// ─────────────────────────────────────────────────────────────────────────
// ONBOARDING UNIFIÉ EN TIMELINE — l'entrée unique du Bureau.
// Un seul flux, présenté comme une frise du temps :
//   1) QUI ÊTES-VOUS ?  → choix du rôle
//   2) MAINTENANT        → l'intention (mariage / rôle). C'est le présent.
//   3) AVANT  (optionnel) → d'où l'on vient (timeline de vie)
//   4) APRÈS  (optionnel) → ce que l'on devient
// Causal : rien n'est obligatoire au-delà du présent, on complète quand on veut.
// Aucun contour blanc — fonds teintés et ombres douces uniquement.
// ─────────────────────────────────────────────────────────────────────────

function Field({ label, value, onChange, placeholder, type = "text" }) {
  return (
    <div>
      <label className="mb-2 block text-[10px] font-semibold uppercase tracking-[0.2em] text-white/40">
        {label}
      </label>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full rounded-lg bg-white/[0.04] px-4 py-3 text-[15px] text-white placeholder:text-white/25 outline-none transition focus:bg-white/[0.07] [color-scheme:dark]"
      />
    </div>
  );
}

// Marqueur de temps sur la frise verticale à gauche des sections.
function TimelineNode({ icon: Icon, tone = "present" }) {
  const tones = {
    past: "bg-white/[0.06] text-white/50",
    present: "bg-accent/20 text-accent",
    future: "bg-white/[0.06] text-white/50",
  };
  return (
    <div className={`grid h-9 w-9 shrink-0 place-items-center rounded-full ${tones[tone]}`}>
      <Icon className="h-4 w-4" strokeWidth={1.7} />
    </div>
  );
}

// Section optionnelle repliable (Avant / Après).
function OptionalTense({ icon, tone, eyebrow, title, subtitle, children, open, onToggle }) {
  return (
    <section className="flex gap-4">
      <div className="flex flex-col items-center">
        <TimelineNode icon={icon} tone={tone} />
        <span className="mt-1 w-px flex-1 bg-white/10" />
      </div>
      <div className="flex-1 pb-8">
        <button
          type="button"
          onClick={onToggle}
          className="flex w-full items-center justify-between rounded-xl bg-white/[0.03] px-4 py-3.5 text-left transition hover:bg-white/[0.05]"
        >
          <span>
            <span className="block text-[10px] font-semibold uppercase tracking-[0.22em] text-white/35">
              {eyebrow} · optionnel
            </span>
            <span className="mt-0.5 block font-heading text-lg font-semibold text-white">{title}</span>
            <span className="mt-0.5 block text-[12px] text-white/45">{subtitle}</span>
          </span>
          <ChevronDown
            className={`h-5 w-5 shrink-0 text-white/40 transition ${open ? "rotate-180" : ""}`}
          />
        </button>
        {open && <div className="mt-4 rounded-xl bg-white/[0.02] p-5">{children}</div>}
      </div>
    </section>
  );
}

const ROLE_QUESTION = {
  officiant: { label: "Type de cérémonie", placeholder: "Laïque, religieuse, symbolique…" },
  temoin: { label: "Pour qui êtes-vous témoin ?", placeholder: "Le marié, la mariée…" },
  cortege: { label: "Votre mission dans le cortège", placeholder: "EVJF, tenues, surprise…" },
  famille: { label: "Votre lien avec les mariés", placeholder: "Parent, frère/sœur, cousin·e…" },
  invite: { label: "De la part de qui ?", placeholder: "Marié, mariée, les deux…" },
  coordinateur: { label: "Ce que vous coordonnez", placeholder: "Budget, logistique, Jour J…" },
  prestataire: { label: "Votre métier / prestation", placeholder: "Photographe, DJ, traiteur…" },
  lieu: { label: "Ville de votre lieu", placeholder: "Aix-en-Provence" },
};

export default function UnifiedTimelineOnboarding({ onComplete }) {
  // step 0 = intro concept · step 1 = qui êtes-vous · step 2 = la timeline
  const [step, setStep] = useState(0);
  const [role, setRole] = useState(null);
  const [openPast, setOpenPast] = useState(false);
  const [openFuture, setOpenFuture] = useState(false);

  const [form, setForm] = useState({
    partner1: "", partner2: "", prenom: "", entreprise: "",
    coupleNames: "", date: "", lieu: "", ville: "",
    invites: 80, budget: 15000, roleInfo: "",
  });
  const [milestones, setMilestones] = useState([]);
  const [future, setFuture] = useState({});

  const set = (k) => (v) => setForm((f) => ({ ...f, [k]: v }));
  const setFutureCat = (cat, list) => setFuture((v) => ({ ...v, [cat]: list }));

  const isCouple = role === "couple";
  const isPro = role === "prestataire" || role === "lieu";

  const finish = () => {
    const q = ROLE_QUESTION[role];
    const base = { _role: role, _life: { milestones, future } };
    if (isCouple) {
      const lieu = [form.lieu, form.ville].filter(Boolean).join(", ");
      onComplete?.({
        ...base,
        couple: {
          ...(form.date ? { date: form.date } : {}),
          ...(lieu ? { lieu_reception: lieu } : {}),
          budget: form.budget,
        },
        invite: { nombre: form.invites },
        _names: [form.partner1, form.partner2].filter(Boolean),
      });
      return;
    }
    if (isPro) {
      onComplete?.({
        ...base, _pro: true, _business: form.entreprise.trim(),
        [role]: { nom: form.entreprise.trim(), ...(form.roleInfo.trim() ? { detail: form.roleInfo.trim() } : {}) },
        _names: form.prenom ? [form.prenom] : [],
      });
      return;
    }
    onComplete?.({
      ...base,
      ...(form.coupleNames.trim() ? { couple: { noms: form.coupleNames.trim() } } : {}),
      ...(q && form.roleInfo.trim() ? { [role]: { detail: form.roleInfo.trim() } } : {}),
      _names: form.prenom ? [form.prenom] : [],
    });
  };

  const canPickContinue = !!role;

  return (
    <div className="relative flex min-h-screen w-full flex-col items-center bg-black px-6 py-16 text-white">
      <div className="absolute inset-0 dot-grid-dark opacity-25" />

      {/* Marque centrale — AIME® Ripple en blanc */}
      <div className="relative mb-10 text-center">
        <h1 className="font-heading text-3xl font-light uppercase tracking-[0.3em] text-white sm:text-4xl">
          AIME<span className="align-super text-sm">®</span>{" "}
          <span className="font-semibold">Ripple</span>
        </h1>
        <p className="mt-2 text-[10px] font-medium uppercase tracking-[0.3em] text-white/35">
          {step === 0 ? "Le concept" : step === 1 ? "Qui êtes-vous ?" : "Votre parcours, sur une timeline"}
        </p>
      </div>

      {/* ÉTAPE 0 — Intro du concept causal */}
      {step === 0 && <RippleIntroScreen onContinue={() => setStep(1)} />}

      {/* ÉTAPE 1 — Qui êtes-vous (mosaïque) */}
      {step === 1 && (
        <div className="relative w-full max-w-2xl rounded-2xl bg-white/[0.03] p-8">
          <h2 className="mb-5 font-heading text-2xl font-semibold tracking-[-0.01em]">Qui êtes-vous ?</h2>
          <RolePickerStep value={role} onSelect={setRole} />
          <div className="mt-8 flex items-center justify-between">
            <button
              type="button"
              onClick={() => setStep(0)}
              className="text-[13px] font-medium text-white/45 transition hover:text-white"
            >
              Retour
            </button>
            <button
              type="button"
              onClick={() => setStep(2)}
              disabled={!canPickContinue}
              className="inline-flex items-center gap-2 rounded-full bg-white px-6 py-2.5 text-[13px] font-semibold text-black transition enabled:hover:scale-[1.02] disabled:opacity-30"
            >
              Continuer <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* ÉTAPE 2 — La timeline : présent (mariage/rôle) + avant/après optionnels */}
      {step === 2 && (
        <div className="relative w-full max-w-xl">
          {/* MAINTENANT — l'intention */}
          <section className="flex gap-4">
            <div className="flex flex-col items-center">
              <TimelineNode icon={isCouple ? Heart : User} tone="present" />
              <span className="mt-1 w-px flex-1 bg-white/10" />
            </div>
            <div className="flex-1 pb-8">
              <span className="block text-[10px] font-semibold uppercase tracking-[0.22em] text-accent">
                Maintenant · votre intention
              </span>
              <h2 className="mt-0.5 font-heading text-2xl font-semibold tracking-[-0.01em]">
                {isCouple ? "Votre mariage" : isPro ? "Votre activité" : "Vous, aujourd'hui"}
              </h2>

              <div className="mt-5 space-y-5 rounded-xl bg-white/[0.03] p-5">
                {isCouple ? (
                  <>
                    <div className="grid grid-cols-2 gap-4">
                      <Field label="Partenaire 1" value={form.partner1} onChange={set("partner1")} placeholder="Marie" />
                      <Field label="Partenaire 2" value={form.partner2} onChange={set("partner2")} placeholder="Thomas" />
                    </div>
                    <Field label="Date du mariage" type="date" value={form.date} onChange={set("date")} />
                    <Field label="Ville" value={form.ville} onChange={set("ville")} placeholder="Paris" />
                  </>
                ) : isPro ? (
                  <>
                    <Field
                      label={role === "lieu" ? "Nom de votre lieu" : "Nom de votre activité"}
                      value={form.entreprise}
                      onChange={set("entreprise")}
                      placeholder={role === "lieu" ? "Domaine des Oliviers" : "Studio Lumière · Photographie"}
                    />
                    <Field label="Votre prénom (contact)" value={form.prenom} onChange={set("prenom")} placeholder="Camille" />
                    <Field label={ROLE_QUESTION[role].label} value={form.roleInfo} onChange={set("roleInfo")} placeholder={ROLE_QUESTION[role].placeholder} />
                  </>
                ) : (
                  <>
                    <Field label="Votre prénom" value={form.prenom} onChange={set("prenom")} placeholder="Camille" />
                    <Field label="Le mariage de… (les mariés)" value={form.coupleNames} onChange={set("coupleNames")} placeholder="Marie & Thomas" />
                    {ROLE_QUESTION[role] && (
                      <Field label={ROLE_QUESTION[role].label} value={form.roleInfo} onChange={set("roleInfo")} placeholder={ROLE_QUESTION[role].placeholder} />
                    )}
                  </>
                )}
              </div>
            </div>
          </section>

          {/* AVANT — optionnel */}
          <OptionalTense
            icon={History}
            tone="past"
            eyebrow="Avant"
            title="D'où vous venez"
            subtitle="Votre histoire, vos racines — les jalons qui vous ont mené·e ici."
            open={openPast}
            onToggle={() => setOpenPast((o) => !o)}
          >
            <PastTimeline milestones={milestones} onChange={setMilestones} />
          </OptionalTense>

          {/* APRÈS — optionnel */}
          <OptionalTense
            icon={Compass}
            tone="future"
            eyebrow="Après"
            title="Ce que vous devenez"
            subtitle="Vos projets, votre cap — ce vers quoi tout cela vous emmène."
            open={openFuture}
            onToggle={() => setOpenFuture((o) => !o)}
          >
            <DeclarationStacker categories={FUTURE_CATEGORIES} values={future} onChange={setFutureCat} />
          </OptionalTense>

          {/* Fin de frise */}
          <div className="flex gap-4">
            <div className="flex flex-col items-center">
              <div className="grid h-9 w-9 place-items-center rounded-full bg-white text-black">
                <Sparkles className="h-4 w-4" />
              </div>
            </div>
            <div className="flex-1 pt-1">
              <p className="text-[13px] leading-6 text-white/50">
                Le présent suffit pour démarrer. L'avant et l'après se complètent
                quand vous voulez — c'est causal, tout reste ouvert.
              </p>
              <div className="mt-5 flex items-center gap-4">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="text-[13px] font-medium text-white/45 transition hover:text-white"
                >
                  Retour
                </button>
                <button
                  type="button"
                  onClick={finish}
                  className="inline-flex items-center gap-2 rounded-full bg-white px-6 py-2.5 text-[13px] font-semibold text-black transition hover:scale-[1.02]"
                >
                  Entrer dans mon Bureau <ArrowRight className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <p className="relative mt-12 text-[10px] uppercase tracking-[0.2em] text-white/20">
        AIME® Ripple · Un bureau unique, conjugué dans le temps
      </p>
    </div>
  );
}