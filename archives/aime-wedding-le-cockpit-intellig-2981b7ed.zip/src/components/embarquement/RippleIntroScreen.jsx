import { ArrowRight, Check, Zap, Lock } from "lucide-react";

// ─────────────────────────────────────────────────────────────────────────
// ÉCRAN D'INTRO AIME® RIPPLE — la toute première chose qu'on voit.
// Sobre : le concept causal expliqué en une phrase + les 3 pictos qui servent
// de légende (Votre rôle · Impacté · Secret), puis « Continuer » vers la
// mosaïque des rôles. Aucun contour blanc — fonds teintés uniquement.
// ─────────────────────────────────────────────────────────────────────────
export default function RippleIntroScreen({ onContinue }) {
  return (
    <div className="relative w-full max-w-xl rounded-2xl bg-white/[0.03] p-8">
      <h2 className="font-heading text-2xl font-semibold tracking-[-0.01em]">
        Bienvenue dans le moteur causal
      </h2>

      <div className="mt-5 rounded-xl bg-white/[0.04] p-4">
        <p className="flex items-start gap-2.5 text-[13px] leading-6 text-white/65">
          <Zap className="mt-0.5 h-4 w-4 shrink-0 text-accent" />
          <span>
            Chaque rôle rayonne sur les autres. Choisissez le vôtre : les rôles
            <span className="text-white"> impactés s'illuminent</span>, et les rôles à
            <span className="text-accent"> secret préservé</span> (surprises) réservent leur
            créneau sans dévoiler leur contenu.
          </span>
        </p>
      </div>

      {/* Légende des 3 pictos */}
      <div className="mt-5 space-y-3">
        <LegendRow
          badge={<span className="grid h-6 w-6 place-items-center rounded-full bg-white text-black"><Check className="h-3.5 w-3.5" /></span>}
          title="Votre rôle"
          text="Le point zéro : tout part de vous."
        />
        <LegendRow
          badge={<span className="grid h-6 w-6 place-items-center rounded-full bg-white/85 text-black"><Zap className="h-3.5 w-3.5" /></span>}
          title="Impacté"
          text="Les rôles que votre choix éclaire et met en mouvement."
        />
        <LegendRow
          badge={<span className="grid h-6 w-6 place-items-center rounded-full bg-accent text-accent-foreground"><Lock className="h-3.5 w-3.5" /></span>}
          title="Secret · créneau réservé"
          text="Les surprises : leur place est gardée, leur contenu reste caché."
        />
      </div>

      <div className="mt-8 flex justify-end">
        <button
          type="button"
          onClick={onContinue}
          className="inline-flex items-center gap-2 rounded-full bg-white px-6 py-2.5 text-[13px] font-semibold text-black transition hover:scale-[1.02]"
        >
          Continuer <ArrowRight className="h-3.5 w-3.5" />
        </button>
      </div>
    </div>
  );
}

function LegendRow({ badge, title, text }) {
  return (
    <div className="flex items-start gap-3">
      {badge}
      <div>
        <p className="text-[13px] font-semibold text-white">{title}</p>
        <p className="text-[12px] leading-5 text-white/45">{text}</p>
      </div>
    </div>
  );
}