import { useEffect } from "react";
import { Outlet, useLocation } from "react-router-dom";
import { applyStoredDesign } from "@/lib/ripple/dsPageStore";
import { applyAdoption } from "@/lib/aimeplus/adoptionApply";
import GlobalHeader from "@/components/nav/GlobalHeader";
import ReseauBottomCapsule from "@/components/reseau/ReseauBottomCapsule";
import SkipLink from "./a11y/SkipLink";
import ScrollToTop from "./ScrollToTop";
import { GuideProvider } from "@/lib/guide/GuideContext";
import { JourneyChromeProvider } from "@/lib/home/journeyChrome";
import { PlumeProvider } from "@/components/plume/PlumeProvider";
import AccessibilityPreferencesSync from "@/components/settings/AccessibilityPreferencesSync";
import RadioProvider from "@/components/radio/RadioProvider";

export default function Layout() {
  const { pathname } = useLocation();
  // Ré-applique le design system personnalisé (page /design-system) à tout le site.
  useEffect(() => { applyStoredDesign(); applyAdoption(); }, []);
  // Landing et verticales immersives : le hero passe sous le header transparent.
  const immersive = pathname === "/";
  const passportPreview = pathname.startsWith("/passeport/");
  const fullScreen = pathname === "/reseau";
  return (
    <GuideProvider>
      <JourneyChromeProvider>
        <PlumeProvider>
          <RadioProvider>
          {/* Le thème est piloté par la bascule jour/nuit (classe .dark sur <html>) —
              plus de mode forcé ici : le site suit réellement le réglage. */}
          <div className="min-h-screen flex flex-col bg-background text-foreground">
            <AccessibilityPreferencesSync />
            <ScrollToTop />
            <SkipLink />
            <GlobalHeader />
            <main
              id="contenu-principal"
              tabIndex={-1}
              className={`flex-1 focus:outline-none safe-area-bottom ${immersive ? "pb-24" : fullScreen ? "pt-16" : "pt-16 pb-24"}`}
            >
              <Outlet />
            </main>
            {!immersive && !fullScreen && !passportPreview && <ReseauBottomCapsule />}
          </div>
          </RadioProvider>
        </PlumeProvider>
      </JourneyChromeProvider>
    </GuideProvider>
  );
}