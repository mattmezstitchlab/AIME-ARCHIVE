import { useState } from "react";

export default function OrchestrationBuilder({ onCreate }) {
  const [date, setDate] = useState("");
  const [lines, setLines] = useState("09:00 · Préparation\n10:00 · Mise en place\n11:00 · Début de l’événement");
  const [message, setMessage] = useState("");
  const submit = async (event) => { event.preventDefault(); setMessage(""); try { await onCreate(date, lines); setMessage("Orchestration programmée."); } catch (error) { setMessage(error.message); } };
  return <form onSubmit={submit} className="mt-3 space-y-3">
    <label className="block text-[10px] font-bold">Date de l’événement<input type="date" required value={date} onChange={(event) => setDate(event.target.value)} className="mt-1 w-full rounded-xl border border-border bg-muted p-3 text-xs" /></label>
    <label className="block text-[10px] font-bold">Timeline précise<textarea required value={lines} onChange={(event) => setLines(event.target.value)} className="mt-1 min-h-32 w-full rounded-xl border border-border bg-muted p-3 font-mono text-[10px]" /></label>
    <button className="w-full rounded-full bg-foreground py-3 text-[10px] font-bold text-background">Programmer l’activation</button>
    <p aria-live="polite" className="text-[9px] font-bold">{message}</p>
  </form>;
}