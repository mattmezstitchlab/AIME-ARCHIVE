const PHASES = { preparation: "bg-sage", circulation: "bg-ink", remise: "bg-accent", retour: "bg-fire", preuve: "bg-primary" };

export default function OrchestrationRail({ steps, selectedId, onSelect }) {
  const starts = steps.map((step) => new Date(step.scheduled_at).getTime());
  const first = Math.min(...starts); const last = Math.max(...steps.map((step) => new Date(step.scheduled_at).getTime() + (step.duration_minutes || 30) * 60000));
  const span = Math.max(1, last - first);
  return <div className="rounded-xl border border-border bg-muted p-3">
    <div className="mb-2 flex justify-between text-[8px] font-bold uppercase tracking-wider text-muted-foreground"><span>Rail du jour</span><span>{new Date(first).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })} — {new Date(last).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}</span></div>
    <div className="relative h-12 overflow-hidden rounded-lg bg-card">{steps.map((step) => { const start = new Date(step.scheduled_at).getTime(); const left = ((start - first) / span) * 100; const width = Math.max(4, ((step.duration_minutes || 30) * 60000 / span) * 100); return <button key={step.id} type="button" onClick={() => onSelect(step.id)} title={step.label} className={`absolute bottom-2 top-2 overflow-hidden rounded-md px-1 text-left text-[8px] font-bold text-primary-foreground ${PHASES[step.phase] || "bg-primary"} ${selectedId === step.id ? "ring-2 ring-foreground" : ""}`} style={{ left: `${left}%`, width: `${width}%` }}><span className="block truncate">{step.label}</span></button>; })}</div>
  </div>;
}