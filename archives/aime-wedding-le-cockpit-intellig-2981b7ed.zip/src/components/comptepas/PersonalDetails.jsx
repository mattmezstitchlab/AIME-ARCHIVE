import { BriefcaseBusiness, Languages, MapPin } from "lucide-react";

export default function PersonalDetails({ identity }) {
  const age = identity.birth_year ? new Date().getFullYear() - identity.birth_year : null;
  const entries = [age && `${age} ans · né(e) en ${identity.birth_year}`, identity.city, identity.profession, identity.country_code, identity.preferred_language?.toUpperCase()].filter(Boolean);
  if (!entries.length) return <p className="mt-4 rounded-xl border border-dashed border-border p-3 text-[9px] text-muted-foreground">Complétez votre année de naissance, votre ville et votre métier.</p>;
  return <div className="mt-4 grid grid-cols-2 gap-2 text-[9px]">
    {age && <p className="rounded-lg bg-card p-2 font-bold">{age} ans <span className="font-normal text-muted-foreground">· {identity.birth_year}</span></p>}
    {identity.city && <p className="flex items-center gap-1 rounded-lg bg-card p-2"><MapPin className="h-3 w-3 text-accent" />{identity.city}</p>}
    {identity.profession && <p className="flex items-center gap-1 rounded-lg bg-card p-2"><BriefcaseBusiness className="h-3 w-3 text-accent" />{identity.profession}</p>}
    {(identity.country_code || identity.preferred_language) && <p className="flex items-center gap-1 rounded-lg bg-card p-2"><Languages className="h-3 w-3 text-accent" />{identity.country_code || "—"} · {identity.preferred_language?.toUpperCase() || "FR"}</p>}
  </div>;
}