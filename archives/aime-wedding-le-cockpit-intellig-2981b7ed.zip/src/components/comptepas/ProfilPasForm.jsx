import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { invalidateProfilPas } from "@/lib/pas/profil";
import VilleGeoInput from "@/components/parcours/VilleGeoInput";
import { Camera, Check } from "lucide-react";

// LE PROFIL — pseudo, photo optionnelle, zone habituelle. Rien de plus, par ADN.
export default function ProfilPasForm({ me }) {
  const [f, setF] = useState({
    pas_pseudo: me.pas_pseudo || "",
    pas_photo_url: me.pas_photo_url || "",
    pas_zone: me.pas_zone || "",
  });
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const photo = async (file) => {
    if (!file) return;
    setUploading(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setF((p) => ({ ...p, pas_photo_url: file_url }));
    setUploading(false);
  };

  const save = async (e) => {
    e.preventDefault();
    setSaving(true);
    await base44.auth.updateMe(f);
    invalidateProfilPas();
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  return (
    <form onSubmit={save} className="rounded-2xl border border-white/15 bg-[#141414] p-6">
      <div className="flex items-center gap-4">
        <label className="relative flex h-20 w-20 shrink-0 cursor-pointer items-center justify-center overflow-hidden rounded-full border-2 border-dashed border-white/25 transition hover:border-accent">
          {f.pas_photo_url ? (
            <img src={f.pas_photo_url} alt="Photo de profil" className="h-full w-full object-cover" />
          ) : (
            <Camera className="h-6 w-6 text-white/40" aria-hidden="true" />
          )}
          <input type="file" accept="image/*" className="hidden"
            onChange={(e) => { photo(e.target.files[0]); e.target.value = ""; }} />
        </label>
        <div>
          <p className="text-[14px] font-bold">{me.full_name || me.email}</p>
          <p className="text-[11px] text-white/50">{uploading ? "Envoi de la photo…" : "Photo optionnelle — cliquez pour changer."}</p>
        </div>
      </div>

      <div className="mt-5 grid gap-4 sm:grid-cols-2">
        <div>
          <label className="text-[12px] font-bold">Pseudo (affiché dans le réseau)</label>
          <input value={f.pas_pseudo} onChange={(e) => setF((p) => ({ ...p, pas_pseudo: e.target.value }))}
            placeholder="Un prénom ou des initiales"
            className="mt-1 flex min-h-[46px] w-full rounded-xl border border-white/15 bg-[#0D0D0D] px-4 text-[13px] outline-none" />
        </div>
        <div>
          <label className="text-[12px] font-bold">Zone habituelle (jamais d'adresse précise)</label>
          <VilleGeoInput value={f.pas_zone} onChange={(v) => setF((p) => ({ ...p, pas_zone: v }))} placeholder="Lille, Arras…" />
        </div>
      </div>

      <button type="submit" disabled={saving}
        className="mt-5 flex min-h-[42px] items-center gap-2 rounded-full bg-accent px-6 text-[13px] font-bold text-black transition hover:opacity-85 disabled:opacity-40">
        {saved ? <><Check className="h-4 w-4" /> Enregistré</> : saving ? "Enregistrement…" : "Enregistrer mon profil"}
      </button>
      <p className="mt-3 text-[11px] text-white/45">Ces informations pré-remplissent vos formulaires de don, besoin et relais.</p>
    </form>
  );
}