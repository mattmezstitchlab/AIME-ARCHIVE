import { useEffect, useState } from "react";

export default function OrchestrationStepEditor({ step, onSave }) {
  const [form, setForm] = useState(step);
  useEffect(() => setForm(step), [step]);
  const field = (key, value) => setForm((current) => ({ ...current, [key]: value }));
  const submit = (event) => { event.preventDefault(); onSave(step.id, form); };
  return <form onSubmit={submit} className="mt-3 space-y-2 rounded-xl border border-border bg-muted p-3">
    <div className="grid grid-cols-2 gap-2"><label className="text-[9px] font-bold">Moment<input value={form.label} onChange={(event) => field("label", event.target.value)} className="mt-1 w-full rounded-lg border border-border bg-card p-2 text-[10px]" /></label><label className="text-[9px] font-bold">Durée<input type="number" min="5" value={form.duration_minutes || 30} onChange={(event) => field("duration_minutes", Number(event.target.value))} className="mt-1 w-full rounded-lg border border-border bg-card p-2 text-[10px]" /></label></div>
    <div className="grid grid-cols-2 gap-2"><label className="text-[9px] font-bold">Phase<select value={form.phase || "preparation"} onChange={(event) => field("phase", event.target.value)} className="mt-1 w-full rounded-lg border border-border bg-card p-2 text-[10px]"><option value="preparation">Préparation</option><option value="circulation">Circulation</option><option value="remise">Remise</option><option value="retour">Retour</option><option value="preuve">Preuve</option></select></label><label className="text-[9px] font-bold">Lieu<input value={form.location_label || ""} onChange={(event) => field("location_label", event.target.value)} className="mt-1 w-full rounded-lg border border-border bg-card p-2 text-[10px]" /></label></div>
    <label className="block text-[9px] font-bold">Responsable<input value={form.owner_label || ""} onChange={(event) => field("owner_label", event.target.value)} className="mt-1 w-full rounded-lg border border-border bg-card p-2 text-[10px]" /></label>
    <label className="block text-[9px] font-bold">Détails<textarea value={form.details || ""} onChange={(event) => field("details", event.target.value)} className="mt-1 min-h-16 w-full rounded-lg border border-border bg-card p-2 text-[10px]" /></label>
    <label className="flex items-center gap-2 text-[9px] font-bold"><input type="checkbox" checked={form.proof_required || false} onChange={(event) => field("proof_required", event.target.checked)} />Preuve obligatoire</label>
    <button className="w-full rounded-full bg-foreground py-2 text-[9px] font-bold text-background">Enregistrer le moment</button>
  </form>;
}