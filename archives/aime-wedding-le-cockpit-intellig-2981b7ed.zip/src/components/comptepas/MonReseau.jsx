import { useState } from "react";
import { Activity, BookOpen, Pin } from "lucide-react";
import MesPasseports from "./MesPasseports";
import MesFavorisPasseports from "./MesFavorisPasseports";
import MesActivites from "./MesActivites";

const TABS = [{ id: "passeports", label: "Passeports", icon: BookOpen }, { id: "favoris", label: "Favoris", icon: Pin }, { id: "activites", label: "Activités", icon: Activity }];
export default function MonReseau({ me }) {
  const [tab, setTab] = useState("passeports");
  return <div><div role="tablist" aria-label="Mon réseau" className="mb-4 grid grid-cols-3 gap-1 rounded-2xl bg-muted p-1">{TABS.map(({ id, label, icon: Icon }) => <button key={id} type="button" role="tab" aria-selected={tab === id} onClick={() => setTab(id)} className={`flex min-h-11 items-center justify-center gap-1 rounded-xl text-[9px] font-bold ${tab === id ? "bg-card shadow-sm" : "text-muted-foreground"}`}><Icon className="h-3.5 w-3.5" />{label}</button>)}</div>{tab === "passeports" ? <MesPasseports me={me} /> : tab === "favoris" ? <MesFavorisPasseports me={me} /> : <MesActivites me={me} />}</div>;
}