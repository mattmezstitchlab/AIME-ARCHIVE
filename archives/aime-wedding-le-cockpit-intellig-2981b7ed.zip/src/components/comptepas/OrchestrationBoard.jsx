import { useState } from "react";
import { DragDropContext, Droppable } from "@hello-pangea/dnd";
import OrchestrationRail from "./OrchestrationRail";
import OrchestrationStepCard from "./OrchestrationStepCard";
import OrchestrationStepEditor from "./OrchestrationStepEditor";

export default function OrchestrationBoard({ record, onReorder, onUpdate, onComplete }) {
  const [selectedId, setSelectedId] = useState(record.timeline_steps[0]?.id);
  const selected = record.timeline_steps.find((step) => step.id === selectedId);
  const dragEnd = ({ source, destination }) => { if (destination && source.index !== destination.index) onReorder(source.index, destination.index); };
  return <div className="mt-3 space-y-3">
    <OrchestrationRail steps={record.timeline_steps} selectedId={selectedId} onSelect={setSelectedId} />
    <DragDropContext onDragEnd={dragEnd}><Droppable droppableId="orchestration-steps">{(provided) => <div ref={provided.innerRef} {...provided.droppableProps} className="space-y-2">{record.timeline_steps.map((step, index) => <OrchestrationStepCard key={step.id} step={step} index={index} selected={step.id === selectedId} onSelect={setSelectedId} onComplete={onComplete} />)}{provided.placeholder}</div>}</Droppable></DragDropContext>
    {selected && <OrchestrationStepEditor step={selected} onSave={onUpdate} />}
  </div>;
}