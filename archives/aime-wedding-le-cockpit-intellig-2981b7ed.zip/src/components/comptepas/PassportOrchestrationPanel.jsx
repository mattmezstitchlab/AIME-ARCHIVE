import { ArrowLeft, Clock3 } from "lucide-react";
import usePassportOrchestration from "./usePassportOrchestration";
import OrchestrationBuilder from "./OrchestrationBuilder";
import OrchestrationBoard from "./OrchestrationBoard";

export default function PassportOrchestrationPanel({ project, onClose }) {
  const orchestration = usePassportOrchestration(project);
  return <div><button type="button" onClick={onClose} className="mb-3 flex items-center gap-1 text-[10px] font-bold"><ArrowLeft className="h-3.5 w-3.5" />{project.title}</button><div className="rounded-2xl border border-border bg-muted p-4"><Clock3 className="h-5 w-5 text-accent" /><h3 className="mt-2 text-sm font-extrabold">Orchestration Cerise</h3><p className="mt-1 text-[10px] text-muted-foreground">Rail horaire, moments détaillés et preuves obligatoires synchronisent tous les passeports reliés.</p></div>{orchestration.loading ? <p className="py-10 text-center text-[10px] text-muted-foreground">Chargement de la timeline…</p> : orchestration.record ? <OrchestrationBoard record={orchestration.record} onReorder={orchestration.reorder} onUpdate={orchestration.updateStep} onComplete={orchestration.complete} /> : <OrchestrationBuilder onCreate={orchestration.create} />}</div>;
}