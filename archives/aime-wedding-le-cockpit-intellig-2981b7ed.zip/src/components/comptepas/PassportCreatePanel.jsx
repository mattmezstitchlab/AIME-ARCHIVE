import { ArrowLeft } from "lucide-react";
import DonnerForm from "@/components/parcours/DonnerForm";
import BesoinForm from "@/components/parcours/BesoinForm";
import UniversalPassportForm from "@/components/comptepas/UniversalPassportForm";
import EvenementForm from "@/components/evenements/EvenementForm";

export default function PassportCreatePanel({ project, kind, onCreated, onClose }) {
  const label = kind === "don" ? "DONNER" : kind === "besoin" ? "RECEVOIR" : kind === "evenement" ? "ÉVÉNEMENTIEL" : "UNIVERSEL";
  const eventCreated = (item) => onCreated({ kind: "evenement", item, passport: { reference: `EVT-${String(item.id).slice(-6).toUpperCase()}` } });
  return <div><button type="button" onClick={onClose} className="mb-3 flex items-center gap-1 text-[10px] font-bold"><ArrowLeft className="h-3.5 w-3.5" />{project.title}</button><p className="mb-3 text-[9px] font-bold uppercase tracking-[0.18em] text-muted-foreground">Nouveau passeport {label}</p>{kind === "don" ? <DonnerForm onCreated={onCreated} /> : kind === "besoin" ? <BesoinForm onCreated={onCreated} /> : kind === "evenement" ? <EvenementForm initialValues={{ title: project.title, event_type: project.project_type === "mariage" ? "mariage" : "autre" }} onCreated={eventCreated} /> : <UniversalPassportForm onCreated={onCreated} />}</div>;
}