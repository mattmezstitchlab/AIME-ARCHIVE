import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { getCategorie } from "@/lib/pas/categories";
import { Footprints, Truck, Flag } from "lucide-react";

// MES ACTIVITÉS — mes dons, mes relais, mes dossards, regroupés.
export default function MesActivites({ me, type }) {
  const [data, setData] = useState(null);

  useEffect(() => {
    (async () => {
      const pseudo = me.pas_pseudo;
      const [dons, relais, events] = await Promise.all([
        base44.entities.ShoePair.filter({ created_by_id: me.id }, "-created_date", 50),
        base44.entities.RelayOffer.filter({ created_by_id: me.id }, "-created_date", 50),
        base44.entities.SolidarityEvent.list("-created_date", 100),
      ]);
      const dossards = events.flatMap((ev) =>
        (ev.participants || [])
          .filter((p) => pseudo && p.name === pseudo)
          .map((p) => ({ id: `${ev.id}-${p.dossard}`, event: ev.title, dossard: p.dossard, date: ev.event_date }))
      );
      setData({ dons, relais, dossards });
    })();
  }, [me]);

  if (data === null) return <p className="py-10 text-center text-[13px] text-muted-foreground">Chargement de vos activités…</p>;

  const bloc = (Icon, titre, items, vide, lien, lienLabel) => (
    <section className="rounded-2xl border border-border bg-card p-4">
      <p className="flex items-center gap-2 text-[13px] font-extrabold text-card-foreground">
        <Icon className="h-4 w-4 text-accent" aria-hidden="true" /> {titre}
        <span className="rounded-full bg-muted px-2 py-0.5 text-[10px] text-muted-foreground">{items.length}</span>
      </p>
      {items.length === 0 ? (
        <p className="mt-2 text-[12px] text-muted-foreground">{vide} <Link to={lien} className="font-semibold text-foreground underline underline-offset-2">{lienLabel}</Link></p>
      ) : (
        <div className="mt-3 space-y-2">
          {items.map((it) => (
            <div key={it.id} className="rounded-xl border border-border bg-muted/50 px-4 py-3">
              <p className="text-[12px] font-bold text-foreground">{it.titre}</p>
              <p className="mt-0.5 text-[11px] text-muted-foreground">{it.sous}</p>
            </div>
          ))}
        </div>
      )}
    </section>
  );

  const dons = data.dons.map((p) => {
    const cat = getCategorie(p.category || "chaussures");
    return { id: p.id, titre: `${cat.label}${p.shoe_size ? ` · Pointure ${p.shoe_size}` : p.size_label ? ` · Taille ${p.size_label}` : ""}`, sous: `${p.city_zone} · statut : ${p.status}` };
  });
  const relais = data.relais.map((r) => ({ id: r.id, titre: `${r.departure_zone} → ${r.arrival_zone}`, sous: `${r.transport_mode} · ${r.travel_date || "date libre"} · ${r.status}` }));
  const dossards = data.dossards.map((d) => ({ id: d.id, titre: `Dossard N° ${d.dossard}`, sous: `${d.event}${d.date ? ` · ${d.date}` : ""}` }));

  const sections = {
    dons: bloc(Footprints, "Mes dons", dons, "Aucun don pour le moment.", "/reseau?mode=donner", "Donner un objet"),
    relais: bloc(Truck, "Mes relais", relais, "Aucun relais proposé.", "/reseau?mode=relayer", "Proposer un trajet"),
    dossards: bloc(Flag, "Mes dossards", dossards, "Aucune inscription trouvée avec votre pseudo.", "/evenements", "Voir les marches"),
  };

  return <div className="space-y-4">{type ? sections[type] : Object.values(sections)}</div>;
}