import { useCallback, useEffect, useMemo, useState } from "react";
import { base44 } from "@/api/base44Client";

const scoreMatch = (source, target) => {
  let score = source.category === target.category ? 60 : 0;
  if (source.shoe_size && source.shoe_size === target.shoe_size) score += 25;
  if (source.size_label && source.size_label === target.size_label) score += 25;
  if ((source.city_zone || source.zone_approx) === (target.city_zone || target.zone_approx)) score += 15;
  return score;
};
export default function usePassportLinks(me, project, items) {
  const [state, setState] = useState({ links: [], candidates: [], loading: true });
  const load = useCallback(async () => { const [links, pairs, needs] = await Promise.all([base44.entities.PassportLink.filter({ project_id: project.id }, "-created_date", 100), base44.entities.ShoePair.filter({ status: "disponible" }, "-created_date", 100), base44.entities.ShoeNeed.filter({ status: "propositions" }, "-created_date", 100)]); setState({ links, candidates: [...pairs.map((item) => ({ kind: "don", item })), ...needs.map((item) => ({ kind: "besoin", item }))], loading: false }); }, [project.id]);
  useEffect(() => { load(); }, [load]);
  const suggestions = useMemo(() => items.flatMap((source) => state.candidates.filter((target) => target.kind !== source.kind && target.item.created_by_id !== me.id).map((target) => ({ source, target, score: scoreMatch(source.item, target.item) })).filter((match) => match.score >= 60)).sort((a, b) => b.score - a.score).slice(0, 8), [items, me.id, state.candidates]);
  const request = async ({ source, target, score }) => { const link = await base44.entities.PassportLink.create({ project_id: project.id, from_kind: source.kind, from_id: source.item.id, to_kind: target.kind, to_id: target.item.id, link_type: "matching_intelligent", status: "en_attente", score, reason: `Compatibilité ${source.item.category || "objet"} détectée par le projet ${project.title}.`, recipient_id: target.item.created_by_id }); if (target.item.created_by_id) await base44.entities.PasNotification.create({ recipient_id: target.item.created_by_id, pair_id: target.kind === "don" ? target.item.id : source.item.id, type: "match_trouve", message: `Le projet « ${project.title} » propose de relier un passeport au vôtre.`, read: false }); await load(); return link; };
  const connectCode = async (code) => { const source = items[0]; if (!source) throw new Error("Ajoutez d’abord un passeport au projet."); const found = await base44.entities.PassportMembership.filter({ passport_code: code.trim() }, "-created_date", 1); const target = found[0]; const externalId = `external-${code.trim().toLowerCase().replace(/[^a-z0-9]+/g, "-")}`; await base44.entities.PassportLink.create({ project_id: project.id, from_kind: source.kind, from_id: source.item.id, to_kind: target?.object_kind || "externe", to_id: target?.object_id || externalId, to_code: code.trim(), link_type: target ? "projet" : "externe", status: target ? "en_attente" : "confirme", score: target ? 100 : 0, reason: target ? `Invitation par code au projet ${project.title}.` : `Référence extérieure reliée au projet ${project.title}.`, recipient_id: target?.created_by_id || "" }); if (target?.created_by_id) await base44.entities.PasNotification.create({ recipient_id: target.created_by_id, type: "match_trouve", message: `Le projet « ${project.title} » vous invite par votre code passeport.`, read: false }); await load(); };
  return { ...state, suggestions, request, connectCode };
}