import { CalendarDays } from "lucide-react";
import { getCategorie } from "@/lib/pas/categories";
import { mapPassportVisual } from "@/lib/passport/mapPassportVisual";

const formatDate = (value) => value ? new Intl.DateTimeFormat("fr-FR", { day: "2-digit", month: "short", year: "numeric" }).format(new Date(value)) : "Date non renseignée";
const clean = (value) => String(value || "actif").replaceAll("_", " ");
export default function PassportListLabel({ kind, item, onOpen }) {
  const visual = mapPassportVisual(kind, item);
  const title = kind === "evenement" || kind === "universel" ? item.title : getCategorie(item.category || "autre").label;
  const date = formatDate(item.event_date || item.created_date);
  return <button type="button" onClick={() => onOpen({ kind, item })} className="flex min-h-14 w-full items-center gap-3 rounded-xl border border-border bg-muted/50 p-2 text-left hover:bg-muted">
    <img src={visual.image_url} alt="" className="h-11 w-11 shrink-0 rounded-lg object-cover" />
    <span className="min-w-0 flex-1"><strong className="block truncate text-[11px]">{title}</strong><small className="mt-1 flex items-center gap-1 text-[9px] text-muted-foreground"><CalendarDays className="h-3 w-3" />{date}</small></span>
    <span className="max-w-20 rounded-full bg-card px-2 py-1 text-center text-[7px] font-bold uppercase tracking-wide text-muted-foreground">{clean(item.status)}</span>
  </button>;
}