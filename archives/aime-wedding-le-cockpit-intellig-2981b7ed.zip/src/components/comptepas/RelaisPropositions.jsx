import { useEffect, useState } from "react";
import { Truck } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { CATEGORIES } from "@/lib/pas/categories";
import { getProfilPas, getMonAdressePlus } from "@/lib/pas/profil";

// LES PROPOSITIONS DE RELAIS — les dons proposés sur mes trajets :
// j'accepte (le segment devient réel) ou je refuse (le don reste dans le réseau).
export default function RelaisPropositions({ me }) {
  const [propositions, setPropositions] = useState(null);

  useEffect(() => {
    (async () => {
      const offres = await base44.entities.RelayOffer.filter({ created_by_id: me.id });
      if (offres.length === 0) { setPropositions([]); return; }
      const ids = offres.map((o) => o.id);
      const legs = (await base44.entities.RelayLeg.filter({ status: "propose" }))
        .filter((l) => ids.includes(l.relay_offer_id));
      const pairs = await Promise.all(legs.map((l) => base44.entities.ShoePair.get(l.pair_id).catch(() => null)));
      setPropositions(legs.map((l, i) => ({ leg: l, pair: pairs[i] })).filter((p) => p.pair));
    })();
  }, [me]);

  const repondre = async ({ leg, pair }, accepte) => {
    setPropositions((v) => v.filter((p) => p.leg.id !== leg.id));
    await base44.entities.RelayLeg.update(leg.id, { status: accepte ? "accepte" : "annule" });
    if (accepte) {
      await base44.entities.ShoePair.update(pair.id, { status: "en_relais" });
      // Le relayeur signe le passeport avec sa vraie page « + » : la chaîne devient navigable.
      if (pair.passport_id) {
        const pp = await base44.entities.PairPassport.get(pair.passport_id).catch(() => null);
        if (pp) {
          const prof = await getProfilPas();
          const plus = await getMonAdressePlus();
          await base44.entities.PairPassport.update(pp.id, {
            history: [...(pp.history || []), {
              step: "en_relais", zone: leg.from_zone, date: new Date().toISOString(),
              actor_pseudo: prof?.pseudo || "Relayeur", actor_plus: plus || "",
              note: `Relais accepté : ${leg.from_zone} → ${leg.to_zone}.`,
            }],
            current_step: "en_relais",
          });
        }
      }
      await base44.entities.PasNotification.create({
        recipient_id: pair.created_by_id,
        pair_id: pair.id,
        type: "relais_accepte",
        message: `Bonne nouvelle : votre don embarque sur le trajet ${leg.from_zone} → ${leg.to_zone}.`,
      });
      // La capacité de l'offre se décompte : pleine, elle passe en « assigné ».
      const offre = await base44.entities.RelayOffer.get(leg.relay_offer_id).catch(() => null);
      if (offre) {
        const acceptes = await base44.entities.RelayLeg.filter({ relay_offer_id: offre.id, status: "accepte" });
        if (acceptes.length >= (offre.capacity || 1)) {
          await base44.entities.RelayOffer.update(offre.id, { status: "assigne" });
        }
      }
      // Le relais accepté répare la chaîne : les incidents ouverts de ce don se ferment.
      const [incidents, legsDuDon] = await Promise.all([
        base44.entities.LogisticsIncident.filter({ status: "ouvert" }),
        base44.entities.RelayLeg.filter({ pair_id: pair.id }),
      ]);
      const legIds = legsDuDon.map((l) => l.id);
      const touches = incidents.filter((i) => i.pair_id === pair.id || legIds.includes(i.leg_id));
      await Promise.all(touches.map((i) => base44.entities.LogisticsIncident.update(i.id, {
        status: "resolu",
        resolution: `Segment repris par un relais accepté (${leg.from_zone} → ${leg.to_zone}).`,
      })));
    }
  };

  if (!propositions || propositions.length === 0) return null;

  const catLabel = (p) => CATEGORIES.find((c) => c.key === p.category)?.label || p.category;

  return (
    <section className="mt-8">
      <h2 className="flex items-center gap-2 text-[15px] font-extrabold">
        <Truck className="h-4 w-4 text-[#F2B90D]" aria-hidden="true" /> Dons proposés sur mes trajets
      </h2>
      <ul className="mt-3 space-y-2">
        {propositions.map((p) => (
          <li key={p.leg.id} className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-white/15 bg-[#141414] p-4">
            <div>
              <p className="text-[13px] font-bold">{catLabel(p.pair)} · {p.pair.city_zone}</p>
              <p className="mt-0.5 text-[12px] text-white/50">Segment : {p.leg.from_zone} → {p.leg.to_zone}{p.leg.leg_date ? ` · ${p.leg.leg_date}` : ""}</p>
            </div>
            <div className="flex gap-2">
              <button onClick={() => repondre(p, true)}
                className="flex min-h-[36px] items-center rounded-full bg-[#F2B90D] px-4 text-[12px] font-bold text-black transition hover:opacity-85">
                Accepter
              </button>
              <button onClick={() => repondre(p, false)}
                className="flex min-h-[36px] items-center rounded-full border border-white/25 px-4 text-[12px] font-bold text-white/70 transition hover:border-white/60">
                Refuser
              </button>
            </div>
          </li>
        ))}
      </ul>
    </section>
  );
}