import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Check, Link2, X } from "lucide-react";

export default function PassportLinkInbox({ me }) {
  const [links, setLinks] = useState([]);
  const load = () => base44.entities.PassportLink.filter({ recipient_id: me.id, status: "en_attente" }, "-created_date", 30).then(setLinks);
  useEffect(() => { load(); }, [me.id]);
  const decide = async (link, status) => { await base44.entities.PassportLink.update(link.id, { status }); if (link.created_by_id) await base44.entities.PasNotification.create({ recipient_id: link.created_by_id, pair_id: link.to_kind === "don" ? link.to_id : link.from_id, type: status === "confirme" ? "match_trouve" : "rappel", message: status === "confirme" ? "Votre proposition de liaison a été confirmée." : "Votre proposition de liaison a été refusée.", read: false }); await load(); };
  if (!links.length) return null;
  return <section className="rounded-2xl border border-accent/50 bg-muted p-4"><div className="flex items-center gap-2"><Link2 className="h-4 w-4 text-accent" /><p className="text-[10px] font-bold uppercase tracking-[0.14em]">Liaisons à confirmer</p></div><div className="mt-3 space-y-2">{links.map((link) => <div key={link.id} className="flex items-center gap-2 rounded-xl bg-card p-3"><p className="flex-1 text-[10px]">{link.reason || "Un passeport souhaite se relier au vôtre."}</p><button onClick={() => decide(link, "confirme")} aria-label="Confirmer" className="flex h-8 w-8 items-center justify-center rounded-full bg-foreground text-background"><Check className="h-3.5 w-3.5" /></button><button onClick={() => decide(link, "refuse")} aria-label="Refuser" className="flex h-8 w-8 items-center justify-center rounded-full border border-border"><X className="h-3.5 w-3.5" /></button></div>)}</div></section>;
}