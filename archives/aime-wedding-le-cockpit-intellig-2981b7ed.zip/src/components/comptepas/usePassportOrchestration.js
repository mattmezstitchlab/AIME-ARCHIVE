import { useCallback, useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";

export default function usePassportOrchestration(project) {
  const [record, setRecord] = useState(null);
  const [loading, setLoading] = useState(true);
  const load = useCallback(async () => {
    const rows = await base44.entities.PassportOrchestration.filter({ project_id: project.id }, "-created_date", 1);
    setRecord(rows[0] || null); setLoading(false);
  }, [project.id]);
  useEffect(() => { load(); }, [load]);
  const create = async (date, lines) => {
    const steps = lines.split("\n").map((line) => {
      const match = line.match(/^(\d{2}:\d{2})\s*[·-]\s*(.+)$/);
      return match ? { id: crypto.randomUUID(), label: match[2], scheduled_at: new Date(`${date}T${match[1]}:00`).toISOString(), duration_minutes: 30, phase: "preparation", status: "a_venir", reminder_minutes: 30 } : null;
    }).filter(Boolean);
    if (!steps.length) throw new Error("Utilisez le format 09:00 · Étape.");
    await base44.entities.PassportOrchestration.create({ project_id: project.id, title: project.title, activation_at: steps[0].scheduled_at, timezone: "Europe/Paris", status: "programmee", cerise_notifications: true, late_threshold_minutes: 10, timeline_steps: steps });
    await load();
  };
  const save = async (steps, status = record.status) => { await base44.entities.PassportOrchestration.update(record.id, { timeline_steps: steps, status }); await load(); };
  const reorder = async (from, to) => { const steps = [...record.timeline_steps]; const [moved] = steps.splice(from, 1); steps.splice(to, 0, moved); await save(steps); };
  const updateStep = (id, patch) => save(record.timeline_steps.map((step) => step.id === id ? { ...step, ...patch } : step));
  const complete = (id) => { const steps = record.timeline_steps.map((step) => step.id === id ? { ...step, status: "terminee" } : step); return save(steps, steps.every((step) => step.status === "terminee") ? "terminee" : record.status); };
  return { record, loading, create, reorder, updateStep, complete };
}