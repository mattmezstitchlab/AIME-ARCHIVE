import { useEffect, useState } from "react";
import { Bell } from "lucide-react";
import { base44 } from "@/api/base44Client";

// MES NOTIFICATIONS — le réseau qui vous parle : relais proposés, dons acceptés, arrivées.
export default function MesNotifications({ me }) {
  const [notifs, setNotifs] = useState(null);

  useEffect(() => {
    base44.entities.PasNotification.filter({ recipient_id: me.id }, "-created_date", 20).then(setNotifs);
  }, [me]);

  const marquerLu = async (n) => {
    setNotifs((v) => v.map((x) => (x.id === n.id ? { ...x, read: true } : x)));
    await base44.entities.PasNotification.update(n.id, { read: true });
  };

  if (!notifs || notifs.length === 0) return null;

  return (
    <section className="mt-8">
      <h2 className="flex items-center gap-2 text-[15px] font-extrabold">
        <Bell className="h-4 w-4 text-[#F2B90D]" aria-hidden="true" /> Notifications
        {notifs.some((n) => !n.read) && (
          <span className="rounded-full bg-[#F2B90D] px-2 py-0.5 text-[10px] font-bold text-black">
            {notifs.filter((n) => !n.read).length}
          </span>
        )}
      </h2>
      <ul className="mt-3 space-y-2">
        {notifs.map((n) => (
          <li key={n.id}
            className={`flex items-start justify-between gap-3 rounded-xl border p-3 ${n.read ? "border-white/10 bg-black/20 text-white/45" : "border-[#F2B90D]/40 bg-[#141414]"}`}>
            <p className="text-[12px] leading-5">{n.message}</p>
            {!n.read && (
              <button onClick={() => marquerLu(n)}
                className="shrink-0 text-[11px] font-bold text-[#F2B90D] transition hover:text-white">
                Lu
              </button>
            )}
          </li>
        ))}
      </ul>
    </section>
  );
}