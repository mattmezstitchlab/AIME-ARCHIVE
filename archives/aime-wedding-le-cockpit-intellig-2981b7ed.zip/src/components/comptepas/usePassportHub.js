import { useCallback, useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";

export default function usePassportHub(me) {
  const [data, setData] = useState(null);
  const load = useCallback(async () => {
    const [pairs, needs, universal, events, projects, memberships, identityResult] = await Promise.all([
      base44.entities.ShoePair.filter({ created_by_id: me.id }, "-created_date", 100),
      base44.entities.ShoeNeed.filter({ created_by_id: me.id }, "-created_date", 100),
      base44.entities.UniversalPassport.filter({ created_by_id: me.id }, "-created_date", 100),
      base44.entities.SolidarityEvent.filter({ created_by_id: me.id }, "-created_date", 100),
      base44.entities.PassportProject.filter({ created_by_id: me.id, status: "active" }, "-created_date", 50),
      base44.entities.PassportMembership.filter({ created_by_id: me.id, status: "active" }, "-created_date", 200),
      base44.functions.invoke("aimeIdentity", { action: "get" }).catch(() => ({ data: {} })),
    ]);
    setData({ projects, memberships, identity: identityResult.data?.identity || null, items: [...pairs.map((item) => ({ kind: "don", item })), ...needs.map((item) => ({ kind: "besoin", item })), ...universal.map((item) => ({ kind: "universel", item })), ...events.map((item) => ({ kind: "evenement", item }))] });
  }, [me.id]);
  useEffect(() => { load(); }, [load]);
  const attach = async (projectId, payload) => { await base44.entities.PassportMembership.create({ project_id: projectId, mother_identity_id: data?.identity?.id || "", object_kind: payload.kind, object_id: payload.item.id, passport_code: payload.passport?.reference || payload.item.code || payload.item.short_code || "", title: payload.item.title || payload.item.description || payload.kind, role: payload.kind === "besoin" ? "besoin" : payload.kind === "evenement" ? "element" : payload.kind === "universel" ? "element" : "ressource", status: "active" }); await load(); };
  const createIdentity = async () => { const response = await base44.functions.invoke("aimeIdentity", { action: "generate", display_name: me.full_name, universe: "Passeports" }); const identity = response.data.identity; if (!identity.is_mother_passport || identity.device_only) await base44.entities.AimeIdentity.update(identity.id, { is_mother_passport: true, device_only: false, visibility: identity.visibility || "prive" }); await load(); return identity; };
  return { data, load, attach, createIdentity };
}