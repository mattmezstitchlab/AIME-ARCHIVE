import { useEffect, useState } from "react";
import { PinOff } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function MesFavorisPasseports({ me }) {
  const [items, setItems] = useState(null);
  useEffect(() => { base44.entities.PassportFavorite.filter({ created_by_id: me.id }, "-created_date", 100).then(setItems); }, [me.id]);
  const remove = async (id) => { await base44.entities.PassportFavorite.delete(id); setItems((current) => current.filter((item) => item.id !== id)); };
  if (!items) return <p className="py-10 text-center text-xs text-muted-foreground">Chargement des favoris…</p>;
  if (!items.length) return <p className="rounded-2xl border border-dashed border-border p-6 text-center text-xs text-muted-foreground">Épinglez un passeport depuis la carte pour le retrouver ici.</p>;
  return <div className="space-y-2">{items.map((item) => <article key={item.id} className="flex items-center gap-3 rounded-2xl border border-border p-3">{item.image_url && <img src={item.image_url} alt="" className="h-14 w-14 rounded-xl object-cover" />}<div className="min-w-0 flex-1"><p className="truncate text-xs font-extrabold">{item.title}</p><p className="mt-1 text-[9px] uppercase tracking-wider text-muted-foreground">{item.passport_kind || "Passeport"}</p></div><button type="button" onClick={() => remove(item.id)} aria-label={`Retirer ${item.title} des favoris`} title="Retirer des favoris" className="flex h-10 w-10 items-center justify-center rounded-full bg-muted"><PinOff className="h-4 w-4" /></button></article>)}</div>;
}