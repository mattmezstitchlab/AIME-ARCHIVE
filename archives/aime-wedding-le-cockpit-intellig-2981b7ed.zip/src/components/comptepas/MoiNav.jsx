const SECTIONS = [
  { href: "#a-traiter", label: "À traiter" },
  { href: "#passeports", label: "Mes passeports" },
  { href: "#activite", label: "Mon activité" },
  { href: "#profil", label: "Mon profil" },
];

export default function MoiNav() {
  return (
    <nav aria-label="Sections de Moi" className="mt-7 flex gap-2 overflow-x-auto pb-1">
      {SECTIONS.map((item) => <a key={item.href} href={item.href} className="min-h-[42px] shrink-0 rounded-full border border-white/15 px-4 py-3 text-[12px] font-bold text-white/70 transition-colors duration-200 hover:border-[#F2B90D] hover:text-white">{item.label}</a>)}
    </nav>
  );
}