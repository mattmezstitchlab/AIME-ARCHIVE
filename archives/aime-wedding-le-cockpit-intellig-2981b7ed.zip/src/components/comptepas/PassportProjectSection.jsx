import { useState } from "react";
import { ChevronDown, FolderKanban } from "lucide-react";
import PassportProjectActions from "@/components/comptepas/PassportProjectActions";
import PassportListLabel from "@/components/comptepas/PassportListLabel";

export default function PassportProjectSection({ project, items, onOpen, onCreate, onLinks, onOrchestrate }) {
  const [open, setOpen] = useState(true);
  return <section className="rounded-2xl border border-border bg-card"><button type="button" onClick={() => setOpen(!open)} className="flex w-full items-center gap-3 p-4 text-left"><FolderKanban className="h-5 w-5 text-accent" /><span className="flex-1"><strong className="block text-xs">{project?.title || "Sans projet"}</strong><small className="text-muted-foreground">{items.length} passeport{items.length > 1 ? "s" : ""}</small></span><ChevronDown className={`h-4 w-4 transition ${open ? "rotate-180" : ""}`} /></button>{open && <div className="border-t border-border p-3"><div className="space-y-2">{items.map(({ kind, item }) => <PassportListLabel key={`${kind}-${item.id}`} kind={kind} item={item} onOpen={onOpen} />)}</div>{project && <PassportProjectActions project={project} onCreate={onCreate} onLinks={onLinks} onOrchestrate={onOrchestrate} />}</div>}</section>;
}