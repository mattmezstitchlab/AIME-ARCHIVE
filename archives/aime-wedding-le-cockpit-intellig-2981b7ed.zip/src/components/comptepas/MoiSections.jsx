import MesNotifications from "@/components/comptepas/MesNotifications";
import RelaisPropositions from "@/components/comptepas/RelaisPropositions";
import MesPasseports from "@/components/comptepas/MesPasseports";
import MesActivites from "@/components/comptepas/MesActivites";
import ProfilPasForm from "@/components/comptepas/ProfilPasForm";
import AdressePlusForm from "@/components/comptepas/AdressePlusForm";

function Titre({ children }) { return <h2 className="mb-4 text-[18px] font-extrabold">{children}</h2>; }

export default function MoiSections({ me }) {
  return (
    <div className="mt-10 space-y-14">
      <section id="a-traiter" className="scroll-mt-24"><Titre>À traiter</Titre><MesNotifications me={me} /><RelaisPropositions me={me} /></section>
      <section id="passeports" className="scroll-mt-24"><Titre>Mes passeports</Titre><MesPasseports me={me} /></section>
      <section id="activite" className="scroll-mt-24"><Titre>Mon activité</Titre><MesActivites me={me} /></section>
      <section id="profil" className="scroll-mt-24 space-y-6"><Titre>Mon profil</Titre><ProfilPasForm me={me} /><div><h3 className="mb-3 text-[14px] font-extrabold">Ma page +</h3><AdressePlusForm me={me} /></div></section>
    </div>
  );
}