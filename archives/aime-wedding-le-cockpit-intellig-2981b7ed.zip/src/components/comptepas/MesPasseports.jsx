import { useState } from "react";
import { ArrowLeft, Plus } from "lucide-react";
import ObjectPassport from "@/components/reseau/passport/ObjectPassport";
import PassportIdentityCard from "@/components/comptepas/PassportIdentityCard";
import PassportProjectForm from "@/components/comptepas/PassportProjectForm";
import PassportProjectSection from "@/components/comptepas/PassportProjectSection";
import PassportCreatePanel from "@/components/comptepas/PassportCreatePanel";
import usePassportHub from "@/components/comptepas/usePassportHub";
import PassportLinksPanel from "@/components/comptepas/PassportLinksPanel";
import PassportLinkInbox from "@/components/comptepas/PassportLinkInbox";
import PersonalPassport from "@/components/comptepas/PersonalPassport";
import PassportOrchestrationPanel from "@/components/comptepas/PassportOrchestrationPanel";
import EventPassport from "@/components/evenements/passport/EventPassport";

export default function MesPasseports({ me }) {
  const { data, load, attach, createIdentity } = usePassportHub(me);
  const [showProjectForm, setShowProjectForm] = useState(false);
  const [opened, setOpened] = useState(null);
  const [creation, setCreation] = useState(null);
  const [linksProject, setLinksProject] = useState(null);
  const [personalOpen, setPersonalOpen] = useState(false);
  const [orchestrationProject, setOrchestrationProject] = useState(null);
  if (!data) return <p className="py-12 text-center text-[13px] text-muted-foreground">Chargement de vos passeports…</p>;
  if (personalOpen && data.identity) return <PersonalPassport identity={data.identity} projects={data.projects} items={data.items} onBack={() => setPersonalOpen(false)} onSaved={load} />;
  if (opened) return <div><button type="button" onClick={() => setOpened(null)} className="mb-3 flex items-center gap-1 text-[10px] font-bold"><ArrowLeft className="h-3.5 w-3.5" />Mes projets</button>{opened.kind === "evenement" ? <EventPassport event={opened.item} causal={null} onChanged={load} /> : <ObjectPassport target={{ ...opened, causal: null }} />}</div>;
  if (creation) return <PassportCreatePanel project={creation.project} kind={creation.kind} onClose={() => setCreation(null)} onCreated={async (payload) => { await attach(creation.project.id, payload); if (payload.kind === "evenement") { setCreation(null); setOpened(payload); } }} />;
  if (linksProject) return <PassportLinksPanel me={me} project={linksProject} items={data.items.filter((entry) => data.memberships.some((membership) => membership.project_id === linksProject.id && membership.object_kind === entry.kind && membership.object_id === entry.item.id))} onClose={() => setLinksProject(null)} />;
  if (orchestrationProject) return <PassportOrchestrationPanel project={orchestrationProject} onClose={() => setOrchestrationProject(null)} />;
  const projectFor = (entry) => data.memberships.find((membership) => membership.object_kind === entry.kind && membership.object_id === entry.item.id)?.project_id;
  const unassigned = data.items.filter((entry) => !projectFor(entry));
  return <div className="space-y-3">
    <PassportIdentityCard identity={data.identity} onOpen={async () => { await createIdentity(); setPersonalOpen(true); }} />
    <PassportLinkInbox me={me} />
    <div className="flex items-center justify-between pt-2"><div><p className="text-[9px] font-bold uppercase tracking-[0.18em] text-muted-foreground">Projets</p><p className="text-xs font-bold">Vos passeports reliés</p></div><button type="button" onClick={() => setShowProjectForm(true)} aria-label="Créer un projet" className="flex h-9 w-9 items-center justify-center rounded-full bg-foreground text-background"><Plus className="h-4 w-4" /></button></div>
    {showProjectForm && <PassportProjectForm onCancel={() => setShowProjectForm(false)} onCreated={async (project) => { await load(); setShowProjectForm(false); if (["mariage", "evenement"].includes(project.project_type)) setCreation({ project, kind: "evenement" }); }} />}
    {data.projects.map((project) => <PassportProjectSection key={project.id} project={project} items={data.items.filter((entry) => projectFor(entry) === project.id)} onOpen={setOpened} onCreate={(selected, kind) => setCreation({ project: selected, kind })} onLinks={setLinksProject} onOrchestrate={setOrchestrationProject} />)}
    {unassigned.length > 0 && <PassportProjectSection project={null} items={unassigned} onOpen={setOpened} />}
    {!data.projects.length && !unassigned.length && <p className="rounded-2xl border border-dashed border-border p-6 text-center text-xs text-muted-foreground">Créez un projet, puis ajoutez un passeport DONNER ou RECEVOIR.</p>}
  </div>;
}