import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Loader2, ExternalLink } from "lucide-react";
import { base44 } from "@/api/base44Client";

// MA PAGE « + » — chaque personne, sans exception, peut publier sa page profil
// sur son adresse +pseudo : vérifiée, unique, publique.
const slugifier = (s) =>
  (s || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");

export default function AdressePlusForm({ me }) {
  const [rec, setRec] = useState(null);
  const [slug, setSlug] = useState("");
  const [etat, setEtat] = useState("idle"); // idle | envoi | pris | ok
  const [charge, setCharge] = useState(true);

  useEffect(() => {
    base44.entities.ProfilPlus.filter({ created_by_id: me.id }).then(([r]) => {
      setRec(r || null);
      setSlug(r?.plus_adresse || slugifier(me.pas_pseudo || me.full_name));
      setCharge(false);
    });
  }, [me]);

  const publier = async () => {
    const s = slugifier(slug);
    if (!s) return;
    setEtat("envoi");
    const [dejaProfil] = await base44.entities.ProfilPlus.filter({ plus_adresse: s });
    const [dejaSite] = await base44.entities.PublishedSite.filter({ slug: s });
    if ((dejaProfil && dejaProfil.created_by_id !== me.id) || dejaSite) {
      setEtat("pris");
      return;
    }
    const data = {
      plus_adresse: s,
      pseudo: me.pas_pseudo || me.full_name || s,
      photo_url: me.pas_photo_url || "",
      zone: me.pas_zone || "",
    };
    const saved = rec
      ? await base44.entities.ProfilPlus.update(rec.id, data).then(() => ({ ...rec, ...data }))
      : await base44.entities.ProfilPlus.create(data);
    setRec(saved);
    setSlug(s);
    setEtat("ok");
  };

  if (charge) return <p className="text-[13px] text-white/50">Chargement…</p>;

  return (
    <div className="rounded-2xl border border-white/15 bg-[#141414] p-5">
      <p className="text-[13px] leading-relaxed text-white/60">
        Votre page profil publique vit sur son adresse « + » : unique, partageable, sans donnée sensible.
      </p>
      <div className="mt-4 flex flex-wrap items-center gap-2">
        <div className="flex min-h-[46px] flex-1 items-center rounded-xl border border-white/15 bg-black/30 px-3">
          <span className="font-mono text-[14px] font-bold text-accent">+</span>
          <input
            type="text"
            value={slug}
            onChange={(e) => { setSlug(e.target.value); setEtat("idle"); }}
            placeholder="votre-pseudo"
            className="w-full bg-transparent px-1 font-mono text-[14px] outline-none"
            aria-label="Votre adresse +"
          />
        </div>
        <button onClick={publier} disabled={etat === "envoi"}
          className="flex min-h-[46px] items-center gap-2 rounded-full bg-accent px-6 text-[13px] font-bold text-black transition hover:opacity-85 disabled:opacity-50">
          {etat === "envoi" && <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />}
          {rec ? "Mettre à jour" : "Publier ma page"}
        </button>
      </div>
      {etat === "pris" && (
        <p className="mt-3 text-[12px] font-bold text-red-400">Cette adresse est déjà prise — essayez-en une autre.</p>
      )}
      {rec && etat !== "pris" && (
        <Link to={`/+${rec.plus_adresse}`} className="mt-3 inline-flex items-center gap-1.5 font-mono text-[12px] font-bold text-accent hover:text-white">
          Voir ma page +{rec.plus_adresse} <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
        </Link>
      )}
    </div>
  );
}