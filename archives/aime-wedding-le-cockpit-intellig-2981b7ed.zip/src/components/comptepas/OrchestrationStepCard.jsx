import { Draggable } from "@hello-pangea/dnd";
import { Check, GripVertical, MapPin } from "lucide-react";

export default function OrchestrationStepCard({ step, index, selected, onSelect, onComplete }) {
  return <Draggable draggableId={step.id} index={index}>{(provided, snapshot) => <div ref={provided.innerRef} {...provided.draggableProps} onClick={() => onSelect(step.id)} className={`flex items-center gap-2 rounded-xl border p-3 ${selected ? "border-foreground" : "border-border"} ${snapshot.isDragging ? "bg-card shadow-xl" : "bg-card"}`}>
    <button type="button" {...provided.dragHandleProps} aria-label="Déplacer cette étape" className="text-muted-foreground"><GripVertical className="h-4 w-4" /></button>
    <div className="w-12 font-mono text-[10px] font-bold">{new Date(step.scheduled_at).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}</div>
    <div className="min-w-0 flex-1"><p className="truncate text-[11px] font-bold">{step.label}</p><p className="mt-0.5 flex items-center gap-1 text-[8px] text-muted-foreground">{step.duration_minutes || 30} min{step.location_label && <><MapPin className="h-2.5 w-2.5" />{step.location_label}</>}</p></div>
    {step.status !== "terminee" && <button type="button" onClick={(event) => { event.stopPropagation(); onComplete(step.id); }} aria-label={`Terminer ${step.label}`} className="flex h-8 w-8 items-center justify-center rounded-full bg-foreground text-background"><Check className="h-3.5 w-3.5" /></button>}
  </div>}</Draggable>;
}