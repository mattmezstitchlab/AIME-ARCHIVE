import EvenementParticipationCard from "@/components/evenements/EvenementParticipationCard";

export default function EvenementCarte({ event, onUpdate }) {
  return <div className="network-window"><EvenementParticipationCard event={event} onChanged={onUpdate} /></div>;
}