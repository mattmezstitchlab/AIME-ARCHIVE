import { useState } from "react";
import { PROVIDERS } from "@/lib/events/eventPassportCatalog";

export default function EventProvidersChapter({ event, onSave }) {
  const [selected, setSelected] = useState(event.provider_categories || []); const [saving, setSaving] = useState(false);
  const toggle = (key) => setSelected(selected.includes(key) ? selected.filter((item) => item !== key) : [...selected, key]);
  const save = async () => { setSaving(true); await onSave({ provider_categories: selected }); setSaving(false); };
  return <div className="p-4"><p className="text-[9px] font-bold uppercase tracking-[0.18em] text-muted-foreground">Taxonomie professionnelle</p><h3 className="mt-1 text-lg font-extrabold">Prestataires</h3><p className="mt-1 text-[9px] text-muted-foreground">Activez tous les métiers utiles à ce projet.</p><div className="mt-4 grid grid-cols-2 gap-2">{PROVIDERS.map(([key, label]) => <button key={key} type="button" aria-pressed={selected.includes(key)} onClick={() => toggle(key)} className={`rounded-xl border px-3 py-2 text-left text-[10px] font-bold ${selected.includes(key) ? "border-foreground bg-foreground text-background" : "border-border"}`}>{label}</button>)}</div><button type="button" onClick={save} disabled={saving} className="mt-4 w-full rounded-full bg-foreground py-3 text-[10px] font-bold text-background disabled:opacity-40">{saving ? "Enregistrement…" : "Enregistrer"}</button></div>;
}