import { useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { DEFAULT_EVENT_CHAPTERS, eventChapterByKey } from "@/lib/events/eventPassportCatalog";
import EvenementParticipationCard from "@/components/evenements/EvenementParticipationCard";
import EventChapterMenu from "./EventChapterMenu";
import EventAllergensChapter from "./EventAllergensChapter";
import EventAccessibilityChapter from "./EventAccessibilityChapter";
import EventProvidersChapter from "./EventProvidersChapter";
import EventGenieChapter from "./EventGenieChapter";
import EventGenericChapter from "./EventGenericChapter";
import EventRadioChapter from "@/components/radio/EventRadioChapter";

const Chapter = ({ chapterKey, event, onSave }) => chapterKey === "radio" ? <EventRadioChapter event={event} /> : chapterKey === "allergens" ? <EventAllergensChapter event={event} onSave={onSave} /> : chapterKey === "accessibility" ? <EventAccessibilityChapter event={event} onSave={onSave} /> : chapterKey === "providers" ? <EventProvidersChapter event={event} onSave={onSave} /> : chapterKey === "genie" ? <EventGenieChapter event={event} onSave={onSave} /> : <EventGenericChapter chapterKey={chapterKey} event={event} onSave={onSave} />;

export default function EventPassport({ event, causal, onChanged }) {
  const [current, setCurrent] = useState(event); const [screen, setScreen] = useState(0); const enabled = Array.isArray(current.enabled_chapters) ? current.enabled_chapters : DEFAULT_EVENT_CHAPTERS;
  const save = async (patch) => { const fresh = await base44.entities.SolidarityEvent.update(current.id, patch); setCurrent(fresh); onChanged?.(); return fresh; };
  const toggle = (key) => save({ enabled_chapters: enabled.includes(key) ? enabled.filter((item) => item !== key) : [...enabled, key] });
  const screens = [{ key: "identity", label: "Événement", element: <EvenementParticipationCard event={current} causal={causal} onChanged={onChanged} /> }, ...enabled.map((key) => ({ key, label: eventChapterByKey(key)?.[1], element: <Chapter chapterKey={key} event={current} onSave={save} /> }))]; const active = Math.min(screen, screens.length - 1);
  return <article className="overflow-hidden rounded-2xl border border-border bg-card"><div className="relative flex items-center justify-between gap-2 border-b border-border px-4 py-3"><div className="min-w-0"><p className="text-[8px] font-bold uppercase tracking-[0.2em] text-muted-foreground">Passeport événementiel</p><p className="mt-1 truncate text-[11px] font-bold">{current.title}</p></div><EventChapterMenu enabled={enabled} onToggle={toggle} /></div><div className="min-h-[320px]">{screens[active].element}</div><div className="flex items-center justify-between border-t border-border px-3 py-2"><button type="button" onClick={() => setScreen((active - 1 + screens.length) % screens.length)} aria-label="Chapitre précédent" className="flex h-8 w-8 items-center justify-center rounded-full border border-border"><ChevronLeft className="h-3.5 w-3.5" /></button><p className="max-w-[60%] truncate text-[8px] font-bold uppercase tracking-widest text-muted-foreground">{screens[active].label}</p><button type="button" onClick={() => setScreen((active + 1) % screens.length)} aria-label="Chapitre suivant" className="flex h-8 w-8 items-center justify-center rounded-full bg-foreground text-background"><ChevronRight className="h-3.5 w-3.5" /></button></div></article>;
}