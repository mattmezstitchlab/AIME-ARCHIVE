import { useState } from "react";
import { eventChapterByKey } from "@/lib/events/eventPassportCatalog";

export default function EventGenericChapter({ chapterKey, event, onSave }) {
  const chapter = eventChapterByKey(chapterKey); const [note, setNote] = useState(event.chapter_notes?.[chapterKey] || ""); const [saving, setSaving] = useState(false);
  const save = async () => { setSaving(true); await onSave({ chapter_notes: { ...(event.chapter_notes || {}), [chapterKey]: note } }); setSaving(false); };
  return <div className="p-4"><p className="text-[9px] font-bold uppercase tracking-[0.18em] text-muted-foreground">Chapitre événementiel</p><h3 className="mt-1 text-lg font-extrabold">{chapter?.[1]}</h3><p className="mt-1 text-[9px] text-muted-foreground">{chapter?.[2]}</p><textarea value={note} onChange={(e) => setNote(e.target.value)} placeholder={`Réglages et informations — ${chapter?.[1]}`} className="mt-4 min-h-40 w-full rounded-xl border border-border bg-muted p-3 text-[10px]" /><button type="button" onClick={save} disabled={saving} className="mt-3 w-full rounded-full bg-foreground py-3 text-[10px] font-bold text-background disabled:opacity-40">{saving ? "Enregistrement…" : "Enregistrer le chapitre"}</button></div>;
}