import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Printer, ClipboardList } from "lucide-react";

// LA LOGISTIQUE ORGANISATEUR — liste des dossards, paiement pointé, émargement au départ.
export default function EvenementLogistique({ event, onUpdate }) {
  const [saving, setSaving] = useState(false);
  const participants = event.participants || [];
  const payant = event.entry_fee > 0;

  const toggle = async (idx, field) => {
    setSaving(true);
    const frais = await base44.entities.SolidarityEvent.get(event.id);
    const liste = [...(frais.participants || [])];
    if (liste[idx]) {
      liste[idx] = { ...liste[idx], [field]: !liste[idx][field] };
      await base44.entities.SolidarityEvent.update(event.id, { participants: liste });
      onUpdate();
    }
    setSaving(false);
  };

  const imprimer = () => {
    const lignes = participants.map((p) =>
      `<tr><td>N° ${p.dossard}</td><td>${p.name}</td>${payant ? `<td>${p.paid ? "Payé" : "—"}</td>` : ""}<td></td></tr>`
    ).join("");
    const w = window.open("", "_blank");
    w.document.write(`<html><head><title>${event.title} — Liste des dossards</title>
      <style>body{font-family:sans-serif;padding:24px}table{width:100%;border-collapse:collapse}td,th{border:1px solid #999;padding:8px;text-align:left}</style>
      </head><body><h2>${event.title}</h2><p>${event.event_date || ""} · ${event.city || ""} — ${participants.length} inscrit(s)</p>
      <table><tr><th>Dossard</th><th>Nom</th>${payant ? "<th>Paiement</th>" : ""}<th>Émargement</th></tr>${lignes}</table></body></html>`);
    w.document.close();
    w.print();
  };

  const presents = participants.filter((p) => p.checked_in).length;
  const payes = participants.filter((p) => p.paid).length;

  return (
    <details className="mt-5 rounded-xl border border-white/10 bg-[#0D0D0D]">
      <summary className="flex min-h-[44px] cursor-pointer items-center gap-2 px-4 text-[12px] font-bold text-white/70 transition hover:text-white">
        <ClipboardList className="h-4 w-4 text-[#F2B90D]" aria-hidden="true" />
        Logistique organisateur — dossards, émargement{payant ? ", paiements" : ""}
      </summary>
      <div className="px-4 pb-4">
        <div className="mt-2 flex flex-wrap items-center gap-3 text-[11px] text-white/50">
          <span>{participants.length} inscrit(s)</span>
          <span>{presents} présent(s) au départ</span>
          {payant && <span>{payes} paiement(s) reçus · {(payes * event.entry_fee).toFixed(0)} € encaissés</span>}
          <button type="button" onClick={imprimer}
            className="ml-auto flex min-h-[34px] items-center gap-1.5 rounded-full border border-white/20 px-4 text-[11px] font-bold text-white/70 transition hover:border-white hover:text-white">
            <Printer className="h-3.5 w-3.5" aria-hidden="true" /> Imprimer la liste
          </button>
        </div>
        {participants.length === 0 ? (
          <p className="mt-3 text-[12px] text-white/40">Aucun inscrit pour le moment.</p>
        ) : (
          <div className="mt-3 space-y-1.5">
            {participants.map((p, idx) => (
              <div key={idx} className="flex flex-wrap items-center gap-3 rounded-lg bg-white/5 px-3 py-2">
                <span className="font-mono text-[13px] font-extrabold text-[#F2B90D]">N° {p.dossard}</span>
                <span className="flex-1 text-[13px] font-bold">{p.name}</span>
                {payant && (
                  <label className="flex cursor-pointer items-center gap-1.5 text-[11px] text-white/60">
                    <input type="checkbox" checked={!!p.paid} disabled={saving} onChange={() => toggle(idx, "paid")} className="h-4 w-4 accent-[#F2B90D]" />
                    Payé
                  </label>
                )}
                <label className="flex cursor-pointer items-center gap-1.5 text-[11px] text-white/60">
                  <input type="checkbox" checked={!!p.checked_in} disabled={saving} onChange={() => toggle(idx, "checked_in")} className="h-4 w-4 accent-[#F2B90D]" />
                  Présent
                </label>
              </div>
            ))}
          </div>
        )}
      </div>
    </details>
  );
}