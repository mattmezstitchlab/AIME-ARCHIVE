import { useState } from "react";
import { base44 } from "@/api/base44Client";

// LA PROMESSE D'APPORT — « le jour J, j'apporte ça » : le compteur monte en direct.
export default function ApportPromesse({ event, onUpdate }) {
  const [f, setF] = useState({ name: "", item_label: "", quantity: "1" });
  const [saving, setSaving] = useState(false);
  const [merci, setMerci] = useState(false);

  const promettre = async (e) => {
    e.preventDefault();
    setSaving(true);
    const frais = await base44.entities.SolidarityEvent.get(event.id);
    await base44.entities.SolidarityEvent.update(event.id, {
      contributions: [...(frais.contributions || []), {
        name: f.name,
        item_label: f.item_label,
        quantity: Number(f.quantity) || 1,
        registered_at: new Date().toISOString(),
      }],
    });
    setSaving(false);
    setMerci(true);
    setF({ name: "", item_label: "", quantity: "1" });
    onUpdate();
    setTimeout(() => setMerci(false), 3000);
  };

  if (merci) {
    return <p className="mt-3 rounded-xl bg-[#F2B90D]/15 p-3 text-[12px] font-bold text-[#F2B90D]">Promesse enregistrée — apportez-le au point de départ le jour J. Merci.</p>;
  }

  return (
    <form onSubmit={promettre} className="mt-3 flex flex-wrap gap-2">
      <input required value={f.name} onChange={(e) => setF((p) => ({ ...p, name: e.target.value }))} placeholder="Votre prénom"
        className="min-h-[42px] w-28 flex-1 rounded-xl border border-white/15 bg-[#0D0D0D] px-3 text-[12px] outline-none" />
      <input required value={f.item_label} onChange={(e) => setF((p) => ({ ...p, item_label: e.target.value }))} placeholder="J'apporte… (ex. baskets 42)"
        className="min-h-[42px] min-w-[130px] flex-[2] rounded-xl border border-white/15 bg-[#0D0D0D] px-3 text-[12px] outline-none" />
      <input type="number" min="1" value={f.quantity} onChange={(e) => setF((p) => ({ ...p, quantity: e.target.value }))} aria-label="Quantité"
        className="min-h-[42px] w-14 rounded-xl border border-white/15 bg-[#0D0D0D] px-3 text-[12px] outline-none" />
      <button type="submit" disabled={saving}
        className="min-h-[42px] rounded-full border border-[#F2B90D] px-4 text-[12px] font-bold text-[#F2B90D] transition hover:bg-[#F2B90D] hover:text-black disabled:opacity-40">
        {saving ? "…" : "J'apporte"}
      </button>
    </form>
  );
}