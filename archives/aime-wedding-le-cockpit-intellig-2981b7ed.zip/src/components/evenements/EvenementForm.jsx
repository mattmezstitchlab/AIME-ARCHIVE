import { useState } from "react";
import { base44 } from "@/api/base44Client";
import ActionOnboardingProgress from "@/components/reseau/ActionOnboardingProgress";
import EventBasicsStep from "@/components/evenements/onboarding/EventBasicsStep";
import EventLogisticsStep from "@/components/evenements/onboarding/EventLogisticsStep";
import EventCauseStep from "@/components/evenements/onboarding/EventCauseStep";
import EventDocumentsStep from "@/components/evenements/onboarding/EventDocumentsStep";
import EventChaptersStep from "@/components/evenements/onboarding/EventChaptersStep";
import { eventTypeProfile } from "@/lib/events/eventTypeProfiles";
import { eventDateTextToIso, isValidEventDateText } from "@/lib/events/eventDate";

const INITIAL = { title: "", event_type: "autre", dateText: "", city: "", start_point: "", distance_km: "", max_participants: "", organizer_name: "", description: "", entry_fee: "", collect_donations: false, collect_types: [], enabled_chapters: eventTypeProfile("autre").chapters, radio_enabled: true, radio_contribution_access: "connected" };
const initialDraft = (initialValues) => {
  const { event_date, date, ...values } = initialValues;
  return { ...INITIAL, ...values, dateText: values.dateText || "" };
};

export default function EvenementForm({ onCreated, initialValues = {} }) {
  const [draft, setDraft] = useState(() => initialDraft(initialValues));
  const [step, setStep] = useState(0);
  const [documents, setDocuments] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const addDocument = async (file) => { if (!file) return; setUploading(true); const { file_url } = await base44.integrations.Core.UploadFile({ file }); setDocuments((items) => [...items, { name: file.name, file_url }]); setUploading(false); };
  const go = (next) => {
    if (next > step && step === 0 && (!draft.title.trim() || !isValidEventDateText(draft.dateText) || !draft.city.trim())) return setError("Renseignez le nom, une date valide et la ville.");
    if (next > step && step === 1 && !draft.organizer_name) return setError("Indiquez qui organise l’événement.");
    setError(""); setStep(Math.max(0, Math.min(4, next)));
  };
  const submit = async (event) => {
    event.preventDefault();
    if (!draft.title.trim() || !isValidEventDateText(draft.dateText) || !draft.city.trim() || !draft.organizer_name.trim()) return setError("Revenez compléter les informations obligatoires.");
    setLoading(true);
    const { dateText, ...eventDraft } = draft;
    const created = await base44.entities.SolidarityEvent.create({ ...eventDraft, event_date: eventDateTextToIso(dateText), distance_km: draft.distance_km ? Number(draft.distance_km) : undefined, entry_fee: draft.entry_fee ? Number(draft.entry_fee) : undefined, max_participants: draft.max_participants ? Number(draft.max_participants) : undefined, documents, participants: [], contributions: [], status: "open" });
    setLoading(false); onCreated(created);
  };
  return <form onSubmit={submit} className="rounded-2xl border border-border bg-card p-4">
    <ActionOnboardingProgress step={step} total={5} onChange={go} />
    {step === 0 && <EventBasicsStep draft={draft} onChange={setDraft} showValidation={Boolean(error)} />}
    {step === 1 && <EventLogisticsStep value={draft} onChange={setDraft} />}
    {step === 2 && <EventCauseStep value={draft} onChange={setDraft} />}
    {step === 3 && <EventChaptersStep value={draft} onChange={setDraft} />}
    {step === 4 && <EventDocumentsStep documents={documents} uploading={uploading} onAdd={addDocument} onRemove={(index) => setDocuments((items) => items.filter((_, itemIndex) => itemIndex !== index))} value={draft} />}
    {error && <p className="mt-3 text-center text-[11px] font-bold text-destructive">{error}</p>}
    {step === 4 && <button type="submit" disabled={loading || uploading} className="mt-5 w-full rounded-full bg-foreground py-3 text-xs font-bold text-background disabled:opacity-40">{loading ? "Création…" : "Ouvrir le passeport"}</button>}
  </form>;
}