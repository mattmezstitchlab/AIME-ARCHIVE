import { useState } from "react";
import { ImagePlus, Sparkles, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function EventVisualTimeline({ event, onChanged }) {
  const [busy, setBusy] = useState("");
  const history = event.visual_history || [];
  const primary = event.visual_primary_url || history.at(-1)?.url;
  const save = async (url, source, label) => {
    const entry = { url, source, label, created_at: new Date().toISOString() };
    await base44.entities.SolidarityEvent.update(event.id, { visual_primary_url: url, visual_history: [...history, entry] });
    await onChanged?.(); setBusy("");
  };
  const upload = async (file) => { if (!file) return; setBusy("photo"); const { file_url } = await base44.integrations.Core.UploadFile({ file }); await save(file_url, "photo", file.name); };
  const generate = async () => { setBusy("ia"); const { url } = await base44.integrations.Core.GenerateImage({ prompt: `Photographie documentaire, humaine et naturelle de ${event.title}, à ${event.city || "proximité"}. ${event.description || "Événement solidaire local"}. Aucun texte dans l'image, cadrage horizontal, lumière naturelle.` }); await save(url, "ia", "Vision générée"); };
  const select = async (url) => { await base44.entities.SolidarityEvent.update(event.id, { visual_primary_url: url }); await onChanged?.(); };
  return <div className="mb-4 overflow-hidden rounded-xl bg-muted">
    <div className="relative h-32">{primary ? <img src={primary} alt={`Visuel de ${event.title}`} className="h-full w-full object-cover" /> : <div className="flex h-full items-center justify-center text-[10px] font-bold uppercase tracking-widest text-muted-foreground">Construire le récit visuel</div>}</div>
    {history.length > 0 && <div className="flex gap-2 overflow-x-auto p-2">{history.map((item, index) => <button key={`${item.created_at}-${index}`} type="button" onClick={() => select(item.url)} className={`w-16 shrink-0 text-left ${primary === item.url ? "opacity-100" : "opacity-55"}`}><img src={item.url} alt="" className="h-10 w-16 rounded-lg object-cover" /><span className="mt-1 block text-[8px] text-muted-foreground">{new Date(item.created_at).toLocaleDateString("fr-FR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" })}</span></button>)}</div>}
    <div className="flex gap-2 border-t border-border p-2"><label className="flex flex-1 cursor-pointer items-center justify-center gap-1 rounded-full bg-card py-2 text-[9px] font-bold"><ImagePlus className="h-3.5 w-3.5" />Photo<input type="file" accept="image/*" onChange={(e) => upload(e.target.files?.[0])} className="sr-only" /></label><button type="button" disabled={!!busy} onClick={generate} className="flex flex-1 items-center justify-center gap-1 rounded-full bg-foreground py-2 text-[9px] font-bold text-background disabled:opacity-40">{busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Sparkles className="h-3.5 w-3.5" />}Générer</button></div>
  </div>;
}