import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { eventActionRecommendations } from "@/lib/events/eventActionEngine";

export default function useEventActionRecommendations(event, phase) {
  const [state, setState] = useState({ loading: false, items: [] });
  const categories = (event?.collect_types || []).join(",");
  useEffect(() => {
    if (!event?.city || !event?.event_type) return setState({ loading: false, items: [] });
    let active = true;
    const load = async () => {
      setState((current) => ({ ...current, loading: true }));
      const [needs, pairs, relays] = await Promise.all([
        base44.entities.ShoeNeed.list("-created_date", 100),
        base44.entities.ShoePair.list("-created_date", 100),
        base44.entities.RelayOffer.list("-created_date", 100),
      ]);
      if (active) setState({ loading: false, items: eventActionRecommendations(event, phase, { needs, pairs, relays }) });
    };
    load();
    const unsubscribers = [base44.entities.ShoeNeed.subscribe(load), base44.entities.ShoePair.subscribe(load), base44.entities.RelayOffer.subscribe(load)];
    return () => { active = false; unsubscribers.forEach((unsubscribe) => unsubscribe()); };
  }, [event?.city, event?.event_type, categories, phase]);
  return state;
}