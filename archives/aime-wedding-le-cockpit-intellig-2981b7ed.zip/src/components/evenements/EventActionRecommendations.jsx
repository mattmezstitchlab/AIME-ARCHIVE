import { Loader2, MapPin } from "lucide-react";
import useEventActionRecommendations from "@/components/evenements/useEventActionRecommendations";

const PHASES = { creation: "Avant création", preparation: "Pendant la préparation", live: "Pendant l’événement" };
const phaseFor = (event, requested) => { if (requested !== "auto") return requested; const today = new Date().toISOString().slice(0, 10); return event.event_date && event.event_date <= today && ["open", "full"].includes(event.status) ? "live" : "preparation"; };

export default function EventActionRecommendations({ event, phase: requested = "auto", onApply }) {
  const phase = phaseFor(event, requested); const { loading, items } = useEventActionRecommendations(event, phase);
  if (!event?.city || !event?.event_type) return null;
  return <section className="mt-4 rounded-2xl border border-border bg-muted/45 p-3" aria-label="Actions prioritaires proposées">
    <div className="mb-2 flex items-center justify-between gap-2"><p className="text-[9px] font-bold uppercase tracking-[0.16em]">Actions prioritaires</p><span className="rounded-full bg-card px-2 py-1 text-[8px] font-bold text-muted-foreground">{PHASES[phase]}</span></div>
    {loading ? <p className="flex items-center gap-2 py-2 text-[10px] text-muted-foreground"><Loader2 className="h-3 w-3 animate-spin" />Lecture du réseau local…</p> : <div className="space-y-2">{items.map((item) => <article key={item.id} className="rounded-xl border border-border bg-card p-2.5">
      <p className="flex items-start gap-2 text-[10px] font-bold leading-snug"><MapPin className="mt-0.5 h-3 w-3 shrink-0 text-accent" /><span>SI {item.si}<br />ALORS {item.alors}<br /><span className="font-medium text-muted-foreground">PARCE QUE {item.parceQue}</span></span></p>
      {onApply && <button type="button" onClick={() => onApply(item)} className="mt-2 rounded-full bg-foreground px-3 py-1.5 text-[9px] font-bold text-background">Prioriser</button>}
    </article>)}</div>}
  </section>;
}