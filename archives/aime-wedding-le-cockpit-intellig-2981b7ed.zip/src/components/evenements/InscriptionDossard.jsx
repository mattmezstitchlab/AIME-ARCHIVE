import { useState } from "react";
import { base44 } from "@/api/base44Client";

// L'INSCRIPTION AVEC DOSSARD — chaque inscrit reçoit son numéro, affiché en grand.
export default function InscriptionDossard({ event, onUpdate }) {
  const [f, setF] = useState({ name: "", pledge_quantity: "" });
  const [saving, setSaving] = useState(false);
  const [dossard, setDossard] = useState(null);

  const complet = event.max_participants && (event.participants?.length || 0) >= event.max_participants;

  const inscrire = async (e) => {
    e.preventDefault();
    setSaving(true);
    // On relit l'événement pour attribuer le bon numéro même si d'autres s'inscrivent.
    const frais = await base44.entities.SolidarityEvent.get(event.id);
    const participants = frais.participants || [];
    const numero = String(participants.length + 1).padStart(3, "0");
    const inscrit = {
      name: f.name,
      dossard: numero,
      pledge_quantity: f.pledge_quantity ? Number(f.pledge_quantity) : undefined,
      registered_at: new Date().toISOString(),
    };
    const pleins = frais.max_participants && participants.length + 1 >= frais.max_participants;
    await base44.entities.SolidarityEvent.update(event.id, {
      participants: [...participants, inscrit],
      ...(pleins ? { status: "full" } : {}),
    });
    const me = await base44.auth.me().catch(() => null);
    if (me) {
      const existing = await base44.entities.PassportMembership.filter({ project_id: event.id, object_kind: "evenement", object_id: event.id });
      if (!existing.some((link) => link.created_by_id === me.id)) await base44.entities.PassportMembership.create({ project_id: event.id, object_kind: "evenement", object_id: event.id, title: event.title, role: "participant", status: "active" });
    }
    setSaving(false);
    setDossard(inscrit);
    onUpdate();
  };

  if (dossard) {
    return (
      <div className="mt-4 rounded-xl bg-accent p-4 text-black">
        <p className="font-mono text-[10px] font-bold uppercase tracking-[0.25em]">Votre dossard</p>
        <p className="mt-1 font-mono text-[44px] font-extrabold leading-none">N° {dossard.dossard}</p>
        <p className="mt-2 text-[13px] font-bold">{dossard.name} · {event.title}</p>
        {dossard.pledge_quantity > 0 && (
          <p className="mt-1 text-[12px]">+ {dossard.pledge_quantity} don(s) promis pour la cause. Merci.</p>
        )}
        {event.entry_fee > 0 && (
          <p className="mt-1 text-[12px] font-bold">Inscription : {event.entry_fee} € — à régler au départ auprès de l'organisateur.</p>
        )}
        <p className="mt-2 text-[11px] opacity-70">Montrez ce numéro au départ — il suffit.</p>
      </div>
    );
  }

  if (complet || event.status === "full") {
    return <p className="mt-4 rounded-xl bg-white/5 p-3 text-[12px] font-bold text-white/60">Événement complet — les inscriptions sont closes.</p>;
  }

  return (
    <form onSubmit={inscrire} className="mt-4 flex flex-wrap gap-2">
      <input required value={f.name} onChange={(e) => setF((p) => ({ ...p, name: e.target.value }))} placeholder="Votre prénom et nom"
        className="min-h-[42px] min-w-[150px] flex-1 rounded-xl border border-white/15 bg-[#0D0D0D] px-3 text-[12px] outline-none" />
      <input type="number" min="0" value={f.pledge_quantity} onChange={(e) => setF((p) => ({ ...p, pledge_quantity: e.target.value }))} placeholder="Dons"
        title="Nombre de dons promis pour la cause (optionnel)"
        className="min-h-[42px] w-16 rounded-xl border border-white/15 bg-[#0D0D0D] px-3 text-[12px] outline-none" />
      <button type="submit" disabled={saving}
        className="min-h-[42px] rounded-full bg-accent px-5 text-[12px] font-bold text-black transition hover:opacity-85 disabled:opacity-40">
        {saving ? "…" : "Je m'inscris"}
      </button>
    </form>
  );
}