import { FileText, Download } from "lucide-react";

// LES DOCUMENTS DE L'ASSO — règlement, autorisation, assurance : à disposition des inscrits.
export default function EvenementDocuments({ documents }) {
  if (!documents?.length) return null;
  return (
    <div className="mt-4">
      <p className="flex items-center gap-1.5 text-[12px] font-bold text-white/70">
        <FileText className="h-4 w-4 text-[#F2B90D]" aria-hidden="true" /> Documents de l'association
      </p>
      <div className="mt-2 flex flex-wrap gap-2">
        {documents.map((d, i) => (
          <a key={i} href={d.file_url} target="_blank" rel="noopener noreferrer"
            className="flex min-h-[36px] items-center gap-1.5 rounded-full border border-white/20 px-4 text-[11px] font-bold text-white/70 transition hover:border-[#F2B90D] hover:text-[#F2B90D]">
            <Download className="h-3.5 w-3.5" aria-hidden="true" /> {d.name}
          </a>
        ))}
      </div>
    </div>
  );
}