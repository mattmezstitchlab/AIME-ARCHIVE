import { useState } from "react";
import { CalendarDays, MapPin } from "lucide-react";
import { base44 } from "@/api/base44Client";
import ActionOnboardingProgress from "@/components/reseau/ActionOnboardingProgress";
import InscriptionDossard from "./InscriptionDossard";
import ApportPromesse from "./ApportPromesse";
import EvenementDocuments from "./EvenementDocuments";
import EvenementLogistique from "./EvenementLogistique";
import GenerateurDocuments from "./GenerateurDocuments";
import EventVisualTimeline from "./EventVisualTimeline";
import EventCausalDescription from "./EventCausalDescription";
import EventActionRecommendations from "./EventActionRecommendations";

export default function EvenementParticipationCard({ event, causal, onChanged }) {
  const [current, setCurrent] = useState(event);
  const [step, setStep] = useState(0);
  const participants = current.participants || [];
  const contributions = current.contributions || [];
  const promises = participants.reduce((sum, item) => sum + (item.pledge_quantity || 0), 0) + contributions.reduce((sum, item) => sum + (item.quantity || 0), 0);
  const total = current.collect_donations ? 4 : 3;
  const organizationStep = current.collect_donations ? 3 : 2;
  const refresh = async () => { const fresh = await base44.entities.SolidarityEvent.get(current.id); setCurrent(fresh); onChanged?.(); };
  const prioritize = async (item) => { await base44.entities.SolidarityEvent.update(current.id, { collect_donations: true, collect_types: [...new Set([...(current.collect_types || []), item.category])] }); await refresh(); };
  return <div className="rounded-2xl border border-border bg-card p-4">
    <ActionOnboardingProgress step={step} total={total} onChange={(next) => setStep(Math.max(0, Math.min(total - 1, next)))} />
    {step === 0 && <div><EventVisualTimeline event={current} onChanged={refresh} /><p className="text-[9px] font-bold uppercase tracking-[0.18em] text-muted-foreground">Événement à l’agenda</p><h3 className="mt-2 text-xl font-extrabold">{current.title}</h3><div className="mt-3 space-y-2 text-xs text-muted-foreground"><p className="flex items-center gap-2"><CalendarDays className="h-4 w-4" />{current.event_date ? new Date(current.event_date).toLocaleDateString("fr-FR") : "Date à confirmer"}</p><p className="flex items-center gap-2"><MapPin className="h-4 w-4" />{current.city}{current.start_point ? ` · ${current.start_point}` : ""}</p></div><EventCausalDescription description={current.description} causal={causal} /><EventActionRecommendations event={current} phase="auto" onApply={prioritize} /><div className="mt-5 grid grid-cols-2 gap-2"><div className="rounded-xl bg-muted p-3"><strong className="block text-xl">{participants.length}</strong><span className="text-[9px] uppercase text-muted-foreground">Participants</span></div><div className="rounded-xl bg-muted p-3"><strong className="block text-xl">{promises}</strong><span className="text-[9px] uppercase text-muted-foreground">Dons promis</span></div></div></div>}
    {step === 1 && <div><p className="mb-2 text-[10px] font-bold uppercase tracking-[0.16em] text-muted-foreground">Se brancher à l’événement</p><InscriptionDossard event={current} onUpdate={refresh} /></div>}
    {current.collect_donations && step === 2 && <div><p className="mb-2 text-[10px] font-bold uppercase tracking-[0.16em] text-muted-foreground">Contribuer au besoin collectif</p><ApportPromesse event={current} onUpdate={refresh} /></div>}
    {step === organizationStep && <div><p className="mb-2 text-[10px] font-bold uppercase tracking-[0.16em] text-muted-foreground">Organisation et suivi</p><EvenementDocuments documents={current.documents} /><EvenementLogistique event={current} onUpdate={refresh} /><GenerateurDocuments event={current} onUpdate={refresh} /></div>}
  </div>;
}