import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { jsPDF } from "jspdf";
import { Search, FileText, Wand2 } from "lucide-react";

// LE GÉNÉRATEUR — infos réelles de l'asso (registre public) + document IA pré-rempli en PDF.
const CATALOGUE = [
  { key: "reglement", label: "Règlement intérieur de l'événement" },
  { key: "autorisation_parentale", label: "Autorisation parentale (mineurs)" },
  { key: "decharge", label: "Décharge de responsabilité" },
  { key: "declaration_mairie", label: "Déclaration de manifestation en mairie" },
  { key: "attestation_participation", label: "Attestation de participation" },
  { key: "convention_benevole", label: "Convention d'engagement bénévole" },
  { key: "demande_assurance", label: "Demande d'attestation d'assurance RC" },
];

export default function GenerateurDocuments({ event, onUpdate }) {
  const [nom, setNom] = useState(event.organizer_name || "");
  const [resultats, setResultats] = useState(null);
  const [asso, setAsso] = useState(null);
  const [docType, setDocType] = useState("reglement");
  const [cherche, setCherche] = useState(false);
  const [genere, setGenere] = useState(false);
  const [fini, setFini] = useState("");

  const chercher = async () => {
    setCherche(true);
    setAsso(null);
    const { data } = await base44.functions.invoke("assoDocGen", { action: "lookup_asso", name: nom });
    setResultats(data.results || []);
    setCherche(false);
  };

  const generer = async () => {
    setGenere(true);
    setFini("");
    const { data } = await base44.functions.invoke("assoDocGen", { action: "generate_document", doc_type: docType, asso, event });
    // Le texte devient un PDF propre, attaché à l'événement.
    const pdf = new jsPDF();
    const lignes = pdf.splitTextToSize(data.text, 175);
    let y = 20;
    for (const l of lignes) {
      if (y > 280) { pdf.addPage(); y = 20; }
      pdf.setFontSize(10);
      pdf.text(l, 17, y);
      y += 5.5;
    }
    const label = CATALOGUE.find((c) => c.key === docType)?.label || "Document";
    const blob = pdf.output("blob");
    const file = new File([blob], `${label}.pdf`, { type: "application/pdf" });
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    const frais = await base44.entities.SolidarityEvent.get(event.id);
    await base44.entities.SolidarityEvent.update(event.id, {
      documents: [...(frais.documents || []), { name: label, file_url }],
    });
    pdf.save(`${label}.pdf`);
    setGenere(false);
    setFini(label);
    onUpdate();
  };

  return (
    <details className="mt-3 rounded-xl border border-white/10 bg-[#0D0D0D]">
      <summary className="flex min-h-[44px] cursor-pointer items-center gap-2 px-4 text-[12px] font-bold text-white/70 transition hover:text-white">
        <Wand2 className="h-4 w-4 text-[#F2B90D]" aria-hidden="true" />
        Générer un document officiel — pré-rempli avec les infos réelles de l'asso
      </summary>
      <div className="px-4 pb-4">
        {/* 1. Retrouver l'asso dans le registre public */}
        <p className="mt-2 text-[11px] text-white/50">1. Retrouvez votre association dans le registre public (RNA, SIREN, adresse officielle).</p>
        <div className="mt-2 flex gap-2">
          <input value={nom} onChange={(e) => setNom(e.target.value)} placeholder="Nom de l'association"
            className="min-h-[42px] flex-1 rounded-xl border border-white/15 bg-black px-3 text-[12px] outline-none" />
          <button type="button" onClick={chercher} disabled={cherche || !nom.trim()}
            className="flex min-h-[42px] items-center gap-1.5 rounded-full border border-white/25 px-4 text-[11px] font-bold text-white/80 transition hover:border-white disabled:opacity-40">
            <Search className="h-3.5 w-3.5" aria-hidden="true" /> {cherche ? "Recherche…" : "Rechercher"}
          </button>
        </div>
        {resultats && !asso && (
          resultats.length === 0 ? (
            <p className="mt-2 text-[11px] text-white/40">Aucune association trouvée — vérifiez l'orthographe exacte.</p>
          ) : (
            <div className="mt-2 space-y-1.5">
              {resultats.map((r, i) => (
                <button key={i} type="button" onClick={() => setAsso(r)}
                  className="block w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-left text-[12px] transition hover:border-[#F2B90D]">
                  <span className="font-bold">{r.nom}</span>
                  <span className="block text-[11px] text-white/50">
                    {r.rna && `RNA ${r.rna} · `}SIREN {r.siren} · {r.adresse}
                  </span>
                </button>
              ))}
            </div>
          )
        )}
        {asso && (
          <div className="mt-2 rounded-lg border border-[#F2B90D]/50 bg-[#F2B90D]/10 px-3 py-2 text-[12px]">
            <span className="font-bold text-[#F2B90D]">{asso.nom}</span>
            <span className="block text-[11px] text-white/60">{asso.rna && `RNA ${asso.rna} · `}SIREN {asso.siren} · {asso.adresse} {asso.code_postal} {asso.commune}</span>
            <button type="button" onClick={() => setAsso(null)} className="mt-1 text-[11px] text-white/50 underline hover:text-white">Changer</button>
          </div>
        )}

        {/* 2. Choisir et générer */}
        {asso && (
          <>
            <p className="mt-3 text-[11px] text-white/50">2. Choisissez le document — il sera rédigé, téléchargé en PDF et attaché à l'événement.</p>
            <div className="mt-2 flex gap-2">
              <select value={docType} onChange={(e) => setDocType(e.target.value)}
                className="min-h-[42px] flex-1 rounded-xl border border-white/15 bg-black px-3 text-[12px] outline-none">
                {CATALOGUE.map((c) => <option key={c.key} value={c.key}>{c.label}</option>)}
              </select>
              <button type="button" onClick={generer} disabled={genere}
                className="flex min-h-[42px] items-center gap-1.5 rounded-full bg-[#F2B90D] px-5 text-[11px] font-bold text-black transition hover:opacity-85 disabled:opacity-40">
                <FileText className="h-3.5 w-3.5" aria-hidden="true" /> {genere ? "Rédaction en cours…" : "Générer le PDF"}
              </button>
            </div>
            {fini && <p className="mt-2 text-[12px] font-bold text-[#F2B90D]">« {fini} » généré, téléchargé et attaché à l'événement.</p>}
          </>
        )}
      </div>
    </details>
  );
}