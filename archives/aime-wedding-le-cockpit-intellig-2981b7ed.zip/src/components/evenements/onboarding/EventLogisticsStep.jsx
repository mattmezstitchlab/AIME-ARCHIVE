import { eventTypeProfile } from "@/lib/events/eventTypeProfiles";
const field = "mt-1 w-full rounded-xl border border-border bg-muted px-3 py-2.5 text-xs";

export default function EventLogisticsStep({ value, onChange }) {
  const profile = eventTypeProfile(value.event_type); const set = (key, next) => onChange({ ...value, [key]: next });
  return <div className="space-y-3">
    <div><label className="text-xs font-bold">Organisateur</label><input value={value.organizer_name} onChange={(event) => set("organizer_name", event.target.value)} placeholder="Personne, collectif ou organisation" className={field} /></div>
    <div><label className="text-xs font-bold">{profile.place}</label><input value={value.start_point} onChange={(event) => set("start_point", event.target.value)} placeholder={profile.place} className={field} /></div>
    <div className={`grid gap-3 ${profile.distance ? "grid-cols-2" : "grid-cols-1"}`}>{profile.distance && <div><label className="text-xs font-bold">Distance du parcours</label><input type="number" min="0" step="0.5" value={value.distance_km} onChange={(event) => set("distance_km", event.target.value)} placeholder="km" className={field} /></div>}<div><label className="text-xs font-bold">Capacité</label><input type="number" min="1" value={value.max_participants} onChange={(event) => set("max_participants", event.target.value)} placeholder="Sans limite" className={field} /></div></div>
    <div><label className="text-xs font-bold">Tarif d’inscription</label><input type="number" min="0" step="0.5" value={value.entry_fee} onChange={(event) => set("entry_fee", event.target.value)} placeholder="0 = gratuit" className={field} /></div>
  </div>;
}