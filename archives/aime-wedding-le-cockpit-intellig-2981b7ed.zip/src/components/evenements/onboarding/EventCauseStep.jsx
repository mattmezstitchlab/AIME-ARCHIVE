import { eventTypeProfile } from "@/lib/events/eventTypeProfiles";
const CATEGORIES = [["chaussures", "Chaussures"], ["vetements", "Vêtements"], ["couchage", "Couchage"], ["hygiene", "Hygiène"], ["instruments", "Instruments"]];

export default function EventCauseStep({ value, onChange }) {
  const profile = eventTypeProfile(value.event_type);
  const set = (key, next) => onChange({ ...value, [key]: next });
  const toggle = (category) => set("collect_types", value.collect_types.includes(category) ? value.collect_types.filter((item) => item !== category) : [...value.collect_types, category]);
  return <div className="space-y-4">
    <div><label className="text-xs font-bold">Pourquoi agir ensemble ?</label><textarea value={value.description} onChange={(event) => set("description", event.target.value)} rows={4} placeholder={profile.purpose} className="mt-1 w-full rounded-xl border border-border bg-muted px-3 py-2.5 text-xs" /></div>
    <label className="flex items-center gap-3 rounded-xl border border-border p-3"><input type="checkbox" checked={value.collect_donations} onChange={(event) => set("collect_donations", event.target.checked)} /><span className="text-xs font-bold">Rassembler aussi des dons ce jour-là</span></label>
    {value.collect_donations && <div><p className="mb-2 text-[10px] font-bold uppercase tracking-[0.15em] text-muted-foreground">Besoins concernés</p><div className="flex flex-wrap gap-2">{CATEGORIES.map(([id, label]) => <button key={id} type="button" onClick={() => toggle(id)} className={`rounded-full border px-3 py-2 text-[11px] font-bold ${value.collect_types.includes(id) ? "border-foreground bg-foreground text-background" : "border-border"}`}>{label}</button>)}</div></div>}
  </div>;
}