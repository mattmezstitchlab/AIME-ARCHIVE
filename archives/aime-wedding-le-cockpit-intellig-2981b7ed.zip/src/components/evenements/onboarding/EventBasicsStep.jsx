import { useState } from "react";
import { EVENT_TYPES } from "@/lib/events/eventPassportCatalog";
import { eventTypeProfile } from "@/lib/events/eventTypeProfiles";
import { isValidEventDateText } from "@/lib/events/eventDate";
import EventActionRecommendations from "@/components/evenements/EventActionRecommendations";
const field = "mt-1 w-full rounded-xl border border-border bg-muted px-3 py-2.5 text-xs";

export default function EventBasicsStep({ draft, onChange, showValidation = false }) {
  const [dateTouched, setDateTouched] = useState(false);
  const profile = eventTypeProfile(draft.event_type);
  const dateInvalid = (dateTouched || showValidation) && !isValidEventDateText(draft.dateText);
  return <div className="space-y-3">
    <div><label htmlFor="event-type" className="text-xs font-bold">Type d’événement</label><select id="event-type" value={draft.event_type || "autre"} onChange={(event) => onChange({ ...draft, event_type: event.currentTarget.value })} className={field}>{EVENT_TYPES.map(([id, label]) => <option key={id} value={id}>{label}</option>)}</select></div>
    <div><label htmlFor="event-title" className="text-xs font-bold">{profile.title}</label><input id="event-title" value={draft.title || ""} onChange={(event) => onChange({ ...draft, title: event.currentTarget.value })} placeholder={profile.title} className={field} /></div>
    <div className="grid grid-cols-2 gap-3"><div><label htmlFor="event-date" className="text-xs font-bold">Date</label><input id="event-date" type="text" inputMode="numeric" placeholder="JJ/MM/AAAA" aria-describedby="event-date-hint" aria-errormessage={dateInvalid ? "event-date-error" : undefined} aria-invalid={dateInvalid} value={draft.dateText || ""} onChange={(e) => onChange({ ...draft, dateText: e.currentTarget.value })} onBlur={() => setDateTouched(true)} className={field} /><p id="event-date-hint" className="mt-1 text-[10px] text-muted-foreground">Format : jour/mois/année</p>{dateInvalid && <p id="event-date-error" className="mt-1 text-[10px] font-bold text-destructive">Saisissez une date réelle au format JJ/MM/AAAA.</p>}</div><div><label htmlFor="event-city" className="text-xs font-bold">Ville</label><input id="event-city" value={draft.city || ""} onChange={(event) => onChange({ ...draft, city: event.currentTarget.value })} placeholder="Ville" className={field} /></div></div>
    <EventActionRecommendations event={draft} phase="creation" onApply={(item) => onChange({ ...draft, collect_donations: true, collect_types: [...new Set([...(draft.collect_types || []), item.category])] })} />
  </div>;
}