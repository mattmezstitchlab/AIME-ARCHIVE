export default function EventCausalDescription({ description, causal }) {
  return <div className="mt-4 space-y-2 text-xs leading-5">
    {description && <p>{description}</p>}
    {causal?.si && <p className="text-muted-foreground"><strong className="text-foreground">SI</strong> {causal.si} <strong className="text-foreground">ALORS</strong> {causal.alors} <strong className="text-foreground">PARCE QUE</strong> {causal.parceQue}</p>}
  </div>;
}