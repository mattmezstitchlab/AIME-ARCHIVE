import { Sparkles } from "lucide-react";

// Badge discret signalant un profil exemple de démonstration (non revendiqué).
// variant "card" : posé sur l'image. variant "inline" : dans un flux de texte.
export default function SampleBadge({ variant = "inline", className = "" }) {
  if (variant === "card") {
    return (
      <span
        className={`absolute top-3 right-3 inline-flex items-center gap-1 bg-background/90 backdrop-blur text-foreground text-[10px] font-semibold px-2 py-1 rounded-full shadow-sm ${className}`}
      >
        <Sparkles className="w-3 h-3" aria-hidden="true" /> Profil exemple
      </span>
    );
  }

  return (
    <span
      className={`inline-flex items-center gap-1 bg-muted text-muted-foreground text-[11px] font-medium px-2.5 py-1 rounded-full ${className}`}
    >
      <Sparkles className="w-3 h-3" aria-hidden="true" /> Profil exemple
    </span>
  );
}