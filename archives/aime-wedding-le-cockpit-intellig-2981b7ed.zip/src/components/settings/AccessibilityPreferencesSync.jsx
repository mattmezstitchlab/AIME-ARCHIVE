import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import useAccountPreferences from "@/components/settings/useAccountPreferences";

function PreferencesLoader({ me }) { useAccountPreferences(me); return null; }
export default function AccessibilityPreferencesSync() {
  const [me, setMe] = useState(null);
  useEffect(() => { base44.auth.me().then(setMe).catch(() => null); }, []);
  return me ? <PreferencesLoader me={me} /> : null;
}