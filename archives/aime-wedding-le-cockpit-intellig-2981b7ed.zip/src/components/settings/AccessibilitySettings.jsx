import { Accessibility } from "lucide-react";
import PreferenceSwitch from "@/components/settings/PreferenceSwitch";

const OPTIONS = [
  ["high_contrast", "Contraste renforcé", "Renforce la lisibilité des textes et commandes."],
  ["large_text", "Texte agrandi", "Augmente la taille générale sans modifier vos données."],
  ["reduced_motion", "Animations réduites", "Désactive les mouvements non indispensables."],
  ["underline_links", "Liens soulignés", "Identifie les liens sans dépendre de la couleur."],
  ["strong_focus", "Focus clavier renforcé", "Affiche clairement la commande active au clavier."],
  ["reading_spacing", "Lecture aérée", "Augmente l’espacement des lignes et des lettres."],
  ["screen_reader_announcements", "Annonces du lecteur d’écran", "Annonce les confirmations et changements importants."],
];

export default function AccessibilitySettings({ values, save }) {
  return <section aria-labelledby="access-title"><div className="mb-3 flex gap-2"><Accessibility className="h-5 w-5 text-accent" aria-hidden="true" /><div><h3 id="access-title" className="text-xs font-extrabold">Interface et accessibilité</h3><p className="text-[9px] text-muted-foreground">Préférences visuelles, motrices et de lecture.</p></div></div><div className="space-y-2">{OPTIONS.map(([key, label, description]) => <PreferenceSwitch key={key} id={`setting-${key}`} label={label} description={description} checked={values[key]} onChange={(checked) => save({ [key]: checked })} />)}</div></section>;
}