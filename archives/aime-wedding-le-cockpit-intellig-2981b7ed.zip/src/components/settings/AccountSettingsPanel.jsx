import useAccountPreferences from "@/components/settings/useAccountPreferences";
import AccessibilitySettings from "@/components/settings/AccessibilitySettings";
import NotificationSettings from "@/components/settings/NotificationSettings";
import PrivacySecuritySettings from "@/components/settings/PrivacySecuritySettings";
import InternationalSettings from "@/components/settings/InternationalSettings";
import GlobalAuditPanel from "@/components/settings/GlobalAuditPanel";

export default function AccountSettingsPanel({ me }) {
  const { values, save, saving, error } = useAccountPreferences(me);
  return <div className="space-y-4"><p role="status" aria-live="polite" className="min-h-4 text-right text-[9px] text-muted-foreground">{error || (saving ? "Enregistrement…" : "Modifications enregistrées automatiquement")}</p><PrivacySecuritySettings me={me} /><AccessibilitySettings values={values} save={save} /><NotificationSettings values={values} save={save} /><InternationalSettings me={me} values={values} save={save} /><GlobalAuditPanel values={values} /></div>;
}