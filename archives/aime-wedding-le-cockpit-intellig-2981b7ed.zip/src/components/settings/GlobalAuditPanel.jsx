import { useEffect, useState } from "react";
import { AlertTriangle, CheckCircle2, ShieldCheck, XCircle } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function GlobalAuditPanel({ values }) {
  const [identity, setIdentity] = useState(null);
  useEffect(() => { base44.functions.invoke("aimeIdentity", { action: "get" }).then((response) => setIdentity(response.data.identity)); }, []);
  const checks = [
    ["ok", "Parcours événementiel", "Un projet Mariage ou Événement ouvre désormais son onboarding dédié puis son passeport."],
    ["warn", "Routes d’authentification", "Les routes historiques utilisent encore des adresses en majuscules, différentes des adresses normalisées attendues par les liens de récupération."],
    ["warn", "Parcours hérités", "De nombreuses anciennes adresses redirigent vers deux écrans centraux ; chaque intention doit encore être validée manuellement."],
    ["critical", "Accès aux données opérationnelles", "Dons, besoins, relais, réservations, projets, liaisons et événements n’ont pas tous de règles d’accès explicites par propriétaire."],
    ["critical", "Donnée d’accompagnement", "Le contact d’un accompagnateur peut être stocké dans un besoin : son accès doit être strictement limité."],
    [identity?.visibility === "prive" ? "ok" : "warn", "Passeport personnel", identity?.visibility === "prive" ? "Le passeport-mère est privé." : "La visibilité du passeport-mère doit être confirmée."],
    ["ok", "Navigation structurelle", "Un lien d’évitement, une zone principale nommée et des libellés accessibles sont présents."],
    ["ok", "Focus des formulaires", "Les champs affichent désormais un contour visible lors de la navigation au clavier."],
    ["ok", "Cibles tactiles", "Les actions principales et la toolbar respectent une taille tactile confortable."],
    [values.interface_language && values.country_code && values.timezone ? "ok" : "warn", "International", "Langue, pays et fuseau doivent rester synchronisés."],
    ["warn", "Traductions", "Plusieurs écrans historiques restent uniquement en français."],
    ["warn", "Paiements", "Stripe reste en environnement de test ; le parcours publié et les webhooks doivent être validés avant le réel."],
    ["warn", "Validation humaine", "Les parcours clavier, lecteur d’écran, mobile et les cas d’erreur doivent encore être testés manuellement."],
  ];
  const passed = checks.filter(([status]) => status === "ok").length;
  const critical = checks.filter(([status]) => status === "critical").length;
  return <section aria-labelledby="audit-title" className="rounded-2xl border border-border p-4"><div className="flex gap-2"><ShieldCheck className="h-5 w-5 text-accent" /><div><h3 id="audit-title" className="text-xs font-extrabold">Audit global · 20 juillet 2026</h3><p className="text-[9px] text-muted-foreground">{passed}/{checks.length} contrôles stabilisés · {critical} alertes critiques · audit statique, validation humaine requise.</p></div></div><ul className="mt-3 space-y-2">{checks.map(([status, label, detail]) => <li key={label} className="flex gap-2 rounded-xl bg-muted p-3">{status === "ok" ? <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-ink" aria-label="Conforme" /> : status === "critical" ? <XCircle className="mt-0.5 h-4 w-4 shrink-0 text-destructive" aria-label="Critique" /> : <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-fire" aria-label="À finaliser" />}<div><p className="text-[9px] font-bold">{label}</p><p className="text-[8px] leading-4 text-muted-foreground">{detail}</p></div></li>)}</ul></section>;
}