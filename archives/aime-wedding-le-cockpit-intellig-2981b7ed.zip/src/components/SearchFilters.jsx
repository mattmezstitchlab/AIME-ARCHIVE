import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { Star, MapPin, RotateCcw } from "lucide-react";
import { CATEGORY_LIST, CITY_LIST } from "@/lib/categories";
import { RADIUS_OPTIONS, STYLE_OPTIONS, LANGUAGE_OPTIONS, SERVICE_OPTIONS } from "@/lib/search-options";
import DateAvailabilityPicker from "@/components/search/DateAvailabilityPicker";

// Petit pavé de section (titre + contenu) pour structurer les filtres.
function Section({ title, children }) {
  return (
    <div className="pb-5 border-b border-border last:border-0">
      <h3 className="text-sm font-semibold text-foreground mb-3">{title}</h3>
      {children}
    </div>
  );
}

// Chip cochable réutilisable (multi-sélection), accessible.
function PickChip({ label, active, onClick }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={`px-3 py-1.5 min-h-[34px] text-xs font-medium rounded-full border transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 ${
        active ? "bg-foreground text-background border-foreground" : "border-border text-foreground hover:bg-muted"
      }`}
    >
      {label}
    </button>
  );
}

export const DEFAULT_FILTERS = {
  categories: [], cities: [], maxPrice: 500, minRating: 0, availableOnly: false,
  radius: 50, dates: [], styles: [], languages: [], options: [],
};

export default function SearchFilters({ filters, setFilters }) {
  const toggleIn = (key, value) => {
    setFilters(prev => ({
      ...prev,
      [key]: prev[key].includes(value) ? prev[key].filter(v => v !== value) : [...prev[key], value],
    }));
  };

  const set = (key, value) => setFilters(prev => ({ ...prev, [key]: value }));

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <h2 className="sr-only">Filtres de recherche</h2>
        <button
          type="button"
          onClick={() => setFilters(DEFAULT_FILTERS)}
          className="ml-auto flex items-center gap-1 text-xs font-medium text-muted-foreground hover:text-foreground transition-colors"
        >
          <RotateCcw className="w-3 h-3" aria-hidden="true" /> Réinitialiser
        </button>
      </div>

      {/* Rayon & localisation */}
      <Section title="Rayon de déplacement">
        <div className="flex flex-wrap gap-2">
          {RADIUS_OPTIONS.map(r => (
            <PickChip
              key={r.label}
              label={r.label}
              active={filters.radius === r.value}
              onClick={() => set("radius", r.value)}
            />
          ))}
        </div>
      </Section>

      <Section title="Villes">
        <div className="space-y-2 max-h-36 overflow-y-auto pr-1">
          {CITY_LIST.map(city => (
            <label key={city} className="flex items-center gap-2 cursor-pointer">
              <Checkbox checked={filters.cities.includes(city)} onCheckedChange={() => toggleIn("cities", city)} />
              <span className="text-sm text-foreground flex items-center gap-1">
                <MapPin className="w-3 h-3" aria-hidden="true" />{city}
              </span>
            </label>
          ))}
        </div>
      </Section>

      <Section title="Catégories">
        <div className="space-y-2">
          {CATEGORY_LIST.map(cat => (
            <label key={cat.slug} className="flex items-center gap-2 cursor-pointer">
              <Checkbox checked={filters.categories.includes(cat.name)} onCheckedChange={() => toggleIn("categories", cat.name)} />
              <span className="text-sm text-foreground">{cat.title}</span>
            </label>
          ))}
        </div>
      </Section>

      {/* Jours précis & budget */}
      <Section title="Disponibilités à des jours précis">
        <DateAvailabilityPicker
          dates={filters.dates}
          onChange={(dates) => set("dates", dates)}
        />
        <label htmlFor="filter-dispo" className="flex items-center justify-between mt-3">
          <span className="text-sm font-medium text-foreground cursor-pointer">Disponible uniquement</span>
          <Switch
            id="filter-dispo"
            checked={filters.availableOnly}
            onCheckedChange={(v) => set("availableOnly", v)}
          />
        </label>
      </Section>

      <Section title="Prix maximum">
        <div className="px-1">
          <Slider
            value={[filters.maxPrice]}
            onValueChange={([v]) => set("maxPrice", v)}
            max={500}
            min={50}
            step={10}
            aria-label="Prix maximum en euros"
            aria-valuetext={`Jusqu'à ${filters.maxPrice} euros`}
          />
          <p className="text-sm text-muted-foreground mt-2">Jusqu'à <span className="font-semibold text-foreground">{filters.maxPrice}€</span></p>
        </div>
      </Section>

      <Section title="Note minimale">
        <div className="flex items-center gap-2" role="group" aria-label="Note minimale">
          {[0, 3, 4, 4.5].map(r => (
            <button
              key={r}
              type="button"
              onClick={() => set("minRating", r)}
              aria-pressed={filters.minRating === r}
              aria-label={r === 0 ? "Toutes les notes" : `Au moins ${r} étoiles`}
              className={`px-3 py-1.5 min-h-[36px] text-xs font-medium rounded-full border transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 ${
                filters.minRating === r ? "bg-foreground text-background border-foreground" : "border-border text-foreground hover:bg-muted"
              }`}
            >
              {r === 0 ? "Tous" : (
                <span className="flex items-center gap-1">{r}<Star className="w-3 h-3 fill-current" aria-hidden="true" /></span>
              )}
            </button>
          ))}
        </div>
      </Section>

      {/* Style, langues & options */}
      <Section title="Style / ambiance">
        <div className="flex flex-wrap gap-2">
          {STYLE_OPTIONS.map(s => (
            <PickChip key={s} label={s} active={filters.styles.includes(s)} onClick={() => toggleIn("styles", s)} />
          ))}
        </div>
      </Section>

      <Section title="Langues parlées">
        <div className="flex flex-wrap gap-2">
          {LANGUAGE_OPTIONS.map(l => (
            <PickChip key={l} label={l} active={filters.languages.includes(l)} onClick={() => toggleIn("languages", l)} />
          ))}
        </div>
      </Section>

      <Section title="Options & services">
        <div className="flex flex-wrap gap-2">
          {SERVICE_OPTIONS.map(o => (
            <PickChip key={o} label={o} active={filters.options.includes(o)} onClick={() => toggleIn("options", o)} />
          ))}
        </div>
      </Section>
    </div>
  );
}

export { SearchFilters };