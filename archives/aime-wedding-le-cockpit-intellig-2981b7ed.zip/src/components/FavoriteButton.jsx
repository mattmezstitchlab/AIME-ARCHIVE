import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Heart } from "lucide-react";

export default function FavoriteButton({ artist, variant = "card" }) {
  const navigate = useNavigate();
  const [favorite, setFavorite] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    let active = true;
    base44.auth.me()
      .then((user) => base44.entities.Favorite.filter({ artist_id: artist.id, created_by_id: user.id }))
      .then((list) => { if (active) setFavorite(list[0] || null); })
      .catch(() => {});
    return () => { active = false; };
  }, [artist.id]);

  const toggle = async (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (loading) return;
    setLoading(true);
    try {
      await base44.auth.me();
    } catch {
      navigate("/Login");
      setLoading(false);
      return;
    }
    try {
      if (favorite) {
        await base44.entities.Favorite.delete(favorite.id);
        setFavorite(null);
      } else {
        const created = await base44.entities.Favorite.create({
          artist_id: artist.id,
          artist_name: artist.name,
          artist_image_url: artist.image_url,
          artist_specialty: artist.specialty,
          artist_location: artist.location,
        });
        setFavorite(created);
      }
    } catch {
      // silencieux : on ne casse pas l'UI
    }
    setLoading(false);
  };

  const isFav = !!favorite;
  const name = artist.name || "cet artiste";
  const focusRing = "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:opacity-50 disabled:pointer-events-none";
  const base = variant === "detail"
    ? `w-11 h-11 rounded-full bg-background border border-border flex items-center justify-center hover:bg-muted transition-colors ${focusRing}`
    : `absolute top-3 right-3 w-9 h-9 rounded-full bg-background/90 backdrop-blur flex items-center justify-center hover:bg-background transition-colors ${focusRing}`;

  return (
    <button
      type="button"
      onClick={toggle}
      disabled={loading}
      aria-pressed={isFav}
      aria-label={isFav ? `Retirer ${name} des favoris` : `Ajouter ${name} aux favoris`}
      title={isFav ? `Retirer ${name} des favoris` : `Ajouter ${name} aux favoris`}
      className={base}
    >
      <Heart className={`w-5 h-5 transition-colors ${isFav ? "fill-foreground text-foreground" : "text-muted-foreground"}`} aria-hidden="true" />
    </button>
  );
}