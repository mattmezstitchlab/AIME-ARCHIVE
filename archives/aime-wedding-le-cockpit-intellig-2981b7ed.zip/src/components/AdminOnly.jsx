import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Lock } from "lucide-react";
import { base44 } from "@/api/base44Client";

// GARDE ADMIN — certaines pages (Design System du site, Santé du site,
// génération d'articles) sont réservées à l'administrateur du site AIME®.
// Les utilisateurs auront leurs propres outils pour LEUR site, dans le Canvas.
export default function AdminOnly({ children }) {
  const [etat, setEtat] = useState("chargement"); // chargement | ok | non

  useEffect(() => {
    base44.auth
      .me()
      .then((u) => setEtat(u?.role === "admin" ? "ok" : "non"))
      .catch(() => setEtat("non"));
  }, []);

  if (etat === "chargement") {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#0C0C0C]">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-white/15 border-t-white" />
      </div>
    );
  }
  if (etat === "non") {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-[#0C0C0C] px-6 text-center text-white">
        <Lock className="h-8 w-8 text-white/30" />
        <h1 className="mt-4 font-heading text-2xl font-light">Espace réservé</h1>
        <p className="mt-2 max-w-sm text-[13px] leading-relaxed text-white/50">
          Cette page est réservée à l'administrateur du site. Les mêmes outils vous
          seront fournis pour votre propre site, dans le Canvas.
        </p>
        <Link to="/" className="mt-5 text-[13px] text-[#c9a96e] underline underline-offset-4">
          ← Revenir à l'accueil
        </Link>
      </div>
    );
  }
  return children;
}