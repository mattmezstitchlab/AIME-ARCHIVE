import { trier } from "@/lib/eventos/model";
import { appliquerSolution } from "@/lib/eventos/engine";
import CadranCausal from "@/components/eventos/CadranCausal";
import RapportSignal from "@/components/eventos/RapportSignal";
import SolutionsPanel from "@/components/eventos/SolutionsPanel";

// ÉTAPE 5 — SIMULER. Les réglages vivent dans la colonne de droite du
// Studio (V2SimulerReglages) ; ici : le cadran, et la chaîne cause →
// absorption → impacts → explications juste en dessous.
export default function V2Simuler({ etat, setEtat, monRole, cible, setCible }) {
  const ordre = trier(etat.moments);
  const cibleEff = cible || ordre[0]?.id;
  const dernier = etat.journal[0];
  const rapport = dernier?.signal || dernier?.decision || dernier?.decisionRequise ? dernier : null;

  return (
    <div className="mx-auto max-w-3xl px-5 pb-10">
      <h2 className="text-xl font-extrabold text-[#1D1D1F]">Simuler la vraie vie</h2>
      <p className="mt-0.5 text-[12px] text-[#6E6E73]">Réglez le scénario dans la colonne de droite — tout est réversible.</p>

      <div className="mt-4 flex justify-center rounded-3xl border border-[#D2D2D7] bg-white p-6">
        <div className="w-full max-w-md">
          <CadranCausal etat={etat} selection={cibleEff} onSelect={setCible} titreCentre="Simulation" />
        </div>
      </div>

      {/* La chaîne complète, juste sous le cadran. */}
      <div className="mt-4 space-y-3">
        {rapport ? <RapportSignal rapport={rapport} /> : (
          <p className="rounded-2xl border border-[#D2D2D7] bg-white p-4 text-[12px] text-[#6E6E73]">
            Lancez un scénario (colonne de droite) : la chaîne cause → absorption → impacts → protégés → conflits → solutions → décision s'affichera ici.
          </p>
        )}
        {rapport?.decisionRequise && rapport.solutionsCandidates?.length > 0 && (
          <SolutionsPanel solutions={rapport.solutionsCandidates}
            onValider={(s) => setEtat(appliquerSolution(etat, s, monRole || "organisateur"))} />
        )}
      </div>
    </div>
  );
}