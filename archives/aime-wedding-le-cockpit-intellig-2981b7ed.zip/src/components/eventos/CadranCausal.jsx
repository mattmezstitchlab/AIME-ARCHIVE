import { useMemo } from "react";
import { fin, trier, enHM, ROLES_V2 } from "@/lib/eventos/model";

// LE CADRAN CAUSAL — dans l'esprit du Cadran Play Jour J : disque noir,
// segments vifs arrondis par rôle, aiguille blanche vers l'heure, heure mono
// au centre, légende des rôles. SVG réel : les cordes proviennent des MÊMES
// relations que celles consommées par le moteur, alternative textuelle rendue.
const rad = (deg) => ((deg - 90) * Math.PI) / 180;
const pt = (cx, cy, r, deg) => [cx + r * Math.cos(rad(deg)), cy + r * Math.sin(rad(deg))];

export default function CadranCausal({ etat, selection, onSelect, heureDemo = null, titreCentre, clair = true }) {
  const ordre = useMemo(() => trier(etat.moments), [etat.moments]);
  const debut = (ordre[0]?.start ?? 0) - 60;
  const total = (fin(ordre[ordre.length - 1] || { start: 60, dur: 0 }) + 60) - debut;
  const angle = (mins) => ((mins - debut) / total) * 360;
  const cx = 180, cy = 180, R = 128, EP = 14;
  const couleurRole = (role) => ROLES_V2.find((r) => r.id === role)?.couleur || "#4ADE9E";
  const rolesPresents = ROLES_V2.filter((r) => ordre.some((m) => m.role === r.id));

  const arc = (a1, a2, r) => {
    const [x1, y1] = pt(cx, cy, r, a1), [x2, y2] = pt(cx, cy, r, a2);
    return `M ${x1} ${y1} A ${r} ${r} 0 ${a2 - a1 > 180 ? 1 : 0} 1 ${x2} ${y2}`;
  };
  const milieu = (m) => pt(cx, cy, R - EP - 22, angle(m.start + m.dur / 2));
  const [ax, ay] = heureDemo !== null ? pt(cx, cy, R - EP - 6, angle(heureDemo)) : [cx, cy];

  return (
    <div>
      <div className="mx-auto w-full max-w-[360px] rounded-full bg-[#111214] p-4" style={{ boxShadow: "0 0 0 1px rgba(255,255,255,0.06), 0 18px 50px rgba(0,0,0,0.5)" }}>
        <svg viewBox="0 0 360 360" role="img" className="w-full"
          aria-label={`Cadran causal : ${ordre.length} moments de ${enHM(ordre[0]?.start ?? 0)} à ${enHM(fin(ordre[ordre.length - 1] || { start: 0, dur: 0 }))}.`}>
          {/* Le disque noir et son anneau de fond. */}
          <circle cx={cx} cy={cy} r={R + EP + 10} fill="#0C0D0F" />
          <circle cx={cx} cy={cy} r={R} fill="none" stroke="#1E2023" strokeWidth={EP} />
          {/* LES CORDES — dessinées depuis etat.relations, la donnée du moteur. */}
          {etat.relations.map((r, i) => {
            const de = ordre.find((m) => m.id === r.de), vers = ordre.find((m) => m.id === r.vers);
            if (!de || !vers) return null;
            const [x1, y1] = milieu(de), [x2, y2] = milieu(vers);
            return <path key={i} d={`M ${x1} ${y1} Q ${cx} ${cy} ${x2} ${y2}`} fill="none"
              stroke={couleurRole(de.role)} strokeOpacity="0.2" strokeWidth="1.5" strokeDasharray={r.type === "termine-avant" ? "4 3" : undefined} />;
          })}
          {/* LES SEGMENTS VIFS — un arc arrondi par moment, couleur du rôle. */}
          {ordre.map((m) => {
            const a1 = angle(m.start) + 2, a2 = angle(fin(m)) - 2;
            const actif = selection === m.id;
            return (
              <path key={m.id} d={arc(a1, Math.max(a1 + 2, a2), R)} fill="none" stroke={couleurRole(m.role)}
                strokeWidth={actif ? EP + 8 : EP} strokeLinecap="round" tabIndex={0} role="button"
                aria-label={`${m.label}, ${enHM(m.start)} à ${enHM(fin(m))}${m.fixe ? ", horaire immuable" : ""}${m.sacre ? ", moment sacré" : ""}`}
                className="cursor-pointer outline-none"
                style={actif ? { filter: `drop-shadow(0 0 8px ${couleurRole(m.role)})` } : undefined}
                onClick={() => onSelect?.(m.id)}
                onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && (e.preventDefault(), onSelect?.(m.id))} />
            );
          })}
          {/* L'AIGUILLE BLANCHE — pointe l'heure en cours (mode direct). */}
          {heureDemo !== null && (
            <>
              <line x1={cx} y1={cy} x2={ax} y2={ay} stroke="#FFFFFF" strokeWidth="2.5" strokeLinecap="round" />
              <circle cx={cx} cy={cy} r="7" fill="#FFFFFF" />
            </>
          )}
          {/* LE CENTRE — titre, heure mono, état. */}
          <text x={cx} y={heureDemo !== null ? cy - 26 : cy - 4} textAnchor="middle" fontSize="11" fontWeight="600" fill="rgba(255,255,255,0.45)" letterSpacing="2" style={{ textTransform: "uppercase" }}>
            {(titreCentre || "Cadran Causal").toUpperCase()}
          </text>
          {heureDemo !== null ? (
            <>
              <text x={cx} y={cy + 34} textAnchor="middle" fontSize="26" fontFamily="monospace" fontWeight="700" fill="#FFFFFF">{enHM(heureDemo)}</text>
              <text x={cx} y={cy + 52} textAnchor="middle" fontSize="8.5" fill="rgba(255,255,255,0.4)" letterSpacing="3">EN COURS · DÉMO</text>
            </>
          ) : (
            <text x={cx} y={cy + 16} textAnchor="middle" fontSize="9" fill="rgba(255,255,255,0.4)" letterSpacing="3">MOTEUR CAUSAL · ACTIF</text>
          )}
        </svg>
      </div>

      {/* LA LÉGENDE — un point vif par rôle présent, façon Play Jour J. */}
      <ul className="mx-auto mt-4 flex max-w-md flex-wrap justify-center gap-x-4 gap-y-1.5" aria-label="Légende des rôles">
        {rolesPresents.map((r) => (
          <li key={r.id} className={`flex items-center gap-1.5 font-mono text-[10px] font-semibold uppercase tracking-[0.14em] ${clair ? "text-[#6E6E73]" : "text-white/60"}`}>
            <span className="h-2.5 w-2.5 rounded-full" style={{ background: r.couleur }} aria-hidden="true" />
            {r.label}
          </li>
        ))}
      </ul>

    </div>
  );
}