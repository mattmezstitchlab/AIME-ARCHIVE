import { useEffect, useState } from "react";
import { trier, ROLES_V2, enHM } from "@/lib/eventos/model";
import { genererDepeches } from "@/lib/eventos/dispatch";
import CadranCausal from "@/components/eventos/CadranCausal";
import VueRole from "@/components/eventos/VueRole";
import V2Simuler from "@/components/eventos/V2Simuler";

// ÉTAPE 7 — PILOTER. Cadran en direct, horloge de démonstration étiquetée
// (mode heure réelle disponible), perturbations injectables, dépêches par
// rôle et main courante — le tout sur le même état causal.
export default function V2Piloter({ etat, setEtat, monRole }) {
  const ordre = trier(etat.moments);
  const [modeReel, setModeReel] = useState(false);
  const [heure, setHeure] = useState(ordre[0]?.start ?? 9 * 60);
  const [roleVue, setRoleVue] = useState(monRole || "organisateur");

  useEffect(() => {
    const t = setInterval(() => {
      if (modeReel) { const d = new Date(); setHeure(d.getHours() * 60 + d.getMinutes()); }
      else setHeure((h) => h + 1); // 1 min simulée / seconde — démo étiquetée
    }, modeReel ? 15000 : 1000);
    return () => clearInterval(t);
  }, [modeReel]);

  const rapport = etat.journal.find((j) => j.signal || j.decision);
  const depeches = rapport?.signal ? genererDepeches(etat, rapport) : [];

  return (
    <div className="mx-auto max-w-6xl px-5 pb-16">
      <div className="flex flex-wrap items-center gap-3">
        <h2 className="text-2xl font-extrabold text-[#1D1D1F]">Piloter le direct</h2>
        <button role="switch" aria-checked={modeReel} onClick={() => setModeReel(!modeReel)}
          className="flex min-h-[44px] items-center gap-2 rounded-full border border-[#D2D2D7] bg-white px-4 text-[12px] font-semibold text-[#1D1D1F]">
          <span className={`h-5 w-9 rounded-full transition ${modeReel ? "bg-[#0071E3]" : "bg-[#D2D2D7]"}`} aria-hidden="true">
            <span className={`block h-4 w-4 translate-y-0.5 rounded-full bg-white transition-transform ${modeReel ? "translate-x-4" : "translate-x-0.5"}`} />
          </span>
          {modeReel ? "Heure réelle" : "Horloge de démonstration (1 min/s)"}
        </button>
      </div>

      <div className="mt-5 grid gap-6 lg:grid-cols-[1fr_380px]">
        <div className="rounded-3xl border border-[#D2D2D7] bg-white p-4">
          <CadranCausal etat={etat} heureDemo={heure} titreCentre={etat.nom?.split("—")[0]?.trim() || "En direct"} />
        </div>
        <div className="space-y-4">
          <div>
            <label className="text-[11px] font-bold uppercase tracking-wide text-[#6E6E73]" htmlFor="vue-role">Voir comme</label>
            <select id="vue-role" value={roleVue} onChange={(e) => setRoleVue(e.target.value)}
              className="mt-1 block min-h-[44px] w-full rounded-xl border border-[#D2D2D7] bg-white px-3 text-[13px]">
              {ROLES_V2.map((r) => <option key={r.id} value={r.id}>{r.label}</option>)}
            </select>
          </div>
          <VueRole etat={etat} roleVue={roleVue} depeches={depeches} />
          {depeches.length > 0 && (
            <div className="rounded-2xl border border-[#D2D2D7] bg-white p-4" aria-live="polite">
              <p className="text-[13px] font-extrabold text-[#1D1D1F]">Dépêches <span className="rounded-full bg-[#F5E6B8] px-2 py-0.5 text-[10px] font-bold text-[#7A6320]">MODE DÉMONSTRATION — rien n'est envoyé</span></p>
              <ul className="mt-2 space-y-2">
                {depeches.filter((d) => roleVue === "organisateur" || roleVue === "coordination" || d.destinataire === roleVue).map((d, i) => (
                  <li key={i} className="rounded-xl bg-[#F5F5F7] p-3 text-[12.5px] text-[#424245]">
                    <p className="font-bold text-[#1D1D1F]">→ {ROLES_V2.find((r) => r.id === d.destinataire)?.label || d.destinataire} · urgence {d.urgence}</p>
                    <p>Cause : {d.cause}</p><p>Instruction : {d.instruction}</p><p>Effet : {d.heureEffet}</p>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>

      {/* Injecter une perturbation en direct — même moteur que la simulation. */}
      <div className="mt-8"><V2Simuler etat={etat} setEtat={setEtat} monRole={monRole} /></div>

      {/* MAIN COURANTE — la trace complète, persistée avec l'état. */}
      <div className="mx-5 rounded-2xl border border-[#D2D2D7] bg-white p-4">
        <h3 className="text-[13px] font-extrabold text-[#1D1D1F]">Main courante</h3>
        {etat.journal.length === 0 ? <p className="mt-1 text-[12.5px] text-[#6E6E73]">Aucun événement tracé pour l'instant.</p> : (
          <ol className="mt-2 space-y-2">
            {etat.journal.slice(0, 20).map((j, i) => (
              <li key={i} className="border-l-2 border-[#D2D2D7] pl-3 text-[12.5px] text-[#424245]">
                <span className="font-mono text-[11px] text-[#6E6E73]">{new Date(j.horodatage).toLocaleTimeString("fr-FR")}</span>
                {" — "}
                {j.signal ? `Signal : ${j.signal.type} ${j.perturbationInitiale} min · absorbé ${j.margeConsommee} · compression ${j.compressionRealisee}/${j.compressionDemandee} · conflit restant ${j.conflitRestant}${j.decisionRequise ? " · DÉCISION REQUISE" : ""}`
                  : j.decision ? `Décision : ${j.decision}${j.validePar ? ` (validée par ${j.validePar})` : ""}` : (j.explication?.[0] || "Événement")}
              </li>
            ))}
          </ol>
        )}
      </div>
    </div>
  );
}