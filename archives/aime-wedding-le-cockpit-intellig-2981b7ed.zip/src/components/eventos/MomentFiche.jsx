import { enHM, ROLES_V2 } from "@/lib/eventos/model";

// FICHE D'UN MOMENT — toutes les politiques éditables. Interrupteurs
// accessibles : role="switch" + aria-checked, cibles ≥ 44 px.
function Interrupteur({ label, aide, actif, onChange }) {
  return (
    <button role="switch" aria-checked={actif} onClick={() => onChange(!actif)}
      className="flex min-h-[44px] w-full items-center justify-between gap-3 rounded-xl border border-[#D2D2D7] bg-white px-3 text-left hover:border-[#86868B]">
      <span>
        <span className="block text-[13px] font-semibold text-[#1D1D1F]">{label}</span>
        {aide && <span className="block text-[11px] text-[#6E6E73]">{aide}</span>}
      </span>
      <span className={`relative h-7 w-12 shrink-0 rounded-full transition ${actif ? "bg-[#0071E3]" : "bg-[#D2D2D7]"}`} aria-hidden="true">
        <span className={`absolute top-1 h-5 w-5 rounded-full bg-white transition-all ${actif ? "left-6" : "left-1"}`} />
      </span>
    </button>
  );
}

export default function MomentFiche({ moment, onChange, onSupprimer, onFermer }) {
  const maj = (patch) => onChange({ ...moment, ...patch });
  const Champ = ({ label, enfants }) => (
    <label className="block">
      <span className="text-[11px] font-bold uppercase tracking-wide text-[#6E6E73]">{label}</span>
      {enfants}
    </label>
  );
  const inputCls = "mt-1 min-h-[44px] w-full rounded-xl border border-[#D2D2D7] bg-white px-3 text-[13px] text-[#1D1D1F] outline-none focus:border-[#0071E3]";

  return (
    <div className="rounded-2xl border border-[#D2D2D7] bg-[#F5F5F7] p-4">
      <div className="flex items-center justify-between">
        <h3 className="text-[15px] font-extrabold text-[#1D1D1F]">{moment.label}</h3>
        <button onClick={onFermer} className="min-h-[44px] min-w-[44px] rounded-full text-[#6E6E73] hover:bg-[#EAEAEC]" aria-label="Fermer la fiche">✕</button>
      </div>
      <div className="mt-3 grid gap-3 sm:grid-cols-2">
        <Champ label="Nom" enfants={<input className={inputCls} value={moment.label} onChange={(e) => maj({ label: e.target.value })} />} />
        <Champ label="Rôle responsable" enfants={
          <select className={inputCls} value={moment.role} onChange={(e) => maj({ role: e.target.value })}>
            {ROLES_V2.map((r) => <option key={r.id} value={r.id}>{r.label}</option>)}
          </select>} />
        <Champ label={`Début (${enHM(moment.start)})`} enfants={
          <input type="time" className={inputCls} value={enHM(moment.start)}
            onChange={(e) => { const [h, m] = e.target.value.split(":").map(Number); maj({ start: h * 60 + m }); }} />} />
        <Champ label="Durée (min)" enfants={<input type="number" min={5} className={inputCls} value={moment.dur} onChange={(e) => maj({ dur: Math.max(5, +e.target.value || 5) })} />} />
        <Champ label="Durée minimale (min)" enfants={<input type="number" min={5} className={inputCls} value={moment.durMin} onChange={(e) => maj({ durMin: Math.max(5, +e.target.value || 5) })} />} />
        <Champ label="Lieu" enfants={<input className={inputCls} value={moment.lieu} onChange={(e) => maj({ lieu: e.target.value })} />} />
        <Champ label="Priorité (1-5)" enfants={<input type="number" min={1} max={5} className={inputCls} value={moment.priorite} onChange={(e) => maj({ priorite: Math.min(5, Math.max(1, +e.target.value || 3)) })} />} />
        <Champ label="Qui décide en cas de problème ?" enfants={<input className={inputCls} value={moment.decideur} onChange={(e) => maj({ decideur: e.target.value })} />} />
      </div>
      <div className="mt-3 grid gap-2 sm:grid-cols-2">
        <Interrupteur label="Horaire immuable" aide="Ne bougera jamais : tout se réorganise autour." actif={moment.fixe} onChange={(v) => maj({ fixe: v })} />
        <Interrupteur label="Moment sacré" aide="Protégé en priorité par toutes les décisions." actif={moment.sacre} onChange={(v) => maj({ sacre: v })} />
        <Interrupteur label="Peut être raccourci" aide={`Jusqu'à sa durée minimale (${moment.durMin} min).`} actif={moment.compressible} onChange={(v) => maj({ compressible: v })} />
        <Interrupteur label="Optionnel" aide="Peut être reporté ou supprimé si nécessaire." actif={moment.optionnel} onChange={(v) => maj({ optionnel: v })} />
      </div>
      <label className="mt-3 block">
        <span className="text-[11px] font-bold uppercase tracking-wide text-[#6E6E73]">Plan alternatif (Plan B)</span>
        <textarea className="mt-1 w-full rounded-xl border border-[#D2D2D7] bg-white p-3 text-[13px] text-[#1D1D1F] outline-none focus:border-[#0071E3]"
          rows={2} value={moment.planB || ""} placeholder="Ex. repli dans l'orangerie en cas de pluie"
          onChange={(e) => maj({ planB: e.target.value || null })} />
      </label>
      <button onClick={onSupprimer} className="mt-3 min-h-[44px] rounded-full border border-[#E8B4A0] px-4 text-[12px] font-semibold text-[#B4573B] hover:bg-[#FDF3EF]">
        Retirer ce moment
      </button>
    </div>
  );
}