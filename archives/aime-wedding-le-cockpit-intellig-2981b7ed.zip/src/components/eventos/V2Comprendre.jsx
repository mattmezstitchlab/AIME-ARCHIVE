import { useState } from "react";

// ÉTAPE 2 — NOUS COMPRENDRE. Une question principale par écran, avec
// l'explication de son utilité. Alimente exactement le même modèle que le
// mode direct (meta + politiques appliquées au template).
const QUESTIONS = [
  { id: "celebre", q: "Qui ou quoi célèbre-t-on ?", aide: "Ce nom devient le cœur de votre événement — il apparaît partout.", type: "texte", placeholder: "Ex. Léa & Tom" },
  { id: "date", q: "Quelle est la date ?", aide: "La date permet de parler en vrais horaires, pas en abstrait.", type: "date" },
  { id: "lieux", q: "Quels sont les lieux ?", aide: "Un moment dans un autre lieu implique un déplacement — le moteur en tiendra compte.", type: "texte", placeholder: "Ex. Mairie de Lyon, Domaine des Cyprès" },
  { id: "invites", q: "Combien de personnes sont attendues ?", aide: "Le nombre influence les durées réalistes (repas, photos, déplacements).", type: "nombre", placeholder: "Ex. 80" },
  { id: "sacres", q: "Quels moments comptent le plus pour vous ?", aide: "Ces moments seront protégés en priorité par toutes les décisions.", type: "texte", placeholder: "Ex. la cérémonie, l'ouverture du bal" },
  { id: "immuables", q: "Quels horaires sont immuables ?", aide: "Un horaire immuable (mairie, coucher du soleil…) ne bougera jamais : tout se réorganisera autour.", type: "texte", placeholder: "Ex. mairie à 15h00" },
  { id: "flexibles", q: "Quels moments peuvent bouger sans drame ?", aide: "Plus il y a de souplesse déclarée, plus les imprévus s'absorbent tout seuls.", type: "texte", placeholder: "Ex. le cocktail peut être raccourci" },
  { id: "decideur", q: "Qui décide en cas de problème ?", aide: "Quand un conflit ne peut pas se résoudre tout seul, cette personne tranche.", type: "texte", placeholder: "Ex. Marie, notre témoin-coordinatrice" },
];

export default function V2Comprendre({ onTerminer, onRetour }) {
  const [i, setI] = useState(0);
  const [reponses, setReponses] = useState({});
  const q = QUESTIONS[i];
  const valeur = reponses[q.id] || "";

  const suivant = () => {
    if (i < QUESTIONS.length - 1) setI(i + 1);
    else onTerminer(reponses);
  };

  return (
    <div className="mx-auto max-w-xl px-5 pb-16">
      <p className="font-mono text-[11px] font-bold uppercase tracking-[0.2em] text-[#0071E3]">
        Question {i + 1} sur {QUESTIONS.length}
      </p>
      <div className="mt-2 h-1.5 w-full rounded-full bg-[#D2D2D7]" role="progressbar"
        aria-valuenow={i + 1} aria-valuemin={1} aria-valuemax={QUESTIONS.length} aria-label="Progression des questions">
        <div className="h-1.5 rounded-full bg-[#0071E3] transition-all" style={{ width: `${((i + 1) / QUESTIONS.length) * 100}%` }} />
      </div>
      <h2 className="mt-6 text-2xl font-extrabold text-[#1D1D1F]">{q.q}</h2>
      <p className="mt-2 rounded-xl bg-[#F5F5F7] p-3 text-[13px] leading-5 text-[#424245]">
        <span className="font-bold">Pourquoi cette question ? </span>{q.aide}
      </p>
      <label className="mt-5 block">
        <span className="sr-only">{q.q}</span>
        <input
          type={q.type === "date" ? "date" : q.type === "nombre" ? "number" : "text"}
          value={valeur} placeholder={q.placeholder} autoFocus
          onChange={(e) => setReponses({ ...reponses, [q.id]: e.target.value })}
          onKeyDown={(e) => e.key === "Enter" && suivant()}
          className="min-h-[48px] w-full rounded-2xl border-2 border-[#D2D2D7] bg-white px-4 text-[15px] text-[#1D1D1F] outline-none focus:border-[#0071E3]"
        />
      </label>
      <div className="mt-5 flex items-center gap-3">
        <button onClick={() => (i > 0 ? setI(i - 1) : onRetour())}
          className="min-h-[44px] rounded-full border-2 border-[#D2D2D7] px-5 text-[13px] font-semibold text-[#1D1D1F] hover:border-[#0071E3]">
          ← Retour
        </button>
        <button onClick={suivant}
          className="min-h-[44px] rounded-full bg-[#0071E3] px-6 text-[13px] font-bold text-white hover:bg-[#0077ED]">
          {i < QUESTIONS.length - 1 ? "Continuer →" : "Générer ma première partition →"}
        </button>
        <button onClick={suivant} className="ml-auto text-[12px] text-[#6E6E73] underline underline-offset-2">Passer</button>
      </div>
    </div>
  );
}