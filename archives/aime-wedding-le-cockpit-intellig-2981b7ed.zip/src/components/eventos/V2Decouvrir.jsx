import { useState } from "react";
import { ROLES_V2, trier, enHM } from "@/lib/eventos/model";
import { templateWedding } from "@/lib/eventos/templates";
import { appliquerSignal } from "@/lib/eventos/engine";
import CadranCausal from "@/components/eventos/CadranCausal";
import RapportSignal from "@/components/eventos/RapportSignal";

const COULEURS = Object.fromEntries(ROLES_V2.map((r) => [r.id, r.couleur]));

// ÉTAPE 1 — DÉCOUVRIR, tout sur UN écran : en haut le titre + « Qui
// êtes-vous ? » en menu déroulant et les deux entrées ; au corps, les
// horaires à gauche, le cadran au centre, et le rapport (cause →
// absorption → impacts → explications) juste sous le cadran.
export default function V2Decouvrir({ onEntrer }) {
  const [demo, setDemo] = useState(() => templateWedding({ exemple: true }));
  const [rapport, setRapport] = useState(null);
  const [role, setRole] = useState("");

  const simulerDemo = () => {
    const r = appliquerSignal(demo, { type: "retard", cibleId: "cortege", minutes: 15 });
    setDemo(r.etat); setRapport(r.rapport);
  };

  return (
    <div className="mx-auto max-w-6xl px-5 pb-8">
      <section className="rounded-[28px] bg-black px-5 py-6 sm:px-8">
        {/* EN-TÊTE — titre à gauche, rôle + entrées à droite. */}
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-[12px] font-semibold text-white/60">AIME Event OS · démonstration réelle du moteur</p>
            <h1 className="mt-1 text-2xl font-semibold tracking-tight text-white sm:text-3xl">
              Un Jour J simple, humain et clair.
            </h1>
          </div>
          <div className="flex flex-wrap items-end gap-2">
            <label className="block text-left">
              <span className="block text-[10px] font-bold uppercase tracking-wide text-white/50">Qui êtes-vous ?</span>
              <select value={role} onChange={(e) => setRole(e.target.value)}
                className="mt-1 block min-h-[44px] rounded-full border border-white/20 bg-white/10 px-4 pr-8 text-[13px] font-medium text-white">
                <option value="" className="text-black">Choisir mon rôle…</option>
                {ROLES_V2.map((r) => (
                  <option key={r.id} value={r.id} className="text-black">{r.label}</option>
                ))}
              </select>
            </label>
            <button disabled={!role} onClick={() => onEntrer(role, "guide")}
              className="min-h-[44px] rounded-full bg-[#0071E3] px-5 text-[13px] font-medium text-white transition hover:bg-[#0077ED] disabled:opacity-40">
              Guidez-moi pas à pas
            </button>
            <button disabled={!role} onClick={() => onEntrer(role, "direct")}
              className="min-h-[44px] rounded-full border border-[#2997FF] px-5 text-[13px] font-medium text-[#2997FF] transition hover:bg-white/5 disabled:opacity-40">
              Mode direct
            </button>
          </div>
        </div>

        {/* CORPS — horaires à gauche · cadran + rapport au centre. */}
        <div className="mt-6 grid gap-6 lg:grid-cols-[230px_1fr]">
          {/* LES HORAIRES — la journée, dans l'ordre, à gauche. */}
          <aside aria-label="Les horaires de la journée" className="text-left">
            <p className="mb-2 text-[10px] font-bold uppercase tracking-wide text-white/50">Les horaires</p>
            <ol className="space-y-1">
              {trier(demo.moments).map((m) => (
                <li key={m.id} className="flex items-center gap-2 rounded-lg bg-white/[0.06] px-2.5 py-1.5">
                  <span className="font-mono text-[11px] text-white/70">{enHM(m.start)}</span>
                  <span className="h-2 w-2 shrink-0 rounded-full" style={{ background: COULEURS[m.role] || "#fff" }} aria-hidden="true" />
                  <span className="truncate text-[12px] text-white/85">{m.label}</span>
                </li>
              ))}
            </ol>
            <p className="mt-3 text-[10px] text-white/40">Données d'exemple (Léa & Tom) · rien n'est envoyé</p>
          </aside>

          {/* LE CADRAN + LE RAPPORT juste en dessous. */}
          <div>
            <div className="flex justify-center">
              <button onClick={simulerDemo}
                className="min-h-[44px] rounded-full bg-[#0071E3] px-6 text-[14px] font-medium text-white transition hover:bg-[#0077ED]">
                Simuler 15 min de retard
              </button>
            </div>
            <div className="mx-auto mt-3 max-w-sm">
              <CadranCausal etat={demo} titreCentre="Démonstration" clair={false} />
            </div>
            {rapport ? (
              <div className="mt-4 text-left"><RapportSignal rapport={rapport} /></div>
            ) : (
              <p className="mt-4 text-center text-[12px] text-white/45">
                Cliquez : la chaîne cause → absorption → impacts → explications apparaîtra ici, sous le cadran.
              </p>
            )}
          </div>
        </div>
      </section>
    </div>
  );
}