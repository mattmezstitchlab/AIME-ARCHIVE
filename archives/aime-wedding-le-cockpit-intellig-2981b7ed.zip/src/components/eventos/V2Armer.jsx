import { resumeArmement } from "@/lib/eventos/verifier";

// ÉTAPE 6 — ARMER. Le résumé obligatoire avant le direct.
export default function V2Armer({ etat, onArmer }) {
  const r = resumeArmement(etat);
  const Tuile = ({ valeur, label }) => (
    <div className="rounded-2xl border border-[#D2D2D7] bg-white p-4 text-center">
      <p className="text-2xl font-extrabold text-[#1D1D1F]">{valeur}</p>
      <p className="mt-0.5 text-[11px] font-semibold uppercase tracking-wide text-[#6E6E73]">{label}</p>
    </div>
  );
  const pret = r.conflitsCritiques.length === 0;
  return (
    <div className="mx-auto max-w-3xl px-5 pb-16">
      <h2 className="text-2xl font-extrabold text-[#1D1D1F]">Armer l'événement</h2>
      <p className="mt-1 text-[13px] text-[#6E6E73]">L'état des lieux complet avant de passer en direct.</p>
      <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Tuile valeur={r.moments} label="Moments" />
        <Tuile valeur={r.roles} label="Rôles" />
        <Tuile valeur={r.lieux.length} label="Lieux" />
        <Tuile valeur={r.ressources.length} label="Ressources" />
        <Tuile valeur={`${r.margesTotales} min`} label="Marges totales" />
        <Tuile valeur={r.invariants.length} label="Horaires immuables" />
        <Tuile valeur={r.plansB} label="Plans B déclarés" />
        <Tuile valeur={r.decisionsNecessaires} label="Décisions en attente" />
      </div>
      {r.invariants.length > 0 && (
        <p className="mt-4 text-[13px] text-[#424245]"><span className="font-bold">Protégés :</span> {r.invariants.join(", ")}</p>
      )}
      {r.conflitsCritiques.length > 0 && (
        <div className="mt-4 rounded-2xl border border-[#E8B4A0] bg-[#FDF3EF] p-4">
          <p className="text-[13px] font-bold text-[#1D1D1F]">Conflits critiques à corriger avant d'armer :</p>
          <ul className="mt-1 list-disc pl-5 text-[13px] text-[#424245]">{r.conflitsCritiques.map((p, i) => <li key={i}>{p.texte}</li>)}</ul>
        </div>
      )}
      {r.risques.length > 0 && (
        <div className="mt-3 rounded-2xl border border-[#F0E3B8] bg-[#FDFAEF] p-4">
          <p className="text-[13px] font-bold text-[#1D1D1F]">Points de vigilance ({r.risques.length}) :</p>
          <ul className="mt-1 list-disc pl-5 text-[13px] text-[#424245]">{r.risques.map((p, i) => <li key={i}>{p.texte}</li>)}</ul>
        </div>
      )}
      <button onClick={onArmer} disabled={!pret}
        className="mt-6 min-h-[52px] w-full rounded-full bg-[#0071E3] text-[15px] font-extrabold text-white transition hover:bg-[#0077ED] disabled:cursor-not-allowed disabled:opacity-40">
        {pret ? "Armer et passer en direct →" : "Corrigez d'abord les conflits critiques"}
      </button>
    </div>
  );
}