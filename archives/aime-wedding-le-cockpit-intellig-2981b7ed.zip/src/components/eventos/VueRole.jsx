import { enHM, fin, trier, ROLES_V2 } from "@/lib/eventos/model";

// VUES PAR RÔLE — toutes tirées du MÊME état causal. Les personnes célébrées
// sont protégées de la complexité ; le prestataire ne voit que ses créneaux.
export default function VueRole({ etat, roleVue, depeches }) {
  const ordre = trier(etat.moments);
  const label = ROLES_V2.find((r) => r.id === roleVue)?.label || roleVue;
  const miens = ordre.filter((m) => m.role === roleVue);
  const rapport = etat.journal.find((j) => j.signal || j.decision);

  if (roleVue === "celebres") {
    const importants = ordre.filter((m) => m.sacre || m.emotion >= 4);
    return (
      <div className="rounded-2xl border border-[#D2D2D7] bg-white p-4">
        <p className="text-[13px] font-extrabold text-[#1D1D1F]">Vos moments importants</p>
        <ul className="mt-2 space-y-1 text-[13px] text-[#424245]">
          {importants.map((m) => <li key={m.id}>💛 {enHM(m.start)} — {m.label}{m.planBActif ? " (plan B activé)" : ""}</li>)}
        </ul>
        {rapport?.decisionRequise && rapport.solutionsCandidates?.some((s) => s.action.type === "decaler-fixe") ? (
          <p className="mt-3 rounded-xl bg-[#FDF3EF] p-3 text-[12.5px] text-[#1D1D1F]">
            Une décision demande votre accord — votre personne de confiance vous présente les options.
          </p>
        ) : (
          <p className="mt-3 rounded-xl bg-[#F5F5F7] p-3 text-[12.5px] text-[#424245]">
            Tout est sous contrôle. Rien à faire de votre côté. 🌿
          </p>
        )}
      </div>
    );
  }

  if (roleVue === "prestataire" || roleVue === "lieu") {
    const concernes = roleVue === "lieu" ? ordre.filter((m) => m.lieu) : miens;
    const prochain = concernes[0];
    return (
      <div className="rounded-2xl border border-[#D2D2D7] bg-white p-4">
        <p className="text-[13px] font-extrabold text-[#1D1D1F]">{roleVue === "lieu" ? "Occupation des espaces" : "Vos engagements"}</p>
        {prochain && roleVue === "prestataire" && (
          <div className="mt-2 rounded-xl bg-[#F5F5F7] p-3 text-[13px] text-[#1D1D1F]">
            <p className="font-bold">Prochain : {prochain.label}</p>
            <p>Heure recalculée : {enHM(prochain.start)} · {prochain.lieu || "lieu à confirmer"}
              {prochain.ressources.length > 0 && ` · ${prochain.ressources.join(", ")}`}</p>
            <button className="mt-2 min-h-[44px] rounded-full border-2 border-[#0071E3] px-4 text-[12px] font-bold text-[#0071E3] hover:bg-white">
              Bien reçu ✓ (mode démonstration)
            </button>
          </div>
        )}
        <ul className="mt-2 space-y-1 text-[12.5px] text-[#424245]">
          {concernes.map((m) => <li key={m.id}>{enHM(m.start)}–{enHM(fin(m))} · {m.label}{m.lieu ? ` · ${m.lieu}` : ""}{m.planB ? " · plan B déclaré" : ""}</li>)}
        </ul>
      </div>
    );
  }

  // Famille & proches / confiance / coordination / organisateur.
  const complet = roleVue === "organisateur" || roleVue === "coordination" || roleVue === "confiance";
  const visibles = complet ? ordre : ordre.filter((m) => m.role === roleVue || m.emotion >= 4);
  return (
    <div className="rounded-2xl border border-[#D2D2D7] bg-white p-4">
      <p className="text-[13px] font-extrabold text-[#1D1D1F]">{complet ? `Command Center — ${label}` : `Ce qui vous concerne — ${label}`}</p>
      <ul className="mt-2 space-y-1 text-[12.5px] text-[#424245]">
        {visibles.map((m) => (
          <li key={m.id}>{enHM(m.start)}–{enHM(fin(m))} · {m.label}{m.lieu ? ` · ${m.lieu}` : ""}
            {complet && m.fixe ? " · immuable" : ""}{complet && !m.decideur ? " · ⚠ sans responsable" : ""}</li>
        ))}
      </ul>
      {complet && depeches?.length > 0 && (
        <p className="mt-2 text-[11.5px] text-[#6E6E73]">{depeches.length} dépêche(s) générée(s) au dernier signal.</p>
      )}
    </div>
  );
}