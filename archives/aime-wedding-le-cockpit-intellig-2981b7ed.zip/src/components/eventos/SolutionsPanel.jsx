// SOLUTIONS CANDIDATES — le moteur propose, l'HUMAIN décide. Chaque solution
// expose sa conséquence ; la recommandée est signalée par texte + badge.
export default function SolutionsPanel({ solutions, onValider }) {
  if (!solutions?.length) return null;
  return (
    <div className="rounded-2xl border border-[#E8B4A0] bg-white p-4" role="group" aria-label="Solutions proposées — validation requise">
      <p className="text-[14px] font-bold text-[#1D1D1F]">Comment voulez-vous résoudre ce conflit ?</p>
      <p className="mt-0.5 text-[12px] text-[#6E6E73]">Le système recommande une option mais n'applique rien sans vous.</p>
      <ul className="mt-3 space-y-2">
        {solutions.map((s) => (
          <li key={s.id} className={`rounded-xl border p-3 ${s.recommandee ? "border-[#0071E3] bg-[#F5F9FF]" : "border-[#D2D2D7]"}`}>
            <div className="flex flex-wrap items-center gap-2">
              <p className="text-[13px] font-semibold text-[#1D1D1F]">{s.label}</p>
              {s.recommandee && <span className="rounded-full bg-[#0071E3] px-2 py-0.5 text-[10px] font-bold text-white">Recommandée</span>}
            </div>
            <p className="mt-1 text-[12px] leading-5 text-[#6E6E73]">Conséquence : {s.consequence}</p>
            <button onClick={() => onValider(s)}
              className="mt-2 min-h-[44px] rounded-full bg-[#0071E3] px-5 text-[13px] font-semibold text-white transition hover:bg-[#0077ED]">
              Valider cette solution
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}