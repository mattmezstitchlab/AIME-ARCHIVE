import { useState } from "react";
import { creerMoment, enHM, fin, trier } from "@/lib/eventos/model";
import { BIBLIOTHEQUE_MOMENTS } from "@/lib/eventos/templates";
import MomentFiche from "@/components/eventos/MomentFiche";
import CadranCausal from "@/components/eventos/CadranCausal";

// ÉTAPE 3 — CONSTRUIRE. Bibliothèque de moments + moment libre + édition +
// réorganisation. L'alternative clavier (« déplacer avant / après ») est le
// mécanisme premier — pas un drag muet.
export default function V2Construire({ etat, setEtat }) {
  const [ouvert, setOuvert] = useState(null);
  const ordre = trier(etat.moments);

  const majMoment = (m) => setEtat({ ...etat, moments: etat.moments.map((x) => (x.id === m.id ? m : x)) });
  const supprimer = (id) => { setEtat({ ...etat, moments: etat.moments.filter((x) => x.id !== id) }); setOuvert(null); };

  const ajouter = (modele) => {
    const dernier = ordre[ordre.length - 1];
    const id = `m${Date.now()}`;
    const nouveau = creerMoment({ ...modele, id, start: dernier ? fin(dernier) + 15 : 9 * 60 });
    setEtat({ ...etat, moments: [...etat.moments, nouveau] });
    setOuvert(id);
  };

  // DÉPLACER AVANT / APRÈS — échange les créneaux de deux moments voisins.
  const deplacer = (id, sens) => {
    const i = ordre.findIndex((m) => m.id === id);
    const j = i + sens;
    if (j < 0 || j >= ordre.length) return;
    const a = { ...ordre[i] }, b = { ...ordre[j] };
    const [premier, second] = sens < 0 ? [a, b] : [b, a];
    const debut = Math.min(a.start, b.start);
    premier.start = debut; second.start = debut + premier.dur + 10;
    setEtat({ ...etat, moments: etat.moments.map((m) => (m.id === a.id ? a : m.id === b.id ? b : m)) });
  };

  return (
    <div className="mx-auto max-w-5xl px-5 pb-16">
      <h2 className="text-2xl font-extrabold text-[#1D1D1F]">Construire ensemble</h2>
      <p className="mt-1 text-[13px] text-[#6E6E73]">Ajoutez, réglez et organisez vos moments. Tout est modifiable à tout instant.</p>
      <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_360px]">
        <div>
          <ul className="space-y-2" aria-label="Vos moments, dans l'ordre">
            {ordre.map((m, i) => (
              <li key={m.id} className="rounded-2xl border border-[#D2D2D7] bg-white p-3">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-mono text-[12px] font-bold text-[#0071E3]">{enHM(m.start)}</span>
                  <button onClick={() => setOuvert(ouvert === m.id ? null : m.id)}
                    className="min-h-[44px] flex-1 text-left text-[14px] font-bold text-[#1D1D1F] hover:underline"
                    aria-expanded={ouvert === m.id}>
                    {m.label} <span className="font-normal text-[#6E6E73]">· {m.dur} min{m.fixe ? " · immuable" : ""}{m.optionnel ? " · optionnel" : ""}</span>
                  </button>
                  <div className="flex gap-1">
                    <button onClick={() => deplacer(m.id, -1)} disabled={i === 0} aria-label={`Déplacer « ${m.label} » avant`}
                      className="min-h-[44px] min-w-[44px] rounded-xl border border-[#D2D2D7] text-[#1D1D1F] hover:bg-[#F5F5F7] disabled:opacity-30">↑</button>
                    <button onClick={() => deplacer(m.id, 1)} disabled={i === ordre.length - 1} aria-label={`Déplacer « ${m.label} » après`}
                      className="min-h-[44px] min-w-[44px] rounded-xl border border-[#D2D2D7] text-[#1D1D1F] hover:bg-[#F5F5F7] disabled:opacity-30">↓</button>
                  </div>
                </div>
                {ouvert === m.id && (
                  <div className="mt-3">
                    <MomentFiche moment={m} onChange={majMoment} onSupprimer={() => supprimer(m.id)} onFermer={() => setOuvert(null)} />
                  </div>
                )}
              </li>
            ))}
          </ul>
          <h3 className="mt-8 text-[13px] font-bold uppercase tracking-wide text-[#6E6E73]">Bibliothèque de moments</h3>
          <div className="mt-2 flex flex-wrap gap-2">
            {BIBLIOTHEQUE_MOMENTS.map((b) => (
              <button key={b.label} onClick={() => ajouter(b)}
                className="min-h-[44px] rounded-full border border-[#D2D2D7] bg-white px-4 text-[12.5px] font-semibold text-[#1D1D1F] hover:border-[#0071E3] hover:bg-[#F5F5F7]">
                + {b.label}
              </button>
            ))}
          </div>
        </div>
        <aside className="lg:sticky lg:top-24 lg:self-start">
          <div className="rounded-3xl border border-[#D2D2D7] bg-white p-4">
            <CadranCausal etat={etat} selection={ouvert} onSelect={setOuvert} titreCentre={etat.exemple ? "Exemple (démo)" : "Votre Jour J"} />
          </div>
        </aside>
      </div>
    </div>
  );
}