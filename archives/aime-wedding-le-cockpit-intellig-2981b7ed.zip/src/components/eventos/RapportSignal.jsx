// LA CHAÎNE D'EXPLICATION — CAUSE → ABSORPTION → IMPACTS → PROTÉGÉS →
// CONFLITS → SOLUTIONS → DÉCISION → ACTIONS. Aucun sens porté par la couleur
// seule : chaque bloc a son intitulé texte.
export default function RapportSignal({ rapport }) {
  if (!rapport) return null;
  const Bloc = ({ titre, enfants, ton = "neutre" }) => (
    <div className={`rounded-xl border p-3 ${ton === "alerte" ? "border-[#E8B4A0] bg-[#FDF3EF]" : ton === "ok" ? "border-[#D2D2D7] bg-[#F5F5F7]" : "border-[#D2D2D7] bg-white"}`}>
      <p className="font-mono text-[10px] font-bold uppercase tracking-[0.18em] text-[#6E6E73]">{titre}</p>
      <div className="mt-1 text-[13px] leading-5 text-[#1D1D1F]">{enfants}</div>
    </div>
  );
  return (
    <div className="space-y-2" aria-live="polite">
      <Bloc titre="Cause" enfants={<>
        {rapport.signal ? `${rapport.signal.type === "avance" ? "Avance" : "Retard"} de ${rapport.perturbationInitiale} min` : rapport.decision}
        {" · "}marge disponible en aval : {rapport.margeDisponible ?? 0} min
      </>} />
      <Bloc titre="Absorption" ton="ok" enfants={`${rapport.margeConsommee ?? 0} min absorbées par les espaces disponibles.`} />
      <Bloc titre="Impacts" enfants={
        (rapport.impacts || []).filter((i) => i.via !== "signal").length === 0
          ? "Rien d'autre ne bouge."
          : <ul className="list-disc pl-4">{rapport.impacts.filter((i) => i.via !== "signal").map((i, k) =>
              <li key={k}>{i.label} : +{i.decalage} min ({i.via === "chronologie" ? "enchaînement" : `relation « ${i.via} »`})</li>)}</ul>
      } />
      {rapport.invariantsProteges?.length > 0 && (
        <Bloc titre="Éléments protégés" ton="ok" enfants={rapport.invariantsProteges.join(", ") +
          (rapport.compressionDemandee ? ` — compression : ${rapport.compressionRealisee}/${rapport.compressionDemandee} min réalisées` : "")} />
      )}
      {rapport.conflitRestant > 0 && (
        <Bloc titre="Conflits restants" ton="alerte" enfants={`${rapport.conflitRestant} min ne peuvent pas être résolues automatiquement. Une décision humaine est requise — rien ne sera appliqué sans votre validation.`} />
      )}
      {rapport.explication?.length > 0 && (
        <Bloc titre="Explication" enfants={<ul className="list-disc pl-4">{rapport.explication.map((e, k) => <li key={k}>{e}</li>)}</ul>} />
      )}
    </div>
  );
}