import { verifierPlan } from "@/lib/eventos/verifier";

// ÉTAPE 4 — VÉRIFIER. Chaque contradiction est détectée ET expliquée en
// langage simple. Niveau porté par texte (jamais par la couleur seule).
export default function V2Verifier({ etat }) {
  const problemes = verifierPlan(etat);
  return (
    <div className="mx-auto max-w-2xl px-5 pb-16" aria-live="polite">
      <h2 className="text-2xl font-extrabold text-[#1D1D1F]">Vérifier le plan</h2>
      <p className="mt-1 text-[13px] text-[#6E6E73]">
        Le système relit tout : chevauchements, personnes à deux endroits, ressources partagées,
        trajets, marges, responsables et plans B.
      </p>
      {problemes.length === 0 ? (
        <div className="mt-6 rounded-2xl border border-[#D2D2D7] bg-[#F5F5F7] p-5">
          <p className="text-[14px] font-bold text-[#1D1D1F]">✓ Aucune contradiction détectée</p>
          <p className="mt-1 text-[13px] text-[#424245]">Votre plan est cohérent. Vous pouvez passer à la simulation.</p>
        </div>
      ) : (
        <ul className="mt-6 space-y-2">
          {problemes.map((p, i) => (
            <li key={i} className={`rounded-2xl border p-4 ${p.niveau === "critique" ? "border-[#E8B4A0] bg-[#FDF3EF]" : "border-[#F0E3B8] bg-[#FDFAEF]"}`}>
              <p className="font-mono text-[10px] font-bold uppercase tracking-[0.16em] text-[#6E6E73]">
                {p.niveau === "critique" ? "À corriger" : "Attention"} · {p.type.replace(/-/g, " ")}
              </p>
              <p className="mt-1 text-[13.5px] leading-6 text-[#1D1D1F]">{p.texte}</p>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}