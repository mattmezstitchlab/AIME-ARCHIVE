import { trier } from "@/lib/eventos/model";
import { appliquerSignal, annulerDernier, genererSolutions } from "@/lib/eventos/engine";

const GRAD = "linear-gradient(90deg, #F2A7C3, #E8C97F, #7FDCB2, #7FC3F0, #C9A2F5)";

// LES RÉGLAGES DE LA SIMULATION — dans la colonne de droite du Studio :
// moment ciblé, minutes, et les scénarios, condensés en style pipeline.
export default function V2SimulerReglages({ etat, setEtat, cible, setCible, minutes, setMinutes }) {
  const ordre = trier(etat.moments);
  const cibleEff = cible || ordre[0]?.id;

  const lancer = (type) => {
    const r = appliquerSignal(etat, { type, cibleId: cibleEff, minutes: Math.abs(minutes) });
    setEtat(r.etat);
  };

  // Scénarios non temporels : rien d'appliqué seul — décision humaine requise.
  const scenarioDecision = (nomScenario) => {
    const clone = JSON.parse(JSON.stringify(etat));
    const m = clone.moments.find((x) => x.id === cibleEff);
    const rapportScenario = {
      decision: null, signal: null, perturbationInitiale: 0, margeDisponible: 0, margeConsommee: 0,
      decalagePropage: 0, compressionDemandee: 0, compressionRealisee: 0,
      conflitRestant: m?.dur || 0, invariantsProteges: [], decisionRequise: true,
      impacts: [], horodatage: Date.now(),
      explication: [
        nomScenario === "pluie" ? `Pluie annoncée : « ${m?.label} »${m?.planB ? " a un plan alternatif déclaré" : " n'a PAS de plan alternatif déclaré"}.`
        : nomScenario === "absence" ? `Absence du responsable de « ${m?.label} » (${m?.role}).`
        : `Panne technique signalée sur « ${m?.label} »${m?.ressources?.length ? ` (ressource : ${m.ressources.join(", ")})` : ""}.`,
        "Aucune modification appliquée : choisissez une solution sous le cadran.",
      ],
    };
    rapportScenario.solutionsCandidates = genererSolutions(clone, rapportScenario, m);
    clone.journal.unshift(rapportScenario);
    setEtat(clone);
  };

  const champ = "mt-1 block min-h-[34px] w-full rounded-lg border border-white/15 bg-white/5 px-2 text-[11px] text-white";
  const btn = "flex min-h-[32px] items-center justify-center rounded-full border border-white/15 px-2.5 text-[10.5px] font-semibold text-white/70 transition hover:border-white/40 hover:text-white";

  return (
    <div className="space-y-2">
      <p className="font-mono text-[7.5px] font-bold uppercase tracking-[0.2em] text-white/35">Simulation</p>
      <label className="block">
        <span className="text-[9px] font-bold uppercase tracking-wide text-white/40">Moment ciblé</span>
        <select value={cibleEff} onChange={(e) => setCible(e.target.value)} className={champ}>
          {ordre.map((m) => <option key={m.id} value={m.id} className="text-black">{m.label}</option>)}
        </select>
      </label>
      <label className="block">
        <span className="text-[9px] font-bold uppercase tracking-wide text-white/40">Minutes</span>
        <input type="number" min={1} max={240} value={minutes} onChange={(e) => setMinutes(+e.target.value || 1)} className={champ} />
      </label>
      <button onClick={() => lancer("retard")}
        className="flex min-h-[34px] w-full items-center justify-center rounded-full text-[11px] font-bold text-black transition hover:opacity-90"
        style={{ background: GRAD }}>
        Retard de {minutes} min
      </button>
      <button onClick={() => lancer("avance")} className={`${btn} w-full`}>Temps récupéré ({minutes} min)</button>
      <div className="grid grid-cols-3 gap-1.5">
        {[["pluie", "Pluie"], ["absence", "Absence"], ["panne", "Panne"]].map(([id, lab]) => (
          <button key={id} onClick={() => scenarioDecision(id)} className={btn}>{lab}</button>
        ))}
      </div>
      {etat.histoire.length > 0 && (
        <button onClick={() => setEtat(annulerDernier(etat))} className={`${btn} w-full border-[#F2A7C3]/40 text-[#F2A7C3] hover:border-[#F2A7C3]`}>
          ↺ Annuler le dernier signal
        </button>
      )}
    </div>
  );
}