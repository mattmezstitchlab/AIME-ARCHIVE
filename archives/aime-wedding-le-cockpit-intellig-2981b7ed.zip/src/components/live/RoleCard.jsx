import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";

// Carte de rôle expressive : chaque carte affiche un aperçu propre à son usage
// (mosaïque, morceaux, compteurs, cockpit…) pour qu'aucune ne ressemble à l'autre.
// `preview` est un nœud React libre rendu sous le titre.
export default function RoleCard({ to, icon: Icon, title, hint, preview, accent }) {
  return (
    <Link
      to={to}
      className="group flex flex-col rounded-2xl border border-foreground/10 bg-card p-5 transition-colors hover:border-foreground54]/50"
    >
      <div className="flex items-start gap-3">
        <span
          className={`inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-full ${
            accent ? "bg-foreground text-background" : "bg-foreground text-background"
          }`}
        >
          <Icon className="h-5 w-5" aria-hidden="true" />
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-sm font-medium text-foreground">{title}</p>
          {hint && <p className="mt-0.5 truncate text-xs text-foreground/50">{hint}</p>}
        </div>
        <ArrowRight className="h-4 w-4 shrink-0 text-foreground/25 transition-colors group-hover:text-foreground" aria-hidden="true" />
      </div>
      {preview && <div className="mt-4">{preview}</div>}
    </Link>
  );
}