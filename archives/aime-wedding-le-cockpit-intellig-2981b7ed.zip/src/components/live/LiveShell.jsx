// Corps standard sous LiveHeader. Largeur et rythme cohérents, fond blanc.
export default function LiveShell({ children, wide = false }) {
  return (
    <div className={`mx-auto px-6 py-10 sm:py-14 ${wide ? "max-w-6xl" : "max-w-5xl"}`}>
      {children}
    </div>
  );
}