import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";

// Carte de hub vivante : chaque carte montre son rôle par un aperçu différent
// (mini-mosaïque, compteurs, onde, cockpit, sceau…) plutôt qu'un template unique.
// `preview` est un noeud libre rendu au-dessus du titre.
export default function HubCard({ to, icon: Icon, title, hint, preview, accent = false }) {
  return (
    <Link
      to={to}
      className={`group flex flex-col rounded-2xl border p-5 transition-all hover:-translate-y-0.5 hover:shadow-md ${
        accent
          ? "border-foreground/30 bg-foreground text-background hover:border-foreground"
          : "border-foreground/10 bg-card hover:border-foreground/25"
      }`}
    >
      {preview && <div className="mb-4">{preview}</div>}
      <div className="mt-auto flex items-start gap-3">
        {Icon && (
          <span
            className={`inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-full ${
              accent ? "bg-background/15 text-background" : "bg-muted text-foreground"
            }`}
          >
            <Icon className="h-4 w-4" aria-hidden="true" />
          </span>
        )}
        <div className="min-w-0 flex-1">
          <p className={`text-sm font-medium ${accent ? "text-background" : "text-foreground"}`}>{title}</p>
          {hint && (
            <p className={`mt-0.5 text-xs ${accent ? "text-background/70" : "text-foreground/50"}`}>{hint}</p>
          )}
        </div>
        <ArrowRight
          className={`h-4 w-4 shrink-0 transition-transform group-hover:translate-x-0.5 ${
            accent ? "text-background/60" : "text-foreground/30"
          }`}
          aria-hidden="true"
        />
      </div>
    </Link>
  );
}