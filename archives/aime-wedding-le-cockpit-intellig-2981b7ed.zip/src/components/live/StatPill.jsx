// Compteur compact réutilisable (RSVP, cockpit…). Valeur forte + libellé discret.
export default function StatPill({ value, label, tone = "neutral" }) {
  const tones = {
    neutral: "text-foreground",
    green: "text-foreground",
    muted: "text-foreground/40",
    danger: "text-destructive",
  };
  return (
    <div className="rounded-xl border border-border bg-background px-4 py-3 text-center">
      <p className={`text-2xl font-light tracking-tight ${tones[tone] || tones.neutral}`}>{value}</p>
      <p className="mt-0.5 text-[11px] uppercase tracking-wide text-foreground/45">{label}</p>
    </div>
  );
}