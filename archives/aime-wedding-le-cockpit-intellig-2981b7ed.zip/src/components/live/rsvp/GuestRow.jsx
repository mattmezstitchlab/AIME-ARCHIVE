import { Check, X, Clock, UserPlus, Utensils, Trash2 } from "lucide-react";

const RSVP_CYCLE = { pending: "yes", yes: "no", no: "pending" };
const RSVP_META = {
  yes: { icon: Check, cls: "border-foreground bg-foreground text-background", label: "Présent" },
  no: { icon: X, cls: "border-foreground/20 bg-foreground/5 text-foreground/50", label: "Absent" },
  pending: { icon: Clock, cls: "border-foreground/20 text-foreground/45", label: "En attente" },
};

// Ligne d'un invité : nom, groupe, bascule RSVP, +1, régime, suppression.
export default function GuestRow({ guest, onCycle, onTogglePlus, onRemove, onAssign, tables = [] }) {
  const meta = RSVP_META[guest.rsvp] || RSVP_META.pending;
  const Icon = meta.icon;
  return (
    <li className="flex flex-wrap items-center gap-3 rounded-xl border border-border bg-background px-4 py-3">
      <button
        type="button"
        onClick={onCycle}
        className={`inline-flex h-7 items-center gap-1.5 rounded-full border px-3 text-[11px] font-medium transition-colors ${meta.cls}`}
        title="Changer la réponse"
      >
        <Icon className="h-3.5 w-3.5" aria-hidden="true" /> {meta.label}
      </button>

      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-medium text-foreground">{guest.name || "Sans nom"}</p>
        <div className="mt-0.5 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-[11px] text-foreground/45">
          {guest.group && <span>{guest.group}</span>}
          {guest.plus_one && <span className="inline-flex items-center gap-0.5"><UserPlus className="h-3 w-3" aria-hidden="true" /> +1</span>}
          {guest.dietary && <span className="inline-flex items-center gap-0.5 text-foreground/60"><Utensils className="h-3 w-3" aria-hidden="true" /> {guest.dietary}</span>}
        </div>
      </div>

      {tables.length > 0 && (
        <select
          value={guest._table || ""}
          onChange={(e) => onAssign(e.target.value)}
          className="shrink-0 rounded-full border border-border bg-paper px-3 py-1 text-[11px] text-foreground outline-none"
        >
          <option value="">Sans table</option>
          {tables.map((t) => (
            <option key={t.id} value={t.id}>{t.label}</option>
          ))}
        </select>
      )}

      <button
        type="button"
        onClick={onTogglePlus}
        className={`shrink-0 rounded-full px-2.5 py-1 text-[11px] transition-colors ${
          guest.plus_one ? "bg-foreground/10 text-foreground" : "bg-paper text-foreground/50 hover:text-foreground"
        }`}
        title="Accompagnant"
      >
        +1
      </button>
      <button type="button" onClick={onRemove} aria-label="Retirer" className="shrink-0 text-foreground/30 hover:text-destructive">
        <Trash2 className="h-4 w-4" aria-hidden="true" />
      </button>
    </li>
  );
}