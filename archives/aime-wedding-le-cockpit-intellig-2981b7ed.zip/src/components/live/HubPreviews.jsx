// Mini-aperçus distincts pour les cartes de hub : chaque usage a sa signature
// visuelle. Données réelles du GuidePlan passées en props, fallback élégant.

// Mini-mosaïque (album)
export function MosaicPreview({ images = [] }) {
  const cells = images.slice(0, 4);
  while (cells.length < 4) cells.push(null);
  return (
    <div className="grid grid-cols-2 gap-1 overflow-hidden rounded-xl">
      {cells.map((src, i) => (
        <div key={i} className="aspect-square bg-[#f6f4ef]">
          {src && <img src={src} alt="" className="h-full w-full object-cover" />}
        </div>
      ))}
    </div>
  );
}

// Mini-onde (playlist)
export function WavePreview({ count = 0 }) {
  const bars = [8, 16, 11, 22, 14, 26, 12, 19, 9, 24, 15, 20, 10, 18];
  return (
    <div>
      <div className="flex h-12 items-end gap-1">
        {bars.map((h, i) => (
          <span key={i} className="flex-1 rounded-full bg-foreground/70" style={{ height: `${h * 1.6}px` }} />
        ))}
      </div>
      {count > 0 && <p className="mt-2 text-[11px] text-foreground/45">{count} titre(s)</p>}
    </div>
  );
}

// Compteurs (RSVP)
export function CountersPreview({ yes = 0, pending = 0, no = 0 }) {
  const items = [
    { v: yes, l: "Oui", c: "text-foreground" },
    { v: pending, l: "En attente", c: "text-foreground/50" },
    { v: no, l: "Non", c: "text-foreground/40" },
  ];
  return (
    <div className="flex gap-2">
      {items.map((it) => (
        <div key={it.l} className="flex-1 rounded-xl bg-[#f6f4ef] py-2.5 text-center">
          <p className={`text-xl font-light ${it.c}`}>{it.v}</p>
          <p className="text-[10px] uppercase tracking-wide text-foreground/45">{it.l}</p>
        </div>
      ))}
    </div>
  );
}

// Cockpit (jour J) : ligne « maintenant / prochain »
export function CockpitPreview({ now, next }) {
  return (
    <div className="space-y-1.5">
      <div className="flex items-center gap-2 rounded-lg bg-foreground/10 px-3 py-2">
        <span className="h-2 w-2 animate-pulse rounded-full bg-foreground" />
        <p className="truncate text-xs font-medium text-foreground">{now || "Aucun moment en cours"}</p>
      </div>
      <div className="flex items-center gap-2 px-3 py-1">
        <span className="h-2 w-2 rounded-full bg-foreground/20" />
        <p className="truncate text-xs text-foreground/50">{next || "À venir…"}</p>
      </div>
    </div>
  );
}

// Sceau (capsule)
export function SealPreview({ date }) {
  return (
    <div className="flex items-center justify-center rounded-xl bg-foreground py-6">
      <div className="text-center">
        <div className="mx-auto mb-2 flex h-9 w-9 items-center justify-center rounded-full border border-background/30 text-background">
          ✦
        </div>
        <p className="text-[10px] uppercase tracking-[0.2em] text-background/60">
          {date ? `Scellée — ${date}` : "À sceller"}
        </p>
      </div>
    </div>
  );
}

// Accès critique (urgences)
export function CriticalPreview({ contacts = 0 }) {
  return (
    <div className="rounded-xl border border-destructive/30 bg-destructive/5 px-3 py-3">
      <p className="text-[11px] font-semibold uppercase tracking-wide text-destructive">Accès critique</p>
      <p className="mt-1 text-xs text-foreground/60">{contacts} contact(s) prioritaire(s)</p>
    </div>
  );
}

// Liste courte (programme / contacts)
export function LinesPreview({ lines = [] }) {
  const rows = lines.slice(0, 3);
  return (
    <div className="space-y-1.5">
      {rows.length === 0 && <p className="text-xs text-foreground/40">Rien encore — à composer</p>}
      {rows.map((l, i) => (
        <div key={i} className="flex items-center gap-2 text-xs text-foreground/60">
          <span className="font-mono text-[11px] text-foreground">{l.time || "—"}</span>
          <span className="truncate">{l.label}</span>
        </div>
      ))}
    </div>
  );
}