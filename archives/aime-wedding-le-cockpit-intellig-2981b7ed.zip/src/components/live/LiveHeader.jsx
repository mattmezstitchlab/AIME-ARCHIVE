import { Link } from "react-router-dom";
import { ChevronLeft } from "lucide-react";

// En-tête léger et cohérent pour les pages vivantes du mariage.
// Ivoire clair, accent vert sauge, retour contextuel — pas de gros hero imposé,
// chaque page reste libre de composer son propre corps.
export default function LiveHeader({ phase, title, subtitle, back = "/avant", backLabel = "Avant", icon: Icon, action }) {
  return (
    <header className="border-b border-border bg-paper">
      <div className="mx-auto max-w-5xl px-6 pb-8 pt-6">
        <Link
          to={back}
          className="inline-flex items-center gap-1 text-xs font-medium text-muted-foreground transition-colors hover:text-foreground"
        >
          <ChevronLeft className="h-3.5 w-3.5" aria-hidden="true" /> {backLabel}
        </Link>
        <div className="mt-5 flex items-end justify-between gap-4">
          <div className="min-w-0">
            {phase && (
              <p className="mb-2 text-[11px] font-semibold uppercase tracking-[0.24em] text-muted-foreground">
                {phase}
              </p>
            )}
            <div className="flex items-center gap-3">
              {Icon && (
                <span className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-foreground text-background">
                  <Icon className="h-5 w-5" aria-hidden="true" />
                </span>
              )}
              <h1 className="text-2xl font-light tracking-tight text-foreground sm:text-4xl">{title}</h1>
            </div>
            {subtitle && <p className="mt-3 max-w-xl text-sm text-foreground/55">{subtitle}</p>}
          </div>
          {action && <div className="shrink-0">{action}</div>}
        </div>
      </div>
    </header>
  );
}