import { useState } from "react";
import { Plus, X } from "lucide-react";
import { RELATIONS } from "@/lib/registre/personCardBuild";

// MES MARIAGES — l'éditeur des branchements de la carte : le mariage et ma
// relation dedans (Marié·e, Prestataire, Invité·e, Témoin…).
export default function WeddingsEditor({ weddings = [], onChange }) {
  const [name, setName] = useState("");
  const [relation, setRelation] = useState(RELATIONS[0]);

  const add = () => {
    if (!name.trim()) return;
    onChange([...weddings, { wedding_name: name.trim(), relation }]);
    setName("");
  };

  return (
    <div>
      <div className="space-y-1.5">
        {weddings.map((w, i) => (
          <div key={i} className="flex items-center justify-between gap-2 rounded-lg border border-white/10 bg-white/[0.02] px-3 py-2">
            <p className="min-w-0 truncate text-[12.5px] text-white/85">
              {w.wedding_name} <span className="font-mono text-[9.5px] uppercase tracking-[0.12em] text-white/40">· {w.relation}</span>
            </p>
            <button
              type="button"
              onClick={() => onChange(weddings.filter((_, idx) => idx !== i))}
              aria-label={`Retirer ${w.wedding_name}`}
              className="grid h-6 w-6 shrink-0 place-items-center rounded-full text-white/40 hover:bg-white/10 hover:text-white"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        ))}
      </div>
      <div className="mt-2 flex gap-2">
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), add())}
          placeholder="Mariage de Léa & Tom…"
          className="min-w-0 flex-1 rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2 text-[13px] text-white placeholder:text-white/25 outline-none focus:border-white/30"
        />
        <select
          value={relation}
          onChange={(e) => setRelation(e.target.value)}
          className="shrink-0 rounded-lg border border-white/10 bg-black px-2 py-2 text-[12px] text-white outline-none focus:border-white/30"
          style={{ colorScheme: "dark" }}
          aria-label="Ma relation dans ce mariage"
        >
          {RELATIONS.map((r) => (
            <option key={r} value={r}>{r}</option>
          ))}
        </select>
        <button
          type="button"
          onClick={add}
          className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-white/10 text-white transition hover:bg-white/20"
          aria-label="Ajouter le mariage"
        >
          <Plus className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}