import { Pencil } from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

// L'APERÇU DU COMPTE — la fiche personne : photo en hero, nom, repère zéro,
// projets et nuancier. Le cœur visuel de la page ME.
export default function CompteApercu({ compte, onModifier }) {
  return (
    <section className="overflow-hidden rounded-2xl border border-white/12 bg-white/[0.02]">
      <div className="relative aspect-[21/8] w-full overflow-hidden">
        <img src={compte.photoUrl} alt={compte.nom} className="h-full w-full object-cover" style={{ objectPosition: "50% 28%" }} />
        <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent" />
        <div className="absolute bottom-3 left-4 right-4 flex items-end justify-between gap-3">
          <div>
            <p className="font-heading text-2xl font-light tracking-[-0.01em] text-white">{compte.nom}</p>
            {compte.naissance && (
              <p className="font-mono text-[9.5px] uppercase tracking-[0.18em] text-white/50">
                Repère zéro · {format(new Date(compte.naissance), "d MMMM yyyy", { locale: fr })}
              </p>
            )}
          </div>
          <div className="flex gap-1.5">
            {(compte.couleurs || []).map((c) => (
              <span key={c} className="h-5 w-5 rounded-full border border-white/30" style={{ background: c }} />
            ))}
          </div>
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-2 p-4">
        {(compte.projets || []).map((p) => (
          <span key={p} className="rounded-full border border-[#c9a96e]/40 bg-[#c9a96e]/10 px-2.5 py-0.5 text-[11px] text-[#e6cf9f]">
            {p}
          </span>
        ))}
        <button
          type="button"
          onClick={onModifier}
          className="ml-auto inline-flex items-center gap-1.5 rounded-lg border border-white/15 px-3.5 py-1.5 text-[12px] text-white/70 transition hover:text-white"
        >
          <Pencil className="h-3.5 w-3.5" /> Modifier
        </button>
      </div>
    </section>
  );
}