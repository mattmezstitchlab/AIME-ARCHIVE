import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";

// LA FRISE NEUTRE DU COMPTE — le même axe temporel que la frise unique,
// mais en couche personnelle : repère zéro, compte validé, projets créés.
export default function CompteFrise({ compte }) {
  const [projets, setProjets] = useState([]);
  useEffect(() => {
    base44.entities.AimeProject.list("-created_date", 50).then(setProjets);
  }, []);

  const debut = compte.naissance ? new Date(compte.naissance).getTime() : (compte.validated_at || Date.now()) - 365 * 864e5;
  const fin = Date.now() + 90 * 864e5; // l'horizon : +3 mois
  const pos = (ts) => Math.min(97, Math.max(3, 3 + ((ts - debut) / (fin - debut)) * 94));

  const reperes = [
    compte.naissance && { ts: new Date(compte.naissance).getTime(), label: "Repère zéro — naissance", color: "#c9a96e" },
    compte.validated_at && { ts: compte.validated_at, label: "Compte AIME® validé", color: "#34d399" },
    ...projets.map((p) => ({
      ts: new Date(p.created_date).getTime(),
      label: `Projet — ${p.project_title || p.intent}`,
      color: "#38bdf8",
    })),
  ].filter(Boolean);

  return (
    <div>
      <div
        className="relative h-12 rounded-lg border border-white/10 bg-black/40"
        style={{
          backgroundImage: "repeating-linear-gradient(to right, rgba(255,255,255,0.14) 0 1px, transparent 1px 9px)",
          backgroundSize: "100% 40%",
          backgroundPosition: "0 100%",
          backgroundRepeat: "no-repeat",
        }}
      >
        {reperes.map((r, i) => (
          <span key={i} className="group absolute top-0 h-full" style={{ left: `${pos(r.ts)}%` }}>
            <span className="absolute bottom-0 h-3/4 w-[2px] -translate-x-1/2" style={{ background: r.color }} />
            <span
              className="pointer-events-none absolute bottom-full left-1/2 mb-1.5 hidden -translate-x-1/2 whitespace-nowrap rounded-md border border-white/15 bg-black/90 px-2 py-1 font-mono text-[9.5px] uppercase tracking-[0.12em] text-white/80 group-hover:block"
            >
              {r.label} · {new Date(r.ts).toLocaleDateString("fr-FR")}
            </span>
          </span>
        ))}
      </div>
      <p className="mt-2 text-[11px] leading-4 text-white/40">
        Votre couche personnelle de la frise unique : du repère zéro à l'horizon — chaque projet créé y pose son point.
        La couche des vérités historiques se découvre dans la page +.
      </p>
    </div>
  );
}