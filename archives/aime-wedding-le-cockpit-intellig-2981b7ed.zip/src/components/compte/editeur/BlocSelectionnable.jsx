// LE BLOC SÉLECTIONNABLE — comme dans Wix / Framer : au survol un contour
// léger, au clic le contour bleu + l'étiquette, et le panneau de droite
// affiche les propriétés détaillées du bloc.
export default function BlocSelectionnable({ id, label, selection, onSelect, children }) {
  const actif = selection === id;
  return (
    <div
      role="button"
      tabIndex={0}
      onClick={(e) => { e.stopPropagation(); onSelect(id); }}
      onKeyDown={(e) => { if (e.key === "Enter") onSelect(id); }}
      aria-label={`Sélectionner le bloc ${label}`}
      aria-pressed={actif}
      className={`relative cursor-pointer rounded-xl transition ${
        actif
          ? "ring-2 ring-[#38bdf8]"
          : "ring-1 ring-transparent hover:ring-[#38bdf8]/40"
      }`}
    >
      {actif && (
        <span className="absolute -top-3 left-3 z-10 rounded-md bg-[#38bdf8] px-2 py-0.5 font-mono text-[9px] font-bold uppercase tracking-[0.14em] text-black">
          {label}
        </span>
      )}
      {children}
    </div>
  );
}