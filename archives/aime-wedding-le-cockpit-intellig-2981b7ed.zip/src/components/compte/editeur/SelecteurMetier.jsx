import { Briefcase } from "lucide-react";
import { DOMAINES_METIERS, findDomaine } from "@/lib/compte/metiersUniversels";

const selectCls =
  "mt-1 w-full rounded-lg border border-white/15 bg-[#141418] px-2.5 py-2 text-[12px] text-white/85 focus:border-[#38bdf8] focus:outline-none";

// LE SÉLECTEUR UNIVERSEL DE MÉTIER — trois niveaux en cascade :
// domaine → sous-catégorie → précision. La précision est ce qui compte.
export default function SelecteurMetier({ valeur = {}, onChange }) {
  const domaine = findDomaine(valeur.domaine);
  const sous = domaine?.sous.find((s) => s.label === valeur.sous) || null;

  return (
    <div>
      <span className="inline-flex items-center gap-1.5 text-[11px] font-medium text-white/60">
        <Briefcase className="h-3 w-3 text-[#c9a96e]" /> Métier — jusqu'à la précision
      </span>

      <label className="mt-2 block">
        <span className="font-mono text-[8.5px] uppercase tracking-[0.16em] text-white/35">Domaine universel</span>
        <select
          value={valeur.domaine || ""}
          onChange={(e) => onChange({ domaine: e.target.value, sous: "", precision: "" })}
          className={selectCls}
        >
          <option value="">— Choisir un domaine —</option>
          {DOMAINES_METIERS.map((d) => (
            <option key={d.label} value={d.label}>{d.label}</option>
          ))}
        </select>
      </label>

      {domaine && (
        <label className="mt-2 block">
          <span className="font-mono text-[8.5px] uppercase tracking-[0.16em] text-white/35">Sous-catégorie</span>
          <select
            value={valeur.sous || ""}
            onChange={(e) => onChange({ ...valeur, sous: e.target.value, precision: "" })}
            className={selectCls}
          >
            <option value="">— Choisir —</option>
            {domaine.sous.map((s) => (
              <option key={s.label} value={s.label}>{s.label}</option>
            ))}
          </select>
        </label>
      )}

      {sous && (
        <label className="mt-2 block">
          <span className="font-mono text-[8.5px] uppercase tracking-[0.16em] text-white/35">La précision — ce qui compte</span>
          <select
            value={valeur.precision || ""}
            onChange={(e) => onChange({ ...valeur, precision: e.target.value })}
            className={selectCls}
          >
            <option value="">— Préciser —</option>
            {sous.precisions.map((p) => (
              <option key={p} value={p}>{p}</option>
            ))}
          </select>
        </label>
      )}
    </div>
  );
}