import { useRef, useState } from "react";
import { ImagePlus, Loader2, Plus, Check, CheckCheck, MousePointerClick } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { findModule, BIBLIOTHEQUE_MODULES, valeurChamp } from "@/lib/aimeplus/bibliothequeModules";
import ChampGenerable from "./ChampGenerable";
import SelecteurMetier from "./SelecteurMetier";

// LE PANNEAU DE DROITE — toute la verticale, façon Wix : les propriétés
// détaillées du bloc sélectionné (textes réglables / générables, photo),
// la bibliothèque de cartes-modules à poser sur la page, et le Valider.
export default function PanneauProprietes({ selection, brouillon, nom, onChamp, onPhoto, onMetier, onToggle, onValider }) {
  const fileRef = useRef(null);
  const [upload, setUpload] = useState(false);
  const module = selection ? findModule(selection) : null;

  const importer = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUpload(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    onPhoto(file_url);
    setUpload(false);
  };

  return (
    <div className="flex h-full flex-col gap-4">
      {/* LES PROPRIÉTÉS DU BLOC SÉLECTIONNÉ */}
      <section className="rounded-2xl border border-white/12 bg-[#0f0f12] p-4">
        {module ? (
          <>
            <p className="inline-flex items-center gap-2 font-mono text-[9.5px] font-bold uppercase tracking-[0.2em] text-[#38bdf8]">
              <module.icon className="h-3.5 w-3.5" /> {module.label} — propriétés
            </p>
            <div className="mt-4 space-y-4">
              {module.champs.map((champ) => (
                <ChampGenerable
                  key={champ.id}
                  champ={champ}
                  nom={nom}
                  valeur={valeurChamp(brouillon.valeurs, module.id, champ)}
                  onChange={(v) => onChamp(module.id, champ.id, v)}
                />
              ))}
              {module.id === "identite" && (
                <SelecteurMetier valeur={brouillon.metier || {}} onChange={onMetier} />
              )}
              {module.id === "identite" && (
                <div>
                  <span className="text-[11px] font-medium text-white/60">Photo de la page</span>
                  <button
                    type="button"
                    onClick={() => fileRef.current?.click()}
                    disabled={upload}
                    className="mt-1.5 flex w-full items-center justify-center gap-2 rounded-lg border border-dashed border-white/25 px-3 py-3 text-[12px] text-white/60 transition hover:border-white/50 hover:text-white disabled:opacity-50"
                  >
                    {upload ? <Loader2 className="h-4 w-4 animate-spin" /> : <ImagePlus className="h-4 w-4" />}
                    {upload ? "Import…" : brouillon.photo_url ? "Changer la photo" : "Importer ma photo"}
                  </button>
                  <input ref={fileRef} type="file" accept="image/*" onChange={importer} className="hidden" />
                </div>
              )}
            </div>
          </>
        ) : (
          <p className="flex items-center gap-2 text-[12px] leading-relaxed text-white/45">
            <MousePointerClick className="h-4 w-4 shrink-0 text-[#38bdf8]" />
            Cliquez un bloc de la page — ses propriétés détaillées s'affichent ici.
          </p>
        )}
      </section>

      {/* LA BIBLIOTHÈQUE DE CARTES-MODULES */}
      <section className="flex-1 rounded-2xl border border-white/12 bg-[#0f0f12] p-4">
        <p className="font-mono text-[9.5px] font-semibold uppercase tracking-[0.2em] text-white/45">
          Bibliothèque de cartes
        </p>
        <div className="mt-3 space-y-2">
          {BIBLIOTHEQUE_MODULES.map((m) => {
            const actif = brouillon.actifs.includes(m.id);
            return (
              <div
                key={m.id}
                className={`flex items-center gap-3 rounded-xl border p-2.5 transition ${
                  actif ? "border-[#c9a96e]/40 bg-[#c9a96e]/[0.06]" : "border-white/10"
                }`}
              >
                <m.icon className={`h-4 w-4 shrink-0 ${actif ? "text-[#c9a96e]" : "text-white/40"}`} strokeWidth={1.6} />
                <span className="min-w-0 flex-1">
                  <span className="block text-[12px] font-semibold text-white/85">{m.label}</span>
                  <span className="block truncate text-[10.5px] text-white/40">{m.description}</span>
                </span>
                <button
                  type="button"
                  onClick={() => onToggle(m.id)}
                  aria-pressed={actif}
                  aria-label={actif ? `Retirer la carte ${m.label}` : `Poser la carte ${m.label} sur la page`}
                  className={`rounded-full p-1.5 transition ${
                    actif ? "bg-[#c9a96e]/20 text-[#c9a96e]" : "border border-white/20 text-white/50 hover:border-white/50 hover:text-white"
                  }`}
                >
                  {actif ? <Check className="h-3.5 w-3.5" /> : <Plus className="h-3.5 w-3.5" />}
                </button>
              </div>
            );
          })}
        </div>
      </section>

      {/* VALIDER — la page devient le compte. */}
      <button
        type="button"
        onClick={onValider}
        disabled={!nom.trim()}
        className="inline-flex items-center justify-center gap-2 rounded-xl bg-[#c9a96e] px-5 py-3 text-[13.5px] font-bold text-black transition hover:brightness-110 disabled:opacity-40"
      >
        <CheckCheck className="h-4 w-4" /> Créer mon compte
      </button>
      {!nom.trim() && (
        <p className="-mt-2 text-center font-mono text-[9px] uppercase tracking-[0.14em] text-white/30">
          Le nom (bloc Identité) est le seul champ requis
        </p>
      )}
    </div>
  );
}