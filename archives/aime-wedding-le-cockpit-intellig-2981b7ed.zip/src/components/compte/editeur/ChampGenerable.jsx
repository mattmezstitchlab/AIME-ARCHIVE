import { useState } from "react";
import { Sparkles, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";

// UN CHAMP DU PANNEAU — texte réglable, et générable par l'IA quand le
// module le permet (✨) : le prompt du champ est nourri du nom de la page.
export default function ChampGenerable({ champ, valeur, nom, onChange }) {
  const [loading, setLoading] = useState(false);

  const generer = async () => {
    setLoading(true);
    const texte = await base44.integrations.Core.InvokeLLM({
      prompt: champ.prompt.replaceAll("{nom}", nom || "cette personne") +
        (valeur ? ` Version actuelle à améliorer : « ${valeur} ».` : ""),
    });
    onChange(String(texte).trim());
    setLoading(false);
  };

  return (
    <label className="block">
      <span className="flex items-center justify-between">
        <span className="text-[11px] font-medium text-white/60">{champ.label}</span>
        {champ.generable && (
          <button
            type="button"
            onClick={generer}
            disabled={loading}
            aria-label={`Générer ${champ.label} par l'IA`}
            className="inline-flex items-center gap-1 rounded-full border border-[#c084fc]/50 px-2 py-0.5 font-mono text-[8.5px] font-bold uppercase tracking-[0.12em] text-[#c084fc] transition hover:bg-[#c084fc]/15 disabled:opacity-50"
          >
            {loading ? <Loader2 className="h-3 w-3 animate-spin" /> : <Sparkles className="h-3 w-3" />}
            Générer
          </button>
        )}
      </span>
      {champ.type === "long" ? (
        <textarea
          value={valeur}
          onChange={(e) => onChange(e.target.value)}
          rows={3}
          className="mt-1.5 w-full resize-none rounded-lg border border-white/15 bg-black/40 px-3 py-2 text-[12.5px] text-white placeholder:text-white/25 focus:border-[#38bdf8]/60 focus:outline-none"
        />
      ) : (
        <input
          type={champ.type === "date" ? "date" : "text"}
          value={valeur}
          onChange={(e) => onChange(e.target.value)}
          className="mt-1.5 w-full rounded-lg border border-white/15 bg-black/40 px-3 py-2 text-[12.5px] text-white placeholder:text-white/25 focus:border-[#38bdf8]/60 focus:outline-none"
        />
      )}
    </label>
  );
}