import { Eye, Rocket, HandHeart } from "lucide-react";

// L'ACCÈS RAPIDE — en haut de la page-personne : dire POURQUOI on est là.
// · Consulter : visiteur, on regarde, rien d'obligé.
// · Créer un projet : porteur — la page complète l'accompagne.
// · Participer : contributeur d'un événement (mariage…) — le MINIMUM
//   essentiel suffit pour être « présent » dans l'organisation ; le reste
//   peut se compléter plus tard, rien n'est perdu.
const MODES = [
  { id: "consulter", label: "Consulter", icon: Eye, hint: "Je découvre — rien d'obligé." },
  { id: "projet", label: "Créer un projet", icon: Rocket, hint: "Je porte un projet — ma page le raconte." },
  { id: "participer", label: "Participer à un événement", icon: HandHeart, hint: "Le minimum essentiel pour être présent." },
];

const EVENEMENTS = ["Mariage", "Anniversaire", "Concert / Spectacle", "Association", "Autre"];
const ROLES = ["Marié·e", "Prestataire", "Lieu", "Famille", "Témoin", "Invité", "Cortège", "Officiant", "Coordinateur"];

export default function AccesRapide({ acces = {}, onChange }) {
  const setMode = (mode) => onChange(mode === acces.mode ? {} : { mode });

  return (
    <div className="mb-5 rounded-2xl border border-white/12 bg-[#0f0f12] p-3.5">
      <p className="font-mono text-[9px] font-bold uppercase tracking-[0.22em] text-white/40">
        Accès rapide — vous êtes ici pour…
      </p>
      <div className="mt-2.5 flex flex-wrap gap-2">
        {MODES.map((m) => {
          const actif = acces.mode === m.id;
          return (
            <button
              key={m.id}
              type="button"
              onClick={() => setMode(m.id)}
              aria-pressed={actif}
              title={m.hint}
              className={`inline-flex items-center gap-1.5 rounded-full border px-3.5 py-1.5 text-[11.5px] font-semibold transition ${
                actif
                  ? "border-[#c9a96e] bg-[#c9a96e]/15 text-[#e6cf9f]"
                  : "border-white/15 text-white/60 hover:border-white/35 hover:text-white"
              }`}
            >
              <m.icon className="h-3.5 w-3.5" /> {m.label}
            </button>
          );
        })}
      </div>

      {/* PARTICIPER — l'événement + le rôle : le Registre retient l'essentiel. */}
      {acces.mode === "participer" && (
        <div className="mt-3 space-y-2.5 border-t border-white/10 pt-3">
          <div>
            <span className="font-mono text-[8.5px] uppercase tracking-[0.16em] text-white/35">L'événement</span>
            <div className="mt-1.5 flex flex-wrap gap-1.5">
              {EVENEMENTS.map((e) => (
                <button
                  key={e}
                  type="button"
                  onClick={() => onChange({ ...acces, evenement: e })}
                  aria-pressed={acces.evenement === e}
                  className={`rounded-full border px-2.5 py-1 text-[10.5px] transition ${
                    acces.evenement === e ? "border-[#38bdf8] bg-[#38bdf8]/15 text-[#7dd3fc]" : "border-white/15 text-white/55 hover:text-white"
                  }`}
                >
                  {e}
                </button>
              ))}
            </div>
          </div>
          <div>
            <span className="font-mono text-[8.5px] uppercase tracking-[0.16em] text-white/35">Mon rôle dedans</span>
            <div className="mt-1.5 flex flex-wrap gap-1.5">
              {ROLES.map((r) => (
                <button
                  key={r}
                  type="button"
                  onClick={() => onChange({ ...acces, role: r })}
                  aria-pressed={acces.role === r}
                  className={`rounded-full border px-2.5 py-1 text-[10.5px] transition ${
                    acces.role === r ? "border-[#c9a96e] bg-[#c9a96e]/15 text-[#e6cf9f]" : "border-white/15 text-white/55 hover:text-white"
                  }`}
                >
                  {r}
                </button>
              ))}
            </div>
          </div>
          <p className="text-[11px] leading-relaxed text-white/40">
            Il suffit du <strong className="text-white/65">nom</strong> et d'un moyen de contact : vous existez
            dans le Registre, l'organisation vous voit — le reste se complète quand vous voulez.
          </p>
        </div>
      )}
    </div>
  );
}