import { Link } from "react-router-dom";
import { Users, Music, Palette, CheckCircle2 } from "lucide-react";

export default function AvantSummary({ wedding }) {
  const guests = wedding.guests || [];
  const confirmed = guests.filter((g) => g.rsvp === "yes").length;
  const pending = guests.filter((g) => g.rsvp === "pending").length;
  const mustPlay = (wedding.must_play || []).length;
  const checklist = wedding.checklist_items || [];
  const done = checklist.filter((c) => c.status === "done").length;
  const colors = wedding.color_palette || [];
  const services = (wedding.linked_services || []).filter((s) => s.status === "booked").length;

  const hasData = guests.length > 0 || mustPlay > 0 || checklist.length > 0 || colors.length > 0;
  if (!hasData) return null;

  return (
    <section className="mx-auto max-w-7xl px-6 pb-6">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {guests.length > 0 && (
          <Link to="/invites-rsvp" className="group p-4 transition-colors hover:bg-muted/50 rounded-xl">
            <Users className="mb-2 h-4 w-4 text-foreground/30" />
            <p className="text-lg font-semibold text-foreground">{confirmed}<span className="text-foreground/30">/{guests.length}</span></p>
            <p className="text-[11px] text-muted-foreground">confirmés{pending > 0 ? ` · ${pending} en attente` : ""}</p>
          </Link>
        )}
        {mustPlay > 0 && (
          <Link to="/playlist" className="group p-4 transition-colors hover:bg-muted/50 rounded-xl">
            <Music className="mb-2 h-4 w-4 text-foreground/30" />
            <p className="text-lg font-semibold text-foreground">{mustPlay}</p>
            <p className="text-[11px] text-muted-foreground">titres souhaités</p>
          </Link>
        )}
        {colors.length > 0 && (
          <Link to="/avant/style-inspirations" className="group p-4 transition-colors hover:bg-muted/50 rounded-xl">
            <div className="mb-2 flex gap-1">
              {colors.slice(0, 5).map((c) => (
                <span key={c.id} className="h-4 w-4 rounded-full border border-border" style={{ backgroundColor: c.hex }} />
              ))}
            </div>
            <p className="text-[11px] text-muted-foreground">Palette du mariage</p>
          </Link>
        )}
        {checklist.length > 0 && (
          <div className="p-4 rounded-xl">
            <CheckCircle2 className="mb-2 h-4 w-4 text-foreground/30" />
            <p className="text-lg font-semibold text-foreground">{done}<span className="text-foreground/30">/{checklist.length}</span></p>
            <p className="text-[11px] text-muted-foreground">check-list{services > 0 ? ` · ${services} prestas réservés` : ""}</p>
          </div>
        )}
      </div>
    </section>
  );
}