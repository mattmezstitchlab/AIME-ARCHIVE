import { Link } from "react-router-dom";
import { Heart, MapPin } from "lucide-react";
import FavoriteButton from "@/components/FavoriteButton";
import ArtistImage from "@/components/ArtistImage";
import AddToPlanButton from "@/components/guide/AddToPlanButton";
import SampleBadge from "@/components/SampleBadge";

export default function ArtistCard({ artist }) {
  const fromPlan = new URLSearchParams(window.location.search).get("fromPlan");
  const to = fromPlan ? `/artiste/${artist.id}?fromPlan=${fromPlan}` : `/artiste/${artist.id}`;
  return (
    <Link
      to={to}
      className="group block rounded-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
      aria-label={`Voir le profil de ${artist.name}, ${artist.specialty} à ${artist.location}`}
    >
      <div className="aspect-[4/5] overflow-hidden rounded-lg mb-3 bg-muted relative">
        <ArtistImage
          src={artist.image_url}
          fallbackCategory={artist.category || artist.specialty}
          fallbackName={artist.name}
          alt={`${artist.name}, ${artist.specialty}`}
          className="w-full h-full transition-transform duration-700 group-hover:scale-105"
        />
        <FavoriteButton artist={artist} variant="card" />
        <AddToPlanButton artist={artist} variant="card" />
        {artist.available && (
          <span className="absolute top-3 left-3 bg-foreground text-background text-[10px] font-semibold px-2 py-1 rounded-full">
            Disponible
          </span>
        )}
        {artist.is_sample && <SampleBadge variant="card" />}
      </div>
      <div className="flex justify-between items-start">
        <div>
          <h3 className="font-semibold text-foreground text-sm group-hover:underline underline-offset-4">{artist.name}</h3>
          <p className="text-xs text-muted-foreground flex items-center gap-1">
            <MapPin className="w-3 h-3" />{artist.location}
          </p>
        </div>
        <div className="flex items-center gap-1 shrink-0">
          <Heart className="w-3.5 h-3.5 fill-foreground text-foreground" />
          <span className="text-sm font-medium text-foreground">{artist.rating}</span>
          <span className="text-xs text-muted-foreground">({artist.reviews_count})</span>
        </div>
      </div>
      <p className="text-xs text-muted-foreground mt-1">
        À partir de <span className="font-semibold text-foreground">{artist.price_from}€</span>
      </p>
    </Link>
  );
}