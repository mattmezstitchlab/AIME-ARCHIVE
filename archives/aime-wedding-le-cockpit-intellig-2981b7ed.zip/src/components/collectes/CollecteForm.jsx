import { useState } from "react";
import { base44 } from "@/api/base44Client";

const TYPES = ["chaussures", "vetements", "couchage", "hygiene", "instruments"];
const ORGAS = [
  { val: "association", label: "Association" },
  { val: "particulier", label: "Particulier" },
  { val: "entreprise", label: "Entreprise" },
  { val: "mairie", label: "Mairie" },
  { val: "ecole", label: "École" },
];
const inputCls = "mt-1 flex min-h-[46px] w-full rounded-xl border border-white/15 bg-[#141414] px-4 text-[13px] outline-none";

// LE FORMULAIRE DE COLLECTE FLASH — un point de collecte déclaré pour quelques jours.
export default function CollecteForm({ onCreated }) {
  const [f, setF] = useState({ title: "", donation_type: "chaussures", city: "", organizer_name: "", organizer_type: "association", target_quantity: "", action_date: "" });
  const [loading, setLoading] = useState(false);
  const set = (k, v) => setF((p) => ({ ...p, [k]: v }));

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    await base44.entities.DonationDrive.create({
      ...f,
      target_quantity: f.target_quantity ? Number(f.target_quantity) : undefined,
      action_date: f.action_date || undefined,
      status: "open",
    });
    setLoading(false);
    onCreated();
  };

  return (
    <form onSubmit={submit} className="rounded-2xl border border-[#F2B90D]/40 bg-[#141414] p-5">
      <p className="text-[14px] font-bold text-[#F2B90D]">Lancer une collecte flash</p>
      <div className="mt-4 grid gap-4 sm:grid-cols-2">
        <div className="sm:col-span-2">
          <label className="text-[12px] font-bold">Nom de la collecte</label>
          <input required value={f.title} onChange={(e) => set("title", e.target.value)} placeholder="Chaussures pour tous — Hiver 2026" className={inputCls} />
        </div>
        <div>
          <label className="text-[12px] font-bold">Nature des dons</label>
          <select value={f.donation_type} onChange={(e) => set("donation_type", e.target.value)} className={`${inputCls} cursor-pointer appearance-none pr-8`}>
            {TYPES.map((t) => <option key={t} value={t}>{t.charAt(0).toUpperCase() + t.slice(1)}</option>)}
          </select>
        </div>
        <div>
          <label className="text-[12px] font-bold">Ville</label>
          <input required value={f.city} onChange={(e) => set("city", e.target.value)} placeholder="Lille" className={inputCls} />
        </div>
        <div>
          <label className="text-[12px] font-bold">Qui porte le point</label>
          <select value={f.organizer_type} onChange={(e) => set("organizer_type", e.target.value)} className={`${inputCls} cursor-pointer appearance-none pr-8`}>
            {ORGAS.map((o) => <option key={o.val} value={o.val}>{o.label}</option>)}
          </select>
        </div>
        <div>
          <label className="text-[12px] font-bold">Nom de l'organisateur</label>
          <input required value={f.organizer_name} onChange={(e) => set("organizer_name", e.target.value)} placeholder="Les Restos du Cœur Lille" className={inputCls} />
        </div>
        <div>
          <label className="text-[12px] font-bold">Objectif (quantité)</label>
          <input type="number" min="1" value={f.target_quantity} onChange={(e) => set("target_quantity", e.target.value)} placeholder="100" className={inputCls} />
        </div>
        <div>
          <label className="text-[12px] font-bold">Date J</label>
          <input type="date" value={f.action_date} onChange={(e) => set("action_date", e.target.value)} className={inputCls} />
        </div>
      </div>
      <button type="submit" disabled={loading}
        className="mt-5 flex min-h-[46px] items-center justify-center rounded-full bg-[#F2B90D] px-8 text-[13px] font-bold text-black transition hover:opacity-85 disabled:opacity-40">
        {loading ? "Création…" : "Ouvrir la collecte"}
      </button>
    </form>
  );
}