import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { MapPin, CalendarDays, Share2 } from "lucide-react";

// LA CARTE D'UNE COLLECTE FLASH — compteur public en direct + promesse en 1 geste.
export default function CollecteCarte({ drive, onUpdate }) {
  const [pledge, setPledge] = useState({ name: "", quantity: "" });
  const [saving, setSaving] = useState(false);
  const [merci, setMerci] = useState(false);
  const [copie, setCopie] = useState(false);

  // LE DON D'ANNIVERSAIRE — la collecte se partage en un geste.
  const partager = async () => {
    await navigator.clipboard.writeText(`${window.location.origin}/collectes`);
    setCopie(true);
    setTimeout(() => setCopie(false), 2000);
  };

  const total = drive.collected_quantity || 0;
  const objectif = drive.target_quantity || 0;
  const pct = objectif ? Math.min(100, Math.round((total / objectif) * 100)) : 0;

  const promettre = async (e) => {
    e.preventDefault();
    const q = Number(pledge.quantity) || 1;
    setSaving(true);
    await base44.entities.DonationDrive.update(drive.id, {
      pledges: [...(drive.pledges || []), { name: pledge.name || "Anonyme", quantity: q }],
      collected_quantity: total + q,
    });
    setSaving(false);
    setMerci(true);
    setPledge({ name: "", quantity: "" });
    onUpdate();
  };

  return (
    <div className="rounded-2xl border border-white/15 bg-[#141414] p-5">
      <div className="flex items-start justify-between gap-3">
        <p className="text-[15px] font-bold leading-snug">{drive.title}</p>
        <div className="flex shrink-0 items-center gap-1.5">
          <span className="rounded-full bg-[#F2B90D] px-3 py-1 text-[11px] font-bold text-black capitalize">{drive.donation_type}</span>
          <button type="button" onClick={partager} aria-label="Partager cette collecte" title={copie ? "Lien copié !" : "Partager"}
            className="flex h-7 w-7 items-center justify-center rounded-full text-white/60 transition hover:bg-white/10 hover:text-white">
            <Share2 className="h-3.5 w-3.5" aria-hidden="true" />
          </button>
        </div>
      </div>
      <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-[12px] text-white/60">
        {drive.city && <span className="flex items-center gap-1"><MapPin className="h-3.5 w-3.5 text-[#F2B90D]" aria-hidden="true" />{drive.city}</span>}
        {drive.action_date && <span className="flex items-center gap-1"><CalendarDays className="h-3.5 w-3.5 text-[#F2B90D]" aria-hidden="true" />Jour J : {new Date(drive.action_date).toLocaleDateString("fr-FR")}</span>}
        {drive.organizer_name && <span>Porté par {drive.organizer_name}</span>}
      </div>

      {/* Le compteur public en direct */}
      <div className="mt-4">
        <div className="flex items-baseline justify-between">
          <p className="text-[20px] font-extrabold text-[#F2B90D]">{total}{objectif ? ` / ${objectif}` : ""}</p>
          {objectif > 0 && <p className="text-[11px] font-bold text-white/50">{pct}%</p>}
        </div>
        <div className="mt-1.5 h-2 overflow-hidden rounded-full bg-white/10">
          <div className="h-full rounded-full bg-[#F2B90D] transition-all duration-700" style={{ width: `${objectif ? pct : total > 0 ? 100 : 0}%` }} />
        </div>
      </div>

      {merci ? (
        <p className="mt-4 text-[13px] font-bold text-[#F2B90D]">Merci — votre promesse est comptée.</p>
      ) : (
        <form onSubmit={promettre} className="mt-4 flex gap-2">
          <input value={pledge.name} onChange={(e) => setPledge((p) => ({ ...p, name: e.target.value }))} placeholder="Votre prénom"
            className="min-h-[42px] flex-1 rounded-xl border border-white/15 bg-[#0D0D0D] px-3 text-[12px] outline-none" />
          <input required type="number" min="1" value={pledge.quantity} onChange={(e) => setPledge((p) => ({ ...p, quantity: e.target.value }))} placeholder="Qté"
            className="min-h-[42px] w-16 rounded-xl border border-white/15 bg-[#0D0D0D] px-3 text-[12px] outline-none" />
          <button type="submit" disabled={saving}
            className="min-h-[42px] rounded-full bg-[#F2B90D] px-4 text-[12px] font-bold text-black transition hover:opacity-85 disabled:opacity-40">
            {saving ? "…" : "Je promets"}
          </button>
        </form>
      )}
    </div>
  );
}