// La navigation principale du site est désormais MainNav (5 espaces + Profil),
// rendue dans le Layout. On ne conserve plus de header flottant séparé pour
// garder une interface épurée et sans doublon de navigation.
export default function Header() {
  return null;
}