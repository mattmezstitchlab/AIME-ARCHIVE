import { useState, useMemo, useRef, useEffect } from "react";
import { Route, Database, Server, Plug, GitBranch, Boxes } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { ROUTES, ENTITIES, FUNCTIONS, INTEGRATIONS, STATUS_META, buildHealthSummary } from "@/lib/health/siteMap";
import RippleCoreImporter from "./phases/RippleCoreImporter";
import AtlasProjectSystem from "@/components/aime/atlas/AtlasProjectSystem";
import MoteurLayerPanel from "./moteur/MoteurLayerPanel";

// ── Le vrai MOTEUR : une carte cartographique à COUCHES superposables ────────
// Chaque strate du site (Projets, Routes, Entités, Fonctions, Intégrations,
// Liens causaux) est un CALQUE qu'on active/désactive dans le panneau de filtres
// — façon brevet Ripple mariage. Les nœuds de chaque couche se dispersent en
// anneaux autour du noyau doré central (le point zéro), reliés par des traits
// causaux. UNE SEULE cartographie de navigation pour tout : l'Atlas des projets
// est simplement une couche de plus, et cliquer un projet zoome dans son
// sous-système radial (SYSTAIME fractal).

// Définition des couches, avec leur couleur, leur rayon d'orbite et leurs nœuds.
function buildLayers(projects) {
  const s = buildHealthSummary();
  return [
    {
      key: "projects",
      label: "Projets (Atlas)",
      icon: Boxes,
      color: "#c9b88f",
      radius: 560,
      count: projects.length,
      nodes: projects.map((p) => ({ id: p.slug || p.id, label: p.title, tone: p.color || "#c9b88f", project: p })),
    },
    {
      key: "routes",
      label: "Routes",
      icon: Route,
      color: "#38bdf8",
      radius: 340,
      count: ROUTES.length,
      nodes: ROUTES.map((r) => ({
        id: r.path,
        label: r.name,
        tone: (STATUS_META[r.status] || STATUS_META.live).color,
      })),
    },
    {
      key: "entities",
      label: "Entités",
      icon: Database,
      color: "#34d399",
      radius: 210,
      count: ENTITIES.length,
      nodes: ENTITIES.map((e) => ({ id: e.name, label: e.name, tone: e.wired ? "#34d399" : "#94a3b8" })),
    },
    {
      key: "functions",
      label: "Fonctions",
      icon: Server,
      color: "#fbbf24",
      radius: 130,
      count: FUNCTIONS.length,
      nodes: FUNCTIONS.map((f) => ({ id: f.name, label: f.name, tone: "#fbbf24" })),
    },
    {
      key: "integrations",
      label: "Intégrations",
      icon: Plug,
      color: "#c084fc",
      radius: 460,
      count: INTEGRATIONS.length,
      nodes: INTEGRATIONS.map((i) => ({ id: i.name, label: i.name, tone: i.status === "ok" ? "#34d399" : "#fbbf24" })),
    },
    {
      key: "links",
      label: "Liens causaux",
      icon: GitBranch,
      color: "#f472b6",
      radius: 0, // couche de traits, pas de nœuds propres
      count: s.totalRoutes,
      nodes: [],
    },
  ];
}

// Positionne les nœuds d'une couche en anneau (angle réparti + léger décalage).
function ringPositions(nodes, radius, phase = 0) {
  const n = nodes.length || 1;
  return nodes.map((node, i) => {
    const angle = phase + (i / n) * Math.PI * 2;
    return {
      ...node,
      x: Math.cos(angle) * radius,
      y: Math.sin(angle) * radius,
    };
  });
}

export default function RippleMoteurMap({ spin = 0, showPanel = true, activeLayers, onToggleLayer }) {
  const [projects, setProjects] = useState([]);
  useEffect(() => {
    base44.entities.AtlasProject.list("order").then(setProjects).catch(() => setProjects([]));
  }, []);

  // Rotation continue du plan moteur : l'angle avance en boucle, la vitesse
  // suit `spin` (0 = arrêté). C'est le moteur qu'on voit tourner, plus ou moins
  // vite selon les réglages de la console.
  const [angle, setAngle] = useState(0);
  const spinRafRef = useRef();
  const spinLastRef = useRef();
  useEffect(() => {
    if (spin <= 0) {
      spinLastRef.current = undefined;
      cancelAnimationFrame(spinRafRef.current);
      return;
    }
    const tick = (ts) => {
      if (spinLastRef.current === undefined) spinLastRef.current = ts;
      const dt = (ts - spinLastRef.current) / 1000;
      spinLastRef.current = ts;
      setAngle((a) => (a + dt * spin * 18) % 360);
      spinRafRef.current = requestAnimationFrame(tick);
    };
    spinRafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(spinRafRef.current);
  }, [spin]);

  const layers = useMemo(() => buildLayers(projects), [projects]);
  // Les calques peuvent être pilotés de l'extérieur (dossier MOTEUR de l'arbre)
  // ou gérés en interne (usage autonome, ex. page /moteur).
  const [internalActive, setInternalActive] = useState(() => ({
    projects: true,
    routes: true,
    entities: true,
    functions: true,
    integrations: false,
    links: true,
  }));
  const active = activeLayers || internalActive;
  const [hovered, setHovered] = useState(null);

  // Zoom dans le sous-système d'un projet (SYSTAIME fractal).
  const [zoomed, setZoomed] = useState(null);

  // ── Point zéro : tri d'une info importée, puis onde vers les nœuds réels ────
  const [imported, setImported] = useState(null); // { name, dest, mode }
  const [litIds, setLitIds] = useState([]);
  const [propagating, setPropagating] = useState(false);
  const timers = useRef([]);
  useEffect(() => () => timers.current.forEach(clearTimeout), []);

  const toggle = (key) =>
    onToggleLayer ? onToggleLayer(key) : setInternalActive((a) => ({ ...a, [key]: !a[key] }));

  // Nœuds positionnés des couches actives (hors couche de liens).
  const placed = layers
    .filter((l) => l.key !== "links" && active[l.key])
    .map((l, li) => ({
      ...l,
      placedNodes: ringPositions(l.nodes, l.radius, li * 0.6),
    }));

  const showLinks = active.links;

  // Tous les IDs de nœuds actuellement placés — cible de l'onde du point zéro.
  const allNodeIds = placed.flatMap((l) => l.placedNodes.map((n) => `${l.key}:${n.id}`));

  // Propagation depuis le point zéro : allume les vrais nœuds un par un.
  const propagate = (file, reco, dest) => {
    timers.current.forEach(clearTimeout);
    timers.current = [];
    setImported({ name: file.name, dest, mode: "propagated" });
    setLitIds([]);
    setPropagating(true);
    if (allNodeIds.length === 0) { setPropagating(false); return; }
    allNodeIds.forEach((id, i) => {
      const t = setTimeout(() => {
        setLitIds((prev) => [...prev, id]);
        if (i === allNodeIds.length - 1) setPropagating(false);
      }, 160 + i * 45);
      timers.current.push(t);
    });
  };

  // Déposer sans propager : le point zéro garde l'info en transit.
  const store = (file, reco, dest) => {
    timers.current.forEach(clearTimeout);
    timers.current = [];
    setLitIds([]);
    setPropagating(false);
    setImported({ name: file.name, dest, mode: "transit" });
  };

  // Clic sur un nœud : si c'est un projet → zoom dans son sous-système.
  const handleNodeClick = (layerKey, node) => {
    if (layerKey === "projects" && node.project) setZoomed(node.project);
  };

  // Vue zoomée : le sous-système radial du projet remplit la carte.
  if (zoomed) {
    return <AtlasProjectSystem project={zoomed} onBack={() => setZoomed(null)} />;
  }

  return (
    <div className="relative flex h-full w-full items-center justify-center">
      {/* Le plan cartographique : plein écran, centré sur le noyau doré (0,0) */}
      <div className="pointer-events-none absolute left-1/2 top-1/2 h-0 w-0 -translate-x-1/2 -translate-y-1/2">
        <svg width="1" height="1" className="overflow-visible" aria-hidden="true">
         <g transform={`rotate(${angle})`}>
          {/* Anneaux d'orbite des couches actives */}
          {placed.map((l) => (
            <circle key={`orbit-${l.key}`} cx="0" cy="0" r={l.radius} fill="none" stroke={l.color} strokeOpacity="0.18" strokeDasharray="3 6" />
          ))}

          {/* Traits causaux : chaque nœud relié au noyau (si couche liens active) */}
          {showLinks &&
            placed.flatMap((l) =>
              l.placedNodes.map((node) => (
                <line key={`link-${l.key}-${node.id}`} x1="0" y1="0" x2={node.x} y2={node.y} stroke={l.color} strokeOpacity="0.22" strokeWidth="1" />
              ))
            )}

          {/* Nœuds de chaque couche active */}
          {placed.flatMap((l) =>
            l.placedNodes.map((node) => {
              const isHover = hovered?.id === node.id && hovered?.layer === l.key;
              const isLit = litIds.includes(`${l.key}:${node.id}`);
              const isProject = l.key === "projects";
              return (
                <g
                  key={`node-${l.key}-${node.id}`}
                  transform={`translate(${node.x}, ${node.y})`}
                  className="pointer-events-auto cursor-pointer"
                  onMouseEnter={() => setHovered({ ...node, layer: l.key, layerLabel: l.label })}
                  onMouseLeave={() => setHovered(null)}
                  onClick={() => handleNodeClick(l.key, node)}
                >
                  {isLit && <circle r="14" fill="none" stroke="#c9b88f" strokeOpacity="0.7" className="ripple-wave" />}
                  {/* Les projets sont des nœuds plus gros, cerclés (ce sont des mondes). */}
                  {isProject && <circle r={isHover || isLit ? 12 : 9} fill="none" stroke={node.tone} strokeOpacity="0.5" />}
                  <circle r={isProject ? (isHover || isLit ? 7 : 5.5) : (isHover || isLit ? 7 : 4.5)} fill={isLit ? "#c9b88f" : node.tone} className="transition-all" />
                  {isHover && !isProject && <circle r="12" fill="none" stroke={node.tone} strokeOpacity="0.5" />}
                </g>
              );
            })
          )}
         </g>
        </svg>
      </div>

      {/* Le POINT ZÉRO — noyau doré central cliquable. */}
      <div className="pointer-events-none absolute left-1/2 top-1/2 h-40 w-40 -translate-x-1/2 -translate-y-1/2">
        <RippleCoreImporter onPropagate={propagate} onStore={store} propagating={propagating} />
      </div>

      {/* Trace de l'info triée par le point zéro — propagée ou en transit */}
      {imported && (
        <div className={`pointer-events-none absolute bottom-28 left-1/2 flex -translate-x-1/2 flex-wrap items-center justify-center gap-2 rounded-full border px-4 py-2 shadow-lg backdrop-blur ${
          imported.mode === "transit" ? "border-border bg-background/90" : "border-accent/50 bg-accent/10"
        }`}>
          <span className="rounded-full border border-border px-2 py-0.5 text-[9px] font-bold uppercase tracking-[0.12em] text-muted-foreground">
            {imported.dest.phaseLabel}
          </span>
          <p className="text-[11px] font-medium text-foreground">
            {imported.mode === "transit"
              ? "En transit dans le noyau (non propagé) :"
              : propagating ? "Propagation sur la carte réelle…" : "Trié & propagé :"}{" "}
            <span className="font-semibold text-accent">{imported.name}</span>
          </p>
        </div>
      )}

      {/* Étiquette flottante du nœud survolé */}
      {hovered && (
        <div className="pointer-events-none absolute left-1/2 top-20 -translate-x-1/2 rounded-full border border-border bg-background/95 px-4 py-1.5 shadow-lg backdrop-blur">
          <span className="text-[10px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">{hovered.layerLabel}</span>
          <span className="mx-2 text-border">·</span>
          <span className="font-heading text-sm font-semibold text-foreground">{hovered.label}</span>
          {hovered.layer === "projects" && <span className="ml-2 text-[10px] font-medium text-accent">cliquer pour zoomer →</span>}
        </div>
      )}

      {/* Panneau du moteur — les couches + Design System & Dossier déployables.
          Masquable : dans le mode Bureau, les couches sont pilotées par l'arbre de gauche. */}
      {showPanel && <MoteurLayerPanel layers={layers} active={active} onToggle={toggle} />}

      {/* Légende compacte en bas à gauche (au-dessus de la dock) */}
      <div className="pointer-events-none absolute bottom-28 left-5 flex flex-wrap gap-x-4 gap-y-1.5 rounded-xl border border-border bg-background/80 px-4 py-2 backdrop-blur">
        {layers.filter((l) => active[l.key] && l.key !== "links").map((l) => (
          <span key={l.key} className="flex items-center gap-1.5 text-[10px] font-medium text-muted-foreground">
            <span className="h-2 w-2 rounded-full" style={{ backgroundColor: l.color }} />
            {l.label}
          </span>
        ))}
      </div>
    </div>
  );
}