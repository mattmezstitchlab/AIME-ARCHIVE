import { useState, useEffect, useRef } from "react";
import {
  RotateCcw, SunDim, Sun, ZoomIn, ZoomOut, Moon, LayoutGrid, AlignJustify, Snowflake,
  Link, SquareDashed, Sparkles, ShoppingCart, CreditCard, MapPin, ClipboardCheck,
  PhoneCall, FileText, Languages, BookOpen, Volume2, VolumeX, Navigation, LifeBuoy,
  List, ArrowLeft, ArrowRight, IdCard, Keyboard as KeyboardIcon,
} from "lucide-react";
import { KEYBOARD_ROWS, keyMatch } from "@/lib/ripple/keyboardLayout";
import { ACTIONS } from "@/lib/ripple/keyboardActions";

const ICONS = {
  RotateCcw, SunDim, Sun, ZoomIn, ZoomOut, Moon, LayoutGrid, AlignJustify, Snowflake,
  Link, SquareDashed, Sparkles, ShoppingCart, CreditCard, MapPin, ClipboardCheck,
  PhoneCall, FileText, Languages, BookOpen, Volume2, VolumeX, Navigation, LifeBuoy,
  List, ArrowLeft, ArrowRight, IdCard,
};

// ─────────────────────────────────────────────────────────────────────────
// VRAI CLAVIER D'ACCESSIBILITÉ (façon Mac/Windows) — chaque touche porte un
// raccourci. On écoute les VRAIES frappes du clavier physique : la touche
// pressée s'allume à l'écran et déclenche son action. On peut aussi cliquer.
// Réglages EAA (touches F) + super-pouvoirs inédits (essentiel, achat, coller
// identité/RIB, remplir formulaire, lire, traduire, simplifier…).
// ─────────────────────────────────────────────────────────────────────────
export default function SmartKeyboard({ onAction }) {
  const [pressed, setPressed] = useState(null); // code de la touche allumée
  const [last, setLast] = useState(null); // dernière action déclenchée (id)
  const timer = useRef(null);

  const trigger = (key) => {
    if (!key) return;
    setPressed(key.code);
    if (key.action) {
      setLast(key.action);
      onAction?.(key.action, key);
    }
    clearTimeout(timer.current);
    timer.current = setTimeout(() => setPressed(null), 260);
  };

  // Écoute des vraies frappes physiques du clavier.
  useEffect(() => {
    const onKeyDown = (e) => {
      const key = keyMatch(e);
      if (!key) return;
      // On empêche seulement les touches qui ont une action (évite F1=aide navigateur…).
      if (key.action || /^F\d/.test(key.code)) e.preventDefault();
      trigger(key);
    };
    window.addEventListener("keydown", onKeyDown);
    return () => { window.removeEventListener("keydown", onKeyDown); clearTimeout(timer.current); };
  }, []);

  const lastAction = last ? ACTIONS[last] : null;
  const LastIcon = lastAction ? ICONS[lastAction.icon] || Sparkles : null;

  return (
    <div>
      {/* Bandeau : dernière action déclenchée */}
      <div className="mb-3 flex items-center gap-2 rounded-xl bg-white/[0.04] px-3 py-2.5 text-white/80">
        {LastIcon ? <LastIcon className="h-4 w-4 text-accent" /> : <KeyboardIcon className="h-4 w-4 text-white/40" />}
        <div className="min-w-0">
          <p className="text-[12px] font-semibold text-white">
            {lastAction ? lastAction.title : "Appuie sur une touche de ton clavier"}
          </p>
          <p className="truncate text-[10.5px] text-white/50">
            {lastAction ? lastAction.desc : "Chaque touche est un raccourci d'accessibilité — la touche pressée s'allume ci-dessous."}
          </p>
        </div>
      </div>

      {/* Le clavier physique */}
      <div className="overflow-x-auto scrollbar-hide">
        <div className="mx-auto w-max rounded-2xl bg-gradient-to-b from-neutral-700/40 to-neutral-900/60 p-2.5 ring-1 ring-white/10">
          <div className="space-y-1.5">
            {KEYBOARD_ROWS.map((row, ri) => (
              <div key={ri} className="flex justify-center gap-1.5">
                {row.map((k) => (
                  <Key key={k.code} k={k} on={pressed === k.code} onClick={() => trigger(k)} />
                ))}
              </div>
            ))}
          </div>
        </div>
      </div>

      <p className="mt-3 text-[10px] leading-snug text-white/40">
        Clavier universel de conformité : les touches système (F1–F12) règlent l'accessibilité EAA,
        les lettres et chiffres déclenchent des super-pouvoirs — afficher l'essentiel, acheter, coller
        son identité ou son RIB, remplir un formulaire, lire à voix haute — sans jamais refaire le site.
      </p>
    </div>
  );
}

// Une touche (keycap).
function Key({ k, on, onClick }) {
  const Icon = k.action ? ICONS[ACTIONS[k.action]?.icon] : null;
  const wideStyle = k.wide ? { flexBasis: `${k.wide * 2.75}rem` } : undefined;
  const hasPower = !!k.action;

  return (
    <button
      type="button"
      onClick={onClick}
      style={wideStyle}
      title={k.action ? ACTIONS[k.action]?.title : k.label}
      className={`relative flex h-11 min-w-[2.4rem] flex-col items-center justify-center rounded-md border px-1 text-center transition-all duration-75 ${
        k.wide ? "flex-1" : ""
      } ${
        on
          ? "-translate-y-px border-accent bg-accent text-accent-foreground shadow-[0_0_0_2px_rgba(201,184,143,0.35)]"
          : hasPower
          ? "border-white/15 bg-gradient-to-b from-neutral-700/70 to-neutral-900 text-white/85 hover:border-accent/50"
          : "border-white/10 bg-gradient-to-b from-neutral-800 to-neutral-900 text-white/45"
      }`}
    >
      <span className="flex items-center gap-0.5 text-[10px] font-semibold leading-none">
        {k.label}
        {Icon && <Icon className={`h-3 w-3 ${on ? "text-accent-foreground" : "text-accent/80"}`} />}
      </span>
      {k.sub && (
        <span className={`mt-0.5 max-w-[3.6rem] truncate text-[7.5px] leading-none ${on ? "text-accent-foreground/80" : "text-white/40"}`}>
          {k.sub}
        </span>
      )}
    </button>
  );
}