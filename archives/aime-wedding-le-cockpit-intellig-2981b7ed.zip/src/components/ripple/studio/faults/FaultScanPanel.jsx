import { useState } from "react";
import { ScanSearch, Loader2, AlertTriangle, ShieldCheck, Layers } from "lucide-react";
import { scanFaults } from "@/lib/gallery/eaaAudit";
import FaultBlockCard from "./FaultBlockCard";

// ─────────────────────────────────────────────────────────────────────────
// PANNEAU D'AUDIT PAR BLOCS — le vrai problème résolu :
//   1. On scanne le code réel du site à partir de son URL.
//   2. On surligne chaque zone fautive (failles EAA/WCAG localisées).
//   3. On traite et régénère chaque bloc indépendamment.
//   4. On reconstitue le site conforme morceau par morceau.
// ─────────────────────────────────────────────────────────────────────────
export default function FaultScanPanel({ url }) {
  const [state, setState] = useState({ status: "idle", data: null, error: null });
  const [fixedIds, setFixedIds] = useState([]);

  const run = async () => {
    if (!url?.trim()) return;
    setState({ status: "loading", data: null, error: null });
    setFixedIds([]);
    try {
      const data = await scanFaults(url.trim());
      if (data?.error) setState({ status: "error", data: null, error: data.error });
      else setState({ status: "done", data, error: null });
    } catch {
      setState({ status: "error", data: null, error: "Analyse impossible." });
    }
  };

  const data = state.data;
  const remaining = data ? data.counts.faulty - fixedIds.filter((id) => data.blocks.find((b) => b.id === id)?.status === "faulty").length : 0;

  return (
    <div>
      {/* Lanceur du scan */}
      <div className="flex items-center gap-2">
        <button
          onClick={run}
          disabled={!url?.trim() || state.status === "loading"}
          className="inline-flex flex-1 items-center justify-center gap-2 rounded-full bg-white px-4 py-2.5 text-[13px] font-semibold text-black transition hover:bg-white/90 disabled:opacity-40"
        >
          {state.status === "loading" ? <Loader2 className="h-4 w-4 animate-spin" /> : <ScanSearch className="h-4 w-4" />}
          {state.status === "loading" ? "Analyse du code en cours…" : "Détecter les failles du site"}
        </button>
      </div>
      {!url?.trim() && (
        <p className="mt-2 text-center text-[11px] text-white/40">Colle l'URL de ton site plus haut pour lancer l'audit.</p>
      )}

      {state.status === "error" && (
        <div className="mt-3 flex items-center gap-2 rounded-xl bg-amber-500/10 px-4 py-3 text-[12px] text-amber-300">
          <AlertTriangle className="h-4 w-4 shrink-0" />
          {state.error} — certains sites bloquent l'analyse automatique.
        </div>
      )}

      {state.status === "done" && data && (
        <div className="mt-4">
          {/* Bilan */}
          <div className="mb-4 grid grid-cols-3 gap-2">
            <Stat icon={ShieldCheck} label="Conformité" value={`${data.score}/100`} tone={data.score >= 80 ? "good" : data.score >= 50 ? "warn" : "bad"} />
            <Stat icon={Layers} label="Zones fautives" value={`${data.counts.faulty}/${data.counts.blocks}`} tone={data.counts.faulty ? "warn" : "good"} />
            <Stat icon={AlertTriangle} label="Failles" value={data.counts.faults} tone={data.counts.faults ? "bad" : "good"} />
          </div>

          <p className="mb-3 text-[11px] text-white/50">
            {data.counts.faults > 0
              ? "Chaque zone en surbrillance est traitée à part, puis régénérée conforme — le site se reconstitue morceau par morceau."
              : "Aucune faille détectée : ce site est déjà conforme sur les points contrôlés."}
          </p>

          {/* Zones scannées, fautives en tête */}
          <div className="space-y-2.5">
            {[...data.blocks]
              .sort((a, b) => (b.faults.length > 0) - (a.faults.length > 0))
              .map((b) => (
                <FaultBlockCard key={b.id} block={b} onFixed={(id) => setFixedIds((ids) => [...new Set([...ids, id])])} />
              ))}
          </div>

          {fixedIds.length > 0 && (
            <p className="mt-4 rounded-xl bg-emerald-500/10 px-4 py-3 text-center text-[12px] text-emerald-300">
              {fixedIds.length} bloc{fixedIds.length > 1 ? "s" : ""} reconstruit{fixedIds.length > 1 ? "s" : ""} et conforme{fixedIds.length > 1 ? "s" : ""}.
              {remaining > 0 ? ` Encore ${remaining} zone${remaining > 1 ? "s" : ""} à traiter.` : " Le site est entièrement reconstitué."}
            </p>
          )}
        </div>
      )}
    </div>
  );
}

function Stat({ icon: Icon, label, value, tone }) {
  const tones = {
    good: "text-emerald-300",
    warn: "text-amber-300",
    bad: "text-red-300",
  };
  return (
    <div className="rounded-xl bg-white/[0.04] px-3 py-2.5 text-center">
      <Icon className={`mx-auto mb-1 h-4 w-4 ${tones[tone] || "text-white/60"}`} />
      <p className={`text-[15px] font-bold ${tones[tone] || "text-white"}`}>{value}</p>
      <p className="text-[9px] uppercase tracking-[0.1em] text-white/40">{label}</p>
    </div>
  );
}