import { useState } from "react";
import { AlertTriangle, CheckCircle2, Wand2, Loader2, ChevronDown, Code2 } from "lucide-react";
import { regenerateBlock } from "@/lib/gallery/eaaAudit";

const SEVERITY = {
  bloquant: { dot: "bg-red-500", text: "text-red-300", label: "Bloquant" },
  majeur: { dot: "bg-amber-500", text: "text-amber-300", label: "Majeur" },
  mineur: { dot: "bg-sky-500", text: "text-sky-300", label: "Mineur" },
};

// ─────────────────────────────────────────────────────────────────────────
// Carte d'une ZONE du site : surlignée si fautive, avec ses failles localisées.
// Bouton « Régénérer ce bloc » → traite la zone indépendamment et affiche le
// code corrigé, conforme. Pièce du puzzle qu'on reconstitue morceau par morceau.
// ─────────────────────────────────────────────────────────────────────────
export default function FaultBlockCard({ block, onFixed }) {
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [fixed, setFixed] = useState(null); // résultat de la régénération

  const isOk = block.status === "ok";
  const done = !!fixed;

  const handleFix = async () => {
    setBusy(true);
    const result = await regenerateBlock(block);
    setBusy(false);
    setFixed(result);
    setOpen(true);
    onFixed?.(block.id);
  };

  return (
    <div
      className={`overflow-hidden rounded-xl border transition ${
        done
          ? "border-emerald-500/40 bg-emerald-500/[0.04]"
          : isOk
          ? "border-white/10 bg-white/[0.02]"
          : "border-amber-500/40 bg-amber-500/[0.05]"
      }`}
    >
      <div className="flex items-start gap-3 px-4 py-3">
        <span
          className={`mt-0.5 inline-flex h-7 w-7 shrink-0 items-center justify-center rounded-full ${
            done ? "bg-emerald-500/20 text-emerald-300" : isOk ? "bg-white/10 text-white/50" : "bg-amber-500/20 text-amber-300"
          }`}
        >
          {done || isOk ? <CheckCircle2 className="h-4 w-4" /> : <AlertTriangle className="h-4 w-4" />}
        </span>

        <div className="min-w-0 flex-1">
          <div className="flex items-center justify-between gap-2">
            <p className="truncate text-[13px] font-semibold text-white">{block.label}</p>
            <code className="shrink-0 rounded bg-white/8 px-1.5 py-0.5 text-[10px] text-white/50">&lt;{block.tag}&gt;</code>
          </div>

          {done ? (
            <p className="mt-0.5 text-[11px] text-emerald-300/90">Zone reconstruite, conforme — {fixed.summary}</p>
          ) : isOk ? (
            <p className="mt-0.5 text-[11px] text-white/40">Aucune faille détectée sur cette zone.</p>
          ) : (
            <p className="mt-0.5 text-[11px] text-amber-300/80">
              {block.faults.length} faille{block.faults.length > 1 ? "s" : ""} à traiter
            </p>
          )}

          {/* Failles localisées */}
          {!isOk && !done && (
            <ul className="mt-2 space-y-1.5">
              {block.faults.map((f, i) => {
                const s = SEVERITY[f.severity] || SEVERITY.mineur;
                return (
                  <li key={i} className="flex items-start gap-2 text-[11px]">
                    <span className={`mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full ${s.dot}`} />
                    <span className="min-w-0">
                      <span className={`font-medium ${s.text}`}>{s.label}</span>
                      <span className="text-white/40"> · WCAG {f.wcag}</span>
                      <span className="block text-white/70">{f.message}</span>
                      {f.evidence && (
                        <code className="mt-0.5 block truncate rounded bg-black/40 px-1.5 py-0.5 text-[10px] text-white/40">
                          {f.evidence}
                        </code>
                      )}
                    </span>
                  </li>
                );
              })}
            </ul>
          )}

          {/* Actions */}
          <div className="mt-2.5 flex items-center gap-2">
            {!isOk && (
              <button
                onClick={handleFix}
                disabled={busy}
                className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[11px] font-medium transition ${
                  done ? "bg-emerald-500/15 text-emerald-300 hover:bg-emerald-500/25" : "bg-accent text-accent-foreground hover:bg-accent/90"
                } disabled:opacity-50`}
              >
                {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Wand2 className="h-3.5 w-3.5" />}
                {busy ? "Reconstruction…" : done ? "Régénérer à nouveau" : "Régénérer ce bloc"}
              </button>
            )}
            {(done || block.snippet) && (
              <button
                onClick={() => setOpen((o) => !o)}
                className="inline-flex items-center gap-1 rounded-full bg-white/8 px-2.5 py-1.5 text-[11px] text-white/60 hover:bg-white/15"
              >
                <Code2 className="h-3.5 w-3.5" />
                Code
                <ChevronDown className={`h-3 w-3 transition-transform ${open ? "rotate-180" : ""}`} />
              </button>
            )}
          </div>
        </div>
      </div>

      {open && (
        <div className="border-t border-white/10 bg-black/40 px-4 py-3">
          {done && (
            <>
              <p className="mb-1.5 text-[10px] font-semibold uppercase tracking-[0.12em] text-emerald-300/70">Corrections</p>
              <ul className="mb-3 space-y-1">
                {(fixed.fixes || []).map((fx, i) => (
                  <li key={i} className="text-[11px] text-white/70">
                    <span className="text-white/40">↳ {fx.fault} :</span> {fx.fix}
                  </li>
                ))}
              </ul>
              <p className="mb-1.5 text-[10px] font-semibold uppercase tracking-[0.12em] text-emerald-300/70">Code conforme</p>
            </>
          )}
          <pre className="max-h-56 overflow-auto rounded-lg bg-black/60 p-3 text-[10.5px] leading-relaxed text-white/70">
            <code>{done ? fixed.html : block.snippet}</code>
          </pre>
        </div>
      )}
    </div>
  );
}