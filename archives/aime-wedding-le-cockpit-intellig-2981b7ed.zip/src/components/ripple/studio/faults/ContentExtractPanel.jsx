import { useState } from "react";
import { FileDown, Loader2, AlertTriangle, Type, Image as ImageIcon, RefreshCw, Link2, Sparkles } from "lucide-react";
import { extractContent, generatePositionVisual } from "@/lib/gallery/eaaAudit";

// ─────────────────────────────────────────────────────────────────────────
// PANNEAU D'EXTRACTION DE CONTENU — la base réutilisable d'un site :
//   1. On aspire tous les TEXTES (titres, paragraphes, listes, liens, boutons)
//      et tous les VISUELS (images + fonds) de la page réelle.
//   2. On les recompose proprement sur le design system RIPPLE UI (dark, sobre,
//      typographie Aeonik/Inter, rythme éditorial) — classe, sans faute de goût.
//   3. Un visuel manquant ou cassé peut être régénéré à la volée.
// ─────────────────────────────────────────────────────────────────────────
export default function ContentExtractPanel({ url }) {
  const [state, setState] = useState({ status: "idle", data: null, error: null });

  const run = async () => {
    if (!url?.trim()) return;
    setState({ status: "loading", data: null, error: null });
    try {
      const data = await extractContent(url.trim());
      if (data?.error) setState({ status: "error", data: null, error: data.error });
      else setState({ status: "done", data, error: null });
    } catch {
      setState({ status: "error", data: null, error: "Extraction impossible." });
    }
  };

  const data = state.data;

  return (
    <div>
      <button
        onClick={run}
        disabled={!url?.trim() || state.status === "loading"}
        className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-white px-4 py-2.5 text-[13px] font-semibold text-black transition hover:bg-white/90 disabled:opacity-40"
      >
        {state.status === "loading" ? <Loader2 className="h-4 w-4 animate-spin" /> : <FileDown className="h-4 w-4" />}
        {state.status === "loading" ? "Extraction du contenu…" : "Extraire le contenu du site"}
      </button>

      {!url?.trim() && (
        <p className="mt-2 text-center text-[11px] text-white/40">Colle l'URL de ton site plus haut pour extraire sa base.</p>
      )}

      {state.status === "error" && (
        <div className="mt-3 flex items-center gap-2 rounded-xl bg-amber-500/10 px-4 py-3 text-[12px] text-amber-300">
          <AlertTriangle className="h-4 w-4 shrink-0" />
          {state.error} — certains sites bloquent l'analyse automatique.
        </div>
      )}

      {state.status === "done" && data && (
        <div className="mt-4 space-y-5">
          {/* Bilan chiffré */}
          <div className="grid grid-cols-3 gap-2">
            <Stat icon={Type} label="Textes" value={data.counts.headings + data.counts.paragraphs + data.counts.lists} />
            <Stat icon={Link2} label="Liens & boutons" value={data.counts.links + data.counts.buttons} />
            <Stat icon={ImageIcon} label="Visuels" value={data.counts.images} />
          </div>
          <p className="text-[11px] text-white/50">
            Base extraite du site. Recomposée sur le design system RIPPLE UI — sobre et sans faute de goût. Un visuel cassé peut être régénéré.
          </p>

          {/* TEXTES — rendus dans leur rôle typographique Ripple */}
          {data.texts.headings.length > 0 && (
            <Section title="Titres">
              <div className="space-y-2">
                {data.texts.headings.slice(0, 40).map((h, i) => (
                  <div key={i} className="flex items-baseline gap-2">
                    <span className="shrink-0 rounded bg-white/8 px-1.5 py-0.5 text-[9px] font-semibold text-white/40">H{h.level}</span>
                    <span
                      className="font-heading text-white"
                      style={{ fontSize: `${Math.max(13, 24 - (h.level - 1) * 2)}px`, fontWeight: h.level <= 2 ? 700 : 500 }}
                    >
                      {h.text}
                    </span>
                  </div>
                ))}
              </div>
            </Section>
          )}

          {data.texts.paragraphs.length > 0 && (
            <Section title="Paragraphes">
              <div className="space-y-2">
                {data.texts.paragraphs.slice(0, 30).map((p, i) => (
                  <p key={i} className="text-[12px] leading-relaxed text-white/70">{p}</p>
                ))}
              </div>
            </Section>
          )}

          {data.texts.lists.length > 0 && (
            <Section title="Listes">
              <ul className="space-y-1">
                {data.texts.lists.slice(0, 30).map((li, i) => (
                  <li key={i} className="flex items-start gap-2 text-[12px] text-white/70">
                    <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-accent" />
                    {li}
                  </li>
                ))}
              </ul>
            </Section>
          )}

          {(data.texts.links.length > 0 || data.texts.buttons.length > 0) && (
            <Section title="Liens & boutons">
              <div className="flex flex-wrap gap-2">
                {data.texts.buttons.slice(0, 20).map((b, i) => (
                  <span key={`b${i}`} className="rounded-full bg-white px-3 py-1.5 text-[11px] font-semibold text-black">{b}</span>
                ))}
                {data.texts.links.slice(0, 30).map((l, i) => (
                  <a key={`l${i}`} href={l.href} target="_blank" rel="noreferrer" className="rounded-full bg-white/8 px-3 py-1.5 text-[11px] text-white/70 hover:bg-white/15">
                    {l.text}
                  </a>
                ))}
              </div>
            </Section>
          )}

          {/* VISUELS — grille, avec régénération à la volée */}
          {data.images.length > 0 && (
            <Section title="Visuels">
              <div className="grid grid-cols-3 gap-2">
                {data.images.slice(0, 24).map((img, i) => (
                  <VisualTile key={i} image={img} />
                ))}
              </div>
            </Section>
          )}
        </div>
      )}
    </div>
  );
}

function VisualTile({ image }) {
  const [src, setSrc] = useState(image.src);
  const [busy, setBusy] = useState(false);
  const [broken, setBroken] = useState(false);

  const regen = async () => {
    setBusy(true);
    try {
      const newUrl = await generatePositionVisual({
        page: { title: "Visuel", hero_title: image.alt || "Illustration cohérente" },
        position: { label: "visuel", hint: "Recréer un visuel propre et accessible équivalent." },
        style: { name: "Ripple UI", palette: ["#111111", "#c9b88f", "#f8f4ec"] },
      });
      setSrc(newUrl);
      setBroken(false);
    } catch {
      /* silencieux : on garde l'ancien état */
    }
    setBusy(false);
  };

  return (
    <div className="group relative overflow-hidden rounded-lg bg-white/[0.04] ring-1 ring-white/10">
      <div className="aspect-square w-full">
        {broken ? (
          <div className="flex h-full w-full items-center justify-center text-white/30">
            <ImageIcon className="h-5 w-5" />
          </div>
        ) : (
          <img src={src} alt={image.alt} onError={() => setBroken(true)} className="h-full w-full object-cover" />
        )}
      </div>
      <button
        onClick={regen}
        disabled={busy}
        aria-label="Régénérer ce visuel"
        className="absolute right-1.5 top-1.5 inline-flex h-7 w-7 items-center justify-center rounded-full bg-black/60 text-white opacity-0 backdrop-blur transition group-hover:opacity-100 disabled:opacity-100"
      >
        {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RefreshCw className="h-3.5 w-3.5" />}
      </button>
      {image.alt && (
        <p className="truncate px-1.5 py-1 text-[9px] text-white/40" title={image.alt}>{image.alt}</p>
      )}
      {broken && (
        <span className="absolute bottom-1.5 left-1.5 inline-flex items-center gap-1 rounded-full bg-amber-500/20 px-1.5 py-0.5 text-[9px] text-amber-300">
          <Sparkles className="h-2.5 w-2.5" /> à régénérer
        </span>
      )}
    </div>
  );
}

function Section({ title, children }) {
  return (
    <div>
      <p className="mb-2 text-[10px] font-semibold uppercase tracking-[0.14em] text-white/40">{title}</p>
      {children}
    </div>
  );
}

function Stat({ icon: Icon, label, value }) {
  return (
    <div className="rounded-xl bg-white/[0.04] px-3 py-2.5 text-center">
      <Icon className="mx-auto mb-1 h-4 w-4 text-white/60" />
      <p className="text-[15px] font-bold text-white">{value}</p>
      <p className="text-[9px] uppercase tracking-[0.1em] text-white/40">{label}</p>
    </div>
  );
}