import { useEffect, useState } from "react";
import { X, LayoutGrid, Loader2, ExternalLink, AlertTriangle } from "lucide-react";
import { base44 } from "@/api/base44Client";

// Miniature d'aperçu d'une page réelle via service de capture par URL.
function shot(u) {
  return `https://image.thum.io/get/width/600/crop/800/${u}`;
}

// ─────────────────────────────────────────────────────────────────────────
// VUE D'ENSEMBLE « EXPOSÉ » (F3) — explore réellement l'URL, détache chaque
// page du site et les affiche côte à côte façon Mission Control, avec un
// aperçu visuel de chaque page.
// ─────────────────────────────────────────────────────────────────────────
export default function SiteExposeOverlay({ url, night, onClose }) {
  const [state, setState] = useState({ loading: true, error: null, pages: [], base: "" });

  useEffect(() => {
    let alive = true;
    (async () => {
      setState({ loading: true, error: null, pages: [], base: "" });
      try {
        const { data } = await base44.functions.invoke("exploreSite", { url });
        if (!alive) return;
        if (data?.error) setState({ loading: false, error: data.error, pages: [], base: "" });
        else setState({ loading: false, error: null, pages: data.pages || [], base: data.base || url });
      } catch (e) {
        if (alive) setState({ loading: false, error: "Exploration impossible.", pages: [], base: "" });
      }
    })();
    return () => { alive = false; };
  }, [url]);

  return (
    <div className={`fixed inset-0 z-50 flex flex-col ${night ? "bg-black" : "bg-neutral-950"} text-white`}>
      <div className="flex items-center justify-between border-b border-white/10 px-5 py-3">
        <p className="flex items-center gap-2 text-[12px] font-semibold uppercase tracking-[0.16em] text-white/85">
          <LayoutGrid className="h-4 w-4 text-accent" />
          Toutes les pages du site
          {!state.loading && !state.error && (
            <span className="rounded-full bg-white/10 px-2 py-0.5 text-[10px] font-medium text-white/60">
              {state.pages.length} page{state.pages.length > 1 ? "s" : ""}
            </span>
          )}
        </p>
        <button
          onClick={onClose}
          className="inline-flex items-center gap-1.5 rounded-full bg-white/10 px-3 py-1.5 text-[11px] text-white/80 hover:bg-white/20"
        >
          <X className="h-3.5 w-3.5" /> Fermer
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-5">
        {state.loading && (
          <div className="flex h-full flex-col items-center justify-center gap-3 text-white/60">
            <Loader2 className="h-6 w-6 animate-spin" />
            <p className="text-[13px]">Exploration de {url}…</p>
          </div>
        )}

        {!state.loading && state.error && (
          <div className="flex h-full flex-col items-center justify-center gap-2 text-center text-white/60">
            <AlertTriangle className="h-6 w-6 text-amber-400" />
            <p className="text-[13px]">{state.error}</p>
            <p className="max-w-sm text-[11px] text-white/40">
              Certains sites bloquent l'exploration automatique. Essaie une autre URL.
            </p>
          </div>
        )}

        {!state.loading && !state.error && (
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
            {state.pages.map((p) => (
              <a
                key={p.url}
                href={p.url}
                target="_blank"
                rel="noreferrer"
                className="group overflow-hidden rounded-xl border border-white/12 bg-white/[0.03] transition hover:border-accent/60"
              >
                <div className="relative aspect-[3/4] overflow-hidden bg-neutral-900">
                  <img
                    src={shot(p.url)}
                    alt={`Aperçu de ${p.title}`}
                    loading="lazy"
                    className="h-full w-full object-cover object-top transition group-hover:scale-[1.03]"
                  />
                  <span className="absolute right-2 top-2 inline-flex h-6 w-6 items-center justify-center rounded-full bg-black/60 text-white/70 opacity-0 backdrop-blur transition group-hover:opacity-100">
                    <ExternalLink className="h-3 w-3" />
                  </span>
                </div>
                <div className="px-3 py-2">
                  <p className="truncate text-[12px] font-medium text-white">{p.title}</p>
                  <p className="truncate text-[10px] text-white/40">{p.path}</p>
                </div>
              </a>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}