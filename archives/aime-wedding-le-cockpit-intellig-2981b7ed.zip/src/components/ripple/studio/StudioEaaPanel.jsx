import { EAA_SETTINGS } from "@/lib/gallery/eaaAccessibility";
import { Switch } from "@/components/ui/switch";
import { Lock } from "lucide-react";

// Panneau de réglages EAA compact du Studio — pour être en règle dès la génération.
// Reprend exactement les paramètres de conformité du builder (contraste, taille,
// interligne, cibles tactiles, focus clavier…), en version resserrée.
export default function StudioEaaPanel({ settings, onChange }) {
  const set = (key, value) => onChange({ ...settings, [key]: value });

  return (
    <div className="grid grid-cols-1 gap-x-5 gap-y-2.5 sm:grid-cols-2">
      {EAA_SETTINGS.map((p) => (
        <div key={p.key} className="rounded-lg bg-white/[0.04] px-3 py-2">
          <div className="flex items-center justify-between gap-2">
            <label className="flex items-center gap-1.5 text-[11px] font-medium text-white/80">
              {p.locked && <Lock className="h-3 w-3 text-accent" />}
              {p.label}
            </label>
            {p.type === "range" ? (
              <span className="rounded bg-white/10 px-1.5 py-0.5 text-[10px] font-mono text-white/60">
                {settings[p.key]}{p.unit}
              </span>
            ) : (
              <Switch
                checked={!!settings[p.key]}
                disabled={p.locked}
                onCheckedChange={(v) => set(p.key, v)}
              />
            )}
          </div>
          {p.type === "range" && (
            <input
              type="range"
              min={p.min}
              max={p.max}
              step={p.step}
              value={settings[p.key]}
              onChange={(e) => set(p.key, Number(e.target.value))}
              className="ripple-range mt-1.5 h-1.5 w-full cursor-pointer appearance-none rounded-full bg-white/15"
            />
          )}
        </div>
      ))}
    </div>
  );
}