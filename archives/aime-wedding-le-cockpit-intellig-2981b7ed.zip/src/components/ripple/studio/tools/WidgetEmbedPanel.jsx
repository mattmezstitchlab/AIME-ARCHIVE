import { useState } from "react";
import { Code2, Eye, AlertTriangle } from "lucide-react";

// ─────────────────────────────────────────────────────────────────────────
// WIDGET HTML / IFRAME / JS — champ de saisie pour coller un embed (iframe,
// widget, snippet HTML) et le prévisualiser dans un cadre isolé (sandbox).
// Un rappel accessibilité invite à donner un titre au cadre pour les lecteurs
// d'écran. Le code reste local, rendu dans une iframe srcDoc sandboxée.
// ─────────────────────────────────────────────────────────────────────────
export default function WidgetEmbedPanel() {
  const [code, setCode] = useState("");
  const [title, setTitle] = useState("");
  const [preview, setPreview] = useState("");

  const hasIframe = /<iframe/i.test(code);
  const missingTitle = hasIframe && !/<iframe[^>]*\btitle=/i.test(code);

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        <Code2 className="h-4 w-4 text-accent" />
        <p className="text-[12px] font-semibold text-white">Intégrer un widget (HTML / iframe / JS)</p>
      </div>

      <input
        type="text"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Titre accessible du widget (ex. Carte de localisation)"
        className="w-full rounded-lg bg-white/[0.06] px-3 py-2 text-[12px] text-white placeholder:text-white/40 focus:outline-none focus-visible:shadow-none"
      />

      <textarea
        value={code}
        onChange={(e) => setCode(e.target.value)}
        rows={5}
        placeholder={'Colle ton code ici — <iframe src="…">, un widget JS ou du HTML.'}
        className="w-full resize-y rounded-lg bg-white/[0.06] px-3 py-2 font-mono text-[11px] text-white placeholder:text-white/40 focus:outline-none focus-visible:shadow-none"
      />

      {missingTitle && (
        <p className="flex items-start gap-1.5 text-[11px] text-amber-300/90">
          <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0" />
          Ton iframe n'a pas d'attribut <code className="mx-1 font-mono">title</code> — obligatoire pour les lecteurs d'écran (WCAG 4.1.2).
        </p>
      )}

      <button
        type="button"
        onClick={() => setPreview(code)}
        disabled={!code.trim()}
        className="inline-flex items-center gap-2 rounded-full bg-white px-4 py-2 text-[12px] font-semibold text-black transition hover:bg-white/90 disabled:opacity-40"
      >
        <Eye className="h-4 w-4" /> Prévisualiser
      </button>

      {preview && (
        <div className="overflow-hidden rounded-xl bg-white/[0.04] p-2">
          <p className="mb-1.5 px-1 text-[10px] uppercase tracking-[0.12em] text-white/40">Aperçu isolé</p>
          <iframe
            title={title || "Aperçu du widget"}
            srcDoc={preview}
            sandbox="allow-scripts allow-same-origin allow-popups allow-forms"
            className="h-56 w-full rounded-lg bg-white"
          />
        </div>
      )}
    </div>
  );
}