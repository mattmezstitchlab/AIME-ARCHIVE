import { useState, useRef } from "react";
import { Pipette, Upload, Loader2, ArrowRight, Check, ImageOff } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { contrastRatio, wcagLevel, suggestAccessible } from "@/lib/ripple/colorAccessibility";

// ─────────────────────────────────────────────────────────────────────────
// PIPETTE COULEURS + PALETTE UNIVERSELLE
// Pioche les couleurs d'un site (via extractSiteColors) OU d'une image uploadée
// (pipette canvas), puis propose pour chaque couleur une variante accessible
// (WCAG AA contre blanc) qui remplace l'originale. Direction artistique + règle.
// ─────────────────────────────────────────────────────────────────────────
export default function ColorPipettePanel({ url }) {
  const [source, setSource] = useState("site"); // site | image
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [colors, setColors] = useState([]); // [{ hex, count }]
  const [imageSrc, setImageSrc] = useState(null);
  const [replacements, setReplacements] = useState({}); // { originalHex: newHex }
  const canvasRef = useRef(null);
  const fileRef = useRef(null);

  // ── Site : extrait les couleurs réelles du HTML/CSS ──────────────────────
  const scanSite = async () => {
    if (!url?.trim()) { setError("Colle d'abord une URL de site en haut."); return; }
    setError(""); setLoading(true); setColors([]);
    try {
      const { data } = await base44.functions.invoke("extractSiteColors", { url });
      if (data.error) setError(data.error);
      else setColors(data.colors || []);
    } catch {
      setError("Échec de la lecture des couleurs.");
    } finally {
      setLoading(false);
    }
  };

  // ── Image : dessine sur canvas, échantillonne une grille de couleurs ─────
  const onPickImage = (e) => {
    const f = e.target.files?.[0];
    e.target.value = "";
    if (!f) return;
    const reader = new FileReader();
    reader.onload = () => setImageSrc(reader.result);
    reader.readAsDataURL(f);
  };

  const samplePalette = () => {
    const canvas = canvasRef.current;
    const img = canvas?._img;
    if (!canvas || !img) return;
    const ctx = canvas.getContext("2d");
    const counts = {};
    const grid = 12;
    for (let y = 0; y < grid; y++) {
      for (let x = 0; x < grid; x++) {
        const px = Math.floor((x + 0.5) / grid * canvas.width);
        const py = Math.floor((y + 0.5) / grid * canvas.height);
        const d = ctx.getImageData(px, py, 1, 1).data;
        const hex = "#" + [d[0], d[1], d[2]].map((n) => n.toString(16).padStart(2, "0")).join("");
        counts[hex] = (counts[hex] || 0) + 1;
      }
    }
    const list = Object.entries(counts).map(([hex, count]) => ({ hex, count })).sort((a, b) => b.count - a.count).slice(0, 24);
    setColors(list);
  };

  const onImageLoad = (e) => {
    const img = e.target;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const w = 220, h = Math.round((img.naturalHeight / img.naturalWidth) * w) || 140;
    canvas.width = w; canvas.height = h;
    canvas.getContext("2d").drawImage(img, 0, 0, w, h);
    canvas._img = img;
    samplePalette();
  };

  const applySuggestion = (hex) => {
    setReplacements((r) => ({ ...r, [hex]: suggestAccessible(hex, "#ffffff", 4.5) }));
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        <Pipette className="h-4 w-4 text-accent" />
        <p className="text-[12px] font-semibold text-white">Pipette couleurs · palette universelle</p>
      </div>

      {/* Source */}
      <div className="flex gap-1.5">
        <SrcTab active={source === "site"} onClick={() => { setSource("site"); setColors([]); }}>Depuis le site</SrcTab>
        <SrcTab active={source === "image"} onClick={() => { setSource("image"); setColors([]); }}>Depuis une image</SrcTab>
      </div>

      {source === "site" ? (
        <button
          type="button"
          onClick={scanSite}
          disabled={loading}
          className="inline-flex items-center gap-2 rounded-full bg-white px-4 py-2 text-[12px] font-semibold text-black transition hover:bg-white/90 disabled:opacity-40"
        >
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Pipette className="h-4 w-4" />}
          Prélever les couleurs du site
        </button>
      ) : (
        <div className="space-y-2">
          <input ref={fileRef} type="file" accept="image/*" onChange={onPickImage} className="hidden" />
          <button
            type="button"
            onClick={() => fileRef.current?.click()}
            className="inline-flex items-center gap-2 rounded-full bg-white px-4 py-2 text-[12px] font-semibold text-black transition hover:bg-white/90"
          >
            <Upload className="h-4 w-4" /> Choisir une image
          </button>
          {imageSrc ? (
            <div className="overflow-hidden rounded-xl bg-white/[0.04] p-2">
              {/* Image visible + canvas caché pour l'échantillonnage. */}
              <img src={imageSrc} alt="Aperçu de l'image à échantillonner" onLoad={onImageLoad} className="max-h-32 w-full rounded-lg object-cover" />
              <canvas ref={canvasRef} className="hidden" />
            </div>
          ) : (
            <p className="flex items-center gap-1.5 text-[11px] text-white/40"><ImageOff className="h-3.5 w-3.5" /> Aucune image chargée.</p>
          )}
        </div>
      )}

      {error && <p className="text-[11px] text-amber-300/90">{error}</p>}

      {/* Palette prélevée : chaque couleur + sa proposition accessible. */}
      {colors.length > 0 && (
        <div className="space-y-1.5">
          <p className="text-[10px] font-medium uppercase tracking-[0.12em] text-white/40">
            {colors.length} couleurs prélevées · contraste testé sur blanc
          </p>
          {colors.map(({ hex }) => {
            const ratio = contrastRatio(hex, "#ffffff");
            const level = wcagLevel(ratio);
            const suggested = replacements[hex];
            const failing = level === "échec";
            return (
              <div key={hex} className="flex items-center gap-2 rounded-lg bg-white/[0.04] px-2 py-1.5">
                <span className="h-6 w-6 shrink-0 rounded-md ring-1 ring-white/15" style={{ background: hex }} />
                <span className="w-[68px] shrink-0 font-mono text-[11px] text-white/80">{hex}</span>
                <span className={`w-[52px] shrink-0 text-[10px] font-semibold ${failing ? "text-red-400" : "text-emerald-400"}`}>
                  {ratio.toFixed(1)} · {level}
                </span>
                {suggested ? (
                  <div className="ml-auto flex items-center gap-1.5">
                    <ArrowRight className="h-3.5 w-3.5 text-white/30" />
                    <span className="h-6 w-6 shrink-0 rounded-md ring-1 ring-white/15" style={{ background: suggested }} />
                    <span className="font-mono text-[11px] text-emerald-300">{suggested}</span>
                    <Check className="h-3.5 w-3.5 text-emerald-400" />
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => applySuggestion(hex)}
                    className="ml-auto rounded-full bg-white/10 px-2.5 py-1 text-[10px] font-semibold text-white transition hover:bg-white/20"
                  >
                    {failing ? "Corriger" : "Optimiser"}
                  </button>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function SrcTab({ active, onClick, children }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`rounded-full px-3 py-1 text-[11px] font-semibold transition ${
        active ? "bg-accent text-accent-foreground" : "bg-white/10 text-white/60 hover:bg-white/20"
      }`}
    >
      {children}
    </button>
  );
}