import { useState } from "react";
import { Type } from "lucide-react";

// ─────────────────────────────────────────────────────────────────────────
// MODULE TEXTE ACCESSIBLE — règle la taille de police, la hauteur de ligne,
// l'espacement des lettres et le contraste, avec un aperçu vivant du rendu.
// Chaque réglage rappelle la borne WCAG associée. État local, sans effet global.
// ─────────────────────────────────────────────────────────────────────────
const CONTROLS = [
  { key: "size", label: "Taille du texte", min: 12, max: 28, step: 1, unit: "px", def: 16, wcag: "1.4.4 · redimensionnable 200 %" },
  { key: "line", label: "Interligne", min: 1.2, max: 2.2, step: 0.1, unit: "", def: 1.5, wcag: "1.4.12 · min. 1,5" },
  { key: "spacing", label: "Espacement lettres", min: 0, max: 0.3, step: 0.01, unit: "em", def: 0.01, wcag: "1.4.12 · min. 0,12em conseillé" },
  { key: "contrast", label: "Contraste", min: 0.4, max: 1, step: 0.05, unit: "", def: 0.85, wcag: "1.4.3 · ratio ≥ 4.5:1" },
];

export default function TextAccessibilityPanel() {
  const [v, setV] = useState(Object.fromEntries(CONTROLS.map((c) => [c.key, c.def])));
  const set = (k, val) => setV((s) => ({ ...s, [k]: val }));

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Type className="h-4 w-4 text-accent" />
        <p className="text-[12px] font-semibold text-white">Module texte accessible</p>
      </div>

      {/* Aperçu vivant */}
      <div className="rounded-xl bg-white p-4">
        <p
          className="text-black"
          style={{
            fontSize: `${v.size}px`,
            lineHeight: v.line,
            letterSpacing: `${v.spacing}em`,
            color: `rgba(17,17,17,${v.contrast})`,
          }}
        >
          Un site lisible par tous : le texte respire, se laisse agrandir et garde
          un contraste net sur le fond. Chaque personne ajuste selon son confort.
        </p>
      </div>

      {/* Curseurs */}
      <div className="space-y-3">
        {CONTROLS.map((c) => (
          <label key={c.key} className="block">
            <span className="mb-1 flex items-center justify-between">
              <span className="text-[11px] font-medium text-white/80">{c.label}</span>
              <span className="font-mono text-[11px] text-accent">{v[c.key]}{c.unit}</span>
            </span>
            <input
              type="range"
              min={c.min}
              max={c.max}
              step={c.step}
              value={v[c.key]}
              onChange={(e) => set(c.key, Number(e.target.value))}
              className="ripple-range h-1 w-full cursor-pointer appearance-none rounded-full bg-white/15"
            />
            <span className="mt-1 block text-[10px] text-white/35">WCAG {c.wcag}</span>
          </label>
        ))}
      </div>
    </div>
  );
}