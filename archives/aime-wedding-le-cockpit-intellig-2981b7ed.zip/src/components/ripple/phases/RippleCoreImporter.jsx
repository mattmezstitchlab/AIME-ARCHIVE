import { useState, useRef } from "react";
import { FolderPlus, X, Upload, Check, Waves, Archive, ArrowRight, FileArchive, Image as ImageIcon, FileText, Music, Film, File as FileIcon } from "lucide-react";
import { classifyForWedding, WEDDING_PHASES } from "@/lib/ripple/weddingRouter";

// Reconnaissance légère du fichier déposé dans le point zéro → type + libellé.
function recognize(file) {
  const ext = (file.name || "").split(".").pop()?.toLowerCase() || "";
  const type = file.type || "";
  if (ext === "zip" || ext === "rar" || ext === "7z" || type.includes("zip")) return { label: "Archive / ZIP", Icon: FileArchive };
  if (type.startsWith("image/")) return { label: "Image", Icon: ImageIcon };
  if (type.startsWith("audio/")) return { label: "Audio", Icon: Music };
  if (type.startsWith("video/")) return { label: "Vidéo", Icon: Film };
  if (ext === "pdf" || ext === "doc" || ext === "docx") return { label: "Document", Icon: FileText };
  return { label: "Fichier", Icon: FileIcon };
}

const PHASE_TONE = {
  avant: "border-sky-400/50 bg-sky-400/10 text-sky-300",
  jourj: "border-accent/60 bg-accent/10 text-accent",
  apres: "border-emerald-500/40 bg-emerald-500/10 text-emerald-400",
  transit: "border-white/20 bg-white/[0.06] text-background/70",
};

// ─── Le POINT ZÉRO — noyau de tri wedding ─────────────────────────────────────
// Bouton rond doré « dossier + » au centre de la mosaïque. Ce n'est pas un simple
// import : c'est le CENTRE DE CONTRÔLE, DE TRI ET DE TRANSITION du mariage.
// « Comme en broderie, on commence toujours par le centre. »
// On dépose une info (photo, texte, dossier, zip…), le noyau la CLASSE vers la
// bonne phase wedding (AVANT / JOUR J / APRÈS), puis DEUX choix :
//   • Trier & propager  → l'onde part et allume les cases ciblées du cockpit
//   • Déposer sans propager → l'info reste EN TRANSIT, rien ne bouge encore
// `onPropagate(file, reco, dest)` et `onStore(file, reco, dest)` préviennent le parent.
export default function RippleCoreImporter({ onPropagate, onStore, propagating = false }) {
  const [open, setOpen] = useState(false);
  const [dropped, setDropped] = useState(null); // { file, reco, dest }
  const [dragOver, setDragOver] = useState(false);
  const fileRef = useRef(null);

  const handleFile = (file) => {
    if (!file) return;
    setDropped({ file, reco: recognize(file), dest: classifyForWedding(file) });
  };

  const reclass = (phaseKey) => {
    setDropped((d) => (d ? { ...d, dest: { ...d.dest, phase: phaseKey, phaseLabel: WEDDING_PHASES[phaseKey].label, phaseHint: WEDDING_PHASES[phaseKey].hint } } : d));
  };

  const close = () => { setOpen(false); setDropped(null); };

  const propagate = () => { if (!dropped) return; onPropagate?.(dropped.file, dropped.reco, dropped.dest); close(); };
  const store = () => { if (!dropped) return; onStore?.(dropped.file, dropped.reco, dropped.dest); close(); };

  return (
    <>
      {/* Noyau central — bouton rond doré, cœur de la convergence Ripple */}
      <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
        <button
          type="button"
          onClick={() => setOpen(true)}
          title="Point zéro — centre de tri & de transition"
          className="pointer-events-auto group flex h-20 w-20 flex-col items-center justify-center rounded-full border border-accent/50 bg-foreground/95 shadow-2xl backdrop-blur transition-transform hover:scale-105"
        >
          <span className={`relative flex h-6 w-6 items-center justify-center ${propagating ? "ripple-impact-pulse" : ""}`}>
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-accent/30" />
            <FolderPlus className="relative h-5 w-5 text-accent" strokeWidth={2} />
          </span>
          <span className="mt-1 font-heading text-[8px] font-semibold uppercase tracking-[0.16em] text-accent">
            Point zéro
          </span>
        </button>
      </div>

      {/* Fenêtre de tri — classe le dépôt vers une phase wedding, puis 2 choix */}
      {open && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center bg-foreground/50 p-4 backdrop-blur-sm">
          <div className="w-full max-w-lg overflow-hidden rounded-2xl border border-border bg-background shadow-2xl">
            <div className="flex items-center justify-between border-b border-border bg-paper px-4 py-3">
              <div className="flex items-center gap-2">
                <FolderPlus className="h-4 w-4 text-accent" strokeWidth={2} />
                <p className="font-heading text-sm font-semibold text-foreground">Point zéro — tri & transition</p>
              </div>
              <button onClick={close} aria-label="Fermer" className="rounded-md p-1 text-muted-foreground hover:bg-background hover:text-foreground">
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="p-6">
              <input ref={fileRef} type="file" className="hidden" onChange={(e) => handleFile(e.target.files?.[0])} />

              {!dropped ? (
                <button
                  type="button"
                  onClick={() => fileRef.current?.click()}
                  onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
                  onDragLeave={() => setDragOver(false)}
                  onDrop={(e) => { e.preventDefault(); setDragOver(false); handleFile(e.dataTransfer.files?.[0]); }}
                  className={`flex w-full flex-col items-center justify-center gap-3 rounded-xl border-2 border-dashed px-6 py-12 text-center transition-colors ${
                    dragOver ? "border-accent bg-accent/5" : "border-border hover:border-foreground/40 hover:bg-paper"
                  }`}
                >
                  <Upload className="h-8 w-8 text-muted-foreground" />
                  <p className="font-heading text-sm font-semibold text-foreground">Déposer une info à trier</p>
                  <p className="text-xs text-muted-foreground">Photo, texte, dossier, .zip… le noyau la classe vers la bonne étape du mariage.</p>
                </button>
              ) : (
                <div>
                  {/* Fichier reconnu */}
                  <div className="flex items-center gap-3 rounded-lg border border-border bg-paper p-4">
                    <dropped.reco.Icon className="h-8 w-8 shrink-0 text-foreground" />
                    <div className="min-w-0">
                      <p className="truncate font-heading text-sm font-semibold text-foreground">{dropped.file.name}</p>
                      <p className="text-xs text-muted-foreground">{dropped.reco.label} · {(dropped.file.size / 1024).toFixed(0)} Ko</p>
                    </div>
                  </div>

                  {/* Classement wedding proposé */}
                  <p className="mt-5 font-heading text-[11px] font-semibold uppercase tracking-[0.18em] text-muted-foreground">Le noyau propose de classer dans</p>
                  <div className="mt-2 flex items-center gap-2 rounded-lg border border-border bg-background p-3">
                    <span className={`rounded-full border px-2.5 py-1 text-[11px] font-bold uppercase tracking-[0.12em] ${PHASE_TONE[dropped.dest.phase] || PHASE_TONE.transit}`}>
                      {dropped.dest.phaseLabel}
                    </span>
                    <div className="min-w-0">
                      <p className="truncate text-sm font-medium text-foreground">{dropped.dest.label}</p>
                      <p className="truncate text-xs text-muted-foreground">{dropped.dest.phaseHint}</p>
                    </div>
                  </div>

                  {/* Reclassement manuel — le centre de contrôle */}
                  <div className="mt-3 flex flex-wrap gap-1.5">
                    <span className="text-[11px] text-muted-foreground">Reclasser :</span>
                    {dropped.dest.suggestions.map((p) => (
                      <button
                        key={p.key}
                        type="button"
                        onClick={() => reclass(p.key)}
                        className={`rounded-full border px-2.5 py-0.5 text-[11px] font-semibold uppercase tracking-[0.1em] transition-colors ${
                          dropped.dest.phase === p.key ? "border-foreground bg-foreground text-background" : "border-border text-muted-foreground hover:border-foreground/40 hover:text-foreground"
                        }`}
                      >
                        {p.label}
                      </button>
                    ))}
                  </div>

                  {/* Deux voies : propager l'onde, ou déposer sans propager */}
                  <div className="mt-6 grid gap-2 sm:grid-cols-2">
                    <button
                      type="button"
                      onClick={store}
                      className="flex flex-col items-start gap-1 rounded-xl border border-border bg-background p-3.5 text-left hover:bg-paper"
                    >
                      <span className="flex items-center gap-1.5 font-heading text-sm font-semibold text-foreground"><Archive className="h-4 w-4 text-muted-foreground" /> Déposer sans propager</span>
                      <span className="text-xs text-muted-foreground">Garder en transit dans le noyau — rien ne bouge encore.</span>
                    </button>
                    <button
                      type="button"
                      onClick={propagate}
                      className="flex flex-col items-start gap-1 rounded-xl border border-foreground bg-foreground p-3.5 text-left text-background hover:bg-foreground/90"
                    >
                      <span className="flex items-center gap-1.5 font-heading text-sm font-semibold"><Waves className="h-4 w-4 text-accent" /> Trier & propager</span>
                      <span className="text-xs text-background/70">Lancer l'onde vers {dropped.dest.phaseLabel} — les cases liées s'allument.</span>
                    </button>
                  </div>

                  <button type="button" onClick={() => setDropped(null)} className="mt-4 inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-[0.16em] text-muted-foreground hover:text-foreground">
                    <ArrowRight className="h-3.5 w-3.5 rotate-180" /> Changer de fichier
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}