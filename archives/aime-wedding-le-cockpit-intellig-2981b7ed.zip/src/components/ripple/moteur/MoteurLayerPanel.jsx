import { useState } from "react";
import { Eye, EyeOff, LayoutGrid, FolderOpen, ChevronRight } from "lucide-react";
import { buildDesignTree, BUREAU_TREE } from "./moteurTreeData";

// ── LE PANNEAU du moteur ─────────────────────────────────────────────────────
// Étroit (largeur du texte « Design System »), en arbre vertical. Chaque ligne
// est un bouton au design des boutons de la capsule. Deux natures :
//   • Couches du moteur (Projets, Routes…) — bouton = toggle du calque.
//   • Design System & Bureau — bouton = déploie son contenu en arbre en dessous.

function CapsuleButton({ icon: Icon, color, label, sub, active, trailing, onClick }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`flex w-full items-center gap-2.5 rounded-full border px-3 py-2 text-left transition-colors ${
        active
          ? "border-foreground/15 bg-foreground text-background"
          : "border-border bg-background/60 text-muted-foreground hover:text-foreground"
      }`}
    >
      <span
        className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full"
        style={color ? { backgroundColor: `${color}22` } : undefined}
      >
        <Icon className="h-3.5 w-3.5" style={color ? { color } : undefined} strokeWidth={1.75} />
      </span>
      <span className="flex-1 min-w-0">
        <span className={`block truncate font-heading text-[11px] font-semibold uppercase tracking-[0.1em] ${active ? "text-background" : "text-foreground"}`}>
          {label}
        </span>
        {sub && <span className={`block text-[10px] ${active ? "text-background/70" : "text-muted-foreground"}`}>{sub}</span>}
      </span>
      {trailing}
    </button>
  );
}

export default function MoteurLayerPanel({ layers, active, onToggle }) {
  const [open, setOpen] = useState(null); // "design" | "bureau" | null
  const designTree = buildDesignTree();

  const toggleOpen = (key) => setOpen((cur) => (cur === key ? null : key));

  return (
    <div className="pointer-events-auto absolute left-5 top-5 z-30 w-52 rounded-3xl border border-border bg-background/90 p-3 shadow-xl backdrop-blur">
      <p className="px-2 font-heading text-[10px] font-semibold uppercase tracking-[0.2em] text-accent">Le moteur</p>

      {/* Couches — chaque bouton est un toggle de calque */}
      <div className="mt-2.5 space-y-1.5">
        {layers.map((l) => (
          <CapsuleButton
            key={l.key}
            icon={l.icon}
            color={l.color}
            label={l.label}
            sub={`${l.count} éléments`}
            active={active[l.key]}
            trailing={
              active[l.key]
                ? <Eye className="h-3.5 w-3.5 text-background/70" />
                : <EyeOff className="h-3.5 w-3.5 text-muted-foreground" />
            }
            onClick={() => onToggle(l.key)}
          />
        ))}
      </div>

      {/* Source de vérité — déployables */}
      <div className="my-2.5 h-px bg-border" />

      <div className="space-y-1.5">
        {/* DESIGN SYSTEM */}
        <CapsuleButton
          icon={LayoutGrid}
          label="Design System"
          active={open === "design"}
          trailing={<ChevronRight className={`h-3.5 w-3.5 transition-transform ${open === "design" ? "rotate-90" : ""} ${open === "design" ? "text-background/70" : "text-muted-foreground"}`} />}
          onClick={() => toggleOpen("design")}
        />
        {open === "design" && (
          <div className="ripple-wave max-h-72 overflow-y-auto scrollbar-hide rounded-2xl border border-border bg-background/60 p-2">
            {designTree.map((cat) => (
              <div key={cat.key} className="mb-2 last:mb-0">
                <p className="px-1 pb-1 text-[9px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
                  {cat.label} · {cat.count}
                </p>
                <div className="space-y-0.5">
                  {cat.items.map((it) => (
                    <div key={it.id} className="flex items-center gap-2 rounded-full px-2 py-1 text-[11px] text-foreground hover:bg-foreground/[0.04]">
                      {it.kind === "color" ? (
                        <span className="h-3 w-3 shrink-0 rounded-full border border-border" style={{ backgroundColor: it.hex }} />
                      ) : (
                        <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-accent" />
                      )}
                      <span className="flex-1 truncate">{it.label}</span>
                      <span className="shrink-0 text-[9px] text-muted-foreground">{it.sample}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* BUREAU */}
        <CapsuleButton
          icon={FolderOpen}
          label="Dossier"
          active={open === "bureau"}
          trailing={<ChevronRight className={`h-3.5 w-3.5 transition-transform ${open === "bureau" ? "rotate-90" : ""} ${open === "bureau" ? "text-background/70" : "text-muted-foreground"}`} />}
          onClick={() => toggleOpen("bureau")}
        />
        {open === "bureau" && (
          <div className="ripple-wave max-h-72 overflow-y-auto scrollbar-hide rounded-2xl border border-border bg-background/60 p-2">
            {BUREAU_TREE.map((folder) => (
              <div key={folder.key} className="mb-2 last:mb-0">
                <p className="px-1 pb-1 text-[9px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">{folder.label}</p>
                <div className="space-y-0.5">
                  {folder.items.map((it) => (
                    <div key={it.id} className="flex items-center gap-2 rounded-full px-2 py-1 text-[11px] text-foreground hover:bg-foreground/[0.04]">
                      <FolderOpen className="h-3 w-3 shrink-0 text-accent" strokeWidth={1.75} />
                      <span className="flex-1 truncate">{it.label}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}