import { DESIGN_ITEMS, DESIGN_CATEGORIES, itemKind } from "@/lib/ripple/designSystemInventory";

// ── Contenu déployable des entrées « Design System » et « Bureau » du panneau ──
// La source de vérité vit désormais DANS le moteur : ces arbres remplacent les
// anciens écrans séparés (grille Design System + Bureau radial).

// Design System → arbre par catégorie, avec un aperçu court par élément.
export function buildDesignTree() {
  return DESIGN_CATEGORIES.map((cat) => {
    const items = DESIGN_ITEMS.filter((d) => d.category === cat);
    return {
      key: cat,
      label: cat,
      count: items.length,
      items: items.map((it) => ({
        id: it.id,
        label: it.label,
        kind: itemKind(it),
        hex: it.hex,
        sample: it.hex || it.size || it.value || it.family || it.picto || it.desc || "",
      })),
    };
  });
}

// Bureau → dossiers rangés (les strates du bureau, en arbre).
export const BUREAU_TREE = [
  {
    key: "avant",
    label: "AVANT",
    items: [
      { id: "b-doc", label: "Documents" },
      { id: "b-budget", label: "Budget & devis" },
      { id: "b-moodboard", label: "Moodboard & palette" },
      { id: "b-invites", label: "Invités & RSVP" },
    ],
  },
  {
    key: "jourj",
    label: "JOUR J",
    items: [
      { id: "b-prog", label: "Programme" },
      { id: "b-table", label: "Plan de table" },
      { id: "b-playlist", label: "Playlist" },
      { id: "b-contacts", label: "Contacts utiles" },
    ],
  },
  {
    key: "apres",
    label: "APRÈS",
    items: [
      { id: "b-album", label: "Album photos" },
      { id: "b-livreor", label: "Livre d'or" },
      { id: "b-merci", label: "Remerciements" },
      { id: "b-factures", label: "Factures & solde" },
    ],
  },
];