import TutoEtape from "./TutoEtape";

// UNE GRANDE CATÉGORIE du mode d'emploi — son intro et ses étapes codées.
export default function TutoCategorie({ cat }) {
  return (
    <section id={cat.id} className="scroll-mt-28" aria-label={`Mode d'emploi — ${cat.label}`}>
      <div className="mb-4 flex items-baseline gap-3">
        <span className="font-mono text-[28px] font-bold" style={{ color: cat.accent }}>{cat.lettre}</span>
        <div>
          <h2 className="font-heading text-2xl font-semibold tracking-tight text-white">{cat.label}</h2>
          <p className="mt-1 max-w-xl text-[13px] leading-5 text-white/50">{cat.intro}</p>
        </div>
      </div>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {cat.etapes.map((e, i) => (
          <TutoEtape key={e.titre} code={`${cat.lettre}${i + 1}`} etape={e} accent={cat.accent} />
        ))}
      </div>
    </section>
  );
}