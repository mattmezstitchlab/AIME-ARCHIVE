// LES MINI-ÉCRANS du mode d'emploi — l'aperçu en un clin d'œil de la fenêtre
// concernée : petits wireframes dessinés, fidèles à la vraie interface.

const Dot = ({ c = "#c9a96e", s = 6 }) => (
  <span className="rounded-full" style={{ width: s, height: s, background: c, display: "inline-block" }} />
);

const Bar = ({ w = "60%", h = 4, c = "rgba(255,255,255,0.25)" }) => (
  <span className="block rounded-full" style={{ width: w, height: h, background: c }} />
);

function Radial({ center = "Point Zéro" }) {
  return (
    <div className="relative h-full w-full">
      <div className="absolute left-1/2 top-1/2 h-[70%] w-[70%] -translate-x-1/2 -translate-y-1/2 rounded-full border border-white/15" />
      {[0, 60, 120, 180, 240, 300].map((a) => (
        <span key={a} className="absolute h-1.5 w-1.5 rounded-full bg-[#c9a96e]"
          style={{ left: `${50 + 35 * Math.cos((a * Math.PI) / 180)}%`, top: `${50 + 35 * Math.sin((a * Math.PI) / 180)}%` }} />
      ))}
      <span className="absolute left-1/2 top-1/2 flex h-9 w-9 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-[#f2efe9] text-center font-mono text-[4.5px] font-bold uppercase tracking-wider text-[#a8894f]">
        {center}
      </span>
    </div>
  );
}

function Clavier({ zones = false }) {
  return (
    <div className="flex h-full flex-col justify-end gap-1 p-2">
      {zones && (
        <div className="flex gap-1">{["1", "2", "3", "4", "5"].map((n) => (
          <span key={n} className={`rounded px-1.5 py-0.5 font-mono text-[6px] ${n === "2" ? "bg-[#c9a96e]/30 text-white" : "bg-white/10 text-white/50"}`}>{n}</span>
        ))}</div>
      )}
      <div className="grid grid-cols-6 gap-1">
        {Array.from({ length: 12 }).map((_, i) => (
          <span key={i} className="h-4 rounded border border-white/15 bg-white/5" />
        ))}
      </div>
    </div>
  );
}

function Cartes({ n = 6 }) {
  return (
    <div className="grid h-full grid-cols-3 gap-1.5 p-2">
      {Array.from({ length: n }).map((_, i) => (
        <div key={i} className="flex flex-col justify-end gap-1 rounded border border-white/12 bg-gradient-to-b from-white/10 to-transparent p-1">
          <Bar w="70%" h={3} />
          <Bar w="45%" h={2} c="rgba(255,255,255,0.15)" />
        </div>
      ))}
    </div>
  );
}

function Timeline() {
  return (
    <div className="flex h-full flex-col justify-center gap-2 p-3">
      <div className="flex gap-1">{["Années", "Mois", "Jours"].map((z, i) => (
        <span key={z} className={`rounded-full px-1.5 py-0.5 font-mono text-[5px] uppercase ${i === 0 ? "bg-[#c9a96e]/30 text-white" : "bg-white/10 text-white/40"}`}>{z}</span>
      ))}</div>
      <div className="relative h-px w-full bg-white/20">
        {[10, 35, 55, 80].map((x) => (
          <span key={x} className="absolute -top-[3px] h-[7px] w-[7px] rounded-full bg-[#38bdf8]" style={{ left: `${x}%` }} />
        ))}
      </div>
      <div className="flex gap-2">{[10, 35, 55].map((x) => <Bar key={x} w="20%" h={3} />)}</div>
    </div>
  );
}

const ECRANS = {
  radial: <Radial />,
  pointzero: (
    <div className="flex h-full items-center gap-2 p-2">
      <div className="h-full w-1/2"><Radial center="P.0" /></div>
      <div className="flex w-1/2 flex-col gap-1.5"><Bar w="90%" /><Bar w="70%" /><Bar w="80%" /><span className="mt-1 rounded bg-[#c9a96e]/30 px-1.5 py-0.5 font-mono text-[6px] text-white">Propager →</span></div>
    </div>
  ),
  apps: (
    <div className="flex h-full flex-col gap-2 p-2">
      <div className="flex gap-1.5">{["EAA", "ABS", "CAN", "BIB", "+"].map((a) => (
        <span key={a} className="flex h-6 w-8 items-center justify-center rounded border border-white/15 bg-white/5 font-mono text-[5px] text-white/60">{a}</span>
      ))}</div>
      <div className="flex-1 rounded border border-white/10 bg-white/[0.03]" />
    </div>
  ),
  ripple: (
    <div className="flex h-full flex-col justify-center gap-2 p-3">
      <div className="flex items-center gap-1.5 rounded-full border border-[#c9a96e]/50 px-2 py-1"><Dot s={4} /><Bar w="70%" h={3} /></div>
      <div className="flex gap-1">{["Simple", "Détaillé", "Complet"].map((l) => <span key={l} className="rounded bg-white/10 px-1.5 py-0.5 font-mono text-[5px] text-white/50">{l}</span>)}</div>
    </div>
  ),
  dossiers: (
    <div className="flex h-full gap-2 p-2">
      <span className="flex h-full w-4 items-center justify-center rounded bg-black/70 font-mono text-[5px] uppercase text-[#c9a96e]" style={{ writingMode: "vertical-rl" }}>Dossiers</span>
      <div className="flex flex-1 flex-col gap-1.5 pt-1"><Bar w="60%" /><Bar w="75%" c="rgba(255,255,255,0.15)" /><Bar w="50%" c="rgba(255,255,255,0.15)" /><Bar w="65%" /></div>
    </div>
  ),
  arbre: (
    <div className="flex h-full flex-col justify-center gap-1.5 p-3">
      <div className="flex items-center gap-1.5"><Dot /><Bar w="50%" /></div>
      <div className="ml-3 flex items-center gap-1.5"><Dot c="rgba(255,255,255,0.4)" s={4} /><Bar w="45%" c="rgba(255,255,255,0.15)" /></div>
      <div className="ml-6 flex items-center gap-1.5"><Dot c="#38bdf8" s={4} /><Bar w="40%" c="rgba(255,255,255,0.15)" /></div>
      <div className="ml-3 flex items-center gap-1.5"><Dot c="rgba(255,255,255,0.4)" s={4} /><Bar w="55%" c="rgba(255,255,255,0.15)" /></div>
    </div>
  ),
  biblio: <Cartes n={6} />,
  clavier: <Clavier />,
  zones: <Clavier zones />,
  systeme: (
    <div className="flex h-full items-end p-2">
      <div className="grid w-full grid-cols-7 gap-1">
        {["esc", "F1", "F2", "F4", "F6", "F7", "F11"].map((f) => (
          <span key={f} className="flex h-5 items-center justify-center rounded border border-white/15 bg-white/5 font-mono text-[5px] text-white/60">{f}</span>
        ))}
      </div>
    </div>
  ),
  mondes: (
    <div className="flex h-full flex-col justify-end gap-1 p-2">
      <div className="flex gap-1">{["Rôles", "Couleurs", "Builder"].map((m, i) => (
        <span key={m} className={`rounded px-1.5 py-0.5 font-mono text-[5px] ${i === 1 ? "bg-[#c9a96e]/30 text-white" : "bg-white/10 text-white/50"}`}>{m}</span>
      ))}</div>
      <div className="grid grid-cols-6 gap-1">
        {["#8B0000", "#C9A96E", "#3E5654", "#36465A", "#6E4A50", "#565046"].map((c) => (
          <span key={c} className="h-4 rounded" style={{ background: c }} />
        ))}
      </div>
    </div>
  ),
  ecran: (
    <div className="flex h-full flex-col gap-1.5 p-2">
      <div className="flex-1 rounded border border-[#c9a96e]/40 bg-white/[0.04] p-1.5"><Bar w="40%" /><div className="mt-1.5 grid grid-cols-4 gap-1">{Array.from({ length: 4 }).map((_, i) => <span key={i} className="h-3 rounded bg-white/10" />)}</div></div>
      <div className="grid grid-cols-8 gap-0.5">{Array.from({ length: 8 }).map((_, i) => <span key={i} className="h-2 rounded-sm bg-white/10" />)}</div>
    </div>
  ),
  registre: <Cartes n={9} />,
  personne: (
    <div className="relative h-full w-full overflow-hidden rounded">
      <div className="absolute inset-0 bg-gradient-to-b from-white/20 to-transparent" />
      <div className="absolute left-2 top-2 flex gap-1"><span className="rounded bg-black/60 px-1 py-0.5 font-mono text-[5px] text-white/70">← Retour</span><span className="rounded bg-black/60 px-1 py-0.5 font-mono text-[5px] text-white/70">01 · 02</span></div>
      <div className="absolute bottom-2 left-2 right-2"><Bar w="55%" h={6} c="rgba(255,255,255,0.8)" /><span className="mt-1 block"><Bar w="35%" h={3} /></span></div>
    </div>
  ),
  timeline: <Timeline />,
  cartes: <Cartes n={6} />,
  jourj: (
    <div className="flex h-full items-center gap-1 p-2">
      {["15:00", "17:00", "20:30", "22:30"].map((h) => (
        <div key={h} className="flex flex-1 flex-col gap-1 rounded border border-white/12 bg-white/[0.04] p-1">
          <span className="font-mono text-[5px] text-[#c9a96e]">{h}</span><Bar w="80%" h={2} c="rgba(255,255,255,0.2)" />
        </div>
      ))}
    </div>
  ),
  convert: (
    <div className="flex h-full items-center justify-center gap-2 p-2">
      <span className="rounded border border-white/15 px-2 py-1 font-mono text-[6px] text-white/60">Mariage</span>
      <span className="text-[#c9a96e]">→</span>
      <span className="rounded bg-[#c9a96e]/25 px-2 py-1 font-mono text-[6px] text-white">Projet Ripple</span>
    </div>
  ),
  onboarding: (
    <div className="flex h-full flex-col justify-center gap-1.5 p-3">
      <Bar w="45%" h={5} c="rgba(255,255,255,0.6)" />
      <div className="flex items-center gap-1.5"><Dot c="#34d399" s={5} /><Bar w="55%" c="rgba(255,255,255,0.2)" /></div>
      <div className="flex items-center gap-1.5"><Dot s={5} /><Bar w="45%" c="rgba(255,255,255,0.2)" /></div>
      <span className="mt-1 self-end rounded-full bg-white px-2 py-0.5 font-mono text-[5px] text-black">Continuer →</span>
    </div>
  ),
  startup: <Cartes n={6} />,
  sante: (
    <div className="flex h-full flex-col justify-center gap-1.5 p-3">
      {[["/", "#34d399"], ["/bureau", "#34d399"], ["/registre", "#34d399"], ["/decouvrir", "#c9a96e"]].map(([r, c]) => (
        <div key={r} className="flex items-center gap-1.5"><Dot c={c} s={4} /><span className="font-mono text-[6px] text-white/50">{r}</span></div>
      ))}
    </div>
  ),
};

export default function TutoMiniEcran({ type }) {
  return (
    <div className="aspect-video w-full overflow-hidden rounded-lg border border-white/12 bg-[#101012]" aria-hidden="true">
      <div className="flex h-3.5 items-center gap-1 border-b border-white/10 px-1.5">
        <span className="h-1 w-1 rounded-full bg-white/25" /><span className="h-1 w-1 rounded-full bg-white/25" /><span className="h-1 w-1 rounded-full bg-white/25" />
      </div>
      <div className="h-[calc(100%-0.875rem)]">{ECRANS[type] || <Cartes n={6} />}</div>
    </div>
  );
}