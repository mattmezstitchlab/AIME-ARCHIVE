import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import TutoMiniEcran from "./TutoMiniEcran";

// UNE ÉTAPE du mode d'emploi — son CODE (B1, C2…), son mini-écran,
// son explication, ses combinaisons clavier et son bouton « aller-y ».
export default function TutoEtape({ code, etape, accent }) {
  return (
    <motion.article
      initial={{ opacity: 0, y: 18 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
      className="flex flex-col gap-3 rounded-2xl border border-white/10 bg-white/[0.02] p-4 transition hover:border-white/25"
    >
      <TutoMiniEcran type={etape.ecran} />
      <div className="flex items-start gap-3">
        <span
          className="mt-0.5 shrink-0 rounded-md px-1.5 py-0.5 font-mono text-[10px] font-bold"
          style={{ background: `${accent}22`, color: accent }}
        >
          {code}
        </span>
        <div className="min-w-0">
          <h3 className="text-[14px] font-semibold text-white">
            {etape.titre}
            {(etape.combos || []).map((c) => (
              <kbd key={c} className="ml-1.5 rounded border border-white/20 px-1 py-0.5 align-middle font-mono text-[9px] font-normal text-white/50">{c}</kbd>
            ))}
          </h3>
          <p className="mt-1 text-[12px] leading-5 text-white/55">{etape.texte}</p>
          {etape.action && (
            <Link
              to={etape.action.to}
              className="mt-2 inline-flex items-center gap-1 text-[11.5px] font-medium text-[#c9a96e] hover:underline"
            >
              {etape.action.label} <ArrowRight className="h-3 w-3" />
            </Link>
          )}
        </div>
      </div>
    </motion.article>
  );
}