import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Banknote } from "lucide-react";
import {
  PAYMENT_STATUS_LABELS,
  DECLARATION_NEXT_STEP,
  makeReceiptNumber,
} from "@/lib/payment";
import PaymentReceipt from "@/components/payment/PaymentReceipt";

// Ligne de suivi de paiement côté pro pour une réservation en espèces déclarées.
export default function ProPaymentRow({ booking }) {
  const [payment, setPayment] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    base44.entities.PaymentRecord.filter({ booking_id: booking.id })
      .then((res) => setPayment(res[0] || null))
      .catch(() => setPayment(null))
      .finally(() => setLoading(false));
  }, [booking.id]);

  const markReceived = async () => {
    if (!payment) return;
    setSaving(true);
    try {
      const receiptNumber = payment.receipt_number || makeReceiptNumber(booking.id);
      // Reçu émis puis déclaration à finaliser selon le chemin (logique simple).
      const nextStatus = payment.declaration_path && payment.declaration_path !== "a_verifier"
        ? "declaration_pending"
        : "receipt_generated";
      const updated = {
        status: nextStatus,
        receipt_number: receiptNumber,
        received_at: new Date().toISOString(),
        receipt_note: "Paiement en espèces déclaré sur place.",
      };
      await base44.entities.PaymentRecord.update(payment.id, updated);
      await base44.entities.Booking.update(booking.id, { payment_status: "received" });
      setPayment((prev) => ({ ...prev, ...updated }));
    } catch {
      // l'état local n'est pas modifié si l'opération échoue
    }
    setSaving(false);
  };

  if (loading || !payment || payment.method !== "cash_declared_on_site") return null;

  const received = ["received", "receipt_generated", "declaration_pending", "declared"].includes(payment.status);

  return (
    <div className="mt-3 rounded-lg border border-border bg-muted/30 p-3">
      <div className="flex items-center gap-2 mb-2">
        <Banknote className="w-4 h-4 text-muted-foreground shrink-0" />
        <span className="text-xs font-medium text-foreground">Espèces déclarées sur place</span>
        <span className="ml-auto text-[10px] font-semibold px-2 py-0.5 rounded-full bg-muted text-foreground">
          {PAYMENT_STATUS_LABELS[payment.status] || "À vérifier"}
        </span>
      </div>

      {!received ? (
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button size="sm" variant="outline" className="h-8 text-xs">Marquer paiement reçu</Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Confirmer la réception du paiement ?</AlertDialogTitle>
              <AlertDialogDescription>
                Un reçu sera généré et la trace conservée dans Artistry. Le paiement reste à déclarer
                selon votre situation.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Retour</AlertDialogCancel>
              <AlertDialogAction
                onClick={markReceived}
                disabled={saving}
                className="bg-foreground text-background hover:bg-foreground/90"
              >
                {saving ? "Enregistrement..." : "Confirmer"}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      ) : (
        <>
          <PaymentReceipt payment={payment} booking={booking} />
          <p className="text-[11px] text-foreground mt-2">
            Prochaine étape : {DECLARATION_NEXT_STEP[payment.declaration_path] || "À vérifier"}
          </p>
        </>
      )}
    </div>
  );
}