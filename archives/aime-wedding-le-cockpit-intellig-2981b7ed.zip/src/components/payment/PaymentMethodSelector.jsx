import { Banknote, Building2, HelpCircle } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import { CASH_THRESHOLD, cashStatusReminder, PAYMENT_DISCLAIMER } from "@/lib/payment";
import PaymentSourcesList from "@/components/payment/PaymentSourcesList";

// Trois choix sobres présentés au client. La valeur "cash" mappe vers cash_declared_on_site.
const OPTIONS = [
  { value: "cash", icon: Banknote, label: "Espèces déclarées sur place" },
  { value: "transfer", icon: Building2, label: "Virement ou facture" },
  { value: "later", icon: HelpCircle, label: "À définir avec l'artiste" },
];

export default function PaymentMethodSelector({
  value,
  onChange,
  acknowledged,
  onAcknowledgeChange,
  price,
  category,
}) {
  const overThreshold = (price || 0) > CASH_THRESHOLD;

  return (
    <div className="border-t border-border pt-4 mt-4">
      <p className="text-sm font-medium text-foreground mb-3">Paiement</p>

      <div className="space-y-2">
        {OPTIONS.map((opt) => {
          const active = value === opt.value;
          return (
            <button
              key={opt.value}
              type="button"
              onClick={() => onChange(opt.value)}
              className={`w-full flex items-center gap-2 text-left text-sm px-3 py-2.5 rounded-md border transition-colors ${
                active
                  ? "border-foreground bg-muted text-foreground"
                  : "border-border text-foreground hover:bg-muted/50"
              }`}
            >
              <opt.icon className="w-4 h-4 text-muted-foreground shrink-0" />
              {opt.label}
            </button>
          );
        })}
      </div>

      {value === "cash" && (
        <div className="mt-3 rounded-lg border border-border bg-muted/30 p-3 space-y-3">
          <p className="text-[11px] text-muted-foreground leading-relaxed">
            Le paiement peut être remis le jour de la prestation, dans les limites légales.
            Artistry conserve une trace et prépare le justificatif adapté.
          </p>

          {overThreshold && (
            <p className="text-[11px] text-foreground leading-relaxed font-medium">
              Le paiement en espèces peut être limité selon votre situation. Préférez virement
              ou facture si nécessaire.
            </p>
          )}

          <p className="text-[11px] text-muted-foreground leading-relaxed">
            {cashStatusReminder(category)}
          </p>

          <label className="flex items-start gap-2 cursor-pointer">
            <Checkbox
              checked={acknowledged}
              onCheckedChange={(v) => onAcknowledgeChange(Boolean(v))}
              className="mt-0.5"
            />
            <span className="text-[11px] text-foreground leading-relaxed">
              Je comprends que ce paiement doit rester déclaré et justifié.
            </span>
          </label>

          <div className="pt-1">
            <p className="text-[10px] text-muted-foreground italic mb-1.5">{PAYMENT_DISCLAIMER}</p>
            <PaymentSourcesList compact />
          </div>
        </div>
      )}
    </div>
  );
}