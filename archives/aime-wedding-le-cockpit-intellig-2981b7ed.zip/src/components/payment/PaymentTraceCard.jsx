import { Banknote, FileCheck } from "lucide-react";
import {
  METHOD_LABELS,
  PAYMENT_STATUS_LABELS,
  DECLARATION_NEXT_STEP,
  cashStatusReminder,
  PAYMENT_DISCLAIMER,
} from "@/lib/payment";
import PaymentSourcesList from "@/components/payment/PaymentSourcesList";

// Carte d'information sur la trace de paiement (utilisée en confirmation et côté pro).
export default function PaymentTraceCard({ payment, category }) {
  if (!payment) return null;
  const isCash = payment.method === "cash_declared_on_site";

  return (
    <div className="rounded-lg border border-border bg-muted/30 p-4">
      <div className="flex items-center gap-2 mb-2">
        <Banknote className="w-4 h-4 text-muted-foreground shrink-0" />
        <span className="text-sm font-medium text-foreground">
          {METHOD_LABELS[payment.method] || "À vérifier"}
        </span>
        <span className="ml-auto text-[10px] font-semibold px-2 py-0.5 rounded-full bg-muted text-foreground">
          {PAYMENT_STATUS_LABELS[payment.status] || "À vérifier"}
        </span>
      </div>

      {isCash && (
        <>
          <p className="text-xs text-muted-foreground leading-relaxed mb-1">
            Statut : Justificatif à préparer.
          </p>
          <p className="text-xs text-muted-foreground leading-relaxed mb-2">
            Prochaine étape : Demandez ou générez un reçu après la prestation.
          </p>
          <div className="flex items-center gap-1.5 text-xs text-foreground mb-2">
            <FileCheck className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
            {DECLARATION_NEXT_STEP[payment.declaration_path] || "À vérifier"}
          </div>
          <p className="text-[11px] text-muted-foreground leading-relaxed mb-3">
            {cashStatusReminder(category || payment.declaration_path)}
          </p>
          <p className="text-[10px] text-muted-foreground italic mb-1.5">{PAYMENT_DISCLAIMER}</p>
          <PaymentSourcesList compact />
        </>
      )}
    </div>
  );
}