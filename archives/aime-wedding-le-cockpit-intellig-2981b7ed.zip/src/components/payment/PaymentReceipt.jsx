import { format, parseISO } from "date-fns";
import { fr } from "date-fns/locale";

// Reçu simple affiché dans l'UI pour un paiement en espèces déclaré sur place.
export default function PaymentReceipt({ payment, booking }) {
  if (!payment) return null;
  const dateStr = payment.received_at
    ? format(parseISO(payment.received_at), "d MMMM yyyy", { locale: fr })
    : "À vérifier";

  const rows = [
    ["N° de reçu", payment.receipt_number || "À vérifier"],
    ["Artiste", payment.artist_name || "À vérifier"],
    ["Client", payment.client_name || "À vérifier"],
    ["Prestation", booking?.service || "À vérifier"],
    ["Montant", payment.amount != null ? `${payment.amount}€` : "À vérifier"],
    ["Date de réception", dateStr],
  ];

  return (
    <div className="rounded-lg border border-border bg-background p-4">
      <p className="text-sm font-semibold text-foreground mb-3">Reçu</p>
      <dl className="space-y-1.5">
        {rows.map(([k, v]) => (
          <div key={k} className="flex items-center justify-between text-xs">
            <dt className="text-muted-foreground">{k}</dt>
            <dd className="text-foreground font-medium">{v}</dd>
          </div>
        ))}
      </dl>
      <p className="text-[11px] text-muted-foreground italic mt-3 pt-3 border-t border-border">
        Paiement en espèces déclaré sur place.
      </p>
    </div>
  );
}