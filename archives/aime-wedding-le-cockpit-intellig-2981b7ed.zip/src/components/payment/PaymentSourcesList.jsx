import { ExternalLink } from "lucide-react";
import { PAYMENT_SOURCES } from "@/lib/payment";

export default function PaymentSourcesList({ compact = false }) {
  const items = compact ? PAYMENT_SOURCES.slice(0, 2) : PAYMENT_SOURCES;
  return (
    <ul className="space-y-1">
      {items.map((s) => (
        <li key={s.url}>
          <a
            href={s.url}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 text-[11px] text-muted-foreground hover:text-foreground underline underline-offset-2 transition-colors"
          >
            {s.label} <ExternalLink className="w-3 h-3 shrink-0" />
          </a>
        </li>
      ))}
    </ul>
  );
}