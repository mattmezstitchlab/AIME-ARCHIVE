import { useMemo } from "react";

const MOMENT_COLORS = {
  "Cérémonie": "#d4d4d4",
  "Cocktail": "#a3a3a3",
  "Repas": "#737373",
  "Ouverture de bal": "#404040",
  "Soirée": "#171717",
};

// Mini graphe SVG des BPM par moment, courbe d'énergie du mariage
export default function BpmTimeline({ grouped, moments }) {
  const points = useMemo(() => {
    const pts = [];
    moments.forEach((m) => {
      (grouped[m] || []).forEach((t) => {
        if (t.bpm) pts.push({ moment: m, bpm: t.bpm, title: t.title });
      });
    });
    return pts;
  }, [grouped, moments]);

  if (points.length < 2) {
    return (
      <div className="rounded-2xl border border-dashed border-foreground/10 px-6 py-8 text-center">
        <p className="text-xs text-foreground/40">
          Ajoutez des BPM à vos titres pour visualiser la courbe d'énergie du mariage.
        </p>
      </div>
    );
  }

  const minBpm = Math.min(...points.map((p) => p.bpm));
  const maxBpm = Math.max(...points.map((p) => p.bpm));
  const range = maxBpm - minBpm || 1;

  const W = 600;
  const H = 120;
  const PAD = 24;

  const coords = points.map((p, i) => ({
    x: PAD + (i / (points.length - 1)) * (W - PAD * 2),
    y: PAD + (1 - (p.bpm - minBpm) / range) * (H - PAD * 2),
    ...p,
  }));

  const pathD = coords
    .map((c, i) => (i === 0 ? `M${c.x},${c.y}` : `L${c.x},${c.y}`))
    .join(" ");

  // Gradient area
  const areaD = `${pathD} L${coords[coords.length - 1].x},${H} L${coords[0].x},${H} Z`;

  return (
    <div className="overflow-x-auto rounded-2xl border border-foreground/10 bg-card p-4">
      <p className="mb-2 text-[10px] font-semibold uppercase tracking-[0.2em] text-foreground/30">
        Courbe d'énergie
      </p>
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full" style={{ minWidth: 400 }}>
        <defs>
          <linearGradient id="bpmGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="hsl(0 0% 7%)" stopOpacity="0.15" />
            <stop offset="100%" stopColor="hsl(0 0% 7%)" stopOpacity="0.02" />
          </linearGradient>
        </defs>

        {/* Y axis labels */}
        <text x={4} y={PAD + 3} className="fill-foreground/25" fontSize="8">{maxBpm}</text>
        <text x={4} y={H - PAD + 8} className="fill-foreground/25" fontSize="8">{minBpm}</text>

        {/* Area */}
        <path d={areaD} fill="url(#bpmGrad)" />

        {/* Line */}
        <path d={pathD} fill="none" stroke="hsl(0 0% 12%)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />

        {/* Dots */}
        {coords.map((c, i) => (
          <g key={i}>
            <circle cx={c.x} cy={c.y} r="4" fill={MOMENT_COLORS[c.moment] || "#171717"} stroke="white" strokeWidth="1.5" />
            <title>{c.title} — {c.bpm} BPM ({c.moment})</title>
          </g>
        ))}
      </svg>

      {/* Legend */}
      <div className="mt-2 flex flex-wrap gap-3">
        {moments.filter((m) => (grouped[m] || []).some((t) => t.bpm)).map((m) => (
          <span key={m} className="flex items-center gap-1.5 text-[10px] text-foreground/50">
            <span className="inline-block h-2 w-2 rounded-full" style={{ backgroundColor: MOMENT_COLORS[m] }} />
            {m}
          </span>
        ))}
      </div>
    </div>
  );
}