import { AlertTriangle } from "lucide-react";

// Alerte quand l'écart de BPM entre deux titres consécutifs est trop grand
const MAX_BPM_GAP = 25;

export default function BpmFlowAlert({ tracks }) {
  const gaps = [];
  for (let i = 0; i < tracks.length - 1; i++) {
    const a = tracks[i];
    const b = tracks[i + 1];
    if (a.bpm && b.bpm && Math.abs(a.bpm - b.bpm) > MAX_BPM_GAP) {
      gaps.push({ from: a, to: b, gap: Math.abs(a.bpm - b.bpm) });
    }
  }

  if (gaps.length === 0) return null;

  return (
    <div className="rounded-xl border border-foreground/10 bg-foreground/[0.03] px-4 py-3">
      <p className="mb-1 flex items-center gap-1.5 text-xs font-medium text-foreground/70">
        <AlertTriangle className="h-3.5 w-3.5" aria-hidden="true" />
        Transition{gaps.length > 1 ? "s" : ""} à lisser
      </p>
      <ul className="space-y-1">
        {gaps.map((g, i) => (
          <li key={i} className="text-[11px] text-foreground/50">
            <span className="font-medium text-foreground/70">{g.from.title}</span>
            {" → "}
            <span className="font-medium text-foreground/70">{g.to.title}</span>
            {" "}
            <span className="text-foreground/40">({g.from.bpm} → {g.to.bpm} BPM, écart {g.gap})</span>
          </li>
        ))}
      </ul>
    </div>
  );
}