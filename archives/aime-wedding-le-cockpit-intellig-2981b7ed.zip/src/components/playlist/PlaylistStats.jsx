import { Music, Check, Gauge } from "lucide-react";

export default function PlaylistStats({ grouped, moments, blacklistCount }) {
  let total = 0;
  let approved = 0;
  let withBpm = 0;
  let bpmSum = 0;

  moments.forEach((m) => {
    (grouped[m] || []).forEach((t) => {
      total++;
      if (t.approved) approved++;
      if (t.bpm) { withBpm++; bpmSum += t.bpm; }
    });
  });

  const avgBpm = withBpm > 0 ? Math.round(bpmSum / withBpm) : null;

  return (
    <div className="rounded-2xl border border-foreground/10 bg-card p-5">
      <p className="mb-3 text-[10px] font-semibold uppercase tracking-[0.2em] text-foreground/30">
        Résumé
      </p>
      <div className="space-y-3">
        <div className="flex items-center gap-3">
          <span className="inline-flex h-8 w-8 items-center justify-center rounded-full bg-foreground/5">
            <Music className="h-4 w-4 text-foreground/50" aria-hidden="true" />
          </span>
          <div>
            <p className="text-sm font-medium text-foreground">{total} titre{total !== 1 ? "s" : ""}</p>
            <p className="text-[11px] text-foreground/40">{blacklistCount} interdit{blacklistCount !== 1 ? "s" : ""}</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <span className="inline-flex h-8 w-8 items-center justify-center rounded-full bg-foreground/5">
            <Check className="h-4 w-4 text-foreground/50" aria-hidden="true" />
          </span>
          <div>
            <p className="text-sm font-medium text-foreground">{approved} validé{approved !== 1 ? "s" : ""}</p>
            <p className="text-[11px] text-foreground/40">sur {total}</p>
          </div>
        </div>
        {avgBpm && (
          <div className="flex items-center gap-3">
            <span className="inline-flex h-8 w-8 items-center justify-center rounded-full bg-foreground/5">
              <Gauge className="h-4 w-4 text-foreground/50" aria-hidden="true" />
            </span>
            <div>
              <p className="text-sm font-medium text-foreground">{avgBpm} BPM moyen</p>
              <p className="text-[11px] text-foreground/40">{withBpm} titre{withBpm !== 1 ? "s" : ""} avec BPM</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}