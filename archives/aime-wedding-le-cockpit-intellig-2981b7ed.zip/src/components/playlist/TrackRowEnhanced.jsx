import { useState } from "react";
import { Check, Trash2, GripVertical } from "lucide-react";

export default function TrackRowEnhanced({ track, index, onApprove, onRemove, onBpmChange }) {
  const [editBpm, setEditBpm] = useState(false);
  const [bpmVal, setBpmVal] = useState(track.bpm || "");

  const saveBpm = () => {
    const v = bpmVal === "" ? null : Number(bpmVal);
    onBpmChange(Number.isFinite(v) ? v : null);
    setEditBpm(false);
  };

  return (
    <li className="group flex items-center gap-3 rounded-xl border border-foreground/10 bg-card px-4 py-3 transition-colors hover:border-foreground/20">
      <span className="w-5 text-center text-[10px] font-medium text-foreground/25">{index + 1}</span>
      <GripVertical className="h-4 w-4 shrink-0 text-foreground/15" aria-hidden="true" />
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-medium text-foreground">{track.title}</p>
        {track.artist && <p className="truncate text-[11px] text-foreground/40">{track.artist}</p>}
      </div>

      {/* BPM editable */}
      {editBpm ? (
        <form onSubmit={(e) => { e.preventDefault(); saveBpm(); }} className="flex items-center gap-1">
          <input
            type="number"
            value={bpmVal}
            onChange={(e) => setBpmVal(e.target.value)}
            autoFocus
            onBlur={saveBpm}
            className="w-14 rounded-md border border-foreground/20 bg-background px-2 py-0.5 text-center text-xs outline-none focus:border-foreground"
          />
          <span className="text-[10px] text-foreground/30">BPM</span>
        </form>
      ) : (
        <button
          type="button"
          onClick={() => setEditBpm(true)}
          className={`rounded-full px-2.5 py-0.5 text-[11px] transition-colors ${
            track.bpm
              ? "bg-foreground/5 font-medium text-foreground/60 hover:bg-foreground/10"
              : "border border-dashed border-foreground/15 text-foreground/30 hover:border-foreground/30"
          }`}
        >
          {track.bpm ? `${track.bpm} BPM` : "BPM"}
        </button>
      )}

      <button
        type="button"
        onClick={onApprove}
        aria-label={track.approved ? "Validé" : "Valider"}
        className={`inline-flex h-7 w-7 items-center justify-center rounded-full border transition-colors ${
          track.approved
            ? "border-foreground bg-foreground text-background"
            : "border-foreground/20 text-foreground/40 hover:border-foreground"
        }`}
      >
        <Check className="h-3.5 w-3.5" aria-hidden="true" />
      </button>
      <button
        type="button"
        onClick={onRemove}
        aria-label="Retirer"
        className="text-foreground/30 transition-colors hover:text-destructive"
      >
        <Trash2 className="h-4 w-4" aria-hidden="true" />
      </button>
    </li>
  );
}