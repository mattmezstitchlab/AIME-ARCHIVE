import { useState } from "react";
import { Wand2, Plus, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";

// Génère des titres de transition entre 2 morceaux via IA
export default function TransitionGenerator({ trackA, trackB, onAdd }) {
  const [suggestions, setSuggestions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);

  const generate = async () => {
    setLoading(true);
    setSuggestions([]);
    try {
      const bpmA = trackA.bpm || "inconnu";
      const bpmB = trackB.bpm || "inconnu";
      const prompt = `Tu es un DJ professionnel spécialisé en mariage.

Le titre "${trackA.title}" (${bpmA} BPM) est suivi de "${trackB.title}" (${bpmB} BPM).

Propose 3 à 5 titres de musique réels et connus pour assurer une transition fluide entre ces deux morceaux. Les BPM doivent progresser graduellement de ${bpmA} vers ${bpmB}.

Pour chaque titre donne : le titre, l'artiste et le BPM estimé.

Réponds uniquement en JSON.`;

      const res = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            transitions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  title: { type: "string" },
                  artist: { type: "string" },
                  bpm: { type: "number" },
                },
                required: ["title", "artist", "bpm"],
              },
            },
          },
          required: ["transitions"],
        },
      });

      setSuggestions(res.transitions || []);
    } catch {
      setSuggestions([]);
    } finally {
      setLoading(false);
    }
  };

  if (!open) {
    return (
      <button
        type="button"
        onClick={() => { setOpen(true); generate(); }}
        className="mx-auto flex items-center gap-1.5 rounded-full border border-dashed border-foreground/15 px-3 py-1.5 text-[11px] text-foreground/40 transition-colors hover:border-foreground/30 hover:text-foreground/60"
      >
        <Wand2 className="h-3 w-3" aria-hidden="true" />
        Générer une transition
      </button>
    );
  }

  return (
    <div className="rounded-xl border border-foreground/10 bg-foreground/[0.02] px-4 py-3">
      <div className="mb-2 flex items-center justify-between">
        <p className="text-[11px] font-medium text-foreground/60">
          Suggestions de transition
        </p>
        <button
          type="button"
          onClick={() => { setOpen(false); setSuggestions([]); }}
          className="text-[10px] text-foreground/30 hover:text-foreground/60"
        >
          Fermer
        </button>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-4">
          <Loader2 className="h-4 w-4 animate-spin text-foreground/30" />
          <span className="ml-2 text-xs text-foreground/40">Analyse des BPM…</span>
        </div>
      ) : suggestions.length > 0 ? (
        <ul className="space-y-1.5">
          {suggestions.map((s, i) => (
            <li key={i} className="flex items-center gap-3 rounded-lg bg-card px-3 py-2">
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm text-foreground">
                  {s.title} <span className="text-foreground/40">— {s.artist}</span>
                </p>
                <p className="text-[10px] text-foreground/40">{s.bpm} BPM</p>
              </div>
              <button
                type="button"
                onClick={() => onAdd(s)}
                className="inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-full border border-foreground/20 text-foreground/50 transition-colors hover:bg-foreground hover:text-background"
              >
                <Plus className="h-3 w-3" aria-hidden="true" />
              </button>
            </li>
          ))}
        </ul>
      ) : (
        <p className="py-3 text-center text-xs text-foreground/40">Aucune suggestion trouvée.</p>
      )}

      {!loading && (
        <button
          type="button"
          onClick={generate}
          className="mt-2 text-[11px] text-foreground/40 hover:text-foreground/60"
        >
          Regénérer
        </button>
      )}
    </div>
  );
}