import React from "react";

export default function AuthLayout({ icon: Icon, title, subtitle, footer, children, backgroundImage }) {
  return (
    <div className="relative min-h-screen flex items-center justify-center overflow-hidden bg-background px-4 py-12">
      {backgroundImage && <><img src={backgroundImage} alt="" className="absolute inset-0 h-full w-full object-cover" /><div className="absolute inset-0 bg-black/65" /></>}
      <div className="relative w-full max-w-md">
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-primary mb-4">
            <Icon className="w-7 h-7 text-primary-foreground" aria-hidden="true" />
          </div>
          <h1 className={`text-3xl font-bold tracking-tight ${backgroundImage ? "text-white" : "text-foreground"}`}>{title}</h1>
          {subtitle && <p className={`mt-2 ${backgroundImage ? "text-white/65" : "text-muted-foreground"}`}>{subtitle}</p>}
        </div>
        <div className="bg-card rounded-2xl shadow-sm border border-border p-8">
          {children}
        </div>
        {footer && (
          <p className={`mt-6 text-center text-sm ${backgroundImage ? "text-white/70" : "text-muted-foreground"}`}>{footer}</p>
        )}
      </div>
    </div>
  );
}