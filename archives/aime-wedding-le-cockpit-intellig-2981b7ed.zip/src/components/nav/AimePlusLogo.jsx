// LA MARQUE DE FABRIQUE — le cercle au contour arc-en-ciel qui circule,
// avec le « + » au centre. Au survol, il se transforme morphologiquement
// en carré et le + pivote en ✕ : le cercle/+ et le carré/✕, c'est AI+ME.
export default function AimePlusLogo({ size = 34 }) {
  return (
    <span className="group relative block" style={{ width: size, height: size }} aria-hidden="true">
      {/* L'anneau arc-en-ciel qui circule (conic-gradient en rotation). */}
      <span className="absolute inset-0 overflow-hidden rounded-full transition-all duration-500 group-hover:rounded-[7px]">
        <span
          className="absolute -inset-1/2"
          style={{
            background: "conic-gradient(#ff5f6d, #ffc371, #c9f76f, #38bdf8, #c084fc, #ff5f6d)",
            animation: "aime-plus-spin 3.5s linear infinite",
          }}
        />
      </span>
      {/* Le cœur noir : cercle → carré, et le + qui devient ✕. */}
      <span className="absolute inset-[2px] flex items-center justify-center rounded-full bg-[#0C0C0C] transition-all duration-500 group-hover:rounded-[5px]">
        <span
          className="text-[18px] font-light leading-none transition-transform duration-500 group-hover:rotate-45"
          style={{ animation: "aime-hue 8s linear infinite" }}
        >
          +
        </span>
      </span>
    </span>
  );
}