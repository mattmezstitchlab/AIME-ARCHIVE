// Navigation principale retirée pour l'instant (c'était du bruit).
// Le composant est conservé mais ne rend rien — on le réactivera plus tard.
export default function MainNav() {
  return null;
}