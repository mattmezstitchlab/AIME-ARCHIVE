import { Link } from "react-router-dom";

// LE HEADER UNIQUE — AIME® Wedding, centré. Rien d'autre.
export default function SiteHeader() {
  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b border-white/10 bg-black">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-center px-4 sm:px-6">
        <Link
          to="/"
          title="AIME® Wedding — l'accueil"
          className="flex flex-col items-center leading-none transition-opacity hover:opacity-80"
        >
          <span className="font-heading text-[16px] font-semibold tracking-[0.14em] text-white/90">
            AIME<span className="align-super text-[8px]">®</span>
          </span>
          <span className="font-signature -mt-0.5 text-[15px] text-white/70">Wedding</span>
        </Link>
      </div>
    </header>
  );
}