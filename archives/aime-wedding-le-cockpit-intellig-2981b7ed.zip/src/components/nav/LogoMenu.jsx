import { Link, useLocation } from "react-router-dom";
import { ChevronDown } from "lucide-react";
import { useAuth } from "@/lib/AuthContext";
import { useWedding } from "@/lib/wedding/useWedding";
import ArtistryWordmark from "@/components/editorial/ArtistryWordmark";
import MenuStepProgress from "@/components/nav/MenuStepProgress";
import { computeStepStatuses } from "@/lib/nav/menuStepStatus";

const STEP_ZERO = {
  key: "equipe", phase: "0 · L'Équipe", subtitle: "Les mariés, témoins, famille", links: [
    { label: "Toute l'équipe", to: "/equipe" },
  ],
};

const STEPS = [
  { key: "rever", phase: "1 · Rêver", subtitle: "La demande est faite — tout commence ici", links: [
    { label: "Date", to: "/avant/date" },
    { label: "Lieu", to: "/avant/lieu" },
    { label: "Cérémonies", to: "/avant/ceremonies" },
    { label: "· Civile", to: "/avant/ceremonies/civile" },
    { label: "· Religieuse", to: "/avant/ceremonies/religieuse" },
    { label: "· Laïque", to: "/avant/ceremonies/laique" },
    { label: "Documents", to: "/avant/documents" },
  ]},
  { key: "definir", phase: "2 · Budget", subtitle: "Combien, pour quoi", links: [
    { label: "Budget global", to: "/avant/budget" },
    { label: "Devis", to: "/avant/devis" },
    { label: "Acomptes", to: "/avant/acomptes" },
  ]},
  { key: "imaginer", phase: "3 · Style", subtitle: "Couleurs, ambiance, fleurs", links: [
    { label: "Palette", to: "/avant/palette" },
    { label: "Moodboard", to: "/avant/moodboard" },
    { label: "Fleurs", to: "/avant/fleurs" },
  ]},
  { key: "choisir", phase: "4 · Prestataires", subtitle: "Trouver, comparer, réserver", links: [
    { label: "Shortlist", to: "/avant/prestataires" },
    { label: "Recherche", to: "/recherche" },
    { label: "Alliances", to: "/avant/alliances" },
    { label: "· Bijoutier", to: "/avant/alliances/bijoutier" },
    { label: "· Gravure", to: "/avant/alliances/gravure" },
    { label: "· Statut", to: "/avant/alliances/statut" },
  ]},
  { key: "inviter", phase: "5 · Inviter", subtitle: "La liste, les RSVP, le site", links: [
    { label: "Liste d'invités", to: "/avant/invites" },
    { label: "Suivi RSVP", to: "/avant/rsvp" },
    { label: "Faire-part", to: "/avant/faire-part" },
    { label: "Site invités", to: "/avant/site-invite" },
  ]},
  { key: "composer", phase: "6 · Musique", subtitle: "Playlist rêvée et interdits", links: [
    { label: "Playlist", to: "/playlist" },
    { label: "Titres interdits", to: "/avant/blacklist" },
  ]},
  { key: "planifier", phase: "7 · Programme", subtitle: "Le déroulé heure par heure", links: [
    { label: "Programme du jour", to: "/programme" },
    { label: "Vœux", to: "/avant/voeux" },
    { label: "Discours", to: "/avant/discours" },
    { label: "Checklist", to: "/avant/checklist" },
  ]},
  { key: "organiser", phase: "8 · Logistique", subtitle: "Table, menu, hébergement, transport", links: [
    { label: "Plan de table", to: "/jour-j/plan-de-table" },
    { label: "Menu & traiteur", to: "/jour-j/menu" },
    { label: "· Traiteur", to: "/jour-j/menu/traiteur" },
    { label: "· Entrée", to: "/jour-j/menu/entree" },
    { label: "· Plat", to: "/jour-j/menu/plat" },
    { label: "· Dessert", to: "/jour-j/menu/dessert" },
    { label: "· Gâteau", to: "/jour-j/menu/gateau" },
    { label: "· Options (végé, enfants)", to: "/jour-j/menu/options" },
    { label: "· Vins", to: "/jour-j/menu/vins" },
    { label: "Dress code", to: "/jour-j/dress-code" },
    { label: "Hébergement", to: "/jour-j/hebergement" },
    { label: "Covoiturage", to: "/jour-j/covoiturage" },
  ]},
  { key: "preparer", phase: "9 · Urgences", subtitle: "Contacts clés et plans B", links: [
    { label: "Contacts utiles", to: "/contacts-utiles" },
    { label: "Kit urgences", to: "/urgences" },
  ]},
  { key: "offrir", phase: "10 · Cadeaux", subtitle: "Cagnotte, liste de mariage, EVJF/EVG", links: [
    { label: "Cagnotte", to: "/avant/cagnotte" },
    { label: "Liste de mariage", to: "/avant/liste-mariage" },
    { label: "EVJF / EVG", to: "/avant/evjf" },
    { label: "· EVJF", to: "/avant/evjf/evjf" },
    { label: "· EVG", to: "/avant/evjf/evg" },
  ]},
  { key: "vivre", phase: "11 · Cockpit", subtitle: "Cockpit temps réel", links: [
    { label: "Cockpit Jour J", to: "/jour-j" },
    { label: "Playlist DJ", to: "/jour-j/playlist" },
  ]},
  { key: "souvenir", phase: "12 · Souvenirs", subtitle: "Garder la magie", links: [
    { label: "Album photos", to: "/album-photos" },
    { label: "Livre d'or", to: "/livre-or" },
    { label: "Remerciements", to: "/remerciements" },
    { label: "Lune de miel", to: "/apres/lune-de-miel" },
    { label: "Changement de nom", to: "/apres/changement-nom" },
    { label: "Factures & solde", to: "/apres/factures-solde" },
  ]},
];

export default function LogoMenu({ open, onToggle, onNavigate }) {
  const { isAuthenticated, logout, navigateToLogin } = useAuth();
  const { wedding } = useWedding();
  const { pathname } = useLocation();
  const statuses = computeStepStatuses(wedding);

  const handleLogout = () => { onNavigate(); logout(); };
  const handleLogin = () => { onNavigate(); navigateToLogin(); };

  const doneCount = Object.values(statuses).filter(s => s.status === "done").length;
  const progress = Math.round((doneCount / STEPS.length) * 100);

  // Trouver l'étape active (la page courante)
  const allSteps = [STEP_ZERO, ...STEPS];
  const activeStepKey = allSteps.find(s => s.links.some(l => pathname === l.to || pathname.startsWith(l.to + "/")))?.key;

  return (
    <>
      <button
        type="button"
        aria-expanded={open}
        onClick={onToggle}
        className="flex items-center gap-1.5 shrink-0"
      >
        <ArtistryWordmark as="text" size="md" />
        <ChevronDown className={`w-3.5 h-3.5 text-foreground/60 transition-transform ${open ? "rotate-180" : ""}`} aria-hidden="true" />
      </button>

      {open && (
        <div className="fixed left-0 right-0 top-14 bottom-0 bg-background border-t border-border shadow-sm overflow-y-auto overscroll-contain">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 pb-24">

            {/* Barre de progression globale */}
            <div className="mb-6">
              <div className="flex items-center justify-between mb-2">
                <p className="text-[10px] font-semibold uppercase tracking-[0.28em] text-muted-foreground">
                  Mon Mariage — de A à Z
                </p>
                <span className="text-[11px] font-medium text-foreground/50">
                  {doneCount}/{STEPS.length} étapes · {progress} %
                </span>
              </div>
              <div className="h-1.5 w-full rounded-full bg-foreground/10 overflow-hidden">
                <div
                  className="h-full rounded-full bg-foreground transition-all duration-500"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>

            <div className="grid gap-6 lg:grid-cols-[1fr_1fr_200px]">
              {/* Colonne gauche — ÉQUIPE (0) + AVANT (1-6) */}
              <div className="space-y-3">
                <StepBlock step={STEP_ZERO} st={{ status: "active", hints: [] }} isCurrent={activeStepKey === "equipe"} onNavigate={onNavigate} />
                <PhaseLabel label="Avant · Préparer" to="/avant" onNavigate={onNavigate} />
                {STEPS.slice(0, 6).map((step) => (
                  <StepBlock key={step.key} step={step} st={statuses[step.key]} isCurrent={activeStepKey === step.key} onNavigate={onNavigate} />
                ))}
              </div>

              {/* Colonne droite — JOUR J (7-11) + APRÈS (12) */}
              <div className="space-y-3">
                <PhaseLabel label="Le Jour J · Agir" to="/jour-j" onNavigate={onNavigate} />
                {STEPS.slice(6, 11).map((step) => (
                  <StepBlock key={step.key} step={step} st={statuses[step.key]} isCurrent={activeStepKey === step.key} onNavigate={onNavigate} />
                ))}
                <div className="pt-2">
                  <PhaseLabel label="Après · Se souvenir" to="/apres" onNavigate={onNavigate} />
                </div>
                {STEPS.slice(11).map((step) => (
                  <StepBlock key={step.key} step={step} st={statuses[step.key]} isCurrent={activeStepKey === step.key} onNavigate={onNavigate} />
                ))}
              </div>

              {/* Colonne utilitaire */}
              <div className="flex flex-col gap-3 pt-1">
                <p className="text-[10px] font-semibold uppercase tracking-[0.28em] text-muted-foreground mb-1">
                  Navigation
                </p>
                <Link to="/" onClick={onNavigate} className="text-sm text-foreground hover:text-foreground/60 transition-colors">Accueil</Link>
                <Link to="/equipe" onClick={onNavigate} className="text-sm text-foreground hover:text-foreground/60 transition-colors">L'Équipe</Link>
                <Link to="/avant" onClick={onNavigate} className="text-sm text-foreground hover:text-foreground/60 transition-colors">Vue Avant</Link>
                <Link to="/jour-j" onClick={onNavigate} className="text-sm text-foreground hover:text-foreground/60 transition-colors">Vue Jour J</Link>
                <Link to="/apres" onClick={onNavigate} className="text-sm text-foreground hover:text-foreground/60 transition-colors">Vue Après</Link>
                <hr className="border-border my-1" />
                <Link to="/infos?tab=a-propos" onClick={onNavigate} className="text-sm text-foreground/60 hover:text-foreground transition-colors">À propos</Link>
                <Link to="/infos?tab=aide" onClick={onNavigate} className="text-sm text-foreground/60 hover:text-foreground transition-colors">Aide</Link>
                <hr className="border-border my-1" />
                {isAuthenticated ? (
                  <>
                    <Link to="/mon-compte" onClick={onNavigate} className="text-sm text-foreground hover:text-foreground/60 transition-colors">Mon compte</Link>
                    <button type="button" onClick={handleLogout} className="text-sm text-foreground/60 hover:text-foreground transition-colors text-left">Déconnexion</button>
                  </>
                ) : (
                  <button type="button" onClick={handleLogin} className="text-sm text-foreground hover:text-foreground/60 transition-colors text-left">Connexion</button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

function PhaseLabel({ label, to, onNavigate }) {
  return (
    <Link to={to} onClick={onNavigate} className="flex items-center gap-2 group mb-1">
      <span className="h-px flex-1 bg-foreground/10" />
      <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-foreground/30 group-hover:text-foreground/60 transition-colors">
        {label}
      </span>
      <span className="h-px flex-1 bg-foreground/10" />
    </Link>
  );
}

function StepBlock({ step, st, isCurrent, onNavigate }) {
  const isActive = st.status === "active";
  const isDone = st.status === "done";
  return (
    <div className={`rounded-xl px-3 py-2.5 transition-colors ${
      isCurrent ? "bg-foreground/[0.06] ring-1 ring-foreground/15" :
      isActive ? "bg-foreground/[0.03]" : ""
    }`}>
      <div className="flex items-center gap-2 mb-0.5">
        <MenuStepProgress status={st.status} />
        <p className={`text-[11px] font-bold uppercase tracking-[0.12em] leading-tight ${
          isDone ? "text-foreground/35 line-through" :
          isActive ? "text-foreground" : "text-foreground/45"
        }`}>
          {step.phase}
        </p>
      </div>
      <p className={`ml-6 text-[10px] mb-1.5 ${isDone ? "text-foreground/25" : "text-foreground/40"}`}>
        {step.subtitle}
      </p>
      {/* Résumés contextuels */}
      {st.hints.length > 0 && (
        <p className="ml-6 mb-1 text-[11px] font-medium text-foreground/55 leading-relaxed">
          {st.hints.join(" · ")}
        </p>
      )}
      <div className="flex flex-col gap-0 ml-6">
        {step.links.map((l) => (
          <Link
            key={l.label}
            to={l.to}
            onClick={onNavigate}
            className={`text-[13px] py-0.5 transition-colors ${
              isActive ? "text-foreground hover:text-foreground/70" :
              isDone ? "text-foreground/30 hover:text-foreground/50" :
              "text-foreground/50 hover:text-foreground"
            }`}
          >
            {l.label}
          </Link>
        ))}
      </div>
    </div>
  );
}