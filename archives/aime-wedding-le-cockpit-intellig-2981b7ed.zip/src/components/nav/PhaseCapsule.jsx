import { useNavigate, useLocation } from "react-router-dom";

const PHASES = [
  { key: "avant", label: "Avant", path: "/?focus=/avant/date" },
  { key: "jour-j", label: "Jour J", path: "/?focus=/programme" },
  { key: "apres", label: "Après", path: "/?focus=/album-photos" },
];

// Capsule temporelle globale (pastille noire, présente sur tout le site).
// Sur l'accueil immersif, `chrome` la synchronise au scroll. Ailleurs, elle
// navigue vers les pages de phase et met en avant la phase courante via l'URL.
export default function PhaseCapsule({ chrome }) {
  const navigate = useNavigate();
  const { pathname } = useLocation();

  const activeFromPath = pathname.startsWith("/jour-j")
    ? "jour-j"
    : pathname.startsWith("/apres")
    ? "apres"
    : pathname.startsWith("/avant")
    ? "avant"
    : null;

  const activePhase = chrome?.activePhase ?? activeFromPath;

  const handle = (p) => {
    if (chrome?.onJumpToPhase) chrome.onJumpToPhase(p.key);
    else navigate(p.path);
  };

  return (
    <div className="inline-flex items-center gap-1 rounded-full bg-black p-1 shadow-lg">
      {PHASES.map((p) => {
        const isActive = activePhase === p.key;
        return (
          <button
            key={p.key}
            type="button"
            onClick={() => handle(p)}
            className={`rounded-full px-3.5 py-1.5 text-[10px] font-semibold uppercase tracking-[0.12em] whitespace-nowrap transition-colors ${
              isActive ? "bg-white text-black" : "text-white/60 hover:text-white"
            }`}
          >
            {p.label}
          </button>
        );
      })}
    </div>
  );
}