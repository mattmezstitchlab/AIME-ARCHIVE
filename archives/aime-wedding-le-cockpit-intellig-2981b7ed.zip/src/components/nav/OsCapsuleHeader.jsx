import { Link } from "react-router-dom";
import { Footprints, Truck, Heart, Map, Megaphone, Route, Users, Flag, User, Atom } from "lucide-react";

// LA CAPSULE NOIRE GLOBALE — version essentielle après le grand nettoyage.
export default function OsCapsuleHeader() {
  const links = [
    { to: "/parcours#donner", label: "Donner", icon: Footprints },
    { to: "/parcours#relais", label: "Relais", icon: Truck },
    { to: "/parcours#besoin", label: "Besoin", icon: Heart },
    { to: "/carte", label: "Carte", icon: Map },
    { to: "/collectes", label: "Collectes", icon: Megaphone },
    { to: "/evenements", label: "Marches", icon: Flag },
    { to: "/chaines", label: "Chaînes", icon: Route },
    { to: "/association", label: "Assos", icon: Users },
    { to: "/soul", label: "Soul", icon: Atom },
    { to: "/compte", label: "Compte", icon: User },
  ];
  return (
    <header className="fixed inset-x-0 top-0 z-50 px-3 pt-3">
      <div className="mx-auto flex max-w-[1500px] items-center gap-3 rounded-full border border-white/10 bg-black px-4 py-1.5">
        <Link to="/" className="flex items-baseline text-white">
          <span className="text-[12px] font-extrabold uppercase tracking-[-0.02em]">LES PAS D'AIME</span>
        </Link>
        <span className="flex-1" />
        <nav className="flex items-center gap-0.5">
          {links.map((l) => (
            <Link key={l.to} to={l.to}
              className="flex min-h-[34px] items-center gap-1.5 rounded-full px-3 text-[11px] font-bold text-white/70 transition hover:bg-white/10 hover:text-white">
              <l.icon className="h-3.5 w-3.5 text-[#F2B90D]" aria-hidden="true" />
              {l.label}
            </Link>
          ))}
        </nav>
      </div>
    </header>
  );
}