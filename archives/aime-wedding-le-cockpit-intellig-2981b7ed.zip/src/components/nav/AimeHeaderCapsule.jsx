import { Link, useLocation } from "react-router-dom";
import { Sun, Moon } from "lucide-react";
import { useSiteTheme } from "@/lib/theme/useSiteTheme";

// Logo carré signature (copie du glyphe Manus des captures).
const MANUS_MARK = "https://media.base44.com/images/public/6a4121ee87663bd9b9c98ef7/a4628f51e_generated_image.png";

const NAV_LINKS = [
  { label: "Comment ça marche ?", path: "/comment-ca-marche" },
];

// ── Header AIME® WEDDING — épuré, fond noir ──────────────────────────────────
// Capsule flottante noire, allongée : gros glyphe carré + « AIME® WEDDING » à
// gauche, navigation au centre (À propos · Magazine · Comment ça marche ?), et
// le toggle jour / nuit tout à droite.
export default function AimeHeaderCapsule() {
  const { night, toggle } = useSiteTheme();
  const { pathname } = useLocation();

  return (
    <div className="pointer-events-none fixed inset-x-0 top-4 z-[70] flex justify-center px-3">
      <nav
        aria-label="AIME Wedding"
        className="pointer-events-auto flex items-center gap-4 rounded-full border border-white/10 bg-black px-3 py-2 shadow-xl backdrop-blur sm:gap-6 sm:px-5"
      >
        <Link to="/" className="flex items-center gap-3" aria-label="Accueil AIME Wedding">
          <img src={MANUS_MARK} alt="" className="h-9 w-9 sm:h-10 sm:w-10" />
          <span className="hidden font-heading text-[13px] font-semibold uppercase tracking-[0.22em] text-white sm:inline">
            AIME® WEDDING
          </span>
        </Link>

        <span className="hidden h-6 w-px bg-white/15 sm:block" />

        <div className="flex items-center gap-3 sm:gap-5">
          {NAV_LINKS.map((link) => {
            const active = pathname === link.path;
            return (
              <Link
                key={link.path}
                to={link.path}
                className={`font-heading text-[10px] font-semibold uppercase tracking-[0.14em] transition-colors sm:text-[11px] ${
                  active ? "text-white" : "text-white/55 hover:text-white"
                }`}
              >
                {link.label}
              </Link>
            );
          })}
        </div>

        <span className="h-6 w-px bg-white/15" />

        <button
          type="button"
          onClick={toggle}
          aria-label={night ? "Passer en mode jour" : "Passer en mode nuit"}
          title={night ? "Mode jour" : "Mode nuit"}
          className="flex items-center justify-center rounded-full p-1.5 text-white/60 transition-colors hover:text-white"
        >
          {night ? <Sun className="h-4 w-4" strokeWidth={1.5} /> : <Moon className="h-4 w-4" strokeWidth={1.5} />}
        </button>
      </nav>
    </div>
  );
}