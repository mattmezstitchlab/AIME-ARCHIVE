import { useEffect, useRef, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { ChevronDown } from "lucide-react";

const DEFAULT_PHASES = [
  { key: "avant", label: "Avant", path: "/?focus=/avant/date" },
  { key: "jour-j", label: "Jour J", path: "/?focus=/programme" },
  { key: "apres", label: "Après", path: "/?focus=/album-photos" },
];

function activePhaseFromPath(pathname) {
  if (pathname.startsWith("/jour-j")) return "jour-j";
  if (pathname.startsWith("/apres")) return "apres";
  if (pathname.startsWith("/avant")) return "avant";
  return null;
}

export default function TemporalLogoMenu({ phases = DEFAULT_PHASES, activePhase, onSelectPhase, color = "dark", size = "md" }) {
  const [open, setOpen] = useState(false);
  const wrapRef = useRef(null);
  const navigate = useNavigate();
  const { pathname } = useLocation();
  const isLight = color === "light";
  const current = activePhase ?? activePhaseFromPath(pathname);
  const items = phases.length ? phases : DEFAULT_PHASES;
  const currentLabel = current === "maintenant" ? "MAINTENANT" : (items.find((p) => p.key === current)?.label || "MAINTENANT").toUpperCase();
  const labelSize = size === "sm" ? "text-[12px]" : "text-[13px]";

  useEffect(() => {
    if (!open) return;
    const onDown = (e) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target)) setOpen(false);
    };
    const onKey = (e) => {
      if (e.key === "Escape") setOpen(false);
    };
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  const select = (phase) => {
    setOpen(false);
    if (onSelectPhase) onSelectPhase(phase.key);
    else navigate(phase.path || DEFAULT_PHASES.find((p) => p.key === phase.key)?.path || "/");
  };

  return (
    <div ref={wrapRef} className="relative shrink-0">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className={`inline-flex items-center gap-1.5 ${isLight ? "text-white" : "text-foreground"}`}
        aria-expanded={open}
        aria-label="Ouvrir le menu temporel"
      >
        <span className={`${labelSize} font-heading font-semibold uppercase tracking-[0.18em]`}>{currentLabel}</span>
        <ChevronDown className={`w-3 h-3 transition-transform ${isLight ? "text-white/60" : "text-foreground/45"} ${open ? "rotate-180" : ""}`} />
      </button>

      {open && (
        <div className="absolute left-0 top-full z-50 mt-2 w-40 rounded-xl bg-black/90 backdrop-blur-xl border border-white/10 p-1 shadow-2xl">
          {items.map((phase) => {
            const isActive = current === phase.key;
            return (
              <button
                key={phase.key}
                type="button"
                onClick={() => select(phase)}
                className={`flex w-full items-center justify-between rounded-lg px-3 py-1.5 text-left text-[11px] font-semibold uppercase tracking-[0.12em] transition-colors ${
                  isActive ? "bg-white text-foreground" : "text-white/70 hover:bg-white/10 hover:text-white"
                }`}
              >
                {phase.label}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}