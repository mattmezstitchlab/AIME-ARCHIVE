import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { User, Heart, Handshake, Users, PartyPopper, ClipboardList, Camera, Building2 } from "lucide-react";
import { ROLES } from "@/lib/home/journeySteps";

const ROLE_ICONS = { Heart, Handshake, Users, PartyPopper, ClipboardList, Camera, Building2 };

export default function ProfileRoleMenu({ role = "couple", onSelectRole, compact = false }) {
  const [open, setOpen] = useState(false);
  const wrapRef = useRef(null);

  useEffect(() => {
    if (!open) return;
    const onDown = (e) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target)) setOpen(false);
    };
    const onKey = (e) => {
      if (e.key === "Escape") setOpen(false);
    };
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  const size = compact ? "w-7 h-7" : "w-9 h-9";
  const iconSize = compact ? "w-3.5 h-3.5" : "w-4 h-4";

  return (
    <div ref={wrapRef} className="relative shrink-0">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className={`inline-flex items-center justify-center ${size} rounded-full bg-black text-white shadow-lg hover:bg-black/80 transition-colors`}
        aria-label="Profil et choix du rôle"
        aria-expanded={open}
      >
        <User className={iconSize} aria-hidden="true" />
      </button>

      {open && (
        <div className="absolute right-0 top-full z-50 mt-2 w-52 rounded-xl bg-black/90 backdrop-blur-xl border border-white/10 p-1 shadow-2xl">
          <p className="px-3 py-1.5 text-[9px] font-semibold uppercase tracking-[0.14em] text-white/35">Vue du dossier</p>
          {ROLES.map((r) => {
            const Icon = ROLE_ICONS[r.icon] || Heart;
            return (
              <button
                key={r.key}
                type="button"
                onClick={() => { onSelectRole?.(r.key); setOpen(false); }}
                className={`flex w-full items-center gap-2.5 rounded-lg px-3 py-1.5 text-left text-[12px] transition-colors ${
                  role === r.key ? "bg-white text-foreground" : "text-white/70 hover:bg-white/10 hover:text-white"
                }`}
              >
                <Icon className="w-3.5 h-3.5 shrink-0" strokeWidth={1.75} /> {r.label}
              </button>
            );
          })}
          <p className="px-3 py-2 text-[11px] leading-snug text-white/45">
            Chaque vue filtre le même mariage, sans créer un second site.
          </p>
          <div className="my-1 h-px bg-white/10" />
          <Link
            to="/mon-compte"
            onClick={() => setOpen(false)}
            className="flex w-full items-center gap-2.5 rounded-lg px-3 py-1.5 text-left text-[12px] text-white/70 hover:bg-white/10 hover:text-white transition-colors"
          >
            <User className="w-3.5 h-3.5" /> Mon compte
          </Link>
        </div>
      )}
    </div>
  );
}