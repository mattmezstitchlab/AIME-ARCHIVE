import { Link, useLocation } from "react-router-dom";
import { ChevronDown } from "lucide-react";
import { useWedding } from "@/lib/wedding/useWedding";
import MenuStepProgress from "@/components/nav/MenuStepProgress";
import { computeStepStatuses } from "@/lib/nav/menuStepStatus";

const AVANT_STEPS = [
  { key: "rever", phase: "1 · Rêver", links: [
    { label: "Date", to: "/avant/date" },
    { label: "Lieu", to: "/avant/lieu" },
    { label: "Cérémonies", to: "/avant/ceremonies" },
    { label: "Civile", to: "/avant/ceremonies/civile", sub: true },
    { label: "Religieuse", to: "/avant/ceremonies/religieuse", sub: true },
    { label: "Laïque", to: "/avant/ceremonies/laique", sub: true },
    { label: "Documents", to: "/avant/documents" },
  ]},
  { key: "definir", phase: "2 · Budget", links: [
    { label: "Budget global", to: "/avant/budget" },
    { label: "Devis", to: "/avant/devis" },
    { label: "Acomptes", to: "/avant/acomptes" },
  ]},
  { key: "imaginer", phase: "3 · Style", links: [
    { label: "Palette", to: "/avant/palette" },
    { label: "Moodboard", to: "/avant/moodboard" },
    { label: "Fleurs", to: "/avant/fleurs" },
  ]},
  { key: "choisir", phase: "4 · Prestataires", links: [
    { label: "Shortlist", to: "/avant/prestataires" },
    { label: "Recherche", to: "/recherche" },
    { label: "Alliances", to: "/avant/alliances" },
    { label: "Bijoutier", to: "/avant/alliances/bijoutier", sub: true },
    { label: "Gravure", to: "/avant/alliances/gravure", sub: true },
    { label: "Statut", to: "/avant/alliances/statut", sub: true },
  ]},
  { key: "inviter", phase: "5 · Inviter", links: [
    { label: "Liste d'invités", to: "/avant/invites" },
    { label: "Suivi RSVP", to: "/avant/rsvp" },
    { label: "Faire-part", to: "/avant/faire-part" },
    { label: "Site invités", to: "/avant/site-invite" },
  ]},
  { key: "composer", phase: "6 · Musique", links: [
    { label: "Playlist", to: "/playlist" },
    { label: "Titres interdits", to: "/avant/blacklist" },
  ]},
];

const JOURJ_STEPS = [
  { key: "planifier", phase: "7 · Programme", links: [
    { label: "Programme du jour", to: "/programme" },
    { label: "Vœux", to: "/avant/voeux" },
    { label: "Discours", to: "/avant/discours" },
    { label: "Checklist", to: "/avant/checklist" },
  ]},
  { key: "organiser", phase: "8 · Logistique", links: [
    { label: "Plan de table", to: "/jour-j/plan-de-table" },
    { label: "Menu & traiteur", to: "/jour-j/menu" },
    { label: "Traiteur", to: "/jour-j/menu/traiteur", sub: true },
    { label: "Entrée", to: "/jour-j/menu/entree", sub: true },
    { label: "Plat", to: "/jour-j/menu/plat", sub: true },
    { label: "Dessert", to: "/jour-j/menu/dessert", sub: true },
    { label: "Gâteau", to: "/jour-j/menu/gateau", sub: true },
    { label: "Options", to: "/jour-j/menu/options", sub: true },
    { label: "Vins", to: "/jour-j/menu/vins", sub: true },
    { label: "Dress code", to: "/jour-j/dress-code" },
    { label: "Hébergement", to: "/jour-j/hebergement" },
    { label: "Covoiturage", to: "/jour-j/covoiturage" },
  ]},
  { key: "preparer", phase: "9 · Urgences", links: [
    { label: "Contacts utiles", to: "/contacts-utiles" },
    { label: "Kit urgences", to: "/urgences" },
  ]},
  { key: "offrir", phase: "10 · Cadeaux", links: [
    { label: "Cagnotte", to: "/avant/cagnotte" },
    { label: "Liste de mariage", to: "/avant/liste-mariage" },
    { label: "EVJF / EVG", to: "/avant/evjf" },
    { label: "EVJF", to: "/avant/evjf/evjf", sub: true },
    { label: "EVG", to: "/avant/evjf/evg", sub: true },
  ]},
  { key: "vivre", phase: "11 · Cockpit", links: [
    { label: "Cockpit Jour J", to: "/jour-j" },
    { label: "Playlist DJ", to: "/jour-j/playlist" },
  ]},
];

const APRES_STEPS = [
  { key: "souvenir", phase: "12 · Souvenirs", links: [
    { label: "Album photos", to: "/album-photos" },
    { label: "Livre d'or", to: "/livre-or" },
    { label: "Remerciements", to: "/remerciements" },
    { label: "Lune de miel", to: "/apres/lune-de-miel" },
    { label: "Changement de nom", to: "/apres/changement-nom" },
    { label: "Factures & solde", to: "/apres/factures-solde" },
  ]},
];

const PHASE_MAP = {
  avant: { steps: AVANT_STEPS, label: "Avant", to: "/avant" },
  "jour-j": { steps: JOURJ_STEPS, label: "Jour J", to: "/jour-j" },
  apres: { steps: APRES_STEPS, label: "Après", to: "/apres" },
};

export default function PhaseDropdown({ phaseKey, isOpen, immersive, onToggle, onNavigate }) {
  const { wedding } = useWedding();
  const { pathname } = useLocation();
  const statuses = computeStepStatuses(wedding);
  const phase = PHASE_MAP[phaseKey];
  if (!phase) return null;

  const isOnPhase = pathname === phase.to || pathname.startsWith(phase.to + "/") ||
    phase.steps.some(s => s.links.some(l => pathname === l.to));

  return (
    <div className="relative">
      <button
        type="button"
        aria-expanded={isOpen}
        onClick={onToggle}
        className={
          immersive
            ? `inline-flex items-center gap-0.5 rounded-full px-2 sm:px-2.5 h-7 text-[10px] font-medium uppercase tracking-[0.12em] transition-colors ${
                isOpen ? "bg-white text-foreground" : "text-white/70 hover:text-white hover:bg-white/10"
              }`
            : `inline-flex items-center gap-1 rounded-full px-3 sm:px-4 h-9 text-[11px] sm:text-xs font-medium uppercase tracking-[0.14em] transition-colors ${
                isOnPhase && !isOpen ? "bg-foreground text-background" :
                isOpen ? "bg-foreground text-background" :
                "text-foreground/70 hover:text-foreground hover:bg-muted"
              }`
        }
      >
        {phase.label}
        <ChevronDown className={`${immersive ? "w-2.5 h-2.5" : "w-3 h-3"} transition-transform ${isOpen ? "rotate-180" : ""}`} aria-hidden="true" />
      </button>

      {isOpen && (
        <div className="absolute top-full left-0 mt-2 w-72 max-h-[calc(100vh-5rem)] overflow-y-auto overscroll-contain rounded-2xl border border-border bg-background shadow-lg p-4 space-y-3 z-50">
          {/* Lien vers la vue d'ensemble */}
          <Link
            to={phase.to}
            onClick={onNavigate}
            className="block text-[10px] font-semibold uppercase tracking-[0.2em] text-foreground/40 hover:text-foreground transition-colors pb-2 border-b border-border"
          >
            Vue d'ensemble →
          </Link>

          {phase.steps.map((step) => {
            const st = statuses[step.key] || { status: "pending", hints: [] };
            const isDone = st.status === "done";
            const isActive = st.status === "active";
            return (
              <div key={step.key}>
                <div className="flex items-center gap-1.5 mb-1">
                  <MenuStepProgress status={st.status} />
                  <span className={`text-[10px] font-bold uppercase tracking-[0.1em] ${
                    isDone ? "text-foreground/30 line-through" :
                    isActive ? "text-foreground" : "text-foreground/40"
                  }`}>
                    {step.phase}
                  </span>
                </div>
                <div className="flex flex-col ml-5">
                  {step.links.map((l) => {
                    const isCurrent = pathname === l.to;
                    const isSub = l.sub;
                    return (
                      <Link
                        key={l.to}
                        to={l.to}
                        onClick={onNavigate}
                        className={`py-0.5 transition-colors ${
                          isSub ? "ml-3 text-[12px]" : "text-[13px]"
                        } ${
                          isCurrent ? "text-foreground font-medium" :
                          isSub ? (isDone ? "text-foreground/25 hover:text-foreground/40" : "text-foreground/40 hover:text-foreground/70") :
                          isDone ? "text-foreground/30 hover:text-foreground/50" :
                          "text-foreground/60 hover:text-foreground"
                        }`}
                      >
                        {l.label}
                      </Link>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}