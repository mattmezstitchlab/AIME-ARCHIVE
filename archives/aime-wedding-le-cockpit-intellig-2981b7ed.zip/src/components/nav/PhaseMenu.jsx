import { Link } from "react-router-dom";

// Panneau déroulant d'un temps (Avant / Jour J / Après) sous le header.
// Chaque univers est un TITRE en majuscules bold ; ses sous-sous-menus sont
// listés en dessous en majuscules grises, plus petits. Pas de picto, ça respire.
export default function PhaseMenu({ phase, onNavigate, onGuide }) {
  return (
    <div className="grid sm:grid-cols-3 gap-x-12 gap-y-12">
      {phase.items.map((item) => {
        const titleCls =
          "block text-sm font-bold uppercase tracking-[0.14em] text-foreground hover:text-foreground/60 transition-colors";

        const Title =
          item.type === "guide" ? (
            <button type="button" onClick={onGuide} className={`${titleCls} text-left`}>
              {item.label}
            </button>
          ) : (
            <Link to={item.to} onClick={onNavigate} className={titleCls}>
              {item.label}
            </Link>
          );

        return (
          <div key={item.key}>
            {Title}
            {item.children?.length > 0 && (
              <div className="mt-4 flex flex-col gap-3">
                {item.children.map((child) => (
                  <Link
                    key={child.key}
                    to={child.to}
                    onClick={onNavigate}
                    className="block text-[11px] uppercase tracking-[0.16em] text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {child.label}
                  </Link>
                ))}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}