import { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { loadCompte } from "@/lib/compte/compteStore";

// AI+ME — le bouton bas-centre arc-en-ciel : il invoque DIRECTEMENT le
// Clavier AI+ME. Réservé aux comptes enregistrés — invisible pour le visiteur.
export default function AimeClavierButton() {
  const [compte, setCompte] = useState(loadCompte);
  const navigate = useNavigate();
  const { pathname } = useLocation();

  useEffect(() => {
    const h = () => setCompte(loadCompte());
    window.addEventListener("aime-compte-maj", h);
    return () => window.removeEventListener("aime-compte-maj", h);
  }, []);

  if (!compte) return null;

  const ouvrir = () => {
    if (pathname !== "/bureau") {
      navigate("/bureau");
      setTimeout(() => window.dispatchEvent(new CustomEvent("aime-clavier-toggle")), 400);
    } else {
      window.dispatchEvent(new CustomEvent("aime-clavier-toggle"));
    }
  };

  return (
    <button
      type="button"
      onClick={ouvrir}
      title="AI+ME — ouvrir le clavier"
      aria-label="AI+ME — ouvrir le clavier"
      className="group fixed bottom-4 left-1/2 z-[55] -translate-x-1/2"
    >
      <span className="relative block overflow-hidden rounded-full p-[2px]">
        <span
          className="absolute -inset-6"
          style={{
            background: "conic-gradient(#ff5f6d, #ffc371, #c9f76f, #38bdf8, #c084fc, #ff5f6d)",
            animation: "aime-plus-spin 3.5s linear infinite",
          }}
        />
        <span className="relative flex items-center gap-1 rounded-full bg-[#0C0C0C] px-5 py-2 font-heading text-[13px] font-semibold tracking-[0.12em] text-white transition-colors group-hover:bg-black">
          AI<span style={{ animation: "aime-hue 8s linear infinite" }}>+</span>ME
        </span>
      </span>
    </button>
  );
}