import { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import { POLES } from "./navPoles";
import CapsulePolePanel from "./CapsulePolePanel";

// LA CAPSULE AI + ME — la seule navigation du site : trois pôles, trois mondes.
export default function AimeCapsuleNav() {
  const [ouvert, setOuvert] = useState(null);
  const { pathname } = useLocation();

  useEffect(() => { setOuvert(null); }, [pathname]);

  const bascule = (key) => setOuvert((o) => (o === key ? null : key));
  const boutonCls = (key) =>
    `min-h-[44px] px-4 text-[20px] font-extrabold tracking-[-0.02em] transition ${
      ouvert === key ? "text-white" : "text-white/85 hover:text-white"
    }`;

  return (
    <header className="fixed inset-x-0 top-0 z-50 flex justify-center pt-3">
      {ouvert && (
        <button aria-label="Fermer le menu" onClick={() => setOuvert(null)}
          className="fixed inset-0 cursor-default bg-transparent" tabIndex={-1} />
      )}
      <div className="relative">
        <div className="flex items-center rounded-full border border-white/10 bg-[#181818] px-3 py-1.5 shadow-[0_10px_30px_rgba(0,0,0,0.5)]">
          <button onClick={() => bascule("ai")} aria-expanded={ouvert === "ai"} className={boutonCls("ai")}>
            AI
          </button>
          <button onClick={() => bascule("plus")} aria-expanded={ouvert === "plus"} aria-label="Le geste — donner, besoin, relais"
            className="mx-1 flex h-11 w-11 items-center justify-center rounded-full transition hover:scale-105"
            style={{ background: "conic-gradient(from 40deg, #F2A7C3, #E8C97F, #7FDCB2, #7FC3F0, #C9A2F5, #F2A7C3)" }}>
            <span className="text-[24px] font-extrabold leading-none text-[#141414]">+</span>
          </button>
          <button onClick={() => bascule("me")} aria-expanded={ouvert === "me"} className={boutonCls("me")}>
            ME
          </button>
        </div>
        {ouvert && <CapsulePolePanel pole={POLES[ouvert]} onClose={() => setOuvert(null)} />}
      </div>
    </header>
  );
}