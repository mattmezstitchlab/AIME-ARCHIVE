import { Atom, Search, Gauge, Footprints, Heart, Truck, User, AtSign } from "lucide-react";

// LES TROIS PÔLES — AI (ce que la machine voit), + (le geste), ME (ce qui est à vous).
export const POLES = {
  ai: {
    key: "ai",
    titre: "AI — ce que la machine voit",
    entrees: [
      { to: "/reseau", label: "Réseau vivant", icon: Atom },
      { to: "/suivi", label: "Mes passeports", icon: Search },
      { to: "/cockpit", label: "Cockpit de circulation", icon: Gauge },
    ],
  },
  plus: {
    key: "plus",
    titre: "+ — le geste, là où on se branche",
    entrees: [
      { to: "/parcours#donner", label: "Donner", icon: Footprints },
      { to: "/parcours#besoin", label: "Exprimer un besoin", icon: Heart },
      { to: "/parcours#relais", label: "Proposer un relais", icon: Truck },
    ],
  },
  me: {
    key: "me",
    titre: "ME — ce qui est à vous",
    entrees: [
      { to: "/compte", label: "Mon compte & notifications", icon: User },
      { to: "/compte#plus", label: "Ma page +nom", icon: AtSign },
    ],
  },
};