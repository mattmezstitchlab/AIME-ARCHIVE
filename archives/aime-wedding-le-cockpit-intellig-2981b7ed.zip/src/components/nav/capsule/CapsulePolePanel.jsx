import { Link } from "react-router-dom";
import { motion } from "framer-motion";

// LE PANNEAU D'UN PÔLE — se déplie sous la capsule, liste ses entrées.
export default function CapsulePolePanel({ pole, onClose }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: -8, scale: 0.97 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.18 }}
      className="absolute left-1/2 top-full mt-2 w-[280px] -translate-x-1/2 rounded-2xl border border-white/12 bg-[#141414] p-2 shadow-[0_18px_50px_rgba(0,0,0,0.6)]"
      role="menu"
    >
      <p className="px-3 pb-1 pt-2 font-mono text-[10px] font-bold uppercase tracking-[0.2em] text-white/40">
        {pole.titre}
      </p>
      {pole.entrees.map((e) => (
        <Link key={e.to} to={e.to} onClick={onClose} role="menuitem"
          className="flex min-h-[42px] items-center gap-3 rounded-xl px-3 text-[13px] font-bold text-white/80 transition hover:bg-white/10 hover:text-white">
          <e.icon className="h-4 w-4 text-[#F2B90D]" aria-hidden="true" />
          {e.label}
        </Link>
      ))}
      <Link to="/" onClick={onClose} role="menuitem"
        className="mt-1 flex min-h-[36px] items-center justify-center rounded-xl border-t border-white/10 text-[11px] font-bold uppercase tracking-[0.18em] text-white/40 transition hover:text-white">
        Les Pas d'AIME — Accueil
      </Link>
    </motion.div>
  );
}