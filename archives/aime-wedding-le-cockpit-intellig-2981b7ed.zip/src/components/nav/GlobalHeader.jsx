import { useEffect, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Menu, Radio, X } from "lucide-react";
import GlobalRadioPanel from "@/components/radio/GlobalRadioPanel";
import GlobalPrimaryNav from "@/components/nav/GlobalPrimaryNav";
import PassportSiteHeader from "@/components/passport/public/PassportSiteHeader";

export default function GlobalHeader() {
  const [open, setOpen] = useState(false);
  const [radioOpen, setRadioOpen] = useState(false);
  const { pathname, search, hash } = useLocation();
  useEffect(() => { setOpen(false); if (new URLSearchParams(search).get("radio")) setRadioOpen(true); }, [pathname, search, hash]);
  if (pathname.startsWith("/passeport/")) return <PassportSiteHeader />;

  return (
    <header className="safe-area-top fixed inset-x-0 top-0 z-20 border-b border-border bg-background/95 text-foreground shadow-sm backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-6 px-4 sm:px-6">
        <Link to="/" className="shrink-0 text-[18px] font-extrabold tracking-[-0.04em]" aria-label="Retour à l’accueil">
          AIME<sup className="ml-0.5 text-[8px]">®</sup>
        </Link>
        <div className="min-w-0 flex-1"><GlobalPrimaryNav /></div>
        <button type="button" onClick={() => setRadioOpen(true)} aria-label="Ouvrir la Radio mondiale" className="flex h-11 items-center gap-2 rounded-full border border-border px-3 text-[10px] font-bold"><Radio className="h-4 w-4" /><span className="hidden sm:inline">Radio</span></button>
        <button type="button" onClick={() => setOpen((value) => !value)} aria-expanded={open} aria-controls="navigation-mobile" aria-label={open ? "Fermer le menu" : "Ouvrir le menu"}
          className="flex h-11 w-11 cursor-pointer items-center justify-center rounded-full border border-border md:hidden">
          {open ? <X className="h-5 w-5" aria-hidden="true" /> : <Menu className="h-5 w-5" aria-hidden="true" />}
        </button>
      </div>
      {radioOpen && <GlobalRadioPanel onClose={() => setRadioOpen(false)} />}
      {open && <div id="navigation-mobile" className="border-t border-border bg-background p-3 md:hidden"><GlobalPrimaryNav mobile /></div>}
    </header>
  );
}