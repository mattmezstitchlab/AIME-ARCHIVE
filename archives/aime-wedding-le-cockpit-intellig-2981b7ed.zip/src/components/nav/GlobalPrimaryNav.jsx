import { Link, useLocation } from "react-router-dom";
const ITEMS = [["Explorer", "/reseau"], ["Créer", "/reseau?mode=donner"], ["Mes passeports", "/reseau?panel=passeports"]];
export default function GlobalPrimaryNav({ mobile = false }) {
  const { pathname, search } = useLocation();
  return <nav aria-label="Navigation principale" className={mobile ? "space-y-1" : "hidden items-center justify-center gap-7 md:flex"}>{ITEMS.map(([label, to]) => { const [path, query] = to.split("?"); const active = pathname === path && (query ? search.includes(query) : !search); return <Link key={label} to={to} aria-current={active ? "page" : undefined} className={mobile ? `block min-h-11 rounded-xl px-4 py-3 text-[15px] font-semibold ${active ? "bg-accent text-accent-foreground" : "text-foreground"}` : `text-[11px] font-semibold transition-colors ${active ? "text-foreground" : "text-muted-foreground hover:text-foreground"}`}>{label}</Link>; })}</nav>;
}