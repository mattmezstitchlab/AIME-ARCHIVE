import { useEffect, useState } from "react";
import { Sun, Moon } from "lucide-react";

// JOUR / NUIT — la bascule globale : elle pose/retire la classe .dark sur
// <html>, mémorisée pour toutes les sessions. Nuit par défaut.
export default function ThemeToggle() {
  const [jour, setJour] = useState(() => localStorage.getItem("aime-theme") === "jour");

  useEffect(() => {
    document.documentElement.classList.toggle("dark", !jour);
    localStorage.setItem("aime-theme", jour ? "jour" : "nuit");
  }, [jour]);

  return (
    <button
      type="button"
      onClick={() => setJour((j) => !j)}
      aria-label={jour ? "Passer en mode nuit" : "Passer en mode jour"}
      title={jour ? "Mode nuit" : "Mode jour"}
      className="flex h-6 w-6 items-center justify-center rounded-full text-white/50 transition hover:bg-white/10 hover:text-white"
    >
      {jour ? <Moon className="h-3 w-3" aria-hidden="true" /> : <Sun className="h-3 w-3" aria-hidden="true" />}
    </button>
  );
}