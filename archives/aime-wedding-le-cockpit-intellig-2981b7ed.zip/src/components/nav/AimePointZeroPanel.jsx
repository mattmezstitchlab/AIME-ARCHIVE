import { Link, useLocation } from "react-router-dom";
import { ArrowRight, Atom, BookOpen, Plus, X } from "lucide-react";

export default function AimePointZeroPanel({ onClose }) {
  const { pathname } = useLocation();
  const inNetwork = pathname === "/reseau";
  const actions = [
    { label: "Créer", detail: "Un don, un besoin ou un relais", to: "/reseau?mode=donner", icon: Plus },
    { label: "Mon réseau", detail: "Passeports, favoris et activités", to: "/reseau?panel=passeports", icon: BookOpen },
    { label: "Coordonner", detail: "Alertes et orchestration causale", to: "/reseau?agent=coordination", icon: Atom },
  ];
  return <section className="fixed left-1/2 top-20 z-[1800] w-[min(92vw,400px)] -translate-x-1/2 rounded-3xl border border-border bg-card p-4 text-card-foreground shadow-2xl" aria-label="Point Zéro AIME">
    <div className="flex items-start justify-between"><div><p className="text-[9px] font-bold uppercase tracking-[0.2em] text-muted-foreground">Point Zéro</p><h2 className="mt-1 text-lg font-extrabold">AIME® maintenant</h2></div><button type="button" onClick={onClose} aria-label="Fermer Point Zéro" className="flex h-9 w-9 items-center justify-center rounded-full bg-muted"><X className="h-4 w-4" /></button></div>
    <div className="mt-3 rounded-2xl bg-muted p-3"><p className="text-[9px] font-bold uppercase tracking-wider text-muted-foreground">Maintenant</p><p className="mt-1 text-sm font-bold">{inNetwork ? "Votre réseau vivant est ouvert." : "Votre prochain geste part d’ici."}</p><p className="mt-1 text-[10px] text-muted-foreground">Parce que chaque action doit rejoindre un passeport et produire une suite visible.</p></div>
    <div className="mt-3 space-y-2">{actions.map(({ label, detail, to, icon: Icon }) => <Link key={label} to={to} onClick={onClose} className="flex min-h-14 items-center gap-3 rounded-2xl border border-border px-3 hover:bg-muted"><Icon className="h-4 w-4" /><span className="flex-1"><strong className="block text-xs">{label}</strong><span className="text-[9px] text-muted-foreground">{detail}</span></span><ArrowRight className="h-4 w-4 text-muted-foreground" /></Link>)}</div>
  </section>;
}