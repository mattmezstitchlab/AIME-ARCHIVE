import { useEffect, useRef, useState } from "react";
import { ChevronDown, Heart, Handshake, Users, PartyPopper, ClipboardList, Camera, Building2 } from "lucide-react";
import ArtistryWordmark from "@/components/editorial/ArtistryWordmark";
import { ROLES } from "@/lib/home/journeySteps";

const ROLE_ICONS = { Heart, Handshake, Users, PartyPopper, ClipboardList, Camera, Building2 };

export default function LogoRoleMenu({ role = "couple", onSelectRole, color = "dark", size = "md" }) {
  const [open, setOpen] = useState(false);
  const wrapRef = useRef(null);
  const isLight = color === "light";

  useEffect(() => {
    if (!open) return;
    const onDown = (e) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target)) setOpen(false);
    };
    const onKey = (e) => {
      if (e.key === "Escape") setOpen(false);
    };
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  return (
    <div ref={wrapRef} className="relative shrink-0">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className={`inline-flex items-center gap-1.5 ${isLight ? "text-white" : "text-foreground"}`}
        aria-expanded={open}
        aria-label="Choisir votre rôle"
      >
        <ArtistryWordmark as="text" size={size} className={isLight ? "text-white" : ""} />
        <ChevronDown className={`w-3 h-3 transition-transform ${isLight ? "text-white/60" : "text-foreground/45"} ${open ? "rotate-180" : ""}`} />
      </button>

      {open && (
        <div className="absolute left-0 top-full z-50 mt-2 w-44 rounded-xl bg-black/90 backdrop-blur-xl border border-white/10 p-1 shadow-2xl">
          {ROLES.map((r) => {
            const Icon = ROLE_ICONS[r.icon] || Heart;
            return (
              <button
                key={r.key}
                type="button"
                onClick={() => { onSelectRole?.(r.key); setOpen(false); }}
                className={`flex w-full items-center gap-2.5 rounded-lg px-3 py-1.5 text-left text-[12px] transition-colors ${
                  role === r.key ? "bg-white text-foreground" : "text-white/70 hover:bg-white/10"
                }`}
              >
                <Icon className="w-3.5 h-3.5 shrink-0" strokeWidth={1.75} /> {r.label}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}