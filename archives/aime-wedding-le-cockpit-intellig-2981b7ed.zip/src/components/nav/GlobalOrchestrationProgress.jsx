import { useEffect, useState } from "react";
import { BellRing, Camera, Check, Clock3 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { orchestrationProgress } from "@/lib/passport/orchestrationProgress";

const STEPS = [
  { label: "Départ", Icon: Clock3 },
  { label: "Alerte", Icon: BellRing },
  { label: "Remise", Icon: Check },
  { label: "Preuve", Icon: Camera },
];

export default function GlobalOrchestrationProgress() {
  const [record, setRecord] = useState(null);
  useEffect(() => { base44.auth.me().then((me) => base44.entities.PassportOrchestration.filter({ created_by_id: me.id }, "-activation_at", 1)).then((items) => setRecord(items[0] || null)).catch(() => setRecord(null)); }, []);
  const activeStep = orchestrationProgress(record);
  return <div className="mx-auto w-full max-w-lg px-2" aria-label="Avancée de l’orchestration">
    <div className="relative">
      <div className="absolute left-[12.5%] right-[12.5%] top-3.5 h-0.5 bg-border" aria-hidden="true" />
      <div className="absolute left-[12.5%] top-3.5 h-0.5 bg-accent" style={{ width: `${activeStep * 25}%` }} aria-hidden="true" />
      <ol className="relative grid grid-cols-4">
        {STEPS.map(({ label, Icon }, index) => { const reached = index <= activeStep; return <li key={label} className="flex min-w-0 flex-col items-center gap-0.5" title={label}>
          <span className={`flex h-7 w-7 items-center justify-center rounded-full border ${reached ? "border-accent bg-accent text-accent-foreground" : "border-border bg-background text-muted-foreground"}`} aria-current={index === activeStep ? "step" : undefined}><Icon className="h-3 w-3" aria-hidden="true" /></span>
          <span className="hidden truncate text-[7px] font-bold text-muted-foreground sm:block">{label}</span>
        </li>; })}
      </ol>
    </div>
  </div>;
}