// Logo AIME® — carré au contour blanc, diagonales croisées à l'intérieur.
export default function AimeLogoMark({ size = 26, className = "" }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      aria-hidden="true"
      className={className}
    >
      <rect x="1.5" y="1.5" width="21" height="21" stroke="currentColor" strokeWidth="1.5" />
      <line x1="1.5" y1="1.5" x2="22.5" y2="22.5" stroke="currentColor" strokeWidth="1.2" />
      <line x1="22.5" y1="1.5" x2="1.5" y2="22.5" stroke="currentColor" strokeWidth="1.2" />
    </svg>
  );
}