import { Link, useLocation } from "react-router-dom";
import { useGuide } from "@/lib/guide/GuideContext";
import { UNIVERSES } from "@/lib/nav/universes";

// Barre d'univers : les grands pôles du mariage, toujours accessibles sur desktop.
// Masquée sur mobile, où les pôles sont repris dans le menu burger.
export default function UniverseNav() {
  const location = useLocation();
  const { openGuide } = useGuide();

  const baseItem =
    "inline-flex items-center gap-1.5 whitespace-nowrap rounded-full px-3.5 h-8 text-[12.5px] font-medium transition-colors shrink-0";

  return (
    <nav
      aria-label="Univers du mariage"
      className="hidden lg:block sticky top-14 z-40 bg-background/95 backdrop-blur border-b border-border"
    >
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-hide py-2">
          {UNIVERSES.map((u) => {
            const Icon = u.icon;

            if (u.type === "guide") {
              return (
                <button
                  key={u.key}
                  type="button"
                  onClick={() => openGuide()}
                  className={`${baseItem} text-muted-foreground hover:text-foreground hover:bg-muted`}
                >
                  <Icon className="w-4 h-4" aria-hidden="true" />
                  {u.label}
                </button>
              );
            }

            const isActive = location.pathname + location.search === u.to;
            return (
              <Link
                key={u.key}
                to={u.to}
                className={`${baseItem} ${
                  isActive
                    ? "bg-foreground text-background"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted"
                }`}
              >
                <Icon className="w-4 h-4" aria-hidden="true" />
                {u.label}
              </Link>
            );
          })}
        </div>
      </div>
    </nav>
  );
}