import { Check, Circle, ArrowRight } from "lucide-react";

// Pastille d'état d'une étape : fait, en cours, ou à faire.
export default function MenuStepProgress({ status }) {
  if (status === "done") {
    return (
      <span className="inline-flex h-4 w-4 items-center justify-center rounded-full bg-foreground">
        <Check className="h-2.5 w-2.5 text-background" aria-hidden="true" />
      </span>
    );
  }
  if (status === "active") {
    return (
      <span className="relative inline-flex h-4 w-4 items-center justify-center">
        <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-foreground/20" />
        <span className="inline-flex h-2.5 w-2.5 rounded-full bg-foreground" />
      </span>
    );
  }
  return (
    <span className="inline-flex h-4 w-4 items-center justify-center rounded-full border border-foreground/20">
      <Circle className="h-2 w-2 text-foreground/20" aria-hidden="true" />
    </span>
  );
}