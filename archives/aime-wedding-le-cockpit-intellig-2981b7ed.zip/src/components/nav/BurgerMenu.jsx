import { useState } from "react";
import { Link } from "react-router-dom";
import { X, Waves } from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { AIME_NAV } from "@/lib/aimeWeddingSite";

const INFO_LINKS = [
  { label: "À propos", to: "/a-propos" },
  { label: "Blog", to: "/blog" },
  { label: "Aide", to: "/infos?tab=aide" },
  { label: "Contact", to: "/infos?tab=contact" },
  { label: "Plan du site", to: "/plan-du-site" },
];

const LEGAL_LINKS = [
  { label: "Mentions légales", to: "/legal?tab=cgu" },
  { label: "Confidentialité", to: "/legal?tab=confidentialite" },
  { label: "Cookies", to: "/legal?tab=cookies" },
  { label: "Accessibilité", to: "/legal?tab=accessibilite" },
];

function Group({ title, links, onClose }) {
  return (
    <div>
      <p className="font-heading text-[12px] font-semibold uppercase tracking-[0.22em] text-foreground">{title}</p>
      <ul className="mt-3 space-y-0.5">
        {links.map((link) => (
          <li key={link.to}>
            <Link
              to={link.to}
              onClick={onClose}
              className="block rounded-md px-2 py-1.5 font-heading text-[11px] uppercase tracking-[0.16em] text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
            >
              {link.label}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}

// Menu déroulant burger sous le logo : verticales par rôle, Ripple UI (source de
// vérité), infos et mentions légales — sécurise l'accès à tout le site.
export default function BurgerMenu() {
  const [open, setOpen] = useState(false);
  const close = () => setOpen(false);

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger
        aria-label="Ouvrir le menu"
        className="flex h-8 w-8 items-center justify-center rounded-full transition-colors hover:bg-muted"
      >
        {open ? <X className="h-5 w-5" /> : <Waves className="h-5 w-5" />}
      </SheetTrigger>
      <SheetContent side="left" className="w-[320px] overflow-y-auto">
        <SheetHeader>
          <SheetTitle className="font-heading text-sm font-semibold uppercase tracking-[0.22em]">AIME WEDDING</SheetTitle>
        </SheetHeader>

        <div className="mt-6 space-y-7">
          <Link
            to="/mecanisme"
            onClick={close}
            className="flex items-center gap-3 rounded-lg border border-foreground bg-foreground p-3 text-background"
          >
            <Waves className="h-5 w-5" />
            <div>
              <p className="font-heading text-sm font-semibold uppercase tracking-[0.16em]">Le mécanisme</p>
              <p className="font-heading text-[10px] uppercase tracking-[0.14em] text-background/70">Une décision, une onde</p>
            </div>
          </Link>

          <Group title="Les verticales" links={AIME_NAV.map((n) => ({ label: n.label, to: n.path }))} onClose={close} />
          <Group title="Infos" links={INFO_LINKS} onClose={close} />
          <Group title="Mentions légales" links={LEGAL_LINKS} onClose={close} />
        </div>
      </SheetContent>
    </Sheet>
  );
}