import { AlertTriangle, XCircle, CheckCircle2 } from "lucide-react";
import { DEAD_LINKS } from "@/lib/health/siteSquelette";

const META = {
  dead: { icon: XCircle, color: "text-red-400", label: "Mort" },
  warn: { icon: AlertTriangle, color: "text-amber-400", label: "À surveiller" },
  ok: { icon: CheckCircle2, color: "text-emerald-400", label: "Couvert" },
};

// Liens morts et problèmes connus.
export default function SanteDeadLinks() {
  return (
    <div className="rounded-2xl border border-border bg-card/50 p-5">
      <p className="mb-4 font-mono text-[10px] uppercase tracking-[0.25em] text-muted-foreground">
        Liens morts & alertes · {DEAD_LINKS.length}
      </p>
      <div className="space-y-3">
        {DEAD_LINKS.map((d) => {
          const m = META[d.severity];
          const Icon = m.icon;
          return (
            <div key={d.path} className="flex items-start gap-2.5">
              <Icon className={`mt-0.5 h-4 w-4 shrink-0 ${m.color}`} />
              <div>
                <p className="font-mono text-[12px] text-foreground">
                  {d.path} <span className={`ml-1 text-[10px] uppercase tracking-[0.12em] ${m.color}`}>{m.label}</span>
                </p>
                <p className="text-[12px] text-muted-foreground">{d.issue}</p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}