import { Link } from "react-router-dom";
import { ArrowUpRight, CircleDot } from "lucide-react";

// Un groupe de routes vivantes : chaque page, son chemin, et ses branchements sortants.
export default function SanteRouteGroup({ group }) {
  return (
    <div className="rounded-2xl border border-border bg-card/50 p-5">
      <p className="mb-4 font-mono text-[10px] uppercase tracking-[0.25em] text-muted-foreground">
        {group.label} · {group.routes.length}
      </p>
      <div className="space-y-4">
        {group.routes.map((r) => (
          <div key={r.path} className="border-l-2 border-emerald-500/40 pl-3">
            <div className="flex flex-wrap items-center gap-2">
              <CircleDot className="h-3 w-3 text-emerald-400" />
              {r.dynamic ? (
                <span className="font-mono text-[12px] text-foreground">{r.path}</span>
              ) : (
                <Link to={r.path} className="font-mono text-[12px] text-foreground underline-offset-2 hover:underline">
                  {r.path}
                </Link>
              )}
              <span className="text-[12px] text-muted-foreground">— {r.name}</span>
              {r.dynamic && (
                <span className="rounded-full bg-muted px-2 py-0.5 font-mono text-[9px] uppercase tracking-[0.12em] text-muted-foreground">
                  dynamique
                </span>
              )}
            </div>
            {r.links?.length > 0 && (
              <div className="mt-1.5 flex flex-wrap gap-1.5">
                {r.links.map((l) => (
                  <span key={l} className="inline-flex items-center gap-1 rounded border border-border px-1.5 py-0.5 font-mono text-[10px] text-muted-foreground">
                    <ArrowUpRight className="h-2.5 w-2.5" /> {l}
                  </span>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}