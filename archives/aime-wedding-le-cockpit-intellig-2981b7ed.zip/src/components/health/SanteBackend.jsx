import { Database, FunctionSquare, Plug } from "lucide-react";
import { ENTITIES, FUNCTIONS, INTEGRATIONS } from "@/lib/health/siteMap";

// Les branchements backend : entités, fonctions déployées, intégrations.
export default function SanteBackend() {
  const cols = [
    { icon: Database, label: "Entités branchées", items: ENTITIES.map((e) => e.name) },
    { icon: FunctionSquare, label: "Fonctions backend", items: FUNCTIONS.map((f) => f.name) },
    { icon: Plug, label: "Intégrations", items: INTEGRATIONS.map((i) => `${i.name}${i.status === "partial" ? " (partiel)" : ""}`) },
  ];
  return (
    <div className="grid gap-4 md:grid-cols-3">
      {cols.map((c) => (
        <div key={c.label} className="rounded-2xl border border-border bg-card/50 p-5">
          <p className="mb-3 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.25em] text-muted-foreground">
            <c.icon className="h-3.5 w-3.5" /> {c.label} · {c.items.length}
          </p>
          <div className="flex flex-wrap gap-1.5">
            {c.items.map((it) => (
              <span key={it} className="rounded border border-border px-2 py-0.5 font-mono text-[10px] text-foreground/80">
                {it}
              </span>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}