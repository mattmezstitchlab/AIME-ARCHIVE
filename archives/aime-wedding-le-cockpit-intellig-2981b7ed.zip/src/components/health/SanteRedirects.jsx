import { CornerDownRight } from "lucide-react";
import { REDIRECTS } from "@/lib/health/siteSquelette";

// La table des redirections legacy : ancien chemin → nouvelle maison.
export default function SanteRedirects() {
  return (
    <div className="rounded-2xl border border-border bg-card/50 p-5">
      <p className="mb-4 font-mono text-[10px] uppercase tracking-[0.25em] text-muted-foreground">
        Redirections · {REDIRECTS.length}
      </p>
      <div className="space-y-2">
        {REDIRECTS.map((r) => (
          <div key={r.from} className="flex flex-wrap items-baseline gap-2 border-b border-border/50 pb-2 last:border-0">
            <span className="font-mono text-[11px] text-amber-400/90">{r.from}</span>
            <CornerDownRight className="h-3 w-3 shrink-0 text-muted-foreground" />
            <span className="font-mono text-[11px] text-muted-foreground">{r.to}</span>
          </div>
        ))}
      </div>
    </div>
  );
}