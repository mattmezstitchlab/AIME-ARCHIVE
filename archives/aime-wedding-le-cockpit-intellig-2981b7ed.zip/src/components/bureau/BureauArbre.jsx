import { useState } from "react";
import { Link } from "react-router-dom";
import { ChevronRight, FileText, ArrowRight } from "lucide-react";

// ─────────────────────────────────────────────────────────────────────────
// ARBRE DU BUREAU — rendu générique récursif.
// Nœud : { id, label, icon, color, badge, summary, to, children }
//   · children  → dossier repliable
//   · to        → fichier-lien (navigue)
//   · ni l'un ni l'autre → fichier informatif (valeur rangée)
// ─────────────────────────────────────────────────────────────────────────

function Row({ node, depth = 0 }) {
  const [open, setOpen] = useState(depth === 0);
  const Icon = node.icon || FileText;
  const pad = { paddingLeft: `${depth * 18 + 8}px` };

  // Dossier repliable
  if (node.children?.length) {
    return (
      <li>
        <button
          type="button"
          onClick={() => setOpen((o) => !o)}
          className="flex w-full items-center gap-2.5 rounded-lg px-2 py-2 text-left transition-colors hover:bg-white/5"
          style={pad}
        >
          <ChevronRight
            className={`h-3.5 w-3.5 shrink-0 text-white/40 transition-transform ${open ? "rotate-90" : ""}`}
          />
          <Icon className="h-4 w-4 shrink-0" style={{ color: node.color || "#c9a96e" }} strokeWidth={1.7} />
          <span className={`flex-1 truncate ${depth === 0 ? "font-heading text-[14px] font-semibold uppercase tracking-[0.12em] text-white" : "text-[13px] text-white/85"}`}>
            {node.label}
          </span>
          {node.badge && <span className="shrink-0 text-[10px] text-white/35">{node.badge}</span>}
        </button>
        {open && (
          <ul className="border-l border-white/10" style={{ marginLeft: `${depth * 18 + 22}px` }}>
            {node.children.map((child) => (
              <Row key={child.id} node={child} depth={0.5} />
            ))}
          </ul>
        )}
      </li>
    );
  }

  // Fichier-action (ouvre une application du Bureau, sans navigation)
  if (node.action) {
    return (
      <li>
        <button
          type="button"
          onClick={node.action}
          className="group flex w-full items-center gap-2.5 rounded-lg px-2 py-2 text-left transition-colors hover:bg-white/5"
          style={pad}
        >
          <Icon className="h-4 w-4 shrink-0" style={{ color: node.color || "rgba(255,255,255,0.5)" }} strokeWidth={1.7} />
          <span className="min-w-0 flex-1 truncate text-[12.5px] font-medium text-white/80 group-hover:text-white">
            {node.label}
          </span>
          <ArrowRight className="h-3.5 w-3.5 shrink-0 text-white/25 transition-colors group-hover:text-white/70" />
        </button>
      </li>
    );
  }

  // Fichier-lien
  if (node.to) {
    return (
      <li>
        <Link
          to={node.to}
          className="group flex items-center gap-2.5 rounded-lg px-2 py-2 transition-colors hover:bg-white/5"
          style={pad}
        >
          <Icon className="h-4 w-4 shrink-0" style={{ color: node.color || "rgba(255,255,255,0.5)" }} strokeWidth={1.7} />
          <span className="min-w-0 flex-1 truncate text-[12.5px] font-medium text-white/80 group-hover:text-white">
            {node.label}
          </span>
          {node.summary && <span className="shrink-0 truncate text-[10.5px] text-white/40">{node.summary}</span>}
          <ArrowRight className="h-3.5 w-3.5 shrink-0 text-white/25 transition-colors group-hover:text-white/70" />
        </Link>
      </li>
    );
  }

  // Fichier informatif (valeur rangée)
  return (
    <li className="flex items-center gap-2.5 px-2 py-1.5" style={pad}>
      <FileText className="h-3.5 w-3.5 shrink-0 text-white/35" strokeWidth={1.6} />
      <span className="min-w-0 flex-1 truncate text-[12px] text-white/60">{node.label}</span>
      {node.summary && <span className="shrink-0 truncate text-[10.5px] text-white/40">{node.summary}</span>}
    </li>
  );
}

export default function BureauArbre({ nodes }) {
  return (
    <ul className="space-y-1">
      {nodes.map((node) => (
        <Row key={node.id} node={node} depth={0} />
      ))}
    </ul>
  );
}