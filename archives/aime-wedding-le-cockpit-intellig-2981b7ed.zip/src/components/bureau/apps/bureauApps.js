import { ShieldCheck, LayoutGrid, Library, Fingerprint, RadioTower, History } from "lucide-react";

// LES APPLICATIONS DU BUREAU — plus de dock : elles s'ouvrent uniquement
// depuis les dossiers du moteur radial. L'Absorbeur et le Scénario sont
// FUSIONNÉS dans la pipeline EAA (onglets d'un même outil).
export const BUREAU_APPS = [
  {
    id: "frise",
    label: "Ma frise — 1024 graduations",
    tagline: "La chronologie des vérités, filtrable : vérités, non-dits brisés, lignée",
    icon: History,
    color: "#c9a96e",
  },
  {
    id: "signature5d",
    label: "Moteur radial 5D",
    tagline: "5 dimensions × 4 positions = 1024 signatures vivantes",
    icon: Fingerprint,
    color: "#c084fc",
  },
  {
    id: "radio",
    label: "Radio On Air",
    tagline: "Seules les musiques en élévation — alpha → omega, phases solaire et lunaire",
    icon: RadioTower,
    color: "#f87171",
  },
  {
    id: "eaa",
    label: "Pipeline EAA",
    tagline: "Absorber → auditer → raconter : la pipeline complète",
    icon: ShieldCheck,
    color: "#34d399",
  },
  {
    id: "canevas",
    label: "Le grand canevas",
    tagline: "Tous les blocs du site sur une même surface",
    icon: LayoutGrid,
    color: "#38bdf8",
  },
  {
    id: "bibliotheque",
    label: "Bibliothèque visuelle",
    tagline: "Tous les visuels, classés, filtrables, animables",
    icon: Library,
    color: "#c9a96e",
  },
];