import { X } from "lucide-react";
import { BUREAU_APPS } from "./bureauApps";
import EaaSuite from "./EaaSuite";
import BlocksCanvas from "@/components/gallery/BlocksCanvas";
import VisualsLibrary from "@/components/gallery/VisualsLibrary";
import MoteurRadial5D from "@/components/bureau/signature/MoteurRadial5D";

const APP_CONTENT = {
  signature5d: MoteurRadial5D,
  eaa: EaaSuite, // pipeline fusionnée : EAA + Absorbeur + Scénario
  canevas: BlocksCanvas,
  bibliotheque: VisualsLibrary,
};

// LA FENÊTRE D'APPLICATION — l'app ouverte au centre du Bureau, avec sa
// barre de titre et son bouton fermer.
export default function BureauAppWindow({ appId, onClose }) {
  const app = BUREAU_APPS.find((a) => a.id === appId);
  const Content = APP_CONTENT[appId];
  if (!app || !Content) return null;

  return (
    <section
      className="dark overflow-hidden rounded-2xl border border-white/12 bg-background text-foreground"
      aria-label={`Application ${app.label}`}
    >
      <div className="flex items-center justify-between border-b border-white/10 bg-white/[0.03] px-4 py-2.5">
        <p className="inline-flex items-center gap-2 font-mono text-[10px] font-semibold uppercase tracking-[0.24em] text-white/50">
          <app.icon className="h-3.5 w-3.5" style={{ color: app.color }} strokeWidth={1.6} />
          {app.label}
        </p>
        <button
          type="button"
          onClick={onClose}
          aria-label={`Fermer ${app.label}`}
          className="rounded-full p-1.5 text-white/40 hover:bg-white/10 hover:text-white"
        >
          <X className="h-4 w-4" />
        </button>
      </div>
      <div className="p-4 sm:p-6">
        <Content />
      </div>
    </section>
  );
}