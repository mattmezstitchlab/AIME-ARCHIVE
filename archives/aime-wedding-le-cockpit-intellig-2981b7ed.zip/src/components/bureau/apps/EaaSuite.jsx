import { useState } from "react";
import { ShieldCheck, Orbit, Clapperboard } from "lucide-react";
import EaaAuditTab from "@/components/gallery/EaaAuditTab";
import AbsorbeurSection from "@/components/gallery/AbsorbeurSection";
import ScenarioGenerator from "@/components/gallery/ScenarioGenerator";

// LA PIPELINE FUSIONNÉE — l'Absorbeur et le Scénario deviennent des ONGLETS
// de la pipeline EAA : un seul outil, trois temps (absorber → auditer → raconter).
const ONGLETS = [
  { id: "pipeline", label: "Pipeline EAA", icon: ShieldCheck, color: "#34d399", Content: EaaAuditTab },
  { id: "absorbeur", label: "L'Absorbeur", icon: Orbit, color: "#c084fc", Content: AbsorbeurSection },
  { id: "scenario", label: "Scénario en visuels", icon: Clapperboard, color: "#f59e0b", Content: ScenarioGenerator },
];

export default function EaaSuite() {
  const [tab, setTab] = useState("pipeline");
  const actif = ONGLETS.find((o) => o.id === tab);

  return (
    <div>
      <div className="mb-4 inline-flex items-center gap-1 rounded-full border border-white/10 bg-white/[0.04] p-1">
        {ONGLETS.map((o) => (
          <button
            key={o.id}
            type="button"
            onClick={() => setTab(o.id)}
            className={`inline-flex h-8 items-center gap-1.5 rounded-full px-3.5 text-[11.5px] font-semibold transition-colors ${
              tab === o.id ? "bg-white text-black" : "text-white/60 hover:text-white"
            }`}
          >
            <o.icon className="h-3.5 w-3.5" style={{ color: tab === o.id ? o.color : undefined }} />
            {o.label}
          </button>
        ))}
      </div>
      <actif.Content />
    </div>
  );
}