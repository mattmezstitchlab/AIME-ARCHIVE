import { useState } from "react";
import { Folder, FileText, ChevronRight, ChevronDown, LayoutGrid } from "lucide-react";

// LA COLONNE FINE — l'arborescence des dossiers de projet, sobre sur noir.
export default function BureauArbrePanel({ projects, activeId, onSelect }) {
  const [ouverts, setOuverts] = useState({});

  return (
    <nav aria-label="Dossiers de projet" className="text-white/70">
      <button
        type="button"
        onClick={() => onSelect(null)}
        className={`flex w-full items-center gap-2 rounded-lg px-2.5 py-1.5 text-[12.5px] font-medium transition ${
          !activeId ? "bg-white text-black" : "text-white/60 hover:bg-white/10"
        }`}
      >
        <LayoutGrid className="h-3.5 w-3.5" /> Le Canevas
      </button>

      <p className="mt-4 flex items-center justify-between px-2.5 font-mono text-[9px] font-semibold uppercase tracking-[0.2em] text-white/30">
        Projets <span>{projects.length}</span>
      </p>
      <div className="mt-1.5 space-y-0.5">
        {projects.map((p) => {
          const facets = p.facets || [];
          const ouvert = ouverts[p.id];
          return (
            <div key={p.id}>
              <div
                className={`flex items-center gap-1 rounded-lg px-1 py-1.5 transition ${
                  activeId === p.id ? "bg-white text-black" : "text-white/60 hover:bg-white/10"
                }`}
              >
                <button
                  type="button"
                  onClick={() => setOuverts((o) => ({ ...o, [p.id]: !o[p.id] }))}
                  aria-label={ouvert ? "Replier" : "Déplier"}
                  className={`shrink-0 rounded p-0.5 ${activeId === p.id ? "text-black/50" : "text-white/30"} hover:opacity-70`}
                >
                  {facets.length > 0 ? (
                    ouvert ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />
                  ) : (
                    <span className="block h-3 w-3" />
                  )}
                </button>
                <button
                  type="button"
                  onClick={() => onSelect(p.id)}
                  className="flex min-w-0 flex-1 items-center gap-2 text-left text-[12.5px]"
                >
                  <Folder className={`h-3.5 w-3.5 shrink-0 ${activeId === p.id ? "text-black/60" : "text-white/35"}`} />
                  <span className="truncate">{p.project_title || p.intent}</span>
                </button>
              </div>
              {ouvert &&
                facets.map((f) => (
                  <button
                    key={f.key}
                    type="button"
                    onClick={() => onSelect(p.id)}
                    className="flex w-full items-center gap-2 rounded-lg py-1 pl-8 pr-2 text-left text-[12px] text-white/45 transition hover:bg-white/10"
                  >
                    <FileText className="h-3 w-3 shrink-0 text-white/25" />
                    <span className="truncate">{f.label}</span>
                  </button>
                ))}
            </div>
          );
        })}
        {projects.length === 0 && <p className="px-2.5 py-2 text-[11px] text-white/30">Aucun projet.</p>}
      </div>
    </nav>
  );
}