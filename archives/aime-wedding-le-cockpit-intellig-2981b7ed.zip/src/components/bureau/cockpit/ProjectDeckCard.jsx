import { X } from "lucide-react";

// Une carte projet façon Startup : type en surtitre, titre, intro de
// Ripple, jauge de progression. Cliquer ouvre le projet dans le cockpit.
export default function ProjectDeckCard({ project, active, onSelect, onDelete }) {
  const questions = project.questions || [];
  const answered = questions.filter((q) => {
    const v = project.answers?.[q.id];
    return v !== undefined && v !== null && v !== "";
  }).length;
  const facetDone = Object.values(project.facet_values || {}).reduce(
    (n, obj) => n + Object.values(obj || {}).filter((v) => v !== "" && v != null).length,
    0
  );
  const totalDone = answered + facetDone;

  return (
    <div
      className={`group relative rounded-2xl border p-4 text-left transition-all ${
        active
          ? "border-[#c9a96e] bg-[#c9a96e]/[0.07]"
          : "border-white/10 bg-white/[0.03] hover:border-white/30"
      }`}
    >
      <button type="button" onClick={onSelect} className="block w-full text-left" aria-pressed={active}>
        <p className="font-mono text-[9px] font-semibold uppercase tracking-[0.2em] text-[#c9a96e]">
          {project.project_type || "Projet"}
        </p>
        <h3 className="mt-1.5 font-heading text-[17px] font-light leading-snug text-white">
          {project.project_title || project.intent}
        </h3>
        {project.intro && (
          <p className="mt-1.5 line-clamp-2 text-[11px] leading-4 text-white/40">{project.intro}</p>
        )}
        <div className="mt-3 flex items-center justify-between">
          <span className="rounded-full bg-white/10 px-2 py-0.5 font-mono text-[10px] text-white/60">
            {answered}/{questions.length} · {totalDone} réglages
          </span>
          <span className="text-[10px] text-white/30">{active ? "Ouvert" : "Ouvrir →"}</span>
        </div>
        <span className="mt-2 block h-1 overflow-hidden rounded-full bg-white/10" aria-hidden="true">
          <span
            className="block h-full rounded-full bg-[#c9a96e] transition-all"
            style={{ width: `${questions.length ? (answered / questions.length) * 100 : 0}%` }}
          />
        </span>
      </button>
      <button
        type="button"
        onClick={onDelete}
        aria-label={`Supprimer le projet ${project.project_title || project.intent}`}
        className="absolute right-2 top-2 rounded-full p-1 text-white/25 opacity-0 transition hover:bg-white/10 hover:text-white group-hover:opacity-100"
      >
        <X className="h-3.5 w-3.5" />
      </button>
    </div>
  );
}