import BureauStatsBand from "./BureauStatsBand";
import ProjectDeckCard from "./ProjectDeckCard";

// LE COCKPIT DES PROJETS — grammaire Startup appliquée au Bureau :
// stats en tête et les projets en grandes cartes. La création se fait
// depuis le bouton « Créer » du dock des Applications.
export default function ProjectDeck({ projects, activeId, onSelect, onDelete }) {
  const types = new Set(projects.map((p) => p.project_type).filter(Boolean));
  const totalDone = projects.reduce((n, p) => {
    const answered = Object.values(p.answers || {}).filter((v) => v !== "" && v != null).length;
    const facets = Object.values(p.facet_values || {}).reduce(
      (m, obj) => m + Object.values(obj || {}).filter((v) => v !== "" && v != null).length,
      0
    );
    return n + answered + facets;
  }, 0);

  return (
    <section aria-label="Mes projets AIME" className="space-y-3">
      <BureauStatsBand
        stats={[
          { value: projects.length, label: "Projets" },
          { value: types.size, label: "Familles explorées" },
          { value: totalDone, label: "Réglages faits" },
        ]}
      />

      {projects.length > 0 ? (
        <>
          <p className="font-mono text-[10px] font-semibold uppercase tracking-[0.24em] text-white/35">
            Mes projets
          </p>
          <div className="grid gap-3 sm:grid-cols-2">
            {projects.map((p) => (
              <ProjectDeckCard
                key={p.id}
                project={p}
                active={p.id === activeId}
                onSelect={() => onSelect(p.id === activeId ? null : p.id)}
                onDelete={() => onDelete(p.id)}
              />
            ))}
          </div>
        </>
      ) : (
        <p className="rounded-2xl border border-dashed border-white/15 px-4 py-6 text-center text-[12px] text-white/35">
          Aucun projet pour l'instant — cliquez « Créer » dans les Applications et dites à Ripple ce que vous voulez faire.
        </p>
      )}
    </section>
  );
}