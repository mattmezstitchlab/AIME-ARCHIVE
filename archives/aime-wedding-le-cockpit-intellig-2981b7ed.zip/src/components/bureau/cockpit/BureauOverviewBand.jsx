import { useEffect, useState } from "react";
import { Users, Wallet, Euro, Sun, Timer } from "lucide-react";

// LA LIGNE CAUSALE « OVERVIEW » — en haut du Bureau, à plat (pas de bandeau) :
// pictos simples, chiffres qui CLIGNOTENT en couleur quand ils bougent
// ensemble (l'impact causal), et le compte à rebours du Jour J.
const PRIX_PAR_INVITE = 145;

export default function BureauOverviewBand() {
  const [invites, setInvites] = useState(86);
  const [pulse, setPulse] = useState(false);

  // Démo causale : un invité confirme toutes les ~8s → tout se propage.
  useEffect(() => {
    const t = setInterval(() => {
      setInvites((n) => n + 1);
      setPulse(true);
      setTimeout(() => setPulse(false), 1600);
    }, 8000);
    return () => clearInterval(t);
  }, []);

  const budget = invites * PRIX_PAR_INVITE + 12000;
  const jourJ = new Date("2026-09-12T15:00:00");
  const diff = Math.max(0, jourJ - new Date());
  const jours = Math.floor(diff / 86400000);
  const heures = Math.floor((diff % 86400000) / 3600000);

  const stats = [
    { icon: Users, label: "Invités", value: invites, live: true, causal: true },
    { icon: Wallet, label: "Budget", value: `${budget.toLocaleString("fr-FR")} €`, causal: true },
    { icon: Euro, label: "Par invité", value: `${PRIX_PAR_INVITE} €` },
    { icon: Sun, label: "Météo Jour J", value: "24°" },
    { icon: Timer, label: "Compte à rebours", value: `${jours} j ${heures} h` },
  ];

  return (
    <section aria-label="Vue d'ensemble causale du mariage" className="px-1">
      <div className="mb-4 flex items-baseline justify-between border-b border-white/10 pb-3">
        <h2 className="font-heading text-[16px] font-semibold tracking-tight text-white">Overview</h2>
        <span className="font-mono text-[9px] font-semibold uppercase tracking-[0.18em] text-white/40">
          Léa & Tom · 12 sept. 2026
        </span>
      </div>
      <div className="grid grid-cols-2 gap-x-4 gap-y-5 sm:grid-cols-5">
        {stats.map((s) => (
          <div key={s.label}>
            <p className="flex items-center gap-1.5 font-mono text-[9px] font-semibold uppercase tracking-[0.14em] text-white/40">
              <s.icon className="h-3 w-3 text-white/35" aria-hidden="true" />
              {s.label}
              {s.live && <span className="h-1.5 w-1.5 rounded-full bg-sky-400 animate-pulse" aria-hidden="true" />}
            </p>
            <p
              className={`mt-1 font-heading text-[21px] font-semibold transition-colors duration-700 ${
                pulse && s.causal ? "text-sky-300" : "text-white"
              }`}
            >
              {s.value}
            </p>
          </div>
        ))}
      </div>
    </section>
  );
}