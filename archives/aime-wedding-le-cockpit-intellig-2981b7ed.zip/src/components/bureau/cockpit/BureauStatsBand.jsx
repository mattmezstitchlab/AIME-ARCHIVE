// Le bandeau de stats du cockpit — même grammaire que la page Startup :
// gros chiffres, labels monospace, calculés sur VOS projets.
export default function BureauStatsBand({ stats }) {
  return (
    <div className="grid grid-cols-3 gap-px overflow-hidden rounded-2xl border border-white/10 bg-white/10">
      {stats.map((s) => (
        <div key={s.label} className="bg-[#0C0C0C] px-4 py-3.5 text-center">
          <p className="font-heading text-2xl font-light text-white">{s.value}</p>
          <p className="mt-0.5 font-mono text-[9px] font-semibold uppercase tracking-[0.18em] text-white/35">
            {s.label}
          </p>
        </div>
      ))}
    </div>
  );
}