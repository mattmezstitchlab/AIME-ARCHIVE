import { useState, useRef, useEffect } from "react";
import {
  Plus, Send, Globe, Upload, X, Loader2, Heart, CalendarDays, ShieldCheck,
  UserRound, History, Archive, Briefcase, FileSignature, PanelsTopLeft, LayoutTemplate,
} from "lucide-react";
import { base44 } from "@/api/base44Client";
import AgentActivite from "./AgentActivite";

// ═══════════════════════════════════════════════════════════════════════════
// LA CONVERSATION DU POINT ZÉRO — sobre : pas de message d'accueil, le « + »
// ouvre LA LISTE de tout ce que le site sait faire (façon Manus), et on
// discute avec les agents (Ripple architecte, le Curateur pour la DA).
// ═══════════════════════════════════════════════════════════════════════════

const AGENTS = {
  ripple: { nom: "Ripple", role: "Architecte", color: "#38bdf8" },
  curateur: { nom: "Le Curateur", role: "Direction artistique", color: "#c084fc" },
};

// LA LISTE DES POSSIBILITÉS — chaque entrée amorce la conversation.
const SKILLS = [
  { icon: Heart, label: "Organiser un mariage", seed: "Je veux organiser un mariage." },
  { icon: CalendarDays, label: "Créer un événement", seed: "Je veux organiser un événement." },
  { icon: PanelsTopLeft, label: "Créer un site web", seed: "Je veux créer un site web." },
  { icon: LayoutTemplate, label: "Mini-site · Wedding OS embarqué", action: "minisite" },
  { icon: ShieldCheck, label: "Audit accessibilité (EAA)", seed: "Je veux un audit d'accessibilité de mon site." },
  { icon: UserRound, label: "CV / Portrait", seed: "Je veux créer mon CV / mon portrait." },
  { icon: History, label: "Timeline de ma vie · Mémoire", seed: "Je veux construire la timeline de ma vie." },
  { icon: Archive, label: "Transmission", seed: "Je veux préparer une transmission — la mémoire de quelqu'un." },
  { icon: Briefcase, label: "Module intermittent·e", seed: "Je suis intermittent·e du spectacle : je veux gérer mon statut." },
  { icon: FileSignature, label: "Générer un contrat", seed: "Je veux générer un contrat." },
];

const CAPACITES = `Ce que la plateforme AIME sait faire (tu guides l'utilisateur vers la bonne action) :
1. CRÉER UN PROJET — mariage, événement, site web, CV… depuis une description, une URL ou un fichier : Ripple génère un onboarding (10 questions rangées par dossiers), puis des cartes recto (infos) / verso (réglages), assemblables sur le Grand Canevas.
2. PIPELINE EAA — audit d'accessibilité European Accessibility Act d'un site (URL requise) : failles, guide de remédiation, refonte guidée.
3. DIRECTION ARTISTIQUE — le Curateur propose style, palette de couleurs (hex), typographies : ces choix alimentent les réglages verso des cartes pour la génération détaillée du pipeline.
4. TIMELINE DE VIE & TRANSMISSION — poser les moments d'une vie (avant/maintenant/après), la mémoire.
5. MODULE INTERMITTENT — statuts, heures, obligations des artistes.
6. CONTRATS — générer des contrats d'alignement (travail, union, transmission…).
7. REGISTRE — les pages profil publiques des personnes et métiers.`;

export default function PointZeroConversation({ onGenerated, onOpenApp, onMiniSite }) {
  const [messages, setMessages] = useState([]);
  const [texte, setTexte] = useState("");
  const [attache, setAttache] = useState(null); // { type: "url"|"fichier", valeur, label }
  const [menuPlus, setMenuPlus] = useState(false);
  const [urlSaisie, setUrlSaisie] = useState("");
  const [loading, setLoading] = useState(false);
  const [activite, setActivite] = useState(null);
  const actTimers = useRef([]);
  const fileRef = useRef(null);
  const finRef = useRef(null);

  useEffect(() => {
    finRef.current?.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }, [messages, loading]);

  // Les tuiles « Créations » du centre amorcent la conversation ici.
  useEffect(() => {
    const h = (e) => { if (e.detail?.seed) setTexte(e.detail.seed); };
    window.addEventListener("aime-pointzero-seed", h);
    return () => window.removeEventListener("aime-pointzero-seed", h);
  }, []);

  const joindreFichier = async (f) => {
    if (!f) return;
    const { file_url } = await base44.integrations.Core.UploadFile({ file: f });
    setAttache({ type: "fichier", valeur: file_url, label: f.name });
    setMenuPlus(false);
  };

  const envoyer = async () => {
    const contenu = texte.trim();
    if ((!contenu && !attache) || loading) return;
    const userMsg = { user: true, reply: contenu || `(pièce jointe : ${attache?.label})`, attache };
    const hist = [...messages, userMsg];
    setMessages(hist);
    setTexte("");
    setLoading(true);

    // Le fil d'activité de l'assistant — les étapes apparaissent en direct.
    actTimers.current.forEach(clearTimeout);
    const pousser = (label) =>
      setActivite((a) => a && { ...a, etapes: [...a.etapes.map((e) => (e.fin ? e : { ...e, fin: Date.now() })), { label, debut: Date.now() }] });
    setActivite({ enCours: true, pensee: null, etapes: [{ label: "Analyse de votre demande", debut: Date.now() }] });
    actTimers.current = [
      setTimeout(() => setActivite((a) => a && { ...a, pensee: "Je regarde tout ce qui est possible sur la plateforme pour répondre au mieux à cette demande." }), 900),
      setTimeout(() => pousser(attache?.type === "url" ? "Exploration du site joint" : attache ? "Lecture du fichier joint" : "Choix de l'agent le plus pertinent"), 1800),
      setTimeout(() => pousser("Préparation du plan de réponse"), 3800),
    ];

    const histTexte = hist
      .map((m) => `${m.user ? "UTILISATEUR" : (AGENTS[m.agent]?.nom || "AGENT").toUpperCase()}: ${m.reply}`)
      .join("\n");

    const res = await base44.integrations.Core.InvokeLLM({
      prompt: `Tu animes le Point Zéro de la plateforme AIME, en français, avec DEUX agents :
- "ripple" : l'architecte — comprend l'intention, pose les bonnes questions, décide quand créer le projet.
- "curateur" : la direction artistique — propose style, palette (couleurs hex), typographies quand on parle d'esthétique.

${CAPACITES}

${attache ? `PIÈCE JOINTE de l'utilisateur : ${attache.type === "url" ? `l'URL ${attache.valeur} (analyse ce site réellement)` : `le fichier ${attache.label}`}.` : ""}

CONVERSATION :
${histTexte}

Réponds comme l'agent le plus pertinent. Sois chaleureux, concret, bref (3-5 phrases max).
- Si l'utilisateur veut un audit d'accessibilité ET qu'une URL est jointe : action="pipeline_eaa".
- Si tu as assez compris le besoin pour générer le projet : action="creer_projet" et remplis "project" (titre court, type, intro chaleureuse, EXACTEMENT 10 questions concrètes rangées par dossier — types "text", "number", "date" ou "select" avec 3-5 options).
- Si tu proposes une direction artistique : remplis "direction" (style_name, palette de 4-5 hex, typo_titres, typo_texte).
- Sinon action=null : continue de guider.`,
      add_context_from_internet: attache?.type === "url",
      file_urls: attache?.type === "fichier" ? [attache.valeur] : undefined,
      response_json_schema: {
        type: "object",
        properties: {
          agent: { type: "string" },
          reply: { type: "string" },
          action: { type: "string" },
          direction: {
            type: "object",
            properties: {
              style_name: { type: "string" },
              palette: { type: "array", items: { type: "string" } },
              typo_titres: { type: "string" },
              typo_texte: { type: "string" },
            },
          },
          project: {
            type: "object",
            properties: {
              project_title: { type: "string" },
              project_type: { type: "string" },
              intro: { type: "string" },
              questions: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    id: { type: "string" },
                    label: { type: "string" },
                    hint: { type: "string" },
                    folder: { type: "string" },
                    type: { type: "string" },
                    options: { type: "array", items: { type: "string" } },
                  },
                },
              },
            },
          },
        },
      },
    });

    setLoading(false);
    // On clôt le fil d'activité : toutes les étapes se cochent avec leur durée réelle.
    actTimers.current.forEach(clearTimeout);
    setActivite((a) => {
      if (!a) return a;
      const etapes = a.etapes.map((e) => (e.fin ? e : { ...e, fin: Date.now() }));
      const extra =
        res.action === "creer_projet" ? "Projet composé — questions et dossiers prêts" :
        res.action === "pipeline_eaa" ? "Ouverture du pipeline d'audit EAA" :
        res.direction?.palette?.length ? "Direction artistique proposée" : null;
      if (extra) etapes.push({ label: extra, debut: Date.now(), fin: Date.now() });
      return { ...a, enCours: false, etapes };
    });
    setMessages((ms) => [...ms, res]);

    if (res.action === "pipeline_eaa" && attache?.type === "url") {
      localStorage.setItem("aime-pointzero-url", JSON.stringify({ url: attache.valeur, intent: "audit", at: Date.now() }));
      onOpenApp("eaa");
      return;
    }
    if (res.action === "creer_projet" && res.project?.questions?.length) {
      onGenerated({
        intent: contenu || attache?.label || "Projet Point Zéro",
        complexity: 2,
        answers: {},
        direction: res.direction || null,
        ...res.project,
      });
      return;
    }
    setAttache(null);
  };

  return (
    <div>
      {/* LE FIL — vide au départ : on parle, ou on choisit dans le « + ». */}
      {messages.length > 0 && (
        <div className="mb-4 max-h-[38vh] space-y-3 overflow-y-auto pr-1">
          {messages.map((m, i) =>
            m.user ? (
              <div key={i} className="flex justify-end">
                <div className="max-w-[85%] rounded-2xl rounded-br-md bg-white/10 px-4 py-2.5 text-[13px] leading-relaxed text-white/90">
                  {m.reply}
                  {m.attache && (
                    <span className="mt-1.5 flex items-center gap-1.5 font-mono text-[9.5px] uppercase tracking-[0.12em] text-white/45">
                      {m.attache.type === "url" ? <Globe className="h-3 w-3" /> : <Upload className="h-3 w-3" />}
                      {m.attache.label}
                    </span>
                  )}
                </div>
              </div>
            ) : (
              <div key={i} className="flex justify-start">
                <div className="max-w-[85%]">
                  <p className="mb-1 font-mono text-[9px] font-semibold uppercase tracking-[0.2em]" style={{ color: AGENTS[m.agent]?.color || "#38bdf8" }}>
                    {AGENTS[m.agent]?.nom || "Ripple"} · {AGENTS[m.agent]?.role || "Architecte"}
                  </p>
                  <div className="rounded-2xl rounded-bl-md border border-white/10 bg-white/[0.04] px-4 py-2.5 text-[13px] leading-relaxed text-white/85">
                    {m.reply}
                    {m.direction?.palette?.length > 0 && (
                      <div className="mt-3 rounded-xl border border-white/10 bg-black/30 p-3">
                        <p className="font-mono text-[9px] font-semibold uppercase tracking-[0.18em] text-white/45">
                          {m.direction.style_name || "Direction artistique"}
                        </p>
                        <div className="mt-2 flex gap-1.5">
                          {m.direction.palette.map((c, j) => (
                            <span key={j} className="h-7 w-7 rounded-md border border-white/15" style={{ background: c }} title={c} />
                          ))}
                        </div>
                        {(m.direction.typo_titres || m.direction.typo_texte) && (
                          <p className="mt-2 text-[11px] text-white/55">
                            Titres : <span className="text-white/85">{m.direction.typo_titres || "—"}</span> · Texte :{" "}
                            <span className="text-white/85">{m.direction.typo_texte || "—"}</span>
                          </p>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )
          )}
          {activite && <AgentActivite activite={activite} />}
          <div ref={finRef} />
        </div>
      )}

      {/* LA PIÈCE JOINTE en attente — sobre. */}
      {attache && (
        <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/[0.06] px-3 py-1.5 text-[11px] text-white/75">
          {attache.type === "url" ? <Globe className="h-3 w-3" /> : <Upload className="h-3 w-3" />}
          <span className="max-w-[220px] truncate">{attache.label}</span>
          <button type="button" onClick={() => setAttache(null)} aria-label="Retirer la pièce jointe" className="text-white/45 hover:text-white">
            <X className="h-3 w-3" />
          </button>
        </div>
      )}

      {/* LE MENU « + » — la liste de TOUT ce qu'on peut faire, façon Manus. */}
      {menuPlus && (
        <div className="mb-3 rounded-xl border border-white/12 bg-black/50 p-2">
          <p className="px-2 pb-1 pt-1 font-mono text-[8.5px] font-semibold uppercase tracking-[0.2em] text-white/35">
            Que voulez-vous faire ?
          </p>
          <div className="grid sm:grid-cols-2">
            {SKILLS.map((s) => (
              <button
                key={s.label}
                type="button"
                onClick={() => { setMenuPlus(false); if (s.action === "minisite") { onMiniSite?.(); return; } setTexte(s.seed); }}
                className="flex items-center gap-2.5 rounded-lg px-2.5 py-2 text-left text-[12.5px] text-white/75 transition hover:bg-white/10 hover:text-white"
              >
                <s.icon className="h-3.5 w-3.5 shrink-0 text-white/45" />
                {s.label}
              </button>
            ))}
          </div>
          <div className="mt-1.5 border-t border-white/10 pt-2">
            <div className="flex gap-1.5 px-1">
              <input
                type="url"
                value={urlSaisie}
                onChange={(e) => setUrlSaisie(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter" && urlSaisie.trim()) { setAttache({ type: "url", valeur: urlSaisie.trim(), label: urlSaisie.trim() }); setUrlSaisie(""); setMenuPlus(false); } }}
                placeholder="Joindre une URL — https://…"
                className="min-w-0 flex-1 rounded-lg border border-white/12 bg-white/[0.04] px-3 py-2 font-mono text-[12px] text-white placeholder:text-white/25 focus:border-white/40 focus:outline-none"
              />
              <button
                type="button"
                disabled={!urlSaisie.trim()}
                onClick={() => { setAttache({ type: "url", valeur: urlSaisie.trim(), label: urlSaisie.trim() }); setUrlSaisie(""); setMenuPlus(false); }}
                className="rounded-lg bg-white px-3 py-2 text-[12px] font-semibold text-black transition hover:bg-white/85 disabled:opacity-30"
              >
                Joindre
              </button>
              <button
                type="button"
                onClick={() => fileRef.current?.click()}
                className="inline-flex items-center gap-1.5 rounded-lg border border-white/15 px-3 py-2 text-[12px] font-semibold text-white/75 transition hover:border-white/40 hover:text-white"
              >
                <Upload className="h-3.5 w-3.5" /> Fichier
              </button>
              <input ref={fileRef} type="file" className="hidden" onChange={(e) => joindreFichier(e.target.files?.[0])} />
            </div>
          </div>
        </div>
      )}

      {/* LE GRAND CHAMP — le « + », la conversation, l'envoi. Tout en blanc. */}
      <div className="flex items-end gap-2">
        <button
          type="button"
          onClick={() => setMenuPlus((v) => !v)}
          aria-expanded={menuPlus}
          aria-label="Tout ce qu'on peut faire — et joindre une URL ou un fichier"
          title="Tout ce qu'on peut faire"
          className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl transition ${
            menuPlus ? "bg-white text-black" : "border border-white/20 text-white/70 hover:border-white/50 hover:text-white"
          }`}
        >
          <Plus className="h-4 w-4" />
        </button>
        <textarea
          value={texte}
          onChange={(e) => setTexte(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); envoyer(); } }}
          rows={2}
          placeholder="Expliquez ce que vous voulez faire — ou appuyez sur + pour voir tout ce qui est possible…"
          className="min-h-[44px] flex-1 resize-none rounded-xl border border-white/15 bg-black/40 px-4 py-2.5 text-[13px] text-white placeholder:text-white/30 focus:border-white/50 focus:outline-none"
        />
        <button
          type="button"
          onClick={envoyer}
          disabled={loading || (!texte.trim() && !attache)}
          aria-label="Envoyer"
          className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-white text-black transition hover:bg-white/85 disabled:opacity-30"
        >
          <Send className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}