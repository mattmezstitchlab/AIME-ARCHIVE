import { useState } from "react";
import { FolderPlus, Upload, MessageCircleQuestion, Sparkles } from "lucide-react";
import PointZeroImport from "@/components/bureau/pointzero/PointZeroImport";
import PointZeroQuestions from "@/components/bureau/pointzero/PointZeroQuestions";
import RippleIntentBar from "@/components/bureau/ripple/RippleIntentBar";

// ─────────────────────────────────────────────────────────────────────────
// LE POINT ZÉRO — au centre du Bureau. La pastille du moteur radial devenue
// bouton : on y dépose des fichiers (toutes extensions) ou on répond aux
// questions manquantes ; le moteur trie et propage tout dans les dossiers
// de l'arbre et le verso des cartes de l'atelier.
// ─────────────────────────────────────────────────────────────────────────

export default function PointZeroHub({ values, projects, onPropagated, onGenerated, compact = false }) {
  const [panel, setPanel] = useState(compact ? "import" : null); // null | "import" | "generer" | "questions"

  return (
    <section className={`text-center ${compact ? "" : "my-10"}`}>
      {/* La pastille Point Zéro — masquée en mode compact (le moteur radial la porte déjà) */}
      {!compact && (
        <>
          <button
            type="button"
            onClick={() => setPanel((p) => (p ? null : "import"))}
            aria-label="Ouvrir le Point Zéro"
            className={`mx-auto flex h-28 w-28 flex-col items-center justify-center gap-1.5 rounded-full bg-[#f2efe9] text-black shadow-[0_0_50px_rgba(255,255,255,0.12)] transition-transform hover:scale-[1.04] ${
              panel ? "ring-4 ring-white/20" : ""
            }`}
          >
            <FolderPlus className="h-5 w-5 text-black/70" strokeWidth={1.7} />
            <span className="font-mono text-[9px] font-semibold uppercase tracking-[0.22em] text-[#a8894f]">
              Point Zéro
            </span>
          </button>
          <p className="mt-3 text-[12px] text-white/40">
            Déposez, répondez — le moteur trie et propage dans vos dossiers.
          </p>
        </>
      )}

      {/* Les deux entrées du moteur */}
      <div className="mt-5 inline-flex items-center gap-1 rounded-full border border-white/10 bg-white/[0.04] p-1">
        {[
          { key: "import", label: "Importer", icon: Upload },
          // GÉNÉRER — le cœur : décrire un projet, Ripple analyse, onboarde et fusionne.
          ...(onGenerated ? [{ key: "generer", label: "Générer", icon: Sparkles }] : []),
          { key: "questions", label: "Compléter les infos", icon: MessageCircleQuestion },
        ].map((t) => {
          const Icon = t.icon;
          const active = panel === t.key;
          return (
            <button
              key={t.key}
              type="button"
              onClick={() => setPanel(active ? null : t.key)}
              className={`inline-flex h-9 items-center gap-1.5 rounded-full px-4 text-[12px] font-semibold transition-colors ${
                active ? "bg-white text-black" : "text-white/60 hover:text-white"
              }`}
            >
              <Icon className="h-3.5 w-3.5" /> {t.label}
            </button>
          );
        })}
      </div>

      {panel === "import" && (
        <div className="mt-6">
          <PointZeroImport onPropagated={onPropagated} />
        </div>
      )}
      {panel === "generer" && onGenerated && (
        <div className="mt-6 text-left ripple-wave">
          <RippleIntentBar onGenerated={onGenerated} />
        </div>
      )}
      {panel === "questions" && (
        <div className="mt-6">
          <PointZeroQuestions values={values} projects={projects} onPropagated={onPropagated} />
        </div>
      )}
    </section>
  );
}