import { Link } from "react-router-dom";
import { Trash2 } from "lucide-react";

// L'ÉCRAN DU + — sous la conversation Point Zéro : vos cartes générées
// (le concept), et les trois essentiels du site. Rien d'autre.
const ESSENTIELS = [
  { to: "/wedding-os", label: "Wedding OS", desc: "Le cockpit chat — chaque rôle a son agent." },
  { to: "/jour-j", label: "Cadran Causal", desc: "Le Jour J orchestré en temps réel." },
  { to: "/registre", label: "Le Registre", desc: "Les cartes de toutes les personnes." },
];

export default function PointZeroAcces({ projects = [], onOpen, onDelete }) {
  return (
    <div className="space-y-8">
      {projects.length > 0 && (
        <div>
          <p className="mb-3 font-mono text-[9px] font-semibold uppercase tracking-[0.26em] text-white/40">
            Vos cartes
          </p>
          <div className="grid gap-3 sm:grid-cols-3">
            {projects.slice(0, 6).map((p) => {
              const img = (p.facets || []).find((f) => f.image_url)?.image_url;
              return (
                <div key={p.id} className="group relative">
                  {onDelete && (
                    <button
                      type="button"
                      onClick={() => onDelete(p.id)}
                      aria-label={`Supprimer la carte ${p.project_title || p.intent}`}
                      className="absolute right-2 top-2 z-10 grid h-7 w-7 place-items-center rounded-full bg-black/55 text-white/60 backdrop-blur transition hover:bg-black/80 hover:text-red-400"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  )}
                <button
                  type="button"
                  onClick={() => onOpen(p.id)}
                  className="relative block h-40 w-full overflow-hidden rounded-2xl border border-white/12 text-left transition-colors hover:border-white/30"
                >
                  {img ? (
                    <img src={img} alt="" className="absolute inset-0 h-full w-full object-cover" />
                  ) : (
                    <span
                      className="absolute inset-0"
                      style={{ background: `linear-gradient(160deg, ${(p.direction?.palette?.[0] || "#9ca3af")}44 0%, #0d0d0d 75%)` }}
                      aria-hidden="true"
                    />
                  )}
                  <span className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent" aria-hidden="true" />
                  <span className="relative flex h-full flex-col justify-end p-3.5">
                    <span className="font-mono text-[8px] font-semibold uppercase tracking-[0.24em] text-white/55">
                      {p.project_type || "Projet"}
                    </span>
                    <span className="mt-0.5 font-heading text-[16px] font-semibold leading-tight text-white">
                      {p.project_title || p.intent}
                    </span>
                  </span>
                </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      <div>
        <p className="mb-3 font-mono text-[9px] font-semibold uppercase tracking-[0.26em] text-white/40">
          Les essentiels
        </p>
        <div className="grid gap-3 sm:grid-cols-3">
          {ESSENTIELS.map((e) => (
            <Link
              key={e.to}
              to={e.to}
              className="rounded-2xl border border-white/12 bg-white/[0.03] p-4 transition-colors hover:border-white/30 hover:bg-white/[0.06]"
            >
              <p className="font-heading text-[15px] font-semibold text-white">{e.label}</p>
              <p className="mt-1 text-[11.5px] leading-relaxed text-white/50">{e.desc}</p>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}