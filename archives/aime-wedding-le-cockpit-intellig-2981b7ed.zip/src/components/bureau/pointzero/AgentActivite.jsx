import { useEffect, useState } from "react";
import { Check, Loader2 } from "lucide-react";

// LE FIL D'ACTIVITÉ DE L'AGENT — façon Framer : la pensée en cours,
// puis les étapes qui apparaissent, se chronomètrent et se cochent en direct.
export default function AgentActivite({ activite }) {
  const [, setTick] = useState(0);
  useEffect(() => {
    if (!activite?.enCours) return;
    const id = setInterval(() => setTick((t) => t + 1), 150);
    return () => clearInterval(id);
  }, [activite?.enCours]);

  if (!activite) return null;
  return (
    <div className="rounded-xl border border-white/10 bg-white/[0.03] px-3.5 py-3">
      {activite.pensee && (
        <div className="mb-2">
          <p className="font-mono text-[8.5px] font-semibold uppercase tracking-[0.2em] text-white/30">Réflexion</p>
          <p className="mt-0.5 text-[11.5px] leading-relaxed text-white/60">{activite.pensee}</p>
        </div>
      )}
      {activite.etapes.map((e, i) => {
        const enCours = !e.fin && activite.enCours;
        const duree = e.fin ? ((e.fin - e.debut) / 1000).toFixed(1) : Math.max(1, Math.round((Date.now() - e.debut) / 1000));
        return (
          <div key={i} className="flex items-center gap-2 py-[3px]">
            {enCours ? (
              <Loader2 className="h-3 w-3 shrink-0 animate-spin text-white/40" />
            ) : (
              <Check className="h-3 w-3 shrink-0 text-[#C9A96E]" />
            )}
            <span className={`flex-1 text-[11.5px] ${enCours ? "text-white/80" : "text-white/45"}`}>{e.label}</span>
            <span className="font-mono text-[9px] text-white/30">{duree}s</span>
          </div>
        );
      })}
    </div>
  );
}