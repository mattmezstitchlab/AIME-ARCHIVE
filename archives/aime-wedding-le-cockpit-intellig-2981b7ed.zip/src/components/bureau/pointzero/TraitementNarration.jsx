import { useEffect, useRef } from "react";
import { Sparkles } from "lucide-react";

// LA VOIX DE RIPPLE — les phrases du traitement, affichées une à une comme
// un Wide Search : c'est la mémorisation ET l'explication de ce que le site
// fait réellement.
export default function TraitementNarration({ phrases }) {
  const endRef = useRef(null);
  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }, [phrases.length]);

  if (!phrases.length) return null;
  return (
    <div className="max-h-44 space-y-1.5 overflow-y-auto scrollbar-hide rounded-xl border border-white/10 bg-black/40 p-3 text-left" aria-live="polite">
      {phrases.map((p, i) => {
        const etape = p.startsWith("ÉTAPE");
        const last = i === phrases.length - 1;
        return (
          <p
            key={i}
            className={`ripple-wave flex gap-2 text-[12px] leading-5 ${
              etape ? "font-semibold text-[#c9a96e]" : last ? "text-white/85" : "text-white/50"
            }`}
          >
            <Sparkles className="mt-0.5 h-3 w-3 shrink-0 text-[#c9a96e]/60" strokeWidth={1.6} />
            <span>{p}</span>
          </p>
        );
      })}
      <div ref={endRef} />
    </div>
  );
}