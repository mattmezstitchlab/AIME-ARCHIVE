import { useState } from "react";
import { Check, SkipForward, Sparkles, GitBranch } from "lucide-react";
import { buildInfoQueue, propagateInfo } from "@/lib/bureau/infoTruth";

// Les questions du Point Zéro — la SOURCE DE VÉRITÉ : toutes les infos
// manquantes du mariage ET des projets Ripple, une par une. Une info donnée
// une seule fois se propage vers toutes les demandes identiques (causal).
export default function PointZeroQuestions({ values, projects, onPropagated }) {
  const [queue, setQueue] = useState(() => buildInfoQueue(values, projects));
  const [draft, setDraft] = useState("");
  const [saving, setSaving] = useState(false);
  const [lastSaved, setLastSaved] = useState(null);

  const current = queue[0];

  if (!current) {
    return (
      <div className="mx-auto max-w-md rounded-2xl border border-white/10 bg-white/[0.03] p-6 text-center">
        <Sparkles className="mx-auto h-5 w-5 text-[#c9a96e]" />
        <p className="mt-2 text-[13px] text-white/70">
          Tout est renseigné — le Point Zéro n'a plus de question pour l'instant.
        </p>
      </div>
    );
  }

  const linkedCount = current.linked.length;

  const advance = () => {
    setQueue((q) => q.slice(1));
    setDraft("");
  };

  const validate = async () => {
    if (draft === "" || saving) return;
    const value =
      current.type === "list"
        ? draft.split(",").map((s) => s.trim()).filter(Boolean)
        : current.type === "money" || current.type === "number"
          ? Number(draft)
          : draft;
    setSaving(true);
    const destinations = await propagateInfo(current, value, projects);
    setSaving(false);
    setLastSaved({ label: current.label, destinations });
    onPropagated?.();
    advance();
  };

  const inputClass =
    "w-full rounded-lg border border-white/15 bg-black px-3 py-2.5 text-sm text-white outline-none focus:border-white/40";

  return (
    <div className="mx-auto w-full max-w-md">
      <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
        <p className="font-mono text-[10px] font-semibold uppercase tracking-[0.22em] text-white/40">
          {current.group} · {queue.length} restante{queue.length > 1 ? "s" : ""}
        </p>
        <p className="mt-2 font-heading text-[16px] font-semibold text-white">{current.label}</p>
        {linkedCount > 0 && (
          <p className="mt-1.5 inline-flex items-center gap-1.5 rounded-full bg-[#c9a96e]/15 px-2.5 py-1 font-mono text-[10px] text-[#c9a96e]">
            <GitBranch className="h-3 w-3" />
            Aussi demandée {linkedCount} fois ailleurs — une réponse remplit tout
          </p>
        )}

        <div className="mt-4">
          {current.options?.length ? (
            <select
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              className={inputClass}
              style={{ colorScheme: "dark" }}
            >
              <option value="">Choisir…</option>
              {current.options.map((o) => (
                <option key={o.value} value={o.value}>{o.label}</option>
              ))}
            </select>
          ) : current.type === "textarea" ? (
            <textarea
              rows={3}
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              placeholder={current.placeholder || ""}
              className={inputClass}
            />
          ) : (
            <input
              type={current.type === "date" ? "date" : current.type === "money" || current.type === "number" ? "number" : "text"}
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              placeholder={current.type === "list" ? "Séparez par des virgules…" : current.placeholder || (current.unit ? `En ${current.unit}` : "")}
              className={inputClass}
              style={{ colorScheme: "dark" }}
            />
          )}
        </div>

        <div className="mt-4 flex items-center justify-between">
          <button
            type="button"
            onClick={advance}
            className="inline-flex items-center gap-1.5 text-[12px] text-white/40 hover:text-white"
          >
            <SkipForward className="h-3.5 w-3.5" /> Passer
          </button>
          <button
            type="button"
            onClick={validate}
            disabled={draft === "" || saving}
            className="inline-flex items-center gap-1.5 rounded-full bg-white px-4 py-2 text-[12px] font-semibold text-black transition enabled:hover:scale-[1.02] disabled:opacity-30"
          >
            <Check className="h-3.5 w-3.5" /> {saving ? "Propagation…" : "Propager"}
          </button>
        </div>
      </div>

      {lastSaved && (
        <p className="ripple-wave mt-3 text-center font-mono text-[10px] uppercase tracking-[0.18em] text-[#c9a96e]">
          Propagé → {lastSaved.destinations.slice(0, 2).join(" · ")}
          {lastSaved.destinations.length > 2 ? ` · +${lastSaved.destinations.length - 2}` : ""}
        </p>
      )}
    </div>
  );
}