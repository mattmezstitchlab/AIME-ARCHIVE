import { X } from "lucide-react";
import PointZeroConversation from "@/components/bureau/pointzero/PointZeroConversation";

// ═══════════════════════════════════════════════════════════════════════════
// LA FENÊTRE UNIQUE DU POINT ZÉRO — la conversation, rien d'autre.
// Le « + » du champ ouvre la liste de tout ce qu'on peut faire ; les infos
// manquantes se complètent DANS le projet, plus ici.
// ═══════════════════════════════════════════════════════════════════════════

export default function PointZeroFenetre({ onGenerated, onOpenApp, onClose }) {
  return (
    <div className="fixed inset-0 z-[70] flex items-start justify-center overflow-y-auto bg-black/70 p-4 pt-[7vh] backdrop-blur-sm" onClick={onClose}>
      <div
        className="w-full max-w-2xl rounded-2xl border border-white/15 bg-[#0e0e11] p-5 shadow-2xl"
        role="dialog"
        aria-label="Point Zéro"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-3">
          <span className="flex h-8 w-8 items-center justify-center rounded-full bg-[conic-gradient(from_0deg,#ff5f6d,#ffc371,#c9f76f,#38bdf8,#c084fc,#ff5f6d)] font-bold text-black">+</span>
          <p className="font-mono text-[10px] font-semibold uppercase tracking-[0.24em] text-white/60">Point Zéro</p>
          <button type="button" onClick={onClose} aria-label="Fermer la fenêtre Point Zéro" className="ml-auto rounded-lg p-1.5 text-white/50 transition hover:bg-white/10 hover:text-white">
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="mt-5">
          <PointZeroConversation onGenerated={onGenerated} onOpenApp={onOpenApp} />
        </div>
      </div>
    </div>
  );
}