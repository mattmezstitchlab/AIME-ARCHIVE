import ResultatElementCard from "./ResultatElementCard";

// LE RÉSULTAT AU CENTRE — chaque élément analysé devient une carte
// modifiable : couleur, taille, utilité. Rien n'est figé.
export default function TraitementResultats({ resultats }) {
  return (
    <section className="rounded-2xl border border-white/12 bg-black/40 p-4">
      <p className="font-mono text-[9.5px] font-semibold uppercase tracking-[0.22em] text-[#c9a96e]">
        Le résultat — modifiable, détail par détail
      </p>
      <p className="mt-1 text-[11px] text-white/45">
        Ripple a reconnu chaque pièce. Ajustez ce que vous voulez : la couleur, la taille, l'utilité — puis enregistrez.
      </p>
      <div className="mt-3 grid gap-2.5 sm:grid-cols-2">
        {resultats.map((el) => (
          <ResultatElementCard key={el.id} element={el} />
        ))}
      </div>
    </section>
  );
}