import { FolderInput, Check } from "lucide-react";
import { STATUT_LABEL, STATUT_COLOR, recalerCouleur } from "@/lib/bureau/rippleTraitement";

// LES PETITS BLOCS — tout ce que le traitement concerne, un bloc par élément,
// avec son état vivant : en attente → éclaté → calibré → validé (onde Ripple).
export default function TraitementBlocs({ records, statuts }) {
  return (
    <ul className="grid gap-1.5 sm:grid-cols-2">
      {records.map((r, i) => {
        const st = statuts[i] || "attente";
        const done = st === "valide";
        return (
          <li
            key={r.id}
            className={`flex items-center gap-2.5 rounded-lg border px-3 py-2 text-[12px] transition-colors ${
              done ? "mariage-ripple-pulse border-[#34d399]/40 bg-[#34d399]/[0.06]" : "border-white/10 bg-white/[0.04]"
            }`}
          >
            {done ? (
              <Check className="h-3.5 w-3.5 shrink-0 text-[#34d399]" strokeWidth={2.2} />
            ) : (
              <FolderInput className="h-3.5 w-3.5 shrink-0" style={{ color: r.color }} strokeWidth={1.7} />
            )}
            <span className="min-w-0 flex-1 truncate text-white/80">{r.name}</span>
            {/* La pastille couleur : brute → recalée sur le nuancier unique. */}
            {st !== "attente" && (
              <span
                className="h-2.5 w-2.5 shrink-0 rounded-full transition-colors"
                style={{ background: st === "eclate" ? r.color : recalerCouleur(r.color) }}
                title={st === "eclate" ? "teinte brute" : "teinte recalée sur le nuancier"}
              />
            )}
            <span className="shrink-0 font-mono text-[9.5px] uppercase tracking-[0.12em]" style={{ color: STATUT_COLOR[st] }}>
              {done ? `→ ${r.folder}` : STATUT_LABEL[st]}
            </span>
          </li>
        );
      })}
    </ul>
  );
}