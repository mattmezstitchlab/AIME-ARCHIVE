import { useRef, useState } from "react";
import { Upload } from "lucide-react";
import { addImports } from "@/lib/bureau/pointZeroStore";
import RippleTraitement from "./RippleTraitement";

// LA DÉCHÈTERIE INTELLIGENTE — on y dépose tout, la totale. Puis « Démarrer » :
// Ripple raconte le traitement étape par étape (éclatement, calibrage des
// couleurs sur le nuancier unique, validation) et le clavier prend vie.
export default function PointZeroImport({ onPropagated }) {
  const inputRef = useRef(null);
  const [lastBatch, setLastBatch] = useState([]);
  const [lastFiles, setLastFiles] = useState([]);

  const handleFiles = (e) => {
    if (!e.target.files?.length) return;
    const files = Array.from(e.target.files);
    const records = addImports(e.target.files);
    setLastBatch(records);
    setLastFiles(files);
    e.target.value = "";
  };

  return (
    <div className="mx-auto w-full max-w-xl">
      <input ref={inputRef} type="file" multiple className="hidden" onChange={handleFiles} />
      <button
        type="button"
        onClick={() => inputRef.current?.click()}
        className="flex w-full flex-col items-center gap-2 rounded-2xl border border-dashed border-white/20 bg-white/[0.02] px-6 py-8 text-center transition-colors hover:border-white/40 hover:bg-white/[0.04]"
      >
        <Upload className="h-5 w-5 text-[#c9a96e]" strokeWidth={1.6} />
        <span className="text-[13px] font-medium text-white/85">Déposer des fichiers dans le Point Zéro</span>
        <span className="text-[11px] text-white/40">Visuels, zip, PDF, audio… toutes extensions — triés et propagés dans les dossiers.</span>
      </button>

      {lastBatch.length > 0 && (
        <RippleTraitement records={lastBatch} files={lastFiles} onDone={onPropagated} />
      )}
    </div>
  );
}