import { useEffect, useRef, useState } from "react";
import { Play } from "lucide-react";
import { analyserFichiers } from "@/lib/bureau/pointZeroAnalyse";
import TraitementNarration from "./TraitementNarration";
import TraitementBlocs from "./TraitementBlocs";
import TraitementResultats from "./TraitementResultats";

// L'ORCHESTRATEUR DU TRAITEMENT — plus de texte écrit d'avance : « Démarrer »
// envoie réellement les fichiers au moteur, Ripple lit leur contenu et
// raconte ce qu'il reconnaît, pièce par pièce. À la fin, le résultat
// s'affiche au centre avec ses options de modification.
export default function RippleTraitement({ records, files = [], onDone }) {
  const [phrases, setPhrases] = useState([]);
  const [statuts, setStatuts] = useState({});
  const [running, setRunning] = useState(false);
  const [resultats, setResultats] = useState(null);
  const timer = useRef(null);

  useEffect(() => () => clearTimeout(timer.current), []);

  const dire = (t) => setPhrases((p) => [...p, t]);
  const attendre = (ms) => new Promise((r) => { timer.current = setTimeout(r, ms); });

  const demarrer = async () => {
    if (running) return;
    setRunning(true);
    setPhrases([]);
    setStatuts({});
    setResultats(null);

    dire("Je reçois vos éléments — chaque pièce entre réellement dans le moteur, rien ne reste brut.");
    records.forEach((_, i) => setStatuts((s) => ({ ...s, [i]: "eclate" })));
    await attendre(2200);
    dire(`ÉTAPE 1 — Lecture en profondeur : ${records.length} élément${records.length > 1 ? "s" : ""} en cours d'analyse (contenu, couleurs, nature)…`);

    let analyse = null;
    try {
      analyse = await analyserFichiers(files, records);
    } catch {
      analyse = records.map((r) => ({
        id: r.id, name: r.name, folder: r.folder, url: "",
        nature: "élément", reconnu: "le moteur n'a pas pu lire ce fichier — le tri par nature est conservé", couleur: "", usage: "", taille: "",
      }));
    }

    await attendre(1600);
    dire("ÉTAPE 2 — Voici ce que je reconnais, pièce par pièce :");
    for (let i = 0; i < analyse.length; i++) {
      await attendre(2500);
      const el = analyse[i];
      dire(`« ${el.name} » — ${el.nature}${el.couleur ? `, couleur d'origine ${el.couleur}` : ""} : ${el.reconnu}`);
      setStatuts((s) => ({ ...s, [i]: "calibre" }));
    }

    await attendre(2200);
    dire("ÉTAPE 3 — Je calibre sur le nuancier unique et je range. Chaque détail reste modifiable ci-dessous : couleur, taille, utilité.");
    records.forEach((_, i) => setStatuts((s) => ({ ...s, [i]: "valide" })));
    await attendre(1400);

    setResultats(analyse);
    setRunning(false);
    onDone?.();
  };

  return (
    <div className="mt-4 space-y-3 text-left">
      {!running && !resultats && (
        <button
          type="button"
          onClick={demarrer}
          className="mx-auto flex items-center gap-2 rounded-xl bg-[#c9a96e] px-5 py-2.5 text-[12.5px] font-semibold text-black transition hover:bg-[#d8bc85]"
        >
          <Play className="h-3.5 w-3.5" /> Démarrer le traitement — {records.length} élément{records.length > 1 ? "s" : ""}
        </button>
      )}

      <TraitementNarration phrases={phrases} />
      {(running || resultats) && <TraitementBlocs records={records} statuts={statuts} />}

      {/* LE RÉSULTAT — au centre, avec les options de modification. */}
      {resultats && <TraitementResultats resultats={resultats} />}
    </div>
  );
}