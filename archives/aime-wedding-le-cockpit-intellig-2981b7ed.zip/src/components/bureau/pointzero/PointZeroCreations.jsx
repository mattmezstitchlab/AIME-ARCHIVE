import { LayoutTemplate, ShieldCheck, Heart, CalendarDays, UserRound, FileSignature, PanelsTopLeft, Archive, ArrowRight } from "lucide-react";

// LES CRÉATIONS DU POINT ZÉRO — visibles dès l'arrivée : on comprend par le
// titre. Chaque tuile est une génération ; leurs réglages créent les bonnes
// cartes ensemble. L'Audit EAA ouvre SA pipeline (étapes).
const GENERATIONS = [
  { icon: Heart, label: "Mariage", seed: "Je veux organiser un mariage." },
  { icon: CalendarDays, label: "Événement", seed: "Je veux organiser un événement." },
  { icon: PanelsTopLeft, label: "Site web", seed: "Je veux créer un site web." },
  { icon: UserRound, label: "CV / Portrait", seed: "Je veux créer mon CV / mon portrait." },
  { icon: FileSignature, label: "Contrat", seed: "Je veux générer un contrat." },
  { icon: Archive, label: "Transmission", seed: "Je veux préparer une transmission — la mémoire de quelqu'un." },
];

export default function PointZeroCreations({ onMiniSite, onAudit }) {
  const semer = (seed) => window.dispatchEvent(new CustomEvent("aime-pointzero-seed", { detail: { seed } }));

  return (
    <header aria-label="Créez votre mini-site">
      <h2 className="text-[30px] font-extrabold leading-tight text-white sm:text-[36px]">Créez votre mini-site</h2>
      <p className="mt-1.5 max-w-2xl text-[13px] leading-relaxed text-white/50">
        Tout ce qui se génère ici — événement, portrait, contrat… — règle les <b className="font-medium text-white/75">bonnes cartes ensemble</b>.
        L'Audit Accessibilité suit sa pipeline, étape par étape.
      </p>

      {/* LES DEUX ENTRÉES PRINCIPALES */}
      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        <button type="button" onClick={onMiniSite}
          className="group flex items-center gap-3.5 rounded-2xl bg-white p-4 text-left transition hover:bg-white/90">
          <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-black text-white">
            <LayoutTemplate className="h-4.5 w-4.5 h-[18px] w-[18px]" />
          </span>
          <span className="min-w-0 flex-1">
            <span className="block text-[14px] font-bold text-black">Mini-site</span>
            <span className="block text-[11px] text-black/55">Rôle → infos → sections → article EAA réglable → site</span>
          </span>
          <ArrowRight className="h-4 w-4 shrink-0 text-black/40 transition group-hover:translate-x-0.5" />
        </button>

        <button type="button" onClick={onAudit}
          className="group flex items-center gap-3.5 rounded-2xl border border-[#7FDCB2]/30 bg-[#7FDCB2]/[0.06] p-4 text-left transition hover:bg-[#7FDCB2]/[0.12]">
          <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[#7FDCB2]/15 text-[#7FDCB2]">
            <ShieldCheck className="h-[18px] w-[18px]" />
          </span>
          <span className="min-w-0 flex-1">
            <span className="block text-[14px] font-bold text-white">Audit Accessibilité · EAA</span>
            <span className="block text-[11px] text-white/45">La pipeline : failles → remédiation → refonte guidée</span>
          </span>
          <ArrowRight className="h-4 w-4 shrink-0 text-white/35 transition group-hover:translate-x-0.5" />
        </button>
      </div>

      {/* TOUTES LES GÉNÉRATIONS — chaque tuile amorce l'agent à droite. */}
      <div className="mt-3 flex flex-wrap gap-2">
        {GENERATIONS.map((g) => (
          <button key={g.label} type="button" onClick={() => semer(g.seed)}
            className="inline-flex items-center gap-2 rounded-full border border-white/12 bg-white/[0.03] px-3.5 py-2 text-[12px] font-semibold text-white/65 transition hover:border-white/35 hover:bg-white/[0.08] hover:text-white">
            <g.icon className="h-3.5 w-3.5 text-white/40" />
            {g.label}
          </button>
        ))}
      </div>
    </header>
  );
}