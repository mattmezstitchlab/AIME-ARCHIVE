import { useState } from "react";
import { Check } from "lucide-react";
import { NUANCIER_AIME } from "@/lib/bureau/rippleTraitement";
import { updateImport } from "@/lib/bureau/pointZeroStore";

const COULEURS = ["#ffffff", "#111111", ...NUANCIER_AIME];
const TAILLES = ["S", "M", "L", "XL"];
const USAGES = ["Titre", "Sous-titre", "Corps de texte", "Logo", "Fond", "Accent", "Illustration", "Ambiance", "Document de référence"];

// UNE PIÈCE ANALYSÉE — ce que Ripple a reconnu, et ses réglages modifiables :
// une typo importée noire d'origine peut passer en blanc, changer de taille,
// recevoir son utilité — comme le verso des cartes.
export default function ResultatElementCard({ element }) {
  const [couleur, setCouleur] = useState(element.couleur || "#111111");
  const [taille, setTaille] = useState((element.taille || "M").charAt(0).toUpperCase());
  const [usage, setUsage] = useState(USAGES.find((u) => element.usage?.toLowerCase().includes(u.toLowerCase())) || element.usage || "");
  const [saved, setSaved] = useState(false);

  const enregistrer = () => {
    updateImport(element.id, { couleur, taille, usage });
    setSaved(true);
    setTimeout(() => setSaved(false), 1800);
  };

  const estImage = /\.(jpe?g|png|webp|gif|svg|avif)$/i.test(element.name);

  return (
    <div className="rounded-xl border border-white/10 bg-white/[0.03] p-3">
      <div className="flex items-start gap-2.5">
        {estImage && element.url ? (
          <img src={element.url} alt={element.name} className="h-12 w-12 shrink-0 rounded-lg object-cover" />
        ) : (
          <span
            className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg border border-white/10 font-heading text-lg"
            style={{ color: couleur === "#111111" ? "#ffffff" : couleur, background: couleur === "#ffffff" ? "#1a1a1a" : "transparent" }}
          >
            Aa
          </span>
        )}
        <div className="min-w-0">
          <p className="truncate text-[12.5px] font-semibold text-white/90">{element.name}</p>
          <p className="font-mono text-[8.5px] uppercase tracking-[0.14em] text-[#c9a96e]">{element.nature}</p>
          <p className="mt-0.5 text-[10.5px] leading-3.5 text-white/50">{element.reconnu}</p>
        </div>
      </div>

      {/* Couleur — la teinte d'origine détectée, modifiable. */}
      <div className="mt-2.5 flex items-center gap-1.5">
        <span className="w-12 font-mono text-[8.5px] uppercase tracking-[0.12em] text-white/40">Couleur</span>
        {COULEURS.map((c) => (
          <button
            key={c}
            type="button"
            onClick={() => setCouleur(c)}
            aria-label={`Couleur ${c}`}
            className={`h-[18px] w-[18px] rounded-full border transition-transform hover:scale-110 ${
              couleur === c ? "border-white ring-2 ring-white/40" : "border-white/25"
            }`}
            style={{ background: c }}
          />
        ))}
      </div>

      {/* Taille */}
      <div className="mt-1.5 flex items-center gap-1.5">
        <span className="w-12 font-mono text-[8.5px] uppercase tracking-[0.12em] text-white/40">Taille</span>
        {TAILLES.map((t) => (
          <button
            key={t}
            type="button"
            onClick={() => setTaille(t)}
            className={`rounded px-2 py-0.5 font-mono text-[9.5px] transition-colors ${
              taille === t ? "bg-white text-black" : "text-white/45 hover:bg-white/10 hover:text-white"
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      {/* Utilité */}
      <div className="mt-1.5 flex items-center gap-1.5">
        <span className="w-12 shrink-0 font-mono text-[8.5px] uppercase tracking-[0.12em] text-white/40">Utilité</span>
        <select
          value={usage}
          onChange={(e) => setUsage(e.target.value)}
          style={{ colorScheme: "dark" }}
          className="flex-1 rounded-lg border border-white/12 bg-black/40 px-2 py-1 text-[11px] text-white/80 focus:border-[#c9a96e]/50 focus:outline-none"
        >
          <option value="">Choisir…</option>
          {USAGES.map((u) => (
            <option key={u} value={u}>{u}</option>
          ))}
        </select>
      </div>

      <button
        type="button"
        onClick={enregistrer}
        className={`mt-2.5 inline-flex w-full items-center justify-center gap-1.5 rounded-lg py-1.5 text-[11.5px] font-semibold transition ${
          saved ? "bg-[#34d399]/20 text-[#34d399]" : "bg-white/10 text-white hover:bg-white/20"
        }`}
      >
        <Check className="h-3.5 w-3.5" /> {saved ? "Enregistré et propagé" : "Enregistrer ces réglages"}
      </button>
    </div>
  );
}