import { useState } from "react";
import { X, ImagePlus, Sparkles, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";

// ─────────────────────────────────────────────────────────────────────────
// CONSOLE DE RÉGLAGE UNIVERSELLE (façon Wix/Framer) — un seul format, en bas.
// Pilotée par une liste de CHAMPS déclarés ailleurs. Chaque champ a un `type` :
//   · "text"    → champ texte simple
//   · "slider"  → curseur (min/max/step/suffix)
//   · "toggle"  → interrupteur oui/non
//   · "palette" → choix parmi des couleurs
//   · "image"   → import URL + génération IA d'un visuel
// À chaque changement : onChange(fieldId, value) → déclenche l'impact causal.
// ─────────────────────────────────────────────────────────────────────────

function ImageField({ field, value, onChange }) {
  const [busy, setBusy] = useState(false);
  const generate = async () => {
    setBusy(true);
    const { url } = await base44.integrations.Core.GenerateImage({
      prompt: field.prompt || `${field.label}, photographie éditoriale, élégante, mariage`,
    });
    onChange(url);
    setBusy(false);
  };
  return (
    <div>
      <div className="flex items-center gap-2">
        <input
          type="url"
          value={value || ""}
          onChange={(e) => onChange(e.target.value)}
          placeholder="Coller une URL d'image…"
          className="min-w-0 flex-1 rounded-lg border border-white/15 bg-white/[0.04] px-3 py-2 text-[12px] text-white placeholder:text-white/30 focus:border-white/50 focus:outline-none"
        />
        <button
          type="button"
          onClick={generate}
          disabled={busy}
          className="inline-flex shrink-0 items-center gap-1.5 rounded-lg bg-white px-3 py-2 text-[12px] font-semibold text-black transition hover:scale-[1.02] disabled:opacity-60"
        >
          {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Sparkles className="h-3.5 w-3.5" />}
          Générer
        </button>
      </div>
      {value && (
        <img src={value} alt="" className="mt-2 h-16 w-full rounded-lg object-cover" />
      )}
    </div>
  );
}

function Field({ field, value, onChange }) {
  if (field.type === "text") {
    return (
      <input
        type="text"
        value={value ?? ""}
        onChange={(e) => onChange(e.target.value)}
        placeholder={field.placeholder || ""}
        className="w-full rounded-lg border border-white/15 bg-white/[0.04] px-3 py-2 text-[12px] text-white placeholder:text-white/30 focus:border-white/50 focus:outline-none"
      />
    );
  }
  if (field.type === "slider") {
    const v = value ?? field.default ?? field.min ?? 0;
    return (
      <div>
        <div className="mb-1 flex justify-between text-[11px] text-white/50">
          <span>{field.min}{field.suffix}</span>
          <span className="font-semibold text-accent">{v}{field.suffix}</span>
          <span>{field.max}{field.suffix}</span>
        </div>
        <input
          type="range"
          min={field.min}
          max={field.max}
          step={field.step || 1}
          value={v}
          onChange={(e) => onChange(Number(e.target.value))}
          className="ripple-range h-1 w-full cursor-pointer appearance-none rounded-full bg-white/20"
        />
      </div>
    );
  }
  if (field.type === "toggle") {
    const on = !!value;
    return (
      <button
        type="button"
        onClick={() => onChange(!on)}
        className={`relative h-6 w-11 shrink-0 rounded-full transition ${on ? "bg-accent" : "bg-white/20"}`}
      >
        <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white transition ${on ? "left-[22px]" : "left-0.5"}`} />
      </button>
    );
  }
  if (field.type === "palette") {
    return (
      <div className="flex flex-wrap gap-2">
        {field.options.map((c) => (
          <button
            key={c}
            type="button"
            onClick={() => onChange(c)}
            aria-label={c}
            className={`h-7 w-7 rounded-full border-2 transition ${value === c ? "border-white scale-110" : "border-transparent"}`}
            style={{ backgroundColor: c }}
          />
        ))}
      </div>
    );
  }
  if (field.type === "image") {
    return <ImageField field={field} value={value} onChange={onChange} />;
  }
  return null;
}

export default function SettingsConsole({ title, impact, fields, values, onChange, onClose }) {
  return (
    <div className="ripple-wave rounded-t-2xl border-t border-white/15 bg-neutral-950/95 backdrop-blur">
      <div className="flex items-center justify-between border-b border-white/10 px-4 py-2.5">
        <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-accent">{title}</p>
        <button
          type="button"
          onClick={onClose}
          aria-label="Fermer la console"
          className="grid h-6 w-6 place-items-center rounded-full text-white/50 transition hover:bg-white/10 hover:text-white"
        >
          <X className="h-3.5 w-3.5" />
        </button>
      </div>

      <div className="max-h-[190px] space-y-3 overflow-y-auto px-4 py-3 scrollbar-hide">
        {fields.map((f) => (
          <div key={f.id} className={f.type === "toggle" ? "flex items-center justify-between gap-3" : ""}>
            <label className="mb-1 block text-[11px] font-medium text-white/60">{f.label}</label>
            <Field field={f} value={values[f.id]} onChange={(v) => onChange(f.id, v)} />
          </div>
        ))}
      </div>

      {impact && (
        <p className="border-t border-white/10 px-4 py-2 text-[10px] leading-4 text-white/45">
          <span className="font-semibold text-white/60">Impact causal · </span>{impact}
        </p>
      )}
    </div>
  );
}