import { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { FolderPlus, ArrowLeft } from "lucide-react";
import { publierContexte, effacerContexte, journaliser } from "@/lib/clavier/contexteClavier";

// ─────────────────────────────────────────────────────────────────────────
// LE MOTEUR RADIAL DU BUREAU — les dossiers orbitent autour du centre ;
// cliquer un point ZOOME dedans. Le moteur PUBLIE son contexte au clavier
// AI+ME (touches 1…9 = les points du niveau) et parle la grammaire
// universelle : 1…9 ouvrir · ← → tourner · ⏎ zoomer · ⌫ remonter · 0 Point Zéro.
// ─────────────────────────────────────────────────────────────────────────

const R = 38; // rayon de l'orbite en % du conteneur
const DIGITS = ["Digit1", "Digit2", "Digit3", "Digit4", "Digit5", "Digit6", "Digit7", "Digit8", "Digit9"];

export default function BureauRadialMoteur({ nodes, onCenterClick, progress, centerOptions = [] }) {
  const navigate = useNavigate();
  const [path, setPath] = useState([]); // pile des dossiers ouverts en profondeur
  // LE DÉPLOIEMENT RADIAL DU POINT ZÉRO — les options autour du centre.
  const [deployed, setDeployed] = useState(false);
  const [sel, setSel] = useState(-1); // le point sélectionné (grammaire ← → ⏎)
  const current = path[path.length - 1] || null;
  const level = (current ? current.children : nodes) || [];
  const n = Math.max(1, level.length);

  const open = useCallback((node) => {
    journaliser(node.label);
    setSel(-1);
    if (node.children?.length) setPath((p) => [...p, node]);
    else if (node.action) node.action();
    else if (node.to) navigate(node.to);
  }, [navigate]);

  const remonter = useCallback(() => {
    setPath((p) => p.slice(0, -1));
    setSel(-1);
  }, []);

  // LA GRAMMAIRE PHYSIQUE — sans modificateur, hors champs de saisie.
  useEffect(() => {
    const enSaisie = (t) => t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable);
    const h = (e) => {
      if (e.altKey || e.metaKey || e.ctrlKey || enSaisie(e.target)) return;
      const d = DIGITS.indexOf(e.code);
      if (d >= 0 && level[d]) { e.preventDefault(); open(level[d]); }
      else if (e.code === "ArrowLeft") { e.preventDefault(); setSel((s) => (s - 1 + n) % n); }
      else if (e.code === "ArrowRight") { e.preventDefault(); setSel((s) => (s + 1) % n); }
      else if (e.code === "Enter" && e.target?.tagName !== "BUTTON") {
        if (sel >= 0 && level[sel]) { e.preventDefault(); open(level[sel]); }
      } else if (e.code === "Backspace" && path.length) { e.preventDefault(); remonter(); }
      else if (e.code === "Digit0") { e.preventDefault(); setPath([]); setSel(-1); centerOptions.length ? setDeployed(true) : onCenterClick?.(); }
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [level, sel, n, path.length, open, remonter, onCenterClick]);

  // LES COMMANDES DU CLAVIER À L'ÉCRAN — la rangée contextuelle nous pilote.
  useEffect(() => {
    const h = (e) => {
      const cmd = e.detail;
      if (cmd === "prev") setSel((s) => (s - 1 + n) % n);
      else if (cmd === "next") setSel((s) => (s + 1) % n);
      else if (cmd === "valider" && sel >= 0 && level[sel]) open(level[sel]);
      else if (cmd === "retour") remonter();
      else if (cmd === "zero") { setPath([]); setSel(-1); centerOptions.length ? setDeployed(true) : onCenterClick?.(); }
    };
    window.addEventListener("aime-moteur-cmd", h);
    return () => window.removeEventListener("aime-moteur-cmd", h);
  }, [level, sel, n, open, remonter, onCenterClick]);

  // LE MOTEUR PUBLIE SON CONTEXTE — le clavier recâble ses touches en direct.
  useEffect(() => {
    publierContexte({
      id: "moteur",
      breadcrumb: ["Bureau", ...path.map((p) => p.label)],
      selection: sel >= 0 ? level[sel]?.label : null,
      peutRetour: path.length > 0,
      commandes: level.slice(0, 9).map((node, i) => ({
        key: String(i + 1),
        label: node.label,
        color: node.color,
        run: () => open(node),
      })),
    });
    return () => effacerContexte("moteur");
  }, [path, nodes, sel, level, open]);

  return (
    <div className="mx-auto w-full max-w-[540px]">
    <div className="relative aspect-square w-full">
      {/* Le niveau courant — zoom avant/arrière au changement de profondeur */}
      <AnimatePresence mode="popLayout" initial={false}>
        <motion.div
          key={current?.id || "root"}
          initial={{ scale: 0.3, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 2.4, opacity: 0 }}
          transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
          className="absolute inset-0"
        >
          <svg viewBox="0 0 100 100" className="absolute inset-0 h-full w-full" aria-hidden="true">
            <circle cx="50" cy="50" r={R} fill="none" stroke="rgba(255,255,255,0.14)" strokeWidth="0.35" />
            <circle cx="50" cy="50" r={R * 0.62} fill="none" stroke="rgba(255,255,255,0.07)" strokeWidth="0.3" strokeDasharray="1.4 2.2" />
            {level.map((node, i) => {
              const a = ((i / n) * 360 - 90) * (Math.PI / 180);
              return (
                <line
                  key={node.id}
                  x1="50" y1="50"
                  x2={50 + R * Math.cos(a)}
                  y2={50 + R * Math.sin(a)}
                  stroke={node.color || "#C9B88F"}
                  strokeOpacity={i === sel ? 0.6 : 0.28}
                  strokeWidth={i === sel ? 0.5 : 0.3}
                />
              );
            })}
          </svg>

          {/* Les points du niveau — dossiers (zoom) et fichiers (lien / valeur) */}
          {level.map((node, i) => {
            const rad = ((i / n) * 360 - 90) * (Math.PI / 180);
            const x = 50 + R * Math.cos(rad);
            const y = 50 + R * Math.sin(rad);
            const cos = Math.cos(rad);
            const lx = 50 + (R + 5) * Math.cos(rad);
            const ly = 50 + (R + 5) * Math.sin(rad);
            const anchor =
              cos > 0.35 ? "translate(0, -50%)" : cos < -0.35 ? "translate(-100%, -50%)" : "translate(-50%, -50%)";
            const clickable = !!(node.children?.length || node.to || node.action);
            const selected = i === sel;
            return (
              <div key={node.id}>
                <button
                  type="button"
                  onClick={() => open(node)}
                  disabled={!clickable}
                  aria-label={node.label}
                  className={`absolute z-10 rounded-full transition-all ${
                    node.children?.length ? "h-[18px] w-[18px]" : "h-3 w-3"
                  } ${clickable ? "hover:ring-2 hover:ring-white/60 hover:scale-125" : "opacity-70"} ${
                    selected ? "scale-125 ring-2 ring-white" : ""
                  }`}
                  style={{
                    left: `${x}%`,
                    top: `${y}%`,
                    transform: "translate(-50%, -50%)",
                    backgroundColor: node.color || "rgba(255,255,255,0.55)",
                  }}
                />
                <button
                  type="button"
                  onClick={() => open(node)}
                  disabled={!clickable}
                  className={`absolute z-10 max-w-[130px] text-left leading-tight ${
                    selected ? "text-white" : clickable ? "text-white/70 hover:text-white" : "text-white/45"
                  }`}
                  style={{ left: `${lx}%`, top: `${ly}%`, transform: anchor }}
                >
                  <span className="block truncate text-[11px] font-medium">
                    {node.label}
                    {node.badge && <span className="ml-1.5 font-mono text-[9px] text-white/35">{node.badge}</span>}
                  </span>
                  {node.summary && (
                    <span className="block truncate text-[9.5px] text-white/35">{node.summary}</span>
                  )}
                </button>
              </div>
            );
          })}
        </motion.div>
      </AnimatePresence>

      {/* LE CENTRE — Point Zéro (racine) ou dossier courant (zoomé) */}
      <div className="absolute left-1/2 top-1/2 z-20 -translate-x-1/2 -translate-y-1/2 text-center">
        {current ? (
          <button
            type="button"
            onClick={remonter}
            aria-label={`Revenir en arrière depuis ${current.label}`}
            className="flex h-24 w-24 flex-col items-center justify-center gap-1 rounded-full border border-white/15 bg-[#131316] text-white transition-transform hover:scale-[1.05]"
          >
            <ArrowLeft className="h-4 w-4 text-white/60" strokeWidth={1.8} />
            <span className="max-w-[76px] truncate px-1 font-mono text-[8.5px] font-semibold uppercase tracking-[0.16em] text-white/55">
              {current.label}
            </span>
          </button>
        ) : (
          <button
            type="button"
            onClick={() => (centerOptions.length ? setDeployed((d) => !d) : onCenterClick?.())}
            aria-expanded={deployed}
            aria-label="Ouvrir le Point Zéro — importer et compléter"
            className="group relative block h-24 w-24 transition-transform hover:scale-[1.05]"
          >
            {/* L'anneau arc-en-ciel qui circule — la marque AI+ME au centre du moteur. */}
            <span className="absolute inset-0 overflow-hidden rounded-full transition-all duration-500 group-hover:rounded-[20px]" aria-hidden="true">
              <span
                className="absolute -inset-1/2"
                style={{
                  background: "conic-gradient(#ff5f6d, #ffc371, #c9f76f, #38bdf8, #c084fc, #ff5f6d)",
                  animation: "aime-plus-spin 3.5s linear infinite",
                }}
              />
            </span>
            <span className="absolute inset-[3px] flex flex-col items-center justify-center gap-1 rounded-full bg-[#0C0C0C] transition-all duration-500 group-hover:rounded-[17px]">
              <span
                className={`text-[30px] font-light leading-none transition-transform duration-500 ${deployed ? "rotate-45" : ""}`}
                style={{ animation: "aime-hue 8s linear infinite" }}
              >
                +
              </span>
              <span className="font-mono text-[8px] font-semibold uppercase tracking-[0.22em] text-white/50">
                Point Zéro
              </span>
            </span>
          </button>
        )}
        {progress && !current && (
          <p className="mt-2 font-mono text-[9px] uppercase tracking-[0.2em] text-white/35">{progress}</p>
        )}
      </div>

      {/* LES OPTIONS DU POINT ZÉRO — déployées en radial autour du centre. */}
      {!current && deployed &&
        centerOptions.map((opt, i) => {
          const a = ((i / centerOptions.length) * 360 - 90) * (Math.PI / 180);
          const x = 50 + 23 * Math.cos(a);
          const y = 50 + 23 * Math.sin(a);
          return (
            <button
              key={opt.key}
              type="button"
              onClick={() => { setDeployed(false); onCenterClick?.(opt.key); }}
              className="absolute z-30 flex -translate-x-1/2 -translate-y-1/2 items-center gap-1.5 whitespace-nowrap rounded-full border border-white/20 bg-black/90 px-3 py-1.5 text-[11px] font-semibold text-white/85 backdrop-blur transition hover:border-white/60 hover:text-white"
              style={{ left: `${x}%`, top: `${y}%` }}
            >
              <span className="h-2 w-2 rounded-full" style={{ backgroundColor: opt.color }} aria-hidden="true" />
              {opt.label}
            </button>
          );
        })}
    </div>

    {/* LES MINI-CARTES DU NIVEAU — en zoom, l'aperçu concret de chaque point. */}
    {current && level.length > 0 && (
      <div className="mt-2 flex gap-2 overflow-x-auto pb-2 scrollbar-hide" role="list" aria-label={`Contenu de ${current.label}`}>
        {level.map((node) => {
          const clickable = !!(node.children?.length || node.to || node.action);
          return (
            <button
              key={node.id}
              type="button"
              role="listitem"
              onClick={() => clickable && open(node)}
              className={`min-w-[130px] max-w-[160px] shrink-0 rounded-xl border border-white/12 bg-[#131316] p-3 text-left transition ${
                clickable ? "hover:border-white/40" : "opacity-70"
              }`}
            >
              <span className="block h-1.5 w-7 rounded-full" style={{ backgroundColor: node.color || "#C9B88F" }} aria-hidden="true" />
              <span className="mt-2 block truncate text-[11.5px] font-bold tracking-[-0.02em] text-white/90">{node.label}</span>
              <span className="mt-0.5 block truncate font-mono text-[8.5px] uppercase tracking-[0.14em] text-white/35">
                {node.summary || node.badge || (node.children?.length ? `${node.children.length} éléments` : clickable ? "Ouvrir" : "—")}
              </span>
            </button>
          );
        })}
      </div>
    )}
    </div>
  );
}