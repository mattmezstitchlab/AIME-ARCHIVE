import { useState } from "react";
import { Link } from "react-router-dom";
import { Check, Pencil, BookOpen, FolderOpen } from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

// ÉTAPE 4 — LA PAGE PERSONNE : hero horizontal recadré sur le regard,
// nuancier calibré, infos éditables — avec le guide pour compléter.
export default function EnregistrerPage({ data, couleurs, onModifier }) {
  const [nom, setNom] = useState(data.nom);
  const [valide, setValide] = useState(false);

  const valider = () => {
    localStorage.setItem(
      "aime-enregistrement-v1",
      JSON.stringify({ ...data, nom, couleurs, validated_at: Date.now() })
    );
    setValide(true);
  };

  return (
    <section className="overflow-hidden rounded-2xl border border-white/12 bg-white/[0.02]">
      {/* Le hero horizontal — la photo recadrée, le regard dans le tiers haut. */}
      <div className="relative aspect-[21/8] w-full overflow-hidden">
        <img src={data.photoUrl} alt={nom} className="h-full w-full object-cover" style={{ objectPosition: "50% 28%" }} />
        <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent" />
        <div className="absolute bottom-3 left-4 right-4 flex items-end justify-between gap-3">
          <div>
            <input
              value={nom}
              onChange={(e) => setNom(e.target.value)}
              aria-label="Nom affiché"
              className="w-full max-w-xs bg-transparent font-heading text-2xl font-light tracking-[-0.01em] text-white focus:outline-none"
            />
            {data.naissance && (
              <p className="font-mono text-[9.5px] uppercase tracking-[0.18em] text-white/50">
                Repère zéro · {format(new Date(data.naissance), "d MMMM yyyy", { locale: fr })}
              </p>
            )}
          </div>
          <div className="flex gap-1.5">
            {couleurs.map((c) => (
              <span key={c} className="h-5 w-5 rounded-full border border-white/30" style={{ background: c }} />
            ))}
          </div>
        </div>
      </div>

      <div className="p-4">
        {data.projets.length > 0 && (
          <div className="flex flex-wrap gap-1.5">
            {data.projets.map((p) => (
              <span key={p} className="rounded-full border border-[#c9a96e]/40 bg-[#c9a96e]/10 px-2.5 py-0.5 text-[11px] text-[#e6cf9f]">
                {p}
              </span>
            ))}
          </div>
        )}

        <div className="mt-4 flex flex-wrap gap-2">
          <button
            type="button"
            onClick={valider}
            className={`inline-flex items-center gap-1.5 rounded-lg px-4 py-2 text-[12.5px] font-semibold transition ${
              valide ? "bg-emerald-500/20 text-emerald-300" : "bg-[#c9a96e] text-black hover:bg-[#d8bc85]"
            }`}
          >
            <Check className="h-4 w-4" /> {valide ? "Page validée et rangée" : "Valider ma page"}
          </button>
          <button
            type="button"
            onClick={onModifier}
            className="inline-flex items-center gap-1.5 rounded-lg border border-white/15 px-4 py-2 text-[12.5px] text-white/70 transition hover:text-white"
          >
            <Pencil className="h-3.5 w-3.5" /> Modifier
          </button>
        </div>

        {/* Le guide au centre : compléter, et le mode d'emploi du site. */}
        <div className="mt-4 grid gap-2 sm:grid-cols-2">
          <Link to="/bureau" className="flex items-center gap-2 rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2.5 text-[12px] text-white/70 transition-colors hover:text-white">
            <FolderOpen className="h-4 w-4 text-[#c9a96e]" /> Compléter dans le Bureau — vos projets, votre timeline
          </Link>
          <Link to="/commencer" className="flex items-center gap-2 rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2.5 text-[12px] text-white/70 transition-colors hover:text-white">
            <BookOpen className="h-4 w-4 text-[#c9a96e]" /> Le mode d'emploi du site — les codes B, C, R, A+ME
          </Link>
        </div>
      </div>
    </section>
  );
}