import { useEffect, useRef, useState } from "react";
import { Sparkle } from "lucide-react";
import { extraireCouleurs } from "@/lib/enregistrer/photoAnalyse";

const PHRASES = [
  "Je reçois votre photo — rien ne reste brut, tout entre dans le moteur.",
  "J'analyse les couleurs : votre image est convertie en 5 teintes, recalées sur le nuancier unique.",
  "Je recadre en format horizontal pour le haut de votre page — cadrage aligné sur le regard.",
  "Je relie vos dates : naissance, projets en tête — chaque repère prend sa place sur votre timeline.",
  "Votre page personne est prête.",
];

// ÉTAPE 3 — LA MISE EN SCÈNE : narration lente phrase par phrase pendant que
// la photo est réellement analysée (couleurs dominantes extraites du pixel).
export default function EnregistrerAnalyse({ photoUrl, onDone }) {
  const [phrases, setPhrases] = useState([]);
  const [couleurs, setCouleurs] = useState([]);
  const couleursRef = useRef([]);
  const timer = useRef(null);

  useEffect(() => {
    extraireCouleurs(photoUrl).then((cs) => {
      couleursRef.current = cs;
      setCouleurs(cs);
    });
    const step = (i) => {
      if (i >= PHRASES.length) {
        timer.current = setTimeout(() => onDone(couleursRef.current), 1200);
        return;
      }
      setPhrases((p) => [...p, PHRASES[i]]);
      timer.current = setTimeout(() => step(i + 1), 2600);
    };
    step(0);
    return () => clearTimeout(timer.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <section className="rounded-2xl border border-white/12 bg-black/50 p-5">
      <div className="flex items-start gap-4">
        <img src={photoUrl} alt="Photo en cours d'analyse" className="h-24 w-24 rounded-xl object-cover opacity-80" />
        <ul className="flex-1 space-y-2">
          {phrases.map((ph, i) => (
            <li key={i} className={`flex items-start gap-2 text-[13px] leading-5 ripple-wave ${i === phrases.length - 1 ? "font-semibold text-[#e6cf9f]" : "text-white/55"}`}>
              <Sparkle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-[#c9a96e]/60" />
              {ph}
            </li>
          ))}
        </ul>
      </div>
      {couleurs.length > 0 && phrases.length >= 2 && (
        <div className="mt-4 flex items-center gap-2">
          <span className="font-mono text-[9px] uppercase tracking-[0.18em] text-white/40">Nuancier extrait</span>
          {couleurs.map((c) => (
            <span key={c} className="h-6 w-6 rounded-full border border-white/20 ripple-wave" style={{ background: c }} title={c} />
          ))}
        </div>
      )}
    </section>
  );
}