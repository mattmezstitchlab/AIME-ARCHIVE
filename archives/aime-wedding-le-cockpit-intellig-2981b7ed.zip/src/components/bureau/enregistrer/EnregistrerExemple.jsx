import { useState } from "react";
import EnregistrerIntent from "./EnregistrerIntent";
import EnregistrerOnboarding from "./EnregistrerOnboarding";
import EnregistrerAnalyse from "./EnregistrerAnalyse";
import EnregistrerPage from "./EnregistrerPage";

// S'ENREGISTRER — la page d'enregistrement EST le Bureau, mais en commençant
// par l'exemple : Point Zéro (grisé sauf S'enregistrer) → Ripple → onboarding
// → analyse mise en scène → la page personne, à modifier et valider.
export default function EnregistrerExemple() {
  const [etape, setEtape] = useState("intent"); // intent | onboarding | analyse | page
  const [data, setData] = useState(null);
  const [couleurs, setCouleurs] = useState([]);

  return (
    <div className="space-y-4">
      {etape === "intent" && <EnregistrerIntent onGenerer={() => setEtape("onboarding")} />}
      {etape === "onboarding" && (
        <EnregistrerOnboarding
          onValider={(d) => {
            setData(d);
            setEtape("analyse");
          }}
        />
      )}
      {etape === "analyse" && data && (
        <EnregistrerAnalyse
          photoUrl={data.photoUrl}
          onDone={(cs) => {
            setCouleurs(cs);
            setEtape("page");
          }}
        />
      )}
      {etape === "page" && data && (
        <EnregistrerPage data={data} couleurs={couleurs} onModifier={() => setEtape("onboarding")} />
      )}
    </div>
  );
}