import { useState } from "react";
import { ImagePlus, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";

const PROJETS = ["Pro — vitrine / activité", "Mariage", "Anniversaire", "Association", "Autre projet perso"];

// ÉTAPE 2 — l'onboarding généré : nom, date de naissance, projets en tête
// (pro ET/OU perso), et la photo. Valider lance l'analyse.
export default function EnregistrerOnboarding({ onValider }) {
  const [nom, setNom] = useState("");
  const [naissance, setNaissance] = useState("");
  const [projets, setProjets] = useState([]);
  const [photoUrl, setPhotoUrl] = useState("");
  const [uploading, setUploading] = useState(false);

  const toggleProjet = (p) =>
    setProjets((ps) => (ps.includes(p) ? ps.filter((x) => x !== p) : [...ps, p]));

  const handleFile = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setPhotoUrl(file_url);
    setUploading(false);
  };

  return (
    <section className="rounded-2xl border border-white/12 bg-white/[0.03] p-5">
      <p className="font-mono text-[9.5px] uppercase tracking-[0.2em] text-[#c9a96e]">
        Onboarding — votre page personne
      </p>

      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        <label className="block">
          <span className="text-[11px] font-medium text-white/55">Votre nom affiché</span>
          <input
            value={nom}
            onChange={(e) => setNom(e.target.value)}
            placeholder="ex. Marie Dupont"
            className="mt-1 w-full rounded-lg border border-white/12 bg-black/40 px-3 py-2 text-[13px] text-white/90 placeholder:text-white/25 focus:border-[#c9a96e]/50 focus:outline-none"
          />
        </label>
        <label className="block">
          <span className="text-[11px] font-medium text-white/55">Date de naissance — votre premier repère</span>
          <input
            type="date"
            value={naissance}
            onChange={(e) => setNaissance(e.target.value)}
            className="mt-1 w-full rounded-lg border border-white/12 bg-black/40 px-3 py-2 text-[13px] text-white/90 focus:border-[#c9a96e]/50 focus:outline-none"
          />
        </label>
      </div>

      <div className="mt-4">
        <span className="text-[11px] font-medium text-white/55">Un projet en tête ? Pro et/ou perso — les deux comptent.</span>
        <div className="mt-1.5 flex flex-wrap gap-1.5">
          {PROJETS.map((p) => (
            <button
              key={p}
              type="button"
              onClick={() => toggleProjet(p)}
              className={`rounded-full border px-3 py-1 text-[11.5px] transition-colors ${
                projets.includes(p)
                  ? "border-[#c9a96e] bg-[#c9a96e]/15 text-[#e6cf9f]"
                  : "border-white/12 text-white/50 hover:text-white"
              }`}
            >
              {p}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-4">
        <span className="text-[11px] font-medium text-white/55">Votre photo — elle sera analysée, calibrée et recadrée.</span>
        <label className="mt-1.5 flex cursor-pointer items-center justify-center gap-2 rounded-xl border border-dashed border-white/20 bg-black/30 px-4 py-5 text-[12px] text-white/50 transition-colors hover:border-[#c9a96e]/50 hover:text-white">
          {uploading ? (
            <><Loader2 className="h-4 w-4 animate-spin" /> Envoi en cours…</>
          ) : photoUrl ? (
            <img src={photoUrl} alt="Votre photo" className="h-20 rounded-lg object-cover" />
          ) : (
            <><ImagePlus className="h-4 w-4" /> Importer ma photo</>
          )}
          <input type="file" accept="image/*" onChange={handleFile} className="sr-only" />
        </label>
      </div>

      <button
        type="button"
        disabled={!nom.trim() || !photoUrl}
        onClick={() => onValider({ nom: nom.trim(), naissance, projets, photoUrl })}
        className="mt-4 w-full rounded-lg bg-[#c9a96e] px-4 py-2 text-[13px] font-semibold text-black transition hover:bg-[#d8bc85] disabled:opacity-40"
      >
        Valider — lancer l'analyse
      </button>
    </section>
  );
}