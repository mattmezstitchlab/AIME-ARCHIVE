import { Upload, Sparkles, MessageCircleQuestion, UserPlus } from "lucide-react";

// ÉTAPE 1 — le Point Zéro en mode EXEMPLE : les boutons habituels sont
// grisés, seul « S'enregistrer » est actif. Le champ Ripple est pré-rempli.
export default function EnregistrerIntent({ onGenerer }) {
  return (
    <section className="rounded-2xl border border-white/12 bg-white/[0.03] p-4">
      <div className="flex flex-wrap items-center justify-center gap-1.5">
        {[
          { icon: Upload, label: "Importer" },
          { icon: Sparkles, label: "Générer" },
          { icon: MessageCircleQuestion, label: "Compléter les infos" },
        ].map((t) => (
          <span key={t.label} className="inline-flex cursor-not-allowed items-center gap-1.5 rounded-full px-3.5 py-1.5 text-[12px] font-medium text-white/25">
            <t.icon className="h-3.5 w-3.5" /> {t.label}
          </span>
        ))}
        <span className="inline-flex items-center gap-1.5 rounded-full bg-white px-3.5 py-1.5 text-[12px] font-semibold text-black">
          <UserPlus className="h-3.5 w-3.5" /> S'enregistrer
        </span>
      </div>

      <p className="mt-3 text-center font-mono text-[9.5px] uppercase tracking-[0.2em] text-[#c9a96e]">
        Ceci est un exemple — le projet « S'enregistrer »
      </p>

      <div className="mx-auto mt-3 flex max-w-xl items-center gap-2 rounded-full border border-white/15 bg-black/40 py-1.5 pl-4 pr-1.5">
        <input
          value="S'enregistrer — créer ma page personne"
          readOnly
          aria-label="Projet exemple"
          className="flex-1 bg-transparent text-[13px] text-white/80 focus:outline-none"
        />
        <button
          type="button"
          onClick={onGenerer}
          className="rounded-full bg-[#c9a96e] px-4 py-1.5 text-[12px] font-semibold text-black transition hover:bg-[#d8bc85]"
        >
          Générer
        </button>
      </div>
      <p className="mt-2 text-center text-[11px] text-white/40">
        Ripple va générer votre onboarding : votre page se construit comme n'importe quel projet.
      </p>
    </section>
  );
}