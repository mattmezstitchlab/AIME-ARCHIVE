import { X, MonitorPlay } from "lucide-react";
import { ROLES, GESTES } from "@/components/devicelanding/causalKeyboardData";
import { SCREEN_MODES, renderMode } from "@/components/devicelanding/causalScreenModes";
import { SITE_MODES, renderSiteScreen } from "@/components/devicelanding/causalSiteScreens";
import { renderRoleScreen } from "@/components/devicelanding/causalRoleScreens";
import { renderOsScreen } from "@/components/devicelanding/causalOsScreen";
import { renderActivite } from "@/components/devicelanding/causalActiviteScreen";
import { renderDesignSystem } from "@/components/devicelanding/causalDesignSystem";
import { CSS } from "@/components/devicelanding/causalKeyboardCss";

// ─────────────────────────────────────────────────────────────────────────
// L'ÉCRAN DU CLAVIER — le paradigme : le clavier en bas n'affiche RIEN,
// chaque touche « écran » pressée affiche son contenu ICI, au centre du
// Bureau. Mêmes rendus que la dalle d'origine, sans doublon.
// ─────────────────────────────────────────────────────────────────────────

const couleur = (r) => r.c;

function ecranHtml(mode, roleId) {
  const ctx = { roles: ROLES, couleur };
  const couple = ROLES.find((r) => r.id === "couple");
  if (mode === "role") return renderRoleScreen(roleId || "couple", { ...ctx, gestes: GESTES });
  if (mode === "designsystem") return renderDesignSystem(ctx);
  if (mode === "os") return renderOsScreen({ ...ctx, openId: null, metier: "", activeId: "couple" });
  if (mode === "activite")
    return renderActivite({
      role: couple, c: couple.c, nbOndes: 0, name: "",
      jj: Math.max(0, Math.ceil((new Date("2026-09-27T00:00:00") - Date.now()) / 86400000)),
    });
  if (SITE_MODES.some((m) => m.id === mode)) return renderSiteScreen(mode, { ...ctx, role: couple, c: couple.c });
  if (SCREEN_MODES.some((m) => m.id === mode)) return renderMode(mode, ctx);
  return `<p style="color:rgba(255,255,255,.5);font-size:.85rem;line-height:1.6">Ce mode vit dans la mémoire du clavier — pressez ses touches pour l'alimenter, le contenu s'écrira ici.</p>`;
}

export default function ClavierEcran({ mode, label, roleId, onClose }) {
  return (
    <section className="rounded-2xl border border-white/10 bg-[#0D0D0F] p-4" aria-label={`Écran du clavier — ${label}`}>
      <div className="mb-3 flex items-center justify-between">
        <p className="inline-flex items-center gap-2 font-mono text-[10px] font-semibold uppercase tracking-[0.24em] text-white/40">
          <MonitorPlay className="h-3.5 w-3.5 text-[#c9a96e]" /> Écran du clavier · {label}
        </p>
        <button type="button" onClick={onClose} aria-label="Fermer l'écran du clavier"
          className="rounded-full p-1.5 text-white/40 hover:bg-white/10 hover:text-white">
          <X className="h-4 w-4" />
        </button>
      </div>
      <div className="ck-scope" data-theme="nuit">
        <style>{CSS}</style>
        <div className="scr-ui">
          <div className="scr-view" style={{ marginTop: 0, minHeight: "18rem" }}
            dangerouslySetInnerHTML={{ __html: ecranHtml(mode, roleId) }} />
        </div>
      </div>
    </section>
  );
}