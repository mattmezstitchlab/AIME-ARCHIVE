import { useState, useEffect } from "react";
import { HelpCircle } from "lucide-react";
import { lireContexte, surContexte } from "@/lib/clavier/contexteClavier";

// LA RANGÉE CONTEXTUELLE — les touches vivantes du clavier : elles se
// recâblent selon l'endroit où l'on est (le contexte publié). Fil d'Ariane
// au-dessus, grammaire universelle à droite, « ? » pour l'auto-mode d'emploi.
const GRAMMAIRE = [
  ["1…9", "ouvrir le point correspondant"],
  ["← →", "tourner la sélection sur l'orbite"],
  ["⏎", "zoomer dans le point sélectionné"],
  ["⌫", "remonter d'un niveau"],
  ["0", "le Point Zéro — toujours"],
];

export default function ClavierContexteRow() {
  const [ctx, setCtx] = useState(lireContexte);
  const [aide, setAide] = useState(false);
  useEffect(() => surContexte(setCtx), []);

  const cmd = (c) => window.dispatchEvent(new CustomEvent("aime-moteur-cmd", { detail: c }));

  return (
    <div className="mb-2 rounded-2xl border border-[#c9a96e]/25 bg-[#c9a96e]/[0.05] p-2.5">
      {/* LE FIL D'ARIANE — où l'on est, pourquoi les touches changent. */}
      <div className="flex items-center justify-between gap-2">
        <p className="min-w-0 truncate font-mono text-[9.5px] font-semibold uppercase tracking-[0.2em] text-white/45">
          {ctx ? ctx.breadcrumb.join(" › ") : "Aucun contexte publié — ouvrez le Bureau, le moteur câble ses touches ici"}
          {ctx?.selection && <span className="text-[#c9a96e]"> · ◉ {ctx.selection}</span>}
        </p>
        <button
          type="button"
          onClick={() => setAide((a) => !a)}
          aria-expanded={aide}
          aria-label="La grammaire du clavier"
          className={`shrink-0 rounded-full p-1 transition-colors ${aide ? "text-[#c9a96e]" : "text-white/40 hover:text-white"}`}
        >
          <HelpCircle className="h-3.5 w-3.5" />
        </button>
      </div>

      {/* « ? » — LA GRAMMAIRE UNIVERSELLE, identique partout. */}
      {aide && (
        <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 rounded-lg border border-white/10 bg-black/40 px-3 py-2">
          {GRAMMAIRE.map(([k, txt]) => (
            <span key={k} className="text-[10.5px] text-white/55">
              <kbd className="mr-1 rounded border border-white/20 px-1 py-0.5 font-mono text-[9px] text-white/75">{k}</kbd>
              {txt}
            </span>
          ))}
        </div>
      )}

      {/* LES TOUCHES RECÂBLÉES + la grammaire cliquable. */}
      {ctx && (
        <div className="mt-2 flex flex-wrap items-center gap-1.5">
          {ctx.commandes.map((c) => (
            <button
              key={c.key}
              type="button"
              onClick={c.run}
              className="inline-flex items-center gap-1.5 rounded-lg border border-white/12 bg-white/[0.04] px-2.5 py-1.5 text-[11px] text-white/70 transition hover:border-[#c9a96e]/60 hover:text-white"
            >
              <span
                className="flex h-4 w-4 items-center justify-center rounded font-mono text-[9px] font-bold text-black"
                style={{ background: c.color || "#C9B88F" }}
              >
                {c.key}
              </span>
              <span className="max-w-[140px] truncate">{c.label}</span>
            </button>
          ))}
          <span className="ml-auto flex items-center gap-1">
            <button type="button" onClick={() => cmd("prev")} aria-label="Tourner à gauche" className="rounded-lg border border-white/12 px-2 py-1 font-mono text-[10px] text-white/60 hover:border-[#c9a96e]/60 hover:text-white">←</button>
            <button type="button" onClick={() => cmd("next")} aria-label="Tourner à droite" className="rounded-lg border border-white/12 px-2 py-1 font-mono text-[10px] text-white/60 hover:border-[#c9a96e]/60 hover:text-white">→</button>
            <button type="button" onClick={() => cmd("valider")} aria-label="Zoomer dans la sélection" className="rounded-lg border border-white/12 px-2 py-1 font-mono text-[10px] text-white/60 hover:border-[#c9a96e]/60 hover:text-white">⏎</button>
            <button type="button" onClick={() => cmd("retour")} disabled={!ctx.peutRetour} aria-label="Remonter d'un niveau" className="rounded-lg border border-white/12 px-2 py-1 font-mono text-[10px] text-white/60 hover:border-[#c9a96e]/60 hover:text-white disabled:opacity-30">⌫</button>
            <button type="button" onClick={() => cmd("zero")} aria-label="Le Point Zéro" className="rounded-lg border border-[#c9a96e]/50 bg-[#c9a96e]/10 px-2 py-1 font-mono text-[10px] font-bold text-[#e6cf9f] hover:bg-[#c9a96e]/20">0</button>
          </span>
        </div>
      )}
    </div>
  );
}