import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import ClavierTouche from "@/components/bureau/claviers/universel/ClavierTouche";
import { ZONES, SYSTEME, CONTEXTE, MONDES, OPERATEURS, COMMANDES } from "./clavierZonesData";
import { pressSysteme } from "./zoneSysteme";

// ═══════════════════════════════════════════════════════════════════════════
// LE CLAVIER AI+ME — UN SEUL clavier, découpé en ZONES-SLIDES (comme les
// rangées d'un vrai clavier). Hauteur fixe, design unifié : mêmes touches,
// même typo mono calibrée partout. L'onde causale traverse à chaque bascule.
// ═══════════════════════════════════════════════════════════════════════════

const PAR_PAGE = 12;

export default function ClavierZones() {
  const [zone, setZone] = useState("contexte");
  const [monde, setMonde] = useState("couleurs");
  const [sousMode, setSousMode] = useState("hex");
  const [page, setPage] = useState(0);
  const [copie, setCopie] = useState(null);
  const [vague, setVague] = useState(0);
  const navigate = useNavigate();

  const zi = ZONES.findIndex((z) => z.id === zone);
  const m = MONDES.find((x) => x.id === monde);
  const onde = () => setVague((v) => v + 1);

  const touchesDeZone = () => {
    if (zone === "systeme") return SYSTEME;
    if (zone === "contexte") return CONTEXTE;
    if (zone === "vivante") return m.touches(sousMode);
    if (zone === "operateurs") return OPERATEURS;
    return COMMANDES;
  };
  const touches = touchesDeZone();
  const nbPages = Math.max(1, Math.ceil(touches.length / PAR_PAGE));
  const visibles = touches.slice(page * PAR_PAGE, (page + 1) * PAR_PAGE);

  const allerZone = (id) => { setZone(id); setPage(0); onde(); };

  // Combinaisons CLAVIER physiques — le minimum à l'écran, tout aux doigts :
  // ⌥1…5 = changer de zone · ⌥◀ ▶ = tourner les pages de la zone.
  useEffect(() => {
    const h = (e) => {
      if (!e.altKey) return;
      const n = ["Digit1", "Digit2", "Digit3", "Digit4", "Digit5"].indexOf(e.code);
      if (n >= 0) { e.preventDefault(); allerZone(ZONES[n].id); }
      else if (e.code === "ArrowLeft") { e.preventDefault(); setPage((p) => Math.max(0, p - 1)); }
      else if (e.code === "ArrowRight") { e.preventDefault(); setPage((p) => Math.min(nbPages - 1, p + 1)); }
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [nbPages]);

  const presser = (t) => {
    const a = t.action || {};
    if (a.type === "copier") {
      navigator.clipboard?.writeText(a.valeur);
      setCopie(a.valeur);
      setTimeout(() => setCopie(null), 1200);
    } else if (a.type === "naviguer") navigate(a.to);
    else if (a.type === "app") window.dispatchEvent(new CustomEvent("aime-bureau-app", { detail: { app: a.app } }));
    else if (a.type === "ecran")
      window.dispatchEvent(new CustomEvent("aime-clavier-ecran", { detail: { mode: a.mode, label: a.label, roleId: a.roleId } }));
    else if (a.type === "monde") {
      const nm = MONDES.find((x) => x.id === a.monde);
      setMonde(a.monde);
      setSousMode(nm?.sousModes?.[0]?.id || null);
      setPage(0);
      setZone("vivante"); // la cause ouvre sa conséquence : le monde re-skinne la zone vivante
      onde();
    } else if (a.type === "systeme") pressSysteme(a.id);
    else if (a.type === "zone") allerZone(a.zone);
    else if (a.type === "pagePrev") setPage((p) => Math.max(0, p - 1));
    else if (a.type === "pageNext") setPage((p) => Math.min(nbPages - 1, p + 1));
    else if (a.type === "entree" && m.entree) presser({ action: m.entree });
  };

  const zoneActive = ZONES[zi];

  return (
    <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-3">
      {/* Les ZONES — les rangées du clavier, en slides */}
      <div className="flex flex-wrap items-center gap-1.5" role="tablist" aria-label="Zones du clavier">
        {ZONES.map((z, i) => (
          <button
            key={z.id}
            type="button"
            role="tab"
            aria-selected={z.id === zone}
            onClick={() => allerZone(z.id)}
            className={`rounded-lg border px-3 py-1.5 font-mono text-[10px] font-bold uppercase tracking-[0.14em] transition ${
              z.id === zone ? "border-[#c9a96e] bg-[#c9a96e]/15 text-white" : "border-white/12 text-white/50 hover:text-white"
            }`}
          >
            <span className="mr-1.5 text-[#c9a96e]/80">{i + 1}</span>
            {z.label}
          </button>
        ))}
      </div>
      <p className="mt-1.5 text-[11px] text-white/45">{zoneActive.sub}</p>

      {/* Sous-modes du monde (zone vivante uniquement) — hauteur constante */}
      <div className="mt-1.5 flex h-7 items-center gap-1.5">
        {zone === "vivante" &&
          (m.sousModes || []).map((sm) => (
            <button
              key={sm.id}
              type="button"
              aria-pressed={sm.id === sousMode}
              onClick={() => { setSousMode(sm.id); setPage(0); onde(); }}
              className={`rounded-full border px-2.5 py-0.5 font-mono text-[10px] font-semibold transition ${
                sm.id === sousMode ? "border-[#c9a96e] bg-[#c9a96e]/15 text-white" : "border-white/12 text-white/45 hover:text-white"
              }`}
            >
              {sm.label}
            </button>
          ))}
        {zone === "vivante" && (
          <span className="ml-auto font-mono text-[10px] uppercase tracking-[0.16em]" style={{ color: m.accent }}>
            Monde · {m.label}
          </span>
        )}
      </div>

      {/* LA ZONE — hauteur fixe, re-skin animé par l'onde causale */}
      <div key={`${zone}-${vague}`} className="ripple-wave mt-2 grid h-[168px] grid-cols-3 grid-rows-2 gap-1.5 sm:grid-cols-4 md:grid-cols-6">
        {visibles.map((t, i) => (
          <ClavierTouche key={`${zone}-${monde}-${page}-${i}`} touche={t} copie={copie} onPress={presser} />
        ))}
      </div>

      {/* Barre basse — glisser entre zones + pagination */}
      <div className="mt-2 flex items-center justify-between">
        <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-white/30">
          AI+ME · Zone {zi + 1}/{ZONES.length} — {zoneActive.label}
          <kbd className="ml-2 rounded border border-white/15 px-1 py-0.5 text-[9px] normal-case tracking-normal text-white/40">⌥1…5</kbd>
          <kbd className="ml-1 rounded border border-white/15 px-1 py-0.5 text-[9px] normal-case tracking-normal text-white/40">⌥◀▶</kbd>
        </span>
        <span className="flex items-center gap-1.5">
          <button type="button" aria-label="Zone précédente" disabled={zi === 0}
            onClick={() => allerZone(ZONES[zi - 1].id)}
            className="rounded-lg border border-white/12 px-3 py-1 font-mono text-[10px] text-white/70 transition hover:border-[#c9a96e]/60 disabled:opacity-30">◀ zone</button>
          <button type="button" aria-label="Zone suivante" disabled={zi === ZONES.length - 1}
            onClick={() => allerZone(ZONES[zi + 1].id)}
            className="rounded-lg border border-white/12 px-3 py-1 font-mono text-[10px] text-white/70 transition hover:border-[#c9a96e]/60 disabled:opacity-30">zone ▶</button>
          {nbPages > 1 && (
            <>
              <span className="ml-1 font-mono text-[10px] text-white/35">{page + 1}/{nbPages}</span>
              <button type="button" aria-label="Page précédente" disabled={page === 0} onClick={() => setPage((p) => p - 1)}
                className="rounded-lg border border-white/12 px-2.5 py-1 text-[11px] text-white/70 transition hover:border-[#c9a96e]/60 disabled:opacity-30">◀</button>
              <button type="button" aria-label="Page suivante" disabled={page >= nbPages - 1} onClick={() => setPage((p) => p + 1)}
                className="rounded-lg border border-white/12 px-2.5 py-1 text-[11px] text-white/70 transition hover:border-[#c9a96e]/60 disabled:opacity-30">▶</button>
            </>
          )}
        </span>
      </div>
    </div>
  );
}