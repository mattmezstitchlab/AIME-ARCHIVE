import { MODES } from "@/components/bureau/claviers/universel/clavierModesData";
import { ROLES } from "@/components/devicelanding/causalKeyboardData";
import { SCREEN_MODES } from "@/components/devicelanding/causalScreenModes";
import { SITE_MODES } from "@/components/devicelanding/causalSiteScreens";

// ═══════════════════════════════════════════════════════════════════════════
// LE CLAVIER EN ZONES — comme un vrai clavier : chaque rangée a un métier.
// 1. SYSTÈME (la rangée F : accessibilité & affichage — actions réelles)
// 2. CONTEXTE (les mondes : rôles, couleurs, symboles, builder, pro, écrans)
// 3. VIVANTE (les touches se re-skinnent selon le monde — la cascade causale)
// 4. OPÉRATEURS (les touches latérales : % * $ € … à copier)
// 5. COMMANDES (la rangée basse : Internet · alt · espace · AI · Entrée)
// ═══════════════════════════════════════════════════════════════════════════

export const ZONES = [
  { id: "systeme", label: "Système", sub: "La rangée F — accessibilité & affichage, en direct sur le site." },
  { id: "contexte", label: "Contexte", sub: "Les mondes : presser un monde re-skinne la zone vivante." },
  { id: "vivante", label: "Vivante", sub: "Les touches du monde choisi — la cascade causale." },
  { id: "operateurs", label: "Opérateurs", sub: "Symboles, devises et opérateurs — pressez pour copier." },
  { id: "commandes", label: "Commandes", sub: "Internet · alt · espace · AI · Entrée = appliquer." },
];

// ── ZONE 1 · SYSTÈME — chaque touche agit RÉELLEMENT sur la page. ──────────
export const SYSTEME = [
  { cap: "esc", sub: "Réinitialise", action: { type: "systeme", id: "esc" } },
  { cap: "F1", sub: "Contraste −", action: { type: "systeme", id: "contrastMoins" } },
  { cap: "F2", sub: "Contraste +", action: { type: "systeme", id: "contrastPlus" } },
  { cap: "F3", sub: "Toutes les pages", action: { type: "naviguer", to: "/sante" } },
  { cap: "F4", sub: "Zoom +", action: { type: "systeme", id: "zoomPlus" } },
  { cap: "F5", sub: "Zoom −", action: { type: "systeme", id: "zoomMoins" } },
  { cap: "F6", sub: "Jour / Nuit", action: { type: "systeme", id: "nuit" } },
  { cap: "F7", sub: "Lire la page", action: { type: "systeme", id: "lire" } },
  { cap: "F8", sub: "Pause voix", action: { type: "systeme", id: "pause" } },
  { cap: "F9", sub: "Interligne +", action: { type: "systeme", id: "interligne" } },
  { cap: "F10", sub: "Animations off", action: { type: "systeme", id: "anim" } },
  { cap: "F11", sub: "Liens soulignés", action: { type: "systeme", id: "liens" } },
  { cap: "F12", sub: "Focus renforcé", action: { type: "systeme", id: "focus" } },
];

// ── ZONE 2 · CONTEXTE — les mondes (Entrée = l'action « appliquer » du monde).
const ENTREES = {
  couleurs: { type: "naviguer", to: "/design-system" },
  builder: { type: "naviguer", to: "/bureau/vitrine" },
  pro: { type: "app", app: "eaa" },
};

export const MONDES = [
  {
    id: "roles",
    label: "Rôles",
    accent: "#e0685c",
    tagline: "Dix rôles causals",
    touches: () =>
      ROLES.map((r) => ({
        cap: r.label,
        sub: "rôle causal",
        action: { type: "ecran", mode: "role", roleId: r.id, label: r.label },
      })),
  },
  ...MODES.map((m) => ({
    ...m,
    tagline:
      m.id === "couleurs" ? "HEX · RVB · CMJN" :
      m.id === "symboles" ? "Le langage AIME" :
      m.id === "builder" ? "Les blocs du site" : "Les surfaces pro",
    entree: ENTREES[m.id],
  })),
  {
    id: "ecrans",
    label: "Écrans",
    accent: "#38bdf8",
    tagline: "Affiche au centre du Bureau",
    touches: () =>
      [...SCREEN_MODES, ...SITE_MODES].map((m) => ({
        cap: m.label || m.id,
        sub: "écran",
        action: { type: "ecran", mode: m.id, label: m.label || m.id },
      })),
  },
];

export const CONTEXTE = MONDES.map((m) => ({
  cap: m.label,
  sub: m.tagline,
  action: { type: "monde", monde: m.id },
}));

// ── ZONE 4 · OPÉRATEURS — pressez pour copier. ─────────────────────────────
const OPS = [
  ["%", "pourcent"], ["‰", "pour mille"], ["×", "multiplier"], ["÷", "diviser"],
  ["±", "plus ou moins"], ["=", "égal"], ["≠", "différent"], ["≤", "inférieur ou égal"],
  ["≥", "supérieur ou égal"], ["€", "euro"], ["$", "dollar"], ["£", "livre"],
  ["#", "dièse"], ["&", "esperluette"], ["§", "section"], ["©", "copyright"],
  ["®", "marque déposée"], ["™", "trademark"], ["°", "degré"], ["—", "tiret long"],
  ["…", "points de suite"], ["·", "point médian"], ["«", "guillemet ouvrant"], ["»", "guillemet fermant"],
];
export const OPERATEURS = OPS.map(([s, nom]) => ({
  cap: s,
  sub: nom,
  action: { type: "copier", valeur: s },
}));

// ── ZONE 5 · COMMANDES — la rangée basse. ──────────────────────────────────
export const COMMANDES = [
  { cap: "INTERNET", sub: "Navigateur", action: { type: "naviguer", to: "/" } },
  { cap: "alt", sub: "Pouvoirs — les mondes", action: { type: "zone", zone: "contexte" } },
  { cap: "espace ◁)", sub: "Lire / Pause", action: { type: "systeme", id: "espace" } },
  { cap: "AI", sub: "Super-agent", action: { type: "ecran", mode: "ai", label: "Super-agent" } },
  { cap: "◀", sub: "Page précédente", action: { type: "pagePrev" } },
  { cap: "▶", sub: "Page suivante", action: { type: "pageNext" } },
  { cap: "Entrée ⏎", sub: "Appliquer au projet", action: { type: "entree" } },
];