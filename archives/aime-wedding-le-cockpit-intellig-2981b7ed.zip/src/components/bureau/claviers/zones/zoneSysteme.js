// LA RANGÉE SYSTÈME — les touches F agissent RÉELLEMENT sur le document :
// contraste, zoom, jour/nuit, lecture vocale, interligne, animations, liens.
const etat = { zoom: 100, contrast: 100, ligne: 0, nuit: false, anim: false, liens: false, focus: false };

function appliquer() {
  const el = document.documentElement;
  el.style.fontSize = etat.zoom === 100 ? "" : `${etat.zoom}%`;
  document.body.style.filter = [
    etat.contrast !== 100 ? `contrast(${etat.contrast}%)` : "",
    etat.nuit ? "invert(1) hue-rotate(180deg)" : "",
  ]
    .filter(Boolean)
    .join(" ");
  document.body.style.lineHeight = etat.ligne ? String(1.5 + etat.ligne * 0.2) : "";
  el.classList.toggle("aime-anim-off", etat.anim);
  el.classList.toggle("aime-liens-soulignes", etat.liens);
  el.classList.toggle("aime-focus-fort", etat.focus);
}

function lirePage() {
  const s = window.speechSynthesis;
  if (!s) return;
  s.cancel();
  const u = new SpeechSynthesisUtterance(document.body.innerText.slice(0, 2500));
  u.lang = "fr-FR";
  s.speak(u);
}

export function pressSysteme(id) {
  const s = window.speechSynthesis;
  if (id === "esc") {
    Object.assign(etat, { zoom: 100, contrast: 100, ligne: 0, nuit: false, anim: false, liens: false, focus: false });
    s?.cancel();
  } else if (id === "contrastMoins") etat.contrast = Math.max(60, etat.contrast - 10);
  else if (id === "contrastPlus") etat.contrast = Math.min(160, etat.contrast + 10);
  else if (id === "zoomPlus") etat.zoom = Math.min(140, etat.zoom + 10);
  else if (id === "zoomMoins") etat.zoom = Math.max(80, etat.zoom - 10);
  else if (id === "nuit") etat.nuit = !etat.nuit;
  else if (id === "lire") lirePage();
  else if (id === "pause") {
    if (s?.paused) s.resume();
    else s?.pause();
  } else if (id === "espace") {
    if (s?.speaking && !s.paused) s.pause();
    else if (s?.paused) s.resume();
    else lirePage();
  } else if (id === "interligne") etat.ligne = (etat.ligne + 1) % 4;
  else if (id === "anim") etat.anim = !etat.anim;
  else if (id === "liens") etat.liens = !etat.liens;
  else if (id === "focus") etat.focus = !etat.focus;
  appliquer();
}