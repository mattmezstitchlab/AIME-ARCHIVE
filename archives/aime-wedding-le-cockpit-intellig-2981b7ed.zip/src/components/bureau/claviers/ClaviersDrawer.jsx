import { useState, useEffect } from "react";
import { Keyboard, X } from "lucide-react";
import ClavierZones from "./zones/ClavierZones";
import ClavierContexteRow from "./ClavierContexteRow";

// L'encoche BASSE « CLAVIER » — UN SEUL clavier AI+ME, découpé en zones-slides
// comme un vrai clavier : Système (rangée F), Contexte (les mondes), Vivante
// (les touches re-skinnées), Opérateurs, Commandes. Les anciens onglets
// (Causal / Universel / EAA) sont devenus des zones et des mondes DE ce clavier.
export default function ClaviersDrawer() {
  const [open, setOpen] = useState(false);

  // ⌥K (alt+K) — le raccourci physique qui ouvre / replie le clavier.
  useEffect(() => {
    const h = (e) => {
      if (e.altKey && e.code === "KeyK") {
        e.preventDefault();
        setOpen((o) => !o);
      }
    };
    window.addEventListener("keydown", h);
    // Le bouton AI+ME (bas-centre) invoque aussi le clavier.
    const t = () => setOpen((o) => !o);
    window.addEventListener("aime-clavier-toggle", t);
    return () => {
      window.removeEventListener("keydown", h);
      window.removeEventListener("aime-clavier-toggle", t);
    };
  }, []);

  // Plus d'encoche visible : le clavier ne s'invoque QU'AU raccourci ⌥K.
  // C'est l'exercice de mémorisation — la surprise de le voir surgir.
  if (!open) return null;

  return (
    <aside
      className="fixed inset-x-0 bottom-0 z-[60] overflow-hidden border-t border-white/10 bg-[#0C0C0C]/95 backdrop-blur-md"
      aria-label="Le clavier AI+ME"
    >
      <div className="mx-auto max-w-6xl px-4 py-3">
        <div className="flex items-center justify-between">
          <p className="inline-flex items-center gap-2 font-mono text-[10px] font-semibold uppercase tracking-[0.24em] text-white/40">
            <Keyboard className="h-3.5 w-3.5 text-[#c9a96e]" /> Le Clavier AI+ME — un châssis, des zones
            <kbd className="rounded border border-white/15 px-1.5 py-0.5 font-mono text-[9px] normal-case tracking-normal text-white/45">⌥K</kbd>
          </p>
          <button
            type="button"
            onClick={() => setOpen(false)}
            aria-label="Replier le clavier"
            className="rounded-full p-1.5 text-white/40 hover:bg-white/10 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="mt-2 pb-3">
          {/* LA RANGÉE CONTEXTUELLE — recâblée par la surface courante. */}
          <ClavierContexteRow />
          <ClavierZones />
        </div>
      </div>
    </aside>
  );
}