// UNE TOUCHE du clavier universel — même gabarit pour tous les modes.
// Si la touche porte un fond (nuancier), le texte s'adapte au contraste.

const texteLisible = (hex) => {
  const n = parseInt(hex.slice(1), 16);
  const lum = 0.299 * ((n >> 16) & 255) + 0.587 * ((n >> 8) & 255) + 0.114 * (n & 255);
  return lum > 150 ? "#111111" : "#ffffff";
};

export default function ClavierTouche({ touche, copie, onPress }) {
  const fond = touche.fond;
  const copiee = copie && touche.action.type === "copier" && copie === touche.action.valeur;
  return (
    <button
      type="button"
      onClick={() => onPress(touche)}
      aria-label={`${touche.cap} — ${touche.sub}`}
      className="flex h-full flex-col justify-between rounded-xl border border-white/12 p-2.5 text-left transition hover:border-[#c9a96e]/70 hover:-translate-y-0.5"
      style={fond ? { background: fond, color: texteLisible(fond) } : { background: "rgba(255,255,255,0.03)", color: "#fff" }}
    >
      <span className="block truncate font-mono text-[13px] font-bold leading-tight">
        {copiee ? "Copié ✓" : touche.cap}
      </span>
      <span className="block truncate text-[10px]" style={{ opacity: 0.6 }}>
        {touche.sub}
      </span>
    </button>
  );
}