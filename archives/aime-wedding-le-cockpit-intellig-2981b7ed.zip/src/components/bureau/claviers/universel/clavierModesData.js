// ═══════════════════════════════════════════════════════════════════════════
// LE CLAVIER UNIVERSEL — les modes en DONNÉES PURES.
// Un mode = { id, label, accent, sousModes?, touches(sousMode) }.
// Chaque touche = { cap, sub, fond?, action: {type:"copier"|"naviguer", …} }.
// Ajouter un mode = ajouter un objet ici : le châssis fait le reste.
// ═══════════════════════════════════════════════════════════════════════════

const hexToRgb = (hex) => {
  const n = parseInt(hex.slice(1), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
};
const fmtRvb = (hex) => hexToRgb(hex).join(" · ");
const fmtCmjn = (hex) => {
  const [r, g, b] = hexToRgb(hex).map((v) => v / 255);
  const k = 1 - Math.max(r, g, b);
  if (k === 1) return "0 · 0 · 0 · 100";
  const f = (v) => Math.round(((1 - v - k) / (1 - k)) * 100);
  return `${f(r)} · ${f(g)} · ${f(b)} · ${Math.round(k * 100)}`;
};

const PALETTE = [
  { hex: "#C9A96E", nom: "Sable" },
  { hex: "#C9B88F", nom: "Sable clair" },
  { hex: "#8A9483", nom: "Sauge" },
  { hex: "#E0685C", nom: "Feu" },
  { hex: "#2E6F6A", nom: "Encre teal" },
  { hex: "#38BDF8", nom: "Ciel" },
  { hex: "#34D399", nom: "Menthe" },
  { hex: "#C084FC", nom: "Lilas" },
  { hex: "#F6F4EE", nom: "Ivoire" },
  { hex: "#111111", nom: "Noir studio" },
  { hex: "#0C0C0C", nom: "Velours" },
  { hex: "#FFFFFF", nom: "Blanc" },
];

const SYMBOLES = [
  { s: "@", nom: "Point Zéro" }, { s: "◉", nom: "Onde" }, { s: "→", nom: "Propagation" },
  { s: "⇄", nom: "Branchement" }, { s: "✓", nom: "Validé" }, { s: "⏸", nom: "Retenu" },
  { s: "⊘", nom: "Pare-feu" }, { s: "◎", nom: "Accessibilité" }, { s: "§", nom: "Section" },
  { s: "∀", nom: "Universel" }, { s: "★", nom: "Favori" }, { s: "✦", nom: "Essence" },
  { s: "◇", nom: "Module" }, { s: "⌘", nom: "Commande" }, { s: "…", nom: "Suite" }, { s: "®", nom: "AIME®" },
];

const BLOCS = [
  { nom: "Hero", sub: "Grand titre + visuel" }, { nom: "Texte", sub: "Paragraphe éditorial" },
  { nom: "Galerie", sub: "Mosaïque de visuels" }, { nom: "Témoignages", sub: "Paroles & preuves" },
  { nom: "Offres", sub: "Services / tarifs" }, { nom: "Appel à l'action", sub: "Bouton principal" },
  { nom: "Contact", sub: "Coordonnées réelles" }, { nom: "Pied de page", sub: "Mentions & accès" },
];

const SURFACES_PRO = [
  { nom: "Vitrine humaine", sub: "Portrait public digne", to: "/bureau/vitrine-humaine" },
  { nom: "Composer la vitrine", sub: "Assembler le site public", to: "/bureau/vitrine" },
  { nom: "Pipeline EAA", sub: "Audit & site conforme", app: "eaa" },
  { nom: "Design System", sub: "Couleurs & typos du site", to: "/design-system" },
  { nom: "Transmission", sub: "Mémoire du passé", to: "/embarquement-pro" },
  { nom: "Startup", sub: "Les projets AIME", to: "/startup" },
];

const FMT = { hex: (h) => h, rvb: fmtRvb, cmjn: fmtCmjn };

export const MODES = [
  {
    id: "couleurs", label: "Couleurs", accent: "#c9a96e",
    sousModes: [{ id: "hex", label: "HEX" }, { id: "rvb", label: "RVB" }, { id: "cmjn", label: "CMJN" }],
    touches: (sm) => PALETTE.map((c) => ({
      cap: FMT[sm || "hex"](c.hex), sub: c.nom, fond: c.hex,
      action: { type: "copier", valeur: FMT[sm || "hex"](c.hex) },
    })),
  },
  {
    id: "symboles", label: "Symboles", accent: "#c084fc",
    touches: () => SYMBOLES.map((k) => ({
      cap: k.s, sub: k.nom, action: { type: "copier", valeur: k.s },
    })),
  },
  {
    id: "builder", label: "Builder", accent: "#38bdf8",
    touches: () => BLOCS.map((b) => ({
      cap: b.nom, sub: b.sub, action: { type: "naviguer", to: "/bureau/vitrine" },
    })),
  },
  {
    id: "pro", label: "Pro", accent: "#34d399",
    touches: () => SURFACES_PRO.map((t) => ({
      cap: t.nom, sub: t.sub,
      action: t.app ? { type: "app", app: t.app } : { type: "naviguer", to: t.to },
    })),
  },
];