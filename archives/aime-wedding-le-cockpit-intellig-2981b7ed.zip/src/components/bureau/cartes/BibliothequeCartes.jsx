import { useState } from "react";
import { FolderOpen } from "lucide-react";

// LA BIBLIOTHÈQUE DE CARTES — sobre sur blanc : tout ce qui a été généré,
// affiché en cartes sur le canevas, filtrable par type de projet.
export default function BibliothequeCartes({ projects, onOpen }) {
  const [filtre, setFiltre] = useState("Tout");
  const types = [...new Set(projects.map((p) => p.project_type).filter(Boolean))];
  const visibles = filtre === "Tout" ? projects : projects.filter((p) => p.project_type === filtre);

  if (projects.length === 0) {
    return (
      <p className="mt-16 text-center font-mono text-[10px] uppercase tracking-[0.24em] text-neutral-300">
        Le canevas est prêt — appuyez sur + pour créer
      </p>
    );
  }

  return (
    <div className="mt-10">
      {/* LES FILTRES — capsules sobres. */}
      <div className="flex flex-wrap items-center justify-center gap-1.5">
        {["Tout", ...types].map((t) => (
          <button
            key={t}
            type="button"
            onClick={() => setFiltre(t)}
            aria-pressed={filtre === t}
            className={`rounded-full px-3.5 py-1.5 text-[11.5px] font-semibold transition ${
              filtre === t
                ? "bg-neutral-900 text-white"
                : "border border-neutral-200 bg-white text-neutral-500 hover:border-neutral-400 hover:text-neutral-900"
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      {/* LES CARTES — chaque génération est une carte, prête à s'assembler. */}
      <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {visibles.map((p) => {
          const nbQ = (p.questions || []).length;
          const nbR = Object.keys(p.answers || {}).length;
          return (
            <button
              key={p.id}
              type="button"
              onClick={() => onOpen(p)}
              className="group rounded-xl border border-neutral-200 bg-white p-4 text-left shadow-sm transition hover:border-neutral-400 hover:shadow-md"
            >
              <div className="flex items-center justify-between">
                <p className="font-mono text-[9px] font-semibold uppercase tracking-[0.2em] text-neutral-400">
                  {p.project_type || "Projet"}
                </p>
                <FolderOpen className="h-3.5 w-3.5 text-neutral-300 transition group-hover:text-neutral-500" />
              </div>
              <h3 className="mt-2 text-[15px] font-semibold leading-snug text-neutral-900">
                {p.project_title || p.intent}
              </h3>
              {p.intro && <p className="mt-1.5 line-clamp-2 text-[12px] leading-relaxed text-neutral-500">{p.intro}</p>}
              <p className="mt-3 font-mono text-[9px] uppercase tracking-[0.16em] text-neutral-400">
                {nbR}/{nbQ} réponses · {(p.facets || []).length} cartes
              </p>
            </button>
          );
        })}
      </div>
    </div>
  );
}