import { Radio, Users } from "lucide-react";

// L'ÉTAT DE L'ONDE — unique : elle se propage à l'infini (personne pour
// l'arrêter, personne pour s'y aligner). Partagée : alignement possible.
export default function SignatureEtat({ code, index, matches }) {
  if (!code) {
    return (
      <p className="text-[13px] leading-6 text-white/45">
        Réglez les 5 anneaux — une position par dimension — pour émettre votre signature.
      </p>
    );
  }
  const aligned = matches && matches.length > 0;
  return (
    <div className="space-y-3">
      <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-white/40">
        Signature <span className="text-[#c9a96e]">{code}</span> · n° {index} / 1024
      </p>
      {aligned ? (
        <div className="rounded-xl border border-emerald-400/30 bg-emerald-400/10 p-3">
          <p className="inline-flex items-center gap-2 text-[13px] font-semibold text-emerald-300">
            <Users className="h-4 w-4" /> Alignement — {matches.length} onde{matches.length > 1 ? "s" : ""} identique{matches.length > 1 ? "s" : ""}
          </p>
          <ul className="mt-1.5 space-y-0.5 text-[12px] text-white/60">
            {matches.map((m) => <li key={m.id}>{m.display_name || "Quelqu'un"} porte la même signature, maintenant.</li>)}
          </ul>
        </div>
      ) : (
        <div className="rounded-xl border border-[#c9a96e]/30 bg-[#c9a96e]/10 p-3">
          <p className="inline-flex items-center gap-2 text-[13px] font-semibold text-[#c9a96e]">
            <Radio className="h-4 w-4" /> Signature unique — l'onde se propage à l'infini
          </p>
          <p className="mt-1 text-[12px] leading-5 text-white/50">
            Vous êtes seul·e sur cette combinaison : rien ne l'arrête, rien ne peut encore s'y aligner.
          </p>
        </div>
      )}
    </div>
  );
}