// LES 5 DIMENSIONS UNIVERSELLES du moteur radial 5D — 4 positions chacune.
// 4^5 = 1024 signatures possibles. La signature n'est pas un profil figé :
// c'est un ÉTAT VIVANT, réglé dans l'instant, propagé en onde depuis le Point Zéro.
export const DIMENSIONS_5D = [
  {
    key: "presence",
    label: "Présence",
    question: "Comment suis-je là, maintenant ?",
    color: "#c9a96e",
    options: ["Présent·e", "Masqué·e", "En veille", "Invisible"],
  },
  {
    key: "envie",
    label: "Envie",
    question: "Mon envie dans l'instant ?",
    color: "#34d399",
    options: ["Créer", "Rencontrer", "Recevoir", "Me poser"],
  },
  {
    key: "etat",
    label: "État",
    question: "Ma météo intérieure ?",
    color: "#38bdf8",
    options: ["Lumineux", "Calme", "Orageux", "Sombre"],
  },
  {
    key: "intention",
    label: "Intention",
    question: "Ce que je veux offrir ?",
    color: "#c084fc",
    options: ["Donner", "Apprendre", "Construire", "Transmettre"],
  },
  {
    key: "rythme",
    label: "Rythme",
    question: "Mon tempo ?",
    color: "#f472b6",
    options: ["Immédiat", "Aujourd'hui", "Cette semaine", "Sans hâte"],
  },
];

// Le code lisible « 2-1-4-3-1 » et le numéro de la signature sur 1024.
export function signatureCode(values) {
  if (DIMENSIONS_5D.some((d) => values?.[d.key] == null)) return null;
  return DIMENSIONS_5D.map((d) => values[d.key] + 1).join("-");
}

export function signatureIndex(values) {
  if (DIMENSIONS_5D.some((d) => values?.[d.key] == null)) return null;
  return DIMENSIONS_5D.reduce((n, d) => n * 4 + values[d.key], 0) + 1;
}