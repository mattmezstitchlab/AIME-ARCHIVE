import { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { DIMENSIONS_5D, signatureCode, signatureIndex } from "./signatureDimensions";
import SignatureAnneaux from "./SignatureAnneaux";
import SignatureEtat from "./SignatureEtat";

// LE MOTEUR RADIAL 5D — 5 dimensions universelles × 4 positions = 1024
// signatures. La signature est un état vivant : réglée dans l'instant,
// émise depuis le Point Zéro. Unique → l'onde file à l'infini.
// Partagée → alignement possible avec ceux qui portent la même.
export default function MoteurRadial5D() {
  const [values, setValues] = useState({});
  const [matches, setMatches] = useState(null);
  const recId = useRef(null);
  const userRef = useRef(null);
  const timer = useRef(null);

  useEffect(() => {
    (async () => {
      const user = await base44.auth.me().catch(() => null);
      userRef.current = user;
      if (!user) return;
      const [rec] = await base44.entities.Signature5D.filter({ created_by_id: user.id });
      if (rec) {
        recId.current = rec.id;
        setValues(rec.values || {});
        if (rec.code) refreshMatches(rec.code);
      }
    })();
    return () => clearTimeout(timer.current);
  }, []);

  const refreshMatches = async (code) => {
    const same = await base44.entities.Signature5D.filter({ code });
    setMatches(same.filter((r) => r.id !== recId.current));
  };

  const handleSelect = (dimKey, i) => {
    const v = { ...values, [dimKey]: i };
    setValues(v);
    const code = signatureCode(v);
    if (!code) return;
    setMatches(null);
    clearTimeout(timer.current);
    timer.current = setTimeout(async () => {
      const payload = { code, values: v, display_name: userRef.current?.full_name || "Anonyme" };
      if (recId.current) {
        await base44.entities.Signature5D.update(recId.current, payload);
      } else {
        recId.current = (await base44.entities.Signature5D.create(payload)).id;
      }
      refreshMatches(code);
    }, 700);
  };

  const code = signatureCode(values);
  return (
    <div className="grid gap-6 md:grid-cols-2 md:items-center">
      <SignatureAnneaux values={values} onSelect={handleSelect} unique={!!code && matches?.length === 0} />
      <div className="space-y-4">
        {DIMENSIONS_5D.map((dim, ringIdx) => (
          <div key={dim.key}>
            <p className="font-mono text-[10px] uppercase tracking-[0.2em]" style={{ color: dim.color }}>
              Anneau {ringIdx + 1} — {dim.label} · <span className="text-white/40 normal-case tracking-normal">{dim.question}</span>
            </p>
            <div className="mt-1.5 flex flex-wrap gap-1.5">
              {dim.options.map((opt, i) => (
                <button key={i} type="button" onClick={() => handleSelect(dim.key, i)}
                  aria-pressed={values[dim.key] === i}
                  className={`rounded-full border px-3 py-1 text-[12px] transition-colors ${
                    values[dim.key] === i
                      ? "border-transparent font-semibold text-black"
                      : "border-white/15 text-white/60 hover:border-white/35 hover:text-white"
                  }`}
                  style={values[dim.key] === i ? { background: dim.color } : undefined}
                >
                  {opt}
                </button>
              ))}
            </div>
          </div>
        ))}
        <SignatureEtat code={code} index={signatureIndex(values)} matches={matches} />
      </div>
    </div>
  );
}