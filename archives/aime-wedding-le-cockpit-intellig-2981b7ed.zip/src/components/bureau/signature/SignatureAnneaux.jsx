import { DIMENSIONS_5D, signatureCode } from "./signatureDimensions";

// LE CADRAN 5D — 5 anneaux concentriques (un par dimension), 4 positions
// cliquables par anneau. Le centre est le Point Zéro : il affiche la
// signature courante et émet l'onde tant qu'elle est unique.
const C = 170;
const RADII = [58, 82, 106, 130, 154];

export default function SignatureAnneaux({ values, onSelect, unique }) {
  const code = signatureCode(values);
  return (
    <svg viewBox="0 0 340 340" className="mx-auto w-full max-w-[380px]" role="group" aria-label="Cadran de la signature 5D">
      {/* L'onde du Point Zéro — ne pulse que si la signature est unique. */}
      {code && unique && [0, 1, 2].map((i) => (
        <circle key={i} cx={C} cy={C} r={30} fill="none" stroke="#c9a96e" strokeWidth="1"
          className="sig5d-onde" style={{ animationDelay: `${i * 1.1}s` }} />
      ))}
      {DIMENSIONS_5D.map((dim, ringIdx) => {
        const r = RADII[ringIdx];
        return (
          <g key={dim.key}>
            <circle cx={C} cy={C} r={r} fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="1" />
            {dim.options.map((opt, i) => {
              // 4 positions par anneau, légèrement décalées d'un anneau à l'autre.
              const a = ((i * 90 + ringIdx * 18 - 90) * Math.PI) / 180;
              const x = C + r * Math.cos(a);
              const y = C + r * Math.sin(a);
              const selected = values?.[dim.key] === i;
              return (
                <g key={i} onClick={() => onSelect(dim.key, i)} className="cursor-pointer" role="button" aria-label={`${dim.label} : ${opt}`}>
                  <circle cx={x} cy={y} r={10} fill={selected ? dim.color : "#1a1a1a"}
                    stroke={selected ? dim.color : "rgba(255,255,255,0.25)"} strokeWidth="1.5" />
                  <text x={x} y={y + 3} textAnchor="middle" fontSize="8" fontFamily="monospace"
                    fill={selected ? "#111" : "rgba(255,255,255,0.5)"}>{i + 1}</text>
                </g>
              );
            })}
          </g>
        );
      })}
      {/* LE POINT ZÉRO — la signature au centre. */}
      <circle cx={C} cy={C} r={34} fill="#111" stroke="rgba(255,255,255,0.15)" strokeWidth="1" />
      <text x={C} y={C + 4} textAnchor="middle" fontSize="12" fontFamily="monospace" fontWeight="600"
        fill={code ? "#c9a96e" : "rgba(255,255,255,0.3)"}>
        {code || "· · · · ·"}
      </text>
    </svg>
  );
}