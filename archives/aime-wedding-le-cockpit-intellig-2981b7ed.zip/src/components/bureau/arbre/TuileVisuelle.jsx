import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Repeat2, FileText, ArrowRight } from "lucide-react";

const KEY = "aime-arbre-verso-v1";
const loadNotes = () => {
  try { return JSON.parse(localStorage.getItem(KEY)) || {}; } catch { return {}; }
};

// UNE TUILE DU MODE VISUEL — façon iOS, mais retournable : le recto est
// l'icône, le verso est configurable (note personnelle + action d'ouverture).
export default function TuileVisuelle({ node, onEnter }) {
  const [flipped, setFlipped] = useState(false);
  const [note, setNote] = useState(() => loadNotes()[node.id] || "");
  const navigate = useNavigate();
  const Icon = node.icon || FileText;
  const isFolder = !!node.children?.length;

  const ouvrir = () => {
    if (isFolder) return onEnter();
    if (node.action) return node.action();
    if (node.to) navigate(node.to);
  };

  const saveNote = () => {
    const all = loadNotes();
    all[node.id] = note;
    try { localStorage.setItem(KEY, JSON.stringify(all)); } catch { /* ignore */ }
  };

  return (
    <div className="relative h-[104px]" style={{ perspective: "600px" }}>
      <div
        className="relative h-full w-full transition-transform duration-500"
        style={{ transformStyle: "preserve-3d", transform: flipped ? "rotateY(180deg)" : "none" }}
      >
        {/* RECTO — l'icône, comme sur iOS. */}
        <button
          type="button"
          onClick={ouvrir}
          className="absolute inset-0 flex flex-col items-center justify-center gap-1.5 rounded-2xl border border-white/10 bg-white/[0.04] transition-colors hover:border-white/30 hover:bg-white/[0.07]"
          style={{ backfaceVisibility: "hidden" }}
        >
          <Icon className="h-5 w-5" style={{ color: node.color || "#c9a96e" }} strokeWidth={1.6} />
          <span className="max-w-full truncate px-1.5 text-[9.5px] font-medium leading-3 text-white/85">
            {node.label}
          </span>
          {node.badge && <span className="font-mono text-[8px] text-white/35">{node.badge}</span>}
        </button>

        {/* VERSO — configurable : la note personnelle + l'ouverture. */}
        <div
          className="absolute inset-0 flex flex-col rounded-2xl border border-[#c9a96e]/40 bg-[#141414] p-1.5"
          style={{ backfaceVisibility: "hidden", transform: "rotateY(180deg)" }}
        >
          <p className="truncate px-0.5 font-mono text-[7.5px] uppercase tracking-[0.14em] text-[#c9a96e]">
            {node.label}
          </p>
          <textarea
            value={note}
            onChange={(e) => setNote(e.target.value)}
            onBlur={saveNote}
            placeholder={node.summary || "Ma note…"}
            className="mt-1 min-h-0 flex-1 resize-none rounded-md border border-white/10 bg-black/40 px-1.5 py-1 text-[9px] text-white/75 placeholder:text-white/25 focus:border-white/30 focus:outline-none"
          />
          <button
            type="button"
            onClick={ouvrir}
            className="mt-1 inline-flex items-center justify-center gap-1 rounded-md bg-white/10 py-0.5 text-[8.5px] font-semibold text-white hover:bg-white/20"
          >
            {isFolder ? "Entrer" : "Ouvrir"} <ArrowRight className="h-2.5 w-2.5" />
          </button>
        </div>
      </div>

      {/* LA BASCULE — retourner la tuile, toujours accessible. */}
      <button
        type="button"
        onClick={() => setFlipped((f) => !f)}
        aria-label={`Retourner ${node.label}`}
        className="absolute -right-1 -top-1 z-10 rounded-full border border-white/15 bg-black p-1 text-white/50 hover:text-white"
      >
        <Repeat2 className="h-2.5 w-2.5" />
      </button>
    </div>
  );
}