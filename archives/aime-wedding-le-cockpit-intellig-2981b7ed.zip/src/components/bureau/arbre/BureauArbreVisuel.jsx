import { useState } from "react";
import { ChevronLeft } from "lucide-react";
import TuileVisuelle from "./TuileVisuelle";

// LE MODE VISUEL DE L'ARBRE — une grille de tuiles façon iOS : on entre dans
// les dossiers niveau par niveau, et chaque tuile se retourne (verso
// configurable). Zéro doublon : mêmes nœuds que le mode texte.
export default function BureauArbreVisuel({ nodes }) {
  const [pile, setPile] = useState([]);
  const niveau = pile.length ? pile[pile.length - 1] : { label: null, nodes };

  return (
    <div>
      {pile.length > 0 && (
        <button
          type="button"
          onClick={() => setPile((p) => p.slice(0, -1))}
          className="mb-2 inline-flex items-center gap-1 rounded-full px-2 py-1 font-mono text-[9px] uppercase tracking-[0.16em] text-white/50 hover:bg-white/10 hover:text-white"
        >
          <ChevronLeft className="h-3 w-3" /> {niveau.label}
        </button>
      )}
      <div className="grid grid-cols-3 gap-2">
        {niveau.nodes.map((n) => (
          <TuileVisuelle
            key={n.id}
            node={n}
            onEnter={() =>
              n.children?.length && setPile((p) => [...p, { label: n.label, nodes: n.children }])
            }
          />
        ))}
      </div>
    </div>
  );
}