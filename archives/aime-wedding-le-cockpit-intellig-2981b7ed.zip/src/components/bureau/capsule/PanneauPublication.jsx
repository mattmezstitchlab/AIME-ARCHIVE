import { useState, useEffect } from "react";
import { X, Globe, Check, Loader2, History, ExternalLink } from "lucide-react";
import { base44 } from "@/api/base44Client";

// LA PUBLICATION +NOM — le bout du pipeline : choisir l'adresse, vérifier
// sa disponibilité, publier / dépublier, et restaurer une version.
const CLE = "aime-studio-publication";
const slugifier = (t) =>
  t.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/^\+/, "").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");

export default function PanneauPublication({ siteName, style, design, pages, onClose }) {
  const memo = (() => { try { return JSON.parse(localStorage.getItem(CLE)) || null; } catch { return null; } })();
  const [slug, setSlug] = useState(memo?.slug || slugifier(siteName || ""));
  const [etat, setEtat] = useState(null); // null | verif | libre | pris | mien
  const [rec, setRec] = useState(null);
  const [action, setAction] = useState(null); // publie | depublie | restaure
  const [msg, setMsg] = useState("");

  // Recharge l'enregistrement publié de ce navigateur (versions, statut).
  useEffect(() => {
    if (memo?.id) base44.entities.PublishedSite.filter({ id: memo.id }).then(([r]) => setRec(r || null));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const verifier = async () => {
    const s = slugifier(slug);
    if (!s) return;
    setSlug(s); setEtat("verif"); setMsg("");
    const [existant] = await base44.entities.PublishedSite.filter({ slug: s });
    if (!existant) setEtat("libre");
    else if (memo?.id && existant.id === memo.id) { setEtat("mien"); setRec(existant); }
    else setEtat("pris");
  };

  const contenu = () => ({ type: "studio", siteName, style, design, pages });

  const publier = async () => {
    const s = slugifier(slug);
    if (!s) return;
    setAction("publie"); setMsg("");
    if (rec && memo?.slug === s) {
      // Nouvelle version : l'ancienne entre dans l'historique (10 max).
      const versions = [{ date: new Date().toISOString(), contenu: { pages: rec.site?.pages, design: rec.site?.design } }, ...(rec.site?.versions || [])].slice(0, 10);
      const maj = await base44.entities.PublishedSite.update(rec.id, {
        titre: siteName, published: true, site: { ...contenu(), versions },
      });
      setRec(maj);
    } else {
      const [existant] = await base44.entities.PublishedSite.filter({ slug: s });
      if (existant && existant.id !== memo?.id) { setAction(null); setEtat("pris"); return; }
      const cree = existant
        ? await base44.entities.PublishedSite.update(existant.id, { titre: siteName, published: true, site: { ...contenu(), versions: existant.site?.versions || [] } })
        : await base44.entities.PublishedSite.create({ slug: s, titre: siteName, role_label: "Studio AI+ME", published: true, site: { ...contenu(), versions: [] } });
      localStorage.setItem(CLE, JSON.stringify({ id: cree.id, slug: s }));
      setRec(cree);
    }
    setEtat("mien"); setAction(null); setMsg(`Publié sur +${s}`);
  };

  const depublier = async () => {
    if (!rec) return;
    setAction("depublie");
    const maj = await base44.entities.PublishedSite.update(rec.id, { published: false });
    setRec(maj); setAction(null); setMsg("Site dépublié — l'adresse est conservée.");
  };

  const restaurer = async (v, idx) => {
    if (!rec) return;
    setAction("restaure");
    const versions = [{ date: new Date().toISOString(), contenu: { pages: rec.site?.pages, design: rec.site?.design } }, ...(rec.site?.versions || []).filter((_, i) => i !== idx)].slice(0, 10);
    const maj = await base44.entities.PublishedSite.update(rec.id, {
      site: { ...rec.site, pages: v.contenu.pages, design: v.contenu.design, versions },
    });
    setRec(maj); setAction(null); setMsg("Version restaurée sur l'adresse publiée.");
  };

  const badge = {
    verif: ["Vérification…", "text-white/50"],
    libre: ["Adresse libre ✓", "text-[#7FDCB2]"],
    pris: ["Adresse déjà prise", "text-[#F2A7C3]"],
    mien: ["C'est votre adresse", "text-[#7FC3F0]"],
  }[etat];

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/70 p-4" role="dialog" aria-modal="true" aria-label="Publication de l'adresse +nom">
      <section className="ripple-wave w-full max-w-lg rounded-3xl border border-white/10 bg-[#0e0e11] p-5 shadow-2xl">
        <div className="mb-4 flex items-center justify-between gap-3">
          <p className="flex items-center gap-2 text-[14px] font-extrabold text-white">
            <Globe className="h-4 w-4 text-[#7FC3F0]" aria-hidden="true" /> Publier sur une adresse +nom
          </p>
          <button type="button" onClick={onClose} aria-label="Fermer la publication"
            className="flex h-9 w-9 items-center justify-center rounded-full text-white/60 transition hover:bg-white/10 hover:text-white">
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* L'adresse : choisir, vérifier. */}
        <div className="flex items-center gap-2 rounded-full border border-white/15 bg-white/[0.03] p-1.5 pl-4 focus-within:border-white/40">
          <span className="text-[15px] font-bold text-white/60" aria-hidden="true">+</span>
          <input value={slug} onChange={(e) => { setSlug(e.target.value); setEtat(null); }}
            placeholder="votre-nom" aria-label="Adresse +nom souhaitée"
            className="min-h-[40px] flex-1 bg-transparent text-[14px] text-white outline-none placeholder:text-white/40 focus-visible:!shadow-none" />
          <button type="button" onClick={verifier} disabled={!slug.trim() || etat === "verif"}
            className="flex min-h-[40px] items-center rounded-full bg-white/10 px-4 text-[12px] font-bold text-white transition hover:bg-white/20 disabled:opacity-40">
            {etat === "verif" ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> : "Vérifier"}
          </button>
        </div>
        {badge && <p className={`mt-2 text-[12px] font-semibold ${badge[1]}`} role="status">{badge[0]}</p>}

        {/* Publier / dépublier. */}
        <div className="mt-4 flex flex-wrap items-center gap-2">
          <button type="button" onClick={publier} disabled={!slug.trim() || etat === "pris" || !!action}
            className="flex min-h-[44px] items-center gap-2 rounded-full px-6 text-[13px] font-bold text-black transition hover:opacity-90 disabled:opacity-40"
            style={{ background: "linear-gradient(90deg, #F2A7C3, #E8C97F, #7FDCB2, #7FC3F0, #C9A2F5)" }}>
            {action === "publie" ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> : <Check className="h-4 w-4" aria-hidden="true" />}
            {rec?.published && memo?.slug === slugifier(slug) ? "Republier (nouvelle version)" : "Publier"}
          </button>
          {rec?.published && (
            <>
              <a href={`/+${rec.slug}`} target="_blank" rel="noopener noreferrer"
                className="flex min-h-[44px] items-center gap-1.5 rounded-full border border-white/20 px-5 text-[12px] font-semibold text-white transition hover:border-white/50">
                Voir +{rec.slug} <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
              </a>
              <button type="button" onClick={depublier} disabled={!!action}
                className="flex min-h-[44px] items-center rounded-full px-4 text-[12px] font-semibold text-white/60 transition hover:bg-white/5 hover:text-white">
                Dépublier
              </button>
            </>
          )}
        </div>
        {msg && <p className="mt-3 text-[12px] font-semibold text-[#7FDCB2]" role="status">{msg}</p>}

        {/* L'historique des versions — restaurer un état précédent. */}
        {rec?.site?.versions?.length > 0 && (
          <div className="mt-5 border-t border-white/10 pt-4">
            <p className="mb-2 flex items-center gap-1.5 font-mono text-[11px] font-semibold uppercase tracking-[0.18em] text-white/50">
              <History className="h-3.5 w-3.5" aria-hidden="true" /> Versions précédentes
            </p>
            <ul className="space-y-1.5">
              {rec.site.versions.map((v, i) => (
                <li key={v.date} className="flex items-center justify-between gap-3 rounded-xl bg-white/[0.03] px-3 py-2">
                  <span className="text-[12px] text-white/70">{new Date(v.date).toLocaleString("fr-FR")}</span>
                  <button type="button" onClick={() => restaurer(v, i)} disabled={!!action}
                    className="rounded-full border border-white/15 px-3 py-1 text-[11px] font-semibold text-white/80 transition hover:border-white/50 disabled:opacity-40">
                    Restaurer
                  </button>
                </li>
              ))}
            </ul>
          </div>
        )}
      </section>
    </div>
  );
}