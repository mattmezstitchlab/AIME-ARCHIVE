import { useState, useEffect } from "react";
import { X, PanelsTopLeft, Boxes, LayoutGrid, Trash2 } from "lucide-react";
import { chargerElements, sauverElements, trierElement } from "@/lib/bureau/capsuleTriage";
import { SECTIONS_SITE, chargerSite, sauverSite, genererSection, genererVisuelSection } from "@/lib/bureau/sectionEtiquettes";
import { loadEaaProject, saveEaaProject, clearEaaProject } from "@/lib/gallery/eaaProject";
import PanneauArbre from "@/components/bureau/capsule/PanneauArbre";
import PanneauCanevas from "@/components/bureau/capsule/PanneauCanevas";
import PanneauEtiquettes from "@/components/bureau/capsule/PanneauEtiquettes";
import PanneauSiteCanvas from "@/components/bureau/capsule/PanneauSiteCanvas";
import PanneauPipeline from "@/components/bureau/capsule/PanneauPipeline";
import PanneauPages from "@/components/bureau/capsule/PanneauPages";
import PanneauReglages from "@/components/bureau/capsule/PanneauReglages";
import PointZeroDepot from "@/components/bureau/capsule/PointZeroDepot";
import PanneauPublication from "@/components/bureau/capsule/PanneauPublication";

// LE PANNEAU DU + — le studio du projet, comme un Wix ultra simple :
// dossiers + étiquettes à gauche · canevas-site VERTICAL au centre (les
// sections se génèrent dedans, dans la DA choisie) · design à droite ·
// dépôt Point Zéro en bas. À la fin : les cartes définitives.
export default function CapsulePanneau({ onClose, onPipeline }) {
  // L'audit en cours (pipeline EAA) fournit la DA et le nom du site.
  const [eaa, setEaa] = useState(() => loadEaaProject());
  // Les réglages faits dans la vue Audit se propagent au dossier du pipeline.
  const majReport = (report) => {
    const next = { ...(eaa || {}), report };
    setEaa(next);
    saveEaaProject(next);
  };
  const style = eaa?.style || null;
  const siteName = eaa?.report?.site_name || "Votre site";

  // Dépôts Point Zéro (triés) + état du site (sections posées, design).
  const [items, setItems] = useState(() => chargerElements());
  const [vue, setVue] = useState("site"); // site | pages | depots
  // MULTI-PAGES — chaque page auditée a son propre canevas de sections.
  const [parPage, setParPage] = useState(() => {
    const s = chargerSite();
    return s.sectionsParPage || { accueil: s.sections || [] };
  });
  const [pageActive, setPageActive] = useState(() => {
    const s = chargerSite();
    return s.pageActive || Object.keys(s.sectionsParPage || { accueil: 1 })[0];
  });
  const sections = parPage[pageActive] || [];
  const setSections = (updater) => setParPage((prev) => ({
    ...prev,
    [pageActive]: typeof updater === "function" ? updater(prev[pageActive] || []) : updater,
  }));
  const [design, setDesign] = useState(() => chargerSite().design || { accent: null, typo: "sans", radius: "doux", texteMode: "synthetique" });
  const [absorbe, setAbsorbe] = useState(false);
  const [pub, setPub] = useState(false); // la publication +nom (bout du pipeline)

  const [filtre, setFiltre] = useState(null);
  const [selItemId, setSelItemId] = useState(null);
  const [selSectionId, setSelSectionId] = useState(null);
  const [selChip, setSelChip] = useState(null);

  useEffect(() => { sauverElements(items); }, [items]);
  useEffect(() => {
    sauverSite({ ...chargerSite(), sectionsParPage: parPage, pageActive, design });
  }, [parPage, pageActive, design]);

  const patcherItem = (id, patch) => setItems((prev) => prev.map((i) => (i.id === id ? { ...i, ...patch } : i)));
  const patcherSection = (id, patch) => setSections((prev) => prev.map((s) => (s.id === id ? { ...s, ...patch } : s)));

  // Dépôt → tri Point Zéro (nourrit aussi les dégradés des étiquettes).
  const deposer = async (depot) => {
    const id = `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    setItems((prev) => [...prev, { id, ...depot, dossier: null, garde: null, x: 30 + (prev.length % 4) * 165, y: 30 + Math.floor(prev.length / 4) * 120 }]);
    const tri = await trierElement(depot);
    patcherItem(id, { label: tri.label || depot.label, dossier: tri.dossier, garde: tri.garde, transformation: tri.transformation, motif: tri.motif });
  };

  // Glisser-déposer une étiquette → la section apparaît DÉJÀ FAITE :
  // générée dans le canevas, nourrie par les dépôts, dans la DA.
  const ajouterSection = async (key) => {
    const def = SECTIONS_SITE.find((s) => s.key === key);
    if (!def || sections.some((s) => s.key === key)) return;
    const id = `${Date.now()}-${key}`;
    setSections((prev) => [...prev, { id, key, label: def.label, status: "gen" }]);
    setSelSectionId(id); setSelChip(null);
    try {
      const res = await genererSection({ def, items, style, siteName, mode: design.texteMode });
      patcherSection(id, { status: "ok", heading: res.heading, body: res.body, cta: res.cta || "" });
    } catch {
      patcherSection(id, { status: "ok", heading: def.label, body: "" });
    }
  };

  const regenerer = async (id) => {
    const s = sections.find((x) => x.id === id);
    // Sections « origine » (versées par le pipeline) : pas d'étiquette au
    // catalogue — on génère depuis leur libellé + texte d'origine (base).
    const def = SECTIONS_SITE.find((d) => d.key === s?.key) || (s ? { key: s.key, label: s.label } : null);
    if (!s || !def) return;
    patcherSection(id, { status: "gen" });
    try {
      const res = await genererSection({ def, items, style, siteName, mode: design.texteMode, base: s.base || "" });
      patcherSection(id, { status: "ok", heading: res.heading, body: res.body, cta: res.cta || "" });
    } catch {
      patcherSection(id, { status: "ok" });
    }
  };

  // À L'OUVERTURE D'UNE PAGE — ses sections versées par le pipeline (statut
  // « gen ») se génèrent dans la DA, une seule fois chacune.
  useEffect(() => {
    sections
      .filter((s) => s.status === "gen" && !s.lance)
      .forEach((s) => { patcherSection(s.id, { lance: true }); regenerer(s.id); });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pageActive]);

  // TEXTE ABSORBÉ — applique le mode choisi (synthétique / régénéré) à
  // toutes les sections posées, l'une après l'autre.
  const absorberTextes = async () => {
    setAbsorbe(true);
    for (const s of sections) { await regenerer(s.id); }
    setAbsorbe(false);
  };

  // L'arborescence du site d'origine (pages absorbées par l'audit).
  const pages = eaa?.report?.pages || [];
  const majPages = (next) => { if (eaa?.report) majReport({ ...eaa.report, pages: next }); };

  const genererVisuel = async (id) => {
    const s = sections.find((x) => x.id === id);
    const def = SECTIONS_SITE.find((d) => d.key === s?.key);
    if (!s || !def) return;
    patcherSection(id, { visuel_gen: true });
    try {
      const url = await genererVisuelSection({ def, section: s, style });
      patcherSection(id, { visuel_gen: false, image_url: url });
    } catch {
      patcherSection(id, { visuel_gen: false });
    }
  };

  const retirerSection = (id) => {
    setSections((prev) => prev.filter((s) => s.id !== id));
    if (selSectionId === id) setSelSectionId(null);
  };

  // LA FIN DE TOUT — les cartes définitives : embarquables, partageables,
  // vendables — le projet à cartes est créé dans le Bureau.
  const genererCartes = () => {
    window.dispatchEvent(new CustomEvent("aime-eaa-projet", {
      detail: {
        intent: `Site : ${siteName}`,
        complexity: 2,
        project_title: siteName,
        project_type: "Mini-site · cartes définitives",
        intro: `J'ai assemblé ${sections.length} sections — je les transforme en cartes définitives, embarquables et partageables.`,
        direction: style ? { style_name: style.name || "", palette: style.palette || [], typo_titres: style.typography || "", typo_texte: "" } : null,
        visuals: [...(style?.hero_url ? [style.hero_url] : []), ...sections.map((s) => s.image_url).filter(Boolean)].slice(0, 6),
        questions: sections.map((s) => ({ id: `sec_${s.key}`, label: `Section ${s.label} — à ajuster ?`, hint: s.heading, folder: "Sections", type: "text" })),
        answers: {},
      },
    }));
    onClose();
  };

  // VIDER LE STUDIO — efface l'audit, les sections et les dépôts mémorisés
  // dans le navigateur : le studio repart complètement à zéro.
  const viderStudio = () => {
    if (!window.confirm("Vider le studio ? L'audit, les pages et les dépôts en cours seront effacés.")) return;
    clearEaaProject();
    sauverSite({});
    sauverElements([]);
    setEaa(null);
    setItems([]);
    setParPage({ accueil: [] });
    setPageActive("accueil");
    setDesign({ accent: null, typo: "sans", radius: "doux", texteMode: "synthetique" });
    setSelItemId(null); setSelSectionId(null); setSelChip(null);
  };

  const selItem = items.find((i) => i.id === selItemId);
  const selSection = sections.find((s) => s.id === selSectionId);

  return (
    <section className="ripple-wave mt-5 flex h-[74vh] w-full max-w-6xl flex-col rounded-3xl border border-white/10 bg-[#0e0e11]/95 shadow-2xl backdrop-blur-xl"
      aria-label="Studio du projet — Point Zéro">
      {/* En-tête */}
      <div className="flex items-center justify-between gap-3 border-b border-white/10 px-4 py-3">
        <p className="flex items-center gap-2 text-[13px] font-extrabold text-white">
          <span className="flex h-6 w-6 items-center justify-center rounded-full bg-[conic-gradient(from_0deg,#ff5f6d,#ffc371,#c9f76f,#38bdf8,#c084fc,#ff5f6d)] text-[11px] font-bold text-black">+</span>
          {eaa?.report ? `Audit en cours · ${siteName}` : "Studio du projet"}
          {style?.name && (
            <span className="font-mono text-[8px] font-semibold uppercase tracking-[0.22em] text-white/35">DA · {style.name}</span>
          )}
        </p>
        <div className="flex items-center gap-1.5">
          {/* VIDER — repartir d'un studio vierge. */}
          <button type="button" onClick={viderStudio} aria-label="Vider le studio — tout effacer"
            className="flex h-9 w-9 items-center justify-center rounded-full text-white/50 transition hover:bg-white/10 hover:text-white">
            <Trash2 className="h-4 w-4" aria-hidden="true" />
          </button>
          {/* PUBLIER — le bout du pipeline : l'adresse +nom. */}
          <button type="button" onClick={() => setPub(true)}
            className="flex min-h-[32px] items-center rounded-full px-4 text-[11px] font-bold text-black transition hover:opacity-90"
            style={{ background: "linear-gradient(90deg, #F2A7C3, #E8C97F, #7FDCB2, #7FC3F0, #C9A2F5)" }}>
            Publier
          </button>
          {/* Bascule canevas-site / dépôts libres */}
          <div className="flex gap-0.5 rounded-full bg-white/5 p-0.5" role="tablist" aria-label="Vue du canevas">
            {[["site", "Site", PanelsTopLeft], ["pages", "Pages", LayoutGrid], ["depots", "Dépôts", Boxes]].map(([v, lab, Icon]) => (
              <button key={v} type="button" role="tab" aria-selected={vue === v} onClick={() => setVue(v)}
                className={`flex min-h-[32px] items-center gap-1.5 rounded-full px-3 text-[11px] font-semibold transition ${vue === v ? "bg-white text-black" : "text-white/50 hover:text-white"}`}>
                <Icon className="h-3.5 w-3.5" aria-hidden="true" /> {lab}
              </button>
            ))}
          </div>
          <button type="button" onClick={onClose} aria-label="Fermer le studio du projet"
            className="flex h-9 w-9 items-center justify-center rounded-full text-white/50 transition hover:bg-white/10 hover:text-white">
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Corps : dossiers + étiquettes · canevas · design/réglages.
          L'audit, lui, se lance via le bouton AI (Pipeline EAA). */}
      <div className="grid min-h-0 flex-1 grid-cols-[210px_1fr] lg:grid-cols-[210px_1fr_260px]">
        <div className="flex min-h-0 flex-col overflow-y-auto scrollbar-hide border-r border-white/10">
          <PanneauArbre items={items} filtre={filtre} onFiltre={setFiltre} />
          <div className="border-t border-white/10">
            <PanneauEtiquettes items={items} sections={sections} selChip={selChip}
              onSelect={(k) => { setSelChip(k); setSelSectionId(null); }} />
          </div>
        </div>

        <div className="flex min-h-0 flex-col gap-2 p-3">
          <div className="min-h-0 flex-1">
            {vue === "site" ? (
              <PanneauSiteCanvas sections={sections} design={design} style={style} siteName={siteName}
                selId={selSectionId}
                pagesDispo={Object.keys(parPage)} pageActive={pageActive}
                onPage={(slug) => { setPageActive(slug); setSelSectionId(null); }}
                onSelect={(id) => { setSelSectionId(id); setSelChip(null); }}
                onDrop={ajouterSection} onFinal={genererCartes} onPatch={patcherSection} />
            ) : vue === "pages" ? (
              <PanneauPages pages={pages} style={style} siteName={siteName} onPages={majPages}
                onOuvrir={(slug) => { if (parPage[slug]) setPageActive(slug); setVue("site"); setSelSectionId(null); }} />
            ) : (
              <PanneauCanevas items={items} filtre={filtre} selectedId={selItemId} onSelect={setSelItemId}
                onMove={(id, x, y) => patcherItem(id, { x, y })} />
            )}
          </div>
          <PointZeroDepot onDepot={deposer} />
        </div>

        <div className="hidden min-h-0 border-l border-white/10 lg:block">
          {vue !== "depots" ? (
            <PanneauPipeline style={style} design={design} onDesign={setDesign} items={items} sections={sections}
              section={selSection} chip={selChip}
              onPatch={patcherSection} onRegen={regenerer} onVisuel={genererVisuel}
              onRemove={retirerSection} onAjouter={ajouterSection}
              pages={pages} onPages={majPages}
              onAbsorber={absorberTextes} absorbe={absorbe}
              onMosaique={() => setVue("pages")}
              scoreOrigine={eaa?.report?.global_score} />
          ) : (
            <PanneauReglages item={selItem} onChange={patcherItem} onDelete={(id) => { setItems((p) => p.filter((i) => i.id !== id)); if (selItemId === id) setSelItemId(null); }} />
          )}
        </div>
      </div>

      {/* LA PUBLICATION +NOM — brouillon, vérification, publication, versions. */}
      {pub && (
        <PanneauPublication siteName={siteName} style={style} design={design} pages={parPage}
          onClose={() => setPub(false)} />
      )}
    </section>
  );
}