import { SECTIONS_SITE, progressionEtiquette } from "@/lib/bureau/sectionEtiquettes";

const GRAD = "linear-gradient(90deg, #F2A7C3, #E8C97F, #7FDCB2, #7FC3F0, #C9A2F5)";

// LES ÉTIQUETTES — les sections possibles du site, À GLISSER-DÉPOSER sur le
// canevas. Le dégradé de progression monte avec vos imports : à 100 %,
// l'étiquette est prête — déposée, la section apparaît déjà faite.
export default function PanneauEtiquettes({ items, sections, selChip, onSelect }) {
  const groupes = [...new Set(SECTIONS_SITE.map((s) => s.groupe))];

  return (
    <div className="p-2">
      <p className="px-2.5 pb-1.5 pt-1 font-mono text-[8px] font-semibold uppercase tracking-[0.22em] text-white/35">
        Sections du site · à glisser sur le canevas
      </p>
      {groupes.map((g) => (
        <div key={g} className="mb-1.5">
          <p className="px-2.5 py-1 font-mono text-[8px] uppercase tracking-[0.18em] text-white/25">{g}</p>
          <div className="space-y-1">
            {SECTIONS_SITE.filter((s) => s.groupe === g).map((sec) => {
              const posee = sections.some((s) => s.key === sec.key);
              const progress = progressionEtiquette(sec, items);
              const sel = selChip === sec.key;
              return (
                <button key={sec.key} type="button" draggable={!posee}
                  onDragStart={(e) => e.dataTransfer.setData("text/aime-section", sec.key)}
                  onClick={() => onSelect(sel ? null : sec.key)}
                  aria-pressed={sel}
                  title={posee ? "Déjà posée sur le canevas" : `${sec.label} — ${progress}% nourrie par vos dépôts`}
                  className={`relative block w-full min-h-[36px] overflow-hidden rounded-lg border px-2.5 text-left transition ${posee ? "cursor-default border-white/5 opacity-40" : "cursor-grab"} ${sel ? "border-white/60" : "border-white/10 hover:border-white/30"}`}>
                  {/* Le dégradé de progression — ce qui « ressort » de vos imports. */}
                  <span aria-hidden="true" className="absolute inset-y-0 left-0 transition-all duration-500"
                    style={{ width: `${progress}%`, background: GRAD, opacity: 0.3 }} />
                  <span className="relative flex items-center justify-between gap-2 py-2">
                    <span className="truncate text-[11px] font-semibold text-white">{sec.label}</span>
                    <span className={`font-mono text-[9px] font-bold ${progress >= 100 ? "text-[#7FDCB2]" : "text-white/40"}`}>
                      {posee ? "posée" : progress >= 100 ? "prête ✓" : `${progress}%`}
                    </span>
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
}