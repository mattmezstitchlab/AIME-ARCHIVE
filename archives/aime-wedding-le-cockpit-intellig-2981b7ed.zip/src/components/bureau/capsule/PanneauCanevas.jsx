import { useRef } from "react";
import { Link2, FileText, File, Image as ImageIcon, Loader2 } from "lucide-react";

const ICONES = { lien: Link2, texte: FileText, image: ImageIcon, fichier: File };

// LE CANEVAS — au centre, façon Framer / Paper : chaque élément déposé est
// une carte DÉPLAÇABLE librement. Le filtre de l'arbre estompe le reste.
export default function PanneauCanevas({ items, filtre, selectedId, onSelect, onMove }) {
  const ref = useRef(null);
  const drag = useRef(null);

  const down = (e, it) => {
    e.preventDefault();
    onSelect(it.id);
    const rect = ref.current.getBoundingClientRect();
    drag.current = { id: it.id, dx: e.clientX - rect.left - it.x, dy: e.clientY - rect.top - it.y };
    e.currentTarget.setPointerCapture(e.pointerId);
  };
  const move = (e) => {
    if (!drag.current) return;
    const rect = ref.current.getBoundingClientRect();
    const x = Math.max(0, Math.min(e.clientX - rect.left - drag.current.dx, rect.width - 150));
    const y = Math.max(0, Math.min(e.clientY - rect.top - drag.current.dy, rect.height - 60));
    onMove(drag.current.id, x, y);
  };
  const up = () => { drag.current = null; };

  const visible = (it) =>
    !filtre || (filtre === "__nongarde" ? it.garde === false : it.dossier === filtre && it.garde !== false);

  return (
    <div ref={ref} onPointerMove={move} onPointerUp={up}
      className="dot-grid-dark relative h-full overflow-hidden rounded-xl border border-white/10 bg-[#0A0A0B]">
      {items.length === 0 && (
        <p className="absolute inset-0 flex items-center justify-center px-8 text-center text-[12px] text-white/30">
          Déposez fichiers, liens, captures ou textes ci-dessous — Point Zéro examine, trie et range.
        </p>
      )}
      {items.map((it) => {
        const Icon = ICONES[it.type] || File;
        const sel = selectedId === it.id;
        return (
          <button key={it.id} type="button" onPointerDown={(e) => down(e, it)}
            className={`absolute w-[150px] cursor-grab touch-none rounded-xl border p-2.5 text-left shadow-lg transition-opacity active:cursor-grabbing ${sel ? "border-white/60 bg-[#1a1a1f]" : "border-white/10 bg-[#141418]"} ${visible(it) ? "" : "opacity-25"} ${it.garde === false ? "border-rose-500/40" : ""}`}
            style={{ left: it.x, top: it.y }}>
            {it.type === "image" && it.url ? (
              <img src={it.url} alt="" className="mb-1.5 h-16 w-full rounded-lg object-cover" />
            ) : (
              <Icon className="mb-1.5 h-4 w-4 text-white/50" aria-hidden="true" />
            )}
            <p className="truncate text-[11px] font-semibold text-white">{it.label || "Sans nom"}</p>
            <p className="mt-0.5 flex items-center gap-1 font-mono text-[8px] font-semibold uppercase tracking-[0.16em] text-white/35">
              {it.garde === null ? (
                <><Loader2 className="h-2.5 w-2.5 animate-spin" aria-hidden="true" /> Tri…</>
              ) : it.garde === false ? (
                <span className="text-rose-300">Non gardé</span>
              ) : (
                it.dossier
              )}
            </p>
          </button>
        );
      })}
    </div>
  );
}