import { useState, useRef } from "react";
import { Paperclip, Link2, Type, ArrowUp, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";

const GRAD = "conic-gradient(from 0deg, #F2A7C3, #E8C97F, #7FDCB2, #7FC3F0, #C9A2F5, #F2A7C3)";

// LE DÉPÔT POINT ZÉRO — la barre du bas : on dépose un fichier, un lien,
// une capture ou un texte + une consigne (ce qu'il doit prendre / absorber).
export default function PointZeroDepot({ onDepot }) {
  const [mode, setMode] = useState("lien"); // lien | texte
  const [valeur, setValeur] = useState("");
  const [consigne, setConsigne] = useState("");
  const [envoi, setEnvoi] = useState(false);
  const fileRef = useRef(null);

  const deposer = async (depot) => {
    setEnvoi(true);
    try { await onDepot({ ...depot, consigne: consigne.trim() || undefined }); } finally { setEnvoi(false); }
    setValeur(""); setConsigne("");
  };

  const soumettre = (e) => {
    e.preventDefault();
    const v = valeur.trim();
    if (!v) return;
    if (mode === "lien") {
      deposer({ type: "lien", label: v.replace(/^https?:\/\//, "").slice(0, 40), url: /^https?:\/\//i.test(v) ? v : `https://${v}` });
    } else {
      deposer({ type: "texte", label: v.slice(0, 40), texte: v });
    }
  };

  const fichiers = async (e) => {
    const files = Array.from(e.target.files || []);
    e.target.value = "";
    for (const f of files) {
      setEnvoi(true);
      try {
        const { file_url } = await base44.integrations.Core.UploadFile({ file: f });
        await onDepot({
          type: f.type.startsWith("image/") ? "image" : "fichier",
          label: f.name, url: file_url,
          consigne: consigne.trim() || undefined,
        });
      } finally { setEnvoi(false); }
    }
    setConsigne("");
  };

  return (
    <form onSubmit={soumettre} className="rounded-xl border border-white/10 bg-[#141418] p-2">
      <div className="flex items-center gap-1.5">
        <input ref={fileRef} type="file" multiple className="hidden" onChange={fichiers}
          aria-label="Déposer des fichiers (tout genre, captures d'écran incluses)" />
        <button type="button" onClick={() => fileRef.current?.click()} title="Déposer des fichiers / captures"
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg text-black" style={{ background: GRAD }}>
          <Paperclip className="h-4 w-4" aria-hidden="true" />
        </button>
        <div className="flex shrink-0 gap-0.5 rounded-lg bg-white/5 p-0.5">
          {[["lien", Link2], ["texte", Type]].map(([m, Icon]) => (
            <button key={m} type="button" onClick={() => setMode(m)} aria-pressed={mode === m} title={m}
              className={`flex h-8 w-8 items-center justify-center rounded-md transition ${mode === m ? "bg-white/15 text-white" : "text-white/40 hover:text-white"}`}>
              <Icon className="h-3.5 w-3.5" aria-hidden="true" />
            </button>
          ))}
        </div>
        <input value={valeur} onChange={(e) => setValeur(e.target.value)}
          placeholder={mode === "lien" ? "https://… (lien à absorber)" : "Collez un texte à absorber…"}
          aria-label={mode === "lien" ? "Lien à déposer" : "Texte à déposer"}
          className="min-h-[36px] min-w-0 flex-1 bg-transparent text-[12px] text-white outline-none placeholder:text-white/25" />
        <button type="submit" disabled={!valeur.trim() || envoi}
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-white text-black transition hover:bg-white/85 disabled:opacity-30"
          aria-label="Déposer">
          {envoi ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> : <ArrowUp className="h-4 w-4" aria-hidden="true" />}
        </button>
      </div>
      <input value={consigne} onChange={(e) => setConsigne(e.target.value)}
        placeholder="Consigne pour Point Zéro — ce qu'il doit prendre, absorber… (optionnel)"
        aria-label="Consigne pour Point Zéro"
        className="mt-1.5 w-full rounded-lg bg-white/[0.03] px-2.5 py-1.5 text-[11px] text-white/70 outline-none placeholder:text-white/20" />
    </form>
  );
}