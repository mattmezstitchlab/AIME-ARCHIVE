import { useState, useEffect } from "react";
import { Loader2, Check, Plus } from "lucide-react";

// LA NARRATION DE L'AUDIT — phrase par phrase, lentement, Point Zéro dit
// ce qu'il analyse et ce qu'il prépare. Sans encadré : juste le carré-morpho
// dégradé (le + qui tourne en ✕) et le fil des phrases.
const GRAD = "conic-gradient(from 0deg, #F2A7C3, #E8C97F, #7FDCB2, #7FC3F0, #C9A2F5, #F2A7C3)";

const PHRASES = [
  "Je me connecte au site et je parcours ses pages…",
  "Je repère le secteur, l'offre et le ton du site…",
  "Perceptible — je vérifie les textes alternatifs des images et les contrastes de couleurs…",
  "Utilisable — je teste la navigation au clavier, le focus visible et la taille des zones cliquables…",
  "Compréhensible — je mesure la clarté du langage, les libellés des formulaires…",
  "Robuste — je contrôle la structure HTML, les rôles ARIA, la compatibilité lecteurs d'écran…",
  "Je calcule le score de conformité EAA, principe par principe…",
  "Je rédige le plan d'action : chaque faille, son impact, et comment la corriger…",
  "Je dessine l'arborescence simplifiée du site refondu…",
  "Je réécris l'essentiel des pages en langage clair, prêt à publier…",
  "Je prépare les mots-clés et les recommandations SEO…",
  "Je compose la direction artistique : ton, palette, typographie…",
  "Je finalise le rapport — encore quelques secondes…",
];

const CADENCE = 4200; // lent — une phrase toutes les ~4 secondes.

export default function AuditNarration() {
  const [etape, setEtape] = useState(0);

  useEffect(() => {
    const t = setInterval(() => setEtape((e) => Math.min(e + 1, PHRASES.length - 1)), CADENCE);
    return () => clearInterval(t);
  }, []);

  return (
    <div className="flex flex-col items-center py-10">
      {/* LE CARRÉ-MORPHO — le dégradé arc-en-ciel, le + qui tourne en ✕. */}
      <span
        className="mb-4 flex h-14 w-14 items-center justify-center text-black shadow-[0_0_36px_rgba(255,255,255,0.22)]"
        style={{ background: GRAD, borderRadius: "16px" }}
        aria-hidden="true"
      >
        <Plus className="h-6 w-6 animate-[spin_4s_linear_infinite]" strokeWidth={3} />
      </span>

      <p className="mb-1 text-[13px] font-bold text-white">Audit EAA en cours…</p>
      <p className="mb-6 font-mono text-[8px] font-semibold uppercase tracking-[0.22em] text-white/35">
        Point Zéro travaille · environ une minute
      </p>

      <ul className="flex w-full max-w-md flex-col gap-2.5" aria-live="polite">
        {PHRASES.slice(Math.max(0, etape - 3), etape + 1).map((ph, i, arr) => {
          const courante = i === arr.length - 1;
          return (
            <li key={ph} className={`ripple-wave flex items-start gap-2.5 ${courante ? "" : "opacity-40"}`}>
              {courante
                ? <Loader2 className="mt-0.5 h-3.5 w-3.5 shrink-0 animate-spin text-[#7FC3F0]" aria-hidden="true" />
                : <Check className="mt-0.5 h-3.5 w-3.5 shrink-0 text-[#7FDCB2]" aria-hidden="true" />}
              <span className={`text-[12.5px] leading-relaxed ${courante ? "accent-arcenciel" : "text-white/45"}`}>{ph}</span>
            </li>
          );
        })}
      </ul>
    </div>
  );
}