import { Trash2, Wand2 } from "lucide-react";
import { DOSSIERS } from "@/lib/bureau/capsuleTriage";

// LES RÉGLAGES — colonne droite : l'élément sélectionné se règle ici
// (nom, dossier, gardé ou non, transformation EAA, consigne d'absorption).
export default function PanneauReglages({ item, onChange, onDelete }) {
  if (!item) {
    return (
      <div className="flex h-full items-center justify-center p-4">
        <p className="text-center text-[11px] text-white/30">Sélectionnez un élément du canevas pour le régler.</p>
      </div>
    );
  }
  const set = (patch) => onChange(item.id, patch);
  const champ = "w-full rounded-lg border border-white/10 bg-white/5 px-2.5 py-2 text-[12px] text-white outline-none placeholder:text-white/25 focus:border-white/35";

  return (
    <div className="flex h-full flex-col gap-3 overflow-y-auto scrollbar-hide p-3">
      <p className="font-mono text-[8px] font-semibold uppercase tracking-[0.22em] text-white/35">Réglages de l'élément</p>

      <label className="block">
        <span className="mb-1 block text-[10px] font-semibold text-white/50">Nom</span>
        <input value={item.label || ""} onChange={(e) => set({ label: e.target.value })} className={champ} />
      </label>

      <label className="block">
        <span className="mb-1 block text-[10px] font-semibold text-white/50">Dossier</span>
        <select value={item.dossier || ""} onChange={(e) => set({ dossier: e.target.value })}
          className={`${champ} appearance-none`}>
          {DOSSIERS.map((d) => <option key={d} value={d} className="bg-[#141418]">{d}</option>)}
        </select>
      </label>

      <div className="flex items-center justify-between rounded-lg border border-white/10 bg-white/5 px-2.5 py-2">
        <span className="text-[12px] text-white/80">Gardé pour la refonte</span>
        <button type="button" role="switch" aria-checked={item.garde !== false}
          onClick={() => set({ garde: item.garde === false })}
          className={`h-5 w-9 rounded-full transition ${item.garde !== false ? "bg-[#7FDCB2]" : "bg-white/15"}`}>
          <span className={`block h-4 w-4 rounded-full bg-white transition-transform ${item.garde !== false ? "translate-x-4" : "translate-x-0.5"}`} />
        </button>
      </div>
      {item.garde === false && item.motif && (
        <p className="rounded-lg border border-rose-500/30 bg-rose-500/5 px-2.5 py-2 text-[11px] text-rose-300">{item.motif}</p>
      )}

      <label className="block">
        <span className="mb-1 flex items-center gap-1 text-[10px] font-semibold text-white/50">
          <Wand2 className="h-3 w-3 text-[#E8C97F]" aria-hidden="true" /> Transformation EAA
        </span>
        <textarea value={item.transformation || ""} onChange={(e) => set({ transformation: e.target.value })}
          rows={3} className={`${champ} resize-none`} placeholder="Comment Point Zéro le reconvertit…" />
      </label>

      <label className="block">
        <span className="mb-1 block text-[10px] font-semibold text-white/50">Consigne — ce qu'il doit prendre / absorber</span>
        <textarea value={item.consigne || ""} onChange={(e) => set({ consigne: e.target.value })}
          rows={2} className={`${champ} resize-none`} placeholder="Ex. garder uniquement le logo et les tarifs…" />
      </label>

      <button type="button" onClick={() => onDelete(item.id)}
        className="mt-auto flex min-h-[36px] items-center justify-center gap-1.5 rounded-lg border border-white/10 text-[11px] text-white/50 transition hover:border-rose-500/40 hover:text-rose-300">
        <Trash2 className="h-3.5 w-3.5" aria-hidden="true" /> Retirer du projet
      </button>
    </div>
  );
}