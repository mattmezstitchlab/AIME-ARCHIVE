import { Folder, FolderOpen, XCircle, Sparkles } from "lucide-react";
import { DOSSIERS } from "@/lib/bureau/capsuleTriage";

// L'ARBRE — colonne gauche : le dossier du projet et ses sous-dossiers,
// remplis par le tri de Point Zéro. « Non gardé » regroupe les écartés.
export default function PanneauArbre({ items, filtre, onFiltre }) {
  const compte = (d) => items.filter((i) => i.dossier === d && i.garde !== false).length;
  const nonGardes = items.filter((i) => i.garde === false).length;
  const enTri = items.filter((i) => i.garde === null).length;

  const ligne = (key, label, n, Icon, cls = "") => (
    <button key={key} type="button" onClick={() => onFiltre(filtre === key ? null : key)}
      className={`flex w-full min-h-[36px] items-center gap-2 rounded-lg px-2.5 text-left text-[12px] transition ${filtre === key ? "bg-white/15 text-white" : "text-white/60 hover:bg-white/5 hover:text-white"} ${cls}`}>
      <Icon className="h-3.5 w-3.5 shrink-0 opacity-70" aria-hidden="true" />
      <span className="flex-1 truncate">{label}</span>
      <span className="font-mono text-[10px] text-white/35">{n}</span>
    </button>
  );

  return (
    <nav aria-label="Dossiers du projet" className="flex flex-col gap-0.5 p-2">
      <p className="px-2.5 pb-2 pt-1 font-mono text-[8px] font-semibold uppercase tracking-[0.22em] text-white/35">
        Dossier du projet
      </p>
      {ligne(null, "Tout le projet", items.length, FolderOpen)}
      {DOSSIERS.map((d) => ligne(d, d, compte(d), Folder))}
      <div className="mt-2 border-t border-white/10 pt-2">
        {ligne("__nongarde", "Non gardé", nonGardes, XCircle, "text-rose-300/60")}
        {enTri > 0 && (
          <p className="flex items-center gap-1.5 px-2.5 py-1.5 text-[11px] text-white/40">
            <Sparkles className="h-3 w-3 animate-pulse text-[#E8C97F]" aria-hidden="true" /> {enTri} en cours de tri…
          </p>
        )}
      </div>
    </nav>
  );
}