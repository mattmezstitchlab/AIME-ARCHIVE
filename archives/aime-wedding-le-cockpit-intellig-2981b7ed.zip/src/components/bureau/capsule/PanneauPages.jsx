import { LayoutGrid, PanelsTopLeft } from "lucide-react";
import EaaEditablePage from "@/components/gallery/eaa/EaaEditablePage";

// PAGES — les vraies pages du site, exactement comme à l'étape 2 du pipeline :
// chaque page est une carte vivante (Aperçu · Contenu · Éditable) avec sa
// maquette générée. Les éditions sont sauvegardées au dossier du projet.
export default function PanneauPages({ pages, style, siteName, onPages, onOuvrir }) {
  if (!pages?.length) {
    return (
      <div className="flex h-full flex-col items-center justify-center gap-2 rounded-2xl border border-dashed border-white/15 p-6 text-center">
        <LayoutGrid className="h-6 w-6 text-white/25" aria-hidden="true" />
        <p className="text-[12px] text-white/40">
          Aucun site absorbé pour l'instant.<br />
          Lancez un audit (AI · URL) : ses pages vivront ici.
        </p>
      </div>
    );
  }

  const artDirection = {
    tone: style?.tone,
    palette: style?.palette,
    typography: style?.typography,
    hero_url: style?.hero_url,
  };

  const updatePage = (slug, patch) =>
    onPages(pages.map((p) => (p.slug === slug ? { ...p, ...patch } : p)));

  const addSection = (slug, section) =>
    onPages(pages.map((p) => (p.slug === slug ? { ...p, sections: [...(p.sections || []), section] } : p)));

  return (
    <div className="h-full overflow-y-auto scrollbar-hide rounded-2xl border border-white/10 bg-[#0A0A0B]/60 p-3">
      <p className="mb-2.5 font-mono text-[8px] font-semibold uppercase tracking-[0.22em] text-white/35">
        Pages du site · générées dans la DA — Aperçu, Contenu, Éditable
      </p>
      <div className="grid gap-4 sm:grid-cols-2">
        {pages.map((p, i) => (
          <div key={p.slug || i} className="flex flex-col gap-2">
            <EaaEditablePage
              page={p}
              artDirection={artDirection}
              siteTitle={siteName}
              onAddSection={addSection}
              onUpdatePage={updatePage}
            />
            {/* La suite : la page s'ouvre sur le canevas Site pour régler
                le design (mise en page, couleurs, visuels…). */}
            {onOuvrir && (
              <button type="button" onClick={() => onOuvrir(p.slug)}
                className="flex min-h-[36px] items-center justify-center gap-1.5 rounded-xl border border-white/15 text-[11.5px] font-bold text-white/70 transition hover:border-white/40 hover:text-white">
                <PanelsTopLeft className="h-3.5 w-3.5 text-[#7FC3F0]" aria-hidden="true" />
                Ouvrir /{p.slug} dans le Site →
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}