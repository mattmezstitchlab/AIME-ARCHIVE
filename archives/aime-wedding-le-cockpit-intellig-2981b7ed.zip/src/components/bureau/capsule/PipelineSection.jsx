import { Loader2, Wand2, Image as ImageIcon, Trash2, Plus } from "lucide-react";
import { SECTIONS_SITE, progressionEtiquette } from "@/lib/bureau/sectionEtiquettes";

// LE BLOC SÉLECTIONNÉ — mise en page (plusieurs choix), textes, régénération
// et génération du visuel, directement dans le canevas.
export default function PipelineSection({ items, sections, section, chip, onPatch, onRegen, onVisuel, onRemove, onAjouter }) {
  const champ = "w-full rounded-lg border border-white/10 bg-white/5 px-2.5 py-2 text-[12px] text-white outline-none placeholder:text-white/25 focus:border-white/35";
  const chipDef = chip ? SECTIONS_SITE.find((s) => s.key === chip) : null;

  if (!chipDef && !section) {
    return <p className="text-[10.5px] text-white/35">Cliquez une étiquette ou une section du canevas pour la configurer ici.</p>;
  }

  if (chipDef && !section) {
    return (
      <div>
        <p className="text-[12px] font-bold text-white">{chipDef.label}</p>
        <p className="mt-1 text-[11px] text-white/50">
          Nourrie à <strong className="text-white">{progressionEtiquette(chipDef, items)}%</strong> par vos dépôts.
          Besoins : {chipDef.besoins.join(", ")}.
        </p>
        <button type="button" onClick={() => onAjouter(chipDef.key)}
          disabled={sections.some((s) => s.key === chipDef.key)}
          className="mt-2 flex min-h-[36px] w-full items-center justify-center gap-1.5 rounded-lg bg-white text-[11px] font-bold text-black transition hover:bg-white/85 disabled:opacity-30">
          <Plus className="h-3.5 w-3.5" aria-hidden="true" /> Poser sur le canevas
        </button>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-2.5">
      <p className="font-mono text-[8px] font-semibold uppercase tracking-[0.22em] text-white/35">Section · {section.label}</p>
      <div>
        <p className="mb-1.5 text-[10px] font-semibold text-white/50">Mise en page suggérée</p>
        <div className="flex flex-wrap gap-1.5">
          {[["standard", "Texte + visuel"], ["plein", "Visuel plein écran"], ["bandeau", "Bandeau"], ["minimal", "Minimal"]].map(([v, lab]) => (
            <button key={v} type="button" onClick={() => onPatch(section.id, { mise: v })}
              aria-pressed={(section.mise || "standard") === v}
              className={`min-h-[30px] rounded-full border px-2.5 text-[10px] font-semibold transition ${(section.mise || "standard") === v ? "border-white bg-white text-black" : "border-white/15 text-white/60 hover:text-white"}`}>
              {lab}
            </button>
          ))}
        </div>
      </div>
      <label className="block">
        <span className="mb-1 block text-[10px] font-semibold text-white/50">Titre</span>
        <input value={section.heading || ""} onChange={(e) => onPatch(section.id, { heading: e.target.value })} className={champ} />
      </label>
      <label className="block">
        <span className="mb-1 block text-[10px] font-semibold text-white/50">Texte</span>
        <textarea value={section.body || ""} onChange={(e) => onPatch(section.id, { body: e.target.value })}
          rows={4} className={`${champ} resize-none`} />
      </label>
      {!section.origine && (
        <button type="button" onClick={() => onRegen(section.id)} disabled={section.status === "gen"}
          className="flex min-h-[36px] items-center justify-center gap-1.5 rounded-lg border border-white/15 text-[11px] font-semibold text-white/70 transition hover:border-white/40 hover:text-white disabled:opacity-40">
          {section.status === "gen" ? <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" /> : <Wand2 className="h-3.5 w-3.5 text-[#C9A2F5]" aria-hidden="true" />}
          Régénérer le texte
        </button>
      )}
      <button type="button" onClick={() => onVisuel(section.id)} disabled={!!section.visuel_gen}
        className="flex min-h-[36px] items-center justify-center gap-1.5 rounded-lg border border-white/15 text-[11px] font-semibold text-white/70 transition hover:border-white/40 hover:text-white disabled:opacity-40">
        {section.visuel_gen ? <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" /> : <ImageIcon className="h-3.5 w-3.5 text-[#7FC3F0]" aria-hidden="true" />}
        Générer le visuel
      </button>
      <button type="button" onClick={() => onRemove(section.id)}
        className="flex min-h-[36px] items-center justify-center gap-1.5 rounded-lg border border-white/10 text-[11px] text-white/50 transition hover:border-rose-500/40 hover:text-rose-300">
        <Trash2 className="h-3.5 w-3.5" aria-hidden="true" /> Retirer la section
      </button>
    </div>
  );
}