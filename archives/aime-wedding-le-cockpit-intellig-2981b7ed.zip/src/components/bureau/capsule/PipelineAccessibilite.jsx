import { EAA_SETTINGS, defaultSettings, conformityScore } from "@/lib/gallery/eaaAccessibility";

const BARRE = "linear-gradient(90deg,#F2A7C3,#E8C97F,#7FDCB2,#7FC3F0,#C9A2F5)";

// ACCESSIBILITÉ EAA DANS LE STUDIO — les mêmes réglages que la console du
// pipeline, appliqués EN DIRECT sur le canevas-site. Le score de conformité
// grimpe à mesure qu'on pousse les curseurs au-dessus du plancher légal.
export default function PipelineAccessibilite({ eaa, onChange, scoreOrigine }) {
  const s = { ...defaultSettings(), ...(eaa || {}) };
  const score = conformityScore(s);
  const maj = (key, value) => onChange({ ...s, [key]: value });

  return (
    <div>
      {/* Le score vivant */}
      <div className="mb-2.5 rounded-lg border border-white/10 bg-white/[0.03] p-2.5">
        <p className="flex items-baseline justify-between">
          <span className="accent-arcenciel font-mono text-[8px] uppercase tracking-[0.22em]">Conformité EAA</span>
          <span className="flex items-baseline gap-1.5">
            {/* Le comparateur avant/après : le score du site d'origine → le vôtre. */}
            {typeof scoreOrigine === "number" && (
              <>
                <span className="text-[12px] font-bold text-[#F2A7C3]" title="Score du site d'origine (audit)">{scoreOrigine}</span>
                <span className="text-[10px] text-white/30" aria-hidden="true">→</span>
              </>
            )}
            <span className="text-[18px] font-extrabold leading-none" style={{ color: score >= 100 ? "#7FDCB2" : "#7FC3F0" }}>
              {score}<span className="text-[10px] text-white/40">/100</span>
            </span>
          </span>
        </p>
        {typeof scoreOrigine === "number" && (
          <p className="mt-1 font-mono text-[7.5px] uppercase tracking-[0.18em] text-white/35">
            Avant l'audit → dans le Studio · +{Math.max(score - scoreOrigine, 0)} points
          </p>
        )}
        <div className="mt-1.5 h-1 overflow-hidden rounded-full bg-white/10">
          <div className="h-full rounded-full transition-all duration-700" style={{ width: `${score}%`, background: BARRE }} />
        </div>
      </div>

      <div className="space-y-2">
        {EAA_SETTINGS.map((p) =>
          p.type === "range" ? (
            <div key={p.key}>
              <p className="flex items-baseline justify-between text-[10px]">
                <span className="font-semibold text-white/60">{p.label}</span>
                <span className="font-mono font-bold text-[#7FC3F0]">{s[p.key]}{p.unit}</span>
              </p>
              <input type="range" min={p.min} max={p.max} step={p.step} value={s[p.key]}
                onChange={(e) => maj(p.key, Number(e.target.value))}
                aria-label={p.label} title={p.hint}
                className="ripple-range h-1 w-full cursor-pointer appearance-none rounded-full bg-white/15" />
            </div>
          ) : (
            <button key={p.key} type="button" disabled={p.locked}
              onClick={() => maj(p.key, !s[p.key])} aria-pressed={!!s[p.key]} title={p.hint}
              className="flex w-full items-center gap-2 rounded-lg border border-white/10 px-2 py-1.5 text-left transition hover:border-white/25 disabled:cursor-default">
              <span className={`flex h-4 w-8 shrink-0 items-center rounded-full p-0.5 transition ${s[p.key] ? "justify-end bg-[#7FDCB2]" : "justify-start bg-white/15"}`} aria-hidden="true">
                <span className="h-3 w-3 rounded-full bg-white shadow" />
              </span>
              <span className="flex-1 text-[10px] font-semibold text-white/60">{p.label}</span>
              {p.locked && <span className="font-mono text-[7.5px] uppercase tracking-widest text-white/30">Exigé EAA</span>}
            </button>
          )
        )}
      </div>
    </div>
  );
}