import { useState, useEffect } from "react";
import { ChevronDown, Loader2, LayoutGrid, BookOpen } from "lucide-react";
import PipelineSection from "@/components/bureau/capsule/PipelineSection";
import PipelineAccessibilite from "@/components/bureau/capsule/PipelineAccessibilite";

const PALETTE_DEFAUT = ["#F2A7C3", "#E8C97F", "#7FDCB2", "#7FC3F0", "#C9A2F5"];

// UNE ÉTAPE DU PIPELINE — accordéon numéroté, dans l'ordre.
function Etape({ num, titre, ouvert, onToggle, children }) {
  return (
    <div className="rounded-xl border border-white/10 bg-white/[0.02]">
      <button type="button" onClick={onToggle} aria-expanded={ouvert}
        className="flex w-full items-center gap-2 px-3 py-2.5 text-left">
        <span className="font-mono text-[9px] font-bold text-white/35">{String(num).padStart(2, "0")}</span>
        <span className="flex-1 text-[11.5px] font-bold text-white">{titre}</span>
        <ChevronDown className={`h-3.5 w-3.5 text-white/40 transition-transform ${ouvert ? "rotate-180" : ""}`} aria-hidden="true" />
      </button>
      {ouvert && <div className="border-t border-white/10 px-3 py-2.5">{children}</div>}
    </div>
  );
}

// LE PIPELINE DE RÉGLAGES — colonne droite du Studio Canevas : tout, dans
// l'ordre — design system AIME, couleurs, texte absorbé (2 modes), vue
// éclatée, arborescence, puis mise en page & visuels du bloc sélectionné.
export default function PanneauPipeline({
  style, design, onDesign, items, sections, section, chip,
  onPatch, onRegen, onVisuel, onRemove, onAjouter,
  pages, onPages, onAbsorber, absorbe, onMosaique, scoreOrigine,
}) {
  const [ouvert, setOuvert] = useState(1);
  const bascule = (n) => setOuvert((o) => (o === n ? 0 : n));
  // Sélection d'un bloc → l'étape 6 s'ouvre d'elle-même.
  useEffect(() => { if (section || chip) setOuvert(7); }, [section?.id, chip]); // eslint-disable-line react-hooks/exhaustive-deps

  const palette = style?.palette?.length ? style.palette : PALETTE_DEFAUT;
  const pill = (actif) =>
    `min-h-[30px] rounded-full border px-2.5 text-[10px] font-semibold transition ${actif ? "border-white bg-white text-black" : "border-white/15 text-white/60 hover:text-white"}`;

  return (
    <div className="flex h-full flex-col gap-2 overflow-y-auto scrollbar-hide p-3">
      <p className="font-mono text-[8px] font-semibold uppercase tracking-[0.22em] text-white/35">Le pipeline · dans l'ordre</p>

      {/* 01 — LE DESIGN SYSTEM AIME */}
      <Etape num={1} titre="Design system AIME®" ouvert={ouvert === 1} onToggle={() => bascule(1)}>
        <p className="mb-2 text-[10px] leading-relaxed text-white/40">
          Basé sur le vrai design system AIME : titres Inter extra-bold serrés, labels mono espacés, accents rares.
        </p>
        <p className="mb-1.5 text-[10px] font-semibold text-white/50">Typographie</p>
        <div className="mb-2.5 flex gap-1.5">
          {[["sans", "Studio — Sans"], ["serif", "Éditorial — Serif"]].map(([v, lab]) => (
            <button key={v} type="button" onClick={() => onDesign({ ...design, typo: v })} aria-pressed={design.typo === v} className={pill(design.typo === v)}>{lab}</button>
          ))}
        </div>
        <p className="mb-1.5 text-[10px] font-semibold text-white/50">Coins</p>
        <div className="flex gap-1.5">
          {[["net", "Net"], ["doux", "Doux"], ["rond", "Rond"]].map(([v, lab]) => (
            <button key={v} type="button" onClick={() => onDesign({ ...design, radius: v })} aria-pressed={(design.radius || "doux") === v} className={pill((design.radius || "doux") === v)}>{lab}</button>
          ))}
        </div>
      </Etape>

      {/* 02 — LES COULEURS */}
      <Etape num={2} titre="Couleurs" ouvert={ouvert === 2} onToggle={() => bascule(2)}>
        <p className="mb-1.5 text-[10px] font-semibold text-white/50">Accent {style?.name ? `· DA « ${style.name} »` : ""}</p>
        <div className="flex flex-wrap gap-1.5">
          {palette.map((c, i) => (
            <button key={i} type="button" onClick={() => onDesign({ ...design, accent: design.accent === c ? null : c })}
              aria-label={`Accent ${c}`} aria-pressed={design.accent === c}
              className={`h-7 w-7 rounded-full border-2 transition ${design.accent === c ? "scale-110 border-white" : "border-white/20 hover:scale-105"}`}
              style={{ backgroundColor: c }} />
          ))}
        </div>
      </Etape>

      {/* 03 — LE TEXTE ABSORBÉ : 2 modes */}
      <Etape num={3} titre="Texte absorbé du site d'origine" ouvert={ouvert === 3} onToggle={() => bascule(3)}>
        <div className="mb-2 flex flex-col gap-1.5">
          {[["synthetique", "Synthétique", "restructuré fidèlement, sans rien inventer"], ["regenere", "Régénéré en mieux", "réécrit plus clair, compréhensible par tous"]].map(([v, lab, aide]) => (
            <button key={v} type="button" onClick={() => onDesign({ ...design, texteMode: v })}
              aria-pressed={(design.texteMode || "synthetique") === v}
              className={`rounded-lg border px-2.5 py-2 text-left transition ${(design.texteMode || "synthetique") === v ? "border-white bg-white/10" : "border-white/10 hover:border-white/30"}`}>
              <span className="block text-[11px] font-bold text-white">{lab}</span>
              <span className="block text-[9.5px] text-white/45">{aide}</span>
            </button>
          ))}
        </div>
        <button type="button" onClick={onAbsorber} disabled={absorbe || sections.length === 0}
          className="flex min-h-[34px] w-full items-center justify-center gap-1.5 rounded-lg bg-white text-[11px] font-bold text-black transition hover:bg-white/85 disabled:opacity-30">
          {absorbe ? <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" /> : <BookOpen className="h-3.5 w-3.5" aria-hidden="true" />}
          Absorber dans toutes les sections
        </button>
      </Etape>

      {/* 04 — LES PAGES DU SITE */}
      <Etape num={4} titre="Pages du site" ouvert={ouvert === 4} onToggle={() => bascule(4)}>
        <p className="mb-2 text-[10px] text-white/40">
          {pages.length ? `${pages.length} pages générées dans la DA — Aperçu, Contenu, Éditable.` : "Lancez un audit (AI · URL) pour générer les pages du site."}
        </p>
        <button type="button" onClick={onMosaique} disabled={!pages.length}
          className="flex min-h-[34px] w-full items-center justify-center gap-1.5 rounded-lg border border-white/15 text-[11px] font-semibold text-white/70 transition hover:border-white/40 hover:text-white disabled:opacity-30">
          <LayoutGrid className="h-3.5 w-3.5 text-[#7FC3F0]" aria-hidden="true" /> Ouvrir les pages
        </button>
      </Etape>

      {/* 05 — L'ARBORESCENCE */}
      <Etape num={5} titre="Arborescence" ouvert={ouvert === 5} onToggle={() => bascule(5)}>
        {pages.length === 0 && <p className="text-[10px] text-white/40">Les pages absorbées apparaîtront ici après l'audit.</p>}
        <div className="flex flex-col gap-1">
          {pages.map((p, i) => (
            <div key={p.slug || i} className="flex items-center gap-2 rounded-lg border border-white/10 px-2 py-1.5">
              <span className="flex-1 truncate text-[10.5px] text-white/70">/{p.slug} <span className="text-white/35">· {p.title}</span></span>
              <button type="button" role="switch" aria-checked={p.keep !== false} aria-label={`Garder la page ${p.title}`}
                onClick={() => onPages(pages.map((x, j) => (j === i ? { ...x, keep: x.keep === false } : x)))}
                className={`h-4 w-8 shrink-0 rounded-full transition ${p.keep !== false ? "bg-[#7FDCB2]" : "bg-white/15"}`}>
                <span className={`block h-3 w-3 rounded-full bg-white transition-transform ${p.keep !== false ? "translate-x-4" : "translate-x-0.5"}`} />
              </button>
            </div>
          ))}
        </div>
      </Etape>

      {/* 06 — ACCESSIBILITÉ EAA : score vivant, appliqué en direct au canevas */}
      <Etape num={6} titre="Accessibilité EAA · score vivant" ouvert={ouvert === 6} onToggle={() => bascule(6)}>
        <PipelineAccessibilite eaa={design.eaa} onChange={(eaa) => onDesign({ ...design, eaa })} scoreOrigine={scoreOrigine} />
      </Etape>

      {/* 07 — MISE EN PAGE & VISUELS DU BLOC SÉLECTIONNÉ */}
      <Etape num={7} titre="Le bloc sélectionné" ouvert={ouvert === 7} onToggle={() => bascule(7)}>
        <PipelineSection items={items} sections={sections} section={section} chip={chip}
          onPatch={onPatch} onRegen={onRegen} onVisuel={onVisuel} onRemove={onRemove} onAjouter={onAjouter} />
      </Etape>
    </div>
  );
}