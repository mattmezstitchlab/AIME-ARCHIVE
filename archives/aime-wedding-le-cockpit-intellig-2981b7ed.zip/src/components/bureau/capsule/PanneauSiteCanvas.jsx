import { Loader2, Sparkles } from "lucide-react";
import { settingsToStyle, defaultSettings } from "@/lib/gallery/eaaAccessibility";

// Un élément de texte CLIQUABLE et MODIFIABLE en place, directement dans le canevas.
function TexteEditable({ value, onSave, className = "", style, placeholder }) {
  return (
    <p contentEditable suppressContentEditableWarning role="textbox" aria-label="Texte modifiable"
      onClick={(e) => e.stopPropagation()}
      onBlur={(e) => onSave(e.currentTarget.textContent.trim())}
      className={`${className} cursor-text rounded outline-none transition focus:ring-1 focus:ring-white/50`}
      style={style}>
      {value || placeholder}
    </p>
  );
}

// LE CANEVAS-SITE — les sections s'empilent à la verticale, se génèrent
// dedans, et CHAQUE ÉLÉMENT (titre, texte, bouton) se sélectionne et se
// modifie en place. Chaque section a sa MISE EN PAGE (plein écran, bandeau…).
export default function PanneauSiteCanvas({ sections, design, style, siteName, selId, onSelect, onDrop, onFinal, onPatch, pagesDispo, pageActive, onPage }) {
  const serif = design.typo === "serif";
  const accent = design.accent || style?.palette?.[0] || "#E8C97F";
  const titreCls = serif ? "font-memoire" : "font-heading";
  // Les réglages EAA du pipeline s'appliquent EN DIRECT sur le canevas.
  const eaa = { ...defaultSettings(), ...(design.eaa || {}) };
  const eaaClass = [
    eaa.underlineLinks ? "[&_a]:underline" : "",
    eaa.reduceMotion ? "[&_*]:!animate-none" : "",
  ].join(" ");

  const renduSection = (s) => {
    const mise = s.mise || "standard";
    const sel = selId === s.id;
    const cadre = `w-full rounded-2xl border text-left transition cursor-pointer ${sel ? "border-white/60" : "border-white/10 hover:border-white/25"}`;

    const contenu = (surImage = false) => (
      <>
        <TexteEditable value={s.heading} onSave={(v) => onPatch(s.id, { heading: v })}
          className={`mt-2 text-[15px] font-bold text-white ${titreCls}`} placeholder="Titre…" />
        {mise !== "minimal" && (
          <TexteEditable value={s.body} onSave={(v) => onPatch(s.id, { body: v })}
            className={`mt-1 text-[12px] leading-relaxed ${surImage ? "text-white/80" : "text-white/55"}`} placeholder="Texte…" />
        )}
        {mise !== "minimal" && s.cta !== undefined && s.cta !== "" && (
          <span className="mt-2 inline-flex items-center rounded-full border px-3 py-1 text-[11px] font-semibold"
            style={{ borderColor: accent, color: accent }} onClick={(e) => e.stopPropagation()}>
            <TexteEditable value={s.cta} onSave={(v) => onPatch(s.id, { cta: v })} className="inline" placeholder="Bouton…" />
          </span>
        )}
      </>
    );

    return (
      <div key={s.id} role="button" tabIndex={0} onClick={() => onSelect(s.id)}
        onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); onSelect(s.id); } }}
        className={`${cadre} ${mise === "plein" ? "relative overflow-hidden" : "bg-[#141418] p-4"}`}>
        {mise === "plein" && (
          <>
            {s.image_url ? (
              <img src={s.image_url} alt="" className="absolute inset-0 h-full w-full object-cover" />
            ) : (
              <span aria-hidden="true" className="absolute inset-0" style={{ background: `linear-gradient(160deg, ${accent}44, #141418)` }} />
            )}
            <span aria-hidden="true" className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />
          </>
        )}
        <div className={mise === "plein" ? "relative flex min-h-[190px] flex-col justify-end p-4" : mise === "bandeau" ? "border-l-2 pl-3" : ""}
          style={mise === "bandeau" ? { borderLeftColor: accent } : undefined}>
          <p className="font-mono text-[8px] font-semibold uppercase tracking-[0.2em] text-white/40">{s.label}</p>
          {s.status === "gen" ? (
            <div className="mt-2 space-y-2" aria-label="Section en cours de génération">
              <p className="flex items-center gap-1.5 text-[11px] text-white/50">
                <Loader2 className="h-3 w-3 animate-spin" aria-hidden="true" /> Génération dans la direction artistique…
              </p>
              <div className="h-3.5 w-2/3 animate-pulse rounded bg-white/10" />
              <div className="h-2.5 w-full animate-pulse rounded bg-white/5" />
            </div>
          ) : (
            <>
              {s.visuel_gen && (
                <p className="mt-2 flex items-center gap-1.5 text-[11px] text-white/50">
                  <Loader2 className="h-3 w-3 animate-spin" aria-hidden="true" /> Visuel en génération…
                </p>
              )}
              {mise === "standard" && s.image_url && (
                <img src={s.image_url} alt={s.heading || s.label} className="mt-2 h-28 w-full rounded-xl object-cover" />
              )}
              {contenu(mise === "plein")}
            </>
          )}
        </div>
      </div>
    );
  };

  return (
    <div
      onDragOver={(e) => e.preventDefault()}
      onDrop={(e) => { e.preventDefault(); const k = e.dataTransfer.getData("text/aime-section"); if (k) onDrop(k); }}
      className={`dot-grid-dark relative h-full overflow-y-auto scrollbar-hide rounded-xl border border-white/10 bg-[#0A0A0B] p-4 ${eaaClass}`}
      style={{ ...settingsToStyle(eaa), fontSize: "calc(1rem * var(--eaa-font-scale))", lineHeight: "var(--eaa-line-height)" }}>
      <div className="mx-auto max-w-md space-y-3 pb-4">
        {/* LES PAGES DU SITE — on édite une page à la fois sur le canevas. */}
        {pagesDispo?.length > 1 && (
          <div className="flex flex-wrap gap-1.5" role="tablist" aria-label="Pages du site">
            {pagesDispo.map((slug) => (
              <button key={slug} type="button" role="tab" aria-selected={pageActive === slug}
                onClick={() => onPage(slug)}
                className={`min-h-[28px] rounded-full border px-2.5 font-mono text-[9px] font-bold uppercase tracking-[0.12em] transition ${pageActive === slug ? "border-white bg-white text-black" : "border-white/15 text-white/50 hover:text-white"}`}>
                /{slug}
              </button>
            ))}
          </div>
        )}

        {/* Le hero — le site en cours, dans sa DA. */}
        <div className="relative overflow-hidden rounded-2xl border border-white/10 p-5"
          style={style?.hero_url ? undefined : { background: `linear-gradient(135deg, ${accent}33, transparent)` }}>
          {style?.hero_url && (
            <>
              <img src={style.hero_url} alt="" className="absolute inset-0 h-full w-full object-cover opacity-40" />
              <span aria-hidden="true" className="absolute inset-0 bg-gradient-to-t from-[#0A0A0B] to-transparent" />
            </>
          )}
          <p className="relative font-mono text-[8px] font-semibold uppercase tracking-[0.22em] text-white/50">
            {style?.name ? `Direction · ${style.name}` : "Votre site en construction"}
          </p>
          <p className={`relative mt-1 text-xl font-extrabold text-white ${titreCls}`}>{siteName}</p>
        </div>

        {sections.length === 0 && (
          <p className="rounded-2xl border border-dashed border-white/15 px-6 py-10 text-center text-[12px] text-white/35">
            Glissez une étiquette de section ici — elle se génère déjà faite, nourrie par vos dépôts.
          </p>
        )}

        {sections.map(renduSection)}

        {/* La fin de tout : les cartes définitives — embarquables, partageables. */}
        {sections.length > 0 && (
          <button type="button" onClick={onFinal}
            className="flex w-full min-h-[44px] items-center justify-center gap-2 rounded-2xl text-[13px] font-bold text-black transition hover:opacity-90"
            style={{ background: "linear-gradient(90deg, #F2A7C3, #E8C97F, #7FDCB2, #7FC3F0, #C9A2F5)" }}>
            <Sparkles className="h-4 w-4" aria-hidden="true" /> Générer les cartes définitives
          </button>
        )}
      </div>
    </div>
  );
}