// UNE TUILE DE CONTEXTE — météo, budget, changements, plan B, décalage :
// les informations qui gravitent autour de l'anneau d'orchestration.
export default function OrchestraTuile({ icon: Icon, label, value, detail, tone = "neutral" }) {
  const tones = {
    neutral: "border-white/10 text-white",
    live: "border-sky-400/25 text-sky-300",
    alert: "border-amber-400/30 text-amber-300",
    ok: "border-emerald-400/25 text-emerald-300",
  };
  return (
    <div className={`rounded-2xl border bg-white/[0.02] px-4 py-3.5 ${tones[tone]}`}>
      <p className="flex items-center gap-1.5 font-mono text-[8.5px] font-semibold uppercase tracking-[0.16em] text-white/40">
        <Icon className="h-3 w-3" aria-hidden="true" />
        {label}
      </p>
      <p className="mt-1 font-heading text-[17px] font-semibold leading-tight">{value}</p>
      {detail && <p className="mt-0.5 text-[10.5px] leading-snug text-white/45">{detail}</p>}
    </div>
  );
}