import { useEffect, useRef, useState } from "react";
import { Sun, Wallet, Umbrella, TimerReset } from "lucide-react";
import OrchestraRing from "./OrchestraRing";
import OrchestraTuile from "./OrchestraTuile";
import { MOMENTS, DAY_START, DAY_END, DELAY_AT, DELAY_MIN, fmt } from "./orchestrationData";

// LE CENTRE D'ORCHESTRATION DU JOUR J — plus de cartes qui défilent :
// l'anneau arc-en-ciel du timing en plein centre, les agents qui parlent
// en temps réel, le contexte (météo, budget, plan B) autour, et le fil
// d'actualité en dessous. La journée se rejoue en boucle accélérée.
export default function JourJDemoTimeline() {
  const [clock, setClock] = useState(DAY_START);
  const [feed, setFeed] = useState([]);
  const lastMsg = useRef("");

  useEffect(() => {
    const t = setInterval(() => {
      setClock((c) => (c >= DAY_END ? DAY_START : c + 4));
    }, 900);
    return () => clearInterval(t);
  }, []);

  // Le retard : +8 min au départ du cortège, répercuté sur la suite.
  const retard = clock >= DELAY_AT ? DELAY_MIN : 0;
  const eff = (m) => m.t + (m.t > DELAY_AT ? retard : 0);

  const idx = Math.max(0, MOMENTS.reduce((acc, m, i) => (clock >= eff(m) ? i : acc), 0));
  const moment = MOMENTS[idx];
  const suivant = MOMENTS[idx + 1];
  const message = moment.messages[Math.floor(clock / 30) % moment.messages.length];
  const progress = (clock - DAY_START) / (DAY_END - DAY_START);

  // Le fil d'actualité : chaque nouveau message d'agent entre en tête.
  useEffect(() => {
    if (message === lastMsg.current) return;
    lastMsg.current = message;
    setFeed((f) => [{ heure: fmt(clock), texte: message, color: moment.color, role: moment.role }, ...f].slice(0, 3));
  }, [message]); // eslint-disable-line react-hooks/exhaustive-deps

  const invites = 86 + (clock >= 1020 ? 2 : 0);

  return (
    <section aria-label="Le centre d'orchestration du Jour J — démo temps réel" className="px-1">
      <div className="mb-6 flex items-baseline justify-between border-b border-white/10 pb-3">
        <h2 className="font-heading text-[16px] font-semibold tracking-tight text-white">Le Jour J, orchestré en direct</h2>
        <span className="font-mono text-[9px] font-semibold uppercase tracking-[0.18em] text-white/40">
          Démo · journée rejouée en boucle
        </span>
      </div>

      {/* LA COMPOSITION — tuiles à gauche · anneau au centre · tuiles à droite. */}
      <div className="grid items-center gap-5 lg:grid-cols-[1fr_auto_1fr]">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-1">
          <OrchestraTuile icon={Sun} label="Météo" value="24° · dégagé" detail="Éclaircies confirmées jusqu'à 23h" />
          <OrchestraTuile
            icon={Wallet} label="Budget live" tone="live"
            value={`${(invites * 145 + 12000).toLocaleString("fr-FR")} €`}
            detail={`${invites} invités confirmés · 145 €/invité`}
          />
        </div>

        <OrchestraRing
          progress={progress}
          heure={fmt(clock)}
          moment={moment}
          message={message}
          next={suivant ? { label: suivant.label, dans: Math.max(1, eff(suivant) - clock) } : null}
          retard={retard}
        />

        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-1">
          <OrchestraTuile
            icon={TimerReset} label="Décalage" tone={retard ? "alert" : "ok"}
            value={retard ? `+${retard} min` : "À l'heure"}
            detail={retard ? `Cérémonie ${fmt(900 + retard)} · cocktail ${fmt(1020 + retard)} — recalés` : "Tous les rôles sur la partition"}
          />
          <OrchestraTuile
            icon={Umbrella} label="Plan B" tone="ok" value="Prêt"
            detail="Salle de repli armée · bascule auto si pluie > 60 %"
          />
        </div>
      </div>

      {/* LE FIL D'ACTUALITÉ — les derniers messages d'orchestration. */}
      <div className="mt-6 space-y-1.5" aria-live="polite">
        {feed.map((f, i) => (
          <div
            key={f.heure + f.texte}
            className={`flex items-baseline gap-3 rounded-xl border border-white/8 bg-white/[0.02] px-4 py-2 ${i === 0 ? "ripple-wave" : ""}`}
            style={{ opacity: 1 - i * 0.3 }}
          >
            <span className="font-mono text-[10px] font-semibold text-white/40">{f.heure}</span>
            <span className="font-mono text-[8.5px] uppercase tracking-[0.14em]" style={{ color: f.color }}>{f.role}</span>
            <span className="min-w-0 flex-1 truncate text-[12px] text-white/60">{f.texte}</span>
          </div>
        ))}
      </div>
    </section>
  );
}