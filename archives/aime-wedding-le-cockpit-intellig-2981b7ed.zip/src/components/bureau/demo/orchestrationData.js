// LA PARTITION DU JOUR J — les moments (en minutes depuis minuit), le rôle
// qui porte chaque moment, et les messages d'orchestration de son agent.
export const DAY_START = 530; // 08:50
export const DAY_END = 1445; // 00:05

export const MOMENTS = [
  {
    t: 540, label: "Préparatifs", role: "Coiffure & Maquillage", color: "#d946ef",
    messages: [
      "Léa est en coiffure — la maquilleuse arrive dans 20 min, tout est calé.",
      "Le vidéaste capte les préparatifs. La photographe est prévenue pour 10:45.",
    ],
  },
  {
    t: 690, label: "Photos couple", role: "Photographe", color: "#38bdf8",
    messages: [
      "Lumière parfaite au jardin — la photographe a 45 min avec le couple.",
      "Le vidéaste double au drone. Le témoin prépare le cortège pendant ce temps.",
    ],
  },
  {
    t: 870, label: "Cortège en route", role: "Témoin", color: "#fbbf24",
    messages: [
      "⚠ Le cortège part avec 8 min de retard — je recale : cérémonie 15:08, cocktail 17:08.",
      "Les musiciens sont prévenus : ils allongent le prélude de 8 minutes.",
    ],
  },
  {
    t: 900, label: "Cérémonie", role: "Officiant·e", color: "#a78bfa",
    messages: [
      "L'officiante ouvre la cérémonie — décalage absorbé, on est à +8 min maîtrisées.",
      "Le traiteur profite du délai : le dressage du cocktail sera prêt pile à l'heure recalée.",
    ],
  },
  {
    t: 1020, label: "Cocktail", role: "Traiteur", color: "#2dd4bf",
    messages: [
      "Service lancé à 17:08 comme recalé. Le DJ installe la sono pendant le service.",
      "2 invités viennent de confirmer — plan de table et budget recalculés automatiquement.",
    ],
  },
  {
    t: 1110, label: "Golden hour", role: "Photographe", color: "#38bdf8",
    messages: [
      "La photographe s'éclipse 15 min avec le couple — golden hour, fenêtre idéale.",
      "Le témoin garde son discours au chaud pour 20:40, après le service chaud.",
    ],
  },
  {
    t: 1200, label: "Dîner", role: "Traiteur", color: "#2dd4bf",
    messages: [
      "Entrées servies. Le discours du témoin est calé entre le plat et le dessert.",
      "Ciel dégagé confirmé pour 22h : le lâcher de lanternes reste au plan A.",
    ],
  },
  {
    t: 1350, label: "Ouverture du bal", role: "DJ", color: "#fb7185",
    messages: [
      "Le DJ lance la première danse — la photographe est en place côté piste.",
      "Montée en tempo validée avec le couple : 3 titres doux puis la playlist festive.",
    ],
  },
  {
    t: 1440, label: "Piste de danse", role: "DJ", color: "#fb7185",
    messages: [
      "Piste pleine. Le traiteur prépare le bar à minuit, navettes invités prévenues.",
    ],
  },
];

// Le retard injecté dans la démo : +8 min au départ du cortège (t=870),
// répercuté sur tous les moments suivants.
export const DELAY_AT = 870;
export const DELAY_MIN = 8;

export const fmt = (min) => {
  const m = ((min % 1440) + 1440) % 1440;
  return `${String(Math.floor(m / 60)).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`;
};