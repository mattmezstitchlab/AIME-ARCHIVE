// L'ANNEAU D'ORCHESTRATION — le cœur graphique : contour arc-en-ciel qui
// progresse avec la journée, et au centre l'heure, le moment en cours et
// le message de l'agent du rôle qui défile.
const RAINBOW = ["#ff5f6d", "#ffc371", "#c9f76f", "#38bdf8", "#c084fc"];

export default function OrchestraRing({ progress, heure, moment, message, next, retard }) {
  const deg = Math.max(2, progress * 360);
  const stops = RAINBOW.map((c, i) => `${c} ${(deg * i) / (RAINBOW.length - 1)}deg`).join(", ");

  return (
    <div className="relative mx-auto h-[300px] w-[300px] sm:h-[340px] sm:w-[340px]">
      {/* Le contour progressif arc-en-ciel. */}
      <div
        className="absolute inset-0 rounded-full transition-all duration-700"
        style={{
          background: `conic-gradient(${stops}, rgba(255,255,255,0.07) ${deg}deg)`,
          WebkitMask: "radial-gradient(farthest-side, transparent calc(100% - 9px), #000 calc(100% - 8px))",
          mask: "radial-gradient(farthest-side, transparent calc(100% - 9px), #000 calc(100% - 8px))",
        }}
        aria-hidden="true"
      />

      {/* Le centre — l'heure, le moment, l'agent qui parle. */}
      <div className="absolute inset-[16px] flex flex-col items-center justify-center rounded-full border border-white/10 bg-[#101014] px-7 text-center">
        <p className="font-mono text-[26px] font-semibold tracking-tight text-white">{heure}</p>
        <p className="mt-1 flex items-center gap-1.5 font-mono text-[9px] font-semibold uppercase tracking-[0.2em]" style={{ color: moment.color }}>
          <span className="h-1.5 w-1.5 rounded-full animate-pulse" style={{ background: moment.color }} aria-hidden="true" />
          {moment.label} · {moment.role}
        </p>
        <p key={message} className="ripple-wave mt-3 min-h-[54px] text-[12px] leading-relaxed text-white/70">
          {message}
        </p>
        <p className="mt-2 font-mono text-[8.5px] uppercase tracking-[0.16em] text-white/35">
          {next ? `Prochain · ${next.label} dans ${next.dans} min` : "Dernier moment de la journée"}
        </p>
        {retard > 0 && (
          <p className="mt-1.5 rounded-full border border-amber-400/30 bg-amber-400/10 px-2.5 py-0.5 font-mono text-[8.5px] font-semibold uppercase tracking-[0.14em] text-amber-300">
            Décalage +{retard} min · recalé
          </p>
        )}
      </div>
    </div>
  );
}