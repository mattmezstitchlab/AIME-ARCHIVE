import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowRight, Plus, ShieldCheck, X } from "lucide-react";
import EaaAuditTab from "@/components/gallery/EaaAuditTab";
import CapsuleForfaits from "@/components/bureau/CapsuleForfaits";
import CapsulePanneau from "@/components/bureau/capsule/CapsulePanneau";

// LA CAPSULE AI+ME — le bijou unique au centre du Bureau. Elle SE LIT :
// [ AI ] [ + arc-en-ciel ] [ ME ]. À gauche, AI : indiquer une URL → le
// PIPELINE EAA s'ouvre dans le panneau du +. Au centre, le + ouvre le
// panneau d'outils (Pipeline EAA : URL, résultats, et la suite).
// À droite, ME : rejoindre une adresse « +nom ».
const GRAD = "conic-gradient(from 0deg, #F2A7C3, #E8C97F, #7FDCB2, #7FC3F0, #C9A2F5, #F2A7C3)";

const slugifier = (txt) =>
  txt.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/^\+/, "").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");

export default function CapsuleAime() {
  const [mode, setMode] = useState(null); // null | "ai" | "me"
  const [pipeline, setPipeline] = useState(false); // le Pipeline EAA (via AI ou le dossier)
  const [panneau, setPanneau] = useState(false); // le panneau du + : dossier du projet
  const [forfaits, setForfaits] = useState(false); // le panneau ME : essai offert & forfaits
  const [valeur, setValeur] = useState("");
  const navigate = useNavigate();
  const ouvert = mode !== null || pipeline || forfaits || panneau;

  const toutFermer = () => { setMode(null); setPipeline(false); setForfaits(false); setPanneau(false); };
  const ouvrir = (m) => { setPipeline(false); setForfaits(false); setPanneau(false); setMode((x) => (x === m ? null : m)); setValeur(""); };
  const valider = (e) => {
    e.preventDefault();
    const v = valeur.trim();
    if (!v) return;
    if (mode === "ai") {
      // L'URL entre dans le PIPELINE EAA — tout se passe dans le panneau du +.
      sessionStorage.setItem("aime-eaa-url", /^https?:\/\//i.test(v) ? v : `https://${v}`);
      setMode(null); setPipeline(true);
    } else {
      navigate(`/+${slugifier(v)}`);
    }
  };

  const cote = (actif) =>
    `flex min-h-[64px] w-24 items-center justify-center rounded-full font-heading text-[38px] font-extrabold leading-none tracking-[-0.04em] transition ${actif ? "bg-white/15 text-white" : "text-white/85 hover:bg-white/10 hover:text-white"}`;

  return (
    <div className="flex w-full flex-col items-center">
      {/* LE BIJOU — AI + ME, rien d'autre : la capsule noire au centre. */}
      <div className="flex items-center gap-3 rounded-full border border-white/10 bg-[#141418]/90 px-4 py-3 shadow-2xl backdrop-blur-xl">
        <button type="button" onClick={() => ouvrir("ai")} aria-expanded={mode === "ai"}
          aria-label="AI — auditer une URL (EAA)" className={cote(mode === "ai")}>
          AI
        </button>

        {/* LE + ARC-EN-CIEL — ouvre le DOSSIER DU PROJET (Point Zéro) ; ✕ referme tout. */}
        <button
          type="button"
          onClick={() => (ouvert ? toutFermer() : setPanneau(true))}
          aria-label={ouvert ? "Refermer" : "Ouvrir le dossier du projet"}
          aria-expanded={panneau}
          className="flex h-16 w-16 items-center justify-center self-center text-black shadow-[0_0_28px_rgba(201,169,110,0.5)] transition-all duration-300 hover:scale-110"
          style={{ background: GRAD, borderRadius: ouvert ? "14px" : "9999px" }}
        >
          <Plus className={`h-7 w-7 transition-transform duration-300 ${ouvert ? "rotate-45" : ""}`} strokeWidth={3} />
        </button>

        <button type="button" onClick={() => { setMode(null); setPipeline(false); setPanneau(false); setValeur(""); setForfaits((f) => !f); }}
          aria-expanded={forfaits} aria-label="ME — adresses +nom et forfaits" className={cote(forfaits)}>
          ME
        </button>
      </div>

      {/* LE CHAMP — apparaît sous le bijou selon le côté choisi. */}
      {mode && (
        <form onSubmit={valider} className="ripple-wave mt-4 flex w-full max-w-md items-center gap-2 rounded-full border border-white/10 bg-[#141418]/90 p-1.5 pl-4 backdrop-blur-xl transition-colors focus-within:border-white/35">
          {mode === "me" && <span className="text-[15px] font-bold text-white/50" aria-hidden="true">+</span>}
          <input
            autoFocus
            value={valeur}
            onChange={(e) => setValeur(e.target.value)}
            placeholder={mode === "ai" ? "https://mon-site.fr" : "lea-tom"}
            aria-label={mode === "ai" ? "URL du site à auditer (EAA)" : "Adresse +nom à visiter"}
            className="min-h-[40px] flex-1 bg-transparent text-[13px] text-white outline-none placeholder:text-white/30 focus-visible:!shadow-none"
          />
          <button type="submit" disabled={!valeur.trim()}
            className="flex min-h-[40px] items-center gap-1.5 rounded-full bg-white px-4 text-[12px] font-bold text-black transition hover:bg-white/85 disabled:opacity-30">
            {mode === "ai" ? "Auditer" : "Visiter"} <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
          </button>
        </form>
      )}

      {/* LE PANNEAU DU + — le DOSSIER DU PROJET façon Framer / Paper :
          arbre à gauche, canevas déplaçable au centre, réglages à droite,
          dépôt Point Zéro (fichiers, liens, captures, textes) en bas. */}
      {panneau && (
        <CapsulePanneau
          onClose={() => setPanneau(false)}
          onPipeline={() => { setPanneau(false); setPipeline(true); }}
        />
      )}

      {/* LE PIPELINE EAA — URL, audit, style, site → verse dans le Studio. */}
      {pipeline && (
        <section className="ripple-wave dark mt-5 w-full max-w-4xl rounded-3xl border border-white/10 bg-[#0e0e11]/95 p-5 shadow-2xl backdrop-blur-xl" aria-label="Pipeline EAA">
          <div className="mb-4 flex items-center justify-between gap-3">
            <p className="flex items-center gap-2 text-[13px] font-extrabold text-white">
              <ShieldCheck className="h-4 w-4 text-[#7FDCB2]" aria-hidden="true" /> Pipeline EAA
              <span className="font-mono text-[8px] font-semibold uppercase tracking-[0.22em] text-white/35">URL → audit → résultats → la suite</span>
            </p>
            <button type="button" onClick={() => setPipeline(false)} aria-label="Fermer le Pipeline EAA"
              className="flex h-9 w-9 items-center justify-center rounded-full text-white/50 transition hover:bg-white/10 hover:text-white">
              <X className="h-4 w-4" />
            </button>
          </div>
          <EaaAuditTab onStudio={() => { setPipeline(false); setPanneau(true); }} />
        </section>
      )}

      {/* LE PANNEAU ME — essai offert & forfaits : l'adresse +nom se gagne. */}
      {forfaits && (
        <CapsuleForfaits
          onEssai={() => { setForfaits(false); ouvrir("ai"); }}
          onVisiter={() => { setForfaits(false); ouvrir("me"); }}
          onClose={() => setForfaits(false)}
        />
      )}

    </div>
  );
}