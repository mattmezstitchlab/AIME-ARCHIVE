import { useState, useRef } from "react";
import JSZip from "jszip";
import { UploadCloud, Loader2, Check, Package, FolderInput, X } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { base44 } from "@/api/base44Client";
import { buildTree, countTree, formatSize } from "@/lib/bureau/archiveTree";
import FileTreeNode from "./FileTreeNode";

// Dossiers de rangement proposés dans le Bureau (façon template).
const DESTINATIONS = ["Bureau", "Templates", "Sites générés", "Archives", "AVANT › Documents"];

// ─────────────────────────────────────────────────────────────────────────
// Fenêtre d'import d'archive — le flux façon Cocoon :
//   1. On dépose / choisit un .zip.
//   2. On lit son contenu et on affiche l'arborescence des dossiers & fichiers.
//   3. On choisit où le ranger (comme un template), on nomme, on enregistre.
// L'archive est déposée dans le Bureau via SavedArchive (fichier + métadonnées).
// ─────────────────────────────────────────────────────────────────────────
export default function ImportArchiveDialog({ open, onOpenChange, onSaved }) {
  const inputRef = useRef(null);
  const [file, setFile] = useState(null);
  const [tree, setTree] = useState(null);
  const [counts, setCounts] = useState({ files: 0, dirs: 0 });
  const [reading, setReading] = useState(false);
  const [error, setError] = useState(null);
  const [label, setLabel] = useState("");
  const [dest, setDest] = useState(DESTINATIONS[0]);
  const [saving, setSaving] = useState(false);
  const [done, setDone] = useState(false);

  const reset = () => {
    setFile(null); setTree(null); setCounts({ files: 0, dirs: 0 });
    setReading(false); setError(null); setLabel(""); setDest(DESTINATIONS[0]);
    setSaving(false); setDone(false);
  };

  const handleClose = (v) => { if (!v) reset(); onOpenChange(v); };

  // Lit l'archive côté navigateur et construit son arborescence.
  const readArchive = async (f) => {
    setError(null);
    setReading(true);
    setFile(f);
    setLabel(f.name);
    try {
      const zip = await JSZip.loadAsync(f);
      const entries = [];
      zip.forEach((path, entry) => {
        if (!entry.dir) {
          entries.push({ path, size: entry._data?.uncompressedSize || 0 });
        }
      });
      if (entries.length === 0) { setError("Cette archive est vide."); setTree(null); }
      else {
        const t = buildTree(entries);
        setTree(t);
        setCounts(countTree(t));
      }
    } catch {
      setError("Impossible de lire cette archive. Formats acceptés : .zip");
      setTree(null);
    } finally {
      setReading(false);
    }
  };

  const onPick = (e) => {
    const f = e.target.files?.[0];
    if (f) readArchive(f);
  };

  const onDrop = (e) => {
    e.preventDefault();
    const f = e.dataTransfer.files?.[0];
    if (f) readArchive(f);
  };

  // Enregistre l'archive dans le Bureau (upload + fiche SavedArchive).
  const save = async () => {
    if (!file || !tree) return;
    setSaving(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      await base44.entities.SavedArchive.create({
        label: label.trim() || file.name,
        file_url,
        path: dest,
        file_count: counts.files,
        size_kb: Math.round(file.size / 1024),
      });
      setDone(true);
      onSaved?.();
      setTimeout(() => handleClose(false), 1100);
    } catch {
      setError("Le rangement a échoué. Réessayez.");
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="dark max-w-lg gap-0 border-white/10 bg-neutral-950 p-0 text-white">
        <DialogHeader className="border-b border-white/10 px-5 py-4">
          <DialogTitle className="flex items-center gap-2 text-[15px] font-semibold">
            <FolderInput className="h-4 w-4 text-accent" /> Importer une archive
          </DialogTitle>
        </DialogHeader>

        <div className="max-h-[70vh] overflow-y-auto scrollbar-hide p-5">
          {done ? (
            <div className="flex flex-col items-center py-10 text-center">
              <div className="grid h-14 w-14 place-items-center rounded-full bg-emerald-500/15 text-emerald-300">
                <Check className="h-7 w-7" />
              </div>
              <p className="mt-4 text-[15px] font-semibold">Rangé dans « {dest} »</p>
              <p className="mt-1 text-[12px] text-white/50">{label}</p>
            </div>
          ) : !tree ? (
            /* Étape 1 — dépôt du fichier */
            <>
              <div
                onDrop={onDrop}
                onDragOver={(e) => e.preventDefault()}
                onClick={() => inputRef.current?.click()}
                className="flex cursor-pointer flex-col items-center justify-center rounded-2xl border border-dashed border-white/20 bg-white/[0.02] px-6 py-12 text-center transition hover:border-accent/50 hover:bg-white/[0.04]"
              >
                {reading ? (
                  <Loader2 className="h-8 w-8 animate-spin text-accent" />
                ) : (
                  <UploadCloud className="h-8 w-8 text-white/40" />
                )}
                <p className="mt-3 text-[14px] font-medium text-white">
                  {reading ? "Lecture de l'archive…" : "Glissez un fichier .zip ici"}
                </p>
                <p className="mt-1 text-[12px] text-white/45">ou cliquez pour parcourir vos fichiers</p>
                <input ref={inputRef} type="file" accept=".zip,application/zip" onChange={onPick} className="hidden" />
              </div>
              {error && <p className="mt-3 text-center text-[12px] text-amber-300">{error}</p>}
            </>
          ) : (
            /* Étape 2 — aperçu de l'arborescence + rangement */
            <>
              <div className="mb-3 flex items-center gap-3 rounded-xl bg-white/[0.04] px-4 py-3">
                <Package className="h-5 w-5 shrink-0 text-accent" />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[13px] font-medium">{file.name}</p>
                  <p className="text-[11px] text-white/45">
                    {counts.files} fichier{counts.files > 1 ? "s" : ""} · {counts.dirs} dossier{counts.dirs > 1 ? "s" : ""} · {formatSize(file.size)}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={reset}
                  aria-label="Changer de fichier"
                  className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-white/10 text-white/60 hover:bg-white/20"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>

              <p className="mb-1.5 text-[10px] font-semibold uppercase tracking-[0.14em] text-white/40">Contenu de l'archive</p>
              <div className="mb-4 max-h-56 overflow-y-auto scrollbar-hide rounded-xl border border-white/10 bg-black/40 p-2">
                {tree.children.map((child) => (
                  <FileTreeNode key={child.path} node={child} />
                ))}
              </div>

              <label className="block">
                <span className="text-[10px] font-semibold uppercase tracking-[0.14em] text-white/40">Nom</span>
                <input
                  value={label}
                  onChange={(e) => setLabel(e.target.value)}
                  className="mt-1 w-full rounded-lg bg-white/[0.06] px-3 py-2 text-[13px] text-white placeholder:text-white/30 focus:outline-none"
                />
              </label>

              <div className="mt-3">
                <span className="text-[10px] font-semibold uppercase tracking-[0.14em] text-white/40">Ranger dans</span>
                <div className="mt-1.5 flex flex-wrap gap-1.5">
                  {DESTINATIONS.map((d) => (
                    <button
                      key={d}
                      type="button"
                      onClick={() => setDest(d)}
                      className={`rounded-full px-3 py-1.5 text-[12px] font-medium transition ${
                        dest === d ? "bg-accent text-accent-foreground" : "bg-white/[0.06] text-white/60 hover:bg-white/10"
                      }`}
                    >
                      {d}
                    </button>
                  ))}
                </div>
              </div>

              {error && <p className="mt-3 text-[12px] text-amber-300">{error}</p>}

              <button
                type="button"
                onClick={save}
                disabled={saving}
                className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-full bg-white px-4 py-2.5 text-[13px] font-semibold text-black transition hover:bg-white/90 disabled:opacity-50"
              >
                {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <FolderInput className="h-4 w-4" />}
                {saving ? "Rangement en cours…" : `Ranger dans « ${dest} »`}
              </button>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}