import { useState } from "react";
import { Folder, FolderOpen, File, ChevronRight } from "lucide-react";
import { formatSize } from "@/lib/bureau/archiveTree";

// ─────────────────────────────────────────────────────────────────────────
// Nœud d'arborescence repliable — dossier ou fichier — façon explorateur.
// Les dossiers de premier niveau sont ouverts par défaut.
// ─────────────────────────────────────────────────────────────────────────
export default function FileTreeNode({ node, depth = 0 }) {
  const [open, setOpen] = useState(depth < 1);

  if (!node.dir) {
    return (
      <div
        className="flex items-center gap-2 rounded-md py-1 text-[12px] text-white/70 hover:bg-white/[0.04]"
        style={{ paddingLeft: 8 + depth * 16 }}
      >
        <File className="h-3.5 w-3.5 shrink-0 text-white/35" />
        <span className="min-w-0 flex-1 truncate">{node.name}</span>
        <span className="shrink-0 text-[10px] text-white/30">{formatSize(node.size)}</span>
      </div>
    );
  }

  return (
    <div>
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="flex w-full items-center gap-1.5 rounded-md py-1 text-left text-[12px] font-medium text-white/85 hover:bg-white/[0.05]"
        style={{ paddingLeft: 4 + depth * 16 }}
      >
        <ChevronRight className={`h-3.5 w-3.5 shrink-0 text-white/40 transition-transform ${open ? "rotate-90" : ""}`} />
        {open ? <FolderOpen className="h-3.5 w-3.5 shrink-0 text-accent" /> : <Folder className="h-3.5 w-3.5 shrink-0 text-accent" />}
        <span className="min-w-0 flex-1 truncate">{node.name || "/"}</span>
        <span className="shrink-0 pr-2 text-[10px] text-white/25">{node.children.length}</span>
      </button>
      {open && node.children.map((child) => (
        <FileTreeNode key={child.path} node={child} depth={depth + 1} />
      ))}
    </div>
  );
}