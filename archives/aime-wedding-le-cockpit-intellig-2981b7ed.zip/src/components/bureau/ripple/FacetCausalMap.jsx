import { facetDone } from "@/lib/bureau/projectFacets";

// LE MINI-SCHÉMA CAUSAL — embarqué sur chaque carte : toutes les facettes du
// projet comme repère. Blanc = complétée, blanc 60% = commencée, gris = vide ;
// la facette de la carte est cerclée. Points ET libellés sont CLIQUABLES :
// ils ouvrent directement la bonne carte (onSelect).
export default function FacetCausalMap({ facets = [], values, activeKey, pulse, onSelect }) {
  if (!facets.length) return null;

  const state = (f) => {
    const total = (f.items || []).length;
    const done = facetDone(f, values);
    return total > 0 && done === total ? "complete" : done > 0 ? "started" : "empty";
  };
  const fill = { complete: "#ffffff", started: "rgba(255,255,255,0.6)", empty: "#242424" };
  const go = (e, key) => {
    e.stopPropagation();
    onSelect?.(key);
  };

  return (
    <div aria-label="Position de la carte dans le projet">
      {/* Le chemin : une piste avec un point par facette */}
      <div className="relative h-1 rounded-full bg-white/20">
        {facets.map((f, i) => {
          const isActive = f.key === activeKey;
          const s = state(f);
          const left = facets.length > 1 ? (i / (facets.length - 1)) * 100 : 50;
          const Dot = onSelect ? "button" : "span";
          return (
            <Dot
              key={f.key}
              {...(onSelect ? { type: "button", onClick: (e) => go(e, f.key), "aria-label": `Ouvrir ${f.label}`, title: f.label } : {})}
              className={`absolute top-1/2 h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full border transition-colors duration-500 ${
                pulse && isActive ? "animate-ping-slow" : ""
              } ${onSelect ? "cursor-pointer hover:scale-125" : ""}`}
              style={{
                left: `${left}%`,
                background: fill[s],
                borderColor: isActive ? f.color || "#fff" : "rgba(255,255,255,0.3)",
                boxShadow: isActive ? `0 0 0 3px ${(f.color || "#ffffff")}55` : undefined,
              }}
            />
          );
        })}
      </div>

      {/* Les repères nommés — cliquables aussi : ils mènent à la bonne carte */}
      <div className="mt-2 flex flex-wrap gap-x-3 gap-y-1">
        {facets.map((f) => {
          const isActive = f.key === activeKey;
          const s = state(f);
          const Label = onSelect ? "button" : "span";
          return (
            <Label
              key={f.key}
              {...(onSelect ? { type: "button", onClick: (e) => go(e, f.key) } : {})}
              className={`inline-flex items-center gap-1 ${onSelect ? "cursor-pointer transition hover:opacity-80" : ""}`}
            >
              <span className="h-1.5 w-1.5 rounded-full" style={{ background: f.color || "#9ca3af" }} />
              <span
                className={`font-mono text-[8px] font-semibold uppercase tracking-[0.14em] ${
                  isActive ? "text-white" : s === "complete" ? "text-white/80" : "text-white/40"
                }`}
              >
                {f.label}
              </span>
            </Label>
          );
        })}
      </div>
    </div>
  );
}