import { useState } from "react";
import { Waves, Loader2 } from "lucide-react";
import { deepenProject } from "@/lib/bureau/projectDeepen";

// ALLER PLUS LOIN — la vague causale : Ripple relit le projet et
// propose de nouvelles questions ciblées (et parfois de nouvelles cartes).
export default function RippleDeepenBar({ project, onDeepened }) {
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  const go = async () => {
    if (loading) return;
    setLoading(true);
    setMessage("");
    const res = await deepenProject(project);
    onDeepened(res);
    setMessage(res.message);
    setLoading(false);
  };

  return (
    <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-3.5">
      <div className="flex items-center justify-between gap-3">
        <p className="text-[12.5px] text-white/45">
          Ripple peut relire vos réponses et <b className="font-medium text-white/75">approfondir le projet</b> — nouvelles questions ciblées, nouvelles cartes si besoin.
        </p>
        <button
          type="button"
          onClick={go}
          disabled={loading}
          className="inline-flex shrink-0 items-center gap-1.5 rounded-xl border border-white/15 bg-white/[0.06] px-3.5 py-2 text-[12px] font-semibold text-white/80 transition hover:bg-white/[0.12] hover:text-white disabled:opacity-40"
        >
          {loading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Waves className="h-3.5 w-3.5" />}
          {loading ? "Ripple relit tout…" : "Aller plus loin"}
        </button>
      </div>
      {message && (
        <p className="ripple-wave mt-2 rounded-xl border border-white/10 bg-white/[0.05] px-3 py-2 text-[12px] leading-5 text-white/70">
          {message}
        </p>
      )}
    </div>
  );
}