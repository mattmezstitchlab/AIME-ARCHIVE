import { X } from "lucide-react";

// L'EN-TÊTE DU PROJET — sobre : titre, type, fermeture. Les questions ont
// disparu : tout se règle au verso des cartes, avec l'agent IA.
export default function ProjectHeaderBar({ project, onClose }) {
  return (
    <div className="flex items-start justify-between gap-3 rounded-2xl border border-white/10 bg-white/[0.02] px-4 py-3.5">
      <div>
        <p className="font-mono text-[10px] font-semibold uppercase tracking-[0.24em] text-white/45">
          Ripple · {project.project_type || project.intent}
        </p>
        <h2 className="mt-1 text-lg font-semibold tracking-tight text-white">
          {project.project_title || project.intent}
        </h2>
      </div>
      <button
        type="button"
        onClick={onClose}
        aria-label="Fermer le projet"
        className="rounded-lg p-1.5 text-white/40 transition hover:bg-white/10 hover:text-white"
      >
        <X className="h-4 w-4" />
      </button>
    </div>
  );
}