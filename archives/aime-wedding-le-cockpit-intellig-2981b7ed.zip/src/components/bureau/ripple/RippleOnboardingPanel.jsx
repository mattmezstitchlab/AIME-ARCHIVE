import { X } from "lucide-react";
import RippleQuestionCard from "./RippleQuestionCard";

// L'ONBOARDING GÉNÉRÉ — les questions de Ripple, groupées par dossier.
// Style figé « bloc agent » : neutre, épuré, aucun doré.
export default function RippleOnboardingPanel({ ob, onAnswer, onClear }) {
  const questions = ob.questions || [];
  const answered = questions.filter((q) => {
    const v = ob.answers?.[q.id];
    return v !== undefined && v !== null && v !== "";
  }).length;

  // Groupement par dossier, dans l'ordre d'apparition.
  const folders = [];
  for (const q of questions) {
    const f = q.folder || "Questions";
    let g = folders.find((x) => x.name === f);
    if (!g) { g = { name: f, items: [] }; folders.push(g); }
    g.items.push(q);
  }

  return (
    <section className="rounded-2xl border border-white/10 bg-white/[0.02] p-4 sm:p-5" aria-label="Onboarding généré par Ripple">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="font-mono text-[10px] font-semibold uppercase tracking-[0.24em] text-white/45">
            Ripple · {ob.project_type || ob.intent}
          </p>
          <h2 className="mt-1.5 text-lg font-semibold tracking-tight text-white">{ob.project_title || ob.intent}</h2>
          {ob.intro && <p className="mt-1.5 max-w-2xl text-[13px] leading-5 text-white/50">{ob.intro}</p>}
        </div>
        <div className="flex shrink-0 items-center gap-2">
          <span className="rounded-full border border-white/10 bg-white/[0.06] px-2.5 py-1 font-mono text-[10px] text-white/60">
            {answered}/{questions.length} répondues
          </span>
          <button
            type="button"
            onClick={onClear}
            aria-label="Fermer le projet"
            className="rounded-lg p-1.5 text-white/40 transition hover:bg-white/10 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>

      <div className="mt-4 h-1 overflow-hidden rounded-full bg-white/[0.08]" aria-hidden="true">
        <div
          className="h-full rounded-full bg-white/70 transition-all duration-500"
          style={{ width: `${questions.length ? (answered / questions.length) * 100 : 0}%` }}
        />
      </div>

      <div className="mt-5 space-y-5">
        {folders.map((f) => (
          <div key={f.name}>
            <p className="mb-2 font-mono text-[10px] font-semibold uppercase tracking-[0.2em] text-white/35">
              {f.name}
            </p>
            <div className="grid gap-2.5 sm:grid-cols-2">
              {f.items.map((q) => (
                <RippleQuestionCard key={q.id} question={q} value={ob.answers?.[q.id]} onChange={(v) => onAnswer(q.id, v)} />
              ))}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}