import { useEffect, useRef, useState } from "react";
import { Undo2, Check, ChevronRight, LayoutTemplate } from "lucide-react";
import FacetCausalMap from "./FacetCausalMap";
import FacetTemplatePanel from "./FacetTemplatePanel";
import FacetItemSettings from "./FacetItemSettings";
import FacetAgentChat from "./FacetAgentChat";
import { facetDone } from "@/lib/bureau/projectFacets";

// LA CARTE UNIVERSELLE — recto = visuel + titre + timeline causale CLIQUABLE
// (chaque point / libellé ouvre la bonne carte) ; verso = les réglages, et en
// bas L'AGENT IA SPÉCIALISTE de la carte : on converse, on joint des fichiers,
// il enregistre lui-même les réglages.
export default function ProjectFacetCard({ facet, facets, kicker, values, flipped, onToggle, onSave, onSelectFacet, direction, onUpdateFacet }) {
  const done = facetDone(facet, values);
  const total = (facet.items || []).length;
  const vals = values?.[facet.key] || {};
  const [openItem, setOpenItem] = useState(null);
  const [showTpl, setShowTpl] = useState(false);

  // Onde causale : quand une info arrive (verso, agent ou propagation),
  // le recto clignote pour montrer la mise à jour en temps réel.
  const [pulse, setPulse] = useState(false);
  const prevDone = useRef(done);
  useEffect(() => {
    if (done > prevDone.current) {
      setPulse(true);
      const t = setTimeout(() => setPulse(false), 1800);
      prevDone.current = done;
      return () => clearTimeout(t);
    }
    prevDone.current = done;
  }, [done]);

  const isFilled = (id) => {
    const v = vals[id];
    return v !== undefined && v !== null && v !== "";
  };

  return (
    <div className="h-[420px]" style={{ perspective: "1200px" }}>
      <div
        className="relative h-full w-full transition-transform duration-500"
        style={{ transformStyle: "preserve-3d", transform: flipped ? "rotateY(180deg)" : "none" }}
      >
        {/* RECTO — le visuel, le titre, la timeline causale cliquable */}
        <div
          role="button"
          tabIndex={0}
          onClick={onToggle}
          onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); onToggle(); } }}
          aria-expanded={flipped}
          aria-label={`Ouvrir la carte ${facet.label}`}
          className={`absolute inset-0 cursor-pointer overflow-hidden rounded-2xl border border-white/12 text-left transition-colors hover:border-white/30 ${
            pulse ? "mariage-ripple-pulse" : ""
          }`}
          style={{ backfaceVisibility: "hidden" }}
        >
          {facet.image_url ? (
            <img src={facet.image_url} alt="" className="absolute inset-0 h-full w-full object-cover" />
          ) : (
            <span
              className="absolute inset-0"
              style={{ background: `linear-gradient(160deg, ${(facet.color || "#9ca3af")}33 0%, #0d0d0d 70%)` }}
              aria-hidden="true"
            />
          )}
          <span className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" aria-hidden="true" />

          <span className="relative flex h-full flex-col justify-end p-4">
            <span className="font-mono text-[9px] font-semibold uppercase tracking-[0.26em] text-white/60">
              {kicker}
            </span>
            <span className="mt-1 font-heading text-[24px] font-semibold leading-tight text-white">
              {facet.label}
            </span>
            <span className="mt-1.5 inline-flex items-center gap-1.5 text-[11px] text-white/75">
              <Check className="h-3.5 w-3.5" />
              {done}/{total} paramétrés
            </span>
            <span className="mt-3 block">
              <FacetCausalMap facets={facets} values={values} activeKey={facet.key} pulse={pulse} onSelect={onSelectFacet} />
            </span>
          </span>
        </div>

        {/* VERSO — le visuel généré occupe TOUT le format ; les réglages par-dessus */}
        <div
          className="absolute inset-0 flex flex-col overflow-hidden rounded-2xl border border-white/12"
          style={{ backfaceVisibility: "hidden", transform: "rotateY(180deg)", background: "#131316" }}
        >
          {facet.image_url && (
            <img src={facet.image_url} alt="" aria-hidden="true" className="absolute inset-0 h-full w-full object-cover" />
          )}
          <span className="absolute inset-0 bg-black/80 backdrop-blur-sm" aria-hidden="true" />
          <div className="relative flex min-h-0 flex-1 flex-col p-4">
          {openItem ? (
            <FacetItemSettings
              facet={facet}
              item={openItem}
              values={vals}
              onClose={() => setOpenItem(null)}
              onValidate={(v) => {
                onSave(facet.key, openItem.id, v);
                setOpenItem(null);
              }}
            />
          ) : showTpl ? (
            <FacetTemplatePanel
              facet={facet}
              tpl={vals._tpl || {}}
              absorbe={vals._absorbe}
              palette={direction?.palette}
              onClose={() => setShowTpl(false)}
              onSaveTpl={(t) => onSave(facet.key, "_tpl", t)}
              onImage={(url) => onUpdateFacet?.(facet.key, { image_url: url })}
              onAbsorb={(t) => onSave(facet.key, "_absorbe", t)}
            />
          ) : (
            <>
              <div className="mb-2 flex items-start justify-between gap-2">
                <div>
                  <p className="font-mono text-[9px] font-semibold uppercase tracking-[0.24em] text-white/45">
                    {kicker}
                  </p>
                  <p className="mt-1 font-heading text-[17px] font-semibold text-white">{facet.label}</p>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => setShowTpl(true)}
                    aria-label={`Template de mise en page de ${facet.label} — hero, section, typo, couleur, visuel`}
                    className="rounded-full p-1.5 text-white/40 hover:bg-white/10 hover:text-white"
                  >
                    <LayoutTemplate className="h-4 w-4" />
                  </button>
                  <button
                    type="button"
                    onClick={onToggle}
                    aria-label={`Refermer la carte ${facet.label}`}
                    className="rounded-full p-1.5 text-white/40 hover:bg-white/10 hover:text-white"
                  >
                    <Undo2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
              <div className="scrollbar-hide min-h-0 flex-1 space-y-1 overflow-y-auto">
                {(facet.items || []).map((it) => (
                  <button
                    key={it.id}
                    type="button"
                    onClick={() => setOpenItem(it)}
                    className="flex w-full items-center gap-2.5 rounded-lg border border-white/8 px-2.5 py-2.5 text-left transition-colors hover:border-white/25 hover:bg-white/5"
                  >
                    <span
                      className={`flex h-4 w-4 shrink-0 items-center justify-center rounded border ${
                        isFilled(it.id) ? "border-white bg-white text-black" : "border-white/30"
                      }`}
                    >
                      {isFilled(it.id) && <Check className="h-3 w-3" />}
                    </span>
                    <span className="flex-1 truncate text-[12px] text-white/85">{it.label}</span>
                    <ChevronRight className="h-3.5 w-3.5 shrink-0 text-white/30" />
                  </button>
                ))}
              </div>

              {/* L'AGENT DE LA CARTE — il pose les questions et remplit lui-même */}
              <FacetAgentChat
                facet={facet}
                values={vals}
                onSaveItem={(itemId, v) => onSave(facet.key, itemId, v)}
              />
            </>
          )}
          </div>
        </div>
      </div>
    </div>
  );
}