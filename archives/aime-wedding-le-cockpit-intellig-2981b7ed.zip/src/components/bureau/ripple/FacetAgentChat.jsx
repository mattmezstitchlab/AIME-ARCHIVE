import { useState, useRef } from "react";
import { Send, Paperclip, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";

// L'AGENT DE LA CARTE — au bas du verso : le spécialiste du rôle converse,
// on peut joindre un fichier ou une photo, et il ENREGISTRE LUI-MÊME les
// réglages de la carte à partir de ce qu'on lui dit.
export default function FacetAgentChat({ facet, values, onSaveItem }) {
  const [input, setInput] = useState("");
  const [reply, setReply] = useState("");
  const [loading, setLoading] = useState(false);
  const [fileName, setFileName] = useState("");
  const fileUrlRef = useRef(null);
  const fileInputRef = useRef(null);

  const attach = async (e) => {
    const f = e.target.files?.[0];
    if (!f) return;
    setFileName(f.name);
    const { file_url } = await base44.integrations.Core.UploadFile({ file: f });
    fileUrlRef.current = file_url;
  };

  const send = async () => {
    const msg = input.trim();
    if (!msg && !fileUrlRef.current) return;
    setLoading(true);
    setInput("");
    const items = (facet.items || []).map((it) => ({
      id: it.id,
      label: it.label,
      type: it.type || "text",
      options: it.options || undefined,
      valeur_actuelle: values?.[it.id] ?? null,
    }));
    const res = await base44.integrations.Core.InvokeLLM({
      prompt: `Tu es l'agent IA spécialiste de la carte « ${facet.label} » d'un projet de mariage (${facet.description || ""}).
Voici les réglages de la carte (id, libellé, type, options éventuelles, valeur actuelle) :
${JSON.stringify(items)}

L'utilisateur te dit : "${msg || "Voici un fichier joint, analyse-le et remplis ce que tu peux."}"

Ta mission :
1. Réponds chaleureusement, en 1 à 3 phrases courtes, en français, comme un spécialiste de ce rôle.
2. Si le message (ou le fichier joint) contient des informations qui permettent de remplir un ou plusieurs réglages, extrais-les dans "updates" (clé = id du réglage, valeur = la valeur à enregistrer, respectant le type et les options).
3. Si des infos importantes manquent encore, pose UNE question ciblée pour la plus prioritaire.`,
      file_urls: fileUrlRef.current ? [fileUrlRef.current] : undefined,
      response_json_schema: {
        type: "object",
        properties: {
          reply: { type: "string" },
          updates: { type: "object", additionalProperties: true },
        },
      },
    });
    const ids = new Set((facet.items || []).map((it) => it.id));
    Object.entries(res.updates || {}).forEach(([id, v]) => {
      if (ids.has(id) && v !== null && v !== "") onSaveItem(id, String(v));
    });
    setReply(res.reply || "");
    fileUrlRef.current = null;
    setFileName("");
    setLoading(false);
  };

  return (
    <div className="mt-2 border-t border-white/10 pt-2">
      {reply && (
        <p className="ripple-wave mb-2 max-h-16 overflow-y-auto rounded-lg bg-white/[0.06] px-2.5 py-1.5 text-[11px] leading-4 text-white/75">
          {reply}
        </p>
      )}
      <div className="flex items-center gap-1.5">
        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          aria-label="Joindre un fichier ou une photo"
          title={fileName || "Joindre un fichier ou une photo"}
          className={`rounded-lg p-2 transition hover:bg-white/10 ${fileName ? "text-white" : "text-white/40 hover:text-white"}`}
        >
          <Paperclip className="h-3.5 w-3.5" />
        </button>
        <input ref={fileInputRef} type="file" className="hidden" onChange={attach} />
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && !loading && send()}
          placeholder={`Parlez à l'agent ${facet.label}…`}
          aria-label={`Converser avec l'agent de la carte ${facet.label}`}
          className="min-w-0 flex-1 rounded-lg border border-white/10 bg-white/[0.06] px-2.5 py-1.5 text-[12px] text-white placeholder:text-white/25 focus:border-white/30 focus:outline-none"
        />
        <button
          type="button"
          onClick={send}
          disabled={loading}
          aria-label="Envoyer"
          className="rounded-lg bg-white p-2 text-black transition hover:bg-white/85 disabled:opacity-40"
        >
          {loading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Send className="h-3.5 w-3.5" />}
        </button>
      </div>
    </div>
  );
}