import { useState } from "react";
import { LayoutGrid, Loader2, RefreshCw, Trash2 } from "lucide-react";
import ProjectFacetCard from "./ProjectFacetCard";
import { generateFacets, generateFacetImages, withSysteme } from "@/lib/bureau/projectFacets";
import { withDeroule } from "@/lib/bureau/derouleFacet";

// LES CARTES DU PROJET — après l'onboarding, Ripple génère les facettes
// (le cockpit universel) ; chaque carte se règle comme celles du mariage.
export default function ProjectFacetSection({ project, onFacetsGenerated, onSaveValue }) {
  const [loading, setLoading] = useState(false);
  const [imaging, setImaging] = useState(false);
  const [openKey, setOpenKey] = useState(null);
  const facets = project.facets || [];

  const generer = async () => {
    if (loading) return;
    setLoading(true);
    // Livrées d'office : « Déroulé — Jour J », « Clavier universel » et
    // « Design system » — les réglages qui remplacent le code.
    const f = withSysteme(withDeroule(await generateFacets(project)));
    onFacetsGenerated(f);
    setLoading(false);
    // Deuxième vague : les visuels de chaque carte, générés en parallèle.
    setImaging(true);
    const withImages = await generateFacetImages(f, project);
    onFacetsGenerated(withImages);
    setImaging(false);
  };

  if (!facets.length) {
    return (
      <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-4 text-center">
        <p className="text-[12.5px] text-white/50">
          Prêt à passer au cockpit ? Ripple transforme vos réponses en <b className="font-medium text-white/80">cartes de projet</b> réglables.
        </p>
        <button
          type="button"
          onClick={generer}
          disabled={loading}
          className="mt-3 inline-flex items-center gap-2 rounded-xl bg-white px-4 py-2 text-[12px] font-semibold text-black transition hover:bg-white/85 disabled:opacity-50"
        >
          {loading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <LayoutGrid className="h-3.5 w-3.5" />}
          {loading ? "Ripple compose les cartes…" : "Générer les cartes du projet"}
        </button>
      </div>
    );
  }

  return (
    <section aria-label="Les cartes du projet">
      <div className="mb-2 flex items-center justify-between">
        <p className="font-mono text-[10px] font-semibold uppercase tracking-[0.24em] text-white/40">
          Les cartes du projet
          {imaging && <span className="ml-2 text-white/70">· les visuels arrivent…</span>}
        </p>
        <button
          type="button"
          onClick={generer}
          disabled={loading}
          className="inline-flex items-center gap-1 rounded-full px-2 py-1 text-[10px] text-white/40 hover:bg-white/10 hover:text-white disabled:opacity-50"
        >
          {loading ? <Loader2 className="h-3 w-3 animate-spin" /> : <RefreshCw className="h-3 w-3" />}
          Regénérer
        </button>
      </div>
      {/* LA TIMELINE HORIZONTALE — chaque carte est un moment du projet,
          reliée à la suivante par le fil ; on scrolle latéralement. */}
      <div className="scrollbar-hide -mx-1 flex gap-4 overflow-x-auto px-1 pb-2">
        {facets.map((f, i) => (
          <div key={f.key} className="w-[320px] shrink-0">
            <div className="mb-2 flex items-center gap-2">
              <span aria-hidden="true" className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full border border-white/25 bg-[#0C0C0C] font-mono text-[9px] text-white/60">
                {i + 1}
              </span>
              <span aria-hidden="true" className="h-px flex-1 bg-white/12" />
              <button
                type="button"
                onClick={() => onFacetsGenerated(facets.filter((x) => x.key !== f.key))}
                aria-label={`Supprimer la carte ${f.label}`}
                className="grid h-5 w-5 shrink-0 place-items-center rounded-full text-white/30 transition hover:bg-white/10 hover:text-red-400"
              >
                <Trash2 className="h-3 w-3" />
              </button>
            </div>
            <ProjectFacetCard
              facet={f}
              facets={facets}
              kicker={project.project_type || project.intent}
              values={project.facet_values}
              flipped={openKey === f.key}
              onToggle={() => setOpenKey(openKey === f.key ? null : f.key)}
              onSave={onSaveValue}
              onSelectFacet={(key) => setOpenKey(key)}
              direction={project.direction}
              onUpdateFacet={(key, patch) => onFacetsGenerated(facets.map((x) => (x.key === key ? { ...x, ...patch } : x)))}
            />
          </div>
        ))}
      </div>
    </section>
  );
}