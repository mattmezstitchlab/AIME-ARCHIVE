import { useState } from "react";
import { Undo2, Wand2, Camera, Link2, Loader2, Check } from "lucide-react";
import { base44 } from "@/api/base44Client";

// LE TEMPLATE DE LA CARTE — derrière chaque carte, en plus des réglages :
// la mise en page de SA section (hero, section, typo, couleur) et son visuel
// (prompt, copie d'écran ou URL absorbée — on trie et on garde le meilleur).
const HEROS = ["Visuel plein", "Dégradé", "Minimal"];
const SECTIONS = ["Texte + visuel", "Liste", "Bandeau"];
const TYPOS = ["Serif", "Sans"];

const Chip = ({ actif, onClick, children }) => (
  <button type="button" onClick={onClick}
    className={`rounded-full px-2.5 py-1 text-[10px] font-medium transition ${actif ? "bg-white text-black" : "bg-white/[0.07] text-white/60 hover:bg-white/15 hover:text-white"}`}>
    {children}
  </button>
);

export default function FacetTemplatePanel({ facet, tpl, absorbe, palette, onClose, onSaveTpl, onImage, onAbsorb }) {
  const [prompt, setPrompt] = useState("");
  const [url, setUrl] = useState("");
  const [busy, setBusy] = useState(null);
  const set = (patch) => onSaveTpl({ ...tpl, ...patch });

  const genererVisuel = async () => {
    if (!prompt.trim() || busy) return;
    setBusy("img");
    const { url: img } = await base44.integrations.Core.GenerateImage({ prompt: `${prompt} — visuel cinématique premium pour la section "${facet.label}" d'un site, sans texte.` });
    onImage(img);
    setBusy(null);
  };

  const absorberCapture = async (file) => {
    if (!file || busy) return;
    setBusy("capture");
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    const res = await base44.integrations.Core.InvokeLLM({
      prompt: `Absorbe le contenu de cette copie d'écran pour la section "${facet.label}" d'un mini-site : trie et garde LE MEILLEUR (messages clés, chiffres, formulations fortes). 5 lignes max, en français.`,
      file_urls: [file_url],
    });
    onAbsorb(res);
    setBusy(null);
  };

  const absorberUrl = async () => {
    if (!url.trim() || busy) return;
    setBusy("url");
    const res = await base44.integrations.Core.InvokeLLM({
      prompt: `Va voir cette page : ${url}. Absorbe son contenu pour la section "${facet.label}" d'un mini-site : trie et garde LE MEILLEUR (messages clés, chiffres, formulations fortes). 5 lignes max, en français.`,
      add_context_from_internet: true,
    });
    onAbsorb(res);
    setBusy(null);
  };

  return (
    <div className="scrollbar-hide flex min-h-0 flex-1 flex-col gap-2.5 overflow-y-auto">
      <div className="flex items-center justify-between">
        <p className="font-mono text-[9px] font-semibold uppercase tracking-[0.24em] text-white/60">Template · {facet.label}</p>
        <button type="button" onClick={onClose} aria-label="Refermer le template" className="rounded-full p-1.5 text-white/40 hover:bg-white/10 hover:text-white">
          <Undo2 className="h-4 w-4" />
        </button>
      </div>

      {[["Hero", HEROS, "hero"], ["Section", SECTIONS, "section"], ["Typo", TYPOS, "typo"]].map(([label, opts, key]) => (
        <div key={key}>
          <p className="mb-1 font-mono text-[8px] font-semibold uppercase tracking-[0.22em] text-white/35">{label}</p>
          <div className="flex flex-wrap gap-1.5">
            {opts.map((o) => <Chip key={o} actif={tpl[key] === o} onClick={() => set({ [key]: o })}>{o}</Chip>)}
          </div>
        </div>
      ))}

      <div>
        <p className="mb-1 font-mono text-[8px] font-semibold uppercase tracking-[0.22em] text-white/35">Couleur d'accent</p>
        <div className="flex flex-wrap gap-1.5">
          {[...(palette || []), "#FFFFFF"].map((c) => (
            <button key={c} type="button" onClick={() => set({ couleur: c })} aria-label={`Accent ${c}`}
              className={`h-6 w-6 rounded-full border-2 transition ${tpl.couleur === c ? "border-white scale-110" : "border-white/20 hover:border-white/60"}`}
              style={{ background: c }} />
          ))}
        </div>
      </div>

      <div className="space-y-1.5 border-t border-white/10 pt-2">
        <p className="font-mono text-[8px] font-semibold uppercase tracking-[0.22em] text-white/35">Visuel & contenu</p>
        <div className="flex gap-1.5">
          <input value={prompt} onChange={(e) => setPrompt(e.target.value)} placeholder="Prompt du visuel…"
            className="min-w-0 flex-1 rounded-lg bg-white/[0.06] px-2.5 py-1.5 text-[11px] text-white placeholder:text-white/30 focus:bg-white/[0.12] focus:outline-none" />
          <button type="button" onClick={genererVisuel} disabled={busy || !prompt.trim()} aria-label="Générer le visuel"
            className="grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-white text-black disabled:opacity-30">
            {busy === "img" ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Wand2 className="h-3.5 w-3.5" />}
          </button>
          <label aria-label="Importer une copie d'écran à absorber"
            className="grid h-7 w-7 shrink-0 cursor-pointer place-items-center rounded-lg bg-white/[0.08] text-white/60 hover:bg-white/15 hover:text-white">
            {busy === "capture" ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Camera className="h-3.5 w-3.5" />}
            <input type="file" accept="image/*" className="hidden" onChange={(e) => { absorberCapture(e.target.files?.[0]); e.target.value = ""; }} />
          </label>
        </div>
        <div className="flex gap-1.5">
          <input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="URL à absorber (on garde le meilleur)…"
            className="min-w-0 flex-1 rounded-lg bg-white/[0.06] px-2.5 py-1.5 text-[11px] text-white placeholder:text-white/30 focus:bg-white/[0.12] focus:outline-none" />
          <button type="button" onClick={absorberUrl} disabled={busy || !url.trim()} aria-label="Absorber le contenu de l'URL"
            className="grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-white/[0.08] text-white/60 hover:bg-white/15 hover:text-white disabled:opacity-30">
            {busy === "url" ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Link2 className="h-3.5 w-3.5" />}
          </button>
        </div>
        {absorbe && (
          <p className="flex items-start gap-1.5 rounded-lg bg-white/[0.05] p-2 text-[10px] leading-relaxed text-white/60">
            <Check className="mt-0.5 h-3 w-3 shrink-0 text-[#7FDCB2]" aria-hidden="true" />
            <span className="line-clamp-4">{absorbe}</span>
          </p>
        )}
      </div>
    </div>
  );
}