import { Check, ChevronDown } from "lucide-react";

// Une question de l'onboarding Ripple — le champ s'adapte au type.
// Style figé « bloc agent » : neutre, épuré, aucun doré.
export default function RippleQuestionCard({ question, value, onChange }) {
  const done = value !== undefined && value !== null && value !== "";
  const inputCls =
    "mt-2 w-full rounded-xl border border-white/10 bg-white/[0.06] px-3 py-2 text-[13px] text-white placeholder:text-white/30 transition focus:border-white/30 focus:bg-white/[0.09] focus:outline-none";

  return (
    <div className={`rounded-xl border p-3.5 transition-colors ${done ? "border-white/20 bg-white/[0.05]" : "border-white/10 bg-white/[0.03]"}`}>
      <label className="flex items-start justify-between gap-2 text-[13px] font-medium text-white/90">
        <span>{question.label}</span>
        {done && (
          <span className="flex h-4.5 w-4.5 shrink-0 items-center justify-center rounded-full bg-white/15 p-0.5">
            <Check className="h-3 w-3 text-white" aria-label="Répondu" />
          </span>
        )}
      </label>
      {question.hint && <p className="mt-1 text-[11px] leading-4 text-white/40">{question.hint}</p>}
      {question.type === "select" && question.options?.length ? (
        <div className="relative">
          <select
            value={value || ""}
            onChange={(e) => onChange(e.target.value)}
            className={`${inputCls} appearance-none pr-9 [&>option]:bg-[#141416] [&>option]:text-white`}
            aria-label={question.label}
          >
            <option value="">Choisir…</option>
            {question.options.map((o) => (
              <option key={o} value={o}>{o}</option>
            ))}
          </select>
          <ChevronDown className="pointer-events-none absolute right-3 top-1/2 h-3.5 w-3.5 translate-y-0 text-white/40" style={{ marginTop: "4px" }} />
        </div>
      ) : (
        <input
          type={question.type === "number" ? "number" : question.type === "date" ? "date" : "text"}
          value={value || ""}
          onChange={(e) => onChange(e.target.value)}
          placeholder="Votre réponse"
          aria-label={question.label}
          className={inputCls}
        />
      )}
    </div>
  );
}