import { useState } from "react";
import { Heart, Loader2, ArrowRight } from "lucide-react";
import { convertMariageToProject } from "@/lib/bureau/mariageToProject";

// Le pont : convertit le mariage historique en vrai projet Ripple, une fois.
export default function MariageConvertButton({ onConverted }) {
  const [loading, setLoading] = useState(false);

  const convertir = async () => {
    if (loading) return;
    setLoading(true);
    const project = await convertMariageToProject();
    setLoading(false);
    onConverted(project);
  };

  return (
    <button
      type="button"
      onClick={convertir}
      disabled={loading}
      className="mx-auto flex items-center gap-2 rounded-full border border-[#c9a96e]/40 bg-[#c9a96e]/10 px-4 py-2 text-[11px] font-semibold text-[#c9a96e] transition hover:bg-[#c9a96e]/20 disabled:opacity-50"
    >
      {loading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Heart className="h-3.5 w-3.5" />}
      {loading ? "Conversion en cours…" : "Convertir le mariage en projet Ripple"}
      {!loading && <ArrowRight className="h-3 w-3" />}
    </button>
  );
}