import { useState } from "react";
import { Check, X } from "lucide-react";

// À PARAMÉTRER — le réglage d'UN item : le champ en haut, et en dessous le
// schéma causal direct de la facette. Plus de modes ni d'explication grisée :
// c'est évident, on règle et on valide.
export default function FacetItemSettings({ facet, item, values, onValidate, onClose }) {
  const [draft, setDraft] = useState(values?.[item.id] ?? "");
  const color = facet.color || "#9ca3af";

  const filled = (id) => {
    const v = id === item.id && draft !== "" ? draft : values?.[id];
    return v !== undefined && v !== null && v !== "";
  };

  const inputClass =
    "w-full rounded-xl border border-white/15 bg-black px-3 py-3 text-sm text-white outline-none focus:border-white/40";

  return (
    <div className="flex h-full flex-col">
      <div className="flex items-start justify-between gap-2">
        <div>
          <p className="font-mono text-[9px] font-semibold uppercase tracking-[0.24em] text-white/40">
            À paramétrer
          </p>
          <p className="mt-1 font-heading text-[15px] font-semibold text-white">{item.label}</p>
          {item.hint && <p className="mt-0.5 text-[10px] text-white/40">{item.hint}</p>}
        </div>
        <button
          type="button"
          onClick={onClose}
          aria-label="Refermer le réglage"
          className="rounded-full p-1.5 text-white/40 hover:bg-white/10 hover:text-white"
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      <div className="mt-3">
        {item.type === "select" && item.options?.length ? (
          <select
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            className={inputClass}
            style={{ colorScheme: "dark" }}
          >
            <option value="">Choisir…</option>
            {item.options.map((o) => (
              <option key={o} value={o}>{o}</option>
            ))}
          </select>
        ) : (
          <input
            type={item.type === "date" ? "date" : item.type === "number" ? "number" : "text"}
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            placeholder={item.hint || ""}
            className={inputClass}
            style={{ colorScheme: "dark" }}
          />
        )}
      </div>

      {/* LE SCHÉMA CAUSAL DIRECT — la facette vue d'en haut, sur le noir */}
      <div className="mt-4 flex-1">
        <div className="grid grid-cols-2 gap-1.5">
          {(facet.items || []).map((it) => {
            const isCurrent = it.id === item.id;
            const isFilled = filled(it.id);
            return (
              <div
                key={it.id}
                className="flex items-center gap-1.5 rounded-md px-1.5 py-1"
                style={isCurrent ? { boxShadow: `0 0 0 1px ${color}` } : undefined}
              >
                <span
                  className={`h-2.5 w-3.5 shrink-0 rounded-[2px] transition-colors duration-500 ${
                    isCurrent && !isFilled ? "animate-pulse" : ""
                  }`}
                  style={{
                    background: isFilled ? "#ffffff" : isCurrent ? "rgba(255,255,255,0.6)" : "#242424",
                  }}
                />
                <span className={`truncate font-mono text-[8px] uppercase tracking-[0.1em] ${isCurrent ? "text-white" : "text-white/35"}`}>
                  {it.label}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      <button
        type="button"
        onClick={() => draft !== "" && onValidate(draft)}
        disabled={draft === ""}
        className="mt-3 inline-flex w-full items-center justify-center gap-2 rounded-full bg-white py-2.5 text-[13px] font-semibold text-black transition enabled:hover:scale-[1.01] disabled:opacity-30"
      >
        <Check className="h-4 w-4" /> Valider
      </button>
    </div>
  );
}