// LA DIRECTION ARTISTIQUE DU PROJET — proposée par le Curateur au Point Zéro,
// conservée sur le projet (elle ne disparaît plus avec la conversation).
export default function ProjectDirectionStrip({ direction }) {
  if (!direction?.palette?.length && !direction?.style_name) return null;
  return (
    <div className="flex flex-wrap items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.02] px-4 py-3">
      <p className="font-mono text-[9px] font-semibold uppercase tracking-[0.2em] text-white">
        Le Curateur · {direction.style_name || "Direction artistique"}
      </p>
      <div className="flex gap-1.5">
        {(direction.palette || []).map((c, i) => (
          <span key={i} className="h-6 w-6 rounded-md border border-white/15" style={{ background: c }} title={c} />
        ))}
      </div>
      {(direction.typo_titres || direction.typo_texte) && (
        <p className="text-[11px] text-white/50">
          Titres : <span className="text-white/85">{direction.typo_titres || "—"}</span> · Texte :{" "}
          <span className="text-white/85">{direction.typo_texte || "—"}</span>
        </p>
      )}
    </div>
  );
}