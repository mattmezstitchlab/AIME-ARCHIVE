import { Globe } from "lucide-react";

// LE MINI-SITE — le bouton qui ouvre la vraie page verticale du projet :
// tout est généré d'un seul coup, unifié par le design system.
export default function ProjectCanvasButton({ project, onOpen }) {
  if (!project?.facets?.length) return null;

  return (
    <div className="flex items-center justify-between gap-3 rounded-2xl border border-white/10 bg-white/[0.02] px-4 py-3.5">
      <p className="text-[12.5px] leading-5 text-white/55">
        Vos cartes sont réglées ? Ripple génère <b className="font-medium text-white/85">tout le Mini-site d'un coup</b> —
        une seule page verticale, chaque verticalité devient une vraie section, unifiée par votre design system.
      </p>
      <button
        type="button"
        onClick={onOpen}
        className="inline-flex shrink-0 items-center gap-1.5 rounded-xl bg-white px-4 py-2 text-[12px] font-semibold text-black transition hover:bg-white/85"
      >
        <Globe className="h-3.5 w-3.5" />
        Ouvrir le Mini-site
      </button>
    </div>
  );
}