import { useState } from "react";
import { Sparkles, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import EtapesProgression from "@/components/aimeplus/EtapesProgression";

// LE CHAMP RIPPLE — le secret du Bureau : on dit ce qu'on veut faire
// (« mariage », « site », « cv », « affiche »…), on règle la complexité,
// et Ripple génère l'onboarding sur mesure directement dans le Bureau.
const NIVEAUX = [
  { v: 1, label: "Simple", questions: 5 },
  { v: 2, label: "Détaillé", questions: 10 },
  { v: 3, label: "Complet", questions: 18 },
];

export default function RippleIntentBar({ onGenerated }) {
  const [intent, setIntent] = useState("");
  const [niveau, setNiveau] = useState(1);
  const [loading, setLoading] = useState(false);
  const [etape, setEtape] = useState(0);
  const nb = NIVEAUX.find((n) => n.v === niveau).questions;

  const generer = async () => {
    const what = intent.trim();
    if (!what || loading) return;
    setLoading(true);
    setEtape(0);
    const timer = setInterval(() => setEtape((e) => Math.min(e + 1, 2)), 3500);
    const res = await base44.integrations.Core.InvokeLLM({
      prompt: `Tu es Ripple, l'agent d'onboarding causal de la plateforme AIME. L'utilisateur veut faire : "${what}".
Génère un onboarding en français pour cadrer ce projet, avec EXACTEMENT ${nb} questions (niveau : ${NIVEAUX.find((n) => n.v === niveau).label}).
Chaque question doit être concrète, utile pour construire le projet, et rangée dans un dossier logique (ex. Essentiel, Personnes, Budget, Style, Contenu, Délais).
Types autorisés : "text" (réponse libre courte), "number", "date", "select" (avec 3 à 5 options).
Donne aussi un titre court de projet et une phrase d'intro chaleureuse signée Ripple.`,
      response_json_schema: {
        type: "object",
        properties: {
          project_title: { type: "string" },
          project_type: { type: "string" },
          intro: { type: "string" },
          questions: {
            type: "array",
            items: {
              type: "object",
              properties: {
                id: { type: "string" },
                label: { type: "string" },
                hint: { type: "string" },
                folder: { type: "string" },
                type: { type: "string" },
                options: { type: "array", items: { type: "string" } },
              },
            },
          },
        },
      },
    });
    clearInterval(timer);
    onGenerated({
      intent: what,
      complexity: niveau,
      created_at: new Date().toISOString(),
      answers: {},
      ...res,
    });
    setIntent("");
    setLoading(false);
  };

  // PENDANT LA GÉNÉRATION — la carte de progression AI+ME, propre et vivante.
  if (loading) {
    return (
      <EtapesProgression
        titre="Ripple prépare votre projet"
        etapes={["Analyse de votre demande", "Dossiers logiques", "Rédaction des questions"]}
        courante={etape}
      />
    );
  }

  return (
    <div className="rounded-2xl border border-white/12 bg-white/[0.03] p-3">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
        <div className="flex min-w-0 flex-1 items-center gap-2 rounded-xl border border-white/15 bg-black/40 px-3 py-2 focus-within:border-[#c9a96e]/60">
          <Sparkles className="h-4 w-4 shrink-0 text-[#c9a96e]" />
          <input
            value={intent}
            onChange={(e) => setIntent(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && generer()}
            placeholder="Que voulez-vous faire ? mariage, site, cv, affiche, refonte…"
            aria-label="Dire à Ripple ce que vous voulez faire"
            className="min-w-0 flex-1 bg-transparent text-[13px] text-white placeholder:text-white/30 focus:outline-none"
          />
        </div>
        <div className="flex items-center gap-2">
          <div className="flex rounded-xl border border-white/15 p-0.5">
            {NIVEAUX.map((n) => (
              <button
                key={n.v}
                type="button"
                onClick={() => setNiveau(n.v)}
                aria-pressed={niveau === n.v}
                className={`rounded-lg px-2.5 py-1.5 text-[11px] font-medium transition-colors ${
                  niveau === n.v ? "bg-[#c9a96e] text-black" : "text-white/50 hover:text-white"
                }`}
              >
                {n.label}
              </button>
            ))}
          </div>
          <button
            type="button"
            onClick={generer}
            disabled={!intent.trim() || loading}
            className="inline-flex shrink-0 items-center gap-1.5 rounded-xl bg-white px-4 py-2 text-[12px] font-semibold text-black transition hover:bg-white/90 disabled:opacity-40"
          >
            {loading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : null}
            {loading ? "Ripple prépare…" : "Générer"}
          </button>
        </div>
      </div>
      <p className="mt-1.5 pl-1 text-[10px] text-white/35">
        Ripple générera <b className="text-white/60">≈ {nb} questions</b> adaptées à votre projet — {NIVEAUX.find((n) => n.v === niveau).label.toLowerCase()}.
      </p>
    </div>
  );
}