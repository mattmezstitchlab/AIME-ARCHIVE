import { Sun, Moon, XCircle } from "lucide-react";

// UNE LIGNE DE MORCEAU — le verdict raconté : alpha → interstice → omega.
export default function RadioTrackRow({ track, playing }) {
  const refused = track.status === "refused";
  const PhaseIcon = track.phase === "solaire" ? Sun : Moon;
  return (
    <li className={`rounded-xl border p-3 ${
      refused ? "border-white/10 bg-white/[0.02] opacity-60"
      : playing ? "border-[#c9a96e]/50 bg-[#c9a96e]/10"
      : "border-white/10 bg-white/[0.04]"
    }`}>
      <div className="flex items-center justify-between gap-2">
        <p className="truncate text-[13px] font-semibold text-white/85">{track.title}</p>
        <span className={`inline-flex shrink-0 items-center gap-1 font-mono text-[10px] uppercase tracking-[0.15em] ${
          refused ? "text-red-400/70" : track.phase === "solaire" ? "text-amber-300" : "text-sky-300"
        }`}>
          {refused ? <XCircle className="h-3 w-3" /> : <PhaseIcon className="h-3 w-3" />}
          {refused ? "Refusé" : `Phase ${track.phase}`}
        </span>
      </div>
      <p className="mt-1 text-[11.5px] leading-5 text-white/45">
        α {track.alpha} → Ω {track.omega}
        {track.interstice && track.interstice !== "aucun repéré" && <> · interstice : {track.interstice}</>}
      </p>
      {track.motif && <p className="mt-0.5 text-[11px] italic text-white/35">{track.motif}</p>}
    </li>
  );
}