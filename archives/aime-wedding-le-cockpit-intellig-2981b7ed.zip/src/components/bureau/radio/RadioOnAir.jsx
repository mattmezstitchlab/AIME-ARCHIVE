import { useState, useEffect, useCallback } from "react";
import { Sun } from "lucide-react";
import { base44 } from "@/api/base44Client";
import RadioImport from "./RadioImport";
import RadioPlayer from "./RadioPlayer";
import RadioTrackRow from "./RadioTrackRow";

// LA RADIO ON AIR — seules les musiques EN ÉLÉVATION entrent dans la
// playlist d'acceptation universelle : celles qui font sortir l'ombre
// intérieure vers l'extérieur, en lumière (phase solaire ou lunaire).
export default function RadioOnAir() {
  const [tracks, setTracks] = useState([]);
  const [playingId, setPlayingId] = useState(null);

  const charger = useCallback(() => {
    base44.entities.RadioTrack.list("-created_date", 100).then(setTracks);
  }, []);
  useEffect(() => { charger(); }, [charger]);

  const accepted = tracks.filter((t) => t.status === "accepted");
  const refused = tracks.filter((t) => t.status === "refused");

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="inline-flex items-center gap-2 font-mono text-[10px] font-semibold uppercase tracking-[0.24em] text-white/40">
          <Sun className="h-3.5 w-3.5 text-[#c9a96e]" /> Playlist d'acceptation universelle · {accepted.length} morceau{accepted.length > 1 ? "x" : ""}
        </p>
        <RadioPlayer playlist={accepted} onTrackChange={setPlayingId} />
      </div>

      <RadioImport onDone={charger} />

      {accepted.length === 0 && refused.length === 0 && (
        <p className="text-center text-[12.5px] text-white/35">
          Aucune musique encore — importez la première, elle sera jugée sur sa trajectoire alpha → omega.
        </p>
      )}

      {accepted.length > 0 && (
        <ul className="space-y-2">
          {accepted.map((t) => <RadioTrackRow key={t.id} track={t} playing={t.id === playingId} />)}
        </ul>
      )}

      {refused.length > 0 && (
        <details>
          <summary className="cursor-pointer font-mono text-[10px] uppercase tracking-[0.2em] text-white/30">
            Refusées — descente ou stagnation dans l'ombre ({refused.length})
          </summary>
          <ul className="mt-2 space-y-2">
            {refused.map((t) => <RadioTrackRow key={t.id} track={t} />)}
          </ul>
        </details>
      )}
    </div>
  );
}