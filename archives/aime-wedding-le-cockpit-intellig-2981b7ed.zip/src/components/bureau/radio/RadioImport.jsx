import { useState, useRef } from "react";
import { Upload, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { analyserAudio } from "@/lib/radio/analyseAudio";
import { verdictMusique } from "@/lib/radio/verdictMusique";

// L'IMPORT — le morceau traverse la pipeline : fréquences → paroles → verdict.
// Accepté, il atterrit dans la playlist d'acceptation universelle.
export default function RadioImport({ onDone }) {
  const [etape, setEtape] = useState(null);
  const inputRef = useRef(null);

  const handleFile = async (file) => {
    if (!file) return;
    const titre = file.name.replace(/\.[^.]+$/, "");
    setEtape("Analyse des fréquences — alpha et omega…");
    const mesures = await analyserAudio(file);
    setEtape("Upload du morceau…");
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setEtape("Écoute des paroles et verdict de trajectoire…");
    const v = await verdictMusique({ fileUrl: file_url, titre, mesures });
    await base44.entities.RadioTrack.create({
      title: titre,
      file_url,
      duration: mesures.duree,
      status: v.accepte ? "accepted" : "refused",
      phase: v.phase,
      alpha: v.alpha,
      omega: v.omega,
      interstice: v.interstice || "",
      motif: v.motif,
      mesures: { alpha: mesures.alpha, omega: mesures.omega, montee: mesures.montee },
    });
    setEtape(null);
    onDone();
  };

  return (
    <div>
      <input ref={inputRef} type="file" accept="audio/*" className="hidden"
        onChange={(e) => handleFile(e.target.files?.[0])} />
      <button
        type="button"
        onClick={() => inputRef.current?.click()}
        disabled={!!etape}
        className="flex w-full items-center justify-center gap-2 rounded-xl border border-dashed border-white/20 px-4 py-5 text-[13px] text-white/60 transition-colors hover:border-[#c9a96e]/50 hover:text-white disabled:opacity-60"
      >
        {etape ? <Loader2 className="h-4 w-4 animate-spin text-[#c9a96e]" /> : <Upload className="h-4 w-4 text-[#c9a96e]" />}
        {etape || "Importer une musique — elle sera analysée (fréquences, paroles, trajectoire alpha→omega)"}
      </button>
    </div>
  );
}