import { useState, useRef, useEffect } from "react";
import { RadioTower } from "lucide-react";

// LE BOUTON RADIO LIVE — ON AIR : diffuse la playlist d'acceptation
// universelle en continu, morceau après morceau, en boucle.
export default function RadioPlayer({ playlist, onTrackChange }) {
  const [onAir, setOnAir] = useState(false);
  const [idx, setIdx] = useState(0);
  const audioRef = useRef(null);

  useEffect(() => {
    onTrackChange(onAir ? playlist[idx]?.id : null);
    if (onAir && audioRef.current) audioRef.current.play().catch(() => {});
  }, [onAir, idx, playlist, onTrackChange]);

  const suivant = () => setIdx((i) => (i + 1) % playlist.length);

  return (
    <div className="flex items-center gap-3">
      <button
        type="button"
        onClick={() => setOnAir((o) => !o)}
        disabled={playlist.length === 0}
        aria-pressed={onAir}
        className={`inline-flex items-center gap-2 rounded-full px-4 py-2 font-mono text-[11px] font-semibold uppercase tracking-[0.2em] transition-colors disabled:opacity-40 ${
          onAir ? "bg-red-600 text-white" : "border border-white/20 text-white/70 hover:border-white/40 hover:text-white"
        }`}
      >
        <span className={`h-2 w-2 rounded-full ${onAir ? "animate-ping-slow bg-white" : "bg-red-500"}`} />
        <RadioTower className="h-3.5 w-3.5" />
        {onAir ? "On Air" : "Radio live"}
      </button>
      {onAir && playlist[idx] && (
        <p className="truncate text-[12px] text-white/55">
          ♪ {playlist[idx].title} <span className="text-white/30">· {idx + 1}/{playlist.length}</span>
        </p>
      )}
      {onAir && playlist[idx] && (
        <audio ref={audioRef} src={playlist[idx].file_url} autoPlay onEnded={suivant} />
      )}
    </div>
  );
}