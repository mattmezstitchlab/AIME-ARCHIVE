import { useState, useEffect } from "react";
import { Library, FolderInput, Stamp, Archive, ChevronRight } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { loadImports } from "@/lib/bureau/pointZeroStore";

// LES BIBLIOTHÈQUES — fusionnées dans le panneau Dossiers : tout ce qui a
// été absorbé et qui est réutilisable (imports Point Zéro, timbres, archives).
// La matériauthèque n'est pas dupliquée ici : elle vit dans l'arbre (Galerie).
function Section({ icon: Icon, label, badge, children, defaultOpen = false }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="border-b border-white/8">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-expanded={open}
        className="flex w-full items-center gap-2 px-1 py-2.5 text-left"
      >
        <ChevronRight className={`h-3 w-3 text-white/30 transition-transform ${open ? "rotate-90" : ""}`} />
        <Icon className="h-3.5 w-3.5 text-[#c9a96e]" strokeWidth={1.6} />
        <span className="flex-1 text-[12px] font-medium text-white/80">{label}</span>
        {badge != null && (
          <span className="rounded-full bg-white/10 px-1.5 py-0.5 font-mono text-[9px] text-white/50">{badge}</span>
        )}
      </button>
      {open && <div className="space-y-1 pb-2.5 pl-6 pr-1">{children}</div>}
    </div>
  );
}

const Item = ({ label, summary }) => (
  <div className="rounded-lg px-2 py-1.5 text-[11px] text-white/60 hover:bg-white/5">
    <p className="truncate text-white/75">{label}</p>
    {summary && <p className="truncate text-[10px] text-white/35">{summary}</p>}
  </div>
);

export default function BibliothequesSections() {
  const [stamps, setStamps] = useState([]);
  const [archives, setArchives] = useState([]);
  const imports = loadImports();

  useEffect(() => {
    base44.entities.RippleStamp.list("-updated_date", 20).then(setStamps);
    base44.entities.SavedArchive.list("-updated_date", 20).then(setArchives);
  }, []);

  return (
    <div className="mt-5">
      <p className="mb-1 inline-flex items-center gap-2 font-mono text-[10px] font-semibold uppercase tracking-[0.24em] text-white/40">
        <Library className="h-3.5 w-3.5 text-[#c9a96e]" /> Bibliothèques
      </p>

      <Section icon={FolderInput} label="Imports Point Zéro" badge={imports.length} defaultOpen>
        {imports.length ? (
          imports.slice(-15).reverse().map((r) => <Item key={r.id} label={r.name} summary={r.folder} />)
        ) : (
          <p className="px-2 py-1 text-[10px] text-white/30">Rien d'absorbé pour l'instant.</p>
        )}
      </Section>

      <Section icon={Stamp} label="Timbres Ripple" badge={stamps.length}>
        {stamps.length ? (
          stamps.map((s) => <Item key={s.id} label={s.label || s.stamp_type} summary={s.folder} />)
        ) : (
          <p className="px-2 py-1 text-[10px] text-white/30">Aucun timbre rangé.</p>
        )}
      </Section>

      <Section icon={Archive} label="Archives" badge={archives.length}>
        {archives.length ? (
          archives.map((a) => <Item key={a.id} label={a.label} summary={a.path} />)
        ) : (
          <p className="px-2 py-1 text-[10px] text-white/30">Aucune archive rangée.</p>
        )}
      </Section>
    </div>
  );
}