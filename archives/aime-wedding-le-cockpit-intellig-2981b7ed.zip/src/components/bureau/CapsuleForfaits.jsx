import { ArrowRight, X, AtSign, Globe, Fingerprint, Share2 } from "lucide-react";
import PlusNomDispo from "@/components/bureau/PlusNomDispo";

// LE PRINCIPE DU +NOM — expliqué d'abord, avant les tarifs.
const PRINCIPE = [
  { Icone: Globe, titre: "Une adresse vivante", texte: "+lea-tom, +votre-marque : votre mini-site vit sur son adresse « + », courte et mémorisable." },
  { Icone: Fingerprint, titre: "Une identité", texte: "Le +nom, c'est vous : votre carte, vos projets et votre site conforme EAA, au même endroit." },
  { Icone: Share2, titre: "Qui se branche", texte: "Les +noms se relient entre eux — invités, prestataires, partenaires se retrouvent par l'adresse." },
];

export default function CapsuleForfaits({ onEssai, onVisiter, onClose }) {
  return (
    <section className="ripple-wave mt-5 w-full max-w-4xl rounded-3xl border border-white/10 bg-[#0e0e11]/95 p-5 shadow-2xl backdrop-blur-xl" aria-label="Forfaits AI+ME">
      <div className="mb-4 flex items-center justify-between gap-3">
        <p className="flex items-center gap-2 text-[13px] font-extrabold text-white">
          <AtSign className="h-4 w-4 text-[#C9A2F5]" aria-hidden="true" /> L'adresse +nom
          <span className="font-mono text-[8px] font-semibold uppercase tracking-[0.22em] text-white/35">Essai offert · abonnement pour publier</span>
        </p>
        <button type="button" onClick={onClose} aria-label="Fermer les forfaits"
          className="flex h-9 w-9 items-center justify-center rounded-full text-white/50 transition hover:bg-white/10 hover:text-white">
          <X className="h-4 w-4" />
        </button>
      </div>

      {/* 1 — LE PRINCIPE : comprendre le +nom avant de voir les tarifs. */}
      <div className="mb-4 grid gap-3 sm:grid-cols-3">
        {PRINCIPE.map(({ Icone, titre, texte }) => (
          <div key={titre} className="rounded-2xl border border-white/10 bg-white/[0.02] p-4">
            <span className="flex h-8 w-8 items-center justify-center rounded-full"
              style={{ background: "conic-gradient(from 0deg, #F2A7C3, #E8C97F, #7FDCB2, #7FC3F0, #C9A2F5, #F2A7C3)" }}>
              <Icone className="h-4 w-4 text-black" aria-hidden="true" />
            </span>
            <p className="mt-2.5 text-[13px] font-extrabold text-white">{titre}</p>
            <p className="mt-1 text-[11.5px] leading-snug text-white/55">{texte}</p>
          </div>
        ))}
      </div>

      {/* 2 — LA DISPO : chercher son +nom, et pourquoi le réserver. */}
      <div className="mb-5 rounded-2xl border border-white/10 bg-white/[0.02] p-4">
        <p className="mb-2.5 font-mono text-[8px] font-semibold uppercase tracking-[0.22em] text-white/40">
          Votre +nom est-il libre ? — vérifiez, puis réservez-le avec un forfait
        </p>
        <PlusNomDispo />
      </div>

      {/* 3 — L'ESSAI : tout est ouvert librement pendant la construction. */}
      <button type="button" onClick={onEssai}
        className="flex min-h-[44px] w-full items-center justify-center gap-1.5 rounded-full bg-white px-4 text-[13px] font-bold text-black transition hover:bg-white/85">
        Commencer librement — l'essai est offert <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
      </button>

      <button type="button" onClick={onVisiter}
        className="mt-4 flex min-h-[40px] w-full items-center justify-center gap-1.5 rounded-full text-[11px] font-semibold text-white/50 transition hover:bg-white/5 hover:text-white">
        Déjà une adresse ? Visiter un +nom <ArrowRight className="h-3 w-3" aria-hidden="true" />
      </button>
    </section>
  );
}