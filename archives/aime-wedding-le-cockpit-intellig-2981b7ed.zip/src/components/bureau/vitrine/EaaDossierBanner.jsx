import { FolderOpen, Palette, ImageIcon, ShieldCheck } from "lucide-react";

// Bannière « dossier de projet EAA » : le composeur annonce ce qu'il a reçu
// du pipeline — site audité, style choisi, visuels générés, score.
export default function EaaDossierBanner({ dossier, mediaCount }) {
  const report = dossier?.report;
  const style = dossier?.style;
  const score = typeof report?.score === "number" ? report.score : null;

  return (
    <div className="mb-6 flex flex-wrap items-center gap-x-5 gap-y-2 rounded-2xl border border-accent/30 bg-accent/[0.06] px-5 py-4">
      <span className="inline-flex items-center gap-2 text-[12px] font-semibold text-accent">
        <FolderOpen className="h-4 w-4" /> Dossier EAA branché
      </span>
      <span className="text-[13px] text-white/80">
        {report?.site_name || "Site audité"}
        {report?.sector ? <span className="text-white/40"> · {report.sector}</span> : null}
      </span>
      {style?.name && (
        <span className="inline-flex items-center gap-1.5 text-[12px] text-white/60">
          <Palette className="h-3.5 w-3.5 text-accent" /> Style « {style.name} »
        </span>
      )}
      <span className="inline-flex items-center gap-1.5 text-[12px] text-white/60">
        <ImageIcon className="h-3.5 w-3.5 text-accent" /> {mediaCount} visuel{mediaCount > 1 ? "s" : ""} du dossier
      </span>
      {score !== null && (
        <span className="inline-flex items-center gap-1.5 rounded-full border border-accent/40 px-2.5 py-1 text-[11px] font-semibold text-accent">
          <ShieldCheck className="h-3.5 w-3.5" /> Audit {score}/100
        </span>
      )}
    </div>
  );
}