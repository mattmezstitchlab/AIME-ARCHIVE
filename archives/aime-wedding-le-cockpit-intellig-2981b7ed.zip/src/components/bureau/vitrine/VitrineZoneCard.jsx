import { useState } from "react";
import { Check, Plus, ArrowLeft, RotateCcw, Sparkles, Film } from "lucide-react";
import { BUILDER_BLOCKS } from "@/lib/gallery/builderBlocks";
import { blockIcon } from "@/lib/gallery/builderBlockIcons";

// ─────────────────────────────────────────────────────────────────────────
// ZONE DE VITRINE = CARTE QUI SE RETOURNE.
//   · RECTO : la zone du site (bloc + visuel intégrés, ou wireframe).
//   · VERSO : les blocs suggérés + LES VISUELS DU DOSSIER EAA à intégrer.
// filled = { block: blockKey, media: { type, url, label } }
// ─────────────────────────────────────────────────────────────────────────
export default function VitrineZoneCard({ zone, filled, eaaMedia = [], onPickBlock, onPickMedia }) {
  const [flipped, setFlipped] = useState(false);

  const filledBlock = filled?.block ? BUILDER_BLOCKS.find((b) => b.key === filled.block) : null;
  const media = filled?.media || null;
  const FilledIcon = filledBlock ? blockIcon(filledBlock.key) : null;
  const suggested = zone.blocks.map((k) => BUILDER_BLOCKS.find((b) => b.key === k)).filter(Boolean);
  const isFilled = !!(filledBlock || media);

  return (
    <div className="group relative aspect-[4/5] [perspective:1400px]">
      <div
        className="relative h-full w-full transition-transform duration-500 [transform-style:preserve-3d]"
        style={{ transform: flipped ? "rotateY(180deg)" : "rotateY(0deg)" }}
      >
        {/* ── RECTO — la zone du site ─────────────────────────────────── */}
        <button
          type="button"
          onClick={() => setFlipped(true)}
          className={`absolute inset-0 flex flex-col overflow-hidden rounded-2xl border text-left [backface-visibility:hidden] transition ${
            isFilled
              ? "border-white/15 bg-white/[0.05]"
              : "border-dashed border-white/15 bg-white/[0.02] hover:border-accent/50"
          }`}
        >
          {/* Visuel du dossier en fond de carte */}
          {media && (
            <>
              {media.type === "video" ? (
                <video src={media.url} className="absolute inset-0 h-full w-full object-cover opacity-35" muted loop autoPlay playsInline />
              ) : (
                <img src={media.url} alt={media.label || zone.label} className="absolute inset-0 h-full w-full object-cover opacity-35" />
              )}
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-black/20" aria-hidden="true" />
            </>
          )}

          <div className="relative flex items-center justify-between px-5 pt-5">
            <span className="text-[10px] font-semibold uppercase tracking-[0.18em] text-white/45">{zone.label}</span>
            {isFilled ? (
              <span className="inline-flex items-center gap-1 rounded-full bg-accent/15 px-2 py-0.5 text-[9px] font-semibold text-accent">
                <Check className="h-2.5 w-2.5" /> intégré
              </span>
            ) : (
              <span className="inline-flex items-center gap-1 rounded-full bg-white/[0.06] px-2 py-0.5 text-[9px] font-medium text-white/50">
                {suggested.length + eaaMedia.length} éléments
              </span>
            )}
          </div>

          <div className="relative flex flex-1 flex-col items-center justify-center px-5 text-center">
            {filledBlock ? (
              <>
                <div className="grid h-14 w-14 place-items-center rounded-2xl bg-accent/10 text-accent">
                  {FilledIcon && <FilledIcon className="h-7 w-7" strokeWidth={1.4} />}
                </div>
                <p className="mt-3 font-heading text-lg text-white">{filledBlock.title}</p>
                <p className="mt-1 text-[12px] leading-snug text-white/45">{filledBlock.subtitle}</p>
              </>
            ) : media ? (
              <p className="font-heading text-[15px] text-white/85">{media.label || "Visuel intégré"}</p>
            ) : (
              <>
                <div className="grid h-14 w-14 place-items-center rounded-2xl border border-dashed border-white/20 text-white/30">
                  <Plus className="h-6 w-6" strokeWidth={1.4} />
                </div>
                <p className="mt-3 font-heading text-[15px] text-white/70">À composer</p>
                <p className="mt-1 text-[12px] leading-snug text-white/35">{zone.hint}</p>
              </>
            )}
          </div>

          <div className="relative flex items-center justify-center gap-1.5 pb-5 text-[11px] text-white/40 transition group-hover:text-accent">
            <RotateCcw className="h-3 w-3" /> {isFilled ? "Changer" : "Voir les blocs"}
          </div>
        </button>

        {/* ── VERSO — blocs suggérés + visuels du dossier EAA ─────────── */}
        <div className="absolute inset-0 flex flex-col overflow-hidden rounded-2xl border border-white/10 bg-neutral-950 [backface-visibility:hidden] [transform:rotateY(180deg)]">
          <div className="flex items-start justify-between gap-2 px-5 pt-5">
            <div className="min-w-0">
              <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-accent">Zone · {zone.label}</p>
              <p className="mt-1 text-[12px] leading-snug text-white/45">{zone.hint}</p>
            </div>
            <button
              type="button"
              onClick={() => setFlipped(false)}
              aria-label="Retourner la carte"
              className="mt-0.5 inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-white/60 transition hover:bg-white/10 hover:text-white"
            >
              <ArrowLeft className="h-4 w-4" />
            </button>
          </div>

          <div className="mt-3 flex-1 space-y-2.5 overflow-y-auto px-4 pb-4 scrollbar-hide">
            {suggested.map((block, i) => {
              const Icon = blockIcon(block.key);
              const isActive = filled?.block === block.key;
              return (
                <button
                  key={block.key}
                  type="button"
                  onClick={() => { onPickBlock(block, zone); setFlipped(false); }}
                  className={`flex w-full items-start gap-3 rounded-xl border p-3 text-left transition ${
                    isActive
                      ? "border-accent bg-accent/[0.1]"
                      : i === 0
                        ? "border-accent/40 bg-accent/[0.05] hover:border-accent/70"
                        : "border-white/10 bg-white/[0.02] hover:border-white/25"
                  }`}
                >
                  <div className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-white/[0.05] text-accent">
                    <Icon className="h-4.5 w-4.5" strokeWidth={1.5} />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <h4 className="truncate font-heading text-[14px] text-white">{block.title}</h4>
                      {i === 0 && !isActive && (
                        <span className="inline-flex shrink-0 items-center gap-1 rounded-full bg-accent px-1.5 py-0.5 text-[8px] font-semibold text-black">
                          <Sparkles className="h-2 w-2" /> conseillé
                        </span>
                      )}
                      {isActive && (
                        <span className="inline-flex shrink-0 items-center gap-1 rounded-full bg-accent/20 px-1.5 py-0.5 text-[8px] font-semibold text-accent">
                          <Check className="h-2 w-2" /> intégré
                        </span>
                      )}
                    </div>
                    <p className="mt-0.5 line-clamp-2 text-[11px] leading-snug text-white/45">{block.subtitle}</p>
                  </div>
                </button>
              );
            })}

            {/* Les visuels générés dans le pipeline EAA, intégrables ici */}
            {eaaMedia.length > 0 && (
              <div className="pt-2">
                <p className="mb-2 text-[10px] font-semibold uppercase tracking-[0.18em] text-accent">
                  Visuels du dossier EAA
                </p>
                <div className="grid grid-cols-2 gap-2">
                  {eaaMedia.map((m, i) => {
                    const isActive = filled?.media?.url === m.url;
                    return (
                      <button
                        key={i}
                        type="button"
                        onClick={() => { onPickMedia(m, zone); setFlipped(false); }}
                        className={`relative aspect-[16/10] overflow-hidden rounded-lg border text-left transition ${
                          isActive ? "border-accent ring-1 ring-accent" : "border-white/10 hover:border-white/40"
                        }`}
                      >
                        {m.type === "video" ? (
                          <video src={m.url} className="h-full w-full object-cover" muted loop autoPlay playsInline />
                        ) : (
                          <img src={m.url} alt={m.label} className="h-full w-full object-cover" />
                        )}
                        <span className="absolute bottom-1 left-1 inline-flex items-center gap-1 rounded-full bg-black/70 px-1.5 py-0.5 font-mono text-[8px] text-white">
                          {m.type === "video" && <Film className="h-2.5 w-2.5" />} {m.label}
                        </span>
                        {isActive && (
                          <span className="absolute top-1 right-1 grid h-5 w-5 place-items-center rounded-full bg-accent text-black">
                            <Check className="h-3 w-3" />
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}