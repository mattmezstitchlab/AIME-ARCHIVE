import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Rocket, Loader2, ExternalLink, Copy, Check } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { BUILDER_BLOCKS } from "@/lib/gallery/builderBlocks";
import { getComposition, saveComposition } from "@/lib/bureau/vitrineComposition";

// Barre de publication : assemble les zones composées en un enregistrement
// ComposedVitrine et publie sur /vc/:slug. Re-publier met à jour la même page.
export default function VitrinePublishBar({ role, vitrine, filled, dossier }) {
  const [publishing, setPublishing] = useState(false);
  const [slug, setSlug] = useState(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    setSlug(getComposition(role).publishedSlug || null);
  }, [role]);

  const done = vitrine.zones.filter((z) => filled[z.id]?.block || filled[z.id]?.media).length;

  const publish = async () => {
    setPublishing(true);
    try {
      const zones = vitrine.zones
        .filter((z) => filled[z.id]?.block || filled[z.id]?.media)
        .map((z) => {
          const f = filled[z.id];
          const block = f.block ? BUILDER_BLOCKS.find((b) => b.key === f.block) : null;
          return {
            id: z.id,
            label: z.label,
            block_key: f.block || "",
            block_title: block?.title || "",
            block_subtitle: block?.subtitle || "",
            media_type: f.media?.type || "",
            media_url: f.media?.url || "",
            media_label: f.media?.label || "",
          };
        });
      const s = slug || `${role}-${Math.random().toString(36).slice(2, 7)}`;
      const data = {
        slug: s,
        role,
        site_name: dossier?.report?.site_name || vitrine.label,
        sector: dossier?.report?.sector || "",
        style_name: dossier?.style?.name || "",
        palette: dossier?.style?.palette || dossier?.style?.colors || [],
        score: typeof dossier?.report?.score === "number" ? dossier.report.score : undefined,
        zones,
        published: true,
      };
      const existing = slug ? await base44.entities.ComposedVitrine.filter({ slug: s }) : [];
      if (existing[0]) await base44.entities.ComposedVitrine.update(existing[0].id, data);
      else await base44.entities.ComposedVitrine.create(data);
      saveComposition(role, { publishedSlug: s });
      setSlug(s);
    } finally {
      setPublishing(false);
    }
  };

  const publicPath = slug ? `/vc/${slug}` : null;
  const copy = () => {
    navigator.clipboard?.writeText(`${window.location.origin}${publicPath}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  return (
    <div className="mt-8 flex flex-wrap items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.03] px-5 py-4">
      <p className="text-[13px] text-white/60">
        <b className="text-accent">{done}</b>/{vitrine.zones.length} zones composées
        {slug && <span className="text-white/40"> · déjà publiée — re-publier met la page à jour</span>}
      </p>
      <div className="ml-auto flex flex-wrap items-center gap-2">
        {publicPath && (
          <>
            <Link
              to={publicPath}
              className="inline-flex items-center gap-1.5 rounded-full border border-white/20 px-4 py-2 text-[12px] font-medium text-white/80 transition hover:border-white/50 hover:text-white"
            >
              <ExternalLink className="h-3.5 w-3.5" /> Voir la vitrine
            </Link>
            <button
              type="button"
              onClick={copy}
              className="inline-flex items-center gap-1.5 rounded-full border border-white/20 px-4 py-2 text-[12px] font-medium text-white/80 transition hover:border-white/50 hover:text-white"
            >
              {copied ? <Check className="h-3.5 w-3.5 text-accent" /> : <Copy className="h-3.5 w-3.5" />}
              {copied ? "Copié" : "Copier le lien"}
            </button>
          </>
        )}
        <button
          type="button"
          onClick={publish}
          disabled={publishing || done === 0}
          className="inline-flex items-center gap-2 rounded-full bg-accent px-5 py-2 text-[12px] font-semibold text-black transition hover:brightness-110 disabled:opacity-40"
        >
          {publishing ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Rocket className="h-3.5 w-3.5" />}
          {slug ? "Re-publier" : "Publier la vitrine"}
        </button>
      </div>
    </div>
  );
}