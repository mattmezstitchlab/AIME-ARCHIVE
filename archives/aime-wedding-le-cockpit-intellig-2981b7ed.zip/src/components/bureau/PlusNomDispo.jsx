import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Search, Loader2, Check, ArrowRight } from "lucide-react";
import { base44 } from "@/api/base44Client";

const slugifier = (txt) =>
  txt.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/^\+/, "").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");

// LA RECHERCHE DE DISPO — on tape son +nom rêvé, on vérifie s'il est libre :
// libre → on le réserve avec un forfait ; pris → on peut le visiter.
export default function PlusNomDispo() {
  const [valeur, setValeur] = useState("");
  const [etat, setEtat] = useState(null); // null | "check" | "libre" | "pris"
  const [slug, setSlug] = useState("");
  const navigate = useNavigate();

  const verifier = async (e) => {
    e.preventDefault();
    const s = slugifier(valeur);
    if (!s) return;
    setSlug(s);
    setEtat("check");
    const rows = await base44.entities.PublishedSite.filter({ slug: s });
    setEtat(rows.length ? "pris" : "libre");
  };

  return (
    <div>
      <form onSubmit={verifier}
        className="flex items-center gap-2 rounded-full border border-white/15 bg-black/40 p-1.5 pl-4 transition-colors focus-within:border-white/40">
        <span className="accent-arcenciel text-[16px]" aria-hidden="true">+</span>
        <input value={valeur} onChange={(e) => { setValeur(e.target.value); setEtat(null); }}
          placeholder="votre-nom" aria-label="Vérifier la disponibilité d'une adresse +nom"
          className="min-h-[40px] flex-1 bg-transparent text-[13px] text-white outline-none placeholder:text-white/30 focus-visible:!shadow-none" />
        <button type="submit" disabled={!valeur.trim() || etat === "check"}
          className="flex min-h-[40px] items-center gap-1.5 rounded-full bg-white px-4 text-[12px] font-bold text-black transition hover:bg-white/85 disabled:opacity-30">
          {etat === "check" ? <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" /> : <Search className="h-3.5 w-3.5" aria-hidden="true" />}
          Vérifier la dispo
        </button>
      </form>

      <div aria-live="polite">
        {etat === "libre" && (
          <p className="mt-2.5 flex items-center gap-2 rounded-xl border border-[#7FDCB2]/35 bg-[#7FDCB2]/5 px-3.5 py-2.5 text-[12px] text-white/80">
            <Check className="h-4 w-4 shrink-0 text-[#7FDCB2]" aria-hidden="true" />
            <span><b className="text-white">+{slug}</b> est libre — réservez-le avec un forfait ci-dessous.</span>
          </p>
        )}
        {etat === "pris" && (
          <p className="mt-2.5 flex items-center gap-2 rounded-xl border border-[#F2A7C3]/35 bg-[#F2A7C3]/5 px-3.5 py-2.5 text-[12px] text-white/80">
            <span><b className="text-white">+{slug}</b> est déjà réservé.</span>
            <button type="button" onClick={() => navigate(`/+${slug}`)}
              className="ml-auto flex shrink-0 items-center gap-1 rounded-full border border-white/20 px-3 py-1 text-[11px] font-semibold text-white/70 transition hover:border-white/50 hover:text-white">
              Visiter <ArrowRight className="h-3 w-3" aria-hidden="true" />
            </button>
          </p>
        )}
      </div>
    </div>
  );
}