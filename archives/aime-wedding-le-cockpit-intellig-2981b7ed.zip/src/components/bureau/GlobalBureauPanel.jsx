import { createPortal } from "react-dom";
import { useNavigate, useLocation } from "react-router-dom";
import { FolderOpen } from "lucide-react";

// ─────────────────────────────────────────────────────────────────────────
// ENCOCHE « DOSSIER » — toujours visible sur le bord gauche de l'app.
// L'arbre des dossiers vit désormais sur la page /bureau (source unique) :
// l'encoche y mène directement, plus de panneau dupliqué.
// ─────────────────────────────────────────────────────────────────────────

export default function GlobalBureauPanel() {
  const navigate = useNavigate();
  const location = useLocation();

  // Sur le Bureau lui-même, l'encoche est inutile.
  if (location.pathname === "/bureau") return null;

  return createPortal(
    <button
      type="button"
      onClick={() => navigate("/bureau")}
      aria-label="Ouvrir le Bureau"
      className="fixed left-0 top-1/2 z-[60] -translate-y-1/2 rounded-r-xl bg-black/80 py-4 pl-2 pr-2.5 text-white shadow-lg backdrop-blur transition-transform hover:translate-x-0.5"
    >
      <span className="flex flex-col items-center gap-2">
        <FolderOpen className="h-4 w-4 text-[#c9a96e]" strokeWidth={1.6} />
        <span
          className="text-[10px] font-semibold uppercase tracking-[0.2em] text-white/80"
          style={{ writingMode: "vertical-rl" }}
        >
          Dossier
        </span>
      </span>
    </button>,
    document.body
  );
}