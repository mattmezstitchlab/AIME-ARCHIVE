import { useEffect, useState } from "react";
import { Check, Loader2, Pencil } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { FAMILLES, SECTIONS_UNIVERSELLES } from "@/lib/bureau/minisite/sectionsTaxonomie";
import SectionEditor from "./SectionEditor";

// LES SECTIONS À COCHER — l'IA reconnaît le projet et pré-coche les blocs
// pertinents (RSVP, Intermittent, Infos pratiques…). Chaque carte reprend
// le design éditorial sobre : fond blanc, grand titre serif, label discret.
export default function MiniSiteSections({ project, secs, onChange }) {
  const [analyse, setAnalyse] = useState(false);
  const [editId, setEditId] = useState(null);
  const coches = secs.coches || [];

  // LA RECONNAISSANCE — au premier passage, l'IA choisit les sections.
  useEffect(() => {
    if (secs.coches !== null || analyse) return;
    setAnalyse(true);
    base44.integrations.Core.InvokeLLM({
      prompt: `Projet : "${project.project_title || project.intent}" (${project.project_type || "projet"}). Intro : ${project.intro || "—"}. Verticalités : ${(project.facets || []).map((f) => f.label).join(", ") || "—"}.
Parmi ces sections de mini-site, choisis les 6 à 10 PERTINENTES pour ce projet (ids exacts) : ${SECTIONS_UNIVERSELLES.map((s) => `${s.id} (${s.label})`).join(", ")}.`,
      response_json_schema: { type: "object", properties: { ids: { type: "array", items: { type: "string" } } } },
    })
      .then((res) => onChange({ ...secs, coches: (res.ids || []).filter((id) => SECTIONS_UNIVERSELLES.some((s) => s.id === id)) }))
      .finally(() => setAnalyse(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const toggle = (id) =>
    onChange({ ...secs, coches: coches.includes(id) ? coches.filter((c) => c !== id) : [...coches, id] });

  return (
    <div className="space-y-3 rounded-2xl border border-white/10 bg-white/[0.02] p-4">
      <div className="flex items-center justify-between gap-3">
        <p className="font-mono text-[9px] font-semibold uppercase tracking-[0.26em] text-white">
          Sections du site · {coches.length} cochée{coches.length > 1 ? "s" : ""}
        </p>
        {analyse && (
          <p className="flex items-center gap-1.5 text-[10px] text-white/45">
            <Loader2 className="h-3 w-3 animate-spin" aria-hidden="true" /> Ripple reconnaît le projet et pré-coche…
          </p>
        )}
      </div>

      {FAMILLES.map((fam) => {
        const sections = SECTIONS_UNIVERSELLES.filter((s) => s.famille === fam);
        return (
          <div key={fam}>
            <p className="mb-1.5 font-mono text-[8px] font-semibold uppercase tracking-[0.24em] text-white/35">{fam}</p>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-4">
              {sections.map((s) => {
                const coche = coches.includes(s.id);
                const data = secs.data?.[s.id] || {};
                return (
                  <div
                    key={s.id}
                    className={`group relative overflow-hidden rounded-lg border bg-[#FBFAF7] transition ${
                      coche ? "border-white shadow-[0_0_0_1px_#fff]" : "border-white/15 opacity-60 hover:opacity-90"
                    }`}
                  >
                    <button type="button" onClick={() => toggle(s.id)} className="block w-full p-3 text-left" aria-pressed={coche}>
                      <span className="block font-mono text-[7px] font-semibold uppercase tracking-[0.22em] text-black/40">{fam}</span>
                      <span className="mt-0.5 block truncate text-[16px] font-bold leading-tight text-black" style={{ fontFamily: "Georgia, 'Times New Roman', serif" }}>
                        {s.label}
                      </span>
                    </button>
                    {data.image_url && <img src={data.image_url} alt="" className="h-14 w-full object-cover" />}
                    <span
                      className={`absolute right-2 top-2 grid h-[18px] w-[18px] place-items-center rounded-full border ${
                        coche ? "border-black bg-black text-white" : "border-black/25 bg-white"
                      }`}
                      aria-hidden="true"
                    >
                      {coche && <Check className="h-3 w-3" />}
                    </span>
                    <button
                      type="button"
                      onClick={() => setEditId(editId === s.id ? null : s.id)}
                      aria-label={`Éditer la section ${s.label}`}
                      className="absolute bottom-2 right-2 grid h-6 w-6 place-items-center rounded-full bg-black/5 text-black/45 opacity-0 transition hover:bg-black hover:text-white group-hover:opacity-100"
                    >
                      <Pencil className="h-3 w-3" />
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        );
      })}

      {editId && (
        <SectionEditor
          section={SECTIONS_UNIVERSELLES.find((s) => s.id === editId)}
          project={project}
          data={secs.data?.[editId] || {}}
          onChange={(patch) => onChange({ ...secs, data: { ...(secs.data || {}), [editId]: { ...(secs.data?.[editId] || {}), ...patch } } })}
          onClose={() => setEditId(null)}
        />
      )}
    </div>
  );
}