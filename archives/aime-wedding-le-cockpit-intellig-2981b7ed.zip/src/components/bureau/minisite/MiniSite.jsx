import { useState } from "react";
import { X, Loader2, Zap } from "lucide-react";
import { base44 } from "@/api/base44Client";
import MiniSiteRender from "./MiniSiteRender";
import MiniSiteDesignSystem from "./MiniSiteDesignSystem";
import MiniSiteSections from "./MiniSiteSections";
import DevicePreview from "./DevicePreview";
import { SECTIONS_UNIVERSELLES } from "@/lib/bureau/minisite/sectionsTaxonomie";

// LE MINI-SITE — TOUT est généré d'un seul coup : une seule page verticale
// qui unifie les verticalités comme un vrai site, habillée par le design
// system du projet (palette, typos, visuels des cartes en plein format).
export default function MiniSite({ project, onClose, onSaved }) {
  const [site, setSite] = useState(project.minisite || null);
  const [busy, setBusy] = useState(false);
  const vals = project.facet_values || {};
  // LE DESIGN SYSTEM — choisi juste avant de générer : couleurs, typos,
  // boutons, composition de page. Tout le site est généré avec ces choix.
  const [ds, setDs] = useState(() => project.minisite?.ds || {
    palette: project.direction?.palette || ["#0C0C0C", "#C9A96E", "#F4F2EC"],
    typo_titres: project.direction?.typo_titres || "Inter",
    typo_texte: project.direction?.typo_texte || "Inter",
    bouton: "pilule",
    compo: "alterne",
  });
  // LES SECTIONS COCHÉES — reconnues et pré-cochées par l'IA, ajustées par
  // l'utilisateur, avec leurs contenus édités (texte, visuel, lien).
  const [secs, setSecs] = useState(() => project.minisite?.secs || { coches: null, data: {} });

  const generer = async () => {
    if (busy) return;
    setBusy(true);
    const cochees = SECTIONS_UNIVERSELLES.filter((s) => (secs.coches || []).includes(s.id));
    try {
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `Tu es le moteur de génération d'AIME®. Génère D'UN SEUL COUP le mini-site COMPLET du projet "${project.project_title || project.intent}" (${project.project_type || "projet"}) — une seule page verticale, comme un vrai site premium.
Design system CHOISI par l'utilisateur (à respecter absolument) : palette ${(ds.palette || []).join(", ")} — titres ${ds.typo_titres} / texte ${ds.typo_texte} — boutons ${ds.bouton} — composition de page ${ds.compo}.
Intro du projet : ${project.intro || "—"}.
${cochees.length ? `Sections COCHÉES par l'utilisateur — génère EXACTEMENT celles-ci, une section chacune, dans cet ordre, avec leur "key" exacte :
${cochees.map((s) => `- key "${s.id}" · ${s.label}${secs.data?.[s.id]?.texte ? ` — TEXTE FOURNI par l'utilisateur, à respecter et peaufiner : ${secs.data[s.id].texte}` : ""}`).join("\n")}
Les verticalités ci-dessous servent de CONNAISSANCES pour nourrir ces sections :` : `Les verticalités (chacune devient UNE SECTION de la page, dans l'ordre) :`}
${(project.facets || [])
  .map((f) => `- key "${f.key}" · ${f.label} : ${f.description || ""}. Réglages connus : ${(f.items || [])
    .map((it) => {
      const v = vals[f.key]?.[it.id];
      return v === null || v === undefined || v === "" ? null : `${it.label} = ${Array.isArray(v) ? v.join(", ") : v}`;
    })
    .filter(Boolean)
    .join(" · ") || "aucun"}${vals[f.key]?._absorbe ? ` — CONTENU ABSORBÉ à privilégier (le meilleur, déjà trié) : ${vals[f.key]._absorbe}` : ""}`)
  .join("\n")}

Rédige TOUT maintenant, sans poser de question :
- "hero" : accroche (3-5 mots), titre percutant, sous_titre (1 phrase).
- "sections" : ${cochees.length ? "UNE par section cochée" : "UNE par verticalité"}, dans l'ordre, avec sa "key" exacte — titre éditorial, texte (2-3 phrases nourries des réglages et contenus connus), 3 "points" concrets et courts.
- "pied" : phrase de clôture élégante.
Ton premium, français, cohérent d'un bout à l'autre.`,
        response_json_schema: {
          type: "object",
          properties: {
            hero: {
              type: "object",
              properties: { accroche: { type: "string" }, titre: { type: "string" }, sous_titre: { type: "string" } },
            },
            sections: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  key: { type: "string" },
                  titre: { type: "string" },
                  texte: { type: "string" },
                  points: { type: "array", items: { type: "string" } },
                },
              },
            },
            pied: { type: "string" },
          },
        },
      });
      // On applique les contenus édités par l'utilisateur (visuel, lien).
      const sections = (res.sections || []).map((s) => {
        const d = secs.data?.[s.key] || {};
        return { ...s, ...(d.image_url ? { image_url: d.image_url } : {}), ...(d.lien ? { lien: d.lien } : {}) };
      });
      const saved = { ...res, sections, ds, secs };
      setSite(saved);
      base44.entities.AimeProject.update(project.id, { minisite: saved });
      onSaved?.(saved);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between gap-3 rounded-2xl border border-white/10 bg-white/[0.03] px-4 py-2.5">
        <p className="font-mono text-[9px] font-semibold uppercase tracking-[0.26em] text-white/45">
          Mini-site · {project.project_title || project.intent}
        </p>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={generer}
            disabled={busy}
            className="inline-flex items-center gap-1.5 rounded-full bg-white px-3.5 py-1.5 text-[11px] font-semibold text-black transition hover:bg-white/85 disabled:opacity-50"
          >
            {busy ? <Loader2 className="h-3 w-3 animate-spin" /> : <Zap className="h-3 w-3" />}
            {busy ? "Génération de tout le site…" : site ? "Tout régénérer" : "Tout générer d'un coup"}
          </button>
          <button type="button" onClick={onClose} aria-label="Fermer le mini-site" className="rounded-full p-1.5 text-white/40 hover:bg-white/10 hover:text-white">
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>

      <MiniSiteDesignSystem direction={project.direction} ds={ds} onChange={setDs} />

      <MiniSiteSections project={project} secs={secs} onChange={setSecs} />

      {site ? (
        <DevicePreview>
          <MiniSiteRender project={project} site={{ ...site, ds }} />
        </DevicePreview>
      ) : (
        <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-12 text-center">
          <p className="mx-auto max-w-md text-[13px] leading-relaxed text-white/50">
            Cochez vos sections, choisissez votre design system, puis un clic : Ripple génère <b className="font-medium text-white/85">tout le mini-site</b> —
            aperçu direct dans un iMac ou un iPhone.
          </p>
        </div>
      )}
    </div>
  );
}