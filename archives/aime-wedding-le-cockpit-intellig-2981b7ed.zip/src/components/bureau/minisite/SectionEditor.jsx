import { useState } from "react";
import { X, Wand2, ImagePlus, Palette, Link2, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";

// L'ÉDITEUR D'UNE SECTION — derrière la carte : le texte (généré par prompt
// ou édité), le visuel (import photo, généré d'après la photo dans un thème,
// ou d'après un thème seul) et le lien URL personnel.
export default function SectionEditor({ section, project, data, onChange, onClose }) {
  const [prompt, setPrompt] = useState("");
  const [theme, setTheme] = useState(data.theme || "");
  const [busy, setBusy] = useState(null);

  const genererTexte = async () => {
    if (busy) return;
    setBusy("texte");
    try {
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `Rédige le texte de la section "${section.label}" du mini-site du projet "${project.project_title || project.intent}". ${prompt.trim() ? `Consigne : ${prompt}.` : ""} 2-3 phrases premium, en français, prêtes à publier.`,
      });
      onChange({ texte: res });
    } finally {
      setBusy(null);
    }
  };

  const importerPhoto = async (file) => {
    if (!file || busy) return;
    setBusy("photo");
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      onChange({ photo_source: file_url, image_url: file_url });
    } finally {
      setBusy(null);
    }
  };

  const genererVisuel = async (avecPhoto) => {
    if (busy || (avecPhoto && !data.photo_source)) return;
    setBusy(avecPhoto ? "img-photo" : "img-theme");
    try {
      const { url } = await base44.integrations.Core.GenerateImage({
        prompt: `Visuel cinématique premium pour la section "${section.label}" d'un site — thème : ${theme.trim() || "sobre, éditorial, lumière naturelle"}. Sans texte incrusté.`,
        ...(avecPhoto ? { existing_image_urls: [data.photo_source] } : {}),
      });
      onChange({ image_url: url, theme });
    } finally {
      setBusy(null);
    }
  };

  const B = ({ id, onClick, icone: Icone, children, disabled }) => (
    <button type="button" onClick={onClick} disabled={busy || disabled}
      className="inline-flex items-center gap-1.5 rounded-full bg-white/[0.08] px-3 py-1.5 text-[10px] font-semibold text-white/65 transition hover:bg-white/15 hover:text-white disabled:opacity-30">
      {busy === id ? <Loader2 className="h-3 w-3 animate-spin" /> : <Icone className="h-3 w-3" />} {children}
    </button>
  );

  return (
    <div className="space-y-2.5 rounded-xl border border-white/12 bg-white/[0.03] p-3.5">
      <div className="flex items-center justify-between">
        <p className="font-mono text-[8.5px] font-semibold uppercase tracking-[0.24em] text-white/55">Éditer · {section.label}</p>
        <button type="button" onClick={onClose} aria-label="Refermer l'éditeur" className="rounded-full p-1 text-white/40 hover:bg-white/10 hover:text-white">
          <X className="h-3.5 w-3.5" />
        </button>
      </div>

      {/* LE TEXTE — édité ou généré par prompt */}
      <textarea
        value={data.texte || ""}
        onChange={(e) => onChange({ texte: e.target.value })}
        placeholder={`Le texte de la section ${section.label} — éditez ou générez par prompt…`}
        rows={3}
        className="w-full resize-none rounded-lg bg-white/[0.06] px-3 py-2 text-[11.5px] leading-relaxed text-white placeholder:text-white/30 focus:bg-white/[0.1] focus:outline-none"
      />
      <div className="flex gap-1.5">
        <input value={prompt} onChange={(e) => setPrompt(e.target.value)} placeholder="Consigne du texte (optionnel)…"
          className="min-w-0 flex-1 rounded-lg bg-white/[0.06] px-2.5 py-1.5 text-[10.5px] text-white placeholder:text-white/30 focus:bg-white/[0.1] focus:outline-none" />
        <B id="texte" onClick={genererTexte} icone={Wand2}>Générer le texte</B>
      </div>

      {/* LE VISUEL — import, photo + thème, ou thème seul */}
      <div className="flex flex-wrap items-center gap-1.5 border-t border-white/8 pt-2.5">
        <label className="inline-flex cursor-pointer items-center gap-1.5 rounded-full bg-white/[0.08] px-3 py-1.5 text-[10px] font-semibold text-white/65 transition hover:bg-white/15 hover:text-white">
          {busy === "photo" ? <Loader2 className="h-3 w-3 animate-spin" /> : <ImagePlus className="h-3 w-3" />} Importer une photo
          <input type="file" accept="image/*" className="hidden" onChange={(e) => { importerPhoto(e.target.files?.[0]); e.target.value = ""; }} />
        </label>
        <input value={theme} onChange={(e) => setTheme(e.target.value)} placeholder="Thème (ex. bord de mer doré)…"
          className="min-w-0 flex-1 rounded-lg bg-white/[0.06] px-2.5 py-1.5 text-[10.5px] text-white placeholder:text-white/30 focus:bg-white/[0.1] focus:outline-none" />
        <B id="img-photo" onClick={() => genererVisuel(true)} icone={Wand2} disabled={!data.photo_source}>D'après la photo</B>
        <B id="img-theme" onClick={() => genererVisuel(false)} icone={Palette}>D'après le thème</B>
      </div>
      {data.image_url && <img src={data.image_url} alt={`Visuel de la section ${section.label}`} className="h-24 w-full rounded-lg object-cover" />}

      {/* LE LIEN PERSONNEL */}
      <div className="flex items-center gap-1.5 border-t border-white/8 pt-2.5">
        <Link2 className="h-3.5 w-3.5 shrink-0 text-white/35" aria-hidden="true" />
        <input value={data.lien || ""} onChange={(e) => onChange({ lien: e.target.value })} placeholder="Lien URL personnel (ex. https://mon-site.fr/rsvp)…"
          className="min-w-0 flex-1 rounded-lg bg-white/[0.06] px-2.5 py-1.5 text-[10.5px] text-white placeholder:text-white/30 focus:bg-white/[0.1] focus:outline-none" />
      </div>
    </div>
  );
}