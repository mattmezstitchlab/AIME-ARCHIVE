import { useState } from "react";
import { Monitor, Smartphone } from "lucide-react";

// L'APERÇU APPAREIL — le mini-site présenté dans un iMac (large) ou un
// iPhone (390px, responsive réel), comme une vraie mise en situation.
export default function DevicePreview({ children }) {
  const [mode, setMode] = useState("imac");

  return (
    <div className="space-y-3">
      <div className="flex justify-center gap-1.5">
        {[["imac", Monitor, "iMac"], ["iphone", Smartphone, "iPhone"]].map(([id, Icone, label]) => (
          <button key={id} type="button" onClick={() => setMode(id)}
            className={`inline-flex items-center gap-1.5 rounded-full px-3.5 py-1.5 text-[10.5px] font-semibold transition ${
              mode === id ? "bg-white text-black" : "bg-white/[0.06] text-white/55 hover:bg-white/[0.12] hover:text-white"
            }`}>
            <Icone className="h-3.5 w-3.5" aria-hidden="true" /> {label}
          </button>
        ))}
      </div>

      {mode === "imac" ? (
        <div className="mx-auto max-w-4xl">
          <div className="rounded-2xl border border-white/15 bg-black p-2.5 shadow-2xl">
            <div className="max-h-[560px] overflow-y-auto overflow-x-hidden rounded-lg scrollbar-hide">{children}</div>
          </div>
          {/* Le pied de l'iMac */}
          <div className="mx-auto h-14 w-16 rounded-b-md bg-gradient-to-b from-white/25 to-white/10" aria-hidden="true" />
          <div className="mx-auto h-1.5 w-40 rounded-full bg-white/20" aria-hidden="true" />
        </div>
      ) : (
        <div className="mx-auto w-[390px] max-w-full">
          <div className="rounded-[44px] border border-white/20 bg-black p-2.5 shadow-2xl">
            <div className="relative overflow-hidden rounded-[34px]">
              {/* L'encoche */}
              <div className="absolute left-1/2 top-1.5 z-10 h-5 w-24 -translate-x-1/2 rounded-full bg-black" aria-hidden="true" />
              <div className="max-h-[640px] overflow-y-auto overflow-x-hidden scrollbar-hide">{children}</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}