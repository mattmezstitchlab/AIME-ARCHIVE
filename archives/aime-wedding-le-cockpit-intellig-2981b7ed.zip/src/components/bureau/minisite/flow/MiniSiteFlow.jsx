import { useState } from "react";
import { X } from "lucide-react";
import FlowRole from "./FlowRole";
import FlowInfos from "./FlowInfos";
import FlowSections from "./FlowSections";
import FlowArticle from "./FlowArticle";
import FlowSite from "./FlowSite";

// LE FLOW MINI-SITE — le Wedding OS EMBARQUÉ dans le Mini-site (sens APEX) :
// tout est masqué, une seule chose au centre. Pipeline : qui on est (rôle
// Wedding OS) → infos essentielles → sections à cocher → l'article EAA
// bienveillant, entièrement réglable, publié au blog comme exemple.
export default function MiniSiteFlow({ onClose }) {
  const [etape, setEtape] = useState("role");
  const [role, setRole] = useState(null);
  const [infos, setInfos] = useState({});
  const [coches, setCoches] = useState(null);
  const [reglages, setReglages] = useState(null);

  return (
    <div className="relative flex min-h-[70vh] flex-col items-center justify-center py-6">
      <button
        type="button"
        onClick={onClose}
        aria-label="Fermer le flow Mini-site"
        className="absolute right-0 top-0 rounded-full p-2 text-white/35 transition hover:bg-white/10 hover:text-white"
      >
        <X className="h-4 w-4" />
      </button>

      {etape === "role" && (
        <FlowRole onChoose={(r) => { setRole(r); setEtape("infos"); }} />
      )}
      {etape === "infos" && (
        <FlowInfos role={role} onDone={(rep) => { setInfos(rep); setEtape("sections"); }} onRetour={() => setEtape("role")} />
      )}
      {etape === "sections" && (
        <FlowSections
          role={role}
          infos={infos}
          coches={coches}
          onChange={setCoches}
          onDone={() => setEtape("article")}
          onRetour={() => setEtape("infos")}
        />
      )}
      {etape === "article" && (
        <FlowArticle
          role={role}
          infos={infos}
          coches={coches || []}
          onRetour={() => setEtape("sections")}
          onMiniSite={(r) => { setReglages(r); setEtape("site"); }}
        />
      )}
      {etape === "site" && (
        <FlowSite role={role} infos={infos} coches={coches || []} reglages={reglages} onRetour={() => setEtape("article")} />
      )}
    </div>
  );
}