import { useEffect, useState } from "react";
import { Loader2, Wand2, Newspaper, ArrowLeft, Check, Sparkles } from "lucide-react";
import { base44 } from "@/api/base44Client";
import FlowArticleReglages, { FONDS, TYPOS, TAILLES, boutonClasses } from "./FlowArticleReglages";

// ÉTAPE 4 — LE VRAI ARTICLE : un article éditorial sur l'accessibilité EAA
// appliquée au thème choisi (pas un catalogue de sections). On règle le
// design system EN LE LISANT (typo, tailles, fond, accent, boutons, hero),
// puis un bouton génère le mini-site avec les sections cochées.
export default function FlowArticle({ role, infos, coches, onRetour, onMiniSite }) {
  const [article, setArticle] = useState(null);
  const [cover, setCover] = useState(null);
  const [busy, setBusy] = useState("gen");
  const [publie, setPublie] = useState(false);
  const [reglages, setReglages] = useState({ typo: "serif", taille: "m", fond: "blanc", accent: "#C9A96E", hero: "Bandeau", bouton: "Pilule" });

  useEffect(() => {
    base44.integrations.Core.InvokeLLM({
      prompt: `Tu es le rédacteur bienveillant d'AIME®, expert EAA (European Accessibility Act). Rédige un VRAI ARTICLE éditorial, chaleureux et sans jargon, sur le thème : « L'accessibilité EAA appliquée à un site de ${role.label} » — le projet de "${infos.nom}" (${infos.projet || role.label}${infos.lieu ? `, à ${infos.lieu}` : ""}${infos.date ? `, le ${infos.date}` : ""}).
L'article explique concrètement ce que l'EAA change pour ce type de site : contrastes, lisibilité, navigation clavier, textes alternatifs, formulaires simples — avec des exemples liés à ce projet précis. Ce n'est PAS une liste de sections : c'est un article qu'on lit avec plaisir.
Réponds en français : "kicker" (surtitre court), "titre" (percutant), "chapo" (2 phrases), "chapitres" (3 à 4 chapitres — chacun : "titre" éditorial, "texte" de 3-4 phrases concrètes, "conseil" pratique d'1 phrase), "citation" (une phrase forte à mettre en exergue), "cloture" (phrase finale bienveillante).`,
      response_json_schema: {
        type: "object",
        properties: {
          kicker: { type: "string" },
          titre: { type: "string" },
          chapo: { type: "string" },
          chapitres: {
            type: "array",
            items: { type: "object", properties: { titre: { type: "string" }, texte: { type: "string" }, conseil: { type: "string" } } },
          },
          citation: { type: "string" },
          cloture: { type: "string" },
        },
      },
    })
      .then(setArticle)
      .finally(() => setBusy(null));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const genererCover = async () => {
    if (busy) return;
    setBusy("img");
    try {
      const { url } = await base44.integrations.Core.GenerateImage({
        prompt: `Visuel de couverture éditorial premium pour "${infos.nom}" — ${infos.projet || role.label}, ${infos.lieu || ""}. Lumière naturelle, cinématique, sans texte.`,
      });
      setCover(url);
    } finally {
      setBusy(null);
    }
  };

  const publier = async () => {
    if (busy || !article) return;
    setBusy("pub");
    try {
      await base44.entities.MagazineArticle.create({
        title: article.titre,
        subtitle: article.chapo,
        kicker: article.kicker,
        category: "Accessibilité · EAA",
        excerpt: article.chapo,
        cover_url: cover || "",
        tags: [role.label, "EAA", "Accessibilité"],
        read_minutes: Math.max(3, (article.chapitres || []).length),
        published: true,
        chapters: (article.chapitres || []).map((c, i) => ({
          id: `ch-${i}`,
          title: c.titre,
          body: c.texte,
          callout: c.conseil,
          quote: i === 1 ? article.citation : "",
        })),
      });
      setPublie(true);
    } finally {
      setBusy(null);
    }
  };

  if (busy === "gen") {
    return (
      <div className="flex flex-col items-center gap-3 py-24 text-white/50">
        <Loader2 className="h-5 w-5 animate-spin" aria-hidden="true" />
        <p className="text-[12px]">Ripple rédige l'article EAA sur votre thème…</p>
      </div>
    );
  }

  const fond = FONDS.find((f) => f.id === reglages.fond) || FONDS[0];
  const typo = (TYPOS.find((t) => t.id === reglages.typo) || TYPOS[0]).font;
  const taille = TAILLES.find((t) => t.id === reglages.taille) || TAILLES[1];
  const btn = boutonClasses(reglages.bouton);

  return (
    <div className="mx-auto w-full max-w-3xl space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <button type="button" onClick={onRetour} className="inline-flex items-center gap-1.5 text-[11px] text-white/35 transition hover:text-white/70">
          <ArrowLeft className="h-3 w-3" aria-hidden="true" /> Sections
        </button>
        <div className="flex items-center gap-2">
          <button type="button" onClick={genererCover} disabled={!!busy}
            className="inline-flex items-center gap-1.5 rounded-full bg-white/[0.08] px-3.5 py-1.5 text-[10.5px] font-semibold text-white/65 transition hover:bg-white/15 hover:text-white disabled:opacity-30">
            {busy === "img" ? <Loader2 className="h-3 w-3 animate-spin" /> : <Wand2 className="h-3 w-3" />} Visuel de couverture
          </button>
          <button type="button" onClick={publier} disabled={!!busy || publie}
            className="inline-flex items-center gap-1.5 rounded-full bg-white/[0.08] px-3.5 py-1.5 text-[10.5px] font-semibold text-white/65 transition hover:bg-white/15 hover:text-white disabled:opacity-30">
            {busy === "pub" ? <Loader2 className="h-3 w-3 animate-spin" /> : publie ? <Check className="h-3 w-3" /> : <Newspaper className="h-3 w-3" />}
            {publie ? "Publié au blog" : "Publier au blog"}
          </button>
          <button type="button" onClick={() => onMiniSite(reglages)} disabled={!!busy}
            className="inline-flex items-center gap-1.5 rounded-full bg-white px-4 py-1.5 text-[11px] font-bold text-black transition hover:bg-white/85 disabled:opacity-40">
            <Sparkles className="h-3 w-3" /> Générer en mini-site
          </button>
        </div>
      </div>

      <FlowArticleReglages reglages={reglages} onChange={setReglages} />

      {/* L'ARTICLE — un vrai article EAA, restylé en direct par les réglages. */}
      <article className="overflow-hidden rounded-2xl border border-white/12" style={{ background: fond.bg, color: fond.texte, fontFamily: typo }}>
        {/* LE HERO — plein format, bandeau, petit format ou sans visuel. */}
        {reglages.hero === "Plein format" && cover ? (
          <header className="relative flex min-h-[340px] flex-col justify-end p-8">
            <img src={cover} alt="" className="absolute inset-0 h-full w-full object-cover" />
            <span className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/25 to-transparent" aria-hidden="true" />
            <div className="relative text-white">
              <p className="font-mono text-[9px] font-bold uppercase tracking-[0.28em]" style={{ color: reglages.accent }}>{article.kicker}</p>
              <h2 className="mt-2 font-bold leading-[1.05]" style={{ fontSize: taille.titre }}>{article.titre}</h2>
            </div>
          </header>
        ) : (
          <header className="p-8 pb-0">
            <div className={reglages.hero === "Petit format" && cover ? "flex items-start gap-5" : ""}>
              <div className="min-w-0 flex-1">
                <p className="font-mono text-[9px] font-bold uppercase tracking-[0.28em]" style={{ color: reglages.accent }}>{article.kicker}</p>
                <h2 className="mt-2 font-bold leading-[1.05]" style={{ fontSize: taille.titre }}>{article.titre}</h2>
                <p className="mt-3 italic opacity-70" style={{ fontSize: taille.corps + 1 }}>{article.chapo}</p>
              </div>
              {reglages.hero === "Petit format" && cover && <img src={cover} alt="" className="h-32 w-44 shrink-0 rounded-lg object-cover" />}
            </div>
            {reglages.hero === "Bandeau" && cover && <img src={cover} alt="" className="mt-6 -mx-8 h-64 w-[calc(100%+4rem)] max-w-none object-cover" />}
          </header>
        )}

        <div className="space-y-8 p-8">
          {/* LE BOUTON D'EXEMPLE — le design system des boutons, réglé en lisant. */}
          <button type="button" className={btn.cls} style={btn.style(reglages.accent, fond)}>
            Découvrir le futur site
          </button>

          {(article.chapitres || []).map((c, i) => (
            <section key={i}>
              <h3 className="font-bold leading-tight" style={{ fontSize: Math.round(taille.titre * 0.55) }}>{c.titre}</h3>
              <p className="mt-2 leading-relaxed opacity-85" style={{ fontSize: taille.corps }}>{c.texte}</p>
              {c.conseil && (
                <p className="mt-3 rounded-lg border-l-4 px-4 py-2.5 font-medium" style={{ fontSize: taille.corps - 1, borderColor: reglages.accent, background: `${reglages.accent}14` }}>
                  {c.conseil}
                </p>
              )}
              {i === 1 && article.citation && (
                <blockquote className="mt-5 border-l-2 pl-4 italic opacity-80" style={{ fontSize: taille.corps + 3, borderColor: reglages.accent }}>
                  « {article.citation} »
                </blockquote>
              )}
            </section>
          ))}

          <div className="border-t pt-5" style={{ borderColor: `${fond.texte}22` }}>
            <p className="italic opacity-70" style={{ fontSize: taille.corps }}>{article.cloture}</p>
            <button type="button" className={`mt-4 ${btn.cls}`} style={btn.style(reglages.accent, fond)}>
              Nous contacter
            </button>
          </div>
        </div>
      </article>
    </div>
  );
}