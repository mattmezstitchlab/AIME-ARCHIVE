import { useEffect, useState } from "react";
import { Loader2, ArrowLeft, ExternalLink } from "lucide-react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { SECTIONS_UNIVERSELLES } from "@/lib/bureau/minisite/sectionsTaxonomie";
import MiniSiteRender from "../MiniSiteRender";
import { FONDS } from "./FlowArticleReglages";

// ÉTAPE 5 — LE MINI-SITE GÉNÉRÉ : construit avec les SECTIONS cochées et
// le design system réglé en lisant l'article. Le projet est sauvegardé —
// il apparaît au Registre et a sa page publique.
export default function FlowSite({ role, infos, coches, reglages, onRetour }) {
  const [project, setProject] = useState(null);

  useEffect(() => {
    const generer = async () => {
      const sections = SECTIONS_UNIVERSELLES.filter((s) => coches.includes(s.id));
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `Tu génères le mini-site une page de "${infos.nom}" (rôle : ${role.label}${infos.projet ? ` — ${infos.projet}` : ""}${infos.lieu ? `, ${infos.lieu}` : ""}${infos.date ? `, ${infos.date}` : ""}). Site accessible EAA : phrases claires, ton chaleureux.
Réponds en français : "hero" ("accroche" surtitre court, "titre" percutant, "sous_titre" 1-2 phrases), "sections" (UNE par section demandée, dans cet ordre : ${sections.map((s) => `"${s.id}" (${s.label})`).join(", ")} — chacune : "key" exacte, "titre" éditorial, "texte" 2-3 phrases, "points" 2-3 puces courtes), "pied" (phrase de clôture).`,
        response_json_schema: {
          type: "object",
          properties: {
            hero: { type: "object", properties: { accroche: { type: "string" }, titre: { type: "string" }, sous_titre: { type: "string" } } },
            sections: {
              type: "array",
              items: { type: "object", properties: { key: { type: "string" }, titre: { type: "string" }, texte: { type: "string" }, points: { type: "array", items: { type: "string" } } } },
            },
            pied: { type: "string" },
          },
        },
      });

      // Le design system réglé dans l'article suit le site.
      const fond = FONDS.find((f) => f.id === reglages.fond) || FONDS[0];
      const site = {
        ...res,
        ds: {
          palette: [fond.bg, reglages.accent, fond.texte],
          typo_titres: reglages.typo === "serif" ? "Georgia" : reglages.typo === "mono" ? "JetBrains Mono" : "Inter",
          typo_texte: "Inter",
          bouton: reglages.bouton === "Carré" ? "carre" : reglages.bouton === "Souligné" ? "souligne" : "pilule",
          compo: "alterne",
        },
      };

      const created = await base44.entities.AimeProject.create({
        intent: `mini-site ${role.label}`,
        project_title: infos.nom,
        project_type: role.label,
        minisite: site,
      });
      setProject(created);
    };
    generer();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (!project) {
    return (
      <div className="flex flex-col items-center gap-3 py-24 text-white/50">
        <Loader2 className="h-5 w-5 animate-spin" aria-hidden="true" />
        <p className="text-[12px]">Ripple construit votre mini-site avec vos sections…</p>
      </div>
    );
  }

  return (
    <div className="mx-auto w-full max-w-4xl space-y-3">
      <div className="flex items-center justify-between gap-2">
        <button type="button" onClick={onRetour} className="inline-flex items-center gap-1.5 text-[11px] text-white/35 transition hover:text-white/70">
          <ArrowLeft className="h-3 w-3" aria-hidden="true" /> Article
        </button>
        <Link to={`/site/${project.id}`}
          className="inline-flex items-center gap-1.5 rounded-full bg-white px-4 py-1.5 text-[11px] font-bold text-black transition hover:bg-white/85">
          <ExternalLink className="h-3 w-3" /> Voir la page publique
        </Link>
      </div>
      <MiniSiteRender project={project} site={project.minisite} />
    </div>
  );
}