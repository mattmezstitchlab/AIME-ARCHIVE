import { ROLES } from "@/components/weddingos/osRoles";

// ÉTAPE 1 — QUI ÊTES-VOUS ? La première étape du Wedding OS, embarquée
// dans le Mini-site : le rôle choisi teinte tout le reste de la pipeline.
export default function FlowRole({ onChoose }) {
  return (
    <div className="mx-auto w-full max-w-2xl text-center">
      <p className="font-mono text-[9px] font-semibold uppercase tracking-[0.3em] text-white/40">
        Mini-site · Wedding OS embarqué — étape 1/4
      </p>
      <h2 className="mt-3 font-heading text-[30px] font-extrabold leading-tight text-white">Qui êtes-vous ?</h2>
      <p className="mt-2 text-[13px] text-white/50">Votre rôle configure l'article, les sections du site et vos agents.</p>

      <div className="mt-8 grid grid-cols-2 gap-2 sm:grid-cols-3">
        {ROLES.map((r) => (
          <button
            key={r.id}
            type="button"
            onClick={() => onChoose(r)}
            className="group rounded-xl border border-white/10 bg-white/[0.03] p-4 text-left transition hover:border-white/40 hover:bg-white/[0.07]"
          >
            <span className="block h-2 w-2 rounded-full" style={{ background: r.color }} aria-hidden="true" />
            <span className="mt-2.5 block text-[13px] font-semibold text-white">{r.label}</span>
            <span className="mt-0.5 block font-mono text-[7.5px] uppercase tracking-[0.18em] text-white/35 transition group-hover:text-white/60">
              {r.agent}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}