import { useState } from "react";
import { ArrowRight, ArrowLeft } from "lucide-react";

// ÉTAPE 2 — LES INFOS ESSENTIELLES : tout est masqué, un seul champ
// conversationnel au centre, une question à la fois.
const QUESTIONS = [
  { id: "nom", label: "Qui êtes-vous ?", hint: "Vos prénoms, votre nom ou votre marque — ex. Léa & Tom" },
  { id: "date", label: "Une date clé ?", hint: "Le mariage, l'événement, un lancement — ou « aucune »" },
  { id: "lieu", label: "Le lieu ?", hint: "La ville, le domaine, la région" },
  { id: "projet", label: "Décrivez le site que vous voulez", hint: "En une ou deux phrases — c'est votre Point Zéro" },
];

export default function FlowInfos({ role, onDone, onRetour }) {
  const [i, setI] = useState(0);
  const [reponses, setReponses] = useState({});
  const [valeur, setValeur] = useState("");
  const q = QUESTIONS[i];

  const valider = () => {
    if (!valeur.trim()) return;
    const maj = { ...reponses, [q.id]: valeur.trim() };
    setReponses(maj);
    setValeur("");
    if (i + 1 < QUESTIONS.length) setI(i + 1);
    else onDone(maj);
  };

  return (
    <div className="mx-auto w-full max-w-xl text-center">
      <p className="font-mono text-[9px] font-semibold uppercase tracking-[0.3em] text-white/40">
        {role.label} — étape 2/4 · question {i + 1}/{QUESTIONS.length}
      </p>
      <h2 className="mt-4 font-heading text-[28px] font-extrabold leading-tight text-white ripple-wave" key={q.id}>
        {q.label}
      </h2>
      <p className="mt-2 text-[12.5px] text-white/45">{q.hint}</p>

      <div className="mt-7 flex items-center gap-2">
        <input
          autoFocus
          value={valeur}
          onChange={(e) => setValeur(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter") valider(); }}
          placeholder="Votre réponse — Entrée pour continuer…"
          className="min-w-0 flex-1 rounded-xl bg-white/[0.06] px-4 py-3.5 text-center text-[14px] text-white placeholder:text-white/25 focus:bg-white/[0.1] focus:outline-none"
        />
        <button
          type="button"
          onClick={valider}
          disabled={!valeur.trim()}
          aria-label="Valider la réponse"
          className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-white text-black transition hover:bg-white/85 disabled:opacity-30"
        >
          <ArrowRight className="h-4 w-4" />
        </button>
      </div>

      <button
        type="button"
        onClick={() => (i > 0 ? setI(i - 1) : onRetour())}
        className="mt-6 inline-flex items-center gap-1.5 text-[11px] text-white/35 transition hover:text-white/70"
      >
        <ArrowLeft className="h-3 w-3" aria-hidden="true" /> Retour
      </button>
    </div>
  );
}