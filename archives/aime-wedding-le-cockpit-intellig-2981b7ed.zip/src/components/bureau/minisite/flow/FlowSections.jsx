import { useEffect, useState } from "react";
import { Check, Loader2, ArrowRight, ArrowLeft } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { FAMILLES, SECTIONS_UNIVERSELLES } from "@/lib/bureau/minisite/sectionsTaxonomie";

// ÉTAPE 3 — CE QU'ON VEUT DANS LE SITE : l'IA reconnaît le rôle + le projet
// et pré-coche ; on ajuste. Ces sections structureront l'article ET le site.
export default function FlowSections({ role, infos, coches, onChange, onDone, onRetour }) {
  const [analyse, setAnalyse] = useState(false);

  useEffect(() => {
    if (coches !== null || analyse) return;
    setAnalyse(true);
    base44.integrations.Core.InvokeLLM({
      prompt: `Rôle : ${role.label} (${role.focus}). Projet : ${infos.projet || "—"}. Nom : ${infos.nom || "—"}, date : ${infos.date || "—"}, lieu : ${infos.lieu || "—"}.
Parmi ces sections de mini-site, choisis les 6 à 10 PERTINENTES (ids exacts) : ${SECTIONS_UNIVERSELLES.map((s) => `${s.id} (${s.label})`).join(", ")}.`,
      response_json_schema: { type: "object", properties: { ids: { type: "array", items: { type: "string" } } } },
    })
      .then((res) => onChange((res.ids || []).filter((id) => SECTIONS_UNIVERSELLES.some((s) => s.id === id))))
      .finally(() => setAnalyse(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const liste = coches || [];
  const toggle = (id) => onChange(liste.includes(id) ? liste.filter((c) => c !== id) : [...liste, id]);

  return (
    <div className="mx-auto w-full max-w-3xl">
      <div className="text-center">
        <p className="font-mono text-[9px] font-semibold uppercase tracking-[0.3em] text-white/40">
          {role.label} — étape 3/4
        </p>
        <h2 className="mt-3 font-heading text-[28px] font-extrabold leading-tight text-white">Que voulez-vous dans le site ?</h2>
        <p className="mt-2 text-[12.5px] text-white/45">
          {analyse ? (
            <span className="inline-flex items-center gap-1.5"><Loader2 className="h-3 w-3 animate-spin" aria-hidden="true" /> Ripple reconnaît votre projet et pré-coche…</span>
          ) : (
            `${liste.length} section${liste.length > 1 ? "s" : ""} cochée${liste.length > 1 ? "s" : ""} — chacune vivra dans l'article et dans le site.`
          )}
        </p>
      </div>

      <div className="mt-7 space-y-3">
        {FAMILLES.map((fam) => (
          <div key={fam}>
            <p className="mb-1.5 font-mono text-[8px] font-semibold uppercase tracking-[0.24em] text-white/35">{fam}</p>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              {SECTIONS_UNIVERSELLES.filter((s) => s.famille === fam).map((s) => {
                const coche = liste.includes(s.id);
                return (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => toggle(s.id)}
                    aria-pressed={coche}
                    className={`relative rounded-lg border bg-[#FBFAF7] p-3 text-left transition ${
                      coche ? "border-white shadow-[0_0_0_1px_#fff]" : "border-white/15 opacity-55 hover:opacity-90"
                    }`}
                  >
                    <span className="block font-mono text-[7px] font-semibold uppercase tracking-[0.2em] text-black/40">{fam}</span>
                    <span className="mt-0.5 block truncate text-[15px] font-bold leading-tight text-black" style={{ fontFamily: "Georgia, 'Times New Roman', serif" }}>
                      {s.label}
                    </span>
                    <span className={`absolute right-2 top-2 grid h-[18px] w-[18px] place-items-center rounded-full border ${coche ? "border-black bg-black text-white" : "border-black/25 bg-white"}`} aria-hidden="true">
                      {coche && <Check className="h-3 w-3" />}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      <div className="mt-7 flex items-center justify-between">
        <button type="button" onClick={onRetour} className="inline-flex items-center gap-1.5 text-[11px] text-white/35 transition hover:text-white/70">
          <ArrowLeft className="h-3 w-3" aria-hidden="true" /> Retour
        </button>
        <button
          type="button"
          onClick={onDone}
          disabled={!liste.length}
          className="inline-flex items-center gap-1.5 rounded-full bg-white px-5 py-2.5 text-[12px] font-bold text-black transition hover:bg-white/85 disabled:opacity-30"
        >
          Générer l'article <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
        </button>
      </div>
    </div>
  );
}