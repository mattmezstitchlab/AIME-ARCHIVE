// LES RÉGLAGES DE L'ARTICLE — le design system réglé EN LISANT : typo,
// tailles, couleurs, fond, contraste (score AA/AAA en direct) et le format
// du visuel hero. Ces choix suivront le futur site.
export const FONDS = [
  { id: "blanc", label: "Blanc", bg: "#FFFFFF", texte: "#141414" },
  { id: "ivoire", label: "Ivoire", bg: "#F6F2E9", texte: "#1A1712" },
  { id: "noir", label: "Noir", bg: "#0E0E10", texte: "#F4F2EC" },
];
export const TYPOS = [
  { id: "serif", label: "Serif", font: "Georgia, 'Times New Roman', serif" },
  { id: "sans", label: "Sans", font: "'Inter', sans-serif" },
  { id: "mono", label: "Mono", font: "'JetBrains Mono', monospace" },
];
export const TAILLES = [
  { id: "s", label: "S", corps: 13, titre: 30 },
  { id: "m", label: "M", corps: 15, titre: 38 },
  { id: "l", label: "L", corps: 17, titre: 46 },
];
export const HEROS = ["Plein format", "Bandeau", "Petit format", "Sans visuel"];
export const ACCENTS = ["#C9A96E", "#8A9B7C", "#B0543F", "#3E6B8A", "#141414"];
export const BOUTONS = ["Pilule", "Carré", "Souligné"];

// Les classes/styles du bouton d'exemple selon le réglage choisi.
export const boutonClasses = (id) =>
  id === "Carré"
    ? { cls: "inline-block rounded-none px-5 py-2.5 text-[12px] font-semibold text-white transition hover:opacity-85", style: (accent) => ({ background: accent }) }
    : id === "Souligné"
    ? { cls: "inline-block rounded-none border-b-2 bg-transparent px-1 pb-1 text-[13px] font-semibold transition hover:opacity-70", style: (accent, fond) => ({ borderColor: accent, color: fond.texte }) }
    : { cls: "inline-block rounded-full px-5 py-2.5 text-[12px] font-semibold text-white transition hover:opacity-85", style: (accent) => ({ background: accent }) };

// Le contraste WCAG entre deux couleurs hex — le score s'affiche en direct.
const lum = (hex) => {
  const v = hex.replace("#", "");
  const [r, g, b] = [0, 2, 4].map((i) => {
    const c = parseInt(v.substr(i, 2), 16) / 255;
    return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
  });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
};
export const contraste = (a, b) => {
  const [l1, l2] = [lum(a), lum(b)].sort((x, y) => y - x);
  return (l1 + 0.05) / (l2 + 0.05);
};

const Ligne = ({ label, children }) => (
  <div className="flex flex-wrap items-center gap-1.5">
    <span className="w-16 shrink-0 font-mono text-[7.5px] font-semibold uppercase tracking-[0.2em] text-white/40">{label}</span>
    {children}
  </div>
);
const Chip = ({ actif, onClick, children }) => (
  <button type="button" onClick={onClick}
    className={`rounded-full px-2.5 py-1 text-[10px] font-semibold transition ${actif ? "bg-white text-black" : "bg-white/[0.07] text-white/55 hover:bg-white/15 hover:text-white"}`}>
    {children}
  </button>
);

export default function FlowArticleReglages({ reglages, onChange }) {
  const set = (patch) => onChange({ ...reglages, ...patch });
  const fond = FONDS.find((f) => f.id === reglages.fond) || FONDS[0];
  const ratio = contraste(fond.texte, fond.bg);
  const ratioAccent = contraste(reglages.accent, fond.bg);

  return (
    <div className="space-y-2 rounded-2xl border border-white/10 bg-white/[0.02] p-3.5">
      <p className="font-mono text-[8.5px] font-semibold uppercase tracking-[0.26em] text-white">
        Web design system · réglé en lisant — suivra votre site
      </p>
      <Ligne label="Typo">
        {TYPOS.map((t) => <Chip key={t.id} actif={reglages.typo === t.id} onClick={() => set({ typo: t.id })}>{t.label}</Chip>)}
      </Ligne>
      <Ligne label="Taille">
        {TAILLES.map((t) => <Chip key={t.id} actif={reglages.taille === t.id} onClick={() => set({ taille: t.id })}>{t.label}</Chip>)}
      </Ligne>
      <Ligne label="Fond">
        {FONDS.map((f) => <Chip key={f.id} actif={reglages.fond === f.id} onClick={() => set({ fond: f.id })}>{f.label}</Chip>)}
      </Ligne>
      <Ligne label="Accent">
        {ACCENTS.map((c) => (
          <button key={c} type="button" onClick={() => set({ accent: c })} aria-label={`Accent ${c}`}
            className={`h-[22px] w-[22px] rounded-full border-2 transition ${reglages.accent === c ? "scale-110 border-white" : "border-white/20 hover:border-white/60"}`}
            style={{ background: c }} />
        ))}
      </Ligne>
      <Ligne label="Boutons">
        {BOUTONS.map((b) => <Chip key={b} actif={reglages.bouton === b} onClick={() => set({ bouton: b })}>{b}</Chip>)}
      </Ligne>
      <Ligne label="Hero">
        {HEROS.map((h) => <Chip key={h} actif={reglages.hero === h} onClick={() => set({ hero: h })}>{h}</Chip>)}
      </Ligne>
      <Ligne label="Contraste">
        <span className={`rounded-full px-2 py-0.5 font-mono text-[9px] font-bold ${ratio >= 7 ? "bg-[#7FDCB2]/20 text-[#7FDCB2]" : ratio >= 4.5 ? "bg-[#E8C97F]/20 text-[#E8C97F]" : "bg-red-500/20 text-red-400"}`}>
          Texte {ratio.toFixed(1)}:1 · {ratio >= 7 ? "AAA" : ratio >= 4.5 ? "AA" : "Insuffisant"}
        </span>
        <span className={`rounded-full px-2 py-0.5 font-mono text-[9px] font-bold ${ratioAccent >= 4.5 ? "bg-[#7FDCB2]/20 text-[#7FDCB2]" : "bg-[#E8C97F]/20 text-[#E8C97F]"}`}>
          Accent {ratioAccent.toFixed(1)}:1
        </span>
      </Ligne>
    </div>
  );
}