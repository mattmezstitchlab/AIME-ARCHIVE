// LE RENDU DU MINI-SITE — une seule page verticale, comme un vrai site,
// habillée par le DESIGN SYSTEM choisi (couleurs, typos, boutons, compo)
// et par le template de chaque carte (hero, section, typo, couleur).
const Points = ({ points, accent, style, centre }) => (
  <ul className={`mt-4 space-y-2 ${centre ? "mx-auto w-fit text-left" : ""}`}>
    {(points || []).map((p, j) => (
      <li key={j} className="flex items-start gap-2.5 text-[12.5px] text-white/80" style={style}>
        <span className="mt-[7px] h-1.5 w-1.5 shrink-0 rounded-full" style={{ background: accent }} aria-hidden="true" />
        {p}
      </li>
    ))}
  </ul>
);

export default function MiniSiteRender({ project, site }) {
  const ds = site.ds || {};
  const dir = project.direction || {};
  const palette = ds.palette || dir.palette || [];
  const sombres = ["#0c0c0c", "#000000", "#ffffff", "#111111", "#f4f2ec", "#eef2ff", "#e8ede6", "#f6efe8"];
  const accent = palette.find((c) => !sombres.includes((c || "").toLowerCase())) || palette[1] || "#C9A96E";
  const facets = project.facets || [];
  const heroImg = facets.find((f) => f.image_url)?.image_url;
  const facetFor = (key) => facets.find((f) => f.key === key);
  const tplFor = (key) => project.facet_values?.[key]?._tpl || {};
  const hTypo = { fontFamily: `'${ds.typo_titres || dir.typo_titres || "Inter"}', Inter, serif` };
  const tTypo = { fontFamily: `'${ds.typo_texte || dir.typo_texte || "Inter"}', Inter, sans-serif` };
  const typoDe = (tpl) => (tpl.typo === "Serif" ? { fontFamily: "'Playfair Display', serif" } : tpl.typo === "Sans" ? { fontFamily: "'Inter', sans-serif" } : hTypo);

  // LE BOUTON du design system — pilule, carré ou souligné.
  const btnCls =
    ds.bouton === "carre"
      ? "inline-block rounded-none bg-white px-5 py-2.5 text-[12px] font-semibold text-black transition hover:bg-white/85"
      : ds.bouton === "souligne"
      ? "inline-block rounded-none border-b-2 bg-transparent px-1 pb-1 text-[13px] font-semibold text-white transition hover:opacity-70"
      : "inline-block rounded-full bg-white px-5 py-2.5 text-[12px] font-semibold text-black transition hover:bg-white/85";
  const btnStyle = ds.bouton === "souligne" ? { borderColor: accent } : undefined;
  const compo = ds.compo || "alterne";
  const premiereKey = site.sections?.[0]?.key;

  return (
    <article className="overflow-hidden rounded-2xl border border-white/12 bg-[#0D0D0F]">
      {/* LA NAV */}
      <nav className="flex flex-wrap items-center gap-x-5 gap-y-1 border-b border-white/8 px-6 py-3">
        <span className="text-[13px] font-bold text-white" style={hTypo}>{project.project_title || project.intent}</span>
        <span className="flex-1" />
        {(site.sections || []).map((s) => (
          <a key={s.key} href={`#ms-${s.key}`} className="font-mono text-[8.5px] font-semibold uppercase tracking-[0.18em] text-white/40 transition hover:text-white">
            {facetFor(s.key)?.label || s.titre}
          </a>
        ))}
      </nav>

      {/* LE HERO */}
      <header className="relative flex min-h-[380px] flex-col justify-end overflow-hidden p-8 sm:p-10">
        {heroImg ? (
          <img src={heroImg} alt="" className="absolute inset-0 h-full w-full object-cover" />
        ) : (
          <span className="absolute inset-0" style={{ background: `linear-gradient(160deg, ${accent}33 0%, #0b0b0d 70%)` }} aria-hidden="true" />
        )}
        <span className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/35 to-transparent" aria-hidden="true" />
        <div className="relative max-w-2xl">
          <p className="font-mono text-[9px] font-semibold uppercase tracking-[0.3em]" style={{ color: accent }}>{site.hero?.accroche}</p>
          <h2 className="mt-2 text-[38px] font-extrabold leading-[1.05] text-white sm:text-[48px]" style={hTypo}>{site.hero?.titre}</h2>
          <p className="mt-3 text-[14.5px] leading-relaxed text-white/70" style={tTypo}>{site.hero?.sous_titre}</p>
          {premiereKey && <a href={`#ms-${premiereKey}`} className={`mt-5 ${btnCls}`} style={btnStyle}>Découvrir</a>}
        </div>
      </header>

      {/* LES SECTIONS — la compo du design system, ajustée carte par carte */}
      {(site.sections || []).map((s, i) => {
        const facet = facetFor(s.key);
        const tpl = tplFor(s.key);
        const img = tpl.hero === "Minimal" ? null : s.image_url || facet?.image_url;
        const lien = s.lien ? (
          <a href={s.lien} target="_blank" rel="noreferrer" className={`mt-4 ${btnCls}`} style={btnStyle}>
            En savoir plus
          </a>
        ) : null;
        const acc = tpl.couleur || accent;
        const titreStyle = typoDe(tpl);
        const mode = tpl.section === "Bandeau" ? "editorial" : tpl.hero === "Visuel plein" ? "plein" : compo;
        const kicker = `${String(i + 1).padStart(2, "0")} · ${facet?.label || "Section"}`;

        if (mode === "plein") {
          return (
            <section key={s.key || i} id={`ms-${s.key}`} className="relative flex min-h-[380px] flex-col justify-end overflow-hidden border-t border-white/8 p-8 sm:p-12">
              {img ? <img src={img} alt="" className="absolute inset-0 h-full w-full object-cover" /> : <span className="absolute inset-0" style={{ background: `linear-gradient(160deg, ${acc}22 0%, #0b0b0d 75%)` }} aria-hidden="true" />}
              <span className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-black/10" aria-hidden="true" />
              <div className="relative max-w-2xl">
                <p className="font-mono text-[9px] font-semibold uppercase tracking-[0.28em]" style={{ color: acc }}>{kicker}</p>
                <h3 className="mt-2 text-[28px] font-bold leading-tight text-white" style={titreStyle}>{s.titre}</h3>
                <p className="mt-3 text-[13.5px] leading-relaxed text-white/70" style={tTypo}>{s.texte}</p>
                <Points points={s.points} accent={acc} style={tTypo} />
                {lien}
              </div>
            </section>
          );
        }

        if (mode === "editorial") {
          return (
            <section key={s.key || i} id={`ms-${s.key}`} className="border-t border-white/8">
              {img && <img src={img} alt="" className="h-44 w-full object-cover" />}
              <div className="mx-auto max-w-2xl p-8 text-center sm:p-10">
                <p className="font-mono text-[9px] font-semibold uppercase tracking-[0.28em]" style={{ color: acc }}>{kicker}</p>
                <h3 className="mt-2 text-[26px] font-bold leading-tight text-white" style={titreStyle}>{s.titre}</h3>
                <p className="mt-3 text-[13.5px] leading-relaxed text-white/65" style={tTypo}>{s.texte}</p>
                <Points points={s.points} accent={acc} style={tTypo} centre />
                {lien}
              </div>
            </section>
          );
        }

        const pair = i % 2 === 1;
        return (
          <section key={s.key || i} id={`ms-${s.key}`} className="grid border-t border-white/8 md:grid-cols-2">
            <div className={`relative min-h-[260px] ${pair ? "md:order-2" : ""}`}>
              {img ? <img src={img} alt="" className="absolute inset-0 h-full w-full object-cover" /> : <span className="absolute inset-0" style={{ background: `linear-gradient(160deg, ${acc}22 0%, #0b0b0d 75%)` }} aria-hidden="true" />}
            </div>
            <div className="flex flex-col justify-center p-8 sm:p-10">
              <p className="font-mono text-[9px] font-semibold uppercase tracking-[0.28em]" style={{ color: acc }}>{kicker}</p>
              <h3 className="mt-2 text-[26px] font-bold leading-tight text-white" style={titreStyle}>{s.titre}</h3>
              <p className="mt-3 text-[13.5px] leading-relaxed text-white/65" style={tTypo}>{s.texte}</p>
              <Points points={s.points} accent={acc} style={tTypo} />
              {lien}
            </div>
          </section>
        );
      })}

      {/* LE PIED DE PAGE */}
      <footer className="border-t border-white/8 p-10 text-center">
        <div className="mx-auto mb-4 flex w-fit gap-1.5">
          {palette.slice(0, 5).map((c, i) => (
            <span key={i} className="h-3 w-3 rounded-full border border-white/15" style={{ background: c }} title={c} />
          ))}
        </div>
        <p className="mx-auto max-w-xl text-[14px] leading-relaxed text-white/60" style={tTypo}>{site.pied}</p>
        <a href="#" className={`mt-5 ${btnCls}`} style={btnStyle} onClick={(e) => e.preventDefault()}>Nous contacter</a>
        <p className="mt-4 font-mono text-[8.5px] font-semibold uppercase tracking-[0.28em] text-white/30">
          {project.project_title || project.intent} · Mini-site AIME®
        </p>
      </footer>
    </article>
  );
}