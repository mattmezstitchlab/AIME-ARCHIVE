// LE DESIGN SYSTEM — juste avant de générer : on choisit les couleurs, les
// typos, le style de bouton et la composition de page. Tout le mini-site
// sera généré nickel avec ces choix.
const PALETTES = [
  { nom: "Encre & Sable", colors: ["#0C0C0C", "#C9A96E", "#F4F2EC"] },
  { nom: "Forêt", colors: ["#0E1512", "#5B8A68", "#E8EDE6"] },
  { nom: "Nuit électrique", colors: ["#0A0E1E", "#38BDF8", "#EEF2FF"] },
  { nom: "Terracotta", colors: ["#161210", "#D07B4F", "#F6EFE8"] },
];
const TYPOS = [
  { nom: "Éditorial", titres: "Playfair Display", texte: "Montserrat" },
  { nom: "Studio", titres: "Inter", texte: "Inter" },
  { nom: "Moderne", titres: "Space Grotesk", texte: "Inter" },
];
const BOUTONS = [
  { id: "pilule", nom: "Pilule" },
  { id: "carre", nom: "Carré" },
  { id: "souligne", nom: "Souligné" },
];
const COMPOS = [
  { id: "alterne", nom: "Alterné", desc: "visuel / texte en quinconce" },
  { id: "plein", nom: "Plein écran", desc: "sections immersives" },
  { id: "editorial", nom: "Éditorial", desc: "bandeaux + texte centré" },
];

const Ligne = ({ label, children }) => (
  <div className="flex flex-wrap items-center gap-2">
    <span className="w-20 shrink-0 font-mono text-[8.5px] font-semibold uppercase tracking-[0.22em] text-white/40">{label}</span>
    {children}
  </div>
);

const Chip = ({ actif, onClick, children }) => (
  <button
    type="button"
    onClick={onClick}
    className={`rounded-full px-3 py-1.5 text-[11px] font-medium transition ${
      actif ? "bg-white text-black" : "bg-white/[0.06] text-white/60 hover:bg-white/[0.12] hover:text-white"
    }`}
  >
    {children}
  </button>
);

export default function MiniSiteDesignSystem({ direction, ds, onChange }) {
  const set = (patch) => onChange({ ...ds, ...patch });
  const palettes = direction?.palette?.length ? [{ nom: "Direction du projet", colors: direction.palette }, ...PALETTES] : PALETTES;

  return (
    <div className="space-y-2.5 rounded-2xl border border-white/10 bg-white/[0.02] p-4">
      <p className="font-mono text-[9px] font-semibold uppercase tracking-[0.26em] text-white">
        Design system · tout sera généré avec ces choix
      </p>

      <Ligne label="Couleurs">
        {palettes.map((p) => (
          <button
            key={p.nom}
            type="button"
            onClick={() => set({ palette: p.colors })}
            title={p.nom}
            className={`flex items-center gap-1 rounded-full border px-2 py-1.5 transition ${
              JSON.stringify(ds.palette) === JSON.stringify(p.colors) ? "border-white bg-white/10" : "border-white/10 hover:border-white/40"
            }`}
          >
            {p.colors.map((c, i) => (
              <span key={i} className="h-3.5 w-3.5 rounded-full border border-white/15" style={{ background: c }} />
            ))}
          </button>
        ))}
      </Ligne>

      <Ligne label="Typos">
        {TYPOS.map((t) => (
          <Chip key={t.nom} actif={ds.typo_titres === t.titres && ds.typo_texte === t.texte} onClick={() => set({ typo_titres: t.titres, typo_texte: t.texte })}>
            {t.nom} — {t.titres}
          </Chip>
        ))}
      </Ligne>

      <Ligne label="Boutons">
        {BOUTONS.map((b) => (
          <Chip key={b.id} actif={ds.bouton === b.id} onClick={() => set({ bouton: b.id })}>
            {b.nom}
          </Chip>
        ))}
      </Ligne>

      <Ligne label="Compo">
        {COMPOS.map((c) => (
          <Chip key={c.id} actif={ds.compo === c.id} onClick={() => set({ compo: c.id })}>
            {c.nom} · {c.desc}
          </Chip>
        ))}
      </Ligne>
    </div>
  );
}