import { useState, useEffect } from "react";
import { FolderTree, X, List, LayoutGrid } from "lucide-react";
import BureauArbre from "@/components/bureau/BureauArbre";
import BureauArbreVisuel from "@/components/bureau/arbre/BureauArbreVisuel";
import BibliothequesSections from "@/components/bureau/BibliothequesSections";

const MODE_KEY = "aime-arbre-mode-v1";

// L'arbre des dossiers en panneau latéral GAUCHE — AI (Architecture
// Intelligente). L'encoche n'apparaît qu'en projet (showNotch), mais le
// bouton AI du header l'ouvre toujours via l'événement « aime-panel-ai ».
export default function BureauTreeDrawer({ nodes, pulsing, showNotch = true }) {
  const [open, setOpen] = useState(false);
  // Deux modes : « texte » (l'arbre classique) et « visuel » (tuiles iOS retournables).
  const [mode, setMode] = useState(() => localStorage.getItem(MODE_KEY) || "texte");
  const changerMode = (m) => {
    setMode(m);
    try { localStorage.setItem(MODE_KEY, m); } catch { /* ignore */ }
  };

  useEffect(() => {
    const h = () => setOpen((o) => !o);
    window.addEventListener("aime-panel-ai", h);
    return () => window.removeEventListener("aime-panel-ai", h);
  }, []);

  if (!open) {
    if (!showNotch) return null;
    return (
      <button
        type="button"
        onClick={() => setOpen(true)}
        aria-label="Déplier l'arbre des dossiers"
        className="fixed left-0 top-1/2 z-[60] -translate-y-1/2 rounded-r-xl bg-black/80 py-4 pl-2 pr-2.5 text-white shadow-lg backdrop-blur transition-transform hover:translate-x-0.5"
      >
        <span className="flex flex-col items-center gap-2">
          <FolderTree className="h-4 w-4 text-[#c9a96e]" strokeWidth={1.6} />
          <span
            className="text-[10px] font-semibold uppercase tracking-[0.2em] text-white/80"
            style={{ writingMode: "vertical-rl" }}
          >
            Dossiers
          </span>
        </span>
      </button>
    );
  }

  return (
    <aside
      className={`fixed bottom-0 left-0 top-16 z-[60] w-[300px] overflow-y-auto scrollbar-hide border-r border-white/10 bg-[#0C0C0C]/95 p-4 backdrop-blur-md ${
        pulsing ? "mariage-ripple-pulse" : ""
      }`}
      aria-label="Arbre des dossiers"
    >
      <div className="mb-3 flex items-center justify-between">
        <p className="inline-flex items-center gap-2 font-mono text-[10px] font-semibold uppercase tracking-[0.24em] text-white/40">
          <FolderTree className="h-3.5 w-3.5 text-[#c9a96e]" /> Dossiers
        </p>
        <div className="flex items-center gap-1">
          {/* La bascule Texte / Visuel de l'arbre. */}
          <button
            type="button"
            onClick={() => changerMode("texte")}
            aria-label="Mode texte"
            aria-pressed={mode === "texte"}
            className={`rounded-md p-1.5 transition-colors ${mode === "texte" ? "bg-white/15 text-white" : "text-white/35 hover:text-white"}`}
          >
            <List className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={() => changerMode("visuel")}
            aria-label="Mode visuel"
            aria-pressed={mode === "visuel"}
            className={`rounded-md p-1.5 transition-colors ${mode === "visuel" ? "bg-white/15 text-white" : "text-white/35 hover:text-white"}`}
          >
            <LayoutGrid className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={() => setOpen(false)}
            aria-label="Replier l'arbre des dossiers"
            className="rounded-full p-1.5 text-white/40 hover:bg-white/10 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>
      {mode === "visuel" ? <BureauArbreVisuel nodes={nodes} /> : <BureauArbre nodes={nodes} />}
      {/* Les bibliothèques fusionnées : l'absorbé réutilisable, sans doublon. */}
      <BibliothequesSections />
    </aside>
  );
}