import { Link } from "react-router-dom";

const slides = [
  { name: "Photographes", slug: "photographes", image: "https://images.unsplash.com/photo-1542038784456-1ea8e935640e?w=400&q=80" },
  { name: "Tatoueurs", slug: "tatoueurs", image: "https://images.unsplash.com/photo-1611501275019-9b5cda994e8d?w=400&q=80" },
  { name: "Peintres", slug: "peintres", image: "https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?w=400&q=80" },
  { name: "Maquilleurs", slug: "maquilleurs", image: "https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=400&q=80" },
  { name: "Musiciens", slug: "musiciens", image: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=400&q=80" },
  { name: "Illustrateurs", slug: "illustrateurs", image: "https://images.unsplash.com/photo-1452860606245-08befc0ff44b?w=400&q=80" },
];

export default function HeroCategorySlider() {
  return (
    <section className="py-8 bg-background border-b border-border">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex gap-4 overflow-x-auto scrollbar-hide pb-2">
          {slides.map((slide) => (
            <Link
              key={slide.slug}
              to={`/${slide.slug}`}
              className="group shrink-0 w-[160px] sm:w-[200px]"
            >
              <div className="aspect-[4/3] overflow-hidden rounded-lg mb-2 bg-muted relative">
                <img
                  src={slide.image}
                  alt={slide.name}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors" />
              </div>
              <p className="text-sm font-medium text-foreground text-center group-hover:underline underline-offset-4">
                {slide.name}
              </p>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}