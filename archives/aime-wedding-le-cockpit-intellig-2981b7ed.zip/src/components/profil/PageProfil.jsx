import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Pencil, Check, Crop, LayoutGrid, Image as ImageIcon, UserRound, CalendarClock, IdCard } from "lucide-react";
import TimelineUniverselle from "@/components/timeline/TimelineUniverselle";
import { collectEvents } from "@/lib/timeline/collectEvents";
import BlocEditable from "@/components/registre/BlocEditable";
import PhotoRecadrage from "@/components/registre/PhotoRecadrage";
import ModulesPro from "@/components/registre/ModulesPro";
import ModeCartes from "@/components/registre/ModeCartes";
import PanneauReglagesBloc from "@/components/registre/PanneauReglagesBloc";
import { MODULES_PRO } from "@/lib/registre/pageBlocs";
import { loadReglages, saveReglages } from "@/lib/registre/pageReglages";

// ─────────────────────────────────────────────────────────────────────────
// LA PAGE PROFIL UNIVERSELLE — LA source de vérité du Registre, en 3 modes :
// · APERÇU — la page publique (les blocs masqués n'existent pas).
// · MODIFIER — le voile à points, blocs cerclés de bleu, photo recadrable,
//   modules activables, VRAIS réglages du bloc sélectionné à droite.
// · CARTES — la page dézoomée : chaque bloc devient une carte retournable.
// Utilisée par le Registre (cartes métier) ET par Mon compte (votre page).
// ─────────────────────────────────────────────────────────────────────────
export default function PageProfil({ personne, backTo = "/registre", backLabel = "Retour" }) {
  const [events, setEvents] = useState([]);
  const [mode, setMode] = useState("apercu"); // apercu | modifier | cartes
  const [recadrer, setRecadrer] = useState(false);
  const [reglages, setReglages] = useState(() => loadReglages(personne.slug));
  const [selection, setSelection] = useState(null);
  const editing = mode === "modifier";

  useEffect(() => {
    const recharger = () => collectEvents().then(setEvents);
    recharger();
    // La Transmission écrit sur la timeline : on la recharge en direct.
    window.addEventListener("aime-transmission-maj", recharger);
    return () => window.removeEventListener("aime-transmission-maj", recharger);
  }, []);

  useEffect(() => {
    setReglages(loadReglages(personne.slug));
  }, [personne.slug]);

  const maj = (r) => {
    setReglages(r);
    saveReglages(personne.slug, r);
  };
  const vis = reglages.vis || {};
  const estVisible = (id, defaut = true) => vis[id] ?? defaut;
  const toggleVis = (id, defaut = true) => maj({ ...reglages, vis: { ...vis, [id]: !estVisible(id, defaut) } });
  const cadrage = reglages.cadrage || { x: 50, y: 50, zoom: 100 };
  const onChangeAdmin = (modId, champId, v) =>
    maj({
      ...reglages,
      admin: { ...(reglages.admin || {}), [modId]: { ...(reglages.admin?.[modId] || {}), [champId]: v } },
    });

  // LES RÉGLAGES CAUSAUX — le verso des cartes et la colonne de droite
  // partagent les mêmes valeurs, et elles pilotent la page en direct.
  const admin = reglages.admin || {};
  const nomAffiche = admin.profil?.nom_affiche || personne.label;
  const groupAffiche = admin.profil?.titre_metier || personne.group;
  const essenceAffichee = admin.profil?.essence || personne.essence;

  // Le portrait : Unsplash optimisé, sinon l'URL importée telle quelle.
  const portraitSrc = personne.portrait?.includes("images.unsplash.com")
    ? `${personne.portrait}?q=80&w=1600&auto=format&fit=crop`
    : personne.portrait;

  const cartes = [
    { id: "photo", label: "Photo", icon: ImageIcon, visible: true, fixe: true },
    { id: "profil", label: "Profil", icon: UserRound, visible: estVisible("profil"), defaut: true },
    { id: "carte", label: "Carte Registre", icon: IdCard, visible: estVisible("carte"), defaut: true },
    { id: "timeline", label: "Timeline", icon: CalendarClock, visible: estVisible("timeline"), defaut: true },
    ...MODULES_PRO.map((m) => ({ id: m.id, label: m.label, icon: m.icon, visible: estVisible(m.id, false), defaut: false })),
  ];

  const MODES = [
    { id: "apercu", label: "Aperçu", icon: Check },
    { id: "modifier", label: "Modifier", icon: Pencil },
    { id: "cartes", label: "Cartes", icon: LayoutGrid },
  ];

  return (
    <div className="relative min-h-screen bg-[#050505] text-white">
      {/* Plus de photo en fond : la photo vit dans la Carte Registre, c'est assez. */}

      {/* LE VOILE — glassmorphism noir + trame de points (Modifier & Cartes). */}
      {mode !== "apercu" && (
        <div className="dot-grid-dark fixed inset-0 z-20 bg-black/55 backdrop-blur-[2px]" aria-hidden="true" />
      )}

      <div className={`relative mx-auto max-w-5xl px-6 pb-24 pt-24 ${mode !== "apercu" ? "z-30" : ""}`}>
        {/* La nav de la page — retour + sections + les 3 modes */}
        <nav className="inline-flex flex-wrap items-center gap-1 rounded-lg bg-black/85 p-1.5 backdrop-blur" aria-label="Navigation de la page profil">
          <Link
            to={backTo}
            className="inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-[12px] font-medium text-white/85 transition hover:bg-white/10"
          >
            <ArrowLeft className="h-3.5 w-3.5" /> {backLabel}
          </Link>
          <a href="#profil" className="rounded-md px-3 py-1.5 font-mono text-[11px] text-white/60 transition hover:bg-white/10 hover:text-white">
            Profil
          </a>
          <a href="#timeline" className="rounded-md px-3 py-1.5 font-mono text-[11px] text-white/60 transition hover:bg-white/10 hover:text-white">
            Timeline
          </a>
          <span className="mx-1 h-4 w-px bg-white/15" aria-hidden="true" />
          {MODES.map((m) => (
            <button
              key={m.id}
              type="button"
              onClick={() => { setMode(m.id); setRecadrer(false); setSelection(null); }}
              aria-pressed={mode === m.id}
              className={`inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 font-mono text-[11px] font-semibold uppercase tracking-[0.12em] transition ${
                mode === m.id ? "bg-[#38bdf8] text-black" : "text-white/60 hover:bg-white/10 hover:text-white"
              }`}
            >
              <m.icon className="h-3 w-3" /> {m.label}
            </button>
          ))}
        </nav>

        {/* En mode Modifier : le recadrage manuel de la photo du hero. */}
        {editing && (
          <div className="mt-4">
            <button
              type="button"
              onClick={() => setRecadrer((r) => !r)}
              aria-expanded={recadrer}
              className="inline-flex items-center gap-1.5 rounded-lg border border-[#38bdf8]/60 bg-black/70 px-3 py-1.5 font-mono text-[10.5px] font-semibold uppercase tracking-[0.14em] text-[#38bdf8] backdrop-blur transition hover:bg-[#38bdf8]/15"
            >
              <Crop className="h-3.5 w-3.5" /> Recadrer la photo
            </button>
            {recadrer && (
              <PhotoRecadrage
                cadrage={cadrage}
                onChange={(c) => maj({ ...reglages, cadrage: c })}
                onClose={() => setRecadrer(false)}
              />
            )}
          </div>
        )}

        {/* MODE CARTES — la page dézoomée en cartes retournables. */}
        {mode === "cartes" && (
          <ModeCartes cartes={cartes} onToggle={toggleVis} valeurs={admin} onChange={onChangeAdmin} />
        )}

        {/* MODES APERÇU & MODIFIER — la page elle-même. */}
        {mode !== "cartes" && (
          <div className={editing ? "lg:grid lg:grid-cols-[1fr_340px] lg:items-start lg:gap-6" : ""}>
          <div className="min-w-0">
            {/* Le profil — bloc éditable */}
            <div id="profil" className="mt-12 scroll-mt-24">
              <BlocEditable
                label="Profil"
                editing={editing}
                cache={!estVisible("profil")}
                onToggle={() => toggleVis("profil")}
                selected={selection === "profil"}
                onSelect={() => setSelection("profil")}
              >
                <p className="font-mono text-[10px] font-semibold uppercase tracking-[0.24em] text-white/50">{groupAffiche}</p>
                <h1 className="mt-4 font-heading text-5xl tracking-[-0.03em] sm:text-7xl">{nomAffiche}</h1>
                {essenceAffichee && (
                  <p className="mt-6 max-w-xl text-[15px] leading-relaxed text-white/65">{essenceAffichee}</p>
                )}
              </BlocEditable>
            </div>

            {/* MA CARTE AU REGISTRE — l'aperçu exact de la carte dans la grille. */}
            <div className="mt-28">
              <BlocEditable
                label="Carte Registre"
                editing={editing}
                cache={!estVisible("carte")}
                onToggle={() => toggleVis("carte")}
                selected={selection === "carte"}
                onSelect={() => setSelection("carte")}
              >
                <p className="font-mono text-[10px] font-semibold uppercase tracking-[0.25em] text-white/45">Ma carte au Registre</p>
                <div className="mt-6 flex items-end gap-5">
                  <div className="w-44 shrink-0 overflow-hidden rounded-xl border border-white/12 bg-white/[0.03]">
                    <div className="aspect-[3/4] overflow-hidden">
                      {portraitSrc ? (
                        <img
                          src={portraitSrc}
                          alt=""
                          className="h-full w-full object-cover"
                          style={{ objectPosition: `${cadrage.x}% ${cadrage.y}%` }}
                        />
                      ) : (
                        <div className="flex h-full items-center justify-center font-mono text-[9px] uppercase tracking-[0.16em] text-white/30">
                          Photo à importer
                        </div>
                      )}
                    </div>
                    <div className="px-3 py-2.5">
                      <p className="text-[13px] font-semibold text-white/95">{nomAffiche}</p>
                      <p className="font-mono text-[8.5px] uppercase tracking-[0.16em] text-white/40">{admin.carte?.libelle || groupAffiche}</p>
                    </div>
                  </div>
                  {editing && (
                    <p className="max-w-xs text-[12.5px] leading-relaxed text-white/50">
                      C'est cette carte que les autres voient dans le Registre — le recadrage la règle en direct.
                    </p>
                  )}
                </div>
              </BlocEditable>
            </div>

            {/* La timeline — bloc éditable */}
            <section id="timeline" className="mt-28 scroll-mt-24">
              <BlocEditable
                label="Timeline"
                editing={editing}
                cache={!estVisible("timeline")}
                onToggle={() => toggleVis("timeline")}
                selected={selection === "timeline"}
                onSelect={() => setSelection("timeline")}
              >
                <p className="font-mono text-[10px] font-semibold uppercase tracking-[0.25em] text-white/45">La timeline</p>
                <h2 className="mt-3 font-heading text-2xl tracking-[-0.02em]">{admin.timeline?.titre || "Le temps, source de vérité."}</h2>
                <div className="mt-8">
                  <TimelineUniverselle events={events} />
                </div>
              </BlocEditable>
            </section>

            {/* LES MODULES PRO — livrés d'office, masqués par défaut, activables. */}
            <ModulesPro
              editing={editing}
              estVisible={estVisible}
              onToggle={toggleVis}
              selection={selection}
              onSelect={setSelection}
            />
          </div>

          {/* LA COLONNE DE DROITE — les vrais réglages du bloc sélectionné. */}
          {editing && (
            <aside className="mt-10 lg:sticky lg:top-20 lg:mt-24 lg:max-h-[calc(100vh-6rem)] lg:overflow-y-auto">
              <PanneauReglagesBloc selection={selection} valeurs={reglages.admin || {}} onChange={onChangeAdmin} />
            </aside>
          )}
          </div>
        )}
      </div>
    </div>
  );
}