import { useState } from "react";
import { Loader2, Upload } from "lucide-react";
import { base44 } from "@/api/base44Client";

const COULEURS = ["#F2A7C3", "#C9A96E", "#7FDCB2", "#7FC3F0", "#C9A2F5", "#E8C97F"];

// CRÉER MON PROFIL — l'entrée UNIQUE : la carte naît ici, en une minute,
// et devient la page profil du Registre.
export default function CreerProfilForm({ onCree }) {
  const [nom, setNom] = useState("");
  const [role, setRole] = useState("");
  const [essence, setEssence] = useState("");
  const [couleur, setCouleur] = useState(COULEURS[1]);
  const [photo, setPhoto] = useState("");
  const [envoi, setEnvoi] = useState(false);
  const [busy, setBusy] = useState(false);

  const uploader = async (file) => {
    if (!file) return;
    setEnvoi(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setPhoto(file_url);
    setEnvoi(false);
  };

  const creer = async (e) => {
    e.preventDefault();
    if (!nom.trim() || busy) return;
    setBusy(true);
    const card = await base44.entities.PersonCard.create({
      display_name: nom.trim(),
      role: role.trim(),
      essence: essence.trim(),
      color: couleur,
      photo_url: photo,
    });
    onCree(card);
  };

  const champ = "w-full rounded-xl border border-white/12 bg-white/[0.04] px-3.5 py-2.5 text-[13px] text-white placeholder:text-white/30 focus:border-white/40 focus:outline-none";

  return (
    <form onSubmit={creer} className="rounded-2xl border border-white/12 bg-white/[0.02] p-6">
      <div className="space-y-2.5">
        <input value={nom} onChange={(e) => setNom(e.target.value)} placeholder="Votre nom — affiché sur la carte" required aria-label="Votre nom" className={champ} />
        <input value={role} onChange={(e) => setRole(e.target.value)} placeholder="Votre rôle — ex. Marié·e, Photographe, Témoin…" aria-label="Votre rôle" className={champ} />
        <textarea value={essence} onChange={(e) => setEssence(e.target.value)} rows={2} placeholder="Votre phrase d'essence — ce que vous faites, ce que vous apportez" aria-label="Votre phrase d'essence" className={`${champ} resize-none`} />
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-4">
        <div className="flex items-center gap-1.5" role="group" aria-label="Couleur d'accent">
          {COULEURS.map((c) => (
            <button key={c} type="button" onClick={() => setCouleur(c)} aria-label={`Couleur ${c}`}
              className={`h-6 w-6 rounded-full border-2 transition ${couleur === c ? "border-white" : "border-transparent hover:border-white/50"}`}
              style={{ background: c }} />
          ))}
        </div>
        <label className="inline-flex cursor-pointer items-center gap-2 rounded-full border border-white/20 px-3.5 py-1.5 text-[11.5px] font-semibold text-white/70 transition hover:bg-white/10 hover:text-white">
          {envoi ? <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" /> : <Upload className="h-3.5 w-3.5" aria-hidden="true" />}
          {photo ? "Photo ajoutée ✓" : "Ajouter une photo"}
          <input type="file" accept="image/*" className="hidden" onChange={(e) => uploader(e.target.files?.[0])} />
        </label>
      </div>

      <button type="submit" disabled={busy || envoi || !nom.trim()}
        className="mt-5 inline-flex items-center gap-2 rounded-full bg-white px-5 py-2 text-[12.5px] font-bold text-black transition hover:bg-white/85 disabled:opacity-40">
        {busy && <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />}
        Créer ma carte profil
      </button>
      <p className="mt-3 text-[10.5px] leading-relaxed text-white/35">
        Votre carte apparaît au Registre et devient votre page profil — vos mini-sites publiés s'y rattachent automatiquement.
      </p>
    </form>
  );
}