import { useState } from "react";
import MeGraduation from "@/components/me/MeGraduation";

// ─────────────────────────────────────────────────────────────────────────
// LA TIMELINE UNIVERSELLE — un seul moteur, plusieurs focales.
// Le temps est la source de vérité : on regarde les MÊMES événements
// en années, mois, jours ou heures. Les événements viennent du
// collecteur temporel (collectEvents) — jamais de données dupliquées.
// ─────────────────────────────────────────────────────────────────────────

const ZOOMS = [
  { id: "annee", label: "Années", key: (d) => String(d.getFullYear()) },
  { id: "mois", label: "Mois", key: (d) => d.toLocaleDateString("fr-FR", { month: "long", year: "numeric" }) },
  { id: "jour", label: "Jours", key: (d) => d.toLocaleDateString("fr-FR", { day: "numeric", month: "short", year: "numeric" }) },
  { id: "heure", label: "Heures", key: (d) => `${d.toLocaleDateString("fr-FR", { day: "numeric", month: "short" })} · ${d.getHours()}h` },
];

export default function TimelineUniverselle({ events = [] }) {
  const [zoom, setZoom] = useState("annee");
  const z = ZOOMS.find((x) => x.id === zoom);

  const buckets = [];
  for (const e of events) {
    const k = z.key(new Date(e.date));
    let b = buckets.find((x) => x.k === k);
    if (!b) {
      b = { k, events: [] };
      buckets.push(b);
    }
    b.events.push(e);
  }

  return (
    <div>
      {/* LA GRADUATION DES 1024 — la même frise des vérités, greffée à la timeline unique. */}
      <div className="relative mb-4 h-8 rounded-lg border border-white/10 bg-black/40">
        {/* Couche personnelle : la graduation sans les bulles des vérités historiques. */}
        <MeGraduation bulle={false} />
      </div>

      {/* Les focales — année, mois, jour, heure : le même temps, zoomé */}
      <div className="flex flex-wrap gap-1.5" role="tablist" aria-label="Focale de la timeline">
        {ZOOMS.map((x) => (
          <button
            key={x.id}
            type="button"
            role="tab"
            aria-selected={x.id === zoom}
            onClick={() => setZoom(x.id)}
            className={`rounded-full border px-3 py-1 font-mono text-[10px] font-semibold uppercase tracking-[0.14em] transition ${
              x.id === zoom ? "border-[#c9a96e] bg-[#c9a96e]/15 text-white" : "border-white/15 text-white/50 hover:text-white"
            }`}
          >
            {x.label}
          </button>
        ))}
      </div>

      {/* Le rail — les moments, dans l'ordre du temps */}
      {buckets.length === 0 ? (
        <p className="mt-6 rounded-xl border border-dashed border-white/15 p-6 text-center text-[12.5px] text-white/45">
          La timeline s'écrira toute seule : chaque date réglée sur une carte, chaque projet créé apparaîtra ici.
        </p>
      ) : (
        <div className="scrollbar-hide mt-5 flex gap-6 overflow-x-auto pb-3">
          {buckets.map((b) => (
            <div key={b.k} className="min-w-[220px] shrink-0">
              <p className="font-mono text-[10px] font-semibold uppercase tracking-[0.2em] text-[#c9a96e]">{b.k}</p>
              <div className="mt-2 space-y-2 border-l border-white/12 pl-3">
                {b.events.map((e, i) => (
                  // Le moment ne redirige plus : il se lit ici, dans la timeline.
                  <div key={i} className="rounded-lg bg-white/[0.04] p-2.5">
                    <p className="flex items-center gap-1.5 text-[12px] font-medium text-white/90">
                      <span className="h-1.5 w-1.5 shrink-0 rounded-full" style={{ background: e.color || "#c9a96e" }} />
                      {e.label}
                    </p>
                    {e.detail && <p className="mt-0.5 pl-3 text-[10.5px] text-white/45">{e.detail}</p>}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}