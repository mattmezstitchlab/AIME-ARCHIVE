
  # Wedding Orbit Prototype

  This is a code bundle for Wedding Orbit Prototype. The original project is available at https://www.figma.com/design/ZN0NR2HwfoPDeIRIOqjAXD/Wedding-Orbit-Prototype.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  