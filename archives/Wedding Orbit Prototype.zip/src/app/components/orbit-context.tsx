import React, { createContext, useContext, useState, useCallback, useRef } from 'react';

export type ObjectType = 'moment' | 'document' | 'decision' | 'calendar' | 'message' | 'budget' | 'provider' | 'guest';
export type ObjectState = 'todo' | 'active' | 'done' | 'blocked' | 'incident';

export interface OrbitObject {
  id: string;
  type: ObjectType;
  state: ObjectState;
  title: string;
  owner: string;
  dueDate: string;
  dependencies: string[];
  triggers: string[];
  payload: Record<string, any>;
  orbitRing: number; // 0=inner, 1=mid, 2=outer
  angle: number; // radians
  description?: string;
  action?: string;
  choices?: string[];
}

export interface Handshake {
  id: string;
  fromId: string;
  toId: string;
  type: string;
  active: boolean;
  timestamp: number;
}

export interface OrbitContextType {
  objects: OrbitObject[];
  handshakes: Handshake[];
  serenity: number;
  dayJMode: boolean;
  bubbleSilence: boolean;
  nextAction: OrbitObject | null;
  selectedObject: OrbitObject | null;
  setSelectedObject: (obj: OrbitObject | null) => void;
  addObject: (obj: OrbitObject) => void;
  updateObject: (id: string, updates: Partial<OrbitObject>) => void;
  removeObject: (id: string) => void;
  answerQuestion: (objectId: string, choice: string) => void;
  addProvider: () => void;
  addGuests: () => void;
  generateDocument: () => void;
  blockCalendar: () => void;
  simulateDelay: () => void;
  activateBubbleSilence: () => void;
  toggleDayJ: () => void;
  triggerHandshake: (fromId: string, toId: string, type: string) => void;
  animatingTransfer: { fromId: string; toId: string } | null;
  planB: string | null;
  clearPlanB: () => void;
}

const OrbitContext = createContext<OrbitContextType | null>(null);

const INITIAL_OBJECTS: OrbitObject[] = [
  {
    id: 'moment-ceremony',
    type: 'moment',
    state: 'active',
    title: 'Cérémonie',
    owner: 'mariés',
    dueDate: '2026-09-15',
    dependencies: ['decision-lieu'],
    triggers: ['message-invites'],
    payload: { guests: 120, time: '15:00' },
    orbitRing: 0,
    angle: 0,
    description: 'La cérémonie principale du mariage',
    action: 'Choisir le type de cérémonie',
    choices: ['Religieuse', 'Laïque', 'Civile uniquement'],
  },
  {
    id: 'decision-lieu',
    type: 'decision',
    state: 'todo',
    title: 'Lieu de réception',
    owner: 'mariés',
    dueDate: '2026-03-01',
    dependencies: [],
    triggers: ['provider-traiteur', 'calendar-venue'],
    payload: { budget: 8000 },
    orbitRing: 1,
    angle: Math.PI * 0.4,
    description: 'Choisir et réserver le lieu de réception',
    action: 'Quel style de lieu ?',
    choices: ['Château / Domaine', 'Restaurant privé', 'Plein air / Jardin'],
  },
  {
    id: 'budget-global',
    type: 'budget',
    state: 'active',
    title: 'Budget Global',
    owner: 'mariés',
    dueDate: '2026-09-15',
    dependencies: [],
    triggers: [],
    payload: { total: 25000, spent: 3200, remaining: 21800 },
    orbitRing: 2,
    angle: Math.PI * 0.8,
    description: 'Suivi du budget total du mariage',
    action: 'Vérifier la répartition du budget',
  },
  {
    id: 'provider-photo',
    type: 'provider',
    state: 'todo',
    title: 'Photographe',
    owner: 'mariés',
    dueDate: '2026-04-01',
    dependencies: ['decision-lieu'],
    triggers: ['document-devis-photo'],
    payload: { contact: '', budget: 2500 },
    orbitRing: 1,
    angle: Math.PI * 1.2,
    description: 'Trouver et réserver un photographe',
    action: 'Quel style de photos ?',
    choices: ['Reportage naturel', 'Artistique / posé', 'Mix des deux'],
  },
  {
    id: 'calendar-venue',
    type: 'calendar',
    state: 'todo',
    title: 'Réservation Lieu',
    owner: 'lieu',
    dueDate: '2026-03-15',
    dependencies: ['decision-lieu'],
    triggers: [],
    payload: { date: '2026-09-15', hold: false },
    orbitRing: 2,
    angle: Math.PI * 1.6,
    description: 'Bloquer la date au lieu choisi',
  },
  {
    id: 'guest-famille',
    type: 'guest',
    state: 'active',
    title: 'Famille proche',
    owner: 'mariés',
    dueDate: '2026-06-01',
    dependencies: [],
    triggers: ['message-save-date'],
    payload: { count: 45, confirmed: 12, pending: 33 },
    orbitRing: 0,
    angle: Math.PI * 0.7,
    description: 'Liste des invités famille',
  },
  {
    id: 'message-save-date',
    type: 'message',
    state: 'todo',
    title: 'Save the Date',
    owner: 'mariés',
    dueDate: '2026-04-15',
    dependencies: ['decision-lieu'],
    triggers: [],
    payload: { recipients: 120, sent: 0 },
    orbitRing: 0,
    angle: Math.PI * 1.4,
    description: 'Envoyer les Save the Date',
  },
  {
    id: 'document-contrat-lieu',
    type: 'document',
    state: 'todo',
    title: 'Contrat Lieu',
    owner: 'lieu',
    dueDate: '2026-03-20',
    dependencies: ['decision-lieu', 'calendar-venue'],
    triggers: ['budget-global'],
    payload: { type: 'contrat', generated: false },
    orbitRing: 2,
    angle: Math.PI * 0.2,
    description: 'Contrat de réservation du lieu',
  },
];

let idCounter = 100;

export function OrbitProvider({ children }: { children: React.ReactNode }) {
  const [objects, setObjects] = useState<OrbitObject[]>(INITIAL_OBJECTS);
  const [handshakes, setHandshakes] = useState<Handshake[]>([]);
  const [serenity, setSerenity] = useState(42);
  const [dayJMode, setDayJMode] = useState(false);
  const [bubbleSilence, setBubbleSilence] = useState(false);
  const [selectedObject, setSelectedObject] = useState<OrbitObject | null>(null);
  const [animatingTransfer, setAnimatingTransfer] = useState<{ fromId: string; toId: string } | null>(null);
  const [planB, setPlanB] = useState<string | null>(null);

  const computeSerenity = useCallback((objs: OrbitObject[]) => {
    const total = objs.length;
    if (total === 0) return 50;
    const done = objs.filter(o => o.state === 'done').length;
    const active = objs.filter(o => o.state === 'active').length;
    const blocked = objs.filter(o => o.state === 'blocked').length;
    const incident = objs.filter(o => o.state === 'incident').length;
    const score = Math.round(((done * 1 + active * 0.3) / total) * 100 - blocked * 5 - incident * 15);
    return Math.max(0, Math.min(100, score));
  }, []);

  const nextAction = objects.find(o => o.state === 'todo' || o.state === 'active') || null;

  const addObject = useCallback((obj: OrbitObject) => {
    setObjects(prev => {
      const next = [...prev, obj];
      setSerenity(computeSerenity(next));
      return next;
    });
  }, [computeSerenity]);

  const updateObject = useCallback((id: string, updates: Partial<OrbitObject>) => {
    setObjects(prev => {
      const next = prev.map(o => o.id === id ? { ...o, ...updates } : o);
      setSerenity(computeSerenity(next));
      return next;
    });
  }, [computeSerenity]);

  const removeObject = useCallback((id: string) => {
    setObjects(prev => {
      const next = prev.filter(o => o.id !== id);
      setSerenity(computeSerenity(next));
      return next;
    });
  }, [computeSerenity]);

  const triggerHandshake = useCallback((fromId: string, toId: string, type: string) => {
    const hs: Handshake = { id: `hs-${Date.now()}`, fromId, toId, type, active: true, timestamp: Date.now() };
    setHandshakes(prev => [...prev, hs]);
    setAnimatingTransfer({ fromId, toId });
    setTimeout(() => {
      setAnimatingTransfer(null);
      setHandshakes(prev => prev.map(h => h.id === hs.id ? { ...h, active: false } : h));
    }, 2000);
  }, []);

  const answerQuestion = useCallback((objectId: string, choice: string) => {
    setObjects(prev => {
      const obj = prev.find(o => o.id === objectId);
      if (!obj) return prev;
      const next = prev.map(o => {
        if (o.id === objectId) return { ...o, state: 'done' as ObjectState, payload: { ...o.payload, answer: choice } };
        return o;
      });
      // Trigger dependencies
      if (obj.triggers.length > 0) {
        const triggerId = obj.triggers[0];
        const triggerObj = next.find(o => o.id === triggerId);
        if (triggerObj) {
          triggerHandshake(objectId, triggerId, 'activation');
        }
      }
      setSerenity(computeSerenity(next));
      return next;
    });
  }, [computeSerenity, triggerHandshake]);

  const addProvider = useCallback(() => {
    const id = `provider-${++idCounter}`;
    const calId = `calendar-${++idCounter}`;
    const newProvider: OrbitObject = {
      id,
      type: 'provider',
      state: 'todo',
      title: 'Nouveau Prestataire',
      owner: 'mariés',
      dueDate: '2026-06-01',
      dependencies: [],
      triggers: [calId],
      payload: { contact: 'contact@presta.fr', budget: 1500 },
      orbitRing: 1,
      angle: Math.PI * (0.3 + Math.random() * 1.4),
      description: 'Prestataire ajouté via Console',
      action: 'Contacter pour devis',
      choices: ['Demander devis', 'Vérifier dispo', 'Reporter'],
    };
    const newCal: OrbitObject = {
      id: calId,
      type: 'calendar',
      state: 'todo',
      title: 'Créneau Presta',
      owner: 'presta',
      dueDate: '2026-06-15',
      dependencies: [id],
      triggers: [],
      payload: { date: '2026-09-15', hold: false },
      orbitRing: 2,
      angle: Math.PI * (0.5 + Math.random() * 1.2),
      description: 'Créneau à bloquer',
    };
    setObjects(prev => {
      const next = [...prev, newProvider, newCal];
      setSerenity(computeSerenity(next));
      return next;
    });
    triggerHandshake(id, calId, 'calendar-link');
  }, [computeSerenity, triggerHandshake]);

  const addGuests = useCallback(() => {
    const id = `guest-${++idCounter}`;
    const msgId = `message-${++idCounter}`;
    const newGuest: OrbitObject = {
      id,
      type: 'guest',
      state: 'active',
      title: '50 Invités ajoutés',
      owner: 'mariés',
      dueDate: '2026-06-01',
      dependencies: [],
      triggers: [msgId],
      payload: { count: 50, confirmed: 0, pending: 50 },
      orbitRing: 0,
      angle: Math.PI * (0.1 + Math.random() * 1.8),
      description: 'Groupe de 50 invités simulés',
    };
    const newMsg: OrbitObject = {
      id: msgId,
      type: 'message',
      state: 'todo',
      title: 'Invitations à envoyer',
      owner: 'mariés',
      dueDate: '2026-05-01',
      dependencies: [id],
      triggers: [],
      payload: { recipients: 50, sent: 0 },
      orbitRing: 0,
      angle: Math.PI * (0.3 + Math.random() * 1.5),
      description: 'Messages d\'invitation automatiques',
    };
    setObjects(prev => {
      const next = [...prev, newGuest, newMsg];
      setSerenity(computeSerenity(next));
      return next;
    });
    triggerHandshake(id, msgId, 'guest-message');
  }, [computeSerenity, triggerHandshake]);

  const generateDocument = useCallback(() => {
    const id = `document-${++idCounter}`;
    const newDoc: OrbitObject = {
      id,
      type: 'document',
      state: 'active',
      title: 'Devis → Contrat → Facture',
      owner: 'système',
      dueDate: '2026-04-01',
      dependencies: [],
      triggers: ['budget-global'],
      payload: { type: 'devis-contrat-facture', generated: true },
      orbitRing: 2,
      angle: Math.PI * 1.8,
      description: 'Chaîne documentaire complète générée',
    };
    setObjects(prev => {
      const next = [...prev, newDoc];
      setSerenity(computeSerenity(next));
      return next;
    });
    // Animate to center then turn green
    setTimeout(() => {
      updateObject(id, { state: 'done' });
      triggerHandshake(id, 'budget-global', 'document-budget');
    }, 1500);
  }, [computeSerenity, updateObject, triggerHandshake]);

  const blockCalendar = useCallback(() => {
    const calObj = objects.find(o => o.type === 'calendar' && o.state === 'todo');
    if (calObj) {
      updateObject(calObj.id, { state: 'done', payload: { ...calObj.payload, hold: true } });
      triggerHandshake(calObj.id, calObj.dependencies[0] || calObj.id, 'calendar-block');
    } else {
      const id = `calendar-${++idCounter}`;
      const newCal: OrbitObject = {
        id,
        type: 'calendar',
        state: 'done',
        title: 'Créneau bloqué',
        owner: 'système',
        dueDate: '2026-09-15',
        dependencies: [],
        triggers: [],
        payload: { date: '2026-09-15', hold: true },
        orbitRing: 2,
        angle: Math.PI * 0.9,
        description: 'Créneau calendrier bloqué',
      };
      addObject(newCal);
    }
  }, [objects, updateObject, triggerHandshake, addObject]);

  const simulateDelay = useCallback(() => {
    const activeObj = objects.find(o => o.type === 'provider' || o.type === 'moment');
    if (activeObj) {
      updateObject(activeObj.id, { state: 'blocked' });
    }
    setPlanB('Réorganiser : intervertir Cocktail et Photos de groupe (+30min). Notifier DJ et traiteur.');
    setSerenity(prev => Math.max(0, prev - 18));
  }, [objects, updateObject]);

  const activateBubbleSilence = useCallback(() => {
    setBubbleSilence(prev => !prev);
  }, []);

  const toggleDayJ = useCallback(() => {
    setDayJMode(prev => !prev);
    if (!dayJMode) {
      // Update providers with day-J statuses
      setObjects(prev => prev.map(o => {
        if (o.type === 'provider') {
          const statuses = ['En route', 'Arrivé', 'On démarre', 'Terminé'];
          return { ...o, payload: { ...o.payload, dayJStatus: statuses[Math.floor(Math.random() * 3)] } };
        }
        return o;
      }));
    }
  }, [dayJMode]);

  const clearPlanB = useCallback(() => setPlanB(null), []);

  return (
    <OrbitContext.Provider value={{
      objects, handshakes, serenity, dayJMode, bubbleSilence,
      nextAction, selectedObject, setSelectedObject,
      addObject, updateObject, removeObject, answerQuestion,
      addProvider, addGuests, generateDocument, blockCalendar,
      simulateDelay, activateBubbleSilence, toggleDayJ,
      triggerHandshake, animatingTransfer, planB, clearPlanB,
    }}>
      {children}
    </OrbitContext.Provider>
  );
}

export function useOrbit() {
  const ctx = useContext(OrbitContext);
  if (!ctx) throw new Error('useOrbit must be inside OrbitProvider');
  return ctx;
}
