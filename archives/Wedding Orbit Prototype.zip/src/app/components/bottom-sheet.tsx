import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useOrbit, OrbitObject, ObjectType, ObjectState } from './orbit-context';
import { useNavigate } from 'react-router';

const TYPE_NAMES: Record<ObjectType, string> = {
  moment: 'Moment',
  document: 'Document',
  decision: 'Décision',
  calendar: 'Calendrier',
  message: 'Message',
  budget: 'Budget',
  provider: 'Prestataire',
  guest: 'Invités',
};

const STATE_NAMES: Record<ObjectState, string> = {
  todo: 'À faire',
  active: 'En cours',
  done: 'Terminé',
  blocked: 'Bloqué',
  incident: 'Incident',
};

const STATE_COLORS: Record<ObjectState, string> = {
  todo: '#6b7280',
  active: '#3b82f6',
  done: '#22c55e',
  blocked: '#f97316',
  incident: '#ef4444',
};

const TYPE_ICONS: Record<ObjectType, string> = {
  moment: '●',
  document: '■',
  decision: '▲',
  calendar: '◗',
  message: '✦',
  budget: '◎',
  provider: '⬡',
  guest: '◇',
};

interface Props {
  object: OrbitObject | null;
  onClose: () => void;
}

export function BottomSheet({ object, onClose }: Props) {
  const { updateObject, triggerHandshake } = useOrbit();
  const navigate = useNavigate();

  if (!object) return null;

  const handleAction = () => {
    if (object.action && object.choices) {
      navigate('/question', { state: { objectId: object.id } });
    } else {
      updateObject(object.id, { state: 'done' });
      if (object.triggers.length > 0) {
        triggerHandshake(object.id, object.triggers[0], 'complete');
      }
    }
    onClose();
  };

  return (
    <AnimatePresence>
      <motion.div
        className="fixed inset-0 z-50 flex items-end justify-center"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
      >
        {/* Backdrop */}
        <motion.div
          className="absolute inset-0 bg-black/60"
          onClick={onClose}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        />

        {/* Sheet */}
        <motion.div
          className="relative w-full max-w-md rounded-t-3xl p-6 pb-10"
          style={{ background: 'linear-gradient(180deg, #1a1a2e 0%, #0f0f1a 100%)' }}
          initial={{ y: 300, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 300, opacity: 0 }}
          transition={{ type: 'spring', damping: 25, stiffness: 300 }}
        >
          {/* Handle */}
          <div className="mx-auto mb-6 h-1 w-12 rounded-full bg-white/20" />

          {/* Type badge */}
          <div className="flex items-center gap-3 mb-4">
            <span
              className="flex items-center justify-center w-10 h-10 rounded-xl"
              style={{ backgroundColor: STATE_COLORS[object.state] + '20', color: STATE_COLORS[object.state] }}
            >
              <span className="text-xl">{TYPE_ICONS[object.type]}</span>
            </span>
            <div>
              <p className="text-white/50 text-xs tracking-wider uppercase">{TYPE_NAMES[object.type]}</p>
              <h3 className="text-white text-lg">{object.title}</h3>
            </div>
          </div>

          {/* State */}
          <div className="flex items-center gap-2 mb-4">
            <span
              className="inline-block w-2.5 h-2.5 rounded-full"
              style={{ backgroundColor: STATE_COLORS[object.state] }}
            />
            <span className="text-white/70 text-sm">{STATE_NAMES[object.state]}</span>
            {object.dueDate && (
              <span className="text-white/30 text-xs ml-auto">{object.dueDate}</span>
            )}
          </div>

          {/* Description */}
          {object.description && (
            <p className="text-white/50 text-sm mb-5 leading-relaxed">{object.description}</p>
          )}

          {/* Dependencies */}
          {object.dependencies.length > 0 && (
            <div className="mb-5">
              <p className="text-white/30 text-xs mb-2 uppercase tracking-wider">Dépendances</p>
              <div className="flex flex-wrap gap-2">
                {object.dependencies.map(dep => (
                  <span key={dep} className="px-2 py-1 rounded-lg bg-white/5 text-white/40 text-xs">{dep}</span>
                ))}
              </div>
            </div>
          )}

          {/* Day-J status */}
          {object.payload.dayJStatus && (
            <div className="mb-5 p-3 rounded-xl bg-blue-500/10 border border-blue-500/20">
              <p className="text-blue-400 text-sm">Jour J : {object.payload.dayJStatus}</p>
            </div>
          )}

          {/* Single Action Button */}
          {object.state !== 'done' && (
            <button
              onClick={handleAction}
              className="w-full py-4 rounded-2xl text-white transition-all active:scale-[0.98]"
              style={{
                background: `linear-gradient(135deg, ${STATE_COLORS[object.state]}, ${STATE_COLORS[object.state]}88)`,
                boxShadow: `0 4px 20px ${STATE_COLORS[object.state]}40`,
              }}
            >
              {object.action || 'Marquer comme terminé'}
            </button>
          )}

          {object.state === 'done' && (
            <div className="w-full py-4 rounded-2xl text-center text-green-400/70 bg-green-500/10 border border-green-500/20">
              ✓ Complété
            </div>
          )}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
