import React from 'react';
import { Outlet } from 'react-router';
import { OrbitProvider } from './orbit-context';

export function Layout() {
  return (
    <OrbitProvider>
      <div className="w-full h-screen max-w-md mx-auto relative overflow-hidden" style={{ background: '#080810' }}>
        <Outlet />
      </div>
    </OrbitProvider>
  );
}
