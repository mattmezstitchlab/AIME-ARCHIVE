import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useNavigate } from 'react-router';
import { useOrbit, OrbitObject } from './orbit-context';
import { OrbitVisualization } from './orbit-visualization';
import { BottomSheet } from './bottom-sheet';

export function OrbitScreen() {
  const {
    objects, serenity, dayJMode, bubbleSilence, nextAction,
    selectedObject, setSelectedObject, toggleDayJ, planB, clearPlanB,
  } = useOrbit();
  const navigate = useNavigate();
  const containerRef = useRef<HTMLDivElement>(null);
  const [dims, setDims] = useState({ w: 390, h: 600 });

  useEffect(() => {
    const measure = () => {
      if (containerRef.current) {
        setDims({
          w: containerRef.current.clientWidth,
          h: containerRef.current.clientHeight,
        });
      }
    };
    measure();
    window.addEventListener('resize', measure);
    return () => window.removeEventListener('resize', measure);
  }, []);

  const centerX = dims.w / 2;
  const centerY = dims.h * 0.42;
  const maxRadius = Math.min(dims.w, dims.h * 0.7) * 0.46;

  const serenityColor = serenity > 70 ? '#22c55e' : serenity > 40 ? '#3b82f6' : serenity > 20 ? '#f97316' : '#ef4444';

  const legend = [
    { type: 'moment', label: 'Moment', icon: '●' },
    { type: 'document', label: 'Document', icon: '■' },
    { type: 'decision', label: 'Décision', icon: '▲' },
    { type: 'provider', label: 'Prestataire', icon: '⬡' },
    { type: 'guest', label: 'Invités', icon: '◇' },
    { type: 'budget', label: 'Budget', icon: '◎' },
  ];

  return (
    <div
      ref={containerRef}
      className="relative w-full h-full overflow-hidden"
      style={{ background: 'linear-gradient(180deg, #080810 0%, #0d0d1a 40%, #111128 100%)' }}
    >
      {/* Top Bar */}
      <div className="absolute top-0 left-0 right-0 z-10 px-5 pt-4 pb-2 flex items-center justify-between">
        <div>
          <h1 className="text-white/90 text-lg tracking-wide">WEDDING ORBIT</h1>
          <p className="text-white/30 text-xs tracking-widest uppercase">
            {dayJMode ? 'JOUR J — LIVE' : '15 Sept 2026'}
          </p>
        </div>
        <div className="flex items-center gap-3">
          {/* Bubble Silence indicator */}
          {bubbleSilence && (
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className="w-8 h-8 rounded-full bg-purple-500/20 flex items-center justify-center"
            >
              <span className="text-purple-400 text-xs">🔇</span>
            </motion.div>
          )}
          {/* Day-J Toggle */}
          <button
            onClick={toggleDayJ}
            className="px-3 py-1.5 rounded-full text-xs transition-all"
            style={{
              background: dayJMode ? 'rgba(249,115,22,0.2)' : 'rgba(255,255,255,0.06)',
              color: dayJMode ? '#f97316' : 'rgba(255,255,255,0.4)',
              border: `1px solid ${dayJMode ? 'rgba(249,115,22,0.3)' : 'rgba(255,255,255,0.08)'}`,
            }}
          >
            {dayJMode ? '● JOUR J' : 'JOUR J'}
          </button>
        </div>
      </div>

      {/* Serenity Score - Center top */}
      <motion.div
        className="absolute z-10 flex flex-col items-center"
        style={{ left: centerX - 40, top: centerY - 35 }}
        animate={{ scale: [1, 1.02, 1] }}
        transition={{ duration: 3, repeat: Infinity }}
      >
        <span className="text-4xl tracking-tight" style={{ color: serenityColor }}>
          {serenity}
          <span className="text-lg text-white/30">%</span>
        </span>
        <span className="text-white/25 text-[10px] tracking-[0.2em] uppercase mt-0.5">Sérénité</span>
      </motion.div>

      {/* Orbit Visualization */}
      <OrbitVisualization
        onSelectObject={(obj) => setSelectedObject(obj)}
        centerX={centerX}
        centerY={centerY}
        maxRadius={maxRadius}
      />

      {/* Shape Legend */}
      <div className="absolute z-10 flex flex-wrap justify-center gap-x-3 gap-y-1 px-4"
        style={{ top: centerY * 2 + 10, left: 0, right: 0 }}
      >
        {legend.map(l => (
          <span key={l.type} className="text-white/25 text-[9px] tracking-wider">
            <span className="mr-0.5">{l.icon}</span> {l.label}
          </span>
        ))}
      </div>

      {/* Next Action Card */}
      <div className="absolute bottom-0 left-0 right-0 z-10 px-4 pb-6">
        {/* Plan B Alert */}
        <AnimatePresence>
          {planB && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="mb-3 p-4 rounded-2xl border"
              style={{
                background: 'rgba(249,115,22,0.08)',
                borderColor: 'rgba(249,115,22,0.2)',
              }}
            >
              <div className="flex items-start justify-between mb-2">
                <span className="text-orange-400 text-xs tracking-wider uppercase">Plan B proposé</span>
                <button onClick={clearPlanB} className="text-white/30 text-xs">✕</button>
              </div>
              <p className="text-white/60 text-sm leading-relaxed">{planB}</p>
              <button
                onClick={clearPlanB}
                className="mt-3 w-full py-2 rounded-xl bg-orange-500/20 text-orange-400 text-sm"
              >
                Appliquer le Plan B
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Main Action Card */}
        {nextAction && (
          <motion.button
            onClick={() => {
              if (nextAction.choices) {
                navigate('/question', { state: { objectId: nextAction.id } });
              } else {
                setSelectedObject(nextAction);
              }
            }}
            className="w-full p-5 rounded-2xl text-left transition-all active:scale-[0.98]"
            style={{
              background: 'linear-gradient(135deg, rgba(30,30,60,0.9), rgba(20,20,40,0.95))',
              border: '1px solid rgba(255,255,255,0.06)',
              boxShadow: `0 0 30px rgba(59,130,246,${0.05 + (serenity / 100) * 0.1})`,
            }}
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.3 }}
          >
            <p className="text-white/30 text-[10px] tracking-[0.2em] uppercase mb-2">Prochaine action</p>
            <p className="text-white/90 text-base mb-1">{nextAction.title}</p>
            <p className="text-white/40 text-xs">{nextAction.action || nextAction.description}</p>
            <div className="flex items-center mt-3">
              <span className="text-blue-400/60 text-xs">Tap pour continuer →</span>
            </div>
          </motion.button>
        )}

        {/* Console Access */}
        <button
          onClick={() => navigate('/console')}
          className="w-full mt-3 py-3 rounded-xl text-white/20 text-xs tracking-[0.15em] uppercase transition-all active:bg-white/5"
          style={{ background: 'rgba(255,255,255,0.02)' }}
        >
          Console · Point Zéro
        </button>
      </div>

      {/* Bottom Sheet */}
      <AnimatePresence>
        {selectedObject && (
          <BottomSheet
            object={selectedObject}
            onClose={() => setSelectedObject(null)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
