import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useNavigate } from 'react-router';
import { useOrbit } from './orbit-context';

interface SimAction {
  label: string;
  description: string;
  icon: string;
  action: () => void;
  color: string;
}

export function ConsoleScreen() {
  const navigate = useNavigate();
  const {
    addProvider, addGuests, generateDocument, blockCalendar,
    simulateDelay, activateBubbleSilence, bubbleSilence,
    serenity, objects, dayJMode,
  } = useOrbit();
  const [feedbacks, setFeedbacks] = useState<string[]>([]);
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  const addFeedback = (msg: string) => {
    setFeedbacks(prev => [msg, ...prev].slice(0, 8));
  };

  const actions: SimAction[] = [
    {
      label: 'Ajouter un prestataire',
      description: 'Crée un hexagone Prestataire + arc Calendrier liés',
      icon: '⬡',
      color: '#3b82f6',
      action: () => {
        addProvider();
        addFeedback('→ Prestataire + Calendrier ajoutés à l\'orbite');
      },
    },
    {
      label: 'Ajouter 50 invités',
      description: 'Simule un lot de 50 invités + messages à envoyer',
      icon: '◇',
      color: '#8b5cf6',
      action: () => {
        addGuests();
        addFeedback('→ 50 invités + Messages créés dans l\'orbite');
      },
    },
    {
      label: 'Générer Devis→Contrat→Facture',
      description: 'Chaîne documentaire complète en auto',
      icon: '■',
      color: '#22c55e',
      action: () => {
        generateDocument();
        addFeedback('→ Document généré, transit vers Budget...');
      },
    },
    {
      label: 'Bloquer un créneau',
      description: 'Réserve et verrouille un créneau calendrier',
      icon: '◗',
      color: '#06b6d4',
      action: () => {
        blockCalendar();
        addFeedback('→ Créneau calendrier bloqué ✓');
      },
    },
    {
      label: 'Simuler retard Jour J',
      description: 'Bloque un prestataire, baisse Sérénité, propose Plan B',
      icon: '⚠',
      color: '#f97316',
      action: () => {
        simulateDelay();
        addFeedback('→ Retard simulé ! Plan B proposé sur l\'orbite');
      },
    },
    {
      label: bubbleSilence ? 'Désactiver Bulle Silence' : 'Activer Bulle Silence',
      description: 'Mode silence : seuls les incidents critiques passent',
      icon: bubbleSilence ? '🔊' : '🔇',
      color: '#a855f7',
      action: () => {
        activateBubbleSilence();
        addFeedback(bubbleSilence ? '→ Bulle Silence désactivée' : '→ Bulle Silence activée — sérénité protégée');
      },
    },
  ];

  const stats = [
    { label: 'Objets', value: objects.length },
    { label: 'Terminés', value: objects.filter(o => o.state === 'done').length },
    { label: 'En cours', value: objects.filter(o => o.state === 'active').length },
    { label: 'Bloqués', value: objects.filter(o => o.state === 'blocked' || o.state === 'incident').length },
  ];

  return (
    <div
      className="w-full h-full overflow-y-auto"
      style={{ background: 'linear-gradient(180deg, #080810 0%, #0d0d1a 40%, #0a0a20 100%)' }}
    >
      <div className="max-w-md mx-auto px-5 pt-5 pb-10">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <button
            onClick={() => navigate('/')}
            className="text-white/30 text-sm"
          >
            ← Orbite
          </button>
          <span className="text-white/15 text-[10px] tracking-[0.3em] uppercase">Console · Point Zéro</span>
        </div>

        {/* Serenity Bar */}
        <div className="mb-8 p-4 rounded-2xl" style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.05)' }}>
          <div className="flex items-center justify-between mb-3">
            <span className="text-white/30 text-xs tracking-wider uppercase">Sérénité</span>
            <span
              className="text-2xl"
              style={{ color: serenity > 60 ? '#22c55e' : serenity > 30 ? '#f97316' : '#ef4444' }}
            >
              {serenity}%
            </span>
          </div>
          <div className="h-1.5 rounded-full bg-white/5 overflow-hidden">
            <motion.div
              className="h-full rounded-full"
              style={{
                background: serenity > 60
                  ? 'linear-gradient(90deg, #22c55e, #4ade80)'
                  : serenity > 30
                    ? 'linear-gradient(90deg, #f97316, #fb923c)'
                    : 'linear-gradient(90deg, #ef4444, #f87171)',
              }}
              animate={{ width: `${serenity}%` }}
              transition={{ type: 'spring', damping: 20 }}
            />
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-4 gap-2 mb-8">
          {stats.map(s => (
            <div key={s.label} className="text-center p-3 rounded-xl" style={{ background: 'rgba(255,255,255,0.02)' }}>
              <p className="text-white/80 text-lg">{s.value}</p>
              <p className="text-white/20 text-[9px] tracking-wider uppercase mt-1">{s.label}</p>
            </div>
          ))}
        </div>

        {/* Simulation Buttons */}
        <p className="text-white/15 text-[10px] tracking-[0.25em] uppercase mb-4">Simulations de preuve</p>
        <div className="space-y-3 mb-8">
          {actions.map((a, i) => (
            <motion.button
              key={a.label}
              onClick={() => {
                setActiveIndex(i);
                a.action();
                setTimeout(() => setActiveIndex(null), 800);
              }}
              className="w-full p-4 rounded-2xl text-left transition-all flex items-center gap-4 active:scale-[0.98]"
              style={{
                background: activeIndex === i
                  ? `${a.color}15`
                  : 'rgba(255,255,255,0.02)',
                border: `1px solid ${activeIndex === i ? `${a.color}30` : 'rgba(255,255,255,0.04)'}`,
              }}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.06 }}
            >
              <span
                className="w-10 h-10 rounded-xl flex items-center justify-center text-lg shrink-0"
                style={{ background: `${a.color}12`, color: a.color }}
              >
                {a.icon}
              </span>
              <div className="flex-1 min-w-0">
                <p className="text-white/80 text-sm">{a.label}</p>
                <p className="text-white/25 text-xs mt-0.5 truncate">{a.description}</p>
              </div>
            </motion.button>
          ))}
        </div>

        {/* Event Feed */}
        <AnimatePresence>
          {feedbacks.length > 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
            >
              <p className="text-white/15 text-[10px] tracking-[0.25em] uppercase mb-3">Événements récents</p>
              <div className="space-y-2">
                {feedbacks.map((fb, i) => (
                  <motion.div
                    key={`${fb}-${i}`}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="px-4 py-2.5 rounded-xl text-white/40 text-xs"
                    style={{ background: 'rgba(255,255,255,0.02)' }}
                  >
                    {fb}
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
