import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useNavigate, useLocation } from 'react-router';
import { useOrbit } from './orbit-context';

export function QuestionScreen() {
  const { objects, answerQuestion } = useOrbit();
  const navigate = useNavigate();
  const location = useLocation();
  const objectId = (location.state as any)?.objectId;
  const [selected, setSelected] = useState<string | null>(null);
  const [validated, setValidated] = useState(false);

  const obj = objects.find(o => o.id === objectId);

  if (!obj || !obj.choices) {
    return (
      <div
        className="w-full h-full flex flex-col items-center justify-center px-6"
        style={{ background: 'linear-gradient(180deg, #080810 0%, #0d0d1a 100%)' }}
      >
        <p className="text-white/40 text-sm mb-6">Aucune question en attente</p>
        <button
          onClick={() => navigate('/')}
          className="px-6 py-3 rounded-2xl bg-white/5 text-white/50 text-sm"
        >
          Retour à l'Orbite
        </button>
      </div>
    );
  }

  const labels = ['A', 'B', 'C'];

  const handleValidate = () => {
    if (!selected) return;
    setValidated(true);
    answerQuestion(obj.id, selected);
    setTimeout(() => navigate('/'), 1200);
  };

  return (
    <div
      className="w-full h-full flex flex-col items-center justify-center px-6 relative overflow-hidden"
      style={{ background: 'linear-gradient(180deg, #080810 0%, #0d0d1a 40%, #0a0a20 100%)' }}
    >
      {/* Background subtle orbit */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <motion.div
          className="rounded-full border border-white/[0.03]"
          style={{ width: 300, height: 300 }}
          animate={{ rotate: 360 }}
          transition={{ duration: 30, repeat: Infinity, ease: 'linear' }}
        />
      </div>

      {/* Back button */}
      <button
        onClick={() => navigate('/')}
        className="absolute top-6 left-5 text-white/30 text-sm z-10"
      >
        ← Orbite
      </button>

      {/* Validated Animation */}
      <AnimatePresence>
        {validated && (
          <motion.div
            className="absolute inset-0 z-20 flex flex-col items-center justify-center"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ type: 'spring', damping: 12 }}
              className="w-24 h-24 rounded-full flex items-center justify-center mb-6"
              style={{ background: 'rgba(34,197,94,0.15)', border: '2px solid rgba(34,197,94,0.3)' }}
            >
              <motion.span
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.3 }}
                className="text-green-400 text-4xl"
              >
                ✓
              </motion.span>
            </motion.div>
            <motion.p
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="text-white/50 text-sm"
            >
              Transmis à l'orbite
            </motion.p>

            {/* Transfer animation lines */}
            {[0, 1, 2].map(i => (
              <motion.div
                key={i}
                className="absolute w-0.5 bg-gradient-to-b from-green-400/50 to-transparent"
                style={{
                  height: 60,
                  left: `${30 + i * 20}%`,
                  top: '65%',
                  transform: `rotate(${-30 + i * 30}deg)`,
                }}
                initial={{ opacity: 0, scaleY: 0 }}
                animate={{ opacity: [0, 0.6, 0], scaleY: [0, 1, 0] }}
                transition={{ delay: 0.3 + i * 0.15, duration: 0.8 }}
              />
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Question Content */}
      {!validated && (
        <motion.div
          className="w-full max-w-sm z-10"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          {/* Category */}
          <p className="text-white/20 text-[10px] tracking-[0.3em] uppercase text-center mb-3">
            Une question à la fois
          </p>

          {/* Question */}
          <h2 className="text-white/90 text-center text-xl mb-10 leading-relaxed">
            {obj.action}
          </h2>

          {/* Choices */}
          <div className="space-y-3 mb-10">
            {obj.choices.map((choice, i) => (
              <motion.button
                key={choice}
                onClick={() => setSelected(choice)}
                className="w-full p-4 rounded-2xl text-left transition-all flex items-center gap-4"
                style={{
                  background: selected === choice
                    ? 'rgba(59,130,246,0.12)'
                    : 'rgba(255,255,255,0.03)',
                  border: `1px solid ${selected === choice ? 'rgba(59,130,246,0.3)' : 'rgba(255,255,255,0.05)'}`,
                }}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 + i * 0.1 }}
                whileTap={{ scale: 0.98 }}
              >
                <span
                  className="w-8 h-8 rounded-lg flex items-center justify-center text-xs shrink-0"
                  style={{
                    background: selected === choice ? 'rgba(59,130,246,0.2)' : 'rgba(255,255,255,0.05)',
                    color: selected === choice ? '#60a5fa' : 'rgba(255,255,255,0.3)',
                  }}
                >
                  {labels[i]}
                </span>
                <span style={{ color: selected === choice ? 'rgba(255,255,255,0.9)' : 'rgba(255,255,255,0.5)' }} className="text-sm">
                  {choice}
                </span>
              </motion.button>
            ))}
          </div>

          {/* Validate */}
          <motion.button
            onClick={handleValidate}
            disabled={!selected}
            className="w-full py-4 rounded-2xl text-white transition-all"
            style={{
              background: selected
                ? 'linear-gradient(135deg, #3b82f6, #2563eb)'
                : 'rgba(255,255,255,0.05)',
              opacity: selected ? 1 : 0.4,
              boxShadow: selected ? '0 4px 25px rgba(59,130,246,0.3)' : 'none',
            }}
            whileTap={selected ? { scale: 0.98 } : {}}
          >
            Valider
          </motion.button>
        </motion.div>
      )}
    </div>
  );
}
