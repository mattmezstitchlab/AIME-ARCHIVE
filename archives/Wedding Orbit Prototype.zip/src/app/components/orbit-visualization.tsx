import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useOrbit, OrbitObject, ObjectState, ObjectType } from './orbit-context';

const STATE_COLORS: Record<ObjectState, string> = {
  todo: '#6b7280',
  active: '#3b82f6',
  done: '#22c55e',
  blocked: '#f97316',
  incident: '#ef4444',
};

const STATE_GLOW: Record<ObjectState, string> = {
  todo: '0 0 8px rgba(107,114,128,0.3)',
  active: '0 0 15px rgba(59,130,246,0.5)',
  done: '0 0 15px rgba(34,197,94,0.5)',
  blocked: '0 0 15px rgba(249,115,22,0.5)',
  incident: '0 0 20px rgba(239,68,68,0.7)',
};

function getShapePath(type: ObjectType, size: number): string {
  const s = size;
  switch (type) {
    case 'moment': // circle
      return `M ${s},0 A ${s},${s} 0 1,1 ${-s},0 A ${s},${s} 0 1,1 ${s},0 Z`;
    case 'document': // square
      return `M ${-s},${-s} L ${s},${-s} L ${s},${s} L ${-s},${s} Z`;
    case 'decision': // triangle
      return `M 0,${-s} L ${s},${s * 0.8} L ${-s},${s * 0.8} Z`;
    case 'calendar': // arc/half-circle
      return `M ${-s},0 A ${s},${s} 0 0,1 ${s},0 L ${s * 0.6},0 A ${s * 0.6},${s * 0.6} 0 0,0 ${-s * 0.6},0 Z`;
    case 'message': // seed/teardrop
      return `M 0,${-s} C ${s * 0.8},${-s * 0.3} ${s * 0.6},${s * 0.8} 0,${s} C ${-s * 0.6},${s * 0.8} ${-s * 0.8},${-s * 0.3} 0,${-s} Z`;
    case 'budget': // ring (use circle, we'll add a hole)
      return `M ${s},0 A ${s},${s} 0 1,1 ${-s},0 A ${s},${s} 0 1,1 ${s},0 Z M ${s * 0.5},0 A ${s * 0.5},${s * 0.5} 0 1,0 ${-s * 0.5},0 A ${s * 0.5},${s * 0.5} 0 1,0 ${s * 0.5},0 Z`;
    case 'provider': // hexagon
      return `M ${s},0 L ${s * 0.5},${s * 0.866} L ${-s * 0.5},${s * 0.866} L ${-s},0 L ${-s * 0.5},${-s * 0.866} L ${s * 0.5},${-s * 0.866} Z`;
    case 'guest': // diamond/losange
      return `M 0,${-s} L ${s * 0.7},0 L 0,${s} L ${-s * 0.7},0 Z`;
    default:
      return `M ${s},0 A ${s},${s} 0 1,1 ${-s},0 A ${s},${s} 0 1,1 ${s},0 Z`;
  }
}

const TYPE_LABELS: Record<ObjectType, string> = {
  moment: '●',
  document: '■',
  decision: '▲',
  calendar: '◗',
  message: '✦',
  budget: '◎',
  provider: '⬡',
  guest: '◇',
};

interface Props {
  onSelectObject: (obj: OrbitObject) => void;
  centerX: number;
  centerY: number;
  maxRadius: number;
}

export function OrbitVisualization({ onSelectObject, centerX, centerY, maxRadius }: Props) {
  const { objects, serenity, animatingTransfer, handshakes, dayJMode } = useOrbit();
  const [tick, setTick] = useState(0);
  const animRef = useRef<number>(0);

  useEffect(() => {
    let running = true;
    const animate = () => {
      if (!running) return;
      setTick(t => t + 1);
      animRef.current = requestAnimationFrame(animate);
    };
    animRef.current = requestAnimationFrame(animate);
    return () => { running = false; cancelAnimationFrame(animRef.current); };
  }, []);

  const ringRadii = [maxRadius * 0.32, maxRadius * 0.58, maxRadius * 0.82];
  const speeds = [0.0008, 0.0005, 0.0003];

  // Serenity affects glow
  const glowIntensity = serenity / 100;
  const orbitColor = `rgba(${100 + serenity}, ${150 + serenity * 0.5}, 255, ${0.15 + glowIntensity * 0.2})`;

  return (
    <svg
      width={centerX * 2}
      height={centerY * 2}
      viewBox={`0 0 ${centerX * 2} ${centerY * 2}`}
      className="absolute inset-0"
    >
      <defs>
        <filter id="glow">
          <feGaussianBlur stdDeviation="3" result="coloredBlur" />
          <feMerge>
            <feMergeNode in="coloredBlur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
        <filter id="glow-strong">
          <feGaussianBlur stdDeviation="6" result="coloredBlur" />
          <feMerge>
            <feMergeNode in="coloredBlur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
        <radialGradient id="centerGrad" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor={`rgba(${100 + serenity}, ${180 + serenity * 0.3}, 255, 0.15)`} />
          <stop offset="100%" stopColor="transparent" />
        </radialGradient>
      </defs>

      {/* Center glow */}
      <circle cx={centerX} cy={centerY} r={maxRadius * 0.15} fill="url(#centerGrad)" />

      {/* Orbit rings */}
      {ringRadii.map((r, i) => (
        <circle
          key={i}
          cx={centerX}
          cy={centerY}
          r={r}
          fill="none"
          stroke={orbitColor}
          strokeWidth={dayJMode ? 2 : 1}
          strokeDasharray={dayJMode ? "8 4" : "4 6"}
          opacity={0.4 + glowIntensity * 0.3}
        />
      ))}

      {/* Handshake transfer lines */}
      {animatingTransfer && (() => {
        const from = objects.find(o => o.id === animatingTransfer.fromId);
        const to = objects.find(o => o.id === animatingTransfer.toId);
        if (!from || !to) return null;
        const r1 = ringRadii[from.orbitRing] || ringRadii[0];
        const r2 = ringRadii[to.orbitRing] || ringRadii[0];
        const a1 = from.angle + tick * speeds[from.orbitRing];
        const a2 = to.angle + tick * speeds[to.orbitRing];
        const x1 = centerX + Math.cos(a1) * r1;
        const y1 = centerY + Math.sin(a1) * r1;
        const x2 = centerX + Math.cos(a2) * r2;
        const y2 = centerY + Math.sin(a2) * r2;
        return (
          <g filter="url(#glow-strong)">
            <line x1={x1} y1={y1} x2={x2} y2={y2} stroke="#60a5fa" strokeWidth={2} opacity={0.8}>
              <animate attributeName="opacity" values="0.8;0.2;0.8" dur="0.8s" repeatCount="indefinite" />
            </line>
            {/* Traveling particle */}
            <circle r={4} fill="#93c5fd">
              <animateMotion dur="1.5s" repeatCount="1" fill="freeze"
                path={`M${x1 - centerX},${y1 - centerY} L${x2 - centerX},${y2 - centerY}`}
              />
              <animate attributeName="opacity" values="1;0.3;1" dur="0.5s" repeatCount="indefinite" />
            </circle>
          </g>
        );
      })()}

      {/* Objects on orbit */}
      {objects.map((obj) => {
        const r = ringRadii[obj.orbitRing] || ringRadii[0];
        const speed = speeds[obj.orbitRing] || speeds[0];
        const angle = obj.angle + tick * speed;
        const x = centerX + Math.cos(angle) * r;
        const y = centerY + Math.sin(angle) * r;
        const color = STATE_COLORS[obj.state];
        const size = obj.state === 'incident' ? 14 : obj.state === 'done' ? 10 : 12;

        return (
          <g
            key={obj.id}
            transform={`translate(${x}, ${y})`}
            onClick={() => onSelectObject(obj)}
            style={{ cursor: 'pointer' }}
            filter="url(#glow)"
          >
            <path
              d={getShapePath(obj.type, size)}
              fill={color}
              fillRule="evenodd"
              opacity={obj.state === 'todo' ? 0.5 : 0.9}
              stroke={color}
              strokeWidth={obj.state === 'active' ? 2 : 1}
            />
            {/* Pulse for active */}
            {obj.state === 'active' && (
              <circle r={size + 5} fill="none" stroke={color} strokeWidth={1} opacity={0.3}>
                <animate attributeName="r" values={`${size + 3};${size + 12};${size + 3}`} dur="2s" repeatCount="indefinite" />
                <animate attributeName="opacity" values="0.4;0;0.4" dur="2s" repeatCount="indefinite" />
              </circle>
            )}
            {/* Incident flash */}
            {obj.state === 'incident' && (
              <circle r={size + 8} fill="none" stroke="#ef4444" strokeWidth={2} opacity={0.6}>
                <animate attributeName="opacity" values="0.8;0;0.8" dur="0.5s" repeatCount="indefinite" />
              </circle>
            )}
            {/* Day-J status badge */}
            {dayJMode && obj.type === 'provider' && obj.payload.dayJStatus && (
              <text
                y={size + 14}
                textAnchor="middle"
                fill="#94a3b8"
                style={{ fontSize: '7px' }}
              >
                {obj.payload.dayJStatus}
              </text>
            )}
          </g>
        );
      })}
    </svg>
  );
}
