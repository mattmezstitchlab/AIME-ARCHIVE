import { createBrowserRouter } from 'react-router';
import { Layout } from './components/layout';
import { OrbitScreen } from './components/orbit-screen';
import { QuestionScreen } from './components/question-screen';
import { ConsoleScreen } from './components/console-screen';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: Layout,
    children: [
      { index: true, Component: OrbitScreen },
      { path: 'question', Component: QuestionScreen },
      { path: 'console', Component: ConsoleScreen },
      { path: '*', Component: OrbitScreen },
    ],
  },
]);
