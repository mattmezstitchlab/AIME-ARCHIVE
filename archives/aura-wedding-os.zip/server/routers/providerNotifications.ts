import { z } from "zod";
import { eq, and, desc } from "drizzle-orm";
import { protectedProcedure, router } from "../_core/trpc";
import { getDb, getWeddingByUserId } from "../db";
import { providerNotifications, providers } from "../../drizzle/schema";

export const providerNotificationsRouter = router({
  // ─── Récupérer les notifications pour le mariage de l'utilisateur ─────────
  list: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new Error("DB unavailable");

    const wedding = await getWeddingByUserId(ctx.user.id);
    if (!wedding) return [];

    const notifications = await db
      .select()
      .from(providerNotifications)
      .where(eq(providerNotifications.weddingId, wedding.id))
      .orderBy(desc(providerNotifications.createdAt))
      .limit(50);

    return notifications;
  }),

  // ─── Nombre de notifications non lues ────────────────────────────────────
  unreadCount: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return { count: 0 };

    const wedding = await getWeddingByUserId(ctx.user.id);
    if (!wedding) return { count: 0 };

    const unread = await db
      .select()
      .from(providerNotifications)
      .where(
        and(
          eq(providerNotifications.weddingId, wedding.id),
          eq(providerNotifications.isRead, false)
        )
      );

    return { count: unread.length };
  }),

  // ─── Marquer une notification comme lue ──────────────────────────────────
  markRead: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");

      const wedding = await getWeddingByUserId(ctx.user.id);
      if (!wedding) throw new Error("Wedding not found");

      await db
        .update(providerNotifications)
        .set({ isRead: true })
        .where(
          and(
            eq(providerNotifications.id, input.id),
            eq(providerNotifications.weddingId, wedding.id)
          )
        );

      return { success: true };
    }),

  // ─── Marquer toutes les notifications comme lues ──────────────────────────
  markAllRead: protectedProcedure.mutation(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new Error("DB unavailable");

    const wedding = await getWeddingByUserId(ctx.user.id);
    if (!wedding) throw new Error("Wedding not found");

    await db
      .update(providerNotifications)
      .set({ isRead: true })
      .where(
        and(
          eq(providerNotifications.weddingId, wedding.id),
          eq(providerNotifications.isRead, false)
        )
      );

    return { success: true };
  }),

  // ─── Créer une notification (usage interne / tests) ───────────────────────
  create: protectedProcedure
    .input(
      z.object({
        providerId: z.number(),
        type: z.enum(["invitation_accepted", "mission_update", "contract_signed", "payment_received", "message"]),
        title: z.string().max(256),
        message: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");

      const wedding = await getWeddingByUserId(ctx.user.id);
      if (!wedding) throw new Error("Wedding not found");

      const [result] = await db.insert(providerNotifications).values({
        weddingId: wedding.id,
        providerId: input.providerId,
        type: input.type,
        title: input.title,
        message: input.message,
        isRead: false,
      });

      return { id: (result as any).insertId, success: true };
    }),
});
