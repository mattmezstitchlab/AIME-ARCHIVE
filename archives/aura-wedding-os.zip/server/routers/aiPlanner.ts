import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import { getDb } from "../db";
import { invokeLLM } from "../_core/llm";
import {
  onboardingSessions, emailCampaigns, emailLogs,
  aiGuideTasks, providerMatches, narrativeMemories,
  weddings, guests, timelineEvents, memories, providers,
  budgetItems, dayOfEvents,
} from "../../drizzle/schema";
import { eq, and, desc, asc } from "drizzle-orm";
import { nanoid } from "nanoid";
import { sendGuestCampaign } from "../_core/email";

// ─── Questions d'onboarding ────────────────────────────────────────────────────
const ONBOARDING_QUESTIONS = [
  {
    step: 0,
    key: "names",
    question: "Bonjour ! Je suis AURA, votre wedding planner IA personnel. Je suis tellement heureuse de vous accompagner dans cette aventure ! Pour commencer, comment vous appelez-vous tous les deux ? (ex : Sophie & Thomas)",
    type: "text",
    placeholder: "Prénom 1 & Prénom 2",
    icon: "💑",
  },
  {
    step: 1,
    key: "weddingDate",
    question: "Magnifique ! Avez-vous déjà une date en tête pour votre grand jour ? Même approximative, ça m'aide à construire votre planning.",
    type: "date",
    placeholder: "JJ/MM/AAAA ou 'Été 2026'",
    icon: "📅",
  },
  {
    step: 2,
    key: "venue",
    question: "Avez-vous déjà une idée du lieu ? Un château, une salle de réception, un domaine en plein air... ou vous cherchez encore ?",
    type: "text",
    placeholder: "Nom du lieu ou 'Pas encore décidé'",
    icon: "🏰",
  },
  {
    step: 3,
    key: "city",
    question: "Dans quelle ville ou région souhaitez-vous vous marier ? Cela m'aidera à vous suggérer les meilleurs prestataires locaux.",
    type: "text",
    placeholder: "Paris, Lyon, Bordeaux...",
    icon: "📍",
  },
  {
    step: 4,
    key: "guestCount",
    question: "Combien d'invités prévoyez-vous environ ? Pas besoin d'être précis, une fourchette suffit.",
    type: "number",
    placeholder: "ex : 80, 150, 200...",
    icon: "👥",
  },
  {
    step: 5,
    key: "budget",
    question: "Quel est votre budget global approximatif pour le mariage ? Cette information reste strictement confidentielle et me permet de vous faire des suggestions adaptées.",
    type: "number",
    placeholder: "ex : 15000, 30000, 50000 (en €)",
    icon: "💰",
  },
  {
    step: 6,
    key: "style",
    question: "Quel style de mariage vous fait rêver ? Romantique champêtre, élégant moderne, bohème nature, luxe classique, ou quelque chose d'unique ?",
    type: "choice",
    choices: ["Romantique champêtre", "Élégant moderne", "Bohème nature", "Luxe classique", "Minimaliste", "Festif & coloré", "Autre"],
    icon: "✨",
  },
  {
    step: 7,
    key: "ceremony",
    question: "Quel type de cérémonie souhaitez-vous ? Cela impacte directement votre planning du Jour J.",
    type: "choice",
    choices: ["Civile uniquement (mairie)", "Religieuse uniquement", "Civile + Religieuse", "Laïque (cérémonie personnalisée)", "Civile + Laïque"],
    icon: "💍",
  },
  {
    step: 8,
    key: "moments",
    question: "Quels moments souhaitez-vous absolument inclure dans votre journée ? (Cochez tout ce qui vous parle)",
    type: "multiChoice",
    choices: ["Séance photo couple", "Cocktail", "Dîner assis", "Soirée dansante", "Feu d'artifice", "Photobooth", "Animation musicale live", "Brunch du lendemain"],
    icon: "🎉",
  },
  {
    step: 9,
    key: "bookedProviders",
    question: "Avez-vous déjà réservé des prestataires ? Si oui, lesquels ? (Cela m'évite de vous suggérer des doublons)",
    type: "multiChoice",
    choices: ["Photographe", "Vidéaste", "Traiteur", "Salle/Domaine", "DJ/Groupe", "Fleuriste", "Coiffeur/Maquilleur", "Officiant", "Aucun pour l'instant"],
    icon: "✅",
  },
  {
    step: 10,
    key: "constraints",
    question: "Y a-t-il des contraintes particulières dont je dois tenir compte ? (Invités à mobilité réduite, régimes alimentaires, budget serré sur certains postes...)",
    type: "text",
    placeholder: "ex : 20 végétariens, grand-mère en fauteuil roulant, pas de DJ après minuit...",
    icon: "⚠️",
  },
  {
    step: 11,
    key: "dream",
    question: "Pour finir, décrivez-moi en quelques mots le mariage de vos rêves. Ce détail me permet de personnaliser chaque suggestion que je vous ferai.",
    type: "textarea",
    placeholder: "ex : Un mariage intime et chaleureux, avec des fleurs partout, une lumière dorée au coucher du soleil...",
    icon: "🌟",
  },
];

export const aiPlannerRouter = router({

  // ─── Onboarding ──────────────────────────────────────────────────────────────
  onboarding: router({
    getSession: protectedProcedure
      .input(z.object({ weddingId: z.number() }))
      .query(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        const sessions = await db.select().from(onboardingSessions)
          .where(and(eq(onboardingSessions.weddingId, input.weddingId), eq(onboardingSessions.userId, ctx.user.id)))
          .limit(1);
        return sessions[0] ?? null;
      }),

    getQuestion: protectedProcedure
      .input(z.object({ step: z.number() }))
      .query(({ input }) => {
        return ONBOARDING_QUESTIONS[input.step] ?? null;
      }),

    getAllQuestions: protectedProcedure.query(() => ONBOARDING_QUESTIONS),

    startOrResume: protectedProcedure
      .input(z.object({ weddingId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        const existing = await db.select().from(onboardingSessions)
          .where(and(eq(onboardingSessions.weddingId, input.weddingId), eq(onboardingSessions.userId, ctx.user.id)))
          .limit(1);
        if (existing[0]) return existing[0];
        await db.insert(onboardingSessions).values({
          weddingId: input.weddingId,
          userId: ctx.user.id,
          currentStep: 0,
          totalSteps: ONBOARDING_QUESTIONS.length,
          answers: JSON.stringify({}),
          completed: false,
        });
        const created = await db.select().from(onboardingSessions)
          .where(and(eq(onboardingSessions.weddingId, input.weddingId), eq(onboardingSessions.userId, ctx.user.id)))
          .limit(1);
        return created[0];
      }),

    submitAnswer: protectedProcedure
      .input(z.object({
        weddingId: z.number(),
        step: z.number(),
        key: z.string(),
        value: z.union([z.string(), z.number(), z.array(z.string())]),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        const sessions = await db.select().from(onboardingSessions)
          .where(and(eq(onboardingSessions.weddingId, input.weddingId), eq(onboardingSessions.userId, ctx.user.id)))
          .limit(1);
        const session = sessions[0];
        if (!session) throw new Error("Session not found");

        const answers = JSON.parse(session.answers ?? "{}");
        answers[input.key] = input.value;
        const nextStep = input.step + 1;
        const completed = nextStep >= ONBOARDING_QUESTIONS.length;

        await db.update(onboardingSessions)
          .set({ answers: JSON.stringify(answers), currentStep: nextStep, completed, completedAt: completed ? new Date() : undefined })
          .where(eq(onboardingSessions.id, session.id));

        // Si terminé, propager vers tous les modules
        if (completed) {
          await propagateOnboardingToModules(db, input.weddingId, ctx.user.id, answers);
        }

        return { nextStep, completed, totalSteps: ONBOARDING_QUESTIONS.length };
      }),

    generateFromAnswers: protectedProcedure
      .input(z.object({ weddingId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        const sessions = await db.select().from(onboardingSessions)
          .where(and(eq(onboardingSessions.weddingId, input.weddingId), eq(onboardingSessions.userId, ctx.user.id)))
          .limit(1);
        const session = sessions[0];
        if (!session) throw new Error("Session not found");
        const answers = JSON.parse(session.answers ?? "{}");
        await propagateOnboardingToModules(db, input.weddingId, ctx.user.id, answers);
        return { success: true };
      }),
  }),

  // ─── Guide d'organisation priorisé ────────────────────────────────────────────
  guide: router({
    list: protectedProcedure
      .input(z.object({ weddingId: z.number() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return [];
        return db.select().from(aiGuideTasks)
          .where(eq(aiGuideTasks.weddingId, input.weddingId))
          .orderBy(asc(aiGuideTasks.sortOrder));
      }),

    generate: protectedProcedure
      .input(z.object({ weddingId: z.number() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");

        // Récupérer les infos du mariage
        const weddingRows = await db.select().from(weddings).where(eq(weddings.id, input.weddingId)).limit(1);
        const wedding = weddingRows[0];
        if (!wedding) throw new Error("Wedding not found");

        const daysUntil = wedding.weddingDate
          ? Math.ceil((new Date(wedding.weddingDate).getTime() - Date.now()) / 86400000)
          : 365;
        const monthsUntil = Math.ceil(daysUntil / 30);

        const prompt = `Tu es un expert wedding planner français. Le mariage est dans ${monthsUntil} mois.
Style: ${wedding.style ?? "non défini"}, Budget: ${wedding.totalBudget ?? "non défini"}€, Invités: ${wedding.guestCount ?? "?"}
Génère une liste de 15 tâches prioritaires pour organiser ce mariage, en JSON strict:
[{"title":"...","description":"...","category":"venue|catering|photography|music|flowers|dress|legal|invitations|transport|honeymoon|other","priority":"urgent|high|medium|low","recommendedMonthsBefore":N,"linkedModule":"providers|budget|timeline|guests|documents|other"}]
Trie par priorité décroissante. Sois très concret et actionnable.`;

        const response = await invokeLLM({
          messages: [{ role: "user", content: prompt }],
          response_format: { type: "json_schema", json_schema: { name: "guide_tasks", strict: true, schema: { type: "object", properties: { tasks: { type: "array", items: { type: "object", properties: { title: { type: "string" }, description: { type: "string" }, category: { type: "string" }, priority: { type: "string" }, recommendedMonthsBefore: { type: "number" }, linkedModule: { type: "string" } }, required: ["title","description","category","priority","recommendedMonthsBefore","linkedModule"], additionalProperties: false } } }, required: ["tasks"], additionalProperties: false } } } as any,
        });

        let tasks: Array<{ title: string; description: string; category: string; priority: string; recommendedMonthsBefore: number; linkedModule: string }> = [];
        try {
          const parsed = JSON.parse(response.choices[0].message.content as string);
          tasks = parsed.tasks ?? parsed;
        } catch {
          tasks = [];
        }

        // Supprimer les anciennes tâches IA et insérer les nouvelles
        await db.delete(aiGuideTasks).where(and(eq(aiGuideTasks.weddingId, input.weddingId), eq(aiGuideTasks.aiGenerated, true)));

        const validCategories = ["venue","catering","photography","music","flowers","dress","legal","invitations","transport","honeymoon","other"] as const;
        const validPriorities = ["urgent","high","medium","low"] as const;

        for (let i = 0; i < tasks.length; i++) {
          const t = tasks[i];
          const deadline = wedding.weddingDate
            ? new Date(new Date(wedding.weddingDate).getTime() - (t.recommendedMonthsBefore * 30 * 86400000))
            : undefined;
          await db.insert(aiGuideTasks).values({
            weddingId: input.weddingId,
            title: t.title,
            description: t.description,
            category: validCategories.includes(t.category as typeof validCategories[number]) ? t.category as typeof validCategories[number] : "other",
            priority: validPriorities.includes(t.priority as typeof validPriorities[number]) ? t.priority as typeof validPriorities[number] : "medium",
            recommendedMonthsBefore: t.recommendedMonthsBefore,
            deadline,
            linkedModule: t.linkedModule,
            sortOrder: i,
            aiGenerated: true,
          });
        }

        return { generated: tasks.length };
      }),

    updateStatus: protectedProcedure
      .input(z.object({
        taskId: z.number(),
        status: z.enum(["todo", "in_progress", "done", "skipped"]),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        await db.update(aiGuideTasks)
          .set({ status: input.status, completedAt: input.status === "done" ? new Date() : undefined })
          .where(eq(aiGuideTasks.id, input.taskId));
        return { success: true };
      }),
  }),

  // ─── Emails groupés ────────────────────────────────────────────────────────────
  email: router({
    listCampaigns: protectedProcedure
      .input(z.object({ weddingId: z.number() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return [];
        return db.select().from(emailCampaigns)
          .where(eq(emailCampaigns.weddingId, input.weddingId))
          .orderBy(desc(emailCampaigns.createdAt));
      }),

    getTemplates: protectedProcedure
      .input(z.object({ weddingId: z.number() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return [];
        const weddingRows = await db.select().from(weddings).where(eq(weddings.id, input.weddingId)).limit(1);
        const w = weddingRows[0];
        const partner1 = w?.partner1Name ?? "Partenaire 1";
        const partner2 = w?.partner2Name ?? "Partenaire 2";
        const dateStr = w?.weddingDate ? new Date(w.weddingDate).toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" }) : "Date à confirmer";
        const venue = w?.venue ?? "Lieu à confirmer";
        const slug = w?.miniSiteSlug ?? "";
        const siteUrl = slug ? `${process.env.VITE_FRONTEND_FORGE_API_URL ?? "https://aurawedding-5jwpbq82.manus.space"}/mariage/${slug}` : "";

        return [
          {
            type: "save_the_date",
            label: "Save the Date",
            subject: `Save the Date — Le mariage de ${partner1} & ${partner2} 💍`,
            body: `Bonjour {{prenom}},\n\nNous avons le bonheur de vous annoncer notre mariage !\n\n📅 Date : ${dateStr}\n📍 Lieu : ${venue}\n\nRetenez bien cette date, vous recevrez prochainement votre invitation officielle.\n\n${siteUrl ? `🌐 Notre site : ${siteUrl}\n\n` : ""}Avec toute notre affection,\n${partner1} & ${partner2}`,
          },
          {
            type: "invitation",
            label: "Invitation officielle",
            subject: `Invitation — Mariage de ${partner1} & ${partner2} 💌`,
            body: `Bonjour {{prenom}},\n\nNous avons l'immense joie de vous inviter à célébrer notre mariage.\n\n📅 Le ${dateStr}\n📍 À ${venue}\n\n🔗 Confirmez votre présence ici : {{lien_rsvp}}\n\nMerci de répondre avant le {{date_limite_rsvp}}.\n\n${siteUrl ? `🌐 Toutes les infos sur notre site : ${siteUrl}\n\n` : ""}Avec tout notre amour,\n${partner1} & ${partner2}`,
          },
          {
            type: "rsvp_reminder",
            label: "Rappel RSVP",
            subject: `Rappel — Confirmez votre présence au mariage de ${partner1} & ${partner2}`,
            body: `Bonjour {{prenom}},\n\nNous n'avons pas encore reçu votre réponse concernant notre mariage le ${dateStr}.\n\nPourriez-vous confirmer votre présence dès que possible ?\n\n🔗 Répondre maintenant : {{lien_rsvp}}\n\nMerci beaucoup,\n${partner1} & ${partner2}`,
          },
          {
            type: "practical_info",
            label: "Infos pratiques",
            subject: `Infos pratiques — Mariage de ${partner1} & ${partner2} 📋`,
            body: `Bonjour {{prenom}},\n\nVotre présence à notre mariage nous touche énormément ! Voici toutes les informations pratiques.\n\n📅 Date : ${dateStr}\n📍 Lieu : ${venue}${w?.city ? `, ${w.city}` : ""}\n${w?.miniSiteDressCode ? `\n👗 Dress code : ${w.miniSiteDressCode}` : ""}\n${w?.miniSiteTransportInfo ? `\n🚗 Transports : ${w.miniSiteTransportInfo}` : ""}\n${w?.miniSiteAccommodation ? `\n🏨 Hébergements : ${w.miniSiteAccommodation}` : ""}\n\n${siteUrl ? `🌐 Programme complet : ${siteUrl}\n\n` : ""}À très bientôt,\n${partner1} & ${partner2}`,
          },
          {
            type: "thank_you",
            label: "Remerciements",
            subject: `Merci d'avoir partagé notre bonheur 💕`,
            body: `Bonjour {{prenom}},\n\nNous tenions à vous remercier du fond du cœur d'avoir partagé ce jour si précieux avec nous.\n\nVotre présence a rendu notre mariage encore plus magique. Nous garderons ces souvenirs toute notre vie.\n\n${siteUrl ? `📸 Retrouvez les photos sur notre site : ${siteUrl}\n\n` : ""}Avec tout notre amour,\n${partner1} & ${partner2}`,
          },
        ];
      }),

    createCampaign: protectedProcedure
      .input(z.object({
        weddingId: z.number(),
        type: z.enum(["save_the_date", "invitation", "rsvp_reminder", "practical_info", "thank_you", "custom"]),
        subject: z.string(),
        bodyTemplate: z.string(),
        recipientFilter: z.enum(["all", "confirmed", "pending", "declined", "no_response"]).default("all"),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        await db.insert(emailCampaigns).values({
          weddingId: input.weddingId,
          type: input.type,
          subject: input.subject,
          bodyTemplate: input.bodyTemplate,
          recipientFilter: input.recipientFilter,
          status: "draft",
        });
        const campaigns = await db.select().from(emailCampaigns)
          .where(eq(emailCampaigns.weddingId, input.weddingId))
          .orderBy(desc(emailCampaigns.createdAt)).limit(1);
        return campaigns[0];
      }),

    previewPersonalized: protectedProcedure
      .input(z.object({
        weddingId: z.number(),
        bodyTemplate: z.string(),
        subject: z.string(),
        guestId: z.number().optional(),
      }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return { subject: input.subject, body: input.bodyTemplate };

        let firstName = "Sophie";
        let rsvpLink = "https://aura.wedding/rsvp/exemple-token";

        if (input.guestId) {
          const guestRows = await db.select().from(guests).where(eq(guests.id, input.guestId)).limit(1);
          const g = guestRows[0];
          if (g) {
            firstName = g.firstName;
            rsvpLink = `${process.env.VITE_FRONTEND_FORGE_API_URL ?? ""}/rsvp/${g.rsvpToken}`;
          }
        }

        const personalized = input.bodyTemplate
          .replace(/\{\{prenom\}\}/g, firstName)
          .replace(/\{\{lien_rsvp\}\}/g, rsvpLink)
          .replace(/\{\{date_limite_rsvp\}\}/g, new Date(Date.now() + 30 * 86400000).toLocaleDateString("fr-FR"));

        return {
          subject: input.subject.replace(/\{\{prenom\}\}/g, firstName),
          body: personalized,
        };
      }),

    sendCampaign: protectedProcedure
      .input(z.object({ campaignId: z.number(), weddingId: z.number() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");

        const campaignRows = await db.select().from(emailCampaigns).where(eq(emailCampaigns.id, input.campaignId)).limit(1);
        const campaign = campaignRows[0];
        if (!campaign) throw new Error("Campaign not found");

        // Récupérer les invités selon le filtre
        let guestQuery = db.select().from(guests).where(eq(guests.weddingId, input.weddingId));
        const allGuests = await guestQuery;

        const filtered = allGuests.filter(g => {
          if (!g.email) return false;
          if (campaign.recipientFilter === "all") return true;
          if (campaign.recipientFilter === "confirmed") return g.rsvpStatus === "confirmed";
          if (campaign.recipientFilter === "pending") return g.rsvpStatus === "pending";
          if (campaign.recipientFilter === "declined") return g.rsvpStatus === "declined";
          if (campaign.recipientFilter === "no_response") return g.rsvpStatus === "pending";
          return true;
        });

        // Marquer comme "sending"
        await db.update(emailCampaigns).set({ status: "sending", totalRecipients: filtered.length }).where(eq(emailCampaigns.id, input.campaignId));

        // Envoi réel via Resend + log en base
        let sentCount = 0;
        for (const guest of filtered) {
          const personalized = campaign.bodyTemplate
            .replace(/\{\{prenom\}\}/g, guest.firstName)
            .replace(/\{\{lien_rsvp\}\}/g, `${process.env.VITE_FRONTEND_FORGE_API_URL ?? ""}/rsvp/${guest.rsvpToken}`)
            .replace(/\{\{date_limite_rsvp\}\}/g, new Date(Date.now() + 30 * 86400000).toLocaleDateString("fr-FR"));

          // Récupérer les noms des mariés pour le template
          const weddingRows = await db.select().from(weddings).where(eq(weddings.id, input.weddingId)).limit(1);
          const wedding = weddingRows[0];

          // Envoi réel via Resend
          const emailResult = await sendGuestCampaign({
            to: guest.email!,
            guestName: `${guest.firstName} ${guest.lastName ?? ""}`.trim(),
            subject: campaign.subject,
            message: personalized,
            partner1Name: wedding?.partner1Name ?? "Les mariés",
            partner2Name: wedding?.partner2Name ?? "",
            rsvpUrl: guest.rsvpToken ? `${process.env.VITE_FRONTEND_FORGE_API_URL ?? ""}/rsvp/${guest.rsvpToken}` : undefined,
          });

          await db.insert(emailLogs).values({
            campaignId: input.campaignId,
            guestId: guest.id,
            recipientEmail: guest.email!,
            recipientName: `${guest.firstName} ${guest.lastName ?? ""}`.trim(),
            personalizedSubject: campaign.subject,
            personalizedBody: personalized,
            status: emailResult.success ? "sent" : "failed",
            sentAt: emailResult.success ? new Date() : null,
          });
          if (emailResult.success) sentCount++;
        }

        await db.update(emailCampaigns).set({ status: "sent", sentAt: new Date(), sentCount }).where(eq(emailCampaigns.id, input.campaignId));
        return { sent: sentCount, total: filtered.length };
      }),

    getCampaignLogs: protectedProcedure
      .input(z.object({ campaignId: z.number() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return [];
        return db.select().from(emailLogs).where(eq(emailLogs.campaignId, input.campaignId)).orderBy(desc(emailLogs.createdAt));
      }),

    deleteCampaign: protectedProcedure
      .input(z.object({ campaignId: z.number() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        await db.delete(emailLogs).where(eq(emailLogs.campaignId, input.campaignId));
        await db.delete(emailCampaigns).where(eq(emailCampaigns.id, input.campaignId));
        return { success: true };
      }),

    updateCampaign: protectedProcedure
      .input(z.object({ campaignId: z.number(), subject: z.string().optional(), body: z.string().optional() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        const upd: Record<string, unknown> = {};
        if (input.subject !== undefined) upd.subject = input.subject;
        if (input.body !== undefined) upd.body = input.body;
        if (Object.keys(upd).length > 0) {
          await db.update(emailCampaigns).set(upd as any).where(eq(emailCampaigns.id, input.campaignId));
        }
        return { success: true };
      }),

    getStats: protectedProcedure
      .input(z.object({ weddingId: z.number() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return { total: 0, sent: 0, failed: 0, campaigns: [] as any[] };
        const campaigns = await db.select().from(emailCampaigns).where(eq(emailCampaigns.weddingId, input.weddingId)).orderBy(desc(emailCampaigns.createdAt));
        const logs = await db.select().from(emailLogs);
        const sent = logs.filter(l => l.status === "sent").length;
        const failed = logs.filter(l => l.status === "failed").length;
        return { total: logs.length, sent, failed, campaigns };
      }),
  }),

  // ─── Assistant Devis ────────────────────────────────────────────────────────────
  quoteAssistant: router({
    analyze: protectedProcedure
      .input(z.object({
        weddingId: z.number(),
        providerCategory: z.string(),
        providerName: z.string(),
        quoteAmount: z.number(),
        quoteDetails: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");

        const weddingRows = await db.select().from(weddings).where(eq(weddings.id, input.weddingId)).limit(1);
        const wedding = weddingRows[0];

        const prompt = `Tu es un expert en mariage français. Analyse ce devis et donne des conseils concrets.
Prestataire: ${input.providerName} (${input.providerCategory})
Montant: ${input.quoteAmount}€
Détails: ${input.quoteDetails ?? "Non précisé"}
Contexte mariage: ${wedding?.guestCount ?? "?"} invités, budget total ${wedding?.totalBudget ?? "?"}€, ville: ${wedding?.city ?? "?"}

Réponds en JSON strict avec:
{
  "assessment": "bon_prix|prix_moyen|prix_eleve|prix_tres_eleve",
  "marketComparison": "phrase comparant au marché",
  "counterOfferSuggestion": nombre ou null,
  "questionsToAsk": ["question1", "question2", "question3"],
  "redFlags": ["point vigilance 1"],
  "positivePoints": ["point positif 1"],
  "recommendation": "phrase de recommandation finale"
}`;

        const response = await invokeLLM({
          messages: [{ role: "user", content: prompt }],
          response_format: { type: "json_schema", json_schema: {
            name: "quote_analysis", strict: true,
            schema: { type: "object", properties: {
              assessment: { type: "string" },
              marketComparison: { type: "string" },
              counterOfferSuggestion: { type: ["number", "null"] as unknown as "number" },
              questionsToAsk: { type: "array", items: { type: "string" } },
              redFlags: { type: "array", items: { type: "string" } },
              positivePoints: { type: "array", items: { type: "string" } },
              recommendation: { type: "string" },
            }, required: ["assessment","marketComparison","counterOfferSuggestion","questionsToAsk","redFlags","positivePoints","recommendation"], additionalProperties: false }
          }}
        });

        return JSON.parse(response.choices[0].message.content as string);
      }),
  }),

  // ─── Matching Prestataires ─────────────────────────────────────────────────────
  matching: router({
    list: protectedProcedure
      .input(z.object({ weddingId: z.number() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return [];
        return db.select().from(providerMatches)
          .where(eq(providerMatches.weddingId, input.weddingId))
          .orderBy(desc(providerMatches.compatibilityScore));
      }),

    generate: protectedProcedure
      .input(z.object({ weddingId: z.number() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");

        const weddingRows = await db.select().from(weddings).where(eq(weddings.id, input.weddingId)).limit(1);
        const wedding = weddingRows[0];
        if (!wedding) throw new Error("Wedding not found");

        const existingProviders = await db.select().from(providers).where(eq(providers.weddingId, input.weddingId));
        const bookedCategories = existingProviders.filter(p => p.status === "booked").map(p => p.category);

        const prompt = `Tu es un expert wedding planner français. Génère des suggestions de prestataires fictifs mais réalistes pour ce mariage.
Style: ${wedding.style ?? "non défini"}, Budget: ${wedding.totalBudget ?? "?"}€, Invités: ${wedding.guestCount ?? "?"}, Ville: ${wedding.city ?? "?"}
Catégories déjà réservées: ${bookedCategories.join(", ") || "aucune"}

Génère 8 suggestions de prestataires (catégories non encore réservées) en JSON:
{"matches": [{"category":"photographer|videographer|caterer|florist|music|venue|transport|beauty|cake|animation|officiant","suggestedName":"Nom Studio/Prestataire","suggestedCity":"Ville","suggestedEmail":"email@exemple.fr","suggestedWebsite":"https://...","compatibilityScore":85,"justification":"Raison précise de la compatibilité","estimatedPrice":"1500€ - 2500€"}]}`;

        const response = await invokeLLM({
          messages: [{ role: "user", content: prompt }],
          response_format: { type: "json_schema", json_schema: { name: "provider_matches", strict: true, schema: { type: "object", properties: { matches: { type: "array", items: { type: "object", properties: { category: { type: "string" }, suggestedName: { type: "string" }, suggestedCity: { type: "string" }, suggestedEmail: { type: "string" }, suggestedWebsite: { type: "string" }, compatibilityScore: { type: "number" }, justification: { type: "string" }, estimatedPrice: { type: "string" } }, required: ["category","suggestedName","suggestedCity","suggestedEmail","suggestedWebsite","compatibilityScore","justification","estimatedPrice"], additionalProperties: false } } }, required: ["matches"], additionalProperties: false } } } as any,
        });

        const parsed = JSON.parse(response.choices[0].message.content as string);
        const matches = parsed.matches ?? [];

        await db.delete(providerMatches).where(eq(providerMatches.weddingId, input.weddingId));

        const validCategories = ["photographer","videographer","caterer","florist","music","venue","transport","beauty","dress","suit","cake","animation","officiant","other"] as const;

        for (const m of matches) {
          await db.insert(providerMatches).values({
            weddingId: input.weddingId,
            category: validCategories.includes(m.category as typeof validCategories[number]) ? m.category as typeof validCategories[number] : "other",
            suggestedName: m.suggestedName,
            suggestedCity: m.suggestedCity,
            suggestedEmail: m.suggestedEmail,
            suggestedWebsite: m.suggestedWebsite,
            compatibilityScore: Math.min(100, Math.max(0, m.compatibilityScore)),
            justification: m.justification,
            estimatedPrice: m.estimatedPrice,
            status: "suggested",
          });
        }

        return { generated: matches.length };
      }),

    updateStatus: protectedProcedure
      .input(z.object({
        matchId: z.number(),
        status: z.enum(["suggested", "contacted", "added", "dismissed"]),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        await db.update(providerMatches).set({ status: input.status }).where(eq(providerMatches.id, input.matchId));
        return { success: true };
      }),
  }),

  // ─── Mémoire Narrative ─────────────────────────────────────────────────────────
  narrative: router({
    list: protectedProcedure
      .input(z.object({ weddingId: z.number() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return [];
        return db.select().from(narrativeMemories)
          .where(eq(narrativeMemories.weddingId, input.weddingId))
          .orderBy(desc(narrativeMemories.createdAt));
      }),

    generate: protectedProcedure
      .input(z.object({
        weddingId: z.number(),
        style: z.enum(["romantic", "poetic", "humorous", "classic"]).default("romantic"),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");

        const weddingRows = await db.select().from(weddings).where(eq(weddings.id, input.weddingId)).limit(1);
        const wedding = weddingRows[0];
        if (!wedding) throw new Error("Wedding not found");

        const memoriesData = await db.select().from(memories).where(eq(memories.weddingId, input.weddingId));
        const timelineData = await db.select().from(timelineEvents).where(eq(timelineEvents.weddingId, input.weddingId));

        const stylePrompts = {
          romantic: "romantique et émouvant, plein de tendresse",
          poetic: "poétique et littéraire, avec des métaphores",
          humorous: "léger et humoristique, avec des touches de douceur",
          classic: "classique et élégant, comme un discours de mariage",
        };

        const memoriesText = memoriesData.map(m => `- ${m.title}: ${m.content ?? ""}`).join("\n");
        const timelineText = timelineData.map(t => `- ${t.title} (${t.category})`).join("\n");

        const prompt = `Tu es un écrivain spécialisé dans les récits de mariage. Écris un récit ${stylePrompts[input.style]} de 3-4 paragraphes pour ce mariage.

Mariés: ${wedding.partner1Name ?? "Partenaire 1"} & ${wedding.partner2Name ?? "Partenaire 2"}
Date: ${wedding.weddingDate ? new Date(wedding.weddingDate).toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" }) : "à venir"}
Lieu: ${wedding.venue ?? wedding.city ?? "lieu de rêve"}
Style: ${wedding.style ?? "élégant"}
${memoriesText ? `\nSouvenirs notés:\n${memoriesText}` : ""}
${timelineText ? `\nMoments planifiés:\n${timelineText}` : ""}

Écris un récit beau et personnel, comme si tu racontais leur histoire à leurs invités. Utilise leurs prénoms.`;

        const response = await invokeLLM({
          messages: [
            { role: "system", content: "Tu es un écrivain expert en récits de mariage. Tu écris en français, avec élégance et émotion." },
            { role: "user", content: prompt }
          ]
        });

        const narrative = response.choices[0].message.content as string;

        // Compter les versions existantes
        const existing = await db.select().from(narrativeMemories).where(eq(narrativeMemories.weddingId, input.weddingId));
        const version = existing.length + 1;

        await db.insert(narrativeMemories).values({
          weddingId: input.weddingId,
          narrative,
          style: input.style,
          version,
          approved: false,
        });

        const created = await db.select().from(narrativeMemories)
          .where(eq(narrativeMemories.weddingId, input.weddingId))
          .orderBy(desc(narrativeMemories.createdAt)).limit(1);
        return created[0];
      }),

    approve: protectedProcedure
      .input(z.object({ narrativeId: z.number() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        await db.update(narrativeMemories).set({ approved: true, approvedAt: new Date() }).where(eq(narrativeMemories.id, input.narrativeId));
        return { success: true };
      }),
    update: protectedProcedure
      .input(z.object({ narrativeId: z.number(), narrative: z.string().min(10) }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        await db.update(narrativeMemories).set({ narrative: input.narrative }).where(eq(narrativeMemories.id, input.narrativeId));
        return { success: true };
      }),
  }),

  // ─── Génération Timeline Jour J ────────────────────────────────────────────────
  generateDayOfTimeline: protectedProcedure
    .input(z.object({ weddingId: z.number() }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");

      const weddingRows = await db.select().from(weddings).where(eq(weddings.id, input.weddingId)).limit(1);
      const wedding = weddingRows[0];
      if (!wedding) throw new Error("Wedding not found");

      const existingProviders = await db.select().from(providers).where(eq(providers.weddingId, input.weddingId));

      const prompt = `Tu es un expert wedding planner français. Génère une timeline détaillée du Jour J pour ce mariage.
Mariés: ${wedding.partner1Name ?? "?"} & ${wedding.partner2Name ?? "?"}
Date: ${wedding.weddingDate ? new Date(wedding.weddingDate).toLocaleDateString("fr-FR") : "?"}
Lieu: ${wedding.venue ?? wedding.city ?? "?"}
Invités: ${wedding.guestCount ?? "?"}
Style: ${wedding.style ?? "classique"}
Prestataires réservés: ${existingProviders.filter(p => p.status === "booked").map(p => p.category).join(", ") || "non précisé"}

Génère une timeline complète du Jour J avec des horaires réalistes en JSON:
{"events": [{"title":"...","category":"ceremony|reception|preparation|photo|transport|dinner|entertainment|other","scheduledTime":"HH:MM","durationMinutes":N,"location":"...","notes":"...","providerCategory":"photographer|caterer|...ou null"}]}
Commence par les préparatifs (8h-10h) et termine par la fin de soirée. Inclus les temps de trajet et marges.`;

      const response = await invokeLLM({
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_schema", json_schema: { name: "day_of_timeline", strict: true, schema: { type: "object", properties: { events: { type: "array", items: { type: "object", properties: { title: { type: "string" }, category: { type: "string" }, scheduledTime: { type: "string" }, durationMinutes: { type: "number" }, location: { type: "string" }, notes: { type: "string" }, providerCategory: { type: "string" } }, required: ["title","category","scheduledTime","durationMinutes","location","notes","providerCategory"], additionalProperties: false } } }, required: ["events"], additionalProperties: false } } } as any,
      });

      const parsed = JSON.parse(response.choices[0].message.content as string);
      const events = parsed.events ?? [];

      const validCategories = ["ceremony","reception","preparation","photo","transport","dinner","entertainment","administrative","other"] as const;
      const weddingDateBase = wedding.weddingDate ? new Date(wedding.weddingDate) : new Date();

      // Supprimer les anciens événements Jour J et créer les nouveaux
      await db.delete(dayOfEvents).where(eq(dayOfEvents.weddingId, input.weddingId));

      for (const e of events) {
        const [hours, minutes] = (e.scheduledTime as string).split(":").map(Number);
        const scheduledTime = new Date(weddingDateBase);
        scheduledTime.setHours(hours ?? 9, minutes ?? 0, 0, 0);

        // Trouver le prestataire correspondant si précisé
        let providerId: number | undefined;
        if (e.providerCategory) {
          const matchedProvider = existingProviders.find(p => p.category === e.providerCategory && p.status === "booked");
          if (matchedProvider) providerId = matchedProvider.id;
        }

        await db.insert(dayOfEvents).values({
          weddingId: input.weddingId,
          title: e.title,
          scheduledTime,
          status: "upcoming",
          notes: `${e.notes}${e.location ? ` | Lieu: ${e.location}` : ""}`,
          delayMinutes: 0,
          notifiedProviders: false,
        });

        // Aussi créer dans timelineEvents pour la vue planning
        await db.insert(timelineEvents).values({
          weddingId: input.weddingId,
          title: e.title,
          category: validCategories.includes(e.category as typeof validCategories[number]) ? e.category as typeof validCategories[number] : "other",
          scheduledAt: scheduledTime,
          durationMinutes: e.durationMinutes,
          location: e.location,
          notes: e.notes,
          providerId,
          status: "confirmed",
          sortOrder: events.indexOf(e),
        });
      }

      return { generated: events.length };
    }),

  // ─── Scénario de Crise Jour J ────────────────────────────────────────────────
  crisis: router({
    handle: protectedProcedure
      .input(z.object({
        weddingId: z.number(),
        crisisType: z.enum(["delay", "cancellation", "weather", "other"]),
        providerName: z.string(),
        delayMinutes: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        const weddingRows = await db.select().from(weddings).where(eq(weddings.id, input.weddingId)).limit(1);
        const wedding = weddingRows[0];
        if (!wedding) throw new Error("Wedding not found");
        const dayEvents = await db.select().from(dayOfEvents).where(eq(dayOfEvents.weddingId, input.weddingId)).orderBy(dayOfEvents.scheduledTime);
        const crisisDescriptions: Record<string, string> = {
          delay: `Le prestataire "${input.providerName}" a ${input.delayMinutes ?? 30} minutes de retard.`,
          cancellation: `Le prestataire "${input.providerName}" vient d'annuler sa prestation.`,
          weather: `Météo défavorable : le prestataire "${input.providerName}" signale un problème lié à la météo.`,
          other: `Imprévu signalé par le prestataire "${input.providerName}".`,
        };
        const prompt = `Tu es un expert wedding planner de crise. Situation d'urgence le jour du mariage.
Mariage: ${wedding.partner1Name ?? "?"} & ${wedding.partner2Name ?? "?"} - ${wedding.weddingDate ? new Date(wedding.weddingDate).toLocaleDateString("fr-FR") : "?"}
Crise: ${crisisDescriptions[input.crisisType]}
Timeline actuelle: ${dayEvents.slice(0, 8).map(e => `${e.title} à ${e.scheduledTime ? new Date(e.scheduledTime).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" }) : "?"}`).join(", ")}

Génère un plan de crise détaillé en français avec:
1. Actions immédiates (dans les 5 prochaines minutes)
2. Ajustements du planning (quels événements décaler et de combien)
3. Communications à envoyer (prestataires, invités, famille)
4. Solutions alternatives si disponibles
5. Message rassurant pour les mariés
Sois concret, actionnable et rassurant.`;
        const response = await invokeLLM({ messages: [{ role: "user", content: prompt }] });
        const plan = (response.choices[0].message.content as string) ?? "Plan de crise non disponible.";
        return { plan, crisisType: input.crisisType, providerName: input.providerName };
      }),
  }),
});

// ─── Helper : propager les réponses d'onboarding vers tous les modules ─────────
async function propagateOnboardingToModules(db: NonNullable<Awaited<ReturnType<typeof getDb>>>, weddingId: number, _userId: number, answers: Record<string, unknown>) {
  // 1. Mettre à jour le profil du mariage
  const updateData: Partial<typeof weddings.$inferInsert> = {};

  if (answers.names && typeof answers.names === "string") {
    const parts = answers.names.split(/[&,\/]/).map((s: string) => s.trim());
    if (parts[0]) updateData.partner1Name = parts[0];
    if (parts[1]) updateData.partner2Name = parts[1];
  }
  if (answers.weddingDate && typeof answers.weddingDate === "string") {
    const d = new Date(answers.weddingDate);
    if (!isNaN(d.getTime())) updateData.weddingDate = d;
  }
  if (answers.venue && typeof answers.venue === "string" && answers.venue !== "Pas encore décidé") {
    updateData.venue = answers.venue;
  }
  if (answers.city && typeof answers.city === "string") updateData.city = answers.city;
  if (answers.guestCount) updateData.guestCount = Number(answers.guestCount);
  if (answers.budget) updateData.totalBudget = String(answers.budget);
  if (answers.style && typeof answers.style === "string") updateData.style = answers.style;
  if (answers.dream && typeof answers.dream === "string") updateData.notes = answers.dream;

  if (Object.keys(updateData).length > 0) {
    await db.update(weddings).set(updateData).where(eq(weddings.id, weddingId));
  }

  // 2. Créer des prestataires "shortlistés" pour les catégories déjà réservées
  if (Array.isArray(answers.bookedProviders)) {
    const categoryMap: Record<string, typeof providers.$inferInsert["category"]> = {
      "Photographe": "photographer", "Vidéaste": "videographer", "Traiteur": "caterer",
      "Salle/Domaine": "venue", "DJ/Groupe": "music", "Fleuriste": "florist",
      "Coiffeur/Maquilleur": "beauty", "Officiant": "officiant",
    };
    for (const bookedName of answers.bookedProviders as string[]) {
      if (bookedName === "Aucun pour l'instant") continue;
      const cat = categoryMap[bookedName];
      if (!cat) continue;
      const existing = await db.select().from(providers)
        .where(and(eq(providers.weddingId, weddingId), eq(providers.category, cat))).limit(1);
      if (existing.length === 0) {
        await db.insert(providers).values({
          weddingId, name: `${bookedName} (à préciser)`, category: cat, status: "booked",
        });
      }
    }
  }

  // 3. Créer des postes budgétaires estimatifs
  const budget = Number(answers.budget ?? 0);
  if (budget > 0) {
    const existingBudget = await db.select().from(budgetItems).where(eq(budgetItems.weddingId, weddingId));
    if (existingBudget.length === 0) {
      const guestCount = Number(answers.guestCount ?? 100);
      const budgetDistribution: Array<{ category: typeof budgetItems.$inferInsert["category"]; label: string; pct: number }> = [
        { category: "catering", label: "Traiteur & boissons", pct: 0.35 },
        { category: "venue", label: "Salle de réception", pct: 0.20 },
        { category: "photography", label: "Photographe", pct: 0.10 },
        { category: "music", label: "DJ / Animation musicale", pct: 0.08 },
        { category: "flowers", label: "Fleurs & décoration", pct: 0.07 },
        { category: "dress", label: "Robe de mariée", pct: 0.06 },
        { category: "beauty", label: "Coiffure & maquillage", pct: 0.04 },
        { category: "invitations", label: "Faire-part & papeterie", pct: 0.03 },
        { category: "transport", label: "Transport & voiture", pct: 0.03 },
        { category: "other", label: "Divers & imprévus", pct: 0.04 },
      ];
      for (const item of budgetDistribution) {
        await db.insert(budgetItems).values({
          weddingId, category: item.category, label: item.label,
          estimatedAmount: String(Math.round(budget * item.pct)),
        });
      }
      void guestCount; // suppress unused warning
    }
  }
}
