import { z } from "zod";
import { eq } from "drizzle-orm";
import Stripe from "stripe";
import { protectedProcedure, publicProcedure, router } from "../_core/trpc";
import { getDb } from "../db";
import { subscriptions, users } from "../../drizzle/schema";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "", { apiVersion: "2025-04-30" as any });

// ─── Plans AURA ──────────────────────────────────────────────────────────────
export const AURA_PLANS = {
  free: {
    name: "Gratuit",
    price: 0,
    priceId: null,
    features: [
      "Cockpit Mariés complet",
      "IA AURA (10 messages/jour)",
      "Jusqu'à 50 invités",
      "Mini-site basique",
      "Timeline & Budget",
    ],
    limits: { aiMessages: 10, guests: 50, documents: 5 },
    color: "#aab5c8",
  },
  essentiel: {
    name: "Essentiel",
    price: 1900, // 19€/mois en centimes
    priceId: process.env.STRIPE_PRICE_ESSENTIEL || "price_essentiel",
    features: [
      "Tout du plan Gratuit",
      "IA AURA illimitée",
      "Jusqu'à 150 invités",
      "Mini-site personnalisé",
      "Emails groupés (500/mois)",
      "Plan de table drag & drop",
      "Export PDF timeline",
    ],
    limits: { aiMessages: -1, guests: 150, documents: 50 },
    color: "#60B4C8",
  },
  premium: {
    name: "Premium",
    price: 3900, // 39€/mois
    priceId: process.env.STRIPE_PRICE_PREMIUM || "price_premium",
    features: [
      "Tout du plan Essentiel",
      "Invités illimités",
      "Matching prestataire IA",
      "Signature électronique",
      "Coordination Jour J temps réel",
      "Mur photo IA",
      "Mémoire narrative IA",
      "Support prioritaire",
    ],
    limits: { aiMessages: -1, guests: -1, documents: -1 },
    color: "#F07167",
  },
  prestige: {
    name: "Prestige",
    price: 7900, // 79€/mois
    priceId: process.env.STRIPE_PRICE_PRESTIGE || "price_prestige",
    features: [
      "Tout du plan Premium",
      "Wedding planner IA dédié",
      "Onboarding personnalisé 1h",
      "Livre souvenir IA offert",
      "Accès anticipé aux nouvelles fonctionnalités",
      "Support téléphonique 7j/7",
    ],
    limits: { aiMessages: -1, guests: -1, documents: -1 },
    color: "#9B59B6",
  },
} as const;

export const subscriptionsRouter = router({
  // Récupérer l'abonnement actuel
  getCurrent: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return { plan: "free" as const, status: "active" as const };

    const rows = await db.select().from(subscriptions).where(eq(subscriptions.userId, ctx.user.id)).limit(1);
    if (!rows[0]) return { plan: "free" as const, status: "active" as const };
    return rows[0];
  }),

  // Récupérer tous les plans disponibles
  getPlans: publicProcedure.query(() => {
    return Object.entries(AURA_PLANS).map(([key, plan]) => ({ id: key, ...plan }));
  }),

  // Créer une session Stripe Checkout
  createCheckout: protectedProcedure
    .input(z.object({
      plan: z.enum(["essentiel", "premium", "prestige"]),
      origin: z.string(),
      successUrl: z.string().optional(),
      cancelUrl: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const planConfig = AURA_PLANS[input.plan];

      const session = await stripe.checkout.sessions.create({
        mode: "subscription",
        customer_email: ctx.user.email || undefined,
        line_items: [
          {
            price_data: {
              currency: "eur",
              product_data: {
                name: `AURA Wedding OS — Plan ${planConfig.name}`,
                description: planConfig.features.slice(0, 3).join(" · "),
              },
              unit_amount: planConfig.price,
              recurring: { interval: "month" },
            },
            quantity: 1,
          },
        ],
        allow_promotion_codes: true,
        client_reference_id: ctx.user.id.toString(),
        metadata: {
          user_id: ctx.user.id.toString(),
          plan: input.plan,
          customer_email: ctx.user.email || "",
          customer_name: ctx.user.name || "",
        },
        success_url: input.successUrl ?? `${input.origin}/cockpit?subscription=success&plan=${input.plan}`,
        cancel_url: input.cancelUrl ?? `${input.origin}/tarifs?canceled=true`,
      });

      return { checkoutUrl: session.url };
    }),

  // Créer un portail client Stripe (gérer l'abonnement)
  createPortal: protectedProcedure
    .input(z.object({ origin: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");

      const rows = await db.select().from(subscriptions).where(eq(subscriptions.userId, ctx.user.id)).limit(1);
      const sub = rows[0];
      if (!sub?.stripeCustomerId) throw new Error("Aucun abonnement actif trouvé.");

      const session = await stripe.billingPortal.sessions.create({
        customer: sub.stripeCustomerId,
        return_url: `${input.origin}/cockpit`,
      });

      return { portalUrl: session.url };
    }),
});
