import { z } from "zod";
import { router, publicProcedure, protectedProcedure } from "../_core/trpc";
import { getDb } from "../db";
import {
  providerSessions, providerProfiles, providerContracts,
  providerMissions, providerInvitations, providers, weddings,
  providerNotifications
} from "../../drizzle/schema";
import { eq, and, desc } from "drizzle-orm";
import { nanoid } from "nanoid";
import { notifyOwner } from "../_core/notification";
import { sendPushToUser, PushTemplates } from "../_core/pushNotification";

// ─── Helpers ─────────────────────────────────────────────────────────────────
async function getSessionByToken(token: string) {
  const db = await getDb();
  if (!db) return null;
  const [session] = await db.select().from(providerSessions)
    .where(eq(providerSessions.sessionToken, token)).limit(1);
  if (!session) return null;
  if (new Date(session.expiresAt) < new Date()) return null;
  return session;
}

// ─── Provider Space Router ────────────────────────────────────────────────────
export const providerSpaceRouter = router({

  // Accepter l'invitation et créer une session prestataire
  acceptAndCreateSession: publicProcedure
    .input(z.object({ invitationToken: z.string() }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");

      const [invitation] = await db.select().from(providerInvitations)
        .where(eq(providerInvitations.token, input.invitationToken)).limit(1);
      if (!invitation) throw new Error("Invitation invalide");

      // Marquer comme acceptée
      await db.update(providerInvitations)
        .set({ accepted: true, acceptedAt: new Date() })
        .where(eq(providerInvitations.id, invitation.id));

      // Créer une session de 30 jours
      const sessionToken = nanoid(64);
      const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
      await db.insert(providerSessions).values({
        invitationId: invitation.id,
        providerId: invitation.providerId,
        weddingId: invitation.weddingId,
        sessionToken,
        expiresAt,
      });

      // Notification pour les mariés
      try {
        const [prov] = await db.select().from(providers)
          .where(eq(providers.id, invitation.providerId)).limit(1);
        await db.insert(providerNotifications).values({
          weddingId: invitation.weddingId,
          providerId: invitation.providerId,
          type: "invitation_accepted",
          title: `${prov?.name ?? "Un prestataire"} a accepté votre invitation`,
          message: `${prov?.name ?? "Le prestataire"} a rejoint votre espace AURA et peut maintenant accéder à ses missions et contrats.`,
          isRead: false,
        });
        // Rappel email owner
        await notifyOwner({
          title: `🎉 ${prov?.name ?? "Un prestataire"} a accepté votre invitation`,
          content: `Bonne nouvelle ! ${prov?.name ?? "Votre prestataire"} a rejoint votre espace AURA Wedding OS.\n\nIl peut maintenant consulter ses missions, signer les contrats et mettre à jour son profil.\n\nConnectez-vous à votre Cockpit pour en savoir plus.`,
        }).catch(() => {});
        // Notification push navigateur
        const [wed] = await db.select().from(weddings)
          .where(eq(weddings.id, invitation.weddingId)).limit(1);
        if (wed) {
          sendPushToUser(
            String(wed.userId),
            PushTemplates.invitationAccepted(prov?.name ?? "Prestataire", prov?.category ?? "")
          ).catch(() => {});
        }
      } catch (_) { /* non bloquant */ }
      return { sessionToken, expiresAt };
    }),

  // Obtenir le contexte complet du tableau de bord prestataire
  getDashboard: publicProcedure
    .input(z.object({ sessionToken: z.string() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return null;

      const session = await getSessionByToken(input.sessionToken);
      if (!session) return null;

      const [provider] = await db.select().from(providers)
        .where(eq(providers.id, session.providerId)).limit(1);
      const [wedding] = await db.select().from(weddings)
        .where(eq(weddings.id, session.weddingId)).limit(1);

      const missions = await db.select().from(providerMissions)
        .where(and(
          eq(providerMissions.providerId, session.providerId),
          eq(providerMissions.weddingId, session.weddingId)
        )).orderBy(providerMissions.scheduledAt);

      const contracts = await db.select().from(providerContracts)
        .where(and(
          eq(providerContracts.providerId, session.providerId),
          eq(providerContracts.weddingId, session.weddingId)
        )).orderBy(desc(providerContracts.createdAt));

      const [profile] = await db.select().from(providerProfiles)
        .where(eq(providerProfiles.providerId, session.providerId)).limit(1);

      return { provider, wedding, missions, contracts, profile: profile ?? null, session };
    }),

  // Gestion des missions
  missions: router({
    list: publicProcedure
      .input(z.object({ sessionToken: z.string() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return [];
        const session = await getSessionByToken(input.sessionToken);
        if (!session) return [];
        return db.select().from(providerMissions)
          .where(and(
            eq(providerMissions.providerId, session.providerId),
            eq(providerMissions.weddingId, session.weddingId)
          )).orderBy(providerMissions.scheduledAt);
      }),

    updateStatus: publicProcedure
      .input(z.object({
        sessionToken: z.string(),
        missionId: z.number(),
        status: z.enum(["pending", "confirmed", "in_progress", "done", "cancelled"]),
        providerNotes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        const session = await getSessionByToken(input.sessionToken);
        if (!session) throw new Error("Session invalide");
        await db.update(providerMissions)
          .set({ status: input.status, providerNotes: input.providerNotes })
          .where(and(
            eq(providerMissions.id, input.missionId),
            eq(providerMissions.providerId, session.providerId)
          ));
        return { success: true };
      }),
  }),

  // Gestion des contrats
  contracts: router({
    list: publicProcedure
      .input(z.object({ sessionToken: z.string() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return [];
        const session = await getSessionByToken(input.sessionToken);
        if (!session) return [];
        return db.select().from(providerContracts)
          .where(and(
            eq(providerContracts.providerId, session.providerId),
            eq(providerContracts.weddingId, session.weddingId)
          )).orderBy(desc(providerContracts.createdAt));
      }),

    // Créer un contrat (par les mariés depuis le cockpit)
    create: protectedProcedure
      .input(z.object({
        providerId: z.number(),
        title: z.string(),
        content: z.string().optional(),
        amount: z.string().optional(),
        depositAmount: z.string().optional(),
        validUntil: z.string().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        const [wedding] = await db.select().from(weddings)
          .where(eq(weddings.userId, ctx.user.id)).limit(1);
        if (!wedding) throw new Error("Mariage introuvable");
        const [contract] = await db.insert(providerContracts).values({
          weddingId: wedding.id,
          providerId: input.providerId,
          title: input.title,
          content: input.content,
          amount: input.amount,
          depositAmount: input.depositAmount,
          validUntil: input.validUntil ? new Date(input.validUntil) : undefined,
          notes: input.notes,
          status: "sent",
        }).$returningId();
        return { id: contract.id };
      }),

    // Signer un contrat côté prestataire
    signAsProvider: publicProcedure
      .input(z.object({
        sessionToken: z.string(),
        contractId: z.number(),
        signatureData: z.string(), // base64 du canvas
        signerName: z.string(),
      }))
      .mutation(async ({ input, ctx }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        const session = await getSessionByToken(input.sessionToken);
        if (!session) throw new Error("Session invalide");

        const [contract] = await db.select().from(providerContracts)
          .where(and(
            eq(providerContracts.id, input.contractId),
            eq(providerContracts.providerId, session.providerId)
          )).limit(1);
        if (!contract) throw new Error("Contrat introuvable");

        const newStatus = contract.coupleSignatureData
          ? "fully_signed" as const
          : "signed_provider" as const;

        await db.update(providerContracts).set({
          providerSignatureData: input.signatureData,
          providerSignedAt: new Date(),
          providerSignerName: input.signerName,
          signatureIpProvider: (ctx.req as any).ip ?? "unknown",
          status: newStatus,
        }).where(eq(providerContracts.id, input.contractId));

        // Notification pour les mariés
        try {
          const [prov] = await db.select().from(providers)
            .where(eq(providers.id, session.providerId)).limit(1);
          await db.insert(providerNotifications).values({
            weddingId: session.weddingId,
            providerId: session.providerId,
            type: "contract_signed",
            title: `Contrat signé par ${input.signerName}`,
            message: `${prov?.name ?? "Votre prestataire"} a signé le contrat "${contract.title}". Vous pouvez maintenant le contre-signer depuis le Cockpit.`,
            isRead: false,
          });
          // Rappel email owner
          await notifyOwner({
            title: `✍️ Contrat signé par ${input.signerName}`,
            content: `${prov?.name ?? "Votre prestataire"} a signé le contrat "${contract.title}".\n\nVous pouvez maintenant le contre-signer depuis votre Cockpit AURA pour finaliser l'accord.`,
          }).catch(() => {});
          // Notification push navigateur
          const [wed2] = await db.select().from(weddings)
            .where(eq(weddings.id, session.weddingId)).limit(1);
          if (wed2) {
            sendPushToUser(
              String(wed2.userId),
              PushTemplates.contractSigned(prov?.name ?? "Prestataire")
            ).catch(() => {});
          }
        } catch (_) { /* non bloquant */ }
        return { success: true, status: newStatus };
      }),

    // Signer un contrat côté mariés (depuis le cockpit)
    signAsCouple: protectedProcedure
      .input(z.object({
        contractId: z.number(),
        signatureData: z.string(),
        signerName: z.string(),
      }))
      .mutation(async ({ input, ctx }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");

        const [contract] = await db.select().from(providerContracts)
          .where(eq(providerContracts.id, input.contractId)).limit(1);
        if (!contract) throw new Error("Contrat introuvable");

        const newStatus = contract.providerSignatureData
          ? "fully_signed" as const
          : "signed_couple" as const;

        await db.update(providerContracts).set({
          coupleSignatureData: input.signatureData,
          coupleSignedAt: new Date(),
          coupleSignerName: input.signerName,
          signatureIpCouple: (ctx.req as any).ip ?? "unknown",
          status: newStatus,
        }).where(eq(providerContracts.id, input.contractId));

        return { success: true, status: newStatus };
      }),

    // Marquer un paiement
    markPayment: protectedProcedure
      .input(z.object({
        contractId: z.number(),
        type: z.enum(["deposit", "balance"]),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        const updates = input.type === "deposit"
          ? { depositPaid: true, depositPaidAt: new Date() }
          : { balancePaid: true, balancePaidAt: new Date() };
        await db.update(providerContracts).set(updates)
          .where(eq(providerContracts.id, input.contractId));
        // Notification pour les mariés
        try {
          const [contract] = await db.select().from(providerContracts)
            .where(eq(providerContracts.id, input.contractId)).limit(1);
          if (contract) {
            const [prov] = await db.select().from(providers)
              .where(eq(providers.id, contract.providerId)).limit(1);
            const label = input.type === "deposit" ? "Acompte reçu" : "Solde reçu";
            await db.insert(providerNotifications).values({
              weddingId: contract.weddingId,
              providerId: contract.providerId,
              type: "payment_received",
              title: `${label} — ${prov?.name ?? "Prestataire"}`,
              message: `Le paiement (${input.type === "deposit" ? "acompte" : "solde"}) pour le contrat "${contract.title}" a été enregistré.`,
              isRead: false,
            });
            // Rappel email owner
            const labelPay = input.type === "deposit" ? "acompte" : "solde";
            await notifyOwner({
              title: `💳 ${label} — ${prov?.name ?? "Prestataire"}`,
              content: `Le paiement (${labelPay}) pour le contrat "${contract.title}" a été enregistré avec succès dans votre espace AURA.\n\nConsultez votre module Contrats pour les détails.`,
            }).catch(() => {});
            // Notification push navigateur
            const [wed3] = await db.select().from(weddings)
              .where(eq(weddings.id, contract.weddingId)).limit(1);
            if (wed3) {
              const amountStr = input.type === "deposit"
                ? (contract.depositAmount ? `${contract.depositAmount}€` : "")
                : (contract.amount ? `${contract.amount}€` : "");
              sendPushToUser(
                String(wed3.userId),
                PushTemplates.paymentReceived(prov?.name ?? "Prestataire", amountStr)
              ).catch(() => {});
            }
          }
        } catch (_) { /* non bloquant */ }
        return { success: true };
      }),
  }),

  // Profil prestataire
  profile: router({
    get: publicProcedure
      .input(z.object({ sessionToken: z.string() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return null;
        const session = await getSessionByToken(input.sessionToken);
        if (!session) return null;
        const [profile] = await db.select().from(providerProfiles)
          .where(eq(providerProfiles.providerId, session.providerId)).limit(1);
        return profile ?? null;
      }),

    upsert: publicProcedure
      .input(z.object({
        sessionToken: z.string(),
        businessName: z.string().optional(),
        bio: z.string().optional(),
        city: z.string().optional(),
        phone: z.string().optional(),
        email: z.string().optional(),
        website: z.string().optional(),
        instagram: z.string().optional(),
        basePrice: z.string().optional(),
        ibanHolder: z.string().optional(),
        ibanFull: z.string().optional(),
        availabilityNotes: z.string().optional(),
        tags: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        const session = await getSessionByToken(input.sessionToken);
        if (!session) throw new Error("Session invalide");

        const { sessionToken, ...profileData } = input;
        const ibanLast4 = profileData.ibanFull
          ? profileData.ibanFull.replace(/\s/g, "").slice(-4)
          : undefined;

        const existing = await db.select().from(providerProfiles)
          .where(eq(providerProfiles.providerId, session.providerId)).limit(1);

        if (existing.length > 0) {
          await db.update(providerProfiles)
            .set({ ...profileData, ibanLast4, updatedAt: new Date() })
            .where(eq(providerProfiles.providerId, session.providerId));
        } else {
          await db.insert(providerProfiles).values({
            userId: session.providerId,
            providerId: session.providerId,
            ...profileData,
            ibanLast4,
          });
        }
        return { success: true };
      }),
  }),

  // Contrats côté cockpit mariés : liste tous les contrats du mariage
  coupleContracts: router({
    list: protectedProcedure
      .query(async ({ ctx }) => {
        const db = await getDb();
        if (!db) return [];
        const [wedding] = await db.select().from(weddings)
          .where(eq(weddings.userId, ctx.user.id)).limit(1);
        if (!wedding) return [];
        return db.select().from(providerContracts)
          .where(eq(providerContracts.weddingId, wedding.id))
          .orderBy(desc(providerContracts.createdAt));
      }),

    addMission: protectedProcedure
      .input(z.object({
        providerId: z.number(),
        contractId: z.number().optional(),
        title: z.string(),
        description: z.string().optional(),
        scheduledAt: z.string().optional(),
        durationMinutes: z.number().optional(),
        location: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        const [wedding] = await db.select().from(weddings)
          .where(eq(weddings.userId, ctx.user.id)).limit(1);
        if (!wedding) throw new Error("Mariage introuvable");
        await db.insert(providerMissions).values({
          weddingId: wedding.id,
          providerId: input.providerId,
          contractId: input.contractId,
          title: input.title,
          description: input.description,
          scheduledAt: input.scheduledAt ? new Date(input.scheduledAt) : undefined,
          durationMinutes: input.durationMinutes ?? 60,
          location: input.location,
        });
        return { success: true };
      }),
  }),
});
