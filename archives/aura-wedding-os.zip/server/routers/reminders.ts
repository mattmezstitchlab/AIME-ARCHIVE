/**
 * Router Rappels Programmés — gestion des crons Heartbeat J-30 / J-7 / J-1
 *
 * - setup   : crée ou recrée les 3 crons en fonction de la date de mariage
 * - cancel  : supprime les 3 crons et efface les taskUids en DB
 * - status  : retourne l'état actuel des 3 crons
 */
import { TRPCError } from "@trpc/server";
import { parse as parseCookie } from "cookie";
import { COOKIE_NAME } from "@shared/const";
import { protectedProcedure, router } from "../_core/trpc";
import {
  createHeartbeatJob,
  deleteHeartbeatJob,
  listHeartbeatJobs,
} from "../_core/heartbeat";
import * as db from "../db";
import { weddings } from "../../drizzle/schema";
import { eq } from "drizzle-orm";

// Calcule le cron 6-field UTC pour un rappel à N jours avant la date de mariage
// Heure d'envoi : 08:00 UTC (10h Paris en été)
function buildCronForDaysBefore(weddingDate: Date, daysBefore: number): string {
  const d = new Date(weddingDate.getTime() - daysBefore * 24 * 60 * 60 * 1000);
  const sec = 0;
  const min = 0;
  const hour = 8;
  const dom = d.getUTCDate();
  const mon = d.getUTCMonth() + 1;
  const dow = "*";
  return `${sec} ${min} ${hour} ${dom} ${mon} ${dow}`;
}

export const remindersRouter = router({
  // ─── Status ────────────────────────────────────────────────────────────────
  status: protectedProcedure.query(async ({ ctx }) => {
    const wedding = await db.getWeddingByUserId(ctx.user.id);
    if (!wedding) return { active: false, weddingDate: null, reminders: [] };

    const active =
      !!wedding.reminderJ30TaskUid ||
      !!wedding.reminderJ7TaskUid ||
      !!wedding.reminderJ1TaskUid;

    return {
      active,
      weddingDate: wedding.weddingDate ?? null,
      reminders: [
        { label: "J-30", taskUid: wedding.reminderJ30TaskUid ?? null },
        { label: "J-7",  taskUid: wedding.reminderJ7TaskUid  ?? null },
        { label: "J-1",  taskUid: wedding.reminderJ1TaskUid  ?? null },
      ],
    };
  }),

  // ─── Setup ─────────────────────────────────────────────────────────────────
  setup: protectedProcedure.mutation(async ({ ctx }) => {
    const wedding = await db.getWeddingByUserId(ctx.user.id);
    if (!wedding) throw new TRPCError({ code: "NOT_FOUND", message: "Mariage introuvable" });
    if (!wedding.weddingDate) {
      throw new TRPCError({
        code: "BAD_REQUEST",
        message: "Veuillez d'abord définir la date de votre mariage dans les réglages.",
      });
    }

    const weddingDate = new Date(wedding.weddingDate);
    const now = new Date();

    // Vérifier que la date est dans le futur
    if (weddingDate.getTime() <= now.getTime()) {
      throw new TRPCError({
        code: "BAD_REQUEST",
        message: "La date de mariage est déjà passée. Les rappels ne peuvent pas être programmés.",
      });
    }

    const sessionToken = parseCookie(ctx.req.headers.cookie ?? "")[COOKIE_NAME] ?? "";
    if (!sessionToken) {
      throw new TRPCError({ code: "UNAUTHORIZED", message: "Session expirée" });
    }

    const partner1 = wedding.partner1Name ?? "Partenaire 1";
    const partner2 = wedding.partner2Name ?? "Partenaire 2";
    const weddingLabel = `${partner1} & ${partner2}`;

    // Supprimer les anciens crons si existants (idempotent)
    const oldUids = [
      wedding.reminderJ30TaskUid,
      wedding.reminderJ7TaskUid,
      wedding.reminderJ1TaskUid,
    ].filter(Boolean) as string[];

    for (const uid of oldUids) {
      try {
        await deleteHeartbeatJob(uid, sessionToken);
      } catch {
        // Ignorer si déjà supprimé
      }
    }

    const results: { label: string; taskUid: string; nextExecution: string | null }[] = [];
    const daysBeforeList = [
      { days: 30, label: "J-30" },
      { days: 7,  label: "J-7" },
      { days: 1,  label: "J-1" },
    ];

    let j30Uid: string | null = null;
    let j7Uid:  string | null = null;
    let j1Uid:  string | null = null;

    for (const { days, label } of daysBeforeList) {
      const reminderDate = new Date(weddingDate.getTime() - days * 24 * 60 * 60 * 1000);
      // Ne pas créer si la date du rappel est déjà passée
      if (reminderDate.getTime() <= now.getTime()) {
        results.push({ label, taskUid: "", nextExecution: null });
        continue;
      }

      const cron = buildCronForDaysBefore(weddingDate, days);
      const job = await createHeartbeatJob(
        {
          name: `wedding-reminder-${label.toLowerCase()}-${wedding.id}`,
          cron,
          path: "/api/scheduled/wedding-reminder",
          payload: { weddingId: wedding.id },
          description: `Rappel ${label} — Mariage de ${weddingLabel}`,
        },
        sessionToken
      );

      results.push({ label, taskUid: job.taskUid, nextExecution: job.nextExecutionAt ?? null });

      if (label === "J-30") j30Uid = job.taskUid;
      if (label === "J-7")  j7Uid  = job.taskUid;
      if (label === "J-1")  j1Uid  = job.taskUid;
    }

    // Persister les taskUids en DB
    const dbConn = await db.getDb();
    if (dbConn) {
      await dbConn.update(weddings)
        .set({
          reminderJ30TaskUid: j30Uid ?? undefined,
          reminderJ7TaskUid:  j7Uid  ?? undefined,
          reminderJ1TaskUid:  j1Uid  ?? undefined,
        })
        .where(eq(weddings.id, wedding.id));
    }

    return { success: true, reminders: results };
  }),

  // ─── Cancel ────────────────────────────────────────────────────────────────
  cancel: protectedProcedure.mutation(async ({ ctx }) => {
    const wedding = await db.getWeddingByUserId(ctx.user.id);
    if (!wedding) throw new TRPCError({ code: "NOT_FOUND", message: "Mariage introuvable" });

    const sessionToken = parseCookie(ctx.req.headers.cookie ?? "")[COOKIE_NAME] ?? "";
    if (!sessionToken) throw new TRPCError({ code: "UNAUTHORIZED", message: "Session expirée" });

    const uids = [
      wedding.reminderJ30TaskUid,
      wedding.reminderJ7TaskUid,
      wedding.reminderJ1TaskUid,
    ].filter(Boolean) as string[];

    for (const uid of uids) {
      try {
        await deleteHeartbeatJob(uid, sessionToken);
      } catch {
        // Ignorer si déjà supprimé
      }
    }

    // Effacer les taskUids en DB
    const dbConn = await db.getDb();
    if (dbConn) {
      await dbConn.update(weddings)
        .set({
          reminderJ30TaskUid: null,
          reminderJ7TaskUid:  null,
          reminderJ1TaskUid:  null,
        })
        .where(eq(weddings.id, wedding.id));
    }

    return { success: true, cancelled: uids.length };
  }),
});
