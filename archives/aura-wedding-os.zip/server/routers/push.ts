/**
 * AURA Wedding OS — Router Push Notifications
 *
 * Procédures tRPC pour gérer les abonnements push navigateur.
 */

import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import { getDb } from "../db";
import { pushSubscriptions } from "../../drizzle/schema";
import { eq, and } from "drizzle-orm";

export const pushRouter = router({
  // ─── S'abonner aux notifications push ──────────────────────────────────────
  subscribe: protectedProcedure
    .input(
      z.object({
        endpoint: z.string().url(),
        p256dh: z.string(),
        auth: z.string(),
        userAgent: z.string().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");

      const userId = String(ctx.user.id);

      // Vérifier si cet endpoint est déjà enregistré pour cet utilisateur
      const existing = await db
        .select()
        .from(pushSubscriptions)
        .where(
          and(
            eq(pushSubscriptions.userId, userId),
            eq(pushSubscriptions.endpoint, input.endpoint)
          )
        )
        .limit(1);

      if (existing.length > 0) {
        // Mettre à jour les clés (peuvent changer après renouvellement)
        await db
          .update(pushSubscriptions)
          .set({ p256dh: input.p256dh, auth: input.auth })
          .where(eq(pushSubscriptions.id, existing[0].id));
        return { subscribed: true, updated: true };
      }

      // Nouvel abonnement
      await db.insert(pushSubscriptions).values({
        userId,
        endpoint: input.endpoint,
        p256dh: input.p256dh,
        auth: input.auth,
        userAgent: input.userAgent,
      });

      return { subscribed: true, updated: false };
    }),

  // ─── Se désabonner ──────────────────────────────────────────────────────────
  unsubscribe: protectedProcedure
    .input(z.object({ endpoint: z.string() }))
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");

      const userId = String(ctx.user.id);

      await db
        .delete(pushSubscriptions)
        .where(
          and(
            eq(pushSubscriptions.userId, userId),
            eq(pushSubscriptions.endpoint, input.endpoint)
          )
        );

      return { unsubscribed: true };
    }),

  // ─── Statut de l'abonnement ─────────────────────────────────────────────────
  status: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return { subscribed: false, count: 0 };

    const userId = String(ctx.user.id);
    const subs = await db
      .select({ id: pushSubscriptions.id, userAgent: pushSubscriptions.userAgent, createdAt: pushSubscriptions.createdAt })
      .from(pushSubscriptions)
      .where(eq(pushSubscriptions.userId, userId));

    return {
      subscribed: subs.length > 0,
      count: subs.length,
      subscriptions: subs,
    };
  }),

  // ─── Notification de test ───────────────────────────────────────────────────
  sendTest: protectedProcedure.mutation(async ({ ctx }) => {
    const { sendPushToUser, PushTemplates } = await import("../_core/pushNotification");
    const userId = String(ctx.user.id);

    const result = await sendPushToUser(userId, {
      title: "🔔 Test AURA Wedding OS",
      body: "Les notifications push fonctionnent correctement ! Vous recevrez vos rappels J-30, J-7 et J-1 à cette adresse.",
      tag: "push-test",
      url: "/cockpit",
      panel: "settings",
    });

    return result;
  }),
});
